# Databricks notebook source
# MAGIC %md
# MAGIC # Source-to-semantic activation: setup
# MAGIC
# MAGIC This notebook loads the activation demo into this workspace. Everything it deploys was generated from the confirmed
# MAGIC source mappings; nothing here is written by hand except this notebook.
# MAGIC
# MAGIC **Before you run it**
# MAGIC 1. Import the package zip into the workspace (Workspace > Import). This notebook must stay in the imported folder.
# MAGIC 2. Attach serverless compute and choose **Run all**. The first run creates the catalog objects and stops, asking for
# MAGIC    the extracts archive.
# MAGIC 3. Upload `cg_activation_extracts.zip` to the volume it names (Catalog > the volume > Upload to this volume) and
# MAGIC    choose **Run all** again.
# MAGIC
# MAGIC Every step can be run again: it replaces what it created. `README.md` in this folder describes the options at the top
# MAGIC of the notebook and what each step creates.

# COMMAND ----------

# MAGIC %md ## Options

# COMMAND ----------

import json, os, re, shutil, time, zipfile
from concurrent.futures import ThreadPoolExecutor

dbutils.widgets.text("catalog", "", "Catalog (blank: the package default)")
dbutils.widgets.text("package_folder", "", "Package folder (blank: this notebook's folder)")
dbutils.widgets.text("extracts_zip", "", "Extracts archive path (blank: look in the volume)")
dbutils.widgets.dropdown("masks", "open", ["open", "enforced"], "Column masks")
dbutils.widgets.dropdown("fail_expectations", "as generated", ["as generated", "warn only"], "Fail expectations")
dbutils.widgets.dropdown("pipeline_update", "run", ["run", "validate only", "skip"], "Pipeline update")
dbutils.widgets.dropdown("tags", "all", ["all", "tables only", "none"], "Unity Catalog tags")
dbutils.widgets.dropdown("consumers", "create", ["create", "skip"], "Genie space and dashboard")
dbutils.widgets.text("warehouse_id", "", "SQL warehouse id (blank: the first one found)")


def _notebook_folder():
    given = dbutils.widgets.get("package_folder").strip()
    if given:
        return given if given.startswith("/Workspace") else "/Workspace" + given
    try:
        path = dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
        return "/Workspace" + os.path.dirname(path)
    except Exception:  # noqa: BLE001
        return os.getcwd()


HERE = _notebook_folder()
if not os.path.exists(os.path.join(HERE, "setup", "package.json")):
    raise Exception(f"The package files were not found in {HERE}. Set the 'Package folder' option to the workspace folder that holds "
                    "this notebook together with setup/, pipelines/, uc/ and semantic/ (for example /Workspace/Users/<you>/cg_activation_databricks).")
PKG = json.load(open(os.path.join(HERE, "setup", "package.json")))
DEFAULT_CATALOG = PKG["catalog"]
CATALOG = dbutils.widgets.get("catalog").strip() or DEFAULT_CATALOG
VOLUME = f"/Volumes/{CATALOG}/landing/{PKG['volume']}"
WARN_ONLY = dbutils.widgets.get("fail_expectations") == "warn only"
DEPLOYED = os.path.join(HERE, "_deployed")
RESULTS = {}          # step -> summary, printed at the end
print(f"package {PKG['version']} built {PKG['built']}; folder {HERE}; catalog {CATALOG}; extracts volume {VOLUME}")

# COMMAND ----------

# Helpers (databricks/demo_lib.py, inlined by the generator)
import datetime as _dt
import decimal as _dec
import re as _re

SCHEMAS = ("bronze", "silver", "gold", "quality", "governance", "landing")


def render(text, catalog, default_catalog, volume_path=None, warn_only=False):
    """A generated file as it is deployed: the catalog the generator ran with replaced by the chosen one (only where it
    is followed by one of the bundle's schemas, or inside a /Volumes/ path), the landing path filled in, and, when
    asked, every FAIL UPDATE expectation relaxed to a warning."""
    if catalog != default_catalog:
        pat = r"(?<![\w.`])" + _re.escape(default_catalog) + r"\.(?=(?:" + "|".join(SCHEMAS) + r")\b)"
        text = _re.sub(pat, catalog + ".", text)
        text = text.replace("/Volumes/" + default_catalog + "/", "/Volumes/" + catalog + "/")
    if volume_path is not None:
        text = text.replace("${volume_path}", volume_path.rstrip("/"))
    if warn_only:
        text = text.replace(" ON VIOLATION FAIL UPDATE", "")
    return text


def chunks(xs, n):
    xs = list(xs)
    return [xs[i:i + n] for i in range(0, len(xs), n)]


def norm(v):
    """A cell as it is compared: numbers to the cent, dates and timestamps as ISO text, everything else as text."""
    if v is None:
        return None
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float, _dec.Decimal)):
        f = round(float(v), 2)
        return 0.0 if f == 0 else f
    if isinstance(v, (_dt.datetime, _dt.date)):
        return v.isoformat()[:19].replace("T00:00:00", "")
    s = str(v)
    if _re.fullmatch(r"\d{4}-\d{2}-\d{2}[ T]00:00:00(\.0+)?", s):
        return s[:10]
    return s


def _close(a, b):
    if isinstance(a, float) and isinstance(b, float):
        return abs(a - b) <= 0.011 + 1e-9 * max(abs(a), abs(b))
    return a == b


def compare_answer(columns, expected_rows, expected_count, actual_rows):
    """An answer on the workspace against the local build's: the row count, and every expected row (the local build's
    first rows) found among the actual rows on the answer's columns. actual_rows are dicts or tuples in column order.
    Returns (ok, detail)."""
    act = []
    for r in actual_rows:
        if isinstance(r, dict):
            act.append(tuple(norm(r.get(c)) for c in columns))
        else:
            act.append(tuple(norm(x) for x in list(r)[:len(columns)]))
    if expected_count is not None and len(act) != expected_count:
        return False, f"{len(act)} rows, expected {expected_count}"
    index = {}
    for t in act:
        index.setdefault(tuple(x for x in t if not isinstance(x, float)), []).append(t)
    missing = 0
    for r in expected_rows or []:
        want = tuple(norm(r.get(c)) for c in columns)
        pool = index.get(tuple(x for x in want if not isinstance(x, float)), [])
        hit = next((t for t in pool if all(_close(a, b) for a, b in zip(t, want))), None)
        if hit is None:
            missing += 1
        else:
            pool.remove(hit)
    if missing:
        return False, f"{missing} of {len(expected_rows)} expected rows not found"
    return True, f"{len(act)} rows" + (f", {len(expected_rows)} compared" if expected_rows else "")

# COMMAND ----------

def R(text):
    """A generated text as deployed to the chosen catalog."""
    return render(text, CATALOG, DEFAULT_CATALOG, VOLUME, WARN_ONLY)


def read(rel):
    with open(os.path.join(HERE, rel), encoding="utf-8") as f:
        return f.read()


def statements(name):
    return [R(s) for s in json.loads(read(f"setup/statements/{name}.json"))]


def first_line(stmt):
    lines = [ln for ln in stmt.split("\n") if ln.strip() and not ln.strip().startswith("--")]
    return (lines[0] if lines else stmt)[:110]


def run_statements(name, stmts, workers=1, stop_on_error=False):
    """Runs each statement; collects failures instead of stopping (unless asked), so one refused statement never hides
    the rest. Returns the failures."""
    t, failed = time.time(), []

    def one(s):
        try:
            spark.sql(s)
            return None
        except Exception as ex:  # noqa: BLE001
            return dict(statement=first_line(s), error=str(ex).split("\n")[0][:400])

    if workers > 1:
        with ThreadPoolExecutor(workers) as pool:
            failed = [r for r in pool.map(one, stmts) if r]
    else:
        for s in stmts:
            r = one(s)
            if r:
                failed.append(r)
                if stop_on_error:
                    break
    RESULTS[name] = f"{len(stmts) - len(failed)} of {len(stmts)} statements in {time.time() - t:.0f}s" + (f"; {len(failed)} FAILED" if failed else "")
    print(name + ": " + RESULTS[name])
    for f in failed[:15]:
        print("  FAILED " + f["statement"] + "\n         " + f["error"])
    if len(failed) > 15:
        print(f"  ... and {len(failed) - 15} more")
    if failed and stop_on_error:
        raise Exception(f"{name}: {failed[0]['statement']}: {failed[0]['error']}")
    return failed


def makedirs(path):
    """os.makedirs for workspace folders, one level at a time (a parent must exist before its child is created)."""
    parts, cur = path.strip("/").split("/"), ""
    for p in parts:
        cur += "/" + p
        if not os.path.isdir(cur):
            os.mkdir(cur)


from databricks.sdk import WorkspaceClient
w = WorkspaceClient()


def api(method, path, body=None, query=None):
    return w.api_client.do(method, path, body=body, query=query)

# COMMAND ----------

# MAGIC %md ## 1. Catalog, schemas and the extracts volume

# COMMAND ----------

have = [r[0] for r in spark.sql("SHOW CATALOGS").collect()]
if CATALOG not in have:
    try:
        spark.sql(f"CREATE CATALOG IF NOT EXISTS `{CATALOG}`")
    except Exception as ex:  # noqa: BLE001
        raise Exception(f"Catalog '{CATALOG}' does not exist and could not be created ({str(ex).splitlines()[0][:200]}). Ask an administrator "
                        f"to create it, or set the 'Catalog' option to one you can create schemas in (one of: {', '.join(have[:8])}) and run again.")
for s in ("landing", "bronze", "silver", "gold", "quality", "governance"):
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS `{CATALOG}`.{s}")
spark.sql(f"CREATE VOLUME IF NOT EXISTS `{CATALOG}`.landing.{PKG['volume']}")
RESULTS["1 catalog"] = f"catalog {CATALOG} with schemas landing, bronze, silver, gold, quality, governance; volume {VOLUME}"
print(RESULTS["1 catalog"])

# COMMAND ----------

# MAGIC %md ## 2. The synthetic extracts
# MAGIC One CSV file per source table, unpacked to `<volume>/<source>/<TABLE>/`. The archive is unpacked on the driver's local
# MAGIC disk and copied to the volume (volumes do not take the random writes unzipping needs).

# COMMAND ----------

def find_zip():
    given = dbutils.widgets.get("extracts_zip").strip()
    if given:
        return given if os.path.exists(given) else None
    for folder in (VOLUME, HERE):
        try:
            hits = sorted(f for f in os.listdir(folder) if f.lower().endswith(".zip") and "extract" in f.lower())
        except Exception:  # noqa: BLE001
            hits = []
        if hits:
            return os.path.join(folder, hits[-1])
    return None


def extracts_present():
    missing = []
    for rel, size in PKG["extracts"].items():
        p = os.path.join(VOLUME, rel)
        if not os.path.exists(p) or os.path.getsize(p) != size:
            missing.append(rel)
    return missing


missing = extracts_present()
if missing:
    z = find_zip()
    if not z:
        raise Exception(f"The extracts are not in the volume yet. Upload {PKG['extracts_zip']} to {VOLUME} (Catalog > {CATALOG} > landing > "
                        f"{PKG['volume']} > Upload to this volume), then choose Run all again.")
    tmp = f"/tmp/cg_activation_extracts_{int(time.time())}"
    os.makedirs(tmp)
    shutil.copy(z, os.path.join(tmp, "extracts.zip"))
    with zipfile.ZipFile(os.path.join(tmp, "extracts.zip")) as zf:
        zf.extractall(os.path.join(tmp, "x"))
    for rel in PKG["extracts"]:
        dst = os.path.join(VOLUME, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy(os.path.join(tmp, "x", rel), dst)
    shutil.rmtree(tmp, ignore_errors=True)
    missing = extracts_present()
    if missing:
        raise Exception(f"{len(missing)} extract files are missing or incomplete after unpacking {z}, for example {missing[:3]}")
    print(f"unpacked {len(PKG['extracts'])} files from {z}")
RESULTS["2 extracts"] = f"{len(PKG['extracts'])} extract files in {VOLUME} ({sum(PKG['extracts'].values()) / 1e6:.0f} MB)"
print(RESULTS["2 extracts"])

# COMMAND ----------

# MAGIC %md ## 3. Pipeline source files, as deployed
# MAGIC The generated SQL under `pipelines/` is copied to `_deployed/` with the catalog and the volume path filled in. The
# MAGIC pipelines read `_deployed/`; `pipelines/` stays as generated.

# COMMAND ----------

if os.path.isdir(DEPLOYED):
    shutil.rmtree(DEPLOYED)
n = 0
for rel in PKG["pipeline_files"]:
    dst = os.path.join(DEPLOYED, rel)
    makedirs(os.path.dirname(dst))
    with open(dst, "w", encoding="utf-8") as f:
        f.write(R(read(rel)))
    n += 1
RESULTS["3 sources"] = f"{n} pipeline source files rendered to {DEPLOYED}" + (" (fail expectations relaxed to warnings)" if WARN_ONLY else "")
print(RESULTS["3 sources"])

# COMMAND ----------

# MAGIC %md ## 4. Column mask functions
# MAGIC `open` creates the functions so that every reader sees the value (this workspace has none of the account groups the
# MAGIC enforced definitions test, and a pipeline that cannot read a masked column builds empty names downstream).
# MAGIC `enforced` creates the generated access rules: add the pipeline's owner to the pipeline runners group first.

# COMMAND ----------

run_statements("4 mask functions", statements("access_functions_open" if dbutils.widgets.get("masks") == "open" else "access_functions"),
               stop_on_error=True)

# COMMAND ----------

# MAGIC %md ## 5. The pipelines
# MAGIC Two Lakeflow declarative pipelines, run in order: the lakehouse (bronze from the extracts, silver, gold) and quality
# MAGIC (the validation views, expectation results and scorecard, which read the lakehouse's tables). They are two because a
# MAGIC pipeline holds at most 1,000 tables.

# COMMAND ----------

def pipeline_spec(p):
    return dict(name=p["name"], catalog=CATALOG, schema=p["schema"], serverless=True, continuous=False, channel="CURRENT", photon=True,
                development=True, configuration={"volume_path": VOLUME},
                libraries=[dict(glob=dict(include=f"{DEPLOYED}/{folder}/**")) for folder in p["folders"]])


def ensure_pipeline(p):
    spec = pipeline_spec(p)
    found = api("GET", "/api/2.0/pipelines", query=dict(filter=f"name LIKE '{p['name']}'", max_results=10)).get("statuses", [])
    found = [x for x in found if x.get("name") == p["name"]]
    if found:
        pid = found[0]["pipeline_id"]
        api("PUT", f"/api/2.0/pipelines/{pid}", body=dict(spec, id=pid))
        return pid, "updated"
    return api("POST", "/api/2.0/pipelines", body=spec)["pipeline_id"], "created"


def pipeline_errors(pid, since_ms, limit=12):
    out = []
    try:
        ev = api("GET", f"/api/2.0/pipelines/{pid}/events", query=dict(filter="level='ERROR'", max_results=50)).get("events", [])
    except Exception as ex:  # noqa: BLE001
        return [f"(the event log could not be read: {str(ex)[:150]})"]
    for e in ev:
        msg = e.get("message", "")
        exc = ((e.get("error") or {}).get("exceptions") or [{}])[0].get("message", "")
        line = (msg + (" | " + exc.split("\n")[0] if exc else ""))[:600]
        if line not in out:
            out.append(line)
    return out[:limit]


def run_update(pid, name, validate_only):
    t = time.time()
    body = dict(validate_only=True) if validate_only else dict(full_refresh=False)
    uid = api("POST", f"/api/2.0/pipelines/{pid}/updates", body=body)["update_id"]
    state, last = "", ""
    while True:
        state = api("GET", f"/api/2.0/pipelines/{pid}/updates/{uid}").get("update", {}).get("state", "")
        if state != last:
            print(f"  {name}: {state} ({time.time() - t:.0f}s)")
            last = state
        if state in ("COMPLETED", "FAILED", "CANCELED"):
            break
        time.sleep(20)
    if state != "COMPLETED":
        errs = pipeline_errors(pid, t)
        print("\n".join("  ERROR " + e for e in errs))
        raise Exception(f"The update of pipeline '{name}' ended {state}. The errors above are from its event log; open the pipeline "
                        "(Jobs & Pipelines) for the dataset each belongs to. If an expectation stopped the update, set the "
                        "'Fail expectations' option to 'warn only' and run again.")
    return f"{'validated' if validate_only else 'updated'} in {time.time() - t:.0f}s"


mode = dbutils.widgets.get("pipeline_update")
PIPELINES = {}
for p in PKG["pipelines"]:
    pid, what = ensure_pipeline(p)
    PIPELINES[p["key"]] = pid
    print(f"pipeline '{p['name']}' {what}: {pid} ({p['tables']} tables, {p['datasets']} datasets)")
    if mode == "skip":
        RESULTS[f"5 pipeline {p['key']}"] = f"{what}, not run"
        continue
    if mode == "validate only" and p["key"] != PKG["pipelines"][0]["key"]:
        RESULTS[f"5 pipeline {p['key']}"] = f"{what}; not validated (it reads the tables the first pipeline creates when it runs)"
        continue
    RESULTS[f"5 pipeline {p['key']}"] = f"{what}, " + run_update(pid, p["name"], mode == "validate only")
    print(RESULTS[f"5 pipeline {p['key']}"])
if mode != "run":
    dbutils.notebook.exit(json.dumps(RESULTS, indent=1))

# COMMAND ----------

# MAGIC %md ## 6. Unity Catalog tags and bronze column comments
# MAGIC Comments, keys and masks of the pipeline's datasets are in their definitions; tags are set here. A refused statement
# MAGIC is listed and does not stop the setup.

# COMMAND ----------

tag_mode = dbutils.widgets.get("tags")
if tag_mode == "none":
    RESULTS["6 tags"] = "skipped"
else:
    stmts = statements("metadata")
    if tag_mode == "tables only":
        stmts = [s for s in stmts if " ALTER COLUMN " not in s]
    run_statements("6 tags", stmts, workers=8)

# COMMAND ----------

# MAGIC %md ## 7. The semantic layer
# MAGIC Semantic views and their public (no personal data) versions, the metric views, and the semantic views' tags.

# COMMAND ----------

run_statements("7a semantic views", statements("semantic_views"))
run_statements("7b metric views", statements("metric_views"))
if tag_mode != "none":
    run_statements("7c semantic tags", statements("semantic_tags"), workers=4)

# COMMAND ----------

# MAGIC %md ## 8. Genie space and the quality dashboard
# MAGIC Both are created in this folder. A workspace without Genie or dashboards reports it here and the setup goes on.

# COMMAND ----------

LINKS = {}
if dbutils.widgets.get("consumers") == "create":
    wh = dbutils.widgets.get("warehouse_id").strip()
    if not wh:
        try:
            whs = api("GET", "/api/2.0/sql/warehouses").get("warehouses", [])
            whs.sort(key=lambda x: (not x.get("enable_serverless_compute", False), x.get("state") != "RUNNING"))
            wh = whs[0]["id"] if whs else ""
        except Exception as ex:  # noqa: BLE001
            print("no SQL warehouse could be listed: " + str(ex)[:200])
    parent = HERE[len("/Workspace"):] if HERE.startswith("/Workspace") else HERE
    if not wh:
        RESULTS["8 consumers"] = "skipped: no SQL warehouse (set the 'SQL warehouse id' option)"
    else:
        g = PKG["genie"]
        try:
            body = dict(title=g["title"], description=g["description"], warehouse_id=wh, parent_path=parent, serialized_space=R(read(g["file"])))
            sid = api("POST", "/api/2.0/genie/spaces", body=body).get("space_id")
            LINKS["Genie space"] = f"/genie/rooms/{sid}"
            RESULTS["8a genie"] = f"space {sid} created"
        except Exception as ex:  # noqa: BLE001
            RESULTS["8a genie"] = "NOT created: " + str(ex).split("\n")[0][:300]
        d = PKG["dashboard"]
        try:
            body = dict(display_name=d["title"], warehouse_id=wh, parent_path=parent, serialized_dashboard=R(read(d["file"])))
            did = api("POST", "/api/2.0/lakeview/dashboards", body=body).get("dashboard_id")
            LINKS["Quality dashboard"] = f"/dashboardsv3/{did}"
            RESULTS["8b dashboard"] = f"dashboard {did} created (a draft: publish it from its page)"
        except Exception as ex:  # noqa: BLE001
            RESULTS["8b dashboard"] = "NOT created: " + str(ex).split("\n")[0][:300]
else:
    RESULTS["8 consumers"] = "skipped"
for k in sorted(RESULTS):
    if k.startswith("8"):
        print(k + ": " + RESULTS[k])

# COMMAND ----------

# MAGIC %md ## 9. Check the load against the local build
# MAGIC Row counts of every bronze, silver and gold dataset, the quality scorecard, and the verified answers (each question's
# MAGIC SQL, run here, against the rows the local build proved).

# COMMAND ----------

EXP = json.loads(read("setup/expected.json"))
counts, problems = {}, []
for part in chunks(sorted(EXP["rows"]), 40):
    sql = " UNION ALL ".join(f"SELECT '{n}' AS n, COUNT(*) AS c FROM `{CATALOG}`.{n}" for n in part)
    try:
        counts.update({r["n"]: r["c"] for r in spark.sql(sql).collect()})
    except Exception:  # noqa: BLE001
        for n in part:                       # one missing table must not hide the rest of its chunk
            try:
                counts[n] = spark.table(f"`{CATALOG}`.{n}").count()
            except Exception as ex:  # noqa: BLE001
                counts[n] = None
                problems.append(f"{n}: not readable ({str(ex).splitlines()[0][:120]})")
diff = [(n, e["rows"], counts.get(n)) for n, e in sorted(EXP["rows"].items()) if counts.get(n) is not None and counts[n] != e["rows"]]
by_layer = {}
for n, e in EXP["rows"].items():
    a = by_layer.setdefault(e["layer"], [0, 0])
    a[0] += 1
    a[1] += counts.get(n) == e["rows"]
RESULTS["9a row counts"] = "; ".join(f"{layer}: {ok} of {n} datasets match" for layer, (n, ok) in sorted(by_layer.items()))
print(RESULTS["9a row counts"])
for n, want, got in diff[:25]:
    print(f"  DIFFERS {n}: {got} rows here, {want} in the local build")
for p in problems[:25]:
    print("  " + p)

try:
    score = spark.sql(f"SELECT score FROM `{CATALOG}`.quality.scorecard WHERE scope = 'ALL'").collect()[0][0]
    RESULTS["9b scorecard"] = f"{float(score):.2f} here, {EXP['scorecard']} in the local build"
except Exception as ex:  # noqa: BLE001
    RESULTS["9b scorecard"] = "not readable: " + str(ex).splitlines()[0][:200]
print("scorecard: " + RESULTS["9b scorecard"])

ANS = json.loads(read(PKG["answers_file"]))
ok_n, bad = 0, []
for b in ANS["benchmarks"]:
    if not b.get("columns"):
        continue                                       # a drill-down: no expected rows were kept
    try:
        rows = [r.asDict() for r in spark.sql(R(b["sql"])).collect()]
        ok, detail = compare_answer(b["columns"], b["rows"], b.get("row_count"), rows)
    except Exception as ex:  # noqa: BLE001
        ok, detail = False, str(ex).splitlines()[0][:200]
    ok_n += ok
    if not ok:
        bad.append(f"{b['key']}: {detail}")
RESULTS["9c answers"] = f"{ok_n} of {ok_n + len(bad)} verified answers reproduce"
print(RESULTS["9c answers"])
for x in bad[:25]:
    print("  DIFFERS " + x)

# COMMAND ----------

# MAGIC %md ## The closing question
# MAGIC *What assets are my intermediary clients focused on for the past year?*

# COMMAND ----------

closing = next((b for b in ANS["benchmarks"] if b["key"] == PKG.get("closing_key")), None)
if closing:
    display(spark.sql(R(closing["sql"])))

# COMMAND ----------

# MAGIC %md ## Summary

# COMMAND ----------

host = spark.conf.get("spark.databricks.workspaceUrl", "")
for key, pid in PIPELINES.items():
    LINKS[f"Pipeline: {key}"] = f"/pipelines/{pid}"
LINKS["Catalog"] = f"/explore/data/{CATALOG}"
rows = "".join(f"<tr><td style='padding:2px 12px 2px 0'><b>{k}</b></td><td>{v}</td></tr>" for k, v in sorted(RESULTS.items()))
links = " &nbsp;|&nbsp; ".join(f"<a href='https://{host}{u}' target='_blank'>{k}</a>" if host else f"{k}: {u}" for k, u in LINKS.items())
displayHTML(f"<h3>Activation demo loaded into catalog {CATALOG}</h3><table>{rows}</table><p>{links}</p>")
