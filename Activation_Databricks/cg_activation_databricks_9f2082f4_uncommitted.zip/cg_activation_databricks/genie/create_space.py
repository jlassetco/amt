"""Creates (or updates) the Genie space from genie/distribution_performance.geniespace.json through the Genie management API, for workspaces that do
not deploy it with the bundle's genie_spaces resource (which needs the direct deployment engine).

    DATABRICKS_HOST=https://<workspace> DATABRICKS_TOKEN=<token> WAREHOUSE_ID=<id> python genie/create_space.py [--space-id <id>]

POST /api/2.0/genie/spaces creates; PATCH /api/2.0/genie/spaces/<id> updates. Standard library only.
"""
import json, os, sys, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
space = json.load(open(os.path.join(HERE, "distribution_performance.geniespace.json")))
body = dict(title="Distribution Performance", description="Certified flows and AUM of the distribution semantic model (SM-01, SM-00).",
            warehouse_id=os.environ["WAREHOUSE_ID"], serialized_space=json.dumps(space))
sid = sys.argv[sys.argv.index("--space-id") + 1] if "--space-id" in sys.argv else None
url = os.environ["DATABRICKS_HOST"].rstrip("/") + "/api/2.0/genie/spaces" + (f"/{sid}" if sid else "")
req = urllib.request.Request(url, data=json.dumps(body).encode(), method="PATCH" if sid else "POST",
                             headers={"Authorization": "Bearer " + os.environ["DATABRICKS_TOKEN"], "Content-Type": "application/json"})
print(json.load(urllib.request.urlopen(req)))
