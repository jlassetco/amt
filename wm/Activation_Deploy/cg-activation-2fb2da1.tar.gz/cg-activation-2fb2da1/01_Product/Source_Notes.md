# Source Notes: 01 Investment Product & Service Offering (Draft v0.1, 2026-10-14)

Workbook: `Investment_Product_Reference_Data_Taxonomy.xlsx` (path unchanged). Content module: `_tools/content/content_01_product.py` (adapted in place; the wholesale version is at tag `wholesale-v1.0`). Enrichment: `_tools/enrichment/enrich_01.py`. Proposals: `_tools/consolidation/proposals_w1_01.py` (jurisdiction pass CW-901).
Size: 17 families, 54 objects (25 business objects, 29 attribute groups), 320 attributes, 112 CDEs (35%), 67 code lists, 42 relationships, 24 sources. The wholesale module had 14 families, 49 objects and 314 attributes (48 objects and 307 attributes once the excluded Record Metadata object is left out). Revised 2026-10-14 after the review (00_Program/Rework/Reviews/01_review.md).

**Perspective.** A US wealth manager that serves investors directly (wealth manager (direct), scope US): direct brokerage, digital and human advice, its own mutual funds, ETFs and bank-maintained CITs, workplace retirement recordkeeping, institutional advisory, a thin intermediary channel and optional personal trust services (the eight CW-004 business lines). 01 is the catalog of what the firm offers. Product management produces it: the funds, plus the services clients choose between alongside them.

## 0. Why this domain exists, and what the adaptation changed

01 is still the catalog the product management group maintains. It covers strategies, funds, ETFs, CITs, share classes, mandates, model portfolios, benchmarks, fund fees, documents, commentary and lifecycle. A direct wealth manager also sells services: advice programs, service tiers, a brokerage platform with a tradable universe, and access to alternatives through feeder funds. Each is defined once here and then enrolled in (15), recommended (45), managed (46) and billed (47) elsewhere. They sit next to the funds because clients choose between them together and because 36 governs both launches.

This is an adaptation, not a rewrite. Every family, object and attribute that is not EU/UK-only keeps its name, because about 50 products and models read 01 by name (CW-021). Legacy family codes (`STR`, `PRD`, `SHC`, ...) are unchanged; the three new families take the `PR-` stem (CW-040).

| Wholesale object | Disposition | What changed |
|---|---|---|
| Target Market | Dropped | MiFID II (CW-901). Suitability and best-interest evidence is 45; the product risk is the Firm Risk Rating |
| Country Registration | Dropped | UCITS / AIFMD passports. US registration and state notice filings are 35 Fund Regulatory Filing (SME question 3) |
| Share Class Tax Reporting | Dropped | UK, German and Austrian tax reporting. US distribution character is 27 |
| Record Metadata | Dropped | Excluded (CD-160); governance metadata is modeled once in 21 |
| ESG Classification | Re-cut | Keeps ESG Investment Approach and ESG Term in Name Indicator (SEC Rule 35d-1); five SFDR / Taxonomy / label fields removed |
| Product Risk Indicator | Re-cut | SRI, SRRI and Global Exposure Method removed; Local Regulatory Risk Rating renamed Firm Risk Rating (CDE); Derivatives Risk Category (Rule 18f-4) added |
| Cost Disclosure | Re-cut | OCF, Transaction Costs and Ex-Ante Ongoing Costs removed; Acquired Fund Fees and Expenses added (Form N-1A Item 3) |
| Investor Transaction Charge | Re-sourced | Front-end load and purchase fee (Maximum Entry Charge), redemption fee under Rule 22c-2 (Maximum Exit Charge), CDSC, Switching Charge as the Form N-1A Item 3 exchange fee, swing pricing under Rule 22c-1(a)(3) |
| Performance Fee | Re-sourced | Fund-level terms of own funds only: the fulcrum fee of registered funds (Advisers Act §205(b)(2), Rules 205-1 and 205-2) and the incentive fee of own feeder and other qualified-client funds (Rule 205-3), with High-Water Mark Indicator and Crystallization Frequency kept for those. Fee Accrual Basis and Fee Breakpoint Schedule apply to share classes only; a mandate's fees are 47 |
| Other Ongoing Fees | Re-cut | Trail Commission Indicator removed; 12b-1 and shareholder servicing stay |
| Income Distribution | Re-cut | Fees Charged to Capital Indicator and the Distribution Policy value Distributing - Gross Income removed (UK and Irish income-share practice) |
| Investment Mandate | Re-cut | Mandate Type loses SMA / Wrap Program and UMA Sleeve: a retail managed account is a 15 account with a 46 model assignment; institutional separate accounts stay |
| Regulatory Classification, External Classification, Security Identifier, Benchmark, Product Tax Status, Product Governance | Re-cut | MiFID Complexity, EFAMA and IA categories, SEDOL / Valoren / WKN, BMR Register Status, CRS Entity Classification and Value Assessment Outcome removed |
| Fund Legal Structure, Investment Objective & Policy, Regulatory Authorization, Product Document, Product Party Role | Re-sourced | US legal forms and regimes, Rule 18f-4 leverage, ICA §18(f) borrowing, SEC and OCC as regulators, Rule 498 and Rule 30e-1 documents, sub-adviser delegation |
| Distribution Availability | Re-cut | Channels: direct brokerage, advice program, workplace plan menu, intermediary, institutional; partner shelf status stays 05 |
| Firm Product Classification | Re-cut | Business Line takes the CW-004 values |
| ETF Characteristics | Extended | ETF Share Class Indicator (multi-class ETF relief) |
| Product Relationship, Lifecycle Event | Extended | Relationship type "Feeder Of"; lifecycle events apply to service offerings |
| All other objects | Kept | Names, grains and attributes unchanged; examples moved to US values (USD, US domicile, NYSE calendar, ARCX listing, T+1) |
| *New:* Service Offering, Offering Feature, Offering Eligibility Rule, Offering Fee Schedule Link, Service Tier | Added (PR-ASO) | CW-036, CW-028 |
| *New:* Tradable Universe Policy Rule, Platform Product Availability | Added (PR-PLT) | CW-037 |
| *New:* Feeder Access Terms, Offering Window | Added (PR-ALT) | CW-038 |

## 1. Sources consulted

| Source | URL | What it gave us |
|---|---|---|
| SEC Form N-1A (Items 3, 4, 5, 12, 18) | https://www.sec.gov/files/formn-1a.pdf (confirm) | Fee table, including the acquired fund fees and expenses line and shareholder fees (sales load, purchase fee, redemption fee); broad-based index in the performance table; share class and sales load disclosure. Drove Cost Disclosure, Investor Transaction Charge, Benchmark Usage Type and the re-sourced fee attributes. |
| SEC Rule 498 (summary prospectus); Rule 30e-1 (tailored shareholder reports) | https://www.ecfr.gov/current/title-17/section-230.498 | Document Type values Summary Prospectus and Tailored Shareholder Report. |
| Investment Company Act rules 2a-7, 6c-11, 12d1-4, 18f-4, 22c-1, 22c-2, 35d-1, 3a-4 (17 CFR Part 270) | https://www.ecfr.gov/current/title-17/chapter-II/part-270 | MMF Type (government, prime retail and institutional, tax-exempt; institutional prime liquidity fee); ETF characteristics; fund of funds; Derivatives Category and Leverage Method (limited derivatives user at 10% exposure, relative VaR 200% and absolute VaR 20%, 250% and 25% for closed-end funds); forward pricing and swing pricing; redemption fee of up to 2%; the 80% names policy; the advisory program safe harbor (Rule 3a-4 Program Indicator, Custom Restrictions Allowed). |
| Investment Company Act of 1940 (§2(a)(51), §3(c)(1), §3(c)(7), §12(d)(1)(E), §15(a), §18(f)) | https://www.law.cornell.edu/uscode/text/15/chapter-2D/subchapter-I | Regulatory Regime values, master-feeder, advisory and sub-advisory contracts, borrowing limit, qualified purchaser. |
| Advisers Act §205(b), Rules 205-1, 205-2 and 205-3; Form ADV Part 2A and Appendix 1 | https://www.ecfr.gov/current/title-17/section-275.205-1 | Fulcrum fee (symmetric adjustment around an index; the measurement period is Rule 205-2, minimum length to confirm); incentive fees of own qualified-client funds such as feeders, with high-water mark and crystallization; wrap fee program brochure (Wrap Fee Program Indicator). |
| Regulation Best Interest (Exchange Act Rule 15l-1) | https://www.ecfr.gov/current/title-17/section-240.15l-1 | Advisory Capacity (broker-dealer under Reg BI vs investment adviser); Firm Risk Rating as the product side of the recommendation match in 45. |
| SEC IM Guidance Update No. 2017-02, Robo-Advisers | https://www.sec.gov/investment/im-guidance-2017-02.pdf | Disclosure of the digital advice service, its algorithms, rebalancing and the role of human advisors: Offering Type, Delivery Mode, Offering Feature Type. |
| OCC 12 CFR 9.18 (collective investment funds) | https://www.ecfr.gov/current/title-12/chapter-I/part-9/section-9.18 | US Bank CIT regime, Bank Collective Trust legal form, CIT Disclosure Document, Trustee role, Group Trust tax classification. |
| FINRA Rules 2341 and 2265; Notice to Members 05-26 | https://www.finra.org/rules-guidance/rulebooks/finra-rules | Sales charges of investment company securities (Maximum Entry Charge, CDSC); extended-hours trading risk disclosure (Universe Rule Type); new product vetting (Product Governance dates re-sourced from MiFID II). |
| Regulation D Rule 506 and Rule 501(a) | https://www.ecfr.gov/current/title-17/section-230.506 | Feeder eligibility (Required Investor Qualification, accredited investor). |
| SEC Rule 35d-1 (fund names) | https://www.ecfr.gov/current/title-17/section-270.35d-1 | ESG Term in Name Indicator, re-sourced from the ESMA fund names guidelines. |
| ICI investment classifications; Morningstar categories | https://www.ici.org ; https://www.morningstar.com | Asset Class and Strategy Classification alignment (replacing EFAMA EFC); External Classification. |
| openfunds field dictionary | https://www.openfunds.org | Fund master cross-check, market-neutral fields only. |
| FIBO CIV, ISO 6166 / 10962 / 18774 / 17442 / 4217 / 3166 / 10383 / 639 / 8601, OpenFIGI, GIPS | as in the Sources tab | Kept unchanged (market-neutral). |
| IOSCO Principles for Financial Benchmarks | https://www.iosco.org | Benchmark Administrator re-sourced from the EU BMR. |
| Vendor wealth platform models (Morningstar Direct, Envestnet, Orion) | vendor sites | Cross-check only of offering, model and platform structures; nothing taken verbatim. |

Removed sources (recorded in JURISDICTION): FinDatEx EMT, EPT and EET; EFAMA EFC; IA Sectors; SFDR and RTS; PRIIPs; MiFID II product governance; UCITS / AIFMD / EU MMFR / EU BMR; ESMA guidelines; UK FCA COLL, SDR and Consumer Duty; HMRC / InvStG / OeKB. The DCAM source was dropped because only the excluded Record Metadata object cited it.

## 2. Design and boundary decisions

1. **An offering is not an enrollment, a model or a fee (CW-036, CW-032).** Service Offering (`OFFR-`) defines the program: type, delivery mode, discretion, advisory capacity, sponsoring legal entity (09 `LEN-`), wrap fee and Rule 3a-4 indicators, the model portfolios it implements (`MDL-`) and status. 15 Program Enrollment holds the account in it, 46 the model assignment, 47 the fee schedule and billing, 45 the recommendation. The offering holds no rate, breakpoint or billing attribute: Offering Fee Schedule Link references the 47 schedule for a period, as Standard or Promotional (SME question 9).
2. **Offering minimums are eligibility rules, with an effective period** (Eligibility Effective From and To, so a changed threshold keeps its history for 15 enrollment checks). There is no "minimum investment" attribute on the offering. The minimum is an Offering Eligibility Rule (`ELIG-`) with criterion Minimum Assets, so that one rule shape covers assets, account registration types (15), investor qualification, residence state, plan participation and service tier. 15 applies the rules at enrollment.
3. **Offering status uses the Lifecycle Status list.** The brief expected a local Offering Status list. The existing Lifecycle Status values (Proposed, In Development, Active, Soft Closed, Hard Closed, ...) fit offerings, so Offering Status reuses that list, and launches, closes and term changes are Lifecycle Events (new type "Change of Offering Terms").
4. **Offering Feature is a lean attribute group** (feature type and setting; a row means the feature is offered). Rebalancing frequency, tax-loss harvesting thresholds and advisor access live in Feature Setting. Account-level feature elections are 15 (Account Feature) and 46 (tax-loss harvesting preference).
5. **Service Tier (CW-028)** is firm-wide (SME question 2), keyed by its tier code (no prefix; the brief rejected `TIER-` and others). The measurement basis is a code; the measured household amount is held on the 02 Service Tier Assignment as a derived copy of 06 client assets. The tier's fee discount is not held here: 47 references the tier in its schedules or waivers. Review frequency is an assignment process in 02 and is not held here either.
6. **Policy here, flags in 17, checks in 48 (CW-037).** Tradable Universe Policy Rule (`TUP-`) holds the rule name, type, criteria (instrument types and session times included), status and effective period. 17 holds each instrument's Fractional Trading Eligible and Extended-Hours Eligible flags with the `TUP-` reference; 48 checks orders. The approving committee is named in the definition, not held as an attribute: approval is a 36 change initiative.
7. **Platform Product Availability** (group label Brokerage Platform Availability, to keep it apart from the kept 05 shelf reference Distribution Availability.Platform Availability) is the operational status on the firm's own platform; Distribution Channel is the commercial channel decision. It has one row per own share class (`SHC-`) or third-party fund or ETF (17 `INS-`) per effective date. Exactly one of the two references is filled (ROW_OWNERSHIP in enrich_01.py). Transaction Fee Category holds the fee treatment only (No Transaction Fee, Transaction Fee, Short-Term Trading Fee Only); whether the product is the firm's own follows from which reference is filled. The due diligence approval references 52 Product Due Diligence (curated platform, SME question 4); 47 holds the transaction-fee amounts.
8. **A feeder is a product (CW-038).** The feeder is an Investment Product (Vehicle Type Feeder Fund, Tender-Offer Fund or Interval Fund) with Feeder Access Terms: access structure (Feeder Fund, Tender-Offer Fund or Interval Fund from the shared Vehicle Type list), underlying private fund instrument (17; filled for a feeder fund only, since an interval or tender-offer fund is itself the vehicle with its own 18 portfolio), and required investor qualification using the shared Investor Qualification Standard (02 steward). The feeder's minimum is the share class Minimum Initial Investment; its placement agent is a Product Party Role (new role value Placement Agent); its liquidity terms are Dealing Terms (notice period, lock-up, gate). Holding these again in Feeder Access Terms would hold the same fact twice. Offering Window (`OFWN-`) holds open and close dates, capacity and status. The subscription is 15 (`AISB-`); the holding is 49.
9. **Fund expense terms stay here; client fees are 47 (CW-036).** The Fees, Charges & Costs family holds fund-level prospectus and offering-document fee terms of own funds (`FSCH-`, CD-023). Fee Breakpoint Schedule is the advisory agreement breakpoints on fund assets; a mandate's management, breakpoint and performance fees are client fees in 47.
10. **Firm Risk Rating** is a product attribute on the firm's 1-5 scale (SME question 8), the scale 45 matches to the investor profile. Derivatives Risk Category (Rule 18f-4) is a separate fact from Leverage Calculation Method (which VaR test applies).
11. **Business Line** keeps its list name with the eight CW-004 values. The wholesale 01 values (Retail, Institutional, Wealth, Insurance, Retirement) were client segments; the consolidation layer currently renames the 01 list to "Client Segment" (LOCAL_RENAMES, CD-209), and that rename must be removed at merge (proposals_w1_01.NOTES).
12. **Foreign investment universe kept (CW-022).** Geographic Focus keeps Europe and Asia Pacific, Hedging and Currency Hedging stay, foreign benchmarks stay, Listing keeps any MIC. Only EU/UK regime content was removed.

**Deviations from the brief.** The fields left out of CW-028, CW-036, CW-037 and CW-038 are stated as an amendment in the CW-901 resolution (proposals_w1_01.py), so the register carries them.
- Size: 320 attributes against the band of 280 to 300 (see proposals_w1_01.NOTES: 307 built wholesale attributes less 42 EU/UK removals is 265, plus 55 additions). The review restored three over-removed fee terms and asked for rule periods, a rule name and status; the lead is asked to widen the 01 band. The brief's optional folds were not applied: folding Commentary Approval into Investment Commentary saves no attributes, and moving NAV Publication Channel to 27 saves one at the cost of a kept-name change.
- Not held (CW-901 amendment): offering launch and close dates (lifecycle events), offering minimum investment (eligibility rule), tier review frequency and fee discount reference (02 and 47), approving committee (36), platform minimums and restriction reason (share class minimums, a Purchase Restriction rule and the availability status), feeder liquidity terms, minimum commitment and placement agent (Dealing Terms, Investor Eligibility, Product Party Role).
- Local lists: Offering Status not created (Lifecycle Status reused) and Feeder Access Structure not created (shared Vehicle Type reused); Comparison Operator added, plus a local copy of the shared Investor Qualification Standard.
- Legal Form, Party Role Type, Pricing Model, Pricing Basis, Distribution Policy, Anti-Dilution Mechanism, Derivatives Usage, Share Class Type, Vehicle Type, Distribution Channel and Audience Restriction lost EU/UK values the brief did not list one by one: SICAV, SICAF, FCP, ICAV, PLC, Unit Trust, ACS, SCSp; Management Company, Paying / Facilities Agent; dual pricing; EPM; Platform / Super-Clean; Pooled Pension / Unit-Linked; Professional Investors Only; Historic pricing; Full Swing Pricing; Distributing - Gross Income (with the Fees Charged to Capital Indicator). All are recorded in JURISDICTION under CW-901.
- The proposals file is `proposals_w1_01.py` (the brief names `proposals_01.py`; the assignment set the W1 name).

## 3. Unverified items

- The Form N-1A PDF path was checked by the reviewer, as was the IM Guidance Update 2017-02 path.
- Fulcrum fee measurement period: Advisers Act Rule 205-2 sets the averaging period; confirm the minimum rolling period (12 months) used in the Performance Reference Period example.
- ETF share classes of mutual funds: the SEC began granting multi-class ETF exemptive relief in 2025. Confirm the status and conditions before relying on the ETF Share Class Indicator values for the firm's range (SME question 5).
- Rule 2a-7 after the 2023 amendments: mandatory liquidity fees for institutional prime and institutional tax-exempt funds and the removal of redemption gates. The MMF Type descriptions assume the amendments are in force (confirm compliance dates).
- Rule 35d-1 amendments (2023): compliance dates were extended. Confirm the date that applies to the firm's fund group.
- FINRA Notice to Members 05-26 as the source for product vetting: it is long-standing guidance, not a rule; confirm the firm's own new product policy.
- The 47 fee schedule and 52 product due diligence objects and keys are not yet drafted; the references use "Reference (Fee Schedule, 47)" and "Reference (Product Due Diligence, 52)" with ownership forced in enrich_01.py.

## 4. SME questions (tailoring levers, with the reference default)

1. Which advice offerings does the reference firm run? *Default:* digital, hybrid and personal advisor, wealth management, planning only, workplace managed account, OCIO. *Lever:* a self-directed-only firm drops the Advice & Service Offerings family.
2. Are service tiers firm-wide or per offering? *Default:* firm-wide relationship tiers measured on household client assets.
3. Where are state notice filings for registered funds held? *Default:* 35 Fund Regulatory Filing.
4. Is the third-party fund platform curated or open? *Default:* curated, with the 52 due diligence approval referenced. *Lever:* an open platform leaves Due Diligence Approval empty.
5. Do ETF share classes of mutual funds exist in the range? *Default:* the indicator exists; values depend on relief.
6. Which alternatives are offered? *Default:* feeders, tender-offer funds and interval funds only.
7. Does the firm offer extended-hours and overnight sessions? *Default:* pre-market and after-hours, stated in the rule criteria.
8. Is the firm risk rating a product attribute or the output of a 37 model? *Default:* a product attribute; where a model computes it, the model is referenced in the methodology.
9. Is a promotional fee schedule an offering link or a 47 waiver? *Default:* an offering link of type Promotional.
10. Should the Investor Type list keep Accredited Investor and Qualified Purchaser now that feeders use the shared Investor Qualification Standard? *Default:* keep for this draft and decide at W5 (TERM_CONFLICTS).
11. Does the firm run offshore feeders (Cayman)? *Default:* no; the Cayman regime value was removed and is restorable from the register.

## 5. Overlaps with other domains (for consolidation)

| Domain | Overlap | Handling |
|---|---|---|
| 02 Client & Household | Service Tier Assignment references Service Tier; Investor Qualification Standard steward | Tier defined here, assigned in 02; local copy of the shared list registered in SHARED_MEMBERSHIPS |
| 15 Account | Program Enrollment references `OFFR-`; Alternative Investment Subscription references `OFWN-` and `PRD-`; Sweep Election references money market share classes | References only; no enrollment fact here |
| 17 Instrument & Issuer | Fractional and extended-hours flags set by `TUP-` rules; third-party funds and ETFs on the platform; underlying fund interest of a feeder | 17 holds the flags with the rule reference; 01 references `INS-` |
| 45 Financial Planning & Advice | Firm Risk Rating; offerings recommended | 45 references `OFFR-`, `SHC-` and the rating |
| 46 Managed Portfolios | Model Portfolios Used; offering features such as tax-loss harvesting | 46 assigns models and holds account preferences |
| 47 Pricing, Fees & Billing | Offering Fee Schedule Link; transaction-fee amounts; tier discounts | 47 masters schedules; prefix not to be confusable with `FSCH-` |
| 48 Brokerage Orders | Order checks against `TUP-` rules | 48 applies the rules |
| 52 External Manager Oversight | Due Diligence Approval; sub-adviser role | Typed reference; 52 masters reviews |
| 05 Distribution Agreements | Platform Availability (intermediary shelf) | Kept as a reference to 05 (IC line) |
| 35 Fund Governance | Registration and state notice filings; fund board | Country Registration dropped; 35 Fund Regulatory Filing |
| 31, 14 | Removed derived copies of SRI / SRRI (31) and BMR status (14) | Their US-only passes check the producing objects |

## 6. Next steps

1. Validate the offering set, tiers, platform policy and feeder terms with the advice program owners, Brokerage Product, Product Management and Legal.
2. Align Offering Fee Schedule Link with the 47 brief (object name, prefix) and Due Diligence Approval with the 52 brief; remove the OWNERSHIP_OVERRIDES once the concepts are registered.
3. Apply the merge steps in proposals_w1_01.NOTES (Business Line rename, shared list re-cuts at W5, CONCEPT_OWNERSHIP rows, JURISDICTION entries).
4. Map Form N-1A attributes to item and instruction numbers, and openfunds-aligned attributes to field IDs.
5. Re-cut or retire the readers of removed 01 content at WP0: 18 data products, 15 data model files and 5 semantic models, listed by file and line in proposals_w1_01.NOTES. DP-064, DP-040 and DP-065 lose their purpose; SEDOL readers are re-pointed to the 17 Instrument Identifier.
