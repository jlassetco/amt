# Source Notes: 02 Client & Household (Draft v0.1, 2026-10-14)

Workbook: `Client_and_Household_Data_Taxonomy.xlsx`. Content module: `_tools/content/content_02_client_and_household.py` (written beside the wholesale `content_02_client_and_customer.py`, which the program lead removes at integration). Enrichment: `_tools/enrichment/enrich_02.py` (rewritten in place). Proposals: `_tools/consolidation/proposals_w1_02.py`.
Size (after the review fix pass): 10 families, 39 objects (26 business objects, 13 attribute groups), 290 attributes, 93 CDEs (32%), 68 code lists (57 local, 11 copies of shared lists), 59 relationships, 35 sources. Ownership: 18 references, 2 derived copies, 0 unresolved.

**Perspective.** Wealth manager (direct) | Scope: US. A hypothetical US wealth manager of the Vanguard type serving investors directly through self-directed brokerage, digital and human advice, its own funds and ETFs, workplace recordkeeping, institutional advisory, a thin intermediary channel and optional trust services (business lines DB, DA, HA, PF, WR, IA, IC, TR; CW-004). Onboarding and identity verification run in house for the broker-dealer, the adviser, the transfer agent and the optional trust company; one client master serves all of them.

## 0. Why this domain exists

A direct wealth manager knows its clients as people and families, not as names behind a distributor. Onboarding, client service and the advice teams produce the client master: who the client is, who acts for them, who they live and plan with, what they have told the firm about their finances, how their identity was verified and what they have agreed to about their data. Regulation reaches every one of these facts: FINRA Rule 4512 and SEC Rule 17a-3(a)(17) for the customer record and trusted contact, Regulation Best Interest and the Advisers Act fiduciary duty for the investor profile, the Bank Secrecy Act identification and beneficial ownership rules for identity, Regulation S-P for privacy. The wholesale 02 mastered a distributor hierarchy and held end investors as pseudonymized look-through records, so it could hold none of this. The party master itself stays (CD-143): every external party is still a 02 `PTY-`, but the client and household are now the primary role family, and every other role keeps only its core here.

## 1. Sources consulted

| Source | URL | What it gave us |
|---|---|---|
| FINRA Rule 4512 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/4512 | Customer record content (employer, occupation, associated person), trusted contact person age 18 or older, reasonable efforts, written disclosure; institutional account 4512(c). Trusted Contact Designation, Individual, Regulatory Classification. |
| FINRA Rule 2165 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2165 | Specified adult definition (65 or older; 18 or older with an impairment), temporary holds, trusted contact. Specified Adult Status, Vulnerability Concern. |
| FINRA Rules 2090 and 2111 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2111 | Essential facts; investment profile elements (age, other investments, financial situation, tax status, objectives, experience, horizon, liquidity, risk tolerance). Investor Profile. |
| FINRA Rule 3210 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/3210 | Accounts of associated persons at other firms. Associated Person Disclosure Indicator. |
| FINRA Rule 2360 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2360 | Options account approval: experience and knowledge by product. Investment Experience. |
| FINRA Rules 2210, 3230, 3310 | https://www.finra.org/rules-guidance/rulebooks/finra-rules | Institutional investor, firm-specific do-not-call, AML program. |
| SEC Rule 17a-3(a)(17) | https://www.ecfr.gov/current/title-17/section-240.17a-3 | Account record content (annual income, net worth excluding primary residence, objectives) and the periodic furnishing cycle. |
| Regulation Best Interest, Rule 15l-1; Form CRS | https://www.ecfr.gov/current/title-17/section-240.15l-1 | Retail customer definition and investment profile. |
| ICA Rule 3a-4 | https://www.ecfr.gov/current/title-17/section-270.3a-4 | Annual client contact; reasonable restrictions. Profile Trigger, Client Restriction. |
| 31 CFR 1023.220, 1024.220, 1020.220 | https://www.ecfr.gov/current/title-31/section-1023.220 | CIP minimum data, documentary and non-documentary methods, discrepancy resolution, government list check, reliance, retention. Identity Verification. |
| 31 CFR 1010.230 (CDD), 1010.610 and 1010.620 | https://www.ecfr.gov/current/title-31/section-1010.230 | Ownership and control prongs, legal entity customer exclusions, certification; due diligence for correspondent and private banking accounts. |
| OFAC sanctions lists | https://ofac.treasury.gov | Sanctions screening. |
| FATF Recommendations | https://www.fatf-gafi.org | PEP categories alongside the US senior foreign political figure. |
| Regulation S-P and S-AM (17 CFR Part 248) | https://www.ecfr.gov/current/title-17/part-248 | Privacy notices, nonaffiliated sharing opt-out, affiliate marketing opt-out and its five-year term. |
| CCPA / CPRA | https://oag.ca.gov/privacy/ccpa | Consumer request types, response time, opt-out signals, GLBA exemption. |
| E-SIGN Act, 15 U.S.C. 7001 | https://www.law.cornell.edu/uscode/text/15/7001 | Consent to electronic delivery. Consent Record. |
| TCPA (47 U.S.C. 227) and CAN-SPAM | https://www.law.cornell.edu/uscode/text/47/227 | Written consent for marketing texts; email opt-out timing. |
| Senior Safe Act (S. 2155, section 303) | https://www.congress.gov/bill/115th-congress/senate-bill/2155 | Agency referral of suspected exploitation. |
| Reg D Rule 501(a), Advisers Act Rule 205-3, ICA 2(a)(51), Rule 144A | https://www.ecfr.gov/current/title-17/section-230.501 | Investor qualification standards and bases; Rule 506(c) verification. |
| IRS Forms W-9, W-8BEN, W-8BEN-E; FATCA | https://www.irs.gov/forms-pubs/about-form-w-9 | Tax classification, US person, TIN types, chapter 4 status. |
| SEC Rule 17Ad-17 | https://www.ecfr.gov/current/title-17/section-240.17Ad-17 | Returned mail and lost securityholder search. |
| USPS Publication 28 | https://pe.usps.com/text/pub28/welcome.htm | Address standards. |
| GLEIF LEI-CDF and Level 2; ISO 17442; ISO 20275; ISO 20022 | https://www.gleif.org/en/lei-data | LEI record, parent relationships, legal forms, party identification. |
| FIBO BE/FBC; BIAN Party Reference Data Directory | https://spec.edmcouncil.org/fibo/ | Party and party role concepts. |
| Salesforce Financial Services Cloud | https://developer.salesforce.com/docs/platform/data-models/guide/fsc-customer.html | Household and member roles, contact points (cross-check only). |
| FDX API | https://financialdataexchange.org | Consumer-permissioned data sharing consent. |
| FINRA CRD, SEC IAPD/EDGAR, NIPR; DTCC participant directories; DOL Form 5500 | https://www.finra.org/registration-exams-ce | Regulatory and market identifiers; thin retirement plan identity. |
| Uniform Power of Attorney Act | https://www.uniformlaws.org | Authority types and termination. |
| SEC IM Guidance Update 2017-02 | https://www.sec.gov/investment/im-guidance-2017-02.pdf | Questionnaire design for digital advice. |

## 2. Design and boundary decisions

- **Outline followed:** the brief's 10 families and 39 objects (27 BO, 12 AG), with the brief's names and the kept names of CW-021 unchanged.
- **Client facts on the party, account facts on the account (CW-024).** No account number, registration type, Client Holding (49) or balance is mastered here. Investor Profile (`INPR-`) is versioned per client; 15 references the version. The profile carries no goal, recommendation or best-interest flag (45).
- **One identity verification per party per CIP program (CW-025)**, with a self-reference "Shared Evidence Verification" for evidence reuse; ROW_OWNERSHIP states the interim rule until the 29 re-cut.
- **Households (CW-027):** Household is an attribute group of a Household party; membership status uses Record Status (Proposed = system-suggested, unconfirmed).
- **Special category (CD-344):** only Specified Adult Status and Vulnerability Concern hold it; every attribute of both objects, including the employee who determined the status, the trusted contact used, the escalation case number and the work status, is flagged "PII - special category (CD-344). Restricted view." Account holds (15 ARX-) and disbursement holds (50 MMH-) reference the concern by its VCON- key; 02 does not reference back (the link is held once).
- **PII notes:** every attribute of an object whose tier is not "No PII" carries a PII note; screening result, AML risk rating and restricted client status are "PII - restricted".
- **Authority, relationship and account role:** Authority Grant is the only master of authority to act; Party Relationship holds the family or legal tie (relationship values that restated a grant were dropped); 15 Account Party Role holds the registration capacity.
- **Identifiers:** Party Identifier is the master register; the identifier attribute groups are typed views of its current rows. Sponsor EIN on Retirement Plan is the sponsor's EIN carried in the plan key (row rule in enrich_02.py; a same-domain copy cannot be declared DERIVED).
- **PII tier** is stated in the Notes of the first attribute of every object.

**Deviations from the brief**

| Brief | Draft | Why |
|---|---|---|
| Organization: "beneficial-ownership exclusion basis"; Beneficial Ownership Certification: "exclusion basis" | Held once, on Organization (Legal Entity Customer Exclusion Basis) | The same fact twice; the exclusion is a standing fact of the entity. |
| Beneficial Ownership Certification: "recertification trigger" | Certifying Onboarding Case (its Case Type is the trigger) plus Recertification Due Date | Avoids a third trigger list. |
| Individual: date of death; Death Notification: date of death | Individual Date of Death (confirmed) and Death Notification Reported Date of Death | Two facts (reported vs confirmed), not one held twice. |
| Tax Profile: "masked TIN" for all parties | TIN for individuals; an organization's TIN is the EIN on US Regulatory Identifier | One value held once. Tax forms on file are 15 Account Tax Certification (referenced as Tax Status Evidence). |
| Household: "status" | Uses Party Status of the Household party | Same fact otherwise held twice. |
| Investor Profile: "tax bracket" | Federal Marginal Tax Rate (Percentage) | Avoids a code list for a rate. |
| Questionnaire risk-score model (37) | Not referenced on the profile; Segment model reference also dropped | Size; models are listed in 37. |
| Organization "entity type" | Party Type re-cut carries the entity class; wholesale Organization Type not carried | Party Type, Tax Classification and Organization Type were three overlapping lists. |
| Investor Qualification (BO) | Attribute group of Party keyed by PTY- plus the standard | Program lead ruling on the review. |
| Death Notification, Vulnerability Concern keyed by grain | Death Notification ID (DTHN-) and Vulnerability Concern ID (VCON-), prefixes proposed as Reserved | 15 and 50 reference them; composite text keys could collide. |
| Household client assets (Derived, 06) | Dropped from Household; Service Tier Assignment Qualifying Client Assets is the one copy | The same 06 figure was held twice. |
| Specified Adult Status: determination date only | Specified Adult Determination Date and Specified Adult Status Effective To | Rule 2165 history. Restricted Client Status and Contact Preference gained Effective To. |
| Investor Category with qualification values | Communications-audience subset (Retail, Institutional, Financial Professional) | Qualifications are mastered on Investor Qualification. |
| Mixed-dimension lists | Party Status (record lifecycle only; Blocked removed), Household Formation Basis (who formed it only), Authority Scope (powers only), Authority Type (one Trading Authorization), Tax Classification (foreign values removed) | One dimension per list. |
| Party Role Type distributor hierarchy levels | Division / Home Office and Region / Complex removed; intermediary roles kept thin | Hierarchy Node moves to 05 (CW-023). Recorded in CW-902. |
| Wholesale attributes dropped from kept objects | Party Display Name, Preferred Name, Ultimate Parent restored; Trading Name, Formation Date, Organization Type, Regulated Entity Indicator, Deceased Indicator, Role Source, Last Verified Date, LEI Entity Category, Ownership Percentage, SEC CIK and vendor ID attributes not carried | Readers and re-points are listed in proposals NOTES. |
| Local lists 38 to 48 | 57 local lists (plus 11 shared copies) | The brief's expected list omits kept wholesale lists (Party Status, Relationship Stage, Party Origin, Parent Relationship Basis, Communication Channel, Opt-In Status, restriction and consent lists). Several were folded into shared Record Status and Case Status to limit the count. |
| Proposals file `proposals_02.py` | `proposals_w1_02.py` | Named by the assignment. |
| Associated Person Disclosure Indicator (from the 15 brief) | Added to Individual | 15 brief moves it to 02 as a party fact. |

**Wholesale objects: kept, re-cut, moved, dropped**

| Wholesale object | Disposition here |
|---|---|
| Party, Organization, Individual, Legal Entity Hierarchy, Party Role, Party Identifier, LEI Record, US Regulatory Identifier, Market Infrastructure & Vendor Identifier | Kept by name (object names; some attributes dropped, see the deviations table). Legal Entity Hierarchy becomes a BO (child x parent x basis x period). Party Type re-cut; Individual gains marital and employment status, occupation, employer, associated person, date of death. |
| Household, Household Membership, Party Relationship | Kept, re-cut (Household is an AG of a Household party; membership effective dated; relationship types re-cut). |
| Contact Point Address, Contact Point Email, Contact Point Phone, Contact Point Usage | Re-cut into Contact Point (BO, `CTP-`) and Postal Address (AG). |
| Digital Profile | Dropped (social profiles of advisors; not a client fact). |
| Contact Preference, Communication Preference, Consent Record, Privacy Profile | Kept, re-cut to US law. |
| Onboarding Case, KYC Profile, Beneficial Ownership, Tax Profile, Regulatory Classification, Segment Assignment, Client Restriction, Restricted Client Status | Kept, re-sourced to US rules. |
| Data Subject Request | Renamed Consumer Privacy Request. |
| Retirement Plan | Kept thin (name, number, type, sponsor, sponsor EIN); AG of Party. |
| Distributor Firm, Form ADV Profile, Hierarchy Node, Branch / Office, Advisor Team, Gatekeeper Profile, Financial Professional, Advisor Practice, Employment Affiliation, Team Membership, External Classification, Consultant Profile, Consultant Advisory Relationship | Moved to 05 at W4 (CW-023), not referenced. |
| Institutional Client | Moved to 12 at W4. |
| Recordkeeper Profile, Plan Service Provider | Moved to 16 at W3. |
| End Investor, Retention, Record Metadata | Dropped (06 summary data; 21 retention metadata). |
| UK & EU Regulatory Identifier, Processing Legal Basis | Removed (jurisdiction, CW-902). |
| New | Authority Grant, Trusted Contact Designation, Death Notification, Investor Profile, Investment Experience, Investor Qualification, Identity Verification, Beneficial Ownership Certification, Service Tier Assignment, Specified Adult Status, Vulnerability Concern. |

**Jurisdiction (CW-902):** 58 entries in `JURISDICTION` (2 objects, 9 attributes including the NACE / UK SIC scheme reference, 6 whole lists, 33 values, 8 sources; Swiss FADP and QUALIFIED_INVESTOR filed under "Other non-US"); see `proposals_w1_02.py`. Foreign individuals and entities stay clients where US law allows; foreign countries, addresses, LEIs and tax residences stay.

## 3. Unverified items (confirm)

1. FINRA Rule 2165 hold periods after the 2022 amendments, and whether the trusted contact disclosure sits in Rule 4512 or its supplementary material.
2. eCFR paths for 31 CFR 1024.220 and 1020.220; the exact exclusion list of 31 CFR 1010.230(e) (Legal Entity Customer Exclusion Basis values). FinCEN Order No. 2026-01 (13 February 2026) relieves covered brokers, dealers and mutual funds from re-identifying beneficial owners at each new account; Recertification Due Date is risk-based accordingly.
3. Regulation S-P 2024 amendment compliance dates; the CCPA GLBA exemption section (1798.145(e)) and the 45-day response period.
4. Senior Safe Act section number; Uniform Power of Attorney Act page URL; SEC IM Guidance 2017-02 URL; Salesforce FSC documentation path.
5. Reg D, Rule 205-3 and Section 2(a)(51) thresholds (Qualification Basis list names tests, not amounts).
6. Senior foreign political figure definition (31 CFR 1010.605) used in PEP Status.

## 4. SME questions (tailoring levers; reference default in brackets)

1. Investor profile per client, per household or both? [Per client with a joint or household scope; lever: household-only firms collapse it.]
2. Which household definition governs? [Client-defined; system suggestions held as Proposed memberships.]
3. Does the Rule 3a-4 annual contact create a new profile version when nothing changed? [Yes, an attested version.]
4. One identity verification reused across programs? [One record per program, sharing evidence; lever: an outsourced TA keeps the fund CIP and the firm holds oversight data in 29.]
5. Which special-category facts may advisors record, and who sees them? [Specified Adult Status and Vulnerability Concern only, restricted to service, advice and compliance.]
6. Trusted contact per client or per account? [Per client with an account scope.]
7. Are trustees and executors clients or related parties? [Related parties unless they hold their own accounts.]
8. Which state privacy laws apply? [Multi-valued regime list; GLBA-covered data flagged.]
9. Are prospects parties? [Yes once identity is captured; anonymous leads stay in 04.]
10. Does service tier qualification include workplace plan assets? [All household client assets as published by 06.]

## 5. Overlaps with other domains (for consolidation)

| Item | Domains | Proposal |
|---|---|---|
| CIP verification | 02 Identity Verification (KYCV-), 29 CIP Verification (CIP-) | 29 re-cut to a reference at W3 (CW-025). |
| Investment objective, risk tolerance, horizon | 02 Investor Profile, 15 Account Investment Profile, 45 | Shared-list candidates; 15 and 45 reference INPR-. |
| Tax form on file | 02 Tax Profile, 15 Account Tax Certification (ATC-) | 15 holds the form; 02 references it. |
| Household | 02, 13 (MHG-), 47 | Three named concepts (CW-027). |
| Holds | 02 Vulnerability Concern, 15 Account Restriction (ARX-), 50 Money Movement Hold (MMH-) | 15 and 50 hold the holds; 02 lists the resulting ARX- only. |
| Regulator, Business Line | 09 shared lists | Re-cut at W5 (CW-039, CW-004); local copies until then. |

## 6. Suggested validation steps

1. Walk an individual, a joint couple, a minor with UTMA custodian, a revocable trust, an LLC and an estate through onboarding against the objects.
2. Test Rule 17a-3(a)(17) and Reg BI profile elements against the Investor Profile attributes with Compliance.
3. Agree with 15 the references from Account Investment Profile, Account Opening, Options Approval Detail and Alternative Investment Subscription.
4. Agree the 29 re-cut and the 13 DEL- link with their drafters.
5. Map attributes to the CRM, onboarding/CIP tool, risk questionnaire, consent platform and privacy request tool.
6. Confirm the items in section 3.
