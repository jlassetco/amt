# Source Notes: 03 Advisor Organization, Coverage & Supervision (Draft v0.1, 2026-10-14)

Workbook: `Advisor_Organization_Coverage_and_Supervision_Data_Taxonomy.xlsx`. Content module: `_tools/content/content_03_advisor_organization_coverage_and_supervision.py` (written beside the wholesale `content_03_sales.py`, which the program lead removes at integration; `content_07_compensation_and_territory.py` stays until W4, CW-080). Enrichment: `_tools/enrichment/enrich_03.py` (rewritten in place). Proposals: `_tools/consolidation/proposals_w2_03.py`.
Size (after the review fix pass): 7 families, 32 objects (22 business objects, 10 attribute groups), 249 attributes, 74 CDEs (30%), 43 code lists (36 local, 7 copies of shared lists), 54 relationships, 21 sources. Ownership: 53 references, 7 derived copies, 21 overrides, 2 row ownership rules, 0 unresolved.

**Perspective.** Wealth manager (direct) | Scope: US. A hypothetical US wealth manager of the Vanguard type serving investors directly through self-directed brokerage, digital and human advice, its own funds and ETFs, workplace recordkeeping, institutional advisory, a thin intermediary channel and optional trust services (business lines DB, DA, HA, PF, WR, IA, IC, TR; CW-004). Advisors are employees (20 `EMP-`) of the broker-dealer, the RIA or both; there is no independent-contractor force by default.

## 0. Why this domain exists

The advice organization produces and maintains the record of who serves which client: the firm's own advisors, planners and service associates, the teams and branches they work in, the principals who supervise them, the coverage model each client tier receives, the advisor or team each household is assigned to, how much capacity each advisor has, what advisors did with clients, which clients were referred from one channel to another, and the incentive plans that pay for the work. 20 holds the employee and 08 the registrations and supervisory evidence, but neither owns the book of business, the supervisory structure of FINRA Rule 3110 as the firm organizes it, or the client-to-advisor assignment that 06 attribution, 45 engagements and 47 billing read. The wholesale 03 described a wholesale sales force and 07 its territories and crediting; this replacement is centered on the household.

## 1. Sources consulted

| Source | URL | What it gave us |
|---|---|---|
| FINRA Rule 3110 Supervision (with .18 and .19) | https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110 | (a)(2) principal designation by type of business, (a)(3) registration and designation of branch offices and OSJs, (a)(4) principals in each OSJ, (a)(5) assignment of each registered person to a supervisor; (c)(1) inspection cycles (OSJs and branches supervising non-branch locations annually, other branches every three years, non-branch locations periodically); (f) OSJ and branch office definitions. Regulatory Notice 24-02 (January 2024) makes .19 (residential supervisory location) effective 1 June 2024 and the .18 remote inspections pilot effective 1 July 2024 (pilot end date confirm). |
| FINRA Form BR | https://www.finra.org/registration-exams-ce/broker-dealers/registration-forms/form-br | Branch and OSJ registration fields; the filing is 08's. |
| FINRA Rules 1210 and 1220 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/1220 | Registration requirement and categories behind roles and principal designations. |
| SEC Rule 203A-3 | https://www.ecfr.gov/current/title-17/section-275.203A-3 | Investment adviser representative definition. |
| Regulation Best Interest, Rule 15l-1(a)(2)(iii) | https://www.ecfr.gov/current/title-17/section-240.15l-1 | Identify and mitigate incentives; identify and eliminate sales contests, quotas, bonuses and non-cash compensation based on specific securities within a limited period ((iii)(D)). Incentive Plan Component, Recognition Award. |
| FINRA Rules 3220 and 2341(l)(5) | https://www.finra.org/rules-guidance/rulebooks/finra-rules/3220 | Gifts and non-cash compensation; recognition events. |
| FINRA Rule 2360(b)(16) and (b)(20) | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2360 | Options account approval and supervision of accounts by a Registered Options Principal. |
| Advisers Act Section 203(e)(6) and Rule 206(4)-7 | https://www.ecfr.gov/current/title-17/section-275.206(4)-7 | Supervision of advisory program accounts (Principal Designation Type, Supervised Function). |
| DOL PTE 2020-02 and DOL FAQ | https://www.dol.gov/sites/dolgov/files/ebsa/about-ebsa/our-activities/resource-center/faqs/new-fiduciary-advice-exemption.pdf | Rollover incentives to mitigate (Rollover Neutral Indicator); adopted 18 December 2020, effective 16 February 2021; status of the 2024 amendments confirm. |
| SEC Rule 17a-4(b)(4); Advisers Act Rule 204-2(a)(7) | https://www.ecfr.gov/current/title-17/section-240.17a-4 | Retention of business communications; activity capture. |
| Investment Company Act Rule 3a-4 | https://www.ecfr.gov/current/title-17/section-270.3a-4 | Annual client contact of advisory programs (contact standard; the review record is 45). |
| FINRA Rules 4530 and 2210 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/4530 | Complaints raised in an activity (08); communications shared (08 approval). |
| CFP Board Code of Ethics and Standards of Conduct | https://www.cfp.net/ethics/code-of-ethics-and-standards-of-conduct | Credential obligations and verification. |
| FINRA CRD and BrokerCheck | https://www.finra.org/registration-exams-ce | Individual CRD number (Derived copy from 08). |
| Regulation S-P; CCPA / CPRA | https://www.ecfr.gov/current/title-17/part-248 | Personal data in notes and referrals; Personal Data Category. |
| ISO/IEC 27001 Annex A 5.12; ISO 639; ISO 3166-2 | https://www.iso.org/standard/27001 | Activity classification, languages, registered states. |
| Salesforce Financial Services Cloud | https://developer.salesforce.com/docs/platform/data-models/guide/fsc-customer.html | Advisor, household and interaction structure (cross-check only; path confirm). |

## 2. Design and boundary decisions

- **Advisor is a profile (CD-144, CW-061).** Keyed by the 20 `EMP-`; no name, contact, job, salary or rating held. Regulated Role Category is not redefined: Advisor Role Assignment references the 20 Job Profile. Registration status, registered states and the CRD number are Derived copies of 08 (CW-072), with a copy timestamp.
- **One advisor-of-record master (CW-063).** Party Coverage Assignment (`CVA-`) with Primary Coverage Indicator is the advisor of record: one primary per scope per date, and for an account on a date the advisor of record resolves at account scope, then client, then household (stated on the attribute and as a ROW_OWNERSHIP rule); covered party is the Client Household (`PTY-HH-`) by default, with account-scope exceptions (15 `ACC-`). Coverage by a pooled team without a named advisor uses Covering Coverage Team.
- **Supervisory structure here, evidence in 08.** Firm Branch Office (profile of 09 `SITE-`, one row per designation period) classifies the office by Branch Type, a list mastered here with the Rule 3110 location classes (Office of Supervisory Jurisdiction, Branch Office, Non-Branch Location), plus Supervises Non-Branch Locations Indicator and Residential Supervisory Location Indicator (Rule 3110.19), and references 08 Branch Registration. 08 Branch Registration and Branch Inspection copy the Branch Type values; 03 Supervisory Assignment masters the heightened-supervision supervisor and 08 copies it (program-lead ruling; both recorded in proposals NOTES for the 08 fix pass). Supervising OSJ and branch manager are held once (Supervisory Hierarchy Link; Principal Designation of type Branch Manager), not on the branch. The inspection cycle is not stored: it follows from the classification under Rule 3110(c)(1); 08 Branch Inspection holds inspections. Heightened supervision is a reference to 08 `HSPL-` on Supervisory Assignment.
- **Activities are the advisor's own interactions.** Advisor Activity references 13 Service Request, 45 Advice Engagement and Advice Review, 04 Campaign; Outcome references 45 Recommendation and 08 Complaint. Meeting Notes is restricted (may hold special-category data, CD-344) and never holds a rationale or best-interest flag. Communication Archive Reference is now a typed Reference to 08 `ARC-` (it was a Derived text copy).
- **Referrals (CW-065).** Channel Referral (`RFRL-`) records source and target channel, referring employee and outcome references (45 `ADENG-`, 15 `ENRL-`, 04 `LEAD-`, 51 `TRUST-`).
- **Incentives reduced (CW-064).** Plan, component (client-outcome and firm-level measures; Product-Specific Time-Limited Indicator for Rule 15l-1(a)(2)(iii)(D); Proprietary Product Linked Indicator), participation (restricted target incentive), statement with earnings lines and a 20 Payroll Result reference, and Recognition Award. The Reg BI review is 08 Incentive Conflict Review, referenced by a composite key forced to 08 in OWNERSHIP_OVERRIDES.
- **Kept attribute names** where readers use them (Activity ID, Activity Owner, Covered Party, Primary Coverage Indicator, Coverage Effective From/To, Coverage Model Code, Required Interactions per Period, Statement ID, Total Earned, Threshold Attainment, Target Incentive Amount, Rule Precedence, Criterion Field). Renames are mapped in `REPOINTS`.
- **Advisor typing.** References to a person who must hold an Advisor profile are `Reference (Advisor)` (forced to mastered here, since the EMP- key resolves to 20 by prefix); staff who need not be advisors (Activity Owner, which includes 05 partner and consultant meetings under CW-138, Internal Participant, principals, supervised persons and supervisors, approvers, referring employees) stay `Reference (Employee)`.
- **Lists.** Coverage Model Code is firm-defined; Coverage Model.Delivery Mode uses the 01 Delivery Mode list (External). Activity Type is the form of the activity plus the 05 meeting kinds (Partner Meeting, Consultant Meeting, Plan Sponsor Review, Finals Presentation); the medium is Interaction Medium only. Role labels are aligned (Financial Planner, Associate Advisor, Service Associate, Specialist).
- **Special category.** Discussion Content.Special Category Content Indicator drives the restricted view of Meeting Notes until the shared Personal Data Category list gets a Special Category value (proposed in SHARED_CANDIDATES).
- **Pay data.** Incentive Plan Participation, Compensation Statement, Incentive Earnings Line and Recognition Award take the compensation tier (Confidential - Compensation, CD-344).
- **Ownership resolution.** `CVA-` and `ICP-` are still registered to 07 until the merge; enrich_03.py forces the five internal references that carry them to "mastered here".
- **PII.** Every object states its tier in the Notes of its first attribute; employee personal data is marked "PII (employee)"; compensation amounts are "restricted - compensation". Examples use fictitious CRD numbers ("0000003 (fictitious)") and example.net addresses.

**Deviations from the brief**

| Brief | Draft | Why |
|---|---|---|
| Module `content_03_advisor_organization.py`; proposals `proposals_03.py` | `content_03_advisor_organization_coverage_and_supervision.py`; `proposals_w2_03.py` | Named by the assignment. |
| 30 objects (20 BO, 10 AG) | 32 objects (22 BO, 10 AG) | The brief's own table lists 32; all are drafted. |
| FINRA Rule 3110(a)(2), (a)(4), (a)(5) | (a)(3) cited for branch and OSJ designation, (a)(2) and (a)(4) for principals, (a)(5) for assignment | Rule text: (a)(2) is principal designation by business type, (a)(3) registration and designation of branches and OSJs. |
| Firm Branch Office: branch manager, supervising OSJ | Held in Principal Designation and Supervisory Hierarchy Link only | Same fact twice otherwise. |
| Branch Type (OSJ, branch, non-branch location, residential supervisory location) | Branch Type = Office of Supervisory Jurisdiction, Branch Office, Non-Branch Location; Residential Supervisory Location Indicator | Program-lead ruling on the review: one list mastered in 03, mutually exclusive classes; an RSL is a non-branch location. |
| Coverage Model list and Delivery Mode list | Coverage Model Code firm-defined; Delivery Mode on the 01 list | One vocabulary per dimension (review B). |
| Advisor Role with Branch Manager and Supervising Principal | Dropped from Advisor Role | Principal Designation holds them. |
| References outside brief section 7 | Content Asset (04), Advice Review (45), Complaint (08), Recipient Delivery Record (13) | Needed for content shared, the Rule 3a-4 contact, complaints raised and the reassignment notice; the brief table should list them. |
| Coverage Assignment Rule without household or advisor | Excepted Party and Target Advisor added | Named exceptions keep their household and advisor (07 Alignment Exception.Excepted Party re-points here). |
| Incentive Plan Component: product-specific indicator | Plus Rollover Neutral Indicator; cap split into Cap Amount and Cap Percentage | PTE 2020-02 and Reg BI (iii)(B)-(C); one type per attribute. |
| Advisor: "channel" | Advice Channels Offered (Interaction Medium) | Avoids a third channel list; 45 Advice Delivery Channel is a shared-list candidate. |
| Coverage Model: tiers; "target households per advisor" | Plus Maximum Households per Advisor and Delivery Mode | Capacity limit needs a maximum. |
| Call Frequency Standard: "annual review required" | Annual Contact Required Indicator (Rule 3a-4 contact) | The review itself is a 45 Advice Review; 08/45 term "Review" kept qualified. |
| Coverage Assignment Rule: criteria "registered state" | Registered-State Check Indicator on the rule | A check against the 08 copy, not a criterion value (SME question 4 lever). |
| Coverage Reassignment: "from and to" | From Advisor, To Advisor, To Coverage Team; client notice planned on the event and sent per item | Staggered notices per household. |
| Capacity: counts Derived from 02 and 15 | Household count mastered here (counted from CVA-); client count (02), account count (15) and Book Client Assets (06, future owner W4) Derived | The household count is this domain's own data. |
| Local lists: Capture Method; Referral Source Channel | Activity Capture Method (the existing LOCAL_RENAMES name); Referral Channel for source and target | One list for both ends of a referral. |
| Internal and external participant role lists | One Activity Participant Role list | Fewer lists; 36 local lists after the fix pass (inside 28 to 36). |
| List names Referral Status, Assignment Basis | Channel Referral Status, Coverage Assignment Basis | Names already used by 04 and 33 for other concepts. |
| 45 prefixes `ADE-`, `RCO-` | `ADENG-`, `AVREV-`, `RECOM-` | The 45 brief reserves these. |
| Recognition Award "08 review reference" | Reference (Incentive Conflict Review, 08) with key RECG- / review date | The 08 brief keys that review by component; noted for 08 in proposals NOTES. |

**Wholesale objects: kept, re-cut, moved, dropped**

| Wholesale object | Disposition here |
|---|---|
| 03 Internal Participant, External Participant, Discussion Content, Outcome & Follow-Up, Activity Capture, License & Registration Reference | Kept by name (Participant Firm and External Attendee Count dropped; Activity Source System kept with a firm-defined value set instead of the wholesale list; topics re-cut to retail). |
| 07 Coverage Model, Call Frequency Standard, Party Coverage Assignment, Incentive Compensation Plan, Compensation Statement | Kept by name, transferred from 07 (`CVA-`, `ICP-`, `CPS-`); 07 keeps them until W4 and the registers point them to 03 (CW-080). |
| 03 Sales Person; Sales Role | Re-cut as Advisor; Advisor Role Assignment (CRM User ID and Home Market dropped). |
| 03 Sales Team, Team Membership & Channel Assignment, Sales Pairing & Alignment; 07 Coverage Team | Re-cut as Coverage Team (`SLT-`) and Coverage Team Membership; 07 `CTM-` retires. |
| 03 Sales Activity | Renamed Advisor Activity (`ACT-`); territory, opportunity, sales play, event and channel references dropped; household, accounts, engagement, review and service request added. |
| 07 Alignment Rule, Alignment Rule Criterion, Alignment Exception; Realignment Event | Re-cut as Coverage Assignment Rule (`ASRL-`) with its Criterion (exceptions are rules of type Named Exception); Coverage Reassignment (`REAS-`) with Coverage Reassignment Item. |
| 07 Plan Component, Rate Table Tier, SPIF & MBO, Product Compensation Tier Mapping; Plan Participant Assignment; Earnings Result | Re-cut as Incentive Plan Component, Incentive Plan Participation, Incentive Earnings Line (rate tables and product tiers dropped). |
| 07 Coverage Tier Assignment | Moved to 02 Service Tier Assignment (CW-028). |
| 03 opportunities, RFPs, answer library, consultant databases, ratings, reviews and notifications, account plans | Moved to 05 at W4 (`OPP-`, `RFP-`, `ANS-`, `DBS-`, `KAP-` held; CW-062); not referenced. |
| 03 Content Usage Event, Sales Play, Forecast Submission, Pipeline Snapshot | Dropped (`PLY-`, `FCS-` retire). |
| 07 territories, goals, crediting, periods, draws, disputes, payroll instructions, accruals, governance, controls; 03 and 07 Record Metadata | Dropped (CW-013, CW-064, CD-160). |
| 07 Remuneration Conflict Assessment, Sales Cluster | Removed (jurisdiction, CW-903). |
| New | Advisor Credential, Firm Branch Office, Supervisory Hierarchy Link, Principal Designation, Supervisory Assignment, Coverage Reassignment Item, Advisor Capacity Snapshot, Channel Referral, Referral Status History, Recognition Award. |

**Jurisdiction (CW-903):** 51 entries in `JURISDICTION` (27 for the wholesale 03, 24 for the 07 content the brief names or 03 absorbs; 2 objects, 12 attributes or attribute wordings, 26 code-list values and list attributions, 11 sources; Canada and Switzerland filed as "Other non-US"). Foreign-language service stays (Languages Spoken); clients resident abroad stay where US law allows.

## 3. Unverified items (confirm)

1. End date of the FINRA Rule 3110.18 remote inspections pilot (30 June 2027 per secondary sources). The effective dates are closed: Regulatory Notice 24-02, .19 from 1 June 2024 and .18 from 1 July 2024.
2. Salesforce FSC documentation path (returns 403); the status of the 2024 amendments to PTE 2020-02.
3. The current FINRA Rule 3220 gift limit (amendments have been proposed); this module states no amount.
4. Rule 15l-1(a)(2)(iii) paragraph lettering as cited ((B) to (D) in the 08 brief, (D) for sales contests).
5. Credential Type values accepted by the firm for client-facing display (CPA/PFS, CIMA, RICP).
6. Regulation S-P 2024 amendment compliance dates.

## 4. SME questions (tailoring levers; reference default in brackets)

1. Employees only, or independent contractors too? [Employees of the broker-dealer, RIA or both; lever: an independent channel adds an advisor firm profile and moves it toward 05.]
2. Named advisor or pooled team per tier? [Digital and self-directed pooled; human advice named or ensemble; lever: the Coverage Model list.]
3. Coverage at household or client grain? [Household (`PTY-HH-`) with account-scope exceptions; lever: client grain.]
4. Does the client's state of residence block assignment to an advisor not registered there? [Yes, Registered-State Check Indicator on the rule; lever: off.]
5. Which incentive measures are allowed? [Client outcomes and firm-level results only, none tied to specific securities or own funds; lever: the Incentive Measure list, subject to the 08 review.]
6. Are referral incentives paid? [Yes, as a Qualified Referrals component reviewed in 08; lever: recognition only.]
7. Trust officers in 03 or 51? [03 holds the person and coverage; 51 the trust role of the trust company.]
8. Branch network? [Small network of branches and OSJs plus residential supervisory locations; lever: remote-only firm keeps the home office OSJ only.]
9. May 45 keep an engagement advisor beside the 03 advisor of record? [Yes, qualified as Engagement Advisor; the advisor of record is read from 03.]

## 5. Overlaps with other domains (for consolidation)

| Item | Domains | Proposal |
|---|---|---|
| Advisor of record | 03 CVA-, 45 Advice Engagement | 45 renames and reads 03 (TERM_CONFLICTS). |
| Registration status | 08 Individual Registration, 03 copy, 20 role requirement | Derived copies only (CW-072). |
| Branch | 03 Firm Branch Office, 08 Branch Registration and Inspection, 09 Office Location | Structure 03, filings and inspections 08, office 09. |
| Interaction medium / delivery channel | 03, 13, 45 | Shared-list candidate. |
| Referral | 03 Channel Referral, 04 Client Referral | Distinct concepts (CW-065). |
| Service coverage | 03 CVA-, 12 SVA- | 12 adaptation decides at W4. |

## 6. Suggested validation steps

1. Walk a digital client upgraded to human advice through referral, assignment rule, coverage assignment, first activity and the 45 engagement.
2. Walk an advisor departure: reassignment, client notices, capacity snapshots before and after, statement for the final period.
3. Test the supervisory chain for one registered person (assignment, supervising office, OSJ principal, branch type) with Compliance against FINRA Rule 3110.
4. Review each incentive measure and the Product-Specific Time-Limited Indicator with Compliance (Reg BI) and Sales Compensation.
5. Agree the re-point map (`REPOINTS`, `OBJECT_MAP`) for DP-009, DP-010, DP-198, DP-243, DP-006 and DP-007 and models_f2.py.
6. Confirm the items in section 3.

## 7. Review fix pass (2026-10-15)

Applied `00_Program/Rework/Reviews/03_review.md` under the program-lead rulings: REPOINTS completed (13 unmapped wholesale attributes mapped or set to None with reasons in REPOINT_REASONS; primary-key changes for models_f2.py and DP-009 in PK_CHANGES); Branch Type list and heightened-supervision supervisor mastered here, with the 08 side recorded for the 08 fix pass; advisor-of-record precedence; READERS completed (37 products with live / pending WP0 status, eleven model files, five key files, four semantic models, framework.py, eight content relationship texts; DP-198 placed in specs_e4_people_workplace_ai.py); Reference (Advisor) typing; list fixes; named exceptions; Rollover Neutral Indicator; Recipient Delivery Record; compensation tier; special-category indicator and proposed shared value; Remuneration Conflict Assessment jurisdiction note and CW-903 criterion; Form BR URL; Rule 3110 dates; Advisers Act and Rule 2360 citations; CDEs on compensation and supervision keys; "Other" values; role label alignment; From Coverage Team; Advisor Status "Leave" removed (read from 20); status history stated as record history; Contact Type primary reference Internal; Supervised Function "Trust Services" removed (12 CFR Part 9 in 51); Referral Channel "Financial Planning" and Incentive Measure "Compliance and Conduct" removed; relationship cardinality "n : 2" split; relationships without an attribute reworded; TERM_CONFLICTS "Advisor of record" resolved.

To stay inside the 250-attribute target, Activity Subject, Assignment Rule Name and Client Requested Alternative Indicator were dropped (Activity Subject mapped to None in REPOINTS).

Skipped Lows, with reasons:
- CDE on Credential Type and Accepting New Clients Indicator: kept. They drive routing and client-facing display; owners are to confirm (see the SME questions).
- Salesforce FSC URL: kept with "confirm path"; it returns 403 and could not be checked.
- Brief naming deviations (module name, proposals file name, 32 objects): left for the lead to update the brief or the CW-062 text at the merge.
