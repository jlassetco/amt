# Source Notes: 04 Marketing, Digital & Client Engagement (Draft v0.1, 2026-10-14; review fix pass 2026-10-15)

Workbook: `Marketing_and_Digital_Data_Taxonomy.xlsx` (folder and output path kept, `domains._FOLDERS`). Content module: `_tools/content/content_04_marketing_and_digital.py` (adapted in place; the wholesale version stays at tag `wholesale-v1.0`). Enrichment: `_tools/enrichment/enrich_04.py` (rewritten in place). Proposals: `_tools/consolidation/proposals_w2_04.py`.
Size (after the review fix pass): 12 families, 61 objects (43 business objects, 18 attribute groups), 318 attributes, 106 CDEs (33.3%), 83 code lists (75 local, 8 copies of shared lists), 59 relationships, 28 sources. Ownership: 49 references, 6 derived copies, 0 unresolved. Band 290 to 320 (program-lead ruling). Wholesale before: 11 families, 56 objects (Record Metadata excluded), 253 attributes, 78 CDEs, 66 code lists, 34 relationships, 25 sources.

**Perspective.** Wealth manager (direct) | Scope: US. A hypothetical US wealth manager of the Vanguard type that acquires and serves investors directly through self-directed brokerage, digital and human advice, its own funds and ETFs, workplace recordkeeping, institutional advisory, a thin intermediary channel and optional trust services (business lines DB, DA, HA, PF, WR, IA, IC, TR; CW-004). Its website and mobile app are owned and operated in house. Disposition: Adapt (CW-001); the US-only pass is CW-904.

## 0. Why this domain exists

Marketing, digital product and client experience teams acquire and engage clients directly. They run campaigns and content, operate the website and app, measure what visitors and clients do there, test and personalize journeys, and turn visitors into prospects, applicants and funded accounts. A direct wealth manager markets to consumers under FINRA Rule 2210 and the Advisers Act marketing rule, with the CAN-SPAM Act, the TCPA, FINRA Rule 3230 and US state privacy law shaping outreach and tracking. No other domain holds the pre-account funnel, digital behavior, experiments or marketing attribution: 02 holds who the person is and what they consented to, 15 the account once an application is submitted, 13 assisted service, 45 advice. 04 keeps its wholesale core (campaigns, content, events, digital properties, engagement, audiences, leads, social and paid media, attribution) and is re-pointed at the direct client.

## 1. Sources consulted

| Source | URL | What we took from it |
|---|---|---|
| Salesforce object reference: Campaign, CampaignMember, Lead | https://developer.salesforce.com/docs/atlas.en-us.object_reference.meta/object_reference/sforce_api_objects_campaign.htm | Campaign hierarchy (`ParentId`), `Type`, `Status`, `BudgetedCost`, `ActualCost`; CampaignMember `Status` and `HasResponded`; lead source, status and conversion. Cross-check only. |
| Account Engagement (Pardot) API: Lifecycle Stage | https://developer.salesforce.com/docs/marketing/pardot/guide/lifecycle-stage-v5.html | Lifecycle stages; separate behavioral score and fit grade. The stages are re-cut to Visitor, Prospect, MQL, Applicant, Client. |
| Adobe XDM and Experience League | https://github.com/adobe/xdm ; https://experienceleague.adobe.com/en/docs/experience-platform/xdm/classes/experienceevent | ExperienceEvent (`_id`, timestamp, `eventType`), identity namespaces, `web.webPageDetails`, Direct Marketing email events. |
| GA4 enhanced measurement and UTM | https://support.google.com/analytics/answer/9216061 ; https://support.google.com/analytics/answer/10917952 | Event names and parameters; UTM parameters including `utm_id`. The app events `app_open`, `feature_use`, `journey_step` and `nudge_view` are firm-defined custom events in the same convention. |
| DCMI Metadata Terms; IPTC Photo Metadata; Adobe XMP; schema.org Event; WCAG 2.2 | https://www.dublincore.org/specifications/dublin-core/dcmi-terms/ ; https://iptc.org/standards/photo-metadata/iptc-standard/ ; https://developer.adobe.com/xmp/docs/ ; https://schema.org/Event ; https://www.w3.org/TR/WCAG22/ | Asset identity, rights, accessibility and event metadata; kept from the wholesale. |
| FINRA Rule 2210 Communications with the Public | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2210 | Retail communication, correspondence and institutional communication; principal approval and filing (08); firm name in retail communications (2210(d)(3)); testimonials (2210(d)(6)); static and interactive social content. Replaces FCA COBS 4 and the ESMA guidelines as the secondary reference of Publishing Entity, Permitted Investor Categories, Permitted and Target Jurisdictions, Performance Content Indicator and Post Compliance Review. |
| SEC marketing rule, Advisers Act Rule 206(4)-1 | https://www.sec.gov/rules-regulations/2020/12/investment-adviser-marketing | Testimonials (current clients) and endorsements (non-clients), compensated promoters and their disclosures under Rule 206(4)-1(b)(1), with (b)(2) oversight and (b)(3) disqualification (confirm paragraphs; Client Referral), performance and hypothetical performance flags. |
| CAN-SPAM compliance guide; 16 CFR Part 316 | https://www.ftc.gov/business-guidance/resources/can-spam-act-compliance-guide-business | Commercial versus transactional email; opt-out honored within 10 business days (Unsubscribe Written Back Timestamp). |
| TCPA, 47 U.S.C. 227; 47 CFR 64.1200 | https://www.law.cornell.edu/uscode/text/47/227 | Prior express written consent for marketing calls and texts (consent records are 02); company-specific do-not-call lists; revocation by any reasonable means (Suppression Reason TCPA Consent Revoked, written to the 02 Consent Record through Revoked Consent Record). The revocation rules took effect April 11, 2025; the revoke-all provision of 64.1200(a)(10) is delayed to January 31, 2027 (confirm). The FCC's one-to-one consent rule was vacated by the Eleventh Circuit on January 24, 2025. |
| FTC Telemarketing Sales Rule (16 CFR Part 310) and National Do Not Call Registry | https://www.ftc.gov/legal-library/browse/rules/telemarketing-sales-rule | Registry scrubs (Registry Scrub Date). |
| FINRA Rule 3230 Telemarketing | https://www.finra.org/rules-guidance/rulebooks/finra-rules/3230 | Firm-specific do-not-call list and the National Do Not Call Registry for broker-dealers. |
| Regulation S-P (17 CFR Part 248) | https://www.ecfr.gov/current/title-17/chapter-II/part-248 | Opt-outs and notices are 02 and 13; cited for the privacy inventory of martech systems. |
| CCPA / CPRA and the CCPA regulations | https://cppa.ca.gov/regulations/ | Sale and sharing of personal information for cross-context behavioral advertising, notice at collection, opt-out preference signals (11 CCR § 7025, confirm); the GLBA data exemption. Basis of Tracking Consent Choice and the re-sourced Applied Tracking Consent and Privacy Notice Version. |
| Global Privacy Control | https://globalprivacycontrol.org | The browser opt-out signal (Tracking Choice Source). |
| SEC request for comment on digital engagement practices, Release Nos. 34-92766 and IA-5833 (August 27, 2021) | https://www.sec.gov/news/press-release/2021-167 | Behavioral prompts, gamification and personalization, and when they may be recommendations: Nudge Type and Recommendation Risk Class. |
| Regulation Best Interest, Exchange Act Rule 15l-1 | https://www.ecfr.gov/current/title-17/section-240.15l-1 | Recommendation to a retail customer; a nudge classed Potential Recommendation routes to 08 and 45 (CW-091). |
| NIST SP 800-63B-4 (Revision 4, 2025) | https://pages.nist.gov/800-63-4/sp800-63b.html | Authenticator types and restricted authenticators (SMS; confirm in Revision 4): MFA Factor Type and Login Method. |
| Net Promoter System (Bain & Company) | https://www.netpromotersystem.com | 0-10 question, promoter, passive and detractor bands; relationship and transactional NPS. |
| IRS Instructions for Forms 1099-MISC and 1099-NEC | https://www.irs.gov/instructions/i1099mec | Prizes and awards as other income: Form 1099-MISC Reportable Indicator. |
| FINRA Rule 4530 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/4530 | Written customer complaint; survey responses and social mentions that may be complaints are referred to 08. |
| IAB Tech Lab Taxonomies | https://github.com/InteractiveAdvertisingBureau/Taxonomies | Cross-check of paid media channel, ad format and content topic lists. |

Removed with the US-only pass (JURISDICTION, CW-904): FCA Handbook COBS 4 and FG24/1, ESMA guidelines on marketing communications (ESMA34-45-1272), GDPR / UK GDPR, ePrivacy Directive / UK PECR and CASL. Removed with the intermediary residue (CW-013): CFP Board CE policies, the Investments & Wealth Institute CE sponsor program and Bombora Company Surge; DCAM left with Record Metadata (CD-160).

## 2. Design and boundary decisions

- **Consent and opt-in state are 02 (CW-029, CW-084).** 04 masters the Subscription Topic catalog (`SUB-`, read by 02 Communication Preference), the Suppression Entry list (hard bounces, spam complaints, National Do Not Call Registry, firm-specific do-not-call, TCPA revocations, reassigned numbers, competitor and employee exclusions), unsubscribe events and the tracking choices of unmatched visitors. An unsubscribe captured in an Email Interaction is written to 02 within 10 business days, evidenced by Unsubscribe Written Back Timestamp. 04 holds no Opt-In Status, Opt-In Method or Opt-Out Source lists. A TCPA revocation captured by 04 (for example a STOP reply) is written to the 02 Consent Record (Revoked Consent Record); Do Not Contact and Deceased suppression rows are copies of 02 (ROW_OWNERSHIP rule on Suppression Reason).
- **Prospects (CW-083).** A visitor or lead below the identity threshold stays in 04 (`VIS-`, `LEAD-`); captured values are PII lineage, never maintained as party data. At the threshold (name plus a verified email or phone, or any application start) 02 creates or matches a party with Relationship Stage Prospect and 04 references `PTY-` (Lead Conversion.Converted Party, Web Visitor.Matched Party).
- **The funnel ends at account opening (CW-085).** Application Journey (`JRNY-`) runs from start to submission and names the resulting 02 Onboarding Case and 15 Account; from submission 15 Account Opening is the master. Questionnaire answers are 02 Investor Profile; the digital advice engagement is 45. Acquisition Milestone records prospect created, application started and submitted, account opened and funded, advice enrolled, rollover completed and recurring investment set up; the milestone is a journey read of facts other domains record: 04 masters only the two application milestones; Prospect Created is a copy of 02, Account Opened and Advice Enrolled of 15, and Account Funded, Rollover Completed and Recurring Investment Set Up of 50 (ROW_OWNERSHIP rule). Attributed Outcome credits milestones to campaigns under an Attribution Model; 06 applies the weights to its flows, and Attributed Amount is a Derived copy of 06.
- **Digital identity versus assisted authentication (CW-086).** The wholesale Portal Account is re-cut and renamed Digital Profile (`DIGP-`): status, MFA factors enrolled, device biometric flag and last login, and never a login name, password, one-time code or biometric template. Sessions carry the Login Method. 13 authenticates people who contact a representative; 02 verifies identity under CIP; 41 runs IAM.
- **Tracking choices.** Tracking Consent Choice records the cookie banner, preference center, Global Privacy Control and mobile OS choices of a visitor. Web Visitor.Applied Tracking Consent is kept (DP-011 reads it) and re-sourced from UK PECR to the CCPA / CPRA. The cookie categories are mastered in 04 per visitor (device), matched or not; only the sale or sharing opt-out of a matched visitor is a copy of 02 Privacy Profile, which holds no cookie categories. Sessions now reference their Session Visitor, and engagement events their Event Session.
- **Nudges and experiments (CW-091).** Every Nudge Definition carries an 08 review of its content asset and trigger, and a Recommendation Risk Class that is a Derived copy of the 08 determination: Pending Determination (not deliverable), Determined Not a Recommendation, Determined Recommendation or Advice Program Communication. Every Nudge Delivery of a Determined Recommendation nudge must carry a Linked Recommendation to the 45 Recommendation (DQ rule); 45 is asked to add a 'Digital Nudge' Recommendation Source value. Each delivery records the suppression check applied and the Marketing Channel used. Experiments name a 21 Metric Definition as primary metric; results are computed in products, not stored.
- **Promotions and referrals (CW-092).** Promotion Offer holds eligibility, the offer period (Offer Start and End Dates), the Award Value and its Promotion Campaign; Promotion Enrollment holds the qualification and award status. Cash awards are 50 Money Movements (`MMVMT-`), which reference the enrollment (50 holds the link; 04 does not); fee awards are 47 Fee Waivers (04 holds the link); reportable awards are 13 Form 1099-MISC records (04 holds the flag). A Client Referral (`CRFL-`) is a client recommending the firm; its reward is held once, as Referral Reward Enrollment to the referrer's enrollment in an offer of award type Referral Reward, and it makes the testimonial compensated under the marketing rule (disclosure flag). The 03 Channel Referral (`RFRL-`) is a different concept; the 04 list is named Referral Program Status to stay apart from the 03 Referral Status.
- **Voice of client (CW-093).** Client Survey (`CSVY-`) and Survey Response (`SRSP-`) hold the score, NPS category and verbatim, the triggering 13 interaction and the 08 complaint referral. Verbatims and registration accessibility needs are "PII - may contain special category (CD-344)".
- **Audiences versus segments (CW-094).** Marketing Segment is an activation audience; its rule may use a 02 Segment Assignment but never re-assigns it.
- **Compliance owns approval.** Assets, messages, nudges, promotions and social posts carry the 08 `REV-` reference (for nudges, offers and messages: the review of the content asset that carries them); approval status, the FINRA category and the nudge recommendation determination are Derived copies of 08. The three Marketing Rule flags are renamed '... Declared Indicator': the submitter's declaration when routing to 08, whose classification governs.
- **Audience gate.** The FCA Access Gate and Self-Certification Record are removed, but their US use is kept as Web Page.Audience Gate (Audience Gate Type: None, Client Login, Financial Professional Self-Certification, Institutional Investor Self-Certification, Verified Financial Professional Login), the evidence that financial-professional-only and institutional communications under FINRA Rule 2210 reached only those audiences.
- **Advisors.** Invited By Advisor and Assigned Advisor reference the 03 advisor (keyed by the 20 `EMP-`, forced to 03 in OWNERSHIP_OVERRIDES); First Sales Activity keeps its name and reads the 03 Advisor Activity (`ACT-`).
- **Intermediary channel is thin (CW-013).** Financial Professional stays as an audience and lead type; the Co-Marketing Agreement reference stays for IC campaigns (05 at W4). CE, sponsorship, intent data, professional gating, territory routing and opportunity outcomes are removed.

### Wealth model adaptation (W2): wholesale objects dropped, kept, re-cut and moved

| Wholesale object | Disposition | What changed |
|---|---|---|
| Marketing Theme, Messaging Pillar, Campaign Budget, Spend Line, Campaign Tracking Code, Content Asset, Asset Classification, Asset Version, Asset Compliance Reference, Asset Rights, Asset Accessibility & Rendition, Event Session, Event Speaker, Web Page, Web Form, Web Visitor / Known User, Email Send, Media Engagement, Marketing Segment, Segment Membership, Subscription Topic, Social Media Account, Social Post, Social Engagement Metrics, Social Listening Mention, Media Placement, Paid Media Delivery, Marketing Touchpoint, Lead Qualification | Kept | Names and grain unchanged; examples, perspective, value lists and sources re-cut; review references point at 08 Retail Conduct & Supervision |
| Campaign, Campaign Targeting, Campaign Product | Kept, re-cut | Campaign Business Line added; Target Business Lines and Target Segments replace Target Business Channels; Target Territories dropped; Campaign Product accepts 01 `OFFR-` |
| Campaign Member, Event Registration | Kept, re-cut | Added By Salesperson and Gifts & Entertainment Record dropped; Invited By Salesperson renamed Invited By Advisor |
| Audience Restriction | Kept, re-cut | Partner-Specific Restriction and Marketing Communication Label Indicator dropped; investor categories re-cut to the US three |
| Marketing Event, Digital Property | Kept, re-cut | Event Type and Property Type lose the advisor values and gain client and workplace values; families renamed Client Events & Webinars and Digital Properties & Martech |
| Portal Account | Re-cut, renamed Digital Profile | Portal User ID and Verified Professional Indicator dropped; Digital Profile ID, Status, MFA Factors Enrolled, Biometric Login Enabled Indicator, Last Login Timestamp added |
| Session, Engagement Event, Email Interaction, Engagement Score, Suppression Entry | Kept, re-cut | Login method; feature used, journey and experiment references; unsubscribe write-back; score date; registry scrub date |
| Marketing Lead, Lead Assignment, Lead Conversion | Kept, re-cut | Captured CRD Number and Assigned Territory dropped; Assigned Salesperson renamed Assigned Advisor; Converted Opportunity replaced by Converted Party and Resulting Application Journey |
| Attribution Model, Attributed Outcome | Kept, re-cut | Model ID added; Attributed Opportunity and Attributed Flow Record replaced by Attributed Milestone and Applied Attribution Model; Attributed Amount a Derived copy of 06 |
| Marketing System | Kept, moved to MK-WEB | Personal Data Categories Processed added (shared Personal Data Category); MK-DMM dropped |
| CE Accreditation, CE Credit Issued, Event Sponsorship, Third-Party Intent Signal | Dropped | Intermediary-only (CW-013); lever: restore from the sibling |
| Access Gate, Self-Certification Record | Dropped | FCA COBS 4 professional gating (JURISDICTION) and intermediary-only |
| Campaign Performance Snapshot | Dropped | Stored metrics; DP-025 computes them; 21 governs metric definitions |
| Record Metadata | Dropped | CD-160 (already excluded from the built workbook) |
| (new) | Added | Tracking Consent Choice, Application Journey, Acquisition Milestone, Nudge Definition, Nudge Delivery, Experiment, Experiment Assignment, Promotion Offer, Promotion Enrollment, Client Referral, Client Survey, Survey Response |

The jurisdiction removals (33 entries) and the scope removals (38 entries, including three from the fix pass) are listed one by one in `proposals_w2_04.py`; the re-points are in REPOINTS.

### Deviations from the brief

- **Size.** 318 attributes. The program lead widened the band to 290 to 320 (the brief said 260 to 295): 75 to 80 attributes sit in the 12 new objects, each implementing an accepted decision. Promotions and referrals stay in scope. For a firm that runs neither, the lever is -23 attributes (Promotion Offer 10, Promotion Enrollment 6, Client Referral 7), to 295.
- **Code lists.** 83 used (75 local, 8 shared) against 50 to 60 local and 9 shared: the brief's band was an estimate error (about 52 wholesale lists survive and the brief names 16 new ones). Communication Channel is no longer used; Nudge Channel was folded into Marketing Channel; Outcome Type was merged into Acquisition Milestone Type; Audience Gate Type was added.
- **Nudge Delivery holds no channel consent.** Text-message nudges rely on the 02 TCPA consent; the delivery records only the suppression check result.
- **Application Journey holds no 45 reference.** The digital advice engagement follows from the 15 account and 02 onboarding case; dropped for size (NOTES).
- **Theme to 42 Brand.** No attribute was added; the wholesale had none and the brand register is 42's.
- **Fix pass lows skipped (one line each).** Delivered Nudge Version: not added, to stay inside the 320 band (the review reference is per content asset version). Promotion Terms Asset: not added, same reason; Promotion Compliance Review is defined as the review of the asset carrying the terms. Respondent Organization: the Respondent Party definition was widened to the contact person of an institutional client instead. Survey Trigger merge into milestone types: the triggers include service events that are not milestones.
- **Assigned Salesperson** was renamed Assigned Advisor (the brief says "Assigned Advisor or Team (03)"); one attribute holds the advisor or the coverage team.
- **Intermediary-only removals** are recorded in `SCOPE_REMOVALS`, not `JURISDICTION`, as the brief §4a directs.

## 3. Unverified items (confirm)

- The FCC TCPA revocation rules: effective April 11, 2025; the revoke-all provision of 47 CFR 64.1200(a)(10) delayed first to April 11, 2026 and then to January 31, 2027 (confirm the 2027 date).
- 11 CCR § 7025 as the CCPA regulation on opt-out preference signals; the CPPA regulations path; profiling opt-out rights under state laws (Engagement Score).
- The withdrawal of the 2023 predictive data analytics proposal on June 12, 2025 (the 34-92766 release date and URL are now cited).
- Regulation S-P 2024 amendment compliance dates (December 3, 2025 larger entities; June 3, 2026 smaller entities).
- FTC Telemarketing Sales Rule: the 31-day registry refresh interval.
- The Form 1099-MISC reporting threshold for payments after 2025.
- Rule 206(4)-1(b)(1) disclosures, (b)(2) oversight and (b)(3) disqualification for compensated testimonials and endorsements.
- FINRA social media Regulatory Notices (10-06, 11-39, 17-18) for static and interactive content: cited from the wholesale, not re-read.
- NIST SP 800-63B-4: whether SMS is still a restricted authenticator in Revision 4.
- Salesforce and Adobe XDM field names: cross-checks from documentation summaries, as in the wholesale.

## 4. SME questions (tailoring levers; reference default in brackets)

1. When does a lead become a 02 party? [Name plus a verified email or phone, or an application start.] Lever: application start only.
2. Are anonymous visitor events kept? [24 months, pseudonymous.] Lever: shorter, or no cross-session identity.
3. Can a nudge be a recommendation? [Determined per nudge by 08; Determined Recommendation nudges carry a 45 Recommendation.] Lever: educational nudges only (drop the risk class).
4. Promotions and referral rewards? [Both in scope, with a 1099-MISC flag and the referral reward held once on the 04 side.] Lever, for a firm that runs neither: drop the family (-23 attributes, to 295).
5. Are survey responses held by a vendor? [In house, keyed to 02.] Lever: aggregates only.
6. Advisor marketing for the IC line? [Thin.] Lever: restore CE, sponsorship, gating and intent from the sibling.
7. Attribution model? [Position-based over milestones, 90-day lookback.] Lever: data-driven.
8. Is the campaign hierarchy four levels (program > campaign > wave > tactic)? [Yes.] Lever: three levels.
9. Which system masters opt-ins? [02.] Lever: the marketing platform, with 02 holding Derived copies (CW-084).

## 5. Overlaps with other domains (for consolidation)

- 02: Communication Preference reads `SUB-`; the Digital Engagement Segment, if kept, is a Derived copy of Engagement Score (CW-094); Privacy Profile Sale / Sharing Opt-Out is written from a matched Tracking Consent Choice.
- 03: Advisor and Coverage Team for lead routing and event invitations; Advisor Activity (`ACT-`) for First Sales Activity and touchpoints; Channel Referral (`RFRL-`) versus Client Referral (`CRFL-`).
- 08: Compliance Review (`REV-`) for assets, messages, nudges, promotions and posts; Complaint (`CPL-`) for survey and social referrals.
- 13: Contact Center Interaction (`CCI-`) triggers transactional surveys; Tax Form Record holds the 1099-MISC.
- 15 and 45: the journey ends at submission; 45 Recommendation (`RECOM-`) referenced from Nudge Delivery.
- 47 and 50: Fee Waiver (`FWV-`) and Money Movement (W3) for promotion awards. 06 (W4): net new assets by campaign.

## 6. Suggested validation steps

1. Walk the families through with Marketing, Digital Product, Client Experience, Marketing Operations, 08 and Privacy; confirm CDEs and boundary calls.
2. Trace one prospect end to end: paid search click, calculator use, lead, prospect party, IRA rollover journey, submission, account opened, funded, attributed outcome; check every hand-off has one owner.
3. Test an unsubscribe and a GPC signal through 04 into 02 and back into the next send.
4. Test a Determined Recommendation nudge: 08 determination, delivery, mandatory 45 recommendation reference.
5. Map attributes to the CRM, marketing automation, CDP, analytics, experimentation, push messaging and survey platforms.
