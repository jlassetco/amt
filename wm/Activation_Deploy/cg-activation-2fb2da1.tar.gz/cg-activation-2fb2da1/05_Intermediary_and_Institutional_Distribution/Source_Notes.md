# Source Notes: 05 Intermediary & Institutional Distribution (Draft v0.1, review fix pass 2026-10-15)

Workbook: `Intermediary_and_Institutional_Distribution_Data_Taxonomy.xlsx`. Content module: `_tools/content/content_05_intermediary_and_institutional_distribution.py` (written beside the wholesale `content_05_distribution_agreements_and_partners.py`, which the program lead removes at integration). Enrichment: `_tools/enrichment/enrich_05.py` (rewritten in place). Proposals: `_tools/consolidation/proposals_w4_05.py` (the brief names it `proposals_05.py`; the assignment named `proposals_w4_05.py`).
Size: 8 families, 53 objects (41 business objects, 12 attribute groups), 311 attributes, 97 CDEs (31.2%), 72 code lists (54 local, 18 copies of shared lists), 49 relationships, 23 sources. Ownership: 55 references, 7 derived copies, 0 unresolved. Per family: INT 34, FPR 32, AGR 41, PAY 49, SHF 52, OPS 41, CON 23, PIP 39.

**Perspective.** Wealth manager (direct) | Scope: US. A hypothetical US wealth manager of the Vanguard type (business lines DB, DA, HA, PF, WR, IA, IC, TR; CW-004). For this firm the intermediary channel is secondary and thin (plan section 4 item 9, section 15 item 1): third-party advisors, broker-dealers, RIAs, platforms, TAMPs and third-party recordkeepers use its own funds, ETFs, CITs and models. The firm does not act as RIA custodian (plan section 13).

## 0. Why this domain exists

Two small teams produce this record. Intermediary Distribution manages platform partnerships, home-office relationships, model delivery and partner payments. Institutional Sales & Consultant Relations manages the institutional and OCIO pipeline, RFPs, consultant databases and ratings. Neither belongs in the client master (02 keeps the party core, CW-023), the own-advisor workforce (03) or post-win servicing (12). In the wholesale model, distribution was the whole firm, so this record was spread across 02, 03, 05, 07 and 08. In the wealth model, one thin domain holds the commercial record of the IC and IA lines plus the WR plan sponsor pipeline, keyed to 02 parties.

## 1. Sources consulted

| Source | URL | What it gave us |
|---|---|---|
| FINRA Rule 2341 (l)(4), (l)(5), (d)(4) | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2341 | (l)(4) cash compensation must be described in the prospectus; (l)(5) non-cash compensation limits (education meetings, sponsorship); (d)(4) the no-load test (no sales charge, asset-based sales and service charges of 0.25% or less), so a 12b-1 service fee lever up to 25 bps keeps the funds no-load. Prospectus Disclosure Indicator, Payment Type Program / Sponsorship Fee. |
| SEC IM Guidance Update 2016-01 | https://www.sec.gov/investment/im-guidance-2016-01.pdf | Board oversight of sub-accounting fees, distribution in guise, fund-paid caps, adviser payments from its own resources. Funding Source, Services Compensated, Sub-Accounting Fee Terms. |
| SEC Rule 22c-2 | https://www.ecfr.gov/current/title-17/chapter-II/subchapter-A/part-270/section-270.22c-2 | Shareholder information agreements. Agreement Type, Rule 22c-2 Agreement in Place Indicator, DD Finding Category. |
| Regulation Best Interest and Form CRS | https://www.sec.gov/rules/final/2019/34-86031.pdf | Broker-dealer disclosure of payments received from fund sponsors; retail account types. Partner Disclosure Type, Account Eligibility. |
| SEC Form N-1A (Item 8 and the SAI) | https://www.sec.gov/files/form-n-1a.pdf | Financial intermediary compensation disclosure (secondary reference). |
| DOL 29 CFR 2550.408b-2 | https://www.law.cornell.edu/cfr/text/29/2550.408b-2 | Indirect compensation information supplied to covered service providers. Payment Disclosure. |
| SEC Form ADV Part 1A and IAPD | https://www.sec.gov/about/forms/formadv-part1a.pdf (confirm path) | Item 5.D, 5.E and 5.F; Schedule D 5.K custodians. Form ADV Profile, Primary Custodian. |
| FINRA CRD, BrokerCheck, Form BR; FINRA Rule 3110 | https://brokercheck.finra.org ; https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110 | Registration status, exams, disclosure events; Rule 3110(f)(1) OSJ, (f)(2) branch office, (f)(2)(A)(ii) primary-residence exclusion, .19 residential supervisory location. |
| SEC Form BD | https://www.sec.gov/files/formbd.pdf | Introducing and clearing arrangements. Clearing Firm. |
| DTCC NSCC Fund/SERV, Networking, Omni/SERV | https://www.dtcc.com/wealth-management-services/mutual-fund-services | Dealing route, Networking levels, servicing responsibilities, sub-account files. |
| FINRA Rule 2251 (primary; Supplementary Material .01) and NYSE Rule 451 (secondary) | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2251 | Reasonable reimbursement for forwarding proxy and other issuer materials; the .01 fee names (Processing Unit, Intermediary Unit, intermediary supplemental, NOBO, Preference Management, Notice and Access). Intermediary Communication Fee Type. |
| ICI / IDC, Navigating Intermediary Relationships (2022) | https://www.idc.org/files/2022/22-ppr-navigating-intermediary-relationships.pdf | Taxonomy of intermediary payments and board oversight. Payment Type, Calculation Basis. |
| ICI FICCA framework (2014 and 2015 updates); AICPA SOC 1 | https://ici.org/pubfile_pdf/ppr_16_ficca.pdf (confirm) | FICCA was developed by ICI with accounting firms and attests to 17 control areas of omnibus intermediaries under AICPA standards; ICI updated it in January 2014 and December 2015 (confirm whether a later version exists). SOC 1 Report Received Date, DD Finding Category. |
| OFAC | https://ofac.treasury.gov | Sanctions screening of partners. |
| DOL Form 5500 and Schedule C | https://www.dol.gov/agencies/ebsa/employers-and-advisers/plan-administration-and-compliance/reporting-and-filing/form-5500 | Plan advisors and recordkeepers of prospect plans. |
| Nasdaq eVestment data collection | https://www.nasdaq.com/solutions/evestment/global-database/data-collection-process | Database profiles and submissions; Mercer data collection through eVestment. |
| GIPS; SEC Marketing Rule 206(4)-1; FINRA Rule 2210 | https://www.gipsstandards.org ; https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.206(4)-1 | Composites, third-party ratings, RFP and database compliance review. |
| Salesforce Sales Cloud Opportunity | https://developer.salesforce.com/docs/atlas.en-us.object_reference.meta/object_reference/sforce_api_objects_opportunity.htm (confirm path) | Opportunity, stage and probability (cross-check only). |
| Discovery Data, Broadridge, FINTRX, Cerulli; FIBO BE | https://www.discoverydata.com ; https://spec.edmcouncil.org/fibo/ | Channel, practice and move data; party-in-role concept. |

## 2. Design and boundary decisions

- **Profiles keyed by the 02 party (CW-132, CD-143).** The 13 restored 02 profiles are Business Objects. Each gains a "<role> Party" key typed Reference (Party), following the 17 Issuer Profile pattern; Form ADV Profile and Advisor Practice are attribute groups. Name, address, CRD, LEI and TIN are not re-mastered. The identifiers needed for the operating set-up (Branch CRD Number, TA Dealer Number, NSCC Participant Number) are declared Derived copies of 02. Advisor Team.Team Name is dropped because it is the 02 Party Display Name. Clearing Firm is held once, on Distributor Firm.
- **Restored 02 attribute sets confirmed.** I loaded the compiled wholesale module `content/__pycache__/content_02_client_and_customer.cpython-314.pyc` with python3.14 from a scratchpad script and dumped the 13 objects with their attributes, code lists, relationships and sources. The restored attributes match it, minus the cuts listed in section 2b. UK Certification Status is not restored (CW-902).
- **One activity master, three coverage records (CW-138).** Partner Coverage Assignment (PCVG-) covers partner firms, external advisors, consultants and third-party recordkeepers only. Consultant research reviews and every meeting are 03 Advisor Activity rows.
- **Partner money (CW-136).** The default Payment Types are platform, sub-accounting, networking, omnibus processing, data, model marketplace and intermediary communication fees. Revenue sharing and Rule 12b-1 service fees are lever values, and no example uses them. Payment Calculation.Basis Value is a Derived copy of 06; a row rule is in enrich_05.py. The Fund-Paid Sub-TA Cap is a Derived copy of the 01 fund fee term Fund-Paid Sub-TA Fee Cap with its Approving Board Resolution (35); 01 does not hold it yet, so the merge edit for 01 is in proposals NOTES (review High, program-lead ruling). Payment Type adds Program / Sponsorship Fee for partner program, conference and education sponsorship. Accrual Amount is dropped because accounting belongs to 10.
- **Model delivery (CW-137).** Model Program Placement is keyed by the sponsor program agreement and the model (AGR- / MDL-), matching 36's example. Model Delivery Event (MDEV-) records the delivery type, model version as-of date, delivery channel (shared Delivery Method) and delivered and acknowledged timestamps. Firm Role in Program must agree with the Agreement Type of the sponsor program agreement.
- **Due diligence (CW-135).** One Business Object (DDQ-) absorbs Risk Rating, Screening, Regulatory Status Check, Questionnaire, Outcome and the wholesale 05 Partner Attestation (SOC 1 / FICCA). Due Diligence Review Type (Initial, Periodic, Event-Driven) is kept (CW-135). Due Diligence Finding is keyed by Due Diligence Finding Key (DDQ-n-Fnn, 08's name), and its remediation status uses the shared Case Status.
- **Pipeline (CW-134, CW-139).** Opportunity types are institutional mandate search, OCIO search, intermediary shelf or model placement, and plan sponsor recordkeeping prospect. DCIO is not a channel: the Distribution Channel value is Intermediary - Third-Party Recordkeeper. Placement & Plan Detail.Plan Recordkeeper is typed Reference (Recordkeeper Profile, 16). Win / Loss points to the resulting Shelf Placement and names 11 Competitor Profiles. The won-opportunity link is held on the 12 side (Mandate Onboarding.Won Opportunity, 12 review ruling); 11 Mandate Search Event.Asset Owner stays Reference (Party, 02) because prospects are not clients (not re-pointed).
- **Boundaries left to siblings.** For public-plan and government opportunities, the Advisers Act Rule 206(4)-5 check reads 02 Party Type and the 08 political contribution records; 05 holds no flag. The firm's own ERISA 408(b)(2) disclosure as a prospective recordkeeper is 16 and 47; 05 Payment Disclosure is the indirect compensation information supplied to third-party recordkeepers. Partner Status and Partner Since Date are Derived copies of the 02 Party Role lifecycle. Internal references are typed to the 05 profile they point at (Distributor Firm, Hierarchy Node, Branch / Office, Advisor Team, Financial Professional, Consultant Profile).
- **Agreements.** The executed document is a 39 Contract (Executed Contract; CD-257; DOC- retired). Two Agreement Types were added for existing readers: Co-Marketing Agreement (04) and Authorized Participant Agreement (29; recorded as a CW-131 decision note, not a distribution-partner agreement). Permitted Jurisdictions is kept as US states (ISO 3166-2:US) for blue-sky notice-filing limits.
- **PII.** Every object states its tier in the Notes of its first attribute. Following CW-150, the profiles of individuals (Financial Professional, Advisor Practice, Employment Affiliation, Team Membership, Gatekeeper, External Classification, Advisor Team) are "PII - identity". Disclosure Events Count is "PII - restricted".
- **Shared lists.** 18 local copies carry exact shared names and labels (SHARED_MEMBERSHIPS), including Cost Bearer (steward 13) and Delivery Method; Data Vendor uses the shared Data Provider labels. ADV Client Type, Program Role and Professional Designation became External citations and Account Fee Unit was dropped (the Rate Schedule Calculation Basis carries the unit). Old-to-new value maps cover the wholesale Partner Channel, the 02 Distribution Channel, Agreement Type and Payment Type. Setup Status, Arrangement Status and Database Profile Status are replaced by Record Status; Remediation Status by Case Status; Service Model is merged into Account Eligibility.

### 2a. Deviations from the brief

| Brief | Draft | Why |
|---|---|---|
| 260 to 300 attributes | 311 | Restored-object completeness: the 22 restored objects keep the attributes their readers and the key registry use (DP-005 still loses 15 inputs, listed in READERS) |
| Brief section 5 attributes | Cut: Discretionary RAUM, Top-Level Firm, Decision Authority, Job Title, Revenue Model, Client Niche, Order Cut-Off Time, Payment Direction, Minimum Annual Payment, Offset Method, Annual Commitment Amount, Team Lead, IAR count | Thin cut within the 311 band; each is in NOT_CARRIED |
| 45 to 55 local code lists | 54 local (+18 shared copies) | 22 restored objects bring their lists |
| Per-family targets (INT 32, FPR 32, AGR 40, PAY 46, SHF 42, OPS 40, CON 26, PIP 40) | 34, 32, 41, 49, 52, 41, 23, 39 | Reader-driven |
| Advisor Practice PII "financial (business)" | "PII - identity" | CW-150 |
| Proposals file proposals_05.py | proposals_w4_05.py | Assignment |
| Shared lists Frequency, Message Standard, SLA Unit, Data Granularity | Not used | Their attributes were cut; membership removal is proposed (Delivery Method kept) |
| Program Membership "benefits" | Not carried (Program Type and Partner Tier stand in) | Thin cut; levered from the sibling |
| Local list names Hierarchy Type, Registration Status | Distributor Hierarchy Type, Advisor Registration Category | The consolidated names (LOCAL_RENAMES) were authored directly |

### 2b. Wholesale objects: dropped, kept, re-cut, moved

| Wholesale object | Disposition here |
|---|---|
| 05 Distribution Agreement, Agreement Party Role, Agreement Term, Agreement Amendment, Agreement Product Coverage, Agreement Distribution Scope, Agreement Account Link | Kept by name. Agreement Market dropped (CW-905); Agreement Paper, Signatory and Notice Contact (39) and Coverage Basis not carried |
| 05 Agreement Document | Dropped; 39 Contract (Executed Contract) |
| 05 Payment Arrangement (+ Payment Terms, Payment Limit), Rate Schedule, Rate Tier, Sub-Accounting Fee Terms, Payment Calculation, Partner Invoice, Partner Payment | Kept; Terms and Limit merged; Basis Position Snapshot renamed Basis Snapshot |
| 05 Distribution Fee Pass-Through | Dropped (CW-136; EU attributes recorded under CW-905) |
| 05 Shelf Placement, Share Class Mapping, Partner Research Rating, Model Program Placement, Partner Program, Program Membership (+ Program Benefit) | Kept; Sales Charge Waiver Indicator dropped (no-load default) |
| 05 Partner Dealer Setup (+ Trading Setup), Networking Setup, Partner Data Feed Arrangement, Agreement Obligation (+ SLA, SLA Measurement), Payment Disclosure (+ 408(b)(2) Compensation Disclosure) | Kept; merged as named; settlement fields left to 29 |
| 05 Partner Attestation | Merged into Distributor Due Diligence |
| 05 Distributor Data Exchange; Record Metadata | Dropped (CW-905; CD-160) |
| 02 thirteen profiles | Restored by name (CW-132) |
| 03 Sales Opportunity, Pipeline Status, Opportunity Value, Win / Loss, RFP Request, RFP Submission, Database Profile, Database Submission, Consultant Rating | Restored by name (CW-134) |
| 03 Placement, Model & DCIO Detail | Restored as Placement & Plan Detail |
| 03 Institutional Search Detail, Opportunity Product, Opportunity Competitor | Merged into Sales Opportunity and Win / Loss |
| 03 Opportunity Team, Stage History, Request Question, Answer Library Entry, Consultant Research Review, Consultant Notification, Account Plan family | Dropped (levers; reviews become 03 Advisor Activity) |
| 08 Distributor Due Diligence and six detail objects | One Business Object plus Due Diligence Finding (CW-135) |
| 13 Intermediary Communication Fee Invoice | Moved in unchanged, except Invoice Validation Status |

Every attribute not carried is listed per object in `proposals_w4_05.py` NOT_CARRIED, and the reader re-points are in READERS.

## 3. Jurisdiction pass (CW-905)

There are 83 JURISDICTION entries: 1 object, 16 attributes or attribute references, 62 code-list values or lists, and 4 sources. All are in `jurisdiction.REGIMES`. They cover every item in brief section 4a, plus the EU/UK values of the restored 02, 03 and 08 lists. These were recorded here because the 02 and 08 passes did not record them, apart from UK Certification Status (CW-902) and the OFSI / UK MLR source (CW-908).

Kept and re-sourced: agreements, payments and disclosures (IM Guidance 2016-01, FINRA 2341, Rule 22c-2, Form N-1A, 408(b)(2), Reg BI), DTCC services, and ISO standards. Platform Participant ID (generic, platform-assigned) and Permitted Jurisdictions (US states) are kept and have no entry. The 02 Distribution Channel values cross-reference CW-911 so the lead records them once. Insurance values were dropped under CW-165 and are not recorded as EU/UK removals.

## 4. Not verified (confirm)

- Form ADV Part 1A PDF path.
- The Salesforce object reference path.
- The FICCA URL and whether ICI has published a version after 2015.
- Form ADV Schedule D 5.K(3) wording, the eVestment URL and the DTCC Omni/SERV page (not reachable in the review).
- The Mercer-through-eVestment collection arrangement (wholesale note).

## 5. SME questions (tailoring levers; reference default first)

1. Depth of the intermediary channel. *Default:* thin (firms, external advisors at practice level, platform and model agreements, platform and sub-accounting fees). *Lever:* restore territories, crediting, key account plans and the NOT_CARRIED attributes from tag wholesale-v1.0.
2. DCIO as a channel. *Default:* no (Intermediary - Third-Party Recordkeeper; plan prospects are a WR opportunity). *Lever:* restore RETIREMENT_DCIO and its coverage.
3. 12b-1 or revenue sharing. *Default:* none. *Lever:* the lever Payment Type, Funding Source and Agreement Type values, and the sibling's Distribution Fee Pass-Through.
4. External advisors held individually. *Default:* yes, where a feed or vendor identifies them. *Lever:* firm-level only drops Financial Professional, Advisor Practice and Employment Affiliation.
5. Model delivery, managed sponsor accounts or both. *Default:* both (Program Role). *Lever:* drop one.
6. Distributor due diligence. *Default:* reduced annual review with SOC 1 / FICCA. *Lever:* an attestation on the agreement.
7. RFP answer content. *Default:* kept in the RFP tool. *Lever:* restore Answer Library Entry (ANS-).
8. Permitted states on agreements. *Default:* nationwide, so the attribute is usually blank. *Lever:* populate the ISO 3166-2:US list where an agreement limits states.

## 6. Suggested validation steps

- `/usr/bin/python3 taxonomy_builder.py content_05_intermediary_and_institutional_distribution` reports OK with 0 unresolved.
- `/usr/bin/python3 enrichment/check_enrichment.py 05` reports OK. On 2026-10-15 it picked the new module (53 objects); a scratchpad wrapper bound to the new module gave the same result.
- At the merge: apply READERS and REPOINTS; move OPP-, RFP-, DBS-, DDQ- and IFI- to owner 05 and drop the interim overrides; register the memberships; append JURISDICTION.
