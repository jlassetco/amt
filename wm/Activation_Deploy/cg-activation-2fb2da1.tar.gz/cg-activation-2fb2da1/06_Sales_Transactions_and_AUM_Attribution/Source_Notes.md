# Source Notes: 06 Client Assets, Flows & Channel Attribution

Draft v0.1, 2026-10-15 (fix pass applied: `00_Program/Rework/Reviews/06_review.md` with the program-lead rulings). Wealth manager (direct) | Scope: US. Companion to `Sales_Transactions_and_AUM_Attribution_Data_Taxonomy.xlsx` (built from `_tools/content/content_06_sales_transactions_and_aum_attribution.py`; file, folder and workbook are renamed at integration with `domains.py`). Adapted in place from the wholesale 06 Sales Transactions & AUM Attribution (CW-141; L1 code TX kept). Proposals: `_tools/consolidation/proposals_w4_06.py`.

## 1. Why this domain exists

Client & Channel Analytics produces the firm's headline numbers: Client Assets, Net New Assets and Advised Assets by channel, advisor, campaign and plan, and own-fund flows by share class. The facts come from five books of record (49 brokerage, 50 money movement, 29 the transfer agent register, 16 workplace recordkeeping, 18 institutional portfolios) plus intermediary feeds; none of them can attribute or certify across the others. 06 conforms, summarizes, attributes and certifies; it never masters a holding (CW-007, CW-011, CW-122, CW-141).

## 2. Key sources

| Source | URL | What was taken |
|---|---|---|
| DTCC / NSCC Fund/SERV, Networking, Omni/SERV, DCC&S | https://www.dtcc.com/wealth-management-services/mutual-fund-services | Intermediary order, account, omnibus and plan data (IC line); kept from wholesale. |
| FINRA Rule 11870 (ACATS) | https://www.finra.org/rules-guidance/rulebooks/finra-rules/11870 | ACATS transfer types and the Source Account Transfer link. |
| IRC sections 402(c) and 408(d)(3) | https://www.law.cornell.edu/uscode/text/26/402 (408: confirm page) | Rollover classification and the Rollover Treatment rule. |
| SEC Rule 17Ad-10 | https://www.ecfr.gov/current/title-17/section-240.17Ad-10 (confirm path) | The TA posting that Source Register Transaction and Source Share Register Balance read (CW-122). |
| SEC Rule 22c-2 | https://www.ecfr.gov/current/title-17/section-270.22c-2 (confirm path; the adopting release URL formerly cited redirects to a redemption-fee page) | Omnibus sub-account information rights. |
| SEC Rule 6c-11 | https://www.ecfr.gov/current/title-17/section-270.6c-11 (confirm path) | ETF custom basket value. |
| SEC Form ADV Part 1A Item 5.F | https://www.sec.gov/about/forms/formadv-part1a.pdf (confirm) | Why Client Assets and Advised Assets differ from regulatory assets under management. |
| ICI Monthly Trends / Fact Book | https://www.ici.org/monthly-trends-in-mutual-fund-investing | Fund flow components; sole industry alignment for flow measures now that EFAMA is removed. |
| Morningstar Estimated Net Cash Flow | https://www.morningstar.com/content/dam/marketing/shared/research/methodology/765555_Estimated_Net_Cash_Flow_Methodology.pdf | Market movement, ETF flow basis, estimated data basis. |
| ISO 20022 (setr, semt) | https://www.iso20022.org/iso-20022-message-definitions | Market-neutral; kept. |
| FINRA BrokerCheck / CRD; Broadridge; SS&C DST; GIPS | as in the Sources tab | Kept from wholesale for the IC line and asset framing. |

## 3. Modeling decisions

- **Counting rule (fix pass, ruling 1).** Every Fund Shareholder Position row carries Register Account Category (Derived from 29) and an Aggregation Role. Counted - Firm Client Account: 49 rows (brokerage, managed, trust) and 29 rows of Fund-Only and Institutional Direct accounts. Counted - Intermediary: Networked register rows and intermediary look-through rows (Omnibus Look-Through, ETF Holding at external DTC participants, Plan Position), with the omnibus residual as an unattributed intermediary amount. Excluded - Omnibus or Nominee: Broker-Dealer Omnibus, DTC Nominee, Intermediary Omnibus aggregate, Plan Omnibus (control only; Broker-Dealer Omnibus units = sum of 49 Client Holdings). Excluded - Firm Proprietary: seed and error accounts. Attribution Only: Sponsor-Reported Assets. Client Assets = Account Asset Summary over firm client accounts (49, 29, 16, 18) plus the Counted - Intermediary rows; Account Asset Summary never holds intermediary assets, so nothing is added twice.
- **One flow book per account book (ruling 2).** 49 Client Account Activity for brokerage, managed and trust accounts (50 money movements only through their 49 posting); 29 Register Transaction for direct registered accounts; 16 Participant Ledger Posting for participant accounts; 18 Portfolio Capital Activity for IA mandates; the intermediary feed for intermediary sub-accounts. 29 omnibus and nominee postings and 50 instructions are never loaded. Gross Sales counts brokerage-account purchases from 49, never the omnibus posting. De-duplication key: Flow Source Book + Source Transaction Reference.
- **Measure Value (ruling 3)** is keyed by measure x period end x Dimension Type x Dimension Key (Total, Channel, Holding Type, Business Line, Advisor, Campaign, Share Class, Segment), so Client Assets by holding type and NNA by advisor or campaign are storable. Inter-channel transfers are Transaction rows (Flow Scope Inter-Channel Transfer, From and To Distribution Channel) generated from Account Channel Assignment, valued at the account's Account Asset Summary total on the last day of the old assignment; journals between firm accounts in different channels are inter-channel transfers, never NNA.
- **Valuation (ruling 4).** 49 rows carry the 49 Client Holding Valuation (own ETFs at the approved market price); register rows the 27 NAV. Client Assets are net equity (long value plus cash and sweep less margin debit; lever gross long value), as of the last business day of the period (End of Day). Seed excluded; trust accounts (51) count under TR through their 49 holdings; participant managed accounts stay WR and are outside Advised Assets by default. Holding Type values name their CW-011 holding type (own funds, third-party funds, securities, cash).

- **Transaction is the flow record, not the activity (CW-141).** Name kept for its readers (glossary: Flow Transaction). Order Source now names the source book and the typed source record (49 Client Account Activity or Account Transfer, 50 Money Movement, 29 Register Transaction, 16 Contribution Record or Distribution Request, 18 Portfolio Capital Activity). Row rule (CD-289) on type, dates, units, amounts and account: Derived from the source on internal rows, mastered as delivered on intermediary rows. The declared flag stays "mastered here" because the conformed record is 06's and the source domain differs by row; the row rule says which. Order Entry Channel and Order Message Type keep their 29 Derived flag (TA-processed own-fund orders).
- **Fund Shareholder Position** (renamed from Position, POS- kept): brokerage and managed accounts are views of 49 Client Holding, every other registered account of 29 Share Register Balance at the 27 NAV; only look-through rows are mastered. New: Position Source Book, Source Client Holding, Source Share Register Balance, Valuation NAV.
- **Account Asset Summary** (new, composite key ACC- / date / holding type) feeds Client Assets; it is computed here by summing the named source book and never edited.
- **Account Channel Assignment** (new, CHASG-): one channel and business line per account per period, from account type, enrollment, plan or partner agreement; a change is an inter-channel transfer.
- **Certified definitions** (Client Asset Measures and Measure Definition examples), each with its tailoring lever:
  - *Client Assets* (MSR-CLIENTASSETS): net equity of every firm client account on the last business day, by channel and holding type, plus intermediary-held own-fund assets (Counted - Intermediary rows); a subtotal excluding intermediary-held assets is offered. *Average Client Assets* (MSR-AVGCLIENTASSETS) is the daily average 10 reads. Lever: report intermediary-held own-fund assets and client-custodied mandates only in Firm AUM.
  - *Net New Assets* (MSR-NNA): external cash and asset movements in less out (deposits, withdrawals, ACATS and other transfers, rollovers from outside, plan contributions and distributions, mandate funding and withdrawals, intermediary net sales of own funds); income, fees and inter-channel transfers excluded. Levers: Income Treatment, Fee Treatment, Rollover Treatment (count firm-plan-to-firm-IRA rollovers as NNA for the direct business).
  - *Advised Assets* (MSR-ADVISEDASSETS): Client Assets in fee-based advice, managed or trust enrollments on the period end (equal to the advised and managed roll-up). Levers: include planning-only clients, participant managed accounts or IA mandates.
  - Firm AUM is not defined here; Own-Fund Overlap Amount is reported, never netted (CW-011).
- **Attribution (CW-143):** advisor of record from 03 Party Coverage Assignment (Primary Coverage Indicator, resolved account, then client, then household); IA direct credit from 03 Relationship Manager assignments; campaign and weight from 04; intermediary hierarchy, consultant and salesperson credit from 05 (Partner Coverage Assignment replaces the 07 crediting rule); institutional client from 12; territory removed, suspense by channel.
- **Identity resolution (CW-144)** applies to intermediary feeds only; internal rows use Attribution Method "Account-Keyed".
- **Asset Measures** keep their AUM names for readers but are defined as own-fund assets by channel; Estimated Management Fee Revenue kept (DP-024, DP-066 read it) and labeled an estimate, booked revenue being 10's.

### Wholesale objects dropped, kept, re-cut and moved

| Wholesale object | Disposition |
|---|---|
| Transaction, Transaction Dates, Transaction Amounts, Transaction Status | Kept; Transaction Type re-cut to 30 values; Flow Scope and Holding Type added; row rule re-sourced |
| Order Source | Kept, re-cut (source book and eight source references; Dealing Route re-cut) |
| Intermediary As Delivered, Linked Transaction, ETF Creation / Redemption, SMA Flow | Kept; party references re-pointed to 05 (CW-132) |
| Transaction Sales Charge | Dropped (no-load default; lever) |
| Position | Renamed Fund Shareholder Position; re-cut |
| Omnibus Look-Through, ETF Holding, Plan Position, Sponsor-Reported Assets | Kept; nominee indicator removed; Plan Position limited to third-party recordkept plans (CW-139) |
| Measure Definition, Flow Treatment Rule, Measure Value, Flow Measures, Asset Measures | Kept; four NNA treatments added; FX Effect dropped; EFAMA removed |
| Attribution Record, Distributor Hierarchy, Market & Client Dimensions, Salesperson Credit, Attribution Method, Unattributed Item, Attribution Override | Kept, re-cut (CW-143) |
| Identifier Crosswalk, Match Rule, Match Result, Data Feed, Load, Reconciliation, Reconciliation Run, Break, Reporting Period, Snapshot, Restatement | Kept; Compensation Cut-Off Date and Coverage - Markets removed |
| Record Metadata | Dropped (CD-160) |
| New | Account Asset Summary, Account Channel Assignment, Client Asset Measures |

### Deviations from the brief

1. Suspense Territory / Bucket replaced by a new Suspense Channel attribute. 2. No 46 Model Assignment reference in Order Source. 3. No separate rollover link attribute: Linked Transaction ID joins the 16 Participant Ledger Posting (Distribution) and the IRA receipt posted in 49 (the 16 Receiving Account money movement reaches 06 only through that posting). 4. 54 code lists against 35-45 (ruling: toward 55; copied lists now cite their owners as External). 5. 290 attributes (band 290). 9. Fix-pass items skipped for the size band are listed in proposals NOTES. 6. Networking Matrix Level (As Delivered) and Data Feed.Coverage - Markets removed. 7. FundsXML removed as EU market practice. 8. Proposals file named `proposals_w4_06.py` per the assignment.

## 4. Wealth model adaptation: jurisdiction pass (CW-906)

26 JURISDICTION entries: 3 attributes (Platform / Fund Distributor (EU/UK), Investor Country, Nominee / Platform Account Indicator), 17 code values (four EU dealing routes, three EU/UK channels, Initial Charge (EU/UK), FCA FRN, Platform Distributor Code, Platform Data Service, Platform Re-Registration (UK), Nominee Disclosure (EU/UK), Attribution Dimension Platform and Investor Country, FundsXML file format and message standard), 6 sources (EFAMA, Calastone, Clearstream Vestima, Allfunds, MiFID II, FundsXML). Re-sourced to ICI, Morningstar, FINRA Rule 11870, IRC 402(c) and 408(d)(3), SEC Rule 22c-2. Foreign-currency cash and foreign securities received in client accounts keep their FX attributes.

## 5. What could not be verified

- eCFR paths for SEC Rules 17Ad-10 and 6c-11, the Cornell page for IRC 408(d)(3), and the Form ADV Part 1A PDF path (marked confirm).
- DTCC record layouts and aggregator dictionaries (member or licensed), as in the wholesale notes.
- Sibling names (49, 50, 29, 16, 05, 03, 04) were checked against the drafted modules in the fix pass; the 04 Attributed Outcome key is a composite (milestone x campaign x model) without a prefix.

## 6. Open questions for SMEs (tailoring levers; reference default first)

1. Which flows count as Net New Assets? *Default:* external cash and asset movements; income and fees excluded. *Lever:* Income Treatment, Fee Treatment.
2. Is a rollover from a firm plan into a firm IRA new money? *Default:* inter-channel transfer. *Lever:* Rollover Treatment = Count as Net New Assets.
3. Do Client Assets include intermediary-held own-fund assets and mandates held at client custodians? *Default:* yes, as their own channels. *Lever:* Firm AUM only.
4. Which holding-type list governs? *Default:* the eleven values. *Lever:* collapse to own funds, third-party funds, securities, cash.
5. Fund-flow attribution to intermediaries at advisor level? *Default:* where feeds allow. *Lever:* firm level only.
6. Advised Assets: fee-based enrollment only? *Default:* yes. *Lever:* include planning-only clients.
7. Is a self-directed-to-advice enrollment an inter-channel transfer (zero firm-wide) and also reported as advised net new assets? *Default:* inter-channel transfer only. *Lever:* separate advice-conversion measure.
8. Does the own-fund overlap also cover the advisory slice of Firm AUM (46 managed and 18 mandate assets)? *Default:* fund slice only (CW-011 owner to confirm). *Lever:* report the overlap by Firm AUM slice.
9. Which flows does a campaign milestone cover? *Default:* the funding flow of the milestone. *Lever:* a window of flows after it.

## 7. Suggested validation steps

1. Ratify the three certified definitions and treatment defaults with Finance; register them in 21.
2. Test that every account has exactly one Account Channel Assignment per day.
3. Reconcile Account Asset Summary totals to 49, 16 and 18, and Fund Shareholder Positions to the 29 register.
4. Re-point the readers listed in `proposals_w4_06.py` NOTES at the W4 merge (DP-006, DP-007, DP-008, DP-241, SM-01 and the Position readers).
