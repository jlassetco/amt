# Source Notes: 08 Retail Conduct & Supervision (Draft v0.1, fix pass 2026-10-15)

Workbook: `Retail_Conduct_and_Supervision_Data_Taxonomy.xlsx`. Content module: `_tools/content/content_08_retail_conduct_and_supervision.py` (written beside the wholesale `content_08_distribution_compliance.py`, which the program lead removes at integration; both stay at tag `wholesale-v1.0`). Enrichment: `_tools/enrichment/enrich_08.py` (rewritten in place). Proposals: `_tools/consolidation/proposals_w2_08.py` (the brief names it `proposals_08.py`; the assignment's name is used).
Size (after the fix pass on 00_Program/Rework/Reviews/08_review.md): 9 families, 39 objects (26 business objects, 13 attribute groups), 303 attributes, 102 CDEs (33.7%), 55 code lists in the module (42 local, 13 copies of shared lists; 54 in the workbook because Approval Status and G&E Approval Status render as one shared list), 61 relationships, 23 sources. Ownership: 87 references, 6 derived copies, 0 unresolved. Jurisdiction register: 71 entries under CW-908. Before the fix pass: 290 attributes, 86 CDEs, 52 local lists, 3 derived copies.

**Perspective.** Wealth manager (direct) | Scope: US. A hypothetical US wealth manager of the Vanguard type (business lines DB, DA, HA, PF, WR, IA, IC, TR; CW-004) with a self-clearing FINRA broker-dealer and an SEC-registered adviser, dual-registered representatives and one supervisory system. Reg BI applies to broker-dealer recommendations, the Advisers Act fiduciary duty to advice, DOL PTE 2020-02 to rollover and IRA advice.

## 0. Why this domain exists

The conduct risk of a wealth manager sits in what its representatives recommend to retail investors and in how the broker-dealer and the adviser supervise them. Retail compliance and the supervising principals produce this record: principal reviews of recommendations, rollovers, approvals, transactions and correspondence; suitability and best-interest surveillance; branch inspections and control testing (FINRA Rules 3110 and 3120); written customer complaints (Rules 4513 and 4530); the supervisory case behind a senior investor concern (Rule 2165); communications review (Rule 2210, Advisers Act Rule 206(4)-1); and the registration of each representative (Forms U4 and U5, Rule 1240, IAR registration). The advice and its evidence are 45's, client facts 02's, approvals 15's and firm-level programs 38's; 08 is the supervisory layer over them (CW-015, CW-066). The wholesale 08 served an intermediary distributor and cannot hold this.

## 1. Sources consulted

| Source | URL | What it gave us |
|---|---|---|
| Regulation Best Interest, Exchange Act Rule 15l-1 | https://www.ecfr.gov/current/title-17/section-240.15l-1 | Disclosure, care, conflict of interest and compliance obligations; incentive conflicts, material limitations and the elimination of sales contests (15l-1(a)(2)(iii)(A) to (D)). Supervisory Review, Best Interest Review Detail, Incentive Conflict Review. |
| Form CRS: Exchange Act Rule 17a-14, Advisers Act Rule 204-5 | https://www.ecfr.gov/current/title-17/section-240.17a-14 | Initial delivery triggers, delivery on recommendation of an account type, rollover or new service, amendment and request timing. Disclosure Delivery Check, Disclosure Trigger. |
| SEC interpretation of the adviser standard of conduct (2019) | https://www.sec.gov/rules-regulations/2019/06/commission-interpretation-regarding-standard-conduct-investment-advisers | Duty of care and loyalty. Standard of Conduct. |
| DOL PTE 2020-02 | https://www.dol.gov/agencies/ebsa/laws-and-regulations/rules-and-regulations/completed-rulemaking/1210-AC38 | Impartial Conduct Standards, rollover documentation, fiduciary acknowledgment, annual retrospective review (held in 38). Best Interest Review Detail. |
| FINRA Rule 3110 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110 | Supervisory system, transaction review (b)(2), correspondence review (b)(4), no self-review (b)(6), inspection cycles (c), branch and OSJ definitions (e) and (f), remote inspections pilot (3110.18) and residential supervisory locations (3110.19). Supervisory System family. |
| FINRA Rules 3120 and 3130 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/3120 | Annual testing and report to senior management; CEO certification (38 Attestation). Supervisory Control Test. |
| FINRA Rules 4530 and 4513; Product and Problem Codes (Attachment A) | https://www.finra.org/filing-reporting/rule-4530-reporting-requirements | Event reporting, quarterly statistical reporting, product and problem codes (Attachment A, effective 1 October 2017, read from https://www.finra.org/sites/default/files/4530_Product_Problem_Codes_Attachment-A.pdf; problem codes 16 Reg BI and 17 Form CRS added by Regulatory Notice 20-17, https://www.finra.org/rules-guidance/notices/20-17), complaint records by office. Complaints family. |
| FINRA Rule 2165 and Regulatory Notice 22-05 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2165 | Specified adults, temporary holds, internal review, trusted contact. Senior Investor Case, Protection Action Type. |
| Senior Safe Act (S. 2155, section 303) | https://www.congress.gov/bill/115th-congress/senate-bill/2155 | Immunity for reports by trained employees. External Protection Report. |
| FINRA Rules 2210, 2212, 2214; filing chart | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2210 | Communication categories, approval, content standards, filing, rankings, investment analysis tools. Communications Review. |
| Advisers Act Rule 206(4)-1 and staff FAQ | https://www.ecfr.gov/current/title-17/section-275.206(4)-1 | Advertisement definition, testimonials, ratings, performance. US Communication Classification, Performance Presentation. |
| Securities Act Rule 482; ICA Rule 34b-1; Rule 497 | https://www.ecfr.gov/current/title-17/section-230.482 | Fund advertisements, standardized performance. |
| SEC Rules 17a-4 and 204-2 | https://www.ecfr.gov/current/title-17/section-240.17a-4 | Retention of business communications and electronic recordkeeping. Captured Communication Record. |
| FINRA Rules 1210, 1220, 1240; Forms U4, U5, BR | https://www.finra.org/rules-guidance/rulebooks/finra-rules/1240 | Registration categories, qualification lapse, CE elements, Maintaining Qualifications Program, uniform forms. Registration & Licensing. |
| NASAA IAR CE Model Rule | https://www.nasaa.org | 12 credits a year (6 products and practice, 6 ethics) in adopting states. CE Element. |
| FINRA Rules 2111, 2360, 4210 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2111 | Quantitative suitability; options approval by a Registered Options Principal; margin. Surveillance Scenario, Supervisory Review Type. |
| FINRA Regulatory Notices 21-09 and 22-08 | https://www.finra.org/rules-guidance/notices/21-09 | Heightened supervision of representatives with misconduct history; complex products. |
| FINRA Rules 3220 and 2341; Regulatory Notice 26-05 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/3220 ; https://www.finra.org/rules-guidance/notices/26-05 | Rule 3220 covers gifts to employees or agents of another person, not to individual retail customers; limit USD 300 effective 30 March 2026 (RN 26-05, 27 February 2026); exclusions; aggregation basis stated in procedures; non-cash compensation and training and education meetings. Gifts family. |
| FINRA Rule 5310 (5310.09 regular and rigorous review) | https://www.finra.org/rules-guidance/rulebooks/finra-rules/5310 | Best-execution committee review of routing and execution quality. Supervisory Review Type 'Best Execution Regular and Rigorous Review'. |
| SEC Rule 22c-2; Form N-1A | https://www.ecfr.gov/current/title-17/section-270.22c-2 | Redemption fees, shareholder information agreements, frequent trading policies. Frequent Trading Case. |
| ERISA, DOL LMRDA Form LM-10, Advisers Act Rule 206(4)-5 | https://www.dol.gov/agencies/olms | Special recipient flags. |
| 31 CFR 1023.320 | https://www.ecfr.gov/current/title-31/section-1023.320 | SAR confidentiality behind the restricted AML case reference. |
| SR 11-7 | https://www.federalreserve.gov/supervisionreg/srletters/sr1107.htm | Model governance of model-based scenarios. |

## 2. Design and boundary decisions

1. **Supervise, never re-master (CW-066).** Supervisory Review references its subject (45 Recommendation `RECOM-`, 15 Account or Account Feature, 48 Client Order `CLORD-`, 08 Captured Communication Record, or for the best-execution review a 48 Routing Rule or Execution Venue Profile; ROW_OWNERSHIP states which subject each type fills) and records the principal, the control applied, dates, outcome and exceptions. Best Interest Review Detail holds the standard applied, the 02 profile version checked, four evidence-present indicators (profile current, alternatives, cost, PTE documentation), the evidence exceptions and references to 45 Best Interest Evidence and Rollover Analysis and to the Disclosure Delivery Check. No rationale, best-interest flag, cost comparison, profile value, approval decision or hold is held here. Acceptance question 3: the missing evidence is a 45 fact, the exception an 08 fact.
2. **One Supervisory Review, typed** (brief SME question 1 default). Digital advice reviews are a type (population review with exception sampling).
3. **Disclosure Delivery Check** tests delivery evidence against the 38 Form CRS filing version in force: 15 Account Disclosure Delivery, 45 Best Interest Evidence for a client-level delivery made before an account exists, 13 Shareholder Communication for amendments and requests, 47 Fee Disclosure Delivery. A row rule requires an account or retail investor and at least one evidence reference unless the result is Not Delivered or Not Required.
4. **Incentive Conflict Review** keys on a 03 Incentive Plan Component or a 03 Recognition Award (non-cash compensation) and the review date, and records the 15l-1(a)(2)(iii) tests, a proprietary-product incentive finding and the outcome; the conflicts register and mitigation stay 38 (`CONFL-`).
5. **Surveillance.** Surveillance Scenario (`SCEN-`) is versioned with type, rule basis, thresholds, population and an optional 37 model. Sales Practice Alert (kept) is keyed to a scenario; its alert types are re-cut to retail exceptions. Frequent Trading Case (kept) stays in 08 (SME question 7 default); 29 references it.
6. **Supervisory system.** Supervisory Control is keyed by its 38 WSP Policy (`POLCY-` / control number); the responsible designation is a code on the 03 Principal Designation scale. Branch Inspection (`BRIN-`) of the 03 Firm Branch Office carries the Rule 3110(c) inspection cycle and a Derived copy of the 03 Branch Type (03 masters the list: Office of Supervisory Jurisdiction, Branch Office, Non-Branch Location; residential supervisory locations are a 03 indicator). Supervisory Finding (`SFND-`) references its source. Heightened Supervision Plan (`HSPL-`) is special category where the basis is a criminal disclosure; its supervisor is a Derived copy of the 03 Supervisory Assignment of type Heightened Supervision Supervisor. The best-execution committee's regular and rigorous review (FINRA Rule 5310.09) is a Supervisory Review type; 48 holds the statistics.
7. **Communications.** The six kept review objects keep their names; Required Disclosures merged into US Communication Classification, Other Regulator Filing into FINRA Advertising Filing (Filing Regulator on the shared Regulator list). Social Media Account merged into Approved Communication Channel, which references the 04 Social Media Account for firm accounts.
8. **Complaints (CW-070).** One Complaint record per grievance meeting Rules 4530 and 4513; oral grievances are recorded by policy (Written Complaint Indicator false) and excluded from the Rule 4530(d) counts by default. The 13 Service Request is referenced as intake; Complaint Office names the 03 OSJ that keeps the Rule 4513 record. The wholesale Vulnerable Customer Indicator is replaced by a restricted Reference (Vulnerability Concern) to 02. Related Transaction is typed 49 Client Account Activity (`CLACT-`). Complaint and senior case statuses use the shared Case Status; Final Response Due Date is kept, re-sourced to firm policy.
9. **Senior investor protection (CW-071).** 08 masters the Senior Investor Case (`SNRC-`) and the agency referral (External Protection Report). The case escalates one or more 02 concerns (SME question 5 default: only concerns raised in 02); the specified adult basis and the first trusted-contact contact are Derived copies of 02, which keeps those facts; later contacts and holds are case actions that reference the 02 trusted contact designation, 15 Account Restriction (`ARX-`) and 50 Money Movement Hold (`MMHLD-`). 02 Vulnerability Concern.Agency Referral Date becomes a Derived copy of 08 at the merge. SARs stay 38; the case holds no AML link (38 may point to `SNRC-`).
10. **Registration (CW-072).** Individual Registration keeps every attribute DP-009 reads and adds Registration Body (FINRA or a state regulator) beside the state jurisdiction; IAR CE applies only in adopting states. Exam Result (person x exam x attempt, with exam date) and CE Requirement reference the registration (`LIC-`); Disclosure Event is keyed per person (`EMP-` / event) with an optional registration link. Branch Registration records the Form BR filing only; the CRD code for a Registered Options Principal is OP.
11. **Gifts.** Special Recipient Flags merged into Gift / Entertainment Item. FINRA Rule 3220 covers gifts to the employees or agents of another person (plan officials, institutional and sponsor personnel), not gifts to individual retail customers (Regulatory Notice 26-05); retail-client gifts are tested against a firm policy limit (G&E Limit Rule 'Firm Retail Client Gift Policy'). Items received from product sponsors (Rule 2341(l)(5)) use the same object with Direction = Inflow (shared Flow Direction).
12. **Retention moves to 21 (CW-068); state notice filings are not 08's (CW-069); Rules 3240 and 3241 declarations are 38's (CW-074).**

### Wholesale objects: kept, re-cut, moved, dropped

| Wholesale object | Disposition |
|---|---|
| Compliance Review, US Communication Classification, Performance Presentation, Review Step, Compliance Approval, FINRA Advertising Filing | Kept by name (attributes trimmed; Required Disclosures and Other Regulator Filing merged in) |
| Approved Communication Channel, Captured Communication Record, Surveillance Alert | Kept by name (Social Media Account merged into the channel) |
| Sales Practice Alert, Frequent Trading Case | Kept by name (re-cut to retail; Selling Distributor dropped) |
| Complaint, Complaint Classification, Complaint Handling, Complaint Regulatory Report | Kept by name (FCA fields removed; FINRA Product Code added; Distributor Involved dropped) |
| Individual Registration, Exam Result, Registration Filing, Disclosure Event, CE Requirement | Kept by name (IAR, IAR CE added; SM&CR removed) |
| Gift / Entertainment Item, Benefit Valuation, G&E Approval, Training / Education Meeting | Kept by name (Special Recipient Flags merged) |
| Required Disclosures; Other Regulator Filing; Social Media Account; Special Recipient Flags | Merged (see above) |
| Retention Rule | Moved to 21 (CW-068) |
| Distributor Due Diligence and its six detail objects | Moved to 05 at W4 (`DDQ-` held) |
| Distribution Conflict of Interest | Dropped (38 `CONFL-`; `COI-` retired) |
| Intermediary Information Package, Private Offering Compliance | Dropped |
| EU / UK Communication Classification, Distributor Feedback Report, Sales Against Target Market, Distribution Chain Information Exchange, Distribution Review Finding, Inducement Assessment, Certification & Competence, Cross-Border Marketing Notification, Pre-Marketing Episode, Reverse Solicitation Record, Outcome Metric | Dropped, EU/UK (JURISDICTION, CW-908) |
| Record Metadata | Dropped (CD-160) |

New objects: Supervisory Review, Best Interest Review Detail, Disclosure Delivery Check, Incentive Conflict Review, Surveillance Scenario, Conduct Corrective Action, Supervisory Control, Supervisory Control Test, Branch Inspection, Supervisory Finding, Heightened Supervision Plan, Senior Investor Case, Senior Investor Case Action, External Protection Report, Branch Registration.

### Deviations from the brief

- Object kinds: 26 business objects and 13 attribute groups (the brief header says 25 and 14; its table gives 26 and 13).
- Local code lists: 42 (within 36 to 46 after the fix pass). Folded into shared lists: Audience Category (Investor Category), Gross Net Presentation (Performance Fee Basis), Alert Review Status, Remediation Status, Complaint Status and Senior Case Status (Case Status), Regulator Filing Type (Regulator), Benefit Direction (Flow Direction). Cited as sibling lists: Branch Type (03), Standard of Conduct (45 Best Interest Component; two values proposed to 45). Firm-defined formats: Lexicon Category, Disclosure Set, Reviewer Role, Capture Method, Surveillance Alert Source, Complaint Root Cause, Complaint Category. De-overlapped: Conduct Rule Basis (rule numbers only), Heightened Supervision Basis (one 'Disclosure Event' value), Supervised Activity Type, Disclosure Status.
- 45 names: Recommendation (`RECOM-`), Best Interest Evidence, Rollover Analysis (`ROLV-`) per the 45 brief and content module, not the plan anchors `RCO-` / `ADE-` named in this brief.
- Attributes: 303 against 240 to 290, because the fix pass added the subjects and keys the review asked for. Not carried from the wholesale objects (no EU/UK reason): Business Purpose, Sponsorship Agreement (replaced by Sponsor Firm), Financial Professional Use Only Indicator, Complaint.Related Communication, Compliance Approval Code, Re-certification Frequency, FINRA Comments Summary, Preservation Method, Content Supervision Model, Excluded Gift Category; with EU primary sources (also in JURISDICTION): Offering Document Reference Included, Regulator Filing Type, Regulator Submission Date. Also dropped in the fix pass: Campaign, Prescribed Periods Shown Indicator, Population Scope, Case Action Action Taken By, Related AML Case. Readers are listed in proposals NOTES.
- Wholesale intermediary attributes Complaint.Distributor Involved and Sales Practice Alert.Selling Distributor dropped (thin IC line; omnibus accounts are 15 accounts).

## 3. Unverified items (confirm)

Closed in the fix pass (verified by the reviewer): the FINRA Rule 4530 code selection against Attachment A (effective 1 October 2017) and Regulatory Notice 20-17 (codes 16 and 17, effective 18 July 2020) - load the full list; Rule 4530(a)(1)(B) as the theft, misappropriation and forgery prong; the Rule 3220 USD 300 limit effective 30 March 2026 (Regulatory Notice 26-05); CRD codes OP (Registered Options Principal) and SU (Sales Supervisor); Series 51 as a current MSRB exam; the Senior Safe Act as section 303 of S. 2155.

Still open:
- FINRA Rule 2165: up to 55 business days in total since the 2022 amendments (Regulatory Notice 22-05); SR-FINRA-2026-018 proposes longer holds and a temporary delay rule (status confirm).
- DOL PTE 2020-02 current text after the litigation over the 2024 amendments; the EBSA page path.
- NASAA IAR CE adopting states and the model rule page.
- FINRA Rule 3290 (outside activities, replacing 3270 and 3280) effective date (38's object, cited in boundary text only).
- FINRA Rule 3110.18 remote inspections pilot end date; the Form CRS amendment and request delivery periods (60 and 30 days); the Form U4 complaint reporting thresholds and the Form U4 and U5 30-day deadline in FINRA By-Laws Article V; the 2019 adviser interpretation page path.

## 4. SME questions (tailoring levers; reference default in brackets)

1. One Supervisory Review object or separate objects per type? [One, typed; split for separate surveillance and review platforms.]
2. Are digital advice recommendations reviewed one by one? [By model and population, with exception sampling.]
3. Which Form CRS triggers are checked? [All triggers plus material change; lever: sample-based checks.]
4. Is every written grievance a complaint, including email and chat; are oral grievances recorded? [Yes to both; oral with the written indicator false and excluded from the Rule 4530(d) counts; lever: written-only scope.]
5. Do senior investor cases cover all specified adults or only concerns? [Only concerns raised in 02.]
6. On what basis is the Rule 3220 annual gift total aggregated: calendar year, fiscal year or rolling 12 months? [Calendar year, stated in the procedures (Regulatory Notice 26-05).]
7. Does the frequent trading case stay with conduct or move to 29? [08; 29 references it.]
8. Where does the retention schedule live? [21 (CW-068); lever: 39 where records sit in Legal.]
9. Does a senior investor case run in compliance or a financial crimes unit? [Compliance (08); lever: 38 (CW-071).]
10. Should the dropped Preservation Method, Content Supervision Model and Excluded Gift Category return? [No; restore if the archive or G&E teams report on them.]

## 5. Overlaps with other domains (for consolidation)

- 45: Recommendation, Best Interest Evidence, Rollover Analysis referenced; 45 Best Interest Evidence keeps the attester's judgment.
- 02: Investor Profile, Vulnerability Concern, Trusted Contact Designation; specified adult basis and first trusted-contact date as Derived copies; at the merge 02 Escalation Case Reference is retyped to Reference (Senior Investor Case, 08) and Agency Referral Date becomes a Derived copy of 08.
- 15: Account, Account Feature, Account Disclosure Delivery, Account Restriction.
- 03: Advisor, Firm Branch Office, Incentive Plan Component, Recognition Award, Branch Type and Principal Designation Type scales; heightened supervisor and branch types as Derived copies; 03 references LIC-, HSPL-, ARC-, GNE- and Incentive Conflict Review.
- 20: Employee, Employee Lifecycle Event, Learning Completion; Regulated Role Category is not merged with Registration Category (NOT_MERGED).
- 38: Policy, Conflict of Interest, Conflict Mitigation, Examination Finding, AML Case, Firm Regulatory Filing (Form CRS).
- 48: Client Order (`CLORD-`), Routing Rule, Execution Venue Profile; 49: Client Account Activity (`CLACT-`); 50: Money Movement Hold (`MMHLD-`).
- 04, 13, 39, 21, 47, 37, 01, 05, 09.

## 6. Suggested validation steps

1. Walk one rollover recommendation from 45 through Supervisory Review, Best Interest Review Detail and Disclosure Delivery Check with Retail Compliance and Advice Operations.
2. Walk one senior investor concern from 02 through the case, a 15 or 50 hold and an APS report with Senior Investor Protection.
3. Reconcile the complaint record to the last two quarters' Rule 4530(d) submissions.
4. Map registration objects to CRD extracts (registrations, exams, U4/U5, CE, Form BR).
5. Confirm the items in section 3.
