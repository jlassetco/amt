# 09 Shared & Enterprise Reference Data: Source Notes

**Workbook:** `Shared_and_Enterprise_Reference_Data_Taxonomy.xlsx` | **Module:** `_tools/content/content_09_shared_and_enterprise_reference_data.py` | Draft v0.1, 2026-10-14
**Perspective:** Wealth manager (direct) | Scope: US. A US wealth manager that serves investors directly (brokerage, digital and human advice), manufactures its own mutual funds, ETFs and CITs, recordkeeps workplace plans and advises institutions (Wealth_Manager_Rework_Plan.md §2). Carried over from the wholesale model with the US-only pass of CW-909 (section 7).
**Size (builder, after W1):** 9 families, 44 objects, 212 attributes, 63 CDEs (29.7%), 56 code lists, 32 relationships, 28 sources.

## 1. Key sources reviewed

| Source | URL | What it gave us |
|---|---|---|
| ISO 3166 / ISO 4217 (SIX amendments) / ISO 639 / IETF BCP 47 / Unicode CLDR | https://www.iso.org/iso-3166-country-codes.html ; https://www.six-group.com/en/products-services/financial-information/data-standards.html ; https://www.loc.gov/standards/iso639-2/ ; https://www.rfc-editor.org/info/bcp47 ; https://cldr.unicode.org | Enterprise keys for country, subdivision, currency, language and locale. ISO 4217 Amendment 180: Bulgaria adopted EUR on 1 Jan 2026 (BGN is now historic, fixed at 1.95583). Amendment 179 added XAD. These show why the registry tracks the source release. |
| IANA Time Zone Database | https://www.iana.org/time-zones | Area/Location IDs are the time zone key. tzdata ships several releases a year, so the release loaded is recorded. |
| US Census FIPS/ANSI and ZCTA; OMB Bulletin 23-01; HUD-USPS crosswalk | https://www.census.gov/library/reference/code-lists/ansi.html ; https://www.whitehouse.gov/wp-content/uploads/2023/07/OMB-Bulletin-23-01.pdf ; https://www.huduser.gov/portal/datasets/usps_crosswalk.html | County FIPS (5-digit), CBSA delineation issued 21 Jul 2023 (supersedes 20-01), ZIP-to-county address ratios. Used for "Preferred County". |
| LSEG WM/Reuters FX benchmarks | https://www.lseg.com/en/data-analytics/financial-data/benchmarks/foreign-exchange-benchmarks | The 4pm London close uses trades and quotes in a short window around 16:00 London. Administered by LSEG Benchmark Services Ltd; kept because the firm's funds hold foreign assets. LSEG has open 2026 consultations (rounding decimals, VND). |
| ECB euro reference rates | https://www.ecb.europa.eu/stats/policy_and_exchange_rates/euro_reference_exchange_rates/html/index.en.html | Concertation around 14:10 CET, published around 16:00 CET on TARGET days, information only. Gave the "Units of Quote per 1 EUR" convention and the TARGET publication calendar. |
| GLEIF LEI-CDF 3.1, RR-CDF 2.1 (Level 2), ELF list | https://www.gleif.org/en/about-lei/common-data-file-format/relationship-record-cdf-format | Direct and ultimate accounting-consolidation parents, Level 2 reporting exceptions and LEI registration statuses. ISO 20275 legal-form codes. |
| FIBO BE Ownership & Control; FBC Functional Entities | https://spec.edmcouncil.org/fibo/ontology/BE/OwnershipAndControl/ ; https://spec.edmcouncil.org/fibo/ontology/FBC/FunctionalEntities/ | Ownership vs control parties, and regulated financial-service-provider categories behind Internal Entity Category and the distribution roles. |
| SEC IAPD/EDGAR (Form ADV, Form BD, Form TA-1), FINRA BrokerCheck, OCC | https://adviserinfo.sec.gov ; https://brokercheck.finra.org ; https://www.sec.gov/edgar ; https://www.occ.gov | Entity-level registration identifiers (SEC file numbers 801-, 8-, 84-, CRD, CIK, OCC charter number). The registrations themselves are mastered in 38 (CD-250). The OCC register page is to confirm. |
| SIFMA holiday recommendations; Federal Reserve Financial Services holiday schedules | https://www.sifma.org ; https://www.frbservices.org/about/holiday-schedules | SIFMA recommends full and early (2:00 p.m. ET) closes for US dollar fixed income; recommendations only. The Reserve Banks publish Fedwire and FedACH holidays (Saturday holidays observed the preceding Friday, Sunday holidays the following Monday) and FedACH processing windows; Fedwire Funds Service operation on Sundays and weekday holidays is announced for no earlier than 2028 (confirm). The SIFMA page URL is to confirm. |
| SEC Rule 22c-1 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.22c-1 | Forward pricing and daily NAV computation for redeemable fund shares: the basis of the every-business-day dealing pattern. |
| NAICS (2022; 2027 in progress), SEC SIC list, GICS | https://www.census.gov/naics/ ; https://www.sec.gov/search-filings/standard-industrial-classification-sic-code-list ; https://www.msci.com/indexes/index-resources/gics | NAICS 2022 combined 523920 Portfolio Management and 523930 Investment Advice into 523940 (verified 2026-10-14 via BLS). The 2027 NAICS is due to take effect for periods from 1 Jan 2027 (Federal Register notice of Jul 2026). These are the reasons for versioned schemes and concordances. |
| ISO/IEC 11179-3:2023; W3C SKOS; DAMA-DMBOK ch. 10; DCAM | https://www.iso.org/standard/78915.html ; https://www.w3.org/TR/skos-reference/ ; https://www.dama.org/cpages/body-of-knowledge | Registry item, registration status and mapping metamodel. SKOS match types for crosswalks. Reference data governance and change control. |

Research was light: about 13 searches and no full-text fetches. Several facts come from search snippets of official pages.

## 2. Design and boundary decisions

- **One generic Geographic Unit (GEO-)** for every scheme, typed by scheme and vintage, with effective-dated hierarchies. Sales and service regions and country clusters (for investment exposure reporting) are **Geographic Groups** (GEO-GRP-…). 07 still owns territories (TER-) and alignment rules. It should point its "Geographic Definition" at GEO- units and replace its own `Geographic Unit Type` list with ours.
- **Market lists are geography.** 03 `Sales Market`, 05 `Agreement Market` and 07 `Market Scope` become Geographic Groups of type *Market*.
- **Calendars: structure here, use elsewhere.** 09 owns CAL- (holiday, exchange, dealing, fiscal and reporting calendars) and the dealing-day rule. 01 keeps the product's calendar reference, cut-off time and valuation point. 09 owns the reporting period *definitions*. 06 (TX-SNP), 07 and 10 own their own close and lock dates. 19 owns the accounting period status (CD-152); Fiscal Period Status is a derived copy of it. Settlement and payment system calendars (Fedwire, FedACH, DTC, TARGET) are 09 Calendars of type Settlement (CSD / Payment System) (CD-185); 26 owns the settlement cycle rules.
- **FX: reference only.** Rate types, sources, fixing times, quote conventions, fallback rules and approved usages are defined here. Rate time series are excluded, and the rate licenses belong to 14 (DSET-).
- **Internal legal entities (LEN-) vs party master (PTY-).** The firm's own entities (parent, RIA, self-clearing broker-dealer, fund adviser and fund trusts, transfer agent, recordkeeper, optional national trust company) are defined here, with GLEIF Level 2 ownership; their registrations (AUTH-) are in 38 (CD-250). Every LEN- carries a PTY- cross-reference, so 01 product party roles and 05 agreements still work. Over time, 03 `Employing Legal Entity`, 05 `Firm Contracting Entity Indicator`, and 08 `Registering Firm`, `Applicable Legal Entity` and the `Legal Entity (firm-defined)` list should reference LEN- directly.
- **Entity vs individual registrations.** Entity registrations (AUTH-: Form ADV, Form BD, Form TA-1, the OCC charter, with their SEC file and charter numbers) are mastered in 38 (CD-250). Individual licenses stay in 08 (LIC-). Own-firm CRD and CIK are held on LEN-, external firms' identifiers on PTY- (02), which mirrors review-log item 1.
- **Entity roles.** 09 records the standing role of an entity in a market or channel (e.g. US principal underwriter for all '40 Act funds). Fund-specific service-provider roles remain in 01's Product Party Role.
- **Org units (OU-) vs Finance.** 09 owns the org unit and its hierarchies, including reorganizations (REORG-). Cost and profit center *codes* and the chart of accounts are owned by 19 (CD-152); the org unit references them as 19 Chart Segment Values. Cost allocation stays in 10.
- **Industry classification.** 09 holds the scheme metadata, nodes and concordances. 02 holds the code assigned to each organization. GICS is flagged as licensed.
- **Code list registry (CLR-).** This follows the ISO/IEC 11179 pattern: entry → version (CLV-) → values → source-system mappings (CLM-), plus consumers and change requests. The registry does **not** build harmonized value sets. Party-matching crosswalks stay in 06 (XWK-). CLM- is for code values only.
- **Prefixes used here:** `REORG-` (reorganization), `SITE-` (office location), `ICS-` (industry classification scheme version), `CLV-` (code list version), `CLM-` (code value mapping); `AUTH-` moved to 38 with the entity registrations (CD-250) and `EMP-` is mastered in 20 (CD-151). The structured GEO- and CAL- IDs used in examples (e.g. `GEO-US-CBSA-35620`, `CAL-US-NYSE`) are illustrative. Note that `CR-` in the change-request example is a workflow-tool reference, not a proposed prefix.

## 3. What could not be verified

- The **ISO 20275 ELF code** of a Delaware LLC (the example names it without a code), the GLEIF RA code and the example LEI are illustrative. Check them against the GLEIF lists.
- The **GLEIF Level 2 reporting exception** values (NATURAL_PERSONS, NON_CONSOLIDATING, NO_KNOWN_PERSON, NON_PUBLIC, NO_LEI) are from memory and need checking against the current RR-CDF and reporting-exception documentation. The same applies to the full LEI registration status list.
- The WMR fix window (snippets disagree: ±30 s vs a 5-minute window, depending on currency tier) and current LSEG consultation outcomes. Confirm with the licensed methodology document via 14.
- The final effective date of NAICS 2027.

## 4. Open questions for SMEs

1. Legal Entity Management / Company Secretariat: which system is the record for group entities, and who owns LEI renewals for each entity?
2. Compliance: should AUTH- (38) also cover state investment adviser notice filings and blue-sky BD registrations, or should those stay in 08?
3. Fund Operations: what is the source of the dealing calendars (the transfer agent or internal), how are NYSE closures applied, and does any CIT deal less often than daily?
4. Finance (19): who maintains the cost center chart segment values, and is the org hierarchy the same as the management P&L hierarchy?
5. Treasury / Fund Accounting: which FX rate type is approved for AUM translation, fee calculation and compensation, and is a single "Group Reporting Currency" agreed?
6. Client Service and Advice: should service regions be pure geography (GEO- groups), or do some regions mix geography and named accounts? If they mix, they belong in 07 as territories.
7. Data Governance Office: the registry tool (MDM hub, data catalog, or a bespoke service), and the approval forum for shared lists.

## 5. Suggested next steps

1. Load the registry with the enterprise shared lists (shared_code_lists.py) and every domain's local lists, tagging owner, class and consumers.
2. Apply the wealth re-cuts of the shared lists 09 stewards (CW-039, CW-909) at W5.
3. Agree the LEN-/PTY- rule with 02 and have 03, 05 and 08 reference LEN- when they are replaced (W2, W4).
4. Choose load sources and refresh cadences for each external list (SIX, IANA, Census/OMB/HUD, SIFMA, Federal Reserve, GLEIF).
5. Confirm the CDEs with the data owners.

## 6. Candidate shared code lists (found duplicated across 01–08)

| Concept | Where it appears today |
|---|---|
| Distribution / Sales Channel | 01, 02, 06 `Distribution Channel`; 03, 07 `Sales Channel`; 04 `Business Channel`; 05 `Partner Channel` (7 lists, all different values) |
| Frequency | 01, 03, 05, 06, 07, 08 `Frequency` |
| Data Quality Status | in all of 01–08 (identical values) |
| Registration Status | 01, 02, 04, 08 |
| Investor Type / Client Category | 01, 02 `Investor Type` |
| Party Role Type | 01, 02 (different meanings: fund service roles vs distributor hierarchy roles) |
| Market (Sales Market / Agreement Market / Market Scope) | 03, 05, 07 → model as Geographic Group Type = Market |
| Lifecycle / Approval / Payment Status | 01 `Lifecycle Status`; 07, 08 `Approval Status`; 05, 07 `Payment Status` |
| Networking Level | 02, 05 (see review-log item 3) |
| Qualification Exam, Screening Result | 02, 08 |
| Personal Data Category, Data Classification | 02, 03; 06, 07 |
| Social Platform, Snapshot Type, Message Standard | 04, 08; 03, 06; 05, 06 |
| Geographic Unit Type; Legal Entity (firm-defined) | 07; 08 → replace with this domain's list and LEN- |

These also appear in the workbook's `Shared Code List Candidate` list, which feeds the registry's "Harmonization Candidate" attribute.

## 7. Wealth model carry-over (W1, CW-909)

The wealth model keeps 09 and its scope; the pass changes only what is EU/UK-specific and the perspective (CW-003, CW-022). Every removal is a JURISDICTION entry in `_tools/consolidation/proposals_w1_09.py` (74 entries) and can be restored from tag `wholesale-v1.0`.

**Removed.** Objects UK Postcode, ITL Region and NUTS Region (the object group "UK & EU Statistical & Postal Geography"); Country.EU Member State Indicator and EEA Member Indicator; FX Rate Usage value Share Class Hedging (UCITS practice; '40 Act classes share one portfolio); FX Quote Convention value Units of Currency per 1 GBP; Entity Distribution Role values Sub-Distributor and Marketing Communication Issuer; Dealing Calendar Rule.Non-Dealing Day Threshold (a UCITS practice: '40 Act funds price every NYSE day under Rule 22c-1 and fair-value foreign closures); FX Rate Source.Benchmark Regulatory Status and the list Benchmark Regulatory Status (EU / UK BMR); Legal Entity Identifier.FCA Firm Reference Number; EU/UK values of Geographic Unit Type, Geographic Scheme, Geographic Hierarchy Type, Internal Entity Category (Management Company / AIFM, MiFID Investment Firm, UK Authorized Firm), Entity Distribution Role (Global Distributor, Management Company, AIFM, s21 Financial Promotion Approver), Industry Classification Scheme (NACE, UK SIC) and Shared Code List Candidate (Distribution Strategy); sources ONS ITL and NSPL, Eurostat NUTS, EU / UK BMR, FCA Register and Handbook, CSSF and Central Bank of Ireland registers, UCITS / AIFMD / MiFID II, NACE Rev. 2.1, UK SIC.

**Re-sourced.** Internal Entity Category to the US entity set (Parent Holding Company, Intermediate Holding Company, Registered Investment Adviser, Broker-Dealer (self-clearing), Fund Adviser, Fund Trust (registrant), Transfer Agent, Recordkeeper, National Trust Company, Service Company, Branch; General Partner / Fund Vehicle Sponsor kept for the W4 retirement decision), sourced to Form ADV, Form BD, Form TA-1 and the OCC charter. Entity Distribution Role to the US roles (Principal Underwriter, Distributor, Selling Dealer or Agent, Placement Agent, Transfer Agent, Recordkeeper, 529 Program Manager, plus Investment Manager, Sub-Adviser, Model Provider and the employing and contracting roles). Entity identifiers: CRD and CIK stay on LEN-; SEC file numbers (801-, 8-, 84-, 811-) and the OCC charter number are held per registration in 38 and are not repeated here. Dealing Day Pattern to SEC Rule 22c-1. Industry classification examples from NACE to NAICS 2022.

**Kept (investment universe).** Every country and subdivision, currencies, time zones, foreign exchange and settlement calendars (TARGET, London), FX rate types and sources (WM/Reuters, ECB, Bank of England), GICS and ISIC.

**Added (plan §5.1).** Calendar Type value Settlement (CSD / Payment System) (Fedwire Funds Service, FedACH, DTC), which replaces Banking / Settlement under CD-185, and the Bond Market value tied to SIFMA US closes, for 49 and 50; a CAL-US-FEDWIRE example on Composite Calendar; SIFMA and Federal Reserve holiday-schedule sources; Internal Legal Entity examples for the entities of plan §2 (LEN-0001 parent, LEN-0002 fund adviser, LEN-0003 broker-dealer, LEN-0004 RIA, LEN-0005 fund trust, LEN-0006 transfer agent, LEN-0007 recordkeeper, LEN-0008 national trust company, LEN-0009 service company).

**Re-pointed.** Nothing to re-type: 09 references 02 only through Party Master Cross-Reference (Reference (Party)), which the wealth 02 keeps (CW-021).

**Shared lists stewarded by 09 (proposed, applied by the program lead at W5).** Regulator to US authorities (plus MSRB); Distribution Market to US (one value: to retire or become US service regions at W4); Delivery Method without the FinDatEx wording; Geographic Unit Type without UK/EU values; Business Line to the eight CW-004 lines. Distribution Channel waits for W4.

**Open questions.** (1) Should Distribution Market survive with one value, or become US sales and service regions (Geographic Group Type = Market) when 03 and 05 are replaced at W4? (2) Do 26, 49 and 50 cite Calendar Type as a shared list or reference CAL- calendars only? (3) Does the firm's optional national trust company need its own Calendar (trust operations) or follow the Federal Reserve calendar? (4) Confirm the Delaware LLC ELF code, the SIFMA holiday page and the OCC charter register page.
