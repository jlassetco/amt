# Source Notes: 10 Client Revenue, Pricing Economics & Profitability (Draft v0.1, wealth manager W4 adaptation, 2026-10-15)

Workbook: `Distribution_Finance_and_Profitability_Data_Taxonomy.xlsx` (name and folder kept until the program lead renames them; the brief's target folder is `10_Client_Revenue_Pricing_Economics_and_Profitability/`). Content module: `_tools/content/content_10_distribution_finance_and_profitability.py` (adapted in place from the wholesale Distribution Finance & Profitability; the wholesale version stays at tag `wholesale-v1.0`). Enrichment: `_tools/enrichment/enrich_10.py`. Proposals: `_tools/consolidation/proposals_w4_10.py`. Brief: `00_Program/Rework/Briefs/10_Client_Revenue_Pricing_Economics_and_Profitability.md`.

Size (built, after the review fix pass of section 9): 10 families, 40 objects (29 business objects, 11 attribute groups), 284 attributes, 94 CDEs (33%), 49 code lists, 55 relationships, 23 sources. Ownership: 68 references, 18 derived copies, 18 overrides, 17 row ownership rules, 0 unresolved. Draft before the fix pass: 280 attributes, 92 CDEs, 52 relationships, 19 derived copies. Wholesale (built, Record Metadata excluded): 11 families, 33 objects, 223 attributes, 68 CDEs, 45 code lists, 28 relationships, 16 sources.

## 0. Why this domain exists, and what the adaptation changed

Finance and FP&A of a direct wealth manager need to know what each client account, Client Household, offering, channel, business line and segment earns and costs. Advisory fees are calculated in 47, commissions come from executions in 48, margin interest and fully paid lending from 49, cash sweep economics from 50, fund management fees from the fund ledger (27), and the certified figures sit in the general ledger (19). None of them answers what a client segment is worth after the cost of serving it. The wholesale 10 answered that question for distribution partners (revenue by share class, partner payments, wholesaler expense, profitability by partner firm and territory). The wealth 10 keeps the revenue-recognition, contract cost, allocation, hierarchy, planning and transfer pricing machinery, keeps the names its live products read, and turns its grain to the client: Client Revenue Record per account, Cash Program Economics, a re-cut Cost-to-Serve Profile, client acquisition cost, lifetime value and pricing scenarios. The fact that justifies a separate domain is unchanged: management accounting reproduces allocated results from rules and drivers, which is neither the ledger (19) nor the fee calculation (47).

Perspective: US entities reporting under US GAAP (the RIA, the broker-dealer acting also as principal underwriter, the fund adviser, the transfer agent, the recordkeeper and the optional trust company). Business lines DB, DA, HA, PF, WR, IA, IC and TR (CW-004).

## 1. Sources consulted

| Source | URL | What it gave us |
|---|---|---|
| FASB ASC 606, ASC 340-40, ASC 280, ASC 810 | https://asc.fasb.org (subscription; topic pages, confirm paths) | Five-step model, constraint ("probable" under US GAAP), principal versus agent, series guidance, consideration payable to a customer; costs to obtain and fulfill, amortization including anticipated renewals, impairment, one-year practical expedient; segment management approach; intercompany elimination. |
| AICPA Audit and Accounting Guide, Revenue Recognition, Chapter 4 Asset Management | https://www.aicpa-cima.com/ (licensed; confirm) | Customer determination (fund versus client), fulcrum and performance fees, 12b-1 trailing fees, CDSC and deferred commissions; kept from the wholesale research (secondary summaries). |
| RSM US, Revenue recognition considerations for asset managers (Nov 2023) | https://rsmus.com/content/dam/rsm/insights/financial-reporting/1pdf/Revenue-recognition-considerations-for-asset-managers-202311.pdf | Practitioner support for waivers as consideration payable and constrained performance fees (wholesale source, KPMG half dropped because the PDF never parsed). |
| Advisers Act Rules 205-1, 205-2, 205-3 | https://www.ecfr.gov/current/title-17/chapter-II/part-275 | Fulcrum fee computation (investment performance, asset value, specified period of at least 12 months) for registered funds; qualified client exemption for performance fees on mandates. |
| Investment Company Act section 15 | https://www.govinfo.gov/content/pkg/COMPS-1879/pdf/COMPS-1879.pdf (confirm URL) | Advisory contracts terminable on 60 days' notice without penalty (Termination Notice Period); sub-advisory contracts. |
| SEC Rule 12b-1; FINRA Rule 2341 | https://www.ecfr.gov/current/title-17/section-270.12b-1 | Fund-paid distribution plans and sales charge limits (intermediary channel only). |
| SEC Form N-1A; SEC IM Guidance Update 2016-01 | https://www.sec.gov/files/formn-1a.pdf ; https://www.sec.gov/investment/im-guidance-2016-01.pdf | Waivers and recoupment; fund-paid versus adviser-paid sub-accounting (wholesale sources kept). |
| SEC Rule 15c3-3 | https://www.ecfr.gov/current/title-17/section-240.15c3-3 | Sweep program context for Cash Program Economics: paragraph (a)(17) defines Sweep Program and (j)(2)(ii) sets its conditions (verified by the reviewer, 2026-10-15). |
| SEC Rule 606 of Regulation NMS | https://www.ecfr.gov/current/title-17/section-242.606 | Order routing payment disclosure; the Order Routing Payment revenue stream exists with default none. |
| FOCUS Report, Form X-17A-5 Part II | https://www.sec.gov/files/formx-17a-5_2.pdf (confirm URL) | Broker-dealer statement of income lines (commissions, fees for account supervision and investment advisory services, interest, other revenue) used to align Revenue Stream, Management P&L Line and Cost Item Category. |
| Form ADV Part 2A, Item 5 (Fees and Compensation) | https://www.sec.gov/about/forms/formadv-part2.pdf (confirm URL) | Fee schedule disclosure for advisory programs: the offering and schedule references of Client Revenue Record and Pricing Scenario. |
| IRC section 482; Treas. Reg. sections 1.482-1 and 1.482-9; IRC section 6662(e) | https://www.ecfr.gov/current/title-26/section-1.482-1 | Arm's length standard and range (section 1.482-1(e)); methods for controlled services transactions (section 1.482-9: services cost method, comparable uncontrolled services price, gross services margin, cost of services plus, comparable profits, profit split, unspecified); documentation penalty protection. Primary for Intercompany & Transfer Pricing (confirm method list against the current regulation). |
| OECD Transfer Pricing Guidelines (2022) | https://doi.org/10.1787/0e655865-en | Secondary reference on TP Method only (lever for a firm with foreign affiliates). |
| FINRA Notice to Members 03-63 (Expense-Sharing Agreements) | https://www.finra.org/rules-guidance/notices/03-63 (confirm URL) | Broker-dealer recording of expenses an affiliate pays under an expense-sharing agreement (SEC Rule 17a-3); secondary reference on Intercompany Service Type. |
| US GAAP Financial Reporting Taxonomy | https://xbrl.fasb.org/ | Revenue and expense disaggregation tags (element names not verified). |
| Kaplan and Anderson, Time-Driven Activity-Based Costing (HBR, Nov 2004) | https://hbswk.hbs.edu/item/adding-time-to-activity-based-costing | Capacity cost rate and unit times for contact center, advice and operations drivers. |
| McKinsey Performance Lens; ICI Trends in the Expenses and Fees of Funds 2025 | https://www.mckinsey.com/featured-insights/charts/assets-up-but-profits-stuck ; https://www.ici.org/system/files/2026-03/per32-01.pdf | Market-neutral context for revenue yield, margins and the decline of 12b-1 revenue (kept). |
| SOX section 404 / COSO 2013 | https://www.coso.org | Reconciliation controls. |

Research was light and reused the wholesale research; new sources were cited from the brief's list and checked only for existence and scope.

## 2. Design and boundary decisions

- **Account for, never recalculate (CW-156).** Client Revenue Record (account x revenue stream x month) carries multi-valued Source Calculation Records on every row: 47 Account Fee Calculation or Fee Invoice (advisory, planning, OCIO, plan recordkeeping and trust fees; 16 and 51 hold only the terms), 47 Fee Debit (account service charges) and Fee Adjustment (corrections), 48 Client Trade Confirmation (commissions and markups) with its 49 Client Account Activity posting, 49 Client Account Activity (margin interest) and Fully Paid Securities Loan, and 50 Sweep Allocation (bank sweep fee allocation). The row amount is the month's sum of its sources. Exceptions stated as such: the fully paid lending firm share is derived from 49 loan data until 49 holds it, and Program Bank Fee Earned is computed in Cash Program Economics from declared 50 and 39 inputs. Distribution Cost Item keeps its name (DP-244 reads it); its Source Record is multi-valued.
- **Calculated, recognized, certified (CW-012, CW-011).** 47 calculates, 10 recognizes, 19 certifies (DP-191). Glossary: Fee Revenue (own funds), Client Revenue (accounts); bare "Fee" is the 47 client fee.
- **Derived copies for client assets and revenue inputs (CW-011, CW-007).** Client Assets and Net New Assets are certified in 06 only. 10 holds them only as Derived copies with an as-of: Profitability Record.Average AUM Reference (06 Average Client Assets, or 27 fund net assets on product rows; row rule), Pricing Scenario.Affected Client Assets (06 Ending Client Assets as of the Scenario Base Date). Forecasts use the 06 definitions but are mastered here. Fund management fee revenue and rate are Derived copies of the 27 Fund Expense Accrual; swept balances and client rates of 50; channel and business line of the 06 Account Channel Assignment at period end; segments of 02 Segment Assignment at period end. 10 masters no Client Holding, cash or sweep balance.
- **Economics, not the price (CW-158).** Pricing Scenario references the proposed 47 Fee Schedule version (client fees) or the 36 Proposed Term Change (fund expense terms, which are 36's until effective, then 01), the 36 Product Change Initiative and 11 Competitor Pricing Observations; it holds no adopted rate.
- **Fee Schedule references (47 review, Medium item).** Wholesale line 68 (Performance Fee Record "terms held in 01 Product") and line 510 (REL "Fee rate terms from 01") meant fund expense terms for share classes and client fees for mandates. The draft keeps the subject attribute and adds Performance Fee Terms Reference typed `Reference (Fund Fee Schedule, 01 / Fee Schedule, 47)` with a row rule (47 owns mandate performance fee terms; the 47 Performance Fee Calculation is the amount source); the REL now reads "Share Class under the fund fee terms (01 FSCH-)", and mandate fees leave Fee Revenue Record for Client Revenue Record. Waiver Record.Expense Cap Terms Reference is re-typed to the 01 fund fee terms. Client-fee references (Pricing Scenario) are `Reference (Fee Schedule, 47)`.
- **Household-level economics are restricted (CW-157).** Client Revenue Record and Client Lifetime Value Estimate are PII - financial; household rows of Profitability Record, Allocation Result and Cost-to-Serve Profile are PII - financial and restricted; products show segment aggregates. Advisor rows are PII - financial (employee compensation, restricted, CD-344) at any grain, and their Direct Sales & Marketing Cost is an allocated Cost Pool amount. No cost item carries one person's pay amount: advisor compensation is booked per cost center and period. Household-grain revenue rows key on the 47 Fee Household, never on the 02 Client Household.
- **Cost-to-serve components (CW-157).** The seven components are a local list (Cost-to-Serve Component) that tags each Cost Pool; the profile stores six amounts (Coverage and Servicing = Advice, Client Service, Platform & Technology, Clearing & Client Asset Custody, Money Movement, Communications & Regulatory), keeping the human-advice versus digital split visible. Intermediary partner payments are the parent record's Distribution Payments. The served subject is the parent Profitability Record's grain; Served Party is kept for household and client rows.
- **Kinds.** Capitalization Assessment, Allocation Result, Cost-to-Serve Profile, Management Hierarchy Node, Plan Line, Flow & Revenue Forecast, Variance, TP Policy, Performance Obligation, Profitability Measure and Pricing Scenario Result are Attribute Groups, as the brief lists them.
- **Prefixes.** Kept: `DCO-`, `ALM-`, `PNL-`, `BUD-`, `RVC-`, `FRR-`, `PFR-`, `WVR-`, `ACR-`, `CCA-`, `ACM-`, `CPO-`, `DRV-`, `ARU-`, `ARN-`, `MHY-`, `HRS-`, `ICA-`, `ICC-`. New (reserved by CW-156 to CW-158): `CLREV-`, `LTVM-`, `PRSC-`. Composite keys for Cash Program Economics, Client Acquisition Cost Record, Client Lifetime Value Estimate and Pricing Scenario Result (proposals_w4_economics.KEY_FORMATS).

## 3. Wholesale objects dropped, kept, re-cut and moved

| Wholesale object | Disposition | What changed |
|---|---|---|
| Revenue Contract, Performance Obligation | Kept | Customer is the fund, the client, the plan sponsor or the institution; Underlying Agreement adds 15 AAG-, 16 PSVA-, 51 TRUST-; contract types and obligation types re-cut; UCITS / AIF and ManCo wording removed; Accounting Framework uses the shared Accounting Basis values |
| Fee Revenue Record | Kept | Own funds, ETFs, CITs and the money market sweep fund; Sub-Adviser Engagement (52) added; fund average net assets Derived from 27 |
| Performance Fee Record | Kept, re-cut | Fulcrum (Rules 205-1, 205-2) and mandate fees (Rule 205-3); Performance Fee Terms Reference added; ESMA source and EUR examples removed; Crystallization Date name kept for DP-012 |
| Distribution Revenue Record | Kept (thin) | Intermediary channel share classes only |
| Waiver Record, Adviser-Borne Cost | Kept | Fund level; client fee waivers are 47 FWV- |
| Distribution Cost Item | Kept, re-cut | Name kept; sources 03, 05, 04, 14, 19, 40; Inducement Assessment Reference removed; Cost Item Category list (renamed from Distribution Expense Category; attribute name kept) |
| Accrual | Kept | 07 removed from the accrual basis |
| Contract Cost Asset, Capitalization Assessment | Kept, re-cut | Advisor and referral incentives for advisory contracts (03 ICP-n-Cnn); legacy deferred sales commission kept as a lever value; placement fee value removed (30 retires) |
| Account Mapping, Control | Kept | Control moves to the Ledger Mapping & Controls family; Control Period added; reconciliation types add 47, 48, 03 and 19 pairs |
| Cost Pool, Allocation Method, Allocation Driver, Allocation Rule, Allocation Run, Allocation Result | Kept | Cost Pool adds Cost-to-Serve Component; drivers add households, service contacts (13), trades (48), money movements (50) |
| Profitability Record, Profitability Measure, Profitability Measure Definition | Kept, re-cut | Territory removed; Salesperson becomes Advisor (03); Business Line, Service Offering, Service Tier added; Partner Firm re-typed to 05 Distributor Firm; Client / Account holds Client Household rows |
| Cost-to-Serve Profile | Kept, re-cut | Components per CW-157 |
| Management Hierarchy, Hierarchy Restatement | Kept | Restatement Trigger 'Territory Realignment' becomes 'Coverage Model Change' |
| Hierarchy Node | Renamed | Management Hierarchy Node (the name resolved to the wholesale 02 Hierarchy Node, which 05 restores) |
| Plan Version, Plan Line, Variance | Kept | |
| Flow & Revenue Forecast | Kept, re-cut | Sales Forecast Reference removed (03 FCS- retired); Forecast Channel added; reads the 06 definitions |
| Intercompany Agreement, TP Policy, Intercompany Charge | Kept | US entities; VAT Treatment removed; IRC section 482 primary |
| Record Metadata | Dropped | CD-160 (governance metadata is 21) |
| (new) Client Revenue Record, Cash Program Economics | Added | CW-156 |
| (new) Client Acquisition Cost Record, Lifetime Value Model, Client Lifetime Value Estimate | Added | CW-157 |
| (new) Pricing Scenario, Pricing Scenario Result | Added | CW-158 |

**07 and 30 references (W4 retirement brief section 5).** All removed or re-pointed: Profitability Record.Territory removed; Capitalization Assessment and the REL rows to ICP-, CPS- and TER- re-pointed to 03 or removed; Source Domain value 07 removed; Restatement Trigger RLN- value replaced; Reconciliation Type and Accrual Basis wording re-pointed to 03; Leaf Member example TER- replaced. 30: private fund placement values removed.

## 4. Jurisdiction pass (CW-910)

42 JURISDICTION entries in proposals_w4_10.py (33 Other EU/UK, 6 UCITS, 3 MiFID II): Inducement Assessment Reference; VAT Treatment and its list; the four EU/UK Accounting Framework values (resolving the W1b None mappings); Trail Commission / Retrocession; ManCo Services Agreement and the UCITS / AIF descriptions; ManCo and retrocession wording; the ESMA primary reference of Crystallization Date; six EUR, UK and Luxembourg examples; IFRS 15 secondary references on 19 attributes and IFRS 8 on Operating Segment Mapping; the IFRS 15 source and the IFRS 8 half of the ASC 280 source. OECD TPG re-sourced to IRC section 482 as primary needs no entry (not an EU/UK regime). Foreign-currency revenue of international funds stays (Variance Driver FX kept).

## 5. Deviations from the brief

1. Client Revenue Record grain is account x revenue stream x month; household-grain rows key on the 47 Fee Household (lever), and business line is a Derived copy of 06 Account Channel Assignment.Assigned Business Line.
2. Profitability Record has no Household or Acquisition Channel attribute: Client / Account holds Client Household rows (as the wholesale held client rows), and acquisition-channel economics are the Client Acquisition Cost Record and Client Lifetime Value Estimate.
3. Cost-to-Serve Profile stores six of the seven CW-157 components (Communications and Regulatory merged); the seven are kept on the Cost-to-Serve Component list.
4. Cost per Funded Household, funded account counts, the cohort on Client Lifetime Value Estimate and the pricing breakeven are computed in products, not stored.
5. The proposals file is proposals_w4_10.py (the brief names proposals_10.py).
6. Sub-advisory reference uses the 52 Sub-Adviser Engagement (SADV-) that the 52 module defines, not the brief's "sub-advisory agreement, SAA- anchor".
7. Attributes are 284, four above the brief's band, after the program-lead fix-pass rulings; every wholesale attribute a live product reads is kept by name.

## 6. Unverified items (confirm)

- Exact ASC paragraph references (for example ASC 606-10-32-11 for the constraint) and US GAAP Taxonomy element names (subscription).
- Whether section 482 documentation matters for the domestic affiliates beyond state tax and separate-return members: intercompany transactions within a US consolidated return are governed mainly by Treas. Reg. section 1.1502-13 (confirm with Tax).
- Content of the FOCUS report form and Form ADV Part 2 PDFs (the URLs resolve; the content could not be read) and the Investment Company Act compilation URL.
- Verified by the reviewer (2026-10-15) and no longer confirm items: SEC Rule 15c3-3(a)(17) and (j)(2)(ii); the Treas. Reg. section 1.482-9(a) method list; FINRA Notice to Members 03-63; ICI per32-01.
- Whether the AICPA Chapter 4 conclusions on fulcrum fees and costs to obtain advisory contracts match the draft's defaults (licensed source, secondary summaries only).
- The 06 measure code MSR-AVGCLIENTASSETS is illustrative (06 gives no measure codes); the drafted 05, 06, 16, 36, 47, 48, 49, 50, 51 and 52 modules were read for every other name.
- How the firm share of fully paid lending revenue is computed: 49 holds only the client's rate (merge edit in proposals NOTES).

## 7. SME questions (tailoring levers; reference default first)

1. Grain of Client Revenue Record. *Default:* account x offering x stream x month. *Lever:* household-month rows where billing is household level.
2. Recognizing entity of bank sweep fees. *Default:* the broker-dealer. *Lever:* a cash-management affiliate.
3. Order routing payments. *Default:* none (the stream exists unused). *Lever:* populated from 48 Rule 606 data.
4. Capitalization of advisor and referral incentives under ASC 340-40. *Default:* capitalized where incremental to a new advisory contract, amortized over the expected relationship life, one-year practical expedient tested. *Lever:* expense all.
5. Legacy deferred sales commissions (CDSC share classes in IC). *Default:* none; the Cost Asset Type value and CDSC Recovery Offset are kept for readers. *Lever:* drop them.
6. Lifetime value method. *Default:* discounted margin over 20 years with segment attrition. *Lever:* cohort revenue multiples or a survival model.
7. Household-level profitability visibility. *Default:* restricted; products show segment aggregates. *Lever:* advisor-facing household views with entitlement.
8. Transfer pricing source. *Default:* IRC section 482 primary, OECD secondary; consolidated-return intercompany transactions follow Treas. Reg. section 1.1502-13 (confirm). *Lever:* OECD primary for a firm with foreign affiliates.
9. Cost-to-serve granularity. *Default:* six stored amounts (Advice, Service, Platform, Clearing and Client Asset Custody, Money Movement, Communications & Regulatory). *Lever:* seven, splitting Communications from Regulatory.
10. (Retired: the program lead ruled that 47 owns mandate performance-fee terms.)
11. Presentation of sub-advised fund fees. *Default:* gross, sub-advisory fees as expense (Stream Principal vs Agent Conclusion 'Principal'). *Lever:* net.

## 8. Suggested validation steps

1. Technical Accounting walkthrough of DF-REV and DF-EXP (customer determination, principal versus agent, fulcrum constraint, capitalization of incentives, sweep fee entity).
2. Reconcile one month of Client Revenue Records to 47 calculations and 48 executions, and to the 19 ledger.
3. FP&A workshop on cost pools, the TDABC drivers and the cost-to-serve components; pilot one quarter for the digital advice offering.
4. Register the lifetime value model in the 37 model inventory and agree its validation.
5. Agree the hand-off contracts with 47, 48, 49, 50, 16, 51, 06 and 03 (source record IDs and amounts).
6. Re-point DP-034, DP-035 (Management Hierarchy Node) and drop VAT Treatment from DP-195 and DP-074 at WP0 (proposals_w4_10 NOTES).

## 9. Review fix pass (00_Program/Rework/Reviews/10_review.md; program-lead rulings, 2026-10-15)

| Ruling or finding | Change |
|---|---|
| 1 (High) Commission source | Client Revenue Record.Source Calculation Record names 48 Client Trade Confirmation (Commission Charged, Markup Markdown Amount, account level) with the 49 Client Account Activity posting; Client Execution removed from the type, REL, row rule and Reconciliation Type ('Confirmations vs Commission Revenue (48)'). |
| 2 (High) Proposed fund terms | Pricing Scenario.Proposed Schedule Version is `Reference (Fee Schedule, 47 / Proposed Term Change, 36)`; fund expense scenarios reference the 36 Proposed Term Change until effective. Family text, REL, Pricing Scenario Type and term conflict updated. |
| 3 (High) Individual pay | Direct Sales & Marketing Cost on advisor rows is an allocated Cost Pool amount; advisor rows are PII - financial (employee compensation, restricted, CD-344); Distribution Cost Item.Source Record is multi-valued with a 05 example, and its override is dropped. |
| 4 Sources | Plan and trust fees source from the 47 Fee Invoice or Account Fee Calculation (16 and 51 are terms); 47 Fee Debit and Fee Adjustment added; Gross Fee Revenue and Applied Gross Fee Rate are Derived copies of the 27 Fund Expense Accrual; fully paid lending firm share derived from 49 loan data meanwhile (49 merge edit in NOTES); the note names 50 Program Bank Daily Total; Program Bank Fee Earned computed here with its inputs declared (50 daily totals, Sweep Allocation, 39 program bank agreement); Net Spread defined from held figures; Scenario Base Date added. |
| 5 Grain and copies | Client Revenue Record grain account x revenue stream x month, Source Calculation Record multi-valued; household rows key on the 47 Fee Household, plan-paid rows on the 16 Service Arrangement; Revenue Business Line added as a Derived copy of 06 Account Channel Assignment.Assigned Business Line; Contract Inception Date, Termination Notice Period, Funding Source, Adviser-Borne Amount and Average AUM Reference given row rules (default owners corrected); row rules added for Target Dimension Member, Leaf Member, Plan Dimension Members and Priced Subject; underwriting rows of Underlying Agreement point to 35; TP Documentation link held on the 10 side (19 back-link merge note). |
| 6 Cost to serve | Coverage and Servicing Cost is the Advice component; Client Service Cost (Service) and Money Movement Cost added; Clearing & Client Asset Custody Cost split out; six components stored; Partner Payments Cost removed (duplicate of Distribution Payments; pending readers DP-034, DP-035). |
| 7 Fidelity | Performance Obligation.Stream Principal vs Agent Conclusion added (sub-advised fund fees gross by default); Crystallization Date primary Rule 205-2, secondary 205-3; Elimination Indicator cites Treas. Reg. section 1.1502-13; SME question 10 retired; Performance Fee Terms Reference points to the 47 Fee Schedule on mandate rows. |
| 8 Registers | Accounting Basis members tuple change stated; Source Domain adds 19, 20, 49, 52 and drops 12; CONCEPT_OWNERSHIP proposals corrected (no Hierarchy Node row; new Management Hierarchy Node row; re-cuts of Fee Revenue Record, Fee Invoice, Incentive Compensation Plan, Compensation Statement, Territory, Sales Activity, Sales Forecast, Fee Schedule / Fee Terms); Channel and Household term conflicts added; READERS completed. |
| Lows applied | Sub-Adviser Engagement fee terms in 35; Revenue Share Class / Mandate typed Share Class; Fund Expense Above Cap limited to unreimbursed amounts; Distribution Payments authoritative; Sub-Advisory Fee Payable worded as expense and tied to the 'Sub-Advisory Fees' cost item; examples aligned (FSCH-04512-02, FSCH-08811-02, COFF component 'Advisory Fee Rate', 'US Local File FY2025', one period on cost items); Funding Source list 05 DI; Client Segment names the designated scheme; PII notes on household amounts; Household Acquisition Channel mastered with a derivation rule; Retirement Plan profitability dimension; Order Routing Payment firm-level; Sub-Advisory Fee Received stream; Cost Item Category boundaries; 'Clearing, Client Asset Custody & Operations'; Revenue Service Offering a CDE; Dimension Grain note; money market sweep fund named as the default sweep vehicle; KEY_FORMATS for Distribution Revenue Record, Adviser-Borne Cost and Control; 19 REL 488 and 47 REL 451 merge notes; stale NOTES statements corrected. |
| Lows skipped | Cohort Month on Client Lifetime Value Estimate and funded account counts on the acquisition record: not added, to hold the band (listed as deviations; the cohort is reached through the household's first funded account). |
