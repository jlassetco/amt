# Source Notes: 11 Market & Competitive Intelligence (Draft v0.1, 2026-10-15)

Workbook: `Market_and_Competitive_Intelligence_Data_Taxonomy.xlsx` (name and folder unchanged). Content module: `_tools/content/content_11_market_and_competitive_intelligence.py` (adapted in place, CW-013, CW-160). Enrichment: `_tools/enrichment/enrich_11.py` (rewritten). Proposals: `_tools/consolidation/proposals_w4_11.py` (JURISDICTION, CW-911, shared memberships and value maps, repoints, readers).

Size (built, after the review fix pass of section 8): 11 families, 36 objects (27 business objects, 9 attribute groups), 260 attributes, 91 CDEs (35%), 52 code lists (40 local, 12 local copies of shared or to-be-shared lists), 47 relationships, 24 sources. Ownership: 28 references, 10 derived copies, 5 row rules, 0 unresolved. Wholesale baseline (built, Record Metadata excluded): 10 families, 34 objects (8 attribute groups), 239 attributes, 80 CDEs, 50 code lists, 33 relationships, 23 sources.

**Perspective.** Wealth manager (direct) | Scope: US. A hypothetical US wealth manager of the Vanguard type: direct brokerage and self-directed investing, digital and human advice, proprietary funds and ETFs, workplace recordkeeping, institutional advisory, a thin intermediary channel and optional personal trust services (business lines DB, DA, HA, PF, WR, IA, IC, TR; CW-004). Its competitors are other brokerages, robo and hybrid advisers, wirehouses, RIA aggregators, recordkeepers, fund and ETF sponsors, bank wealth managers and trust companies. Every competitor and individual in an example is hypothetical (Northbridge Brokerage, Example Digital Advisers, Example Global Investors).

## 0. Why this domain exists, and what the adaptation changed

Strategy, product and pricing teams need to know where industry flows and household assets are going, the firm's share of them by channel and segment, what competitors offer and charge (advisory fee rates, subscription fees, commissions, options contract fees, account service fees, margin rates, cash sweep yields, expense ratios), how the firm's funds compare with their peers on performance, fees and ratings, how big each investor segment and plan market is, and what is changing in the market and in regulation. The data is licensed or public, arrives in releases that are restated, and never describes the firm's own clients: the firm's values appear only as Derived copies of 06 (certified measures), 01 (fund expense terms) or 47 (fee schedules), with their as-of dates (CW-160).

This is an adaptation. Kept objects keep their names so that the live products DP-014, DP-105, DP-109, DP-159, DP-183, DP-223, DP-236 and DP-248 and the carried text in 36, 38 and 42 resolve unchanged (checked by script against every 11 read in `data_products/specs_*.py`). Family codes are kept except MI-DMM, which becomes MI-SRC.

| Wholesale object | Disposition | What changed |
|---|---|---|
| Industry Dataset Profile, Industry Data Release, Industry Flow Observation, Category Mapping | Kept | EFAMA and IA references and values removed (section 7); Coverage Basis re-cut; Distribution Channel uses Industry Channel re-cut to the CW-164 / CW-140 values; Distributor Firm re-typed to 05 (CW-132); US examples |
| Market Share Definition, Market Share Record | Kept | Numerator Source '06 Certified Measure'; Firm Value a Derived copy of 06 with a row rule; Share Measure Basis adds Net New Assets and Client Count; Share Dimension adds Wealth Band and Investor Segment; Distributor Firm re-typed to 05 |
| Industry Ranking | Kept, now an attribute group of Market Share Record | Brief section 5 |
| Competitor Profile | Kept, re-cut | Competitor Type re-cut to the wealth competitor set; Headquarters Country removed (read from 02) |
| Competitor Metric Snapshot | Kept, re-cut | Adds Reported Client Assets, Reported Net New Assets, Client Account Count, Advisor Count |
| Competitor Distribution Footprint | Kept, re-cut | Channel presence only (grain competitor x channel); Market removed (CW-911); Estimated Wholesaler Headcount renamed Estimated Advisor Headcount; Key Distribution Partners re-typed to 05 |
| Competitor Offering (`COFF-`), Competitor Pricing Observation | Added (CW-160) | Offering: type, contested business line, minimum, features, comparable own offering, status. Pricing: offering x price component x as-of (x balance tier), rate or amount, quote basis, source type and document |
| Competitor Event, Competitor Personnel Move | Kept | Event types add Pricing Change, Program Launch, Feature Launch, Cash Yield Change; roles drop Senior Wholesaler and add Head of Wealth / Advice and Head of Digital; Personnel Move is PII - identity |
| Peer Universe, Peer Universe Member, Peer Fund | Kept | US examples; ISIN and Domicile stay for peers of international funds |
| Peer Metric Snapshot | Kept, now a business object | Snapshot Subject (peer fund or own share class) added as key part; Expense Ratio is the Form N-1A net expense ratio |
| Rating Scheme, Rating Observation, Medalist Rating Detail, Sustainability Rating Detail, Award | Kept | FE fundinfo and Citywire schemes and scale values removed; Rated Object Type 'Fund Manager' becomes 'Service Offering'; Peer Group Basis removed (held per observation); Award Recipient drops the manager party and adds Service Offering |
| Manager Rating | Removed | Citywire (CW-911); lever restores |
| Fee Benchmark Study | Kept, re-cut | Subject Share Class kept by name (DP-109, DP-183); adds Subject Service Offering (01), Subject Fee Schedule (47) and Comparison Offerings (COFF-); Fee Measure and Study Purpose re-cut to US measures |
| Fee Benchmark Result, Pricing Input | Kept | Own Fee Rate a Derived copy of 01 or 47 (row rule); Asset-Weighted Peer Average Fee removed; Pricing Input read by 10 Pricing Scenario and 36 (CW-158) |
| Market Sizing Record | Kept, re-cut | Adds Wealth Band, Age Band and Mapped Firm Segment (02 scheme value); Projection Indicator removed; subject types and metrics re-cut to households, advice, participants and rollovers |
| Opportunity Potential | Kept (thin, IC) | Practice AUM Input and Potential Score removed; Firm Assets with Party a Derived copy of the 06 intermediary-held measure |
| Plan Market Record | Kept | DCIO Opportunity Value renamed Recordkeeping Opportunity Value (CW-139); Participant Count added |
| Market Research Report, Market Trend, Mandate Search Event, Win/Loss Analysis | Kept | Consultant and Linked Opportunity re-typed to 05 (CW-170); win/loss reads the 05 Win / Loss |
| Intelligence Item | Kept | Source Name removed (Source Type kept); Linked Own Products adds Service Offering |
| Regulatory Horizon Item | Kept as a business object at regulator x initiative (fix pass; the brief made it an attribute group) | Regulatory Body joins the shared Regulator US labels; Initiative Source Type and Source Intelligence Items added; Regulatory Stage re-cut to US rulemaking stages |
| Record Metadata | Dropped (CD-160) | Source Vendor Dataset and Redistribution Permitted Indicator re-cut into Redistribution Restriction (family Data Sourcing Controls, MI-SRC) |

## 1. Sources consulted

| Source | URL | What was taken |
|---|---|---|
| ICI weekly estimated flows and ETF net issuance; ICI Monthly Trends | https://www.ici.org/research/stats/flows; https://www.ici.org/monthly-trends-in-mutual-fund-investing | Weekly estimates revised in later weeks; monthly reported sales, redemptions and net new cash flow; reinvested dividends excluded. Flow Estimation Method, Revision Policy, Data Release |
| ICI Investment Company Fact Book | https://www.icifactbook.org | Annual US fund assets, flows and household ownership. Market sizing and trends |
| Federal Reserve Survey of Consumer Finances | https://www.federalreserve.gov/econres/scfindex.htm | Household assets by wealth and age group (age of family head bands). Wealth Band, Age Band, Investable Household Assets |
| Financial Accounts of the United States (Z.1) | https://www.federalreserve.gov/releases/z1/ | Household financial assets by instrument. Total market sizing |
| Morningstar Estimated Net Cash Flow, Star Rating, Medalist Rating (April 2026), Sustainability Rating methodologies | See the Sources tab | Flow estimation, rating schemes, pillars, price score, globes |
| LSEG Lipper Leaders methodology | https://lipperleaders.com/documents/LipperLeaders_Methodology_Intl.pdf | Measures (Tax Efficiency for US funds), quintile scores, periods; replaces FE fundinfo as secondary reference |
| ISS Market Intelligence Simfund; Broadridge; Cerulli; Nasdaq eVestment; Discovery Data | vendor sites | Dataset structure only (no vendor data reproduced) |
| SEC Form ADV and IAPD (Part 1A Item 5.F, Part 2A and Appendix 1 wrap fee brochure) | https://adviserinfo.sec.gov | Competitor regulatory AUM, advisor counts and advisory fee schedules; Price Source Type |
| SEC Form CRS | https://www.sec.gov/files/formcrs.pdf | Relationship and service types and fee summaries of competing broker-dealers and advisers; Competitor Offering Type |
| FINRA BrokerCheck; FINRA Industry Snapshot | https://brokercheck.finra.org | Registered representative counts; Advisor Count, Estimated Advisor Headcount |
| SEC Form N-1A fee table (Item 3) | https://www.sec.gov/files/formn-1a.pdf | Net and gross expense ratio; replaces the Ongoing Charges Figure |
| Investment Company Act Section 15(c) | https://www.law.cornell.edu/uscode/text/15/80a-15 | Board approval of advisory contracts, informed by fee comparisons; replaces the FCA Assessment of Value as the fee study basis |
| SEC Marketing Rule 206(4)-1 | https://www.ecfr.gov/current/title-17/section-275.206(4)-1 | Third-party rating citation conditions; Paid to Participate Indicator, Redistribution Permitted Indicator |
| DOL Form 5500 datasets (EFAST2) | https://www.dol.gov/agencies/ebsa/about-ebsa/our-activities/public-disclosure/foia/form-5500-datasets | Plan Market Record (Schedule H assets, Schedule C service providers, participant counts) |

## 2. Design and boundary decisions

- **Market, not the firm (CW-160).** The three places the firm's own value appears are Derived copies with a row rule where needed: Market Share Record.Firm Value (06 certified measure or the same industry dataset), Fee Benchmark Result.Own Fee Rate (01 share class or 47 fee schedule) and Opportunity Potential.Firm Assets with Party (06). Competitor figures are prefixed 'Reported' and are on the competitor's own definitions, never the 06 Client Assets measure.
- **Competitor Offering and Competitor Pricing Observation (CW-160, CW-158).** The offering is keyed `COFF-` and points at the competitor profile and the comparable own Service Offering (01). A pricing observation is one price component of one offering as of a date, with either a rate or an amount, the unit it is quoted in, the balance tier and the document it was captured from. 10 Pricing Scenario and 36 Business Case Market Evidence read it; 47 keeps the firm's own schedule. Promotions are recorded in the source document reference rather than a separate flag (attribute budget).
- **Fee studies extend to advice programs.** A fee study has a share class subject (fund) or a service offering subject with its 47 fee schedule version, compared with a peer universe (funds) or a set of competitor offerings (programs). Subject Share Class keeps its name for DP-109 and DP-183 (deviation from the brief, which renamed it to 'Subject').
- **Peer data is not due diligence.** A third-party fund on the platform is vetted in 52; 11 holds only its peer metrics (REL to 52).
- **Competitors and individuals are 02 parties (CD-143).** Competitor Display Name is a Derived copy of the 02 name kept for DP-014; Headquarters Country is no longer copied.
- **Restored 05 objects (CW-132, CW-134, CW-170).** Distributor Firm (Industry Flow Observation, Market Share Record, Footprint Key Distribution Partners), Consultant Profile (Mandate Search Event.Consultant) and Sales Opportunity (Linked Opportunity, Win/Loss Analysis) are typed with the 05 object names and forced to 05 in OWNERSHIP_OVERRIDES until the register moves OPP- and the profiles to 05. Asset Owner stays a 02 party (an asset owner running a search need not be a client; not re-pointed to 12 Institutional Client). Opportunity Potential.Target Party stays a 02 party holding a 05 role.
- **07 and 30 retirement (W4 retirement brief section 5).** The REL 'Market Sizing Record feeds Territory Potential Metric (07)' and every 07 mention in META and the MI-MSZ definition are removed (CW-907). There was no 30 reference; 'Private Markets in Wealth' stays as a market topic.
- **Kinds.** Industry Ranking becomes an attribute group of Market Share Record and Peer Metric Snapshot a business object with Snapshot Subject, per the brief; Regulatory Horizon Item stays a business object at regulator x initiative (fix-pass ruling 4, deviation from the brief). The keys file and the logical models that key them differently are listed in proposals NOTES.
- **Horizon versus change.** The Regulatory Horizon Item tracks an initiative in the market; 38 Regulatory Change Item manages the firm's implementation and cites it (REL).
- **Redistribution Restriction.** License terms stay 14; 11 keeps the one use flag the Marketing Rule citation check needs, as an attribute group of the dataset profile.
- **Attribute budget.** To stay at 260 attributes the draft folds delivery mode into Competitor Offering Type, records launches as Competitor Events, and removes attributes read only by pending products (Practice AUM Input, Potential Score, Projection Indicator, Peer Group Basis, Asset-Weighted Peer Average Fee, Source Name, Headquarters Country). Every attribute a live product reads is kept.

## 3. Unverified items (confirm)

- Cerulli report titles and channel definitions (vendor site, licensed); only the structure is used.
- Morningstar US Fund Fee Study: the landing-page URL (cited as morningstar.com, confirm page).
- Lipper Leaders Tax Efficiency: cited from the international methodology; confirm against the US document.
- Morningstar Medalist April 2026 methodology: pillar labels and the -2.5 to +2.5 price score (carried from the wholesale notes).
- Wealth Band now uses the 02 Net Worth Band boundaries (the SCF publishes percentile groups of net worth, not dollar bands); Age Band is cited External (Federal Reserve SCF age-of-family-head groups, verified by the reviewer).
- Form ADV Part 2A Appendix 1 item numbers cited in the example Source Document Reference.
- Closed in the fix pass: FINRA 2026 Industry Snapshot (published June 2026, URL in SRC); Regulation S-P amendment compliance dates (2025-12-03 larger, 2026-06-03 smaller entities); Form CRS covers broker-dealers (formcrs.pdf) and advisers (Form ADV Part 3, added).
- The Data Provider value FEDERAL_RESERVE is a proposal for steward 14.

## 4. SME questions (tailoring levers; reference default in brackets)

1. Competitor set. [Direct brokerages, digital and hybrid advisers, wirehouses, RIA aggregators, recordkeepers, fund and ETF sponsors, bank wealth managers, trust companies and OCIO providers, as 02 parties with hypothetical names.] Lever: a narrower set for a firm without workplace business.
2. Price observation sources and cadence. [Public schedules and disclosure documents (Form ADV Part 2A and Appendix 1, Form CRS and Form ADV Part 3, fee schedules, prospectus fee tables), captured monthly, plus event-triggered capture: a Competitor Event 'Cash Yield Change' or 'Pricing Change' starts a new observation the same day, because sweep yields move with rates between monthly runs.] Lever: a vendor pricing dataset (Pricing Source Type 'Vendor Pricing Dataset').
3. Cash sweep yield as competitor pricing. [Yes, Price Component 'Cash Sweep Yield'.] Lever: drop the value if cash is not a pricing lever.
4. Advisor-channel depth. [Opportunity Potential for intermediary firms only (05 Distributor Firm role), No PII, no advisor-level wallet share or potential score.] Lever: restore advisor-level potential from the sibling, which makes the object PII - identity.
9. Offering channel. [No channel on Competitor Offering; the competitor's channels are read from Competitor Distribution Footprint.] Lever: add 'Offering Channel' (Industry Channel) for TR and IA offerings sold through intermediaries.
5. Consultant databases. [IA mandate searches only.] Lever: drop Mandate Search Event with IA.
6. Investor segment scheme for sizing. [Wealth band x age band, mapped to 02 segment scheme values.] Lever: a life-stage scheme.
7. Personnel moves. [Executives and portfolio managers of competitors, PII - identity.] Lever: drop the object for privacy.
8. Market share numerator. [06 certified measures for channel and segment share; the same industry dataset for fund category share.] Lever: same-source numerators everywhere.

## 5. Overlaps with other domains (for consolidation)

- 05: Distributor Firm, Consultant Profile, Sales Opportunity and Win / Loss resolve against the 05 module (CW-132, CW-134). 05 Win / Loss.Winning Competitor is Reference (Party); 11 aggregates by Competitor Profile (note for 05 at merge).
- 06: content_06 Measure Category value 'Market Share' should be dropped or defined as an input to 11 (market share is mastered here).
- 06: MSR- measures and the intermediary-held own-fund measure assumed from the 06 brief; LOAD- stays 06.
- 10 and 36: read Competitor Pricing Observation (composite key COFF- / Price Component / Observation As-of Date), Fee Benchmark Result, Pricing Input and Market Sizing Record.
- 38: Regulatory Change Item.Source Horizon Item resolves to the kept Regulatory Horizon Item.
- 14: dataset catalog and license; Data Provider gains FEDERAL_RESERVE (proposed).
- Shared-list candidates: Price Component (with 47 and 10), Wealth Band and Age Band (with 02 and 06), Competitor Offering Type (with 01 Offering Type).

## 6. Suggested validation steps

1. Walk one advice program end to end: Competitor Offering -> Pricing Observations -> Fee Benchmark Study (Subject Service Offering, Comparison Offerings) -> Result -> Pricing Input -> 10 Pricing Scenario.
2. Walk one fund category: Dataset -> Release -> Flow Observation -> Category Mapping -> Market Share Record with a 06 numerator -> Peer Universe -> Rating Observation -> Fee study.
3. Confirm with 06 that the numerator measures and as-of dates match the Firm Value row rule.
4. Re-run the reader check after the 05 and 06 drafts land.

## 7. Wealth model adaptation (W4) and US-only pass (CW-911)

Removed under CW-911 (67 JURISDICTION entries in `proposals_w4_11.py`: 1 object, 1 attribute, 36 code values, 24 re-sourced references and examples, 5 sources): object Manager Rating; attribute Competitor Distribution Footprint.Market; Industry Data Provider EFAMA, Investment Association, FE fundinfo, Citywire; Category Scheme EFAMA EFC, IA Sector; Industry Vehicle Type UCITS, AIF; Industry Channel UK Platform, UK IFA / Wealth Manager / DFM, EU Private Bank, EU Retail Bank Network, EU Fund Platform; Regulatory Body UK FCA, ESMA, European Commission, CSSF, Central Bank of Ireland, BaFin; Rating Scheme FE fundinfo Crown Rating and Citywire Manager Rating with their scale values; Fee Measure Ongoing Charges Figure and PRIIPs Total Costs; Fee Study Purpose Assessment of Value; Coverage Basis Country of Sale; Sizing Unit EUR and GBP; sources EFAMA, Investment Association, FE fundinfo, Citywire and FCA COLL 6.6.20R / Consumer Duty. Re-sourced: dataset and observation references to ICI, Morningstar, LSEG Lipper and ISS Market Intelligence; fee measures to Form N-1A; fee study purpose to Investment Company Act Section 15(c); award citation to SEC Marketing Rule 206(4)-1; horizon scanning to the US regulators and rulemaking stages; examples to US values. Kept: Morningstar Global Category, Lipper Global Classification, Peer Fund ISIN and Domicile (peers of the firm's international funds). Also dropped (not jurisdiction): Record Metadata (CD-160) with its DCAM source and its Data Classification and Data Quality Status lists.

## 8. Review fix pass (00_Program/Rework/Reviews/11_review.md; program-lead rulings, 2026-10-15)

Before: 11 families, 36 objects (26 BO, 10 AG), 260 attributes, 81 CDEs, 29 references, 9 derived, 60 code lists, 46 relationships, 23 sources. After: 11 families, 36 objects (27 BO, 9 AG), 260 attributes, 91 CDEs (35%), 28 references, 10 derived, 5 row rules, 52 code lists, 47 relationships, 24 sources; 0 unresolved.

1. **Peer Metric Snapshot (High).** Own share class rows copy Expense Ratio from the 01 Net Expense Ratio and Total Return from the 32 Performance Return; peer fund rows stay mastered here from the vendor dataset; Estimated Net Flow is the vendor estimate on every row. Recorded as ROW_OWNERSHIP rules; the attribute flag stays "Mastered here" because the builder holds one flag per attribute and peer rows are the majority.
2. **Fee statistics.** Fee Benchmark Study.Measure Unit (local copy of the 22 Measure Unit: Percent, Basis Points, Currency Amount) gives the unit of every Fee Benchmark Result and Pricing Input statistic, now typed Decimal; Fee Benchmark Result.Reference Balance states the balance for tiered schedules.
3. **Pricing key.** Balance Tier became Balance Tier Lower Bound (Amount, CDE), part of the key only when the price is tiered. 'Advisory Fee Rate' was already a Price Component value; the key format is published in proposals KEY_FORMATS and the 10 and 36 example keys are corrected in NOTES for their owners.
4. **Grain and CDEs.** Regulatory Horizon Item stays a business object at regulator x initiative (readers win over the brief's table; deviation recorded), with Source Intelligence Items. Flagged Firm Value, Industry Value, Own Fee Rate, Balance Tier Lower Bound, Subject Service Offering and the keys named by the review; unflagged Relevance Rating and Fee Competitiveness Assessment, and, to stay at 35%, Analyst-Driven Percentage, Reported Client Assets, Indicator As-of Date and Competitor Offering Type. Vendor Manager Identifiers keeps vendor codes (mastered here); Regulatory Identifiers (Derived 02) holds CRD and SEC numbers. Mapped Firm Segment values name their 02 scheme ("Wealth Tier: Mass Affluent"). Wealth Band adopts the 02 Net Worth Band boundaries; the 02 top-band split is proposed in SHARED_CANDIDATES for steward 02 at W5. Opportunity Potential is firm-only, No PII.
5. **Readers and overrides.** NOTES adds the models_c2, sm_06, sm_08 and keys_g5 lines and the key rows of the new objects; the override claim is corrected (the four PTY-keyed overrides are permanent).
6. **Sources and lists.** FINRA 2026 Industry Snapshot and Form ADV Part 3 added, Morningstar US Fund Fee Study cited; Sizing Unit, Reinvestment Treatment and Rating Basis dropped (Reinvested Distribution Treatment kept as a Boolean for DP-014); Age Band, Rating Value, Medalist Pillar Score, Lipper Leaders Measure, Rating Time Period and Search Event Type cited External. The local list count falls to 40, below the brief's 45-52, as a consequence of this ruling. The Coverage Basis LOCAL_RENAMES name becomes 'Industry Data Attribution Basis'; the Price Quote Basis clash with 22 is a TERM_CONFLICT. The offering channel attribute does not fit within 260: recorded as a lever (section 4, question 9).
7. **Lever.** Event-triggered price capture through the 'Cash Yield Change' event (section 4, question 2).
8. **Lows applied:** code-list description re-sourcings registered (4 CW-911 entries, 71 in all); Own Fee Rate notes say "01 or 47 per row rule"; Industry Ranking.Ranking Basis and Redistribution Restriction.Source Vendor Dataset removed; Category / Segment and Mandate Asset Class typed Code; Top Loss Reasons typed Code (multi) on the 05 Win Loss Reason list and Opportunities Decided declared Derived (05); PTY- examples cut to 6 digits and MSHD- examples fitted to the registered format; PII added to every Personnel Move attribute; Plan Party typed Reference (Retirement Plan); Subject Fee Schedule must be linked to the Subject Service Offering; Competitor Offering Type adds Institutional / OCIO; the three REL rows aligned with the attributes; the 06 Market Share residue and the 05 Winning Competitor type noted for their owners; the Distribution Channel new_values note added. **Skipped:** none.
