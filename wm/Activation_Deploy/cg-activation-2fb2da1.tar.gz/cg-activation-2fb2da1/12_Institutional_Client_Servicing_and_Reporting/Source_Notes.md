# Source Notes: 12 Institutional Client Servicing & Reporting (Draft v0.1, 2026-10-14; 12 fix pass 2026-10-15)

Wealth-manager reference model, W4 adaptation (CW-145). Workbook: `Institutional_Client_Servicing_and_Reporting_Data_Taxonomy.xlsx`. Content module: `_tools/content/content_12_institutional_client_servicing_and_reporting.py` (edited in place). Enrichment: `_tools/enrichment/enrich_12.py`. Proposals: `_tools/consolidation/proposals_w4_12.py`. The wholesale version stays at tag wholesale-v1.0.

Size after the 12 fix pass: 10 families, 33 objects (29 Business Objects, 4 Attribute Groups), 250 attributes, 87 CDEs (35%), 51 code lists (37 local, 14 local copies of shared lists), 55 relationships, 19 sources; 61 references, 6 derived copies, 0 unresolved. Draft v0.1 had 28 Business Objects, 5 Attribute Groups, 83 CDEs, 54 relationships and 17 sources. Wholesale before: 10 families, 36 objects, 236 attributes, 75 CDEs, 52 code lists, 37 relationships, 15 sources.

## 1. Why this domain exists

The firm is a US wealth manager that serves investors directly (plan section 2). Two of its eight business lines have institutional relationships that need a servicing record no other domain holds. The registered investment adviser is the OCIO and institutional manager for endowments, foundations, pensions, health systems and other asset owners (IA). The recordkeeper administers workplace plans and services their sponsors (WR). 01 holds the mandate and its guidelines, 16 the plan, 18 and 32 the portfolio and its returns, 33 the breach and 47 the fees. 12 holds what the firm has promised each relationship and what it has delivered: who services it, the client's investment policy, the reports and their delivery, breach notices to the client, requests and cash-flow instructions, reviews, new-mandate set-up and termination. The wholesale 12 also serviced sub-advisory, DCIO and model-sponsor clients and billed mandates. Those left: sub-advisory and DCIO are out of the reference scope, sponsors and consultants are 05, and billing is 47. For the PF line, institutions in the firm's funds and CITs (including plans that hold the CITs on another recordkeeper, segment "Plan Sponsor - CIT Only") are served with the "Pooled Fund or CIT" report scope level and the Consultant Data Pack; no separate CIT unit report is needed.

## 2. Sources

| Source | URL | What it gave us |
|---|---|---|
| GIPS Standards for Firms (2020) | https://www.gipsstandards.org/standards/gips-standards-for-firms/ | GIPS Report types, required numerical information and disclosures, the 12-month update rule, gross and net presentation (kept from the wholesale notes) |
| SEC Marketing Rule 206(4)-1; Rule 204-2 | https://www.sec.gov/rules-regulations/2020/12/investment-adviser-marketing | Gross and net presentation, extracted and hypothetical performance (Compliance Review on Report Run); books and records retention (Records Retention End Date, Sign-Off Timestamp) |
| Advisers Act Rule 206(4)-5 | https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.206(4)-5 (confirm path) | Government entity definition (Institutional Client.Government Entity Indicator) |
| Advisers Act Rule 206(4)-2 | https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.206(4)-2 (confirm path) | Qualified custodian statements; Reporting Driver value (confirm current status: the 2023 safeguarding proposal was withdrawn on 2025-06-12) |
| ERISA sections 3(21) and 3(38), 29 U.S.C. 1002 | https://www.law.cornell.edu/uscode/text/29/1002 | Fiduciary and investment manager definitions (ERISA Fiduciary Status, ERISA Plan Indicator) |
| DOL 29 CFR 2550.408b-2 | https://www.law.cornell.edu/cfr/text/29/2550.408b-2 | Sponsor fee disclosures: 16 and 47 own them; 12 reports and reviews around them |
| Uniform Prudent Management of Institutional Funds Act | https://www.uniformlaws.org (confirm page) | Prudence standard for charitable funds (UPMIFA Applicability Indicator; secondary on Spending Policy Method and Spending Rate, which are firm-defined; IRC section 4942 sets the 5% minimum for private foundations) |
| CFA Institute, Elements of an Investment Policy Statement for Institutional Investors | https://www.cfainstitute.org (confirm page) | IPS content: objectives, risk and liquidity constraints, governance, review |
| Advisers Act Rule 206(4)-6 and Rule 204-2(c)(2) | https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.206(4)-6 (confirm path) | Adviser proxy voting policies, disclosure to clients of how to obtain their voting records, records: the source of Stewardship Report Scope for separate accounts and OCIO portfolios |
| Exchange Act Rule 14Ad-1 | https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.14Ad-1 (confirm path) | Say-on-pay votes reported by the firm as a Form 13F manager on its own Form N-PX (first filings due August 31, 2024) |
| SEC Form N-PX | https://www.sec.gov/files/formn-px.pdf (the review confirmed it resolves: the amended form, 2024) | Fund proxy voting record, for pooled vehicles only; also the form for the manager's say-on-pay report |
| SEC Form N-1A Item 16(f) and Form N-PORT | https://www.sec.gov/files/formn-1a.pdf (confirm path) | The fund's portfolio holdings disclosure policy (Item 16(f), in the SAI) sets Portfolio Holdings Disclosure Lag Days; N-PORT gives the public timing (2024 amendments, compliance dates extended; confirm) |
| Regulation S-ID | https://www.ecfr.gov/current/title-17/chapter-II/part-248/subpart-C (confirm path) | Secondary only: the call-back is firm policy; S-ID applies to institutional accounts only where the firm's program designates them covered accounts |
| AICPA SSAE 18 / SOC 1 | https://www.aicpa-cima.com (confirm page) | SOC 1 Report Request service request type |
| SWIFT ISO 15022 and ISO 20022 | https://www.swift.com/standards/iso-15022 | Safekeeping account and settlement messages (market-neutral, kept) |
| ISO 9362, 4217, 639, 8601 | https://www.iso.org | Reference formats (kept) |
| Salesforce Service Cloud Case object | https://developer.salesforce.com/docs/atlas.en-us.object_reference.meta/object_reference/sforce_api_objects_case.htm (confirm path) | Case status and SLA fields |
| ITIL 4 Service Level Management | https://www.axelos.com | Service standards |
| SEC Form ADV Part 1A | https://www.sec.gov/about/forms/formadv-part1a.pdf (confirm path) | Item 5.D client types behind Institutional Client Type |

Removed with the US-only pass (CW-912): CTI templates, MiFID II Delegated Regulation 2017/565 Arts 60-62, FCA COBS 16A and SYSC 9, UK Stewardship Code 2026, Solvency II TPT, ESMA performance fee guidelines. Removed for other reasons: ILPA templates (private funds out of scope, CW-016), Net Promoter System (surveys are 04, CW-093), DCAM (Record Metadata, CD-160).

## 3. Wholesale objects: dropped, kept, re-cut and moved

| Wholesale object | Disposition | What changed |
|---|---|---|
| Service Relationship | Kept, re-cut | Client typed Reference (Institutional Client, 12); Serviced Pooled Holdings renamed Serviced Pooled Vehicles (12 fix pass); Servicing Segment re-cut to OCIO, Institutional Separate Account, Institutional Pooled (Fund or CIT), Plan Sponsor - Recordkept, Plan Sponsor - CIT Only; Advising Consultant references 05 Consultant Advisory Relationship; Relationship Business Line and Relationship Start Date added; servicing legal entity rewritten to US entities |
| Service Tier | Renamed Institutional Service Tier | 01 Service Tier is the retail tier (CW-028). Attributes unchanged (Service Tier Code kept for readers) |
| Service Standard, Service Team, Service Coverage Assignment | Kept | Service Role loses Relationship Manager (03, CW-138) and Billing Analyst (47); adds OCIO Client Strategist and Plan Sponsor Service Manager; SVT-INST-02 |
| Report Definition, Report Component, Report Template, Report Package | Kept | Regulatory Driver re-cut; Stewardship Report Scope moved here; languages en and es; Report Package gains Covered Retirement Plans; Covered Mandates / Holdings renamed Covered Mandates / Vehicles (12 fix pass) |
| Presentation Profile, Portfolio Holdings Presentation, GIPS Report Provision | Kept | Look-Through Template re-cut; USD examples |
| Template Adoption | Dropped | ILPA (CW-016), UK CTI and MiFID ex-post costs (CW-912); Stewardship Report Scope moved to Report Definition |
| Report Schedule, Report Run, Distribution List, Report Delivery | Kept | CAL-US-NYSE, US time zones, CTP- contact point example |
| Guideline Monitoring Arrangement, Breach Notification, Compliance Certificate | Kept | Breach facts stay Derived copies of 33 (CD-222); Compliance Certificate gains Certified Mandate |
| Depreciation Notification | Dropped | MiFID II / COBS 16A (CW-912) |
| Client Service Request, Cash Flow Notification | Kept | Request types re-cut; Related Complaint to 08; USD example |
| Client Review, Relationship Health Score | Kept | Review types add Plan Fiduciary Committee Review and IPS Review; Reviewed IPS Version and Survey Inputs (04) added; meeting is a 03 Advisor Activity |
| Client Feedback Response | Dropped | 04 Client Survey and Survey Response (CW-093); CFS- retired |
| Custody Account, Cash Flow Arrangement, Client Data Feed, Transition Event | Kept; Custody Account renamed Client Custodian Account (12 fix pass) | Client Account is a 15 account; Custody Mandate renamed Client Custodian Mandate; America/New_York example; Transition Event gains Transition Total Cost (aggregate; 25 TCA read, not copied) |
| Billing Arrangement, Fee Invoice, Performance Fee Calculation, Fee Adjustment, Billing Dispute | Moved to 47 | With names and prefixes (CW-012, CW-054); lists Billing Basis, Fee Collection Method, Payment Status, Fee Adjustment Type, Dispute Reason removed here; EU/UK examples recorded under CW-912 |
| Mandate Termination | Kept | Final Invoice is Reference (Fee Invoice, 47); retention to SEC Rule 204-2 |
| Record Metadata | Dropped | CD-160 |
| 02 Institutional Client | Restored here, name unchanged (CW-133) | BO keyed by Institutional Client Party (PTY-); the seven wholesale attributes kept by name, plus Primary Business Line, Funded Status As-Of Date, UPMIFA Applicability Indicator, Fiscal Year End |

New: Investment Policy Statement (IPSV-), OCIO Service Detail (attribute group), Plan Sponsor Servicing Detail (Business Object keyed SVR- / plan PTY-, one row per plan of a sponsor relationship), Mandate Onboarding (key MND- / onboarding start date).

## 4. Modeling decisions

- **Profile here, party core in 02 (CW-023, CW-133).** Institutional Client is a Business Object, not an attribute group, because an attribute group cannot have a parent in another domain (enrichment contract). The key is the Institutional Client Party reference. References to the profile from 12 carry the PTY- example and are forced "mastered here" in OWNERSHIP_OVERRIDES. The wholesale attribute values were recovered from the compiled wholesale 02 module (as the channel briefs did); the program lead confirms against tag wholesale-v1.0.
- **Which party holds the profile.** The Institutional Client profile sits on the asset-owning party: the plan trust for a defined benefit, public or Taft-Hartley plan (so Funded Status is a fact of that party), the institution itself for an endowment, foundation, health system or insurer, and the employer for DC plan sponsor servicing. A corporation with a DB OCIO mandate and a recordkept 401(k) therefore has two profiles on two parties (the DB plan trust, type Corporate DB Plan; the employer, type Corporate DC Plan Sponsor). Relabeled Institutional Client Type values have an old-to-new map in proposals REPOINTS.
- **Plan sponsors are Institutional Clients too.** Institutional Client Type has "Corporate DC Plan Sponsor", so one Service Relationship model covers OCIO, mandate and sponsor clients. 16 keeps the Plan Sponsor Profile (sponsor facts) and the plan; 12's Plan Sponsor Servicing Detail (one row per plan) references the plan, the 16 recordkeeping Service Arrangement and the fiduciary committee's 16 Plan Role Assignment (CW-146); 16 adds the "Plan Fiduciary Committee" role value. ERISA fiduciary status of a recordkept plan is mastered on the 16 role assignment; OCIO Service Detail's value must agree with it.
- **OCIO (CW-147).** 12 masters the IPS versions and the OCIO Service Detail. The IPS references the 24 Asset Allocation Policy in its key form "<policy subject> v<n>" (example MND-01234 v3, forced to 24); 24 adds a client or mandate subject at its fix pass. The 52 managers are referenced as Sub-Adviser Engagements (SADV-): the 52 brief rejected the plan anchor MGR-, and its Engagement Scope list has "OCIO Mandate". Binding guidelines stay 01 Investment Restrictions; the IPS holds the client's own statements of risk and liquidity.
- **Servicing, not selling or billing (CW-054, CW-138).** No relationship manager of record, pipeline, consultant profile or fee fact is held. Mandate Onboarding references the won 05 Sales Opportunity (OPP-, forced to 05 until the prefix is restored) and the 39 contract. The hand-off is held on the 12 side only; 05 drops Win / Loss.Resulting Service Relationship.
- **Breach facts and custody set-up** follow CD-222, CD-155 and CD-194 unchanged. Client Custodian Account.Custodian is a reference that holds the 15 Institutional Account custodian; it is not a Derived copy because a reference cannot also be one.
- **Bare-word qualifiers (CW-007).** At the 12 fix pass Custody Account became Client Custodian Account, and the client-asset names became Serviced Pooled Vehicles and Covered Mandates / Vehicles (readers in proposals REPOINTS). Holdings Presentation and its two "Holdings" attributes describe 18 portfolio holdings and were renamed at W5 to Portfolio Holdings Presentation, Portfolio Holdings Detail Level and Portfolio Holdings Disclosure Lag Days. Stewardship reporting cites Advisers Act Rule 206(4)-6 and Rule 14Ad-1 for the firm's votes, and fund Form N-PX only for pooled vehicles.
- **PII (CW-150).** Every object states its tier in its first attribute's Notes. Profiles, policies, relationships and reports are "No PII". Recipients, signatories, certifying officers and assigned employees are "PII - identity".

## 5. Deviations from the brief

1. The proposals file is `proposals_w4_12.py` (as the assignment says), not `proposals_12.py`.
2. Compliance Certificate gains Certified Mandate: its grain is mandate x period end and it had no mandate attribute.
3. Custody Account, Serviced Pooled Holdings and Covered Mandates / Holdings were renamed at the 12 fix pass. Holdings Presentation, Holdings Detail Level and Holdings Disclosure Lag Days became Portfolio Holdings Presentation, Portfolio Holdings Detail Level and Portfolio Holdings Disclosure Lag Days at W5, the 'Service Request Type' list became 'Institutional Service Request Type' in the module, and In-Specie Indicator is kept as ordinary US usage.
4. The local list Spending Policy Method is added; it is not in the brief's section 8 list.
5. The IPS holds one Governing Body Approval Date and one IPS Effective Date. The brief lists "adoption and governing body approval dates", which are the same event in most institutions (lever below).
6. Plan Sponsor Servicing Detail is a Business Object keyed relationship x plan (program-lead ruling), not the brief's attribute group.
7. Size: 250 attributes, at the top of the 210 to 250 target. To stay there after the fix-pass additions (Sponsor Service Relationship, Transition Total Cost), Servicing Detail Effective From and Delegation Effective Date were dropped (Relationship Start Date covers both). 33 objects, as the brief says.

## 6. Unverified (confirm)

1. eCFR paths for Advisers Act Rules 206(4)-5, 206(4)-2 and 206(4)-6, Exchange Act Rule 14Ad-1 and Regulation S-ID; PDF paths for Forms N-1A, N-PORT and ADV Part 1A; the UPMIFA and CFA Institute IPS pages; the AICPA SOC 1 page; the Salesforce Case object path.
2. Whether UPMIFA applies to each charitable client depends on the state where it is organized (Pennsylvania has not enacted UPMIFA). Confirm per client with Legal.
3. The ERISA section 3(38) written acknowledgment of fiduciary status and the 3(21) adviser description in the ERISA Fiduciary Status list paraphrase the statute; confirm the wording with ERISA counsel.
4. The restored Institutional Client attributes come from the compiled wholesale 02 module, not from the tag.
5. Rule 206(4)-2: confirm current status. The SEC's 2023 safeguarding proposal that would have replaced it was withdrawn on 2025-06-12, so 206(4)-2 stays the citation.
6. Form N-PORT timing: the 2024 amendments have extended compliance dates; confirm before citing a lag.
7. Vanguard sold its OCIO business to Mercer in 2024 (confirm); see lever 1.
8. The names this module uses for 05 (Consultant Advisory Relationship, Sales Opportunity), 16 (Service Arrangement, Plan Role Assignment), 24 (Asset Allocation Policy) and 52 (Sub-Adviser Engagement) come from their briefs and current modules. Confirm them when the sibling drafts merge.

## 7. Open questions for SMEs (tailoring levers; reference default first)

1. **Which relationships does 12 service?** Default: OCIO, institutional separate account and pooled (fund or CIT) clients, and sponsors of recordkept plans. Levers: add a sub-advisory segment; move plan sponsors to 16 for a recordkeeper-only firm; or drop the OCIO segment, OCIO Service Detail and the IPS for a firm that does not run OCIO (Vanguard sold its OCIO business to Mercer in 2024; confirm).
2. **Is the IPS mastered by the firm?** Default: yes for OCIO clients (Firm-Drafted Indicator = Y); a client-provided policy is still versioned here. Lever: hold the IPS only as a 39 document reference.
3. **Who is the relationship manager of record?** Default: 03 Party Coverage Assignment (CW-063, CW-138); 12 holds servicing roles. Lever: a separate institutional coverage model in 12.
4. **Do plan sponsor reports belong here or in 16?** Default: sponsor report packages and committee reviews are 12; the data comes from 16. Lever: move sponsor reporting to 16.
5. **Does the firm notify clients of guideline breaches by contract?** Default: yes, per the investment management agreement. Lever: none.
6. **Are relationship surveys run by 04 for institutional clients too?** Default: yes (CW-093); the health score reads them. Lever: keep a 12 feedback object.
7. **Steward of the shared Performance Fee Basis list.** Ruled by the program lead (not a lever): steward 32, with 12 and 47 as members.
8. **IPS adoption and approval.** Default: one approval date and one effective date. Lever: add a separate adoption date where the board ratifies a committee approval.
9. **Where ERISA fiduciary status lives for non-OCIO mandates.** Default: OCIO Service Detail holds it for OCIO relationships; for a recordkept plan the 16 Plan Role Assignment (3(38) or 3(21)) is the master and the 12 value must agree; for an ERISA plan's non-OCIO institutional separate account mandate the status is read from the investment management agreement (39) and Institutional Client.ERISA Plan Indicator. Lever: move ERISA Fiduciary Status to Service Relationship or to the 01 mandate so every ERISA mandate holds it in one place.
10. **Institutional client types not carried** (sovereign wealth funds, central banks, family offices, corporate treasuries). Default: out of the IA client base. Lever: add the values back.

## 8. Suggested validation steps

1. Walk an OCIO endowment end to end: Institutional Client -> IPS version -> Service Relationship with OCIO Service Detail -> quarterly OCIO Total Portfolio Report run and delivery -> breach notification -> IPS review.
2. Walk a recordkept 401(k) sponsor: Institutional Client (Corporate DC Plan Sponsor) -> Service Relationship with Plan Sponsor Servicing Detail -> Plan Sponsor Review Report -> Plan Fiduciary Committee Review.
3. Check with 16 that no plan provision, role or arrangement fact is held here, and with 47 that no fee fact is.
4. Re-point the readers listed in proposals_w4_12.py NOTES (DP-023, DP-042, DP-068, DP-092, DP-225, DP-243, the key registry INST_CLIENT, SM-00 and SM-04) at the W4 merge.
