# Source Notes: 13 Client Service & Communications (Draft v0.1, 2026-10-14)

Workbook: `Investor_Servicing_and_Shareholder_Communications_Data_Taxonomy.xlsx` (name and folder kept; renaming is a program-lead choice). Content module: `_tools/content/content_13_investor_servicing_and_shareholder_communications.py` (adapted in place from the wholesale Investor Servicing & Shareholder Communications). Enrichment: `_tools/enrichment/enrich_13.py` (rewritten). Proposals: `_tools/consolidation/proposals_w2_13.py`.
Size (built): 8 families, 40 objects (30 business objects, 10 attribute groups), 289 attributes, 92 CDEs (32%), 68 code lists (61 local, 7 copies of shared or to-be-shared lists), 60 relationships, 26 sources. Ownership: 62 references, 8 derived copies, 0 unresolved (after the review fix pass, section 8). Wholesale baseline (built, Record Metadata excluded): 40 objects, 230 attributes, 70 CDEs, 60 code lists, 36 relationships, 20 sources.

**Perspective.** Wealth manager (direct) | Scope: US. A hypothetical US wealth manager of the Vanguard type: direct brokerage and self-directed investing, digital and human advice, proprietary funds and ETFs, workplace recordkeeping, institutional advisory, a thin intermediary channel and optional personal trust services (business lines DB, DA, HA, PF, WR, IA, IC, TR; CW-004). The contact center, document composition, tax reporting, transfer agent and recordkeeper are in house; the broker-dealer is self-clearing.

## 0. Why this domain exists, and what the adaptation changed

Client service operations, the contact center and document operations serve every client and account the firm carries. They take calls, chats, secure messages and branch visits, authenticate the person on the line, open and work service requests, produce and deliver statements, confirmations, tax forms and regulatory communications, manage e-delivery and householding, solicit fund proxies, forward issuer proxies to brokerage clients, find lost clients and escheat what cannot be returned. The wholesale 13 served the shareholders of a fund complex held mostly through intermediaries and overseen at an outsourced transfer agent. The wealth 13 serves the direct client across brokerage, advisory, fund-only, participant and trust accounts. The broker-dealer's delivery obligations sit at its center: FINRA Rule 2231 statements, SEC Rule 10b-10 confirmations and IRS information returns. The fund-complex duties stay: shareholder reports, prospectus delivery and fund proxy solicitation.

This is an adaptation. Every kept object keeps its name and grain, because carried modules and live products read 13 by name (Service Request: 02, 15, 29; Investor Document: 16; Shareholder Communication: 02, 16, 35, 36, 42; Proxy Campaign and Proposal: 34, 35, 36; Servicing Error: 29, 37; Servicing Provider Engagement: 40; Intermediary Communication Fee Invoice: 19). Family codes are kept so that kept attribute IDs stay stable within untouched families.

| Wholesale object | Disposition | What changed |
|---|---|---|
| Request Controls, Account Maintenance Change, QA Review, Investor Document Definition, Production Run, Tailored Shareholder Report, Prospectus Delivery, Communication Distribution, Householding Group, Mail Hold, Proxy Campaign, Proxy Proposal, Vote Tally, Intermediary Vote Instruction, Dormancy Assessment, Escheatment Report & Remittance, Unclaimed Property Reclaim, Service Level Definition, Service Level Measurement | Kept | Names and grain unchanged. Examples and sources re-cut. Small additions: call-back verification, change notification document (Rule 17a-3(a)(17)), Statement Type, Householded Document Scope, Mail Hold End Date (FINRA Rule 3150), Dormancy Account, Remittance Money Movement (50), SLA Scope. Service Level Measurement is now flagged an attribute group of its definition |
| Service Request | Kept, re-cut | Every account type. Adds Request Business Line, Assisting Advisor (03), Resulting Client Account Activity (49) and Resulting Money Movement (50). Resulting Transaction (06) removed. Escalated Complaint re-sourced to FINRA Rule 4530 (08 Complaint). Servicing Provider redefined for outsourced items only |
| Transfer of Ownership & Estate | Kept, re-cut | Decedent and Date of Death replaced by Related Death Notification (02 DTHN-). Beneficiary Allocation Percentage replaced by Claimed Beneficiary Designation (15 ABD-). Adds Estate Settlement Case (51 ESTATE-) and Deceased-Account Restriction (15 ARX-) |
| Contact Center Interaction | Kept, re-cut | Every assisted channel. Adds Interaction Party, Interaction Agent (20 EMP-), Interaction Queue, Wait Time and Handle Time. Dissatisfaction Expressed Indicator re-sourced to FINRA Rule 4530. Recording Reference restricted (may contain special category) |
| Investor Document | Kept, re-cut | Statement types (brokerage, advisory, fund-only, participant, trust). Adds Issuing Entity (09). Statement frequency and duplicate recipients are read from 15 Account Preference (CW-915) |
| Trade Confirmation | Renamed **Confirmation Delivery** | References the 48 Client Trade Confirmation (CCONF-) or the 29 Fund Order. Confirmed Transaction (06) removed (CW-081) |
| Tax Form Record | Kept, re-cut | Adds Tax Form Account, Payer Entity (09) and Authority Filing Due Date. Payer Fund kept for fund-only accounts. Form set re-cut to the IRS forms. HMRC removed |
| Shareholder Communication, Shareholder Notice, Recipient Delivery Record | Kept, re-cut | Adds the broker-dealer and adviser communications (CW-087), Communicating Entity and Source Plan Notice (16). Shareholder Notice loses Change Classification and Free Redemption Window End Date and gains Change Effective Date. Recipient Delivery Record gains Distribution Job, Returned Mail Date and Return Reason (CW-089) |
| E-Delivery Election | Kept | Linked Consent Record re-sourced to E-SIGN. Adds Election Basis (SEC guidance, DOL safe harbor, IRS consent, E-SIGN) |
| Lost Shareholder Status | Kept, re-cut | Adds Searching Entity: Rule 17Ad-17 applies to both the transfer agent and the broker-dealer. First Returned Mail Date reads the 13 delivery records (ROW_OWNERSHIP) |
| Servicing Error, Shareholder Remediation | Kept, re-cut | Client-impacting errors on any account. Adds Affected Business Line and Remediation Money Movement (50). COLL 6.6 reference removed |
| Servicing Provider Engagement | Moved | Removed from 13 at the W2-W4 merge; 29 masters it (CW-088; amends CD-202). 40 line 80 re-pointed to 29; DP-176 and DP-210 re-point at lineage |
| Intermediary Distribution Request, NOBO List Request | Moved | Removed from 13 at the W2-W4 merge; 29 masters them (CW-088) |
| Intermediary Communication Fee Invoice | Moved | Removed from 13 at the W2-W4 merge; 05 masters it (CW-088). 19 line 236 re-pointed to 05 |
| UK & EU Tax Document, EU/UK Investor Information Provision, Notice Cascade, UK Dormant Asset Transfer | Removed | US-only pass (CW-913; section 7) |
| Record Metadata | Dropped | Excluded (CD-160); governance metadata is modeled once in 21 |
| *New:* Interaction Authentication | Added (SV-SRQ) | CW-086 |
| *New:* Beneficial Owner Disclosure Election | Added (SV-DEL) | CW-090 |
| *New:* Voting Choice Election (VCEL-) | Added (SV-PRX) | CW-082, CW-934 |
| *New:* Issuer Proxy Pass-Through | Added (SV-PRX) | CW-090 |

Family names were re-worded for the wealth model with their codes kept: Client Service Requests & Interactions (SV-SRQ); Statements, Confirmations & Tax Documents (SV-STM); Regulatory Client Communications (SV-COM); Delivery Elections & Householding (SV-DEL); Proxy, Voting Choice & Shareholder Meetings (SV-PRX); Intermediary Beneficial-Owner Communications (SV-BOC, transitional); Escheatment, Unclaimed Property & Dormancy (SV-ESC); Service Quality, Errors & Remediation (SV-TAO, code kept).

## 1. Sources consulted

| Topic | Finding | URL |
|---|---|---|
| Account statements | FINRA Rule 2231 requires account statements at least quarterly. Monthly statements in months with activity are firm practice (15 Account Preference holds the frequency) | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2231 |
| Confirmations | Rule 10b-10 requires a confirmation at or before completion of the transaction. Paragraph (b) allows periodic confirmation for certain periodic plans and investment company plans, subject to conditions | https://www.ecfr.gov/current/title-17/section-240.10b-10 |
| Tailored shareholder reports | Release 33-11125 (October 2022): concise annual and semi-annual reports, with financial statements on Form N-CSR and the website. N-1A funds are excluded from Rule 30e-3. Compliance date July 24, 2024 | https://www.sec.gov/files/rules/final/2022/33-11125.pdf |
| Householding | Rule 154 (Release 33-7912): written or implied consent, 60-day notice, annual revocation notice. Rules 30e-1 and 14a-3(e) allow the same for shareholder reports and proxy materials | https://www.sec.gov/rules/final/33-7912.htm |
| E-delivery | 1995, 1996 and 2000 interpretive releases (notice, access, evidence; informed and global consent). E-SIGN section 101(c) consumer consent. DOL notice-and-access safe harbor (2020) for plan documents | https://www.sec.gov/files/rules/interp/33-7288.txt ; https://www.ecfr.gov/current/title-29/section-2520.104b-31 |
| Lost securityholders | Rule 17Ad-17 (Release 34-68668, 2013) applies to transfer agents and broker-dealers. It requires two database searches and a notice to unresponsive payees within seven months | https://www.sec.gov/rules/final/2013/34-68668.pdf |
| Issuer pass-through | Rule 14b-1 obliges brokers to forward materials and to disclose NOBO lists; objecting owners are not disclosed. FINRA Rule 2251 governs forwarding and reimbursement. NYSE Rule 452 governs broker discretionary votes on routine matters | https://www.ecfr.gov/current/title-17/section-240.14b-1 ; https://www.finra.org/rules-guidance/rulebooks/finra-rules/2251 |
| Adviser and broker communications | Form CRS updates go to existing clients (Release 34-86032). Advisers Act Rule 204-3 requires the annual summary of material changes. FINRA Rules 2264 (margin), 2266 (SIPC), 2267 (BrokerCheck) and 4370 (business continuity disclosure) also apply | https://www.sec.gov/rules/final/2019/34-86032.pdf ; https://www.finra.org/rules-guidance/rulebooks/finra-rules/2267 |
| Privacy and identity theft | Regulation S-P (2024 amendments): customer notification of sensitive information breaches within 30 days. Compliance dates are about December 2025 (larger entities) and June 2026 (smaller entities). Regulation S-ID covers red flags | https://www.ecfr.gov/current/title-17/chapter-II/part-248 |
| Holding of mail | FINRA Rule 3150: mail may be held on the customer's written instruction for a limited period | https://www.finra.org/rules-guidance/rulebooks/finra-rules/3150 |
| Authentication | NIST SP 800-63B-4 (final, July 2025): authenticator assurance levels AAL1 to AAL3. Used as a cross-check only; the method list is firm policy, and knowledge questions and personal recognition sit below AAL2 | https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-63B-4.pdf |
| Information returns | IRS General Instructions: furnish and filing dates, corrected returns, truncated TINs on recipient copies, electronic furnishing consent | https://www.irs.gov/pub/irs-pdf/i1099gi.pdf |
| Investor choice voting | Form N-PX amendments (Release 33-11131) give context only; no rule mandates investor choice. The program options are the 34 Voting Choice Option Type | https://www.sec.gov/files/rules/final/2022/33-11131.pdf |
| Unclaimed property | NAUPA standard format and property codes; state dormancy periods; Revised Uniform Unclaimed Property Act (2016) | https://unclaimed.org/reporting/ |
| Case management (cross-check) | Salesforce Service Cloud Case object: status, origin (channel), priority | https://developer.salesforce.com/docs/atlas.en-us.object_reference.meta/object_reference/sforce_api_objects_case.htm |

## 2. Design and boundary decisions

- **Record versus delivery (CW-081).** 48 masters the client trade confirmation, 29 the fund order, 49 holdings, lots and activity, and 16 the plan notice. 13 masters the rendered document, its delivery and the information return as filed. No balance, lot or trade economics is held here. The only quantity is Issuer Proxy Pass-Through.Record Date Entitled Quantity, a declared Derived copy of 49 Client Corporate Action Entitlement (CLCAE-).
- **Who delivers what (CW-087).** 15 delivers account-opening and feature disclosures and 47 delivers fee disclosures. 13 delivers periodic and event-driven communications, including privacy notices, through Shareholder Communication (COMM-, name kept). 02 Privacy Profile.Initial Privacy Notice keeps pointing at a COMM- record; the value Initial Privacy Notice was added for it.
- **Assisted authentication (CW-086).** Interaction Authentication records method, result, step-up, failed attempts and the Reg S-ID red flag. It references 02 Identity Verification only when a CIP check is run. It never holds passwords, codes, knowledge answers or biometric templates; voice biometric consent is a 02 Consent Record.
- **Deceased clients and returned mail (CW-089).** 02 masters the death and the date of death. 13 masters the requests that follow and references DTHN-, ABD-, ARX- and, where the trust company acts, ESTATE-. Recipient Delivery Record masters returned mail for every delivery: each communication sent through a distribution job and each Investor Document delivered has one. Investor Document.Delivery Status is a summary of it. 02 Mail Returned Date becomes a Derived copy; Lost Shareholder Status.First Returned Mail Date is the earliest Returned Mail Date of the account's delivery records (ROW_OWNERSHIP).
- **Voting choice (CW-082).** The election references the 34 Voting Policy version and carries the option type from the to-be-shared 34 list. Voting Choice Offered Funds is read from 34 for validation; 13 adds no policy x fund link. 34 reads the elections.
- **Issuer pass-through (CW-090).** The issuer meeting is referenced as a 17 Corporate Action Event (CAE-), which exists today. CW-090 says "per the 49 brief", and the plan anchor CAX- is the 49 account transfer, so a corporate action object in 49 was not assumed (deviation, recorded in NOTES).
- **Three households (CW-027).** Householding Group (MHG-) is described as the Mailing Household everywhere.
- **Transitional objects (CW-088).** Servicing Provider Engagement, Intermediary Distribution Request and NOBO List Request moved to 29 and Intermediary Communication Fee Invoice to 05; the W2-W4 merge removed them from 13.
- **PII.** Every object states its tier in its first attribute's Notes. Recordings, transcripts and the incapacity / guardianship transfer reason are special category or may contain it (CD-344), restricted; the facts are 02 Vulnerability Concern. TINs are masked (`***-**-4821`).
- **Deviation from the brief:** the brief's "Request Channel" is the kept Intake Channel; no second channel attribute was added. The brief's prefix for fund orders (TAO-) is FNDO- in content_29; FNDO- is used.

## 3. Unverified items (confirm)

- Regulation S-P 2024 amendments: release number (34-100155 assumed) and whether the compliance dates (about December 3, 2025 and June 3, 2026) were extended after industry requests in 2025.
- SEC Rule 17a-3(a)(17) notice to the former address after an address change, and its 30-day timing (from knowledge).
- FINRA Rule 3150 maximum hold period and conditions (cited, not re-read).
- E-SIGN URL on uscode.house.gov; DOL 29 CFR 2520.104b-31 eCFR path; NIST SP 800-63B-4 PDF path on nvlpubs.nist.gov; Broadridge Form 10-K URL (sec.gov unreachable from the review session).
- Rule 10b-10(b) conditions for periodic confirmation of systematic plans and reinvestments.
- IRS electronic furnishing consent rules per form; TIN truncation on recipient copies; filing due dates by method (FIRE / IRIS).
- NAUPA property code SC08 in the example is illustrative; state dormancy periods for securities and IRAs not checked.
- Current NYSE Rule 451 / FINRA Rule 2251 fee schedule components (list is indicative).
- Rule 14a-3(e) householding of proxy statements and annual reports, and joint privacy notices under Reg S-P, as values of Householded Document Type.
- 48, 49 and 50 objects are keyed to the W3 brief reservations (CCONF-, CLACT-, CLCAE-, MMVMT-); confirm them against the W3 drafts. RGTX- (29 Register Transaction, CW-122) is reserved in proposals_w3_oversight.py, not yet in decisions.PREFIXES.

## 4. SME questions (tailoring levers; reference default in brackets)

1. One service request master for brokerage, fund-only and participant accounts? [Yes.] Lever: a recordkeeper with its own case tool keeps participant requests in 16.
2. Is the transfer agent in house? [Yes; outsourced-TA oversight leaves 13 at W3, CW-088.] Lever: an outsourced TA keeps Servicing Provider Engagement at full depth in 29.
3. Voting choice offered? [To direct shareholders of selected own funds, one election per account and fund.] Lever: per household, or not offered (drop VCEL- and the Voting Choice family group).
4. Third-party issuer proxies? [The broker-dealer forwards through an agent and records each client's instruction.] Lever: aggregates only from the agent.
5. Statement consolidation? [One statement per account; household consolidation optional, Client Statement Type value Consolidated Household Statement.] Lever: household statements as the default document.
6. Annual privacy notice? [Not sent while the Reg S-P annual notice exception applies; sent on a change in practices.] Lever: send annually.
7. Who masters returned mail? [13 Recipient Delivery Record; 02 Mail Returned Date is a Derived copy, CW-089.] Lever: a CRM that masters returned mail flips the Derived flag.
8. Advisor personal recognition as an authentication method? [Listed but limited by policy.] Lever: drop the value where policy forbids it.
9. OBO / NOBO default at account opening? [Firm default recorded with Disclosure Default Applied Indicator.] Lever: require an explicit election on the application.

## 5. Overlaps with other domains (for consolidation)

| Item | Domains | Proposed resolution |
|---|---|---|
| Returned mail | 13, 02 | 13 masters; 02 Derived copy (CW-089) |
| Authentication events | 13, 04, 02, 41 | Split by who authenticates (CW-086) |
| Confirmation | 13, 48, 26 | 48 record, 13 delivery, 26 fund-side affirmation (TERM_CONFLICTS) |
| Voting choice | 13, 34 | Election 13; options, policies and votes 34; shared list steward 34 (CW-082) |
| Complaints | 13, 08 | Reference CPL-; dissatisfaction flag only (CW-070, CW-093) |
| Surveys and NPS | 13, 04 | 04 masters surveys; 13 keeps QA Review (CW-093) |
| Statement preferences | 13, 15 | 15 Account Preference; 13 reads (CW-915) |
| Service channel and authentication method lists | 13, 02, 04, 12, 41 | SHARED_CANDIDATES |
| Shared list memberships | 13 | Remove COLL Change Classification and Data Quality Status memberships; add Business Line; create Voting Choice Option Type (proposals) |

## 6. Suggested validation steps

1. Walk a death claim end to end with Estate Services: 02 notification, 13 requests, 15 restriction and beneficiary designation, 51 case, 50 disbursement.
2. Walk an issuer proxy cycle with Brokerage Operations and the forwarding agent: record date (49), materials, instructions, NOBO list.
3. Map the contact center platform's authentication log to Interaction Authentication and confirm that no secrets are exported.
4. Reconcile one statement run's counts and a 1099 season's furnish and filing dates against the composition and tax engines.
5. Confirm the CDE set with Client Service, Document Operations, Tax Reporting and Compliance.

## 7. Wealth model adaptation (W2)

**Removed (CW-913; 39 JURISDICTION entries in `proposals_w2_13.py`: 20 Other EU/UK, 9 FCA, 7 UCITS, 2 PRIIPs, 1 GDPR / UK GDPR).**

| Removed | Regime | Note |
|---|---|---|
| UK & EU Tax Document (UK Distribution Type, Equalization Amount, Excess Reportable Income per Unit); list UK Distribution Type; values Tax Voucher / Certificate, UK Tax Voucher, UK Consolidated Tax Certificate, UK Excess Reportable Income Report, EU Annual Tax Statement, Document Regulatory Basis HMRC; HMRC source | Other EU/UK | US information returns stay; Form 1042-S stays |
| EU/UK Investor Information Provision (Provision Medium); list Durable Medium Type; values Annual Report (UCITS / UK), Half-Yearly Report (UCITS / UK), KID (PRIIPs) / KIID (UCITS), UCITS Directive, PRIIPs Regulation; UCITS Directive source | UCITS, PRIIPs | US delivery via Delivery Method and E-Delivery Election |
| Shareholder Notice.Change Classification and list COLL Change Classification; Free Redemption Window End Date | FCA, UCITS | Minimum Notice Period re-sourced to SEC Rule 35d-1; Change Effective Date added |
| Notice Cascade and list Cascade Method; Holding Model Platform Nominee; Audience Basis Platform / Nominee Holders | Other EU/UK | |
| UK Dormant Asset Transfer; list UK Dormant Asset Category; Reclaim Source UK Reclaim Fund; Dormant Assets Act source | Other EU/UK | |
| Meeting Type Extraordinary General Meeting; Vote Standard Extraordinary Resolution; Fund Proposal Type Fundamental Change (COLL), Approve Scheme of Arrangement; Communication Regulatory Basis UK FCA COLL; Document Regulatory Basis FCA COBS 16; FCA Handbook source | FCA, Other EU/UK | Investment Company Act references kept |
| Estate Document Type Grant of Probate (UK); Shareholder Notice Type Dealing Suspension | Other EU/UK | Redemption Suspension (ICA Section 22(e)) replaces the latter |
| GDPR and FCA DISP parts of the combined source | GDPR / UK GDPR, FCA | Re-sourced to E-SIGN and FINRA Rule 4530 |

**Re-sourced:** Escalated Complaint and Dissatisfaction Expressed Indicator to FINRA Rule 4530; Linked Consent Record to E-SIGN; NAV Error Magnitude and Materiality Threshold Exceeded Indicator to the board-approved NAV error policy; Minimum Notice Period to Rule 35d-1; Shareholder Approval Required Indicator, Meeting Type, Proposal Type and Vote Standard to the Investment Company Act; tax attributes to the IRS only; report deadlines to Form N-CSR and Rule 30e-1.

**Re-pointed and renamed:** see REPOINTS in the proposals file. Trade Confirmation is now Confirmation Delivery. Resulting Transaction is now 49 activity and 50 money movement. Decedent and Date of Death are now 02 Death Notification. Beneficiary Allocation Percentage is now the 15 Beneficiary Designation. Value relabels: RPO becomes Returned Mail, Shareholder becomes Client, Unit / Share becomes Share.

**Readers** (live products, models and semantic models with file and line) are listed in NOTES of the proposals file. DP-069, DP-070, DP-085, DP-091 and DP-106 lose removed columns. DP-169, DP-244, DP-176 and DP-210 are unaffected at W2.

**Open for later stages:** W3 confirms the 48, 49 and 50 object names, and 29 takes three transitional objects. At W4, 05 takes the fee invoice. At W5, 34 creates the shared Voting Choice Option Type list.

## 8. Review fix pass (00_Program/Rework/Reviews/13_review.md; program-lead rulings, 2026-10-15)

Counts before: 282 attributes, 84 CDEs, 60 references, 7 derived copies, 67 code lists, 59 relationships. After: 289 attributes, 92 CDEs (32%), 62 references, 8 derived copies, 68 code lists, 60 relationships. The attribute count is 4 above the brief's 285 because the rulings add 7 attributes.

**High (A1).** W3 examples are re-keyed to the reserved prefixes: CCONF- (48), CLACT- (49), MMVMT- (50). The issuer pass-through quantity is renamed Record Date Entitled Quantity and is a Derived copy of 49 Client Corporate Action Entitlement (CLCAE-). The relationship and the DERIVED row follow.

**Medium.**
- **03 boundary:** row rule stated on the family, on Contact Center Interaction (first attribute Notes and ROW_OWNERSHIP) and in a new relationship. Added Service Request.Originating Advisor Activity (03, ACT-). Interaction Agent is the 20 employee.
- **Returned mail:** Recipient Delivery Record covers every delivery and gains Delivered Investor Document. Investor Document.Delivery Status is a summary of it. The First Returned Mail Date rule is restated.
- **Derived copies:** Chosen Option Type is declared Derived from 34. Correction Transactions now reference 29 Register Transaction, and Shares Outstanding at Record Date is a Derived copy of the 29 Share Register Balance (CW-122).
- **Readers:** content_29 line 418 and models_c10 lines 567-570 added to NOTES.
- **Code lists:**
  - Investor Document Category: Trade Confirmation is relabeled Client Confirmation.
  - Authentication Method is a firm-practice list, and Authentication Assurance Level (AAL1 to AAL3, NIST SP 800-63B-4) is added.
  - The OBO/NOBO value Default Applied is removed.
  - Statement Type is renamed Client Statement Type.
- **Other additions:** Householding Group.Householding Address (02); Investor Document grain includes the recipient; Issuer Proxy Pass-Through.Broker Discretionary Vote Permitted Indicator.
- **CDEs:** flags added as the review names; seven descriptive or transitional flags removed.
- **Transitional names:** Holding Model and Beneficial Owner Position Count stay; the rename is recorded as a binding instruction to the 29 receiver.

**Low (applied).**
- Tax Year is now an Integer.
- Definitions that restated their names are rewritten.
- Examples use the 01 and 34 formats.
- Form 8937 Reference is dropped.
- New values: Supplemental Tax Information and Order Routing Disclosure (SEC Rule 606(b)) in Investor Document Category; Firm in Cost Bearer.
- The Business Continuity Disclosure value is limited to on-request mailings.
- Interaction Channel is restricted to assisted values.
- Mail Hold gains Mail Hold Start Date, and Rule 3150 is scoped to client requests.
- Voting Choice Elected Timestamp added.
- Lost Shareholder Status relationship changed to 1 : 0..n, with the episode grain.
- PII notes added to Updated Master Record and Deceased-Account Restriction.
- SHARED_CANDIDATES gain Metric Unit and Oversight Rating; a LOCAL_RENAMES proposal is made for Good Order Status.
- The Broadridge URL is marked confirm.

**Low (skipped).**
- Rename of Service Request.Servicing Provider: deferred to W3, when the engagement moves to 29 (NOTES).
- Mail Hold Instruction Reference: the written instruction is the originating Service Request, so no separate reference was added.
- Lost Shareholder Status effective-from and effective-to attributes: the episode runs from First Returned Mail Date until the indicator clears, so no new attributes were added (size).
