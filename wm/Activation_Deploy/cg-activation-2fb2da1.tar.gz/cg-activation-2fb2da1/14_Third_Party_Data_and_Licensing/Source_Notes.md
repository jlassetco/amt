# Source Notes: 14 Third-Party Data & Licensing

**Workbook:** `Third_Party_Data_and_Licensing_Taxonomy.xlsx` | **Content module:** `_tools/content/content_14_third_party_data_and_licensing.py` | Draft v0.1, 2026-10-01; wealth model carry-over (W1b, CW-914), 2026-10-14: Wealth manager (direct) | Scope: US

Build result (W1b, after review): 10 families, 30 objects, 232 attributes, 70 CDEs (30.2%), 60 code lists, 33 relationships, 14 sources (section 7). Wholesale baseline (wholesale-v1.0): 10 families, 30 objects, 243 attributes, 73 CDEs, 63 code lists, 33 relationships, 19 sources. (The v0.1 draft of 2026-10-01 had 11 domains, 28 subdomains, 31 concepts and 250 attributes.)

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| FISD (SIIA) market data policy work (BIPPS working group) | https://fisd.net ; draft on derived data and non-display: https://mondovisione.com/news/fisd-issues-derived-data-and-nondisplay-usage-draft-industry-comment-sought-2011124/ | Display use means a person views the data. Non-display use is any other access or processing. Derived data is created from market data and cannot be reverse-engineered to recreate it. Used for `Permitted Use Category`, `Usage Mode`, `Non-Display Use Type`, `Derived Data Ownership` and `Derived Data Survival Indicator`. |
| AICPA SOC 2 (Trust Services Criteria) | https://www.aicpa-cima.com/topic/audit-assurance/audit-and-assurance-greater-than-soc-2 | Type I covers control design at a point in time; Type II covers operating effectiveness over a period. There are five categories, and Security is always in scope. Used for the Assurance Report concept and its lists. |
| SEC Regulation S-P (17 CFR Part 248, Subpart A) | https://www.ecfr.gov/current/title-17/chapter-II/part-248/subpart-A | Safeguarding of customer information and service-provider oversight; personal data fields (W1b, CW-914). |
| CCPA as amended by the CPRA | https://oag.ca.gov/privacy/ccpa | Personal information in purchased and aggregated datasets; service provider terms (W1b, CW-914). |
| CTA and UTP Plans, OPRA, exchange subscriber agreements | https://www.ctaplan.com ; https://www.utpplan.com ; https://www.opraplan.com | Professional and non-professional subscriber definitions and monthly subscriber reporting, for client real-time quote entitlements (W1b addition, CW-914). |
| US Interagency Guidance on Third-Party Relationships (2023) | https://www.federalregister.gov/documents/2023/06/09/2023-12340/interagency-guidance-on-third-party-relationships-risk-management | Third-party lifecycle stages and risk-based tiering; since W1b also the reference for substitutability, exit planning and termination (in place of DORA). Used as good practice only, because it is banking guidance. |
| EDM Council DCAM and CDMC | https://edmcouncil.org/frameworks/dcam/ ; https://edmcouncil.org/frameworks/cdmc/ | Ownership and stewardship, authoritative sources, cataloging and classification, lineage and data-sharing controls. Used for the dataset catalog, `Authoritative Source Indicator`, classification and SLA metrics. |
| Snowflake Marketplace documentation | https://docs.snowflake.com/en/collaboration/collaboration-marketplace-about | Listings, the provider/consumer model, paid listings and Secure Data Sharing. Used for the `Cloud Data Share` delivery method and `Marketplace Listing / Share Name`. |
| Bloomberg Data License (public page) | https://professional.bloomberg.com/products/data/data-license/ | Enterprise delivery feeding many applications, priced by data and applications rather than users. Supports the `Enterprise` and `Per Application / Non-Display` license models, alongside the Terminal per-seat model. |
| MSCI Index License Agreement for Funds (SEC exhibit) | https://www.sec.gov/Archives/edgar/data/1408198/000119312512086989/d264713dex101.htm | Fees are basis points on average daily net assets, calculated by the licensee and paid quarterly in arrears, with trademark-use and product-coverage schedules. Used for Index Product Coverage and the AUM-linked Usage Declaration. |
| Morningstar licensing practice (press) | https://www.financial-planning.com/news/consultants-call-morningstar-billing-unfair | Morningstar licenses by department, restricts sharing with affiliates, and charges extra for redistribution. Used for `Licensed Business Units`, `Licensed Legal Entities` and the `Affiliate Sharing` and `Redistribution` use categories. |

## 2. Design decisions and boundary calls

- **Vendor = party.** The vendor's legal identity, LEI and contact persons are `PTY-` records in 02. 14 holds only the relationship role (tier, owner, status, reviews). 02's `Data Vendor` code list (Discovery Data, Broadridge, ...) should become a reference to the vendors held here.
- **DLA- vs AGR-.** 14 owns licenses for data the firm *buys from vendors*, including Broadridge Distribution Insight even though it contains distributor data. 05 owns data-sharing and data-licensing agreements *with distribution partners*, and any data fees paid to them. Test: if the counterparty is a distribution partner under 05, it is `AGR-`. If it is a data vendor, it is `DLA-`.
- **Dataset sits between license and feed.** `DSET-` is the commercial and catalog view. 06 `FEED-` remains the technical delivery. One dataset can have several feeds, and a feed carries one dataset.
- **Rights as coded grants.** Each permitted use is one row per agreement × dataset × use category, with a status: permitted, conditional, requires additional license, prohibited or not addressed. "Not addressed" must be treated as not permitted until Legal confirms. AI/ML training and generative AI retrieval are separate categories.
- **Index licensing reuses DLA-.** An index license is a `DLA-` of type *Index License Agreement*. Index Use links it to 01 `BMK-`, and Index Product Coverage links it to 01 `PRD-`/`SHC-` with fees in basis points. Index levels and constituents are not held. Since W1b no benchmark-register status is held here (EU and UK BMR removed, CW-914); 01's static `BMR Register Status` flag on the benchmark is 01's to remove (overlap, see §6).
- **Ratings.** 14 holds the *right* to show Morningstar or Lipper ratings (e.g. in marketing materials). The rating values belong to 11 (own and peer funds), and partner research ratings belong to 05.
- **Consultant databases.** Reading Nasdaq eVestment data is a 14 license. Submitting our data to eVestment is 03 (`DBS-`).
- **Intent data.** The Bombora/ZoomInfo dataset and its license are 14. The intent signals and scores are 04.
- **Cost.** 14 holds contract value, invoices, and the agreed cost split to `OU-` (09). Accounting, accruals and standard allocation methods (`ALM-`) are 10, and 14 only references them.
- **No ICT register.** The DORA ICT Third-Party Register Entry left at W1b (CW-914); data-vendor risk sits on Vendor Risk Assessment, and the enterprise third-party program is 40.
- **No `LIC-`.** "License" in attribute names always means a data license. Personnel licenses remain `LIC-` in 08.

## 3. What could not be verified

- **Exchange subscriber definitions.** The professional / non-professional definitions are paraphrased from the CTA / OPRA non-professional subscriber definition and the exchange subscriber agreements; the plan URLs were not fetched (confirm).
- **The FISD standard terminology document itself.** The definitions come from secondary sources (Mondo Visione, exchange policies). fisd.net was not fetched.
- **Morningstar, S&P DJI, FTSE Russell, LSEG and Bloomberg license terms.** Only public descriptions and one press article were used. Vendor-specific rules for display, redistribution, delays and attribution need to be checked against the firm's actual contracts.
- **The AICPA SOC 2 page URL** came from search results and was not fetched.
- **The MSCI exhibit is from 2012.** Current fee structures may differ.

## 4. Open questions for client SMEs

1. Is there a market data inventory or entitlement platform (e.g. MDSL, TRG, Calero), and is it the system of record for DLA-/ENT-?
2. Which client-facing real-time quote products does the firm display (streaming, snapshot, delayed), and does it count non-professional subscribers by login or by account for the monthly exchange reports?
3. Which index licenses are index-tracking (ETF/index fund) and which cover benchmark use only? Who prepares the quarterly AUM declarations, and from which 06 measure?
4. Which account aggregators and planning data providers does the firm use, and do clients consent to aggregation in 02 (Consent Record) or in the vendor's own flow?
5. What is the firm's position on using licensed data for AI/ML training and in generative AI tools? Has Legal reviewed the top contracts?
6. Are licenses departmental (e.g. separate Morningstar licenses for Marketing and Investments)? Which legal entities are named as licensees?
7. Is there a chargeback of data cost to business units today, and does 10 want the split at OU level or at product/channel level?

## 5. Recommended next steps

1. Build the first inventory: the top 25 vendors, their DLA-/DSET- records and renewal and notice dates. The notice deadline alone justifies the effort.
2. Run a Legal workshop to code the permitted-use grants for the five high-risk uses (client display of real-time quotes, client reporting, marketing materials, index-tracking, AI/ML).
3. Hold a joint session with 05 and 06 on the DLA-/AGR-/FEED- boundary (see §6).
4. Agree the monthly exchange subscriber reporting process with Digital and Market Data (professional and non-professional counts).
5. Map the attributes to the CLM, procurement/AP, entitlement, data catalog and TPRM systems.

## 6. Overlaps for consolidation

| # | Item | Appears in | Proposed resolution |
|---|---|---|---|
| 1 | `Governing Agreement` and `License Use Restriction` on the Data Feed | 06 (FEED-, references AGR-) | For vendor feeds, reference `DLA-` and `DSET-`. Replace 06's `License Use Restriction` list with a reference to 14 Permitted Use Grants. |
| 2 | `Data Vendor` code list | 02 | Replace with a reference to vendors held in 14 (PTY- in the vendor role). |
| 3 | "Data Licensing / Data Sharing Agreement" type | 05 | Keep for distribution partners only. Document the vendor vs partner test (§2). |
| 4 | `BMR Register Status` on Benchmark | 01 | Since W1b, 14 holds no BMR status (CW-914); the 01 flag is EU/UK-only and is listed for 01's pass. |
| 5 | Intent provider code list | 04 | 04 `Intent Provider` should reference 14 datasets (DSET-). |
| 6 | Manager Database list (eVestment etc.) | 03 | Distinct concept (outbound submissions). Cross-reference the DSET- where the firm also licenses the database. |
| 7 | Data cost allocation | 10 | 14 holds the contract-level split. 10 owns allocation methods and accounting. |
| 8 | Internal employee references | 03 EMP- | 14 uses EMP- for non-sales staff (market data, legal, risk). The enterprise workforce-master decision (09) is needed. |
| 9 | Code lists `Frequency`, `Severity`, `Data Quality Status`, `Information Classification` | many | Harmonize into enterprise lists (09 CLR-). |

**New ID prefixes proposed:** `VRA-` (vendor risk assessment), `DAPP-` (consuming application), `UDC-` (usage declaration), `LAU-` (license audit), `DINV-` (data invoice), `RNW-` (renewal case), `VDI-` (vendor data issue). These are in addition to `DSET-`, `DLA-` and `ENT-` from §8, and none collides with §3 or §6.

## 7. Wealth model carry-over (W1b, CW-914)

14 is kept (plan section 5.1). The pass made only the changes CW-022 allows: the US-only pass, the perspective text, the 02 re-pointing and the additions plan section 5.1 names for 14. Object and attribute names are unchanged except for the removed object and attributes. The decision draft and the jurisdiction entries are in `_tools/consolidation/proposals_w1b_14.py`.

**Removed (EU/UK only; 38 jurisdiction entries: BMR 25, DORA 7, FCA 4, GDPR / UK GDPR 1, PRIIPs 1).**
- Object ICT Third-Party Register Entry (DORA register of information, with its object group ICT Third-Party Register & Resilience): DORA In-Scope Indicator, Reporting Financial Entity, Contractual Arrangement Reference, ICT Service Type, Supports Critical or Important Function, Supported Functions, Data Storage Locations, Material Subcontractors, UK Important Business Service Mapping (the brief places it on Vendor Risk Assessment; it sat on this object) and Impact Tolerance Dependency Indicator; the relationship "Data License Agreement is reported in ICT Third-Party Register Entry"; 14's use of the shared DORA ICT Service Type list.
- Index Use: BMR Use Indicator, Benchmark Category (BMR), Administrator Register Status (EU), Administrator Register Status (UK), Register Status Check Date (it dated the register check only), Benchmark Contingency Plan Reference; local lists BMR Benchmark Category and BMR Register Status (whole lists).
- Code values: Identifier Scheme FCA FRN / IRN; the local list Substitutability (Not Substitutable, Highly Complex, Medium Complexity, Easily Substitutable: the DORA scale, a member of the shared DORA Substitutability list); Output Type Prospectus / KID (now Prospectus / Shareholder Report).
- Sources: EU BMR as amended by Regulation (EU) 2025/914; ESMA benchmarks register; UK BMR and FCA benchmarks register; DORA; Commission Implementing Regulation (EU) 2024/2956; FCA PS21/3 (SYSC 15A); FTSE Russell EU BMR FAQs; GDPR and UK GDPR.

**Re-sourced.**
- Vendor Risk Assessment.Substitutability to a firm-defined scale (code list 'Firm-defined', for example Not Substitutable, Difficult, Moderate, Easily Substitutable; the example "Difficult" fits it); with no local list, 14 leaves the shared DORA Substitutability list, which retires (CW-039). Exit Strategy Documented Indicator, Termination for Convenience Indicator and the Vendor Risk Domain list to the US interagency third-party risk management guidance; DORA removed from Risk Domains Assessed; Governing Law reads Internal.
- Personal-data fields to Regulation S-P (primary: client account data is GLBA nonpublic personal information, largely exempt from the CCPA) with state law (CCPA / CPRA) for non-GLBA data (marketing contacts, advisor databases, website visitors): Personal Data Processed Indicator, Contains Personal Data Indicator, Personal Data Use Restrictions (example re-cut to aggregated account data).
- Index Provider and Index Use Type, and the Index Use Type list, to Internal with the MSCI index license as reference.

**Perspective rewritten.** META subtitle; overview Purpose (a US direct wealth manager: exchange market data for client display, account aggregation, planning data, fund data, index licenses of its index funds and ETFs, market data; advisor and consultant databases only for the intermediary channel and institutional advisory), Scope, Core model, Applies To, CDE, Primary / Secondary Reference and Suggested next steps 1, 3 and 6; family texts of Vendor Risk & Resilience, Index & Benchmark Licensing and Entitlements & Access; the dataset examples (Account Aggregation - Held-Away Accounts instead of Discovery Data Advisor Intelligence; Consuming Business Domain 45 Financial Planning & Advice; Target Concept "45 Financial Planning & Advice / held-away assets" instead of the wholesale 02 Financial Professional Profile); Licensed Business Units example "Digital Advice"; Vendor Type descriptions of the intermediary datasets; SUMMARY in `enrich_14.py`; this file's header, build line, sources, design notes, unverified list, SME questions 2 and 4, next steps 2 and 4 and overlap 4.

**Re-pointed.** "02 Client & Customer" reads "02 Client & Household" (overview Scope, REL, Consuming Business Domain values and SUMMARY); "01 Investment Product" reads "01 Investment Product & Service Offering" in the Consuming Business Domain list; the Target Concept example no longer names the wholesale 02 Financial Professional Profile (a 05 role profile from W4, CW-023); the Entitlement REL holder reads Employee (20 Human Capital: EMP-) instead of the stale "03 Sales: EMP-, pending workforce master". Party references resolve unchanged (CW-021).

**Added (plan section 5.1, CW-914).** Real-time quote entitlements, account aggregation data and planning data:
- Entitlement: Entitled Client (Reference (Party), PII). Entitlement grain and group text now read user, client subscriber or application.
- New object Market Data Subscriber (object group Market Data Subscribers; grain client subscriber x status effective date): Subscriber Client, Market Data Subscriber Status (CDE; new local list Professional, Non-Professional, aligned to the CTA / OPRA definition), Subscriber Status Attested Date, Subscriber Status Effective From. The status is a property of the client, held once per client and read by every entitlement the client holds (review fix pass).
- Values: Entitlement Holder Type Client Subscriber; Entitlement Type Client Real-Time Quote Display; Declaration Type Exchange Subscriber Report; Vendor Type Exchange & Quote Provider, Account Aggregation Provider, Planning Data Provider; Dataset Subject Area Real-Time Market Data, Account Aggregation Data, Financial Planning Data; Consuming Business Domain 45 Financial Planning & Advice.
- Sources: SEC Regulation S-P; CCPA as amended by the CPRA; CTA and UTP plans with OPRA and the exchange subscriber agreements.

**IDs.** The removed ICT Third-Party Register Entry was the last object of Vendor Risk & Resilience, so no other object or attribute code there changes. Attribute IDs renumber in Index & Benchmark Licensing (after Index Use Type) and in Entitlements & Access (after Entitled User); Market Data Subscriber is appended as the family's last object.

**Left for later stages (NOTES in the proposals file).** References to 05 (data-sharing agreements with distribution partners, AGR-), 06 (FEED-, declared AUM), 03 (consultant database submissions), 04 (intent signals), 08 (personnel licenses), 10 (allocation methods) and 11 and 12, and the wholesale use cases and values (Advisor Targeting & Segmentation, Territory Design & Potential, Redistribution to Distribution Partners), wait for W2 and W4.

**Open questions (W1b).**
1. Does the firm count client subscribers by login or by account, and is the subscriber agreement acceptance held in 02 (Consent Record) or 15 (for W3, 48 and 49), with only the status and attestation date here?
2. Should account aggregation consent live in 02 (Consent Record) with 14 holding only the license and permitted use?

**Unverified.** The CTA plan URL and the subscriber definitions (confirm); 17 CFR Part 248 Subpart A eCFR path (standard pattern).
