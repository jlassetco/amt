# Source Notes: 15 Account (wealth manager, Draft v0.1, 2026-10-14)

Workbook: `Account_Data_Taxonomy.xlsx`. Content module: `_tools/content/content_15_account.py` (rewritten in place; the wholesale version is at tag `wholesale-v1.0`). Enrichment: `_tools/enrichment/enrich_15.py`. Proposals: `_tools/consolidation/proposals_w1_15.py` (JURISDICTION, CW-915, shared lists, term conflicts, WP0 re-pointing list).
Size: 9 families, 35 objects (21 business objects, 14 attribute groups), 290 attributes, 97 CDEs (33%), 62 code lists, 51 relationships, 30 sources; 51 references, 6 Derived copies, 1 ownership override, 0 unresolved. Fix pass applied on 2026-10-14 (review `00_Program/Rework/Reviews/15_review.md` and program-lead rulings 1-13; see section 2a).

**Perspective.** A hypothetical US wealth manager of the Vanguard type (Wealth_Manager_Rework_Plan.md section 2): direct brokerage on a self-clearing broker-dealer, digital and human advice, proprietary funds and ETFs at an in-house transfer agent, workplace recordkeeping, institutional advisory, a thin intermediary channel and optional trust services. US only (CW-003). Decisions implemented: CW-006, CW-021, CW-024, CW-026, CW-031 to CW-035, CW-039, CW-040; the US-only pass is drafted as CW-915.

## 0. Why this domain exists

For a wealth manager the account is the unit of custody of client assets (49), taxation, advice enrollment, billing and supervision. Brokerage operations, new accounts and retirement services keep the account master: its registration and tax wrapper, who owns it and who may act on it, the agreements and disclosures it was opened under, the features it is approved for (margin, options, sweep, cash management), the advisory program it is enrolled in, its tax certification and distribution status, the instructions that move money in and out of it, and the restrictions on it. The wholesale 15 saw accounts as a transfer agent and recordkeeper see them; the wealth 15 keeps that core and its identifier discipline and is rebuilt around the brokerage and advisory account, which 45 to 50 key on. Holdings, orders, money movement and fees are separate masters (49, 48, 50, 47). Every account kind, including fund-only, participant, trust and institutional separate accounts, is one master here (CW-035).

## 1. Sources consulted

The URLs were composed from the publishers' current site structure and were not opened in this session; the rules and forms are real. Deep links marked "confirm" in the module need checking.

| Source | URL | What it gave us |
|---|---|---|
| FINRA Rules 4512 and 2165 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/4512 | Account record content, principal acceptance of the account (Account Approved By / Date), investment objective per account, temporary holds (Rule 2165: 15 business days, at most 55 in total since the 2022 amendments, Regulatory Notice 22-05; SR-FINRA-2026-018 pending, confirm). |
| SEC Rules 17a-3(a)(17) and 17a-4 | https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.17a-3 | Account record furnished within 30 days of opening and every 36 months (Account Profile Last Furnished Date); retention after closure. |
| Regulation Best Interest (Rule 15l-1) and Form CRS (Rule 17a-14) | https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.15l-1 | Retail customer investment profile (02) and the account profile set against it; disclosures delivered at opening. |
| FINRA Rule 2360 (b)(16) | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2360 | Options approval by a registered options principal, background verification within 15 days, options agreement, ODD delivery. Options levels are firm-defined. |
| Regulation T (12 CFR 220) and FINRA Rule 4210 | https://www.ecfr.gov/current/title-12/chapter-II/subchapter-A/part-220 | Cash, margin and good faith accounts (Reg T Account Type on Account); the 90-day freeze (12 CFR 220.8(c)); portfolio margin (4210(g)). |
| FINRA Regulatory Notices 26-10 and 26-11 (confirm) | https://www.finra.org/rules-guidance/notices/26-10 | Intraday margin standard replacing the day trading margin requirements, pattern day trader designation and USD 25,000 minimum equity; intraday margin level and deficits; effective June 4, 2026, phase-in to October 20, 2027. Found by web search in the fix pass; the notice text was not read. |
| FINRA Rules 2264, 2265, 2270, 2268, 2231, 3210, 4370 | https://www.finra.org/rules-guidance/rulebooks/finra-rules | Margin, extended hours and day-trading disclosures; predispute arbitration clause; statement frequency; duplicate statements to employer member firms; BCP disclosure. |
| FINRA Rules 5130 and 5131 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/5130 | Restricted persons, general exemptions, de minimis, annual verification incl. negative consent; Rule 5131(b) covered executives and directors. |
| SEC Rule 15c3-3(j)(2) | https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.15c3-3 | Sweep vehicles and the notice on changes (Cash Sweep Election). |
| Investment Company Act Rule 3a-4; Form ADV Part 2 (Rule 204-3) | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.3a-4 | Reasonable restrictions, annual contact, discretion; brochure and wrap fee brochure delivery (Program Enrollment). |
| IRS Publications 590-A and 590-B; IRC 408, 408A, 401(a)(9); SECURE Act 2019; SECURE 2.0 | https://www.irs.gov/publications/p590b | IRA types, Roth five-year rule, SIMPLE two-year rule, inherited IRA beneficiary classes, ten-year rule, required beginning date, IRA aggregation. |
| Treas. Reg. 1.401(a)(9)-5, -9 and 1.408-8 | https://www.ecfr.gov/current/title-26/chapter-I/subchapter-A/part-1 | Life expectancy tables, divisors, RMD computation (RMD Record). |
| IRC 529, 530, 223; MSRB Rule G-45 | https://uscode.house.gov | 529, Coverdell and HSA detail; 529 portfolios as municipal fund securities (17 instrument). |
| IRS Form W-9, Publication 1281, IRC 3406 | https://www.irs.gov/forms-pubs/about-form-w-9 | TIN certification, exempt payee and FATCA codes, backup withholding, B- and C-notices. |
| IRS Forms W-8 family, 1042-S, FATCA Form 8966 | https://www.irs.gov/forms-pubs/about-form-w-8-ben | Foreign status, validity, treaty claims, chapter 3 rate. |
| IRS Forms W-4R and W-4P | https://www.irs.gov/forms-pubs/about-form-w-4r | Federal withholding elections on IRA distributions. |
| IRS Forms 5305-A and 5305-RA | https://www.irs.gov/forms-pubs/about-form-5305-a | IRA custodial agreement types. |
| IRC 6045, Treas. Reg. 1.1012-1, Form 1099-B | https://www.irs.gov/forms-pubs/about-form-1099-b | Cost-basis methods and election scopes (average cost for fund and DRIP shares). |
| UTMA / UGMA; Uniform TOD Security Registration Act | https://www.uniformlaws.org (confirm) | Custodial accounts, successor custodian, TOD and per stirpes. |
| ERISA, IRC 401(k), DOL Form 5500 | https://www.dol.gov/agencies/ebsa/laws-and-regulations/laws/erisa | Participant accounts, spousal consent, plan identification. |
| NACHA Operating Rules | https://www.nacha.org/rules | Bank account validation, ABA routing numbers. |
| DTCC NSCC Fund/SERV and Networking; DTCC ACATS; FINRA Rule 11870 | https://www.dtcc.com (confirm deep links) | Networked accounts (IC); account transfers that close an account. |
| SEC Rules 17Ad-7, 17Ad-17, 22c-2, 10b-10 | https://www.ecfr.gov/current/title-17 | Fund-only account records, dormancy, market-timing blocks, confirmations. |
| Regulation D Rule 501; ESIGN Act | https://www.ecfr.gov/current/title-17/chapter-II/part-230/section-230.501 ; https://uscode.house.gov | Investor qualification for feeder subscriptions (02 determination); electronic signatures on agreements. |
| Salesforce FSC; SS&C DST TA2000; FIBO FBC | https://developer.salesforce.com/docs (confirm); https://www.ssctech.com/products/ta2000 ; https://spec.edmcouncil.org/fibo/ | Cross-checks of account, role and fund-account structures. |
| Wholesale 15 module, 16 and 29 modules, the 02 and 01 W1 briefs, plan section 5.2 | local | Kept objects and names, participant and TA boundaries, sibling object names and prefixes. |

## 2. Modeling decisions

- **One account master (CW-035).** Account Type re-cut to Brokerage, Fund-Only, Managed Advisory, Participant, Plan, Fiduciary, Institutional Separate, Omnibus at Transfer Agent, Firm Proprietary and Networked Investor. `Plan Account` was added to the brief's list because the plan-to-participant link and Plan Participant Account.Plan Account need it.
- **No holdings (CW-007).** RMD Prior Year-End Value is a Derived copy of 49; RMD Satisfied Amount and Subscription Funded Amount are Derived copies of 50. Covered Security Indicator moved to the 49 client lot.
- **Account profile vs investor profile (CW-024).** Account Investment Profile is an effective-dated Business Object (account x profile period, keyed by Profile Account) so the history required by SEC Rule 17a-3(a)(17) is kept; each version references the 02 investor profile version in force. Objective, risk, horizon and liquidity cite the 02 scales (External), not copied. The brief made it an attribute group; the lead ruled for versions (ruling 8).
- **Parties on the account (CW-026, ruling 4).** Account Party Role links parties to the account and holds no party-level facts. Parties held elsewhere are not role values: powers of attorney and trusted contacts (02), beneficiaries (Beneficiary Designation), successor custodian (Custodial Account Detail), dealer, branch and rep of record (Intermediary Account Servicing), interested parties (Account Preference.Duplicate Statement Recipient, now multi), trustees and grantors (51 trust roles under Account Registration Detail.Governing Trust), plan sponsor and plan trustee (16 Plan Role Assignment). Plan Participant Account.Participant is a reference to 16 (forced by OWNERSHIP_OVERRIDES); the 16 Participant Plan Membership masters it.
- **Participant balances (ruling 3).** Balances of recordkept participant accounts are mastered in 16, the recordkeeping book of record, not in 15 or 49.
- **Margin (ruling 1, ruling 7).** The pattern day trader regime is not modeled: FINRA replaced it with an intraday margin standard (Regulatory Notice 26-10, effective June 4, 2026; confirm). Account carries Reg T Account Type (cash, margin, good faith), Intraday Margin Standard Indicator and Intraday Margin Requirement Basis; Margin Account Detail keeps portfolio margin and a reference to the margin disclosure delivery. This amends the CW-031 wording (recorded in CW-915).
- **Rule 2165 holds (ruling 10).** A hold on a disbursement is a 50 Money Movement Hold; a hold on securities transactions or on the whole account is a 15 Account Restriction, which references the 02 Vulnerability Concern (link mastered on the 15 side). Account Restriction Type now says why (kind) and Restriction Scope what is blocked.
- **Features (CW-031).** Approver and profile version are on Account Feature (generic for margin, options, fully paid lending). Feature Agreements is multi (account x feature x agreement), so Level 3 and 4 options hold both the options and the margin agreement. Disclosure evidence is held once in Account Disclosure Delivery; Options Approval Detail and Margin Account Detail reference the ODD and margin disclosure deliveries. The wholesale Account Privilege became Feature Type values. Dividend reinvestment is an Account Feature only; the standing-instruction Distribution Option was dropped (ruling 5).
- **Enrollment (CW-032).** Program Enrollment references 01 OFFR-, 45 RCO-, 02 CRX- and an advisory Account Agreement; no model, target or fee. Rule 3a-4 annual contact is recorded.
- **Tax (CW-034).** CRS content removed (CW-915); B-notice count and chapter 3 rate added; the RMD Record is per IRA per year; withholding elections are their own object.
- **Instructions (CW-033).** Initial Funding Transaction, Triggering Transaction and Final Transaction now reference 50 Money Movement; Closing Account Transfer references 49.
- **PII tiers.** Stated in the Notes of each object's first attribute. Special category (CD-344) is flagged only on Account Restriction rows for FINRA Rule 2165 holds and on Source Vulnerability Concern. HSA Coverage Type is PII - financial (coverage tier, no health condition); the Coverdell deadline, which could reveal a special-needs exception, was dropped. Beneficiary Class deliberately does not hold the disability or chronic-illness basis of an eligible designated beneficiary.

### Deviations from the brief

1. Object `Sweep Election` named **Cash Sweep Election**, matching the existing Sweep term-conflict ruling (15 holds the "Cash Sweep Election").
2. **Joint Tenancy Type** and **IRA Type** not modeled: Account Registration Type already carries the tenancy form and the IRA type (the brief adds Community Property, Tenancy by the Entirety, Inherited Roth, SEP and SIMPLE to it), so separate attributes would hold the same fact twice.
3. 529 **designated beneficiary and successor owner** are Account Party Role values only, not attributes of Education & Health Savings Account Detail.
4. **Margin agreement and Form ADV brochure delivered** are reached through Feature Agreements and Account Disclosure Delivery; the ODD and margin disclosure deliveries are referenced from the options and margin groups.
5. **Code lists 62** against a target of 35-45: kept attributes still need about 20 wholesale lists the brief's section 8 omitted (Certification Status, TIN Certification Status, Account Tax Classification, Tax Reporting Regime, Instruction Status, Bank Instruction Purpose, Bank Account Type, Bank Verification Status, Redemption Proceeds Method, Account Opening NIGO Reason, Account Status Reason, Closure Initiator, Restriction Imposed By, Restriction Scope, Beneficiary Type, Beneficiary Relationship, Custodial Statute, Lifecycle Event Source, Participant Account Status, Rule 5130 Status). Tax ID Type, Distribution Option and Account Investment Objective were removed in the fix pass; Agreement Status is now the shared 05 list.
8. **Account Investment Profile** is a Business Object (ruling 8), so the object split is 21 BO / 14 AG instead of 20 / 15.
6. Family names: wholesale names kept where the content is the same (Registration, Ownership & Beneficiaries; Standing Instructions, Bank Instructions & Preferences; Account Lifecycle & Status); "Account Restrictions & Eligibility" and "Tax, Cost Basis & Distributions" instead of the brief's shorter names.
7. Opening Message Reference, Lifecycle Event Message Reference and the ISO 20022 acmt channel were dropped (not a US direct channel).

### Wholesale objects: dropped, kept, re-cut, moved

| Wholesale object | Disposition |
|---|---|
| Account | Kept; Advisory Program Indicator dropped; Carrying Entity, Account Purpose, Account Business Line, Reg T Account Type, Intraday Margin Standard Indicator and Requirement Basis added |
| Account Identifier, Account Hierarchy Link | Kept; scheme and link-type lists re-cut |
| Account Party Role | Kept; role list re-cut (CW-026) |
| Account Registration Detail | Kept, re-cut: Account Investment Objective moved to Account Investment Profile; Associated Person Disclosure Indicator to 02; Governing Trust (51) added |
| Custodial Account Detail, Beneficiary Designation | Kept (Designation Evidence Reference dropped) |
| Platform Program Enrollment | Dropped: Program Enrollment (ENRL-); model to 46; intermediary platform programs to 05 (W4) |
| Intermediary Account Servicing | Kept thin; Nominee Designation removed (CW-915); Omnibus Parent Account removed (Account Hierarchy Link) |
| Institutional Account | Kept; Governing Agreement re-pointed to 39 Contract |
| Plan Participant Account | Kept; Participant Plan Membership (16) added; Participant is a reference to 16; two indicators are Derived copies of 16 |
| Account Tax Certification | Kept; Tax ID Type (02 fact), Electronic Signature Indicator and Certification Document Reference dropped |
| Account Tax Reporting Status | Kept, re-cut: CRS fields and Tax Residence Country removed; B-Notice Count, Chapter 3 Withholding Rate added |
| Cost Basis Election | Kept; Covered Security Indicator moved to 49; Cost Basis Election Scope added |
| Account Standing Instruction | Kept; Bank Instruction Reference dropped (duplicate of Linked Bank Instruction); Distribution Option dropped (DRIP is an Account Feature); Instruction Destination Account added |
| Bank Instruction, Account Preference | Kept; ABA-only routing |
| Account Opening | Kept; Opening Servicing Provider and Opening Message Reference dropped; identity verification, recommendation and principal approval added |
| Account Lifecycle Event, Account Status History, Account Closure | Kept; transaction references re-pointed to 50 and 49; Status Account key added to Account Status History |
| Account Restriction | Kept; types re-cut; Source Vulnerability Concern added |
| Account Privilege | Dropped: Account Feature types |
| Record Metadata | Dropped (CD-160) |
| New | Account Investment Profile, Retirement Account Detail, Education & Health Savings Account Detail, Account Feature, Options Approval Detail, Margin Account Detail, Cash Sweep Election, Account Agreement, Account Disclosure Delivery, Program Enrollment, Alternative Investment Subscription, RMD Record, Retirement Distribution Election, New Issue Eligibility |

The full list of wholesale attribute names dropped, moved or re-typed, for re-pointing the products at WP0, is in `proposals_w1_15.py` NOTES.

## 2a. Review fix pass (2026-10-14)

Applied: both Highs (intraday margin standard replaces the pattern day trader regime; Status Account added to Account Status History), every Medium under the program-lead rulings, and the Lows except these: TIN Certification Status keeps certification and IRS notice states in one list (kept wholesale list read by DP-093; B-Notice Count and Backup Withholding Reason hold the counts and reasons); 'Fortnightly' kept because it is the shared Frequency value (steward 09 asked to rename it); Account Status Reason and Account Closure Reason overlap and the three 'who' lists (Restriction Imposed By, Closure Initiator, Lifecycle Event Source) were not merged, logged as SHARED_CANDIDATES; the proposals file name is reported to the lead, not changed.

## 3. Unverified items (confirm)

1. Deep links for uniformlaws.org, DTCC ACATS and NSCC pages, and the Salesforce FSC data model were not opened.
2. RMD required beginning age under SECURE 2.0 (73, rising to 75) and the final RMD regulations' treatment of the ten-year rule with annual distributions: confirm current Treasury guidance.
3. FINRA Rule 4210 intraday margin standard (Regulatory Notice 26-10): effective June 4, 2026, phase-in to October 20, 2027, and the requirement-basis values; confirm against the notice and Attachment A. FINRA Rule 2165: current 55-business-day maximum and the pending SR-FINRA-2026-018 (proposed 145 business days and Rule 2166); confirm.
3a. FINRA Rule 2360(b)(16) timing (verification within 15 days of approval) and Rule 5130 annual verification and negative consent wording: confirm against the current rulebook.
4. The 24% backup withholding rate and the W-8 validity period are current-law values.
5. Fully paid lending disclosure (FINRA Rule 4330(b)) is listed without a rule number in the Disclosure Type list pending confirmation.
6. Regulation S-P amendments (2024) compliance dates for the initial privacy notice and incident notice: status moving, confirm.

## 4. Open questions for SMEs (tailoring levers; reference default in italics)

1. Enrollment per account or per household? *Per account*; lever: add a household reference to Program Enrollment.
2. Which features does the firm offer? *All Feature Type values*; lever: drop margin, options or fully paid lending (plan section 15 item 3).
3. Does a fund-only account convert in place or by re-registration? *Re-registration (Predecessor to Successor Account link)*.
4. Is the IRA custodian the broker-dealer or the trust company? *A named internal entity per account (IRA Custodian Entity)*.
5. Which disclosures gate opening? *Form CRS, customer agreement, and each feature's disclosure before approval*.
6. Is the RMD computed for every IRA? *Yes, with aggregation flagged*.
7. Is tax-loss harvesting an account feature or a 46 setting? *46*.
8. Are feeder subscriptions held in the brokerage account? *Yes*.
9. Which legacy TA accounts remain? *Fund-only accounts stay open; no new ones*.
10. Are options levels four, as modeled, or the firm's own scheme? *Four firm-defined levels*.
11. Are client-trustee revocable trusts recorded in 51 when the optional trust line is not adopted? *Yes, as a 51 Trust with its trust roles*; lever: without 51, record trustees as Primary Owner roles.

## 5. Suggested validation steps

1. Walk one account of each Account Type through opening, a feature approval, an enrollment and closure with Brokerage Operations.
2. Reconcile Account Role Type with 02 Party Role Type and Authority Grant types once the 02 module lands.
3. Confirm with 49 and 50 the Derived copies and the Money Movement and Account Transfer keys (MMT-, CAX-, SWP-, PBK-).
4. Re-point the products listed in proposals NOTES at WP0 and rerun the W1 gate (every Reference (Account ...) resolves).
