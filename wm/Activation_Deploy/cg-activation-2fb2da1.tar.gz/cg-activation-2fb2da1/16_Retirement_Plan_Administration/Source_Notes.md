# Source Notes: 16 Retirement Plan Administration (Draft v0.1, wealth manager W3 adaptation, 2026-10-15)

Workbook: `Retirement_Plan_Administration_Data_Taxonomy.xlsx`. Content module: `_tools/content/content_16_retirement_plan_administration.py` (adapted in place). Enrichment: `_tools/enrichment/enrich_16.py`. Proposals: `_tools/consolidation/proposals_w3_16.py` (CW-916). Keys: `_tools/data_models/keys_g6_15_16.py` (16 region; RP-BAL and RP-ROL keys to add at WP2).
Size (built, after the 16_review.md fix pass): 13 families, 55 objects (41 business objects, 14 attribute groups), 354 attributes, 118 CDEs (33%), 74 code lists, 88 relationships, 33 sources. First W3 draft: 350 attributes, 110 CDEs. Before the adaptation: 11 families, 43 objects, 275 attributes, 84 CDEs, 59 code lists, 55 relationships, 25 sources (Record Metadata excluded in all).

**Perspective.** The firm is a US wealth manager that serves investors directly (Wealth manager (direct) | Scope: US). Retirement Services is its in-house defined contribution recordkeeper for plans of every size: it administers 401(k), 403(b), 457(b), profit-sharing, SIMPLE IRA and SEP programs and keeps each participant's balance by money source and investment option, the participant book of record (CW-915, CW-125). The workplace line is also the firm's largest source of new direct clients: separating participants roll into the firm's IRAs and advice programs (CW-126), and participant managed accounts run inside plans (CW-127). This domain covers plan administration for the plans the firm recordkeeps, where the firm is the system of record. Sections 1 to 6 below are the wholesale notes, kept as the record and corrected where the wealth model changed a boundary; section 7 records the W3 adaptation.

## 1. Sources consulted

| Source | URL | What it gave us |
|---|---|---|
| ERISA Title I (29 U.S.C. ch. 18) | https://www.dol.gov/agencies/ebsa/laws-and-regulations/laws/erisa | Fiduciary definitions 3(16), 3(21), 3(38) and 402(a) named fiduciary for the Plan Fiduciary & Service Role list; eligibility (202), vesting (203), spousal consent (205), QDRO procedures and segregation (206(d)(3)), annual report and audit requirement (103), blackout notice (101(i)), benefit statements and lifetime income illustrations (105). |
| IRC 401(k), 401(m), 402(g), 402A, 408(k), 408(p), 410, 411, 414(q)/(v)/(w)/414A, 415, 416, 72(p), 401(a)(9), 401(a)(31), 402(f), 3405 | https://www.law.cornell.edu/uscode/text/26/401 (and sibling sections) | Plan type detail, safe harbor designs, eligibility and entry, vesting schedules (3-year cliff, 6-year graded, 2-year QACA cliff), catch-up types, HCE and key employee flags, deferral and annual additions limits, loan limits and terms, RMD required beginning date, mandatory 20% withholding, direct rollover and automatic rollover, 402(f) notice window. |
| Treasury Regulations 1.401(k)-1(d)(3) (hardship), 1.401(k)-2 (ADP/ACP correction), 1.72(p)-1 (loan cure period, deemed distribution, offset), 1.401(a)(9)-5 and -9 (RMD and life expectancy), 1.401-7 (forfeitures) | https://www.ecfr.gov/current/title-26/chapter-I/subchapter-A/part-1 | Hardship safe harbor reasons (Hardship Reason list, restored at W3 as special category data), cure period end date, deemed distribution date, forfeiture use and the 12-month use deadline (IRS proposed regulations 2023; status to confirm). |
| DOL 29 CFR 2550.404a-5 | https://www.ecfr.gov/current/title-29/subtitle-B/chapter-XXV/subchapter-F/part-2550/section-2550.404a-5 | Initial, annual (at least every 14 months) and quarterly participant fee disclosures; 30 to 90 day change notice; fee allocation (pro rata, per capita, individual). Drove the Plan Notice Type and Fee Payer lists and the Fund Change Event. |
| DOL 29 CFR 2550.408b-2 | https://www.ecfr.gov/current/title-29/section-2550.408b-2 | Covered service provider disclosure to the responsible plan fiduciary (Plan Notice Type, Plan Fee Component). |
| DOL 29 CFR 2550.404c-5 (QDIA) | https://www.ecfr.gov/current/title-29/section-2550.404c-5 | QDIA role on the menu, default election indicator and QDIA notice. The QDIA Type list moved from 02 into 16 at W3 (CW-023) and gained the grandfathered stable value product (404c-5(e)(4)(v)); 404c-5(e)(3) limits a managed account QDIA to a 3(38) manager, trustee or sponsor. |
| DOL 29 CFR 2520 (2520.101-3 blackout notice; 2520.103-1, 2520.104a-5 Form 5500; 2520.104-46 small plan audit waiver) | https://www.ecfr.gov/current/title-29/subtitle-B/chapter-XXV/subchapter-C/part-2520 | Blackout notice 30 to 60 days before the blackout; Form 5500 due date (last day of the seventh month after plan year end); the 100-participant large plan threshold now counted on participants with account balances (2023 plan year forms onward). |
| DOL 29 CFR 2510.3-102 | https://www.ecfr.gov/current/title-29/section-2510.3-102 | Participant contributions become plan assets when they can reasonably be segregated; 7-business-day safe harbor for plans with fewer than 100 participants. Drove Deposit Deadline (dropped for size; Late Deposit Indicator kept) and the Late Deposit Case. |
| DOL 29 CFR 2530.200b-2 and -3 | https://www.ecfr.gov/current/title-29/section-2530.200b-2 | Hour of service, equivalencies and elapsed time (Service Crediting Method, Hours of Service Credited). |
| Form 5500 Series, instructions and EFAST2 | https://www.dol.gov/agencies/ebsa/employers-and-advisers/plan-administration-and-compliance/reporting-and-filing/form-5500 ; https://www.efast.dol.gov | Form 5500, 5500-SF, 5500-EZ, schedules, Schedule H/I line 4a late deposits, electronic signature options and acknowledgments (Government Filing, Form 5500 Detail). |
| IRS Form 8955-SSA | https://www.irs.gov/retirement-plans/form-8955-ssa-resources | Entry codes A, B, C, D and deferred vested benefit reporting (Separated Participant Entry). |
| IRS Form 1099-R instructions, Form W-4R | https://www.irs.gov/instructions/i1099r ; https://www.irs.gov/forms-pubs/about-form-w-4r | Box 7 distribution codes (subset: 1, 2, 3, 4, 7, 8, B, E, G, H, L, M, P), taxable amount, withholding elections (Tax Withholding & 1099-R Detail). |
| IRS EPCRS, Rev. Proc. 2021-30; IRS 401(k) Plan Fix-It Guide | https://www.irs.gov/retirement-plans/epcrs-overview ; https://www.irs.gov/retirement-plans/401k-plan-fix-it-guide | SCP, VCP (Form 8950), Audit CAP; failure types and Appendix A/B correction methods (Plan Correction, Plan Failure Type, Correction Program). SECURE 2.0 section 305 expanded self-correction. |
| DOL Voluntary Fiduciary Correction Program and Online Calculator | https://www.dol.gov/agencies/ebsa/employers-and-advisers/plan-administration-and-compliance/correction-programs/vfcp | Late deposit correction, lost earnings calculation, 2025 VFCP update self-correction component (effective March 17, 2025; confirm) for lost earnings of USD 1,000 or less within 180 days (Late Deposit Case). |
| SECURE 2.0 Act of 2022 (Division T, Pub. L. 117-328) and Senate Finance section-by-section summary | https://www.congress.gov/bill/117th-congress/house-bill/2617 ; https://www.finance.senate.gov/imo/media/doc/secure_2.0_act_of_2022_section_by_section_summary.pdf | Sections used: 101 mandatory automatic enrollment for new plans (from 2025), 107 RMD age 73/75, 109 higher catch-up at 60 to 63, 115 emergency personal expense distributions, 116 additional SIMPLE nonelective, 121 Starter 401(k), 125 long-term part-time employees (two years from 2025), 304 cash-out threshold USD 7,000, 305 self-correction, 312 hardship self-certification, 601 Roth SIMPLE and SEP, 603 Roth catch-up for high earners (from 2026 under final regulations). |
| IRS Notice 2024-2 and COLA limits | https://www.irs.gov/retirement-plans/cola-increases-for-dollar-limitations-on-benefits-and-contributions | SECURE 2.0 amendment deadline (December 31, 2026 for most non-governmental plans); annual 402(g), 415(c), 401(a)(17), 414(v) and SIMPLE limits. The USD 24,500 402(g) example is the 2026 limit; confirm each year. |
| IRS pre-approved plan program, Rev. Proc. 2017-41 | https://www.irs.gov/retirement-plans/pre-approved-retirement-plans | Opinion letters, Cycle 3 DC restatement window (August 1, 2020 to July 31, 2022), adoption agreements (Plan Document). |
| IRS SIMPLE IRA and SEP guidance, Forms 5304-SIMPLE, 5305-SIMPLE, 5305-SEP | https://www.irs.gov/retirement-plans/plan-sponsor/simple-ira-plan ; https://www.irs.gov/retirement-plans/plan-sponsor/simplified-employee-pension-plan-sep | 100-employee limit, 3% match or 2% nonelective, 60-day election notice, model forms (SIMPLE IRA & SEP Program Detail). |
| IRS plan termination guidance, Form 5310, Rev. Rul. 89-87; DOL FAB 2014-01; PBGC Missing Participants Program | https://www.irs.gov/retirement-plans/plan-sponsor/terminating-a-retirement-plan ; https://www.pbgc.gov/prac/missing-participants-program | Full vesting on termination, distribution within one year, missing participant search steps and default IRA, PBGC program for terminated DC plans (Plan Termination). |
| DOL QDRO guidance booklet | https://www.dol.gov/agencies/ebsa/about-ebsa/our-activities/resource-center/publications/qdros | Qualification procedures, 18-month segregation, alternate payee rights (QDRO Case). |
| SPARK Institute data standards and best practices | https://www.sparkinstitute.org | Participant status and employment event vocabulary, 180- and 360-degree payroll integration, conversion data sets, cybersecurity best practices. The detailed SPARK data layouts are member materials and were not opened. |
| DTCC Retirement Plan Services | https://www.dtcc.com (deep link to confirm; the wholesale path returns 404) | Trading and settlement between recordkeepers and fund companies for third-party funds on plan menus; the firm's own funds net into plan-level 29 Fund Orders. |
| AICPA SAS 136 and Employee Benefit Plan Audit Quality Center; SOC 1 | https://www.aicpa-cima.com/topic/audit-assurance/employee-benefit-plan-audit | ERISA section 103(a)(3)(C) audit (formerly limited scope), auditor opinions, service organization reports (Plan Audit). |
| Sibling modules 02, 03, 04, 05, 06, 11, 12, 13, 15, 29, 39, 45, 46, 47, 50 and the conventions document | local | Boundaries and reused patterns (D() helper, SRC 7-tuples, key registry conventions). |

## 2. Design and boundary decisions

- **Reference, don't redefine.** The plan identity, sponsor, participants, beneficiaries, alternate payees, trustees, fiduciaries (including a Plan Fiduciary Committee), TPAs, external advisors of record, payroll providers, auditors and other recordkeepers are 02 parties. Participant, receiving IRA and alternate payee accounts are 15 (`ACC-`), and 15 holds no amount (CW-915). Share classes, model portfolios and service offerings are 01; unit values 27; plan-level fund orders 29; trade proposals 46; client fee schedules 47; advice engagements 45; interactions, statements and tax forms 13; service contracts 39; complaints 08; employees 20; advisors 03.
- **Participant book of record (CW-915, CW-125).** Participant Balance (membership x money source x option x valuation date, with units, unit value applied, market value and vested amount) and Participant Ledger Posting (PLPST-, with units, unit value and amount) are mastered here. Unit values are Derived copies of 27 for the firm's funds and CITs, so market value re-performs against the 29 register. The five wholesale 06 transaction references keep their names and are typed Participant Ledger Posting; Vested Balance by Source references Participant Balance. Plan assets (Retirement Plan Profile, Form 5500 Detail) are calculated from Participant Balance plus outstanding participant loan principal.
- **Profiles (CW-023, CW-127).** Recordkeeper Profile covers any recordkeeper the firm deals with (own entity, conversion counterparties, third-party recordkeepers carrying its funds, incumbents of prospect plans), read by 05 and 06. Plan Service Provider and Retirement Plan Profile cover firm-recordkept plans only; other plans' statistics and Schedule C providers are 11 Plan Market Record. Plan Sponsor Profile is administrative; servicing and reporting are 12.
- **15 Account vs 16 Membership.** 15 masters the Plan Participant Account, the Beneficiary Designation (`ABD-`), bank instructions and restrictions; 16 masters the Participant Plan Membership (eligibility, entry, enrollment, HCE status, elections) and the balances. Both store the membership-to-account link; the proposed authoritative side is 15 (NOTES).
- **Money source is a dimension, not an object.** Contribution Source keys contributions, balances, postings, vesting, forfeitures and distributions; it includes the SECURE 2.0 sources (Roth employer contributions, PLESA, Roth SIMPLE / SEP) and in-plan Roth rollover amounts. Candidate shared list, steward 16.
- **Contributions.** A contribution (CONT-) is membership x source x receipt; the payroll batch is filled only for payroll contributions, so incoming rollovers, automatic portability transfers and corrective contributions have valid rows (row rule).
- **Exchanges and managed accounts (CW-127).** Participant Investment Transfer (PEXC-) is one movement from one option to another. Several 46 Trade Proposals net into one transfer; the link is held on the 46 side only (n : 1). Plan Managed Account Service says the plan offers the service; a default (QDIA) row requires a 3(38) manager, trustee or sponsor fiduciary basis (29 CFR 2550.404c-5(e)(3)).
- **Rollover and hand-off (CW-045, CW-126).** Participant Retail Hand-Off holds trigger, consent to contact (firm policy; Regulation S-AM requires only notice and opt-out), referral to a 45 engagement or 03 advisor, outcome by destination, the linked Distribution Request and the calculated rollover amount. Distributions are paid on the recordkeeper's rail (CW-107); the receipt into a firm IRA is a 50 money movement. 04 copies the "Rollover Completed" date from 50 today.
- **13 Documents and communications.** Plan notices are 16 obligations with deadline and delivery evidence; 13 delivers them (`COMM-`). Statements and the Form 1099-R are 13 `STMT-` documents built from 16 detail.
- **Rule vs event.** Plan provisions are attribute groups of the Plan Document; elections and processing records are separate, effective-dated business objects.
- **Government Filing is one object** with Form 5500 Detail and Separated Participant Entry as attribute groups (`GFIL-`).
- **Prefixes.** The 31 wholesale 16 prefixes are kept; PLPST-, PEXC- and PRTHO- are reserved (CW-128). PFEE- is now an identifier (Plan Fee Line ID).
- **Size.** 354 attributes against the 360 band ruled by the program lead; CDEs 33%, including every composite-key part.

## 3. Unverified items

1. Composed ecfr.gov and irs.gov deep links; the DTCC deep link (the wholesale path returns 404).
2. The IRS forfeiture regulations (proposed 2023): confirm status and transition rule.
3. 2026 limits (402(g) USD 24,500; cash-out threshold USD 7,000).
4. Roth catch-up (section 603) implementation date under the 2025 final regulations.
5. SPARK Institute layouts are member materials; vocabulary from public summaries.
6. EFAST2 filing status vocabulary quoted from memory.
7. Form 5500 line 8a plan characteristic codes 2A to 2T (from memory).
8. DOL 2025 VFCP update effective date (March 17, 2025, per the reviewer).
9. PTE 2020-02 status after the 2024 amendments (boundary only).

## 4. SME questions (tailoring levers; reference default first)

See section 7.7 for the W3 levers. Kept from the wholesale notes, rewritten for the adapted domain:
- **Programs in scope:** which recordkeeping programs run today? *Default:* the Recordkeeping Program list (small, mid and large plans, TPA-partnered, SIMPLE IRA, SEP, 403(b), PEP).
- **Fiduciary services:** does an affiliate act as 3(16) administrator, directed trustee or 3(38) manager? *Default:* 3(38) for the managed account service only; other roles third parties.
- **SIMPLE and SEP coverage:** on the recordkeeping platform or as IRAs? *Default:* recordkeeping platform; *lever:* move the group to 15.
- **Payroll integration:** does the payroll feed deliver employment events, compensation and hours? *Default:* yes for 360-degree integrations.
- **Compliance testing and Form 5500:** firm or TPA? *Default:* the firm for bundled programs, the TPA for TPA-partnered ones.
- **Participant balances and ledger:** confirm that the recordkeeping platform holds the participant ledger at money source x option grain and that balances reconcile daily to the plan's 29 Share Register Balance. *Default:* yes.
- **Tax reporting (13):** Form 1099-R for plans produced by the same 13 processes as IRA tax forms. *Default:* yes.

## 5. Overlaps with other domains (for consolidation)

| Item | Domains | Proposal |
|---|---|---|
| Retirement plan identity and statistics | 02 (thin Retirement Plan), 16 (Retirement Plan Profile, recordkept plans), 11 (Plan Market Record, all plans) | 02 identity; 16 recordkept-plan statistics; 11 public data for other plans |
| Recordkeepers and service providers | 16 (Recordkeeper Profile, any recordkeeper; Plan Service Provider, recordkept plans), 05, 06 | 05 and 06 read the 16 Recordkeeper Profile; prospect plan providers come from 11 |
| Participant balances | 16 (Participant Balance), 15 (no amount), 49 (windows and IRAs), 29 (plan omnibus), 06 (view) | 16 masters; 29 reconciles the omnibus |
| Exchanges from managed accounts | 46 (Trade Proposal), 16 (Participant Investment Transfer) | Link held by 46, n : 1 |
| Rollover | 16 (distribution, hand-off), 45 (analysis), 50 (receipt), 04 (milestone), 06 (capture rate) | Split by fact (CW-126) |
| Plan and managed account fees | 16 (Plan Fee Schedule), 47 (bills by Service Arrangement; participant fee schedule) | CW-051 |
| Beneficiary designation | 15 (ABD-), 16 (spousal consent) | 15 masters |
| Contribution Source, QDIA Type, Hand-Off Outcome | 16, 15, 45, 04, 06 | Shared candidates (proposals) |
| Frequency, Case Status, Reconciliation Status | 09, 06 | Shared memberships registered (proposals) |

## 6. Next steps

1. SME validation with Retirement Services, Plan Compliance, Participant Services, the rollover and advice teams, the transfer agent, ERISA counsel and the TPA partner team.
2. Register PLPST-, PEXC-, PRTHO- (and CLFEE- for 47) and remove the temporary OWNERSHIP_OVERRIDES.
3. Agree with 46 the n : 1 release link, with 29 the netting and omnibus reconciliation, with 04 the rollover milestone source and with 15 the authoritative membership-account link.
4. Map attributes to the recordkeeping platform, the participant ledger, payroll feeds, testing engine, Form 5500 software and EFAST2.
5. Verify section 3 and map ERISA and IRC attributes to exact paragraphs and Form 5500 line numbers.
6. Re-point DP-094 to DP-096, the f4 data model and the key registry per proposals NOTES.

## 7. Wealth model adaptation (W3, CW-006; CW-125 to CW-127, CW-916)

### 7.1 Why the domain changed

For the wealth manager the recordkeeper is a core business line (WR), not a side business. The adapted 16 keeps the recordkeeping core by name, becomes the participant book of record (CW-915, CW-125), takes in the sponsor, recordkeeper, provider and plan profiles from 02 (CW-023, CW-127), adds participant distribution and service elections, the plan managed account service, and the rollover capture and participant-to-retail hand-off that acceptance question 10 measures (CW-126).

### 7.2 Sources added (W3)

| Source | URL | What it gave us |
|---|---|---|
| IRC 402 and 402A | https://www.law.cornell.edu/uscode/text/26/402 | Eligible rollover distributions, 402(f) notice, Roth basis, in-plan Roth conversions (402A(c)(4)) |
| Treas. Reg. 1.401(a)(31)-1 (Q&A-14) and 1.402(c)-2 | https://www.ecfr.gov/current/title-26/chapter-I/subchapter-A/part-1 | Reasonable conclusion that an incoming rollover is valid; eligibility of distributions |
| IRS Rev. Rul. 2014-9 | https://www.irs.gov/irb/2014-17_IRB (confirm path) | Simplified due diligence for incoming rollovers (Form 5500 line 8a of the distributing plan; IRA certification). Verified by search: the ruling exists and says this. |
| IRS Notice 2020-62, modified by Notice 2026-13 | https://www.irs.gov/irb/2020-35_IRB ; https://www.irs.gov/pub/irs-drop/n-26-13.pdf | Safe harbor 402(f) explanations; Notice 2026-13 (January 2026) modifies both for SECURE 2.0 (verified by the reviewer) |
| DOL 29 CFR 2550.404a-2 | https://www.ecfr.gov/current/title-29/section-2550.404a-2 | Automatic rollover safe harbor for mandatory distributions |
| ERISA 408(g), 29 CFR 2550.408g-1 | https://www.ecfr.gov/current/title-29/section-2550.408g-1 | Eligible investment advice arrangements (level fee, computer model) for Managed Account Fiduciary Basis |
| DOL Advisory Opinion 2001-09A | https://www.dol.gov/agencies/ebsa/about-ebsa/our-activities/resource-center/advisory-opinions/2001-09a | Independent financial expert advice programs (verified by search) |
| DOL PTE 2020-02 | https://www.dol.gov/agencies/ebsa/about-ebsa/our-activities/resource-center/faqs/new-fiduciary-advice-exemption (85 FR 82798) | Boundary only: the rollover evidence is 45 |
| DOL VFCP 2025 update | https://www.dol.gov/agencies/ebsa/employers-and-advisers/plan-administration-and-compliance/correction-programs/vfcp | Self-correction component for late deposits (replaces the SECURE 2.0 section 305 citation; confirm effective date) |
| SEC Rules 22c-1 and 22c-2 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.22c-2 | Trade-date pricing of plan exchanges; frequent-trading restrictions |
| SECURE 2.0 sections 120, 127, 604 (in the kept SECURE 2.0 source) | https://www.congress.gov/bill/117th-congress/house-bill/2617 | Automatic portability (120), pension-linked emergency savings accounts (127), optional Roth employer contributions (604), Roth SIMPLE / SEP (601): verified by the reviewer |
| DOL Form 5500 instructions, line 8a | https://www.dol.gov/agencies/ebsa/employers-and-advisers/plan-administration-and-compliance/reporting-and-filing/form-5500 | Plan Characteristic Code list (2A to 2T subset, from memory; confirm against the current year) |

Removed: DCAM (cited only by the excluded Record Metadata). The DTCC Retirement Plan Services source is re-described (no 06 transaction references remain) and its deep link is marked confirm.

### 7.3 Wholesale objects dropped, kept, re-cut and moved

| Wholesale object or attribute | Disposition | Now |
|---|---|---|
| All 43 objects of the eleven kept families | Kept by name | Kinds, grains and PII flags kept; participant-level objects state their PII tier |
| Record Metadata (family RP-DMG) | Dropped | Governance metadata is 21 (CD-160, CW-020); Data Quality Status, Confidentiality Classification and DCAM go with it |
| Contribution Record.Posting Transaction, Participant Loan.Disbursement Transaction, Forfeiture Record.Forfeiture Transaction, Distribution Request.Settlement Transactions, Fund Change Event.Mapping Transactions | Re-cut | Names kept, typed Reference (Participant Ledger Posting) (CW-125) |
| Vested Balance by Source.Source Position (06 POS-) | Re-cut, renamed | Source Participant Balance, Reference (Participant Balance) (multi). Renamed because a bare 'Position' fails the books-of-record test (checklist 1); readers in proposals NOTES |
| Service Arrangement.Governing Agreement (05 Agreement) | Re-cut | Reference (Contract, 39) (CW-127) |
| Form 5500 Detail.Total Plan Assets at Year End, Participants with Balances at Year End | Kept, flagged | Calculated from Participant Balance (16); the wholesale DERIVED entry to 06 removed |
| Plan Fee Schedule | Kept, keyed | Plan Fee Line ID (PFEE-, the registered prefix that 45 already uses) added so 47 and 45 can reference a line |
| Distribution Request | Kept, extended | Hardship Reason (special category), Receiving Account (15), Originating Hand-Off; Rollover Direction kept |
| Investment Election.Automatic Rebalancing Frequency | Kept | Participant-directed only; executed as Participant Investment Transfers; managed accounts rebalance in 46 |
| 02 Recordkeeper Profile, Plan Service Provider | Moved in, names kept | Recordkeeper Profile (BO keyed by the recordkeeper party); Plan Service Provider (AG of Plan Role Assignment: Schedule C codes). The 02 Service Provider, Plan Service Role and service dates fold into Plan Role Assignment (no second role record) |
| 02 Retirement Plan statistics | Moved in | Retirement Plan Profile (plan x plan year): plan characteristic codes, plan assets, QDIA type. Active Participants, Form 5500 Filing Year and Fiduciary Investment Adviser Type not restored (the plan year, the Form 5500 Detail counts and the 3(21)/3(38) Plan Role Assignment hold them). UK Pension Scheme Registry Number not restored (JURISDICTION) |

New objects (12): Plan Sponsor Profile, Recordkeeper Profile, Retirement Plan Profile, Plan Service Provider (AG), Plan Managed Account Service, Participant Distribution Election, Participant Service Election, Rollover Contribution Detail (AG), Participant Balance, Participant Ledger Posting (PLPST-), Participant Investment Transfer (PEXC-), Participant Retail Hand-Off (PRTHO-). New families: Participant Balances & Ledger (RP-BAL), Rollover Capture & Retail Hand-Off (RP-ROL); RP-FID renamed "Plan Sponsor, Fiduciaries, Service Roles & Fees".

### 7.4 Modeling decisions (W3)

- **Participant Balance** is membership x money source x plan investment option x valuation date, with units, unit value applied (Derived copy of 27 for the firm's funds and CITs), market value and vested amount. It is never called a holding or position. Balances are the postings up to the valuation date; each posting carries units, its unit value and amount. Postings net into plan-level 29 Fund Orders per option and trade date; the reconciliation to the plan's 29 Share Register Balance is 29's.
- **Participant Investment Transfer (PEXC-)** is the "participant exchange" that 46 releases trade proposals into (46 references it by this name). Grain: one movement from one option to another. Several 46 Trade Proposals (the sells and buys of one rebalance) net into one transfer; the link is held on the 46 side only (Released Participant Investment Transfer, n : 1), so 16 holds no pointer to 46 (fix-pass ruling 1). Excessive-trading rejection is a Transfer Status value (SEC Rule 22c-2).
- **Managed accounts in plan (boundary ruled per brief section 4 rule 4):** 16 Plan Managed Account Service (plan x 01 offering x period: availability, fiduciary basis, the 47 fee schedule that prices it); 15 Program Enrollment on the participant account; 46 Model Assignment at participant-account grain, which reads balances, deferral rates and salary as Derived copies of 16; 46 trade proposals executed here as Participant Investment Transfers. The fiduciary itself is a 3(38) or 3(21) Plan Role Assignment, so the service holds no fiduciary party. Participant fee rates are 47 (CW-051); the Plan Fee Component value "Managed Account Fee" is kept only for plan-paid charges.
- **Rollover and hand-off:** the hand-off holds trigger, consent to contact (02 Consent Record; requiring consent is firm policy, Regulation S-AM requires notice and opt-out), the referral to a 45 Advice Engagement or a 03 advisor, the outcome by destination, the linked Distribution Request and the rollover amount (calculated from it), as CW-126 lists. Distribution Request.Originating Hand-Off is the inverse link and must agree. No cost comparison, best-interest reason or fiduciary acknowledgment is held (45); no supervisory review (08). Distributions are paid on the recordkeeper's rail (CW-107); the receipt into a firm IRA is a 50 Money Movement that references DIST-.
- **Elections here, interactions in 13:** the new distribution and service elections cite the 13 Contact Center Interaction as their source. 15 Retirement Distribution Election (IRAs) and 16 Participant Distribution Election (plan memberships) are split by account type, as are 15 RMD Record and 16 RMD Calculation.
- **Personal data:** participant-level objects are "PII - financial" (membership and employment events "PII - identity"; QDRO also identity for the alternate payee); Distribution Request.Hardship Reason is "PII - special category (CD-344)", restricted and read as aggregates. Profiles, menu and service objects are "No PII".
- **Shared lists:** Frequency, Case Status and Reconciliation Status re-cut to the shared labels and registered as memberships (Semi-Monthly and Per Payroll proposed for Frequency). Business Line, Record Status and Approval Status are not used: no 16 attribute needs them. Tax Form Type (steward 15) holds the W-9 / W-8 family and does not apply to 1099-R.

### 7.5 Deviations from the brief

1. Proposals file named `proposals_w3_16.py` (the assignment), not `proposals_16.py` (brief section 1).
2. Size: held to the program-lead band (350 at the first draft, 360 at the fix pass; now 354). Restored at the fix pass: unit value on balances and postings, the hand-off's referred advisor, linked distribution and rollover amount. Still left out, as levers: Participant Balance Basis, installment amount and payment method preference on Participant Distribution Election, payroll provider (a Plan Role Assignment) and payroll frequency on Plan Sponsor Profile, market segment, active participants and fiduciary adviser type on Retirement Plan Profile (Form 5500 Detail and Plan Role Assignment hold the last two), receiving business line, Roth five-year start year, and a reversed-posting link.
3. Code lists: 74 against the brief's 52 to 58. The brief's range did not add its own 13 new lists; 15 were added (Hardship Reason and Managed Account Availability beyond the brief's set, QDIA Type moved from 02; Participant Balance Basis not used).
4. Vested Balance by Source.Source Position renamed (section 7.3).
5. Controlled group: modeled as Controlled Group Members (multi) on the sponsor profile rather than an indicator, because the IRC 414(b)/(c) testing group is not the 02 legal entity hierarchy.

### 7.6 Unverified items (W3)

1. Form 5500 line 8a plan characteristic codes 2A to 2T are from memory; confirm wording and that 2N to 2Q (not used) are unchanged.
2. SECURE 2.0 section numbers 120, 127, 601 and 604: verified by the reviewer; closed. DOL and IRS guidance on PLESAs (2024) not cited.
3. IRS Notice 2026-13 (January 2026) modifies the Notice 2020-62 explanations: verified by the reviewer; closed.
4. DOL PTE 2020-02 status after the 2024 Retirement Security Rule amendments and litigation: confirm (boundary only).
5. Rev. Rul. 2014-9 is at 2014-17 I.R.B. 975 (verified by the reviewer); the PTE 2020-02 link now points to the DOL FAQ page; the DTCC deep link is to confirm. 6. Late Deposit Correction Program now cites the DOL VFCP 2025 update (effective March 17, 2025; confirm) instead of SECURE 2.0 section 305.

### 7.7 Open questions for SMEs (tailoring levers; reference default first)

1. Outsourced recordkeeping functions (TPA testing, Form 5500 preparation, distribution processing)? *Default:* in house, with TPA-partnered programs as a Recordkeeping Program value. *Lever:* outsourced functions become received records with the provider as a Plan Role Assignment.
2. Participant balances in 16 or on the brokerage platform? *Default:* 16 (CW-915; the 49 brief agrees). *Lever:* a platform merge moves them to 49 and 16 keeps only the ledger.
3. Participant managed accounts? *Default:* yes, digital, ERISA 3(38). *Lever:* drop Plan Managed Account Service and the 46 release route.
4. Rollover outreach automatic at separation? *Default:* a hand-off for every separation with a vested balance; outreach waits for consent to contact as firm policy (Regulation S-AM itself requires notice and an opt-out for affiliate marketing, not consent). *Lever:* only for participants who ask, or outreach on notice and opt-out.
5. Automatic portability and pension-linked emergency savings? *Default:* elections modeled, both optional features.
6. Sponsor relationship management? *Default:* administrative profile here, servicing and reporting in 12 (W4).
7. Firm as custodian of automatic rollover IRAs? *Default:* yes, a 15 account, counted as "Rolled to Firm IRA" (the Hand-Off Outcome values are now split by destination: firm IRA, firm-recordkept plan, external plan or IRA, stayed, cashed out; the method stays in Distribution Type). *Lever:* a third-party provider (Auto-Rollover IRA Provider kept), counted as "Rolled to External Plan or IRA".
8. Distributions through the 50 payment hub? *Default:* no, the recordkeeper's rail. *Lever:* one hub, and Distribution Request gains a reference to the 50 Money Movement.

### 7.8 Suggested validation (W3)

1. Reconcile a sample plan: sum of Participant Balance per option = plan omnibus Share Register Balance (29) at a valuation date; ledger postings for a trade date = the plan-level Fund Order quantity.
2. Walk one separation through hand-off, 45 engagement, Distribution Request, 15 IRA and 50 receipt, and check that 04 and 06 can measure rollover capture from the hand-off outcome.
3. Walk a 46 participant managed account rebalance to Participant Investment Transfers and postings.
4. Re-point DP-094 to DP-096 and the f4 data model per proposals NOTES.

### 7.9 Fix pass (16_review.md and the 12 review addendum, 2026-10-15)

Applied the program-lead rulings 1 to 6 and the Lows (details in proposals REPOINTS and NOTES): 46 link held on the 46 side only; Recordkeeper Profile widened, Plan Service Provider and Retirement Plan Profile limited to recordkept plans (row rules); SECURE 2.0 money sources and the QDIA fiduciary-basis rule; unit values, loans in plan assets, the non-payroll contribution row rule, PII tiers and flags, Payroll Employee ID mastered here, the CW-126 hand-off items; citations and text; sections 1 to 6 refreshed; composite-key parts flagged CDE; 'Plan Fiduciary Committee' added to Plan Fiduciary & Service Role for 12. Skipped, with reasons: the Managed Account Fiduciary Basis list keeps its name (the advice values are described as advice services and the QDIA rule is stated); 1099-R codes Q and D not added (Roth IRA and nonqualified annuity codes, not issued by a plan); the Form 5500 line 8a wording was not re-checked (kept as confirm); the 09 Frequency relabel and the brief's section 4 row are requests to other owners (NOTES).
