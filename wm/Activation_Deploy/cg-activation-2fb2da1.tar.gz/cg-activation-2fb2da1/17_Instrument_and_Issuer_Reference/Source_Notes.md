# Source Notes: 17 Instrument & Issuer Reference

**Workbook:** `Instrument_and_Issuer_Reference_Data_Taxonomy.xlsx` (built from `_tools/content/content_17_instrument_and_issuer_reference.py`)
**Status:** Draft v0.1, wealth model (direct), scope US, 2026-10-14: the draft of 2026-10-06 carried over with the US-only pass, the perspective rewrite and the retail-tradable additions of CW-917 (section 6). 9 families, 25 objects (15 business objects, 10 attribute groups), 279 attributes, 90 proposed CDEs (32%), 52 code lists, 33 relationships, 29 sources, 4 attributes flagged PII (employee references only), 16 derived copies. No Record Metadata object (CD-148).

**Why this domain exists.** The firm is a US wealth manager: a direct brokerage platform, digital and human advice, its own mutual funds, ETFs and CITs, workplace recordkeeping, institutional advisory and optional trust services. Every investment and brokerage domain needs to know what was bought, sold, held, priced or voted on, whether by a fund portfolio or by a client account, and no other Data Domain says what a security is: 01 Investment Product & Service Offering describes only the firm's own funds and its offerings and platform policy. The instrument master is produced by the security master (reference data) team in investment operations. That team sources vendor data, scrubs it and sets up new instruments, so the data is stewarded apart from both the product team (01) and the client data organization that owns the party master (02). Issuers are external parties, so the party core stays in 02. This domain adds the issuer role (issuer type, country of risk, investment sector, credit parent override, issuer identifiers and ratings), which only the security master maintains. Fund and institutional portfolios (18), client holdings (49), client orders (48), prices (22), fund desk trades (25, 26), corporate action processing (28, 49) and risk (31) all key on the instrument. The firm is regulated and distributes in the US only; the instrument universe stays global (CW-022).

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| ISO 6166 ISIN; ANNA | https://www.anna-web.org | ISIN structure (country prefix, national number, check digit), allocation by national numbering agencies, CFI and FISN allocated with the ISIN. Shaped Instrument Identifier and Country of Issue. |
| ISO 10962 CFI | https://www.iso.org/standard/81140.html | Categories and groups (E equities, D debt, C collective investment vehicles, R entitlements, O options, F futures, S swaps and others) as the basis of the Instrument Type list; option right, style and delivery attributes. The 2021 edition is assumed (see section 3). |
| ISO 18774 FISN | https://www.anna-web.org | Short name built from issuer short name and instrument abbreviation. |
| ISO 10383 MIC | https://www.iso20022.org/market-identifier-codes | Operating vs segment MICs; Instrument Listing carries both. |
| OMG FIGI / OpenFIGI | https://www.openfigi.com | Three FIGI levels (share class, composite, exchange). Modeled as three Instrument Identifier Scheme values, with exchange-level identifiers linked to a Listing. |
| ANNA DSB (OTC ISIN, UPI, CFI for OTC) | https://www.anna-dsb.com | Product-level identification of OTC derivatives. UPI (ISO 4914) is a scheme value and a CDE on OTC Derivative Product Terms. The asset class, base product and sub-product follow the ISDA taxonomy used by the DSB templates. |
| CUSIP Global Services | https://www.cusip.com | Six-character issuer number plus issue number and check digit; CINS for non-North American issues. The CUSIP Issuer Number sits on Issuer Profile. |
| GLEIF LEI and Level 2 | https://www.gleif.org | Direct and ultimate accounting parents. These stay in 02 Legal Entity Hierarchy; 17 adds a credit parent override only where research departs from the legal parent. |
| FIBO SEC, DER, BE | https://spec.edmcouncil.org/fibo/ | Instrument, issuer, equity, debt, pool-backed security and derivative concepts; the underlying relationship; issuer as a role of a legal entity. |
| ISO 20022 reda and seev | https://www.iso20022.org/iso-20022-message-definitions | Security reference content (form of security, denomination, interest, maturity, redemption) for Instrument and Debt Terms; corporate action notification (seev.031) event and option structure, key dates and the official event reference (COAF). |
| ISO 15022 MT564 | https://www.iso15022.org | CAEV, CAMV, CAOP and DISF code sets. |
| SMPG corporate action market practice | https://www.smpg.info | Mandatory with options vs voluntary; ex-date, record date and payment date definitions; announcement status (preliminary vs confirmed). |
| CFTC clearing requirement, 17 CFR Part 50 | https://www.ecfr.gov/current/title-17/chapter-I/part-50 | Classes of swaps required to be cleared, behind the Clearing Mandate Indicator. |
| ISDA definitions and FINOS Common Domain Model | https://www.finos.org/common-domain-model | Day count and business day conventions, floor and cap, governing definitions, the asset class / base product / sub-product taxonomy. |
| GICS | https://www.msci.com/our-solutions/indexes/gics | Four levels (sector, industry group, industry, sub-industry) with 8-digit sub-industry codes. The license is held in 14; the scheme version is registered in 09 (ICS-). |
| NAIC SVO | https://content.naic.org/svo.htm | NAIC designations 1 to 6 with designation categories (1.A to 6), and the filing-exempt route. A regulatory designation scheme, not a credit rating agency. The current category list needs confirming (section 3). |
| SEC Rule 2a-7 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.2a-7 | Eligible security; government, prime (retail and institutional) and tax-exempt fund types. |
| OCC options symbology (OSI) and listed option specifications | https://www.theocc.com (confirm page) | 21-character OSI symbol (root, expiration, call or put, strike) as an identifier scheme; adjusted series after corporate actions; expiration cycles (standard monthly, weekly, quarterly, end of month, LEAPS, daily). |
| FDIC deposit insurance, 12 CFR Part 330 | https://www.ecfr.gov/current/title-12/chapter-III/subchapter-B/part-330 | Insured deposits and ownership categories; pass-through coverage of brokered CDs. Shaped the FDIC Insured Indicator and the Certificate of Deposit instrument type. |
| MSRB Rules D-12 and G-45 (confirm) and EMMA | https://www.msrb.org ; https://emma.msrb.org | Municipal fund security definition (529 and ABLE plans, LGIPs); municipal security and plan disclosures. Shaped Municipal Fund Security Terms, Municipal Security Terms and the EMMA identifier scheme value. |
| IRC sections 103, 529 and 57(a)(5) | https://www.law.cornell.edu/uscode/text/26/103 ; https://www.law.cornell.edu/uscode/text/26/529 ; https://www.law.cornell.edu/uscode/text/26/57 | Tax-exempt interest on state and local bonds (Tax-Exempt Indicator); qualified tuition programs (Plan Sponsoring State, Municipal Fund Security Type); private activity bond interest as an AMT preference (AMT Subject Indicator). |
| FINRA Rule 2265 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2265 | Extended hours trading risk disclosure, cited on the Extended-Hours Eligible Indicator. |
| SEC Rule 144, Rule 144A and Regulation S | https://www.ecfr.gov/current/title-17/chapter-II/part-230/section-230.144A | Restricted securities (Rule 144(a)(3)); the QIB resale safe harbor; offshore offerings. |
| ICMA Green / Social / Sustainability Bond and Sustainability-Linked Bond Principles | https://www.icmagroup.org | Sustainable Bond Label values (use-of-proceeds labels plus sustainability-linked). |
| SEC NRSROs | https://www.sec.gov (Office of Credit Ratings page to confirm) | Credit Rating Agency list (NRSROs only, including AM Best), credit rating types, outlook, watch and action vocabulary as the agencies define them. |
| openfunds | https://openfunds.org | Held-fund fields: vehicle, domicile, dealing frequency, distribution policy. |
| ILPA | https://ilpa.org | LP fund interest terms: GP, vintage, strategy, commitment currency, fund term. |
| Vendor security masters (Bloomberg, ICE, LSEG, S&P; Aladdin, SimCorp) | vendor sites | Used for structure only (identifier cross-reference table, asset-class term groups, issuer vs instrument split, corporate action golden copy). No field dictionaries were copied. |

## 2. Design decisions and boundary calls

- **Outline followed: 9 families and 23 objects (25 since the W1 additions, section 6).** Object names are unchanged from the brief. One kind changed after review: Regulatory Instrument Classification is now an effective-dated Business Object (instrument x effective period), not an attribute group, so NAIC, Rule 144A and 2a-7 classifications keep history.
- **Own Fund Share Class instruments never remaster 01 (boundary rule 1, CD-154, program lead decision).** An own share class held in any book of record is an Instrument of type "Own Fund Share Class" with `Own Share Class` = SHC-: first the client accounts (client holdings mastered in 49), then the own portfolios (portfolio holdings mastered in 18). For those rows:
  - Name, FISN, CFI Code, Denomination Currency, Country of Issue and Issue Date (Instrument) are Derived copy (01), declared in `enrich_17.py`.
  - Fund Vehicle Type, Fund Regulatory Regime, Fund Domicile, Fund Dealing Frequency, Fund Distribution Policy and Money Market Fund Type (Fund Instrument Terms) are also Derived copy (01).
  - Each of these definitions says "Copied from 01 for own share classes; mastered here for third-party and other instruments".
  - Issuer and Fund Manager or General Partner are blank on these rows (third-party only).
  - Identifier rows copied from 01 carry `Derived from Own Share Class Indicator` = Y.
  - 17 creates no listing rows for own share classes, so `Identifier Listing` is blank on them and the venue comes from 01 Listing.
  - The fund term lists reuse the 01 lists by name and value (Vehicle Type, Regulatory Regime, Distribution Policy, MMF Type); the wealth model uses their US values only (CW-039).
  - Because the Derived flag is attribute-level, these attributes show as Derived copy (01) for every row, although the security master populates them for third-party instruments. The definitions state the row rule.
- **One place per fact.** Identifiers live only in Instrument Identifier rows. The earlier Own Share Class ISIN, CUSIP, SEDOL and FIGI columns, the primary listing MIC copy, the UPI column and the Exchange Contract Code column were removed. The listing ticker lives only on Instrument Listing, so "Exchange Ticker" is no longer an identifier scheme. One "Fund Manager or General Partner" and one "Fund Domicile" on Fund Instrument Terms now cover third-party funds and LP interests; Fund Interest Terms keeps only private-fund specifics.
- **Asset class is held once.** The firm asset-class hierarchy is held in Instrument Classification Assignment. `Asset Class` on the Instrument is level 1, derived within 17 from that assignment and kept as a CDE filter shortcut.
- **Classification scheme by reference only.** The scheme is the 09 ICS- scheme version reference. The separate scheme code and the local "Investment Classification Scheme" list were dropped. Levels and labels are Derived copy (09). `proposals_17.py` asks 09 to widen ICS- to investment and firm schemes.
- **Subtype lists refine Instrument Type.** Instrument Type is the parent. Equity Share Type refines "Equity Share", and Private Asset Type refines "Loan", "Private Equity Holding" and "Real Asset". The Syndicated, Delayed Draw, Convertible and REIT indicators were removed because a list answers each of them. Inflation-Linked Indicator stays and "Inflation-Indexed" left Coupon Type, because a TIPS has a fixed coupon mechanism with indexed principal. Callable and Puttable indicators stay as filter shortcuts derived from Redemption Schedule.
- **CFI Code is on the Instrument (deviation from the brief).** It is allocated with the ISIN by the numbering agency and is a matching key. CFI mappings in the Instrument Type list were corrected: ED / DD depositary receipts, DG MBS, DN municipal, and S, H, J (and M) for UPI-level OTC products.
- **FIGI level is a scheme value, not a column.** There are three FIGI values in Instrument Identifier Scheme. Exchange-level identifiers point to the Instrument Listing.
- **Issuer Profile has no name, address or regulator (boundary rule 2).** It holds:
  - issuer type, defined as the credit and limit-testing class and distinguished from 02 Organization Type;
  - country of risk and its basis;
  - CUSIP issuer number and Bloomberg company ID (confirm with 02, see `proposals_17.py` NOTES);
  - primary equity instrument, status, and the date the profile was set up.

  Issuer Regulators and the single-vendor Vendor Issuer ID were removed.
- **Debt Guarantor on Debt Terms (addition to the brief)** covers instrument-level guarantees. `In Default Indicator` replaces the "Defaulted" instrument status.
- **Statuses are split by dimension.**
  - Instrument Status is lifecycle only; suspension and delisting are on Listing Status.
  - Corporate action status is split into Announcement Status (Preliminary, Confirmed, Canceled, Withdrawn), which options also use, and an internal Golden Copy Status.
  - Processing ("Completed") is left to 28.
- **Reference, not market data (boundary rule 3).** There are no prices, factors, yields, index levels or rate fixings. `Shares Outstanding` and `Amount Outstanding` are slowly changing reference values, each with an as-of date. `Coupon Rate` is the fixed or initial rate; step rates are on Coupon Schedule.
- **Credit ratings stay in 17 (SME question 3 open).** All rating attributes and lists are prefixed "Credit Rating" (TERM_CONFLICTS rule). Rated Issuer is filled only for issuer ratings, so the key tells issue and issuer ratings apart. NAIC SVO is not a rating agency; NAIC designations sit on Regulatory Instrument Classification. AM Best and Other were added to the agency list.
- **Corporate actions (boundary rule 4).** The event is scrubbed golden copy. The COAF reference is a CDE (cross-custodian matching key). Entitlements, elections and payments are 28 for fund portfolios and 49 for client accounts. There is no placeholder relationship to 28; the Overview states the dependency.
- **Private markets.** Private Asset Terms and Fund Interest Terms are attribute groups of the Instrument, keyed by an internal identifier scheme. Investment Close Date and Holding Vehicle were removed, because they are facts about the firm's investment (30 / 18), not the instrument.
- **OTC derivatives at product level (SME question 2 open).** The UPI is an identifier row; OTC Derivative Product Terms holds the product taxonomy and conventions. Clearing Mandate Indicator cites the CFTC clearing requirement (17 CFR Part 50).
- **No Index object.** Underlying indices reference 01 Benchmark (BMK-).
- **Shared lists.** 17 stewards the shared Instrument Type, Instrument Asset Class, Day Count Convention and Credit Outlook lists, is a member of Business Day Convention, and cites further shared lists directly as "Shared: <name>".
  - Frequency, Record Status, Case Status, Approval Status, Message Standard and Data Provider are local lists with shared names and values; the value maps are in `proposals_17.py`.
  - Data Provider gains proposed vendor values, and "Other" also covers values assigned internally.
  - The Regulator copy was removed together with Issuer Regulators.
- **Self-references** use "Reference (Instrument, 17)" (and Listing, Corporate Action Event), the same form as sibling 18, so no self-reference overrides are needed. Employee references are forced to 20 Human Capital in `enrich_17.py` (CD-151).

### Review response

All 2 High and 28 Medium findings of `00_Program/Expansion/Reviews/17_review.md` were applied, three of them in part (see below). Of the 28 Low findings, 25 were applied in full; the other three are listed below with the reason.

Medium findings applied in part:
- **Issuer Profile identifiers (A).** CUSIP Issuer Number and Bloomberg Company ID stay as columns: the brief names them as security-master issuer identifiers. The single-vendor `Vendor Issuer ID` was dropped. Moving them into 02 Party Identifier schemes is proposed in `proposals_17.py` NOTES for 02 to decide.
- **Rating Agency vs 02 role proposals (E).** Credit Rating Agency stays a code list, because the brief expects that list. The role proposals now match every party 17 references: Issuer, Guarantor, Portfolio Company, Depositary Bank, Loan Administrative Agent, Collateral Manager / Servicer, Third-Party Fund Manager / GP, Clearing House / CCP, Offeror and Numbering Agency. Rating Agency and Exchange Operator are kept because the brief and CD-143 require them; each code value or MIC maps to the party.
- **Instrument Type mixes ownership (F).** "Own Fund Share Class" is kept as a type because brief boundary rule 1 and the program lead decision use it. The third-party fund values were merged into one "Third-Party Fund", so an ETF-exposure query uses Fund Vehicle Type, which is filled for both own (Derived 01) and third-party funds. "Other" was added.

Low findings not applied, or applied with a different remedy:
- **Object names vs Applies To (D).** Accepted without renaming, as the reviewer allows. The Overview "Applies To" entry now says that Coupon Period and Redemption Event are rows of Coupon Schedule and Redemption Schedule.
- **Instrument Asset Class (F).** "Multi-Asset / Fund" became "Multi-Asset" and "Currency / FX" was added. "Derivative" is kept, flagged in the list for review with Investment Risk, as the reviewer suggested.
- **Sources (G).** The ISO 10962 and SEC Office of Credit Ratings URLs were not replaced, because I could not verify a better URL. Both are marked "confirm" rather than guessed. NAIC (content.naic.org/svo.htm) and ISO 15022 (iso15022.org) were updated as suggested.

## 3. What could not be verified

- **ISO 10962 edition and page.** The link https://www.iso.org/standard/81140.html returned 403 to the reviewer. It is kept with "confirm"; check the edition and whether ANNA's code tables reflect a later amendment.
- **NAIC designation categories.** The 20 categories (1.A to 1.G, 2.A to 2.C, 3.A to 3.C, 4.A to 4.C, 5.A to 5.C, 6) and the filing-exempt route are from industry knowledge; confirm them against the SVO Purposes and Procedures Manual.
- **ISDA taxonomy values and the UPI CFI scope** ("Interest Rate / IR Swap / Fixed Float"; S, H, J and M) follow the ANNA DSB usage. The current DSB template names were not checked.
- **Rating agency names.** Moody's legal brand ("Moody's Ratings") and DBRS Morningstar naming change over time. The list is illustrative.
- **SEC Office of Credit Ratings page.** Cited at the site root with "confirm".
- **Example identifiers.** Apple Inc. public identifiers (ISIN US0378331005, CUSIP 037833100, ticker AAPL on XNGS) are used as realistic examples. The UPI, COAF, pool, Bloomberg company ID and all INS-/IID-/LST-/CAE-/ISR-/PTY- values are illustrative.
- **Rule 2a-7 fund types** reflect the rule as amended through 2023; check for later amendments.

## 4. Open questions for client SMEs

1. Which platform is the security master of record (OMS / IBOR vendor, EDM tool, in-house), and which vendor wins per field (golden-copy survivorship)?
2. Are OTC derivatives set up as instruments at product level (UPI) with trade economics in 26, or as one instrument per trade, as many OMSs do?
3. Do credit ratings belong in 17 (reference used by compliance) or in 22 (observations alongside prices)?
4. Does 01 Benchmark cover every index used as an underlying, or does 17 need its own Index object?
5. Are own share classes set up as instruments for every class, or only those held in client accounts or own portfolios, or listed?
6. Which issuer parent drives concentration limits: the 02 legal parent (GLEIF) or a credit-research parent maintained here?
7. Who sets up private asset instruments and feeder fund underlyings (the alternatives team or the security master team), and what internal identifier scheme is used?
8. Which sector schemes are licensed and which one drives compliance and client reporting?
9. Who scrubs corporate action events (security master team or the custody / asset servicing team in 28), and what is the golden source (DTCC GCA, custodian, vendor)?
10. (Ruled at W5, CW-165: the NAIC designation stays as an instrument attribute of the investment universe; insurer-client wording dropped.)
11. (Added) Should CFI stay on the Instrument or move into Instrument Classification Assignment?
12. (Added) Are Shares Outstanding and Amount Outstanding maintained by the security master, or should they be 22 time series?

## 5. Recommended next steps

1. Run a boundary workshop with 01 (own share-class instruments, Benchmark as underlying, Tradable Universe Policy Rule), 02 (issuer role, new Party Role Type values, legal vs credit parent), 18 and 49 (fund portfolio and client holdings key on INS-), 48 (orders read the eligibility flags) and 09 (ICS- registration of ICB and BICS).
2. Map the attributes to the security master of record and its vendor feeds, and record the survivorship rule per family.
3. Have Investment Compliance confirm the regulatory classification flags and the CDE list, and agree that 33 references them.
4. Have Brokerage Operations confirm the options, CD, municipal and 529 terms and the fractional and extended-hours flags.
5. Merge the shared-list memberships and Data Provider additions in `proposals_17.py`, and register the five prefixes.
6. Turn the Relationships tab into a logical instrument model shared with 18, 22, 25, 26, 28, 31, 48 and 49.

## 6. Wealth model carry-over (W1, CW-917)

17 is kept (plan section 5.1). The pass made four kinds of change only (CW-022): the US-only pass, the perspective text, the wording around the books of record, and the retail-tradable additions the plan names. Object and attribute names are unchanged except for the removed attributes, because DP-097, DP-098, DP-099 and other products read 17 by name. The decision draft and the jurisdiction entries are in `_tools/consolidation/proposals_w1_17.py`.

**Removed (EU/UK only; 23 jurisdiction entries: UCITS 10, Other EU/UK 5, MiFID II 2, MiFIR 2, FinDatEx 2, FCA 1, EMIR 1).**
- Regulatory Instrument Classification: UCITS Eligible Asset Indicator, UCITS Eligible Asset Category, MiFID II Complex Instrument Indicator, EU or UK Trading Venue Indicator, Solvency II CIC Code.
- Securitized Product Terms: STS Securitization Indicator.
- Code list UCITS Eligible Asset Category (whole list); Credit Rating Agency value Scope Ratings (not an NRSRO; keeping the list to NRSROs is a policy lever, see open question 6). DBRS Morningstar now reads Morningstar DBRS.
- Not recorded by 17 (17 holds no copy; the steward 01 records them under CW-901 and removes them at W5, CW-039): the EU/UK values of the shared lists that 17 cites on Fund Instrument Terms, Regulatory Regime (UCITS, UK UCITS, EU AIF, ELTIF, EU MMF, UK NURS, UK QIS, Lux SIF, Lux RAIF, Irish QIAIF) and MMF Type (Public Debt CNAV, LVNAV, Short-Term VNAV, Standard VNAV). The examples and definitions now use the US values; the workbook still lists the shared values until W5.
- Sources: ESMA FIRDS, FCA FIRDS, EMIR Article 4, FinDatEx TPT and the Solvency II CIC table, Directive 2007/16/EC and UCITS Article 50, MiFID II and MiFIR, the EU and UK Securitisation Regulations, the EU Money Market Funds Regulation, the EU Credit Rating Agencies Regulation.

**Re-sourced.**
- Clearing Mandate Indicator to the CFTC clearing requirement (17 CFR Part 50) alone.
- Credit Rating Agency to NRSROs only (SEC Office of Credit Ratings).
- Twenty attributes that cited ESMA FIRDS as a cross-check now cite ISO 20022, ISO 10962, ISO 6166 (ANNA), FIBO SEC, FINOS CDM, the exchange or OCC, or nothing where the primary reference suffices (FISN, CFI Code, Denomination Currency, Issue Date, Coupon Rate, Reference Rate, Reference Rate Term, Floating Rate Spread, Maturity Date, Amount Issued, Debt Seniority, Contract Multiplier, Expiry Date, Strike Price, Option Style, Settlement Method, Listing Venue MIC, Listing Trading Currency, Listing Date, Delisting Date). The source alignment of the Debt Seniority, Option Style and Settlement Method lists changed the same way.

**Kept on purpose (investment universe, CW-022).** Foreign instruments, listings, issuers and corporate actions; SEDOL, Valoren and WKN identifier schemes; the "30E/360" day count; the "Senior Non-Preferred" seniority (non-US bank issuers; description reworded); the "Court Meeting" event (CMET, UK scheme of arrangement on foreign issuers); Option Style "European" (an exercise style); NAIC designations (listed for the W4 retirement of insurance-dedicated funds).

**Perspective rewritten.** META subtitle; overview Purpose, Scope, Core model, Design principles (new principle 9: policy is 01, the flag is 17, the check is 48), CDE, Notes and Suggested next steps; the family texts of Instrument Setup, Instrument Classification, Regulatory Classification, Fund Instrument Terms, Listed Derivative Contract Terms, Private Market Instruments, Credit Ratings and Corporate Action Events; NAICS/NACE now reads NAICS (NACE leaves 02 and 09); the books of record are named (18 fund and institutional portfolio holdings, 49 client holdings, 28 and 49 entitlements); SUMMARY in `enrich_17.py`.

**Added (plan section 5.1, CW-037, CW-039).**
- Instrument: Fractional Trading Eligible Indicator and Extended-Hours Eligible Indicator, each with the 01 Tradable Universe Policy Rule (`TUP-`) that set it.
- Listed Derivative Contract Terms: Option Expiration Type (the listing cycle, one value per series: Standard Monthly, Weekly, Quarterly, End-of-Month, Other; long-dated series are read from Expiry Date, so there is no LEAPS value) and Adjusted Option Indicator; Instrument Identifier Scheme value OCC Option Symbol (OSI); one instrument per OCC series. An OCC adjustment re-symbols the same series: the instrument keeps its INS- and takes a new, effective-dated OSI identifier row; Successor Of is used only where OCC lists a new series.
- Debt Terms: FDIC Insured Indicator (brokered CDs); Redemption Event Type value Survivor Option; Instrument Type value Certificate of Deposit.
- New attribute group Municipal Security Terms (Municipal Issuer State, Municipal Security Type, AMT Subject Indicator, Bond Insurer); Instrument Identifier Scheme value MSRB EMMA Security ID.
- New attribute group Municipal Fund Security Terms for 529 and ABLE portfolios (Municipal Fund Security Type, Plan Sponsoring State, Program Manager, Plan Sales Channel, Plan Portfolio Allocation Type, Target Enrollment Year); Instrument Type value Municipal Fund Security.
- Five local code lists: Option Expiration Type, Municipal Security Type, Municipal Fund Security Type, Municipal Fund Plan Sales Channel, Municipal Fund Portfolio Allocation Type. No new prefix.

**Open questions (W1).**
1. Should the flags carry their own as-of date, or is the period of the 01 rule enough to reconstruct history?
2. Is the EMMA identifier a separate scheme at all, or does EMMA key every municipal security and 529 plan disclosure by CUSIP (confirm)?
3. Should the shared Regulatory Regime list keep a "Non-US Regulated Fund" value for foreign funds held by the international funds once the EU/UK values leave?
4. Does the firm act as 529 program manager (its own plan) or only offer third-party plans on the platform (tailoring lever)? The row rule is set: where the firm is program manager, the plan's portfolios are its own products (01) and the Municipal Fund Security Terms values are Derived copies of 01 (ROW_OWNERSHIP in `enrich_17.py`); otherwise 17 masters them. The plan name is not copied: the plan (issuing trust or program) is the Issuer party in 02. Plan Sponsoring State, Program Manager and Plan Sales Channel repeat on each portfolio by design; a separate plan object would add a business object for three slowly changing facts.
5. Complex-product flag (tailoring lever): FINRA Regulatory Notices 09-31 (leveraged and inverse ETPs) and 12-03 (complex products) may call for an instrument-level complex-product flag. W1 does not add it; the model leaves complex-product handling to 01 platform policy and 48 order checks (CW-036, CW-037). A firm that wants the flag adds it on the TUP- pattern.
6. Credit rating agencies: should the list stay NRSROs only, or should the international bond funds be able to record non-NRSRO ratings of foreign issuers (restore Scope Ratings, or widen Other)?

**Unverified.** OCC symbology page and expiration cycle names (confirm); MSRB Rule G-45 as the source of program manager and sales channel (confirm); MSRB EMMA identifier format (confirm); the 12 CFR Part 330 and 17 CFR Part 50 eCFR paths follow the standard eCFR pattern and should be opened once.

