# Source Notes: 18 Portfolio & Investment Book of Record

**Workbook:** `Portfolio_and_Investment_Book_of_Record_Data_Taxonomy.xlsx` (built from `_tools/content/content_18_portfolio_and_investment_book_of_record.py`)
**Status:** Draft v0.1, 2026-10-06, revised after independent review (00_Program/Expansion/Reviews/18_review.md); wealth model carry-over 2026-10-14 (W1b, CW-918; section 7). **Perspective:** Wealth manager (direct) | Scope: US. 7 families, 24 objects (16 business objects, 8 attribute groups), 216 attributes, 68 proposed CDEs (31%), 22 local code lists plus the enterprise shared lists (29 in the workbook), 42 relationships, 18 sources, 5 attributes flagged PII (3 employee references; portfolio name and identifier value for an institutional separate account of a natural person). 37 references, 15 derived copies, 0 unresolved.

**Why this domain exists.** The US wealth manager runs its own mutual funds, ETFs and CITs and its institutional separate accounts in house, so it keeps an investment book of record (IBOR) for those portfolios: what each portfolio holds at start of day and through the day, in which lots, with what cash, after which transactions. It is one of three books of record (CW-007): portfolio holdings here; client holdings in brokerage and advisory accounts, including retail managed accounts, in 49 Clearing, Settlement & Client Asset Custody; fund shareholder positions in 06. 01 Investment Product & Service Offering describes what the firm sells, 06 holds shareholders' positions in the firm's funds and 49 the brokerage book of record; none is the book of securities a portfolio manager runs. The IBOR is produced by investment operations from the order management and IBOR platform and is stewarded apart from product and distribution. Trading (25), performance (32), risk (31) and investment compliance (33) all key on the portfolio and its holdings, which is why it is drafted first.

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| ISO 20022 semt messages (semt.002 Custody Statement of Holdings, semt.003 Accounting Statement of Holdings, semt.017 Statement of Transactions, semt.018 Statement of Pending Transactions) | https://www.iso20022.org/iso-20022-message-definitions | Holding statement structure: quantity with a unit choice (units, face amount), sub-balances (settled, pending), price and value in local and base currency; transaction and pending transaction statements. Shaped Portfolio Holding, Quantity Unit, Holding Valuation, Cash Balance Type and Portfolio Transaction. |
| FIX Protocol (Allocation Instruction J, Position Maintenance Request AL, Position Report AP) | https://www.fixtrading.org/standards/ | Side, quantity, price, settlement date, accrued interest and commission on booked allocations; position adjustments as a maintained action with a reason. Shaped Portfolio Transaction, Transaction Cost & Charge and Position Adjustment. |
| BIAN Service Landscape | https://bian.org/servicelandscape/ | Separation of portfolio management, position keeping and investment account behavior; used only to confirm the family cut. Service domain names not verified (see section 3). |
| FIBO SEC and FBC | https://spec.edmcouncil.org/fibo/ | Portfolio and holding as concepts distinct from the security and from the account; legal ownership of a portfolio. |
| IRS Publication 550 | https://www.irs.gov/publications/p550 | Basis of investment property, capitalized costs, identification of shares sold (specific identification, FIFO default), holding period, wash sales. Shaped Tax Lot, Lot Relief and Portfolio Accounting Basis. |
| IRC Sections 1091 and 1222; Treas. Reg. 1.1012-1(c) | https://www.law.cornell.edu/uscode/text/26/1091 | Wash-sale disallowance, replacement-lot basis adjustment and holding period tacking (30 days either side of the sale); short-term / long-term at one year; adequate identification and FIFO default. |
| IRS Form 8949 | https://www.irs.gov/forms-pubs/about-form-8949 | Date acquired, date sold, proceeds, basis, wash-sale adjustment, short / long split (Lot Relief). |
| GIPS 2020 Standards for Firms | https://www.gipsstandards.org | Portfolio as the unit of management; inception and termination; carve-outs (Portfolio Hierarchy Link Type). |
| ILPA Reporting Template and Capital Call & Distribution Template | https://ilpa.org | Commitment, called capital, distributions, unfunded commitment and NAV roll-forward (Fund Interest Holding Detail); subscription credit facilities. The revised Capital Call & Distribution Template (2025, effective Q1 2027) has a standalone unfunded commitment section. |
| SEC Form N-PORT | https://www.sec.gov/files/formn-port.pdf | Cross-check of holding-level fields for registered funds: units, value, long / short, derivative notional, counterparty, delta. Unfunded commitments are not cited to N-PORT (they are disclosed in financial statement schedules). |
| SEC Rule 6c-11 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.6c-11 | Daily ETF holdings publication and in-kind baskets (Fund Portfolio Detail, In-Kind Activity Indicator). |
| SEC interpretive release 34-54165 (2006), Commission Guidance Regarding Client Commission Practices Under Section 28(e) of the Exchange Act | https://www.sec.gov/rules-regulations/2006/07/commission-guidance-regarding-client-commission-practices-under-section-28e-securities-exchange-act | Soft dollar safe harbor for research and brokerage services paid with client commissions (Research Payment Component). Added at W1b (CW-918), replacing the MiFID II research payment rules; the URL is the one 23 cites. |
| SEC Form ADV | https://adviserinfo.sec.gov | Discretion, sub-advisory and separate account and sponsor program structures (SMA Portfolio Detail, Managing Entity). |
| Aladdin, Charles River IMS, SimCorp, eFront / FIS Investran (public product pages) | https://www.blackrock.com/aladdin, https://www.crd.com, https://www.simcorp.com, https://www.efront.com | Structure only: start-of-day vs real-time IBOR views, aggregate portfolios, cash projection, combined IBOR / ABOR, private markets commitments. No field names reproduced. |
| ISO 3166 / 4217 / 8601 | https://www.iso.org | Country, currency and date formats. |

## 2. Design decisions and boundary calls

- **Portfolio vs product (CD-145).** Portfolio (`PORT-`) is the managed book. Portfolio Implementation Link joins it to what it delivers. The brief's single polymorphic "implemented object" is modeled as **one reference per link type** (Implemented Product `PRD-`, Implemented Mandate `MND-`, Managed Account `ACC-`, Followed Model Portfolio `MDL-`), with Implementation Link Type saying which one is filled, so every reference resolves to one owning domain. A feeder fund is a product linked to its master's portfolio. Product and mandate facts are read through the link and never repeated on the book: master-feeder role, fund-of-funds flag, valuation frequency, fund administrator, sub-advisory (01 mandate type) and in-kind dealing were removed after review. The one exception is Daily Holdings Publication Indicator, kept as a Derived copy (01) because the IBOR end-of-day view is the source of the published ETF holdings file; 01 has no such term yet, so proposals_18 asks 01 to add one.
- **Legal Owner Entity** is recorded only for CIT books (trustee bank entity) and proprietary books. A fund's legal owner is the 01 product reached through Implements Product; an institutional separate account's or mandate's owner is the account holder reached through Manages Account or Implements Mandate.
- **Portfolio Type is structural only** (Standalone Book, Sleeve, Aggregate). **Business Line** uses the eight CW-004 lines as two-letter codes (shared list, steward 09; W1b re-cut): fund books are PF, institutional separate account and mandate books IA. Mandates are recorded once, through Implements Mandate links; seed and proprietary books once, through Proprietary Capital Indicator; sleeves once, as a type value plus the Sleeve Of hierarchy link; shadow books once, as the IBOR Operating Model value "Shadow of Client Custodian Record".
- **Hierarchy link types** are Sleeve Of, Carve-Out Of, Aggregation and Successor Of. Master-feeder is an Implementation Link (rule 1) and fund of funds is a Portfolio Holding of an own-share-class instrument (CD-146), so neither is a hierarchy link. Look-Through Roll-Up Indicator applies to sleeves and aggregates.
- **Business-line detail (deviation).** Three attribute groups remain: Fund Portfolio Detail (cash sweep vehicle, daily holdings publication), SMA Portfolio Detail (institutional separate accounts only in the wealth model; sponsor or consultant program agreement, discretion, tax-aware and loss harvesting flags) and Private Fund Portfolio Detail. The brief's **Mandate Portfolio Detail was dissolved**: after removing the 01 and 12 repeats (sub-advised, SSI, cash flow notification flag, funding transition, shadow book) only the custody account was left, and it now sits on the Portfolio as Safekeeping Custody Account. Hence 24 objects instead of 25 (within ±3).
- **Three books of record (CD-146, CW-007).** No object is called "Position" bare. Client holdings are 49 and fund shareholder positions 06. Portfolio Holding (`HLD-`) is portfolio x instrument x holding date x holding view; own-fund holdings point to the latest 06 period-end position through `Corresponding Shareholder Position`. "Portfolio Position Snapshot" and "Position Adjustment" keep the brief's qualified names.
- **IBOR, not ABOR.** Holding Valuation and the Portfolio Valuation Summary are the investment estimate; NAV, the accrual ledger and amortization are 27, custodian reconciliation 28. The snapshot carries only a control status (shared Reconciliation Status).
- **Grain.** A Tax Lot carries its current state; its history is rebuilt from Lot Relief, and the lot relates to the portfolio x instrument, not to a dated holding row. A Portfolio Position Snapshot is portfolio x snapshot type x as-of timestamp; its members are the holdings and cash balances of its business date and Snapshot Holding View. Portfolio Capital Activity is keyed by share class for pooled funds and by client account (`ACC-`) for mandate and institutional separate account books. Position Adjustment is keyed by its Adjusting Transaction. Portfolio status history and accounting basis history come from Portfolio Lifecycle Events (Status Change, Accounting Basis Change).
- **Values owned elsewhere are Derived copies:** Price Used, Price Date, Price Source, Holding FX Rate, Cash FX Rate, Trade FX Rate and Delta Used (22); Source Allocation ID (25, an identifier, because 25 has no prefix and only four new prefixes may appear); Settlement Confirmed Indicator, Encumbered Quantity and Initial Margin Posted (26); Daily Holdings Publication Indicator (01). Settled and Unsettled Quantity stay mastered as IBOR computations, noted as depending on 26 settlement status. Settlement confirmation appears only once (no "Settlement Confirmed" event type).
- **Signs.** Amounts are unsigned where a direction or type is recorded (Holding Quantity with Long / Short; Projected Amount with Projected Flow Direction; Activity Amount with Capital Activity Type, which gives the direction, so the capital activity carries no separate Flow Direction) and signed where none is (Transaction Quantity, Quantity Adjustment, cash balances).
- **Portfolio Transaction (`PTXN-`)** is the booked effect on the portfolio; its booking lifecycle is the Portfolio Transaction Event trail. In-kind transfers reference the Portfolio Capital Activity they settle. Costs are explicit only; implicit costs belong to 25.
- **Lot relief.** US lot identification only (Treas. Reg. 1.1012-1; the UK share identification rules left at W1b, section 7). Labels shared with 15 Cost Basis Method are aligned (High Cost, Low Cost, Specific Lot Identification).
- **Cash.** Cash Balance Type is the timing basis only (Settled, Trade Date, Available); account purpose (operating, margin, collateral, income, subscription / redemption) is a separate attribute; overdrafts are negative settled balances; projections live only in Projected Cash Movement.
- **Operating model (CD-147)** and **SSIs (CD-155)** as before: Book of Record System, IBOR Operating Model and Middle Office Provider on the Portfolio; SSIs are reached through the 12 custody account and mandate, so 18 holds no SSI reference and stays neutral to CD-155.
- **Shared code lists.** Record Status, Approval Status, Flow Direction (Inflow and Outflow only), Period Type, Reconciliation Status and Data Basis are used as `Shared: <name>`, loaded from `shared_code_lists.py` by the `_shared` helper because 18 is not yet a member of any shared list. Frequency is no longer used.
- **Local lists.** 22 after W1b (UK Matching Rule and Transaction Cost Category removed): the brief's list (Valuation View was replaced by Holding View) plus Business Line, IBOR Operating Model, Quantity Unit, Holding Period Term, Capital Activity Source and Cash Account Purpose.
- **Reference typing.** References to 18's own objects are typed `Reference (<Object>, 18)`, to 17 as `Reference (Instrument, 17)` / `Reference (Corporate Action Event, 17)`, and FX rate type as `Reference (FX Rate Type, 09)`, so they resolve before prefixes are registered. Employee references (`EMP-`) are forced to 20 with OWNERSHIP_OVERRIDES.
- **Personal data.** Portfolio Name and Portfolio Identifier Value carry a conditional PII note for institutional separate accounts of natural persons (personal trusts, family offices), and the overview notes treat the holdings, lots, cash and transactions of such books as nonpublic personal information under Regulation S-P and GLBA.
- **Not modeled.** Portfolio manager assignment (01 today, 24 later), targets and weights (24), orders and allocations (25), settlement and collateral (26), NAV (27), reconciliation (28), investor capital accounts (30), seed capital accounting (43), governance record metadata (21).

### Review response

All 3 High and 26 Medium findings were applied, the Highs as decided by the program lead. Lows were applied except as listed:
- **Subtitle "Business domain 18" (I, Low): not applied.** The drafting instructions prescribe this subtitle form for all Stage 1 modules and the builder rewrites it to "Data Domain 18" in the workbook. The Structure and Tabs overview text and "Built from" were updated.
- **Mandate Portfolio Detail (A, B, C findings): applied by dissolving the object** rather than trimming it to one attribute; see the business-line bullet above.
- **Settled / Unsettled Quantity (E, Low): applied as a note**, not as Derived copy, because the IBOR computes them; only the settlement status input is 26's.
- **Snapshot membership (D, Medium): applied by definition** (business date and Snapshot Holding View) rather than adding a snapshot reference to every holding and cash balance.
- **Cash Flow Notification Required Indicator (A, Low): dropped**, derivable from the 12 Cash Flow Arrangement.
- No action needed (as the review states): the EMP- overrides and the `_shared` helper.

## 3. What could not be verified

- **BIAN service domain names.** The public BIAN pages found confirm an Investment Account service domain and the service landscape structure, but not the current names "Investment Portfolio Management" or "Securities Position Keeping"; confirm against the BIAN repository before citing them by name.
- **SEC Form N-PORT PDF path.** Confirmed by the reviewer.
- **ILPA template URL.** Cited at the ILPA home page; the specific template download path was not confirmed.
- **Vendor structures.** Aladdin, Charles River, SimCorp and eFront / Investran structures are inferred from public product descriptions only; holding view names (start of day, real time) are common industry terms, not vendor field names.
- **IBOR / ABOR literature.** No EDM Council or consultancy paper was cited, because none was verified in this pass.
- **ISO 20022 message names.** semt.002, semt.003, semt.017 and semt.018 are cited from knowledge of the catalog; confirm the current versions.
- **Examples** (portfolio codes, lot IDs, amounts, FX rates) are illustrative.

## 4. Open questions for client SMEs

1. Which platform is the IBOR (Aladdin, Charles River, SimCorp, in-house), and does it also hold the ABOR, or is the ABOR at the fund administrator or custodian?
2. Which functions are outsourced (middle office, fund accounting, private fund administration), and for which business lines?
3. Institutional separate account granularity: one portfolio per account or per sleeve? Is any portfolio kept for nondiscretionary model-delivery programs?
4. Are fund-of-funds and master-feeder look-through holdings stored in the IBOR or derived downstream (12, 31)?
5. Which lot relief methods apply by business line (tax-aware institutional separate accounts, US funds)?
6. Are intraday holdings persisted, or only start-of-day and end-of-day views?
7. For private fund portfolios, is the private markets administration system the book of record for private holdings and unfunded commitments?
8. Are seed capital and proprietary portfolios in this book, or in 43 Corporate Treasury & Capital?
9. For insurer separate accounts the firm sub-advises (if any; insurance-dedicated funds are out of scope, CW-004), does the firm keep the book or receive holdings from the insurer's custodian?
10. Is the IBOR valuation summary used officially anywhere (client reporting, compliance), or only as an estimate ahead of NAV?
11. Does the IBOR keep capitalized transaction costs in lot cost for funds as well as institutional separate accounts, and which books pay research through Section 28(e) commissions and which in hard dollars?
12. Is the gain budget for tax-aware institutional separate accounts held in the IBOR, the sponsor platform or the client record? (Retail managed accounts are 46 and 49.)

## 5. Overlaps with other domains (for consolidation)

- **01:** 'Business Line' in 01 means client segment; proposed rename (term conflict). ETF transparency term proposed for 01.
- **05 / 15:** Sponsor program of a sponsor program account (intermediary channel) keyed by AGR- (05) here, while the wealth 15 keys a program enrollment by ENRL- (term conflict logged).
- **06:** Position, ETF Holding, Transaction, Snapshot and Flow / Asset Measures vs 18 Portfolio Holding, Portfolio Transaction, Portfolio Position Snapshot and Portfolio Capital Activity (term conflicts logged in `proposals_18.py`).
- **01:** Model Portfolio vs Portfolio; Portfolio Manager Assignment stays in 01 for now; Cost Disclosure vs Transaction Cost Category; master-feeder role, valuation frequency, fund administrator and mandate type read from 01.
- **12:** Custody Account, Standing Settlement Instruction, Transition Event and Cash Flow Notification referenced, not rebuilt; Holdings Presentation is presentation of 18 holdings.
- **15:** Institutional separate accounts and mandate accounts referenced (implementation link, capital activity); seed capital indicator also proposed for 15 in the gaps register; Cost Basis Election (the client's election, 15) vs Lot Relief Method (portfolio) proposed as NOT_MERGED.
- **17 (sibling):** Instrument (`INS-`) and Corporate Action Event (`CAE-`) referenced on Portfolio Holding, Tax Lot, Portfolio Transaction, Projected Cash Movement, Position Adjustment and Fund Portfolio Detail (cash sweep vehicle). No instrument terms (multiplier, factor, coupon, general partner) are held here.
- **20 (sibling):** Employee (`EMP-`) on lifecycle events, booking events and adjustment approvals.

## 6. Recommended next steps

1. Run a boundary workshop with investment operations, 01, 06, 12 and 15 to confirm CD-145 and CD-146 as drafted, the implementation link per product, mandate and institutional separate account, and the CDE list.
2. Answer SME questions 1, 2 and 6 first: they decide the system of record per family and whether intraday holdings are persisted.
3. Map attributes to the IBOR platform's portfolio, position, lot, cash and transaction tables and to the private markets system.
4. Have fund tax review lot relief methods and wash-sale handling by business line.
5. Register PORT-, HLD-, LOT-, PTXN- and the concept ownership rows in `decisions.py`; drop the ", 18" / ", 17" qualifiers once prefixes are registered.
6. Hand the Derived copy attributes to 22, 25 and 26 when those domains are drafted.
7. Turn the Relationships tab into a logical IBOR model shared with 24 to 33.

## 7. Wealth model carry-over (W1b, CW-918)

18 is kept (plan section 5.1). The pass made the four kinds of change of CW-022 only: the US-only pass, the perspective text, the wording around the books of record and the replaced 02 and 15, and the Business Line re-cut to CW-004. No object or attribute is renamed; four attributes were removed, in the families Portfolio Master (Accounting Basis), Tax Lots and Portfolio Activity, and no IDs are assigned in the module (attribute IDs are positional in the workbook and renumber within those families). The decision draft, the jurisdiction entries and the readers are in `_tools/consolidation/proposals_w1b_18.py`.

**Removed (EU/UK only; 18 jurisdiction entries: Other EU/UK 8, MiFID II 10).**
- Lot Relief: UK Matching Rule Applied. Tax Lot: Pooled Lot Indicator (TCGA 1992 s104 pool). Portfolio Accounting Basis: Lot Rule Jurisdiction (existed only to switch a book to the UK rules; every 18 book now follows US lot identification, and Holding Period Term "Not Applicable" covers tax-exempt books).
- Transaction Cost & Charge: Cost Categories Applied (MiFID II costs and charges categories); the explicit amounts stay.
- Code lists: UK Matching Rule (3 values, whole list); Transaction Cost Category (7 values, whole list, read only by the removed attribute); Lot Relief Method value UK Share Identification Rules (TCGA 1992 s105-106A) (18 is steward of the shared list; see SHARED_RECUTS).
- Sources: HMRC Capital Gains Manual CG51500; Commission Delegated Regulation (EU) 2017/565 Article 50 and Annex II; Commission Delegated Directive (EU) 2017/593 Article 13.

**Re-sourced.** Research Payment Component to Exchange Act Section 28(e) and SEC release 34-54165 (soft dollars); Commission Amount, Exchange and Clearing Fee Amount (definition names the SEC Section 31 fee) and Transaction Tax Amount to the FIX Protocol; Total Explicit Cost to Internal / FIX; Default Lot Relief Method, Relief Method Applied and Original Cost Local drop the HMRC cross-reference (Treas. Reg. 1.1012-1 and IRS Publication 550). The Lot Relief Method list source is IRS Publication 550 / Treas. Reg. 1.1012-1.

**Kept on purpose (investment universe, CW-022).** EUR and other local-currency amounts; stamp duty and financial transaction tax on foreign trades (Transaction Tax Amount); the WMR London 4pm fixing as an FX rate type example.

**Perspective and re-points.** META subtitle; overview Purpose, Scope (the 18 / 49 boundary: retail managed accounts are 15 accounts managed in 46 holding Client Holdings in 49, never 18 portfolios; CW-007, CW-009), Core model, Design principle 2 (three books of record), Notes (Regulation S-P, GLBA and state law in place of GDPR) and Suggested next steps; family texts of Portfolio Master, Business-Line Detail, Holdings, Tax Lots (client lots are 49, the election is 15 Cost Basis Election) and Portfolio Activity; "SMA account" reads "institutional separate account" in Portfolio Name, Portfolio Identifier Value, Legal Owner Entity, Implemented Product, Managed Account, the SMA Detail group, Sponsor Program Agreement, Tax-Aware Management Indicator, Activity Share Class, Activity Account and the code values Sleeve, Sponsor Account Number, Implements Product, Implements Mandate, Manages Account, Client Contribution, Client Withdrawal and Sponsor Notification and four relationships; "insurance-dedicated fund" no longer appears in the pooled-fund texts (CW-004); 02 is named Client & Household (party core); "Shareholder Position" reads "Fund Shareholder Position"; SUMMARY and the SMA Portfolio Detail grain in `enrich_18.py`. References typed (Party) and (Account) are unchanged and resolve (CW-021).

**Business Line (CW-004).** The local copy of the shared list now holds the eight two-letter codes, as 02 and 15 do; the example is PF. The six wholesale values (Mutual Fund, ETF, Collective Investment Trust, Separately Managed Account, Private Markets, Insurance-Dedicated Fund) leave; the value map of the shared list needs the identity map for 18 (SHARED_RECUTS).

**Additions.** None beyond the boundary sentence (brief section 4).

**Left for later stages (NOTES).** Private Fund Portfolio Detail, Fund Interest Holding Detail, the private-fund values of Projected Cash Source, Capital Activity Type, Capital Activity Source, Portfolio Transaction Type and Portfolio Identifier Scheme, and the eFront / Investran and ILPA sources serve private markets books (W4 decision on 30); Sponsor Program Agreement references 05 (replaced at W4); Related Transition Event and Source Cash Flow Notification reference 12 (adapted at W4); Scope names 30 for investor capital accounts.

**Open questions (W1b).**
1. (Ruled at the W1b fix pass, CW-918: accounts the firm manages inside a third-party sponsor's wrap or model program are sponsor program accounts of the intermediary channel, IC line; institutional separate accounts are the firm's own institutional mandates, IA line. SMA Portfolio Detail and Manages Account serve both.) Which sponsor programs does the IC line serve with full discretion (a book per account) rather than by model delivery?
2. Does the optional trust company run common trust fund books (Business Line TR) in this IBOR, or are trust accounts client accounts in 49 and 51?
3. Is any portfolio kept for the alternative-investment feeder funds of 01 and 15 (Fund Interest Holding Detail), or do the feeders sit with the external manager?

**Fix pass (W1b review).** Sponsor and wrap program accounts reworded as IC-line sponsor program accounts (program lead ruling 1); Managing Entity covers oversight of external sub-advisers (52); Followed Model Portfolio reconciles to a 15 Program Enrollment only where the account has one; Lot Rule Jurisdiction recorded as a generic attribute that became single-valued under US-only scope; SME question 11 and the 05 / 15 overlap lines reworded.

**Unverified.** The Section 28(e) release URL is copied from 23 (the reviewer confirmed it resolves); the SEC Section 31 fee wording is general (confirm with fund accounting how it is booked).
