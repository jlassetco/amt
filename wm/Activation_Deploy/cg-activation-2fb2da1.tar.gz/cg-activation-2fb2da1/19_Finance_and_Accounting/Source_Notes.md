# Source Notes: 19 Finance & Accounting

**Workbook:** `Finance_and_Accounting_Data_Taxonomy.xlsx` (built from `_tools/content/content_19_finance_and_accounting.py`)
**Status:** Draft v0.2, 2026-10-06 (review 19_review.md applied); wealth model carry-over (W1b, CW-919), 2026-10-14: Wealth manager (direct) | Scope: US; 248 attributes, 82 CDEs (33.1%), 16 sources (section 6). The counts below are those of the wholesale review. 8 families, 29 objects (28 business objects, 1 attribute group), 249 attributes, 82 proposed CDEs (32.9%), 28 local code lists plus 10 enterprise shared lists, 45 relationships, 18 sources, 11 attributes flagged PII. Domain code `FI` (the brief was first written with `FN`; changed because the data product framework uses `FN-01` to `FN-18`).

**Why this domain exists.** The firm's general ledger, chart of accounts and financial close are run by the Finance function (the Controller's group, Financial Reporting, FP&A and Tax) for every legal entity of the US wealth manager group (holding company, advisers, self-clearing broker-dealer, transfer agent, recordkeeper, service company, optional national trust company) and every business line. Until now the only finance domain was 10 Distribution Finance & Profitability, which had to model the chart-of-accounts mapping and GL postings itself and which, by design, sees only distribution revenue and cost. Corporate payables and receivables, consolidation, statutory and regulatory financial reporting, enterprise planning and corporate tax had no home. 19 masters the ledger and the records Finance produces; 10 keeps the distribution view of revenue, cost and profitability on top of it (CD-144), the same pattern as the employee master and the Sales Person profile. The books of the funds the firm manages are not here: they are 27 Fund Accounting & Valuation.

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| FASB Accounting Standards Codification (ASC 105, 250, 326, 606, 740, 810, 830) | https://asc.fasb.org | Consolidation under the voting interest and VIE models (Control Assessment Basis, Consolidation Method, consolidated funds and GP entities), functional currency and translation (Ledger Currency, Functional Currency, Translation Rate Type), income tax provision components and uncertain tax positions, expected credit losses on receivables, revenue disaggregation (moved from 10), restatement of comparatives. |
| US GAAP Financial Reporting Taxonomy (XBRL) | https://www.fasb.org/xbrl | Statement elements and captions for Financial Statement Class and Financial Statement Line (XBRL Element). The page returned HTTP 403 to automated fetch; it is the address given in the brief and used by 10. |
| SEC Regulation S-X | https://www.ecfr.gov/current/title-17/chapter-II/part-210 | Required financial statements and captions. |
| XBRL Global Ledger Taxonomy Framework 2015 (Recommendation) | https://www.xbrl.org/int/gl/2015-03-25/gl-framework-REC-2015-03-25.html | Account, journal header and line, debit/credit indicator, source document and subledger concepts. Shaped the split of Journal Entry (header) and GL Posting (line), and the Journal Source list. |
| OECD Guidance for the Standard Audit File - Tax (SAF-T), Version 2.0 (April 2010) | https://web-archive-storage.oecd.org/aemint-web-archive-prod/web-archive/31/319f3ea18d49a9a849ac736cc1cb6b6325080f23fcee60705509cf6b00a8af4e.pdf (OECD web archive copy; confirm a stable link) | Master files (general ledger accounts, customers, suppliers, tax table) and entries (GL journals, invoices, payments), used to cross-check Payable Invoice, Receivable Item and GL Account. |
| ISO 20022 pain.001, camt.053, camt.054 | https://www.iso20022.org/iso-20022-message-definitions | Payment method values, value date, bank statement entry reference for cash application. |
| SEC Rule 17a-5 (Form X-17A-5 FOCUS Report) and FINRA eFOCUS | https://www.finra.org/filing-reporting/focus | Part II (carrying / clearing firms) and Part IIA (other broker-dealers); filing through eFOCUS on the FINRA Gateway. Page verified. |
| SEC Form ADV, Part 1A Item 5.F and Part 2A Item 18 | https://www.sec.gov/about/forms/formadv.pdf (confirm) | Form ADV financial items of the advisers as a Regulatory Return Type (W1b, CW-919). |
| Streamlined Sales and Use Tax Agreement (SSUTA) and state sales and use tax laws | https://www.streamlinedsalestax.org (confirm) | US sales and use tax on purchases and sales; use tax self-assessment; exemption certificates (Indirect Tax Detail, W1b, CW-919). |
| SEC Rule 15c3-1 (net capital) | https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.15c3-1 | Capital requirement and capital resources reported on FOCUS. |
| OECD Transfer Pricing Guidelines (2022), Chapter V | https://doi.org/10.1787/0e655865-en | Master file, local file and country-by-country report as TP Documentation Type (the DOI 10 also cites). |
| OECD Pillar Two GloBE Model Rules and GloBE Information Return | https://www.oecd.org/en/topics/sub-issues/global-minimum-tax.html (confirm) | Top-up tax as a tax type and provision component. OECD page returned 403. |
| IRS Form 1120, Form 8975; IRC Section 6662(e) | https://www.irs.gov/forms-pubs/about-form-1120 | US corporate return, CbC report, contemporaneous documentation for penalty protection. |
| Sarbanes-Oxley Section 404, PCAOB AS 2201, COSO 2013 | https://pcaobus.org/oversight/standards/auditing-standards/details/AS2201 | Journal approval and segregation of duties, close controls, account reconciliations (Journal Approved By, Manual Journal Indicator, Close Task, Account Reconciliation Frequency). |
| SAP S/4HANA Universal Journal, Oracle Fusion Cloud General Ledger, Workday Financials worktags | https://docs.oracle.com/en/cloud/saas/financials/ | Cross-checks only: primary / secondary / reporting-currency ledgers, company codes, chart segments vs worktags, balance types, subledger control accounts. No field dictionary copied. SAP and Workday documentation URLs were not cited (not verified). |

## 2. Design decisions and boundary calls

- **Moved from 10 under CD-152 (names kept).**

  | 10 attribute ID | 10 object | Attribute | 19 attribute ID | 19 object | Change |
  |---|---|---|---|---|---|
  | DF-COA-005 | Account Mapping | External Reporting Line | FI-COA-040 | Financial Statement Line | moved to the new statement line object (see review response) |
  | DF-COA-006 | Account Mapping | XBRL Element | FI-COA-041 | Financial Statement Line | as above |
  | DF-COA-007 | Account Mapping | Revenue Disaggregation Category | FI-COA-044 | Financial Statement Line Mapping | code list cited as `External (10 - Revenue Stream)` |
  | DF-COA-010 | GL Posting | Journal ID | FI-JNL-001 / FI-JNL-013 | Journal Entry (key) / GL Posting (reference to the header) | the key is on Journal Entry; GL Posting keeps the name as the reference |
  | DF-COA-011 | GL Posting | Journal Type | FI-JNL-003 | Journal Entry | header attribute; list gains Fee Waiver / Expense Reimbursement and Management Fee Offset |
  | DF-COA-012 | GL Posting | Posting Date | FI-JNL-005 | Journal Entry | header attribute |
  | DF-COA-013 | GL Posting | Posting Accounting Period | FI-JNL-006 | Journal Entry | header attribute |
  | DF-COA-014 | GL Posting | Posting Legal Entity | FI-JNL-007 | Journal Entry | header attribute; noted as determined by the ledger |
  | DF-COA-015 | GL Posting | Posted Account | FI-JNL-015 | GL Posting | re-typed from Code (Firm-defined) to Reference (GL Account, 19) |
  | DF-COA-016 | GL Posting | Posted Amount | FI-JNL-017 | GL Posting | definition states the amount is unsigned |
  | DF-COA-017 | GL Posting | Source Finance Record | FI-JNL-022 | GL Posting | extended to 10 Waiver Record (WVR-) and Contract Cost Asset (CCA-) |
  | DF-COA-018 | GL Posting | Intercompany Partner Entity | FI-JNL-027 | GL Posting | none |
  | DF-DMM-001 | Accounting Period Status | Period Close Status | FI-CLS-003 | Accounting Period Status | list gains Not Yet Opened, Permanently Closed |
  | DF-DMM-002 | Accounting Period Status | Translation Rate Type | FI-CLS-004 | Accounting Period Status | now the income statement (average) rate type; Balance Sheet Translation Rate Type added |

  The 10 lists `Journal Type` and `Period Close Status` move with them (values kept, additions marked "Added in 19"). 10 keeps Account Mapping narrowed to Management P&L Line -> GL Account; the re-typing of `GL Natural Account` and `Applicable Ledger` and every other change to 07, 09, 10, 12, 14 and 20 is proposed in `proposals_19.py` section 6, not applied.
- **Journal Entry vs GL Posting.** XBRL GL and SAF-T both separate the journal header from its lines. GL Posting's grain is journal x line, with `Journal Line Number` and `Debit Credit Indicator` added. Journal Entry carries both `Journal Prepared By` and `Journal Approved By`, so segregation of duties can be evidenced. Subledger sources are three typed references (payable invoice, supplier payment, receivable item) rather than one polymorphic one.
- **Payroll posts in summary (program lead decision 1).** GL lines are posted from a payroll run, never per employee. `Source Payroll Run` holds the run identifier as a derived copy owned by 20; `proposals_19.py` asks 20 to add a Payroll Run object (legal entity x pay period x run) to which Payroll Result rows roll up, and to drop the employee-level `Payroll GL Posting` link. No compensation detail is held here.
- **Posting sources from 10 (program lead decision 2).** `Source Finance Record` now covers FRR-, WVR-, DCO-, ACR-, CCA-, ARN- and ICC-, so fee waivers, expense reimbursements and contract cost amortization can be journaled.
- **Accounting company code (program lead decision 3).** Mastered once, as the Chart Segment Value of segment "Company" (its Segment Value Code), with Represented Legal Entity. It was removed from Ledger. 09 `Internal Legal Entity.Accounting Company Code` is proposed as a derived copy of that segment value, not a reference to a ledger.
- **Chart Segment Value** masters cost and profit center codes (amends CD-084) and never natural accounts (GL Account is the only record for those). Format decision: the posting code is the bare GL code (e.g. 41020); the 09 org unit keeps its `OU-CC-` key and is linked through Represented Org Unit. The three 10 cost-center references and the 09 descriptions and REL are covered in the proposals.
- **Ledger** grain is legal entity x accounting basis x ledger currency x ledger role (an adjustment ledger shares the first three with its primary). A consolidation ledger is kept for the group parent. Functional currency is the primary ledger's currency (moved off Consolidation Scope Entity).
- **Financial statement lines.** A new Financial Statement Line object (framework x line) masters the line code, caption (`External Reporting Line`) and `XBRL Element`. The mapping links GL accounts to it; Financial Statement Line Values reference it, so the caption and element are not duplicated.
- **GL Account Balance** grain adds balance currency; the "Budget" balance type was dropped because plan amounts live only on Financial Plan Lines.
- **Consolidation Scope Entity** has exactly one consolidated unit per row: a legal entity (09), a fund product (01) or a seed portfolio (18). Ownership links stay in 09 Entity Ownership Relationship; 19 holds the accounting conclusion.
- **Intercompany matching** uses the shared Reconciliation Status list, with a separate `Eliminated Indicator`, because a balance can be matched and eliminated at the same time.
- **Payables and receivables (CD-158, program lead decision 5).** Payable Invoice (now with a Payable Document Type for invoices, credit notes and prepayments), Payable Invoice Line, Supplier Payment, Supplier Payment Application (payment x invoice, allowing partial payments), Receivable Item and Cash Receipt Application are generic. Links to the domain records are held on the 19 records only. The reviewer did not identify a domain that has no other way to find its invoice, so no reverse links are proposed for 05, 12, 13 or 14; 14's existing `AP Document Reference` and 12's `Payment Status` become derived copies. Receivable Item gains `Debtor Fund Product` (funds the firm manages are 01 products, not 02 parties), `Source Intercompany Charge` and `Other Source Document Reference` (carried interest, fee offsets, subleases).
- **Indirect Tax Detail** is an attribute group of Payable Invoice Line. Since W1b it holds US sales and use tax; `Supplier VAT Number` was removed (CW-919).
- **Financial reporting.** Regulatory Financial Return holds the capital requirement and resources amounts as reported values; capital management is 43. MIF001 (own funds) and MIF002 (liquid assets) are separate values.
- **Planning.** Financial Plan Version (FPL-) is the enterprise plan; 10 BUD- versions roll into it through a link held on 10. Planned FTE is a top-down target; position-level FTE is 20 Workforce Position. Plan Type follows 10 (Annual Budget, Rolling Forecast, Long-Range Plan, Scenario); stress cases are Plan Scenario values.
- **Corporate Tax (subject to CD-149).** Tax Type holds taxes only; FATCA registrations (GIIN) sit under Withholding Tax and country-by-country reports are TP Documentation. Provision Component values are grouped as expense or balance components; the effective tax rate is computed from the rows, not stored.
- **Transfer Pricing Documentation (program lead decision 4)** is its own Business Object: documented legal entity or group x fiscal year x document type (local file, master file, CbC report), with an identifier, referencing the entity or group parent, not a tax return. 10 `TP Policy.TP Documentation Reference` is proposed as a reference to it.
- **Shared lists.** 19 is not yet a member of any shared list, so attributes cite `Shared: <name>` directly and the module reads the values from `shared_code_lists.py`. Stewardship of Payable Invoice Status and Outgoing Payment Status moving to 19 is recorded in `proposals_19.py`.
- **Ownership mechanics.** Fiscal periods and FX rate types are carried as Code with `External (09 Shared - ...)`, as 10 does, and forced to 09 in `enrich_19.py`. Employee references are forced to 20 (CD-151 not yet applied). Because JNL- is still registered to 10, journal references are forced to "mastered here". Derived copies: Applied Exchange Rate (owner 22, CD-153) and Source Payroll Run (owner 20).

**Deviations from the brief.**
1. Transfer Pricing Documentation is a Business Object keyed by entity or group x fiscal year x document type, not an attribute group of Tax Return (program lead decision 4). The brief's 25 BO + 2 AG becomes 28 BO + 1 AG.
2. Two objects were added: Financial Statement Line (review finding B) and Supplier Payment Application (review finding D). 29 objects, within 27 ± 3.
3. The accounting company code is not on Ledger; it is the Company Chart Segment Value (program lead decision 3).
4. Local lists: the brief's `Tax Return Status` is `Return Filing Status`, also used by Regulatory Financial Return. The brief's local `Intercompany Match Status` is replaced by the shared Reconciliation Status plus an indicator. Added `Ledger Role`, `Journal Status`, `Control Assessment Basis`, `Indirect Tax Recoverability`, `Receivable Source Type`, `Payable Document Type`, `Plan Type` and `TP Documentation Type`. Payment terms (dropped), write-off reason and consolidation group are not local lists.
5. The shared Severity list named in the brief is not used: Close Issue Severity was dropped to stay within 250 attributes.
6. 07 Compensation Accrual is a posting source only through Journal Source and a logical relationship, because it has no key.
7. Statement line code examples avoid two-letter prefixes (`IS0110`, `BS0120`), since `IS-` reads as a domain code.
8. To stay within 250 attributes after the review additions, these attributes were removed: Chart Owner, Close Issue Severity, Consolidated Fund Indicator, Functional Currency, Effective Tax Rate, Expected Credit Loss Allowance, Write-Off Reason, Regulatory Submission Reference and Return Preparer Firm. These were removed or replaced by review fixes: Ledger.Accounting Company Code, Invoice Accounting Journal, Source Distribution Plan Version, Statement Line Label, Mapping Reporting Framework, Paid Invoices, Source Subledger Document and Source Payroll Result.

**Review response (00_Program/Expansion/Reviews/19_review.md).** All High and Medium findings and the six program lead decisions were applied, except as listed below. Lows were applied except as listed.
- *A, Medium: replace the per-domain "Source X" attributes on the 19 records with one typed "Source Domain Document" pair.* Not applied. Lead decision 5 keeps the links on the 19 records. Typed per-domain references resolve ownership and lineage automatically; a type + free ID pair would not. The duplication the reviewer flagged is removed instead by dropping every proposed reverse link.
- *D, Medium: GL Account Balance account combination held as Text.* Partly applied. Balance currency was added to the grain and "Budget" was dropped. The combination stays a concatenated key of Chart Segment Value codes (noted on the attribute), because a variable-length set of segment references cannot form a grain key.
- *E, Low: flag Journal Entry.Posting Legal Entity as a Derived copy.* Not applied as a flag. The contract allows DERIVED only for values owned by another domain, and the attribute is already typed as a reference to 09. A note says it is determined by Journal Ledger -> Ledger Legal Entity.
- *D, Low: Cash Receipt header.* Not modeled. Receipt-level facts still repeat per application. A Cash Receipt header (amount, currency, bank account) belongs with bank accounts in 43, or in 19 if there is no treasury function (SME Q4). Recorded in the proposals notes.
- *F, Low: Revenue Disaggregation Category cites an External 10 list.* No action, as the reviewer accepted.
- *G, Low: US GAAP Taxonomy URL differs between 10 and 19.* 19 keeps the FASB page. Aligning 10 is proposed, because 10 cannot be edited here.
- *J, Low: CDE consistency.* Partly applied. Financial Statement ID and Payment Value Date are now CDEs; Plan Version Status and Close Task Status are not. TP Documentation Type stays a CDE because it is now part of the grain. Statement Line Code is a CDE only on Financial Statement Line. Close Task ID and several secondary keys were left non-CDE to keep the share at 32.9% (target 25-35%).
- *H, Medium (mutual funds): expense reimbursements payable to a fund.* Recorded as a gap. Payable Invoice assumes a supplier party, and own funds are 01 products. Reimbursements are journaled from 10 Waiver Records (Journal Type "Fee Waiver / Expense Reimbursement"); a generic payable to a fund needs the same Debtor Fund Product pattern on the payable side if the business wants it (SME question 13).
- *H, Medium (private markets): management fee offsets.* Modeled as a Journal Type value and a receivable source (Other Source Document Reference). A full offset calculation belongs to 30 Private Markets.

## 3. What could not be verified

- The OECD Transfer Pricing Guidelines are cited by DOI (as 10 does). The Pillar Two page and the FASB XBRL page returned HTTP 403 to automated fetch and must be confirmed. The SAF-T guidance now points at the OECD web archive copy of the 2010 PDF; confirm a stable OECD link.
- Return values: whether the optional national trust company files a Call Report, and the Form ADV items used as financial returns, are marked "confirm".
- The FOCUS Part IIA capital requirement example (USD 25,000) is illustrative; the actual minimum depends on the broker-dealer's business under Rule 15c3-1.
- The XBRL element example `us-gaap:DistributionAndServicingFees`, carried from 10, is still marked "to confirm".
- Year-type fiscal period IDs (`FY2027-Y`) assume 09 issues them; confirm the format with 09.
- SAP S/4HANA and Workday Financials structures are cited from general knowledge; no vendor URL was verified for them.
- ERP document numbers, ledger IDs, company codes, tax registration numbers and amounts in examples are illustrative.

## 4. Open questions for client SMEs

1. Which ERP is the general ledger, how many ledgers and accounting bases are kept per entity, and is there a separate consolidation tool?
2. What are the chart segments (company, natural account, cost center, product, channel, intercompany), and does product or channel sit in the GL or only in 10's management view?
3. Does the trust company (CIT trustee), if a group entity, file bank regulatory financial returns that belong here?
4. Is there a separate Corporate Treasury function (plan §3 item 43), or do bank accounts, cash receipts and regulatory capital fold into 19?
5. Is fee revenue booked from 10 Fee Revenue Records, from fund accounting accrual feeds (27), or from billing (12)? Which is the subledger of record?
6. Are seed investments, GP entities and private funds consolidated, and who runs the ASC 810 assessment?
7. Tax (CD-149): one Tax domain or tax split by producer? Who owns corporate tax data today?
8. Which AP / procurement system holds supplier invoices, and is the supplier master in the ERP or in procurement (40)?
9. Are enterprise budgets and forecasts produced in a planning tool separate from 10's distribution plan?
10. Which regulatory financial returns are filed by which entities (FOCUS Part II and the annual report of the broker-dealer, Form ADV items of the advisers, a Call Report of the trust company)?
11. Is the 09 Fiscal Period Status a copy of the group primary ledger's status, or should 09 drop it?
12. Does the payroll system post one summary journal per run and legal entity, or per run, entity and cost center (this sets the Payroll Run grain proposed for 20)?
13. Are expense reimbursements owed to funds settled through AP (needing a fund payee on Payable Invoice) or only through fund accounting?

## 5. Recommended next steps

1. Review with the Controller, Financial Reporting, FP&A, AP / AR and Tax; confirm CDEs.
2. Map attributes to the ERP GL, subledgers, consolidation and planning tools; record the system of record per object.
3. Apply the CD-152 and CD-158 changes in 07, 09, 10, 12 and 14, the 20 Payroll Run proposal and the decision text updates (proposals_19.py sections 4, 6 and 7) at consolidation.
4. Re-register JNL- to 19 and add the CONCEPT_OWNERSHIP rows, so the enrichment overrides for journal references can be removed.
5. Confirm the "confirm" URLs and regulatory return codes in section 3.
6. Decide CD-149 before Stage 2 (27 Fund Accounting will need the Accounting Basis and Tax Type lists).

## 6. Wealth model carry-over (W1b, CW-919)

19 is kept (plan section 5.1). The pass made only the changes CW-022 allows: the US-only pass and the perspective text. No object is removed or renamed. One attribute is removed (Indirect Tax Detail.Supplier VAT Number), so the attribute IDs of the Payables family renumber after Indirect Tax Detail. The decision draft and the jurisdiction entries are in `_tools/consolidation/proposals_w1b_19.py`.

**Removed (EU/UK only; 26 jurisdiction entries: Other EU/UK 17, FCA 4, UK market practice 3, EU market practice 1, ICARA 1).**
- Indirect Tax Detail: Supplier VAT Number.
- Regulatory Return Type values FCA MIF001 Own Funds Return, FCA MIF002 Liquid Assets Return, FCA Financial Return (other), CSSF Management Company Return, Central Bank of Ireland Return, FCA MIF007 ICARA Questionnaire.
- Accounting Basis values (shared list, steward 19) IFRS (EU-adopted), UK-adopted IFRS, FRS 102 (UK GAAP), Lux GAAP, Irish GAAP (FRS 102); US GAAP, Tax Basis and Regulatory stay. The shared list is re-cut by its steward at W5 (SHARED_RECUTS).
- Payment Method values SEPA Credit Transfer, UK Faster Payment, BACS, CHAPS (payment schemes of the former EU/UK entities; foreign suppliers are paid by wire).
- Control Assessment Basis values IFRS 10 Control - Principal and IFRS 10 - Agent; Indirect Tax Recoverability values Partially Recoverable, Reverse Charge - Self-Accounted and Exempt Supply (VAT terms); Tax Type value VAT.
- Sources: IFRS Standards (the basis of the EU/UK group entities; the firm's own books are US GAAP), FCA MIFIDPRU and RegData, Council Directive 2006/112/EC (VAT), UK Companies Act 2006 Part 15. IFRS 10, IFRS 15, IAS 1, IAS 12 and IAS 21 also left the secondary references of 25 attributes and the alignment of five lists (Consolidation Method, Control Assessment Basis, Financial Statement Type, Provision Component, and the Revaluation and Uncertain Tax Position value notes).

**Re-sourced.**
- Regulatory Financial Return to the FOCUS Report (Form X-17A-5, SEC Rule 17a-5) and Form ADV financial items (new source row, confirm): Return Filing Entity and Regulatory Return Type cite SEC Form ADV as secondary; the example is now FOCUS Report Part II (the self-clearing broker-dealer); new value Form ADV Financial Information; Bank Call Report re-worded to the optional national trust company; list alignment SEC / FINRA / OCC; Capital Requirement Amount and Capital Resources Amount read the Rule 15c3-1 net capital terms only.
- Indirect Tax Detail and Receivable Item.Output VAT Amount to US sales and use tax (new source row: the Streamlined Sales and Use Tax Agreement and state law, confirm): Indirect Tax Type (example Sales and Use Tax), Indirect Tax Rate, Indirect Tax Recoverability (list re-cut to Irrecoverable, Use Tax - Self-Assessed, Exempt Purchase, Fully Recoverable), Recoverable Percentage (kept generic: 0% for US sales and use tax, because DP-195 and SM-14 read it), Output VAT Amount (name kept; advisory, management and trust fees are generally not subject to state sales tax). EU VAT Directive left the secondary references of Payable Document Type, Supplier Invoice Number and Invoice Date.
- Control Assessment Basis aligned to ASC 810 and ASC 946 (Investment Entity Exception re-described under ASC 946).

**Perspective rewritten.** META subtitle; overview Purpose (the US wealth manager group entities; every business line), Scope (FOCUS, Form ADV, Call Report), Design principle 2 (US GAAP, regulatory and tax books), Primary / Secondary Reference, Notes (US privacy law); the Regulatory Financial Return object group text and the Indirect Tax Detail group text; examples in USD instead of GBP across Payables and Receivables, chart segment value "Human and Hybrid Advice - East Region", close task "Reconcile intercompany balances with the broker-dealer", payroll run "US-SM-2026-09-R1", payment run "US-AP ...", payment method ACH Credit, tax registration US-PA / Sales and Use Tax / PA-87654321, TP documentation "US Local File FY2025"; the Capital and Liquidity Stress plan scenario no longer cites ICARA; SUMMARY and the Indirect Tax Detail grain in `enrich_19.py`; this file's status line, rationale, sources, design notes, unverified list and SME questions 6 and 10.

**Re-pointed.** "02 Client & Customer" reads "02 Client & Household" and "01 Investment Product" reads "01 Investment Product & Service Offering" in SUMMARY; Party references resolve unchanged (CW-021).

**Added.** Nothing beyond what the re-sourcing needs (the brief names no addition): the Regulatory Return Type value Form ADV Financial Information and two source rows.

**Review fix pass (2026-10-14).** Capital Requirement Amount and Capital Resources Amount examples are now those of a carrying broker-dealer (USD 250,000 minimum under Rule 15c3-1; USD 412,000,000 net capital); Intercompany Balance amounts and Covered Transaction Value are in USD (the US group has no euro-ledger entity; GL Posting keeps a EUR transaction amount, a foreign-currency transaction under ASC 830); the indirect tax fields cite state sales and use tax law as primary and SSUTA as secondary (Pennsylvania, the example state, is not an SSUTA member); Form ADV Financial Information names Part 2A Item 18 as the financial item and Part 1A Item 5.F as a reported amount (confirm); Design principle 1 reads "revenue of the adviser". Output VAT Amount is a rename candidate for W5 ("Output Indirect Tax Amount").

**Kept on purpose.** Foreign currency translation (ASC 830) and FX rate references; OECD SAF-T as a market-neutral structural reference; transfer pricing documentation and OECD Pillar Two (see open question 2).

**Left for later stages (NOTES in the proposals file).** References to 10 Distribution Finance & Profitability, 05 partner invoices and payments, 07 compensation accruals, 12 fee invoices and 13 intermediary communication fee invoices (W2, W4); private-markets content (Management Fee Offset journal type, Carried Interest / Incentive Allocation receivable source and its 30 note, Revenue - Performance Fees and Carried Interest caption) for the W4 retirement of 30.

**Open questions (W1b).**
1. Does the optional national trust company file an FFIEC Call Report (trust-only national banks generally do), or only OCC trust reports (confirm)?
2. A purely domestic US group is not an MNE group under the GloBE rules and files no country-by-country report: keep Pillar Two Top-Up Tax, the Pillar Two provision component and the CbC documentation type as a tailoring lever, or remove them at W5?
3. Which states tax any of the firm's services (for example digital advice subscriptions) so that Output VAT Amount is ever non-zero (confirm with Tax)?

**Unverified.** SSUTA and Form ADV URLs (confirm); Form ADV Part 1A Item 5.F and Part 2A Item 18 as the financial items (confirm).
