# Source Notes: 20 Human Capital

**Workbook:** `Human_Capital_Data_Taxonomy.xlsx` (built from `_tools/content/content_20_human_capital.py`)
**Status:** Draft v0.1, wealth model (direct), scope US, 2026-10-14: the draft of 2026-10-06 (revised after the independent review, `00_Program/Expansion/Reviews/20_review.md`, and by CD-364) carried over with the US-only pass and the perspective rewrite of CW-920 (section 6). 7 families, 28 objects (25 business objects, 3 attribute groups), 231 attributes (24 moved from 09), 74 proposed CDEs (32%), 59 code lists (53 local, 6 enterprise shared lists used directly), 38 relationships, 20 sources, 163 attributes flagged PII (11 of them special category data). No Record Metadata object (governance metadata is modeled once in 21, CD-148).

**Why this domain exists.** Employee data is produced and maintained by HR from the HR system of record, which is why decision CD-120 lifted the employee master out of 03 Sales in v0.3. At the time the only enterprise home was 09 Shared & Enterprise Reference Data, so the Workforce family there held just an Employee and a reporting line, enough for the distribution domains to reference `EMP-`. The enterprise needs the rest of the HR record that every function relies on: jobs and positions, employment events, compensation and benefits, performance, talent and learning. This domain takes the employee master from 09 (CD-151) and adds that record, so 09 returns to reference data (geography, calendars, legal entities, org units) and every domain keeps referencing the same `EMP-` key. The firm is a US wealth manager (a direct brokerage platform, digital and human advice, its own mutual funds, ETFs and CITs, workplace recordkeeping, institutional advisory and optional trust services) that employs in the US only: its regulated roles are FINRA-registered principals, representatives and operations professionals of the self-clearing broker-dealer and investment adviser representatives of the adviser, so the job profile records those registration needs and the individual registrations stay in 08. The EU/UK remuneration codes and material risk taker identification that shaped the wholesale reward family were removed under CW-920 (section 6).

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| HR Open Standards (HR-JSON) | https://www.hropenstandards.org | Vocabulary for person, employment, position opening, candidate, application, screening and assessment. Shaped the recruiting objects and the lifecycle event. |
| ISO 30414:2025 Human resource management: requirements and recommendations for human capital reporting and disclosure (second edition, published 24 August 2025; first edition ISO 30414:2018 at https://www.iso.org/standard/69338.html) | https://committee.iso.org/sites/tc260/home/news/content-left-area/news-and-updates/iso-30414-2025-strengthening-hum.html | Metric areas (workforce composition, diversity, costs, productivity, turnover, recruiting, training, leadership). Used for Human Capital Metric Value, Authorized FTE, turnover fields (Voluntary Termination Indicator, Termination Reason) and recruiting measures (Candidate Source, time-to-fill dates). The standard itself is paid; the metric list was not read in full. |
| US SOC 2018 | https://www.bls.gov/soc/ | Occupation code on Job Profile; example 13-2052 Personal Financial Advisors. |
| FINRA Rule 3110(e), Forms U4 / U5 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110 | Investigation of applicants for registration, fingerprinting and review of the applicant's most recent Form U5 (Background Screening, the Prior Form U5 Review screening type); Form U5 within 30 days of termination as the trigger in Regulatory Notification Required Indicator. Filings stay in 08. |
| FINRA Rule 1220 registration categories; SEC Rule 203A-3(a) | https://www.finra.org/rules-guidance/rulebooks/finra-rules/1220 ; https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.203A-3 (confirm path) | Registered principal, registered representative and operations professional categories, and the investment adviser representative (state registration through Form U4): the Regulated Role Category list (CW-920). |
| FINRA Rule 1240 (continuing education); FINRA Rule 3310(e) (AML training) | https://www.finra.org/rules-guidance/rulebooks/finra-rules/1240 ; https://www.finra.org/rules-guidance/rulebooks/finra-rules/3310 | Regulatory Credit Type (Firm Element only; the Regulatory Element is completed in FINRA's system and tracked in 08), Training Requirement Type and completion evidence. |
| EEOC EEO-1 Component 1 | https://www.eeoc.gov/data/eeo-1-data-collection | Sex (on Legal Gender), race / ethnicity categories and job categories; the workforce snapshot date on Metric Period End Date; the metric breakdowns. |
| EEOC recordkeeping, 29 CFR 1602.14 | https://www.ecfr.gov/current/title-29/subtitle-B/chapter-XIV/part-1602/section-1602.14 (confirm path) | Minimum retention of employment and application records (one year, longer where a charge is filed); primary reference of Candidate Data Retention End Date. |
| Fair Credit Reporting Act | https://www.ftc.gov/legal-library/browse/statutes/fair-credit-reporting-act | Disclosure, authorization and adverse action for background and credit checks; with state fair chance laws, the handling of criminal history (Background Screening Type and Result). |
| California CCPA as amended by the CPRA | https://cppa.ca.gov/ | Employee and applicant personal information and sensitive personal information (racial or ethnic origin, health, sex life or sexual orientation, biometric data, government identifiers); the special category notes, Diversity Data Processing Basis and candidate retention. |
| US FLSA; US FMLA | https://www.dol.gov/agencies/whd/flsa ; https://www.dol.gov/agencies/whd/fmla | FLSA Status; job-protected leave. |
| USCIS Form I-9 | https://www.uscis.gov/i-9 | Work Authorization Type (the I-9 categories) and expiry and re-verification. |
| VEVRAA and Section 503 (US DOL OFCCP) | https://www.dol.gov/agencies/ofccp | Protected veteran and disability self-identification. Applies to federal contractors; applicability to the firm to confirm. |
| IRS Form W-2; ERISA | https://www.irs.gov/forms-pubs/about-form-w-2 ; https://www.dol.gov/agencies/ebsa/laws-and-regulations/laws/erisa | Payroll run and result fields (wages, income tax and social security withheld separately); benefit plan years and types. |
| Workday HCM; SAP SuccessFactors Employee Central | https://www.workday.com ; https://help.sap.com/docs/SAP_SUCCESSFACTORS_EMPLOYEE_CENTRAL | Structure only: worker, position management (Job Profile vs Position vs assignment), supervisory organization, contingent worker types, compensation components. |

## 2. Design decisions and boundary calls

**Moves applied (CD-151).** The three objects below were copied into 20 with every name, definition, data type, example, reference and CDE flag identical to 09 (verified programmatically). Under the program lead's PII decision the Notes column was then completed with "PII" on every moved attribute (it had been missing on Employee ID, Job Title, Job Family, Employing Legal Entity, Home Org Unit, Work Location, Employment Type, Employment Status, Reporting Employee, Line Manager, Reporting Line Type, the two reporting dates, Assigned Org Unit and Assignment Effective From / To); this is logged as a CD-151 follow-up in `proposals_20.py`. The program lead removes the objects from 09 at merge; content_09 was not edited.

| Object (20 family) | Old 09 location and attribute IDs | Attributes |
|---|---|---|
| Employee (Employee Master) | 09 Workforce, SR-WFC-001 to SR-WFC-016 | 16 |
| Employee Reporting Line (Employee Master) | 09 Workforce, SR-WFC-017 to SR-WFC-021 | 5 |
| Org Unit Assignment (Jobs, Positions & Assignments) | 09 Internal Organization / Org Hierarchies, SR-ORG-018 to SR-ORG-020 | 3 |
| Code lists Employment Type, Employment Status, Reporting Line Type | 09 CL | values unchanged |

The brief's target size says "21 moved from 09"; with Org Unit Assignment it is 24.

**Program lead decisions applied (review Highs):**
1. **Material risk taker identification was mastered in 20** (HR runs it; removed from the wealth model under CW-920, section 6, because no EU/UK remuneration code applies). 07 Remuneration Conflict Assessment / Identified Staff Indicator should keep only a Derived copy of 20 Material Risk Taker Identification / Material Risk Taker Indicator; the change to enrich_07 and the 07 definition is proposed in `proposals_20.py` (CROSS_DOMAIN_CHANGES), and 07 is added to the users of the concept. content_07 was not edited.
2. **PII rule:** every attribute of a record whose grain is an individual, every identifier of an individual (including Employee ID) and every reference to an employee on any other record is flagged PII. There are no exceptions. Records whose grain is not an individual (Job Profile, Workforce Position, Job Requisition, Benefit Plan, Payroll Run, Learning Item, Mandatory Training Requirement, Human Capital Metric Value) are not PII except for their employee references (e.g. Hiring Manager). Special category flags: diversity (racial or ethnic origin, health, sexual orientation), medical leave types and their dates (health), fingerprinting (biometric), criminal record results and severity (Article 10).
3. **Payroll Run object added** (Business Object, legal entity x pay period x run, firm-defined text identifier, no new prefix). Payroll Results roll up to it (n : 1). The GL link sits on the run: `Payroll Journal Entries`, Reference (Journal Entry, 19) (multi), JNL-, forced to 19 in OWNERSHIP_OVERRIDES until CD-152; cardinality one run : one or more journals. The per-employee posting link was removed. Pay date, pay period and legal entity moved from Payroll Result to Payroll Run. The proposal for 19 to re-type its GL Posting / Source Payroll Result to the run identifier is in `proposals_20.py`.

**Deviations from the brief's outline (§5) and lists (§8):**
1. **29 objects (brief 28):** Payroll Run added on the program lead's decision.
2. **Code list names qualified.** Lists the brief called Screening Result, Screening Type, Lifecycle Event Type, Termination Reason, Benefit Type, Review Type, Assignment Type, Vesting Basis and Remuneration Regime collide with lists in 08, 01, 05, 12, 16, 07 or with the shared Screening Result list (steward 08). They are named Background Screening Result, Background Screening Type, Employee Lifecycle Event Type, Employee Termination Reason, Employee Benefit Type, Performance Review Type, Job Assignment Type, Award Vesting Basis and MRT Remuneration Regime. NOT_MERGED entries are proposed.
3. **Shared lists used directly** as `Shared: <name>`: Record Status, Severity, Frequency, Regulator, Period Type, Information Classification (values copied from `shared_code_lists.py` at import). Approval Status was dropped with the trimmed approval attributes; Case Status and Personal Data Category are not used (requisitions have a recruiting-specific status; personal data is flagged in Notes and classification belongs to the 21 Object Governance Profile).
4. **Payroll Result references 07 Compensation Statements (CPS-, multi)**, not Payroll Payment Instructions, which have no identifier. Proposal for 07 recorded.
5. **Carried interest and co-investment** are Variable Award Type values with `Carried Interest Points` and a `Linked Fund` reference to 01 Product (the fund, not the carry vehicle, which is left to 30).
6. **Mandatory Training Requirement** grain is requirement x applicable population x effective period; the population is a rule (text).
7. **Learning Completion** also holds assignments not yet completed, with a Completion Due Date from which Overdue is derived.
8. **Performance Review** grain is employee x review cycle x review type (brief: employee x review cycle), so a mid-year and a year-end review in one cycle year can coexist.
9. **Contingent Worker Detail** stays an attribute group holding the current engagement only; successive SOWs are recorded as Contract Extension lifecycle events (the UK IR35 determination was removed under CW-920).
10. **Personal data minimized.** No emergency contacts, dependents' details, candidate contact details, bank details or medical detail. Socio-economic background was not added.
11. **Size management.** To add the review's required attributes and the Payroll Run while staying within the 240-attribute target, these low-value attributes were removed: Candidate Email Address, Number of Openings, Requisition Job Profile (derived from the position), Covered Dependents Count, Leave Approval Status, Event Approval Status, Learning Duration Hours, Engagement Rate Basis (and the Rate Basis list), Job Profile Status, Metric Value Status (and its list) and Assignment Change Event.

**Boundary calls.**
- Profile pattern (CD-144): 03 Sales Person extends Employee by `EMP-`; no 03 change beyond stale definition text (proposal).
- Candidates and employees are not 02 parties for their employment (CD-143). `Client Party Cross-Reference` links the PTY- an employee holds as client, investor or participant in the firm's own recordkept 401(k) (16 keys participants by PTY-); Benefit Enrollment / Own Plan Membership links the PMEM-.
- Incentive comp is 07, reward is 20: "Annual Cash Bonus" is a discretionary bonus not paid under a 07 ICP-; 07 bonuses reach 20 only through payroll instructions (TERM_CONFLICTS "Bonus").
- Regulated Role Category is what the role requires (multi-valued; FINRA Rule 1220 categories and investment adviser representative); the individual's registrations and Form U4 status stay in 08.
- CE tracking stays in 08: 20 no longer links completions to registrations; 08 CE Requirement should reference 20 Learning Completion (proposal).
- Policy attestations stay in 08 (codes of ethics later in 38); sanctions and PEP screening of employees uses the 08 lists.
- Position FTE: Authorized FTE is the position's authorization; each position references the 19 Financial Plan Line whose planned FTE it reconciles to.
- Metric definitions and their allowed breakdowns are registered in 21 (`KPI-`); Human Capital Metric Value carries the breakdown values.

**References to sibling Stage 1 domains:** 19 Chart Segment Value (cost center), Financial Plan Line (FPL-), Journal Entry (JNL-, from Payroll Run); 21 Metric Definition (KPI-).

**Ownership resolution.** `EMP-` is still registered to 09, so 33 OWNERSHIP_OVERRIDES force employee references and references to 20's own objects to "mastered here", and one forces JNL- to 19. They can be removed once CD-151, CD-152 and the Stage 1 prefixes are applied.

### Review response

All three Highs were applied as decided by the program lead (above). All 30 Mediums were applied, four of them by the alternative the reviewer offered: Contingent Worker Detail holds the current engagement only (not converted to a business object); Nationality is kept as optional with a stated purpose and a link to SME question 8; Regulated Role Category was narrowed to the role requirement and made multi-valued, with a shared list proposed for 08 rather than referencing 08's list now (08's list lacks the FINRA values); the org-placement precedence rules are recorded as a NOTE in `proposals_20.py`. Lows were applied except the following:

| Finding | Not applied, or applied differently | Reason |
|---|---|---|
| J (Medium, part): `Business Email Address` CDE | CDE flag left as is | Moved tuple; CD-151 keeps the move identical apart from the PII notes ordered by the program lead. The regulated-reporting fields were made CDEs as asked. |
| B (Low): flag Employee Job Title, Job Family, Hire Date, Termination Date as derived | Recorded as a proposal, not flagged | DERIVED in the enrichment contract marks copies from another Data Domain; these are copies within 20, and the fields are moved tuples. |
| B (Low): Voluntary Termination Indicator | Kept, defined as derived from Termination Reason; each reason value now carries its voluntary / involuntary mapping | Turnover reporting reads the flag directly. |
| I (Low): relabel Org Unit Assignment Applies To; D (Low): split Assignment Effective From / To | Proposed only | CD-151 requires the moved tuples to stay unchanged. |
| G (Low): replace Workday home page | Kept https://www.workday.com | Workday's data model documentation is behind a customer login; no public document page to cite. The ESMA, EFRAG and ONS rows were replaced with document pages. |
| A (Low): carry vehicle | `Linked Fund or Vehicle` renamed `Linked Fund` and reworded; no carry vehicle reference | The vehicle belongs to 30 (not built; SME question 13). |

## 3. What could not be verified

- ISO 30414:2025 metric list: the standard is paid; only public summaries were read. The 2025 edition URL on iso.org was not confirmed.
- Whether VEVRAA / Section 503 self-identification applies (only to federal contractors).
- The "Mutual Agreement" voluntary / involuntary classification (firm convention).
- Vendor structures (Workday, SuccessFactors) were checked against public documentation only.
- Example identifiers (EMP-, LEN-, PTY-, LIC-, PMEM-, JNL-, payroll run identifiers, SOC 13-2052) are illustrative.

## 4. Open questions for client SMEs

1. Which HRIS is the system of record (Workday, SuccessFactors, other), and does it hold contractors, consultants and secondees as well as employees?
2. Are non-executive directors and fund board members in the employee master or only in 35 / 39?
3. Do firm-wide registrations stay in 08 (sales staff only) or move to 20 or 38?
4. Which compensation data may appear in a shared enterprise catalog given its confidentiality (base pay, bonuses, deferred awards, carry)?
5. (Closed by CW-920: material risk taker identification left the wealth model with the EU/UK remuneration codes.)
6. Does the firm recordkeep its own 401(k) plan in 16, and how does benefit enrollment link to it?
7. Is candidate data in scope for the enterprise model, or kept only in the applicant tracking system?
8. Which diversity data is collected, in which states, on what basis (including Nationality, Sexual Orientation and Protected Veteran Status)?
9. Which learning system holds completions, and does 08's CE tracking already depend on it?
10. Is position management used (budgeted positions), or are only jobs and assignments maintained?
11. Is payroll in house or outsourced, and what level of payroll detail should the enterprise hold?
12. (Closed by CW-920: no EU entity in the wealth model.)
13. (New) Are carried interest allocations administered by HR or by the private markets finance team, and should they stay in 20 or move to 30?
14. (New) Is a multi-entity payroll run ever posted as one journal, or is it always one run per legal entity as modeled?

## 5. Recommended next steps (including validation)

1. Walk the Hierarchy tab with HR operations, Reward, Talent Acquisition, Learning and People Analytics; confirm grains, especially Employee Job Assignment vs Org Unit Assignment, Payroll Run vs Payroll Result and Learning Completion.
2. With Compliance and Reward, test the Variable Compensation Award / Deferred Award Tranche chain against one real deferred award paid in fund-linked units and the firm's clawback policy.
3. With the privacy officer, confirm the special category items, the processing basis per state and the candidate retention period; agree default classifications for the 21 Object Governance Profile.
4. Map attributes to the HRIS, payroll, ATS and LMS extracts; confirm which fields actually exist.
5. Agree hand-offs: 07 Payroll Payment Instruction to Payroll Result; Payroll Run to 19 Journal Entry (both sides meet at the run identifier); Workforce Position to 19 Financial Plan Line; Benefit Enrollment to 16 PMEM-; Lifecycle Event (termination) to 08 Form U5; 08 CE Requirement to 20 Learning Completion.
6. At merge, apply CD-151 (remove 09 Workforce and Org Unit Assignment, re-point EMP- to 20, update ownership aliases) and run the full build and baseline check.

## 6. Wealth model carry-over (W1b, CW-920)

20 is kept (plan section 5.1). The pass made the changes CW-022 allows and no others: the US-only pass, the perspective text and the re-pointed wording around 02. No object or attribute is renamed; one object and four attributes leave. The certified headcount, FTE and pay definitions (CD-341, CD-364: Employment Status, Employment Type, Contingent Worker Type, Assignment FTE, Authorized FTE, Standard Weekly Hours, Full-Time Reference Hours, Hours Worked, the pay amounts) are unchanged; only the UK secondary references and the UK wording of the Hours Worked note were replaced. The decision draft and the jurisdiction entries are in `_tools/consolidation/proposals_w1b_20.py`.

**Removed (EU/UK only; 59 jurisdiction entries: Other EU/UK 30, FCA 13, SM&CR 6, UCITS 5, AIFMD 2, GDPR / UK GDPR 2, MiFID II 1).**
- Object Material Risk Taker Identification (8 attributes: MRT Employee, MRT Performance Year, Remuneration Regime, Identifying Legal Entity, Material Risk Taker Indicator, MRT Criteria Met, Deferral Exemption Applied Indicator, Identification Approval Date) with its two relationships and the code lists MRT Remuneration Regime (5 values) and MRT Criterion (11 values). It existed only for the UCITS, AIFMD, MIFIDPRU and IFD remuneration codes.
- Attributes: Employee Diversity Profile.UK Ethnic Group (with the list UK Ethnic Group, 6 values); Contingent Worker Detail.Off-Payroll Working Determination (with the list IR35 Determination, 4 values); Job Profile.ISCO-08 Code (used only for EU and UK statistical and ESRS reporting); Deferred Award Tranche.Retention Period End Date (the post-vesting retention of instrument awards is a UK/EU remuneration code rule).
- Code values: National Identifier Type UK National Insurance Number and EU National Tax Identifier; Work Authorization Type EU Free Movement; Regulated Role Category Senior Management Function, Certification Function and Conduct Rules Staff; Diversity Data Processing Basis Equality Monitoring (UK DPA 2018); Background Screening Type Regulatory References (FCA SYSC 22); Tranche Vesting Status Released After Retention; Regulatory Credit Type UK Structured CPD; Training Requirement Type Conduct Rules (FCA conduct rules); Training Requirement Type Market Abuse relabeled Insider Trading and MNPI (Advisers Act section 204A, Exchange Act section 15(g); review fix pass).
- Sources (14 removed, one retitled): ILO ISCO-08; FCA SYSC 19G, 19E and 19B; ESMA remuneration guidelines; FCA SM&CR; UK MLR 2017; UK gender pay gap regulations; EU Pay Transparency Directive; ESRS S1; GDPR and UK GDPR with DPA 2018; UK right to work guidance; HMRC IR35; UK ONS ethnicity standard; the MiFID II Article 16(7) half of the FINRA Rule 4511 source.

**Re-sourced.**
- Job Profile.Regulated Role Category to FINRA Rule 1220 registration categories and the investment adviser representative (SEC Rule 203A-3(a), state registration through Form U4): values FINRA Registered Representative, FINRA Registered Principal, FINRA Operations Professional (added: the self-clearing broker-dealer's covered back-office staff), Investment Adviser Representative (added), Not Regulated.
- Mandatory training: Training Requirement Type cites FINRA Rule 3310(e) and FINRA Rule 1240; Completion Date cites Rule 3310(e) alone; the value Conduct Rules becomes Code of Ethics and Conduct (Advisers Act Rule 204A-1 and the firm code); Data Protection cites Regulation S-P, Regulation S-ID and state privacy law.
- Diversity: EEO-1 is the primary reference; Diversity Data Processing Basis re-cut to US values (Explicit Consent, Employment Law Obligation, US Voluntary Self-Identification, Not Collected) and sourced to EEO-1 / OFCCP and the California CPRA; Diversity Collection Jurisdiction, Gender Identity, Disability Status and Sexual Orientation lose their GDPR and ESRS references.
- Special category handling (CD-344 and state law): the overview Notes define the restricted tier against CPRA sensitive personal information, state biometric privacy laws, the Fair Credit Reporting Act and state fair chance laws; GDPR Article 9 and 10 citations are gone from every note.
- Background Screening: Screening Type secondary reference FCRA; value Prior Form U5 Review (FINRA Rule 3110(e)) replaces Regulatory References; Criminal Record Check, Fingerprinting and Credit Check descriptions cite FCRA and state law.
- Candidate Data Retention End Date to 29 CFR 1602.14 and the CPRA.
- Variable Compensation Award and Deferred Award Tranche: every SYSC 19G / 19E / 19B and ESMA reference becomes Internal (the firm's compensation, deferral and clawback policy); the attributes stay (US firms defer, pay fund-linked awards and claw back). The Award Instrument, Variable Award Type, Tranche Vesting Status, Malus / Clawback Status and Objective Category lists are sourced to firm policy.
- Work Authorization Type to USCIS Form I-9 alone; Citizen / Settled Status relabeled US Citizen or Noncitizen National (the I-9 category); visa examples US only.
- Workforce metrics: Metric Breakdown and Metric Period End Date cite EEO-1 (the workforce snapshot date replaces the UK pay gap snapshot); Termination Reason and Voluntary Termination Indicator cite ISO 30414 only; Hours Worked cites the US FLSA (CD-364 definition unchanged); Business Phone Number cites FINRA Rule 4511.
- Sources added (4): FINRA Rule 1220 and SEC Rule 203A-3(a); 29 CFR 1602.14; the Fair Credit Reporting Act; the California CCPA as amended by the CPRA. Net 30 to 20 sources.

**Perspective rewritten.** META subtitle; overview Purpose, Scope, Core model, Applies To, CDE, Notes and Suggested next steps; the family texts of Compensation, Benefits & Payroll, Variable Compensation and Workforce Analytics; examples (USD amounts and a US payroll run, a US address, a masked SSN, a financial advisor job profile with SOC 13-2052, US country codes); the UK-flavored code-value descriptions (leave, benefits, allowance, auto-enrollment, working pattern); the DPO is the privacy officer; SUMMARY in `enrich_20.py`. The Distribution job family keeps its name and now reads "advice, sales, relationship management and client service".

**Re-pointed.** Client Party Cross-Reference reads "client of the firm (an account owner or household member)" instead of "client or investor"; the Party relationship note reads "client or own-plan participant"; 02 is named 02 Client & Household and 01 Investment Product & Service Offering. Every Reference (Party) still resolves (CW-021).

**Added.** None (the brief names no addition for 20).

**Left for later stages (not changed, listed in the proposals NOTES).** References to 07 (Compensation Statement, `CPS-`, on Payroll Result; the 07 hand-off in the overview and relationships), to 08 (Individual Registration, `LIC-`, on Background Screening; CE Requirement; Form U5 filing), to 03 (Sales Person profile) and to 30 (carry vehicle; Carried Interest Points and the carried interest and co-investment award values, a private-markets residue for the W4 decision).

**Open questions (W1b).**
1. Diversity Collection Jurisdiction holds a country; in a US-only firm the governing law differs by state. Should it hold a state (ISO 3166-2) or go (tailoring lever)?
2. Does the firm need Protected Veteran Status and Section 503 disability self-identification (federal contractor status)?
3. Should Award Instrument keep Carry Vehicle Interest and Variable Award Type keep Carried Interest Allocation and Co-Investment Entitlement once 30 retires (W4)?
4. Is a US pay transparency or state pay data report (for example California pay data reporting) in scope for Workforce Analytics? The pass did not add one.

**Unverified.** The eCFR paths of SEC Rule 203A-3 and 29 CFR 1602.14 follow the standard pattern (confirm); the FINRA Rule 1220 sub-paragraph numbers on the Regulated Role Category values (confirm); the FTC FCRA page and the CPPA home page as the citations (confirm); whether Rule 3110(e) still requires the review of the prior Form U5 in the form described (confirm against the current rule text).

**Review fix pass (2026-10-14).** Special-category notes now read "PII - special category (CD-344)"; Market Abuse relabeled Insider Trading and MNPI; the FINRA Rule 3110(e) source row now attributes fingerprinting to Exchange Act Rule 17f-2 and the 30-day Form U5 deadline to FINRA By-Laws Article V, Section 3 (both confirm); Candidate Data Retention End Date reworded against the 29 CFR 1602.14 minimum; the Full-Time Reference Hours and Standard Weekly Hours examples read 40.0 and 32.0 (CD-364 definitions unchanged); Remuneration Committee Approval Date listed as a rename candidate; the decision's domains list names 20 only.
