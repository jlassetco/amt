# Source Notes: 21 Data Governance & Analytics

**Workbook:** `Data_Governance_and_Analytics_Data_Taxonomy.xlsx` (built from `_tools/content/content_21_data_governance_and_analytics.py`)
**Status:** Draft v0.1 (revised after independent review), 2026-10-06; wealth model carry-over (W1b, CW-921), 2026-10-14: Wealth manager (direct) | Scope: US; 291 attributes, 91 CDEs (31.3%), 58 code lists, 23 sources (section 6). The counts below are those of the wholesale review.

**Counts:**
- 8 families and 28 objects (25 business objects, 3 attribute groups).
- 295 attributes, of which 92 are proposed CDEs (31%).
- 62 code lists, 51 relationships and 24 sources.
- 10 attributes flagged PII: 7 employee references and 3 record keys.

**Why this domain exists.** The Chief Data Office produces its own data:
- who owns and stewards each concept;
- what terms mean and which elements are critical;
- what the quality rules say and what they found;
- where data comes from and where it goes;
- which metrics and data products are certified;
- how AI uses data.

Until now that metadata was scattered:
- Each of Data Domains 01 to 16 carried its own "Record Metadata" block (16 objects, 27 distinct attribute names), which v0.3 excluded from every output.
- 06 kept its own DQ rules.
- 09 kept its code list registry.

This domain models governance metadata once (CD-148). It treats the taxonomy itself, the decision log and the data product catalog as governed assets. It describes data and never holds business values.

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| DAMA-DMBOK (2nd edition, revised) | https://www.dama.org/cpages/body-of-knowledge | Governance roles (owner, steward, custodian), governance bodies, metadata management, data quality dimensions (the primary source for DQ Dimension) and the issue management cycle. Licensed text, not reproduced. |
| EDM Council DCAM | https://edmcouncil.org/frameworks/dcam/ | Data ownership and accountability, Critical Data Elements, authoritative sources and data quality management. |
| EDM Council CDMC | https://edmcouncil.org/frameworks/cdmc/ | Cloud data controls: cataloging, classification, ownership, authoritative sources, lineage and retention for sensitive data. |
| ISO/IEC 11179-3:2023 Metadata registries, Part 3 | https://www.iso.org/standard/78915.html | Registry items with a stable identity and a registration per version, which shaped Taxonomy Element vs Taxonomy Element Registration. Also designation and definition, classification and mapping. **The brief's URL (78914) is wrong; edition 4 (2023) is 78915.** |
| ISO 8000-1:2022 Data quality, Part 1 | https://www.iso.org/standard/81745.html | Principles of data quality. URL confirmed. |
| ISO/IEC 25012:2008 Data quality model | https://www.iso.org/standard/35736.html | Characteristics mapped from the DAMA dimensions (Currentness for Timeliness; no direct equivalent for Uniqueness or Integrity). URL unverified (confirm). |
| BCBS 239 | https://www.bis.org/publ/bcbs239.htm | Accuracy, completeness and lineage of data behind critical reports. Applied as practice. |
| W3C DCAT 3 | https://www.w3.org/TR/vocab-dcat-3/ | Catalog, dataset, distribution and data service structure, used for Data Asset. |
| W3C SKOS Reference | https://www.w3.org/TR/skos-reference/ | Term relationship types. |
| OpenLineage | https://openlineage.io | Lineage events with column-level facets, and data quality metrics. |
| Open Data Contract Standard (Bitol) | https://bitol-io.github.io/open-data-contract-standard/ | v3.1.0 documentation sections: fundamentals, schema, data quality, SLA, support and roles. Used for Data Contract. |
| ILPA Reporting Template (v2.0, January 2025) | https://ilpa.org/industry-guidance/templates-standards-model-documents/reporting-template | Fee, expense and carried interest reporting to private fund investors. Used as a Contract Standard for private markets. |
| NIST AI RMF 1.0 (AI 100-1) and Generative AI Profile (AI 600-1) | https://www.nist.gov/itl/ai-risk-management-framework | Govern, Map, Measure and Manage functions; the profile list. |
| ISO/IEC 42001:2023 | https://www.iso.org/standard/81230.html | AI management system. Confirmed: 81230, edition 1, December 2023. |
| Federal Reserve SR 11-7 | https://www.federalreserve.gov/supervisionreg/srletters/sr1107.htm | Model risk boundary with 37 (CD-159). |
| Microsoft Purview Unified Catalog | https://learn.microsoft.com/en-us/purview/unified-catalog-critical-data-elements | Governance domains, data products, CDEs and endorsement. Used as a cross-check only. |
| ISO/IEC 27001:2022 | https://www.iso.org/standard/27001 | Information classification and labeling. |
| SEC Regulation S-P (17 CFR Part 248, Subpart A) | https://www.ecfr.gov/current/title-17/chapter-II/part-248/subpart-A | Nonpublic personal information of clients; safeguards and service-provider oversight. Primary reference of the personal data category fields since W1b (CW-921). |
| CCPA as amended by CPRA | https://oag.ca.gov/privacy/ccpa | Sensitive personal information (separate indicator); pseudonymization. |
| FINRA Rule 2165 (and Rule 4512) | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2165 | Specified adults, financial exploitation and temporary holds: the client categories of the special category tier (review fix pass, CW-921). |
| SEC Rule 613 (CAT), Rules 17a-3, 17a-4, 15c3-3, Regulation Best Interest, Form CRS | https://www.ecfr.gov/current/title-17/chapter-II/part-242/section-242.613 | US CDE Regulatory Driver values of the self-clearing broker-dealer (W1b, CW-921). |
| SEC Rules 17Ad-7, 31a-2, 204-2 and 17a-4 | https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.17Ad-7 | Retention by registrant type (transfer agent, fund, adviser, broker-dealer), behind the 08 retention schedule. |
| Program artifacts | (internal) | The first instances of the 21 objects: the decision log, baseline `distribution-v0.4`, `data_products/framework.py` and `CONTRACT.md`, `semantic_model/register.py` (MODELS, CERTIFIED, AGGREGATION) and the capability map (C-14.04 to C-14.07). |

## 2. Design decisions and boundary calls

**Structure.** The draft keeps the brief's 8 families and 26 objects and adds two objects after review:
- **Taxonomy Element:** stable identity.
- **Data Product Input:** product x taxonomy element.

28 objects is within 26 ±3. No object is named "Record Metadata".

**Stable anchoring (program lead decision 3; CD-162).**
- Taxonomy Element holds the identity: Data Domain, family, object and attribute by name, with the key `NN | Family | Object | Attribute`.
- Taxonomy Element Registration is its per-release version. It carries the positional code as "Published Element Code", which is a release-specific label and never a key. It also carries the published facts: name, definition, kind, grain, parent object, data type, code list or format, the registered code list (CLR-), the CDE flag, the ownership flag, the mastering domain and the change type.
- These records reference the Taxonomy Element and record the release they were registered in: Data Ownership Assignment, Business Term Relationship, Critical Data Element, Data Classification Assignment, Data Quality Rule, Data Element Mapping, System of Record Designation, Object Governance Profile, Record Governance Metadata and Data Product Input.
- A rename or move creates a new element linked by Successor Taxonomy Element.

**System of record (program lead decision 1; CD-161).**
- System of Record Designation is the element-level master. It names a system or a cataloged asset, such as a licensed dataset's Data Asset.
- 14 Dataset Consumption keeps its dataset-level Authoritative Source Indicator, and `proposals_21.py` proposes reconciling it to the designation.
- No 21 attribute repeats 14 Dataset Consumption facts. The AI approval's Boolean license check was replaced by a reference to the 14 Permitted Use Grant.

**Metric Definition (program lead decision 2).**
- Added: unit of measure, currency basis, aggregation rule (aligned to `register.AGGREGATION` and 06 Aggregation Behavior), direction, dimensions, owning data domain, disclosure frameworks (ISO 30414, ESRS S1), owning semantic model, the semantic model metric name and the source data product.
- 20 Human Capital Metric Value reads its unit from here.
- Metric Business Definition and Metric Formula are used only where no 06, 10 or 11 measure is registered, so no definition is restated.
- Certification is 21's; the 06 Certified Indicator becomes a derived copy (CD-163).

**Data products (program lead decision 4).** Every field in `framework.PRODUCTS`, `WAVE`, `RATIONALE` and `DELIVERY` and every section of `data_products/CONTRACT.md` now has a home:
- Data Product holds the framework fields: definition, tier, type, owning domain, owner role, primary and supporting functions, wave, priority, value rationale and dependency note.
- It also holds the specification fields: upstream products, grain, dimensions, refresh, timeliness, history, classification, PII and delivery modes, plus measure, question and DQ rule counts and a spec reference.
- Inputs are rows of Data Product Input.

**Ownership is held once.**
- Data Ownership Assignment is the only master of data ownership. Its typed scopes are taxonomy element, business capability (text), code list, business term, data product, data asset, DQ rule and metric.
- Per-object owner and steward attributes were removed: Term Steward, DQ Rule Owner, Data Asset Owner, Metric Owner, Data Product Owner, Semantic Model Owner, and the owner, steward and system of record on Object Governance Profile.
- Kept because they are record-specific: CDE Owner, DQ Issue Owner and AI Use Case Business Owner.
- On Record Governance Metadata, "Record Data Owner" and "Record Data Steward" are used only where a record differs from the object-level assignment. They were renamed so that they resolve to 20 and are no longer forced to "Mastered here" by `ownership.py` rule 0.

**Classification precedence (CD-165).**
- Record overrides element or asset assignment, which overrides the object default.
- Licensed datasets are classified in 14 (CD-164).
- Data Classification Assignment has a typed value per scheme, plus a generic value for MNPI, residency and export control.
- Special category data (the CD-344 tier for every data subject, clients included; named "GDPR Special Category Data Indicator" until W1b) and CPRA sensitive personal information are separate indicators.
- 04's "Personal Data Classification" and 13's indicator now map to a new Personal Data Sensitivity list instead of to Personal Data Category.

**Record Governance Metadata (23 attributes)** is the harmonized union of the excluded attributes. Not carried:
- Source Servicing Provider (15)
- External Source Release (09)
- Redistribution Permitted Indicator (11)

**CD-156.** The 06 DQ Rule attribute names are kept, and DQ Result % sits on Data Quality Result. DQ Result now has its own key and a tested scope (asset or load). Issues reference the raising result.

**CD-157.** Code lists are reached through Business Term "Governing Code List", Taxonomy Element Registration "Element Code List" and Governed Scope Type "Code List".

**CD-160 lineage.**
- Every feed in lineage is a Data Asset of type Feed.
- Targets are a Data Asset, a 12 Client Data Feed or a 12 Report Definition. Client deliverables are endpoints, not assets.
- Provider Delivery covers fund administrator files (private markets), CIT administrator files and sponsor platform files of the intermediary channel.

**Shared lists.** These are now referenced as `Shared: <name>` with values loaded from `shared_code_lists.py`, the 18 to 20 pattern: Data Quality Status, Information Classification, Personal Data Category, Record Status, Approval Status, Severity, Case Status and Frequency. Business Domain stays a local copy: the shared values plus the proposed 15 to 21, including the EXT values.

**Business Line** now uses the eight CW-004 codes of the shared list (DB, DA, HA, PF, WR, IA, IC, TR) since W1b, and nothing else.

### Deviations from the brief

1. The ISO/IEC 11179-3 URL was corrected (78915).
2. There are 28 objects (two added: Taxonomy Element and Data Product Input).
3. **Size overrun:** 295 attributes against the 170 to 220 target. The overrun comes from the four High decisions:
   - release anchors on 10 objects;
   - registration facts;
   - typed ownership scopes;
   - metric interpretability fields;
   - the data product catalog fields.

   No trimming was done that would break those decisions. The CDE share stays inside the target at 31%.
4. Object Governance Profile no longer holds owner, steward or system of record (brief §4 lists them); they are resolved from Data Ownership Assignment and System of Record Designation, so each fact has one master.
5. The semantic model is a code list; its model-level facts stay in `register.py`.
6. The shared lists SLA Unit, RAG Status and Data Basis are not used.
7. Four local list names are qualified to avoid collisions (Element Mapping Type, Taxonomy Release Status, Governance Certification Status, Data Product Business Function).

### Review response

All 4 High findings and the A, D and E Mediums were applied, as were all other Mediums except those listed below. Lows were applied unless listed. Findings not applied, or applied partly:

| Finding | Response |
|---|---|
| B (Medium): consider dropping Data Product Classification | Kept, because the data product framework records a classification per product (program lead decision 4). The precedence rule defines it as the classification of the published output. |
| D (Medium): make the semantic model a Business Object | Took the reviewer's alternative: owning semantic model, metric name and source product are on Metric Definition, and the binding no longer repeats the model owner. A Semantic Model object with an SM- prefix is left as SME question 13. |
| D (Medium): surrogate keys for all Business Objects without an identifier | Partly. Keys were added to Data Ownership Assignment, Critical Data Element, Data Quality Result, Lineage Link and System of Record Designation. Business Term Relationship, Data Classification Assignment, Data Element Mapping, Object Governance Profile, Data Product Input and AI Data Usage Approval keep composite keys (all of whose parts are now typed references). |
| B (Medium): published CDE flag derived from the CDE object | Applied in the definition. It cannot be flagged "Derived copy" because the source is in the same domain. |
| A (Low): optional 06 Reconciliation (RCN-) reference on Data Quality Result | Not added. The DQ Rule Type "Cross-System Comparison" now says that comparisons of feeds stay 06 reconciliations, which removes the overlap without a reference. |
| C (Low): Data Contract ID uses a DP- child key | Kept, as the reviewer allows; recorded in PREFIX_NOTES. |
| E (Low): element-level lineage as references | Kept as text for v0.1 and noted in `proposals_21.py`. |
| I (Low): subtitle "Business domain 21" | Kept, because the drafting instructions prescribe it and the builder converts it. The Structure and Tabs text was updated. |
| J (Low): size | Logged as a deviation instead of trimming (see above). |

## 3. What could not be verified

- **iso.org URLs.** The ISO/IEC 25012 URL (35736) and the ISO/IEC 27001 landing URL could not be opened, because iso.org blocks automated fetches.
- **Licensed frameworks.** DAMA-DMBOK, DCAM and CDMC are licensed or member-only.
- **ODCS.** It is cited as "v3"; the site currently shows v3.1.0.
- **AI risk tiers.** The internal AI risk tiers of the firm's own use cases need legal and risk review; state AI laws (for example Colorado SB 24-205) were not assessed (confirm).
- **NIST AI 600-1** edition in force.
- **Purview** structures are partly in preview.
- **Illustrative examples.** All examples are illustrative, except the taxonomy element examples, which name real elements of `distribution-v0.4`: 06 Transactions / Intermediary As Delivered / Representative Number (TX-TRN-036), 06 Flow & AUM Measures / Measure Definition / Business Definition (TX-MEA-004) and 15 Account Master / Account / Account Type (AC-ACC-002).

## 4. Open questions for client SMEs

1. Which catalog and governance tool is in use or planned (Collibra, Alation, Purview, Atlan), and which of these objects live in it?
2. Are data owners assigned by business capability, by Data Domain, or both?
3. Are CDEs designated only at attribute level, or also per data product and regulatory report?
4. Should the code list registry stay in 09 or move to 21 (CD-157)?
5. Who owns the DQ rule framework, and do operational checks in 06 become instances of it (CD-156)?
6. Is record-level governance metadata physically carried on records, or described only at object level?
7. Who owns the AI use case register (CDO, CRO, CTO), and how does it relate to model risk management (37)?
8. Is there an application inventory or CMDB the "System" list can reference before 41 exists?
9. Are BI reports and dashboards cataloged and certified today, and in which tools?
10. Are data contracts in use, and on which standard (ODCS, ILPA templates, internal)?
11. Should Information Classification be stewarded by 21 or by 41?
12. Which NIST AI RMF profile does the firm apply to client-facing AI (digital advice, client service), and does any state AI law apply to it?
13. Should the semantic models become records with their own prefix (SM-)?
14. Can the taxonomy build emit the stable name-path key next to the positional attribute ID (CD-162)?

## 5. Recommended next steps

1. Generate Taxonomy Element keys and registrations from the `distribution-v0.4` baseline. Load the decision log, the 96 data products with their inputs and upstream products, the certified metrics and the semantic model register.
2. Hold a boundary workshop with 14 (CD-161, CD-164), 06 (CD-156, CD-163), 09 (CD-157) and 12 (CD-160), and with model risk (CD-159).
3. Apply the Business Domain extension and the stewardship changes in `proposals_21.py`.
4. Ask every domain to attach Record Governance Metadata by reference. Mark CD-006 superseded.
5. Map the objects to the selected catalog tool.
6. Have the Chief Privacy Officer, Information Security and Legal review the classification precedence, the personal data sensitivity list and the AI risk classification.

## 6. Wealth model carry-over (W1b, CW-921)

21 is kept (plan section 5.1). The pass made only the changes CW-022 allows: the US-only pass, the perspective text, the 02 re-pointing and the Business Line re-cut to CW-004. No object is removed. Four attributes are removed, so the attribute IDs of the AI & Model Data Governance family renumber from AI Risk Classification onward; one attribute is renamed in place as the brief directs (GDPR Special Category Data Indicator to Special Category Data Indicator), so the CDEs & Classification family keeps its IDs. The decision draft and the jurisdiction entries are in `_tools/consolidation/proposals_w1b_21.py`.

**Removed (EU/UK only; 34 jurisdiction entries: Other EU/UK 26, GDPR / UK GDPR 2, FinDatEx 2, PRIIPs 1, MiFIR 1, AIFMD 1, CRS 1).**
- AI Risk Classification: EU AI Act Risk Category, EU AI Act Operator Roles, Article 50 Transparency Obligations, Fundamental Rights Impact Assessment Required Indicator; local lists AI Risk Category, Article 50 Obligation and EU AI Act Operator Role (whole lists).
- Data Classification Assignment: "GDPR Special Category Data Indicator" as named; the attribute stays as **Special Category Data Indicator** (CD-344 tier, CPRA secondary).
- Code values: CDE Regulatory Driver UCITS / PRIIPs KID, EMIR / MiFIR Transaction Reporting, AIFMD Annex IV, and the CRS half of FATCA / CRS Reporting (now FATCA Reporting); Data Product Business Function EU / UK Cross-Border Distribution (FN-18); Contract Standard FinDatEx TPT; Metric Disclosure Framework ESRS S1.
- Sources: EU AI Act (Regulation (EU) 2024/1689); EU HLEG Ethics Guidelines for Trustworthy AI; EU GDPR and UK GDPR; FinDatEx TPT.

**Re-sourced.**
- AI risk classification to the NIST AI RMF (AI 100-1, Generative AI Profile AI 600-1): AI Use Case Purpose (NIST Map function), Human Oversight Mode (attribute and list), Uses General-Purpose AI Model Indicator (NIST AI 600-1), Permitted AI Data Uses (ISO/IEC 42001 and NIST), the AI Technique value Rules-Based Automation and the Permitted AI Data Use list alignment. Internal AI Risk Tier and NIST AI RMF Profile stay as the classification.
- Personal data fields to SEC Regulation S-P (new source row) and the CCPA / CPRA: Assigned Personal Data Categories, Default Personal Data Categories, Personal Data Category, Data Product Contains Personal Data, Personal Data Categories Used (S-P primary); Personal Data Sensitivity (CPRA); list Personal Data Sensitivity (Pseudonymized and Special Category values).
- CDE Regulatory Driver gains the US drivers of the self-clearing broker-dealer and adviser: FATCA Reporting, Consolidated Audit Trail (SEC Rule 613), Broker-Dealer Books and Records (SEC Rules 17a-3 and 17a-4), Customer Protection Reserve (SEC Rule 15c3-3), Regulation Best Interest (new source row). Form N-PORT was already a value.
- Consumer External Party: FinDatEx TPT secondary removed; ESRS S1 secondary removed from Metric Disclosure Frameworks.

**Perspective rewritten.** META subtitle; overview Purpose (every business line of the US direct wealth manager, CW-004; sources), Scope (02 Client & Household: privacy profiles, consent and privacy rights requests), Notes (Regulation S-P and state privacy law), Suggested next steps 2 (current release wealth-w1-v0.1) and 7 (Chief Privacy Officer; internal AI risk tiers); the Provider Delivery and Providing Party examples (CIT administrator and intermediary sponsor platform files instead of SMA sponsor files); the Consumer External Party definition and its relationship note; SUMMARY in `enrich_21.py`; this file's status line, sources, design notes, unverified list, SME questions 10 and 12 and next step 6.

**Business Line (CW-004).** The local list Business Line (a member of the shared list, steward 09) now holds the codes DB, DA, HA, PF, WR, IA, IC, TR with their labels as descriptions; Mutual Fund, ETF, Collective Investment Trust, Separately Managed Account, Institutional Mandate and Proprietary / Seed leave (not EU/UK; recorded in CW-921, not in the jurisdiction register); Private Markets and Insurance-Dedicated Fund were also removed in the review fix pass (program-lead ruling: the local copy carries the eight CW-004 codes only). The Designation Business Lines example reads "DB; HA". The value map of the shared list for member 21 changes accordingly (SHARED_RECUTS in the proposals file).

**Re-pointed.** "02 Client & Customer" reads "02 Client & Household" (overview Scope, the Release Scope Domains example, SUMMARY); "01 Investment Product" in that example reads "01 Investment Product & Service Offering". Party references resolve unchanged (CW-021).

**Review fix pass (2026-10-14).** Special Category Data Indicator now defines the CD-344 tier for every data subject: health, disability and medical leave; cognitive impairment and diminished capacity; FINRA Rule 2165 specified-adult status, suspected exploitation and hold reasons; financial hardship; and the employee categories (diversity, background screening, criminal history), with the restricted-view rule (released only through the restricted views or products named for the tier; aggregates follow the minimum cell size) and FINRA Rule 2165 as secondary reference (new source row). The metric and data product dimension examples use wealth 02 names (Party, Household, Client, Account, Business Line) instead of Distributor Firm, Advisor, Territory and Distributor Hierarchy. Regulation Best Interest is re-described (Rule 15l-1) and Form CRS (Rule 17a-14, Rule 204-5) is a separate CDE driver value.

**Added.** Nothing (the brief names no addition for 21) beyond the US CDE driver values and three source rows that the re-sourcing needs.

**Left for later stages (NOTES in the proposals file).** References to 08 (records retention schedule, Retention Rule, OBL-), 06, 10, 11 and 12 and the distribution examples left in the data product registry (the FN-01 to FN-19 business functions, Distribution Performance) wait for W2, W4 and WP0; ILPA Reporting Template and the private markets examples wait for W4.

**Open questions (W1b).**
1. Is the CPRA indicator enough for the US model, or should 21 keep both the CPRA flag and the CD-344 special category flag (draft keeps both)?
2. Which state AI laws apply to client-facing AI in the advice lines (confirm), and should a US AI law driver be added to the internal AI risk tier?
3. Should the Data Product Business Function list take the wealth functions FN-60 onward at WP0, when the data product framework retires the wholesale functions?

**Unverified.** Colorado SB 24-205 named as an example of a state AI law (confirm scope and effective date); eCFR paths of 17 CFR Part 248 Subpart A and 17 CFR 242.613 follow the standard pattern (confirm).
