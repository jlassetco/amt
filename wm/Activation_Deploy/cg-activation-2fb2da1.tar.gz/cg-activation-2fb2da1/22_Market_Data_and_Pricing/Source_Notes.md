# Source Notes: 22 Market Data & Pricing

**Workbook:** `Market_Data_and_Pricing_Data_Taxonomy.xlsx` (built from `_tools/content/content_22_market_data_and_pricing.py`)
**Status:** Draft v0.1 after independent review (`00_Program/Expansion/Reviews/22_review.md`), 2026-10-06; wealth model carry-over (W1b, CW-922), 2026-10-14: Wealth manager (direct) | Scope: US; 269 attributes, 85 CDEs (31.6%), 27 sources (section 7). The counts below are those of the wholesale review. 8 families, 31 objects (28 business objects, 3 attribute groups), 269 attributes, 85 proposed CDEs (31.6%), 38 code lists (32 local, 6 local copies of enterprise shared lists), 52 relationships, 31 sources, 54 references, 6 derived copies, 0 overrides, 0 unresolved, 9 attributes flagged PII. Builder: `[content_22_market_data_and_pricing] OK ... 269 attributes, 85 CDEs, 54 references, 6 derived, 0 unresolved, 38 code lists`; `check_enrichment.py 22`: OK.

**Why this domain exists.** Every holding is valued every day from a price, a rate or a fair value decision that the pricing and valuation team in investment operations sourced, checked and approved. That team loads vendor prices, applies the pricing policy and source hierarchy, works tolerance breaks, challenges vendors, sets manual and fair value prices, and takes hard-to-value and private assets to the valuation committee, which acts as valuation designee under SEC Rule 2a-5 for the registered funds (the CIT trustee values the CITs under 12 CFR 9.18). In the wealth model the same approved prices also value client holdings in brokerage and advisory accounts (49). Market data are observations (many per instrument per day, each with a source, timestamp and approval state), and the approved value carries regulatory weight (NAV, fair value), so it has to come from a function independent of portfolio management. No existing domain held them: 09 has FX rate types but no rates, 17 has instrument terms but no prices, 14 licenses the data and 01 defines benchmarks.

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| SEC Rule 2a-5 (good faith determinations of fair value) | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.2a-5 | Valuation designee; "readily available market quotation" means Level 1 unadjusted quoted prices only, so evaluated vendor prices are fair values too (hence back-tests on any Approved Price); methodologies, testing, pricing service oversight and price challenges, fair value triggers. Compliance date 8 September 2022 (confirmed through the SEC small entity compliance guide). |
| Rule 2a-5 adopting release IC-34128 | https://www.sec.gov/files/rules/final/2020/ic-34128.pdf | Round-lot vs odd-lot evaluated prices (Evaluation Lot Size Basis), stale price checks, back-testing practice, oversight of pricing services. |
| SEC Rule 31a-4 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.31a-4 | Records supporting fair value determinations: approved price versions and approval timestamp, override justification, quote evidence, minutes. |
| SEC Rule 2a-7 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.2a-7 | Market-based valuation and amortized cost (Approved Price Basis value). The shadow NAV itself is 27. |
| SEC Rule 6c-11 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.6c-11 | Market price (official closing price, or the NBBO midpoint at NAV time if it more accurately reflects market value), premium / discount, median bid-ask spread (NBBO spread at the end of each 10-second interval over the last 30 calendar days, divided by the midpoint; review verified against the rule text). ETF Market Statistic. |
| SEC Rule 22c-1 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.22c-1 | Forward pricing at the time the board sets; swing pricing (Own Fund Swung Price). |
| IOSCO Principles for the Valuation of CIS (FR05/13, May 2013) | https://www.iosco.org/library/pubdocs/pdf/IOSCOPD413.pdf | Written valuation policy, independence, pricing sources, overrides with documented approval, periodic review. |
| 12 CFR 9.18 | https://www.ecfr.gov/current/title-12/chapter-I/part-9/section-9.18 | CIT valuation by the trustee bank. |
| FASB ASC 820 | https://asc.fasb.org (confirm topic page) | Levels 1-3, valuation approaches, Level 3 input disclosure, NAV practical expedient (US GAAP only). |
| ASC 830 | https://asc.fasb.org (confirm) | Spot vs average rates for income and expense translation (FX Rate Basis, Period Rate). IAS 21 removed at W1b (CW-922). |
| IOSCO Principles for Financial Benchmarks (FR07/13) | https://www.iosco.org/library/pubdocs/pdf/IOSCOPD415.pdf (confirm) | Market-neutral reference for the benchmark administrator (Rate Administrator), replacing EU and UK BMR at W1b (CW-922). |
| IPEV Valuation Guidelines (2025 edition) | https://www.privateequityvaluation.com/Valuation-Guidelines | Techniques, calibration, roll-forward of fund NAVs. Official domain confirmed by search; 30 cites a mistyped domain and the 2022 edition. |
| ISO 20022 reda (reda.001 PriceReport) | https://www.iso20022.org/iso-20022-message-definitions | Price type, value, currency, quotation basis, valuation date and time. |
| FIX market data (MsgType W, MDEntryType) | https://www.fixtrading.org/standards/ | Bid, offer, trade, closing and settlement price entry types. |
| LSEG WM/Reuters FX Benchmarks | https://www.lseg.com/en/ftse-russell/benchmarks/wmr-fx-benchmarks (confirm) | 4 p.m. London fix, spot and forward rates, forward points. 09 cites a different LSEG URL. |
| ECB EUR STR | https://www.ecb.europa.eu/stats/financial_markets_and_interest_rates/euro_short-term_rate/html/eurostr_overview.en.html | Published at 08:00 CET on TARGET2 days (confirmed). |
| New York Fed SOFR | https://www.newyorkfed.org/markets/reference-rates/sofr | SOFR, SOFR Averages and SOFR Index (Fixing Value Type). |
| Bank of England SONIA | https://www.bankofengland.co.uk/markets/sonia-benchmark | Administered and published every London business day (confirmed). |
| EMMI EURIBOR | https://www.emmi-benchmarks.eu/ | Administrator; tenors 1W, 1M, 3M, 6M, 12M (confirmed). |
| MSCI, S&P DJI, FTSE Russell methodologies | https://www.msci.com/indexes/index-resources/index-methodology ; https://www.spglobal.com/spdji/en/governance/methodologies/ (confirm) ; https://www.lseg.com/en/ftse-russell/ (confirm) | Level variants, weights, free float, announced changes and effective dates. |
| FINRA TRACE | https://www.finra.org/filing-reporting/trace | Trade prints as price evidence. |
| SEC Form N-PORT | https://www.sec.gov/files/formn-port.pdf | Option delta and fair value level per holding. |
| ICE evaluated pricing; Bloomberg BVAL | https://www.ice.com/fixed-income-data-services/data-and-analytics/pricing/evaluated-pricing | Structure only. |
| FINOS CDM / FpML indices | https://cdm.finos.org | Floating rate and inflation index codes, curve concepts. |
| ISO 4217 / 8601 / 10383 / 3166 | https://www.iso.org | Formats. |

## 2. Design decisions and boundary calls

- **One current approved value, versioned (decision 9).** Approved Price (PRICE-) has grain instrument x pricing point x price date x version, with one current version per key. A change after approval (override, challenge, 27 restatement) creates a new version with Version Effective Timestamp and Supersedes Approved Price; the version a NAV used is never overwritten. Price Approval Timestamp evidences approval before the NAV strike.
- **Origin vs basis (decision 10).** The draft list Price Source Type was split: **Price Origin** (where an observation came from) on observations and hierarchy ranks, and **Approved Price Basis** (selected observation, override, fair value determination, fair value factor, own fund NAV, carried forward, amortized cost, contract value) on the Approved Price. 18 Price Source copies the basis.
- **Fair value level on every price (decision 2).** Approved Price Fair Value Level (Level 1 / 2 / 3, or NAV practical expedient) is on every version; Fair Value Determinations are for Level 3 and adjusted quotations. Valuation Back-Test always names an Approved Price and optionally a determination, so evaluated vendor prices are back-tested too.
- **Own-fund row rule (decision 1, CD-167, plan §4 item 9).** On Own Fund Share Class rows, Approved Price Value copies 27 Share Class NAV "NAV per Share" (unswung) from the record whose parent Fund NAV Calculation is the latest version with NAV Status "Final" (Original or Re-Strike) for the latest valuation point at or before the pricing point; Approved Price Currency copies 27 "NAV Currency". The swung price is the separate Own Fund Swung Price (copy of "Swung NAV per Share") with Own Fund Swing Decision referencing 27 Swing Pricing Decision (SWG-). Own Fund NAV Record references the 27 NAV- record (format NAV-<date><share class, 6 digits><version, 2 digits>, as in 27). Price Date stays mastered as 22's business-date key; an earlier own-fund valuation date shows in Underlying Market Date.
- **One path per fact (decisions 7 and 8).** A factor-adjusted price has basis Fair Value Factor and references the factor (Applied Fair Value Factor); "Systematic Fair Value Factor" was removed from Fair Value Method and Factor Applied Indicator was dropped. An override is referenced by the approved price it sets (Applied Price Override). Vendor identity is the 14 Dataset on observations and hierarchy ranks; Ranked Data Provider is a Derived copy (14) of the dataset's provider; broker quotes keep the 02 party.
- **FX (decision 3, CD-168).** FX Rate Observation adds FX Rate Basis (spot, forward outright, period average, budget; aligned to 09 rate types such as "Monthly Average Rate" and "Budget Rate"), Rate Period Start / End, Forward Outright Rate and Period Rate. Rates are stored for the pair as quoted by the rate type; consumers take the reciprocal for the inverse and compute crosses from two observations of the same rate type, basis and timestamp through the 09 pivot currency. 22 stores no inverses or crosses. The FX family definition states the rule.
- **Approved analytics (decision 5).** Pricing Source Hierarchy Rule ranks datasets per analytic measure (Ranked Analytic Measure); each Pricing Analytics Observation carries its Analytics Source Rank and an Approved Analytics Value Indicator, exactly one Y per instrument, date and measure. 18 Delta Used copies the approved Option Delta row.
- **Fund interests (decision 6, CD-170).** Valued Portfolio is mandatory on determinations for private fund interests (stated in the grain). Valuation Basis Date is a Derived copy (18 GP Statement Date) on fund-interest rows, and Underlying NAV Used a Derived copy of 18 GP Reported NAV.
- **ETF market statistics (decision 4).** Own ETF Market Observation was replaced by **ETF Market Statistic** (own ETF instrument x date), computed and mastered here: closing price, NBBO midpoint at NAV time, Rule 6c-11 market price, premium / discount against the referenced 27 Share Class NAV, and the 30-day median bid-ask spread computed from intraday NBBO quotes (source dataset recorded). 35 discloses; 31 may read. NBBO attributes are blank for EU and UK listings.
- **18, 19 and 06 copies to re-note** (`proposals_22.DERIVED_COPY_RENOTES`): Price Used (Approved Price Value), Price Date (business date; amend the 18 definition), Price Source (Approved Price Basis), Holding FX Rate and Cash FX Rate (spot rate, its inverse or a cross; recommend an FXR- reference in 18), Trade FX Rate (22 on market-rate rows, 25 Execution.Executed FX Rate on executed FX trade rows), Delta Used (approved Option Delta row), Adjusted NAV (approved Fair Value Amount for the same portfolio; redefine the 18 attribute), 19 Applied Exchange Rate (spot or period rate), 06 FX Rate Applied (proposed only).
- **Unchanged boundaries.** 09 FX Rate Type attributes, 17 instrument terms and credit ratings, 01 benchmark definitions and 14 license data are referenced, not repeated. Index data keys on 01 BMK- (CD-169 option A). Approval of a fair value lives on the determination (Approving Meeting references the meeting).

**Key formats (decision 11; also in `proposals_22.KEY_FORMATS`):** `PRICE-<price date YYYYMMDD>-<instrument number, 8 digits>-<pricing point number, 2 digits>-<version, 2 digits>` (PRICE-20261005-00104477-01-01); `PCHL-<year>-<sequence, 5 digits>` (PCHL-2026-00318); `FVD-<year>-<sequence, 6 digits>` (FVD-2026-001187); `FXR-<rate date YYYYMMDD>-<rate type short code>-<base and quote currency>-<tenor or basis code>` (FXR-20261005-WMR16-EURUSD-SP); `CURVE-<currency or underlying>-<curve short name>` (CURVE-USD-UST).

**Deviations from the brief**

1. **31 objects instead of 29** (within ±3): Valuation Committee Member (effective-dated membership with the independence test) and Private Asset Valuation Detail (the third attribute group). Own ETF Market Observation became ETF Market Statistic (program lead decision 4).
2. **Pricing Analytics Observation is long, not wide** (one row per measure), with an approved-row rule.
3. **269 attributes (target 200-260) and 32 local lists (target 20-28).** The excess comes from the program lead decisions (versioning, swung price, fair value level, FX basis and period rates, ETF statistics, analytics approval) and review additions (hierarchy scope, fixing value type, origin / basis split). Thirteen lower-value attributes were removed to offset part of it.
4. **Lists:** FX Rate Tenor widened to Rate Tenor (FX, fixings, curves, surface expiries; now with SN, 1Y, 4Y, 15Y, 25Y, 40Y and 50Y). Added FX Rate Basis, Fixing Value Type, Price Origin and Approved Price Basis. No Valuation Committee Decision Outcome list (approval is on the determination) and no observability list (Boolean).
5. **Shared lists are local copies** with the exact shared name and values (Record Status, Approval Status, Case Status, Severity, Frequency, Data Provider), listed in `proposals_22.SHARED_MEMBERSHIPS`, per the Stage 2 addendum. Message Standard and Data Basis are not used; their proposed values stay in proposals_22.
6. **Volatility surfaces** are Curve Definitions of type Volatility Surface.
7. **Committee meetings** carry no attendee list, only Quorum Met.

### Review response

All 11 Medium findings were applied as the program lead decided (decisions 1-11 above). The Lows were applied except where noted:

| Finding | Response |
|---|---|
| A Low 18 Price Date | Applied: re-note states the business date and the 18 definition change. |
| A Low Trade FX Rate | Applied: names 25 Execution.Executed FX Rate. |
| A Low 27 ABOR Valuation Method | Applied: Amortized Cost and Contract Value added to Approved Price Basis; proposal that 27 read its method from 22. |
| A Low 30 Portfolio Company Profile | Applied: Valued Portfolio Company dropped (company reached through the 17 issuer); the 30 metric link is a note on Input Value until 30 keys that record. Override removed. |
| A Low 17 hand-backs | Applied: CPR, CDR and PSA in Pricing Analytic Measure; inflation index levels as Reference Rate Fixings (Fixing Value Type). |
| A Low CD-187 names | Applied as a note in proposals_22 (cannot edit proposals_stage2_b). |
| B Low override repeats value | Applied: Applied Price Override; definition says the value equals the applied override or determination. |
| B Low two meeting attributes | Applied: one Approving Meeting reference. |
| B Low Enterprise Value repeats | Partly applied: noted as per company and date; not moved to a company-level row, which would need a 30-keyed object. |
| C Low ETF market price wording | Applied (rule wording). |
| C Low SOFR index levels | Applied: Fixing Value Type; Fixing Value typed Decimal. |
| C Low Rate Tenor gaps | Applied; 12M replaced by 1Y ("also written 12M"). Option expiries keep using Rate Tenor. |
| C Low Strike Unit | Applied: mapping in the definition. |
| C Low Case Status / Approval Status values | Applied: definitions name the values not used. |
| C Low cross-domain example keys | Applied for 22 (key formats published; DSET- five digits; NAV- follows 27). Sibling examples are for consolidation. |
| D Low Pricing Point dating | Applied. |
| D Low hierarchy scope | Applied: market, currency, pricing point and rule code; tolerance rule gains instrument type. |
| D Low Price Observation grain | Applied: grain names price origin and source dataset or quoting broker. |
| D Low index status | Applied: Index Level Status, Change Announcement Status, announcement date in the change grain. |
| D Low FVD sequence | Applied as a rule: each attempt keeps its own FVD- ID; at most one approved per key. |
| D Low constituents not in 17 | Applied: Vendor Constituent Identifier; SME question 6 widened. |
| E Low row rule on currency and date | Partly applied: Currency flagged Derived copy (27). **Not applied to Price Date**: it is 22's business-date key, not a copied value; the earlier NAV date shows in Underlying Market Date. |
| E Low identifier CDEs | Applied for PRICE-, PCHL-, FVD-, FXR-, Approved Price Basis and Determination Pricing Point. **Not applied to Price Observation Key**: a surrogate key that no other domain matches on. |
| F Low Price Type mixes side and kind | **Partly applied**: "Trade Print" removed (it repeats the origin). Evaluated Bid / Mid / Ask, NBBO Midpoint, Settlement Price and NAV per Unit kept as one list, because vendors and reda deliver them as price types; a separate Price Side list would add a list without changing any hierarchy rule. |
| F Low Valuation Committee Type | Applied: Private Markets value removed; scope goes in the committee name. |
| F Low Challenge Outcome "Escalated" | Applied: removed; escalation is Case Status "Escalated". |
| F Low NAV practical expedient | Applied: description says US GAAP only. |
| F Low Measure Unit vs 09 | Applied as a proposal note (check 09 Unit Category before sharing). |
| G Low relationships | Applied: 12 relationships added or corrected (52 in total); REL to Party now hangs on Broker Quote Detail. |
| G Low sources | Applied: UCITS Directive, FCA COLL, 12 CFR 9.18, ASC 830 / IAS 21, FTSE Russell and S&P DJI rows. |
| G Low IPEV edition | Applied for 22 (2025 edition, confirmed by search); 30 alignment proposed. |
| G Low "confirm" URLs | **Not resolved**: ASC 820, S&P DJI, FTSE Russell, FCA COLL 6.3, IAS 21 and LSEG WMR URLs remain "confirm"; none were fetched. |
| H Low UCITS ETF listings | Partly applied: NBBO attributes are blank for EU and UK listings. **No iNAV value added**: the iNAV ticker is 01 and iNAV values are a dissemination matter, not a Rule 6c-11 statistic. |

## 3. References to sibling Stage 2 domains

- **27 Fund Accounting & Valuation** (names checked against the current `content_27`): `Reference (Share Class NAV, 27)` on Approved Price.Own Fund NAV Record and ETF Market Statistic.Premium / Discount NAV; `Reference (Swing Pricing Decision, 27)` on Approved Price.Own Fund Swing Decision. 27's own references to 22 use Approved Price, Fair Value Determination, FX Rate Observation and Reference Rate Fixing; their example keys should follow the published formats.
- **30 Private Markets:** no reference from 22 after the review. 30 Private Investment references FVD-.
- **18 (Stage 1):** Portfolio (PORT-), Portfolio Transaction (PTXN-).
- **25:** Execution.Executed FX Rate is named in the Trade FX Rate row rule (proposals only).
- **23, 24, 26, 28:** they reference Approved Price, Index Change Announcement and Reference Rate Fixing; no reference from 22.

## 4. What could not be verified

- ASC 820, ASC 830, IOSCO FR07/13, S&P DJI, FTSE Russell and LSEG WMR URLs (marked "confirm").
- ISO 20022 reda.001 price type codes were not checked against the message definition report.
- Evaluated pricing quality scores and fair value factor vendor statistics are vendor-specific.
- Whether intraday NBBO data for own ETFs is held by the firm or sourced from a vendor (Intraday Quote Source Dataset).

## 5. Open questions for SMEs

1. Which platform holds approved prices, and is pricing outsourced for any business line?
2. Who is the valuation designee per fund family, and does the firm's trust company or an unaffiliated trustee bank value the CITs?
3. Which pricing points exist, and are institutional separate accounts priced by the firm or by the client's custodian?
4. Which fair value factor vendor is used, and what triggers its application?
5. Are private asset valuations prepared by the pricing team, by private markets valuation staff (30) or by third-party valuation agents?
6. Which indices are in scope for level and constituent data (CD-169), and must every constituent be a 17 instrument?
7. Do credit ratings stay in 17 or move to 22 (17 SME question 3)?
8. Are NAV, AUM translation and GL translation using the same FX rate types (CD-102)?
9. Is the price of an own share class held by an own portfolio always the 27 NAV, or the exchange price for own ETFs; and does any holder's policy value own fund holdings at the swung price?
10. Are curves built in house or taken from vendors, and are volatility surfaces stored?
11. Are intraday prices persisted, or only pricing-point snapshots (and is intraday NBBO data held for own ETFs)?
12. How are OTC derivatives priced (vendor, counterparty marks, in-house model), and how do disputes relate to 26 margin call disputes?
13. Will 17 set up an Own Fund Share Class instrument for every own ETF so that ETF Market Statistic can key on it (17 SME question 5)?
14. Which rules set the fair value level of an approved price where no determination exists (by price origin, by vendor leveling hint, or both)?

The draft's questions on the 30-day spread owner and on post-strike price versions are closed by program lead decisions 4 and 9.

## 6. Suggested validation steps

1. Walk one day's pricing for one US fund (equity, corporate bond, foreign equity with a fair value factor, money market instrument at amortized cost, own fund of funds holding) through Price Observation -> Approved Price -> 18 Holding Valuation and 27 NAV, including a post-strike restatement that creates a version 02.
2. Walk one quarter-end fund-interest valuation through Fair Value Determination (with Valued Portfolio), Valuation Inputs, committee approval and the 18 Adjusted NAV copy.
3. Check Price Origin and Approved Price Basis against the pricing platform's source codes, and Tolerance Check Type against the current tolerance matrix.
4. Recompute one ETF's 30-day median bid-ask spread and premium / discount and compare with the website disclosure.
5. Confirm with 01 the CD-169 widening of Benchmark.
6. Re-run `taxonomy_builder.py content_22_market_data_and_pricing` and `check_enrichment.py 22` after 27 and 30 settle their object names.


## Stage 2 consolidation (2026-10-06)

PRICE-, PCHL-, FVD-, FXR- and CURVE- are registered (IDX- stays Proposed under CD-169 option B). The six local copies of shared lists were replaced by direct citations of the shared lists. The seven data providers and the FIX and reda message standards proposed here were added to the shared lists. The 18 placeholders now name the 22 objects (CD-167, CD-168, CD-170), as do 19 Applied Exchange Rate and the 17 text. CD-206 records ETF market statistics. See `_tools/consolidation/stage2_consolidation_notes.md` and §15 of the conventions document.

## 7. Wealth model carry-over (W1b, CW-922)

22 is kept (plan section 5.1). The pass made only the changes CW-022 allows. No object or attribute is removed or renamed, so no attribute ID changes; the removals are code values and sources. The decision draft and the jurisdiction entries are in `_tools/consolidation/proposals_w1b_22.py`.

**Removed (EU/UK only; 12 jurisdiction entries: AIFMD 3, UCITS 3, Other EU/UK 3 (IFRS 13 value and source, IAS 21), FCA 2, BMR 1).**
- Code list Valuation Regulatory Framework: values AIFMD Article 19, UCITS Directive, FCA COLL; the value "ASC 820 / IFRS 13" now reads "ASC 820" (the funds report under US GAAP).
- Code list Valuation Committee Type: values AIFM Valuation Function, ManCo Valuation Committee.
- Sources: AIFMD Article 19 with Delegated Regulation (EU) 231/2013 Articles 67-74; UCITS Directive 2009/65/EC; FCA COLL 6.3; IFRS 13; IAS 21 (the row now reads ASC 830 only); EU and UK Benchmarks Regulations.

**Re-sourced.**
- Valuation governance to SEC Rule 2a-5 (valuation designee, pricing service oversight, segregation from portfolio management) and Rule 31a-4 (records), with 12 CFR 9.18 for the CITs: Policy Owner Entity, Committee Owner Entity and Valuation Committee Type (secondary 12 CFR 9.18 in place of AIFMD Article 19); Outsourced Pricing Provider, Portfolio Management Function Indicator and External Valuation Agent (primary SEC Rule 2a-5 in place of AIFMD Article 19); the source alignment of Valuation Committee Type.
- Own Fund Swung Price: FCA COLL 6.3 removed; SEC Rule 22c-1 stays (swing pricing is permitted but not used by US mutual funds).
- Fair value hierarchy fields: IFRS 13 removed from Approved Price Fair Value Level (secondary now SEC Form N-PORT), Fair Value Hierarchy Level and Unobservable Input Indicator; list Fair Value Hierarchy Level aligned to ASC 820 only. Period Rate, Rate Period Start, Rate Period End and the FX Rate Basis list: IAS 21 removed (ASC 830 stays; the last three in the review fix pass).
- Rate Administrator: from EU and UK BMR to Internal with the IOSCO Principles for Financial Benchmarks (new source row, confirm URL).

**Perspective rewritten.** META subtitle; overview Purpose (a US direct wealth manager valuing its proprietary funds, CITs, advice model portfolios and institutional separate accounts, and supplying the approved prices that value client holdings in 49; foreign markets, currencies, reference rates and indices stay), Scope (parties in 02 Client & Household), Core model (valuation designee or CIT trustee), Notes (US privacy law); family text of Fair Value & Valuation Governance; Policy Owner Entity, Policy Approval Status, Committee Owner Entity, Portfolio Management Function Indicator and Valuation Committee Name definitions; the NBBO notes on ETF Market Statistic (own ETFs are US-listed); code value descriptions Fund NAV Valuation Point (registered funds and CITs), SMA Month-End Valuation (relabeled Institutional Separate Account Month-End Valuation in the review fix pass; the text reader specs_e1_book_of_record.py line 355 is updated at merge), Sponsor or Client Priced (institutional separate account client or custodian) and Contract Value (stable value contracts of CITs and stable value funds); the relationship note on Pricing Policy ownership; SUMMARY in `enrich_22.py`; this file's status line, "Why this domain exists", source table, unverified list and SME questions 2 and 3.

**Re-pointed.** "02 Client & Customer" reads "02 Client & Household" and "01 Investment Product" reads "01 Investment Product & Service Offering" (overview Scope, SUMMARY); references to Party resolve unchanged (CW-021). The client book of record (49) is named as a reader of approved prices (CW-007); 18 keeps fund and institutional portfolio holdings.

**Kept on purpose (investment universe, CW-022).** SONIA, EUR STR, EURIBOR, UK RPI, HICP and their administrators and sources (Bank of England, ECB, EMMI), WM/Reuters 4 p.m. London fixes, foreign exchanges and listings, fair value factors for foreign closes.

**Added.** Nothing (the brief names no addition for 22); one source row (IOSCO Principles for Financial Benchmarks) and, in the review fix pass, the Valuation Committee Type value Board (no valuation designee). Client Holdings (49) is named as in CW-007.

**Left for later stages (NOTES in the proposals file).** References to 30 Private Markets (overview Scope, Design principle 2, Suggested next step 5, Input Value note, two relationships) and the private-asset content (Private Asset Valuation Detail, Pricing Point Purpose "Private Asset Quarter-End", Price Origin "GP Statement", IPEV) are left for the W4 retirement of 30.

**Open questions (W1b).**
1. Does the firm's trust company act as CIT trustee and valuation authority, or is an unaffiliated trustee bank used (plan section 2: trust services optional)?
2. Should the approved price used for client statements and client holdings (49) be a separate pricing point, or the fund NAV and market close pricing points?

**Unverified.** IOSCO FR07/13 URL (IOSCOPD415) and ASC 830 topic page (confirm).
