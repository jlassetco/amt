# Source Notes: 23 Investment Research

**Workbook:** `Investment_Research_Data_Taxonomy.xlsx` (built from `_tools/content/content_23_investment_research.py`)
**Status:** Draft v0.1 revised after independent review (`00_Program/Expansion/Reviews/23_review.md`), 2026-10-06; wealth model carry-over (W1b, CW-923), 2026-10-14: Wealth manager (direct) | Scope: US; 202 attributes, 63 CDEs (31.2%), 11 sources (section 6). The counts below are those of the wholesale review. 6 families, 23 objects (20 business objects, 3 attribute groups), 200 attributes, 63 proposed CDEs (31.5%), 31 code lists (26 local, 5 that copy enterprise shared lists by name), 43 relationships, 16 sources, 18 attributes flagged PII (employee references, external meeting participants and provider contacts), 1 derived copy (22), 1 ownership override. No Record Metadata object (governance metadata is modeled once in 21).

**Why this domain exists.** Portfolio managers act on views that analysts form: who covers which issuer, what the analyst recommends and at what price target, how a credit is rated internally, what the estimates and models say, and what management said in last week's meeting. The research function produces this record in a research management system under controls no other function applies: MNPI from issuer contact (Advisers Act Section 204A, and FINRA Rule 3110(d) at the affiliated broker-dealer), the Section 28(e) good-faith determination when research is paid with client commissions, and the duty to evidence the basis of investment recommendations. In the wealth model the research serves the firm's proprietary funds, the model portfolios of its digital and human advice and its institutional separate accounts. No existing domain holds it: 11 is distribution's view of competitors and markets, 01 commentary is client-facing, and 03 records meetings with clients, not issuers. Research is an input to investment decisions, owned by research and consumed by 24, 25, 33 and 34, with its own lifecycle (coverage, recommendation, revision) and information barriers.

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| SEC Release 34-54165 (Section 28(e) guidance, 2006) | https://www.sec.gov/rules-regulations/2006/07/commission-guidance-regarding-client-commission-practices-under-section-28e-securities-exchange-act | Eligible research vs brokerage; Research Provider Type and Research Service Type. URL verified by the reviewer. |
| SEC Rule 2a-7 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.2a-7 | Eligible security = board (or delegate) determination of minimal credit risks, with factors; first tier security = issuer with the highest capacity to meet short-term obligations. |
| Advisers Act Section 204A; Rule 204A-1 | https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.204A-1 | Policies to prevent misuse of MNPI: basis for the MNPI flag, escalation reference and expert network controls. |
| CFA Institute Asset Manager Code | https://rpc.cfainstitute.org/codes-and-standards/asset-manager-code | Reasonable basis and documentation for investment decisions; supervisory review. |
| FINRA Rule 3110(d) | https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110 | Broker-dealer review of transactions for insider trading; secondary reference of the wall-crossing and MNPI fields (W1b, CW-923; paragraph (d) confirm). |
| FINRA Rule 2210 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2210 | Retail communications of the affiliated broker-dealer; secondary reference of Investment Recommendation Disclosure Indicator (review fix pass, CW-923; confirm). |
| FINRA Rule 2241 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2241 | Sell-side reference point only: rating definitions and price targets. |
| FIBO BE / SEC | https://spec.edmcouncil.org/fibo/ | Issuer as a role of a legal entity; securities. |
| FactSet RMS; Bipsync | https://www.factset.com ; https://www.bipsync.com | Vendor structure only: notes, ratings and price target history, coverage, meeting notes, MNPI tagging. |
| Visible Alpha; Bloomberg BEst | https://visiblealpha.com ; https://www.bloomberg.com/professional | Estimate metric families, fiscal period conventions, adjusted vs reported basis. |
| ISO 4217, 3166, 8601; ISO/IEC 27001 | https://www.iso.org | Formats; information classification. |

## 2. Design decisions and boundary calls

- **Families and objects follow the brief** (6 families), with 23 objects instead of 22 after the review split of the provider evaluation. Deviations:
  - **List "Coverage Subject Type" renamed "Research Subject Type"**, because one list classifies coverage subjects, universe members, recommendation subjects and publication subjects. Values: Issuer, Instrument, Sector, Country, Rates Market, Theme (publications only).
  - **List "Coverage Role" renamed "Research Coverage Role"** (list and attribute) to avoid the 07 collision.
  - **Recommendation-publication link held once, on the recommendation** ("Announcing Publication"), not also on the publication as the brief suggested.
  - **Issuer Meeting Format split from Meeting Channel** (the brief's "call" is a channel).
  - **Research Provider Evaluation split** into Research Evaluation Round (provider x period x evaluator: overall score, vote allocation share, approval), which 25 Research Payment references, and Evaluation Criterion Score (round x criterion).
  - **Research Provider Type holds the business model only**; the specialty is a separate list, Research Specialty.
  - **Internal Credit Assessment covers any assessed party** (issuer or trading counterparty) so 25 Counterparty Review can read it; grain includes the rating scale.
  - **Meeting MNPI Assessment keeps only the MNPI flag and an escalation reference**; wall crossing is per internal participant; the compliance determination, reviewer, notification time, market sounding flag and cleansing dates are proposed to 38 (proposals_23.py PROPOSED_TO_38). This narrows brief §5, which listed "compliance notified".
  - **No Coverage Status list, no "Research Management System" attribute (CD-147 "if needed"), no house view indicator, no "Money Market Eligible List" universe type, no payment route.**
  - **26 local lists vs the brief's 15-22.** Valuation Method, Meeting Channel, Meeting Topic Category, Research Service Type, Research Specialty and the split rating and credit lists (scale and value) account for the overrun; each keeps one dimension per list.
- **Current recommendation (one rule).** The current research recommendation is the latest row per subject x rating scale x recommending analyst; the research team's view is the current recommendation of the analyst whose coverage role is Primary Analyst; the firm's house view is a 24 Investment Committee Decision. No "current rating" column on coverage.
- **Price at Recommendation** is a Derived copy (22): the Approved Price Value of the recommended instrument at the firm's primary pricing point for the recommendation date; currency and quote basis are those of the 22 Approved Price. Reference Approved Price holds the PRICE- key (22's format).
- **Per-row ownership (plan §4 item 9).** Recommended Issuer and Assessed Party carry a Row Ownership Rule note: on rows with an instrument they are derived from the issuer of the 17 Instrument; otherwise entered. Both remain References to 02.
- **Same fact once.** Issuer type, country of risk and sector are never copied onto coverage. Agency ratings are not repeated; the internal-to-agency notch mapping sits on the Internal Credit Rating code values, not on each assessment. Countries are 09 Geographic Unit references (GEO-) everywhere.
- **Everything is dated:** coverage and universe membership (Effective From / To), recommendations (timestamp), credit assessments (Effective From / To), estimates and forecasts (estimate / forecast date plus period end), signal scores (as-of date), signal versions (Effective From / To), subscriptions, provider profiles (Effective From / To), consumption (timestamp), evaluation rounds (period end).
- **Identifiers.** Only RCOV-, RREC-, RPUB-, IMTG- are used, with key formats published in proposals_23.py KEY_FORMATS (RREC- plus seven digits). Universes, models and signals use plain codes, and model and signal versions are separate attributes. The Scored Evaluation Round reference uses the composite round key (starting with PTY-), so enrich_23.py forces it to "mastered here".
- **Shared lists.** Record Status, Approval Status, Period Type, Sentiment and Information Classification are local copies with the shared names and values (proposals_23.py SHARED_MEMBERSHIPS). Frequency and Data Provider are no longer used.
- **CDEs (31.5%)** cover row keys and the brief's list: coverage keys, analyst and subject; recommendation ID, analyst, issuer, rating, change type, price target and timestamp; internal credit rating, minimal credit risk indicator and effective date; publication ID, author and timestamp; meeting ID, issuer and start time; participant wall-crossing timestamp; MNPI flag; provider type and approval; consumption and evaluation keys, overall score and vote allocation share.
- **PII.** Employee references carry "PII (employee)."; external participants and provider contacts carry "PII.".

### Review response

All 41 findings were applied, together with the program lead decisions, except the points below.

| Finding | Response |
|---|---|
| A [High] evaluation split: "hold criterion weights once per round" | Partly applied. Following the lead decision, the round is provider x period x evaluator, so Criterion Weight sits on Evaluation Criterion Score (round x criterion) and repeats across evaluators of the same period. A separate evaluation policy object (period x criterion weight) would remove the repeat. It is left for SME question 12 rather than adding a 24th object. |
| A [Medium] MNPI determination fields: "keep with a future-owner note, or drop" | Applied as the lead decided: dropped and proposed to 38. Compliance Notified Timestamp and Market Sounding Indicator were dropped too (the lead kept only the flag and escalation reference), which goes further than the reviewer's minimum. |
| A [Medium] house view: "Adopting Committee Decision" reference | Not added; the indicator was removed (lead decision 4). 24 can reference the forecast if it needs the link. |
| A [Medium] 25 example key should include the scale | Cannot edit 25; recorded in proposals_23.py KEY_FORMATS. |
| G [Low] 30 hand-off | Relationship renamed to Due Diligence Workstream [30]; 30's notes cannot be edited from here (proposals_23.py NOTES). |

Attributes dropped to keep within 200 after the additions: Recommendation Approved By, Universe Membership Rule, Member Added By, Research Use Approval Date, Governing Data License Agreement (read through the 14 dataset), Signal Calculation Frequency, Signal Percentile Rank, Forecast Update Frequency, Meeting Logged Timestamp, Follow-Up Action, Agency Equivalent Notch, Provider Data Vendor, House View Indicator, Research Payment Route, and the MNPI control fields above.

## 3. What could not be verified

- Rule 2a-7 paragraph numbering for the eligible security definition, the minimal credit risk factors and the first tier security definition (the concepts are confirmed; paragraph references are not cited).
- The Section 204A citation page (the eCFR URL is Rule 204A-1).
- Vendor field structures (FactSet RMS, Bipsync, Visible Alpha, Bloomberg BEst) are from general knowledge.
- Internal credit rating values, notch mappings and recommendation scale values are illustrative placeholders.

## 4. Open questions for client SMEs

1. Which system holds research (research management platform, OMS notes, shared drives), and is it one system for equity, credit and quant?
2. Is there one firm rating scale or one per team, and how are recommendation changes approved?
3. Does credit research make the Rule 2a-7 minimal credit risk determinations, and are internal credit ratings used in compliance limits (33)?
4. Do house views and economic forecasts belong to research (23) or to the investment committee (24)? (Draft assumes 24 for house views.)
5. Are quantitative signal scores persisted per instrument and date, or computed on demand inside the portfolio construction tools?
6. Are ESG assessments written by research analysts (23) or by the stewardship team (34)?
7. Is there any private-company research outside 30 deal due diligence, and are private credit loans set up as 17 instruments so that internal credit assessments can reference them?
8. Who logs issuer meetings (analysts, PMs, a corporate access desk), and how is MNPI escalated to compliance today?
9. Which funds and accounts pay for research from the adviser's own resources and which use client commissions under Section 28(e), including commission sharing arrangements (determines the 25 link)?
10. Are expert network calls approved and logged per call, and by whom (chaperone requirement)?
11. Are any publications released externally (to the firm's brokerage and advice clients, institutional separate account clients or the public), and if so does the affiliated broker-dealer distribute them (FINRA Rules 2210 and 2241 would then apply; tailoring lever)?
12. Is the broker vote captured per criterion with firm-wide weights per period, or as one overall score per provider and evaluator?
13. Are scenario (bull / base / bear) values and consensus estimates kept as research records, or only inside the model files?

## 5. Recommended next steps

1. Validate rating scales, change types, credit scales and CDEs with the Director of Research, Head of Credit Research and Investment Compliance.
2. Agree the 2a-7 record (determination, first tier, approval by the board's delegate, retention) with the money market fund team.
3. At consolidation, have 24 adopt the RREC- format and 25 reference Research Evaluation Round and add the scale to its credit view key; register 23 on the five shared lists; add 02 Party Role Type values for research providers, expert networks and corporate access providers.
4. Hand PROPOSED_TO_38 to the Stage 4 brief for 38.
5. Map attributes to the research management platform and the OMS fields that portfolio managers see.


## Stage 2 consolidation (2026-10-06)

RCOV-, RREC-, RPUB- and IMTG- are registered. The five local copies of shared lists were replaced by direct citations. 24's RREC- example now follows the 23 format. 23's two Party Role Type values (Expert Network, Corporate Access Provider) are deferred to the program lead. See `_tools/consolidation/stage2_consolidation_notes.md` and §15 of the conventions document.

## 6. Wealth model carry-over (W1b, CW-923)

23 is kept (plan section 5.1). The pass made only the changes CW-022 allows: the US-only pass, the perspective text and the re-pointing of the 02 wording. No object or attribute is removed or renamed, so no attribute ID changes. The decision draft and the jurisdiction entries are in `_tools/consolidation/proposals_w1b_23.py`.

**Removed (EU/UK only; 8 jurisdiction entries: Other EU/UK 3, MiFID II 3, FCA 1, UK Stewardship Code 1).**
- Code list Corporate Access Charge Basis: value Minor Non-Monetary Benefit (the MiFID II inducement exemption).
- Sources: Delegated Directive (EU) 2017/593 Articles 12-13 with MiFID II Article 24; Directive (EU) 2024/2811; FCA COBS 2.3B and PS24/9; EU MAR (Regulation 596/2014) Articles 7, 11 and 20; Delegated Regulation (EU) 2016/958; Delegated Regulation (EU) 2016/960 and the ESMA market soundings guidelines; UK Stewardship Code 2026.

**Re-sourced.**
- Research payment and evaluation fields to Exchange Act Section 28(e) (SEC Release 34-54165): Corporate Access Charge Basis, Subscribed Service Type, Research Interaction Type, Overall Evaluation Score, Evaluation Criterion and the source alignment of the lists Corporate Access Charge Basis, Research Provider Type and Evaluation Criterion. Evaluation Period End Date reads Internal. The payments themselves stay in 25.
- Publication Review.Investment Recommendation Disclosure Indicator (review fix pass, program-lead ruling): kept and re-sourced from EU and UK MAR Article 20 to FINRA Rule 2241 (research report disclosures) and FINRA Rule 2210 (retail communications; new source row), for research the affiliated broker-dealer distributes to clients.
- Wall-crossing and MNPI fields to Advisers Act Section 204A policies: Meeting Start Timestamp, Wall-Crossing Consent Indicator and Wall-Crossing Timestamp cite Section 204A alone; MNPI Received Indicator has FINRA Rule 3110(d) as secondary (new source row; 3110(d) covers transaction review for insider trading, not wall-crossing records).
- Recommendation fields that cited Delegated Regulation (EU) 2016/958: Recommendation Change Type, Valuation Method and Key Risks now cite FINRA Rule 2241 as the sell-side reference point (Recommendation Horizon Months reads Internal: Rule 2241 sets no horizon); Previous Recommendation, Price Target (secondary), Recommendation Timestamp, Price at Recommendation, Key Assumptions, Publication Timestamp, External Release Indicator and External Release Date cite Internal or nothing. The list Recommendation Change Type aligns to FINRA Rule 2241 rating and price target history.
- Stewardship Objective Indicator reads Internal (the stewardship hand-off to 34 stays; 34 takes its own US-only pass).

**Perspective rewritten.** META subtitle; overview Purpose (the investment management arm of a US direct wealth manager: proprietary funds, the advice model portfolios and institutional separate accounts, lines PF, DA, HA and IA; sub-advised funds use the sub-adviser's research), Scope (parties in 02 Client & Household), CDE (Section 28(e) only), Notes (US privacy law: state laws such as the CCPA as amended by the CPRA, and Regulation S-P where the individual is also a client), Suggested next steps item 5 (payment routes per fund and account: own resources or Section 28(e) client commissions); the "Why this domain exists" paragraph above; SME questions 9 and 11; SUMMARY in `enrich_23.py`.

**Re-pointed.** "02 Client & Customer" reads "02 Client & Household" and "01 Investment Product" reads "01 Investment Product & Service Offering" in the overview Scope and SUMMARY. Issuers, research providers, expert networks and issuer executives stay Reference (Party), which the wealth 02 keeps (CW-021). 23 holds no client, account or holding text.

**Kept on purpose (investment universe, CW-022).** Coverage of foreign issuers, countries and rates markets; "non-GAAP or non-IFRS" on Adjusted Basis Indicator (foreign issuers report under IFRS); "core HICP for the euro area" on the Economic Indicator list; the euro area as a forecast geography.

**Added.** Nothing (the brief names no addition for 23). New source rows FINRA Rule 3110(d) and FINRA Rule 2210 only.

**Left for later stages (NOTES in the proposals file).** The relationship to 30 Due Diligence Workstream (W4 retirement of 30); "sales activity (03)" in the Purpose and "Never a 03 Sales Activity" in the Issuer Meetings family and its relationship (re-pointed to 03 Advisor Activity at W5); SME question 7 (private-company research outside 30).

**Open questions (W1b).**
1. Closed in the review fix pass: the disclosure flag is kept with FINRA Rules 2241 and 2210. Remaining question: which released notes count as research reports under Rule 2241 rather than retail communications under Rule 2210 (confirm with Compliance)?
2. Corporate access: SEC staff treat arranging issuer meetings as outside the Section 28(e) safe harbor in some cases; should Corporate Access Charge Basis gain a value for corporate access paid with client commissions only where bundled with eligible research (confirm with Compliance)?

**Unverified.** The FINRA Rule 3110 URL is the FINRA rulebook pattern and paragraph (d) (transaction review and investigation) should be opened once (confirm).
