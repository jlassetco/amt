# Source Notes: 24 Portfolio Management & Construction

**Workbook:** `Portfolio_Management_and_Construction_Data_Taxonomy.xlsx` (built from `_tools/content/content_24_portfolio_management_and_construction.py`)
**Status:** Draft v0.1, 2026-10-06, revised after independent review (00_Program/Expansion/Reviews/24_review.md); adapted to the wealth manager at W3, 2026-10-15 (section 7; the counts in this line are the wholesale v0.1 counts). Perspective: Wealth manager (direct) | Scope: US. 8 families, 28 objects (25 business objects, 3 attribute groups), 239 attributes, 81 proposed CDEs (33.9%), 25 local code lists plus 6 verbatim copies of enterprise shared lists, 57 relationships, 19 sources, 21 attributes flagged PII in wholesale v0.1 (struck at W3: 24 now holds no client PII, only employee references). 53 references to other Data Domains, 7 derived copies, 5 ownership overrides, 0 unresolved.

**Why this domain exists.** Between the product the firm sells (01) and the book it holds (18) sits the record of intent: what the investment committee decided, which portfolio managers run which books, what each portfolio and model should hold, which rebalance produced which proposed trades, how much cash will be investable tomorrow and which basket an ETF will accept today. Portfolio managers, the multi-asset and solutions teams and the investment committees produce this data in the portfolio management, optimizer and order management platforms. No existing domain covers it: 01 holds the model portfolio as an offering with no weights and the disclosed portfolio managers at product grain, and 18 holds what is held, not what should be held. Intent has its own owners, approvals and history, and every later control (pre-trade compliance, best execution, performance attribution, the Advisers Act Rule 204-2(a)(3) order memorandum) has to trace a trade back to the decision that caused it. That is the reason for a separate Data Domain.

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| SEC Rule 6c-11 (exchange-traded funds) | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.6c-11 | Definitions (a): a custom basket is a basket of a non-representative selection of the ETF's holdings, or a representative basket that differs from the initial basket used that business day; the cash balancing amount accounts for the difference between the basket's value and the NAV of a creation unit. Custom basket policies and procedures (c)(3). Basket records (d)(2): holdings with quantities and percentage weights, custom basket identification and compliance record, cash balancing amount, AP identity. Website disclosure (c)(1); baskets need not be posted. Shaped ETF Basket (Basket Type, Basket Balancing Amount), ETF Basket Constituent (Constituent Weight), Custom Basket Approval and Custom Basket Reason. |
| Advisers Act Rule 204-2(a)(3) | https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.204-2 | Memorandum of each order: terms, the person who recommended the transaction and the person who placed it, the account, the date of entry; discretionary orders designated. Re-sources the decision trail (W3; replaces the removed RTS 22 row, CW-924). |
| Advisers Act Rule 206(4)-1; FINRA Rule 2210(d)(1)(F) | https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.206(4)-1 | Hypothetical performance (definition in paragraph (e)) for projections built on capital-market assumptions; broker-dealer limits on projections (rule moving: SR-FINRA-2026-004, filed 2026-02-10, pending at the SEC; confirm, including planning tools). |
| Investment Company Act Rule 3a-4 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.3a-4 | Model-based discretionary advisory programs: context for Model Lineup. |
| GIPS 2020 Standards for Firms | https://www.gipsstandards.org/standards/gips-standards-for-firms/ | Portfolio, composite and benchmark concepts; blended benchmarks used as policy benchmarks. |
| FIX Protocol (FIX Latest) | https://www.fixtrading.org/standards/ | Side (tag 54) and PositionEffect (tag 77); fields a proposal carries into a 25 Trade Order; list orders for program trades. |
| DOL QDIA regulation, 29 CFR 2550.404c-5 | https://www.ecfr.gov/current/title-29/subtitle-B/chapter-XXV/subchapter-F/part-2550/section-2550.404c-5 | Target-date (life-cycle) funds and model portfolios whose asset mix changes with age or target date: Glide Path Point, Allocation Policy Type 'Glide Path', Policy Model Portfolio. |
| IRS Publication 550; IRC Sections 1091 and 1222; Treas. Reg. 1.1012-1(c); Form 8949 | https://www.irs.gov/publications/p550 | Identification of shares sold, wash sales, holding periods: Lot Selection Method, Wash Sale Risk Indicator, Proposed Lot Selection and Tax Budget. |
| IRC Section 817(h) and Treas. Reg. 1.817-5 | https://www.ecfr.gov/current/title-26/chapter-I/subchapter-A/part-1/section-1.817-5 | Diversification test for insurance-dedicated funds; 24 holds only the internal buffer (Constraint Type 'Diversification Buffer'); the test is coded in 33. |
| CFA Institute Asset Manager Code | https://rpc.cfainstitute.org/codes-and-standards/asset-manager-code | Reasonable basis and documentation of investment decisions, committee governance. |
| ILPA Principles 3.0 | https://ilpa.org | Context for private investment governance and co-investment (Decision Scope Deal). Added after review. |
| ILPA Reporting Template | https://ilpa.org | Commitment, call and distribution terms used in the Commitment Pacing Plan. Removed with the object at the W3 fix pass (CW-930). |
| Money Management Institute | https://www.mminst.org | Industry descriptions of SMA, UMA and model-delivered programs, sleeves and overlay management (no formal definitions; cited as practice). |
| FIBO (SEC, FBC) | https://spec.edmcouncil.org/fibo/ | Portfolio, holding and asset class concepts. |
| GICS | https://www.msci.com/our-solutions/indexes/gics | Sector and industry codes for classification target lines, through the 09 scheme register (ICS-). Added after review; URL to confirm. |
| DTCC / NSCC ETF services | https://www.dtcc.com | Daily dissemination of baskets (portfolio composition file). Page not confirmed; see section 3. |
| Axioma / MSCI Barra; BlackRock Aladdin; Charles River IMS; SimCorp One (public product pages) | https://www.simcorp.com, https://www.blackrock.com/aladdin, https://www.crd.com | Structure only: hard and soft optimizer constraints, tracking error budgets, turnover limits, risk models, model management, rebalancing and order generation, cash ladders. |
| ISO 3166 / 4217 / 8601 | https://www.iso.org | Country, currency and date formats. |

SEC Form N-1A and SEC Form ADV were cited in v0.1 and removed after review: under option B the N-1A disclosure is 01's, and Form ADV did not support the committee entity.

## 2. Design decisions and boundary calls

- **CD-175 under option B (deviation from the brief, on the program lead's instruction).** 01 'Portfolio Manager Assignment' is unchanged and holds the disclosure. 24 masters only the operational **Portfolio Management Assignment** at portfolio grain (18 `PORT-`, manager `EMP-` and/or team `OU-`, role, effective period). The 24 role and dates are operational and may legitimately differ from the 01 disclosed role and length of service (sleeve managers, backups). 24 holds no disclosed facts and cites no N-1A requirement. proposals_24 NOTES propose the reconciliation (employee and role, through the 18 implementation link) and the 01 re-typing of Portfolio Manager to `Reference (Employee)` that the join needs. 01 Investment Strategy 'Lead Portfolio Manager' remains a third record of who manages what under option B. Option A steps are also in the NOTES.
- **Model as product vs model weights (CD-176).** A Target Allocation Set names exactly one subject, typed by Target Subject Type, with one reference per subject type. 01 keeps the model record and its delivery terms. Model Change Summary is an attribute group for model subjects; no delivery-event object is created.
- **Target weight is held once**, on Target Allocation Line. Whether weights are absolute or active is the set's Active Weight Indicator. Classification lines name the 09 classification scheme (`ICS-`) and the node code. Tolerance bands are in percentage points of portfolio weight. Sleeves are 18 child portfolios.
- **Target Set Status is lifecycle only** (Working, Scheduled, Effective, Superseded, Withdrawn); approval uses the shared Approval Status; sponsor publication is an indicator. A version's end is the next version's effective timestamp (no superseded timestamp stored). Basket Purpose is separate from Basket Type.
- **Investment governance (deviation: one object added).** Investment Committee Member (committee x employee x role x period); the chair is a member role. The outcome is held only on Investment Committee Decision. **Private investment approvals are 24's (CD-205, program lead decision):** Committee Decision Type has 'Private Investment Approval' and 'Private Investment Exit Approval', and Decision Scope Deal references the 30 Deal (`PDL-`). Deal Allocation across funds is 30's.
- **Asset allocation policies** apply to a strategy, a product or (new after review) a 01 model portfolio, for target-date model series on recordkept plan menus. **Neutral Weight is a Derived copy (01)** of the policy benchmark's Blend Components, with a row rule (per plan §4 item 9): mastered here only when the policy has no blended benchmark. Line Proxy Benchmark is the matching blend component.
- **Glide paths (deviation in grain).** A glide path is an Asset Allocation Policy of type Glide Path; each Glide Path Point is policy x years to target date x asset class x sub-class, the sub-class being level 2 of the 17 firm asset-class scheme.
- **Asset class list.** 24 cites the shared **Instrument Asset Class** directly (direct user since Stage 2); allocation uses exclude Multi-Asset and Derivative.
- **Constraints are not rules.** Portfolio Construction Constraint holds only the portfolio manager's limits and may reference the 01 restriction it buffers. Client restrictions (02 `CRX-`, customizations) and account restrictions (15 `ARX-`, trading blocks) are applied per portfolio at proposal and recorded only as a relationship on Rebalance Portfolio Result. Realized gain limits are held once, on Tax Budget.
- **Commitment pacing (wholesale; removed at W3, CW-930):** portfolio x plan period x plan version date.
- **Investment decisions (deviation: one object added).** An Investment Decision (`IDEC-`) records the action (Investment Decision Action: Initiate, Add, Trim, Exit, Switch, Reweight, Hedge) separately from the cause (Investment Decision Cause, on Decision Rationale). It covers one or more portfolios or models through **Investment Decision Scope** rows; Decision Strategy names a strategy-wide decision. Decision Maker is the person who recommended the transaction (Rule 204-2(a)(3)); an algorithmic decision names a 37 Decision Algorithm instead (W3). A switch names both instruments.
- **Rebalancing (deviation: two objects added).** Rebalance Run (`RBAL-`); its scope is the set of its Rebalance Portfolio Results. Index changes trigger a run through **Rebalance Index Change Trigger** (one row per 22 announcement). Proposed Trade has a system key (Proposed Trade ID, no prefix) and an Originating Investment Decision, so manual proposals are keyed and traced. **CD-180:** the order references the proposal; 24 no longer holds Released Trade Order, release time or releasing person, only the status Released. Accepting a Rebalance Portfolio Result sets its proposals to Accepted. Proposed Lot Selection (proposed trade x tax lot) holds lot-level instructions.
- **Tax budget** is keyed by the 18 portfolio of an institutional separate account (or sleeve) x tax year since W3 (CW-048); retail account budgets are 46. Realized Gain to Date is a Derived copy (18).
- **Cash forecast (CD-178, program lead decision).** Investable Cash Amount = Opening Cash (Derived copy 18) + Projected Cash Net (Derived copy 18, every Projected Cash Movement source including capital activity) + the portfolio manager's adjustments − Cash Target. Capital activity is counted once. Adjustment sources are limited to items not yet in 18 (expected large subscription or redemption, planned investment, manual correction). One forecast per currency.
- **ETF baskets (CD-177, program lead decisions).** Basket Balancing Amount is the one estimated cash fact, mastered here as the Rule 6c-11(a) cash balancing amount; NAV per Creation Unit is computed as 27 NAV per Share x creation unit size (Derived copy 27); the actual cash per AP order is 29. The cash attributes moved onto ETF Basket (the separate Basket Cash Component attribute group was dissolved, keeping the object count within the brief's range). Basket Type follows the two limbs of the 6c-11(a) custom basket definition; representative sampling and index-change baskets are standard when representative and equal to the day's initial basket. Constituent Weight records the 6c-11(d)(2) percentage weight. Basket ID format BSKT-YYYYMMDD-nnnnn is published in proposals_24 for 29.
- **Personal data rule (W3).** 24 holds no client personal data: retail managed accounts are 46. Institutional separate account amounts are confidential, not PII; employee references are PII (internal staff).
- **Ownership overrides.** Four own-object references with composite keys starting `STR-` or `PORT-` are forced to mastered here; the 22 index change reference, whose key starts `BMK-`, is forced to 22.
- **Shared lists.** Record Status, Approval Status, Frequency, Period Type, Data Basis, Flow Direction, Business Line and Lot Relief Method are cited directly as enterprise shared lists (direct user since Stage 2; the v0.1 local copies were dropped).
- **Size against the brief:** 8 families / 28 objects (target 25 ±3), 239 attributes (180-240), 33.9% CDE, 25 local lists (18-25), 57 relationships, 19 sources. Only `IDEC-`, `TGT-`, `RBAL-` and `BSKT-` appear as new prefixes. No Record Metadata object.

### Review response

All 4 High and 10 Medium findings were applied as described above, following the program lead's decisions. Lows applied unless listed here:

| Finding | Response |
|---|---|
| D Low: Rebalance Run scope attribute and run status | Not added. Scope is defined as the set of Rebalance Portfolio Results (the reviewer's alternative); a run status list would push local lists above the brief's 25, and a failed run is one without results. |
| C Low: Target Weight Basis code | Applied as a Boolean (Active Weight Indicator) instead of a code list, to stay within the local list range. |
| C High (part): rename Pro Rata Deviation Indicator to Non-Representative Selection Indicator | Dropped instead. Representativeness is a basket-level fact already given by Basket Type and Custom Basket Reason (which names the 6c-11(a) limb). |
| G Low: research recommendations many per decision | Partly applied: the relationship is n : 0..n; the attribute holds the primary recommendation and the thesis names others. A multi-valued reference type is not in the conventions' data type list. |
| B Low: Committee Decision Outcome overlaps Approval Status | Kept (Deferred and Noted have no equivalent); the mapping is in proposals_24. |
| A Low (30 Deal Allocation name) | Applied in REL and TERM_CONFLICTS; no 24 attribute needs a Reference (Deal Allocation, 30). |
| A High (30 deal approvals), link direction | Both 24 (Decision Scope Deal) and 30 (Deal / Investment Committee Decision) hold the link as instructed; proposals_24 recommends keeping one direction at consolidation. |
| E Low: four overrides | Kept, as the reviewer recommends; note added to proposals. |
| G Low: DTCC page | Still not confirmed (section 3). |

## 3. What could not be verified

- The CFA Institute Asset Manager Code URL (rpc.cfainstitute.org) was taken from the brief and not opened; confirm.
- The DTCC page for ETF portfolio composition file services was not located; the source row points to the DTCC home page (confirm).
- The GICS page URL on msci.com was not opened; confirm.
- Money Management Institute publishes no formal definitions; cited as industry practice. Commitment pacing has no standard.
- Vendor optimizer and platform structures are taken from public product descriptions only.

## 4. Open questions for client SMEs

1. Which platforms hold targets, models and rebalances (OMS / PMS, optimizer, model management platform)?
2. Option A or B for Portfolio Manager Assignment (CD-175), and is the assignment kept per portfolio, per product or both? (Drafted as B, per portfolio.)
3. Is each model's target set shared with a lead portfolio (representative account), or maintained separately?
4. Are house views and tactical allocation formally recorded by an investment committee, and which committees exist?
5. Who owns glide path design: the investment committee or product development (36)?
6. Are proposed trades persisted after release, or only the resulting 25 orders?
7. Is the investable cash forecast stored, and which flow estimates feed it (06, 29, 12 cash flow notifications)?
8. Who approves custom ETF baskets, and are rejected baskets kept? (Drafted as kept.)
9. (W3) Answered by CW-048: retail managed account budgets are 46; institutional separate account budgets stay here.
10. Are private fund pacing plans built by 24 or by the private markets team (30), and are they split by private markets strategy or vintage?
11. How is every order linked to a decision today (order memorandum under Rule 204-2(a)(3), trade rationale capture)?
12. Are tactical views set at house level only, or also per strategy and per portfolio manager?
13. Are sleeve-level tax budgets used in multi-sleeve institutional separate accounts, or only portfolio-level budgets?
14. Are investment decisions taken across a strategy (one decision for many portfolios) or per portfolio?

## 5. Overlaps with other domains (for consolidation)

- **01:** Portfolio Manager Assignment (CD-175 option B, reconciliation and Portfolio Manager re-typing); model weights (CD-176); Creation Unit Size and policy neutral weights copied; 01 'Asset Class' and 'Business Line' lists differ from the lists used here.
- **06 / 29:** 06 'ETF Basket Type' to be split between 29 Basket Settlement Form and 24 Basket Type; 29 adopts BSKT-YYYYMMDD-nnnnn.
- **18:** cash projections and realized gains copied (CD-178); Business Line and Lot Relief Method copied verbatim.
- **37:** Decision Algorithm and CMA Generating Model reference Model Inventory Entry (MODEL-).
- **45 / 46 / 52:** see section 7.
- **22 / 23 / 25 / 27 / 30:** Index Change Announcement (22); Research Recommendation `RREC-` (23); 25 Trade Order holds the link to Proposed Trade (CD-180) and should use the Proposed Trade ID; Share Class NAV (27) for NAV per creation unit; Deal `PDL-` and the decision link direction (30, CD-205).
- Term conflicts on Target, Allocation, Decision, Model, Basket, Portfolio Manager Assignment and Committee are in proposals_24.

## 6. Recommended next steps

1. Take the CD-175 decision; apply the 01 re-typing and the reconciliation check in either case.
2. Register `IDEC-`, `TGT-`, `RBAL-` and `BSKT-` with their key formats and 24's shared-list memberships at Stage 2 consolidation.
3. Walk one model change end to end with the multi-asset team: committee decision, policy version, target set, rebalance run, proposed trades, 25 orders.
4. Walk one ETF creation day with ETF capital markets and 29: basket build, balancing amount, custom basket approval, dissemination, AP order and actual cash, in-kind booking in 18.
5. Walk one private deal approval with 30: deal, committee decision, deal allocation, private investment.
6. Confirm with investment compliance that Decision Maker, Decision Algorithm and Decision Timestamp give what the Rule 204-2(a)(3) order memorandum needs.
7. Revisit Rebalance Portfolio Result tracking error fields when 31 Investment Risk is drafted.


## Stage 2 consolidation (2026-10-06)

IDEC-, TGT-, RBAL- and BSKT- are registered. Business Line is now the enterprise shared list (CD-209), and 24 cites it directly with the other six shared lists. The private deal approval direction with 30 is CD-208. See `_tools/consolidation/stage2_consolidation_notes.md` and §15 of the conventions document.


## 7. Wealth model adaptation (W3, 2026-10-15)

Brief: `00_Program/Rework/Briefs/W3_24_32_Family_Additions.md`; decisions CW-009, CW-046, CW-048, CW-121, CW-128, CW-130 and the US-only pass CW-924 (`_tools/consolidation/proposals_w3_24.py`).

**Counts.** Before: 8 families, 28 objects, 240 attributes, 81 CDEs, 54 references, 9 derived, 32 code lists, 57 relationships, 19 sources. After: 10 families, 34 objects (31 business objects, 3 attribute groups), 285 attributes, 99 CDEs (34.7%), 60 references, 8 derived, 0 unresolved, 36 code lists, 76 relationships, 21 sources.

| Wholesale item | Disposition |
|---|---|
| Investment Decision.Decision Supervising Branch Country | Removed (MiFIR RTS 22 field 58; JURISDICTION) |
| Investment Decision.Decision Algorithm Code | Removed (MiFIR); replaced by Decision Algorithm, Reference (Model Inventory Entry, 37) |
| RTS 22 references on Investment Decision ID, Decision Maker, Decision Timestamp, Investment Decision Scope, Target Allocation Set and Proposed Trade (Originating Investment Decision), Decision Authority Indicator | Re-sourced to Advisers Act Rule 204-2(a)(3) |
| Source Delegated Regulation (EU) 2017/590 | Removed (MiFIR) |
| Tax Budget.Budget Account | Removed (CW-048, boundary; not jurisdiction); Budget Portfolio becomes the key |
| Proposed Trade, Proposed Lot Selection, Rebalance Portfolio Result | Kept; definitions limited to 18 portfolios and 18 LOT- lots; PII notes replaced by confidentiality notes |
| Committee Decision Type, Investment Committee Type | Re-cut: CMA Approval, Model Lineup Approval, Manager Hire, Manager Termination, Third-Party Product Approval; Manager Research Committee |
| Decision Scope Deal, Commitment Pacing Plan, Private Markets Investment Committee, private investment decision values, ILPA sources | Removed at the fix pass with the 30 retirement (CW-930, CW-166) |
| Insurance-dedicated buffer (IRC 817(h)) | Kept; CW-004 scope note |

**Added.** Capital Market Assumptions (`PM-CMA`): Capital Market Assumption Set (`CMASET-`; exact name, read by 45), Asset Class Return Assumption, Asset Class Correlation Assumption. Advice Model Construction (`PM-MDC`): Model Lineup (`MLNUP-`), Model Lineup Position, Model Building Block. Asset Allocation Policy gains Policy Purpose and Policy CMA Set.

**Modeling decisions.** Inflation is held once on the set (answers the 45 review). Correlations relate two return assumption lines of the same set; the diagonal is not stored. A lineup names its CMA set only when it has no governing policy (row rule), so the set is held once. A lineup position decides nothing about a client: 45 recommends from it, 46 assigns from it, both by reference; risk and horizon bands read the 02 Investor Profile lists. Equity share is a design label; the weight is only on Target Allocation Line. The building block's Product List Status is a Derived copy of 52; substantial identity for wash sales is 46.

**Deviations from the brief.** Proposals file `proposals_w3_24.py` (the assignment) rather than `proposals_24.py`. Policy Purpose adds Multi-Asset Fund. Not added for the size band: CMA set name, lineup name, a default-position flag and a client-projection-use flag (boundary rule 4 is stated in the family definition).

**Not verified (confirm).** FINRA Rule 2210(d)(1)(F) (rule moving: SR-FINRA-2026-004 pending) treatment of investment analysis tools and planning projections; whether the marketing rule staff FAQ treats CMA-based projections in one-on-one plans as advertisements. Rule 204-2(a)(3), Rule 3a-4 and 29 CFR 2550.404c-5 were cited from the eCFR paths in the brief.

**SME questions (levers, with the reference default).** 1) CMA set built in house or licensed? Default in house, one set per horizon, approved annually; lever: licensed, the set becomes a 14 dataset with 24 approval only (CMA Generating Model blank). 2) One lineup for every advice program? Default one lineup per purpose. 3) Are alternates used outside wash sale windows (for example product changes)? Default yes, as Building Block Role Alternate. 4) Does the workplace managed account service personalize from a lineup or directly from the glide path? Default from a glide-path lineup.

**Readers to re-point** (lineage pass): DP-126, SM-08 (Decision Algorithm Code, Decision Supervising Branch Country); DP-130 and keys_e7_22_24 (Tax Budget.Budget Account); DP-127 unchanged until W4. Lines in proposals_w3_24.py NOTES.

### Fix pass (00_Program/Rework/Reviews/24_32_review.md, 2026-10-15)

Program-lead rulings: band widened to 295 attributes; 30 retires (CW-930, CW-166), applied here from proposals_w4_retire.py CARRIED_INTO_MERGE (22 items).

**Counts.** Before the fix pass: 10 families, 34 objects, 285 attributes, 99 CDEs, 60 references, 8 derived, 36 code lists, 76 relationships, 21 sources. After: 10 families, 33 objects (30 business objects, 3 attribute groups), 280 attributes, 98 CDEs (35.0%), 60 references, 8 derived, 0 unresolved, 35 code lists, 77 relationships, 19 sources.

**Applied.** Model Lineup Name and Lineup Service Offering (01 OFFR-); Building Block Slot and Alternate For Building Block; Policy Mandate (01 MND-, the subject 12 Investment Policy Statement references; key `<MND-> v<version>`); Model Lineup Position readers (45 Recommendation, 46 Model Assignment) recorded as proposed; key-format AMENDMENTS for the return and correlation assumptions; Decision Authority Indicator reference order swapped; committee example "PF; DA; HA; WR; IA"; Rule 3a-4 row re-worded and made secondary on Model Lineup Purpose; DOL target-date fund tips page (February 2013) https://www.dol.gov/agencies/ebsa/about-ebsa/our-activities/resource-center/fact-sheets/target-date-retirement-funds-tips-for-erisa-plan-fiduciaries; Product List Status read for Product Use Scope "Advice Models" on Building Block Effective From; sub-class examples aligned; Decision Algorithm example MODEL-0441; 37 Model Type request; the 30 removals (Decision Scope Deal, Commitment Pacing group and Plan, Private Markets Investment Committee, three decision-type values, two RELs, two ILPA sources, overview and enrich text).

**CDE swaps.** Un-flagged: Meeting Date, Committee Member, Tactical Stance, Assignment Effective From, Cash in Lieu Indicator, Custom Basket Approver, Proposed Trade Side. Flagged: Building Block Share Class, Building Block Instrument, Policy Model Portfolio, CMA Horizon Years, Model Lineup Status, Lineup Effective From, and the new Policy Mandate, Lineup Service Offering and Building Block Slot.

**Skipped.** None. Vehicle keys: both kept (01 SHC- on the block, 17 INS- on the target line), with the 17-to-01 join stated in the note.
