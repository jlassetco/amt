# Source Notes: 25 Portfolio Trading & Execution (wholesale name Trading & Execution)

**Workbook:** `Trading_and_Execution_Data_Taxonomy.xlsx` (built from `_tools/content/content_25_trading_and_execution.py`)
**Status:** Draft v0.1, 2026-10-06, revised after independent review (00_Program/Expansion/Reviews/25_review.md); wealth model carry-over 2026-10-14 (W1b, CW-925; section 7). **Perspective:** Wealth manager (direct) | Scope: US. 7 families, 30 objects (28 business objects, 2 attribute groups), 266 attributes, 84 proposed CDEs (32%), 27 local code lists plus the enterprise shared lists (35 in the workbook), 43 relationships, 19 sources. 60 references, 4 derived copies, 0 unresolved. 21 attributes flagged PII: 6 employee references, 8 portfolio references and 4 institutional separate account references (conditional on a natural person's account), and the three FINRA 5130 / 5131 beneficial-owner attributes.

**Why this domain exists.** The portfolio trading desks of the US wealth manager turn portfolio decisions for its own funds and institutional portfolios into executed trades: they receive orders, aggregate them into blocks, place them with brokers, venues and algorithms, record fills, allocate the result fairly across funds, sleeves and institutional separate accounts, and evidence best execution. Client orders of the brokerage and advisory business are a different lifecycle with their own regulation and are mastered in 48 Brokerage Orders & Execution (CW-010); hence the rename to Portfolio Trading & Execution. They also approve the brokers and counterparties the firm may trade with, pay commissions and research, and take part in new issues. Until now this data had no owner: 18 books the result of an allocation, 06 holds shareholder transactions in the firm's own funds, and 05 "Trading Setup" is fund dealing with distributors. Trading creates records that regulators examine apart from the book (order audit trail, fair allocation, best execution, new issue eligibility, counterparty approval), and every downstream domain (18 booking, 26 settlement, 33 compliance, 38 surveillance) needs the order, execution and allocation keys.

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| FIX Protocol (FIX Latest): NewOrderSingle, NewOrderList, ExecutionReport, AllocationInstruction, AllocationReport, Confirmation | https://www.fixtrading.org/standards/ | Field and enumeration alignment: Side (54), OrdType (40), TimeInForce (59), OrdStatus (39), ExecType (150), ExecInst (18), SecurityType (FXSPOT, FXFWD, FXSWAP, FXNDF), LastCapacity (29), LastLiquidityInd (851), LastMkt (30), CommType (13), AllocID (70), SettlDate (64), SettlDate2 (193), CalculatedCcyLastQty (1056), GrossTradeAmt (381), NetMoney (118). Shaped Trade Order, Order Handling Instruction, Broker Placement, Execution, Trade Allocation and Allocation Cost Detail. |
| SEC Release IA-5248 (2019), Commission Interpretation Regarding Standard of Conduct for Investment Advisers | https://www.sec.gov/rules/interp/2019/ia-5248.pdf | The adviser's duty to seek best execution as part of its fiduciary duty of care under Advisers Act Section 206 (Best Execution Policy, Execution Factor Priority, Best Execution Review). Added at W1b (CW-925); URL not reopened (confirm). |
| FINRA Rule 5310 (Best Execution and Interpositioning) | https://www.finra.org/rules-guidance/rulebooks/finra-rules/5310 | Reasonable diligence and the 5310(a)(1) factors, regular and rigorous review, for the affiliated broker-dealer where it executes portfolio trades (Best Execution Policy, Execution Factor). Added at W1b (CW-925). |
| SEC Rules 605 and 606 | https://www.ecfr.gov/current/title-17/chapter-II/part-242/section-242.606 | Rule 606(b)(3) reports on not-held orders on request (Execution Instructions note; Best Execution Review count). |
| FINRA Rules 5130 and 5131 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/5130 ; https://www.finra.org/rules-guidance/rulebooks/finra-rules/5131 | Restricted persons, 10% de minimis, general exemptions, reliance on representations made within the prior 12 months, spinning (New Issue Eligibility Certification, Restricted Person Status). |
| SEC Rules 17a-7 and 10f-3 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.17a-7 ; https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.10f-3 | Cross trades at the independent current market price, no brokerage other than customary transfer fees (Cross Trade); affiliate-in-syndicate purchases: not from the affiliate, percentage cap, quarterly board review (New Issue Offering, Rule 10f-3 Purchase). |
| SEC SMC Capital no-action letter (1995) | https://www.sec.gov/divisions/investment/noaction/smccapital090595.htm | Aggregation and allocation conditions: written pre-allocation, same average price, documented departures (Block Order, Block Order Membership, Trade Allocation). |
| SEC Rule 13h-1 | https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.13h-1 | Large trader ID given to brokers (mastered on Order Handling Instruction until 38 owns the Form 13H registration). |
| Exchange Act Section 28(e); Release 34-54165 | https://www.sec.gov/rules-regulations/2006/07/commission-guidance-regarding-client-commission-practices-under-section-28e-securities-exchange-act | Commission sharing arrangements and eligible research (Commission Sharing Arrangement, Research Payment Source). |
| ERISA Section 408(b)(19) (29 U.S.C. 1108(b)(19)) | https://www.law.cornell.edu/uscode/text/29/1108 | Cross trades involving plan assets (CITs) (Cross Trade Basis). |
| Exchange Act Section 31 (15 U.S.C. 78ee) | https://www.law.cornell.edu/uscode/text/15/78ee | Regulatory transaction fee on covered sales; example at the FY2026 rate of USD 20.60 per million from 4 April 2026 (rate taken from the review; confirm against SEC Fee Rate Advisory 2026-2). |
| Regulation SHO Rule 203 | https://www.ecfr.gov/current/title-17/chapter-II/part-242/section-242.203 | Sell Short / Sell Short Exempt sides (the locate reference was dropped as broker data). |
| CAT NMS Plan | https://www.catnmsplan.com/ | CAT reporting falls on broker-dealer Industry Members: no CAT objects here (CD-184); the affiliated broker-dealer's CAT reporting of client orders is 48 (CW-010). |
| FINRA TRACE | https://www.finra.org/filing-reporting/trace | Bond prints as a TCA benchmark source (Composite Bond Price); the data itself is 22. |
| ISO 10383 MIC; ISO 4217 | https://www.iso20022.org/market-identifier-codes | Executing venue codes, XOFF for off-venue trades; currency codes for FX currency pairs and dealt currency. |
| SEC Form ADV Part 2 Item 12 | https://www.sec.gov/about/forms/formadv-part2.pdf | Directed brokerage, trade rotation and trade-away disclosure. |
| Advisers Act Rule 204-2(a)(3); Investment Company Act Rule 31a-1(b)(5) | https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.204-2 ; https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.31a-1 | Order memoranda with time of entry (Order Created Timestamp, Trade Order Event). Rule 17a-4 (broker-dealers) is no longer cited. |
| Charles River IMS, Bloomberg AIM / EMSX, Aladdin, FlexTrade (public product descriptions) | https://www.crd.com | Structure only: order, block, placement ("route"), fill and allocation objects; broker approval lists. |

## 2. Design decisions and boundary calls

- **Order-to-allocation chain (CD-180).** Trade Order (`TORD-`) -> Block Order Membership -> Block Order (`BLOCK-`) -> Broker Placement -> Execution (`EXEC-`) -> Trade Allocation (`ALLOC-`). Every order executed in the market goes through a block (a block of one when not aggregated). The order references the 24 Investment Decision (`IDEC-`) and, where it came from a rebalance or manual proposal, the 24 Proposed Trade, keyed by 24's grain (run x portfolio x instrument x side). The order holds this link; 24 drops its reverse copy.
- **25 masters the value 18 holds as "Source Allocation ID".** 18 Portfolio Transaction "Source Allocation ID" (today an Identifier flagged Derived copy (25)) is to be re-typed `Reference (Trade Allocation, 25)` at consolidation (CD-180).
- **Commission (CD-174).** Commission, research component, exchange and clearing fees, regulatory fees and transaction taxes live only on Allocation Cost Detail. 18 "Commission Amount" and "Research Payment Component" become Derived copy (25). proposals_25 proposes the same row rule for 18's fee and tax amounts (the Section 31 fee booked into 18 Exchange and Clearing Fee Amount) and gives a 25 -> 18 mapping table for the four trade fields whose names differ (Gross Trade Amount / Principal Amount, Net Trade Amount / Net Settlement Amount, Allocation Average Price / Transaction Price, Allocation Trade Date / Trade Date).
- **FX orders and executions (CD-168, program lead decision 1).** A Trade Order can be for an FX contract: FX Instrument Type (FIX SecurityType), Currency Pair (base/quote as dealt), Dealt Currency, the dealt amount (Order Cash Amount), FX Value Date and FX Far Value Date; Order Instrument is optional because 17 has no FX instrument (proposals_25 asks 17 for one). Executions carry Dealt Amount, Contra Amount, Executed FX Rate (the dealt rate in the quoted direction of the pair) and Far Leg FX Rate. The CD-168 row rule is changed: 18 Trade FX Rate on FX-trade rows is derived from the executed rate with a stated conversion to base currency (as is, inverted, or crossed through base with a 22 rate), not copied; bundled FX on securities settlements stays a 22 copy.
- **Cross trades (program lead decision 3).** An internal cross produces two Trade Allocations with Allocation Source "Internal Cross" and no block or executing broker. Cross Trade has its own reference and a cross timestamp in its grain, and references the 22 Price Observation at the time of the cross (Rule 17a-7 current market price), with the value as Derived copy (22).
- **Counterparty approval (CD-143 working assumption, CD-179).** Approved Counterparty Profile is a role profile keyed by `PTY-` (17 Issuer Profile pattern): no name, LEI or legal parent. Approval status lives on the profile, scope status on the scope row, next review date only on the profile; the review records the status it set. Scope and limits may be narrowed to a fund. Required agreements are a reference to 26 Trading Agreement (`TAGR-`); limit usage is 31; the credit view is a 23 Internal Credit Assessment.
- **Research (CD-174).** "CSA" is never used: the object is Commission Sharing Arrangement, with a dated Commission Sharing Balance series. Research Payment references the 23 Research Evaluation Round (provider x period x evaluator) and the 19 Payable Invoice; its payment status is a Derived copy (19). 25 holds no "research payment route" for 23 to copy.
- **Reporting (CD-184).** The MiFIR Transaction Report object was removed at W1b (CW-925; section 7). Large Trader ID is a Derived copy of the 38 Form 13H registration. No CAT objects: CAT reporting of client orders is 48.
- **Rule 10f-3 (program lead decision 4).** Rule 10f-3 Purchase records each fund's purchase in an offering with an affiliated underwriter: allocation as evidence, seller, percentage of the offering, conditions met, board report date.
- **TCA (program lead decision 4).** Benchmark-independent measures (arrival price, implementation shortfall, explicit cost, outlier) are held once on TCA Result; TCA Benchmark Result holds one row per benchmark with its price and cost.
- **Operating model (CD-147).** Trade Order carries the trading legal entity; Best Execution Policy carries Trading Operating Model and Outsourced Trading Provider.
- **Status lists kept apart.** Trade Order Status (OMS lifecycle), Trade Order Event Type and Compliance Check Outcome (Derived copy (33)) are three lists. Block status is the EMS working status exchanged in FIX (OrdStatus); the order's lifecycle includes pre-release states, so the two are kept distinct. Counterparty Approval Status maps to the shared Approval Status for Pending, Approved and Rejected and adds usage states.
- **Effective dating.** Approval status (effective from), scopes, limits, commission schedules, commission sharing arrangements and policy versions are effective-dated; balances are dated by statement; reviews are dated events.
- **Per-row ownership (plan §4 item 9).** No 25 object mixes mastered and copied rows. The row rule applies in 18 (trade rows booked from 25 allocations) and is proposed there.
- **Shared lists.** Approval Status, Record Status, Case Status, Severity, Frequency, Outgoing Payment Status and Period Type are local copies with the exact shared names and values; Message Standard is a copy plus one proposed value, "FIX" (the value 22 also proposes). Listed in proposals_25 SHARED_MEMBERSHIPS with identity value maps.
- **Reference typing.** Own objects are typed `Reference (<Object>, 25)`; sibling objects `Reference (Investment Decision, 24)`, `Reference (Proposed Trade, 24)`, `Reference (Price Observation, 22)`, `Reference (Trading Agreement, 26)`, `Reference (Internal Credit Assessment, 23)`, `Reference (Research Evaluation Round, 23)` and `Reference (AP Creation / Redemption Order, 29)`. Grain-keyed references whose example starts with another domain's prefix are fixed with OWNERSHIP_OVERRIDES (6 forced to 25, 2 to 23).

### Deviations from the brief

- **Objects: 31 (29 BO, 2 AG) instead of 28 (25 BO, 3 AG); 30 after W1b.** Added after review: Rule 10f-3 Purchase, Commission Sharing Balance and TCA Benchmark Result. The MiFIR Transaction Report business object was removed at W1b.
- **Trade Allocation grain** is block (or cross trade) x executing broker (none for crosses) x trade order x portfolio or institutional separate account (brief: block x portfolio or account). A block placed with two brokers yields two confirmations; two member orders for one portfolio need the order in the key. An institutional separate account must be managed by the allocated portfolio.
- **Counterparty Approval Scope countries** are a descriptive multi-valued attribute (ISO 3166-1), not part of the key.
- **Commission Schedule:** execution-only versus bundled is expressed by the execution and research component rates, not a separate list.
- **Research Payment** grain adds the payment source.
- **TCA Result** measures one of trade order, block order or execution (brief: order or execution).
- **Best Execution Policy** keeps approved venues only; approved brokers are the Counterparty Approval Scope rows.
- **Execution Strategy** is on the block; trading desk was dropped from the order.
- **Business Line** was not used (the brief allowed it "if needed").
- **Dropped to hold the attribute target** (v0.1 and this revision): short sale locate reference, requested settlement date, non-standard settlement indicator, execution yield, placement limit price, status and requested venue, allocation priority, allocation timestamp, reallocation justification, "allocated by", order event reason and resulting status, indication limit price, fairness reviewer, offering currency (prices are in the instrument's quotation currency), initial approval date, approving committee, relationship owner, limit approver and warning threshold, event-driven review flag and status before review, research payment account reference, budget approver and disclosure date, commission schedule execution strategy, TCA slippage and outlier comment, broker rank, broker review action, period commission total, exceptions count, report submission timestamp, rotation sequence number. Each can return if an SME needs it.

### Review response

All 1 High and 14 Medium findings were applied, the High and five Mediums as decided by the program lead (FX model and CD-168 rule; proposal link held by the order; cross trades as allocations without a block and with a 22 Price Observation; Research Evaluation Round; Large Trader ID mastered here; decision maker as a 24 copy; Rules 204-2 and 31a-1; market-side INTC report; Rule 10f-3 Purchase; dated balances; TCA header and benchmark rows; "FIX"; mapping table; FY2026 Section 31 example). Lows were applied except as listed:
- **A, Research Payment Route on Research Budget (Medium): not applied, by program lead decision.** 23 is removing its "Research Payment Route" copy, so 25 adds no master for it.
- **A, Research Payment to 23 evaluation (Medium): applied as the program lead set it.** The reference is to the 23 Research Evaluation Round (provider x period x evaluator); the relationship is n : 0..n because a payment relates to every evaluator's round of its period.
- **C, price currency on each object (Low): applied by definition, not by new attributes.** Order limit, cross, independent, offer, arrival and benchmark prices state that they are in the instrument's quotation currency (17); a currency attribute on each would exceed the size target.
- **C, Execution Factor Priority as a ranked child (Low): applied as a note** (list order is significant), not as a new object, to stay within the object target.
- **C, Block Order Status vs Trade Order Status (Low): kept both**, with the reason stated (EMS working status in FIX vs OMS lifecycle with pre-release states).
- **D, Counterparty Trading Limit Type mixing activity and measure (Low): partly applied.** Values renamed to "measure + activity"; no separate activity attribute was added (size target).
- **D, Counterparty Approval Scope key (Low): applied by removing countries from the grain**; no surrogate scope ID was added.
- **E, 09 Entity Authorization Type value for Form 13H (Medium): superseded** by the program lead decision to master the Large Trader ID here until 38.
- **E, Investment Decision Maker (Medium): applied as an Identifier holding the RTS 22 field 57 value** (person identifier or algorithm code), flagged Derived copy (24). The decision itself is reached through Trade Order.Originating Investment Decision rather than a second reference on the report.
- **H, syndicated loan trade attributes (Low): applied as a note** (documentation and assignment / participation are treated as 26 settlement data; proposals_25 NOTES).
- **J, CDE rebalance (Low): applied** (Allocated Account, Trade Order Event Type, Execution Type and Execution Venue flagged; the three review outcomes and several dates and references unflagged), giving 84 CDEs (30%).

## 3. What could not be verified

- **FIX enumeration codes** in list descriptions (e.g. Side D = Subscribe, OrdType D = Previously Quoted, TimeInForce 7 = At the Close) are from knowledge of FIX 4.4 / FIX Latest; confirm against fiximate / orchimate.
- **FINRA 5130 general exemptions** are cited as an external list "FINRA Rule 5130(c)" without reproducing the values; confirm the paragraph reference.
- **SEC Rule 605 amendments** (Release 34-99679) compliance date of 1 August 2026 and any later relief: confirm (brief note); nothing in the model depends on it.
- **Section 31 FY2026 rate** (USD 20.60 per million from 4 April 2026, USD 0 before) is taken from the review; confirm against SEC Fee Rate Advisory 2026-2.
- **FIX FX tags** (SecurityType values, SettlDate2 193, CalculatedCcyLastQty 1056, LastPx2 640) are from knowledge of the standards; confirm.
- **Rule 10f-3 percentage cap** (25% for most categories) is stated in a note only; confirm per security category.
- **LTID format** in the example (8 digits + 4-digit suffix) is illustrative.
- **Vendor structures** (Charles River, Bloomberg, Aladdin, FlexTrade) are inferred from public descriptions only; "placement" is often called "route" in EMS products.
- **Examples** (IDs, prices, amounts, rates) are illustrative.

## 4. Open questions for client SMEs

1. Which OMS / EMS platforms are in use by asset class, and which is the system of record for allocations?
2. Is the allocation recorded per portfolio and per institutional separate account, or per sleeve with account allocation done by the sponsor? Are internal crosses booked as allocations in the OMS?
3. Which committee approves brokers and counterparties, and are limits set by trading or by risk (31)? Are limits set per entity, per fund or per activity?
4. (Closed at W1b: the firm reports no MiFIR transactions; CW-925.) Do portfolio orders and 48 client orders ever share a block, a desk or an executing broker list, and if so how is fair allocation between funds and client accounts evidenced?
5. Which entities pay research from own resources (hard dollars) and which through Section 28(e) commission sharing (soft dollars)?
6. Are cross trades permitted, for which vehicles, and who approves them?
7. Is any affiliate ever in an underwriting syndicate (Rule 10f-3)?
8. How is trade rotation between sponsor programs and model-delivery platforms recorded?
9. Which TCA provider is used, and are results stored per execution, per order or per block?
10. Are trade errors recorded in the OMS, in a separate incident tool, or both (37)?
11. Is FX for share class hedging executed by the trading desk or by a third-party hedging provider? Are FX trades set up as instruments in the security master today?
12. Is any trading outsourced (outsourced trading desk, sub-adviser trading), and for which asset classes (CD-147)?

## 5. Overlaps with other domains (for consolidation)

- **18:** Source Allocation ID (re-type), Commission Amount and Research Payment Component (Derived copy (25)), Trade FX Rate (derived with a stated conversion), plus the proposed row rule and mapping table for fees, taxes and trade fields. Portfolio Transaction, Transaction Cost & Charge and Portfolio Transaction Event are not rebuilt.
- **02:** Party Role Type additions (CD-179); no party facts repeated on the profile.
- **05:** "Trading Setup" (fund dealing) term conflict; sponsor program agreements (`AGR-`) referenced for trade rotation.
- **06:** No shareholder order objects; Transaction (`TXN-`), Order Source and ETF Creation / Redemption are not used.
- **17:** FX contract instrument proposed.
- **22 (sibling):** Price Observation referenced from Cross Trade (value as Derived copy); cross-currency FX conversion uses 22 rates; TCA benchmarks use 22 data; "FIX" Message Standard value agreed.
- **23 (sibling):** Research Evaluation Round and Internal Credit Assessment referenced by grain.
- **24 (sibling):** Investment Decision (`IDEC-`) and Proposed Trade referenced from Trade Order; 24 drops Released Trade Order.
- **26 (sibling):** Trading Agreement (`TAGR-`) referenced from Counterparty Approval Scope; 26 OTC Trade Date proposed as a Derived copy (25); no confirmation, settlement status or agreement terms in 25.
- **29 (sibling):** AP Creation / Redemption Order referenced from Trade Order.
- **33, 37, 38 (later stages):** compliance outcome copy, incident reference as text, large trader ID (mastered here until 38).

## 6. Recommended next steps

1. Confirm the changed CD-168 rule with its owner and the FX instrument with 17.
2. Answer SME questions 1, 2 and 4 first: they fix the system of record, the allocation grain and the boundary with 48 client orders.
3. Map attributes to the OMS / EMS of record and to the FIX messages exchanged with brokers.
4. Apply the 18 re-typing, Derived copy flags and mapping (CD-168, CD-174, CD-180) and register TORD-, BLOCK-, EXEC-, ALLOC- and TCA- in decisions.py; drop the ", 25" qualifiers once registered.
5. Register 25 as a direct user of the nine shared lists and add "FIX" to Message Standard (with 22).
6. Turn the Relationships tab into the logical order-to-allocation model shared with 18, 24, 26, 31, 33 and 38.


## Stage 2 consolidation (2026-10-06)

TORD-, BLOCK-, EXEC-, ALLOC- and TCA- are registered. The nine local copies of shared lists were replaced by direct citations; FIX was added to Message Standard once. 18 Source Allocation ID references ALLOC- (CD-180), and 18 Commission Amount and Research Payment Component are derived copies of Allocation Cost Detail (CD-174). The 25 Party Role Type values were added to 02 (CD-143). The other trade fields in TRADE_FIELD_MAPPING are deferred. See `_tools/consolidation/stage2_consolidation_notes.md` and §15 of the conventions document.

## 7. Wealth model carry-over (W1b, CW-925)

25 is kept and renamed **Portfolio Trading & Execution** (plan section 5.1; CW-010): META title and subtitle carry the new name now; `domains.py` takes it at merge (the program lead), and the output path and folder `25_Trading_and_Execution` are unchanged. The overview states the boundary: fund and institutional portfolio orders are mastered here; client orders, their routing, executions, allocations to client accounts, confirmations, Rule 605 and 606 disclosure and CAT reporting are 48, including the orders that rebalance retail managed accounts (46). The pass made the four kinds of change of CW-022 only. No object or attribute is renamed; one object and three attributes were removed (families Allocation and Commissions & Research Payments, whose attribute positions renumber). The decision draft, the jurisdiction entries and the readers are in `_tools/consolidation/proposals_w1b_25.py`.

**Removed (EU/UK only; 19 jurisdiction entries: MiFIR 9, MiFID II 8, FCA 1, Other EU/UK 1).**
- Object MiFIR Transaction Report (11 attributes: Transaction Reference Number, Aggregated Market-Side Report Indicator, Reported Block Order, Reported Trade Allocation, Transmission Conditions Met Indicator, Reporting Legal Entity, Approved Reporting Mechanism, Receiving Competent Authority (example FCA, a removed shared Regulator value), Investment Decision Maker, Execution Decision Maker, Transaction Report Status), its object group Transaction Reports, its relationship and its enrichment rows (grain, the Derived copy (24) of Investment Decision Maker).
- Research Budget: Research Payment Account Indicator and Client Research Charge Rate (MiFID II research payment account). Commission Sharing Arrangement: Joint Payment Indicator (EU 2024/2811 and FCA COBS 2.3B joint payment option).
- Code lists: Transaction Report Status (6 values, whole local list; member of the shared Regulatory Report Status, steward 25); Cross Trade Basis value Firm Conflicts Policy (EU / UK funds); Research Payment Source value Research Payment Account.
- Sources: MiFID II Article 27; Delegated Regulation (EU) 2017/565 Articles 64-65 and 50; Directive (EU) 2024/790 and FCA PS21/20; MiFIR Article 26; RTS 22 (Delegated Regulation (EU) 2017/590); Delegated Directive (EU) 2017/593 Article 13 with Directive (EU) 2024/2811; FCA PS24/9 and COBS 2.3B.

**Re-sourced.** Best Execution Policy (Policy Legal Entity, Execution Factor Priority, Reviewed Policy) to the adviser's duty of best execution (SEC Release IA-5248, Advisers Act Section 206) and FINRA Rule 5310 for the affiliated broker-dealer; the Execution Factor list source likewise (values kept: they are the factors a US best execution policy weighs); Policy Asset Class, Approved Execution Venues and Explicit Cost bps to Internal; Research Budget (Budget Year, Budget Legal Entity, Budget Strategy, Research Budget Amount) to Internal and Section 28(e) (examples USD and the US adviser entity LEN-0004); Research Payment Source and Research Payment Component to Section 28(e) alone; Commission Amount, Exchange and Clearing Fee Amount and Transaction Tax Amount to the FIX Protocol; the MiFIR and MiFID cross-references on Originating Investment Decision, Order Originator, Trading Legal Entity, Block Trader, Execution Strategy, Execution Timestamp and Execution Venue replaced by Advisers Act Rule 204-2, SEC Rule 31a-1, SEC Form ADV, the FIX Protocol or nothing. Cross trades stay on Rule 17a-7 and ERISA Section 408(b)(19).

**Kept on purpose (investment universe, CW-022).** Foreign venues (XLON in the approved venue example), FX orders and executions, the WM/Reuters fix as a TCA benchmark, Hedged Share Class (generic; listed in NOTES as rarely used by US funds), stamp duty and financial transaction tax on foreign trades.

**Perspective and re-points.** META title and subtitle; overview Purpose, Scope (the CW-010 boundary), Core model, Design principle 1 (trade order, not client order or fund order), Applies To, Notes (Regulation S-P, GLBA and state law in place of GDPR; no MiFIR identifiers) and Suggested next step 6; family texts of Order Management, Allocation, Commissions & Research Payments and Best Execution & TCA; "SMA account" reads "institutional separate account" in the two PII note constants, Allocated Account, Indicating Account, Receiving Account, Certified Account, Directed Broker, Trade-Away Indicator, Trade Rotation Program and the Model Change value; 02 is named Client & Household (party core) and 01 Investment Product & Service Offering; enrich_25 docstring, SUMMARY and four grain texts.

**Additions.** None (brief: rename only).

**Open questions (W1b).**
1. Does the affiliated broker-dealer execute any fund or institutional portfolio trades (FINRA Rule 5310 then applies to it, and Section 17(e) and Rule 17e-1 to its commissions), or does the adviser trade only with unaffiliated brokers?
2. Are research payments made in hard dollars by any entity now that the MiFID research payment account is gone, or only through Section 28(e) commission sharing?
3. Do the funds have currency-hedged share classes at all (Hedged Share Class, Order Reason Share Class Hedge)?

**Fix pass (W1b review).** Sponsor and wrap program accounts (Directed Broker note, Trade-Away Indicator, Trade Rotation Program, Order Reason Model Change) now read as sponsor program accounts of the intermediary channel (IC line), and institutional separate account is kept for the firm's own institutional mandates (program lead ruling 1); Trading Legal Entity says orders of external sub-advisers are not held here (52); the RTS 22 and Directive 2024/2811 items left section 3, and Regulator left the shared-list sentence (25 holds no Regulator list).

**Unverified.** SEC Release IA-5248 URL (the reviewer confirmed it); FINRA Rule 5310 URL follows the FINRA rulebook pattern (confirm); the attribution of the Execution Factor values to FINRA 5310(a)(1) is by analogy (the rule names market character, size and type, markets checked and accessibility of quotation), not a verbatim list.
