# Source Notes: 26 Trade Operations, Settlement & Collateral

**Workbook:** `Trade_Operations_Settlement_and_Collateral_Data_Taxonomy.xlsx` (built from `_tools/content/content_26_trade_operations_settlement_and_collateral.py`)
**Status:** Draft v0.2, 2026-10-06 (independent review applied); wealth model carry-over 2026-10-14 (W1b, CW-926; section 6). **Perspective:** Wealth manager (direct) | Scope: US. 6 families, 28 objects (22 business objects, 6 attribute groups), 297 attributes, 93 proposed CDEs (31.3%), 42 code lists in the workbook (31 local), 49 relationships, 29 sources, 52 references, 4 derived copies, 9 attributes flagged PII.

**Why this domain exists.** Once a fund or institutional portfolio trade is allocated in 25, investment operations has to confirm, match, instruct and settle it, work the fails and the fails charges or foreign CSD penalties they bring, keep every OTC derivative and repo through its life, report swaps where the fund is the reporting side, and call, post and agree margin under the ISDA and CSA terms it negotiated with each counterparty. These records run on their own lifecycle and deadlines (same-day affirmation under US T+1, daily margin calls). They are kept per trade, per agreement and per day by a function that is distinct from portfolio trading (25) and fund custody (28). 26 is fund-side settlement only: the self-clearing broker-dealer's clearance and settlement of client trades is 49 Clearing, Settlement & Client Asset Custody (plan section 5.1). No existing domain covered them: 12 captured SSIs only at mandate set-up, 18 books trades without settling them, and 28 holds safekeeping and reconciliation.

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| ISO 20022 sese and colr message definitions | https://www.iso20022.org/iso-20022-message-definitions | sese.023 instruction content (securities movement, payment, place of settlement, partial settlement), sese.024 status advice (processing, matching and settlement status with reason codes), sese.025 confirmation, sese.027 cancellation status. colr margin call, response and dispute messages shaped Margin Call and Dispute Reason. |
| SWIFT ISO 15022 MT 540-548, MT 670 / 671 | https://www.swift.com/standards/iso-15022 | Receive / deliver free (MT 540 / 542) and against payment (MT 541 / 543), confirmations (MT 544-547), status advice (MT 548), SSI update notifications. Settlement Type keeps payment basis and direction out of the list (see §2). |
| SMPG market practice | https://www.smpg.info/ | Status and reason codes (LACK, MONY, CLAC, CMON, CMIS, NMAS, DDAT, DQUA, DSEC, DTRD, DMON, FUTU, CYCL, LATE, PREA / PRCY) for the Settlement Fail Reason list. Codes recalled from market practice; confirm (see §3). |
| DTCC CTM, DTCC TradeSuite ID | https://www.dtcc.com/products-and-services/trade-processing-solutions/ctm | Central matching of allocations and confirmations, match status, affirmation; the Confirmation Channel and Match Exception Field lists. "CTM" is written only as a channel value, never as an ID (CTM- is 07's prefix). |
| DTCC ALERT | https://www.dtcc.com/products-and-services/trade-processing-solutions/alert | Counterparty and own-side SSIs; SSI Source. |
| SEC Release 34-96930 (Rules 15c6-1, 15c6-2; Rule 204-2 amendments) | https://www.sec.gov/rules/final/2023/34-96930.pdf | T+1 from 28 May 2024; same-day allocation, confirmation and affirmation; adviser recordkeeping of time-stamped allocations, confirmations and affirmations (Affirmation Timestamp). |
| CSDR (Regulation (EU) No 909/2014), CSDR Refit (Regulation (EU) 2023/2845), Regulation (EU) 2025/2075 | https://eur-lex.europa.eu/eli/reg/2014/909/oj ; https://eur-lex.europa.eu/eli/reg/2023/2845/oj ; https://eur-lex.europa.eu/eli/reg/2025/2075/oj | Settlement discipline; cash penalties since 1 February 2022; mandatory buy-ins only if the Commission adopts an implementing act; EU T+1 from 11 October 2027. |
| Delegated Regulation (EU) 2018/1229 and (EU) 2017/389 | https://eur-lex.europa.eu/eli/reg_del/2018/1229/oj | Late matching fail penalty (LMFP, charged once to the last party to instruct) and settlement fail penalty (SEFP, per business day); penalty rates. LMFP / SEFP behavior cross-checked with CSD publications (ECB T2S, Clearstream, Euronext). |
| UK accelerated settlement (T+1) | https://www.gov.uk/government/publications/accelerated-settlement-t1 | UK T+1 from 11 October 2027. |
| ISDA documentation (Master, CSA VM / IM) | https://www.isda.org/book/2018-credit-support-annex-for-initial-margin-im-ny-law/ | Agreement and annex structure, threshold, minimum transfer amount, independent amount, valuation agent, eligible collateral, additional termination events. |
| ISDA SIMM | https://www.isda.org/isda-solutions-infohub/isda-simm/ | IM Calculation Method and SIMM Version. |
| ISDA / FINOS Common Domain Model | https://www.finos.org/common-domain-model | Lifecycle event types and cash flow types for OTC trades. |
| BCBS-IOSCO margin framework (Basel MGN) | https://www.bis.org/basel_framework/chapter/MGN/10.htm | IM threshold, MTA, eligible collateral, haircuts (including the 8% FX haircut), segregation and no rehypothecation of IM. |
| CFTC 17 CFR 23.150-23.161 | https://www.ecfr.gov/current/title-17/chapter-I/part-23/subpart-E | US uncleared margin for swap dealers' counterparties (funds as financial end users). |
| FINRA Rule 11810; Regulation SHO Rule 204 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/11810 ; https://www.ecfr.gov/current/title-17/chapter-II/part-242/section-242.204 | Buy-in procedures of the FINRA Uniform Practice Code and close-out of fails to deliver by clearing agency participants (Buy-In Notice, Buy-In Basis). Added at W1b (CW-926); URLs follow the FINRA and eCFR patterns (confirm). |
| CFTC Part 45 | https://www.ecfr.gov/current/title-17/chapter-I/part-45 | Swap data reporting, UTI, action and event types. |
| ISO 23897 (UTI), ISO 4914 (UPI) | https://www.iso.org/standard/77308.html | UTI structure (LEI of generating entity plus unique value); UPI at product level in 17. |
| ICMA GMRA, SIFMA MRA | https://www.icmagroup.org/market-practice-and-regulatory-policy/repo-and-collateral-markets/legal-documentation/global-master-repurchase-agreement-gmra/ | Repo Trade terms (purchase / repurchase date and price, haircut, substitution). |
| FIA clearing and give-up documentation | https://www.fia.org/ | Futures and cleared derivatives agreements; give-up agreement parties. |
| SEC Rule 18f-4 and Rule 6c-11 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.18f-4 | Context: derivatives data that 31 and 35 will read; in-kind ETF basket settlement. |
| TMPG fails charge | https://www.newyorkfed.org/tmpg | US Fails Charge penalty type. |
| AcadiaSoft (vendor practice) | https://www.acadiasoft.com/ | Margin call workflow and statuses, dispute handling, IM reconciliation (Counterparty IM Amount). Structure only. |
| ISO 9362 / 13616 / 4217 / 3166 / 8601 | https://www.iso.org | BIC, IBAN, currency, country (including ISO 3166-2 for governing law, e.g. US-NY) and date formats. |
| SEC Regulation SBSR (17 CFR 242.900-242.909) | https://www.ecfr.gov/current/title-17/chapter-II/part-242 | Reporting of security-based swaps (single-name CDS and total return swaps); added to Trade Report Regime (review A). |
| FINRA Rule 4210 (covered agency transactions) | https://www.finra.org/rules-guidance/rulebooks/finra-rules/4210 | TBA margin since 22 May 2024 (reviewer verified the date); MSFTA agreement type and Variation Margin note. |
| Delegated Regulation (EU) 2017/389 | https://eur-lex.europa.eu/eli/reg_del/2017/389/oj | Penalty rate parameters (own source row now). |
| LSTA secondary trading and settlement practice | https://www.lsta.org/ | Assignment vs participation, agent and borrower consents, delayed compensation (Loan Settlement Detail). |
| CLS | https://www.cls-group.com/ | Payment-versus-payment FX settlement (CLS Settlement Indicator). |
| ISDA 2021 Interest Rate Derivatives Definitions (via ISDA documentation) | https://www.isda.org/ | Compounded overnight rate calculation (Floating Rate Calculation Method, Observation Shift Days); labels to confirm. |

## 2. Design decisions and boundary calls

- **CD-155, SSIs: drafted under option A.** 12's "Standing Settlement Instruction" moved here with its 10 attribute tuples copied exactly, and with its lists SSI Asset Class, Settlement Message Standard and SSI Verification Status unchanged. The one change to a moved tuple is a row-rule note on "Safekeeping Account" (program lead decision on the review). The grain is widened from mandate to instruction owner by adding attributes, not renaming: SSI Owner Type, SSI Portfolio, SSI Fund, SSI Counterparty, Own Safekeeping Account (28 SKA-), Counterparty Safekeeping Account Number, SSI Settlement Currency (the key for cash SSIs), Cash Correspondent BIC, Cash Account Number, SSI Status and SSI Effective To. SSI Verification is a new attribute group. content_12 is not edited; the removal is applied at merge. `SSI-` is still registered to 12, so enrich_26 forces the two SSI references on Settlement Instruction to "mastered here".
- **Safekeeping account row rule (CD-155 / CD-194).** Exactly one account attribute is set, by SSI Owner Type: Client Mandate uses the moved "Safekeeping Account" (12 CUA-); Fund and Portfolio use "Own Safekeeping Account" (28 SKA-); Counterparty uses "Counterparty Safekeeping Account Number". The rule is in both notes and in enrich_26 ROW_RULES. Re-typing the moved attribute to SKA- and retiring "Own Safekeeping Account" is a CD-194 consequence, logged in proposals_26, not part of CD-155.
- **CD-155 option B (not drafted).** 12 would keep client-mandate SSIs, and 26 would create "Counterparty and Portfolio Settlement Instruction" (`CPSI-`) for fund, portfolio and counterparty instructions with the same attribute names. Two objects would then hold one concept split by owner type, which needs a consolidation check that no owner appears in both.
- **CD-181, values held in 18.** Rewritten at the right grain (proposals_26 NOTES): Settlement Confirmed Indicator is a Derived copy of the latest Settlement Status Event; Initial Margin Posted is a Derived allocation of the per-agreement posted initial margin (regulatory and cleared) Collateral Value to the portfolio's derivative holdings, pro rata to each holding's IM contribution or, failing that, to gross notional; Encumbered Quantity is the sum of posted Balance Quantity for the holding's portfolio and instrument across all agreements and margin types, including repo collateral delivered out and cleared margin, plus 28's on-loan quantity. Collateral Balance now has the source portfolio and the currency in its grain so these roll-ups work. Settled / Unsettled Quantity stay 18 computations.
- **CD-182, agreements.** Trading Agreement (`TAGR-`), Credit Support Terms, Eligible Collateral Schedule and Termination Event Trigger are here; approval and limits are 25 (25 Governing Trading Agreement references TAGR-), exposure 31, securities lending agreements 28. Agreement types now include MSFTA (TBAs, margined under FINRA Rule 4210), Prime Brokerage and Tri-Party Collateral Agreements. Amendments set Last Amendment Date; a new annex is a new row linked by Parent Agreement.
- **CD-183, hand-off.** Trade-level settlement only; statements and reconciliations are 28, ledger entries 27. 27 and 28 already reference "Settlement Instruction, 26". 26 Related AP Order is an order-level reference only; 29 Basket Settlement Line owns the line-level link to SETL-.
- **CD-184, reporting.** Derivative Trade Report covers CFTC Part 45 and SEC Regulation SBSR, where the fund rather than its dealer counterparty reports, and names the Reporting Counterparty (02 party record of the fund) and the Report Submitting Entity. Reporting obligations and counterparty classifications are read from 38. EMIR, UK EMIR and SFTR reporting and the Entity Responsible for Reporting (EMIR Article 9(1d)) were removed at W1b (section 6).
- **CD-185, cycles.** Settlement Cycle Rule is market x instrument type x settlement type x effective period with allocation and affirmation cut-offs; calendars are 09.
- **CD-147.** Settlement Instruction and Trading Agreement carry the outsourced operations provider.
- **One Settlement Instruction object, attribute groups by type.** The instruction keeps one key (SETL-) for every settlement so that 27, 28 and 29 reference one thing. Securities attributes (instrument, quantity, place of settlement, direction, payment basis) apply to securities types, and their CDE flags are conditional on Settlement Type (notes and ROW_RULES). Cash Payment Detail (payment direction, currency, amount, FX counter amount, CLS indicator) serves cash collateral, derivative payments and FX settlement; Loan Settlement Detail (participation indicator, administrative agent, loan trade date, closing date, consents, delayed compensation) serves syndicated loan trades. FX settlement is in scope here; FX trade economics stay in 25.
- **Status as events, one fact once.** Settlement status lives only on Settlement Status Event (processing status, Matched Indicator and Trade Settlement Status as separate attributes). OTC Trade Status and Repo Status are noted as derived from events and never maintained separately. Collateral value lives only on Collateral Balance; Margin Call keeps Collateral Held Amount only as the call-calculation snapshot. Margin Call Status is lifecycle only; direction is Call Collateral Direction.
- **Confirmed values are the broker's.** Confirmed Trade Date, Settlement Date, Quantity, Price and Net Amount are mastered here as received and compared with 25 (Our Value / Their Value on the match exception). Settlement Quantity and Amount keep a row rule: Derived copy (25) for trade rows, mastered on Collateral Movement, Repo Trade or 29 basket lines otherwise.
- **OTC economics by leg.** OTC Trade Leg (trade x leg) holds payer, notional and currency, fixed rate or floating index and spread, calculation method, payment frequency and day count. The trade keeps trade-level terms only (dates, side, option strike and expiry, CDS reference entity). OTC Cash Flow carries leg, calculation period, a single fixing reference or observation shift and calculated compounded rate, so compounded overnight rates are supported.
- **Repo Trade.** Keyed by a firm Repo Trade Reference (the SFTR UTI was removed at W1b). Its collateral is held as Collateral Balance and Collateral Movement rows of margin type Repo Collateral, which also carry substitutions.
- **Prices and fixings from 22.** Collateral Market Value is computed here from Balance Quantity and the referenced 22 Approved Price (mastered here, computed). OTC Cash Flow references 22 fixings.
- **Shared lists.** Exact local copies of nine shared lists, listed under SHARED_MEMBERSHIPS; Message Standard values are proposed at business-area level together with 25 and 28.

**Deviations from the brief.**
1. Settlement Type split into business purpose, Against Payment Indicator and Securities Movement Direction; the local "Settlement Cycle" list is replaced by the `T+n` format.
2. Settlement Status Event carries separate processing, matching and settlement statuses.
3. Settlement Fail has no resolution-type list; the outcome is read from the status events and the Buy-In Notice.
4. Initial Margin Calculation grain adds direction; Collateral Balance grain adds source portfolio and currency; Termination Event Trigger grain adds the measurement period (one row per tier).
5. Objects: 28 (brief 25 ±3) after adding OTC Trade Leg, Cash Payment Detail and Loan Settlement Detail at the program lead's direction.
6. Attributes: 300 (brief 210-270). The overshoot comes from the review additions the program lead asked for (leg economics, cash and loan settlement detail, trade report parties, compounded rates, collateral keys); 14 lower-value attributes were removed to offset part of it.
7. Local lists: 31 (28 new plus 3 moved from 12), above the 20-28 target.
8. Report event types, OTC trade side, leg floating rate index and day count use external code sets.

### Review response

Applied: all 15 Medium findings, as decided by the program lead, and all Low findings except those listed below.

Not applied, or applied differently:
- **A (CUA- / SKA-), counterparty rows.** The lead's decision says fund, portfolio and counterparty SSIs use the 28 safekeeping account. Counterparty SSIs describe the counterparty's own account at its settlement agent, which is not a 28 record (28 masters the firm's accounts at its custodians). Counterparty rows therefore use "Counterparty Safekeeping Account Number"; fund and portfolio rows use SKA-.
- **A (moved Safekeeping Account PII).** The PII wording is included in the row-rule note now rather than waiting for merge, because the lead asked for the note on the moved attribute.
- **E (SSI ID CDE).** Not flagged now, because the moved tuple is copied exactly; logged in proposals_26 NOTES as a merge-time change.
- **D (Repo collateral as multi-valued or child group).** Applied differently: Repo Collateral Instrument was removed, and repo collateral is held as Collateral Balance and Collateral Movement rows (margin type Repo Collateral, Related Repo Trade), which also serve CD-181.
- **B (Independent Amount twice).** Kept the amount on Credit Support Terms and removed the "Independent Amount" Margin Type value.
- **C (Penalty Borne By code).** Applied as a Boolean (Penalty Absorbed by Firm Indicator, blank until decided) plus the existing portfolio reference, to avoid another local list.
- **C (Loan transfer form).** Applied as a Boolean Participation Indicator rather than a list.
- **G (27 hand-off).** Logged in proposals NOTES for 27 to confirm; no 26 change is needed.
- **J (CDE rebalancing).** The keys the reviewer named are now CDEs; to stay near 30%, CDE flags were removed from secondary keys of child records (leg payer, movement margin type, IM calculation date and others).
- **Funding Memo Amount, Fail Owner, Call Analyst, Agreement Negotiator, SIMM Version and eight similar attributes** were removed to limit the size overshoot. These removals were not review findings.

## 3. What could not be verified

- **SMPG reason codes.** The Settlement Status Reason codes are recalled from ISO 15022 / 20022 practice; confirm them against the current SMPG and custodian documentation.
- **CSD penalty statuses and messages.** No penalty status list is modeled (Penalty Appeal Status uses Case Status); the ISO 20022 penalty report message (semt.044) and MT 537 penalty use were not confirmed.
- **CFTC Part 45 event types** are cited as an external code set; confirm against the CFTC technical specifications (the EMIR Refit set left at W1b).
- **Floating Rate Calculation Method labels** follow the 2021 ISDA Definitions as recalled; confirm.
- **DTCC cut-offs** (19:00 / 21:00 ET) in the examples; confirm with DTCC and the custodians.
- **Regulation (EU) 2025/2075** was confirmed by the reviewer (published 14 October 2025, applies from 11 October 2027). The UK T+1 date is from the brief.
- **ISO 23897 page URL** (iso.org/standard/77308) returned 403 to an automated fetch; confirm. **DTCC ALERT URL** now follows the brief; not re-verified.
- **Vendor models** (CTM, ALERT, AcadiaSoft, CLS, Calypso / Murex, Aladdin / SimCorp) were used for structure only.
- Identifiers in examples (UTIs, BICs, account numbers, IBAN) are illustrative.

## 4. Open questions for client SMEs

1. CD-155: option A or B for SSIs, and is DTCC ALERT the golden source for counterparty SSIs?
2. Which matching and settlement platforms are used (CTM, TradeSuite ID, custodian portals, in-house), and is any part of trade support outsourced (CD-147)?
3. Are the cash penalties foreign CSDs charge on the funds' settlements (EU CSDR) allocated to portfolios or absorbed by the firm, and are US fails charges tracked?
4. Are OTC derivatives held as one 26 trade per contract with product terms in 17 (17 SME question 2)?
5. For which funds' swaps and security-based swaps is the fund the reporting side (CFTC Part 45, SEC Regulation SBSR) rather than the dealer, and is submission delegated?
6. Which funds are in scope of uncleared initial margin, and who are the segregation custodians?
7. Is collateral management in house or outsourced (tri-party, collateral agent)?
8. Do settlement instructions for institutional separate accounts go to the clients' custodians directly or through the sponsor?
9. Do the funds use repo, and under which master agreements (GMRA, MRA)? Which funds trade TBAs under MSFTAs?
10. Does the firm hold ISDA documentation for the funds as counterparties or for the adviser as agent, and how are fund-level termination triggers (NAV decline tiers, key person) monitored?
11. How do settlement records flow to the fund accountant and custodian when those functions are outsourced (27, 28)?
12. Under CD-194, should the moved SSI "Safekeeping Account" (CUA-) be re-typed to SKA- and merged with "Own Safekeeping Account"?
13. What basis should allocate initial margin posted per agreement to derivative holdings in 18 (IM contribution or gross notional)?
14. Is FX settlement (CLS and gross) run by trade operations, and are syndicated loan trades settled by the same team?

## 5. Recommended next steps

1. Decide CD-155 and CD-194 together. Then apply the SSI move to 12 (remove the object and its three lists, add the 12 reference to the 26 SSI), re-register `SSI-` to 26, flag SSI ID as CDE, and re-type the moved Safekeeping Account if CD-194 option A is chosen.
2. Walk through the families with trade support, settlements, collateral management, derivatives operations and regulatory reporting; confirm the CDEs and the status and reason lists.
3. Map attributes to the matching platform, custodian messaging (sese / MT 54x, pacs / MT 202, CLS), the OTC and collateral systems, AcadiaSoft and the trade repository submissions.
4. Replace the illustrative reason codes, lifecycle event types, calculation methods and collateral types with platform values; confirm the SMPG and CFTC Part 45 code sets.
5. Apply the CD-181 row rules to the 18 Notes (Settlement Confirmed Indicator, Initial Margin Posted, Encumbered Quantity, Settled / Unsettled Quantity).
6. Agree with 25 the allocation key; with 27 the posting route for penalties, margin and OTC payments; with 28 the shared Trade Report Regime, report status and Collateral Type lists; with 29 the basket-line link and status read.
7. Register 26 in the shared lists named in proposals_26 and add the proposed Message Standard, Party Role Type and Calendar Type values.


## Stage 2 consolidation (2026-10-06)

CD-155 option A is applied: the 12 SSI and its lists were removed, and SSI- is registered to 26 (CPSI- retired). The two SSI ownership overrides were dropped, and SSI ID is a CDE. CNFM-, SETL-, CSDP-, OTC-, TAGR- and MCALL- are registered. The nine local copies of shared lists were replaced by direct citations, and the sese, colr, pacs and FpML message standards were added. Re-typing the SSI Safekeeping Account to SKA- is deferred (DP-086). See `_tools/consolidation/stage2_consolidation_notes.md` and §15 of the conventions document.

## 6. Wealth model carry-over (W1b, CW-926)

26 is kept (plan section 5.1). The overview states the boundary: 26 is fund-side settlement only (funds and institutional portfolios); clearance, settlement and custody of client trades in brokerage and advisory accounts are 49, and client money movement is 50. The pass made the four kinds of change of CW-022 only. No object or attribute is renamed; three attributes were removed (families OTC Derivative & Financing Lifecycle, whose attribute positions renumber). The decision draft, the jurisdiction entries and the readers are in `_tools/consolidation/proposals_w1b_26.py`.

**Removed (EU/UK only; 14 jurisdiction entries: EMIR 5, SFTR 8, CSDR 1).**
- Repo Trade: Repo UTI (SFTR). Derivative Trade Report: Reported Repo Trade (SFTR) and Entity Responsible for Reporting (EMIR Article 9(1d); the example named the UCITS management company or AIFM), with the relationship to the Internal Legal Entity.
- Code values: Trade Report Regime EU EMIR, UK EMIR, EU SFTR, UK SFTR (the local list keeps CFTC Part 45 and SEC Regulation SBSR; shared Regulatory Trade Report Regime, steward 26, re-cut in SHARED_RECUTS); Trade Report Action Type Early Termination (ETRM), Collateral Update (COLU) and Reuse Update (REUU) (SFTR only); Buy-In Basis CSDR Mandatory Buy-In (never in force; brief).
- Sources: EMIR and reporting RTS (EU) 2022/1855 with UK EMIR; SFTR (Regulation (EU) 2015/2365); Delegated Regulation (EU) 2016/2251 (EU uncleared margin RTS).
- Margin Rule Regulators: the example "CFTC / NFA; ESMA" now reads "CFTC / NFA; SEC" (ESMA left the shared Regulator list under CW-909; no 26 entry).

**Re-sourced.** Buy-In Notice (Buy-In Basis, Execution Date, Quantity, Price, Price Differential Amount) to FINRA Rule 11810 and Regulation SHO Rule 204 (two new source rows and two new Buy-In Basis values, FINRA Rule 11810 Buy-In and Regulation SHO Rule 204 Close-Out, which are the US instances of the list); trade reporting (Reported OTC Trade, Reported UTI, Trade Report Regime, Report Action Type, Report Event Type, Reporting Counterparty, Report Submitting Entity, Trade Repository, Report Submission Timestamp, Report Processing Status) to CFTC Part 45 and SEC Regulation SBSR; the EMIR cross-references on the OTC trade, clearing, leg and event attributes (UTI, OTC Counterparty, OTC Trade Date, Trade Side, Clearing Status, Central Counterparty, Clearing Member, Cleared UTI, Leg Number, Leg Payer, Leg Notional Amount, OTC Event Type, Resulting UTI) to CFTC Part 45; the SFTR references on Repo Trade to ICMA GMRA and SIFMA MRA; Segregation Required Indicator, Eligible Collateral Type and Concentration Limit to the CFTC margin rules and BCBS-IOSCO; Intended Settlement Date, Partial Settlement Allowed Indicator, Fail Start Date and Standard Settlement Cycle drop CSDR for SEC Rule 15c6-1, SMPG and ISO 20022. Clearing Status and Trade Report Action Type list sources name CFTC Part 45.

**Kept on purpose (investment universe, CW-022), against the brief's removal list.** The brief lists Settlement Penalty (whole object) and the CSDR, Delegated Regulations 2018/1229 and 2017/389 and UK T+1 sources for removal. They stay: the object also holds the US instance (the TMPG fails charge on Treasury, agency and agency MBS trades), and the cash penalties EU CSDs charge on every participant's fails reach the firm's international funds through their custodians whatever the firm's regulator, as foreign transaction taxes do; the EU and UK T+1 dates are the settlement cycles of foreign markets the funds trade in (the same logic as foreign calendars). The source rows are relabeled as foreign-market rules, and the penalty values are described as foreign CSD penalties. DP-151 and the 37 loss-event product (specs_e4) read Settlement Penalty. If the program lead prefers the brief, the removal is one object (10 attributes), the Penalty Type values LMFP and SEFP and four source rows; the US Fails Charge would then need a new home (see NOTES). Foreign CSD SSIs (CREST place of settlement, GB market, GBP, IBAN examples) stay.

**Perspective and re-points.** META subtitle; overview Purpose (fund-side boundary), Scope, Core model, Design principles 1 and 6, CDE, Notes (Regulation S-P, GLBA and state law in place of GDPR) and Suggested next steps 1, 4 and 5; family and group texts of Settlement Penalties, Settlement Instructions & Cycles, OTC Derivative & Financing Lifecycle and Trade Reporting; "SMA account" reads "institutional separate account" in Settlement SMA Account (name kept), Principal Account, the PII notes of Settlement Safekeeping Account, Safekeeping Account, Own Safekeeping Account and Cash Account Number, and the code values Client / Sponsor and Client Mandate; 01, 02 and 25 named with their wealth names; enrich_26 SUMMARY and the Derivative Trade Report grain.

**Additions.** None beyond the boundary sentence (brief section 4).

**Open questions (W1b).**
1. (Closed at the W1b fix pass: the program lead kept Settlement Penalty and its attribute names. Its attributes now take the generic primary reference Internal, with the market rules of the settlement venue (CSDR, TMPG fails charge, Delegated Regulation 2017/389) as secondary; Penalty Calculating CSD covers the CSD that computed a penalty or the counterparty that claimed a fails charge.)
2. Do any funds report swaps themselves (CFTC Part 45 reporting hierarchy normally puts the duty on the swap dealer), or is Derivative Trade Report only a record of the dealer's report?
3. Is any repo of the funds subject to a US reporting duty that would need its UTI (the OFR non-centrally cleared bilateral repo collection falls on covered reporters, not normally on the funds; confirm)?

**Fix pass (W1b review).** Settlement Penalty re-referenced as above; the Buy-In Basis value Regulation SHO Rule 204 Close-Out states that the close-out duty is the broker-dealer's; the READERS list in proposals_w1b_26 gained the EMIR and SFTR text readers and the sm_09 Open Collateral Disputes measure, whose 15-day EMIR dispute flag should be re-sourced by its owner (17 CFR 23.502, confirm).

**Unverified.** FINRA Rule 11810 and Regulation SHO Rule 204 URLs (patterns; confirm); the CFTC Part 45 action type labels after the removal of the SFTR values (confirm against the CFTC technical specification); OFR repo collection scope (open question 3).
