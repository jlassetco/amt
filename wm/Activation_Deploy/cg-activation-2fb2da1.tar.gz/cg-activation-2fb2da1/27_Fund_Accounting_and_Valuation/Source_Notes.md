# Source Notes: 27 Fund Accounting & Valuation

**Workbook:** `Fund_Accounting_and_Valuation_Data_Taxonomy.xlsx` (built from `_tools/content/content_27_fund_accounting_and_valuation.py`)
**Status:** Draft v0.1 after independent review, 2026-10-06; wealth model carry-over 2026-10-14 (W1b, CW-927; section 6). **Perspective:** Wealth manager (direct) | Scope: US. 9 families, 32 objects (29 business objects, 3 attribute groups), 275 attributes, 95 proposed CDEs (34.5%), 42 code lists in the workbook (31 local; Business Line and Accounting Basis cited from the shared lists), 51 relationships, 17 sources, 7 derived copies, 0 unresolved references. Personal data is limited to 5 employee references (approvers, case owner, check performer), each flagged PII.

**Why this domain exists.** Every fund the US wealth manager sponsors and runs (its own mutual funds, money market funds, ETFs and CITs) keeps its own books, from which the official NAV is struck every valuation day. That book (the accounting book of record, ABOR) is kept by fund accounting, in house or at an administrator, and is stewarded apart from the corporate ledgers of the firm (19, which by design holds no fund ledger), from the investment view of the portfolio (18) and from the client book of record of the brokerage (49). No existing domain held the fund ledger, the NAV, fund expense accruals, distribution declarations, swing pricing decisions, NAV errors or fund tax. The NAV is the price at which every shareholder order is filled (SEC Rule 22c-1), including the orders of the firm's own brokerage and advisory clients, so it is a regulated, audited output with its own error and correction regime.

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| SEC Rule 2a-4 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.2a-4 | Definition of current NAV; portfolio changes and capital stock reflected no later than the next business day (Accounting Date note); valuation at market value or fair value. |
| SEC Rule 2a-5 and release IC-34128 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.2a-5 | Boundary only: fair value determinations and the valuation designee are 22 / future 35; 27 records the determination applied. |
| SEC Rule 22c-1 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.22c-1 | Forward pricing; optional swing pricing for US funds (policies, swing threshold, swing factor, upper limit), which shaped the swing parameter and decision objects. |
| SEC swing pricing / hard close proposal (Release 33-11130 / IC-34746, File S7-26-22) | https://www.govinfo.gov/content/pkg/FR-2022-12-16/html/2022-24376.htm | Proposed November 2022 (mandatory swing pricing and hard close for most open-end funds). Not adopted; current agenda status to confirm. Context only. |
| SEC Rule 18f-3 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.18f-3 | Class-specific expenses; allocation of income, gains and common expenses by relative net assets, or settled shares / simultaneous equations for daily-dividend funds (Class Allocation Method). |
| SEC Rule 19a-1 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.19a-1 | Written statement of source when a distribution is not solely from net investment income (Section 19 Notice Required Indicator, estimated character basis). |
| SEC Rule 6c-11 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.6c-11 | Creation units and baskets behind ETF capital stock booked from 29 AP orders (Source AP Order). |
| SEC Rule 2a-7 and Form N-MFP | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.2a-7 | Amortized cost valuation, market-based NAV to four decimals, daily dividend factor. |
| SEC Regulation S-X Article 6; Form N-1A Item 13; Form N-CSR | https://www.ecfr.gov/current/title-17/chapter-II/part-210 | Statement types and captions; financial highlights (per-share data, total return, expense ratios, turnover). Filing is future 35. |
| FASB ASC 946 / 820 / 830; AICPA Audit and Accounting Guide: Investment Companies | https://asc.fasb.org (licensed) | Investment company accounting, statements, financial highlights, permanent book-tax reclassifications. Not reproduced; structure only. |
| IRC Sections 851-855 | https://www.law.cornell.edu/uscode/text/26/851 | Gross income (90%) and quarterly asset diversification (50% / 25%) tests, distribution requirement, qualified dividends, spillback (section 855). |
| IRC Section 4982 and IRS Form 8613 | https://www.law.cornell.edu/uscode/text/26/4982 | Calendar-year ordinary income and October-year capital gain excise requirements (Distribution Requirement Period). |
| IRS Form 1099-DIV, Form 1120-RIC; IRC 1091, 1092, 1212, 1296 | https://www.irs.gov/forms-pubs/about-form-1099-div | Distribution character values; book-tax difference types (wash sales, straddles, PFIC mark-to-market, capital loss carryforward). |
| OCC 12 CFR 9.18 | https://www.ecfr.gov/current/title-12/chapter-I/part-9/section-9.18 | Collective investment fund valuation (at least quarterly; admissions and withdrawals on valuation dates). CIT Unit Value Detail. |
| DTCC Mutual Fund Profile (price, rate and distribution data) | https://www.dtcc.com/wealth-and-investment-solutions/fund-solutions/price-rate-distribution-data | NAV and rate dissemination channel. |
| ICI papers on NAV errors | https://www.ici.org | US materiality practice; titles to confirm. |
| Fund accounting platforms and administrators (SimCorp, Aladdin, SS&C, State Street, BNY, Northern Trust, Citco) | https://www.simcorp.com | ABOR / IBOR split, book and NAV workflow. Structure only. |

## 2. Modeling decisions and deviations from the brief

- **Structure:** the brief's 9 families with 32 objects (brief 29 ±3): three objects were added after review, Fund Book Operating Period, Fund Book Portfolio Link and ABOR to IBOR Reconciliation. Expense Accrual is renamed Fund Expense Accrual (CD-186 naming).
- **Sibling names** were checked against the Stage 2 modules: 22 Approved Price (`PRICE-`, the 27 brief said "Security Price"), Reference Rate Fixing, FX Rate Observation (`FXR-`), Fair Value Determination (`FVD-`); 26 Settlement Instruction (`SETL-`); 28 Income Collection, Safekeeping Account (`SKA-`); 29 Fund Order (`FNDO-`), AP Creation / Redemption Order (`ECR-`), TA Control Check (`TACK-`); 30 Capital Call (`CCN-`), Distribution (`PDIS-`), Fund Credit Facility (`FCF-`), Waterfall Calculation (`DWF-`, the brief said "Distribution Waterfall Calculation").
- **NAV release vs transmission (program lead decision).** NAV Dissemination masters the release only: released NAV, release sequence, release timestamp, release status, correction flag and the corrected release. Channel, per-channel timestamp, deadline, recipient and format are 29 Price & Rate Transmission, which references the release. The object keeps the brief's name; renaming it "NAV Release" is proposed. NAV and holdings packages to insurers are 12 Report Runs (CD-193).
- **ABOR quantity is mastered here (program lead decision).** The book keeps its own quantity (Rule 2a-4 booking, as-of corrections), linked to one or more 18 portfolios through Fund Book Portfolio Link. ABOR to IBOR Reconciliation (book x portfolio x instrument x date) compares it with the 18 holding; the IBOR quantity there is a Derived copy (18). Identified cost starts from 18 lot Original Cost Base (GAAP / IFRS) or Adjusted Cost Basis Base (Tax Basis); no second lot master.
- **Typed source references on journal lines:** one attribute per source type (18 PTXN-, 26 SETL-, 29 FNDO-, 29 ECR-, 27 FDIV-, 30 CCN-, PDIS-, FCF-, DWF-), with matching Fund Journal Source Type values. Fund Journal Entry has Posting Date (distinct from Accounting Date) and an optional Related NAV Error Case.
- **Capital stock proof** is a 29 TA control; 27 only references it (Relied-On TA Control Check) and holds no proof result. Price Movement and Stale Price checks were removed (22 price validation); "Price Exceptions Cleared" is the NAV-level gate. NAV Control Check grain is NAV x check type x run sequence.
- **NAV calculation source** (Fund Accounting / Administrator / Firm Shadow) is a separate dimension from NAV Version Type (Original / Re-Strike / Restatement) and NAV Status; grain is book x valuation date x calculation source x version.
- **Effective dating:** the operating model, administrator of record and platform are on Fund Book Operating Period (book x effective period); portfolio links and swing parameters are effective-dated.
- **Distributions:** Distribution Type records income source only; daily dividends are daily declaration rows (Daily Dividend Indicator, rate held once on the declaration; the Share Class NAV daily factor was removed); spillback is an indicator; return of capital is only a character. Distribution Character keeps estimated and final rows (data basis in the grain). The UK equalization and excess reportable income attributes left at W1b (section 6).
- **Fund Financial Statement** is the statement set per book and fiscal period (statements included as Code (multi)); net assets and auditor are held once; Financial Highlights is an attribute group per class, and "Financial Highlights" is no longer a statement type.
- **Per-row ownership (plan §4 item 9):** Coupon Rate Applied (17 for fixed and step; computed for floating with Applied Rate Fixing to 22) and Fee Rate Applied (01 for flat schedules; blended breakpoint rate computed here) are flagged Derived copy with the row rule in the definition. Whole-column copies: Business Line (18), Book Reporting Currency and NAV Currency (01), Expense Cap Rate Applied (01), IBOR Quantity (18).
- **Providers of record:** 01 Product Party Role masters the administrator and auditor appointments; 27 records the administrator that kept the book in a period and the auditor that signed a statement set. Book Code is mastered here; the 18 identifier scheme holds a copy.
- **Adviser side of waivers:** Adviser Recoupment Receivable (19 Receivable Item) and Adviser Reimbursement Payable (19 Payable Invoice, to confirm as the right 19 object for non-invoice payables).
- **Swing direction** uses the shared Flow Direction list ("Neutral" = zero net activity); no local Swing Direction list.
- **Shared lists** are local copies with exact shared names and values (Record Status, Approval Status, Data Basis, Reconciliation Status, Severity, Regulator, Flow Direction, Outgoing Payment Status, Case Status), listed in SHARED_MEMBERSHIPS. Message Standard and Period Type are no longer used. Accounting Basis is a byte-identical copy of 19's list.
- **CDEs:** the five registered-prefix identifiers (NAV-, FDIV-, NEC-, SWG-, FTAX-) and FJNL- are CDEs; descriptive and operational fields were unflagged to stay within 35%.
- **Prefixes:** only `NAV-`, `FJNL-`, `FDIV-`, `NEC-`, `SWG-`, `FTAX-`; their formats are published in proposals_27 NOTES. No Record Metadata object (CD-148).

### Review response

All 61 findings of `00_Program/Expansion/Reviews/27_review.md` were applied, with these exceptions:

| Finding | Not applied / partly applied | Reason |
|---|---|---|
| E Low: nine own-object references forced by OWNERSHIP_OVERRIDES | Kept (13 own-object overrides, plus 1 forcing 28) | They resolve correctly; dropping them needs the CONCEPT_OWNERSHIP rows proposed in proposals_27, which 27 cannot edit. |
| C Low: Check Tolerance and Observed Variance typed Percentage for proofs | Not applied | Moot: capital stock and cash proofs left 27; the remaining NAV-level checks measure percentages. |
| D Low: Income Accrual composite key differs from 28's | Logged, not changed | 28 uses '<book> / <ISIN> / <date>'; 27 keeps fund / basis / INS- / date (+ income type). Needs agreement with 28 (proposals_27 NOTES). |
| I Low: rename Income Accrual / relabel Financial Statement | Partly | Expense Accrual renamed Fund Expense Accrual and Applies To relabeled "Fund Statement" / "Fund Expense Accrual"; Income Accrual keeps its name because 28 references it by name. |
| A High: NAV Dissemination object name | Name kept | The split is implemented; the object name stays as in the brief and 29 references it. Rename to "NAV Release" proposed. |
| A Medium: Adviser Payable object in 19 | Partly | 19 has no generic payable item; Payable Invoice is used and flagged to confirm. |
| D Low: CD-188 grain wording | Logged | CD text is outside 27's files; proposed in proposals_27 NOTES. |

## 3. What could not be verified

- Current status of the SEC 2022 swing pricing and hard close proposal (not adopted as of the last confirmed information; reproposal status to confirm).
- NAV error materiality: no SEC rule sets a threshold. The W1b re-sourcing to SEC staff practice and the board-approved policy (commonly 0.5% of NAV, or one cent per share, from ICI industry practice) has no single citable source; confirm with fund accounting and counsel. The example 0.50% threshold is illustrative.
- Titles of the ICI NAV error and valuation papers.
- Nasdaq Fund Network deadlines and record layout (channel value only, no URL cited).
- DTCC Profile record fields (member documentation).
- Vendor structures (SimCorp, Aladdin, SS&C, State Street, BNY, Northern Trust, Citco): public descriptions only.
- Identifiers in examples are illustrative.

## 4. Open questions for SMEs

1. Which funds and lines are accounted in house and which at an administrator (by name), and does the firm keep a shadow NAV for outsourced funds (CD-147)?
2. Is there one lot master (18 `LOT-`) used for ABOR amortized cost, or does the accounting platform keep its own lots? (ABOR quantity is now mastered here and reconciled to 18.)
3. Is shares outstanding mastered by fund accounting (capital stock booked) or by the TA register (29), with fund accounting reconciling?
4. What NAV error materiality policy does the board approve, and does it differ by fund type (MMF, ETF, CIT under the trustee's policy)?
5. Has any fund adopted swing pricing under Rule 22c-1(a)(3) (the swing objects stay generic for that case), and who sets thresholds and factors?
6. Are fund tax calculations done by fund accounting, a fund tax team or an outsourced provider, and does the firm want a single Tax domain (CD-149)?
7. Which channels receive NAVs (Profile, Nasdaq, insurers, platforms), and are corrected NAVs re-disseminated? (Transmission is modeled in 29 for every channel.)
8. For private funds, is the private markets administration system the fund ledger, or the same accounting platform as the open-end funds?
9. Are fund expense payments made by fund accounting or by the adviser's AP with reimbursement (19 Source_Notes question 13)?
10. Are financial highlights the source for 01 Cost Disclosure (expense ratios), or does 01 keep prospectus figures independently?
11. Confirm that the capital stock proof is run by the TA (29) and only relied on by fund accounting, as now modeled.
12. Do evergreen private funds strike a per-unit NAV in 27 (Share Class NAV rows), or only capital accounts in 30?
13. Tailoring question for fund tax (W1b): do the funds use tax equalization on redemptions (earnings and profits distributed to redeeming shareholders and counted toward the dividends-paid deduction, as limited since the RIC Modernization Act of 2010; confirm)? If so, where is it computed and held (a book-tax item of the Fund Tax family)? No attribute is added in W1b.

## 5. Suggested validation steps

1. Walk one daily NAV cycle with fund accounting (trades and capital stock booked, valuation, accruals, class allocation, checks, approval, dissemination) and confirm each step lands on a 27 object.
2. Map the objects to the fund accounting platform or administrator files (books, trial balance, valuation, NAV, expense, distribution and tax modules).
3. Confirm with 22 the Approved Price key and the own-share-class row rule, and with 18 the holding view used for ABOR.
4. Confirm with 29 the release / transmission split and the capital stock proof reliance, and with 10 / 13 the derived copies (CD-188, CD-189).
5. Have fund tax review the FA-FTX family and the Distribution Character list against 1099-DIV production.
6. Register the shared-list memberships and move the six prefixes to Registered at the Stage 2 consolidation.


## Stage 2 consolidation (2026-10-06)

DVD- was renamed FDIV- (one letter from 22 FVD-); NAV-, FJNL-, NEC-, SWG- and FTAX- are registered. The ten local copies of shared lists, including Business Line (CD-209), were replaced by direct citations. The Related Income Collection override was dropped. 10 Waiver Record and 13 Servicing Error amounts are derived copies of 27 (CD-188, CD-189). CD-207 records the NAV release / price transmission split. See `_tools/consolidation/stage2_consolidation_notes.md` and §15 of the conventions document.

## 6. Wealth model carry-over (W1b, CW-927)

27 is kept (plan section 5.1). The pass made the four kinds of change of CW-022 only. No object or attribute is renamed; five attributes were removed (families NAV Calculation, Swing Pricing & Anti-Dilution and Income & Distributions, whose attribute positions renumber). The decision draft, the jurisdiction entries and the readers are in `_tools/consolidation/proposals_w1b_27.py`.

**Removed (EU/UK only; 22 jurisdiction entries: Other EU/UK 14, FCA 5, UK market practice 1, UCITS 1, EU market practice 1).**
- Distribution Declaration: Equalization per Share (UK group 2 equalization, IA SORP) and Excess Reportable Income per Unit (UK reporting fund regime). Swing Pricing Parameter: Dilution Levy Rate; Swing Pricing Decision: Dilution Levy Amount (FCA COLL 6.3). Share Class NAV: Bid Price (UK dual pricing; found by the grep, not in the brief).
- Code values: Distribution Type UK Income Allocation; Distribution Requirement Period UK Reporting Period; Fund Tax Regime UK Authorised Investment Fund, Offshore Fund (UK tax), Irish Investment Undertaking, Luxembourg Subscription Tax Fund; Fund Tax Return Type UK Company Tax Return (CT600), Luxembourg Subscription Tax Return; Materiality Basis FCA COLL (UK), CSSF Circular 24/856, Central Bank of Ireland Guidance.
- Sources: FCA COLL 6.3 and 6.6; IA SORP; CSSF Circular 24/856; UCITS Directive 2009/65/EC; Offshore Funds (Tax) Regulations 2009; ALFI Swing Pricing Guidelines.
- Not recorded by 27 (no local copy; the steward 19 records them under CW-919): the EU/UK values of the shared Accounting Basis list (IFRS (EU-adopted), UK-adopted IFRS, FRS 102, Lux GAAP, Irish GAAP). The 27 note and the Identified Cost Amount definition no longer name them.

**Re-sourced.** Swing pricing (Swing Factor Method, Inflow and Outflow Swing Factor, Swing Threshold, Swing Factor Applied, the Swing Factor Method list) to SEC Rule 22c-1(a)(3): US funds may swing price, so the generic objects stay; NAV error materiality (Materiality Basis, Materiality Threshold, NAV Error Type, NAV Error Percentage, Correction Methods and their lists) to SEC staff practice and the board-approved policy, with the ICI practice row (confirm source); Valuation Date and NAV per Share to Rule 2a-4 in place of COLL 6.3; Offer Price and Swung NAV per Share drop COLL; Accounting Basis secondary reference to Regulation S-X Article 6; fund tax stays on Subchapter M (IRC sections 851-855), section 4982 and Form 1120-RIC. Regulators Notified example CSSF (a removed shared Regulator value) now reads SEC.

**Kept on purpose (investment universe, CW-022).** Foreign-currency journal lines and valuations (EUR examples), the WMR FX observation key, Tax Jurisdiction on Fund Tax Year Record (foreign taxes the funds pay), PFIC and section 988 book-tax differences, the foreign tax credit pass-through character.

**Perspective and re-points.** META subtitle; overview Purpose, Scope (no UK dilution levies or insurance-dedicated NAVs; 26 is fund-side; client holdings and client cost basis of fund shares are 49), Notes (Regulation S-P, GLBA and state law in place of GDPR; the British-spelling sentence leaves with the UK names) and Suggested next step 7; the Swing Pricing family and decision group texts; Business Line example PF (CW-004 codes; Derived copy of 18) and "Institutional separate accounts have no fund book" (also in the relationship note); 01 and 02 named with their wealth names; enrich_27 SUMMARY.

**Additions.** None (brief).

**Left for later stages (NOTES).** References to 30 (Source Capital Call, Source Private Fund Distribution, Source Credit Facility, Source Waterfall Calculation, the Fund Journal Source Type values Capital Call, Private Fund Distribution, Credit Facility and Carried Interest, the Partner Tax Allocation relationship, the Partnership tax regime note, the Scope list) for W4; insurer-facing text (NAV and holdings packages to insurers, 12 Report Runs, CD-193) for the W4 decision on insurance-dedicated funds.

**Fix pass (W1b review).** The equalization removal note no longer reads as 'no equalization in the US' (question 13 added); 47 Pricing, Fees & Billing is named in the fee boundary (Scope and Design principle 1); the stale FCA COLL 6.6 review row was removed.

**Unverified.** The NAV error materiality source (no single SEC source; confirm); the 2% upper limit of the swing factor under Rule 22c-1(a)(3) as stated in the source row (confirm against the rule text).
