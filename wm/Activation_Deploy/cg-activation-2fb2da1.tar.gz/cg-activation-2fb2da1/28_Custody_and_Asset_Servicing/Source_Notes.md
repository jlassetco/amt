# Source Notes: 28 Fund Custody & Asset Servicing

**Workbook:** `Custody_and_Asset_Servicing_Data_Taxonomy.xlsx` (built from `_tools/content/content_28_custody_and_asset_servicing.py`)
**Status:** Draft v0.1, wealth model (direct), scope US, 2026-10-14: the draft of 2026-10-06 (revised after the independent review, `00_Program/Expansion/Reviews/28_review.md`) carried over with the US-only pass, the perspective rewrite and the rename to Fund Custody & Asset Servicing of CW-928 (section 6). The workbook path and folder keep the wholesale name until the program lead moves them.

| Measure | Count |
|---|---|
| Families | 6 |
| Objects | 25 (all business objects) |
| Attributes | 226 |
| Proposed CDEs | 76 (33.6%) |
| Code lists | 34: 26 local, plus shared and external lists cited directly |
| Relationships | 35 |
| Sources | 21 |
| References | 57 |
| Derived copies | 2 |
| Ownership overrides | 4 |
| Unresolved references | 0 |
| Attributes flagged PII | 11, plus a domain-level PII rule in the Overview |

**Why this domain exists.** The firm is a US wealth manager. Its proprietary mutual funds, ETFs and CITs, and the institutional separate accounts it manages for institutional advisory clients, hold their assets at custodian banks, which in turn hold them through sub-custodians and central securities depositories in the markets the funds invest in. This is fund custody. Custody of client assets is a different business with a different rule: the firm's self-clearing broker-dealer holds its clients' securities itself under SEC Rule 15c3-3, and that book of record is 49 Clearing, Settlement & Client Asset Custody (CW-007). Fund asset servicing:

- oversees the custodians;
- reconciles the 18 portfolio holdings and cash against them;
- processes corporate actions and elections, including dividends and interest;
- controls income;
- recovers withholding tax;
- files class action claims;
- runs securities lending for the funds.

No other domain holds these records. 12 holds the custody set-up captured when an institutional mandate is opened, 17 the corporate action as announced, 18 the fund and institutional portfolio book, and 49 the client holdings. None of them holds the account at the custodian, an account's entitlement to an event, or the reconciliation break.

Custody is outsourced while oversight stays in house (CD-147). The grain is therefore the custodian's records as received, plus the firm's own control records.

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| Investment Company Act Section 17(f); SEC Rule 17f-4 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.17f-4 | Bank custody requirement and the use of US securities depositories such as DTC. Added as an assessment type after the review (the SME decides whether it is used). |
| SEC Rule 17f-5 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.17f-5 | Eligible foreign custodian, delegation to a foreign custody manager, reporting to the board. |
| SEC Rule 17f-7 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.17f-7 | Eligible foreign securities depository and the analysis of custody risks. |
| OCC 12 CFR 9.13 | https://www.ecfr.gov/current/title-12/chapter-I/part-9/section-9.13 | Custody of fiduciary assets by a national bank trustee. Basis for an internal CIT trustee self-custodying (Provider Legal Entity). |
| ISO 20022 seev, semt and camt message definitions | https://www.iso20022.org/iso-20022-message-definitions | Notification, instruction, status, confirmation and reversal messages (seev.031/.033/.034/.036/.037); statements (semt.002/.017/.018, camt.053); sub-balance types; bank transaction codes. The review confirmed the numbering. |
| ISO 15022 / SWIFT MT535-MT537, MT564-MT568, MT940, MT950 | https://www.iso15022.org | MT535 field 93a balance qualifiers. The review confirmed that the on-loan qualifier is **LOAN** (the first draft said LEND). Also the :23G: function of the message, and the SEME (message) and CORP (event) references. |
| SMPG corporate action market practice | https://www.smpg.info | Notification, instruction and confirmation flow, custodian deadline vs market deadline, market claims, default option. |
| SEC Rule 10c-1a | https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.10c-1a | Loan reporting to FINRA. The SEC order of 3 December 2025 moved compliance to 28 September 2028 (verified, and confirmed by the review). |
| ISLA GMSLA 2010 / 2018 | https://www.islaemea.org | Agreement forms, collateral, margin and recall terms (Securities Lending Agreement). |
| SEC Form N-CEN | https://www.sec.gov/files/formn-cen.pdf | Lending agent, indemnification, collateral reinvestment, revenue split. |
| Investment Company Act Section 18 | https://www.law.cornell.edu/uscode/text/15/80a-18 | Statutory basis of the one-third on-loan limit, which is an SEC staff position (see section 3). |
| Council Directive (EU) 2025/50 (FASTER) | https://taxation-customs.ec.europa.eu/taxation/business-taxation/faster-directive_en | Relief at source and quick refund. Transposition by 31 December 2028, application from 1 January 2030 (verified). |
| OECD TRACE Implementation Package | https://www.oecd.org/tax (path to confirm) | Authorized intermediary model for relief at source and reclaims. |
| IRS Form 6166 | https://www.irs.gov/individuals/international-taxpayers/form-6166-certification-of-us-tax-residency | Residence certificate filed to claim treaty relief abroad. |
| PSLRA 1995 | https://www.congress.gov/bill/104th-congress/house-bill/1058 | Plan of allocation and recognized loss. Case facts now come from the 17 event. |
| FASB ASC 946 | https://asc.fasb.org | Dividend income recognized on the ex-date, which defines the expected-income row in 27. |
| AICPA SOC 1 / ISAE 3402 | https://www.aicpa-cima.com/topic/audit-assurance/audit-and-assurance-greater-than-soc-1 | Control report received in the service review. |
| ISSA | https://www.issanet.org | Holding models and nominee structures. |
| SEC Rule 6c-11 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.6c-11 | ETF in-kind basket deliveries. |
| Vendor models (custody portals of the large global custodians, DTCC asset services, class action claims services) | https://www.dtcc.com/asset-services | Structure only. Brand names were removed from examples after the review. |
| ISO 3166, 4217, 6166, 8601, 13616 | https://www.iso.org | Formats. |

## 2. Design decisions and boundary calls

Sections 1 to 5 record the reasoning of the wholesale draft. Where they mention CASS, client money, depositaries, UCITS, AIFMD, CSDR, SFTR or SMA and mandate accounts (now institutional separate accounts), section 6 supersedes them: those objects, values and sources were removed in the wealth model.

### Accounts and providers

- **CD-194, option A.** 28 masters every Safekeeping Account (`SKA-`) for funds, portfolios and client mandates. Each account is linked to its owner by an effective-dated Safekeeping Account Assignment, with one reference per owner type.
  - Assignment rule: a fund account carries the fund (PRD-) and its main book (PORT-). An institutional separate account carries the client account (ACC-) and its book.
  - 12 keeps Custody Account (`CUA-`) as the set-up workflow, and `proposals_28.py` asks it to point to the SKA- it creates.
  - The Safekeeping Account Number is mastered here. `proposals_28.py` proposes that the 15 identifier scheme "Custodian Account Number" becomes a derived copy of 28 for institutional separate account rows; 15 was not edited.
  - **Option B** (recorded, not drafted): 12 Custody Account moves to 28 unchanged and `CUA-` becomes 28's prefix for mandate accounts.
- **One Safekeeping Account object, widened (program lead decision 4).** The object is defined as "an account or record at a custodian, sub-custodian, CASS bank or depositary in which assets or client money are held or verified". Safekeeping Account Type carries the distinctions:
  - Securities Account
  - Cash Account (at a custodian)
  - **Bank Deposit Account** (new: CASS client bank accounts and fund operating accounts at a bank)
  - Collateral Account
  - Ownership Verification Record

  I did not split CASS bank accounts into their own object, because their attributes (provider, number, IBAN, currency, status, dates) are the same. The differences are covered by the type and by Client Asset Designation.
- **Self-custodying CIT trustees (decision 7).** Custody Provider Profile has a Provider Party (02) / Provider Legal Entity (09) pair, and Safekeeping Account has an Account Provider / Internal Account Provider pair. In each pair exactly one is filled.
- **Prudential Regulator removed.** The regulator of a provider is read from 02 Organization "Primary Regulator". The local Regulator list was dropped as a result.
- **01 consistency check.** The Account Provider of a fund's main account must equal the custodian or depositary appointed in 01 Product Party Role. 01 holds the appointment and 28 holds the accounts.

### Corporate actions and income

- **Event in 17, processing in 28 (CD-195).** Only per-account facts are held here.
  - The Notification Receipt is now one custodian message, identified by its Custodian Message Reference (SEME), with a Notification Function (new, replacement, reminder, cancellation).
  - The Payment is identified by its Payment Confirmation Reference.
  - The Entitlement grain is event x safekeeping account x entitled portfolio, so an omnibus account serving several portfolios is covered.
  - The Election Instruction Status list now runs through the whole instruction lifecycle, from the firm's draft to execution in the market, and includes Defaulted. Draft and Sent are the firm's states, and Accepted by Custodian and Executed are separate values. The Default Applied Indicator was dropped.
- **Income recorded once (review High, decision 1).**
  - Corporate Action Payment holds income received (Paid Net Amount) and tax withheld (Withholding Tax Amount) for dividends and coupons.
  - Income Collection is the control record, one per income entitlement. It holds the 27 expectation (Expected Income Accrual, Expected Net Income Amount as a derived copy of 27), the Received Payment reference, the difference and the claim status. It no longer holds a received amount, instrument or account.
  - Withholding Tax Reclaim references the Source Payment and no longer holds a withheld amount.
  - **Row rule:** every Income Collection row has a 17 event, so Income Due Date is a derived copy of 17 for every row. Income without a 17 event is not controlled here until 17 announces it.
- **Expected income (decision 5).** 27 has no separate "declared entitlement" object; its Income Accrual is daily. Expected Income Accrual therefore names the accrual row booked on the ex-date (dividends) or the payment date (interest). The expected net amount is that row's Accrued Income Balance less its Withholding Tax Accrued Amount.
  - The relationship now reads "Income Collection is expected by Income Accrual [27], 1 : 0..n", which matches 27's "n : 0..1".
  - `proposals_28.py` asks 27 to add an income receivable record if it wants one, so that 28 can reference it.
- **Class actions (decision 3).** Class Action Claim references the 17 Corporate Action Event of type Class Action (CLSA), which carries the case facts. The claim keeps only its own facts: fund or client account, eligible purchase quantity, recognized loss, filing agent, filed date, opt-out, status and recovery. Case name, jurisdiction, class period, settlement class instrument and filing deadline were removed and proposed to 17.

### Reconciliation, lending and CASS

- **Reconcile, do not remaster (CD-196, CD-146).** A break holds only the signed differences. Custody Break Type values are now mutually exclusive: Quantity Difference means both sides hold the instrument. Timing Difference excludes settlement causes. The Related AP Order is kept as a shortcut, with a note that it is also reachable through the 26 settlement instruction (CD-183).
- **Securities lending (CD-182, CD-198).** 28 now masters the **Securities Lending Agreement**, keyed lending program x agent x counterparty. It covers both the authorization agreement (no counterparty) and the master agreements with borrowers (GMSLA, MSLA), and it holds the agreement type, eligible collateral, minimum margin, indemnification, document reference, status and dates. Securities Loan references its governing agreement.
  - The text attribute Program Agreement Reference and the list Lending Agreement Framework were removed. The list became Lending Agreement Type.
  - Custody and depositary agreements stay a document code until 39 exists.
- **Grains (decision 6).** The three former attribute groups are now business objects:
  - Client Asset Designation: account x effective period.
  - Lending Collateral Received: loan or borrower pool x collateral item x mark date.
  - Loan Regulatory Report: loan x regime.

  Securities Loan carries a Loan Mark Date for Loan Value and is declared current state.
- **CASS designation once.** It is held on Client Asset Designation. Account Holding Model uses Custody Holding Model, limited by a note to Omnibus and Individual Client Segregated. Direct Holding and Nominee are market-level values, and the nominee is Registered Nominee.

### Lists and ownership

- **Shared lists.** 28 defines local copies of eight enterprise shared lists, with their exact names and values: Record Status, Approval Status, Case Status, Reconciliation Status, Severity, Risk Rating, Data Basis and Message Standard. Message Standard adds the proposed values "ISO 20022 seev" and "ISO 20022 camt". All eight are listed in `proposals_28.py` SHARED_MEMBERSHIPS.
- **List renames (decision 2).** Four local lists were renamed to avoid colliding with same-named lists in 06, 13 and 16, and the renames are proposed as LOCAL_RENAMES:
  - Break Type → Custody Break Type
  - Holding Model → Custody Holding Model
  - Reclaim Status → Tax Reclaim Status
  - Loan Status → Securities Loan Status

  The On Loan balance code was corrected from LEND to LOAN.
- **Ownership overrides.** Four 28 lending references are forced to "mastered here", because their composite example keys begin with PRD- / PTY-.

### Deviations from the brief

1. There are 29 objects, all business objects, against the brief's 28 (25 BO, 3 AG): Securities Lending Agreement was added (CD-182), and the three AGs became business objects after the review.
2. There are 31 local code lists against the brief's 20-28. Lists beyond the brief §8 list:
   - Custody Service Type
   - Service Review Outcome
   - Foreign Custody Assessment Type
   - CASS Account Designation
   - Lending Agreement Type
   - Loan Reporting Regime
   - Loan Report Status
   - Acknowledgment Letter Type
   - Notification Function
   - Custody Holding Model (in place of the brief's Holding Model)
3. Frequency and Regulator (named in the brief's shared lists) are not used.
4. The brief's Income Collection grain (instrument x account x payment date) was changed to the income entitlement, and the brief's Tax Relief Documentation status uses the shared Approval Status.
5. The 26 reference uses the 26 Settlement Instruction (`SETL-`), as named in the 26 brief and draft.
6. Registered Nominee and Client Money Bank (provider role) were added.

### Review response

Every High and Medium finding was applied. Low findings applied: Maximum On-Loan Percentage marked provisional (future owner 01); Related AP Order note; internal reporter and assessor note; Default Applied Indicator dropped; Market Sub-Account removed and collateral purposes noted; Statement Message Standard dropped; Break Type and Root Cause made exclusive; Lending Agreement Type fixed; Relief Form made Text; Entitled Cash Amount defined as a total; examples fixed; assignment rule added; CASS wording aligned; entitlement, holding line, statement and revenue grains; review role added; domain-level PII note; Revenue Data Basis note; "Other" values added; Rule 17f-4 added; CDE placement adjusted.

Findings not applied, or applied differently:

- **Income Claim Status (F, Low).** I defined the sequence of values in their descriptions instead of splitting the list. That avoids a 32nd local list, and the values form one control lifecycle.
- **Holding Model on the account (B, Medium).** I restricted the values by a note instead of creating a separate Account Segregation Type list, again to avoid another local list.
- **Local list count (F, Low).** The deviation note is updated, but the count was not reduced (31). The added lists are each needed by an attribute.
- **Investment Company Act Section 18 source (G, Low).** It now points to the statute rather than the sec.gov home page. The SEC staff no-action letters behind the one-third limit could not be located and verified in this session (web search was unavailable), so they are not cited.
- **OECD TRACE URL (G, Low).** Still the general OECD tax page, because the package path could not be verified.
- **Remaining sub-balance codes (F, Medium, second part).** Only LOAN was corrected. The other MT535 / semt.002 codes remain unverified against the usage guidelines (section 3).
- **The four "no action" Lows** (shared-list copies, size, source spot-checks, business-line coverage) needed no action.

## 3. What could not be verified

- **ISO sub-balance codes.** Apart from LOAN, which the review confirmed, the codes (AWAS, BLOK, BORR, COLI, COLO, PLED, PEND, PENR, REGO) and the :23G: function codes (NEWM, REPL, REPE, RMDR, CANC, WITH) are from working knowledge. Confirm them against the MT535, MT564 and semt.002 usage guidelines.
- **CASS rule references.** The following are cited at chapter level: CASS 7.17 (statutory trust), the standard method, the acknowledgment letter templates (including whether a CASS 6 custodian equivalent exists) and the delivery-versus-payment exemption.
- **OECD TRACE URL path.**
- **One-third on-loan limit.** This is an SEC staff position; the letters were not located.
- **OCC 12 CFR 9.13** applies to national bank trustees. State-chartered trustee banks follow state rules.
- **Sibling object names** are taken from the 22, 24, 26, 27 and 29 drafts or briefs: Approved Price, Investment Decision, Settlement Instruction, ABOR Valuation Record, Income Accrual, Fund Journal Entry, AP Creation / Redemption Order.
- **Examples** are illustrative.

## 4. Open questions for client SMEs

1. Which custodians serve which funds and business lines? Is any custody insourced, for example a CIT trustee bank acting as its own custodian?
2. Custody account ownership (CD-194): option A or option B?
3. For institutional separate accounts held at the client's custodian, does the firm or the custodian run the master reconciliation?
4. Who makes voluntary corporate action decisions, and where are they recorded?
5. Withdrawn (W1b): the firm has no UK CASS entity; the US customer-protection record is 49's.
6. Is securities lending run by the custodian as agent or by a third-party agent? Which funds lend, and who will be the Rule 10c-1a reporting party?
7. Who files class action claims, and are claims filed for institutional separate account clients (retail clients are 49's)? Should 17 hold the case facts as proposed?
8. Are withholding tax reclaims tracked in house or only in custodian reports? Does any market require one filing for several payments?
9. Should Tax be one domain (CD-149)?
10. Withdrawn (W1b): no AIFMD funds.
11. Does the firm receive sub-custodian-level statements?
12. Withdrawn (W1b): no EU entity.
13. Should income that has no 17 event (for example, a custodian credit with no announcement) be controlled in 28 before 17 creates the event?
14. Should Rule 17f-4 depository use (DTC) be assessed alongside Rules 17f-5 and 17f-7?

## 5. Recommended next steps

1. Decide CD-194 with 12. Then apply the 12, 15 and 18 changes listed in `proposals_28.py` CHANGES_TO_OTHER_DOMAINS.
2. Agree with 27 the expected-income row, or a new income receivable record.
3. Agree with 17 the class action case facts.
4. Map statements, notifications, instructions and confirmations to each custodian's message guides, and confirm the codes.
5. Withdrawn (W1b): CASS content removed.
6. Have fund tax review the relief methods and reclaim filing practice.
7. At consolidation, register the eight prefixes, the shared-list memberships and the LOCAL_RENAMES.


## Stage 2 consolidation (2026-10-06)

CREC- was renamed CUREC-, CAEL- ELECT- and SCA- SCAC-; SKA-, CAEN-, WHTR-, SBL- and CMC- are registered. CD-194 option A is applied: 12 Custody Account, 15 Account Identifier and 18 reference or copy the 28 Safekeeping Account. The eight local copies of shared lists were replaced by direct citations; seev and camt were added to Message Standard. See `_tools/consolidation/stage2_consolidation_notes.md` and §15 of the conventions document.

## 6. Wealth model carry-over (W1b, CW-928)

28 is kept and renamed **Fund Custody & Asset Servicing** (plan section 5.1). The pass made the four kinds of change CW-022 allows: the US-only pass, the perspective text, the wording around the books of record (CW-007), and the rename with its boundary sentence. Names of kept objects and attributes are unchanged, because DP-167, DP-172, DP-173 and DP-174 and their models read 28 by name. The decision draft, the jurisdiction entries and the readers of the removed objects are in `_tools/consolidation/proposals_w1b_28.py`.

**Boundary (CW-007).** 28 holds fund assets: the custody of the firm's mutual funds, ETFs, CITs and institutional separate accounts at custodian banks, and the oversight of that custody. Custody of client assets at the firm's self-clearing broker-dealer, meaning customer securities in its possession or control, the reserve computation and the client holdings under SEC Rule 15c3-3, belongs to 49 Clearing, Settlement & Client Asset Custody. Retail brokerage, retirement and managed accounts have no safekeeping account in 28. Corporate actions and class action claims on client holdings are 49's too. The rename is in META. The overview, the family texts of Custody Network, Safekeeping Accounts and Corporate Action Processing, and the definitions of Safekeeping Account, Owning Client Account, Class Action Claim and Claiming Client Account all state the boundary.

**Removed (EU/UK only; 44 jurisdiction entries: CASS 31, AIFMD 5, UCITS 4, SFTR 3, CSDR 1).**
- The Client Assets & Money family (CU-CAS) as a whole: Client Money Calculation, CASS Acknowledgment Letter, CASS Firm Profile. The US customer-protection record is 49's, under Rule 15c3-3, and is not rebuilt here.
- Client Asset Designation (Safekeeping Accounts). It was the last object of the family, so no attribute ID of a kept object moved.
- Local lists CASS Account Designation, Client Money Calculation Method, Acknowledgment Letter Type, Acknowledgment Letter Status, CASS Firm Classification.
- Values: Custody Reconciliation Type (the two CASS external reconciliations); Foreign Custody Assessment Type (UCITS and AIFMD delegation due diligence, CASS 6 third-party custodian review); Loan Reporting Regime (EU SFTR, UK SFTR); Custody Provider Role (Depositary, Client Money Bank); Custody Service Type (Depositary Oversight, Ownership Verification); Safekeeping Account Type (Ownership Verification Record); Custodian Statement Type (Depositary Ownership Verification Statement).
- Sources: CSDR, FCA CASS 1A / 6 / 7, UCITS V depositary rules, AIFMD Article 21, EU / UK SFTR. Four relationships went with the removed objects.

**Re-sourced.**
- Foreign Custody Assessment and its type list now rest on Investment Company Act Section 17(f) and SEC Rules 17f-4, 17f-5 and 17f-7. The secondary UCITS and AIFMD references were dropped from Custody Provider Role, Sub-Custodian, Foreign Custody Assessment Type, Eligibility Decision, Owning Fund and Safekeeping Account Type.
- Securities lending reporting now rests on SEC Rule 10c-1a: Loan Regulatory Report, Loan Reporting Regime, Reported Loan, Reporting Party, Unique Transaction Identifier, Loan Report Status, Loaned Instrument, Loan Quantity and Lending Collateral Type. Loan Reporting Regime keeps one value, SEC Rule 10c-1a, because the grain is loan x regime and the list is a member of the shared Regulatory Trade Report Regime. The Unique Transaction Identifier now holds the loan identifier FINRA assigns (confirm format). Loan and collateral marks (Loan Value, Loan Mark Date, Collateral Mark Date, Collateral Value) cite the ISLA GMSLA. Collateralized Loan, Collateral Pool Borrower, Collateral Instrument and Tri-Party Agent are Internal.
- Holding models (Custody Holding Model, Market Holding Model, Account Holding Model) moved from CSDR Article 38 to ISSA market practice. The CSDR secondary reference was dropped from Securities Depository and Market Claim Indicator, and the FCA CASS 6 secondary from Custody Reconciliation Type and Signed Off By.

**Kept on purpose (investment universe, CW-022).** Kept: foreign sub-custodians and depositories, including the ICSD value naming Euroclear Bank and Clearstream Banking; market holding models; foreign-currency cash accounts and IBANs (the example is now a German sub-custodian account); withholding tax relief documentation and reclaims; the EU FASTER Directive, which is the relief procedure of EU source countries for income on EU securities the international funds hold; the OECD TRACE package; the ISLA GMSLA, a market-neutral lending agreement whose English governing law is a legal fact; and the Opt-Out Indicator's non-US collective action.

**Perspective rewritten.**
- META title and subtitle.
- Overview: Purpose, Scope, Core model, Design principles (new 6: fund assets here, client assets in 49; new 10: the custody universe is global), Applies To, CDE, Notes (GDPR replaced by Regulation S-P, GLBA and state privacy law) and Suggested next steps (the CASS step is replaced by the 28 / 49 boundary with the 49 drafter).
- "SMA or mandate account" now reads "institutional separate account" (IA line, CW-009). "Custodian or depositary" now reads "custodian" or "securities depository".
- SUMMARY in `enrich_28.py`.

**Re-pointed.** "02 Client & Customer" now reads the 02 party core (CD-143). No Reference type changed: Party and Account keep their names (CW-021).

**Added.** Nothing beyond the rename and the boundary sentence.

**Open questions (W1b).**
1. Does 49 model the broker-dealer's own accounts at DTC and its banks (customer securities, the Special Reserve Bank Account) on the 28 Safekeeping Account pattern, or in 49 alone? The answer sets whether SKA- gains an owner type for the broker-dealer.
2. Who files class action claims for retail clients: 49 (client holdings) or the firm's claims filer through 28? This draft assigns them to 49.
3. DP-175 (Client Money & Client Assets) reads only removed objects. Retire it at WP0, or re-scope it to the 49 Rule 15c3-3 reserve and possession-or-control controls?

**Review fix pass.** Bare "position" and "holding" now name the books of record (18 Portfolio Holding, 49 Client Holding, 06 Fund Shareholder Position). Tax Relief Method takes OECD TRACE as primary and FASTER as secondary. Custody Provider Role takes Investment Company Act Section 17(f) as primary. The Rule 17f-4 assessment value is marked optional. Loan Reporting Regime is a deliberate one-value list (recorded in CW-928 for CW-039). Unique Transaction Identifier keeps its name but now holds the FINRA-assigned identifier (REPOINTS in `proposals_w1b_28.py`).

**Unverified.** The status of Rule 10c-1a (confirm): the Fifth Circuit remanded the rule to the SEC in August 2025, and the SEC's December 2025 exemptive order deferred reporting to 28 September 2028 and public dissemination to 29 March 2029. Whether the FASTER Directive's relief-at-source and quick-refund procedures are open to US-resident beneficial owners such as the funds (confirm). The format of the FINRA-assigned loan identifier under Rule 10c-1a (SLATE) used in the Unique Transaction Identifier example (confirm); whether Rule 10c-1a reports the type of collateral, cited as the secondary reference of Lending Collateral Type (confirm against 17 CFR 240.10c-1a(e)).
