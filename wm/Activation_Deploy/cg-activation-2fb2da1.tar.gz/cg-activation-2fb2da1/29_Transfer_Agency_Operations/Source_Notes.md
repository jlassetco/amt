# Source Notes: 29 Transfer Agency Operations (Draft v0.1, W3 wealth adaptation, 2026-10-15)

Workbook: `Transfer_Agency_Operations_Data_Taxonomy.xlsx` (name and folder kept). Content module: `_tools/content/content_29_transfer_agency_operations.py` (adapted in place; wholesale version at tag `wholesale-v1.0`). Enrichment: `_tools/enrichment/enrich_29.py`. Proposals: `_tools/consolidation/proposals_w3_29.py` (the Stage 2 `proposals_29.py` is kept unchanged).
Size (built): 7 families, 27 objects (21 business objects, 6 attribute groups), 279 attributes, 95 CDEs (34%), 41 code lists in the workbook (31 local, 10 shared lists cited directly; Order Settlement Method shows as the shared Fund Dealing Settlement Method), 60 relationships, 23 sources. Ownership: 61 references, 8 derived copies, 7 row ownership rules, 0 unresolved (after the review fix pass). Wholesale baseline: 6 families, 22 objects, 230 attributes, 78 CDEs, 39 code lists, 42 relationships, 21 sources.

**Perspective.** Wealth manager (direct) | Scope: US. A hypothetical US wealth manager of the Vanguard type (CW-004 lines DB, DA, HA, PF, WR, IA, IC, TR). The transfer agent is in house (registered under Exchange Act section 17A, Form TA-1); own funds held by brokerage clients sit in the self-clearing broker-dealer's omnibus account at the TA; fund-only accounts stay open but take no new openings (15 default).

## 0. Why this domain exists, and what the adaptation changed

The transfer agent is the fund complex's registrar. It receives and prices every order in the firm's own mutual funds and CITs, keeps the register of who holds how many shares, settles dealing money with the broker-dealer, NSCC and intermediaries, processes authorized participant orders for the ETFs, and runs the daily controls that prove the register to fund accounting. The wholesale 29 served intermediaries and EU platforms and left the register to 06. In the wealth model most own-fund shares sit in one broker-dealer omnibus account per share class, fed by aggregated client orders from 48 (CW-097). The rest are legacy fund-only, intermediary omnibus and networked, plan omnibus and institutional direct accounts, plus the ETFs' DTC nominee account. 29 keeps order processing and now masters the register itself (the Rule 17Ad-10 securityholder file). 06 reads that register as the Fund Shareholder Position view for accounts the broker-dealer does not carry (CW-122).

| Wholesale object | Disposition | What changed |
|---|---|---|
| Fund Order (`FNDO-`) | Kept, re-cut | Order Account re-cut to the 15 account types. Resulting Transaction re-typed to Reference (Register Transaction, 29) (CW-122). Order Origin loses Insurance Company Instruction (out of scope, CW-004) and gains Affiliated Broker-Dealer Omnibus and Cash Sweep Run. Cut-Off Result loses its FCA COLL reference |
| Order Routing Detail | Kept, re-cut | Platform Order Reference removed (CW-929). Dealing Route becomes a local copy with the US values plus Affiliated Broker-Dealer Omnibus |
| As-Of Order Detail, Order Event, Order Exception, Exchange Link | Kept | As-Of Reason gains Broker-Dealer Aggregation Error. The Allfunds example code was removed |
| *New:* Brokerage Omnibus Order Detail | Added (AG of Fund Order) | Aggregation date and cycle, client order count, purchase and redemption totals (Derived copies of 48), side netting indicator (CW-097, CW-123) |
| Settlement Obligation, Intermediary Settlement Batch (`FBAT-`), Settlement Exception | Kept | Order Settlement Method re-cut (Calastone and ICSD removed, Affiliated Broker-Dealer Omnibus Settlement added). Obligation Amount is now mastered here (the Register Transaction net amount), no longer a Derived copy of 06. Return Reason Code gains a row rule for returned client payments (50) |
| Cash Movement | Kept, re-cut | Fund-side settlement only. Investor Bank Instruction replaced by Client Money Movement (Reference (Money Movement, 50), CW-107). Payment Method values cut to the US rails |
| AP Creation / Redemption Order (`ECR-`), AP Order Fee, Basket Settlement Line | Kept | AP Resulting Transaction re-typed to Register Transaction (CD-200 amended by CW-122). AP Agreement stays Reference (Agreement) to 05 until W4 |
| CIP Verification (`CIP-`) | Removed | 02 Identity Verification (`KYCV-`, CIP Program "Mutual Fund CIP"), read through 15 Account Opening (CW-025, CW-124). `CIP-` is retired. Its five lists left with it |
| *New:* Share Register Balance | Added (TA-REG) | Registered account x share class x business date: registered, collected, uncollected, escrowed or pledged and restricted shares; register account category; last register transaction; register keeper. No value |
| *New:* Register Transaction (`RGTX-`) | Added (TA-REG) | The Rule 17Ad-10 posting: type, account, share class, trade, settlement and posting dates, shares and direction, NAV record and price applied, gross amount, sales charge, redemption fee, tax withheld, net amount, originating fund order, AP order or 27 distribution declaration, Fund Share Transfer counter account, status, reversal link |
| Intermediary Distribution Request (`BOD-`), NOBO List Request | Moved in from 13 (CW-088) | Placed in TA-REG. Attributes and lists kept; on receipt Holding Model became Beneficial Owner Holding Model and Beneficial Owner Position Count became Beneficial Owner Account Count (13 fix-pass instruction; W0 term ruling) |
| Account Monitoring Alert (`AMA-`), Alert Disposition | Kept, re-cut | Covers dealing-triggered alerts. Adds Triggering Money Movement (50). Payment scenarios and the check / ACH fraud category moved to 50 (CW-123). JMLSG and UK OFSI references removed |
| Shareholder Information Request | Kept | Rule 22c-2. Related Frequent Trading Case still references 08 (`FTC-`) |
| TA Control Check (`TACK-`), TA Control Exception, TA Processing Calendar Event | Kept | Capital Stock Proof sums Share Register Balance. Dealing Suspension re-sourced to Investment Company Act section 22(e) |
| Servicing Provider Engagement | Moved in from 13 (CW-088; amends CD-202) | Placed in TA-OVS. Adds Engagement Start and End Date, Oversight Review Period End Date, Latest SOC 1 Report Date and Provider Service Levels (13 `SVL-`). Servicing Provider Role gains Sub-Transfer Agent |
| Order Interface Session, Price & Rate Transmission | Kept | NAV Dissemination Channel loses Insurer Feed (out of scope) and gains Broker-Dealer Pricing Feed. The transmission keys follow the 27 release key (NAV- / release sequence) |

Families: Investor Identity & Financial Crime became **Shareholder Account Monitoring** (TA-FCC kept), and TA Controls became **TA Controls & Oversight** (TA-OVS kept). **Shareholder Register** (TA-REG) is new.

## 1. Sources consulted

| Source | URL | What was taken |
|---|---|---|
| SEC Rule 22c-1 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.22c-1 | Forward pricing, designated-agent receipt (the broker-dealer for its omnibus orders); register trade date and price |
| SEC Rule 22c-2 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.22c-2 | Shareholder information agreements; redemption fees retained by the fund |
| SEC Rule 6c-11 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.6c-11 | AP orders, baskets, cash component |
| Investment Company Act section 22(e) | https://www.law.cornell.edu/uscode/text/15/80a-22 | The seven-day payment rule and its exceptions (exchange closure or restricted trading, emergency, SEC order): Dealing Suspension only. Uncollected Shares rests on the prospectus and fund policy, not the statute |
| SEC Rules 17Ad-10 and 17Ad-4(a) | https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.17Ad-10 | Securityholder file postings and control book: Share Register Balance, Register Transaction, capital stock proof. 17Ad-10 applies to the funds' recordkeeping TA; 17Ad-4(a) exempts fund shares only from 17Ad-2, 17Ad-3 and parts of 17Ad-6, and the 17Ad-10(a)(2) posting extensions exclude them (verified at the review) |
| Exchange Act section 17A and Form TA-1 | https://www.sec.gov/files/formta-1.pdf (form title and 084- file-number format to confirm) | Transfer agent registration number on Servicing Provider Engagement; Register Keeper |
| SEC Rules 14a-13 and 14b-1 | https://www.ecfr.gov/current/title-17/chapter-II/part-240 | Broker search, beneficial-owner counts, NOBO lists |
| SEC Rule 38a-1 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.38a-1 | Oversight of the TA and its service providers |
| FinCEN 31 CFR Part 1024 | https://www.ecfr.gov/current/title-31/subtitle-B/chapter-X/part-1024 | Mutual fund AML program and SAR confidentiality (1024.320(e)); the CIP (1024.220) now applies through 02 |
| FINRA Rules 3310, 2165, 2341 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/3310 ; .../2341 | AML program; Rule 2165 holds; sales charges on Register Transaction |
| OFAC SDN list | https://ofac.treasury.gov | Sanctions screening of fund-side counterparties and shareholders |
| IRC sections 3406, 3405 and 1441 | https://www.law.cornell.edu/uscode/text/26/3406 | Backup, IRA-distribution and foreign-person withholding (Tax Withheld Amount) |
| DTCC NSCC Fund/SERV, DCC&S, Networking, Mutual Fund Profile Service | the existing deep links (verified at Stage 2) | Routes, control numbers, money settlement, networking levels, price and rate file |
| DTCC NSCC Omni/SERV | https://www.dtcc.com/wealth-management-services/mutual-fund-services/omni-serv | Omnibus sub-account records (Register Account Category Intermediary Omnibus) |
| ISO 20022 setr | https://www.iso20022.org/iso-20022-message-definitions | Order, status and switch messages (market-neutral, kept) |
| NACHA Operating Rules | https://www.nacha.org/rules | Return reason codes |
| AICPA SOC 1 | https://www.aicpa-cima.com/topic/audit-assurance/audit-and-assurance-greater-than-soc-1 | Service organization reports in provider oversight (moved with the 13 object) |
| SS&C DST TA2000 (structure only) | https://www.ssctech.com (product page to confirm) | Order lifecycle, collected and uncollected shares, daily TA controls |
| ISO 4217 / ISO 8601 | https://www.iso.org | Formats |

Removed under CW-929: the Calastone source, the Clearstream Vestima, Euroclear FundSettle and Allfunds source, FCA COLL 6.2, 6.3 and 7.2, UK MLR 2017 and JMLSG, and the UK OFSI part of the OFAC source. The 31 CFR 1010.230 source (CDD beneficial owners) left with CIP Verification, which was its only user; it is not a jurisdiction item.

## 2. Design and boundary decisions

- **The register is 29; the views are elsewhere (CW-122).** Share Register Balance and Register Transaction are the TA's books of record for every account registered at the TA. Neither is named or described as a Holding or Position, and neither carries a market value. 06 Fund Shareholder Position is a view: of 49 Client Holding for brokerage accounts, and of Share Register Balance for every other registered account. The Shareholder Register family definition names Client Holding (49), Portfolio Holding (18) and Fund Shareholder Position (06).
- **One omnibus balance, many client holdings (CW-097, CW-122).** Own-fund client orders are aggregated into one Fund Order per share class and dealing cycle on the broker-dealer omnibus account. The client-level link is on the 48 Order Route (Resulting Fund Order). Brokerage Omnibus Order Detail holds only Derived aggregate copies and copies no client quantity. 49 Stock Record Reconciliation reconciles 49 to 29.
- **Instruction, order, posting.** The client instruction is 48 (brokerage) or the 13 request (fund-only). The 29 Fund Order is the dealing instruction as received. The 29 Register Transaction is the confirmed posting. Fund Order.Resulting Transaction and AP Resulting Transaction keep their names for their readers. The settlement amount of a fund order is the Register Transaction net amount, mastered in 29.
- **Dealing money here, client money in 50 (CW-107).** Cash Movement is the fund-side entry against the 28 safekeeping cash account. For a fund-only shareholder it references the 50 Money Movement, and Payment Reference and Payment Method stay blank. Returned client payments copy the 50 return reason (ROW_OWNERSHIP).
- **No identity data (CW-025, CW-124).** CIP Verification and its five lists were removed. 29 holds no verification method, document or result.
- **Monitoring split (CW-123).** 29 alerts on dealing in shareholder accounts. Alerts on a payment alone are 50 Money Movement Monitoring Alerts (`MMALT-`). The program, cases and SARs are 38; frequent trading cases are 08. SAR confidentiality handling is unchanged.
- **Register Account Category** is constant per account. It is kept on the balance so that the 06 view and the 49 reconciliation select rows without re-deriving it from 15; the 15 Account Type map is a row rule (ROW_OWNERSHIP). By ruling, 15 adds Direct Institutional Fund Account, DTC Nominee Account and CIT Unitholder Account at the merge; 15 Institutional Separate Account does not map to Institutional Direct. CIT unit registers follow the trust company's recordkeeping agreement, not Rule 17Ad-10.
- **The omnibus balance is not a Fund Shareholder Position (ruling on CW-122).** 06 excludes the Broker-Dealer Omnibus Share Register Balance from its view and from Client Assets; the 49 look-through Client Holdings are the positions, and 06 checks omnibus units = sum of 49 Client Holdings as a control.
- **Resolved dealer and rep are mastered here.** 29 resolves the delivered dealer and rep codes from the Fund/SERV and Networking feed fields; 06 copies them (the earlier copy from 06 was circular).
- **Aggregated omnibus orders.** Order Received Timestamp is the broker-dealer's attested aggregation cut-off; per-client Rule 22c-1 receipt evidence stays on the 48 Client Order. The aggregates copy 48 for broker-dealer rows and the 50 Sweep Run allocations for sweep rows (row rule by Order Origin).
- **Postings.** Register Transaction Status is posting state only (Pending Posting, Posted, Reversed, Corrected); settlement state is read from the Settlement Obligation. As-Of Posting Indicator lets 06 read the as-of. Escheatment Delivery, Reorganization In / Out and Register Adjustment postings carry no originating order or declaration.
- **Special category (CD-344).** Account Monitoring Alert and Alert Disposition rows of category Fraud - Elder Financial Exploitation, or whose disposition places a FINRA Rule 2165 hold, are special category with a restricted view, as 15 Account Restriction and 50 Hold Reason mark the same facts. Diminished-capacity observations belong in 02 Vulnerability Concern, never in the rationale.
- **Lots.** The cost basis of fund-only accounts is held in 49 Client Tax Lots (CW-034), which Register Transactions open and relieve. The register holds shares only.

**Deviations from the brief:**
1. The proposals file is `proposals_w3_29.py`, not `proposals_29.py`.
2. Investor Bank Instruction was removed rather than kept beside Client Money Movement. CW-107 says the Cash Movement references the money movement "instead of holding the investor bank instruction".
3. Register Account Category adds Institutional Direct and Firm Proprietary to the seven CW-122 values.
4. Two received 13 attributes were renamed on receipt (the 13 fix-pass instruction).
5. Servicing Provider Engagement has five added attributes.
6. Monitoring lists lost their payment values.
7. Order Origin adds Cash Sweep Run, for the 50 brief's sweep fund orders.

**Sibling and future references:**
- 48: Client Order, Order Route (Derived copies only).
- 49: Client Tax Lot, Stock Record Reconciliation, Street Settlement Obligation (REL lines; the links are held on the 49 side as Reconciled Register Balances and Own-Fund Settlement Obligation).
- 50: Money Movement, as `Reference (Money Movement, 50)` with the `MMVMT-` example; Sweep Run (REL and list value).
- 16: Payroll Contribution Batch, Participant Ledger Posting (REL).
- 27: Distribution Declaration (`FDIV-`).
- 13: Service Level Definition (`SVL-`).
- 06 (W4) and 05 (W4) are referenced by name.

## 3. Unverified items (confirm)

- The SEC staff position on delaying redemption payment until a purchase payment is collected, and the hold period stated in the prospectus (Uncollected Shares).
- The Form TA-1 title and file-number format, and the SS&C TA2000 product page.
- The Fund/SERV transaction code behind each Register Transaction Type value (no public code list found).
- Shared Networking Level wording (steward 15): DTCC lists levels 0, 3 and 4; Level 1 to be dropped at the merge.
- The DTCC cycle names behind Interface Cycle and Omnibus Aggregation Cycle.
- The Register Transaction Type values against the Fund/SERV transaction codes.
- Monitoring Scenario values. They are industry typologies, not a regulatory list.
- FINRA Rule 2165 hold length (SR-FINRA-2026-018 pending, as noted in 15).

## 4. SME questions (tailoring levers; reference default in brackets)

1. **In-house or outsourced TA?** [In house.]
   - Lever, outsourced: the register becomes a received record from the provider (Register Keeper names it).
   - Servicing Provider Engagement grows to cover the outsourced TA: SLAs, SOC 1 reliance, and Rule 38a-1 oversight.
   - Processing Provider is filled on every order and control.
   - The firm may need a received copy of CIP results (the CW-025 exception).
2. **Omnibus or networked brokerage sub-accounts?** [One omnibus account per share class.] Lever, networked: the register holds the sub-accounts, the Fund Order becomes one per client order, and 49 reconciles each sub-account.
3. **Are new fund-only accounts opened?** [No; existing accounts stay.] Lever: convert them all to brokerage accounts and drop Fund-Only from Register Account Category.
4. **Where are the cost-basis lots of fund-only accounts kept?** [49 Client Tax Lot.] Lever: the lots stay on the TA platform as a 29 object.
5. **Is the firm a 529 program manager?** [No.] Lever, yes: 529 accounts become TA-registered accounts, and the 529 portfolios register their classes here.
6. **Who processes AP orders: the TA or the ETF's custodian?** [The TA; confirm with ETF Operations, since market practice often puts creations and redemptions with the custodian acting as the ETF's transfer agent.] Lever, the custodian: AP orders become received records.
7. **Are purchases and redemptions netted on the omnibus order?** [Not netted; Side Netting Indicator records the choice.]
8. **Does the TA pay fund-only shareholders directly?** [No; payments go through 50.] Lever, yes (the CW-107 lever): Cash Movement keeps the payment detail.

## 5. Overlaps with other domains (for consolidation)

See `proposals_w3_29.py`: SHARED_MEMBERSHIPS, SHARED_CANDIDATES, TERM_CONFLICTS (Order, Transfer, Account, Transaction, Balance, Alert, Settlement Obligation, Cash Movement / Money Movement), REPOINTS and NOTES. NOTES also lists the readers to re-point: DP-177, DP-178, DP-179, DP-180, DP-168, DP-244, DP-176, DP-210, DP-043, DP-069 (including the Intermediary Fee Cost per Position metric), DP-071 and DP-076, together with their data models, key registries and SM-12, SM-07 and SM-06.

## 6. Suggested validation steps

1. Walk one brokerage own-fund purchase end to end with Brokerage Operations and the TA: 48 Client Order, Fund Order, Register Transaction, Share Register Balance, 49 reconciliation, Settlement Obligation.
2. Walk one fund-only redemption: 13 request, Fund Order, Register Transaction, Cash Movement, and the 50 Money Movement.
3. Map the Register Transaction Type values to the TA platform's transaction codes and to Fund/SERV.
4. Confirm the capital stock proof split with Fund Accounting.
5. Confirm the monitoring split with the AML Officer.

## 7. Wealth model adaptation (W3) and US-only pass (CW-929)

- **Removed (39 JURISDICTION entries, decision CW-929):**
  - 1 attribute: Platform Order Reference.
  - 18 code values (Dealing Route 5, Order Settlement Method 2, shared Fund Dealing Settlement Method 2, Order Payment Method 4, CIP lists 5).
  - 14 references, list sources and value notes.
  - 5 sources.
  - 1 perspective entry.
  - By regime: EU market practice 17, Other EU/UK 15, FCA 4, UK market practice 2 (CHAPS, Bacs Direct Debit), GDPR / UK GDPR 1.
- **Re-sourced:**
  - Cut-Off Result to Rule 22c-1.
  - Dealing Suspension to section 22(e) (seven-day rule and exceptions); Uncollected Shares to the prospectus and fund policy.
  - Monitoring lists to FinCEN and FINRA Rule 3310.
  - Matched Sanctions List to OFAC.
- **Re-pointed:**
  - Resulting Transaction and AP Resulting Transaction now reference Register Transaction.
  - Obligation Amount is now mastered in 29.
  - Investor Bank Instruction is replaced by Client Money Movement.
  - CIP Verification is replaced by 02 Identity Verification.
- **Added:**
  - The Shareholder Register family.
  - Brokerage Omnibus Order Detail.
  - Triggering Money Movement.
  - The three CW-088 objects.
- **Out of scope (CW-004):** the insurance-dedicated values. They are recorded in REPOINTS, not in JURISDICTION.

## 8. Review fix pass (29_review.md, 2026-10-15)

Every High and Medium finding was applied under the program-lead rulings:
- Special category on the elder exploitation and Rule 2165 rows.
- The CW-122 omnibus ruling recorded for 06.
- Uncollected Shares re-sourced away from section 22(e).
- Copies: resolved dealer and rep now mastered here; the sweep row rule added.
- The 49 links stated as held on the 49 side.
- Register Account Category: row rule and the new 15 types.
- Closed confirms: Rule 17Ad-10, Omni/SERV and the Form TA-1 URL.
- The Order Routing Detail PII tier.

Lows applied:
- NOBO List Request is now No PII.
- CHAPS and Bacs are recorded as UK market practice.
- The SWIFT_DIRECT and label rulings are recorded.
- Register Transaction Status holds posting state only.
- New Register Transaction Types, with the originating row rule relaxed.
- Aggregated-order receipt timestamp defined.
- The Side Netting lever citation corrected.
- Tax Withheld Amount widened to sections 3405 and 1441.
- Engagement start date added to the Servicing Provider Engagement grain.
- DERIVED comment now names 28 for Cash Proof.
- Shared descriptions copied unchanged for TA Direct and Sponsor File.
- CIT register note added.
- Networking Level note for 15.
- Alert and Settlement Obligation term conflicts.
- CDE flags on Share Movement Direction, Uncollected Shares and Register Settlement Date; Omnibus Aggregation Date and Distribution Confirmed Date are no longer CDEs.
- The 13 RGTX- example digits noted for 13.

Skipped:
- The brief header count (not a 29 file).
- The workbook's shared Fund Dealing Settlement Method values, which only the merge can change. Do not circulate the 29 xlsx as US-only until then.
