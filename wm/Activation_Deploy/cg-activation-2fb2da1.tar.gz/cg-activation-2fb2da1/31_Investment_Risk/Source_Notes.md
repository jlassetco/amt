# Source Notes: 31 Investment Risk

**Workbook:** `Investment_Risk_Data_Taxonomy.xlsx` (built from `_tools/content/content_31_investment_risk.py`)
**Status:** Draft v0.1, wealth model (direct), scope US, 2026-10-14: the draft of 2026-10-06 (revised after independent review, 00_Program/Expansion/Reviews/31_review.md, and the program lead's decisions) carried over with the US-only pass and the perspective rewrite of CW-931 (section 7). 7 families, 25 objects (24 business objects, 1 attribute group), 242 attributes, 79 proposed CDEs (32.6%), 22 local code lists plus the enterprise shared lists cited directly (34 in all), 42 relationships, 16 sources. 56 references to other Data Domains, 4 derived copies, 0 unresolved (14 ownership overrides).

**Why this domain exists.** The firm is a US wealth manager whose own mutual funds, ETFs and CITs (PF line) and institutional separate accounts (IA line) are managed in house. Its investment risk function measures what those funds and portfolios hold and how much they could lose. That means exposures, ex-ante tracking error, VaR and expected shortfall, stress tests, fund liquidity under SEC Rule 22e-4, and derivatives exposure and the VaR tests under Rule 18f-4. It also sets risk limits and escalates exceedances to the program administrators and the fund boards. No other domain holds these records: 18 stores holdings, 22 prices, curves and per-instrument vendor analytics, and 24 the portfolio manager's optimizer estimates. What justifies a separate domain is independence. Rules 22e-4 and 18f-4 require these measures to come from a program administrator and a derivatives risk manager who are separate from portfolio management, with their own models, limits and escalation. The risk profile of a client is a different thing: it belongs to 02 and 45, and client managed accounts belong to 46 (CW-009).

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| SEC Rule 22e-4; Releases IC-32315 (2016) and IC-33142 (2018) | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.22e-4 (eCFR blocks automated fetch; confirm) | Four liquidity categories and their definitions (Liquidity Category list), classification at least monthly, reasonably anticipated trade size, classification by asset class with exceptions, HLIM and shortfall reporting (board at next meeting; more than 7 consecutive calendar days, board within one business day and Form N-RN), 15% illiquid limit, In-Kind ETF exemption, split classification of one position (IC-33142). |
| SEC Rule 18f-4; Release IC-34084 (2020) | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.18f-4 (confirm) | Derivatives risk management program and derivatives risk manager, derivatives exposure (gross notional, options delta-adjusted, interest rate derivatives as 10-year bond equivalents), relative VaR test (200%, 250% for closed-end funds with preferred stock) against a designated reference portfolio (unleveraged index or the fund's securities portfolio), absolute test (20% / 25%), 99% confidence, 20 trading days, at least three years of history, daily testing, more than 5 business days out of compliance triggers board reporting and N-RN, weekly stress tests and back-tests, limited derivatives user exception at 10% with currency and interest rate hedges excluded. |
| Forms N-PORT and N-RN (N-LIQUID renamed by IC-34084); Form N-CEN | https://www.sec.gov/files/formn-port.pdf ; https://www.sec.gov/files/formn-rn.pdf ; https://www.sec.gov/files/formn-cen.pdf (confirm all three) | Which 31 values are filed (liquidity classification Item C.7, VaR and derivatives exposure, N-RN events); the filings themselves are 35. |
| SEC Rule 2a-7(g)(8) | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.2a-7 | Money market fund stress testing as a program type and stress test purpose. |
| Basel Framework MAR | https://www.bis.org/basel_framework/standard/MAR.htm (confirm) | Expected shortfall at 97.5%, actual and hypothetical P&L for back-testing, traffic-light zones: concepts only. |
| NGFS climate scenarios | https://www.ngfs.net/ngfs-scenarios-portal/ (confirm) | Climate scenario families (Climate Scenario Pathway, Stress Scenario Type). |
| NAIC Model 280 | (removed at W5, CW-165) | Insurance-dedicated residue; no longer a source. |
| SEC Form PF | https://www.sec.gov/files/formpf.pdf (confirm; 2024 amendments' compliance date extended, confirm current date) | Portfolio and investor liquidity buckets for private funds. |
| SEC Rule 6c-11 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.6c-11 | ETF market statistics read as a liquidity input (22 ETF Market Statistic, CD-206). |
| SR 11-7 Supervisory Guidance on Model Risk Management | https://www.federalreserve.gov/supervisionreg/srletters/sr1107.htm | Model use vs inventory and validation, by analogy (Model Inventory Reference, future 37). |
| MSCI Barra, Bloomberg PORT, SimCorp Axioma | https://www.msci.com ; https://www.bloomberg.com/professional ; https://www.simcorp.com (product pages not confirmed) | Structure only: factor model, factor exposures, specific risk, covariance, risk decomposition, model horizons. |
| ISDA Master Agreement and CSA | https://www.isda.org | Netting set and collateral concepts (agreements and collateral stay 26). |

## 2. Design decisions and boundary calls

Sections 1 to 6 record the reasoning of the wholesale draft. Where they mention UCITS, AIFMD, PRIIPs, the SRI or SRRI, CESR or ESMA guidelines, or the UK CCI regime, section 7 supersedes them: those objects, values and sources were removed in the wealth model.

- **Measured, not observed (CD-211).** No price, curve point, vendor duration, option delta, fair value or ETF statistic is stored. Risk Factor references the 22 Curve Definition it represents; Stress Scenario Shock references a 31 factor, a 22 curve or a 01 index; Fund Liquidity Profile references the 22 ETF Market Statistic of an own ETF; Liquidity Classification references the 22 Fair Value Determination of a position without a market quotation. Instrument Factor Loading is a model output, not the 22 vendor duration or delta. 18 Delta-Adjusted Exposure Base stays 18 and is aggregated by Portfolio Exposure.
- **Ex-ante only (boundary rule 2).** Risk Measure values are prefixed "Ex-Ante" where 32 has an ex-post twin (tracking error, volatility, beta); VaR and expected shortfall are forecasts by definition. The one ex-post statistic computed here is the SRRI input, named "SRRI Ex-Post Volatility": a regulatory calculation input whose returns are read from 32 Performance Return.
- **Same fact once.** Thresholds live only on Risk Limit (VaR Test Result references the limit through Applied VaR Limit). Utilization lives only on Risk Limit Utilization (Counterparty Exposure references the 25 limit but holds no utilization). The HLIM lives only on Highly Liquid Investment Minimum and is never a Risk Limit; an HLIM shortfall is recorded on Fund Liquidity Profile (indicator and consecutive days), not as an RLEX-. The 15% illiquid limit is a Risk Limit (CD-223), so its excess is an RLEX-.
- **Utilization Measured Value.** Risk Limit Utilization keeps the value as measured, with a Source Measure Record pointer, so that a restated measure does not change a utilization already reported. This is the one deliberate snapshot of a 31 value inside 31.
- **Counterparty limits (CD-215, program lead decision 1).** Counterparty Exposure is one row per counterparty, date, counterparty exposure measure and scope (portfolio, trading entity or firm), and netting set where netted. Its measures cover net mark-to-market, collateral held, net exposure after collateral and PFE, plus every value a 25 Counterparty Trading Limit caps, named exactly as the 25 Limit Type values (OTC Derivative Gross Notional, FX Settlement Exposure, Repo Exposure, Unsettled Trade Exposure, Daily Trading Volume). Utilization of a 25 limit takes the Counterparty Exposure Amount of the matching row, so every 25 limit has a 31 value and RLEX- stays the one exceedance record. Risk Limit Utilization and Risk Limit Exceedance each point either to a 31 Risk Limit or to a 25 limit. No 31 Risk Limit is set on counterparty exposure.
- **Derived copies (plan §4 item 9 row rules).** Counterparty Exposure Amount (26 Collateral Balance on Collateral Held rows only: Received Variation Margin, Cleared Variation Margin and Repo Collateral; segregated regulatory initial margin excluded); Net Assets Used and Profile Net Assets (27); Realized Daily P&L (flagged 27, the majority case; Actual rows copy 27 or 18, Hypothetical rows are computed here); Recommended Holding Period Used (01).
- **Disclosure vs calculation (CD-212).** 01 attributes to be re-noted Derived copy (31): **Product Risk Indicator.Summary Risk Indicator (SRI)** and **Product Risk Indicator.SRRI**. 01 Global Exposure Method, Leverage Calculation Method, Maximum Leverage and Derivatives Usage are read, never repeated.
- **Program administrator.** Risk Program Designation references the 35 Fund Officer Appointment (role value 'Liquidity Risk Program Administrator (Rule 22e-4)' or 'Derivatives Risk Manager (Rule 18f-4)') rather than mastering the person; a Program Risk Lead (20 employee) is held only where no appointment exists (UCITS RMP, AIFMD policy, risk appetite framework).
- **Board approvals (CD-237 over CD-225, program lead decision 3).** 31 holds no board link. HLIM Board Approval, Program Board Approval and DRP Board Reporting Meeting were removed; 35 Resolution Subject Link holds approvals of 31 records and 35 Board Report Received holds the DRP report. If a 31 consumer needs it later, only a derived 'Board Approved Indicator' or 'Board Approval Date' read from 35 may be added.
- **Fund vs portfolio keys.** Rule 22e-4, Rule 18f-4, UCITS and AIFMD program results (Liquidity Classification, HLIM, Fund Liquidity Profile, Liquidity Horizon Bucket, Designated Reference Portfolio, VaR Test Result, Leverage & Exposure Measurement, Risk Program Designation) are keyed by the fund (PRD-) and measured on the fund's whole 18 book (every portfolio linked by an active 18 Portfolio Implementation Link, sleeves included). Measures, exposures, decomposition, stress results and back-tests are keyed by the 18 portfolio; VaR Test Result reads the measure of the portfolio that holds the fund's whole book. The grains say so.
- **Risk Limit scope.** Exactly one of Limited Fund, Limited Portfolio, Limited Strategy and Limit Business Lines is set, or none for a firm-wide limit; strategy, business line and firm-wide limits are measured per portfolio in scope, so Risk Limit Utilization is limit x date x portfolio (program lead decision 2). A limit names exactly one of a program test measure (Risk Limit Measure, now only program tests, including the 10% Rule 18f-4 limited derivatives user test), a Risk Measure or an Exposure Measure, plus its qualifiers (horizon, confidence level, benchmark, stress scenario, exposure dimension and bucket). Limit Setting Entity records a CIT trustee bank that sets a limit. Risk Limits exclude 24 portfolio construction constraints and budgets.
- **Private markets.** Leverage & Exposure Measurement references the 30 Fund Credit Facility whose borrowing is included in AIFMD exposure; Liquidity Horizon Bucket references the 30 Private Fund Profile for investor liquidity terms; Liquidity Classification references 22 Fair Value Determinations.
- **Renames to avoid 22's 'Instrument Factor Observation'.** Risk Factor Observation became Risk Factor Return and Instrument Factor Exposure became Instrument Factor Loading (the program lead's example 'Portfolio Factor Exposure' was not used because the object is per instrument, not per portfolio).
- **Grain keys of other domains' objects** follow their enrich files: 25 Counterparty Trading Limit (counterparty x limit type x trading entity x fund x effective period), 23 Internal Credit Assessment (party x analyst x scale x date), 27 Fund NAV Calculation (as 27 writes it), 22 ETF Market Statistic (instrument x date), 34 Portfolio Climate Metric (methodology value 'IFRS S2 / TCFD' for WACI) and 35 Fund Officer Appointment (35 role values). Blank key parts are written '(none)'.
- **Risk Factor dating.** Risk Factor has no effective dates of its own: it is dated by its model version (Model Effective From / To).

### Deviations from the brief

| Brief | Draft | Why |
|---|---|---|
| Family codes RK-MSR, RK-STR, RK-LIQ, RK-DRV | RK-MEA, RK-STT, RK-LQD, RK-DER | Attribute IDs would print registered prefixes MSR-, STR- (01 strategy) and DRV-, and LIQ- is left free for 36. |
| Risk Decomposition grain: run x portfolio x risk dimension x bucket | keyed by the full Portfolio Risk Measure (run, portfolio, measure, horizon, confidence level, benchmark) x dimension x bucket | 1-day and 20-day VaR, or tracking error against two benchmarks, would otherwise collide (review). |
| Portfolio Risk Measure "benchmark basis" | benchmark reference (blank = absolute) in the grain | Avoids a separate basis list that duplicates whether a benchmark is set. |
| Fund Liquidity Profile "above-15% indicator" | dropped | The 15% limit is a Risk Limit; its excess is the RLEX- and the utilization row. Keeping an indicator would hold the same fact twice. |
| Risk Program Designation "administrator EMP-" | 35 Fund Officer Appointment reference plus Program Risk Lead (EMP-) for programs without an appointment | 35 masters officer appointments, including the liquidity program administrator. |
| Shared lists | local copies named as the shared lists | 31 is not yet a registered direct user, so 'Shared: <name>' would not resolve (drafter_common Stage 2 addendum). Period Type was not needed (horizons are in days). |
| Local lists named in §8: Risk Limit Type as "hard, soft, warning" | Hard, Soft, Monitoring Only; no separate limit direction list | 'Warning' clashed with the Warning Threshold; all 31 limits are maximums and the HLIM (a minimum) is not a Risk Limit. |
| Brief §7 / CD-225: HLIM, program and DRP reference 35 approvals | no 35 board references | CD-237 ruling: 35 holds the link once. |
| Leverage & Exposure Measurement: fund or portfolio | fund only | Leverage and global exposure are fund regimes; SMA exposure is a Portfolio Exposure. |
| Liquidity Classification: portfolio x instrument | fund x instrument | Rule 22e-4 classifies the fund's investments. |
| Object names Risk Factor Observation, Instrument Factor Exposure | Risk Factor Return, Instrument Factor Loading | Avoid 22 'Instrument Factor Observation'. |
| Local lists 18-24 | 24 | Counterparty Exposure Measure added (CD-215). |
| Shock unit, exposure unit, limit unit | cite 22 'Measure Unit' and 22 'Rate Tenor' as External | Avoids a third copy of a unit list; proposed as shared lists. |

### Review response

All 3 High and 13 Medium findings of 31_review.md were applied, with the program lead's decisions 1-4. Lows applied: Factor term conflict; Holding View definition; HLIM board wording (moot: link removed); Designated Reference Index note corrected and flagged 'verify'; Shocked Index reference for index shocks and board escalation noted as evidenced in 35; Factor Return is daily; Scenario Effective To and Risk Limit Status added; Risk Limit scope rule stated; PII notes on keys embedding EMP-; Realized Daily P&L flagged 27; Source Measure Record format published; Collateral margin types stated; 'Leverage Percent of Net Assets' renamed; Risk Limit Type 'Warning' replaced by 'Monitoring Only'; Peak Utilization Percent dropped (it is the maximum of the utilization rows); Exposure Method values qualified by regime and 'Sum of Notionals (UCITS)' added; Credit Risk Class format; Climate Metric Input example uses the 34 methodology value; Administrator Appointment example uses the 35 role value; N-RN URL added; Liquidity Classification relationship re-pointed; GRAIN_KEY_FORMATS extended; Triggering Utilization added to Risk Limit Exceedance; Limit Setting Entity added for CITs; Highly Liquid Margin Adjustment added; CDE flags on Classification Portion Number, Portion Percent of Position, Stress Scenario Version and Indicator Calculation Date.

To stay within the 260-attribute cap after the additions, these derivable or low-value attributes were removed: Risk Factor Name, Bucket Instrument (an instrument is a Risk Bucket value), Percent Contribution to Risk, Post-Stress Net Assets, Liquidity Shortfall Amount, Scenario Approved By, Designation Rationale, Program Designation Status, Scenario Average Annual Return, Peak Utilization Percent.

Findings not applied, with reasons:
- [Low] Counterparty Exposure Method values SA-CCR and Current Exposure Method: kept until SME question 5 confirms which methods are used; removing them now would pre-empt the answer.
- [Low] Insurance-dedicated funds look-through and NAIC Model 280: accepted as a known v0.1 gap (see §3); no object added.
- [Low] 34 relationship alignment (34 says the climate metric feeds Stress Scenario, 31 reads it on Stress Test Result): left for the Stage 3 consolidation, noted on the attribute.
- [Note] 35 names 'Derivatives VaR Test Result' and 'Liquidity Risk Program Report': left for consolidation, as instructed (proposals_31 NOTES).

## 3. What could not be verified

- Rule 18f-4 designated index conditions (unleveraged, approved by the derivatives risk manager, reflects the markets or asset classes the fund invests in, not administered by an affiliate unless widely recognized and used): marked 'verify' on Designated Reference Index; the earlier 'constituents are published' wording was removed.
- Insurance-dedicated funds are out of the wealth model (CW-165); the NAIC Model 280 source and the stress source 'Insurer Requested' were removed at W5.
- The current Form N-PORT amendment compliance dates (2024 amendments) and the Form PF 2024 amendments' compliance date: not used in any attribute; confirm before citing dates.
- Withdrawn (W1b): the UK Consumer Composite Investments (CCI) question; the product risk indicators were removed (section 7).
- Form N-RN parts for liquidity (Parts B-D) and VaR (Parts E-G) as numbered after IC-34084: referenced only by form name.
- Basel MAR99 traffic-light boundaries and the CESR/10-788 back-testing exception rules were used as concepts; the firm's own thresholds need SME confirmation.
- Vendor product pages (MSCI Barra, Bloomberg PORT, SimCorp Axioma) were not fetched; used for structure only.
- eCFR and EUR-Lex pages block automated fetch; rule text was taken from the brief and general knowledge of the rules and should be checked against the official text.

## 4. Open questions for client SMEs

1. Which risk platforms and vendors are used, and which values are stored rather than recomputed (factor exposures, decomposition, PFE)?
2. Who are the 22e-4 program administrator and 18f-4 derivatives risk manager per fund family; which funds are limited derivatives users?
3. Are liquidity classifications done by asset class or by position, which reasonably anticipated trade size is used, and should 22 own per-instrument liquidity inputs (volume, bid-ask spread)?
4. Which body approves risk limits (risk committee, CIO, board), and which limits are hard?
5. Are counterparty exposures measured by risk or by the collateral team, and is PFE computed?
6. Withdrawn (W1b): no PRIIPs or UCITS indicators.
7. Which climate scenarios are run, and does the risk team or the stewardship team (34) own them?
8. Withdrawn (W1b): no UK funds.
9. Should 25 counterparty limit exceedances be escalated by risk (RLEX-) or by trading?
10. Is the Risk Limit Utilization snapshot of the measured value acceptable, or should utilization hold only the percentage?

## 5. Overlaps with other domains (for consolidation)

- **01:** Withdrawn (W1b): the SRI and SRRI derived copies were removed with the Product Risk Indicators family (CW-901, CW-931). Exposure Method values are read by 01 Leverage Calculation Method by name only.
- **18:** Delta-Adjusted Exposure Base stays 18; Realized Daily P&L and Net Assets Used read 18 Portfolio Valuation Summary on non-fund rows.
- **22:** inputs only; 31 cites 22 Measure Unit and Rate Tenor lists (proposed shared).
- **24:** Rebalance Run "Risk Model Used" to be re-typed Reference (Risk Model, 31); Pre- and Post-Trade Tracking Error stay 24 as optimizer estimates (CD-211).
- **25 / 26:** limit and agreement referenced; 25 Limit Type values are matched by 31 Counterparty Exposure Measure values (shared list candidate); collateral held rows are Derived copy (26); SIMM and margin calls stay 26.
- **32 / 33 / 35:** ex-post statistics are 32; coded restrictions and breaches are 33 (rules name 31 measures); filings, board reports and Reportable Fund Events are 35 and reference 31 objects by name (CD-225). Name differences from the 35 brief are listed in proposals_31 NOTES.
- **30:** Fund Credit Facility and Private Fund Profile referenced for private-markets leverage and liquidity.
- **34:** Stress Test Result reads 34 Portfolio Climate Metric (CD-216).
- **35:** board approvals of 31 records are linked from 35 Resolution Subject Link only (CD-237).
- **37:** Model Inventory Reference is text until Stage 4.

## 6. Suggested validation steps

1. Walk one US fund through a month: liquidity classifications, profile, HLIM test, the 15% limit utilization, a VaR test and a weekly stress test, and check each N-PORT and N-RN item maps to a 31 attribute.
2. Withdrawn (W1b): no UCITS funds.
3. Withdrawn (W1b): no AIFs; for a private feeder fund, walk the Form PF liquidity buckets instead (W4 with 30).
4. Reconcile one OTC counterparty's exposure with 26 collateral balances and the 25 trading limit, and raise a test RLEX-.
5. Withdrawn (W1b): the SRI and SRRI calculations were removed.
6. Confirm with 33 that no 31 Risk Limit duplicates a coded restriction, and with 24 that no risk limit is a PM constraint.

## Stage 3 consolidation (2026-10-06)

Changes made to this module at the Stage 3 consolidation (CD-241, CD-242; `_tools/consolidation/stage3_consolidation_notes.md`):
- Prefixes RLMT-, RLEX- and STRESS- registered with the published formats; no rename.
- Local copies of nine enterprise shared lists removed; attributes cite "Shared: <name>" (31 is a registered direct user).
- Climate Metric Input re-pointed from the retired 34 "Portfolio Climate Metric" to Reference (Portfolio Sustainability Metric, 34), with the 34 key format; the relationship row renamed to match.
- 02 Party Role Type "Risk Model Vendor" added (CD-143); 01 SRI and SRRI are now Derived copies (31) of Product Risk Indicator Calculation (CD-212).
- Masters summary names Risk Factor Return and Instrument Factor Loading. All overrides kept (composite keys).

## 7. Wealth model carry-over (W1b, CW-931)

31 is kept (plan section 5.1). The pass made the changes CW-022 allows: the US-only pass, the perspective text and the Business Line example. Names of kept objects and attributes are unchanged, so DP-154, DP-155 and the SM-10 model keep resolving. The decision draft, the jurisdiction entries and the readers of the removed objects are in `_tools/consolidation/proposals_w1b_31.py`.

**Removed (EU/UK only; 26 jurisdiction entries: UCITS 12, PRIIPs 8, AIFMD 4, FCA 1, Other EU/UK 1).**
- The Product Risk Indicators family as a whole: Product Risk Indicator Calculation (PRIIPs SRI and UCITS SRRI) and PRIIPs Performance Scenario, with the lists Product Risk Indicator Type and PRIIPs Scenario Type. 01 removed the disclosed SRI and SRRI under CW-901. US funds disclose risk in the Form N-1A risk/return summary and compute no numeric indicator.
- Values: Counterparty Exposure Method "UCITS Positive Mark-to-Market"; Exposure Method "Commitment Approach (UCITS)", "Sum of Notionals (UCITS)", "Gross Method (AIFMD)" and "Commitment Method (AIFMD)"; VaR Test Regime "UCITS Relative VaR" and "UCITS Absolute VaR"; Risk Program Type "UCITS Risk Management Process" and "AIFMD Risk Management Policy"; Risk Limit Measure "Commitment Global Exposure Percent".
- Sources: CESR/10-788; Directive 2010/43/EU; UCITS Directive Articles 51-52; AIFMD and Delegated Regulation 231/2013; ESMA34-39-897; the PRIIPs RTS (2017/653); Regulation 583/2010 with CESR/10-673. Two relationships went with the removed family.

**Re-sourced.**
- VaR tests, designated reference portfolios, back-testing, risk horizon and lookback now rest on SEC Rule 18f-4 alone. CESR/10-788 was dropped from 21 attributes.
- The risk programs are now the Rule 22e-4 liquidity risk management program, the Rule 18f-4 derivatives risk management program, the limited derivatives user policies, Rule 2a-7 stress testing and the firm risk appetite framework.
- Liquidity Stress Detail now rests on Rule 22e-4: the liquidity risk assessment under normal and reasonably foreseeable stressed conditions (confirm the paragraph, 22e-4(b)(1)(i)).
- Liquidity Horizon Bucket and Fund Borrowing Facility now rest on SEC Form PF. They cover private funds only and are left for the W4 decision on 30.
- Counterparty exposure now rests on ISDA concepts and Internal. Counterparty concentration limits are 33 rules (fund policy and institutional guidelines).

**Perspective rewritten.**
- META subtitle.
- Overview:
  - Purpose: the firm's own funds and institutional portfolios. Client risk is 02 and 45, and client managed accounts are 46.
  - Scope.
  - Core model.
  - Design principles: 3 (01 declares the Rule 18f-4 leverage calculation method), 4 (prospectus leverage limits are 33 rules) and 7 (18 portfolios are never retail client accounts).
  - Applies To, CDE, Primary / Secondary Reference.
  - Notes: Regulation S-P, GLBA and state law.
  - Suggested next steps.
- The PII note on portfolios now reads "institutional separate account".
- "01 Global Exposure Method" now reads 01 Leverage Calculation Method.
- 25 is now named Portfolio Trading & Execution.
- SUMMARY in `enrich_31.py`.

**Business Line (CW-004).** The Limit Business Lines example is now "PF; IA".

**Added.** Exposure Method value "Section 18 Asset Coverage" and the Investment Company Act Section 18 source (review fix pass, program-lead ruling).

**Left for later stages.**
- 30 references, for W4: Fund Borrowing Facility, Bucket Private Fund Profile and their relationships.
- Insurance-dedicated residue: the NAIC Model 280 source and the Stress Scenario Source value "Insurer Requested" were removed at W5 (CW-165).
- Exposure Method (steward 31) now has two US values: "Rule 18f-4 Derivatives Exposure" and "Section 18 Asset Coverage" (added in the review fix pass by program-lead ruling: the prospectus borrowing and leverage limit of a US fund is the Section 18(f) asset-coverage test). The object group "Leverage & Global Exposure" is renamed "Leverage & Derivatives Exposure" and the Exposures family text no longer uses the UCITS term "global exposure"; the object Leverage & Exposure Measurement keeps its name.

**Open questions (W1b).**
1. Do the managed account programs (46) need any 31 measure, such as model portfolio risk, or does 46 keep the risk of its models (CW-009)?
2. Does the firm keep private feeder funds that file Form PF? If not, Liquidity Horizon Bucket and Fund Borrowing Facility go with 30 at W4.

**Unverified.** The Rule 22e-4 paragraph cited for liquidity stress (confirm).
