# Source Notes: 32 Performance & Attribution

**Workbook:** `Performance_and_Attribution_Data_Taxonomy.xlsx` (built from `_tools/content/content_32_performance_and_attribution.py`)
**Status:** Draft v0.1 after independent review, 2026-10-06; adapted to the wealth manager at W3, 2026-10-15 (section 8; the counts in this line are the wholesale v0.1 counts). Perspective: Wealth manager (direct) | Scope: US. 6 families, 24 objects (21 business objects, 3 attribute groups), 240 attributes, 80 proposed CDEs (33.3%), 31 code lists (22 local, 3 copies of 01 / 12 lists, 6 local copies of enterprise shared lists), 48 relationships, 19 sources, 8 derived copies, 9 ownership overrides, 0 unresolved references.

**Why this domain exists.** The performance measurement team calculates the official return of every portfolio, share class, account and composite, the benchmark returns they are compared with, the attribution that explains the difference and the statistics that put it in context, and it keeps the firm's GIPS compliance record. Every client report (12), shareholder report (13), marketing piece (04, 08), consultant database submission (03), performance fee (10, 12) and regulatory filing (35) depends on those numbers, yet before this domain no one mastered them: 01 defines composites and benchmarks, 12 says how performance is shown, 11 stores vendor-reported returns and 27 strikes the NAV. A return is a calculated, versioned, signed-off record with its own methodology, restatement history and GIPS evidence, owned by a function independent of the portfolio managers it measures.

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| GIPS Standards for Firms (2020), Handbook and guidance statements | https://www.gipsstandards.org/standards/gips-standards-for-firms/ | Firm definition and total firm assets, composite membership and exclusion, significant cash flows, carve-outs with own cash, internal dispersion (not required under six portfolios), 3-year annualized ex-post standard deviation, money-weighted returns and multiples for private funds, subscription lines, error correction (12-month disclosure), verification vs performance examination. |
| SEC Marketing Rule 206(4)-1 and staff FAQ | https://www.ecfr.gov/current/title-17/section-275.206(4)-1 ; https://www.sec.gov/rules-regulations/staff-guidance/division-investment-management-frequently-asked-questions/marketing-compliance-frequently-asked-questions | Net with gross, 1/5/10-year periods, hypothetical performance (model, back-tested), predecessor performance. |
| SEC Rule 482 and Form N-1A Items 4, 26, 27A | https://www.ecfr.gov/current/title-17/chapter-II/part-230/section-230.482 ; https://www.sec.gov/files/formn-1a.pdf (confirm) | Standardized returns with maximum sales charge; before- and after-tax returns (Return Tax Basis, Sales Charge Adjusted Indicator); tailored shareholder report performance (Release 33-11125). |
| SEC Rule 6c-11 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.6c-11 | ETF market price (closing price or NBBO midpoint) for market price returns. |
| Form N-PORT | https://www.sec.gov/files/formn-port.pdf | Part B, Item B.5: monthly class returns that 35 files (confirmed by review). |
| FINRA Rule 2210 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2210 | Retail communications, projection limits. |
| FINRA Rule 2231; Regulation S-P (17 CFR Part 248) | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2231 ; https://www.ecfr.gov/current/title-17/chapter-II/part-248 | Account statements that show personal returns (treatment of returns on statements: confirm); personal financial data basis of the PII tiers (W3, replacing the removed UCITS KIID and PRIIPs row, CW-932). |
| ILPA Reporting and Performance Templates (2025) | https://ilpa.org/wp-content/uploads/2025/09/Combined-Overview-ILPA-Templates.pdf | Gross and net IRR and multiples, with and without facility, granular and gross-up methodologies. Removed at the W3 fix pass with the Private Markets Performance family (CW-930, CW-166). |
| Brinson, Hood and Beebower (1986); Brinson and Fachler (1985) | https://doi.org/10.2469/faj.v42.n4.39 | Allocation, selection and interaction effects. |
| Carino (1999), Menchero (2000), Frongello (2002); GRAP | https://www.spauldinggrp.com (journal publisher; confirm) | Linking methods. |
| Bacon, Practical Portfolio Performance Measurement and Attribution | https://www.wiley.com (confirm edition) | Calculation methods, ex-post statistics, geometric and fixed income attribution. |
| CFA Institute CIPM | https://www.cfainstitute.org/programs/cipm | Statistic and attribution vocabulary. |
| Karnosky and Singer (1994); Ankrim and Hensel (1994) | https://www.cfainstitute.org/research/foundation (confirm) | Currency attribution methods. |
| Kaplan and Schoar (2005); Long and Nickels (1996); Rouvinez (2003); Gredil, Griffiths and Stucke (2014); Cambridge Associates mPME | https://doi.org/10.1111/j.1540-6261.2005.00775.x | PME methods and output units. Removed at the W3 fix pass with the Private Markets Performance family (CW-930, CW-166). |
| DOL Rule 404a-5 | https://www.ecfr.gov/current/title-29/subtitle-B/chapter-XXV/subchapter-F/part-2550/section-2550.404a-5 | Investment option returns in participant disclosures (16 reads 32 share class / unit class rows). |
| Form PF | https://www.sec.gov/files/formpf.pdf | Monthly gross and net returns that 35 files (the AIFMD Annex IV half was removed at W3, CW-932). |
| Morningstar; Nasdaq eVestment data collection | https://www.nasdaq.com/solutions/evestment/global-database/data-collection-process | Cross-check of reinvestment and composite submission conventions only. |

## 2. Modeling decisions and deviations from the brief

- **Structure:** 6 families and 24 objects (brief 23 ±3). Attribution Segment Result was added so segment weights and returns are held once per segment, not repeated on every Attribution Effect row (allocation, selection and interaction rows of a segment would otherwise each carry the same weights).
- **Family code PF-RAS** instead of the brief's PF-RET, because "RET" is 08's registered `RET-` prefix (the rule the 36 brief applied to PD-REV).
- **Return key (after review):** Performance Return = subject x period start x period end x fee basis x **net fee basis** (actual / model / highest, blank on gross) x **calculation type** (time- / money-weighted) x price basis x **tax basis** x **sales charge basis** x currency x version. Form N-1A requires after-tax returns and Rule 482 standardized returns deduct the maximum sales charge; non-fund rows default to Before Taxes and N. Return Tax Basis is a new local list.
- **Typed subject references (after review):** every subject is a set of typed references, one per subject kind, exactly one filled per row, with the Subject Type as discriminator (Profile, Return: Portfolio 18, Share Class 01, Account 15, Composite 01, Model Portfolio 01; Ex-Post Risk Statistic: Portfolio, Share Class, Composite, Benchmark; private measures: Private Fund 01, Private Investment 30, Composite 01; PME: Private Fund, Private Investment). Each resolves to its owner.
- **Same fact once:** return values live only on Performance Return and Benchmark Return. Attribution Result, Contribution to Return and Performance Restatement reference RETURN- and versions; the restatement holds only the computed difference. Composite returns are Performance Return rows with subject type GIPS Composite and no component values; Composite Period Statistic is the only home of composite assets and of the GIPS 3-year composite and benchmark standard deviations, which are never produced as Ex-Post Risk Statistic rows. Attribution segment and effect rows have no 'Total' row: totals are the referenced Performance Return and Benchmark Return. Significant cash flow removal dates live only on Significant Cash Flow Event; a temporary removal does not end the membership, and Composite Membership references the events.
- **"Gross and Net"** stays in the copied Performance Fee Basis list but is declared invalid on every return, statistic and measure row.
- **Lists:** Return Methodology and Net Fee Treatment are byte-identical copies of 12 (the brief named the second "Fee Schedule Basis"; the 12 name was kept so consolidation is a membership). Benchmark return type uses a copy of 01 Return Type. The brief's local "Observation Frequency" list was replaced by the shared Frequency copy, and the brief's "Data Basis" was not used: Return Status (Preliminary, Final, Restated, Superseded) and Return Source (in house, administrator, recordkeeper, index provider) carry what Data Basis would have. Benchmark hedging is a Boolean in the grain, not a list. Carve-out cash treatment is a Boolean (Own Cash Balance Indicator) with a text cash allocation method. Composite Inclusion Basis, GIPS engagement type and verification opinion lists were not created (dates, approvals and Booleans cover them). 22 local lists, at the top of the brief's 16 to 22.
- **Status and reason separate:** Composite Membership has no status list; dates and Membership Approval Status give the state and Composite Exclusion Reason gives the reason. Period Close Status is separate from Return Status.
- **Derived copies (row rules in the attribute notes):** Beginning and Ending Portfolio Value and Net External Cash Flow (18, portfolio and account rows only; the 18 value is the IBOR estimate, and share class rows use the referenced 27 NAV instead); Fees Deducted Amount (12 fee invoices on net-of-actual-fee institutional separate account rows, computed here on model fee rows, blank on gross and share class rows); Profile Model Fee Rate (01 fee schedule: Share Class Management Fee Rate or the strategy / mandate Fee Schedule (FSCH-)); Benchmark Return Blend Components Applied (01); Significant Flow Amount (18) and Applied Significant Flow Threshold (01). Cumulative Paid-In Capital is now computed here from 30 Capital Call Allocations and Purpose Lines, not a copy.
- **Versioning (after review):** Benchmark Return, Ex-Post Risk Statistic, Private Markets Performance Measure, Investor Performance Measure and Public Market Equivalent have a version in the key and status as a plain attribute; Benchmark Return and the two private measures carry a Supersedes reference. Attribution Result is keyed by the portfolio return version and the full benchmark return key; its portfolio, benchmark and dates are read from them (the repeated attributes were removed, as on Contribution to Return).
- **Private measure inputs (CD-219):** Residual Value NAV Calculation (27 Fund NAV Calculation) on fund and composite rows and Residual Value Fair Value Determination (22 FVD-) on investment rows.
- **Other review changes:** Track Record Continuity Change and a Performance Close Group moved to the measurement profile; Applied FX Rate replaced by Applied FX Rate Type (09) with the 22 observations implied; Reinvested Distributions removed (implied by class and period); GIPS Firm Code added and used by GIPS Verification; Restatement Date added; Attribution Calculation Basis added to Attribution Model and a classification scheme reference to Contribution to Return; Statistic Price Basis, Currency and Version added to Ex-Post Risk Statistic; PME subject type and facility basis added; units given per value in the Ex-Post Statistic and PME Method lists; conditional PII notes on every value of an individual's row; consumer relationships to 16, 03 and 11 added.
- **CD-217:** Performance Return can serve either option: the fiscal-period, Net of Fees, NAV, Before Taxes, non-sales-charge-adjusted share class row is what 27 Financial Highlights **Total Return** would copy (option A) or reconcile to (option B).
- **CD-218:** 32 membership is by 18 portfolio while 01 **Composite Member** is a product / mandate reference, so option A is reworded as a derived roll-up through 18 Portfolio Implementation Link (option B, retire it, as fallback). 01 Share Class **Performance Calculation Basis** is proposed as a Derived copy of the measurement profile (proposals_32 FUTURE_DERIVED_COPIES).
- **CD-219:** private measures reference 30 commitments, capital accounts and credit facilities; no capital account balances, calls, distributions or waterfall amounts are mastered. Administrator-calculated measures carry Measure Source = Fund Administrator.
- **CD-220:** superseded at W3 by CW-129: client account returns are Personal Rate of Return in the Client Account Performance family; Performance Return account rows are institutional separate accounts only.
- **CD-211:** only ex-post statistics; "Ex-Post" appears in names where 31 has an ex-ante counterpart (tracking error, beta, standard deviation).
- **Model inventory:** Attribution Model holds Model Inventory Reference as text, "future owner 37" (CD-216).
- **Not modeled:** extracted performance, targeted and projected returns (not calculated returns; a marketing / product SME question), rankings and quartiles (11), periods shown and fee basis shown (12), GIPS firm assets by business line (brief "if used"; can be added as a grain column).
- **Sibling references:** 31 Risk Model; 35 Fund Regulatory Filing (REL only, the consumer holds the reference); 36 Product Change Initiative (Track Record Continuity Change). Names checked against the in-progress content_33-36 modules, which already reference "Performance Return, 32" and "Benchmark Return, 32".
- **Ownership overrides (9):** references whose composite keys start with a third domain's prefix: 22 Index Level Observation and ETF Market Statistic (4, forced to 22), 30 Private Investment (2, forced to 30), 27 Fund NAV Calculation (1, forced to 27); own-object Benchmark Return Record and Significant Cash Flow Removals forced to "mastered here".
- **Size trims to stay within 240 attributes:** dropped Policy Approval Status, Default Return Calculation Method, Hypothetical Assumptions Reference and Hypothetical Approver, Benchmark Annualized Indicator, Non-Discretionary Assets Included, Firm Definition Effective To, Cash Allocation Method, Verification Report Issued Indicator, Investor DPI Multiple, Target Final Business Day, GIPS Disclosure End Date (the 12-month rule is in the indicator's definition); Record Status list no longer used.

### Review response

Applied: all 4 Highs (per the program lead decisions), all 19 Mediums and the Lows, except:
- **Contribution Item Return / Statistic Annualized Indicator:** not reinstated; units and annualization are given per value in the Ex-Post Statistic list instead of an indicator.
- **Ex-Post Risk Statistic subjects:** typed references cover Portfolio, Share Class, Composite and Benchmark only. Account and model portfolio statistics are computed on the 18 portfolio (institutional separate account book) or not produced; adding two more references would push the domain past 240 attributes.
- **Significant Cash Flow Event membership start date (Low):** not added as an attribute; the join (flow date within the membership dates) is stated in the grain and the Flow Composite definition.
- **Performance Close Group (Low):** kept as an operational list (source note says business line x subject type) rather than two attributes.
- **Investor Performance Measure facility basis:** not added; investor-level measures are on actual investor cash flows.

## 3. What could not be verified

- GIPS 2020 provision numbers for: carve-outs requiring their own cash balance for composite inclusion; the subscription line rule (returns with and without the line when principal is not repaid within the GIPS time limit); the 12-month disclosure of material errors. The requirements are as modeled; provision references to confirm.
- ILPA Performance Template definitions of the Granular and Gross-Up methodologies (list descriptions marked "confirm"). (Moot after the W3 fix pass: the family left 32.)
- Journal citations for Carino, Menchero, Frongello, Ankrim and Hensel, Long and Nickels, Rouvinez and Gredil et al., and the current edition of Bacon. URLs given are publisher home pages, not article pages.
- Form N-1A PDF URL and Release 33-11125 page (not fetched).

## 4. Open questions for SMEs

1. Which performance platform calculates returns, and are daily or monthly valuations used per business line?
2. CD-217: is the 27 Financial Highlights Total Return taken from 32 (option A) or computed and audited in 27 with a 32 reconciliation (option B)?
3. (W3) Answered by CW-129: personal rates of return are calculated here; plan account values come from the in-house recordkeeper (16).
4. Who approves composite membership changes, and is there a GIPS committee?
5. Which attribution models are used per asset class (equity Brinson, fixed income, factor) and which linking method?
6. Are private fund IRRs calculated by the administrator, by private markets finance (30) or here?
7. Are benchmark returns taken from the index vendor or recomputed from 22 levels, and how are blends rebalanced?
8. Which returns are marked Final, and on which business day after month end?
9. Is model portfolio (hypothetical) performance produced, and how is it reviewed under the SEC Marketing Rule? Who owns targeted and projected returns?
10. Does the firm claim GIPS compliance for all lines, and for which pooled funds are GIPS pooled fund reports prepared?
11. How are performance restatements disclosed to clients (12) and shareholders (13)?
12. Are after-tax returns calculated in house or by a vendor, and are sales-charge-adjusted returns produced for every load class?

## 5. Suggested validation steps

1. Walk one month-end close for a mutual fund class (NAV and standardized returns), an ETF (NAV and market price), an institutional separate account composite, a managed account composite, a client household and a private fund through the objects and confirm every number has one home.
2. Reconcile Composite Membership against the composite system and the verifier's last sample; confirm the 01 Composite Member re-note (CD-218).
3. Confirm with 27 that Start and End NAV Record and Reinvested Distributions are enough to reproduce Form N-1A total returns.
4. Confirm with 30 and the administrator that the ILPA template output maps to Private Markets Performance Measure and Investor Performance Measure. (Moot after the W3 fix pass: the family left 32; feeder returns are ordinary returns.)
5. Agree with 12, 13 and 35 that they read only Final or Restated rows by RETURN- reference.
6. Review CDEs with the GIPS officer and Compliance.

## Stage 3 consolidation (2026-10-06)

Changes made to this module at the Stage 3 consolidation (CD-241, CD-242; `_tools/consolidation/stage3_consolidation_notes.md`):
- Prefixes RETURN-, PAAN- and GVER- registered with the published formats; no rename.
- Local copies of six enterprise shared lists removed. Return Methodology and Net Fee Treatment became shared lists stewarded by 32, with 12 as member (CD-242); the 32 copies were removed.
- 01 GIPS Composite Composite Member is now a Derived copy (32) rolled up through 18 Portfolio Implementation Link (CD-218 option A). All overrides kept (composite keys).


## 8. Wealth model adaptation (W3, 2026-10-15)

Brief: `00_Program/Rework/Briefs/W3_24_32_Family_Additions.md`; decisions CW-011, CW-027, CW-050, CW-129, CW-130 and the US-only pass CW-932 (`_tools/consolidation/proposals_w3_32.py`).

**Counts.** Before: 6 families, 24 objects, 240 attributes, 80 CDEs, 60 references, 8 derived, 31 code lists, 48 relationships, 19 sources. After: 7 families, 29 objects (26 business objects, 3 attribute groups), 285 attributes, 99 CDEs (34.7%), 69 references, 12 derived, 0 unresolved, 37 code lists, 59 relationships, 19 sources.

| Wholesale item | Disposition |
|---|---|
| Source Regulation (EU) 583/2010 (UCITS KIID past performance) | Removed (UCITS) |
| Source PRIIPs Delegated Regulation 2017/653 | Removed (PRIIPs) |
| Form PF source row, AIFMD Annex IV half | Cut (AIFMD); row kept as SEC Form PF |
| GIPS Firm Definition example ('US and UK investment advisers') | Re-worded; non-US affiliates stay as text |
| Return Account, Profiled Account (SMA, institutional, participant, direct shareholder; CD-220 option A) | Re-scoped to institutional separate accounts (CW-129) |
| Composite Membership | No retail, participant or trust account may be a member (GIPS does not reach personal returns) |
| Measured Subject Type, Return Source, Performance Close Group | Re-cut; Managed Account Composite added (CW-050) |
| Private Markets Performance (references to 30) | Removed at the fix pass with the 30 retirement (CW-930, CW-166) |

**Added.** Client Account Performance (`PF-CAP`): Client Performance Profile, Household Performance Group (`HPGRP-`), Household Performance Group Member, Personal Rate of Return (`PRROR-`; exact name), Client Return Exception. Return Managed Account Composite and Profiled Managed Account Composite (Reference (Managed Account Composite, 46), `MACP-`).

**Modeling decisions.** One row is one number: method (time-weighted or money-weighted) and fee basis are key parts; 'Both' and 'Gross and Net' are valid on the profile only. Values and flows are Derived copies of 49 Client Holding Valuation and Client Account Activity, 16 Participant Balance for plan accounts and 47 Fee Debit; row rules are in enrich_32. A Household Performance Group groups accounts of the 02 Client Household for performance only (CW-027). Open Client Return Exceptions suppress publication. GIPS is cited as the source of the calculation methods, not as a compliance claim.

**Deviations from the brief.** Proposals file `proposals_w3_32.py`. A Profiled Managed Account Composite was added so composite returns have a close group. No separate calculation method, return source, period basis or group dates on the new objects (size band). 32 carries a verbatim local copy of the shared Record Status (not yet a direct user).

**Not verified (confirm).** The marketing rule staff FAQ position on personal performance in one-on-one communications; FINRA Rule 2231 treatment of returns on statements; GIPS guidance paths on calculation methodology. FINRA Rule 2210's projection prohibition is moving (SR-FINRA-2026-004, filed 2026-02-10, pending at the SEC). 49, 29, 47, 50 and 52 are now drafted and the names used resolve.

**SME questions (levers, with the reference default).** 1) Are personal returns shown net of advisory fees? Default both; net is the certified figure. 2) Is the money-weighted return the statement headline? Default yes for retail, time-weighted for program reporting. 3) Do household groups default to all accounts? Default yes; clients may define subsets. 4) Is a return suppressed for an account with less than one full period? Default yes. Lever (CW-129): a firm without personal performance reporting drops the family.

**Readers.** DP-145 extended at WP1 to publish Personal Rate of Return (CW-011); DP-145 PII note and SM-08 return_account re-scoped; DP-158 example text only; others unchanged. Lines in proposals_w3_32.py NOTES.

### Fix pass (00_Program/Rework/Reviews/24_32_review.md, 2026-10-15)

Program-lead rulings: band widened to 295 attributes; 30 retires (CW-930, CW-166) and the insurance-dedicated close group goes (CW-165), applied here from proposals_w4_retire.py CARRIED_INTO_MERGE (19 items).

**Counts.** Before the fix pass: 7 families, 29 objects, 285 attributes, 99 CDEs, 69 references, 12 derived, 37 code lists, 59 relationships, 19 sources. After: 6 families, 26 objects (23 business objects, 3 attribute groups), 246 attributes, 85 CDEs (34.6%), 57 references, 12 derived, 0 unresolved, 34 code lists, 56 relationships, 17 sources.

**Applied.** Personal Rate of Return values, flows and fees name every source with row rules: 49 Client Holding Valuation, Account Cash Balance (sweep balances of the 50 program included) and Margin Balance Snapshot debit, and Client Account Activity for brokerage and managed accounts; 29 Share Register Balance and Register Transaction for fund-only accounts at the transfer agent; 16 Participant Balance and Participant Ledger Posting for plan accounts; fees from 47 Fee Debit and Fee Invoice, and 16 Plan Fee Schedule for plan accounts. Institutional Fees Deducted Amount is a Derived copy of 47 (Fee Invoice, Performance Fee Calculation; CW-054). GIPS firm scope stated on the GIPS family, Composite Membership and the GIPS Firm Definition example. Added Personal Return Calculation Method (Modified Dietz, IRR, daily valuation), Period Basis and Client Notification Indicator; default household-group member row rule; Client Comparison Target Set removed (the comparison is the model's 01 blended benchmark); 'Householding Group (MHG-)' wording for 13; GIPS Composite Exclusion Reason rename; suppression source Internal with FINRA Rule 2231 (confirm); Database Submission [05]; Private Markets Performance family, Private Fund and Private Investment subject values, Facility Basis, ILPA Performance Methodology and PME Method lists, their RELs and the ILPA and PME sources removed; Insurance-Dedicated Fund Share Classes close group removed.

**CDE swaps.** Flagged: Personal Return Account, Personal Return Group, Client Profile Account. Un-flagged: Member Account, Client Return Exception Type, Member Inclusion Date, Performance Group Type, Statistic Period End Date.

**Levers added.** 6) Personal-return calculation method: default true IRR for the money-weighted headline and Modified Dietz linked monthly (or daily valuation) for time-weighted. 7) GIPS firm scope: default the advice programs are run by a separate adviser entity outside the GIPS firm, so no retail account is a composite member; lever: they enter the GIPS firm as wrap or pooled composites (then 46 Managed Account Composite links to a 01 GIPS composite and 32 counts its members). 8) Fund-only account source: default 29 Share Register Balance and Register Transaction; lever: a firm that books every account in 49 reads 49 only.

**Skipped.** Adding 32 to the shared Record Status direct users: shared_code_lists.py is outside this pass's files (proposed in proposals_w3_32 SHARED_MEMBERSHIPS; the local copy stays until the merge).
