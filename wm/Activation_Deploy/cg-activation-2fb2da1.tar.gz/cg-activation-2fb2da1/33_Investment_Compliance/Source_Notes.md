# Source Notes: 33 Investment Compliance

**Workbook:** `Investment_Compliance_Data_Taxonomy.xlsx` (built from `_tools/content/content_33_investment_compliance.py`)
**Status:** Draft v0.1, wealth model (direct), scope US, 2026-10-14: the draft of 2026-10-06 (revised after the independent review, `00_Program/Expansion/Reviews/33_review.md`) carried over with the US-only pass and the perspective rewrite of CW-933 (section 7). 6 families, 25 objects (24 business objects, 1 attribute group), 239 attributes, 74 proposed CDEs (31.0%), 33 code lists in the workbook (17 local, the rest shared or external lists cited directly), 41 relationships, 14 sources, 21 attributes flagged PII. No Record Metadata object.

**Why this domain exists.** The firm is a US wealth manager that manages its own mutual funds, ETFs and CITs (PF line) and institutional separate accounts (IA line) in house. Its investment compliance team turns prospectus limits, institutional client guidelines and statutory investment restrictions into coded rules in the compliance engine. It tests every proposed trade, order, block and private deal before release and every portfolio after the close, works the alerts, and investigates, remediates and reports breaches. It answers to the CCO under SEC Rule 38a-1 and Advisers Act Rule 206(4)-7. Client-account checks of the brokerage and advice businesses (order suitability and restrictions, Reg BI evidence, managed account drift) are 48, 45 and 46, not 33. Before this draft, the restrictions existed only as text and limit values (01 `RST-`, 02 `CRX-`). 12 reported breaches to clients with no breach master behind them, and 25 carried a compliance check outcome copied from a domain that did not yet exist. The fact that justifies a separate domain is that **a coded rule is not the restriction it implements**:
- one restriction becomes several rules;
- one rule serves many portfolios;
- every test, override and breach must be evidenced against the exact rule version that was in force.

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| Investment Company Act of 1940 Sections 2(a)(16), 5(b)(1), 12(d), 18 | https://www.law.cornell.edu/uscode/text/15/80a-5 ; .../80a-2 ; .../80a-12 ; .../80a-18 | Section 2(a)(16) government security (includes securities issued or guaranteed by US government instrumentalities); 75-5-10 diversified company test (5% of total assets and 10% of voting securities of one issuer within 75% of total assets); Section 12(d)(1) fund-of-funds limits (3% / 5% / 10%); 12(d)(3) securities-related issuers; Section 18 asset coverage (300% for bank borrowing). Shaped Regulatory Limit Provision and the "% of Total Assets" and "Ratio" Measurement Basis additions. |
| SEC Rules 12d1-4 and 12d3-1 | https://www.ecfr.gov/current/title-17/chapter-II/part-270 | Acquiring fund conditions; the 5% equity / 10% debt / 5% of total assets limits on securities-related issuers. Rule Instrument List Type "Securities-Related Issuers" (brokers, dealers, underwriters and investment advisers); "Affiliated Issuers" is limited to Section 17 and Rule 10f-3 tests. |
| SEC Rule 35d-1 (Names Rule), 2023 amendments | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.35d-1 | 80% investment policy; temporary departures with a 90-day return to compliance (Cure Deadline Date). Web search on 2026-10-06 confirmed the SEC's 14 March 2025 extension of the compliance dates to 11 June 2026 (fund groups with $1 billion or more in net assets) and 11 December 2026 (smaller groups). |
| SEC Rule 2a-7, as amended 2023 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.2a-7 | Issuer diversification, WAM (60 days) and WAL (120 days), daily (25%) and weekly (50%) liquid asset minimums, and minimal credit risk. Rule Types Maturity, Liquidity and Credit Quality; Internal Credit Assessment Used Indicator (CD-173). |
| SEC Rule 38a-1, Advisers Act Rule 206(4)-7, Investment Company Act Release No. 26299 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.38a-1 ; https://www.sec.gov/rules-regulations/2003/12/compliance-programs-investment-companies-investment-advisers (verified by the reviewer: Release No. 26299 / IA-2204) | Written policies, annual review (Periodic Rule Review), CCO report to the board and "material compliance matters" (Material Breach Indicator, Board Reportable Indicator). |
| ICA Rule 31a-2 and Advisers Act Rule 204-2 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.31a-2 ; https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.204-2 | Record retention, which is why rule versions are kept and each result cites a version. |
| SEC Rules 17a-7 and 10f-3 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.17a-7 ; https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.10f-3 | Transaction conditions that pre-trade rules may test (Rule Type "Transaction Test"). The cross trade and 10f-3 records stay in 25 (CD-224). |
| IRC Section 851(b)(3) | https://www.law.cornell.edu/uscode/text/26/851 | RIC quarterly diversification. 33 only monitors it pre-trade; the determination is 27's RIC Test Result (CD-224). |
| ERISA Sections 404(a)(1)(C), 406; DOL PTE 84-14 | https://www.dol.gov/agencies/ebsa/laws-and-regulations/laws/erisa | Diversification duty and prohibited transactions with parties in interest (Rule Instrument List Type "ERISA Party-in-Interest Issuers"). |
| OCC 12 CFR 9.18 | https://www.ecfr.gov/current/title-12/chapter-I/part-9/section-9.18 (confirm) | Collective investment fund rules for CITs. The specific diversification paragraph was not verified. |
| Charles River IMS, Aladdin, SimCorp (compliance modules) | https://www.crd.com (confirm) ; https://www.blackrock.com/aladdin ; https://www.simcorp.com | Structure only: rules, rule groups, assignments, pre- and post-trade checks, alerts and overrides. No field names reproduced. |

## 2. Design decisions and boundary calls

Sections 1 to 6 record the reasoning of the wholesale draft. Where they mention UCITS, AIFMD, FCA COLL, the EU MMF Regulation, MiFID II, CSSF, depositaries or ManCo boards, section 7 supersedes them: those values, the attribute and the sources were removed in the wealth model.

- **Restriction vs rule (CD-221).** Compliance Rule holds only coded logic, the coded limit and warning values, measurement basis, applicability, the hard / soft setting and version. Restriction text, Limit Value, Restriction Source and Category stay in 01 and are not repeated. A rule's limit may sit inside the source by an internal buffer; the difference is Rule Source Link.Buffer Versus Source (blank for client restriction and firm policy sources, which have no limit value).
- **Statutory limits are held once.** Regulatory Limit Provision is the master of statutory limit values. A 01 restriction with Restriction Source "Regulatory" is the prospectus restatement; proposals_33 asks 01 to add "Restated Regulatory Provision" (not edited here).
- **Rule sources.** 01 `RST-`, 02 `CRX-`, a Regulatory Limit Provision or a firm policy. 15 `ARX-` is never a source, and 24 Portfolio Construction Constraint is not a rule.
- **Versioning.**
  - A rule version (CRULE- x Rule Version) is effective-dated on its own (Timestamps). Only Approved or Approved with Conditions versions may carry a Version Effective From; Version Approved By and Version Approved Date record the approval.
  - Rule Status (Active, Paused, Retired) has its own effective dates on the version. A second pause of the same version closes the version and opens a new one, so pause history is never overwritten.
  - A Rule Library version is a dated set of rule versions held as Rule Library Membership rows; a new rule version creates a new library version, and a rule may belong to several libraries.
  - Rule Assignment pins a library version or a rule version, never a bare rule. Putting a new version in force for a portfolio closes the assignment row and opens a new one.
  - Rule Source Link is pinned to the rule version and has no dates of its own.
  - Date convention: a Date effective from or to is effective from the start of that day in the portfolio's (or library owner's) time zone.
- **Rule instrument lists (CD-224).** Rule Instrument List Member rows exist only for firm-maintained lists (Members Held Here Indicator = Y). Lists sourced from a 34 Sustainability Exclusion List or the 38 restricted list (text until Stage 4) are read at their source; no members, and no MNPI names, are stored in 33. Compliance Rule.Rule Instrument Lists Read links each rule to the lists it tests.
- **ERISA party-in-interest lists (deviation from brief §3, which says they come from 02).** Drafted as a firm-maintained 33 list because SME question 10 is open; if 02 maintains them, the list becomes a sourced list reading 02 (proposals_33 PROPOSED_CHANGES).
- **One limit, one owner (CD-223).** No risk measures, HLIM, VaR tests or `RLEX-` in 33. Rules of type Risk Measure Limit (for example AIFMD leverage caps) and concentration rules on OTC counterparties (UCITS Art 52(1)) name the 31 measure in Risk Measure Read or Exposure Method Read (the 31 "Risk Measure" and "Exposure Method" lists); the result points to the 31 record. Rule 2a-7 liquid asset minimums are 33 Liquidity rules; the Rule 22e-4 program is 31's.
- **Check here, order in 25 (CD-180, CD-221).**
  - A pre-trade run has one Pre-Trade Check Subject: a 24 Proposed Trade, a 25 Trade Order, a 25 Block Order or a 30 Deal.
  - For order and block subjects, a Check Subject Member row is held per tested order (each member order of a block), with Initial Check Outcome, the final Compliance Check Outcome and the Releasing Override. 25 copies the final outcome per order.
  - Row rule: 25 copies the outcome of the **latest run before release** that covered the order, whether checked alone or in a block. When an override changes the outcome, 25 records a second Compliance Checked event.
  - A run is recorded even when no rule applies, so "Not Checked" has a 33 master. Proposed trade and deal outcomes are on the subject row (Subject Check Outcome).
- **Results and breaches per issuer or group.** Compliance Rule Result is keyed run x portfolio x rule version x evaluated issuer, instrument or group, so two issuers over the same limit give two results and two breaches. Limit Applied is the limit after any Guideline Waiver (Applied Guideline Waiver). Numerator and Denominator are Decimals in the rule's measurement basis units.
- **Breach here, report in 12 and 35 (CD-222).** Investment Breach carries the five attributes 12 Breach Notification will re-note as **Derived copy (33)**, with identical names: **Breach Type, Breach Detected Date, Breached Restriction, Cure Action, Cure Date**. The primary source is a typed pair (Breached Restriction for 01, Breached Client Restriction for 02; at most one filled), and further sources of the same rule are Breached Source Restriction rows. proposals_33 asks 12 to add "Breached Client Restriction" too. 33 holds no client notification facts. Breach Closure Date is on the breach. The breach's origin is held once on the breach (Originating Alert or Originating Manual Check).
- **Regulator notification is 35's.** Breach Review keeps Regulatory Notification Required Indicator and Resulting Reportable Fund Event (35); the notified regulator and date are 35 Reportable Fund Event facts.
- **One loss, one home.** Related Trade Error (25) holds the loss when filled; Breach Loss Calculation is used only otherwise. Related NAV Error Case points to 27 `NEC-`.
- **Guideline waivers as data.** Waived Limit Value, Waived Measurement Basis and Waiver Scope Issuer hold the relaxed limit; Waiver Conditions keeps only what cannot be structured.
- **Key formats.** Only `CRULE-`, `CCHK-`, `CALERT-` and `BREACH-` are new, in the published formats. Libraries, provisions and lists use firm codes without a hyphenated stem; coding requests (`RCR 2026/0187`) and waivers (`GW 2026/0031`) use internal references. Sibling examples follow the owners' formats.

### Deviations from the brief

1. **Objects.** 25 objects (brief 22 ±3): Rule Library Membership, Check Subject Member and Breached Source Restriction were added after the review; Alert Disposition became a Business Object keyed by disposition sequence, so a reopened alert keeps earlier dispositions.
2. **Lists.** 22 local lists plus 9 shared copies. Added beyond the brief: Assignment Basis, Rule Instrument List Type, Check Run Trigger, Rule Review Outcome. "Hard or soft" is a Boolean (Hard Block Indicator); materiality is a Boolean plus Shared Severity; Manual Compliance Check reuses Compliance Rule Result Status. Alert Type and Pre-Trade Subject Type were removed (derivable).
3. **Regulatory Regime** copies the 01 values and proposes one addition ("ERISA Plan Assets"; "IRC 817(h) Insurance-Dedicated" removed at W5, CW-165) so those libraries can be scoped.
4. **Measurement Basis** copies the five 01 values and proposes six additions: % of Total Assets, Days, Ratio, Rating Notch, % of Commitments, % of Capital.
5. **Regulator** cannot yet hold the IRS; "IRS / US Treasury" is proposed for the shared list, and Provision Regulator stays blank for IRC provisions until then.
6. **Grains.** Rule Coding Request is keyed by request (no sequence); the rule version holds Originating Coding Request. An alert comes from one rule result.
7. **Breach Review** holds board and depositary escalation and the regulator-notification decision only; client notification is 12's and regulator notification 35's.
8. **Sources.** Added beyond the brief: EU MMF Regulation, CSSF Circular 24/856, and a separate Advisers Act Rule 204-2 row. Total 20.
9. **Size management.** Staying at 240 attributes after the review additions required removing low-value attributes:
   - first build: Prices As-Of Date, run counts, Warning Level Applied, remediation and coding request status fields, list and breach owner, Override Expiry Timestamp, Gain Retained, Next Review Due Date, Applicable Business Lines;
   - after the review: Library Owning Entity, Rule Library Name, Numerator / Denominator Definition (folded into Rule Logic Expression), Rule Information Classification, Source Policy Reference (use Interpretation Note), Assigned By, Assignment Mandate, Rule Instrument List Name, Request Received Date, Tested By, Coding Rules (derivable from Rule Source Link), Run Requested By, Compliance Engine (a system fact, SME question 1), Headroom (limit minus measured), Alert Type, Alert Closed Timestamp, Four-Eyes Satisfied Indicator, Maximum Excess, Breached Rule Version (the version in force at Breach Start Date), Loss Measurement End Date, Compensation Paid Date, Waiver Evidence Reference, Waiver Scope Group Key, Check Method Description, Pre-Trade Subject Type, Resulting Investment Breach and Check Resulting Breach (link held on the breach).

### Review response

All 5 High findings and all Medium findings were applied, with the program lead's decisions 1-7. Lows were applied except as follows:

| Finding | Response |
|---|---|
| C Low: define Headroom sign for minimum rules | Not applied as worded: Headroom was removed (derivable as limit minus measured value) to stay within 240 attributes. |
| D Medium: Rule Status pause history | Applied with status effective dates on the version (lead decision 4) rather than a separate status-history object; a second pause closes the version. |
| B Low: Alert Type derivable | Applied by removal rather than by a derived flag. |
| I Low / A Medium: 35 naming | Flag only (lead decision 1): "Investment Breach" and "Compliance Rule" are kept; the 35 brief, CD-234, "Compliance Breach Summary" and the 35 brief's "Guideline Rule" are listed in proposals_33 NOTES for the consolidation. |
| G Low: 27 vs 35 RIC determination | Reported to the consolidation (NOTES); 33 adds Evidential Period-End Run Indicator. Ownership is not 33's to decide. |
| H Low: OCC 12 CFR 9.18 paragraph | Left open (§3). |
| G Low: "(confirm)" markers | Removed for CSSF 24/856 and the SEC 38a-1 release (reviewer verified). Kept for FCA COLL 5, 26 CFR 1.817-5, 12 CFR 9.18 and crd.com, which the reviewer did not verify. |

## 3. What could not be verified

- The exact eCFR section URLs for 12 CFR 9.18 and 26 CFR 1.817-5 follow the standard eCFR pattern but were not fetched (eCFR blocks automated fetch). The 9.18 diversification paragraph needs confirming.
- The URLs for the FCA COLL 5 handbook page and crd.com are marked "confirm". The reviewer confirmed the 2a-7 liquidity minimums, the 817(h) tests, the AIFMD II limits and the 35d-1 extension against the texts.
- The UCITS article mapping (Arts 52-57) and the 817(h) percentages are from knowledge of the texts and were not re-read for this draft.
- The 2a-7 liquidity minimums (25% / 50%) reflect the 2023 amendments as understood. Confirm the effective dates with fund counsel.
- Sibling object names used (all present in the sibling modules per the review): 31 Leverage & Exposure Measurement, Counterparty Exposure, Portfolio Risk Measure; 34 Sustainability Exclusion List; 35 Board Resolution and Reportable Fund Event; 36 Product Change Initiative. Open naming decision (flag only): "Compliance Breach" remains in the 35 brief, CD-234 and the 35 value "Compliance Breach Summary", and the 35 brief calls the rule object "Guideline Rule".

## 4. Open questions for SMEs

1. Which compliance engines are used, and are institutional separate account and private feeder fund guidelines in the same engine as the funds?
2. Are internal buffers coded below prospectus limits, and who approves them?
3. Which restrictions are not codable today, and how are they monitored?
4. Who approves pre-trade overrides of hard rules, and are soft-rule overrides logged?
5. What is the breach materiality policy, and which breaches go to the board, the CIT trustee, the client or the regulator?
6. How are breach losses calculated, and who pays (adviser, sub-adviser, fund, insurer)?
7. Does compliance or the risk function monitor the 18f-4 and 22e-4 limits (CD-223)? Are Rule 2a-7 liquid asset minimums compliance rules (as drafted) or risk limits?
8. How are 38 restricted list entries delivered to the engine, and can 33 staff see the list itself?
9. Are rule libraries shared across funds with the same regime, and how are rule versions retained (Rule 31a-2 / 204-2)?
10. Are ERISA party-in-interest lists maintained by compliance or by 02?
11. (Closed at W5: insurance-dedicated funds are out of scope, CW-165.)
12. Does the engine evaluate a block per member order (as modeled with Check Subject Member), or only as a block, in which case the per-order outcome must be derived from the portfolio's rule results?
13. Which run is the evidential period-end run for RIC diversification, and who designates it?

## 5. Overlaps and hand-offs (for consolidation)

| Domain | Item | Proposal |
|---|---|---|
| 25 | Trade Order Event.Compliance Check Outcome | Derived copy (33) of Check Subject Member.Compliance Check Outcome (per order; latest run before release; second event after an override); the list is stewarded by 33 with values unchanged (CD-180, CD-221). |
| 12 | Breach Notification | Add Related Investment Breach (`BREACH-`). Five attributes become Derived copy (33): Breach Type, Breach Detected Date, Breached Restriction, Cure Action, Cure Date (CD-222). Add Breached Client Restriction; Breached Mandate stays 12's or is derived from the portfolio. Breach Type and Cure Action lists stewarded by 33. |
| 12 | Guideline Monitoring Arrangement, Compliance Certificate | Read Restriction Coding Status and Manual Compliance Check; no attribute change required. |
| 01 | Investment Restriction, Measurement Basis, Limit Type, Regulatory Regime | Regulatory restrictions reference 33 Regulatory Limit Provision; six proposed Measurement Basis values; two proposed Regulatory Regime values. |
| 09 | Shared Regulator | Add "IRS / US Treasury". |
| 35 | Board reports, Reportable Fund Event, RIC Qualification Determination | Reference Investment Breach and Compliance Rule Result; 33 Breach Review references Reportable Fund Event, which masters regulator notification. Naming conflict flagged only. |
| 31 | Measures read by rules | 31 "Risk Measure" and "Exposure Method" lists; no 31 values copied. |
| 34, 36, 38 | Exclusion lists, product changes, restricted list | Sourced lists read at source, no members stored (34, 38); 36 by reference; 38 text until Stage 4. |

Proposed changes to 12 and 25 are proposals only; neither module was edited.

## 6. Suggested validation steps

1. Walk one institutional separate account guideline, one 1940 Act diversified fund and one 2a-7 fund from restriction (01 / 02) through rule, assignment, pre-trade run, alert, override and breach, with the head of investment compliance.
2. Map Compliance Rule, Rule Assignment, Compliance Check Run and Compliance Alert to the engine's rule, group, assignment and alert tables.
3. Confirm with 25 the per-order copy, the latest-run-before-release rule and the second event after an override (SME question 12).
4. Confirm with 12 the five Derived copy attributes and the new reference.
5. Confirm the CD-223 split with the 31 author: the list of 31 measures 33 rules may read.
6. Withdrawn (W1b): no EU funds. Check the breach and loss attributes against the firm's breach and NAV error policy and the fund boards' reporting instead.
7. Re-run `taxonomy_builder.py content_33_investment_compliance` and `check_enrichment.py 33` after any sibling renames.

## Stage 3 consolidation (2026-10-06)

Changes made to this module at the Stage 3 consolidation (CD-241, CD-242; `_tools/consolidation/stage3_consolidation_notes.md`):
- Prefixes CRULE-, CCHK-, CALERT- and BREACH- registered with the published formats; no rename.
- Local copies of nine enterprise shared lists removed. Compliance Check Outcome, Breach Type and Cure Action became shared lists stewarded by 33, with 25 and 12 as members (CD-242).
- Guideline Waiver "Approving Board Resolution" replaced by "Board Approval Date", a Derived copy (35) read through 35 Resolution Subject Link (CD-237 ruling).
- Regulator "IRS / US Treasury" and the six Measurement Basis values were added in 01 and the shared list; the 33 copy of Measurement Basis now matches 01.
- 12 Breach Notification references the Investment Breach and copies its facts (CD-222); 25 copies the per-order check outcome (CD-180).
- Overrides for Source Risk Measurement and Resulting Reportable Fund Event dropped (they resolve now that 31 and 35 are registered). Blank sibling examples filled (TCOAL / 3, LCHG-2026-00118).

## 7. Wealth model carry-over (W1b, CW-933)

33 is kept (plan section 5.1). The pass made the changes CW-022 allows: the US-only pass, the perspective text and the Business Line example. Object and attribute names are unchanged except for the one removed attribute. The decision draft, the jurisdiction entries and the readers are in `_tools/consolidation/proposals_w1b_33.py`.

**Removed (EU/UK only; 18 jurisdiction entries: AIFMD 5, UCITS 4, Other EU/UK 4, FCA 3, MiFID II 1, Other non-US 1).**
- Breach Review: Depositary Notification Date. The two attributes after it (CCO Sign-Off By, CCO Sign-Off Date) move up one ID within Breaches & Remediation.
- Regulatory Regime (local copy of the 01 list): UCITS, UK UCITS, EU AIF, ELTIF, EU MMF, UK NURS, UK QIS, Lux SIF, Lux RAIF, Irish QIAIF and Cayman Regulated Mutual Fund, removed as in 01 (CW-901).
- Sources: UCITS Directive with Directive 2007/16/EC, FCA COLL 5, EU MMF Regulation, AIFMD with AIFMD II, MiFID II Delegated Regulation 2017/565 Article 54, CSSF Circular 24/856.

**Re-sourced.**
- The rule library examples now come from the 1940 Act:
  - library "1940 Act Diversified 75-5-10";
  - rule "ICA 12(d)(1)(A)(iii) investment companies 10% hard", measured on total assets;
  - provision "ICA 12(d)(1)(A)(iii) investment companies 10%".
- The Core model cites Sections 5(b)(1) and 12(d)(1)(A)(iii) and IRC 851(b)(3).
- Look-Through Indicator now rests on Rule 12d1-4, Exposure Method Read on Rule 18f-4 (a prospectus derivatives exposure cap), Cure Deadline Date on Rule 35d-1, and Material Breach Indicator on Rule 38a-1 alone.
- Loss Calculation Method, Related NAV Error Case and Regulatory Notification Required Indicator are now Internal, resting on the firm's breach and NAV error policy.
- Rule Type value descriptions now cite US rules.

**Perspective rewritten.**
- META subtitle.
- Overview: Purpose, Scope, Core model, Design principles (3), Notes (Regulation S-P, GLBA and state law) and Suggested next steps. The boundary with the client-account checks of 45, 46 and 48 is stated.
- "SMA" now reads "institutional separate account" (IA line, CW-009).
- ManCo and AIFM boards now read fund board or CIT trustee.
- 02 is named Client & Household (Client Restriction keeps its name, CW-021), and 25 Portfolio Trading & Execution.
- SUMMARY in `enrich_33.py`.

**Business Line (CW-004).** The Library Business Lines example is now "PF".

**Added.** Nothing.

**Left for later stages.**
- 30 Deal references, for W4: Tested Deal, the "Deal Pre-Approval" run type and the relationship.
- Insurance-dedicated residue: IRC 817(h) and Treasury Regulation 1.817-5, the NAIC Models 280 and 283, and the Regulatory Regime value "IRC 817(h) Insurance-Dedicated" were removed at W5 (CW-165).

**Open questions (W1b).**
1. Does a CIT trustee need its own breach notification date, now that the depositary date is gone? Today the trustee is informed through board and trustee reporting (35).
2. Should the shared Measurement Basis value "% of Capital" (AIFMD II single-borrower limit) be re-described for private fund documents or removed (steward 01)?

**Unverified.** The Rule 12d1-1 money market fund exclusion used in the Interpretation Note example is from working knowledge (confirm with fund counsel).
