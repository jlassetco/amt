# Source Notes: 34 Stewardship & Sustainable Investing

**Workbook:** `Stewardship_and_Sustainable_Investing_Data_Taxonomy.xlsx` (built from `_tools/content/content_34_stewardship_and_sustainable_investing.py`)
**Status:** Draft v0.2, wealth model (direct), scope US, 2026-10-14: the draft of 2026-10-06 (independent review applied) carried over with the US-only pass, the perspective rewrite and the investor choice addition of CW-934 (section 6). 7 families, 26 objects (24 business objects, 2 attribute groups), 237 attributes, 74 proposed CDEs (31%), 38 code lists (29 local, 9 enterprise shared lists cited directly), 49 relationships, 17 sources, 19 attributes flagged PII. Ownership: 65 references, 4 derived copies, 0 unresolved.

**Why this domain exists.** The firm is a US wealth manager: a direct brokerage platform, digital and human advice, its own mutual funds, ETFs and CITs, workplace recordkeeping, institutional advisory and optional trust services. Its investment stewardship team decides how the firm votes the shares its funds and the institutional separate accounts it manages hold, which voting policies it offers fund shareholders who want to choose (investor choice proxy voting), engages investee companies, and turns vendor and company-reported sustainability data into the firm's own assessments, climate metrics and stewardship reports. No other domain holds this record: 13 holds proxy solicitation of the firm's own fund shareholders and their voting choices (the reverse direction), 23 holds issuer meetings held for research, 17 holds meeting events as reference and 01 holds the ESG characteristics of products. Votes are regulated disclosures in their own right (Form N-PX, Rules 30b1-4, 14Ad-1 and 206(4)-6); climate and stewardship reports are voluntary (IFRS S2, PRI, NZAM). The EU/UK content of the wholesale draft (SFDR, PAI, EU Taxonomy, UK SDR, UK Stewardship Code, SRD II) was removed under CW-934 (section 6).

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| SEC Form N-PX and Rule 30b1-4 as amended by Release 33-11131 (adopted November 2, 2022; compliance from July 1, 2024; first filings by August 31, 2024) | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.30b1-4 | The 14 proposal categories (Audit-related; Capital structure; Compensation; Corporate governance; Director elections; Diversity, equity, and inclusion; Environment or climate; Extraordinary transactions; Human rights or human capital/workforce; Investment company matters; Section 14A say-on-pay votes; Shareholder rights and defenses; Other social issues; Other), verified against a law firm summary of the final release (K&L Gates, November 28, 2022). Per-vote fields: shares voted, how voted, shares loaned and not recalled, for or against management. Matter described in the issuer's form-of-proxy language. |
| SEC Rule 14Ad-1 | https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.14Ad-1 | Manager say-on-pay reporting where the manager has and exercises voting power; drives Voting Authority Holder and the "Form N-PX - Manager Say-on-Pay Report" type. |
| SEC Rule 206(4)-6 | https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.206(4)-6 | Written voting policies and conflict procedures, disclosure to clients of how to obtain their voting record; Voting Policy, Voting Guideline, Vote Decision Source, Client Account Voting Report. |
| SEC Schedules 13D and 13G and C&DI 103.12 (February 2025) | https://www.sec.gov/rules-regulations/staff-guidance/compliance-disclosure-interpretations/exchange-act-sections-13d-13g-regulation-13d-g (confirm) | Engagement that may affect passive-investor status; only a review flag is held (future owner 38). |
| SEC Rules 14a-1(l) and 14a-2(b)(9) (proxy voting advice) | https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.14a-2 | Proxy advisor as a proxy voting advice business; Recommendation Revised Indicator. |
| DOL 29 CFR 2550.404a-1 | https://www.ecfr.gov/current/title-29/subtitle-B/chapter-XXV/subchapter-F/part-2550/section-2550.404a-1 | Proxy voting duties for plan assets; the "Trustee" authority holder for CITs. |
| Delegated Regulation (EU) 2020/1818 Art 12 (PAB / CTB exclusions) | https://eur-lex.europa.eu/eli/reg_del/2020/1818/oj | Exclusion Policy Basis values Paris-Aligned and Climate Transition Benchmark Exclusions, kept as the index methodology of Paris-aligned and climate transition indexes the funds may track (CW-934, section 6); now a secondary reference only. |
| IFRS S2 (ISSB, June 2023; TCFD monitoring transferred to ISSB) | https://www.ifrs.org/issued-standards/ifrs-sustainability-standards-navigator/ifrs-s2-climate-related-disclosures/ | Financed emissions, climate metrics and targets. |
| PCAF Global GHG Accounting and Reporting Standard Part A | https://carbonaccountingfinancials.com/standard | Asset classes, attribution on EVIC or equity plus debt, data quality scores 1-5. Third edition (December 2025) per the brief, not verified. |
| GHG Protocol Corporate Standard and Scope 2 Guidance | https://ghgprotocol.org/corporate-standard | Scope list (location- and market-based Scope 2). |
| Net Zero Asset Managers initiative | https://www.netzeroassetmanagers.org (confirm) | Target types (portfolio decarbonization reference, portfolio coverage, engagement threshold) and AUM in scope. The 2025 relaunch wording was not verified. |
| PRI Reporting Framework | https://www.unpri.org/reporting-and-assessment (confirm 2026 modules) | Engagement themes and channels, assessment results. |
| ICGN Global Stewardship Principles | https://www.icgn.org (confirm edition) | Escalation practice. |
| ISS and Glass Lewis benchmark policies (public) | https://www.issgovernance.com ; https://www.glasslewis.com | Policy and guideline structure only. |
| ISO 20022 seev general meeting messages (seev.001, .004, .006, .007) | https://www.iso20022.org/iso-20022-message-definitions | Ballot, instruction, status and vote execution confirmation. |
| Broadridge ProxyEdge (vendor practice) | https://www.broadridge.com | Ballot control numbers. |
| ESG Data Convergence Initiative | https://www.esgdc.org (confirm) | Portfolio company metrics, held as Issuer Sustainability Observations. |

## 2. Design decisions and boundary calls

- **Investee votes here, fund shareholder votes in 13 (CD-226).** The investee meeting is a 17 Corporate Action Event; 34 adds agenda items keyed CAE- x item number and ballots keyed meeting x 28 SKA-. **Own-fund meetings:** a meeting of one of the firm's own funds is a 13 Proxy Campaign. 34 records a Ballot only where an own portfolio (for example a fund of funds) holds that fund as a shareholder; the ballot references the 13 PRX- (Own Fund Proxy Campaign) instead of a 17 CAE-, its vote instructions and rationale reference 13 Proxy Proposals (PRP-), and 13's Mirror / Echo Voted Shares tally is never copied. No other 13 object or list is used.
- **No meeting object; meeting date not repeated.** 17 has Record Date but no meeting date; proposals_34 asks 17 for one with the meeting event types (including Court Meeting, CMET). This blocks complete Form N-PX content until 17 adds it.
- **Vote cast held once; decision held once.** Vote Instruction (per ballot and item) holds Vote Cast and Shares Voted (instructed shares, as N-PX reports them). Vote Rationale is the firm's decision per agenda item and voting policy applied, so 40 ballots on one meeting share one rationale; each instruction references the rationale it implements. Vote Decision Source and Vote Decision Maker stay on the instruction because a portfolio manager override or client direction can apply to one portfolio only.
- **Ballot derived copies.** Record Date Shares (including shares on loan; = shares voted + not voted + on loan not recalled) copies 28 Corporate Action Entitlement.Eligible Balance through Ballot Entitlement, or the 18 holding for own-fund meetings. Shares on Loan Not Recalled is the 28 quantity on loan at the record date and not returned before it; 28 must add a dated on-loan quantity (proposed). The portfolio is read from the 28 safekeeping account assignment (Ballot Portfolio removed).
- **Recall: decision here, execution in 28 (CD-198).** Recall Requested Date is the stewardship team's request to the agent lender; 28 Recall Date is the agent's recall from the borrower.
- **Engagement is a case, not a meeting (CD-227).** The engaged party may be an issuer, a private portfolio company or, for market-wide engagement, a regulator or standard setter. Engagement Interaction has its own ID; Contact Medium is the medium only, and the 23 IMTG- reference shows when a 23 meeting record exists (no date, participant or topic repeated). 03 Advisor Activity is never used. Engagement Status uses the shared Case Status for workflow only (values such as Pending Good Order do not apply to engagements; brief-mandated); Engagement Outcome is separate.
- **One indicator vocabulary, typed by level (program lead decision 1).** Sustainability Indicator Definition carries Indicator Level (Issuer / Portfolio / Entity) and a unit per level (reference to 09 Unit of Measure); a portfolio indicator names its issuer input. Issuer values are Issuer Sustainability Observations and ESG Rating Observations (22 observation pattern). Portfolio, product and entity values are one object, Portfolio Sustainability Metric (grain: scope x period end x indicator x emission scopes x measurement basis, with unit and normalization currency), tagged with the frameworks it serves (TCFD / ISSB, NZAM, internal; the SFDR PAI and FCA ESG tags and the PAI Calculation statement were removed under CW-934). One financed emissions figure is held once. The former PAI Indicator Result, Portfolio Climate Metric and Climate Metric list are retired.
- **Firm view.** Firm ESG Assessment (ESGA-) is dated, versioned and approved. Exclusion lists have one policy basis each; members are effective-dated against the list code across versions. (The SFDR Sustainable Investment Determination was removed under CW-934.)
- **Commitment in 01, outcome in 34 (CD-229).** Superseded in the wealth model: Product Sustainability Outcome existed only for SFDR and UK SDR periodic disclosures and was removed under CW-934; ESG fund characteristics stay in 01.
- **35 links (stage-wide ruling, CD-237 over CD-225).** Board approval of a voting policy is held only on 35 Resolution Subject Link, and the N-PX filing only on 35's Filing Document rows (one per series' Proxy Voting Report). 34 holds no reference to 35.
- **Signatory status.** Removed under CW-934: the only body that granted status on a report was the FRC (UK Stewardship Code). PRI signatory status is the PRI Collaborative Initiative Membership; PRI assessment scores sit on the Stewardship Report (Framework Assessment Result).
- **Reports.** Proxy Voting Report and Stewardship Report have firm-defined identifiers (no new prefix). A proxy voting report selects vote instructions by rule (n : n), and a Client Account Voting Report type with a Reporting Client Account covers institutional separate accounts and other accounts that delegate voting.
- **Private markets.** No ballots; portfolio companies are engaged and observed through their 02 party (30 Portfolio Company Profile is keyed by PTY-). PCAF "Business Loans and Unlisted Equity" covers private equity and private debt; their attribution denominator comes from 30.
- **Per-row ownership (plan §4 item 9).** Attribution Denominator Value is owned by row: 22 pricing analytics for listed EVIC (primary, the enrichment owner), 14 licensed dataset for vendor EVIC, 30 fair value for private companies, a 14 sovereign dataset for PPP-adjusted GDP. Record Date Shares: 28 entitlement, else 18 holding.
- **Spelling.** "Proxy Advisor" is used throughout (program lead), keeping "adviser" only in regulatory terms (Sub-Adviser, investment adviser entity).

### Deviations from the brief

| Brief | Draft | Why |
|---|---|---|
| Say-on-pay indicator on Investee Meeting Agenda Item | Not held | Proposal Category "Section 14A say-on-pay votes" already carries it. |
| Vote Rationale as an attribute group of Vote Instruction | Business object per agenda item x voting policy | Review D, program lead decision 4. |
| PAI Indicator Result and Portfolio Climate Metric | One Portfolio Sustainability Metric | Program lead decision 1. |
| Signatory Status as an attribute group of Stewardship Report | Business object (entity x body x period) | Review D. |
| Voting Policy approval by 35 resolution | Held by 35 only | Stage-wide ruling. |
| Proxy Voting Report references the 35 filing | Held by 35 only (Filing Document) | Stage-wide ruling. |
| Local lists "Collaborative Initiative", "Engagement Channel", "Climate Metric", "Climate Metric Methodology", "PAI Scope Type", "Recall Reason" | Dropped or replaced: initiative is the 02 party; "Engagement Contact Medium"; indicators; "Metric Calculation Standard"; scope by which reference is filled; reason in Materiality Assessment | Review F and size. |
| New local lists | Vote Decision Source, Management Recommendation, Indicator Level, Sustainability Objective Type, Metric Measurement Basis, Metric Framework, Metric Calculation Standard, Outcome Disclosure Regime, PCAF Asset Class, Attribution Basis | Review findings and lead decisions; 33 local lists, one above the 24-32 target. |
| Shared lists Frequency, Period Type, Reporting Period Basis, Regulator, Business Line | Not used | No attribute needs them after the cuts. |
| Data Provider value "ISS" | Proposed as "ISS STOXX" (proposals only; local copy identical to the shared list) | Avoids confusion with ISS Market Intelligence. |

### Review response (2026-10-06)

The review (`00_Program/Expansion/Reviews/34_review.md`: 1 High, 22 Medium, 36 Low) and the program lead decisions 1-4 were applied, apart from the points below.

| Finding | Response |
|---|---|
| D [Medium] Lower priority: identifiers for ESG Rating Observation and Sustainable Investment Determination | Not applied. Both have composite grains and no other domain references them; add keys if a referrer appears. |
| F [Low] Voting Position "Case-by-Case" routes rather than states a position | Partly applied. "Refer to Committee" removed (Vote Decision Source has Stewardship Committee). "Case-by-Case" kept: it is a real default position in benchmark policies (no default, review on merits). |
| F [Low] Inclusion Type "Exclude" defined as a carve-out | Kept the shared list and asked 09 to widen the definition (the review's first option) rather than adding a local list. |
| G [Medium] Proxy Voting Report reports Vote Instruction | Cardinality changed to n : n with the selection rule; no report line object added (the review's alternative), noted in proposals for consolidation. |
| I [Low] Use "Proxy Adviser" throughout | Superseded by program lead decision 4: "Proxy Advisor", keeping "adviser" in regulatory names. |
| D [Medium] Move decision facts to the rationale | Rationale, pre-declaration, linked engagement and override approval moved; Vote Decision Source and Vote Decision Maker kept on the instruction (overrides can be per portfolio). |
| F [Low] Severity for vendor controversy; Case Status values | Vendor controversy column removed (raw vendor value held in ESG Rating Value under type "Controversy Level"); Case Status kept as the brief mandates, noted above. |

## 3. What could not be verified

- PCAF Part A third edition (December 2025) and any asset classes it adds (use of proceeds, securitizations, sub-sovereign debt): the list holds the second-edition classes.
- NZAM relaunch (October 2025) wording and target types; Climate Target Type follows the earlier NZAM target-setting categories.
- SEC C&DI 103.12 page location; whether Rule 14a-2(b)(9) conditions still apply after the 2022 amendments.
- PRI 2026 Reporting Framework modules; ICGN principles edition; ESG Data Convergence Initiative site.
- The four-milestone engagement scale is common practice, not a standard.
- Example identifiers, URLs on example.com and values are illustrative.

## 4. Open questions for client SMEs

1. Which voting platform and proxy advisor(s) are used, and is the house policy custom or an adopted benchmark policy?
2. Who approves voting policies and overrides: a stewardship committee, the 24 investment committee, or the fund boards (35)?
3. Are votes split across funds on the same meeting, and how often do portfolio managers override the stewardship team?
4. When are lent securities recalled for a vote (materiality rule), and who decides?
5. Do any institutional separate account clients or CIT trustees retain voting, and which funds offer investor choice proxy voting?
6. Is the firm's own ESG score per issuer one score or several (per strategy)?
7. Which data vendors feed climate metrics, and is estimated data permitted?
8. (Closed by CW-934: no SFDR PAI statement in the US model.)
9. Does the firm file the manager N-PX jointly with the funds' N-PX (35 filing record)?
10. Are exclusion lists firm-wide or per product, and which team owns them (stewardship or investment compliance)?
11. Which climate targets remain after the NZAM relaunch?

## 5. Recommended next steps

1. Boundary workshop with 13, 17, 23, 28, 33 and 35 to confirm the splits in section 2 and the CDE list.
2. Ask 17 to add the meeting event types (including CMET) and a meeting date (CD-226; blocker for N-PX content), 28 a dated on-loan quantity, and 02 the role types in proposals_34.py.
3. Map voting objects to the voting platform and advisor feeds and to ISO 20022 seev messages; map the climate metrics to IFRS S2 and the firm's voluntary climate report.
4. Agree the recall materiality rule with 28 and the securities lending agent.
5. Agree with 33 how coded rules cite the 34 exclusion list version, and with 31 who owns climate scenarios.
6. Register 34 as a member of the nine shared lists it copies and add the proposed Data Provider values.
7. Ask 31 to re-point Climate Metric Input to Portfolio Sustainability Metric, and 35 to use the 34 report ID format on its Filing Document rows.

## Stage 3 consolidation (2026-10-06)

Changes made to this module at the Stage 3 consolidation (CD-241, CD-242; `_tools/consolidation/stage3_consolidation_notes.md`):
- Prefixes VOTE-, ENGM-, ESGA-, PAIC- and VPOL- registered with the published formats; no rename.
- Local copies of nine enterprise shared lists removed. Data Provider gained ISS STOXX, Glass Lewis, Sustainalytics and CDP (Originating Provider example now CDP); MSCI ESG Research was not added.
- 02 Party Role Type gained Proxy Advisor, Proxy Voting Agent, Collaborative Engagement Initiative and Stewardship Framework Body (CD-143).
- 17 Corporate Action Event gained the meeting types MEET, XMET, OMET, BMET and CMET and a Meeting Date (CD-226). The 28 dated on-loan quantity is deferred.
- 31 Climate Metric Input now references Portfolio Sustainability Metric with the 34 key. All overrides kept (composite keys and 13 references).

## 6. Wealth model carry-over (W1b, CW-934)

34 is kept (plan section 5.1). The pass made the changes CW-022 allows and no others: the US-only pass, the perspective text, the re-pointed wording (institutional separate accounts, 02 Client & Household) and the one addition the plan names for 34. Object and attribute names are unchanged except for the removed objects and attributes, because DP-133, DP-134, DP-135 and the SM-08 sustainability views read 34 by name. The certified metric sources of SM-08 (official and benchmark returns, DP-145) are untouched: 34 feeds none of them. The decision draft and the jurisdiction entries are in `_tools/consolidation/proposals_w1b_34.py`.

**Removed (EU/UK only; 48 jurisdiction entries: SFDR 24, UK Stewardship Code 9, FCA 6, Other EU/UK 4, BMR 2, EU Taxonomy 2, FinDatEx 1).**
- Objects: Sustainable Investment Determination (SFDR Article 2(17), DNSH, good governance and EU Taxonomy alignment; 10 attributes); PAI Calculation (the SFDR principal adverse impact statement; 9 attributes); Product Sustainability Outcome (SFDR Article 8 and 9 and UK SDR periodic achieved proportions; 13 attributes); Signatory Status (FRC signatory status on a UK Stewardship Code report; 6 attributes). Their five relationships go with them.
- Attributes: Sustainability Indicator Definition.SFDR PAI Table and SFDR PAI Indicator Number; Portfolio Sustainability Metric.Reporting PAI Calculation and PAI Actions Taken.
- Code lists (whole): SFDR PAI Table, Sustainable Investment Framework, Sustainability Objective Type, Outcome Disclosure Regime, Signatory Status. Values: Metric Framework SFDR PAI, FCA ESG Sourcebook and EU Climate Benchmark; Metric Calculation Standard SFDR RTS Annex I and EU Climate Benchmark; Proxy Voting Report Type SRD II Voting Disclosure; Stewardship Framework UK Stewardship Code 2026 (both reports), FCA ESG Sourcebook (entity and product reports) and SRD II Engagement Policy Disclosure.
- Sources (9): UK Stewardship Code 2026; SRD II; SFDR; SFDR RTS; the Commission SFDR review proposal; the EU Taxonomy Regulation and Disclosures Delegated Act; the FCA ESG sourcebook and PS23/16; FinDatEx EET; the ICMA bond principles (used only by the removed determination; 17 keeps the sustainable bond label).

**Re-sourced.**
- Proxy voting disclosure stays on Form N-PX (Rule 30b1-4), Rule 14Ad-1 and Rule 206(4)-6: Vote Rationale Text and Pre-Declared Vote Indicator cite Internal and Rule 206(4)-6 instead of SRD II and the UK Stewardship Code; Vote Confirmation Status cites Internal and ISO 20022 seev.006 / seev.007 instead of SRD II Article 3c; Policy Document Location and Reporting Manager Entity lose the SRD II reference; the Client Account Voting Report value cites Rule 206(4)-6.
- Engagement: the Engagement family text names the Schedule 13D / 13G review (the source row now reads Schedules 13D and 13G and C&DI 103.12); Engagement ID, Engaged Party, Engagement Theme, Engagement Outcome, Objective Description, Interaction Summary, Escalation Action Type and the Engagement Theme and Escalation Action Type lists lose their UK Stewardship Code references (PRI, ICGN or Internal).
- Metrics: Indicator Name, Indicator Level, Indicator Unit, Metric Product, Metric Indicator, Metric Measurement Basis cite Internal; Metric Legal Entity and Normalization Currency cite IFRS S2; Metric Data Basis and Observation Data Basis cite PCAF; the SFDR and FCA ESG secondary references of Metric Period End Date, Emission Scopes Included, Metric Value and Metric Coverage Percentage are gone; examples in USD.
- Stewardship reports: Stewardship Framework re-cut to Firm Stewardship Report, Voluntary Climate Report (TCFD / IFRS S2), PRI Reporting Framework, Net Zero Asset Managers Progress Report and Other (the first two are the US instances of the removed UK Stewardship Code and FCA ESG reports); report identifier, entity, product, period, location and reported-engagement attributes cite Internal.
- Exclusions: Exclusion Policy Basis and Revenue Threshold Percentage cite Internal; the EU BMR Delegated Regulation 2020/1818 Article 12 stays as a secondary reference and a source row because Paris-aligned and climate transition index exclusions are index methodology of indexes a US fund may track (investment-universe principle, CW-022; see open question 1).

**Perspective rewritten.** META subtitle; overview Purpose, Scope, Core model, Design principles (6 and the new 10 on investor choice), Applies To, CDE, Notes and Suggested next steps; family texts of Stewardship Policies, Engagement, ESG Data & Assessments, Portfolio Sustainability Metrics & Product Outcomes (family name and code kept), Stewardship Disclosure & Reporting; the Firm Assessments and Stewardship Reports & Status group texts; SUMMARY in `enrich_34.py`. "Underlying investors" in pass-through voting reads "fund shareholders".

**Re-pointed (CW-021, CW-023; IA line).** "SMA account" and "SMA or institutional account" read "client account (an institutional separate account of the IA line or another account that delegates voting)" in the family text, the Voting Authority group, Authority Account, Reporting Client Account and the Account relationship note; the Proxy Voting Report Type value SMA Client Voting Report is relabeled Client Account Voting Report; the Ballot Safekeeping Account note reads "individual client". 02 is named Client & Household, 01 Investment Product & Service Offering, 13 Client Service & Communications. Every Reference (Party) and Reference (Account) still resolves.

**Added (plan section 5.1 row 34).** Investor choice proxy voting options on Voting Policy: Voting Choice Option Type (local list Voting Choice Option Type: Fund Adviser Policy, Board-Aligned, Third-Party Benchmark, Values-Based, Not Voting, Other) and Voting Choice Offered Funds (Reference (Product) (multi), the own funds whose shareholders may choose the policy), with the relationship "Voting Policy is offered as an investor choice option to shareholders of Investment Product [01]". The shareholder's election is left to 13 (W2). The Pass-Through Voting Choice values of Voting Authority Holder and Vote Decision Source now point to it.

**Left for later stages (not changed, listed in the proposals NOTES).** References to 30 (portfolio company profile, private company EVIC on Attribution Denominator Value and its row rule, the private markets boundary text) and to 13 (Proxy Campaign, Proxy Proposal, the investor choice election) stay. The ESG Data Convergence Initiative source (private company metrics) is a private-markets residue for W4.

**Open questions (W1b).**
1. Exclusion Policy Basis keeps the Paris-aligned and climate transition benchmark exclusions as index methodology; should a US firm restate them against the index provider's methodology document instead of the EU Delegated Regulation (tailoring lever)?
2. Which funds offer investor choice proxy voting, and are the option types the firm's program terms (Voting Choice Option Type is marked confirm)?
3. Does the firm publish a voluntary climate report, and does California's climate disclosure law (SB 253 and SB 261) reach it (confirm; not modeled)?
4. Should Signatory Status return as a generic object if the firm signs a US stewardship framework that grants status on a report?

**Unverified.** The Voting Choice Option Type values follow public descriptions of investor choice programs, not a rule (confirm); the SEC C&DI 103.12 page location (unchanged from the expansion).

**Review fix pass (2026-10-14).** The Schedule 13D / 13G source row now carries the SEC Division of Corporation Finance C&DI page for Exchange Act Sections 13(d) and 13(g) and Regulation 13D-G (confirm); Holding Value Used reads "portfolio holding (18)"; Voting Choice Option Type cites Internal only; IFRS S2 and PCAF are marked voluntary in the Sources tab and the overview Notes; SUMMARY reads "proxy advisors"; the ICMA entries say their regime tag is that of the removed object; READERS gain DP-132 (line 777) and line 978; the decision's domains list names 34 only. Not changed: the quoted review finding 'Use "Proxy Adviser" throughout' in the 2026-10-06 review response table (a quotation).
