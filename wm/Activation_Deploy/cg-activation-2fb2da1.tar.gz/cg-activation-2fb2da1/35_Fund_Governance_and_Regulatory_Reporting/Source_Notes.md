# Source Notes: 35 Fund Governance & Regulatory Reporting

**Workbook:** `Fund_Governance_and_Regulatory_Reporting_Data_Taxonomy.xlsx` (built from `_tools/content/content_35_fund_governance_and_regulatory_reporting.py`)
**Status:** Draft v0.1, wealth model (direct), scope US, 2026-10-14: the draft of 2026-10-06 (independent review applied) carried over with the US-only pass and the perspective rewrite of CW-935 (section 7). 6 families, 29 objects (23 business objects, 6 attribute groups), 249 attributes, 76 proposed CDEs (30.5%), 37 code lists (28 local, the rest shared or external lists cited directly), 47 relationships, 19 sources, 26 attributes flagged PII. 78 references, 3 derived copies, 0 unresolved.

**Why this domain exists.** The firm is a US wealth manager that sponsors its own mutual funds, ETFs and CITs (PF line). Every fund it sponsors is overseen by a governing body: the board of directors or trustees of a US registrant, the fiduciary committee of the trustee bank for the CITs (which may be the firm's own trust company) and, for any private feeder fund, the limited partner advisory committee. Fund legal and governance (the fund secretary, fund treasurer and fund CCO) and regulatory reporting produce the record of what those bodies approved and what the funds filed with regulators. No existing domain holds it: 01 holds the fund and a single "Governing Body" party reference, 13 delivers reports to shareholders, 27 prepares the numbers and 08 files distribution materials. Board approvals and regulatory filings are legal acts of the fund itself (Investment Company Act Sections 15 and 30), with their own officers, deadlines and certifications, and every filing relies on data mastered in five or more other domains. That is why they form a separate Data Domain, which files and approves but produces none of the measures it reports (CD-233, CD-234).

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| Investment Company Act of 1940, Sections 2(a)(19), 10, 15, 16, 30, 32 | https://www.law.cornell.edu/uscode/text/15/80a-15 | Interested person definition; board composition; written advisory contract, two-year initial term, annual continuance by the board or shareholders and by a majority of independent directors, the duty to request and evaluate information (15(c)), 60-day termination and termination on assignment; Section 16(a) election of directors; Section 32(a) auditor selection. |
| SEC Rule 0-1(a)(6) and (a)(7) | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.0-1 | The fund governance standards used as tests on Governance Standards Profile: independent majority, independent nomination, independent legal counsel, annual self-assessment, quarterly separate sessions, authority to hire staff. |
| SEC Rule 38a-1 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.38a-1 | CCO designation and compensation approved by the board including a majority of independent directors; annual written report; material compliance matters. |
| SEC Rules 2a-5, 12b-1, 15a-4, 17a-7, 17e-1, 17g-1, 18f-3, 18f-4, 22e-4, 30a-2 | https://www.ecfr.gov/current/title-17/chapter-II/part-270 | Board Report Type values (valuation designee, 12b-1, affiliated transactions, derivatives risk manager, liquidity program); Resolution Type values; fidelity bond minimum, annual approval and filing (Form 40-17G); officer certifications. |
| SEC Rule 6c-11(c) | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.6c-11 | ETF website disclosures (daily holdings, NAV, market price, premium / discount, median bid-ask spread, statement after a premium or discount above 2% for more than seven consecutive trading days). |
| SEC Rule 2a-7 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.2a-7 | MMF website disclosures; Forms N-MFP and N-CR. |
| SEC forms (N-PORT, N-CEN, N-CSR, N-PX, N-MFP, N-CR, N-RN, 24F-2, 40-17G, N-8F, N-14) | https://www.sec.gov/forms | Filing Form Type values, filers, periods, due-day rules, signatures, confidential treatment. |
| SEC EDGAR Filer Manual | https://www.sec.gov/edgar/filer-manual | Submission types (485APOS, 485BPOS, 497, 497K, N-CSRS, 24F-2NT), accession numbers, suspended filings, filing agents. Path to confirm. |
| Tailored Shareholder Reports, Release 33-11125 | https://www.sec.gov/files/rules/final/2022/33-11125.pdf | N-CSR filing of financial statements and of the board's basis for approving advisory contracts; Rule 30e-1 website availability. |
| SEC N-PORT proposal and Names Rule extension (February 18, 2026), law firm summary | https://www.stblaw.com/about-us/publications/view/2026/05/11/sec-proposes-amendments-to-form-n-port-and-extends-compliance-dates-for-names-rule-reporting-(registered-funds-regulatory-update) | Names Rule compliance extended to November 17, 2027 (fund groups of $10 billion or more) and May 18, 2028; proposal to reduce N-PORT public disclosure to quarterly and give 15 more days to file. Used in the Due Day Rule note. |
| SEC Form PF and the 2024 amendments; extension of August 31, 2026 (law firm summary) | https://www.mofo.com/resources/insights/260915-form-pf-amendments-compliance-date-extension | Compliance date of the February 2024 Form PF amendments moved from October 1, 2026 to July 1, 2027; an April 2026 proposal to modify or eliminate parts of them is pending. |
| OCC 12 CFR Part 9, Sections 9.4 and 9.18 | https://www.ecfr.gov/current/title-12/chapter-I/part-9 | CIT trustee fiduciary committee as a governing body type; collective investment fund plan and annual audit. |
| IRC Sections 851 and 852 | https://www.law.cornell.edu/uscode/text/26/851 | RIC qualification and cure provisions (817(h) removed at W5, CW-165). |
| Jones v. Harris Associates, 559 U.S. 335 (2010); Gartenberg v. Merrill Lynch (2d Cir. 1982) | https://www.supremecourt.gov/opinions/09pdf/08-586.pdf | The 15(c) Factor list and Renewal Material Type values. |
| Independent Directors Council (ICI) | https://www.idc.org | Board committee functions, lead independent director, 15(c) request practice, self-assessment practice. Specific publications not confirmed. |
| SEC exemptive orders | https://www.sec.gov | Exemptive Relief Type values (manager of managers, ETF share class relief, interfund lending; mixed and shared funding removed at W5, CW-165). Index page not confirmed. |
| ILPA Principles 3.0 | https://ilpa.org | LPAC composition and consents (Consent Type). |

## 2. Design decisions and boundary calls

Sections 1 to 6 record the reasoning of the wholesale draft. Where they mention UCITS management companies, AIFMs, UK AFMs, CSSF, the Central Bank of Ireland, FCA COLL, Annex IV or conducting officers, section 7 supersedes them: those values, the attribute and the sources were removed in the wealth model.

1. **35 files, others produce (CD-233, CD-234).** Fund Regulatory Filing holds the submission facts only: form, filer, period, due date, submitted timestamp, accession number, status, amendment link, effectiveness date and confidentiality. The values reported are reached through Filing Data Source (source type, record key, as-of date, reconciled indicator, sign-off), which is record-level evidence, not a 21 Lineage Link. No holding, NAV, return, liquidity bucket, VaR or breach is held here.
2. **Fund boards here, corporate boards in 39, management committees not at all (CD-231).** Governing Body Type has no value for a valuation, investment or product governance committee. The board committee that oversees the valuation designee is 'Valuation Oversight' (Board Committee Function), named so that it cannot be confused with the 22 Valuation Committee.
3. **Agreement and renewal here, fee terms in 01 (CD-232).** Fund Advisory Agreement references the 01 Fee Schedule (`FSCH-`) and holds no rate or breakpoint. The renewal holds dates, the approving resolution, the outcome and the continuation end date; its materials are references to 10, 11 and 32.
4. **One link per approval (CD-237, which prevails over CD-225 by program lead ruling).** Resolution Subject Link holds every approval of a subject outside 35 (01 product, share class or service-provider role, including CIT plan document adoption and amendment; 13 shareholder communication; 27 fund financial statement; 31 HLIM or risk program designation; 33 guideline waiver; 34 voting policy or proxy voting report; 36 proposal, change or review), the initial approval, amendment or termination of a Fund Advisory Agreement, and the approval of a RIC determination (identified by its 27 fund tax year). The consumers hold no approval reference, only a derived status (proposals_35 VALUE_PROPOSALS). 35 records whose grain is itself an approval event (Advisory Contract Renewal, Fund Fidelity Bond, Fund Officer Appointment, Exemptive Relief Reliance) carry their resolution reference and get no subject link, so no approval is held twice.
5. **The meeting date is held once.** An action by written consent is a Board Meeting of type 'Written Consent in Lieu of Meeting', dated on the effective date of the consent. Board Resolution therefore always has an Adopting Meeting and no adoption date of its own; votes on a board written consent are on Resolution Vote Count, and Board Consent Record counts apply to LPAC consents.
6. **Members are 02 or 20, never both.** Governing Body Membership has two typed references: External Member Party (02 `PTY-`: independent directors, LPAC representatives, officers of a third-party CIT trustee) and Interested Member Employee (20 `EMP-`). Interested Person Status is held on the membership because the status is assessed per body and per period.
7. **Determination here, tests in 27 and 33 (CD-191, CD-235).** RIC Qualification Determination references 27 RIC Test Results (the Section 817(h) reference was removed at W5, CW-165); it holds only the conclusion, cure narrative, approver and audit committee review.
8. **ETF and MMF disclosures read 18, 22 and 24 (CD-177, CD-206).** Fund Public Disclosure holds publication facts and the persistent premium / discount statement trigger; the statistics are 22 ETF Market Statistic and the holdings cross-check is the 24 ETF Basket.
9. **Governed Fund Coverage.Covered Business Line is a Derived copy (18)** of the Business Line on the portfolio that implements the fund (CD-209), not a 35 classification.
10. **Effective dating.** Coverage, memberships, officer appointments, filing obligations and relief reliance carry Effective From / To. The Governance Standards Profile has one row per assessment date.
11. **CIT trustees (program lead decision 3).** A CIT trustee fiduciary committee is a Fund Governing Body whose Governed Entity (affiliated trustee, `LEN-`) or Governed Trustee Party (third-party trustee, `PTY-`) is filled, exactly one. Resolution types cover CIT plan document adoption and amendment (12 CFR 9.18(b)(1)) and the annual audit review (9.18(b)(6)); trustee bank officers have their own Interested Person Status value. 36 'CIT Trustee Approval' rows become Derived copies (35).
12. **Filing grain (program lead decision 4).** Fund Regulatory Filing is keyed by filer x form x reporting period end or event / as-of date x event reference x submission sequence. Registration and prospectus filings (485, 497, N-14) use Event or As-Of Date instead of a period; event-driven forms carry an Event Reference so same-day filings do not collide; amendments are identified only by Amended Filing. Periodic filings reference their Filing Obligation (Met Obligation); event-driven forms have no obligation row. Submitted Timestamp, Acceptance Timestamp and Official Filing Date (CDE, the date timeliness is measured on) are separate.
13. **Per-fund advisory terms (program lead decision 5).** Agreement Fund Schedule (agreement x fund x approval cycle) holds the 01 fee schedule, the 13 proxy proposal (`PRP-`) by which shareholders approved the agreement, the shareholder approval date (Derived copy 13) and the per-fund outcome and continuation end date of each renewal.
14. **Documents filed.** A Filing Document child row holds each shareholder report (one per share class under tailored shareholder reports), prospectus or SAI, and N-PX voting report transmitted. The N-PX link is held only here (34 drops its back-reference). The change-to-filing link is held only by 36 (Satisfying Filing); 35 dropped 'Originating Change Initiative'.
15. **Board reports** are keyed by meeting, type, period and the reported funds or 31 risk program; Board Report Source Items hold the many breaches, exceedances and fair value determinations a report discusses.

**Deviations from the brief:**

- **Sibling names.** The brief's expected names were replaced by those in the 31-34 and 36 modules (now confirmed against the modules): 31 'VaR Test Result' (not 'Derivatives VaR Test Result'), 'Risk Limit Exceedance' (`RLEX-`), 'Fund Liquidity Profile', 'Risk Program Designation'; 32 'Performance Return' (`RETURN-`, not 'Share Class Return'); 33 'Investment Breach' (`BREACH-`, not 'Compliance Breach'), 'Guideline Waiver' and 'Compliance Rule Result'. 31 has no 'Liquidity Risk Program Report' object, so that report is a Board Report Received type.
- **Fund Regulatory Filing grain.** Not obligation x period x sequence: see decision 12 (event-driven filings have no obligation; periodic filings reference it optionally).
- **Board Consent Record** moved from Fund Regulatory Status to Board Approvals & Resolutions (the family of its parent, Board Resolution).
- **Written consents** are modeled as a Board Meeting type (decision 5) rather than as a resolution without a meeting.
- **Audit committee financial expert** is a Boolean on the membership, not a Member Role value, so that Member Role stays positional (chair, lead independent, member).
- **Governance Standards Profile** has no 'self-assessment date'; the date is held once on Board Self-Assessment. The 'independent chair' test is held as a practice indicator because the 2004 independent chair and 75% conditions were vacated (to confirm with counsel).
- **Agreement Termination Reason and Due Day Basis** are text rather than local lists, which keeps the domain at 28 local lists (brief target 22-28).
- **Sizes.** 6 families and 29 objects (brief 26 +/- 3, after adding Board Report Source Item, Agreement Fund Schedule and Filing Document in the review pass). The attribute count was held at 248 (inside 200-250) by dropping low-value attributes during the review pass: Independent Chair Indicator, Members Present Count, Minutes Approving Meeting, Presenter Party, Assessment Method, Assessment Discussion Meeting, Consent Solicitation Date, Joint Insured Bond Indicator (derivable from Insured Funds), Termination Notice Days, Supplemental Request Indicator, Material As-Of Date, Filing Preparer Party (the filing keeps Filing Agent Party), Reporting Period Type (with the Period Type list), Reconciliation Exception Count, Order Date (in the citation) and Voting Member Indicator (the Observer and Advisory Board Member roles say it).

### Review response

The independent review (`00_Program/Expansion/Reviews/35_review.md`: 3 High, 12 Medium, 32 Low) was applied with the program lead's decisions 1-6. All High and Medium findings were applied. Applied differently or not applied:

- **F (Low) / decision 4, "On Event" in the obligation frequency:** Filing Frequency uses an exact copy of the shared Frequency list, so the value cannot be removed without breaking the membership. Its definition now excludes 'On Event' and states that event-driven forms have no obligation row.
- **A (Low), Persistent Premium or Discount Statement Required Indicator:** kept as mastered here with a note that 35 computes it from the 22 ETF Market Statistic series; it is a 35 disclosure determination, not a copied value.
- **B (Low), Certifying Officer Role:** kept, noted as derivable from the Fund Officer Appointment; the form records the capacity in which the officer signed.
- **B (Low), Determined Fund:** kept as the key, with a note that it must equal the fund of the tax year record.
- **B (Low), written consent counts:** Consent Type keeps one 'Board Written Consent' value; the definitions say board written consent votes are read from Resolution Vote Count and the consent counts apply to LPAC consents.
- **C (Low), Factor Satisfied Indicator:** dropped rather than recast; the finding text holds the board's characterization, and no per-factor conclusion list was added (keeps the local list count at 28).
- **D (Low), joint meetings:** not remodeled; one Board Meeting row per body, with a note and SME question 13.
- **D (Medium) / decision 5, per-fund renewal outcome:** Agreement Fund Schedule includes the approval cycle (initial or `RENEW-`) in its grain, so the per-fund outcome keeps its history.
- **G (Low), home-page URLs for IDC, SEC exemptive orders and ILPA:** not replaced, because no specific page was verified; they stay listed in §3.
- **Regulator (Low):** 'IRS' was added to the local copy of the shared Regulator list and proposed as a new shared value (proposals_35 SHARED_MEMBERSHIPS); until it is accepted the local list differs from the shared list by that one value.

## 3. What could not be verified

- The current eCFR text of Rule 0-1(a)(7) after the vacated 2004 amendments: the six tests used are taken from memory of the rule and must be confirmed by counsel.
- The SEC release page for the February 2026 N-PORT proposal and Names Rule extension (only a law firm summary was checked), and the outcome of that proposal (N-PORT is still modeled as monthly).
- The SEC release page for the August 31, 2026 Form PF extension (a law firm summary was checked) and the April 2026 Form PF proposal.
- The SEC EDGAR Filer Manual path and the current list of investment company submission types.
- CSSF Circular 18/698 page, CSSF and Central Bank of Ireland return codes (held as generic 'CSSF Periodic Return' and 'Central Bank of Ireland Fund Return'), and the COLL reference for the UK fund report directors' statement.
- Whether a "Rule 498B" exists: it was not used or cited.
- IDC publications and the SEC exemptive order index page (generic URLs only).
- Whether the in-person voting requirement for 15(c) approvals still has standing relief for virtual meetings; Meeting Format is held so the answer can be recorded either way.
- The Regulation S-T rule that sets the EDGAR official filing date for submissions accepted after the daily cut-off (cited generically on Official Filing Date).
- SEC Rule 38a-1(a)(4)(iii)(A) as the subparagraph for the annual report and material compliance matters (per the review; to check against the eCFR).

## 4. Open questions for client SMEs

1. How many fund boards and clusters are there, and do committees have separate charters?
2. Who prepares 15(c) materials (in house or a vendor such as Broadridge), and is there one agreement per fund or per trust?
3. Which filings are prepared in house and which by an administrator or filing agent (CD-147)?
4. Does the firm file the manager N-PX jointly with the funds' N-PX?
5. Is the CIT trustee bank an affiliate (internal `LEN-`) or a third-party trustee (02 `PTY-`)?
6. Withdrawn (W1b): no UCITS management company or AIFM.
7. Are LPAC consents recorded by fund legal or by private markets (30)?
8. Who makes the RIC qualification determination: the fund treasurer, tax or the audit committee?
9. Which exemptive orders do the funds rely on (ETF share class, manager of managers, interfund lending)?
10. Does the board receive breach summaries directly from 33, or via the CCO report?
11. Is the Form 1120-RIC filing tracked by fund legal / treasury as a regulatory filing (CD-191), or by fund tax only?
12. Can 31, 33 and 34 show a derived approval status from 35 Resolution Subject Link in their systems, now that they hold no approval reference (CD-237 ruling)?
13. Do several trust boards meet jointly, and if so is one set of minutes kept per board or one for the joint meeting?

## 5. Overlaps with other domains (for consolidation)

All proposed, none applied (see `_tools/consolidation/proposals_35.py` VALUE_PROPOSALS):

- 01 Product Governance 'Governing Body' re-types to Reference (Fund Governing Body, 35); 01 Product Party Role Type 'Board of Directors' retired (CD-231).
- 01 Regulatory Authorization 'Regulatory Reporting Obligations' becomes a Derived copy (35) of Filing Obligation (CD-233).
- 13 'Regulatory Filing Reference' and 'Form N-CSR Filing Date' become Derived copies (35) of the N-CSR filing's accession number and Official Filing Date (CD-233). 35 Publication Timestamp on shareholder report website rows is a Derived copy of 13 Website Availability Date.
- 10 Revenue Contract 'Underlying Agreement' re-types to Reference (Fund Advisory Agreement, 35) on fund advisory rows (CD-232).
- 27 Fund Tax Return Type filing evidence becomes a `REGF-` reference (CD-191).
- 02 Party Role Type gains 'Independent Fund Director / Trustee', 'Independent Counsel to Fund Directors', 'Fidelity Bond Insurer', 'Fund Filing Agent', 'LPAC Member Representative' and 'CIT Trustee Bank' (CD-143).
- CD-237 over CD-225: 31 drops HLIM Board Approval and Program Board Approval, 33 drops Guideline Waiver Approving Board Resolution, 34 drops Voting Policy Approving Board Resolution and Proxy Voting Report Voting Report Filing; 36 Fund Board Approval and CIT Trustee Approval requirement rows become Derived copies (35). 36 keeps Satisfying Filing (the change-to-filing link).
- 'Resolution Outcome' renamed 'Board Resolution Outcome' (14 has an unrelated list of the old name).
- Term conflicts: Board, Committee, Meeting, Filing, Agreement, Resolution, Disclosure, Approval.

## 6. Suggested validation steps

1. Walk one fund through a year with the fund secretary: board coverage, four regular meetings, the 15(c) meeting, the resolutions adopted and the subject links they create.
2. Walk one N-PORT, one N-CSR and one N-RN with regulatory reporting: obligation, filing, certification, data sources and the 13 / 31 / 33 records referenced.
3. Check the Filing Form Type list against the EDGAR submission types the funds actually used in the last two years.
4. Check Governed Fund Coverage against the SAI board tables and the N-CEN registrant data.
5. Confirm the Rule 0-1(a)(7) tests and the 15(c) in-person voting position with counsel to the independent directors.
6. Re-run the builder after the 31, 33, 34 and 36 fix passes and check that no sibling still holds a board-approval or N-PX filing reference.

## Stage 3 consolidation (2026-10-06)

Changes made to this module at the Stage 3 consolidation (CD-241, CD-242; `_tools/consolidation/stage3_consolidation_notes.md`):
- Prefixes BOARD-, BMEET-, RESO-, ADVA-, RENEW- and REGF- registered with the published formats; no rename.
- Local copies of nine enterprise shared lists removed; "IRS" is the shared Regulator value "IRS / US Treasury".
- Sibling examples aligned to the owners' key formats (31 grain keys, 32 Benchmark Return, 33 Compliance Rule Result, 34 Proxy Voting Report, 36 PRVW- with its 2-digit sequence); six composite-key overrides added. Board Report Type value renamed "Investment Breach Summary".
- 10 Revenue Contract Underlying Agreement references the Fund Advisory Agreement on fund advisory rows (CD-232, CD-022 superseded). 02 Party Role Type gained Independent Fund Director / Trustee and Independent Counsel to Fund Directors; the other four proposed roles are deferred.
- Notes that called the 33, 34 and 36 link removals "proposed" now record them as done (CD-237, CD-230, CD-233).

## 7. Wealth model carry-over (W1b, CW-935)

35 is kept (plan section 5.1). The pass made the changes CW-022 allows: the US-only pass, the perspective text, the Business Line example, and the re-sourcing of filings that the brief names. Object and attribute names are unchanged except for the one removed attribute. The decision draft, the jurisdiction entries and the readers are in `_tools/consolidation/proposals_w1b_35.py`.

**Removed (EU/UK only; 32 jurisdiction entries: UCITS 9, FCA 8, Other EU/UK 8, AIFMD 7).**
- Governance Standards Profile: UK AFM Independence Requirement Met Indicator. Governance Standards Met Indicator, the attribute after it, moves up one ID.
- Governing Body Type: UCITS management company, AIFM, self-managed (SICAV, ICAV, OEIC) and UK AFM boards.
- Governed Fund Coverage Basis: umbrella sub-fund, management company, AIFM and AFM coverage.
- Interested Person Status: the two non-US standards.
- Fund Officer Role: Conducting Officer, Designated Person, Money Laundering Reporting Officer.
- Board Report Type: Conducting Officer Report, Assessment of Value Report.
- Advisory Agreement Type: the UCITS and AIFMD delegations.
- Filing Form Type: AIFMD Annex IV, the UCITS annual and semi-annual report filings, the CSSF and Central Bank of Ireland returns, FCA authorized fund reports.
- Filing Certification Type: the Annex IV sign-off and the UK directors' statement.
- Reportable Event Type: UCITS, AIFMD and UK breach notifications.
- Sources: AIFMD with Regulation 231/2013 Annex IV and AIFMD II; UCITS V with CSSF Circular 18/698; FCA COLL.

**Re-sourced.**
- The filings are the SEC forms already listed: N-PORT, N-CEN, N-CSR and N-CSRS, N-1A, N-PX, 24F-2NT, N-MFP, N-CR, N-RN, 40-17G and the 485 and 497 series.
- As the brief names, Filing Form Type gains "State Notice Filing (NSMIA)", and the sources gain Securities Act Section 18. It is not yet settled whether 35 or 08 owns these filings (question 2 below).
- Obligated Entity and Filer Entity now rest on Form PF. Governing Body Type, Governed Entity and Officer Entity now rest on the Investment Company Act Section 10 and OCC 12 CFR 9.
- Reportable Event Type now rests on Forms N-RN and N-CR and Section 22(e). "Suspension of Dealing" is now described as a Section 22(e) suspension of redemptions.
- The Financial Statements Approval and RIC "Not Applicable" descriptions were reworded for US funds and CITs.

**Kept for later decisions (W4).**
- Form PF, which goes with 30 if the firm has no private funds.
- LPAC values, consents and the ILPA source.
- Board Consent Record.Related Private Fund Deal (30 `PDL-`).
- The Section 817(h) result, its list and "Mixed and Shared Funding" (insurance-dedicated funds): removed at W5 (CW-165; Relied 817(h) Rule Results removed too, readers in proposals_w5_content REPOINTS).

**Perspective rewritten.**
- META subtitle.
- Overview: Purpose, Scope, Core model, Notes (Regulation S-P, GLBA and state law) and next step 6. The Purpose states that firm-level filings are 38 and 19.
- Family texts of Bodies & Coverage, Governance Standards and Filing Obligations, and the definitions that named management companies, AIFMs or AFMs.
- SUMMARY in `enrich_35.py`.

**Business Line (CW-004).** The Covered Business Line example is now "PF".

**Added.** Filing Form Type "State Notice Filing (NSMIA)" and the Securities Act Section 18 source (the re-sourcing the brief names). In the review fix pass, by program-lead ruling: Filing Obligation.Obligation Filing State and Fund Regulatory Filing.Filing State (ISO 3166-2 US subdivision), so a state notice filing is one obligation and one filing per state; both grains now carry the state. The attribute IDs after them in Regulatory Filings & Disclosures move down. Covered Series no longer says "sub-funds".

**Open questions (W1b).**
1. Does the firm offer private feeder funds that file Form PF? If not, Form PF and the LPAC content go with 30 at W4.
2. Who owns the state notice filings for the funds: fund regulatory reporting (35) or the distribution compliance successor (08)? This is settled at W2; if 08 takes them, the value, the two Filing State attributes and the source move with them.
3. 36 still keys product reviews "...-AOV-..." (assessment of value). Subject Product Review keeps the example until 36 re-keys it.

**Unverified.** Securities Act Section 18(b)(2) (covered securities of registered investment companies) and Section 18(c)(2) (state notice filings and fees) as the NSMIA paragraphs (confirm).
