# Source Notes: 36 Product Development & Lifecycle

**Workbook:** `Product_Development_and_Lifecycle_Data_Taxonomy.xlsx` (built from `_tools/content/content_36_product_development_and_lifecycle.py`)
**Status:** Wealth manager (direct), Scope: US. W4 adaptation draft v0.1, 2026-10-15, revised after review (`00_Program/Rework/Reviews/36_review.md`, fix pass below) (brief `00_Program/Rework/Briefs/36_Product_Development_and_Lifecycle.md`; decisions CW-161, CW-164, CW-169, CW-170 and CW-936 in `proposals_w4_economics.py`, drafted CW-936 in `_tools/consolidation/proposals_w4_36.py`). 5 families, 24 objects (18 business objects, 6 attribute groups), 250 attributes, 84 proposed CDEs (33.6%), 30 local code lists (24 lists of its own, 6 copies of 01 and 15 lists) plus 13 enterprise shared lists cited directly (43 in all), 51 relationships, 27 sources. 78 references to other Data Domains, 8 derived copies, 6 ownership overrides, 4 row ownership rules, 0 unresolved. (First W4 draft: 9 BO / 15 AG, 85 CDEs, 76 references.) Before the adaptation (wholesale v0.1): 23 objects (18 BO, 5 AG), 230 attributes, 78 CDEs, 40 code lists, 41 relationships, 20 sources, 63 references.

**Why this domain exists.** Product management of a direct wealth manager runs one governed pipeline for everything a client can buy: a new fund, ETF or CIT share class, a fund merger or liquidation, a mutual fund to ETF conversion, a new digital or hybrid advice program, a change to the fee schedule of an advice tier, a brokerage platform feature such as fractional shares or extended-hours trading. Each moves through proposal, business case, committee approval, a regulatory clock (Rule 485(a), Rule 17a-8, Form ADV and Form CRS amendments, advance fee notices), launch readiness and periodic review. 01 records what the offering is once it exists, 35 the fund board's resolutions and fund filings, 47 the client fee schedule, 15 the accounts that enroll; none of them holds the initiative, its approvals and its evidence (CD-236, CW-036). The wholesale 36 governed funds for a manufacturer selling in the US and under UK and EU product governance; the wealth 36 keeps the fund pipeline, drops the UK and EU apparatus and extends the same objects to advice services and platform features (CW-161).

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| SEC Rule 485 and Rule 497 | https://www.ecfr.gov/current/title-17/chapter-II/part-230/section-230.485 | 485(a) amendments effective 60 days after filing, 75 days for a new series; 485(b) for non-material updates; 497 supplements. Fund Filing requirement types (kept). |
| SEC Form N-1A | https://www.sec.gov/files/form-n-1a.pdf | Item 3 fee table: Projected Total Annual Operating Expense (renamed from Projected Ongoing Charge); class fee terms. |
| SEC Rule 6c-11 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.6c-11 | New ETFs and ETFs created by conversion; listing readiness (kept). |
| ETF share class exemptive relief (Dimensional notice IC-35770, September 29, 2025, File No. 812-15484; order IC-35786, November 17, 2025) | https://www.sec.gov/files/rules/ic/2025/ic-35770.pdf | ETF Conversion Route values; Exemptive Relief requirement type (kept; the order PDF was not opened). |
| SEC Rule 17a-8; Forms N-14 and N-8F | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.17a-8 ; https://www.sec.gov/files/formn-14.pdf ; https://www.sec.gov/files/formn-8f.pdf | Mergers, board determinations, deregistration (kept; form URLs resolve, review web check). |
| SEC Rule 35d-1 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.35d-1 | 80% policy and 60 days' notice; now also the source of Minimum Notice Days (re-sourced from COLL). |
| SEC Rules 22e-4 and 2a-5 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.22e-4 ; https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.2a-5 | Liquidity evidence for liquidations and mergers (31); fair value process a new fund's pricing set-up must cover (22). |
| Investment Company Act Sections 13(a) and 15 | https://www.law.cornell.edu/uscode/text/15/80a-15 | Shareholder vote on fundamental policy changes (13(a)) and on advisory contracts (15(a)); source of Shareholder Vote and Shareholder Adverse Indicator. Section 26(c) left with Fund Substitution (CW-165). |
| Investment Company Act Rule 3a-4 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.3a-4 | Proposed Rule 3a-4 Program Indicator and the discretion fields of Service Offering Specification; quarterly written notice and contact at least annually. |
| Form ADV Part 2 (including Appendix 1) and Advisers Act Rules 204-1, 204-3 | https://www.sec.gov/files/formadv-part2.pdf | Wrap fee and program brochure amendments as requirement types; amended promptly when materially inaccurate and annually. |
| Form CRS (General Instruction 8) and Exchange Act Rule 17a-14 | https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.17a-14 | Form CRS Amendment (within 30 days, General Instruction 8) and Form CRS Change Communication to existing retail investors within 60 days (Rule 17a-14(c)(4)), evidenced by 13 Recipient Delivery Records. |
| Exchange Act Rule 15l-1 (Regulation Best Interest) | https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.15l-1 | Proposed Advisory Capacity (with the Advisers Act). |
| NASD Notice to Members 05-26, NASD Recommends Best Practices for Reviewing New Products (April 2005), reiterated by FINRA Regulatory Notice 12-03, Heightened Supervision of Complex Products (January 2012) | https://www.finra.org/rules-guidance/notices/05-26 ; https://www.finra.org/rules-guidance/notices/12-03 | New product vetting: product committee, approval process, post-approval review. Replaces FCA PROD 3 and the ESMA guidelines as the practice source of the committee, decision types and review types. |
| FINRA Regulatory Notice 22-08 | https://www.finra.org/rules-guidance/notices/22-08 | Complex products and options: heightened review of platform features for self-directed clients. |
| FINRA Rule 1017 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/1017 | Continuing membership application: the US Regulator Prior Approval value (replaces the UCITS competent authority approvals; confirm when a feature triggers it). |
| FINRA Rules 2265, 3110, 4530 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2265 ; https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110 | Extended hours disclosure; written supervisory procedures as readiness evidence; complaint reporting as review evidence. |
| NSMIA, Securities Act Section 18 | https://www.law.cornell.edu/uscode/text/15/77r | State notice filings (35) replace the 01 country registration workstream. |
| SEC IM Guidance Update 2017-02 (robo-advisers) | https://www.sec.gov/investment/im-guidance-2017-02.pdf | Digital advice offering considerations. |
| IRC Section 368(a); OCC 12 CFR 9.18 | https://www.law.cornell.edu/uscode/text/26/368 ; https://www.ecfr.gov/current/title-12/chapter-I/part-9/section-9.18 | Tax-free reorganizations; CIT written plan approved by the bank's board (9.18(b)(1)) and annual audit (9.18(b)(6)); a state-chartered trust company trustee follows state law mirroring 9.18 (confirm). CIT Annual Review is sourced to firm and trustee practice. |
| openfunds; Morningstar Category; ISO 3166 / 4217 / 8601 / 10383 | https://openfunds.org ; https://www.morningstar.com ; https://www.iso.org | Share class fields (market-neutral); peer category; formats (kept). |

Removed sources (CW-936, JURISDICTION): FCA COLL 4.3 and 6.6.20R-6.6.21R; FCA PROD 3 and PRIN 2A; ESMA Guidelines on MiFID II product governance; UCITS Directive Chapter VI; PRIIPs Regulation and FCA PS25/20; FinDatEx EMT and EFT.

## 2. Design decisions and boundary calls

- **Initiative here, record of the offering in 01 (CD-236, CW-036).** Service Offering Specification and Platform Feature Specification hold proposed values only; on launch 01 creates the Service Offering (OFFR-), Offering Eligibility Rule or Tradable Universe Policy Rule (TUP-), and 36 references the created record (Created Service Offering, Governing Policy Rule). 36 never holds the live offering, a rule's criteria or an eligibility threshold after launch. Platform feature eligibility (eligible offerings and registration types, required disclosure, client activation) has its live home in a 01 platform feature object of the Brokerage Platform Offering family; the four 36 attributes are its proposed values, and the 01 object is a merge edit for 01 (program-lead ruling, review High).
- **Approval by the right body.** Fund changes need 35 Board Resolutions, read through 35 Resolution Subject Link (CD-237); program and feature changes are approved by the product committee (36 Product Approval Decision) under 38 policies. A review never stores a board decision; the AFM board approval date left with the US pass.
- **Price economics in 10, price in 47 (CW-158).** A Program Pricing Change has a Proposed Term Change of term Advisory Fee Schedule that references the proposed 47 schedule version (CLFEE-, status Proposed); 36 holds no rate. The 10 Pricing Scenario references the change initiative, so 36 holds no scenario link on the change (one direction per link); a business case may cite a scenario as market evidence.
- **Requirement evidence groups.** Seven groups, one source each (exemptive relief is satisfied by 35 Exemptive Relief Reliance.Reliance Effective From, the attribute 35 holds; Form CRS changes are communicated within 60 days and evidenced by 13 Recipient Delivery Records): board or trustee approval (35 Resolution Subject Link), fund filing including state notice filings (35 Fund Regulatory Filing), exemptive relief (35), firm filing (38 Firm Regulatory Filing: Form ADV Part 2A or Appendix 1, Form CRS), shareholder or client notice or vote (13; the advisory agreement amendment is delivered by a 13 communication, acceptance per account is 15 Account Agreement), client fee notice (47 Fee Disclosure Delivery of type Advance Notice of Fee Change for the proposed schedule; no delivery row or client is copied) and regulator prior approval (FINRA Rule 1017, mastered here). enrich_36 keeps 35 as the primary derived owner and states the rule in ROW_OWNERSHIP.
- **Reviews evidence, never re-master (CD-238).** Product Review Criterion Result references 32 returns, 11 peer universes and fee studies, 10 profitability records, 06 measure values and 21 metric definitions, and holds two declared Derived counts: complaints (08 Complaint by Product / Share Class, or by Account through 15 Program Enrollment in the offering at Received Date) and drift exceptions (46 Tolerance Breached Indicator of accounts enrolled in the offering). Complaints count only under Client Outcomes; Operational Issues covers servicing errors and incidents. No return, fee or individual complaint is copied. "Review" is never bare (CW-169).
- **Readiness is evidence (CD-239).** Readiness Check gains Platform Product Availability (01, brokerage platform set-up; CW-170), Policy (38, supervisory procedures) and Release (41, digital release). The 05 Shelf Placement, Model Program Placement and Distribution Agreement references stay for the IC line (the 05 W4 brief keeps them). Workstreams without an owning record (NSCC Profile, 48 to 50 brokerage set-up until referenced, Advice Program Setup, Fee Schedule Setup, State Notice Filing, Client Communications, Seed Capital) are evidenced by the check name.
- **Object kinds.** Every kept object keeps its wholesale kind, as the brief's text says (program-lead ruling in the fix pass; the brief's 9 / 15 table is not followed): keys_e7_30_36 keys the kept business objects without a fold flag, and an attribute group may not sit under an attribute group. Result: 18 business objects and 6 attribute groups (Business Case Market Evidence, the three structure details, Service Offering Specification and Platform Feature Specification, both of Product Change Initiative). The key rows of the three new objects and the two extended primary keys are in `proposals_w4_36.py` KEY_ROWS.
- **PRVW- key.** The subject key carries its own prefix (PRVW-2026-PRD-00981-PPR-01; MDL-, OFFR-, SHC- or the launching LCHG- of a platform feature) so that product and model numbers cannot collide.
- **Service tiers.** Service Tier Change is scoped and termed through Scope Service Tier and Term Service Tier (01 Service Tier, keyed by tier code) with the terms Tier Asset Threshold and Tier Benefits; it creates no 01 Lifecycle Event (the 01 Service Tier row changes). The full Product Change Type to 01 Lifecycle Event Type map is in VALUE_MAPS.
- **Lists.** The local cost bearer list is renamed Reorganization Cost Bearer (it collided with the shared Cost Bearer of steward 13; lossy map in VALUE_MAPS). Copies of 01 (Offering Type, Delivery Mode, Discretion Type, Advisory Capacity) and 15 (Feature Type, Disclosure Type) lists keep the owners' names and values; account registration types cite "External (15 Account Registration Type)" rather than copying 28 values.

### Wealth adaptation (W4): wholesale objects dropped, kept, re-cut and added

| Wholesale object | Disposition | What changed |
|---|---|---|
| Product Proposal | Kept, re-cut | Proposal Category and Proposed Offering Type added; Intended Distribution Markets removed (CW-164, CW-170); Business Line example PF; Proposed Manufacturer Entity re-sourced to Internal |
| Proposal Stage History, Product Business Case, Business Case Market Evidence | Kept (BO, BO, AG) | Projected Ongoing Charge renamed Projected Total Annual Operating Expense; evidence adds 11 Competitor Pricing Observation and 10 Pricing Scenario |
| Product Governance Committee, Membership, Meeting, Product Approval Decision | Kept (BO) | FINRA RN 05-26 practice replaces FCA PROD 3 and ESMA; Value Assessment Sign-off removed; Product Committee Meeting Frequency, Effective From, Effective To and Minutes Location trimmed; Observer / Advisor |
| Product Change Initiative, Changed Product Scope, Proposed Term Change, Share Class Specification | Kept (BO) | Scope and Term Service Offering added; COLL Change Classification removed; Proposed Fee Schedule (47) added; Product Change Type re-cut (8 program and feature values added; SFDR Reclassification and Fund Substitution removed); Scope and Term Service Tier added; Proposed Class Servicing Fee Rate, Proposed Hedging Type and Proposed Minimum Initial Investment trimmed |
| Fund Reorganization, ETF Conversion, Liquidation Detail | Kept (AG) | UCITS and UK merger structures and the AFM cost bearer removed |
| Change Impact Assessment | Kept (BO), re-cut | Foreseeable Harm Identified Indicator removed; Impact Area adds Advisory Clients, Supervisory Procedures, Client Disclosures, Technology |
| Change Regulatory Requirement | Kept (BO), re-cut | FCA and UCITS types removed; Form ADV, Form CRS, Advance Fee Change Notice, Advisory Agreement Amendment, State Notice Filing, FINRA Continuing Membership Application added; Form N-1A Initial Registration and Form CRS Change Communication added; Satisfying Firm Filing (38) added |
| Product Readiness Plan, Readiness Check | Kept (BO), re-cut | Evidence Country Registration removed; Evidence Platform Product Availability, Supervisory Policy, Release added; workstreams re-cut (Fund Custody, State Notice Filing and seven wealth workstreams) |
| Product Review | Kept (BO), re-cut | Review Service Offering and Review Platform Feature added; AFM Board Approval Date removed; review types re-cut to PPR, PLR, APR, RRR, CIT; PRVW- key with the subject prefix (PRVW-2026-PRD-00981-PPR-01) |
| Target Market Review Result | Dropped | MiFID II (CW-936), with the two 08 feedback attributes the 08 drafter asked to remove (CW-067) |
| Value Assessment Criterion Result | Dropped | COLL 6.6.20R and PRIN 2A (CW-936), with Outcome Evidence Metric (Outcome Metric, 08) and Comparable Share Class |
| Review Action | Kept (BO) | Action types re-cut (MiFID types removed; program, feature, disclosure and supervisory types added) |
| (new) Service Offering Specification, Platform Feature Specification, Product Review Criterion Result | Added (AG, AG, BO) | CW-161 |

Removals not under CW-936: Fund Substitution and the Section 26(c) Substitution Order requirement (CW-165, insurance-dedicated); the 30 Private Fund Profile note on Scope Product and the private-fund perspective text (CW-930; the W4 retirement brief lists no other 36 reference, and no 07 reference existed).

### Deviations from the brief

1. Platform Feature Specification holds no Release, supervisory procedure or launched date: the 41 Release and the 38 Policy are Readiness Check evidence, and the launch date is the initiative's Actual Effective Date (each held once).
2. The 10 Pricing Scenario is not referenced from the Proposed Term Change (10 references LCHG-).
3. Product Review Criterion Result's subject is the share class, or the reviewed product, model or offering as a whole.
4. Proposal Category added (not in the brief).
5. Requirement Country and Affected Shareholder Accounts Count keep their names (live readers DP-106 and DP-108); their definitions now cover client accounts and state notice filings.
6. Seven low-value attributes trimmed to stay inside the attribute band (Proposed Class Servicing Fee Rate, Proposed Hedging Type, Proposed Minimum Initial Investment, Product Committee Meeting Frequency, Effective From, Effective To and Minutes Location; none has a reader).
7. Object kinds follow the brief's text, not its 9 / 15 table (fix-pass ruling): 18 BO, 6 AG.
8. Service Offering Specification has no Proposed Sponsoring Entity or Proposed Offering Name (the proposal's Proposed Manufacturer Entity and the initiative's Change Title carry them; the band is at 250).
9. Typed readiness references to the 48, 49, 50 and 52 set-up objects are deferred to W5 by choice (Readiness Check Name text until then).

## 3. What could not be verified

- When a new brokerage platform feature is a "material change in business operations" that needs a FINRA Rule 1017 continuing membership application (confirm with broker-dealer counsel).
- The ETF share class order IC-35786 (November 17, 2025) is cited from the SEC notices-and-orders listing; the order PDF was not opened.
- The state-trust reading of 12 CFR 9.18 for a state-chartered trust company trustee (confirm per state).
- The Morningstar Category methodology URL.
- Names Rule (Rule 35d-1, 2023 amendments): compliance dates as extended in 2025 (Release 33-11368) are June 11, 2026 for fund groups with net assets of USD 1 billion or more and December 11, 2026 for smaller groups (review web check; the release itself was not reopened in this pass).
- The review's web checks (2026-10-15) resolved the earlier confirms on Forms N-14, N-8F and N-1A (URL corrected), IM Guidance Update 2017-02, the Form CRS 30-day amendment (General Instruction 8) and 60-day communication, the Form ADV "promptly and annually" amendment, the NASD 05-26 label and its 12-03 reiteration, and Rule 3a-4's annual contact.

## 4. Open questions for SMEs (tailoring levers, reference default first)

1. **Who approves advice programs and platform features?** Default: the firm's product committee, with a broker-dealer supervisory principal as a voting member and the RIA CCO as a non-voting member (Observer / Advisor), to keep compliance independent; the fund board only for fund changes. Lever: a separate advice program committee (a second Product Governance Committee row with its own remit).
2. **Are platform features governed as products?** Default: yes for client-facing features with a disclosure or eligibility rule (Platform Feature Specification). Lever: technology change management only (41), with 36 holding program launches alone.
3. **Review cycle.** Default: annual Periodic Product Review for funds and model portfolios, annual Advice Program Review for programs; Post-Launch Review at 12 months for funds, programs and platform features. Lever: risk-based cycles (Next Review Due Date set by risk tier).
4. **Advance notice of program fee increases.** Default: a Change Regulatory Requirement of type Advance Fee Change Notice evidenced by 47 Fee Disclosure Delivery, with the notice period per the advisory agreement. Lever: negative-consent agreement amendment (Advisory Agreement Amendment, 15 acceptance).
5. **CIT reviews.** Default: CIT Annual Review by the trustee, recorded here, with any approval read from 35. Lever: trustee review in 35 only.
6. **Feeder fund launches.** Default: governed here like funds, with 52 underlying-manager due diligence as evidence (text until a reference is added). Lever: drop with the feeder family.
7. **Criterion ratings.** Default: four local ratings (Meets Expectations, Monitor, Below Expectations, Not Assessed). Lever: keep the RAG scale of the wholesale model.
8. **Cost bearer list.** Default: the local list renamed Reorganization Cost Bearer (Adviser, Merging Fund, Acquiring Fund, Shared). Lever: join the shared Cost Bearer (steward 13) and lose the merging / acquiring distinction.
9. **Regulator prior approvals.** Default: only the FINRA continuing membership application is mastered here. Lever: where the optional trust company (TR line) runs the CITs, add state banking regulator approvals (plan or charter changes) as Regulator Prior Approval values; with a national bank charter, OCC approvals.

## 5. Overlaps with other domains (for consolidation)

| Domain | Item | Proposal |
|---|---|---|
| 01 | Product Approval Date, Last / Next Product Review Date, Product Owner, Lifecycle Event; Offering and feature lists | CD-236 re-notes; Product Lifecycle Event Type with 'Change of Offering Terms' mapping; 01 label 'FINRA Notice to Members 05-26' to read 'NASD Notice to Members 05-26' |
| 10 | Pricing Scenario | References LCHG- (CW-158); 36 references PRSC- only from market evidence |
| 13 | Shareholder Communication, Proxy Proposal | Links held on the 36 requirement; COLL classification membership ended (CW-913) |
| 35 | Resolution Subject Link; state notice filings; PRVW- example | CD-237; State Notice Filing requirement type reads 35 filings; 35 example follows PRVW-2026-PRD-00981-PPR-01 |
| 38 | Firm Regulatory Filing, Policy | Satisfying Firm Filing; Evidence Supervisory Policy |
| 47 | Fee Schedule, Fee Disclosure Delivery | Proposed schedule version; advance notice evidence derived by schedule version |
| 08, 46 | Complaint, Drift Assessment | Derived counts on Product Review Criterion Result |

## 6. Suggested validation steps

1. Walk four cases end to end with product management, fund legal and advisory compliance: a fund merger, a mutual fund to ETF share class conversion, a hybrid advice tier fee increase, and an extended-hours trading launch.
2. Confirm the seven evidence groups and the status mapping with fund legal (35), the RIA CCO (38, 47) and the broker-dealer's supervisory principals.
3. Re-point DP-105 to DP-109 and DP-242 at WP0 as listed in `proposals_w4_36.py` NOTES (READERS).
4. Confirm the outstanding items in section 3.

## History

- Wholesale v0.1 (2026-10-06) and its review response are kept at tag wholesale-v1.0. The Stage 3 consolidation (CD-241, CD-242) registered PPSL-, PAPR-, LCHG- and PRVW-, replaced local copies of enterprise lists by 'Shared:' citations and made Committee Decision Outcome a 24 shared list; those changes carry over.
- W4 (2026-10-15): this adaptation (CW-161, CW-936).
- W4 fix pass (2026-10-15), review `00_Program/Rework/Reviews/36_review.md` (1 High, 10 Medium, 24 Low) under the program-lead rulings: platform feature eligibility re-cast as proposed values of a 01 platform feature object (merge edit for 01); kinds reverted to wholesale (18 BO, 6 AG) with KEY_ROWS; PRVW- key with subject prefix; Service Tier scope and term; complaint and drift count paths; Form CRS 60-day communication via 13 Recipient Delivery Record; platform feature as Post-Launch Review subject; exemptive relief rule on Reliance Effective From; Product Change Type to 01 Lifecycle Event Type map; NASD 05-26 / FINRA 12-03 label; Rule 3a-4 annual contact; 9.18 annual audit; Form N-1A URL; Reorganization Cost Bearer rename and five value renames recorded; extra reader lines; Requirement Country no longer a CDE. Skipped Lows are listed in proposals_w4_36.py NOTES. Counts before the fix pass: 24 objects (9 BO, 15 AG), 250 attributes, 85 CDEs, 76 references; after: 24 objects (18 BO, 6 AG), 250 attributes, 84 CDEs, 78 references.
