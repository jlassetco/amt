# Source Notes: 37 Enterprise & Operational Risk

**Workbook:** `Enterprise_and_Operational_Risk_Data_Taxonomy.xlsx` (built from `_tools/content/content_37_enterprise_and_operational_risk.py`)
**Status:** Draft v0.1, wealth model (direct), scope US, 2026-10-14: the draft of 2026-10-06 (revised after independent review, 00_Program/Expansion/Reviews/37_review.md, and the program lead's rulings) carried over with the US-only pass and the perspective rewrite of CW-937 (section 7). 9 families, 35 objects (33 business objects, 2 attribute groups), 278 attributes, 85 proposed CDEs (30.6%), 34 local code lists plus 11 enterprise shared lists cited directly, 41 relationships, 23 sources. 68 references to other Data Domains, 6 derived copies (with row rules), 0 unresolved (2 ownership overrides).

**Why this domain exists.** The firm is a US wealth manager: a self-clearing broker-dealer running a direct brokerage platform, a registered investment adviser for digital and human advice and institutional mandates, its own mutual funds, ETFs and CITs, workplace recordkeeping and optional trust services. Its second line of defense (enterprise and operational risk, model risk, operational resilience and business continuity, and third-party risk) and its third line (internal audit) produce the firm's record of what can go wrong, what controls it, what did go wrong and what it cost. Before this draft that record was scattered as text: 25 Trade Error held "Related Incident Reference" as text, 10 and 19 cited key controls as codes, 21, 22, 31, 32 and 34 held model names as text with "future owner 37", 14 held a data-vendor-only risk assessment, and 20 flagged key-person risk "as an input to 37". The fact that justifies a separate Data Domain is that the risk and control framework is a cross-cutting register: one control library, one incident and loss database, one model inventory and one audit universe that every business domain is assessed against, kept by functions that must stay independent of the businesses they assess. Internal Audit is a family here with its own owner (the Chief Audit Executive), so its independence rests on ownership rather than on a separate domain (SME question 1).

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| COSO ERM: Integrating with Strategy and Performance (2017) | https://www.coso.org/enterprise-risk-management (confirm page path) | Risk register, risk statements, appetite and tolerance, severity assessment |
| COSO Internal Control - Integrated Framework (2013) | https://www.coso.org/internal-control (confirm page path) | Control types, key controls, components and principles |
| BCBS Revisions to the Principles for the Sound Management of Operational Risk (2021) | https://www.bis.org/bcbs/publ/d515.htm | RCSA, KRIs, loss data, cause analysis, three lines |
| Basel Framework OPE25 Standardised approach (loss data standards) | https://www.bis.org/basel_framework/chapter/OPE/25.htm | Gross loss, recoveries, dates (reviewer confirmed the chapter) |
| Basel II (2006) Annex 9, detailed loss event type classification | https://www.bis.org/publ/bcbs128.htm | The 7 level 1 and 20 level 2 event types (Basel Event Type lists) |
| OCC 12 CFR Part 9 | https://www.ecfr.gov/current/title-12/chapter-I/part-9 | Trustee bank controls of CITs (Control Owning Legal Entity) |
| ORX Reference Taxonomy | https://managingrisktogether.orx.org (confirm) | Level 1 risk types cross-check (Non-Financial Risk Type); public summary only |
| SR 26-2 (2026-04-17, supersedes SR 11-7) | https://www.federalreserve.gov/supervisionreg/srletters/sr2602.htm (verified by the brief) | Model definition, inventory, validation, monitoring |
| SR 11-7 (historical; superseded with SR 21-8 by SR 26-2) | https://www.federalreserve.gov/supervisionreg/srletters/sr1107.htm | Basis of the 21 and 31 notes |
| IIA Global Internal Audit Standards (2024, effective 2025-01-09) | https://www.theiia.org/en/standards/2024-standards/global-internal-audit-standards/ (confirm) | Audit universe, plan, engagements, findings (condition, criteria, root cause), follow-up |
| ISO 22301:2019 | https://www.iso.org/standard/75106.html | BIA, RTO, RPO, MTPD, plans, exercises (structure only) |
| NIST CSF 2.0 | https://www.nist.gov/cyberframework | 37-41 boundary (Respond, Recover) |
| Interagency Guidance on Third-Party Relationships (June 2023) | https://www.federalreserve.gov/supervisionreg/srletters/SR2304.htm (SR 23-4, confirmed by the reviewer) | Third-party lifecycle and risk domains |
| SEC Rule 38a-1 / Advisers Act Rule 206(4)-7 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.38a-1 | Compliance testing as Control Test rows (Testing Line Compliance); business continuity as part of the adviser's and funds' compliance policies (Business Continuity Plan) |
| FINRA Rule 4370 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/4370 | Broker-dealer BCP elements (data backup and recovery, mission critical systems, alternate locations, critical business constituents, banks and counterparties, annual review): Business Continuity Plan, Resilience Resource Mapping, Resilience Test (CW-937). |
| FINRA Rule 4530 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/4530 | Rule 4530(a) reportable events (violations, specified written customer complaints, disciplinary and criminal events), 4530(b) internal conclusions of violations and 4530(d) complaint statistics. An operational incident leads to a 4530 report only where it also involves such an event (confirm against the rule text): the FINRA Rule 4530 Report regime value (CW-937). |
| SEC Regulation S-P, 17 CFR Part 248 Subpart A (2024 amendments, 248.30) | https://www.ecfr.gov/current/title-17/chapter-II/part-248/subpart-A | Incident response program and notice to affected individuals of unauthorized access to sensitive customer information: the Regulation S-P Customer Notification stage and the notification deadline (CW-937). The amendments are in force (compliance dates, larger entities 2025-12-03 and smaller entities 2026-06-03: confirm). |
| Interagency Paper on Sound Practices to Strengthen Operational Resilience (SR 20-24, November 2020) | https://www.federalreserve.gov/supervisionreg/srletters/SR2024.htm (confirm) | Critical operations, mapping of interconnections and dependencies, scenario analysis: Critical or Important Function, Resilience Resource Mapping, Resilience Test (applied by analogy; CW-937). |
| PCAOB AS 2201 / SOX 404 | https://pcaobus.org/oversight/standards/auditing-standards/details/AS2201 | Control nature, design and operating effectiveness |
| ServiceNow IRM, Archer, MetricStream (public descriptions) | https://www.servicenow.com/products/integrated-risk-management.html (confirm) | Object structure only |

## 2. Design decisions and boundary calls

- **CD-243, library here, execution there.** Control holds the definition and names its Control Execution Record Type (29 TA Control Check, 27 NAV Control Check, 06 Reconciliation, 19 Close Task, 07 Compensation Control, 10 Control, 33 Compliance Check Run). Control Test samples executions by key as text evidence and copies no result. 38 compliance monitoring tests are Control Test rows with Testing Line "Compliance".
- **CD-244, incidents and one loss, one home (program lead rulings 2 and 3).** Operational Incident copies no facts of 33 breaches or 31 exceedances; they appear only as Incident Source Record rows, and only where an operational failure caused them or they caused a loss. Two measures are kept apart. Loss Event Amount.Loss Amount is the gross loss borne by the firm (cash out plus write-downs): Derived copy of 25 Reimbursement Amount, 27 Fund Loss Amount where an internal entity reimbursed, 33 Breach Loss Calculation Compensation Amount, 26 Penalty Amount where the firm absorbed it (a US fails charge or a counterparty claim; 26 keeps Settlement Penalty under CW-926); mastered only where no source exists (fraud, legal settlements and fines, disruption costs). Operational Loss Event.Impact Amount is the client or portfolio harm: Derived copy of 25 Error Gain or Loss Amount, 27 Fund Loss Amount, 33 Breach Loss Amount, or the sum of 13 Shareholder Remediation by servicing error. Insurance recoveries are read from 43 Insurance Claim (which holds the only link) at claim level. DERIVED names primary owners 25 and 27; the notes give every source.
- **CD-245 (and the coordinator's ruling).** 41 IT Incident (ITINC-) and 44 Physical Security Incident are referenced from Incident Source Record; neither holds a 37 reference. All authority and customer notifications (FINRA Rule 4530 reports, Regulation S-P customer notifications, state breach notifications) are Incident Regulatory Notification rows; the DORA major-incident classification was removed under CW-937.
- **CD-246, inventory here, use there.** Model Inventory Entry (MODEL- x version) with Tier Assignment, Validation and Performance Monitoring; no list of uses. Trading Algorithm Code (a MiFIR transaction reporting code) was removed under CW-937; 24 Decision Algorithm Code loses its source (W3).
- **CD-247, Internal Audit.** Five objects owned by the Chief Audit Executive (noted on the key attributes). Audit Finding Rating is only on the finding; management action is a Risk Issue that holds the one link (Source Audit Finding); a finding closes only through a Finding Closure Validation attempt (a business object, one row per attempt) with outcome Validated - Closed. Audit committee approval of the plan is linked from 39 Corporate Resolution Subject Link; 37 keeps a Derived copy (39) approval status.
- **Issue sources (program lead ruling 4).** Risk Issue holds typed references to every source (audit finding, 38 examination finding and compliance program review, incident, control test, model validation, third-party assessment, resilience test, 41 vulnerability finding); a self-identified issue has none. 38 and 41 are asked to drop their reverse links.
- **Appetite (program lead ruling 1).** No approval reference; Appetite Approval Date is a Derived copy (39). The KRI-appetite link is held only on KRI Threshold. Appetite Category gains Capital and Liquidity (code CAP) so 43's Capital Appetite Statement resolves.
- **CD-248 (amended by program lead ruling 5).** Third-Party Risk Assessment holds residual risk only; the inherent tier (40 Supplier Risk Tiering), exit plans and the outsourcing register (40) are not copied. 14 Vendor Risk Assessment keeps Inherent Risk Rating mastered as the data-vendor specialization and holds the reference to the 37 assessment (proposed).
- **CD-249.** Critical or Important Function, Resilience Resource Mapping (typed resources: 20 WFP-, business capability, 41 APPL- and IT Service, 09 SITE-, 40 VENG-, 21 DAS-), BIA, BCP and Resilience Test here; ICT DR results are read from 41 Security & Resilience Test. The UK Important Business Service and Impact Tolerance objects were removed under CW-937; the function is now the critical activity or operation of the interagency guidance and the mapping's only subject.
- **CD-246 (program lead ruling 6).** Model vendor, owner, use status and version are mastered on Model Inventory Entry; 31 Risk Model's copies become Derived copies (37) and its version equals the inventory version (proposed).

### Deviations from the brief

1. **Incident Source Record added** (BO, incident x source record): typed source references for 25, 27, 33, 31, 13, 41, 44, 16, 29 (AP order, account monitoring alert) and 30, one per row, instead of a list of source attributes on the incident. 37 objects (35 BO, 2 AG after the review) vs 36.
2. **Risk Taxonomy Level** is an Integer (1-3), not a list; a **Non-Financial Risk Type** list classifies level 1 instead.
3. **Basel Event Type** is two lists (Level 1, Level 2), so each attribute uses one level; Level 2 values name their Level 1 parent.
4. **One Assessment Level list** (Low / Medium / High) serves Mitigation Strength, Exit Feasibility and model materiality, complexity and uncertainty, instead of separate lists.
5. **Model use status** uses the shared Record Status, not a local list.
6. **Notification regime** is folded into Incident Notification Stage values (FINRA Rule 4530 report, Regulation S-P customer notification, state breach notification, other authority; CW-937).
7. **Operational Loss Event** does not repeat the Basel event type (read from the incident's classification) and holds no Basel business line, insurance claim indicator or first booked date (derived from the earliest Loss Booking Date).
8. **Third-Party Risk Assessment** has a firm reference key ("TPRA 2026/00412") in addition to its grain, so dependents do not embed PTY- keys.
9. **Risk Issue** has a typed source reference for every source; there is no free-text source key.
10. **Audit Finding** rating uses Shared: Severity (brief §8); the local Audit Rating list is the engagement opinion.
11. **14 Vendor Risk Assessment Inherent Risk Rating** stays mastered in 14 (CD-248 amendment); the brief's Derived copy (37) proposal and the draft's Derived copy (40) proposal are withdrawn.
12. **Size:** 297 attributes, above the 290 ceiling by 7, because the review and the program lead added Control Owning Legal Entity, four likelihood and impact codes, five incident sources, eight typed issue sources, the Impact Amount, IT Service and process mapping, and two closure-validation keys; duplicates were trimmed to compensate (see Review response). CDEs follow one rule: each business object's own identifier, code and version are CDEs; reference parts of a compound grain are not. Period Type is not used.
14. **Risk Taxonomy Category** holds no level or risk type attribute: level 1 rows are the risk types, read through the parent chain (no Non-Financial Risk Type list).
15. **Likelihood and impact** use one five-point Risk Matrix Score list.
13. **Shared lists** are local copies with the exact shared names and values (Stage 2 addendum), not "Shared:" citations, because 37 is not yet a registered direct user.

### Review response

All five High findings and the program lead's rulings 1-6 are applied. Every Medium is applied or applied in part; the list below gives the findings not applied, or applied differently, with the reason.

- **A Medium, Non-Financial Risk Type and Appetite Category (B Medium):** the risk type list was removed (level 1 taxonomy rows are the only vocabulary), but Appetite Category stays a separate list, because it must also hold Capital and Liquidity (program lead ruling 6), which is not a non-financial risk category.
- **E Medium, Loss Amount owner wording:** the enrichment contract takes one owner per attribute, so DERIVED names primary owners (25 for Loss Amount, 27 for Impact Amount) and the notes carry the full row rule; proposals_37 NOTES propose an object-level Row Ownership Rule convention.
- **B Medium, Assessed Third Party as Derived copy (40):** it is a Reference, which the resolver cannot flag Derived; the row rule is in its note.
- **G Medium, control execution relationship:** reworded as "names the record type of" with no cardinality; optional Reference (Control, 37) columns on 27, 29 and 06 are not proposed (recorded in NOTES as a later option), to avoid five more cross-domain changes in Stage 4.
- **H Medium, business process code:** the capability map code ("C-08.03 ...") is used as 21 and 41 do, typed Firm-defined; no master exists, so it stays an open item rather than a reference.
- **H Low, KRI Source Record Type:** not added (size); the KRI Definition text names the source record type.
- **J/brief Low, missing brief content:** Model Developer not re-added (size; Model Owner is accountable); in-house models are identified by a blank Model Vendor (stated in the definition); Risk Control Link design adequacy not re-added (Mitigation Strength carries the judgment); Audit Engagement end date is the Audit Report Issued Date. Fieldwork Start Date and Covered Third Party were added.
- **I Low, 44 example format:** not changed. The 44 module's Security Incident Reference example is "PSI 2026-0007" with the note "format agreed with 37", which matches 37.
- **I Low, 39 / 40 key-format mismatches:** recorded in proposals_37 NOTES for consolidation; not changed in 37.
- **Trims to make room (not review findings):** Planned Engagement Count, Exceptions Found Count, Loss First Booked Date, Recovery Party, KRI Name earlier, Tolerance Last Mapped and Last Tested Dates (read from mapping and tests), Taxonomy Version Effective From, Single Point of Failure Indicator, RCSA Due Date and KRI Owner.
- **H Low, insurance-dedicated funds:** accepted. 35 RIC Qualification Determination is not an incident source; an 817(h) failure enters through the 33 breach.
- **H Low, AIFM risk management function:** left as an SME note (question 5).

## 3. What could not be verified

- Regulation S-P notification deadline (as soon as practicable, not later than 30 days after becoming aware of the incident) and compliance dates of the 2024 amendments; FINRA Rule 4530 reporting periods. The model does not hard-code them (Notification Deadline Timestamp).
- URLs marked "confirm" in §1 (COSO page paths, Basel OPE25 chapter URL, ORX, IIA, SR 23-4 and SR 20-24 letter numbers, ServiceNow page).
- IIA Topical Requirement on third parties and its effective date (named in the brief) was not cited.
- The 38-44 object names were checked against the sibling modules (being revised in parallel); recheck at merge.

## 4. Open questions for SMEs

1. Does Internal Audit want its own Data Domain, or is a family owned by the Chief Audit Executive enough for independence?
2. Which GRC platform holds the register, controls, incidents and issues, and does Internal Audit use the same platform?
3. What loss threshold triggers a loss event record, and are near misses and gains recorded?
4. Are trade errors and NAV errors always raised as operational incidents, or only above a threshold (25 SME question 10)?
5. Which entities keep a business continuity plan (the broker-dealer under FINRA Rule 4370; the adviser and the funds under Rules 206(4)-7 and 38a-1; the trust company), and is it one plan or several?
6. Is the firm (or a parent) subject to SOX 404, so that "SOX key control" applies?
7. Which models are in the inventory today (optimizers, trading algorithms, ESG scores, AI use cases), and who validates vendor models?
8. Does model risk follow SR 26-2 by analogy, or an internal standard only?
9. Who performs third-party risk assessments for data vendors (CD-090) and servicing providers (13)?
10. Is the risk appetite approved by the holding company board, the entity boards, or both?
11. Is the audit universe shared with the fund boards' audit committees (35), or kept for the corporate group only?
12. Who decides that an incident needs a Regulation S-P customer notification or a FINRA Rule 4530 report: the CISO team (41), Compliance (38) or operational risk (37)?
13. Should the business capability map be mastered (21 or a new owner) so process codes on incidents, BIAs and mappings become references?

## 5. Overlaps with other domains (for consolidation)

Listed in `_tools/consolidation/proposals_37.py` PROPOSED_CHANGES: re-type 25 Related Incident Reference, 10 Control Reference, 19 Key Control Reference, 31 and 32 Model Inventory Reference (with version), 21 Model Name, 22 Valuation Model Name, 34 Assessment Methodology Name and Metric Model Name; 31 Model Vendor, Owner and Status, 24 Decision Algorithm Code, 14 Residual Risk Rating and 23 Expert Network Due Diligence Date as Derived copies; 14 Inherent Risk Rating unchanged and a new 14 reference to the 37 assessment; 38 Remediating Risk Issue and Review Findings Raised and 41 Risk Acceptance Issue dropped; 07 Compensation Control library link; 20 Key-Person Risk Indicator note; 02 Party Role Type values. Term conflicts: Incident, Risk, Control, Issue, Model, Audit, Exception, Appetite / Limit.

## 6. Suggested validation steps

1. Walk one NAV error (27 NEC-) end to end: incident, source record, classification, loss event, Derived copy loss amount, risk issue, KRI observation.
2. Walk one cyber incident involving customer information from 41 IT Incident to its Regulation S-P customer notification and state breach notification rows.
3. Confirm the Basel and firm taxonomy mapping with the Head of Operational Risk.
4. Load the current model inventory and check that every consumer in 21, 22, 31, 32 and 34 resolves to a MODEL- entry.
5. Check the audit universe against the 39 corporate bodies and the 35 fund audit committees.

## 7. Wealth model carry-over (W1b, CW-937)

37 is kept (plan section 5.1). The pass made the changes CW-022 allows and no others: the US-only pass, the perspective text, the re-pointed wording and the Business Line and Regulator examples. Object and attribute names are unchanged except for the removed objects and attributes. The decision draft and the jurisdiction entries are in `_tools/consolidation/proposals_w1b_37.py`.

**Removed (EU/UK only; 26 jurisdiction entries: FCA 13, DORA 8, MiFIR 2, Other EU/UK 2, CSDR 1).**
- Objects: Important Business Service (FCA SYSC 15A, PS21/3; 8 attributes) and Impact Tolerance (5 attributes) with the list Impact Tolerance Metric; two relationships removed ('Operational Incident disrupts Important Business Service', 'Important Business Service has Impact Tolerance') and two rewritten to Critical or Important Function ('depends on', 'supports').
- Attributes: Operational Incident.Impacted Business Services; Incident Classification.DORA Major ICT-Related Incident Indicator and DORA Classification Timestamp; Critical or Important Function.Related Important Business Service; Resilience Resource Mapping.Mapped Business Service; Resilience Test.Tested Business Service; Model Inventory Entry.Trading Algorithm Code (MiFIR RTS 22 algorithm code).
- Values: Incident Notification Stage DORA Initial Notification, DORA Intermediate Report, DORA Final Report and FCA SUP 15 Notification.
- Sources (9): DORA; Delegated Regulation 2024/1772; Delegated Regulation 2025/301 and Implementing Regulation 2025/302; FCA SYSC 15A; FCA SUP 15; PRA SS1/23; EBA/GL/2019/02; MiFIR RTS 22; CSDR and Delegated Regulation 2018/1229.
- No ICARA content was found in 37.

**Kept and re-sourced on purpose (deviation from the brief row).** The brief lists Critical or Important Function (DORA) for removal. It is kept: the 2023 interagency third-party guidance that 37 and 40 already cite uses "critical activities", the 2020 interagency sound practices use "critical operations", and the 40 editor kept Outsourcing Arrangement.Supported Critical or Important Functions (Reference (Critical or Important Function, 37)) on that basis under CW-940. Its code, name, entity and dates now cite the interagency guidance or Internal, the example names the firm's own funds, the designating entity is any internal entity, and it is the subject of every Resilience Resource Mapping. The lead may still remove it; the 40 reference, the mapping subject and DP readers would then need a new anchor (open question 1).

**Re-sourced.**
- Business continuity to FINRA Rule 4370 and the adviser's and funds' compliance-program plans (SEC Rules 206(4)-7 and 38a-1): family text; Business Continuity Plan Code, Plan Scope and Plan Last Reviewed Date; Resilience Resource Mapping (Resource Type, the mapped application, site and supplier described as mission critical systems, alternate locations and critical business constituents); Resilience Test Date, Type and the Tolerance Met Indicator, which now records whether the tested plan recovered the processes within their BIA recovery time objectives (name kept); Resilience Test Type and Resilience Resource Type list sources; Source Resilience Test on Risk Issue.
- Operational resilience to the interagency sound practices (SR 20-24, applied by analogy): Critical or Important Function, Mapped Function, Resilience Test Scenario. Reg SCI does not apply: the firm operates no SCI entity (an exchange, clearing agency or SCI ATS would be a lever).
- Incident notification to Regulation S-P customer notification and state breach laws for customer-data incidents, and to FINRA Rule 4530 only where the incident also involves a 4530 reportable event: Notification Authority (example FINRA; blank when only customers are notified); review fix pass: Incident Notification Regime (new attribute and list: Regulation S-P Customer Notification, State Breach Notification, FINRA Rule 4530 Report, SEC or Other Regulator Notification, Internal) and Incident Notification Stage (name kept; Initial, Update or Amendment, Final); Notifying Legal Entity, Notification Deadline and Sent Timestamps (US time zone examples), Authority Reference Number.
- Third-party risk: EBA and DORA references on Third-Party Assessment Type, Exit Feasibility and Third-Party Risk Domain replaced by the interagency guidance; list sources likewise.
- Model risk: PRA SS1/23 references on Model ID, Model Type, Model Tier, Model Materiality, Complexity and Uncertainty, Model Validation Type and Outcome replaced by SR 26-2 or Internal; the Model Tier list cites SR 26-2 risk-based tiering. The model risk and internal audit families are otherwise unchanged.
- Incident Discovery Date and Source IT Incident lose their DORA secondary references; Amount Source Settlement Penalty cites Internal (26 keeps Settlement Penalty for US fails charges under CW-926).
- Sources added (4): FINRA Rule 4370, FINRA Rule 4530, Regulation S-P (17 CFR Part 248 Subpart A), the interagency sound practices (SR 20-24). Net 27 to 22.

**Perspective rewritten.** META subtitle; overview Purpose, Scope, Core model, Design principles 6 and 10, Applies To, CDE, Primary / Secondary Reference, Notes (PII under US law; portfolios are fund and institutional portfolios) and Suggested next steps 3, 4 and 7; the Operational Resilience & Continuity family text and the Business Services & Functions group text (group name kept); Third-Party Risk family text; SUMMARY and the Resilience Resource Mapping grain in `enrich_37.py`. Business Line examples use the CW-004 codes (PF; DB) and the Regulator example is FINRA (W1 merge notes section 5). The UK site example (Edinburgh) reads Malvern and Charlotte.

**Re-pointed.** The SMA note on Impacted Portfolios now says retail managed accounts are 15 accounts, not 18 portfolios (CW-007); Source Model Portfolio reads "model platform sponsor (IC line) or an institutional separate account"; 02 is named Client & Household in SUMMARY. Every Reference (Party) still resolves.

**Added.** None (the brief names no addition for 37). The four new Incident Notification Stage values and the relationships "Resilience Test exercises Business Continuity Plan" and "Outsourcing Arrangement [40] supports Critical or Important Function" (replacing the 40 relationship that named the removed register objects) are the US instances of removed content.

**Left for later stages (not changed, listed in the proposals NOTES).** References to 30 (Source Waterfall Calculation, Source Capital Call, their Incident Source Type values and relationship), to 13 (Servicing Error, Shareholder Remediation) and to 07 (07 Compensation Control as a control execution record type) stay.

**Open questions (W1b).**
1. Keep Critical or Important Function as the US critical activity or operation (as drafted), or remove it as the brief lists and give 40 and the resource mapping another anchor?
2. Should Business Continuity Plan carry the FINRA Rule 4370 emergency contact persons and the annual review approval as attributes (not added in W1b)?
3. Is a separate Regulation S-ID identity theft red flags record needed in 37, or is that 41's program record (41 adds it in W1b)?

**Unverified.** SR 20-24 letter number and URL (confirm); Regulation S-P amendment compliance dates (amendments in force) and the 30-day notice period (confirm); FINRA Rule 4530 30-calendar-day reporting period for 4530(a) events (confirm).

**Review fix pass (2026-10-14).** FINRA Rule 4530 is no longer presented as the home of incident notification (overview, Core model, CDE, relationship and source row corrected); the notification is split into regime and stage as above; FINRA Regulatory Notice 21-29 added as the broker-dealer's vendor-management source (secondary reference of Third-Party Assessment Type); the Business Line examples use the CW-004 codes (PF, DB); the relationship counts of the removed objects are corrected; a BIA link and the rename 'Recovery Objective Met Indicator' are recorded as candidates for the lead; the decision's domains list names 37 only.
