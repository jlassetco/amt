# Source Notes: 38 Corporate Compliance & Regulatory Affairs

**Workbook:** `Corporate_Compliance_and_Regulatory_Affairs_Data_Taxonomy.xlsx` (built from `_tools/content/content_38_corporate_compliance_and_regulatory_affairs.py`)
**Status:** Draft v0.1, 2026-10-15, wealth-manager adaptation (W4; disposition keep -> adapt, CW-167), revised after the review (`00_Program/Rework/Reviews/38_review.md`) under the program lead's rulings. Wealth manager (direct), scope US. 9 families, 36 objects (28 business objects, 8 attribute groups), 291 attributes, 101 proposed CDEs (35%), 53 code lists (44 local, 9 shared), 68 relationships, 22 sources, 107 attributes flagged PII. The builder reports 65 references, 2 derived copies and 0 unresolved; enrich_38 holds 9 row ownership rules. Wholesale baseline (tag `wholesale-v1.0`): 35 objects (2 attribute groups), 280 attributes, 87 CDEs, 53 code lists, 59 references.
**Brief:** `00_Program/Rework/Briefs/38_Corporate_Compliance_and_Regulatory_Affairs.md`. Decisions applied: CW-162, CW-163, CW-164, CW-165, CW-168, CW-169, CW-930 (`proposals_w4_economics.py`), CW-003, CW-013, CW-022, CW-056, CW-066 to CW-069, CW-074; drafts CW-938 (`_tools/consolidation/proposals_w4_38.py`).

**Why this domain exists.** The chief compliance officers of the wealth manager's regulated entities each run a firm-level program: the SEC-registered adviser (digital, human and institutional advice; Rule 206(4)-7), the funds (Rule 38a-1), the self-clearing FINRA broker-dealer that is also principal underwriter (FINRA Rules 3110, 3120, 3130, 3310), the in-house transfer agent (Form TA-1 and TA-2) and the optional trust company (OCC or state charter). Regulators register, examine and receive filings from each entity as a whole. 38 holds those programs: registrations and filings, Form CRS filing, examinations, the policy library and attestations, program reviews, the adviser's custody status, the code of ethics and personal trading, political contributions, the conflicts register, the AML program and its cases, information barriers and market-abuse surveillance. 08 supervises retail conduct (what representatives recommend and how principals review it); 38 holds the programs that apply to the firm and its people.

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| Advisers Act Rules 204A-1, 206(4)-5, 206(4)-7, 204-2; Section 204A | https://www.ecfr.gov/current/title-17/chapter-II/part-275 | Code of ethics (access persons, report deadlines, pre-approval of IPOs and limited offerings); pay-to-play (covered associates, de minimis USD 350 / 150, two-year time-out, look-back); compliance program annual review; MNPI procedures (kept from the wholesale draft). |
| Advisers Act Rule 206(4)-2 and Form ADV-E | https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.206(4)-2 | Custody bases, qualified custodians, related-person custody and internal control report, surprise examination by an independent public accountant, Form ADV-E submitted by the accountant through IARD within 120 days and material discrepancies reported within one business day (verified by the reviewer against the IARD Form ADV-E guidance). Paragraph references remain marked confirm. |
| Investment Company Act Rules 17j-1 and 38a-1 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.38a-1 | Fund access persons; fund CCO annual report and material compliance matters. |
| SEC Release IA-2204 / IC-26299 | https://www.sec.gov/rules-regulations/2003/12/compliance-programs-investment-companies-investment-advisers | Annual review content, CCO role. |
| Form ADV and instructions; IARD | https://www.sec.gov/about/forms/formadv.pdf | Parts 1A, 2A (with Appendix 1), 2B and 3; annual updating amendment within 90 days; custody item (Item 9, confirm); conflicts disclosures. |
| Form CRS: Exchange Act Rule 17a-14, Advisers Act Rule 204-5, Form CRS instructions | https://www.ecfr.gov/current/title-17/section-240.17a-14 | Filing by capacity (adviser through IARD as Part 3, broker-dealer through CRD, dual registrant), website posting, amendment within 30 days of a material inaccuracy and communication of changes to existing retail investors within 60 days (verified by the reviewer against the SEC small entity guide). |
| Form BD; Rule 15b1-1; FINRA CRD | https://www.sec.gov/files/formbd.pdf | Broker-dealer registration and types of business (item numbers to confirm). |
| Form TA-1 and TA-2; Rules 17Ac2-1 and 17Ac2-2 | https://www.ecfr.gov/current/title-17/section-240.17Ac2-1 | Transfer agent registration and the annual report (March 31 due date, confirm). |
| OCC 12 CFR 5.20 and 12 CFR Part 9 | https://www.ecfr.gov/current/title-12/part-5 | National trust bank charter; self-dealing (9.12) as a conflict category. |
| Rules 13f-1, 13d-1 (2023 amendments), 13h-1, 13f-2 | https://www.sec.gov/rules-regulations | Form 13F, Schedules 13D and 13G, Form 13H, Form SHO (compliance deferred to the January 2028 period, first filings 2028-02-14). |
| FINRA Rules 2030, 3110, 3120, 3130, 3210, 3240, 3241, 3270, 3280, 3310, 5270, 5320 | https://www.finra.org/rules-guidance/rulebooks/finra-rules | Supervision and certification; accounts at other firms (3210, Associated Person); borrowing and lending (3240); customer beneficiary or fiduciary (3241); OBAs and private securities transactions; AML program and independent test; front running (5270) and trading ahead (5320); BD pay-to-play (2030). Rule 3290 approved by the SEC 2026-09-15, effective date to be announced (confirm). |
| MSRB Rule G-37 | https://www.msrb.org/Rules-and-Interpretations/MSRB-Rules | Municipal finance professionals (Conduct Designation Type), USD 250 de minimis per election where the MFP may vote, two-year ban on municipal securities business, applied to 529 plan underwriting. URL and applicability to 529 primary distribution to confirm. |
| Exchange Act Section 15(g) | https://www.law.cornell.edu/uscode/text/15/78o | Broker-dealer MNPI procedures (restricted, watch and wall-crossing lists). |
| Regulation Best Interest, Rule 15l-1 | https://www.ecfr.gov/current/title-17/section-240.15l-1 | Conflict of interest obligation: conflict register categories and disclosure. |
| BSA program rules: 31 CFR 1023.210 / .320, 1024.210 / .320, 1010.520; 31 CFR Part 1032 | https://www.ecfr.gov/current/title-31/subtitle-B/chapter-X | BD and fund AML programs, SAR timing and confidentiality, 314(a) information sharing; adviser AML rule effective 2028-01-01 under FinCEN's final rule of 2025-12-31 (scope still under review). |
| OFAC 31 CFR 501.603 and 501.604 | https://www.ecfr.gov/current/title-31/section-501.603 | Blocked property and rejected transaction reports (10 business days) and the annual report. |
| Regulation S-P (2024 amendments) and Regulation S-ID | https://www.ecfr.gov/current/title-17/part-248 | Program review types; PII note. The 2024 amendments are in force: larger entities from 2025-12-03, smaller entities from 2026-06-03; every regulated entity of the reference firm is a larger entity. |
| DOL PTE 2020-02, Section II(d) | https://www.dol.gov/agencies/ebsa/laws-and-regulations/rules-and-regulations/completed-rulemaking/1210-AC38 | Retrospective review report (URL and section confirm). |
| FATF Recommendations | https://www.fatf-gafi.org/en/topics/fatf-recommendations.html | Secondary reference for the AML risk rating only (URL confirm). |
| SEC, FINRA and OCC public registers; NASAA | https://adviserinfo.sec.gov ; https://brokercheck.finra.org | Registration numbers and statuses; state notice filings. |
| StarCompliance, ComplySci, NICE Actimize | https://www.starcompliance.com ; https://www.complysci.com ; https://www.niceactimize.com | Structure only. |

## 2. Wealth adaptation (W4): dropped, kept, re-cut and added

| Wholesale object | Disposition | What changed |
|---|---|---|
| Entity Authorization | Kept, re-cut | US types only; SIPC, state BD, MSRB dealer, transfer agent (TA-1) types added; State Insurance License removed (CW-165); Regulator Reference Number re-sourced to SEC file numbers, CRD, MSRB, NFA and OCC numbers, fictitious example; Regulated Activity re-cut to Form BD and Form ADV business types (confirm). |
| Cross-Border Passport | Dropped | EU passports (JURISDICTION). |
| Firm Regulatory Filing | Kept, re-cut | Form CRS, TA-1, TA-2, ADV-E added; FILNG- form codes CRS, TA1, TA2, ADVE; EU and UK notifications and CASS CMAR removed. |
| Form CRS Filing Detail | Added (AG) | Filer capacity, relationship summary version, amendment trigger, website posting date (CW-162). |
| Ownership Disclosure Determination | Kept | US regimes only; aggregation names 49 discretionary client holdings beside 18. |
| Regulatory Obligation, Regulatory Change Item, Regulatory Change Impact | Kept | Source Regulation re-cut (MSRB, FinCEN, OCC, DOL added); instrument types re-cut; Impacted Business Line CW-004. Change Impact is an AG. |
| Regulatory Examination, Regulator Request Item, Examination Finding | Kept | Thematic Review removed. Request Item and Finding are AGs. |
| Policy, Policy Version, Attestation, Compliance Program Review | Kept, re-cut | Policy Domain Distribution -> Retail Conduct; Privacy and Financial Crime added; Program Review Type adds PTE 2020-02, Reg S-P and Reg S-ID, drops MLRO and Compliance Function reports. Policy Version is an AG. |
| Adviser Custody Profile, Custody Surprise Examination | Added (BO) | Rule 206(4)-2 custody status and surprise examination with Form ADV-E (CW-162, CW-056). |
| Code of ethics objects (7) | Kept | Associated Person (Rule 3210) added; Relevant Person, Insider-List-Eligible and ISA / SIPP removed. |
| Political Contribution, Pay-to-Play Review | Kept | FINRA Rule 2030 and MSRB Rule G-37 references (G-37 confirm). |
| Conflict of Interest, Conflict Mitigation, Outside Business Activity | Kept, re-cut | Wealth conflict categories (CW-168); OBA types for Rules 3240 and 3241 (CW-074); FCA SYSC 10 re-sourced to Form ADV and Rule 15l-1; 30 LPAC text removed. Conflict Mitigation is an AG. |
| AML Program Assessment, AML Case, AML and Sanctions Report | Kept, re-cut | Trust company row (31 CFR 1020); 50 alert source and 314(a) source added; 314(a) match report type; UK and EU types removed; report keyed without a case (AML Report Key). |
| Firm Restricted List, Restricted List Entry, MNPI Escalation, Insider List Entry | Kept, re-sourced | Advisers Act Section 204A and Exchange Act Section 15(g); Insider List Entry is the wall-crossing log; Source Deal (30) removed (CW-930). |
| Trade Surveillance Alert | Kept, re-cut | Subject Client Orders and Client Executions (48); scenarios for FINRA Rules 5270 and 5320; Escalated - STOR removed. |
| Suspicious Transaction and Order Report | Dropped | MAR Article 16; the route is an AML Case and a SAR (CW-163). |

Family renames (codes kept): Policies & Attestations -> **Policies, Attestations & Program Reviews**; Conflicts of Interest -> **Conflicts & Outside Activities**. New subfamily: Adviser Custody Status. No object or attribute renamed.

## 3. Design decisions and boundary calls

- **Firm programs here, retail supervision in 08 (CW-066).** No 38 object stores a recommendation, a best-interest test, a supervisory review, a sales-practice alert, a complaint or an individual or branch registration. 08 references 38 Policies (WSPs), Attestations (Rule 3130) and the Form CRS version.
- **Market abuse here, sales practices in 08, alerts at their source (CW-163).** Trade Surveillance Alert covers front running and trading ahead of customer orders, manipulation and personal-trading conflicts over 25 portfolio orders, 48 client orders and executions and 38 personal transactions. Suspicious activity is escalated to an AML Case, and the SAR is filed from the case. 29 and 50 own their monitoring alerts and hold the link to the AML Case.
- **AML case links held on the alert side (ruling 2).** 29 Alert Disposition.Escalation Case Reference, 50 Money Movement Monitoring Alert.Escalated AML Case and (proposed for 08) a Senior Investor Case reference hold the link to the AML Case; the single-valued 38 source attributes for 29 and 50 were dropped, because a case can gather many alerts. AML Case Source names each kind. AML Case rows of type Elder Financial Exploitation, or sourced from an 08 Senior Investor Case, are PII - special category (CD-344, row rule).
- **Personal trading at the firm's own broker-dealer (ruling 1).** An employee account there is a 15 Account (Personal Trading Account.Firm Brokerage Account). On those rows, Reported Personal Holding and Personal Transaction values are Derived copies of 49 Client Holding and 48 Client Execution (seven row rules in enrich_38); only outside-broker rows (Rule 3210 duplicate statements, broker feeds) and self-reported rows are mastered here.
- **FINRA Rule 3120 report (ruling 3).** Mastered here as a Compliance Program Review; 08 Supervisory Control Test.'Rule 3120 Report Date' becomes a Derived copy at the merge.
- **AML report key (CW-163, coordinator addition from the 50 draft).** Every AML and Sanctions Report has a restricted firm key (AML Report Key, "AMLR 2026-00031", no prefix). Reported Case and Report Sequence are filled only when the report is filed from a case. An OFAC blocked or rejected payment report raised directly by 50 Payment Sanctions Screening carries only the key.
- **Custody status here, custody of assets in 49 (CW-056, CW-169).** Adviser Custody Profile is the adviser's Rule 206(4)-2 status: custody bases, the related-person qualified custodians (the self-clearing broker-dealer and the trust company, LEN-), other qualified custodians (02 parties), operational independence, the surprise examination requirement and the internal control report date. Fee deduction authorizations stay 47 records (relationship row only). "Custody" is never used bare.
- **Privacy oversight, not privacy records (CW-029, CW-163).** Policy (domain Privacy), Regulatory Obligation and Compliance Program Review (Reg S-P, Reg S-ID types) cover privacy oversight. Consents are 02, notices 13, safeguards and incidents 41 (relationship rows), the retention schedule 21 (CW-068).
- **Firm filings here, fund filings in 35 (CW-069).** Form 13F stays here as the adviser's own filing. Fund-share state notice filings stay 35; adviser notice filings and state BD registrations are Entity Authorization rows with Authorization Jurisdiction.
- **Conflicts (CW-168).** The register holds the conflict; 08 Incentive Conflict Review reviews advisor compensation and account-type conflicts; 10 Cash Program Economics is the evidence for sweep conflicts. Both links are relationship rows only (no attribute), because 10 is per period and 08 holds its own link.
- **Kept retained links, held once:** policy approvals on 39 or 35; exam referral on 39; remediation on 37; project delivery on 41 Project Scope Link; obligation-to-policy on Policy.Policy Regulatory Basis.
- **PII and restricted flags.** The object-level PII rule is kept, now sourced to Regulation S-P and state privacy law. AML objects are Restricted under 31 CFR 1023.320(e) and 1024.320(e). The new client-order and client-execution subjects on Trade Surveillance Alert carry a PII note.

### Deviations from the brief

- **Attributes 291** (band 265 to 290): the AML Report Key was added at the coordinator's request after the band was set. Report Sequence was kept because DP-226 and its model read it.
- **Code lists:** 53 = 44 local + 9 shared (the earlier "55 against 45 to 52" counted shared lists as local). Three local lists were added (Form CRS Filer Capacity, Form CRS Amendment Trigger, Custody Basis); Pre-Clearance Decision was folded into Shared: Approval Status (Denied becomes Rejected) and Personal Trade Side now cites 25 Order Side. Impacted Data Domain cites the shared Business Domain as External until 09 registers 38 as a direct user.
- **Policy Domain** adds Privacy and Financial Crime, which the brief does not name (needed for CW-163 privacy oversight and the AML policies).
- **Brief §5 family names** were adopted, which renames two families (codes kept).

## 4. What could not be verified

- The FinCEN investment adviser AML rule (31 CFR Part 1032): the date is fixed at 2028-01-01 by the final rule of 2025-12-31; only the scope revision is open.
- FINRA Rule 3290: effective date not yet announced. Rules 3270 and 3280 apply until then.
- Form BD and Form ADV item numbers. Form ADV Item 9 for custody.
- Rule 206(4)-2 detail: paragraph references and the operational independence test.
- MSRB Rule G-37: applicability to 529 plan underwriting, and the MSRB URL.
- PTE 2020-02: the Section II(d) reference and the DOL URL. FATF URL.
- Example identifiers (CRD 999901, EDGAR accession, BSA ID, AMLR key) are fictitious or illustrative.
- Sibling names were checked against the current drafts: 48 Client Order and Client Execution (CLORD-, CLEXE-), 50 Money Movement Monitoring Alert (MMALT-) and Payment Sanctions Screening, 47 Fee Deduction Authorization, 41 Information Security Program and Security Incident Detail, and 08 Surveillance Alert, Incentive Conflict Review and Supervisory Review. Re-check them at the merge.

## 5. Open questions for SMEs (tailoring levers)

1. **Records retention schedule.** *Default:* 21 Retention Rule (CW-068). *Lever:* 39, for a records function in Legal; 38 only if Compliance owns records management.
2. **Surprise examination obligation.** *Default:* custody is through fee deduction and an operationally independent affiliated qualified custodian, so no surprise examination is required and the internal control report is kept (examples: Operationally Independent Y, Surprise Examination Required N). Custody Surprise Examination stays modeled for the case where the affiliate is not operationally independent. *Lever:* drop Custody Surprise Examination.
3. **Adviser AML program.** *Default:* the adviser row exists with applicability date 2028-01-01, fixed by FinCEN's final rule of 2025-12-31. *Lever:* narrow the row if FinCEN's scope revision exempts the firm's advisory business.
4. **MSRB Rule G-37 and FINRA Rule 2030.** *Default:* modeled for 529 underwriting and for government plan solicitation. *Lever:* drop them if the firm sells no municipal fund securities.
5. **Surveillance of client orders.** *Default:* market-abuse scenarios here, sales-practice scenarios in 08. *Lever:* one surveillance owner, recorded as scenario ownership only.
6. **Trust company.** *Default:* an OCC national trust bank (12 CFR 5.20) as a TR-line internal legal entity in 09. The plan's "no bank charter" means no depository charter; a trust-only national bank is the TR option. *Lever:* a state charter, or none (drop the charter, the AML row and the self-dealing category with 51).
7. **Rule 3290.** *Default:* the 3270 and 3280 values are kept. *Lever:* switch the OBA types and references when the rule takes effect.
8. **Personal trading at the firm's own broker-dealer.** *Default (ruling 1):* the account is a 15 Account (Firm Brokerage Account) and its holdings and trades are Derived copies of 49 and 48. *Lever:* none; a firm without a broker-dealer leaves the attribute blank.
9. **Third-party solicitor payments for government clients (Rule 206(4)-5(a)(2)(i)).** *Default:* not modeled. *Lever:* add them to Pay-to-Play Review.

## 6. Suggested validation steps

1. Walk one Form CRS amendment from end to end: the 38 filing and its version, then 15 delivery at opening, 13 update delivery, and the 08 delivery check.
2. Walk the custody status with the adviser's CCO: fee deduction (47), the affiliated broker-dealer as qualified custodian (49 holds the assets), the surprise examination, and Form ADV-E.
3. Walk one front-running alert on a 48 client order, from the alert to the AML Case, the SAR decision and the report. Then walk one OFAC rejected payment from 50 to an AML and Sanctions Report without a case.
4. Walk one 13G filing: 18 and 49 holdings, the determination, the filing, and EDGAR acceptance.
5. Map the code of ethics objects to the personal trading platform's export, and the conflict categories to the Form ADV Part 2A and Form CRS text.
