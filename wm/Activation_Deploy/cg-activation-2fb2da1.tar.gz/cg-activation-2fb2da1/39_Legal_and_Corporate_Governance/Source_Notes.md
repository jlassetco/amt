# Source Notes: 39 Legal & Corporate Governance

**Workbook:** `Legal_and_Corporate_Governance_Data_Taxonomy.xlsx` (built from `_tools/content/content_39_legal_and_corporate_governance.py`)
**Status:** Draft v0.1, wealth model (direct), scope US, 2026-10-14: the draft of 2026-10-06 (independent review applied) carried over with the US-only pass and the perspective rewrite of CW-939 (section 6). 6 families, 29 objects (28 business objects, 1 attribute group), 237 attributes, 83 proposed CDEs (35%), 65 references, 7 derived copies, 0 unresolved, 44 code lists (33 local, 11 enterprise shared lists cited directly), 35 relationships, 19 sources, 50 attributes flagged PII.

**Why this domain exists.** The firm is a US wealth manager (holding company, registered investment adviser, self-clearing broker-dealer, fund trusts and an optional trust company, organized under Delaware, Maryland and other state law). Its general counsel's office and company secretariat keep the firm's legal record:
- executed contracts and their documents
- disputes, litigation and enforcement matters
- legal holds
- the boards, officers and resolutions of the firm's own companies, and who may sign for them
- the trademarks that protect the firm's names

Before this draft, that record was scattered:
- Each business domain kept its own contracts (05 `AGR-`, 14 `DLA-`, 26 `TAGR-`, 35 `ADVA-`).
- Custody agreements, charters, LPAs and SOWs existed only as text marked "future owner 39" (20, 26, 28, 30, 35).
- Legal holds existed only as two indicators (02, 08), with no hold record behind them.
- Corporate boards were excluded from 35 by design (CD-231).

The shared-concept pattern (CD-144, CD-257) gives Legal the generic contract record and its key. Each business domain keeps only the typed profile it produces.

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| CLOC Core 12 and legal operations maturity model | https://cloc.org | Intake (legal service requests), contract lifecycle stages, matter management, outside counsel management |
| LEDES e-billing formats and ABA UTBMS code sets | https://ledes.org | Invoice review fields, timekeeper IDs, UTBMS task codes (cited as an external format) |
| Federal Rules of Civil Procedure 26 and 37(e); Zubulake v. UBS Warburg | https://www.law.cornell.edu/rules/frcp/rule_37 | Duty to preserve and its trigger date, privilege, spoliation risk |
| The Sedona Conference Commentary on Legal Holds, Second Edition | https://thesedonaconference.org | Hold notice, custodians, acknowledgment, reminders, scope, release |
| Delaware General Corporation Law Title 8 Ch. 1 (ss.141, 142, 228; franchise tax) | https://delcode.delaware.gov/title8/c001/ | Boards and committees, officers, unanimous and stockholder written consents |
| Maryland Corporations and Associations Article; SDAT annual report | https://dat.maryland.gov | Maryland corporations and statutory trusts (governing law value, statutory filing type) |
| FinCEN Beneficial Ownership Information reporting | https://www.fincen.gov/boi | Final rule of August 2026 (Federal Register citation to confirm) making the domestic exemption permanent: the firm's own US entities file no BOI report; only an entity formed under foreign law and registered in a state still reports (the FinCEN BOI Report value is a lever for such a subsidiary) |
| FASB ASC 450-20 | https://asc.fasb.org | Probable, reasonably possible and remote; accrual and disclosure (topic only, licensed) |
| IAS 37 | https://www.ifrs.org/issued-standards/list-of-standards/ias-37-provisions-contingent-liabilities-and-contingent-assets/ | Probable (more likely than not), possible and remote; provision vs contingent liability |
| SEC Division of Enforcement, Enforcement Manual (updated 2026-02-24) | https://www.sec.gov/divisions/enforce/enforcementmanual.pdf | Formal orders, subpoenas, Wells notices and submissions (matter types and events) |
| USPTO trademarks, TSDR; Lanham Act ss.8, 9, 15 | https://www.uspto.gov/trademarks | Serial and registration numbers, statuses, maintenance deadlines |
| WIPO Nice Classification and Madrid System | https://www.wipo.int/classifications/nice/en/ | Nice classes (external format), international registration and dependency period |
| eIDAS Regulation (EU) 910/2014; US ESIGN Act | https://eur-lex.europa.eu/eli/reg/2014/910/oj | Electronic signature validity (signed date, envelope ID) |
| SEC Rules 204-2 and 17a-4; FINRA Rule 4511 | https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.204-2 | Retention context that a hold suspends |
| SEC Form ADV and Rule 206(4)-7 | https://www.sec.gov/about/forms/formadv.pdf | Adviser CCO designation (Corporate Officer Role) |
| SEC Regulation S-P, 17 CFR 248.30 (2024 amendments) | https://www.ecfr.gov/current/title-17/chapter-II/part-248/subpart-A | Oversight of service providers: the Data Protection and Privacy Terms clause type (CW-939); state privacy law service-provider terms (CPRA) are named in the value description |
| ASC 842 / IFRS 16, OECD TPG, ILPA Principles 3.0 and Model LPA | https://www.ifrs.org/issued-standards/list-of-standards/ifrs-16-leases/ | Context for the typed lease, intercompany, side letter and LPA records |
| Vendor cross-checks: Ironclad, Icertis, Diligent Entities, Mitratech / Onit | https://www.diligent.com | Structure only: contract repository, entity and board management, matter management |

## 2. Design decisions and boundary calls

**Generic contract here, typed profile there (CD-257, as amended by program lead ruling 3).**
- The typed owners are 01, 05, 10, 14, 16, 26, 28, 30, 35, 40, 43 and 44.
- Contract holds family, subtype, hierarchy role, parent, contracting entity (09 `LEN-`) or fund (01 `PRD-`), status, dates, governing law, legal owner and business lines.
- Typed Contract Link holds at most one link: 05 `AGR-` or its amendment, 14 `DLA-`, 26 `TAGR-`, 35 `ADVA-`, 28 Securities Lending Agreement, 30 side letter, Investor Commitment, Private Fund Profile and `FCF-`, 10 `ICA-`, 16 `PSVA-`, 01 `MND-`, and 43 `DEBT-` and `INPOL-`.
- 40 Supplier Contract Profile (keyed by `CTRCT-`) and 44 Lease (Lease Contract) hold the link from their own side. Typed Record Type still names them.
- Bank mandates are untyped contracts that reference the 43 Corporate Bank Account. The 43 draft has no mandate agreement record.
- No fee, payment, collateral, lending or side letter economics is held here.

**Amendments (ruling 5).**
- Every executed amendment is its own Contract, with a Parent Contract and its own typed link where one exists (05 Agreement Amendment). Otherwise its dates are mastered here.
- Document versions are drafts and conformed copies of one instrument.
- Each version holds one file per Document Sequence and Document Role (main agreement, exhibit, counterpart, DPA).

**Row rule (ruling 4).**
- Six attributes stay flagged Derived copy with declared owner "05": Contract Status, Contract Effective Date, Contract Expiry Date, Governing Law, Contract Party Role and Key Date Value.
- Each note states "owner = domain of the typed link; mastered in 39 on untyped rows". The note is the authority.
- External and Internal Contract Party carry the same rule in their notes.
- A per-row owner mechanism is requested in proposals_39 NOTES.

**One link per approval (rulings 1 and 2).**
- What a corporate resolution approved is held only on Corporate Resolution Subject Link. Subject types now include memberships, officer appointments, powers of attorney and signing authority grants. No 39 object holds its own approving resolution.
- 37, 38 and 42 drop their consumer-side references; 43 holds none.

**One direction for other links (ruling 2).**
- 39 Legal Matter.Originating Examination is the exam-to-matter link; 38 drops Referred Legal Matter.
- 37 holds the link from a loss event to a matter.
- 13 Servicing Provider Engagement is proposed to reference the TA service Contract.

**Corporate boards here, fund and GP boards in 35 (CD-231, CD-259, ruling 6).**
- Boards of funds, fund-management entities and private fund general partners are 35. Carry vehicles and holding entities with no fund-governing role are 39.
- An affiliated CIT trustee bank's own corporate board is 39; its fiduciary committee is 35.

**Each fact held once (ruling 6).**
- Contract effective and expiry dates are held only on Contract; Key Date Type no longer has those values.
- The regulator of a matter is held only on Matter Regulator; Matter Party Role has no Regulator value.
- Outside counsel is held only on Outside Counsel Engagement.
- Member independence is held only on Independent Member Indicator.
- The SM&CR approval date was removed because 08 masters it (SM&CR content left entirely under CW-939).

**Assessments and keys.**
- Matter Financial Assessment is per reporting entity and assessment date, with separate ASC 450 and IAS 37 likelihoods.
- Contract Key Date carries a sequence.
- Outside Counsel Engagement is keyed by its engagement letter Contract and the matter.

**Entity, enforcement and hold boundaries.**
- 09 entity facts are not repeated.
- Enforcement matters reference the 38 exam (CD-253).
- Legal Hold Scope is the source of the 02 and 08 indicators (CD-258) and references 41 Application (`APPL-`).

**Other choices.**
- Corporate Resolution Subject Link is a 29th object, against brief §5 (it mirrors 35).
- Trademark License Grant is now a Business Object (review D7), against brief §5.
- UTBMS task codes and Nice classes are cited as external formats.
- Local list count is 33, against a target of 24 to 30.
- CDEs now include the counterparty and matter party references and six principal typed links. The share was held at 35% by not flagging descriptive or secondary attributes (Document Location, Power Scope, Membership Body and others).

**Prefixes.** Only the seven reserved prefixes appear, in the published formats. Sibling examples use the owners' formats (AGR-004512, AGR-004512-A03, DLA-000184, TAGR-00118, ADVA-00041, ICA-0019, PSVA-00921, ICMT-000188, APV-2026-0018833, LEN-0004, EXAM-2026-0007, FILNG-ADV-2026-00002, POLCY-0118, RAS 2026 OPS 04, APPL-00412, DEBT-0003, BKAC-00118, INPOL-DO-2026-01). CGOV- is kept; 42 renames COVG-.

### Review response

All findings and the program lead rulings were applied, except the following:

- **A10 (Low), Protected Brand resolves to 04:** no change before consolidation, as the reviewer suggested. Re-check that it resolves to 42 after CD-271 is applied.
- **F3 (Low), Contract Subtype has 36 values (above about 30):** the CIT Participation Agreement value and a family crosswalk were added, but the list was not shortened. Each subtype is needed to index a distinct typed or untyped instrument.
- **F5 (Low), CD-255 Regulator values (FinCEN, OFAC, OFSI, NCA):** not added, because CD-255 is not yet applied and the local copy must match the shared list. The IRS description was corrected. The additions, and DOJ / state attorney general, are proposed in proposals_39. (The OFSI and NCA part of that proposal lapsed under CW-939: no UK regulator values in the wealth model.)
- **F7 (Low), Governing Law has no "Unknown":** not added. The list stays the 05 values plus Maryland until it is promoted to a shared list (SHARED_CANDIDATES).
- **E1 / E3 (Medium / Low), stand-in owner "05":** kept as declared owner per ruling 4. The note is the authority; the per-row owner mechanism is requested.
- **J (Medium), "flag the populated typed link":** a CDE cannot be set per row, so the six highest-volume links (05 agreement, 14, 26, 35, 01 mandate, 30 investor commitment) were flagged, together with Typed Record Type. The other nine links are not CDEs, to keep the share at 35%.
- **Attributes dropped to stay within 240:** Notice Period Days, Clause Reference, Party Added Date, Votes For, Votes Against, Billing Arrangement and Rate Card Reference. The C6 rate card finding was resolved by dropping the rate card, not converting it.

## 3. What could not be verified

- Page paths for CLOC Core 12, The Sedona Conference commentary, the Maryland SDAT page: confirm. The SEC Enforcement Manual edition was checked by the reviewer.
- The exact LEDES format versions in use and the client's UTBMS code set (litigation vs counseling).
- That Rule 206(4)-7 CCO, 31 CFR 1023.210 and SMF17 are the right labels for every entity type in the group.
- Grace periods around the Lanham Act deadlines: confirm with IP counsel.
- Federal Register citation of the August 2026 FinCEN BOI final rule.

## 4. Open questions for client SMEs

1. Which contract lifecycle tool is the repository, and is it the system of record for 05 and 14 agreements or only an index?
2. Does Legal keep executed copies of 05 agreements in the repository? [Settled at the W2-W4 merge: yes. The 05 Agreement Document and DOC- are retired (CW-131) and the 39 Contract Document Version is the only executed-copy record.]
3. Are IMAs for SMA and institutional mandates signed and stored by Legal or by 12 client onboarding?
4. Which internal entities have boards distinct from fund and GP boards, and is the CIT trustee bank an internal entity?
5. Which matter management and e-billing tools are used, and is outside counsel spend approved in procurement (40)?
6. Who issues legal holds for regulatory exams (38), as opposed to litigation?
7. Are signing authority matrices maintained by Legal, Finance or the company secretary?
8. Are domain names held by Legal (IP) or by Technology / Corporate Communications (41, 42)?
9. Are LPAs and side letters for private funds stored by Legal or by 30 fund formation?
10. Which group entities report under US GAAP and which under IFRS, for matter assessments?

## 5. Recommended next steps

1. Apply the PROPOSED_CHANGES in proposals_39:
   - re-typings in 28, 35 and 20
   - Derived copies in 02 and 08
   - text notes in 26, 30 and 35
   - removal of approval references in 37, 38 and 42
   - 38 drops Referred Legal Matter
   - 43 relationship wording
   - 13 reference to the TA service Contract
   - 02 Party Role Type values
2. Implement a per-row owner mechanism (plan §4 item 9) for the six row-rule attributes.
3. Register 39 as a direct user of the 11 shared lists and switch the attributes to "Shared: <name>". Promote Governing Law to a shared list with "Maryland".
4. Crosswalk each typed owner's agreement type list to Contract Subtype.
5. Validate with the general counsel, company secretary, litigation and IP counsel, and the controller (reserves).

## 6. Wealth model carry-over (W1b, CW-939)

39 is kept (plan section 5.1). The pass made the changes CW-022 allows and no others: the US-only pass, the perspective text and the Business Line example. No object is removed and no object or attribute is renamed; one attribute leaves. The decision draft and the jurisdiction entries are in `_tools/consolidation/proposals_w1b_39.py`.

**Removed (EU/UK only; 34 jurisdiction entries: Other EU/UK 20, UK market practice 5, ICARA 3, SM&CR 3, GDPR / UK GDPR 2, UCITS 1).**
- Attribute: Corporate Resolution Subject Link.Subject ICARA Assessment (43 removes ICARA Assessment under CW-943).
- Values: Corporate Officer Role SM&CR Senior Management Function Holder and Money Laundering Reporting Officer (MLRO, UK SMF17; the US AML Compliance Officer / BSA Officer stays); Corporate Resolution Subject Type ICARA Assessment (43); Statutory Filing Type UK Confirmation Statement, UK PSC Register Update, UK Annual Accounts Filing, UK Officer Appointment / Termination, Luxembourg RCS Filing, Luxembourg RBE Beneficial Owner Filing, Irish CRO Annual Return; Forum Type UK Court and EU Member State Court (relabeled into one Non-US Court, with Other added, program lead ruling: the funds claim in foreign collective actions and English-law contracts stay, CW-022) and Employment Tribunal (UK, removed); Corporate Meeting Type Written Resolution (UK Companies Act Part 13); Clause Type Data Protection (GDPR Article 28 DPA); Contract Subtype Depositary Agreement (UCITS / AIFMD); IP Office EUIPO, UKIPO and Benelux Office for IP; Docket Deadline Type EU / UK Renewal.
- Sources (6 removed, one split): UK Companies Act 2006; Companies House guidance; Luxembourg Business Registers (RCS, RBE); EUIPO; GDPR Article 28; FCA SM&CR and Form A; the FCA MIFIDPRU 7 and UK Modern Slavery Act parts of the SEC Form ADV source row.

**Re-sourced.**
- Data-protection clauses to Regulation S-P service-provider oversight (17 CFR 248.30) and state privacy law contract terms: Clause Type value Data Protection and Privacy Terms (replaces the GDPR Article 28 value), the Clause Type secondary reference and list source, the Data Processing Agreement subtype description; source row Regulation S-P added.
- Statutory filings to Delaware and state annual reports and FinCEN beneficial ownership reporting: Statutory Filing Type re-cut to Delaware Annual Franchise Tax Report, Maryland Annual Report and Personal Property Return, Other State Annual Report (new, the US instance of the removed UK and Luxembourg registry filings), FinCEN BOI Report (a lever only for a foreign-formed subsidiary registered in a state: FinCEN's August 2026 final rule exempts the firm's domestic entities; confirm) and Other; the Statutory Filing attributes cite DGCL, FinCEN BOI or Internal; examples are a Delaware franchise tax report (period 2025, due 2026-03-01).
- Governance attributes lose their UK Companies Act references (Corporate Body Type, Member External Party, Corporate Member Role, Corporate Meeting Date and Type, Minutes Approval Status, Subject Body Membership, Subject Capital Transaction) and cite DGCL or Internal; Corporate Officer Role cites SEC Rule 206(4)-7; Regulatory Notification Filing reads "Form ADV or Form BD amendment" and the 08 note names Form U4.
- Matter Regulator loses the FCA secondary reference; the GDPR Article 10 notes on matter parties read "criminal history data (restricted tier, CD-344)".
- Trademark attributes lose the EUIPO secondary reference; the Permitted Use example is a US ETF name.
- Subject Corporate Publication cites Internal and uses a corporate responsibility report example (CRR/0004/2025/1) instead of the UK modern slavery statement.

**Kept on purpose (CW-022).** Governing Law values England and Wales, Scotland, Luxembourg, Ireland, Germany, Switzerland (contract law is a legal fact of the instrument); the eIDAS Regulation beside the ESIGN Act (signature validity for instruments under a foreign governing law); IAS 37 Likelihood and the IAS 37 source (used only where an entity reports under IFRS; a tailoring lever, see open question 1); WIPO Madrid and Other National Office (foreign protection of the firm's marks is a lever, not a regime). The 1940 Act fund boards stay 35's; 39 references them only in text.

**Perspective rewritten.** META subtitle; overview Purpose, Core model, Design principles 2 and 8, Notes; the Corporate Entity Governance and Statutory Filings texts; SUMMARY in `enrich_39.py` (ICARA reference removed; the ICARA ownership override removed). The Contract Business Lines example uses the CW-004 code PF (W1 merge notes section 5). "ManCo, AIFM, ACD" read "1940 Act fund board" and "the CIT trustee's fiduciary committee".

**Re-pointed.** None needed: every Reference (Party) and (Contact Point) still resolves (CW-021); 39 names no wholesale 02 role profile.

**Added.** None (the brief names no addition for 39).

**Left for later stages (not changed, listed in the proposals NOTES).** References to 05 (Agreement Amendment, Agreement Document, Distribution Agreement typed link and its Typed Record Type values), to 30 (Side Letter, Investor Commitment, Private Fund Profile, Fund Credit Facility, their typed links, Typed Record Type values and the Private Fund Investor Document family) and to 08 (retention rules) stay. Contract Subtype Fund Participation Agreement ("insurance-dedicated funds") and carry vehicles in the governance text are W4 residues.

**Open questions (W1b).**
1. Does any group entity report under IFRS? If not, IAS 37 Likelihood and its list can go at W4 (lever).
2. Which states beyond Delaware and Maryland hold entity annual reports (Other State Annual Report)?
3. Does the firm register its marks outside the US (WIPO Madrid, other national offices)?

**Unverified.** Federal Register citation of FinCEN's August 2026 BOI final rule (confirm); the Regulation S-P 248.30 service-provider oversight paragraph (confirm; the 2024 amendments are in force).

**Review fix pass (2026-10-14).** BOI wording follows FinCEN's August 2026 final rule; Forum Type regains Non-US Court and Other; UK corporate vocabulary relabeled (Independent / Outside Director, Corporate Secretary, Annual and Special Meeting of Stockholders, Compensation Committee; five JURISDICTION entries, regime UK market practice); DP-230 added to READERS; the OFSI / NCA proposal marked lapsed; Regulation S-P amendments stated as in force; the decision's domains list names 39 only.
