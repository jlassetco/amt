# Source Notes: 40 Procurement & Vendor Management

**Workbook:** `Procurement_and_Vendor_Management_Data_Taxonomy.xlsx` (built from `_tools/content/content_40_procurement_and_vendor_management.py`)
**Status:** Draft v0.1, wealth model (direct), scope US, 2026-10-14: the reviewed draft of 2026-10-06 carried over with the US-only pass and the perspective rewrite of CW-940 (section 6). 6 families, 21 objects (19 business objects, 2 attribute groups), 172 attributes, 57 proposed CDEs (33%), 38 references, 6 derived copies, 32 code lists (24 local, 8 enterprise shared lists cited directly), 35 relationships, 14 sources, 17 attributes flagged PII.

**Why this domain exists.** The firm is a US wealth manager: direct brokerage through its self-clearing broker-dealer, digital and human advice, its own mutual funds, ETFs and CITs, workplace recordkeeping, institutional advisory and optional trust services. The procurement and vendor management office buys everything the firm does not make: technology, data, services, outsourced operations (statement print and mail, fund administration, cloud hosting), contingent labor and facilities. It onboards each supplier, runs sourcing events, raises purchase orders, confirms receipt, matches invoices before 19 pays them, measures supplier performance and decides how critical each supplier is. It also keeps the outsourcing register with exit plans that the US rules expect a firm to be able to show: FINRA Rule 3110 and Regulatory Notice 21-29 for functions the broker-dealer outsources, SEC Rule 38a-1 for fund service providers, Regulation S-P (as amended in 2024) for service providers with access to customer information, and the 2023 interagency guidance on third-party relationships for the optional trust company and the CIT trustee. Before this domain, the supplier existed only as a 02 party with no supplier profile, 19 held "Purchase Order Reference" as text, 14 held a procurement supplier number, and 20 held contingent workers' statements of work as text. The purchase-to-pay and third-party lifecycle has its own owner and system (the procurement suite), and 14 data vendors, 13 servicing providers and 28 custody providers are specializations of one supplier record (CD-144, CD-260), not separate masters.

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| FINRA Rule 3110 and Regulatory Notice 21-29 (2021) | https://www.finra.org/rules-guidance/notices/21-29 | Supervision of outsourced broker-dealer functions: due diligence, monitoring, exit and contingency planning (Outsourcing Arrangement, Exit Plan, tiering) |
| SEC Rule 38a-1 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.38a-1 | US fund service provider oversight (Fund Service Provider Role link) and, with Advisers Act Rule 206(4)-7, the adviser's oversight of service providers. History: the SEC's outsourcing proposal for advisers (Release IA-6176, proposed Rule 206(4)-11) was withdrawn on June 12, 2025; it was a regime value until CW-940 and is no longer one. |
| SEC Regulation S-P, 17 CFR Part 248 Subpart A, as amended May 2024 | https://www.ecfr.gov/current/title-17/chapter-II/part-248/subpart-A | Service-provider oversight for customer information (17 CFR 248.30), the Data Protection Assessment onboarding step and the Shared Data Assets source |
| California Consumer Privacy Act as amended by the CPRA | https://oag.ca.gov/privacy/ccpa | Personal data of individual suppliers; sensitive personal information revealed by two diversity certification values |
| Interagency Guidance on Third-Party Relationships: Risk Management (2023) | https://www.federalreserve.gov/supervisionreg/srletters/SR2304.htm | Lifecycle, criticality-based due diligence, onboarding steps, contingency and termination planning (applied to the trust company and the CIT trustee, adopted firm-wide) |
| ISO 20400:2017 | https://www.iso.org/standard/63026.html | Procurement process stages, supplier performance dimensions (structure only) |
| UN/CEFACT Buy-Ship-Pay and Recommendation 20 | https://unece.org/trade/uncefact | Purchase order, line, receipt, payment terms concepts |
| UNSPSC | https://www.unspsc.org | Category code external format |
| Coupa and SAP Ariba public documentation | https://www.coupa.com ; https://www.sap.com/products/spend-management.html | Sourcing event types, PO types, two- and three-way match, hold reasons (structure only) |
| IRS Forms W-9, W-8BEN-E | https://www.irs.gov/forms-pubs/about-form-w-9 | Supplier tax documentation: the payee form on file (Form W-9, substitute Form W-9, W-8 series) is mastered here (CW-940); the tax status and masked TIN stay on the 02 Tax Profile |
| OFAC sanctions programs and SDN List | https://ofac.treasury.gov | Supplier sanctions screening |
| US SBA size standards | https://www.sba.gov/federal-contracting/contracting-guide/size-standards | Small and diverse business certification types |
| ISO 4217 / 3166 / 8601 / 9362 / 13616 / 20022 | https://www.iso.org | Formats |

## 2. Design decisions and boundary calls

- **One supplier, specialized profiles (CD-260 rule 1).** Supplier Profile is keyed by the 02 `PTY-` (one row per status period) and holds no name, legal form, LEI, address, contact, TIN of its own. Tax Form on File is mastered here for suppliers (CW-940): the wealth 02 holds no form type (02 Tax Profile.Tax Status Evidence points only to 15 Account Tax Certification) and 15 covers accounts only; it becomes a Derived copy (02) if 02 extends the form on file to the Supplier role. Supplier Engagement (`VENG-`) links to 14 Data Vendor, 13 Servicing Provider Engagement, 28 Custody Provider Profile and 01 Product Party Role, and copies none of them. The ERP supplier number is held once, as "SUP 0045521".
- **AML link held once (review High).** Supplier Onboarding Case holds the screening disposition only; 38 AML Case holds the only link (Source Supplier Onboarding Case), because the case number is restricted under SAR confidentiality.
- **Sourcing the firm issues (rule 2).** Sourcing Event (`SRCG-`) types are qualified ("Sourcing RFP"). Sourcing Award is one row per awarded supplier, with its share, value, engagement and 39 contract, so split awards are recorded.
- **Order and match here, invoice and payment in 19 (rule 3, CD-158).** Invoice Match Result is keyed by the 19 Payable Invoice (`APV-`) plus the invoice line number (a Derived copy (19)); it holds the matched quantity, matched amount, unit price used and tolerance applied, and the variances computed from them. 19 is asked to add Invoiced Quantity and Invoiced Unit Price to Payable Invoice Line, after which Unit Price Used becomes a Derived copy, and a remit-to account reference on Supplier Payment. Supplier Spend Summary Invoiced and Paid Amounts are Derived copies (19), credit notes signed negative by Payable Document Type, assigned by Invoice Date and Payment Value Date, in the group reporting currency.
- **Firm purchases only (rule 4).** Supplier Engagement carries a Fund-Paid Indicator; fund-paid engagements have no purchase order.
- **Tier here, risk in 37, register here (rule 5, CD-248, CD-249, CD-261, CD-268).** Supplier Risk Tiering holds the dated inherent tier (list renamed Third-Party Criticality Tier), drivers (the "Supports Critical or Important Function" driver is set from 37 references) and due-diligence depth. 37 designates functions; Outsourcing Arrangement's critical-or-important indicator is a Derived copy (37).
- **DORA register grain (program lead decision 1).** Removed in the wealth model (CW-940, section 6): the register of information objects (ICT Register Arrangement Header, ICT Register of Information Entry, Supply Chain Subcontractor), the two B_02.01 fields on Supplier Contract Profile and the seven register lists left with them. The wholesale design stays at tag wholesale-v1.0.
- **Function references.** 37 Critical or Important Function holds designated functions only; Outsourcing Arrangement references them. In the wealth model the designation follows the critical activities of the 2023 interagency guidance and FINRA Regulatory Notice 21-29 (CW-940).
- **Terms here, contract in 39 (rule 6, CD-257).** Supplier Contract Profile exists only on 39 contracts that are untyped or typed "Supplier Contract Profile (40)"; data licenses keep commercial terms in 14 and leases in 44. Contract Status is a Derived copy (39); the register copies of the contract dates, notice periods and governing law country left with the DORA register (CW-940).
- **One performance review per engagement.** Row rule: 14, 13 and 28 review data-vendor, servicing and custody engagements; 40 reviews every other engagement. Contracted Service Level rows exist only where 13, 14, 05 and 44 do not measure the service.
- **PII.** Diversity Certifications flag sensitive personal information under state privacy laws (CW-940; the wholesale text cited GDPR Article 9) for an individual holding the LGBTQ+-owned or disability-owned values; remittance details use the shared labels "Restricted - Personal Data" / "Restricted"; every supplier party reference carries the individual-supplier note.
- **Qualified list names.** Contract Pricing Model, Sourcing Disqualification Reason, Invoice Match Status, Purchase Requisition Status, Third-Party Criticality Tier (Outsourcing Notification Status, DORA Substitutability and DORA ICT Service Type left at CW-940).
- **Deviations from the brief.**
  - Family "Supplier Performance" named "Supplier Performance & Spend"; family code `VM-PRF` kept.
  - 25 objects (brief 24) in the wholesale draft, ICT Register Arrangement Header added (removed at CW-940, now 21); Sourcing Award is now a Business Object (two attribute groups remain: Supplier Remittance Detail, Exit Plan).
  - Supplier Profile has no primary category or tax form date; Supplier Contract Profile has no rate card reference, benchmarking right, spend commitment or escalation terms (size target).
  - No 25 Approved Counterparty Profile link: 25 holds the outsourced trading provider on Best Execution Policy, and the engaged supplier is the same party.
  - Information Classification, Frequency and Risk Rating shared lists are not used.
  - 32 local code lists against a target of 22 to 28: seven DORA register enumerations and Payment Terms accounted for the excess (24 local after CW-940).
  - "SEC Outsourcing Proposal (withdrawn)" was kept as a historical Outsourcing Regime value (CD-261); removed at CW-940 (section 6).
- **Hand-offs proposed at Stage 4 (not applied; proposals_40.PROPOSED_CHANGES; the DORA items lapse with CW-940):** 19 Purchase Order Reference, overview notes, Payable Invoice Line quantity and unit price, Supplier Payment remit-to account; 02 Tax Form Type / TIN applies-to and Party Role Type values; 14 Procurement Supplier ID and each ICT Third-Party Register Entry field with its 40 source (DLA- translated to CTRCT- through 39 Typed Contract Link; UK Important Business Service Mapping removed from the list for lack of a 40 source; n : 0..1 cardinality), 14 VRA fields and Strategic Tier; 20 Supplier Contract Reference; 37 business function register; 39 notice side and Governing Law country; 41 adoption of the DORA ICT Service Type list.

### Review response

All three High findings and all Medium findings were applied, as were the Lows except these:
- **B_02.01 fields not on the register header.** Decision 1 asked for the entity-grain fields of B_02.01 and B_07.01 to move to a register header. B_07.01 fields are on the new ICT Register Arrangement Header (contract x ICT service type). B_02.01 is keyed by contract alone, so its fields (arrangement type, annual expense) went to Supplier Contract Profile, as the review proposed; putting them on the header would repeat them for every ICT service type of a contract.
- **Register Supplier Engagement on the header, not the entry.** Entries reach it through the header key (contract x ICT service type), which avoids holding it once per entity and function.
- **Engagement Status and Outsourcing Arrangement Status keep the shared Record Status** (Low F): a local engagement lifecycle list would add a 33rd list; exit is evidenced by End Date. Noted on the attribute.
- **Code list count (Low F)** accepted at 32 local; Due Diligence Depth is not folded into the tier list, because the depth is a policy consequence of the tier that may change on its own.
- **ESMA and CSSF source URLs (Low G)** were home pages; both sources left at CW-940.
- **Invoice match history (Low D)** accepted as latest run only; the note on Match Timestamp says hold history stays in the procurement suite's audit log.

## 3. What could not be verified

- The DORA, ESMA and CSSF items of the wholesale draft lapsed with their removal (CW-940).
- FINRA Regulatory Notice 21-29 page, the 2024 Regulation S-P amendments (service-provider oversight in 17 CFR 248.30) and the withdrawal of the SEC outsourcing proposal (Release IA-6176, 2025-06-12): confirm (section 6).
- UNSPSC example "43230000" (segment 43, family 4323 Software): confirm against the current UNSPSC release.

## 4. Open questions for client SMEs

1. Which procurement suite (Coupa, SAP Ariba, Oracle) and which ERP supplier master is the system of record for suppliers?
2. Who maintains supplier remittance bank details: procurement, accounts payable (19) or treasury (43)?
3. Does procurement or the risk function set the criticality tier, and does the tier feed 37 automatically?
4. Which entities keep an outsourcing register: the broker-dealer only (FINRA Rule 3110), or every entity including the adviser, the funds and the trust company?
5. Are fund service providers (custodian, administrator, TA) procured through 40 or appointed by fund boards with Legal only?
6. Are contingent workers bought through POs, statements of work or a vendor management system (decides the 20 re-typing)?
7. Is legal spend (outside counsel) bought through POs or approved in 39 e-billing only?
8. Which spend thresholds require a sourcing event, and are single-source justifications recorded?
9. Do data-vendor outsourcings (14) appear in the 40 outsourcing register, or does 14 hold its own oversight view?
10. Is a four-way match used anywhere (for example for facilities work), and what price tolerance applies?
11. Does any regulator expect advance notice of an outsourcing (for example the trust company's chartering authority), so that a notification record is needed (tailoring lever; the wholesale Outsourcing Notification is restorable from wholesale-v1.0)?
12. Should 39 allow a second typed link so data licenses and leases can carry a 40 Supplier Contract Profile?

## 5. Recommended next steps

1. Validate families, statuses, PO types, tiers, drivers, regimes and CDEs with procurement, accounts payable, TPRM, compliance and legal.
2. Agree the 19, 14 and 20 hand-offs and the 02 Party Role Type values at the Stage 4 consolidation.
3. Map Outsourcing Arrangement and Exit Plan to the vendor oversight tool and the broker-dealer's written supervisory procedures.
4. Agree with 37, 39 and 41 the sibling object names used here once their drafts are final.
5. Map attributes to the procurement suite and the ERP (supplier master, PO, goods receipt, invoice verification).
6. Register the copied shared lists (proposals_40.SHARED_MEMBERSHIPS) and decide the shared-list candidates.

## 6. Wealth model carry-over (W1b, CW-940)

40 is kept (plan section 5.1). The pass made the four kinds of change CW-022 allows and no other: the US-only pass, the perspective text, the re-pointing of wording around the replaced 02, and Business Line values re-cut to CW-004. The brief names no addition for 40. Object and attribute names are unchanged except for the removed ones; attribute IDs renumber in the Supplier Contracts and Criticality & Outsourcing families. The decision draft and the jurisdiction entries are in `_tools/consolidation/proposals_w1b_40.py`.

**Removed (EU/UK only; 76 jurisdiction entries: DORA 51, Other EU/UK 19, FCA 3, CRS 2, GDPR / UK GDPR 1).**
- Objects: ICT Register Arrangement Header (DORA B_07.01), ICT Register of Information Entry (B_02.02), Supply Chain Subcontractor (B_05.02), Outsourcing Notification (FCA SYSC 8, CSSF Circular 22/806, EBA guidelines).
- Attributes: Supplier Contract Profile.ICT Contractual Arrangement Type and Annual ICT Expense (B_02.01); Outsourcing Arrangement.Supported Important Business Services (FCA SYSC 15A).
- Local code lists (whole): DORA ICT Service Type, DORA Substitutability, Reintegration Possibility, DORA Assessment Level, Level of Reliance, Contractual Arrangement Type, Arrangement Termination Reason, Outsourcing Notification Type, Outsourcing Notification Status.
- Values: Outsourcing Regime EBA Outsourcing Guidelines, ESMA Cloud Outsourcing Guidelines, FCA SYSC 8, CSSF Circular 22/806, DORA ICT Third-Party, UCITS / AIFMD Delegation; Diversity Certification Type UK SME; Tax Form Type CRS Self-Certification - Individual and - Entity.
- Sources: DORA Articles 28-30, ITS (EU) 2024/2956, RTS (EU) 2024/1773, EBA/GL/2019/02, ESMA50-164-4285, FCA SYSC 8 and SYSC 15A, CSSF Circular 22/806, GDPR Articles 9 and 28, UK OFSI (from the sanctions source).

**Re-sourced.**
- Outsourcing Arrangement (ID, Outsourcing Entity, Outsourced Function Description, Outsourcing Regimes, Supported Critical or Important Functions, Critical or Important Outsourcing Indicator, Outsourcing Contract, Intragroup Outsourcing Indicator, Service Commencement Date) to FINRA Regulatory Notice 21-29, FINRA Rule 3110, the 2023 interagency guidance and Regulation S-P; the example function is statement print and mail for the broker-dealer.
- Exit Plan (Exit Strategy Type, Alternative Providers, Planned Transition Period, Exit Plan Last Tested Date) and Supplier Contract Profile.Exit Assistance Period to the interagency guidance and FINRA Regulatory Notice 21-29.
- Supplier Risk Tiering (Third-Party Criticality Tier, Criticality Drivers) to the interagency guidance and FINRA Regulatory Notice 21-29; lists Criticality Driver and Exit Strategy Type re-sourced the same way.
- Outsourcing Regime re-cut to the US set: FINRA Rule 3110 Supervision of Outsourced Functions, SEC Rule 38a-1 Service Provider Oversight, Advisers Act Rule 206(4)-7 Service Provider Oversight, Reg S-P Service Provider Oversight, Interagency Third-Party Guidance (Trust Company), Other. The withdrawn SEC outsourcing proposal (Release IA-6176, withdrawn June 12, 2025) is no longer a value; its history is kept in section 1.
- Supplier Engagement.Shared Data Assets and the onboarding step Data Protection Assessment to Regulation S-P service-provider oversight (17 CFR 248.30) and state privacy law (GDPR Article 28 before).
- Diversity Certifications and the two sensitive certification values to state privacy law (sensitive personal information; GDPR Article 9 before).
- Sanctions Screening Result to OFAC alone; Bank Identifier to the ABA routing number (BIC for a supplier paid abroad; the UK sort code format is gone) and Bank Account Number (Masked) to a US example.
- Tax Form on File (ownership change ruled by the program lead, CW-940): 40 masters the supplier's tax form on file; the wealth 02 holds no form type (the form on file is a 15 Account Tax Certification), so the attribute is mastered here for suppliers until 02 extends it to the Supplier role; its Derived (02) flag is removed. Tax Form Type is a local list aligned to the IRS forms of 15 (CRS values removed, Substitute Form W-9 and W-8ECI added).

**Perspective rewritten.** META subtitle; overview Purpose, Scope, Core model, Design principles 5, 7 and 9, Applies To, CDE, Primary / Secondary Reference, Notes and Suggested next steps; the Criticality & Outsourcing family text and the Supplier Contract Profile object text; Engagement Business Lines example "PF; DB" (CW-004; "Mutual Fund; ETF" before); 02 is named Client & Household, the party core for every external party (CW-023); SUMMARY in `enrich_40.py`.

**Re-pointed.** No reference changes type: Reference (Party) resolves to the wealth 02 (CW-021). The wording of Tax Form on File and the out-of-scope list now names the wealth 02 Tax Profile and the 15 Account Tax Certification. 40 no longer references 41 (the IT service and application links sat on the removed register header) and no longer cites the shared Regulator list.

**Left for later stages (not changed).** "deal costs (30)" in design principle 4 (30 retires at W4); "RFPs the firm answers (03)" and the "03 RFP Requests (RFP-)" note on the Sourcing family (03 replaced later); "05 Service Level Agreement" in the Contracted Service Level row rule (05 replaced at W4); the 13 Servicing Provider Engagement specialization (13 adapted at W2).

**Open questions (W1b).**
1. Does the adviser keep its own outsourcing register under Rule 206(4)-7, or only the broker-dealer under FINRA Rule 3110 (see question 4)?
2. Does the trust company's charter (OCC or state) bring a notification duty for material outsourcing that would restore Outsourcing Notification in a US form?
3. Should Regulation S-P service providers be flagged on the engagement (a firm-wide list that the incident response program in 41 uses for the 72-hour notice) rather than read from the Outsourcing Regimes value?

**Unverified (confirm).** Verified by the W1b review: FINRA Regulatory Notice 21-29 (URL and title), the 72-hour service-provider notice in the 2024 Regulation S-P amendments, the withdrawal of Release IA-6176 on June 12, 2025. Still to confirm: the CPRA definition of sensitive personal information as the basis of the two restricted diversity values.
