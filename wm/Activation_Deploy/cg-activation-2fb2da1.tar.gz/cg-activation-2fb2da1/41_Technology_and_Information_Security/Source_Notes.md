# Source Notes: 41 Technology & Information Security

**Workbook:** `Technology_and_Information_Security_Data_Taxonomy.xlsx` (built from `_tools/content/content_41_technology_and_information_security.py`)
**Status:** Draft v0.1, wealth model (direct), scope US, 2026-10-14: the reviewed draft of 2026-10-06 (`00_Program/Expansion/Reviews/41_review.md`) carried over with the US-only pass, the perspective rewrite and the Regulation S-P and S-ID additions of CW-941 (section 7). 7 families, 34 objects (31 business objects, 3 attribute groups), 289 attributes, 87 proposed CDEs (30.1%), 45 local code lists plus 11 enterprise shared lists (56 in all), 59 relationships, 33 sources, 46 cross-domain references, 0 derived copies, 0 unresolved. Enrichment: `_tools/enrichment/enrich_41.py`. Proposals: `_tools/consolidation/proposals_41.py` and `proposals_w1b_41.py`.

**Why this domain exists.** Every Data Domain names a system of record, but until now no domain could say what a system is. 21 held an interim "System" list (CD-160), 18 held Book of Record System as a code marked "future 41", 14 kept a Consuming Application only for market data declarations, and 36 held Launch Project Code as text. The technology organization (the CIO's application and infrastructure teams, the CISO's security operations, the IT service desk and the PMO) maintains the records that resolve these: the application inventory, configuration items, identities and access, IT incidents, changes, projects and security tests. The firm is a US wealth manager (a self-clearing broker-dealer, an investment adviser, its own funds and an optional trust company), so several of these are regulatory records in their own right: the safeguards and incident response program with customer notification under Regulation S-P as amended in 2024, the identity theft red flags program under Regulation S-ID, the business continuity expectations of FINRA Rule 4370 and FINRA's cybersecurity guidance, the FFIEC expectations for the trust company and, as the firm's chosen frameworks, NIST CSF 2.0, the NIST AI RMF and the ISO/IEC 27001 Annex A inventory, access and incident controls. Regulation SCI applies only if an entity of the firm is an SCI entity (section 7).

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| ITIL 4 practices (incident, problem, change enablement, service configuration, release, deployment) | https://www.axelos.com/certifications/itil-service-management | Incident, problem, known error, change types (standard, normal, emergency), change authority, CI, release and deployment concepts; priority = impact x urgency. Public summaries only; no licensed text reproduced. |
| NIST CSF 2.0 (CSWP 29, Feb 2024) | https://doi.org/10.6028/NIST.CSWP.29 | Govern / Identify / Protect / Detect / Respond / Recover outcomes framing the families. |
| NIST SP 800-53 Rev 5 | https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final | AC-2 account management and review, AC-5 separation of duties, AC-6 least privilege, CM-3 change control, IR, RA-5 vulnerability monitoring. |
| NIST SP 800-61 Rev 3 (April 2025, verified) | https://csrc.nist.gov/pubs/sp/800/61/r3/final | Incident lifecycle; detection, containment, eradication dates. Replaces Rev 2 (2012). |
| NIST SP 800-34 Rev 1 | https://csrc.nist.gov/pubs/sp/800/34/r1/upd1/final | RTO, RPO, recovery strategies, contingency plan testing. |
| NIST SP 800-40 Rev 4 | https://csrc.nist.gov/pubs/sp/800/40/r4/final | Patch and vulnerability remediation timing, end of support. |
| NIST SP 800-63 (Digital Identity Guidelines) and SP 800-145 | https://csrc.nist.gov/pubs/sp/800/63/4/final | Identity, MFA; cloud service and deployment models for Hosting Model. |
| FIPS 199 | https://csrc.nist.gov/pubs/fips/199/final | Low / Moderate / High impact levels for C, I and A. |
| ISO/IEC 27001:2022 and 27002:2022 | https://www.iso.org/standard/27001 | Annex A 5.9 inventory and ownership, 5.15-5.18 access, 5.24-5.28 incidents, 8.8 vulnerabilities, 8.32 change. |
| ISO/IEC 19770-1:2017 | https://www.iso.org/standard/68531.html | IT asset management and software license position. |
| SEC Regulation S-P amendments, Release 34-100155 (adopted May 16, 2024; FR June 3, 2024; verified) | https://www.sec.gov/rules/final/2024/34-100155.pdf | Incident response program, sensitive customer information, notice within 30 days of becoming aware, Attorney General delay, service provider notice within 72 hours. Compliance: larger entities Dec 3, 2025, smaller June 3, 2026. |
| SEC proposed adviser cybersecurity rule (2022), withdrawn June 12, 2025 | (not cited in SRC) | Context only; not modeled as a requirement. |
| 17 CFR Part 248 Subpart A (Regulation S-P, section 248.30) | https://www.ecfr.gov/current/title-17/chapter-II/part-248/subpart-A | Safeguards and incident response program, service-provider oversight, compliance dates (Information Security Program, Governing Response Program). |
| 17 CFR Part 248 Subpart C (Regulation S-ID, sections 248.201-202) | https://www.ecfr.gov/current/title-17/chapter-II/part-248/subpart-C | Identity theft prevention program, red flags, board approval, annual report (Information Security Program, Identity Theft Red Flag Indicator). |
| FINRA Rule 4370 and FINRA cybersecurity guidance | https://www.finra.org/rules-guidance/key-topics/cybersecurity | Business continuity and recovery (Recovery Tier, Tested Financial Entity); cybersecurity program practices (confirm page). |
| Regulation SCI, 17 CFR 242.1000-1007 | https://www.ecfr.gov/current/title-17/section-242.1000 | Applies only to SCI entities; a value of Security Program Type, not applicable by default (confirm). |
| NIST AI RMF 1.0 (NIST AI 100-1) and Generative AI Profile (NIST AI 600-1) | https://www.nist.gov/itl/ai-risk-management-framework | AI system profile, human oversight, logging (replaces the EU AI Act). |
| FINRA Regulatory Notice 24-09 (generative AI) | https://www.finra.org/rules-guidance/notices/24-09 | Supervision of AI tools (Human Oversight Assignee; confirm). |
| NIST SP 800-115 and SP 800-84 | https://csrc.nist.gov/pubs/sp/800/115/final | Test types, testers, tabletop exercises (replaces the DORA testing and TLPT references). |
| State data breach notification laws | https://www.ncsl.org/technology-and-communication/security-breach-notification-laws | Personal data breach notice alongside Regulation S-P (replaces GDPR Articles 33-34; confirm page). |
| SEC Rules 17a-4 and 204-2 | https://www.ecfr.gov/current/title-17/section-240.17a-4 | Retention of AI system logs that are books and records. |
| ISO/IEC 42001:2023 | https://www.iso.org/standard/81230.html | AI system inventory linked to use cases. |
| TOGAF Standard 10th ed.; Gartner TIME | https://www.opengroup.org/togaf | Application portfolio catalog, application/function matrix; TIME dispositions. |
| ServiceNow CSDM / CMDB (public docs) | https://www.servicenow.com/docs | Business application vs application service, business / technical service, CI classes and relationship types (structure only). |
| FIRST CVSS v4.0; CVE; CISA KEV | https://www.first.org/cvss/v4-0/ | Base score, version, CVE ID, known-exploited flag. |
| VERIS; MITRE ATT&CK | https://veriscommunity.net | Seven threat action categories (Malware, Hacking, Social, Misuse, Physical, Error, Environmental) and actor categories. |
| CIS Controls v8.1 | https://www.cisecurity.org/controls | Asset inventory, MFA, privileged accounts. |
| FFIEC IT Examination Handbook | https://ithandbook.ffiec.gov/ | Optional trust company and CIT trustee context (SME question 6). |
| FASB ASC 350-40, ASU 2025-06 (issued Sept 2025; verified) | https://www.fasb.org | Capitalization of internal-use software (decision is 19's). |
| PMI PMBOK Guide | https://www.pmi.org/standards/pmbok | Program, project, phase, baseline, milestone, cost at completion. |

## 2. Design decisions and boundary calls

- **21 designates, 41 describes (CD-263).** Application carries no system-of-record flag; Application Capability Mapping carries no authority. Capability codes are text, as 21 holds them.
- **Provider platforms are Applications** with hosting model "Provider-Hosted" (CD-147), so 01, 09 and 18 references to a fund administrator or TA system resolve.
- **Criticality vs recovery.** Criticality Tier is held only on Application; Recovery Tier, RTO, RPO only on Application Recovery Profile. Whether an application supports a critical or important function is 37 Resilience Resource Mapping, never held here (important business services left with CW-937 and CW-941).
- **Incidents (CD-266, CD-245, program lead ruling).** IT Incident is the technical record of every class (service disruption, security event, data integrity). A security event carries Security Incident Detail with the Reg S-P determination, Became Aware Date and Customer Notice Due Date, and the service provider notice timestamp. 41 holds no 37 reference, no regulatory severity classification and no regulator report; the 37 Operational Incident holds the only link (ITINC-). Major Incident Indicator is the ITIL procedure flag only. The customer notices themselves are 13 / 12 communications; 41 holds counts, never identities.
- **Access (CD-265).** Digital Identity references EMP- or PTY- and holds no person attributes. System Access Grant references the triggering ELE- and the provisioned ENT- (one direction).
- **Projects (CD-267).** Project Scope Link is the only project link, with one typed reference per delivered object type. 36 Launch Project Code becomes a Derived copy; the 38 brief's "implementing 41 project" on Regulatory Change Impact is flagged in proposals_41 as conflicting with the rule.
- **AI (CD-269).** AI System Profile (attribute group of Application) holds deployment facts (NIST AI RMF since CW-941); AI System Model Deployment holds each 37 Model Inventory Entry the system runs, dated; AI System Use Case Link is the only APPL- to AIU- link. The firm's AI operator roles stay on 21 AI Use Case.
- **Register (CD-268, ruling).** IT Service carries the ICT Service Type, a firm-defined list since CW-941 (the DORA S01-S19 taxonomy and the 40 register of information were removed). No contractual-arrangement, provider-criticality or function attribute here.
- **Policies (ruling).** IT and security standards are rows in the 38 Policy library; 41 references them on Access Review Campaign and Vulnerability Finding.
- **Information Classification** is applied as an access-role ceiling, not re-created (CD-270).
- **Links held once (program lead decision 3).** The VULN- to ISSUE- link is held on 37 (typed issue source); the latest DR test of an application is read from Security & Resilience Test.Tested Applications. Reg S-P notices are linked from 13 / 12 (proposed Reference (IT Incident, 41)).
- **Legal entities.** Application.Owning Legal Entity and IT Incident.Affected Legal Entities attribute technology risk to the broker-dealer, the adviser, the funds and the trust company.
- **PII rule.** Every attribute of a Digital Identity, IT Asset Assignment, System Access Grant or Access Review Decision row is flagged PII; employee references elsewhere carry the internal-staff PII note.

**Deviations from the brief**
1. Release holds no "linked changes" list; the link is held once, on Change Request.Implemented Release (one direction).
2. Security categorization is three FIPS 199 attributes (confidentiality, integrity, availability) with a local Security Impact Level list.
3. AI System Profile holds no "general-purpose model basis" attribute: it is a property of the 37 model and already on 21 AI Use Case. "Input data control" was an indicator (removed at CW-941, EU AI Act); instructions-for-use location dropped to keep the size in range. Deployed models are a dated child object (AI System Model Deployment, +1 object: 33 against 32).
4. Access Review Campaign scope is modeled as Reviewed Application plus Privileged Access Only Indicator rather than a scope list.
5. Vulnerability Finding has no separate "discovery source" list: Source Test is blank for continuous scanning.
6. Local lists: 44 (brief: 30-36). Added Security Impact Level, DR Strategy, Identity Status, IT Service Category, IT Incident Status, Detection Source, Data Impact Type, Threat Actor Category, Delivery Methodology, Test Outcome, Project Status and Change Approval Step so that no status list mixes dimensions; Interface Type became Interface Mechanism; EU AI Act Operator Role was removed. Case Status is used only for Problem Record (incident status has its own list, since Case Status values such as "Waiting on Client" do not fit).
7. Business Domain is used on Project (Impacted Data Domains); the local copy adds 22-44 as proposed values (the shared list stops at 21).
8. Firm codes without prefixes (IFC, SVC, PRB, UAR, SRT, program name codes) key the objects without reserved prefixes; their formats are published in proposals_41 FIRM_CODE_FORMATS.
9. Change Approval is a business object (change x approval step), not an attribute group, so several approvals per change are held.
10. Software License Position references the Application (the product is held once, on Application); Software Publisher was dropped (Application.Software Vendor).

### Review response

All High and Medium findings and the program lead decisions were applied: ICT Service Type S01-S19 with Annex III labels (shared candidate, steward 41, 40 to adopt; replaced by a firm-defined list at CW-941); Incident Occurrence Timestamp and Occurrence Time Estimated Indicator; Vulnerability Finding.Risk Acceptance Issue and Application Recovery Profile.Last Disaster Recovery Test dropped; the 38 note reworded; the duplicated Attorney General value removed and the indicator reworded (the Attorney General informs the Commission); Root Cause Category made exclusive; Interface Mechanism separated from Message Standard; Project Status added (CDE) and Project Phase made phase-only; AI System Model Deployment and multi-step Change Approval; Granting and Revoking Lifecycle Events; Firm AI Act Operator Role removed (21 holds it); Licensed Application replaces the second product name; IT Service and Test code formats published; the 13 / 12 notice link made a firm proposal; Owning Legal Entity and Affected Legal Entities added. Lows applied: Vendor Technical Contact, register-authority note on Third-Party Service Provider, Loss Incident dropped, RTO governs the tier, Log Retention code list blanked, (multi) on multi-valued references, calculated notes, examples (technology OU, freeze calendar, two policies, every Scope Link target), Deployed By definition, Problem 1 : 0..n, Tested Configuration Items, one PII rule, Identity Type, Hosting Model rule, Delegate removed, VERIS Unknown, 43 note, SMA questionnaires in Scope, confirm notes removed, shared Information Classification wording.

Not applied, with reason:
- F (Low) local list count: kept at 44. Folding IT Service Category, Deployment Result or Identity Status into other lists would mix dimensions or objects, which the brief's review checklist forbids; the deviation is recorded above.
- F (Low) Record Status on CI, IT Service and Interface: kept the shared list and added the CMDB state mapping as a note on Configuration Item Status, to confirm with the CMDB owner.
- C (Low) CDE on License Compliance Gap: kept, with a note that the value is calculated (one of the review's two options).
- To trim back to 280 attributes after the additions, six low-value attributes were dropped: Change Approval Timestamp (CAB date kept), Planned Production Release Date, Cloud Region, Primary Model Indicator, Access Review Campaign Name, Rolled Back Indicator (Deployment Result and Change Outcome 'Failed - Rolled Back' hold it).

## 3. What could not be verified

- The EU AI Act and Digital Omnibus items lapsed with their removal (CW-941).
- The CW-941 additions and re-sourcing items listed in section 7 (confirm).
- SR 26-2 (cited per the 37 brief, CD-246) not independently verified; URL is the SR letters index.
- NIST SP 800-63-4 final URL, ISO/IEC 19770-1 catalog number and the ServiceNow CSDM documentation URL: confirm.
- ITIL 4 page now under PeopleCert; confirm URL.

## 4. Open questions for client SMEs

1. Which tool is the application inventory (ServiceNow APM, LeanIX, a spreadsheet), and does it also hold the CMDB?
2. Are outsourced provider platforms (TA, fund administrator) inventoried as Applications, or as IT Services only? (Draft: Applications, Provider-Hosted.)
3. Is the IT incident record for security events held in the ITSM tool or in a separate SOC case tool?
4. Does the CISO team or the 37 operational risk team set the severity of an IT Incident, and which data points must 41 capture first for the Regulation S-P determination?
5. Which identity sources feed provisioning (HRIS joiner events from 20, a contractor register)?
6. Is the optional trust company (and CIT trustee) a national trust bank subject to OCC IT examinations or a state-chartered trust company?
7. Does the PMO manage only technology projects, or all change including product launches and regulatory change?
8. Are project costs capitalized as internal-use software (ASC 350-40, as amended by ASU 2025-06), and who holds the capitalization decision (41 or 19)?
9. Which personal data breaches not caused by a security incident (misdirected mail) are notified, and by whom (38 or the privacy office)?
10. Should 14 Consuming Application be re-keyed to APPL- (option A) or keep DAPP- with a reference (option B)?
11. Should Interface, IT Service, Problem, Access Review Campaign and Test codes get registered prefixes (formats published in FIRM_CODE_FORMATS meanwhile)?
12. Do CMDB states map to the shared Record Status as noted on Configuration Item Status?

## 5. Overlaps with other domains (for consolidation)

All re-typings are in `proposals_41.py` VALUE_PROPOSALS: 21 Hosting System, Designated System, System of Record, Source System and the retirement of the "System" list; 18 Book of Record System and Event Source System; 09 Code Mapping Source System and Subscribing System; 01 System Cross-Reference Source System; 02 Record Metadata Source System; every 01-16 Record Metadata System of Record (excluded objects); optional 03 Activity Source System, 05 Sub-Accounting Platform, 30 Private Fund Platform; 28 SWIFT overview; 14 Consuming Application and 04 Marketing System (CD-264); 20 overview (CD-265); 36 Launch Project Code (CD-267); 40 and 14 Supported IT Service (CD-268); 37, 39, 42, 43 references to APPL-, ITINC-, VULN- and the 41 test; 13 / 12 Related IT Incident on Reg S-P notices; 40 adoption of the S01-S19 ICT Service Type list (lapsed at CW-941) and the SVC code format.

## 6. Recommended next steps

1. Validate families, lists and CDEs with the CIO, CISO, ITSM lead, enterprise architecture and PMO.
2. Load the application inventory first and re-point the system references listed above.
3. Agree with 37 the incident data points its severity classification reads, and with compliance the entities each Regulation S-P and S-ID program covers.
4. Map attributes to the APM, CMDB, IGA, ITSM, vulnerability management and PPM tools.

## 7. Wealth model carry-over (W1b, CW-941)

41 is kept (plan section 5.1). The pass made the four kinds of change CW-022 allows: the US-only pass, the perspective text, the re-pointing of wording around the replaced 02, Business Line values re-cut to CW-004, and the one addition the brief names. Object and attribute names are unchanged except for the removed attributes; attribute IDs renumber in the Application Portfolio, IT Service & Incident Management and Security Testing & Vulnerabilities families. The decision draft and the jurisdiction entries are in `_tools/consolidation/proposals_w1b_41.py`.

**Removed (EU/UK only; 30 jurisdiction entries: DORA 26, Other EU/UK 2, FCA 1, GDPR / UK GDPR 1).**
- Attributes: AI System Profile.Input Data Controlled Indicator (EU AI Act Article 26(4) deployer duty); IT Incident.Occurrence Time Estimated Indicator (DORA incident report data point); Security & Resilience Test.TLPT Attestation Date (DORA Article 26).
- Values: Test Type "Threat-Led Penetration Test (TLPT)"; the 19 DORA Annex III values (S01-S19) of ICT Service Type, replaced by a firm-defined list (the attribute stays).
- Sources: DORA, ITS (EU) 2024/2956, RTS (EU) 2024/1772 with 2025/301 and 2025/302, RTS (EU) 2025/1190 (TLPT), EU AI Act (Regulation (EU) 2024/1689), FCA SYSC 15A, GDPR Articles 4(12), 33 and 34.
- NIS2 and UK cyber rules: no hit in the wholesale module.

**Re-sourced.**
- ICT Service Type (IT Service) to a firm-defined list (Cloud - SaaS, PaaS, IaaS, Hosting and Data Center Services, Network and Telecommunications, Software Development and Engineering, Application Support and Operations, Help Desk and End-User Support, Security Services, Data Provision and Analytics, Software Licensing, Hardware and Devices, ICT Consulting and Project Services, Other).
- AI System Profile (AI System Provider, Log Retention Months, Human Oversight Assignee) and AI System Model Deployment to the NIST AI RMF, with FINRA Regulatory Notice 24-09 and SEC Rule 17a-4 where they apply; Application Type value AI System to the NIST AI RMF definition.
- IT Incident timing and impact (Incident Occurrence Timestamp, Incident Detected Timestamp, Service Restored Timestamp, Service Downtime Minutes, Data Impact Types, Detection Source, Incident Root Cause Category) to NIST SP 800-61, ITIL 4 and FIPS 199; the Detection Source, Data Impact Type and Root Cause Category lists the same way.
- Security & Resilience Test (Test Type, Tested Applications, Tested IT Services, Tested Financial Entity, External Tester) to NIST SP 800-115, NIST SP 800-34, FINRA Rule 4370 and the FFIEC handbook.
- Personal Data Affected Indicator and Affected Individuals Estimate to Regulation S-P and state breach notification laws (GDPR before); Owning Legal Entity, Affected Legal Entities, Criticality Tier, Recovery Tier and the access grant dates lose their DORA references.

**Regulations kept and stated (the brief's row).** Regulation S-P safeguards and incident response with customer notification (2024 amendments; the existing Security Incident Detail attributes: Became Aware Date, Customer Notification Determination and its date, Customer Notice Due Date, Attorney General Delay Indicator, Notifying Service Provider and the 72-hour service provider notice); Regulation S-ID; FINRA cybersecurity expectations and Rule 4370; NIST CSF 2.0. Regulation SCI is stated as a program type that applies only to an SCI entity: a self-clearing broker-dealer is not an SCI entity unless it operates an SCI alternative trading system (confirm with compliance).

**Added (plan section 5.1, CW-941).**
- New object Information Security Program (IT Service & Incident Management family; no prefix, firm code "ISP nnnn"): Security Program Code, Security Program Type (Regulation S-P Safeguards and Incident Response, Regulation S-ID Identity Theft Prevention, Firm Information Security Program, Regulation SCI Policies and Procedures, Other), Covered Legal Entities, Program Policy (38), Program Owner, Program Approval Date, Program Last Review Date, Last Board Report Date, Program Compliance Date, Security Program Status.
- Security Incident Detail: Governing Response Program (Reference (Information Security Program, 41)) and Identity Theft Red Flag Indicator.
- Three relationships; local list Security Program Type; nine sources (17 CFR 248.30, Regulation S-ID, FINRA Rule 4370 and cybersecurity guidance, Regulation SCI, NIST AI RMF, FINRA Regulatory Notice 24-09, NIST SP 800-115 and 800-84, state breach laws, SEC Rules 17a-4 and 204-2).

**Perspective rewritten.** META subtitle; overview Purpose, Scope, Core model, Design principles 2 and 6, Applies To, CDE, Primary / Secondary Reference, Notes and Suggested next steps; the IT Service & Incident Management and Security Testing family texts and the AI System, IT Service and Security Incident Detail object texts; examples: Business Lines Served "DB; DA; HA" and Program Business Lines "PF; WR" (CW-004); capability "C-15.05 Account Opening & Maintenance"; IT Service Name "Client brokerage account servicing"; Access Role Name "Client correspondence approver"; interface endpoints (NSCC Fund/SERV and ACATS, DTC, SWIFT, plan sponsor payroll feeds, market data vendors); "investor-portal" reads "client-portal"; 02 is Client & Household; SUMMARY in `enrich_41.py`.

**Left for later stages (not changed).** The 13 and 12 Reg S-P notice records ("Shareholder Communication [13] / Client communication [12]" relationship and the Security Incident Detail texts; 13 adapted at W2, 12 at W4); "private fund administrator" in the Provider-Hosted value of Hosting Model (30 retires at W4); "30 Private Fund Platform" in section 5.

**Open questions (W1b).**
1. Which entities does each program cover (the transfer agent, if registered, is also a Regulation S-P covered institution)?
2. Is any entity an SCI entity (an ATS above the Regulation SCI thresholds)? If not, the Regulation SCI value can be dropped.
3. Should the Regulation S-ID red flag on an incident also carry the covered account (a 15 reference), or is the 15 account restriction enough?

**Unverified (confirm).** FINRA cybersecurity key-topics page and Regulatory Notice 24-09 title; the NCSL breach-law page; the eCFR section URLs for 17 CFR 242.1000 and 240.17a-4; the Regulation S-ID annual board report and board approval wording (17 CFR 248.201 and its Appendix A); the NIST AI RMF wording of the AI system definition.
