# Source Notes: 42 Corporate Communications & Public Affairs

**Workbook:** `Corporate_Communications_and_Public_Affairs_Data_Taxonomy.xlsx` (built from `_tools/content/content_42_corporate_communications_and_public_affairs.py`)
**Status:** Draft v0.1, wealth model (direct), scope US, 2026-10-14: the reviewed draft of 2026-10-06 (`00_Program/Expansion/Reviews/42_review.md`) carried over with the US-only pass and the perspective rewrite of CW-942 (section 7). 8 families, 27 objects (27 business objects, 0 attribute groups), 227 attributes, 69 proposed CDEs (30.4%), 35 code lists (29 local, 6 enterprise shared lists), 38 relationships, 12 sources, 66 references, 2 derived copies, 0 unresolved.

**Why this domain exists.** The firm is a US wealth manager (direct brokerage, digital and human advice, its own funds, workplace recordkeeping, institutional advisory, optional trust services). Its corporate communications and public affairs team speaks for the firm as a company rather than for its products: it owns the corporate brand, answers journalists, writes press releases and internal announcements, runs crisis communications, publishes corporate statements and represents the firm to governments and trade bodies. Nothing in 01-41 mastered a media inquiry, a policy position or a lobbying report; 04 lists "Press Release" only as a Content Type of a content asset, which proposals_42 asks 04 to retire or key to the 42 release. Two of its records are legal disclosures with their own filer, deadlines and penalties (LDA registrations and LD-2 / LD-203 reports; state lobbying registrations and reports), and a corporate statement is approved by the firm's leadership or a board, not by the product marketing chain.

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| Lobbying Disclosure Act of 1995 as amended by HLOGA 2007 (2 U.S.C. 1601 et seq.) | https://www.law.cornell.edu/uscode/text/2/chapter-26 | Lobbying contact and covered official definitions (1602), registration (1603), reports (1604). Lobbying Contact Indicator, Lobbying Registration, Lobbying Disclosure Report. |
| LDA Guidance (Clerk of the House, Secretary of the Senate) | https://lobbyingdisclosure.house.gov/ldaguidance.pdf | LD-2 due 20 days after quarter end, LD-203 due 30 days after half-year end, LD-2 amounts rounded to the nearest USD 10,000, three expense methods (LDA, IRC 6033(b)(8), IRC 162(e)), covered official positions in the prior 20 years, general issue area codes, LD-203 gift and travel rule certification. The PDF did not render in my tools; the points are from my knowledge and secondary sources (see §3). |
| LDA threshold update effective 2025-01-01 | https://insidepoliticallaw.com/2025/03/10/ldas-registration-thresholds-increase-for-lobbyist-employers-and-lobbying-firms/ | In-house organization expense threshold USD 16,000 per quarter (from USD 14,000), next adjustment 2029-01-01. Verified by web search. |
| State lobbying statutes (for example New York Legislative Law Article 1-A) | https://ethics.ny.gov/lobbying (confirm) | State registration of lobbyists and their employers, periodic reports (Lobbying Regime, Registrant Category, Lobbying Report Type, Registration Jurisdiction). Added at CW-942. |
| SEC Rules 17a-5(c) and 15c3-1 | https://www.ecfr.gov/current/title-17/section-240.17a-5 | Statement of financial condition furnished to customers with the net capital note (Publication Type, Source Capital Requirement Calculation). Added at CW-942; website availability to confirm. |
| SEC Regulation D Rules 502(c) and 506(c) | https://www.ecfr.gov/current/title-17/chapter-II/part-230 | General solicitation limits: Fund in Offering Indicator. |
| FINRA Rule 2210; SEC Marketing Rule | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2210 | When a release is a communication 08 reviews; paid award entries. |
| IRC 162(e) and 6033(e) | https://www.law.cornell.edu/uscode/text/26/162 | Lobbying portion of dues, reported by the association. |
| GRI 2 (2-28, 2-29) and GRI 415 | https://www.globalreporting.org/standards/ | Membership associations, stakeholder groups, public policy. |
| PRSA Code of Ethics | https://www.prsa.org/about/prsa-code-of-ethics | Disclosure of information, conflicts, embargo practice (definitions only). |
| AMEC Barcelona Principles 4.0 (June 2025) | https://amecorg.com (confirm page URL) | Measurement concepts for coverage and reputation (reach, sentiment, share of voice as context). Release date confirmed by web search. |
| ISO 20671 / ISO 10668 | https://www.iso.org/standard/68570.html (confirm edition) | Brand evaluation structure only. |
| GHG Protocol Corporate Standard | https://ghgprotocol.org/corporate-standard | Publication sources from 44. (The SFDR entity PAI statement is a 34 record; removed after review.) |

## 2. Design decisions and boundary calls

1. **Brand moved (CD-271, MOVE option per program lead ruling).** The 04 Brand's six attribute tuples and the lists Brand Level and Brand Status are copied verbatim (checked programmatically against `content_04`); `content_04` is not edited and 04 removes them at merge. After review, by program lead decision, Brand Level is flagged CDE (the only difference from the 04 tuple; propose the same at merge) and the per-level stewardship row rule is stated on the Brand Register object group; Brand Steward Function was dropped. One governance attribute is added: Brand Owning Entity. All brand rows are mastered here. Because BRD- is still registered to 04, the five internal brand references are forced "mastered here" in `enrich_42.OWNERSHIP_OVERRIDES`.
2. **Prefix rename COVG- -> MCOV- (program lead ruling).** COVG- is an anagram of 39's CGOV-. MCOV- is one letter from RCOV- (23), which the brief had rejected; recorded in `proposals_42.PREFIXES` with the reason.
3. **04 holds channels, 42 holds the message (CD-272).** No URL or handle register; Press Release and Corporate Publication reference WEB-. Coverage on social media records the Social Platform only.
4. **42 publishes, others produce.** Corporate Publication holds publication facts only and has a firm-defined ID (`SFC/0003/2025/1` since CW-942). Board approval is held only on 39 Corporate Resolution Subject Link; 42 holds a derived Publication Board Approval Date. Stewardship reports and entity PAI statements are 34 records and are not publication types here. Publication Source Link has one typed reference per source master (20 Human Capital Metric Value, 34 PAI Calculation, 43 Capital Requirement Calculation, 44 Operational Emission Record), or an Other Source Record Key that names the owning domain. No figure is copied.
5. **Lobbying here, political money in 38 (CD-273).** LD-203 rows reference 38 Political Contribution records (multi) and copy no amount. Registration ID is held only on Lobbying Registration; Registered Lobbyist and Lobbying Disclosure Report reference the registration.
6. **Trigger held once.** Communications Issue holds typed trigger references to 37, 41, 39 and 44 (health and safety, and physical security), selected by Issue Trigger Type. Issue Level is separate from Case Status. Social media mentions are mastered by 04 Social Listening Mention and referenced from the issue.
7. **Awards.** Corporate Award Entry holds entries for any award; Firm Award Result only for firm-level and individual corporate awards; fund and portfolio manager results, and the paid-to-participate fact, are the 11 Award referenced through AWD-. Award Result has the 11 Award Outcome values verbatim.
8. **Media contacts.** Media Contact Profile is keyed by the 02 PTY- of a journalist or an outlet (Media Outlet Type is filled on outlet rows), following the 17 Issuer Profile pattern.
9. **Internal engagement** is aggregate only (no per-person rows), pending SME Q7.

**Deviations from the brief**
- COVG- renamed MCOV- (ruling).
- Size: the first draft had 264 attributes; trimmed to 230 (the top of the 180-230 range). Dropped among others Brand Business Lines, Release Wire Service, Release Campaign, Coverage Monitoring Provider, Registration Owner, Lobbying Registration Status (status follows the termination date). As a result the shared lists Business Line and Frequency (brief §8) are not used.
- Local lists not created from the brief's expected set: Inquiry Response Type is kept, but "Issue Trigger Type" also serves as crisis plan scenario types; "Association Membership Tier" is used as named. Added: Brand Steward Function, Press Release Status, Publication Status, Publication Source Domain, LDA Expense Reporting Method, Registrant Category.
- Consultation Response holds the consultation reference on the response (no separate consultation object); grain consultation x responding entity, as the brief states.
- Tax strategy (Finance Act 2016 Sch.19) was added to Publication Type; removed at CW-942 with the other UK publication duties.
- Public Policy Position approver and Trade Association Membership committee seats (brief §5) and Press Release campaign link (brief §4) are deliberately left out to stay within the 230-attribute ceiling; 04 Campaign references a release through its own content if needed.

### Review response

Applied: all three High findings (program lead decisions 1-3), every Medium (decision 4 and the rest: LD-203 lobbyist rows via Filing Lobbyist and an amendment sequence in the LOBR- key; EU TR Cost Band; Trigger Physical Security Incident; 04 Press Release content type and Social Listening Mention row rule in proposals; paid-entry flag dropped in favor of 11 Award; Brand Level CDE with Brand Steward Function dropped; Statement Type limited to form; Spokesperson Topic list separate from Policy Topic; 38 identifier and LD-203 scope dependency; Corporate Publication, Corporate Event, Official Contact IDs; Audience Job Profile and Leadership Group defined; Registration Jurisdiction example US-NY; Award Entrant Type split into Portfolio Manager and Individual (Corporate)), and these Lows: Issue Line Lobbyists note; Below LD-2 Reporting Floor Indicator; Media Training note names the learning item; covered positions separated with ';'; Source Data Domain dropped (Other Source Record Key names the domain); Measurement Period Start; Crisis Plan Code; PAIC- and BCP examples; neutral Internal Communication key; LDA lists cited as external formats; 'Other' values added; REL note; Mentioned Brands restored; Structure text; CDE flags moved off descriptive text onto Measurement Value; sibling names re-checked; local list count reduced to 28 (Brand Steward Function, Publication Source Domain, two LDA lists removed; Spokesperson Topic and EU TR Cost Band added).

Trimming to stay at 230 attributes after the additions also dropped: Brand Owner, Brand Use Approval Status, Spokesperson Approved By, Corporate Event Owner (the last two also cleared the missing-PII Low), Internal Communication Classification, Reactions Count, Crisis Plan Last Exercised Date and Report Due Date (derivable from report type and period).

Not applied, with reason:
- Low (Release Campaign, brief §4): not restored; size ceiling. Recorded above.
- Low (Policy Position approver, membership committee seats): not added; size ceiling. Recorded above.
- Low (Reported Political Contributions example): stays '(38 key pending)' until 38 publishes a key; dependency logged in proposals_42.
- Low (Information Classification steward label): moot; the list is no longer used in 42.
- Low (Brand Level / Brand Status not CDE to keep tuples identical): superseded by the program lead decision to flag Brand Level as CDE; Brand Status stays non-CDE.
- Low (Media Training Completion Date key): no Reference (Learning Completion, 20) added (size ceiling); the note names the source learning item.

## 3. What could not be verified

- 38 Political Contribution has no identifier attribute, and its scope is Rule 206(4)-5 pay-to-play; whether it captures every LD-203 item (FECA contributions of USD 200 or more, honorary expenses, payments for events honoring covered officials) is an open dependency (proposals_42 NOTES).
- The EU Transparency Register items lapsed with their removal (CW-942).
- The LDA Guidance PDF could not be rendered; LD-2 rounding (nearest USD 10,000), due dates and the three expense methods are from knowledge, consistent with the brief. Confirm against the February 2025 revision.
- LDA general issue area codes and the houses and agencies list are now cited as external formats; confirm example labels.
- Format of LDA Senate / House IDs in examples ("401103942-12") is illustrative.
- AMEC Barcelona Principles page and ISO 20671 edition URLs (marked "confirm").
- Sibling object names were re-checked against the 37-41, 43 and 44 modules after review; all match. HSEI- and PSI keys follow 44's published examples.

## 4. Open questions for client SMEs

1. Is the brand register run by corporate communications or by marketing (CD-271 option A or B)?
2. Does the firm or an affiliate register under the LDA, and does it use outside lobbying firms that report it as a client?
3. In which states does the firm register lobbyists or appear as a lobbyist employer (state and local registers; the Registration Jurisdiction)?
4. Do press releases about funds go through 08 review in every case, or only when they mention performance?
5. Is crisis communications run from the same tool as 37 incident management?
6. Which corporate publications does a board approve (the broker-dealer statement of financial condition is approved by management and audited at year end), and which entity's board?
7. Does internal communications measure engagement per employee (PII) or only in aggregate?
8. Are charitable donations and community sponsorship in this function (not modeled; candidate family)?
9. Who owns social media accounts of executives: 04, 42 or the individual (08 supervises)?
10. Are trade association lobbying portions received from associations, or estimated by Tax (19)?

## 5. Overlaps with other domains (for consolidation)

- 04: Brand removal at merge; Property Type "Corporate Website / Newsroom" proposed.
- 12: Report Template "Brand" note becomes "owned by 42".
- 02: Party Role Type values Journalist, Media Outlet, Government Official, Trade Association, Award Organizer, plus Newswire Service, Media Monitoring Provider, Reputation Research Provider, Lobbying Firm, Legislative Body / Government Agency.
- 11: Award Result / Award Outcome shared-list candidate.
- 37, 39, 41, 44: no reference back to CRIS-. 39 Subject Link should use the Corporate Publication ID; 44 Space Reservation the Corporate Event ID.
- 38: Political Contribution identifier and LD-203 scope needed.
- 04: Content Type 'Press Release' to retire; Social Listening Mention is the social coverage master and needs an identifier.
- 34: Stewardship Report is the publication of that kind; the PAI Calculation link left at CW-942 (SFDR).

## 6. Recommended next steps

1. Confirm the LDA facts against the current LDA Guidance and complete the issue-area and entity lists.
2. Map Media Contact Profile, Media Inquiry and Media Coverage Item to the PR CRM and monitoring tool.
3. Agree source records per publication with 20, 43 and 44.
4. Re-check sibling references against the 37-44 modules at merge, and drop the brand overrides once BRD- transfers.

## 7. Wealth model carry-over (W1b, CW-942)

42 is kept (plan section 5.1). The pass made the four kinds of change CW-022 allows and no other; the brief names no addition for 42. Object and attribute names are unchanged except for the removed attributes; attribute IDs renumber in the Corporate Publications and Lobbying Disclosure families. The decision draft and the jurisdiction entries are in `_tools/consolidation/proposals_w1b_42.py`.

**Removed (EU/UK only; 33 jurisdiction entries: Other EU/UK 29, FCA 2, SFDR 1, UK market practice 1).**
- Attributes: Lobbying Disclosure Report.EU TR Cost Band (EU Transparency Register); Corporate Publication.Government Portal Submission Date (UK gender pay gap service and modern slavery registry); Publication Source Link.Source PAI Calculation (SFDR entity statement of 34).
- Local list EU TR Cost Band (whole, 14 values).
- Values: Lobbying Regime EU Transparency Register and UK Register of Consultant Lobbyists; Registrant Category EU TR Category II - Company or Group and UK Client of Consultant Lobbyist; Lobbying Report Type EU TR Annual Update; Publication Type Modern Slavery Statement, Gender Pay Gap Report, MIFIDPRU 8 Disclosure and Tax Strategy.
- Sources: EU Transparency Register IIA 2021, UK Transparency of Lobbying Act 2014, UK Modern Slavery Act 2015 s.54, UK gender pay gap regulations 2017, FCA MIFIDPRU 8, Finance Act 2016 Schedule 19, CIPR Code of Conduct.

**Re-sourced.**
- Lobbying to the Lobbying Disclosure Act (LD-1, LD-2, LD-203) and state registers: Lobbying Registration ID, Lobbying Regime, Registrant Category and Lobbying Report Type cite state lobbying statutes as the secondary reference (the EU Transparency Register before); Registration Jurisdiction holds the state or local register; the three lists keep the LDA and state values only.
- Corporate publications to the US: Publication Type re-cut to Statement of Financial Condition (SEC Rule 17a-5(c)), Corporate Responsibility Report, Annual Review, Other; Corporate Publication Type, Publication Signatory, Publication Board Approval Date and Publication Property lose their UK references; Source Capital Requirement Calculation now points at the 43 net capital calculation published in the statement's net capital note (SEC Rules 17a-5(c) and 15c3-1; MIFIDPRU 8 before); Source Human Capital Metric Value cites headcount and workforce composition (the gender pay gap before).
- Consultation Reference examples are US (SEC file number, FINRA Regulatory Notice, Federal Register docket).
- Inquiry Response Type list source reads PRSA practice only.

**Regulation FD.** The wholesale module did not cite Regulation FD, and nothing was added: Regulation FD binds issuers with registered securities and closed-end funds, and the firm (a privately held manager with open-end funds and ETFs) is neither by default. A firm with a listed parent or closed-end funds adds a selective-disclosure check to Press Release and Corporate Publication (tailoring lever).

**Perspective rewritten.** META subtitle; overview Purpose, Scope, Core model, Design principles 2, Notes and Suggested next steps; the Corporate Publications and Lobbying Disclosure family texts; examples (publication ID SFC/0003/2025/1 with no board approval date, the Statement of Financial Condition type, the RCAP-0003-NC-20251231-01 net capital key matching the 2025-12-31 period end, headcount; Other Source Record Key example names 19 balance sheet figures, not a tax strategy); brand licensee and co-branding texts name intermediary firms and plan sponsor partners instead of distributors; 02 is Client & Household; SUMMARY and docstring in `enrich_42.py`.

**Left for later stages (not changed).** Press Release.Coordinated Shareholder Communication and the relationship to 13 Shareholder Communication (13 adapted at W2); compliance review and gift and entertainment references to 08 Distribution Compliance (08 replaced at W2); fund and manager award results in 11 (adapted at W4); the Statement Delivery Methods note on 12 and 13.

**Open questions (W1b).**
1. Should the broker-dealer statement of financial condition be a 42 publication at all, or a 19 or 43 regulatory record that 42 only posts? Rule 17a-5(c) requires the statement to be furnished to customers, which is a 13 client communication, so 42 holds the publication record only.
2. Does the firm publish a voluntary political engagement disclosure (CPA-Zicklin style)? If so it is a Publication Type value.

**Unverified (confirm).** The website-availability option for the 17a-5(c) statement; the New York lobbying page as the state example; the eCFR section URL for 17 CFR 240.17a-5.
