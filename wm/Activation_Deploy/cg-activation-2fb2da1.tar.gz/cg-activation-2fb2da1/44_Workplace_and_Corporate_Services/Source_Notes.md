# Source Notes: 44 Workplace & Corporate Services

**Workbook:** `Workplace_and_Corporate_Services_Data_Taxonomy.xlsx` (built from `_tools/content/content_44_workplace_and_corporate_services.py`)
**Status:** Draft v0.1, wealth model (direct), scope US, 2026-10-14: the reviewed draft of 2026-10-06 carried over with the US-only pass and the perspective rewrite of CW-944 (section 6). 7 families, 28 objects (27 business objects, 1 attribute group), 238 attributes, 73 proposed CDEs (30.7%), 43 code lists (33 local, 10 enterprise shared lists), 56 relationships, 19 sources, 59 references, 1 derived copy, 98 attributes flagged PII.

**Why this domain exists.** The firm is a US wealth manager occupying offices, operations centers and branch and advice centers in the US. Its workplace and corporate services team (real estate, facilities management, physical security, health and safety, travel and expense administration, and the environmental side of running offices) produces the record of where the firm works, on what terms it occupies its buildings, what it spends traveling and entertaining, and the footprint of its own operations. 09 holds an Office Location as a four-attribute organizational reference, 19 pays invoices and posts journals, and 20 holds the employee; none holds a lease, a desk, a badge, an expense report or a kilowatt-hour. Leases, workplace injuries and operational emissions each carry their own external obligations (ASC 842 / IFRS 16 lease terms that 19 accounts for, OSHA and RIDDOR recording, GHG Protocol Scope 1-3 and California SB 253), and the records are kept in an integrated workplace management system (IWMS) and a travel and expense platform, not in the ERP. Plan section 3 marks the domain optional and low priority (SME question 1).

## 1. Key sources reviewed

| Source | URL | What was taken |
|---|---|---|
| FASB ASC 842 Leases | https://asc.fasb.org/842 | Commencement date, lease term including options reasonably certain to be exercised, operating vs finance classification, sublessor classification (sales-type, direct financing, operating, by reference to the underlying asset; verified by the reviewer), discount rate (rate implicit or incremental borrowing rate; risk-free election for private companies), variable payments, remeasurement events, subleases, short-term election. |
| ISO 41001:2018 Facility management systems | https://www.iso.org/standard/68021.html | FM scope and service delivery concepts; used for work order and maintenance structure only. |
| ISO 55000 Asset management | https://www.iso.org/standard/83053.html (edition not confirmed) | Asset and in-service concepts for Facility Asset. |
| OSCRE industry data concepts | https://www.oscre.org (not confirmed) | Space hierarchy and lease abstraction fields; structure only. |
| IPMS / BOMA measurement standards | https://ipmsc.org (not confirmed) | Gross vs rentable area; why Contractual Rentable Area differs from measured Space Area. |
| OSHA 29 CFR Part 1904 | https://www.ecfr.gov/current/title-29/subtitle-B/chapter-XVII/part-1904 | General recording criteria (1904.7), Form 300 outcome columns G-J (Injury Outcome), days away capped at 180, Form 301 incident fields, severe injury reporting (1904.39) for Regulatory Report Date. |
| OSHA 29 CFR 1910.38 | https://www.ecfr.gov/current/title-29/subtitle-B/chapter-XVII/part-1910/subpart-E/section-1910.38 | Employees designated to assist in evacuation (Emergency Role). |
| GHG Protocol Corporate Standard and Scope 2 Guidance | https://ghgprotocol.org/corporate-standard | Scope definitions; location-based and market-based Scope 2 reported as separate rows. |
| GHG Protocol Scope 3 Standard | https://ghgprotocol.org/corporate-value-chain-scope-3-standard | Operational categories 1, 3, 5, 6, 7; category 15 stays in 34. |
| California SB 253 and CARB | https://ww2.arb.ca.gov/our-work/programs/california-corporate-greenhouse-gas-ghg-reporting-and-climate-related-financial | Verified by web search (law firm summaries of CARB's June 2026 bulletin): first Scope 1-2 reports due November 10, 2026 (moved from August 10); Scope 3 from 2027; over USD 1bn revenue and doing business in California. |
| PCI DSS v4.0.1 | https://www.pcisecuritystandards.org | Masked card number only; no expiry date or full PAN held. |
| ISO 18245:2023 Merchant category codes | https://www.iso.org/standard/79450.html | Verified: ISO 18245:2023, edition 2, TC 68/SC 9. Cited as an External code list. |
| IRS Treas. Reg. 1.62-2 | https://www.ecfr.gov/current/title-26/chapter-I/subchapter-A/part-1/section-1.62-2 | Substantiation of amount, time, place and business purpose; per diem allowances. |
| USGBC LEED; US EPA ENERGY STAR | https://www.usgbc.org/leed | Certification levels (BREEAM removed at CW-944). |
| ADA Title I and the Pregnant Workers Fairness Act | https://www.ada.gov | Workplace accommodation assessments; confidentiality of employee medical information (Assessed Employee, Risk Assessment Type, Notes). Added at CW-944. |
| OSHA 29 CFR 1910.39, 1910.151, 1910.157 | https://www.ecfr.gov/current/title-29/subtitle-B/chapter-XVII/part-1910 | Fire prevention plans, first aid, extinguisher maintenance (Risk Assessment Type, Statutory Requirement example). Added at CW-944. |
| US EPA GHG Emission Factors Hub and eGRID | https://www.epa.gov/climateleadership/ghg-emission-factors-hub | Emission factors (Emission Factor Source). Added at CW-944. |
| FINRA Rule 3110 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110 | Branch office definition (FINRA Branch Office Indicator, Derived copy 08). |
| UN/ECE Recommendation 20 | https://unece.org/trade/uncefact/cl-recommendations | Unit codes FTK, MTK, KWH used for area, energy and activity units (09 Unit of Measure format). |

## 2. Design decisions and boundary calls

1. **09 keeps the key, 44 keeps the building (CD-279 rule 1; program lead ruling).** Office Location is not moved. Every 44 object that needs a site references the 09 SITE- key directly; Site Profile is an effective-dated profile keyed by SITE- and repeats none of the 09 country, time zone or legal entity. This is a recorded ruling, not an open question; `proposals_44.py` proposes only that 09 widen the Office Location definition to 'office or site'.
2. **Lease accounting drafted here, produced by 19 (CD-279 rule 2; program lead ruling).** Lease Accounting Measurement is an attribute group of the Lease, one row per lease x 19 ledger x measurement date (so measurements in different ledgers, US GAAP or tax, measurements of a lease are separate rows). Its object-group definition and the first attribute carry the row-ownership note naming the 19 Controller as producer. If the client runs lease accounting in the ERP it moves to 19 unchanged. Journals and balances stay 19; the posting relationship is drawn to 19 Journal Entry and a Journal Source value 'Lease Accounting' is proposed.
3. **IT assets in 41, facility assets here (CD-279 rule 3).** Facility Asset Class includes 'UPS / Building Power' and 'Security Hardware' with notes that anything in the 41 CMDB is never a Facility Asset.
4. **One incident record per layer (CD-280 rule 4).** Physical Security Incident and Health & Safety Incident hold no 37 reference; 37 Operational Incident and 42 Communications Issue reference them (relationships only).
5. **Casual visitors are an exception to the party rule (CD-280; program lead ruling).** Stated on the Visitors object group, on Visitor Name and in the relationships: casual visitors are recorded by name as PII text and are not created as 02 parties, like job candidates in 20; a known visitor is referenced by PTY-. The same exception covers an injured non-employee on a Health & Safety Incident (Affected Non-Employee Name).
6. **Travel and expense (CD-280 rule 6; program lead rulings).** 44 holds the trip (Travel Booking, TRIP-) and the expense report and lines. 19 holds payables, payments and journals; 20 holds employees and payroll; 08 holds gifts and entertainment compliance. Employees are never 02 parties (CD-151), so an employee claimant is reimbursed through a 20 Payroll Result; a 19 Supplier Payment is referenced only where the payee is a 02 party (Reimbursement Route row rule). Reimbursement Status is a Derived copy: AP rows copy 19 Supplier Payment.Outgoing Payment Status, Payroll rows are set from 20 Payroll Run.Pay Date; the enrichment names 19 as owner. An entertainment line references its 08 GNE- records (one per recipient) and holds no compliance fact; on such lines External Attendees and Business Purpose are left empty because 08 holds them.
7. **Operational footprint feeds 34 (CD-281; program lead rulings).** Operational Emission Record masters the firm's own Scope 1, Scope 2 and operational Scope 3 categories 1, 3, 5, 6 and 7. Its grain is reporting entity x record level (Entity Total, or Site with the 09 site) x reporting year x GHG scope category x calculation method, so entity totals and site rows never collide and distance-based and spend-based travel rows are distinct. It references the 34 Sustainability Indicator Definition it feeds (Reported Indicator, codes such as OWN_GHG_SCOPE2_MB). 34 Portfolio Sustainability Metric rows for those indicators are proposed as Derived copies (44) of Entity Total rows only. The key format is published in proposals_44 KEY_FORMATS and 42 is asked to use it. No financed emissions here.
8. **Same fact once.** Area is held on Site Profile (site gross area) and Building Space (space area) only; the total of space areas is derived. Leased Space holds the contractual rentable area, which is a lease term and is defined as distinct from measured area. Rent is held only on Lease Payment Schedule Line. Corporate Card is keyed by the issuer's card account ID or platform token (program lead decision); the masked card number is a display attribute held once. The card-to-expense match is held once, on Expense Line. The lease-to-contract link is held once, on the Lease (program lead decision; 39 Linked Lease proposed for removal and CD-257 amendment proposed).
10. **Incidents and keys agreed with 37.** Physical Security Incident uses 37's key format 'PSI 2026-0007'. 37 is asked to add the Health & Safety Incident link on its side; the relationship is marked proposed until it does.
11. **PII rule.** Every attribute of a person-keyed record (expense report and line, corporate card and transaction, travel booking, badge, zone grant, visit, space reservation, health and safety incident, emergency role) is flagged PII; health and safety incident attributes are also flagged special-category health data. On other records only person-revealing attributes are flagged.
9. **Mixed-dimension lists kept apart.** Lease Role vs Lease Classification vs Lease Recognition Exemption; H&S Incident Type vs Injury Outcome; Site Type vs Tenure Type (subletting removed from Tenure Type; it is Lease Role = Sublessor); Space Level vs Space Type; Badge Type vs Badge Status; GHG Scope Category vs Calculation Method vs Emission Record Level.

**Deviations from the brief**

| Brief | Draft | Why |
|---|---|---|
| 27 objects | 28: Space Assignment split out of Building Space | Org unit assignments are effective-dated without versioning the space. |
| Lease status in the Lease outline; no list named | Shared list Agreement Status (local copy) | Same lifecycle as a 39 Contract; avoids a 31st local list. Added to SHARED_MEMBERSHIPS. |
| Shared lists Business Line and Information Classification | Not used | The recharge target is the fund PRD- (business line derivable from 01); no classified-record attribute needed. |
| Risk Rating not listed | Used for Workplace Risk Assessment overall rating | Enterprise list fits; added to SHARED_MEMBERSHIPS. |
| Card Transaction holds the matched Expense Line | Match held on Expense Line only | Same link once (review checklist). |
| Operational Emission Record grain | Calculation Method and Emission Record Level added (program lead decision); Scope 2 location / market split also kept in GHG Scope Category, as in 34 | Unique grain; GHG scope list stays shareable with 34. |
| Scope 3 categories 1, 5, 6, 7 | Category 3 (fuel- and energy-related activities) added | It arises from the same purchased energy data (transmission losses, upstream fuel); SME to confirm. |
| 24 to 30 local lists | 33 | Lease Recognition Exemption, Emission Record Level and Calculation Method were added on review findings. |
| Corporate Card keyed by masked number | Keyed by issuer card account ID or token | Program lead decision (review High). |
| FINRA branch indicator copied from 08 | Mastered here with a note that 08 or 38 may claim it | Neither 08 nor 38 masters branch registrations (program lead decision). |
| Lease outline: rent-free period, currency, contract, status | Kept; security deposit, governing law and lease administrator not modeled | Attribute target; governing law belongs to the 39 Contract. |
| Space Reservation: attendee count | Not modeled | Attribute target. |
| Expense Line: rechargeable indicator plus fund | Recharge Fund reference only (blank = not rechargeable) | One attribute holds the fact. |
| Facility Work Order: SLA target and completion; cost; PO | SLA completion due and completed timestamps, work order space, vendor invoice APV-, purchase order PURCH- (40); no separate cost | Cost is on the 19 invoice. |

### Review response (independent review, 00_Program/Expansion/Reviews/44_review.md)

All 2 High and 20 Medium findings were applied, the program lead's four decisions included. The Lows were applied except where listed below.

| Finding | Severity | Response |
|---|---|---|
| A: Lease has no Governing Law or Contract Effective Date that 39 can copy | Medium | Applied as a proposal, not as new attributes: 39 keeps Governing Law and Contract Effective Date mastered on lease rows (row-rule exception in proposals_44 for CD-257). Adding them to 44 would duplicate 39's contract facts. |
| A: Recharge Fund has no 27 link | Low | Relationship to 27 Fund Expense Accrual added as a row rule; no attribute on 44 (an optional 27 attribute is proposed). |
| B: Escalation Basis repeated on every period line | Low | Kept, as the reviewer's first option, with the definition limited to the charge on the line. |
| D: Reporting Year basis | Low | Applied in the definition (entity's fiscal reporting year); no period start and end attributes, to stay within the attribute target. |
| E: Applicable Job Level should cite 20's list | Low | Partly applied: kept as 'Firm-defined (20 Job Level)' rather than copying 20's list; registration of 44 as a user, or a shared Job Level list, is proposed in SHARED_CANDIDATES. |
| F: Facility Asset Status uses Record Status | Low | Not applied: kept the shared list with a stated value mapping (Active, Paused, Retired) to avoid a 34th local list. |
| F: Utility Resource mixes consumption, waste and refrigerant | Low | Applied as a scope note on the list; the object was not renamed, to keep the brief's name. |
| G: IPMS source URL still marked confirm | Low | Partly applied: the ASC 842 URL is filled in; the IPMS URL could not be verified and stays marked confirm. |
| E: Reimbursement Status per-row owner | Medium | Applied as instructed: the note gives the 19 and 20 sources by row; the enrichment, which takes one owner, names 19. |

## 3. What could not be verified

- The ISO 55000 current edition URL, the OSCRE and IPMS pages, marked "confirm" in the Sources tab (the UK SECR and CSRD items lapsed with their removal, CW-944).
- WELL and ENERGY STAR certification level names in the Building Certification list (marked confirm).
- US EPA USEEIO as the spend-based Scope 3 factor source (marked confirm).
- Sibling names were checked against the 37-42 modules at review: 38 Policy (POLCY-), 39 Contract (CTRCT-), 40 Purchase Order (PURCH-), 42 Corporate Event ('CE/2026/0031'), 37 'PSI 2026-0007'. 43 Corporate Insurance Policy appears in a relationship only.
- Whether the firm's own operations fall in California SB 253 scope by entity (SME question 7).

## 4. Open questions for client SMEs

1. Is workplace data in an IWMS (lease and space system), and does the client want this domain at all (plan section 3: optional)?
2. Does lease accounting run in the lease system or in the ERP (decides whether Lease Accounting Measurement stays here or moves to 19)?
3. Is there a fixed-asset register for facility assets, and where (19 has no fixed-asset object)?
4. Are employee expenses reimbursed through payroll (20) or accounts payable (19), by country?
5. Which visitors must be registered as parties (clients, regulators), and what is the visitor log retention period?
6. Is occupancy measured from badge data per person (PII under state privacy laws) or only in aggregate?
7. Which entities are in scope for California SB 253 (revenue above USD 1 billion and doing business in California)?
8. Are company vehicles in scope (Scope 1 mobile combustion, Facility Asset Class 'Vehicle')?
9. Who owns duty-of-care traveler tracking: Security (44) or HR (20)?
10. Are FINRA branch office designations held in 08 or 38 (Site Profile masters the indicator until one of them does)?

Ruled, not open: 09 Office Location is referenced by 44, not moved (program lead).

## 5. Recommended next steps

1. Validate families, lists and CDEs with Real Estate, Facilities, Corporate Security, Health & Safety, Travel & Expense, the Controller and sustainability reporting.
2. Map attributes to the IWMS, the badge and visitor systems, the H&S system, the T&E platform and the energy data platform.
3. Agree with 19 the Journal Source values and the lease accounting location; with 19 and 20 the reimbursement route (employees through payroll); with 34 the own-operations indicator codes and the entity-total Derived copy rule; with 37 the Health & Safety Incident link; with 39 the Linked Lease removal and the CD-257 amendment; with 42 the emission record key.
4. Agree a retention schedule for visitor names, badge data and H&S records with the DPO.
5. At consolidation, register LEASE-, FMWO-, BADGE-, HSEI-, EXPR-, TRIP- and the shared memberships in `proposals_44.py`.

## 6. Wealth model carry-over (W1b, CW-944)

44 is kept (plan section 5.1). The pass made the four kinds of change CW-022 allows and no other; the brief names no addition for 44. Object and attribute names are unchanged except for the removed attribute; attribute IDs renumber in the Health & Safety family. The decision draft and the jurisdiction entries are in `_tools/consolidation/proposals_w1b_44.py`.

**Removed (EU/UK only; 23 jurisdiction entries: Other EU/UK 16, of which the 4 IFRS 16 entries share the regime of the CW-919 IFRS removal, and UK market practice 7).**
- Attribute: Health & Safety Incident.RIDDOR Reportable Indicator.
- Values: Emission Factor Source UK Government GHG Conversion Factors and AIB European Residual Mix; H&S Incident Type Dangerous Occurrence (RIDDOR Schedule 2); Risk Assessment Type DSE Workstation Assessment and New or Expectant Mother Assessment; Building Certification BREEAM Pass, Good, Very Good, Excellent and Outstanding; Escalation Basis Upward-Only Review; Lease Classification Single Lessee Model and Sublease - Finance, Lease Recognition Exemption Low-Value Asset (IFRS 16, not the firm's basis).
- Sources: RIDDOR 2013 and HSE guidance, UK DSE Regulations 1992, Regulatory Reform (Fire Safety) Order 2005, CSRD as amended by Omnibus I, UK SECR, IFRS 16, the HMRC Employment Income Manual (from the IRS row), BRE BREEAM (from the LEED row).

**Re-sourced.**
- Health and safety to OSHA recordkeeping (29 CFR Part 1904): H&S Incident Type, Occurred Timestamp, Affected Non-Employee Name (Internal; OSHA logs cover employees only), Regulatory Report Date (OSHA 1904.39 severe injury reports), Days Away From Work (OSHA Form 300); the H&S Incident Type list; GDPR special-category wording becomes sensitive health data under state privacy laws and ADA medical confidentiality.
- Risk assessments and emergency roles to OSHA 29 CFR 1910.38, 1910.39, 1910.151 and the ADA: Risk Assessment Type re-cut (Ergonomic Workstation Assessment and Workplace Accommodation Assessment replace the two UK values; Legionella to ASHRAE 188), Assessed Workstation, Assessed Employee (ADA Title I, Pregnant Workers Fairness Act), Next Review Date, Emergency Role and its list; the Statutory Requirement example is OSHA 1910.157 extinguisher maintenance (UK LOLER before).
- Leases to ASC 842 only (IFRS 16 references removed from the Lease, Lease Payment, Lease Option, Lease Measurement and Facility Asset attributes and five list sources; Measurement Ledger text; Index-Linked no longer cites RPI).
- Emission factors to the EPA GHG Emission Factors Hub and eGRID (Emission Factor Source example and secondary reference); Utility Resource, Consumption Quantity and Assurance Level lose UK SECR and CSRD; Meter Identifier example is a US meter number (UK MPAN before).
- Escalation Basis Open Market Review re-cut to Fair Market Value Reset (US lease term); Lone Working Assessment sourced to the OSHA General Duty Clause; expense attributes (Expense Type, Business Purpose, Per Diem Rate) to IRS Treas. Reg. 1.62-2 only; Building Certification to LEED, WELL and ENERGY STAR.

**Perspective rewritten.** META subtitle; overview Purpose, Scope, Core model, Design principles 8, Notes and Suggested next steps 6 and 7; the Health & Safety family text; site examples SITE-US-PHL (SITE-UK-LON before); the Attendance Count note (no EU works council); 02 is Client & Household; SUMMARY, docstring and the Workplace Risk Assessment grain text in `enrich_44.py`.

**Left for later stages (not changed).** Expense Line.Recharge Fund ("private fund deal costs", 30 LPA expense rules; W4); the gift and entertainment link to 08 Distribution Compliance (W2); the 34 own-operations indicator copies (34's pass, CW-934).

**Open questions (W1b).**
1. Does the firm keep any non-US site (for example an offshore operations center)? If so the RIDDOR or local equivalents are a tailoring lever restorable from wholesale-v1.0.
2. Does the firm report climate data under California SB 253 and SB 261, or voluntarily only?

**Unverified (confirm).** The ada.gov landing page as the ADA source; OSHA 1910.39 and 1910.157 citations for fire prevention and extinguisher maintenance; ASHRAE Standard 188 for Legionella water management.
