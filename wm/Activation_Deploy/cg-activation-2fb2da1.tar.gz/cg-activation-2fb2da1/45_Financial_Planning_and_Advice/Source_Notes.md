# Source Notes: 45 Financial Planning & Advice (Draft v0.1, review fix pass, 2026-10-14)

Workbook: `Financial_Planning_and_Advice_Data_Taxonomy.xlsx`. Content module: `_tools/content/content_45_financial_planning_and_advice.py` (new). Enrichment: `_tools/enrichment/enrich_45.py`. Proposals: `_tools/consolidation/proposals_w2_45.py`.
Size (after the review fix pass, 45_review.md): 7 families, 28 objects (23 business objects, 5 attribute groups), 269 attributes, 91 CDEs (33.8%), 43 code lists (39 local, 4 local copies of shared lists), 64 relationships, 23 sources. Ownership: 50 references, 9 derived copies, 2 overrides, 6 row rules, 0 unresolved.

**Perspective.** Wealth manager (direct) | Scope: US. A hypothetical US wealth manager of the Vanguard type serving investors directly through self-directed brokerage, digital and human advice, its own funds and ETFs, workplace recordkeeping, institutional advisory, a thin intermediary channel and optional trust services (business lines DB, DA, HA, PF, WR, IA, IC, TR; CW-004). Advice is given by the RIA (advisory capacity) and, for brokerage recommendations, by the broker-dealer (Reg BI capacity); planning tools are in house or licensed; account aggregation runs through a licensed aggregator under client consent.

## 0. Why this domain exists

Advice Operations, the planning team and the digital advice platform produce a record that no wholesale domain held: what a client is trying to achieve, the plan built to get there, the assumptions and outside assets it rests on, what the firm recommended, and why that recommendation was in the client's best interest. For a wealth manager this is regulated evidence as much as service data. Regulation Best Interest requires the care obligation to be met, and SEC Rule 17a-3(a)(35) requires a record of what was collected from and given to the retail customer, for each recommendation; the Advisers Act fiduciary duty applies to every advisory relationship; a rollover from a workplace plan needs the DOL PTE 2020-02 documentation. The investor profile is a client fact (02), the enrollment that follows a recommendation is an account fact (15), and the management of the account to a model is 46. 45 holds the advice between them, once, so that 08 can supervise it and 15 and 46 can reference it.

| Business line | What it adds here |
|---|---|
| DB | Recommendation Source 'Representative', Engagement Type 'Brokerage Recommendations', security and account-type recommendations with Reg BI evidence, usually without a Financial Plan. |
| DA | Recommendation Source 'Algorithm' with the 37 engine and its version; Goal-Only plan type; Monte Carlo scenarios; Advice Review Type 'Digital Check-In' and 'Rule 3a-4 Annual Contact'. |
| HA | Comprehensive engagements, plan versions, cash-flow and balance-sheet inputs, scenarios, periodic reviews, retirement-income goals. |
| PF | No objects; own funds appear as the recommended share class (01 SHC-) and as Conflict Type 'Proprietary Product'. |
| WR | Rollover Analyses for participants of recordkept plans (16 PMEM-, PFEE-), Engagement Type 'Workplace Participant Advice'. |
| IA, IC | No difference (OCIO advice is 12 and 24; external advisors' advice is not recorded by the firm). |
| TR | Goal Type 'Trust Funding'; Planning Balance Sheet Item.Asset Trust (51 TRUST-); a recommendation to establish a trust account is an Account Type recommendation with registration type Trust, implemented by the 15 account that names the 51 Trust. |

## 1. Sources consulted

| Source | URL | What it gave us |
|---|---|---|
| Regulation Best Interest, Exchange Act Rule 15l-1; release 34-86031 | https://www.ecfr.gov/current/title-17/section-240.15l-1 | Disclosure, care, conflict and compliance obligations; "recommendation", "retail customer", investment profile factors, series of recommendations. Recommendation, Rationale, Best Interest Evidence, Investment Profile Factor. |
| Form CRS, Rule 17a-14 and Advisers Act Rule 204-5; release 34-86032; SEC Rule 17a-3(a)(24) | https://www.ecfr.gov/current/title-17/section-240.17a-14 | Delivery points triggered by account-type and rollover recommendations; record of the date each Form CRS was provided to each retail investor, including before an account is opened. Evidence Disclosure Delivery, Client-Level Form CRS Delivered Date. |
| SEC Rule 17a-3(a)(35) and Rule 17a-4 | https://www.ecfr.gov/current/title-17/section-240.17a-3 | Reg BI record of information collected and provided, and the associated person (verified by the reviewer on the LII copy); retention. |
| Commission Interpretation, Standard of Conduct for Investment Advisers, IA-5248 (2019) | https://www.sec.gov/rules/interp/2019/ia-5248.pdf | Duty of care (best interest, best execution, monitoring) and loyalty. Advice Capacity, Best Interest Component. |
| Advisers Act Rule 204-2 | https://www.ecfr.gov/current/title-17/section-275.204-2 | Written communications relating to advice; Plan Document Reference, Evidence Document Reference. |
| Form ADV Part 2A and Appendix 1 | https://www.sec.gov/about/forms/formadv-part2.pdf | Planning and advisory services and agreements. Advice Engagement. |
| Investment Company Act Rule 3a-4 | https://www.ecfr.gov/current/title-17/section-270.3a-4 | Annual contact on changes in financial situation, objectives and restrictions. Advice Review. |
| DOL PTE 2020-02 (85 FR 82798, Dec 18, 2020) | https://www.federalregister.gov/documents/2020/12/18/2020-27825/prohibited-transaction-exemption-2020-02-improving-investment-advice-for-workers-and-retirees | Fiduciary acknowledgment, services and conflicts disclosure, Impartial Conduct Standards, documented rollover reasons, retrospective review. Rollover Analysis, PTE 2020-02 Documentation. |
| DOL Retirement Security Rule (89 FR 32122) and its removal (91 FR 13503, Mar 20, 2026) | https://www.federalregister.gov/documents/2026/03/20/2026-05492 | Status: see section 4. Fiduciary Status Basis. |
| ERISA 3(21), IRC 4975 and 402(c) | https://www.dol.gov/agencies/ebsa | Fiduciary advice; eligible rollover distributions. |
| DOL 29 CFR 2550.404a-5 and 2550.408b-2 | https://www.ecfr.gov/current/title-29/section-2550.404a-5 | Plan fee data for rollover comparisons. Plan Fee Data Source. |
| FINRA Regulatory Notice 13-45; Rules 2111, 2090, 3110 | https://www.finra.org/rules-guidance/notices/13-45 | Rollover comparison factors (fees, options, services, withdrawals, creditor protection, RMDs, employer stock); suitability; supervision. Rollover Option Comparison. |
| SEC IM Guidance Update 2017-02, Robo-Advisers | https://www.sec.gov/investment/im-guidance-2017-02.pdf | Algorithm disclosure, questionnaire design and oversight. Recommendation Source, Projection Method. |
| CFP Board Code of Ethics and Standards of Conduct (2019; Section C replaced the Practice Standards) | https://www.cfp.net/ethics/code-of-ethics-and-standards-of-conduct | Seven-step process, scope of engagement, plan presentation and monitoring. Engagement, Goal, Plan Version. |
| FDX API | https://financialdataexchange.org | Account types, consent, connection status. Aggregated Account. |
| CFPB 12 CFR Part 1033 | https://www.ecfr.gov/current/title-12/part-1033 | Consumer-permissioned access (status: section 4). |
| SSA period life table | https://www.ssa.gov/oact/STATS/table4c6.html | Life expectancy basis; claiming ages. |
| Federal Reserve SR 11-7 | https://www.federalreserve.gov/supervisionreg/srletters/sr1107.htm | Model governance of planning and advice engines (inventoried in 37). |
| IRC Section 529; Uniform Trust Code; DOL Form 5500; ISO 4217 / 8601 | https://www.irs.gov/newsroom/529-plans-questions-and-answers | Education accounts; trust assets; external plan identity; currencies and dates. |
| Salesforce Financial Services Cloud | https://developer.salesforce.com/docs/platform/data-models/guide/fsc-customer.html | Financial Goal, Financial Plan, assets and liabilities (cross-check only). |

## 2. Design and boundary decisions

- **Outline followed:** the brief's 7 families with one added attribute group (28 objects: 23 BO, 5 AG); family codes AV-ENG, AV-GOL, AV-PLN, AV-INP, AV-PRJ, AV-REC, AV-ROL.
- **Client Financial Plan (program-lead ruling).** The objects are "Client Financial Plan" and "Client Financial Plan Version" (list "Client Financial Plan Version Status"); 19 keeps "Financial Plan Version" (FPL-) for enterprise budgets. The rename removes the name clash, so no ownership override is needed for the plan-version references.
- **Three records, three owners (CW-024).** No objective, risk tolerance, time horizon or income/net-worth band on any 45 object. Advice Review, Client Financial Plan Version and Recommendation reference the 02 INPR- version. The one 02 value used, the federal marginal tax rate, is a declared Derived copy on Client Planning Assumptions.
- **Recommendation mastered once (CW-042).** Name kept exactly. Rationale (AG), Alternatives and Best Interest Evidence hold the care, cost, conflict and disclosure evidence; the profile version relied on is held once, on the Recommendation. Component Satisfied Indicator is the attester's judgment at the time; 08 holds any supervisory exception and never edits it (CW-015). Recommendation Capacity has two values only (one capacity per recommendation; a dual registrant states each one).
- **Rollover facts held once (ruling 7).** For a Rollover recommendation, the alternatives and costs are Rollover Option Comparison rows, the rationale is Rollover Analysis.Best Interest Reasons and the attestation is PTE 2020-02 Documentation; the Recommendation references the analysis it relied on (Supporting Rollover Analysis). Best Interest Evidence no longer has a PTE component. Several analyses may exist per recommendation, one current.
- **Implementation index (ruling 3, CW-032).** The link from an implementing record to the recommendation is mastered on the implementing side (15 Source Recommendation and Originating Recommendation, 46 Model Assignment.Source Recommendation, 48 Client Order source). Recommendation Implementation Link is a Derived index: the 15, 46 and 48 keys are Derived copies with a row rule; only the 16 distribution of a rollover is mastered here, because 16 holds no recommendation link.
- **Assumptions held once (ruling 8).** Planning Assumption Set is a firm house set (keyed by Assumption Set Code) with inflation, healthcare inflation and simulation count and a reference to the 24 Capital Market Assumption Set for return assumptions; each plan version references it (Version Assumption Set), a stress scenario may name another. Client-specific tax and longevity assumptions are the attribute group Client Planning Assumptions of the plan version. Planning State Tax Rate is a 45 planning assumption, not the client's tax status.
- **Rule 3a-4 annual contact (CW-044, ruling 4):** Advice Review references the 15 Program Enrollments it satisfies, the join path for 15's Derived copy of the annual contact date.
- **Form CRS before an account exists (ruling 5):** Best Interest Evidence holds a client-level Form CRS delivered date and version (SEC Rule 17a-3(a)(24)) when no 15 account-keyed delivery exists (row rule).
- **No returns, no Client Holdings (CW-011, CW-007).** Goal Progress Snapshot holds Firm Assets Assigned to Goal as a Derived copy of 49 and Contributions to Date as a Derived copy of 50 (16 for participant accounts, row rule), each with the snapshot date; External Assets come from 45 Aggregated Account Balances. The personal rate of return is a reference to 32.
- **Projections are results, not performance (CW-046)**; the engine is a 37 Model Inventory Entry; the today's-dollars convention is stated once per scenario.
- **Algorithmic advice (CW-057):** Recommendation Source 'Algorithm', Recommendation Engine (37) and Engine Version as a Derived copy of the 37 Model Version at the presented timestamp. Recommending Advisor is the person who made it, or for an algorithm the employee accountable for the program.
- **Aggregation:** balance, six allocation buckets that sum to 100% and the account's tax treatment; holding-level data in the feed is not retained (lever: Aggregated Holding, never a 49 Client Holding). The aggregation provider is the 02 Consent Record's Data Recipient and is not repeated.
- **Special category (CW-060, CD-344):** Life Expectancy Basis, Modeled Life Expectancy Age and Healthcare Cost Basis are marked special category outright, restricted view, coded bases with no medical detail. Healthcare Expense cash-flow rows are read as aggregates only. Hardship is not a goal type; vulnerability stays 02.
- **Advisor of record (03 CW-063):** 45 holds the employee who acted on each record, never an "advisor of record" attribute.
- **References to 13:** Contact Center Interaction (review), Recipient Delivery Record (PTE 2020-02 documentation sent to one investor). No 45 attribute points at an 08 retrospective review; 08 holds findings on its Best Interest Review Detail.
- **PII tier** stated in the Notes of the first attribute of every object; external account numbers masked; examples fictitious and internally consistent.
- **Ownership overrides:** two references to 'Fee Schedule' forced to 47 until the merge moves that concept row from 01 to 47.

**Deviations from the brief**

| Brief | Draft | Why |
|---|---|---|
| Retirement Income Goal Detail: longevity basis (CD-344); Planning Assumption Set: life expectancy, healthcare cost bases, tax rate, CMA set, inflation, simulation count per plan version | Firm house Planning Assumption Set referenced per version; client tax and longevity bases on the new AG Client Planning Assumptions; goal detail holds Income Needed Through Age | Held once (ruling 8); one added attribute group (28 objects). |
| Best Interest Evidence: profile version (02) | Held once on Recommendation (Recommendation Profile Version) | One recommendation relies on one version; repeating it per component row duplicates it. |
| Goal Progress Snapshot: probability of success | Snapshot Probability of Success, defined as a recalculation on the as-of date; the plan-version figure stays on Goal Projection Result | Two different facts (dated recalculation versus accepted-scenario result). |
| Goal Funding Link: funding source type | Two typed references (15 Account, Aggregated Account); no Funding Source Type list | The list restated which reference is filled. |
| Shared list Meeting Format for reviews | Review Channel uses Advice Delivery Channel | One channel dimension; Meeting Format carries board values. |
| Objects Financial Plan / Financial Plan Version; local lists "Plan Type", "Plan Version Status", "Scenario Type" | Client Financial Plan / Client Financial Plan Version; Client Financial Plan Type, Client Financial Plan Version Status, Planning Scenario Type | Program-lead ruling; 19 owns the object Financial Plan Version and shared lists named Financial Plan Type, Plan Version Status and Plan Scenario with budget meanings (CW-058). |
| Advice Engagement: "advisor of record (20 EMP-)" | Engagement Advisor (20 EMP-) | 03 brief CW-063 makes the 03 coverage assignment the only advisor-of-record master. |
| Business Line as a direct user of the shared list | Local copy with the CW-004 codes | 45 is not in the shared list's direct_users, so 'Shared: Business Line' fails validation; register at merge (SHARED_MEMBERSHIPS). Same for Frequency, Record Status, Delivery Method. |
| Local lists 28 to 36 | 39 | Added Education Cost Basis, Healthcare Cost Basis, Investment Profile Factor, Plan Fee Data Source, On-Track Status, Rollover Analysis Status, Recommendation Capacity, Account Tax Treatment. |
| Attributes 200 to 260 | 269 | The review fix pass added the rulings' attributes (enrollment join, client-level Form CRS, rollover analysis link, assumption set keys, tax treatment, allocation buckets). |
| Recommendation Implementation Link mastered | Derived index of the 15, 46 and 48 back-links | Ruling 3 (CW-032). |
| Rollover Analysis: plan fee source "16 PFEE- or collected 404(a)(5) disclosure" | Plan Fee Data Source (code), Source Plan Fee Schedule (16), Collected Fee Disclosure Date | Adds Form 5500 and industry benchmark sources (Notice 13-45 practice when plan data cannot be obtained). |
| Recommendation: "accounts (15)" | Recommendation Accounts plus Recommended Registration Type (15 list) | An account-type recommendation names a registration type before any account exists. |

**Wholesale objects:** none (new domain).

## 3. Jurisdiction: EU/UK concepts left out (no REMOVALS entry)

New domain: nothing removed, `JURISDICTION = []`. The design leaves out, and a UK extension would add as a family (plan section 13): MiFID II suitability and appropriateness assessments and the suitability report; FCA COBS 9 and 9A; Consumer Duty outcomes and vulnerability guidance; Retail Distribution Review adviser-charging records; the ESMA suitability guidelines; PRIIPs cost illustrations; EU/UK pension transfer advice. Kept: foreign-currency goals (a home abroad), foreign institutions and currencies on aggregated accounts, nonresident clients as 02 parties.

## 4. Unverified items (confirm)

1. **DOL fiduciary rule status.** Secondary sources (law-firm and recordkeeper alerts) report a March 20, 2026 removal of the 2024 Retirement Security Rule after court vacatur, effective April 20, 2026, restoring the 1975 five-part test and the original PTE 2020-02 text, and stating that DOL no longer relies on the PTE 2020-02 preamble's interpretation of rollover advice. FR document 2026-05492 and 91 FR 13503 are not confirmed. Fiduciary Status Basis now has two values (Acknowledged Fiduciary - PTE 2020-02; Non-Fiduciary - Five-Part Test Not Met): "Level-Fee Fiduciary" was removed because the 2016 exemption was vacated in 2018 and a fiduciary paid a new advisory fee on rolled-over assets relies on PTE 2020-02 (DOL PTE 2020-02 FAQs; confirm).
2. The best-execution element of the Impartial Conduct Standards against the 2020 PTE text. (Rule 17a-3(a)(35) and the IA-5248 path were verified by the reviewer; marks closed.)
3. URLs: PTE 2020-02 Federal Register path, CFP Board standards page, SEC IM Guidance 2017-02 PDF, Form ADV Part 2 PDF, Salesforce FSC path, Uniform Trust Code page.
4. CFPB 12 CFR Part 1033: reported enjoined and under reconsideration (advance notice August 2025; proposed rule planned); compliance dates uncertain.
5. FDX account type values and the license terms for reproducing the list (FDX Account Type is a starter subset).
6. PFEE- key format for the 16 Plan Fee Schedule (no PREFIX_FORMATS row). 48 Client Order examples use CLORD- and 51 Trust examples TRUST-, per those domains.

## 5. SME questions (tailoring levers; reference default in brackets)

1. Goals per client or per household? [Either; the owner is a 02 party or `PTY-HH-`. Lever: household-only.]
2. Is every brokerage recommendation recorded? [Every recommendation the firm defines as such under Reg BI, including security recommendations by representatives. Lever: a firm making no security recommendations drops the Security type.]
3. Does a digital advice client have a Financial Plan? [Yes, plan type Goal-Only with versions. Lever: goals without plans.]
4. Is the Rule 3a-4 annual contact an Advice Review or a 02 profile refresh? [Advice Review that confirms or creates a 02 profile version.]
5. Aggregated holdings at holding level? [Balance and asset-class mix only. Lever: add an Aggregated Holding object (never a 49 Client Holding).]
6. Health-based longevity and healthcare-cost bases recorded? [Coded bases flagged special category (CD-344), no medical detail. Lever: drop them.]
7. PTE 2020-02 retrospective review in 45 or 08? [08; 45 holds per-rollover documentation and the review year.]
8. Which planning engines feed projections? [One in-house engine inventoried in 37. Lever: a vendor tool, recorded in 37 only.]
9. After the 2026 restoration of the five-part test, does the firm treat every rollover recommendation as fiduciary advice? [Yes, Acknowledged Fiduciary - PTE 2020-02. Lever: document Non-Fiduciary - Five-Part Test Not Met case by case; Reg BI still applies.]
10. Should Engagement Advisor reference the 03 coverage assignment instead of the employee? [Employee who delivers the engagement. Lever: reference 03 once it lands.]
11. Should the client-level Form CRS delivery later move to a party-keyed 15 or 13 record? [45 holds it on Best Interest Evidence until one exists.]

## 6. Overlaps with other domains (for consolidation)

| Item | Domains | Proposal |
|---|---|---|
| Plan objects | 45 Client Financial Plan / Version, 19 Financial Plan Version (FPL-) | Resolved by the 45 rename (ruling); 19 unchanged. |
| Recommendation | 45, 23 Research Recommendation | Resolved: bare name is 45 in the wealth model; 23 is 'Research Recommendation'. |
| Implementation link | 45 index, 15, 46, 48 | Mastered on the implementing side; 45 is the Derived index (CW-032). |
| Advice capacity | 45 Advice Capacity, 01 Advisory Capacity, 08 | Shared-list candidate. |
| Delivery channel | 45, 03, 13 | Advice Delivery Channel as shared list at W5 (CW-044). |
| Rule 3a-4 annual contact date | 45 Advice Review, 15 Program Enrollment | 15 date becomes a Derived copy (CW-044). |
| Outside assets | 02 Outside Investable Assets Band, 45 Aggregated Account Balance | Stated band versus observed balance; neither replaces the other (CW-024). |
| Rollover | 16 Distribution Request, 45 Rollover Analysis | Transaction versus advice (CW-045). |
| Advisor of record | 03, 45 | 03 masters it; 45 records who acted. |

## 7. Suggested validation steps

1. Walk a digital advice enrollment, a hybrid comprehensive plan with two versions, a phone representative's account-type recommendation and a 401(k) rollover to IRA through the objects, from engagement to the implementation index.
2. Test the Reg BI care, disclosure and conflict evidence and the PTE 2020-02 conditions against Retail Compliance's checklists and the 08 Best Interest Review Detail.
3. Agree with 15 the RECOM- re-key and the Derived copy of the annual contact date; with 46 and 47 the MASGN- and CLFEE- references.
4. Confirm the special-category handling of longevity and healthcare-cost bases with the Data Protection Officer.
5. Map attributes to the planning tool, the digital advice engine, the aggregation feed and the evidence archive.
6. Confirm the items in section 4.
