# Source Notes: 46 Managed Portfolios & Rebalancing (Draft v0.1, 2026-10-14)

Workbook: `Managed_Portfolios_and_Rebalancing_Data_Taxonomy.xlsx`. Content module: `_tools/content/content_46_managed_portfolios_and_rebalancing.py` (new). Enrichment: `_tools/enrichment/enrich_46.py`. Proposals: `_tools/consolidation/proposals_w2_46.py`.
Size (after the review fix pass of 2026-10-14): 8 families, 24 objects (23 business objects, 1 attribute group), 236 attributes, 84 CDEs (36%, slightly above the brief's 35% because the review asked for the window scope, location keys and period ends to be flagged), 37 code lists (30 local, 7 copies of shared lists), 43 relationships, 23 sources. Ownership: 61 references, 10 derived copies, 2 overrides, 3 row ownership rules, 0 unresolved.

**Perspective.** Wealth manager (direct) | Scope: US. A hypothetical US wealth manager of the Vanguard type (business lines DB, DA, HA, PF, WR, IA, IC, TR; CW-004). Its RIA sponsors discretionary programs under Investment Company Act Rule 3a-4 and executes through the affiliated self-clearing broker-dealer; the firm's investment team builds the models (01 `MDL-`, weights in 24 `TGT-`); fractional shares are available.

## 0. Why this domain exists

Managed Account Operations runs the firm's discretionary programs (digital advice, hybrid and human-advised managed accounts, workplace participant managed accounts and, optionally, trust accounts) across hundreds of thousands of client accounts. Its data is not fund portfolio management: each account is a 15 account held in the 49 brokerage book of record and managed to an 01 model whose weights 24 maintains, but with its own restrictions, tax situation, cash flows and household. The domain holds which model each account follows, how the account deviates from it, its drift, rebalance and tax-loss-harvesting decisions, wash-sale control across a household, and the trade proposals handed to 48. Rule 3a-4 makes individualized management of each account a condition of the program's safe harbor, which is why this record is kept at account grain and apart from 24.

| Business line | What it adds here |
|---|---|
| DB | Nothing (self-directed accounts have no model). Their IRAs can still be in wash-sale scope through a Household Managed Group. |
| DA | Model Assignment at scale, threshold and cash-flow triggers, daily harvest scans, fractional proposals, automatic batch release. |
| HA | Custom targets and override lines approved by an advisor, household asset location, legacy securities, multi-sleeve assignments. |
| PF | Own funds are model building blocks (24, 01); no fund-side object here. |
| WR | Model Assignment on participant accounts; proposals released as 16 Participant Investment Transfers (`PEXC-`), which 16 nets into the plan-level 29 Fund Order; no wash-sale control (tax-deferred). |
| IA, IC | No difference (18 portfolios in 24; models delivered to third-party advisors are 05). |
| TR | Account Investment Constraint sourced from a 51 Trust Term Provision. |

## 1. Sources consulted

| Source | URL | What it gave us |
|---|---|---|
| ICA Rule 3a-4; adopting release IC-22579 / IA-1623 (March 24, 1997; 62 FR 15098, https://www.sec.gov/rules/final/ic-22579.txt) | https://www.ecfr.gov/current/title-17/section-270.3a-4 | Individualized management, reasonable restrictions, annual contact (15), quarterly notice (13), indicia of ownership (49). Model Assignment, Account Investment Constraint, override lines. |
| Form ADV Part 1A Item 5.F and instructions; Part 2A Appendix 1 | https://www.sec.gov/about/forms/formadv-part2.pdf | Discretionary and non-discretionary regulatory AUM; continuous and regular supervisory or management services. Regulatory AUM Classification, Discretion Exercised. |
| Advisers Act section 206(3); Rule 206(3)-2 | https://www.ecfr.gov/current/title-17/section-275.206(3)-2 | Principal trade disclosure and consent (the adviser's or a controlled affiliate's account); agency cross transaction conditions; temporary Rule 206(3)-3T expired on December 31, 2016 and was not extended. Pre-Trade Check Type. |
| Advisers Act Rules 206(4)-7 and 204-2 | https://www.ecfr.gov/current/title-17/section-275.206(4)-7 | Compliance policies over rebalancing and trading; records of orders and their basis. Approvals, timestamps. |
| IRC section 1091; Treas. Reg. 1.1091-1 | https://www.law.cornell.edu/uscode/text/26/1091 | 30 days before and after the loss sale, substantially identical securities, disallowed loss and basis adjustment. Wash Sale Control Window, Security Group. |
| Rev. Rul. 2008-5 (2008-3 I.R.B. 271) | https://www.irs.gov/irb/2008-03_IRB | A purchase in the seller's own IRA or Roth IRA in the window makes the taxable sale a wash sale and the IRA basis is not increased. With Publication 550 (spouse purchases) it sets the legal scope of Controlled and Monitored Accounts in Scope. |
| IRS Publication 550 | https://www.irs.gov/publications/p550 | Capital gains, holding periods, wash sales, substantially identical property, specific identification. |
| IRC section 1222 | https://www.law.cornell.edu/uscode/text/26/1222 | Short-term and long-term terms. Holding Period Term. |
| IRC section 6045; Treas. Reg. 1.1012-1(c) | https://www.ecfr.gov/current/title-26/section-1.1012-1 | Adequate identification of lots at the time of sale; broker basis reporting (49). Proposed Client Lot Selection. |
| IRC section 401(a)(9) | https://www.law.cornell.edu/uscode/text/26/401 | RMD cash raises (the RMD record is 15). |
| SEC IM Guidance Update 2017-02 | https://www.sec.gov/investment/im-guidance-2017-02.pdf | Disclosure of algorithms, rebalancing and tax-loss-harvesting features. Tax Saving Method, trigger types. |
| SEC Examinations Risk Alert, electronic investment advice (2021-11-09) | https://www.sec.gov/files/exams-eia-risk-alert.pdf | Robo-adviser portfolio management and Rule 3a-4 reliance observations; tax-loss-harvesting disclosures. |
| SEC Examinations Risk Alert, wrap fee programs (2021-07-21) | https://www.sec.gov/exams/announcement/risk-alert-wrap-fee-programs | Monitoring of low trading activity (reverse churning) and suitability of wrap accounts. Rebalance Decision, 08 surveillance link. |
| GIPS 2020 for Firms | https://www.gipsstandards.org | Composite construction, discretion, minimum size, significant cash flow policy. Managed Account Composite and membership. |
| SR 11-7 | https://www.federalreserve.gov/supervisionreg/srletters/sr1107.htm | Model risk context for the rebalancing and asset location engines (37). |
| Uniform Prudent Investor Act | https://www.uniformlaws.org | Trust investment duties read through 51 terms. |
| FIX Protocol | https://www.fixtrading.org | Side, OrderQty and CashOrderQty of the proposal. |
| GICS | https://www.msci.com/our-solutions/indexes/gics | Sector exclusions. |
| NACHA Operating Rules | https://www.nacha.org/rules | ACH behind 50 money movements. |
| Envestnet, Orion, Vestmark, Aladdin Wealth documentation | https://www.vestmark.com | Cross-check of sleeve, tolerance, harvest threshold and household structures only. |
| Salesforce FSC household model | https://developer.salesforce.com/docs/platform/data-models/guide/fsc-customer.html | Household grouping cross-check. |
| Reg BI (Rule 15l-1); Advisers Act fiduciary interpretation (IA-5248) | https://www.ecfr.gov/current/title-17/section-240.15l-1 | Context of the 45 recommendation an assignment follows (not re-mastered). |
| FINRA Rule 2111; SEC Rule 17a-3 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2111 | Tax status in the 02 profile; books and records behind the 49 Client Holding view. |

## 2. Design and boundary decisions

- **Outline followed:** the brief's 8 families and 24 objects (23 BO, 1 AG) with the brief's names and grains.
- **Model, assignment, target (CW-009, CW-047).** Model Assignment hangs from the 15 Program Enrollment; the program (01 `OFFR-`) and the discretionary grant are read from the enrollment, not repeated. Managed Account Target references the 24 Target Allocation Set version applied; only overrides are mastered. Drift Assessment Line.Line Target Weight is a Derived copy (24) with a row rule (override rows are 46).
- **Account-level tax management (CW-048).** Every lot reference is typed `Reference (Client Tax Lot, 49)` with `CTLOT-` examples (49 brief); no 18 `LOT-` or `PORT-` reference exists. Realized gains, unrealized losses, market values, actual weights and available cash are Derived copies of 49 with an as-of date or timestamp beside them.
- **Proposal, not order (CW-049).** Trade Proposal ends at Released and holds the released 48 Client Order (`CLORD-`) or, for a participant managed account, the 16 Participant Investment Transfer (`PEXC-`) key and the release timestamp only. 16 nets transfers into the plan-level 29 Fund Order; 46 never releases to 29 directly.
- **Wash sale (IRC 1091, Rev. Rul. 2008-5).** The legal scope is the seller and spouse (IRS Publication 550) and the seller's own IRAs (Rev. Rul. 2008-5); other household members' accounts are not in scope. The window splits the scope into Controlled Accounts in Scope (managed: purchases blocked) and Monitored Accounts in Scope (self-directed accounts and IRAs: purchases flagged, never blocked). The security group is a typed reference to the firm's Substantially Identical Security Group; same-day loss sales of one group merge into one window.
- **Sleeves share the account target.** The assigned model of a multi-sleeve account is an 01 multi-sleeve model whose 24 target set carries the sleeve weights; Sleeve Assignment names each sleeve's model and sub-adviser engagement (52 `SADV-`). This is the leaner cut: one target, one drift and one proposal set per account, with no copied sleeve weight. Lever: sleeve-grain targets, drift and proposals.
- **Asset classes.** Drift, override and location lines use the 17 Instrument Asset Class list that 24 targets and 49 holdings use, so Line Target Weight is a sum of 24 lines by class through the 17 instrument lookup (row rule in enrich_46). Drift lines may also be instrument lines (legacy securities, Security Level drift).
- **Tolerance precedence.** Override line tolerance, then the account's asset class tolerance, then the 24 Target Allocation Line bands, then the program trigger rule threshold.
- **Links held once.** 50 Money Movement and 47 Fee Debit reference the 46 cash instruction (`CSHI-`); 46 holds no attribute pointing back. The cash instruction references only its 15 sources (standing instruction, RMD record).
- **Restrictions (Rule 3a-4).** Account Investment Constraint references the 02 Client Restriction or the 51 Trust Term Provision and holds its coded effect and implementation rule only; restriction text is never copied. A row rule states which limit values are mastered here.
- **PII.** Every object states its tier in the Notes of its first attribute: 19 objects 'PII - financial', 5 'No PII' (Rebalance Trigger Rule, Model Change Implementation, Substantially Identical Security Group, Trade Proposal Batch, Managed Account Composite). No special-category data is held. Employee references are marked 'PII (internal staff)'.
- **CW-057.** Algorithmic and human-advised programs share the objects; the engine is a 37 Model Inventory Entry on the batch and on the asset location decision.
- **Bare book-of-record words.** 'Holding' and 'Position' appear only as '49 Client Holding' or 'holding period'; legacy positions are 'Legacy Security'.

**Deviations from the brief**

| Brief | Draft | Why |
|---|---|---|
| Model Assignment: program, enrollment, discretion type | Enrollment only (program read from 15 Enrolled Service Offering); 'Discretion Exercised' (Account Discretion Type) with a note that the grant is 15 Discretionary Authority Indicator | The program and the grant would be held twice. |
| Local list 'Discretion Type' | 'Account Discretion Type' (Full, Limited - Rebalance Only, Non-Discretionary) | 01 has 'Discretion Type' with offering-level values. |
| Local lists 'Constraint Type', 'Override Reason' | 'Account Constraint Type', 'Account Target Override Reason' | Same names exist with other values in 24 (Constraint Type), 06 and 33 (Override Reason). |
| Tax Management Setting: 'tax rate basis (Derived copy, 02)' | Tax Rate Source Profile (reference to 02 `INPR-`) plus Applied Federal Marginal Tax Rate (Derived copy, 02) | The copy names its source version. |
| Tax Management Setting | Adds Managed Sale Lot Selection Method (shared Lot Relief Method) | Brief section 8 lists the shared list; the account default stays 15 Cost Basis Election. |
| Household Managed Group | Adds Account Tax Treatment (rule-set from the 15 registration type) and Client Consent Date | Asset location needs the tax character; consent evidences joint management under Rule 3a-4. |
| Managed Account Target: 'drift tolerance' | Asset Class Drift Tolerance (the trigger rule carries the program's total drift threshold) | One tolerance per level. |
| Account Investment Constraint: 'implementation rule' | Implementation Rule plus Substitute Instrument, Constrained Instruments, Constrained Sector (GICS), limit value and basis | Coded effect of each constraint type. |
| Drift Assessment: 'holdings as-of (49)' | Holdings As-Of Timestamp plus Pending Activity Indicator | Pending orders or money movements defer rebalancing. |
| Account Rebalance Event: 'trigger' | Event Trigger Type plus typed references to the trigger rule, drift assessment, model change or cash instruction | One trigger source per event type. |
| Tax-Loss Harvest Decision: 'unrealized and harvested loss' | Unrealized Loss at Scan (Derived copy, 49); the harvested (realized) loss is a 49 lot relief fact | Realized amounts are 49's. Harvest Loss Term added. |
| Trade Proposal: 'released client order (48)' | Released Client Order (48) or Released Participant Investment Transfer (16), with Execution Route | WR participant exchanges are 16 transfers netted by 16 into plan-level 29 orders (review High; ruling 1). |
| Trade Proposal Exception: 'principal or cross trade flag' | Pre-Trade Check Type values 'Principal Trade' and 'Agency Cross Trade' | A flag would repeat the check type. |
| Managed Account Cash Instruction: sources 50, 15, 47 | 15 sources only (standing instruction, RMD record), plus Available Cash Used (Derived copy of 49 Account Cash Balance) | 50 and 47 hold the link from their side (ruling 7). |
| Sleeve Assignment: target sleeve weight; Sleeve manager (52) | No sleeve weight (read from 24); Sleeve Sub-Adviser Engagement (52 `SADV-`) | Ruling 5 (sleeves share the account target); 52 brief names the engagement. |
| Drift Assessment Line: account x asset class | Asset class or instrument line | Instrument override lines and Security Level drift need a line. |
| Wash Sale Control Window: accounts in scope, wash sale incurred | Controlled and Monitored Accounts in Scope; incurred is a Window Status value only | Ruling 4; one fact held once. |
| Account Investment Constraint: sector | Constrained Classification Scheme (09) and Value, as in 24 | Aligned with 24; 'Values-Based Screen' dropped (no screen object to name). |
| Composite Exclusion Reason 'align with 32' | First four values carry 32's labels; two 46 values added; Significant Cash Flow Exclusion Indicator dropped (it repeated a value) | Candidate shared list (steward 32). |
| Shared Asset Class (01) | Shared Instrument Asset Class (17), subset copied | Ruling 3; 01 Asset Class is the lever. |
| Local Holding Period Term | Cites the 18 list (External) | Ruling 6; member of 18's list, not a copy. |
| Key format of Wash Sale Control Window (GRAIN_KEY_FORMATS 'SIG-SP500') | 'SPX500' firm-defined group code | SIG- is not reserved. Lead changes the example at merge. |
| Business Line (shared list, brief section 8) | Not used | The program's business line is read from the 01 offering. |
| Code lists 24 to 30 local | 30 local | Added Account Tax Treatment, Implementation Status, Proposal Execution Route. Record Status is used with a documented subset on Model Assignment, Household Managed Group and Account Investment Constraint. |

## 3. Jurisdiction (new domain, CW-022)

`JURISDICTION = []`. Sources are US only (Rule 3a-4, the Advisers Act, Form ADV, the Internal Revenue Code). Left out and not to be added: UK discretionary management suitability for portfolio management (FCA COBS 9A), the 10 percent depreciation notice (COBS 16A, which the wholesale 12 Depreciation Notification once reflected), MiFID II best-execution and inducement records, UK capital gains share identification ('bed and breakfasting') rules and ISA wrappers. Foreign securities and ADRs in models, the foreign tax credit in asset location (Asset Location Basis 'Foreign Tax Credit Eligibility') and nonresident clients' accounts stay.

## 4. References to sibling and future domains

| Object referenced | Domain | Type used | Status |
|---|---|---|---|
| Recommendation (`RECOM-`) | 45 | Reference (Recommendation, 45) | W2 sibling brief |
| Participant Investment Transfer (`PEXC-`) | 16 | Reference (Participant Investment Transfer, 16) | 16 brief (W3 adaptation) |
| Client Order (`CLORD-`) | 48 | Reference (Client Order, 48) | 48 brief |
| Client Tax Lot (`CTLOT-`); Client Holding (`CLHLD-`), Client Lot Relief, Account Cash Balance, Client Account Activity (`CLACT-`) | 49 | Reference (Client Tax Lot, 49); Derived copies (49) | 49 brief |
| Money Movement (`MMVMT-`) | 50 | REL only (50 references `CSHI-`) | 50 brief |
| Fee Debit (`FDBT-`) | 47 | REL only (47 Fee Debit.Cash Raise Instruction references `CSHI-`) | 47 module |
| Trust Term Provision (key on `TRUST-`) | 51 | Reference (Trust Term Provision, 51) | 51 brief |
| Sub-Adviser Engagement (`SADV-`) | 52 | Reference (Sub-Adviser Engagement, 52) | 52 brief |
| Sales Practice Alert (`SPA-`) | 08 | REL only | 08 brief |

## 5. Unverified items (confirm)

Closed in the fix pass (confirmed by the reviewer): the IC-22579 adopting release and URL; Rev. Rul. 2008-5 at 2008-3 I.R.B. 271; the expiry of temporary Rule 206(3)-3T on December 31, 2016; the two 2021 risk alert URLs.

1. Form ADV Part 1A instructions URL and the exact Item 5.F / instruction 5.b wording used in Regulatory AUM Classification.
2. SEC IM Guidance Update 2017-02 URL.
3. Vendor documentation paths (Envestnet, Orion, Vestmark, Aladdin Wealth); the structures were used only as a cross-check.
4. Key formats of the 16, 48, 49 and 52 objects follow the published PREFIX_FORMATS (`PEXC-2026-0041877`, `CLORD-20261005-004188221`, `CTLOT-00418822173`, `SADV-00412`); confirm the object names when those modules land.

## 6. SME questions (tailoring levers; reference default in brackets)

1. Is a model assigned per account or per household? [Per account, with a Household Managed Group for asset location and wash-sale scope. Lever: household-level assignment.]
2. Does the firm run multi-sleeve accounts? [Yes, Sleeve Assignment, with sleeves sharing the account target of a multi-sleeve model. Levers: sleeve-grain targets and drift; drop the object.]
3. Which accounts share a wash-sale window? [The seller's and spouse's accounts in the household managed group, including their IRAs: managed accounts blocked, self-directed accounts flagged. Lever: account only, or block self-directed purchases by agreement.]
4. Which funds are substantially identical? [Firm policy groups; two funds tracking the same index are treated as identical. Lever: per tax counsel.]
5. Principal and cross trades in managed accounts? [Not permitted; flagged as exceptions. Lever: allowed with section 206(3) consent recorded in 48.]
6. Is drift assessed daily for every account? [Daily for digital, on event for human-advised. Lever: calendar only.]
7. Is a harvest's tax saving estimated at the client's marginal rate? [Yes, from 02 Federal Marginal Tax Rate (Derived copy). Lever: a flat assumed rate (Tax Saving Method).]
8. Are managed account composites presented under GIPS? [Operational only, linked to 01 `CMP-` where presented.]
9. Which asset class list drives drift? [17 Instrument Asset Class, the list of 24 targets and 49 holdings. Lever: 01 Asset Class with a mapping.]
10. How are participant managed account (WR) proposals executed? [Released as 16 Participant Investment Transfers, netted by 16 into plan-level 29 Fund Orders. Lever: 16 rebalances to a 46-maintained Investment Election instead.]
11. Should the tax management setting keep history? [No: attribute group with audit trail. Lever: effective-dated object.]

## 7. Overlaps with other domains (for consolidation)

| Item | Domains | Proposal |
|---|---|---|
| Tax budget, proposed trades and lot selections | 24, 46 | 24 keeps 18 portfolios only at the W3 re-cut (CW-048). |
| Discretion | 01 Discretion Type, 15 Discretionary Authority Indicator, 46 Discretion Exercised | Three levels (offering, grant, use); no copy. |
| Reasonable restrictions | 02 Client Restriction, 15 Program Enrollment.Reasonable Restrictions, 46 Account Investment Constraint | 15 says which were accepted, 46 how each is implemented. |
| Composite | 01, 32, 46 | Term conflict logged (CW-050). |
| Asset class lists | 01, 17, 24, 46, 49 | 46 uses 17 Instrument Asset Class (ruling 3). |
| Cash instruction links | 46, 47, 50 | Held once, on the 47 and 50 side. |
| Holding Period Term | 18, 46, 49 | 46 cites the 18 list. |

## 8. Suggested validation steps

1. Walk a digital advice account, a hybrid household with a taxable account and two IRAs, a multi-sleeve account with a sub-advised sleeve, a participant managed account and a trust account through assignment, drift, harvest, wash-sale and release.
2. Test the Rule 3a-4 evidence (individualized targets, accepted restrictions) and the Form ADV Item 5.F classification with Advisory Compliance.
3. Agree the Client Tax Lot and Client Holding contract with the 49 drafter and the release contract with 48 and 29.
4. Agree the 24 re-cut and the asset class rollup with the 24 owner.
5. Map attributes to the rebalancing engine, tax overlay and order management system.
6. Confirm the items in section 5.
