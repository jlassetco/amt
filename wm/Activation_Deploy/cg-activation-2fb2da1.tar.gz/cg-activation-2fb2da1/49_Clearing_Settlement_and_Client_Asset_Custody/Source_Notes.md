# Source Notes: 49 Clearing, Settlement & Client Asset Custody (Draft v0.1, 2026-10-14)

Workbook: `Clearing_Settlement_and_Client_Asset_Custody_Data_Taxonomy.xlsx`. Content module: `_tools/content/content_49_clearing_settlement_and_client_asset_custody.py` (new). Enrichment: `_tools/enrichment/enrich_49.py`. Proposals: `_tools/consolidation/proposals_w3_49.py` (the W3 brief decisions are in `proposals_w3_brokerage.py`).
Size (after the 2026-10-15 fix pass on `00_Program/Rework/Reviews/49_review.md`): 9 families, 26 objects (23 business objects, 3 attribute groups), 285 attributes, 96 CDEs (34%), 46 code lists (38 local, 8 copies of shared lists), 61 relationships, 24 sources. Ownership: 55 references, 2 derived copies, 5 overrides, 8 row ownership rules, 0 unresolved. Before the fix pass: 274 attributes, 92 CDEs, 43 lists, 58 relationships, 50 references, 3 overrides, 3 row rules.

**Perspective.** Wealth manager (direct) | Scope: US. A hypothetical US wealth manager of the Vanguard type (business lines DB, DA, HA, PF, WR, IA, IC, TR; CW-004) whose broker-dealer is self-clearing: an NSCC and DTC participant and an OCC clearing member, holding own mutual funds through an omnibus account at the in-house transfer agent (29) and foreign securities through a bank custodian, offering limited margin and fully paid lending.

## 0. Why this domain exists

Brokerage Operations (clearance, stock record, cashiering, margin, transfers, reorganization and customer protection) keeps the brokerage book of record: what every client account holds, in which Client Tax Lots and at what basis, its cash, sweep and margin balances, what is pending, where each security is held and whether it is in the firm's possession or control. No other domain keeps it: 18 is the investment book of record of the firm's funds and institutional portfolios (Portfolio Holding), 28 is Fund Custody, and 06 summarizes client assets (CW-007, CW-011). The broker-dealer's own regulation makes the record distinct: SEC Rule 15c3-3 for Client Asset Custody and the reserve, Rules 17a-3 and 17a-13 for the stock record and the quarterly count, IRC section 6045 for cost basis, FINRA Rule 11870 for account transfers.

## 1. Sources consulted

| Source | URL | What it gave us |
|---|---|---|
| SEC Rule 15c3-3 | https://www.ecfr.gov/current/title-17/section-240.15c3-3 | Possession or control (b), control locations (c), deficits (d), reserve computation and deposits (e), PAB, fully paid lending (b)(3), sweep (j)(2), buy-in of customer sells (m). Client Holding quantities, Reserve Computation, Possession or Control Determination, Control Location. |
| SEC Rule 15c3-3a (Exhibit A) | https://www.ecfr.gov/current/title-17/section-240.15c3-3a | Items 1 to 15 (Item 15: margin at a registered clearing agency for customers' US Treasury transactions) and Item 16; Note E debit reduction (1 percent basic; 3 or 2 percent alternative per 15c3-1). |
| SEC press release 2025-95 | https://www.sec.gov/newsroom/press-releases/2025-95-sec-extends-compliance-date-help-broker-dealers-fully-test-implement-daily-reserve-computation | Daily computation compliance date extended to June 30, 2026, now treated as in force subject to confirmation (amendments adopted December 20, 2024; USD 500 million average total credits threshold; 2 percent debit reduction for daily computers). |
| SEC Rule 15c3-1 | https://www.ecfr.gov/current/title-17/section-240.15c3-1 | Alternative standard on aggregate debit items (43 reads the Customer row). |
| SEC Rules 17a-3, 17a-4, 17a-5 | https://www.ecfr.gov/current/title-17/section-240.17a-3 | Blotters, ledgers, securities record, FOCUS (average total credits). |
| SEC Rule 17a-13 | https://www.ecfr.gov/current/title-17/section-240.17a-13 | Quarterly count, verification and comparison; recording of differences. Security Count. |
| SEC Rule 15c6-1 | https://www.ecfr.gov/current/title-17/section-240.15c6-1 | T+1 settlement. |
| Regulation T (12 CFR 220) | https://www.ecfr.gov/current/title-12/part-220 | Cash and margin accounts, SMA, payment period, extensions, 220.8(c) freeze. Margin Balance Snapshot, Client Margin Call, Client Settlement Fail. |
| FINRA Rule 4210 and Regulatory Notice 26-10 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/4210 ; https://www.finra.org/rules-guidance/notices/26-10 | Maintenance requirements; intraday margin standard replacing the day-trading requirements (effective June 4, 2026; phase-in to October 20, 2027). |
| FINRA Rule 4330 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/4330 | Fully paid lending conditions. |
| FINRA Rule 11870 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/11870 | ACATS validation and completion, residual credits, non-transferable assets. |
| FINRA Rule 1220 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/1220 | Financial and operations principal (reserve approver). |
| SEC Rule 10c-1a | https://www.ecfr.gov/current/title-17/section-240.10c-1a | Securities loan reporting; compliance dates moved to September 28, 2028 (reporting) and March 29, 2029 (dissemination) by the SEC order of December 3, 2025 (secondary sources: Orrick, McDermott). |
| Regulation SHO Rule 204 | https://www.ecfr.gov/current/title-17/section-242.204 | Close-out of fails. |
| SEC Rule 14b-1 | https://www.ecfr.gov/current/title-17/section-240.14b-1 | Record-date holders for proxy pass-through (13 reads the quantity). |
| SEC Rules 10b-10 and 144 | https://www.ecfr.gov/current/title-17/section-240.10b-10 | Confirmed commission (48); restricted securities. |
| IRC 6045, 6045A, 6045B; Treas. Reg. 1.6045-1, 1.6045A-1 | https://www.law.cornell.edu/uscode/text/26/6045 | Covered securities and dates, basis reporting, transfer statements within 15 days, issuer organizational actions. |
| IRC 1012, 1014, 1015, 1091, 1222, 1223; Publication 550 | https://www.irs.gov/publications/p550 | Basis, inheritance and gift, wash sales, holding period, lot identification. |
| IRS Forms 1099-B, 8949, 8937, 1099-DIV, 1042-S | https://www.irs.gov/forms-pubs/about-form-1099-b | Reporting categories, issuer basis reports, dividend and foreign tax reporting. |
| SIPC | https://www.sipc.org | Customer definition; USD 500,000 protection including USD 250,000 cash. |
| DTCC (NSCC CNS, ACATS, DTC) | https://www.dtcc.com | Clearing channels, ACATS cycle and control numbers, cost basis reporting service (paths to confirm). |
| OCC | https://www.theocc.com | Exercise and assignment settlement. |
| ISO 20022 seev; ISO 15022 MT564 to MT568 | https://www.iso20022.org | Entitlement and election fields. |

## 2. Design and boundary decisions

- **Outline followed:** the brief's 9 families and objects, with the brief's names except one rename (below). The brief says 27 objects but its table lists 26; the draft has those 26 (23 BO, 3 AG).
- **Three books of record (CW-007, CW-101).** Every quantity-holding object is "Client ..."; no 18 Portfolio Holding, Tax Lot or Lot Relief, 28 Safekeeping Account, Corporate Action Entitlement or Securities Loan, or 26 Settlement Instruction is copied. Client Holding mirrors the brief's quantity set (trade-date, settled, short, segregated, margin-pledged, on-loan, restricted, fractional) and carries the Own Share Class Indicator (Derived from 17) from which 06 builds the Fund Shareholder Position view. Every lot reference is typed "Reference (Client Tax Lot, 49)".
- **Covered Security Indicator** sits on Client Tax Lot only (CW-915), with the IRC section 6045(g) class; it is not repeated on Client Holding.
- **Fund-only (TA-registered) accounts (CW-034, CW-122, CW-141).** Their shares are 29 Share Register Balances, not Client Holdings, but their lots and basis are 49 Client Tax Lots. A lot is opened by a 49 Client Account Activity or a 29 Register Transaction (Acquisition Register Transaction) and relieved likewise (Closing Register Transaction); row rules say exactly one is filled.
- **Own-fund omnibus (CW-097, CW-122).** The settlement of a brokerage omnibus fund order is the 29 Settlement Obligation; the 49 Street Settlement Obligation row of channel Own-Fund Omnibus references it and carries no amounts. The Stock Record to Own-Fund Omnibus run references the Control Location and the 29 Share Register Balances; the break's External Quantity is read, not mastered.
- **Link to 48 (CW-098).** Client Account Activity.Source Client Allocation references the 48 Client Allocation, because a block or multi-fill order posts once per account from its allocation; the link is held on the 49 side only and 48 drops its back-reference.
- **One posting ledger.** Client Account Activity books 48 allocations, 50 money movements, 47 fee debits, 29 fund orders, entitlements and account transfers; status is lifecycle only (Pending, Posted, Reversed); Activity Type is the separate list.
- **Cash (CW-102).** Account Cash Balance masters the Sweep Balance; the row rule in enrich_49 says the 50 Sweep Allocations sum to it and a difference is a Stock Record Reconciliation break of type Program-Bank Sweep. Cash Balance Type includes Cash Available to Invest and to Withdraw (computed as-of rows), which 46 and, for cash accounts, 48 copy. Balance Basis (trade date, settlement date) is part of the key. The per-row sweep reconciliation status was dropped: the Program-Bank Sweep run, keyed by sweep program, holds the result.
- **Reserve (CW-103, CW-943).** One object, Reserve Computation (RESRV-; Customer or PAB), with Exhibit A lines, Average Total Credits (threshold test), requirement, deposit and the 43 reserve bank accounts. Aggregate Debit Items Amount keeps that exact name for 43's Derived copy (row rule: Customer row only). Average Total Credits combines Customer and PAB and repeats on both rows. The debit reduction is 1 percent (basic method), 3 percent (alternative method) or 2 percent (alternative method, daily computer), not applied to PAB. Exhibit A Formula Item lists items 1 to 15. 49 holds no net capital figure.
- **Client Asset Custody, not Fund Custody.** Control Location is a role profile of a 02 party whose type follows the Rule 15c3-3(c) grounds (c)(1) to (c)(7), plus the in-house transfer agent (basis to confirm) and firm possession (vault, possession rather than control); Possession or Control Determination is one row per instrument, date and Deficit Source, with the 15c3-3(d), (h) and (c)(3) time frames in the source list; the bank custodian of client foreign securities is a control location, not a 28 Safekeeping Account.
- **Margin (CW-105).** Only the intraday margin standard of amended FINRA Rule 4210 is modeled (no pattern day trader regime, per the 15 review); Buying Power is the figure 48 copies, with the snapshot's Margin Snapshot Type and As-Of Timestamp (end of day or intraday). The reference firm adopted the new standard on June 4, 2026, so no legacy day-trading call is modeled. Liquidations are 48 Client Orders.
- **Account transfers (CW-104).** Account Transfer and Asset Line; the 6045A statement is its own object, keyed by transfer, direction and version. Transfer Reject Reason lists only the exceptions FINRA Rule 11870(d) permits. Transfer Direction is In or Out; an internal re-registration is channel Internal Re-Registration. The client request is a 13 Service Request.
- **Corporate actions (CW-106, CW-090).** Record Date Client Holding Quantity is copied by 13 as Issuer Proxy Pass-Through.Record Date Entitled Quantity (13 keeps its name); payments post as activity; basis effects are Cost Basis Adjustments citing the issuer's Form 8937.
- **PII.** Account-level objects are "PII - financial"; firm-level objects (Street Settlement Obligation, Reserve Computation and Lines, Possession or Control Determination, Control Location, Loan Reporting Detail, Security Count, Stock Record Reconciliation) are "No PII"; Stock Record Break is financial only when assigned to an account. Contra Firm Account Number is masked and restricted. No special-category data is held.
- **Jurisdiction.** New domain; `JURISDICTION = []`. Left out and not to be added: CASS 6 and 7 client money and custody (removed from 28 under CW-928), CSDR settlement discipline, SFTR reporting of client loans, the EU shareholder rights directive pass-through, UK stamp duty reserve tax as a client charge. Kept: foreign securities at a bank custodian or designated foreign depository, foreign-currency cash balances, foreign tax withheld on client income.

**Deviations from the brief**

| Brief | Draft | Why |
|---|---|---|
| Possession or Control Position | Possession or Control Determination | Term ruling Position (W0): "Position" is used only in 06 Fund Shareholder Position. Rename the GRAIN_KEY_FORMATS row at merge. |
| 27 objects | 26 objects | The brief's table lists 26. |
| Local lists 26 to 32 | 35 local | Lifecycle statuses kept apart from types and reasons (Client Tax Lot Status, Street Settlement Status, Loan Status, Election Status) and three source lists (Noncovered Basis Source, Relief Method Source, Deficit Source). |
| Reconciliation Type | Stock Record Reconciliation Type | Avoids a same-name list with other reconciliation domains. |
| Shared Message Standard, Flow Direction, Business Line, Record Status | Not used | Cut for size or not needed (proposals NOTES). |
| Control Location "Rule 15c3-3(c) paragraph basis" | Folded into Control Location Type | The type values follow the 15c3-3(c) grounds; paragraph numbering to confirm. |
| Possession or Control "action to reduce" | Deficit Source (one row per source) and Action Deadline Date | The action and time frame follow from the source under 15c3-3(d), (h) and (c)(3). |
| Possession or Control grain instrument x date | instrument x date x Deficit Source | A deficit can sit in more than one source (review). |
| Client Account Activity to 48 Client Execution | Source Client Allocation (48) | Program-lead ruling (CW-098). |
| Local lists 35 | 38 | Fix pass added Cash Balance Basis, Margin Snapshot Type and Break Status. |
| Fully Paid Securities Loan borrower (02) | Borrowing Entity (09 internal legal entity) | Reference default: the firm borrows as principal (SME question 7). |

## 3. Unverified items (confirm)

1. Daily reserve computation: in force from June 30, 2026 (no later extension found); the threshold average (Customer plus PAB total credits, twelve month-end FOCUS reports) and the 2 percent reduction were verified by the reviewer. Still to confirm: deposit timing for daily computers.
2. Exhibit A: aligned to items 1 to 15 in the fix pass (reviewer verified against Cornell LII); confirm the wording of items 14 and 15 against the eCFR text.
3. The basis on which the in-house transfer agent counts as a good control location (SEC staff interpretation or a (c)(7) designation). The (c) grounds and (d) time frames were aligned to the reviewer's verified reading.
4. FINRA Regulatory Notice 26-11 (the 4210 interpretations) and the Intraday Margin Deficit call mechanics; Notice 26-10 dates verified.
5. Rule 10c-1a: compliance dates of September 28, 2028 and March 29, 2029 (SEC order of December 2025, read through secondary sources) and the Fifth Circuit remand; which party reports a fully paid loan in which the broker-dealer borrows as principal.
6. NSCC ACATS reject codes for the twelve Rule 11870(d) exceptions (the 11870 time frames were verified).
7. Covered security class dates and Form 8949 box letters; DTCC service guide paths; OCC rule paths.

## 4. SME questions (tailoring levers; reference default in brackets)

1. Self-clearing or fully disclosed? [Self-clearing; 49 complete. Lever: the clearing firm carries the accounts; 49 shrinks to received copies of holdings, lots and activity plus transfers and elections.]
2. Daily or weekly reserve computation? [Daily. Lever: weekly; the 49 debit reduction stays at 3 percent. 43's net capital requirement is 2 percent of aggregate debit items under the alternative standard either way.]
3. PAB computation? [Yes, usually zero. Lever: drop the PAB value.]
4. Own funds by omnibus at the in-house TA or networked? [Omnibus, reconciled daily (Stock Record to Own-Fund Omnibus). Lever: networked; the 29 register holds sub-accounts.]
5. Default lot relief method and DRIP basis? [FIFO for securities, average cost for funds, from 15. Lever: tax-optimized default.]
6. Margin offered to which accounts? [Limited, non-retirement accounts approved in 15. Lever: drop the margin objects.]
7. Fully paid lending? [Offered, firm as principal borrower. Lever: a Vanguard-type firm may not offer it, and the fully paid lending objects drop; or an agency program (Borrowing Entity becomes a 02 party).]
8. Fractional shares in transfers out? [Liquidated and transferred as cash. Lever: fractional delivery where the contra firm accepts.]
9. Recordkept participant balances in 49? [No, 16 keeps them; brokerage windows and IRAs are 49. Lever: move at a recordkeeping platform merge.]
10. Are both trade-date and settlement-date cash balances kept? [Both, distinguished by Balance Basis; settlement date is the book of record. Lever: settlement date only, and Balance Basis drops from the key.]
11. Default sweep vehicle? [The firm's own money market fund, whose shares are Client Holdings, with the bank deposit sweep program by account type or election, held as the 49 Sweep Balance with 50 Sweep Allocations (program-lead ruling, aligned with 50 lever 3). Lever: bank program as the sole default, so Sweep Balance rows exist for every account.]
12. Where are the lots of fund-only (TA-registered) accounts kept? [49 Client Tax Lots, opened and relieved by 29 Register Transactions. Lever: the TA platform keeps them (29 brief), and 49 holds brokerage-account lots only.]

## 5. Overlaps with other domains (for consolidation)

| Item | Domains | Proposal |
|---|---|---|
| Holdings, lots, cash | 49 Client Holding, Client Tax Lot, Account Cash Balance; 18 Portfolio Holding, Tax Lot, Cash Balance | Parallel books (CW-007); term conflicts Holding, Tax Lot, Cash Balance. |
| Sweep | 49 Sweep Balance; 50 Sweep Allocation; 15 Cash Sweep Election | Row rule on Cash Balance Amount (CW-102). |
| Reserve and net capital | 49 Reserve Computation; 43 Capital Requirement Calculation | 43 re-type and re-key (CW-103). |
| Corporate actions | 49 Client Corporate Action Entitlement; 28 Corporate Action Entitlement; 17 event | Term conflict Entitlement. |
| Lending | 49 Fully Paid Securities Loan; 28 Securities Loan | Term conflict Securities Loan; shared Regulatory Trade Report Regime. |
| Margin calls | 49 Client Margin Call; 26 Margin Call | Term conflict Margin Call. |
| Transfers | 49 Account Transfer; 50 money movement; 29 Fund Share Transfer | Term conflict Transfer. |
| Holding Period Term | 49, 18, 46 | Shared-list candidate. |
| Fund-only lots and the omnibus | 49 Client Tax Lot, Street Settlement Obligation, Stock Record Reconciliation; 29 Register Transaction, Settlement Obligation, Share Register Balance | References on the 49 side (CW-097, CW-122, CW-141). |
| Booking of client trades | 49 Client Account Activity; 48 Client Allocation | 49 holds the link; 48 drops its back-reference (CW-098). |

## 6. Suggested validation steps

1. Walk a buy, a sale with specific identification, a dividend reinvested, a spin-off with Form 8937, an ACATS transfer in with basis and a fee debit through the objects, checking each posting and lot effect.
2. Rebuild a weekly and a daily Customer reserve computation from Account Cash Balances and the Exhibit A lines with Finance and the FINOP.
3. Test a possession or control deficit (fail to receive) and its clearance against Rule 15c3-3(d).
4. Agree the Derived copy attribute names with 15, 43, 45, 46, 47, 51 and 13 (proposals NOTES) and the re-keys of CW-114.
5. Map attributes to the stock record, cost basis engine, margin system, ACATS interface and the reserve workbook.
6. Confirm the items in section 3.
