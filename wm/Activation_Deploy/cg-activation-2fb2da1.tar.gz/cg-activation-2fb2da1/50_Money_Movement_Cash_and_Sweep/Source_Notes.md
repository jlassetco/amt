# Source Notes: 50 Money Movement, Cash & Sweep (Draft v0.1, 2026-10-14; review fix pass 2026-10-15)

Workbook: `Money_Movement_Cash_and_Sweep_Data_Taxonomy.xlsx`. Content module: `_tools/content/content_50_money_movement_cash_and_sweep.py` (new). Enrichment: `_tools/enrichment/enrich_50.py`. Proposals: `_tools/consolidation/proposals_w3_50.py`. Review: `00_Program/Rework/Reviews/50_review.md`.
Size: 8 families, 26 objects (21 business objects, 5 attribute groups), 250 attributes, 82 CDEs (33%), 42 code lists (33 local, 9 copies of shared lists), 47 relationships, 21 sources. Ownership: 50 references, 3 derived copies, 2 overrides, 5 row ownership rules, 0 unresolved.

**Perspective.** Wealth manager (direct) | Scope: US. The reference firm is a hypothetical US wealth manager of the Vanguard type (business lines DB, DA, HA, PF, WR, IA, IC, TR; CW-004).
- Its broker-dealer is self-clearing and has no bank charter.
- It originates ACH as a non-consumer originator through an ODFI bank and sends Fedwire through a correspondent.
- Brokerage and IRA cash defaults to the firm's own money market fund. A bank deposit sweep across several program banks is offered by account type or election.
- Checkwriting runs on the money market funds. A debit card is offered through one program bank.

## 0. Why this domain exists

Money Movement Operations and Cash Programs move clients' money in and out of their accounts and hold their uninvested cash. That covers:
- ACH contributions and withdrawals, wires, and checks deposited and issued;
- journals between accounts, direct deposit and bill pay, and debit-card spending;
- the daily sweep of free credit balances.

The firm has no bank charter. Swept bank deposits therefore sit in omnibus accounts that the broker-dealer opens as agent at program banks, and FDIC insurance reaches the client only through the pass-through rules of 12 CFR Part 330. Payments are also where fraud and elder exploitation show up first. That is why FINRA Rule 2165 disbursement holds and the money-movement monitoring of the broker-dealer's AML program sit with the payment record. None of this belongs to the firm's own treasury (43), the brokerage book of record (49) or the fund complex's settlement cash (29), so 50 is a Data Domain of its own (CW-016).

| Business line | What it adds here |
|---|---|
| DB | Every object: funding and withdrawals, direct deposit and bill pay, card, checks, money market and bank sweep, holds, fraud, monitoring. |
| DA | Movements whose source is a 15 Account Standing Instruction or a 46 Managed Account Cash Instruction. |
| HA | Movements entered by the firm's advisor (Initiating Employee, 20); external advisers act under a 02 Authority Grant. Rule 2165 holds are reviewed in 08. |
| PF | Own money market funds as the default sweep vehicle (Eligible Sweep Funds, 01 `SHC-`). The Sweep Run places 29 Fund Orders, and checkwriting drafts are honored by a 29 redemption. Payments of fund-only accounts are 50 movements (CW-107). |
| WR | Rollover receipts into IRAs reference the 16 Distribution Request. Plan distributions stay on the recordkeeper's rail. |
| IA, IC | No difference. |
| TR | Movements whose source is a 51 Trust Distribution Request; trust accounts fall in the FDIC Trust Accounts category. |

## 1. Sources consulted

| Source | URL | What it gave us |
|---|---|---|
| NACHA Operating Rules (2026); Nacha fraud monitoring and company entry description pages | https://www.nacha.org/rules ; https://www.nacha.org/rules/risk-management-topics-fraud-monitoring-phase-2 ; https://www.nacha.org/rules/risk-management-topics-company-entry-descriptions | Standard entry classes, transaction codes and trace numbers. Same-day ACH. Return codes (including R14 and R15) and change codes. The reinitiation limit, the unauthorized return rate and WSUD. Micro-entries (ACCTVERIFY) and WEB debit account validation. PAYROLL and PURCHASE descriptions are mandatory from March 20, 2026. Fraud monitoring: phase 1 March 20, 2026; phase 2 June 19, 2026, with compliance by June 22, 2026. The reference firm is phase 1 (more than 6 million originations in 2023). |
| Federal Reserve Fedwire Funds Service | https://www.frbservices.org/financial-services/wires | IMAD and OMAD, ISO 20022 since July 14, 2025, and business days. |
| ISO 20022 (pacs.008, pacs.009, pacs.004, pacs.002, camt.056, camt.029) | https://www.iso20022.org | Wire Message Type, UETR, status events and recalls. |
| Regulation CC (12 CFR Part 229) | https://www.ecfr.gov/current/title-12/chapter-II/subchapter-A/part-229 | Binds banks. The firm's holds follow firm policy aligned to Reg CC timing, so check attributes cite Internal first and Reg CC second. |
| Check 21 Act | https://www.law.cornell.edu/uscode/text/12/chapter-50 | Image exchange and substitute checks. |
| Regulation E (12 CFR Part 1005) | https://www.ecfr.gov/current/title-12/chapter-X/part-1005 | Financial institution definition (1005.2(i)), liability (1005.6) and error resolution (1005.11): notice within 60 days, provisional credit at 10 business days, and 45 or 90 days to investigate. |
| SEC Rule 15c3-3(j) | https://www.law.cornell.edu/cfr/text/17/240.15c3-3 | (j)(2)(ii): (A) consent (15 election), (B) disclosures, (C) quarterly liquidation notice (13), and (D) 30-day notice of a change (Program Change Notice Date and Effective Date). (j)(1) statements are 13. |
| FDIC 12 CFR Part 330 | https://www.ecfr.gov/current/title-12/chapter-III/subchapter-B/part-330 | Ownership categories (330.6, 330.9, 330.10, 330.11, 330.14, 330.15, verified by the reviewer), the USD 250,000 maximum, pass-through recordkeeping (330.5, 330.7), and up to five trust beneficiaries. |
| FDIC 12 CFR 337.6 (brokered deposits); withdrawal of the 2024 proposal | https://www.ecfr.gov/current/title-12/chapter-III/subchapter-B/part-337/section-337.6 ; https://www.sewkis.com/insights/fdic-withdraws-pending-proposed-rule-on-brokered-deposits/ | The 2020 rule stands after the March 3, 2025 withdrawal. Primary purpose exception notices (25 percent test, enabling transactions) give Primary Purpose Exception Basis and Exception Notice Filed Date. |
| FDIC custodial deposit account recordkeeping proposal, RIN 3064-AG07 (89 FR, October 2, 2024) | https://www.govinfo.gov/content/pkg/FR-2024-10-02/html/2024-22565.htm | The proposal exempts custodial deposit accounts established by broker-dealers, so as drafted it does not reach the omnibus sweep accounts. No final action found. |
| FDIC BankFind Suite | https://banks.data.fdic.gov | FDIC certificate number and charter class: facts of the 02 bank party, held here as Derived copies. |
| 31 CFR 1010.410, 1023.220, 1023.320 | https://www.ecfr.gov/current/title-31/section-1023.320 | Funds transfer records and the travel rule (USD 3,000), CIP, and SAR filing and confidentiality. |
| FinCEN advisory on elder financial exploitation (FIN-2022-A002) | https://www.fincen.gov/resources/advisoriesbulletinsfact-sheets/advisories | Red flags behind the Elder Exploitation Pattern scenario. |
| OFAC, 31 CFR Part 501 | https://ofac.treasury.gov | Lists, blocking and rejection, and 10-business-day reports. |
| FINRA Rule 2165; Regulatory Notice 22-05; SR-FINRA-2026-018 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/2165 ; https://www.finra.org/rules-guidance/rule-filings/sr-finra-2026-018 | Today: 15 business days, extensions to 55 in total, notice within two business days. The August 2026 filing would raise the maximum to 145 business days (three 30-day increments) and add Rule 2166 temporary delays of up to 10 business days (Regulatory Notice 26-02 had 5). SEC action pending. |
| SIFMA comment letter (September 30, 2026) | https://www.sifma.org/advocacy/letters/proposed-rule-change-to-amend-finra-rules-0150-2165-4512-and-to-adopt-finra-rule-2166 | Filing status (release 34-106275). |
| FINRA Rules 3310 and 4512; Senior Safe Act | https://www.finra.org/rules-guidance/rulebooks/finra-rules/3310 | AML program and monitoring, trusted contact, and reporting immunity. |
| PCI DSS v4.0.1 | https://www.pcisecuritystandards.org | Masked PAN and storage limits. |
| ISO 18245, ISO/IEC 7812, ISO 8583 | https://www.iso.org/standard/79450.html | Merchant category codes, card numbers and authorization messages. |
| ISO 13616 IBAN, ISO 9362 BIC; ABA routing numbers | https://www.swift.com/standards/data-standards/bic-business-identifier-code | Counterparty bank and account on foreign wires. |
| IRS Forms 5498 and 1099-R | https://www.irs.gov/forms-pubs/about-form-1099-r | Contribution year and distribution codes. |

## 2. Design and boundary decisions

- **Outline.** The draft keeps the brief's 8 families and 26 objects. The brief's header count of "19 BO, 7 AG" contradicts its own table (21 BO, 5 AG), so the draft follows the table. Program Bank Daily Position is renamed **Program Bank Daily Total** and keyed per sweep program, program bank and business date. A bank in two programs has two omnibus accounts and two statements.
- **Link direction (lead ruling).** Neighbors reference the Money Movement; 50 references only its own inputs and the 02, 15 and 43 masters.
  - Dropped: Posting Activity, Return Posting Activity and Interest Posting Activity. 49 Client Account Activity.Source Money Movement holds that link.
  - Dropped: Source Service Request and Source Escheatment Report. 13 holds those links, as it does for Remediation.
  - Kept on the 50 side: 15 `SIN-`, 46 `CSHI-`, 47 `FDBT-`, 51 `TDRQ-`, 04 Promotion Enrollment, 16 `DIST-` and 02 `DTHN-`.
  - The REL rows remain, each with a note naming the side that holds the link. Movement Source Type keeps the 13 values, now including Remediation (13).
- **Firm settlement account.** It is held once, on Money Movement, rather than as an ODFI field on ACH Entry Detail. It is blank for card movements and for drafts drawn on a program bank or a fund. **Check Direction** is dropped because Movement Direction carries the same fact. Movement Direction is read relative to the movement account; the shared descriptions are kept unchanged.
- **Omnibus deposit accounts (CW-108)** are Program Bank Participation facts, never 43 accounts. **Program Bank** is the role profile of a 02 bank party. FDIC Certificate Number and Bank Charter Type are Derived copies of facts of that party (02 scheme proposal at W5).
- **Sweep vehicle (lead ruling).** Sweep Program lists Eligible Sweep Funds (multi). 15 Cash Sweep Election.Elected Sweep Fund must be one of them (row rule), and the old single-valued fund is dropped. Sweep Program Type labels follow 15 Sweep Vehicle Type.
- **15c3-3(j)(2).** Consent is on the 15 election, and the disclosure version and the latest change notice are on Sweep Program. The latest change is recorded as Program Change Notice Date and Program Change Effective Date (30-day rule, (ii)(D)). Statement notices are 13.
- **Primary purpose exception.** Primary Purpose Exception Basis and Exception Notice Filed Date replace the Boolean on Program Bank Participation (12 CFR 337.6; basis values marked confirm).
- **Holds and special category (CW-109, CW-115, CD-344; High finding).** A hold row is 'PII - special category (CD-344)' in either case:
  - its Hold Type is FINRA Rule 2165 Disbursement Hold or FINRA Rule 2166 Temporary Delay;
  - its Hold Reason is one of the four flagged reasons.

  A Rule 2165 hold must carry a flagged reason. Monitoring alerts raised by the Elder Exploitation Pattern scenario are special category too. Both rules are in enrich_50 ROW_OWNERSHIP and in the object notes. Rule 2166 is modeled with its filed limit of 10 business days (confirm). Legal Process, AML and Deceased Owner holds stop one movement; an account freeze is the 15 restriction.
- **Bank verification (CW-033).** The event cites the 15 Bank Verification Method and Bank Verification Status lists (External), so the row rule copies values without a map. The 50 lists Verification Method and Verification Result are dropped; their names clashed with 02's CIP lists.
- **List renames (W5 clashes):**
  - Money Movement Return Type, renamed from Return Type (which clashed with 01) and then from ACH Return Type at the W2-W4 merge, because it also holds the wire and check equivalents.
  - Money Movement Hold Status, renamed from Hold Status, which clashed with 39.
  - Debit Card Status, renamed from Card Status, which clashed with 44.
- **Monitoring and sanctions (CW-110).** The alert disposition list is a copy of 29's. The scenario list is "Money Movement Monitoring Scenario". Screening Result answers the match question; Sanctions Screening Disposition records the action.
- **Fraud.** Assessment Timestamp keys the assessment and is the as-of of the Derived copy Account Age Days (15).
- **Checkwriting on own money market funds (lead ruling).** A draft is drawn on the fund's checkwriting bank and honored by a redemption. Check Detail.Redeeming Fund Order (typed with 29) records the path from check presentment to the 29 Fund Order. Drawn-On Program Bank serves only where checkwriting runs on a program bank.
- **Regulation E scope (confirm).** The broker-dealer that holds the brokerage account may itself be a Regulation E financial institution under 1005.2(i). Reg E also reaches ACH and other electronic transfers on a consumer brokerage account, not only card transfers. Card Dispute works card errors, and ACH error notices are worked on the same object until a broader EFT error notice object is agreed.
- **Wire.** OMAD is added. Wire Counterparty Name holds the beneficiary of an outgoing wire or the originator of an incoming one.
- **Keys.** Event Sequence and Exception Sequence prevent key collisions.
- **PII tiers.** Every object states its tier on its first attribute.
  - 'PII - financial (restricted)': ACH, Wire and Check detail, Bank Account Verification Event, Money Movement Monitoring Alert (special category on Elder Exploitation Pattern rows) and Debit Card.
  - 'PII - identity': Payment Sanctions Screening.
  - 'PII - financial' with special-category rows: Money Movement Hold.
  - 'No PII': Sweep Program, Program Bank, Program Bank Participation, Sweep Rate Tier, Sweep Run, Program Bank Daily Total, and Client Cash Forecast with its lines.
  - Every other object is 'PII - financial'.
- **Bare words.** "Position" no longer appears. "Custody" appears only in the name of domain 49.

## 3. Jurisdiction (new domain, CW-022)

`JURISDICTION = []`. Only US sources are used.

Left out, and not to be added: UK client money (CASS 7), Faster Payments and BACS, SEPA credit transfers and direct debits, the UK Financial Services Compensation Scheme (FSCS), PSD2 strong customer authentication, and UK APP fraud reimbursement.

Kept: foreign wires to non-US banks (IBAN, BIC, bank country and OFAC screening), FX conversion at payment, the IAT entry class, and nonresident-alien clients.

## 4. References to sibling and future domains

| Domain | Object referenced (type as written) | Example key |
|---|---|---|
| 49 (W3 sibling) | Account Cash Balance, 49 (override; Sweep Allocation reconciliation only). The 49 activity holds the posting link. | `ACC-0049812 / USD / SWEEP_BALANCE / 2026-10-05` |
| 46 (W2) | Managed Account Cash Instruction, 46 | `CSHI-2026-00318273` |
| 47 (W2) | Fee Debit, 47 | `FDBT-2026M09-000418822` |
| 51 (W2) | Trust Distribution Request, 51 | `TDRQ-2026-00318` |
| 08 (W2) | Senior Investor Case, 08 | `SNRC-2026-00217` |
| 04 (W2) | Promotion Enrollment, 04 | `PROMO-2026-007 / PTY-104588` |
| 13 (W2) | Service Request (on Money Movement Exception only); the 13 side holds the movement links | `SRQ-2026-0081302` |
| 29 (W3) | Fund Order (Sweep Run); Fund Order, 29 (Check Detail.Redeeming Fund Order) | `FNDO-2026-00418390` |
| 02 (W1) | Authority Grant, 02; Trusted Contact Designation, 02; Vulnerability Concern, 02; Death Notification, 02; Party; Contact Point | `AGNT-`, `TCNT-`, `VCON-`, `DTHN-`, `PTY-`, `CTP-` |
| 15 (W1) | Account; Account Standing Instruction; Bank Instruction; Account Feature; Account Restriction; External lists Bank Verification Method and Status, Account Type | `ACC-`, `SIN-`, `ABI-`, `AFEA-`, `ARX-` |
| 16 | Distribution Request, 16 | `DIST-2026-0071201` |
| 38 (W4 consumer) | AML Case, 38; AML and Sanctions Report, 38; Policy | `AML case 2026-0441`; `POLCY-0118` |
| 43, 39, 37, 14, 09, 01, 20 | Corporate Bank Account; Cash Forecast, 43; Contract; Model Inventory Entry; Loss Event; Licensed Dataset; Internal Legal Entity; Share Class; Employee | registered prefixes |

The domain's own objects are referenced as "Reference (<Object>, 50)": Money Movement, Money Movement Hold, Program Bank, Sweep Program, Debit Card, Bank Account Verification Event and Client Cash Forecast.

## 5. Unverified items (confirm)

- SEC action on SR-FINRA-2026-018 (Rule 2165 up to 145 business days; Rule 2166 up to 10 business days as filed).
- Final status of RIN 3064-AG07. As proposed it exempts broker-dealer custodial accounts.
- The Primary Purpose Exception Basis values and the notice-filer practice under the 2020 brokered deposits rule (12 CFR 337.6).
- Whether the broker-dealer is a Regulation E financial institution for brokerage-account transfers, and how far Reg E reaches ACH on brokerage accounts. A CFPB 2025 proposed interpretive rule was reported; its status is unverified.
- NACHA code titles and the modeled subset, checked against Appendices Four and Five of the 2026 Rules.
- FinCEN advisory number FIN-2022-A002 and its URL path; the ISO 18245 catalog URL.
- Closed in the fix pass:
  - the PAYROLL and PURCHASE descriptions;
  - the NACHA phase dates;
  - the 12 CFR 330 section numbers;
  - the current Rule 2165 limits;
  - the Rule 2166 limit (10 days as filed);
  - the withdrawal of the brokered deposits proposal.

## 6. SME questions (tailoring levers; reference default in brackets)

1. Is the broker-dealer self-clearing or fully disclosed? [Self-clearing.] Lever: under fully disclosed clearing, the clearing firm's program applies and Sweep Allocations become received copies.
2. How many program banks, and is coverage above USD 250,000 offered? [Several banks with priority order and client exclusions.] Lever: one bank.
3. Which sweep vehicle is the default? [Cash defaults to the firm's own money market fund. The bank deposit sweep is offered by account type (such as a cash-management account) or by election.] Levers: bank sweep only, or money market fund only.
4. Are instant payments (RTP, FedNow) offered? [No.] Lever: add rail values and a detail group.
5. What funds availability applies to deposited checks and ACH? [Firm-policy holds aligned to Regulation CC timing.] Lever: no holds on verified bank accounts.
6. Do Rule 2165 holds cover disbursements only, or securities too? [Disbursements here, securities transactions in 15.] Lever: one account-level restriction.
7. Are checkwriting and a debit card offered? [Checkwriting on the firm's own money market funds: each draft is drawn on the fund's checkwriting bank and honored by a 29 redemption (Check Detail.Redeeming Fund Order). A debit card is issued through one program bank.] Levers: checkwriting through a program bank (Drawn-On Program Bank), or drop the card family.
8. Do plan distributions run through 50? [No: they run on the recordkeeper's rail (16), and rollover receipts reference the 16 Distribution Request.] Lever: one payment hub.
9. If Rule 2166 is adopted, are its delays recorded here or in 15? [Disbursement delays here, as special category; securities delays in 15.]
10. Does 38 report blocked and rejected payments without an AML case? [Yes.]
11. (Added) In which NACHA fraud monitoring phase is the firm? [Phase 1 (large originator).] Lever: phase 2 for a smaller firm.

## 7. Overlaps with other domains (for consolidation)

- 29 Cash Movement.Client Money Movement now references 50 (CW-107). Payment Rail is mapped to 29 Order Payment Method in proposals LIST_MAPS.
- 15: Bank Verification Status and Method are set from the 50 event, using the same vocabulary. Elected Sweep Fund must be one of the Eligible Sweep Funds. Sweep vehicle labels are aligned.
- 49 renamed its mention of Program Bank Daily Position to Program Bank Daily Total at the W2-W4 merge.
- 43 Cash Flow Category and 50 Client Cash Flow Category are a hierarchy candidate.
- 44 Card Transaction and 50 Card Transaction Detail stay separate, as do 44 Card Status and 50 Debit Card Status.
- 47 REL "Fee Invoice is paid by Money Movement" needs a decision at the W3 merge (proposals NOTES).

## 8. Suggested validation steps

1. Walk an ACH withdrawal through return (R01) and reinitiation, and check the 49 postings that reference the movement.
2. Walk a Rule 2165 hold across 02, 15, 50 and 08, and confirm that its special-category tier holds whatever reason is chosen.
3. Run one day's sweep. Sum the allocations per account against the 49 Sweep Balance, and per program and bank against the omnibus statement (Program Bank Daily Total).
4. Present a money market fund checkwriting draft and trace it to the 29 redemption and the 49 Client Holding change.
5. Recompute FDIC coverage for a joint account and for a revocable trust with three beneficiaries.
6. Review the alerts and screening with the AML Officer for SAR confidentiality and the special-category view.
