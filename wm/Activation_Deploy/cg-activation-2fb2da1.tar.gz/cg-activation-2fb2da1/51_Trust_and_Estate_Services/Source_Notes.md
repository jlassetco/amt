# Source Notes: 51 Trust & Estate Services (Draft v0.1, 2026-10-14)

Workbook: `Trust_and_Estate_Services_Data_Taxonomy.xlsx`. Content module: `_tools/content/content_51_trust_and_estate_services.py` (new). Enrichment: `_tools/enrichment/enrich_51.py` (new). Proposals: `_tools/consolidation/proposals_w2_51.py`.
Size (after the review fix pass, 2026-10-14): 7 families, 15 objects (10 business objects, 5 attribute groups), 143 attributes, 41 CDEs (29%), 27 code lists (24 local, 3 copies of shared lists), 40 relationships, 15 sources. Ownership: 22 references, 5 derived copies, 0 unresolved. The fix pass applied `00_Program/Rework/Reviews/51_review.md` (1 High, 12 Medium, 18 Low) with the program-lead rulings; see section 2a.

**Perspective.** Wealth manager (direct) | Scope: US. A hypothetical US wealth manager of the Vanguard type whose optional national trust company (OCC charter, 12 CFR Part 9) acts as trustee, co-trustee, directed trustee, agent for trustee or executor for wealth clients (business line TR, CW-004), and whose broker-dealer also opens accounts for trusts whose trustees are the clients themselves (DB). Optional, Light tier (CW-017): a firm without a trust company drops 51 and keeps the 15 Governing Trust certification facts.

## 0. Why this domain exists

Trust officers and fiduciary operations produce a record no other domain holds: the trust instrument and its terms, who holds which fiduciary role, who the beneficiaries and remaindermen are, each discretionary distribution request and the decision on it, the principal or income character of each receipt and disbursement, the reviews 12 CFR 9.6 requires of every fiduciary account, estate settlement cases, and the fiduciary income tax return (Form 1041). The party is 02's, the account 15's, the Client Holdings 49's and the investment management 46's; the trust's terms and the fiduciary's decisions have their own regulator (OCC), statutes (state trust codes, the uniform acts) and system (trust accounting), which is why 51 is a Data Domain and not a family of 15.

## 1. Sources consulted

| Source | URL | What it gave us |
|---|---|---|
| 12 CFR Part 9 (Fiduciary Activities of National Banks) | https://www.ecfr.gov/current/title-12/chapter-I/part-9 | 9.4 trust committees and delegation, 9.5 policies, 9.6 reviews, 9.8 records, 9.9 audit, 9.12 self-dealing. The 9.6 text was checked (via the Cornell LII copy, https://www.law.cornell.edu/cfr/text/12/9.6): (a) review before accepting an account "to determine whether it can properly administer the account"; (b) "a prompt review of all assets" on acceptance of an account with investment discretion; (c) "at least once during every calendar year" a review of all assets of each account with investment discretion, "individually and collectively". Fiduciary Account Review, Fiduciary Review Type. |
| OCC Comptroller's Handbook, Personal Fiduciary Activities (revised 2015, OCC Bulletin 2015-12); Conflicts of Interest | https://www.occ.gov/publications-and-resources/publications/comptrollers-handbook/index-comptrollers-handbook.html (confirm booklet path) | The current handbook source: account acceptance, initial-review timing practice, administrative reviews, distribution practice. |
| OCC Bulletin 2008-10, Fiduciary Activities of National Banks: Annual Reviews of Fiduciary Accounts Pursuant to 12 CFR 9.6(c) | https://www.occ.treas.gov/news-issuances/bulletins/2008/bulletin-2008-10.html | Historical: listed by the OCC as superseded by Bulletin 2014-3 (extent to confirm). |
| Uniform Trust Code | https://www.uniformlaws.org (confirm act page) | Sections 103 (qualified beneficiary), 108 (principal place of administration), 111 (nonjudicial settlement), 414 (uneconomic trust), 502 (spendthrift), 602 (revocation), 701 and 704 (acceptance, vacancy), 813 (duty to inform and report), 1013 (certification of trust). |
| Uniform Directed Trust Act (2017) | https://www.uniformlaws.org (confirm) | Trust directors, directed trustees: Fiduciary Capacity "Directed Trustee", Trust Role Type advisers. |
| Uniform Prudent Investor Act (1994) | https://www.uniformlaws.org (confirm) | Prudent investor standard and diversification; review exceptions; provisions read by 46. |
| Uniform Principal and Income Act (1997, amended) | https://www.uniformlaws.org (confirm) | Allocation rules, power to adjust. |
| Uniform Fiduciary Income and Principal Act (2018) | https://www.uniformlaws.org (confirm) | Allocation rules, power to adjust, unitrust; state adoption to confirm. |
| IRS Form 1041 and Instructions; Schedule K-1 (Form 1041) | https://www.irs.gov/forms-pubs/about-form-1041 | Entity types, DNI, elections, due dates, K-1 boxes. |
| IRS Form 7004; Form 8855 | https://www.irs.gov/forms-pubs/about-form-7004 | Extension; section 645 election. |
| IRC Subchapter J (641 to 692; 671 to 679 grantor trusts) | https://www.law.cornell.edu/uscode/text/26/subtitle-A/chapter-1/subchapter-J | DNI, section 644 calendar year, 645, 663(b), 643(e)(3), grantor trusts. |
| Treas. Reg. 1.671-4 | https://www.ecfr.gov/current/title-26/section-1.671-4 | Optional grantor-trust reporting methods. |
| IRC 7701(a)(30)-(31); IRC 2032 | https://www.law.cornell.edu/uscode/text/26/7701 | Domestic and foreign trust tests (read from 02 Tax Profile); alternate valuation date. |
| FINRA Rule 3241 | https://www.finra.org/rules-guidance/rulebooks/finra-rules/3241 | Registered person named trustee, executor or beneficiary of a customer: cross-check only (38 declaration, CW-074). |
| State trust and probate codes (Delaware Title 12; South Dakota, Nevada directed-trust statutes) | https://delcode.delaware.gov/title12/ (confirm chapters) | Situs, directed trusts, decanting, creditor periods, probate status and court accountings: tailoring lever. |

## 2. Design and boundary decisions

- **Outline followed:** the brief's 7 families and 15 objects (10 BO, 5 AG) with its names; "Trust" is the exact name 15 Account Registration Detail.Governing Trust references (CW-075). Family codes TE-TRS, TE-ROL, TE-DIS, TE-ACC, TE-REV, TE-EST, TE-TAX.
- **The trust is not a party or an account (CW-075).** Trust Party references the 02 party of type Trust; Trust Name is a Derived copy of its 02 legal name and Filer EIN a masked Derived copy of its 02 EIN; foreign trust status is read from 02 Tax Profile.US Person Indicator.
- **Fiduciary capacity is held once, on Trust Role.** The trust company's appointment is the Trust Role row held by the 09 internal legal entity (Trustee, Co-Trustee, Directed Trustee, Agent for Trustee). A trust with no such row is a certification-only trust (client trustee, DB).
- **Certification facts (ruling 3).** 51 masters the certification facts (certification received date, execution date of version 1, situs and governing law) for every trust it records, including certification-only trusts; the rule is stated once, on Certification of Trust Received Date. 15 Trust or Agreement Date and Registration Jurisdiction become Derived copies of 51 at the merge. 51 holds no inverse account list; Fiduciary Account Review lists the accounts reviewed (15) as the brief allows.
- **Roles (CW-026).** Every role holder, beneficiary, decedent and personal representative is a 02 party; the trust company is a 09 internal legal entity. Authority grants (letters testamentary) stay 02 and are referenced. 51 masters every trust relationship (ruling 1): ROW_OWNERSHIP rules on Trust Role Type and Beneficial Interest Type make 02 Party Relationship 'Trustee Of', 'Grantor Of' and 'Trust Beneficiary Of' rows Derived copies for trusts with a 51 record (CD-289), for rows held by a 02 party only (trust-company rows derive nothing in 02); the 02 side is in proposals NOTES.
- **Principal and income is a ledger, not a book of record (CW-076, CW-007).** Principal and Income Allocation references the 49 client account activity (CLACT-) or 50 money movement (MMVMT-) it characterizes and masters only the date, the character and the principal and income amounts; Fiduciary Accounting Statement masters principal cash and income cash, with the market value a Derived copy of 49. No Client Holding, client tax lot, cash balance or payment is mastered.
- **Distributions.** The decision cites the Trust Term Provision applied; the payment link is held once, on the 50 side (the Money Movement names TDRQ- as its source), so the decision carries no payment reference; Decision Authority carries the reference default (trust officer within a limit, trust committee above it).
- **Reviews.** Fiduciary Review Type cites 12 CFR 9.6(a), (b), (c) by paragraph; the 60-day initial-review deadline is held as a firm-policy due date (confirm the OCC guidance).
- **Estate settlement (CW-077).** One case per estate the trust company acts for, following a 02 Death Notification; 13 keeps every transfer and re-registration request and references ESTATE-.
- **Fiduciary tax (CW-076).** Fiduciary Tax Return per trust or estate and tax year; K-1 amounts by character in Beneficiary Tax Allocation; 13 delivers the K-1; 19 keeps the firm's tax.
- **PII.** Every object states its tier in its first attribute's Notes and every attribute carries a PII note. Special category (CD-344): Trust Distribution Request (purpose and description), Distribution Decision (inherited; decision and rationale restricted) and Trust Term Provision summaries of special needs provisions. EINs masked.
- **No Record Metadata object** (21). Only TRUST-, TDRQ-, FIRV-, ESTATE-, TXRT- (and neighbors' keys) in examples.

**Deviations from the brief**

| Brief | Draft | Why |
|---|---|---|
| Trust: "name" | Trust Name kept as a Derived copy of 02 Organization.Legal Name | The name is a party fact (02 checklist item). |
| Trust: "situs and governing law state"; local list "Trust Situs" with foreign situs as a value | Situs Jurisdiction and Governing Law Jurisdiction as ISO 3166-2 codes (a foreign situs takes the ISO 3166-1 country code); foreign trust status read from 02; no Trust Situs list | A situs list of states would duplicate ISO 3166-2; the basis of situs is left to the Provision Type 'Situs Change Authority'. |
| Trust: referral source (03 Channel Referral) | Not carried as an attribute | Size; 03 Channel Referral can name the trust outcome. Noted in proposals. |
| Trust Instrument Document: "court of testamentary trust" | Not carried; Probate Court not carried on the estate case either | Size; the court is on the instrument document (Court Order) and the 39 legal matter where litigated. |
| Trust Term Provision: powers of appointment, spendthrift, decanting, protector powers as attributes | Provision Type values, with Distribution Standard, Unitrust or Annuity Rate, Termination Event and Investment Constraint Indicator as attributes | One row per provision type keeps the grain of the brief. |
| Trust Role: "powers held, bond" | Not carried; Role End Reason as text | Size; powers are Trust Term Provisions. |
| Beneficial Interest: "per stirpes", "age conditions", "vesting event" | One Vesting Condition text; vesting folded into Beneficial Interest Type (Vested Remainder, Contingent Remainder) | Kept the list count within 20 to 26. |
| Trust Distribution Request: "requested by", "supporting documents received" | Folded into Purpose Description and the 13 intake request | Size. |
| Distribution Decision: "decided by (officer or committee, 39)" | Decided By (20) and Decision Authority (Trust Committee value); the 39 committee is referenced on Fiduciary Account Review | Avoids two decision-maker references on one row. |
| Principal and Income Allocation: "power to adjust or unitrust conversion indicator" | Values of Principal and Income Rule | The rule applied already says it. |
| Fiduciary Accounting Statement: "opening principal and income cash" | Not carried (the prior statement's closing figures) | Same fact held twice. |
| Estate Settlement Case: "letters date, inventory filed, final accounting" | Letters on the 02 Authority Grant (referenced); inventory and final accounting as Estate Milestone tasks | One fact held once. |
| Fiduciary Tax Return: "due date, extension" | Extended Due Date only (the base due date is computed) | Size. |
| Shared lists Business Line, Record Status, Frequency | Not used | Every row is TR; statuses are lifecycle-specific; no recurrence held. |
| Proposals file `proposals_51.py` | `proposals_w2_51.py` | Named by the assignment. |
| Trust: firm fiduciary capacity, trust company entity (09), foreign trust indicator | Dropped in the fix pass | Held once: Trust Role rows held by the trust company; 02 US Person Indicator (ruling 4). |
| Distribution Decision: money movement (50) | Dropped in the fix pass | Link held on the 50 side (ruling 2). |
| Fiduciary Tax Return: tax year | Tax Year End Date (Date); base due date computed from it | Fiscal-year estates (ruling 5). |

**Wholesale objects:** none; 51 is new. **Jurisdiction (CW-951):** no removals, `JURISDICTION = []`; CW-951 drafted in proposals.

**References to sibling and future domains**

| Object (type) | Domain | Used on |
|---|---|---|
| Advisor (`Reference (Advisor, 03)`, EMP- example, override to 03) | 03 | Trust.Administering Trust Officer |
| Client Account Activity (`Reference (Client Account Activity, 49)`, CLACT-) | 49 (W3) | Principal and Income Allocation.Source Account Activity |
| Money Movement (`Reference (Money Movement, 50)`, MMVMT-) | 50 (W3) | Principal and Income Allocation.Source Money Movement (the payment of a decision is held on the 50 side) |
| Client Holding (Derived copies) | 49 (W3) | Closing Market Value; Client Holding Valuation Date |
| Account Investment Constraint, Fee Debit, Tax Form Record, Outside Business Activity, Channel Referral, Senior Investor Case | 46, 47, 13, 38, 03, 08 | Relationships only |
| Communication delivery date (Derived) | 13 | Fiduciary Accounting Statement.Trustee Report Delivered Date |

## 2a. Review fix pass (2026-10-14)

| Finding | Action |
|---|---|
| High: Trust Beneficiary Of held twice (02 and 51) | ROW_OWNERSHIP rule on Beneficial Interest Type; 02 merge note extended; 02 added to the Beneficiary term conflict. |
| Medium: special-needs values not marked | Trust Instrument Type, Provision Type and Distribution Standard notes and list values marked PII - special category (CD-344). |
| Medium: Foreign Trust Indicator duplicates 02 | Dropped; read 02 US Person Indicator. |
| Medium: CAA- and MMT- anchors | Re-pointed to CLACT- and MMVMT-. |
| Medium: payment link on both sides | Distribution Payment dropped; 50 holds the TDRQ- source; REL kept. |
| Medium: certification facts contradiction | One rule: 51 masters them for every trust; 15 date and jurisdiction Derived at merge. |
| Medium: fiduciary capacity held twice | Firm Fiduciary Capacity and Trust Company Entity dropped (Fiduciary Capacity list removed); Trust Role Type gains Directed Trustee. |
| Medium: Trust Instrument Type not exclusive | Purpose-only list with a most-specific-wins rule; Revocable Living, Irrevocable General and Testamentary replaced by General Estate Planning Trust. |
| Medium: Tax Year as text | Tax Year End Date (Date); base due date computed. |
| Medium: 02 derivation from trust-company rows | Row rule limited to rows with a Role Holder Party. |
| Medium: Trust Term Provision key | Provision Sequence and Provision Effective To added; KEY_FORMATS row proposed. |
| Medium: allocation has no date | Allocation Date added. |
| Medium: OCC Bulletin 2008-10 | Full title, marked historical (superseded by 2014-3, confirm); 2015 handbook booklet cited as current. |
| Lows applied | Role End Reason restricted; Trustee Report Delivered Date Derived (13); Letters Received and Form 1041 Filed read from their records; Investment Discretion as-of the review; successor serving defined by Role Effective From; foreign situs coded ISO 3166-1; filed-date example after April 15; decision row holds the latest decision; Exception Sequence and Task Sequence added; TXRT- format proposed; 13 ESTATE- digit count noted; term conflicts Proposed; concept row 'Trust / Trust Instrument'; two shared candidates added; review REL split; REL rows to 03 Channel Referral and 08 Senior Investor Case; Probate Jurisdiction added; Role Effective From, Role Effective To and Return Filed Date flagged CDE. |
| Lows skipped | Return Status keeps the shared Case Status as a work status (lead decides); requested-by not added; the 03 name in domains.py is the lead's. |

## 3. Unverified items (confirm)

1. The OCC 60-day initial post-acceptance review expectation (the rule says "prompt"); how far OCC Bulletin 2008-10 is superseded by Bulletin 2014-3; the path of the 2015 Personal Fiduciary Activities booklet.
2. State adoption of the Uniform Fiduciary Income and Principal Act and its section numbers (power to adjust 203, unitrust Article 3); UPIA section 104; the deferred compensation and annuity section.
3. Uniform Law Commission act page URLs for the UTC, Uniform Directed Trust Act, UPIA (prudent investor), UPIA (principal and income) and UFIPA.
4. Schedule K-1 (Form 1041) box numbering for the current year; the Form 7004 extension length for Form 1041.
5. FINRA Rule 3241 effective date (February 15, 2021, Regulatory Notice 20-38; confirmed by secondary sources only).
6. Delaware Title 12 chapter references and other directed-trust statutes.

## 4. SME questions (tailoring levers; reference default in brackets)

1. Does the firm hold Trust records for client-trustee trusts it does not administer? [Yes: no Trust Role row held by the trust company; 51 masters the certification facts and roles. Lever: 15 keeps the certification facts and 51 holds fiduciary trusts only.]
2. Directed trusts? [Supported: Directed Trustee role, investment and distribution adviser roles, Distribution Adviser Direction authority. Lever: drop the adviser values.]
3. Which principal and income act governs? [The act of the trust's governing-law state, recorded per allocation (Principal and Income Rule). Lever: one firm-wide default.]
4. Who decides discretionary distributions? [A trust officer up to a delegated limit, the trust committee (39) above it.]
5. Is the initial post-acceptance review tracked to a fixed deadline? [60 days as firm policy, confirm the OCC guidance. Lever: the deadline value.]
6. Is the firm executor or only agent for the personal representative? [Both values in Estate Role. Lever: agent only.]
7. Does 51 prepare Form 1041 or only hold the filing facts? [Filing facts and K-1 allocations; preparation outsourced.]
8. Are special-needs and medical purposes recorded? [Yes, special category with a restricted view. Lever: coded purpose only, no Purpose Description or Provision Summary text.]
9. Is Form 706 (estate tax) in scope of the estate case? [Milestone only; no estate tax figures held.]

## 5. Overlaps with other domains (for consolidation)

| Item | Domains | Proposal |
|---|---|---|
| Trustee Of / Grantor Of | 02 Party Relationship, 51 Trust Role | 02 rows Derived for trusts with a 51 record (CW-075). |
| Governing Trust example | 15, 51 | TRS-000412 re-keys to TRUST-000412 at merge. |
| Estate | 02 Death Notification, 13 Transfer of Ownership & Estate, 51 Estate Settlement Case | One fact each (CW-077); 13 references ESTATE- by typed domain number. |
| Investment provisions | 51 Trust Term Provision, 46 Account Investment Constraint | 46 references the provision. |
| Trustee fees | 47, 51 | 47 holds the fee; 51 allocates its principal and income character via the 49 activity. |
| Tax returns | 19 Corporate Tax Return, 51 Fiduciary Tax Return, 13 Tax Form Record | Term conflict logged; 13 delivers K-1s. |

## 6. Suggested validation steps

1. Walk a revocable trust with a client trustee (certification only), a corporate-trustee irrevocable trust with discretionary HEMS distributions, a directed trust with an investment adviser, a special needs trust and an estate with the trust company as executor through the objects.
2. Test the 12 CFR 9.6 review types and the review calendar with Fiduciary Compliance.
3. Run one quarter of a trust's 49 activity through the principal and income rules with Trust Accounting.
4. Reconcile a prior-year Form 1041 and its K-1s against Fiduciary Tax Return and Beneficiary Tax Allocation.
5. Agree the 02 row rule, the 15 re-key and the 13, 46, 47, 49 and 50 references with their drafters.
6. Confirm the items in section 3.
