# Source Notes: 52 External Manager & Sub-Adviser Oversight (Draft v0.1, 2026-10-14; review fix pass 2026-10-15)

Workbook: `External_Manager_and_Sub_Adviser_Oversight_Data_Taxonomy.xlsx`. Content module: `_tools/content/content_52_external_manager_and_sub_adviser_oversight.py` (new). Enrichment: `_tools/enrichment/enrich_52.py`. Proposals: `_tools/consolidation/proposals_w3_52.py`.
Size: 8 families, 28 objects (26 business objects, 2 attribute groups), 250 attributes, 84 CDEs (34%), 39 code lists (30 local, 9 copies of shared lists), 48 relationships, 19 sources. Ownership: 49 references, 10 derived copies, 12 overrides, 4 row ownership rules, 0 unresolved.

**Perspective.** Wealth manager (direct) | Scope: US. A hypothetical US wealth manager of the Vanguard type (business lines DB, DA, HA, PF, WR, IA, IC, TR; CW-004). Its fund adviser oversees unaffiliated sub-advisers (sleeves and whole funds); its broker-dealer and RIA curate third-party funds and ETFs; manager research is in house.

## 0. Why this domain exists

Manager Research & Oversight finds, vets, hires, watches and replaces the external managers the firm relies on: the sub-advisers that run part of the active fund range (Investment Company Act Section 15), managers hired for OCIO clients and trust accounts, and the sponsors of third-party funds and ETFs that advice models and plan menus use or that clients are recommended (Reg BI reasonable-basis diligence). 35 masters the contract and the board's Section 15(c) approval, 33 codes and tests the guidelines, 32, 31, 11 and 27 compute the base numbers, 12 executes transitions; 52 holds the judgment and its evidence.

| Business line | What it adds here |
|---|---|
| DB | A screen of self-directed platform listings (Product Due Diligence with Full Due Diligence Indicator = N) and Product List Status (scope Brokerage Platform); 01 Platform Product Availability references the approval. |
| DA | Full Product Due Diligence for model building blocks; 24 Model Building Block reads the list status. |
| HA | Full due diligence for anything recommended; 45 to read the list status (requested). |
| PF | The core: searches, due diligence, Sub-Adviser Engagement, guideline sets, certifications, thresholds, oversight reviews, Section 15(c) submissions, manager-of-managers hires, terminations. CIT sub-advisers: overseeing entity the trust company. |
| WR | Plan Menus scope (optional, when the firm is a 3(21) or 3(38) fiduciary); 16 to read the status (requested). |
| IA | OCIO managers: Engagement Scope 'OCIO Mandate', governed by a 39 contract. |
| IC | Product due diligence of third-party ETFs inside delivered models only. |
| TR | Engagement Scope 'Trust Mandate' (prudent investor delegation, optional), governed by a 39 contract. |

## 1. Sources consulted

| Source | URL | What it gave us |
|---|---|---|
| Investment Company Act s.15(a), (c), (a)(3), (a)(4) | https://www.law.cornell.edu/uscode/text/15/80a-15 | Written sub-advisory contract, board approval and continuance, duty to request and furnish information, termination on notice and on assignment. |
| Investment Company Act s.2(a)(3), s.6(c) | https://www.law.cornell.edu/uscode/text/15/80a-2 | Affiliated person; exemptive authority behind manager-of-managers orders. |
| Rule 15a-4 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.15a-4 | Interim contracts of up to 150 days. |
| Manager-of-managers exemptive orders; proposed Rule 15a-5 (Release 33-8312 / 34-48683 / IC-26230, File S7-20-03, October 2003) | https://www.sec.gov/rules/proposed/33-8312.htm | Hiring unaffiliated sub-advisers without a vote; information statement or notice within 90 days of the hire; adviser oversight; no fee increase without a vote. |
| Regulation 14C, Rule 14c-2(d); Rule 14a-16 | https://www.ecfr.gov/current/title-17/chapter-II/part-240 | Information statement content and the notice-and-access route the orders permit. The post-hire timing is the order's, not Rule 14c-2(b)'s 20-day pre-action rule. |
| Rule 12d1-4; s.12(d)(1) | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.12d1-4 | Fund of funds investment agreement, adviser evaluation and findings, duplicative fees. |
| Form N-1A Items 5, 10; SAI Items 19, 20 | https://www.sec.gov/files/formn-1a.pdf | Sub-adviser and portfolio manager disclosure; turnover in financial highlights (read from 27). |
| Rules 38a-1 and 17j-1 | https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.38a-1 | Board approval of sub-adviser policies and codes of ethics; certifications. No longer cited for guideline delivery (internal). |
| Advisers Act Rules 206(4)-7, 206(4)-6, 204-2 | https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.206(4)-7 | Sub-adviser compliance program; delegated proxy voting; records of oversight and of rule versions delivered. |
| Advisers Act fiduciary interpretation (Release IA-5248, 2019) | https://www.sec.gov/rules/interp/2019/ia-5248.pdf | Duty of care in selecting and monitoring managers for OCIO clients. |
| ERISA s.3(21), 3(38), 404(a) | https://www.law.cornell.edu/uscode/text/29/1002 | Plan menu scope and OCIO manager selection for plan clients. |
| UPMIFA s.5 | https://www.uniformlaws.org | Delegation by endowments and foundations (OCIO clients). |
| Uniform Prudent Investor Act s.9 | https://www.uniformlaws.org | Trust Mandate scope only. |
| Reg BI care obligation, Rule 15l-1(a)(2)(ii) | https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.15l-1 | Reasonable diligence before a recommendation; full due diligence for recommended uses. |
| FINRA Regulatory Notice 22-08 | https://www.finra.org/rules-guidance/notices/22-08 | Complex product determination (the firm determines; no standard definition). |
| Form ADV; IAPD; FINRA Form U4, BrokerCheck | https://adviserinfo.sec.gov | Ownership (Schedules A and B), assets, disciplinary disclosures. |
| FCRA, 15 U.S.C. 1681b | https://www.law.cornell.edu/uscode/text/15/1681b | Authorization before vendor consumer reports on key persons; only outcome and authorization held. |
| ILPA DDQ; AIMA illustrative DDQs | https://ilpa.org ; https://www.aima.org | Questionnaire section structure and scoring factors (cross-check only). |
| ISO 4217 / ISO 8601 | https://www.iso.org | Formats. |

## 2. Design and boundary decisions

- **Contract 35, oversight 52 (CW-117).** No object is a sub-advisory agreement. Sub-Adviser Engagement has a conditional governing document (row rule): Governing Fund Agreement (35 ADVA-) on Sleeve and Whole Fund scopes; Governing Contract (39) on OCIO Mandate, Trust Mandate and Retail Managed Account Sleeve scopes. Engaged Fund and Board Approval Date follow the fund rule; Board Approval Date is the earliest approving 35 resolution of the agreement (CD-237). The 18 Sleeve Portfolio is optional and blank for retail managed account sleeves, where the 46 Sleeve Assignment references the engagement.
- **Metrics (CW-119 as amended, CW-119-AM1 proposed).** Base numbers are Derived copies of pinned owner records: returns and benchmark returns (32, Return Version pinned), ex-post statistics (32), ex-ante tracking error (31), peer percentile (11 Peer Metric Snapshot), fee versus peers (11 Fee Benchmark Result), turnover (27 Financial Highlights, fund level). 52 computes only excess return (annualized return minus annualized benchmark return, percentage points) and breach count (count of 33 breaches on rules in the engagement's guideline set in the period). Style drift and active share are 52 oversight computations from 18 holdings and 22 index constituents at a stated date (W5 candidate for 32). The unit is the shared Measure Unit list; each Oversight Metric value describes its basis, unit and direction.
- **Thresholds** are stored once per engagement and metric (Oversight Metric Threshold: direction from shared Restriction Limit Type, value, warning value, approving decision, effective period). Readings carry only the flag against the threshold in force.
- **Guidelines (CW-118).** Guideline Rule Inclusion references 33 rules with the rule version pinned (Included Rule Version), or 01 restrictions.
- **Certifications.** Firm-level certifications (Rule 38a-1 policies, Rule 17j-1 code of ethics, Rule 206(4)-7 summary) key on the External Manager Profile and are stored once; quarterly guideline certifications also name the engagement.
- **Grain.** Onsite Visit, Background Check Result and Fund of Funds Use Detail are business objects with composite keys (review / visit date; key person / type / date; product review / acquiring fund). The remaining attribute groups are Search Outcome and Manager-of-Managers Hire Condition.
- **Transitions.** Manager Transition was dropped: the execution record is 12 Transition Event (Manager Replacement), referenced from Manager Termination. Aggregate transition cost is requested of 12 (proposals NOTES).
- **Product Due Diligence (CW-120).** One review per 17 instrument (one share class); Full Due Diligence Indicator separates the self-directed screen from full diligence. Oversight Review has two conclusions: Engagement Review Conclusion (Watch Status) and Product Review Conclusion (Product List Status). Research Coverage Status on the profile is set independently of engagement watch and product list status.
- **PII.** Every object states its tier. Manager Key Person, Onsite Visit and Background Check Result are PII - identity; background-check attributes are restricted; FCRA authorization is recorded as a fact.

**Deviations from the brief (cumulative)**
1. 28 objects (the brief's table lists 28); 26 business objects and 2 attribute groups after the fix pass; one object added (Oversight Metric Threshold) and one dropped (Manager Transition, to 12).
2. Local lists held at 30: Case Status for search and finding status; Oversight Status Reason (values scoped in their descriptions); Threshold Result; shared Vehicle Type, Asset Class, Business Domain, Measure Unit and Restriction Limit Type copies; Transition Method dropped with the transition; Manager Ownership Type restored as a small list.
3. Dropped to stay within 250 attributes: Industry Start Year, Stage Reached Date, Questionnaire Sections, Visit Notes Location, Check Next Due Date, Criterion Comment, the three Business Line attributes, Superseded Guideline Set, Strategy Inception Date, Review Questionnaire Type, Metric Data Basis. Track Record Source not restored; the GIPS source line was removed instead.
4. Shared Approval Status, Frequency, Period Type, Business Line and Data Basis are not used.
5. Proposals file `proposals_w3_52.py` (assignment) rather than `proposals_52.py` (brief).
6. Questionnaire template codes avoid the DDQ- token (registered 08, moving to 05 at W4).
7. The fix-pass ruling named "17 index constituents"; the registered object is 22 Index Constituent (members are 17 instruments), which is used.

## 3. Jurisdiction (new domain, CW-022)

Nothing removed; no JURISDICTION entries. Deliberately not imported: UCITS Directive Article 13 delegation due diligence, AIFMD delegation letters, FCA SYSC 8 outsourcing, MiFID product governance distributor duties. Foreign sub-advisers registered with the SEC stay in scope.

## 4. References to sibling and future domains

| Object | Domain | Type used | Note |
|---|---|---|---|
| Fund Advisory Agreement, Advisory Contract Renewal, Exemptive Relief Reliance | 35 | Reference (X, 35) | Exemptive Relief Reliance forced 35. |
| Transition Event | 12 | Reference (Transition Event, 12) | TRN-2026-0042. |
| Investment Committee Decision | 24 | Reference (Investment Committee Decision, 24) | 'MRC / date / item'. |
| Portfolio | 18 | Reference (Portfolio, 18) | Optional. |
| Performance Return, Benchmark Return, Ex-Post Risk Statistic | 32 | Reference (X, 32) | Last two forced 32. |
| Portfolio Risk Measure | 31 | Reference (Portfolio Risk Measure, 31) | |
| Peer Metric Snapshot, Fee Benchmark Result | 11 | Reference (X, 11) | Snapshot forced 11 (key starts SHC-). |
| Financial Highlights | 27 | Reference (Financial Highlights, 27) | Forced 27 (key starts PRD-). |
| Readers (REL only): Sleeve Assignment (46, wired), Model Building Block (24, wired), Plan Investment Option (16, planned), Recommendation (45, planned), Platform Product Availability (01, wired) | | | 16 and 45 requests in proposals NOTES. |

## 5. Unverified items (confirm)

- Proposed Rule 15a-5 (Release 33-8312): still listed as proposed; no adoption found; kept "confirm". Confirm the 90-day window against the fund complex's own order.
- eCFR path for Rule 14c-2; ILPA and AIMA paths; UPIA and UPMIFA deep links.
- Style drift method (holdings-based style exposures against the agreed style) to agree with 32 at W5.

## 6. SME questions (tailoring levers; reference default in brackets)

1. Sleeves of multi-manager funds, whole funds or both? [Both.] Lever: whole funds only drops the sleeve PORT- reference.
2. Manager research in house or outsourced? [In house.]
3. Manager-of-managers order relied on? [Yes, for unaffiliated sub-advisers.] Lever: no order drops the hire-condition group.
4. Platform curation depth? [Screen for self-directed platform listing; full due diligence for Advice Models, Plan Menus, Fund of Funds and recommended uses.] Lever: full curation of every platform product.
5. Plan menu fiduciary (3(21) or 3(38))? [No; Plan Menus scope optional.]
6. OCIO manager research shares the objects? [Yes, IA line, governed by a 39 contract.]
7. Thresholds per engagement or per strategy type? [Per engagement and metric, stored once with direction and warning band.]
8. Sleeve-level turnover? [No: fund-level turnover from 27.] Lever: a sleeve turnover computed in 32 or 52 from 18 transactions.

## 7. Overlaps with other domains (for consolidation)

- 35 Fund Advisory Agreement.External Sub-Adviser vs Engaged Sub-Adviser: same PTY-; 35 Termination Reason to read the 52 code; interim status read from the 35 agreement type.
- 12 Transition Event: owns the transition; aggregate cost requested.
- 05 Partner Product Due Diligence, 08 Distributor Due Diligence (to 05 at W4), 40 supplier due diligence: CD-060 amendment.
- 37 audit findings vs Oversight Finding: term conflict logged.

## 8. Suggested validation steps

1. Walk one fund hire, one OCIO hire and one retail managed account sleeve hire end to end with Manager Research, the Fund Treasurer and Advice Operations.
2. Rebuild one quarterly scorecard from Oversight Metric Readings and thresholds and confirm each value against its source record.
3. Check 01 Platform Product Availability rows against Product List Status (scope Brokerage Platform) and the screen.
4. Confirm thresholds, directions and CDEs with Investment Compliance and counsel to the independent trustees.
