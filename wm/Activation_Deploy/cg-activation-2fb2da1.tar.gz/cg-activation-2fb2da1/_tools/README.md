# Taxonomy tooling

Each workbook is generated from a content module in `content/`, plus the consolidation layer in `consolidation/` (shared code lists and decisions) and enrichment in `enrichment/`. Enrichment holds the grain, ownership corrections and domain summaries; validate it with `python enrichment/check_enrichment.py NN`.

The hierarchy is L1 Data Domain > L2 Data Family > L3 Data Business Object > L4 Data Business Attribute. Ownership for each attribute is resolved by `ownership.py`. To change a definition, edit the module, never the `.xlsx`, then rebuild.

Requires Python 3 with `openpyxl` (`pip install openpyxl`).

```bash
cd _tools
python taxonomy_builder.py content_03_sales   # rebuild one business domain
python taxonomy_builder.py --all              # rebuild every workbook
python build_index.py                          # rebuild 00_Program/Taxonomy_Index.xlsx
python build_enterprise.py                     # rebuild 00_Program/Enterprise_Data_Taxonomy.xlsx (registers, decisions, term conflicts)
```

**Renamed at Step 5 (CD-150):** the enterprise workbook is `00_Program/Enterprise_Data_Taxonomy.xlsx`. Until Step 5 it was `Enterprise_Distribution_Data_Taxonomy.xlsx`; this note stays for one release as the redirect. The distribution view is a filter, not a separate file: on the Data Domains sheet (and in the Taxonomy Index), set "Distribution View" = Y for Data Domains 01-16, or filter "Area" (from `capability_map/areas.py`) to Distribution & Client plus Foundations.

**Row Ownership Rule (CD-289):** an optional `ROW_OWNERSHIP` dict in `enrichment/enrich_NN.py` gives, per attribute, the rule for which rows are mastered here and which are copied from or owned by another Data Domain. The builders show it in a "Row Ownership Rule" column (Taxonomy tab, Enterprise Attributes, Hierarchy Index). `ownership.py` ignores it, so the flag stays as declared.

The builder validates each module before writing. It checks:
- tuple shapes
- duplicate domain codes and attributes
- CDE values
- that every referenced code list is defined (or is an external format such as ISO or Firm-defined)

Count formulas are computed when the workbook is opened in Excel.

See `../00_Program/Domain_Ownership_and_Conventions.md` for the content-module conventions.

## Data products

`data_products/` holds the data product layer that sits on top of the taxonomy:
- `framework.py`: the business functions, the product register (Waves 1–3) and any unspecified backlog
- `specs_*.py`: attribute-level specifications, written to `data_products/CONTRACT.md`

Every input object and attribute is validated against the consolidated taxonomy.

```bash
python data_products/dp_model.py               # validate all specs (or pass one specs_* module)
python data_products/dp_model.py --catalog data_products/_catalog.txt   # object/attribute list for authoring
python build_data_products.py                  # writes 00_Program/Data_Product_Catalog.xlsx (--draft: specified products only)
```

`build_explorer.py` also adds the data products to the explorer.

**Enterprise functions (CD-291, 2026-10-08):** `framework.FUNCTIONS` is `(code, name, area, capabilities, description, roles, decisions)`. FN-01 to FN-19 are the distribution and plan recordkeeping functions; FN-20 to FN-51 are the enterprise functions of the data products expansion (`00_Program/Data_Products_Expansion_Plan.md`), each with its home area (`capability_map/areas.py`) and the L2 capabilities it runs (`capability_map/content_capabilities.py`). `dp_model.py` checks both and that every capability has a function; a function with no product is a warning until Phase 1 of the expansion closes. Each expansion wave's products are registered in `framework.py` as a `WAVE_E<n>` list before their specs are written (`specs_e<n>_<group>.py`); `IN_PROGRESS` names the waves whose products may still lack a specification, and the validators, catalog and explorer leave those out until the spec lands. A product of an expansion wave that lists the BI semantic model is reported by `sm_model.py` as awaiting its Phase 2 model rather than failing. Wave E0 product briefs live in `00_Program/Expansion/Product_Briefs/`, with their candidate products in `consolidation/proposals_dp_<group>.py`:

```bash
python data_products/candidate_coverage.py proposals_dp_<group>   # one brief's candidates against the taxonomy and the coverage rule
python data_products/candidate_coverage.py --all                  # every brief together (cross-brief upstream names resolve)
```

## Semantic models

`semantic_model/` defines how data products are published to dashboards, Excel and AI assistants: eighteen semantic models (shared dimensions plus seven distribution and ten enterprise subject areas, Wave E9 of the data products expansion), each metric defined once; `register.IN_PROGRESS` names any registered model whose file is still being written. The standard is in `semantic_model/CONTRACT.md`; see `semantic_model/README.md`.

```bash
python semantic_model/sm_model.py               # validate the register and every model (or pass SM-04)
python semantic_model/build_semantic_model.py   # regenerate semantic_model/out/ (drafts, sizing, models as YAML)
```

The output is deterministic: sets are written sorted, so a rebuild with no content change leaves `semantic_model/out/` unchanged (Step 5, CD-290).

`build_explorer.py` publishes the models when they validate.

## Logical data models

`data_models/` holds a logical model for each data product. The standard is in `data_models/CONTRACT.md`. The folder contains:
- `keys.py`, `keys_g*.py` and `keys_e7_*.py`: the shared key and link registry (keys.py for 01-16; `keys_g7/g8/g9` the few expansion objects the distribution products read; `keys_e7_*` every object of 17-44, Wave E7 of the data products expansion). `python data_models/dm_model.py --keys keys_e7_<group>` checks one file with its domains' coverage; `--models models_<module>` checks one models file with a lenient view of conformed sources another author is still writing. It gives each taxonomy object's primary key, whether a group folds into its parent or becomes a child entity, and the target of each reference attribute.
- `models_*.py`: one model per product. Foundational products are normalized (ER); consumer products are star schemas that reuse foundational entities as conformed dimensions.

```bash
python data_models/dm_model.py                 # validate keys and models
python data_models/dm_model.py --conformed     # list foundational entities available as conformed dimensions
python build_data_models.py                    # writes 00_Program/Data_Product_Logical_Models.xlsx
```

`build_explorer.py` adds each model (diagram and entity tables) to its product page.

## Gap register

`consolidation/gaps_register.py` holds the triage register: the gaps found while specifying and modeling the data products, merged into distinct issues. Each issue has a category, change type, priority, decision owner and the products it affects.

```bash
python build_gap_register.py                   # writes 00_Program/Gap_Register.xlsx
```

## Client-facing explorer (local, no hosting)

```bash
python build_explorer.py      # writes 00_Program/Taxonomy_Explorer.html
```

This produces a single self-contained HTML file with the data embedded. Open it by double-clicking. It needs no server or internet connection; fonts fall back to system fonts when offline.

It covers the landscape map (the distribution value chain in columns, with each enterprise expansion stage drawn as a band below it), a page per business domain (drilling down to attributes), the core-entity matrix, the shared code lists, the data products, the semantic models with their metric glossary, and search. The **Guide & method** page (`#/guide`) leads with the taxonomy-to-consumption operating model (data products, semantic layer, direct delivery), followed by the design principles and a key to the explorer's symbols; its counts are computed from the embedded data, so it stays current on rebuild. It deliberately leaves out reviews, decisions and working notes. Edit the page design in `explorer/template.html`.

The **View** switch in the header (or `#/view/ID`, with `#/view/all` for the enterprise view) narrows the whole explorer to one area plus Foundations. The data products page follows the view: products owned by the view's domains, with a switch to add products of other areas that read them. Within each tier the products are grouped by topic (`framework.TOPICS`, with `TOPIC_OF_DOMAIN` and the `PRODUCT_TOPIC` overrides; validated by `dp_model.py`), and the catalog carries a Topic column. `python build_review_pack.py` regenerates the foundational products' review pack from the specs. Each area's home page copy (title, lede, ladder caption, bands intro and the roles in the guide) is data in `explorer/views/view_<ID>.py`, one module per non-band area, validated on every build.

## Brand theme (explorer only)

The explorer carries the KPMG LLP theme from `brand/`:
- `kpmg.css`: colors, type and component tweaks, layered over each page's own styles
- `kpmg-logo.svg`: the header logo

`build_explorer.py` applies it to `00_Program/Taxonomy_Explorer.html`. Pass `--brand none` for an unbranded page. The review app (`review_app/`, published on claude.ai) and the Excel workbooks are kept separate and are not themed.

To theme another page, add `<!--brand:css--><!--/brand:css-->` after its `<style>`, add `<!--brand:logo--><!--/brand:logo-->` where the logo goes, and set `data-app` on `<body>`. Then call `brand.apply(html)` in its build or run `python brand.py FILE.html`. Keep the markers empty in templates.

## Baseline regression check

`check_baseline.py` proves that the protected Data Domains (01–16 at first; every domain merged so far in later baselines) and everything built on them (consolidation registers, data products, logical models, semantic models) are unchanged from the `distribution-v0.4` baseline, except where a logged decision says so. It works in memory from the content modules, consolidation and enrichment; it never reads or writes the `.xlsx` files. It also runs the whole-build validators (taxonomy validation of every content module, `check_enrichment.py`, `dp_model.py`, `dm_model.py`, `sm_model.py`) and fails if any fails or any domain has an unresolved reference.

```bash
python check_baseline.py --snapshot             # write baseline/distribution-v0.4.json (pass a name for another baseline)
python check_baseline.py                        # compare to the baseline (same as --check distribution-v0.4)
python check_baseline.py --allow CD-101,CD-102  # also state the decisions the differences must trace to
python check_baseline.py --check stage1-v0.1     # compare to the baseline taken after the Stage 1 consolidation
python check_baseline.py --check stage2-v0.1     # compare to the baseline taken after the Stage 2 consolidation (01-30)
python check_baseline.py --check stage3-v0.1     # compare to the baseline taken after the Stage 3 consolidation (01-36)
python check_baseline.py --check stage4-v0.1     # compare to the baseline taken after the Stage 4 consolidation (01-44)
python check_baseline.py --check wholesale-v1.0  # compare to the complete wholesale model (01-44, all four layers)
```

Step 5 (consolidation across all 44 domains: CD-150 and CD-286 to CD-290) is reconciled against `stage4-v0.1` in `consolidation/step5_consolidation_notes.md` §7: `python check_baseline.py --check stage4-v0.1 --allow CD-150,CD-286,CD-287,CD-288,CD-289,CD-290`. The program lead takes the next snapshot.

Nine baselines are kept. `wholesale-v1.0` is the complete wholesale reference model (44 Data Domains, 238 products, 238 logical models, 18 semantic models; 2026-10-14, git tag `wholesale-v1.0`), taken before the wealth-manager sibling was cut, and is the reference for the wealth-manager branch (below). `products-phase2-v0.1` is the catalog, logical models and semantic layer at the end of Phase 2 of the data products expansion. `products-phase1-v0.1` is the state at the end of Phase 1 of the data products expansion (238 specified products, 51 functions, 270 decisions; 2026-10-08) and is the reference for Phase 2. `enterprise-v0.9` is the Step 5 state (all 44 Data Domains, the 96 products, 96 models and 8 semantic models) and is the reference for the data products expansion: added products, functions, logical models and semantic metrics are reported as expansion additions, not differences, while removals and changes to existing entries must trace to a decision. `distribution-v0.4` is the frozen distribution taxonomy. `stage1-v0.1` was taken after the Stage 1 consolidation (Data Domains 17-21 merged; CD-151, CD-152, CD-156, CD-158, CD-163 and CD-166 applied to 01-16); its reconciliation is in `consolidation/stage1_consolidation_notes.md`. `stage2-v0.1` was taken after the Stage 2 consolidation (Data Domains 22-30 merged; the Stage 2 decisions applied to 01-21); its reconciliation is in `consolidation/stage2_consolidation_notes.md`. `stage3-v0.1` was taken after the Stage 3 consolidation (Data Domains 31-36 merged; the Stage 3 decisions applied to 01-30); its reconciliation is in `consolidation/stage3_consolidation_notes.md`. `stage4-v0.1` was taken after the Stage 4 consolidation (Data Domains 37-44 merged; the Stage 4 decisions applied to 01-36); its reconciliation is in `consolidation/stage4_consolidation_notes.md`. Drafting is complete; taxonomy changes are checked against `stage4-v0.1` and the products expansion against `enterprise-v0.9`.

Which domains a baseline protects is recorded in its `meta.domains`. `distribution-v0.4` and `stage1-v0.1` protect 01-16. A new snapshot (`--snapshot NAME`, any name other than distribution-v0.4) protects every content module that exists when it is taken: `stage2-v0.1` protects 01-30, `stage3-v0.1` protects 01-36, and `stage4-v0.1`, `enterprise-v0.9`, the products baselines and `wholesale-v1.0` protect 01-44. Protected domains are compared in full. Domains that a baseline recorded only by counts (17-21 in stage1-v0.1) are compared on those counts, and a change fails the check. Domains newer than the baseline are expansion additions.

The check prints the differences by Data Domain (count changes, objects added or removed, changed attributes, ownership, grain, code lists or relationships), then the registers, data products, logical models and semantic models. It exits 1 on any difference and 0 when everything matches. `--allow` only annotates the report; it never suppresses a difference. Run it after each expansion stage is merged, and log every difference as a `CD-` decision. Content modules outside the baseline's protected domains are validated but not compared. They are listed under "Expansion additions (not failures)", together with any new register entry (prefix, concept owner, decision, term conflict or shared code list) that names only unprotected Data Domains. A register entry that is removed or changed, or a new one that names a protected domain, still fails the check.

The Data Domain numbers, names and two-letter codes (01–52) are defined once in `domains.py`. `taxonomy_builder.py`, `ownership.py`, `enrichment/check_enrichment.py`, the data product validator and `capability_map/areas.py` all read them from there.

## Wealth-manager sibling (branch feature/wealth-manager)

The repository on branch `feature/wealth-manager` is a second reference model, for a US direct-to-investor wealth manager that also manufactures funds (Vanguard type, hypothetical firm). It is cut from git tag `wholesale-v1.0`, where the wholesale model stays frozen; the plan is `00_Program/Wealth_Manager_Rework_Plan.md` and the framing decisions are CW-001 to CW-020 (`consolidation/proposals_wealth_w0.py`, merged into `decisions.py`).

- **The siblings are never merged.** A shared-foundation fix found on one side is cherry-picked to the other, with a decision on each side (CW-001). Compare the branch with the wholesale model on demand with `python check_baseline.py --check wholesale-v1.0`.
- **Identifier series (CW-002).** Decisions: `CW-001` onward; the inherited `CD-` entries are the record of the shared foundation and are never renumbered or edited (`decisions.MODEL = "wealth"`). Products: retired `DP-` numbers stay retired and new products start at `DP-300`. Semantic models: new models start at `SM-20`. Functions: new functions start at `FN-60`. ID prefixes: one register for both siblings; a prefix used by either is never reused by the other. Data Domain numbers 07 and 30 are retired and never reused; new domains start at 45.
- **Domain register.** `domains.py` registers 45-52 and holds `DISPOSITION` (keep, adapt, replace, retire or new, with the target name, for all 52), `DISPOSITION_DECISION` (the W0 decision behind each), `RETIRED_DOMAINS` (number -> retiring decision; empty at W0, 07 and 30 added at W4), `REPLACEMENT_L1_CODE` (02 HH, 03 AO, 05 DI, 08 RC, applied at their stage) and `WEALTH_DOMAINS` (every non-retired domain). `WHOLESALE_DOMAINS`, `DISTRIBUTION_DOMAINS` and `EXPANSION_DOMAINS` are unchanged in meaning.
- **Areas (CW-018).** `capability_map/areas.py` has seven areas and the Foundations band: Investment, Investment Operations, Fund Operations, Client & Advice, Brokerage & Workplace Operations, Distribution, Channels & Client Economics, Corporate Functions, Foundations. `RETIRED_AREAS` is the mechanism for a wholesale area id a register still cites; it has been empty since the W0 function re-pointing retired `DCL`.
- **Jurisdiction register (CW-003).** `consolidation/jurisdiction.py` records every EU/UK object, attribute, code value and source the US-only pass removes (`REMOVALS`: domain, object, attribute, regime, decision, note), so a UK extension can be restored from the sibling object by object. `CHECKLIST` is the drafters' remove / keep table. Format in `consolidation/CONTRACT.md`.
- **Baseline check on the branch (CW-019).** Carried domains are compared in full. A domain with disposition `replace` is reported as "Data Domain NN replaced (counts only; CW-nnn)" and compared by counts only once its module name differs from the baseline's or its object or attribute count moves by more than 50 percent; `--replaced NN,NN` forces this for a replacement that kept the module name and size. A domain in `RETIRED_DOMAINS` is reported as "retired by CW-nnn", not as a removal. Domains absent from the baseline (45-52) are expansion additions. New CW- decisions, term conflicts carrying a CW- `decision`, and any new register entry that names 45-52 are listed under "Wealth-model additions (not failures)"; a change to or removal of an existing entry still fails. `wholesale-v1.0` is the comparison baseline until `wealth-taxonomy-v0.1` is taken at W5.

```bash
python check_baseline.py --check wholesale-v1.0                 # the branch against the wholesale model
python check_baseline.py --check wholesale-v1.0 --replaced 15   # compare 15 by counts only, as a replaced domain
```

### Products pending WP0 re-scope (CW-041)

At the W1 merge the wholesale consumer products are held out rather than re-pointed to the replaced 02 and 15. `framework.RESCOPE_PENDING` lists every Consumer-aligned product of Waves 1 to 4 (79 products); `semantic_model/register.PENDING` lists SM-02 to SM-06 (SM-01 and SM-07 stay live: they own the certified flow, AUM and fee-revenue metrics until WP0 re-homes them). Their specs, logical models and semantic model files stay in place but are not validated, built, counted or published: the catalog shows a "Pending re-scope (WP0)" row, the explorer a collapsed group, and `check_baseline.py` a "Pending WP0 re-scope (not failures; CW-041)" section. The foundational products of those waves and every Wave E1 to E5 product stay live. The validators report each live dependency on a pending product as a warning until WP0, with a count on every run ("live product X depends on pending product Y; re-point at WP0; CW-041"); a live semantic model that reads a metric defined in a pending model is an error. WP0 empties both registers.
