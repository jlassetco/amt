# Source-to-semantic activation

A running demonstration of the operating model's first link: map a source system to the taxonomy, and the data
products and the semantic layer above it switch on. One slice (`config.SLICE`: SM-20 Client Assets & Flows, the
household tables of SM-21 Client & Household 360, the relationship-health tables of SM-27 Intermediary &
Institutional and the fee, billing, cost-to-serve and profitability tables of SM-28 Client Economics), eight
synthetic source systems, and every layer generated from the model except the confirmed mappings, the firm rules of
the certified family and the SQL of the metrics whose model text is a sentence. Section 11 of `00_Program/Data_Products_Approach.md` is the write-up; the rulings are
decisions CW-275 to CW-280.

## Run it

```bash
cd _tools
python3 -m venv activation/.venv && activation/.venv/bin/pip install duckdb pyyaml anthropic mcp openpyxl   # once (Python 3.10+)
activation/.venv/bin/python activation/compile/build_all.py        # about 45 s: sources -> slice -> mappings -> physical -> derived -> proof -> semantic -> tests -> states
activation/.venv/bin/python activation/serve/query.py --list       # the metrics and whether each answers
activation/.venv/bin/python activation/serve/query.py "Net New Assets" --by client_assets_flows.dimension_key --dimension-type Channel --period 2026-Q3
activation/.venv/bin/python activation/serve/query.py "Client Assets" --by distribution_channel.channel_name
activation/.venv/bin/python activation/compile/export_dbt.py       # dbt Semantic Layer YAML under activation/out/dbt/
activation/.venv/bin/python activation/mapping/propose.py SRC-BRK --baseline --eval   # the mapping assistant (--assistant ollama|anthropic|baseline; default the configured model)
activation/.venv/bin/python activation/serve/mcp_server.py --selftest                 # the assistant's tools; .mcp.json registers the server for Claude Code
activation/.venv/bin/python activation/demo/build_demo.py          # writes 00_Program/Activation_Demo.html
```

Everything under `activation/out/` and the demo page are generated (gitignored). `/usr/bin/python3` (3.9) runs the
generator and the repo's validators; the venv runs the compiler, because DuckDB and the MCP package need 3.10+.

## Layout

| Folder | What | Hand-written |
|---|---|---|
| `config.py`, `slice.py` | The slice: which semantic models to activate, resolved to tables, entities, columns, metrics and questions (`out/slice.json`) | config only |
| `sources/` | `schema.py`: the eight source systems' tables, columns and vocabularies (their data dictionaries): a brokerage clearing platform, a CRM in Salesforce FSC shape, a transfer agent fund register, an institutional client system, a portfolio accounting book of record, an advisory fee billing engine, a revenue sub-ledger and a cost allocation engine. `generate.py`: the synthetic firm and `truths.json`, the certified figures computed independently (`GENERATOR_BRIEF.md`, `GENERATOR_BRIEF_INSTITUTIONAL.md` and `GENERATOR_BRIEF_ECONOMICS.md` are its specification) | schema, generator |
| `mapping/` | `CONTRACT.md` (the registry standard), `map_brokerage.py`, `map_crm.py`, `map_ta.py`, `map_inst.py`, `map_pab.py`, `map_bil.py`, `map_rev.py`, `map_cst.py` (the confirmed mappings: 606 rows, 418 taxonomy attributes, the declared gaps), `check_mapping.py` (validation and coverage), `propose.py` (the AI mapping assistant and its evaluation against the confirmed modules) | the eight mappings |
| `compile/` | `physical.py` (mapping rows to conformed DuckDB tables, keys minted and resolved; `transforms.py` holds the row shapes and the derivations whose mapping text is prose), `derivations.py` (DP-013, DP-192, DP-006, DP-007, DP-008, DP-320, DP-495 by firm rules), `check_truths.py` (the proof), `semantic.py` (views, joins, metrics proven by execution; `expressions.py` is the executable form of the models' prose), `tests.py` (generated data-quality tests), `export_dbt.py`, `coverage.py` (activation states), `build_all.py` | transforms, derivations, expressions |
| `serve/` | `query.py` (the engine: metric, breakdowns, filters, period; lineage back to the taxonomy), `mcp_server.py` (list_metrics, describe, query, coverage, cannot_answer, ask), `llm.py` (the model provider: Claude, a local model on Ollama, or none) | none |
| `demo/` | `build_demo.py`: the self-contained demo page (Map, Compile, Ask) | none |

## What the build proves

- `check_truths.py`: every DP-008 measure row (504), every household row (300), every institutional relationship's client assets and at-risk flag (48), every profitability and cost-to-serve row (336 and 360), every fee run and 48 planted facts match the generator's independent computation to the cent.
- The client-economics wave (SM-28): the billing engine, revenue sub-ledger and allocation engine map to DP-305, DP-012 and DP-480; the compiler derives the billing re-performance test (DP-346: every released calculation re-performed on the schedule version its assignment names, off-schedule and household-breakpoint findings), cost to serve (DP-498) and profitability (DP-499: client revenue plus own-fund fee revenue attributed by own-fund holdings, less distribution, marketing and allocated cost) by firm rules. 44 SM-28 metrics answer; the demo questions cover fee revenue and the effective fee rate by offering over four quarters, the failed fee runs and off-schedule accounts of the quarter, the offerings and segments with negative contribution, and cost to serve by segment. Fiscal periods are codes (FYyyyy-Mmm) on the revenue, allocation and profitability facts, which the engine turns into the months a period spans.
- The institutional question the demo is built to answer, "How much of our AUM with public pension plans sits with clients whose relationship is at risk?", runs on the full basis: fund-held assets from the transfer agent (institutional fund accounts) plus separate-account and OCIO mandates valued from the portfolio book of record, attributed to the client's service relationships (DP-510 Fact Attributed Client Assets and Fact Relationship Health) and cut by the latest health score. SM-27's Relationship Client Assets, At-Risk Relationships and At-Risk Relationship Client Assets are the metrics; the plan the assistant runs is a filter (`institutional_client.institutional_client_type = 'Public Pension Plan'`) on the metric, so a plan may now carry filters on dimension values as well as breakdowns.
- `semantic.py`: 43 of 45 semantic tables compile to views, 44 of 46 joins execute, 32 of 38 in-scope metrics answer; each one that does not names its reason.
- `tests.py`: about 400 generated tests; the three planted gaps are caught (option positions with no holding type, the register's cash dividend code, the proposed customer-number scheme).
- The repo's own validators and `check_baseline.py --check wealth-v1.0` are unchanged: the activation adds, it does not change the model.

## Deploying to EC2 (the demo's end state)

`deploy/` packages the tracked tree, installs it on an EC2 instance behind nginx with basic auth, builds the DuckDB
slice and runs the web app as a systemd service with Claude through the Anthropic API; the key is read from SSM
Parameter Store by the instance role at start. `deploy/README.md` is the runbook; `deploy/cloudformation.yaml` is the
one-stack version.

## Tailoring levers

The slice (any models in `config.SLICE`, narrowed by `config.TABLES`), the sources (a client's dictionaries in `sources/schema.py` and extracts in `out/sources/`), the runtime (DuckDB locally; the generated SQL ports to a warehouse), the semantic engine export (dbt; others are adapters over `out/compiled_model.json`), the assistant (Claude through MCP; any model behind the same tools).

## Runtimes: DuckDB and local Spark (Databricks shape)

`compile/runtime.py` is the one place that knows the engine. `--runtime duckdb` (the default) is the fast reference;
`--runtime spark` builds the same layers on local Spark with Delta Lake, laid out as a Databricks workspace is:
`bronze` (the extracts as landed), `silver` (the conformed foundational products and the books-of-record derivations),
`gold` (the certified family, the consumer facts, the helper tables and the semantic views), with a persistent catalog
(a Hive metastore in a local Derby database under `out/spark/`). The exported Databricks assets (`compile/export_databricks.py`:
Unity Catalog metric views, semantic view DDL, notebooks, an asset bundle) carry the `wealth` catalog name in front.

```bash
activation/.venv/bin/python activation/compile/build_all.py --runtime spark    # bronze -> silver -> gold on Spark; the proof runs on Spark too
```

Spark needs a JDK: `activation/.jdk/` holds a Temurin 17 (gitignored; `JAVA_HOME` is read from `activation/.jdk/JAVA_HOME`).
PySpark 3.5 does not support Python 3.14's serializer, so the Spark path avoids DataFrame creation from Python rows;
on a machine with Python 3.11 or 3.12 that constraint goes away. Spark local mode on an 8 GB laptop takes about
8 minutes for the physical layer and 6 for the derivations; the DuckDB path takes under a minute.

## Moving the demo to a server

The stack is a folder plus three local dependencies, so the move is: copy the repository, create the virtual
environment with Python 3.11 or 3.12 (`pip install duckdb pyyaml anthropic mcp openpyxl pyspark==3.5.3 delta-spark==3.2.1`),
unpack a Temurin 17 JDK into `activation/.jdk/` (or set `JAVA_HOME`), raise `config.SPARK_CORES` and
`config.SPARK_DRIVER_MEMORY` to the machine, run `build_all.py --runtime spark`, and start the web app bound to the
LAN address. The GPU is not used by Spark SQL; it is what makes a local model server (Ollama or vLLM) practical, which
can take the place of Claude for the mapping assistant and the question router so that nothing leaves the machine.

## The assistant on a local model

`serve/llm.py` picks the model behind the mapping assistant and the question router: `ACTIVATION_LLM=anthropic|ollama|none`
when set; otherwise Ollama when `ACTIVATION_OLLAMA_URL` is set, Claude when a Claude credential is set, Ollama when
`http://127.0.0.1:11434` answers, else none (the deterministic paths). `ACTIVATION_OLLAMA_MODEL` (default `qwen3:4b`) and
`ACTIVATION_OLLAMA_CTX` (at most 8192) size the local model. Calls are kept small for a 4 GB GPU: no thinking,
temperature 0, the answer constrained to a JSON schema whose enums hold the only valid targets, metric names and code
values. The proposer sends one call per chunk of at most 8 columns with the chunk's top 6 candidate objects, and a
second call for the code values of the columns it marks crosswalk; `ask` sends one call that turns the question into a
query plan (metric, breakdown, period, dimension type, or decline) and runs it here. A failed call, a declined plan or a
plan that does not run falls back to the deterministic path, and the answer says which assistant answered.

```bash
ssh -N -L 11434:127.0.0.1:11434 <gpu-server> &                     # when Ollama runs on another machine
ACTIVATION_LLM=ollama activation/.venv/bin/python activation/mapping/propose.py SRC-BRK --assistant ollama --eval
ACTIVATION_LLM=ollama activation/.venv/bin/python activation/serve/mcp_server.py --selftest "How many funded accounts does each channel have?"
```

## Claude Code as the assistant (a subscription, no API key)

`serve/llm.py` has a third provider, `claudecode`: Claude Code installed on the machine that serves the app, logged in
once with the user's subscription (`claude auth login`), run headless per question (`claude -p` with `--json-schema`)
with the activation MCP server attached through `--mcp-config` and `--strict-mcp-config`. Claude plans and runs the
tools itself (list_metrics, describe, query, cannot_answer) and returns a structured result: the answer, the query
calls behind it, the parts the model declines and the model ids used. The app re-runs the cited queries so the page
shows the same rows and lineage it shows for the other assistants. The MCP server a Claude Code session launches runs
on the DuckDB build (the Spark metastore is single-process), which holds the same figures. Selection:
`ACTIVATION_LLM=claudecode` in the service unit, with the CLI on the unit's `PATH`; when the CLI is missing or not
logged in, the local model (Ollama) stands in. Demo questions keep their verified plans and never go to a model.
Expect 10 to 60 seconds per question; the usage counts against the subscription's windows. This is the user's own use
of their subscription through the official client; an application serving other people needs the API provider.

## The local model and its speed

The assistant runs on Ollama with `qwen3:4b` when `ACTIVATION_LLM=ollama` (see `serve/llm.py`). On the server's 4 GB
card the model answers a question in 3 to 4 seconds and maps a source in 2.5 to 4 minutes. What makes it that fast:
Ollama runs with flash attention, an 8-bit KV cache and a 30-minute keep-alive (`/etc/systemd/system/ollama.service.d/override.conf`),
the context is 4k (`ACTIVATION_OLLAMA_CTX=4096`), and the proposals are precomputed and cached per source and data
dictionary (`app/server.py --precompute local`, cache files under `out/proposals/`; the page shows "cached" with a
"Run again live" button). `mapping/propose.py` can pack the prompt per chunk (`LOCAL_PACK = "chunk"`, the default,
best quality) or once per table so the model server reuses its cached prefix (`"table"`, fastest, lower precision).
The output size, not the prompt, sets the time: the model writes about 60 tokens per column at 35 to 45 tokens per second.
