"""Puts the repo's tooling on sys.path so the activation modules can import the taxonomy, product, model and semantic
layers exactly as their own validators do. Import this first in every activation module."""
import os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.dirname(HERE)
OUT = os.path.join(HERE, "out")
for p in (TOOLS, HERE, os.path.join(TOOLS, "semantic_model"), os.path.join(TOOLS, "semantic_model", "models"),
          os.path.join(TOOLS, "data_models"), os.path.join(TOOLS, "data_products"), os.path.join(TOOLS, "consolidation"),
          os.path.join(TOOLS, "content")):
    if p not in sys.path:
        sys.path.insert(0, p)
sys.dont_write_bytecode = True
os.makedirs(OUT, exist_ok=True)
