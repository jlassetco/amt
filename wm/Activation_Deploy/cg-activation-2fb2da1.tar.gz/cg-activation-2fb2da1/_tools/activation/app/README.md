# Live demo web app

The source-to-semantic activation as a five-step workspace for a client session: **Sources** (the three systems as
they land), **Map** (the mapping assistant's proposal, the steward's confirmed mapping, the coverage it switches on),
**Build** (the compile steps with a live log and the layer diagram), **Products** (activation states, rows and lineage
back to the source columns) and **Ask** (questions answered with SQL and lineage, or declined with the gap; a SQL
editor over the catalog). No internet and no API key are needed.

## Run it

```bash
cd _tools
activation/.venv/bin/python activation/app/server.py --runtime duckdb                 # http://localhost:8765/
activation/.venv/bin/python activation/app/server.py --runtime spark                  # local Spark with Delta: bronze, silver, gold
activation/.venv/bin/python activation/app/server.py --runtime spark --host 0.0.0.0   # a LAN server: browse to http://<machine>:8765/
```

The server opens one runtime for its lifetime (Spark takes about 5 s to start) and holds it until stopped (Ctrl+C).
Run `activation/compile/build_all.py` once first so the extracts, `out/slice.json` and the mappings' coverage exist;
the Build step then reruns the compile steps in the server. On DuckDB a full build takes about 6 s in the server;
on Spark the physical layer takes about 8 minutes and the derivations about 6, so on Spark build ahead of the session
and use the Build step to show single steps (semantic, tests, coverage take seconds).

## What it is

| File | What |
|---|---|
| `server.py` | `http.server` with a JSON API; standard library only. Every response is `{"ok": true, ...}` or `{"ok": false, "error": ...}`. Handlers are plain functions over the runtime (`compile/runtime.py`), the mapping modules (`mapping/`), the query engine and the assistant's tools (`serve/`) and the generated reports. |
| `index.html` | The single page: inline CSS and JS, no external scripts. The server applies the KPMG theme (`_tools/brand.py`) when it serves it. |

API: `GET /api/state`; `GET /api/sources`, `/api/sources/{sid}/{table}?limit&offset`, `/api/sources/{sid}/dictionary`;
`POST /api/map/propose {source, assistant}`, `GET /api/map/confirmed/{sid}`, `POST /api/map/check`;
`POST /api/build {steps}` (409 while one runs), `GET /api/build/log?since=N`, `GET /api/build/status`;
`GET /api/products`, `/api/products/{pid}/{entity}?limit&offset`; `GET /api/metrics`, `/api/metrics/{name}`,
`POST /api/query {metric, by, filters, period, dimension_type}`, `POST /api/ask {question}`, `GET /api/questions`;
`POST /api/sql {sql}` (one read-only SELECT or WITH, at most 500 rows), `GET /api/catalog`.

Notes:
- The mapping assistant and the question router use Claude only when `ANTHROPIC_API_KEY` is set; otherwise the
  deterministic baseline proposer and router answer, and the page says so.
- The SQL tab is labeled "Databricks SQL (local Spark)" on Spark: the tables are the `bronze`, `silver` and `gold`
  schemas of the local metastore (the exported Databricks assets put the `wealth` catalog in front). DuckDB-flavored
  names (`src_brk."ACCT_MASTER"`, `dp_093.account`) are translated on Spark.
- Only one build runs at a time; the build's printed output goes to the log the page polls.
- The server marks pandas, numpy, pyarrow and polars as absent when they are not installed: DuckDB's Python client
  otherwise attempts the import for every bound parameter, which made the derivations step about ten times slower.
