"""The live demo web app of the source-to-semantic activation: a local HTTP server with a JSON API over the runtime and
the generated reports, and a single-page UI (index.html) that walks Sources, Map, Build, Products and Ask.

Usage (from _tools/):
  activation/.venv/bin/python activation/app/server.py --runtime duckdb|spark [--host 127.0.0.1] [--port 8765]
  --host 0.0.0.0 serves the LAN. The server opens one runtime for its lifetime; a build runs in a background thread.

Standard library only (http.server, threading, json, csv); every response is {"ok": true, ...} or {"ok": false, "error": ...}.
"""
import argparse, csv, datetime, decimal, hashlib, json, os, re, sys, threading, time, traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, unquote, urlparse

APP = os.path.dirname(os.path.abspath(__file__))
ACT = os.path.dirname(APP)
TOOLS = os.path.dirname(ACT)
for p in (os.path.join(ACT, "sources"), os.path.join(ACT, "mapping"), os.path.join(ACT, "serve"), os.path.join(ACT, "compile"), ACT, TOOLS):
    if p not in sys.path:
        sys.path.insert(0, p)
import _paths  # noqa: E402,F401
import config  # noqa: E402
import runtime  # noqa: E402
from schema import SOURCES  # noqa: E402

OUT = os.path.join(ACT, "out")
SRC_DIR = os.path.join(OUT, "sources")
ROW_CAP = 500
STEPS = ["physical", "derivations", "check_truths", "semantic", "tests", "coverage"]
STEP_LABELS = {"physical": "Build the conformed products", "derivations": "Derive the products by firm rules",
               "check_truths": "Prove the certified figures", "semantic": "Compile the semantic layer",
               "tests": "Run the generated tests", "coverage": "Write the activation states"}
RT = None                       # the runtime, opened once in main()
LOCK = threading.RLock()        # serializes DuckDB access across request threads and the build thread
CACHE = {}
BUILD = dict(running=False, lines=[], started=None, finished=None, steps=[], done=[], current=None, results={}, error=None,
             verdict=None, thread=None)


class ApiError(Exception):
    def __init__(self, status, msg):
        super().__init__(msg); self.status = status


# ---------------------------------------------------------------------------------------------------- runtime helpers
def open_runtime(name):
    # DuckDB's Python client tries `import pandas` (and friends) for every bound parameter; when they are not installed
    # each failed import walks sys.path, which made insert_rows ten times slower in this process. Mark them absent.
    import importlib.util
    for m in ("pandas", "numpy", "pyarrow", "polars"):
        if m not in sys.modules and importlib.util.find_spec(m) is None:
            sys.modules[m] = None
    rt = runtime.get(name)
    if rt.name == "duckdb":               # one DuckDB connection shared by the request threads and the build thread
        for m in ("exec", "fetch", "fetchone", "scalar", "columns", "select_columns", "table_exists", "create_table",
                  "create_table_as", "create_view", "insert_select", "insert_rows", "load_csv", "stage", "count",
                  "replace_from_select"):
            f = getattr(rt, m)
            def locked(*a, _f=f, **kw):
                with LOCK:
                    return _f(*a, **kw)
            setattr(rt, m, locked)
    return rt


def jsonable(v):
    if isinstance(v, decimal.Decimal):
        return float(v)
    if isinstance(v, (datetime.date, datetime.datetime)):
        return v.isoformat()
    if isinstance(v, bytes):
        return v.hex()
    if isinstance(v, float) and v != v:
        return None
    return str(v)


def dumps(obj):
    return json.dumps(obj, default=jsonable, ensure_ascii=False)


def load_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def out_json(name):
    """A generated file of the runtime (activation.json, compiled_model.json, ...) or None."""
    return load_json(os.path.join(RT.out, name))


def layer_of(table):
    """bronze, silver or gold on Spark (the schema), None on DuckDB."""
    return table.split(".")[0] if RT.name == "spark" else None


def safe_exists(table):
    try:
        return RT.table_exists(table)
    except Exception:
        return False


def table_rows(table, limit, offset=0):
    sql = f"select * from {table} limit {int(limit)} offset {int(offset)}" if RT.name == "duckdb" else \
          f"select * from {table} limit {int(offset) + int(limit)}"
    rows = RT.fetch(sql)[int(offset):] if RT.name == "spark" else RT.fetch(sql)
    return RT.columns(table), [list(r) for r in rows]


def count_rows(table, report_count=None):
    """Live count on DuckDB (cheap); on Spark the reports' counts, so nothing scans."""
    if RT.name == "spark" and report_count is not None:
        return report_count
    try:
        return RT.count(table)
    except Exception:
        return report_count


def warm():
    """Fills the products and catalog caches in the background (the first Spark reads take seconds)."""
    def run():
        for f in (api_products, api_catalog):
            try:
                f({}, {})
            except Exception:
                pass
    threading.Thread(target=run, daemon=True, name="warm").start()


def reset_caches():
    CACHE.clear()
    try:
        import mcp_server
        mcp_server._CACHE.clear()
    except Exception:
        pass


# ---------------------------------------------------------------------------------------------------------- state
def api_state(q, body):
    files = {f: os.path.exists(os.path.join(RT.out, f)) for f in
             ("physical_report.json", "derivation_report.json", "compiled_model.json", "test_results.json", "activation.json")}
    files.update({f: os.path.exists(os.path.join(OUT, f)) for f in ("slice.json", "coverage.json")})
    files["sources"] = os.path.exists(os.path.join(SRC_DIR, "truths.json"))
    act = out_json("activation.json")
    try:
        import llm
        assistant = llm.describe(llm.get())
    except Exception as e:
        assistant = dict(kind="none", name="none", label=f"no model ({type(e).__name__})", model=None, available=False)
    return dict(runtime=RT.name, runtime_label="Local Spark with Delta Lake (bronze, silver, gold)" if RT.name == "spark" else "DuckDB",
                as_of=config.AS_OF, slice=config.SLICE, catalog=config.CATALOG, build_running=BUILD["running"],
                summary=act["summary"] if act else None, files=files, assistant=assistant,
                layers=["bronze", "silver", "gold"] if RT.name == "spark" else ["sources", "conformed", "derived", "semantic"],
                steps=[dict(id=s, label=STEP_LABELS[s]) for s in STEPS])


# -------------------------------------------------------------------------------------------------------- sources
def csv_path(sid, table):
    if sid not in SOURCES or table not in SOURCES[sid]["tables"]:
        raise ApiError(404, f"no source table {sid}/{table}")
    return os.path.join(SRC_DIR, sid, f"{table}.csv")


def csv_count(path):
    key = ("csvcount", path)
    if key not in CACHE:
        try:
            with open(path, newline="", encoding="utf-8") as f:
                CACHE[key] = max(0, sum(1 for _ in csv.reader(f)) - 1)
        except OSError:
            CACHE[key] = None
    return CACHE[key]


def api_sources(q, body):
    phys = out_json("physical_report.json") or {}
    systems = []
    for sid, s in SOURCES.items():
        tables = []
        for t, d in s["tables"].items():
            name = RT.src(sid, t)
            loaded = safe_exists(name)
            rows = count_rows(name, phys.get("sources", {}).get(f"{sid}/{t}")) if loaded else csv_count(csv_path(sid, t))
            tables.append(dict(name=t, physical=name, layer=layer_of(name) if loaded else None, loaded=loaded,
                               description=d["description"], grain=d["grain"], keys=d["keys"], volume=d.get("volume", ""),
                               columns=len(d["columns"]), rows=rows, rows_from="runtime" if loaded else "extract"))
        systems.append(dict(id=sid, name=s["name"], kind=s["kind"], shape=s["shape"], note=s["note"], tables=tables))
    return dict(systems=systems)


def api_source_table(q, body, sid, table):
    sid, table = unquote(sid), unquote(table)
    path = csv_path(sid, table)
    limit = min(int(q.get("limit", 50)), ROW_CAP); offset = max(0, int(q.get("offset", 0)))
    name = RT.src(sid, table)
    d = SOURCES[sid]["tables"][table]
    meta = dict(source=sid, table=table, description=d["description"], grain=d["grain"], keys=d["keys"],
                dictionary=[dict(name=c[0], type=c[1], description=c[2], example=c[3]) for c in d["columns"]])
    if safe_exists(name):
        cols, rows = table_rows(name, limit, offset)
        phys = out_json("physical_report.json") or {}
        return dict(meta, physical=name, layer=layer_of(name), origin="runtime", columns=cols, rows=rows, offset=offset,
                    limit=limit, total=count_rows(name, phys.get("sources", {}).get(f"{sid}/{table}")))
    with open(path, newline="", encoding="utf-8") as f:
        r = csv.reader(f)
        cols = next(r, [])
        rows = []
        for i, row in enumerate(r):
            if i >= offset + limit:
                break
            if i >= offset:
                rows.append(row)
    return dict(meta, physical=None, layer=None, origin="extract", columns=cols, rows=rows, offset=offset, limit=limit,
                total=csv_count(path))


def api_source_dictionary(q, body, sid):
    sid = unquote(sid)
    path = os.path.join(SRC_DIR, sid, "_dictionary.csv")
    if sid not in SOURCES:
        raise ApiError(404, f"no source {sid}")
    if not os.path.exists(path):
        import schema
        rows = [list(r) for r in schema.dictionary_rows(sid)]
        return dict(source=sid, columns=["table", "column", "type", "description", "example", "table_grain"], rows=rows)
    with open(path, newline="", encoding="utf-8") as f:
        r = csv.reader(f)
        cols = next(r, [])
        return dict(source=sid, columns=cols, rows=[row for row in r])


# ------------------------------------------------------------------------------------------------------------ map
def mapping_modules():
    import check_mapping as cm
    if "mods" not in CACHE:
        CACHE["mods"] = cm.load_mappings()
    return CACHE["mods"]


def taxonomy():
    import propose
    if "tx" not in CACHE:
        CACHE["tx"] = propose.Taxonomy()
    return CACHE["tx"]


def tgt(t):
    return dict(domain=t[0], object=t[1], attribute=t[2] if len(t) > 2 else None)


def api_map_propose(q, body):
    """assistant: "local" (Ollama), "claude", "baseline", or true for the configured provider. The answer names the
    assistant that ran, its timing, and the baseline's evaluation beside the assistant's."""
    import propose
    sid = body.get("source")
    if sid not in SOURCES:
        raise ApiError(400, f"source must be one of {sorted(SOURCES)}")
    t0 = time.time()
    tx = taxonomy()
    want = body.get("assistant")
    has_key = bool(os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"))
    want = {"local": "ollama", "claude": "anthropic" if has_key else "claudecode", "baseline": "baseline"}.get(want) if isinstance(want, str) else (None if want else "baseline")
    if isinstance(body.get("assistant"), str) and want is None:
        raise ApiError(400, "assistant must be local, claude or baseline")
    # a proposal is a pure function of the dictionary, the assistant and the tables: keep it, and re-run only on request
    from schema import dictionary_rows
    setup = [propose.LOCAL_PACK, propose.CHUNK, propose.LOCAL_OBJECTS, propose.LOCAL_VALUES, propose.LOCAL_EXTRAS, proposer_model(want)]
    digest = hashlib.sha256(json.dumps([dictionary_rows(sid), body.get("tables"), setup], default=str).encode()).hexdigest()[:12]
    cache_path = os.path.join(propose.OUT_DIR, f"cache_{sid}_{want or 'auto'}_{digest}.json")
    if not body.get("force") and os.path.exists(cache_path):
        d = json.load(open(cache_path)); d["cached"] = True
        return d
    prop = propose.propose(tx, sid, body.get("tables"), assistant=want)
    rows = []
    for t, c, g, k, d in prop["attributes"]:
        conf, why = prop["confidence"].get((t, c, tuple(g)), (None, ""))
        inv = prop["invalid"].get((t, c, tuple(g)))
        rows.append(dict(table=t, column=c, target=tgt(g), kind=k, detail=d, confidence=conf, rationale=why, invalid=inv or []))
    confirmed = mapping_modules().get(sid)
    ev = propose.evaluate(prop, confirmed, body.get("tables")) if confirmed else None
    ran = prop["assistant"]
    base_ev = None
    if confirmed and ran["kind"] != "baseline":
        base_ev = propose.evaluate(propose.propose(tx, sid, body.get("tables"), assistant="baseline"), confirmed, body.get("tables"))
    notes = {"anthropic": f"Proposed by {ran['label']}: the whole table in one structured call.",
             "ollama": f"Proposed by {ran['label']}: one small structured call per table chunk of at most {propose.CHUNK} columns, "
                       "and one for the code values of the columns it marks crosswalk. Nothing leaves the firm's machines.",
             "claudecode": f"Proposed by {ran['label']}: one headless Claude Code session per table chunk of at most {propose.CHUNK} columns, "
                           "and one for the code values of the columns it marks crosswalk; the subscription's usage, no API key.",
             "baseline": "The deterministic baseline (token overlap between the data dictionary and the taxonomy), no model call."}
    resp = dict(source=sid, proposer=prop["proposer"], assistant=ran, assistant_available=llm_describe(),
                note=notes[ran["kind"]], fallbacks=prop.get("fallbacks", []), timing=prop.get("timing"),
                rows=rows, crosswalks={n: dict(target=list(cw["target"]), values=[list(v) for v in cw["values"]]) for n, cw in prop["crosswalks"].items()},
                identifier_schemes={k: list(v) for k, v in prop["source"]["identifier_schemes"].items()},
                gaps=[list(g) for g in prop["gaps"]], source_errors=prop["invalid"].get("source", []),
                eval=ev, baseline_eval=base_ev, confirmed_module=confirmed.__name__ if confirmed else None,
                elapsed_ms=int((time.time() - t0) * 1000), cached=False, computed_at=datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))
    os.makedirs(propose.OUT_DIR, exist_ok=True)
    with open(cache_path, "w") as f:
        json.dump(resp, f, default=str)
    return resp


def precompute(assistant="local"):
    """Run and cache the proposals for every source before a demo, with no runtime open."""
    for sid in SOURCES:
        t = time.time()
        d = api_map_propose(None, {"source": sid, "assistant": assistant, "force": True})
        ov = (d.get("eval") or {}).get("overall") or {}
        print(f"{sid}: {d['assistant']['label']}: {len(d['rows'])} rows in {time.time() - t:.0f}s; precision {ov.get('precision')}, recall {ov.get('recall')}; "
              f"{(d.get('timing') or {}).get('calls')} calls, {(d.get('timing') or {}).get('prompt_tokens')} prompt tokens", flush=True)


def proposer_model(want):
    """The model a proposal run would use, for the cache key: the provider asked for, not the one configured for questions."""
    try:
        import llm
        if want in (None, "auto"):
            return llm.describe(llm.get()).get("model")
        if want == "baseline":
            return None
        p = llm.make(want)
        return p.model or p.kind
    except Exception:
        return None


def llm_describe():
    try:
        import llm
        return llm.describe(llm.get())
    except Exception:
        return dict(kind="none", label="no model", model=None, available=False)


def api_map_confirmed(q, body, sid):
    sid = unquote(sid)
    m = mapping_modules().get(sid)
    if not m:
        raise ApiError(404, f"no confirmed mapping for {sid}")
    schemes = [dict(key=k, domain=v[0], scheme_list=v[1], value=v[2], note=v[3] if len(v) > 3 else "")
               for k, v in m.SOURCE.get("identifier_schemes", {}).items()]
    cws = [dict(name=n, target=list(cw["target"]), values=[dict(source=v[0], target=v[1], note=v[2], no_equivalent=v[1] is None)
                                                            for v in cw["values"]]) for n, cw in m.CROSSWALKS.items()]
    rows = [dict(table=t, column=c, target=tgt(g), kind=k, detail=d) for t, c, g, k, d in m.ATTRIBUTES]
    kinds = {}
    for r in rows:
        kinds[r["kind"]] = kinds.get(r["kind"], 0) + 1
    return dict(source=sid, module=f"mapping/{m.__name__}.py", doc=(m.__doc__ or "").strip(), name=m.SOURCE.get("name"),
                objects=[dict(table=t, domain=o[0], object=o[1], note=n) for t, o, n in m.OBJECTS], rows=rows, kinds=kinds,
                crosswalks=cws, identifier_schemes=schemes, gaps=[dict(table=t, note=n) for t, n in getattr(m, "GAPS", [])])


def api_map_check(q, body):
    import check_mapping as cm
    import slice as sl
    t0 = time.time()
    CACHE.pop("mods", None)
    mods = mapping_modules()
    if "objs" not in CACHE:
        CACHE["objs"] = sl.load()[3]; CACHE["cl"] = sl.code_lists()
    errs = cm.validate(mods, CACHE["objs"], CACHE["cl"])
    s = load_json(os.path.join(OUT, "slice.json"))
    if s is None:
        raise ApiError(409, "out/slice.json is missing: run activation/slice.py first")
    cov = cm.coverage(mods, s)
    with open(os.path.join(OUT, "coverage.json"), "w") as f:
        json.dump(cov, f, indent=1, ensure_ascii=False)
    ents = {k: {x: e[x] for x in ("product", "entity", "derived_product", "attrs", "mapped", "used", "used_mapped", "missing", "cde_unmapped")}
            for k, e in cov["entities"].items()}
    prods = sorted(cov["products"].values(), key=lambda p: (p["tier"] != "Foundational", p["id"]))
    return dict(errors=errs, products=prods, entities=ents, gaps=cov["gaps"], metrics=cov["metrics"],
                metrics_mappable=sum(m["mappable"] for m in cov["metrics"]), metrics_total=len(cov["metrics"]),
                mapped_targets=cov["mapped_targets"], attribute_rows=sum(len(m.ATTRIBUTES) for m in mods.values()),
                sources=cov["sources"], elapsed_ms=int((time.time() - t0) * 1000))


# ---------------------------------------------------------------------------------------------------------- build
class StdoutTee:
    """Sends what the build thread prints (check_truths, tests) to the build log; other threads print as usual."""
    def __init__(self, orig):
        self.orig = orig; self.buf = ""
    def write(self, s):
        t = BUILD.get("thread")
        if t is not None and threading.current_thread() is t:
            self.buf += s                       # print() writes its pieces separately: log whole lines
            while "\n" in self.buf:
                line, self.buf = self.buf.split("\n", 1)
                if line.strip():
                    build_log(line)
            return len(s)
        return self.orig.write(s)
    def flush(self):
        t = BUILD.get("thread")
        if t is not None and threading.current_thread() is t and self.buf.strip():
            build_log(self.buf); self.buf = ""
        self.orig.flush()
    def __getattr__(self, k):
        return getattr(self.orig, k)


def build_log(text):
    for line in str(text).splitlines():
        if line.strip():
            _log_line(line)


def _log_line(line):
    m = re.match(r"== (\w+) \(", line)
    if m:
        BUILD["current"] = m.group(1)
    m = re.match(r"== (\w+) done in ([\d.]+)s", line)
    if m:
        BUILD["done"].append(dict(step=m.group(1), seconds=float(m.group(2)))); BUILD["current"] = None
    m = re.match(r"RESULT: (.*)", line) or re.match(r"check_truths: (.*)", line)
    if m:
        BUILD["verdict"] = m.group(1)
    BUILD["lines"].append(f"{time.strftime('%H:%M:%S')}  {line}")


def build_worker(steps):
    from build_all import run_steps
    try:
        run_steps(RT, build_log, steps)
    except Exception as e:
        BUILD["error"] = f"{type(e).__name__}: {e}"
        build_log(f"FAILED: {BUILD['error']}")
        for line in traceback.format_exc().splitlines()[-8:]:
            build_log("  " + line)
    finally:
        sys.stdout.flush()
        reset_caches(); warm()
        BUILD["finished"] = time.time(); BUILD["running"] = False
        build_log(f"build {'failed' if BUILD['error'] else 'finished'} in {BUILD['finished'] - BUILD['started']:.1f}s")


def api_build(q, body):
    steps = body.get("steps") or STEPS
    bad = [s for s in steps if s not in STEPS]
    if bad:
        raise ApiError(400, f"unknown step(s) {bad}; steps are {STEPS}")
    steps = [s for s in STEPS if s in steps]
    with LOCK:
        if BUILD["running"]:
            raise ApiError(409, "a build is already running")
        BUILD.update(running=True, lines=[], started=time.time(), finished=None, steps=steps, done=[], current=None,
                     results={}, error=None, verdict=None)
        th = threading.Thread(target=build_worker, args=(steps,), daemon=True, name="build")
        BUILD["thread"] = th
    th.start()
    return dict(started=True, steps=steps, runtime=RT.name)


def build_status():
    return dict(running=BUILD["running"], steps=BUILD["steps"], done=BUILD["done"], current=BUILD["current"], error=BUILD["error"],
                verdict=BUILD["verdict"], started=BUILD["started"], finished=BUILD["finished"], lines=len(BUILD["lines"]),
                elapsed=round((BUILD["finished"] or time.time()) - BUILD["started"], 1) if BUILD["started"] else None)


def api_build_log(q, body):
    since = max(0, int(q.get("since", 0)))
    return dict(build_status(), since=since, next=len(BUILD["lines"]), log=BUILD["lines"][since:], finished=not BUILD["running"])


def api_build_status(q, body):
    return build_status()


# ------------------------------------------------------------------------------------------------------- products
def test_summary():
    t = out_json("test_results.json")
    return (t or {}).get("summary", {})


def product_layer(pid):
    return ("gold" if pid in runtime.GOLD_PRODUCTS else "silver") if RT.name == "spark" else None


def api_products(q, body):
    if "products" not in CACHE:
        CACHE["products"] = products_view()
    return CACHE["products"]


def products_view():
    act = out_json("activation.json")
    s = load_json(os.path.join(OUT, "slice.json")) or {"entities": {}, "products": {}}
    phys = out_json("physical_report.json") or {"entities": {}}
    der = out_json("derivation_report.json") or {"counts": {}}
    cov = load_json(os.path.join(OUT, "coverage.json")) or {"products": {}, "entities": {}}
    tests = test_summary()
    prods = (act or {}).get("products") or cov["products"]
    ents_state = (act or {}).get("entities", {})
    out = []
    for pid, p in prods.items():
        ents = []
        for key, e in s["entities"].items():
            if e["product"] != pid:
                continue
            tbl = RT.entity(pid, e["entity"])
            es = ents_state.get(key, {})
            rep = (phys["entities"].get(key) or {}).get("rows")
            if rep is None:
                rep = der["counts"].get(key)          # None: counted once (the derived helper entities), then cached
            exists = safe_exists(tbl)
            ents.append(dict(key=key, entity=e["entity"], table=tbl, layer=layer_of(tbl), built=exists,
                             rows=count_rows(tbl, rep) if exists else None, state=es.get("state"), note=es.get("note", ""),
                             grain=e.get("grain", "")))
        out.append(dict(id=pid, name=p.get("name") or s["products"].get(pid, {}).get("name", ""),
                        tier=p.get("tier") or s["products"].get(pid, {}).get("tier", ""), state=p.get("state"),
                        derived=pid in config.DERIVED_PRODUCTS, derived_from=config.DERIVED_PRODUCTS.get(pid, []),
                        missing=p.get("missing", []), layer=product_layer(pid), entities=ents, tests=tests.get(pid)))
    out.sort(key=lambda p: (p["layer"] or "", p["tier"] != "Foundational", p["derived"], p["id"]))
    enabled = [dict(model=m["model"], name=m["name"]) for m in (act or {}).get("metrics", []) if m.get("state") == "enabled" and not m.get("ref")]
    groups = ["silver", "gold"] if RT.name == "spark" else ["Foundational", "Consumer-aligned"]
    return dict(products=out, summary=(act or {}).get("summary"), enabled_metrics=enabled, group_by="layer" if RT.name == "spark" else "tier",
                groups=groups, from_activation=act is not None)


def api_product_entity(q, body, pid, entity):
    pid, entity = unquote(pid), unquote(entity)
    key = f"{pid}/{entity}"
    s = load_json(os.path.join(OUT, "slice.json")) or {"entities": {}}
    e = s["entities"].get(key)
    if not e:
        raise ApiError(404, f"no entity {key} in the slice")
    tbl = RT.entity(pid, entity)
    limit = min(int(q.get("limit", 50)), ROW_CAP); offset = max(0, int(q.get("offset", 0)))
    cols, rows = table_rows(tbl, limit, offset) if safe_exists(tbl) else ([], [])
    phys = (out_json("physical_report.json") or {"entities": {}})["entities"].get(key, {})
    cov = (load_json(os.path.join(OUT, "coverage.json")) or {"entities": {}})["entities"].get(key, {})
    act = (out_json("activation.json") or {"entities": {}})["entities"].get(key, {})
    by_attr = {r["name"]: r for r in cov.get("rows", [])}
    lineage = []
    for a in e["attrs"]:
        col = runtime.snake(a["name"])
        cr = by_attr.get(a["name"], {})
        pc = phys.get("columns", {}).get(col, {})
        lineage.append(dict(column=col, attribute=a["name"], taxonomy=a["taxonomy"], attr_id=a.get("attr_id"), definition=a.get("definition", ""),
                            type=a.get("type"), pk=a.get("pk"), cde=a.get("cde"), pii=a.get("pii"), used=a["name"] in e.get("used", []),
                            in_table=col in cols, non_null=pc.get("non_null"), sources=cr.get("sources", []), mapped=cr.get("mapped", False),
                            derived=a.get("derived", False)))
    derived = pid in config.DERIVED_PRODUCTS
    der = out_json("derivation_report.json") or {"gaps": []}
    total = count_rows(tbl, phys.get("rows") or (out_json("derivation_report.json") or {"counts": {}})["counts"].get(key)) if cols else None
    return dict(key=key, product=pid, entity=entity, table=tbl, layer=layer_of(tbl), grain=e.get("grain", ""), pk=e.get("pk", []),
                columns=cols, rows=rows, offset=offset, limit=limit, total=total, state=act.get("state"), note=act.get("note", ""),
                derived=derived, derived_from=config.DERIVED_PRODUCTS.get(pid, []), feeds=phys.get("feeds", []),
                derivation_gaps=[g["note"] for g in der.get("gaps", []) if g.get("entity") == key],
                derivation_note=act.get("note", "") if derived else "", lineage=lineage)


# -------------------------------------------------------------------------------------------------- metrics / ask
def mcp():
    import mcp_server
    if not os.path.exists(os.path.join(RT.out, "compiled_model.json")):
        raise ApiError(409, f"no compiled model for the {RT.name} runtime yet: run the build (at least the semantic step)")
    return mcp_server


def api_metrics(q, body):
    ms = mcp().list_metrics()
    act = out_json("activation.json") or {"metrics": []}
    st = {(m["model"], m["name"]): m for m in act["metrics"]}
    for m in ms["metrics"]:
        a = st.get((m["model"], m["name"]), {})
        m["state"] = a.get("state"); m["in_scope"] = a.get("in_scope"); m["ref"] = a.get("ref")
    return ms


def api_metric(q, body, name):
    r = mcp().describe(unquote(name))
    if r.get("error"):
        raise ApiError(404, r["error"])
    return r


def api_query(q, body):
    M = mcp()
    if not body.get("metric"):
        raise ApiError(400, "metric is required")
    try:
        r = M.Q.run(M._m(), body["metric"], by=body.get("by") or [], filters=body.get("filters") or [], as_of=body.get("as_of"),
                    period=body.get("period"), dimension_type=body.get("dimension_type"))
    except ValueError as e:
        raise ApiError(400, str(e))
    r["row_count"] = len(r["rows"]); r["rows"] = r["rows"][:ROW_CAP]
    return M.plain(r)


def api_ask(q, body):
    M = mcp()
    question = (body.get("question") or "").strip()
    if not question:
        raise ApiError(400, "question is required")
    t0 = time.time()
    try:
        r = M.ask(question)
    except Exception as e:           # a model call that fails (no network) falls back to the deterministic router
        r = M.route(question); r.update(assistant="router", fallback=f"the assistant was unavailable ({type(e).__name__}: {e}); deterministic router used")
    r = M.plain(r)
    r["assistant"] = r.get("assistant") or "router"
    r["router"] = "deterministic" if r["assistant"] == "router" else r["assistant"]
    r["elapsed_ms"] = int((time.time() - t0) * 1000)
    return r


def api_questions(q, body):
    act = out_json("activation.json") or {}
    cm = out_json("compiled_model.json") or {}
    states = {(x["model"], x["question"]): x for x in act.get("questions", [])}
    qs = []
    for v in cm.get("questions", []):
        a = states.get((v["model"], v["question"]), {})
        qs.append(dict(model=v["model"], question=v["question"], answer=v.get("answer", ""), state=a.get("state"),
                       metrics=a.get("metrics", []), missing=a.get("missing", [])))
    try:
        import mcp_server as MS
        for d in MS.DEMO_QUESTIONS:
            qs.insert(0, dict(model=d["model"], question=d["question"], answer=d.get("note", ""), state="enabled", metrics=d["metrics"], missing=[], demo=True))
    except Exception:
        pass
    return dict(questions=qs, cannot_answer=cm.get("cannot_answer", act.get("cannot_answer", [])))


# ------------------------------------------------------------------------------------------------------------ sql
FORBIDDEN = re.compile(r"\b(insert|update|delete|merge|create|drop|alter|truncate|attach|detach|copy|export|import|install|load|"
                       r"pragma|call|set|reset|grant|revoke|vacuum|optimize|checkpoint|use|refresh|cache|uncache|msck|analyze|"
                       r"read_\w+|glob|sniff_csv|query_table|getenv)\b", re.I)


def check_select(sql):
    s = re.sub(r"--[^\n]*", " ", sql)
    s = re.sub(r"/\*.*?\*/", " ", s, flags=re.S).strip().rstrip(";").strip()
    bare = re.sub(r"'(?:[^']|'')*'", "''", s)              # string literals out before the keyword checks
    if not s:
        raise ApiError(400, "empty statement")
    if ";" in bare:
        raise ApiError(400, "one statement only")
    if not re.match(r"(?is)^\s*(select|with)\b", bare):
        raise ApiError(400, "only a single SELECT or WITH statement runs here (read-only)")
    m = FORBIDDEN.search(bare)
    if m:
        raise ApiError(400, f"'{m.group(0)}' is not allowed: read-only SELECT statements only")
    if re.search(r"(?i)\bfrom\s*''|\bjoin\s*''", bare):
        raise ApiError(400, "reading files is not allowed")
    return s


def api_sql(q, body):
    sql = check_select(body.get("sql") or "")
    if RT.name == "spark":
        sql = RT.sql(sql)                  # DuckDB-flavored names (src_brk."X", dp_093.account) work on Spark too
    wrapped = f"select * from ({sql}) as q_ limit {ROW_CAP + 1}"
    t0 = time.time()
    try:
        cols = RT.select_columns(wrapped)
        rows = [list(r) for r in RT.fetch(wrapped)]
    except Exception as e:
        raise ApiError(400, str(e).strip().splitlines()[0][:600] if str(e).strip() else type(e).__name__)
    ms = int((time.time() - t0) * 1000)
    return dict(sql=sql, columns=cols, rows=rows[:ROW_CAP], truncated=len(rows) > ROW_CAP, row_count=min(len(rows), ROW_CAP),
                elapsed_ms=ms, runtime=RT.name, label="Databricks SQL (local Spark)" if RT.name == "spark" else "SQL",
                catalog=api_catalog(q, body)["schemas"] if body.get("with_catalog") else None)


def report_counts():
    """Table name -> row count from the generated reports (no scans)."""
    counts = {}
    phys = out_json("physical_report.json") or {}
    for k, n in phys.get("sources", {}).items():
        sid, t = k.split("/", 1)
        counts[RT.src(sid, t)] = n
    for k, e in phys.get("entities", {}).items():
        pid, ent = k.split("/", 1)
        counts[RT.entity(pid, ent)] = e.get("rows")
    for k, n in (out_json("derivation_report.json") or {}).get("counts", {}).items():
        pid, ent = k.split("/", 1)
        counts[RT.entity(pid, ent)] = n
    cmod = out_json("compiled_model.json") or {}
    act = out_json("activation.json") or {}
    for k, t in cmod.get("tables", {}).items():
        if t.get("view"):
            counts[t["view"]] = act.get("tables", {}).get(k, {}).get("rows")
    return {k.replace('"', "").replace("`", "").lower(): v for k, v in counts.items()}


def api_catalog(q, body):
    if "catalog" in CACHE:
        return CACHE["catalog"]
    counts = report_counts()
    schemas = {}
    if RT.name == "spark":
        for sch in ("bronze", "silver", "gold"):
            try:
                rows = RT.fetch(f"show tables in {sch}")
            except Exception:
                rows = []
            for r in rows:
                if r[2]:
                    continue
                full = f"{sch}.{r[1]}"
                schemas.setdefault(sch, []).append(dict(name=r[1], full=full, rows=counts.get(full.lower())))
    else:
        rows = RT.fetch("select table_schema, table_name, table_type from information_schema.tables where table_catalog = current_database() "
                        "and table_schema not in ('information_schema', 'pg_catalog', 'stg') order by 1, 2")
        est = {(r[0], r[1]): r[2] for r in RT.fetch("select schema_name, table_name, estimated_size from duckdb_tables()")}
        for sch, name, typ in rows:
            full = f'{sch}."{name}"' if not re.fullmatch(r"[a-z_][a-z0-9_]*", name) else f"{sch}.{name}"
            n = counts.get(f"{sch}.{name}".lower(), est.get((sch, name)))
            schemas.setdefault(sch, []).append(dict(name=name, full=full, rows=n, view=typ == "VIEW"))
    order = ["bronze", "silver", "gold"] if RT.name == "spark" else None
    out = [dict(name=k, tables=v) for k, v in sorted(schemas.items(), key=lambda kv: (order.index(kv[0]) if order and kv[0] in order else 9, kv[0]))]
    res = dict(runtime=RT.name, catalog=config.CATALOG if RT.name == "spark" else None, schemas=out,
               label="Databricks SQL (local Spark)" if RT.name == "spark" else "SQL")
    CACHE["catalog"] = res
    return res


# --------------------------------------------------------------------------------------------------------- server
ROUTES = [
    ("GET", r"/api/state", api_state),
    ("GET", r"/api/sources", api_sources),
    ("GET", r"/api/sources/([^/]+)/dictionary", api_source_dictionary),
    ("GET", r"/api/sources/([^/]+)/([^/]+)", api_source_table),
    ("POST", r"/api/map/propose", api_map_propose),
    ("GET", r"/api/map/confirmed/([^/]+)", api_map_confirmed),
    ("POST", r"/api/map/check", api_map_check),
    ("POST", r"/api/build", api_build),
    ("GET", r"/api/build/log", api_build_log),
    ("GET", r"/api/build/status", api_build_status),
    ("GET", r"/api/products", api_products),
    ("GET", r"/api/products/([^/]+)/([^/]+)", api_product_entity),
    ("GET", r"/api/metrics", api_metrics),
    ("GET", r"/api/metrics/(.+)", api_metric),
    ("POST", r"/api/query", api_query),
    ("POST", r"/api/ask", api_ask),
    ("GET", r"/api/questions", api_questions),
    ("POST", r"/api/sql", api_sql),
    ("GET", r"/api/catalog", api_catalog),
]


def index_html():
    with open(os.path.join(APP, "index.html"), encoding="utf-8") as f:
        html = f.read()
    try:
        import brand
        html = brand.apply(html)
    except Exception as e:                 # an unbranded page still works
        sys.stderr.write(f"brand not applied: {e}\n")
    return html


class Handler(BaseHTTPRequestHandler):
    server_version = "ActivationDemo/1.0"

    def log_message(self, fmt, *args):
        if "/api/build/log" not in (args[0] if args else ""):
            sys.stderr.write(f"{self.address_string()} {fmt % args}\n")

    def send(self, status, payload, ctype="application/json; charset=utf-8"):
        data = payload if isinstance(payload, bytes) else payload.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def handle_any(self, method):
        u = urlparse(self.path)
        if method == "GET" and u.path in ("/", "/index.html"):
            return self.send(200, index_html(), "text/html; charset=utf-8")
        q = {k: v[-1] for k, v in parse_qs(u.query).items()}
        body = {}
        if method == "POST":
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n) if n else b""
            try:
                body = json.loads(raw or b"{}")
                if not isinstance(body, dict):
                    raise ValueError("body must be a JSON object")
            except ValueError as e:
                return self.send(400, dumps(dict(ok=False, error=f"bad JSON body: {e}")))
        for m, pat, fn in ROUTES:
            mt = re.fullmatch(pat, u.path)
            if mt and m == method:
                try:
                    res = fn(q, body, *mt.groups())
                    return self.send(200, dumps(dict(ok=True, **res)))
                except ApiError as e:
                    return self.send(e.status, dumps(dict(ok=False, error=str(e))))
                except Exception as e:
                    traceback.print_exc()
                    return self.send(500, dumps(dict(ok=False, error=f"{type(e).__name__}: {e}")))
        if any(re.fullmatch(pat, u.path) for _, pat, _ in ROUTES):
            return self.send(405, dumps(dict(ok=False, error=f"{method} not allowed on {u.path}")))
        return self.send(404, dumps(dict(ok=False, error=f"not found: {u.path}")))

    def do_GET(self):
        self.handle_any("GET")

    def do_POST(self):
        self.handle_any("POST")


def main():
    global RT
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--runtime", choices=["duckdb", "spark"], default=runtime.selected_name())
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--precompute", nargs="?", const="local", help="run and cache the proposals for every source (local|baseline|claude), then exit")
    a = ap.parse_args()
    if a.precompute:
        precompute(a.precompute); return
    t0 = time.time()
    print(f"opening the {a.runtime} runtime ...", flush=True)
    RT = open_runtime(a.runtime)
    sys.stdout = StdoutTee(sys.stdout)
    srv = ThreadingHTTPServer((a.host, a.port), Handler)
    srv.daemon_threads = True
    warm()
    shown = "localhost" if a.host in ("127.0.0.1", "0.0.0.0") else a.host
    print(f"runtime {RT.name} ready in {time.time() - t0:.1f}s; serving http://{shown}:{a.port}/"
          + ("  (listening on every interface: use this machine's LAN address)" if a.host == "0.0.0.0" else ""), flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()
        try:
            RT.close()
        except Exception:
            pass


if __name__ == "__main__":
    main()
