"""Runs the whole activation in order: slice -> mapping check -> physical -> derivations -> truths check -> semantic ->
tests -> coverage. Each step is its own script; this just chains them and stops at the first failure.

Usage (from _tools/):  activation/.venv/bin/python activation/compile/build_all.py [--skip-generate]
"""
import os, subprocess, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
ACT = os.path.dirname(HERE)
TOOLS = os.path.dirname(ACT)
PY = sys.executable
STEPS = [
    ("generate the synthetic sources", [PY, "activation/sources/generate.py"]),
    ("resolve the slice", [PY, "activation/slice.py"]),
    ("check the mappings", [PY, "activation/mapping/check_mapping.py", "--quiet"]),
    ("build the physical layer", [PY, "activation/compile/physical.py"]),
    ("derive the products", [PY, "activation/compile/derivations.py"]),
    ("prove the certified figures", [PY, "activation/compile/check_truths.py"]),
    ("compile the semantic layer", [PY, "activation/compile/semantic.py"]),
    ("run the generated tests", [PY, "activation/compile/tests.py"]),
    ("write the activation states", [PY, "activation/compile/coverage.py"]),
]


IN_PROCESS = ["physical", "derivations", "check_truths", "semantic", "tests", "coverage"]


def run_steps(rt, log=print, steps=None):
    """The compile steps in this process on an open runtime (the web app runs them in a thread with a live log)."""
    sys.path.insert(0, HERE)
    import importlib
    results = {}
    for name in steps or IN_PROCESS:
        t = time.time()
        log(f"== {name} ({rt.name})")
        mod = importlib.import_module(name)
        if name == "check_truths":
            rc = mod.main(rt=rt)
            results[name] = rc
            log(f"check_truths: {'no differences' if rc == 0 else str(rc) + ' difference(s)'}")
        else:
            results[name] = mod.main(rt, log)
        log(f"== {name} done in {time.time() - t:.1f}s")
    return results


def main():
    skip = "--skip-generate" in sys.argv
    rtn = None
    for i, a in enumerate(sys.argv):
        if a == "--runtime" and i + 1 < len(sys.argv):
            rtn = sys.argv[i + 1]
    t0 = time.time()
    for name, cmd in STEPS:
        if skip and cmd[1].endswith("generate.py"):
            continue
        if rtn and cmd[0] == PY and not cmd[1].endswith(("generate.py", "slice.py", "check_mapping.py")):
            cmd = cmd + ["--runtime", rtn]
        t = time.time()
        r = subprocess.run(cmd, cwd=TOOLS, capture_output=True, text=True)
        tail = ([l for l in r.stdout.strip().splitlines() if not l.startswith(("[Stage", "\t", "::", "Ivy", "The jars"))] or [""])[-1]
        print(f"{'ok ' if r.returncode == 0 else 'FAIL'} {name:32s} {time.time() - t:5.1f}s  {tail[:100]}")
        if r.returncode != 0:
            print(r.stdout[-3000:]); print(r.stderr[-3000:]); sys.exit(1)
    print(f"done in {time.time() - t0:.1f}s")


if __name__ == "__main__":
    main()
