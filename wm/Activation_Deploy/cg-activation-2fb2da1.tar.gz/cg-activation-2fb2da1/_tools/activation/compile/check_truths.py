"""Proves the compiled pipeline against the generator's independent computation (sources/truths.json): every DP-008
measure row, the household figures and the planted facts. Exits 1 on any difference beyond a cent.

Usage (from _tools/):  python activation/compile/check_truths.py [--verbose]
"""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import _paths  # noqa: E402,F401
sys.path.insert(0, HERE)
import config  # noqa: E402
import runtime  # noqa: E402

AMOUNTS = ["beginning_client_assets", "ending_client_assets", "average_client_assets", "net_new_assets", "net_inter_channel_transfers",
           "client_market_movement_other", "advised_assets", "own_fund_overlap_amount", "client_assets_excl_intermediary", "gross_sales",
           "redemptions", "net_exchanges", "net_flows", "restatement_impact"]
COUNTS = ["funded_accounts", "clients", "households"]
DBCOL = {"client_market_movement_other": "client_market_movement_and_other", "client_assets_excl_intermediary": "client_assets_excluding_intermediary_held"}


def norm_key(dim, key):
    if dim == "Advisor" and key.startswith("EMP-"):
        return key[4:]
    if dim == "Share Class" and key.startswith("SHC-"):
        return key[4:]
    return key


def planted_values(rt):
    """{planted fact: the pipeline's value}, read from the built tables (the demo page shows them beside the truths)."""
    q = lambda sql: rt.scalar(rt.sql(sql))
    out = {
        "HOUSEHOLDS_WITHOUT_PRIMARY_ADVISOR": q("select count(*) from dp_320.fact_household_360 where households_without_primary_advisor = 1"),
        "SUGGESTED_MATCHES": q("select count(*) from dp_495.fact_match_result where match_status = 'Suggested'"),
        "UNLINKED_BROKERAGE_ACCOUNTS": q("""select count(*) from dp_093.account a where a.account_id like 'ACC-BRK-%' and not exists
                                            (select 1 from dp_093.account_identifier i where i.identified_account = a.account_id and i.account_identifier_scheme = 'CRM Financial Account ID')"""),
        "OPTIONS_UNATTRIBUTED": q(f"select ending_client_assets from cert.measure_wide where period_type = 'Month' and period_end_date = date '{config.AS_OF}' and dimension_type = 'Holding Type' and dimension_key = 'UNATTRIBUTED'"),
        "AFFILIATED_OMNIBUS_VALUE": q(f"select sum(market_value) from dp_007.position where aggregation_role = 'Excluded - Omnibus or Nominee' and valuation_date = date '{config.AS_OF}'"),
        "BROKERAGE_OWN_FUND_VALUE": q(f"select sum(market_value_in_usd) from dp_300.client_holding where own_share_class_indicator and client_holding_date = date '{config.AS_OF}'"),
        "SERVICE_TIER_MISMATCH": q("select count(*) from dp_320.fact_household_360 where service_tier_qualification_mismatch = 1"),
        "INTER_CHANNEL_TRANSFER_PAIRS": q("select count(*) / 2 from dp_006.transaction where flow_scope = 'Inter-Channel Transfer' and transaction_status = 'Settled'"),
        "SAME_OWNER_JOURNALS_EXCLUDED": q("""select sum(t.reporting_currency_amount) from dp_006.transaction t where t.reporting_currency_amount > 0 and t.flow_scope <> 'Inter-Channel Transfer'
                                            and t.transaction_status = 'Settled' and t.transaction_id in (select transaction_key from dp_006.linked_transaction where same_owner_indicator)"""),
        "INSTITUTIONAL_CLIENTS": q("select count(*) from dp_003.institutional_client"),
        "PUBLIC_PENSION_PLANS": q("select count(*) from dp_003.institutional_client where institutional_client_type = 'Public Pension Plan'"),
        "AT_RISK_RELATIONSHIPS": q(f"select count(*) from dp_510.fact_relationship_health where calendar_date_key = date '{config.AS_OF}' and at_risk_relationships = 1"),
        "PUBLIC_PENSION_AT_RISK_RELATIONSHIPS": q(f"""select count(*) from dp_510.fact_relationship_health f join dp_510.service_relationship r on r.service_relationship_id = f.service_relationship_key
                                                    join dp_003.institutional_client c on c.institutional_client_party = r.client
                                                    where f.calendar_date_key = date '{config.AS_OF}' and f.at_risk_relationships = 1 and c.institutional_client_type = 'Public Pension Plan'"""),
        "INSTITUTIONAL_CLIENT_ASSETS": q(f"select sum(relationship_client_assets) from dp_510.fact_relationship_health where calendar_date_key = date '{config.AS_OF}'"),
        "SEPARATE_ACCOUNT_ASSETS": q(f"select sum(s.summary_market_value) from dp_007.account_asset_summary s where s.summary_as_of_date = date '{config.AS_OF}' and s.summary_source_book = 'Institutional Portfolio Book (18)'"),
        "PUBLIC_PENSION_CLIENT_ASSETS": q(f"""select sum(f.relationship_client_assets) from dp_510.fact_relationship_health f join dp_510.service_relationship r on r.service_relationship_id = f.service_relationship_key
                                            join dp_003.institutional_client c on c.institutional_client_party = r.client where f.calendar_date_key = date '{config.AS_OF}' and c.institutional_client_type = 'Public Pension Plan'"""),
        "PUBLIC_PENSION_AT_RISK_CLIENT_ASSETS": q(f"""select sum(f.relationship_client_assets) from dp_510.fact_relationship_health f join dp_510.service_relationship r on r.service_relationship_id = f.service_relationship_key
                                                    join dp_003.institutional_client c on c.institutional_client_party = r.client
                                                    where f.calendar_date_key = date '{config.AS_OF}' and f.at_risk_relationships = 1 and c.institutional_client_type = 'Public Pension Plan'"""),
        "AT_RISK_CLIENT_ASSETS": q(f"select sum(relationship_client_assets) from dp_510.fact_relationship_health where calendar_date_key = date '{config.AS_OF}' and at_risk_relationships = 1"),
        "TA_DIRECT_UNLINKED_ACCOUNTS": q("""select count(*) from dp_093.account a where a.account_type = 'Fund-Only Account' and not exists
                                            (select 1 from dp_093.account_identifier i where i.identified_account = a.account_id and i.account_identifier_scheme = 'CRM Financial Account ID')"""),
    }
    if rt.has_table(rt.entity("DP-499", "Fact Profitability")):
        out.update(economics_values(rt))
    return out


Q3 = "('FY2026-M07', 'FY2026-M08', 'FY2026-M09')"
FEE_STREAMS = "('Advisory Fee', 'Wrap Fee', 'Planning Fee', 'Subscription Fee', 'Account Service Fee', 'Recordkeeping Fee', 'Trust Fee', 'OCIO Fee', 'Mandate Performance Fee')"
RELEASED = "(select fee_calculation_run_id from dp_305.fee_run where run_status = 'Released' and run_type <> 'Simulation' and run_billing_period_end between date '2026-07-01' and date '2026-09-30')"
TESTED = "run_status in ('Approved', 'Released') and run_type <> 'Simulation' and run_billing_period_end between date '2026-07-01' and date '2026-09-30'"


def economics_values(rt):
    """The client-economics planted facts (SM-28 slice) recomputed from the derived and mapped products."""
    q = lambda sql: rt.scalar(rt.sql(sql))
    cf = q(f"select sum(recognized_revenue_amount) from dp_012.client_revenue_record where client_revenue_period in {Q3} and client_revenue_stream in {FEE_STREAMS}")
    fg = q(f"select sum(gross_fee_revenue) from dp_012.fee_revenue_record where revenue_accounting_period in {Q3}")
    fo = q(f"select sum(waiver_and_reimbursement_offset) from dp_012.fee_revenue_record where revenue_accounting_period in {Q3}")
    return {
        "CLIENT_FEE_REVENUE_Q3": cf,
        "CLIENT_REVENUE_Q3": q(f"select sum(recognized_revenue_amount) from dp_012.client_revenue_record where client_revenue_period in {Q3}"),
        "FUND_GROSS_FEE_REVENUE_Q3": fg,
        "FUND_NET_FEE_REVENUE_Q3": q(f"select sum(net_fee_revenue) from dp_012.fee_revenue_record where revenue_accounting_period in {Q3}"),
        "GROSS_FEE_REVENUE_Q3": (cf or 0) + (fg or 0),
        "NET_FEE_REVENUE_Q3": (cf or 0) + (fg or 0) - (fo or 0),
        "NET_BILLED_FEES_Q3": q(f"select sum(net_fee) from dp_305.account_fee_calculation where calculation_run in {RELEASED}"),
        "GROSS_BILLED_FEES_Q3": q(f"select sum(gross_fee) from dp_305.account_fee_calculation where calculation_run in {RELEASED}"),
        "BILLABLE_ASSETS_BILLED_Q3": q(f"select sum(billable_assets) from dp_305.account_fee_calculation where calculation_run in {RELEASED}"),
        "AVERAGE_EFFECTIVE_RATE_BPS_Q3": q(f"select sum(effective_annual_rate * billable_assets) / sum(billable_assets) from dp_305.account_fee_calculation where calculation_run in {RELEASED}"),
        "EFFECTIVE_NET_FEE_RATE_BPS_Q3": q(f"""select sum(r.recognized_revenue_amount) * 4 * 10000.0 / (select sum(c.billable_assets) from dp_305.account_fee_calculation c where c.calculation_run || '|' || c.calculated_assignment in
                                              (select distinct source_calculation_record from dp_012.client_revenue_record where client_revenue_period in {Q3} and client_revenue_stream in ('Advisory Fee', 'Wrap Fee', 'OCIO Fee', 'Trust Fee', 'Recordkeeping Fee')))
                                              from dp_012.client_revenue_record r where r.client_revenue_period in {Q3} and r.client_revenue_stream in ('Advisory Fee', 'Wrap Fee', 'OCIO Fee', 'Trust Fee', 'Recordkeeping Fee')"""),
        "FEE_RUNS_TESTED_Q3": q(f"select count(*) from dp_305.fee_run where {TESTED}"),
        "FAILED_FEE_RUNS_Q3": q(f"""select count(*) from dp_305.fee_run r where {TESTED} and (fee_reconciliation_status in ('Break Open', 'Not Reconciled') or (run_status = 'Released' and run_approved_by is null)
                                   or abs(run_net_fee_total - (select coalesce(sum(net_fee), 0) from dp_305.account_fee_calculation c where c.calculation_run = r.fee_calculation_run_id)) > 0.01)"""),
        "ACCOUNTS_BILLED_OFF_SCHEDULE_Q3": q(f"select count(distinct calculated_assignment) from dp_346.fact_fee_billing_test where off_schedule_flag = 1 and calculation_run in {RELEASED}"),
        "BILLING_VARIANCE_Q3": q(f"select sum(billing_variance) from dp_346.fact_fee_billing_test where off_schedule_flag = 1 and calculation_run in {RELEASED}"),
        "HOUSEHOLD_BREAKPOINT_NOT_APPLIED_Q3": q(f"select count(*) from dp_346.fact_fee_billing_test where household_breakpoint_not_applied = 1 and calculation_run in {RELEASED}"),
        "FAILED_FEE_DEBITS_Q3": q("select count(*) from dp_305.fee_debit where fee_debit_status = 'Failed' and debit_date between date '2026-07-01' and date '2026-09-30'"),
        "FAILED_FEE_DEBIT_AMOUNT_Q3": q("select sum(debit_amount) from dp_305.fee_debit where fee_debit_status = 'Failed' and debit_date between date '2026-07-01' and date '2026-09-30'"),
        "ACTIVE_FEE_WAIVERS": q(f"select count(*) from dp_305.fee_waiver where waiver_period_start <= date '{config.AS_OF}' and (waiver_period_end is null or waiver_period_end >= date '{config.AS_OF}')"),
        "ACTIVE_FEE_SCHEDULE_VERSIONS": q(f"select count(*) from dp_305.fee_schedule where schedule_status = 'Active' and version_effective_from <= date '{config.AS_OF}' and (version_effective_to is null or version_effective_to >= date '{config.AS_OF}')"),
        "ACTIVE_FEE_SCHEDULE_ASSIGNMENTS": q(f"select count(*) from dp_305.fee_schedule_assignment where assignment_effective_from <= date '{config.AS_OF}' and (assignment_effective_to is null or assignment_effective_to >= date '{config.AS_OF}')"),
        "FEE_HOUSEHOLD_MEMBER_ACCOUNTS": q(f"""select count(distinct m.member_account) from dp_305.fee_household_membership m join dp_305.fee_household h on h.fee_household_id = m.membership_fee_household
                                            where m.fee_household_membership_status = 'Active' and h.fee_household_status = 'Active' and m.fee_household_membership_effective_from <= date '{config.AS_OF}' and (m.fee_household_membership_effective_to is null or m.fee_household_membership_effective_to >= date '{config.AS_OF}')"""),
        "TOTAL_COST_TO_SERVE_Q3": q(f"select sum(total_cost_to_serve) from dp_498.fact_cost_to_serve where dimension_grain = 'Client Segment' and profitability_period in {Q3}"),
        "ALLOCATED_COST_Q3": q(f"""select sum(x.allocated_amount) from dp_480.allocation_result x join dp_480.allocation_run r on r.allocation_run_id = x.allocation_run_key
                                 join dp_480.allocation_rule rl on rl.allocation_rule_id = x.allocated_rule
                                 where r.run_status = 'Final' and r.run_data_version = 'Actual' and r.run_period in {Q3} and rl.target_dimension = 'Channel'"""),
        "UNALLOCATED_RESIDUAL_Q3": q(f"select sum(unallocated_residual) from dp_480.allocation_run where run_status = 'Final' and run_data_version = 'Actual' and run_period in {Q3}"),
        "GROSS_REVENUE_Q3": q(f"select sum(gross_revenue) from dp_499.fact_profitability where dimension_grain = 'Business Line' and profitability_period in {Q3}"),
        "CONTRIBUTION_MARGIN_Q3": q(f"select sum(contribution_margin) from dp_499.fact_profitability where dimension_grain = 'Business Line' and profitability_period in {Q3}"),
        "OPERATING_PROFIT_Q3": q(f"select sum(operating_profit) from dp_499.fact_profitability where dimension_grain = 'Business Line' and profitability_period in {Q3}"),
        "NEGATIVE_CONTRIBUTION_CUTS": q("select count(*) from dp_499.fact_profitability where offerings_and_segments_with_negative_contribution = 1"),
    }


def main(verbose=False, rt=None):
    rt = rt or runtime.get()
    truths = json.load(open(os.path.join(_paths.OUT, "sources", "truths.json")))
    cols = AMOUNTS + COUNTS + ["client_organic_growth_rate"]
    rows = rt.fetch(rt.sql("select period_type, period_end_date, dimension_type, dimension_key, " + ", ".join(DBCOL.get(c, c) for c in cols) + " from cert.measure_wide"))
    got = {(r[0], str(r[1]), r[2], norm_key(r[2], r[3])): dict(zip(cols, r[4:])) for r in rows}
    diffs, checked = [], 0
    for t in truths["measure_values"]:
        k = (t["period_type"], t["period_end"], t["dimension_type"], t["dimension_key"])
        g = got.get(k)
        if g is None:
            diffs.append(f"missing row {k}"); continue
        checked += 1
        for c in AMOUNTS:
            if abs((g[c] or 0) - (t[c] or 0)) > 0.011:
                diffs.append(f"{k} {c}: pipeline {g[c]:.2f} vs truth {t[c]:.2f} (diff {(g[c] or 0) - (t[c] or 0):.2f})")
        for c in COUNTS:
            if int(g[c] or 0) != int(t[c] or 0):
                diffs.append(f"{k} {c}: pipeline {g[c]} vs truth {t[c]}")
        gr, tr = g["client_organic_growth_rate"], t["client_organic_growth_rate"]
        if (gr is None) != (tr is None) or (gr is not None and abs(gr - tr) > 1e-6):
            diffs.append(f"{k} client_organic_growth_rate: pipeline {gr} vs truth {tr}")
    extra = set(got) - {(t["period_type"], t["period_end"], t["dimension_type"], t["dimension_key"]) for t in truths["measure_values"]}
    if extra:
        diffs.append(f"{len(extra)} pipeline rows the truths do not have, e.g. {sorted(extra)[:3]}")
    # households
    hh = {r[0]: r[1:] for r in rt.fetch(rt.sql("""select household_key, household_members, household_client_assets, household_advised_assets, held_away_assets,
                                               households_without_primary_advisor, service_tier_qualification_mismatch, non_household_client_assets from dp_320.fact_household_360"""))}
    hdiff = 0
    for t in truths["households"]:
        g = hh.get("PTY-HH-" + t["crm_account_id"])
        if g is None:
            diffs.append(f"household {t['crm_account_id']} missing"); continue
        pairs = [("household_members", g[0]), ("household_client_assets", g[1]), ("household_advised_assets", g[2]), ("held_away_assets", g[3]),
                 ("without_primary_advisor", g[4]), ("service_tier_mismatch", g[5])]
        for name, val in pairs:
            if abs((val or 0) - (t[name] or 0)) > 0.011:
                hdiff += 1
                if hdiff <= 10:
                    diffs.append(f"household {t['crm_account_id']} {name}: pipeline {val} vs truth {t[name]}")
    if hdiff > 10:
        diffs.append(f"... {hdiff} household differences in all")
    nonhh = next(iter(hh.values()))[6] if hh else None
    if nonhh is None or abs(nonhh - truths["non_household_client_assets"]) > 0.011:
        diffs.append(f"non_household_client_assets: pipeline {nonhh} vs truth {truths['non_household_client_assets']}")
    # planted facts
    p = truths["planted"]
    planted = planted_values(rt)
    for k, v in planted.items():
        if k in p and abs(float(v or 0) - float(p[k])) > 0.011:
            diffs.append(f"planted {k}: pipeline {v} vs truth {p[k]}")
    # the institutional relationships at AS_OF: client assets and the at-risk flag per relationship
    rels = {r[0]: r[1:] for r in rt.fetch(rt.sql(f"select service_relationship_key, relationship_client_assets, at_risk_relationships from dp_510.fact_relationship_health where calendar_date_key = date '{config.AS_OF}'"))}
    rdiff = 0
    for t in truths.get("relationships", []):
        g = rels.get(t["rel_id"])
        if g is None:
            rdiff += 1; diffs.append(f"relationship {t['rel_id']} missing") if rdiff <= 10 else None; continue
        if abs((g[0] or 0) - (t["relationship_client_assets"] or 0)) > 0.011 or int(g[1] or 0) != int(bool(t["at_risk"])):
            rdiff += 1
            if rdiff <= 10:
                diffs.append(f"relationship {t['rel_id']}: pipeline assets {g[0]} at_risk {g[1]} vs truth {t['relationship_client_assets']} {t['at_risk']}")
    if truths.get("profitability") and rt.has_table(rt.entity("DP-499", "Fact Profitability")):
        prof = {(r[0], r[1], r[2]): r[3:] for r in rt.fetch(rt.sql("select profitability_period, dimension_grain, split_part(profitability_record_id, '|', 3), gross_revenue, distribution_payments, direct_sales_marketing_cost, contribution_margin, allocated_indirect_cost, operating_profit from dp_499.fact_profitability"))}
        grain = {"SEG": "Client Segment", "CHAN": "Channel", "BL": "Business Line", "OFF": "Service Offering", "TIER": "Service Tier"}
        pdiff = 0
        for t in truths["profitability"]:
            g = prof.get((f"FY{t['fiscal_month'][:4]}-M{t['fiscal_month'][5:7]}", grain.get(t["grain"], t["grain"]), t["member"]))
            vals = ["gross_revenue", "distribution_payments", "direct_sales_marketing_cost", "contribution_margin", "allocated_indirect_cost", "operating_profit"]
            if g is None:
                pdiff += 1; diffs.append(f"profitability {t['fiscal_month']} {t['grain']} {t['member']} missing") if pdiff <= 10 else None; continue
            for i, c in enumerate(vals):
                if abs((g[i] or 0) - (t[c] or 0)) > 0.011:
                    pdiff += 1
                    if pdiff <= 10:
                        diffs.append(f"profitability {t['fiscal_month']} {t['grain']} {t['member']} {c}: pipeline {g[i]:.2f} vs truth {t[c]:.2f}")
        if pdiff > 10:
            diffs.append(f"... {pdiff} profitability differences in all")
        cts = {(r[0], r[1], r[2]): r[3] for r in rt.fetch(rt.sql("select profitability_period, dimension_grain, split_part(profitability_record_id, '|', 3), total_cost_to_serve from dp_498.fact_cost_to_serve"))}
        cdiff = 0
        for t in truths.get("cost_to_serve", []):
            g = cts.get((f"FY{t['fiscal_month'][:4]}-M{t['fiscal_month'][5:7]}", grain.get(t["grain"], t["grain"]), t["member"]))
            if g is None or abs(g - (t["total"] or 0)) > 0.011:
                cdiff += 1
                if cdiff <= 10:
                    diffs.append(f"cost_to_serve {t['fiscal_month']} {t['grain']} {t['member']}: pipeline {g} vs truth {t['total']}")
        if cdiff > 10:
            diffs.append(f"... {cdiff} cost-to-serve differences in all")
        runs = {r[0]: r[1:] for r in rt.fetch(rt.sql("select fee_calculation_run_id, run_net_fee_total, (select coalesce(sum(net_fee), 0) from dp_305.account_fee_calculation c where c.calculation_run = r.fee_calculation_run_id) from dp_305.fee_run r"))}
        for t in truths.get("fee_runs", []):
            g = runs.get("FR-" + t["run_id"])
            if g is None:
                diffs.append(f"fee run {t['run_id']} missing"); continue
            if abs((g[0] or 0) - (t["net_fee_total"] or 0)) > 0.011 or abs((g[1] or 0) - (t["calc_net_fee_sum"] or 0)) > 0.011:
                diffs.append(f"fee run {t['run_id']}: pipeline total {g[0]} calcs {g[1]} vs truth {t['net_fee_total']} {t['calc_net_fee_sum']}")
    if rdiff > 10:
        diffs.append(f"... {rdiff} relationship differences in all")
    print(f"measure rows checked {checked} (truths {len(truths['measure_values'])}, pipeline {len(got)}); households {len(truths['households'])}; relationships {len(truths.get('relationships', []))}; planted {len(planted)}")
    if verbose or diffs:
        for d in diffs[:60]:
            print("  DIFF", d)
    print("RESULT:", "no differences" if not diffs else f"{len(diffs)} difference(s)")
    return 1 if diffs else 0


if __name__ == "__main__":
    sys.exit(main("--verbose" in sys.argv))
