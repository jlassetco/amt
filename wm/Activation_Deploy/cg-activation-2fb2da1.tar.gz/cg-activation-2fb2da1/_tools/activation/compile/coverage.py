"""Activation states from the built layers: for every product, entity, semantic table, metric and verified question of
the slice, whether it is enabled, partial or not started, with the reason. Written to activation/out/activation.json
for the explorer badge and the demo page.

Usage (from _tools/):  python activation/compile/coverage.py      (after semantic.py and tests.py)
"""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import _paths  # noqa: E402,F401
import config  # noqa: E402
import runtime  # noqa: E402


def main(rt=None, log=print):
    out = rt.out if rt else runtime.out_dir()
    slice_ = json.load(open(os.path.join(_paths.OUT, "slice.json")))
    compiled = json.load(open(os.path.join(out, "compiled_model.json")))
    mapping = json.load(open(os.path.join(_paths.OUT, "coverage.json")))
    physical = json.load(open(os.path.join(out, "physical_report.json")))
    derived = json.load(open(os.path.join(out, "derivation_report.json")))
    tests = json.load(open(os.path.join(out, "test_results.json"))) if os.path.exists(os.path.join(out, "test_results.json")) else {"tests": [], "summary": {}}
    entities = {}
    for key, e in slice_["entities"].items():
        pr = physical["entities"].get(key)
        if e["product"] in config.DERIVED_PRODUCTS or key in getattr(config, "DERIVED_ENTITIES", {}):
            rows = derived["counts"].get(key)
            state = "enabled"
            frm = config.DERIVED_ENTITIES.get(key) if key in getattr(config, "DERIVED_ENTITIES", {}) else config.DERIVED_PRODUCTS.get(e["product"])
            note = ("derived by firm rules from " + ", ".join(frm)) if frm else "generated from the taxonomy and the firm's own reference data"
        elif pr and pr["rows"]:
            cov = mapping["entities"].get(key, {})
            state = "enabled" if not cov.get("missing") else "partial"
            note = ("missing: " + ", ".join(cov["missing"][:6])) if cov.get("missing") else "every attribute the slice reads is mapped"
        else:
            state, note = "not started", "no source maps to this entity"
        entities[key] = dict(product=e["product"], entity=e["entity"], state=state, note=note, rows=(pr or {}).get("rows", derived["counts"].get(key, 0)),
                             mapped=mapping["entities"].get(key, {}).get("mapped", 0), used=mapping["entities"].get(key, {}).get("used", 0),
                             used_mapped=mapping["entities"].get(key, {}).get("used_mapped", 0), attrs=len(e["attrs"]), extra=e.get("extra", False))
    products = {}
    for pid, p in slice_["products"].items():
        ents = [entities[k] for k in entities if entities[k]["product"] == pid]
        states = {e["state"] for e in ents}
        state = "enabled" if states == {"enabled"} else ("not started" if states == {"not started"} else "partial")
        ts = tests["summary"].get(pid, {})
        products[pid] = dict(id=pid, name=p["name"], tier=p["tier"], state=state, entities=[e["entity"] for e in ents],
                             derived_from=config.DERIVED_PRODUCTS.get(pid, []), tests=ts.get("tests", 0), test_failures=ts.get("failures", 0),
                             missing=[f"{e['entity']}: {e['note']}" for e in ents if e["state"] == "partial"])
    metrics = [dict(model=m["model"], name=m["name"], state="enabled" if m["answerable"] else ("partial" if m["executable"] else "not started"),
                    reason=m["reason"], value_total=m["value_total"], ref=m.get("ref"), in_scope=m["in_scope"]) for m in compiled["metrics"]]
    ans = {(m["model"], m["name"]) for m in compiled["metrics"] if m["answerable"]}
    questions = []
    for qd in compiled["questions"]:
        named = [m for m in compiled["metrics"] if m["model"] == qd["model"] and (f"[{m['name']}]" in qd["answer"] or m["name"] in qd["answer"])]
        ok = [m for m in named if (m["model"], m["name"]) in ans or (m.get("ref") and m["answerable"])]
        state = "enabled" if named and len(ok) == len(named) else ("partial" if ok else "not started")
        questions.append(dict(model=qd["model"], question=qd["question"], state=state, metrics=[m["name"] for m in named],
                              missing=[m["name"] + (f" ({m['reason']})" if m["reason"] else "") for m in named if m not in ok]))
    tables = {k: dict(state="enabled" if t.get("view") and not t.get("unpopulated") else ("partial" if t.get("view") else "not started"),
                      rows=t.get("rows", 0), unpopulated=t.get("unpopulated", []), reason=t.get("reason", "")) for k, t in compiled["tables"].items()}
    n = lambda items, st: sum(1 for x in items if x["state"] == st)
    summary = dict(products={st: n(products.values(), st) for st in ("enabled", "partial", "not started")},
                   entities={st: n(entities.values(), st) for st in ("enabled", "partial", "not started")},
                   tables={st: n(tables.values(), st) for st in ("enabled", "partial", "not started")},
                   metrics={st: n([m for m in metrics if m["in_scope"] and not m["ref"]], st) for st in ("enabled", "partial", "not started")},
                   questions={st: n(questions, st) for st in ("enabled", "partial", "not started")},
                   cannot_answer=len(compiled["cannot_answer"]), gaps=len(mapping["gaps"]) + len(derived["gaps"]),
                   tests=len(tests["tests"]), test_failures=sum(1 for t in tests["tests"] if t.get("failures") and t.get("severity") != "expectation"))
    act = dict(runtime=compiled.get("runtime", "duckdb"), slice=slice_["slice"], as_of=config.AS_OF, summary=summary, products=products, entities=entities, tables=tables, metrics=metrics,
               questions=questions, cannot_answer=compiled["cannot_answer"], gaps=mapping["gaps"] + derived["gaps"])
    with open(os.path.join(out, "activation.json"), "w") as f:
        json.dump(act, f, indent=1, default=str)
    log(json.dumps(summary))
    return act


if __name__ == "__main__":
    main()
