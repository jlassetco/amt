"""Derived products: the SQL that builds DP-013 (calendar and code values), DP-192 (the worker record), DP-006 (client
flow transactions), DP-007 (account asset summaries and positions), DP-008 (the certified client-asset family), DP-320
(the household facts) and DP-495 (the identifier crosswalk and match results) from the conformed tables physical.py
built. Each step either creates a helper table in schema cert (firm rules the taxonomy does not hold) or fills one
entity of the slice (schema dp_nnn). The certified rules follow the DP-008 measure definitions as the generator brief
states them (sources/GENERATOR_BRIEF.md); check_truths.py proves the result against the generator's own computation.

Usage (from _tools/):  python activation/compile/derivations.py      (after physical.py)
"""
import datetime as dt, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import _paths  # noqa: E402,F401
sys.path.insert(0, HERE)
import config  # noqa: E402
import runtime  # noqa: E402
import slice as sl  # noqa: E402
from runtime import snake, sql_type  # noqa: E402

AS_OF = config.AS_OF
UNATTR = "UNATTRIBUTED"
GAPS = []     # (entity, note): firm rules or raw source columns the derivation had to read because the taxonomy slice has no home for them

MEASURES = [  # (column, name, aggregation behavior, treatments...)
    ("beginning_client_assets", "Beginning Client Assets", "Semi-Additive"), ("ending_client_assets", "Ending Client Assets", "Semi-Additive"),
    ("average_client_assets", "Average Client Assets", "Semi-Additive"), ("net_new_assets", "Net New Assets", "Additive"),
    ("net_inter_channel_transfers", "Net Inter-Channel Transfers", "Additive"), ("client_market_movement_and_other", "Client Market Movement and Other", "Additive"),
    ("client_organic_growth_rate", "Client Organic Growth Rate", "Non-Additive"), ("advised_assets", "Advised Assets", "Semi-Additive"),
    ("own_fund_overlap_amount", "Own-Fund Overlap Amount", "Semi-Additive"), ("client_assets_excluding_intermediary_held", "Client Assets Excluding Intermediary-Held", "Semi-Additive"),
    ("gross_sales", "Gross Sales", "Additive"), ("redemptions", "Redemptions", "Additive"), ("net_exchanges", "Net Exchanges", "Additive"),
    ("net_flows", "Net Flows", "Additive"), ("funded_accounts", "Funded Accounts", "Non-Additive"), ("clients", "Clients", "Non-Additive"),
    ("households", "Households", "Non-Additive"), ("restatement_impact", "Restatement Impact", "Additive"),
]
TREATMENTS = {  # exchange, transfer, income, fee, inter-channel, rollover
    "Net New Assets": ("Net Only", "Exclude (Same Owner)", "Exclude (Market Movement and Other)", "Exclude (Market Movement and Other)", "Inter-Channel Transfer (Zero Firm-Wide)", "Count as Net New Assets"),
    "Gross Sales": ("Exclude (Report Separately)", "Exclude (Report Separately)", "Exclude from Sales (Market Movement)", "Exclude at Product Level", "Inter-Channel Transfer (Zero Firm-Wide)", "Include in Gross"),
}
DEFAULT_TREATMENT = ("Net Only", "Include", "Exclude (Market Movement and Other)", "Exclude (Market Movement and Other)", "Inter-Channel Transfer (Zero Firm-Wide)", "Include")
CHANNEL_OF_BL = {"DB": "DIRECT_SELF_DIRECTED", "DA": "DIRECT_DIGITAL_ADVICE", "HA": "DIRECT_HUMAN_ADVICE", "TR": "DIRECT_TRUST", "PF": "DIRECT_SELF_DIRECTED", "IC": "INTERMEDIARY"}
US_HOLIDAYS_2026 = {"2026-01-01": "New Year's Day", "2026-01-19": "Martin Luther King Jr. Day", "2026-02-16": "Presidents' Day", "2026-04-03": "Good Friday",
                    "2026-05-25": "Memorial Day", "2026-06-19": "Juneteenth", "2026-07-03": "Independence Day (observed)", "2026-09-07": "Labor Day",
                    "2026-11-26": "Thanksgiving Day", "2026-12-25": "Christmas Day"}


def create_entity(rt, slice_, key, with_derived=True):
    e = slice_["entities"][key]
    cols, seen = [], set()
    for a in e["attrs"]:  # a derived measure that shares its name with a stored attribute ("Total Cost-to-Serve" and "Total Cost to Serve") is one column
        if (with_derived or not a["derived"] or a["name"] in e["pk"]) and snake(a["name"]) not in seen:
            cols.append(a); seen.add(snake(a["name"]))
    rt.create_table(rt.entity(e["product"], e["entity"]), [(snake(a["name"]), sql_type(a["type"]) if not a["derived"] else "DOUBLE") for a in cols])
    return [snake(a["name"]) for a in cols]


def fill(rt, slice_, key, select_sql):
    """Creates the entity table and inserts the select; every select column must be an attribute of the entity."""
    select_sql = rt.sql(dialect(rt, select_sql))
    cols = create_entity(rt, slice_, key)
    got = rt.select_columns(select_sql)
    bad = [c for c in got if c not in cols]
    if bad:
        raise SystemExit(f"{key}: the derivation produces columns that are not attributes of the entity: {bad}")
    e = slice_["entities"][key]
    tbl = rt.entity(e["product"], e["entity"])
    rt.insert_select(tbl, got, f"select * from ({select_sql}) x")
    return rt.count(tbl)


def ctas(rt, name, sql):
    rt.create_table_as(rt.sql(name), rt.sql(dialect(rt, sql)))


def dialect(rt, sql):
    """The few helpers that differ by engine, spelled as placeholders in the SQL above."""
    return (sql.replace("__LIST_HAS__", rt.list_has("r.serviced_mandates", "m.mandate_id"))
               .replace("__FMT8__", rt.fmt8("s.summary_as_of_date")).replace("__FMT8G__", rt.fmt8("g.month_end")))


# ------------------------------------------------------------------------------------------------- DP-013
def build_dp013(rt, slice_):
    create_entity(rt, slice_, "DP-013/Calendar Date")
    d = dt.date(2026, 1, 1); rows = []
    while d.year == 2026:
        hol = US_HOLIDAYS_2026.get(d.isoformat())
        typ = "Holiday" if hol else ("Weekend" if d.weekday() >= 5 else "Business Day")
        rows.append(("CAL-REPORTING", d, typ, hol, 1.0 if typ == "Business Day" else 0.0)); d += dt.timedelta(days=1)
    rt.insert_rows(rt.entity("DP-013", "Calendar Date"), ["calendar_key", "calendar_date", "day_type", "holiday_name", "business_day_indicator"], rows)
    create_entity(rt, slice_, "DP-013/Code Value")
    seen, rows = set(), []
    for (dom, name), vals in sl.code_lists().items():
        lname = name.replace("Shared: ", "")
        for label, desc, code in vals:
            if (lname, code) in seen:
                continue
            seen.add((lname, code)); rows.append((lname, code, label, None, "Active", None))
    rt.insert_rows(rt.entity("DP-013", "Code Value"), ["code_list_key", "code", "code_label", "parent_code", "code_value_status", "replaced_by_code"], rows)
    GAPS.append(("DP-013/Code Value", "Code List Key is the list name; local lists of the same name in several domains are merged by code"))
    build_dp013_reference(rt, slice_)
    return len(rows)


def build_dp013_reference(rt, slice_):
    """The firm's own reference entities that the shared dimensions read when they are in the slice: fiscal periods (the
    fiscal calendar is the calendar year), the internal legal entities the portfolio book and the register name, and the
    org units. Firm-defined content, so generated here rather than mapped from a source."""
    as_of = dt.date.fromisoformat(config.AS_OF)
    if "DP-013/Fiscal Period" in slice_["entities"]:
        create_entity(rt, slice_, "DP-013/Fiscal Period"); rows = []
        for y in (2025, 2026):
            for m in range(1, 13):
                start = dt.date(y, m, 1); end = (dt.date(y + (m == 12), m % 12 + 1, 1) - dt.timedelta(days=1))
                rows.append(("CAL-FISCAL", f"FY{y}-M{m:02d}", y, "MONTH", start, end, "Closed" if end < as_of else ("Soft Close" if start <= as_of else "Future")))
            for qn in range(1, 5):
                start = dt.date(y, 3 * qn - 2, 1); end = (dt.date(y + (qn == 4), (3 * qn) % 12 + 1, 1) - dt.timedelta(days=1))
                rows.append(("CAL-FISCAL", f"FY{y}-Q{qn}", y, "QUARTER", start, end, "Closed" if end < as_of else ("Soft Close" if start <= as_of else "Future")))
        rt.insert_rows(rt.entity("DP-013", "Fiscal Period"), ["calendar_key", "fiscal_period_id", "fiscal_year", "fiscal_period_type", "period_start_date", "period_end_date", "fiscal_period_status"], rows)
    if "DP-013/Internal Legal Entity" in slice_["entities"]:
        create_entity(rt, slice_, "DP-013/Internal Legal Entity")
        rows = [("LE-HC", "The Firm Holdings, Inc.", "Parent Holding Company", "US-PA", "Active", 0.0, None, "1000"),
                ("LE-IA", "The Firm Advisers, Inc.", "Registered Investment Adviser", "US-PA", "Active", 0.0, "LE-HC", "1100"),
                ("LE-BD", "The Firm Brokerage Services LLC", "Broker-Dealer (self-clearing)", "US-PA", "Active", 0.0, "LE-HC", "1200"),
                ("LE-TA", "The Firm Shareholder Services, Inc.", "Transfer Agent", "US-PA", "Active", 0.0, "LE-HC", "1300"),
                ("LE-FT", "The Firm Funds Trust", "Fund Trust (registrant)", "US-DE", "Active", 0.0, None, "1400"),
                ("LE-TC", "The Firm Trust Company, N.A.", "National Trust Company", "US-PA", "Active", 0.0, "LE-HC", "1500")]
        rt.insert_rows(rt.entity("DP-013", "Internal Legal Entity"), ["legal_entity_id", "legal_name", "entity_category", "jurisdiction_of_formation", "entity_status", "branch_indicator", "head_office_entity", "accounting_company_code"], rows)
    if "DP-013/Org Unit" in slice_["entities"]:
        create_entity(rt, slice_, "DP-013/Org Unit")
        rows = [("OU-RETAIL", "Personal Investor", "Division", "Distribution", "LE-BD", dt.date(2020, 1, 1)),
                ("OU-INST", "Institutional Investor", "Division", "Distribution", "LE-IA", dt.date(2020, 1, 1)),
                ("OU-WORK", "Workplace", "Division", "Distribution", "LE-IA", dt.date(2020, 1, 1)),
                ("OU-IM", "Investment Management", "Division", "Investment Management", "LE-IA", dt.date(2020, 1, 1)),
                ("OU-INST-SEP", "Institutional Separate Accounts", "Business Unit", "Distribution", "LE-IA", dt.date(2020, 1, 1)),
                ("OU-INST-OCIO", "Outsourced CIO", "Business Unit", "Distribution", "LE-IA", dt.date(2021, 7, 1))]
        rt.insert_rows(rt.entity("DP-013", "Org Unit"), ["org_unit_id", "org_unit_name", "org_unit_type", "business_function", "employing_booking_entity", "org_unit_effective_from"], rows)


# ------------------------------------------------------------------------------------------------- helpers (cert)
HELPERS = [
    # institutional accounts: which client party and service relationship each separate-account portfolio and direct
    # institutional fund account belongs to, and the channel that follows from the relationship (OCIO; consultant-led
    # when the relationship has an advising consultant; direct otherwise). The fund-account link is read from the
    # platform's FUND_ACCOUNT list (no taxonomy home for an account-to-relationship link: a declared gap).
    ("cert.inst_account", """
        with rel_mandate as (
               select r.service_relationship_id, r.client, r.servicing_segment, r.advising_consultant, m.mandate_id
               from dp_510.service_relationship r join dp_003.investment_mandate m on __LIST_HAS__),
             pa as (select a.account_id, rm.service_relationship_id, rm.client, rm.servicing_segment, rm.advising_consultant, 'IA' as business_line_code
                    from dp_093.account a join rel_mandate rm on rm.mandate_id = a.related_mandate
                    where a.account_type = 'Institutional Separate Account'),
             fa as (select 'ACC-TA-' || f."TA_ACCT_NO" as account_id, r.service_relationship_id, r.client, r.servicing_segment, r.advising_consultant, 'PF' as business_line_code
                    from src_inst."FUND_ACCOUNT" f join dp_510.service_relationship r on r.service_relationship_id = f."REL_ID"),
             u as (select * from pa union all select * from fa)
        select u.account_id, u.service_relationship_id, u.client as client_party, u.servicing_segment, u.business_line_code,
               case when u.servicing_segment = 'OCIO' then 'INSTITUTIONAL_OCIO' when u.advising_consultant is not null then 'INSTITUTIONAL_CONSULTANT'
                    else 'INSTITUTIONAL_DIRECT' end as channel_code
        from u"""),
    ("cert.instrument_ht", """
        select instrument_id, own_share_class,
               case when instrument_type = 'Own Fund Share Class' then
                         (case when asset_class = 'Cash & Money Market' then 'Cash and Sweep' when fund_vehicle_type = 'Exchange-Traded Fund' then 'Own ETF' else 'Own Mutual Fund' end)
                    when instrument_type = 'Third-Party Fund' then
                         (case when asset_class = 'Cash & Money Market' then 'Cash and Sweep' when fund_vehicle_type = 'Exchange-Traded Fund' then 'Third-Party ETF' else 'Third-Party Mutual Fund' end)
                    when instrument_type = 'Equity Share' then 'Equity'
                    when instrument_type in ('Corporate Bond', 'Certificate of Deposit') then 'Fixed Income and CDs'
                    when instrument_type = 'Other' then 'Other' end as holding_type,
               instrument_type = 'Own Fund Share Class' as is_own
        from dp_097.instrument"""),
    ("cert.share_class_ht", """
        select s.share_class_id,
               case when p.product_asset_class = 'Money Market' then 'Cash and Sweep' when p.vehicle_type = 'Exchange-Traded Fund' then 'Own ETF' else 'Own Mutual Fund' end as holding_type
        from dp_004.share_class s left join dp_004.investment_product p on p.product_id = s.parent_product"""),
    ("cert.account_attr", f"""
        with owner as (select role_account, min(role_party) as person from dp_093.account_party_role where account_role_type = 'Primary Owner' group by 1),
             hh as (select household_member as person, min(household) as household from dp_240.household_membership
                    where membership_status = 'Active' and (membership_effective_to is null or membership_effective_to > date '{AS_OF}') group by 1),
             adv as (select covered_party as household, min(covering_advisor) as advisor from dp_009.coverage_assignment where party_coverage_role = 'Primary Advisor' group by 1),
             seg as (select segmented_party as household, min(segment) as segment from dp_240.segment_assignment where segmentation_scheme = 'Client Value Segment' group by 1),
             enr as (select enrolled_account, max(case when enrollment_status = 'Active' then 1 else 0 end) as active from dp_093.program_enrollment group by 1),
             cat as (select register_account, max(register_account_category) as category from dp_580.register_position group by 1),
             bl as (select code, code_label from dp_013.code_value where code_list_key = 'Business Line')
        select a.account_id, a.account_type, a.account_business_line, coalesce(ia.business_line_code, bl.code) as business_line_code,
               coalesce(ia.channel_code, case bl.code when 'DB' then 'DIRECT_SELF_DIRECTED' when 'DA' then 'DIRECT_DIGITAL_ADVICE' when 'HA' then 'DIRECT_HUMAN_ADVICE'
                            when 'TR' then 'DIRECT_TRUST' when 'PF' then 'DIRECT_SELF_DIRECTED' when 'IC' then 'INTERMEDIARY' end) as channel_code,
               coalesce(o.person, ia.client_party) as person, case when o.person like 'PTY-BRK-%' or ia.account_id is not null then null else h.household end as household, ad.advisor, s.segment,
               ia.service_relationship_id, ia.client_party as institutional_client,
               a.account_type in ('Omnibus Account at Transfer Agent', 'Networked Investor Account') as intermediary,
               coalesce(c.category = 'Broker-Dealer Omnibus', false) as affiliated_omnibus,
               (a.account_type = 'Fiduciary Account' or (a.account_type = 'Managed Advisory Account' and coalesce(e.active, 0) = 1)) as advised,
               a.account_id like 'ACC-TA-%' as on_register
        from dp_093.account a
        left join bl on bl.code_label = a.account_business_line
        left join owner o on o.role_account = a.account_id
        left join hh h on h.person = o.person
        left join adv ad on ad.household = h.household
        left join seg s on s.household = h.household
        left join enr e on e.enrolled_account = a.account_id
        left join cat c on c.register_account = a.account_id
        left join cert.inst_account ia on ia.account_id = a.account_id"""),
]


# The share of each dimension member in the firm's own-fund holdings at the latest month-end on or before each fiscal
# month (the attribution key for own-fund fee revenue in DP-499): channels and business lines from the certified family's
# own-fund overlap, segments and offerings from the accounts' own-fund asset summaries.
OWN_FUND_SHARE = """
    with own as (select as_of as month_end, dimension_type, dimension_key, account, value from cert.asset_dim where is_own),
         total as (select month_end, sum(value) as t from own where dimension_type = 'Total' group by 1),
         me as (select month_end from total),
         months as (select distinct run_period from dp_480.allocation_run where run_status = 'Final' and run_data_version = 'Actual'),
         pick as (select m.run_period, (select max(month_end) from me where cast(month_end as varchar) <= substr(m.run_period, 3, 4) || '-' || substr(m.run_period, 9, 2) || '-31') as month_end from months m),
         pick2 as (select run_period, coalesce(month_end, (select min(month_end) from me)) as month_end from pick),
         fam as (select month_end, case dimension_type when 'Segment' then 'Client Segment' else dimension_type end as grain, dimension_key as member, sum(value) as v
                 from own where dimension_type in ('Channel', 'Business Line', 'Segment') group by 1, 2, 3),
         offs as (select o.month_end, 'Service Offering' as grain,
                         coalesce(replace(e.enrolled_service_offering, 'OFF-', ''), case when o.account like 'ACC-BRK-%' then 'BRK' else 'UNATTRIBUTED' end) as member, sum(o.value) as v
                  from own o left join dp_093.program_enrollment e on e.enrolled_account = o.account and e.enrollment_status = 'Active'
                  where o.dimension_type = 'Total' group by 1, 2, 3),
         all_ as (select * from fam union all select * from offs)
    select p.run_period, c.grain, c.member, c.v / nullif(t.t, 0) as share
    from pick2 p join all_ c on c.month_end = p.month_end join total t on t.month_end = c.month_end"""


# ------------------------------------------------------------------------------------------------- DP-192
DP192 = """
    select 'EMP-' || u.Employee_Number__c as employee_id, u.Employee_Number__c as hr_employee_number, u."Name" as preferred_name,
           u."Title" as job_title, 'Employee' as employment_type,
           case when lower(u.IsActive) = 'true' then 'Active' else 'Terminated' end as employment_status
    from src_crm."User" u"""

# ------------------------------------------------------------------------------------------------- DP-006
DP006_TRANSACTION = """
    with act as (select a.*, r."XFER_TYPE_CD" as xfer, r."CONTRA_ACCT_NO" as contra, r."CONTRA_FIRM_CD" as contra_firm
                 from dp_300.client_account_activity a join src_brk."ACTIVITY" r on 'CLACT-' || r."TXN_ID" = a.client_account_activity_id),
         reversed as (select reversed_activity as id from act where activity_status = 'Reversed' and reversed_activity is not null),
         brk as (
           select 'TXN-' || a.client_account_activity_id as transaction_id, a.client_account_activity_id as source_transaction_reference,
                  case a.activity_type when 'Money Movement In' then 'Cash Deposit' when 'Money Movement Out' then 'Cash Withdrawal'
                       when 'Journal' then (case when a.activity_net_amount >= 0 then 'Journal In' else 'Journal Out' end)
                       when 'Account Transfer In' then (case a.xfer when 'ACATS' then 'ACATS Transfer In' when 'ROLLOVER' then 'Rollover In' else 'Securities Received' end)
                       when 'Account Transfer Out' then (case a.xfer when 'ACATS' then 'ACATS Transfer Out' else 'Securities Delivered' end)
                       when 'Fund Purchase' then 'Purchase' when 'Fund Redemption' then 'Redemption' end as transaction_type,
                  case when a.activity_type in ('Money Movement In', 'Account Transfer In', 'Fund Purchase') or (a.activity_type = 'Journal' and a.activity_net_amount >= 0) then 'Inflow' else 'Outflow' end as flow_direction,
                  case when a.activity_type in ('Fund Purchase', 'Fund Redemption') then 'Fund Flow'
                       when a.activity_type = 'Journal' and ca.person = oa.person and ca.channel_code <> oa.channel_code then 'Inter-Channel Transfer'
                       else 'Client Asset Flow' end as flow_scope,
                  coalesce(i.holding_type, case when a.activity_instrument is null then 'Cash and Sweep' end) as holding_type,
                  i.own_share_class as share_class, a.activity_account as account, a.trade_date, a.settlement_date,
                  abs(a.activity_net_amount) as gross_amount,
                  case when a.activity_type = 'Account Transfer In' then abs(a.activity_net_amount) else a.activity_net_amount end as reporting_currency_amount,
                  'Brokerage Book of Record (49)' as flow_source_book, a.client_account_activity_id as source_client_account_activity,
                  case when a.activity_status = 'Pending' then 'Pending' when a.activity_status = 'Reversed' then 'Reversed'
                       when a.client_account_activity_id in (select id from reversed) then 'Canceled' else 'Settled' end as transaction_status,
                  case when a.reversed_activity is not null then 'TXN-' || a.reversed_activity end as original_transaction_id,
                  a.activity_currency as currency
           from act a
           left join cert.instrument_ht i on i.instrument_id = a.activity_instrument
           left join cert.account_attr ca on ca.account_id = a.activity_account
           left join cert.account_attr oa on oa.account_id = 'ACC-BRK-' || a.contra
           where a.activity_type in ('Money Movement In', 'Money Movement Out', 'Journal', 'Account Transfer In', 'Account Transfer Out')
              or (a.activity_type in ('Fund Purchase', 'Fund Redemption') and coalesce(i.is_own, false))),
         reg as (select t.*, r."SOURCE_CD" as source_cd from dp_580.register_transaction t join src_ta."TRANSACTION" r on 'RGTX-' || r."CONFIRM_NO" = t.register_transaction_id),
         reg_reversed as (select reversed_register_transaction as id from reg where register_transaction_status = 'Reversed' and reversed_register_transaction is not null),
         mirror as (   -- the brokerage fund trade behind each affiliated-omnibus register trade (the look-through)
           select t.register_transaction_id, b.client_account_activity_id,
                  row_number() over (partition by t.register_transaction_id order by b.client_account_activity_id) as rn
           from reg t join cert.account_attr ta on ta.account_id = t.posting_account and ta.affiliated_omnibus
           join dp_300.client_account_activity b on b.trade_date = t.register_trade_date and abs(b.activity_net_amount) = t.net_amount
                and b.activity_type = (case t.register_transaction_type when 'Purchase' then 'Fund Purchase' when 'Redemption' then 'Fund Redemption' end)
           join dp_097.instrument i on i.instrument_id = b.activity_instrument and i.own_share_class = t.posting_share_class),
         ta as (
           select 'TXN-' || t.register_transaction_id as transaction_id, t.register_transaction_id as source_transaction_reference,
                  case t.register_transaction_type when 'Fund Share Transfer In' then 'Transfer In' when 'Fund Share Transfer Out' then 'Transfer Out'
                       when 'Dividend Reinvestment' then 'Reinvestment' when 'Capital Gain Reinvestment' then 'Reinvestment'
                       when 'Share Class Conversion In' then 'Share Class Conversion' when 'Share Class Conversion Out' then 'Share Class Conversion'
                       else t.register_transaction_type end as transaction_type,
                  t.share_movement_direction as flow_direction,
                  case when ta.affiliated_omnibus then 'Fund Flow'
                       when t.register_transaction_type in ('Purchase', 'Redemption', 'Fund Share Transfer In', 'Fund Share Transfer Out') then 'Client Asset and Fund Flow'
                       else 'Fund Flow' end as flow_scope,
                  h.holding_type, t.posting_share_class as share_class, t.posting_account as account, t.register_trade_date as trade_date, t.register_settlement_date as settlement_date,
                  abs(t.net_amount) as gross_amount,
                  case when t.share_movement_direction = 'Outflow' then -abs(t.net_amount) else abs(t.net_amount) end as reporting_currency_amount,
                  'Transfer Agent Register (29)' as flow_source_book, m.client_account_activity_id as source_client_account_activity,
                  case when t.register_transaction_status = 'Reversed' then 'Reversed' when t.register_transaction_id in (select id from reg_reversed) then 'Canceled' else 'Settled' end as transaction_status,
                  case when t.reversed_register_transaction is not null then 'TXN-' || t.reversed_register_transaction end as original_transaction_id,
                  t.register_transaction_currency as currency,
                  case t.source_cd when 'FS' then 'NSCC Fund/SERV' when 'DR' then 'TA Direct' when 'OM' then 'Affiliated Broker-Dealer Omnibus' when 'RK' then 'Recordkeeper File' end as order_entry_channel,
                  t.register_transaction_id as source_register_transaction
           from reg t
           left join cert.account_attr ta on ta.account_id = t.posting_account
           left join cert.share_class_ht h on h.share_class_id = t.posting_share_class
           left join mirror m on m.register_transaction_id = t.register_transaction_id and m.rn = 1
           where t.register_transaction_type is not null)      -- the cash dividend code (111) is a distribution payment, not a share movement
    select transaction_id, source_transaction_reference, transaction_type, flow_direction, flow_scope, holding_type, share_class, account, trade_date, settlement_date,
           gross_amount, reporting_currency_amount, flow_source_book, source_client_account_activity, transaction_status, original_transaction_id,
           cast(null as string) as source_register_transaction, cast(null as string) as order_entry_channel
    from brk
    union all
    select transaction_id, source_transaction_reference, transaction_type, flow_direction, flow_scope, holding_type, share_class, account, trade_date, settlement_date,
           gross_amount, reporting_currency_amount, flow_source_book, source_client_account_activity, transaction_status, original_transaction_id,
           source_register_transaction, order_entry_channel
    from ta"""

DP006_LINKED = """
    with act as (select a.client_account_activity_id as id, a.activity_account, a.trade_date, a.activity_net_amount as net, r."CONTRA_ACCT_NO" as contra
                 from dp_300.client_account_activity a join src_brk."ACTIVITY" r on 'CLACT-' || r."TXN_ID" = a.client_account_activity_id
                 where a.activity_type = 'Journal' and r."CONTRA_ACCT_NO" is not null),
         pairs as (
           select x.id, y.id as other, row_number() over (partition by x.id order by y.id) as rn
           from act x join act y on y.activity_account = 'ACC-BRK-' || x.contra and x.activity_account = 'ACC-BRK-' || y.contra
                                and y.trade_date = x.trade_date and y.net = -x.net and y.id <> x.id),
         ch as (select code, code_label from dp_013.code_value where code_list_key = 'Distribution Channel')
    select 'TXN-' || p.id as transaction_key, 'TXN-' || p.other as linked_transaction_id, 'Intra-Firm' as transfer_type,
           (a.person = b.person) as same_owner_indicator,
           (case when x.net < 0 then cha.code_label else chb.code_label end) as from_distribution_channel,
           (case when x.net < 0 then chb.code_label else cha.code_label end) as to_distribution_channel
    from pairs p join act x on x.id = p.id join act y on y.id = p.other
    left join cert.account_attr a on a.account_id = x.activity_account left join cert.account_attr b on b.account_id = y.activity_account
    left join ch cha on cha.code = a.channel_code left join ch chb on chb.code = b.channel_code
    where p.rn = 1"""

# ------------------------------------------------------------------------------------------------- DP-007
DP007_SUMMARY = """
    with ch as (select code, code_label from dp_013.code_value where code_list_key = 'Distribution Channel'),
         rows_ as (
           select h.holding_account as account, h.client_holding_date as as_of, coalesce(i.holding_type, 'UNATTRIBUTED') as holding_type,
                  'Brokerage Book of Record (49)' as book, h.market_value_in_usd as mv, coalesce(i.is_own, false) as own
           from dp_300.client_holding h left join cert.instrument_ht i on i.instrument_id = h.held_instrument
           where h.client_holding_view = 'End of Day'
           union all
           select c.cash_balance_account, c.cash_balance_business_date, 'Cash and Sweep', 'Brokerage Book of Record (49)', c.cash_balance_amount, false
           from dp_300.cash_balance c where c.balance_basis = 'Settlement Date'
           union all
           select 'ACC-PAB-' || h.holding_portfolio, h.holding_date, coalesce(i.holding_type, 'UNATTRIBUTED'), 'Institutional Portfolio Book (18)', h.market_value_base, coalesce(i.is_own, false)
           from dp_142.portfolio_holding h left join cert.instrument_ht i on i.instrument_id = h.held_instrument where h.holding_view = 'End of Day'
           union all
           select 'ACC-PAB-' || v.valued_portfolio, v.valuation_as_of_date, 'Cash and Sweep', 'Institutional Portfolio Book (18)',
                  coalesce(v.total_cash_balance, 0) + coalesce(v.total_accrued_income, 0), false
           from dp_142.portfolio_valuation_summary v where v.valuation_view = 'End of Day'
           union all
           select p.register_account, p.register_business_date, s.holding_type, 'Transfer Agent Register (29)', raw.mv, true
           from dp_580.register_position p
           join cert.account_attr a on a.account_id = p.register_account and not a.intermediary and not a.affiliated_omnibus
           left join cert.share_class_ht s on s.share_class_id = p.register_share_class
           join (select 'ACC-TA-' || "ACCT_NO" as acct, 'SHC-' || "FUND_NO" as shc, cast(try_strptime("ASOF_DT", '%Y%m%d') as date) as d, try_cast("MKT_VAL" as double) as mv from src_ta."POSITION") raw
                on raw.acct = p.register_account and raw.shc = p.register_share_class and raw.d = p.register_business_date)
    select r.account as summary_account, r.as_of as summary_as_of_date, r.holding_type as summary_holding_type, min(r.book) as summary_source_book,
           sum(r.mv) as summary_market_value, bool_or(r.own) as own_product_indicator, min(ch.code_label) as summary_distribution_channel,
           bool_or(a.advised) as advised_assets_indicator
    from rows_ r left join cert.account_attr a on a.account_id = r.account left join ch on ch.code = a.channel_code
    group by r.account, r.as_of, r.holding_type"""

DP007_POSITION = """
    select 'POS-' || p.register_account || '-' || p.register_share_class || '-' || strftime(p.register_business_date, '%Y%m%d') as position_id,
           p.register_account as account, p.register_share_class as share_class, p.register_business_date as valuation_date,
           'Transfer Agent Register (29)' as position_source_book, p.register_account_category,
           case when a.affiliated_omnibus then 'Excluded - Omnibus or Nominee' else 'Counted - Intermediary' end as aggregation_role,
           p.collected_shares as units_held, raw.mv as market_value, p.register_account as omnibus_parent_account, cast(null as double) as omnibus_residual_amount
    from dp_580.register_position p
    join cert.account_attr a on a.account_id = p.register_account and (a.intermediary or a.affiliated_omnibus)
    join (select 'ACC-TA-' || "ACCT_NO" as acct, 'SHC-' || "FUND_NO" as shc, cast(try_strptime("ASOF_DT", '%Y%m%d') as date) as d, try_cast("MKT_VAL" as double) as mv from src_ta."POSITION") raw
         on raw.acct = p.register_account and raw.shc = p.register_share_class and raw.d = p.register_business_date"""

# ------------------------------------------------------------------------------------------------- DP-008
def build_dp008(rt, slice_):
    """The certified family: asset and flow facts attributed to every dimension, then the measure rows per period."""
    month_ends = [r[0] for r in rt.fetch(rt.sql("select distinct summary_as_of_date from dp_007.account_asset_summary order by 1"))]
    if len(month_ends) < 2:
        raise SystemExit("DP-008 needs at least two month-ends of asset summaries")
    periods = []
    for i in range(1, len(month_ends)):
        periods.append(("Month", month_ends[i - 1], month_ends[i], 1))
    if len(month_ends) == 4:
        periods.append(("Quarter", month_ends[0], month_ends[3], 3))
    ctas(rt, "cert.period", "select * from (values " + ", ".join(
        f"('{p[0]}', date '{p[1]}', date '{p[2]}', {p[3]}, 'RP-{p[2].strftime('%Y-%m')}-{p[0][0]}')" for p in periods) +
        ") as t(period_type, begin_end, period_end, months, reporting_period_id)")
    # asset facts: counted rows (account summaries plus counted intermediary positions)
    ctas(rt, "cert.asset_fact", """
        select s.summary_account as account, s.summary_as_of_date as as_of, s.summary_market_value as value, s.summary_holding_type as holding_type,
               cast(null as string) as share_class, s.own_product_indicator as is_own
        from dp_007.account_asset_summary s
        union all
        select p.account, p.valuation_date, p.market_value, h.holding_type, p.share_class, true
        from dp_007.position p left join cert.share_class_ht h on h.share_class_id = p.share_class where p.aggregation_role = 'Counted - Intermediary'""")
    # share class of brokerage own-fund holdings is on the holding, not the summary: rebuild the share-class slice from holdings
    ctas(rt, "cert.asset_fact_sc", """
        select h.holding_account as account, h.client_holding_date as as_of, h.market_value_in_usd as value, coalesce(i.holding_type, 'UNATTRIBUTED') as holding_type,
               i.own_share_class as share_class, coalesce(i.is_own, false) as is_own
        from dp_300.client_holding h left join cert.instrument_ht i on i.instrument_id = h.held_instrument where h.client_holding_view = 'End of Day'
        union all
        select c.cash_balance_account, c.cash_balance_business_date, c.cash_balance_amount, 'Cash and Sweep', null, false
        from dp_300.cash_balance c where c.balance_basis = 'Settlement Date'
        union all
        select 'ACC-PAB-' || h.holding_portfolio, h.holding_date, h.market_value_base, coalesce(i.holding_type, 'UNATTRIBUTED'), i.own_share_class, coalesce(i.is_own, false)
        from dp_142.portfolio_holding h left join cert.instrument_ht i on i.instrument_id = h.held_instrument where h.holding_view = 'End of Day'
        union all
        select 'ACC-PAB-' || v.valued_portfolio, v.valuation_as_of_date, coalesce(v.total_cash_balance, 0) + coalesce(v.total_accrued_income, 0), 'Cash and Sweep', null, false
        from dp_142.portfolio_valuation_summary v where v.valuation_view = 'End of Day'
        union all
        select p.register_account, p.register_business_date, raw.mv, s.holding_type, p.register_share_class, true
        from dp_580.register_position p join cert.account_attr a on a.account_id = p.register_account and not a.affiliated_omnibus
        left join cert.share_class_ht s on s.share_class_id = p.register_share_class
        join (select 'ACC-TA-' || "ACCT_NO" as acct, 'SHC-' || "FUND_NO" as shc, cast(try_strptime("ASOF_DT", '%Y%m%d') as date) as d, try_cast("MKT_VAL" as double) as mv from src_ta."POSITION") raw
             on raw.acct = p.register_account and raw.shc = p.register_share_class and raw.d = p.register_business_date""")
    # flow facts from DP-006: current transactions only; the attribution account of an omnibus trade is the mirrored brokerage account
    ctas(rt, "cert.flow_fact", """
        with cur as (select t.*, coalesce(b.activity_account, t.account) as attr_account
                     from dp_006.transaction t
                     left join dp_300.client_account_activity b on b.client_account_activity_id = t.source_client_account_activity and t.flow_source_book like 'Transfer Agent%'
                     where t.transaction_status not in ('Canceled', 'Reversed', 'Rejected', 'Pending'))
        select trade_date, attr_account as account, holding_type, share_class, 'nna' as measure, reporting_currency_amount as amount
        from cur where flow_scope in ('Client Asset Flow', 'Client Asset and Fund Flow')
              and (transaction_type in ('Cash Deposit', 'Cash Withdrawal', 'ACATS Transfer In', 'ACATS Transfer Out', 'Securities Received', 'Securities Delivered', 'Rollover In', 'Purchase', 'Redemption', 'Transfer In', 'Transfer Out')
                   or (transaction_type in ('Journal In', 'Journal Out') and not exists (select 1 from dp_006.linked_transaction l where l.transaction_key = cur.transaction_id and l.same_owner_indicator)))
        union all
        select trade_date, attr_account, holding_type, share_class, 'nict', reporting_currency_amount from cur where flow_scope = 'Inter-Channel Transfer'
        union all
        select trade_date, attr_account, holding_type, share_class, 'gross', gross_amount from cur where flow_source_book like 'Transfer Agent%' and transaction_type = 'Purchase'
        union all
        select trade_date, attr_account, holding_type, share_class, 'redemptions', gross_amount from cur where flow_source_book like 'Transfer Agent%' and transaction_type = 'Redemption'
        union all
        select trade_date, attr_account, holding_type, share_class, 'exchanges', reporting_currency_amount from cur where flow_source_book like 'Transfer Agent%' and transaction_type in ('Exchange In', 'Exchange Out')""")
    GAPS.append(("DP-008/Measure Value", "The distribution channel of an account is derived from its business line (06 Account Channel Assignment is outside the slice)"))
    dims = {"Total": "'ALL'", "Channel": "coalesce(a.channel_code, 'UNATTRIBUTED')", "Holding Type": "coalesce(f.holding_type, 'UNATTRIBUTED')",
            "Business Line": "coalesce(a.business_line_code, 'UNATTRIBUTED')", "Advisor": "coalesce(a.advisor, 'UNATTRIBUTED')",
            "Segment": "coalesce(a.segment, 'UNATTRIBUTED')", "Share Class": "coalesce(f.share_class, 'UNATTRIBUTED')"}
    def attributed(src, extra):
        return " union all ".join(f"select '{d}' as dimension_type, {k} as dimension_key, f.*, a.person, a.household, a.advised, a.intermediary from {src} f left join cert.account_attr a on a.account_id = f.account"
                                  for d, k in dims.items())
    # every dimension is attributed at position level (cert.asset_fact_sc): the summary's own-product flag is per row, not per dollar
    ctas(rt, "cert.asset_dim", attributed("cert.asset_fact_sc", ""))
    ctas(rt, "cert.flow_dim", attributed("cert.flow_fact", ""))
    ctas(rt, "cert.keys", """
        select distinct dimension_type, dimension_key from cert.asset_dim union select distinct dimension_type, dimension_key from cert.flow_dim""")
    ctas(rt, "cert.measure_wide", f"""
        with grid as (select p.*, k.dimension_type, k.dimension_key from cert.period p cross join cert.keys k),
             bal as (select dimension_type, dimension_key, as_of, sum(value) as e, sum(case when advised then value else 0 end) as adv,
                            sum(case when is_own then value else 0 end) as own, sum(case when intermediary then value else 0 end) as inter
                     from cert.asset_dim group by 1, 2, 3),
             funded as (select dimension_type, dimension_key, as_of, count(*) as accts, count(distinct person) as persons, count(distinct household) as hhs
                        from (select dimension_type, dimension_key, as_of, account, max(person) as person, max(household) as household, sum(value) as v
                              from cert.asset_dim group by 1, 2, 3, 4) t where v > 0 group by 1, 2, 3),
             fl as (select g.reporting_period_id, f.dimension_type, f.dimension_key, f.measure, sum(f.amount) as amount
                    from cert.flow_dim f join cert.period g on f.trade_date > g.begin_end and f.trade_date <= g.period_end group by 1, 2, 3, 4),
             avgq as (select g.reporting_period_id, b.dimension_type, b.dimension_key, avg(b.e) as avg_e
                      from cert.period g join bal b on b.as_of > g.begin_end and b.as_of <= g.period_end where g.months > 1 group by 1, 2, 3)
        select g.period_type, {rt.add_days('g.begin_end', 1)} as period_start_date, g.period_end as period_end_date, g.reporting_period_id, g.months,
               g.dimension_type, g.dimension_key,
               coalesce(b0.e, 0) as beginning_client_assets, coalesce(b1.e, 0) as ending_client_assets,
               case when g.months = 1 then round((coalesce(b0.e, 0) + coalesce(b1.e, 0)) / 2, 2) else round(coalesce(q.avg_e, 0), 2) end as average_client_assets,
               coalesce(nna.amount, 0) as net_new_assets, coalesce(nict.amount, 0) as net_inter_channel_transfers,
               coalesce(b1.e, 0) - coalesce(b0.e, 0) - coalesce(nna.amount, 0) - coalesce(nict.amount, 0) as client_market_movement_and_other,
               case when coalesce(b0.e, 0) <> 0 then round(coalesce(nna.amount, 0) * 12 / g.months / b0.e, 8) end as client_organic_growth_rate,
               coalesce(b1.adv, 0) as advised_assets, coalesce(b1.own, 0) as own_fund_overlap_amount,
               coalesce(b1.e, 0) - coalesce(b1.inter, 0) as client_assets_excluding_intermediary_held,
               coalesce(gs.amount, 0) as gross_sales, coalesce(rd.amount, 0) as redemptions, coalesce(ex.amount, 0) as net_exchanges,
               coalesce(gs.amount, 0) - coalesce(rd.amount, 0) + coalesce(ex.amount, 0) as net_flows,
               coalesce(fu.accts, 0) as funded_accounts, coalesce(fu.persons, 0) as clients, coalesce(fu.hhs, 0) as households, 0.0 as restatement_impact
        from grid g
        left join bal b0 on b0.dimension_type = g.dimension_type and b0.dimension_key = g.dimension_key and b0.as_of = g.begin_end
        left join bal b1 on b1.dimension_type = g.dimension_type and b1.dimension_key = g.dimension_key and b1.as_of = g.period_end
        left join funded fu on fu.dimension_type = g.dimension_type and fu.dimension_key = g.dimension_key and fu.as_of = g.period_end
        left join avgq q on q.reporting_period_id = g.reporting_period_id and q.dimension_type = g.dimension_type and q.dimension_key = g.dimension_key
        left join fl nna on nna.reporting_period_id = g.reporting_period_id and nna.dimension_type = g.dimension_type and nna.dimension_key = g.dimension_key and nna.measure = 'nna'
        left join fl nict on nict.reporting_period_id = g.reporting_period_id and nict.dimension_type = g.dimension_type and nict.dimension_key = g.dimension_key and nict.measure = 'nict'
        left join fl gs on gs.reporting_period_id = g.reporting_period_id and gs.dimension_type = g.dimension_type and gs.dimension_key = g.dimension_key and gs.measure = 'gross'
        left join fl rd on rd.reporting_period_id = g.reporting_period_id and rd.dimension_type = g.dimension_type and rd.dimension_key = g.dimension_key and rd.measure = 'redemptions'
        left join fl ex on ex.reporting_period_id = g.reporting_period_id and ex.dimension_type = g.dimension_type and ex.dimension_key = g.dimension_key and ex.measure = 'exchanges'""")
    # entities
    fill(rt, slice_, "DP-008/Reporting Period", "select reporting_period_id, period_type, period_end as final_close_date from cert.period")
    fill(rt, slice_, "DP-008/Snapshot", "select 'SNAP-' || reporting_period_id || '-FINAL-1' as snapshot_id, 'Final' as snapshot_type, date '%s' as as_of_date, cast(null as string) as supersedes_snapshot from cert.period" % AS_OF)
    defs = ["('MSR-CLIENT-ASSET-FAMILY', 'Client Asset Family (certified)', 'Semi-Additive', true, 'Net Only', 'Exclude (Same Owner)', 'Exclude (Market Movement and Other)', 'Exclude (Market Movement and Other)', 'Inter-Channel Transfer (Zero Firm-Wide)', 'Count as Net New Assets')"]
    for col, name, agg in MEASURES:
        tr = TREATMENTS.get(name, DEFAULT_TREATMENT)
        defs.append(f"('MSR-{col.upper().replace('_', '-')}', '{name}', '{agg}', true, '{tr[0]}', '{tr[1]}', '{tr[2]}', '{tr[3]}', '{tr[4]}', '{tr[5]}')")
    fill(rt, slice_, "DP-008/Measure Definition", "select * from (values " + ", ".join(defs) + ") as t(measure_id, measure_name, aggregation_behavior, certified_indicator, exchange_treatment, transfer_treatment, income_treatment, fee_treatment, inter_channel_transfer_treatment, rollover_treatment)")
    # One row per period x dimension key carries every named measure of the family (the semantic model reads the named
    # columns and hides Measure Amount); the Measure key names the family. Open decision for the model owner (CW-): the
    # long form (one row per measure) would leave the named CDE columns null on most rows.
    GAPS.append(("DP-008/Measure Value", "Published wide: one row per period x dimension key with every named measure; Measure = MSR-CLIENT-ASSET-FAMILY (open decision: long form vs wide form)"))
    cols = ", ".join(c for c, _, _ in MEASURES)
    n = fill(rt, slice_, "DP-008/Measure Value", f"""select 'MSR-CLIENT-ASSET-FAMILY' as measure, period_type, cast(period_start_date as date) as period_start_date, period_end_date, dimension_type, dimension_key,
                             reporting_period_id as reporting_period, cast(null as double) as measure_amount, 'Reported / Actual' as data_basis, 'SNAP-' || reporting_period_id || '-FINAL-1' as snapshot,
                             {cols} from cert.measure_wide""")
    return n


# ------------------------------------------------------------------------------------------------- DP-320
def build_dp320(rt, slice_):
    fill(rt, slice_, "DP-320/Fact Household Client Assets", """
        select s.summary_account, s.summary_as_of_date, s.summary_holding_type, s.summary_source_book, s.summary_market_value, s.advised_assets_indicator
        from dp_007.account_asset_summary s join cert.account_attr a on a.account_id = s.summary_account where a.household is not null""")
    fill(rt, slice_, "DP-320/Fact Fund Position View", """
        select position_id, account, share_class, valuation_date, aggregation_role, market_value, omnibus_parent_account, omnibus_residual_amount
        from dp_007.position where aggregation_role = 'Counted - Intermediary'""")
    GAPS.append(("DP-320/Fact Household 360", "Held-Away Assets are read from the CRM's held-away financial accounts (no home in 15 Account); plan, goal, fee-household, service-contact and trust measures are null: their products (DP-303, DP-305, DP-381, DP-307) are outside the slice"))
    n = fill(rt, slice_, "DP-320/Fact Household 360", f"""
        with hh as (select party_id from dp_240.party where party_type = 'Household'),
             members as (select household, count(distinct household_member) as n from dp_240.household_membership m
                         join dp_240.party p on p.party_id = m.household_member and p.party_status = 'Active'
                         where m.membership_status = 'Active' and (m.membership_effective_to is null or m.membership_effective_to > date '{AS_OF}') group by 1),
             assets as (select a.household, sum(f.value) as v, sum(case when a.advised then f.value else 0 end) as adv
                        from cert.asset_fact f join cert.account_attr a on a.account_id = f.account where f.as_of = date '{AS_OF}' and a.household is not null group by 1),
             nonhh as (select sum(f.value) as v from cert.asset_fact f left join cert.account_attr a on a.account_id = f.account where f.as_of = date '{AS_OF}' and a.household is null),
             total as (select ending_client_assets as v from cert.measure_wide where dimension_type = 'Total' and period_end_date = date '{AS_OF}' and period_type = 'Month'),
             away as (select 'PTY-HH-' || "FinServ__Household__c" as household, sum(try_cast("Held_Away_Value__c" as double)) as v from src_crm."FinServ__FinancialAccount__c" where lower("Held_Away__c") = 'true' group by 1),
             cov as (select distinct covered_party from dp_009.coverage_assignment where party_coverage_role = 'Primary Advisor'),
             tier as (select t.tier_party, t.assigned_service_tier, s.tier_asset_threshold from dp_240.service_tier_assignment t join dp_004.service_tier s on s.service_tier_code = t.assigned_service_tier),
             qual as (select h.party_id, max(s.tier_asset_threshold) as threshold from hh h join assets x on x.household = h.party_id join dp_004.service_tier s on s.tier_asset_threshold <= x.v group by 1)
        select date '{AS_OF}' as as_of_date_key, h.party_id as household_key,
               case when coalesce(m.n, 0) > 0 then 1.0 else 0.0 end as households_in_view, cast(coalesce(m.n, 0) as double) as household_members,
               coalesce(x.v, 0) as household_client_assets, (select v from nonhh) as non_household_client_assets,
               (select sum(coalesce(v, 0)) from assets) + (select v from nonhh) - (select v from total) as household_client_assets_tie_out_variance,
               coalesce(x.adv, 0) as household_advised_assets,
               case when coalesce(x.v, 0) > 0 then round(coalesce(x.adv, 0) / x.v, 4) end as managed_share_of_household_assets,
               coalesce(aw.v, 0) as held_away_assets,
               cast(null as double) as households_without_current_plan, cast(null as double) as household_goals_off_track, cast(null as double) as fee_household_alignment_breaks,
               case when c.covered_party is null then 1.0 else 0.0 end as households_without_primary_advisor,
               case when coalesce(ql.threshold, 0) > coalesce(t.tier_asset_threshold, 0) then 1.0 else 0.0 end as service_tier_qualification_mismatch,
               cast(null as double) as recent_service_contacts, cast(null as double) as trust_linked_households, cast(null as double) as protection_flag_present_from_dp_322
        from hh h left join members m on m.household = h.party_id left join assets x on x.household = h.party_id left join away aw on aw.household = h.party_id
        left join cov c on c.covered_party = h.party_id left join tier t on t.tier_party = h.party_id left join qual ql on ql.party_id = h.party_id""")
    return n


# ------------------------------------------------------------------------------------------------- DP-510
def build_dp510(rt, slice_):
    """The institutional relationship facts: the asset summaries of institutional accounts, their attribution to the
    institutional client, and the relationship-by-month-end fact that carries client assets and the latest health score."""
    GAPS.append(("DP-510/Fact Attributed Client Assets", "A fund account's relationship is read from the platform's FUND_ACCOUNT list; 15 Account has no attribute linking an account to a 12 Service Relationship (candidate addition)"))
    fill(rt, slice_, "DP-510/Fact Account Asset Summary", """
        select s.summary_account, s.summary_as_of_date, s.summary_holding_type, s.summary_source_book, s.summary_market_value, s.own_product_indicator,
               s.summary_distribution_channel, s.advised_assets_indicator
        from dp_007.account_asset_summary s join cert.inst_account ia on ia.account_id = s.summary_account""")
    fill(rt, slice_, "DP-510/Fact Attributed Client Assets", """
        with ch as (select code, code_label from dp_013.code_value where code_list_key = 'Distribution Channel'),
             bl as (select code, code_label from dp_013.code_value where code_list_key = 'Business Line')
        select 'ATTR-' || s.summary_account || '-' || __FMT8__ || '-' || s.summary_holding_type as attribution_record_id,
               'Account Asset Summary' as source_record_type, s.summary_account as source_account_asset_summary, s.summary_market_value as attributed_amount,
               100.0 as attribution_share, s.summary_as_of_date as attribution_effective_date, ch.code_label as distribution_channel, bl.code_label as business_line,
               ia.client_party as institutional_client, 'Account-Keyed' as attribution_method
        from dp_007.account_asset_summary s join cert.inst_account ia on ia.account_id = s.summary_account
        left join ch on ch.code = ia.channel_code left join bl on bl.code = ia.business_line_code""")
    n = fill(rt, slice_, "DP-510/Fact Relationship Health", """
        with me as (select distinct summary_as_of_date as month_end from dp_007.account_asset_summary),
             rel as (select service_relationship_id, service_relationship_status from dp_510.service_relationship),
             grid as (select r.service_relationship_id, r.service_relationship_status, me.month_end from rel r cross join me),
             assets as (select ia.service_relationship_id, s.summary_as_of_date as month_end, sum(s.summary_market_value) as v
                        from dp_007.account_asset_summary s join cert.inst_account ia on ia.account_id = s.summary_account group by 1, 2),
             latest as (select g.service_relationship_id, g.month_end, max(h.health_score_date) as score_date
                        from grid g join dp_510.fact_health_score h on h.scored_relationship = g.service_relationship_id and h.health_score_date <= g.month_end group by 1, 2)
        select g.service_relationship_id || '|' || __FMT8G__ as fact_relationship_health_key, g.month_end as calendar_date_key, g.service_relationship_id as service_relationship_key,
               case when g.service_relationship_status in ('Active', 'Under Notice') then 1.0 else 0.0 end as active_relationships_by_segment,
               coalesce(a.v, 0) as relationship_client_assets,
               case when h.at_risk_indicator then 1.0 else 0.0 end as at_risk_relationships,
               h.overall_health_score as average_health_score
        from grid g left join assets a on a.service_relationship_id = g.service_relationship_id and a.month_end = g.month_end
        left join latest l on l.service_relationship_id = g.service_relationship_id and l.month_end = g.month_end
        left join dp_510.fact_health_score h on h.scored_relationship = l.service_relationship_id and h.health_score_date = l.score_date""")
    return n


# ------------------------------------------------------------------------------------------------- DP-346 / DP-498 / DP-499
FISCAL = "'FY' || substr(%s, 1, 4) || '-M' || substr(%s, 6, 2)"


def build_dp012_fee_revenue(rt, slice_):
    """The fee revenue record's derived measures (gross and net fee revenue, the effective net fee rate) as the
    sub-ledger accrued them: the taxonomy flags them derived, so the mapped table carries no column for them."""
    stored = ", ".join("r." + snake(a["name"]) for a in slice_["entities"]["DP-012/Fee Revenue Record"]["attrs"] if not a["derived"])
    ctas(rt, "cert.fee_revenue_src", f"""
        select {stored}, cast(f."GROSS_FEE" as double) as gross_fee_revenue, cast(f."NET_FEE" as double) as net_fee_revenue,
               case when cast(f."AVG_NET_ASSETS" as double) > 0 then cast(f."NET_FEE" as double) * 12.0 / cast(f."AVG_NET_ASSETS" as double) * 10000.0 end as effective_net_fee_rate
        from dp_012.fee_revenue_record r left join src_rev."FUND_REV" f on 'FRR-' || f."REV_ID" = r.fee_revenue_record_id""")
    return fill(rt, slice_, "DP-012/Fee Revenue Record", "select * from cert.fee_revenue_src")


def build_dp346(rt, slice_):
    """The billing re-performance test: every released, non-simulation calculation re-performed on the tiers of the
    schedule version its assignment names at the run's billing period end; off schedule when the engine applied another
    version; the household breakpoint miss when the account is in a fee household with two or more active members but
    the calculation used no household assets."""
    GAPS.append(("DP-346/Fact Fee Billing Test", "The re-performance reads the schedule tiers from the billing engine's SCHEDULE_TIER extract; 47 Fee Schedule carries no tier entity in the slice"))
    return fill(rt, slice_, "DP-346/Fact Fee Billing Test", """
        with calc as (select c.*, r.run_billing_period_start, r.run_billing_period_end, r.run_type
                      from dp_305.account_fee_calculation c join dp_305.fee_run r on r.fee_calculation_run_id = c.calculation_run
                      where r.run_status = 'Released' and r.run_type <> 'Simulation'),
             inforce as (select c.calculation_run, c.calculated_assignment, a.assigned_fee_schedule as inforce_schedule, a.billed_account, a.billed_enrollment, a.assigned_fee_household
                         from calc c join dp_305.fee_schedule_assignment a on a.fee_schedule_assignment_id = c.calculated_assignment),
             sched as (select 'FS-' || t."SCHED_ID" as fee_schedule_id, t."TIER_NO" as tier_no, cast(t."LOWER_BOUND" as double) as lo,
                              cast(t."UPPER_BOUND" as double) as hi, cast(t."RATE_BPS" as double) as rate_bps, s."TIER_METHOD_CD" as tier_method
                       from src_bil."SCHEDULE_TIER" t join src_bil."SCHEDULE" s on s."SCHED_ID" = t."SCHED_ID"),
             basis as (select c.calculation_run, c.calculated_assignment, i.inforce_schedule, coalesce(c.fee_household_assets, c.billable_assets) as basis_value, c.billable_assets
                       from calc c join inforce i on i.calculation_run = c.calculation_run and i.calculated_assignment = c.calculated_assignment),
             blended as (select b.calculation_run, b.calculated_assignment,
                                sum(greatest(0, least(b.basis_value, coalesce(t.hi, 1e18)) - t.lo) * t.rate_bps) / nullif(max(b.basis_value), 0) as blended_bps,
                                max(case when b.basis_value >= t.lo and (t.hi is null or b.basis_value < t.hi) then t.rate_bps end) as cliff_bps,
                                max(t.tier_method) as tier_method
                         from basis b join sched t on t.fee_schedule_id = b.inforce_schedule group by 1, 2),
             rate as (select calculation_run, calculated_assignment, case when tier_method = 'CL' then cliff_bps when tier_method = 'SR' then cliff_bps else blended_bps end as inforce_bps from blended),
             grp as (select a.assigned_fee_household, c.calculation_run, sum(c.billable_assets) as billed from calc c join dp_305.fee_schedule_assignment a on a.fee_schedule_assignment_id = c.calculated_assignment
                     where a.assigned_fee_household is not null group by 1, 2),
             members as (select m.membership_fee_household, count(distinct m.member_account) as n from dp_305.fee_household_membership m
                         where m.fee_household_membership_status = 'Active' and m.fee_household_membership_effective_from <= date '%(as_of)s' and (m.fee_household_membership_effective_to is null or m.fee_household_membership_effective_to >= date '%(as_of)s') group by 1)
        select c.calculation_run as calculation_run, c.calculated_assignment as calculated_assignment, c.calculated_billing_arrangement as calculated_billing_arrangement,
               i.inforce_schedule as schedule_version_applied, c.account_valuation, c.billable_assets, c.fee_household_assets, c.effective_annual_rate, c.gross_fee, c.discount_amount,
               c.waiver_amount_applied, c.own_fund_credit_amount, c.net_fee, c.exception_indicator,
               null as pro_ration_days,
               round(c.billable_assets * r.inforce_bps / 10000.0 / 4.0, 2) - c.discount_amount - c.waiver_amount_applied - c.own_fund_credit_amount as re_performed_fee,
               case when c.schedule_version_applied <> i.inforce_schedule then 1.0 else 0.0 end as off_schedule_flag,
               case when c.schedule_version_applied <> i.inforce_schedule then c.net_fee - (round(c.billable_assets * r.inforce_bps / 10000.0 / 4.0, 2) - c.discount_amount - c.waiver_amount_applied - c.own_fund_credit_amount) else 0 end as billing_variance,
               case when i.assigned_fee_household is not null and mb.n >= 2 and (c.fee_household_assets is null or c.fee_household_assets = c.billable_assets)
                         and coalesce(gp.billed, 0) > c.billable_assets then 1.0 else 0.0 end as household_breakpoint_not_applied
        from calc c join inforce i on i.calculation_run = c.calculation_run and i.calculated_assignment = c.calculated_assignment
        left join rate r on r.calculation_run = c.calculation_run and r.calculated_assignment = c.calculated_assignment
        left join members mb on mb.membership_fee_household = i.assigned_fee_household
        left join grp gp on gp.assigned_fee_household = i.assigned_fee_household and gp.calculation_run = c.calculation_run""" % dict(as_of=config.AS_OF))


def build_dp498(rt, slice_):
    """Cost to serve per fiscal month, dimension grain and member from the final actual allocation run's results: the
    allocated amounts of the pools with a cost-to-serve component, by component; average client assets and households
    of the same member and month from the certified family (where the family carries the dimension)."""
    return fill(rt, slice_, "DP-498/Fact Cost to Serve", """
        with runs as (select allocation_run_id, run_period from dp_480.allocation_run where run_status = 'Final' and run_data_version = 'Actual'),
             res as (select r.run_period, x.target_dimension_member as member, rl.target_dimension as grain, p.cost_to_serve_component as comp, x.allocated_amount as amt
                     from dp_480.allocation_result x join runs r on r.allocation_run_id = x.allocation_run_key
                     join dp_480.allocation_rule rl on rl.allocation_rule_id = x.allocated_rule join dp_480.cost_pool p on p.cost_pool_id = rl.source_cost_pool
                     where rl.target_dimension is not null and p.cost_to_serve_component is not null),
             agg as (select run_period, grain, member,
                            sum(case when comp = 'Advice' then amt else 0 end) as advice, sum(case when comp = 'Service' then amt else 0 end) as service,
                            sum(case when comp = 'Platform' then amt else 0 end) as platform, sum(case when comp = 'Clearing and Client Asset Custody' then amt else 0 end) as clearing,
                            sum(case when comp = 'Money Movement' then amt else 0 end) as money, sum(case when comp in ('Communications', 'Regulatory') then amt else 0 end) as comms,
                            sum(amt) as total
                     from res group by 1, 2, 3),
             mv as (select period_end_date, dimension_type, dimension_key, average_client_assets, households from dp_008.measure_value
                    where period_type = 'Month' and snapshot in (select snapshot_id from dp_008.snapshot where snapshot_type in ('Final', 'Restated')))
        select a.run_period || '|' || a.grain || '|' || a.member as profitability_record_id, a.run_period as profitability_period, 'Actual' as data_version, a.grain as dimension_grain,
               case when a.grain = 'Channel' then a.member end as channel, case when a.grain = 'Business Line' then a.member end as business_line,
               case when a.grain = 'Service Offering' and a.member <> 'UNATTRIBUTED' then 'OFF-' || a.member end as service_offering, case when a.grain = 'Service Tier' then a.member end as service_tier,
               case when a.grain = 'Client Segment' then a.member end as client_segment,
               'MH-CURRENT' as hierarchy_version, (select min(allocation_run_id) from runs r where r.run_period = a.run_period) as source_allocation_run,
               a.advice as coverage_and_servicing_cost, a.service as client_service_cost, a.platform as platform_technology_cost, a.clearing as clearing_client_asset_custody_cost,
               a.money as money_movement_cost, a.comms as communications_regulatory_cost, a.total as total_cost_to_serve,
               case when mv.average_client_assets > 0 then a.total * 12.0 / mv.average_client_assets * 10000.0 end as cost_to_serve_rate,
               mv.average_client_assets as average_client_assets_from_dp_008, mv.households as households_from_dp_008
        from agg a left join mv on mv.dimension_type = case a.grain when 'Client Segment' then 'Segment' else a.grain end and mv.dimension_key = a.member
                                and (%(fiscal_me)s) = a.run_period""" % dict(fiscal_me=FISCAL % ("cast(mv.period_end_date as varchar)", "cast(mv.period_end_date as varchar)")))


def build_dp499(rt, slice_):
    """Profitability per fiscal month, grain (Client Segment, Channel, Business Line, Service Offering) and member:
    client revenue of the member plus the month's own-fund net fee revenue attributed by the member's share of own-fund
    holdings; distribution payments (DIST pools), direct sales and marketing (MKT pools) and the other pools' allocations
    from the final actual run; the negative-contribution flag over the trailing four quarters at the latest month."""
    GAPS.append(("DP-499/Fact Profitability", "Own-fund fee revenue is attributed to segments and offerings by the accounts' own-fund holdings at the latest month-end on or before the month; the certified family carries own-fund overlap only by channel and business line"))
    ctas(rt, "cert.own_fund_share", OWN_FUND_SHARE)   # after DP-008, whose cert.asset_dim it reads
    n = fill(rt, slice_, "DP-499/Fact Profitability", """
        with runs as (select allocation_run_id, run_period from dp_480.allocation_run where run_status = 'Final' and run_data_version = 'Actual'),
             alloc as (select r.run_period, rl.target_dimension as grain, x.target_dimension_member as member, p.cost_pool_type as ptype, x.allocated_amount as amt
                       from dp_480.allocation_result x join runs r on r.allocation_run_id = x.allocation_run_key
                       join dp_480.allocation_rule rl on rl.allocation_rule_id = x.allocated_rule join dp_480.cost_pool p on p.cost_pool_id = rl.source_cost_pool
                       where rl.target_dimension in ('Client Segment', 'Channel', 'Business Line', 'Service Offering')),
             cost as (select run_period, grain, member, sum(case when ptype = 'Intermediary Distribution' then amt else 0 end) as dist,
                             sum(case when ptype = 'Marketing & Acquisition' then amt else 0 end) as sm,
                             sum(case when ptype not in ('Intermediary Distribution', 'Marketing & Acquisition') then amt else 0 end) as indirect
                      from alloc group by 1, 2, 3),
             bl as (select code, code_label from dp_013.code_value where code_list_key = 'Business Line'),
             crev as (select client_revenue_period as run_period, 'Client Segment' as grain, coalesce(client_segment_at_period_end, 'UNATTRIBUTED') as member, sum(recognized_revenue_amount) as rev
                      from dp_012.client_revenue_record group by 1, 2, 3
                      union all select client_revenue_period, 'Channel', coalesce(revenue_channel, 'UNATTRIBUTED'), sum(recognized_revenue_amount) from dp_012.client_revenue_record group by 1, 2, 3
                      union all select c.client_revenue_period, 'Business Line', coalesce(bl.code, c.revenue_business_line, 'UNATTRIBUTED'), sum(c.recognized_revenue_amount) from dp_012.client_revenue_record c left join bl on bl.code_label = c.revenue_business_line group by 1, 2, 3
                      union all select client_revenue_period, 'Service Offering', coalesce(replace(revenue_service_offering, 'OFF-', ''), 'UNATTRIBUTED'), sum(recognized_revenue_amount) from dp_012.client_revenue_record group by 1, 2, 3),
             fund as (select revenue_accounting_period as run_period, sum(net_fee_revenue) as net from dp_012.fee_revenue_record group by 1),
             share as (select * from cert.own_fund_share),
             members as (select run_period, grain, member from cost union select run_period, grain, member from crev union select run_period, grain, member from share where share > 0),
             mv as (select period_end_date, dimension_type, dimension_key, average_client_assets from dp_008.measure_value
                    where period_type = 'Month' and snapshot in (select snapshot_id from dp_008.snapshot where snapshot_type in ('Final', 'Restated'))),
             rows_ as (select m.run_period, m.grain, m.member, coalesce(cr.rev, 0) + round(coalesce(f.net, 0) * coalesce(sh.share, 0), 2) as gross,
                              coalesce(c.dist, 0) as dist, coalesce(c.sm, 0) as sm, coalesce(c.indirect, 0) as indirect, mv.average_client_assets as aca
                       from members m left join crev cr on cr.run_period = m.run_period and cr.grain = m.grain and cr.member = m.member
                       left join cost c on c.run_period = m.run_period and c.grain = m.grain and c.member = m.member
                       left join fund f on f.run_period = m.run_period
                       left join share sh on sh.run_period = m.run_period and sh.grain = m.grain and sh.member = m.member
                       left join mv on mv.dimension_type = case m.grain when 'Client Segment' then 'Segment' else m.grain end and mv.dimension_key = m.member and (%(fiscal_me)s) = m.run_period),
             t4 as (select grain, member, sum(gross - dist - sm) as cm4 from rows_ group by 1, 2)
        select r.run_period || '|' || r.grain || '|' || r.member as profitability_record_id, r.run_period as profitability_period, 'Actual' as data_version, r.grain as dimension_grain,
               case when r.grain = 'Channel' then r.member end as channel, case when r.grain = 'Business Line' then r.member end as business_line,
               case when r.grain = 'Service Offering' and r.member <> 'UNATTRIBUTED' then 'OFF-' || r.member end as service_offering, cast(null as varchar) as service_tier, cast(null as varchar) as partner_firm,
               cast(null as varchar) as product_share_class, cast(null as varchar) as advisor, cast(null as varchar) as client_account,
               case when r.grain = 'Client Segment' then r.member end as client_segment, 'LE-HC' as reporting_legal_entity, 'MH-CURRENT' as hierarchy_version,
               (select min(allocation_run_id) from runs x where x.run_period = r.run_period) as source_allocation_run, 'USD' as reporting_currency,
               r.gross as gross_revenue, r.dist as distribution_payments, r.gross - r.dist as net_revenue_after_distribution_costs,
               case when r.aca > 0 then (r.gross - r.dist) * 12.0 / r.aca * 10000.0 end as net_revenue_yield,
               r.sm as direct_sales_marketing_cost, r.gross - r.dist - r.sm as contribution_margin, r.indirect as allocated_indirect_cost,
               r.gross - r.dist - r.sm - r.indirect as operating_profit,
               case when r.gross <> 0 then (r.gross - r.dist - r.sm - r.indirect) / r.gross * 100.0 end as operating_margin,
               cast(null as double) as total_cost_to_serve,
               r.aca as average_client_assets_from_dp_008,
               case when r.run_period = (select max(run_period) from rows_) and r.grain in ('Service Offering', 'Client Segment') and t4.cm4 < 0 then 1.0 else 0.0 end as offerings_and_segments_with_negative_contribution
        from rows_ r left join t4 on t4.grain = r.grain and t4.member = r.member""" % dict(fiscal_me=FISCAL % ("cast(mv.period_end_date as varchar)", "cast(mv.period_end_date as varchar)")))
    create_entity(rt, slice_, "DP-499/Profitability Measure Definition")
    rt.insert_rows(rt.entity("DP-499", "Profitability Measure Definition"), ["profitability_measure_code", "measure_formula"], [
        ("Net Revenue Yield", "net revenue after distribution costs, annualized / average client assets x 10,000"),
        ("Net Revenue After Distribution Costs", "gross revenue - distribution payments"),
        ("Contribution Margin", "net revenue after distribution costs - direct sales and marketing cost"),
        ("Operating Profit", "contribution margin - allocated indirect cost"),
        ("Operating Margin", "operating profit / gross revenue"),
        ("Cost-to-Serve Rate", "total cost to serve, annualized / average client assets x 10,000"),
        ("Cost-Income Ratio", "(direct sales and marketing cost + allocated indirect cost) / gross revenue")])
    return n


# ------------------------------------------------------------------------------------------------- DP-495
def build_dp495(rt, slice_):
    fill(rt, slice_, "DP-495/Match Rule", """
        select * from (values ('MR-1', 'Deterministic', 100, 100, 'FEED-BRK-CUST'), ('MR-2', 'Deterministic', 100, 100, 'FEED-BRK-CUST'), ('MR-3', 'Probabilistic', 95, 70, 'FEED-BRK-CUST'))
        as t(match_rule_id, match_rule_type, auto_accept_threshold, review_threshold, applicable_feeds)""")
    GAPS.append(("DP-495/Identifier Crosswalk", "Source Identifier Type carries the proposed scheme for a brokerage customer number; 06 Intermediary Identifier Type lists only intermediary schemes"))
    ctas(rt, "cert.customer_match", """
        with cu as (select "CUST_NO" as cust, "CRM_CONTACT_ID" as crm, "FIRST_NM" as fn, "LAST_NM" as ln, cast(try_strptime("DOB", '%Y%m%d') as date) as dob from src_brk."CUST_MASTER"),
             byno as (select "Brokerage_Customer_No__c" as cust, min("Id") as id from src_crm."Contact" group by 1),
             byname as (select "FirstName" as fn, "LastName" as ln, try_cast("Birthdate" as date) as dob, min("Id") as id, count(*) as n from src_crm."Contact" where "Status__c" <> 'Merged' group by 1, 2, 3)
        select cu.cust, cu.crm, b.id as by_number, case when nm.n = 1 then nm.id end as by_name,
               case when cu.crm is not null then 'MR-1' when b.id is not null then 'MR-2' when nm.n = 1 then 'MR-3' end as rule,
               case when cu.crm is not null then 'Matched - Auto' when b.id is not null then 'Matched - Auto' when nm.n = 1 then 'Suggested' else 'Unmatched' end as status,
               case when cu.crm is not null or b.id is not null then 100 when nm.n = 1 then 85 else 0 end as score
        from cu left join byno b on b.cust = cu.cust left join byname nm on nm.fn = cu.fn and nm.ln = cu.ln and nm.dob = cu.dob""")
    fill(rt, slice_, "DP-495/Identifier Crosswalk", f"""
        select 'XW-BRK-' || m.cust as crosswalk_id, 'FEED-BRK-CUST' as source_feed, '{__import__("transforms").PROPOSED_SCHEME}' as source_identifier_type, m.cust as source_identifier_value,
               coalesce('PTY-' || m.crm, 'PTY-' || m.by_number, 'PTY-BRK-' || m.cust) as resolved_party, cast(null as string) as resolved_account,
               date '2026-01-01' as crosswalk_effective_from, cast(null as date) as crosswalk_effective_to
        from cert.customer_match m""")
    n = fill(rt, slice_, "DP-495/Fact Match Result", f"""
        select 'XW-BRK-' || m.cust as identifier_crosswalk_key, m.status as match_status,
               case m.rule when 'MR-1' then 'Source Key Exact' when 'MR-2' then 'Source Key Exact' when 'MR-3' then 'Name + ZIP Code Fuzzy' end as match_source,
               m.rule as match_rule_applied, m.score as match_score, date '{AS_OF}' as match_date
        from cert.customer_match m""")
    return n


def main(rt=None, log=print):
    rt = rt or runtime.get()
    del GAPS[:]
    slice_ = json.load(open(os.path.join(_paths.OUT, "slice.json")))
    counts = {}
    counts["DP-013/Code Value"] = build_dp013(rt, slice_); log("  DP-013 calendar and code values")
    for name, sql in HELPERS:
        ctas(rt, name, sql)
    for key, sql in [("DP-192/Employee", DP192), ("DP-006/Transaction", DP006_TRANSACTION), ("DP-006/Linked Transaction", DP006_LINKED),
                     ("DP-007/Account Asset Summary", DP007_SUMMARY), ("DP-007/Position", DP007_POSITION)]:
        counts[key] = fill(rt, slice_, key, sql); log(f"  {key:36s} {counts[key]:7d} rows")
    builds = [("DP-008/Measure Value", build_dp008), ("DP-320/Fact Household 360", build_dp320), ("DP-510/Fact Relationship Health", build_dp510), ("DP-495/Fact Match Result", build_dp495)]
    if "DP-499/Fact Profitability" in slice_["entities"]:
        builds += [("DP-012/Fee Revenue Record", build_dp012_fee_revenue), ("DP-346/Fact Fee Billing Test", build_dp346), ("DP-498/Fact Cost to Serve", build_dp498), ("DP-499/Fact Profitability", build_dp499)]
    for key, fn in builds:
        counts[key] = fn(rt, slice_); log(f"  {key:36s} {counts[key]:7d} rows")
    with open(os.path.join(rt.out, "derivation_report.json"), "w") as f:
        json.dump(dict(runtime=rt.name, counts=counts, gaps=[dict(entity=e, note=n) for e, n in GAPS]), f, indent=1)
    return counts


if __name__ == "__main__":
    main()
    runtime.get().close()
