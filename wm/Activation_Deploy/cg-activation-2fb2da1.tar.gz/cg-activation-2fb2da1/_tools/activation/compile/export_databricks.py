"""Exports the compiled semantic layer and pipeline of the activation slice as Databricks assets under
activation/out/databricks/: Unity Catalog metric views (YAML spec 1.1 and their CREATE VIEW ... WITH METRICS DDL), the
semantic views as Spark SQL, four source-format notebooks, an Asset Bundle (databricks.yml), Genie notes and a README.
Every name comes from runtime.names("spark") with config.CATALOG in front, so the local Spark build deploys unchanged.
Usage (from _tools/):  activation/.venv/bin/python activation/compile/export_databricks.py      (after semantic.py)
"""
import json, os, re, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import _paths  # noqa: E402,F401
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "sources"))
import yaml  # noqa: E402
import config, runtime  # noqa: E402
from schema import SOURCES  # noqa: E402

OUT = os.path.join(os.path.dirname(HERE), "out")
DBX = os.path.join(OUT, "databricks")
N = runtime.names("spark")
CAT = config.CATALOG
SQL_WORDS = {"filter", "where", "and", "or", "not", "in", "is", "null", "case", "when", "then", "else", "end", "distinct",
             "true", "false", "as", "between", "like", "select", "from", "source"}
RESERVED = {"measure", "order", "group", "user", "date", "time", "timestamp", "table", "from", "select", "where", "window"}
DIM_TYPES = ["Total", "Channel", "Holding Type", "Business Line", "Advisor", "Campaign", "Share Class", "Segment"]


def fq(name):
    """A runtime name (schema.table) with the Unity Catalog in front."""
    return f"{CAT}.{name}"


def ident(c):
    """A column reference, backquoted when Spark SQL needs it."""
    return c if re.fullmatch(r"[a-z_][a-z0-9_]*", c) and c not in RESERVED else f"`{c}`"


def snake(s):
    return re.sub(r"[^a-z0-9]+", "_", s.lower().replace("%", " pct")).strip("_")


def spark_sql(text):
    """DuckDB-flavored SQL over product tables -> Spark SQL with three-level names."""
    return re.sub(r"(?<![\w.`])(bronze|silver|gold)\.", rf"{CAT}.\1.", N.sql(text))


def metric_expr(sql, tname):
    """A metric's aggregate over semantic names -> a measure expression over the metric view's source columns."""
    s = re.sub(rf'"?\b{tname}"?\.', "", sql)
    s = re.sub(r"\barg_min\(", "min_by(", re.sub(r"\barg_max\(", "max_by(", s))
    s = re.sub(r"\bdp_(\d{3})\.\"?(\w+)\"?", lambda m: fq(N.entity(f"DP-{m.group(1)}", m.group(2))), s)
    s = re.sub(r'"([^"]+)"', lambda m: ident(m.group(1)), s)
    return re.sub(r"(?<![\w.`])([a-z_][a-z0-9_]*)\b(?!\s*\()", lambda m: m.group(1) if m.group(1) in SQL_WORDS else ident(m.group(1)), s)


def words(expr):
    """Column identifiers an expression reads (functions, keywords, literals and subqueries left out)."""
    e = re.sub(r"'[^']*'", "''", expr)
    e = re.sub(r"\(select .*?\)\)?", "(0)", e, flags=re.S)
    e, out = e.replace("`", ""), set()
    for m in re.finditer(r"(?<![\w.])(\d*[A-Za-z_]\w*(?:\.\d*[A-Za-z_]\w*)?)\b(?!\s*\()", e):
        out |= {m.group(1)} if m.group(1).lower() not in SQL_WORDS else set()
    return out


def col_info(slice_, k):
    return {c["name"]: c for c in slice_["tables"].get(k, {}).get("columns", [])}


def view_ddl(t):
    """CREATE OR REPLACE VIEW for one semantic view over its physical product table, always-filters applied."""
    phys = N.entity(t["product"], t["entity"])
    assert phys.split(".")[1].endswith(t["physical"].split(".", 1)[1].strip('"')), (phys, t["physical"])
    sel = ",\n  ".join(f"{ident(p)} AS {ident(s)}" for s, p in t["columns"].items())
    where = " AND ".join(f"({spark_sql(f)})" for f in t["always_filter_sql"])
    return (f"-- {t['model']} {t['name']}: {t['entity']} ({t['product']}), {t['kind']}\n"
            f"CREATE OR REPLACE VIEW {fq(N.view(t['model'], t['name']))} AS\nSELECT\n  {sel}\nFROM {fq(phys)}" + (f"\nWHERE {where}" if where else "") + "\n;\n")


def mv_filter(t, notes, key):
    """The parameter-free always-filters that read only columns the semantic view exposes, renamed to semantic names."""
    inv, keep = {p: s for s, p in t["columns"].items()}, []
    for f in t["always_filter_sql"]:
        if "select " in f or not words(f) <= set(inv):
            notes.append(f"- {key}: always-filter `{f}` stays in the semantic view only (it reads {'a subquery' if 'select ' in f else 'columns the view does not expose'}).")
            continue
        keep.append("(" + re.sub(r"(?<![\w'])([a-z_][a-z0-9_]*)\b(?!\s*\()", lambda m: ident(inv.get(m.group(1), m.group(1))) if m.group(1) in inv else m.group(1), f) + ")")
    for qf in t["query_filters"]:
        notes.append(f"- {key}: parameterized filter `{qf}` is not carried; queries filter it in WHERE (04_ask does).")
    return " AND ".join(keep)


def joins_for(cm, key, tabs, notes):
    """The compiled many-to-one joins from a table to other semantic views, as metric view joins."""
    out, seen = [], set()
    for j in cm["joins"]:
        if j.get("frm_table") != key or not j["executable"]:
            continue
        elif j["to_table"] not in tabs or j["type"] != "many-to-one":
            notes.append(f"- {key} -> {j['to_table'] or j['to']}: not joined ({'metric view joins are many-to-one' if j['type'] != 'many-to-one' else 'target has no view'}). {j['warning'][:160]}")
            continue
        (fc, tc), alias = re.findall(r'"\w+"\."(\w+)"', j["sql"]), tabs[j["to_table"]]["name"]
        alias = alias if alias not in seen else f"{alias}_by_{fc}"; seen.add(alias)
        on = f"source.{ident(fc)} = {alias}.{ident(tc)}"
        cond = re.search(r"\bwhere (dimension_type (?:=|in) .+)$", j["text"])
        on += f" AND source.{cond.group(1)}" if cond else ""
        out.append(dict(name=alias, source=fq(N.view(*j["to_table"].split(".", 1))), on=on, _to=j["to_table"]))
    return out


def field(name, expr, info, suffix=""):
    rec = dict(name=name, expr=expr)
    if info.get("attr"):
        rec["display_name"] = (info["attr"] + suffix)[:255]
    if info.get("definition") or info.get("pii"):
        rec["comment"] = (info.get("definition") or "") + (" Personal data (PII)." if info.get("pii") else "") + (" Critical data element." if info.get("cde") else "")
    return rec


def metric_view(cm, slice_, key, tabs, notes):
    """One metric view (YAML dict) for a semantic table with answerable metrics, or None."""
    t = tabs[key]
    mets = [m for m in cm["metrics"] if not m["ref"] and m["answerable"] and m["sql"] and m["tables"] == [key]]
    if not mets:
        return None
    joins, info = joins_for(cm, key, tabs, notes), col_info(slice_, key)
    mnames = {snake(m["name"]) for m in mets}
    fields = [field(c if c not in mnames else f"{c}_value", ident(c), info.get(c, {})) for c in t["columns"]]
    names = {f["name"] for f in fields} | mnames
    for j in joins:
        jinfo = col_info(slice_, j["_to"])
        for c in tabs[j["_to"]]["columns"]:
            n = f"{j['name']}_{c}" if f"{j['name']}_{c}" not in names else f"{j['name']}__{c}"
            names.add(n); fields.append(field(n, f"{j['name']}.{ident(c)}", jinfo.get(c, {}), f" ({j['name'].replace('_', ' ')})"))
    measures = []
    for m in mets:
        n, expr = snake(m["name"]), metric_expr(m["sql"], t["name"])
        if "select " in expr:
            notes.append(f"- {key} / {m['name']}: measure `{n}` keeps an IN-subquery on {CAT}.silver inside FILTER; open Spark accepts it, metric views are unverified (fallback: expose same_owner_indicator in the semantic view).")
        measures.append(dict(name=n, expr=expr, display_name=m["name"][:255],
                             comment=f"{m['description']} Aggregation: {m['aggregation']}." + (f" Time rule: {m['time_rule']}." if m["time_rule"] else "")))
    mv = dict(version=1.1, comment=f"{t['model']} {t['name']}: {t['kind']} from {t['product']} {t['entity']}. Grain: {t['grain'] or 'one row per key'}.",
              source=fq(N.view(t["model"], t["name"])))
    flt = mv_filter(t, notes, key)
    mv.update(**({"filter": flt} if flt else {}), **({"joins": [{k: v for k, v in j.items() if k != "_to"} for j in joins]} if joins else {}))
    mv.update(fields=fields, measures=measures)
    return mv


def mv_name(key):
    return "mv_" + key.lower().replace("-", "").replace(".", "_", 1)


def ask_queries(cm, mvs):
    """Five verified questions answered by one metric view each: (question, SQL with MEASURE())."""
    out = []
    for q in cm["questions"]:
        text, hits = q["answer"], {}
        for key, x in sorted(((k, x) for k, mv in mvs.items() if k.startswith(q["model"]) for x in mv["measures"]), key=lambda kx: -len(kx[1]["display_name"])):
            pat = rf"(?<![\w-]){re.escape(x['display_name'])}(?![\w%-])"
            if re.search(pat, text):
                hits.setdefault(key, []).append(x); text = re.sub(pat, " ", text)
        if not hits:
            continue
        key = max(hits, key=lambda k: len(hits[k])); mv, hit = mvs[key], sorted(hits[key], key=lambda x: q["answer"].find(x["display_name"]))
        cols = [f["name"] for f in mv["fields"] if "." not in f["expr"]]
        dims = [c for c in cols if "_" in c and re.search(rf"\b{c}\b", q["answer"]) and c not in ("dimension_type", "period_type", "dimension_key")]
        where = []
        if "dimension_type" in cols:
            dt = sorted((v for v in DIM_TYPES if f"'{v}'" in q["answer"]), key=lambda v: q["answer"].find(f"'{v}'"))[:1] or [cm["params"]["dimension_type"]]
            where += [f"dimension_type = '{dt[0]}'", f"period_type = '{cm['params']['period_type']}'"]
            dims = ["dimension_key"] + [d for d in dims if d != "dimension_key"]
            dims += [] if "period_end_date" in dims else ["period_end_date"]
        sel = ",\n  ".join([ident(d) for d in dims] + [f"MEASURE({ident(x['name'])}) AS {ident(x['name'])}" for x in hit])
        sql = f"SELECT\n  {sel}\nFROM {fq('gold.' + mv_name(key))}" + (f"\nWHERE {' AND '.join(where)}" if where else "") + \
              (f"\nGROUP BY {', '.join(ident(d) for d in dims)}\nORDER BY {', '.join(ident(d) for d in dims)}" if dims else "")
        out.append((q["question"], sql))
    return out[:5]


NB = "# Databricks notebook source\n"
CMD = "\n# COMMAND ----------\n\n"


def md(text):
    return "\n".join("# MAGIC " + ("%md " if i == 0 else "") + line for i, line in enumerate(text.strip().splitlines())).replace("# MAGIC  ", "# MAGIC ") + "\n"


def notebooks(asks):
    """The four source-format notebooks, as {file name: text}."""
    tables = [(sid, t, fq(N.src(sid, t))) for sid, s in SOURCES.items() for t in s["tables"]]
    land = NB + md(f"""# 01 Land bronze
Reads the extracts of the three sources ({', '.join(SOURCES)}) from `<volume_path>/<source>/<TABLE>.csv` and lands each as a
Delta table in `{CAT}.bronze`, all columns as strings (empty strings arrive as null), exactly as the local Spark build does.""") + CMD + \
        f'dbutils.widgets.text("volume_path", "/Volumes/{CAT}/bronze/sources")\nvolume_path = dbutils.widgets.get("volume_path")\n' \
        f'spark.sql("CREATE SCHEMA IF NOT EXISTS {CAT}.bronze")\nTABLES = {json.dumps(tables, indent=1)}\n' + CMD + \
        'for sid, table, target in TABLES:\n    df = spark.read.option("header", "true").option("inferSchema", "false").csv(f"{volume_path}/{sid}/{table}.csv")\n' \
        '    df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(target)\n' \
        '    print(f"{target:44s} {spark.table(target).count():7d} rows")\n'
    build = NB + md(f"""# 02 Build silver and gold
The activation compiles the sources into the Databricks layout in four steps, each a module of `_tools/activation/compile/`:
1. `physical`: lands the extracts (again, from the repo's `activation/out/sources/`, copied from the volume below) and builds the
   conformed foundational products in `{CAT}.silver` through the mapping modules.
2. `derivations`: derives the books of record (DP-006, DP-007) in silver and the certified family (DP-008), the household
   facts (DP-320) and the match results (DP-495) in `{CAT}.gold` by the firm rules.
3. `check_truths`: proves the certified figures against the generator's planted truths; the job fails if one does not tie.
4. `semantic`: compiles the semantic models into `compiled_model.json` (against the DuckDB reference); the gold views
   themselves come from `sql/semantic_views.sql` in notebook 03.
Needs the repo as a Git folder in the workspace (`repo_path`) and `ACTIVATION_RUNTIME=spark`. `USE CATALOG {CAT}` supplies the
catalog level the local session leaves out.""") + CMD + \
        '# MAGIC %pip install delta-spark pyyaml duckdb\n' + CMD + \
        f'import os, shutil, sys\ndbutils.widgets.text("repo_path", "")\ndbutils.widgets.text("volume_path", "/Volumes/{CAT}/bronze/sources")\n' \
        'act = os.path.join(dbutils.widgets.get("repo_path"), "_tools", "activation")\n' \
        'shutil.copytree(dbutils.widgets.get("volume_path"), os.path.join(act, "out", "sources"), dirs_exist_ok=True)\n' \
        f'os.environ["ACTIVATION_RUNTIME"] = "spark"\nspark.sql("USE CATALOG {CAT}")\nos.chdir(os.path.dirname(act))\n' \
        'sys.path[:0] = [act, os.path.join(act, "compile")]\n' + CMD + \
        'import runtime\nruntime.SparkRuntime.close = lambda self: None   # never stop the shared workspace session\n' \
        'import physical, derivations, check_truths, semantic\nrt = runtime.get("spark")\nphysical.main(rt)\nderivations.main()\n' \
        'assert check_truths.main(True) in (0, None), "certified figures do not tie"\nsemantic.main()\n'
    views = NB + md(f"""# 03 Semantic and metric views
Runs `sql/semantic_views.sql` (one `{CAT}.gold` view per semantic table, physical columns renamed to semantic names,
always-filters applied) and then `sql/metric_views.sql` (one metric view per fact table with metrics).""") + CMD + \
        'import os\nfor f in ("semantic_views.sql", "metric_views.sql"):\n    text = open(os.path.join(os.getcwd(), "..", "sql", f)).read()\n' \
        '    for stmt in text.split("\\n;\\n"):\n        body = "\\n".join(l for l in stmt.splitlines() if not l.startswith("--")).strip()\n' \
        '        if body:\n            spark.sql(body)\n    print(f, "applied")\n'
    ask = NB + md(f"""# 04 Ask
Five verified questions of the semantic models, answered from the metric views with `MEASURE()`. Measures aggregate at
query time over the dimensions in GROUP BY; on DP-008 rows pick one dimension_type and one period_type, as the model requires.""")
    for q, sql in asks:
        ask += CMD + md(f"**{q}**") + CMD + f'display(spark.sql("""\n{sql}\n"""))\n'
    return {"01_land_bronze.py": land, "02_build_silver_gold.py": build, "03_semantic_views.py": views, "04_ask.py": ask}


def bundle(nbs):
    """The Asset Bundle: one job running the four notebooks in order, a volume_path parameter, target dev."""
    keys = [f[:-3] for f in nbs]
    tasks = [dict(task_key=k, notebook_task=dict(notebook_path=f"./notebooks/{k}.py"), **({"depends_on": [dict(task_key=keys[i - 1])]} if i else {})) for i, k in enumerate(keys)]
    return dict(bundle=dict(name="cg_wealth_activation"),
                variables=dict(volume_path=dict(description="Unity Catalog volume holding <source>/<TABLE>.csv", default=f"/Volumes/{CAT}/bronze/sources"),
                               repo_path=dict(description="Workspace Git folder of the CG-Taxonomy repo", default="/Workspace/Users/${workspace.current_user.userName}/CG-Taxonomy-wealth")),
                resources=dict(jobs=dict(activation_demo=dict(name="CG wealth source-to-semantic activation",
                    parameters=[dict(name="volume_path", default="${var.volume_path}"), dict(name="repo_path", default="${var.repo_path}")], tasks=tasks))),
                targets=dict(dev=dict(mode="development", default=True)))


def validate(tabs):
    """Loads every YAML back; checks sources and join sources against runtime names and measure columns against fields."""
    allowed = {fq(N.view(*k.split(".", 1))) for k in tabs}
    c, d = dict(metric_views=0, fields=0, measures=0, joins=0), os.path.join(DBX, "metric_views")
    for f in sorted(x for x in os.listdir(d) if x.endswith(".yaml")):
        mv = yaml.safe_load(open(os.path.join(d, f)))
        assert mv["version"] == 1.1 and set(mv) <= {"version", "comment", "source", "filter", "joins", "fields", "measures"}, f
        assert mv["source"] in allowed and all(j["source"] in allowed for j in mv.get("joins", [])), f
        own = {f_["expr"].strip("`") for f_ in mv["fields"] if "." not in f_["expr"]}
        cols = own | {f_["expr"].replace("`", "") for f_ in mv["fields"] if "." in f_["expr"]}
        assert all(words(j["on"]) <= {f"source.{x}" for x in own} | cols for j in mv.get("joins", [])), f
        for m in mv["measures"]:
            assert words(m["expr"]) <= cols, (f, m["name"], words(m["expr"]) - cols)
            for t in re.findall(rf"\b{CAT}\.(\w+\.\w+)", m["expr"]):
                assert re.fullmatch(r"(silver|gold)\.dp_\d{3}_\w+", t), t
        assert len({x["name"] for x in mv["fields"] + mv["measures"]}) == len(mv["fields"]) + len(mv["measures"]), f
        c["metric_views"] += 1; c["fields"] += len(mv["fields"]); c["measures"] += len(mv["measures"]); c["joins"] += len(mv.get("joins", []))
    yaml.safe_load(open(os.path.join(DBX, "databricks.yml")))
    ddl = [yaml.safe_load(x) for x in re.findall(r"AS \$\$\n(.*?)\$\$\n;", open(os.path.join(DBX, "sql", "metric_views.sql")).read(), re.S)]
    assert len(ddl) == c["metric_views"] and all(x["version"] == 1.1 for x in ddl)
    for f in os.listdir(os.path.join(DBX, "notebooks")):
        text = open(os.path.join(DBX, "notebooks", f)).read()
        assert text.startswith(NB) and "# COMMAND ----------" in text, f
        compile("\n".join(l for l in text.splitlines() if not l.startswith("# MAGIC")), f, "exec")
    return c


def write(rel, text):
    os.makedirs(os.path.dirname(os.path.join(DBX, rel)), exist_ok=True); open(os.path.join(DBX, rel), "w").write(text)


def main():
    cm, slice_ = (json.load(open(os.path.join(OUT, f))) for f in ("compiled_model.json", "slice.json"))
    shutil.rmtree(DBX, ignore_errors=True)
    tabs, notes, mvs = {k: t for k, t in cm["tables"].items() if t.get("view")}, [], {}
    write("sql/semantic_views.sql", f"-- Semantic views of the activation slice, Spark SQL on Unity Catalog `{CAT}`. Generated by export_databricks.py.\n\n"
          + "\n".join(view_ddl(t) for t in tabs.values()))
    ddl = [f"-- Metric views (YAML spec 1.1). Generated by export_databricks.py.\n"]
    for key in tabs:
        mv = metric_view(cm, slice_, key, tabs, notes)
        if mv:
            mvs[key], text = mv, yaml.safe_dump(mv, sort_keys=False, allow_unicode=True, width=1000)
            write(f"metric_views/{mv_name(key)[3:]}.yaml", text)
            ddl.append(f"CREATE OR REPLACE VIEW {fq('gold.' + mv_name(key))}\nWITH METRICS\nLANGUAGE YAML\nAS $$\n{text}$$\n;\n")
    write("sql/metric_views.sql", "\n".join(ddl))
    unexp = [m for m in cm["metrics"] if not (not m["ref"] and m["answerable"] and m["sql"])]
    refs = [m for m in unexp if m["ref"] and m["answerable"]]
    notes += [f"- {m['model']} / {m['name']}: a reference to {m['ref']}; query that measure on its own metric view." for m in refs]
    for why in dict.fromkeys(m["reason"] for m in unexp if m not in refs):
        notes.append(f"- Not exported, {why}: " + "; ".join(f"{m['model']} {m['name']}" for m in unexp if m not in refs and m["reason"] == why) + ".")
    write("metric_views/_notes.md", "# What the metric views do not express\n\n" + "\n".join(notes) + "\n")
    asks = ask_queries(cm, mvs)
    nbs = notebooks(asks)
    for f, text in nbs.items():
        write(f"notebooks/{f}", text)
    write("databricks.yml", yaml.safe_dump(bundle(nbs), sort_keys=False, width=1000))
    sample = [q["question"] for q in cm["questions"] if any(re.search(re.escape(x["display_name"]), q["answer"]) for mv in mvs.values() for x in mv["measures"])]
    write("genie_space.md", f"""# Wiring the metric views into an AI/BI Genie space
1. Create a Genie space on a SQL warehouse with access to catalog `{CAT}`; Genie is the Ask surface on Databricks.
2. Add the metric views: {', '.join(f'`{fq("gold." + mv_name(k))}`' for k in mvs)}.
3. Add the dimension views they join to (for lookups Genie runs alone): {', '.join(sorted({f'`{j["source"]}`' for mv in mvs.values() for j in mv.get("joins", [])}))}.
4. General instructions: on DP-008 rows always filter one dimension_type (default '{cm['params']['dimension_type']}') and one period_type (default '{cm['params']['period_type']}'); use MEASURE() for every figure.
5. Sample questions: {' | '.join(sample)}
6. Decline, with the reason, the questions the model cannot answer: {' | '.join(c['question'] for c in cm['cannot_answer'])}
7. Add each 04_ask query as a trusted SQL example ("benchmark") so Genie reuses the certified shape.
8. Grant the space's users SELECT on the views only; personal-data columns are flagged "Personal data (PII)" in field comments and need column masks first.
9. Measures not exported (see metric_views/_notes.md) should be declined, not approximated from the semantic views.
10. Re-run notebook 03 after every rebuild so the space reads the current definitions.
""")
    c = validate(tabs)
    write("README.md", f"""# Databricks export of the activation slice
Generated by `activation/compile/export_databricks.py` from `out/compiled_model.json` and `out/slice.json`; do not edit by hand.
- `metric_views/*.yaml`: {c['metric_views']} Unity Catalog metric views (YAML spec 1.1), {c['fields']} fields, {c['measures']} measures, {c['joins']} joins.
  `metric_views/_notes.md` lists what they do not express (non-many-to-one joins, subquery filters, parameterized filters, unexported metrics).
- `sql/semantic_views.sql`: {len(tabs)} `CREATE OR REPLACE VIEW {CAT}.gold.<view>` statements over the physical product tables.
- `sql/metric_views.sql`: the `CREATE OR REPLACE VIEW ... WITH METRICS LANGUAGE YAML AS $$ ... $$` statement of each metric view.
- `notebooks/`: 01 lands the three sources' CSVs in `{CAT}.bronze`, 02 builds silver and gold with the activation modules
  (`ACTIVATION_RUNTIME=spark`), 03 runs the two SQL files, 04 answers {len(asks)} verified questions with `MEASURE()`.
- `databricks.yml`: an Asset Bundle with one job running the four notebooks in order (parameters `volume_path`, `repo_path`), target `dev`.
- `genie_space.md`: how to put the metric views behind an AI/BI Genie space.

## Deploy
1. Create catalog `{CAT}` with schemas `bronze`, `silver`, `gold`, and a volume; upload `out/sources/<SOURCE>/<TABLE>.csv` to it.
2. Add the repo to the workspace as a Git folder (branch feature/wealth-manager).
3. From this folder: `databricks bundle validate -t dev`, `databricks bundle deploy -t dev`,
   `databricks bundle run activation_demo -t dev --params volume_path=/Volumes/{CAT}/bronze/sources,repo_path=/Workspace/...`.
   Tasks without a cluster spec run on serverless compute; add a job cluster if the workspace has none (metric views need DBR 17.2+ or a SQL warehouse).

## Not validated
No workspace or CLI was available: the YAML was loaded back and every source, join source and measure column checked
against the runtime's names, the notebooks compile as Python, but nothing was run on Databricks. The metric view DDL follows the
docs' `CREATE OR REPLACE VIEW ... WITH METRICS LANGUAGE YAML AS $$...$$`; `bundle validate` has not been run.

## Local to Databricks
1. No catalog level locally: the local session names `bronze.x`, `silver.x`, `gold.x`; the assets name `{CAT}.<schema>.x`, and notebook 02 runs `USE CATALOG {CAT}` first.
2. ANSI mode is on in Databricks (off locally), so the compiled SQL uses `try_cast` and `try_to_timestamp`, which return null instead of failing on bad values.
""")
    print(json.dumps(dict(c, notebooks=len(nbs), semantic_views=len(tabs), ask_queries=len(asks), notes=len(notes))))


if __name__ == "__main__":
    main()
