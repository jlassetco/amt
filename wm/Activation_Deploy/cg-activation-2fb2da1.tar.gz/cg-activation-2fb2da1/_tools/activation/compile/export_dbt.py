"""Exports the compiled semantic model of the activation slice as dbt Semantic Layer (MetricFlow) YAML under
activation/out/dbt/ (one models/semantic/<view>.yml per semantic model, metrics, view stubs, sources, saved queries, README).
Usage (from _tools/):  activation/.venv/bin/python activation/compile/export_dbt.py      (after semantic.py)
"""
import json, os, re, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import _paths  # noqa: E402,F401
sys.path.insert(0, HERE)
import yaml  # noqa: E402

OUT = os.path.join(os.path.dirname(HERE), "out")
DBT = os.path.join(OUT, "dbt")
AGGS = {"sum": "sum", "max": "max", "arg_max": "max", "arg_min": "sum"}
MEASURES = {}
DIM_TYPES = ["Total", "Channel", "Holding Type", "Business Line", "Advisor", "Campaign", "Share Class", "Segment"]


def snake(s):  # physical.snake, with % spelled out
    return re.sub(r"[^a-z0-9]+", "_", s.lower().replace("%", " pct")).strip("_")


def dump(path, data, comment=""):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(yaml.safe_dump(data, sort_keys=False, allow_unicode=True, width=120) + comment)


def split_physical(p):
    return p.split(".", 1)[0], p.split(".", 1)[1].strip('"')


def build_tables(cm, slice_):
    """Per exported table: entity name, primary-key columns, column info (slice columns, plus the entity's attributes for
    the keys the compiler added), time columns, agg-time dimension."""
    tabs = {k: t for k, t in cm["tables"].items() if t.get("view")}
    count, out = [t["name"] for t in tabs.values()], {}
    for k, t in tabs.items():
        ent = slice_["entities"][slice_["tables"][k]["entity_key"]]
        by_phys = {snake(a["name"]): dict(a, attr=a["name"]) for a in ent["attrs"]}
        info = {s: by_phys[p] for s, p in t["columns"].items() if p in by_phys} | {c["name"]: c for c in slice_["tables"][k]["columns"]}
        inv = {p: s for s, p in sorted(t["columns"].items(), key=lambda x: x[0] == x[1])}  # identity names win
        pk = [inv[snake(a)] for a in ent["pk"] if snake(a) in inv]
        time = [c for c in t["columns"] if info.get(c, {}).get("type") in ("Date", "Timestamp") or c == t.get("default_as_of_column")]
        ent = t["name"] if count.count(t["name"]) == 1 else f"{t['model'].lower().replace('-', '')}_{t['name']}"
        out[k] = dict(t=t, info=info, pk=pk, time=time, entity=ent, sm=t["view"].split(".")[1], measures={}, extra_dims={},
                      uniques={}, foreign={}, agg_time=t.get("default_as_of_column") or (time[0] if time else None))
    return out


def link_joins(cm, tabs):
    """Turns each executable join into a foreign entity on the from table (and a unique entity on the target when the
    target column is not its single primary key); returns the joins MetricFlow cannot express."""
    skipped = []
    for j in cm["joins"]:
        if not j["executable"] or j["frm_table"] not in tabs or j["to_table"] not in tabs:
            continue
        (fc,), (tc,) = re.findall(r'"\w+"\."(\w+)" =', j["sql"]), re.findall(r'= "\w+"\."(\w+)"', j["sql"])
        f, to = tabs[j["frm_table"]], tabs[j["to_table"]]
        if to["pk"] != [tc] and j["type"] == "many-to-many":
            skipped.append(f"{j['frm_table']} -> {j['to_table']} ({tc} is not a key of the target)"); continue
        name = to["entity"] if to["pk"] == [tc] else f"{to['entity']}_by_{tc}"
        to["uniques"].update({name: tc} if name != to["entity"] else {})
        f["foreign"].setdefault(name, fc)
    return skipped


def close(sql, j, depth=1):
    """The index just past the parenthesis that closes the one opened before j."""
    while depth:
        depth += {"(": 1, ")": -1}.get(sql[j], 0); j += 1
    return j


def calls(sql):
    """Splits a metric's SQL into its top-level aggregate calls (with any FILTER clause) and the arithmetic around them."""
    parts, expr, i = [], "", 0
    while i < len(sql):
        m = re.match(r"(sum|count|max|arg_max|arg_min)\(", sql[i:])
        if not m:
            expr += sql[i]; i += 1; continue
        j = end = close(sql, i + len(m.group(0)))
        fm, filt = re.match(r"\s*filter \(where ", sql[j:]), None
        if fm:
            j = close(sql, end + len(fm.group(0)))
            filt = sql[end + len(fm.group(0)):j - 1]
        parts.append((sql[i:end], filt)); expr += f"@{len(parts) - 1}"; i = j
    return parts, expr.strip()


def measure_for(tabs, metric, call):
    """Registers the measure behind one aggregate call and returns (table key, measure name)."""
    m = re.match(r"(\w+)\((distinct )?(.*)\)$", call, re.S)
    fn, distinct, arg = m.groups()
    key = next(k for k in metric["tables"] if k in tabs)
    tb, rule = tabs[key], (metric.get("time_rule") or "").lower()
    col = re.sub(rf"\b{tb['t']['name']}\.", "", arg).split(",")[0].strip()
    agg = "count_distinct" if distinct else "count" if arg == "*" else AGGS[fn]
    window = None if not tb["t"].get("default_as_of_column") else "min" if fn == "arg_min" or (fn != "arg_max" and "first" in rule) \
        else "max" if fn == "arg_max" or "last" in rule else None
    expr = "1" if arg == "*" else col
    name = (col if re.fullmatch(r"\w+", col) else snake(metric["name"])) + {"count_distinct": "_distinct", "count": "_rows"}.get(agg, "") \
        + ("_first" if window == "min" else "")
    spec = (expr, agg, window)
    if MEASURES.get(name, (key, spec)) != (key, spec):
        name = f"{tb['t']['name']}_{name}"
    MEASURES[name] = (key, spec)
    tb["measures"][name] = dict(expr=expr, agg=agg, window=window, col=col)
    return key, name


def translate_filter(tabs, key, filt):
    """FILTER (where ...) -> MetricFlow Dimension() syntax; measure columns used in a filter get a `<col>_value` dimension."""
    tb = tabs[key]
    def sub(m):
        col = m.group(1)
        if col in tb["time"]:
            return f"{{{{ TimeDimension('{tb['entity']}__{col}', 'day') }}}}"
        if any(m["col"] == col and m["agg"] in ("sum", "max") for m in tb["measures"].values()):
            tb["extra_dims"][f"{col}_value"] = col; col = f"{col}_value"
        return f"{{{{ Dimension('{tb['entity']}__{col}') }}}}"
    return re.sub(rf"\b{tb['t']['name']}\.(\w+)", sub, filt)


def attrs_of(slice_, metric):
    """The taxonomy attributes behind a metric's columns, with their attribute IDs."""
    out = []
    for c in metric.get("columns") or []:
        for rec in (x for k in metric["tables"] for x in slice_["tables"].get(k, {}).get("columns", []) if x["name"] == c.split(".")[1]):
            a = rec["attr"] + (f" ({rec['attr_id']})" if rec.get("attr_id") else "")
            out += [a] if a not in out else []
    return out


def build_metrics(cm, slice_, tabs):
    """Own answerable metrics -> simple / ratio / derived; in-slice references -> derived aliases; the rest -> skipped."""
    metrics, skipped, names, simple, tables_of = [], [], {}, {}, {}
    def helper(measure):  # the unfiltered simple metric over a measure: an exported one when it exists, else a helper
        if measure not in simple:
            simple[measure] = measure + "_total" if measure in names.values() else measure
            metrics.append(dict(name=simple[measure], label=simple[measure].replace("_", " ").capitalize(), type="simple",
                                type_params=dict(measure=measure), meta=dict(helper=True)))
        return simple[measure]
    todo = []
    for m in (m for m in cm["metrics"] if not m["ref"]):
        if not m["answerable"] or not m["sql"] or "select " in (m["sql"] or ""):
            skipped.append((m, m["reason"] or "its filter is a subquery on another table, which a MetricFlow filter cannot express")); continue
        parts, expr = calls(m["sql"])
        reg = [(meas, translate_filter(tabs, key, filt) if filt else None) for call, filt in parts for key, meas in [measure_for(tabs, m, call)]]
        n = snake(m["name"])
        names[(m["model"], m["name"])] = n if n not in names.values() else f"{m['model'].lower().replace('-', '')}_{n}"
        if expr == "@0" and not reg[0][1]:
            simple.setdefault(reg[0][0], names[(m["model"], m["name"])])
        todo.append((m, reg, expr)); tables_of[names[(m["model"], m["name"])]] = m["tables"]
    for m, reg, expr in sorted(todo, key=lambda x: x[2] != "@0"):
        rec = dict(name=names[(m["model"], m["name"])], label=m["name"], description=m["description"])
        if expr == "@0":
            rec.update(type="simple", type_params=dict(measure=reg[0][0]), **({"filter": reg[0][1]} if reg[0][1] else {}))
        elif re.fullmatch(r"@0 / @1", expr):
            side = lambda r: dict(name=helper(r[0]), **({"filter": r[1]} if r[1] else {}))
            rec.update(type="ratio", type_params=dict(numerator=side(reg[0]), denominator=side(reg[1])))
        else:
            refs = [dict(name=helper(r[0]), **({"filter": r[1]} if r[1] else {})) for r in reg]
            rec.update(type="derived", type_params=dict(expr=re.sub(r"@(\d+)", lambda x: refs[int(x.group(1))]["name"], expr), metrics=refs))
        rec["meta"] = dict(source_product=m["source"][0], source_measure=m["source"][1], taxonomy_attributes=attrs_of(slice_, m),
                           time_rule=m["time_rule"] or "", owner=cm["models"][m["model"]]["owner"], certified=m["model"] == "SM-20")
        metrics.append(rec)
    for m in (m for m in cm["metrics"] if m["ref"]):
        tgt = tuple(m["ref"].split("/", 1))
        if not m["answerable"] or tgt not in names:
            skipped.append((m, m["reason"] or "the target metric is not exported")); continue
        name = names[(m["model"], m["name"])] = f"{m['model'].lower().replace('-', '')}_{snake(m['name'])}"
        tables_of[name] = tables_of[names[tgt]]
        metrics.append(dict(name=name, label=f"{m['name']} ({m['model']})", description=f"Reference to {m['ref']}.", type="derived",
                            type_params=dict(expr=names[tgt], metrics=[dict(name=names[tgt])]),
                            meta=dict(ref=m["ref"], owner=cm["models"][m["model"]]["owner"], certified=tgt[0] == "SM-20")))
    return metrics, skipped, names, tables_of


def semantic_model(tb):
    """One semantic_models entry for an exported table."""
    t, info, pk = tb["t"], tb["info"], tb["pk"]
    ents = [dict(name=tb["entity"], type="primary", **({"expr": pk[0]} if len(pk) == 1 else {"expr": f"concat_ws('|', {', '.join(pk)})"}))] if pk else []
    ents += [dict(name=n, type="unique", expr=c) for n, c in tb["uniques"].items()]
    ents += [dict(name=n, type="foreign", expr=c) for n, c in tb["foreign"].items() if n != tb["entity"]]
    mcols = {m["col"] for m in tb["measures"].values() if m["agg"] in ("sum", "max")}
    dims = [dict(name=c, type="time" if c in tb["time"] else "categorical", description=info.get(c, {}).get("definition", ""),
                 **({"type_params": dict(time_granularity="day")} if c in tb["time"] else {})) for c in t["columns"] if c not in mcols]
    dims += [dict(name=n, type="categorical", expr=c, description=f"The value of {c}, for filters.") for n, c in tb["extra_dims"].items()]
    meas = [dict(name=n, agg=m["agg"], expr=m["expr"], description=("Distinct count: " if m["agg"] == "count_distinct" else "")
                 + (info.get(m["col"], {}).get("definition", "") or f"Rows of {t['name']}."),
                 **({"non_additive_dimension": dict(name=t["default_as_of_column"], window_choice=m["window"])} if m["window"] else {}))
            for n, m in tb["measures"].items()]
    return dict(name=tb["sm"], description=f"{t['kind']} from {t['product']} {t['entity']} (model {t['model']}). Grain: {t['grain'] or 'one row per key'}.",
                model=f"ref('{tb['sm']}')", **({"defaults": dict(agg_time_dimension=tb["agg_time"])} if tb["agg_time"] and (meas or t.get("default_as_of_column")) else {}),
                entities=ents, dimensions=dims, **({"measures": meas} if meas else {}))


def view_sql(t):
    schema, table = split_physical(t["physical"])
    src = lambda s, n: f"{{{{ source('activation_{s}', '{n}') }}}}"
    sel = ",\n    ".join(f'"{p}" as "{s}"' for s, p in t["columns"].items())
    fix = lambda f: re.sub(r"(dp_[0-9]+)\.(\w+)", lambda m: src(m.group(1), m.group(2)), f)
    where = " and ".join(f"({fix(f)})" for f in t["always_filter_sql"])
    return f"-- {t['model']} {t['name']}: {t['entity']} ({t['product']})\nselect\n    {sel}\nfrom {src(schema, table)}" + (f"\nwhere {where}" if where else "") + "\n"


def saved_queries(cm, tabs, names, tables_of):
    """One saved query per verified question, naming its exported metrics and the dimensions its answer text names."""
    out, skipped, n = [], [], {}
    for q in cm["questions"]:
        mid = q["model"]; n[mid] = n.get(mid, 0) + 1
        cands = sorted({m["name"] for m in cm["metrics"] if m["model"] == mid}, key=len, reverse=True)
        text, found = q["answer"], []
        for c in cands:
            pat = rf"\[{re.escape(c)}\]|(?<![\w-]){re.escape(c)}(?![\w%-])"
            if re.search(pat, text):
                found.append(c); text = re.sub(pat, " ", text)
        mets = [names[(mid, c)] for c in found if (mid, c) in names]
        name = f"{mid.lower().replace('-', '')}_q{n[mid]:02d}"
        if not mets:
            skipped.append(f"{name}: {q['question']} (metrics: {', '.join(found) or 'none named'})"); continue
        keys = {k for x in mets for k in tables_of[x] if k in tabs}
        qp = dict(metrics=mets)
        if len(keys) == 1:
            tb = tabs[keys.pop()]; e = tb["entity"]; gb, where = [], []
            for c in tb["t"]["columns"]:
                if "_" in c and re.search(rf"\b{c}\b", q["answer"]) and c not in ("dimension_type", "dimension_key", "period_type"):
                    gb.append(f"TimeDimension('{e}__{c}', 'day')" if c in tb["time"] else f"Dimension('{e}__{c}')")
            if "dimension_type" in tb["t"]["columns"]:
                vals = [v for v in DIM_TYPES if f"'{v}'" in q["answer"]] or [cm["params"]["dimension_type"]]
                where.append(f"{{{{ Dimension('{e}__dimension_type') }}}} in ({', '.join(repr(v) for v in vals)})")
                where.append(f"{{{{ Dimension('{e}__period_type') }}}} = '{cm['params']['period_type']}'")
                gb = [f"Dimension('{e}__dimension_type')", f"Dimension('{e}__dimension_key')"] + gb
            qp.update(**({"group_by": list(dict.fromkeys(gb))} if gb else {}), **({"where": where} if where else {}))
        out.append(dict(name=name, description=q["question"], query_params=qp))
    return out, skipped


def main():
    cm, slice_ = (json.load(open(os.path.join(OUT, f))) for f in ("compiled_model.json", "slice.json"))
    shutil.rmtree(DBT, ignore_errors=True)
    tabs = build_tables(cm, slice_)
    skipped_joins = link_joins(cm, tabs)
    metrics, skipped, names, tables_of = build_metrics(cm, slice_, tabs)
    sem, views, sources = os.path.join(DBT, "models", "semantic"), os.path.join(DBT, "models", "views"), {}
    os.makedirs(views)
    for tb in tabs.values():
        dump(os.path.join(sem, f"{tb['sm']}.yml"), dict(semantic_models=[semantic_model(tb)]))
        with open(os.path.join(views, f"{tb['sm']}.sql"), "w") as f:
            f.write(view_sql(tb["t"]))
        for f in [tb["t"]["physical"]] + [f"{a}.{b}" for x in tb["t"]["always_filter_sql"] for a, b in re.findall(r"(dp_[0-9]+)\.(\w+)", x)]:
            s, t = split_physical(f); sources.setdefault(s, set()).add(t)
    dump(os.path.join(DBT, "models", "sources.yml"), dict(version=2, sources=[
        dict(name=f"activation_{s}", schema=s, description="Physical data product tables of the activation DuckDB.",
             tables=[dict(name=t) for t in sorted(ts)]) for s, ts in sorted(sources.items())]))
    note = "\n# not exported\n" + "".join(f"#   - {m['model']} / {m['name']}: {why}\n" for m, why in skipped)
    note += "".join(f"#   - join {j}: MetricFlow has no fan-out join\n" for j in skipped_joins)
    dump(os.path.join(sem, "metrics.yml"), dict(metrics=metrics), note)
    sq, sq_skipped = saved_queries(cm, tabs, names, tables_of)
    dump(os.path.join(DBT, "saved_queries.yml"), dict(saved_queries=sq),
         "\n# questions not exported (none of their metrics is exported)\n" + "".join(f"#   - {s}\n" for s in sq_skipped))
    counts = validate()
    kinds = ["helper" if m["meta"].get("helper") else m["type"] for m in metrics]
    by_type = {k: kinds.count(k) for k in sorted(set(kinds))}
    readme = f"""# dbt Semantic Layer export of the activation slice
Generated by `activation/compile/export_dbt.py` from `out/compiled_model.json` and `out/slice.json`; do not edit by hand.
- `models/semantic/<view>.yml`: {counts['semantic_models']} semantic models (one per compiled view), {counts['dimensions']} dimensions, {counts['measures']} measures.
- `models/semantic/metrics.yml`: {counts['metrics']} metrics ({', '.join(f'{v} {k}' for k, v in by_type.items())}); {len(skipped)} metrics are listed as not exported, with the reason.
- `models/views/*.sql` + `models/sources.yml`: view stubs over the physical data product tables, so every `ref()` resolves.
- `saved_queries.yml`: {counts['saved_queries']} saved queries, one per verified question with an exported metric ({len(sq_skipped)} skipped).
Two things MetricFlow cannot express directly here:
1. The certified table's `:dimension_type` (and `:period_type`) query-time parameter: each saved query pins it with a `where` filter on `dimension_type`, defaulting to 'Total'; ad hoc queries must do the same.
2. Multi-table metrics (such as Client Assets by Channel and Holding Type, over two fact tables): a dbt project would add a union model of the facts and a semantic model on it.
"""
    open(os.path.join(DBT, "README.md"), "w").write(readme)
    print(json.dumps(dict(counts, metric_types=by_type, not_exported=len(skipped), joins_skipped=len(skipped_joins), questions_skipped=len(sq_skipped))))


def validate():
    """Loads every YAML file back and counts its entries; checks that metric measures and filter dimensions resolve."""
    c, meas, dims, used, refs = dict(semantic_models=0, dimensions=0, measures=0, metrics=0, saved_queries=0), set(), set(), set(), set()
    for path in (os.path.join(r, f) for r, _, fs in os.walk(DBT) for f in fs if f.endswith(".yml")):
        text = open(path).read()
        d, refs = yaml.safe_load(text) or {}, refs | set(re.findall(r"Dimension\('(\w+)'", text))
        used |= {m["type_params"]["measure"] for m in d.get("metrics", []) if m["type"] == "simple"}
        for sm in d.get("semantic_models", []):
            c["semantic_models"] += 1; c["dimensions"] += len(sm["dimensions"]); c["measures"] += len(sm.get("measures", []))
            meas |= {m["name"] for m in sm.get("measures", [])}
            dims |= {f"{e['name']}__{x['name']}" for e in sm["entities"] for x in sm["dimensions"]}
        c["metrics"] += len(d.get("metrics", [])); c["saved_queries"] += len(d.get("saved_queries", []))
    assert used <= meas and refs <= dims, (used - meas, refs - dims)
    return c


if __name__ == "__main__":
    main()
