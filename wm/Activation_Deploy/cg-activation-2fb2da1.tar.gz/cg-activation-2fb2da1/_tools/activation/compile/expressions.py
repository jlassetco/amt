"""Executable form of the semantic models' prose: the always-filters, joins and metrics whose text in sm_*.py is a
sentence rather than SQL. Everything is written in the models' own names (semantic table and column names); the
semantic builder resolves them to the physical views. A metric with no entry and a plain `sum(table.column)` or
`count(distinct table.column) where ...` expression is compiled from the model text itself.

The one new kind of content the activation adds to the model: the certified metrics are defined once here as SQL.
"""

# Parameters a query supplies (with defaults); a filter that names one is applied by the engine, not in the view.
PARAMS = {"as_of_date": None, "dimension_type": "Total", "period_type": "Month", "dimension_grain": "Business Line"}   # the engine sets dimension_type and dimension_grain from the requested breakdown

# Always-filters without parameters go into the view; those with :params are applied per query.
ALWAYS = {
    ("SM-20", "client_assets_flows"): ["snapshot in (select snapshot_id from dp_008.snapshot where snapshot_type in ('Final', 'Restated'))",
                                       "dimension_type = :dimension_type", "period_type = :period_type"],
    ("SM-20", "flow_transactions"): ["transaction_status not in ('Canceled', 'Reversed', 'Rejected')"],
    ("SM-20", "account_asset_summary"): ["summary_as_of_date in (select final_close_date from dp_008.reporting_period)"],
    ("SM-20", "intermediary_positions"): ["aggregation_role = 'Counted - Intermediary' or omnibus_residual_amount is not null"],
    ("SM-00", "calendar_date"): ["calendar_key = 'CAL-REPORTING'"],
    ("SM-00", "code_value"): ["code_value_status = 'Active'"],
    ("SM-00", "distribution_channel"): ["code_list_key = 'Distribution Channel'"],
    ("SM-00", "program"): ["offering_type not in ('Brokerage', 'Planning Only')"],
    ("SM-00", "firm_advisor"): ["advisor_status is not null"],
    ("SM-00", "household"): ["party_type = 'Household'"],
    ("SM-00", "client"): ["party_type <> 'Household'"],
    ("SM-00", "household_membership"): ["membership_status = 'Active'", "membership_effective_from <= :as_of_date and (membership_effective_to is null or membership_effective_to > :as_of_date)"],
    ("SM-21", "household"): ["party_type = 'Household'"],
    ("SM-21", "client"): ["party_type <> 'Household'"],
    ("SM-21", "household_membership"): ["membership_status = 'Active'", "membership_effective_from <= :as_of_date and (membership_effective_to is null or membership_effective_to > :as_of_date)"],
    ("SM-27", "relationship_attribution"): ["source_account_asset_summary is not null"],
    ("SM-21", "account_owner"): ["account_role_effective_from <= :as_of_date and (account_role_effective_to is null or account_role_effective_to > :as_of_date)"],
    # SM-28: fiscal months roll up from months; the billed calculation set is the released, non-simulation runs; cost to
    # serve and profitability are the actual version of the final run at one dimension grain per query
    ("SM-00", "fiscal_month"): ["calendar_key = 'CAL-FISCAL'", "fiscal_period_type = 'MONTH'"],
    ("SM-00", "fiscal_quarter"): ["calendar_key = 'CAL-FISCAL'", "fiscal_period_type = 'QUARTER'"],
    ("SM-28", "fee_revenue"): ["revenue_data_basis in ('Actual', 'Accrued Estimate')"],
    ("SM-28", "account_fee_calculation"): ["calculation_run in (select fee_calculation_run_id from dp_305.fee_run where run_status = 'Released' and run_type <> 'Simulation')"],
    ("SM-28", "fee_billing_test"): ["calculation_run in (select fee_calculation_run_id from dp_305.fee_run where run_status = 'Released' and run_type <> 'Simulation')"],
    ("SM-28", "fee_schedule_assignment"): ["assignment_effective_from <= :as_of_date and (assignment_effective_to is null or assignment_effective_to >= :as_of_date)"],
    ("SM-28", "fee_household_membership"): ["fee_household_membership_status = 'Active'", "fee_membership_effective_from <= :as_of_date and (fee_membership_effective_to is null or fee_membership_effective_to >= :as_of_date)"],
    ("SM-28", "allocation_run"): ["run_status = 'Final'", "run_data_version = 'Actual'"],
    ("SM-28", "allocation_result"): ["allocation_run_key in (select allocation_run_id from dp_480.allocation_run where run_status = 'Final' and run_data_version = 'Actual')"],
    ("SM-28", "cost_to_serve"): ["data_version = 'Actual'", "cts_dimension_grain = :dimension_grain"],
    ("SM-28", "profitability"): ["data_version = 'Actual'", "dimension_grain = :dimension_grain"],
    ("SM-28", "client_assets"): ["snapshot in (select snapshot_id from dp_008.snapshot where snapshot_type in ('Final', 'Restated'))",
                                 "assets_dimension_type = :dimension_type", "period_type = :period_type"],
}
UNSUPPORTED_TABLES = {("SM-00", "parent_group"): "no party hierarchy in the slice", ("SM-00", "direct_parent"): "no party hierarchy in the slice"}

# Default filters: the column that pins a single as-of period when the query gives none.
DEFAULT_AS_OF = {
    ("SM-20", "client_assets_flows"): "period_end_date", ("SM-20", "account_asset_summary"): "summary_as_of_date",
    ("SM-20", "intermediary_positions"): "valuation_date", ("SM-21", "household_360"): "as_of_date_key",
    ("SM-21", "household_client_assets"): "summary_as_of_date", ("SM-21", "fund_position_view"): "valuation_date",
    ("SM-27", "relationship_health"): "month_end", ("SM-27", "relationship_asset_summary"): "summary_as_of_date",
    ("SM-27", "relationship_attribution"): "attribution_effective_date",
    # SM-28: fiscal-period codes (FYyyyy-Mmm) on the revenue, allocation and profitability facts; a date on the billing runs,
    # which the calculation facts reach through their run
    ("SM-28", "client_revenue"): "client_revenue_period", ("SM-28", "fee_revenue"): "revenue_accounting_period",
    ("SM-28", "fee_run"): "run_billing_period_end", ("SM-28", "account_fee_calculation"): "fee_run.run_billing_period_end",
    ("SM-28", "fee_billing_test"): "fee_run.run_billing_period_end", ("SM-28", "fee_debit"): "debit_date",
    ("SM-28", "allocation_run"): "run_period", ("SM-28", "allocation_result"): "allocation_run.run_period",
    ("SM-28", "cost_to_serve"): "cts_profitability_period", ("SM-28", "profitability"): "profitability_period",
    ("SM-28", "client_assets"): "assets_period_end_date",
}
# Columns of the one-grain-per-query facts that imply the grain when a query breaks down or filters by them.
DIMENSION_GRAIN_OF = {"cts_client_segment": "Client Segment", "cts_channel": "Channel", "cts_business_line": "Business Line", "cts_service_offering": "Service Offering",
                      "cts_service_tier": "Service Tier", "profitability_client_segment": "Client Segment", "profitability_channel": "Channel",
                      "profitability_business_line": "Business Line", "profitability_service_offering": "Service Offering", "profitability_service_tier": "Service Tier"}
# Columns that hold a fiscal-period code rather than a date (the engine turns a period into the codes it spans).
FISCAL_CODE_COLUMNS = {"client_revenue_period", "revenue_accounting_period", "run_period", "cts_profitability_period", "profitability_period"}

# Semantic names the models use for a shared table that differ from the SM-00 table name.
TABLE_ALIAS = {"account": "client_account", "employee": "firm_advisor", "worker": "employee", "service_tier": "offering_service_tier"}

# Join conditions for relationships whose `on` text is a sentence. Keyed by (model, frm, to).
JOINS = {
    ("SM-20", "client_assets_flows", "DP-013/Code Value"): "client_assets_flows.dimension_key = code_value.code",
    ("SM-20", "client_assets_flows", "DP-004/Share Class"): "client_assets_flows.dimension_key = share_class.share_class_id",
    ("SM-20", "client_assets_flows", "DP-009/Employee"): "client_assets_flows.dimension_key = firm_advisor.employee_id",
    ("SM-20", "flow_transactions", "DP-093/Account"): "flow_transactions.txn_account = client_account.account_id",
    ("SM-20", "flow_transactions", "DP-093/Program Enrollment"): "flow_transactions.txn_account = program_enrollment.enrolled_account",
    ("SM-20", "DP-240/Household Membership", "DP-240/Party"): "household_membership.household = party.party_id",
    ("SM-20", "account_asset_summary", "DP-093/Account"): "account_asset_summary.summary_account = client_account.account_id",
    ("SM-20", "account_asset_summary", "DP-013/Code Value"): "account_asset_summary.summary_holding_type = code_value.code_label",
    ("SM-21", "household", "client"): None,          # many-to-many through household_membership; not a direct join
    ("SM-21", "household", "DP-093/Account"): None,  # many-to-many through membership and account_owner
    ("SM-28", "fee_billing_test", "account_fee_calculation"): ("fee_billing_test.test_calculation_run = account_fee_calculation.calculation_run and "
                                                               "fee_billing_test.test_calculated_assignment = account_fee_calculation.calculated_assignment"),
    ("SM-28", "fee_debit", "account_fee_calculation"): "fee_debit.debited_calculation = account_fee_calculation.calculation_run || '|' || account_fee_calculation.calculated_assignment",
    ("SM-28", "account_fee_calculation", "fee_schedule_assignment"): "account_fee_calculation.calculated_assignment = fee_schedule_assignment.fee_schedule_assignment_id",
    ("SM-28", "account_fee_calculation", "fee_schedule"): "account_fee_calculation.schedule_version_applied = fee_schedule.fee_schedule_id",
    ("SM-28", "cost_pool", "DP-190/Cost Center"): None,  # multi-valued cost center list; DP-190 is not in the slice
    ("SM-28", "client_revenue", "account_fee_calculation"): "client_revenue.source_calculation_record = account_fee_calculation.calculation_run || '|' || account_fee_calculation.calculated_assignment",
}

# Relationships the models imply but do not list (added to the compiled joins).
EXTRA_RELATIONSHIPS = [
    dict(model="SM-28", frm="client_revenue", to="account_fee_calculation", type="many-to-one",
         on="client_revenue.source_calculation_record = account_fee_calculation.calculation_run || '|' || account_fee_calculation.calculated_assignment"),
]

# Metrics whose model text is not an aggregate expression. Written over the semantic names; FILTER clauses are DuckDB.
METRICS = {
    ("SM-20", "Average Client Assets"): "sum(client_assets_flows.average_client_assets) / count(distinct client_assets_flows.period_end_date)",
    ("SM-20", "Client Organic Growth Rate"): ("sum(client_assets_flows.net_new_assets) * 12 / count(distinct client_assets_flows.period_end_date) "
                                              "/ min_by(client_assets_flows.beginning_client_assets, client_assets_flows.period_end_date)"),
    ("SM-20", "Funded Accounts"): "max_by(client_assets_flows.funded_accounts, client_assets_flows.period_end_date)",
    ("SM-20", "Clients"): "max_by(client_assets_flows.clients, client_assets_flows.period_end_date)",
    ("SM-20", "Households"): "max_by(client_assets_flows.households, client_assets_flows.period_end_date)",
    ("SM-20", "Own-Fund Share of Client Assets %"): "sum(account_asset_summary.summary_market_value) filter (where account_asset_summary.own_product_indicator) / sum(account_asset_summary.summary_market_value)",
    ("SM-20", "Intermediary-Held Own-Fund Value"): "sum(intermediary_positions.position_market_value) filter (where intermediary_positions.aggregation_role = 'Counted - Intermediary')",
    ("SM-20", "Inter-Channel Transfer Amount"): ("sum(case when flow_transactions.flow_direction = 'Outflow' then -flow_transactions.gross_amount else flow_transactions.gross_amount end) "
                                                 "filter (where flow_transactions.flow_scope = 'Inter-Channel Transfer')"),
    ("SM-20", "Advisors With Net Outflows"): "count(distinct client_assets_flows.dimension_key) filter (where client_assets_flows.dimension_type = 'Advisor' and client_assets_flows.net_new_assets < 0)",
    ("SM-20", "Same-Owner Transfers Excluded"): ("sum(flow_transactions.reporting_currency_amount) filter (where flow_transactions.reporting_currency_amount > 0 and "
                                                 "flow_transactions.flow_scope <> 'Inter-Channel Transfer' and "
                                                 "flow_transactions.transaction_id in (select transaction_key from dp_006.linked_transaction where same_owner_indicator))"),
    ("SM-20", "Suggested Matches Awaiting Review"): "count(*) filter (where match_result.match_status = 'Suggested')",
    ("SM-21", "Households in View"): "count(distinct household_360.household_key) filter (where household_360.households_in_view = 1)",
    ("SM-21", "Non-Household Client Assets"): "max(household_360.non_household_client_assets)",
    ("SM-21", "Households Without Current Plan"): "count(distinct household_360.household_key) filter (where household_360.households_without_current_plan = 1)",
    ("SM-21", "Households Without Primary Advisor"): "count(distinct household_360.household_key) filter (where household_360.households_without_primary_advisor = 1)",
    ("SM-21", "Service Tier Qualification Mismatch"): "count(distinct household_360.household_key) filter (where household_360.service_tier_qualification_mismatch = 1)",
    ("SM-21", "Trust-Linked Households"): "count(distinct household_360.household_key) filter (where household_360.trust_linked_households = 1)",
    # SM-27: the relationship-health fact carries, per relationship and month-end, the client assets attributed to the
    # relationship, the latest health score on or before the month-end and whether it flags the relationship at risk
    ("SM-27", "Active Relationships by Segment"): "count(distinct relationship_health.service_relationship_key) filter (where relationship_health.active_relationships_by_segment = 1)",
    ("SM-27", "Relationship Client Assets"): "sum(relationship_health.relationship_client_assets)",
    ("SM-27", "At-Risk Relationships"): "count(distinct relationship_health.service_relationship_key) filter (where relationship_health.at_risk_relationships = 1)",
    ("SM-27", "At-Risk Relationship Client Assets"): "sum(relationship_health.relationship_client_assets) filter (where relationship_health.at_risk_relationships = 1)",
    ("SM-27", "Average Health Score"): "sum(relationship_health.average_health_score * relationship_health.relationship_client_assets) / sum(relationship_health.relationship_client_assets)",
    # SM-28: client revenue by stream and its fee subset; the billed calculation set; the re-performance test; cost to
    # serve and profitability at one grain. Annualized rates take the months in the selected range from the fiscal codes.
    ("SM-28", "Client Fee Revenue"): "sum(client_revenue.recognized_revenue_amount) filter (where client_revenue.client_revenue_stream in ('Advisory Fee', 'Wrap Fee', 'Planning Fee', 'Subscription Fee', 'Account Service Fee', 'Recordkeeping Fee', 'Trust Fee', 'OCIO Fee', 'Mandate Performance Fee'))",
    ("SM-28", "Client Transaction and Interest Revenue"): "sum(client_revenue.recognized_revenue_amount) filter (where client_revenue.client_revenue_stream in ('Commission', 'Markup / Markdown', 'Margin Interest', 'Fully Paid Lending Revenue', 'Bank Sweep Fee', 'Order Routing Payment'))",
    ("SM-28", "Client Revenue by Stream"): "sum(client_revenue.recognized_revenue_amount)",
    ("SM-28", "Gross Fee Revenue"): "sum(client_revenue.recognized_revenue_amount) filter (where client_revenue.client_revenue_stream in ('Advisory Fee', 'Wrap Fee', 'Planning Fee', 'Subscription Fee', 'Account Service Fee', 'Recordkeeping Fee', 'Trust Fee', 'OCIO Fee', 'Mandate Performance Fee'))",
    ("SM-28", "Net Fee Revenue"): "sum(client_revenue.recognized_revenue_amount) filter (where client_revenue.client_revenue_stream in ('Advisory Fee', 'Wrap Fee', 'Planning Fee', 'Subscription Fee', 'Account Service Fee', 'Recordkeeping Fee', 'Trust Fee', 'OCIO Fee', 'Mandate Performance Fee'))",
    ("SM-28", "Effective Net Fee Rate"): "sum(client_revenue.recognized_revenue_amount) filter (where client_revenue.client_revenue_stream in ('Advisory Fee', 'Wrap Fee', 'OCIO Fee', 'Trust Fee', 'Recordkeeping Fee')) * 12.0 / count(distinct client_revenue.client_revenue_period) * 10000.0 / nullif(sum(account_fee_calculation.billable_assets) filter (where client_revenue.client_revenue_stream in ('Advisory Fee', 'Wrap Fee', 'OCIO Fee', 'Trust Fee', 'Recordkeeping Fee')) / count(distinct client_revenue.client_revenue_period), 0)",
    ("SM-28", "Fund Effective Net Fee Rate"): "sum(fee_revenue.net_fee_revenue) * 12.0 / count(distinct fee_revenue.revenue_accounting_period) * 10000.0 / nullif(sum(fee_revenue.fee_basis_average_assets) / count(distinct fee_revenue.revenue_accounting_period), 0)",
    ("SM-28", "Active Fee Schedule Versions"): "count(distinct fee_schedule.fee_schedule_id) filter (where fee_schedule.schedule_status = 'Active' and fee_schedule.version_effective_from <= :as_of_date and (fee_schedule.version_effective_to is null or fee_schedule.version_effective_to >= :as_of_date))",
    ("SM-28", "Active Fee Schedule Assignments"): "count(distinct fee_schedule_assignment.fee_schedule_assignment_id)",
    ("SM-28", "Fee Household Member Accounts"): "count(distinct fee_household_membership.member_account)",
    ("SM-28", "Active Fee Waivers"): "count(distinct fee_waiver.fee_waiver_id) filter (where fee_waiver.waiver_period_start <= :as_of_date and (fee_waiver.waiver_period_end is null or fee_waiver.waiver_period_end >= :as_of_date))",
    ("SM-28", "Fee Calculation Runs"): "count(distinct fee_run.fee_calculation_run_id)",
    ("SM-28", "Run Control Total Variance"): "sum(fee_run.run_net_fee_total - (select coalesce(sum(c.net_fee), 0) from dp_305.account_fee_calculation c where c.calculation_run = fee_run.fee_calculation_run_id)) filter (where fee_run.run_status in ('Approved', 'Released'))",
    ("SM-28", "Billable Assets Billed"): "sum(account_fee_calculation.billable_assets)",
    ("SM-28", "Gross Billed Fees"): "sum(account_fee_calculation.gross_fee)",
    ("SM-28", "Fee Reductions Applied"): "sum(account_fee_calculation.discount_amount + account_fee_calculation.waiver_amount_applied + account_fee_calculation.own_fund_credit_amount)",
    ("SM-28", "Net Billed Fees"): "sum(account_fee_calculation.net_fee)",
    ("SM-28", "Average Effective Annual Rate"): "sum(account_fee_calculation.effective_annual_rate * account_fee_calculation.billable_assets) / nullif(sum(account_fee_calculation.billable_assets), 0)",
    ("SM-28", "Billed Fee Realization %"): "sum(account_fee_calculation.net_fee) * 100.0 / nullif(sum(account_fee_calculation.gross_fee), 0)",
    ("SM-28", "Failed Fee Debits"): "count(*) filter (where fee_debit.fee_debit_status = 'Failed')",
    ("SM-28", "Fee Runs Tested"): "count(distinct fee_run.fee_calculation_run_id) filter (where fee_run.run_status in ('Approved', 'Released') and fee_run.run_type <> 'Simulation')",
    ("SM-28", "Failed Fee Runs"): ("count(distinct fee_run.fee_calculation_run_id) filter (where fee_run.run_status in ('Approved', 'Released') and fee_run.run_type <> 'Simulation' and "
                                   "(fee_run.fee_reconciliation_status in ('Break Open', 'Not Reconciled') or (fee_run.run_status = 'Released' and fee_run.run_approved_by is null) or "
                                   "abs(fee_run.run_net_fee_total - (select coalesce(sum(c.net_fee), 0) from dp_305.account_fee_calculation c where c.calculation_run = fee_run.fee_calculation_run_id)) > 0.01))"),
    ("SM-28", "Accounts Billed Off Schedule"): "count(distinct fee_billing_test.test_calculated_assignment) filter (where fee_billing_test.off_schedule_flag = 1)",
    ("SM-28", "Billing Variance"): "sum(fee_billing_test.billing_variance) filter (where fee_billing_test.off_schedule_flag = 1)",
    ("SM-28", "Household Breakpoint Not Applied"): "count(*) filter (where fee_billing_test.household_breakpoint_not_applied = 1)",
    ("SM-28", "Total Cost to Serve"): "sum(cost_to_serve.total_cost_to_serve)",
    ("SM-28", "Cost to Serve Rate (bps)"): 'sum(cost_to_serve.total_cost_to_serve) * 12.0 / count(distinct cost_to_serve.cts_profitability_period) * 10000.0 / nullif(sum(cost_to_serve.average_client_assets_from_dp_008) / count(distinct cost_to_serve.cts_profitability_period), 0)',
    ("SM-28", "Cost to Serve per Household"): 'sum(cost_to_serve.total_cost_to_serve) * 12.0 / count(distinct cost_to_serve.cts_profitability_period) / nullif(sum(cost_to_serve.households_from_dp_008) / count(distinct cost_to_serve.cts_profitability_period), 0)',
    ("SM-28", "Pool-to-Pool Transfers"): 'sum(allocation_result.allocated_amount) filter (where allocation_rule.target_dimension is null)',
    ("SM-28", "Allocated Cost"): "sum(allocation_result.allocated_amount) filter (where allocation_rule.target_dimension = 'Channel')",
    ("SM-28", "Unallocated Residual Amount"): "sum(allocation_run.unallocated_residual)",
    ("SM-28", "Allocation Completeness %"): "sum(allocation_result.allocated_amount) filter (where allocation_rule.target_dimension = 'Channel') * 100.0 / (sum(allocation_result.allocated_amount) filter (where allocation_rule.target_dimension = 'Channel') + sum(allocation_run.unallocated_residual / (select count(*) from dp_480.allocation_result x where x.allocation_run_key = allocation_run.allocation_run_id)))",
    ("SM-28", "Active Allocation Rules"): "count(distinct allocation_rule.allocation_rule_id) filter (where allocation_rule.rule_effective_from <= :as_of_date and (allocation_rule.rule_effective_to is null or allocation_rule.rule_effective_to >= :as_of_date))",
    ("SM-28", "Gross Revenue"): "sum(profitability.gross_revenue)",
    ("SM-28", "Distribution Payments in Profitability"): "sum(profitability.distribution_payments)",
    ("SM-28", "Net Revenue After Distribution Costs"): "sum(profitability.net_revenue_after_distribution_costs)",
    ("SM-28", "Direct Sales & Marketing Cost"): "sum(profitability.direct_sales_marketing_cost)",
    ("SM-28", "Contribution Margin"): "sum(profitability.contribution_margin)",
    ("SM-28", "Contribution Margin %"): "sum(profitability.contribution_margin) * 100.0 / nullif(sum(profitability.gross_revenue), 0)",
    ("SM-28", "Allocated Indirect Cost"): "sum(profitability.allocated_indirect_cost)",
    ("SM-28", "Operating Profit"): "sum(profitability.operating_profit)",
    ("SM-28", "Operating Margin %"): "sum(profitability.operating_profit) * 100.0 / nullif(sum(profitability.gross_revenue), 0)",
    ("SM-28", "Net Revenue Yield on Client Assets (bps)"): "sum(profitability.net_revenue_after_distribution_costs) * 12.0 / count(distinct profitability.profitability_period) * 10000.0 / nullif(sum(profitability.average_client_assets_from_dp_008) / count(distinct profitability.profitability_period), 0)",
    ("SM-28", "Offerings and Segments With Negative Contribution"): 'count(*) filter (where profitability.offerings_and_segments_with_negative_contribution = 1)',
}
# Metrics the slice cannot compile, with the reason the model owner needs.
NOT_COMPILED = {
    ("SM-20", "Client Assets by Channel and Holding Type"): "spans two fact tables (account_asset_summary and intermediary_positions); needs a union fact or two queries added",
    ("SM-27", "Relationships Without Primary Contact"): "reads service_coverage, left out of the slice",
    ("SM-27", "Institutional Clients Without Current Profile"): "reads the relationship status beside the client profile; two tables",
    ("SM-27", "OCIO Relationships by Delegation"): "a count on the service_relationship dimension at a month-end; the demo keeps the relationship facts on relationship_health",
    ("SM-28", "Client Fee Revenue by Household"): "rolls account revenue to the 02 household through the owner role; a household bridge the demo leaves to SM-21",
    ("SM-28", "Yield Drift (bps)"): "needs the same period a year earlier; the demo's certified snapshots start in June 2026",
    ("SM-28", "Revenue by Client Segment Scheme"): "regroups by a chosen segmentation scheme; the demo carries one scheme, the segment at period end on the record",
    ("SM-28", "Billed to Client Fee Revenue Variance"): "the alignment of calculations to fiscal months is one third per month in the demo; the variance is zero by construction",
    ("SM-28", "Allocated Cost Tie-Out"): "cost to serve is derived from the same allocation results; the tie-out is zero by construction",
    ("SM-28", "Client Revenue Yield (bps)"): "two fact tables (client_revenue over DP-008 average client assets); ask Client Revenue by Stream by channel beside Average Client Assets, or Net Revenue Yield on Client Assets (bps) from profitability",
    ("SM-28", "Fee Revenue Yield (bps)"): "two fact tables (client_revenue over DP-008 average client assets); ask Client Fee Revenue beside Average Client Assets",
    ("SM-28", "Allocation to Ledger Difference"): "reads Pool Source Cost (DP-191 certified expense by cost center), outside the slice; the engine's POOL_COST extract is kept as a gap",
    ("SM-28", "Allocated Cost by Cost-to-Serve Component"): "a grouping of Allocated Cost by the rule's pool component; ask Allocated Cost by allocation_rule.source_cost_pool",
    ("SM-28", "Revenue to Cost to Serve Ratio"): "two base tables (client_revenue and cost_to_serve); ask Client Revenue by Stream and Total Cost to Serve by client segment",
}
# Notes on simplifications a steward should confirm.
NOTES = {
    ("SM-20", "Advisors With Net Outflows"): "the DP-009 advisor status condition is not applied (join to firm_advisor on dimension_key when needed)",
    ("SM-20", "Suggested Matches Awaiting Review"): "the threshold window is not applied; every Suggested result in the demo scores 85, inside MR-3's window",
    ("SM-20", "Intermediary-Held Own-Fund Value"): "no omnibus residual amounts in the demo; the once-per-omnibus term is zero",
    ("SM-27", "At-Risk Relationship Client Assets"): "the client assets attributed to the relationship's accounts at the month-end (DP-007 attribution records), with the latest health score on or before it; analytical, not a certified number: Client Assets by Institutional channel are SM-20's",
    ("SM-20", "Same-Owner Transfers Excluded"): "counts the credit legs of same-owner journals within one channel; same-owner journals across channels are Net Inter-Channel Transfers, reported separately",
    ("SM-28", "Gross Fee Revenue"): "the client fee streams of client_revenue; the own funds' management fee revenue (fee_revenue, gross and net of fund waivers) is the other half of the model's definition and answers through Fund Effective Net Fee Rate and fee_revenue's own columns; the firm total is the two added",
    ("SM-28", "Net Fee Revenue"): "equals Gross Fee Revenue on client_revenue: fund-level waiver and reimbursement offsets sit on fee_revenue",
    ("SM-28", "Effective Net Fee Rate"): "annualized from the months in the selected range over the billable assets of the calculations the revenue rows cite",
    ("SM-28", "Offerings and Segments With Negative Contribution"): "a cut is negative when its contribution margin over the trailing four fiscal quarters (to the as-of month) is below zero; the flag is computed in DP-499 at the latest month",
    ("SM-28", "Allocated Cost"): "the engine allocates every pool under each of its dimension rules in parallel (the same total per rule), so allocated cost is counted once, at the Channel cut every pool has; ask by allocation_rule.target_dimension for the other cuts",
    ("SM-28", "Cost to Serve Rate (bps)"): "over the certified Average Client Assets of the same dimension member and months (DP-008, Dimension Type Segment, Channel or Business Line)",
}
