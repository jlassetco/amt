"""Builds the physical layer from the confirmed mappings: loads the source extracts, then creates one conformed table
per mapped entity of the slice (table = the entity in snake case under its product, columns = the entity's attributes
in snake case), populated column by column from the mapping rows. Unmapped attributes stay NULL and are reported.
Derived products are built afterwards by derivations.py. Runs on DuckDB or Spark through compile/runtime.py.

Usage (from _tools/):  python activation/compile/physical.py [--runtime spark]     (needs activation/out/sources/ and slice.json)
"""
import importlib, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import _paths  # noqa: E402,F401
sys.path.insert(0, os.path.join(_paths.HERE, "mapping")); sys.path.insert(0, os.path.join(_paths.HERE, "sources")); sys.path.insert(0, HERE)
import config  # noqa: E402
import runtime  # noqa: E402
from runtime import snake, sql_type  # noqa: E402
from schema import SOURCES  # noqa: E402
import transforms  # noqa: E402

DB_PATH = os.path.join(_paths.OUT, "activation.duckdb")      # the DuckDB file (kept for the modules that open it read-only)
SRC_DIR = os.path.join(_paths.OUT, "sources")


def pschema(pid):
    return pid.lower().replace("-", "_")


def q(name):
    """DuckDB quoting, kept for the hand-written SQL that runtime.sql() translates."""
    return '"' + name.replace('"', '""') + '"'


# ------------------------------------------------------------------------------------------------- source loading
def load_sources(rt):
    """Every extract into the bronze layer (src_<source>.<TABLE> on DuckDB, bronze.<source>_<table> on Spark), as strings."""
    counts = {}
    for sid, src in SOURCES.items():
        for t, d in src["tables"].items():
            path = os.path.join(SRC_DIR, sid, f"{t}.csv")
            if not os.path.exists(path):
                raise SystemExit(f"missing extract {path}; run activation/sources/generate.py")
            cols = [c[0] for c in d["columns"]]
            tbl = rt.src(sid, t)
            rt.load_csv(tbl, path)
            have = rt.columns(tbl)
            if have != cols:
                raise SystemExit(f"{sid}/{t}: extract columns differ from schema.py:\n  have {have}\n  want {cols}")
            counts[f"{sid}/{t}"] = rt.count(tbl)
    return counts


# ------------------------------------------------------------------------------------------------- typing
def typed(rt, expr, atype):
    """Casts a STRING source expression to the attribute's type."""
    t = atype.split(" (")[0]
    if t == "Date":
        return rt.any_date(expr)
    if t == "Timestamp":
        return f"try_cast({expr} as timestamp)"
    if t in ("Amount", "Decimal", "Percentage", "Number"):
        return f"try_cast({expr} as double)"
    if t == "Integer":
        return f"try_cast({expr} as integer)"
    if t == "Boolean":
        return (f"coalesce(try_cast({expr} as boolean), case when upper(cast({expr} as string)) in ('Y', 'YES', 'TRUE', '1', 'T') then true "
                f"when upper(cast({expr} as string)) in ('N', 'NO', 'FALSE', '0', 'F') then false end)")
    return expr


def is_sql(rt, expr, from_sql):
    try:
        rt.exec(f"select {expr} from {from_sql} limit 0")
        return True
    except Exception:
        return False


# ------------------------------------------------------------------------------------------------- mapping -> SQL
def load_mappings():
    mods = {}
    for f in sorted(os.listdir(os.path.join(_paths.HERE, "mapping"))):
        if f.startswith("map_") and f.endswith(".py"):
            m = importlib.import_module(f[:-3]); mods[m.SOURCE["id"]] = m
    return mods


def crosswalk_case(rt, col, cw):
    parts = []
    for sv, tv, _ in cw["values"]:
        if sv == "":
            parts.append(f"when {col} is null then " + ("null" if tv is None else f"'{tv}'"))
        else:
            parts.append(f"when {col} = '{sv}' then " + ("null" if tv is None else f"'{tv}'"))
    return "(case " + " ".join(parts) + " else null end)"


def column_sql(rt, sid, m, t, col, kind, detail, attr, from_sql):
    """The SQL expression for one mapping row, or None when it is not executable (reported)."""
    if kind == "direct":
        return typed(rt, rt.q(col), attr["type"])
    if kind == "constant":
        return repr(detail) if sql_type(attr["type"]) == "STRING" else typed(rt, repr(detail), attr["type"])
    if kind == "crosswalk":
        return crosswalk_case(rt, rt.q(col), m.CROSSWALKS[detail])
    if kind == "identifier":
        return rt.q(col)                   # the source value; resolved to the enterprise key by resolve_references
    if kind == "derived":
        ov = transforms.DERIVED.get((sid, t, tuple(attr["taxonomy"]) + (attr["name"],)))
        if ov is not None:
            ov = rt.sql(ov)
            return typed(rt, ov, attr["type"]) if sql_type(attr["type"]) != "STRING" else ov
        base = re.sub(r"\s*\([^()]*\)\s*$", "", detail)
        candidates = [detail, base, detail.split(" where ")[0], base.split(" where ")[0], base.split(" for ")[0], detail.split(":")[0]]
        for expr in candidates:
            expr = rt.sql(expr)
            if expr and is_sql(rt, expr, from_sql):
                return typed(rt, expr, attr["type"]) if sql_type(attr["type"]) != "STRING" else expr
        return None
    return None


def build_entity(rt, slice_, key, mods, report):
    """One conformed table for a mapped entity, merged across the sources that feed it (column-level priority)."""
    e = slice_["entities"][key]
    pid, ename = e["product"], e["entity"]
    tname = rt.entity(pid, ename)
    cols = [a for a in e["attrs"] if not a["derived"] or a["name"] in e["pk"]]
    rt.create_table(tname, [(snake(a["name"]), sql_type(a["type"])) for a in cols])
    objects = {tuple(o) for o in e["objects"]}
    feeds = []
    for sid in config.SOURCE_PRIORITY:
        m = mods.get(sid)
        if not m:
            continue
        for t, obj, _ in m.OBJECTS:
            if tuple(obj) in objects and (sid, t) not in feeds:
                feeds.append((sid, t))
    if not feeds:
        report["entities"][key] = dict(table=tname, feeds=[], rows=0, columns={}, note="no source maps to this entity")
        return
    stg_tables, colinfo = [], {}
    for sid, t in feeds:
        m = mods[sid]
        shape = transforms.SHAPES.get((sid, t, key), {})
        from_sql = rt.sql(shape["from_sql"]) if shape.get("from_sql") else f"{rt.src(sid, t)} as {rt.q(t)}"   # aliased by its own name for correlated subqueries
        where = rt.sql(shape.get("where", ""))
        if shape.get("skip"):
            continue
        exprs, miss = {}, []
        for row in m.ATTRIBUTES:
            rt_, col, target, kind, detail = row
            if rt_ != t or tuple(target[:2]) not in objects or kind == "unmapped":
                continue
            attr = next((a for a in cols if a["name"] == target[2] and tuple(a["taxonomy"] or ()) == tuple(target[:2])), None)
            if attr is None:
                continue
            cname = snake(attr["name"])
            if cname in exprs and kind != "derived":
                continue                     # the first row for a column wins unless a derived override follows
            sql = column_sql(rt, sid, m, t, col, kind, detail, attr, from_sql)
            if sql is None:
                miss.append((cname, kind, detail)); continue
            if kind == "identifier":
                colinfo.setdefault(cname, {})["identifier"] = (sid, detail, attr)
            if kind == "derived" and cname in exprs and (sid, t, tuple(target)) in transforms.DERIVED:
                exprs[cname] = sql
            elif kind == "derived" and cname in exprs:
                exprs[cname] = f"coalesce({sql}, {exprs[cname]})"
            else:
                exprs[cname] = sql
        for c, sql in shape.get("override", {}).items():
            exprs[c] = rt.sql(sql)
        if not exprs:
            continue
        select = ", ".join(f"{sql} as {rt.q(c)}" for c, sql in exprs.items())
        stg = rt.stage(f"{snake(key)}__{sid.lower().replace('-', '_')}__{snake(t)}", f"select {select} from {from_sql}" + (f" where {where}" if where else ""))
        n = rt.count(stg)
        pkc = [snake(a) for a in e["pk"] if snake(a) in exprs]
        if pkc:        # duplicate keys inside one source make the merge pick a row by chance: a shape must settle it
            nd = rt.scalar(f"select count(*) from (select distinct {', '.join(rt.q(c) for c in pkc)} from {stg} where " + " and ".join(f"{rt.q(c)} is not null" for c in pkc) + ") d")
            nn = rt.scalar(f"select count(*) from {stg} where " + " and ".join(f"{rt.q(c)} is not null" for c in pkc))
            if nn != nd:
                report.setdefault("nondeterministic", []).append(dict(entity=key, source=sid, table=t, rows=nn, keys=nd))
        stg_tables.append((sid, t, stg, list(exprs), n))
        for c, k, d in miss:
            report["unbuilt"].append(dict(entity=key, source=sid, table=t, column=c, kind=k, detail=d))
    if not stg_tables:
        report["entities"][key] = dict(table=tname, feeds=[f"{s}/{t}" for s, t in feeds], rows=0, columns={}, note="no executable mapping rows")
        return
    pk = [snake(a) for a in e["pk"]]
    pk = [c for c in pk if any(c in cs for _, _, _, cs, _ in stg_tables)]
    merge_sql(rt, tname, [snake(a["name"]) for a in cols], pk, stg_tables)
    rows = rt.count(tname)
    filled = {}
    for a in cols:
        c = snake(a["name"])
        if any(c in cs for _, _, _, cs, _ in stg_tables):
            nn = rt.scalar(f"select count({rt.q(c)}) from {tname}")
            filled[c] = dict(sources=[f"{s}/{t}" for s, t, _, cs, _ in stg_tables if c in cs], non_null=nn)
    report["entities"][key] = dict(table=tname, feeds=[f"{s}/{t}" for s, t, _, _, _ in stg_tables], rows=rows, pk=pk,
                                   columns=filled, unmapped=[snake(a["name"]) for a in cols if snake(a["name"]) not in filled])
    for cname, info in colinfo.items():
        report["identifiers"].append(dict(entity=key, column=cname, source=info["identifier"][0], scheme=info["identifier"][1],
                                          type=info["identifier"][2]["type"]))


def merge_sql(rt, target, all_cols, pk, stg_tables):
    """Union the staging relations; when a key is fed by several sources, take each column from the first source that has it."""
    if not pk:
        for sid, t, stg, cs, n in stg_tables:
            rt.insert_select(target, cs, f"select {', '.join(rt.q(c) for c in cs)} from {stg}")
        return
    parts = []
    for i, (sid, t, stg, cs, n) in enumerate(stg_tables):
        sel = ", ".join((rt.q(c) if c in cs else "null") + f" as {rt.q(c)}" for c in all_cols)
        parts.append(f"select {i} as _prio, {sel} from {stg} where " + " and ".join(f"{rt.q(c)} is not null" for c in pk))
    union = " union all ".join(parts)
    agg = ", ".join(f"min_by({rt.q(c)}, case when {rt.q(c)} is null then 1000000 else _prio end) as {rt.q(c)}" if c not in pk else rt.q(c) for c in all_cols)
    rt.insert_select(target, all_cols, f"select {agg} from ({union}) u group by {', '.join(rt.q(c) for c in pk)}")


# ------------------------------------------------------------------------------------------------- references
def resolve_references(rt, slice_, report):
    """Identifier columns hold source numbers; rewrite them to enterprise keys through the identifier entities."""
    acc_id, pty_id = rt.entity("DP-093", "Account Identifier"), rt.entity("DP-240", "Party Identifier")
    for item in report["identifiers"]:
        key, c, sid, scheme = item["entity"], item["column"], item["source"], item["scheme"]
        e = slice_["entities"][key]; tbl = rt.entity(e["product"], e["entity"])
        attr = next(a for a in e["attrs"] if snake(a["name"]) == c)
        if attr["name"] in ("Account Identifier Value", "Identifier Value"):
            continue                           # the identifier entities keep the raw value
        tgt = re.match(r"Reference \(([^,)]+)", attr["type"])
        ref = tgt.group(1) if tgt else ""
        if ref == "Account":
            idt, scol, vcol, kcol, prefix = acc_id, "account_identifier_scheme", "account_identifier_value", "identified_account", "ACC-%"
        elif ref == "Party":
            idt, scol, vcol, kcol, prefix = pty_id, "identifier_scheme", "identifier_value", "identified_party", "PTY-%"
        else:
            continue
        label = transforms.SCHEME_LABEL[(sid, scheme)].replace("'", "''")
        cols = rt.columns(tbl)
        sel = ", ".join(f"coalesce(i.{rt.q(kcol)}, x.{rt.q(col)}) as {rt.q(col)}" if col == c else f"x.{rt.q(col)}" for col in cols)
        rt.replace_from_select(tbl, f"""select {sel} from {tbl} x
            left join (select {rt.q(vcol)} as v, max({rt.q(kcol)}) as {rt.q(kcol)} from {idt} where {rt.q(scol)} = '{label}' group by {rt.q(vcol)}) i
                   on i.v = x.{rt.q(c)} and x.{rt.q(c)} not like '{prefix}'""")
        item["unresolved"] = rt.scalar(f"select count(*) from {tbl} where {rt.q(c)} is not null and {rt.q(c)} not like '{prefix}'")
    # two sources that named the same party by different numbers now agree on the key: collapse to one row per key,
    # taking the non-null value of every other column (a close date one source has and the other leaves blank)
    for key, r in report["entities"].items():
        if r["rows"]:
            pk = r.get("pk") or []
            cols = rt.columns(r["table"])
            if pk and all(p in cols for p in pk):
                others = ", ".join(f"max({rt.q(c)}) as {rt.q(c)}" for c in cols if c not in pk)
                sel = ", ".join(rt.q(c) for c in pk) + (", " + others if others else "")
                rt.replace_from_select(r["table"], f"select {sel} from {r['table']} group by {', '.join(rt.q(c) for c in pk)}")
            else:
                rt.replace_from_select(r["table"], f"select distinct * from {r['table']}")
            r["rows"] = rt.count(r["table"])


def main(rt=None, log=print):
    rt = rt or runtime.get()
    slice_ = json.load(open(os.path.join(_paths.OUT, "slice.json")))
    mods = load_mappings()
    report = dict(runtime=rt.name, sources=load_sources(rt), entities={}, unbuilt=[], identifiers=[])
    transforms.prepare(rt)
    order = sorted(k for k, e in slice_["entities"].items() if e["product"] not in config.DERIVED_PRODUCTS)
    order.sort(key=lambda k: (0 if k.endswith("Identifier") else 1, k))
    for key in order:
        build_entity(rt, slice_, key, mods, report)
    transforms.after_mapping(rt)
    resolve_references(rt, slice_, report)
    with open(os.path.join(rt.out, "physical_report.json"), "w") as f:
        json.dump(report, f, indent=1)
    log(f"sources: {sum(report['sources'].values())} rows in {len(report['sources'])} tables ({rt.name})")
    for k, r in report["entities"].items():
        log(f"  {r['table']:46s} {r['rows']:7d} rows  {len(r['columns']):3d} columns filled, {len(r.get('unmapped', [])):3d} unmapped   <- {', '.join(r['feeds'])}")
    if report["unbuilt"]:
        log(f"derived rows without executable SQL ({len(report['unbuilt'])}):")
        for u in report["unbuilt"]:
            log(f"  {u['entity']}.{u['column']} [{u['source']}/{u['table']}]: {u['detail'][:100]}")
    for d in report.get("nondeterministic", []):
        log(f"  WARNING {d['entity']} from {d['source']}/{d['table']}: {d['rows']} rows for {d['keys']} keys; the merge picks by chance (add a shape)")
    unres = [i for i in report["identifiers"] if i.get("unresolved")]
    for i in unres:
        log(f"  unresolved: {i['entity']}.{i['column']}: {i['unresolved']} value(s) not resolved through {i['scheme']}")
    return report


if __name__ == "__main__":
    rt = runtime.get()
    rt.reset()
    main(rt)
    rt.close()
