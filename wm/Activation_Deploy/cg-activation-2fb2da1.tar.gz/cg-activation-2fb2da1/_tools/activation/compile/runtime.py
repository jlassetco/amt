"""The runtime the activation compiles onto: DuckDB (the fast reference) or local Spark with Delta Lake laid out the
way a Databricks workspace is (schemas bronze, silver and gold; Delta tables; Spark SQL). Every module that builds or
reads tables goes through a Runtime: it owns naming, identifier quoting, the few dialect-specific helpers, table
creation and loading, and `sql()`, which translates the hand-written DuckDB-flavored SQL of transforms.py,
derivations.py and expressions.py to the runtime's dialect.

    rt = runtime.get()              # ACTIVATION_RUNTIME=duckdb|spark (default duckdb), or --runtime on the command line
    rt.src("SRC-BRK", "ACCT_MASTER")      -> src_brk."ACCT_MASTER"   |  bronze.brk_acct_master
    rt.entity("DP-093", "Account")        -> dp_093."account"        |  silver.dp_093_account
    rt.tbl("cert", "measure_wide")        -> cert.measure_wide       |  gold.cert_measure_wide
    rt.view("SM-20", "client_assets_flows") -> sem.sm20_client_assets_flows | gold.sm20_client_assets_flows

Layers on Spark: bronze = the source extracts as landed; silver = the conformed foundational products and the
books-of-record derivations (DP-006, DP-007); gold = the certified family (DP-008), the consumer facts (DP-320,
DP-495), the helper tables and the semantic views. Databricks' Unity Catalog adds a catalog level in front
(`config.CATALOG`), which the exported assets carry and the local session leaves out.
"""
import os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ACT = os.path.dirname(HERE)
sys.path.insert(0, ACT)
import config  # noqa: E402

OUT = os.path.join(ACT, "out")
GOLD_PRODUCTS = {"DP-008", "DP-320", "DP-495"}
LISTAGG = re.compile(r"__LISTAGG__\((\w+)\)")   # ordered, "; "-separated list of a column within a group, per engine
SOURCE_SHORT = {"SRC-BRK": "brk", "SRC-CRM": "crm", "SRC-TA": "ta", "SRC-INST": "inst", "SRC-PAB": "pab", "SRC-BIL": "bil", "SRC-REV": "rev", "SRC-CST": "cst"}
SQL_TYPES = {"Date": "DATE", "Timestamp": "TIMESTAMP", "Amount": "DOUBLE", "Decimal": "DOUBLE", "Percentage": "DOUBLE",
             "Number": "DOUBLE", "Integer": "INTEGER", "Boolean": "BOOLEAN"}


def snake(s):
    return re.sub(r"[^a-z0-9]+", "_", s.lower()).strip("_")


def sql_type(atype):
    return SQL_TYPES.get(atype.split(" (")[0], "STRING")


class Runtime:
    name = ""

    # ---- naming
    def q(self, name): raise NotImplementedError
    def src(self, sid, table): raise NotImplementedError
    def entity(self, pid, ename): raise NotImplementedError
    def tbl(self, layer, name): raise NotImplementedError
    def view(self, mid, tname): return self.tbl("sem", f"{mid.lower().replace('-', '')}_{tname}")
    def public_view(self, mid, tname): return self.tbl("sem_public", f"{mid.lower().replace('-', '')}_{tname}")

    # ---- dialect helpers (expressions over STRING source columns)
    def date8(self, expr): raise NotImplementedError            # 'YYYYMMDD' -> DATE (null when unparsable)
    def any_date(self, expr):                                   # ISO 8601 or YYYYMMDD, whichever parses
        return f"coalesce(try_cast({expr} as date), {self.date8(f'cast({expr} as string)')})"
    def fmt8(self, expr): raise NotImplementedError             # DATE -> 'YYYYMMDD'
    def add_days(self, expr, n): raise NotImplementedError
    def multi_map(self, col, mapping):                          # 'A;B' -> 'label A; label B'
        raise NotImplementedError
    def unnest_values(self, table, col, sep="; "):              # subquery: one row (v) per element of a separated list column
        raise NotImplementedError
    def list_has(self, col, value, sep="; "):                   # boolean: a separated list column contains the value expression
        raise NotImplementedError

    # ---- execution
    def exec(self, sql, params=None): raise NotImplementedError
    def fetch(self, sql, params=None): raise NotImplementedError
    def fetchone(self, sql, params=None):
        rows = self.fetch(sql, params); return rows[0] if rows else None
    def scalar(self, sql, params=None):
        r = self.fetchone(sql, params); return r[0] if r else None
    def columns(self, table): raise NotImplementedError
    def has_table(self, table):
        try:
            self.columns(table); return True
        except Exception:
            return False
    def select_columns(self, select_sql): raise NotImplementedError
    def table_exists(self, table): raise NotImplementedError
    def create_table(self, table, coldefs): raise NotImplementedError     # coldefs: [(name, SQL type)]
    def create_table_as(self, table, select_sql): raise NotImplementedError
    def create_view(self, view, select_sql): raise NotImplementedError
    def insert_select(self, table, cols, select_sql):
        self.exec(f"insert into {table} ({', '.join(self.q(c) for c in cols)}) {select_sql}")
    def insert_rows(self, table, cols, rows): raise NotImplementedError
    def load_csv(self, table, path): raise NotImplementedError
    def stage(self, name, select_sql): raise NotImplementedError          # a staging relation; returns its name
    def close(self): pass
    def count(self, table): return self.scalar(f"select count(*) from {table}")
    def replace_from_select(self, table, select_sql):
        """Rebuilds a table from a select that reads it (a resolution or a de-duplication): materialize, then replace."""
        tmp = table.rsplit(".", 1)[0] + "." + table.rsplit(".", 1)[1].strip('"`') + "__tmp"
        self.create_table_as(tmp, select_sql)
        self.create_table_as(table, f"select * from {tmp}")
        self.exec(f"drop table {tmp}")

    # ---- translation of hand-written SQL
    def sql(self, text): return LISTAGG.sub(lambda m: f"string_agg({m.group(1)}, '; ' order by {m.group(1)})", text)


class DuckRuntime(Runtime):
    name = "duckdb"

    def __init__(self, path=None):
        for m in ("pandas", "numpy", "pyarrow", "polars"):      # DuckDB probes for these on every parameterized call; a failed import walks the whole path
            sys.modules.setdefault(m, None)
        import duckdb
        self.out = OUT
        self.path = path or os.path.join(OUT, "activation.duckdb")
        self.con = duckdb.connect(self.path)
        for s in ("stg", "cert", "sem", "sem_public"):
            self.con.execute(f"create schema if not exists {s}")

    def q(self, name): return '"' + name.replace('"', '""') + '"'
    def src(self, sid, table): return f"src_{SOURCE_SHORT[sid]}.{self.q(table)}"
    def entity(self, pid, ename): return f"{pid.lower().replace('-', '_')}.{self.q(snake(ename))}"
    def tbl(self, layer, name): return f"{layer}.{name}"
    def date8(self, expr): return f"cast(try_strptime({expr}, '%Y%m%d') as date)"
    def fmt8(self, expr): return f"strftime({expr}, '%Y%m%d')"
    def add_days(self, expr, n): return f"cast({expr} + interval {n} day as date)"
    def multi_map(self, col, mapping):
        cases = " ".join(f"when '{k}' then '{v}'" for k, v in mapping.items())
        return f"array_to_string(list_transform(string_split({col}, ';'), x -> case x {cases} else x end), '; ')"
    def unnest_values(self, table, col, sep="; "):
        return f"(select trim(v) as v from {table}, unnest(string_split(cast({self.q(col)} as string), '{sep}')) as u(v) where {self.q(col)} is not null)"
    def list_has(self, col, value, sep="; "):
        return f"list_contains(string_split(cast({col} as string), '{sep}'), {value})"
    def exec(self, sql, params=None): self.con.execute(sql, params or [])
    def fetch(self, sql, params=None): return self.con.execute(sql, params or []).fetchall()
    def columns(self, table): return [r[1] for r in self.con.execute(f"pragma table_info('{table.replace(chr(34), '')}')").fetchall()]
    def select_columns(self, select_sql): return [r[0] for r in self.con.execute(f"describe select * from ({select_sql}) x").fetchall()]
    def table_exists(self, table):
        try:
            self.con.execute(f"select 1 from {table} limit 0"); return True
        except Exception:
            return False
    def create_table(self, table, coldefs):
        sch = table.split(".")[0]
        self.con.execute(f"create schema if not exists {sch}")
        self.con.execute(f"create or replace table {table} (" + ", ".join(f"{self.q(c)} {t if t != 'STRING' else 'VARCHAR'}" for c, t in coldefs) + ")")
    def create_table_as(self, table, select_sql):
        self.con.execute(f"create schema if not exists {table.split('.')[0]}")
        self.con.execute(f"create or replace table {table} as {select_sql}")
    def create_view(self, view, select_sql):
        self.con.execute(f"create schema if not exists {view.split('.')[0]}")
        self.con.execute(f"create or replace view {view} as {select_sql}")
    def insert_rows(self, table, cols, rows):
        self.con.executemany(f"insert into {table} ({', '.join(self.q(c) for c in cols)}) values ({', '.join('?' for _ in cols)})", rows)
    def load_csv(self, table, path):
        self.con.execute(f"create schema if not exists {table.split('.')[0]}")
        self.con.execute(f"create or replace table {table} as select * from read_csv(?, header=true, all_varchar=true)", [path])
        for c in self.columns(table):
            self.con.execute(f"update {table} set {self.q(c)} = null where {self.q(c)} = ''")
    def stage(self, name, select_sql):
        t = self.tbl("stg", name); self.con.execute(f"create or replace table {t} as {select_sql}"); return t
    def reset(self):
        """A fresh database file."""
        self.con.close(); os.remove(self.path) if os.path.exists(self.path) else None; self.__init__(self.path)
    def close(self): self.con.close()


class SparkRuntime(Runtime):
    name = "spark"

    def __init__(self):
        jh = os.path.join(ACT, ".jdk", "JAVA_HOME")
        if os.path.exists(jh) and not os.environ.get("JAVA_HOME"):
            os.environ["JAVA_HOME"] = open(jh).read().strip()
        os.environ.setdefault("SPARK_LOCAL_IP", "127.0.0.1")
        from pyspark.sql import SparkSession
        from delta import configure_spark_with_delta_pip
        self.out = os.path.join(OUT, "spark")
        os.makedirs(self.out, exist_ok=True)
        b = (SparkSession.builder.appName("cg-activation").master(f"local[{config.SPARK_CORES}]")
             .config("spark.driver.memory", config.SPARK_DRIVER_MEMORY).config("spark.sql.shuffle.partitions", "8")
             .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
             .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
             .config("spark.sql.warehouse.dir", os.path.join(self.out, "warehouse"))
             # a persistent catalog, as a workspace has: the Hive metastore in a local Derby database
             .config("spark.sql.catalogImplementation", "hive")
             .config("spark.hadoop.javax.jdo.option.ConnectionURL", f"jdbc:derby:;databaseName={os.path.join(self.out, 'metastore_db')};create=true")
             .config("spark.driver.extraJavaOptions", f"-Dderby.system.home={self.out} -Dderby.stream.error.file={os.path.join(self.out, 'derby.log')}")
             .config("spark.databricks.delta.schema.autoMerge.enabled", "false")
             .config("spark.sql.legacy.allowNonEmptyLocationInCTAS", "true")
             .config("spark.ui.enabled", "false").config("spark.sql.ansi.enabled", "false").enableHiveSupport())
        self.spark = configure_spark_with_delta_pip(b).getOrCreate()
        self.spark.sparkContext.setLogLevel("ERROR")
        for s in ("bronze", "silver", "gold"):
            self.spark.sql(f"create database if not exists {s}")

    def q(self, name): return "`" + name.replace("`", "``") + "`"
    def src(self, sid, table): return f"bronze.{SOURCE_SHORT[sid]}_{table.lower()}"
    def entity(self, pid, ename):
        layer = "gold" if pid in GOLD_PRODUCTS else "silver"
        return f"{layer}.{pid.lower().replace('-', '_')}_{snake(ename)}"
    def tbl(self, layer, name):
        return {"cert": f"gold.cert_{name}", "sem": f"gold.{name}", "sem_public": f"gold.pub_{name}", "stg": f"stg_{name}"}.get(layer, f"{layer}.{name}")
    def date8(self, expr): return f"cast(try_to_timestamp({expr}, 'yyyyMMdd') as date)"
    def fmt8(self, expr): return f"date_format({expr}, 'yyyyMMdd')"
    def add_days(self, expr, n): return f"date_add({expr}, {n})"
    def multi_map(self, col, mapping):
        cases = " ".join(f"when '{k}' then '{v}'" for k, v in mapping.items())
        return f"array_join(transform(split({col}, ';'), x -> case x {cases} else x end), '; ')"
    def unnest_values(self, table, col, sep="; "):
        return f"(select trim(v) as v from {table} lateral view explode(split(cast({self.q(col)} as string), '{sep}')) u as v where {self.q(col)} is not null)"
    def list_has(self, col, value, sep="; "):
        return f"array_contains(split(cast({col} as string), '{sep}'), {value})"
    def exec(self, sql, params=None): self.spark.sql(self._bind(sql, params))
    def fetch(self, sql, params=None): return [tuple(r) for r in self.spark.sql(self._bind(sql, params)).collect()]
    def _bind(self, sql, params):
        for p in params or []:
            sql = sql.replace("?", "'" + str(p).replace("'", "''") + "'", 1)
        return sql
    def columns(self, table): return self.spark.table(table).columns
    def select_columns(self, select_sql): return self.spark.sql(select_sql).columns
    def table_exists(self, table): return self.spark.catalog.tableExists(table)
    def _clear(self, table):
        """Drop the table and remove a leftover managed location (a failed earlier run leaves a non-Delta directory)."""
        import shutil
        self.spark.sql(f"drop table if exists {table}")
        sch, name = table.split(".", 1)
        loc = os.path.join(self.out, "warehouse", f"{sch}.db", name.strip("`"))
        if os.path.isdir(loc):
            shutil.rmtree(loc, ignore_errors=True)
    def create_table(self, table, coldefs):
        self._clear(table)
        self.spark.sql(f"create table {table} (" + ", ".join(f"{self.q(c)} {t}" for c, t in coldefs) + ") using delta")
    def create_table_as(self, table, select_sql):
        if not self.spark.catalog.tableExists(table):
            self._clear(table)
        self.spark.sql(f"create or replace table {table} using delta as {select_sql}")
    def reset(self):
        """A fresh warehouse: every layer dropped and its files removed."""
        import shutil
        for s in ("bronze", "silver", "gold"):
            self.spark.sql(f"drop database if exists {s} cascade")
        shutil.rmtree(os.path.join(self.out, "warehouse"), ignore_errors=True)
        for s in ("bronze", "silver", "gold"):
            self.spark.sql(f"create database {s}")
    def create_view(self, view, select_sql):
        self.spark.sql(f"create or replace view {view} as {select_sql}")
    def insert_select(self, table, cols, select_sql):
        """Insert by name: the select's columns land in the table's columns of the same name, the rest stay null."""
        tcols = self.columns(table)
        types = {f.name: f.dataType.simpleString() for f in self.spark.table(table).schema.fields}
        sel = ", ".join(f"x.{self.q(c)}" if c in cols else f"cast(null as {types[c]}) as {self.q(c)}" for c in tcols)
        self.spark.sql(f"insert into {table} select {sel} from ({select_sql}) x")
    def insert_rows(self, table, cols, rows):
        """Rows as SQL VALUES in batches (PySpark's createDataFrame needs Python serialization, which Python 3.14 breaks)."""
        import datetime as _dt
        def lit(v):
            if v is None: return "null"
            if isinstance(v, bool): return "true" if v else "false"
            if isinstance(v, (int, float)): return repr(v)
            if isinstance(v, _dt.datetime): return f"timestamp '{v.isoformat(sep=' ')}'"
            if isinstance(v, _dt.date): return f"date '{v.isoformat()}'"
            return "'" + str(v).replace("'", "''") + "'"
        for i in range(0, len(rows), 500):
            vals = ", ".join("(" + ", ".join(lit(v) for v in r) + ")" for r in rows[i:i + 500])
            self.insert_select(table, cols, f"select * from (values {vals}) as v({', '.join(self.q(c) for c in cols)})")
    def load_csv(self, table, path):
        df = self.spark.read.option("header", "true").option("inferSchema", "false").csv(path)
        df.createOrReplaceTempView("_csv_")
        self.spark.sql(f"create or replace table {table} using delta as select * from _csv_")
    def stage(self, name, select_sql):
        t = self.tbl("stg", name); self.spark.sql(f"create or replace temporary view {t} as {select_sql}"); return t
    def close(self): self.spark.stop()

    # ---- translation of hand-written DuckDB-flavored SQL
    def sql(self, text):
        t = LISTAGG.sub(lambda m: f"array_join(sort_array(collect_list({m.group(1)})), '; ')", text)
        t = re.sub(r'\bsrc_(brk|crm|ta|inst|pab|bil|rev|cst)\."([^"]+)"', lambda m: f"bronze.{m.group(1)}_{m.group(2).lower()}", t)
        t = re.sub(r'\bsrc_(brk|crm|ta|inst|pab|bil|rev|cst)\.(\w+)', lambda m: f"bronze.{m.group(1)}_{m.group(2).lower()}", t)
        t = re.sub(r'\bdp_(\d{3})\."([^"]+)"', lambda m: self.entity(f"DP-{m.group(1)}", m.group(2)), t)
        t = re.sub(r'\bdp_(\d{3})\.(\w+)', lambda m: self.entity(f"DP-{m.group(1)}", m.group(2)), t)
        t = re.sub(r'\bcert\.(\w+)', lambda m: self.tbl("cert", m.group(1)), t)
        t = re.sub(r'\bstg\.(\w+)', lambda m: self.tbl("stg", m.group(1)), t)
        t = re.sub(r'\bsem_public\.(\w+)', lambda m: self.tbl("sem_public", m.group(1)), t)
        t = re.sub(r'\bsem\.(\w+)', lambda m: self.tbl("sem", m.group(1)), t)
        t = re.sub(r'"([^"]+)"', lambda m: self.q(m.group(1)), t)                    # identifiers; string literals use single quotes
        t = re.sub(r"try_strptime\(([^()]+(?:\([^()]*\))?[^()]*), '%Y%m%d'\)", lambda m: f"try_to_timestamp({m.group(1)}, 'yyyyMMdd')", t)
        t = re.sub(r"strftime\(([^,]+), '%Y%m%d'\)", lambda m: f"date_format({m.group(1)}, 'yyyyMMdd')", t)
        t = t.replace("list_transform(string_split(", "transform(split(").replace("array_to_string(", "array_join(")
        t = re.sub(r"\bas varchar\b", "as string", t)
        t = t.replace("arg_min(", "min_by(").replace("arg_max(", "max_by(")
        t = re.sub(r"\binterval (\d+) day\b", r"interval \1 days", t)
        return t


class _Names:
    """Naming only, without opening a session (for exporters that write table names into assets)."""
    def __init__(self, cls):
        self._c = cls
    def __getattr__(self, k):
        f = getattr(self._c, k)
        return lambda *a, **kw: f(self, *a, **kw)
    out = OUT


def names(name="spark"):
    return _Names(SparkRuntime if name == "spark" else DuckRuntime)


def selected_name(name=None):
    """The runtime name the command line or environment selects, without opening a session."""
    if name is None:
        for i, a in enumerate(sys.argv):
            if a == "--runtime" and i + 1 < len(sys.argv):
                name = sys.argv[i + 1]
            elif a.startswith("--runtime="):
                name = a.split("=", 1)[1]
    return name or os.environ.get("ACTIVATION_RUNTIME", "duckdb")


def out_dir(name=None):
    name = selected_name(name)
    return OUT if name == "duckdb" else os.path.join(OUT, name)


_RT = None


def get(name=None):
    """The runtime for this process: --runtime on the command line, else ACTIVATION_RUNTIME, else duckdb."""
    global _RT
    if _RT is not None:
        return _RT
    name = selected_name(name)
    _RT = SparkRuntime() if name == "spark" else DuckRuntime()
    return _RT


if __name__ == "__main__":
    rt = get()
    print(rt.name, rt.src("SRC-BRK", "ACCT_MASTER"), rt.entity("DP-093", "Account"), rt.entity("DP-008", "Measure Value"), rt.view("SM-20", "client_assets_flows"))
    print(rt.sql('select r."TXN_ID", cast(try_strptime(a."DOB", \'%Y%m%d\') as date) from src_brk."ACTIVITY" r join dp_300.client_account_activity a on 1=1 where x = date \'2026-09-30\' + interval 1 day'))
    print(rt.fetch("select 1 as one, cast(null as string) as s, date '2026-09-30' + interval 1 day as d"))
    rt.close()
