"""Compiles the semantic models of the slice onto the physical layer: one DuckDB view per semantic table (schema
sem), with the model's column names, parameter-free always-filters applied and the entity keys carried; the joins
and metrics resolved to SQL and proven by execution; and the compiled model written to activation/out/compiled_model.json
for the query engine, the dbt export, the coverage report and the demo page.

Usage (from _tools/):  python activation/compile/semantic.py      (after derivations.py)
"""
import json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import _paths  # noqa: E402,F401
sys.path.insert(0, HERE)
import config  # noqa: E402
import expressions as X  # noqa: E402
import runtime  # noqa: E402
from runtime import snake  # noqa: E402

RT = None          # the runtime of this compile; set in main (q() quotes for it)


def q(name):
    return RT.q(name) if RT else '"' + name.replace('"', '""') + '"'


def physical_of(slice_, t):
    e = slice_["entities"][t["entity_key"]]
    return RT.entity(e["product"], e["entity"]), e


def column_map(con, slice_, t):
    """semantic column -> physical column (those that exist), with the entity's keys added when the table omits them."""
    tbl, e = physical_of(slice_, t)
    have = set(con.columns(tbl))
    cols, missing = {}, []
    for c in t["columns"]:
        if snake(c["attr"]) in have:
            cols[c["name"]] = snake(c["attr"])
        else:
            missing.append(c["name"])
    for a in e["attrs"]:                      # keys, foreign keys and materialized measures ride along (joins and metrics need them)
        if a["name"] in e["pk"] or a.get("fk") or a["type"].startswith("Reference (") or a["type"] == "Foreign key" or a.get("derived"):
            phys = snake(a["name"])
            if phys in have and phys not in cols.values():
                cols[phys] = phys
    return cols, missing


def build_views(con, slice_, compiled):
    for key, t in slice_["tables"].items():
        mid, tname = t["model"], t["name"]
        tbl, e = physical_of(slice_, t)
        filters = [con.sql(f) for f in X.ALWAYS.get((mid, tname), []) if ":" not in f]
        params = [con.sql(f) for f in X.ALWAYS.get((mid, tname), []) if ":" in f]
        if (mid, tname) in X.UNSUPPORTED_TABLES:
            compiled["tables"][key] = dict(model=mid, name=tname, view=None, physical=tbl, reason=X.UNSUPPORTED_TABLES[(mid, tname)])
            continue
        if not con.has_table(tbl):  # a shared dimension no source of the slice populates (its product is not started)
            compiled["tables"][key] = dict(model=mid, name=tname, view=None, physical=tbl, kind=t["kind"], product=t["product"], entity=t["entity"],
                                           reason=f"no source of the slice populates {t['product']} {t['entity']}", not_materialized=[c["name"] for c in t["columns"]])
            continue
        cols, missing = column_map(con, slice_, t)
        select = ", ".join(f"{q(p)} as {q(s)}" for s, p in cols.items())
        where = (" where " + " and ".join(f"({f})" for f in filters)) if filters else ""
        vn = con.view(mid, tname)
        con.create_view(vn, f"select {select} from {tbl}{where}")
        pii = [s for s, p in cols.items() if any(a["pii"] and snake(a["name"]) == p for a in e["attrs"])]
        pub = [s for s in cols if s not in pii]
        if pub:
            con.create_view(con.public_view(mid, tname), f"select {', '.join(q(s) for s in pub)} from {vn}")
        rows = con.count(vn)
        populated = {s: con.scalar(f"select count({q(s)}) from {vn}") for s in cols}
        compiled["tables"][key] = dict(model=mid, name=tname, view=vn, physical=tbl, kind=t["kind"], grain=t["grain"], product=t["product"], entity=t["entity"],
                                       columns=cols, pii_columns=pii, always_filter_sql=filters, query_filters=params,
                                       always_filter_text=t["always_filter"], default_filter_text=t["default_filter"],
                                       default_as_of_column=X.DEFAULT_AS_OF.get((mid, tname)), fiscal_code_as_of=(X.DEFAULT_AS_OF.get((mid, tname)) in X.FISCAL_CODE_COLUMNS),
                                       dimension_grain_of={c: g for c, g in X.DIMENSION_GRAIN_OF.items() if c in cols}, rows=rows, populated=populated,
                                       unpopulated=[s for s, n in populated.items() if n == 0],
                                       not_materialized=missing)


def resolve_table(slice_, mid, ref):
    """A relationship end: a table of the model, or a shared 'DP-nnn/Entity' reference -> the SM-00 table key(s)."""
    if ref in slice_["shared"]:
        return [f"SM-00.{n}" for n in slice_["shared"][ref]]
    return [f"{mid}.{ref}"] if f"{mid}.{ref}" in slice_["tables"] else []


def build_joins(con, slice_, compiled):
    for r in slice_["relationships"] + [dict(x, warning="") for x in X.EXTRA_RELATIONSHIPS if x["model"] in slice_["models"]]:
        mid = r["model"]
        frm_keys, to_keys = resolve_table(slice_, mid, r["frm"]), resolve_table(slice_, mid, r["to"])
        ov = X.JOINS.get((mid, r["frm"], r["to"]), "")
        rec = dict(model=mid, frm=r["frm"], to=r["to"], type=r["type"], text=r["on"], warning=r.get("warning", ""), sql=None, frm_table=None, to_table=None, executable=False, reason="")
        if ov is None:
            rec["reason"] = "many-to-many through a bridge table; not a direct join"; compiled["joins"].append(rec); continue
        candidates = [ov] if ov else [r["on"]]
        for fk in frm_keys:
            for tk in to_keys:
                ft, tt = compiled["tables"].get(fk), compiled["tables"].get(tk)
                if not ft or not tt or not ft.get("view") or not tt.get("view"):
                    continue
                for cand in candidates:
                    sql = qualify_override(cand, ft["name"], tt["name"]) if ov else normalize_join(cand, ft["name"], tt["name"])
                    if sql and try_sql(con, f"select 1 from {ft['view']} as {q(ft['name'])} join {tt['view']} as {q(tt['name'])} on {sql} limit 1"):
                        rec.update(sql=sql, frm_table=fk, to_table=tk, executable=True); break
                if rec["executable"]:
                    break
            if rec["executable"]:
                break
        if not rec["executable"]:
            rec["reason"] = "the join text is a sentence with no executable form yet" if not ov else "the override did not execute"
        compiled["joins"].append(rec)


def qualify_override(text, frm_name, to_name):
    """An override from expressions.JOINS, with its table.column references quoted onto the two view aliases."""
    names = {frm_name, to_name} | {k for k, v in X.TABLE_ALIAS.items() if v in (frm_name, to_name)}
    def rep(m):
        t, c = m.group(1), m.group(2)
        t = X.TABLE_ALIAS.get(t, t)
        return f"{q(t)}.{q(c)}" if t in (frm_name, to_name) else m.group(0)
    out = re.sub(r"\b([a-z_][a-z0-9_]*)\.([a-z_][a-z0-9_]*)\b", rep, text)
    return out if out != text or any(n + "." in text for n in names) else None


def normalize_join(text, frm_name, to_name):
    """Takes the first `a.b = c.d` of the text and maps the model's table names onto the view aliases."""
    m = re.search(r"(?:([A-Za-z_][\w]*)\.)?([\w]+)\s*=\s*(?:([A-Za-z_][\w]*)\.)?([\w]+)", text)
    if not m or m.group(2).isdigit() or m.group(4).isdigit():
        return None
    a, ac, b, bc = m.groups()
    if a is None and b is None:  # "column = column": the model writes the frm table's column, then the to table's
        a, b = frm_name, to_name
    elif b is None:  # "frm.column = column": the unqualified side is the other table's column
        b = to_name if X.TABLE_ALIAS.get(a, a) == frm_name else frm_name
    elif a is None:
        a = to_name if X.TABLE_ALIAS.get(b, b) == frm_name else frm_name
    def fix(n):
        n = X.TABLE_ALIAS.get(n, n)
        return n
    a, b = fix(a), fix(b)
    if {a, b} != {frm_name, to_name}:
        # the text may use the entity's short name for the shared table; map whichever side is not the frm
        if a == frm_name:
            b = to_name
        elif b == frm_name:
            a = to_name
        elif a == to_name:
            b = frm_name
        elif b == to_name:
            a = frm_name
        else:
            return None
    return f"{q(a)}.{q(ac)} = {q(b)}.{q(bc)}"


def try_sql(con, sql):
    try:
        con.exec(sql); return True
    except Exception:
        return False


def metric_sql(m):
    """SQL aggregate for a metric from the override, or from a plain model expression."""
    key = (m["model"], m["name"])
    if key in X.NOT_COMPILED:
        return None, X.NOT_COMPILED[key]
    if key in X.METRICS:
        return (RT.sql(X.METRICS[key]) if RT else X.METRICS[key]), ""
    e = (m.get("expr") or "").strip()
    if re.match(r"^(sum|avg|min|max)\(\w+\.\w+\)$", e):
        return e, ""
    mm = re.match(r"^count\(distinct (\w+\.\w+)\) where (.+)$", e)
    if mm:
        return f"count(distinct {mm.group(1)}) filter (where {mm.group(2)})", ""
    return None, "the model's expression is a sentence; add it to expressions.METRICS"


def tables_in(sql):
    """The semantic tables a metric names, in order of first mention (the first is the base table)."""
    out = []
    for t, _ in re.findall(r"\b([a-z_][a-z0-9_]*)\.([a-z_][a-z0-9_]*)", sql):
        if t not in out:
            out.append(t)
    return out


def proof_joins(compiled, base_key, other_keys):
    """Left joins from the base view to the other views a metric names, through the compiled joins (one hop each)."""
    out = []
    for k in other_keys:
        t = compiled["tables"][k]
        j = next((j for j in compiled["joins"] if j["executable"] and {j["frm_table"], j["to_table"]} == {base_key, k}), None)
        if not j:
            raise ValueError(f"no executable join between {compiled['tables'][base_key]['name']} and {t['name']}")
        out.append(f"left join {t['view']} as {q(t['name'])} on {j['sql']}")
    return " ".join(out)


def qualify(sql, cols_by_table):
    """Semantic `table.column` -> quoted alias references; leaves physical `dp_nnn.table` subqueries alone."""
    def rep(mt):
        t, c = mt.group(1), mt.group(2)
        if t in cols_by_table and c in cols_by_table[t]:
            return f"{q(t)}.{q(c)}"
        return mt.group(0)
    return re.sub(r"\b([a-z_][a-z0-9_]*)\.([a-z_][a-z0-9_]*)", rep, sql)


def build_metrics(con, slice_, compiled):
    for m in slice_["metrics"]:
        key = (m["model"], m["name"])
        rec = dict(model=m["model"], name=m["name"], aggregation=m.get("aggregation"), description=m.get("description", ""), source=m.get("source"),
                   time_rule=m.get("time_rule", ""), note=m.get("note", ""), text=m.get("expr") or f"{m.get('numerator', '')} / {m.get('denominator', '')}",
                   ref=m.get("ref"), in_scope=m["in_scope"], sql=None, tables=[], columns=[], executable=False, answerable=False, reason="", value_total=None,
                   steward_note=X.NOTES.get(key, ""))
        if m.get("ref"):
            tgt = m["ref"].split("/")[0]
            rec["reason"] = "reference to a model in the slice" if tgt in slice_["models"] else f"reference to {tgt}, a model outside the slice"
            rec["answerable"] = tgt in slice_["models"]
            compiled["metrics"].append(rec); continue
        if not m["in_scope"]:
            rec["reason"] = "reads tables left out of the slice"; compiled["metrics"].append(rec); continue
        sql, reason = metric_sql(m)
        if not sql:
            rec["reason"] = reason; compiled["metrics"].append(rec); continue
        tabs = [t for t in tables_in(sql) if f"{m['model']}.{t}" in compiled["tables"] or f"SM-00.{t}" in compiled["tables"]]
        tkeys = [f"{m['model']}.{t}" if f"{m['model']}.{t}" in compiled["tables"] else f"SM-00.{t}" for t in tabs]
        if not tkeys:
            rec["reason"] = "names no table of the slice"; compiled["metrics"].append(rec); continue
        base = compiled["tables"][tkeys[0]]
        cols_by_table = {compiled["tables"][k]["name"]: compiled["tables"][k]["columns"] for k in tkeys}
        qsql = qualify(sql, cols_by_table)
        cols = sorted({(t, c) for t, c in re.findall(r"\b([a-z_][a-z0-9_]*)\.([a-z_][a-z0-9_]*)", sql) if t in cols_by_table and c in cols_by_table[t]})
        rec.update(sql=sql, tables=tkeys, columns=[f"{t}.{c}" for t, c in cols])
        # prove it: run at the as-of date with the query-time filters at their defaults
        where = query_where(base, config.AS_OF, X.PARAMS)
        qsql = qsql.replace(":as_of_date", f"date '{config.AS_OF}'")
        try:
            probe = f"select {qsql} from {base['view']} as {q(base['name'])} {proof_joins(compiled, tkeys[0], tkeys[1:])}{where}"
            val = con.scalar(probe)
            rec["executable"] = True
            empty = [c for c in rec["columns"] if base["populated"].get(c.split(".")[1], 1) == 0 and c.split(".")[0] == base["name"]
                     and not c.endswith(("_effective_to", "_to", "_end", "_end_date", "_termination_date"))]
            if val is None or empty:
                rec["reason"] = ("no source populates " + ", ".join(empty)) if empty else "the probe returned null"
            else:
                rec["answerable"], rec["value_total"] = True, (float(val) if isinstance(val, (int, float)) else str(val))
        except Exception as ex:
            rec["reason"] = f"does not execute: {str(ex).splitlines()[0][:160]}"
        compiled["metrics"].append(rec)


def fiscal_code(d):
    """The fiscal month code of a date (the fiscal year is the calendar year)."""
    d = str(d)
    return f"FY{d[:4]}-M{d[5:7]}"


def query_where(table, as_of, params, extra=None):
    conds = []
    for f in table.get("query_filters", []):
        s = f
        for p, v in params.items():
            if v is None and p == "as_of_date":
                v = as_of
            s = s.replace(f":{p}", f"'{v}'" if not re.match(r"^\d{4}-\d{2}-\d{2}$", str(v)) else f"date '{v}'")
        conds.append(f"({s})")
    aoc = table.get("default_as_of_column")
    if aoc and as_of and "." not in aoc:  # an as-of column on another table is applied by the engine, not in the proof
        if table.get("fiscal_code_as_of"):
            conds.append(f"{q(table['name'])}.{q(aoc)} = '{fiscal_code(as_of)}'")
        else:
            conds.append(f"{q(table['name'])}.{q(aoc)} = date '{as_of}'")
    conds += extra or []
    return (" where " + " and ".join(conds)) if conds else ""


def main(rt=None, log=print):
    global RT
    RT = con = rt or runtime.get()
    slice_ = json.load(open(os.path.join(_paths.OUT, "slice.json")))
    compiled = dict(runtime=con.name, slice=slice_["slice"], as_of=config.AS_OF, models=slice_["models"], tables={}, joins=[], metrics=[],
                    questions=slice_["questions"], cannot_answer=slice_["cannot_answer"], params=X.PARAMS)
    build_views(con, slice_, compiled)
    build_joins(con, slice_, compiled)
    build_metrics(con, slice_, compiled)
    with open(os.path.join(con.out, "compiled_model.json"), "w") as f:
        json.dump(compiled, f, indent=1, default=str)
    views = [t for t in compiled["tables"].values() if t.get("view")]
    log(f"views: {len(views)} of {len(compiled['tables'])} tables; joins executable {sum(j['executable'] for j in compiled['joins'])} of {len(compiled['joins'])}")
    own = [m for m in compiled["metrics"] if not m["ref"] and m["in_scope"]]
    log(f"metrics in scope {len(own)}: executable {sum(m['executable'] for m in own)}, answerable {sum(m['answerable'] for m in own)}")
    for m in own:
        tag = "ANSWERABLE " if m["answerable"] else ("runs, null " if m["executable"] else "NOT COMPILED")
        val = f"{m['value_total']:,.2f}" if isinstance(m["value_total"], float) else ""
        log(f"  {tag} {m['model']} {m['name']:44s} {val:>20s}  {m['reason'][:90]}")
    for j in compiled["joins"]:
        if not j["executable"]:
            log(f"  join not executable: {j['model']} {j['frm']} -> {j['to']}: {j['reason']}")
    return compiled


if __name__ == "__main__":
    main()
    runtime.get().close()
