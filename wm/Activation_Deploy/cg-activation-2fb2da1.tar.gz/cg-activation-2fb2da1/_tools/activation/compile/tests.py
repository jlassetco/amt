"""Generates the data-quality test suite of the activation layer from the model's metadata (keys, critical data
elements, code lists, references) plus the hand-listed expectations of the planted gaps, and runs it on the built
DuckDB database (read-only). Writes activation/out/test_results.json and prints a table per product.

Ordinary failures are the demo's content; the run exits 1 only when an expectation (a planted gap) is not caught.

Usage (from _tools/):  activation/.venv/bin/python activation/compile/tests.py
"""
import json, os, re, sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import _paths  # noqa: E402,F401
sys.path.insert(0, HERE)
import config  # noqa: E402
import runtime  # noqa: E402
from runtime import snake  # noqa: E402

RT = None


def q(name):
    return RT.q(name)

# CDEs whose taxonomy flag is unconditional but whose value applies to some rows only (CW-275 follow-up: applies-to rules)
CONDITIONAL_CDE = {"Account Close Date": "closed accounts only", "Date of Death": "deceased persons only", "Legal Name": "organizations only",
                   "Given Name": "individuals only", "Family Name": "individuals only", "Date of Birth": "individuals only",
                   "Enrollment Termination Date": "terminated enrollments only", "Share Class": "fund flows only",
                   "Settlement Date": "settled transactions only", "Account Role Effective To": "ended roles only",
                   "Reg T Account Type": "brokerage accounts only (fund-only accounts have no Regulation T type; CW-275 follow-up)",
                   "Own Share Class": "own fund share classes only", "Fund Vehicle Type": "fund instruments only",
                   "Trusted Contact Person": "provided designations only", "Account Open Date": "opened accounts only (pending applications have none)",
                   "Employing Legal Entity": "HR's record (DP-192 is stood in for by the CRM user); not in the slice",
                   "Contingent Worker Type": "contingent workers only"}
SEVERITY = {"key_unique": "error", "key_incomplete": "error", "cde_complete": "error", "reference_integrity": "error",
            "code_membership": "warning", "expectation": "expectation"}
REF_TARGETS = {
    "Account": ("dp_093", "account", "account_id"), "Party": ("dp_240", "party", "party_id"),
    "Advisor's party": ("dp_240", "party", "party_id"), "Instrument": ("dp_097", "instrument", "instrument_id"),
    "Share Class": ("dp_004", "share_class", "share_class_id"), "Product": ("dp_004", "investment_product", "product_id"),
    "Service Offering": ("dp_004", "service_offering", "offering_id"),
    "Service Tier": ("dp_004", "service_tier", "service_tier_code"), "Employee": ("dp_009", "employee", "employee_id"),
    "Advisor": ("dp_009", "employee", "employee_id"), "Measure": ("dp_008", "measure_definition", "measure_id"),
    "Snapshot": ("dp_008", "snapshot", "snapshot_id"),
    "Reporting Period": ("dp_008", "reporting_period", "reporting_period_id"),
    "Transaction": ("dp_006", "transaction", "transaction_id"), "Match Rule": ("dp_495", "match_rule", "match_rule_id"),
    "Client Account Activity": ("dp_300", "client_account_activity", "client_account_activity_id"),
    "Register Transaction": ("dp_580", "register_transaction", "register_transaction_id"),
}
REF_SKIP = {"Share Register Balance", "Client Holding"}
UNTESTABLE_LIST = re.compile(r"^(ISO |Firm-defined|External \()")
EXPECTATIONS = [  # (product, entity, column, condition SQL, sample column or None, description)
    ("DP-007", "Account Asset Summary", "Summary Holding Type", "{c} = 'UNATTRIBUTED'", None,
     "option positions carry holding type UNATTRIBUTED (no taxonomy equivalent)"),
    ("DP-580", "Register Transaction", "Register Transaction Type", "{c} is null", "Register Transaction ID",
     "fund register cash dividend code 111 maps to no register transaction type"),
    ("DP-240", "Party Identifier", "Identifier Scheme", "{c} not in ({labels})", None,
     "brokerage customer number uses a proposed identifier scheme outside the 02 Identifier Scheme list"),
]


def load_json(name):
    with open(os.path.join(_paths.OUT, name)) as f:
        return json.load(f)


def lookup_list(lists, domain, name):
    """The labels of a code list, or None when the list has no testable values."""
    if not name or UNTESTABLE_LIST.match(name):
        return None
    base = name[len("Shared: "):] if name.startswith("Shared: ") else name
    rows = lists.get((domain, base)) or lists.get((domain, "Shared: " + base))
    return [r[0] for r in rows] if rows else None


def ref_concept(atype):
    """'Reference (Fund Order, 29) (multi)' -> 'Fund Order'."""
    inner = re.sub(r"\s*\(multi\)\s*$", "", atype)[len("Reference ("):].rstrip(")")
    return re.sub(r",\s*\d+$", "", inner).strip()


def scalar(con, sql, params=None):
    return con.scalar(con.sql(sql), params)


def samples(con, sql, params=None):
    return [str(r[0]) for r in con.fetch(con.sql(sql + " limit 5"), params)]


def literal_list(values):
    return "(" + ", ".join("'" + str(v).replace("'", "''") + "'" for v in values) + ")"


def record(ent, table, kind, column, rows, failures, smp=None, note=""):
    return dict(product=ent["product"], entity=ent["entity"], table=table, kind=kind, column=column,
                rows_checked=rows, failures=failures, samples=smp or [], severity=SEVERITY.get(kind, "info"), note=note)


def values_expr(table, c, multi):
    """A subquery of the column's non-null values, one per row (or per element of a '; '-separated list)."""
    if multi:
        return RT.unnest_values(table, c)
    return f"(select cast({q(c)} as string) as v from {table} where {q(c)} is not null)"


def test_keys(con, ent, table, n, populated, derived):
    """key_unique over the pk columns (rows with a null pk column excluded) and key_incomplete for those rows."""
    pk = [snake(p) for p in ent["pk"]]
    cols = [c for c in pk if c in populated or derived]
    skipped = [c for c in pk if c not in cols]
    note = f"unfed key columns not checked: {', '.join(skipped)}" if skipped else ""
    if not cols:
        return [record(ent, table, "not_testable", ",".join(pk), n, 0, note="no key column is fed")]
    keys = ", ".join(q(c) for c in cols)
    notnull = " and ".join(f"{q(c)} is not null" for c in cols)
    dup_sql = f"select {keys}, count(*) k from {table} where {notnull} group by {keys} having count(*) > 1"
    dups = scalar(con, f"select coalesce(sum(k), 0) from ({dup_sql})")
    smp = [" | ".join(str(x) for x in r[:-1]) for r in con.fetch(con.sql(dup_sql + " limit 5"))]
    nulls = scalar(con, f"select count(*) from {table} where not ({notnull})")
    nsmp = [c for c in cols if scalar(con, f"select count(*) from {table} where {q(c)} is null")]
    return [record(ent, table, "key_unique", ",".join(cols), n, int(dups), smp, note),
            record(ent, table, "key_incomplete", ",".join(cols), n, nulls, nsmp, "samples = key columns with nulls")]


def test_attr(con, ent, a, table, n, cols, populated, derived, lists, gaps):
    """cde_complete, code_membership and reference_integrity for one attribute."""
    out, c = [], snake(a["name"])
    if c not in cols or (c not in populated and not derived):
        return out
    if a["cde"] and (a["name"] in ent["used"] or a["pk"]):
        nulls = scalar(con, f"select count(*) from {table} where {q(c)} is null")
        cond = CONDITIONAL_CDE.get(a["name"])
        rec = record(ent, table, "cde_complete", c, n, nulls, note=gaps.get(ent["product"] + "/" + ent["entity"], ""))
        if cond:        # a CDE that applies to some rows only: the taxonomy's flag is unconditional, so report it as a warning
            rec["severity"], rec["note"] = "warning", f"conditional CDE: {cond}"
        out.append(rec)
    if c not in populated:
        return out
    multi = "(multi)" in a["type"]
    labels = lookup_list(lists, (a["taxonomy"] or [""])[0], a["code_list"])
    if labels:
        vals = values_expr(table, c, multi)
        cond = f"v not in {literal_list(labels)}"
        bad = scalar(con, f"select count(*) from {vals} where {cond}")
        smp = samples(con, f"select distinct v from {vals} where {cond} order by v")
        out.append(record(ent, table, "code_membership", c, n, bad, smp, f"list {a['code_list']}"))
    if a["type"].startswith("Reference ("):
        concept = ref_concept(a["type"])
        if concept in REF_SKIP:
            return out
        if concept not in REF_TARGETS:
            out.append(record(ent, table, "not_testable", c, n, 0, note=f"referenced concept '{concept}' has no table in the slice"))
            return out
        s, t, k = REF_TARGETS[concept]
        target = con.sql(f"{s}.{t}")
        vals = values_expr(table, c, multi)
        prefixes = [r[0] for r in con.fetch(f"select distinct regexp_extract({q(k)}, '^([A-Z]+-)', 1) from {target}") if r[0]]
        if prefixes:
            hits = scalar(con, f"select count(*) from {vals} where " + " or ".join(f"v like '{p}%'" for p in prefixes))
            if hits == 0:
                out.append(record(ent, table, "not_testable", c, n, 0,
                                  note=f"values are not of the form {s}.{t}.{k} mints ({', '.join(prefixes)})"))
                return out
        cond = f"v not in (select cast({q(k)} as string) from {target} where {q(k)} is not null)"
        bad = scalar(con, f"select count(*) from {vals} where {cond}")
        smp = samples(con, f"select distinct v from {vals} where {cond} order by v")
        out.append(record(ent, table, "reference_integrity", c, n, bad, smp, f"-> {s}.{t}.{k}"))
    return out


def test_expectations(con, lists):
    """The planted gaps: each passes when the layer finds at least one row with the condition."""
    out, scheme = [], lookup_list(lists, "02", "Identifier Scheme") or []
    for pid, ename, col, cond, scol, desc in EXPECTATIONS:
        table, c = con.entity(pid, ename), snake(col)
        labels = ", ".join("'" + v.replace("'", "''") + "'" for v in scheme)
        where = cond.format(c=q(c), labels=labels)
        n = scalar(con, f"select count(*) from {table}")
        hit = scalar(con, f"select count(*) from {table} where {where}")
        sc = q(snake(scol or col))
        smp = samples(con, f"select distinct cast({sc} as string) from {table} where {where} order by 1")
        rec = record(dict(product=pid, entity=ename), table, "expectation", c, n, hit, smp, desc)
        rec["met"] = hit > 0
        if scol:
            rec["note"] += f" (samples are {snake(scol)})"
        out.append(rec)
    return out


def summarize(tests):
    """Per product: tests, failing tests, failing error tests and failing warning tests (expectations excluded)."""
    summ = defaultdict(lambda: dict(tests=0, failures=0, errors=0, warnings=0))
    for t in tests:
        if t["kind"] in ("expectation", "not_testable"):
            continue
        s = summ[t["product"]]
        s["tests"] += 1
        if t["failures"]:
            s["failures"] += 1
            s["errors" if t["severity"] == "error" else "warnings"] += 1
    return dict(sorted(summ.items()))


def report(tests, summ):
    """Prints the failing tests per product, the totals and the expectations."""
    for pid, s in summ.items():
        print(f"\n{pid}  tests {s['tests']}  failing {s['failures']} (errors {s['errors']}, warnings {s['warnings']})")
        for t in tests:
            if t["product"] == pid and t["failures"] and t["kind"] not in ("expectation", "not_testable"):
                smp = ", ".join(t["samples"][:3])
                print(f"  {t['kind']:<20} {t['table'] + '.' + t['column']:<62} {t['failures']:>6}  {smp[:60]}")
    tot = {k: sum(s[k] for s in summ.values()) for k in ("tests", "failures", "errors", "warnings")}
    nt = sum(1 for t in tests if t["kind"] == "not_testable")
    print(f"\nTotal: {tot['tests']} tests, {tot['failures']} failing ({tot['errors']} errors, {tot['warnings']} warnings); "
          f"{nt} not testable")
    print("\nExpectations (the layer caught the planted gap):")
    for t in tests:
        if t["kind"] == "expectation":
            print(f"  {'MET    ' if t['met'] else 'NOT MET'} {t['table']}.{t['column']}: {t['failures']} rows "
                  f"[{', '.join(t['samples'])}] - {t['note']}")


def main(rt=None, log=print):
    global RT
    from slice import code_lists
    RT = con = rt or runtime.get()
    sl = load_json("slice.json")
    phys = json.load(open(os.path.join(con.out, "physical_report.json")))
    gaps = {g["entity"]: g["note"] for g in json.load(open(os.path.join(con.out, "derivation_report.json")))["gaps"]}
    lists = code_lists()
    tests = []
    for key, ent in sl["entities"].items():
        table = con.entity(ent["product"], ent["entity"])
        n = scalar(con, f"select count(*) from {table}") if con.table_exists(table) else 0
        if not n:
            continue
        derived = ent["product"] in config.DERIVED_PRODUCTS
        cols = con.columns(table)
        fed = phys["entities"].get(key, {}).get("columns", {})
        populated = {c for c in cols if fed.get(c, {}).get("non_null")
                     or scalar(con, f"select count({q(c)}) from {table}")}
        tests += test_keys(con, ent, table, n, populated, derived)
        for a in ent["attrs"]:
            tests += test_attr(con, ent, a, table, n, cols, populated, derived, lists, gaps)
    tests += test_expectations(con, lists)
    summ = summarize(tests)
    met = all(t["met"] for t in tests if t["kind"] == "expectation")
    with open(os.path.join(con.out, "test_results.json"), "w") as f:
        json.dump(dict(runtime=con.name, tests=tests, summary=summ, expectations_met=met), f, indent=1)
    import io, contextlib
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        report(tests, summ)
    for line in buf.getvalue().splitlines():
        log(line)
    return dict(tests=tests, summary=summ, expectations_met=met)


if __name__ == "__main__":
    r = main()
    runtime.get().close()
    sys.exit(0 if r["expectations_met"] else 1)
