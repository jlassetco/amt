"""Executable SQL for the mapping rows whose `derived` text is a sentence rather than an expression, and the row shapes
(unpivots and filters) for source tables that feed an entity at a different grain. Keyed by the mapping row's
(source id, source table, target) or (source id, source table, entity key). physical.py applies them; a derived row
with neither executable text nor an entry here is reported as unbuilt.
"""
import importlib, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "mapping"))

PROPOSED_SCHEME = "Brokerage Platform Customer Number (proposed)"

# identifier scheme labels stored in the identifier entities: the taxonomy value, or the proposed label for a gap
SCHEME_LABEL = {}
for _f in sorted(os.listdir(os.path.join(os.path.dirname(HERE), "mapping"))):
    if _f.startswith("map_") and _f.endswith(".py"):
        _m = importlib.import_module(_f[:-3])
        for _k, _s in _m.SOURCE.get("identifier_schemes", {}).items():
            SCHEME_LABEL[(_m.SOURCE["id"], _k)] = _s[2] if _s[2] is not None else PROPOSED_SCHEME

BL = {"DB": "Direct brokerage and self-directed investing", "DA": "Digital advice", "HA": "Human and hybrid advice",
      "PF": "Proprietary funds and ETFs", "WR": "Workplace retirement recordkeeping", "IA": "Institutional advisory",
      "IC": "Intermediary channel", "PT": "Personal trust services", "TR": "Personal trust services"}
CH = {"Phone": "Phone", "Video": "Video Conference", "InPerson": "In Person", "Chat": "Chat / Messaging"}


def _multi(col, mapping):
    cases = " ".join(f"when '{k}' then '{v}'" for k, v in mapping.items())
    return f"array_to_string(list_transform(string_split({col}, ';'), x -> case x {cases} else x end), '; ')"


# the party a brokerage customer resolves to: the CRM contact it carries, else the contact that carries it, else its own party
BRK_PARTY = "coalesce('PTY-' || CRM_CONTACT_ID, 'PTY-' || CONTACT_BY_NUMBER, 'PTY-BRK-' || CUST_NO)"
# the customer table joined to the CRM contact that carries its number (one row per customer)
CUST_JOINED = ("(select c.*, x.CONTACT_BY_NUMBER from src_brk.CUST_MASTER c left join "
               "(select \"Brokerage_Customer_No__c\" as BCN, min(\"Id\") as CONTACT_BY_NUMBER from src_crm.\"Contact\" where \"Brokerage_Customer_No__c\" is not null group by \"Brokerage_Customer_No__c\") x "
               "on x.BCN = c.CUST_NO)")
FA_JOINED = ("(select r.*, f.Source_System__c as FA_SOURCE, f.FinServ__FinancialAccountNumber__c as FA_NUMBER, f.FinServ__PrimaryOwner__c as FA_PRIMARY_OWNER "
             "from src_crm.FinServ__FinancialAccountRole__c r left join src_crm.FinServ__FinancialAccount__c f on f.\"Id\" = r.FinServ__FinancialAccount__c) FinServ__FinancialAccountRole__c")
FA_ACCOUNT = "'ACC-' || Source_System__c || '-' || FinServ__FinancialAccountNumber__c"
TA_CATEGORY = ("(case SA_ACCT_TYPE_CD when 'I' then 'Fund-Only' when 'N' then 'Networked' when 'P' then 'Plan Omnibus' when 'D' then 'Institutional Direct' "
               "when 'O' then (case when SA_DEALER_TYPE_CD = 'AFF' then 'Broker-Dealer Omnibus' else 'Intermediary Omnibus' end) end)")
TA_POSITION_JOINED = ("(select p.*, a.ACCT_TYPE_CD as SA_ACCT_TYPE_CD, d.DEALER_TYPE_CD as SA_DEALER_TYPE_CD from src_ta.POSITION p "
                      "left join src_ta.SHR_ACCT a on a.ACCT_NO = p.ACCT_NO left join src_ta.DEALER d on d.DEALER_NO = a.DEALER_NO) POSITION")
# the register's accounts with the legal nature of the institutional client that owns a direct institutional account (D)
TA_SHR_JOINED = ("(select a.*, c.ENTITY_KIND_CD as INST_ENTITY_KIND_CD from src_ta.SHR_ACCT a "
                 "left join src_inst.FUND_ACCOUNT fa on fa.TA_ACCT_NO = a.ACCT_NO left join src_inst.CLIENT c on c.CLIENT_ID = fa.CLIENT_ID) SHR_ACCT")
# an institution's registration type from its legal nature (a government body has none: a declared gap)
INST_REGISTRATION = "case INST_ENTITY_KIND_CD when 'PLAN' then 'Retirement Plan Trust' when 'NPO' then 'Nonprofit' when 'CORP' then 'Corporate' end"
# SRC-BIL approvals name a CRM user; the employee key is minted from the user's employee number, as map_crm.py keys advisors
def _with_approver(table):
    return (f"(select b.*, u.Employee_Number__c as APPROVER_EMPLOYEE_NUMBER from src_bil.{table} b "
            f"left join src_crm.\"User\" u on u.\"Id\" = b.APPROVED_BY) {table}")


# SRC-CST pool expense categories: a '; '-separated code list, each element through map_cst's CATEGORIES crosswalk
_CST_CATEGORIES = {sv: tv for sv, tv, _ in importlib.import_module("map_cst").CROSSWALKS["CATEGORIES"]["values"] if tv}
CST_CATEGORIES = ("array_to_string(list_transform(string_split(CATEGORIES, '; '), x -> case x "
                  + " ".join(f"when '{k}' then '{v}'" for k, v in _CST_CATEGORIES.items()) + " else x end), '; ')")

DERIVED = {
    # SRC-BRK
    ("SRC-BRK", "ACCT_MASTER", ("15", "Account Party Role", "Account Role Type")): "ROLE_TYPE",
    ("SRC-BRK", "CUST_MASTER", ("02", "Party", "Party ID")): BRK_PARTY,
    ("SRC-BRK", "CUST_MASTER", ("02", "Party Identifier", "Identified Party")): BRK_PARTY,
    ("SRC-BRK", "CUST_MASTER", ("02", "Party Identifier", "Identifier Status")): "case when CUST_STATUS_CD = 'M' then 'Retired' else 'Active' end",
    ("SRC-BRK", "CUST_MASTER", ("02", "Party Identifier", "Identifier Scheme")): "ID_SCHEME",
    ("SRC-BRK", "SEC_MASTER", ("17", "Instrument", "Instrument Type")):
        "case when FUND_FAMILY_CD = 'OWN' then 'Own Fund Share Class' when SEC_TYPE_CD = 'EQ' then 'Equity Share' "
        "when SEC_TYPE_CD in ('ETF', 'MF', 'MMF') then 'Third-Party Fund' when SEC_TYPE_CD = 'FI' then 'Corporate Bond' "
        "when SEC_TYPE_CD = 'CD' then 'Certificate of Deposit' when SEC_TYPE_CD = 'OPT' then 'Listed Option' when SEC_TYPE_CD = 'UIT' then 'Other' end",
    ("SRC-BRK", "SEC_MASTER", ("17", "Fund Instrument Terms", "Fund Vehicle Type")):
        "case when SEC_TYPE_CD = 'ETF' then 'Exchange-Traded Fund' when SEC_TYPE_CD in ('MF', 'MMF') then 'Open-Ended Fund' end",
    ("SRC-BRK", "SEC_MASTER", ("17", "Fund Instrument Terms", "Own Investment Product")): "'PRD-' || TA_PRODUCT_CD",
    ("SRC-BRK", "POSITIONS", ("49", "Client Holding", "Own Share Class Indicator")): "coalesce(SEC_FUND_FAMILY_CD = 'OWN', false)",
    ("SRC-BRK", "CASH_BAL", ("49", "Account Cash Balance", "Balance Sweep Program")): "case when BAL_TYPE_CD = 'SWP' then 'SWP-' || SWEEP_PGM_CD end",
    # SRC-CRM
    ("SRC-CRM", "Account", ("02", "Segment Assignment", "Segment Effective From")): "try_cast(CreatedDate as date)",
    ("SRC-CRM", "Account", ("03", "Party Coverage Assignment", "Covering Advisor")): "'EMP-' || OWNER_EMPLOYEE_NUMBER",
    ("SRC-CRM", "Contact", ("02", "Household Membership", "Membership Status")): "case when Household_End__c is null then 'Active' else 'Inactive' end",
    ("SRC-CRM", "Contact", ("02", "Party Identifier", "Identifier Scheme")): "ID_SCHEME",
    ("SRC-CRM", "FinServ__FinancialAccount__c", ("15", "Account Identifier", "Identified Account")): FA_ACCOUNT,
    ("SRC-CRM", "FinServ__FinancialAccount__c", ("15", "Account", "Account ID")): FA_ACCOUNT,
    ("SRC-CRM", "FinServ__FinancialAccountRole__c", ("15", "Account Party Role", "Role Account")): "'ACC-' || FA_SOURCE || '-' || FA_NUMBER",
    ("SRC-CRM", "FinServ__FinancialAccountRole__c", ("02", "Authority Grant", "Grantor Party")): "'PTY-' || FA_PRIMARY_OWNER",
    ("SRC-CRM", "FinServ__FinancialAccountRole__c", ("02", "Authority Grant", "Accounts Covered")): "'ACC-' || FA_SOURCE || '-' || FA_NUMBER",
    ("SRC-CRM", "User", ("20", "Employee", "Employment Status")): "case when lower(IsActive) = 'true' then 'Active' else 'Terminated' end",
    ("SRC-CRM", "User", ("03", "Advisor", "Employee")): "'EMP-' || Employee_Number__c",
    ("SRC-CRM", "User", ("03", "Advisor", "Advisor Business Lines")): _multi("Business_Lines__c", BL),
    ("SRC-CRM", "User", ("03", "Advisor", "Advice Channels Offered")): _multi("Channels_Offered__c", CH),
    # SRC-TA
    ("SRC-TA", "FUND_MASTER", ("01", "Investment Product", "Product Inception Date")): "PRODUCT_INCEPT_DT",
    ("SRC-TA", "SHR_ACCT", ("15", "Account", "Account Registration Type")):
        "case when SOC_CD = '7' then (case IRA_TYPE_CD when 'T' then 'Traditional IRA' when 'R' then 'Roth IRA' when 'S' then 'SEP IRA' when 'I' then 'Inherited IRA' else 'Traditional IRA' end) "
        "when SOC_CD = '1' then 'Individual' when SOC_CD = '2' then 'Joint Tenants (JTWROS)' when SOC_CD = '3' then 'UTMA / UGMA' "
        "when SOC_CD = '5' then 'Revocable Trust' when SOC_CD = '8' then (" + INST_REGISTRATION + ") when SOC_CD = '9' then 'Corporate' end",
    ("SRC-TA", "SHR_ACCT", ("15", "Account", "Account Business Line")):
        "case when ACCT_TYPE_CD = 'I' then 'Proprietary funds and ETFs' when ACCT_TYPE_CD = 'D' then 'Proprietary funds and ETFs' else 'Intermediary channel' end",
    ("SRC-TA", "POSITION", ("29", "Share Register Balance", "Register Account Category")): TA_CATEGORY,
    ("SRC-TA", "POSITION", ("29", "Share Register Balance", "Registered Shares")): "try_cast(SHARES as double) + coalesce(try_cast(SHARES_UNCOLL as double), 0)",
    ("SRC-TA", "TRANSACTION", ("29", "Register Transaction", "Share Movement Direction")):
        "case when TRAN_CD in ('001', '051', '071', '101', '102', '201') then 'Inflow' when TRAN_CD in ('002', '052', '072', '202') then 'Outflow' when TRAN_CD = '111' then 'Neutral' end",
    ("SRC-TA", "DEALER", ("02", "Party Identifier", "Identifier Scheme")): "ID_SCHEME",
    # SRC-INST
    ("SRC-INST", "CLIENT", ("02", "Party Identifier", "Identifier Scheme")): "ID_SCHEME",
    ("SRC-INST", "CLIENT", ("05", "Consultant Advisory Relationship", "Consultant Firm")): "'PTY-CONS-' || CONSULTANT_ID",
    ("SRC-INST", "RELATIONSHIP", ("12", "Service Relationship", "Serviced Mandates")): "SERVICED_MANDATES",
    ("SRC-INST", "RELATIONSHIP", ("12", "Service Relationship", "Advising Consultant")): "'PTY-CONS-' || CONSULTANT_ID",
    ("SRC-INST", "HEALTH_SCORE", ("12", "Relationship Health Score", "Survey Inputs")): "'SVR-' || SURVEY_ID",
    ("SRC-INST", "FUND_ACCOUNT", ("15", "Account Party Role", "Account Role Effective From")): "cast(try_strptime(TA_ESTAB_DT, '%Y%m%d') as date)",
    # SRC-PAB
    ("SRC-PAB", "PORTFOLIO", ("15", "Account", "Account Registration Type")): INST_REGISTRATION,
    ("SRC-PAB", "PORTFOLIO", ("15", "Account Registration Detail", "Registration Line 1")): "INST_LEGAL_NAME",
    # SRC-BIL
    ("SRC-BIL", "FEE_RUN", ("47", "Fee Calculation Run", "Run Approved By")): "'EMP-' || APPROVER_EMPLOYEE_NUMBER",
    ("SRC-BIL", "WAIVER", ("47", "Fee Waiver", "Waiver Approved By")): "'EMP-' || APPROVER_EMPLOYEE_NUMBER",
    # SRC-CST
    ("SRC-CST", "POOL", ("10", "Cost Pool", "Included Expense Categories")): CST_CATEGORIES,
}

# Row shapes: a FROM clause (and filter) that presents the source table at the entity's grain. Column overrides name
# the unpivoted columns. The shape's columns must carry the names the mapping rows and DERIVED entries use.
SHAPES = {
    ("SRC-BRK", "ACCT_MASTER", "DP-093/Account Party Role"): dict(
        from_sql="(select a.*, a.PRIM_CUST_NO as ROLE_CUST_NO, 'Primary Owner' as ROLE_TYPE from src_brk.ACCT_MASTER a "
                 "union all select a.*, a.SEC_CUST_NO, 'Joint Owner' from src_brk.ACCT_MASTER a where a.SEC_CUST_NO is not null) ACCT_MASTER",
        override={"role_party": "ROLE_CUST_NO"}),
    ("SRC-BRK", "ACCT_MASTER", "DP-093/Program Enrollment"): dict(where="PROGRAM_CD is not null"),
    ("SRC-BRK", "CUST_MASTER", "DP-240/Party"): dict(from_sql=CUST_JOINED + " CUST_MASTER"),
    ("SRC-BRK", "CUST_MASTER", "DP-240/Party Identifier"): dict(
        from_sql="(select j.*, j.CUST_NO as ID_VALUE, '" + PROPOSED_SCHEME + "' as ID_SCHEME from " + CUST_JOINED + " j "
                 "union all select j.*, j.CRM_CONTACT_ID, 'CRM ID' from " + CUST_JOINED + " j where j.CRM_CONTACT_ID is not null) CUST_MASTER",
        override={"identifier_value": "ID_VALUE"}),
    ("SRC-BRK", "SEC_MASTER", "DP-097/Instrument"): dict(
        from_sql="(select s.*, f.PRODUCT_CD as TA_PRODUCT_CD from src_brk.SEC_MASTER s left join src_ta.FUND_MASTER f on f.FUND_NO = s.TA_FUND_NO) SEC_MASTER"),
    ("SRC-BRK", "POSITIONS", "DP-300/Client Holding"): dict(
        from_sql="(select p.*, s.FUND_FAMILY_CD as SEC_FUND_FAMILY_CD from src_brk.POSITIONS p left join src_brk.SEC_MASTER s on s.CUSIP = p.CUSIP) POSITIONS"),
    ("SRC-TA", "POSITION", "DP-580/Register Position"): dict(from_sql=TA_POSITION_JOINED),
    # one product per PRODUCT_CD: the representative class is the investor class, then admiral, then institutional
    # (an ETF class is a share class of the same open-end fund); the product's inception is the earliest class launch
    ("SRC-TA", "FUND_MASTER", "DP-004/Investment Product"): dict(
        from_sql="(select * from (select f.*, min(cast(try_strptime(f.INCEPT_DT, '%Y%m%d') as date)) over (partition by f.PRODUCT_CD) as PRODUCT_INCEPT_DT, "
                 "row_number() over (partition by f.PRODUCT_CD order by case f.CLASS_CD when 'INV' then 0 when 'ADM' then 1 when 'INST' then 2 else 3 end, f.FUND_NO) as rn "
                 "from src_ta.FUND_MASTER f) x where rn = 1) FUND_MASTER"),
    ("SRC-CRM", "Contact", "DP-240/Party Identifier"): dict(
        from_sql="(select c.*, c.\"Id\" as ID_VALUE, 'CRM ID' as ID_SCHEME from src_crm.\"Contact\" c "
                 "union all select c.*, c.Brokerage_Customer_No__c, '" + PROPOSED_SCHEME + "' from src_crm.\"Contact\" c where c.Brokerage_Customer_No__c is not null) Contact",
        override={"identifier_value": "ID_VALUE"}),
    ("SRC-CRM", "Contact", "DP-240/Household Membership"): dict(where="AccountId is not null"),
    ("SRC-CRM", "Account", "DP-009/Coverage Assignment"): dict(
        from_sql="(select a.*, u.Employee_Number__c as OWNER_EMPLOYEE_NUMBER from src_crm.\"Account\" a left join src_crm.\"User\" u on u.\"Id\" = a.OwnerId) \"Account\"",
        where="OwnerId is not null"),
    ("SRC-CRM", "FinServ__FinancialAccount__c", "DP-093/Account Identifier"): dict(
        from_sql="(select f.*, f.FinServ__FinancialAccountNumber__c as ID_VALUE, case f.Source_System__c when 'BRK' then 'Brokerage Account Number' when 'TA' then 'Transfer Agent Account Number' end as ID_SCHEME, "
                 "'ACI-CRM-' || f.\"Id\" || '-N' as ID_ID from src_crm.FinServ__FinancialAccount__c f where f.FinServ__FinancialAccountNumber__c is not null "
                 "union all select f.*, f.\"Id\", 'CRM Financial Account ID', 'ACI-CRM-' || f.\"Id\" || '-C' from src_crm.FinServ__FinancialAccount__c f where f.FinServ__FinancialAccountNumber__c is not null) FinServ__FinancialAccount__c",
        override={"account_identifier_value": "ID_VALUE", "account_identifier_scheme": "ID_SCHEME", "account_identifier_id": "ID_ID"}),
    ("SRC-CRM", "FinServ__FinancialAccount__c", "DP-093/Account"): dict(where="FinServ__FinancialAccountNumber__c is not null"),
    ("SRC-CRM", "FinServ__FinancialAccountRole__c", "DP-093/Account Party Role"): dict(from_sql=FA_JOINED, where="FinServ__Role__c not in ('Beneficiary', 'Power of Attorney')"),
    ("SRC-CRM", "FinServ__FinancialAccountRole__c", "DP-240/Authority Grant"): dict(from_sql=FA_JOINED, where="FinServ__Role__c = 'Power of Attorney'"),
    ("SRC-CRM", "User", "DP-009/Employee"): dict(where="\"UserRole.Name\" = 'Advisor'"),
    # DP-580's Shareholder Account is the register's accounts only (DP-093 Account Master holds every account)
    ("SRC-BRK", "ACCT_MASTER", "DP-580/Shareholder Account"): dict(skip=True),
    ("SRC-CRM", "FinServ__FinancialAccount__c", "DP-580/Shareholder Account"): dict(where="Source_System__c = 'TA'"),
    ("SRC-TA", "DEALER", "DP-240/Party Identifier"): dict(
        from_sql="(select d.*, d.DEALER_NO as ID_VALUE, 'TA Dealer Number' as ID_SCHEME from src_ta.DEALER d "
                 "union all select d.*, d.NSCC_NO, 'NSCC Participant Number' from src_ta.DEALER d where d.NSCC_NO is not null) DEALER",
        override={"identifier_value": "ID_VALUE"}),
    # SRC-TA direct institutional accounts take their registration from the owning client (both entities that hold 15 Account)
    ("SRC-TA", "SHR_ACCT", "DP-093/Account"): dict(from_sql=TA_SHR_JOINED),
    ("SRC-TA", "SHR_ACCT", "DP-580/Shareholder Account"): dict(from_sql=TA_SHR_JOINED),
    # SRC-INST
    ("SRC-INST", "CLIENT", "DP-240/Party Identifier"): dict(
        from_sql="(select c.*, c.CLIENT_ID as ID_VALUE, 'CRM ID' as ID_SCHEME from src_inst.CLIENT c "
                 "union all select c.*, c.EIN, 'EIN' from src_inst.CLIENT c where c.EIN is not null) CLIENT",
        override={"identifier_value": "ID_VALUE"}),
    ("SRC-INST", "RELATIONSHIP", "DP-510/Service Relationship"): dict(
        from_sql="(select r.*, m.SERVICED_MANDATES from src_inst.RELATIONSHIP r left join "
                 "(select REL_ID as M_REL_ID, __LISTAGG__(MANDATE_ID) as SERVICED_MANDATES from src_inst.MANDATE group by REL_ID) m "
                 "on m.M_REL_ID = r.REL_ID) RELATIONSHIP"),
    ("SRC-INST", "FUND_ACCOUNT", "DP-093/Account Party Role"): dict(
        from_sql="(select f.*, a.ESTAB_DT as TA_ESTAB_DT from src_inst.FUND_ACCOUNT f left join src_ta.SHR_ACCT a on a.ACCT_NO = f.TA_ACCT_NO) FUND_ACCOUNT"),
    # SRC-PAB: the separate account takes its registration from the client; DP-580 holds register accounts only
    ("SRC-PAB", "PORTFOLIO", "DP-093/Account"): dict(
        from_sql="(select p.*, c.ENTITY_KIND_CD as INST_ENTITY_KIND_CD, c.LEGAL_NAME as INST_LEGAL_NAME from src_pab.PORTFOLIO p "
                 "left join src_inst.CLIENT c on c.CLIENT_ID = p.CLIENT_ID) PORTFOLIO"),
    ("SRC-PAB", "PORTFOLIO", "DP-580/Shareholder Account"): dict(skip=True),
    # SRC-BIL: approvers resolve through the CRM user to the employee key
    ("SRC-BIL", "FEE_RUN", "DP-305/Fee Run"): dict(from_sql=_with_approver("FEE_RUN")),
    ("SRC-BIL", "WAIVER", "DP-305/Fee Waiver"): dict(from_sql=_with_approver("WAIVER")),
    # SRC-CST: the run key of a result is a product key with no taxonomy attribute (the run is the result's parent)
    ("SRC-CST", "RESULT", "DP-480/Allocation Result"): dict(override={"allocation_run_key": "RUN_ID"}),
}


def prepare(rt):
    """Nothing to prepare yet; kept for symmetry with after_mapping."""


def after_mapping(rt):
    """Steps that need every mapped entity in place: none yet (reference resolution is physical.py's)."""
