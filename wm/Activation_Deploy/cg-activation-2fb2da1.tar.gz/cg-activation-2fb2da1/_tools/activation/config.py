"""Configuration of the source-to-semantic activation demo.

SLICE names the semantic models the demo activates. Everything else (the synthetic sources, the mapping scaffold, the
compiled tables, the coverage report and the demo page) is derived from the tables those models read. TABLES narrows a
model to some of its tables; None keeps every table of the model.
"""

SLICE = ["SM-20", "SM-21", "SM-27", "SM-28"]

TABLES = {
    # SM-20: the eight tables read from the foundational products (DP-008, DP-006, DP-007), plus the three DP-495
    # supply-chain tables that the mapping registry itself populates. The other DP-49x consumer tables stay out.
    "SM-20": ["client_assets_flows", "snapshot", "reporting_period", "measure_definition",
              "flow_transactions", "flow_linked_transactions", "account_asset_summary", "intermediary_positions",
              "identifier_crosswalk", "match_rule", "match_result"],
    # SM-21: the household tables. Trust (DP-307), fiduciary reviews (DP-351) and personal rate of return (DP-145) stay out.
    "SM-21": ["household_360", "household_client_assets", "fund_position_view",
              "household", "client", "household_membership", "account_owner"],
    # SM-27: the institutional relationship tables that answer "how much of our assets with public pension plans sits
    # with clients whose relationship is at risk": health scores, service relationships, the institutional client and
    # its mandates, and the client assets attributed to each relationship.
    "SM-27": ["health_score", "service_relationship", "institutional_client", "investment_mandate",
              "relationship_attribution", "relationship_asset_summary", "relationship_health"],
    # SM-28: the client economics chain a direct wealth manager runs: fee schedules, assignments, runs, calculations,
    # waivers and debits from the billing engine (DP-305), the billing re-performance test (DP-346), client and own-fund
    # fee revenue from the revenue sub-ledger (DP-012), cost pools, rules, runs and results from the allocation engine
    # (DP-480), and the cost-to-serve and profitability facts derived from them (DP-498, DP-499). Institutional billing
    # arrangements, invoices, disputes, intercompany charges, lifetime value and pricing scenarios stay out.
    "SM-28": ["client_revenue", "fee_revenue",
              "fee_schedule", "fee_schedule_assignment", "fee_household", "fee_household_membership", "fee_run",
              "account_fee_calculation", "fee_waiver", "fee_debit", "fee_billing_test",
              "cost_pool", "allocation_method", "allocation_rule", "allocation_run", "allocation_result",
              "cost_to_serve", "profitability", "profitability_measure_definition", "client_assets"],
}

# The synthetic source systems. Ids are the SOURCE ids of the mapping modules in mapping/.
SOURCES = {
    "SRC-BRK": "Brokerage Clearing Platform",
    "SRC-CRM": "Client Relationship Management (Salesforce FSC shape)",
    "SRC-TA": "Transfer Agent Fund Share Register",
    "SRC-INST": "Institutional Client Platform",
    "SRC-PAB": "Portfolio Accounting Book of Record",
    "SRC-BIL": "Advisory Fee Billing Engine",
    "SRC-REV": "Revenue Sub-Ledger",
    "SRC-CST": "Cost Allocation Engine",
}

AS_OF = "2026-09-30"          # the one locked month-end the demo publishes
SEED = 20261017               # generator seed; change it to get a different synthetic firm

# Entities no slice table reads but the activation needs: the identifier entities that resolve source account and party
# numbers to the enterprise keys, and the staging entities of the books of record that the sources map to directly
# (brokerage activity and holdings are 49, DP-300; the fund share register is 29, DP-580). DP-006 and DP-007 derive from them.
EXTRA_ENTITIES = [
    ("DP-093", "Account Identifier"), ("DP-240", "Party Identifier"),
    ("DP-300", "Client Holding"), ("DP-300", "Client Account Activity"), ("DP-300", "Cash Balance"),
    ("DP-580", "Shareholder Account"), ("DP-580", "Register Position"), ("DP-580", "Register Transaction"),
    # the institutional separate accounts: the portfolio book of record (18, DP-142 and DP-140)
    ("DP-142", "Portfolio Holding"), ("DP-142", "Portfolio Valuation Summary"), ("DP-140", "Portfolio"), ("DP-140", "Investment Mandate"), ("DP-140", "Portfolio Implementation Link"),
]

# Products the compiler derives from other products by firm rules, rather than mapping from sources. A derived product is
# enabled when every product it derives from is enabled. DP-013's calendar and code values come from the taxonomy itself.
DERIVED_PRODUCTS = {
    "DP-013": [],                                              # calendar and code values generated from the taxonomy
    "DP-192": ["DP-009"],                                      # the HR worker record is stood in for by the advisor record (CRM User)
    "DP-006": ["DP-300", "DP-580", "DP-093", "DP-240"],        # client flow transactions from the two books of record
    "DP-007": ["DP-300", "DP-580", "DP-093", "DP-004"],        # account asset summaries and positions
    "DP-008": ["DP-006", "DP-007", "DP-093", "DP-240", "DP-009"],   # the certified family
    "DP-320": ["DP-008", "DP-007", "DP-240", "DP-093", "DP-009", "DP-004"],
    "DP-495": ["DP-006", "DP-093", "DP-240"],                  # identifier crosswalk and match results from the mapping registry
}

# Entities of otherwise mapped products that the compiler derives (DP-510 maps its dimensions and health scores from the
# institutional platform; its asset facts derive from DP-007's summaries and the institutional client link).
DERIVED_ENTITIES = {
    "DP-510/Fact Account Asset Summary": ["DP-007"],
    "DP-510/Fact Attributed Client Assets": ["DP-007", "DP-003", "DP-093"],
    "DP-510/Fact Relationship Health": ["DP-510", "DP-007"],
    # the billing re-performance test, cost to serve and profitability are computed from the billing, revenue and
    # allocation products by firm rules (DP-346, DP-498 and DP-499 own no source of their own)
    "DP-346/Fact Fee Billing Test": ["DP-305"],
    "DP-498/Fact Cost to Serve": ["DP-480"],
    "DP-499/Fact Profitability": ["DP-012", "DP-480", "DP-008"],
    "DP-499/Profitability Measure Definition": ["DP-499"],
}

# When several sources feed one entity, each column is taken from the first source in this order that maps it.
SOURCE_PRIORITY = ["SRC-CRM", "SRC-BRK", "SRC-TA", "SRC-INST", "SRC-PAB", "SRC-BIL", "SRC-REV", "SRC-CST"]

# Runtime: duckdb (the reference) or spark (local Spark with Delta Lake, laid out like a Databricks workspace).
import os as _os
CATALOG = "wealth"                 # the Unity Catalog name the exported Databricks assets use
SPARK_CORES = int(_os.environ.get("ACTIVATION_SPARK_CORES", "2"))              # raise on a bigger machine
SPARK_DRIVER_MEMORY = _os.environ.get("ACTIVATION_SPARK_MEMORY", "2g")
