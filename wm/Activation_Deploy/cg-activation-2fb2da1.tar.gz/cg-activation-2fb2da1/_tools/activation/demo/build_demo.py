"""Builds the self-contained demo page of the source-to-semantic activation (00_Program/Activation_Demo.html): the
overview, the three moments (Map, Compile, Ask) and the taxonomy findings, every figure read from activation/out/ or
computed at build time through serve/query.py. The page opens from the file system with no server.

Usage (from _tools/):  activation/.venv/bin/python activation/demo/build_demo.py
Reads the dbt export (out/dbt/) and the mapping assistant's evaluation (out/proposals/eval_*.json) when present.
"""
import contextlib, csv, glob, html, io, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import _paths  # noqa: E402,F401
for _d in ("compile", "serve", "mapping", "sources"):
    sys.path.insert(0, os.path.join(_paths.HERE, _d))
import duckdb  # noqa: E402
import config, brand, decisions, query, check_truths  # noqa: E402
import map_bil, map_brokerage, map_crm, map_cst, map_inst, map_pab, map_rev, map_ta  # noqa: E402
from schema import SOURCES  # noqa: E402
from physical import DB_PATH  # noqa: E402

REPO = os.path.dirname(_paths.TOOLS)
OUT_HTML = os.path.join(REPO, "00_Program", "Activation_Demo.html")
OUT = _paths.OUT
MODULES = [map_brokerage, map_crm, map_ta, map_inst, map_pab, map_bil, map_rev, map_cst]
LIMIT = 200
FINDINGS = [f"CW-{n}" for n in range(275, 281)]
MCP_TOOLS = [("list_metrics", "the metrics of the slice and whether each answers"),
             ("describe", "a metric's definition, SQL, time rule and lineage to the taxonomy"),
             ("query", "runs a metric with breakdowns, filters and a period; returns rows, SQL and lineage"),
             ("coverage", "the activation states of products, entities, tables, metrics and questions"),
             ("cannot_answer", "the questions the models decline, with the reason and the gap id"),
             ("ask", "a business question in plain words, routed to a verified question or a metric")]
LEVERS = [("The slice", "any semantic models in config.SLICE, narrowed by config.TABLES"),
          ("The sources", "the firm's own data dictionaries in place of the synthetic ones, and its extracts"),
          ("The runtime", "DuckDB locally; the generated SQL ports to the firm's warehouse"),
          ("The semantic engine", "dbt Semantic Layer export; other engines are adapters over the compiled model"),
          ("The assistant", "Claude through MCP; any model behind the same tools")]


# ----------------------------------------------------------------------------------------------------------- helpers
def e(x):
    """HTML-escapes a value; None renders empty."""
    return "" if x is None else html.escape(str(x))


def rd(name):
    """Loads out/<name> as JSON, or None when it is not built."""
    p = os.path.join(OUT, name)
    return json.load(open(p)) if os.path.exists(p) else None


def num(v, d=2):
    """A number with thousands separators; None renders as a dash."""
    if v is None:
        return "&ndash;"
    if isinstance(v, float) and abs(v) < 0.5 * 10 ** -d:
        v = 0.0
    if isinstance(v, (int, float)) and float(v).is_integer() and d == 0:
        return f"{int(v):,}"
    return f"{v:,.{d}f}"


AMOUNT_WORDS = ("Assets", "Amount", "Value", "Sales", "Redemptions", "Flows", "Exchanges", "Transfers", "Movement", "Impact", "Excluded", "Overlap")


def fmt(v, name=""):
    """Formats an answer cell by the metric's name: percent, US dollar amount, count or text."""
    if v is None:
        return "&ndash;"
    if isinstance(v, bool):
        return "yes" if v else "no"
    if isinstance(v, (int, float)):
        if "%" in name:
            return f"{v * 100:.1f}%" if abs(v) <= 1.5 else f"{v:.2f}%"
        if any(w in name for w in AMOUNT_WORDS):
            return ("-" if v <= -0.005 else "") + f"${abs(v):,.2f}"
        return f"{int(v):,}" if float(v).is_integer() else f"{v:,.4f}"
    return e(v)


def badge(state):
    """The three-state badge (enabled, partial, not started) and the yes/no badges."""
    cls = {"enabled": "ok", "partial": "warn", "not started": "bad", "yes": "ok", "no": "bad", "met": "ok"}.get(state, "neutral")
    return f'<span class="badge {cls}">{e(state)}</span>'


def table(head, rows, cls="", limit=LIMIT, attrs=None):
    """A table with a header; long tables keep the first `limit` rows and say how many there are."""
    attrs = attrs or [""] * len(rows)
    body = "".join(f"<tr{a}>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r, a in list(zip(rows, attrs))[:limit])
    more = f'<p class="note">Showing the first {limit} of {len(rows):,} rows.</p>' if len(rows) > limit else ""
    return f'<div class="tw"><table class="{cls}"><thead><tr>' + "".join(f"<th>{h}</th>" for h in head) + f"</tr></thead><tbody>{body}</tbody></table></div>{more}"


def code(text, lang=""):
    return f'<pre class="code {lang}"><code>{e(text)}</code></pre>'


def details(summary, body, open_=False):
    return f'<details class="det"{" open" if open_ else ""}><summary>{summary}</summary><div class="det-b">{body}</div></details>'


def sec(id_, eyebrow, title, lede, body):
    return f'<section id="{id_}"><div class="sec-h"><span class="eyebrow">{e(eyebrow)}</span><h2>{e(title)}</h2><p>{lede}</p></div>{body}</section>'


def h3(t, sub=""):
    return f'<h3>{e(t)}</h3>' + (f'<p class="sub">{sub}</p>' if sub else "")


def tgt(t):
    """A mapping target (domain, object, attribute) as text."""
    return " &middot; ".join(e(x) for x in t if x) if t else ""


def notbuilt(what, cmd):
    return f'<div class="callout">{e(what)} not built yet. Run <code>{e(cmd)}</code> from <code>_tools/</code> and rebuild this page.</div>'


def stat(n, label):
    return f'<div class="stat"><b>{n}</b><span>{label}</span></div>'


# ----------------------------------------------------------------------------------------------------------- data
def load_inputs():
    """Every generated input the page reads."""
    d = {k: rd(k + ".json") for k in ("slice", "coverage", "physical_report", "derivation_report", "test_results", "compiled_model", "activation")}
    d["truths"] = rd("sources/truths.json")
    d["evals"] = [json.load(open(p)) for p in sorted(glob.glob(os.path.join(OUT, "proposals", "eval_*.json")))]
    return d


def state_counts(summary):
    return "".join(f'<td>{num(summary.get(s, 0), 0)}</td>' for s in ("enabled", "partial", "not started"))


ASKS = [
    ("What were net new assets in 2026-Q3 by channel?", "Net New Assets", dict(by=["client_assets_flows.dimension_key"], dimension_type="Channel", period="2026-Q3")),
    ("What were Client Assets at the month-end by channel?", "Client Assets", dict(by=["distribution_channel.channel_name"])),
    ("What were Client Assets at the month-end by holding type?", "Client Assets", dict(by=["client_assets_flows.dimension_key"], dimension_type="Holding Type")),
    ("How many funded accounts does each channel have?", "Funded Accounts", dict(by=["distribution_channel.channel_name"])),
    ("How many clients does each channel have?", "Clients", dict(by=["distribution_channel.channel_name"])),
    ("How many households does each channel have?", "Households", dict(by=["distribution_channel.channel_name"])),
    ("What share of client assets is in our own funds, by channel?", "Own-Fund Share of Client Assets %", dict(by=["account_asset_summary.summary_distribution_channel"])),
    ("Which ten households hold the most client assets?", "Household Client Assets", dict(by=["household.household_name"]), 10),
    ("How many households have no primary advisor?", "Households Without Primary Advisor", {}),
    ("How many households sit in a service tier their assets do not qualify for?", "Service Tier Qualification Mismatch", {}),
    ("How many suggested identity matches are waiting for a steward?", "Suggested Matches Awaiting Review", {}),
    ("How much did same-owner transfers move that net new assets leave out?", "Same-Owner Transfers Excluded", {}),
    ("Which households have no current financial plan?", "Households Without Current Plan", {}),
    ("Which household goals are off track?", "Household Goals Off Track", {}),
    ("What are Client Assets by channel and holding type at once?", "Client Assets by Channel and Holding Type", {}),
    ("How much of our AUM with public pension plans sits with clients whose relationship is at risk?", "At-Risk Relationship Client Assets",
     dict(by=["institutional_client.institutional_client_type"], filters=["institutional_client.institutional_client_type = 'Public Pension Plan'"])),
    ("How many public pension plan relationships are at risk, and what do they hold with us in total?", "Relationship Client Assets",
     dict(by=["institutional_client.institutional_client_type"], filters=["institutional_client.institutional_client_type = 'Public Pension Plan'"])),
    ("Which institutional relationships are at risk, by segment?", "At-Risk Relationships", dict(by=["service_relationship.servicing_segment"])),
    ("What is the effective net fee rate by offering over the last four quarters?", "Effective Net Fee Rate", dict(by=["client_revenue.revenue_service_offering"], period="2025-10-01..2026-09-30")),
    ("How much client fee revenue did each offering earn over the last four quarters?", "Client Fee Revenue", dict(by=["client_revenue.revenue_service_offering"], period="2025-10-01..2026-09-30")),
    ("How many advisory fee runs failed reconciliation this quarter?", "Failed Fee Runs", dict(period="2026-Q3")),
    ("How many accounts were billed outside their schedule this quarter?", "Accounts Billed Off Schedule", dict(period="2026-Q3")),
    ("Which service offerings have negative contribution over the last four quarters?", "Contribution Margin", dict(by=["profitability.profitability_service_offering"], period="2025-10-01..2026-09-30")),
    ("What does it cost to serve each client segment this quarter?", "Total Cost to Serve", dict(by=["cost_to_serve.cts_client_segment"], period="2026-Q3")),
    ("What is the cost-to-serve rate by client segment?", "Cost to Serve Rate (bps)", dict(by=["cost_to_serve.cts_client_segment"], period="2026-Q3")),
]


def precompute(model):
    """Runs every Ask request through the query engine; returns (question, request, result, top) tuples."""
    out = []  # the engine queries through the process's runtime connection
    for a in ASKS:
        q, metric, kw = a[0], a[1], a[2]
        top = a[3] if len(a) > 3 else None
        try:
            r = query.run(model, metric, **kw)
        except Exception as ex:  # a request the engine cannot plan is shown as a refusal with its reason
            r = dict(metric=metric, answerable=False, reason=str(ex), rows=[], sql=None, lineage=None)
        if top and r["rows"]:
            r["total_rows"] = len(r["rows"])
            r["rows"] = sorted(r["rows"], key=lambda x: -(x.get(r["metric"]) or 0))[:top]
        out.append((q, kw, r))
    return out


def proof(truths):
    """The Total rows of the as-of month and quarter, pipeline beside truth, the planted facts, and check_truths' verdict."""
    import runtime
    con = runtime.get()
    cols = check_truths.AMOUNTS + check_truths.COUNTS + ["client_organic_growth_rate"]
    got = {}
    for r in con.fetch(con.sql("select period_type, " + ", ".join(check_truths.DBCOL.get(c, c) for c in cols) +
                               f" from cert.measure_wide where dimension_type = 'Total' and period_end_date = date '{config.AS_OF}'")):
        got[r[0]] = dict(zip(cols, r[1:]))
    tru = {t["period_type"]: t for t in truths["measure_values"] if t["dimension_type"] == "Total" and t["period_end"] == config.AS_OF}
    planted = check_truths.planted_values(con)
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = check_truths.main()
    lines = buf.getvalue().strip().splitlines()
    return cols, got, tru, planted, rc, lines


def mcp_snippet():
    """The registration snippet: the repo's .mcp.json, else the first .mcp.json under _tools/."""
    cands = [os.path.join(REPO, ".mcp.json")] + sorted(glob.glob(os.path.join(_paths.TOOLS, "**", ".mcp.json"), recursive=True))
    for p in cands:
        if os.path.exists(p) and ".venv" not in p:
            return os.path.relpath(p, REPO), open(p).read()
    return None, None


# ----------------------------------------------------------------------------------------------------------- sections
def s_overview(d):
    """The claim, the moments, the activation summary, the slice, what is hand-written, the levers."""
    a, sl, cm = d["activation"], d["slice"], d["compiled_model"]
    s = a["summary"]
    rows = [[k.capitalize()] + [num(s[k].get(x, 0), 0) for x in ("enabled", "partial", "not started")] for k in ("products", "entities", "tables", "metrics", "questions")]
    summ = table(["", badge("enabled"), badge("partial"), badge("not started")], rows, "states")
    ins = [m for m in cm["metrics"] if m.get("in_scope") and not m.get("ref")]
    ans = sum(1 for m in ins if m.get("answerable"))
    exp = [t for t in d["test_results"]["tests"] if t["kind"] == "expectation"]
    stats = "".join([stat(f'{ans} of {len(ins)}', "in-scope metrics answer"), stat(num(len(d["truths"]["measure_values"]), 0), "certified rows proven to the cent"),
                     stat(num(s["tests"], 0), "generated tests"), stat(f'{sum(1 for t in exp if t.get("met"))} of {len(exp)}', "planted gaps caught"),
                     stat(num(s["gaps"], 0), "gaps named"), stat(num(s["cannot_answer"], 0), "questions declined with a reason")])
    moments = "".join(f'<a class="moment" href="#{i.lower()}"><span class="eyebrow">{n}</span><b>{i}</b><span>{t}</span></a>' for n, i, t in [
        ("1", "Map", "Eight source systems are mapped to the taxonomy in a registry whose rows name taxonomy objects and attributes, with crosswalks for code values and identifier schemes for keys."),
        ("2", "Compile", "The registry compiles to conformed tables, the derived products are built by firm rules, generated tests run, and the semantic models compile to views, joins and metrics in SQL."),
        ("3", "Ask", "A query engine answers the models' verified questions with the SQL and the lineage back to the taxonomy, and declines the questions the models cannot answer, naming the gap.")])
    mrows = []
    for mid, m in sl["models"].items():
        mrows.append([f"<b>{e(mid)}</b> {e(m['name'])}<br><span class='muted'>{e(m['owner'])}</span>", num(len(m["tables"]), 0),
                      ", ".join(f"<code>{e(t)}</code>" for t in m["tables"]), num(len(m["tables_left_out"]), 0)])
    mapped_rows = sum(len(m.ATTRIBUTES) for m in MODULES)
    prose = sum(1 for m in ins if m.get("sql") and m.get("text") and m["sql"] != m["text"])
    hand = [("Hand-written", f"The confirmed mappings ({mapped_rows} registry rows over {len(MODULES)} sources), the derivation rules of the certified family "
             f"(DP-006, DP-007, DP-008, DP-320, DP-495) and the SQL of the {prose} in-scope metrics whose model text is a sentence."),
            ("Generated from the model", f"The slice ({len(sl['tables'])} semantic tables, {len(sl['entities'])} logical entities), the conformed tables and keys, "
             f"{num(s['tests'], 0)} data-quality tests, {len(cm['tables'])} views, {len(cm['joins'])} joins, the metric SQL of the rest, the activation states, the dbt export and the lineage of every answer.")]
    body = (f'<p class="claim">Map a source system to the taxonomy once, and the data products and the semantic layer above it switch on without new definitions. '
            f'With {len(MODULES)} sources mapped for {len(sl["models"])} semantic models, the firm\'s certified client asset figures compute, prove to the cent and answer questions with their lineage, as of {e(sl["as_of"])}.</p>'
            f'<div class="moments">{moments}</div><div class="stats">{stats}</div>'
            f'<div class="grid2"><div class="card">{h3("Activation summary", "Enabled: every attribute the slice reads is mapped or derived. Partial: keys mapped, some attributes missing. Not started: nothing maps to it.")}{summ}'
            f'<p class="note">{num(s["gaps"], 0)} gaps; {num(s["tests"], 0)} tests, {num(s["test_failures"], 0)} with failing rows; {num(s["cannot_answer"], 0)} declined questions.</p></div>'
            f'<div class="card">{h3("The slice", "The one input: the semantic models to activate. Everything else is resolved from their table bindings.")}'
            + table(["Model", "Tables kept", "Tables", "Left out"], mrows) + '</div></div>'
            f'<div class="grid2"><div class="card">{h3("Hand-written and generated")}' + "".join(f"<p><b>{e(k)}.</b> {e(v)}</p>" for k, v in hand) + '</div>'
            f'<div class="card">{h3("Tailoring levers")}<ul class="levers">' + "".join(f"<li><b>{e(k)}</b> {e(v)}</li>" for k, v in LEVERS) + '</ul></div></div>')
    return sec("overview", "Source to semantic", "Activation demo", f"The operating model's first link, built for one slice: SM-20 Client Assets &amp; Flows and the household tables of SM-21 Client &amp; Household 360.", body)


def s_map(d):
    """Sources, registry, crosswalks, identifier schemes, the assistant's evaluation, coverage and gaps."""
    phys, a, cov = d["physical_report"], d["activation"], d["coverage"]
    parts = []
    for sid, s in SOURCES.items():
        dic = {}
        p = os.path.join(OUT, "sources", sid, "_dictionary.csv")
        if os.path.exists(p):
            for r in csv.DictReader(open(p)):
                dic.setdefault(r["table"], []).append(r)
        trows = []
        for tn, t in s["tables"].items():
            ex = table(["Column", "Type", "Description", "Example"], [[f"<code>{e(r['column'])}</code>", e(r["type"]), e(r["description"]), f"<code>{e(r['example'])}</code>"] for r in dic.get(tn, [])[:6]], "small")
            trows.append(details(f"<code>{e(tn)}</code> <span class='muted'>{e(t['description'])}</span> <span class='pill'>{num(phys['sources'].get(sid + '/' + tn), 0)} rows</span> <span class='pill'>{len(t['columns'])} columns</span>",
                                 ex + (f'<p class="note">{len(dic.get(tn, [])) - 6} more columns in the dictionary.</p>' if len(dic.get(tn, [])) > 6 else "")))
        parts.append(f'<div class="card src"><span class="eyebrow">{e(sid)} &middot; {e(s["kind"])}</span><h3>{e(s["name"])}</h3><p class="sub">{e(s["shape"])}. {e(s["note"])}</p>{"".join(trows)}</div>')
    srcs = h3("The eight source systems", "Synthetic, in their vendors' shapes and codes: nothing in them uses the taxonomy's names.") + "".join(parts)
    kinds = sorted({r[3] for m in MODULES for r in m.ATTRIBUTES})
    reg = [h3("The mapping registry", "One module per source, in the registry standard (CW-275). Each row names a taxonomy object and attribute; the kind says how the column becomes it.")
           + '<div class="filters"><label>Kind <select id="kindf"><option value="">all kinds</option>' + "".join(f'<option>{e(k)}</option>' for k in kinds)
           + '</select></label><label>Search <input id="regq" type="search" placeholder="column, attribute, detail"></label></div>']
    for m in MODULES:
        S = m.SOURCE
        objs = table(["Source table", "Taxonomy object", "Grain"], [[f"<code>{e(t)}</code>", tgt(o), e(n)] for t, o, n in m.OBJECTS], "small")
        kc = {}
        for r in m.ATTRIBUTES:
            kc[r[3]] = kc.get(r[3], 0) + 1
        attrs = table(["Table", "Column", "Taxonomy target", "Kind", "Detail"],
                      [[f"<code>{e(r[0])}</code>", f"<code>{e(r[1])}</code>", tgt(r[2]), f'<span class="kind k-{e(r[3])}">{e(r[3])}</span>', e(r[4])] for r in m.ATTRIBUTES],
                      "small reg", attrs=[f' data-kind="{e(r[3])}"' for r in m.ATTRIBUTES])
        gaps = "".join(f"<li><code>{e(t)}</code> {e(n)}</li>" for t, n in getattr(m, "GAPS", []))
        reg.append(details(f"<b>{e(S['id'])}</b> {e(S['name'])} <span class='pill'>{len(m.OBJECTS)} objects</span> <span class='pill'>{len(m.ATTRIBUTES)} attribute rows</span> "
                           + " ".join(f"<span class='kind k-{e(k)}'>{e(k)} {v}</span>" for k, v in sorted(kc.items())),
                           "<h4>OBJECTS</h4>" + objs + "<h4>ATTRIBUTES</h4>" + attrs + (f"<h4>Declared gaps</h4><ul>{gaps}</ul>" if gaps else ""), open_=m is MODULES[0]))
    xw = [h3("Crosswalks", "Source code values to taxonomy code values. A value with no taxonomy equivalent is left empty on purpose: it is a gap, and the tests fail the rows that carry it.")]
    for m in MODULES:
        items = []
        for name, c in m.CROSSWALKS.items():
            vals = c["values"]
            ng = sum(1 for v in vals if v[1] is None)
            rows = [[f"<code>{e(v[0])}</code>", e(v[1]) if v[1] is not None else '<span class="badge bad">no equivalent</span>', e(v[2] if len(v) > 2 else "")] for v in vals]
            items.append(details(f"<code>{e(name)}</code> &rarr; {tgt(c['target'])} <span class='pill'>{len(vals)} values</span>" + (f" <span class='badge bad'>{ng} gap{'s' if ng > 1 else ''}</span>" if ng else ""),
                                 table(["Source code", "Taxonomy value", "Note"], rows, "small", attrs=[' class="gaprow"' if v[1] is None else "" for v in vals])))
        xw.append(f'<div class="card"><h4>{e(m.SOURCE["id"])} <span class="muted">{len(m.CROSSWALKS)} crosswalks</span></h4>{"".join(items)}</div>')
    idr = []
    for m in MODULES:
        for col, v in m.SOURCE["identifier_schemes"].items():
            proposed = v[2] is None
            idr.append([e(m.SOURCE["id"]), f"<code>{e(col)}</code>", f"{e(v[0])} {e(v[1])}",
                        ('<span class="badge warn">proposed</span> ' + e(v[3] if len(v) > 3 else "")) if proposed else e(v[2])])
    ids = h3("Identifier schemes", "Each source key lands in the identifier entity under its scheme and resolves to the enterprise key. A scheme the taxonomy lacks is proposed (CW-279).") + table(["Source", "Key column", "Scheme list", "Scheme"], idr, "small")
    ires = table(["Entity", "Column", "Source", "Scheme", "Type", "Unresolved"], [[e(i["entity"]), f"<code>{e(i['column'])}</code>", e(i["source"]), f"<code>{e(i['scheme'])}</code>", e(i["type"]), num(i.get("unresolved"), 0) if "unresolved" in i else "&ndash;"] for i in phys["identifiers"]], "small")
    ids += "<h4>Keys resolved at compile time</h4>" + ires
    if d["evals"]:
        rows = []
        for ev in d["evals"]:
            for k, r in ev["results"].items():
                rows.append([e(ev["source"]), f'<span class="badge {"ask" if ev["proposer"] != "baseline" else "neutral"}">{e(ev["proposer"])}</span>', f"<b>{e(k)}</b>" if k == "overall" else e(k),
                             num(r.get("confirmed"), 0), num(r.get("proposed"), 0) if "proposed" in r else "&ndash;",
                             f'{r["precision"]:.0%}' if r.get("precision") is not None else "&ndash;", f'{r["recall"]:.0%}' if r.get("recall") is not None else "&ndash;"])
        props = sorted({ev["proposer"] for ev in d["evals"]})
        ai = (h3("The AI mapping assistant", "It proposes a registry from a data dictionary and the taxonomy; the steward confirms. Measured here against the confirmed modules, per mapping kind.")
              + f'<p class="note">Proposers evaluated: {", ".join(e(p) for p in props)}. The baseline is a deterministic token-overlap matcher with no model call, the floor the assistant is measured against; '
              + ("a Claude proposal appears beside it when it has been run." if "baseline" in props and len(props) == 1 else "the Claude rows are the assistant itself.") + '</p>'
              + table(["Source", "Proposer", "Kind", "Confirmed rows", "Proposed", "Precision", "Recall"], rows, "small"))
    else:
        ai = h3("The AI mapping assistant") + notbuilt("The assistant's evaluation is", "activation/.venv/bin/python activation/mapping/propose.py SRC-BRK --baseline --eval")
    inferred = {k: v["state"] for k, v in cov["products"].items()}
    prow = [[f"<b>{e(p['id'])}</b> {e(p['name'])}", e(p["tier"]), badge(inferred.get(p["id"], "")), badge(p["state"]), e(", ".join(p.get("derived_from") or [])),
             "<br>".join(e(x) for x in p.get("missing") or []) or "&ndash;"] for p in a["products"].values()]
    covh = h3("Coverage per product", "Inferred from the mappings (CW-277), then the fact after the build: a derived product is enabled when the products it derives from are.") + table(["Product", "Tier", "Inferred", "Built", "Derived from", "Missing attributes"], prow, "small")
    grows = [[e(g.get("source", "")), f"<code>{e(g.get('table', ''))}</code>" if g.get("table") else e(g.get("entity", "")), tgt(g.get("target")), e(g.get("kind", "derivation")), e(g["note"])] for g in a["gaps"]]
    gaph = h3(f"Every gap ({len(a['gaps'])})", "Unmapped attributes, code values with no equivalent, schemes the taxonomy lacks, and the derivation notes.") + table(["Source", "Table or entity", "Target", "Kind", "Note"], grows, "small")
    body = (f'<div class="card">{srcs}</div><div class="card">{"".join(reg)}</div><div>{"".join(xw)}</div><div class="card">{ids}</div><div class="card">{ai}</div>'
            f'<div class="card">{covh}</div><div class="card">{gaph}</div>')
    return sec("map", "Moment 1", "Map", "The steward-confirmed registry is the only hand-written link between a source and the taxonomy. It is checked against the taxonomy, and it reports what each source enables.", body)


def chain_svg(products, phys):
    """The derivation chain as inline SVG: sources, then products by derivation depth (config.DERIVED_PRODUCTS)."""
    der = config.DERIVED_PRODUCTS
    nodes = set(der) | {u for ups in der.values() for u in ups}
    lvl = {}

    def L(p):
        if p not in lvl:
            lvl[p] = 1 + max((L(u) for u in der.get(p, [])), default=-1) if der.get(p) else 0
        return lvl[p]
    for p in nodes:
        L(p)
    feeds = {}
    for key, en in phys["entities"].items():
        for f in en.get("feeds", []):
            feeds.setdefault(f.split("/")[0], set()).add(key.split("/")[0])
    cols = {-1: sorted(SOURCES)}
    for p in sorted(nodes):
        cols.setdefault(lvl[p], []).append(p)
    W, H, GX, GY = 168, 46, 205, 60
    pos, maxn = {}, max(len(v) for v in cols.values())
    for c, items in cols.items():
        off = (maxn - len(items)) * GY / 2
        for i, n in enumerate(items):
            pos[n] = (20 + (c + 1) * GX, 30 + off + i * GY)
    edges = [(s, p) for s, ps in feeds.items() if s in pos for p in ps if p in pos and lvl.get(p) == 0] + [(u, p) for p, ups in der.items() for u in ups]
    out = []
    for a_, b_ in edges:
        (x1, y1), (x2, y2) = pos[a_], pos[b_]
        x1, y1, y2 = x1 + W, y1 + H / 2, y2 + H / 2
        mx = (x1 + x2) / 2
        out.append(f'<path class="edge" d="M{x1:.0f},{y1:.0f} C{mx:.0f},{y1:.0f} {mx:.0f},{y2:.0f} {x2:.0f},{y2:.0f}"/>')
    for n, (x, y) in pos.items():
        if n in SOURCES:
            name, st = SOURCES[n]["name"], "src"
        else:
            p = products.get(n, {})
            name, st = p.get("name", ""), p.get("state", "")
            st = {"enabled": "ok", "partial": "warn"}.get(st, "bad")
            if n in der and not der[n]:
                name = name + " (from the taxonomy)"
        short = name if len(name) <= 26 else name[:25] + "…"
        out.append(f'<g class="node {st}"><title>{e(n)} {e(name)}</title><rect x="{x}" y="{y}" width="{W}" height="{H}" rx="4"/>'
                   f'<text x="{x + 10}" y="{y + 19}" class="nid">{e(n)}</text><text x="{x + 10}" y="{y + 36}" class="nname">{e(short)}</text></g>')
    heads = "".join(f'<text class="colh" x="{20 + (c + 1) * GX}" y="16">{t}</text>' for c, t in [(-1, "Sources"), (0, "Mapped products"), (1, "Derived by firm rules"), (2, "Certified family"), (3, "Consumer view")] if c in cols)
    w, h = 20 + (max(cols) + 2) * GX, 40 + maxn * GY
    return f'<div class="tw"><svg class="chain" viewBox="0 0 {w} {h}" width="{w}" role="img" aria-label="Derivation chain from sources to products">{heads}{"".join(out)}</svg></div>'


def s_compile(d):
    """Physical layer, derivation chain, proof, tests, semantic layer, dbt export."""
    phys, a, tr, cm = d["physical_report"], d["activation"], d["test_results"], d["compiled_model"]
    rows = []
    for k, en in phys["entities"].items():
        filled = sum(1 for c in en.get("columns", {}).values() if c.get("non_null"))
        rows.append([f"<code>{e(en['table'])}</code>", e(k), num(en["rows"], 0), f"{filled} of {len(en.get('columns', {}))}", num(len(en.get("unmapped", [])), 0),
                     e(", ".join(en.get("feeds", []))) or f'<span class="muted">{e(en.get("note", ""))}</span>'])
    physh = h3("The physical layer", "One conformed table per logical entity, columns filled from the registry, keys minted and resolved through the identifier entities.") + table(["Table", "Entity", "Rows", "Columns filled", "Unmapped", "Fed by"], rows, "small")
    drows = [[e(k), num(v, 0), badge(a["entities"].get(k, {}).get("state", ""))] for k, v in d["derivation_report"]["counts"].items()]
    chain = (h3("The derivation chain", "Sources map to the books of record and the masters; the derived products are built from them by firm rules (config.DERIVED_PRODUCTS).") + chain_svg(a["products"], phys)
             + table(["Derived entity", "Rows", "State"], drows, "small"))
    cols, got, tru, planted, rc, lines = proof(d["truths"])
    prow = []
    for c in cols:
        dec = 6 if c == "client_organic_growth_rate" else (0 if c in check_truths.COUNTS else 2)
        cells = []
        for pt in ("Month", "Quarter"):
            g, t = got.get(pt, {}).get(c), tru.get(pt, {}).get(c)
            ok = g is not None and t is not None and abs((g or 0) - (t or 0)) <= (1e-6 if dec == 6 else 0.011)
            cells += [num(g, dec), num(t, dec), badge("yes" if ok else "no")]
        prow.append([e(c.replace("_", " ").capitalize())] + cells)
    ptab = table(["Measure (Total)", f"{config.AS_OF[:7]} pipeline", "truth", "match", "2026-Q3 pipeline", "truth", "match"], prow, "small num")
    frow = [[e(k.replace("_", " ").capitalize()), num(v, 2 if isinstance(d["truths"]["planted"][k], float) else 0), num(d["truths"]["planted"][k], 2 if isinstance(d["truths"]["planted"][k], float) else 0),
             badge("yes" if abs(float(v or 0) - float(d["truths"]["planted"][k])) <= 0.011 else "no")] for k, v in planted.items() if k in d["truths"]["planted"]]
    verdict = lines[-1] if lines else ""
    proofh = (h3("The proof", "The generator computed the certified figures independently, in Python, from the same synthetic firm. The pipeline must match them to the cent.")
              + f'<div class="callout {"ok" if rc == 0 else "bad"}"><b>check_truths.py</b>: {e(lines[0] if lines else "")}. <b>{e(verdict)}</b></div>' + ptab
              + "<h4>Planted facts</h4>" + table(["Fact", "Pipeline", "Truth", "Match"], frow, "small num"))
    srows = [[e(p), num(v["tests"], 0), num(v["failures"], 0), num(v["errors"], 0), num(v["warnings"], 0)] for p, v in tr["summary"].items()]
    exp = [t for t in tr["tests"] if t["kind"] == "expectation"]
    erows = [[badge("met" if t.get("met") else "no"), e(t["product"]), f"<code>{e(t['column'])}</code>", e(t["note"]), num(t["failures"], 0), "<br>".join(f"<code>{e(s)}</code>" for s in t["samples"][:3])] for t in exp]
    fails = sorted([t for t in tr["tests"] if t["failures"] and t["kind"] != "expectation"], key=lambda t: -t["failures"])[:12]

    def reading(t):
        if t["note"].startswith("conditional CDE"):
            return f"Expected: a {t['note']}; the empty rows are outside that population, not defects."
        if t["kind"] == "code_membership":
            return f"Values outside the {t['note'].replace('list ', '')} list: " + ", ".join(t["samples"][:2]) + "."
        if t["kind"] == "key_unique":
            return "Duplicate keys: the source carries the same role twice for one account and date."
        if t["kind"] == "cde_complete":
            return "A critical data element the sources leave empty for these rows: a mapping gap to close or a conditional rule to record."
        return t["note"]
    frows = [[e(t["product"]), e(t["entity"]), e(t["kind"]), f"<code>{e(t['column'][:60])}</code>", f"{num(t['failures'], 0)} of {num(t['rows_checked'], 0)}", e(t["severity"]), e(reading(t))] for t in fails]
    testh = (h3("The generated tests", f"{len(tr['tests'])} tests generated from the attributes' CDE flags, code lists and references. The planted gaps must be caught: "
                + ("every expectation is met." if tr.get("expectations_met") else "an expectation was missed."))
             + '<div class="grid2"><div>' + table(["Product", "Tests", "With failures", "Errors", "Warnings"], srows, "small num") + '</div><div><h4>The planted gaps, caught</h4>'
             + table(["", "Product", "Column", "Expectation", "Rows", "Samples"], erows, "small") + '</div></div><h4>The biggest failures, read</h4>' + table(["Product", "Entity", "Test", "Column", "Failing rows", "Severity", "Reading"], frows, "small"))
    trow = [[f"<code>{e(t['view'] or '')}</code>" if t.get("view") else '<span class="muted">not compiled</span>', e(k), e(t.get("kind", "")), num(t.get("rows"), 0), aft(t.get("always_filter_text")),
             badge(a["tables"].get(k, {}).get("state", ""))] for k, t in cm["tables"].items()]
    jrow = [[f"<code>{e(j['frm'])}</code> &rarr; <code>{e(j['to'])}</code>", e(j["model"]), f"<code>{e(j['text'])}</code>", badge("yes" if j["executable"] else "no"), e(j.get("reason") or j.get("warning") or "")] for j in cm["joins"]]
    ast = {(m["model"], m["name"]): m for m in a["metrics"]}
    ins = [m for m in cm["metrics"] if m.get("in_scope")]
    mrow = [[f"<b>{e(m['name'])}</b><br><span class='muted'>{e(m['model'])}</span>", badge(ast.get((m["model"], m["name"]), {}).get("state", "")),
             fmt(m.get("value_total"), m["name"]) if m.get("answerable") else "&ndash;", (f"<span class='muted'>by reference to {e(m['ref'])}</span>" if m.get("ref") else f"<code class='sql'>{e(m.get('sql') or m.get('text') or '')}</code>"), e(m.get("reason") or m.get("note", "")[:160])] for m in ins]
    outn = len([m for m in cm["metrics"] if not m.get("in_scope")])
    semh = (h3("The semantic layer", f"{sum(1 for t in cm['tables'].values() if t.get('view'))} of {len(cm['tables'])} tables compile to views; {sum(1 for j in cm['joins'] if j['executable'])} of {len(cm['joins'])} joins execute; "
               f"{sum(1 for m in ins if m.get('answerable') and not m.get('ref'))} of {sum(1 for m in ins if not m.get('ref'))} in-scope metrics of their own answer. Each one that does not names its reason.")
            + details(f"Tables and views ({len(cm['tables'])})", table(["View", "Semantic table", "Kind", "Rows", "Always-filter", "State"], trow, "small"))
            + details(f"Joins ({len(cm['joins'])})", table(["Join", "Model", "On", "Executes", "Why not"], jrow, "small"))
            + details(f"In-scope metrics ({len(ins)}, of which {sum(1 for m in ins if m.get('ref'))} defined by reference to another model), value at {e(config.AS_OF)} (Total)", table(["Metric", "State", "Value", "SQL", "Reason or note"], mrow, "small"), open_=True)
            + f'<p class="note">{outn} further metrics of the two models read tables left out of the slice; they switch on when the slice grows.</p>')
    dbt = os.path.join(OUT, "dbt")
    if os.path.isdir(dbt):
        files = sorted(os.path.relpath(p, dbt) for p in glob.glob(os.path.join(dbt, "**", "*"), recursive=True) if os.path.isfile(p))
        sm = os.path.join(dbt, "models", "semantic", "sm20_client_assets_flows.yml")
        ex = "\n".join(open(sm).read().splitlines()[:48]) if os.path.exists(sm) else ""
        mt = os.path.join(dbt, "models", "semantic", "metrics.yml")
        blocks = re.split(r"\n(?=- name: )", open(mt).read()) if os.path.exists(mt) else []
        two = [b for b in blocks if re.match(r"- name: (client_assets|net_new_assets)\n", b)][:2]
        readme = os.path.join(dbt, "README.md")
        intro = "".join(f"<li>{e(l[2:])}</li>" for l in open(readme).read().splitlines() if l.startswith("- ")) if os.path.exists(readme) else ""
        dbth = (h3("The dbt Semantic Layer export", f"{len(files)} files generated from the compiled model; the same definitions in the engine a firm may already run.") + (f"<ul>{intro}</ul>" if intro else "")
                + details(f"Files ({len(files)})", "<ul class='files'>" + "".join(f"<li><code>{e(f)}</code></li>" for f in files[:LIMIT]) + "</ul>")
                + '<div class="grid2"><div><h4>Semantic model: sm20_client_assets_flows.yml (excerpt)</h4>' + code(ex + "\n  ...") + '</div><div><h4>Two metrics: metrics.yml (excerpt)</h4>' + code("metrics:\n" + "\n".join(two)) + '</div></div>')
    else:
        dbth = h3("The dbt Semantic Layer export") + notbuilt("The dbt export is", "activation/.venv/bin/python activation/compile/export_dbt.py")
    body = "".join(f'<div class="card">{x}</div>' for x in (physh, chain, proofh, testh, semh, dbth))
    return sec("compile", "Moment 2", "Compile", "The registry compiles to conformed tables; the derived products are built by firm rules and proven; tests are generated from the taxonomy; the semantic models compile to SQL.", body)


def aft(x):
    """An always-filter text (a string or a list of them)."""
    x = "; ".join(x) if isinstance(x, list) else x
    return e(x) if x else "&ndash;"


def lineage_html(lg):
    """model -> product measure -> taxonomy attribute (definition on hover) -> owner."""
    if not lg:
        return ""
    attrs = " ".join(f'<span class="lin attr" title="{e(x["definition"])}">{e(x["attribute"])}' + (f' <small>{e(x["taxonomy"][0])} {e(x["taxonomy"][1])}</small>' if x.get("taxonomy") else "")
                     + ('<span class="badge cde">CDE</span>' if x.get("cde") else "") + "</span>" for x in lg.get("attributes", []))
    steps = [f'<span class="lin">{e(lg["model"])} {e(lg["model_name"])}</span>', f'<span class="lin">{e(lg.get("product") or "")} {e(lg.get("product_measure") or "")}</span>', attrs or '<span class="lin muted">no taxonomy attribute</span>', f'<span class="lin owner">{e(lg["owner"])}</span>']
    return '<div class="lineage">' + '<span class="arr">&rarr;</span>'.join(steps) + "</div>"


def s_ask(d, answers):
    """Verified questions, precomputed answers with SQL and lineage, refusals, the MCP tools."""
    a, cm = d["activation"], d["compiled_model"]
    qa = {(q["model"], q["question"]): q for q in cm["questions"]}
    qrow = [[e(q["model"]), e(q["question"]), badge(q["state"]), e(", ".join(q.get("metrics", []))), "<br>".join(e(x) for x in q.get("missing", [])) or "&ndash;"] for q in a["questions"]]
    vq = h3("The models' verified questions", "Each question is enabled when every metric it reads answers.") + table(["Model", "Question", "State", "Metrics", "Missing"], qrow, "small")
    cards = []
    for q, kw, r in answers:
        m = r["metric"]
        req = ", ".join([f"by {', '.join(kw['by'])}"] if kw.get("by") else []) + "".join(f", {k.replace('_', ' ')} {v}" for k, v in kw.items() if k != "by")
        if r["answerable"]:
            keys = list(r["rows"][0].keys()) if r["rows"] else []
            tb = table([e(k) for k in keys], [[fmt(row[k], m if k == m else "") for k in keys] for row in r["rows"]], "small num")
            more = f'<p class="note">Top 10 of {r["total_rows"]} households.</p>' if r.get("total_rows") else ""
            cards.append(f'<div class="answer"><p class="q">{e(q)}</p><p class="req"><b>{e(m)}</b> <span class="muted">{e(req.strip(", "))}</span></p>{tb}{more}'
                         + details("SQL", code(r["sql"], "sql")) + lineage_html(r["lineage"]) + "</div>")
        else:
            cards.append(f'<div class="answer refused"><p class="q">{e(q)}</p><p class="req"><b>{e(m)}</b> {badge("no")}</p><p>Declined: {e(r["reason"])}.</p>' + lineage_html(r.get("lineage")) + "</div>")
    ans = h3("Answers, computed when this page was built", f"{sum(1 for x in answers if x[2]['answerable'])} answered and {sum(1 for x in answers if not x[2]['answerable'])} declined. Hover an attribute for its taxonomy definition.") + '<div class="answers">' + "".join(cards) + "</div>"
    crow = [[e(c["model"]), e(c["question"]), e(c["why"]), f"<code>{e(c['gap'])}</code>" if c.get("gap") else "&ndash;"] for c in cm["cannot_answer"]]
    ca = h3("Questions the models decline", "Recorded in the models with the reason and, where one exists, the taxonomy gap id. The assistant declines them the same way.") + table(["Model", "Question", "Why", "Gap"], crow, "small")
    nos = [m for m in cm["metrics"] if m.get("in_scope") and not m.get("answerable") and not m.get("ref")]
    nrow = [[e(m["model"]), f"<b>{e(m['name'])}</b>", e(m["reason"])] for m in nos]
    ns = h3("In-scope metrics with no source yet", "They compile, but nothing in the slice populates what they read, or they span two fact tables.") + table(["Model", "Metric", "Reason"], nrow, "small")
    srv = os.path.join(_paths.HERE, "serve", "mcp_server.py")
    src = open(srv).read() if os.path.exists(srv) else ""
    trow = [[f"<code>{e(n)}</code>", e(t), badge("yes" if re.search(rf"\b{n}\b", src) else "no")] for n, t in MCP_TOOLS]
    path, snip = mcp_snippet()
    mcp = (h3("The assistant's tools (MCP)", "The same engine, exposed to an AI assistant: it answers the verified questions and declines the others with their gap ids.")
           + ("" if src else notbuilt("The MCP server (serve/mcp_server.py) is", "activation/.venv/bin/python activation/serve/mcp_server.py --selftest"))
           + table(["Tool", "What it does", "In the server"], trow, "small") + (f"<h4>Registration ({e(path)})</h4>" + code(snip) if snip else notbuilt("The .mcp.json registration is", "see activation/README.md")))
    body = "".join(f'<div class="card">{x}</div>' for x in (vq, ans, ca, ns, mcp))
    return sec("ask", "Moment 3", "Ask", "Any answerable metric runs with breakdowns through the compiled joins and returns its rows, the SQL it ran and the lineage back to the taxonomy.", body)


def s_findings():
    """The rulings the build needed: decisions CW-275 to CW-280."""
    ds = [x for x in decisions.DECISIONS if x["id"] in FINDINGS]
    cards = "".join(f'<div class="card finding"><span class="eyebrow">{e(x["id"])} &middot; {e(x.get("theme", ""))} &middot; {e(x.get("status", ""))} &middot; {e(x.get("owner_role", ""))}</span>'
                    f'<h3>{e(x["title"])}</h3><p class="sub">{e(x.get("issue", ""))}</p><p><b>Resolution.</b> {e(x["resolution"])}</p></div>' for x in ds)
    return sec("findings", "What the build found", "Findings", f"The taxonomy rulings the activation needed: {len(ds)} decisions, from the registry standard to the gaps the sources exposed.", cards)


# ----------------------------------------------------------------------------------------------------------- page
CSS = """
:root { --bg:#f5f6fa; --surface:#fff; --sunk:#eaedf3; --ink:#0c233c; --muted:#535e6c; --line:#d5d9e1; --accent:#1e49e2; --accent-ink:#fff; --accent-soft:#e3e9fc;
  --ok:#00796f; --ok-soft:#d8f5f1; --warn:#9a5b00; --warn-soft:#fbeccf; --bad:#c0262d; --bad-soft:#fbe0e1; --ask:#7213ea; --ask-soft:#ece1fd; --cde:#c8166f; --cde-soft:#fde4f1;
  --f-body:-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif; --f-display:var(--f-body); --f-mono:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace; --radius:4px; color-scheme:light; }
@media (prefers-color-scheme: dark) { :root:not([data-theme="light"]) { --bg:#071627; --surface:#0c233c; --sunk:#12304f; --ink:#f5f6fa; --muted:#a7b3c4; --line:#21405f; --accent:#7f9cff; --accent-ink:#071627; --accent-soft:#1a3266;
  --ok:#63ebda; --ok-soft:#10393d; --warn:#f2b65a; --warn-soft:#3d2c12; --bad:#ff8a8f; --bad-soft:#43191e; --ask:#b78cff; --ask-soft:#2c1f52; --cde:#ff7dbf; --cde-soft:#44193a; color-scheme:dark; } }
:root[data-theme="dark"] { --bg:#071627; --surface:#0c233c; --sunk:#12304f; --ink:#f5f6fa; --muted:#a7b3c4; --line:#21405f; --accent:#7f9cff; --accent-ink:#071627; --accent-soft:#1a3266;
  --ok:#63ebda; --ok-soft:#10393d; --warn:#f2b65a; --warn-soft:#3d2c12; --bad:#ff8a8f; --bad-soft:#43191e; --ask:#b78cff; --ask-soft:#2c1f52; --cde:#ff7dbf; --cde-soft:#44193a; color-scheme:dark; }
* { box-sizing:border-box; } html { scroll-padding-top:72px; scroll-behavior:smooth; }
body { margin:0; background:var(--bg); color:var(--ink); font:14.5px/1.55 var(--f-body); }
a { color:var(--accent); } code, pre { font-family:var(--f-mono); font-size:.86em; } h1,h2,h3,h4 { font-family:var(--f-display); margin:0; text-wrap:balance; }
.bar { position:sticky; top:0; z-index:30; background:var(--surface); border-bottom:1px solid var(--line); border-top:4px solid var(--accent); }
.bar-in { display:flex; align-items:center; gap:14px; padding:10px 24px; } .mark { display:grid; line-height:1.15; } .mark b { font-size:18px; } .mark span { font-size:11px; color:var(--muted); letter-spacing:.06em; text-transform:uppercase; }
.asof { margin-left:auto; font-size:12.5px; color:var(--muted); }
.layout { display:grid; grid-template-columns:210px minmax(0,1fr); max-width:1480px; margin:0 auto; }
nav.side { position:sticky; top:62px; align-self:start; padding:28px 12px 28px 24px; display:grid; gap:2px; }
nav.side a { text-decoration:none; color:var(--muted); padding:7px 10px; border-radius:var(--radius); font-weight:600; font-size:14px; }
nav.side a small { display:block; font-weight:400; font-size:11.5px; } nav.side a:hover { background:var(--sunk); color:var(--ink); } nav.side a.on { background:var(--accent-soft); color:var(--ink); box-shadow:inset 3px 0 0 var(--accent); }
main { padding:0 24px 80px; min-width:0; } section { padding-top:32px; }
.sec-h { margin-bottom:16px; } .sec-h h2 { font-size:30px; } .sec-h p { color:var(--muted); max-width:80ch; margin:6px 0 0; }
.eyebrow { font-size:11px; letter-spacing:.09em; text-transform:uppercase; color:var(--muted); font-weight:700; }
.card { background:var(--surface); border:1px solid var(--line); border-radius:var(--radius); padding:18px 20px; margin-bottom:16px; min-width:0; }
.card h3 { font-size:19px; margin-bottom:2px; } .card h4 { font-size:14px; margin:16px 0 6px; } p.sub { color:var(--muted); margin:2px 0 12px; max-width:90ch; }
.claim { font-size:19px; line-height:1.45; max-width:72ch; margin:0 0 18px; }
.moments { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:12px; margin-bottom:16px; }
.moment { display:grid; gap:4px; text-decoration:none; color:var(--ink); background:var(--surface); border:1px solid var(--line); border-top:4px solid var(--accent); border-radius:var(--radius); padding:14px 16px; }
.moment b { font-size:22px; } .moment span:last-child { color:var(--muted); font-size:13.5px; }
.stats { display:grid; grid-template-columns:repeat(6,minmax(0,1fr)); gap:10px; margin-bottom:16px; }
.stat { background:var(--surface); border:1px solid var(--line); border-radius:var(--radius); padding:12px 14px; display:grid; gap:2px; }
.stat b { font-size:24px; font-variant-numeric:tabular-nums; } .stat span { font-size:12.5px; color:var(--muted); }
.grid2 { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:16px; } .grid2 > .card { margin-bottom:16px; }
.tw { overflow-x:auto; max-width:100%; } table { border-collapse:collapse; width:100%; font-size:13px; }
th { text-align:left; background:var(--sunk); font-size:11px; letter-spacing:.05em; text-transform:uppercase; padding:6px 8px; position:sticky; top:0; }
td { border-top:1px solid var(--line); padding:6px 8px; vertical-align:top; overflow-wrap:break-word; } td code:not(.sql) { white-space:nowrap; } table.num td { font-variant-numeric:tabular-nums; }
table.small td { font-size:12.5px; } tr.gaprow td { background:var(--bad-soft); } table.states td:not(:first-child) { font-size:18px; font-weight:700; text-align:center; } table.states th:not(:first-child) { text-align:center; }
.badge { display:inline-block; font-size:10.5px; font-weight:700; letter-spacing:.05em; text-transform:uppercase; padding:1px 7px; border-radius:var(--radius); white-space:nowrap; }
.badge.ok { background:var(--ok-soft); color:var(--ok); } .badge.warn { background:var(--warn-soft); color:var(--warn); } .badge.bad { background:var(--bad-soft); color:var(--bad); }
.badge.neutral { background:var(--sunk); color:var(--muted); } .badge.ask { background:var(--ask-soft); color:var(--ask); } .badge.cde { background:var(--cde-soft); color:var(--cde); margin-left:4px; }
.pill { font-size:11.5px; color:var(--muted); border:1px solid var(--line); border-radius:99px; padding:0 8px; margin-left:4px; white-space:nowrap; }
.kind { font-size:11px; font-family:var(--f-mono); padding:1px 6px; border-radius:var(--radius); background:var(--sunk); white-space:nowrap; margin-right:3px; }
.k-unmapped { background:var(--bad-soft); color:var(--bad); } .k-crosswalk { background:var(--ask-soft); color:var(--ask); } .k-identifier { background:var(--accent-soft); } .k-derived { background:var(--warn-soft); color:var(--warn); } .k-direct { background:var(--ok-soft); color:var(--ok); }
details.det { border:1px solid var(--line); border-radius:var(--radius); margin:6px 0; background:var(--surface); }
details.det > summary { cursor:pointer; padding:8px 12px; font-size:13.5px; } details.det[open] > summary { border-bottom:1px solid var(--line); } .det-b { padding:10px 12px; }
pre.code { background:var(--sunk); border-radius:var(--radius); padding:10px 12px; overflow-x:auto; white-space:pre; margin:6px 0; max-height:420px; }
code.sql { white-space:pre-wrap; font-size:11.5px; } .muted { color:var(--muted); } .note { color:var(--muted); font-size:12.5px; margin:6px 0; }
.callout { border-left:4px solid var(--warn); background:var(--warn-soft); padding:10px 12px; border-radius:var(--radius); margin:8px 0; }
.callout.ok { border-color:var(--ok); background:var(--ok-soft); } .callout.bad { border-color:var(--bad); background:var(--bad-soft); }
.filters { display:flex; gap:16px; flex-wrap:wrap; margin:8px 0; font-size:13px; } .filters select, .filters input { font:inherit; padding:4px 8px; border:1px solid var(--line); border-radius:var(--radius); background:var(--surface); color:var(--ink); }
.levers { padding-left:18px; margin:0; } .levers li { margin:4px 0; } .src { border-left:4px solid var(--accent); }
.answers { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:12px; }
.answer { border:1px solid var(--line); border-radius:var(--radius); padding:12px 14px; min-width:0; } .answer.refused { background:var(--bad-soft); border-color:transparent; }
.answer .q { font-weight:700; margin:0 0 2px; font-size:15px; } .answer .req { margin:0 0 8px; font-size:12.5px; }
.lineage { display:flex; flex-wrap:wrap; gap:4px; align-items:center; margin-top:8px; font-size:12px; }
.lin { background:var(--sunk); border-radius:var(--radius); padding:2px 8px; } .lin.attr { background:var(--accent-soft); cursor:help; border-bottom:1px dotted var(--accent); } .lin.owner { background:var(--ok-soft); } .arr { color:var(--muted); }
.finding h3 { margin:4px 0; }
svg.chain { display:block; max-width:none; font-family:var(--f-body); } svg.chain .edge { fill:none; stroke:var(--muted); stroke-opacity:.45; stroke-width:1.4; }
svg.chain rect { stroke-width:1.5; } svg.chain .src rect { fill:var(--accent-soft); stroke:var(--accent); } svg.chain .ok rect { fill:var(--ok-soft); stroke:var(--ok); }
svg.chain .warn rect { fill:var(--warn-soft); stroke:var(--warn); } svg.chain .bad rect { fill:var(--bad-soft); stroke:var(--bad); }
svg.chain .nid { font-size:12.5px; font-weight:700; fill:var(--ink); } svg.chain .nname { font-size:11px; fill:var(--muted); } svg.chain .colh { font-size:11px; font-weight:700; fill:var(--muted); text-transform:uppercase; letter-spacing:.06em; }
ul.files { columns:2; font-size:12px; }
@media (max-width:980px) { .layout { grid-template-columns:1fr; } nav.side { position:sticky; top:58px; z-index:20; display:flex; overflow-x:auto; padding:8px 16px; background:var(--bg); border-bottom:1px solid var(--line); }
  nav.side a small { display:none; } main { padding:0 16px 60px; } .grid2, .answers, .moments { grid-template-columns:1fr; } .stats { grid-template-columns:repeat(2,minmax(0,1fr)); } .bar-in { padding:10px 16px; } .asof { display:none; } }
"""

JS = """
const links=[...document.querySelectorAll('nav.side a')];const secs=links.map(a=>document.querySelector(a.getAttribute('href')));
const spy=()=>{let i=0;secs.forEach((s,k)=>{if(s&&s.getBoundingClientRect().top<120)i=k});links.forEach((a,k)=>a.classList.toggle('on',k===i))};
addEventListener('scroll',spy,{passive:true});spy();
const kf=document.getElementById('kindf'),rq=document.getElementById('regq');
function filt(){const k=kf.value,q=rq.value.toLowerCase();document.querySelectorAll('table.reg tbody tr').forEach(tr=>{tr.hidden=(k&&tr.dataset.kind!==k)||(q&&!tr.textContent.toLowerCase().includes(q))});
 if(k||q)document.querySelectorAll('table.reg').forEach(t=>t.closest('details').open=true)}
if(kf){kf.addEventListener('change',filt);rq.addEventListener('input',filt)}
"""

PAGE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Activation Demo</title>
<style>__CSS__</style>
<!--brand:css--><!--/brand:css-->
</head><body data-app="activation">
<header class="bar"><div class="bar-in"><!--brand:logo--><!--/brand:logo--><div class="mark"><b>Source-to-semantic activation</b><span>Wealth management reference model</span></div><div class="asof">As of __ASOF__ &middot; slice __SLICE__</div></div></header>
<div class="layout"><nav class="side" aria-label="Sections">
<a href="#overview">Overview<small>the claim and the states</small></a><a href="#map">Map<small>sources to the taxonomy</small></a><a href="#compile">Compile<small>tables, proof, tests, SQL</small></a>
<a href="#ask">Ask<small>answers with lineage</small></a><a href="#findings">Findings<small>CW-275 to CW-280</small></a></nav>
<main>__BODY__</main></div>
<script>__JS__</script>
</body></html>"""


def build():
    """Reads the inputs, precomputes the answers, renders and brands the page, writes it."""
    d = load_inputs()
    missing = [k for k in ("slice", "coverage", "physical_report", "derivation_report", "test_results", "compiled_model", "activation", "truths") if d[k] is None]
    if missing:
        raise SystemExit(f"not built: {', '.join(missing)}; run activation/compile/build_all.py first")
    answers = precompute(query.load())
    body = s_overview(d) + s_map(d) + s_compile(d) + s_ask(d, answers) + s_findings()
    page = (PAGE.replace("__CSS__", CSS).replace("__JS__", JS).replace("__ASOF__", e(config.AS_OF)).replace("__SLICE__", e(" + ".join(config.SLICE))).replace("__BODY__", body))
    page = brand.apply(page)
    with open(OUT_HTML, "w", encoding="utf-8") as f:
        f.write(page)
    print(f"wrote {os.path.relpath(OUT_HTML, REPO)} ({os.path.getsize(OUT_HTML) / 1024:,.0f} KB); answers {sum(1 for a in answers if a[2]['answerable'])} answered, "
          f"{sum(1 for a in answers if not a[2]['answerable'])} declined; eval files {len(d['evals'])}; dbt {'yes' if os.path.isdir(os.path.join(OUT, 'dbt')) else 'no'}")
    return answers


if __name__ == "__main__":
    for q, kw, r in build():
        first = r["rows"][0] if r["rows"] else None
        print(f"  {r['metric']}: " + (", ".join(f"{k}={fmt(v, r['metric'] if k == r['metric'] else '')}" for k, v in first.items()) if first else f"declined ({r.get('reason')})"))
