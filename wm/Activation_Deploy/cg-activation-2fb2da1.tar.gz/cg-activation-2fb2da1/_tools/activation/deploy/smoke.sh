#!/usr/bin/env bash
# Smoke test of a deployed activation demo: the app answers, the build states are present, a certified metric runs,
# the assistant is Claude, and a demo question answers. Run on the instance, or from anywhere with the URL and the
# basic-auth credentials.
#
#   smoke.sh [http://host/] [user:password]        default http://127.0.0.1:8765/ with no auth (on the instance)
set -euo pipefail
BASE=${1:-http://127.0.0.1:8765/}; BASE=${BASE%/}
AUTH=${2:-}
c() { curl -fsS -m 300 ${AUTH:+-u "$AUTH"} "$@"; }
py() { python3 -c "$@" 2>/dev/null || /opt/cg-activation/venv/bin/python -c "$@"; }

echo "== state"
c "$BASE/api/state" | py 'import json,sys; d=json.load(sys.stdin); a=d.get("assistant") or {}; s=d.get("summary") or {}
print(f"runtime {d.get(\"runtime\")}; as of {d.get(\"as_of\")}; assistant: {a.get(\"label\")} (available: {a.get(\"available\")})")
print(f"states: metrics {s.get(\"metrics\")}; questions {s.get(\"questions\")}; tests {s.get(\"tests\")} ({s.get(\"test_failures\")} with failing rows); {s.get(\"cannot_answer\")} declined")'

echo "== metrics"
c "$BASE/api/metrics" | py 'import json,sys; m=json.load(sys.stdin)["metrics"]; ins=[x for x in m if x.get("in_scope")]; print(f"{sum(1 for x in ins if x.get(\"state\")==\"enabled\")} of {len(ins)} in-scope metrics answer")'

echo "== query: Client Assets by channel (certified; the total must match the proof)"
c "$BASE/api/query" -H 'Content-Type: application/json' -d '{"metric":"Client Assets","by":["distribution_channel.channel_name"]}' \
  | py 'import json,sys; d=json.load(sys.stdin); rows=d.get("rows") or []
vals=[(r[-1] if isinstance(r,list) else [v for k,v in r.items() if k=="Client Assets" or k==list(r)[-1]][-1]) for r in rows]
print(f"{len(rows)} rows; total {sum(float(v or 0) for v in vals):,.2f}; lineage: {bool(d.get(\"lineage\"))}")'

echo "== ask: a demo question (verified plan; no model call)"
c "$BASE/api/ask" -H 'Content-Type: application/json' -d '{"question":"How many funded accounts does each channel have?"}' \
  | py 'import json,sys; d=json.load(sys.stdin); print("error:", d["error"]) if d.get("error") else print(f"assistant: {d.get(\"assistant\")}; router: {d.get(\"router\")}; metric: {d.get(\"metric\") or (d.get(\"plan\") or {}).get(\"metric\")}; rows: {len(d.get(\"rows\") or [])}")'
echo "== done"
