# Source mapping registry standard

A **mapping module** (`mapping/map_<source>.py`) records how one source system's tables, columns and code values map to
the taxonomy. It is the first link of the operating model ("sources are mapped to its attributes") and the input the
compiler turns into physical tables, tests, access rules and the semantic model. The AI mapping assistant
(`propose.py`) writes a proposal in the same shape; a steward's confirmed version is the module.

Targets are always taxonomy names, never product or semantic names: `(domain, object, attribute)` exactly as the content
modules spell them. The compiler finds the logical entity that holds the object.

## Module fields

```python
SOURCE = dict(id="SRC-BRK", name="Brokerage Clearing Platform", kind="System of record",
              identifier_schemes={                 # source key column -> the taxonomy identifier scheme it issues
                  "ACCT_NO": ("15", "Account Identifier Scheme", "Brokerage Account Number"),
                  "CUST_NO": ("02", "Identifier Scheme", "Brokerage Customer Number")})

OBJECTS = [                                       # which taxonomy object each source table populates (one table may feed several)
    ("ACCT_MASTER", ("15", "Account"), "one row per account; the version in force at extract time"),
]

ATTRIBUTES = [                                    # (source table, source column, target, kind, detail)
    ("ACCT_MASTER", "OPEN_DT", ("15", "Account", "Account Open Date"), "direct", "YYYYMMDD to ISO 8601"),
    ("ACCT_MASTER", "ACCT_NO", ("15", "Account Identifier", "Account Identifier Value"), "identifier", "ACCT_NO"),
    ("ACCT_MASTER", "REG_CD", ("15", "Account", "Account Registration Type"), "crosswalk", "REG_CD"),
    ("ACCT_MASTER", "", ("15", "Account", "Carrying Entity"), "constant", "LE-BD"),
    ("ACCT_MASTER", "STATUS_CD", ("15", "Account", "Account Close Date"), "derived", "CLOSE_DT when STATUS_CD = 'C'"),
    ("ACCT_MASTER", "", ("15", "Account", "Account Purpose"), "unmapped", "the platform holds no purpose; CRM may"),
]

CROSSWALKS = {                                    # source code value -> taxonomy code value (None = no equivalent, a gap)
    "REG_CD": dict(target=("15", "Account Registration Type"), values=[
        ("IND", "Individual", ""), ("JTWROS", "Joint Tenants (JTWROS)", ""), ("529", None, "529 plans are carried by the plan sponsor"),
    ]),
}
```

## Mapping kinds

| kind | meaning | detail |
|---|---|---|
| `direct` | the column is the attribute, after type conversion only | conversion note, optional |
| `identifier` | the column is a source-issued identifier; it lands in the identifier entity under its scheme and resolves to the enterprise key | the key of `SOURCE.identifier_schemes` |
| `crosswalk` | the column's code values translate through a crosswalk | the key of `CROSSWALKS` |
| `derived` | computed from columns of the same source table | a short SQL expression over the table's columns |
| `constant` | the same value for every row of the table | the value |
| `unmapped` | the attribute is a product input the source cannot supply | the reason (a gap) |

A target may be fed by more than one source (the compiler takes the row from the system of record named in `OBJECTS`
first). A source column may feed more than one target. A `Reference (...)` attribute is mapped as `identifier` when the
column carries the source's own key for the referenced object; the compiler resolves it through that object's
identifier entity.

## Rules

1. Every target must exist in the consolidated taxonomy; every crosswalk target value must be a value of the named
   code list (or `None`); every identifier scheme must be a value of the scheme's code list.
2. Every source table and column named must exist in `sources/schema.py` (the source's data dictionary).
3. Map at the grain of the source table: a table that is `one row per account` maps to objects whose grain is the
   account, not to the account's positions.
4. Do not invent values. A code with no taxonomy equivalent is `None` with a note; the compiler reports it as a gap and
   the data-quality tests fail the rows that carry it.
5. Personal data stays personal: the mapping carries the taxonomy's PII tier through; it never maps a PII column to a
   non-PII attribute.

## Validation and coverage

`python activation/mapping/check_mapping.py` (from `_tools/`) validates every module, then reports coverage against
the slice (`activation/out/slice.json`): per entity the attributes mapped, the slice-read attributes mapped, the CDEs
unmapped; per product whether it is **enabled** (every attribute the slice reads is mapped, or the product derives
from enabled products), **partial** (with the missing attributes named) or **not started**; every `None` crosswalk
value and every `unmapped` row as a gap. It writes `activation/out/coverage.json`.
