"""Validates the mapping modules (mapping/map_*.py) against the taxonomy and the source schema, then reports coverage
of the activation slice. See CONTRACT.md.

Usage (from _tools/):  python activation/mapping/check_mapping.py [--quiet]
Writes activation/out/coverage.json.
"""
import importlib, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import _paths  # noqa: E402,F401
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(_paths.HERE, "sources"))
import slice as sl  # noqa: E402
import config  # noqa: E402
from schema import SOURCES  # noqa: E402

KINDS = {"direct", "identifier", "crosswalk", "derived", "constant", "unmapped"}


def load_mappings():
    mods = {}
    for f in sorted(os.listdir(HERE)):
        if f.startswith("map_") and f.endswith(".py"):
            m = importlib.import_module(f[:-3])
            mods[m.SOURCE["id"]] = m
    return mods


def list_values(cl, dom, name):
    vals = cl.get((dom, name)) or cl.get((dom, "Shared: " + name))
    return None if vals is None else {v[0] for v in vals}


def validate(mods, objs, cl):
    errs = []
    for sid, m in mods.items():
        src = SOURCES.get(sid)
        if not src:
            errs.append(f"{sid}: not a source in sources/schema.py"); continue
        cols = {t: {c[0] for c in d["columns"]} for t, d in src["tables"].items()}
        for key, sch in m.SOURCE.get("identifier_schemes", {}).items():
            dom, lname, value = sch[0], sch[1], sch[2]
            vals = list_values(cl, dom, lname)
            if vals is None:
                errs.append(f"{sid}: identifier scheme {key}: {dom} has no code list '{lname}'")
            elif value is None and (len(sch) < 4 or not sch[3]):
                errs.append(f"{sid}: identifier scheme {key}: a scheme with no taxonomy value needs a gap note")
            elif value is not None and value not in vals:
                errs.append(f"{sid}: identifier scheme {key}: '{value}' is not a value of {dom} {lname}")
        for g in getattr(m, "GAPS", []):
            if not (isinstance(g, (list, tuple)) and len(g) == 2 and g[1]):
                errs.append(f"{sid}: GAPS entries are (source table or '', reason): {g!r}")
        for t, obj, _ in m.OBJECTS:
            if t not in cols:
                errs.append(f"{sid}: OBJECTS names table {t} that the source does not have")
            if tuple(obj) not in objs:
                errs.append(f"{sid}: OBJECTS: {obj} is not a taxonomy object")
        for name, cw in m.CROSSWALKS.items():
            dom, lname = cw["target"]
            vals = list_values(cl, dom, lname)
            if vals is None:
                errs.append(f"{sid}: crosswalk {name}: {dom} has no code list '{lname}'"); continue
            for sv, tv, _ in cw["values"]:
                if tv is not None and tv not in vals:
                    errs.append(f"{sid}: crosswalk {name}: '{tv}' is not a value of {dom} {lname}")
        tables_seen = set()
        for row in m.ATTRIBUTES:
            if len(row) != 5:
                errs.append(f"{sid}: ATTRIBUTES row has {len(row)} fields: {row!r}"); continue
            t, col, target, kind, detail = row
            tables_seen.add(t)
            if t not in cols:
                errs.append(f"{sid}: {t}.{col}: table not in the source"); continue
            if kind not in KINDS:
                errs.append(f"{sid}: {t}.{col}: kind '{kind}' is not one of {sorted(KINDS)}")
            if kind in ("direct", "identifier", "crosswalk") and col not in cols[t]:
                errs.append(f"{sid}: {t}.{col}: column not in the source table")
            if kind in ("constant", "unmapped") and col:
                errs.append(f"{sid}: {t}.{col}: a {kind} row names no source column")
            if kind == "derived" and not detail:
                errs.append(f"{sid}: {t} -> {target}: derived row needs an expression")
            if kind == "identifier" and detail not in m.SOURCE.get("identifier_schemes", {}):
                errs.append(f"{sid}: {t}.{col}: identifier scheme '{detail}' is not declared in SOURCE")
            if kind == "crosswalk" and detail not in m.CROSSWALKS:
                errs.append(f"{sid}: {t}.{col}: crosswalk '{detail}' is not defined")
            if kind == "unmapped" and not detail:
                errs.append(f"{sid}: {t} -> {target}: unmapped row needs a reason")
            dom, obj, attr = target
            if (dom, obj) not in objs:
                errs.append(f"{sid}: {t}.{col}: target object {(dom, obj)} is not in the taxonomy")
            elif attr not in objs[(dom, obj)]["attrs"]:
                errs.append(f"{sid}: {t}.{col}: '{attr}' is not an attribute of {(dom, obj)}")
            else:
                a = objs[(dom, obj)]["attrs"][attr]
                if kind == "crosswalk" and detail in m.CROSSWALKS:
                    cdom, cname = m.CROSSWALKS[detail]["target"]
                    aname = a["code_list"].replace("Shared: ", "")
                    same = (cname == aname) and (cdom == dom or a["code_list"].startswith("Shared: "))
                    if not same:
                        errs.append(f"{sid}: {t}.{col}: crosswalk {detail} targets {m.CROSSWALKS[detail]['target']} but the attribute's list is {dom} {a['code_list']}")
            if not any(tt == t and tuple(oo) == (dom, obj) for tt, oo, _ in m.OBJECTS):
                errs.append(f"{sid}: {t}.{col}: maps to {(dom, obj)} but OBJECTS does not say {t} populates it")
    return errs


def coverage(mods, s):
    """Per entity and product, what the confirmed mappings enable."""
    mapped = {}                                  # (dom, obj, attr) -> [(source, table, column, kind)]
    gaps = []
    for sid, m in mods.items():
        for t, col, target, kind, detail in m.ATTRIBUTES:
            if kind == "unmapped":
                gaps.append(dict(source=sid, table=t, target=list(target), kind="unmapped", note=detail)); continue
            mapped.setdefault(tuple(target), []).append(dict(source=sid, table=t, column=col, kind=kind, detail=detail))
        for name, cw in m.CROSSWALKS.items():
            for sv, tv, note in cw["values"]:
                if tv is None:
                    gaps.append(dict(source=sid, crosswalk=name, value=sv, target=list(cw["target"]), kind="no_equivalent", note=note))
        for key, sch in m.SOURCE.get("identifier_schemes", {}).items():
            if sch[2] is None:
                gaps.append(dict(source=sid, scheme=key, target=list(sch[:2]), kind="no_identifier_scheme", note=sch[3]))
        for t, note in getattr(m, "GAPS", []):
            gaps.append(dict(source=sid, table=t, kind="declared", note=note))
    derived = getattr(config, "DERIVED_PRODUCTS", {})
    ents, prods = {}, {}
    for key, e in s["entities"].items():
        rows = []
        for a in e["attrs"]:
            tgt = tuple(a["taxonomy"] + [a["name"]]) if a["taxonomy"] else None
            srcs = mapped.get(tgt, []) if tgt else []
            rows.append(dict(name=a["name"], used=a["name"] in e["used"], pk=a["pk"], cde=a["cde"], pii=a["pii"],
                             derived=a["derived"], mapped=bool(srcs), sources=srcs))
        pid = e["product"]
        is_derived = pid in derived
        used = [r for r in rows if r["used"] or r["pk"]]
        missing = [r["name"] for r in used if not r["mapped"] and not r["derived"]]
        ents[key] = dict(product=pid, entity=e["entity"], derived_product=is_derived, attrs=len(rows),
                         mapped=sum(r["mapped"] for r in rows), used=len(used), used_mapped=sum(r["mapped"] for r in used),
                         cde_unmapped=[r["name"] for r in rows if r["cde"] and not r["mapped"] and not r["derived"]],
                         missing=missing, rows=rows)
        prods.setdefault(pid, []).append(key)
    state = {}
    def product_state(pid, seen=()):
        if pid in state:
            return state[pid]
        if pid in derived:
            ups = [u for u in derived[pid] if u in prods or u in derived]
            st = "enabled" if all(product_state(u, seen + (pid,)) == "enabled" for u in ups if u not in seen) else "partial"
            state[pid] = dict(state=st, derived_from=derived[pid], missing=[]); return state[pid]
        keys = prods.get(pid, [])
        missing = [f"{ents[k]['entity']}: {', '.join(ents[k]['missing'])}" for k in keys if ents[k]["missing"]]
        any_mapped = any(ents[k]["mapped"] for k in keys)
        st = "enabled" if not missing else ("partial" if any_mapped else "not started")
        state[pid] = dict(state=st, derived_from=[], missing=missing); return state[pid]
    for pid in list(prods) + list(derived):
        product_state(pid)
    products = {pid: dict(id=pid, name=s["products"].get(pid, {}).get("name", ""), tier=s["products"].get(pid, {}).get("tier", ""),
                          entities=prods.get(pid, []), **state[pid]) for pid in state}
    # Metric estimate: a metric looks mappable when every entity its tables read has its keys mapped (or derives from
    # products whose sources are at least partly mapped). The compiler proves answerability on the built tables.
    def entity_ok(key):
        e = ents[key]
        if e["derived_product"]:
            return all(state.get(u, {}).get("state") in ("enabled", "partial") for u in derived[e["product"]])
        return bool(e["mapped"]) and all(r["mapped"] or r["derived"] for r in e["rows"] if r["pk"])
    metrics = []
    for m in s["metrics"]:
        if "ref" in m or not m["in_scope"]:
            continue
        keys = [s["tables"][f"{m['model']}.{t}"]["entity_key"] for t in m["tables_read"] if f"{m['model']}.{t}" in s["tables"]]
        pids = sorted({k.split("/")[0] for k in keys})
        metrics.append(dict(model=m["model"], name=m["name"], products=pids, entities=keys,
                            mappable=bool(keys) and all(entity_ok(k) for k in keys)))
    return dict(entities=ents, products=products, metrics=metrics, gaps=gaps,
                mapped_targets=len(mapped), sources=sorted(mods))


def main(quiet=False):
    models, logical, specs, objs = sl.load()
    cl = sl.code_lists()
    mods = load_mappings()
    if not mods:
        raise SystemExit("no mapping modules in activation/mapping/")
    errs = validate(mods, objs, cl)
    for e in errs:
        print("ERROR", e)
    path = os.path.join(_paths.OUT, "slice.json")
    if not os.path.exists(path):
        raise SystemExit("run activation/slice.py first")
    s = json.load(open(path))
    cov = coverage(mods, s)
    with open(os.path.join(_paths.OUT, "coverage.json"), "w") as f:
        json.dump(cov, f, indent=1, ensure_ascii=False)
    n_attr = sum(len(m.ATTRIBUTES) for m in mods.values())
    print(f"{len(mods)} mapping module(s), {n_attr} attribute rows, {cov['mapped_targets']} taxonomy attributes mapped, "
          f"{len(errs)} error(s)")
    if not quiet:
        print("\nProducts:")
        for p in sorted(cov["products"].values(), key=lambda p: (p["tier"] != "Foundational", p["id"])):
            tag = p["state"].upper()
            extra = f" <- {', '.join(p['derived_from'])}" if p["derived_from"] else ""
            print(f"  {tag:12s} {p['id']} {p['name']}{extra}")
            for mline in p["missing"][:6]:
                print(f"               missing {mline[:160]}")
        print("\nEntities (used attributes mapped / used; CDEs unmapped):")
        for k, e in cov["entities"].items():
            if e["derived_product"]:
                continue
            print(f"  {k:42s} {e['used_mapped']:3d}/{e['used']:<3d} of {e['attrs']:3d}   CDE unmapped: {', '.join(e['cde_unmapped'][:8])}")
        ans = [m for m in cov["metrics"] if m["mappable"]]
        print(f"\nMetrics mappable (estimate; the compiler proves answerability): {len(ans)} of {len(cov['metrics'])}")
        for m in cov["metrics"]:
            if not m["mappable"]:
                print(f"  not yet: {m['model']} {m['name']} ({', '.join(m['products'])})")
        print(f"\nGaps: {len(cov['gaps'])}")
        for g in cov["gaps"][:40]:
            print("  ", {k: v for k, v in g.items()})
    return 1 if errs else 0


if __name__ == "__main__":
    sys.exit(main(quiet="--quiet" in sys.argv))
