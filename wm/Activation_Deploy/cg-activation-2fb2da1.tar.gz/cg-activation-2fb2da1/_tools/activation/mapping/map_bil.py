"""Confirmed mapping of SRC-BIL, the advisory fee billing engine, to the taxonomy. See CONTRACT.md.

The engine is the system of record for client fee billing of the brokerage platform's enrolled accounts (47): fee
schedule versions, fee households and their member accounts, the assignment of a schedule version to each enrolled
account, the quarterly calculation runs, one calculation per run and assignment, waivers and the debits that collect
the fees. Schedule tiers have no entity in the slice; the compiler reads SCHEDULE_TIER directly to re-perform fees.
Enterprise keys: FS-<schedule version>, FH-<fee group>, FSA-<assignment>, FR-<run>, FW-<waiver>, FD-<debit>; a
calculation is FR-<run>|FSA-<assignment> (its two key parts joined by '|'). Accounts are ACC-BRK-<account number>,
enrollments ENRL-BRK-<account number>, CRM households PTY-HH-<Id>, approvers EMP-<employee number of the CRM user>.
"""

SOURCE = dict(
    id="SRC-BIL", name="Advisory Fee Billing Engine", kind="System of record for client fee billing",
    identifier_schemes={})

OBJECTS = [
    ("SCHEDULE", ("47", "Fee Schedule"), "one row per fee schedule version"),
    ("SCHEDULE", ("47", "Performance Fee Terms"), "none: the engine bills no performance fees"),
    ("FEE_GROUP", ("47", "Fee Household"), "one row per fee group"),
    ("FEE_GROUP_MBR", ("47", "Fee Household Membership"), "one row per group x account x effective period"),
    ("ASSIGNMENT", ("47", "Fee Schedule Assignment"), "one row per assignment (SCD 2 by schedule version)"),
    ("FEE_RUN", ("47", "Fee Calculation Run"), "one row per run"),
    ("FEE_CALC", ("47", "Account Fee Calculation"), "one row per run x assignment"),
    ("WAIVER", ("47", "Fee Waiver"), "one row per waiver"),
    ("DEBIT", ("47", "Fee Debit"), "one row per debit"),
]

ATTRIBUTES = [
    # SCHEDULE -> 47 Fee Schedule / Performance Fee Terms
    ("SCHEDULE", "SCHED_ID", ("47", "Fee Schedule", "Fee Schedule ID"), "derived", "'FS-' || SCHED_ID"),
    ("SCHEDULE", "SCHED_NM", ("47", "Fee Schedule", "Fee Schedule Name"), "direct", ""),
    ("SCHEDULE", "SCHED_TYPE_CD", ("47", "Fee Schedule", "Fee Schedule Type"), "crosswalk", "SCHED_TYPE_CD"),
    ("SCHEDULE", "VERSION_NO", ("47", "Fee Schedule", "Schedule Version Number"), "direct", ""),
    ("SCHEDULE", "STATUS_CD", ("47", "Fee Schedule", "Schedule Status"), "crosswalk", "SCHED_STATUS_CD"),
    ("SCHEDULE", "EFF_FROM_DT", ("47", "Fee Schedule", "Version Effective From"), "direct", ""),
    ("SCHEDULE", "EFF_TO_DT", ("47", "Fee Schedule", "Version Effective To"), "direct", "blank while current"),
    ("SCHEDULE", "BASIS_CD", ("47", "Fee Schedule", "Billing Basis"), "crosswalk", "BASIS_CD"),
    ("SCHEDULE", "TIER_METHOD_CD", ("47", "Fee Schedule", "Tier Method"), "crosswalk", "TIER_METHOD_CD"),
    ("SCHEDULE", "BILL_FREQ_CD", ("47", "Fee Schedule", "Default Billing Frequency"), "crosswalk", "BILL_FREQ_CD"),
    ("SCHEDULE", "BILL_TIMING_CD", ("47", "Fee Schedule", "Default Billing Timing"), "crosswalk", "BILL_TIMING_CD"),
    ("SCHEDULE", "MIN_ANNUAL_FEE", ("47", "Fee Schedule", "Minimum Annual Fee"), "direct", "0 when none"),
    ("SCHEDULE", "MAX_RATE_BPS", ("47", "Fee Schedule", "Maximum Fee Rate"), "direct", "basis points; the top tier"),
    ("SCHEDULE", "OWN_FUND_CD", ("47", "Fee Schedule", "Own-Fund Treatment"), "crosswalk", "OWN_FUND_CD"),
    ("SCHEDULE", "ADV_REF", ("47", "Fee Schedule", "Form ADV Disclosure Reference"), "direct", ""),
    ("SCHEDULE", "PRIOR_SCHED_ID", ("47", "Fee Schedule", "Superseded Schedule Version"), "derived", "'FS-' || PRIOR_SCHED_ID"),
    ("SCHEDULE", "", ("47", "Fee Schedule", "Schedule Approved By"), "unmapped", "the engine does not record schedule approvals"),
    ("SCHEDULE", "", ("47", "Performance Fee Terms", "Performance Fee Rate"), "unmapped", "the engine bills no performance fees"),
    ("SCHEDULE", "", ("47", "Performance Fee Terms", "Hurdle Type"), "unmapped", "the engine bills no performance fees"),
    ("SCHEDULE", "", ("47", "Performance Fee Terms", "High-Water Mark Indicator"), "unmapped", "the engine bills no performance fees"),
    ("SCHEDULE", "", ("47", "Performance Fee Terms", "Crystallization Frequency"), "unmapped", "the engine bills no performance fees"),
    ("SCHEDULE", "", ("47", "Performance Fee Terms", "Performance Fee Basis"), "unmapped", "the engine bills no performance fees"),
    # FEE_GROUP -> 47 Fee Household
    ("FEE_GROUP", "GROUP_ID", ("47", "Fee Household", "Fee Household ID"), "derived", "'FH-' || GROUP_ID"),
    ("FEE_GROUP", "CRM_HH_ID", ("47", "Fee Household", "Anchor Client Household"), "derived", "'PTY-HH-' || CRM_HH_ID (null for an entity group)"),
    ("FEE_GROUP", "BASIS_CD", ("47", "Fee Household", "Formation Basis"), "crosswalk", "GROUP_BASIS_CD"),
    ("FEE_GROUP", "STATUS_CD", ("47", "Fee Household", "Fee Household Status"), "crosswalk", "GROUP_STATUS_CD"),
    ("FEE_GROUP", "EFF_FROM_DT", ("47", "Fee Household", "Fee Household Effective From"), "direct", ""),
    ("FEE_GROUP", "EFF_TO_DT", ("47", "Fee Household", "Fee Household Effective To"), "direct", "blank while active"),
    ("FEE_GROUP", "", ("47", "Fee Household", "Fee Household Name"), "unmapped", "the engine keeps no group name"),
    # FEE_GROUP_MBR -> 47 Fee Household Membership
    ("FEE_GROUP_MBR", "GROUP_ID", ("47", "Fee Household Membership", "Membership Fee Household"), "derived", "'FH-' || GROUP_ID"),
    ("FEE_GROUP_MBR", "ACCT_NO", ("47", "Fee Household Membership", "Member Account"), "derived", "'ACC-BRK-' || ACCT_NO"),
    ("FEE_GROUP_MBR", "BASIS_CD", ("47", "Fee Household Membership", "Inclusion Basis"), "crosswalk", "GROUP_BASIS_CD"),
    ("FEE_GROUP_MBR", "STATUS_CD", ("47", "Fee Household Membership", "Fee Household Membership Status"), "crosswalk", "MBR_STATUS_CD"),
    ("FEE_GROUP_MBR", "EFF_FROM_DT", ("47", "Fee Household Membership", "Fee Household Membership Effective From"), "direct", ""),
    ("FEE_GROUP_MBR", "EFF_TO_DT", ("47", "Fee Household Membership", "Fee Household Membership Effective To"), "direct", "blank while active"),
    # ASSIGNMENT -> 47 Fee Schedule Assignment
    ("ASSIGNMENT", "ASSIGN_ID", ("47", "Fee Schedule Assignment", "Fee Schedule Assignment ID"), "derived", "'FSA-' || ASSIGN_ID"),
    ("ASSIGNMENT", "ACCT_NO", ("47", "Fee Schedule Assignment", "Billed Enrollment"), "derived",
     "case when PROGRAM_CD in ('DAP', 'PAS', 'WMP', 'TRS') then 'ENRL-BRK-' || ACCT_NO end"),
    ("ASSIGNMENT", "ACCT_NO", ("47", "Fee Schedule Assignment", "Billed Account"), "derived",
     "case when PROGRAM_CD is null then 'ACC-BRK-' || ACCT_NO end"),
    ("ASSIGNMENT", "", ("47", "Fee Schedule Assignment", "Billed Advice Engagement"), "unmapped", "the engine bills program enrollments, not advice engagements"),
    ("ASSIGNMENT", "SCHED_ID", ("47", "Fee Schedule Assignment", "Assigned Fee Schedule"), "derived", "'FS-' || SCHED_ID"),
    ("ASSIGNMENT", "PAY_ACCT_NO", ("47", "Fee Schedule Assignment", "Fee-Paying Account"), "derived", "'ACC-BRK-' || PAY_ACCT_NO"),
    ("ASSIGNMENT", "COLLECT_CD", ("47", "Fee Schedule Assignment", "Fee Collection Method"), "crosswalk", "COLLECT_CD"),
    ("ASSIGNMENT", "BILL_TIMING_CD", ("47", "Fee Schedule Assignment", "Billing Timing"), "crosswalk", "BILL_TIMING_CD"),
    ("ASSIGNMENT", "BILL_FREQ_CD", ("47", "Fee Schedule Assignment", "Billing Frequency"), "crosswalk", "BILL_FREQ_CD"),
    ("ASSIGNMENT", "GROUP_ID", ("47", "Fee Schedule Assignment", "Assigned Fee Household"), "derived", "'FH-' || GROUP_ID (null when no group)"),
    ("ASSIGNMENT", "NEGOTIATED_FLG", ("47", "Fee Schedule Assignment", "Negotiated Rate Indicator"), "direct", ""),
    ("ASSIGNMENT", "EFF_FROM_DT", ("47", "Fee Schedule Assignment", "Assignment Effective From"), "direct", ""),
    ("ASSIGNMENT", "EFF_TO_DT", ("47", "Fee Schedule Assignment", "Assignment Effective To"), "direct", "blank while current"),
    # FEE_RUN -> 47 Fee Calculation Run
    ("FEE_RUN", "RUN_ID", ("47", "Fee Calculation Run", "Fee Calculation Run ID"), "derived", "'FR-' || RUN_ID"),
    ("FEE_RUN", "PERIOD_START_DT", ("47", "Fee Calculation Run", "Run Billing Period Start"), "direct", ""),
    ("FEE_RUN", "PERIOD_END_DT", ("47", "Fee Calculation Run", "Run Billing Period End"), "direct", ""),
    ("FEE_RUN", "RUN_TYPE_CD", ("47", "Fee Calculation Run", "Run Type"), "crosswalk", "RUN_TYPE_CD"),
    ("FEE_RUN", "VAL_DT", ("47", "Fee Calculation Run", "Valuation As-Of Date"), "direct", ""),
    ("FEE_RUN", "", ("47", "Fee Calculation Run", "Calculation Engine"), "constant", "Advisory Fee Billing Engine"),
    ("FEE_RUN", "STATUS_CD", ("47", "Fee Calculation Run", "Run Status"), "crosswalk", "RUN_STATUS_CD"),
    ("FEE_RUN", "RECON_CD", ("47", "Fee Calculation Run", "Fee Reconciliation Status"), "crosswalk", "RECON_CD"),
    ("FEE_RUN", "NET_FEE_TOTAL", ("47", "Fee Calculation Run", "Run Net Fee Total"), "direct", "the engine's control total"),
    ("FEE_RUN", "APPROVED_BY", ("47", "Fee Calculation Run", "Run Approved By"), "derived", "'EMP-' || Employee_Number__c of the CRM User APPROVED_BY"),
    # FEE_CALC -> 47 Account Fee Calculation
    ("FEE_CALC", "RUN_ID", ("47", "Account Fee Calculation", "Calculation Run"), "derived", "'FR-' || RUN_ID"),
    ("FEE_CALC", "ASSIGN_ID", ("47", "Account Fee Calculation", "Calculated Assignment"), "derived", "'FSA-' || ASSIGN_ID"),
    ("FEE_CALC", "", ("47", "Account Fee Calculation", "Calculated Billing Arrangement"), "unmapped", "billing arrangements are institutional; this engine bills assignments only"),
    ("FEE_CALC", "SCHED_ID", ("47", "Account Fee Calculation", "Schedule Version Applied"), "derived", "'FS-' || SCHED_ID"),
    ("FEE_CALC", "ACCT_VALUE", ("47", "Account Fee Calculation", "Account Valuation"), "direct", ""),
    ("FEE_CALC", "BILLABLE_ASSETS", ("47", "Account Fee Calculation", "Billable Assets"), "direct", ""),
    ("FEE_CALC", "GROUP_ASSETS", ("47", "Account Fee Calculation", "Fee Household Assets"), "direct", "blank when no group applied"),
    ("FEE_CALC", "RATE_BPS", ("47", "Account Fee Calculation", "Effective Annual Rate"), "direct", "basis points"),
    ("FEE_CALC", "PRORATE_DAYS", ("47", "Account Fee Calculation", "Pro-Ration Days"), "direct", "blank for a full period"),
    ("FEE_CALC", "GROSS_FEE", ("47", "Account Fee Calculation", "Gross Fee"), "direct", ""),
    ("FEE_CALC", "DISCOUNT_AMT", ("47", "Account Fee Calculation", "Discount Amount"), "direct", ""),
    ("FEE_CALC", "WAIVER_IDS", ("47", "Account Fee Calculation", "Waivers Applied"), "derived", "'FW-' || replace(WAIVER_IDS, '; ', '; FW-')"),
    ("FEE_CALC", "WAIVER_AMT", ("47", "Account Fee Calculation", "Waiver Amount Applied"), "direct", ""),
    ("FEE_CALC", "OWN_FUND_CREDIT", ("47", "Account Fee Calculation", "Own-Fund Credit Amount"), "direct", ""),
    ("FEE_CALC", "NET_FEE", ("47", "Account Fee Calculation", "Net Fee"), "direct", ""),
    ("FEE_CALC", "EXCEPTION_FLG", ("47", "Account Fee Calculation", "Exception Indicator"), "direct", ""),
    # WAIVER -> 47 Fee Waiver
    ("WAIVER", "WAIVER_ID", ("47", "Fee Waiver", "Fee Waiver ID"), "derived", "'FW-' || WAIVER_ID"),
    ("WAIVER", "ASSIGN_ID", ("47", "Fee Waiver", "Waived Assignment"), "derived", "'FSA-' || ASSIGN_ID"),
    ("WAIVER", "", ("47", "Fee Waiver", "Waived Billing Arrangement"), "unmapped", "waivers name assignments; no institutional billing arrangements here"),
    ("WAIVER", "REASON_CD", ("47", "Fee Waiver", "Waiver Reason"), "crosswalk", "REASON_CD"),
    ("WAIVER", "PCT", ("47", "Fee Waiver", "Waiver Percentage"), "direct", "percent; blank for an amount waiver"),
    ("WAIVER", "AMT", ("47", "Fee Waiver", "Waiver Amount"), "direct", "blank for a percentage waiver"),
    ("WAIVER", "START_DT", ("47", "Fee Waiver", "Waiver Period Start"), "direct", ""),
    ("WAIVER", "END_DT", ("47", "Fee Waiver", "Waiver Period End"), "direct", "blank while open"),
    ("WAIVER", "APPROVED_BY", ("47", "Fee Waiver", "Waiver Approved By"), "derived", "'EMP-' || Employee_Number__c of the CRM User APPROVED_BY"),
    # DEBIT -> 47 Fee Debit
    ("DEBIT", "DEBIT_ID", ("47", "Fee Debit", "Fee Debit ID"), "derived", "'FD-' || DEBIT_ID"),
    ("DEBIT", "RUN_ID", ("47", "Fee Debit", "Debited Calculation"), "derived", "'FR-' || RUN_ID || '|FSA-' || ASSIGN_ID"),
    ("DEBIT", "FEE_TYPE_CD", ("47", "Fee Debit", "Charged Fee Type"), "crosswalk", "SCHED_TYPE_CD"),
    ("DEBIT", "ACCT_NO", ("47", "Fee Debit", "Debited Account"), "derived", "'ACC-BRK-' || ACCT_NO"),
    ("DEBIT", "AMT", ("47", "Fee Debit", "Debit Amount"), "direct", ""),
    ("DEBIT", "DEBIT_DT", ("47", "Fee Debit", "Debit Date"), "direct", ""),
    ("DEBIT", "STATUS_CD", ("47", "Fee Debit", "Fee Debit Status"), "crosswalk", "DEBIT_STATUS_CD"),
    ("DEBIT", "", ("47", "Fee Debit", "Debit Posting"), "unmapped", "the engine keeps no brokerage activity reference for the posting"),
    ("DEBIT", "FAIL_RSN", ("47", "Fee Debit", "Debit Failure Reason"), "direct", "blank unless failed"),
]

CROSSWALKS = {
    "SCHED_TYPE_CD": dict(target=("47", "Fee Schedule Type"), values=[
        ("ADV", "Asset-Based Advisory", ""), ("WRAP", "Wrap Fee", ""), ("FLAT", "Flat Fee", ""), ("SUB", "Subscription", ""),
        ("SVC", "Account Service", ""), ("TRST", "Trust Administration", "")]),
    "SCHED_STATUS_CD": dict(target=("47", "Record Status"), values=[
        ("D", "Draft", ""), ("P", "Proposed", ""), ("A", "Active", ""), ("R", "Retired", "")]),
    "BASIS_CD": dict(target=("47", "Billing Basis"), values=[
        ("ADV", "Average Daily Value", ""), ("AME", "Average Month-End Value", ""), ("PEV", "Period-End Value", ""), ("FLAT", "Flat", "")]),
    "TIER_METHOD_CD": dict(target=("47", "Tier Method"), values=[("BL", "Blended", ""), ("CL", "Cliff", ""), ("SR", "Single Rate", "")]),
    "BILL_FREQ_CD": dict(target=("47", "Frequency"), values=[("Q", "Quarterly", ""), ("M", "Monthly", ""), ("A", "Annual", "")]),
    "BILL_TIMING_CD": dict(target=("47", "Billing Timing"), values=[("ARR", "In Arrears", ""), ("ADV", "In Advance", "")]),
    "OWN_FUND_CD": dict(target=("47", "Own-Fund Treatment"), values=[
        ("EXCL", "Excluded from Billable Assets", ""), ("CRED", "Credited Against Fee", ""), ("NONE", "Billed Without Offset", "")]),
    "GROUP_BASIS_CD": dict(target=("47", "Fee Household Formation Basis"), values=[
        ("HH", "Client Household", ""), ("LINK", "Client-Requested Link", ""), ("ENT", "Entity Group", "")]),
    "GROUP_STATUS_CD": dict(target=("47", "Record Status"), values=[("A", "Active", ""), ("I", "Inactive", "")]),
    "MBR_STATUS_CD": dict(target=("47", "Record Status"), values=[
        ("A", "Active", ""), ("P", "Proposed", "awaiting the client's confirmation"), ("I", "Inactive", "")]),
    "COLLECT_CD": dict(target=("47", "Fee Collection Method"), values=[("DED", "Deducted from Account", ""), ("INV", "Invoice", "")]),
    "RUN_TYPE_CD": dict(target=("47", "Run Type"), values=[
        ("REG", "Regular", ""), ("ONB", "Onboarding Pro Rata", ""), ("TRM", "Termination Pro Rata", ""),
        ("RECALC", "Recalculation", ""), ("SIM", "Simulation", "")]),
    "RUN_STATUS_CD": dict(target=("47", "Run Status"), values=[
        ("SCH", "Scheduled", ""), ("CALC", "Calculated", ""), ("REV", "In Review", ""), ("APPR", "Approved", ""), ("REL", "Released", "")]),
    "RECON_CD": dict(target=("47", "Reconciliation Status"), values=[   # blank (a simulation) falls through to null
        ("REC", "Reconciled", ""), ("TOL", "Reconciled within Tolerance", ""), ("BRK", "Break Open", ""),
        ("EXPL", "Break Explained", ""), ("NR", "Not Reconciled", "")]),
    "REASON_CD": dict(target=("47", "Waiver Reason"), values=[
        ("PROMO", "Promotional", ""), ("SVC", "Service Recovery", ""), ("EMP", "Employee / Affiliate", ""),
        ("REL", "Relationship Concession", ""), ("OTH", "Other", "")]),
    "DEBIT_STATUS_CD": dict(target=("47", "Fee Debit Status"), values=[
        ("PEND", "Pending", ""), ("POST", "Posted", ""), ("FAIL", "Failed", ""), ("REV", "Reversed", ""), ("CANC", "Canceled", "")]),
}

GAPS = [
    ("SCHEDULE_TIER", "Schedule tiers (bounds and rates per version) have no entity in the slice (47 Fee Schedule Tier is outside SM-28's tables); the compiler reads SRC-BIL SCHEDULE_TIER directly to re-perform fees (DP-346)."),
    ("SCHEDULE", "FAMILY_CD (the schedule family a version belongs to) has no home on 47 Fee Schedule; versions chain through Superseded Schedule Version."),
    ("ASSIGNMENT", "PROGRAM_CD feeds only the choice of Billed Enrollment (ENRL-BRK-<account>, the enrollment the brokerage mapping mints); the enrollment carries the program, so it has no column of its own here."),
    ("FEE_RUN", "APPROVED_BY and WAIVER.APPROVED_BY are CRM User Ids; the EMP- key is minted from the user's Employee_Number__c, and DP-009 Employee holds advisor users only, so an approver who is not an advisor does not resolve to an Employee row."),
    ("FEE_CALC", "Account Fee Calculation is keyed by run x assignment (Calculated Billing Arrangement is null for every row); references to a calculation (Fee Debit Debited Calculation, Client Revenue Record Source Calculation Record) carry 'FR-<run>|FSA-<assignment>', the key parts joined by '|'."),
    ("DEBIT", "RUN_ID and ASSIGN_ID feed Debited Calculation; FEE_TYPE_CD repeats the schedule type of the calculation's schedule version."),
]
