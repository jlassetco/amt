"""Confirmed mapping of SRC-BRK, the brokerage clearing platform, to the taxonomy. See CONTRACT.md.

The platform is the system of record for brokerage, managed advisory and trust accounts (15), their holdings, cash
balances and activity (49), and the customers it knows (02, resolved to the CRM party where linked). Its security
master stands in for the instrument master (17, DP-097) in the demo. Enterprise keys are minted from the platform's
own numbers: ACC-BRK-<ACCT_NO>, PTY-<CRM contact Id> (or PTY-BRK-<CUST_NO> when unlinked), INS-<CUSIP>, SHC-<fund number>.
"""

SOURCE = dict(
    id="SRC-BRK", name="Brokerage Clearing Platform", kind="System of record",
    identifier_schemes={
        "ACCT_NO": ("15", "Account Identifier Scheme", "Brokerage Account Number"),
        "CUST_NO": ("02", "Identifier Scheme", None,
                    "02 Identifier Scheme has no value for a brokerage platform customer number (it lists CRM ID, "
                    "Vendor ID and regulatory schemes); proposed addition 'Brokerage Platform Customer Number'"),
        "CRM_CONTACT_ID": ("02", "Identifier Scheme", "CRM ID"),
    })

OBJECTS = [
    ("ACCT_MASTER", ("15", "Account"), "one row per account, the version in force at extract time"),
    ("ACCT_MASTER", ("15", "Account Identifier"), "the brokerage account number as an identifier of the account"),
    ("ACCT_MASTER", ("15", "Account Registration Detail"), "the registration title"),
    ("ACCT_MASTER", ("15", "Account Closure"), "closure reason of closed accounts"),
    ("ACCT_MASTER", ("15", "Account Opening"), "nothing the platform holds at account grain"),
    ("ACCT_MASTER", ("15", "Intermediary Account Servicing"), "direct accounts are not networked"),
    ("ACCT_MASTER", ("15", "Account Tax Reporting Status"), "nothing the platform extract holds"),
    ("ACCT_MASTER", ("15", "Account Party Role"), "two rows per account at most: the primary owner and the joint owner"),
    ("ACCT_MASTER", ("15", "Program Enrollment"), "one enrollment per advisory account (the current program)"),
    ("CUST_MASTER", ("02", "Party"), "one party per customer; a customer linked to a CRM contact is the same party"),
    ("CUST_MASTER", ("02", "Individual"), "name and dates of the person"),
    ("CUST_MASTER", ("02", "Party Identifier"), "the platform customer number and the CRM contact Id it carries"),
    ("CUST_MASTER", ("02", "Tax Profile"), "only the last four digits of the TIN are extracted"),
    ("SEC_MASTER", ("17", "Instrument"), "one instrument per CUSIP (stands in for the security master vendor feed)"),
    ("SEC_MASTER", ("17", "Fund Instrument Terms"), "fund vehicle and own-product link for fund instruments"),
    ("POSITIONS", ("49", "Client Holding"), "one End of Day holding per account x CUSIP x month-end"),
    ("POSITIONS", ("49", "Client Holding Valuation"), "the valuation of the same row"),
    ("CASH_BAL", ("49", "Account Cash Balance"), "one row per account x currency x balance type x basis x month-end"),
    ("ACTIVITY", ("49", "Client Account Activity"), "one posting per transaction"),
]

ATTRIBUTES = [
    # ACCT_MASTER -> 15 Account
    ("ACCT_MASTER", "ACCT_NO", ("15", "Account", "Account ID"), "derived", "'ACC-BRK-' || ACCT_NO"),
    ("ACCT_MASTER", "ACCT_NO", ("15", "Account", "External Account Number"), "direct", ""),
    ("ACCT_MASTER", "ACCT_TITLE", ("15", "Account", "Account Name"), "direct", ""),
    ("ACCT_MASTER", "ACCT_CLASS_CD", ("15", "Account", "Account Type"), "crosswalk", "ACCT_CLASS_CD"),
    ("ACCT_MASTER", "REG_CD", ("15", "Account", "Account Registration Type"), "crosswalk", "REG_CD"),
    ("ACCT_MASTER", "STATUS_CD", ("15", "Account", "Account Status"), "crosswalk", "STATUS_CD"),
    ("ACCT_MASTER", "OPEN_DT", ("15", "Account", "Account Open Date"), "direct", "YYYYMMDD to ISO 8601"),
    ("ACCT_MASTER", "CLOSE_DT", ("15", "Account", "Account Close Date"), "direct", "YYYYMMDD to ISO 8601"),
    ("ACCT_MASTER", "MARGIN_CD", ("15", "Account", "Reg T Account Type"), "crosswalk", "MARGIN_CD"),
    ("ACCT_MASTER", "CARRY_ENT_CD", ("15", "Account", "Carrying Entity"), "derived", "'LE-' || CARRY_ENT_CD"),
    ("ACCT_MASTER", "PURPOSE_CD", ("15", "Account", "Account Purpose"), "crosswalk", "PURPOSE_CD"),
    ("ACCT_MASTER", "CHANNEL_CD", ("15", "Account", "Account Business Line"), "crosswalk", "CHANNEL_CD_BL"),
    ("ACCT_MASTER", "ACCT_TITLE", ("15", "Account Registration Detail", "Registration Line 1"), "direct", ""),
    ("ACCT_MASTER", "REG_CD", ("15", "Account Registration Detail", "Entity Account Indicator"), "derived", "REG_CD in ('RTR', 'ITR', 'EST')"),
    ("ACCT_MASTER", "CLOSE_RSN_CD", ("15", "Account Closure", "Closure Reason"), "crosswalk", "CLOSE_RSN_CD"),
    ("ACCT_MASTER", "", ("15", "Intermediary Account Servicing", "Networking Level"), "constant", "Not Networked"),
    ("ACCT_MASTER", "", ("15", "Account Opening", "Application Channel"), "unmapped", "the platform keeps the onboarding channel on the customer (CUST_MASTER.ONBOARD_CHANNEL_CD), not the account"),
    ("ACCT_MASTER", "", ("15", "Account Opening", "Good Order Date"), "unmapped", "not in the extract; the account opening workflow holds it"),
    ("ACCT_MASTER", "", ("15", "Account Tax Reporting Status", "Tax Reporting Regimes"), "unmapped", "tax reporting regimes are assigned by the tax operations system"),
    # ACCT_MASTER -> 15 Account Identifier
    ("ACCT_MASTER", "ACCT_NO", ("15", "Account Identifier", "Account Identifier ID"), "derived", "'ACI-BRK-' || ACCT_NO"),
    ("ACCT_MASTER", "ACCT_NO", ("15", "Account Identifier", "Identified Account"), "derived", "'ACC-BRK-' || ACCT_NO"),
    ("ACCT_MASTER", "", ("15", "Account Identifier", "Account Identifier Scheme"), "constant", "Brokerage Account Number"),
    ("ACCT_MASTER", "ACCT_NO", ("15", "Account Identifier", "Account Identifier Value"), "identifier", "ACCT_NO"),
    ("ACCT_MASTER", "", ("15", "Account Identifier", "Primary Identifier Indicator"), "constant", "Y"),
    ("ACCT_MASTER", "", ("15", "Account Identifier", "Account Identifier Status"), "constant", "Active"),
    ("ACCT_MASTER", "OPEN_DT", ("15", "Account Identifier", "Identifier Effective From"), "direct", ""),
    # ACCT_MASTER -> 15 Account Party Role (primary and joint owner rows)
    ("ACCT_MASTER", "PRIM_CUST_NO", ("15", "Account Party Role", "Role Party"), "identifier", "CUST_NO"),
    ("ACCT_MASTER", "SEC_CUST_NO", ("15", "Account Party Role", "Role Party"), "identifier", "CUST_NO"),
    ("ACCT_MASTER", "ACCT_NO", ("15", "Account Party Role", "Role Account"), "derived", "'ACC-BRK-' || ACCT_NO"),
    ("ACCT_MASTER", "SEC_CUST_NO", ("15", "Account Party Role", "Account Role Type"), "derived", "'Primary Owner' for the PRIM_CUST_NO row, 'Joint Owner' for the SEC_CUST_NO row"),
    ("ACCT_MASTER", "OPEN_DT", ("15", "Account Party Role", "Account Role Effective From"), "direct", ""),
    ("ACCT_MASTER", "CLOSE_DT", ("15", "Account Party Role", "Account Role Effective To"), "direct", ""),
    # ACCT_MASTER -> 15 Program Enrollment (rows with PROGRAM_CD)
    ("ACCT_MASTER", "ACCT_NO", ("15", "Program Enrollment", "Program Enrollment ID"), "derived", "'ENRL-BRK-' || ACCT_NO where PROGRAM_CD <> ''"),
    ("ACCT_MASTER", "ACCT_NO", ("15", "Program Enrollment", "Enrolled Account"), "derived", "'ACC-BRK-' || ACCT_NO"),
    ("ACCT_MASTER", "PROGRAM_CD", ("15", "Program Enrollment", "Enrolled Service Offering"), "derived", "'OFF-' || PROGRAM_CD (the same codes as CRM Offering__c.Code__c)"),
    ("ACCT_MASTER", "ENROLL_STATUS_CD", ("15", "Program Enrollment", "Enrollment Status"), "crosswalk", "ENROLL_STATUS_CD"),
    ("ACCT_MASTER", "ENROLL_DT", ("15", "Program Enrollment", "Enrollment Effective Date"), "direct", ""),
    ("ACCT_MASTER", "", ("15", "Program Enrollment", "Enrollment Termination Date"), "unmapped", "the platform overwrites the enrollment; termination history is in the advice platform"),
    ("ACCT_MASTER", "", ("15", "Program Enrollment", "Advisory Agreement"), "unmapped", "agreements are in the document system, not the clearing platform"),
    ("ACCT_MASTER", "PROGRAM_CD", ("15", "Program Enrollment", "Discretionary Authority Indicator"), "derived", "PROGRAM_CD in ('PAS', 'WMP', 'DAP')"),
    # CUST_MASTER -> 02 Party / Individual / Party Identifier
    ("CUST_MASTER", "CRM_CONTACT_ID", ("02", "Party", "Party ID"), "derived", "coalesce('PTY-' || CRM_CONTACT_ID, 'PTY-BRK-' || CUST_NO): the CRM party when linked, else a platform-only party"),
    ("CUST_MASTER", "", ("02", "Party", "Party Type"), "constant", "Individual"),
    ("CUST_MASTER", "LAST_NM", ("02", "Party", "Party Display Name"), "derived", "FIRST_NM || ' ' || LAST_NM"),
    ("CUST_MASTER", "CUST_STATUS_CD", ("02", "Party", "Party Status"), "crosswalk", "CUST_STATUS_CD"),
    ("CUST_MASTER", "", ("02", "Party", "Relationship Stage"), "constant", "Client"),
    ("CUST_MASTER", "ONBOARD_CHANNEL_CD", ("02", "Party", "Party Origin"), "crosswalk", "ONBOARD_CHANNEL_CD"),
    ("CUST_MASTER", "MERGED_TO_CUST_NO", ("02", "Party", "Merged Into Party"), "identifier", "CUST_NO"),
    ("CUST_MASTER", "FIRST_NM", ("02", "Individual", "Given Name"), "direct", ""),
    ("CUST_MASTER", "LAST_NM", ("02", "Individual", "Family Name"), "direct", ""),
    ("CUST_MASTER", "DOB", ("02", "Individual", "Date of Birth"), "direct", "YYYYMMDD to ISO 8601"),
    ("CUST_MASTER", "DOD", ("02", "Individual", "Date of Death"), "direct", "YYYYMMDD to ISO 8601"),
    ("CUST_MASTER", "CUST_NO", ("02", "Party Identifier", "Identifier Value"), "identifier", "CUST_NO"),
    ("CUST_MASTER", "CRM_CONTACT_ID", ("02", "Party Identifier", "Identifier Value"), "identifier", "CRM_CONTACT_ID"),
    ("CUST_MASTER", "CUST_NO", ("02", "Party Identifier", "Identified Party"), "derived", "the Party ID minted above"),
    ("CUST_MASTER", "CUST_STATUS_CD", ("02", "Party Identifier", "Identifier Status"), "derived", "'Active' unless CUST_STATUS_CD = 'M' (then 'Retired')"),
    ("CUST_MASTER", "CRM_CONTACT_ID", ("02", "Party Identifier", "Identifier Scheme"), "derived", "'CRM ID' for the CRM_CONTACT_ID row; the brokerage customer number scheme (a taxonomy gap) for the CUST_NO row"),
    ("CUST_MASTER", "", ("02", "Party Identifier", "Identifier Effective From"), "unmapped", "the platform keeps no identifier history"),
    ("CUST_MASTER", "", ("02", "Tax Profile", "Tax Identification Number"), "unmapped", "only the last four digits are extracted (PII); the full TIN stays in the platform"),
    # SEC_MASTER -> 17 Instrument
    ("SEC_MASTER", "CUSIP", ("17", "Instrument", "Instrument ID"), "derived", "'INS-' || CUSIP (the CUSIP itself belongs in 17 Instrument Identifier, outside the slice)"),
    ("SEC_MASTER", "SEC_DESC", ("17", "Instrument", "Instrument Name"), "direct", ""),
    ("SEC_MASTER", "SEC_TYPE_CD", ("17", "Instrument", "Instrument Type"), "crosswalk", "SEC_TYPE_CD"),
    ("SEC_MASTER", "FUND_FAMILY_CD", ("17", "Instrument", "Instrument Type"), "derived", "'Own Fund Share Class' when FUND_FAMILY_CD = 'OWN' (overrides the SEC_TYPE_CD crosswalk)"),
    ("SEC_MASTER", "ASSET_CLS_CD", ("17", "Instrument", "Asset Class"), "crosswalk", "ASSET_CLS_CD"),
    ("SEC_MASTER", "CCY", ("17", "Instrument", "Denomination Currency"), "direct", ""),
    ("SEC_MASTER", "SEC_STATUS_CD", ("17", "Instrument", "Instrument Status"), "crosswalk", "SEC_STATUS_CD"),
    ("SEC_MASTER", "TA_FUND_NO", ("17", "Instrument", "Own Share Class"), "derived", "'SHC-' || TA_FUND_NO where FUND_FAMILY_CD = 'OWN'"),
    ("SEC_MASTER", "", ("17", "Instrument", "Issuer"), "unmapped", "ISSUER_NM is a name, not a party; the issuer party comes from the issuer master (DP-098)"),
    ("SEC_MASTER", "", ("17", "Instrument", "CFI Code"), "unmapped", "not carried by the clearing platform; vendor security master"),
    ("SEC_MASTER", "SEC_TYPE_CD", ("17", "Fund Instrument Terms", "Fund Vehicle Type"), "derived", "'Exchange-Traded Fund' for ETF, 'Open-Ended Fund' for MF and MMF, else null"),
    ("SEC_MASTER", "TA_FUND_NO", ("17", "Fund Instrument Terms", "Own Investment Product"), "derived", "the Product ID of the fund number's PRODUCT_CD in the transfer agent FUND_MASTER"),
    # POSITIONS -> 49 Client Holding / Client Holding Valuation
    ("POSITIONS", "ACCT_NO", ("49", "Client Holding", "Client Holding ID"), "derived", "'CLHLD-' || ACCT_NO || '-' || CUSIP || '-' || ASOF_DT"),
    ("POSITIONS", "ACCT_NO", ("49", "Client Holding", "Holding Account"), "identifier", "ACCT_NO"),
    ("POSITIONS", "CUSIP", ("49", "Client Holding", "Held Instrument"), "derived", "'INS-' || CUSIP"),
    ("POSITIONS", "ASOF_DT", ("49", "Client Holding", "Client Holding Date"), "direct", "YYYYMMDD to ISO 8601"),
    ("POSITIONS", "", ("49", "Client Holding", "Client Holding View"), "constant", "End of Day"),
    ("POSITIONS", "QTY_TD", ("49", "Client Holding", "Trade-Date Quantity"), "direct", ""),
    ("POSITIONS", "QTY_SD", ("49", "Client Holding", "Settled Quantity"), "direct", ""),
    ("POSITIONS", "CUSIP", ("49", "Client Holding", "Own Share Class Indicator"), "derived", "SEC_MASTER.FUND_FAMILY_CD = 'OWN' for the CUSIP"),
    ("POSITIONS", "ASOF_DT", ("49", "Client Holding Valuation", "Valuation Date"), "direct", ""),
    ("POSITIONS", "MKT_VAL", ("49", "Client Holding Valuation", "Market Value"), "direct", ""),
    ("POSITIONS", "MKT_VAL", ("49", "Client Holding Valuation", "Market Value in USD"), "direct", "USD-only platform"),
    ("POSITIONS", "", ("49", "Client Holding Valuation", "Valuation Currency"), "constant", "USD"),
    ("POSITIONS", "COST_BASIS", ("49", "Client Holding Valuation", "Total Cost Basis"), "direct", ""),
    ("POSITIONS", "ACCRUED_INT", ("49", "Client Holding Valuation", "Accrued Interest"), "direct", ""),
    ("POSITIONS", "", ("49", "Client Holding Valuation", "Valuation Price Record"), "unmapped", "PRICE is the price applied, not a 22 Approved Price record; the pricing product (DP-143) supplies the record"),
    # CASH_BAL -> 49 Account Cash Balance
    ("CASH_BAL", "ACCT_NO", ("49", "Account Cash Balance", "Cash Balance Account"), "identifier", "ACCT_NO"),
    ("CASH_BAL", "CCY", ("49", "Account Cash Balance", "Cash Balance Currency"), "direct", ""),
    ("CASH_BAL", "BAL_TYPE_CD", ("49", "Account Cash Balance", "Cash Balance Type"), "crosswalk", "BAL_TYPE_CD"),
    ("CASH_BAL", "BAL_BASIS_CD", ("49", "Account Cash Balance", "Balance Basis"), "crosswalk", "BAL_BASIS_CD"),
    ("CASH_BAL", "ASOF_DT", ("49", "Account Cash Balance", "Cash Balance Business Date"), "direct", "YYYYMMDD to ISO 8601"),
    ("CASH_BAL", "BAL_AMT", ("49", "Account Cash Balance", "Cash Balance Amount"), "direct", ""),
    ("CASH_BAL", "SWEEP_PGM_CD", ("49", "Account Cash Balance", "Balance Sweep Program"), "derived", "'SWP-' || SWEEP_PGM_CD for SWP rows"),
    # ACTIVITY -> 49 Client Account Activity
    ("ACTIVITY", "TXN_ID", ("49", "Client Account Activity", "Client Account Activity ID"), "derived", "'CLACT-' || TXN_ID"),
    ("ACTIVITY", "ACCT_NO", ("49", "Client Account Activity", "Activity Account"), "identifier", "ACCT_NO"),
    ("ACTIVITY", "TXN_CD", ("49", "Client Account Activity", "Activity Type"), "crosswalk", "TXN_CD"),
    ("ACTIVITY", "CUSIP", ("49", "Client Account Activity", "Activity Instrument"), "derived", "'INS-' || CUSIP where CUSIP <> ''"),
    ("ACTIVITY", "TRD_DT", ("49", "Client Account Activity", "Trade Date"), "direct", "YYYYMMDD to ISO 8601"),
    ("ACTIVITY", "SETL_DT", ("49", "Client Account Activity", "Settlement Date"), "direct", "YYYYMMDD to ISO 8601"),
    ("ACTIVITY", "ENTRY_DT", ("49", "Client Account Activity", "Entry Date"), "direct", "YYYYMMDD to ISO 8601"),
    ("ACTIVITY", "QTY", ("49", "Client Account Activity", "Activity Quantity"), "direct", ""),
    ("ACTIVITY", "PRICE", ("49", "Client Account Activity", "Activity Price"), "direct", ""),
    ("ACTIVITY", "NET_AMT", ("49", "Client Account Activity", "Activity Net Amount"), "direct", "signed, credits positive"),
    ("ACTIVITY", "CCY", ("49", "Client Account Activity", "Activity Currency"), "direct", ""),
    ("ACTIVITY", "STATUS_CD", ("49", "Client Account Activity", "Activity Status"), "crosswalk", "STATUS_CD_ACT"),
    ("ACTIVITY", "REVERSAL_OF_TXN_ID", ("49", "Client Account Activity", "Reversed Activity"), "derived", "'CLACT-' || REVERSAL_OF_TXN_ID where not blank"),
    ("ACTIVITY", "", ("49", "Client Account Activity", "Source Account Transfer"), "unmapped", "XFER_TYPE_CD, CONTRA_ACCT_NO and CONTRA_FIRM_CD describe the transfer on the posting itself; 49 Account Transfer (the ACATS record) is outside the slice, so the flow derivation reads these source columns directly"),
]

CROSSWALKS = {
    "ACCT_CLASS_CD": dict(target=("15", "Account Type"), values=[
        ("B", "Brokerage Account", ""), ("A", "Managed Advisory Account", ""), ("T", "Fiduciary Account", "carried by the trust company")]),
    "REG_CD": dict(target=("15", "Account Registration Type"), values=[
        ("IND", "Individual", ""), ("JTWROS", "Joint Tenants (JTWROS)", ""), ("TIC", "Tenants in Common", ""),
        ("TIRA", "Traditional IRA", ""), ("RIRA", "Roth IRA", ""), ("ROLL", "Rollover IRA", ""), ("INHIRA", "Inherited IRA", ""),
        ("SEP", "SEP IRA", ""), ("UTMA", "UTMA / UGMA", ""), ("RTR", "Revocable Trust", ""), ("ITR", "Irrevocable Trust", ""),
        ("EST", "Estate", ""), ("529", "529 Plan", "")]),
    "STATUS_CD": dict(target=("15", "Account Status"), values=[
        ("O", "Open", ""), ("P", "Pending", ""), ("D", "Dormant", ""), ("C", "Closed", ""), ("E", "Escheated", "")]),
    "MARGIN_CD": dict(target=("15", "Reg T Account Type"), values=[("C", "Cash Account", ""), ("M", "Margin Account", "")]),
    "PURPOSE_CD": dict(target=("15", "Account Purpose"), values=[
        ("RET", "Retirement Savings", ""), ("EDU", "Education Savings", ""), ("GEN", "General Investing", ""),
        ("CSH", "Cash Management / Emergency Reserve", ""), ("EST", "Estate and Legacy", "")]),
    "CHANNEL_CD_BL": dict(target=("15", "Business Line"), values=[
        ("SD", "Direct brokerage and self-directed investing", "code DB"), ("DA", "Digital advice", "code DA"),
        ("HA", "Human and hybrid advice", "code HA"), ("TR", "Personal trust services", "code TR")]),
    "CLOSE_RSN_CD": dict(target=("15", "Account Closure Reason"), values=[
        ("FW", "Full Withdrawal", ""), ("AO", "Transfer Out (ACATS)", ""), ("RR", "Re-Registration to Successor Account", ""),
        ("ES", "Estate Settlement", ""), ("SB", "Small Balance Closure", ""), ("FE", "Opened in Error", "")]),
    "ENROLL_STATUS_CD": dict(target=("15", "Enrollment Status"), values=[
        ("A", "Active", ""), ("S", "Suspended", ""), ("T", "Terminated", "")]),
    "CUST_STATUS_CD": dict(target=("02", "Party Status"), values=[("A", "Active", ""), ("I", "Inactive", ""), ("M", "Merged", "")]),
    "ONBOARD_CHANNEL_CD": dict(target=("02", "Party Origin"), values=[
        ("WEB", "Direct Online Application", ""), ("MOB", "Mobile App Application", ""), ("PHN", "Phone Representative", ""),
        ("ADV", "Advisor-Assisted Onboarding", ""), ("XFR", "Account Transfer In", "")]),
    "SEC_TYPE_CD": dict(target=("17", "Instrument Type"), values=[
        ("EQ", "Equity Share", ""), ("ETF", "Third-Party Fund", "own ETFs are overridden to Own Fund Share Class"),
        ("MF", "Third-Party Fund", "own funds are overridden to Own Fund Share Class"), ("MMF", "Third-Party Fund", "money market funds; own ones overridden"),
        ("FI", "Corporate Bond", "the platform does not distinguish bond types; steward ruling pending"),
        ("CD", "Certificate of Deposit", ""), ("OPT", "Listed Option", ""), ("UIT", "Other", "unit investment trusts")]),
    "ASSET_CLS_CD": dict(target=("17", "Instrument Asset Class"), values=[
        ("EQ", "Equity", ""), ("FI", "Fixed Income", ""), ("CASH", "Cash & Money Market", ""), ("MA", "Multi-Asset", ""), ("DER", "Derivative", "")]),
    "SEC_STATUS_CD": dict(target=("17", "Instrument Status"), values=[("A", "Active", ""), ("I", "Inactive", ""), ("M", "Matured", "")]),
    "BAL_TYPE_CD": dict(target=("49", "Cash Balance Type"), values=[
        ("FCB", "Free Credit Balance", ""), ("SWP", "Sweep Balance", ""), ("MDB", "Margin Debit Balance", "")]),
    "BAL_BASIS_CD": dict(target=("49", "Cash Balance Basis"), values=[("T", "Trade Date", ""), ("S", "Settlement Date", "")]),
    "TXN_CD": dict(target=("49", "Activity Type"), values=[
        ("BUY", "Buy", ""), ("SEL", "Sell", ""), ("FBUY", "Fund Purchase", ""), ("FRED", "Fund Redemption", ""),
        ("DEP", "Money Movement In", ""), ("WDL", "Money Movement Out", ""), ("JNL", "Journal", ""),
        ("DIV", "Dividend", ""), ("INT", "Interest", ""), ("CGD", "Capital Gain Distribution", ""), ("FEE", "Fee Debit", ""),
        ("ACATI", "Account Transfer In", ""), ("ACATO", "Account Transfer Out", ""), ("XFRI", "Account Transfer In", "non-ACATS"),
        ("XFRO", "Account Transfer Out", "non-ACATS"), ("ROLLI", "Account Transfer In", "rollover; the rollover nature is in XFER_TYPE_CD")]),
    "STATUS_CD_ACT": dict(target=("49", "Activity Status"), values=[("P", "Posted", ""), ("N", "Pending", ""), ("R", "Reversed", "")]),
}

GAPS = [
    ("ACTIVITY", "XFER_TYPE_CD, CONTRA_ACCT_NO and CONTRA_FIRM_CD have no home on 49 Client Account Activity; they describe the 49 Account Transfer that DP-300 models outside this slice. The DP-006 derivation reads them from the staging row."),
    ("ACCT_MASTER", "REP_CD (the rep of record) is not mapped: advisor coverage of direct clients is the CRM's (03 Party Coverage Assignment through DP-009); the code is kept to tie the account to the advisor in the Advisor dimension."),
]
