"""Confirmed mapping of SRC-CRM, the CRM in Salesforce Financial Services Cloud shape, to the taxonomy. See CONTRACT.md.

The CRM is the system of record for households and their members (02), the people the firm knows, who holds which role
on which account (15 Account Party Role), the advisor assignment (03), consents and trusted contacts (02), and the
offering and service tier reference (01). Its financial accounts carry the brokerage and transfer agent account
numbers, which is how accounts roll up to people and households (15 Account Identifier). Enterprise keys:
PTY-HH-<household Id>, PTY-<contact Id>, EMP-<employee number>, OFF-<offering code>.
"""

SOURCE = dict(
    id="SRC-CRM", name="Client Relationship Management", kind="System of record for households and relationships",
    identifier_schemes={
        "Contact.Id": ("02", "Identifier Scheme", "CRM ID"),
        "FinancialAccount.Id": ("15", "Account Identifier Scheme", "CRM Financial Account ID"),
        "FinancialAccountNumber.BRK": ("15", "Account Identifier Scheme", "Brokerage Account Number"),
        "FinancialAccountNumber.TA": ("15", "Account Identifier Scheme", "Transfer Agent Account Number"),
        "Brokerage_Customer_No__c": ("02", "Identifier Scheme", None,
                                     "02 Identifier Scheme has no value for a brokerage platform customer number; the same gap SRC-BRK reports"),
    })

OBJECTS = [
    ("Account", ("02", "Party"), "one Household party per CRM household"),
    ("Account", ("02", "Household"), "household name, formation basis, primary member"),
    ("Account", ("02", "Segment Assignment"), "the household's client value segment (current value only)"),
    ("Account", ("02", "Service Tier Assignment"), "the household's service tier (current value only)"),
    ("Account", ("03", "Party Coverage Assignment"), "the owning user as primary advisor of the household"),
    ("Contact", ("02", "Party"), "one Individual party per contact"),
    ("Contact", ("02", "Individual"), "name and dates"),
    ("Contact", ("02", "Party Identifier"), "the contact Id and the brokerage customer number it carries"),
    ("Contact", ("02", "Household Membership"), "membership of the contact's primary household"),
    ("Contact", ("02", "Privacy Profile"), "do-not-contact"),
    ("FinServ__FinancialAccount__c", ("15", "Account Identifier"), "the external account number and the CRM financial account Id of each account"),
    ("FinServ__FinancialAccount__c", ("15", "Account"), "business line as the CRM classifies the account"),
    ("FinServ__FinancialAccountRole__c", ("15", "Account Party Role"), "owner and custodial roles; beneficiaries and powers of attorney are other objects"),
    ("FinServ__FinancialAccountRole__c", ("02", "Authority Grant"), "Power of Attorney rows"),
    ("User", ("20", "Employee"), "the advisor's worker record as the CRM knows it (DP-192's record is HR's)"),
    ("User", ("03", "Advisor"), "advisor profile of users in advisor roles"),
    ("Consent__c", ("02", "Consent Record"), "one row per consent"),
    ("Trusted_Contact__c", ("02", "Trusted Contact Designation"), "one row per designation"),
    ("Offering__c", ("01", "Service Offering"), "one row per offering"),
    ("Service_Tier__c", ("01", "Service Tier"), "one row per tier"),
]

ATTRIBUTES = [
    # Account (households) -> 02 Party / Household / Segment Assignment / Service Tier Assignment / 03 coverage
    ("Account", "Id", ("02", "Party", "Party ID"), "derived", "'PTY-HH-' || Id"),
    ("Account", "", ("02", "Party", "Party Type"), "constant", "Household"),
    ("Account", "Name", ("02", "Party", "Party Display Name"), "direct", ""),
    ("Account", "FinServ__Status__c", ("02", "Party", "Party Status"), "crosswalk", "HH_STATUS"),
    ("Account", "", ("02", "Party", "Relationship Stage"), "constant", "Client"),
    ("Account", "Name", ("02", "Household", "Household Name"), "direct", ""),
    ("Account", "Formation_Basis__c", ("02", "Household", "Household Formation Basis"), "crosswalk", "FORMATION_BASIS"),
    ("Account", "FinServ__PrimaryContact__c", ("02", "Household", "Primary Member"), "derived", "'PTY-' || FinServ__PrimaryContact__c"),
    ("Account", "Household_Confirmed_Date__c", ("02", "Household", "Membership Last Confirmed Date"), "direct", ""),
    ("Account", "Id", ("02", "Segment Assignment", "Segmented Party"), "derived", "'PTY-HH-' || Id"),
    ("Account", "", ("02", "Segment Assignment", "Segmentation Scheme"), "constant", "Client Value Segment"),
    ("Account", "Segment__c", ("02", "Segment Assignment", "Segment"), "direct", "firm-defined segment codes"),
    ("Account", "CreatedDate", ("02", "Segment Assignment", "Segment Effective From"), "derived", "date(CreatedDate): the CRM keeps no segment history, so the assignment is dated from the household's creation"),
    ("Account", "Id", ("02", "Service Tier Assignment", "Tier Party"), "derived", "'PTY-HH-' || Id"),
    ("Account", "Service_Tier__c", ("02", "Service Tier Assignment", "Assigned Service Tier"), "direct", "the Service Tier Code"),
    ("Account", "Tier_Method__c", ("02", "Service Tier Assignment", "Tier Assignment Method"), "crosswalk", "TIER_METHOD"),
    ("Account", "", ("02", "Service Tier Assignment", "Tier Effective From"), "unmapped", "the CRM overwrites the tier; no effective date is kept"),
    ("Account", "Id", ("03", "Party Coverage Assignment", "Coverage Assignment ID"), "derived", "'COV-HH-' || Id where OwnerId is not blank"),
    ("Account", "Id", ("03", "Party Coverage Assignment", "Covered Party"), "derived", "'PTY-HH-' || Id"),
    ("Account", "OwnerId", ("03", "Party Coverage Assignment", "Covering Advisor"), "derived", "'EMP-' || User.Employee_Number__c of OwnerId"),
    ("Account", "", ("03", "Party Coverage Assignment", "Party Coverage Role"), "constant", "Primary Advisor"),
    ("Account", "", ("03", "Party Coverage Assignment", "Primary Coverage Indicator"), "constant", "Y"),
    ("Account", "", ("03", "Party Coverage Assignment", "Coverage Effective From"), "unmapped", "the CRM keeps no assignment history; the owner change log is not extracted"),
    ("Account", "", ("03", "Party Coverage Assignment", "Coverage Effective To"), "unmapped", "as above"),
    # Contact -> 02 Party / Individual / Party Identifier / Household Membership / Privacy Profile
    ("Contact", "Id", ("02", "Party", "Party ID"), "derived", "'PTY-' || Id"),
    ("Contact", "", ("02", "Party", "Party Type"), "constant", "Individual"),
    ("Contact", "LastName", ("02", "Party", "Party Display Name"), "derived", "FirstName || ' ' || LastName"),
    ("Contact", "Status__c", ("02", "Party", "Party Status"), "crosswalk", "CONTACT_STATUS"),
    ("Contact", "FinServ__Status__c", ("02", "Party", "Relationship Stage"), "crosswalk", "STAGE"),
    ("Contact", "LeadSource", ("02", "Party", "Party Origin"), "crosswalk", "LEAD_SOURCE"),
    ("Contact", "Merged_Into__c", ("02", "Party", "Merged Into Party"), "derived", "'PTY-' || Merged_Into__c"),
    ("Contact", "FirstName", ("02", "Individual", "Given Name"), "direct", ""),
    ("Contact", "LastName", ("02", "Individual", "Family Name"), "direct", ""),
    ("Contact", "Birthdate", ("02", "Individual", "Date of Birth"), "direct", ""),
    ("Contact", "Deceased_Date__c", ("02", "Individual", "Date of Death"), "direct", ""),
    ("Contact", "Id", ("02", "Party Identifier", "Identifier Value"), "identifier", "Contact.Id"),
    ("Contact", "Brokerage_Customer_No__c", ("02", "Party Identifier", "Identifier Value"), "identifier", "Brokerage_Customer_No__c"),
    ("Contact", "Id", ("02", "Party Identifier", "Identified Party"), "derived", "'PTY-' || Id"),
    ("Contact", "", ("02", "Party Identifier", "Identifier Status"), "constant", "Active"),
    ("Contact", "Brokerage_Customer_No__c", ("02", "Party Identifier", "Identifier Scheme"), "derived", "'CRM ID' for the Id row; the brokerage customer number scheme (a taxonomy gap) for the Brokerage_Customer_No__c row"),
    ("Contact", "", ("02", "Party Identifier", "Identifier Effective From"), "unmapped", "the CRM keeps no identifier history"),
    ("Contact", "AccountId", ("02", "Household Membership", "Household"), "derived", "'PTY-HH-' || AccountId where AccountId is not blank"),
    ("Contact", "Id", ("02", "Household Membership", "Household Member"), "derived", "'PTY-' || Id"),
    ("Contact", "FinServ__PrimaryHouseholdRole__c", ("02", "Household Membership", "Household Member Role"), "crosswalk", "HH_ROLE"),
    ("Contact", "Household_End__c", ("02", "Household Membership", "Membership Status"), "derived", "'Active' when Household_End__c is blank, else 'Inactive'"),
    ("Contact", "Household_Start__c", ("02", "Household Membership", "Membership Effective From"), "direct", ""),
    ("Contact", "Household_End__c", ("02", "Household Membership", "Membership Effective To"), "direct", ""),
    ("Contact", "Do_Not_Contact__c", ("02", "Privacy Profile", "Do Not Contact Indicator"), "direct", ""),
    # FinancialAccount -> 15 Account Identifier (the account crosswalk) and the CRM's view of the account
    ("FinServ__FinancialAccount__c", "Id", ("15", "Account Identifier", "Account Identifier ID"), "derived", "'ACI-CRM-' || Id"),
    ("FinServ__FinancialAccount__c", "FinServ__FinancialAccountNumber__c", ("15", "Account Identifier", "Identified Account"), "derived", "'ACC-' || Source_System__c || '-' || FinServ__FinancialAccountNumber__c"),
    ("FinServ__FinancialAccount__c", "Source_System__c", ("15", "Account Identifier", "Account Identifier Scheme"), "crosswalk", "SOURCE_SYSTEM_SCHEME"),
    ("FinServ__FinancialAccount__c", "FinServ__FinancialAccountNumber__c", ("15", "Account Identifier", "Account Identifier Value"), "identifier", "FinancialAccountNumber.BRK"),
    ("FinServ__FinancialAccount__c", "FinServ__FinancialAccountNumber__c", ("15", "Account Identifier", "Account Identifier Value"), "identifier", "FinancialAccountNumber.TA"),
    ("FinServ__FinancialAccount__c", "Id", ("15", "Account Identifier", "Account Identifier Value"), "identifier", "FinancialAccount.Id"),
    ("FinServ__FinancialAccount__c", "", ("15", "Account Identifier", "Account Identifier Status"), "constant", "Active"),
    ("FinServ__FinancialAccount__c", "FinServ__OpenDate__c", ("15", "Account Identifier", "Identifier Effective From"), "direct", ""),
    ("FinServ__FinancialAccount__c", "FinServ__FinancialAccountNumber__c", ("15", "Account", "Account ID"), "derived", "'ACC-' || Source_System__c || '-' || FinServ__FinancialAccountNumber__c (the key the platform mints)"),
    ("FinServ__FinancialAccount__c", "Name", ("15", "Account", "Account Name"), "direct", "the client's nickname; the platform title is the registration"),
    ("FinServ__FinancialAccount__c", "Business_Line__c", ("15", "Account", "Account Business Line"), "crosswalk", "BUSINESS_LINE"),
    # FinancialAccountRole -> 15 Account Party Role and 02 Authority Grant
    ("FinServ__FinancialAccountRole__c", "FinServ__Role__c", ("15", "Account Party Role", "Account Role Type"), "crosswalk", "FA_ROLE"),
    ("FinServ__FinancialAccountRole__c", "FinServ__RelatedContact__c", ("15", "Account Party Role", "Role Party"), "derived", "'PTY-' || FinServ__RelatedContact__c"),
    ("FinServ__FinancialAccountRole__c", "FinServ__FinancialAccount__c", ("15", "Account Party Role", "Role Account"), "derived", "the Identified Account of the financial account row"),
    ("FinServ__FinancialAccountRole__c", "FinServ__StartDate__c", ("15", "Account Party Role", "Account Role Effective From"), "direct", ""),
    ("FinServ__FinancialAccountRole__c", "FinServ__EndDate__c", ("15", "Account Party Role", "Account Role Effective To"), "direct", ""),
    ("FinServ__FinancialAccountRole__c", "Id", ("02", "Authority Grant", "Authority Grant ID"), "derived", "'AUTH-' || Id for Power of Attorney rows"),
    ("FinServ__FinancialAccountRole__c", "FinServ__FinancialAccount__c", ("02", "Authority Grant", "Grantor Party"), "derived", "the primary owner of the financial account"),
    ("FinServ__FinancialAccountRole__c", "FinServ__RelatedContact__c", ("02", "Authority Grant", "Authority Holder"), "derived", "'PTY-' || FinServ__RelatedContact__c"),
    ("FinServ__FinancialAccountRole__c", "FinServ__Role__c", ("02", "Authority Grant", "Authority Type"), "crosswalk", "FA_ROLE_AUTHORITY"),
    ("FinServ__FinancialAccountRole__c", "", ("02", "Authority Grant", "Authority Scope"), "unmapped", "the CRM role does not say whether the power covers disbursements"),
    ("FinServ__FinancialAccountRole__c", "FinServ__FinancialAccount__c", ("02", "Authority Grant", "Accounts Covered"), "derived", "the Identified Account of the financial account row"),
    ("FinServ__FinancialAccountRole__c", "FinServ__StartDate__c", ("02", "Authority Grant", "Grant Effective From"), "direct", ""),
    ("FinServ__FinancialAccountRole__c", "FinServ__EndDate__c", ("02", "Authority Grant", "Revoked Date"), "direct", ""),
    # User -> 20 Employee (stand-in) and 03 Advisor
    ("User", "Employee_Number__c", ("20", "Employee", "Employee ID"), "derived", "'EMP-' || Employee_Number__c"),
    ("User", "Employee_Number__c", ("20", "Employee", "HR Employee Number"), "direct", ""),
    ("User", "Name", ("20", "Employee", "Preferred Name"), "direct", ""),
    ("User", "Title", ("20", "Employee", "Job Title"), "direct", ""),
    ("User", "IsActive", ("20", "Employee", "Employment Status"), "derived", "'Active' when IsActive else 'Terminated' (HR's status is DP-192's; this is the CRM's view)"),
    ("User", "", ("20", "Employee", "Legal Last Name"), "unmapped", "the CRM holds the display name only; HR holds legal names"),
    ("User", "", ("20", "Employee", "Business Email Address"), "unmapped", "not extracted (PII)"),
    ("User", "", ("20", "Employee", "Employing Legal Entity"), "unmapped", "HR's; the CRM does not know the employing entity"),
    ("User", "Employee_Number__c", ("03", "Advisor", "Employee"), "derived", "'EMP-' || Employee_Number__c where UserRole.Name is an advisor role"),
    ("User", "Advisor_Status__c", ("03", "Advisor", "Advisor Status"), "crosswalk", "ADVISOR_STATUS"),
    ("User", "Title", ("03", "Advisor", "Client-Facing Title"), "direct", ""),
    ("User", "Channels_Offered__c", ("03", "Advisor", "Advice Channels Offered"), "crosswalk", "CHANNELS_OFFERED"),
    ("User", "Business_Lines__c", ("03", "Advisor", "Advisor Business Lines"), "crosswalk", "BUSINESS_LINE"),
    ("User", "", ("03", "Advisor", "Entities Represented"), "unmapped", "registrations are in the licensing system (DP-039)"),
    # Consent__c -> 02 Consent Record
    ("Consent__c", "Id", ("02", "Consent Record", "Consent Record ID"), "derived", "'CNS-' || Id"),
    ("Consent__c", "Contact__c", ("02", "Consent Record", "Consenting Party"), "derived", "'PTY-' || Contact__c"),
    ("Consent__c", "Purpose__c", ("02", "Consent Record", "Consent Purpose"), "crosswalk", "CONSENT_PURPOSE"),
    ("Consent__c", "Status__c", ("02", "Consent Record", "Consent Status"), "crosswalk", "CONSENT_STATUS"),
    ("Consent__c", "Capture_Method__c", ("02", "Consent Record", "Consent Capture Method"), "crosswalk", "CAPTURE_METHOD"),
    ("Consent__c", "Captured_Date__c", ("02", "Consent Record", "Consent Captured Timestamp"), "direct", "a date; the CRM keeps no time of day"),
    ("Consent__c", "Expiry_Date__c", ("02", "Consent Record", "Consent Expiry Date"), "direct", ""),
    ("Consent__c", "Withdrawn_Timestamp__c", ("02", "Consent Record", "Consent Withdrawn Timestamp"), "direct", ""),
    # Trusted_Contact__c -> 02 Trusted Contact Designation
    ("Trusted_Contact__c", "Id", ("02", "Trusted Contact Designation", "Trusted Contact Designation ID"), "derived", "'TCD-' || Id"),
    ("Trusted_Contact__c", "Client__c", ("02", "Trusted Contact Designation", "Designating Client"), "derived", "'PTY-' || Client__c"),
    ("Trusted_Contact__c", "Trusted_Person__c", ("02", "Trusted Contact Designation", "Trusted Contact Person"), "derived", "'PTY-' || Trusted_Person__c"),
    ("Trusted_Contact__c", "Status__c", ("02", "Trusted Contact Designation", "Designation Status"), "crosswalk", "TC_STATUS"),
    ("Trusted_Contact__c", "Effective_From__c", ("02", "Trusted Contact Designation", "Designation Effective From"), "direct", ""),
    ("Trusted_Contact__c", "Effective_To__c", ("02", "Trusted Contact Designation", "Designation Effective To"), "direct", ""),
    # Offering__c -> 01 Service Offering
    ("Offering__c", "Code__c", ("01", "Service Offering", "Offering ID"), "derived", "'OFF-' || Code__c"),
    ("Offering__c", "Name", ("01", "Service Offering", "Offering Name"), "direct", ""),
    ("Offering__c", "Type__c", ("01", "Service Offering", "Offering Type"), "crosswalk", "OFFERING_TYPE"),
    ("Offering__c", "Delivery_Mode__c", ("01", "Service Offering", "Delivery Mode"), "crosswalk", "DELIVERY_MODE"),
    ("Offering__c", "Discretion__c", ("01", "Service Offering", "Discretion Type"), "crosswalk", "DISCRETION"),
    ("Offering__c", "Capacity__c", ("01", "Service Offering", "Advisory Capacity"), "crosswalk", "CAPACITY"),
    ("Offering__c", "Wrap_Fee__c", ("01", "Service Offering", "Wrap Fee Program Indicator"), "direct", ""),
    ("Offering__c", "Rule_3a4__c", ("01", "Service Offering", "Rule 3a-4 Program Indicator"), "direct", ""),
    ("Offering__c", "Status__c", ("01", "Service Offering", "Offering Status"), "crosswalk", "OFFERING_STATUS"),
    ("Offering__c", "", ("01", "Service Offering", "Sponsoring Entity"), "unmapped", "the CRM does not record which legal entity sponsors the offering"),
    # Service_Tier__c -> 01 Service Tier
    ("Service_Tier__c", "Code__c", ("01", "Service Tier", "Service Tier Code"), "direct", ""),
    ("Service_Tier__c", "Name", ("01", "Service Tier", "Service Tier Name"), "direct", ""),
    ("Service_Tier__c", "Asset_Threshold__c", ("01", "Service Tier", "Tier Asset Threshold"), "direct", ""),
    ("Service_Tier__c", "Threshold_Basis__c", ("01", "Service Tier", "Tier Measurement Basis"), "crosswalk", "TIER_BASIS"),
]

CROSSWALKS = {
    "HH_STATUS": dict(target=("02", "Party Status"), values=[("Active", "Active", ""), ("Inactive", "Inactive", "")]),
    "FORMATION_BASIS": dict(target=("02", "Household Formation Basis"), values=[
        ("Client", "Client Defined", ""), ("AdvisorProposed", "Advisor Proposed - Client Confirmed", ""), ("SystemSuggested", "System Suggested - Unconfirmed", "")]),
    "TIER_METHOD": dict(target=("02", "Assignment Method"), values=[
        ("Rule", "Rule-Based Threshold", ""), ("Score", "Model Score", ""), ("Manual", "Manual Override", ""), ("Grandfathered", "Grandfathered", "")]),
    "CONTACT_STATUS": dict(target=("02", "Party Status"), values=[
        ("Active", "Active", ""), ("Inactive", "Inactive", ""), ("Merged", "Merged", ""), ("PendingVerification", "Pending Verification", "")]),
    "STAGE": dict(target=("02", "Relationship Stage"), values=[
        ("Prospect", "Prospect", ""), ("Applicant", "Applicant", ""), ("Client", "Client", ""), ("Former Client", "Former Client", ""), ("Related Party", "Related Party", "")]),
    "LEAD_SOURCE": dict(target=("02", "Party Origin"), values=[
        ("Web", "Direct Online Application", ""), ("Mobile", "Mobile App Application", ""), ("Phone", "Phone Representative", ""),
        ("Advisor", "Advisor-Assisted Onboarding", ""), ("Workplace", "Workplace Plan Enrollment", ""), ("TransferAgent", "Transfer Agent Registration", ""),
        ("AccountTransfer", "Account Transfer In", ""), ("Referral", "Lead Conversion", "")]),
    "HH_ROLE": dict(target=("02", "Household Member Role"), values=[
        ("Head", "Head of Household", ""), ("Spouse", "Spouse / Domestic Partner", ""), ("Dependent", "Dependent", ""), ("Other", "Other Family Member", "")]),
    "SOURCE_SYSTEM_SCHEME": dict(target=("15", "Account Identifier Scheme"), values=[
        ("BRK", "Brokerage Account Number", ""), ("TA", "Transfer Agent Account Number", "")]),
    "BUSINESS_LINE": dict(target=("15", "Business Line"), values=[
        ("DB", "Direct brokerage and self-directed investing", "code DB"), ("DA", "Digital advice", "code DA"), ("HA", "Human and hybrid advice", "code HA"),
        ("PF", "Proprietary funds and ETFs", "code PF"), ("PT", "Personal trust services", "the CRM's PT is the taxonomy's TR")]),
    "FA_ROLE": dict(target=("15", "Account Role Type"), values=[
        ("Primary Owner", "Primary Owner", ""), ("Joint Owner", "Joint Owner", ""), ("Custodian", "Custodian (UTMA)", ""),
        ("Guardian", "Guardian / Conservator", ""), ("Trustee", "Authorized Signatory", "a trustee signs for the trust account; the trust itself is 51"),
        ("Authorized Trader", "Authorized Signatory", ""),
        ("Beneficiary", None, "beneficiaries are 15 Beneficiary Designation, not an account party role"),
        ("Power of Attorney", None, "powers of attorney are 02 Authority Grant (mapped below), not an account party role")]),
    "FA_ROLE_AUTHORITY": dict(target=("02", "Authority Type"), values=[
        ("Power of Attorney", "Durable Power of Attorney", "the CRM does not distinguish durable, limited and springing powers; steward ruling pending")]),
    "ADVISOR_STATUS": dict(target=("03", "Advisor Status"), values=[
        ("Onboarding", "Onboarding", ""), ("Active", "Active", ""), ("Transitioning", "Transitioning Book", ""), ("Inactive", "Inactive", "")]),
    "CHANNELS_OFFERED": dict(target=("03", "Interaction Medium"), values=[
        ("Phone", "Phone", ""), ("Video", "Video Conference", ""), ("InPerson", "In Person", ""), ("Chat", "Chat / Messaging", "")]),
    "CONSENT_PURPOSE": dict(target=("02", "Consent Purpose"), values=[
        ("eDelivery", "Electronic Delivery (E-SIGN)", ""), ("MarketingEmail", "Marketing Email", ""), ("MarketingSMS", "Marketing Text Messages", ""),
        ("CallRecording", "Call Recording", ""), ("DataSharing", "Third-Party Data Sharing (FDX)", "")]),
    "CONSENT_STATUS": dict(target=("02", "Consent Status"), values=[
        ("Granted", "Granted", ""), ("Withdrawn", "Withdrawn", ""), ("Expired", "Expired", ""), ("Declined", "Declined", "")]),
    "CAPTURE_METHOD": dict(target=("02", "Consent Capture Method"), values=[
        ("WebSingle", "Web Form - Single Opt-In", ""), ("WebDouble", "Web Form - Double Opt-In", ""), ("Mobile", "Mobile App", ""),
        ("ESign", "Electronic Signature Ceremony", ""), ("Verbal", "Recorded Verbal", ""), ("Paper", "Paper Form", "")]),
    "TC_STATUS": dict(target=("02", "Trusted Contact Status"), values=[
        ("Provided", "Provided", ""), ("Declined", "Declined by Client", ""), ("Requested", "Requested - Not Provided", "")]),
    "OFFERING_TYPE": dict(target=("01", "Offering Type"), values=[
        ("DigitalAdvice", "Digital Advice", ""), ("HybridAdvice", "Hybrid Advice", ""), ("PersonalAdvisor", "Personal Advisor", ""),
        ("WealthManagement", "Wealth Management", ""), ("PlanningOnly", "Planning Only", ""), ("Brokerage", "Brokerage", ""), ("TrustServices", "Trust Services", "")]),
    "DELIVERY_MODE": dict(target=("01", "Delivery Mode"), values=[
        ("DigitalOnly", "Digital Only", ""), ("DigitalWithAdvisor", "Digital with Advisor Access", ""), ("DedicatedAdvisor", "Dedicated Advisor", ""), ("AdvisorTeam", "Advisor Team", "")]),
    "DISCRETION": dict(target=("01", "Discretion Type"), values=[
        ("Discretionary", "Discretionary", ""), ("NonDiscretionary", "Non-Discretionary", ""), ("NA", "Not Applicable", "")]),
    "CAPACITY": dict(target=("01", "Advisory Capacity"), values=[
        ("IA", "Investment Adviser", ""), ("BD", "Broker-Dealer", ""), ("TC", "Trust Company Fiduciary", ""), ("DUAL", "Dual Capacity", "")]),
    "OFFERING_STATUS": dict(target=("01", "Lifecycle Status"), values=[
        ("Active", "Active", ""), ("SoftClosed", "Soft Closed", ""), ("Inactive", "Inactive", "")]),
    "TIER_BASIS": dict(target=("01", "Tier Measurement Basis"), values=[
        ("HouseholdAssets", "Household Client Assets", ""), ("ClientAssets", "Client Assets", ""), ("HouseholdAssetsInclWorkplace", "Household Client Assets incl. Workplace Plan", "")]),
}

GAPS = [
    ("FinServ__FinancialAccount__c", "Held-away accounts (Held_Away__c) have no home in 15 Account, which masters the firm's own accounts; DP-320 reads Held-Away Assets from the CRM aggregation directly. Candidate taxonomy addition: 02 Held-Away Asset Summary."),
    ("User", "Rep_Code__c (the firm rep code of the brokerage platform) has no identifier scheme for employees in 20; it is kept to join ACCT_MASTER.REP_CD to the advisor."),
]
