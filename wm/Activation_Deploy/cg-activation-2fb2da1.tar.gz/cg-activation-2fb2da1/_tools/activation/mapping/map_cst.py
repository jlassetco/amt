"""Confirmed mapping of SRC-CST, the cost allocation engine, to the taxonomy. See CONTRACT.md.

The engine is the system of record for management cost allocation (10): the cost pools the ledger's operating expense
flows into, the allocation methods, the rules that send each pool to a profitability dimension by a driver, each
month's allocation run and its results per rule and dimension member. Pool cost per run (POOL_COST) has no entity in
the slice; the compiler reads it directly for the Pool Source Cost measure. Enterprise keys keep the engine's own ids
(CP-, M-, AR-, ALR-); run periods are FY<yyyy>-M<mm> (DP-013 Fiscal Period); dimension members keep the enterprise
codes the engine uses (certified channel keys, business line codes DB ... IC, CRM segment names, program codes, T1-T4).
"""

SOURCE = dict(
    id="SRC-CST", name="Cost Allocation Engine", kind="System of record for cost allocation",
    identifier_schemes={})

OBJECTS = [
    ("POOL", ("10", "Cost Pool"), "one row per cost pool"),
    ("METHOD", ("10", "Allocation Method"), "one row per method"),
    ("RULE", ("10", "Allocation Rule"), "one row per rule"),
    ("RUN", ("10", "Allocation Run"), "one row per run (fiscal month x data version)"),
    ("RESULT", ("10", "Allocation Result"), "one row per run x rule x target member"),
]

ATTRIBUTES = [
    # POOL -> 10 Cost Pool
    ("POOL", "POOL_ID", ("10", "Cost Pool", "Cost Pool ID"), "direct", "already CP-prefixed"),
    ("POOL", "POOL_TYPE_CD", ("10", "Cost Pool", "Cost Pool Type"), "crosswalk", "POOL_TYPE_CD"),
    ("POOL", "CTS_COMP_CD", ("10", "Cost Pool", "Cost-to-Serve Component"), "crosswalk", "CTS_COMP_CD"),
    ("POOL", "COST_CENTERS", ("10", "Cost Pool", "Contributing Cost Centers"), "direct", "'; '-separated cost center codes (GAPS)"),
    ("POOL", "CATEGORIES", ("10", "Cost Pool", "Included Expense Categories"), "derived", "each '; '-separated code through crosswalk CATEGORIES"),
    # METHOD -> 10 Allocation Method
    ("METHOD", "METHOD_ID", ("10", "Allocation Method", "Allocation Method ID"), "direct", ""),
    ("METHOD", "METHOD_NM", ("10", "Allocation Method", "Allocation Method Name"), "direct", ""),
    ("METHOD", "METHOD_TYPE_CD", ("10", "Allocation Method", "Allocation Method Type"), "crosswalk", "METHOD_TYPE_CD"),
    # RULE -> 10 Allocation Rule
    ("RULE", "RULE_ID", ("10", "Allocation Rule", "Allocation Rule ID"), "direct", ""),
    ("RULE", "POOL_ID", ("10", "Allocation Rule", "Source Cost Pool"), "direct", "the Cost Pool ID"),
    ("RULE", "METHOD_ID", ("10", "Allocation Rule", "Applied Allocation Method"), "direct", "the Allocation Method ID"),
    ("RULE", "DRIVER_CD", ("10", "Allocation Rule", "Applied Driver"), "direct", "driver code; no driver entity (GAPS)"),
    ("RULE", "TARGET_DIM_CD", ("10", "Allocation Rule", "Target Dimension"), "crosswalk", "TARGET_DIM_CD"),
    ("RULE", "SEQ_NO", ("10", "Allocation Rule", "Allocation Sequence"), "direct", ""),
    ("RULE", "EFF_FROM_DT", ("10", "Allocation Rule", "Rule Effective From"), "direct", ""),
    ("RULE", "EFF_TO_DT", ("10", "Allocation Rule", "Rule Effective To"), "direct", "blank while current"),
    # RUN -> 10 Allocation Run
    ("RUN", "RUN_ID", ("10", "Allocation Run", "Allocation Run ID"), "direct", ""),
    ("RUN", "FISCAL_MONTH", ("10", "Allocation Run", "Run Period"), "derived",
     "'FY' || substr(FISCAL_MONTH, 1, 4) || '-M' || substr(FISCAL_MONTH, 6, 2)"),
    ("RUN", "VERSION_CD", ("10", "Allocation Run", "Run Data Version"), "crosswalk", "VERSION_CD"),
    ("RUN", "STATUS_CD", ("10", "Allocation Run", "Run Status"), "crosswalk", "RUN_STATUS_CD"),
    ("RUN", "RESIDUAL_AMT", ("10", "Allocation Run", "Unallocated Residual"), "direct", "unused capacity"),
    # RESULT -> 10 Allocation Result (Allocation Run Key = RUN_ID through the row shape in compile/transforms.py)
    ("RESULT", "RULE_ID", ("10", "Allocation Result", "Allocated Rule"), "direct", "the Allocation Rule ID"),
    ("RESULT", "TARGET_MEMBER", ("10", "Allocation Result", "Target Dimension Member"), "direct", "enterprise member code, or a pool id"),
    ("RESULT", "DRIVER_SHARE", ("10", "Allocation Result", "Driver Share"), "direct", "percent"),
    ("RESULT", "AMT", ("10", "Allocation Result", "Allocated Amount"), "direct", ""),
]

CROSSWALKS = {
    "POOL_TYPE_CD": dict(target=("10", "Cost Pool Type"), values=[
        ("ADV", "Advice", ""), ("SVC", "Client Service", ""), ("PLAT", "Platform & Technology", ""),
        ("CLR", "Clearing & Client Asset Custody Operations", ""), ("MM", "Money Movement Operations", ""),
        ("COMM", "Client Communications", ""), ("COMP", "Compliance & Supervision", ""), ("MKT", "Marketing & Acquisition", ""),
        ("PROD", "Product Management", ""), ("DIST", "Intermediary Distribution", ""), ("CORP", "Corporate Overhead", "")]),
    "CTS_COMP_CD": dict(target=("10", "Cost-to-Serve Component"), values=[   # blank (outside cost to serve) falls through to null
        ("ADV", "Advice", ""), ("SVC", "Service", ""), ("PLAT", "Platform", ""), ("CLR", "Clearing and Client Asset Custody", ""),
        ("MM", "Money Movement", ""), ("COMM", "Communications", ""), ("REG", "Regulatory", "")]),
    "CATEGORIES": dict(target=("10", "Cost Item Category"), values=[   # applied element by element (transforms.DERIVED)
        ("ADVCOMP", "Advisor Base Compensation", ""), ("ADVINC", "Advisor Incentive Compensation", ""),
        ("SVCCOMP", "Service Staff Compensation", ""), ("MKTG", "Marketing & Acquisition Spend", ""),
        ("CLRFEE", "Clearing & Exchange Fees", ""), ("CCTECH", "Contact Center Technology", ""),
        ("PLTECH", "Platform Technology", ""), ("DATA", "Third-Party Data Licenses", ""), ("MAIL", "Statement & Mailing Costs", ""),
        ("REGFEE", "Regulatory Fees & Assessments", ""), ("REVSHR", "Revenue Sharing", ""), ("SUBTA", "Sub-TA / Networking Fees", ""),
        ("OTH", "Other", "")]),
    "METHOD_TYPE_CD": dict(target=("10", "Allocation Method Type"), values=[
        ("DIRECT", "Direct Assignment", ""), ("DRIVER", "Driver-Based", ""), ("ABC", "Activity-Based", ""),
        ("TDABC", "Time-Driven Activity-Based", ""), ("REV", "Proportional to Revenue", ""), ("FIXED", "Fixed Percentage", ""),
        ("STEP", "Step-Down", ""), ("RECIP", "Reciprocal", "")]),
    "TARGET_DIM_CD": dict(target=("10", "Profitability Dimension"), values=[
        ("SEG", "Client Segment", ""), ("CHAN", "Channel", ""), ("BL", "Business Line", ""), ("OFF", "Service Offering", ""),
        ("TIER", "Service Tier", ""), ("POOL", None, "a step-down to another cost pool is not a profitability dimension")]),
    "VERSION_CD": dict(target=("10", "Data Version"), values=[("ACT", "Actual", ""), ("BUD", "Budget", ""), ("FCST", "Forecast", "")]),
    "RUN_STATUS_CD": dict(target=("10", "Run Status"), values=[
        ("DRAFT", "Draft", ""), ("PRELIM", "Preliminary", ""), ("FINAL", "Final", ""), ("SUPER", "Superseded", "")]),
}

GAPS = [
    ("POOL_COST", "The ledger expense that flowed into each pool per run has no entity in the slice (10 Cost Pool holds no amounts); the compiler reads SRC-CST POOL_COST directly for the Pool Source Cost measure."),
    ("POOL", "Contributing Cost Centers carries the engine's '; '-separated cost center codes as text: 09 Chart Segment Value (DP-190) is not in the slice, so the codes do not resolve to cost centers."),
    ("POOL", "POOL_NM has no home on 10 Cost Pool (the taxonomy names a pool by its type)."),
    ("RULE", "Applied Driver carries the engine's DRIVER_CD (ADVHRS, HH, ACCTS, AUM, TXN, REV, CONTACTS, FIXED): no 10 Allocation Driver entity is in the slice, so it does not resolve to a driver row."),
    ("RULE", "TARGET_DIM_CD POOL (the CORP step-down to the other pools) has no Profitability Dimension value: Target Dimension is null on that rule, and its results' members are pool ids."),
    ("RESULT", "Allocation Run Key is a product key with no taxonomy attribute (the run is the Allocation Result's parent object); the row shape in compile/transforms.py fills it from RUN_ID. TARGET_DIM_CD repeats the rule's dimension and has no home of its own."),
]
