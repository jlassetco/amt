"""Confirmed mapping of SRC-INST, the institutional client platform, to the taxonomy. See CONTRACT.md.

The platform is the system of record for institutional clients (12 Institutional Client, with their 02 party), their
service relationships and OCIO terms (12), the mandates the firm manages for them (01 Investment Mandate), the quarterly
relationship health scores (12) and the consulting firms that advise them (02 parties, 05 consultant profile and
advisory relationship). Its fund account list says which transfer agent accounts the clients own (15 Account Party
Role). Enterprise keys: PTY-INST-<client id>, PTY-CONS-<consultant id>; relationships and mandates keep the platform's
own ids (SR-, MD-); strategies are STR-<strategy code>.
"""

SOURCE = dict(
    id="SRC-INST", name="Institutional Client Platform", kind="System of record for institutional relationships",
    identifier_schemes={
        "CLIENT_ID": ("02", "Identifier Scheme", "CRM ID"),
        "CONSULTANT_ID": ("02", "Identifier Scheme", "CRM ID"),
        "EIN": ("02", "Identifier Scheme", "EIN"),
    })

OBJECTS = [
    ("CLIENT", ("02", "Party"), "one party per institutional client (plan, nonprofit, corporation or government body)"),
    ("CLIENT", ("02", "Organization"), "legal name"),
    ("CLIENT", ("02", "US Regulatory Identifier"), "the EIN"),
    ("CLIENT", ("02", "Party Identifier"), "the platform client id and the EIN"),
    ("CLIENT", ("12", "Institutional Client"), "one row per client"),
    ("CLIENT", ("05", "Consultant Advisory Relationship"), "the client's advising consultant firm, where it has one"),
    ("RELATIONSHIP", ("12", "Service Relationship"), "one row per service relationship"),
    ("RELATIONSHIP", ("12", "OCIO Service Detail"), "delegation scope and ERISA status (OCIO relationships)"),
    ("MANDATE", ("01", "Investment Mandate"), "one row per mandate"),
    ("HEALTH_SCORE", ("12", "Relationship Health Score"), "one row per relationship x score date"),
    ("FUND_ACCOUNT", ("15", "Account Party Role"), "the client as primary owner of each direct institutional fund account"),
    ("CONSULTANT", ("02", "Party"), "one Corporation party per consulting firm"),
    ("CONSULTANT", ("02", "Organization"), "legal name"),
    ("CONSULTANT", ("02", "Party Identifier"), "the platform consultant id"),
    ("CONSULTANT", ("05", "Consultant Profile"), "consultant type"),
]

ATTRIBUTES = [
    # CLIENT -> 02 Party / Organization / US Regulatory Identifier / Party Identifier
    ("CLIENT", "CLIENT_ID", ("02", "Party", "Party ID"), "derived", "'PTY-INST-' || CLIENT_ID"),
    ("CLIENT", "ENTITY_KIND_CD", ("02", "Party", "Party Type"), "crosswalk", "ENTITY_KIND_CD"),
    ("CLIENT", "CLIENT_NAME", ("02", "Party", "Party Display Name"), "direct", ""),
    ("CLIENT", "STATUS_CD", ("02", "Party", "Party Status"), "crosswalk", "CLIENT_PARTY_STATUS"),
    ("CLIENT", "STATUS_CD", ("02", "Party", "Relationship Stage"), "crosswalk", "CLIENT_STAGE"),
    ("CLIENT", "", ("02", "Party", "Party Origin"), "unmapped", "the platform does not record how the institution came to the firm"),
    ("CLIENT", "", ("02", "Party", "Primary Country"), "constant", "US"),
    ("CLIENT", "LEGAL_NAME", ("02", "Organization", "Legal Name"), "direct", ""),
    ("CLIENT", "", ("02", "Organization", "Legal Form"), "unmapped", "the platform keeps a legal nature (ENTITY_KIND_CD), not an ISO 20275 legal form"),
    ("CLIENT", "", ("02", "Organization", "Legal Jurisdiction"), "unmapped", "the state of organization is not extracted"),
    ("CLIENT", "", ("02", "Organization", "Industry Classification"), "unmapped", "no NAICS code on the platform"),
    ("CLIENT", "", ("02", "Organization", "Primary Regulator"), "unmapped", "the platform does not record the client's regulators"),
    ("CLIENT", "EIN", ("02", "US Regulatory Identifier", "Employer Identification Number"), "direct", ""),
    ("CLIENT", "CLIENT_ID", ("02", "Party Identifier", "Identifier Value"), "identifier", "CLIENT_ID"),
    ("CLIENT", "EIN", ("02", "Party Identifier", "Identifier Value"), "identifier", "EIN"),
    ("CLIENT", "CLIENT_ID", ("02", "Party Identifier", "Identified Party"), "derived", "'PTY-INST-' || CLIENT_ID"),
    ("CLIENT", "EIN", ("02", "Party Identifier", "Identifier Scheme"), "derived", "'CRM ID' for the CLIENT_ID row, 'EIN' for the EIN row"),
    ("CLIENT", "", ("02", "Party Identifier", "Identifier Status"), "constant", "Active"),
    ("CLIENT", "", ("02", "Party Identifier", "Identifier Effective From"), "unmapped", "the platform keeps no identifier history"),
    # CLIENT -> 12 Institutional Client
    ("CLIENT", "CLIENT_ID", ("12", "Institutional Client", "Institutional Client Party"), "derived", "'PTY-INST-' || CLIENT_ID"),
    ("CLIENT", "CLIENT_TYPE_CD", ("12", "Institutional Client", "Institutional Client Type"), "crosswalk", "CLIENT_TYPE_CD"),
    ("CLIENT", "BUS_LINE_CD", ("12", "Institutional Client", "Primary Business Line"), "crosswalk", "BUS_LINE_CD"),
    ("CLIENT", "INVESTABLE_ASSETS", ("12", "Institutional Client", "Total Investable Assets"), "direct", "all managers, as the client reports"),
    ("CLIENT", "ASSETS_ASOF_DT", ("12", "Institutional Client", "Assets As-Of Date"), "direct", ""),
    ("CLIENT", "GOVERNANCE_CD", ("12", "Institutional Client", "Governance Model"), "crosswalk", "GOVERNANCE_CD"),
    ("CLIENT", "GOV_ENTITY_FLG", ("12", "Institutional Client", "Government Entity Indicator"), "direct", ""),
    ("CLIENT", "ERISA_FLG", ("12", "Institutional Client", "ERISA Plan Indicator"), "direct", ""),
    ("CLIENT", "", ("12", "Institutional Client", "Funded Status"), "unmapped", "the platform does not hold actuarial funded status"),
    ("CLIENT", "", ("12", "Institutional Client", "Funded Status As-Of Date"), "unmapped", "as above"),
    ("CLIENT", "", ("12", "Institutional Client", "UPMIFA Applicability Indicator"), "unmapped", "not recorded"),
    ("CLIENT", "", ("12", "Institutional Client", "Fiscal Year End"), "unmapped", "not recorded"),
    # CLIENT -> 05 Consultant Advisory Relationship (outside the slice)
    ("CLIENT", "CONSULTANT_ID", ("05", "Consultant Advisory Relationship", "Consultant Firm"), "derived", "'PTY-CONS-' || CONSULTANT_ID where CONSULTANT_ID is not blank"),
    ("CLIENT", "CLIENT_ID", ("05", "Consultant Advisory Relationship", "Advised Client"), "derived", "'PTY-INST-' || CLIENT_ID"),
    ("CLIENT", "", ("05", "Consultant Advisory Relationship", "Consulting Engagement Type"), "unmapped", "the platform records the consultant, not the engagement terms"),
    ("CLIENT", "", ("05", "Consultant Advisory Relationship", "Engagement Effective From"), "unmapped", "no engagement dates on the platform"),
    # RELATIONSHIP -> 12 Service Relationship / OCIO Service Detail
    ("RELATIONSHIP", "REL_ID", ("12", "Service Relationship", "Service Relationship ID"), "direct", ""),
    ("RELATIONSHIP", "CLIENT_ID", ("12", "Service Relationship", "Client"), "derived", "'PTY-INST-' || CLIENT_ID"),
    ("RELATIONSHIP", "SEGMENT_CD", ("12", "Service Relationship", "Servicing Segment"), "crosswalk", "SEGMENT_CD"),
    ("RELATIONSHIP", "BUS_LINE_CD", ("12", "Service Relationship", "Relationship Business Line"), "crosswalk", "BUS_LINE_CD"),
    ("RELATIONSHIP", "REL_ID", ("12", "Service Relationship", "Serviced Mandates"), "derived", "the MANDATE_IDs of the MANDATE rows under REL_ID, '; '-separated"),
    ("RELATIONSHIP", "CONSULTANT_ID", ("12", "Service Relationship", "Advising Consultant"), "derived", "'PTY-CONS-' || CONSULTANT_ID (the consultant firm's party; see GAPS)"),
    ("RELATIONSHIP", "TIER_CD", ("12", "Service Relationship", "Service Tier"), "crosswalk", "TIER_CD"),
    ("RELATIONSHIP", "START_DT", ("12", "Service Relationship", "Relationship Start Date"), "direct", ""),
    ("RELATIONSHIP", "STATUS_CD", ("12", "Service Relationship", "Service Relationship Status"), "crosswalk", "REL_STATUS_CD"),
    ("RELATIONSHIP", "", ("12", "Service Relationship", "Servicing Legal Entity"), "unmapped", "the platform does not record which entity contracts the service"),
    ("RELATIONSHIP", "OCIO_SCOPE_CD", ("12", "OCIO Service Detail", "OCIO Delegation Scope"), "crosswalk", "OCIO_SCOPE_CD"),
    ("RELATIONSHIP", "ERISA_FID_CD", ("12", "OCIO Service Detail", "ERISA Fiduciary Status"), "crosswalk", "ERISA_FID_CD"),
    ("RELATIONSHIP", "", ("12", "OCIO Service Detail", "Total Portfolio Indicator"), "unmapped", "the delegation scope does not say whether the OCIO runs the whole portfolio"),
    ("RELATIONSHIP", "", ("12", "OCIO Service Detail", "Delegated Asset Share"), "unmapped", "the platform holds no delegated share of the client's assets"),
    ("RELATIONSHIP", "", ("12", "OCIO Service Detail", "Governing IPS"), "unmapped", "investment policy statements (12) are not extracted"),
    ("RELATIONSHIP", "", ("12", "OCIO Service Detail", "OCIO Service Offering"), "unmapped", "the OCIO offering is not recorded on the relationship"),
    # MANDATE -> 01 Investment Mandate
    ("MANDATE", "MANDATE_ID", ("01", "Investment Mandate", "Mandate ID"), "direct", ""),
    ("MANDATE", "MANDATE_NM", ("01", "Investment Mandate", "Mandate Name"), "direct", ""),
    ("MANDATE", "MANDATE_TYPE_CD", ("01", "Investment Mandate", "Mandate Type"), "crosswalk", "MANDATE_TYPE_CD"),
    ("MANDATE", "CLIENT_ID", ("01", "Investment Mandate", "Client"), "derived", "'PTY-INST-' || CLIENT_ID"),
    ("MANDATE", "STRATEGY_CD", ("01", "Investment Mandate", "Implemented Strategy"), "derived", "'STR-' || STRATEGY_CD"),
    ("MANDATE", "", ("01", "Investment Mandate", "Investment Management Agreement Date"), "unmapped", "the IMA date is not extracted; INCEPT_DT is the funding date, not the agreement date"),
    # HEALTH_SCORE -> 12 Relationship Health Score
    ("HEALTH_SCORE", "SCORE_DT", ("12", "Relationship Health Score", "Health Score Date"), "direct", ""),
    ("HEALTH_SCORE", "REL_ID", ("12", "Relationship Health Score", "Scored Relationship"), "direct", "the Service Relationship ID"),
    ("HEALTH_SCORE", "SCORE", ("12", "Relationship Health Score", "Overall Health Score"), "direct", "0 to 100"),
    ("HEALTH_SCORE", "RAG_CD", ("12", "Relationship Health Score", "Health Status"), "crosswalk", "RAG_CD"),
    ("HEALTH_SCORE", "AT_RISK_FLG", ("12", "Relationship Health Score", "At-Risk Indicator"), "direct", ""),
    ("HEALTH_SCORE", "AT_RISK_RSN_CD", ("12", "Relationship Health Score", "At-Risk Reason"), "crosswalk", "AT_RISK_RSN_CD"),
    ("HEALTH_SCORE", "SURVEY_ID", ("12", "Relationship Health Score", "Survey Inputs"), "derived", "'SVR-' || SURVEY_ID (null when blank; see GAPS)"),
    # FUND_ACCOUNT -> 15 Account Party Role (the client owns its direct institutional fund accounts)
    ("FUND_ACCOUNT", "", ("15", "Account Party Role", "Account Role Type"), "constant", "Primary Owner"),
    ("FUND_ACCOUNT", "CLIENT_ID", ("15", "Account Party Role", "Role Party"), "derived", "'PTY-INST-' || CLIENT_ID"),
    ("FUND_ACCOUNT", "TA_ACCT_NO", ("15", "Account Party Role", "Role Account"), "derived", "'ACC-TA-' || TA_ACCT_NO"),
    ("FUND_ACCOUNT", "TA_ACCT_NO", ("15", "Account Party Role", "Account Role Effective From"), "derived", "the register's ESTAB_DT of the account (SRC-TA SHR_ACCT)"),
    ("FUND_ACCOUNT", "", ("15", "Account Party Role", "Account Role Effective To"), "unmapped", "the fund account list keeps current ownership only"),
    # CONSULTANT -> 02 Party / Organization / Party Identifier, 05 Consultant Profile
    ("CONSULTANT", "CONSULTANT_ID", ("02", "Party", "Party ID"), "derived", "'PTY-CONS-' || CONSULTANT_ID"),
    ("CONSULTANT", "", ("02", "Party", "Party Type"), "constant", "Corporation"),
    ("CONSULTANT", "CONSULTANT_NM", ("02", "Party", "Party Display Name"), "direct", ""),
    ("CONSULTANT", "", ("02", "Party", "Party Status"), "constant", "Active"),
    ("CONSULTANT", "", ("02", "Party", "Relationship Stage"), "constant", "Related Party"),
    ("CONSULTANT", "CONSULTANT_NM", ("02", "Organization", "Legal Name"), "direct", "the platform holds one firm name"),
    ("CONSULTANT", "CONSULTANT_ID", ("02", "Party Identifier", "Identifier Value"), "identifier", "CONSULTANT_ID"),
    ("CONSULTANT", "CONSULTANT_ID", ("02", "Party Identifier", "Identified Party"), "derived", "'PTY-CONS-' || CONSULTANT_ID"),
    ("CONSULTANT", "", ("02", "Party Identifier", "Identifier Scheme"), "constant", "CRM ID"),
    ("CONSULTANT", "", ("02", "Party Identifier", "Identifier Status"), "constant", "Active"),
    ("CONSULTANT", "CONSULTANT_ID", ("05", "Consultant Profile", "Consultant Party"), "derived", "'PTY-CONS-' || CONSULTANT_ID"),
    ("CONSULTANT", "CONSULTANT_TYPE_CD", ("05", "Consultant Profile", "Consultant Type"), "crosswalk", "CONSULTANT_TYPE_CD"),
    ("CONSULTANT", "CONSULTANT_TYPE_CD", ("05", "Consultant Profile", "Competing OCIO Indicator"), "derived", "CONSULTANT_TYPE_CD = 'OCIO'"),
    ("CONSULTANT", "", ("05", "Consultant Profile", "Assets Under Advisement"), "unmapped", "not recorded"),
]

CROSSWALKS = {
    "ENTITY_KIND_CD": dict(target=("02", "Party Type"), values=[
        ("PLAN", "Retirement Plan", ""), ("CORP", "Corporation", ""), ("NPO", "Nonprofit", ""), ("GOV", "Government", "")]),
    "CLIENT_PARTY_STATUS": dict(target=("02", "Party Status"), values=[
        ("A", "Active", ""), ("P", "Active", "a prospect is an active party; the stage says prospect"), ("T", "Inactive", "")]),
    "CLIENT_STAGE": dict(target=("02", "Relationship Stage"), values=[
        ("A", "Client", ""), ("P", "Prospect", ""), ("T", "Former Client", "")]),
    "CLIENT_TYPE_CD": dict(target=("12", "Institutional Client Type"), values=[
        ("PPP", "Public Pension Plan", ""), ("CDB", "Corporate DB Plan", ""), ("CDC", "Corporate DC Plan Sponsor", ""),
        ("END", "Endowment", ""), ("FND", "Foundation", ""), ("HLTH", "Health System", ""), ("INS", "Insurance General Account", ""),
        ("TH", "Taft-Hartley / Multiemployer Plan", ""), ("GOV", "Government Entity", ""), ("OTH", "Other", "")]),
    "BUS_LINE_CD": dict(target=("12", "Business Line"), values=[
        ("IA", "Institutional advisory", ""), ("PF", "Proprietary funds and ETFs", "")]),
    "GOVERNANCE_CD": dict(target=("12", "Governance Model"), values=[
        ("CIO", "Internal CIO / Staff", ""), ("ICC", "Investment Committee with Consultant", ""), ("ICO", "Investment Committee with OCIO", ""),
        ("BTC", "Board / Trustees with Consultant", ""), ("DEL", "Fully Delegated (OCIO)", "")]),
    "SEGMENT_CD": dict(target=("12", "Servicing Segment"), values=[
        ("OCIO", "OCIO", ""), ("SEP", "Institutional Separate Account", ""), ("POOL", "Institutional Pooled (Fund or CIT)", ""),
        ("RK", "Plan Sponsor - Recordkept", ""), ("CIT", "Plan Sponsor - CIT Only", "")]),
    "TIER_CD": dict(target=("12", "Institutional Service Tier"), values=[
        ("T1", "Tier 1 - Strategic", ""), ("T2", "Tier 2 - Core", ""), ("T3", "Tier 3 - Standard", ""), ("T4", "Tier 4 - Pooled / Digital", "")]),
    "REL_STATUS_CD": dict(target=("12", "Service Relationship Status"), values=[
        ("ONB", "Onboarding", ""), ("ACT", "Active", ""), ("NOT", "Under Notice", ""), ("TRM", "Terminated", ""), ("DRM", "Dormant", "")]),
    "OCIO_SCOPE_CD": dict(target=("12", "OCIO Delegation Scope"), values=[
        ("FULL", "Full Discretion", ""), ("PART", "Partial Discretion", ""), ("ADV", "Non-Discretionary (Advisory)", "")]),
    "ERISA_FID_CD": dict(target=("12", "ERISA Fiduciary Status"), values=[
        ("338", "ERISA 3(38) Investment Manager", ""), ("321", "ERISA 3(21) Co-Fiduciary Adviser", ""), ("NONE", "Not ERISA", "")]),
    "MANDATE_TYPE_CD": dict(target=("01", "Mandate Type"), values=[
        ("SEG", "Segregated Account", ""), ("SUB", "Sub-Advisory", ""), ("FOO", "Fund of One", "")]),
    "RAG_CD": dict(target=("12", "RAG Status"), values=[("G", "Green", ""), ("A", "Amber", ""), ("R", "Red", "")]),
    "AT_RISK_RSN_CD": dict(target=("12", "At-Risk Reason"), values=[   # blank (not at risk) falls through to null
        ("PERF", "Underperformance", ""), ("PERS", "Personnel Change", ""), ("SERV", "Service Issues", ""),
        ("STRAT", "Client Strategy Change", ""), ("FEE", "Fee Pressure", ""), ("CONS", "Consultant Rating Change", ""),
        ("SPON", "Plan Sponsor Event", "")]),
    "CONSULTANT_TYPE_CD": dict(target=("05", "Consultant Type"), values=[
        ("GEN", "Full-Service Investment Consultant", ""), ("SPEC", "Specialist Consultant", ""), ("OCIO", "OCIO / Fiduciary Manager", "a competing OCIO")]),
}

GAPS = [
    ("CLIENT", "SEGMENT_CD (the client's primary servicing segment) has no home on 12 Institutional Client: the taxonomy holds the segment per service relationship (RELATIONSHIP.SEGMENT_CD, mapped)."),
    ("RELATIONSHIP", "Advising Consultant references 05 Consultant Advisory Relationship, which has no single key; the column carries the consultant firm's party (PTY-CONS-) until the engagement is sourced. Candidate: a Consultant Advisory Relationship ID."),
    ("MANDATE", "STATUS_CD and INCEPT_DT have no home on 01 Investment Mandate (status and funding live on the 12 Mandate Onboarding and Mandate Termination events, not extracted); REL_ID feeds Service Relationship Serviced Mandates."),
    ("MANDATE", "STRATEGY_CD is minted as STR-<code>, but no extract carries 01 Investment Strategy (the codes are the pooled equivalents' SRC-TA PRODUCT_CDs), so Implemented Strategy does not resolve to a strategy row."),
    ("HEALTH_SCORE", "SURVEY_ID feeds Survey Inputs (a reference to 04 Survey Response), which is outside the slice's Fact Health Score and has no survey extract to resolve against."),
    ("FUND_ACCOUNT", "REL_ID (the relationship a fund account is served under) has no home in 15 or 12; DP-510 attributes account assets to relationships through the client and the register."),
]
