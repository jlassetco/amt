"""Confirmed mapping of SRC-PAB, the portfolio accounting book of record for institutional separate accounts, to the
taxonomy. See CONTRACT.md.

The book is the system of record for separate-account portfolios (18 Portfolio and the link to the mandate each
implements), their month-end holdings and valuation summaries (18), and, because each portfolio is the client's
separate account, the institutional account itself (15 Account, its custodian account number and its primary owner).
Enterprise keys: portfolios keep the book's id (P-), ACC-PAB-<portfolio id>, ACI-PAB-<portfolio id>,
HLD-<portfolio>-<security>-<date>, INS-<CUSIP>, PTY-INST-<client id>, PTY-CUST-<custodian code>, LE-<managing entity>.
"""

SOURCE = dict(
    id="SRC-PAB", name="Portfolio Accounting Book of Record", kind="System of record for separate-account portfolios",
    identifier_schemes={
        "CUSTODY_ACCT_NO": ("15", "Account Identifier Scheme", "Custodian Account Number"),
    })

OBJECTS = [
    ("PORTFOLIO", ("18", "Portfolio"), "one portfolio per separate account"),
    ("PORTFOLIO", ("18", "Portfolio Implementation Link"), "the mandate each portfolio implements"),
    ("PORTFOLIO", ("15", "Account"), "one Institutional Separate Account per portfolio"),
    ("PORTFOLIO", ("15", "Account Registration Detail"), "registration line from the client's legal name"),
    ("PORTFOLIO", ("15", "Institutional Account"), "related mandate and custodian"),
    ("PORTFOLIO", ("15", "Account Identifier"), "the custodian account number"),
    ("PORTFOLIO", ("15", "Account Party Role"), "the client as primary owner"),
    ("PORTFOLIO", ("12", "Client Custodian Account"), "the custody set-up of each portfolio"),
    ("VALUATION", ("18", "Portfolio Valuation Summary"), "one row per portfolio x month-end"),
    ("HOLDING", ("18", "Portfolio Holding"), "one row per portfolio x security x month-end"),
    ("HOLDING", ("18", "Holding Valuation"), "price and market value"),
]

ATTRIBUTES = [
    # PORTFOLIO -> 18 Portfolio
    ("PORTFOLIO", "PORT_ID", ("18", "Portfolio", "Portfolio ID"), "direct", ""),
    ("PORTFOLIO", "PORT_NAME", ("18", "Portfolio", "Portfolio Name"), "direct", ""),
    ("PORTFOLIO", "PORT_TYPE_CD", ("18", "Portfolio", "Portfolio Type"), "crosswalk", "PORT_TYPE_CD"),
    ("PORTFOLIO", "", ("18", "Portfolio", "Business Line"), "constant", "Institutional advisory"),
    ("PORTFOLIO", "STATUS_CD", ("18", "Portfolio", "Portfolio Status"), "crosswalk", "PORT_STATUS_CD"),
    ("PORTFOLIO", "BASE_CCY", ("18", "Portfolio", "Base Currency"), "direct", ""),
    ("PORTFOLIO", "", ("18", "Portfolio", "Legal Owner Entity"), "unmapped", "LEGAL_OWNER_CD CLIENT: the client owns the assets, so no firm legal entity is the owner"),
    ("PORTFOLIO", "MGMT_ENTITY_CD", ("18", "Portfolio", "Managing Entity"), "derived", "'LE-' || MGMT_ENTITY_CD"),
    ("PORTFOLIO", "LEGAL_OWNER_CD", ("18", "Portfolio", "Proprietary Capital Indicator"), "derived", "LEGAL_OWNER_CD <> 'CLIENT'"),
    ("PORTFOLIO", "INCEPT_DT", ("18", "Portfolio", "Inception Date"), "direct", ""),
    ("PORTFOLIO", "", ("18", "Portfolio", "Termination Date"), "unmapped", "the book extract carries status only, no termination date"),
    ("PORTFOLIO", "", ("18", "Portfolio", "Safekeeping Custody Account"), "unmapped", "28 safekeeping accounts are not sourced; the custody account number lands as the account's Custodian Account Number"),
    # PORTFOLIO -> 18 Portfolio Implementation Link
    ("PORTFOLIO", "PORT_ID", ("18", "Portfolio Implementation Link", "Implementing Portfolio"), "direct", ""),
    ("PORTFOLIO", "", ("18", "Portfolio Implementation Link", "Implementation Link Type"), "constant", "Implements Mandate"),
    ("PORTFOLIO", "MANDATE_ID", ("18", "Portfolio Implementation Link", "Implemented Mandate"), "direct", "the Mandate ID (SRC-INST)"),
    ("PORTFOLIO", "", ("18", "Portfolio Implementation Link", "Primary Implementation Indicator"), "constant", "true"),
    ("PORTFOLIO", "INCEPT_DT", ("18", "Portfolio Implementation Link", "Implementation Effective From"), "direct", "the portfolio's inception"),
    # PORTFOLIO -> 15 Account and its groups
    ("PORTFOLIO", "PORT_ID", ("15", "Account", "Account ID"), "derived", "'ACC-PAB-' || PORT_ID"),
    ("PORTFOLIO", "", ("15", "Account", "Account Type"), "constant", "Institutional Separate Account"),
    ("PORTFOLIO", "PORT_NAME", ("15", "Account", "Account Name"), "direct", ""),
    ("PORTFOLIO", "CUSTODY_ACCT_NO", ("15", "Account", "External Account Number"), "direct", "the custodian's account number"),
    ("PORTFOLIO", "CLIENT_ID", ("15", "Account", "Account Registration Type"), "derived", "from the client's legal nature (SRC-INST CLIENT.ENTITY_KIND_CD): PLAN 'Retirement Plan Trust', NPO 'Nonprofit', CORP 'Corporate'; GOV has no value (GAPS)"),
    ("PORTFOLIO", "STATUS_CD", ("15", "Account", "Account Status"), "crosswalk", "ACCT_STATUS_CD"),
    ("PORTFOLIO", "INCEPT_DT", ("15", "Account", "Account Open Date"), "direct", ""),
    ("PORTFOLIO", "", ("15", "Account", "Account Close Date"), "unmapped", "the book extract carries no termination date"),
    ("PORTFOLIO", "", ("15", "Account", "Reg T Account Type"), "unmapped", "a separate account at a custodian bank is not a brokerage margin account; Regulation T does not apply"),
    ("PORTFOLIO", "MGMT_ENTITY_CD", ("15", "Account", "Carrying Entity"), "derived", "'LE-' || MGMT_ENTITY_CD (the adviser carries the advisory account; the custodian holds the assets)"),
    ("PORTFOLIO", "", ("15", "Account", "Account Purpose"), "unmapped", "not recorded"),
    ("PORTFOLIO", "", ("15", "Account", "Account Business Line"), "constant", "Institutional advisory"),
    ("PORTFOLIO", "CLIENT_ID", ("15", "Account Registration Detail", "Registration Line 1"), "derived", "the client's LEGAL_NAME (SRC-INST CLIENT)"),
    ("PORTFOLIO", "", ("15", "Account Registration Detail", "Entity Account Indicator"), "constant", "true"),
    ("PORTFOLIO", "MANDATE_ID", ("15", "Institutional Account", "Related Mandate"), "direct", "the Mandate ID (SRC-INST)"),
    ("PORTFOLIO", "CUSTODIAN_CD", ("15", "Institutional Account", "Custodian"), "derived", "'PTY-CUST-' || CUSTODIAN_CD (see GAPS)"),
    ("PORTFOLIO", "", ("15", "Institutional Account", "Governing Agreement"), "unmapped", "investment management agreements are not extracted"),
    # PORTFOLIO -> 15 Account Identifier
    ("PORTFOLIO", "PORT_ID", ("15", "Account Identifier", "Account Identifier ID"), "derived", "'ACI-PAB-' || PORT_ID"),
    ("PORTFOLIO", "PORT_ID", ("15", "Account Identifier", "Identified Account"), "derived", "'ACC-PAB-' || PORT_ID"),
    ("PORTFOLIO", "", ("15", "Account Identifier", "Account Identifier Scheme"), "constant", "Custodian Account Number"),
    ("PORTFOLIO", "CUSTODY_ACCT_NO", ("15", "Account Identifier", "Account Identifier Value"), "identifier", "CUSTODY_ACCT_NO"),
    ("PORTFOLIO", "CUSTODIAN_CD", ("15", "Account Identifier", "Issuing Party"), "derived", "'PTY-CUST-' || CUSTODIAN_CD"),
    ("PORTFOLIO", "", ("15", "Account Identifier", "Primary Identifier Indicator"), "constant", "Y"),
    ("PORTFOLIO", "", ("15", "Account Identifier", "Account Identifier Status"), "constant", "Active"),
    ("PORTFOLIO", "INCEPT_DT", ("15", "Account Identifier", "Identifier Effective From"), "direct", ""),
    # PORTFOLIO -> 15 Account Party Role (the client owns the separate account)
    ("PORTFOLIO", "", ("15", "Account Party Role", "Account Role Type"), "constant", "Primary Owner"),
    ("PORTFOLIO", "CLIENT_ID", ("15", "Account Party Role", "Role Party"), "derived", "'PTY-INST-' || CLIENT_ID"),
    ("PORTFOLIO", "PORT_ID", ("15", "Account Party Role", "Role Account"), "derived", "'ACC-PAB-' || PORT_ID"),
    ("PORTFOLIO", "INCEPT_DT", ("15", "Account Party Role", "Account Role Effective From"), "direct", ""),
    ("PORTFOLIO", "", ("15", "Account Party Role", "Account Role Effective To"), "unmapped", "no termination date in the book"),
    # PORTFOLIO -> 12 Client Custodian Account (outside the slice)
    ("PORTFOLIO", "PORT_ID", ("12", "Client Custodian Account", "Client Custodian Account Set-Up ID"), "derived", "'CCA-' || PORT_ID"),
    ("PORTFOLIO", "PORT_ID", ("12", "Client Custodian Account", "Client Account"), "derived", "'ACC-PAB-' || PORT_ID"),
    ("PORTFOLIO", "MANDATE_ID", ("12", "Client Custodian Account", "Client Custodian Mandate"), "direct", ""),
    ("PORTFOLIO", "CUSTODIAN_CD", ("12", "Client Custodian Account", "Custodian"), "derived", "'PTY-CUST-' || CUSTODIAN_CD"),
    ("PORTFOLIO", "CUSTODIAN_CD", ("12", "Client Custodian Account", "Custodian BIC"), "derived",
     "case CUSTODIAN_CD when 'NTRS' then 'CNORUS44' when 'BNYM' then 'IRVTUS3N' when 'STT' then 'SBOSUS33' when 'JPM' then 'CHASUS33' end"),
    ("PORTFOLIO", "CUSTODY_ACCT_NO", ("12", "Client Custodian Account", "Safekeeping Account Number"), "direct", ""),
    # VALUATION -> 18 Portfolio Valuation Summary
    ("VALUATION", "PORT_ID", ("18", "Portfolio Valuation Summary", "Valued Portfolio"), "direct", ""),
    ("VALUATION", "ASOF_DT", ("18", "Portfolio Valuation Summary", "Valuation As-Of Date"), "direct", ""),
    ("VALUATION", "VIEW_CD", ("18", "Portfolio Valuation Summary", "Valuation View"), "crosswalk", "VIEW_CD"),
    ("VALUATION", "", ("18", "Portfolio Valuation Summary", "Valuation Period Type"), "constant", "Month"),
    ("VALUATION", "HOLDINGS_MKT_VAL", ("18", "Portfolio Valuation Summary", "Total Holdings Market Value"), "direct", ""),
    ("VALUATION", "CASH_VAL", ("18", "Portfolio Valuation Summary", "Total Cash Balance"), "direct", ""),
    ("VALUATION", "ACCRUED_INCOME", ("18", "Portfolio Valuation Summary", "Total Accrued Income"), "direct", ""),
    ("VALUATION", "TOTAL_MKT_VAL", ("18", "Portfolio Valuation Summary", "Total IBOR Market Value"), "direct", "holdings + cash + accrued"),
    ("VALUATION", "", ("18", "Portfolio Valuation Summary", "Summary Data Basis"), "constant", "Reported / Actual"),
    ("VALUATION", "", ("18", "Portfolio Valuation Summary", "Summary Snapshot"), "unmapped", "18 position snapshots are not extracted"),
    # HOLDING -> 18 Portfolio Holding / Holding Valuation
    ("HOLDING", "SECURITY_ID", ("18", "Portfolio Holding", "Holding ID"), "derived", "'HLD-' || PORT_ID || '-' || SECURITY_ID || '-' || ASOF_DT"),
    ("HOLDING", "PORT_ID", ("18", "Portfolio Holding", "Holding Portfolio"), "direct", ""),
    ("HOLDING", "SECURITY_ID", ("18", "Portfolio Holding", "Held Instrument"), "derived", "'INS-' || SECURITY_ID"),
    ("HOLDING", "ASOF_DT", ("18", "Portfolio Holding", "Holding Date"), "direct", ""),
    ("HOLDING", "VIEW_CD", ("18", "Portfolio Holding", "Holding View"), "crosswalk", "VIEW_CD"),
    ("HOLDING", "QTY", ("18", "Portfolio Holding", "Holding Quantity"), "direct", ""),
    ("HOLDING", "QTY", ("18", "Portfolio Holding", "Long / Short Indicator"), "derived", "case when try_cast(QTY as double) < 0 then 'Short' else 'Long' end"),
    ("HOLDING", "", ("18", "Portfolio Holding", "Settled Quantity"), "unmapped", "the book extract holds traded quantity only"),
    ("HOLDING", "PRICE", ("18", "Holding Valuation", "Price Used"), "direct", ""),
    ("HOLDING", "ASOF_DT", ("18", "Holding Valuation", "Price Date"), "direct", "month-end prices"),
    ("HOLDING", "MKT_VAL", ("18", "Holding Valuation", "Market Value Local"), "direct", ""),
    ("HOLDING", "MKT_VAL", ("18", "Holding Valuation", "Market Value Base"), "direct", "the book values every holding in the portfolio's base currency (USD)"),
    ("HOLDING", "", ("18", "Holding Valuation", "Holding Cost Base"), "unmapped", "tax lots and cost are not extracted"),
]

CROSSWALKS = {
    "PORT_TYPE_CD": dict(target=("18", "Portfolio Type"), values=[
        ("SEP", "Standalone Book", ""), ("FOO", "Standalone Book", "a fund of one is its own book; the vehicle is the mandate type")]),
    "PORT_STATUS_CD": dict(target=("18", "Portfolio Status"), values=[
        ("A", "Active", ""), ("T", "Terminated", ""), ("L", "Liquidating", "")]),
    "ACCT_STATUS_CD": dict(target=("15", "Account Status"), values=[
        ("A", "Open", ""), ("L", "Open", "an account in liquidation stays open until it is closed"), ("T", "Closed", "")]),
    "VIEW_CD": dict(target=("18", "Holding View"), values=[("EOD", "End of Day", "")]),
}

GAPS = [
    ("PORTFOLIO", "CUSTODIAN_CD names the custodian bank (NTRS, BNYM, STT, JPM) but no extract carries custodians as parties: the PTY-CUST- keys in Custodian and Issuing Party do not resolve until a counterparty master (02 Financial Institution parties with BIC identifiers) is sourced."),
    ("PORTFOLIO", "PORT_ID keys the account (ACC-PAB-) but 15 Account Identifier Scheme has no portfolio accounting system value, so the book's own id is not an account identifier. Candidate: 'Portfolio Accounting System ID'."),
    ("PORTFOLIO", "A government body's account (CLIENT.ENTITY_KIND_CD GOV) has no 15 Account Registration Type value (Corporate, Nonprofit and Retirement Plan Trust do not fit); the registration is null. Candidate: 'Government Entity'."),
    ("HOLDING", "ASSET_CLS_CD (EQ, FI, CASH, OWNF) has no home on 18 Portfolio Holding: classification belongs to the instrument (17) and own fund products (01), which the brokerage security master and the register supply."),
]
