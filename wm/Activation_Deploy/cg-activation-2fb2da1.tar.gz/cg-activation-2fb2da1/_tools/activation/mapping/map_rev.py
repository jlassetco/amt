"""Confirmed mapping of SRC-REV, the revenue sub-ledger, to the taxonomy. See CONTRACT.md.

The sub-ledger is the system of record for recognized revenue (10): client revenue per brokerage account, revenue
stream and fiscal month (10 Client Revenue Record), and the management fee revenue of the firm's own funds per share
class and fiscal month (10 Fee Revenue Record). Enterprise keys: CRR-<record id>, FRR-<record id>,
ACC-BRK-<account number>, OFF-<offering code>, LE-<legal entity code>, SHC-<fund number> (the TA mapping's share class
key), fiscal periods FY<yyyy>-M<mm> (DP-013 Fiscal Period), calculations FR-<run>|FSA-<assignment> (map_bil.py).
Channels are the certified Distribution Channel keys (DIRECT_SELF_DIRECTED ...), as the client-asset family keys them.
"""

SOURCE = dict(
    id="SRC-REV", name="Revenue Sub-Ledger", kind="System of record for recognized revenue",
    identifier_schemes={})

OBJECTS = [
    ("CLIENT_REV", ("10", "Client Revenue Record"), "one row per account x stream x fiscal month"),
    ("FUND_REV", ("10", "Fee Revenue Record"), "one row per share class x fiscal month"),
]

ATTRIBUTES = [
    # CLIENT_REV -> 10 Client Revenue Record
    ("CLIENT_REV", "REV_ID", ("10", "Client Revenue Record", "Client Revenue Record ID"), "derived", "'CRR-' || REV_ID"),
    ("CLIENT_REV", "ACCT_NO", ("10", "Client Revenue Record", "Revenue Account / Household"), "derived", "'ACC-BRK-' || ACCT_NO"),
    ("CLIENT_REV", "STREAM_CD", ("10", "Client Revenue Record", "Client Revenue Stream"), "crosswalk", "STREAM_CD"),
    ("CLIENT_REV", "OFFERING_CD", ("10", "Client Revenue Record", "Revenue Service Offering"), "derived", "'OFF-' || OFFERING_CD"),
    ("CLIENT_REV", "FISCAL_MONTH", ("10", "Client Revenue Record", "Client Revenue Period"), "derived",
     "'FY' || substr(FISCAL_MONTH, 1, 4) || '-M' || substr(FISCAL_MONTH, 6, 2)"),
    ("CLIENT_REV", "SOURCE_REF", ("10", "Client Revenue Record", "Source Calculation Record"), "derived",
     "case when SOURCE_REF like '%|%' then 'FR-' || replace(SOURCE_REF, '|', '|FSA-') end"),
    ("CLIENT_REV", "AMT", ("10", "Client Revenue Record", "Recognized Revenue Amount"), "direct", "USD"),
    ("CLIENT_REV", "LEGAL_ENT_CD", ("10", "Client Revenue Record", "Recognizing Legal Entity"), "derived", "'LE-' || LEGAL_ENT_CD"),
    ("CLIENT_REV", "CHANNEL_CD", ("10", "Client Revenue Record", "Revenue Channel"), "derived",
     "case CHANNEL_CD when 'SD' then 'DIRECT_SELF_DIRECTED' when 'DA' then 'DIRECT_DIGITAL_ADVICE' "
     "when 'HA' then 'DIRECT_HUMAN_ADVICE' when 'TR' then 'DIRECT_TRUST' end"),
    ("CLIENT_REV", "BUS_LINE_CD", ("10", "Client Revenue Record", "Revenue Business Line"), "crosswalk", "BUS_LINE_CD"),
    ("CLIENT_REV", "SEGMENT_CD", ("10", "Client Revenue Record", "Client Segment at Period End"), "direct", "CRM segment name; blank without household"),
    # FUND_REV -> 10 Fee Revenue Record
    ("FUND_REV", "REV_ID", ("10", "Fee Revenue Record", "Fee Revenue Record ID"), "derived", "'FRR-' || REV_ID"),
    ("FUND_REV", "FUND_NO", ("10", "Fee Revenue Record", "Revenue Share Class / Mandate"), "derived", "'SHC-' || FUND_NO"),
    ("FUND_REV", "FISCAL_MONTH", ("10", "Fee Revenue Record", "Revenue Accounting Period"), "derived",
     "'FY' || substr(FISCAL_MONTH, 1, 4) || '-M' || substr(FISCAL_MONTH, 6, 2)"),
    ("FUND_REV", "AVG_NET_ASSETS", ("10", "Fee Revenue Record", "Fee Basis Average Assets"), "direct", ""),
    ("FUND_REV", "BASIS_SRC_CD", ("10", "Fee Revenue Record", "Fee Basis Source"), "crosswalk", "BASIS_SRC_CD"),
    ("FUND_REV", "GROSS_RATE_BPS", ("10", "Fee Revenue Record", "Applied Gross Fee Rate"), "direct", "basis points"),
    ("FUND_REV", "GROSS_FEE", ("10", "Fee Revenue Record", "Gross Fee Revenue"), "direct", "as fund accounting accrued it"),
    ("FUND_REV", "WAIVER_OFFSET", ("10", "Fee Revenue Record", "Waiver and Reimbursement Offset"), "direct", ""),
    ("FUND_REV", "NET_FEE", ("10", "Fee Revenue Record", "Net Fee Revenue"), "direct", "the amount recognized"),
    ("FUND_REV", "BASIS_CD", ("10", "Fee Revenue Record", "Revenue Data Basis"), "crosswalk", "FUND_BASIS_CD"),
    ("FUND_REV", "SUBADV_FEE", ("10", "Fee Revenue Record", "Sub-Advisory Fee Payable"), "direct", "0 when none"),
    ("FUND_REV", "SUBADV_ENG_ID", ("10", "Fee Revenue Record", "Sub-Adviser Engagement"), "direct", "already SAE-keyed; does not resolve (GAPS)"),
]

CROSSWALKS = {
    "STREAM_CD": dict(target=("10", "Revenue Stream"), values=[
        ("ADVF", "Advisory Fee", ""), ("WRAP", "Wrap Fee", ""), ("PLAN", "Planning Fee", ""), ("SUBS", "Subscription Fee", ""),
        ("COMM", "Commission", ""), ("MKUP", "Markup / Markdown", ""), ("SVCF", "Account Service Fee", ""),
        ("MGNI", "Margin Interest", ""), ("FPLR", "Fully Paid Lending Revenue", ""), ("SWPF", "Bank Sweep Fee", ""),
        ("TRST", "Trust Fee", ""), ("ORP", "Order Routing Payment", ""), ("OTH", "Other Revenue", "")]),
    "BUS_LINE_CD": dict(target=("10", "Business Line"), values=[
        ("DB", "Direct brokerage and self-directed investing", ""), ("DA", "Digital advice", ""),
        ("HA", "Human and hybrid advice", ""), ("TR", "Personal trust services", "")]),
    "BASIS_SRC_CD": dict(target=("10", "Fee Basis Source"), values=[
        ("FA", "Fund Accounting NAV", ""), ("TA", "Transfer Agent Records", "")]),
    "FUND_BASIS_CD": dict(target=("10", "Revenue Data Basis"), values=[("FIN", "Actual", "final month"), ("EST", "Accrued Estimate", "")]),
}

GAPS = [
    ("CLIENT_REV", "BASIS_CD (ACT actual, EST accrued estimate, ALLOC allocated) has no home on 10 Client Revenue Record; every row of this extract is ACT."),
    ("CLIENT_REV", "Revenue Channel's list is the enterprise Distribution Channel (external to domain 10), so CHANNEL_CD is translated by a derived expression (SD, DA, HA, TR to DIRECT_SELF_DIRECTED, DIRECT_DIGITAL_ADVICE, DIRECT_HUMAN_ADVICE, DIRECT_TRUST) rather than a crosswalk the checker could validate."),
    ("CLIENT_REV", "Source Calculation Record carries 'FR-<run>|FSA-<assignment>' for fee streams only; the transactional streams' source records (49 activity, 50 sweep allocations) are not referenced by the sub-ledger, so it is null for them."),
    ("FUND_REV", "Sub-Adviser Engagement carries the sub-ledger's SAE- engagement id, but no source carries 52 Sub-Adviser Engagement, so it does not resolve."),
    ("FUND_REV", "CLASS_CD repeats the class of FUND_NO (the TA share class key is SHC-<fund number>); the Revenue Contract Key of the entity is not fed (no revenue contracts are sourced)."),
]
