"""Confirmed mapping of SRC-TA, the transfer agent fund share register, to the taxonomy. See CONTRACT.md.

The register is the system of record for fund-only, omnibus, plan and networked shareholder accounts of the firm's own
funds (15, carried by the transfer agent), including the direct institutional accounts of pension plans, endowments and
foundations (ACCT_TYPE_CD D, whose owners SRC-INST FUND_ACCOUNT names), the share balances and register transactions (29), and, through its fund
master, the own fund range (01: investment products and share classes). Dealers are parties (02). Enterprise keys:
ACC-TA-<account>, SHC-<fund number>, PRD-<product code>, PTY-DLR-<dealer number>, RGTX-<confirmation number>.
"""

SOURCE = dict(
    id="SRC-TA", name="Transfer Agent Fund Share Register", kind="System of record for fund shareholder accounts",
    identifier_schemes={
        "ACCT_NO": ("15", "Account Identifier Scheme", "Transfer Agent Account Number"),
        "DEALER_NO": ("02", "Identifier Scheme", "TA Dealer Number"),
        "NSCC_NO": ("02", "Identifier Scheme", "NSCC Participant Number"),
    })

OBJECTS = [
    ("FUND_MASTER", ("01", "Investment Product"), "one product per PRODUCT_CD (the classes fold into it)"),
    ("FUND_MASTER", ("01", "Fund Legal Structure"), "constants for a US 1940 Act fund family"),
    ("FUND_MASTER", ("01", "Firm Product Classification"), "asset class and business line"),
    ("FUND_MASTER", ("01", "Share Class"), "one share class per fund number"),
    ("FUND_MASTER", ("01", "Investor Eligibility"), "minimum investment and investor type"),
    ("FUND_MASTER", ("01", "Security Identifier"), "the CUSIP of the class"),
    ("FUND_MASTER", ("01", "External Cross-Reference"), "the ticker"),
    ("SHR_ACCT", ("15", "Account"), "one account per shareholder account"),
    ("SHR_ACCT", ("15", "Account Identifier"), "the transfer agent account number"),
    ("SHR_ACCT", ("15", "Account Registration Detail"), "registration lines"),
    ("SHR_ACCT", ("15", "Intermediary Account Servicing"), "dealer and networking level"),
    ("SHR_ACCT", ("15", "Retirement Account Detail"), "nothing beyond the IRA type, which refines the registration"),
    ("POSITION", ("29", "Share Register Balance"), "one balance per account x fund number x month-end"),
    ("TRANSACTION", ("29", "Register Transaction"), "one posting per confirmation"),
    ("DEALER", ("02", "Party"), "one Financial Institution party per dealer"),
    ("DEALER", ("02", "Organization"), "legal name"),
    ("DEALER", ("02", "Party Identifier"), "dealer and NSCC numbers"),
]

ATTRIBUTES = [
    # FUND_MASTER -> 01 Investment Product (one per PRODUCT_CD)
    ("FUND_MASTER", "PRODUCT_CD", ("01", "Investment Product", "Product ID"), "derived", "'PRD-' || PRODUCT_CD"),
    ("FUND_MASTER", "FUND_NM", ("01", "Investment Product", "Product Legal Name"), "direct", "the name shared by the classes"),
    ("FUND_MASTER", "FUND_NM", ("01", "Investment Product", "Product Marketing Name"), "direct", ""),
    ("FUND_MASTER", "VEHICLE_CD", ("01", "Investment Product", "Vehicle Type"), "crosswalk", "VEHICLE_CD"),
    ("FUND_MASTER", "", ("01", "Investment Product", "Base Currency"), "constant", "USD"),
    ("FUND_MASTER", "INCEPT_DT", ("01", "Investment Product", "Product Inception Date"), "derived", "min(INCEPT_DT) over the classes of the PRODUCT_CD"),
    ("FUND_MASTER", "", ("01", "Investment Product", "Implemented Strategy"), "unmapped", "the register does not know the investment strategy (DP-004 takes it from the product master)"),
    ("FUND_MASTER", "", ("01", "Fund Legal Structure", "Legal Form"), "constant", "Delaware Statutory Trust"),
    ("FUND_MASTER", "", ("01", "Fund Legal Structure", "Regulatory Regime"), "constant", "US 1940 Act Registered"),
    ("FUND_MASTER", "", ("01", "Fund Legal Structure", "Fund Domicile"), "constant", "US"),
    ("FUND_MASTER", "", ("01", "Firm Product Classification", "Business Line"), "constant", "Proprietary funds and ETFs"),
    ("FUND_MASTER", "ASSET_CLS_CD", ("01", "Firm Product Classification", "Product Asset Class"), "crosswalk", "ASSET_CLS_CD"),
    # FUND_MASTER -> 01 Share Class (one per FUND_NO)
    ("FUND_MASTER", "FUND_NO", ("01", "Share Class", "Share Class ID"), "derived", "'SHC-' || FUND_NO"),
    ("FUND_MASTER", "PRODUCT_CD", ("01", "Share Class", "Parent Product"), "derived", "'PRD-' || PRODUCT_CD"),
    ("FUND_MASTER", "CLASS_CD", ("01", "Share Class", "Share Class Legal Name"), "derived", "FUND_NM || ' ' || CLASS_CD || ' Shares'"),
    ("FUND_MASTER", "CLASS_CD", ("01", "Share Class", "Share Class Designation"), "direct", ""),
    ("FUND_MASTER", "CLASS_CD", ("01", "Share Class", "Share Class Type"), "crosswalk", "CLASS_CD"),
    ("FUND_MASTER", "", ("01", "Share Class", "Share Class Currency"), "constant", "USD"),
    ("FUND_MASTER", "INCEPT_DT", ("01", "Share Class", "Share Class Launch Date"), "direct", "YYYYMMDD to ISO 8601"),
    ("FUND_MASTER", "STATUS_CD", ("01", "Share Class", "Share Class Status"), "crosswalk", "FUND_STATUS_CD"),
    ("FUND_MASTER", "INVESTOR_TYPE_CD", ("01", "Investor Eligibility", "Eligible Investor Type"), "crosswalk", "INVESTOR_TYPE_CD"),
    ("FUND_MASTER", "MIN_INIT_INV", ("01", "Investor Eligibility", "Minimum Initial Investment"), "direct", ""),
    ("FUND_MASTER", "CUSIP", ("01", "Security Identifier", "CUSIP"), "direct", ""),
    ("FUND_MASTER", "TICKER", ("01", "External Cross-Reference", "Bloomberg Ticker"), "direct", "the exchange ticker, which the Bloomberg ticker extends with the market suffix"),
    # SHR_ACCT -> 15 Account and its groups
    ("SHR_ACCT", "ACCT_NO", ("15", "Account", "Account ID"), "derived", "'ACC-TA-' || ACCT_NO"),
    ("SHR_ACCT", "ACCT_NO", ("15", "Account", "External Account Number"), "direct", ""),
    ("SHR_ACCT", "REG_LINE_1", ("15", "Account", "Account Name"), "direct", ""),
    ("SHR_ACCT", "ACCT_TYPE_CD", ("15", "Account", "Account Type"), "crosswalk", "ACCT_TYPE_CD"),
    ("SHR_ACCT", "SOC_CD", ("15", "Account", "Account Registration Type"), "crosswalk", "SOC_CD"),
    ("SHR_ACCT", "IRA_TYPE_CD", ("15", "Account", "Account Registration Type"), "derived", "for SOC_CD 7: T 'Traditional IRA', R 'Roth IRA', S 'SEP IRA', I 'Inherited IRA'; for SOC_CD 8 the owning client's legal nature (SRC-INST CLIENT.ENTITY_KIND_CD through FUND_ACCOUNT): PLAN 'Retirement Plan Trust', NPO 'Nonprofit', CORP 'Corporate' (refines the SOC_CD crosswalk)"),
    ("SHR_ACCT", "STATUS_CD", ("15", "Account", "Account Status"), "crosswalk", "ACCT_STATUS_CD"),
    ("SHR_ACCT", "ESTAB_DT", ("15", "Account", "Account Open Date"), "direct", "YYYYMMDD to ISO 8601"),
    ("SHR_ACCT", "CLOSE_DT", ("15", "Account", "Account Close Date"), "direct", "YYYYMMDD to ISO 8601"),
    ("SHR_ACCT", "", ("15", "Account", "Reg T Account Type"), "unmapped", "fund-only accounts are not brokerage accounts; Regulation T does not apply (steward: confirm the CDE is conditional)"),
    ("SHR_ACCT", "", ("15", "Account", "Carrying Entity"), "constant", "LE-TA"),
    ("SHR_ACCT", "ACCT_TYPE_CD", ("15", "Account", "Account Business Line"), "derived", "'Proprietary funds and ETFs' (PF) for direct accounts (I), 'Institutional advisory' (IA) for direct institutional accounts (D), 'Intermediary channel' (IC) for omnibus, plan and networked accounts"),
    ("SHR_ACCT", "REG_LINE_1", ("15", "Account Registration Detail", "Registration Line 1"), "direct", ""),
    ("SHR_ACCT", "REG_LINE_2", ("15", "Account Registration Detail", "Registration Line 2"), "direct", ""),
    ("SHR_ACCT", "SOC_CD", ("15", "Account Registration Detail", "Entity Account Indicator"), "derived", "SOC_CD in ('5', '8', '9')"),
    ("SHR_ACCT", "NSCC_LEVEL", ("15", "Intermediary Account Servicing", "Networking Level"), "crosswalk", "NSCC_LEVEL"),
    ("SHR_ACCT", "DEALER_NO", ("15", "Intermediary Account Servicing", "Dealer of Record"), "derived", "'PTY-DLR-' || DEALER_NO"),
    ("SHR_ACCT", "", ("15", "Intermediary Account Servicing", "Branch of Record"), "unmapped", "BRANCH_NO is a dealer branch number with no party record in the extract"),
    ("SHR_ACCT", "", ("15", "Intermediary Account Servicing", "Rep of Record"), "unmapped", "REP_NO is a dealer rep number with no party record in the extract"),
    ("SHR_ACCT", "ACCT_NO", ("15", "Account Identifier", "Account Identifier ID"), "derived", "'ACI-TA-' || ACCT_NO"),
    ("SHR_ACCT", "ACCT_NO", ("15", "Account Identifier", "Identified Account"), "derived", "'ACC-TA-' || ACCT_NO"),
    ("SHR_ACCT", "", ("15", "Account Identifier", "Account Identifier Scheme"), "constant", "Transfer Agent Account Number"),
    ("SHR_ACCT", "ACCT_NO", ("15", "Account Identifier", "Account Identifier Value"), "identifier", "ACCT_NO"),
    ("SHR_ACCT", "", ("15", "Account Identifier", "Primary Identifier Indicator"), "constant", "Y"),
    ("SHR_ACCT", "", ("15", "Account Identifier", "Account Identifier Status"), "constant", "Active"),
    ("SHR_ACCT", "ESTAB_DT", ("15", "Account Identifier", "Identifier Effective From"), "direct", ""),
    # POSITION -> 29 Share Register Balance
    ("POSITION", "ACCT_NO", ("29", "Share Register Balance", "Register Account"), "identifier", "ACCT_NO"),
    ("POSITION", "FUND_NO", ("29", "Share Register Balance", "Register Share Class"), "derived", "'SHC-' || FUND_NO"),
    ("POSITION", "ASOF_DT", ("29", "Share Register Balance", "Register Business Date"), "direct", "YYYYMMDD to ISO 8601"),
    ("POSITION", "ACCT_NO", ("29", "Share Register Balance", "Register Account Category"), "derived", "from SHR_ACCT: I 'Fund-Only'; O 'Broker-Dealer Omnibus' when the dealer is the affiliated BD, else 'Intermediary Omnibus'; N 'Networked'; P 'Plan Omnibus'; D 'Institutional Direct'"),
    ("POSITION", "SHARES", ("29", "Share Register Balance", "Registered Shares"), "derived", "SHARES + SHARES_UNCOLL"),
    ("POSITION", "SHARES", ("29", "Share Register Balance", "Collected Shares"), "direct", ""),
    ("POSITION", "SHARES_UNCOLL", ("29", "Share Register Balance", "Uncollected Shares"), "direct", ""),
    ("POSITION", "SHARES_ESCROW", ("29", "Share Register Balance", "Escrowed or Pledged Shares"), "direct", ""),
    ("POSITION", "", ("29", "Share Register Balance", "Register Keeper"), "unmapped", "the register keeper is the firm's own transfer agent, an internal legal entity (09), not a party in the extract"),
    # TRANSACTION -> 29 Register Transaction
    ("TRANSACTION", "CONFIRM_NO", ("29", "Register Transaction", "Register Transaction ID"), "derived", "'RGTX-' || CONFIRM_NO"),
    ("TRANSACTION", "TRAN_CD", ("29", "Register Transaction", "Register Transaction Type"), "crosswalk", "TRAN_CD"),
    ("TRANSACTION", "ACCT_NO", ("29", "Register Transaction", "Posting Account"), "identifier", "ACCT_NO"),
    ("TRANSACTION", "FUND_NO", ("29", "Register Transaction", "Posting Share Class"), "derived", "'SHC-' || FUND_NO"),
    ("TRANSACTION", "TRADE_DT", ("29", "Register Transaction", "Register Trade Date"), "direct", "YYYYMMDD to ISO 8601"),
    ("TRANSACTION", "SETL_DT", ("29", "Register Transaction", "Register Settlement Date"), "direct", "YYYYMMDD to ISO 8601"),
    ("TRANSACTION", "POST_DT", ("29", "Register Transaction", "Posting Date"), "direct", "YYYYMMDD to ISO 8601"),
    ("TRANSACTION", "SHARES", ("29", "Register Transaction", "Shares Posted"), "direct", ""),
    ("TRANSACTION", "TRAN_CD", ("29", "Register Transaction", "Share Movement Direction"), "derived", "'Inflow' for 001, 051, 071, 101, 102, 201; 'Outflow' for 002, 052, 072, 202; 'Neutral' for 111"),
    ("TRANSACTION", "NAV_APPLIED", ("29", "Register Transaction", "Price per Share Applied"), "direct", ""),
    ("TRANSACTION", "GROSS_AMT", ("29", "Register Transaction", "Gross Amount"), "direct", ""),
    ("TRANSACTION", "NET_AMT", ("29", "Register Transaction", "Net Amount"), "direct", ""),
    ("TRANSACTION", "", ("29", "Register Transaction", "Register Transaction Currency"), "constant", "USD"),
    ("TRANSACTION", "STATUS_CD", ("29", "Register Transaction", "Register Transaction Status"), "crosswalk", "TRAN_STATUS_CD"),
    ("TRANSACTION", "REVERSAL_OF", ("29", "Register Transaction", "Reversed Register Transaction"), "derived", "'RGTX-' || REVERSAL_OF where not blank"),
    ("TRANSACTION", "", ("29", "Register Transaction", "Originating Fund Order"), "unmapped", "orders (29 Fund Order) are not in the register extract; SOURCE_CD says which route the order came by"),
    # DEALER -> 02 Party / Organization / Party Identifier
    ("DEALER", "DEALER_NO", ("02", "Party", "Party ID"), "derived", "'PTY-DLR-' || DEALER_NO"),
    ("DEALER", "", ("02", "Party", "Party Type"), "constant", "Financial Institution"),
    ("DEALER", "DEALER_NM", ("02", "Party", "Party Display Name"), "direct", ""),
    ("DEALER", "", ("02", "Party", "Party Status"), "constant", "Active"),
    ("DEALER", "", ("02", "Party", "Relationship Stage"), "constant", "Counterparty / Vendor"),
    ("DEALER", "DEALER_NM", ("02", "Organization", "Legal Name"), "direct", ""),
    ("DEALER", "DEALER_NO", ("02", "Party Identifier", "Identifier Value"), "identifier", "DEALER_NO"),
    ("DEALER", "NSCC_NO", ("02", "Party Identifier", "Identifier Value"), "identifier", "NSCC_NO"),
    ("DEALER", "DEALER_NO", ("02", "Party Identifier", "Identified Party"), "derived", "'PTY-DLR-' || DEALER_NO"),
    ("DEALER", "", ("02", "Party Identifier", "Identifier Status"), "constant", "Active"),
    ("DEALER", "NSCC_NO", ("02", "Party Identifier", "Identifier Scheme"), "derived", "'TA Dealer Number' for the DEALER_NO row, 'NSCC Participant Number' for the NSCC_NO row"),
    ("DEALER", "", ("02", "Party Identifier", "Identifier Effective From"), "unmapped", "the dealer file keeps no history"),
]

CROSSWALKS = {
    "VEHICLE_CD": dict(target=("01", "Vehicle Type"), values=[
        ("OEF", "Open-Ended Fund", ""), ("ETF", "Exchange-Traded Fund", ""), ("CIT", "Collective Investment Trust", "")]),
    "ASSET_CLS_CD": dict(target=("01", "Asset Class"), values=[
        ("EQ", "Equity", ""), ("FI", "Fixed Income", ""), ("MM", "Money Market", ""), ("BAL", "Multi-Asset", "")]),
    "CLASS_CD": dict(target=("01", "Share Class Type"), values=[
        ("INV", "Retail", ""), ("ADM", "Retail", "a retail class with a higher minimum"), ("INST", "Institutional", ""), ("ETF", "ETF Share Class", "")]),
    "FUND_STATUS_CD": dict(target=("01", "Lifecycle Status"), values=[
        ("A", "Active", ""), ("S", "Soft Closed", ""), ("C", "Hard Closed", ""), ("L", "Liquidated", "")]),
    "INVESTOR_TYPE_CD": dict(target=("01", "Investor Category"), values=[
        ("R", "Retail", ""), ("I", "Institutional", ""), ("RI", "Retail", "both retail and institutional; the multi-value attribute takes Retail and Institutional")]),
    "ACCT_TYPE_CD": dict(target=("15", "Account Type"), values=[
        ("I", "Fund-Only Account", ""), ("O", "Omnibus Account at Transfer Agent", ""), ("N", "Networked Investor Account", ""),
        ("P", "Omnibus Account at Transfer Agent", "a recordkeeper's plan omnibus; the plan itself is 16"),
        ("D", "Direct Institutional Fund Account", "a pension plan, endowment or foundation holding fund shares directly")]),
    "SOC_CD": dict(target=("15", "Account Registration Type"), values=[
        ("1", "Individual", ""), ("2", "Joint Tenants (JTWROS)", ""), ("3", "UTMA / UGMA", ""), ("5", "Revocable Trust", "the register does not distinguish revocable from irrevocable"),
        ("7", "Traditional IRA", "refined by IRA_TYPE_CD"),
        ("8", "Retirement Plan Trust", "an institution; most direct institutional holders are plans. Refined by the owning client's legal nature (NPO Nonprofit, CORP Corporate); a government body has no value (GAPS)"),
        ("9", "Corporate", "dealer-controlled omnibus registered to the dealer")]),
    "ACCT_STATUS_CD": dict(target=("15", "Account Status"), values=[
        ("A", "Open", ""), ("C", "Closed", ""), ("Z", "Open", "zero balance is a balance state, not an account status")]),
    "NSCC_LEVEL": dict(target=("15", "Networking Level"), values=[
        ("0", "Level 0", ""), ("3", "Level 3", ""), ("4", "Level 4", ""), ("", "Not Networked", "")]),
    "TRAN_CD": dict(target=("29", "Register Transaction Type"), values=[
        ("001", "Purchase", ""), ("002", "Redemption", ""), ("051", "Exchange In", ""), ("052", "Exchange Out", ""),
        ("071", "Fund Share Transfer In", ""), ("072", "Fund Share Transfer Out", ""), ("101", "Dividend Reinvestment", ""),
        ("102", "Capital Gain Reinvestment", ""), ("111", None, "a cash dividend is a 27 distribution payment, not a share movement"),
        ("201", "Share Class Conversion In", ""), ("202", "Share Class Conversion Out", "")]),
    "TRAN_STATUS_CD": dict(target=("29", "Register Transaction Status"), values=[
        ("P", "Posted", ""), ("R", "Reversed", ""), ("C", "Corrected", "")]),
}

GAPS = [
    ("POSITION", "The register carries no value: NAV and MKT_VAL are the transfer agent's valuation. The taxonomy values register positions through 27 Share Class NAV (DP-165), outside the slice, so the DP-007 derivation reads the register's NAV directly."),
    ("SHR_ACCT", "A direct institutional account (SOC_CD 8) owned by a government body (SRC-INST CLIENT.ENTITY_KIND_CD GOV) has no 15 Account Registration Type value; the registration is null. Candidate: 'Government Entity'."),
    ("TRANSACTION", "SOURCE_CD (the dealing route) has no home on 29 Register Transaction; DP-006 Order Entry Channel (Shared: Dealing Route) takes it from the staging row."),
]
