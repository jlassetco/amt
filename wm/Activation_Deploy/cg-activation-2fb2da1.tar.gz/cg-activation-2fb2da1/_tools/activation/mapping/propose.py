"""The AI mapping assistant: proposes a mapping module (CONTRACT.md shape) for one source from its data dictionary and
the taxonomy, and measures a proposal against the steward-confirmed module.

Usage (from _tools/):
  activation/.venv/bin/python activation/mapping/propose.py SRC-BRK [--table T] [--out DIR] [--assistant ollama|anthropic|baseline] [--eval]
The assistant defaults to the provider serve/llm.py selects (Claude with ANTHROPIC_API_KEY, or an open-weight model on an
Ollama server), else the deterministic token-overlap baseline (--baseline is short for --assistant baseline). Claude gets the
whole table in one call; the local model gets one small call per chunk of at most 8 columns (the top 6 candidate objects of
the chunk, trimmed code lists) and a second small call for the code values of the columns it marks crosswalk. --eval with
Claude reuses a Claude proposal already in the output folder. Writes map_<source>_proposed.py, its .json twin and
eval_<source>.json (with the proposer, the provider's model and the timing).
"""
import argparse, json, math, os, re, sys, time, types
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import _paths  # noqa: E402
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(_paths.HERE, "sources")); sys.path.insert(0, os.path.join(_paths.HERE, "serve"))
import llm  # noqa: E402
import slice as sl  # noqa: E402
import check_mapping as cm  # noqa: E402
from schema import SOURCES, dictionary_rows  # noqa: E402

MODEL = os.environ.get("ACTIVATION_ANTHROPIC_MODEL") or "claude-opus-5-5"   # the deployment may pin the proposer's model
BEST, CAND = 2.0, 1.5                           # baseline preference for the best object and the candidates
OUT_DIR = os.path.join(_paths.OUT, "proposals")
KINDS = ["direct", "identifier", "crosswalk", "derived", "constant", "unmapped"]
SCHEME_LISTS = [("15", "Account Identifier Scheme"), ("02", "Identifier Scheme")]
ID_TARGET = {"15": ("15", "Account Identifier", "Account Identifier Value"), "02": ("02", "Party Identifier", "Identifier Value")}
ABBR = {"acct": "account", "no": "number", "cd": "code", "dt": "date", "cust": "customer", "nm": "name", "reg": "registration",
        "sec": "security", "qty": "quantity", "mkt": "market", "val": "value", "txn": "transaction", "tran": "transaction",
        "amt": "amount", "bal": "balance", "ccy": "currency", "dob": "date birth", "dod": "date death", "td": "trade date",
        "sd": "settlement date", "setl": "settlement", "trd": "trade", "rsn": "reason", "enroll": "enrollment", "pgm": "program",
        "id": "identifier", "prim": "primary", "desc": "description", "cls": "class", "asof": "date", "inv": "investor",
        "init": "initial", "min": "minimum", "incept": "inception", "int": "interest", "div": "dividend", "shr": "share",
        "nav": "net asset value", "ent": "entity", "carry": "carrying", "xfer": "transfer", "uncoll": "uncollected",
        "estab": "established", "opt": "option", "ta": "transfer agent", "hh": "household", "rep": "representative",
        "confirm": "confirmation", "finserv": "", "c": "", "fin": "financial", "serv": "service"}
STOP = set("the a an of and or for to in on by is at as be when with its it this that which from per one row rows blank "
           "otherwise each else are has have not only into than any all e g eg such were was".split())
COMPAT = {"id": {"Identifier", "Text"}, "text": {"Text"}, "code": {"Code", "Code (multi)", "Boolean"}, "date": {"Date"},
          "timestamp": {"Timestamp", "Date"}, "integer": {"Integer", "Decimal"}, "boolean": {"Boolean"},
          "number": {"Decimal", "Amount", "Percentage", "Integer"}, "amount": {"Amount", "Decimal"}}


def has_key():
    """True when a Claude credential is in the environment (its value is never read here)."""
    return llm.has_claude_key()


def tokens(text, expand=False):
    """Lower-case word tokens, abbreviations expanded, stop words dropped, plurals folded."""
    text = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", str(text or ""))
    out = []
    for w in re.split(r"[^A-Za-z0-9]+", text.lower()):
        for x in (ABBR.get(w, w) if expand else w).split():
            if x and x not in STOP:
                out.append(x[:-3] + "y" if x.endswith("ies") and len(x) > 4 else x[:-1] if x.endswith("s") and len(x) > 3 and not x.endswith("ss") else x)
    return out


class Taxonomy:
    """The taxonomy attributes with token sets and IDF weights, and the code lists."""
    def __init__(self):
        _, _, _, self.objs = sl.load()
        self.cl = sl.code_lists()
        self.attrs = [(k, n, a, set(tokens(n)), set(tokens(a["def"]))) for k, o in self.objs.items() for n, a in o["attrs"].items()]
        df = Counter(t for *_, nt, dt in self.attrs for t in nt | dt)
        self.idf = {t: math.log(len(self.attrs) / c) for t, c in df.items()}

    def values(self, dom, code_list):
        return self.cl.get((dom, code_list)) or self.cl.get((dom, "Shared: " + code_list.replace("Shared: ", ""))) or []

    def w(self, toks):
        return sum(self.idf.get(t, 3.0) for t in toks)


def column_scores(tx, col):
    """Score every taxonomy attribute against one dictionary row: name overlap counts double."""
    ct = set(tokens(col[1], True)) | set(tokens(col[3]))
    out = []
    for i, (k, n, a, nt, dt) in enumerate(tx.attrs):
        s = 2 * tx.w(ct & nt) + 0.5 * tx.w(ct & dt)
        if s > 0:
            out.append((s + (1.0 if a["type"] in COMPAT.get(col[2], ()) else 0), i))
    return sorted(out, reverse=True)[:200]


def table_context(tx, sid, table):
    """Per-column scores and the candidate objects (top 8) of one source table."""
    d = SOURCES[sid]["tables"][table]
    rows = [r for r in dictionary_rows(sid) if r[0] == table]
    head = set(tokens(table, True)) | set(tokens(d["description"])) | set(tokens(d["grain"]))
    scores = {r[1]: column_scores(tx, r) for r in rows}
    obj = Counter()
    for k, o in tx.objs.items():
        obj[k] += 3 * tx.w(head & set(tokens(o["name"]))) + 2 * tx.w(set(tokens(d["grain"])) & set(tokens(o.get("grain", ""))))
    for sc in scores.values():
        best = {}
        for s, i in sc:
            best.setdefault(tx.attrs[i][0], s)
        obj.update({k: s / 2 for k, s in best.items()})
    return rows, scores, [k for k, _ in obj.most_common(8)]


def parse_codes(desc):
    """Source code values and labels named in a column description ('B brokerage, A managed' or 'Active, Inactive')."""
    desc = desc.split(";")[0].split(":", 1)[-1]
    out = []
    for seg in desc.split(","):
        w = seg.strip().split()
        if len(w) == 1:
            out.append((w[0], w[0]))
        elif len(w) > 1 and re.fullmatch(r"[A-Z0-9]{1,6}", w[0]):
            out.append((w[0], " ".join(w[1:]).strip("()")))
    return out


def crosswalk_values(tx, desc, dom, code_list):
    vals, res = tx.values(dom, code_list), []
    for code, label in parse_codes(desc):
        lt = set(tokens(label, True)) | {code.lower()}
        best = max(((tx.w(lt & (set(tokens(v[0])) | set(tokens(v[1])) | {str(v[2]).lower()})), v[0]) for v in vals), default=(0, None))
        res.append((code, best[1] if best[0] > 0 else None, "" if best[0] > 0 else "no equivalent found by token overlap"))
    return res


def match_scheme(tx, sid, col):
    """The identifier scheme value best matching a key column, or None."""
    ct = set(tokens(col[1], True)) | set(tokens(col[3])) | set(tokens(SOURCES[sid]["name"]))
    best = (0, None)
    for dom, lname in SCHEME_LISTS:
        for v in tx.values(dom, lname):
            vt = set(tokens(v[0]))
            if len(ct & vt) >= 2 and len(ct & vt) / len(vt) >= 0.75:
                best = max(best, (tx.w(ct & vt), (dom, lname, v[0])))
    return best[1]


def empty_proposal(sid, proposer):
    return dict(proposer=proposer, source=dict(id=sid, name=SOURCES[sid]["name"], kind=SOURCES[sid]["kind"], identifier_schemes={}),
                objects=[], attributes=[], crosswalks={}, gaps=[], confidence={})


def baseline_table(tx, sid, table, prop, only=None):
    """Deterministic proposal for one table (or only some of its columns): top-scoring attribute per column, preferring
    the table's best object."""
    rows, scores, cands = table_context(tx, sid, table)
    keys = {c for t in SOURCES[sid]["tables"].values() for c in t["keys"]}
    for r in rows:
        if only is not None and r[1] not in only:
            continue
        if r[1] in SOURCES[sid]["tables"][table]["keys"] and r[2] == "id":
            sch = match_scheme(tx, sid, r)
            if sch:
                prop["source"]["identifier_schemes"][r[1]] = sch
                add_row(prop, table, r[1], ID_TARGET[sch[0]], "identifier", r[1], 0.6, f"key column; scheme '{sch[2]}' matches by name")
        ranked = sorted(((s * (BEST if tx.attrs[i][0] == cands[0] else CAND if tx.attrs[i][0] in cands else 1), i) for s, i in scores[r[1]]), reverse=True)
        if not ranked or ranked[0][0] < 4:
            prop["gaps"].append((table, f"{r[1]}: no taxonomy attribute found by token overlap")); continue
        s, i = ranked[0]
        k, n, a = tx.attrs[i][:3]
        conf = round(min(0.95, s / (s + 8)), 2)
        ref = next((c for c in keys if r[1] != c and r[1].endswith(c) and c in prop["source"]["identifier_schemes"]), None)
        if r[2] == "id" and a["type"].startswith("Reference") and (ref or r[1] in prop["source"]["identifier_schemes"]):
            add_row(prop, table, r[1], (*k, n), "identifier", ref or r[1], conf, "source key of a referenced object")
        elif r[2] == "code" and a["code_list"] and tx.values(k[0], a["code_list"]):
            dom, lname = k[0], a["code_list"].replace("Shared: ", "")
            name = r[1] if r[1] not in prop["crosswalks"] else f"{r[1]}_{table}"
            prop["crosswalks"][name] = dict(target=(dom, lname), values=crosswalk_values(tx, r[3], dom, a["code_list"]))
            add_row(prop, table, r[1], (*k, n), "crosswalk", name, conf, f"code column; '{n}' has code list {lname}")
        elif a["type"] in COMPAT.get(r[2], ()):
            add_row(prop, table, r[1], (*k, n), "direct", "", conf, f"name and definition overlap; {r[2]} to {a['type']}")
        else:
            prop["gaps"].append((table, f"{r[1]}: best candidate {k[1]}.{n} is a {a['type']}, not a {r[2]}"))


def add_row(prop, table, col, target, kind, detail, conf, why):
    prop["attributes"].append((table, col, tuple(target), kind, detail))
    prop["confidence"][(table, col, tuple(target))] = (conf, why)
    obj = tuple(target[:2])
    if not any(t == table and o == obj for t, o, _ in prop["objects"]):
        prop["objects"].append((table, obj, "proposed"))


SYSTEM = """You map one source system table to a wealth manager's data taxonomy, writing a proposal a data steward will confirm.
Targets are taxonomy names exactly as given: (domain, object, attribute). Choose only from the candidate objects provided.
Mapping kinds: direct (the column is the attribute after type conversion; detail = conversion note), identifier (the column is
a source-issued identifier or the source key of a referenced object; detail = the identifier scheme key you declare),
crosswalk (code values translate; detail = the crosswalk name you define), derived (detail = a short SQL expression over the
table's columns), constant (no column; detail = the value), unmapped (no column; an attribute the table should supply but
cannot; detail = the reason). A column may feed several targets. Map at the table's grain. Never invent code values: a source
value with no equivalent in the target code list gets target "" and a note. Identifier scheme values must come from the
scheme lists given; use "" with a note when none fits. Never map a PII column to a non-PII attribute. Give a confidence from
0 to 1 and a one-sentence rationale for every row. Columns with no taxonomy home go in gaps."""

S, A = {"type": "string"}, lambda p: {"type": "array", "items": p}
O = lambda **p: {"type": "object", "properties": p, "required": list(p), "additionalProperties": False}
ROW = O(column=S, domain=S, object=S, attribute=S, kind={"type": "string", "enum": KINDS}, detail=S,
        confidence={"type": "number"}, rationale=S)
SCHEMA = O(rows=A(ROW), objects=A(O(domain=S, object=S, note=S)),
           identifier_schemes=A(O(key=S, domain=S, scheme_list=S, value=S, note=S)),
           crosswalks=A(O(name=S, domain=S, code_list=S, values=A(O(source=S, target=S, note=S)))), gaps=A(S))


def claude_table(tx, sid, table, prop):
    """Ask Claude for one table's proposal (structured output through serve/llm.py) and merge it into the proposal."""
    rows, _, cands = table_context(tx, sid, table)
    d = SOURCES[sid]["tables"][table]
    pack = dict(source={k: SOURCES[sid][k] for k in ("id", "name", "kind", "shape", "note")},
                table=dict(name=table, description=d["description"], grain=d["grain"], keys=d["keys"]),
                other_tables={t: x["keys"] for t, x in SOURCES[sid]["tables"].items() if t != table},
                columns=[dict(column=r[1], type=r[2], description=r[3], example=r[4]) for r in rows],
                identifier_schemes={f"{dm} {n}": [v[0] for v in tx.values(dm, n)] for dm, n in SCHEME_LISTS},
                candidate_objects=[dict(domain=k[0], object=k[1], grain=tx.objs[k].get("grain", ""), attributes=[
                    dict(name=n, definition=a["def"][:300], type=a["type"], pii=a["pii"], code_list=a["code_list"],
                         values=[v[0] for v in tx.values(k[0], a["code_list"])][:60] if a["code_list"] else [])
                    for n, a in tx.objs[k]["attrs"].items()]) for k in cands])
    try:
        out = llm.make("anthropic", model=MODEL, effort="high").structured(
            SYSTEM, "Propose the mapping of this table.\n" + json.dumps(pack, ensure_ascii=False), SCHEMA, 64000)
    except llm.LLMError as e:
        prop["gaps"].append((table, f"no proposal: {e}")); return
    for s in out["identifier_schemes"]:
        prop["source"]["identifier_schemes"][s["key"]] = (s["domain"], s["scheme_list"], s["value"]) if s["value"] else (s["domain"], s["scheme_list"], None, s["note"])
    for c in out["crosswalks"]:
        prop["crosswalks"][c["name"]] = dict(target=(c["domain"], c["code_list"].replace("Shared: ", "")),
                                             values=[(v["source"], v["target"] or None, v["note"]) for v in c["values"]])
    for o in out["objects"]:
        prop["objects"].append((table, (o["domain"], o["object"]), o["note"]))
    for r in out["rows"]:
        col = "" if r["kind"] in ("constant", "unmapped") else r["column"]
        add_row(prop, table, col, (r["domain"], r["object"], r["attribute"]), r["kind"], r["detail"], r["confidence"], r["rationale"])
    prop["gaps"] += [(table, g) for g in out["gaps"]]


# ------------------------------------------------------------------------------------------- the local model (small calls)
CHUNK, LOCAL_OBJECTS, LOCAL_VALUES, LOCAL_XW_VALUES = 8, 6, 12, 40
LOCAL_PACK = "chunk"                               # "chunk": candidates picked per chunk (best quality); "table": one cached pack per table (fastest)
LOCAL_EXTRAS = 4                                   # extra candidate objects a chunk may add after the stable pack
LOCAL_KINDS = ["direct", "identifier", "crosswalk", "derived", "unmapped"]
LOCAL_SYSTEM = """You map columns of one source system table to a wealth manager's data taxonomy. For each column pick the one
target (written exactly "domain | object | attribute" from the candidate list) the column populates, or "none" when no
candidate fits. Kinds: direct (the column is the attribute after type conversion; detail = conversion note or ""),
identifier (the column is a source-issued account or customer number, or the source key of a referenced object; detail =
the key column; scheme = the identifier scheme from the lists given, or "" when none fits), crosswalk (a code column
whose values translate to the target attribute's code list; detail = ""), derived (computed from the table's columns;
detail = a short SQL expression), unmapped (no candidate fits; target "none"). Prefer the object at the table's grain.
rationale: at most eight words.
Never map a personal-data column to a non-personal attribute. Confidence is 0 to 1; rationale is at most 12 words."""
XW_SYSTEM = """You translate a source system's code values to a taxonomy code list. For each source code pick the one
target value with the same meaning, exactly as listed, or "" when none has the same meaning. Never invent values."""


def local_candidates(tx, sid, table, chunk, scores):
    """The top candidate objects for one chunk of columns: the table's name and grain, and the chunk's best attributes."""
    d = SOURCES[sid]["tables"][table]
    head = set(tokens(table, True)) | set(tokens(d["description"])) | set(tokens(d["grain"]))
    obj = Counter()
    for k, o in tx.objs.items():
        obj[k] += 3 * tx.w(head & set(tokens(o["name"]))) + 2 * tx.w(set(tokens(d["grain"])) & set(tokens(o.get("grain", ""))))
    for r in chunk:
        best = {}
        for s, i in scores[r[1]]:
            best.setdefault(tx.attrs[i][0], s)
        obj.update(best)
    cands = [k for k, _ in obj.most_common(LOCAL_OBJECTS)]
    for r in chunk:                                       # a key column brings its identifier object
        if r[1] in d["keys"] and r[2] == "id":
            sch = match_scheme(tx, sid, r)
            idobj = (ID_TARGET[sch[0]][0], ID_TARGET[sch[0]][1]) if sch else None
            if idobj and idobj not in cands:
                cands[-1] = idobj
    return cands


def local_objects(tx, cands):
    """The candidate objects and attributes as text lines."""
    lines = []
    for k in cands:
        o = tx.objs[k]
        lines.append(f"[{k[0]} | {k[1]}] grain: {o.get('grain', '')[:90]}")
        for n, a in o["attrs"].items():
            vals = [v[0] for v in tx.values(k[0], a["code_list"])][:LOCAL_VALUES] if a["code_list"] else []
            lines.append(f"  - {n} ({a['type']}{', PII' if a['pii'] else ''}): {a['def'][:110]}" + (f" Values: {', '.join(vals)}" if vals else ""))
    return lines


def local_pack(tx, sid, table, cands):
    """The stable context of one source table: the same text for every chunk, so the model server reuses its cached
    prompt prefix across the chunk calls (the columns to map come in the user message)."""
    d = SOURCES[sid]["tables"][table]
    lines = [f"Source: {SOURCES[sid]['name']} ({SOURCES[sid]['kind']}). Table {table}: {d['description']} Grain: {d['grain']}. "
             f"Keys: {', '.join(d['keys'])}. Keys of the other tables: "
             + "; ".join(f"{t} {', '.join(x['keys'])}" for t, x in SOURCES[sid]["tables"].items() if t != table) + ".",
             "", "Candidate taxonomy objects and attributes (target = \"domain | object | attribute\"):"]
    lines += local_objects(tx, cands)
    lines += ["", "Identifier schemes: " + "; ".join(f"{dm} {n}: {', '.join(v[0] for v in tx.values(dm, n))}" for dm, n in SCHEME_LISTS)]
    return "\n".join(lines)


def local_columns(tx, chunk, extras):
    """The user message of one chunk: extra candidate objects this chunk needs, then its columns."""
    lines = []
    if extras:
        lines += ["Additional candidate objects for these columns:"] + local_objects(tx, extras) + [""]
    lines += ["Columns to map:"] + [f"- {r[1]} ({r[2]}): {r[3]}" + (f" e.g. {r[4]}" if r[4] else "") for r in chunk]
    return "\n".join(lines)


def local_schema(tx, chunk, cands):
    targets = [f"{k[0]} | {k[1]} | {n}" for k in cands for n in tx.objs[k]["attrs"]] + ["none"]
    schemes = [v[0] for dm, n in SCHEME_LISTS for v in tx.values(dm, n)] + [""]
    row = O(target={"type": "string", "enum": targets}, kind={"type": "string", "enum": LOCAL_KINDS}, detail=S,
            scheme={"type": "string", "enum": schemes}, confidence={"type": "number"}, rationale={"type": "string", "maxLength": 70})
    return O(**{r[1]: row for r in chunk})


def local_crosswalks(p, tx, sid, table, todo, prop):
    """Second small call: the code values of the columns the first call marked crosswalk."""
    props, ctx = {}, []
    for col, desc, (dom, lname, cl) in todo:
        codes = parse_codes(desc)
        vals = [v[0] for v in tx.values(dom, cl)][:LOCAL_XW_VALUES]
        if not codes:
            continue
        props[col] = O(**{c: {"type": "string", "enum": vals + [""]} for c, _ in codes})
        ctx.append(f"Column {col}: {desc}\n  source codes: " + "; ".join(f"{c} = {lab}" for c, lab in codes) +
                   f"\n  target list {dom} {lname}: " + ", ".join(vals))
    out = p.structured(XW_SYSTEM, "\n\n".join(ctx), O(**props), 60 + 25 * sum(len(x["properties"]) for x in props.values())) if props else {}
    for col, desc, (dom, lname, cl) in todo:
        name = col if col not in prop["crosswalks"] else f"{col}_{table}"
        got = out.get(col, {})
        prop["crosswalks"][name] = dict(target=(dom, lname), values=[
            (c, got.get(c) or None, "" if got.get(c) else "no equivalent named by the local model") for c, _ in parse_codes(desc)])
        yield col, name


def local_chunk(p, tx, sid, table, chunk, scores, prop, stable, table_cands):
    if LOCAL_PACK == "table":                             # the cached per-table pack plus a few objects this chunk needs
        extras = [k for k in local_candidates(tx, sid, table, chunk, scores) if k not in table_cands][:LOCAL_EXTRAS]
        cands = list(table_cands) + extras
    else:                                                 # the chunk's own best objects (the prompt differs per chunk)
        cands, extras = local_candidates(tx, sid, table, chunk, scores), []
        stable = local_pack(tx, sid, table, cands)
    out = p.structured(LOCAL_SYSTEM + "\n\n" + stable, local_columns(tx, chunk, extras), local_schema(tx, chunk, cands), 150 * len(chunk) + 150)
    keys = {c for t in SOURCES[sid]["tables"].values() for c in t["keys"]}
    pending, xw = [], []
    for r in chunk:
        x = out.get(r[1]) or {}
        tgt, kind = x.get("target", "none"), x.get("kind", "unmapped")
        why, conf = (x.get("rationale") or "").strip(), max(0.0, min(1.0, float(x.get("confidence") or 0)))
        if tgt == "none" or kind == "unmapped":
            prop["gaps"].append((table, f"{r[1]}: no taxonomy home named by the local model{': ' + why if why else ''}")); continue
        dom, obj, attr = [t.strip() for t in tgt.split(" | ", 2)]
        a = tx.objs[(dom, obj)]["attrs"][attr]
        detail = (x.get("detail") or "").strip()
        if kind == "direct" and r[2] == "code" and a["code_list"] and a["type"] != "Boolean":
            kind = "crosswalk"                            # a code column landing on a code-list attribute translates its values
        if kind == "crosswalk":
            if a["code_list"] and tx.values(dom, a["code_list"]):
                xw.append((r[1], r[3], (dom, a["code_list"].replace("Shared: ", ""), a["code_list"])))
                pending.append((r[1], (dom, obj, attr), "crosswalk", None, conf, why)); continue
            kind, detail = "direct", ""
        if kind == "identifier":
            key = detail if detail in keys else r[1]
            sch = x.get("scheme") or ""
            if key not in prop["source"]["identifier_schemes"]:
                lists = [(dm, n) for dm, n in SCHEME_LISTS if sch in [v[0] for v in tx.values(dm, n)]]
                lists.sort(key=lambda l: l[0] != dom)
                dm, n = lists[0] if lists else next((l for l in SCHEME_LISTS if l[0] == dom), SCHEME_LISTS[1])
                prop["source"]["identifier_schemes"][key] = (dm, n, sch) if lists else \
                    (dm, n, None, "no scheme value named by the local model; a steward chooses one or proposes an addition")
            detail = key
        elif kind == "derived" and not detail:
            detail = r[1]
        pending.append((r[1], (dom, obj, attr), kind, detail, conf, why))
    names = dict(local_crosswalks(p, tx, sid, table, xw, prop)) if xw else {}
    for col, target, kind, detail, conf, why in pending:
        add_row(prop, table, col, target, kind, names.get(col, detail) if detail is None else detail, round(conf, 2), why)


def local_table(p, tx, sid, table, prop):
    """The local model's proposal for one table, chunk by chunk; a chunk that fails twice falls back to the baseline."""
    rows, scores, table_cands = table_context(tx, sid, table)
    table_cands = table_cands[:LOCAL_OBJECTS]
    d = SOURCES[sid]["tables"][table]
    for r in rows:                                        # a key column brings its identifier object
        if r[1] in d["keys"] and r[2] == "id":
            sch = match_scheme(tx, sid, r)
            idobj = (ID_TARGET[sch[0]][0], ID_TARGET[sch[0]][1]) if sch else None
            if idobj and idobj not in table_cands:
                table_cands.append(idobj)
    stable = local_pack(tx, sid, table, table_cands)
    failed = []
    for i in range(0, len(rows), CHUNK):
        chunk = rows[i:i + CHUNK]
        for attempt in (1, 2):
            try:
                local_chunk(p, tx, sid, table, chunk, scores, prop, stable, table_cands); break
            except (llm.LLMError, KeyError, ValueError) as e:
                if attempt == 2:
                    failed += [r[1] for r in chunk]
                    prop.setdefault("fallbacks", []).append(f"{table} columns {chunk[0][1]}..{chunk[-1][1]}: {e}; baseline used")
    if failed:
        baseline_table(tx, sid, table, prop, only=set(failed))


def as_module(prop, rows=None):
    return types.SimpleNamespace(SOURCE=prop["source"], OBJECTS=prop["objects"], CROSSWALKS=prop["crosswalks"], GAPS=prop["gaps"],
                                 ATTRIBUTES=prop["attributes"] if rows is None else rows)


def validate(tx, prop):
    """check_mapping.validate on the whole proposal, then row by row so each failing row is marked."""
    sid = prop["source"]["id"]
    invalid = {}
    for e in cm.validate({sid: as_module(prop, [])}, tx.objs, tx.cl):
        invalid.setdefault("source", []).append(e)
    for r in prop["attributes"]:
        errs = [e for e in cm.validate({sid: as_module(prop, [r])}, tx.objs, tx.cl) if e not in invalid.get("source", [])]
        if errs:
            invalid[(r[0], r[1], r[2])] = errs
    prop["invalid"] = invalid
    return invalid


def write(prop, out_dir, stem):
    """Write map_<stem>_proposed.py (CONTRACT shape plus CONFIDENCE and INVALID) and its JSON twin."""
    os.makedirs(out_dir, exist_ok=True)
    lst = lambda xs: "[\n" + "".join(f"    {x!r},\n" for x in xs) + "]"
    dct = lambda d: "{\n" + "".join(f"    {k!r}: {v!r},\n" for k, v in d.items()) + "}"
    sid = prop["source"]["id"]
    py = (f'"""PROPOSED mapping of {sid} ({prop["source"]["name"]}) by propose.py ({prop["proposer"]}). Not confirmed: a steward '
          f'reviews it against CONTRACT.md before it becomes mapping/map_{stem}.py."""\n\nPROPOSER = {prop["proposer"]!r}\n\n'
          f'SOURCE = {prop["source"]!r}\n\nOBJECTS = {lst(prop["objects"])}\n\nATTRIBUTES = {lst(prop["attributes"])}\n\n'
          f'CROSSWALKS = {dct(prop["crosswalks"])}\n\nGAPS = {lst(prop["gaps"])}\n\n'
          f'CONFIDENCE = {dct(prop["confidence"])}  # (table, column, target) -> (confidence, rationale)\n\n'
          f'INVALID = {dct(prop["invalid"])}  # rows that fail check_mapping.validate, with the errors\n')
    path = os.path.join(out_dir, f"map_{stem}_proposed.py")
    open(path, "w").write(py)
    js = dict(prop, confidence=[dict(table=k[0], column=k[1], target=k[2], confidence=v[0], rationale=v[1]) for k, v in prop["confidence"].items()],
              invalid=[dict(row=list(k) if isinstance(k, tuple) else k, errors=v) for k, v in prop["invalid"].items()])
    json.dump(js, open(path[:-3] + ".json", "w"), indent=1, ensure_ascii=False, default=list)
    return path


def load_json(path):
    j = json.load(open(path)); j["attributes"] = [(t, c, tuple(g), k, d) for t, c, g, k, d in j["attributes"]]; return j

def resolve_assistant(assistant=None, baseline=False):
    """'anthropic', 'ollama' or 'baseline': the one asked for when its provider is usable, else the configured one, else
    the baseline. Returns (kind, provider or None, note when the request could not be honored)."""
    if baseline or assistant == "baseline":
        return "baseline", None, ""
    want = {"claude": "anthropic" if llm.has_claude_key() else "claudecode", "local": "ollama"}.get(assistant, assistant) or llm.configured_kind()
    if want == "none":
        return "baseline", None, ""
    p = llm.get(want)
    if p.available():
        return want, p, ""
    return "baseline", None, f"{want} assistant is not available; the deterministic baseline ran instead"


def propose(tx, sid, tables=None, baseline=False, assistant=None):
    kind, p, note = resolve_assistant(assistant, baseline)
    prop = empty_proposal(sid, MODEL if kind == "anthropic" else p.name() if kind in ("ollama", "claudecode") else "baseline")
    prop["assistant"] = dict(kind=kind, label=p.label() if p else "deterministic baseline (token overlap)", model=p.model if p else None)
    if note:
        prop["fallbacks"] = [note]
    t0 = time.time()
    for t in tables or SOURCES[sid]["tables"]:
        if kind == "anthropic":
            claude_table(tx, sid, t, prop)
        elif kind in ("ollama", "claudecode"):   # Claude Code takes the chunked structured prompts too, one session per chunk
            local_table(p, tx, sid, t, prop)
        else:
            baseline_table(tx, sid, t, prop)
    prop["timing"] = dict(seconds=round(time.time() - t0, 1), **(p.stats() if p else {}))
    validate(tx, prop)
    return prop


def evaluate(prop, confirmed, tables=None):
    """Recall of the confirmed rows (target, and target with kind) and precision of the proposed rows, per kind and overall."""
    conf = [r for r in confirmed.ATTRIBUTES if r[3] != "unmapped" and (not tables or r[0] in tables)]
    got = {}
    for t, c, g, k, _ in prop["attributes"]:
        if k != "unmapped":
            got.setdefault((t, c), {})[tuple(g)] = k
    truth = {(t, c, tuple(g), k) for t, c, g, k, _ in conf}
    truth_t = {(t, c, tuple(g)) for t, c, g, k, _ in conf}
    per = {}
    for t, c, g, k, _ in conf:
        p = per.setdefault(k, Counter())
        hit = got.get((t, c), {}).get(tuple(g))
        p["confirmed"] += 1; p["target_hit"] += hit is not None; p["kind_hit"] += hit == k
    for (t, c), gs in got.items():
        for g, k in gs.items():
            p = per.setdefault(k, Counter())
            p["proposed"] += 1; p["proposed_correct"] += (t, c, g, k) in truth; p["proposed_target_ok"] += (t, c, g) in truth_t
    per["overall"] = sum(per.values(), Counter())
    res = {}
    for k, p in per.items():
        r = lambda a, b: round(p[a] / p[b], 3) if p[b] else None
        res[k] = dict(p, recall_target=r("target_hit", "confirmed"), recall=r("kind_hit", "confirmed"),
                      precision_target=r("proposed_target_ok", "proposed"), precision=r("proposed_correct", "proposed"))
    return res


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("source"); ap.add_argument("--table", action="append"); ap.add_argument("--out", default=OUT_DIR)
    ap.add_argument("--assistant", choices=["ollama", "anthropic", "baseline"], help="default: the configured provider, else baseline")
    ap.add_argument("--baseline", action="store_true", help="same as --assistant baseline"); ap.add_argument("--eval", action="store_true")
    a = ap.parse_args()
    if a.source not in SOURCES:
        raise SystemExit(f"unknown source {a.source}; one of {sorted(SOURCES)}")
    confirmed = cm.load_mappings().get(a.source)
    stem = confirmed.__name__[4:] if confirmed else a.source.lower().replace("src-", "")
    tx = Taxonomy()
    kind, _, note = resolve_assistant(a.assistant, a.baseline)
    print(note or f"assistant: {kind}")
    existing = os.path.join(a.out, f"map_{stem}_proposed.json")
    if a.eval and kind == "anthropic" and os.path.exists(existing) and load_json(existing)["proposer"] == MODEL:
        prop = load_json(existing)
    else:
        prop = propose(tx, a.source, a.table, assistant=kind)
        path = write(prop, a.out, stem)
        n_bad = sum(1 for k in prop["invalid"] if k != "source")
        print(f"{a.source}: {len(prop['attributes'])} rows, {len(prop['crosswalks'])} crosswalks, {len(prop['gaps'])} gaps, "
              f"{n_bad} row(s) fail validation, {prop['timing']} -> {os.path.relpath(path, _paths.TOOLS)}")
        for f in prop.get("fallbacks", []):
            print("  fallback:", f)
    if a.eval:
        if not confirmed:
            raise SystemExit(f"no confirmed module for {a.source}")
        res = evaluate(prop, confirmed, a.table)
        print(f"\n{a.source} ({prop['proposer']}) vs mapping/{confirmed.__name__}.py")
        print(f"  {'kind':11s} {'confirmed':>9s} {'tgt rec':>8s} {'recall':>7s} {'proposed':>9s} {'tgt prec':>9s} {'precision':>9s}")
        for k in KINDS + ["overall"]:
            if k in res:
                x = res[k]; f = lambda v: "-" if v is None else f"{v:.2f}"
                print(f"  {k:11s} {x.get('confirmed', 0):9d} {f(x['recall_target']):>8s} {f(x['recall']):>7s} {x.get('proposed', 0):9d} "
                      f"{f(x['precision_target']):>9s} {f(x['precision']):>9s}")
        os.makedirs(a.out, exist_ok=True)
        json.dump(dict(source=a.source, proposer=prop["proposer"], assistant=prop.get("assistant"), timing=prop.get("timing"),
                       fallbacks=prop.get("fallbacks", []), confirmed_module=confirmed.__name__, tables=a.table, results=res),
                  open(os.path.join(a.out, f"eval_{a.source}.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
