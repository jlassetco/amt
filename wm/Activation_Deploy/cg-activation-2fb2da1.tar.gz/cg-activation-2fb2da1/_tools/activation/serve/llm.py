"""The model provider of the activation demo's assistants (the mapping proposer and the question router): one interface,
three implementations chosen by the environment, so the same code runs on Claude, on an open-weight model served by
Ollama on the firm's own GPU, or on no model at all (the deterministic paths).

Selection (get()):
  ACTIVATION_LLM=anthropic|ollama|claudecode|none     an explicit choice wins (claudecode falls back to ollama when not logged in)
  otherwise ACTIVATION_OLLAMA_URL set      -> ollama
  otherwise a Claude credential is set     -> anthropic (ANTHROPIC_API_KEY or ANTHROPIC_AUTH_TOKEN)
  otherwise http://127.0.0.1:11434 answers -> ollama
  otherwise                                -> none
ACTIVATION_OLLAMA_MODEL names the local model (default qwen3:4b); ACTIVATION_OLLAMA_CTX its context window (default and
maximum 8192: a model's plan prompt is 2.5k to 3.5k tokens, and Ollama truncates an over-long prompt silently); ACTIVATION_LLM_TIMEOUT the per-call
timeout in seconds.

Provider methods: structured(system, user, schema, max_tokens) -> parsed JSON object; name(); label(); model;
available(). Every failure raises LLMError with a readable message; callers fall back to their deterministic path and
say so. Standard library only for Ollama (urllib).
"""
import json, os, time, urllib.error, urllib.request

DEFAULT_OLLAMA = "http://127.0.0.1:11434"
OLLAMA_LABELS = {"qwen3:4b": "Qwen3 4B"}
CLAUDE_LABELS = {"claude-opus-5-5": "Claude Opus 5.5", "claude-sonnet-5-5": "Claude Sonnet 5.5"}
_CACHE = {}


class LLMError(RuntimeError):
    """A model call that did not produce a usable answer (unreachable, timed out, refused, cut off, not JSON)."""


def timeout_s(default=180):
    try:
        return float(os.environ.get("ACTIVATION_LLM_TIMEOUT", default))
    except ValueError:
        return float(default)


def has_claude_key():
    """True when a Claude credential is in the environment (its value is never read here)."""
    return bool(os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"))


class NoProvider:
    kind, model = "none", None

    def name(self):
        return "none"

    def label(self):
        return "no model (deterministic paths only)"

    def available(self):
        return False

    def structured(self, system, user, schema, max_tokens=1024, **kw):
        raise LLMError("no model provider is configured")


class Ollama:
    """An open-weight model on an Ollama server: POST /api/chat with the JSON schema as the format, no thinking,
    temperature 0 and an 8k context."""
    kind = "ollama"

    def __init__(self, url=None, model=None, num_ctx=None):
        self.url = (url or os.environ.get("ACTIVATION_OLLAMA_URL") or DEFAULT_OLLAMA).rstrip("/")
        self.model = model or os.environ.get("ACTIVATION_OLLAMA_MODEL") or "qwen3:4b"
        self.num_ctx = min(8192, int(num_ctx or os.environ.get("ACTIVATION_OLLAMA_CTX") or 8192))
        self.calls, self.seconds, self.prompt_tokens, self.output_tokens = 0, 0.0, 0, 0

    def name(self):
        return f"ollama/{self.model}"

    def label(self):
        nice = OLLAMA_LABELS.get(self.model, self.model)
        where = "the server's GPU" if self.url == DEFAULT_OLLAMA or "127.0.0.1" in self.url or "localhost" in self.url else self.url
        return f"{nice} on {where} (Ollama)"

    def _req(self, path, body=None, timeout=None):
        data = None if body is None else json.dumps(body).encode()
        req = urllib.request.Request(self.url + path, data=data, headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=timeout or timeout_s()) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            raise LLMError(f"Ollama {path} returned HTTP {e.code}: {e.read().decode(errors='replace')[:300]}") from e
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            raise LLMError(f"Ollama at {self.url} is unreachable or timed out ({e})") from e

    def available(self, timeout=1.5):
        """The server answers and has the model; cached for 30 seconds."""
        key = ("ollama", self.url, self.model)
        hit = _CACHE.get(key)
        if hit and time.time() - hit[1] < 30:
            return hit[0]
        try:
            tags = self._req("/api/tags", timeout=timeout)
            names = {m.get("name") for m in tags.get("models", [])} | {m.get("model") for m in tags.get("models", [])}
            ok = self.model in names or f"{self.model}:latest" in names
        except LLMError:
            ok = False
        _CACHE[key] = (ok, time.time())
        return ok

    def structured(self, system, user, schema, max_tokens=1024, **kw):
        est = (len(system) + len(user)) / 3.6 + len(json.dumps(schema)) / 4   # Ollama truncates the head of an over-long prompt silently
        if est + max_tokens > self.num_ctx:
            raise LLMError(f"the prompt (about {int(est)} tokens) plus the answer would not fit the {self.num_ctx}-token context; raise ACTIVATION_OLLAMA_CTX or narrow the plan")
        body = dict(model=self.model, stream=False, think=False, format=schema, keep_alive="30m",
                    options=dict(temperature=0, num_ctx=self.num_ctx, num_predict=max_tokens),
                    messages=[{"role": "system", "content": system}, {"role": "user", "content": user}])
        t0 = time.time()
        r = self._req("/api/chat", body, timeout=kw.get("timeout"))
        self.calls += 1; self.seconds += time.time() - t0
        self.prompt_tokens += r.get("prompt_eval_count", 0); self.output_tokens += r.get("eval_count", 0)
        if r.get("prompt_eval_count", 0) >= self.num_ctx:
            raise LLMError(f"the prompt filled the {self.num_ctx}-token context; the answer would be unreliable")
        if r.get("done_reason") == "length":
            raise LLMError(f"the answer was cut off at {max_tokens} tokens")
        text = (r.get("message") or {}).get("content", "")
        try:
            return json.loads(text)
        except json.JSONDecodeError as e:
            raise LLMError(f"the model's answer is not JSON: {text[:200]!r}") from e

    def stats(self):
        return dict(calls=self.calls, model_seconds=round(self.seconds, 1), prompt_tokens=self.prompt_tokens, output_tokens=self.output_tokens)


class Anthropic:
    """Claude through the Anthropic SDK: structured output (output_config.format) with the server-side refusal
    fallback, streamed so a large max_tokens does not hit the HTTP timeout."""
    kind = "anthropic"

    def __init__(self, model=None, effort=None):
        # ACTIVATION_ANTHROPIC_MODEL and ACTIVATION_ANTHROPIC_EFFORT set the deployment's defaults (the EC2 service unit)
        self.model = model or os.environ.get("ACTIVATION_ANTHROPIC_MODEL") or "claude-opus-5-5"
        self.effort = effort or os.environ.get("ACTIVATION_ANTHROPIC_EFFORT") or "high"
        self.calls, self.seconds = 0, 0.0

    def name(self):
        return f"anthropic/{self.model}"

    def label(self):
        return f"{CLAUDE_LABELS.get(self.model, self.model)} (Anthropic API)"

    def available(self):
        if not has_claude_key():
            return False
        try:
            import anthropic  # noqa: F401
            return True
        except ImportError:
            return False

    def structured(self, system, user, schema, max_tokens=16000, model=None, effort=None, **kw):
        try:
            import anthropic
        except ImportError as e:
            raise LLMError("the anthropic package is not installed") from e
        t0 = time.time()
        try:
            with anthropic.Anthropic().beta.messages.stream(
                    model=model or self.model, max_tokens=max_tokens, system=system,
                    betas=["server-side-fallback-2026-07-01"], fallbacks="default",
                    output_config={"effort": effort or self.effort, "format": {"type": "json_schema", "schema": schema}},
                    messages=[{"role": "user", "content": user}]) as st:
                msg = st.get_final_message()
        except anthropic.APIError as e:
            raise LLMError(f"Claude call failed: {type(e).__name__}: {e}") from e
        finally:
            self.calls += 1; self.seconds += time.time() - t0
        if msg.stop_reason in ("refusal", "max_tokens"):
            raise LLMError(f"Claude stopped with {msg.stop_reason}")
        text = next((b.text for b in msg.content if b.type == "text"), "")
        try:
            return json.loads(text)
        except json.JSONDecodeError as e:
            raise LLMError(f"Claude's answer is not JSON: {text[:200]!r}") from e

    def stats(self):
        return dict(calls=self.calls, model_seconds=round(self.seconds, 1))


class ClaudeCode:
    """Claude Code on this machine, logged in with the user's subscription, run headless (`claude -p`) with the
    activation MCP server attached: Claude plans and runs the query tools itself and returns a structured summary.
    This is the user's own use of their subscription through the official client; an application serving other
    people needs the API provider instead."""
    kind = "claudecode"

    def __init__(self, binary=None, model=None):
        import shutil
        self.binary = binary or os.environ.get("ACTIVATION_CLAUDE_BIN") or shutil.which("claude") or os.path.expanduser("~/.local/bin/claude")
        self.model = model or os.environ.get("ACTIVATION_CLAUDE_MODEL") or None     # None: the subscription's default
        self.calls, self.seconds = 0, 0.0

    def name(self):
        return "claudecode/" + (self.model or "default")

    def label(self):
        return "Claude Code on the server (subscription)" + (f", {self.model}" if self.model else "")

    def available(self):
        key = ("claudecode", self.binary)
        hit = _CACHE.get(key)
        if hit and time.time() - hit[1] < 60:
            return hit[0]
        ok = False
        if os.path.exists(self.binary):
            try:
                import subprocess
                r = subprocess.run([self.binary, "auth", "status"], capture_output=True, text=True, timeout=20)
                try:
                    ok = bool(json.loads(r.stdout).get("loggedIn"))
                except Exception:
                    ok = r.returncode == 0 and "not logged in" not in (r.stdout + r.stderr).lower()
            except Exception:
                ok = False
        _CACHE[key] = (ok, time.time())
        return ok

    def run(self, system, prompt, schema, mcp_config, server_name, max_turns=10, timeout=None):
        """One headless Claude Code session: returns the parsed structured result and the session's usage."""
        import subprocess
        cmd = [self.binary, "-p", prompt, "--output-format", "json", "--json-schema", json.dumps(schema), "--system-prompt", system,
               "--tools", "", "--max-turns", str(max_turns), "--no-session-persistence", "--permission-mode", "dontAsk"]
        if mcp_config:  # with the activation tools attached; without them, one structured answer (the mapping proposer's shape)
            cmd += ["--mcp-config", mcp_config, "--strict-mcp-config", "--allowedTools", f"mcp__{server_name}"]
        if self.model:
            cmd += ["--model", self.model]
        env = dict(os.environ, PATH=os.path.dirname(self.binary) + ":" + os.environ.get("PATH", ""))
        t0 = time.time()
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout or timeout_s(240), env=env)
        except subprocess.TimeoutExpired as e:
            raise LLMError(f"Claude Code did not answer within {int(timeout or timeout_s(240))} s") from e
        finally:
            self.calls += 1; self.seconds += time.time() - t0
        if r.returncode != 0:
            raise LLMError(f"Claude Code exited {r.returncode}: {(r.stderr or r.stdout).strip()[:300]}")
        try:
            out = json.loads(r.stdout)
        except json.JSONDecodeError as e:
            raise LLMError(f"Claude Code's output is not JSON: {r.stdout[:200]!r}") from e
        if out.get("is_error") or out.get("terminal_reason") in ("api_error", "error", "auth_error"):
            raise LLMError(f"Claude Code reported {out.get('terminal_reason') or 'an error'}: {str(out.get('result') or out.get('error') or '')[:300]}")
        res = out.get("structured_output")
        if res is None:
            text = out.get("result") or ""
            try:
                res = json.loads(text[text.find("{"):text.rfind("}") + 1])
            except Exception as e:
                raise LLMError(f"Claude Code's answer is not the structured result: {text[:200]!r}") from e
        return res, dict(turns=out.get("num_turns"), duration_ms=out.get("duration_ms"), cost_usd=out.get("total_cost_usd"), session=out.get("session_id"))

    def structured(self, system, user, schema, max_tokens=1024, **kw):
        res, _ = self.run(system, user, schema, kw.get("mcp_config", ""), kw.get("server_name", "cg-activation"),
                          max_turns=kw.get("max_turns", 10 if kw.get("mcp_config") else 1), timeout=kw.get("timeout"))
        return res

    def stats(self):
        return dict(calls=self.calls, model_seconds=round(self.seconds, 1))


def make(kind, **kw):
    return {"ollama": Ollama, "anthropic": Anthropic, "claudecode": ClaudeCode, "none": NoProvider}[kind](**kw)


def configured_kind():
    """The provider kind the environment selects (see the module docstring)."""
    want = (os.environ.get("ACTIVATION_LLM") or "").strip().lower()
    if want in ("anthropic", "claude"):
        return "anthropic"
    if want in ("ollama", "local"):
        return "ollama"
    if want in ("claudecode", "claude-code", "code"):
        return "claudecode"
    if want == "none":
        return "none"
    if os.environ.get("ACTIVATION_OLLAMA_URL"):
        return "ollama"
    if has_claude_key():
        return "anthropic"
    return "ollama" if Ollama().available() else "none"


def get(kind=None, **kw):
    """The provider for this kind (or the configured one); NoProvider when it is not usable."""
    kind = kind or configured_kind()
    if kind == "none":
        return NoProvider()
    p = make(kind, **kw)
    if p.available():
        return p
    if kind == "claudecode":  # not installed or not logged in: the local model stands in
        o = Ollama()
        return o if o.available() else NoProvider()
    return NoProvider()


def describe(p=None):
    p = p or get()
    return dict(kind=p.kind, name=p.name(), label=p.label(), model=p.model, available=p.available())


if __name__ == "__main__":
    p = get()
    print(json.dumps(describe(p), indent=1))
    if p.available():
        t0 = time.time()
        print(p.structured("Answer in JSON.", "What is 2 + 2?", {"type": "object", "properties": {"answer": {"type": "integer"}},
                                                                  "required": ["answer"]}, 30), f"{time.time() - t0:.2f}s")
