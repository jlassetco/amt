"""MCP server of the activation demo: the compiled semantic model (SM-20, SM-21) as tools an assistant can call, every
answer carrying its lineage (metric -> product measure -> taxonomy attribute -> owner) and every declined question its gap.

Usage (from _tools/):
  activation/.venv/bin/python activation/serve/mcp_server.py              stdio MCP server (see serve/mcp.json)
  activation/.venv/bin/python activation/serve/mcp_server.py --selftest   calls every tool in-process and prints the results

ask() uses the model provider serve/llm.py selects: Claude (Sonnet) plans tool calls when the provider is Anthropic; a local
open-weight model (Ollama) makes one small structured call that turns the question into a query plan, which runs here.
With no provider, a declined plan or a plan that does not run, the deterministic router answers (it matches the question
to the compiled model's verified and cannot-answer questions). Every answer names the assistant that produced it.
"""
import json, math, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(HERE))
import _paths  # noqa: E402
import config  # noqa: E402
import query as Q  # noqa: E402
import llm  # noqa: E402

ROUTER_MODEL = os.environ.get("ACTIVATION_ROUTER_MODEL") or "claude-sonnet-5-5"   # the question router's Claude model
ROW_CAP = 25
STOP = set("the a an of and or for to in on by is at as be what were was which how do does did many much have has with its "
           "it this that from per are each we our their there".split())
SYN = {"nna": "net new assets", "aum": "assets under management", "adviser": "advisor", "advisers": "advisors"}
DIMENSIONS = [("business line", "Business Line"), ("holding type", "Holding Type"), ("share class", "Share Class"),
              ("channel", "Channel"), ("advisor", "Advisor"), ("segment", "Segment")]
_CACHE = {}


def has_key():
    """True when a Claude credential is in the environment (its value is never read here)."""
    return llm.has_claude_key()


def provider():
    """The configured model provider (cached per process; NoProvider when none is usable)."""
    if "llm" not in _CACHE:
        _CACHE["llm"] = llm.get()
    return _CACHE["llm"]


def _m():
    if "model" not in _CACHE:
        _CACHE["model"] = Q.load()
    return _CACHE["model"]


def activation():
    if "act" not in _CACHE:
        import runtime
        _CACHE["act"] = json.load(open(os.path.join(runtime.out_dir(), "activation.json")))
    return _CACHE["act"]


def plain(x):
    """JSON-safe copy (dates and decimals as strings or floats)."""
    return json.loads(json.dumps(x, default=lambda v: float(v) if hasattr(v, "as_integer_ratio") else str(v)))


def tokens(text):
    text = " ".join(SYN.get(w, w) for w in re.split(r"[^a-z0-9%]+", str(text).lower()))
    return {w[:-1] if w.endswith("s") and len(w) > 3 and not w.endswith("ss") else w for w in text.split() if w and w not in STOP}


def sim(a, b):
    """Cosine overlap of two token sets."""
    return len(a & b) / math.sqrt(len(a) * len(b)) if a and b else 0.0


def list_metrics(model: str | None = None) -> dict:
    """Every metric of the compiled model: name, model, aggregation, answerable and, when not, why."""
    ms = [dict(name=m["name"], model=m["model"], aggregation=m.get("aggregation"), answerable=bool(m.get("answerable")),
               reason=m.get("reason", "")) for m in _m()["metrics"] if model in (None, m["model"])]
    return dict(count=len(ms), answerable=sum(m["answerable"] for m in ms), metrics=ms)


def describe(metric: str) -> dict:
    """A metric's definition, aggregation and time rule, and its lineage: product measure, taxonomy attributes with
    definitions, owner and steward note."""
    m0 = Q.find_metric(_m(), metric)
    if m0 is None:
        return dict(error=f"no metric named {metric!r}", suggestions=[m["name"] for m in _m()["metrics"] if tokens(metric) & tokens(m["name"])][:10])
    m = Q.resolve_ref(_m(), m0) or m0
    cuts = {}
    if m.get("answerable") and m.get("tables"):
        cm = _m(); base_key = m["tables"][0]; base = cm["tables"][base_key]
        cuts = {base["name"]: list(base["columns"])}
        cuts.update(Q.reachable(cm, base_key))
        fv = filter_values()
        cuts = {t: [f"{c} in [{', '.join(fv[t + '.' + c][:12])}]" if (t + "." + c) in fv else c for c in cols] for t, cols in cuts.items()}
    return plain(dict(name=m0["name"], model=m0["model"], definition=m.get("description", ""), aggregation=m.get("aggregation"),
                      time_rule=m.get("time_rule", ""), note=m.get("note", ""), answerable=bool(m.get("answerable")),
                      reason=m.get("reason", ""), base_table=(m.get("tables") or [""])[0].split(".")[-1],
                      breakdown_columns=cuts, how_to_query="by and filters take table.column from breakdown_columns; a filter is \"table.column = 'value'\"",
                      lineage=Q.lineage(_m(), m)))


def query(metric: str, by: list[str] | None = None, filters: list[str] | None = None, as_of: str | None = None,
          period: str | None = None, dimension_type: str | None = None) -> dict:
    """Run a metric: by = ["table.column", ...] breakdowns, filters = SQL conditions, as_of = YYYY-MM-DD, period = YYYY-Qn or
    YYYY-MM-DD..YYYY-MM-DD, dimension_type for client_assets_flows (Channel, Advisor, Segment, Holding Type, ...).
    Returns the rows (first 25 and the count), the SQL and the lineage."""
    r = Q.run(_m(), metric, by=by or [], filters=filters or [], as_of=as_of, period=period, dimension_type=dimension_type)
    r["row_count"] = len(r["rows"]); r["rows"] = r["rows"][:ROW_CAP]
    return plain(r)


def coverage() -> dict:
    """The activation summary and the products not yet enabled, with the attributes they miss."""
    a = activation()
    partial = [dict(id=p["id"], name=p["name"], state=p["state"], missing=p.get("missing", [])) for p in a["products"].values() if p["state"] != "enabled"]
    return dict(as_of=a.get("as_of"), summary=a["summary"], partial_products=partial)


def cannot_answer(question: str) -> dict:
    """The compiled model's declined questions that resemble this one (with their gap ids), and the metrics that are
    not answerable whose names resemble it (with the reason)."""
    qt = tokens(question)
    ca = sorted(((sim(qt, tokens(c["question"])), c) for c in _m()["cannot_answer"]), key=lambda x: -x[0])
    hits = [dict(c, score=round(s, 2), gap=c.get("gap") or None) for s, c in ca if s >= 0.3] or \
           [dict(c, score=round(s, 2), gap=c.get("gap") or None) for s, c in ca[:1] if s > 0]
    mets = [dict(name=m["name"], model=m["model"], reason=m.get("reason", "")) for m in _m()["metrics"]
            if not m.get("answerable") and len(qt & tokens(m["name"])) >= max(2, math.ceil(0.6 * len(tokens(m["name"]))))]
    return dict(question=question, matches=hits, gaps=sorted({h["gap"] for h in hits if h["gap"]}), unanswerable_metrics=mets[:10])


def ask(question: str) -> dict:
    """Answer a business question from the semantic model: the metric results with lineage, or the reason and gap when
    the model declines it. Uses the configured model (Claude or a local model) when one is available, else the
    deterministic router; the answer's 'assistant' names which one answered."""
    p = provider()
    if p.kind == "anthropic":
        r = ask_claude(question); r["assistant"] = p.label(); return r
    if p.kind == "claudecode":
        return ask_claude_code(question, p)
    if p.kind == "ollama":
        return ask_local(question, p)
    r = route(question); r["assistant"] = "router"; return r


# ------------------------------------------------------------------------------------- Claude Code with the tools
CLAUDE_CODE_SYSTEM = """You answer a wealth manager's business questions from its semantic model, using only the cg-activation
tools: list_metrics (optionally by model id) to find the metrics, describe for a metric's definition, lineage and, above all,
breakdown_columns (the exact table.column names you may pass as by or filters, with the values of the filterable ones:
always call describe before the first query of a metric and copy the names from it), query to get numbers (metric; by: list of table.column breakdowns; filters: list of "table.column = 'value'"; period: YYYY-Qn or
YYYY-MM-DD..YYYY-MM-DD, empty for the as-of month-end; dimension_type for client_assets_flows metrics), cannot_answer to
check whether the model declines the question. Vocabulary: 'AUM' or 'assets' are Client Assets (certified, by channel),
Household Client Assets (households) or Relationship Client Assets / At-Risk Relationship Client Assets (institutional
clients, model SM-27); 'last four quarters' is 2025-10-01..2026-09-30; 'this quarter' is 2026-Q3. Call query for every
number you cite; never compute or invent one. Keep to at most five query calls. Then return the structured result: a
two-to-four sentence answer with the numbers, the exact query calls behind them, the parts the model declines, and the
model ids used. If no metric fits, say so in the answer with queries empty."""
CLAUDE_CODE_SCHEMA = {"type": "object", "additionalProperties": False, "required": ["answer", "queries", "declined", "models"],
                      "properties": {"answer": {"type": "string"},
                                     "queries": {"type": "array", "maxItems": 4, "items": {"type": "object", "additionalProperties": False, "required": ["metric", "by", "filters", "period", "dimension_type"],
                                                 "properties": {"metric": {"type": "string"}, "by": {"type": "array", "items": {"type": "string"}}, "filters": {"type": "array", "items": {"type": "string"}},
                                                                "period": {"type": "string"}, "dimension_type": {"type": "string"}}}},
                                     "declined": {"type": "array", "items": {"type": "object", "additionalProperties": False, "required": ["part", "reason"],
                                                  "properties": {"part": {"type": "string"}, "reason": {"type": "string"}}}},
                                     "models": {"type": "array", "items": {"type": "string"}}}}


def claude_mcp_config():
    """The MCP config Claude Code loads: this server on the reference runtime (the Spark metastore is single-process)."""
    path = os.path.join(_paths.OUT, "claude_mcp.json")
    cfg = {"mcpServers": {"cg-activation": {"command": sys.executable, "args": [os.path.abspath(__file__)],
                                            "env": {"ACTIVATION_RUNTIME": "duckdb", "ACTIVATION_LLM": "none"}}}}
    with open(path, "w") as f:
        json.dump(cfg, f, indent=1)
    return path


def ask_claude_code(question, p=None):
    """Claude Code (the user's subscription) plans and runs the query tools in a headless session; the queries it cites
    are re-run here so the page shows the same rows with their lineage. A failed session falls back to the local model."""
    p = p or provider()
    ds, d = demo_match(question)
    if d and ds >= 0.85:
        r = route(question); r.update(assistant="verified plan for a demo question (no model call)"); return r
    try:
        res, usage = p.run(CLAUDE_CODE_SYSTEM, question, CLAUDE_CODE_SCHEMA, claude_mcp_config(), "cg-activation")
    except llm.LLMError as e:
        o = llm.get("ollama")
        if o.available():
            r = ask_local(question, o); r["fallback"] = f"Claude Code did not answer ({e}); the local model answered"; return r
        r = route(question); r.update(assistant="router", fallback=f"Claude Code did not answer ({e}); deterministic router used"); return r
    results = []
    for i, qd in enumerate((res.get("queries") or [])[:4]):
        try:
            r = Q.run(_m(), qd["metric"], by=[b for b in qd.get("by") or [] if b], filters=[f for f in qd.get("filters") or [] if f],
                      period=(qd.get("period") or None), dimension_type=(qd.get("dimension_type") or None))
            results.append(dict(r, rows=r["rows"][:ROW_CAP], row_count=len(r["rows"]), role="asked" if i == 0 else "context"))
        except Exception as e:
            results.append(dict(metric=qd.get("metric"), answerable=False, reason=str(e)[:160], rows=[], role="asked" if i == 0 else "context"))
    return plain(dict(question=question, route="claude_code", assistant=p.label(), model=p.model, plan=dict(queries=res.get("queries"), models=res.get("models")),
                      answer=res.get("answer", ""), results=results, declined_parts=[dict(metric=x.get("part"), reason=x.get("reason")) for x in res.get("declined") or []],
                      usage=usage,
                      lineage=[dict(metric=r["metric"], **{k: r["lineage"][k] for k in ("model", "owner", "product", "product_measure")},
                                    attributes=[a["attribute"] for a in r["lineage"]["attributes"]]) for r in results if r.get("lineage")]))


# ------------------------------------------------------------------------------------- the local model's query plan
PLAN_DIMS = ["Channel", "Advisor", "Segment", "Business Line", "Holding Type", "Share Class", "Total", ""]

# Questions the demo is built to answer beyond the models' verified questions: a plan each, run by the deterministic
# router when the question matches, and shown to the local model as examples.
DEMO_QUESTIONS = [
    dict(model="SM-27", question="How much of our AUM with public pension plans sits with clients whose relationship is at risk?",
         metrics=["At-Risk Relationship Client Assets", "At-Risk Relationships", "Relationship Client Assets"],
         by=["institutional_client.institutional_client_type"], filters=[("institutional_client.institutional_client_type", "Public Pension Plan")],
         note="'AUM with' a client here is the client assets attributed to the client's relationships at the latest month-end "
              "(DP-510, analytical); Firm AUM is SM-11's and the certified Client Assets by Institutional channel are SM-20's."),
    dict(model="SM-27", question="Which institutional relationships are at risk, and what do they hold with us?",
         metrics=["At-Risk Relationship Client Assets", "At-Risk Relationships"], by=["service_relationship.servicing_segment"], filters=[], note=""),
    dict(model="SM-28", question="How have gross and net fee revenue and the effective net fee rate moved by offering over the last four quarters?",
         metrics=["Gross Fee Revenue", "Net Fee Revenue", "Effective Net Fee Rate"], by=["client_revenue.revenue_service_offering"], filters=[],
         period="2025-10-01..2026-09-30",
         note="Fee revenue by the offering the account is enrolled in over the last four fiscal quarters (DP-012 client revenue records, fiscal months 2025-10 to 2026-09); the effective net fee rate annualizes the asset-based fee streams over the billable assets of the calculations the records cite (DP-305). Ask the same by client_revenue.client_revenue_period for the month-by-month movement."),
    dict(model="SM-28", question="Which advisory fee runs failed reconciliation this quarter, and which accounts were billed outside their schedule?",
         metrics=["Failed Fee Runs", "Fee Runs Tested", "Accounts Billed Off Schedule", "Billing Variance", "Household Breakpoint Not Applied"], by=[], filters=[], period="2026-Q3",
         note="Runs with their billing period end in the quarter (released or approved, not simulations) whose reconciliation is open or whose control total differs from their calculations; the off-schedule accounts come from the re-performance of every released calculation on the schedule version its assignment names (DP-346)."),
    dict(model="SM-28", question="Which service offerings and client segments have negative contribution over the last four quarters?",
         metrics=["Offerings and Segments With Negative Contribution", "Contribution Margin", "Contribution Margin %", "Operating Profit"], by=["profitability.profitability_service_offering"], filters=[],
         period="2025-10-01..2026-09-30",
         note="Profitability at the service-offering grain (DP-499, actual version, final allocation run): gross revenue less distribution payments and direct sales and marketing cost is the contribution margin; the negative flag is set on a cut whose contribution over the trailing four quarters is below zero. Ask the same by client segment for the segment cuts."),
    dict(model="SM-28", question="What does it cost to serve each client segment, and what is the cost-to-serve rate?",
         metrics=["Total Cost to Serve", "Cost to Serve Rate (bps)", "Cost to Serve per Household"], by=["cost_to_serve.cts_client_segment"], filters=[], period="2026-Q3",
         note="Cost to serve at the client-segment grain from the final actual allocation runs of the quarter (DP-498): the allocated cost of the pools with a cost-to-serve component; the rate annualizes it over the certified average client assets of the segment."),
]
# Dimension columns a plan may filter or break down by, with their values read from the built tables.
FILTER_COLUMNS = ["institutional_client.institutional_client_type", "service_relationship.servicing_segment", "service_relationship.service_tier",
                  "service_relationship.service_relationship_status", "household.household_formation_basis",
                  "client_revenue.revenue_service_offering", "client_revenue.client_revenue_stream", "client_revenue.revenue_channel", "client_revenue.client_segment_at_period_end",
                  "profitability.profitability_service_offering", "profitability.profitability_client_segment", "profitability.profitability_business_line", "profitability.profitability_channel",
                  "cost_to_serve.cts_client_segment", "cost_to_serve.cts_channel", "cost_to_serve.cts_service_offering", "cost_to_serve.cts_service_tier",
                  "fee_run.run_type", "fee_run.fee_reconciliation_status", "fee_schedule.fee_schedule_type"]


# Breakdown columns offered to the model beside the filterable ones: keys and periods a question may ask "by".
BY_COLUMNS = {"client_assets_flows.dimension_key", "household_360.household_key", "household.household_name", "account_asset_summary.summary_distribution_channel",
              "account_asset_summary.summary_holding_type", "distribution_channel.channel_name", "fee_run.fee_calculation_run_id", "client_revenue.client_revenue_period",
              "profitability.profitability_period", "cost_to_serve.cts_profitability_period", "fee_debit.fee_debit_status", "service_relationship.service_relationship_id",
              "relationship_health.service_relationship_key", "allocation_rule.target_dimension", "allocation_rule.source_cost_pool", "fee_schedule.fee_schedule_name"}


def filter_values():
    """{table.column: [values]} for the filterable dimension columns that exist in the compiled model."""
    if "fvals" in _CACHE:
        return _CACHE["fvals"]
    import runtime
    rt = runtime.get(); cm = _m(); out = {}
    for fc in FILTER_COLUMNS:
        t, c = fc.split(".")
        tb = next((x for x in cm["tables"].values() if x["name"] == t and x.get("view") and c in x["columns"]), None)
        if tb is None:
            continue
        try:
            vals = [r[0] for r in rt.fetch(f"select distinct {rt.q(c)} from {tb['view']} where {rt.q(c)} is not null order by 1 limit 25")]
        except Exception:
            vals = []
        if vals:
            out[fc] = [str(v) for v in vals]
    labels = {}
    try:  # service offerings are referenced by id; the model sees and may answer with their names
        labels = {r[0]: r[1] for r in rt.fetch(rt.sql("select offering_id, offering_name from dp_004.service_offering"))}
    except Exception:
        pass
    _CACHE["flabels"] = {fc: {labels[v]: v for v in vs if v in labels} for fc, vs in out.items() if any(v in labels for v in vs)}
    _CACHE["fvals"] = out
    return out


def filter_label_text(fc, vals):
    """A column's values for the prompt, with the name beside an id."""
    lab = {v: k for k, v in _CACHE.get("flabels", {}).get(fc, {}).items()}
    return ", ".join(f"{v} ({lab[v]})" if v in lab else v for v in vals)


def canonical_value(fc, v):
    """The stored value for a value the model wrote (an id, or the name of an offering)."""
    fv = filter_values()
    if v in fv.get(fc, []):
        return v
    lab = _CACHE.get("flabels", {}).get(fc, {})
    if v in lab:
        return lab[v]
    head = v.split(" (")[0].strip()
    if head in fv.get(fc, []):
        return head
    return lab.get(v.strip(" )").split("(")[-1].strip())


def demo_match(question):
    """The demo question closest to this one, with its plan, when it is close enough."""
    qt = tokens(question)
    best = max(((sim(qt, tokens(d["question"])), d) for d in DEMO_QUESTIONS), key=lambda x: x[0])
    return best if best[0] >= 0.7 else (0, None)


def repair_metric(metric, columns):
    """An answerable metric of the model that owns the plan's columns whose name contains the planned metric's words
    (the shortest such name), or None."""
    cm = _m()
    models = {k.split(".")[0] for k, t in cm["tables"].items() for c in columns if t["name"] == c.split(".")[0] and k.split(".")[0] != "SM-00"}
    want = tokens(metric)
    cands = [m for m in cm["metrics"] if m.get("answerable") and not m.get("ref") and m["model"] in models and m["name"] != metric and want <= tokens(m["name"])]
    return min((m["name"] for m in cands), key=len) if cands else None


def run_plan(metric, by=(), filters=(), period=None, dimension_type=None):
    """A plan through the query engine, with filters as 'table.column = value'."""
    fs = [f"{c} = '{str(v).replace(chr(39), chr(39) * 2)}'" for c, v in filters]
    return Q.run(_m(), metric, by=list(by), filters=fs, period=period or None, dimension_type=dimension_type)


MODEL_WORDS = {  # vocabulary that points a question at a model before the plan is made (a small model plans better over one model)
    "SM-20": "assets flows net new nna channel advisor share class holding type funded accounts clients households growth sales redemptions overlap transfers matches",
    "SM-21": "household households member owner advisor tier plan goals trust",
    "SM-27": "institutional relationship relationships pension endowment foundation corporate plan mandate ocio consultant health score at risk segment",
    "SM-28": "fee fees billing billed revenue rate bps schedule waiver debit run runs reconciliation off schedule breakpoint cost serve profitability margin "
             "contribution operating profit allocation pool offering program fiscal quarter economics",
}


def pick_models(question):
    """The model(s) a question belongs to: the best score over the model's vocabulary, metric names, verified and demo
    questions; a second model rides along when it scores nearly as well."""
    cm = _m(); qt = tokens(question); scores = {}
    for mid in cm["models"]:
        if mid == "SM-00" or mid not in {m["model"] for m in cm["metrics"] if m.get("answerable")}:
            continue
        sc = [sim(qt, tokens(MODEL_WORDS.get(mid, ""))) * 2]
        sc += [sim(qt, tokens(x["question"])) for x in cm["questions"] if x["model"] == mid]
        sc += [sim(qt, tokens(d["question"])) for d in DEMO_QUESTIONS if d["model"] == mid]
        sc += [len(qt & tokens(m["name"])) / max(len(tokens(m["name"])), 1) * 0.8 for m in cm["metrics"] if m["model"] == mid and m.get("answerable") and not m.get("ref")]
        scores[mid] = max(sc or [0])
    best = max(scores.values() or [0])
    return tuple(sorted(m for m, v in scores.items() if v >= best - 0.05 and v > 0)) or tuple(scores)


def plan_context(models=None):
    """A compact glossary for the local model, and the enums its plan is constrained to, for the chosen model(s)."""
    models = tuple(models or ())
    key = ("plan",) + models
    if key in _CACHE:
        return _CACHE[key]
    cm = _m()
    in_scope = (lambda mid: mid in models) if models else (lambda mid: True)
    table_model = {t["name"]: k.split(".")[0] for k, t in cm["tables"].items()}
    mets = [m for m in cm["metrics"] if m.get("answerable") and not m.get("ref") and in_scope(m["model"])]
    bases = []
    for m in mets:
        b = (m.get("tables") or [""])[0]
        if b and b not in bases:
            bases.append(b)
    by = []
    for b in bases:
        t = cm["tables"][b]
        by += [f"{t['name']}.{c}" for c in t["columns"] if f"{t['name']}.{c}" in BY_COLUMNS]
    fv = {fc: v for fc, v in filter_values().items() if in_scope(table_model.get(fc.split(".")[0], "")) or
          (table_model.get(fc.split(".")[0]) == "SM-00" and any(fc.split(".")[0] in (cm["tables"][b]["name"],) or True for b in bases))}
    if models:  # shared dimensions only when a chosen model's base reaches them
        fv = {fc: v for fc, v in fv.items() if table_model.get(fc.split(".")[0]) != "SM-00" or any(Q.join_path(cm, b, fc.split(".")[0]) for b in bases)}
    by += [fc for fc in fv if fc not in by]
    dims = [t for t in cm["tables"].values() if t.get("view") and t.get("kind") == "Dimension" and (in_scope(t["model"]) or t["model"] == "SM-00")]
    questions = [v for v in cm["questions"] if in_scope(v["model"])]
    demos = [d for d in DEMO_QUESTIONS if in_scope(d["model"])]
    declines = [c for c in cm["cannot_answer"] if in_scope(c["model"])]
    named = lambda v: ", ".join(m["name"] for m in metrics_named(v["answer"], v["model"], v["question"])) or "(not answerable here)"
    q = period_of("last quarter")
    model_names = ", ".join(m + " " + cm["models"][m]["name"] for m in models)
    text = (f"The semantic model of a wealth manager, as of {config.AS_OF}" + (f", model(s) {model_names}" if models else "") +
            f". 'Last quarter' or 'this quarter' is {q}; 'this year' "
            f"or 'year to date' is {period_of('this year')}; with no period, the as-of date (leave period empty).\n\n"
            "Answerable metrics (metric: table; description):\n" +
            "\n".join(f"- {m['name']}: {(m.get('tables') or [''])[0].split('.')[-1]}; {m.get('description', '')[:110]}" for m in mets) +
            "\n\nBreakdowns: client_assets_flows metrics break down only by client_assets_flows.dimension_key with a dimension_type "
            "(Channel, Advisor, Segment, Business Line, Holding Type, Share Class); household_360 metrics by household_360.household_key "
            "(one row per household); account_asset_summary by summary_distribution_channel or summary_holding_type.\n"
            "Dimension tables and key columns: " + "; ".join(f"{t['name']} ({', '.join(list(t['columns'])[:4])})" for t in dims[:14]) +
            "\n\nFilterable columns and their values (a filter is {column, value}): " +
            "; ".join(f"{fc} in [{filter_label_text(fc, v)}]" for fc, v in fv.items()) +
            "\n\nVocabulary: 'AUM', 'assets under management' or 'assets with us' means client assets: the certified Client Assets "
            "(client_assets_flows) for the firm or a channel, Household Client Assets for households, and Relationship Client Assets "
            "or At-Risk Relationship Client Assets (relationship_health) for institutional clients and their relationships. 'Public "
            "pension plans', 'endowments', 'corporate plans' are values of institutional_client.institutional_client_type. "
            "'At risk' means the relationship's latest health score flags it (At-Risk Relationships, At-Risk Relationship Client Assets). "
            "Fees, billing and revenue: 'fee revenue' is Gross Fee Revenue / Net Fee Revenue / Client Fee Revenue (client_revenue, by offering, channel, "
            "segment or stream); 'billed fees' are Net Billed Fees / Gross Billed Fees (account_fee_calculation); 'fee rate' is Effective Net Fee Rate "
            "or Average Effective Annual Rate; 'fee runs' are Fee Runs Tested / Failed Fee Runs; 'off schedule' is Accounts Billed Off Schedule and "
            "Billing Variance; 'failed debits' is Failed Fee Debits (fee_debit); 'cost to serve' is Total Cost to Serve / Cost to Serve Rate (bps) / Cost to Serve per Household (cost_to_serve, by "
            "cts_client_segment, cts_channel, cts_business_line, cts_service_offering); 'profitability', 'margin', 'operating profit' are Gross Revenue / "
            "Contribution Margin / Contribution Margin % / Operating Profit / Operating Margin % (profitability, by profitability_service_offering, "
            "profitability_client_segment, profitability_business_line, profitability_channel). 'Last four quarters' is the period 2025-10-01..2026-09-30; "
            "'this quarter' is 2026-Q3."
            "\n\nDemo questions (question -> plan):\n" + "\n".join(f"- {d['question']} -> {d['metrics'][0]} by {', '.join(d['by'])}"
            + (" where " + " and ".join(f"{c} = {v}" for c, v in d["filters"]) if d["filters"] else "") for d in demos) +
            "\n\nVerified questions (question -> metrics):\n" + "\n".join(f"- {v['question']} -> {named(v)}" for v in questions) +
            "\n\nQuestions the model cannot answer (decline these, with the reason):\n" +
            "\n".join(f"- {c['question']}: {c['why'][:120]}" for c in declines))
    S = {"type": "string"}
    schema = {"type": "object", "additionalProperties": False,      # the metric first: a small model decides better that way
              "required": ["metric", "by", "filters", "period", "dimension_type", "intent", "reason"],
              "properties": {"metric": {"type": "string", "enum": [m["name"] for m in mets] + [""]},
                             "by": {"type": "array", "items": {"type": "string", "enum": by}, "maxItems": 2},
                             "filters": {"type": "array", "maxItems": 2, "items": {"type": "object", "additionalProperties": False, "required": ["column", "value"],
                                         "properties": {"column": {"type": "string", "enum": list(fv) + [""]}, "value": {"type": "string", "maxLength": 60}}}},
                             "period": {"type": "string", "maxLength": 24},
                             "dimension_type": {"type": "string", "enum": PLAN_DIMS},
                             "intent": {"type": "string", "enum": ["query", "decline"]},
                             "reason": {"type": "string", "maxLength": 100}}}
    _CACHE[key] = (text, schema)
    return _CACHE[key]


PLAN_SYSTEM = """You turn a business question into one query plan over a semantic model. Pick the answerable metric whose
name or description best matches the question, the breakdown it asks for, the period and the dimension type. Use only
the names given. intent is "query" whenever a metric answers the question; intent is "decline" only when the question
is one the model cannot answer (listed) or no metric fits, and then metric is "". For "which households ..." questions,
break down by household_360.household_key. A condition on a dimension value ("public pension plans", "OCIO relationships")
is a filter {column, value} using the filterable columns and values given, with the value copied from that list; filters is []
otherwise. by lists only the breakdowns the question asks for ("how much" with a filter needs none beyond the filter's column).
A breakdown or filter on an institutional column (institutional_client.*, service_relationship.*) goes with a relationship
metric: "how many relationships" is At-Risk Relationships or Active Relationships by Segment, "how much" is Relationship Client
Assets or At-Risk Relationship Client Assets. "At the end of June" or "as of June 30" is the period 2026-04-01..2026-06-30.
period is YYYY-Qn, YYYY-MM-DD..YYYY-MM-DD or "". reason: one short sentence."""


def ask_local(question, p=None):
    """One structured call to the local model plans the query; the plan runs here. A decline, an invalid plan or a
    failed call falls back to the deterministic router, and the answer says so."""
    p = p or provider()
    ds, d = demo_match(question)
    if d and ds >= 0.85:  # the demo question itself (or near enough): its verified plan, no model call
        r = route(question); r.update(assistant="verified plan for a demo question (no model call)"); return r
    models = pick_models(question)
    text, schema = plan_context(models)
    try:
        plan = p.structured(PLAN_SYSTEM, text + "\n\nQuestion: " + question, schema, 240, timeout=60)
        plan["models"] = list(models)
        plan["by"] = list(dict.fromkeys(plan.get("by") or []))
        plan["filters"] = [dict(t) for t in dict.fromkeys(tuple(sorted(f.items())) for f in (plan.get("filters") or []) if isinstance(f, dict))]
    except llm.LLMError as e:
        r = route(question); r.update(assistant="router", fallback=f"the local model was unavailable ({e}); deterministic router used")
        return r
    period = (plan.get("period") or "").strip()
    if period and not re.match(r"^\d{4}-Q[1-4]$|^\d{4}-\d{2}-\d{2}\.\.\d{4}-\d{2}-\d{2}$", period):
        period = period_of(question)
    plan["period"] = period
    if plan.get("intent") != "query" or not plan.get("metric"):
        r = route(question)
        r.update(assistant="router", plan=plan, fallback=f"{p.label()} declined ({plan.get('reason', '')}); the deterministic router answered")
        if r.get("route") == "declined":
            r["assistant"] = p.label() + " with the router's gap lookup"
        return r
    by, dt = list(plan.get("by") or []), plan.get("dimension_type") or None
    base = (Q.find_metric(_m(), plan["metric"]) or {}).get("tables", [""])[0]
    notes = []
    try:
        if base.endswith("client_assets_flows"):
            bad = [b for b in by if not b.startswith("client_assets_flows.")]
            if bad:  # the certified family cuts only by its own dimension keys; the same measure in the columns' model may cut this way
                alt = repair_metric(plan["metric"], bad + [f.get("column") or "" for f in plan.get("filters") or []])
                if not alt:
                    raise ValueError(f"{plan['metric']} breaks down only by dimension_key, not by {', '.join(by)}")
                notes.append(f"{plan['metric']} breaks down only by its certified dimension keys, not by {', '.join(bad)}; answered with {alt}, the same measure in the model that owns those columns")
                plan["metric"] = alt; base = (Q.find_metric(_m(), alt) or {}).get("tables", [""])[0]
            else:
                by = ["client_assets_flows.dimension_key"] if dt and dt != "Total" else []
        guard = cannot_answer(question)["matches"]
        planned_model = (Q.find_metric(_m(), plan["metric"]) or {}).get("model")
        # a declined question of the planned metric's own model blocks the plan; another model's does not (SM-20 declines
        # household client assets because SM-21 publishes them, so a plan on SM-21 is the right answer)
        plan_cols = set()
        for c in by + [f.get("column") or "" for f in (plan.get("filters") or [])]:
            plan_cols |= tokens(c.split(".")[-1].replace("_", " "))
        about = tokens(guard[0]["question"]) if guard else set()
        if guard and guard[0]["score"] >= 0.6 and guard[0].get("model") in (None, planned_model) and (not plan_cols or (plan_cols & about - {"client", "cts"})):
            raise ValueError(f"the question matches the declined question {guard[0]['question']!r}")
        fv = filter_values()
        flt, qt = [], tokens(question)
        for f in plan.get("filters") or []:
            c, v = f.get("column"), f.get("value")
            cv = canonical_value(c, v) if c in fv and v else None
            if cv and (tokens(v) & qt) and (c, cv) not in flt:
                flt.append((c, cv))
            elif c and v and (c, cv) not in flt:
                notes.append(f"filter {c} = {v!r} dropped: " + ("the question does not name it" if cv else "not a value of that column"))
        # a dimension breakdown the question does not name (and that is not the filter's column) is the model's embellishment
        keep = []
        for b in by:
            named = bool(tokens(b.split(".")[1]) & qt)
            if b in fv and b not in [c for c, _ in flt] and not named:
                notes.append(f"breakdown by {b} dropped: the question does not ask for it")
            elif not named and b.split(".")[0] != base.split(".")[-1] and Q.join_path(_m(), base, b.split(".")[0]) is None:
                notes.append(f"breakdown by {b} dropped: {plan['metric']} cannot reach it and the question does not ask for it")
            else:
                keep.append(b)
        by = keep
        metric = plan["metric"]
        try:
            r = run_plan(metric, by=by, filters=flt, period=period or None, dimension_type=dt if base.endswith("client_assets_flows") else None)
        except Exception as e:
            # the metric cannot be cut by the plan's columns: the same measure published by the columns' own model can
            # ("Client Assets" by institutional client type -> SM-27's "Relationship Client Assets")
            alt = repair_metric(metric, by + [c for c, _ in flt])
            if not alt:
                raise
            notes.append(f"{metric} cannot be cut by {', '.join(by + [c for c, _ in flt])} ({e}); answered with {alt}, the same measure in that model")
            metric = alt
            r = run_plan(metric, by=by, filters=flt, period=period or None)
        plan["metric"] = metric
    except Exception as e:  # an invalid plan (a column the metric cannot break down by) goes to the router
        out = route(question)
        out.update(assistant="router", plan=plan, fallback=f"the plan from {p.label()} did not run ({e}); deterministic router used")
        return out
    rows = r["rows"]
    note = None
    if base.endswith("household_360") and "household_360.household_key" in by and question.lower().startswith("which"):
        rows = [x for x in rows if x.get(r["metric"])]; note = "households where the metric is non-zero"
    if notes:
        note = "; ".join([note] * bool(note) + notes)
    r = dict(r, rows=rows[:ROW_CAP], row_count=len(rows), role="asked", **({"note": note} if note else {}))
    return plain(dict(question=question, route="local_plan", assistant=p.label(), model=p.model, plan=plan,
                      period=period or f"as of {config.AS_OF}", results=[r], answer=plan.get("reason", ""),
                      lineage=[dict(metric=r["metric"], **{k: r["lineage"][k] for k in ("model", "owner", "product", "product_measure")},
                                    attributes=[a["attribute"] for a in r["lineage"]["attributes"]])]))


def period_of(question):
    t = question.lower()
    y, mo = int(config.AS_OF[:4]), int(config.AS_OF[5:7])
    if "quarter" in t:
        return f"{y}-Q{(mo - 1) // 3 + 1}"
    if "year" in t or "ytd" in t:
        return f"{y}-01-01..{config.AS_OF}"
    return None


def metrics_named(text, model_id, question):
    """Metrics of the model whose names appear in a verified answer, longest names first, no overlaps."""
    found, rest = [], text.lower()
    for m in sorted((m for m in _m()["metrics"] if m["model"] == model_id), key=lambda m: -len(m["name"])):
        pat = r"(?<![\w-])" + re.escape(m["name"].lower()) + r"(?![\w-])"
        if re.search(pat, rest):
            found.append(m); rest = re.sub(pat, " ", rest)
    qt = tokens(question)
    hh = "household" in qt
    found.sort(key=lambda m: (-(len(qt & tokens(m["name"])) / len(tokens(m["name"]))), not (hh and "household_360" in str(m.get("tables")))))
    return found


def run_one(m, question, primary):
    """Run one metric with the breakdowns the question's words imply."""
    qt, base = question.lower(), (m.get("tables") or [""])[0]
    period, out = period_of(question), []
    if not primary:
        return [query(m["name"], period=period)]
    if base.endswith("client_assets_flows"):
        dims = [d for w, d in DIMENSIONS if w in qt] or [None]
        return [query(m["name"], by=["client_assets_flows.dimension_key"] if d else [], period=period, dimension_type=d) for d in dims]
    if base.endswith("household_360") and qt.startswith("which"):
        r = Q.run(_m(), m["name"], by=["household_360.household_key"])
        keep = [x for x in r["rows"] if x.get(m["name"])]
        out.append(plain(dict(r, rows=keep[:ROW_CAP], row_count=len(keep), note="households where the metric is non-zero")))
        return out
    return [query(m["name"], period=period)]


def route(question):
    """Deterministic router: the best verified question runs the metrics its answer names; a closer cannot-answer
    question declines with its gap."""
    cm = _m()
    qt = tokens(question)
    ds, d = demo_match(question)
    if d:
        results = []
        for i, mname in enumerate(d["metrics"]):
            try:
                r = run_plan(mname, by=d["by"], filters=d["filters"], period=d.get("period") or period_of(question))
                results.append(dict(r, rows=r["rows"][:ROW_CAP], row_count=len(r["rows"]), role="asked" if i == 0 else "context"))
            except Exception as e:
                results.append(dict(metric=mname, answerable=False, reason=str(e)[:160], rows=[], role="asked" if i == 0 else "context"))
        return plain(dict(question=question, route="demo_question", matched_question=d["question"], score=round(ds, 2),
                          plan=dict(metric=d["metrics"][0], by=d["by"], filters=[dict(column=c, value=v) for c, v in d["filters"]]),
                          period=d.get("period") or period_of(question) or f"as of {config.AS_OF}", results=results, answer=d["note"],
                          lineage=[dict(metric=r["metric"], **{k: r["lineage"][k] for k in ("model", "owner", "product", "product_measure")},
                                        attributes=[a["attribute"] for a in r["lineage"]["attributes"]]) for r in results if r.get("lineage")]))
    vq = max(((sim(qt, tokens(v["question"])), v) for v in cm["questions"]), key=lambda x: x[0])
    ca = max(((sim(qt, tokens(c["question"])), c) for c in cm["cannot_answer"]), key=lambda x: x[0])
    if ca[0] >= vq[0] and ca[0] >= 0.3:
        c = ca[1]; mm = cm["models"].get(c["model"], {})
        return dict(question=question, route="declined", matched_question=c["question"], score=round(ca[0], 2), answer=c["why"],
                    gap=c.get("gap") or "no gap id: a modeling or scope decision", related=cannot_answer(question),
                    lineage=dict(model=c["model"], model_name=mm.get("name"), owner=mm.get("owner")))
    if vq[0] < 0.3:
        direct = max(((sim(qt, tokens(m["name"])), m) for m in cm["metrics"] if m.get("answerable") and not m.get("ref")), key=lambda x: x[0])
        if direct[0] < 0.5:
            return dict(question=question, route="no_match", answer="No verified question or metric matches; see list_metrics.",
                        gap=None, lineage=None, related=cannot_answer(question))
        res = run_one(direct[1], question, True)
        return dict(question=question, route="metric_name", results=res, lineage=[r["lineage"] for r in res])
    v = vq[1]
    named = metrics_named(v["answer"], v["model"], question)
    best = max((len(qt & tokens(m["name"])) / len(tokens(m["name"])) for m in named), default=0)
    results, declined = [], []
    for m in named:
        primary = len(qt & tokens(m["name"])) / len(tokens(m["name"])) >= min(best, 0.5)
        r = Q.resolve_ref(cm, m) if m.get("ref") else m
        if not r or not r.get("answerable"):
            declined.append(dict(metric=m["name"], reason=(r or m).get("reason") or m.get("reason", ""))); continue
        for x in run_one(m, question, primary):
            x["role"] = "asked" if primary else "context from the verified answer"
            results.append(x)
    return dict(question=question, route="verified_question", matched_question=v["question"], score=round(vq[0], 2),
                period=period_of(question) or f"as of {config.AS_OF}", results=results, declined_parts=declined,
                lineage=[dict(metric=r["metric"], **{k: r["lineage"][k] for k in ("model", "owner", "product", "product_measure")},
                              attributes=[a["attribute"] for a in r["lineage"]["attributes"]]) for r in results])


TOOLS = [
    dict(name="query", description=query.__doc__, input_schema=dict(type="object", required=["metric"], properties=dict(
        metric=dict(type="string"), by=dict(type="array", items=dict(type="string")), filters=dict(type="array", items=dict(type="string")),
        as_of=dict(type="string"), period=dict(type="string"), dimension_type=dict(type="string")))),
    dict(name="cannot_answer", description=cannot_answer.__doc__, input_schema=dict(
        type="object", required=["question"], properties=dict(question=dict(type="string")))),
]


def glossary():
    cm = _m()
    mets = [f"- {m['name']} ({m['model']}, {m.get('aggregation')}, table {(m.get('tables') or ['?'])[0]}): {m.get('description', '')[:160]}"
            for m in cm["metrics"] if m.get("answerable") and not m.get("ref")]
    no = [f"- {m['name']}: {m.get('reason', '')}" for m in cm["metrics"] if not m.get("answerable")]
    tabs = [f"- {k}: {', '.join(t.get('columns', {}))}" for k, t in cm["tables"].items() if t.get("view")]
    ex = [f"Q: {v['question']}\nA: {v['answer']}" for v in cm["questions"]]
    return (f"You answer business questions from a wealth manager's semantic model, as of {config.AS_OF}, only through the tools. "
            "Turn the question into one or more query calls (metric names exactly as listed; breakdowns as table.column; "
            "client_assets_flows breaks down by dimension_key with a dimension_type of Channel, Advisor, Segment, Business Line, "
            "Holding Type, Share Class or Total; quarters as YYYY-Qn). If the model cannot answer, call cannot_answer and say why "
            "with the gap id. Report figures with their metric names; do not compute figures the tools did not return.\n\n"
            "Answerable metrics:\n" + "\n".join(mets) + "\n\nNot answerable:\n" + "\n".join(no) +
            "\n\nTables and columns:\n" + "\n".join(tabs) + "\n\nVerified questions:\n" + "\n\n".join(ex))


def ask_claude(question):
    """Claude (Sonnet) plans the query calls; the tools run here; the answer returns with every result's lineage."""
    import anthropic
    client = anthropic.Anthropic()
    messages, results, declines, resp = [{"role": "user", "content": question}], [], [], None
    for _ in range(6):
        resp = client.beta.messages.create(
            model=ROUTER_MODEL, max_tokens=16000, betas=["server-side-fallback-2026-07-01"], fallbacks="default",
            system=[{"type": "text", "text": glossary(), "cache_control": {"type": "ephemeral"}}], tools=TOOLS,
            output_config={"effort": "medium"}, messages=messages)
        if resp.stop_reason == "refusal":
            break
        messages.append({"role": "assistant", "content": resp.content})
        uses = [b for b in resp.content if b.type == "tool_use"]
        if not uses:
            break
        out = []
        for b in uses:
            try:
                r = query(**b.input) if b.name == "query" else cannot_answer(**b.input)
                (results if b.name == "query" else declines).append(r)
                out.append({"type": "tool_result", "tool_use_id": b.id, "content": json.dumps(r, default=str)[:20000]})
            except Exception as e:  # a bad metric name or column goes back to Claude to correct
                out.append({"type": "tool_result", "tool_use_id": b.id, "content": f"Error: {e}", "is_error": True})
        messages.append({"role": "user", "content": out})
    text = "".join(b.text for b in (resp.content if resp else []) if b.type == "text")
    gaps = sorted({g for d in declines for g in d["gaps"]})
    return dict(question=question, route="claude", model=ROUTER_MODEL, answer=text, results=results,
                lineage=[r["lineage"] for r in results], gap=(gaps or "no gap id") if declines else None,
                declined=declines, stop_reason=resp.stop_reason if resp else None)


def serve():
    from mcp.server.mcpserver import MCPServer
    srv = MCPServer("cg-activation", instructions="The wealth manager's compiled semantic model (Client Assets & NNA, "
                    "Client & Household 360). Every answer carries lineage; declined questions carry their gap.")
    for f in (list_metrics, describe, query, coverage, cannot_answer, ask):
        srv.tool()(f)
    srv.run("stdio")


def selftest():
    show = lambda name, r, n=1500: print(f"\n=== {name}\n" + json.dumps(r, indent=1, default=str)[:n])
    lm = list_metrics()
    show("list_metrics()", dict(count=lm["count"], answerable=lm["answerable"], first=lm["metrics"][:3]))
    show("describe('Net New Assets')", describe("Net New Assets"))
    show("query('Net New Assets', by=[dimension_key], period=2026-Q3, dimension_type=Channel)",
         query("Net New Assets", by=["client_assets_flows.dimension_key"], period="2026-Q3", dimension_type="Channel"))
    show("coverage()", coverage())
    show("cannot_answer('Client Assets by household')", cannot_answer("Client Assets by household"))
    p = provider()
    print(f"\nask() assistant: {p.label() if p.available() else 'deterministic router (no model provider available)'}")
    import time
    for q in ("What were net new assets last quarter by channel?", "Which households have no primary advisor?", "Client Assets by household",
              *[a for a in sys.argv[1:] if not a.startswith("--")]):
        t0 = time.time(); r = ask(q); r["elapsed_s"] = round(time.time() - t0, 2)
        for x in r.get("results", []):
            x.pop("sql", None); x.pop("params", None); x["rows"] = x["rows"][:5]
            x["lineage"] = {k: x["lineage"][k] for k in ("model", "owner", "product", "product_measure")} | \
                           {"attributes": [a["attribute"] for a in x["lineage"]["attributes"]]}
        show(f"ask({q!r})", r, 4000)


if __name__ == "__main__":
    selftest() if "--selftest" in sys.argv else serve()
