"""The query engine of the activation demo: runs a metric request against the compiled semantic model in DuckDB.

A request names a metric, optional breakdowns ("table.column" of the metric's table or of a joined dimension), optional
filters and an as-of date. The engine applies the model's always-filters and the query-time parameters, joins
dimensions through the compiled relationships, applies the metric's time rule and returns the rows with the SQL it
ran and the lineage of the metric (model, product measure, taxonomy attribute, owner).

Usage (from _tools/):
  python activation/serve/query.py "Net New Assets" --by client_assets_flows.dimension_key --dimension-type Channel --period 2026-Q3
  python activation/serve/query.py "Households Without Primary Advisor"
  python activation/serve/query.py --list
"""
import argparse, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import _paths  # noqa: E402,F401
sys.path.insert(0, os.path.join(_paths.HERE, "compile"))
import config  # noqa: E402
import runtime  # noqa: E402
import semantic  # noqa: E402
from semantic import qualify  # noqa: E402


def q(name):
    return runtime.get().q(name)


def load(name=None):
    """The compiled model of the selected runtime (activation/out/compiled_model.json, or out/spark/ for Spark)."""
    rt = runtime.get(name)
    semantic.RT = rt
    return json.load(open(os.path.join(rt.out, "compiled_model.json")))


def find_metric(model, name):
    cands = [m for m in model["metrics"] if m["name"].lower() == name.lower() and not m.get("ref")]
    if not cands:
        cands = [m for m in model["metrics"] if name.lower() in m["name"].lower() and not m.get("ref")]
    return cands[0] if cands else None


def resolve_ref(model, m):
    """A metric defined by reference to another model's metric resolves to that definition when it is in the slice."""
    while m and m.get("ref"):
        mid, name = m["ref"].split("/", 1)
        m = next((x for x in model["metrics"] if x["model"] == mid and x["name"] == name and not x.get("ref")), None)
    return m


def _hop(model, from_key, target_table):
    """One compiled join from a table (key) to a table by name: (join dict with sql, target key) or (None, None)."""
    from_model = model["tables"][from_key]["model"]
    cands = [k for k, t in model["tables"].items() if t["name"] == target_table and t.get("view")]
    cands.sort(key=lambda k: (model["tables"][k]["model"] != from_model, k))
    if not cands:
        return None, None
    tkey = cands[0]; target = model["tables"][tkey]
    for j in model["joins"]:
        if not j["executable"]:
            continue
        for side, other in (("frm_table", "to_table"), ("to_table", "frm_table")):
            if j[side] == from_key and model["tables"][j[other]].get("entity") == target.get("entity"):
                o = model["tables"][j[other]]
                if j[other] == tkey:
                    return j, tkey
                m = re.search(re.escape(q(o["name"])) + r"\.([`\"])(\w+)\1", j["sql"])
                if not m:
                    continue
                phys = o["columns"].get(m.group(2))
                sem = next((s for s, p in target["columns"].items() if p == phys), None)
                if sem is None:
                    continue
                return dict(j, sql=j["sql"].replace(f'{q(o["name"])}.{q(m.group(2))}', f"{q(target_table)}.{q(sem)}")), tkey
    return None, None


def fiscal_codes(period, as_of):
    """The fiscal month codes a period spans (YYYY-Qn or YYYY-MM-DD..YYYY-MM-DD), or the as-of month alone."""
    if period and re.match(r"^\d{4}-Q[1-4]$", period):
        y, qn = period.split("-Q"); return [f"FY{y}-M{m:02d}" for m in range(int(qn) * 3 - 2, int(qn) * 3 + 1)]
    if period and ".." in period:
        a, b = period.split(".."); ya, ma, yb, mb = int(a[:4]), int(a[5:7]), int(b[:4]), int(b[5:7])
        return [f"FY{y}-M{m:02d}" for y in range(ya, yb + 1) for m in range(1, 13) if (y, m) >= (ya, ma) and (y, m) <= (yb, mb)]
    d = str(as_of or config.AS_OF); return [f"FY{d[:4]}-M{d[5:7]}"]


def join_path(model, base_key, target_table):
    """The joins from the base table to a table by name: the shortest chain of up to three hops through tables of the
    base's model or the shared dimensions (a relationship's client's party, for its name). Returns [(join, table key)]
    hops, or None."""
    base_model = model["tables"][base_key]["model"]
    frontier, seen = [(base_key, [])], {base_key}
    for _ in range(3):
        nxt = []
        for key, path in frontier:
            j, tkey = _hop(model, key, target_table)
            if j:
                return path + [(j, tkey)]
            for mid_key, mt in model["tables"].items():
                if mid_key in seen or not mt.get("view") or mt["model"] not in (base_model, "SM-00"):
                    continue
                j1, k1 = _hop(model, key, mt["name"])
                if j1:
                    seen.add(k1); nxt.append((k1, path + [(j1, k1)]))
        frontier = nxt
    return None


DIMENSION_TYPE_OF = {"distribution_channel": "Channel", "code_value": "Channel", "share_class": "Share Class", "firm_advisor": "Advisor"}


def normalize_period(period, as_of):
    """A period as the engine understands it: YYYY-Qn, YYYY-MM-DD..YYYY-MM-DD, or none; a plain date becomes the as-of date."""
    period = (period or "").strip()
    if not period:
        return None, as_of
    if re.match(r"^\d{4}-Q[1-4]$", period) or re.match(r"^\d{4}-\d{2}-\d{2}\.\.\d{4}-\d{2}-\d{2}$", period):
        return period, as_of
    if re.match(r"^\d{4}-\d{2}-\d{2}$", period):
        return None, period
    m = re.match(r"^(\d{4})-(\d{2})$", period)
    if m:  # a month: the month's range
        y, mo = int(m.group(1)), int(m.group(2)); last = 29 if mo == 2 and y % 4 == 0 else 28 if mo == 2 else 30 if mo in (4, 6, 9, 11) else 31
        return f"{y}-{mo:02d}-01..{y}-{mo:02d}-{last}", as_of
    raise ValueError(f"period {period!r} is not YYYY-Qn, YYYY-MM-DD..YYYY-MM-DD or a date")


def reachable(model, base_key):
    """The tables a base table can reach by the compiled joins (one or two hops), by name, with their columns."""
    out = {}
    for k, t in model["tables"].items():
        if k == base_key or not t.get("view"):
            continue
        if join_path(model, base_key, t["name"]) and not (model["tables"][base_key].get("kind") == "Fact" and t.get("kind") == "Fact"):
            out[t["name"]] = list(t["columns"])
    return out


def run(model, metric_name, by=(), filters=(), as_of=None, period=None, dimension_type=None, period_type=None, con=None):
    period, as_of = normalize_period(period, as_of)
    m0 = find_metric(model, metric_name)
    if m0 is None:
        raise ValueError(f"no metric named {metric_name!r}; use --list")
    m = resolve_ref(model, m0)
    if m is None or not m.get("sql") or not m.get("answerable"):
        reason = (m0 if m is None else m)["reason"]
        return dict(metric=m0["name"], model=m0["model"], answerable=False, reason=reason, sql=None, rows=[], lineage=lineage(model, m0))
    base_key = m["tables"][0]
    base = model["tables"][base_key]
    alias = base["name"]
    cols_by_table = {alias: base["columns"]}
    joins_sql, group_cols, select_cols, joined = [], [], [], set()

    def ensure_joined(t, allow_fact=False):
        nonlocal dimension_type
        if t == alias or t in joined:
            return
        path = join_path(model, base_key, t)
        if path and not allow_fact and base.get("kind") == "Fact" and model["tables"][path[-1][1]].get("kind") == "Fact":
            raise ValueError(f"{t} is a fact table with several rows per {alias} row; a breakdown by it would multiply the measure. Ask a metric of {t} instead, or cut by a dimension")
        if not path:
            if not any(x["name"] == t for x in model["tables"].values()):
                raise ValueError(f"no table named {t}; write columns as table.column; {alias} itself has {', '.join(base['columns'])}; tables it reaches: {', '.join(sorted(reachable(model, base_key)))}")
            raise ValueError(f"no executable join from {alias} to {t}; tables {alias} reaches: {', '.join(sorted(reachable(model, base_key)))}")
        for j, tkey in path:
            jt = model["tables"][tkey]
            if jt["name"] in joined or jt["name"] == alias:
                continue
            cols_by_table[jt["name"]] = jt["columns"]
            joins_sql.append(f"left join {jt['view']} as {q(jt['name'])} on {j['sql']}")
            joined.add(jt["name"])
        if dimension_type is None and t in DIMENSION_TYPE_OF and "dimension_type" in base["columns"]:
            dimension_type = DIMENSION_TYPE_OF[t]

    for tk in m.get("tables", [])[1:]:  # a metric written over two tables (a revenue record and the calculation it cites) joins the second
        ensure_joined(model["tables"][tk]["name"], allow_fact=True)
    dimension_grain = None
    for b in by:
        t, c = b.split(".", 1) if "." in b else (alias, b)
        ensure_joined(t)
        if c not in cols_by_table[t]:
            raise ValueError(f"{t} has no column {c}; its columns: {', '.join(cols_by_table[t])}")
        group_cols.append(f"{q(t)}.{q(c)}"); select_cols.append(f"{q(t)}.{q(c)} as {q(c)}")
        if t == alias and c == "dimension_key" and dimension_type is None:
            dimension_type = "Channel"
        if t == alias and c in base.get("dimension_grain_of", {}):
            dimension_grain = base["dimension_grain_of"][c]
    for f in filters:
        for c, g in base.get("dimension_grain_of", {}).items():
            if re.search(rf"\b{alias}\.{c}\b", f) and dimension_grain is None:
                dimension_grain = g
    for f in filters:                                     # a filter on another table joins it too
        for t, c in re.findall(r"\b([a-z_][a-z0-9_]*)\.([a-z_][a-z0-9_]*)", f):
            if t != alias and t not in joined and any(tb["name"] == t for tb in model["tables"].values()):
                ensure_joined(t)
    params = dict(model["params"])
    params["as_of_date"] = as_of or config.AS_OF
    if dimension_type:
        params["dimension_type"] = dimension_type
    if dimension_grain:
        params["dimension_grain"] = dimension_grain
    if period_type:
        params["period_type"] = period_type
    conds = []
    for f in base.get("query_filters", []):
        s = f
        for p, v in params.items():
            s = s.replace(f":{p}", f"date '{v}'" if re.match(r"^\d{4}-\d{2}-\d{2}$", str(v)) else f"'{v}'")
        conds.append(f"({s})")
    # the period: a single as-of date by default; a quarter or a date range selects several period rows of a Month grain
    aoc = base.get("default_as_of_column")
    aoc_alias, aoc_view = alias, base["view"]
    if aoc and "." in aoc:  # the as-of column lives on a table the base reaches by a join (a calculation's run)
        aoc_alias, aoc = aoc.split(".", 1)
        ensure_joined(aoc_alias)
        aoc_view = next(t["view"] for t in model["tables"].values() if t["name"] == aoc_alias and t.get("view"))
    fiscal = bool(aoc) and (base.get("fiscal_code_as_of") or aoc in semantic.X.FISCAL_CODE_COLUMNS)
    snapshot = m.get("aggregation") in ("semi_additive",) and "period_type" not in base["columns"] and not fiscal
    if fiscal:  # a fiscal month code (on the base or the joined table): the months the period spans, or the as-of month
        conds.append(f"{q(aoc_alias)}.{q(aoc)} in ({', '.join(repr(c) for c in fiscal_codes(period, params['as_of_date']))})")
    elif aoc and snapshot and period:  # a point-in-time measure over a range: the last snapshot on or before the range's end
        end = period.split("..")[1] if ".." in period else (lambda y, qn: f"{y}-{int(qn) * 3:02d}-{30 if int(qn) * 3 in (6, 9) else 31}")(*period.split("-Q"))
        conds.append(f"cast({q(aoc_alias)}.{q(aoc)} as date) = (select max(cast({q(aoc)} as date)) from {aoc_view} where cast({q(aoc)} as date) <= date '{end}')")
    elif aoc:
        alias = aoc_alias  # the date conditions below apply to the table that carries the as-of column
        if period and re.match(r"^\d{4}-Q[1-4]$", period):
            y, qn = period.split("-Q"); mo = int(qn) * 3
            if "period_type" in base["columns"] and period_type is None:
                params["period_type"] = "Quarter"
                conds = [c.replace("'Month'", "'Quarter'") for c in conds]
                conds.append(f"{q(alias)}.{q(aoc)} = (select max({q(aoc)}) from {base['view']} where {q(aoc)} <= date '{y}-{mo:02d}-{28 if mo == 2 else 30 if mo in (4, 6, 9, 11) else 31}')")
            else:
                conds.append(f"cast({q(alias)}.{q(aoc)} as date) between date '{y}-{mo - 2:02d}-01' and date '{y}-{mo:02d}-{30 if mo in (4, 6, 9, 11) else 31}'")
        elif period and ".." in period:
            a, b = period.split("..")
            conds.append(f"cast({q(alias)}.{q(aoc)} as date) between date '{a}' and date '{b}'")
        else:
            conds.append(f"{q(alias)}.{q(aoc)} = date '{params['as_of_date']}'")
    alias = base["name"]
    for f in filters:
        conds.append(f"({qualify(f, cols_by_table)})")
    msql = qualify(m['sql'], cols_by_table).replace(":as_of_date", f"date '{params['as_of_date']}'")
    sql = f"select {', '.join(select_cols + [msql + ' as ' + q(m['name'])])} from {base['view']} as {q(alias)} " + \
          " ".join(joins_sql) + ((" where " + " and ".join(conds)) if conds else "") + \
          ((" group by " + ", ".join(group_cols) + " order by " + ", ".join(group_cols)) if group_cols else "")
    rt = runtime.get()
    names = rt.select_columns(sql)
    rows = [dict(zip(names, r)) for r in rt.fetch(sql)]
    return dict(metric=m["name"], model=m["model"], answerable=True, sql=sql, rows=rows, params=params, lineage=lineage(model, m))


def snake(x):
    return re.sub(r"[^a-z0-9]+", "_", x.lower()).strip("_")


def lineage(model, m):
    """Metric -> product measure -> taxonomy attribute and definition -> owner."""
    src = m.get("source") or []
    out = dict(model=m["model"], model_name=model["models"].get(m["model"], {}).get("name", ""), owner=model["models"].get(m["model"], {}).get("owner", ""),
               metric=m["name"], aggregation=m.get("aggregation"), time_rule=m.get("time_rule", ""), description=m.get("description", ""),
               product=src[0] if src else None, product_measure=src[1] if len(src) > 1 else None, columns=m.get("columns", []), sql=m.get("sql"),
               steward_note=m.get("steward_note", ""))
    slice_ = json.load(open(os.path.join(_paths.OUT, "slice.json")))
    attrs = []
    for col in m.get("columns", []):
        t, c = col.split(".")
        for key, tb in model["tables"].items():
            if tb["name"] == t and tb.get("columns", {}).get(c):
                st = slice_["tables"].get(key)
                sc = next((x for x in st["columns"] if x["name"] == c), None) if st else None
                if sc:
                    attrs.append(dict(column=col, attribute=sc["attr"], taxonomy=sc["taxonomy"], attr_id=sc["attr_id"], definition=sc["definition"][:300], cde=sc["cde"], pii=sc["pii"]))
                elif st:  # a measure the table carries as a derived attribute of its entity rather than a declared column
                    phys = tb["columns"][c]
                    ea = next((a for a in slice_["entities"][st["entity_key"]]["attrs"] if snake(a["name"]) == phys), None)
                    if ea:
                        attrs.append(dict(column=col, attribute=ea["name"], taxonomy=ea["taxonomy"], attr_id=ea["attr_id"], definition=ea["definition"][:300], cde=ea["cde"], pii=ea["pii"]))
                break
    out["attributes"] = attrs
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("metric", nargs="?")
    ap.add_argument("--by", action="append", default=[])
    ap.add_argument("--filter", action="append", default=[])
    ap.add_argument("--as-of")
    ap.add_argument("--period", help="YYYY-Qn or YYYY-MM-DD..YYYY-MM-DD")
    ap.add_argument("--dimension-type")
    ap.add_argument("--period-type")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--runtime")
    a = ap.parse_args()
    model = load()
    if a.list or not a.metric:
        for m in model["metrics"]:
            if m.get("ref"):
                continue
            print(f"{'yes' if m['answerable'] else 'no ':3s} {m['model']} {m['name']:46s} {m['reason'][:70]}")
        return
    r = run(model, a.metric, by=a.by, filters=a.filter, as_of=a.as_of, period=a.period, dimension_type=a.dimension_type, period_type=a.period_type)
    if a.json:
        print(json.dumps(r, indent=1, default=str)); return
    if not r["answerable"]:
        print(f"{r['metric']} ({r['model']}): not answerable: {r['reason']}"); return
    print(r["sql"]); print()
    for row in r["rows"]:
        print("  " + "  ".join(f"{k}={v:,.2f}" if isinstance(v, float) else f"{k}={v}" for k, v in row.items()))
    lg = r["lineage"]
    print(f"\nlineage: {lg['model']} {lg['model_name']} (owner {lg['owner']}) -> {lg['product']} '{lg['product_measure']}' -> " +
          "; ".join(f"{x['taxonomy'][0]} {x['taxonomy'][1]}.{x['attribute']}" for x in lg["attributes"] if x["taxonomy"]))


if __name__ == "__main__":
    main()
