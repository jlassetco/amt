"""Resolves the activation slice: the semantic models in config.SLICE (narrowed by config.TABLES) to the tables they
read, the logical entities behind those tables, every column with its taxonomy attribute, the shared dimensions they
join, the metrics, the access rules and the business questions. Everything else in activation/ reads this.

Usage (from _tools/):  python activation/slice.py          prints the footprint and writes activation/out/slice.json
"""
import json, os, re, sys, importlib

import _paths  # noqa: F401
import sm_model, dm_model, dp_model, framework as fw, register as rg  # noqa: E402
import config  # noqa: E402

TIER = {p[0]: p[2] for p in fw.PRODUCTS}
PNAME = {p[0]: p[1] for p in fw.PRODUCTS}
OWNER = {m[0]: m[2] for m in rg.MODELS}


def load():
    """(models, logical, specs, objs): the validated semantic models, logical models, product specs and taxonomy."""
    models, logical, specs, gaps, errs, warns = sm_model.load()
    if errs:
        raise SystemExit("The semantic layer does not validate; fix it before activating:\n  " + "\n  ".join(errs[:10]))
    objs, _, _, _, _ = dm_model.load_all()
    return models, logical, specs, objs


def code_lists():
    """{(domain, list name): [(value, description, code), ...]} for every local and shared code list. The value is what
    the workbook's Code List tab shows (the label); for an enterprise shared list the code is the bracketed token of
    the description ("[DIRECT_SELF_DIRECTED] ..."), for a local list the code is the value itself."""
    from taxonomy_builder import CONTENT, Consolidated, load_consolidation
    scl = load_consolidation()
    out = {}
    for f in sorted(os.listdir(CONTENT)):
        if f.startswith("content_") and f.endswith(".py"):
            m = Consolidated(importlib.import_module(f[:-3]), scl)
            n = m.__name__.split("_")[1]
            for name, (steward, values) in m.CL.items():
                rows = []
                for v in values:
                    desc = v[1] if len(v) > 1 else ""
                    mt = re.match(r"^\[([^\]]+)\]\s*(.*)$", desc) if name.startswith("Shared: ") else None
                    rows.append((v[0], mt.group(2) if mt else desc, mt.group(1) if mt else v[0]))
                out[(n, name)] = rows
    return out


def snake(s):
    return re.sub(r"[^a-z0-9]+", "_", s.lower()).strip("_")


def _column(col, role, ent, objs):
    a = next((x for x in ent["attrs"] if x["name"] == col["attr"]), None)
    if a is None:
        raise SystemExit(f"{ent['name']}: column {col['name']} reads attribute '{col['attr']}' that the entity does not hold")
    obj = tuple(a["obj"]) if a.get("obj") else None
    code_list = objs[obj]["attrs"][a["name"]]["code_list"] if obj and a["name"] in objs[obj]["attrs"] else ""
    return dict(name=col["name"], attr=col["attr"], role=role, note=col.get("note", ""), type=a["type"],
                taxonomy=list(obj) if obj else None, attr_id=a.get("id", ""), code_list=code_list,
                cde=bool(a.get("cde")), pii=bool(a.get("pii")), derived=bool(a.get("derived")), definition=a.get("def", ""))


def _table(mid, t, logical, objs):
    ent = sm_model.entity(logical, t["product"], t["entity"])
    if ent is None:
        raise SystemExit(f"{mid}.{t['name']}: {t['product']} has no entity '{t['entity']}'")
    cols = [_column(c, "dimension", ent, objs) for c in t.get("dimensions", [])]
    cols += [_column(c, "fact", ent, objs) for c in t.get("facts", [])]
    return dict(model=mid, name=t["name"], product=t["product"], entity=t["entity"], kind=t["kind"],
                synthesized=bool(t.get("synthesized")), grain=t.get("grain", ""), always_filter=list(t.get("always_filter", [])),
                default_filter=t.get("default_filter", ""), columns=cols,
                hidden=[list(h) for h in t.get("hidden", [])])


def _entity(pid, ent, objs):
    attrs = []
    for a in ent["attrs"]:
        obj = tuple(a["obj"]) if a.get("obj") else None
        tx = objs[obj]["attrs"].get(a["name"]) if obj else None
        attrs.append(dict(name=a["name"], type=a["type"], taxonomy=list(obj) if obj else None, attr_id=a.get("id", ""),
                          code_list=tx["code_list"] if tx else "", cde=bool(a.get("cde")), pii=bool(a.get("pii")),
                          pk=bool(a.get("pk")), fk=a.get("fk", ""), derived=bool(a.get("derived")), definition=a.get("def", "")))
    return dict(product=pid, product_name=PNAME.get(pid, ""), tier=TIER.get(pid, ""), entity=ent["name"], role=ent["role"],
                grain=ent.get("grain", ""), note=ent.get("note", ""), conformed=ent.get("conformed"),
                objects=[list(o) for o in ent.get("objects", [])], pk=[a["name"] for a in ent["attrs"] if a.get("pk")],
                attrs=attrs, used=[])


def resolve(slice_ids=None, tables=None, loaded=None):
    """The resolved slice as one JSON-serializable dict."""
    slice_ids = slice_ids or config.SLICE
    tables = config.TABLES if tables is None else tables
    models, logical, specs, objs = loaded or load()
    sm00 = models["SM-00"]
    out = dict(slice=list(slice_ids), as_of=config.AS_OF, models={}, tables={}, shared={}, entities={}, products={},
               metrics=[], relationships=[], questions=[], cannot_answer=[])
    ents = {}

    def take_entity(t):
        key = f"{t['product']}/{t['entity']}"
        if key not in ents:
            ents[key] = _entity(t["product"], sm_model.entity(logical, t["product"], t["entity"]), objs)
        used = set(ents[key]["used"])
        used.update(c["attr"] for c in t["columns"])
        ents[key]["used"] = sorted(used)
        return key

    for mid in slice_ids:
        if mid not in models:
            raise SystemExit(f"{mid} is not a live semantic model")
        m = models[mid]
        keep = tables.get(mid)
        own = [t for t in m["tables"] if keep is None or t["name"] in keep]
        missing = set(keep or []) - {t["name"] for t in own}
        if missing:
            raise SystemExit(f"{mid}: config.TABLES names tables the model does not have: {sorted(missing)}")
        names = {t["name"] for t in own}
        reg = next(r for r in rg.MODELS if r[0] == mid)
        out["models"][mid] = dict(id=mid, name=reg[1], owner=reg[2], functions=list(reg[3]), status=m.get("status", ""),
                                  description=m.get("description", ""), questions=list(m.get("questions", [])),
                                  tables=sorted(names), tables_left_out=sorted({t["name"] for t in m["tables"]} - names),
                                  shared=list(m.get("shared", [])), hierarchies=list(m.get("hierarchies", [])),
                                  access=m.get("access", {}), open_decisions=list(m.get("open_decisions", [])))
        for t in own:
            tb = _table(mid, t, logical, objs)
            tb["entity_key"] = take_entity(tb)
            out["tables"][f"{mid}.{t['name']}"] = tb
        for s in m.get("shared", []):
            pid, ename = s.split("/", 1)
            sts = [t for t in sm00["tables"] if t["product"] == pid and t["entity"] == ename]
            if not sts:            # an SM-00 entity with no published table: expose the whole entity as one dimension
                ent = sm_model.entity(logical, pid, ename)
                if ent is None:
                    raise SystemExit(f"{mid}: shared dimension {s} is not an entity of {pid}")
                sts = [dict(name=snake(ename), product=pid, entity=ename, kind="Dimension", synthesized=True,
                            dimensions=[dict(name=snake(a["name"]), attr=a["name"]) for a in ent["attrs"] if not a.get("derived")])]
            out["shared"].setdefault(s, [])
            for t in sts:
                key = f"SM-00.{t['name']}"
                if key not in out["tables"]:
                    tb = _table("SM-00", t, logical, objs)
                    tb["entity_key"] = take_entity(tb)
                    out["tables"][key] = tb
                if t["name"] not in out["shared"][s]:
                    out["shared"][s].append(t["name"])
        for r in m.get("relationships", []):
            if (r["frm"] in names or r["frm"] in m.get("shared", [])) and (r["to"] in names or r["to"] in m.get("shared", [])):
                out["relationships"].append(dict(model=mid, **r))
        mine, texts = [], {}
        for x in m.get("metrics", []):
            d = dict(model=mid, **x)
            if "source" in d:
                d["source"] = list(d["source"])
            # a metric is in scope when every table its expression names is in the slice (refs are always in scope)
            texts[d["name"]] = " ".join(str(d.get(k, "")) for k in ("expr", "numerator", "denominator"))
            d["tables_read"] = sorted({n for n in {t["name"] for t in m["tables"]} if f"{n}." in texts[d["name"]]})
            mine.append(d)
        # a metric written over other metrics ("[Relationship Client Assets] of relationships counted in [At-Risk
        # Relationships]") reads the tables those metrics read
        by_name = {d["name"]: d for d in mine}
        for _ in range(3):
            for d in mine:
                for ref in re.findall(r"\[([^\]]+)\]", texts[d["name"]]):
                    if ref in by_name and ref != d["name"]:
                        d["tables_read"] = sorted(set(d["tables_read"]) | set(by_name[ref]["tables_read"]))
        for d in mine:
            reads = set(d["tables_read"])
            d["in_scope"] = bool(reads) and reads <= names or "ref" in d
            out["metrics"].append(d)
        for q in m.get("verified_questions", []):
            out["questions"].append(dict(model=mid, **q))
        for q in m.get("cannot_answer", []):
            out["cannot_answer"].append(dict(model=mid, **q))
    for pid, ename in getattr(config, "EXTRA_ENTITIES", []):
        key = f"{pid}/{ename}"
        if key not in ents:
            ent = sm_model.entity(logical, pid, ename)
            if ent is None:
                raise SystemExit(f"config.EXTRA_ENTITIES: {pid} has no entity '{ename}'")
            ents[key] = _entity(pid, ent, objs)
            ents[key]["extra"] = True
    for key, e in ents.items():
        out["entities"][key] = e
        pid = e["product"]
        if pid not in out["products"]:
            s = specs.get(pid, {})
            out["products"][pid] = dict(id=pid, name=PNAME.get(pid, ""), tier=TIER.get(pid, ""),
                                        home_model=sm_model.HOME.get(pid, ""), definition=s.get("definition", ""),
                                        grain=s.get("grain", ""), upstream=list(s.get("upstream", [])),
                                        inputs=[[d, o, list(a)] for d, o, a in s.get("inputs", [])],
                                        measures=[[n, d] for n, d, _ in s.get("measures", [])],
                                        entities=[])
        out["products"][pid]["entities"].append(e["entity"])
    return out


def summary(s):
    lines = [f"Slice {', '.join(s['slice'])} as of {s['as_of']}"]
    for mid, m in s["models"].items():
        lines.append(f"  {mid} {m['name']}: {len(m['tables'])} tables kept, {len(m['tables_left_out'])} left out, {len(m['shared'])} shared dimensions")
    own = [t for t in s["tables"].values() if t["model"] != "SM-00"]
    sh = [t for t in s["tables"].values() if t["model"] == "SM-00"]
    cols = sum(len(t["columns"]) for t in s["tables"].values())
    lines.append(f"  tables: {len(own)} own + {len(sh)} shared (SM-00); columns {cols}")
    fnd = [p for p in s["products"].values() if p["tier"] == "Foundational"]
    con = [p for p in s["products"].values() if p["tier"] != "Foundational"]
    lines.append(f"  entities: {len(s['entities'])} from {len(fnd)} foundational products ({', '.join(sorted(p['id'] for p in fnd))}) and {len(con)} consumer products ({', '.join(sorted(p['id'] for p in con))})")
    nattr = sum(len(e["attrs"]) for e in s["entities"].values()); nused = sum(len(e["used"]) for e in s["entities"].values())
    lines.append(f"  entity attributes: {nattr} in the logical models, {nused} read by the slice tables")
    ins = [m for m in s["metrics"] if m["in_scope"] and "ref" not in m]; refs = [m for m in s["metrics"] if "ref" in m]
    outs = [m for m in s["metrics"] if not m["in_scope"] and "ref" not in m]
    lines.append(f"  metrics: {len(ins)} in scope, {len(refs)} references, {len(outs)} read tables left out")
    lines.append(f"  relationships {len(s['relationships'])}; verified questions {len(s['questions'])}; cannot-answer {len(s['cannot_answer'])}")
    return "\n".join(lines)


if __name__ == "__main__":
    s = resolve()
    print(summary(s))
    path = os.path.join(_paths.OUT, "slice.json")
    with open(path, "w") as f:
        json.dump(s, f, indent=1, ensure_ascii=False)
    print("wrote", os.path.relpath(path, _paths.TOOLS))
