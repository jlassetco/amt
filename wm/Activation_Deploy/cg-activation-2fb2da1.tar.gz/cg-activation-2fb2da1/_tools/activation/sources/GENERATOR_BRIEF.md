# Brief: the synthetic sources of the activation demo (`sources/generate.py`)

**Purpose.** Produce the extracts and data dictionaries of three source systems of a hypothetical US direct wealth
manager, shaped exactly as `sources/schema.py` defines them, together with `truths.json`: the certified figures and
planted facts computed independently in Python, which the compiled SQL pipeline must reproduce. The demo's
credibility rests on that independent computation, so the rules below are the specification; follow them exactly and
record any judgment call in a `NOTES` list written into `truths.json`.

**Environment.** `/usr/bin/python3` (3.9), standard library only (`csv`, `random`, `datetime`, `json`, `hashlib`).
Deterministic from `config.SEED`. Run from `_tools/`: `python activation/sources/generate.py` writes
`activation/out/sources/<SRC-ID>/<TABLE>.csv` (header row = the column names of `schema.py`, in order),
`activation/out/sources/<SRC-ID>/_dictionary.csv` (`table,column,type,description,example,table_grain` from
`schema.dictionary_rows`), and `activation/out/sources/truths.json`. Import `config` and `schema` through
`_paths` (see `slice.py` for the pattern). Keep the run under ten seconds.

**Dates.** Month-end snapshot dates: 2026-06-30, 2026-07-31, 2026-08-31, 2026-09-30 (`config.AS_OF` is the last).
Activity window: 2026-07-01 to 2026-09-30, business days only. BRK and TA dates are `YYYYMMDD`; CRM dates are ISO
(`YYYY-MM-DD`, timestamps `YYYY-MM-DDTHH:MM:SSZ`). Amounts have two decimals, quantities three.

## The firm and its sources

- The firm: a broker-dealer (carrying entity code `BD`, dealer number `0010`, NSCC `0010`, `DEALER_TYPE_CD` AFF), a
  trust company (`TC`), and its own fund family (`FUND_FAMILY_CD` OWN). Reference names are invented; do not use real
  fund names or tickers (prefix tickers with `FX`, e.g. `FXTSAX`; CUSIPs are 9 characters, digits plus a letter is fine).
- Own funds: 18 products (`PRODUCT_CD` P0001..) with 2 or 3 classes each (INV, ADM, and ETF for 6 of them), about 45
  fund numbers in `FUND_MASTER`, including 2 money market funds (`ASSET_CLS_CD` MM). Every own fund number has one
  `SEC_MASTER` row with `FUND_FAMILY_CD` OWN and `TA_FUND_NO` set; ETF classes are `SEC_TYPE_CD` ETF, money market
  classes MMF, the rest MF. Third-party securities: about 250 (EQ 150, ETF 40, MF 30, FI 20, CD 5, OPT 8); options
  have `SEC_TYPE_CD` OPT and `ASSET_CLS_CD` DER.
- Households: 300 in CRM `Account`. People: about 1,000 `Contact` rows: 2 to 3 members per household (Head, Spouse,
  Dependent), plus 60 trusted-contact persons and 40 prospects with no household (`AccountId` blank, stage Prospect).
  12 contacts are deceased (`Deceased_Date__c` set, still members). 8 contacts are `Merged` into another.
- Advisors: 45 `User` rows with `UserRole.Name` Advisor (status Active 40, Onboarding 2, Transitioning 2, Inactive 1)
  plus 15 non-advisor users. Each has a `Rep_Code__c` and `Employee_Number__c`. 265 households have an `OwnerId`
  (an active or transitioning advisor); 35 have none (planted: `HOUSEHOLDS_WITHOUT_PRIMARY_ADVISOR` = 35).
- Brokerage accounts (`ACCT_MASTER`): about 560. Classes: B 420, A 125 (enrolled in DAP or PAS or WMP, `ENROLL_STATUS_CD`
  A, with `CHANNEL_CD` DA for DAP and HA otherwise), T 15 (`CHANNEL_CD` TR, `CARRY_ENT_CD` TC). Status: O 520, C 30
  (closed in the window or before, zero positions after close), D 8, P 2. Every account's `PRIM_CUST_NO` is a
  `CUST_MASTER` customer; joint accounts (REG_CD JTWROS or TIC, about 120) also have `SEC_CUST_NO`. `REP_CD` is the
  `Rep_Code__c` of the household's owner advisor when there is one, else a rep code of a random advisor.
- Customers (`CUST_MASTER`): about 640. 90 percent carry `CRM_CONTACT_ID`; 10 percent (legacy) have it blank, and of
  those, 80 percent are reachable through `Contact.Brokerage_Customer_No__c`, 20 percent only by name and date of birth
  (planted: `SUGGESTED_MATCHES`, the count of customers resolvable only by name and date of birth).
- Transfer agent accounts (`SHR_ACCT`): 300 direct (`ACCT_TYPE_CD` I, dealer 0010, SOC 1/2/5/7), 1 affiliated omnibus
  (`ACCT_TYPE_CD` O, SOC 9, dealer 0010), 3 third-party omnibus (dealers 0421 WH, 0877 RIA, 1203 BK), 1 plan omnibus
  (`ACCT_TYPE_CD` P, dealer 2290 RK), 20 networked (`ACCT_TYPE_CD` N, NSCC_LEVEL 3, dealer 0421 or 0877). `DEALER`
  has those 6 rows plus one unused.
- CRM financial accounts: one `FinServ__FinancialAccount__c` per brokerage account (`Source_System__c` BRK) except 15
  brokerage accounts that have none (planted: `UNLINKED_BROKERAGE_ACCOUNTS` = 15, with their total value at AS_OF
  as `UNLINKED_BROKERAGE_VALUE`); one per TA direct account (`Source_System__c` TA) except 6. Omnibus, plan and
  networked TA accounts have no CRM financial account. Roles: a `FinServ__FinancialAccountRole__c` Primary Owner for
  every linked account, Joint Owner where there is a second customer, 40 Power of Attorney and 25 Trustee rows.
  Also 30 held-away accounts (`Held_Away__c` true, `Held_Away_Value__c` set, no source number) spread over households.
- Consents: about 1,500 `Consent__c`; trusted contacts: 400 `Trusted_Contact__c`. Offerings: 7 `Offering__c` rows
  (DAP DigitalAdvice, PAS PersonalAdvisor, WMP WealthManagement, TRS TrustServices, PLN PlanningOnly, BRK Brokerage,
  HYB HybridAdvice); service tiers: T1 (0), T2 (500,000), T3 (2,000,000), T4 (10,000,000), basis HouseholdAssets.
  Household `Service_Tier__c` follows the household's client assets at 2026-06-30 by those thresholds, except 18
  households set one tier too low (planted: `SERVICE_TIER_MISMATCH` = 18 at AS_OF, computed against AS_OF assets;
  write the count your data actually yields).

## Positions, balances and activity

- Brokerage positions: 2 to 8 securities per open account per month-end; 45 percent of position value in own funds
  (MF, ETF, MMF with OWN), the rest third-party. Prices move month to month (random walk, plus or minus 6 percent).
  Options: 25 positions across 12 accounts (planted: `OPTIONS_UNATTRIBUTED` = their total `MKT_VAL` at AS_OF).
- Cash balances per open brokerage account per month-end: FCB and SWP (basis S; basis T rows for 20 percent of
  accounts with the same amount), MDB negative for 30 margin accounts.
- The affiliated omnibus TA account's `POSITION` rows: for every own fund number and month-end, `SHARES` equals the sum
  of brokerage `QTY_SD` in that fund across all brokerage accounts, `MKT_VAL` the matching value (planted:
  `AFFILIATED_OMNIBUS_VALUE` = its total at AS_OF, which must equal `BROKERAGE_OWN_FUND_VALUE`). Third-party omnibus,
  plan and networked accounts hold their own positions (not derived from anything).
- Brokerage activity (about 7,000 rows): BUY/SEL/FBUY/FRED trades with matching cash effect; DEP and WDL; DIV, INT, CGD
  monthly on holdings; FEE quarterly on advisory accounts; 40 ACATI (`XFER_TYPE_CD` ACATS, with `CONTRA_FIRM_CD`),
  12 ACATO, 10 XFRI, 6 ROLLI (ROLLOVER), and journals: 30 JNL rows between two accounts of the same primary customer
  (`XFER_TYPE_CD` INTRAFIRM; a brokerage-to-IRA or brokerage-to-brokerage pair, each with a matching contra row),
  of which 12 move money from a self-directed account (CHANNEL SD) to a managed advisory account (CHANNEL DA or HA)
  of the same customer (planted inter-channel transfers), and 8 JNL rows between accounts of different customers
  (gifts; count as transfers). 60 activity rows are `STATUS_CD` N (pending) and 25 are R with a `REVERSAL_OF_TXN_ID`
  pointing at a posted row of the same amount (both the reversed row and its reversal are excluded from the flows).
  Every FBUY/FRED on an own fund in the window has a matching TA `TRANSACTION` on the affiliated omnibus account
  (TRAN_CD 001/002, SOURCE_CD OM, same trade date and amount).
- TA transactions on direct accounts (about 2,500): 001 purchases and 002 redemptions, 051/052 exchange pairs, 101/102
  reinvestments monthly, 10 071 transfers in and 6 072 out, 20 reversed (R with `REVERSAL_OF`). Third-party omnibus and
  networked accounts: purchases and redemptions with SOURCE_CD FS.
- Positions must be consistent with activity only loosely (the demo does not reconcile quantities); keep the
  month-end values plausible and the planted equalities exact.

## The certified figures (ground truth, computed in Python and written to `truths.json`)

Compute for each **period**: the months 2026-07, 2026-08, 2026-09 and the quarter 2026-Q3; and for each
**dimension type** below, one row per **dimension key** plus the key `ALL` for Total. Beginning = the month-end before
the period start; Ending = the period end. Dates of positions and balances are the month-ends.

Row attribution of an asset or flow to a dimension key:
- `Total`: key `ALL`.
- `Channel` (the taxonomy's Distribution Channel values): brokerage SD -> `Direct - Self-Directed`, DA -> `Direct -
  Digital Advice`, HA -> `Direct - Human Advice`, TR -> `Direct - Trust`; TA direct -> `Direct - Self-Directed`;
  TA third-party omnibus, plan and networked -> `Intermediary`.
- `Holding Type`: brokerage securities by SEC_TYPE_CD and FUND_FAMILY_CD: MF+OWN `Own Mutual Fund`, ETF+OWN `Own ETF`,
  MMF+OWN `Cash and Sweep`, MF `Third-Party Mutual Fund`, ETF `Third-Party ETF`, EQ `Equity`, FI or CD `Fixed Income
  and CDs`, MMF (third-party) `Cash and Sweep`, UIT `Other`, OPT -> `UNATTRIBUTED` (no taxonomy equivalent, the planted
  gap); cash balances `Cash and Sweep`; TA positions `Own Mutual Fund` or `Own ETF` by VEHICLE_CD (money market funds
  `Cash and Sweep`).
- `Business Line` (two-letter codes of the taxonomy's Business Line list; read them with `slice.code_lists()`):
  brokerage SD -> direct brokerage, DA -> digital advice, HA -> human and hybrid advice, TR -> personal trust;
  TA direct -> proprietary funds; TA intermediary -> intermediary channel.
- `Advisor`: the `Employee_Number__c` of the owner advisor of the household the account rolls up to (through the CRM
  financial account); accounts with no household or no advisor -> `UNATTRIBUTED`. TA intermediary accounts -> `UNATTRIBUTED`.
- `Segment`: the household's `Segment__c`; no household -> `UNATTRIBUTED`.
- `Share Class`: own-fund rows only, keyed by `FUND_NO` (brokerage own-fund positions through `TA_FUND_NO`); everything
  else -> `UNATTRIBUTED` (so Share Class rows still add to Total).
- No `Campaign` rows.

Measures per row (all in USD):
- **Ending Client Assets** = brokerage positions `MKT_VAL` + brokerage cash (FCB + SWP + MDB, basis S) + TA direct
  positions `MKT_VAL` + TA third-party omnibus, plan and networked positions `MKT_VAL`. The affiliated omnibus account
  is never counted (its value is the brokerage own-fund holdings, CW-007). Closed, pending and dormant accounts count
  whatever they hold (normally zero).
- **Beginning Client Assets** = the same at the beginning month-end.
- **Average Client Assets** = mean of the month-end Ending values of the months in the period (for a month, the mean of
  beginning and ending).
- **Client Assets Excluding Intermediary-Held** = Ending less the TA third-party omnibus, plan and networked values.
- **Own-Fund Overlap Amount** = the part of Ending held in own funds: brokerage OWN positions + all counted TA positions.
- **Advised Assets** = Ending of brokerage accounts with `ENROLL_STATUS_CD` A (class A) plus class T trust accounts.
- **Net New Assets** (the certified flow treatment): sum over posted brokerage activity in the period of DEP (+), WDL
  (-), ACATI (+ `NET_AMT` or the market value delivered: use `NET_AMT`, make it positive), ACATO (-), XFRI (+), XFRO
  (-), ROLLI (+), JNL between different customers (signed per account); JNL between accounts of the same customer is
  excluded (same-owner transfer); BUY/SEL/FBUY/FRED/DIV/INT/CGD/FEE are excluded (within-account, income and fees);
  plus TA direct, third-party omnibus, plan and networked: 001 (+ NET_AMT), 002 (-), 071 (+), 072 (-); 051/052, 101,
  102, 111, 201, 202 excluded. Affiliated omnibus transactions are excluded (they mirror brokerage FBUY/FRED, which are
  within-account). Reversed rows and their reversals are excluded; pending rows are excluded.
- **Net Inter-Channel Transfers** = the signed JNL amounts between same-customer accounts in different channels,
  attributed to each account's channel (so the Total row is zero and Channel rows offset).
- **Client Market Movement and Other** = Ending - Beginning - Net New Assets - Net Inter-Channel Transfers.
- **Client Organic Growth Rate** = Net New Assets annualized (x 12 / months in the period) / Beginning Client Assets.
- **Gross Sales** = TA 001 `NET_AMT` on every TA account including the affiliated omnibus (the fund-flow family counts
  the register, where the brokerage own-fund purchases arrive as omnibus trades); **Redemptions** = TA 002;
  **Net Exchanges** = 051 - 052; **Net Flows** = Gross Sales - Redemptions + Net Exchanges. Share Class rows carry
  these by fund number; the Channel, Business Line, Advisor and Segment rows of the fund-flow family attribute the
  affiliated omnibus trades to the brokerage account behind the matching FBUY/FRED. Reversals excluded.
- **Funded Accounts** = counted accounts with Ending > 0 (brokerage accounts and TA direct accounts; a TA omnibus or
  networked account counts as one). **Clients** = distinct primary-owner persons (CRM contacts, or brokerage
  customers when unlinked) of funded accounts. **Households** = distinct CRM households of funded accounts.
- **Restatement Impact** = 0 (one Final snapshot).

Also write, at AS_OF, the household figures: per household `household_members` (active, non-merged contacts with a
current membership), `household_client_assets` (Ending of its linked, counted accounts), `household_advised_assets`,
`held_away_assets`, `without_primary_advisor` (0/1), `service_tier_mismatch` (0/1: assets qualify for a higher tier
than assigned), and the firm-level `non_household_client_assets` (Ending of counted accounts that roll up to no
household: unlinked brokerage accounts, unlinked TA direct accounts and the intermediary accounts).

`truths.json` layout:
```json
{"as_of": "2026-09-30", "seed": 20261017, "notes": ["..."],
 "planted": {"HOUSEHOLDS_WITHOUT_PRIMARY_ADVISOR": 35, "SUGGESTED_MATCHES": 13, "UNLINKED_BROKERAGE_ACCOUNTS": 15,
             "UNLINKED_BROKERAGE_VALUE": 0.0, "OPTIONS_UNATTRIBUTED": 0.0, "AFFILIATED_OMNIBUS_VALUE": 0.0,
             "BROKERAGE_OWN_FUND_VALUE": 0.0, "SERVICE_TIER_MISMATCH": 18, "INTER_CHANNEL_TRANSFER_PAIRS": 12,
             "SAME_OWNER_JOURNALS_EXCLUDED": 0.0, "REVERSED_ROWS": 25, "PENDING_ROWS": 60},
 "measure_values": [{"period_type": "Month", "period_start": "2026-07-01", "period_end": "2026-07-31",
                     "dimension_type": "Channel", "dimension_key": "Direct - Self-Directed",
                     "beginning_client_assets": 0.0, "ending_client_assets": 0.0, "average_client_assets": 0.0,
                     "net_new_assets": 0.0, "net_inter_channel_transfers": 0.0, "client_market_movement_other": 0.0,
                     "client_organic_growth_rate": 0.0, "advised_assets": 0.0, "own_fund_overlap_amount": 0.0,
                     "client_assets_excl_intermediary": 0.0, "gross_sales": 0.0, "redemptions": 0.0,
                     "net_exchanges": 0.0, "net_flows": 0.0, "funded_accounts": 0, "clients": 0, "households": 0,
                     "restatement_impact": 0.0}],
 "households": [{"crm_account_id": "001...", "household_members": 3, "household_client_assets": 0.0,
                 "household_advised_assets": 0.0, "held_away_assets": 0.0, "without_primary_advisor": 0,
                 "service_tier_mismatch": 0}],
 "non_household_client_assets": 0.0,
 "counts": {"SRC-BRK/ACCT_MASTER": 560, "...": 0}}
```

**Checks the generator must run on itself before writing** (fail loudly if any is off): the Total row's Ending equals
the sum of the Channel rows, of the Holding Type rows, of the Business Line rows, of the Advisor rows, of the Segment
rows and of the Share Class rows (each including its `UNATTRIBUTED` member) for every period; Net Inter-Channel
Transfers is zero on every Total row; `AFFILIATED_OMNIBUS_VALUE == BROKERAGE_OWN_FUND_VALUE`; every foreign reference
in the extracts resolves (contact Ids, customer numbers, fund numbers, CUSIPs, dealer numbers, contra accounts); the
quarter's Net New Assets equals the sum of the three months'.

**Style.** Plain Python, functions with short docstrings, US spelling, no third-party packages. Print a one-line
summary per table and the planted values at the end.
