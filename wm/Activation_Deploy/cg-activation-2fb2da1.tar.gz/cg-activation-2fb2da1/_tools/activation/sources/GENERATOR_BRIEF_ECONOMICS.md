# Brief addendum: client economics (`sources/generate.py`, third slice)

Read `GENERATOR_BRIEF.md` and `GENERATOR_BRIEF_INSTITUTIONAL.md` first; everything there stands and every existing
extract, figure and planted value keeps its value. This addendum adds the firm's client economics so the demo can
answer the fee, billing, cost-to-serve and profitability questions of SM-28: three new sources, `SRC-BIL` (the
advisory fee billing engine), `SRC-REV` (the revenue sub-ledger) and `SRC-CST` (the cost allocation engine).
`sources/schema.py` defines every table, column and code. Build this business after the wealth and institutional
businesses with its own random generator seeded from `"<SEED>-economics"`, so nothing upstream changes. Keep the run
deterministic and under twenty seconds.

## Time frame

Twelve fiscal months, `2025-10` to `2026-09` (the fiscal year is the calendar year; fiscal quarters are calendar
quarters: Q4 2025, Q1, Q2 and Q3 2026). Billing is quarterly in arrears. AS_OF is still 2026-09-30.

## The billing engine (`SRC-BIL`)

- **Schedules (`SCHEDULE`, `SCHEDULE_TIER`).** Six families, each with 2 or 3 versions (about 14 version rows):
  `ADV-STD` (asset-based advisory for PAS, type ADV, blended tiers 90/75/60/45 bps at 0 / 500k / 2m / 10m),
  `ADV-DIG` (DAP, type ADV, single rate 30 bps), `WMP-WRAP` (WMP, type WRAP, blended 100/80/65/50 bps),
  `TRS-ADM` (TRS, type TRST, blended 110/90/70 bps), `PLN-FLAT` (planning only, type FLAT, 0 bps, minimum annual fee
  2,400, billed to no account here: one assignment-less version so the family exists), `SVC-ACCT` (account service,
  type SVC, single rate 0 with minimum annual fee 0; no assignments). The current version of each family is active
  (`STATUS_CD` A) from 2025-01-01 with no end date; the prior versions are retired with `EFF_TO_DT` 2024-12-31; the
  version before that (where there are three) ended 2023-12-31. Each version's tiers are in `SCHEDULE_TIER`; rates
  differ a little between versions (the prior version of `ADV-STD` is 95/80/65/50). `OWN_FUND_CD` is CRED for the
  advisory families, NONE for TRS. `MAX_RATE_BPS` is the top tier.
- **Assignments (`ASSIGNMENT`).** One per enrolled brokerage account (`ACCT_MASTER.PROGRAM_CD` in DAP, PAS, WMP, TRS,
  `ENROLL_STATUS_CD` A): 140 current assignments on the current version of the program's family, effective from the
  later of 2025-01-01 and the enrollment date, open-ended, quarterly in arrears, deducted from the billed account
  (`PAY_ACCT_NO` = `ACCT_NO`, except 6 assignments that pay from another account of the same household). 30 of the
  accounts enrolled before 2025 also have a closed assignment on the prior version (2024-01-01 to 2024-12-31), so
  about 170 rows. `NEGOTIATED_FLG` true on 5.
- **Fee groups (`FEE_GROUP`, `FEE_GROUP_MBR`).** One group per CRM household that has two or more enrolled accounts
  (about 40 to 60 groups), `BASIS_CD` HH, active from 2024-01-01, members = the household's enrolled accounts (HH,
  A). Add 3 client-requested links (LINK) that bring an unenrolled account of the household in, and 2 proposed (P)
  memberships awaiting confirmation. Every assignment of a member account carries the `GROUP_ID`.
- **Runs (`FEE_RUN`).** Regular runs for the four quarters (`R-2025Q4-01`, `R-2026Q1-01`, `R-2026Q2-01`,
  `R-2026Q3-01`), all REL (released), RECON_CD REC, approved; one onboarding pro-rata run in Q2 (`R-2026Q2-02`, ONB,
  REL, REC, 6 calculations with `PRORATE_DAYS`); one termination pro-rata run in Q3 (`R-2026Q3-02`, TRM, REL, 3
  calculations, **RECON_CD BRK**: this is the one failed run of Q3); one recalculation run in Q1 (`R-2026Q1-02`,
  RECALC, APPR, REC); one simulation run for Q3 (`R-2026Q3-SIM`, SIM, CALC, blank recon, never counted); one scheduled
  Q4 2026 run (`R-2026Q4-01`, SCH, no calculations). `VAL_DT` is the period end. `NET_FEE_TOTAL` equals the sum of the
  run's `FEE_CALC.NET_FEE` **except** for `R-2026Q2-01`, where it is 1,250.00 higher (a control-total variance that is
  explained: RECON_CD EXPL; it is not a failed run because Q2 is not the quarter asked, but keep it consistent).
- **Calculations (`FEE_CALC`).** One per run and assignment in force at the period end (the regular runs bill every
  current assignment: 140 rows each). Billable assets: for `R-2026Q3-01` the account's total value at 2026-09-30 as
  the brokerage positions and cash value it (so it ties to the certified ending client assets of the account); for the
  earlier runs scale that value back by the account's market movement (use 0.97, 0.94, 0.92 for Q2, Q1, Q4 2025 with
  per-account noise). `ACCT_VALUE` = `BILLABLE_ASSETS`. `GROUP_ASSETS` = the sum of billable assets of the group's
  active member accounts in that run (blank when the assignment has no group). `RATE_BPS` = the blended rate from
  the applied schedule version's tiers on `GROUP_ASSETS` where present, else on `BILLABLE_ASSETS` (cliff and single-rate
  families use their rule). `GROSS_FEE` = `BILLABLE_ASSETS` × `RATE_BPS` / 10,000 / 4 (× `PRORATE_DAYS` / days in the
  period for pro-rata runs). `OWN_FUND_CREDIT` on CRED schedules = the account's own-fund holdings at the valuation
  date × 20 bps / 4. `WAIVER_AMT` from the waivers in force (percentage of gross, or the amount). `DISCOUNT_AMT` 0
  except 8 rows with a 10 percent discount. `NET_FEE` = gross − discount − waiver − credit, never below 0.
  Plant in `R-2026Q3-01`: **4 off-schedule calculations** whose `SCHED_ID` is the family's *prior* version while the
  assignment in force names the current one (their fee therefore differs from a re-performance on the current tiers;
  make two overbilled and two underbilled), and **2 household-breakpoint misses**: accounts that are active members
  of a group with two or more active members but whose `GROUP_ASSETS` is blank and whose rate was set on their own
  billable assets. Every other Q3 calculation re-performs exactly: `RATE_BPS` and `GROSS_FEE` follow the tiers of the
  assignment's schedule version in force at 2026-09-30 to the cent (round the fee to cents once, at the end).
  `EXCEPTION_FLG` true on the 4 off-schedule rows. `WAIVER_IDS` lists the waivers applied.
- **Waivers (`WAIVER`).** 12: 8 in force at 2026-09-30 (start on or before, end blank or after), 4 ended in 2025;
  reasons spread over PROMO, SVC, EMP, REL; 9 percentage (25, 50, 100), 3 amount; 2 of the 8 in force have a blank
  `APPROVED_BY`. Each names a current assignment.
- **Debits (`DEBIT`).** One per calculation of each released regular or pro-rata run, dated the 6th business day
  after the period end (the Q3 run's debits are dated 2026-10-07, after AS_OF, with `STATUS_CD` PEND); earlier runs'
  debits POST, except **3 of the Q2 run's debits FAIL** ("insufficient cash") and 1 REV (reversed). `AMT` =
  `NET_FEE`; `ACCT_NO` = the assignment's `PAY_ACCT_NO`; `FEE_TYPE_CD` = the schedule type.

## The revenue sub-ledger (`SRC-REV`)

- **Client revenue (`CLIENT_REV`).** Per account, stream and fiscal month, `BASIS_CD` ACT:
  - Fee streams from the billing engine: each released regular or pro-rata run's calculation is recognized in the
    three months of its billing period as `NET_FEE` / 3 (the pro-rata runs over their period's months), stream
    `ADVF` for ADV and WRAP schedules, `TRST` for TRST, with `SOURCE_REF` = `'<RUN_ID>|<ASSIGN_ID>'`, `OFFERING_CD`
    = the program, `LEGAL_ENT_CD` IA (TC for TRS). Rounding: split the net fee into cents so the three months add
    exactly to it.
  - `SWPF` (bank sweep fee) for every brokerage account with a positive sweep cash balance: balance at the prior
    month-end × 150 bps / 12 (use the account's `CASH_BAL` at the four month-ends you have and the same value for the
    earlier months, scaled like billable assets), `LEGAL_ENT_CD` BD, `OFFERING_CD` BRK for self-directed accounts, the
    program's offering for enrolled ones.
  - `COMM` for self-directed accounts' option and bond trades (a flat 0.65 per contract or 1 per bond; a few hundred
    rows over the year) and `SVCF` for the brokerage `FEE` activity rows of self-directed accounts (their `NET_AMT`,
    in the month of the trade date), `LEGAL_ENT_CD` BD, `OFFERING_CD` BRK.
  - `MGNI` margin interest for margin accounts with a debit balance (10 to 20 accounts, a few hundred dollars a
    month), BD, BRK.
  - `CHANNEL_CD`, `BUS_LINE_CD` and `SEGMENT_CD` are the account's brokerage channel, its business line (DB for
    self-directed brokerage, DA for DAP, HA for PAS and WMP, TR for TRS) and the CRM household's `Segment__c` at the
    period end (blank for accounts with no household).
- **Fund revenue (`FUND_REV`).** Per own-fund share class (`FUND_MASTER`) and month: `AVG_NET_ASSETS` lognormal
  around 400 million per class (institutional classes larger, R6/INST around 900 million), moving 1 to 2 percent a
  month; `GROSS_RATE_BPS` by product type (money market 15, index 5 to 10, bond 25 to 40, equity 35 to 60,
  target-date 10 to 20, same rate every month for a class); `GROSS_FEE` = assets × rate / 10,000 / 12;
  `WAIVER_OFFSET` 0 for most classes, 2 to 6 percent of the gross fee for 8 classes (expense caps); `NET_FEE` =
  gross − offset; `BASIS_CD` FIN for months up to 2026-08, EST for 2026-09 (one row per class and month: the
  estimate is the only row for September); `SUBADV_FEE` on 3 classes (20 percent of net), with an engagement id
  `SAE-00n`.

## The cost allocation engine (`SRC-CST`)

- **Pools (`POOL`).** 11, one per `POOL_TYPE_CD`, with the cost-to-serve component the schema gives (ADV→ADV,
  SVC→SVC, PLAT→PLAT, CLR→CLR, MM→MM, COMM→COMM, COMP→REG; MKT, PROD, DIST, CORP blank).
- **Methods (`METHOD`).** 5: direct, driver-based, activity-based, proportional to revenue, step-down.
- **Rules (`RULE`).** For each pool except CORP, one rule per target dimension among SEG, CHAN, BL, OFF (and TIER
  for ADV and SVC), about 40 rules, effective 2025-01-01, open; drivers as the schema lists (ADV by ADVHRS, SVC by
  CONTACTS, PLAT and CLR by ACCTS, MM by TXN, COMM by HH, COMP by AUM, MKT by HH, PROD by AUM, DIST direct to the
  intermediary channel and the IC business line). CORP has one step-down rule to the other pools (TARGET_DIM_CD POOL,
  SEQ_NO 1); every other rule has SEQ_NO 10.
- **Runs (`RUN`).** One FINAL actual run per month (12), plus a SUPER (superseded) actual run for 2026-06 whose
  results were replaced by the final one (keep its results too; they are history), plus one BUD (budget) FINAL run
  for 2026-09. `RESIDUAL_AMT` 0.5 to 1.5 percent of the month's pool cost (unused capacity), in the final runs.
- **Pool cost (`POOL_COST`).** The month's operating expense per pool. Size the firm so that annual operating
  expense is about 55 percent of annual gross revenue (client revenue plus fund net fee revenue): ADV the largest
  pool, then PLAT, SVC, CORP, MKT; DIST small (the intermediary business is small). Vary 3 to 8 percent month to
  month.
- **Results (`RESULT`).** For each final run: the CORP pool's step-down rule first spreads CORP's cost to the other
  ten pools (rows with `TARGET_DIM_CD` POOL and `TARGET_MEMBER` the pool id, by fixed shares that add to 100). Then
  each other rule allocates its pool's cost plus its share of CORP, less the pool's share of the residual, to the
  members of its target dimension by driver shares that add to 100 percent (channels: the certified Channel keys of
  the firm's own channels DIRECT_SELF_DIRECTED, DIRECT_DIGITAL_ADVICE, DIRECT_HUMAN_ADVICE, DIRECT_TRUST,
  INTERMEDIARY, INSTITUTIONAL_DIRECT, INSTITUTIONAL_CONSULTANT, INSTITUTIONAL_OCIO; business lines DB, DA, HA, TR,
  PF, IA, IC; segments Core, Select, Private, Flagship; offerings DAP, PAS, WMP, TRS, HYB, PLN, BRK; tiers T1 to T4).
  **Every rule of a pool allocates the same total** (the pool's allocable cost), so each dimension's members add to
  the same amount for that pool and month. Driver shares are stable across months with small noise. Make the
  `Core` segment and the `PLN` offering expensive relative to their revenue (see the planted facts).

## Derived facts the pipeline will compute (define them here so the generator can plant the truths)

- **Cost to serve** per fiscal month, dimension grain (SEG, CHAN, BL, OFF, TIER) and member: the sum of the final
  actual run's allocated amounts to that member from pools with a cost-to-serve component, by component (ADV →
  coverage and servicing, SVC → client service, PLAT → platform and technology, CLR → clearing and custody, MM →
  money movement, COMM and REG → communications and regulatory); total = the sum of the six.
- **Profitability** per fiscal month, grain (SEG, CHAN, BL, OFF) and member, actual, from the final run:
  `gross_revenue` = client revenue of the member (CLIENT_REV rows by SEGMENT_CD, CHANNEL_CD mapped to the certified
  channel key, BUS_LINE_CD, OFFERING_CD) + the month's fund net fee revenue (FUND_REV.NET_FEE total) attributed to the
  member by its share of own-fund holdings: for channels and business lines use the certified family's
  own_fund_overlap_amount of that member at the latest month-end on or before the month end (the four month-ends you
  have; for earlier months use 2026-06-30's), for segments and offerings the same computed from the accounts' own-fund
  holdings grouped by the household's segment and the account's offering (UNATTRIBUTED-like remainders go to the
  member `UNATTRIBUTED`); `distribution_payments` = DIST pool allocations to the member; `net_revenue_after_distribution_costs`
  = gross − distribution; `direct_sales_marketing_cost` = MKT pool allocations; `contribution_margin` = net revenue −
  direct S&M; `allocated_indirect_cost` = all other pools' allocations (including PROD and the step-down CORP share
  carried inside them); `operating_profit` = contribution margin − allocated indirect cost. The institutional channels
  and business lines (IA, PF, IC and the INSTITUTIONAL_* and INTERMEDIARY keys) receive cost but have no client revenue
  here (their revenue is not in this slice): leave their gross revenue at the fund revenue share only, so they show
  negative operating profit; that is expected and not one of the planted negative cuts.
- Plant it so that, over the trailing four quarters, exactly **two cuts have a negative contribution margin** among
  the firm's own service offerings and segments: offering `PLN` (planning only: little revenue, marketing cost) and
  segment `Core` (many small households). Every other offering (DAP, PAS, WMP, TRS, BRK, HYB) and segment (Select,
  Private, Flagship) has a positive contribution margin in every quarter.

## New planted facts (`truths.json` -> `planted`)

For fiscal quarter Q3 2026 (months 2026-07 to 2026-09) unless stated: `CLIENT_FEE_REVENUE_Q3` (ADVF + TRST + WRAP +
PLAN + SUBS + SVCF streams), `CLIENT_REVENUE_Q3` (all streams), `FUND_GROSS_FEE_REVENUE_Q3`, `FUND_NET_FEE_REVENUE_Q3`,
`GROSS_FEE_REVENUE_Q3` (client fee revenue + fund gross), `NET_FEE_REVENUE_Q3` (gross fee revenue − fund waiver
offsets), `NET_BILLED_FEES_Q3` and `GROSS_BILLED_FEES_Q3` and `BILLABLE_ASSETS_BILLED_Q3` (the released Q3 regular and
pro-rata runs' calculations), `AVERAGE_EFFECTIVE_RATE_BPS_Q3` (sum of rate × billable / sum billable over the same
rows), `EFFECTIVE_NET_FEE_RATE_BPS_Q3` (annualized ADVF + WRAP + TRST revenue of Q3 × 10,000 / the billable assets of
the calculations those rows reference), `FEE_RUNS_TESTED_Q3` (2: the REG and TRM runs with period end in Q3, APPR or
REL, not SIM), `FAILED_FEE_RUNS_Q3` (1), `ACCOUNTS_BILLED_OFF_SCHEDULE_Q3` (4), `BILLING_VARIANCE_Q3` (sum over the
4 of net fee − re-performed fee, where the re-performed fee is gross on the in-force version's tiers less the same
discount, waiver and credit), `HOUSEHOLD_BREAKPOINT_NOT_APPLIED_Q3` (2), `FAILED_FEE_DEBITS_Q3` (count of FAIL debits
dated in Q3: 3) and `FAILED_FEE_DEBIT_AMOUNT_Q3`, `ACTIVE_FEE_WAIVERS` (8, at AS_OF), `ACTIVE_FEE_SCHEDULE_VERSIONS` (6,
at AS_OF), `ACTIVE_FEE_SCHEDULE_ASSIGNMENTS` (140, at AS_OF), `FEE_HOUSEHOLD_MEMBER_ACCOUNTS` (active members of active
groups at AS_OF), `TOTAL_COST_TO_SERVE_Q3` (segment grain, all members), `ALLOCATED_COST_Q3` (final actual runs, to
final targets, excluding pool-to-pool rows), `UNALLOCATED_RESIDUAL_Q3`, `GROSS_REVENUE_Q3` (profitability, business-line
grain, all members), `CONTRIBUTION_MARGIN_Q3` and `OPERATING_PROFIT_Q3` (same grain), `NEGATIVE_CONTRIBUTION_CUTS` (2).

Also add lists: `fee_runs` (run_id, run_type_cd, status_cd, recon_cd, net_fee_total, calc_net_fee_sum, tested_q3,
failed_q3), `client_revenue_months` (fiscal_month × stream_cd → amount), `fund_revenue_months` (fiscal_month → gross,
offset, net, avg_assets), `profitability` (fiscal_month, grain, member → gross_revenue, distribution_payments,
direct_sales_marketing_cost, contribution_margin, allocated_indirect_cost, operating_profit) and `cost_to_serve`
(fiscal_month, grain, member → the six components and total) for every month, and `effective_rate_by_offering_q3`
(offering → effective net fee rate bps).

## Self-checks to add

Every existing check still passes. Plus: each run's `NET_FEE_TOTAL` equals its calculations' net fee sum except the Q2
regular run (exactly 1,250.00 over); every Q3 regular-run calculation other than the 4 off-schedule and 2 breakpoint
rows re-performs to the cent on the in-force version's tiers; the three months of a calculation's fee revenue add
exactly to its net fee; each profitability member's measures add up (gross − distribution − S&M = contribution;
contribution − indirect = operating profit); for each pool and month every rule's results add to the same total, and
the members' driver shares add to 100; `ALLOCATED_COST_Q3` + `UNALLOCATED_RESIDUAL_Q3` equals the three months' pool
cost (after the step-down nets out); the two negative cuts are exactly PLN and Core and no other own offering or
segment is negative; every `ACCT_NO` exists in `ACCT_MASTER`, every `CRM_HH_ID` in the CRM accounts, every
`APPROVED_BY` in `SRC-CRM User`, every `FUND_NO`/`CLASS_CD` in `FUND_MASTER`.
