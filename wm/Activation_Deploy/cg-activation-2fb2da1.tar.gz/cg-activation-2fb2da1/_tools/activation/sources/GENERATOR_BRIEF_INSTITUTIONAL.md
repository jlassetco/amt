# Brief addendum: the institutional business (`sources/generate.py`, second slice)

Read `GENERATOR_BRIEF.md` first; everything there stands. This addendum adds the institutional business so the demo
can answer "how much of our assets with public pension plans sits with clients whose relationship is at risk". Two new
sources (`SRC-INST`, the institutional client platform; `SRC-PAB`, the portfolio accounting book of record) and new
rows in the transfer agent register. `sources/schema.py` defines every table and column. Keep the run deterministic
(`config.SEED`) and under fifteen seconds; the existing planted facts keep their values except where this addendum
says a figure grows.

## The institutional business

- **Clients (`SRC-INST CLIENT`): 40.** Types: 9 PPP (public pension plans), 8 CDB, 5 CDC, 6 END, 5 FND, 3 HLTH, 2 INS,
  1 TH, 1 GOV. Entity kinds follow the type (PPP, CDB, CDC, TH -> PLAN; END, FND, HLTH -> NPO; INS -> CORP; GOV -> GOV).
  Investable assets: lognormal around 3 billion for PPP and CDB, 800 million for the rest. 38 active, 2 terminated
  (no live relationship). Invented names (state and city names are fine, no real plans). Consultants: 6 firms
  (`CONSULTANT`), 24 clients have one.
- **Relationships (`RELATIONSHIP`): 48.** Every active client has one; 8 of the larger clients have a second (SEP plus
  POOL). Segments: SEP 26, OCIO 8, POOL 10, RK 3, CIT 1. Tiers follow investable assets (T1 above 2 billion, T2 above
  500 million, T3 otherwise, T4 for POOL and CIT). Status: ACT 44, NOT 2 (under notice), ONB 1, DRM 1. OCIO
  relationships carry `OCIO_SCOPE_CD` and ERISA status; the 2 NOT relationships are among the at-risk ones.
- **Mandates (`MANDATE`): 70**, SEG mostly, 6 FOO, 4 SUB, each under a relationship of its client (OCIO and SEP
  relationships carry 1 to 3 mandates; POOL/RK/CIT relationships carry none). 62 active, 8 terminated. Strategy codes
  are `SRC-TA FUND_MASTER.PRODUCT_CD` values.
- **Portfolios (`SRC-PAB PORTFOLIO`): 62**, one per active mandate (`MANDATE_ID`, `CLIENT_ID` set), custodian and
  custody account number per portfolio, inception = mandate inception.
- **Valuations and holdings (`VALUATION`, `HOLDING`)** at the four month-ends for every active portfolio. Holdings:
  15 to 40 securities per portfolio drawn from the brokerage `SEC_MASTER` universe by the mandate's strategy (fixed
  income mandates hold FI and CD; equity mandates EQ; balanced both); 14 portfolios also hold own-fund INST-class
  shares (`ASSET_CLS_CD` OWNF, the share class CUSIP). Prices move month to month like the brokerage positions.
  `VALUATION.HOLDINGS_MKT_VAL` equals the sum of the portfolio's `HOLDING.MKT_VAL`; `CASH_VAL` is 1 to 3 percent of
  it; `ACCRUED_INCOME` 0 to 0.5 percent; `TOTAL_MKT_VAL` the sum of the three. Total separate-account assets at AS_OF
  about 9 to 11 billion, public pension plans about 4 billion of it.
- **Health scores (`HEALTH_SCORE`)**: every relationship that is not ONB gets a score at 2025-12-31, 2026-03-31,
  2026-06-30 and 2026-09-30 (so 4 per relationship). Scores 35 to 95; RAG G above 70, A 50 to 70, R below 50. At the
  latest date (2026-09-30) exactly **7 relationships are at risk** (`AT_RISK_FLG` true, score below 50, RAG R, a
  reason): **3 of them belong to public pension plans** (two SEP, one OCIO), the other four spread over CDB, END, INS
  and TH. Three of the seven were already at risk at 2026-06-30; the others became at risk in the latest quarter. No
  relationship outside these seven is at risk at the latest date; a few were at risk in earlier quarters and recovered.
- **Fund accounts.** The register gains **30 direct institutional accounts** (`SHR_ACCT` with `ACCT_TYPE_CD` D,
  `SOC_CD` 8, dealer 0010, `REG_LINE_1` the client's legal name), each listed in `SRC-INST FUND_ACCOUNT` with its
  client and relationship (POOL, RK and CIT relationships own most of them; some SEP clients also hold one). They hold
  INST-class own fund positions of 5 to 80 million at each month-end, with purchases and redemptions in the window
  like direct accounts (SOURCE_CD DR). No CRM financial accounts for them (institutional clients are not in the CRM).

## Rules added to the certified figures

Everything in the main brief stands. Add the institutional accounts to the counted assets and flows:

- **Accounts.** Each active portfolio is an account (key `PAB:<PORT_ID>`); each D fund account is an account
  (`TA:<ACCT_NO>`). Neither has a household. The person of both is the client (`CLIENT_ID`, counted once in Clients
  regardless of how many accounts the client has). Households do not count them.
- **Ending assets** of a portfolio at a month-end = `VALUATION.TOTAL_MKT_VAL`. Holding Type rows: each `HOLDING` row
  by the brokerage rule (`SEC_MASTER` type and family: OWNF -> Own Mutual Fund or Own ETF by the class; FI/CD -> Fixed
  Income and CDs; EQ -> Equity) and `CASH_VAL` + `ACCRUED_INCOME` -> Cash and Sweep. Share Class rows: own-fund
  holdings by fund number, the rest UNATTRIBUTED. Own-fund overlap: own-fund holdings. D accounts follow the direct
  account rules of the main brief.
- **Channel** of an institutional account follows its relationship: OCIO -> `INSTITUTIONAL_OCIO`; any other segment
  with a consultant on the relationship -> `INSTITUTIONAL_CONSULTANT_LED`; otherwise -> `INSTITUTIONAL_DIRECT`.
  (A D fund account takes the relationship in `FUND_ACCOUNT.REL_ID`.)
- **Business Line**: `IA` for portfolios, `PF` for D fund accounts. **Advisor** and **Segment**: `UNATTRIBUTED`.
- **Flows**: D fund accounts' 001/002 count in Net New Assets as direct accounts do; portfolios have no flows in the
  window (no capital activity is generated), so their month-to-month change is market movement.
- Not advised; not intermediary.

## New planted facts (`truths.json` -> `planted`)

`INSTITUTIONAL_CLIENTS` 40, `PUBLIC_PENSION_PLANS` 9, `AT_RISK_RELATIONSHIPS` 7, `PUBLIC_PENSION_AT_RISK_RELATIONSHIPS`
3, `INSTITUTIONAL_CLIENT_ASSETS` (all portfolios and D accounts at AS_OF), `SEPARATE_ACCOUNT_ASSETS` (portfolios only),
`PUBLIC_PENSION_CLIENT_ASSETS` (every PPP client's accounts at AS_OF), `PUBLIC_PENSION_AT_RISK_CLIENT_ASSETS` (the
accounts under the 3 at-risk PPP relationships at AS_OF), `AT_RISK_CLIENT_ASSETS` (under all 7). Also add a
`relationships` list: one entry per relationship with `rel_id`, `client_id`, `client_type_cd`, `segment_cd`,
`latest_score_date`, `latest_score`, `at_risk`, `at_risk_reason_cd`, `relationship_client_assets` (the assets of the
portfolios and fund accounts served under it at AS_OF), `channel_code`.

## Self-checks to add

Every existing check still passes (the dimension rows still add to Total, Net Inter-Channel Transfers zero, the
quarter equals the months). Plus: `VALUATION.TOTAL_MKT_VAL` = holdings + cash + accrued per portfolio and date;
`PUBLIC_PENSION_AT_RISK_CLIENT_ASSETS` equals the sum of `relationship_client_assets` over the three PPP at-risk
relationships; `SEPARATE_ACCOUNT_ASSETS` equals the sum of the valuations at AS_OF; every `FUND_ACCOUNT.TA_ACCT_NO`
exists in `SHR_ACCT` with type D; every `MANDATE_ID` of a portfolio exists; every client of a relationship exists.
