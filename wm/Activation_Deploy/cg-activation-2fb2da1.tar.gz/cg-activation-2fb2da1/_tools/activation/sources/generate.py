"""The synthetic firm: a hypothetical US direct wealth manager and the extracts of its three source systems.

Writes, under activation/out/sources/:
  SRC-BRK/, SRC-CRM/, SRC-TA/, SRC-INST/, SRC-PAB/, SRC-BIL/, SRC-REV/, SRC-CST/   one CSV per table (header = the columns of schema.py, in order) and _dictionary.csv
  truths.json                   the certified figures and planted facts, computed here in Python, independently of the
                                compiled SQL pipeline that must reproduce them

The firm: a broker-dealer (BD, dealer 0010), a trust company (TC) and its own fund family (OWN). 300 households,
about 1,000 contacts, 60 users, about 560 brokerage accounts, 300 direct fund accounts and a handful of intermediary
accounts on the fund register; and an institutional business (GENERATOR_BRIEF_INSTITUTIONAL.md): 40 institutional
clients with 48 relationships, 62 separate-account portfolios and 30 direct institutional fund accounts; and the client
economics (GENERATOR_BRIEF_ECONOMICS.md): the fee billing engine, the revenue sub-ledger and the cost allocation engine
over the twelve fiscal months 2025-10 to 2026-09. Everything is invented: names, tickers (own funds FX..., third-party Y...) and CUSIPs.

The rules are those of GENERATOR_BRIEF.md and its addenda GENERATOR_BRIEF_INSTITUTIONAL.md and GENERATOR_BRIEF_ECONOMICS.md. Run from _tools/:  python activation/sources/generate.py
Standard library only; deterministic from config.SEED. Amounts are held in integer cents and quantities in
thousandths so that the planted equalities are exact.
"""
import csv, json, os, random, sys
from datetime import date, timedelta
from fractions import Fraction

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)
import _paths  # noqa: E402,F401
import config  # noqa: E402
import schema  # noqa: E402
import slice as taxonomy_slice  # noqa: E402

OUT = os.path.join(_paths.OUT, "sources")
NOTES = []

MONTH_ENDS = [date(2026, 6, 30), date(2026, 7, 31), date(2026, 8, 31), date(2026, 9, 30)]
WINDOW_START, WINDOW_END = date(2026, 7, 1), date(2026, 9, 30)
HOLIDAYS = {date(2026, 7, 3), date(2026, 9, 7)}
PERIODS = [("Month", 0, 1), ("Month", 1, 2), ("Month", 2, 3), ("Quarter", 0, 3)]   # (type, beginning ME, ending ME)
UNATTRIBUTED = "UNATTRIBUTED"
TIERS = [("T4", 10_000_000_00), ("T3", 2_000_000_00), ("T2", 500_000_00), ("T1", 0)]
TIER_NAMES = {"T1": "Digital", "T2": "Select", "T3": "Private", "T4": "Flagship"}
SEGMENT_OF_TIER = {"T1": "Core", "T2": "Select", "T3": "Private", "T4": "Flagship"}
BRK_CHANNEL_LABEL = {"SD": "Direct - Self-Directed", "DA": "Direct - Digital Advice", "HA": "Direct - Human Advice",
                     "TR": "Direct - Trust", "TA": "Direct - Self-Directed", "INT": "Intermediary"}
INST_CHANNEL_LABEL = {"IOCIO": "Institutional - OCIO", "ICONS": "Institutional - Consultant-Led",
                      "IDIR": "Institutional - Direct"}

FIRST = ["James", "Mary", "Robert", "Patricia", "John", "Jennifer", "Michael", "Linda", "David", "Elizabeth", "William",
         "Barbara", "Richard", "Susan", "Joseph", "Jessica", "Thomas", "Sarah", "Charles", "Karen", "Daniel", "Nancy",
         "Matthew", "Lisa", "Anthony", "Betty", "Mark", "Margaret", "Steven", "Sandra", "Andrew", "Ashley", "Kenneth",
         "Emily", "Kevin", "Donna", "Brian", "Michelle", "George", "Carol", "Priya", "Wei", "Aisha", "Carlos", "Mei",
         "Omar", "Sofia", "Diego", "Hana", "Ravi", "Elena", "Kwame", "Yuki", "Fatima", "Luis", "Ingrid", "Tariq", "Nina"]
CHILD = ["Ava", "Liam", "Noah", "Olivia", "Emma", "Mason", "Lucas", "Mia", "Ethan", "Zoe", "Leo", "Maya", "Aria", "Owen"]
LAST = ["Okafor", "Whitfield", "Marlowe", "Castellano", "Brennan", "Nakamura", "Lindqvist", "Abernathy", "Delacroix",
        "Huxley", "Ramanathan", "Sorensen", "Achebe", "Valdivia", "Kowalczyk", "Prescott", "Thornbury", "Ferreira",
        "Galloway", "Haldane", "Iverson", "Jablonski", "Kerrigan", "Lowell", "Mbeki", "Novak", "Oyelaran", "Pembroke",
        "Quintero", "Rourke", "Sandoval", "Tanaka", "Underhill", "Vasquez", "Wexler", "Yamamoto", "Zielinski", "Ashworth",
        "Blackwood", "Calloway", "Dunmore", "Eastman", "Fairbanks", "Granger", "Holloway", "Ingram", "Jardine",
        "Kingsley", "Langford", "Merriweather", "Northcott", "Osei", "Pacheco", "Radcliffe", "Stanhope", "Trevino",
        "Upton", "Vance", "Winslow", "Yardley", "Alvarez", "Bergstrom", "Chandrasekar", "Dorsey", "Eriksen", "Fontaine",
        "Gutierrez", "Hargrove", "Ishikawa", "Kaminski", "Lachance", "Moreau", "Nwosu", "Ostrowski", "Petrakis"]


# ---------------------------------------------------------------------------------------------------------------------
# Small helpers

def business_days(start, end):
    """Weekdays from start to end inclusive, less the two market holidays of the window."""
    out, d = [], start
    while d <= end:
        if d.weekday() < 5 and d not in HOLIDAYS:
            out.append(d)
        d += timedelta(days=1)
    return out


BDAYS = business_days(WINDOW_START, WINDOW_END)


def next_bday(d):
    """The next business day after d."""
    d += timedelta(days=1)
    while d.weekday() >= 5 or d in HOLIDAYS:
        d += timedelta(days=1)
    return d


def month_index(d):
    """Index into MONTH_ENDS of the month-end that closes the month of d (1 = July)."""
    return d.month - 6


def ymd(d):
    """Brokerage and transfer-agent date format."""
    return d.strftime("%Y%m%d") if d else ""


def iso(d):
    """CRM date format."""
    return d.isoformat() if d else ""


def stamp(d, rng):
    """CRM timestamp on day d."""
    return "%sT%02d:%02d:%02dZ" % (d.isoformat(), rng.randint(8, 20), rng.randint(0, 59), rng.randint(0, 59))


def amt(cents):
    """Cents as a two-decimal amount string."""
    if cents is None:
        return ""
    sign = "-" if cents < 0 else ""
    return "%s%d.%02d" % (sign, abs(cents) // 100, abs(cents) % 100)


def qty(milli):
    """Thousandths as a three-decimal quantity string."""
    if milli is None:
        return ""
    sign = "-" if milli < 0 else ""
    return "%s%d.%03d" % (sign, abs(milli) // 1000, abs(milli) % 1000)


def value_of(milli, price_cents, mult=1):
    """Market value in cents of a quantity at a price, rounded half up."""
    sign = -1 if milli < 0 else 1
    return sign * ((abs(milli) * price_cents * mult + 500) // 1000)


def shares_for(cents, price_cents, whole=False):
    """Quantity in thousandths worth about `cents` at the price."""
    q = cents * 1000 // max(price_cents, 1)
    return max(1000, round(q / 1000) * 1000) if whole else max(1, q)


def sfid(prefix, n):
    """An 18-character Salesforce-style Id."""
    return "%sAb%010dIAJ" % (prefix, n)


def lognormal_cents(rng, median_dollars, sigma):
    """A lognormal dollar amount, in cents."""
    return int(rng.lognormvariate(0, sigma) * median_dollars * 100)


def tier_for(cents):
    """The service tier household assets qualify for."""
    for code, threshold in TIERS:
        if cents >= threshold:
            return code


def round_cents(frac):
    """A Fraction of cents rounded half up to whole cents."""
    sign = -1 if frac < 0 else 1
    return sign * int(abs(frac) + Fraction(1, 2))


# ---------------------------------------------------------------------------------------------------------------------
# The taxonomy's code values the certified figures are keyed by

def taxonomy_keys():
    """The taxonomy codes the certified figures are keyed by: Business Line and Distribution Channel codes by role
    (the bracketed codes of the two enterprise shared lists), checked against the Holding Type values."""
    lists = taxonomy_slice.code_lists()
    def find(name):
        for (dom, n), values in sorted(lists.items()):
            if n == name:
                return {label: code for label, _, code in values}
        raise SystemExit("code list %r not found in the taxonomy" % name)
    bl, ch = find("Shared: Business Line"), find("Shared: Distribution Channel")
    def code(codes, label):
        hits = [c for v, c in codes.items() if v.startswith(label)]
        assert len(hits) == 1, label
        return hits[0]
    business_lines = {"SD": code(bl, "Direct brokerage"), "DA": code(bl, "Digital advice"),
                      "HA": code(bl, "Human and hybrid"), "TR": code(bl, "Personal trust"),
                      "TA": code(bl, "Proprietary funds"), "INT": code(bl, "Intermediary channel"),
                      "IA": code(bl, "Institutional advisory")}
    channels = {k: ch[v] for k, v in BRK_CHANNEL_LABEL.items()}
    channels.update({k: ch[v] for k, v in INST_CHANNEL_LABEL.items()})
    holding_types = set(find("Holding Type"))
    for v in ["Own Mutual Fund", "Own ETF", "Cash and Sweep", "Third-Party Mutual Fund", "Third-Party ETF", "Equity",
              "Fixed Income and CDs", "Other"]:
        assert v in holding_types, v
    return business_lines, channels


# ---------------------------------------------------------------------------------------------------------------------
# Reference data: users, offerings, tiers, dealers, the fund family and the security master

def build_users(rng, f):
    """45 advisors (40 Active, 2 Onboarding, 2 Transitioning, 1 Inactive) and 15 other users."""
    statuses = ["Active"] * 40 + ["Onboarding"] * 2 + ["Transitioning"] * 2 + ["Inactive"]
    others = ["Planner"] * 4 + ["Service Associate"] * 5 + ["Trust Officer"] * 2 + ["Supervisor"] * 2 + ["Operations"] * 2
    titles = {"Advisor": ["Financial Advisor", "Senior Financial Advisor", "Wealth Advisor"],
              "Planner": ["Financial Planner"], "Service Associate": ["Client Service Associate"],
              "Trust Officer": ["Trust Officer"], "Supervisor": ["Branch Supervisor"], "Operations": ["Operations Analyst"]}
    rows = []
    for i in range(60):
        role = "Advisor" if i < 45 else others[i - 45]
        status = statuses[i] if i < 45 else ""
        rows.append({"Id": sfid("005", i + 1), "Name": "%s %s" % (rng.choice(FIRST), rng.choice(LAST)),
                     "Title": rng.choice(titles[role]), "Employee_Number__c": "E%05d" % (10100 + i * 7),
                     "UserRole.Name": role, "IsActive": "false" if status == "Inactive" else "true",
                     "Advisor_Status__c": status,
                     "Business_Lines__c": rng.choice(["HA", "HA;PT", "DA;HA", "HA"]) if role == "Advisor" else
                                          ("PT" if role == "Trust Officer" else ""),
                     "Channels_Offered__c": rng.choice(["Phone;Video", "Phone;Video;InPerson", "Video;Chat", "Phone"]),
                     "Branch__c": "B%03d" % rng.choice([11, 17, 23, 31, 42, 58]), "Rep_Code__c": "R%04d" % (4100 + i * 13)})
    f["users"] = rows
    f["advisors"] = [u for u in rows if u["UserRole.Name"] == "Advisor"]
    f["owner_pool"] = [u for u in f["advisors"] if u["Advisor_Status__c"] in ("Active", "Transitioning")]
    f["user_by_id"] = {u["Id"]: u for u in rows}


def build_offerings(f):
    """The seven offerings and four service tiers."""
    O = [("DAP", "Digital Advice Program", "DigitalAdvice", "DigitalOnly", "Discretionary", "IA", "true", "true", 3000),
         ("PAS", "Personal Advisor Services", "PersonalAdvisor", "DedicatedAdvisor", "Discretionary", "IA", "true", "true", 50000),
         ("WMP", "Wealth Management Program", "WealthManagement", "AdvisorTeam", "Discretionary", "IA", "true", "true", 2000000),
         ("TRS", "Trust Services", "TrustServices", "AdvisorTeam", "Discretionary", "TC", "false", "false", 1000000),
         ("PLN", "Planning Only", "PlanningOnly", "DedicatedAdvisor", "NA", "IA", "false", "false", 0),
         ("BRK", "Self-Directed Brokerage", "Brokerage", "DigitalOnly", "NA", "BD", "false", "false", 0),
         ("HYB", "Hybrid Advice", "HybridAdvice", "DigitalWithAdvisor", "Discretionary", "DUAL", "true", "true", 50000)]
    f["offerings"] = [{"Code__c": c, "Name": n, "Type__c": t, "Delivery_Mode__c": dm, "Discretion__c": di,
                       "Capacity__c": ca, "Wrap_Fee__c": w, "Rule_3a4__c": r, "Status__c": "Active",
                       "Minimum_Assets__c": amt(m * 100)} for c, n, t, dm, di, ca, w, r, m in O]
    f["tiers"] = [{"Code__c": c, "Name": TIER_NAMES[c], "Offering__c": o, "Asset_Threshold__c": amt(th),
                   "Threshold_Basis__c": "HouseholdAssets"}
                  for (c, th), o in zip(reversed(TIERS), ["DAP", "PAS", "WMP", "WMP"])]


def build_dealers(f):
    """The firm's broker-dealer, the intermediaries holding omnibus or networked accounts, and one unused dealer."""
    D = [("0010", "The Firm Brokerage Services LLC", "0010", "AFF"), ("0421", "Meridian Wirehouse Securities", "0421", "WH"),
         ("0877", "Harborview RIA Custody", "0877", "RIA"), ("1203", "First Prairie Bank Brokerage", "1203", "BK"),
         ("2290", "Summit Plan Recordkeeping", "2290", "RK"), ("3315", "Lakeshore Independent Brokers", "3315", "BK")]
    f["dealers"] = [{"DEALER_NO": a, "DEALER_NM": b, "NSCC_NO": c, "DEALER_TYPE_CD": d} for a, b, c, d in D]
    NOTES.append("DEALER has 6 rows: the 5 dealers the brief names (0010, 0421, 0877, 1203, 2290) plus one unused "
                 "(3315); the brief's 'those 6 rows plus one unused' counts one more than it lists.")


def random_walk(rng, p0, step=0.06):
    """Four month-end prices in cents: a random walk of up to plus or minus `step` a month."""
    out = [p0]
    for _ in range(3):
        out.append(max(5, int(round(out[-1] * (1 + rng.uniform(-step, step))))))
    return out


def build_funds(rng, f):
    """18 own products with 2 or 3 share classes (INV, ADM, and ETF for 6), and their security master rows."""
    P = [("Broad Market Equity Index Fund", "EQ", "BME"), ("Large Cap Core Index Fund", "EQ", "LCC"),
         ("Mid Cap Blend Index Fund", "EQ", "MCB"), ("Small Cap Value Index Fund", "EQ", "SCV"),
         ("International Developed Equity Index Fund", "EQ", "IDE"), ("Core Bond Index Fund", "FI", "CBI"),
         ("Emerging Markets Equity Index Fund", "EQ", "EME"), ("Dividend Growth Fund", "EQ", "DGR"),
         ("Global Quality Equity Fund", "EQ", "GQE"), ("Real Estate Securities Index Fund", "EQ", "RES"),
         ("Short-Term Treasury Fund", "FI", "STT"), ("Intermediate Municipal Bond Fund", "FI", "IMB"),
         ("Inflation-Protected Securities Fund", "FI", "IPS"), ("High Yield Corporate Fund", "FI", "HYC"),
         ("Balanced Allocation Fund", "BAL", "BAL"), ("Retirement Path 2045 Fund", "BAL", "RPF"),
         ("Federal Money Market Fund", "MM", "FMM"), ("Treasury Money Market Fund", "MM", "TMM")]
    funds, secs, n = [], [], 0
    for i, (name, acls, abbr) in enumerate(P):
        classes = ["INV", "ADM"] + (["ETF"] if i < 6 else [])
        base = 100 if acls == "MM" else rng.randint(1800, 32000)
        incept = date(rng.randint(1992, 2018), rng.randint(1, 12), rng.randint(1, 28))
        for cls in classes:
            n += 1
            fund_no = "%04d" % (500 + n * 7)
            cusip = "31%06dF" % (420000 + n * 13)
            ticker = "FX" + abbr + {"INV": "X", "ADM": "A", "ETF": "E"}[cls]
            prices = [100] * 4 if acls == "MM" else random_walk(rng, base + (0 if cls == "INV" else rng.randint(-300, 300)))
            vehicle = "ETF" if cls == "ETF" else "OEF"
            funds.append({"FUND_NO": fund_no, "FUND_NM": name, "CLASS_CD": cls, "PRODUCT_CD": "P%04d" % (i + 1),
                          "CUSIP": cusip, "TICKER": ticker, "VEHICLE_CD": vehicle, "ASSET_CLS_CD": acls,
                          "INCEPT_DT": ymd(incept if cls != "ETF" else date(2021, 3, 15)),
                          "STATUS_CD": "S" if (abbr == "SCV" and cls == "INV") else "A",
                          "MIN_INIT_INV": amt({"INV": 3000, "ADM": 50000, "ETF": 0}[cls] * 100),
                          "INVESTOR_TYPE_CD": "RI" if cls == "ADM" else "R"})
            stype = "ETF" if cls == "ETF" else ("MMF" if acls == "MM" else "MF")
            secs.append(dict(CUSIP=cusip, SYMBOL=ticker, SEC_DESC=(name + " " + {"INV": "INVESTOR", "ADM": "ADMIRAL",
                             "ETF": "ETF SHARES"}[cls]).upper(), SEC_TYPE_CD=stype,
                             ASSET_CLS_CD={"EQ": "EQ", "FI": "FI", "MM": "CASH", "BAL": "MA"}[acls],
                             ISSUER_NM="The Firm Funds Trust", FUND_FAMILY_CD="OWN", TA_FUND_NO=fund_no, CCY="USD",
                             SEC_STATUS_CD="A", _prices=prices, _mult=1))
    f["funds"] = funds
    f["fund_by_no"] = {x["FUND_NO"]: x for x in funds}
    return secs


def build_third_party(rng):
    """About 250 third-party securities: EQ 150, ETF 40, MF 30, FI 20, CD 5, OPT 8, plus 2 UIT and 1 money market."""
    A = ["Northwind", "Bluegate", "Copperline", "Redfern", "Silverbrook", "Ironwood", "Clearwater", "Highmark", "Lakemont",
         "Stonebridge", "Brightwater", "Falconer", "Greystone", "Harbor", "Juniper", "Kestrel", "Larkspur", "Maple",
         "Oakridge", "Pinecrest", "Quarry", "Riverton", "Summit", "Tidewater", "Westfield"]
    B = ["Industries", "Systems", "Holdings", "Energy", "Biosciences", "Logistics", "Materials", "Networks", "Foods",
         "Robotics", "Semiconductor", "Health", "Financial", "Utilities", "Retail", "Aerospace"]
    SPONSORS = ["HRZ", "MRD", "CST", "PLR", "VRT"]
    used, secs = set(), []
    def symbol():
        while True:
            s = "Y" + "".join(rng.choice("ABCDEFGHJKLMNPQRSTUVWXZ") for _ in range(3))
            if s not in used:
                used.add(s)
                return s
    def add(stype, acls, desc, issuer, family, price, mult=1):
        secs.append(dict(CUSIP="%06d%s%02d" % (110000 + len(secs) * 211, "ABCDEFGHJK"[len(secs) % 10], len(secs) % 97),
                         SYMBOL=symbol(), SEC_DESC=desc.upper(), SEC_TYPE_CD=stype, ASSET_CLS_CD=acls, ISSUER_NM=issuer,
                         FUND_FAMILY_CD=family, TA_FUND_NO="", CCY="USD", SEC_STATUS_CD="A",
                         _prices=random_walk(rng, price) if stype != "MMF" else [100] * 4, _mult=mult))
    names = set()
    while len(names) < 150:
        names.add("%s %s" % (rng.choice(A), rng.choice(B)))
    for nm in sorted(names):
        add("EQ", "EQ", nm + " Inc Common Stock", nm + " Inc", "", rng.randint(1500, 45000))
    themes = ["US Total Market", "S&P Style Large Cap", "Dividend", "Technology", "Health Care", "Aggregate Bond",
              "Short Treasury", "International", "Emerging Markets", "Small Cap"]
    for i in range(40):
        sp, th = SPONSORS[i % 5], themes[i % 10]
        add("ETF", "FI" if "Bond" in th or "Treasury" in th else "EQ", "%s %s ETF %d" % (sp, th, i // 10 + 1),
            sp + " ETF Trust", sp, rng.randint(3000, 50000))
    for i in range(30):
        sp = SPONSORS[(i + 2) % 5]
        add("MF", "EQ" if i % 3 else "FI", "%s %s Fund Class %s" % (sp, themes[(i * 3) % 10], "AIC"[i % 3]),
            sp + " Funds", sp, rng.randint(1000, 8000))
    for i in range(20):
        issuer = "%s %s" % (A[i % 25], B[(i * 5) % 16])
        add("FI", "FI", "%s Corp %.2f%% %02d/15/%d" % (issuer, 3 + (i % 9) * 0.25, i % 12 + 1, 2028 + i % 10),
            issuer + " Corp", "", rng.randint(9200, 10400))
    for i in range(5):
        add("CD", "FI", "First %s Bank CD %.2f%% %02d/2027" % (A[i * 3], 3.9 + i * 0.1, i * 2 + 1),
            "First %s Bank" % A[i * 3], "", 10000)
    eq = [s for s in secs if s["SEC_TYPE_CD"] == "EQ"]
    for i in range(8):
        u = eq[i * 17]
        add("OPT", "DER", "%s %s 12/18/26 %d" % ("CALL" if i % 2 == 0 else "PUT", u["SYMBOL"],
            u["_prices"][0] // 100 + 5), u["ISSUER_NM"], "", rng.randint(150, 1800), mult=100)
    for i in range(2):
        add("UIT", "MA", "Balanced Income Trust Series %d" % (40 + i), "Unit Investment Trust Sponsor", "", rng.randint(900, 1200))
    add("MMF", "CASH", "PLR Government Money Market Fund", "PLR Funds", "PLR", 100)
    return secs


def holding_type(sec):
    """The taxonomy Holding Type of a brokerage security (options have none: the planted gap)."""
    st, own = sec["SEC_TYPE_CD"], sec["FUND_FAMILY_CD"] == "OWN"
    if st == "MF":
        return "Own Mutual Fund" if own else "Third-Party Mutual Fund"
    if st == "ETF":
        return "Own ETF" if own else "Third-Party ETF"
    return {"MMF": "Cash and Sweep", "EQ": "Equity", "FI": "Fixed Income and CDs", "CD": "Fixed Income and CDs",
            "UIT": "Other", "OPT": UNATTRIBUTED}[st]


def fund_holding_type(fund):
    """The Holding Type of a fund-register position or transaction, by vehicle (money market funds are cash)."""
    if fund["ASSET_CLS_CD"] == "MM":
        return "Cash and Sweep"
    return "Own ETF" if fund["VEHICLE_CD"] == "ETF" else "Own Mutual Fund"


# ---------------------------------------------------------------------------------------------------------------------
# People: households, contacts and brokerage customers

def person(rng, role, last):
    """A first name and birth date for a household role."""
    if role == "Dependent":
        return rng.choice(CHILD), date(rng.randint(2006, 2020), rng.randint(1, 12), rng.randint(1, 28))
    return rng.choice(FIRST), date(rng.randint(1942, 1992), rng.randint(1, 12), rng.randint(1, 28))


def build_households(rng, f):
    """300 households of 2 to 3 members, 60 trusted-contact persons, 40 prospects, 12 deceased and 8 merged contacts."""
    contacts, households, n = [], [], [0]
    def contact(first, last, dob, hh, role, start, stage, lead):
        n[0] += 1
        c = {"Id": sfid("003", n[0]), "FirstName": first, "LastName": last, "Birthdate": iso(dob),
             "Deceased_Date__c": "", "AccountId": hh or "", "FinServ__PrimaryHouseholdRole__c": role,
             "Household_Start__c": iso(start), "Household_End__c": "", "Status__c": "Active", "Merged_Into__c": "",
             "FinServ__Status__c": stage, "LeadSource": lead, "Brokerage_Customer_No__c": "",
             "Do_Not_Contact__c": "true" if rng.random() < 0.03 else "false", "_dob": dob}
        contacts.append(c)
        return c
    leads = ["Web", "Mobile", "Phone", "Advisor", "Workplace", "TransferAgent", "AccountTransfer", "Referral"]
    for h in range(300):
        hid, last = sfid("001", h + 1), rng.choice(LAST)
        created = date(rng.randint(2012, 2025), rng.randint(1, 12), rng.randint(1, 28))
        r = rng.random()
        roles = ["Head", "Spouse", "Dependent"] if r < 0.85 else (["Head", "Spouse"] if r < 0.95 else ["Head", "Dependent"])
        members = []
        lead = rng.choice(leads)
        for role in roles:
            first, dob = person(rng, role, last)
            members.append(contact(first, last, dob, hid, role, created, "Client", lead))
        households.append({"Id": hid, "Name": last + " Household", "RecordType.Name": "Household",
                           "FinServ__PrimaryContact__c": members[0]["Id"], "OwnerId": "", "FinServ__Status__c": "Active",
                           "Segment__c": "", "Service_Tier__c": "", "Tier_Method__c": "", "Formation_Basis__c":
                           rng.choice(["Client"] * 6 + ["AdvisorProposed"] * 3 + ["SystemSuggested"]),
                           "Household_Confirmed_Date__c": iso(created + timedelta(days=rng.randint(0, 600))),
                           "CreatedDate": stamp(created, rng), "_members": members, "_created": created})
    for _ in range(60):
        first, dob = person(rng, "Head", None)
        contact(first, rng.choice(LAST), dob, None, "", date(2023, 1, 1) + timedelta(days=rng.randint(0, 1000)),
                "Related Party", "Referral")
    for _ in range(40):
        first, dob = person(rng, "Head", None)
        contact(first, rng.choice(LAST), dob, None, "", date(2026, 1, 1) + timedelta(days=rng.randint(0, 250)),
                "Prospect", rng.choice(leads))
    for c in contacts:
        if not c["AccountId"]:
            c["Household_Start__c"] = ""
    adults = [c for h in households for c in h["_members"] if c["FinServ__PrimaryHouseholdRole__c"] != "Dependent"]
    adults.sort(key=lambda c: c["_dob"])
    for c in rng.sample(adults[:120], 12):
        c["Deceased_Date__c"] = iso(date(2025, 1, 1) + timedelta(days=rng.randint(0, 600)))
    for c in rng.sample([a for a in adults if not a["Deceased_Date__c"]], 8):
        dup = contact(c["FirstName"], c["LastName"], c["_dob"], c["AccountId"], c["FinServ__PrimaryHouseholdRole__c"],
                      date(2024, 5, 1), "Client", c["LeadSource"])
        dup.update({"Status__c": "Merged", "Merged_Into__c": c["Id"],
                    "Household_End__c": iso(date(2025, 1, 1) + timedelta(days=rng.randint(0, 500)))})
    NOTES.append("Deceased contacts keep Status__c Active and a current membership (the brief: 'still members'), so "
                 "they count in household_members; merged duplicates (Status__c Merged, Household_End__c set) do not.")
    # Owners: 265 households with an active or transitioning advisor, 35 without
    unowned = set(rng.sample(range(300), 35))
    for i, h in enumerate(households):
        if i not in unowned:
            h["OwnerId"] = rng.choice(f["owner_pool"])["Id"]
    f["households"], f["contacts"] = households, contacts
    f["hh_by_id"] = {h["Id"]: h for h in households}
    f["contact_by_id"] = {c["Id"]: c for c in contacts}


def build_customers(rng, f):
    """Brokerage customers for 270 households: heads, spouses and some dependents; 10 percent legacy (no CRM Id)."""
    hh_brk = rng.sample(f["households"], 270)
    brk_ids = {h["Id"] for h in hh_brk}
    for h in f["households"]:
        h["_has_brk"] = h["Id"] in brk_ids
    customers, n = [], [0]
    def customer(c, h):
        n[0] += 1
        cu = {"CUST_NO": "C%07d" % (88000 + n[0] * 3), "FIRST_NM": c["FirstName"], "LAST_NM": c["LastName"],
              "DOB": ymd(c["_dob"]), "DOD": c["Deceased_Date__c"].replace("-", ""),
              "TAX_ID_LAST4": "%04d" % rng.randint(0, 9999), "CUST_STATUS_CD": "A", "MERGED_TO_CUST_NO": "",
              "CRM_CONTACT_ID": c["Id"], "ONBOARD_CHANNEL_CD": rng.choice(["WEB", "WEB", "MOB", "PHN", "ADV", "XFR"]),
              "_contact": c, "_hh": h}
        c["_cust"] = cu
        customers.append(cu)
        return cu
    for h in hh_brk:
        for c in h["_members"]:
            role = c["FinServ__PrimaryHouseholdRole__c"]
            if role in ("Head", "Spouse") or (role == "Dependent" and rng.random() < 0.4):
                customer(c, h)
    f["customers"] = customers
    f["hh_brk"] = hh_brk


def link_customers(rng, f):
    """CRM_CONTACT_ID on 90 percent; of the legacy 10 percent, 80 percent reachable by Brokerage_Customer_No__c."""
    customers = f["customers"]
    legacy = rng.sample(customers, round(len(customers) * 0.10))
    by_name = rng.sample(legacy, round(len(legacy) * 0.20))
    legacy_ids, name_ids = {c["CUST_NO"] for c in legacy}, {c["CUST_NO"] for c in by_name}
    for cu in customers:
        c = cu["_contact"]
        if cu["CUST_NO"] in legacy_ids:
            cu["CRM_CONTACT_ID"] = ""
            if cu["CUST_NO"] not in name_ids:
                c["Brokerage_Customer_No__c"] = cu["CUST_NO"]
        elif rng.random() < 0.6:
            c["Brokerage_Customer_No__c"] = cu["CUST_NO"]
    # A name-and-birth-date match must be unique among contacts for it to be a fair suggestion
    keys = {}
    for c in f["contacts"]:
        if c["Status__c"] != "Merged":
            keys.setdefault((c["FirstName"], c["LastName"], c["_dob"]), []).append(c)
    for cu in by_name:
        assert len(keys[(cu["FIRST_NM"], cu["LAST_NM"], cu["_contact"]["_dob"])]) == 1


# ---------------------------------------------------------------------------------------------------------------------
# Brokerage accounts

def build_brokerage_accounts(rng, f):
    """About 560 accounts: B 420, A 125, T 15; status O 520, C 30, D 8, P 2; about 120 joint."""
    accts, n = [], [0]
    def add(prim, sec, reg):
        n[0] += 1
        a = {"ACCT_NO": "%08d" % (30010000 + n[0] * 17), "_prim": prim, "_sec": sec, "REG_CD": reg,
             "_hh": prim["_hh"], "_open": date(rng.randint(2012, 2025), rng.randint(1, 12), rng.randint(1, 28))}
        accts.append(a)
        prim.setdefault("_accts", []).append(a)
        return a
    custs = {h["Id"]: {} for h in f["hh_brk"]}
    for cu in f["customers"]:
        custs[cu["_hh"]["Id"]].setdefault(cu["_contact"]["FinServ__PrimaryHouseholdRole__c"], []).append(cu)
    for h in f["hh_brk"]:
        add(custs[h["Id"]]["Head"][0], None, rng.choice(["IND", "IND", "IND", "TIRA", "RIRA", "ROLL"]))
    with_spouse = [h for h in f["hh_brk"] if "Spouse" in custs[h["Id"]]]
    for h in rng.sample(with_spouse, 120):
        add(custs[h["Id"]]["Head"][0], custs[h["Id"]]["Spouse"][0], "JTWROS" if rng.random() < 0.83 else "TIC")
    for cu in f["customers"]:
        if cu["_contact"]["FinServ__PrimaryHouseholdRole__c"] == "Dependent":
            add(cu, None, rng.choice(["UTMA", "UTMA", "529"]))
    k = 0
    while len(accts) < 560:
        h = rng.choice(with_spouse if k % 2 == 0 else f["hh_brk"])
        if k % 2 == 0:
            add(custs[h["Id"]]["Spouse"][0], None, rng.choice(["TIRA", "RIRA", "IND"]))
        else:
            add(custs[h["Id"]]["Head"][0], None, rng.choice(["TIRA", "ROLL", "SEP", "INHIRA", "RIRA"]))
        k += 1
    assert len(accts) == 560, len(accts)
    for cu in f["customers"]:
        if not cu.get("_accts") and not any(a["_sec"] is cu for a in accts):
            cu["CUST_STATUS_CD"] = "I"
    f["accts"] = accts
    assign_classes(rng, f)
    assign_statuses(rng, f)
    finish_accounts(rng, f)


def assign_classes(rng, f):
    """Reserve the journal pairs, then set 15 trust and 125 managed advisory accounts; the rest are self-directed."""
    accts = f["accts"]
    for a in accts:
        a["_cls"], a["_chan"] = "B", "SD"
    multi = [cu for cu in f["customers"] if len(cu.get("_accts", [])) >= 2]
    picks = rng.sample(multi, 30)
    reserved = set()
    f["inter_pairs"], f["same_pairs"], f["gift_pairs"] = [], [], []
    for i, cu in enumerate(picks):
        src, dst = cu["_accts"][0], cu["_accts"][1]
        reserved.update([src["ACCT_NO"], dst["ACCT_NO"]])
        if i < 12:
            dst["_cls"] = "A"
            f["inter_pairs"].append((src, dst))
        else:
            f["same_pairs"].append((src, dst) if dst["REG_CD"] in ("TIRA", "RIRA", "ROLL", "SEP") or rng.random() < .5
                                   else (dst, src))
    utma = [a for a in accts if a["REG_CD"] in ("UTMA", "529") and a["ACCT_NO"] not in reserved]
    for a in utma:
        head = [c for c in f["customers"] if c["_hh"] is a["_hh"] and c["_contact"]["FinServ__PrimaryHouseholdRole__c"] == "Head"][0]
        free = [x for x in head.get("_accts", []) if x["ACCT_NO"] not in reserved]
        if free and len(f["gift_pairs"]) < 8:
            f["gift_pairs"].append((free[0], a))
            reserved.update([free[0]["ACCT_NO"], a["ACCT_NO"]])
    pool = [a for a in accts if a["ACCT_NO"] not in reserved]
    trust = rng.sample([a for a in pool if a["REG_CD"] == "IND" and a["_sec"] is None], 15)
    for i, a in enumerate(trust):
        a["_cls"], a["REG_CD"] = "T", "RTR" if i < 10 else "ITR"
    pool = [a for a in pool if a["_cls"] == "B" and a["REG_CD"] not in ("UTMA", "529")]
    for a in rng.sample(pool, 125 - 12):
        a["_cls"] = "A"
    for a in accts:
        if a["_cls"] == "T":
            a["_chan"], a["_prog"] = "TR", "TRS"
        elif a["_cls"] == "A":
            owned = bool(a["_hh"]["OwnerId"])
            a["_prog"] = rng.choice(["PAS", "PAS", "WMP", "DAP"]) if owned else rng.choice(["DAP", "DAP", "DAP", "PAS"])
            a["_chan"] = "DA" if a["_prog"] == "DAP" else "HA"
        else:
            a["_prog"] = ""
    f["reserved"] = reserved


def assign_statuses(rng, f):
    """30 closed (18 before the window, 12 inside it), 8 dormant, 2 pending, 20 opened in the window."""
    accts = f["accts"]
    for a in accts:
        a["_status"], a["_close"], a["_close_rsn"] = "O", None, ""
    pool = [a for a in accts if a["ACCT_NO"] not in f["reserved"]]
    rng.shuffle(pool)
    closed, dormant, pending, new = pool[:30], pool[30:38], pool[38:40], pool[40:60]
    for i, a in enumerate(closed):
        a["_status"] = "C"
        if i < 18:
            a["_close"] = date(2025, 1, 2) + timedelta(days=rng.randint(0, 520))
            a["_close_rsn"] = rng.choice(["FW", "AO", "RR", "SB"])
        else:
            a["_close"] = rng.choice(BDAYS[5:-3])
            a["_close_rsn"] = "AO" if i < 24 else "FW"
        a["_open"] = min(a["_open"], a["_close"] - timedelta(days=200))
    for a in dormant:
        a["_status"], a["_open"] = "D", date(rng.randint(2012, 2018), rng.randint(1, 12), rng.randint(1, 28))
    for a in pending:
        a["_status"], a["_open"] = "P", None
    for a in new:
        a["_open"] = rng.choice(BDAYS[:-10])
    f["new_accts"] = new
    open_b = [a for a in pool[60:] if a["_cls"] == "B"]
    f["margin"] = rng.sample([a for a in open_b if a["REG_CD"] in ("IND", "JTWROS", "TIC")], 30)
    f["options_accts"] = rng.sample(open_b, 12)
    f["unlinked_brk"] = rng.sample(open_b, 15)


def finish_accounts(rng, f):
    """Fill the ACCT_MASTER columns."""
    reg_title = {"TIRA": "TRAD IRA", "RIRA": "ROTH IRA", "ROLL": "ROLLOVER IRA", "SEP": "SEP IRA", "INHIRA": "INH IRA",
                 "529": "529 PLAN"}
    margin = {a["ACCT_NO"] for a in f["margin"]}
    for a in f["accts"]:
        p, s, h = a["_prim"], a["_sec"], a["_hh"]
        name = ("%s %s" % (p["FIRST_NM"], p["LAST_NM"])).upper()
        reg = a["REG_CD"]
        if s:
            title = "%s & %s %s %s" % (name, s["FIRST_NM"].upper(), s["LAST_NM"].upper(), reg)
        elif reg == "UTMA":
            title = "%s CUST %s UTMA" % (h["_members"][0]["FirstName"].upper() + " " + p["LAST_NM"].upper(), name)
        elif reg in ("RTR", "ITR"):
            title = "%s TTEE %s FAMILY %sTRUST" % (name, p["LAST_NM"].upper(), "REV " if reg == "RTR" else "")
        else:
            title = name + (" " + reg_title[reg] if reg in reg_title else "")
        owner = f["user_by_id"].get(h["OwnerId"]) or rng.choice(f["advisors"])
        a.update({"ACCT_TITLE": title, "ACCT_CLASS_CD": a["_cls"], "MARGIN_CD": "M" if a["ACCT_NO"] in margin else "C",
                  "STATUS_CD": a["_status"], "OPEN_DT": ymd(a["_open"]), "CLOSE_DT": ymd(a["_close"]),
                  "CLOSE_RSN_CD": a["_close_rsn"], "CHANNEL_CD": a["_chan"], "PROGRAM_CD": a["_prog"],
                  "ENROLL_DT": ymd(max(a["_open"], date(2020, 1, 2) + timedelta(days=rng.randint(0, 2400))))
                  if a["_prog"] and a["_open"] else "",
                  "ENROLL_STATUS_CD": "A" if a["_prog"] else "",
                  "PURPOSE_CD": "RET" if reg in reg_title and reg != "529" else ("EDU" if reg in ("529", "UTMA") else
                                ("EST" if reg in ("RTR", "ITR") else rng.choice(["GEN", "GEN", "GEN", "CSH"]))),
                  "BRANCH_CD": owner["Branch__c"], "REP_CD": owner["Rep_Code__c"], "PRIM_CUST_NO": p["CUST_NO"],
                  "SEC_CUST_NO": s["CUST_NO"] if s else "", "CARRY_ENT_CD": "TC" if a["_cls"] == "T" else "BD"})
    f["acct_by_no"] = {a["ACCT_NO"]: a for a in f["accts"]}


# ---------------------------------------------------------------------------------------------------------------------
# Transfer agent accounts

def build_ta_accounts(rng, f):
    """300 direct accounts, the affiliated omnibus, 3 third-party omnibus, 1 plan omnibus and 20 networked accounts."""
    rows, n = [], [0]
    def add(soc, typ, reg1, reg2, dealer, level, estab, **meta):
        n[0] += 1
        r = {"ACCT_NO": "77%08d" % (410000 + n[0] * 29), "SOC_CD": soc, "ACCT_TYPE_CD": typ, "REG_LINE_1": reg1,
             "REG_LINE_2": reg2, "TAX_ID_LAST4": "%04d" % rng.randint(0, 9999), "DEALER_NO": dealer,
             "BRANCH_NO": "" if dealer == "0010" else "%03d" % rng.randint(1, 400),
             "REP_NO": "" if dealer == "0010" else "%05d" % rng.randint(1, 99999), "NSCC_LEVEL": level,
             "ESTAB_DT": ymd(estab), "CLOSE_DT": "", "STATUS_CD": "A", "DIV_OPT_CD": "R" if rng.random() < .8 else "C",
             "IRA_TYPE_CD": "", "_kind": "TA_DIRECT" if typ == "I" else "TA_INT"}
        r.update(meta)
        rows.append(r)
        return r
    ta_only = [h for h in f["households"] if not h["_has_brk"]]
    owners = []
    for h in ta_only:
        owners += [h] * rng.choice([1, 2])
    while len(owners) < 300:
        owners.append(rng.choice(f["households"]))
    for h in owners[:300]:
        adults = [c for c in h["_members"] if c["FinServ__PrimaryHouseholdRole__c"] != "Dependent"
                  and c["Status__c"] != "Merged"]
        c = rng.choice(adults)
        spouse = [x for x in adults if x is not c]
        r = rng.random()
        soc = "2" if spouse and r < 0.15 else ("5" if r < 0.25 else ("7" if r < 0.45 else "1"))
        name = ("%s %s" % (c["FirstName"], c["LastName"])).upper()
        reg2 = {"2": ("%s %s JTWROS" % (spouse[0]["FirstName"], spouse[0]["LastName"])).upper() if spouse else "",
                "5": "TTEE %s FAMILY TRUST" % c["LastName"].upper(), "7": "FIRM FUNDS TRUST CO CUST IRA", "1": ""}[soc]
        t = add(soc, "I", name, reg2, "0010", "", date(rng.randint(2008, 2025), rng.randint(1, 12), rng.randint(1, 28)),
                _hh=h, _owner=c, _joint=spouse[0] if soc == "2" else None)
        if soc == "7":
            t["IRA_TYPE_CD"] = rng.choice("TTRSI")
    direct = list(rows)
    for t in rng.sample(direct, 5):
        t["STATUS_CD"], t["_zero"] = "Z", True
    f["affiliated"] = add("9", "O", "THE FIRM BROKERAGE SERVICES LLC", "OMNIBUS FBO CUSTOMERS", "0010", "", date(2009, 4, 1))
    tp = [add("9", "O", nm, "OMNIBUS FBO CUSTOMERS", d, "", date(2014 + i, 3, 2))
          for i, (d, nm) in enumerate([("0421", "MERIDIAN WIREHOUSE SECURITIES"), ("0877", "HARBORVIEW RIA CUSTODY"),
                                       ("1203", "FIRST PRAIRIE BANK BROKERAGE")])]
    plan = add("9", "P", "SUMMIT PLAN RECORDKEEPING", "FBO PARTICIPATING PLANS", "2290", "", date(2017, 7, 1))
    networked = [add(rng.choice("127"), "N", ("%s %s" % (rng.choice(FIRST), rng.choice(LAST))).upper(), "",
                     rng.choice(["0421", "0877"]), "3", date(rng.randint(2015, 2025), rng.randint(1, 12), 5))
                 for _ in range(20)]
    for r in tp + [plan] + networked:
        r["DIV_OPT_CD"] = "R"
    f["affiliated"]["_kind"] = "TA_AFFILIATED"
    f["ta_accts"], f["ta_direct"], f["ta_intermediary"] = rows, direct, tp + [plan] + networked
    f["ta_by_no"] = {t["ACCT_NO"]: t for t in rows}
    f["unlinked_ta"] = rng.sample([t for t in direct if not t.get("_zero")], 6)


# ---------------------------------------------------------------------------------------------------------------------
# CRM financial accounts and roles

def build_financial_accounts(rng, f):
    """One financial account per brokerage account (less 15) and per direct fund account (less 6), roles, held-away."""
    fas, roles, n, rn = [], [], [0], [0]
    btype = {"TIRA": "IRA", "RIRA": "IRA", "ROLL": "IRA", "SEP": "IRA", "INHIRA": "IRA", "529": "529"}
    bl = {"SD": "DB", "DA": "DA", "HA": "HA", "TR": "PT"}
    ch = {"SD": "SelfDirected", "DA": "DigitalAdvice", "HA": "HumanAdvice", "TR": "Trust"}
    def role(fa, contact, name, start, active=True):
        rn[0] += 1
        roles.append({"Id": sfid("a0C", rn[0]), "FinServ__FinancialAccount__c": fa["Id"],
                      "FinServ__RelatedContact__c": contact["Id"], "FinServ__Role__c": name,
                      "FinServ__StartDate__c": iso(start), "FinServ__EndDate__c": "" if active else iso(date(2026, 3, 31)),
                      "FinServ__Active__c": "true" if active else "false"})
    def fa(name, number, source, typ, prim, joint, hh, status, opened, program="", line="", channel="", away=None):
        n[0] += 1
        r = {"Id": sfid("a0B", n[0]), "Name": name, "FinServ__FinancialAccountNumber__c": number,
             "Source_System__c": source, "FinServ__FinancialAccountType__c": typ, "FinServ__PrimaryOwner__c": prim["Id"],
             "FinServ__JointOwner__c": joint["Id"] if joint else "", "FinServ__Household__c": hh["Id"],
             "FinServ__Status__c": status, "FinServ__OpenDate__c": iso(opened), "Program__c": program,
             "Business_Line__c": line, "Channel__c": channel, "Held_Away__c": "true" if away is not None else "false",
             "Held_Away_Value__c": amt(away) if away is not None else ""}
        fas.append(r)
        role(r, prim, "Primary Owner", opened or date(2026, 7, 1))
        if joint:
            role(r, joint, "Joint Owner", opened or date(2026, 7, 1))
        return r
    unlinked = {a["ACCT_NO"] for a in f["unlinked_brk"]}
    for a in f["accts"]:
        a["_fa"] = None
        if a["ACCT_NO"] in unlinked:
            continue
        typ = "Trust" if a["_cls"] == "T" else btype.get(a["REG_CD"], "Advisory" if a["_cls"] == "A" else "Brokerage")
        status = {"O": "Open", "D": "Open", "C": "Closed", "P": "Pending"}[a["_status"]]
        a["_fa"] = fa(a["ACCT_TITLE"].title(), a["ACCT_NO"], "BRK", typ, a["_prim"]["_contact"],
                      a["_sec"]["_contact"] if a["_sec"] else None, a["_hh"], status, a["_open"], a["_prog"],
                      bl[a["_chan"]], ch[a["_chan"]])
    unlinked_ta = {t["ACCT_NO"] for t in f["unlinked_ta"]}
    for t in f["ta_direct"]:
        t["_fa"] = None
        if t["ACCT_NO"] in unlinked_ta:
            continue
        typ = {"7": "IRA", "5": "Trust"}.get(t["SOC_CD"], "MutualFund")
        t["_fa"] = fa(t["REG_LINE_1"].title() + " Fund Account", t["ACCT_NO"], "TA", typ, t["_owner"], t["_joint"],
                      t["_hh"], "Closed" if t.get("_zero") else "Open",
                      date(int(t["ESTAB_DT"][:4]), int(t["ESTAB_DT"][4:6]), int(t["ESTAB_DT"][6:])), "", "PF",
                      "TransferAgentDirect")
    for h in rng.sample(f["households"], 30):
        c = h["_members"][0]
        fa("Held Away - " + rng.choice(["Workplace 401(k)", "Outside Brokerage", "Bank Savings", "Annuity"]), "", "",
           rng.choice(["Brokerage", "IRA", "Advisory"]), c, None, h, "Open", date(2024, 1, 2) + timedelta(days=rng.randint(0, 600)),
           away=lognormal_cents(rng, 180000, 0.9))
    adults = [c for h in f["households"] for c in h["_members"] if c["FinServ__PrimaryHouseholdRole__c"] != "Dependent"
              and c["Status__c"] != "Merged"]
    trusted = [c for c in f["contacts"] if c["FinServ__Status__c"] == "Related Party"]
    linked = [x for x in fas if x["Source_System__c"]]
    for x in rng.sample(linked, 40):
        role(x, rng.choice(trusted + adults), "Power of Attorney", date(2023, 1, 2) + timedelta(days=rng.randint(0, 900)))
    trust_fas = [x for x in linked if x["FinServ__FinancialAccountType__c"] == "Trust"]
    for i, x in enumerate((trust_fas * 2)[:25]):       # the grantor as trustee, then a co-trustee
        who = f["contact_by_id"][x["FinServ__PrimaryOwner__c"]] if i < len(trust_fas) else rng.choice(adults)
        role(x, who, "Trustee", date(2022, 6, 1) + timedelta(days=rng.randint(0, 900)))
    f["fas"], f["fa_roles"] = fas, roles


def build_consents_and_trusted(rng, f):
    """About 1,500 consents and 400 trusted-contact designations."""
    members = [c for h in f["households"] for c in h["_members"] if c["Status__c"] != "Merged"]
    adults = [c for c in members if c["FinServ__PrimaryHouseholdRole__c"] != "Dependent"]
    trusted = [c for c in f["contacts"] if c["FinServ__Status__c"] == "Related Party"]
    consents = []
    for i in range(1500):
        status = rng.choice(["Granted"] * 7 + ["Withdrawn", "Expired", "Declined"])
        captured = date(2020, 1, 2) + timedelta(days=rng.randint(0, 2400))
        consents.append({"Id": sfid("a0D", i + 1), "Contact__c": rng.choice(adults)["Id"],
                         "Purpose__c": rng.choice(["eDelivery", "eDelivery", "MarketingEmail", "MarketingSMS",
                                                   "CallRecording", "DataSharing"]), "Status__c": status,
                         "Capture_Method__c": rng.choice(["WebSingle", "WebDouble", "Mobile", "ESign", "Verbal", "Paper"]),
                         "Captured_Date__c": iso(captured),
                         "Expiry_Date__c": iso(captured + timedelta(days=730)) if status == "Expired" else "",
                         "Withdrawn_Timestamp__c": stamp(captured + timedelta(days=rng.randint(30, 300)), rng)
                         if status == "Withdrawn" else ""})
    tcs = []
    for i, c in enumerate(rng.sample(adults, 400)):
        status = rng.choice(["Provided"] * 8 + ["Declined", "Requested"])
        start = date(2021, 1, 4) + timedelta(days=rng.randint(0, 1800))
        tcs.append({"Id": sfid("a0E", i + 1), "Client__c": c["Id"],
                    "Trusted_Person__c": rng.choice(trusted)["Id"] if status == "Provided" else "",
                    "Status__c": status, "Effective_From__c": iso(start), "Effective_To__c": ""})
    f["consents"], f["trusted"] = consents, tcs


# ---------------------------------------------------------------------------------------------------------------------
# Month-end positions and balances

def holding_months(a):
    """Indexes of the month-ends at which a brokerage account holds anything."""
    if a["_status"] == "P":
        return []
    return [i for i, me in enumerate(MONTH_ENDS) if a["_open"] <= me and (a["_close"] is None or a["_close"] > me)]


def drift(rng, milli):
    """Next month's quantity: unchanged most months, otherwise a small trade-driven change."""
    if rng.random() < 0.7:
        return milli
    return max(1, int(milli * (1 + rng.uniform(-0.05, 0.05))))


def build_positions(rng, f, secs):
    """Brokerage positions (2 to 8 per account per month-end, 45 percent of value in own funds), options and cash."""
    own = [s for s in secs if s["FUND_FAMILY_CD"] == "OWN"]
    tp = {t: [s for s in secs if s["SEC_TYPE_CD"] == t and s["FUND_FAMILY_CD"] != "OWN"]
          for t in ("EQ", "ETF", "MF", "FI", "CD", "UIT", "MMF", "OPT")}
    tp_weights = [("EQ", 55), ("ETF", 20), ("MF", 12), ("FI", 7), ("CD", 3), ("UIT", 1.5), ("MMF", 1.5)]
    big = rng.sample(f["households"], 9)
    for i, h in enumerate(big):
        h["_mult"] = 45 if i < 3 else 12
    positions, cash = [], []
    options = {a["ACCT_NO"]: (3 if i == 0 else 2) for i, a in enumerate(f["options_accts"])}
    margin = {a["ACCT_NO"] for a in f["margin"]}
    for a in f["accts"]:
        months = holding_months(a)
        a["_holdings"] = {}
        if not months:
            continue
        reg = a["REG_CD"]
        median = {"UTMA": 25000, "529": 30000, "RTR": 1200000, "ITR": 1500000}.get(reg, 150000 if reg in
                  ("TIRA", "RIRA", "ROLL", "SEP", "INHIRA") else 110000)
        target = lognormal_cents(rng, median, 0.9 if a["_status"] != "D" else 0.5) * a["_hh"].get("_mult", 1)
        if a["_status"] == "D":
            target //= 20
        k = rng.randint(2, 8)
        n_own = min(k - 1, max(1, round(k * 0.45)))
        w_own = rng.uniform(0.35, 0.55)
        picks = [(s, w_own / n_own) for s in rng.sample(own, n_own)]
        chosen = set()
        while len(picks) < k:
            t = rng.choices([t for t, _ in tp_weights], [w for _, w in tp_weights])[0]
            s = rng.choice(tp[t])
            if s["CUSIP"] not in chosen:
                chosen.add(s["CUSIP"])
                picks.append((s, (1 - w_own) / (k - n_own)))
        first = months[0]
        for s, w in picks:
            whole = s["SEC_TYPE_CD"] in ("EQ", "ETF", "CD", "FI")
            a["_holdings"][s["CUSIP"]] = [shares_for(int(target * w * rng.uniform(0.6, 1.4)), s["_prices"][first], whole)]
        for s in rng.sample(tp["OPT"], options.get(a["ACCT_NO"], 0)):
            a["_holdings"][s["CUSIP"]] = [rng.randint(1, 10) * 1000]
        for cusip, path in a["_holdings"].items():
            for _ in months[1:]:
                path.append(path[-1] if f["sec_by_cusip"][cusip]["SEC_TYPE_CD"] in ("OPT", "EQ", "FI", "CD")
                            and rng.random() < 0.85 else drift(rng, path[-1]))
        fcb0, swp0 = int(target * rng.uniform(0.003, 0.02)), int(target * rng.uniform(0.01, 0.06))
        sweep = "BDP" if rng.random() < 0.8 else "MMF"
        trade_basis = rng.random() < 0.2
        mdb0 = -int(target * rng.uniform(0.05, 0.2)) if a["ACCT_NO"] in margin else 0
        for j, m in enumerate(months):
            for cusip, path in a["_holdings"].items():
                s = f["sec_by_cusip"][cusip]
                q, p = path[j], s["_prices"][m]
                mv = value_of(q, p, s["_mult"])
                cost = int(mv * rng.uniform(0.7, 1.1)) if s["SEC_TYPE_CD"] != "MMF" else mv
                positions.append({"ASOF_DT": ymd(MONTH_ENDS[m]), "ACCT_NO": a["ACCT_NO"], "CUSIP": cusip, "QTY_TD": qty(q),
                                  "QTY_SD": qty(q), "PRICE": amt(p), "MKT_VAL": amt(mv), "COST_BASIS": amt(cost),
                                  "ACCRUED_INT": amt(mv * 4 // 1000 if s["SEC_TYPE_CD"] in ("FI", "CD") else 0),
                                  "_m": m, "_mv": mv, "_q": q, "_sec": s, "_acct": a})
            bals = [("FCB", int(fcb0 * rng.uniform(0.8, 1.2)), ""), ("SWP", int(swp0 * rng.uniform(0.8, 1.2)), sweep)]
            if mdb0:
                bals.append(("MDB", int(mdb0 * rng.uniform(0.8, 1.2)), ""))
            for typ, c, pgm in bals:
                for basis in (["S", "T"] if trade_basis else ["S"]):
                    cash.append({"ASOF_DT": ymd(MONTH_ENDS[m]), "ACCT_NO": a["ACCT_NO"], "CCY": "USD", "BAL_TYPE_CD": typ,
                                 "BAL_BASIS_CD": basis, "BAL_AMT": amt(c), "SWEEP_PGM_CD": pgm,
                                 "_m": m, "_c": c, "_acct": a})
    f["positions"], f["cash"] = positions, cash
    NOTES.append("Brokerage MKT_VAL is QTY_SD x PRICE (x 100 for options), rounded to the cent; QTY_TD equals QTY_SD.")


def build_register_positions(rng, f):
    """Fund-register positions: direct and intermediary holdings, and the affiliated omnibus mirroring brokerage."""
    funds = f["funds"]
    oef = [x for x in funds if x["VEHICLE_CD"] == "OEF"]
    oef_nonmm = [x for x in oef if x["ASSET_CLS_CD"] != "MM"]
    rows = []
    def price(fund, m):
        return f["sec_by_cusip"][fund["CUSIP"]]["_prices"][m]
    def hold(t, picks):
        t["_holdings"] = {}
        for fund, cents in picks:
            path = [shares_for(cents, price(fund, 0))]
            for _ in range(3):
                path.append(drift(rng, path[-1]))
            t["_holdings"][fund["FUND_NO"]] = path
        for m in range(4):
            for fno, path in t["_holdings"].items():
                nav = price(f["fund_by_no"][fno], m)
                mv = value_of(path[m], nav)
                rows.append({"ASOF_DT": ymd(MONTH_ENDS[m]), "ACCT_NO": t["ACCT_NO"], "FUND_NO": fno,
                             "SHARES": qty(path[m]), "SHARES_UNCOLL": "0.000", "SHARES_ESCROW": "0.000", "NAV": amt(nav),
                             "MKT_VAL": amt(mv), "_m": m, "_mv": mv, "_acct": t, "_fund": f["fund_by_no"][fno]})
    for t in f["ta_direct"]:
        if t.get("_zero"):
            t["_holdings"] = {}
            continue
        k = rng.choice([1, 1, 2, 2, 3])
        picks = rng.sample(oef, k)
        hold(t, [(x, lognormal_cents(rng, 40000, 0.9) * t["_hh"].get("_mult", 1) // k) for x in picks])
    for t in f["ta_intermediary"]:
        if t["ACCT_TYPE_CD"] == "O":
            hold(t, [(x, rng.randint(300_000, 4_000_000) * 100) for x in rng.sample(oef_nonmm, rng.randint(8, 14))])
        elif t["ACCT_TYPE_CD"] == "P":
            hold(t, [(x, rng.randint(1_000_000, 5_000_000) * 100) for x in rng.sample(
                [x for x in oef_nonmm if x["CLASS_CD"] == "ADM"], 6)])
        else:
            hold(t, [(x, rng.randint(30_000, 600_000) * 100) for x in rng.sample(oef_nonmm, rng.randint(1, 3))])
    # The affiliated omnibus: for every own fund number and month-end, the sum of brokerage settled quantities and values
    agg = {}
    for p in f["positions"]:
        if p["_sec"]["FUND_FAMILY_CD"] == "OWN":
            key = (p["_m"], p["_sec"]["TA_FUND_NO"])
            q, v = agg.get(key, (0, 0))
            agg[key] = (q + p["_q"], v + p["_mv"])
    om = f["affiliated"]
    for m in range(4):
        for fund in funds:
            q, v = agg.get((m, fund["FUND_NO"]), (0, 0))
            rows.append({"ASOF_DT": ymd(MONTH_ENDS[m]), "ACCT_NO": om["ACCT_NO"], "FUND_NO": fund["FUND_NO"],
                         "SHARES": qty(q), "SHARES_UNCOLL": "0.000", "SHARES_ESCROW": "0.000", "NAV": amt(price(fund, m)),
                         "MKT_VAL": amt(v), "_m": m, "_mv": v, "_acct": om, "_fund": fund})
    NOTES.append("Affiliated omnibus POSITION rows are written for every own fund number at every month-end (zero "
                 "where no brokerage account holds the class); MKT_VAL is the sum of the brokerage MKT_VAL values, so "
                 "the equality is exact to the cent.")
    f["ta_positions"] = rows


# ---------------------------------------------------------------------------------------------------------------------
# Brokerage activity and the register transactions

def build_activity(rng, f):
    """About 7,000 brokerage activity rows and the matching omnibus register trades."""
    rows, seq = [], [0]
    f["omnibus_trades"] = []
    def txn(a, cd, d, net, sec=None, q=None, price=None, status="P", contra="", firm="", xfer="", desc=""):
        seq[0] += 1
        r = {"TXN_ID": "T%s%08d" % (d.strftime("%y%m%d"), 18000 + seq[0] * 7), "ACCT_NO": a["ACCT_NO"], "TXN_CD": cd,
             "TRD_DT": ymd(d), "SETL_DT": ymd(next_bday(d) if sec else d), "ENTRY_DT": ymd(d),
             "CUSIP": sec["CUSIP"] if sec else "", "QTY": qty(q), "PRICE": amt(price), "NET_AMT": amt(net), "CCY": "USD",
             "STATUS_CD": status, "REVERSAL_OF_TXN_ID": "", "CONTRA_ACCT_NO": contra, "CONTRA_FIRM_CD": firm,
             "XFER_TYPE_CD": xfer, "TXN_DESC": desc or cd, "_acct": a, "_sec": sec, "_net": net, "_d": d}
        rows.append(r)
        if cd in ("FBUY", "FRED") and sec and sec["FUND_FAMILY_CD"] == "OWN" and status == "P":
            f["omnibus_trades"].append((r, "001" if cd == "FBUY" else "002", abs(q), abs(net)))
        return r
    def days_in(a, m):
        return [d for d in BDAYS if d.month == m + 6 and (a["_open"] <= d) and (a["_close"] is None or d < a["_close"])]
    def value_at(a, m):
        mv = sum(value_of(p[min(m, len(p) - 1)], f["sec_by_cusip"][c]["_prices"][m], f["sec_by_cusip"][c]["_mult"])
                 for c, p in a["_holdings"].items())
        return mv
    active = [a for a in f["accts"] if a["_status"] in ("O", "C") and a["_open"] and a["_open"] <= WINDOW_END
              and (a["_close"] is None or a["_close"] > WINDOW_START)]
    for a in active:
        held = list(a["_holdings"])
        for m in (1, 2, 3):
            days = days_in(a, m)
            if not days or not held:
                continue
            for _ in range(rng.choice([0, 0, 1, 1, 2, 3])):
                s = f["sec_by_cusip"][rng.choice(held)]
                if s["SEC_TYPE_CD"] == "OPT":
                    continue
                fund = s["SEC_TYPE_CD"] in ("MF", "MMF")
                buy = rng.random() < 0.55
                p = s["_prices"][m]
                q = shares_for(rng.randint(500, 25000) * 100, p, not fund)
                net = value_of(q, p, s["_mult"])
                cd = ("FBUY" if buy else "FRED") if fund else ("BUY" if buy else "SEL")
                txn(a, cd, rng.choice(days), -net if buy else net, s, q if buy else -q, p,
                    desc="%s %s %s @ %s" % (cd, qty(q), s["SYMBOL"], amt(p)))
            for c in held:
                s = f["sec_by_cusip"][c]
                if s["SEC_TYPE_CD"] in ("EQ", "ETF", "MF", "UIT") and rng.random() < 0.3:
                    mv = value_of(a["_holdings"][c][0], s["_prices"][m], s["_mult"])
                    if mv * 25 // 10000 > 0:
                        txn(a, "DIV", rng.choice(days), mv * rng.randint(10, 40) // 10000, s, desc="DIVIDEND " + s["SYMBOL"])
                if s["SEC_TYPE_CD"] == "MF" and rng.random() < 0.05:
                    mv = value_of(a["_holdings"][c][0], s["_prices"][m])
                    if mv // 100 > 0:
                        txn(a, "CGD", rng.choice(days), mv // 100, s, desc="CAP GAIN DIST " + s["SYMBOL"])
            if rng.random() < 0.9:
                txn(a, "INT", days[-1], rng.randint(50, 9000), desc="CREDIT INTEREST")
            if rng.random() < 0.3:
                txn(a, "DEP", rng.choice(days), lognormal_cents(rng, 4000, 1.0), desc="ACH DEPOSIT")
            if rng.random() < 0.18:
                txn(a, "WDL", rng.choice(days), -lognormal_cents(rng, 3000, 1.0), desc="ACH WITHDRAWAL")
            if m == 1 and a["_cls"] in ("A", "T"):
                fee = value_at(a, 0 if a["_open"] <= MONTH_ENDS[0] else 1) * 25 // 10000
                if fee:
                    txn(a, "FEE", days[min(9, len(days) - 1)], -fee, desc="ADVISORY FEE Q3 2026")
    firms = ["0141", "0188", "0221", "0352", "0443", "0505", "0636", "0725"]
    eq = [s for s in f["sec_by_cusip"].values() if s["SEC_TYPE_CD"] in ("EQ", "ETF") and s["FUND_FAMILY_CD"] != "OWN"]
    steady = [a for a in active if a["_close"] is None and a["_open"] < WINDOW_START and a["ACCT_NO"] not in f["reserved"]]
    # New accounts funded on their open date: 12 by ACATS, 8 by deposit
    n_acati = 0
    for i, a in enumerate(f["new_accts"]):
        v = value_at(a, month_index(a["_open"])) or lognormal_cents(rng, 50000, 0.5)
        if i < 12:
            txn(a, "ACATI", a["_open"], v, firm=rng.choice(firms), xfer="ACATS", desc="ACATS TRANSFER IN")
            n_acati += 1
        else:
            txn(a, "DEP", a["_open"], v, desc="WIRE DEPOSIT")
    for a in rng.sample(steady, 40 - n_acati):
        s = rng.choice(eq)
        m = rng.choice([1, 2, 3])
        q = rng.randint(20, 600) * 1000
        txn(a, "ACATI", rng.choice([d for d in BDAYS if d.month == m + 6]), value_of(q, s["_prices"][m]), s, q,
            s["_prices"][m], firm=rng.choice(firms), xfer="ACATS", desc="ACATS RECEIVE " + s["SYMBOL"])
    # Closures inside the window: 6 by ACATS out, 6 by full withdrawal
    closing = [a for a in f["accts"] if a["_close"] and a["_close"] >= WINDOW_START]
    n_acato = 0
    for a in closing:
        v = value_at(a, month_index(a["_close"]) - 1)
        if a["_close_rsn"] == "AO":
            txn(a, "ACATO", a["_close"], -v, firm=rng.choice(firms), xfer="ACATS", desc="ACATS TRANSFER OUT FULL")
            n_acato += 1
        else:
            txn(a, "WDL", a["_close"], -v, desc="CLOSING WITHDRAWAL")
    for a in rng.sample(steady, 12 - n_acato):
        txn(a, "ACATO", rng.choice(BDAYS), -lognormal_cents(rng, 30000, 0.8), firm=rng.choice(firms), xfer="ACATS",
            desc="ACATS TRANSFER OUT PARTIAL")
    for a in rng.sample(steady, 10):
        s, m = rng.choice(eq), rng.choice([1, 2, 3])
        q = rng.randint(10, 300) * 1000
        txn(a, "XFRI", rng.choice([d for d in BDAYS if d.month == m + 6]), value_of(q, s["_prices"][m]), s, q,
            s["_prices"][m], firm=rng.choice(firms), xfer="NONACATS", desc="RECEIVE VERSUS FREE " + s["SYMBOL"])
    iras = [a for a in steady if a["REG_CD"] in ("TIRA", "ROLL")]
    for a in rng.sample(iras, 6):
        txn(a, "ROLLI", rng.choice(BDAYS), lognormal_cents(rng, 90000, 0.7), firm=rng.choice(firms), xfer="ROLLOVER",
            desc="401K ROLLOVER IN")
    # Journals: 30 same-customer pairs (12 self-directed to managed advisory) and 8 gift pairs between customers
    for src, dst in f["inter_pairs"] + f["same_pairs"] + f["gift_pairs"]:
        d, x = rng.choice(BDAYS), lognormal_cents(rng, 15000, 0.8)
        txn(src, "JNL", d, -x, contra=dst["ACCT_NO"], xfer="INTRAFIRM", desc="JOURNAL TO " + dst["ACCT_NO"])
        txn(dst, "JNL", d, x, contra=src["ACCT_NO"], xfer="INTRAFIRM", desc="JOURNAL FROM " + src["ACCT_NO"])
    NOTES.append("Journals are pairs: 30 same-customer pairs (60 rows; 12 self-directed to managed advisory, 18 within "
                 "one channel) and 8 gift pairs between different customers (16 rows), each row with its contra row.")
    # 25 reversals of posted deposits and withdrawals, then 60 pending rows at the end of September
    candidates = [r for r in rows if r["TXN_CD"] in ("DEP", "WDL") and r["TXN_DESC"].startswith("ACH")]
    for orig in rng.sample(candidates, 25):
        seq[0] += 1
        rev = dict(orig)
        rev.update({"TXN_ID": "T%s%08d" % (orig["_d"].strftime("%y%m%d"), 18000 + seq[0] * 7), "STATUS_CD": "R",
                    "REVERSAL_OF_TXN_ID": orig["TXN_ID"], "ENTRY_DT": ymd(next_bday(orig["_d"])),
                    "TXN_DESC": "REVERSAL " + orig["TXN_DESC"]})
        rows.append(rev)
    NOTES.append("A reversal row (STATUS_CD R) repeats the reversed row's trade date and NET_AMT (same sign) and points "
                 "at it through REVERSAL_OF_TXN_ID; the reversed row stays STATUS_CD P.")
    for _ in range(60):
        a = rng.choice(steady)
        d = rng.choice(BDAYS[-3:])
        cd = rng.choice(["DEP", "DEP", "WDL", "BUY", "SEL"])
        if cd in ("BUY", "SEL"):
            s = rng.choice(eq)
            q = rng.randint(5, 200) * 1000
            v = value_of(q, s["_prices"][3])
            txn(a, cd, d, -v if cd == "BUY" else v, s, q if cd == "BUY" else -q, s["_prices"][3], status="N",
                desc="%s %s %s PENDING" % (cd, qty(q), s["SYMBOL"]))
        else:
            v = lognormal_cents(rng, 5000, 0.8)
            txn(a, cd, d, v if cd == "DEP" else -v, status="N", desc="ACH %s PENDING" % cd)
    rows.sort(key=lambda r: (r["TRD_DT"], r["TXN_ID"]))
    f["activity"] = rows


def build_register_transactions(rng, f):
    """About 2,500 direct-account register transactions, intermediary trades and the omnibus mirror of brokerage."""
    rows, seq = [], [0]
    def tx(t, fund, cd, d, cents, src, status="P", reversal_of=""):
        seq[0] += 1
        nav = f["sec_by_cusip"][fund["CUSIP"]]["_prices"][month_index(d)]
        r = {"CONFIRM_NO": "%s%08d" % (d.strftime("%y%m%d"), 1170000 + seq[0] * 11), "ACCT_NO": t["ACCT_NO"],
             "FUND_NO": fund["FUND_NO"], "TRAN_CD": cd, "TRADE_DT": ymd(d), "SETL_DT": ymd(next_bday(d)),
             "POST_DT": ymd(d), "SHARES": qty(shares_for(cents, nav)), "NAV_APPLIED": amt(nav), "GROSS_AMT": amt(cents),
             "NET_AMT": amt(cents), "SOURCE_CD": src, "STATUS_CD": status, "REVERSAL_OF": reversal_of,
             "DEALER_NO": t["DEALER_NO"], "REP_NO": t["REP_NO"], "_acct": t, "_fund": fund, "_net": cents, "_d": d,
             "_brk": None}
        rows.append(r)
        return r
    oef = [x for x in f["funds"] if x["VEHICLE_CD"] == "OEF"]
    live = [t for t in f["ta_direct"] if not t.get("_zero")]
    for t in live:
        for m in (1, 2, 3):
            days = [d for d in BDAYS if d.month == m + 6]
            for fno, path in t["_holdings"].items():
                fund = f["fund_by_no"][fno]
                v = value_of(path[m], f["sec_by_cusip"][fund["CUSIP"]]["_prices"][m])
                income = max(100, v * rng.randint(8, 30) // 10000)
                tx(t, fund, "101" if t["DIV_OPT_CD"] == "R" else "111", days[-1], income, "DR")
                if m == 3 and rng.random() < 0.15:
                    tx(t, fund, "102", days[-2], max(100, v // 150), "DR")
            fund = f["fund_by_no"][rng.choice(list(t["_holdings"]))]
            if rng.random() < 0.5:
                tx(t, fund, "001", rng.choice(days), lognormal_cents(rng, 1500, 0.9), rng.choice(["DR", "DR", "FS"]))
            if rng.random() < 0.15:
                tx(t, fund, "002", rng.choice(days), lognormal_cents(rng, 4000, 0.9), "DR")
            if rng.random() < 0.06:
                d, x = rng.choice(days), lognormal_cents(rng, 5000, 0.8)
                tx(t, fund, "052", d, x, "DR")
                tx(t, rng.choice([o for o in oef if o is not fund]), "051", d, x, "DR")
    for t in rng.sample(live, 10):
        tx(t, f["fund_by_no"][rng.choice(list(t["_holdings"]))], "071", rng.choice(BDAYS), lognormal_cents(rng, 25000, 0.8), "DR")
    for t in rng.sample(live, 6):
        tx(t, f["fund_by_no"][rng.choice(list(t["_holdings"]))], "072", rng.choice(BDAYS), lognormal_cents(rng, 20000, 0.8), "DR")
    for t in f["ta_intermediary"]:
        n = {"O": (6, 10), "P": (5, 8), "N": (0, 2)}[t["ACCT_TYPE_CD"]]
        size = 30000 if t["ACCT_TYPE_CD"] == "N" else 150000
        src = "RK" if t["ACCT_TYPE_CD"] == "P" else "FS"
        for m in (1, 2, 3):
            days = [d for d in BDAYS if d.month == m + 6]
            for _ in range(rng.randint(*n)):
                fund = f["fund_by_no"][rng.choice(list(t["_holdings"]))]
                tx(t, fund, "001" if rng.random() < 0.55 else "002", rng.choice(days), lognormal_cents(rng, size, 0.8), src)
    originals = [r for r in rows if r["TRAN_CD"] in ("001", "002") and r["_acct"]["_kind"] == "TA_DIRECT"]
    for orig in rng.sample(originals, 20):
        rev = tx(orig["_acct"], orig["_fund"], orig["TRAN_CD"], orig["_d"], orig["_net"], orig["SOURCE_CD"], "R",
                 orig["CONFIRM_NO"])
        rev["POST_DT"] = ymd(next_bday(orig["_d"]))
    om = f["affiliated"]
    for brk, cd, q, cents in f["omnibus_trades"]:
        fund = f["fund_by_no"][brk["_sec"]["TA_FUND_NO"]]
        r = tx(om, fund, cd, brk["_d"], cents, "OM")
        r["SHARES"], r["NAV_APPLIED"], r["_brk"] = qty(q), amt(brk["_sec"]["_prices"][month_index(brk["_d"])]), brk
    rows.sort(key=lambda r: (r["TRADE_DT"], r["CONFIRM_NO"]))
    f["ta_txns"] = rows


# ---------------------------------------------------------------------------------------------------------------------
# The institutional business: SRC-INST (clients, relationships, mandates, health scores, fund accounts, consultants),
# SRC-PAB (portfolios, valuations, holdings) and the direct institutional accounts on the fund register. Built with its
# own random generator, after everything else, so the wealth business's extracts and figures are unchanged.

INST_PRODUCTS = ["P0001", "P0002", "P0003", "P0005", "P0006", "P0007", "P0011", "P0013", "P0015", "P0017"]
ENTITY_KIND = {"PPP": "PLAN", "CDB": "PLAN", "CDC": "PLAN", "TH": "PLAN", "END": "NPO", "FND": "NPO", "HLTH": "NPO",
               "INS": "CORP", "GOV": "GOV"}
# (type, short name, legal name, first relationship segment or None when terminated, has a consultant)
INST_CLIENTS = [
    ("PPP", "Cascadia PERS", "Cascadia Public Employees Retirement System", "SEP", True),
    ("PPP", "Lakeland STRS", "Lakeland State Teachers' Retirement System", "SEP", True),
    ("PPP", "Red River CERA", "Red River County Employees' Retirement Association", "SEP", True),
    ("PPP", "Bay Harbor Police and Fire", "City of Bay Harbor Police and Fire Pension Fund", "SEP", True),
    ("PPP", "Summit County RS", "Summit County Retirement System", "SEP", True),
    ("PPP", "Northfield MERF", "Northfield Municipal Employees' Retirement Fund", "SEP", True),
    ("PPP", "Pinecrest SERF", "Pinecrest State Employees' Retirement Fund", "SEP", False),
    ("PPP", "Highplains PSRS", "Highplains Public Safety Retirement System", "SEP", False),
    ("PPP", "Tidewater TPP", "Tidewater Teachers' Pension Plan", "OCIO", True),
    ("CDB", "Northwind Industries Pension", "Northwind Industries Inc. Pension Plan", "SEP", True),
    ("CDB", "Copperline Energy Pension", "Copperline Energy Corporation Retirement Plan", "SEP", True),
    ("CDB", "Ironwood Materials Pension", "Ironwood Materials Company Pension Plan", "SEP", True),
    ("CDB", "Stonebridge Logistics Pension", "Stonebridge Logistics Inc. Defined Benefit Plan", "SEP", True),
    ("CDB", "Falconer Aerospace Pension", "Falconer Aerospace Corporation Pension Plan", "SEP", False),
    ("CDB", "Greystone Utilities Pension", "Greystone Utilities Company Retirement Plan", "OCIO", True),
    ("CDB", "Kestrel Semiconductor Pension", "Kestrel Semiconductor Inc. Pension Plan", "OCIO", False),
    ("CDB", "Oakridge Foods Pension", "Oakridge Foods Inc. Retirement Income Plan", None, True),
    ("CDC", "Bluegate Systems 401(k)", "Bluegate Systems Inc. 401(k) Savings Plan", "RK", True),
    ("CDC", "Harbor Networks 401(k)", "Harbor Networks Corporation 401(k) Plan", "RK", True),
    ("CDC", "Larkspur Retail 401(k)", "Larkspur Retail Group 401(k) Savings Plan", "RK", False),
    ("CDC", "Quarry Robotics 401(k)", "Quarry Robotics Inc. Retirement Savings Plan", "CIT", False),
    ("CDC", "Westfield Financial 401(k)", "Westfield Financial Corporation Thrift Plan", "SEP", True),
    ("END", "Westbrook University", "Trustees of Westbrook University", "SEP", True),
    ("END", "Ashford College", "Ashford College Endowment Fund", "SEP", True),
    ("END", "St. Aldric University", "St. Aldric University Endowment", "SEP", False),
    ("END", "Mercer Valley College", "Mercer Valley College Foundation Endowment", "SEP", False),
    ("END", "Halvorsen Institute", "Halvorsen Institute of Technology Endowment", "OCIO", True),
    ("END", "Brookline Academy", "Brookline Academy Endowment Trust", "OCIO", False),
    ("FND", "Larkspur Family Foundation", "The Larkspur Family Foundation", "SEP", True),
    ("FND", "Hollis Foundation", "Hollis Foundation for Children", "SEP", False),
    ("FND", "Calder Trust", "The Calder Charitable Trust", "OCIO", True),
    ("FND", "Ravenna Community Foundation", "Ravenna Community Foundation Inc.", "OCIO", False),
    ("FND", "Whitcombe Arts Foundation", "Whitcombe Arts Foundation", None, False),
    ("HLTH", "Riverton Health", "Riverton Health System", "SEP", True),
    ("HLTH", "Clearwater Regional Medical", "Clearwater Regional Medical Center", "SEP", True),
    ("HLTH", "Maplewood Health Partners", "Maplewood Health Partners Inc.", "OCIO", False),
    ("INS", "Granite Mutual Life", "Granite Mutual Life Insurance Company", "SEP", False),
    ("INS", "Brightwater Mutual", "Brightwater Mutual Insurance Company", "SEP", False),
    ("TH", "Lakemont Building Trades", "Lakemont Building Trades Pension Trust Fund", "SEP", True),
    ("GOV", "Port of Westfield Pool", "Port of Westfield Long-Term Investment Pool", "SEP", False),
]
# The seven relationships at risk at the latest score date: (client short name, segment, status, at risk since June)
AT_RISK = [("Bay Harbor Police and Fire", "SEP", "NOT", True), ("Highplains PSRS", "SEP", "ACT", False),
           ("Tidewater TPP", "OCIO", "ACT", False), ("Stonebridge Logistics Pension", "SEP", "NOT", True),
           ("Ashford College", "SEP", "ACT", False), ("Granite Mutual Life", "SEP", "ACT", True),
           ("Lakemont Building Trades", "SEP", "ACT", False)]
AT_RISK_REASON = {"PPP": ["PERF", "CONS", "SPON"], "CDB": ["SPON"], "END": ["PERF"], "INS": ["STRAT"], "TH": ["SERV"]}
SCORE_DATES = [date(2025, 12, 31), date(2026, 3, 31), date(2026, 6, 30), date(2026, 9, 30)]


def build_inst_funds(irng, f, secs):
    """INST share classes of ten own products (FUND_MASTER and SEC_MASTER rows), added after the wealth business is
    built; the affiliated omnibus gets its zero rows for them (no brokerage account holds an INST class)."""
    n = len(f["funds"])
    by_prod = {}
    for x in f["funds"]:
        by_prod.setdefault(x["PRODUCT_CD"], []).append(x)
    new_funds, new_secs = [], []
    for k, prod in enumerate(INST_PRODUCTS):
        inv, adm = by_prod[prod][0], by_prod[prod][1]
        n += 1
        fund_no, cusip = "%04d" % (900 + (k + 1) * 7), "31%06dF" % (420000 + n * 13)
        acls = inv["ASSET_CLS_CD"]
        p0 = f["sec_by_cusip"][adm["CUSIP"]]["_prices"][0]
        prices = [100] * 4 if acls == "MM" else random_walk(irng, p0 + irng.randint(-150, 150))
        new_funds.append({"FUND_NO": fund_no, "FUND_NM": inv["FUND_NM"], "CLASS_CD": "INST", "PRODUCT_CD": prod,
                          "CUSIP": cusip, "TICKER": inv["TICKER"][:-1] + "I", "VEHICLE_CD": "OEF", "ASSET_CLS_CD": acls,
                          "INCEPT_DT": ymd(date(irng.randint(2008, 2019), irng.randint(1, 12), irng.randint(1, 28))),
                          "STATUS_CD": "A", "MIN_INIT_INV": amt(5_000_000_00), "INVESTOR_TYPE_CD": "I"})
        new_secs.append(dict(CUSIP=cusip, SYMBOL=inv["TICKER"][:-1] + "I", SEC_DESC=(inv["FUND_NM"] + " INSTITUTIONAL").upper(),
                             SEC_TYPE_CD="MMF" if acls == "MM" else "MF",
                             ASSET_CLS_CD={"EQ": "EQ", "FI": "FI", "MM": "CASH", "BAL": "MA"}[acls],
                             ISSUER_NM="The Firm Funds Trust", FUND_FAMILY_CD="OWN", TA_FUND_NO=fund_no, CCY="USD",
                             SEC_STATUS_CD="A", _prices=prices, _mult=1))
    f["funds"].extend(new_funds)
    for x in new_funds:
        f["fund_by_no"][x["FUND_NO"]] = x
    n_own = sum(1 for s in secs if s["FUND_FAMILY_CD"] == "OWN")
    secs[n_own:n_own] = new_secs
    for s in new_secs:
        f["sec_by_cusip"][s["CUSIP"]] = s
    om = f["affiliated"]
    for m in range(4):
        for fund in new_funds:
            f["ta_positions"].append({"ASOF_DT": ymd(MONTH_ENDS[m]), "ACCT_NO": om["ACCT_NO"], "FUND_NO": fund["FUND_NO"],
                                      "SHARES": qty(0), "SHARES_UNCOLL": "0.000", "SHARES_ESCROW": "0.000",
                                      "NAV": amt(f["sec_by_cusip"][fund["CUSIP"]]["_prices"][m]), "MKT_VAL": amt(0),
                                      "_m": m, "_mv": 0, "_acct": om, "_fund": fund})
    f["inst_funds"] = new_funds
    NOTES.append("Ten own products gain an INST share class (FUND_MASTER CLASS_CD INST, VEHICLE_CD OEF, investor type I, "
                 "fund numbers 0907 to 0970) with its SEC_MASTER row (MF, or MMF for the money market class); the "
                 "affiliated omnibus carries zero rows for them, as for every own fund number no brokerage account holds.")


def build_inst_clients(irng, f):
    """40 institutional clients, 6 consultants and 48 relationships (38 first relationships plus 10 pooled seconds)."""
    cons = [("CF-001", "Meridian Investment Consulting", "GEN"), ("CF-002", "Halcyon Advisory Partners", "GEN"),
            ("CF-003", "Crestline Consulting Group", "GEN"), ("CF-004", "Bramble & Hart Investment Consulting", "GEN"),
            ("CF-005", "Northgate Fiduciary Consulting", "SPEC"), ("CF-006", "Arbor Point Advisors", "OCIO")]
    f["consultants"] = [{"CONSULTANT_ID": a, "CONSULTANT_NM": b, "CONSULTANT_TYPE_CD": c} for a, b, c in cons]
    order = list(range(len(INST_CLIENTS)))
    irng.shuffle(order)
    clients = []
    for i, idx in enumerate(order):
        typ, short, legal, seg, has_cons = INST_CLIENTS[idx]
        median = 3_000_000_000 if typ in ("PPP", "CDB") else 800_000_000
        invest = lognormal_cents(irng, median, 0.5)
        consultant = irng.choice(cons[:5])[0] if has_cons else ""
        gov = ("BTC" if typ in ("PPP", "TH") else "ICC") if has_cons else "CIO"
        if seg == "OCIO":
            gov = irng.choice(["ICO", "DEL"])
        clients.append({"CLIENT_ID": "IC-%05d" % (400 + i * 17), "CLIENT_NAME": short, "LEGAL_NAME": legal,
                        "CLIENT_TYPE_CD": typ, "ENTITY_KIND_CD": ENTITY_KIND[typ], "SEGMENT_CD": seg or "SEP",
                        "BUS_LINE_CD": "IA" if seg in ("SEP", "OCIO", None) else "PF", "INVESTABLE_ASSETS": amt(invest),
                        "ASSETS_ASOF_DT": iso(date(2026, 6, 30)), "GOVERNANCE_CD": gov,
                        "GOV_ENTITY_FLG": "true" if typ in ("PPP", "GOV") else "false",
                        "ERISA_FLG": "true" if typ in ("CDB", "CDC", "TH") else "false",
                        "EIN": "%02d-%07d" % (irng.randint(10, 98), irng.randint(1000000, 9999999)),
                        "STATUS_CD": "A" if seg else "T", "CONSULTANT_ID": consultant,
                        "_invest": invest, "_seg": seg, "_rels": []})
    f["inst_clients"] = clients
    f["inst_client_by_id"] = {c["CLIENT_ID"]: c for c in clients}
    rels = []
    def rel(c, seg, start):
        erisa = c["ERISA_FLG"] == "true"
        scope = irng.choice(["FULL", "FULL", "PART", "ADV"]) if seg == "OCIO" else ""
        r = {"REL_ID": "SR-%05d" % (900 + len(rels) * 13), "CLIENT_ID": c["CLIENT_ID"], "SEGMENT_CD": seg,
             "BUS_LINE_CD": "IA" if seg in ("SEP", "OCIO") else "PF",
             "TIER_CD": "T4" if seg in ("POOL", "CIT") else ("T1" if c["_invest"] > 2_000_000_000_00 else
                                                            ("T2" if c["_invest"] > 500_000_000_00 else "T3")),
             "STATUS_CD": "ACT", "START_DT": iso(start), "CONSULTANT_ID": c["CONSULTANT_ID"], "OCIO_SCOPE_CD": scope,
             "ERISA_FID_CD": ("321" if scope == "ADV" else "338") if erisa and seg in ("SEP", "OCIO") else "NONE",
             "_client": c, "_start": start, "_mandates": [], "_fund_accts": []}
        rels.append(r)
        c["_rels"].append(r)
        return r
    active = [c for c in clients if c["_seg"]]
    for c in active:
        rel(c, c["_seg"], date(irng.randint(2008, 2023), irng.randint(1, 12), 1))
    seps = sorted([c for c in active if c["_seg"] == "SEP"], key=lambda c: -c["_invest"])[:8]
    ocios = sorted([c for c in active if c["_seg"] == "OCIO"], key=lambda c: -c["_invest"])[:2]
    seconds = [rel(c, "POOL", date(irng.randint(2015, 2025), irng.randint(1, 12), 1)) for c in seps + ocios]
    seconds[-1].update({"STATUS_CD": "ONB", "START_DT": iso(date(2026, 8, 3)), "_start": date(2026, 8, 3)})
    seconds[-2]["STATUS_CD"] = "DRM"
    by_short = {c["CLIENT_NAME"]: c for c in clients}
    f["at_risk_rels"] = []
    for short, seg, status, since_june in AT_RISK:
        r = [x for x in by_short[short]["_rels"] if x["SEGMENT_CD"] == seg][0]
        r["STATUS_CD"], r["_since_june"] = status, since_june
        f["at_risk_rels"].append(r)
    f["inst_rels"], f["rel_by_id"] = rels, {r["REL_ID"]: r for r in rels}
    NOTES.append("Relationships: the 38 active clients hold one first relationship each (SEP 26, OCIO 8, RK 3, CIT 1) "
                 "and 10 hold a second POOL relationship (the 8 largest SEP clients and the 2 largest OCIO clients), "
                 "48 in all; the addendum's '8 have a second' would give 46 against its 48 and its segment counts, so "
                 "two OCIO clients carry the remaining two POOL seconds. Terminated clients (2) have no relationship. "
                 "ONB and DRM are two of the POOL seconds; the 2 NOT relationships are at-risk ones.")
    NOTES.append("A relationship's CONSULTANT_ID is its client's consultant (24 clients have one). SRC-INST and SRC-PAB "
                 "dates are ISO (YYYY-MM-DD), as the schema's examples show; booleans are 'true'/'false'.")


def build_mandates_and_portfolios(irng, f):
    """70 mandates under the SEP and OCIO relationships (62 active, 8 terminated) and one portfolio per active mandate."""
    prod = {}
    for x in f["funds"]:
        prod.setdefault(x["PRODUCT_CD"], x)
    eq = [p for p, x in sorted(prod.items()) if x["ASSET_CLS_CD"] == "EQ"]
    fi = [p for p, x in sorted(prod.items()) if x["ASSET_CLS_CD"] == "FI"]
    bal = [p for p, x in sorted(prod.items()) if x["ASSET_CLS_CD"] == "BAL"]
    hosts = [r for r in f["inst_rels"] if r["SEGMENT_CD"] in ("SEP", "OCIO")]
    slots = [[r, "A"] for r in hosts]
    extra = ["A"] * (62 - len(hosts)) + ["T"] * 8
    counts = {r["REL_ID"]: 1 for r in hosts}
    for status in extra:
        r = irng.choice([x for x in hosts if counts[x["REL_ID"]] < 3])
        counts[r["REL_ID"]] += 1
        slots.append([r, status])
    slots.sort(key=lambda s: (hosts.index(s[0]), s[1]))
    mandates = []
    for r, status in slots:
        c = r["_client"]
        if r["SEGMENT_CD"] == "OCIO":
            strat = irng.choice(bal + bal + [eq[0], fi[0]])
        elif c["CLIENT_TYPE_CD"] == "INS":
            strat = irng.choice(fi)
        else:
            strat = irng.choice(eq + fi + bal[:1])
        incept = r["_start"] + timedelta(days=irng.randint(20, 900))
        incept = min(incept, date(2026, 3, 31) - timedelta(days=irng.randint(0, 400)))
        incept = max(incept, r["_start"])
        mandates.append({"MANDATE_ID": "MD-%05d" % (2200 + len(mandates) * 11), "CLIENT_ID": c["CLIENT_ID"],
                         "REL_ID": r["REL_ID"],
                         "MANDATE_NM": "%s - %s" % (c["CLIENT_NAME"], prod[strat]["FUND_NM"].replace(" Fund", "")),
                         "MANDATE_TYPE_CD": "SEG", "STRATEGY_CD": strat, "INCEPT_DT": iso(incept), "STATUS_CD": status,
                         "_rel": r, "_incept": incept, "_acls": prod[strat]["ASSET_CLS_CD"]})
        r["_mandates"].append(mandates[-1])
    non_ocio = [m for m in mandates if m["_rel"]["SEGMENT_CD"] == "SEP" and m["STATUS_CD"] == "A"]
    ins = [m for m in non_ocio if m["_rel"]["_client"]["CLIENT_TYPE_CD"] == "INS"]
    sub = (ins + irng.sample([m for m in non_ocio if m not in ins], 4))[:4]
    for m in sub:
        m["MANDATE_TYPE_CD"] = "SUB"
    for m in irng.sample([m for m in mandates if m["MANDATE_TYPE_CD"] == "SEG"], 6):
        m["MANDATE_TYPE_CD"] = "FOO"
    f["mandates"] = mandates
    custodians = {"NTRS": "NT", "BNYM": "BN", "STT": "SS", "JPM": "JP"}
    cust_of = {}
    ports = []
    for m in mandates:
        if m["STATUS_CD"] != "A":
            continue
        c = m["_rel"]["_client"]
        cust = cust_of.setdefault(c["CLIENT_ID"], irng.choice(sorted(custodians)))
        abbr = "".join(w[0] for w in prod[m["STRATEGY_CD"]]["FUND_NM"].replace(" Fund", "").split())
        ports.append({"PORT_ID": "P-%05d" % (30000 + len(ports) * 17), "PORT_NAME": ("%s %s" % (c["CLIENT_NAME"], abbr)).upper(),
                      "MANDATE_ID": m["MANDATE_ID"], "CLIENT_ID": c["CLIENT_ID"],
                      "PORT_TYPE_CD": "FOO" if m["MANDATE_TYPE_CD"] == "FOO" else "SEP", "BASE_CCY": "USD",
                      "INCEPT_DT": m["INCEPT_DT"], "STATUS_CD": "A", "CUSTODIAN_CD": cust,
                      "CUSTODY_ACCT_NO": "%s-%07d" % (custodians[cust], irng.randint(1000000, 9999999)),
                      "LEGAL_OWNER_CD": "CLIENT", "MGMT_ENTITY_CD": "IA", "_mandate": m, "_rel": m["_rel"],
                      "_client": c, "_kind": "PAB"})
    f["portfolios"] = ports
    NOTES.append("Mandates: every SEP and OCIO relationship carries at least one active mandate (34), the other 28 "
                 "active and 8 terminated mandates are spread at random with at most 3 per relationship; OCIO mandates "
                 "mostly follow the balanced products, insurance mandates fixed income (the 4 SUB mandates include "
                 "theirs). Strategy codes are FUND_MASTER PRODUCT_CD values (money market products excluded).")


def build_portfolio_holdings(irng, f):
    """Month-end holdings and valuations of every portfolio: about 4 billion for public pension plans, 6 for the rest."""
    secs = list(f["sec_by_cusip"].values())
    eq = [s for s in secs if s["SEC_TYPE_CD"] == "EQ"]
    fi = [s for s in secs if s["SEC_TYPE_CD"] in ("FI", "CD")]
    inst = [f["sec_by_cusip"][x["CUSIP"]] for x in f["inst_funds"] if x["ASSET_CLS_CD"] != "MM"]
    ports = f["portfolios"]
    raw = [p["_client"]["_invest"] * irng.lognormvariate(0, 0.5) / len([x for x in ports if x["_client"] is p["_client"]])
           for p in ports]
    targets = {}
    for group, total in (("PPP", 4_000_000_000_00), ("OTHER", 6_000_000_000_00)):
        idx = [i for i, p in enumerate(ports) if (p["_client"]["CLIENT_TYPE_CD"] == "PPP") == (group == "PPP")]
        s = sum(raw[i] for i in idx)
        for i in idx:
            targets[i] = int(raw[i] / s * total * irng.uniform(0.98, 1.02))
    ownf = set(irng.sample(range(len(ports)), 14))
    holdings, vals = [], []
    for i, p in enumerate(ports):
        acls = p["_mandate"]["_acls"]
        if acls == "FI":
            picks = irng.sample(fi, irng.randint(15, len(fi)))
        elif acls == "EQ":
            picks = irng.sample(eq, irng.randint(15, 40))
        else:
            k = irng.randint(20, 40)
            n_fi = min(len(fi), k * 2 // 5)
            picks = irng.sample(eq, k - n_fi) + irng.sample(fi, n_fi)
        weights = [irng.uniform(0.5, 1.5) for _ in picks]
        own = []
        if i in ownf:
            match = [s for s in inst if f["fund_by_no"][s["TA_FUND_NO"]]["ASSET_CLS_CD"] == acls] or inst
            own = irng.sample(match, min(len(match), irng.choice([1, 1, 2])))
        own_share = irng.uniform(0.05, 0.20) if own else 0
        total_w = sum(weights)
        alloc = [(s, targets[i] * (1 - own_share) * w / total_w) for s, w in zip(picks, weights)]
        alloc += [(s, targets[i] * own_share / len(own)) for s in own]
        p["_holdings"] = {}
        for s, cents in alloc:
            path = [shares_for(int(cents), s["_prices"][0], s["FUND_FAMILY_CD"] != "OWN")]
            for _ in range(3):
                path.append(path[-1] if irng.random() < 0.85 else drift(irng, path[-1]))
            p["_holdings"][s["CUSIP"]] = path
        for m in range(4):
            hv = 0
            for cusip, path in p["_holdings"].items():
                s = f["sec_by_cusip"][cusip]
                mv = value_of(path[m], s["_prices"][m])
                hv += mv
                holdings.append({"ASOF_DT": iso(MONTH_ENDS[m]), "PORT_ID": p["PORT_ID"], "SECURITY_ID": cusip,
                                 "QTY": qty(path[m]), "PRICE": amt(s["_prices"][m]), "MKT_VAL": amt(mv),
                                 "ASSET_CLS_CD": "OWNF" if s["FUND_FAMILY_CD"] == "OWN" else
                                 ("EQ" if s["SEC_TYPE_CD"] == "EQ" else "FI"), "VIEW_CD": "EOD",
                                 "_m": m, "_mv": mv, "_sec": s, "_port": p})
            cash = int(hv * irng.uniform(0.01, 0.03))
            accrued = int(hv * irng.uniform(0, 0.005))
            vals.append({"ASOF_DT": iso(MONTH_ENDS[m]), "PORT_ID": p["PORT_ID"], "HOLDINGS_MKT_VAL": amt(hv),
                         "CASH_VAL": amt(cash), "ACCRUED_INCOME": amt(accrued), "TOTAL_MKT_VAL": amt(hv + cash + accrued),
                         "VIEW_CD": "EOD", "_m": m, "_hv": hv, "_cash": cash, "_accrued": accrued,
                         "_total": hv + cash + accrued, "_port": p})
    f["holdings"], f["valuations"] = holdings, vals
    NOTES.append("Portfolio sizes are drawn in proportion to the client's investable assets and scaled so that the "
                 "public pension plans' portfolios hold about 4 billion and the others about 6 billion at 2026-06-30; "
                 "fixed income mandates hold 15 to 25 securities (the universe has 25 FI and CD), equity 15 to 40, "
                 "balanced 20 to 40 with two fifths in fixed income. 14 portfolios also hold 1 or 2 INST classes (5 to "
                 "20 percent). HOLDING.MKT_VAL is QTY x PRICE rounded to the cent; no HOLDING row is CASH (cash sits in "
                 "VALUATION.CASH_VAL).")


def build_health_scores(irng, f):
    """Quarterly scores for every relationship but the onboarding one; exactly the seven planted ones at risk now."""
    at_risk = {r["REL_ID"] for r in f["at_risk_rels"]}
    scored = [r for r in f["inst_rels"] if r["STATUS_CD"] != "ONB"]
    recovered = irng.sample([r for r in scored if r["REL_ID"] not in at_risk], 3)
    rec_when = {r["REL_ID"]: q for r, q in zip(recovered, [0, 1, 0])}
    rows = []
    for r in scored:
        rid = r["REL_ID"]
        reasons = AT_RISK_REASON.get(r["_client"]["CLIENT_TYPE_CD"], ["SERV", "FEE", "PERS"])
        reason = irng.choice(reasons)
        base = irng.uniform(58, 90)
        for q, d in enumerate(SCORE_DATES):
            if rid in at_risk and (q == 3 or (q == 2 and r.get("_since_june"))):
                score = irng.uniform(35, 49.4)
            elif rid in at_risk:
                score = irng.uniform(51, 68) if q >= 1 else irng.uniform(55, 78)
            elif rec_when.get(rid) == q:
                score = irng.uniform(38, 49.4)
            else:
                score = min(95, max(51, base + irng.uniform(-6, 6)))
            score = round(score, 1)
            rag = "G" if score > 70 else ("A" if score >= 50 else "R")
            rows.append({"REL_ID": rid, "SCORE_DT": iso(d), "SCORE": "%.1f" % score, "RAG_CD": rag,
                         "AT_RISK_FLG": "true" if rag == "R" else "false", "AT_RISK_RSN_CD": reason if rag == "R" else "",
                         "SURVEY_ID": "SV-%05d" % irng.randint(10000, 99999) if irng.random() < 0.6 else "",
                         "_rel": r, "_score": score, "_d": d})
    f["health"] = rows
    NOTES.append("Health scores: AT_RISK_FLG is true exactly when RAG_CD is R (score below 50); A covers 50 to 70 "
                 "inclusive, G above 70. Three relationships outside the seven were at risk at 2025-12-31 or 2026-03-31 "
                 "and recovered. The onboarding relationship has no score, so latest_score_date is null for it.")


def build_inst_fund_accounts(irng, f):
    """30 direct institutional fund accounts (SHR_ACCT type D, SOC 8), their positions and their register trades."""
    rels = f["inst_rels"]
    owners = [r for r in rels if r["SEGMENT_CD"] in ("POOL", "RK", "CIT") and r["STATUS_CD"] != "ONB"]
    picks = list(owners)
    while len(picks) < 24:
        r = irng.choice(owners)
        if picks.count(r) < 3:
            picks.append(r)
    pool_clients = {r["CLIENT_ID"] for r in rels if r["SEGMENT_CD"] == "POOL"}
    sep = [r for r in rels if r["SEGMENT_CD"] == "SEP" and r["CLIENT_ID"] not in pool_clients]
    forced = [r for r in f["at_risk_rels"] if r in sep and r["_client"]["CLIENT_TYPE_CD"] == "PPP"][:1]
    picks += forced + irng.sample([r for r in sep if r not in forced], 6 - len(forced))
    picks.sort(key=lambda r: rels.index(r))
    accts, positions, links = [], [], []
    for i, r in enumerate(picks):
        c = r["_client"]
        estab = max(r["_start"], date(2010, 1, 4)) + timedelta(days=irng.randint(0, 400))
        estab = min(estab, date(2026, 5, 29))
        t = {"ACCT_NO": "77%08d" % (500000 + (i + 1) * 37), "SOC_CD": "8", "ACCT_TYPE_CD": "D",
             "REG_LINE_1": c["LEGAL_NAME"].upper(), "REG_LINE_2": "", "TAX_ID_LAST4": c["EIN"][-4:],
             "DEALER_NO": "0010", "BRANCH_NO": "", "REP_NO": "", "NSCC_LEVEL": "", "ESTAB_DT": ymd(estab), "CLOSE_DT": "",
             "STATUS_CD": "A", "DIV_OPT_CD": "R", "IRA_TYPE_CD": "", "_kind": "TA_INST", "_rel": r, "_client": c}
        accts.append(t)
        r["_fund_accts"].append(t)
        links.append({"CLIENT_ID": c["CLIENT_ID"], "TA_ACCT_NO": t["ACCT_NO"], "REL_ID": r["REL_ID"]})
        target = min(70_000_000_00, max(6_000_000_00, lognormal_cents(irng, 22_000_000, 0.7)))
        funds = irng.sample(f["inst_funds"], irng.choice([1, 1, 2, 3]))
        t["_holdings"] = {}
        for fund in funds:
            p0 = f["sec_by_cusip"][fund["CUSIP"]]["_prices"][0]
            path = [shares_for(target // len(funds), p0)]
            for _ in range(3):
                path.append(drift(irng, path[-1]))
            t["_holdings"][fund["FUND_NO"]] = path
        for m in range(4):
            for fno, path in t["_holdings"].items():
                fund = f["fund_by_no"][fno]
                nav = f["sec_by_cusip"][fund["CUSIP"]]["_prices"][m]
                mv = value_of(path[m], nav)
                positions.append({"ASOF_DT": ymd(MONTH_ENDS[m]), "ACCT_NO": t["ACCT_NO"], "FUND_NO": fno,
                                  "SHARES": qty(path[m]), "SHARES_UNCOLL": "0.000", "SHARES_ESCROW": "0.000",
                                  "NAV": amt(nav), "MKT_VAL": amt(mv), "_m": m, "_mv": mv, "_acct": t, "_fund": fund})
    txns, seq = [], [0]
    def tx(t, fund, cd, d, cents):
        seq[0] += 1
        nav = f["sec_by_cusip"][fund["CUSIP"]]["_prices"][month_index(d)]
        txns.append({"CONFIRM_NO": "%s%08d" % (d.strftime("%y%m%d"), 5170000 + seq[0] * 11), "ACCT_NO": t["ACCT_NO"],
                     "FUND_NO": fund["FUND_NO"], "TRAN_CD": cd, "TRADE_DT": ymd(d), "SETL_DT": ymd(next_bday(d)),
                     "POST_DT": ymd(d), "SHARES": qty(shares_for(cents, nav)), "NAV_APPLIED": amt(nav),
                     "GROSS_AMT": amt(cents), "NET_AMT": amt(cents), "SOURCE_CD": "DR", "STATUS_CD": "P",
                     "REVERSAL_OF": "", "DEALER_NO": "0010", "REP_NO": "", "_acct": t, "_fund": fund, "_net": cents,
                     "_d": d, "_brk": None})
    for t in accts:
        for m in (1, 2, 3):
            days = [d for d in BDAYS if d.month == m + 6]
            for fno, path in t["_holdings"].items():
                fund = f["fund_by_no"][fno]
                v = value_of(path[m], f["sec_by_cusip"][fund["CUSIP"]]["_prices"][m])
                tx(t, fund, "101", days[-1], max(100, v * irng.randint(8, 30) // 10000))
            fund = f["fund_by_no"][irng.choice(sorted(t["_holdings"]))]
            if irng.random() < 0.5:
                tx(t, fund, "001", irng.choice(days), irng.randint(250_000, 4_000_000) * 100)
            if irng.random() < 0.35:
                tx(t, fund, "002", irng.choice(days), irng.randint(250_000, 5_000_000) * 100)
    f["ta_inst"], f["fund_accounts"] = accts, links
    f["ta_accts"].extend(accts)
    for t in accts:
        f["ta_by_no"][t["ACCT_NO"]] = t
    f["ta_positions"].extend(positions)
    f["ta_txns"].extend(txns)
    f["ta_txns"].sort(key=lambda r: (r["TRADE_DT"], r["CONFIRM_NO"]))
    NOTES.append("Direct institutional fund accounts: 24 under the POOL, RK and CIT relationships (each but the "
                 "onboarding one has at least one) and 6 under SEP relationships of clients without a POOL "
                 "relationship (one of them an at-risk public pension relationship). REG_LINE_1 is the client's "
                 "LEGAL_NAME in upper case, as the register prints registrations; TAX_ID_LAST4 the EIN's last four. "
                 "Each holds 1 to 3 INST classes worth 6 to 70 million at 2026-06-30 (drifting a few percent after). "
                 "Trades: monthly 101 reinvestments, and 001 and 002 in about half and a third of the months "
                 "(SOURCE_CD DR, no reversals).")


def build_institutional(f, secs):
    """The institutional business, with its own random generator so the wealth business is unchanged."""
    irng = random.Random("%s-institutional" % config.SEED)
    build_inst_funds(irng, f, secs)
    build_inst_clients(irng, f)
    build_mandates_and_portfolios(irng, f)
    build_portfolio_holdings(irng, f)
    build_health_scores(irng, f)
    build_inst_fund_accounts(irng, f)
    NOTES.append("The institutional business is generated after the wealth business from its own generator "
                 "(random.Random('<SEED>-institutional')), so every wealth extract, household figure and existing "
                 "planted value is unchanged; only the Total, Holding Type, Share Class and the new Channel and "
                 "Business Line rows grow.")


def rel_channel(r, ch):
    """The Distribution Channel code of an institutional relationship."""
    if r["SEGMENT_CD"] == "OCIO":
        return ch["IOCIO"]
    return ch["ICONS"] if r["CONSULTANT_ID"] else ch["IDIR"]


# ---------------------------------------------------------------------------------------------------------------------
# Household assets, tiers and segments

def counted_asset_rows(f):
    """Every counted asset fact: (month-end index, account, value in cents, holding type, share class key, own fund).
    Institutional portfolios count each HOLDING row and their cash plus accrued income (Cash and Sweep)."""
    out = []
    for p in f["positions"]:
        s = p["_sec"]
        out.append((p["_m"], p["_acct"], p["_mv"], holding_type(s), s["TA_FUND_NO"] or UNATTRIBUTED, s["FUND_FAMILY_CD"] == "OWN"))
    for c in f["cash"]:
        if c["BAL_BASIS_CD"] == "S":
            out.append((c["_m"], c["_acct"], c["_c"], "Cash and Sweep", UNATTRIBUTED, False))
    for p in f["ta_positions"]:
        if p["_acct"]["_kind"] != "TA_AFFILIATED":
            out.append((p["_m"], p["_acct"], p["_mv"], fund_holding_type(p["_fund"]), p["FUND_NO"], True))
    for h in f.get("holdings", []):
        s = h["_sec"]
        out.append((h["_m"], h["_port"], h["_mv"], holding_type(s), s["TA_FUND_NO"] or UNATTRIBUTED,
                    s["FUND_FAMILY_CD"] == "OWN"))
    for v in f.get("valuations", []):
        out.append((v["_m"], v["_port"], v["_cash"] + v["_accrued"], "Cash and Sweep", UNATTRIBUTED, False))
    return out


def account_person(f, acct):
    """The primary-owner person of a client account: the financial account's primary owner when there is one;
    for an unlinked brokerage account, the contact its customer resolves to (CRM_CONTACT_ID, else the contact carrying
    its customer number), else the platform customer ("CUST:<no>"); None for an unlinked direct fund account."""
    if acct.get("_fa"):
        return acct["_fa"]["FinServ__PrimaryOwner__c"]
    cu = acct.get("_prim")
    if cu is None:
        return None
    if "contact_by_cust" not in f:
        f["contact_by_cust"] = {c["Brokerage_Customer_No__c"]: c["Id"] for c in f["contacts"]
                                if c["Brokerage_Customer_No__c"]}
    return cu["CRM_CONTACT_ID"] or f["contact_by_cust"].get(cu["CUST_NO"]) or "CUST:" + cu["CUST_NO"]


def household_of(f, acct):
    """The household an account rolls up to: the current CRM household (AccountId, membership not ended, not merged)
    of its primary-owner person when that person is a CRM contact, else None (account owner -> client -> household)."""
    c = f["contact_by_id"].get(account_person(f, acct) or "")
    if c and c["AccountId"] and not c["Household_End__c"] and c["Status__c"] != "Merged":
        return c["AccountId"]
    return None


def set_tiers(rng, f, facts):
    """Service tiers from 2026-06-30 assets (18 set one tier too low) and segments from the qualifying tier."""
    assets = {}
    for m, acct, v, *_ in facts:
        hid = household_of(f, acct) if acct.get("_kind") != "TA_INT" else None
        if hid and m in (0, 3):
            assets[(hid, m)] = assets.get((hid, m), 0) + v
    order = ["T1", "T2", "T3", "T4"]
    for h in f["households"]:
        june = tier_for(assets.get((h["Id"], 0), 0))
        h["Service_Tier__c"], h["Segment__c"] = june, SEGMENT_OF_TIER[june]
        h["Tier_Method__c"] = rng.choice(["Rule"] * 8 + ["Score", "Manual", "Grandfathered"])
        h["_june"], h["_sept"] = assets.get((h["Id"], 0), 0), assets.get((h["Id"], 3), 0)
    eligible = [h for h in f["households"] if h["Service_Tier__c"] != "T1"
                and order.index(tier_for(h["_sept"])) >= order.index(h["Service_Tier__c"])]
    if len(eligible) < 18:
        NOTES.append("Only %d households could carry a too-low tier; all of them do." % len(eligible))
    for h in rng.sample(eligible, min(18, len(eligible))):
        h["Service_Tier__c"] = order[order.index(h["Service_Tier__c"]) - 1]
    NOTES.append("Segment__c follows the tier the household's 2026-06-30 assets qualify for (Core, Select, Private, "
                 "Flagship); the 18 planted households carry a Service_Tier__c one below that.")


# ---------------------------------------------------------------------------------------------------------------------
# The certified figures

def account_attributes(f, bl, ch):
    """Dimension attributes of every counted account (brokerage, direct and intermediary register accounts)."""
    attrs = {}
    def household_attrs(hid):
        if not hid:
            return UNATTRIBUTED, UNATTRIBUTED
        h = f["hh_by_id"][hid]
        owner = f["user_by_id"].get(h["OwnerId"])
        return (owner["Employee_Number__c"] if owner else UNATTRIBUTED), h["Segment__c"]
    for a in f["accts"]:
        hid = household_of(f, a)
        adv, seg = household_attrs(hid)
        who = account_person(f, a)
        attrs[id(a)] = dict(key="BRK:" + a["ACCT_NO"], channel=ch[a["_chan"]], bl=bl[a["_chan"]], advisor=adv,
                            segment=seg, household=hid, person=who, intermediary=False,
                            advised=(a["_cls"] == "A" and a["ENROLL_STATUS_CD"] == "A") or a["_cls"] == "T")
    for t in f["ta_direct"]:
        hid = household_of(f, t)
        adv, seg = household_attrs(hid)
        attrs[id(t)] = dict(key="TA:" + t["ACCT_NO"], channel=ch["TA"], bl=bl["TA"], advisor=adv,
                            segment=seg, household=hid, intermediary=False, advised=False,
                            person=account_person(f, t))
    for t in f["ta_intermediary"]:
        attrs[id(t)] = dict(key="TA:" + t["ACCT_NO"], channel=ch["INT"], bl=bl["INT"], advisor=UNATTRIBUTED,
                            segment=UNATTRIBUTED, household=None, person=None, intermediary=True, advised=False)
    for p in f.get("portfolios", []):
        attrs[id(p)] = dict(key="PAB:" + p["PORT_ID"], channel=rel_channel(p["_rel"], ch), bl=bl["IA"],
                            advisor=UNATTRIBUTED, segment=UNATTRIBUTED, household=None, person=p["CLIENT_ID"],
                            intermediary=False, advised=False, rel=p["_rel"]["REL_ID"])
    for t in f.get("ta_inst", []):
        attrs[id(t)] = dict(key="TA:" + t["ACCT_NO"], channel=rel_channel(t["_rel"], ch), bl=bl["TA"],
                            advisor=UNATTRIBUTED, segment=UNATTRIBUTED, household=None, person=t["_client"]["CLIENT_ID"],
                            intermediary=False, advised=False, rel=t["_rel"]["REL_ID"])
    NOTES.append("Institutional accounts: a portfolio (PAB:<PORT_ID>) and a direct institutional fund account "
                 "(TA:<ACCT_NO>) take the Channel of their relationship (OCIO; else consultant-led when the "
                 "relationship has a CONSULTANT_ID; else direct; the codes are read from the taxonomy's Distribution "
                 "Channel list, where the consultant-led code is INSTITUTIONAL_CONSULTANT), Business Line IA or PF, "
                 "Advisor and Segment UNATTRIBUTED, no household; their person is the CLIENT_ID, so a client with "
                 "several accounts counts once in Clients.")
    NOTES.append("Clients and Households count only client accounts: intermediary omnibus, plan and networked accounts "
                 "add to Funded Accounts (one each) but have no primary-owner person or household. The person of a "
                 "linked account is its financial account's primary owner; of an unlinked brokerage account, the "
                 "customer's CRM_CONTACT_ID, else the contact carrying its customer number, else the customer number; "
                 "an unlinked direct fund account has no person (it counts in Funded Accounts only).")
    NOTES.append("The household of an account is the current CRM household (Contact.AccountId, Household_End__c blank, "
                 "not Merged) of its primary-owner person when that person is a CRM contact (account owner -> client "
                 "-> household membership), so an unlinked brokerage account whose customer resolves to a contact rolls "
                 "up to that household (assets, Advisor, Segment, service tier). Platform-only customers, unlinked "
                 "direct fund accounts and intermediary accounts have no household.")
    return attrs


def flow_facts(f, attrs):
    """Every flow fact: (date, account attributes, holding type, share class, {measure: cents})."""
    out = []
    reversed_ids = {r["REVERSAL_OF_TXN_ID"] for r in f["activity"] if r["STATUS_CD"] == "R"}
    nna_codes = {"DEP", "WDL", "ACATI", "ACATO", "XFRI", "XFRO", "ROLLI"}
    same_owner = 0
    for r in f["activity"]:
        if r["STATUS_CD"] != "P" or r["TXN_ID"] in reversed_ids:
            continue
        a, cd, net = r["_acct"], r["TXN_CD"], r["_net"]
        s = r["_sec"]
        ht = holding_type(s) if s else "Cash and Sweep"
        sc = (s["TA_FUND_NO"] or UNATTRIBUTED) if s else UNATTRIBUTED
        meas = {}
        if cd in nna_codes:
            meas["nna"] = abs(net) if cd == "ACATI" else net
        elif cd == "JNL":
            other = f["acct_by_no"][r["CONTRA_ACCT_NO"]]
            if other["PRIM_CUST_NO"] != a["PRIM_CUST_NO"]:
                meas["nna"] = net
            elif other["_chan"] != a["_chan"]:
                meas["nict"] = net
            elif net > 0 and WINDOW_START <= r["_d"] <= WINDOW_END:
                same_owner += net
        if meas:
            out.append((r["_d"], attrs[id(a)], ht, sc, meas))
    ta_reversed = {r["REVERSAL_OF"] for r in f["ta_txns"] if r["STATUS_CD"] == "R"}
    for r in f["ta_txns"]:
        if r["STATUS_CD"] != "P" or r["CONFIRM_NO"] in ta_reversed:
            continue
        t, cd, net, fund = r["_acct"], r["TRAN_CD"], r["_net"], r["_fund"]
        meas = {}
        if t["_kind"] != "TA_AFFILIATED" and cd in ("001", "002", "071", "072"):
            meas["nna"] = net if cd in ("001", "071") else -net
        if cd == "001":
            meas["gross"] = net
        elif cd == "002":
            meas["redemptions"] = net
        elif cd == "051":
            meas["exchanges"] = net
        elif cd == "052":
            meas["exchanges"] = -net
        if meas:
            owner = attrs[id(r["_brk"]["_acct"])] if t["_kind"] == "TA_AFFILIATED" else attrs[id(t)]
            out.append((r["_d"], owner, fund_holding_type(fund), fund["FUND_NO"], meas))
    f["same_owner_journals"] = same_owner
    NOTES.append("Flows fall in a period by trade date (TRD_DT, TRADE_DT). On the Holding Type and Share Class rows a "
                 "brokerage flow takes its security's attribution (cash-only entries are Cash and Sweep and "
                 "UNATTRIBUTED) and a register flow its fund number's.")
    return out


DIMENSIONS = ["Total", "Channel", "Holding Type", "Business Line", "Advisor", "Segment", "Share Class"]


def dim_key(dim, attrs, ht, sc):
    """The dimension key of a fact."""
    return {"Total": "ALL", "Channel": attrs["channel"], "Holding Type": ht, "Business Line": attrs["bl"],
            "Advisor": attrs["advisor"], "Segment": attrs["segment"], "Share Class": sc}[dim]


def certify(f, facts, flows, attrs):
    """The measure values per period and dimension key, the household figures and the firm-level remainder."""
    # Asset sums per (dimension, key, month-end) and per (dimension, key, month-end, account)
    ending, advised, own, inter, per_acct = {}, {}, {}, {}, {}
    def add(d, k, v):
        d[k] = d.get(k, 0) + v
    for m, acct, v, ht, sc, is_own in facts:
        a = attrs[id(acct)]
        for dim in DIMENSIONS:
            k = (dim, dim_key(dim, a, ht, sc), m)
            add(ending, k, v)
            if a["advised"]:
                add(advised, k, v)
            if is_own:
                add(own, k, v)
            if a["intermediary"]:
                add(inter, k, v)
            add(per_acct, k + (a["key"],), v)
    funded = {}
    by_key = {a["key"]: a for a in attrs.values()}
    for (dim, key, m, akey), v in per_acct.items():
        if v > 0:
            funded.setdefault((dim, key, m), set()).add(akey)
    flow_sum = {}
    for d, a, ht, sc, meas in flows:
        for dim in DIMENSIONS:
            for name, v in meas.items():
                add(flow_sum, (dim, dim_key(dim, a, ht, sc), d, name), v)
    keys = {dim: set() for dim in DIMENSIONS}
    for (dim, key, m) in ending:
        keys[dim].add(key)
    for (dim, key, d, name) in flow_sum:
        keys[dim].add(key)
    values = []
    for ptype, b, e in PERIODS:
        start = MONTH_ENDS[b] + timedelta(days=1)
        end = MONTH_ENDS[e]
        months = e - b
        for dim in DIMENSIONS:
            for key in sorted(keys[dim], key=lambda k: (k == UNATTRIBUTED, k)):
                def fl(name):
                    return sum(v for (dd, kk, d, nn), v in flow_sum.items()
                               if dd == dim and kk == key and nn == name and start <= d <= end)
                B, E = ending.get((dim, key, b), 0), ending.get((dim, key, e), 0)
                avg = Fraction(B + E, 2) if months == 1 else Fraction(sum(ending.get((dim, key, i), 0)
                                                                          for i in range(b + 1, e + 1)), months)
                nna, nict = fl("nna"), fl("nict")
                gross, red, exch = fl("gross"), fl("redemptions"), fl("exchanges")
                accts = funded.get((dim, key, e), set())
                people = {by_key[x]["person"] for x in accts if by_key[x]["person"]}
                hhs = {by_key[x]["household"] for x in accts if by_key[x]["household"]}
                values.append({"period_type": ptype, "period_start": start.isoformat(), "period_end": end.isoformat(),
                               "dimension_type": dim, "dimension_key": key,
                               "beginning_client_assets": B / 100, "ending_client_assets": E / 100,
                               "average_client_assets": round_cents(avg) / 100,
                               "net_new_assets": nna / 100, "net_inter_channel_transfers": nict / 100,
                               "client_market_movement_other": (E - B - nna - nict) / 100,
                               "client_organic_growth_rate": round(nna * 12 / months / B, 8) if B else None,
                               "advised_assets": advised.get((dim, key, e), 0) / 100,
                               "own_fund_overlap_amount": own.get((dim, key, e), 0) / 100,
                               "client_assets_excl_intermediary": (E - inter.get((dim, key, e), 0)) / 100,
                               "gross_sales": gross / 100, "redemptions": red / 100, "net_exchanges": exch / 100,
                               "net_flows": (gross - red + exch) / 100, "funded_accounts": len(accts),
                               "clients": len(people), "households": len(hhs), "restatement_impact": 0.0,
                               "_cents": dict(E=E, nna=nna, nict=nict)})
    NOTES.append("dimension_key carries codes: Channel the Distribution Channel codes (DIRECT_SELF_DIRECTED, ...), "
                 "Business Line the two-letter codes, Holding Type the local list's values, Advisor the employee "
                 "number, Segment the CRM Segment__c code, Share Class the fund number, Total ALL; UNATTRIBUTED otherwise.")
    NOTES.append("Every period carries a row for every dimension key that appears in any period (zeros allowed). "
                 "Client Organic Growth Rate is null where Beginning Client Assets is zero; it is rounded to 8 decimals, "
                 "amounts to the cent (Average Client Assets half up).")
    NOTES.append("Funded Accounts, Clients and Households on a dimension row count accounts whose Ending within that "
                 "row's slice is above zero (so an account may count under several Holding Type or Share Class keys).")
    return values


def household_figures(f, facts, attrs):
    """Per-household figures at AS_OF and the firm-level assets that roll up to no household."""
    assets, advised, non_household = {}, {}, 0
    for m, acct, v, *_ in facts:
        if m != 3:
            continue
        a = attrs[id(acct)]
        if a["household"]:
            assets[a["household"]] = assets.get(a["household"], 0) + v
            if a["advised"]:
                advised[a["household"]] = advised.get(a["household"], 0) + v
        else:
            non_household += v
    away = {}
    for x in f["fas"]:
        if x["Held_Away__c"] == "true":
            cents = int(x["Held_Away_Value__c"].replace(".", ""))
            away[x["FinServ__Household__c"]] = away.get(x["FinServ__Household__c"], 0) + cents
    order = ["T1", "T2", "T3", "T4"]
    out = []
    for h in f["households"]:
        members = [c for c in f["contacts"] if c["AccountId"] == h["Id"] and c["Status__c"] == "Active"
                   and not c["Household_End__c"]]
        v = assets.get(h["Id"], 0)
        out.append({"crm_account_id": h["Id"], "household_members": len(members), "household_client_assets": v / 100,
                    "household_advised_assets": advised.get(h["Id"], 0) / 100, "held_away_assets": away.get(h["Id"], 0) / 100,
                    "without_primary_advisor": 0 if h["OwnerId"] else 1,
                    "service_tier_mismatch": 1 if order.index(tier_for(v)) > order.index(h["Service_Tier__c"]) else 0,
                    "_cents": v})
    return out, non_household


def planted_values(f, facts, attrs, households):
    """The planted facts, each computed from the data as written."""
    unlinked = {id(a) for a in f["unlinked_brk"]}
    referenced = {c["Brokerage_Customer_No__c"] for c in f["contacts"] if c["Brokerage_Customer_No__c"]}
    brk_own = sum(p["_mv"] for p in f["positions"] if p["_m"] == 3 and p["_sec"]["FUND_FAMILY_CD"] == "OWN")
    omni = sum(p["_mv"] for p in f["ta_positions"] if p["_m"] == 3 and p["_acct"]["_kind"] == "TA_AFFILIATED")
    gained = {attrs[id(acct)]["household"] for m, acct, v, *_ in facts
              if m == 3 and id(acct) in unlinked and attrs[id(acct)]["household"] and v}
    pairs = set()
    for r in f["activity"]:
        if r["TXN_CD"] == "JNL" and r["STATUS_CD"] == "P" and r["_net"] < 0:
            other = f["acct_by_no"][r["CONTRA_ACCT_NO"]]
            if other["PRIM_CUST_NO"] == r["_acct"]["PRIM_CUST_NO"] and other["_chan"] != r["_acct"]["_chan"]:
                pairs.add((r["ACCT_NO"], other["ACCT_NO"], r["TRD_DT"]))
    return {
        "HOUSEHOLDS_WITHOUT_PRIMARY_ADVISOR": sum(1 for h in f["households"] if not h["OwnerId"]),
        "SUGGESTED_MATCHES": sum(1 for c in f["customers"] if not c["CRM_CONTACT_ID"] and c["CUST_NO"] not in referenced),
        "UNLINKED_BROKERAGE_ACCOUNTS": sum(1 for a in f["accts"] if not a["_fa"]),
        "UNLINKED_BROKERAGE_VALUE": sum(v for m, acct, v, *_ in facts if m == 3 and id(acct) in unlinked) / 100,
        "OPTIONS_UNATTRIBUTED": sum(p["_mv"] for p in f["positions"] if p["_m"] == 3 and p["_sec"]["SEC_TYPE_CD"] == "OPT") / 100,
        "AFFILIATED_OMNIBUS_VALUE": omni / 100,
        "BROKERAGE_OWN_FUND_VALUE": brk_own / 100,
        "SERVICE_TIER_MISMATCH": sum(h["service_tier_mismatch"] for h in households),
        "INTER_CHANNEL_TRANSFER_PAIRS": len(pairs),
        "SAME_OWNER_JOURNALS_EXCLUDED": f["same_owner_journals"] / 100,
        "TA_DIRECT_UNLINKED_ACCOUNTS": sum(1 for t in f["ta_direct"] if not t["_fa"]),
        "HOUSEHOLDS_WITH_UNLINKED_ACCOUNTS": len(gained),
        "REVERSED_ROWS": sum(1 for r in f["activity"] if r["STATUS_CD"] == "R"),
        "PENDING_ROWS": sum(1 for r in f["activity"] if r["STATUS_CD"] == "N"),
    }, (omni, brk_own)


def institutional_figures(f, facts, attrs):
    """The institutional planted facts and the per-relationship list, from the counted assets at AS_OF."""
    rel_assets, total, sep = {}, 0, 0
    for m, acct, v, *_ in facts:
        a = attrs[id(acct)]
        if m != 3 or "rel" not in a:
            continue
        rel_assets[a["rel"]] = rel_assets.get(a["rel"], 0) + v
        total += v
        if a["key"].startswith("PAB:"):
            sep += v
    latest = {}
    for h in f["health"]:
        if h["REL_ID"] not in latest or h["_d"] > latest[h["REL_ID"]]["_d"]:
            latest[h["REL_ID"]] = h
    rels = []
    for r in f["inst_rels"]:
        h = latest.get(r["REL_ID"])
        rels.append({"rel_id": r["REL_ID"], "client_id": r["CLIENT_ID"], "client_type_cd": r["_client"]["CLIENT_TYPE_CD"],
                     "segment_cd": r["SEGMENT_CD"], "latest_score_date": h["SCORE_DT"] if h else None,
                     "latest_score": h["_score"] if h else None, "at_risk": bool(h and h["AT_RISK_FLG"] == "true"),
                     "at_risk_reason_cd": (h["AT_RISK_RSN_CD"] or None) if h else None,
                     "relationship_client_assets": rel_assets.get(r["REL_ID"], 0) / 100,
                     "channel_code": attrs_channel(f, r), "_cents": rel_assets.get(r["REL_ID"], 0)})
    ppp = [x for x in rels if x["client_type_cd"] == "PPP"]
    planted = {
        "INSTITUTIONAL_CLIENTS": len(f["inst_clients"]),
        "PUBLIC_PENSION_PLANS": sum(1 for c in f["inst_clients"] if c["CLIENT_TYPE_CD"] == "PPP"),
        "AT_RISK_RELATIONSHIPS": sum(1 for x in rels if x["at_risk"]),
        "PUBLIC_PENSION_AT_RISK_RELATIONSHIPS": sum(1 for x in ppp if x["at_risk"]),
        "INSTITUTIONAL_CLIENT_ASSETS": total / 100,
        "SEPARATE_ACCOUNT_ASSETS": sep / 100,
        "PUBLIC_PENSION_CLIENT_ASSETS": sum(x["_cents"] for x in ppp) / 100,
        "PUBLIC_PENSION_AT_RISK_CLIENT_ASSETS": sum(x["_cents"] for x in ppp if x["at_risk"]) / 100,
        "AT_RISK_CLIENT_ASSETS": sum(x["_cents"] for x in rels if x["at_risk"]) / 100,
    }
    NOTES.append("relationship_client_assets is the AS_OF Ending of the portfolios (through MANDATE.REL_ID) and direct "
                 "institutional fund accounts (FUND_ACCOUNT.REL_ID) served under the relationship; "
                 "PUBLIC_PENSION_CLIENT_ASSETS sums it over every relationship of a PPP client, so a pension plan's "
                 "pooled fund accounts count there but not in PUBLIC_PENSION_AT_RISK_CLIENT_ASSETS unless their own "
                 "relationship is at risk. latest_score and the at-risk fields are those of the 2026-09-30 score.")
    return planted, rels


def attrs_channel(f, r):
    """The Channel code of a relationship, as its accounts carry it."""
    return rel_channel(r, f["channels"])


def institutional_failures(f, tables, planted, rels):
    """The addendum's checks."""
    fails = []
    for v in f["valuations"]:
        if v["_total"] != v["_hv"] + v["_cash"] + v["_accrued"]:
            fails.append("VALUATION %s %s: total is not holdings + cash + accrued" % (v["PORT_ID"], v["ASOF_DT"]))
    hsum = {}
    for h in f["holdings"]:
        k = (h["PORT_ID"], h["ASOF_DT"])
        hsum[k] = hsum.get(k, 0) + h["_mv"]
    for v in f["valuations"]:
        if hsum.get((v["PORT_ID"], v["ASOF_DT"]), 0) != v["_hv"]:
            fails.append("VALUATION %s %s: HOLDINGS_MKT_VAL differs from its HOLDING rows" % (v["PORT_ID"], v["ASOF_DT"]))
    ppp_risk = [x for x in rels if x["client_type_cd"] == "PPP" and x["at_risk"]]
    if len(ppp_risk) != 3 or round(sum(x["_cents"] for x in ppp_risk)) != round(planted["PUBLIC_PENSION_AT_RISK_CLIENT_ASSETS"] * 100):
        fails.append("PUBLIC_PENSION_AT_RISK_CLIENT_ASSETS differs from the three PPP at-risk relationships")
    if sum(v["_total"] for v in f["valuations"] if v["_m"] == 3) != round(planted["SEPARATE_ACCOUNT_ASSETS"] * 100):
        fails.append("SEPARATE_ACCOUNT_ASSETS differs from the AS_OF valuations")
    if planted["AT_RISK_RELATIONSHIPS"] != 7 or planted["PUBLIC_PENSION_AT_RISK_RELATIONSHIPS"] != 3:
        fails.append("at-risk relationship counts are off")
    june = {h["REL_ID"] for h in f["health"] if h["SCORE_DT"] == "2026-06-30" and h["AT_RISK_FLG"] == "true"}
    if len(june & {x["rel_id"] for x in rels if x["at_risk"]}) != 3:
        fails.append("not exactly three of the at-risk relationships were at risk at 2026-06-30")
    d_accts = {r["ACCT_NO"] for r in tables[("SRC-TA", "SHR_ACCT")] if r["ACCT_TYPE_CD"] == "D"}
    for r in tables[("SRC-INST", "FUND_ACCOUNT")]:
        if r["TA_ACCT_NO"] not in d_accts:
            fails.append("FUND_ACCOUNT %s is not a type D register account" % r["TA_ACCT_NO"])
    if len(d_accts) != 30:
        fails.append("%d type D accounts, not 30" % len(d_accts))
    expect = {("SRC-INST", "CLIENT"): 40, ("SRC-INST", "RELATIONSHIP"): 48, ("SRC-INST", "MANDATE"): 70,
              ("SRC-PAB", "PORTFOLIO"): 62, ("SRC-INST", "FUND_ACCOUNT"): 30, ("SRC-INST", "CONSULTANT"): 6}
    for k, n in expect.items():
        if len(tables[k]) != n:
            fails.append("%s/%s has %d rows, not %d" % (k + (len(tables[k]), n)))
    return fails


# ---------------------------------------------------------------------------------------------------------------------
# The client economics business (GENERATOR_BRIEF_ECONOMICS.md): SRC-BIL (the advisory fee billing engine), SRC-REV (the
# revenue sub-ledger) and SRC-CST (the cost allocation engine), over the twelve fiscal months 2025-10 to 2026-09. Built
# with its own random generator after the wealth and institutional businesses and their certified figures, which it
# reads but never changes.

FISCAL_MONTHS = ["2025-10", "2025-11", "2025-12"] + ["2026-%02d" % m for m in range(1, 10)]
FISCAL_QUARTERS = [("2025Q4", date(2025, 10, 1), date(2025, 12, 31)), ("2026Q1", date(2026, 1, 1), date(2026, 3, 31)),
                   ("2026Q2", date(2026, 4, 1), date(2026, 6, 30)), ("2026Q3", date(2026, 7, 1), date(2026, 9, 30))]
Q_START = {q: s for q, s, e in FISCAL_QUARTERS}
Q_END = {q: e for q, s, e in FISCAL_QUARTERS}
QUARTER_FACTOR = {"2025Q4": 0.92, "2026Q1": 0.94, "2026Q2": 0.97, "2026Q3": 1.0}
ECON_HOLIDAYS = {date(2026, 1, 1), date(2026, 4, 3), date(2026, 7, 3), date(2026, 9, 7)}
PROGRAM_FAMILY = {"PAS": "ADV-STD", "DAP": "ADV-DIG", "WMP": "WMP-WRAP", "TRS": "TRS-ADM"}
# family, name, type, method, own-fund treatment, versions oldest first: (tiers [(lower bound in dollars, bps)], minimum)
FEE_FAMILIES = [
    ("ADV-STD", "Personal Advisor Standard Schedule", "ADV", "BL", "CRED",
     [([(0, 100), (500_000, 85), (2_000_000, 70), (10_000_000, 50)], 0),
      ([(0, 95), (500_000, 80), (2_000_000, 65), (10_000_000, 50)], 0),
      ([(0, 90), (500_000, 75), (2_000_000, 60), (10_000_000, 45)], 0)]),
    ("ADV-DIG", "Digital Advice Program Schedule", "ADV", "SR", "CRED", [([(0, 35)], 0), ([(0, 30)], 0)]),
    ("WMP-WRAP", "Wealth Management Program Wrap Fee Schedule", "WRAP", "BL", "CRED",
     [([(0, 110), (500_000, 90), (2_000_000, 70), (10_000_000, 55)], 0),
      ([(0, 95), (500_000, 75), (2_000_000, 60), (10_000_000, 45)], 0),
      ([(0, 100), (500_000, 80), (2_000_000, 65), (10_000_000, 50)], 0)]),
    ("TRS-ADM", "Trust Administration Fee Schedule", "TRST", "BL", "NONE",
     [([(0, 100), (1_000_000, 85), (5_000_000, 65)], 0), ([(0, 110), (1_000_000, 90), (5_000_000, 70)], 0)]),
    ("PLN-FLAT", "Planning Only Flat Fee Schedule", "FLAT", "SR", "NONE", [([(0, 0)], 2000), ([(0, 0)], 2400)]),
    ("SVC-ACCT", "Account Service Fee Schedule", "SVC", "SR", "NONE", [([(0, 0)], 0), ([(0, 0)], 0)]),
]
FEE_STREAMS = {"ADVF", "TRST", "WRAP", "PLAN", "SUBS", "SVCF"}
POOLS = [  # type, name, cost-to-serve component, cost centers, categories, weight in operating expense
    ("ADV", "Advisor Coverage and Planning", "ADV", "CC-4100; CC-4120", "ADVCOMP; ADVINC", 0.22),
    ("SVC", "Client Service", "SVC", "CC-4200; CC-4210", "SVCCOMP; CCTECH", 0.14),
    ("PLAT", "Platform and Technology", "PLAT", "CC-5100; CC-5150", "PLTECH; DATA", 0.17),
    ("CLR", "Clearing and Custody Operations", "CLR", "CC-5300", "CLRFEE; SVCCOMP", 0.08),
    ("MM", "Money Movement Operations", "MM", "CC-5400", "SVCCOMP; OTH", 0.035),
    ("COMM", "Client Communications", "COMM", "CC-5500", "MAIL; DATA", 0.025),
    ("COMP", "Compliance and Supervision", "REG", "CC-6100; CC-6150", "REGFEE; OTH", 0.05),
    ("MKT", "Marketing and Acquisition", "", "CC-7100", "MKTG", None),
    ("PROD", "Product Management", "", "CC-7200", "DATA; OTH", 0.06),
    ("DIST", "Intermediary Distribution", "", "CC-7300", "REVSHR; SUBTA", 0.015),
    ("CORP", "Corporate Overhead", "", "CC-9000; CC-9100", "OTH", 0.12),
]
POOL_METHOD = {"ADV": ("M-ABC", "ADVHRS"), "SVC": ("M-ABC", "CONTACTS"), "PLAT": ("M-DRV", "ACCTS"),
               "CLR": ("M-DRV", "ACCTS"), "MM": ("M-DRV", "TXN"), "COMM": ("M-DRV", "HH"), "COMP": ("M-DRV", "AUM"),
               "MKT": ("M-DRV", "HH"), "PROD": ("M-DRV", "AUM"), "DIST": ("M-DIR", "FIXED"), "CORP": ("M-STEP", "FIXED")}
CORP_SHARES = {"ADV": 2200, "SVC": 1400, "PLAT": 1800, "CLR": 900, "MM": 500, "COMM": 400, "COMP": 900, "MKT": 800,
               "PROD": 800, "DIST": 300}
CTS_COMPONENTS = [("ADV", "coverage_and_servicing"), ("SVC", "client_service"), ("PLAT", "platform_and_technology"),
                  ("CLR", "clearing_and_custody"), ("MM", "money_movement"), ("COMM", "communications_and_regulatory"),
                  ("REG", "communications_and_regulatory")]
CTS_NAMES = ["coverage_and_servicing", "client_service", "platform_and_technology", "clearing_and_custody",
             "money_movement", "communications_and_regulatory"]
GRAIN_NAMES = {"SEG": "Segment", "CHAN": "Channel", "BL": "Business Line", "OFF": "Offering", "TIER": "Service Tier"}
SEG_MEMBERS = ["Core", "Select", "Private", "Flagship"]
CHAN_MEMBERS = ["DIRECT_SELF_DIRECTED", "DIRECT_DIGITAL_ADVICE", "DIRECT_HUMAN_ADVICE", "DIRECT_TRUST", "INTERMEDIARY",
                "INSTITUTIONAL_DIRECT", "INSTITUTIONAL_CONSULTANT", "INSTITUTIONAL_OCIO"]
BL_MEMBERS = ["DB", "DA", "HA", "TR", "PF", "IA", "IC"]
OFF_MEMBERS = ["DAP", "PAS", "WMP", "TRS", "HYB", "PLN", "BRK"]
TIER_MEMBERS = ["T1", "T2", "T3", "T4"]
DIM_MEMBERS = {"SEG": SEG_MEMBERS, "CHAN": CHAN_MEMBERS, "BL": BL_MEMBERS, "OFF": OFF_MEMBERS, "TIER": TIER_MEMBERS}
# Base driver weights per pool and dimension (members in the order of DIM_MEMBERS); MKT's SEG and OFF weights are set
# from revenue (econ_mkt_weights), DIST goes directly to the intermediary channel and business line.
DRIVER_BASE = {
    "SEG": {"ADV": [20, 30, 30, 20], "SVC": [40, 28, 20, 12], "PLAT": [55, 22, 14, 9], "CLR": [55, 22, 14, 9],
            "MM": [45, 25, 18, 12], "COMM": [50, 25, 15, 10], "COMP": [15, 25, 30, 30], "PROD": [15, 25, 30, 30]},
    "CHAN": {"ADV": [2, 4, 48, 14, 2, 10, 12, 8], "SVC": [30, 10, 25, 8, 3, 8, 9, 7], "PLAT": [40, 15, 15, 5, 5, 7, 8, 5],
             "CLR": [45, 12, 15, 6, 4, 6, 7, 5], "MM": [40, 12, 18, 6, 6, 6, 7, 5], "COMM": [35, 12, 20, 6, 5, 7, 8, 7],
             "COMP": [15, 8, 20, 10, 8, 12, 15, 12], "MKT": [30, 25, 20, 5, 3, 6, 6, 5],
             "PROD": [10, 5, 10, 5, 15, 15, 25, 15]},
    "BL": {"ADV": [2, 4, 48, 14, 5, 25, 2], "SVC": [28, 10, 25, 8, 12, 12, 5], "PLAT": [35, 15, 15, 5, 15, 10, 5],
           "CLR": [40, 12, 15, 6, 12, 10, 5], "MM": [35, 12, 18, 6, 15, 9, 5], "COMM": [30, 12, 20, 6, 17, 10, 5],
           "COMP": [15, 8, 20, 10, 15, 25, 7], "MKT": [30, 25, 20, 5, 8, 7, 5], "PROD": [10, 5, 10, 5, 30, 25, 15]},
    "OFF": {"ADV": [5, 40, 25, 15, 0, 10, 5], "SVC": [15, 25, 12, 8, 0, 5, 35], "PLAT": [20, 15, 8, 4, 0, 3, 50],
            "CLR": [18, 15, 8, 6, 0, 1, 52], "MM": [15, 15, 8, 5, 0, 2, 55], "COMM": [15, 18, 10, 7, 0, 5, 45],
            "COMP": [10, 25, 20, 15, 0, 5, 25], "PROD": [15, 25, 20, 10, 0, 5, 25]},
    "TIER": {"ADV": [20, 30, 30, 20], "SVC": [45, 28, 17, 10]},
}
MKT_CORE_RATIO = Fraction(13, 10)     # the Core segment's marketing cost over its revenue (the planted negative cut)
MKT_PLN_SHARE = Fraction(5, 100)      # the PLN offering's share of marketing cost (it has no revenue here)


def quarter_of(fm):
    """Fiscal quarter key of a fiscal month YYYY-MM."""
    return "%sQ%d" % (fm[:4], (int(fm[5:]) - 1) // 3 + 1)


def months_of(q):
    """The three fiscal months of a fiscal quarter key."""
    first = (int(q[-1]) - 1) * 3 + 1
    return ["%s-%02d" % (q[:4], first + i) for i in range(3)]


def overlap_month(fm):
    """Index into MONTH_ENDS of the latest month-end on or before the end of fiscal month fm (2026-06-30 before)."""
    return {"2026-07": 1, "2026-08": 2, "2026-09": 3}.get(fm, 0)


def prior_month_end(fm):
    """The month-end before fiscal month fm."""
    return date(int(fm[:4]), int(fm[5:]), 1) - timedelta(days=1)


def nth_bday_after(d, n):
    """The n-th business day after d (weekends and the economics holidays skipped)."""
    k = 0
    while k < n:
        d += timedelta(days=1)
        if d.weekday() < 5 and d not in ECON_HOLIDAYS:
            k += 1
    return d


def split_exact(total, weights):
    """Integer parts of `total` proportional to integer `weights`, adding exactly to `total` (largest remainder)."""
    W = sum(weights)
    if W == 0:
        return [0] * len(weights)
    parts = [total * w // W for w in weights]
    rest = total - sum(parts)
    order = sorted(range(len(weights)), key=lambda i: (-((total * weights[i]) % W), i))
    for i in order[:rest]:
        parts[i] += 1
    return parts


def bps4(frac):
    """A rate in basis points written with four decimals."""
    n = round_cents(frac * 10000)
    return "%d.%04d" % (n // 10000, n % 10000)


def pct2(hundredths):
    """A share in hundredths of a percent written as a percent with two decimals."""
    return "%d.%02d" % (hundredths // 100, hundredths % 100)


def sched_rate(sched, value):
    """The exact annual rate (bps, a Fraction) a schedule version's tiers give on a value in cents: blended tiers charge
    each band's rate on the value within it; single-rate schedules charge their one rate; a zero value takes tier 1."""
    tiers = sched["_tiers"]
    if sched["TIER_METHOD_CD"] == "SR" or value <= 0:
        return Fraction(tiers[0][2])
    fee = Fraction(0)
    for lo, hi, rate in tiers:
        portion = (min(value, hi) if hi is not None else value) - lo
        if portion > 0:
            fee += Fraction(portion * rate, 10000)
    return fee * 10000 / value


def econ_schedules(f):
    """SCHEDULE and SCHEDULE_TIER: six families, 14 versions; the current one active from 2025-01-01."""
    scheds, tiers = [], []
    f["sched_by_id"], f["current_sched"], f["prior_sched"] = {}, {}, {}
    for fam, name, typ, method, own, versions in FEE_FAMILIES:
        n = len(versions)
        for i, (bands, minimum) in enumerate(versions):
            vno = i + 1
            sid = "S-%s-%d" % (fam, vno)
            if vno == n:
                status, start, end, ed = "A", date(2025, 1, 1), None, "March 2025"
            elif vno == n - 1:
                status, start, end, ed = "R", date(2024, 1, 1), date(2024, 12, 31), "March 2024"
            else:
                status, start, end, ed = "R", date(2021, 1, 1), date(2023, 12, 31), "March 2021"
            s = {"SCHED_ID": sid, "FAMILY_CD": fam, "SCHED_NM": name, "SCHED_TYPE_CD": typ, "VERSION_NO": str(vno),
                 "STATUS_CD": status, "EFF_FROM_DT": iso(start), "EFF_TO_DT": iso(end),
                 "BASIS_CD": "FLAT" if typ in ("FLAT", "SVC") else "PEV", "TIER_METHOD_CD": method,
                 "BILL_FREQ_CD": "A" if typ == "FLAT" else "Q", "BILL_TIMING_CD": "ARR",
                 "MIN_ANNUAL_FEE": amt(minimum * 100), "MAX_RATE_BPS": str(max(r for _, r in bands)),
                 "OWN_FUND_CD": own, "ADV_REF": "Item 5, " + ed,
                 "PRIOR_SCHED_ID": "S-%s-%d" % (fam, vno - 1) if vno > 1 else "",
                 "_tiers": [], "_from": start, "_to": end}
            for k, (lo, rate) in enumerate(bands):
                hi = bands[k + 1][0] if k + 1 < len(bands) else None
                s["_tiers"].append((lo * 100, hi * 100 if hi is not None else None, rate))
                tiers.append({"SCHED_ID": sid, "TIER_NO": str(k + 1), "LOWER_BOUND": amt(lo * 100),
                              "UPPER_BOUND": amt(hi * 100) if hi is not None else "", "RATE_BPS": str(rate)})
            scheds.append(s)
            f["sched_by_id"][sid] = s
            if vno == n:
                f["current_sched"][fam] = s
            elif vno == n - 1:
                f["prior_sched"][fam] = s
    f["schedules"], f["schedule_tiers"] = scheds, tiers
    NOTES.append("Fee schedules: ADV-STD and WMP-WRAP have three versions, the other four families two (%d versions, %d "
                 "tiers). The current version of each family is active from 2025-01-01, the prior one ran 2024-01-01 "
                 "to 2024-12-31, the first (where there are three) 2021-01-01 to 2023-12-31. WMP-WRAP and TRS-ADM bands "
                 "are not in the brief: WMP-WRAP uses the ADV-STD bounds (0 / 500k / 2m / 10m), TRS-ADM 0 / 1m / 5m. "
                 "Prior versions: ADV-STD 95/80/65/50 (the brief's), ADV-DIG 35, WMP-WRAP 95/75/60/45 and TRS-ADM "
                 "100/85/65 (so a fee billed on the prior version is higher for ADV-STD and ADV-DIG and lower for "
                 "WMP-WRAP and TRS-ADM). BASIS_CD PEV (period-end value) for the asset-based families, FLAT for PLN-FLAT "
                 "and SVC-ACCT; MAX_RATE_BPS is the highest tier rate; a blended rate on a zero value is tier 1's."
                 % (len(scheds), len(tiers)))


def econ_values(erng, f, facts):
    """Per brokerage account: the month-end values and own-fund holdings, and the billing valuation of each quarter:
    at 2026-09-30 the account's total value (positions plus cash, as the certified family counts it), earlier quarters
    that value scaled by 0.92 / 0.94 / 0.97 with per-account noise (an account closed in the window scales its last
    month-end value)."""
    val, own = {}, {}
    brk = {id(a) for a in f["accts"]}
    for m, acct, v, ht, sc, is_own in facts:
        if id(acct) in brk:
            k = (acct["ACCT_NO"], m)
            val[k] = val.get(k, 0) + v
            if is_own:
                own[k] = own.get(k, 0) + v
    f["econ_val"], f["econ_own"] = val, own
    fac, qval, qown = {}, {}, {}
    for a in f["accts"]:
        no = a["ACCT_NO"]
        fac[no] = {q: (QUARTER_FACTOR[q] * (1 + erng.uniform(-0.015, 0.015)) if q != "2026Q3" else 1.0)
                   for q, _, _ in FISCAL_QUARTERS}
        months = holding_months(a)
        last = months[-1] if months else None
        for q, _, _ in FISCAL_QUARTERS:
            if q == "2026Q3":
                qval[(no, q)] = val.get((no, 3), 0) if 3 in months else 0
                qown[(no, q)] = own.get((no, 3), 0) if 3 in months else 0
            elif last is None:
                qval[(no, q)] = qown[(no, q)] = 0
            else:
                qval[(no, q)] = int(round(val.get((no, last), 0) * fac[no][q]))
                qown[(no, q)] = int(round(own.get((no, last), 0) * fac[no][q]))
    f["econ_fac"], f["econ_qval"], f["econ_qown"] = fac, qval, qown


def econ_assignments(erng, f, attrs):
    """ASSIGNMENT, FEE_GROUP and FEE_GROUP_MBR: one current assignment per enrolled account, 30 closed prior-version
    assignments, one fee group per household with two or more enrolled accounts, 3 links and 2 proposed members."""
    enrolled = [a for a in f["accts"] if a["PROGRAM_CD"] in PROGRAM_FAMILY and a["ENROLL_STATUS_CD"] == "A"]
    enrolled.sort(key=lambda a: a["ACCT_NO"])
    def enroll_date(a):
        e = a["ENROLL_DT"]
        return date(int(e[:4]), int(e[4:6]), int(e[6:])) if e else None
    hh_of = {a["ACCT_NO"]: attrs[id(a)]["household"] for a in f["accts"]}
    by_hh = {}
    for a in enrolled:
        if hh_of[a["ACCT_NO"]]:
            by_hh.setdefault(hh_of[a["ACCT_NO"]], []).append(a)
    groups, members, gid_of = [], [], {}
    for hid in sorted(h for h, accts in by_hh.items() if len(accts) >= 2):
        gid = "FG-%05d" % (len(groups) + 1)
        groups.append({"GROUP_ID": gid, "CRM_HH_ID": hid, "BASIS_CD": "HH", "STATUS_CD": "A",
                       "EFF_FROM_DT": iso(date(2024, 1, 1)), "EFF_TO_DT": "", "_hh": hid})
        for a in by_hh[hid]:
            start = max(date(2024, 1, 1), enroll_date(a) or date(2024, 1, 1))
            members.append({"GROUP_ID": gid, "ACCT_NO": a["ACCT_NO"], "BASIS_CD": "HH", "STATUS_CD": "A",
                            "EFF_FROM_DT": iso(start), "EFF_TO_DT": "", "_from": start, "_acct": a})
            gid_of[a["ACCT_NO"]] = gid
    # Client-requested links and proposed memberships: unenrolled open accounts of a group's household
    enrolled_nos = {a["ACCT_NO"] for a in enrolled}
    spare = []
    for g in groups:
        for a in f["accts"]:
            if hh_of[a["ACCT_NO"]] == g["_hh"] and a["ACCT_NO"] not in enrolled_nos and a["_status"] == "O" \
                    and a["_open"] < date(2025, 7, 1):
                spare.append((g, a))
    picks = erng.sample(spare, 5)
    used = set()
    for i, (g, a) in enumerate(picks):
        if a["ACCT_NO"] in used:
            raise SystemExit("an account was picked twice for a fee group link")
        used.add(a["ACCT_NO"])
        start = date(2025, 7, 1) if i < 3 else date(2026, 9, 15)
        members.append({"GROUP_ID": g["GROUP_ID"], "ACCT_NO": a["ACCT_NO"], "BASIS_CD": "LINK",
                        "STATUS_CD": "A" if i < 3 else "P", "EFF_FROM_DT": iso(start), "EFF_TO_DT": "",
                        "_from": start, "_acct": a})
    members.sort(key=lambda r: (r["GROUP_ID"], r["ACCT_NO"]))
    f["fee_groups"], f["fee_members"] = groups, members
    # Assignments: current ones on the program family's current version, then 30 closed prior-version ones
    asg = []
    for a in enrolled:
        fam = PROGRAM_FAMILY[a["PROGRAM_CD"]]
        start = max(date(2025, 1, 1), enroll_date(a) or date(2025, 1, 1))
        asg.append({"ASSIGN_ID": "FA-%06d" % (len(asg) + 1), "ACCT_NO": a["ACCT_NO"], "PROGRAM_CD": a["PROGRAM_CD"],
                    "SCHED_ID": f["current_sched"][fam]["SCHED_ID"], "PAY_ACCT_NO": a["ACCT_NO"], "COLLECT_CD": "DED",
                    "BILL_FREQ_CD": "Q", "BILL_TIMING_CD": "ARR", "GROUP_ID": gid_of.get(a["ACCT_NO"], ""),
                    "NEGOTIATED_FLG": "false", "EFF_FROM_DT": iso(start), "EFF_TO_DT": "",
                    "_acct": a, "_from": start, "_to": None, "_fam": fam, "_enroll": enroll_date(a)})
    current = list(asg)
    early = [x for x in current if x["_enroll"] and x["_enroll"] < date(2025, 1, 1)]
    for x in sorted(erng.sample(early, 30), key=lambda x: x["ACCT_NO"]):
        start = max(date(2024, 1, 1), x["_enroll"])
        asg.append(dict(x, ASSIGN_ID="FA-%06d" % (len(asg) + 1), SCHED_ID=f["prior_sched"][x["_fam"]]["SCHED_ID"],
                        EFF_FROM_DT=iso(start), EFF_TO_DT=iso(date(2024, 12, 31)), _from=start, _to=date(2024, 12, 31)))
    # Six assignments pay from another open account of the same household
    payers = []
    for x in current:
        hid = hh_of[x["ACCT_NO"]]
        others = [a for a in f["accts"] if hid and hh_of[a["ACCT_NO"]] == hid and a is not x["_acct"]
                  and a["_status"] == "O" and a["_cls"] == "B"]
        if others and x["_acct"]["_status"] == "O":
            payers.append((x, others))
    for x, others in erng.sample(payers, 6):
        x["PAY_ACCT_NO"] = erng.choice(others)["ACCT_NO"]
    f["assignments"], f["current_asg"] = asg, current
    f["hh_of_acct"] = hh_of
    NOTES.append("Fee groups follow the CRM household each account rolls up to (account owner -> contact -> household). "
                 "The data has %d households with two or more enrolled accounts, so there are %d groups (the brief "
                 "expected 40 to 60); members are those enrolled accounts (HH, from the later of 2024-01-01 and the "
                 "enrollment date) plus 3 client-requested links (LINK, A, from 2025-07-01) and 2 proposed links (LINK, "
                 "P, from 2026-09-15) of unenrolled open accounts of group households." % (len(groups), len(groups)))
    NOTES.append("Assignments: all 140 enrolled accounts (ENROLL_STATUS_CD A, whatever the account status) have a "
                 "current, open-ended assignment on their program family's current version from the later of 2025-01-01 "
                 "and the enrollment date (a pending account with no enrollment date from 2025-01-01); an account closed "
                 "before 2026-09-30 keeps it and is billed on a zero value. 30 accounts enrolled before 2025 also have a "
                 "closed assignment on the prior version (later of 2024-01-01 and enrollment to 2024-12-31). Assignment "
                 "ids FA-000001 to FA-000140 are the current ones in account order. 6 current assignments pay from "
                 "another open self-directed account of the same household.")


def econ_fee_calc(f, run, x, sched, billable, own_val, group_assets, days=None, period_days=None, discount=False,
                  waivers=()):
    """One FEE_CALC row: the rate from the schedule version's tiers on the group's assets (else the account's), the
    gross fee for the quarter (pro-rated by days), the 10 percent discount, the waivers (percentage of gross or an
    amount) and the own-fund credit, each capped so the net fee is never below zero."""
    rate = sched_rate(sched, group_assets if group_assets is not None else billable)
    prorate = Fraction(days, period_days) if days else Fraction(1)
    gross = round_cents(Fraction(billable) * rate / 40000 * prorate)
    disc = round_cents(Fraction(gross, 10)) if discount else 0
    w = 0
    for wv in waivers:
        w += round_cents(Fraction(gross) * wv["_pct"] / 100) if wv["_pct"] is not None else wv["_amt"]
    w = min(w, gross - disc)
    credit = round_cents(Fraction(own_val) * 20 / 40000 * prorate) if sched["OWN_FUND_CD"] == "CRED" else 0
    credit = min(credit, gross - disc - w)
    net = gross - disc - w - credit
    return {"RUN_ID": run["RUN_ID"], "ASSIGN_ID": x["ASSIGN_ID"], "SCHED_ID": sched["SCHED_ID"],
            "ACCT_VALUE": amt(billable), "BILLABLE_ASSETS": amt(billable),
            "GROUP_ASSETS": amt(group_assets) if group_assets is not None else "", "RATE_BPS": bps4(rate),
            "GROSS_FEE": amt(gross), "DISCOUNT_AMT": amt(disc), "WAIVER_AMT": amt(w), "OWN_FUND_CREDIT": amt(credit),
            "NET_FEE": amt(net), "EXCEPTION_FLG": "false", "PRORATE_DAYS": str(days) if days else "",
            "WAIVER_IDS": "; ".join(wv["WAIVER_ID"] for wv in waivers),
            "_run": run, "_asg": x, "_sched": sched, "_billable": billable, "_own": own_val, "_group": group_assets,
            "_rate": rate, "_rate4": round_cents(rate * 10000), "_gross": gross, "_disc": disc, "_waiver": w,
            "_credit": credit, "_net": net, "_days": days, "_period_days": period_days}


def econ_billing(erng, f):
    """FEE_RUN, FEE_CALC, WAIVER and DEBIT: four regular quarterly runs, an onboarding and a termination pro-rata run,
    a recalculation, a simulation and a scheduled run; the planted off-schedule and household-breakpoint rows."""
    qval, qown = f["econ_qval"], f["econ_qown"]
    current = f["current_asg"]
    users = f["users"]
    approvers = [u["Id"] for u in users if u["UserRole.Name"] == "Supervisor"]
    # Group assets at a period end: the billing valuation of the group's active members (HH and LINK)
    def group_assets(x, q, own_override=None):
        gid = x["GROUP_ID"]
        if not gid:
            return None
        total = 0
        for mb in f["fee_members"]:
            if mb["GROUP_ID"] == gid and mb["STATUS_CD"] == "A" and mb["_from"] <= Q_END[q]:
                if own_override is not None and mb["ACCT_NO"] == x["ACCT_NO"]:
                    total += own_override
                else:
                    total += qval[(mb["ACCT_NO"], q)]
        return total
    def in_force(x, d):
        return x["_from"] <= d and (x["_to"] is None or x["_to"] >= d)
    # Onboarding (enrolled in Q2 2026) and termination (closed in Q3 2026) accounts
    q2_joiners = sorted([x for x in current if x["_enroll"] and Q_START["2026Q2"] <= x["_enroll"] <= Q_END["2026Q2"]],
                        key=lambda x: (x["_enroll"], x["ACCT_NO"]))[:6]
    leavers = [x for x in current if x["_acct"]["_close"] and Q_START["2026Q3"] <= x["_acct"]["_close"] <= Q_END["2026Q3"]]
    onb_ids = {x["ASSIGN_ID"] for x in q2_joiners}
    # Planted Q3 rows: 2 household-breakpoint misses, 4 off-schedule (2 over-, 2 underbilled)
    group_size = {}
    for mb in f["fee_members"]:
        if mb["STATUS_CD"] == "A":
            group_size[mb["GROUP_ID"]] = group_size.get(mb["GROUP_ID"], 0) + 1
    def live(x):
        return qval[(x["ACCT_NO"], "2026Q3")] > 0 and x["_acct"]["_status"] == "O" and x["ASSIGN_ID"] not in onb_ids
    bp_cands = []
    for x in current:
        if x["GROUP_ID"] and group_size[x["GROUP_ID"]] >= 2 and live(x) and x["_fam"] != "ADV-DIG":
            s = f["sched_by_id"][x["SCHED_ID"]]
            own = qval[(x["ACCT_NO"], "2026Q3")]
            if sched_rate(s, own) != sched_rate(s, group_assets(x, "2026Q3")):
                bp_cands.append(x)
    if len(bp_cands) < 2:
        raise SystemExit("fewer than two accounts can carry a household-breakpoint miss")
    breakpoint_ids = {x["ASSIGN_ID"] for x in erng.sample(bp_cands, 2)}
    plain = [x for x in current if live(x) and not x["GROUP_ID"]]
    over = erng.sample([x for x in plain if x["_fam"] == "ADV-STD"], 2)
    under = erng.sample([x for x in plain if x["_fam"] == "WMP-WRAP"], 2)
    off_ids = {x["ASSIGN_ID"] for x in over + under}
    special = breakpoint_ids | off_ids
    # Discounts (2 negotiated assignments, all four regular runs) and 3 more negotiated assignments
    steady = [x for x in current if live(x) and x["ASSIGN_ID"] not in special and x["_from"] <= Q_END["2025Q4"]]
    disc = erng.sample(steady, 2)
    disc_ids = {x["ASSIGN_ID"] for x in disc}
    for x in disc + erng.sample([x for x in current if x["ASSIGN_ID"] not in disc_ids], 3):
        x["NEGOTIATED_FLG"] = "true"
    # Waivers: 8 in force at AS_OF, 4 that ended in 2025
    wv_pool = [x for x in steady if x["ASSIGN_ID"] not in disc_ids]
    wv_targets = erng.sample(wv_pool, 12)
    W = [  # (start, end, pct, amount in dollars, reason, approved)
        (date(2025, 4, 1), None, 25, None, "PROMO", True), (date(2025, 10, 1), date(2026, 12, 31), 50, None, "SVC", True),
        (date(2026, 1, 1), None, 100, None, "EMP", True), (date(2026, 4, 1), date(2027, 3, 31), None, 300, "REL", True),
        (date(2026, 7, 1), date(2026, 12, 31), 25, None, "PROMO", False), (date(2025, 7, 1), None, 50, None, "REL", True),
        (date(2026, 7, 1), None, None, 150, "SVC", False), (date(2025, 1, 1), None, 100, None, "EMP", True),
        (date(2024, 7, 1), date(2025, 3, 31), 50, None, "PROMO", True),
        (date(2024, 10, 1), date(2025, 6, 30), 25, None, "SVC", True),
        (date(2025, 1, 1), date(2025, 9, 30), None, 200, "REL", True),
        (date(2025, 4, 1), date(2025, 12, 31), 100, None, "EMP", True)]
    waivers = []
    for i, ((start, end, pct, dollars, rsn, ok), x) in enumerate(zip(W, wv_targets)):
        waivers.append({"WAIVER_ID": "W-%05d" % (i + 1), "ASSIGN_ID": x["ASSIGN_ID"], "REASON_CD": rsn,
                        "PCT": str(pct) if pct is not None else "", "AMT": amt(dollars * 100) if dollars else "",
                        "START_DT": iso(start), "END_DT": iso(end),
                        "APPROVED_BY": erng.choice(approvers) if ok else "",
                        "_pct": pct, "_amt": dollars * 100 if dollars else None, "_start": start, "_end": end})
    def waivers_for(x, d):
        return [w for w in waivers if w["ASSIGN_ID"] == x["ASSIGN_ID"] and w["_start"] <= d
                and (w["_end"] is None or w["_end"] >= d)]
    # Runs
    runs, calcs = [], []
    def run(run_id, q, typ, status, recon, approved, start=None, end=None):
        r = {"RUN_ID": run_id, "PERIOD_START_DT": iso(start or Q_START[q]), "PERIOD_END_DT": iso(end or Q_END[q]),
             "RUN_TYPE_CD": typ, "VAL_DT": iso(end or Q_END[q]), "STATUS_CD": status, "RECON_CD": recon,
             "APPROVED_BY": erng.choice(approvers) if approved else "", "NET_FEE_TOTAL": "", "_q": q, "_calcs": []}
        runs.append(r)
        return r
    def add(r, row):
        calcs.append(row)
        r["_calcs"].append(row)
        return row
    q4 = run("R-2025Q4-01", "2025Q4", "REG", "REL", "REC", True)
    q1 = run("R-2026Q1-01", "2026Q1", "REG", "REL", "REC", True)
    q1r = run("R-2026Q1-02", "2026Q1", "RECALC", "APPR", "REC", True)
    q2 = run("R-2026Q2-01", "2026Q2", "REG", "REL", "EXPL", True)
    q2o = run("R-2026Q2-02", "2026Q2", "ONB", "REL", "REC", True)
    q3 = run("R-2026Q3-01", "2026Q3", "REG", "REL", "REC", True)
    q3t = run("R-2026Q3-02", "2026Q3", "TRM", "REL", "BRK", True)
    q3s = run("R-2026Q3-SIM", "2026Q3", "SIM", "CALC", "", False)
    run("R-2026Q4-01", None, "SCH", "SCH", "", False, date(2026, 10, 1), date(2026, 12, 31))
    for r in (q4, q1, q2, q3):
        q, end = r["_q"], Q_END[r["_q"]]
        for x in current:
            if not in_force(x, end) or (r is q2 and x["ASSIGN_ID"] in onb_ids):
                continue
            sched = f["sched_by_id"][x["SCHED_ID"]]
            ga = group_assets(x, q)
            if r is q3 and x["ASSIGN_ID"] in off_ids:
                sched = f["prior_sched"][x["_fam"]]
            if r is q3 and x["ASSIGN_ID"] in breakpoint_ids:
                ga = None
            row = add(r, econ_fee_calc(f, r, x, sched, qval[(x["ACCT_NO"], q)], qown[(x["ACCT_NO"], q)], ga,
                                       discount=x["ASSIGN_ID"] in disc_ids, waivers=waivers_for(x, end)))
            if r is q3 and x["ASSIGN_ID"] in off_ids:
                row["EXCEPTION_FLG"] = "true"
    q2_days = (Q_END["2026Q2"] - Q_START["2026Q2"]).days + 1
    for x in q2_joiners:
        days = (Q_END["2026Q2"] - x["_enroll"]).days + 1
        add(q2o, econ_fee_calc(f, q2o, x, f["sched_by_id"][x["SCHED_ID"]], qval[(x["ACCT_NO"], "2026Q2")],
                               qown[(x["ACCT_NO"], "2026Q2")], group_assets(x, "2026Q2"), days, q2_days,
                               waivers=waivers_for(x, Q_END["2026Q2"])))
    q3_days = (Q_END["2026Q3"] - Q_START["2026Q3"]).days + 1
    for x in leavers:
        a = x["_acct"]
        last = holding_months(a)[-1]
        billable, own_val = f["econ_val"].get((a["ACCT_NO"], last), 0), f["econ_own"].get((a["ACCT_NO"], last), 0)
        days = (a["_close"] - Q_START["2026Q3"]).days
        ga = group_assets(x, "2026Q3", billable) if x["GROUP_ID"] else None
        add(q3t, econ_fee_calc(f, q3t, x, f["sched_by_id"][x["SCHED_ID"]], billable, own_val, ga, days, q3_days,
                               waivers=waivers_for(x, Q_END["2026Q3"])))
    # The recalculation (4 Q1 calculations re-run, same result) and the simulation (20 Q3 calculations, never counted)
    normal_q1 = [c for c in q1["_calcs"] if c["_net"] > 0]
    for c in erng.sample(normal_q1, 4):
        add(q1r, dict(c, RUN_ID=q1r["RUN_ID"], _run=q1r))
    normal_q3 = [c for c in q3["_calcs"] if c["_net"] > 0 and c["ASSIGN_ID"] not in special]
    for c in sorted(erng.sample(normal_q3, 20), key=lambda c: c["ASSIGN_ID"]):
        add(q3s, dict(c, RUN_ID=q3s["RUN_ID"], _run=q3s))
    for r in runs:
        if r["RUN_TYPE_CD"] != "SCH":
            total = sum(c["_net"] for c in r["_calcs"]) + (125000 if r is q2 else 0)
            r["NET_FEE_TOTAL"], r["_total"] = amt(total), total
        else:
            r["_total"] = None
    # Debits: one per calculation with a fee of each released regular or pro-rata run
    debits = []
    for r in runs:
        if r["STATUS_CD"] != "REL":
            continue
        d = nth_bday_after(Q_END[r["_q"]], 5)
        for c in r["_calcs"]:
            if c["_net"] <= 0:
                continue
            x = c["_asg"]
            debits.append({"DEBIT_ID": "D-%s-%s" % (r["_q"], x["ASSIGN_ID"][3:]), "RUN_ID": r["RUN_ID"],
                           "ASSIGN_ID": x["ASSIGN_ID"], "FEE_TYPE_CD": c["_sched"]["SCHED_TYPE_CD"],
                           "ACCT_NO": x["PAY_ACCT_NO"], "DEBIT_DT": iso(d),
                           "STATUS_CD": "PEND" if d > date(2026, 9, 30) else "POST", "FAIL_RSN": "", "AMT": amt(c["_net"]),
                           "_d": d, "_amt": c["_net"], "_run": r})
    q2_debits = [d for d in debits if d["_run"] is q2]
    picks = erng.sample(q2_debits, 4)
    for d in picks[:3]:
        d["STATUS_CD"], d["FAIL_RSN"] = "FAIL", "insufficient cash"
    picks[3]["STATUS_CD"] = "REV"
    if len({d["DEBIT_ID"] for d in debits}) != len(debits):
        raise SystemExit("duplicate DEBIT_ID")
    f["fee_runs"], f["fee_calcs"], f["waivers"], f["debits"] = runs, calcs, waivers, debits
    f["off_ids"], f["breakpoint_ids"], f["onb_ids"] = off_ids, breakpoint_ids, onb_ids
    f["over_ids"] = {x["ASSIGN_ID"] for x in over}
    NOTES.append("Billing valuations: R-2026Q3-01 bills each account's total value at 2026-09-30 (brokerage positions "
                 "plus FCB, SWP and MDB cash, basis S: the certified Ending Client Assets of the account); the earlier "
                 "regular runs scale it by 0.92, 0.94 and 0.97 times (1 +/- 1.5 percent) per account, as the brief asks, "
                 "rather than reading the 2026-06-30 snapshot; an account closed in the window scales its last month-end "
                 "value, one closed earlier is billed on zero. Own-fund holdings for the credit are scaled the same way. "
                 "GROUP_ASSETS is the billing valuation of the group's active members (HH and LINK, effective at the period "
                 "end) whether or not they are billed in that run; proposed members do not count.")
    NOTES.append("Regular runs bill every assignment in force at the period end (rows per run: %s), except that the six "
                 "assignments starting in Q2 2026 are billed only by the onboarding run R-2026Q2-02 (PRORATE_DAYS = "
                 "days from the enrollment date to 2026-06-30 inclusive, over 91); assignments starting inside another "
                 "quarter are billed for the full quarter by that quarter's regular run. Only %d enrolled accounts close "
                 "in Q3 2026, so the termination run R-2026Q3-02 has %d calculations (the brief said 3): billed on the "
                 "account's last month-end value, PRORATE_DAYS = days from 2026-07-01 to the day before closing, over "
                 "92; those accounts are also in R-2026Q3-01 on a zero value."
                 % (", ".join("%s %d" % (r["RUN_ID"], len(r["_calcs"])) for r in (q4, q1, q2, q3)), len(leavers),
                    len(leavers)))
    NOTES.append("Fee arithmetic, in cents: rate = the exact blended rate of the applied version's tiers on GROUP_ASSETS "
                 "when present, else on BILLABLE_ASSETS (RATE_BPS written to four decimals); GROSS_FEE = round(billable x "
                 "exact rate / 10,000 / 4 x PRORATE_DAYS / days in period), rounded once, half up; discount = 10 percent "
                 "of gross; waiver = percentage of gross or the amount, capped at gross - discount; OWN_FUND_CREDIT = "
                 "own-fund holdings x 20 bps / 4 (pro-rated), capped at what is left; NET_FEE = gross - discount - "
                 "waiver - credit, so it is never below zero and always equals that difference.")
    NOTES.append("Runs: R-2026Q1-02 (RECALC, APPR) re-runs 4 Q1 calculations with the same result; R-2026Q3-SIM "
                 "(SIM, CALC) repeats 20 Q3 calculations; R-2026Q4-01 (SCH) has no calculations, no approver and a "
                 "blank NET_FEE_TOTAL. Runs are approved by a CRM Supervisor user. Debits are written only for "
                 "calculations with a positive net fee, dated the fifth business day after the period end (2026-01-01, "
                 "2026-04-03 and 2026-07-03 are holidays), which gives the brief's 2026-10-07 for Q3 and the schema's "
                 "2026-07-08 for Q2 (the brief's 'sixth' counts the period end); the Q3 debits are PEND, the 3 FAIL and "
                 "1 REV are among the Q2 regular run's, dated 2026-07-08 (so in Q3).")
    NOTES.append("Waivers: 12 on distinct current assignments (8 in force at 2026-09-30, 2 of them unapproved; 4 ended in "
                 "2025, one of which ended 2025-12-31 and so applies to R-2025Q4-01); a waiver applies to a calculation "
                 "when it is in force at the run's period end; an amount waiver is that amount per quarter. The 8 "
                 "discount rows are two negotiated assignments in each of the four regular runs; NEGOTIATED_FLG is "
                 "true on those two and three others (a flag only: no rate override). The 4 off-schedule rows are two "
                 "ADV-STD accounts billed on S-ADV-STD-2 (overbilled) and two WMP-WRAP accounts on S-WMP-WRAP-2 "
                 "(underbilled), with no group, waiver or discount; the 2 breakpoint misses are group members whose "
                 "own-asset rate differs from the group rate.")


def econ_client_revenue(erng, f, attrs, bl):
    """CLIENT_REV: fee revenue from the released regular and pro-rata runs (a third of each net fee a month), bank sweep
    fees, margin interest and commissions on self-directed option and bond trades."""
    rows = []
    def add(fm, a, stream, cents, offering, le, ref=""):
        seg = attrs[id(a)]["segment"]
        rows.append({"FISCAL_MONTH": fm, "ACCT_NO": a["ACCT_NO"], "STREAM_CD": stream, "OFFERING_CD": offering,
                     "CHANNEL_CD": a["_chan"], "BUS_LINE_CD": bl[a["_chan"]],
                     "SEGMENT_CD": "" if seg == UNATTRIBUTED else seg, "LEGAL_ENT_CD": le, "SOURCE_REF": ref,
                     "AMT": amt(cents), "BASIS_CD": "ACT", "_amt": cents, "_acct": a})
    for r in f["fee_runs"]:
        if r["STATUS_CD"] != "REL":
            continue
        for c in r["_calcs"]:
            if c["_billable"] <= 0:
                continue
            x = c["_asg"]
            stream = "TRST" if c["_sched"]["SCHED_TYPE_CD"] == "TRST" else "ADVF"
            parts = [c["_net"] // 3] * 3
            for i in range(c["_net"] - sum(parts)):
                parts[i] += 1
            for fm, p in zip(months_of(r["_q"]), parts):
                add(fm, x["_acct"], stream, p, x["PROGRAM_CD"], "TC" if x["PROGRAM_CD"] == "TRS" else "IA",
                    "%s|%s" % (r["RUN_ID"], x["ASSIGN_ID"]))
    # Sweep fees and margin interest on the prior month-end balance
    bal = {}
    for c in f["cash"]:
        if c["BAL_BASIS_CD"] == "S":
            bal[(c["ACCT_NO"], c["BAL_TYPE_CD"], c["_m"])] = c["_c"]
    fac = f["econ_fac"]
    for a in f["accts"]:
        no = a["ACCT_NO"]
        offering = a["_prog"] or "BRK"
        for fm in FISCAL_MONTHS:
            pme = prior_month_end(fm)
            if not a["_open"] or a["_open"] > pme:
                continue
            m = {"2026-07": 0, "2026-08": 1, "2026-09": 2}.get(fm)
            scale = 1.0 if m is not None else fac[no][quarter_of(fm)] / fac[no]["2026Q2"]
            for typ, stream, bps, le in (("SWP", "SWPF", 150, "BD"), ("MDB", "MGNI", 1250, "BD")):
                b = bal.get((no, typ, m if m is not None else 0))
                if b is None:
                    continue
                b = abs(b) if m is not None else int(round(abs(b) * scale))
                cents = round_cents(Fraction(b * bps, 120000))
                if b > 0 and cents > 0 and (typ == "SWP" or a["MARGIN_CD"] == "M"):
                    add(fm, a, stream, cents, offering if stream == "SWPF" else "BRK", le)
    # Commissions: Q3 from the posted self-directed option and bond trades; earlier months from the accounts holding them
    comm = {}
    reversed_ids = {r["REVERSAL_OF_TXN_ID"] for r in f["activity"] if r["STATUS_CD"] == "R"}
    for r in f["activity"]:
        s = r["_sec"]
        if r["STATUS_CD"] == "P" and r["TXN_ID"] not in reversed_ids and r["TXN_CD"] in ("BUY", "SEL") and s \
                and s["SEC_TYPE_CD"] in ("FI", "CD", "OPT") and r["_acct"]["_chan"] == "SD":
            units = abs(int(round(float(r["QTY"]))))
            cents = units * (65 if s["SEC_TYPE_CD"] == "OPT" else 100)
            k = (r["TRD_DT"][:4] + "-" + r["TRD_DT"][4:6], r["ACCT_NO"])
            comm[k] = comm.get(k, 0) + cents
    holders = {}
    for p in f["positions"]:
        if p["_m"] == 0 and p["_sec"]["SEC_TYPE_CD"] in ("FI", "CD", "OPT") and p["_acct"]["_chan"] == "SD":
            holders.setdefault(p["ACCT_NO"], set()).add(p["_sec"]["SEC_TYPE_CD"])
    for fm in FISCAL_MONTHS[:9]:
        for no in sorted(holders):
            a = f["acct_by_no"][no]
            if a["_open"] > prior_month_end(fm) or erng.random() >= 0.35:
                continue
            cents = 0
            for _ in range(erng.choice([1, 1, 2])):
                if "OPT" in holders[no] and erng.random() < 0.4:
                    cents += erng.randint(1, 10) * 65
                else:
                    cents += erng.randint(5, 60) * 100
            comm[(fm, no)] = comm.get((fm, no), 0) + cents
    for (fm, no), cents in comm.items():
        add(fm, f["acct_by_no"][no], "COMM", cents, "BRK", "BD")
    order = {s: i for i, s in enumerate(["ADVF", "WRAP", "TRST", "PLAN", "SUBS", "SVCF", "COMM", "MKUP", "MGNI", "FPLR",
                                         "SWPF", "ORP", "OTH"])}
    rows.sort(key=lambda r: (r["FISCAL_MONTH"], r["ACCT_NO"], order[r["STREAM_CD"]], r["SOURCE_REF"]))
    seq = {}
    for r in rows:
        seq[r["FISCAL_MONTH"]] = seq.get(r["FISCAL_MONTH"], 0) + 1
        r["REV_ID"] = "CR-%s-%06d" % (r["FISCAL_MONTH"], seq[r["FISCAL_MONTH"]])
    f["client_rev"] = rows
    NOTES.append("Client revenue: fee rows (ADVF for the ADV and WRAP schedules, as the brief says, TRST for TRS; "
                 "LEGAL_ENT_CD IA, TC for TRS) for every calculation of a released regular or pro-rata run with positive "
                 "billable assets (an amount of 0.00 when the fee is fully waived), split into cents so the three months "
                 "add exactly to NET_FEE (the first months take the extra cents). SWPF = the prior month-end SWP balance "
                 "(basis S) x 150 bps / 12; MGNI = the prior month-end MDB debit balance x 12.5 percent / 12 on every "
                 "margin account (the data has %d margin accounts with a debit balance, not 10 to 20); months before "
                 "2026-07 use the 2026-06-30 balance scaled by the account's billing quarter factors relative to Q2, "
                 "and only accounts open by the prior month-end earn them (accounts closed before the window, which "
                 "have no balances, earn none). COMM: Q3 from the posted BUY/SEL rows of self-directed accounts in "
                 "bonds and CDs ($1 a unit) or options ($0.65 a contract), one row per account and month; 2025-10 to "
                 "2026-06 from the self-directed accounts holding bonds, CDs or options at 2026-06-30 (a trade month "
                 "with probability 0.35). No SVCF rows: the brokerage FEE activity rows are all on advisory and trust "
                 "accounts, none on self-directed ones." % len(f["margin"]))


def econ_fund_revenue(erng, f):
    """FUND_REV: management fee revenue per own share class and fiscal month (September an estimate)."""
    rows = []
    waived = set(erng.sample([x["FUND_NO"] for x in f["funds"]], 8))
    subadv = {no: "SAE-%03d" % (i + 1) for i, no in enumerate(sorted(erng.sample(
        [x["FUND_NO"] for x in f["funds"] if x["ASSET_CLS_CD"] in ("EQ", "FI")], 3)))}
    ta_basis = set(erng.sample([x["FUND_NO"] for x in f["funds"]], 6))
    for x in f["funds"]:
        name, acls = x["FUND_NM"], x["ASSET_CLS_CD"]
        if acls == "MM":
            lo, hi = 15, 15
        elif "Retirement Path" in name:
            lo, hi = 10, 20
        elif "Index" in name:
            lo, hi = 5, 10
        elif acls == "FI":
            lo, hi = 25, 40
        else:
            lo, hi = 35, 60
        rate = erng.randint(lo, hi)
        median = 900_000_000 if x["CLASS_CD"] == "INST" else 400_000_000
        assets = lognormal_cents(erng, median, 0.45)
        wpct = Fraction(erng.randint(20, 60), 1000) if x["FUND_NO"] in waived else Fraction(0)
        for fm in FISCAL_MONTHS:
            gross = round_cents(Fraction(assets * rate, 120000))
            offset = round_cents(gross * wpct)
            net = gross - offset
            sub = round_cents(Fraction(net, 5)) if x["FUND_NO"] in subadv else 0
            rows.append({"REV_ID": "FR-%s-%s" % (fm, x["FUND_NO"]), "FISCAL_MONTH": fm, "FUND_NO": x["FUND_NO"],
                         "CLASS_CD": x["CLASS_CD"], "AVG_NET_ASSETS": amt(assets),
                         "BASIS_SRC_CD": "TA" if x["FUND_NO"] in ta_basis else "FA", "GROSS_RATE_BPS": str(rate),
                         "GROSS_FEE": amt(gross), "WAIVER_OFFSET": amt(offset), "NET_FEE": amt(net),
                         "BASIS_CD": "EST" if fm == "2026-09" else "FIN", "SUBADV_FEE": amt(sub),
                         "SUBADV_ENG_ID": subadv.get(x["FUND_NO"], ""),
                         "_assets": assets, "_gross": gross, "_offset": offset, "_net": net})
            assets = int(assets * (1 + erng.choice([-1, 1]) * erng.uniform(0.01, 0.02)))
    f["fund_rev"] = rows
    NOTES.append("Fund revenue: one row per FUND_MASTER class (all %d, INST classes around 900 million, the rest around "
                 "400 million) and month; rates by product type (money market 15, index 5 to 10, target-date 10 to 20, "
                 "bond 25 to 40, equity and the balanced fund 35 to 60 bps); 8 classes carry a waiver offset of 2 to 6 "
                 "percent of gross; 3 equity or bond classes a sub-advisory fee of 20 percent of net (SAE-001 to "
                 "SAE-003); 6 classes take their asset basis from the transfer agent (BASIS_SRC_CD TA)."
                 % len(f["funds"]))


def econ_member_revenue(f, facts, attrs):
    """Gross revenue per fiscal month, grain (SEG, CHAN, BL, OFF) and member: the member's client revenue plus the
    month's fund net fee revenue attributed by the member's share of own-fund holdings (rounded once, per member)."""
    ch = f["channels"]
    brk = {id(a) for a in f["accts"]}
    ov = {}
    for m, acct, v, ht, sc, is_own in facts:
        if not is_own:
            continue
        a = attrs[id(acct)]
        off = ((acct["_prog"] or "BRK") if id(acct) in brk else UNATTRIBUTED)
        for g, member in (("SEG", a["segment"]), ("CHAN", a["channel"]), ("BL", a["bl"]), ("OFF", off)):
            ov[(m, g, member)] = ov.get((m, g, member), 0) + v
        ov[(m, "ALL", "ALL")] = ov.get((m, "ALL", "ALL"), 0) + v
    client = {}
    for r in f["client_rev"]:
        for g, member in (("SEG", r["SEGMENT_CD"] or UNATTRIBUTED), ("CHAN", ch[r["CHANNEL_CD"]]),
                          ("BL", r["BUS_LINE_CD"]), ("OFF", r["OFFERING_CD"])):
            k = (r["FISCAL_MONTH"], g, member)
            client[k] = client.get(k, 0) + r["_amt"]
    fund_net = {}
    for r in f["fund_rev"]:
        fund_net[r["FISCAL_MONTH"]] = fund_net.get(r["FISCAL_MONTH"], 0) + r["_net"]
    rev = {}
    for fm in FISCAL_MONTHS:
        m = overlap_month(fm)
        for g in ("SEG", "CHAN", "BL", "OFF"):
            members = {k[2] for k in ov if k[0] == m and k[1] == g} | {k[2] for k in client if k[0] == fm and k[1] == g}
            for member in members:
                share = Fraction(fund_net[fm] * ov.get((m, g, member), 0), ov[(m, "ALL", "ALL")])
                rev[(fm, g, member)] = round_cents(client.get((fm, g, member), 0) + share)
    f["econ_overlap"], f["econ_rev"] = ov, rev
    NOTES.append("Profitability gross revenue = the member's CLIENT_REV (SEGMENT_CD, blank -> UNATTRIBUTED; CHANNEL_CD "
                 "mapped to the certified channel key; BUS_LINE_CD; OFFERING_CD) + the month's total FUND_REV.NET_FEE x "
                 "the member's own-fund holdings / all own-fund holdings, at the month-end of the month (2026-07 to "
                 "2026-09) or 2026-06-30 for earlier months, from the certified family's counted rows (own_fund_overlap_"
                 "amount by Channel and Business Line; for Segment and Offering the same rows grouped by the household's "
                 "segment and the brokerage account's program, BRK when none; everything else UNATTRIBUTED); the sum is "
                 "rounded once to the cent per month, grain and member.")


def econ_mkt_weights(f):
    """Marketing driver weights for SEG and OFF, set from revenue so that Core and PLN cost more than they earn and every
    other own segment and offering earns more than its marketing cost (the planted negative cuts)."""
    rev = f["econ_rev"]
    def total(g, member):
        return sum(rev.get((fm, g, member), 0) for fm in FISCAL_MONTHS)
    seg = {m: total("SEG", m) for m in SEG_MEMBERS}
    off = {m: total("OFF", m) for m in OFF_MEMBERS}
    others_seg = sum(v for k, v in seg.items() if k != "Core")
    others_off = sum(v for k, v in off.items() if k not in ("PLN", "HYB"))
    target = min(MKT_CORE_RATIO * seg["Core"] + Fraction(45, 100) * others_seg,
                 Fraction(55, 100) * others_off / (1 - MKT_PLN_SHARE))
    if target <= MKT_CORE_RATIO * seg["Core"] * Fraction(11, 10):
        raise SystemExit("cannot size marketing cost so that only Core is negative")
    return target, seg, off


def econ_costs(erng, f):
    """POOL, METHOD, RULE, RUN, POOL_COST and RESULT: eleven pools, the CORP step-down, about 40 rules, a final actual run
    per month plus a superseded June run and a September budget run."""
    rev_total = sum(r["_amt"] for r in f["client_rev"]) + sum(r["_net"] for r in f["fund_rev"])
    opex = rev_total * 55 // 100
    mkt_target, seg_rev, off_rev = econ_mkt_weights(f)
    weights = {p[0]: p[5] for p in POOLS}
    non_mkt_w = sum(w for w in weights.values() if w)
    s_mkt = 0
    for _ in range(20):    # MKT's source cost so its allocable cost (with its CORP share, less residual) hits the target
        corp = (opex - s_mkt) * weights["CORP"] / non_mkt_w
        s_mkt = float(mkt_target) / 0.99 - corp * CORP_SHARES["MKT"] / 10000
    annual = {p: (s_mkt if p == "MKT" else (opex - s_mkt) * w / non_mkt_w) for p, w in weights.items()}
    monthly = {}
    for p, _, _, _, _, _ in POOLS:
        path = [1.0]
        for _ in range(11):
            path.append(path[-1] * (1 + erng.choice([-1, 1]) * erng.uniform(0.03, 0.08)))
        mean = sum(path) / 12
        monthly[p] = [int(round(annual[p] / 12 * x / mean)) for x in path]
    pools = [{"POOL_ID": "CP-" + t, "POOL_NM": n, "POOL_TYPE_CD": t, "CTS_COMP_CD": c, "COST_CENTERS": cc,
              "CATEGORIES": cat} for t, n, c, cc, cat, _ in POOLS]
    methods = [{"METHOD_ID": a, "METHOD_NM": b, "METHOD_TYPE_CD": c} for a, b, c in
               [("M-DIR", "Direct assignment", "DIRECT"), ("M-DRV", "Driver-based", "DRIVER"),
                ("M-ABC", "Activity-based", "ABC"), ("M-REV", "Proportional to revenue", "REV"),
                ("M-STEP", "Step-down", "STEP")]]
    rules = []
    def rule(p, dim, seq):
        meth, drv = POOL_METHOD[p]
        r = {"RULE_ID": "AR-%04d" % (len(rules) + 1), "POOL_ID": "CP-" + p, "METHOD_ID": meth, "DRIVER_CD": drv,
             "TARGET_DIM_CD": dim, "SEQ_NO": str(seq), "EFF_FROM_DT": iso(date(2025, 1, 1)), "EFF_TO_DT": "",
             "_pool": p, "_dim": dim}
        rules.append(r)
    for p, _, _, _, _, _ in POOLS:
        if p == "CORP":
            continue
        if p == "DIST":
            dims = ["CHAN", "BL"]
        else:
            dims = ["SEG", "CHAN", "BL", "OFF"] + (["TIER"] if p in ("ADV", "SVC") else [])
        for dim in dims:
            rule(p, dim, 10)
    rule("CORP", "POOL", 1)
    # Marketing base weights from revenue
    A = mkt_target
    core_w = MKT_CORE_RATIO * seg_rev["Core"] / A
    others_seg = sum(v for k, v in seg_rev.items() if k != "Core")
    others_off = sum(v for k, v in off_rev.items() if k not in ("PLN", "HYB"))
    mkt_base = {"SEG": [core_w] + [(1 - core_w) * seg_rev[m] / others_seg for m in SEG_MEMBERS[1:]],
                "OFF": [(1 - MKT_PLN_SHARE) * off_rev[m] / others_off if m not in ("PLN", "HYB") else
                        (MKT_PLN_SHARE if m == "PLN" else 0) for m in OFF_MEMBERS]}
    def base(p, dim):
        if p == "DIST":
            return [1 if m in ("INTERMEDIARY", "IC") else 0 for m in DIM_MEMBERS[dim]]
        if p == "MKT" and dim in mkt_base:
            return [float(x) for x in mkt_base[dim]]
        return DRIVER_BASE[dim][p]
    runs, pool_costs, results = [], [], []
    alloc = {}     # (run_id, pool, dim, member) -> cents
    def allocate(run_id, fm, version, status, costs, noise):
        total = sum(costs.values())
        resid = int(round(total * erng.uniform(0.005, 0.015)))
        runs.append({"RUN_ID": run_id, "FISCAL_MONTH": fm, "VERSION_CD": version, "STATUS_CD": status,
                     "RESIDUAL_AMT": amt(resid), "_resid": resid, "_fm": fm})
        for p, _, _, _, _, _ in POOLS:
            pool_costs.append({"RUN_ID": run_id, "POOL_ID": "CP-" + p, "SOURCE_COST": amt(costs[p]),
                               "_pool": p, "_c": costs[p]})
        targets = [p for p, _, _, _, _, _ in POOLS if p != "CORP"]
        corp_parts = split_exact(costs["CORP"], [CORP_SHARES[p] for p in targets])
        corp_rule = [r for r in rules if r["_pool"] == "CORP"][0]
        for p, c in zip(targets, corp_parts):
            results.append({"RUN_ID": run_id, "RULE_ID": corp_rule["RULE_ID"], "TARGET_DIM_CD": "POOL",
                            "TARGET_MEMBER": "CP-" + p, "DRIVER_SHARE": pct2(CORP_SHARES[p]), "AMT": amt(c),
                            "_run": run_id, "_pool": "CORP", "_dim": "POOL", "_member": "CP-" + p, "_share": CORP_SHARES[p],
                            "_amt": c})
        loaded = [costs[p] + c for p, c in zip(targets, corp_parts)]
        resid_parts = split_exact(resid, loaded)
        allocable = {p: l - r for p, l, r in zip(targets, loaded, resid_parts)}
        for r in rules:
            p, dim = r["_pool"], r["_dim"]
            if p == "CORP":
                continue
            w = [x * (1 + erng.uniform(-noise, noise)) if x else 0 for x in base(p, dim)]
            shares = split_exact(10000, [int(round(x * 1_000_000)) for x in w])
            amts = split_exact(allocable[p], shares)
            for member, s, c in zip(DIM_MEMBERS[dim], shares, amts):
                results.append({"RUN_ID": run_id, "RULE_ID": r["RULE_ID"], "TARGET_DIM_CD": dim, "TARGET_MEMBER": member,
                                "DRIVER_SHARE": pct2(s), "AMT": amt(c), "_run": run_id, "_pool": p, "_dim": dim,
                                "_member": member, "_share": s, "_amt": c})
                alloc[(run_id, p, dim, member)] = c
        return allocable
    final = {}
    allocables = {}
    for i, fm in enumerate(FISCAL_MONTHS):
        costs = {p: monthly[p][i] for p in monthly}
        if fm == "2026-06":
            prelim = {p: int(round(c * (1 + erng.uniform(-0.02, 0.02)))) for p, c in costs.items()}
            allocate("ALR-2026-06-ACT-1", fm, "ACT", "SUPER", prelim, 0.03)
            run_id = "ALR-2026-06-ACT-2"
        else:
            run_id = "ALR-%s-ACT-1" % fm
        allocables[run_id] = allocate(run_id, fm, "ACT", "FINAL", costs, 0.03)
        final[fm] = run_id
    budget = {p: int(round(monthly[p][11] * erng.uniform(0.98, 1.06))) for p in monthly}
    allocate("ALR-2026-09-BUD-1", "2026-09", "BUD", "FINAL", budget, 0.03)
    f["pools"], f["methods"], f["rules"], f["alloc_runs"] = pools, methods, rules, runs
    f["pool_costs"], f["alloc_results"], f["alloc"], f["final_run"] = pool_costs, results, alloc, final
    f["allocables"] = allocables
    ann = {p: sum(monthly[p]) for p in monthly}
    order = sorted(ann, key=lambda p: -ann[p])
    f["econ_opex"], f["econ_rev_total"] = sum(ann.values()), rev_total
    NOTES.append("Cost pools: annual operating expense %s is %.1f percent of annual gross revenue %s (client revenue plus "
                 "fund net fee revenue); pools by annual cost: %s. Each pool varies 3 to 8 percent month to month. The "
                 "marketing pool is sized from revenue (its allocable cost is about %.2f times Core's revenue plus 0.45 "
                 "times the other segments'), and its SEG and OFF driver shares are set so Core's marketing cost is 1.3 "
                 "times its revenue and PLN takes 5 percent (it has no revenue: PLN-FLAT bills no account here); the "
                 "other segments and offerings get the rest in proportion to their revenue."
                 % (amt(f["econ_opex"]), 100.0 * f["econ_opex"] / rev_total, amt(rev_total),
                    ", ".join("%s %s" % (p, amt(ann[p])) for p in order), float(MKT_CORE_RATIO)))
    NOTES.append("Allocation: the CORP rule (AR-0041, STEP, SEQ_NO 1, TARGET_DIM_CD POOL) spreads CORP's whole cost to the "
                 "ten other pools by fixed shares; RUN.RESIDUAL_AMT (0.5 to 1.5 percent of the month's total pool cost) "
                 "is taken from the ten pools in proportion to their cost plus CORP share; every rule of a pool then "
                 "allocates the same allocable cost (cost + CORP share - residual share) to its dimension's members by "
                 "driver shares written to hundredths of a percent that add to exactly 100, the amounts split to the cent "
                 "by largest remainder. DIST has only two rules (DIRECT, 100 percent to INTERMEDIARY and to IC): the "
                 "intermediary business has no segment, offering or tier, so DIST carries no SEG or OFF rule and the "
                 "profitability of segments and offerings has no distribution payments. ADV and SVC also allocate to "
                 "TIER (T1 to T4). HYB is a member of every OFF rule with a zero share: no account is in the HYB "
                 "program, so it has no revenue and no cost, and its contribution margin is zero (not positive, as the "
                 "brief asked; it is not negative either). 41 rules in all. The superseded June run "
                 "(ALR-2026-06-ACT-1) allocated preliminary pool costs; the budget run (ALR-2026-09-BUD-1) is the "
                 "September budget.")


def econ_derived(f):
    """Cost to serve and profitability per fiscal month, grain and member, from the final actual runs."""
    alloc, rev = f["alloc"], f["econ_rev"]
    comp = {p: name for p, name in CTS_COMPONENTS}
    pool_comp = {t: comp.get(c) for t, _, c, _, _, _ in POOLS}
    cts, prof = [], []
    for fm in FISCAL_MONTHS:
        run_id = f["final_run"][fm]
        for g in ("SEG", "CHAN", "BL", "OFF", "TIER"):
            for member in DIM_MEMBERS[g]:
                row = {"fiscal_month": fm, "grain": g, "grain_name": GRAIN_NAMES[g], "member": member}
                tot = 0
                for name in CTS_NAMES:
                    c = sum(alloc.get((run_id, p, g, member), 0) for p in pool_comp if pool_comp[p] == name)
                    row[name] = c
                    tot += c
                row["total"] = tot
                cts.append(row)
        for g in ("SEG", "CHAN", "BL", "OFF"):
            members = list(DIM_MEMBERS[g]) + sorted({k[2] for k in rev if k[0] == fm and k[1] == g} - set(DIM_MEMBERS[g]))
            for member in members:
                gross = rev.get((fm, g, member), 0)
                dist = alloc.get((run_id, "DIST", g, member), 0)
                mkt = alloc.get((run_id, "MKT", g, member), 0)
                ind = sum(alloc.get((run_id, p, g, member), 0) for p in pool_comp if p not in ("DIST", "MKT", "CORP"))
                prof.append({"fiscal_month": fm, "grain": g, "grain_name": GRAIN_NAMES[g], "member": member,
                             "gross_revenue": gross, "distribution_payments": dist,
                             "net_revenue_after_distribution_costs": gross - dist, "direct_sales_marketing_cost": mkt,
                             "contribution_margin": gross - dist - mkt, "allocated_indirect_cost": ind,
                             "operating_profit": gross - dist - mkt - ind})
    f["cts"], f["prof"] = cts, prof
    NOTES.append("cost_to_serve: per fiscal month, grain (SEG, CHAN, BL, OFF, TIER) and member, the final actual run's "
                 "allocations from the pools with a cost-to-serve component: coverage_and_servicing (ADV), client_service "
                 "(SVC), platform_and_technology (PLAT), clearing_and_custody (CLR), money_movement (MM), "
                 "communications_and_regulatory (COMM and COMP, component REG); total = the six. profitability: "
                 "distribution_payments = DIST allocations, direct_sales_marketing_cost = MKT, allocated_indirect_cost = "
                 "ADV, SVC, PLAT, CLR, MM, COMM, COMP and PROD (CORP reaches them through the step-down); members are the "
                 "rule members plus UNATTRIBUTED, which carries revenue only. The institutional and intermediary members "
                 "show fund revenue only and so a negative operating profit, as expected.")


def econ_planted(f):
    """The economics planted facts and lists."""
    q3m = months_of("2026Q3")
    q3_runs = [r for r in f["fee_runs"] if r["PERIOD_END_DT"] >= "2026-07-01" and r["PERIOD_END_DT"] <= "2026-09-30"]
    tested = [r for r in q3_runs if r["STATUS_CD"] in ("APPR", "REL") and r["RUN_TYPE_CD"] != "SIM"]
    tested_ids = {r["RUN_ID"] for r in tested}
    def failed(r):
        return r["RECON_CD"] in ("BRK", "NR") or (r["STATUS_CD"] == "REL" and not r["APPROVED_BY"]) or \
            abs(r["_total"] - sum(c["_net"] for c in r["_calcs"])) > 1
    billed = [c for r in q3_runs if r["STATUS_CD"] == "REL" and r["RUN_TYPE_CD"] != "SIM" for c in r["_calcs"]]
    off = [c for c in billed if c["_run"]["RUN_ID"] == "R-2026Q3-01" and c["ASSIGN_ID"] in f["off_ids"]]
    def reperformed(c):
        s = f["sched_by_id"][c["_asg"]["SCHED_ID"]]
        rate = sched_rate(s, c["_group"] if c["_group"] is not None else c["_billable"])
        prorate = Fraction(c["_days"], c["_period_days"]) if c["_days"] else 1
        return round_cents(Fraction(c["_billable"]) * rate / 40000 * prorate)
    variance = sum(c["_net"] - (reperformed(c) - c["_disc"] - c["_waiver"] - c["_credit"]) for c in off)
    active_members = {}
    for mb in f["fee_members"]:
        if mb["STATUS_CD"] == "A" and mb["_from"] <= date(2026, 9, 30):
            active_members.setdefault(mb["GROUP_ID"], set()).add(mb["ACCT_NO"])
    member_of = {no: g for g, nos in active_members.items() for no in nos}
    bp = [c for c in billed if c["_group"] is None and c["_asg"]["ACCT_NO"] in member_of
          and len(active_members[member_of[c["_asg"]["ACCT_NO"]]]) >= 2]
    rev_q3 = [r for r in f["client_rev"] if r["FISCAL_MONTH"] in q3m]
    fund_q3 = [r for r in f["fund_rev"] if r["FISCAL_MONTH"] in q3m]
    client_fee = sum(r["_amt"] for r in rev_q3 if r["STREAM_CD"] in FEE_STREAMS)
    fund_gross, fund_net = sum(r["_gross"] for r in fund_q3), sum(r["_net"] for r in fund_q3)
    fund_offset = sum(r["_offset"] for r in fund_q3)
    calc_by_ref = {"%s|%s" % (c["RUN_ID"], c["ASSIGN_ID"]): c for c in f["fee_calcs"]}
    def eff_rate(rows):
        fee = sum(r["_amt"] for r in rows if r["STREAM_CD"] in ("ADVF", "WRAP", "TRST"))
        refs = {r["SOURCE_REF"] for r in rows if r["STREAM_CD"] in ("ADVF", "WRAP", "TRST") and r["SOURCE_REF"]}
        base = sum(calc_by_ref[x]["_billable"] for x in refs)
        return Fraction(fee * 12 * 10000, 3 * base) if base else None
    by_off = {}
    for r in rev_q3:
        by_off.setdefault(r["OFFERING_CD"], []).append(r)
    eff_off = {o: round(float(eff_rate(rows)), 6) for o, rows in sorted(by_off.items()) if eff_rate(rows) is not None}
    sum_billable = sum(c["_billable"] for c in billed)
    final_q3 = [f["final_run"][fm] for fm in q3m]
    allocated = sum(r["_amt"] for r in f["alloc_results"] if r["_run"] in final_q3 and r["_dim"] == "CHAN")
    resid = sum(r["_resid"] for r in f["alloc_runs"] if r["RUN_ID"] in final_q3)
    cts_q3 = sum(r["total"] for r in f["cts"] if r["fiscal_month"] in q3m and r["grain"] == "SEG")
    prof_q3 = [r for r in f["prof"] if r["fiscal_month"] in q3m and r["grain"] == "BL"]
    negative = econ_negative_cuts(f)
    asof = date(2026, 9, 30)
    planted = {
        "CLIENT_FEE_REVENUE_Q3": client_fee / 100,
        "CLIENT_REVENUE_Q3": sum(r["_amt"] for r in rev_q3) / 100,
        "FUND_GROSS_FEE_REVENUE_Q3": fund_gross / 100,
        "FUND_NET_FEE_REVENUE_Q3": fund_net / 100,
        "GROSS_FEE_REVENUE_Q3": (client_fee + fund_gross) / 100,
        "NET_FEE_REVENUE_Q3": (client_fee + fund_gross - fund_offset) / 100,
        "NET_BILLED_FEES_Q3": sum(c["_net"] for c in billed) / 100,
        "GROSS_BILLED_FEES_Q3": sum(c["_gross"] for c in billed) / 100,
        "BILLABLE_ASSETS_BILLED_Q3": sum_billable / 100,
        "AVERAGE_EFFECTIVE_RATE_BPS_Q3": round(float(Fraction(sum(c["_rate4"] * c["_billable"] for c in billed),
                                                              10000 * sum_billable)), 6),
        "EFFECTIVE_NET_FEE_RATE_BPS_Q3": round(float(eff_rate(rev_q3)), 6),
        "FEE_RUNS_TESTED_Q3": len(tested),
        "FAILED_FEE_RUNS_Q3": sum(1 for r in tested if failed(r)),
        "ACCOUNTS_BILLED_OFF_SCHEDULE_Q3": len({c["ASSIGN_ID"] for c in billed if c["SCHED_ID"] != c["_asg"]["SCHED_ID"]}),
        "BILLING_VARIANCE_Q3": variance / 100,
        "HOUSEHOLD_BREAKPOINT_NOT_APPLIED_Q3": len(bp),
        "FAILED_FEE_DEBITS_Q3": sum(1 for d in f["debits"] if d["STATUS_CD"] == "FAIL" and
                                    date(2026, 7, 1) <= d["_d"] <= asof),
        "FAILED_FEE_DEBIT_AMOUNT_Q3": sum(d["_amt"] for d in f["debits"] if d["STATUS_CD"] == "FAIL" and
                                          date(2026, 7, 1) <= d["_d"] <= asof) / 100,
        "ACTIVE_FEE_WAIVERS": sum(1 for w in f["waivers"] if w["_start"] <= asof and (w["_end"] is None or w["_end"] >= asof)),
        "ACTIVE_FEE_SCHEDULE_VERSIONS": sum(1 for s in f["schedules"] if s["STATUS_CD"] == "A" and s["_from"] <= asof
                                            and (s["_to"] is None or s["_to"] >= asof)),
        "ACTIVE_FEE_SCHEDULE_ASSIGNMENTS": sum(1 for x in f["assignments"] if x["_from"] <= asof
                                               and (x["_to"] is None or x["_to"] >= asof)),
        "FEE_HOUSEHOLD_MEMBER_ACCOUNTS": len({no for g in f["fee_groups"] if g["STATUS_CD"] == "A"
                                              for no in active_members.get(g["GROUP_ID"], ())}),
        "TOTAL_COST_TO_SERVE_Q3": cts_q3 / 100,
        "ALLOCATED_COST_Q3": allocated / 100,
        "UNALLOCATED_RESIDUAL_Q3": resid / 100,
        "GROSS_REVENUE_Q3": sum(r["gross_revenue"] for r in prof_q3) / 100,
        "CONTRIBUTION_MARGIN_Q3": sum(r["contribution_margin"] for r in prof_q3) / 100,
        "OPERATING_PROFIT_Q3": sum(r["operating_profit"] for r in prof_q3) / 100,
        "NEGATIVE_CONTRIBUTION_CUTS": len(negative),
    }
    fee_runs = [{"run_id": r["RUN_ID"], "run_type_cd": r["RUN_TYPE_CD"], "status_cd": r["STATUS_CD"],
                 "recon_cd": r["RECON_CD"] or None,
                 "net_fee_total": r["_total"] / 100 if r["_total"] is not None else None,
                 "calc_net_fee_sum": sum(c["_net"] for c in r["_calcs"]) / 100, "calculations": len(r["_calcs"]),
                 "tested_q3": r["RUN_ID"] in tested_ids, "failed_q3": r["RUN_ID"] in tested_ids and failed(r)}
                for r in f["fee_runs"]]
    crm = {}
    for r in f["client_rev"]:
        k = (r["FISCAL_MONTH"], r["STREAM_CD"])
        crm[k] = crm.get(k, 0) + r["_amt"]
    client_months = [{"fiscal_month": k[0], "stream_cd": k[1], "amount": v / 100} for k, v in sorted(crm.items())]
    fund_months = []
    for fm in FISCAL_MONTHS:
        rows = [r for r in f["fund_rev"] if r["FISCAL_MONTH"] == fm]
        fund_months.append({"fiscal_month": fm, "gross": sum(r["_gross"] for r in rows) / 100,
                            "offset": sum(r["_offset"] for r in rows) / 100, "net": sum(r["_net"] for r in rows) / 100,
                            "avg_assets": sum(r["_assets"] for r in rows) / 100})
    money = ("gross_revenue", "distribution_payments", "net_revenue_after_distribution_costs",
             "direct_sales_marketing_cost", "contribution_margin", "allocated_indirect_cost", "operating_profit")
    prof = [dict(r, **{k: r[k] / 100 for k in money}) for r in f["prof"]]
    cts = [dict(r, **{k: r[k] / 100 for k in CTS_NAMES + ["total"]}) for r in f["cts"]]
    lists = {"fee_runs": fee_runs, "client_revenue_months": client_months, "fund_revenue_months": fund_months,
             "profitability": prof, "cost_to_serve": cts, "effective_rate_by_offering_q3": eff_off,
             "negative_contribution_cuts": negative}
    NOTES.append("Economics planted facts are for fiscal Q3 2026 (2026-07 to 2026-09). The billed set is the released, "
                 "non-simulation runs with period end in Q3 (R-2026Q3-01 and the termination run R-2026Q3-02). "
                 "AVERAGE_EFFECTIVE_RATE_BPS_Q3 weights the written four-decimal RATE_BPS by billable assets. "
                 "EFFECTIVE_NET_FEE_RATE_BPS_Q3 = the Q3 ADVF + WRAP + TRST revenue x 12 / 3 x 10,000 / the billable "
                 "assets of the distinct calculations those rows cite (effective_rate_by_offering_q3 the same per "
                 "OFFERING_CD). A failed run is a tested run whose RECON_CD is BRK or NR, released without an approver, "
                 "or whose NET_FEE_TOTAL differs from its calculations by more than a cent; R-2026Q2-01 is 1,250.00 over "
                 "(RECON_CD EXPL) but is not a Q3 run. BILLING_VARIANCE_Q3 = the sum over the 4 off-schedule rows of "
                 "NET_FEE - (gross re-performed on the in-force version's tiers on the same assets - the same discount, "
                 "waiver and credit). HOUSEHOLD_BREAKPOINT_NOT_APPLIED_Q3 counts billed Q3 calculations with a blank "
                 "GROUP_ASSETS whose account is an active member of a group with two or more active members.")
    NOTES.append("ALLOCATED_COST_Q3 counts each pool's allocation once: the Q3 final actual runs' results at one grain "
                 "(CHAN, the grain every non-CORP pool allocates to), excluding the pool-to-pool step-down rows, so "
                 "ALLOCATED_COST_Q3 + UNALLOCATED_RESIDUAL_Q3 = the three months' POOL_COST. Summing RESULT over every "
                 "rule instead would count a pool once per dimension (%s for Q3). TOTAL_COST_TO_SERVE_Q3 is at segment "
                 "grain; GROSS_REVENUE_Q3, CONTRIBUTION_MARGIN_Q3 and OPERATING_PROFIT_Q3 at business-line grain (all "
                 "members). NEGATIVE_CONTRIBUTION_CUTS counts the own offerings (DAP, PAS, WMP, TRS, HYB, PLN, BRK) and "
                 "segments (Core, Select, Private, Flagship) whose contribution margin over the trailing four fiscal "
                 "quarters (2025-10 to 2026-09) is below zero (listed in negative_contribution_cuts)."
                 % amt(sum(r["_amt"] for r in f["alloc_results"] if r["_run"] in final_q3 and r["_dim"] != "POOL")))
    return planted, lists


def econ_negative_cuts(f):
    """Own offerings and segments with a negative contribution margin over the trailing four quarters."""
    cm = {}
    for r in f["prof"]:
        if (r["grain"] == "OFF" and r["member"] in OFF_MEMBERS) or (r["grain"] == "SEG" and r["member"] in SEG_MEMBERS):
            k = (r["grain"], r["member"])
            cm[k] = cm.get(k, 0) + r["contribution_margin"]
    return sorted(m for (g, m), v in cm.items() if v < 0)


def econ_failures(f, tables, planted):
    """The economics addendum's checks."""
    fails = []
    for r in f["fee_runs"]:
        if r["_total"] is None:
            continue
        s = sum(c["_net"] for c in r["_calcs"])
        want = s + (125000 if r["RUN_ID"] == "R-2026Q2-01" else 0)
        if r["_total"] != want:
            fails.append("FEE_RUN %s: NET_FEE_TOTAL %d, calculations %d" % (r["RUN_ID"], r["_total"], s))
    for c in f["fee_calcs"]:
        if c["_net"] != c["_gross"] - c["_disc"] - c["_waiver"] - c["_credit"] or c["_net"] < 0:
            fails.append("FEE_CALC %s %s: net is not gross - reductions" % (c["RUN_ID"], c["ASSIGN_ID"]))
        if c["_run"]["RUN_ID"] != "R-2026Q3-01" or c["ASSIGN_ID"] in f["off_ids"] | f["breakpoint_ids"]:
            continue
        x = c["_asg"]
        s = f["sched_by_id"][x["SCHED_ID"]]
        if not (s["_from"] <= date(2026, 9, 30) and (s["_to"] is None or s["_to"] >= date(2026, 9, 30))) \
                or c["SCHED_ID"] != x["SCHED_ID"]:
            fails.append("FEE_CALC %s: not on the in-force version" % c["ASSIGN_ID"])
        rate = sched_rate(s, c["_group"] if c["_group"] is not None else c["_billable"])
        if c["RATE_BPS"] != bps4(rate) or round_cents(Fraction(c["_billable"]) * rate / 40000) != c["_gross"]:
            fails.append("FEE_CALC %s: does not re-perform" % c["ASSIGN_ID"])
    for c in f["fee_calcs"]:
        if c["_run"]["RUN_ID"] == "R-2026Q3-01" and c["ASSIGN_ID"] in f["off_ids"]:
            s = f["sched_by_id"][c["_asg"]["SCHED_ID"]]
            regross = round_cents(Fraction(c["_billable"]) * sched_rate(s, c["_billable"]) / 40000)
            if (c["_gross"] > regross) != (c["ASSIGN_ID"] in f["over_ids"]) or c["_gross"] == regross:
                fails.append("off-schedule row %s is not over- or underbilled as planted" % c["ASSIGN_ID"])
    by_ref = {}
    for r in f["client_rev"]:
        if r["SOURCE_REF"]:
            by_ref.setdefault(r["SOURCE_REF"], []).append(r["_amt"])
    for c in f["fee_calcs"]:
        ref = "%s|%s" % (c["RUN_ID"], c["ASSIGN_ID"])
        if ref in by_ref and (len(by_ref[ref]) != 3 or sum(by_ref[ref]) != c["_net"]):
            fails.append("revenue of %s does not add to its net fee" % ref)
    for r in f["prof"]:
        if r["gross_revenue"] - r["distribution_payments"] - r["direct_sales_marketing_cost"] != r["contribution_margin"] \
                or r["contribution_margin"] - r["allocated_indirect_cost"] != r["operating_profit"]:
            fails.append("profitability %s %s %s does not add up" % (r["fiscal_month"], r["grain"], r["member"]))
    totals, shares = {}, {}
    for r in f["alloc_results"]:
        if r["_dim"] == "POOL":
            continue
        k = (r["_run"], r["_pool"], r["_dim"])
        totals[k] = totals.get(k, 0) + r["_amt"]
        shares[k] = shares.get(k, 0) + r["_share"]
    per_pool = {}
    for (run, p, dim), v in totals.items():
        per_pool.setdefault((run, p), set()).add(v)
        if shares[(run, p, dim)] != 10000:
            fails.append("RESULT %s %s %s: driver shares add to %d" % (run, p, dim, shares[(run, p, dim)]))
    for k, vals in per_pool.items():
        if len(vals) != 1:
            fails.append("RESULT %s %s: rules allocate different totals" % k)
    for run in f["alloc_runs"]:
        cost = sum(c["_c"] for c in f["pool_costs"] if c["RUN_ID"] == run["RUN_ID"])
        chan = sum(r["_amt"] for r in f["alloc_results"] if r["_run"] == run["RUN_ID"] and r["_dim"] == "CHAN")
        if chan + run["_resid"] != cost:
            fails.append("RUN %s: allocated + residual != pool cost" % run["RUN_ID"])
    q3_cost = sum(c["_c"] for c in f["pool_costs"] if c["RUN_ID"] in [f["final_run"][m] for m in months_of("2026Q3")])
    if round((planted["ALLOCATED_COST_Q3"] + planted["UNALLOCATED_RESIDUAL_Q3"]) * 100) != q3_cost:
        fails.append("ALLOCATED_COST_Q3 + UNALLOCATED_RESIDUAL_Q3 differs from the Q3 pool cost")
    if econ_negative_cuts(f) != ["Core", "PLN"]:
        fails.append("negative contribution cuts are %s, not Core and PLN" % econ_negative_cuts(f))
    for q, _, _ in FISCAL_QUARTERS:
        cm = {}
        for r in f["prof"]:
            if r["fiscal_month"] in months_of(q) and r["grain"] in ("SEG", "OFF"):
                cm[r["member"]] = cm.get(r["member"], 0) + r["contribution_margin"]
        for member, v in cm.items():
            if member in ("Core", "PLN"):
                if v >= 0:
                    fails.append("%s: %s contribution margin is not negative" % (q, member))
            elif member in ("Select", "Private", "Flagship", "DAP", "PAS", "WMP", "TRS", "BRK") and v <= 0:
                fails.append("%s: %s contribution margin is not positive" % (q, member))
            elif member == "HYB" and v != 0:
                fails.append("%s: HYB contribution margin is not zero" % q)
    want = {"ACCOUNTS_BILLED_OFF_SCHEDULE_Q3": 4, "HOUSEHOLD_BREAKPOINT_NOT_APPLIED_Q3": 2, "FAILED_FEE_RUNS_Q3": 1,
            "FEE_RUNS_TESTED_Q3": 2, "FAILED_FEE_DEBITS_Q3": 3, "ACTIVE_FEE_WAIVERS": 8,
            "ACTIVE_FEE_SCHEDULE_VERSIONS": 6, "ACTIVE_FEE_SCHEDULE_ASSIGNMENTS": 140, "NEGATIVE_CONTRIBUTION_CUTS": 2}
    for k, v in want.items():
        if planted[k] != v:
            fails.append("%s is %s, not %s" % (k, planted[k], v))
    if sum(1 for w in f["waivers"] if w["_start"] <= date(2026, 9, 30) and (w["_end"] is None or
           w["_end"] >= date(2026, 9, 30)) and not w["APPROVED_BY"]) != 2:
        fails.append("not exactly 2 unapproved waivers in force")
    if sum(1 for c in f["fee_calcs"] if c["_disc"] and c["_run"]["RUN_TYPE_CD"] == "REG") != 8:
        fails.append("not exactly 8 discounted calculations in the regular runs")
    # References
    def col(src, table, name):
        return {r[name] for r in tables[(src, table)]}
    accts = col("SRC-BRK", "ACCT_MASTER", "ACCT_NO")
    users = col("SRC-CRM", "User", "Id")
    hhs = col("SRC-CRM", "Account", "Id")
    scheds = col("SRC-BIL", "SCHEDULE", "SCHED_ID")
    asgs = col("SRC-BIL", "ASSIGNMENT", "ASSIGN_ID")
    groups = col("SRC-BIL", "FEE_GROUP", "GROUP_ID")
    fruns = col("SRC-BIL", "FEE_RUN", "RUN_ID")
    pools = col("SRC-CST", "POOL", "POOL_ID")
    rules = col("SRC-CST", "RULE", "RULE_ID")
    aruns = col("SRC-CST", "RUN", "RUN_ID")
    methods = col("SRC-CST", "METHOD", "METHOD_ID")
    waiver_ids = col("SRC-BIL", "WAIVER", "WAIVER_ID")
    checks = [("SRC-BIL", "ASSIGNMENT", "ACCT_NO", accts), ("SRC-BIL", "ASSIGNMENT", "PAY_ACCT_NO", accts),
              ("SRC-BIL", "ASSIGNMENT", "SCHED_ID", scheds), ("SRC-BIL", "ASSIGNMENT", "GROUP_ID", groups),
              ("SRC-BIL", "SCHEDULE_TIER", "SCHED_ID", scheds), ("SRC-BIL", "SCHEDULE", "PRIOR_SCHED_ID", scheds),
              ("SRC-BIL", "FEE_GROUP", "CRM_HH_ID", hhs), ("SRC-BIL", "FEE_GROUP_MBR", "GROUP_ID", groups),
              ("SRC-BIL", "FEE_GROUP_MBR", "ACCT_NO", accts), ("SRC-BIL", "FEE_RUN", "APPROVED_BY", users),
              ("SRC-BIL", "FEE_CALC", "RUN_ID", fruns), ("SRC-BIL", "FEE_CALC", "ASSIGN_ID", asgs),
              ("SRC-BIL", "FEE_CALC", "SCHED_ID", scheds), ("SRC-BIL", "WAIVER", "ASSIGN_ID", asgs),
              ("SRC-BIL", "WAIVER", "APPROVED_BY", users), ("SRC-BIL", "DEBIT", "RUN_ID", fruns),
              ("SRC-BIL", "DEBIT", "ASSIGN_ID", asgs), ("SRC-BIL", "DEBIT", "ACCT_NO", accts),
              ("SRC-REV", "CLIENT_REV", "ACCT_NO", accts), ("SRC-CST", "RULE", "POOL_ID", pools),
              ("SRC-CST", "RULE", "METHOD_ID", methods), ("SRC-CST", "POOL_COST", "RUN_ID", aruns),
              ("SRC-CST", "POOL_COST", "POOL_ID", pools), ("SRC-CST", "RESULT", "RUN_ID", aruns),
              ("SRC-CST", "RESULT", "RULE_ID", rules)]
    for src, table, name, valid in checks:
        bad = {r[name] for r in tables[(src, table)] if r[name] and r[name] not in valid}
        if bad:
            fails.append("%s/%s.%s: %d unresolved values, e.g. %s" % (src, table, name, len(bad), sorted(bad)[0]))
    classes = {(r["FUND_NO"], r["CLASS_CD"]) for r in tables[("SRC-TA", "FUND_MASTER")]}
    for r in tables[("SRC-REV", "FUND_REV")]:
        if (r["FUND_NO"], r["CLASS_CD"]) not in classes:
            fails.append("FUND_REV %s: fund and class not in FUND_MASTER" % r["REV_ID"])
            break
    for r in tables[("SRC-BIL", "FEE_CALC")]:
        for w in filter(None, r["WAIVER_IDS"].split("; ")):
            if w not in waiver_ids:
                fails.append("FEE_CALC %s %s: unknown waiver %s" % (r["RUN_ID"], r["ASSIGN_ID"], w))
    refs = {"%s|%s" % (c["RUN_ID"], c["ASSIGN_ID"]) for c in tables[("SRC-BIL", "FEE_CALC")]}
    for r in tables[("SRC-REV", "CLIENT_REV")]:
        if r["SOURCE_REF"] and r["SOURCE_REF"] not in refs:
            fails.append("CLIENT_REV %s cites an unknown calculation" % r["REV_ID"])
            break
    for r in tables[("SRC-CST", "RESULT")]:
        if r["TARGET_DIM_CD"] == "POOL" and r["TARGET_MEMBER"] not in pools:
            fails.append("RESULT step-down row to unknown pool %s" % r["TARGET_MEMBER"])
    return fails


def build_economics(f, facts, attrs, bl):
    """The client economics business, with its own random generator so everything upstream is unchanged; returns its
    tables keyed by (source, table)."""
    erng = random.Random("%s-economics" % config.SEED)
    econ_schedules(f)
    econ_values(erng, f, facts)
    econ_assignments(erng, f, attrs)
    econ_billing(erng, f)
    econ_client_revenue(erng, f, attrs, bl)
    econ_fund_revenue(erng, f)
    econ_member_revenue(f, facts, attrs)
    econ_costs(erng, f)
    econ_derived(f)
    NOTES.append("The client economics business (SRC-BIL, SRC-REV, SRC-CST) is generated after the wealth and "
                 "institutional businesses and their certified figures from its own generator "
                 "(random.Random('<SEED>-economics')); it reads them and changes nothing upstream.")
    return {
        ("SRC-BIL", "SCHEDULE"): f["schedules"], ("SRC-BIL", "SCHEDULE_TIER"): f["schedule_tiers"],
        ("SRC-BIL", "FEE_GROUP"): f["fee_groups"], ("SRC-BIL", "FEE_GROUP_MBR"): f["fee_members"],
        ("SRC-BIL", "ASSIGNMENT"): f["assignments"], ("SRC-BIL", "FEE_RUN"): f["fee_runs"],
        ("SRC-BIL", "FEE_CALC"): f["fee_calcs"], ("SRC-BIL", "WAIVER"): f["waivers"], ("SRC-BIL", "DEBIT"): f["debits"],
        ("SRC-REV", "CLIENT_REV"): f["client_rev"], ("SRC-REV", "FUND_REV"): f["fund_rev"],
        ("SRC-CST", "POOL"): f["pools"], ("SRC-CST", "METHOD"): f["methods"], ("SRC-CST", "RULE"): f["rules"],
        ("SRC-CST", "RUN"): f["alloc_runs"], ("SRC-CST", "POOL_COST"): f["pool_costs"],
        ("SRC-CST", "RESULT"): f["alloc_results"],
    }


# ---------------------------------------------------------------------------------------------------------------------
# Self-checks

def self_check(f, tables, values, planted, cents_pair, households, non_household):
    """The brief's checks; returns a list of failures (empty when all pass)."""
    fails = []
    for ptype, b, e in PERIODS:
        start = (MONTH_ENDS[b] + timedelta(days=1)).isoformat()
        rows = [v for v in values if v["period_start"] == start and v["period_type"] == ptype]
        total = [v for v in rows if v["dimension_type"] == "Total"][0]["_cents"]
        for dim in DIMENSIONS[1:]:
            for measure in ("E", "nna"):
                s = sum(v["_cents"][measure] for v in rows if v["dimension_type"] == dim)
                if s != total[measure]:
                    fails.append("%s %s: %s rows sum to %d, Total is %d" % (ptype, start, dim, s, total[measure]))
        if total["nict"] != 0:
            fails.append("%s %s: Net Inter-Channel Transfers on Total is %d" % (ptype, start, total["nict"]))
    if cents_pair[0] != cents_pair[1]:
        fails.append("AFFILIATED_OMNIBUS_VALUE %d != BROKERAGE_OWN_FUND_VALUE %d" % cents_pair)
    q = {(v["dimension_type"], v["dimension_key"]): v["_cents"]["nna"] for v in values if v["period_type"] == "Quarter"}
    msum = {}
    for v in values:
        if v["period_type"] == "Month":
            k = (v["dimension_type"], v["dimension_key"])
            msum[k] = msum.get(k, 0) + v["_cents"]["nna"]
    for k in q:
        if q[k] != msum.get(k, 0):
            fails.append("Quarter Net New Assets %s %s: %d != months %d" % (k + (q[k], msum.get(k, 0))))
    total_e = [v for v in values if v["period_type"] == "Month" and v["period_end"] == config.AS_OF
               and v["dimension_type"] == "Total"][0]["_cents"]["E"]
    if sum(h["_cents"] for h in households) + non_household != total_e:
        fails.append("household assets plus non-household assets differ from the Total Ending at AS_OF")
    fails += reference_failures(tables)
    return fails


def reference_failures(tables):
    """Every foreign reference in the extracts resolves."""
    def col(src, table, name):
        return {r[name] for r in tables[(src, table)]}
    contacts = col("SRC-CRM", "Contact", "Id")
    households = col("SRC-CRM", "Account", "Id")
    users = col("SRC-CRM", "User", "Id")
    fas = col("SRC-CRM", "FinServ__FinancialAccount__c", "Id")
    custs = col("SRC-BRK", "CUST_MASTER", "CUST_NO")
    accts = col("SRC-BRK", "ACCT_MASTER", "ACCT_NO")
    cusips = col("SRC-BRK", "SEC_MASTER", "CUSIP")
    funds = col("SRC-TA", "FUND_MASTER", "FUND_NO")
    ta_accts = col("SRC-TA", "SHR_ACCT", "ACCT_NO")
    dealers = col("SRC-TA", "DEALER", "DEALER_NO")
    reps = col("SRC-CRM", "User", "Rep_Code__c")
    offerings = col("SRC-CRM", "Offering__c", "Code__c")
    tiers = col("SRC-CRM", "Service_Tier__c", "Code__c")
    txn_ids = col("SRC-BRK", "ACTIVITY", "TXN_ID")
    confirms = col("SRC-TA", "TRANSACTION", "CONFIRM_NO")
    clients = col("SRC-INST", "CLIENT", "CLIENT_ID")
    rels = col("SRC-INST", "RELATIONSHIP", "REL_ID")
    mandates = col("SRC-INST", "MANDATE", "MANDATE_ID")
    consultants = col("SRC-INST", "CONSULTANT", "CONSULTANT_ID")
    products = col("SRC-TA", "FUND_MASTER", "PRODUCT_CD")
    ports = col("SRC-PAB", "PORTFOLIO", "PORT_ID")
    checks = [
        ("SRC-CRM", "Account", "FinServ__PrimaryContact__c", contacts), ("SRC-CRM", "Account", "OwnerId", users),
        ("SRC-CRM", "Account", "Service_Tier__c", tiers),
        ("SRC-CRM", "Contact", "AccountId", households), ("SRC-CRM", "Contact", "Merged_Into__c", contacts),
        ("SRC-CRM", "Contact", "Brokerage_Customer_No__c", custs),
        ("SRC-CRM", "FinServ__FinancialAccount__c", "FinServ__PrimaryOwner__c", contacts),
        ("SRC-CRM", "FinServ__FinancialAccount__c", "FinServ__JointOwner__c", contacts),
        ("SRC-CRM", "FinServ__FinancialAccount__c", "FinServ__Household__c", households),
        ("SRC-CRM", "FinServ__FinancialAccount__c", "Program__c", offerings),
        ("SRC-CRM", "FinServ__FinancialAccountRole__c", "FinServ__FinancialAccount__c", fas),
        ("SRC-CRM", "FinServ__FinancialAccountRole__c", "FinServ__RelatedContact__c", contacts),
        ("SRC-CRM", "Consent__c", "Contact__c", contacts), ("SRC-CRM", "Trusted_Contact__c", "Client__c", contacts),
        ("SRC-CRM", "Trusted_Contact__c", "Trusted_Person__c", contacts),
        ("SRC-CRM", "Service_Tier__c", "Offering__c", offerings),
        ("SRC-BRK", "ACCT_MASTER", "PRIM_CUST_NO", custs), ("SRC-BRK", "ACCT_MASTER", "SEC_CUST_NO", custs),
        ("SRC-BRK", "ACCT_MASTER", "REP_CD", reps), ("SRC-BRK", "ACCT_MASTER", "PROGRAM_CD", offerings),
        ("SRC-BRK", "CUST_MASTER", "CRM_CONTACT_ID", contacts), ("SRC-BRK", "CUST_MASTER", "MERGED_TO_CUST_NO", custs),
        ("SRC-BRK", "SEC_MASTER", "TA_FUND_NO", funds),
        ("SRC-BRK", "POSITIONS", "ACCT_NO", accts), ("SRC-BRK", "POSITIONS", "CUSIP", cusips),
        ("SRC-BRK", "CASH_BAL", "ACCT_NO", accts),
        ("SRC-BRK", "ACTIVITY", "ACCT_NO", accts), ("SRC-BRK", "ACTIVITY", "CUSIP", cusips),
        ("SRC-BRK", "ACTIVITY", "CONTRA_ACCT_NO", accts), ("SRC-BRK", "ACTIVITY", "REVERSAL_OF_TXN_ID", txn_ids),
        ("SRC-TA", "FUND_MASTER", "CUSIP", cusips), ("SRC-TA", "SHR_ACCT", "DEALER_NO", dealers),
        ("SRC-TA", "POSITION", "ACCT_NO", ta_accts), ("SRC-TA", "POSITION", "FUND_NO", funds),
        ("SRC-TA", "TRANSACTION", "ACCT_NO", ta_accts), ("SRC-TA", "TRANSACTION", "FUND_NO", funds),
        ("SRC-TA", "TRANSACTION", "DEALER_NO", dealers), ("SRC-TA", "TRANSACTION", "REVERSAL_OF", confirms),
        ("SRC-INST", "CLIENT", "CONSULTANT_ID", consultants), ("SRC-INST", "RELATIONSHIP", "CLIENT_ID", clients),
        ("SRC-INST", "RELATIONSHIP", "CONSULTANT_ID", consultants), ("SRC-INST", "MANDATE", "CLIENT_ID", clients),
        ("SRC-INST", "MANDATE", "REL_ID", rels), ("SRC-INST", "MANDATE", "STRATEGY_CD", products),
        ("SRC-INST", "HEALTH_SCORE", "REL_ID", rels), ("SRC-INST", "FUND_ACCOUNT", "CLIENT_ID", clients),
        ("SRC-INST", "FUND_ACCOUNT", "REL_ID", rels), ("SRC-INST", "FUND_ACCOUNT", "TA_ACCT_NO", ta_accts),
        ("SRC-PAB", "PORTFOLIO", "MANDATE_ID", mandates), ("SRC-PAB", "PORTFOLIO", "CLIENT_ID", clients),
        ("SRC-PAB", "VALUATION", "PORT_ID", ports), ("SRC-PAB", "HOLDING", "PORT_ID", ports),
        ("SRC-PAB", "HOLDING", "SECURITY_ID", cusips),
    ]
    fails = []
    for src, table, name, valid in checks:
        bad = {r[name] for r in tables[(src, table)] if r[name] and r[name] not in valid}
        if bad:
            fails.append("%s/%s.%s: %d unresolved values, e.g. %s" % (src, table, name, len(bad), sorted(bad)[0]))
    for r in tables[("SRC-CRM", "FinServ__FinancialAccount__c")]:
        number, src = r["FinServ__FinancialAccountNumber__c"], r["Source_System__c"]
        if number and number not in (accts if src == "BRK" else ta_accts):
            fails.append("financial account %s points at unknown %s account %s" % (r["Id"], src, number))
    for r in tables[("SRC-BRK", "ACTIVITY")]:
        if r["REVERSAL_OF_TXN_ID"]:
            orig = [x for x in tables[("SRC-BRK", "ACTIVITY")] if x["TXN_ID"] == r["REVERSAL_OF_TXN_ID"]][0]
            if orig["STATUS_CD"] != "P" or orig["NET_AMT"] != r["NET_AMT"]:
                fails.append("reversal %s does not match a posted row of the same amount" % r["TXN_ID"])
    return fails


# ---------------------------------------------------------------------------------------------------------------------
# Output

def collect_tables(f, secs):
    """The rows of every table, keyed by (source, table)."""
    return {
        ("SRC-BRK", "ACCT_MASTER"): f["accts"], ("SRC-BRK", "CUST_MASTER"): f["customers"],
        ("SRC-BRK", "SEC_MASTER"): secs, ("SRC-BRK", "POSITIONS"): f["positions"], ("SRC-BRK", "CASH_BAL"): f["cash"],
        ("SRC-BRK", "ACTIVITY"): f["activity"],
        ("SRC-CRM", "Account"): f["households"], ("SRC-CRM", "Contact"): f["contacts"],
        ("SRC-CRM", "FinServ__FinancialAccount__c"): f["fas"], ("SRC-CRM", "FinServ__FinancialAccountRole__c"): f["fa_roles"],
        ("SRC-CRM", "User"): f["users"], ("SRC-CRM", "Consent__c"): f["consents"],
        ("SRC-CRM", "Trusted_Contact__c"): f["trusted"], ("SRC-CRM", "Offering__c"): f["offerings"],
        ("SRC-CRM", "Service_Tier__c"): f["tiers"],
        ("SRC-TA", "FUND_MASTER"): f["funds"], ("SRC-TA", "SHR_ACCT"): f["ta_accts"],
        ("SRC-TA", "POSITION"): f["ta_positions"], ("SRC-TA", "TRANSACTION"): f["ta_txns"],
        ("SRC-TA", "DEALER"): f["dealers"],
        ("SRC-INST", "CLIENT"): f["inst_clients"], ("SRC-INST", "RELATIONSHIP"): f["inst_rels"],
        ("SRC-INST", "MANDATE"): f["mandates"], ("SRC-INST", "HEALTH_SCORE"): f["health"],
        ("SRC-INST", "FUND_ACCOUNT"): f["fund_accounts"], ("SRC-INST", "CONSULTANT"): f["consultants"],
        ("SRC-PAB", "PORTFOLIO"): f["portfolios"], ("SRC-PAB", "VALUATION"): f["valuations"],
        ("SRC-PAB", "HOLDING"): f["holdings"],
    }


def write_tables(tables):
    """One CSV per table with the schema's columns in order, and each source's data dictionary."""
    for src, s in schema.SOURCES.items():
        folder = os.path.join(OUT, src)
        os.makedirs(folder, exist_ok=True)
        for tname, t in s["tables"].items():
            cols = [c[0] for c in t["columns"]]
            rows = tables[(src, tname)]
            with open(os.path.join(folder, tname + ".csv"), "w", newline="") as fh:
                w = csv.writer(fh)
                w.writerow(cols)
                for r in rows:
                    w.writerow([r.get(c, "") for c in cols])
            print("  %-8s %-34s %6d rows" % (src, tname, len(rows)))
        with open(os.path.join(folder, "_dictionary.csv"), "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["table", "column", "type", "description", "example", "table_grain"])
            w.writerows(schema.dictionary_rows(src))


def main():
    rng = random.Random(config.SEED)
    bl, ch = taxonomy_keys()
    f = {}
    build_users(rng, f)
    build_offerings(f)
    build_dealers(f)
    secs = build_funds(rng, f) + build_third_party(rng)
    f["sec_by_cusip"] = {s["CUSIP"]: s for s in secs}
    build_households(rng, f)
    build_customers(rng, f)
    link_customers(rng, f)
    build_brokerage_accounts(rng, f)
    build_ta_accounts(rng, f)
    build_financial_accounts(rng, f)
    build_consents_and_trusted(rng, f)
    build_positions(rng, f, secs)
    build_register_positions(rng, f)
    build_activity(rng, f)
    build_register_transactions(rng, f)
    build_institutional(f, secs)
    f["channels"] = ch
    facts = counted_asset_rows(f)
    set_tiers(rng, f, facts)
    attrs = account_attributes(f, bl, ch)
    flows = flow_facts(f, attrs)
    values = certify(f, facts, flows, attrs)
    households, non_household = household_figures(f, facts, attrs)
    planted, cents_pair = planted_values(f, facts, attrs, households)
    inst_planted, relationships = institutional_figures(f, facts, attrs)
    planted.update(inst_planted)
    tables = collect_tables(f, secs)
    fails = self_check(f, tables, values, planted, cents_pair, households, non_household)
    fails += institutional_failures(f, tables, planted, relationships)
    if fails:
        print("SELF-CHECK FAILED:\n  " + "\n  ".join(fails[:30]), file=sys.stderr)
        sys.exit(1)
    own_share = sum(p["_mv"] for p in f["positions"] if p["_sec"]["FUND_FAMILY_CD"] == "OWN") / \
        max(1, sum(p["_mv"] for p in f["positions"]))
    NOTES.append("Own funds hold %.1f%% of brokerage position value across the four month-ends." % (own_share * 100))
    NOTES.append("Counts written as the data yields them: %d brokerage customers (heads and spouses of the 270 "
                 "brokerage households plus 40 percent of their dependents; customers without an account are status I), "
                 "so 10 percent legacy is %d and SUGGESTED_MATCHES is %d; SERVICE_TIER_MISMATCH is %d (the 18 planted "
                 "plus households whose assets crossed a threshold upward between June and September)."
                 % (len(f["customers"]), sum(1 for c in f["customers"] if not c["CRM_CONTACT_ID"]),
                    planted["SUGGESTED_MATCHES"], planted["SERVICE_TIER_MISMATCH"]))
    NOTES.append("REVERSED_ROWS and PENDING_ROWS count brokerage ACTIVITY rows; the register also carries 20 reversals "
                 "(TRANSACTION STATUS_CD R), excluded from the flows the same way.")
    NOTES.append("SAME_OWNER_JOURNALS_EXCLUDED is the sum of the credit legs of the posted journals between two accounts "
                 "of the same customer in the same channel in the quarter (the amount kept out of both flow measures).")
    tables.update(build_economics(f, facts, attrs, bl))
    econ_planted_values, econ_lists = econ_planted(f)
    planted.update(econ_planted_values)
    fails = econ_failures(f, tables, planted)
    if fails:
        print("SELF-CHECK FAILED (economics):\n  " + "\n  ".join(fails[:30]), file=sys.stderr)
        sys.exit(1)
    os.makedirs(OUT, exist_ok=True)
    print("Synthetic sources (seed %d, as of %s) -> %s" % (config.SEED, config.AS_OF, OUT))
    write_tables(tables)
    for v in values:
        v.pop("_cents")
    for h in households:
        h.pop("_cents")
    for r in relationships:
        r.pop("_cents")
    truths = {"as_of": config.AS_OF, "seed": config.SEED, "notes": NOTES, "planted": planted, "measure_values": values,
              "households": households, "non_household_client_assets": non_household / 100,
              "relationships": relationships, **econ_lists,
              "counts": {"%s/%s" % k: len(v) for k, v in tables.items()}}
    with open(os.path.join(OUT, "truths.json"), "w") as fh:
        json.dump(truths, fh, indent=1)
    print("Self-checks passed. Planted values:")
    for k, v in planted.items():
        print("  %-36s %s" % (k, v))


if __name__ == "__main__":
    main()
