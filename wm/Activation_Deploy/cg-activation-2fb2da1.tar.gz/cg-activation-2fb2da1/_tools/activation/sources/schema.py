"""The three synthetic source systems of the activation demo: their tables, columns and vocabularies, exactly as a
wealth manager's platforms would hand them over. This module is the data dictionary each source publishes
(generate.py writes it out as <source>_dictionary.csv) and the contract for the extracts, the mapping modules and
the AI mapping assistant. Nothing here uses the taxonomy's names on purpose: the shapes and codes are the vendors'.

Column tuple: (name, type, description, example). Types: id, text, code, date, timestamp, integer, number, amount, boolean.
"""

SOURCES = {}


def source(id, name, kind, shape, note, tables):
    SOURCES[id] = dict(id=id, name=name, kind=kind, shape=shape, note=note, tables=tables)


def table(description, grain, keys, columns, volume=""):
    return dict(description=description, grain=grain, keys=list(keys), columns=list(columns), volume=volume)


# ---------------------------------------------------------------------------------------------------------------------
# SRC-BRK: the brokerage clearing and custody platform (the book of record for brokerage and managed advisory accounts)
source("SRC-BRK", "Brokerage Clearing Platform", "System of record", "Clearing-firm style mainframe extracts",
       "Nightly fixed-layout extracts converted to CSV. Codes are the platform's own; the account number is the "
       "customer-facing brokerage number. Customers are keyed by CUST_NO; the CRM carries the link to the household.",
       {
    "ACCT_MASTER": table(
        "One row per brokerage, managed advisory or trust account carried by the broker-dealer.",
        "account", ["ACCT_NO"], [
            ("ACCT_NO", "id", "Brokerage account number (8 digits), printed on statements", "30017422"),
            ("ACCT_TITLE", "text", "Registration title as printed", "JANE A OKAFOR & DAVID OKAFOR JTWROS"),
            ("ACCT_CLASS_CD", "code", "Account class: B brokerage self-directed, A managed advisory, T trust (fiduciary)", "B"),
            ("REG_CD", "code", "Registration: IND, JTWROS, TIC, TIRA (traditional IRA), RIRA (Roth), ROLL (rollover IRA), "
                               "INHIRA, SEP, UTMA, RTR (revocable trust), ITR (irrevocable trust), EST (estate), 529", "JTWROS"),
            ("MARGIN_CD", "code", "Regulation T type: C cash, M margin", "C"),
            ("STATUS_CD", "code", "O open, P pending approval, D dormant, C closed, E escheated", "O"),
            ("OPEN_DT", "date", "Date the account was approved and opened (YYYYMMDD)", "20240311"),
            ("CLOSE_DT", "date", "Date closed; blank while open", ""),
            ("CLOSE_RSN_CD", "code", "FW full withdrawal, AO ACATS out, RR re-registered, ES estate, SB small balance, FE firm error", ""),
            ("CHANNEL_CD", "code", "Servicing channel: SD self-directed, DA digital advice, HA human advice, TR trust", "SD"),
            ("PROGRAM_CD", "code", "Advisory program the account is enrolled in: DAP digital advice, PAS personal advisor, "
                                   "WMP wealth management, TRS trust services; blank for self-directed", ""),
            ("ENROLL_DT", "date", "Program enrollment effective date", ""),
            ("ENROLL_STATUS_CD", "code", "A active, S suspended, T terminated; blank when not enrolled", ""),
            ("PURPOSE_CD", "code", "RET retirement, EDU education, GEN general investing, CSH cash reserve, EST estate", "GEN"),
            ("BRANCH_CD", "code", "Servicing branch", "B017"),
            ("REP_CD", "code", "Registered representative of record (firm rep code)", "R4471"),
            ("PRIM_CUST_NO", "id", "Primary owner's customer number (CUST_MASTER)", "C0088121"),
            ("SEC_CUST_NO", "id", "Joint owner's customer number; blank for single-owner accounts", "C0088122"),
            ("CARRY_ENT_CD", "code", "Carrying entity: BD broker-dealer, TC trust company", "BD"),
        ], "about 700 rows"),
    "CUST_MASTER": table(
        "One row per customer known to the brokerage platform (natural persons only; entities are carried as trust accounts).",
        "customer", ["CUST_NO"], [
            ("CUST_NO", "id", "Platform customer number", "C0088121"),
            ("FIRST_NM", "text", "First name", "Jane"),
            ("LAST_NM", "text", "Last name", "Okafor"),
            ("DOB", "date", "Date of birth (YYYYMMDD)", "19780422"),
            ("DOD", "date", "Date of death when notified; blank otherwise", ""),
            ("TAX_ID_LAST4", "text", "Last four digits of the taxpayer identification number", "4471"),
            ("CUST_STATUS_CD", "code", "A active, I inactive, M merged into another customer", "A"),
            ("MERGED_TO_CUST_NO", "id", "Surviving customer number when status is M", ""),
            ("CRM_CONTACT_ID", "id", "The CRM Contact Id the platform received at onboarding (may be blank for legacy customers)", "003Ab00000Fk3PqIAJ"),
            ("ONBOARD_CHANNEL_CD", "code", "WEB, MOB mobile, PHN phone representative, ADV advisor-assisted, XFR account transfer in", "WEB"),
        ], "about 1,000 rows"),
    "SEC_MASTER": table(
        "The platform's security master: every instrument that has had a position or activity.",
        "security", ["CUSIP"], [
            ("CUSIP", "id", "CUSIP of the security", "922908769"),
            ("SYMBOL", "text", "Ticker symbol", "VTSAX"),
            ("SEC_DESC", "text", "Security description", "TOTAL STOCK MARKET INDEX FUND ADMIRAL"),
            ("SEC_TYPE_CD", "code", "EQ equity, ETF exchange-traded fund, MF mutual fund, FI fixed income, CD certificate of deposit, "
                                    "MMF money market fund, OPT listed option, UIT unit trust", "MF"),
            ("ASSET_CLS_CD", "code", "EQ equity, FI fixed income, CASH cash and equivalents, MA multi-asset, DER derivative", "EQ"),
            ("ISSUER_NM", "text", "Issuer name", "The Firm Index Funds"),
            ("FUND_FAMILY_CD", "code", "Fund family for MF/ETF/MMF: OWN the firm's own funds, else the sponsor code", "OWN"),
            ("TA_FUND_NO", "id", "For OWN funds: the transfer agent fund number of the share class", "0585"),
            ("CCY", "code", "Trading currency (ISO 4217)", "USD"),
            ("SEC_STATUS_CD", "code", "A active, I inactive, M matured", "A"),
        ], "about 300 rows"),
    "POSITIONS": table(
        "End-of-day positions on each month-end business day.",
        "as-of date x account x security", ["ASOF_DT", "ACCT_NO", "CUSIP"], [
            ("ASOF_DT", "date", "Position date (YYYYMMDD), month-end business day", "20260930"),
            ("ACCT_NO", "id", "Brokerage account number", "30017422"),
            ("CUSIP", "id", "Security held", "922908769"),
            ("QTY_TD", "number", "Trade-date quantity (shares, units or contracts)", "1250.317"),
            ("QTY_SD", "number", "Settlement-date quantity", "1250.317"),
            ("PRICE", "number", "Closing price or NAV applied", "132.41"),
            ("MKT_VAL", "amount", "Market value in USD at the closing price", "165554.47"),
            ("COST_BASIS", "amount", "Total cost basis of the open lots", "121880.00"),
            ("ACCRUED_INT", "amount", "Accrued interest (fixed income)", "0.00"),
        ], "about 16,000 rows (four month-ends)"),
    "CASH_BAL": table(
        "End-of-day cash balances on each month-end business day.",
        "as-of date x account x balance type x basis", ["ASOF_DT", "ACCT_NO", "BAL_TYPE_CD", "BAL_BASIS_CD"], [
            ("ASOF_DT", "date", "Balance date (YYYYMMDD)", "20260930"),
            ("ACCT_NO", "id", "Brokerage account number", "30017422"),
            ("CCY", "code", "Currency (ISO 4217)", "USD"),
            ("BAL_TYPE_CD", "code", "FCB free credit balance, SWP sweep balance, MDB margin debit balance", "SWP"),
            ("BAL_BASIS_CD", "code", "T trade date, S settlement date", "S"),
            ("BAL_AMT", "amount", "Balance amount; debits negative", "4120.55"),
            ("SWEEP_PGM_CD", "code", "Sweep program for SWP balances: BDP bank deposit program, MMF money market fund", "BDP"),
        ], "about 4,000 rows"),
    "ACTIVITY": table(
        "Every posted or pending transaction on an account in the extract window.",
        "transaction", ["TXN_ID"], [
            ("TXN_ID", "id", "Transaction identifier", "T26092300018411"),
            ("ACCT_NO", "id", "Brokerage account number", "30017422"),
            ("TXN_CD", "code", "BUY, SEL, FBUY fund purchase, FRED fund redemption, DEP deposit, WDL withdrawal, "
                               "JNL journal between accounts, DIV dividend, INT interest, CGD capital gain distribution, "
                               "FEE advisory or account fee, ACATI ACATS transfer in, ACATO ACATS transfer out, "
                               "XFRI non-ACATS securities in, XFRO non-ACATS securities out, ROLLI rollover in", "BUY"),
            ("TRD_DT", "date", "Trade date (YYYYMMDD)", "20260923"),
            ("SETL_DT", "date", "Settlement date", "20260924"),
            ("ENTRY_DT", "date", "Posting date", "20260923"),
            ("CUSIP", "id", "Security; blank for cash-only entries", "922908769"),
            ("QTY", "number", "Quantity; negative for sells and deliveries", "100.000"),
            ("PRICE", "number", "Price or NAV", "132.41"),
            ("NET_AMT", "amount", "Net cash effect on the account, signed (credits positive)", "-13241.00"),
            ("CCY", "code", "Currency", "USD"),
            ("STATUS_CD", "code", "P posted, N pending, R reversed", "P"),
            ("REVERSAL_OF_TXN_ID", "id", "The transaction this one reverses", ""),
            ("CONTRA_ACCT_NO", "id", "Other account for journals and intra-firm transfers", ""),
            ("CONTRA_FIRM_CD", "code", "Delivering or receiving firm (DTC participant number) for ACATS and non-ACATS transfers", ""),
            ("XFER_TYPE_CD", "code", "ACATS, NONACATS, INTRAFIRM, ROLLOVER, TTEE (trustee-to-trustee)", ""),
            ("TXN_DESC", "text", "Narrative", "BUY 100 VTSAX @ 132.41"),
        ], "about 7,000 rows"),
})

# ---------------------------------------------------------------------------------------------------------------------
# SRC-CRM: the CRM, in Salesforce Financial Services Cloud shape (households, contacts, financial accounts and roles)
source("SRC-CRM", "Client Relationship Management", "System of record for households and relationships",
       "Salesforce Financial Services Cloud objects (API names)",
       "Object exports with Salesforce 18-character Ids. The household is an Account of record type Household; a "
       "person is a Contact whose AccountId is their primary household. Financial accounts carry the external account "
       "numbers of the brokerage platform and the transfer agent, which is how the firm links accounts to people.",
       {
    "Account": table(
        "Households (RecordType Household). The CRM keeps no person accounts; people are Contacts.",
        "household", ["Id"], [
            ("Id", "id", "Salesforce Id", "001Ab00000H7xQkIAJ"),
            ("Name", "text", "Household name", "Okafor Household"),
            ("RecordType.Name", "code", "Household", "Household"),
            ("FinServ__PrimaryContact__c", "id", "Primary member (Contact Id)", "003Ab00000Fk3PqIAJ"),
            ("OwnerId", "id", "Owning user: the primary advisor (User Id); blank when unassigned", "005Ab00000Bq1LzIAJ"),
            ("FinServ__Status__c", "code", "Active, Inactive", "Active"),
            ("Segment__c", "code", "Client value segment: Core, Select, Private, Flagship", "Select"),
            ("Service_Tier__c", "code", "Assigned service tier code: T1 Digital, T2 Select, T3 Private, T4 Flagship", "T2"),
            ("Tier_Method__c", "code", "How the tier was set: Rule, Score, Manual, Grandfathered", "Rule"),
            ("Formation_Basis__c", "code", "Client, AdvisorProposed, SystemSuggested", "Client"),
            ("Household_Confirmed_Date__c", "date", "Date the client last confirmed the household makeup", "2026-02-14"),
            ("CreatedDate", "timestamp", "Record creation", "2019-06-03T14:22:10Z"),
        ], "about 320 rows"),
    "Contact": table(
        "Natural persons: clients, prospects, authorized persons and trusted contacts.",
        "person", ["Id"], [
            ("Id", "id", "Salesforce Id", "003Ab00000Fk3PqIAJ"),
            ("FirstName", "text", "First name", "Jane"),
            ("LastName", "text", "Last name", "Okafor"),
            ("Birthdate", "date", "Date of birth", "1978-04-22"),
            ("Deceased_Date__c", "date", "Date of death when notified", ""),
            ("AccountId", "id", "Primary household (Account Id)", "001Ab00000H7xQkIAJ"),
            ("FinServ__PrimaryHouseholdRole__c", "code", "Role in the household: Head, Spouse, Dependent, Other", "Head"),
            ("Household_Start__c", "date", "Membership start", "2019-06-03"),
            ("Household_End__c", "date", "Membership end; blank while current", ""),
            ("Status__c", "code", "Active, Inactive, Merged, PendingVerification", "Active"),
            ("Merged_Into__c", "id", "Surviving Contact when Status is Merged", ""),
            ("FinServ__Status__c", "code", "Relationship stage: Prospect, Applicant, Client, Former Client, Related Party", "Client"),
            ("LeadSource", "code", "Web, Mobile, Phone, Advisor, Workplace, TransferAgent, AccountTransfer, Referral", "Web"),
            ("Brokerage_Customer_No__c", "id", "Customer number on the brokerage platform (CUST_MASTER.CUST_NO)", "C0088121"),
            ("Do_Not_Contact__c", "boolean", "Do-not-contact flag", "false"),
        ], "about 1,100 rows"),
    "FinServ__FinancialAccount__c": table(
        "Financial accounts the household holds at the firm, keyed by the external account number of the source system.",
        "financial account", ["Id"], [
            ("Id", "id", "Salesforce Id", "a0BAb00000Qm2VxMAJ"),
            ("Name", "text", "Display name", "Joint Brokerage - Lake House"),
            ("FinServ__FinancialAccountNumber__c", "id", "External account number: brokerage ACCT_NO or transfer agent ACCT_NO", "30017422"),
            ("Source_System__c", "code", "BRK brokerage platform, TA transfer agent", "BRK"),
            ("FinServ__FinancialAccountType__c", "code", "Brokerage, Advisory, MutualFund, Trust, IRA, 529", "Brokerage"),
            ("FinServ__PrimaryOwner__c", "id", "Primary owner (Contact Id)", "003Ab00000Fk3PqIAJ"),
            ("FinServ__JointOwner__c", "id", "Joint owner (Contact Id)", "003Ab00000Fk3PrIAJ"),
            ("FinServ__Household__c", "id", "Household the account rolls up to (Account Id)", "001Ab00000H7xQkIAJ"),
            ("FinServ__Status__c", "code", "Open, Closed, Pending", "Open"),
            ("FinServ__OpenDate__c", "date", "Open date", "2024-03-11"),
            ("Program__c", "code", "Advisory program code (Offering__c.Code__c) when enrolled", ""),
            ("Business_Line__c", "code", "DB direct brokerage, DA digital advice, HA human advice, PF proprietary funds, PT trust", "DB"),
            ("Channel__c", "code", "SelfDirected, DigitalAdvice, HumanAdvice, Trust, TransferAgentDirect", "SelfDirected"),
            ("Held_Away__c", "boolean", "True for accounts held at another firm (aggregated)", "false"),
            ("Held_Away_Value__c", "amount", "Last aggregated value for held-away accounts", ""),
        ], "about 1,100 rows"),
    "FinServ__FinancialAccountRole__c": table(
        "Who holds which role on a financial account, effective dated.",
        "account x contact x role x period", ["Id"], [
            ("Id", "id", "Salesforce Id", "a0CAb00000Rz5TkMAJ"),
            ("FinServ__FinancialAccount__c", "id", "Financial account (Id)", "a0BAb00000Qm2VxMAJ"),
            ("FinServ__RelatedContact__c", "id", "Contact (Id)", "003Ab00000Fk3PqIAJ"),
            ("FinServ__Role__c", "code", "Primary Owner, Joint Owner, Custodian, Guardian, Trustee, Beneficiary, Power of Attorney, Authorized Trader", "Primary Owner"),
            ("FinServ__StartDate__c", "date", "Role start", "2024-03-11"),
            ("FinServ__EndDate__c", "date", "Role end; blank while current", ""),
            ("FinServ__Active__c", "boolean", "Role currently active", "true"),
        ], "about 1,700 rows"),
    "User": table(
        "Firm users; advisors are users with an advisor role.",
        "user", ["Id"], [
            ("Id", "id", "Salesforce Id", "005Ab00000Bq1LzIAJ"),
            ("Name", "text", "Full name", "Priya Natarajan"),
            ("Title", "text", "Job title", "Senior Financial Advisor"),
            ("Employee_Number__c", "id", "HR employee number", "E10477"),
            ("UserRole.Name", "code", "Advisor, Planner, Service Associate, Trust Officer, Supervisor, Operations", "Advisor"),
            ("IsActive", "boolean", "User active", "true"),
            ("Advisor_Status__c", "code", "Onboarding, Active, Transitioning, Inactive; blank for non-advisors", "Active"),
            ("Business_Lines__c", "text", "Semicolon-separated: DA;HA;PT", "HA;PT"),
            ("Channels_Offered__c", "text", "Semicolon-separated: Phone;Video;InPerson;Chat", "Phone;Video"),
            ("Branch__c", "code", "Branch code", "B017"),
            ("Rep_Code__c", "code", "Registered representative code on the brokerage platform (ACCT_MASTER.REP_CD)", "R4471"),
        ], "about 60 rows"),
    "Consent__c": table(
        "Consents captured from contacts.",
        "consent", ["Id"], [
            ("Id", "id", "Salesforce Id", "a0DAb00000S1aQwMAJ"),
            ("Contact__c", "id", "Consenting contact", "003Ab00000Fk3PqIAJ"),
            ("Purpose__c", "code", "eDelivery, MarketingEmail, MarketingSMS, CallRecording, DataSharing", "eDelivery"),
            ("Status__c", "code", "Granted, Withdrawn, Expired, Declined", "Granted"),
            ("Capture_Method__c", "code", "WebSingle, WebDouble, Mobile, ESign, Verbal, Paper", "WebSingle"),
            ("Captured_Date__c", "date", "Capture date", "2024-03-11"),
            ("Expiry_Date__c", "date", "Expiry date", ""),
            ("Withdrawn_Timestamp__c", "timestamp", "When withdrawn", ""),
        ], "about 1,500 rows"),
    "Trusted_Contact__c": table(
        "FINRA Rule 4512 trusted contact designations.",
        "designation", ["Id"], [
            ("Id", "id", "Salesforce Id", "a0EAb00000T9kLmMAJ"),
            ("Client__c", "id", "Designating client (Contact Id)", "003Ab00000Fk3PqIAJ"),
            ("Trusted_Person__c", "id", "Trusted contact person (Contact Id)", "003Ab00000Fk3PzIAJ"),
            ("Status__c", "code", "Provided, Declined, Requested", "Provided"),
            ("Effective_From__c", "date", "Effective from", "2024-03-11"),
            ("Effective_To__c", "date", "Effective to", ""),
        ], "about 400 rows"),
    "Offering__c": table(
        "The advice and service offerings a client can enroll in, maintained by Product & Offering Management.",
        "offering", ["Code__c"], [
            ("Code__c", "code", "Offering code", "PAS"),
            ("Name", "text", "Offering name", "Personal Advisor Services"),
            ("Type__c", "code", "DigitalAdvice, HybridAdvice, PersonalAdvisor, WealthManagement, PlanningOnly, Brokerage, TrustServices", "PersonalAdvisor"),
            ("Delivery_Mode__c", "code", "DigitalOnly, DigitalWithAdvisor, DedicatedAdvisor, AdvisorTeam", "DedicatedAdvisor"),
            ("Discretion__c", "code", "Discretionary, NonDiscretionary, NA", "Discretionary"),
            ("Capacity__c", "code", "IA investment adviser, BD broker-dealer, TC trust fiduciary, DUAL", "IA"),
            ("Wrap_Fee__c", "boolean", "Wrap fee program", "true"),
            ("Rule_3a4__c", "boolean", "Relies on Rule 3a-4", "true"),
            ("Status__c", "code", "Active, SoftClosed, Inactive", "Active"),
            ("Minimum_Assets__c", "amount", "Minimum household assets to enroll", "50000"),
        ], "7 rows"),
    "Service_Tier__c": table(
        "Service tiers and their asset thresholds.",
        "tier", ["Code__c"], [
            ("Code__c", "code", "Tier code", "T2"),
            ("Name", "text", "Tier name", "Select"),
            ("Offering__c", "code", "Offering the tier belongs to (Offering__c.Code__c)", "PAS"),
            ("Asset_Threshold__c", "amount", "Minimum household client assets for the tier", "500000"),
            ("Threshold_Basis__c", "code", "HouseholdAssets, ClientAssets, HouseholdAssetsInclWorkplace", "HouseholdAssets"),
        ], "4 rows"),
})

# ---------------------------------------------------------------------------------------------------------------------
# SRC-TA: the transfer agent's fund share register (direct fund-only accounts, networked and omnibus accounts)
source("SRC-TA", "Transfer Agent Fund Share Register", "System of record for fund shareholder accounts",
       "Recordkeeping-system style extracts (DST/SS&C TA2000 flavor)",
       "Account-level register for the firm's own funds. Direct shareholders hold fund-only accounts; the affiliated "
       "broker-dealer and third-party intermediaries hold omnibus accounts whose underlying investors are in the "
       "brokerage platform or in the intermediary's sub-accounting. Fund numbers identify share classes.",
       {
    "FUND_MASTER": table(
        "Fund numbers (share classes) of the firm's own funds and ETFs.",
        "fund number (share class)", ["FUND_NO"], [
            ("FUND_NO", "id", "Fund number: one per share class", "0585"),
            ("FUND_NM", "text", "Fund name", "Total Stock Market Index Fund"),
            ("CLASS_CD", "code", "INV investor, ADM admiral, INST institutional, ETF exchange-traded class", "ADM"),
            ("PRODUCT_CD", "id", "Parent fund (portfolio) code shared by its classes", "P0085"),
            ("CUSIP", "id", "CUSIP of the share class", "922908769"),
            ("TICKER", "text", "Ticker", "VTSAX"),
            ("VEHICLE_CD", "code", "OEF open-end fund, ETF exchange-traded fund, CIT collective trust", "OEF"),
            ("ASSET_CLS_CD", "code", "EQ, FI, MM money market, BAL balanced", "EQ"),
            ("INCEPT_DT", "date", "Class inception date (YYYYMMDD)", "20001113"),
            ("STATUS_CD", "code", "A active (open), S soft closed, C closed to new investors, L liquidated", "A"),
            ("MIN_INIT_INV", "amount", "Minimum initial investment", "3000"),
            ("INVESTOR_TYPE_CD", "code", "R retail, I institutional, RI both", "R"),
        ], "about 60 rows"),
    "SHR_ACCT": table(
        "Shareholder accounts on the register.",
        "shareholder account", ["ACCT_NO"], [
            ("ACCT_NO", "id", "Transfer agent account number (10 digits)", "7700412093"),
            ("SOC_CD", "code", "Social code: 1 individual, 2 joint, 3 custodian UGMA/UTMA, 5 trust, 7 IRA, 8 institution (pension plan, endowment, foundation, corporation), 9 dealer-controlled omnibus", "1"),
            ("ACCT_TYPE_CD", "code", "I direct individual investor, O omnibus (dealer-controlled), N networked (NSCC level 3/4), P plan omnibus, D direct institutional investor (pension plan, endowment, foundation holding fund shares directly)", "I"),
            ("REG_LINE_1", "text", "Registration line 1", "JANE A OKAFOR"),
            ("REG_LINE_2", "text", "Registration line 2", ""),
            ("TAX_ID_LAST4", "text", "Last four of the TIN", "4471"),
            ("DEALER_NO", "id", "Dealer number (NSCC) for omnibus and networked accounts; the firm's own BD for direct", "0010"),
            ("BRANCH_NO", "id", "Dealer branch", ""),
            ("REP_NO", "id", "Dealer representative number", ""),
            ("NSCC_LEVEL", "code", "0, 3, 4 or blank (not networked)", ""),
            ("ESTAB_DT", "date", "Establishment date (YYYYMMDD)", "20160907"),
            ("CLOSE_DT", "date", "Close date; blank while open", ""),
            ("STATUS_CD", "code", "A active, C closed, Z zero balance", "A"),
            ("DIV_OPT_CD", "code", "R reinvest, C cash", "R"),
            ("IRA_TYPE_CD", "code", "For SOC_CD 7: T traditional, R Roth, S SEP, I inherited", ""),
        ], "about 500 rows"),
    "POSITION": table(
        "Share balances at each month-end.",
        "as-of date x account x fund", ["ASOF_DT", "ACCT_NO", "FUND_NO"], [
            ("ASOF_DT", "date", "Balance date (YYYYMMDD)", "20260930"),
            ("ACCT_NO", "id", "Shareholder account", "7700412093"),
            ("FUND_NO", "id", "Fund number", "0585"),
            ("SHARES", "number", "Collected shares", "812.441"),
            ("SHARES_UNCOLL", "number", "Uncollected shares (recent purchases)", "0.000"),
            ("SHARES_ESCROW", "number", "Escrowed or pledged shares", "0.000"),
            ("NAV", "number", "NAV applied", "132.41"),
            ("MKT_VAL", "amount", "Value at NAV", "107575.31"),
        ], "about 4,000 rows"),
    "TRANSACTION": table(
        "Posted register transactions in the extract window.",
        "register transaction", ["CONFIRM_NO"], [
            ("CONFIRM_NO", "id", "Confirmation number", "26092301177314"),
            ("ACCT_NO", "id", "Shareholder account", "7700412093"),
            ("FUND_NO", "id", "Fund number", "0585"),
            ("TRAN_CD", "code", "001 purchase, 002 redemption, 051 exchange in, 052 exchange out, 071 transfer in, "
                                "072 transfer out, 101 dividend reinvest, 102 capital gain reinvest, 111 dividend cash, "
                                "201 class conversion in, 202 class conversion out", "001"),
            ("TRADE_DT", "date", "Trade date (YYYYMMDD)", "20260923"),
            ("SETL_DT", "date", "Settlement date", "20260924"),
            ("POST_DT", "date", "Posting date", "20260923"),
            ("SHARES", "number", "Shares posted, positive", "37.772"),
            ("NAV_APPLIED", "number", "NAV applied", "132.41"),
            ("GROSS_AMT", "amount", "Gross amount", "5001.39"),
            ("NET_AMT", "amount", "Net amount after charges", "5001.39"),
            ("SOURCE_CD", "code", "FS NSCC Fund/SERV, DR direct (TA), OM omnibus file, RK recordkeeper file", "DR"),
            ("STATUS_CD", "code", "P posted, R reversed, C corrected", "P"),
            ("REVERSAL_OF", "id", "Confirmation number reversed", ""),
            ("DEALER_NO", "id", "Dealer on the trade", "0010"),
            ("REP_NO", "id", "Rep on the trade", ""),
        ], "about 3,000 rows"),
    "DEALER": table(
        "Dealers and intermediaries holding omnibus or networked accounts.",
        "dealer", ["DEALER_NO"], [
            ("DEALER_NO", "id", "Dealer number", "0010"),
            ("DEALER_NM", "text", "Dealer name", "The Firm Brokerage Services LLC"),
            ("NSCC_NO", "id", "NSCC participant number", "0010"),
            ("DEALER_TYPE_CD", "code", "AFF affiliated broker-dealer, WH wirehouse, RIA custodian, BK bank, RK recordkeeper", "AFF"),
        ], "about 8 rows"),
})


# ---------------------------------------------------------------------------------------------------------------------
# SRC-INST: the institutional client platform (institutional CRM and client-service system: clients, relationships,
# mandates, health scores, consultants). Keyed by its own client and relationship ids.
source("SRC-INST", "Institutional Client Platform", "System of record for institutional relationships", "Institutional CRM and client-service exports",
       "Nightly exports of the institutional business's client-service platform: who the institutional clients are, which "
       "service relationships and mandates they hold, how healthy each relationship is, and which transfer agent fund "
       "accounts and portfolio-book portfolios belong to them. Separate-account values live in the portfolio book (SRC-PAB).",
       {
    "CLIENT": table(
        "One row per institutional client (a plan, endowment, foundation, insurer or other institution).",
        "institutional client", ["CLIENT_ID"], [
            ("CLIENT_ID", "id", "Platform client id", "IC-00417"),
            ("CLIENT_NAME", "text", "Client name", "Cascadia Public Employees Retirement System"),
            ("LEGAL_NAME", "text", "Legal name", "Cascadia Public Employees Retirement System"),
            ("CLIENT_TYPE_CD", "code", "PPP public pension plan, CDB corporate DB plan, CDC corporate DC plan sponsor, END endowment, FND foundation, HLTH health system, INS insurance general account, TH Taft-Hartley plan, GOV government entity, OTH other", "PPP"),
            ("ENTITY_KIND_CD", "code", "Legal nature: PLAN retirement plan, CORP corporation, NPO nonprofit, GOV government body", "PLAN"),
            ("SEGMENT_CD", "code", "Servicing segment: OCIO, SEP institutional separate account, POOL institutional pooled, RK plan sponsor recordkept, CIT plan sponsor CIT only", "SEP"),
            ("BUS_LINE_CD", "code", "Primary business line: IA institutional advisory, PF proprietary funds", "IA"),
            ("INVESTABLE_ASSETS", "amount", "Total investable assets of the client (all managers), as reported", "4800000000"),
            ("ASSETS_ASOF_DT", "date", "As-of date of the investable assets", "2026-06-30"),
            ("GOVERNANCE_CD", "code", "CIO internal CIO/staff, ICC investment committee with consultant, ICO investment committee with OCIO, BTC board/trustees with consultant, DEL fully delegated", "BTC"),
            ("GOV_ENTITY_FLG", "boolean", "Government entity", "true"),
            ("ERISA_FLG", "boolean", "ERISA plan", "false"),
            ("EIN", "id", "Employer identification number", "91-6001234"),
            ("STATUS_CD", "code", "A active, P prospect, T terminated", "A"),
            ("CONSULTANT_ID", "id", "Advising consultant firm (CONSULTANT.CONSULTANT_ID), blank when none", "CF-003"),
        ], "about 40 rows"),
    "RELATIONSHIP": table(
        "One row per service relationship a client holds with the firm.",
        "service relationship", ["REL_ID"], [
            ("REL_ID", "id", "Relationship id", "SR-00913"),
            ("CLIENT_ID", "id", "Client (CLIENT.CLIENT_ID)", "IC-00417"),
            ("SEGMENT_CD", "code", "OCIO, SEP, POOL, RK, CIT (as CLIENT.SEGMENT_CD)", "SEP"),
            ("BUS_LINE_CD", "code", "IA institutional advisory, PF proprietary funds", "IA"),
            ("TIER_CD", "code", "T1 strategic, T2 core, T3 standard, T4 pooled/digital", "T1"),
            ("STATUS_CD", "code", "ONB onboarding, ACT active, NOT under notice, TRM terminated, DRM dormant", "ACT"),
            ("START_DT", "date", "Relationship start", "2019-03-01"),
            ("CONSULTANT_ID", "id", "Advising consultant on the relationship", "CF-003"),
            ("OCIO_SCOPE_CD", "code", "For OCIO relationships: FULL, PART, ADV; blank otherwise", ""),
            ("ERISA_FID_CD", "code", "ERISA fiduciary status: 338, 321, NONE", "NONE"),
        ], "about 48 rows"),
    "MANDATE": table(
        "One row per investment mandate (separate account or fund of one) the firm manages for a client.",
        "mandate", ["MANDATE_ID"], [
            ("MANDATE_ID", "id", "Mandate id", "MD-02210"),
            ("CLIENT_ID", "id", "Client", "IC-00417"),
            ("REL_ID", "id", "Service relationship the mandate is served under", "SR-00913"),
            ("MANDATE_NM", "text", "Mandate name", "Cascadia PERS - US Core Fixed Income"),
            ("MANDATE_TYPE_CD", "code", "SEG segregated account, SUB sub-advisory, FOO fund of one", "SEG"),
            ("STRATEGY_CD", "code", "Firm strategy code (SRC-TA FUND_MASTER PRODUCT_CD for the strategy's pooled equivalent)", "P0007"),
            ("INCEPT_DT", "date", "Mandate inception", "2019-04-15"),
            ("STATUS_CD", "code", "A active, T terminated, N notice given", "A"),
        ], "about 70 rows"),
    "HEALTH_SCORE": table(
        "Quarterly relationship health scores from the client-service review.",
        "relationship x score date", ["REL_ID", "SCORE_DT"], [
            ("REL_ID", "id", "Relationship", "SR-00913"),
            ("SCORE_DT", "date", "Score date (quarter end)", "2026-09-30"),
            ("SCORE", "number", "Overall health score, 0 to 100", "61.5"),
            ("RAG_CD", "code", "G green, A amber, R red", "R"),
            ("AT_RISK_FLG", "boolean", "Flagged at risk of termination or reduction", "true"),
            ("AT_RISK_RSN_CD", "code", "PERF underperformance, PERS personnel change, SERV service issues, STRAT client strategy change, FEE fee pressure, CONS consultant rating change, SPON plan sponsor event; blank when not at risk", "PERF"),
            ("SURVEY_ID", "id", "Survey response the score drew on, blank when none", ""),
        ], "about 190 rows (four quarters)"),
    "FUND_ACCOUNT": table(
        "The transfer agent fund accounts that belong to institutional clients (direct institutional investors).",
        "client x transfer agent account", ["TA_ACCT_NO"], [
            ("CLIENT_ID", "id", "Client", "IC-00417"),
            ("TA_ACCT_NO", "id", "Transfer agent account number (SRC-TA SHR_ACCT.ACCT_NO)", "7700500012"),
            ("REL_ID", "id", "Relationship the account is served under", "SR-00913"),
        ], "about 30 rows"),
    "CONSULTANT": table(
        "Investment consulting firms advising clients.",
        "consultant firm", ["CONSULTANT_ID"], [
            ("CONSULTANT_ID", "id", "Consultant firm id", "CF-003"),
            ("CONSULTANT_NM", "text", "Firm name", "Meridian Investment Consulting"),
            ("CONSULTANT_TYPE_CD", "code", "GEN general consultant, SPEC specialist, OCIO competing OCIO", "GEN"),
        ], "about 6 rows"),
})

# ---------------------------------------------------------------------------------------------------------------------
# SRC-PAB: the portfolio accounting book of record for institutional separate accounts (the investment book)
source("SRC-PAB", "Portfolio Accounting Book of Record", "System of record for separate-account portfolios", "Portfolio accounting system extracts",
       "Month-end extracts of the investment book of record: each separate-account portfolio, its valuation and its holdings. "
       "Portfolios link to the institutional platform's mandates and clients, and to the custodian account that holds the assets.",
       {
    "PORTFOLIO": table(
        "One row per managed portfolio (separate account).",
        "portfolio", ["PORT_ID"], [
            ("PORT_ID", "id", "Portfolio id", "P-30417"),
            ("PORT_NAME", "text", "Portfolio name", "CASCADIA PERS CORE FI"),
            ("MANDATE_ID", "id", "Mandate the portfolio implements (SRC-INST MANDATE.MANDATE_ID)", "MD-02210"),
            ("CLIENT_ID", "id", "Client (SRC-INST CLIENT.CLIENT_ID)", "IC-00417"),
            ("PORT_TYPE_CD", "code", "SEP separate account, FOO fund of one", "SEP"),
            ("BASE_CCY", "code", "Base currency", "USD"),
            ("INCEPT_DT", "date", "Inception date", "2019-04-15"),
            ("STATUS_CD", "code", "A active, T terminated, L in liquidation", "A"),
            ("CUSTODIAN_CD", "code", "Custodian bank: NTRS, BNYM, STT, JPM", "NTRS"),
            ("CUSTODY_ACCT_NO", "id", "Custodian account number holding the assets", "NT-8841207"),
            ("LEGAL_OWNER_CD", "code", "Legal owner: CLIENT (the client owns the assets)", "CLIENT"),
            ("MGMT_ENTITY_CD", "code", "Managing entity: IA the firm's investment adviser", "IA"),
        ], "about 60 rows"),
    "VALUATION": table(
        "Month-end portfolio valuations.",
        "as-of date x portfolio", ["ASOF_DT", "PORT_ID"], [
            ("ASOF_DT", "date", "Valuation date", "2026-09-30"),
            ("PORT_ID", "id", "Portfolio", "P-30417"),
            ("HOLDINGS_MKT_VAL", "amount", "Market value of securities held", "412803112.55"),
            ("CASH_VAL", "amount", "Cash and equivalents", "6120044.10"),
            ("ACCRUED_INCOME", "amount", "Accrued income", "1402311.00"),
            ("TOTAL_MKT_VAL", "amount", "Total portfolio value (holdings + cash + accrued)", "420325467.65"),
            ("VIEW_CD", "code", "EOD end of day", "EOD"),
        ], "about 240 rows (four month-ends)"),
    "HOLDING": table(
        "Month-end holdings of each portfolio.",
        "as-of date x portfolio x security", ["ASOF_DT", "PORT_ID", "SECURITY_ID"], [
            ("ASOF_DT", "date", "Holding date", "2026-09-30"),
            ("PORT_ID", "id", "Portfolio", "P-30417"),
            ("SECURITY_ID", "id", "Security identifier (CUSIP; own funds carry the share class CUSIP)", "912828YK0"),
            ("QTY", "number", "Quantity held", "25000000.000"),
            ("PRICE", "number", "Price", "98.4375"),
            ("MKT_VAL", "amount", "Market value", "24609375.00"),
            ("ASSET_CLS_CD", "code", "EQ equity, FI fixed income, CASH, OWNF own fund", "FI"),
            ("VIEW_CD", "code", "EOD end of day", "EOD"),
        ], "about 2,000 rows"),
})


def dictionary_rows(src_id):
    """Rows of the data dictionary a source publishes: (table, column, type, description, example, table_grain)."""
    s = SOURCES[src_id]
    return [(t, c[0], c[1], c[2], c[3], d["grain"]) for t, d in s["tables"].items() for c in d["columns"]]


if __name__ == "__main__":
    for sid, s in SOURCES.items():
        n = sum(len(t["columns"]) for t in s["tables"].values())
        print(f"{sid} {s['name']}: {len(s['tables'])} tables, {n} columns")

# ---------------------------------------------------------------------------------------------------------------------
# SRC-BIL: the advisory fee billing engine (fee schedules, assignments, runs, calculations, waivers and debits)
source("SRC-BIL", "Advisory Fee Billing Engine", "System of record for client fee billing", "Billing engine database extracts",
       "Nightly table extracts of the firm's fee billing engine. It bills the advisory, wrap, trust and planning programs "
       "of the brokerage platform's enrolled accounts quarterly in arrears. Accounts are keyed by the brokerage account "
       "number; fee groups (households for breakpoints) by the CRM household id. Amounts are USD; dates are ISO.",
       {
    "SCHEDULE": table(
        "One row per fee schedule version (every rate, tier, minimum or billing-term change is a new version).",
        "fee schedule version", ["SCHED_ID"], [
            ("SCHED_ID", "id", "Schedule version id: family, then version number", "S-ADV-STD-3"),
            ("FAMILY_CD", "code", "Schedule family the versions belong to", "ADV-STD"),
            ("SCHED_NM", "text", "Schedule name as shown to clients and in Form ADV Part 2A", "Personal Advisor Standard Schedule"),
            ("SCHED_TYPE_CD", "code", "ADV asset-based advisory, WRAP wrap fee, FLAT flat fee, SUB subscription, SVC account service, TRST trust administration", "ADV"),
            ("VERSION_NO", "integer", "Version number within the family", "3"),
            ("STATUS_CD", "code", "D draft, P proposed, A active, R retired", "A"),
            ("EFF_FROM_DT", "date", "First date fees may be calculated under this version", "2025-01-01"),
            ("EFF_TO_DT", "date", "Last date; blank while current", ""),
            ("BASIS_CD", "code", "Billing basis: ADV average daily value, AME average month-end value, PEV period-end value, FLAT flat", "AME"),
            ("TIER_METHOD_CD", "code", "BL blended (each tier's rate on the value within the tier), CL cliff (one rate on the whole value), SR single rate", "BL"),
            ("BILL_FREQ_CD", "code", "Default billing frequency: Q quarterly, M monthly, A annual", "Q"),
            ("BILL_TIMING_CD", "code", "ARR in arrears, ADV in advance", "ARR"),
            ("MIN_ANNUAL_FEE", "amount", "Minimum annual fee; 0 when none", "0"),
            ("MAX_RATE_BPS", "number", "Highest annual rate the schedule allows, basis points", "95"),
            ("OWN_FUND_CD", "code", "Own-fund treatment: EXCL excluded from billable assets, CRED credited against the fee, NONE billed without offset", "CRED"),
            ("ADV_REF", "text", "Form ADV Part 2A item and brochure edition", "Item 5, March 2026"),
            ("PRIOR_SCHED_ID", "id", "Version this one replaced; blank for the first", "S-ADV-STD-2"),
        ], "about 14 rows"),
    "SCHEDULE_TIER": table(
        "Rate tiers of each schedule version.",
        "schedule version x tier", ["SCHED_ID", "TIER_NO"], [
            ("SCHED_ID", "id", "Schedule version", "S-ADV-STD-3"),
            ("TIER_NO", "integer", "Tier order from the lowest band", "1"),
            ("LOWER_BOUND", "amount", "Inclusive lower bound of billable value", "0"),
            ("UPPER_BOUND", "amount", "Exclusive upper bound; blank for the top tier", "500000"),
            ("RATE_BPS", "number", "Annual rate for the band, basis points", "90"),
        ], "about 40 rows"),
    "FEE_GROUP": table(
        "Fee groups: the households whose combined assets set breakpoints.",
        "fee group x effective period", ["GROUP_ID"], [
            ("GROUP_ID", "id", "Fee group id", "FG-00031"),
            ("CRM_HH_ID", "id", "CRM household the group starts from (SRC-CRM Account.Id); blank for an entity group", "001Ab0000000031IAJ"),
            ("BASIS_CD", "code", "HH from the CRM household, LINK client-requested link, ENT entity group", "HH"),
            ("STATUS_CD", "code", "A active, I inactive", "A"),
            ("EFF_FROM_DT", "date", "Date from which the group's aggregated assets set breakpoints", "2024-01-01"),
            ("EFF_TO_DT", "date", "Date after which the group no longer applies; blank while active", ""),
        ], "about 60 rows"),
    "FEE_GROUP_MBR": table(
        "Member accounts of each fee group.",
        "fee group x account x effective period", ["GROUP_ID", "ACCT_NO", "EFF_FROM_DT"], [
            ("GROUP_ID", "id", "Fee group", "FG-00031"),
            ("ACCT_NO", "id", "Brokerage account number (SRC-BRK ACCT_MASTER.ACCT_NO)", "30017422"),
            ("BASIS_CD", "code", "HH member of the household, LINK linked at the client's request, ENT entity group member", "HH"),
            ("STATUS_CD", "code", "A active, P proposed (awaiting confirmation), I inactive", "A"),
            ("EFF_FROM_DT", "date", "Date from which the account's assets count", "2024-01-01"),
            ("EFF_TO_DT", "date", "Date after which they no longer count; blank while active", ""),
        ], "about 150 rows"),
    "ASSIGNMENT": table(
        "Which schedule version bills which enrolled account, from when, and which account pays.",
        "billed account x schedule x period", ["ASSIGN_ID"], [
            ("ASSIGN_ID", "id", "Assignment id", "FA-000217"),
            ("ACCT_NO", "id", "Billed brokerage account (the enrolled account)", "30017422"),
            ("PROGRAM_CD", "code", "Program the account is enrolled in (SRC-BRK ACCT_MASTER.PROGRAM_CD): DAP, PAS, WMP, TRS", "PAS"),
            ("SCHED_ID", "id", "Schedule version in force for the assignment period", "S-ADV-STD-3"),
            ("PAY_ACCT_NO", "id", "Account the fee is debited from (usually the billed account)", "30017422"),
            ("COLLECT_CD", "code", "DED deducted from the fee-paying account, INV invoiced", "DED"),
            ("BILL_FREQ_CD", "code", "Q quarterly, M monthly", "Q"),
            ("BILL_TIMING_CD", "code", "ARR in arrears, ADV in advance", "ARR"),
            ("GROUP_ID", "id", "Fee group whose assets set the breakpoint; blank when none", "FG-00031"),
            ("NEGOTIATED_FLG", "boolean", "A negotiated rate override applies", "false"),
            ("EFF_FROM_DT", "date", "First day billed under this schedule version", "2025-01-01"),
            ("EFF_TO_DT", "date", "Last day; blank while current", ""),
        ], "about 170 rows"),
    "FEE_RUN": table(
        "Fee calculation runs.",
        "run", ["RUN_ID"], [
            ("RUN_ID", "id", "Run id: billing period and sequence", "R-2026Q3-01"),
            ("PERIOD_START_DT", "date", "First day of the billing period", "2026-07-01"),
            ("PERIOD_END_DT", "date", "Last day of the billing period", "2026-09-30"),
            ("RUN_TYPE_CD", "code", "REG regular period run, ONB onboarding pro rata, TRM termination pro rata, RECALC recalculation, SIM simulation", "REG"),
            ("VAL_DT", "date", "As-of date of the valuations used", "2026-09-30"),
            ("STATUS_CD", "code", "SCH scheduled, CALC calculated, REV in review, APPR approved, REL released for collection", "REL"),
            ("RECON_CD", "code", "Reconciliation of the run's totals: REC reconciled, TOL within tolerance, BRK break open, EXPL break explained, NR not reconciled", "REC"),
            ("APPROVED_BY", "id", "CRM user who approved the run (SRC-CRM User.Id); blank when not approved", "005Ab0000000031IAJ"),
            ("NET_FEE_TOTAL", "amount", "Control total: the sum of the net fee of the run's calculations as the engine recorded it", "1284311.52"),
        ], "about 9 rows"),
    "FEE_CALC": table(
        "One calculation per run and assignment.",
        "run x assignment", ["RUN_ID", "ASSIGN_ID"], [
            ("RUN_ID", "id", "Run", "R-2026Q3-01"),
            ("ASSIGN_ID", "id", "Assignment the fee was calculated for", "FA-000217"),
            ("SCHED_ID", "id", "Schedule version actually applied by the engine", "S-ADV-STD-3"),
            ("ACCT_VALUE", "amount", "Account value on the billing basis at the valuation date", "1250000.00"),
            ("BILLABLE_ASSETS", "amount", "Account value less billable-asset exclusions", "1250000.00"),
            ("GROUP_ASSETS", "amount", "Combined billable assets of the fee group used for the breakpoint; blank when no group was applied", "2100000.00"),
            ("RATE_BPS", "number", "Effective annual rate that resulted, basis points", "72.5"),
            ("GROSS_FEE", "amount", "Fee for the period at the effective rate, pro-rated where applicable", "2265.63"),
            ("DISCOUNT_AMT", "amount", "Reduction from discount rules", "0"),
            ("WAIVER_AMT", "amount", "Reduction from waivers applied", "0"),
            ("OWN_FUND_CREDIT", "amount", "Credit for own-fund holdings under a CRED schedule", "112.40"),
            ("NET_FEE", "amount", "Fee due after discounts, waivers and credit", "2153.23"),
            ("EXCEPTION_FLG", "boolean", "The calculation raised an exception", "false"),
            ("PRORATE_DAYS", "integer", "Days billed when the account joined or left mid-period; blank for a full period", ""),
            ("WAIVER_IDS", "text", "Waivers applied, '; '-separated; blank when none", ""),
        ], "about 600 rows"),
    "WAIVER": table(
        "Fee waivers.",
        "waiver", ["WAIVER_ID"], [
            ("WAIVER_ID", "id", "Waiver id", "W-00012"),
            ("ASSIGN_ID", "id", "Assignment whose fee is waived", "FA-000217"),
            ("REASON_CD", "code", "PROMO promotional, SVC service recovery, EMP employee or affiliate, REL relationship concession, OTH other", "SVC"),
            ("PCT", "number", "Share of the fee waived, percent; blank when an amount", "100"),
            ("AMT", "amount", "Fixed amount waived; blank when a percentage", ""),
            ("START_DT", "date", "First day of the billing periods covered", "2026-07-01"),
            ("END_DT", "date", "Last day; blank while open", "2026-12-31"),
            ("APPROVED_BY", "id", "CRM user who approved the waiver; blank when unapproved", "005Ab0000000031IAJ"),
        ], "about 12 rows"),
    "DEBIT": table(
        "Fee debits instructed against accounts.",
        "debit", ["DEBIT_ID"], [
            ("DEBIT_ID", "id", "Debit id: billing period and sequence", "D-2026Q2-000217"),
            ("RUN_ID", "id", "Run the debit collects", "R-2026Q2-01"),
            ("ASSIGN_ID", "id", "Assignment", "FA-000217"),
            ("FEE_TYPE_CD", "code", "Kind of fee collected: ADV, WRAP, FLAT, SUB, SVC, TRST (as SCHEDULE.SCHED_TYPE_CD)", "ADV"),
            ("ACCT_NO", "id", "Account debited", "30017422"),
            ("DEBIT_DT", "date", "Date the debit was instructed to post", "2026-07-08"),
            ("STATUS_CD", "code", "PEND pending, POST posted, FAIL failed, REV reversed, CANC canceled", "POST"),
            ("FAIL_RSN", "text", "Why a failed debit did not post; blank otherwise", ""),
            ("AMT", "amount", "Amount deducted", "2153.23"),
        ], "about 420 rows"),
})

# ---------------------------------------------------------------------------------------------------------------------
# SRC-REV: the revenue sub-ledger (client revenue by account, stream and fiscal month; own-fund fee revenue by share class)
source("SRC-REV", "Revenue Sub-Ledger", "System of record for recognized revenue", "Finance sub-ledger extracts",
       "Monthly extracts of the revenue sub-ledger that feeds the general ledger: client revenue recognized per account, "
       "revenue stream and fiscal month, and the management fee revenue of the firm's own funds per share class and "
       "month. Fiscal months are calendar months (the fiscal year is the calendar year). Amounts are USD.",
       {
    "CLIENT_REV": table(
        "Client revenue recognized per account, stream and fiscal month.",
        "account x stream x fiscal month", ["REV_ID"], [
            ("REV_ID", "id", "Record id", "CR-2026-09-000731"),
            ("FISCAL_MONTH", "code", "Fiscal month YYYY-MM", "2026-09"),
            ("ACCT_NO", "id", "Brokerage account the revenue is earned on (SRC-BRK ACCT_MASTER.ACCT_NO)", "30017422"),
            ("STREAM_CD", "code", "ADVF advisory fee, WRAP wrap fee, PLAN planning fee, SUBS subscription fee, COMM commission, MKUP markup/markdown, SVCF account service fee, MGNI margin interest, FPLR fully paid lending revenue, SWPF bank sweep fee, TRST trust fee, ORP order routing payment, OTH other", "ADVF"),
            ("OFFERING_CD", "code", "Service offering the revenue is earned under: DAP, PAS, WMP, TRS, HYB, PLN, BRK", "PAS"),
            ("CHANNEL_CD", "code", "Channel of the account at period end (SRC-BRK ACCT_MASTER.CHANNEL_CD): SD, DA, HA, TR", "HA"),
            ("BUS_LINE_CD", "code", "Business line of the account at period end: DB direct brokerage, DA digital advice, HA human advice, TR trust", "HA"),
            ("SEGMENT_CD", "code", "Client value segment of the account's household at period end (SRC-CRM Account.Segment__c): Core, Select, Private, Flagship", "Select"),
            ("LEGAL_ENT_CD", "code", "Recognizing legal entity: IA the adviser, BD the broker-dealer, TC the trust company", "IA"),
            ("SOURCE_REF", "text", "Billing record the amount comes from: '<RUN_ID>|<ASSIGN_ID>' of SRC-BIL FEE_CALC for fee streams; blank for transactional streams", "R-2026Q3-01|FA-000217"),
            ("AMT", "amount", "Revenue recognized for the month", "717.74"),
            ("BASIS_CD", "code", "ACT actual (settled), EST accrued estimate, ALLOC allocated", "ACT"),
        ], "about 12,000 rows (twelve months)"),
    "FUND_REV": table(
        "Management fee revenue of the firm's own funds per share class and fiscal month, as accrued by fund accounting.",
        "share class x fiscal month", ["REV_ID"], [
            ("REV_ID", "id", "Record id", "FR-2026-09-0101"),
            ("FISCAL_MONTH", "code", "Fiscal month YYYY-MM", "2026-09"),
            ("FUND_NO", "id", "Fund number (SRC-TA FUND_MASTER.FUND_NO)", "0101"),
            ("CLASS_CD", "code", "Share class code (SRC-TA FUND_MASTER.CLASS_CD)", "INV"),
            ("AVG_NET_ASSETS", "amount", "Average net assets of the class used to accrue the fee", "512000000.00"),
            ("BASIS_SRC_CD", "code", "Where the asset basis came from: FA fund accounting NAV, TA transfer agent records", "FA"),
            ("GROSS_RATE_BPS", "number", "Annual management fee rate applied, basis points", "35"),
            ("GROSS_FEE", "amount", "Management fee earned before fund-level waivers and reimbursements", "149333.33"),
            ("WAIVER_OFFSET", "amount", "Fund-level waivers and reimbursements netted against revenue", "8500.00"),
            ("NET_FEE", "amount", "Fee revenue after waivers; the amount recognized", "140833.33"),
            ("BASIS_CD", "code", "FIN final, EST accrued estimate", "FIN"),
            ("SUBADV_FEE", "amount", "Sub-advisory fee payable to an external sub-adviser for the class; 0 when none", "0"),
            ("SUBADV_ENG_ID", "id", "Sub-adviser engagement; blank when none", ""),
        ], "about 620 rows"),
})

# ---------------------------------------------------------------------------------------------------------------------
# SRC-CST: the cost allocation engine (cost pools, methods, rules, runs and allocated results)
source("SRC-CST", "Cost Allocation Engine", "System of record for cost allocation", "Management accounting engine extracts",
       "Monthly extracts of the cost allocation engine: the cost pools the ledger's operating expense flows into, the "
       "rules and drivers that allocate each pool to profitability dimensions, each month's allocation run and its "
       "results. Dimension members use the enterprise codes (channel and business line as the certified client-asset "
       "family keys them, CRM segment names, program codes for offerings, T1 to T4 for service tiers).",
       {
    "POOL": table(
        "Cost pools.",
        "cost pool", ["POOL_ID"], [
            ("POOL_ID", "id", "Pool id", "CP-ADV"),
            ("POOL_NM", "text", "Pool name", "Advisor Coverage and Planning"),
            ("POOL_TYPE_CD", "code", "ADV advice, SVC client service, PLAT platform and technology, CLR clearing and custody operations, MM money movement operations, COMM client communications, COMP compliance and supervision, MKT marketing and acquisition, PROD product management, DIST intermediary distribution, CORP corporate overhead", "ADV"),
            ("CTS_COMP_CD", "code", "Cost-to-serve component the pool reports under: ADV advice, SVC service, PLAT platform, CLR clearing and custody, MM money movement, COMM communications, REG regulatory; blank for pools outside cost to serve (MKT, DIST, PROD, CORP)", "ADV"),
            ("COST_CENTERS", "text", "Contributing cost center codes, '; '-separated", "CC-4100; CC-4120"),
            ("CATEGORIES", "text", "Included expense categories, '; '-separated: ADVCOMP advisor base compensation, ADVINC advisor incentive, SVCCOMP service staff compensation, MKTG marketing and acquisition spend, CLRFEE clearing and exchange fees, CCTECH contact center technology, PLTECH platform technology, DATA third-party data, MAIL statement and mailing, REGFEE regulatory fees, REVSHR revenue sharing, SUBTA sub-TA and networking fees, OTH other", "ADVCOMP; ADVINC"),
        ], "about 11 rows"),
    "METHOD": table(
        "Allocation methods.",
        "method", ["METHOD_ID"], [
            ("METHOD_ID", "id", "Method id", "M-DRV"),
            ("METHOD_NM", "text", "Method name", "Driver-based"),
            ("METHOD_TYPE_CD", "code", "DIRECT direct assignment, DRIVER driver-based, ABC activity-based, TDABC time-driven activity-based, REV proportional to revenue, FIXED fixed percentage, STEP step-down, RECIP reciprocal", "DRIVER"),
        ], "about 5 rows"),
    "RULE": table(
        "Allocation rules: which pool goes to which dimension by which method and driver.",
        "rule", ["RULE_ID"], [
            ("RULE_ID", "id", "Rule id", "AR-0007"),
            ("POOL_ID", "id", "Source pool", "CP-ADV"),
            ("METHOD_ID", "id", "Method applied", "M-DRV"),
            ("DRIVER_CD", "code", "Driver applied: ADVHRS advisor hours, HH households, ACCTS accounts, AUM client assets, TXN transactions, REV revenue, CONTACTS service contacts, FIXED fixed split", "ADVHRS"),
            ("TARGET_DIM_CD", "code", "Dimension allocated to: SEG client segment, CHAN channel, BL business line, OFF service offering, TIER service tier, POOL another pool (step-down)", "SEG"),
            ("SEQ_NO", "integer", "Order in the step-down", "10"),
            ("EFF_FROM_DT", "date", "Rule applies from", "2025-01-01"),
            ("EFF_TO_DT", "date", "Rule ends; blank while current", ""),
        ], "about 40 rows"),
    "RUN": table(
        "Allocation runs, one final run per fiscal month and data version.",
        "run", ["RUN_ID"], [
            ("RUN_ID", "id", "Run id", "ALR-2026-09-ACT-1"),
            ("FISCAL_MONTH", "code", "Fiscal month allocated, YYYY-MM", "2026-09"),
            ("VERSION_CD", "code", "ACT actual, BUD budget, FCST forecast", "ACT"),
            ("STATUS_CD", "code", "DRAFT, PRELIM preliminary, FINAL, SUPER superseded", "FINAL"),
            ("RESIDUAL_AMT", "amount", "Pool cost left unallocated (unused capacity)", "41250.00"),
        ], "about 15 rows"),
    "POOL_COST": table(
        "Ledger operating expense that flowed into each pool for the run's month.",
        "run x pool", ["RUN_ID", "POOL_ID"], [
            ("RUN_ID", "id", "Run", "ALR-2026-09-ACT-1"),
            ("POOL_ID", "id", "Pool", "CP-ADV"),
            ("SOURCE_COST", "amount", "Operating expense of the pool's cost centers and categories for the month", "1830000.00"),
        ], "about 165 rows"),
    "RESULT": table(
        "Allocated amounts per run, rule and target member.",
        "run x rule x target member", ["RUN_ID", "RULE_ID", "TARGET_MEMBER"], [
            ("RUN_ID", "id", "Run", "ALR-2026-09-ACT-1"),
            ("RULE_ID", "id", "Rule that produced the result", "AR-0007"),
            ("TARGET_DIM_CD", "code", "Dimension of the member (as RULE.TARGET_DIM_CD)", "SEG"),
            ("TARGET_MEMBER", "code", "Member receiving the allocation: a channel code (DIRECT_SELF_DIRECTED ...), business line code (DB, DA, HA, TR, PF, IA, IC), segment (Core, Select, Private, Flagship), offering (DAP, PAS, WMP, TRS, HYB, PLN, BRK), tier (T1 to T4) or pool id", "Select"),
            ("DRIVER_SHARE", "number", "Member's share of the driver quantity, percent", "23.4"),
            ("AMT", "amount", "Cost allocated to the member", "428220.00"),
        ], "about 2,500 rows"),
})
