"""Business domain 01 - Investment Product. Content module for taxonomy_builder.py."""

META = {
 "title": "Investment Product Reference Data Taxonomy",
 "subtitle": "Business domain 01 - Product | Asset manager (wholesale distributor) | Scope: US + EU/UK | Draft v0.1 | 2026-10-01",
 "output": "01_Product/Investment_Product_Reference_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the investment product data domain of an asset manager, stitched together from open industry standards (FIBO CIV, openfunds, FinDatEx EMT/EPT/EET, ISO, GIPS) and regulation (UCITS, AIFMD, PRIIPs, MiFID II, SFDR, SEC). Use it as a starting point for a product master, a data catalogue or a business glossary."),
  ("Scope", "In scope: investment strategies, pooled vehicles, separate accounts/mandates, model portfolios, share classes and the reference data describing them. Out of scope: instrument / security master for holdings, transactional data (orders, flows), time-series data (NAVs, AUM, performance returns), client/party master (see 02_Client_and_Customer), distribution agreements and platform shelf status (see 05_Distribution_Agreements_and_Partners)."),
  ("Structure", "Four levels: Domain > Subdomain > Concept > Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Strategy (what we manage) -> Product / Vehicle (how it is packaged: fund, ETF, CIT, SMA, mandate, model) -> Share Class (how investors own it). Most classification is set at Strategy and inherited by Product; most commercial terms (fees, currency, distribution, registration, identifiers) live at Share Class."),
  ("Design principles", "1) Reuse standards: openfunds field definitions and FIBO CIV concepts are the default; internal attributes only where no standard exists. 2) Effective-date everything that changes (classifications, benchmarks, parties, registrations, fees). 3) Use controlled code lists, not free text. 4) Reference parties, benchmarks and calendars by ID rather than copying them. 5) Flag Critical Data Elements (CDE) for governance and data-quality focus."),
  ("Applies To", "Shows the level at which each attribute is held: Strategy, Composite, Product, Mandate, Model, Share Class, Benchmark or All."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify, distribute, price or report on the product. Confirm with data owners."),
  ("Primary / Secondary Reference", "Standard or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Next step: map each openfunds- and FinDatEx-aligned attribute to its exact field ID in the current version of those standards."),
  ("Tabs", "Hierarchy: domains, subdomains and concepts with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: concept-level cardinalities for the logical model | Sources: standards used, owners, licences and links."),
  ("Suggested next steps", "1) Validate domains and CDEs with Product, Distribution, Legal/Compliance and Operations. 2) Map attributes to source systems (fund admin, TA, OMS/PMS, CRM, document management). 3) Map to openfunds / FinDatEx field IDs. 4) Agree data owners and stewards per subdomain. 5) Extend code lists to firm values. 6) Turn the Relationships tab into a logical data model."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

D("Investment Strategy", "STR",
  "The investment capability or approach the firm manages, independent of the vehicle(s) through which it is offered to clients.",
  [
   ("Strategy Definition", "Core identity and ownership of an investment strategy.", [
     ("Investment Strategy", [
       ("Strategy ID", "Unique internal identifier for the investment strategy.", "Strategy", "Identifier", "", "STR-00123", "Internal", "", "Y"),
       ("Strategy Name", "Official name of the strategy as used in governance, RFPs and reporting.", "Strategy", "Text", "", "Global Sustainable Equity", "Internal", "GIPS", "Y"),
       ("Strategy Description", "Narrative description of the investment philosophy and process.", "Strategy", "Text", "", "High-conviction portfolio of 30-50 global companies with durable sustainable growth", "Internal", "", ""),
       ("Strategy Investment Objective", "Return and/or risk objective of the strategy, independent of any vehicle.", "Strategy", "Text", "", "Outperform MSCI ACWI NR by 2% p.a. over rolling 5 years", "GIPS", "", ""),
       ("Strategy Inception Date", "Date the strategy began managing assets; start of the strategy track record.", "Strategy", "Date", "ISO 8601", "2012-04-01", "GIPS", "", "Y"),
       ("Strategy Status", "Current lifecycle status of the strategy.", "Strategy", "Code", "Lifecycle Status", "Active", "Internal", "", "Y"),
       ("Investment Team", "Investment team or desk accountable for managing the strategy.", "Strategy", "Reference", "Firm-defined", "Global Equities", "Internal", "", ""),
       ("Lead Portfolio Manager", "Party reference for the named lead portfolio manager(s) of the strategy.", "Strategy", "Reference (Party)", "", "PTY-0457", "Internal", "openfunds", ""),
       ("Investment Affiliate / Boutique", "Affiliate or boutique that owns the strategy in a multi-boutique firm.", "Strategy", "Reference (Party)", "", "PTY-0012", "Internal", "", ""),
     ]),
   ]),
   ("Strategy Classification", "Firm-standard classification facets assigned at strategy level and inherited by products by default.", [
     ("Strategy Classification", [
       ("Asset Class", "Primary asset class of the strategy.", "Strategy", "Code", "Asset Class", "Equity", "Internal", "EFAMA EFC", "Y"),
       ("Sub-Asset Class", "Secondary asset class grouping within the primary asset class.", "Strategy", "Code", "Sub-Asset Class (firm-defined)", "Global Equity", "Internal", "EFAMA EFC", ""),
       ("Investment Approach", "Management approach of the strategy (active, passive, factor, etc.).", "Strategy", "Code", "Investment Approach", "Active Fundamental", "Internal", "openfunds", "Y"),
       ("Investment Style", "Style orientation of the strategy.", "Strategy", "Code", "Investment Style", "Growth", "Internal", "Morningstar", ""),
       ("Market Capitalisation Focus", "Market capitalisation segment targeted (equity strategies).", "Strategy", "Code", "Market Cap Focus", "Large Cap", "Internal", "Morningstar", ""),
       ("Geographic Focus", "Primary geographic investment universe.", "Strategy", "Code", "Geographic Focus", "Global", "Internal", "EFAMA EFC", "Y"),
       ("Sector / Thematic Focus", "Sector or theme the strategy concentrates on, where applicable.", "Strategy", "Text", "", "Clean Energy", "Internal", "", ""),
       ("Public / Private Markets Indicator", "Whether the strategy invests in public, private or both markets.", "Strategy", "Code", "Market Type", "Public", "Internal", "", ""),
       ("Liquidity Profile", "Liquidity offered to investors by vehicles implementing the strategy.", "Strategy", "Code", "Liquidity Profile", "Daily", "Internal", "", ""),
     ]),
   ]),
   ("Composite (GIPS)", "GIPS composites used to present strategy performance to prospective clients.", [
     ("GIPS Composite", [
       ("Composite ID", "Unique identifier for the GIPS composite.", "Composite", "Identifier", "", "CMP-0045", "GIPS", "", "Y"),
       ("Composite Name", "Name of the composite as presented in GIPS reports.", "Composite", "Text", "", "Global Sustainable Equity Composite", "GIPS", "", "Y"),
       ("Composite Definition", "Documented criteria determining which portfolios belong to the composite.", "Composite", "Text", "", "All discretionary fee-paying portfolios managed to the Global Sustainable Equity strategy...", "GIPS", "", ""),
       ("Composite Creation Date", "Date the composite was created.", "Composite", "Date", "ISO 8601", "2013-01-01", "GIPS", "", ""),
       ("Composite Inception Date", "Date from which composite performance is presented.", "Composite", "Date", "ISO 8601", "2012-04-01", "GIPS", "", ""),
       ("Composite Benchmark", "Benchmark against which composite performance is presented.", "Composite", "Reference (Benchmark)", "", "BMK-0001", "GIPS", "", ""),
       ("Minimum Portfolio Size", "Asset threshold below which portfolios are excluded from the composite.", "Composite", "Amount", "", "USD 5,000,000", "GIPS", "", ""),
       ("Significant Cash Flow Policy", "Policy for temporarily removing portfolios with significant cash flows.", "Composite", "Text", "", "Remove if external flow > 10% of portfolio value", "GIPS", "", ""),
       ("Composite Member", "Effective-dated membership of products and mandates in the composite.", "Composite", "Reference (Product / Mandate)", "", "PRD-00981 from 2015-06-01", "GIPS", "", ""),
     ]),
   ]),
  ])

D("Product & Vehicle", "PRD",
  "The legal or contractual vehicle through which a strategy is offered to clients: pooled funds, separate accounts, mandates and model portfolios.",
  [
   ("Product Definition", "Core identity of an investment product or vehicle.", [
     ("Investment Product", [
       ("Product ID", "Unique internal identifier for the product or vehicle.", "Product", "Identifier", "", "PRD-00981", "Internal", "FIBO CIV", "Y"),
       ("Product Legal Name", "Legal name of the product per constitutional documents.", "Product", "Text", "", "Example Funds SICAV - Global Sustainable Equity Fund", "openfunds", "FIBO CIV", "Y"),
       ("Product Marketing Name", "Short or marketing name used in client communications.", "Product", "Text", "", "Global Sustainable Equity Fund", "Internal", "", ""),
       ("Product Description", "Short description of the product for catalogues and websites.", "Product", "Text", "", "", "Internal", "", ""),
       ("Vehicle Type", "Type of investment vehicle.", "Product", "Code", "Vehicle Type", "Open-Ended Fund", "FIBO CIV", "openfunds", "Y"),
       ("Implemented Strategy", "Strategy that the product implements.", "Product", "Reference (Strategy)", "", "STR-00123", "Internal", "", "Y"),
       ("Base Currency", "Currency in which the product's NAV and accounts are kept.", "Product", "Code", "ISO 4217", "USD", "openfunds", "FinDatEx EMT", "Y"),
       ("Product Inception Date", "Date the product was launched / first priced.", "Product", "Date", "ISO 8601", "2015-06-01", "openfunds", "FIBO CIV", "Y"),
       ("Fiscal Year End", "Month and day of the product's financial year end.", "Product", "Text", "MM-DD", "12-31", "openfunds", "", ""),
       ("Product Range", "Commercial product range or line the product belongs to.", "Product", "Code", "Firm-defined", "Sustainable Range", "Internal", "", ""),
     ]),
   ]),
   ("Legal Structure", "Legal form, regulatory regime and structural features of pooled vehicles.", [
     ("Fund Legal Structure", [
       ("Legal Form", "Legal form of the vehicle.", "Product", "Code", "Legal Form", "SICAV", "FIBO CIV", "openfunds", "Y"),
       ("Regulatory Regime", "Regulatory framework the vehicle is authorised or operated under.", "Product", "Code", "Regulatory Regime", "UCITS", "openfunds", "FinDatEx EMT", "Y"),
       ("Fund Domicile", "Country in which the vehicle is legally domiciled.", "Product", "Code", "ISO 3166-1 alpha-2", "LU", "openfunds", "FIBO CIV", "Y"),
       ("Fund LEI", "Legal Entity Identifier of the fund or sub-fund.", "Product", "Identifier", "ISO 17442", "5493001KJTIIGC8Y1R12", "ISO 17442 (GLEIF)", "openfunds", "Y"),
       ("Umbrella Indicator", "Whether the vehicle is an umbrella structure containing sub-funds.", "Product", "Boolean", "", "N", "FIBO CIV", "openfunds", ""),
       ("Umbrella Fund", "Reference to the umbrella fund of which this product is a sub-fund.", "Product", "Reference (Product)", "", "PRD-00900", "FIBO CIV", "openfunds", "Y"),
       ("Segregated Liability Indicator", "Whether assets and liabilities are segregated between sub-funds.", "Product", "Boolean", "", "Y", "openfunds", "", ""),
       ("Fund Openness", "Whether the vehicle is open-ended, closed-ended or periodically open.", "Product", "Code", "Fund Openness", "Open-Ended", "FIBO CIV", "openfunds", "Y"),
       ("Fund of Funds Indicator", "Whether the vehicle primarily invests in other collective investment schemes.", "Product", "Boolean", "", "N", "openfunds", "FinDatEx EMT", ""),
       ("Master-Feeder Role", "Role of the vehicle in a master-feeder structure.", "Product", "Code", "Master-Feeder Role", "Standalone", "openfunds", "UCITS Directive", ""),
       ("Master Fund", "Reference to the master fund, where the product is a feeder.", "Product", "Reference (Product)", "", "", "openfunds", "", ""),
       ("Legal Registration Number", "Company or trade register number of the vehicle.", "Product", "Text", "", "RCS B123456", "Internal", "", ""),
       ("Constitutional Document Date", "Date of the current prospectus / trust deed / articles.", "Product", "Date", "ISO 8601", "2026-03-15", "Internal", "", ""),
     ]),
   ]),
   ("Separate Account & Mandate", "Contractual arrangements where the firm manages assets for a single client.", [
     ("Investment Mandate", [
       ("Mandate ID", "Unique identifier for the separate account or mandate.", "Mandate", "Identifier", "", "MND-01234", "Internal", "", "Y"),
       ("Mandate Name", "Name of the mandate.", "Mandate", "Text", "", "XYZ Pension Plan - Global Equity", "Internal", "", ""),
       ("Mandate Type", "Type of separately managed arrangement.", "Mandate", "Code", "Mandate Type", "Segregated Account", "Internal", "", "Y"),
       ("Client", "Party reference of the client / account owner.", "Mandate", "Reference (Party)", "", "PTY-2201", "Internal", "", "Y"),
       ("Implemented Strategy", "Strategy the mandate is managed to.", "Mandate", "Reference (Strategy)", "", "STR-00123", "Internal", "", "Y"),
       ("Investment Management Agreement Date", "Date the governing IMA was signed.", "Mandate", "Date", "ISO 8601", "2019-09-30", "Internal", "", ""),
       ("Custom Guidelines Indicator", "Whether the mandate has client-specific guidelines that deviate from the strategy model.", "Mandate", "Boolean", "", "Y", "Internal", "", ""),
       ("Minimum Account Size", "Minimum asset size accepted for this mandate type.", "Mandate", "Amount", "", "USD 50,000,000", "Internal", "", ""),
       ("Mandate Base Currency", "Reference currency of the mandate.", "Mandate", "Code", "ISO 4217", "GBP", "Internal", "", ""),
     ]),
   ]),
   ("Model Portfolio", "Model portfolios delivered to third-party platforms or sponsors for implementation.", [
     ("Model Portfolio", [
       ("Model Portfolio ID", "Unique identifier for the model portfolio.", "Model", "Identifier", "", "MDL-0077", "Internal", "", "Y"),
       ("Model Portfolio Name", "Name of the model portfolio.", "Model", "Text", "", "Global Equity Model - Moderate", "Internal", "", ""),
       ("Implemented Strategy", "Strategy the model portfolio represents.", "Model", "Reference (Strategy)", "", "STR-00123", "Internal", "", "Y"),
       ("Model Sponsor / Platform", "Party reference of the platform or sponsor receiving the model.", "Model", "Reference (Party)", "", "PTY-3301", "Internal", "", ""),
       ("Rebalance Frequency", "Frequency at which model changes are delivered.", "Model", "Code", "Frequency", "Quarterly", "Internal", "", ""),
       ("Model Delivery Method", "How the model is delivered (file, API, platform upload).", "Model", "Text", "", "Platform upload", "Internal", "", ""),
     ]),
   ]),
   ("Product Relationships", "Structural relationships between products (umbrella, master-feeder, clones, mergers).", [
     ("Product Relationship", [
       ("Source Product", "Product at the 'from' end of the relationship.", "Product", "Reference (Product)", "", "PRD-00981", "FIBO CIV", "", "Y"),
       ("Target Product", "Product at the 'to' end of the relationship.", "Product", "Reference (Product)", "", "PRD-00900", "FIBO CIV", "", "Y"),
       ("Relationship Type", "Nature of the relationship between the two products.", "Product", "Code", "Product Relationship Type", "Umbrella - Sub-fund", "FIBO CIV", "", "Y"),
       ("Relationship Effective From", "Date the relationship became effective.", "Product", "Date", "ISO 8601", "2015-06-01", "Internal", "", ""),
       ("Relationship Effective To", "Date the relationship ended, if applicable.", "Product", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

D("Share Class", "SHC",
  "The unit of investor ownership in a pooled product, differentiated by currency, fees, distribution policy, hedging and investor eligibility.",
  [
   ("Share Class Definition", "Core identity of a share or unit class.", [
     ("Share Class", [
       ("Share Class ID", "Unique internal identifier for the share class.", "Share Class", "Identifier", "", "SHC-004512", "Internal", "FIBO CIV", "Y"),
       ("Parent Product", "Product to which the share class belongs.", "Share Class", "Reference (Product)", "", "PRD-00981", "FIBO CIV", "openfunds", "Y"),
       ("Share Class Legal Name", "Full legal name of the share class.", "Share Class", "Text", "", "Global Sustainable Equity Fund A Acc USD", "openfunds", "FinDatEx EMT", "Y"),
       ("Share Class Designation", "Short class code or letter used in the prospectus.", "Share Class", "Text", "", "A Acc USD", "openfunds", "", ""),
       ("Share Class Type", "Commercial type of the share class.", "Share Class", "Code", "Share Class Type", "Retail", "Internal", "openfunds", "Y"),
       ("Share Class Currency", "Currency in which the share class is denominated and priced.", "Share Class", "Code", "ISO 4217", "USD", "openfunds", "FinDatEx EMT", "Y"),
       ("Share Class Launch Date", "Date the share class was first priced.", "Share Class", "Date", "ISO 8601", "2015-06-01", "openfunds", "", "Y"),
       ("Share Class Status", "Current lifecycle status of the share class.", "Share Class", "Code", "Lifecycle Status", "Active", "Internal", "openfunds", "Y"),
       ("Initial Offer Price", "Price per share at launch.", "Share Class", "Decimal", "", "100.00", "openfunds", "", ""),
       ("Initial Offer Period End Date", "Last day of the initial offer period.", "Share Class", "Date", "ISO 8601", "2015-05-29", "openfunds", "", ""),
     ]),
   ]),
   ("Share Class Features", "Features that differentiate share classes of the same product.", [
     ("Currency Hedging", [
       ("Currency Hedged Indicator", "Whether the share class applies currency hedging.", "Share Class", "Boolean", "", "Y", "openfunds", "FinDatEx EMT", "Y"),
       ("Hedging Type", "Method of hedging applied to the share class.", "Share Class", "Code", "Hedging Type", "NAV Hedged", "openfunds", "ESMA", ""),
       ("Hedge Target Ratio", "Target percentage of currency exposure hedged.", "Share Class", "Percentage", "", "100%", "Internal", "", ""),
     ]),
     ("Income Distribution", [
       ("Distribution Policy", "Whether income is accumulated or distributed.", "Share Class", "Code", "Distribution Policy", "Accumulating", "openfunds", "FinDatEx EMT", "Y"),
       ("Distribution Frequency", "Frequency of income distributions.", "Share Class", "Code", "Frequency", "Quarterly", "openfunds", "", ""),
       ("Distribution Payment Method", "Default treatment of distributions for investors.", "Share Class", "Code", "Distribution Payment Method", "Cash", "openfunds", "", ""),
       ("Fees Charged to Capital Indicator", "Whether fees are charged to capital to enhance distributable income.", "Share Class", "Boolean", "", "N", "openfunds", "", ""),
     ]),
     ("Investor Eligibility", [
       ("Eligible Investor Type", "Type(s) of investor eligible to invest in the share class.", "Share Class", "Code (multi)", "Investor Type", "Retail; Professional", "openfunds", "FinDatEx EMT", "Y"),
       ("Minimum Initial Investment", "Minimum amount for a first subscription.", "Share Class", "Amount", "", "USD 1,000", "openfunds", "", ""),
       ("Minimum Subsequent Investment", "Minimum amount for additional subscriptions.", "Share Class", "Amount", "", "USD 100", "openfunds", "", ""),
       ("Minimum Holding", "Minimum holding an investor must maintain.", "Share Class", "Amount", "", "USD 1,000", "openfunds", "", ""),
       ("Eligibility Restriction", "Narrative restriction on who may invest.", "Share Class", "Text", "", "Available only to discretionary managers with a separate fee arrangement", "Internal", "", ""),
     ]),
   ]),
  ])

D("Identifiers & Cross-References", "IDN",
  "Industry, vendor and internal identifiers used to recognise products and share classes across systems and counterparties.",
  [
   ("Global Identifiers", "Standard identifiers issued by recognised numbering agencies or standards bodies.", [
     ("Security Identifier", [
       ("ISIN", "International Securities Identification Number of the share class.", "Share Class", "Identifier", "ISO 6166", "LU1234567890", "ISO 6166 (ANNA)", "openfunds", "Y"),
       ("CUSIP", "CUSIP identifier (US/Canada share classes).", "Share Class", "Identifier", "", "123456789", "CUSIP Global Services", "", ""),
       ("SEDOL", "Stock Exchange Daily Official List identifier.", "Share Class", "Identifier", "", "B1YW440", "LSEG", "", ""),
       ("FIGI", "Financial Instrument Global Identifier.", "Share Class", "Identifier", "", "BBG000BLNNH6", "OMG FIGI / OpenFIGI", "", ""),
       ("Valoren", "Swiss security number.", "Share Class", "Identifier", "", "12345678", "SIX", "openfunds", ""),
       ("WKN", "German securities identification number.", "Share Class", "Identifier", "", "A1JX52", "WM Datenservice", "openfunds", ""),
       ("FISN", "Financial Instrument Short Name.", "Share Class", "Text", "ISO 18774", "EXAMPLE FDS/GLB SUS EQ A ACC USD", "ISO 18774", "", ""),
     ]),
     ("Regulatory Filing Identifier", [
       ("SEC Investment Company File Number", "SEC file number of the registered investment company (US).", "Product", "Identifier", "", "811-01234", "SEC EDGAR", "", ""),
       ("SEC Series ID", "SEC EDGAR series identifier of the fund (US).", "Product", "Identifier", "", "S000012345", "SEC EDGAR", "", ""),
       ("SEC Class / Contract ID", "SEC EDGAR class identifier of the share class (US).", "Share Class", "Identifier", "", "C000034567", "SEC EDGAR", "", ""),
     ]),
   ]),
   ("Vendor & Industry Cross-References", "Identifiers assigned by data vendors, ratings agencies and market infrastructure.", [
     ("External Cross-Reference", [
       ("Morningstar SecId", "Morningstar security identifier of the share class.", "Share Class", "Identifier", "", "F00000XXXX", "Morningstar", "", ""),
       ("Morningstar FundId", "Morningstar identifier of the fund.", "Product", "Identifier", "", "FS0000XXXX", "Morningstar", "", ""),
       ("Lipper ID", "LSEG Lipper identifier of the share class.", "Share Class", "Identifier", "", "68123456", "LSEG Lipper", "", ""),
       ("Bloomberg Ticker", "Bloomberg ticker of the share class.", "Share Class", "Text", "", "EXGSEAU LX Equity", "Bloomberg", "", ""),
       ("DTCC Fund/SERV Code", "NSCC Fund/SERV fund code (US mutual funds).", "Share Class", "Identifier", "", "12345", "DTCC / NSCC", "", ""),
     ]),
   ]),
   ("Internal Cross-References", "Identifiers used by internal systems and outsourced service providers.", [
     ("System Cross-Reference", [
       ("Source System", "System assigning the identifier.", "Product, Share Class", "Code", "Firm-defined", "Fund Administrator", "Internal", "", "Y"),
       ("Source System Code", "Identifier of the product/share class in the source system.", "Product, Share Class", "Identifier", "", "FA-10045", "Internal", "", "Y"),
       ("Cross-Reference Effective From", "Date the cross-reference became valid.", "Product, Share Class", "Date", "ISO 8601", "2015-06-01", "Internal", "", ""),
       ("Cross-Reference Effective To", "Date the cross-reference ceased to be valid.", "Product, Share Class", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

D("Product Classification", "CLS",
  "Internal, industry, regulatory and sustainability classifications assigned to products and share classes.",
  [
   ("Internal Product Classification", "Firm-standard classifications used for management reporting, AUM and catalogues.", [
     ("Firm Product Classification", [
       ("Business Line", "Business line that owns the product commercially.", "Product", "Code", "Business Line", "Retail", "Internal", "", "Y"),
       ("Product Asset Class", "Asset class of the product; defaults from the strategy but can be overridden.", "Product", "Code", "Asset Class", "Equity", "Internal", "EFAMA EFC", "Y", "Inherit from Strategy unless overridden."),
       ("Product Investment Approach", "Investment approach of the product; defaults from the strategy.", "Product", "Code", "Investment Approach", "Active Fundamental", "Internal", "", "", "Inherit from Strategy unless overridden."),
       ("AUM Reporting Category", "Category used to aggregate AUM in management and public reporting.", "Product", "Code", "Firm-defined", "Equity - Global", "Internal", "", ""),
     ]),
   ]),
   ("Industry & Peer Group Classification", "Third-party category schemes used for peer comparison and distribution.", [
     ("External Classification", [
       ("EFAMA European Fund Category", "Category under the EFAMA European Fund Classification.", "Product", "Code", "External (EFAMA EFC)", "Equity Global", "EFAMA EFC", "", ""),
       ("Morningstar Category", "Morningstar peer category.", "Share Class", "Code", "External (Morningstar)", "Global Large-Cap Growth Equity", "Morningstar", "", ""),
       ("Morningstar Global Category", "Morningstar global broad category.", "Share Class", "Code", "External (Morningstar)", "Global Equity Large Cap", "Morningstar", "", ""),
       ("Lipper Global Classification", "LSEG Lipper Global Classification.", "Share Class", "Code", "External (LSEG Lipper)", "Equity Global", "LSEG Lipper", "", ""),
       ("IA Sector", "UK Investment Association sector.", "Product", "Code", "External (IA)", "Global", "Investment Association", "", ""),
       ("ICI Investment Category", "ICI investment classification (US).", "Product", "Code", "External (ICI)", "World Equity", "ICI", "", ""),
       ("Classification Effective Date", "Date the external classification was assigned.", "Product, Share Class", "Date", "ISO 8601", "2026-01-31", "Internal", "", ""),
     ]),
   ]),
   ("Regulatory Product Classification", "Classifications required by regulation or used in regulatory reporting.", [
     ("Regulatory Classification", [
       ("CFI Code", "Classification of Financial Instruments code of the share class.", "Share Class", "Code", "ISO 10962", "CIOGEU", "ISO 10962", "openfunds", "Y"),
       ("MiFID Complexity", "Whether the product is complex or non-complex under MiFID II.", "Share Class", "Code", "MiFID Complexity", "Non-Complex", "FinDatEx EMT", "MiFID II", "Y"),
       ("Money Market Fund Type", "Money market fund type under EU MMFR or US Rule 2a-7.", "Product", "Code", "MMF Type", "LVNAV", "EU MMFR", "SEC Rule 2a-7", ""),
       ("US Fund Type", "SEC classification of the registered investment company.", "Product", "Code", "US Fund Type", "Open-End Management Company", "SEC Form N-1A", "", ""),
     ]),
   ]),
   ("Sustainability Classification", "ESG and sustainability classifications, labels and commitments.", [
     ("ESG Classification", [
       ("SFDR Classification", "Classification under the EU Sustainable Finance Disclosure Regulation.", "Product", "Code", "SFDR Classification", "Article 8", "SFDR", "FinDatEx EET", "Y"),
       ("Sustainability Label", "Sustainability label(s) held by the product.", "Product", "Code (multi)", "Sustainability Label", "Sustainability Focus", "UK FCA SDR", "FinDatEx EET", ""),
       ("ESG Investment Approach", "ESG approach(es) applied in the investment process.", "Product", "Code (multi)", "ESG Investment Approach", "ESG Integration; Exclusion", "FinDatEx EET", "", ""),
       ("Minimum Sustainable Investment %", "Minimum proportion of sustainable investments committed in pre-contractual disclosures.", "Product", "Percentage", "", "20%", "FinDatEx EET", "SFDR RTS", ""),
       ("Minimum Taxonomy-Aligned Investment %", "Minimum proportion of EU Taxonomy-aligned investments committed.", "Product", "Percentage", "", "0%", "FinDatEx EET", "SFDR RTS", ""),
       ("Principal Adverse Impacts Considered", "Whether the product considers principal adverse impacts on sustainability factors.", "Product", "Boolean", "", "Y", "FinDatEx EET", "SFDR", ""),
       ("ESG Term in Name Indicator", "Whether the product name uses ESG- or sustainability-related terms (triggers naming rules).", "Product", "Boolean", "", "Y", "ESMA Fund Names Guidelines", "", ""),
     ]),
   ]),
  ])

D("Investment Policy & Risk", "POL",
  "The documented investment objective, policy, restrictions and risk profile of a product.",
  [
   ("Objective & Policy", "Prospectus-level objective and policy, including use of benchmarks, derivatives and leverage.", [
     ("Investment Objective & Policy", [
       ("Investment Objective", "Investment objective as stated in the offering document.", "Product", "Text", "", "To achieve long-term capital growth...", "openfunds", "Prospectus", "Y"),
       ("Investment Policy", "Investment policy as stated in the offering document.", "Product", "Text", "", "The Fund invests at least 80% in equities of companies worldwide...", "Prospectus", "", ""),
       ("Benchmark Usage Type", "How a benchmark is used in managing the product (target, constraint, comparator).", "Product", "Code", "Benchmark Usage Type", "Comparator", "ESMA UCITS Q&A", "UK FCA COLL", "Y"),
       ("Recommended Holding Period", "Recommended minimum holding period in years.", "Share Class", "Integer", "Years", "5", "PRIIPs RTS", "FinDatEx EMT", ""),
       ("Derivatives Usage", "Purpose(s) for which derivatives may be used.", "Product", "Code", "Derivatives Usage", "Hedging and EPM", "Prospectus", "", ""),
       ("Leverage Calculation Method", "Method used to calculate leverage (AIFs).", "Product", "Code", "Leverage Method", "Commitment Method", "AIFMD", "", ""),
       ("Maximum Leverage", "Maximum permitted leverage as a percentage of NAV.", "Product", "Percentage", "", "200%", "AIFMD", "Prospectus", ""),
       ("Maximum Borrowing", "Maximum permitted borrowing as a percentage of NAV.", "Product", "Percentage", "", "10%", "UCITS Directive", "Prospectus", ""),
       ("Securities Lending Permitted Indicator", "Whether the product may engage in securities lending.", "Product", "Boolean", "", "Y", "Prospectus", "", ""),
     ]),
   ]),
   ("Investment Restrictions", "Machine-readable investment restrictions and guidelines applied to products and mandates.", [
     ("Investment Restriction", [
       ("Restriction ID", "Unique identifier of the restriction.", "Product, Mandate", "Identifier", "", "RST-55012", "Internal", "", "Y"),
       ("Restriction Source", "Origin of the restriction.", "Product, Mandate", "Code", "Restriction Source", "Prospectus", "Internal", "", "Y"),
       ("Restriction Category", "Category of the restriction.", "Product, Mandate", "Code", "Restriction Category", "Concentration", "Internal", "", ""),
       ("Restriction Description", "Narrative description of the restriction.", "Product, Mandate", "Text", "", "Max 10% NAV in any single issuer", "Internal", "", ""),
       ("Limit Type", "Whether the limit is a minimum, maximum, range or prohibition.", "Product, Mandate", "Code", "Limit Type", "Maximum", "Internal", "", ""),
       ("Limit Value", "Numeric limit value.", "Product, Mandate", "Decimal", "", "10", "Internal", "", ""),
       ("Measurement Basis", "Basis on which the limit is measured.", "Product, Mandate", "Code", "Measurement Basis", "% of NAV", "Internal", "", ""),
       ("Restriction Effective From", "Date the restriction became effective.", "Product, Mandate", "Date", "ISO 8601", "2015-06-01", "Internal", "", ""),
     ]),
   ]),
   ("Risk Profile", "Regulatory and internal risk indicators for the product.", [
     ("Product Risk Indicator", [
       ("Summary Risk Indicator (SRI)", "PRIIPs summary risk indicator on a scale of 1 to 7.", "Share Class", "Integer", "1-7", "4", "PRIIPs RTS", "FinDatEx EMT", "Y"),
       ("SRRI", "UCITS KIID synthetic risk and reward indicator (1-7); retained where KIIDs are still used, e.g. UK.", "Share Class", "Integer", "1-7", "6", "UCITS KIID Regulation", "", ""),
       ("Global Exposure Method", "Method used to measure global exposure (UCITS).", "Product", "Code", "Risk Measurement Method", "Commitment", "UCITS Directive", "ESMA", ""),
       ("Local Regulatory Risk Rating", "Risk rating required by a local regulator or distributor.", "Share Class", "Code", "Firm-defined", "Medium", "Internal", "", ""),
     ]),
   ]),
  ])

D("Benchmark & Performance Reference", "BMK",
  "Benchmarks and indices assigned to products and the reference data that governs how performance is presented.",
  [
   ("Benchmark Definition", "Master data describing benchmarks and blended benchmarks.", [
     ("Benchmark", [
       ("Benchmark ID", "Unique internal identifier for the benchmark.", "Benchmark", "Identifier", "", "BMK-0001", "Internal", "", "Y"),
       ("Benchmark Name", "Official name of the benchmark or index.", "Benchmark", "Text", "", "MSCI ACWI Net Total Return USD", "openfunds", "", "Y"),
       ("Benchmark Administrator", "Party that administers the benchmark.", "Benchmark", "Reference (Party)", "", "MSCI", "EU BMR", "", ""),
       ("Benchmark Currency", "Currency of the benchmark.", "Benchmark", "Code", "ISO 4217", "USD", "Internal", "", ""),
       ("Return Type", "Treatment of income in the benchmark return.", "Benchmark", "Code", "Return Type", "Net Total Return", "Internal", "", ""),
       ("Benchmark Hedged Indicator", "Whether the benchmark is currency hedged.", "Benchmark", "Boolean", "", "N", "Internal", "", ""),
       ("Blended Benchmark Indicator", "Whether the benchmark is a blend of components.", "Benchmark", "Boolean", "", "N", "Internal", "", ""),
       ("Blend Components", "Component benchmarks and weights for a blended benchmark.", "Benchmark", "Reference (Benchmark) + Percentage", "", "60% BMK-0001; 40% BMK-0007", "Internal", "", ""),
       ("BMR Register Status", "Whether the administrator or benchmark is on the ESMA/FCA benchmarks register.", "Benchmark", "Boolean", "", "Y", "EU BMR", "", ""),
       ("Benchmark Vendor Code", "Vendor ticker or code for the benchmark.", "Benchmark", "Text", "", "NDUEACWF Index", "Bloomberg", "", ""),
     ]),
   ]),
   ("Benchmark Assignment", "Effective-dated assignment of benchmarks to products and share classes by role.", [
     ("Product Benchmark Assignment", [
       ("Assigned Product / Share Class", "Product or share class receiving the benchmark.", "Product, Share Class", "Reference (Product / Share Class)", "", "SHC-004512", "Internal", "", "Y"),
       ("Assigned Benchmark", "Benchmark being assigned.", "Product, Share Class", "Reference (Benchmark)", "", "BMK-0001", "Internal", "", "Y"),
       ("Benchmark Role", "Role the benchmark plays for the product.", "Product, Share Class", "Code", "Benchmark Role", "Primary", "Internal", "openfunds", "Y"),
       ("Assignment Effective From", "Date the assignment became effective.", "Product, Share Class", "Date", "ISO 8601", "2015-06-01", "Internal", "", "Y"),
       ("Assignment Effective To", "Date the assignment ended.", "Product, Share Class", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Prospectus Disclosed Indicator", "Whether the benchmark is disclosed in the offering document.", "Product, Share Class", "Boolean", "", "Y", "ESMA UCITS Q&A", "", ""),
     ]),
   ]),
   ("Performance Reference", "Reference data that governs performance track records and presentation.", [
     ("Performance Track Record", [
       ("Performance Inception Date", "Date from which performance is calculated and shown.", "Share Class", "Date", "ISO 8601", "2015-06-01", "openfunds", "", "Y"),
       ("Track Record Source", "Predecessor product or share class whose track record is used, if any.", "Share Class", "Reference (Product / Share Class)", "", "", "Internal", "GIPS", ""),
       ("Performance Calculation Basis", "Basis on which performance is calculated.", "Share Class", "Code", "Performance Calculation Basis", "NAV-to-NAV Net of Fees", "Internal", "GIPS", ""),
     ]),
   ]),
  ])

D("Fees, Charges & Costs", "FEE",
  "Fee terms set by the product and the cost figures disclosed to investors.",
  [
   ("Management & Ongoing Fees", "Recurring fees charged to the product or share class.", [
     ("Management Fee", [
       ("Management Fee Rate", "Annual management fee as a percentage.", "Share Class", "Percentage", "", "0.75%", "openfunds", "FinDatEx EMT", "Y"),
       ("Maximum Management Fee Rate", "Maximum management fee permitted by the offering document.", "Share Class", "Percentage", "", "1.50%", "openfunds", "", ""),
       ("Fee Accrual Basis", "Basis on which the fee is calculated.", "Share Class, Mandate", "Code", "Fee Accrual Basis", "Average Net Assets", "Internal", "", ""),
       ("Fee Breakpoint Schedule", "Tiered fee rates by asset level (mainly mandates and US funds).", "Share Class, Mandate", "Reference (Fee Tier)", "", "0.75% first USD 100m; 0.60% thereafter", "Internal", "", ""),
     ]),
     ("Other Ongoing Fees", [
       ("Administration / Operating Fee Rate", "Fixed or variable operating / administration fee.", "Share Class", "Percentage", "", "0.15%", "openfunds", "", ""),
       ("Distribution (12b-1) Fee Rate", "Annual distribution and/or service fee (US).", "Share Class", "Percentage", "", "0.25%", "SEC Form N-1A", "", ""),
       ("Shareholder Servicing Fee Rate", "Annual shareholder servicing fee.", "Share Class", "Percentage", "", "0.10%", "SEC Form N-1A", "", ""),
       ("Trail Commission Indicator", "Whether the share class pays trail commission / retrocessions.", "Share Class", "Boolean", "", "N", "openfunds", "FinDatEx EMT", ""),
     ]),
   ]),
   ("Performance Fee", "Terms of performance-related fees.", [
     ("Performance Fee", [
       ("Performance Fee Indicator", "Whether a performance fee applies.", "Share Class", "Boolean", "", "N", "openfunds", "FinDatEx EMT", "Y"),
       ("Performance Fee Rate", "Performance fee participation rate.", "Share Class", "Percentage", "", "20%", "openfunds", "", ""),
       ("Hurdle Type", "Type of hurdle above which the fee is earned.", "Share Class", "Code", "Hurdle Type", "Benchmark", "ESMA Performance Fee Guidelines", "", ""),
       ("Hurdle Benchmark", "Benchmark used as the hurdle.", "Share Class", "Reference (Benchmark)", "", "BMK-0001", "ESMA Performance Fee Guidelines", "", ""),
       ("High-Water Mark Indicator", "Whether a high-water mark applies.", "Share Class", "Boolean", "", "Y", "ESMA Performance Fee Guidelines", "openfunds", ""),
       ("Crystallisation Frequency", "Frequency at which the performance fee crystallises.", "Share Class", "Code", "Frequency", "Annual", "ESMA Performance Fee Guidelines", "", ""),
       ("Performance Reference Period", "Period over which performance is measured for the fee (e.g., rolling 5 years).", "Share Class", "Text", "", "Whole life / minimum 5 years", "ESMA Performance Fee Guidelines", "", ""),
     ]),
   ]),
   ("Transaction Charges", "Charges and mechanisms applied when investors deal.", [
     ("Investor Transaction Charge", [
       ("Maximum Entry Charge", "Maximum subscription / sales charge.", "Share Class", "Percentage", "", "5.00%", "openfunds", "FinDatEx EMT", "Y"),
       ("Maximum Exit Charge", "Maximum redemption charge.", "Share Class", "Percentage", "", "0.00%", "openfunds", "FinDatEx EMT", "Y"),
       ("CDSC Schedule", "Contingent deferred sales charge schedule by holding period (US).", "Share Class", "Text", "", "1% if redeemed within 12 months", "SEC Form N-1A", "", ""),
       ("Switching Charge", "Charge for switching between share classes or funds.", "Share Class", "Percentage", "", "1.00%", "openfunds", "", ""),
       ("Anti-Dilution Mechanism", "Mechanism used to protect investors from dilution.", "Product", "Code", "Anti-Dilution Mechanism", "Partial Swing Pricing", "openfunds", "", ""),
       ("Maximum Swing Factor", "Maximum swing factor permitted.", "Product", "Percentage", "", "2.00%", "Prospectus", "", ""),
     ]),
   ]),
   ("Reported Costs & Expense Ratios", "Calculated cost figures disclosed in KIDs, prospectuses and MiFID cost reports.", [
     ("Cost Disclosure", [
       ("Ongoing Charges Figure (OCF)", "Ongoing charges as a percentage of average NAV.", "Share Class", "Percentage", "", "0.92%", "openfunds", "FinDatEx EMT", "Y"),
       ("Gross Expense Ratio", "Total annual fund operating expenses before waivers (US).", "Share Class", "Percentage", "", "1.10%", "SEC Form N-1A", "", ""),
       ("Net Expense Ratio", "Total annual fund operating expenses after waivers (US).", "Share Class", "Percentage", "", "0.95%", "SEC Form N-1A", "", ""),
       ("Expense Cap Rate", "Contractual cap on expenses through waiver or reimbursement.", "Share Class", "Percentage", "", "0.95%", "SEC Form N-1A", "", ""),
       ("Waiver Expiry Date", "Date the contractual fee waiver or expense cap expires.", "Share Class", "Date", "ISO 8601", "2027-04-30", "SEC Form N-1A", "", ""),
       ("Transaction Costs", "Portfolio transaction costs as a percentage, PRIIPs methodology.", "Share Class", "Percentage", "", "0.12%", "PRIIPs RTS", "FinDatEx EMT", ""),
       ("Ex-Ante Ongoing Costs", "Ex-ante ongoing costs for MiFID II cost disclosure.", "Share Class", "Percentage", "", "0.92%", "FinDatEx EMT", "MiFID II", ""),
       ("Cost Reference Date", "Date as of which the cost figures are calculated.", "Share Class", "Date", "ISO 8601", "2025-12-31", "FinDatEx EMT", "", ""),
     ]),
   ]),
  ])

D("Dealing, Valuation & Listing", "OPS",
  "Operational terms governing how investors deal, how the product is valued and where it trades.",
  [
   ("Dealing Terms", "Terms on which investors subscribe and redeem.", [
     ("Dealing Terms", [
       ("Dealing Frequency", "Frequency of dealing days.", "Share Class", "Code", "Frequency", "Daily", "openfunds", "FinDatEx EMT", "Y"),
       ("Dealing Cut-off Time", "Latest time orders are accepted for a dealing day.", "Share Class", "Time", "HH:MM", "12:00", "openfunds", "", "Y"),
       ("Cut-off Time Zone", "Time zone of the dealing cut-off.", "Share Class", "Code", "IANA Time Zone", "Europe/Luxembourg", "openfunds", "", "Y"),
       ("Subscription Settlement Period", "Settlement lag for subscriptions in business days.", "Share Class", "Integer", "T+n", "2", "openfunds", "", ""),
       ("Redemption Settlement Period", "Settlement lag for redemptions in business days.", "Share Class", "Integer", "T+n", "3", "openfunds", "", ""),
       ("Redemption Notice Period", "Notice required before redemption, in days.", "Share Class", "Integer", "Days", "0", "openfunds", "", ""),
       ("Lock-up Period", "Initial period during which redemptions are not permitted, in months.", "Share Class", "Integer", "Months", "0", "Internal", "", ""),
       ("Redemption Gate", "Maximum percentage of NAV redeemable on a dealing day before gating.", "Product", "Percentage", "", "10%", "Prospectus", "", ""),
       ("Pricing Basis", "Whether dealing is at forward or historic prices.", "Share Class", "Code", "Pricing Basis", "Forward", "openfunds", "", ""),
       ("Dealing Calendar", "Calendar of dealing and non-dealing days.", "Product", "Reference (Calendar)", "", "CAL-LU-01", "Internal", "", ""),
     ]),
   ]),
   ("Valuation & Pricing", "Terms governing valuation and NAV publication.", [
     ("Valuation Terms", [
       ("Valuation Frequency", "Frequency of NAV calculation.", "Product", "Code", "Frequency", "Daily", "openfunds", "", "Y"),
       ("Valuation Point", "Time at which assets are valued.", "Product", "Time", "HH:MM + time zone", "16:00 America/New_York", "openfunds", "", ""),
       ("Pricing Model", "Single, swinging single or dual pricing.", "Product", "Code", "Pricing Model", "Single Swinging Price", "openfunds", "", ""),
       ("NAV Decimal Precision", "Number of decimal places in the published NAV.", "Share Class", "Integer", "", "2", "Internal", "", ""),
       ("NAV Publication Channel", "Where the NAV is published.", "Share Class", "Text", "", "Firm website; Bloomberg; Morningstar", "Internal", "", ""),
     ]),
   ]),
   ("Exchange Listing", "Exchange listings for ETFs and listed closed-ended vehicles.", [
     ("Listing", [
       ("Listing Exchange", "Exchange on which the share class is listed.", "Share Class", "Code", "ISO 10383 (MIC)", "XLON", "ISO 10383", "", "Y"),
       ("Exchange Ticker", "Local exchange ticker.", "Share Class", "Text", "", "GSEQ", "Exchange", "", "Y"),
       ("Trading Currency", "Currency in which the listing trades.", "Share Class", "Code", "ISO 4217", "GBP", "Exchange", "", "Y"),
       ("Primary Listing Indicator", "Whether this is the primary listing.", "Share Class", "Boolean", "", "Y", "Internal", "", ""),
       ("Listing Date", "Date the listing commenced.", "Share Class", "Date", "ISO 8601", "2020-02-10", "Exchange", "", ""),
       ("Delisting Date", "Date the listing ended.", "Share Class", "Date", "ISO 8601", "", "Exchange", "", ""),
       ("iNAV Ticker", "Ticker of the indicative NAV.", "Share Class", "Text", "", "IGSEQ", "Exchange", "", ""),
     ]),
     ("ETF Characteristics", [
       ("Replication Method", "How an index-tracking product replicates its index.", "Product", "Code", "Replication Method", "Physical - Full", "openfunds", "FinDatEx EMT", "Y"),
       ("Creation Unit Size", "Number of shares per creation / redemption unit.", "Share Class", "Integer", "", "50000", "Internal", "", ""),
       ("Index Tracked", "Index the ETF or index fund tracks.", "Product", "Reference (Benchmark)", "", "BMK-0001", "openfunds", "", ""),
     ]),
   ]),
  ])

D("Product Parties & Roles", "PTY",
  "Legal entities and individuals that play a defined role for a product (service providers, delegates, portfolio managers).",
  [
   ("Service Providers", "Effective-dated assignment of service providers and delegates to products.", [
     ("Product Party Role", [
       ("Party", "Reference to the party in the party / legal entity master.", "Product", "Reference (Party)", "", "PTY-0101", "FIBO CIV", "", "Y"),
       ("Party Legal Name", "Legal name of the party (from party master).", "Product", "Text", "", "Example Depositary Bank S.A.", "openfunds", "", ""),
       ("Party LEI", "LEI of the party (from party master).", "Product", "Identifier", "ISO 17442", "549300XXXXXXXXXXXX12", "ISO 17442 (GLEIF)", "openfunds", "Y"),
       ("Party Role Type", "Role the party plays for the product.", "Product", "Code", "Party Role Type", "Depositary", "FIBO CIV", "openfunds", "Y"),
       ("Delegated Function Indicator", "Whether the role is performed under delegation from the ManCo/AIFM.", "Product", "Boolean", "", "Y", "AIFMD", "UCITS Directive", ""),
       ("Role Effective From", "Date the party assumed the role.", "Product", "Date", "ISO 8601", "2015-06-01", "Internal", "", "Y"),
       ("Role Effective To", "Date the party ceased the role.", "Product", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Key Persons", "Portfolio managers and other key persons named for a product.", [
     ("Portfolio Manager Assignment", [
       ("Portfolio Manager", "Reference to the individual portfolio manager.", "Product, Mandate", "Reference (Party)", "", "PTY-0457", "openfunds", "", "Y"),
       ("Portfolio Manager Role", "Role of the individual on the product.", "Product, Mandate", "Code", "PM Role", "Lead", "Internal", "", ""),
       ("PM Start Date", "Date the individual started managing the product.", "Product, Mandate", "Date", "ISO 8601", "2015-06-01", "openfunds", "SEC Form N-1A", ""),
       ("PM End Date", "Date the individual stopped managing the product.", "Product, Mandate", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

D("Distribution & Registration", "DST",
  "Where, to whom and through which channels a product may be marketed and sold.",
  [
   ("Registration for Sale", "Country-level registration / notification status of share classes.", [
     ("Country Registration", [
       ("Registration Country", "Country in which the share class is registered or notified for sale.", "Share Class", "Code", "ISO 3166-1 alpha-2", "DE", "openfunds", "", "Y"),
       ("Registration Status", "Status of the registration in that country.", "Share Class", "Code", "Registration Status", "Registered", "openfunds", "", "Y"),
       ("Registration Date", "Date the registration became effective.", "Share Class", "Date", "ISO 8601", "2016-02-01", "openfunds", "", ""),
       ("Permitted Investor Type", "Investor types the product may be marketed to in that country.", "Share Class", "Code (multi)", "Investor Type", "Retail; Professional", "openfunds", "", "Y"),
       ("Marketing Basis", "Legal basis on which the product is marketed in that country.", "Share Class", "Code", "Marketing Basis", "UCITS Passport", "UCITS Directive", "AIFMD", ""),
       ("Local Facilities / Paying Agent", "Local agent appointed in the country of registration.", "Share Class", "Reference (Party)", "", "PTY-0800", "openfunds", "", ""),
     ]),
   ]),
   ("Target Market (MiFID II)", "Manufacturer's target market per MiFID II product governance, as exchanged via the EMT.", [
     ("Target Market", [
       ("Target Investor Type", "Client category in the target market.", "Share Class", "Code (multi)", "Investor Type", "Retail; Professional", "FinDatEx EMT", "MiFID II", "Y"),
       ("Knowledge & Experience", "Minimum investor knowledge and experience.", "Share Class", "Code", "Knowledge & Experience", "Basic", "FinDatEx EMT", "MiFID II", ""),
       ("Ability to Bear Losses", "Investor's required ability to bear losses.", "Share Class", "Code", "Ability to Bear Losses", "No Capital Guarantee", "FinDatEx EMT", "MiFID II", ""),
       ("Risk Tolerance", "Required investor risk tolerance (typically expressed via SRI).", "Share Class", "Integer", "1-7", "4", "FinDatEx EMT", "MiFID II", ""),
       ("Client Objective", "Investment objective(s) the product is designed to meet.", "Share Class", "Code (multi)", "Client Objective", "Growth", "FinDatEx EMT", "MiFID II", ""),
       ("Minimum Investment Horizon", "Minimum recommended investment horizon.", "Share Class", "Integer", "Years", "5", "FinDatEx EMT", "PRIIPs RTS", ""),
       ("Sustainability Preferences Met", "Whether the product can meet client sustainability preferences.", "Share Class", "Boolean", "", "Y", "FinDatEx EMT", "FinDatEx EET", ""),
       ("Distribution Strategy", "Distribution services through which the product may be sold.", "Share Class", "Code (multi)", "Distribution Strategy", "Investment Advice; Portfolio Management", "FinDatEx EMT", "MiFID II", ""),
       ("Negative Target Market", "Investors for whom the product is not compatible.", "Share Class", "Text", "", "Investors seeking capital protection", "FinDatEx EMT", "MiFID II", ""),
     ]),
   ]),
   ("Channel & Availability", "Commercial availability by channel, platform and restriction.", [
     ("Distribution Availability", [
       ("Distribution Channel", "Channel(s) through which the share class is distributed.", "Share Class", "Code (multi)", "Distribution Channel", "Platform / Fund Supermarket", "Internal", "", ""),
       ("Platform Availability", "Third-party platforms on which the share class is available.", "Share Class", "Reference (Party) (multi)", "", "PTY-3301; PTY-3302", "Internal", "", ""),
       ("Sales Restriction", "Restrictions on selling the product (e.g., to US persons).", "Product, Share Class", "Text", "", "Not for sale to US Persons", "Prospectus", "", ""),
     ]),
   ]),
  ])

D("Regulatory, Tax & Disclosure", "REG",
  "Regulatory authorisation, required documents and tax status of products and share classes.",
  [
   ("Regulatory Authorisation", "Authorisation of the product by its competent authority.", [
     ("Regulatory Authorisation", [
       ("Competent Authority", "Regulator that authorised the product.", "Product", "Reference (Party)", "", "CSSF", "openfunds", "", "Y"),
       ("Authorisation Date", "Date the product was authorised.", "Product", "Date", "ISO 8601", "2015-05-15", "openfunds", "", ""),
       ("Authorisation Number", "Regulator-assigned authorisation or registration number.", "Product", "Identifier", "", "O00012345", "Internal", "", ""),
       ("Regulatory Reporting Obligations", "Regulatory reports the product is in scope for.", "Product", "Text (multi)", "", "AIFMD Annex IV; EMIR; Form N-PORT", "Internal", "", ""),
     ]),
   ]),
   ("Product Disclosures", "Regulatory and marketing documents published for products and share classes.", [
     ("Product Document", [
       ("Document Type", "Type of document.", "Product, Share Class", "Code", "Document Type", "KID (PRIIPs)", "openfunds", "", "Y"),
       ("Document Language", "Language of the document.", "Product, Share Class", "Code", "ISO 639-1", "de", "openfunds", "", "Y"),
       ("Document Jurisdiction", "Country for which the document is produced.", "Product, Share Class", "Code", "ISO 3166-1 alpha-2", "DE", "openfunds", "", ""),
       ("Document Version Date", "Date of the document version.", "Product, Share Class", "Date", "ISO 8601", "2026-02-14", "openfunds", "", "Y"),
       ("Document Location", "URL or repository reference for the document.", "Product, Share Class", "Text", "URI", "https://docs.example.com/kid/LU1234567890_de.pdf", "openfunds", "", ""),
     ]),
   ]),
   ("Tax Status", "Tax classification and tax reporting status at product and share-class level.", [
     ("Product Tax Status", [
       ("Tax Residence Country", "Country of tax residence of the vehicle.", "Product", "Code", "ISO 3166-1 alpha-2", "LU", "Internal", "", ""),
       ("US Tax Classification", "US federal tax classification of the vehicle.", "Product", "Code", "US Tax Classification", "RIC", "Internal", "", ""),
       ("FATCA GIIN", "Global Intermediary Identification Number.", "Product", "Identifier", "", "98Q96B.00000.LE.442", "IRS FATCA", "", ""),
       ("CRS Entity Classification", "Classification of the vehicle under the OECD Common Reporting Standard.", "Product", "Code", "CRS Classification", "Investment Entity", "OECD CRS", "", ""),
       ("Tax Transparency Indicator", "Whether the vehicle is tax transparent.", "Product", "Boolean", "", "N", "Internal", "", ""),
     ]),
     ("Share Class Tax Reporting", [
       ("UK Reporting Fund Status", "Whether the share class has HMRC Reporting Fund status.", "Share Class", "Boolean", "", "Y", "HMRC", "openfunds", ""),
       ("UK Reporting Fund Status Effective Date", "Date reporting fund status became effective.", "Share Class", "Date", "ISO 8601", "2016-01-01", "HMRC", "", ""),
       ("German Investment Tax Classification", "Fund type for German partial exemption (InvStG).", "Share Class", "Code", "German Investment Tax Classification", "Equity Fund", "German InvStG", "openfunds", ""),
       ("Austrian Tax Reporting Indicator", "Whether the share class is a reporting fund in Austria (OeKB).", "Share Class", "Boolean", "", "Y", "OeKB", "openfunds", ""),
     ]),
   ]),
  ])

D("Lifecycle & Governance", "LCG",
  "Lifecycle events, product governance and data management metadata for the product domain.",
  [
   ("Product Lifecycle", "Effective-dated events that change a product's or share class's status or structure.", [
     ("Lifecycle Event", [
       ("Lifecycle Status", "Current status of the product or share class.", "All", "Code", "Lifecycle Status", "Active", "Internal", "openfunds", "Y"),
       ("Status Effective Date", "Date the current status took effect.", "All", "Date", "ISO 8601", "2015-06-01", "Internal", "", "Y"),
       ("Lifecycle Event Type", "Type of lifecycle event.", "Product, Share Class", "Code", "Lifecycle Event Type", "Merger", "Internal", "", "Y"),
       ("Event Effective Date", "Date the event took effect.", "Product, Share Class", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
       ("Successor Product / Share Class", "Product or share class that receives investors after a merger or conversion.", "Product, Share Class", "Reference (Product / Share Class)", "", "SHC-004700", "Internal", "", ""),
       ("Event Reason", "Business rationale for the event.", "Product, Share Class", "Text", "", "Sub-scale; merged into larger fund with same strategy", "Internal", "", ""),
       ("Investor Notice Date", "Date investors were notified of the event.", "Product, Share Class", "Date", "ISO 8601", "2026-08-15", "Internal", "", ""),
     ]),
   ]),
   ("Product Governance", "Product approval, review and value-assessment reference data.", [
     ("Product Governance", [
       ("Product Owner", "Business owner accountable for the product.", "Product", "Reference (Party)", "", "PTY-0999", "Internal", "MiFID II", "Y"),
       ("Product Approval Date", "Date the product was approved by the product governance committee.", "Product", "Date", "ISO 8601", "2015-03-10", "MiFID II", "", ""),
       ("Last Product Review Date", "Date of the last periodic product review.", "Product", "Date", "ISO 8601", "2026-03-31", "MiFID II", "UK FCA Consumer Duty", ""),
       ("Next Product Review Date", "Scheduled date of the next product review.", "Product", "Date", "ISO 8601", "2027-03-31", "MiFID II", "", ""),
       ("Value Assessment Outcome", "Outcome of the latest assessment of value / fair value review.", "Product, Share Class", "Code", "Value Assessment Outcome", "Value Delivered", "UK FCA COLL", "UK FCA Consumer Duty", ""),
       ("Governing Body", "Board or governing body overseeing the product.", "Product", "Reference (Party)", "", "PTY-0050", "Internal", "", ""),
     ]),
   ]),
   ("Data Management Metadata", "Metadata applied to every record in the product domain.", [
     ("Record Metadata", [
       ("Data Owner", "Business role accountable for the data element.", "All", "Reference (Party)", "", "Head of Product", "DCAM (EDM Council)", "", ""),
       ("Data Steward", "Role responsible for day-to-day data quality.", "All", "Reference (Party)", "", "Product Data Steward", "DCAM (EDM Council)", "", ""),
       ("System of Record", "System holding the authoritative value.", "All", "Code", "Firm-defined", "Product Master", "Internal", "", ""),
       ("Record Effective From", "Business-effective start date of the record version.", "All", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Record Effective To", "Business-effective end date of the record version.", "All", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Last Updated Timestamp", "System timestamp of the last change.", "All", "Timestamp", "ISO 8601", "2026-09-30T17:45:00Z", "Internal", "", ""),
       ("Data Quality Status", "Validation status of the record.", "All", "Code", "Data Quality Status", "Validated", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Lifecycle Status": ("Internal (aligned to openfunds)", [("Proposed","Idea under evaluation"),("In Development","Approved for build, not yet launched"),("Active","Launched and open to investors"),("Soft Closed","Closed to new investors; existing investors may add"),("Hard Closed","Closed to all subscriptions"),("In Liquidation","Liquidation in progress"),("Merged","Merged into a successor"),("Liquidated","Fully liquidated"),("Inactive","Launched but unfunded / dormant")]),
 "Asset Class": ("Internal (aligned to EFAMA EFC)", [("Equity",""),("Fixed Income",""),("Multi-Asset",""),("Money Market",""),("Real Estate",""),("Private Equity",""),("Private Credit",""),("Infrastructure",""),("Hedge / Absolute Return",""),("Commodities",""),("Other","")]),
 "Investment Approach": ("Internal", [("Active Fundamental",""),("Active Quantitative",""),("Passive Index",""),("Smart Beta / Factor",""),("Enhanced Index","")]),
 "Investment Style": ("Internal (aligned to Morningstar Style Box)", [("Growth",""),("Value",""),("Core / Blend",""),("Income",""),("Quality",""),("Not Applicable","")]),
 "Market Cap Focus": ("Internal", [("Large Cap",""),("Mid Cap",""),("Small Cap",""),("Micro Cap",""),("All Cap",""),("Not Applicable","")]),
 "Geographic Focus": ("Internal", [("Global",""),("Global ex-US",""),("Developed Markets",""),("Emerging Markets",""),("Frontier Markets",""),("North America",""),("Europe",""),("Asia Pacific",""),("Single Country","Specify country in Sector / Thematic or separate attribute")]),
 "Market Type": ("Internal", [("Public",""),("Private",""),("Hybrid","")]),
 "Liquidity Profile": ("Internal", [("Daily",""),("Weekly / Monthly",""),("Semi-Liquid (Evergreen)","Periodic liquidity, typically quarterly with gates"),("Illiquid (Drawdown / Closed-Ended)","")]),
 "Vehicle Type": ("FIBO CIV / openfunds", [("Open-Ended Fund","Mutual fund / UCITS / OEIC"),("Exchange-Traded Fund",""),("Closed-End Fund",""),("Interval Fund","US periodic repurchase fund"),("Collective Investment Trust","US bank-maintained CIT"),("Unit Investment Trust",""),("Private Fund (Drawdown)","LP / closed-ended private markets fund"),("Evergreen Private Fund",""),("Pooled Pension / Unit-Linked Fund",""),("Separately Managed Account","SMA / wrap program account"),("Segregated Mandate","Institutional segregated account"),("Model Portfolio","")]),
 "Legal Form": ("FIBO CIV / openfunds", [("SICAV",""),("SICAF",""),("FCP","Fonds commun de placement"),("ICAV","Irish Collective Asset-management Vehicle"),("Investment Company (PLC)",""),("Unit Trust",""),("OEIC / ICVC",""),("Authorised Contractual Scheme",""),("US Open-End Investment Company","'40 Act registered"),("Delaware Statutory Trust",""),("Massachusetts Business Trust",""),("Limited Partnership",""),("SCSp","Luxembourg special limited partnership"),("Limited Liability Company",""),("Bank Collective Trust","")]),
 "Regulatory Regime": ("openfunds / Internal", [("UCITS","EU UCITS Directive"),("UK UCITS",""),("EU AIF","AIFMD"),("ELTIF",""),("EU MMF","Money Market Funds Regulation"),("UK NURS","Non-UCITS Retail Scheme"),("UK QIS","Qualified Investor Scheme"),("Lux SIF",""),("Lux RAIF",""),("Irish QIAIF",""),("US 1940 Act Registered",""),("US Private Fund 3(c)(1)",""),("US Private Fund 3(c)(7)",""),("US Bank CIT","OCC / state banking regulation"),("Cayman Regulated Mutual Fund","CIMA")]),
 "Fund Openness": ("FIBO CIV", [("Open-Ended",""),("Closed-Ended",""),("Semi-Open","Interval / tender-offer liquidity")]),
 "Master-Feeder Role": ("UCITS Directive", [("Master",""),("Feeder",""),("Standalone","")]),
 "Mandate Type": ("Internal", [("Segregated Account",""),("Sub-Advisory",""),("SMA / Wrap Program",""),("UMA Sleeve",""),("Fund of One","")]),
 "Frequency": ("Internal", [("Daily",""),("Weekly",""),("Fortnightly",""),("Monthly",""),("Quarterly",""),("Semi-Annual",""),("Annual",""),("Ad Hoc","")]),
 "Product Relationship Type": ("FIBO CIV / Internal", [("Umbrella - Sub-fund",""),("Master - Feeder",""),("Clone / Mirror","Same strategy, different domicile or vehicle"),("Parallel Vehicle",""),("Fund of Funds Holding",""),("Predecessor - Successor","Merger or conversion")]),
 "Share Class Type": ("Internal / openfunds", [("Retail",""),("Institutional",""),("Clean","No commission / rebate"),("Founder / Seed",""),("Platform / Super-Clean",""),("Employee",""),("ETF Share Class",""),("Internal","Reserved for in-house fund-of-funds / mandates")]),
 "Hedging Type": ("openfunds / ESMA", [("Unhedged",""),("NAV Hedged","Base currency hedged to class currency"),("Portfolio Hedged","Look-through hedge of underlying exposures"),("Duration Hedged","Permitted for some regimes only")]),
 "Distribution Policy": ("openfunds", [("Accumulating",""),("Distributing",""),("Distributing - Gross Income","Fees charged to capital")]),
 "Distribution Payment Method": ("openfunds", [("Cash",""),("Reinvestment",""),("Investor Election","")]),
 "Investor Type": ("MiFID II / openfunds / US", [("Retail",""),("Professional",""),("Eligible Counterparty",""),("Institutional",""),("Accredited Investor","US Reg D"),("Qualified Purchaser","US '40 Act s.2(a)(51)"),("Qualified Investor","CH CISA / EU well-informed")]),
 "Benchmark Usage Type": ("ESMA UCITS Q&A / UK FCA COLL", [("No Benchmark",""),("Comparator",""),("Constraint",""),("Target",""),("Index Tracking","")]),
 "Derivatives Usage": ("Prospectus", [("None",""),("Hedging Only",""),("Hedging and EPM","Efficient portfolio management"),("Investment Purposes","")]),
 "Leverage Method": ("AIFMD", [("Gross Method",""),("Commitment Method","")]),
 "Restriction Source": ("Internal", [("Regulatory",""),("Prospectus",""),("Client IMA",""),("Internal / House",""),("ESG Exclusion Policy","")]),
 "Restriction Category": ("Internal", [("Concentration",""),("Issuer",""),("Sector / Industry",""),("Country",""),("Credit Quality",""),("Liquidity",""),("Exclusion",""),("Instrument Type","")]),
 "Limit Type": ("Internal", [("Minimum",""),("Maximum",""),("Range",""),("Prohibition","")]),
 "Measurement Basis": ("Internal", [("% of NAV",""),("% of Market Value",""),("% of Issuer Capital",""),("Absolute Amount",""),("Count","")]),
 "Risk Measurement Method": ("UCITS Directive / ESMA", [("Commitment",""),("Relative VaR",""),("Absolute VaR","")]),
 "Return Type": ("Internal", [("Price Return",""),("Net Total Return",""),("Gross Total Return","")]),
 "Benchmark Role": ("Internal / openfunds", [("Primary",""),("Secondary",""),("Performance Fee Hurdle",""),("Risk / Tracking",""),("Peer Comparison",""),("Index Tracked","")]),
 "Performance Calculation Basis": ("GIPS / Internal", [("NAV-to-NAV Net of Fees",""),("Gross of Fees",""),("Time-Weighted",""),("Money-Weighted (IRR)","")]),
 "Fee Accrual Basis": ("Internal", [("Average Net Assets",""),("Committed Capital",""),("Invested Capital",""),("Fixed Fee","")]),
 "Hurdle Type": ("ESMA Performance Fee Guidelines", [("Benchmark",""),("Fixed Rate",""),("Cash Rate + Spread",""),("None","High-water mark only")]),
 "Anti-Dilution Mechanism": ("openfunds", [("Full Swing Pricing",""),("Partial Swing Pricing",""),("Dilution Levy",""),("Dual Pricing",""),("Liquidity Fee",""),("None","")]),
 "Pricing Basis": ("openfunds", [("Forward",""),("Historic","")]),
 "Pricing Model": ("openfunds", [("Single Price",""),("Single Swinging Price",""),("Dual Price (Bid / Offer)","")]),
 "Replication Method": ("openfunds / FinDatEx EMT", [("Physical - Full",""),("Physical - Optimised / Sampled",""),("Synthetic - Swap-Based",""),("Active (Non-Index)","")]),
 "Party Role Type": ("FIBO CIV / openfunds", [("Management Company",""),("AIFM",""),("Investment Manager",""),("Sub-Investment Manager",""),("Investment Adviser",""),("Depositary / Trustee",""),("Custodian",""),("Fund Administrator",""),("Transfer Agent / Registrar",""),("Auditor",""),("Legal Adviser",""),("Principal Distributor / Underwriter",""),("Paying / Facilities Agent",""),("Authorised Participant",""),("Market Maker",""),("Index Provider",""),("Board of Directors","")]),
 "PM Role": ("Internal", [("Lead",""),("Co-Manager",""),("Associate / Deputy","")]),
 "Registration Status": ("openfunds", [("Registered",""),("Pending",""),("Notified",""),("Private Placement Only",""),("Deregistered","")]),
 "Marketing Basis": ("UCITS Directive / AIFMD", [("UCITS Passport",""),("AIFMD Marketing Passport",""),("National Private Placement",""),("Domestic Authorisation",""),("Professional Investors Only (Exempt)","")]),
 "Knowledge & Experience": ("FinDatEx EMT", [("Basic",""),("Informed",""),("Advanced","")]),
 "Ability to Bear Losses": ("FinDatEx EMT", [("No Capital Loss",""),("Limited Capital Loss",""),("No Capital Guarantee",""),("Loss Beyond Capital","")]),
 "Client Objective": ("FinDatEx EMT", [("Preservation",""),("Growth",""),("Income",""),("Hedging",""),("Option or Leveraged",""),("Other","")]),
 "Distribution Strategy": ("FinDatEx EMT", [("Execution Only",""),("Execution with Appropriateness",""),("Non-Advised",""),("Investment Advice",""),("Portfolio Management","")]),
 "Distribution Channel": ("Internal", [("Retail Intermediary / Adviser",""),("Private Bank / Wealth",""),("Platform / Fund Supermarket",""),("Institutional Direct",""),("DC / Retirement",""),("Insurance / Unit-Linked",""),("Direct to Consumer","")]),
 "SFDR Classification": ("SFDR", [("Article 6",""),("Article 8",""),("Article 8 with Sustainable Investment","Market convention, not a legal category"),("Article 9",""),("Not in Scope","Non-EU products")]),
 "Sustainability Label": ("UK FCA SDR / national labels", [("Sustainability Focus","UK SDR"),("Sustainability Improvers","UK SDR"),("Sustainability Impact","UK SDR"),("Sustainability Mixed Goals","UK SDR"),("ISR Label","France"),("Towards Sustainability","Belgium"),("LuxFLAG ESG","Luxembourg"),("FNG-Siegel","Germany / Austria / Switzerland"),("None","")]),
 "ESG Investment Approach": ("FinDatEx EET / Internal", [("Exclusion / Negative Screening",""),("ESG Integration",""),("Best-in-Class",""),("Thematic",""),("Impact",""),("Engagement / Stewardship",""),("None","")]),
 "MiFID Complexity": ("MiFID II", [("Complex",""),("Non-Complex","")]),
 "MMF Type": ("EU MMFR / SEC Rule 2a-7", [("Public Debt CNAV","EU"),("LVNAV","EU"),("Short-Term VNAV","EU"),("Standard VNAV","EU"),("Government MMF","US"),("Prime MMF - Institutional","US"),("Prime MMF - Retail","US"),("Tax-Exempt MMF","US")]),
 "US Fund Type": ("SEC", [("Open-End Management Company",""),("Closed-End Management Company",""),("Unit Investment Trust",""),("ETF (Rule 6c-11)",""),("Interval Fund",""),("Business Development Company","")]),
 "Document Type": ("openfunds", [("Prospectus",""),("Prospectus Supplement",""),("KID (PRIIPs)",""),("KIID (UCITS)",""),("Summary Prospectus","US"),("Statement of Additional Information","US"),("Annual Report",""),("Semi-Annual Report",""),("Factsheet",""),("SFDR Pre-Contractual Annex",""),("SFDR Periodic Annex",""),("Consumer-Facing Disclosure","UK SDR"),("Assessment of Value Report","UK"),("Articles / Trust Deed",""),("Investment Management Agreement","")]),
 "US Tax Classification": ("IRS", [("RIC","Regulated investment company (Subchapter M)"),("Partnership",""),("Grantor Trust",""),("Corporation","")]),
 "CRS Classification": ("OECD CRS", [("Investment Entity",""),("Active NFE",""),("Passive NFE","")]),
 "German Investment Tax Classification": ("German InvStG", [("Equity Fund","Min. 50% equity"),("Mixed Fund","Min. 25% equity"),("Real Estate Fund",""),("Foreign Real Estate Fund",""),("Other Fund","")]),
 "Lifecycle Event Type": ("Internal", [("Launch",""),("Soft Close",""),("Hard Close",""),("Reopen",""),("Merger",""),("Liquidation",""),("Conversion",""),("Rename",""),("Change of Objective / Policy",""),("Change of Service Provider","")]),
 "Value Assessment Outcome": ("UK FCA COLL", [("Value Delivered",""),("Value Delivered - Action Required",""),("Value Not Delivered","")]),
 "Data Quality Status": ("Internal", [("Validated",""),("Pending Validation",""),("Exception",""),("Deprecated","")]),
 "Business Line": ("Internal", [("Retail",""),("Institutional",""),("Wealth",""),("Insurance",""),("Retirement","")]),
}

# ---------------------------------------------------------------------------
# Relationships, sources
# ---------------------------------------------------------------------------
REL = [
 ("Investment Strategy","is implemented by","Investment Product","1 : 0..n","A strategy may be offered through many vehicles (funds, ETFs, CITs)."),
 ("Investment Strategy","is implemented by","Investment Mandate","1 : 0..n",""),
 ("Investment Strategy","is implemented by","Model Portfolio","1 : 0..n",""),
 ("Investment Strategy","is represented by","GIPS Composite","1 : 0..n","Usually one primary composite per strategy."),
 ("GIPS Composite","contains","Investment Product / Investment Mandate","1 : 0..n","Effective-dated membership."),
 ("Investment Product (Umbrella)","contains","Investment Product (Sub-fund)","1 : 1..n","Via Product Relationship."),
 ("Investment Product (Feeder)","invests in","Investment Product (Master)","n : 1","Via Product Relationship."),
 ("Investment Product","issues","Share Class","1 : 1..n","Mandates and models have no share classes."),
 ("Share Class","is identified by","Security Identifier","1 : 0..n","ISIN, CUSIP, SEDOL, FIGI, etc."),
 ("Share Class","is listed as","Listing","1 : 0..n","ETFs / listed closed-ended funds."),
 ("Share Class","is registered as","Country Registration","1 : 0..n",""),
 ("Share Class","has","Target Market","1 : 0..1",""),
 ("Investment Product / Share Class","is assigned","Product Benchmark Assignment","1 : 0..n","Each assignment references one Benchmark and a role."),
 ("Product Benchmark Assignment","references","Benchmark","n : 1",""),
 ("Investment Product","is served by","Product Party Role","1 : 1..n","Each role references a Party (legal entity master)."),
 ("Investment Product / Mandate","is managed by","Portfolio Manager Assignment","1 : 1..n",""),
 ("Investment Product / Mandate","is constrained by","Investment Restriction","1 : 0..n",""),
 ("Share Class","is charged","Fee terms (Management, Performance, Transaction)","1 : 0..n","Fees typically vary by share class."),
 ("Investment Product / Share Class","is classified by","External Classification","1 : 0..n","Effective-dated."),
 ("Investment Product / Share Class","is described by","Product Document","1 : 0..n","By type, language and jurisdiction."),
 ("Investment Product / Share Class","undergoes","Lifecycle Event","1 : 0..n",""),
 ("Investment Product / Share Class","is cross-referenced by","System Cross-Reference","1 : 0..n",""),
]

SRC = [
 ("FIBO - Collective Investment Vehicles (CIV)","EDM Council","https://spec.edmcouncil.org/fibo/","Open (MIT licence)","Ontology of funds, umbrellas, share classes, legal forms and fund roles","Conceptual backbone: Product, Legal Structure, Share Class, Party Roles, Product Relationships"),
 ("openfunds","openfunds Association","https://www.openfunds.org","Free open standard","Governed dictionary of fund and share-class data fields (static, dealing, fees, registrations, documents)","Primary attribute dictionary for Product, Share Class, Fees, Dealing, Registration, Documents"),
 ("FinDatEx EMT (European MiFID Template)","FinDatEx","https://findatex.eu","Free template","MiFID II target market and costs & charges data exchanged with distributors","Target Market, Reported Costs, MiFID complexity"),
 ("FinDatEx EPT (European PRIIPs Template)","FinDatEx","https://findatex.eu","Free template","PRIIPs KID data: SRI, performance scenarios, costs","Risk Profile, Transaction Costs, Recommended Holding Period"),
 ("FinDatEx EET (European ESG Template)","FinDatEx","https://findatex.eu","Free template","SFDR, Taxonomy and sustainability preference data","Sustainability Classification"),
 ("ISO 6166 (ISIN) / ISO 10962 (CFI) / ISO 18774 (FISN)","ISO; ANNA","https://www.anna-web.org","Standard (ISO purchase); codes via NNAs","Instrument identification and classification","Global Identifiers, Regulatory Classification"),
 ("ISO 17442 (LEI)","ISO; GLEIF","https://www.gleif.org","Open data (GLEIF)","Legal entity identification","Fund LEI, Party LEI"),
 ("ISO 4217 / ISO 3166 / ISO 10383 / ISO 639 / ISO 8601","ISO","https://www.iso.org","Standard; code lists widely available","Currency, country, market (MIC), language and date/time codes","Reference code lists used throughout"),
 ("OpenFIGI","Object Management Group / Bloomberg","https://www.openfigi.com","Open","Financial Instrument Global Identifier","Global Identifiers"),
 ("GIPS Standards","CFA Institute","https://www.gipsstandards.org","Free","Composite definition and performance presentation","Strategy, GIPS Composite, Performance Reference"),
 ("EFAMA European Fund Classification (EFC)","EFAMA","https://www.efama.org","Free","Pan-European fund categorisation","Asset class alignment, External Classification"),
 ("Morningstar Category / Global Category","Morningstar","https://www.morningstar.com","Licensed","Peer-group categories","External Classification"),
 ("Lipper Global Classification","LSEG","https://www.lseg.com","Licensed","Peer-group categories","External Classification"),
 ("IA Sectors","The Investment Association (UK)","https://www.theia.org","Free","UK fund sectors","External Classification"),
 ("ICI Investment Classifications","Investment Company Institute (US)","https://www.ici.org","Free","US fund categories and industry definitions","External Classification, US vehicle definitions"),
 ("SFDR and SFDR RTS","European Union","https://eur-lex.europa.eu","Regulation","Sustainability disclosures and product categorisation","Sustainability Classification"),
 ("PRIIPs Regulation and RTS","European Union","https://eur-lex.europa.eu","Regulation","KID content: SRI, costs, holding period","Risk Profile, Reported Costs"),
 ("MiFID II product governance","European Union / ESMA","https://www.esma.europa.eu","Regulation and guidelines","Target market, product governance","Target Market, Product Governance"),
 ("UCITS Directive, AIFMD, EU MMFR, EU BMR","European Union","https://eur-lex.europa.eu","Regulation","Vehicle regimes, leverage, MMF types, benchmark use","Legal Structure, Objective & Policy, Benchmark"),
 ("ESMA guidelines and Q&A (performance fees, fund names, UCITS benchmarks)","ESMA","https://www.esma.europa.eu","Guidance","Fee, naming and benchmark disclosure rules","Performance Fee, ESG naming, Benchmark Usage"),
 ("UK FCA COLL, SDR and Consumer Duty","UK FCA","https://www.handbook.fca.org.uk","Regulation","UK fund rules, sustainability labels, value assessment","Sustainability Label, Value Assessment"),
 ("SEC Form N-1A and EDGAR series/class IDs","US SEC","https://www.sec.gov","Regulation","US fund registration, fee table, series/class identifiers","Fees (US), Regulatory Filing Identifier, US Fund Type"),
 ("HMRC Reporting Funds / German InvStG / OeKB","National tax authorities","Various","Regulation","Share-class tax reporting status","Share Class Tax Reporting"),
 ("DCAM","EDM Council","https://edmcouncil.org","Member framework","Data management capability: ownership and stewardship","Data Management Metadata"),
 ("Vendor EDM models (GoldenSource, S&P EDM, SimCorp, Aladdin)","Commercial vendors","Vendor-provided","Proprietary / licensed","Security- and fund-master data models","Optional cross-check during implementation; not used as primary source"),
]


_SRC_KEYS = {
 "FIBO": ["FIBO*"], "openfunds": ["openfunds"], "FinDatEx EMT": ["FinDatEx EMT"], "FinDatEx EET": ["FinDatEx EET"],
 "ISO 6166": ["ISO 6166*", "ISO 10962", "ISO 18774"], "ISO 17442": ["ISO 17442*"], "ISO 4217": ["ISO 10383"],
 "OpenFIGI": ["OMG FIGI*"], "GIPS": ["GIPS"], "EFAMA": ["EFAMA*"], "Morningstar": ["Morningstar"], "Lipper": ["LSEG Lipper"],
 "IA Sectors": ["Investment Association"], "ICI": ["ICI"], "SFDR and": ["SFDR", "SFDR RTS"], "PRIIPs": ["PRIIPs*"],
 "MiFID": ["MiFID II"], "UCITS Directive": ["UCITS*", "AIFMD", "EU MMFR", "EU BMR"], "ESMA": ["ESMA*"],
 "UK FCA": ["UK FCA*"], "SEC": ["SEC*"], "HMRC": ["HMRC", "German InvStG", "OeKB"], "DCAM": ["DCAM*"],
}
SRC = [tuple(s) + (next((v for k, v in _SRC_KEYS.items() if s[0].startswith(k)), []),) for s in SRC]
