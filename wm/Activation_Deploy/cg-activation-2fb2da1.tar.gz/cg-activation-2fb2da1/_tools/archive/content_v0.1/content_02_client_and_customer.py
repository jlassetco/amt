"""Business domain 02 - Client & Customer. Content module for taxonomy_builder.py."""

META = {
 "title": "Client & Customer Reference Data Taxonomy",
 "subtitle": "Business domain 02 - Client & Customer | Asset manager (wholesale distributor) | Scope: US + EU/UK | Draft v0.1 | 2026-10-01",
 "output": "02_Client_and_Customer/Client_and_Customer_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the party and client data domain of an asset manager that distributes wholesale. It defines the party master for every external organisation and individual the firm deals with: distributor firms and their hierarchy down to the advisor, gatekeepers, institutional clients and consultants, retirement plans and their service providers, and end investors on a look-through basis. It also covers the accounts, identifiers, classifications, contact points, privacy and KYC data attached to them. It draws on open standards (FIBO BE/FBC, GLEIF LEI-CDF, ISO 20022, ISO 20275, BIAN), regulatory registers (FINRA CRD, SEC Form ADV, FCA Register, DOL Form 5500), regulation (MiFID II, GDPR, CCPA/CPRA, AML/CFT) and common CRM and vendor data models (Salesforce FSC, Discovery Data, Broadridge). Use it as a starting point for a party/client master, CRM data model, data catalogue or business glossary."),
  ("Scope", "In scope: party master (organisation and individual), party roles and identifiers, intermediary firm hierarchy (firm > home office/division > branch/office > team > advisor), advisor practice profiles and affiliation history, gatekeepers/research, institutional clients and consultants, retirement plans, recordkeepers and plan advisors, end investors (look-through) and households, client/omnibus/networked/plan/institutional accounts, party relationships, regulatory and commercial segmentation, contact points, privacy status and legal basis for processing, institutional onboarding/KYC, and data management metadata. Out of scope (referenced by ID only): products, share classes and mandates (01 Investment Product); internal sales personnel, activities, opportunities and RFPs (03 Sales); campaigns, digital engagement, leads and marketing communication preferences / subscriptions (04 Marketing & Digital); selling, platform and DCIO agreements, shelf/approved-list status and research ratings (05 Distribution Agreements & Partners); transactions, positions, flows and AUM attribution (06 Sales Transactions & AUM Attribution); territories, coverage assignments, goals and crediting (07 Compensation & Territory); distributor due diligence, complaints and internal licences (08 Distribution Compliance)."),
  ("Structure", "Four levels: Domain > Subdomain > Concept > Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Party (one record per real-world organisation or individual, PTY-) plays one or more effective-dated Party Roles (distributor firm, branch, team, advisor, gatekeeper, institutional client, consultant, plan, recordkeeper, end investor). The intermediary hierarchy is a set of Hierarchy Nodes, each a party in a role, linked parent-to-child; advisors attach to firms and branches through Employment Affiliations (firm-employs-advisor) and to teams through Team Memberships. Accounts (ACC-) are held by parties through Account Party Roles (owner, dealer/branch/rep of record, plan sponsor) and may roll up to omnibus accounts. Identifiers, classifications, segment assignments, contact points, consents and KYC profiles hang off the party."),
  ("Design principles", "1) One party, many roles: never duplicate a party because it plays a second role (an RIA can be a distributor, a client and a model sponsor). 2) Prefer authoritative public identifiers (LEI, CRD, FRN/IRN, SEC file number, EIN + plan number) as match keys; keep vendor IDs as cross-references. 3) Effective-date all roles, relationships, affiliations, classifications and statuses so history can be reconstructed (advisor moves are a key business event). 4) Use controlled code lists, not free text. 5) Reference products, agreements, employees, territories and positions by ID; do not copy them. 6) Mark personal data (PII) and apply data minimisation: end-investor data is held only at the granularity the legal basis and intermediary agreements allow. 7) Flag Critical Data Elements (CDE) for governance and data-quality focus."),
  ("Applies To", "Shows the party type, role or record an attribute is held for: All Parties, Organisation, Individual, Distributor Firm, Hierarchy Node, Branch, Team, Advisor, Gatekeeper, Institutional Client, Consultant, Retirement Plan, Recordkeeper, End Investor, Household, Account, Contact Point or All."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify and match a party, build the distribution hierarchy, attribute assets and flows, meet regulatory classification or KYC obligations, or honour privacy rights. Confirm with data owners."),
  ("Primary / Secondary Reference", "Standard, register or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Vendor references (Discovery Data, Broadridge, FINTRX, Cerulli) indicate where the data is usually sourced and how it is commonly structured, not a licence to reproduce vendor taxonomies. Next step: map each attribute to the exact field in the source register, CRM object or vendor feed."),
  ("Notes", "PII = personal data under GDPR / UK GDPR and US state privacy laws. 'PII - restricted' = sensitive identifiers or special-category-adjacent data; hold only with a documented need and access controls."),
  ("Tabs", "Hierarchy: domains, subdomains and concepts with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: concept-level cardinalities for the logical model, including references to other business domains | Sources: standards, registers, regulations and vendor models used, with owners, licences and links."),
  ("Suggested next steps", "1) Validate domains, party roles and CDEs with Distribution, Sales Operations, Institutional, DCIO, Compliance, Privacy/DPO and Data Management. 2) Agree the hierarchy model of record (regulatory CRD structure versus vendor versus firm-defined) and the survivorship rules between CRD, Discovery Data, Broadridge and CRM. 3) Map attributes to source systems (CRM, TA/sub-TA feeds, vendor files, onboarding/KYC tool, consent platform). 4) Confirm with Legal which end-investor attributes can be received under each intermediary agreement and privacy regime. 5) Agree data owners and stewards per subdomain. 6) Extend code lists to firm values. 7) Turn the Relationships tab into a logical party data model aligned with 03, 05, 06 and 07."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Party Master", "CC-PTY",
  "The golden record for every external party the firm interacts with, whether an organisation or an individual, together with the roles that party plays.",
  [
   ("Party Core", "Identity and lifecycle attributes common to every party, regardless of type or role.", [
     ("Party", [
       ("Party ID", "Unique, permanent internal identifier for the party. Never reused, and retained after merge as a pointer to the surviving record.", "All Parties", "Identifier", "", "PTY-104588", "Internal", "FIBO BE", "Y"),
       ("Party Type", "Whether the party is an organisation (legal entity, branch, team, plan or other formal organisation) or a natural person.", "All Parties", "Code", "Party Type", "Organisation", "FIBO BE", "Salesforce FSC", "Y"),
       ("Party Display Name", "Name used to display the party in CRM and reports; derived from legal name or preferred name.", "All Parties", "Text", "", "Northbridge Wealth Partners", "Internal", "Salesforce FSC", ""),
       ("Party Status", "Lifecycle status of the party record.", "All Parties", "Code", "Party Status", "Active", "Internal", "BIAN", "Y"),
       ("Relationship Stage", "Commercial relationship stage of the party with the firm as a whole.", "All Parties", "Code", "Relationship Stage", "Client", "Internal", "Salesforce FSC", "Y"),
       ("Party Origin", "How the party record was created.", "All Parties", "Code", "Party Origin", "Vendor Feed - Discovery Data", "Internal", "", ""),
       ("Merged Into Party", "Surviving party record where this record was identified as a duplicate and merged.", "All Parties", "Reference (Party)", "", "PTY-100212", "Internal", "", "", "Supports de-duplication audit trail."),
       ("Primary Country", "Country of domicile (organisation) or residence (individual) used for regulatory and privacy scoping.", "All Parties", "Code", "ISO 3166-1 alpha-2", "US", "ISO 3166", "", "Y", "PII when the party is an individual."),
     ]),
   ]),
   ("Organisation", "Legal and descriptive attributes of organisations, aligned to FIBO legal entities and the GLEIF Level 1 record.", [
     ("Organisation", [
       ("Legal Name", "Registered legal name of the organisation as shown on its constitutional documents or official register.", "Organisation", "Text", "", "Northbridge Wealth Partners LLC", "GLEIF LEI-CDF", "FIBO BE", "Y"),
       ("Trading Name", "Name under which the organisation does business, where different from its legal name (DBA).", "Organisation", "Text", "", "Northbridge Wealth", "GLEIF LEI-CDF", "", ""),
       ("Organisation Type", "Business type of the organisation, independent of the role it plays with the firm.", "Organisation", "Code", "Organisation Type", "Registered Investment Adviser", "Internal", "FIBO FBC", "Y"),
       ("Legal Form", "Legal form of the entity, coded to the ISO 20275 Entity Legal Form (ELF) list.", "Organisation", "Code", "ISO 20275", "Limited Liability Company (ELF: 8888 / jurisdiction-specific code)", "ISO 20275", "GLEIF LEI-CDF", ""),
       ("Legal Jurisdiction", "Jurisdiction under whose law the entity is organised (country or country subdivision).", "Organisation", "Code", "ISO 3166-2", "US-DE", "GLEIF LEI-CDF", "FIBO BE", "Y"),
       ("Formation Date", "Date the entity was incorporated or otherwise legally formed.", "Organisation", "Date", "ISO 8601", "2009-02-11", "GLEIF LEI-CDF", "", ""),
       ("Industry Classification", "Industry code of the organisation (NAICS in the US, NACE in the EU/UK SIC).", "Organisation", "Code", "External (NAICS / NACE)", "523930 - Investment Advice", "Internal", "", ""),
       ("Regulated Entity Indicator", "Whether the organisation is authorised or registered with a financial regulator.", "Organisation", "Boolean", "", "Y", "FIBO FBC", "MiFID II", ""),
       ("Primary Regulator", "Main financial regulator(s) supervising the organisation.", "Organisation", "Code (multi)", "Regulator", "SEC; FINRA", "FIBO FBC", "", ""),
     ]),
     ("Legal Entity Hierarchy", [
       ("Direct Parent", "Legal entity that directly consolidates or controls this organisation.", "Organisation", "Reference (Party)", "", "PTY-100050", "GLEIF LEI-CDF", "FIBO BE", "Y", "GLEIF Level 2 'who owns whom' where available."),
       ("Ultimate Parent", "Highest-level legal entity that consolidates this organisation.", "Organisation", "Reference (Party)", "", "PTY-100001", "GLEIF LEI-CDF", "FIBO BE", "Y"),
       ("Parent Relationship Basis", "Basis on which the parent relationship is asserted.", "Organisation", "Code", "Parent Relationship Basis", "Accounting Consolidation", "GLEIF LEI-CDF", "", ""),
       ("Ownership Percentage", "Percentage of the organisation held by the direct parent, where known.", "Organisation", "Percentage", "", "100%", "FIBO BE", "", ""),
     ]),
   ]),
   ("Individual", "Personal attributes of natural persons: advisors, gatekeepers, institutional contacts, consultants and end investors.", [
     ("Individual", [
       ("Given Name", "First / given name of the individual.", "Individual", "Text", "", "Sarah", "FIBO BE", "Salesforce FSC", "Y", "PII"),
       ("Family Name", "Surname / family name of the individual.", "Individual", "Text", "", "Okafor", "FIBO BE", "Salesforce FSC", "Y", "PII"),
       ("Preferred Name", "Name the individual prefers to be addressed by.", "Individual", "Text", "", "Sally", "Internal", "Salesforce FSC", "", "PII"),
       ("Date of Birth", "Date of birth. Hold only where required for KYC or regulatory matching; otherwise use an age band.", "Individual", "Date", "ISO 8601", "1971-05-22", "FIBO BE", "FinCEN CDD Rule", "", "PII - restricted"),
       ("Nationality", "Citizenship(s) of the individual, required for KYC of beneficial owners and controllers.", "Individual", "Code (multi)", "ISO 3166-1 alpha-2", "GB; IE", "FATF", "", "", "PII"),
       ("Deceased Indicator", "Whether the individual is known to be deceased; suppresses contact and triggers account review.", "Individual", "Boolean", "", "N", "Internal", "", "", "PII"),
     ]),
   ]),
   ("Party Role", "The effective-dated roles a party plays in relation to the firm. A party can hold several roles at once.", [
     ("Party Role", [
       ("Role Type", "Role the party plays (e.g. distributor firm, branch, financial advisor, gatekeeper, institutional client, consultant, retirement plan, recordkeeper, end investor).", "All Parties", "Code", "Party Role Type", "Financial Advisor", "FIBO BE", "BIAN", "Y"),
       ("Role Status", "Status of the party in this role.", "All Parties", "Code", "Role Status", "Active", "Internal", "", ""),
       ("Role Effective From", "Date the party began playing the role.", "All Parties", "Date", "ISO 8601", "2019-01-02", "Internal", "", ""),
       ("Role Effective To", "Date the party stopped playing the role.", "All Parties", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Role Source", "Source that asserted the role (register, vendor, onboarding, manual).", "All Parties", "Code", "Party Origin", "Regulatory Register - FINRA CRD", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Party Identifiers", "CC-PID",
  "Regulatory, market-infrastructure, tax and vendor identifiers used to recognise parties across registers, systems and counterparties, and to match records.",
  [
   ("Identifier Register", "Generic, effective-dated store of every identifier held for a party.", [
     ("Party Identifier", [
       ("Identifier Value", "The identifier as issued.", "All Parties", "Identifier", "", "5493004SXGJ8KJ3TQR56", "ISO 20022", "", ""),
       ("Identifier Scheme", "Scheme or register that issued the identifier.", "All Parties", "Code", "Identifier Scheme", "LEI", "ISO 20022", "FIBO FBC", ""),
       ("Identifier Status", "Whether the identifier is currently valid.", "All Parties", "Code", "Identifier Status", "Active", "Internal", "", ""),
       ("Last Verified Date", "Date the identifier was last checked against the issuing register.", "All Parties", "Date", "ISO 8601", "2026-09-15", "Internal", "", ""),
     ]),
   ]),
   ("Legal Entity Identifier", "LEI and selected GLEIF Level 1 reference data for organisations.", [
     ("LEI Record", [
       ("LEI", "20-character Legal Entity Identifier of the organisation.", "Organisation", "Identifier", "ISO 17442", "5493004SXGJ8KJ3TQR56", "ISO 17442 (GLEIF)", "ISO 20022", "Y"),
       ("LEI Registration Status", "Status of the LEI registration in the Global LEI System.", "Organisation", "Code", "LEI Registration Status", "ISSUED", "GLEIF LEI-CDF", "", ""),
       ("LEI Entity Category", "GLEIF entity category (general, branch, fund, sole proprietor, etc.).", "Organisation", "Code", "LEI Entity Category", "GENERAL", "GLEIF LEI-CDF", "", ""),
       ("Registration Authority ID", "GLEIF Registration Authority (RA) code of the business register holding the entity.", "Organisation", "Code", "External (GLEIF RA list)", "RA000602", "GLEIF LEI-CDF", "FIBO FBC", ""),
       ("Registration Authority Entity ID", "Identifier of the entity at that business register (e.g. Delaware file number, Companies House number).", "Organisation", "Identifier", "", "4512378", "GLEIF LEI-CDF", "", ""),
     ]),
   ]),
   ("US Regulatory Identifiers", "Identifiers issued by US regulators and self-regulatory organisations.", [
     ("US Regulatory Identifier", [
       ("Firm CRD Number", "FINRA Central Registration Depository number of a broker-dealer or investment adviser firm (also used in IARD / IAPD).", "Organisation", "Identifier", "", "149822", "FINRA CRD", "SEC Form ADV", "Y"),
       ("Individual CRD Number", "FINRA CRD number of a registered individual (registered representative or investment adviser representative).", "Individual", "Identifier", "", "5123467", "FINRA CRD", "FINRA BrokerCheck", "Y", "PII"),
       ("SEC File Number", "SEC file number of a registered investment adviser (801-) or broker-dealer (8-).", "Organisation", "Identifier", "", "801-112345", "SEC Form ADV", "SEC Form BD", "Y"),
       ("SEC Central Index Key", "SEC EDGAR CIK of the organisation, used for filings such as 13F and Form D.", "Organisation", "Identifier", "", "0001678901", "SEC EDGAR", "", ""),
       ("National Producer Number", "NIPR National Producer Number of a licensed insurance producer (relevant for annuity and insurance-channel advisors).", "Individual", "Identifier", "", "17654321", "NIPR", "", "", "PII"),
       ("Employer Identification Number", "IRS EIN of a US organisation; with the plan number, identifies a retirement plan in Form 5500.", "Organisation", "Identifier", "", "36-4512378", "IRS", "DOL Form 5500", "Y"),
     ]),
   ]),
   ("UK & EU Regulatory Identifiers", "Identifiers issued by UK and EU regulators and registers.", [
     ("UK & EU Regulatory Identifier", [
       ("FCA Firm Reference Number", "FRN of a firm on the FCA Financial Services Register.", "Organisation", "Identifier", "", "612345", "UK FCA Register", "", "Y"),
       ("FCA Individual Reference Number", "IRN of an individual on the FCA Financial Services Register (approved / certified persons).", "Individual", "Identifier", "", "ABC01234", "UK FCA Register", "UK FCA SM&CR", "Y", "PII"),
       ("National Competent Authority ID", "Register number at an EU national competent authority (e.g. CSSF, BaFin, AMF, Central Bank of Ireland C-number).", "Organisation", "Identifier", "", "C123456 (Central Bank of Ireland)", "MiFID II", "", ""),
       ("Business Identifier Code", "ISO 9362 BIC of a financial institution, used in settlement and messaging.", "Organisation", "Identifier", "ISO 9362", "NBWPGB2L", "ISO 9362", "ISO 20022", ""),
     ]),
   ]),
   ("Market Infrastructure & Vendor Identifiers", "Identifiers used in fund processing networks and by commercial data vendors.", [
     ("Market Infrastructure & Vendor Identifier", [
       ("NSCC Participant Number", "NSCC member / participant number of the intermediary used in Fund/SERV and Networking.", "Distributor Firm", "Identifier", "", "0457", "DTCC / NSCC", "", ""),
       ("Transfer Agent Dealer Number", "Dealer (broker) number assigned to the intermediary by the fund's transfer agent; key for matching TA trades to firms.", "Distributor Firm, Branch", "Identifier", "", "D-004512", "DTCC / NSCC", "Internal", "Y"),
       ("Vendor Party ID", "Identifier of the party in a commercial data vendor's database (e.g. Discovery Data, Broadridge, FINTRX).", "All Parties", "Identifier", "", "DD-REP-8812345", "Discovery Data", "Broadridge", "", "PII when the party is an individual."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Intermediary Firm & Hierarchy", "CC-INT",
  "Distributor firms (wirehouses, regional and independent broker-dealers, RIAs, banks, private banks, IFAs, platforms and TAMPs), their regulatory profile, and the hierarchy from firm through home office, branch and team to the advisor.",
  [
   ("Distributor Firm Profile", "Commercial and regulatory profile of an intermediary firm that distributes the firm's products.", [
     ("Distributor Firm", [
       ("Distribution Channel", "Primary intermediary channel of the firm, using a Cerulli-style channel scheme.", "Distributor Firm", "Code", "Distribution Channel", "Independent RIA", "Cerulli", "Discovery Data", "Y"),
       ("Firm Registration Type", "How the firm is registered to provide brokerage and/or advisory services.", "Distributor Firm", "Code", "Firm Registration Type", "SEC-Registered Investment Adviser", "SEC Form ADV", "FINRA CRD", "Y"),
       ("Number of Registered Representatives", "Number of FINRA-registered representatives associated with the firm.", "Distributor Firm", "Integer", "", "2,450", "FINRA CRD", "Discovery Data", ""),
       ("Number of Investment Adviser Representatives", "Number of investment adviser representatives (IARs) associated with the firm.", "Distributor Firm", "Integer", "", "118", "SEC Form ADV", "Discovery Data", ""),
       ("Clearing Firm", "Clearing broker-dealer used by an introducing firm.", "Distributor Firm", "Reference (Party)", "", "PTY-100780", "SEC Form BD", "", ""),
       ("Primary Custodian", "Custodian(s) on which the RIA's client assets are held; key for RIA-channel data and platform access.", "Distributor Firm", "Reference (Party)", "", "PTY-100912", "SEC Form ADV", "Discovery Data", "", "Form ADV Schedule D 5.K(3) / Item 9 custodian data."),
       ("Product Platforms Offered", "Investment vehicles and programmes the firm makes available to its advisors.", "Distributor Firm", "Code (multi)", "Platform Offering", "Mutual Funds; ETFs; SMA; UMA; Model Portfolios", "Internal", "Broadridge", ""),
       ("Firm Operating Model", "Degree of central control over advisors' product and model selection.", "Distributor Firm", "Code", "Firm Operating Model", "Centralised Research / Approved List", "Internal", "Cerulli", ""),
     ]),
     ("Form ADV Profile", [
       ("Regulatory Assets Under Management", "Total regulatory AUM reported in Form ADV Part 1A Item 5.F.", "Distributor Firm", "Amount", "", "USD 4,850,000,000", "SEC Form ADV", "FINTRX", "Y"),
       ("Discretionary RAUM", "Portion of regulatory AUM managed on a discretionary basis (Item 5.F).", "Distributor Firm", "Amount", "", "USD 4,210,000,000", "SEC Form ADV", "", ""),
       ("Advisory Client Types", "Types of clients served (Item 5.D), e.g. high-net-worth individuals, pension plans, charities.", "Distributor Firm", "Code (multi)", "ADV Client Type", "High Net Worth Individuals; Individuals (other); Pension and Profit Sharing Plans", "SEC Form ADV", "", ""),
       ("Compensation Arrangements", "How the adviser is compensated (Item 5.E).", "Distributor Firm", "Code (multi)", "ADV Compensation Type", "Percentage of AUM; Fixed Fees", "SEC Form ADV", "", ""),
       ("Form ADV Filing Date", "Date of the Form ADV filing from which the profile was taken.", "Distributor Firm", "Date", "ISO 8601", "2026-03-28", "SEC Form ADV", "", ""),
     ]),
   ]),
   ("Firm Hierarchy", "The parent-child structure of a distributor firm. Each node is a party (organisation) in a hierarchy role.", [
     ("Hierarchy Node", [
       ("Hierarchy Type", "Which hierarchy the node belongs to; firms are often modelled in several hierarchies at once.", "Hierarchy Node", "Code", "Hierarchy Type", "Firm Operational", "Internal", "Broadridge", ""),
       ("Hierarchy Level", "Level of the node in the hierarchy.", "Hierarchy Node", "Code", "Hierarchy Level", "Branch / Office", "Internal", "Salesforce FSC", "Y"),
       ("Parent Node", "Party that is the immediate parent of this node in the given hierarchy.", "Hierarchy Node", "Reference (Party)", "", "PTY-100450", "Internal", "", "Y"),
       ("Top-Level Firm", "Firm at the top of the hierarchy, denormalised for reporting and attribution.", "Hierarchy Node", "Reference (Party)", "", "PTY-100001", "Internal", "", ""),
       ("Node Effective From", "Date the node took its current position in the hierarchy.", "Hierarchy Node", "Date", "ISO 8601", "2024-01-01", "Internal", "", ""),
       ("Node Effective To", "Date the node left this position (closure, re-parenting, merger).", "Hierarchy Node", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Branch / Office", [
       ("Branch CRD Number", "FINRA branch office number registered through Form BR.", "Branch", "Identifier", "", "712345", "FINRA Form BR", "FINRA CRD", "Y"),
       ("Branch Type", "Regulatory and operational type of the location.", "Branch", "Code", "Branch Type", "OSJ Branch", "FINRA Form BR", "", ""),
       ("Supervising OSJ", "Office of Supervisory Jurisdiction responsible for a non-OSJ branch.", "Branch", "Reference (Party)", "", "PTY-100455", "FINRA Form BR", "", ""),
     ]),
     ("Advisor Team", [
       ("Team Name", "Name under which the advisor team markets itself.", "Team", "Text", "", "The Harbourview Group", "Internal", "Discovery Data", ""),
       ("Team Lead", "Advisor who leads the team.", "Team", "Reference (Party)", "", "PTY-204511", "Internal", "", ""),
       ("Team Rep Code", "Joint / split representative code under which team business is booked at the firm and the TA.", "Team", "Identifier", "", "J4K7", "Internal", "DTCC / NSCC", "Y", "Used for flow attribution in 06 TX."),
     ]),
   ]),
   ("Home Office & Gatekeepers", "Central functions at distributor firms that control product access and model and research decisions.", [
     ("Gatekeeper Profile", [
       ("Gatekeeper Function", "Home-office function the individual or unit performs.", "Gatekeeper", "Code", "Gatekeeper Function", "Manager Research / Due Diligence", "Internal", "Cerulli", "Y"),
       ("Decision Authority", "Level of authority over product approval or allocation.", "Gatekeeper", "Code", "Decision Authority", "Approver", "Internal", "", ""),
       ("Asset Class Coverage", "Asset classes or vehicle types the gatekeeper covers.", "Gatekeeper", "Code (multi)", "Asset Class Coverage", "Fixed Income; Alternatives", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Financial Professional & Practice", "CC-FPR",
  "Individual financial professionals at intermediaries (advisors, registered representatives, IFAs, private bankers, plan advisors): their registrations, practice profile and employment history.",
  [
   ("Financial Professional Profile", "Professional and registration profile of an external financial professional, largely sourced from CRD/IAPD, the FCA Register and vendors.", [
     ("Financial Professional", [
       ("Professional Type", "Type of financial professional.", "Advisor", "Code", "Professional Type", "Dually Registered (RR + IAR)", "FINRA CRD", "Discovery Data", "Y"),
       ("Job Title", "Title held at the employing firm.", "Advisor", "Text", "", "Senior Vice President, Wealth Management", "Internal", "", "", "PII"),
       ("Professional Designations", "Professional credentials held.", "Advisor", "Code (multi)", "Professional Designation", "CFP; CIMA", "Internal", "Discovery Data", "", "PII"),
       ("Industry Start Date", "Date the professional first became registered in the industry; used to derive years of experience.", "Advisor", "Date", "ISO 8601", "2003-08-18", "FINRA BrokerCheck", "", "", "PII"),
       ("Qualification Exams", "FINRA / NASAA examinations passed.", "Advisor", "Code (multi)", "Qualification Exam", "SIE; Series 7; Series 66", "FINRA BrokerCheck", "", "", "PII"),
       ("Registration Status", "Current registration status in CRD / IAPD.", "Advisor", "Code", "Registration Status", "Active - BD and IA", "FINRA CRD", "", "Y", "PII"),
       ("Disclosure Events Count", "Number of disclosure events (customer disputes, regulatory actions, terminations) on BrokerCheck / IAPD.", "Advisor", "Integer", "", "0", "FINRA BrokerCheck", "", "", "PII - restricted. Public data; use for distributor risk only."),
       ("UK Certification Status", "Whether the individual is an SM&CR certified or approved person and holds a Statement of Professional Standing where applicable.", "Advisor", "Code", "UK Certification Status", "Certified - SPS Held", "UK FCA SM&CR", "UK FCA Register", "", "PII"),
     ]),
   ]),
   ("Practice Profile", "Business profile of an advisor's or team's practice, used for segmentation and targeting.", [
     ("Advisor Practice", [
       ("Business Model", "Business model of the practice.", "Advisor, Team", "Code", "Advisor Business Model", "Wirehouse FA", "Cerulli", "Discovery Data", "Y"),
       ("Revenue Model", "Predominant source of practice revenue.", "Advisor, Team", "Code", "Revenue Model", "Fee-Based", "Cerulli", "Discovery Data", ""),
       ("Practice AUM", "Total client assets serviced by the practice (book size).", "Advisor, Team", "Amount", "", "USD 412,000,000", "Discovery Data", "Broadridge", "Y", "Vendor estimate unless sourced from 06 TX."),
       ("Number of Client Households", "Number of client households served.", "Advisor, Team", "Integer", "", "210", "Discovery Data", "", ""),
       ("Investment Management Style", "How the practice builds portfolios.", "Advisor, Team", "Code", "Investment Management Style", "Rep as Portfolio Manager", "Cerulli", "Broadridge", ""),
       ("Client Niche", "Client segments the practice specialises in.", "Advisor, Team", "Code (multi)", "Client Niche", "Business Owners; Pre-Retirees", "Internal", "Discovery Data", ""),
       ("Vehicle Usage", "Vehicles the practice uses materially.", "Advisor, Team", "Code (multi)", "Platform Offering", "ETFs; Model Portfolios; SMA", "Broadridge", "Discovery Data", ""),
       ("Retirement Plan Practice Indicator", "Whether the advisor actively advises employer retirement plans (plan advisor).", "Advisor, Team", "Boolean", "", "Y", "DOL Form 5500", "Discovery Data", "", "Derived from Schedule C / vendor data."),
       ("Practice Data As-Of Date", "Date of the vendor or survey data used for the practice profile.", "Advisor, Team", "Date", "ISO 8601", "2026-06-30", "Internal", "", ""),
     ]),
   ]),
   ("Employment & Affiliation", "Effective-dated firm-employs-advisor relationships, including advisor moves between firms.", [
     ("Employment Affiliation", [
       ("Employing Firm", "Firm the professional is registered with or employed by.", "Advisor", "Reference (Party)", "", "PTY-100001", "FINRA CRD", "UK FCA Register", "Y"),
       ("Office of Record", "Branch or office the professional works from.", "Advisor", "Reference (Party)", "", "PTY-100455", "FINRA Form BR", "", ""),
       ("Affiliation Type", "Nature of the professional's association with the firm.", "Advisor", "Code", "Affiliation Type", "Employee", "FINRA CRD", "UK FCA Register", ""),
       ("Affiliation Start Date", "Date the professional joined the firm.", "Advisor", "Date", "ISO 8601", "2018-04-09", "FINRA CRD", "", "Y"),
       ("Affiliation End Date", "Date the professional left the firm.", "Advisor", "Date", "ISO 8601", "", "FINRA CRD", "", "Y"),
       ("Primary Affiliation Indicator", "Whether this is the professional's primary affiliation, where they are registered with more than one firm (e.g. BD plus RIA).", "Advisor", "Boolean", "", "Y", "Internal", "", ""),
       ("Affiliation Change Reason", "Reason for leaving or changing affiliation.", "Advisor", "Code", "Affiliation Change Reason", "Breakaway to Independent RIA", "Discovery Data", "Internal", ""),
       ("Move Detected Date", "Date the firm first learned of the move (vendor alert, CRD change, TA rep transfer).", "Advisor", "Date", "ISO 8601", "2026-09-12", "Discovery Data", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Institutional & Retirement Clients", "CC-INS",
  "Institutional asset owners, investment consultants, and US/UK retirement plans with their sponsors, recordkeepers and plan advisors.",
  [
   ("Institutional Client Profile", "Profile of an institutional asset owner that is a client or prospect.", [
     ("Institutional Client", [
       ("Institutional Client Type", "Type of institutional asset owner.", "Institutional Client", "Code", "Institutional Client Type", "Public Pension Plan", "Internal", "SEC Form ADV", "Y"),
       ("Total Investable Assets", "Total assets under the institution's investment programme.", "Institutional Client", "Amount", "", "USD 18,400,000,000", "Internal", "", "Y"),
       ("Assets As-Of Date", "Date the investable assets figure relates to.", "Institutional Client", "Date", "ISO 8601", "2026-06-30", "Internal", "", ""),
       ("Governance Model", "How investment decisions are governed.", "Institutional Client", "Code", "Governance Model", "Investment Committee with Consultant", "Internal", "", ""),
       ("Funded Status", "Ratio of assets to liabilities for defined benefit plans.", "Institutional Client", "Percentage", "", "84%", "Internal", "", ""),
       ("Government Entity Indicator", "Whether the client is a government entity for SEC pay-to-play rule purposes.", "Institutional Client", "Boolean", "", "Y", "SEC Rule 206(4)-5", "", "Y"),
       ("ERISA Plan Indicator", "Whether the client is subject to ERISA fiduciary rules.", "Institutional Client", "Boolean", "", "N", "ERISA", "", ""),
     ]),
   ]),
   ("Investment Consultant", "Consultants and OCIOs that advise institutional clients and act as influencers in manager selection.", [
     ("Consultant Profile", [
       ("Consultant Type", "Business type of the consulting firm.", "Consultant", "Code", "Consultant Type", "Full-Service Investment Consultant", "Internal", "", ""),
       ("Assets Under Advisement", "Total client assets on which the consultant advises.", "Consultant", "Amount", "", "USD 1,200,000,000,000", "Internal", "SEC Form ADV", ""),
       ("Discretionary OCIO Assets", "Client assets managed on a discretionary (OCIO / fiduciary management) basis.", "Consultant", "Amount", "", "USD 95,000,000,000", "SEC Form ADV", "", ""),
       ("Manager Research Coverage", "Asset classes covered by the consultant's manager research team.", "Consultant", "Code (multi)", "Asset Class Coverage", "Global Equity; Private Credit", "Internal", "", ""),
     ]),
   ]),
   ("Retirement Plan", "Employer-sponsored retirement plans (DC and DB) in the DCIO and institutional channels.", [
     ("Retirement Plan", [
       ("Plan Sponsor", "Employer or organisation that sponsors the plan.", "Retirement Plan", "Reference (Party)", "", "PTY-301120", "DOL Form 5500", "ERISA", "Y"),
       ("Sponsor EIN", "EIN of the plan sponsor as reported on Form 5500 line 2b.", "Retirement Plan", "Identifier", "", "36-4512378", "DOL Form 5500", "IRS", "Y"),
       ("Plan Number", "Three-digit plan number (PN) assigned by the sponsor; with the EIN uniquely identifies a US plan.", "Retirement Plan", "Identifier", "", "001", "DOL Form 5500", "", "Y"),
       ("Plan Name", "Name of the plan as reported on Form 5500.", "Retirement Plan", "Text", "", "Harbor Manufacturing 401(k) Savings Plan", "DOL Form 5500", "", ""),
       ("Plan Type", "Type of retirement plan.", "Retirement Plan", "Code", "Retirement Plan Type", "401(k)", "DOL Form 5500", "", "Y"),
       ("Plan Characteristic Codes", "Form 5500 line 8a/8b plan characteristics codes (e.g. 2J 401(k) feature, 2T participant-directed with default).", "Retirement Plan", "Code (multi)", "External (DOL Form 5500)", "2E; 2F; 2J; 2K; 2T", "DOL Form 5500", "", ""),
       ("Plan Assets", "Net assets of the plan at year end (Schedule H/I).", "Retirement Plan", "Amount", "", "USD 312,500,000", "DOL Form 5500", "", "Y"),
       ("Active Participants", "Number of active participants at year end.", "Retirement Plan", "Integer", "", "2,940", "DOL Form 5500", "", ""),
       ("Form 5500 Filing Year", "Plan year of the latest Form 5500 used to populate the record.", "Retirement Plan", "Integer", "", "2025", "DOL Form 5500", "", ""),
       ("QDIA Type", "Type of qualified default investment alternative used.", "Retirement Plan", "Code", "QDIA Type", "Target Date Fund", "ERISA", "", ""),
       ("Fiduciary Investment Adviser Type", "Whether an adviser acts as ERISA 3(21) co-fiduciary or 3(38) investment manager to the plan.", "Retirement Plan", "Code", "ERISA Fiduciary Type", "3(38) Investment Manager", "ERISA", "", ""),
       ("UK Pension Scheme Registry Number", "The Pensions Regulator's Pension Scheme Registry number for UK schemes.", "Retirement Plan", "Identifier", "", "10123456", "TPR", "", ""),
     ]),
     ("Recordkeeper Profile", [
       ("Recordkeeper Model", "Operating model of the recordkeeper.", "Recordkeeper", "Code", "Recordkeeper Model", "Open Architecture", "Internal", "", ""),
       ("Plan Market Segments Served", "Plan size segments the recordkeeper primarily serves.", "Recordkeeper", "Code (multi)", "Plan Market Segment", "Small; Mid", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("End Investor & Household", "CC-INV",
  "End investors behind intermediaries and plans, held on a look-through basis only where data-sharing agreements and privacy law allow, and the households they belong to.",
  [
   ("End Investor Profile", "Minimum-necessary profile of an end investor, usually received in anonymised or pseudonymised form.", [
     ("End Investor", [
       ("Investor Type", "Legal type of the end investor.", "End Investor", "Code", "Investor Type", "Individual", "Internal", "Salesforce FSC", "Y"),
       ("Look-Through Data Basis", "How the firm holds data about the investor.", "End Investor", "Code", "Look-Through Data Basis", "Pseudonymised (Intermediary Token)", "Internal", "EU GDPR", "Y"),
       ("Pseudonymised Investor Key", "Stable token supplied by the intermediary or sub-TA that identifies the investor without revealing identity.", "End Investor", "Identifier", "", "a4f9c2e1-7b33", "EU GDPR", "", "Y", "PII (pseudonymised data remains personal data under GDPR)."),
       ("Residence Region", "State (US) or region of residence; used for tax, blue-sky and registration checks.", "End Investor", "Code", "ISO 3166-2", "US-CA", "Internal", "", "", "PII"),
       ("Investor Age Band", "Age band of the investor, held instead of date of birth.", "End Investor", "Code", "Age Band", "55-64", "Internal", "", "", "PII"),
       ("Wealth Tier", "Wealth segment of the investor or household.", "End Investor, Household", "Code", "Wealth Tier", "High Net Worth", "Internal", "Cerulli", "", "PII"),
       ("Advisor of Record", "Financial professional who advises the investor.", "End Investor", "Reference (Party)", "", "PTY-204511", "Internal", "", "Y"),
       ("Vulnerable Customer Indicator", "Whether the intermediary has flagged characteristics of vulnerability (UK Consumer Duty). Hold only if shared under agreement.", "End Investor", "Boolean", "", "N", "UK FCA Consumer Duty", "", "", "PII - restricted"),
     ]),
   ]),
   ("Household", "Groups of individuals whose finances are managed together.", [
     ("Household", [
       ("Household ID", "Identifier of the household group.", "Household", "Identifier", "", "PTY-HH-55012", "Salesforce FSC", "", ""),
       ("Household Name", "Display name of the household.", "Household", "Text", "", "Okafor Household", "Salesforce FSC", "", "", "PII"),
       ("Primary Member", "Individual designated as the head of household.", "Household", "Reference (Party)", "", "PTY-500771", "Salesforce FSC", "", "", "PII"),
       ("Household Investable Assets", "Estimated total investable assets of the household.", "Household", "Amount", "", "USD 4,200,000", "Internal", "Salesforce FSC", "", "PII"),
       ("Household Source", "Source that defined the household grouping.", "Household", "Code", "Party Origin", "Intermediary Feed", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Accounts", "CC-ACC",
  "Accounts through which clients and intermediaries hold the firm's products: direct and networked investor accounts, omnibus and sub-accounts, plan accounts and institutional accounts, with the parties that play roles on them.",
  [
   ("Account Core", "Identity, type and status of an account. Holdings and transactions are owned by 06 TX.", [
     ("Account", [
       ("Account ID", "Unique internal identifier for the account.", "Account", "Identifier", "", "ACC-0049812", "Internal", "Salesforce FSC", "Y"),
       ("Account Type", "Structural type of the account.", "Account", "Code", "Account Type", "Networked Investor Account", "Internal", "DTCC / NSCC", "Y"),
       ("Account Name", "Registration or title of the account.", "Account", "Text", "", "Okafor Family Trust UAD 04/02/2015", "Salesforce FSC", "", "", "PII when held by individuals."),
       ("External Account Number", "Account number at the transfer agent, custodian or platform.", "Account", "Identifier", "", "TA 0045-889123", "Internal", "DTCC / NSCC", "Y", "PII when held by individuals."),
       ("Account Registration Type", "Legal registration of the account.", "Account", "Code", "Account Registration Type", "Revocable Trust", "Salesforce FSC", "IRS", "Y"),
       ("Account Status", "Lifecycle status of the account.", "Account", "Code", "Account Status", "Open", "Internal", "", "Y"),
       ("Account Open Date", "Date the account was opened.", "Account", "Date", "ISO 8601", "2021-11-03", "Internal", "", ""),
       ("Account Close Date", "Date the account was closed.", "Account", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Advisory Program Indicator", "Whether the account sits in a fee-based advisory or wrap programme rather than a brokerage relationship.", "Account", "Boolean", "", "Y", "SEC Form ADV", "", ""),
     ]),
   ]),
   ("Intermediary & Omnibus Servicing", "How an account is held and serviced through intermediaries and fund processing networks.", [
     ("Intermediary Account Servicing", [
       ("Networking Level", "NSCC Networking matrix level, defining whether the fund or the intermediary controls and services the account.", "Account", "Code", "Networking Level", "Level 3", "DTCC / NSCC", "", "Y"),
       ("Dealer of Record", "Intermediary firm of record on the account at the transfer agent.", "Account", "Reference (Party)", "", "PTY-100001", "DTCC / NSCC", "", "Y"),
       ("Branch of Record", "Branch or office of record on the account.", "Account", "Reference (Party)", "", "PTY-100455", "DTCC / NSCC", "", ""),
       ("Rep of Record", "Financial professional or team of record on the account.", "Account", "Reference (Party)", "", "PTY-204511", "DTCC / NSCC", "", "Y"),
       ("Rep Code at Transfer Agent", "Representative code held on the TA account; used to resolve the rep of record.", "Account", "Identifier", "", "J4K7", "DTCC / NSCC", "", ""),
       ("Omnibus Parent Account", "Omnibus account under which this sub-account is aggregated.", "Account", "Reference (Account)", "", "ACC-0000312", "Internal", "", ""),
       ("Nominee Designation", "Nominee or designation reference on a platform or nominee account (UK / EU).", "Account", "Text", "", "PLATFORMNOM A/C 77812", "Internal", "", ""),
     ]),
   ]),
   ("Institutional & Plan Accounts", "Accounts held by institutional clients and retirement plans.", [
     ("Institutional Account", [
       ("Related Mandate", "Separate account mandate the account is managed under.", "Account", "Reference (Mandate)", "", "MND-01234", "Internal", "", ""),
       ("Related Retirement Plan", "Retirement plan that holds the account.", "Account", "Reference (Party)", "", "PTY-301121", "DOL Form 5500", "", ""),
       ("Custodian", "Custodian bank holding the account's assets.", "Account", "Reference (Party)", "", "PTY-100912", "Internal", "", ""),
       ("Governing Agreement", "Agreement governing the account (e.g. IMA, subscription agreement, DCIO servicing agreement).", "Account", "Reference (Agreement)", "", "AGR-00981", "Internal", "", ""),
     ]),
   ]),
   ("Account Party Role", "Effective-dated roles parties play on an account.", [
     ("Account Party Role", [
       ("Account Role Type", "Role the party plays on the account.", "Account", "Code", "Account Role Type", "Primary Owner", "Salesforce FSC", "ISO 20022", "Y"),
       ("Role Party", "Party playing the role.", "Account", "Reference (Party)", "", "PTY-500771", "Salesforce FSC", "", ""),
       ("Account Role Effective From", "Date the role started.", "Account", "Date", "ISO 8601", "2021-11-03", "Internal", "", ""),
       ("Account Role Effective To", "Date the role ended.", "Account", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Party Relationships", "CC-REL",
  "Effective-dated relationships between parties: household membership, team membership, consultant-advises-client, firm-employs-advisor (see CC-FPR), plan service providers and other influence relationships.",
  [
   ("Party-to-Party Relationship", "Generic relationship between two parties, typed by a controlled list.", [
     ("Party Relationship", [
       ("From Party", "Party at the 'from' end of the relationship.", "All Parties", "Reference (Party)", "", "PTY-204511", "Salesforce FSC", "FIBO BE", ""),
       ("To Party", "Party at the 'to' end of the relationship.", "All Parties", "Reference (Party)", "", "PTY-500771", "Salesforce FSC", "FIBO BE", ""),
       ("Relationship Type", "Nature of the relationship.", "All Parties", "Code", "Party Relationship Type", "Advises", "Salesforce FSC", "BIAN", "Y"),
       ("Relationship Effective From", "Date the relationship began.", "All Parties", "Date", "ISO 8601", "2022-02-01", "Internal", "", ""),
       ("Relationship Effective To", "Date the relationship ended.", "All Parties", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Household Membership", [
       ("Household", "Household the individual belongs to.", "Household", "Reference (Party)", "", "PTY-HH-55012", "Salesforce FSC", "", "", "PII"),
       ("Household Member", "Individual who belongs to the household.", "Household", "Reference (Party)", "", "PTY-500771", "Salesforce FSC", "", "", "PII"),
       ("Household Member Role", "Role of the member in the household.", "Household", "Code", "Household Member Role", "Spouse / Partner", "Salesforce FSC", "", "", "PII"),
     ]),
   ]),
   ("Team Membership", "Membership of financial professionals in advisor teams.", [
     ("Team Membership", [
       ("Team", "Advisor team.", "Team", "Reference (Party)", "", "PTY-204500", "Internal", "Discovery Data", ""),
       ("Team Member", "Financial professional who is a member of the team.", "Team", "Reference (Party)", "", "PTY-204511", "Internal", "", "Y"),
       ("Team Member Role", "Role of the member on the team.", "Team", "Code", "Team Member Role", "Senior Partner", "Internal", "Discovery Data", ""),
       ("Team Membership Effective From", "Date the member joined the team.", "Team", "Date", "ISO 8601", "2020-01-01", "Internal", "", ""),
       ("Team Membership Effective To", "Date the member left the team.", "Team", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Consultant Relationship", "Consultant-advises-client relationships in the institutional channel.", [
     ("Consultant Advisory Relationship", [
       ("Consultant Firm", "Consulting firm advising the client.", "Consultant", "Reference (Party)", "", "PTY-100670", "Internal", "", "Y"),
       ("Advised Client", "Institutional client or plan being advised.", "Institutional Client", "Reference (Party)", "", "PTY-301120", "Internal", "", "Y"),
       ("Consulting Engagement Type", "Nature of the consultant's engagement.", "Consultant", "Code", "Consulting Engagement Type", "Non-Discretionary General Consultant", "Internal", "", ""),
       ("Engagement Effective From", "Date the engagement started.", "Consultant", "Date", "ISO 8601", "2019-07-01", "Internal", "", ""),
       ("Engagement Effective To", "Date the engagement ended.", "Consultant", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Plan Service Relationship", "Relationships between a retirement plan and its service providers.", [
     ("Plan Service Provider", [
       ("Service Provider", "Party providing services to the plan.", "Retirement Plan", "Reference (Party)", "", "PTY-100990", "DOL Form 5500", "", ""),
       ("Plan Service Role", "Role of the service provider for the plan.", "Retirement Plan", "Code", "Plan Service Role", "Recordkeeper", "DOL Form 5500", "", "Y"),
       ("Schedule C Service Codes", "Service codes reported for the provider on Form 5500 Schedule C.", "Retirement Plan", "Code (multi)", "External (DOL Form 5500)", "15; 64", "DOL Form 5500", "", ""),
       ("Service Effective From", "Date the provider started servicing the plan.", "Retirement Plan", "Date", "ISO 8601", "2023-01-01", "Internal", "", ""),
       ("Service Effective To", "Date the provider stopped servicing the plan.", "Retirement Plan", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Classification & Segmentation", "CC-SEG",
  "Regulatory client classifications, firm-defined segmentation and vendor or industry classifications assigned to parties.",
  [
   ("Regulatory Client Classification", "Classifications that drive regulatory treatment of a party.", [
     ("Regulatory Classification", [
       ("MiFID Client Category", "Client categorisation under MiFID II / UK COBS 3.", "All Parties", "Code", "MiFID Client Category", "Per Se Professional", "MiFID II", "UK FCA COBS", "Y"),
       ("Categorisation Basis", "How the category was reached.", "All Parties", "Code", "Categorisation Basis", "Per Se (Annex II Section I)", "MiFID II", "UK FCA COBS", ""),
       ("Categorisation Date", "Date the client was categorised or last re-categorised.", "All Parties", "Date", "ISO 8601", "2025-11-20", "MiFID II", "", ""),
       ("US Investor Qualification", "Highest US investor qualification evidenced for the party (private fund and offering eligibility).", "All Parties", "Code", "US Investor Qualification", "Qualified Purchaser", "SEC Regulation D", "", "Y"),
       ("FINRA Institutional Investor Indicator", "Whether the party qualifies as an institutional investor for FINRA Rule 2210 communications (institutional communications).", "All Parties", "Boolean", "", "Y", "FINRA Rule 2210", "", "Y", "Drives use of institutional vs retail materials (08 DC)."),
       ("FINRA Institutional Account Indicator", "Whether the account holder meets the FINRA Rule 4512(c) institutional account definition.", "All Parties", "Boolean", "", "Y", "FINRA Rule 4512", "", ""),
       ("Reg BI Retail Customer Indicator", "Whether the party is a retail customer for SEC Regulation Best Interest / Form CRS purposes.", "End Investor", "Boolean", "", "Y", "SEC Reg BI", "", ""),
     ]),
   ]),
   ("Firm-Defined Segmentation", "Segments and tiers assigned by the asset manager to prioritise coverage and service.", [
     ("Segment Assignment", [
       ("Segmentation Scheme", "Segmentation model the assignment belongs to.", "All Parties", "Code", "Segmentation Scheme", "Advisor Value Tier", "Internal", "", ""),
       ("Segment", "Segment or tier assigned.", "All Parties", "Code", "Firm-defined", "Tier A - Strategic", "Internal", "", "Y"),
       ("Assignment Method", "How the segment was assigned.", "All Parties", "Code", "Assignment Method", "Model Score", "Internal", "", ""),
       ("Segment Score", "Numeric score that produced the assignment, where model-based.", "All Parties", "Decimal", "", "87.4", "Internal", "", ""),
       ("Segment Effective From", "Date the assignment took effect.", "All Parties", "Date", "ISO 8601", "2026-07-01", "Internal", "", ""),
       ("Segment Effective To", "Date the assignment ended.", "All Parties", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Vendor & Industry Classification", "Classifications supplied by advisor-data and industry-research vendors, kept alongside internal values.", [
     ("External Classification", [
       ("Classification Vendor", "Vendor or research firm that supplied the classification.", "All Parties", "Code", "Data Vendor", "Broadridge", "Internal", "", ""),
       ("Vendor Channel", "Channel assigned by the vendor (e.g. Discovery Data or Broadridge channel), mapped to the internal Distribution Channel.", "Distributor Firm, Advisor", "Code", "External (Vendor)", "Hybrid RIA", "Discovery Data", "Broadridge", ""),
       ("Vendor Advisor Segment", "Vendor's advisor or practice segment (e.g. persona, propensity or opportunity segment).", "Advisor, Team", "Code", "External (Vendor)", "Model Adopter - Growth", "Broadridge", "", ""),
       ("Vendor Classification As-Of Date", "Date of the vendor file the classification came from.", "All Parties", "Date", "ISO 8601", "2026-08-31", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Contact Points", "CC-CPT",
  "Addresses, email addresses, telephone numbers and digital profiles through which parties can be reached, with usage and verification.",
  [
   ("Postal Address", "Physical and mailing addresses of parties.", [
     ("Contact Point Address", [
       ("Address Usage", "Purpose of the address.", "Contact Point", "Code", "Address Usage", "Branch Office", "Salesforce FSC", "ISO 20022", ""),
       ("Address Line 1", "First line of the street address.", "Contact Point", "Text", "", "200 Harbour Street, Suite 1400", "ISO 20022", "", "", "PII when the address of an individual."),
       ("City", "City or town.", "Contact Point", "Text", "", "Boston", "ISO 20022", "", ""),
       ("Country Subdivision", "State, province or county.", "Contact Point", "Code", "ISO 3166-2", "US-MA", "ISO 20022", "", ""),
       ("Postal Code", "ZIP or postal code.", "Contact Point", "Text", "", "02110", "ISO 20022", "", "", "PII when the address of an individual."),
       ("Country", "Country of the address.", "Contact Point", "Code", "ISO 3166-1 alpha-2", "US", "ISO 20022", "", "Y"),
       ("Geocode", "Latitude and longitude of the address, used for territory alignment.", "Contact Point", "Text", "", "42.3554, -71.0530", "Internal", "", "", "PII when the address of an individual."),
       ("Address Validation Status", "Result of address verification against postal reference data.", "Contact Point", "Code", "Validation Status", "Verified", "Internal", "", ""),
     ]),
   ]),
   ("Electronic & Digital Contact", "Email, telephone and online contact points.", [
     ("Contact Point Email", [
       ("Email Address", "Email address of the party.", "Contact Point", "Text", "Email", "s.okafor@northbridgewealth.example", "Salesforce FSC", "", "Y", "PII"),
       ("Email Deliverability Status", "Deliverability status from validation or bounce handling.", "Contact Point", "Code", "Validation Status", "Verified", "Internal", "", ""),
     ]),
     ("Contact Point Phone", [
       ("Phone Number", "Telephone number in international format.", "Contact Point", "Text", "E.164", "+16175550142", "ITU-T E.164", "Salesforce FSC", "Y", "PII"),
       ("Phone Type", "Type of telephone line.", "Contact Point", "Code", "Phone Type", "Mobile", "Salesforce FSC", "", "", "Mobile numbers are subject to TCPA / PECR rules."),
     ]),
     ("Digital Profile", [
       ("Digital Profile Type", "Type of online profile.", "Contact Point", "Code", "Digital Profile Type", "LinkedIn", "Internal", "", "", "PII"),
       ("Digital Profile URL", "URL of the online profile.", "Contact Point", "Text", "URI", "https://www.linkedin.com/in/example", "Internal", "", "", "PII"),
     ]),
     ("Contact Point Usage", [
       ("Primary Contact Point Indicator", "Whether the contact point is the party's primary one of its type.", "Contact Point", "Boolean", "", "Y", "Salesforce FSC", "", ""),
       ("Contact Point Effective From", "Date the contact point became valid.", "Contact Point", "Date", "ISO 8601", "2024-03-01", "Internal", "", ""),
       ("Contact Point Effective To", "Date the contact point ceased to be valid.", "Contact Point", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Client Onboarding & KYC", "CC-KYC",
  "Onboarding, customer due diligence, beneficial ownership and tax classification for institutional and direct clients. Due diligence on distributors (know-your-distributor) is owned by 08 Distribution Compliance.",
  [
   ("Onboarding Case", "Workflow record for onboarding or periodic review of a client.", [
     ("Onboarding Case", [
       ("Onboarding Case ID", "Identifier of the onboarding or review case.", "Institutional Client", "Identifier", "", "ONB-2026-0412", "Internal", "", ""),
       ("Case Type", "Reason the case was opened.", "Institutional Client", "Code", "KYC Case Type", "New Client Onboarding", "Internal", "FATF", ""),
       ("Case Status", "Current status of the case.", "Institutional Client", "Code", "KYC Case Status", "Approved", "Internal", "", ""),
       ("Case Opened Date", "Date the case was opened.", "Institutional Client", "Date", "ISO 8601", "2026-05-04", "Internal", "", ""),
     ]),
   ]),
   ("Customer Due Diligence", "Risk-based KYC/AML profile of a client.", [
     ("KYC Profile", [
       ("KYC Status", "Overall KYC status of the client.", "Institutional Client, End Investor", "Code", "KYC Status", "Complete", "FATF", "EU AMLD", "Y"),
       ("AML Risk Rating", "Money laundering and terrorist financing risk rating.", "Institutional Client, End Investor", "Code", "AML Risk Rating", "Low", "FATF", "UK MLR 2017", "Y"),
       ("Due Diligence Level", "Level of due diligence applied.", "Institutional Client, End Investor", "Code", "Due Diligence Level", "Simplified", "EU AMLD", "UK MLR 2017", ""),
       ("Nature and Purpose of Relationship", "Documented nature and intended purpose of the business relationship.", "Institutional Client", "Text", "", "Defined benefit plan investing in global equity mandate", "FinCEN CDD Rule", "EU AMLD", ""),
       ("Source of Funds", "Origin of the funds to be invested.", "Institutional Client, End Investor", "Text", "", "Employer and employee pension contributions", "EU AMLD", "UK MLR 2017", "", "PII when the client is an individual."),
       ("PEP Status", "Whether the party or a related individual is a politically exposed person.", "Individual", "Code", "PEP Status", "Not a PEP", "FATF", "EU AMLD", "Y", "PII - restricted"),
       ("Sanctions Screening Result", "Latest outcome of sanctions screening (OFAC, UK, EU, UN lists).", "All Parties", "Code", "Screening Result", "No Match", "OFAC", "EU AMLD", "Y"),
       ("Last Screening Date", "Date of the latest sanctions / PEP / adverse media screening.", "All Parties", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
       ("Next KYC Review Date", "Date the next periodic KYC review is due, driven by risk rating.", "Institutional Client, End Investor", "Date", "ISO 8601", "2029-06-12", "UK MLR 2017", "", ""),
     ]),
     ("Beneficial Ownership", [
       ("Beneficial Owner", "Individual who owns or controls the client entity.", "Institutional Client", "Reference (Party)", "", "PTY-500901", "FinCEN CDD Rule", "EU AMLD", "Y", "PII"),
       ("Beneficial Ownership Percentage", "Percentage of ownership held, directly or indirectly.", "Institutional Client", "Percentage", "", "30%", "FinCEN CDD Rule", "EU AMLD", "", "PII"),
       ("Control Person Indicator", "Whether the individual qualifies under the control prong (significant managerial control).", "Institutional Client", "Boolean", "", "Y", "FinCEN CDD Rule", "", "", "PII"),
     ]),
   ]),
   ("Tax Classification", "FATCA and CRS status and tax documentation of clients.", [
     ("Tax Profile", [
       ("FATCA Status", "FATCA classification of the client.", "Institutional Client, End Investor", "Code", "FATCA Status", "Exempt Beneficial Owner", "FATCA", "IRS", "Y"),
       ("CRS Entity Classification", "OECD Common Reporting Standard classification of an entity client.", "Institutional Client", "Code", "CRS Entity Classification", "Active NFE", "OECD CRS", "", ""),
       ("Tax Residence Countries", "Countries in which the client is resident for tax purposes.", "Institutional Client, End Investor", "Code (multi)", "ISO 3166-1 alpha-2", "US", "OECD CRS", "FATCA", "", "PII when the client is an individual."),
       ("Tax Identification Number", "Tax identification number for each tax residence. Store masked; restrict access.", "Institutional Client, End Investor", "Identifier", "", "XXX-XX-1234 (masked)", "OECD CRS", "IRS", "", "PII - restricted"),
       ("Tax Form Type", "Tax certification held (W-9, W-8BEN-E, CRS self-certification).", "Institutional Client, End Investor", "Code", "Tax Form Type", "W-9", "IRS", "OECD CRS", ""),
       ("GIIN", "FATCA Global Intermediary Identification Number of a financial institution client.", "Institutional Client", "Identifier", "", "98Q96B.00000.LE.250", "FATCA", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Privacy, Consent & Data Governance", "CC-PRV",
  "Privacy status, lawful basis for processing, consent records, data subject requests and retention for personal data held about parties, plus record-level data management metadata. Channel-level marketing subscriptions and preferences are owned by 04 Marketing & Digital and reference this domain.",
  [
   ("Privacy Profile", "Privacy regimes and privacy status applying to a party.", [
     ("Privacy Profile", [
       ("Applicable Privacy Regimes", "Privacy laws that apply to the party's personal data.", "Individual", "Code (multi)", "Privacy Regime", "EU GDPR; CCPA / CPRA", "EU GDPR", "CCPA / CPRA", "Y", "PII"),
       ("Personal Data Categories Held", "Categories of personal data held about the individual.", "Individual", "Code (multi)", "Personal Data Category", "Identity; Professional; Contact; Registration", "EU GDPR", "CCPA / CPRA", "", "PII"),
       ("Sale / Sharing Opt-Out Indicator", "Whether the individual has opted out of sale or sharing of personal information (incl. global privacy control signals).", "Individual", "Boolean", "", "N", "CCPA / CPRA", "US State Privacy Laws", "Y", "PII"),
       ("Processing Restriction Indicator", "Whether processing is restricted or objected to (GDPR Art. 18 / 21).", "Individual", "Boolean", "", "N", "EU GDPR", "UK GDPR", "", "PII"),
       ("Do Not Contact Indicator", "Whether the individual must not be contacted for any non-mandatory purpose (global suppression).", "Individual", "Boolean", "", "N", "Internal", "EU GDPR", "Y", "PII. Overrides 04 MK channel preferences."),
     ]),
   ]),
   ("Lawful Basis & Consent", "Lawful basis for each processing purpose, and the consent records that evidence consent where it is the basis.", [
     ("Processing Legal Basis", [
       ("Processing Purpose", "Purpose for which personal data is processed.", "Individual", "Code", "Processing Purpose", "Relationship Management", "EU GDPR", "", "", "PII"),
       ("Lawful Basis", "GDPR Article 6 lawful basis relied on for the purpose.", "Individual", "Code", "Lawful Basis", "Legitimate Interests", "EU GDPR", "UK GDPR", "Y", "PII"),
       ("Legitimate Interests Assessment Reference", "Reference to the documented LIA where legitimate interests is relied on.", "Individual", "Text", "", "LIA-INT-2025-03", "UK GDPR", "", ""),
       ("Legal Basis Effective From", "Date the basis began to apply.", "Individual", "Date", "ISO 8601", "2025-01-15", "Internal", "", ""),
       ("Legal Basis Effective To", "Date the basis stopped applying.", "Individual", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Consent Record", [
       ("Consent Purpose", "Processing purpose consented to.", "Individual", "Code", "Processing Purpose", "Direct Marketing", "EU GDPR", "Salesforce FSC", "", "PII"),
       ("Consent Status", "Current status of the consent.", "Individual", "Code", "Consent Status", "Granted", "EU GDPR", "Salesforce FSC", "Y", "PII"),
       ("Consent Captured Timestamp", "When consent was given.", "Individual", "Timestamp", "ISO 8601", "2026-02-10T14:22:05Z", "EU GDPR", "", "", "PII"),
       ("Consent Capture Method", "How consent was captured.", "Individual", "Code", "Consent Capture Method", "Web Form - Double Opt-In", "EU GDPR", "", "", "PII"),
       ("Consent Evidence Reference", "Pointer to the stored evidence (form version, wording, IP / log).", "Individual", "Text", "", "evidence://consent/2026/02/10/7781", "EU GDPR", "", "", "PII"),
       ("Consent Withdrawn Timestamp", "When consent was withdrawn.", "Individual", "Timestamp", "ISO 8601", "", "EU GDPR", "", "", "PII"),
     ]),
   ]),
   ("Data Subject Rights", "Requests from individuals exercising privacy rights.", [
     ("Data Subject Request", [
       ("Request Type", "Right being exercised.", "Individual", "Code", "Data Subject Request Type", "Access", "EU GDPR", "CCPA / CPRA", "Y", "PII"),
       ("Statutory Due Date", "Date by which the response is legally due (one month GDPR; 45 days CCPA, subject to extension).", "Individual", "Date", "ISO 8601", "2026-10-02", "EU GDPR", "CCPA / CPRA", "", "PII"),
       ("Request Status", "Status of the request.", "Individual", "Code", "Data Subject Request Status", "In Progress", "Internal", "", "", "PII"),
     ]),
     ("Retention", [
       ("Retention Category", "Retention schedule category applied to the party's records.", "All Parties", "Code", "Firm-defined", "Distributor Contact - 6 years after last activity", "Internal", "", ""),
       ("Scheduled Erasure Date", "Date the personal data is due for deletion or anonymisation.", "All Parties", "Date", "ISO 8601", "2032-01-31", "EU GDPR", "", "", "PII"),
       ("Legal Hold Indicator", "Whether deletion is suspended due to litigation, investigation or regulatory hold.", "All Parties", "Boolean", "", "N", "Internal", "", ""),
     ]),
   ]),
   ("Data Management Metadata", "Metadata applied to every record in the client & customer domain.", [
     ("Record Metadata", [
       ("Data Owner", "Business role accountable for the data element.", "All", "Reference (Party)", "", "Head of Distribution Operations", "DCAM (EDM Council)", "", ""),
       ("Data Steward", "Role responsible for day-to-day data quality.", "All", "Reference (Party)", "", "Client Data Steward", "DCAM (EDM Council)", "", ""),
       ("System of Record", "System holding the authoritative value.", "All", "Code", "Firm-defined", "CRM", "Internal", "", ""),
       ("Source System", "System from which the record version was received.", "All", "Code", "Firm-defined", "Discovery Data Feed", "Internal", "", ""),
       ("Source System Record ID", "Identifier of the record in the source system.", "All", "Identifier", "", "0015g00000XyZ12AAB", "Internal", "", ""),
       ("Match Confidence Score", "Confidence of the entity-resolution match that linked the source record to the golden party.", "All", "Decimal", "", "0.97", "Internal", "", ""),
       ("Record Effective From", "Business-effective start date of the record version.", "All", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Record Effective To", "Business-effective end date of the record version.", "All", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Last Updated Timestamp", "System timestamp of the last change.", "All", "Timestamp", "ISO 8601", "2026-09-30T17:45:00Z", "Internal", "", ""),
       ("Data Quality Status", "Validation status of the record.", "All", "Code", "Data Quality Status", "Validated", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Party Type": ("FIBO BE", [("Organisation","Legal entity, branch, team, plan or other formal organisation"),("Individual","Natural person")]),
 "Party Status": ("Internal", [("Active",""),("Inactive","No current role or relationship"),("Pending Verification","Created but not yet validated"),("Merged","Duplicate merged into surviving record"),("Dissolved / Deceased",""),("Blocked","Do not transact / sanctions or compliance hold")]),
 "Relationship Stage": ("Internal / Salesforce FSC", [("Suspect","Identified in vendor data, not yet qualified"),("Prospect","Qualified, no assets or business"),("Client","Holds assets or has transacted"),("Former Client","Previously a client; no current assets"),("Influencer Only","Consultant, gatekeeper or other non-investing party")]),
 "Party Origin": ("Internal", [("Regulatory Register - FINRA CRD",""),("Regulatory Register - SEC IAPD",""),("Regulatory Register - FCA",""),("GLEIF",""),("Vendor Feed - Discovery Data",""),("Vendor Feed - Broadridge",""),("Vendor Feed - FINTRX",""),("Intermediary Feed","TA, sub-TA or platform data"),("DOL Form 5500",""),("Onboarding",""),("Manual - Sales",""),("Web / Marketing","Created from 04 MK lead or registration")]),
 "Organisation Type": ("Internal (aligned to FIBO FBC)", [("Broker-Dealer",""),("Registered Investment Adviser",""),("Bank / Trust Company",""),("Private Bank",""),("Insurance Company",""),("Independent Financial Adviser Firm","UK / EU"),("Discretionary Fund Manager","UK / EU"),("Investment Platform / Fund Supermarket",""),("TAMP","Turnkey asset management programme"),("Recordkeeper / TPA",""),("Investment Consultant / OCIO",""),("Pension Plan / Scheme",""),("Endowment / Foundation",""),("Sovereign / Public Entity",""),("Family Office",""),("Corporate",""),("Fund / Collective Investment Vehicle",""),("Other","")]),
 "Regulator": ("Internal", [("SEC",""),("FINRA",""),("State Securities Regulator",""),("OCC",""),("Federal Reserve",""),("DOL / EBSA",""),("State Insurance Regulator",""),("UK FCA",""),("UK PRA",""),("CSSF","Luxembourg"),("Central Bank of Ireland",""),("BaFin","Germany"),("AMF","France"),("Other EU NCA","")]),
 "Parent Relationship Basis": ("GLEIF LEI-CDF (Level 2)", [("Accounting Consolidation","Parent consolidates the entity in its financial statements"),("Majority Ownership",""),("Control (Non-Ownership)",""),("Fund Management","Fund managed by another entity"),("Unknown","")]),
 "Party Role Type": ("Internal (aligned to FIBO BE / BIAN)", [("Distributor Firm","Broker-dealer, RIA, bank, IFA firm, platform, TAMP"),("Division / Home Office",""),("Region / Complex",""),("Branch / Office",""),("Advisor Team",""),("Financial Advisor","RR, IAR, IFA, private banker, plan advisor"),("Gatekeeper / Research",""),("Home Office Contact","Product, marketing, operations"),("Institutional Client",""),("Investment Consultant / OCIO",""),("Plan Sponsor",""),("Retirement Plan",""),("Recordkeeper",""),("Third-Party Administrator",""),("Custodian",""),("Clearing Firm",""),("Sub-Accounting Provider",""),("End Investor",""),("Household",""),("Beneficial Owner / Controller",""),("Fund Service Provider","Party referenced by 01 Product party roles")]),
 "Role Status": ("Internal", [("Active",""),("Inactive",""),("Pending","")]),
 "Identifier Scheme": ("ISO 20022 / Internal", [("LEI","ISO 17442"),("BIC","ISO 9362"),("FINRA CRD - Firm",""),("FINRA CRD - Individual",""),("FINRA CRD - Branch",""),("SEC File Number",""),("SEC CIK",""),("EIN",""),("EIN + Plan Number","US retirement plan"),("NPN","NIPR"),("NSCC Participant Number",""),("TA Dealer Number",""),("FCA FRN",""),("FCA IRN",""),("EU NCA Register ID",""),("Company Registration Number",""),("TPR Pension Scheme Registry Number",""),("GIIN","FATCA"),("Vendor ID",""),("CRM ID","")]),
 "Identifier Status": ("Internal", [("Active",""),("Inactive",""),("Retired","Superseded or no longer issued"),("Unverified","")]),
 "LEI Registration Status": ("GLEIF LEI-CDF 3.1", [("PENDING_VALIDATION",""),("ISSUED",""),("LAPSED","Not renewed"),("MERGED",""),("RETIRED",""),("ANNULLED",""),("DUPLICATE",""),("TRANSFERRED",""),("PENDING_TRANSFER",""),("PENDING_ARCHIVAL","")]),
 "LEI Entity Category": ("GLEIF LEI-CDF 3.1", [("GENERAL",""),("BRANCH",""),("FUND","Managed by another legal entity"),("SOLE_PROPRIETOR",""),("RESIDENT_GOVERNMENT_ENTITY",""),("INTERNATIONAL_ORGANIZATION","")]),
 "Data Vendor": ("Internal", [("Discovery Data",""),("Broadridge",""),("FINTRX",""),("Cerulli",""),("Morningstar",""),("eVestment / Nasdaq",""),("Other","")]),
 "Distribution Channel": ("Internal (Cerulli-style channel scheme)", [("Wirehouse",""),("National / Regional Broker-Dealer",""),("Independent Broker-Dealer",""),("Insurance Broker-Dealer",""),("Bank Broker-Dealer",""),("Dually Registered / Hybrid RIA",""),("Independent RIA",""),("Private Bank / Trust Company",""),("Family Office",""),("TAMP / Model Platform",""),("Retirement Recordkeeper / DCIO",""),("UK IFA / Network",""),("UK / EU Discretionary Fund Manager",""),("Fund Platform / Supermarket","UK / EU"),("EU Bank Distributor",""),("Institutional Direct",""),("Investment Consultant","")]),
 "Firm Registration Type": ("SEC / FINRA / UK FCA", [("Broker-Dealer (FINRA Member)",""),("SEC-Registered Investment Adviser",""),("State-Registered Investment Adviser",""),("Dual Registrant (BD + RIA)",""),("Exempt Reporting Adviser",""),("Bank (Exempt)",""),("FCA Authorised Firm",""),("FCA Appointed Representative",""),("EU MiFID Investment Firm",""),("EU Credit Institution",""),("Unregulated","")]),
 "Platform Offering": ("Internal", [("Mutual Funds",""),("ETFs",""),("SMA",""),("UMA",""),("Model Portfolios",""),("CITs",""),("Interval / Tender-Offer Funds",""),("Private / Alternative Funds",""),("Annuities",""),("UCITS / OEICs","UK / EU")]),
 "Firm Operating Model": ("Internal (Cerulli-style)", [("Centralised Research / Approved List","Home office controls product access"),("Centralised Models","Home office models dominate assets"),("Advisor Discretion","Advisors select from broad shelf"),("Outsourced (TAMP / OCIO)","")]),
 "ADV Client Type": ("SEC Form ADV Part 1A Item 5.D", [("Individuals (other than HNW)",""),("High Net Worth Individuals",""),("Banking or Thrift Institutions",""),("Investment Companies",""),("Business Development Companies",""),("Pooled Investment Vehicles",""),("Pension and Profit Sharing Plans",""),("Charitable Organisations",""),("State or Municipal Government Entities",""),("Other Investment Advisers",""),("Insurance Companies",""),("Sovereign Wealth Funds and Foreign Official Institutions",""),("Corporations or Other Businesses",""),("Other","")]),
 "ADV Compensation Type": ("SEC Form ADV Part 1A Item 5.E", [("Percentage of AUM",""),("Hourly Charges",""),("Subscription Fees",""),("Fixed Fees",""),("Commissions",""),("Performance-Based Fees",""),("Other","")]),
 "Hierarchy Type": ("Internal", [("Regulatory (CRD)","Firm and branch structure as registered"),("Firm Operational","Divisions, regions, complexes as the firm runs them"),("Vendor - Broadridge",""),("Vendor - Discovery Data",""),("Asset Manager Coverage","Hierarchy used for internal reporting; alignment to territories in 07 CT")]),
 "Hierarchy Level": ("Internal", [("Firm",""),("Division / Home Office",""),("Region",""),("Complex / Market",""),("Branch / Office",""),("Team","")]),
 "Branch Type": ("FINRA Form BR / Rule 3110", [("Main Office",""),("OSJ Branch","Office of Supervisory Jurisdiction"),("Non-OSJ Branch",""),("Non-Branch Location","e.g. primary residence, temporary location"),("Non-Registered Office","UK / EU or RIA-only office")]),
 "Gatekeeper Function": ("Internal", [("Manager Research / Due Diligence",""),("CIO / Model Portfolio Management",""),("Product Management / Shelf",""),("Platform / Advisory Programme Management",""),("Retirement / DCIO Programme",""),("Alternatives Platform",""),("Home Office Marketing / Sales Desk",""),("Operations / Product Onboarding","")]),
 "Decision Authority": ("Internal", [("Approver","Final approval authority"),("Recommender",""),("Influencer",""),("Operational Only","")]),
 "Asset Class Coverage": ("Internal (aligned to 01 Product Asset Class)", [("US Equity",""),("Global Equity",""),("Emerging Markets",""),("Fixed Income",""),("Multi-Asset",""),("Alternatives",""),("Private Credit",""),("Private Equity",""),("Real Assets",""),("ESG / Sustainable","")]),
 "Professional Type": ("FINRA CRD / UK FCA / Internal", [("Registered Representative",""),("Investment Adviser Representative",""),("Dually Registered (RR + IAR)",""),("Insurance Producer",""),("Private Banker / Relationship Manager",""),("Trust Officer",""),("Plan Advisor",""),("UK IFA",""),("Discretionary Portfolio Manager",""),("Paraplanner / Associate","")]),
 "Professional Designation": ("Internal", [("CFP",""),("CFA",""),("ChFC",""),("CIMA",""),("CPWA",""),("CRPS",""),("AIF",""),("CPA / PFS",""),("Chartered Financial Planner","UK CII"),("Certified Financial Planner (UK)",""),("CISI Chartered Wealth Manager","")]),
 "Qualification Exam": ("FINRA / NASAA", [("SIE",""),("Series 6",""),("Series 7",""),("Series 63",""),("Series 65",""),("Series 66",""),("Series 24",""),("Series 9 / 10",""),("Series 26","")]),
 "Registration Status": ("FINRA CRD / SEC IAPD", [("Active - BD",""),("Active - IA",""),("Active - BD and IA",""),("Previously Registered",""),("Barred / Suspended","")]),
 "UK Certification Status": ("UK FCA SM&CR", [("Senior Manager",""),("Certified - SPS Held",""),("Certified",""),("Conduct Rules Staff Only",""),("Not Applicable","")]),
 "Advisor Business Model": ("Internal (Cerulli-style)", [("Wirehouse FA",""),("Regional BD Advisor",""),("Independent BD Advisor",""),("Hybrid RIA Advisor",""),("Independent RIA Advisor",""),("Bank Advisor",""),("Insurance Agent / Advisor",""),("Private Banker",""),("UK IFA",""),("Retirement Plan Specialist","")]),
 "Revenue Model": ("Internal", [("Fee-Based","Predominantly advisory fees"),("Commission-Based",""),("Hybrid (Fee and Commission)",""),("Salaried","")]),
 "Investment Management Style": ("Internal (Cerulli-style)", [("Rep as Portfolio Manager","Advisor selects securities/funds with discretion"),("Rep as Advisor","Non-discretionary recommendations"),("Model User","Uses home-office or third-party models"),("Outsourcer","TAMP / OCIO / SMA manager")]),
 "Client Niche": ("Internal", [("Mass Affluent",""),("High Net Worth",""),("Ultra High Net Worth",""),("Pre-Retirees / Retirees",""),("Business Owners",""),("Corporate Executives",""),("Retirement Plans",""),("Foundations / Non-Profits",""),("Medical Professionals","")]),
 "Affiliation Type": ("FINRA CRD / UK FCA", [("Employee",""),("Independent Contractor",""),("Appointed Representative","UK"),("Investment Adviser Representative Only",""),("Outside Business Activity","")]),
 "Affiliation Change Reason": ("Internal", [("Moved to Another Firm",""),("Breakaway to Independent RIA",""),("Joined Hybrid / Independent BD",""),("Team Lift-Out",""),("Firm Merger / Acquisition",""),("Retirement",""),("Terminated",""),("Left Industry",""),("Deceased","")]),
 "Institutional Client Type": ("Internal (aligned to SEC Form ADV Item 5.D)", [("Corporate DB Plan",""),("Corporate DC Plan",""),("Public Pension Plan",""),("Taft-Hartley / Multiemployer Plan",""),("Endowment",""),("Foundation",""),("Healthcare System",""),("Insurance Company - General Account",""),("Sovereign Wealth Fund",""),("Central Bank / Official Institution",""),("Family Office",""),("Corporate Treasury",""),("UK DB Scheme",""),("UK DC / Master Trust",""),("UK Local Government Pension Scheme Pool",""),("Other","")]),
 "Governance Model": ("Internal", [("Internal CIO / Staff",""),("Investment Committee with Consultant",""),("Board / Trustees with Consultant",""),("Fully Delegated (OCIO / Fiduciary Manager)","")]),
 "Consultant Type": ("Internal", [("Full-Service Investment Consultant",""),("OCIO / Fiduciary Manager",""),("Specialist Consultant","e.g. alternatives, DC"),("Retirement Plan Consultant",""),("Actuarial / Benefits Consultant","")]),
 "Retirement Plan Type": ("DOL Form 5500 / UK", [("401(k)",""),("403(b)",""),("457(b)",""),("Profit Sharing",""),("Money Purchase",""),("Defined Benefit",""),("Cash Balance",""),("Pooled Employer Plan (PEP)",""),("UK DC Trust-Based",""),("UK Master Trust",""),("UK Group Personal Pension",""),("UK DB Scheme","")]),
 "QDIA Type": ("ERISA (29 CFR 2550.404c-5)", [("Target Date Fund",""),("Balanced Fund",""),("Managed Account",""),("Capital Preservation (120-day)",""),("None","")]),
 "ERISA Fiduciary Type": ("ERISA", [("3(21) Co-Fiduciary",""),("3(38) Investment Manager",""),("Non-Fiduciary Broker",""),("3(16) Administrator","")]),
 "Recordkeeper Model": ("Internal", [("Bundled / Proprietary",""),("Open Architecture",""),("Insurance Group Annuity",""),("TPA Alliance","")]),
 "Plan Market Segment": ("Internal", [("Micro","< USD 5m"),("Small","USD 5m - 50m"),("Mid","USD 50m - 250m"),("Large","USD 250m - 1bn"),("Mega","> USD 1bn")]),
 "Investor Type": ("Internal", [("Individual",""),("Joint",""),("Trust",""),("Estate",""),("Corporate",""),("Charity / Non-Profit",""),("Plan Participant",""),("Minor (Custodial)","")]),
 "Look-Through Data Basis": ("Internal", [("Direct Registered","Investor known to the TA by name"),("Networked - Identified","Identity shared via networking file"),("Pseudonymised (Intermediary Token)","Stable token, no direct identifiers"),("Aggregated Only","No investor-level data held")]),
 "Age Band": ("Internal", [("Under 35",""),("35-44",""),("45-54",""),("55-64",""),("65-74",""),("75+",""),("Unknown","")]),
 "Wealth Tier": ("Internal (Cerulli-style)", [("Mass Market","< USD 100k"),("Mass Affluent","USD 100k - 1m"),("High Net Worth","USD 1m - 5m"),("Very High Net Worth","USD 5m - 30m"),("Ultra High Net Worth","> USD 30m")]),
 "Account Type": ("Internal / DTCC Networking", [("Direct Investor Account","Held directly at TA"),("Networked Investor Account","Held via NSCC Networking"),("Omnibus Account","Single TA account aggregating many investors"),("Sub-Account","Underlying position within an omnibus"),("Plan Account","Retirement plan level"),("Institutional Fund Account",""),("Separate Account","Linked to a mandate"),("Model / SMA Program Account",""),("Platform / Nominee Account","UK / EU")]),
 "Account Registration Type": ("Internal / Salesforce FSC", [("Individual",""),("Joint Tenants (JTWROS)",""),("Tenants in Common",""),("Revocable Trust",""),("Irrevocable Trust",""),("Traditional IRA",""),("Roth IRA",""),("Rollover IRA",""),("SEP / SIMPLE IRA",""),("UTMA / UGMA",""),("529 Plan",""),("Corporate",""),("Partnership / LLC",""),("Estate",""),("Retirement Plan Trust",""),("ISA","UK"),("SIPP","UK"),("General Investment Account","UK"),("Nominee","UK / EU")]),
 "Account Status": ("Internal", [("Pending",""),("Open",""),("Dormant",""),("Restricted","e.g. escheatment, legal hold, KYC"),("Closed","")]),
 "Networking Level": ("DTCC / NSCC Networking (verify definitions with TA)", [("Level 0","Fund/TA maintains the account and investor servicing; intermediary has limited control"),("Level 1","Shared control; fund/TA services account and investor communications"),("Level 3","Intermediary controls the account and assumes defined servicing; fund retains tax reporting / statements per matrix"),("Level 4","Intermediary controls and fully services the account; fund has no direct investor contact")]),
 "Account Role Type": ("Salesforce FSC / ISO 20022", [("Primary Owner",""),("Joint Owner",""),("Trustee",""),("Beneficiary",""),("Custodian (UTMA)",""),("Power of Attorney",""),("Authorised Signatory",""),("Plan Sponsor",""),("Rep of Record",""),("Dealer of Record","")]),
 "Party Relationship Type": ("Internal (aligned to Salesforce FSC / BIAN)", [("Advises","Advisor to end investor"),("Employs","Firm to individual; detail held in Employment Affiliation"),("Member Of","Individual to team or household"),("Consults For","Consultant to institutional client"),("Services Plan","Provider to retirement plan"),("Sponsors","Employer to plan"),("Custodies For",""),("Clears For","Clearing firm to introducing BD"),("Subsidiary Of",""),("Refers / Introduces",""),("Spouse / Partner Of",""),("Assistant To","")]),
 "Household Member Role": ("Salesforce FSC", [("Head of Household",""),("Spouse / Partner",""),("Dependant",""),("Other Family Member",""),("Trust / Entity","")]),
 "Team Member Role": ("Internal", [("Team Lead",""),("Senior Partner",""),("Partner",""),("Junior Advisor",""),("Client Service Associate",""),("Analyst / Portfolio Specialist","")]),
 "Consulting Engagement Type": ("Internal", [("Non-Discretionary General Consultant",""),("Discretionary OCIO",""),("Specialist / Asset-Class Consultant",""),("Manager Search Only",""),("DC Plan Consultant","")]),
 "Plan Service Role": ("DOL Form 5500 Schedule C / Internal", [("Recordkeeper",""),("Third-Party Administrator",""),("Plan Advisor / Broker",""),("3(38) Investment Manager",""),("Directed Trustee",""),("Custodian",""),("Auditor",""),("Actuary","")]),
 "MiFID Client Category": ("MiFID II Annex II / UK FCA COBS 3", [("Retail Client",""),("Per Se Professional",""),("Elective Professional","Opted up from retail"),("Eligible Counterparty",""),("Elective Eligible Counterparty","")]),
 "Categorisation Basis": ("MiFID II / UK FCA COBS 3", [("Per Se (Annex II Section I)",""),("Opt-Up (Annex II Section II)","Qualitative and quantitative tests"),("Opt-Down","Professional treated as retail at own request"),("Default Retail","")]),
 "US Investor Qualification": ("SEC / ICA 1940", [("None Evidenced",""),("Accredited Investor","Reg D Rule 501(a)"),("Qualified Client","Advisers Act Rule 205-3"),("Qualified Purchaser","ICA s.2(a)(51)"),("Qualified Institutional Buyer","Rule 144A")]),
 "Segmentation Scheme": ("Internal", [("Advisor Value Tier",""),("Advisor Growth Potential",""),("Institutional Priority",""),("DCIO Plan Advisor Tier",""),("Service Model","")]),
 "Assignment Method": ("Internal", [("Rule-Based",""),("Model Score",""),("Manual Override",""),("Vendor-Supplied","")]),
 "Address Usage": ("Salesforce FSC / ISO 20022", [("Registered Office",""),("Headquarters",""),("Branch Office",""),("Mailing",""),("Residential",""),("Billing","")]),
 "Validation Status": ("Internal", [("Verified",""),("Unverified",""),("Invalid",""),("Bounced / Returned","")]),
 "Phone Type": ("Internal", [("Office",""),("Direct",""),("Mobile",""),("Assistant",""),("Fax","")]),
 "Digital Profile Type": ("Internal", [("LinkedIn",""),("X / Twitter",""),("Practice Website",""),("Other","")]),
 "KYC Case Type": ("Internal", [("New Client Onboarding",""),("Periodic Review",""),("Trigger Event Review","Ownership change, adverse media, screening hit"),("Remediation","")]),
 "KYC Case Status": ("Internal", [("Open",""),("Awaiting Client Documents",""),("Under Review",""),("Escalated",""),("Approved",""),("Rejected",""),("Withdrawn","")]),
 "KYC Status": ("Internal", [("Not Started",""),("In Progress",""),("Complete",""),("Expired","Review overdue"),("Failed","")]),
 "AML Risk Rating": ("FATF risk-based approach", [("Low",""),("Medium",""),("High",""),("Prohibited","")]),
 "Due Diligence Level": ("EU AMLD / UK MLR 2017", [("Simplified",""),("Standard",""),("Enhanced","")]),
 "PEP Status": ("FATF / EU AMLD", [("Not a PEP",""),("Domestic PEP",""),("Foreign PEP",""),("International Organisation PEP",""),("Family Member / Close Associate",""),("Former PEP","")]),
 "Screening Result": ("Internal", [("No Match",""),("Potential Match - Under Review",""),("False Positive",""),("True Match","")]),
 "FATCA Status": ("FATCA / IRS W-8BEN-E", [("US Person",""),("Exempt Beneficial Owner",""),("Participating FFI",""),("Registered Deemed-Compliant FFI",""),("Active NFFE",""),("Passive NFFE",""),("Non-Participating FFI","")]),
 "CRS Entity Classification": ("OECD CRS", [("Financial Institution - Investment Entity",""),("Financial Institution - Other",""),("Active NFE",""),("Passive NFE",""),("Government / International Organisation","")]),
 "Tax Form Type": ("IRS / OECD CRS", [("W-9",""),("W-8BEN",""),("W-8BEN-E",""),("W-8IMY",""),("W-8EXP",""),("CRS Self-Certification - Individual",""),("CRS Self-Certification - Entity","")]),
 "Privacy Regime": ("Internal", [("EU GDPR",""),("UK GDPR / DPA 2018",""),("CCPA / CPRA","California"),("Other US State Privacy Law","e.g. VA, CO, CT, TX"),("GLBA","US financial privacy"),("Swiss FADP","")]),
 "Personal Data Category": ("Internal / CCPA categories", [("Identity",""),("Contact",""),("Professional / Employment",""),("Registration / Licensing",""),("Financial",""),("Government Identifier","Sensitive under CPRA"),("Online Identifiers / Engagement",""),("Inferences / Segmentation","")]),
 "Processing Purpose": ("Internal (GDPR Art. 5(1)(b))", [("Relationship Management",""),("Direct Marketing","Channel preferences in 04 MK"),("Regulatory Compliance","KYC/AML, tax, recordkeeping"),("Sales Attribution and Compensation","06 TX / 07 CT"),("Analytics and Segmentation",""),("Event Management","04 MK")]),
 "Lawful Basis": ("GDPR Article 6(1)", [("Consent","Art. 6(1)(a)"),("Contract","Art. 6(1)(b)"),("Legal Obligation","Art. 6(1)(c)"),("Vital Interests","Art. 6(1)(d)"),("Public Task","Art. 6(1)(e)"),("Legitimate Interests","Art. 6(1)(f)")]),
 "Consent Status": ("Internal / Salesforce consent model", [("Granted",""),("Withdrawn",""),("Expired",""),("Not Sought","")]),
 "Consent Capture Method": ("Internal", [("Web Form - Single Opt-In",""),("Web Form - Double Opt-In",""),("Event Registration",""),("Paper Form",""),("Verbal - Recorded",""),("Intermediary-Captured","")]),
 "Data Subject Request Type": ("GDPR Arts. 15-22 / CCPA", [("Access",""),("Rectification",""),("Erasure",""),("Restriction",""),("Portability",""),("Objection",""),("Opt-Out of Sale / Sharing","CCPA"),("Limit Use of Sensitive PI","CPRA")]),
 "Data Subject Request Status": ("Internal", [("Received",""),("Identity Verification",""),("In Progress",""),("Extended",""),("Completed",""),("Rejected","")]),
 "Data Quality Status": ("Internal", [("Validated",""),("Pending Validation",""),("Exception",""),("Deprecated","")]),
}

# ---------------------------------------------------------------------------
# Relationships, sources
# ---------------------------------------------------------------------------
REL = [
 ("Party","plays","Party Role","1 : 1..n","Effective-dated; one party can hold many roles (e.g. an RIA as distributor and model sponsor)."),
 ("Party","is identified by","Party Identifier","1 : 0..n","LEI, CRD, FRN/IRN, SEC file number, EIN, vendor IDs."),
 ("Organisation","is consolidated by","Organisation (Direct / Ultimate Parent)","n : 0..1","GLEIF Level 2 where available."),
 ("Hierarchy Node (Party)","is child of","Hierarchy Node (Party)","n : 0..1","Per Hierarchy Type: firm > division/home office > region > branch > team."),
 ("Financial Professional","is affiliated with","Distributor Firm / Branch (Employment Affiliation)","1 : 1..n","Firm-employs-advisor; history preserved for advisor moves."),
 ("Financial Professional","is member of","Advisor Team (Team Membership)","n : 0..n",""),
 ("Individual","is member of","Household","n : 0..n",""),
 ("Investment Consultant","advises","Institutional Client / Retirement Plan","n : n","Via Consultant Advisory Relationship."),
 ("Retirement Plan","is sponsored by","Plan Sponsor (Organisation)","n : 1","Identified by Sponsor EIN + Plan Number."),
 ("Retirement Plan","is serviced by","Recordkeeper / TPA / Plan Advisor (Plan Service Provider)","1 : 1..n",""),
 ("Account","has","Account Party Role","1 : 1..n","Owner, dealer/branch/rep of record, plan sponsor, trustee."),
 ("Sub-Account","rolls up to","Omnibus Account","n : 1",""),
 ("Party","is assigned","Segment Assignment / External Classification","1 : 0..n","Effective-dated."),
 ("Party","is reached via","Contact Point (Address / Email / Phone / Digital)","1 : 0..n",""),
 ("Party","has","KYC Profile / Tax Profile","1 : 0..1","Direct clients and institutional clients only."),
 ("Institutional Client","is owned / controlled by","Beneficial Owner (Individual)","1 : 0..n",""),
 ("Individual","is processed under","Processing Legal Basis / Consent Record","1 : 0..n",""),
 ("Account","holds","Position (06 TX, POS-) / Transaction (06 TX, TXN-)","1 : 0..n","Cross-domain: holdings, flows and AUM attribution owned by 06 TX."),
 ("Account (Separate Account)","is managed under","Investment Mandate (01 Product, MND-)","n : 0..1","Cross-domain."),
 ("Distributor Firm / Retirement Plan","is party to","Agreement (05 DA, AGR-)","1 : 0..n","Cross-domain: selling, platform, DCIO and networking agreements; shelf status by partner owned by 05 DA."),
 ("Party (Firm / Branch / Advisor / Institutional Client)","is covered by","Employee (03 Sales, EMP-) via Coverage Assignment (07 CT)","n : n","Cross-domain: coverage and territory alignment owned by 07 CT."),
 ("Branch / Advisor (via Contact Point Address)","is aligned to","Territory (07 CT, TER-)","n : 1","Cross-domain: alignment rules owned by 07 CT."),
 ("Party","is subject of","Activity / Opportunity (03 Sales, ACT- / OPP-)","1 : 0..n","Cross-domain."),
 ("Individual","has","Marketing Subscription / Preference (04 MK)","1 : 0..n","Cross-domain: 04 MK preferences must respect CC Lawful Basis, Consent and Do Not Contact."),
 ("Distributor Firm","is subject of","Distributor Due Diligence (08 DC, DDQ-)","1 : 0..n","Cross-domain: know-your-distributor owned by 08 DC."),
 ("Party","is referenced by","Product Party Role / Model Sponsor (01 Product)","1 : 0..n","Cross-domain: 01 Product references parties by PTY- ID."),
]

SRC = [
 ("FIBO - Business Entities (BE) and Financial Business & Commerce (FBC)","EDM Council","https://spec.edmcouncil.org/fibo/","Open (MIT licence)","Ontology of legal persons, formal organisations, ownership and control, registration authorities and regulated financial entities","Conceptual backbone: Party, Organisation, Individual, Legal Entity Hierarchy, Party Role", ["FIBO*"]),
 ("GLEIF LEI-CDF 3.1 and Level 2 relationship data; ISO 17442","GLEIF; ISO","https://www.gleif.org/en/about-lei/common-data-file-format/lei-cdf-format","Open data (CC0)","LEI Level 1 reference data (legal name, jurisdiction, legal form, registration status, entity category, registration authority) and Level 2 parent relationships","Organisation, Legal Entity Hierarchy, LEI Record", ["GLEIF*", "ISO 17442*"]),
 ("ISO 20275 Entity Legal Forms (ELF)","ISO; GLEIF","https://www.gleif.org/en/about-lei/code-lists/iso-20275-entity-legal-forms-code-list","Open code list","Codes for legal forms by jurisdiction","Legal Form", ["ISO 20275"]),
 ("ISO 20022 party components (PartyIdentification, PostalAddress) and ISO 9362 BIC","ISO; SWIFT","https://www.iso20022.org","Free standard","Party identification structures (LEI, BIC, generic organisation identification) and structured postal address","Identifier Register, Postal Address, Account Party Role", ["ISO 20022", "ISO 9362"]),
 ("BIAN Party Reference Data Directory","BIAN","https://bian.org/semantic-apis/party-reference-data-directory/","Free (registration)","Service domain for party reference details, contacts, associations and demographics","Cross-check for Party core, Party Role and Party Relationship (secondary reference)", []),
 ("Salesforce Financial Services Cloud data model (Account, Contact, Person Account, Account Contact Relationship, Party Relationship Group, Financial Account, Contact Point and consent objects)","Salesforce","https://developer.salesforce.com/docs/platform/data-models/guide/fsc-customer.html","Vendor documentation","CRM party, household, relationship, financial account and contact point/consent model","Households, Party Relationships, Account Party Role, Contact Points, Consent Record", ["Salesforce FSC"]),
 ("Microsoft Cloud for Financial Services - banking and wealth management data model","Microsoft","https://learn.microsoft.com/industry/financial-services/","Vendor documentation","Common data model for customers, relationships, holdings and households","Cross-check for party and household model (not used as primary)", []),
 ("FINRA CRD, BrokerCheck, Form BR and Forms U4/U5","FINRA","https://www.finra.org/registration-exams-ce","Public register / regulatory forms","Firm, branch and individual registration, exams, employment history and disclosures","US Regulatory Identifiers, Branch / Office, Financial Professional, Employment Affiliation", ["FINRA*"]),
 ("SEC Form ADV, IAPD and Form BD","US SEC","https://adviserinfo.sec.gov","Public register / regulatory forms","RIA registration, regulatory AUM, client types, compensation, custodians; BD registration","Form ADV Profile, Firm Registration Type, US Regulatory Identifiers", ["SEC*"]),
 ("FCA Financial Services Register and SM&CR","UK FCA","https://register.fca.org.uk","Public register (API available)","Firm Reference Numbers, Individual Reference Numbers, approved and certified persons, appointed representatives","UK & EU Regulatory Identifiers, UK Certification Status", ["UK FCA Register", "UK FCA SM&CR"]),
 ("FCA Handbook COBS 3 and MiFID II Annex II (client categorisation)","UK FCA; European Union","https://www.handbook.fca.org.uk/handbook/COBS/3/","Regulation","Retail, professional and eligible counterparty categorisation","Regulatory Classification", ["MiFID II", "UK FCA COBS"]),
 ("DTCC / NSCC Fund/SERV and Networking","DTCC","https://www.dtcc.com/wealth-management-services/mutual-fund-services","Member documentation","Fund trade processing, networking levels, participant and dealer identification","Market Infrastructure Identifiers, Intermediary Account Servicing", ["DTCC / NSCC"]),
 ("DOL Form 5500 and Schedules (EFAST2)","US DOL / EBSA","https://www.dol.gov/agencies/ebsa/employers-and-advisers/plan-administration-and-compliance/reporting-and-filing/form-5500","Public data","Plan sponsor EIN and plan number, plan characteristics codes, assets, participants, Schedule C service providers","Retirement Plan, Plan Service Provider, Recordkeeper Profile", ["DOL Form 5500"]),
 ("ERISA and DOL QDIA regulation","US DOL","https://www.dol.gov/agencies/ebsa","Regulation","Fiduciary roles (3(21), 3(38)), QDIA","Retirement Plan", ["ERISA"]),
 ("IRS EIN, FATCA (W-9 / W-8 series) and OECD Common Reporting Standard","IRS; OECD","https://www.irs.gov/businesses/corporations/foreign-account-tax-compliance-act-fatca","Regulation","Tax identifiers, FATCA and CRS classifications and self-certifications","Tax Profile, Employer Identification Number", ["IRS", "FATCA", "OECD CRS"]),
 ("NIPR National Producer Number","NIPR","https://nipr.com","Public lookup","Insurance producer identification","National Producer Number", ["NIPR"]),
 ("SEC Regulation D, Reg BI, Rule 206(4)-5; FINRA Rules 2210 and 4512","US SEC; FINRA","https://www.sec.gov/rules-regulations","Regulation","Investor qualification, retail customer status, pay-to-play government entity, institutional investor/account definitions","Regulatory Classification, Institutional Client", ["SEC Regulation D", "SEC Reg BI", "SEC Rule 206(4)-5", "FINRA Rule 2210", "FINRA Rule 4512"]),
 ("EU GDPR and UK GDPR / Data Protection Act 2018","European Union; UK ICO","https://eur-lex.europa.eu/eli/reg/2016/679/oj","Regulation","Lawful basis, consent, data subject rights, records of processing, retention","Privacy Profile, Processing Legal Basis, Consent Record, Data Subject Request", ["EU GDPR", "UK GDPR"]),
 ("CCPA / CPRA and other US state privacy laws; GLBA","California Privacy Protection Agency; US states; FTC","https://cppa.ca.gov","Regulation","Opt-out of sale/sharing, sensitive personal information, consumer requests","Privacy Profile, Data Subject Request", ["CCPA / CPRA", "US State Privacy Laws"]),
 ("FATF Recommendations; EU AML Directives / AMLR; UK MLR 2017; FinCEN CDD Rule; OFAC","FATF; EU; HM Treasury; FinCEN; US Treasury","https://www.fatf-gafi.org","Regulation and guidance","Risk-based CDD, EDD, PEPs, beneficial ownership, sanctions screening","Client Onboarding & KYC", ["FATF", "EU AMLD", "UK MLR 2017", "FinCEN CDD Rule", "OFAC"]),
 ("UK FCA Consumer Duty (vulnerable customers)","UK FCA","https://www.fca.org.uk/firms/consumer-duty","Regulation","Customer vulnerability and outcomes","End Investor", ["UK FCA Consumer Duty"]),
 ("The Pensions Regulator - Pension Scheme Registry","UK TPR","https://www.thepensionsregulator.gov.uk","Public / regulatory","UK pension scheme registration numbers","Retirement Plan (UK)", ["TPR"]),
 ("Companies House and EU business registers","UK Companies House; national registers","https://find-and-update.company-information.service.gov.uk","Public register","Company registration numbers","Registration Authority Entity ID (secondary reference)", []),
 ("Discovery Data","Discovery Data (Broadridge-independent vendor)","https://www.discoverydata.com","Licensed","Advisor, team, branch and firm data; channel classification; advisor move tracking; practice profiles","Distributor Firm, Financial Professional, Practice Profile, Employment Affiliation, Vendor Channel", ["Discovery Data"]),
 ("Broadridge Distribution Insight","Broadridge","https://www.broadridge.com/resource/distribution-insight-advisory-solutions","Licensed","Intermediary sales data, firm/office/rep hierarchy, advisor segmentation and scoring","Hierarchy Type, Vendor Advisor Segment, Vehicle Usage", ["Broadridge"]),
 ("FINTRX","FINTRX","https://www.fintrx.com","Licensed","RIA and family office firm and contact data, Form ADV-derived profiles","Form ADV Profile and RIA firm data (secondary reference)", []),
 ("Cerulli Associates advisor channel and practice research","Cerulli Associates","https://www.cerulli.com","Licensed research","Advisor channel definitions, practice types, investment management styles, wealth tiers","Distribution Channel, Business Model, Investment Management Style, Wealth Tier", ["Cerulli"]),
 ("ISO 3166 / ISO 639 / ISO 8601 / ITU-T E.164","ISO; ITU","https://www.iso.org","Standard; code lists widely available","Country, subdivision, language, date/time and telephone number formats","Reference code lists used throughout", ["ISO 3166", "ITU-T E.164"]),
 ("DCAM","EDM Council","https://edmcouncil.org","Member framework","Data management capability: ownership and stewardship","Data Management Metadata", ["DCAM*"]),
]
