"""Business domain 04 - Marketing & Digital. Content module for taxonomy_builder.py."""

META = {
 "title": "Marketing & Digital Data Taxonomy",
 "subtitle": "Business domain 04 - Marketing & Digital | Asset manager (wholesale distributor) | Scope: US + EU/UK | Draft v0.1 | 2026-10-01",
 "output": "04_Marketing_and_Digital/Marketing_and_Digital_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the marketing and digital data of an asset manager that markets its products wholesale (B2B2C) to financial advisors, home-office gatekeepers, institutional investors and consultants, retirement plan advisors and sponsors and, where permitted, end investors. It is built from open vendor data models (Salesforce Campaign / CampaignMember / Lead, Account Engagement, Adobe XDM, GA4 and UTM conventions), open metadata standards (Dublin Core, IPTC, schema.org, WCAG) and the marketing-communication rules that shape the data (FINRA Rule 2210, SEC Marketing Rule, FCA COBS 4, ESMA marketing communication guidelines, CAN-SPAM, GDPR / PECR). Use it as a starting point for a marketing data model, a CDP / MAP design, a data catalogue or a business glossary."),
  ("Scope", "In scope: brand architecture and messaging; campaigns (programme > campaign > wave > tactic), budgets, spend, tracking codes and campaign membership; marketing content and digital asset metadata (audience restriction, jurisdiction, language, products, topics, version, expiry, rights, accessibility); events, registrations, attendance, CE credits and sponsorships; digital properties, pages, gating and investor self-certification; digital identity, sessions and web / email / video / webinar engagement; third-party intent and engagement scoring; segments and membership; subscription topics, channel opt-in / opt-out and suppression; leads, lead scoring and routing; social media accounts, posts, engagement and listening; paid media placements, creatives and delivery; touchpoints, attribution models and influenced pipeline / flows; marketing data management metadata. "
             "Out of scope (referenced by ID only): party master, contact points, consent legal basis and privacy status (02 Client & Customer, PTY-, ACC-); sales personnel, activities and opportunities (03 Sales, EMP-, ACT-, OPP-); products, share classes, product documents and registrations for sale (01 Product, STR-, PRD-, SHC-); agreements and conference-sponsorship payment terms (05 Distribution Agreements & Partners, AGR-); transactions, flows and AUM attribution (06 Sales Transactions & AUM Attribution, TXN-); territories and crediting (07 Compensation & Territory, TER-); review and approval of marketing materials, filings, social media supervision and archiving, gifts and entertainment, complaints and records retention (08 Distribution Compliance, REV-, GNE-, CPL-)."),
  ("Structure", "Four levels: Domain > Subdomain > Concept > Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Brand / Marketing Theme -> Campaign (programme > campaign > wave > tactic) -> Content Asset, Event, Email Send, Social Post and Media Placement (the things a campaign deploys) -> Engagement Event (what an identified or anonymous person did, on a Digital Property or channel) -> Touchpoint (an engagement attributed to a Party and a Campaign) -> Lead / Opportunity / Flow outcomes (attributed through an Attribution Model). Audiences (Segments), Subscriptions and Suppressions control who may be targeted; Audience Restriction and Jurisdiction on assets, pages and events control what each audience may see."),
  ("Design principles", "1) Reuse open vendor models (Salesforce, Adobe XDM, GA4) and metadata standards (Dublin Core, IPTC, schema.org) for names and structures; internal attributes only where none exists. 2) Reference, don't copy: people and firms are Parties (PTY-) mastered in 02; marketing holds only captured, pre-match values (flagged PII) until identity resolution. 3) Compliance owns the approval decision: marketing stores the REV- reference and a read-only mirror of approval status and expiry. 4) Every asset, page, event and segment carries an Audience Restriction and Permitted Jurisdictions so that regulatory gating can be enforced in systems, not by convention. 5) Effective-date memberships, preferences, suppressions and statuses. 6) Flag Critical Data Elements (CDE) and personal data (PII) for governance."),
  ("Applies To", "Shows the record at which each attribute is held: Brand, Theme, Campaign, Campaign Member, Tracking Code, Content Asset, Event, Registration, CE Credit, Digital Property, Web Page, Visitor, Session, Engagement Event, Email, Segment, Subscription, Suppression, Lead, Social Account, Social Post, Placement, Touchpoint, Attribution or All."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify, target, gate, measure or attribute marketing activity, or to evidence that marketing honoured audience restrictions and opt-outs. Confirm with data owners."),
  ("Primary / Secondary Reference", "Standard or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Regulatory references (FINRA, SEC, FCA, ESMA, CAN-SPAM, GDPR) indicate the rule that drives the data requirement; interpretation and approval sit with 08 Distribution Compliance and Legal. Next step: map vendor-aligned attributes to exact field API names in the firm's CRM, MAP, DAM and analytics configuration."),
  ("PII", "Attributes marked 'PII' in Notes hold or can be linked to personal data (identifiers, contact details, cookies / device IDs, IP-derived data, behavioural events of identifiable people). GDPR / UK GDPR, ePrivacy / PECR and US state privacy laws apply; legal basis and consent are mastered in 02 Client & Customer."),
  ("Tabs", "Hierarchy: domains, subdomains and concepts with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: concept-level cardinalities and cross-domain references | Sources: standards and data models used, owners, licences and links."),
  ("Suggested next steps", "1) Validate domains, CDEs and boundary calls with Marketing, Digital, Marketing Operations, Sales Operations, Distribution Compliance and Privacy. 2) Map attributes to source systems (CRM, marketing automation, DAM, CMS, web analytics, webinar / event platforms, social publishing and archiving, ad platforms, intent provider). 3) Agree the identity-resolution and party-match rules with 02 Client & Customer. 4) Agree the Audience Restriction and Content Type lists with 08 Distribution Compliance so they drive review routing. 5) Agree attribution model(s) and the flow source with 06 Sales Transactions. 6) Extend code lists to firm values and assign owners and stewards per subdomain."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Brand & Messaging", "MK-BRD",
  "The firm's brand architecture and the marketing themes and messaging pillars that campaigns and content are built on.",
  [
   ("Brand Architecture", "Corporate, affiliate, sub- and product-range brands under which the firm markets.", [
     ("Brand", [
       ("Brand ID", "Unique internal identifier for the brand.", "Brand", "Identifier", "", "BRD-003", "Internal", "", "Y"),
       ("Brand Name", "Name of the brand as used in market.", "Brand", "Text", "", "Example Investments Fixed Income", "Internal", "", "Y"),
       ("Brand Level", "Position of the brand in the brand architecture.", "Brand", "Code", "Brand Level", "Sub-Brand", "Internal", "", ""),
       ("Parent Brand", "Brand directly above this brand in the hierarchy.", "Brand", "Reference (Brand)", "", "BRD-001", "Internal", "", ""),
       ("Brand Status", "Lifecycle status of the brand.", "Brand", "Code", "Brand Status", "Active", "Internal", "", ""),
       ("Brand Permitted Jurisdictions", "Countries in which the brand may be used (e.g., subject to trademark registration or entity licensing).", "Brand", "Code (multi)", "ISO 3166-1 alpha-2", "US; GB; LU; DE; IE", "Internal", "", ""),
     ]),
   ]),
   ("Themes & Messaging", "Reusable marketing themes and approved key messages that align campaigns, content and sales enablement.", [
     ("Marketing Theme", [
       ("Theme ID", "Unique identifier for the marketing theme.", "Theme", "Identifier", "", "THM-0021", "Internal", "", ""),
       ("Theme Name", "Name of the theme.", "Theme", "Text", "", "Income in a higher-for-longer world", "Internal", "", ""),
       ("Theme Type", "Category of theme.", "Theme", "Code", "Theme Type", "Market Outlook", "Internal", "", ""),
       ("Theme Strategies / Products", "Strategies and products the theme is designed to support.", "Theme", "Reference (Strategy / Product) (multi)", "", "STR-00123; PRD-00981", "Internal", "", "Y"),
     ]),
     ("Messaging Pillar", [
       ("Key Message Statement", "The approved headline message for the pillar.", "Theme", "Text", "", "Active fixed income can capture yield while managing duration risk", "Internal", "", ""),
       ("Proof Points", "Supporting facts or capabilities that substantiate the message.", "Theme", "Text", "", "30-year track record; 45 credit analysts; 4-star Morningstar rating (as of 2026-06-30)", "Internal", "SEC Marketing Rule", "", "Third-party ratings and performance claims require compliance substantiation (08)."),
       ("Messaging Compliance Review", "Compliance review under which the message text was pre-approved for reuse.", "Theme", "Reference (Compliance Review)", "", "REV-2026-01877", "Internal", "FINRA Rule 2210", "", "Owned by 08 Distribution Compliance."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Campaign Management", "MK-CAM",
  "Planned, budgeted marketing initiatives organised as programme > campaign > wave / tactic, with objectives, targeting, products, spend, tracking codes and members.",
  [
   ("Campaign Definition", "Identity, hierarchy, ownership and dates of a campaign record at any level.", [
     ("Campaign", [
       ("Campaign ID", "Unique identifier for the campaign record (any level).", "Campaign", "Identifier", "", "CAM-004512", "Salesforce", "Adobe XDM", "Y"),
       ("Campaign Name", "Name of the campaign following the firm naming convention.", "Campaign", "Text", "", "FY26Q4_US_RIA_ActiveFI_Nurture_Wave2", "Salesforce", "", "Y"),
       ("Campaign Level", "Level of the record in the campaign hierarchy.", "Campaign", "Code", "Campaign Level", "Wave", "Internal", "Salesforce", "Y"),
       ("Parent Campaign", "Campaign record directly above this one in the hierarchy.", "Campaign", "Reference (Campaign)", "", "CAM-004500", "Salesforce", "", "Y"),
       ("Campaign Type", "Nature of the campaign.", "Campaign", "Code", "Campaign Type", "Nurture", "Salesforce", "", ""),
       ("Campaign Status", "Lifecycle status of the campaign.", "Campaign", "Code", "Campaign Status", "In Progress", "Salesforce", "", "Y"),
       ("Campaign Owner", "Marketing employee accountable for the campaign.", "Campaign", "Reference (Employee)", "", "EMP-0412", "Salesforce", "", ""),
       ("Planned Start Date", "Date the campaign is planned to start.", "Campaign", "Date", "ISO 8601", "2026-10-06", "Salesforce", "", ""),
       ("Planned End Date", "Date the campaign is planned to end.", "Campaign", "Date", "ISO 8601", "2026-12-12", "Salesforce", "", ""),
       ("Marketing Theme", "Theme the campaign executes.", "Campaign", "Reference (Theme)", "", "THM-0021", "Internal", "", ""),
       ("Co-Marketing Agreement", "Agreement that governs partner co-marketing funding and terms.", "Campaign", "Reference (Agreement)", "", "AGR-00218", "Internal", "", "", "Owned by 05 Distribution Agreements & Partners."),
     ]),
   ]),
   ("Objectives & Targeting", "What the campaign aims to achieve, for whom, where and with which products.", [
     ("Campaign Targeting", [
       ("Primary Objective", "Main business objective of the campaign.", "Campaign", "Code", "Campaign Objective", "Lead Generation", "Internal", "", ""),
       ("Primary KPI", "Measure used to judge success against the objective.", "Campaign", "Code", "Marketing KPI", "MQLs", "Internal", "", ""),
       ("Target Audience Types", "Audience types the campaign is aimed at.", "Campaign", "Code (multi)", "Audience Type", "Financial Advisor; Home Office / Gatekeeper", "Internal", "", "Y"),
       ("Target Business Channels", "Distribution channels / firm types targeted.", "Campaign", "Code (multi)", "Business Channel", "RIA; Independent Broker-Dealer", "Internal", "", ""),
       ("Target Jurisdictions", "Countries in which the campaign may be deployed.", "Campaign", "Code (multi)", "ISO 3166-1 alpha-2", "US", "Internal", "ESMA Marketing Guidelines", "Y"),
       ("Target Territories", "Sales territories the campaign supports, for wholesaler alignment.", "Campaign", "Reference (Territory) (multi)", "", "TER-US-WEST-03; TER-US-WEST-04", "Internal", "", "", "Territories owned by 07 Compensation & Territory."),
       ("Marketing Channel Mix", "Marketing channels used by the campaign.", "Campaign", "Code (multi)", "Marketing Channel", "Email; Paid Social; Webinar", "Internal", "Adobe XDM", ""),
     ]),
     ("Campaign Product", [
       ("Campaign Product / Share Class", "Product, share class or strategy promoted by the campaign.", "Campaign", "Reference (Product / Share Class)", "", "PRD-00981", "Internal", "", "Y", "Owned by 01 Product."),
       ("Product Role in Campaign", "Prominence of the product in the campaign.", "Campaign", "Code", "Product Role", "Featured", "Internal", "", ""),
     ]),
   ]),
   ("Budget & Spend", "Planned and actual cost of campaigns, and the line items that make it up.", [
     ("Campaign Budget", [
       ("Budgeted Cost", "Amount budgeted for the campaign.", "Campaign", "Amount", "", "USD 85,000", "Salesforce", "", ""),
       ("Actual Cost", "Amount actually spent to run the campaign, including rolled-up child campaigns.", "Campaign", "Amount", "", "USD 61,250", "Salesforce", "", "Y"),
       ("Budget Currency", "Currency of budget and cost amounts.", "Campaign", "Code", "ISO 4217", "USD", "ISO 4217", "", ""),
     ]),
     ("Spend Line", [
       ("Spend Category", "Category of the spend line.", "Campaign", "Code", "Spend Category", "Media", "Internal", "", ""),
       ("Spend Amount", "Amount of the spend line.", "Campaign", "Amount", "", "USD 12,500", "Internal", "", ""),
     ]),
   ]),
   ("Tracking Codes", "Campaign tracking parameters appended to links so that traffic and responses can be attributed.", [
     ("Campaign Tracking Code", [
       ("Tracked URL", "Full destination URL including tracking parameters.", "Tracking Code", "Text", "URI", "https://www.example.com/insights/active-fi?utm_source=linkedin&utm_medium=paid_social&utm_campaign=fy26q4_activefi&utm_id=CAM-004512", "UTM", "GA4", ""),
       ("utm_id", "Campaign identifier carried in the URL; should equal the Campaign ID to enable cost and data import.", "Tracking Code", "Text", "", "CAM-004512", "GA4", "UTM", "Y"),
       ("utm_source", "Referrer that sent the traffic.", "Tracking Code", "Code", "UTM Source (firm-defined)", "linkedin", "UTM", "GA4", ""),
       ("utm_medium", "Marketing medium of the traffic.", "Tracking Code", "Code", "UTM Medium", "paid_social", "UTM", "GA4", ""),
       ("utm_campaign", "Campaign name or code as it appears in analytics.", "Tracking Code", "Text", "", "fy26q4_activefi", "UTM", "GA4", ""),
       ("utm_content", "Differentiates ads, links or creative variants within a campaign.", "Tracking Code", "Text", "", "carousel_v2", "UTM", "GA4", ""),
     ]),
   ]),
   ("Campaign Membership", "People and organisations targeted by, or responding to, a campaign.", [
     ("Campaign Member", [
       ("Member Party", "Person or organisation that is a member of the campaign.", "Campaign Member", "Reference (Party)", "", "PTY-55120", "Salesforce", "", "Y", "PII (link to individual). Party mastered in 02."),
       ("Member Lead", "Lead record that is a member, where the person is not yet a matched Party.", "Campaign Member", "Reference (Lead)", "", "LEAD-0091234", "Salesforce", "", "", "PII (link to individual)."),
       ("Member Status", "Status of the member in the campaign.", "Campaign Member", "Code", "Campaign Member Status", "Responded", "Salesforce", "", "Y"),
       ("Responded Indicator", "Whether the member's status counts as a response.", "Campaign Member", "Boolean", "", "Y", "Salesforce", "", ""),
       ("Added By Salesperson", "Wholesaler or salesperson who nominated the member, where sales-added.", "Campaign Member", "Reference (Employee)", "", "EMP-0233", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Content & Digital Assets", "MK-AST",
  "Marketing content and digital assets (documents, video, audio, images, templates) and the metadata that governs who may see them, where, in which language, for how long and under which rights.",
  [
   ("Asset Identity", "Core descriptive metadata of a content asset, aligned to Dublin Core.", [
     ("Content Asset", [
       ("Asset ID", "Unique identifier of the content asset (all versions).", "Content Asset", "Identifier", "", "AST-018233", "Dublin Core", "Internal", "Y", "dc:identifier"),
       ("Asset Title", "Title of the asset.", "Content Asset", "Text", "", "Q3 2026 Fixed Income Outlook: Duration Is Back", "Dublin Core", "IPTC", "Y", "dc:title"),
       ("Asset Description", "Short summary / abstract of the asset.", "Content Asset", "Text", "", "Our CIO explains why we added duration in Q3 and where we see value in credit.", "Dublin Core", "", "", "dc:description"),
       ("Content Type", "Business type of the content.", "Content Asset", "Code", "Content Type", "Market Commentary", "Internal", "Dublin Core", "Y", "dc:type maps to the coarser DCMI Type vocabulary."),
       ("Asset Owner", "Marketing employee accountable for the asset's accuracy and lifecycle.", "Content Asset", "Reference (Employee)", "", "EMP-0412", "Internal", "", ""),
       ("Asset Authors", "Named authors or presenters (employees or external contributors).", "Content Asset", "Reference (Employee / Party) (multi)", "", "EMP-0107; PTY-0457", "Dublin Core", "", "", "dc:creator. PII (named individuals)."),
       ("Publishing Entity", "Legal entity that issues the communication (shown in the legal footer).", "Content Asset", "Reference (Party)", "", "PTY-0015", "Dublin Core", "FCA COBS 4", "", "dc:publisher. Must match entity permitted to communicate in each jurisdiction."),
       ("Parent / Source Asset", "Asset this asset was derived from (e.g., a social cut-down of a webinar recording).", "Content Asset", "Reference (Content Asset)", "", "AST-018100", "Dublin Core", "", "", "dc:source"),
     ]),
   ]),
   ("Audience & Distribution Restrictions", "Who may receive the asset, where and through which channels; drives gating, distribution lists and compliance routing.", [
     ("Audience Restriction", [
       ("Audience Restriction", "Highest-level statement of who may receive the asset.", "Content Asset", "Code", "Audience Restriction", "Financial Professional Use Only", "Internal", "FINRA Rule 2210", "Y"),
       ("FINRA Communication Category", "FINRA Rule 2210 category of the communication, as determined by compliance (US).", "Content Asset", "Code", "FINRA Communication Category", "Retail Communication", "FINRA Rule 2210", "", "", "Mirrored from 08 Distribution Compliance; marketing does not set it."),
       ("Permitted Investor Categories", "Regulatory client categories the asset may be shown to.", "Content Asset", "Code (multi)", "Investor Category", "US Retail Investor; US Institutional Investor", "Internal", "FCA COBS 4", ""),
       ("Permitted Jurisdictions", "Countries in which the asset may be distributed.", "Content Asset", "Code (multi)", "ISO 3166-1 alpha-2", "GB; IE; LU; DE", "Internal", "ESMA Marketing Guidelines", "Y", "Must be consistent with product registration for sale (01) and cross-border notifications (08)."),
       ("Partner-Specific Restriction", "Distributor firms the asset is restricted to (partner-specific or co-branded material).", "Content Asset", "Reference (Party) (multi)", "", "PTY-3301", "Internal", "", ""),
       ("Marketing Communication Label Indicator", "Whether the asset is clearly identified as a marketing communication.", "Content Asset", "Boolean", "", "Y", "ESMA Marketing Guidelines", "", ""),
     ]),
   ]),
   ("Descriptive Classification", "Language, products, topics and tags used for search, personalisation and reporting.", [
     ("Asset Classification", [
       ("Asset Language", "Language of the asset content.", "Content Asset", "Code", "ISO 639-1", "en", "Dublin Core", "", "", "dc:language"),
       ("Featured Products / Share Classes", "Products, share classes or strategies the asset discusses.", "Content Asset", "Reference (Product / Share Class) (multi)", "", "PRD-00981; SHC-004512", "Internal", "", "Y"),
       ("Content Topics", "Controlled topics the asset covers.", "Content Asset", "Code (multi)", "Content Topic", "Interest Rates; Credit", "Internal", "IAB", ""),
       ("Keywords / Tags", "Free keywords used for search.", "Content Asset", "Text (multi)", "", "duration; yield curve; Fed", "IPTC", "Dublin Core", "", "dc:subject / IPTC Keywords"),
       ("Gated Indicator", "Whether access requires a form fill or login.", "Content Asset", "Boolean", "", "Y", "Internal", "", ""),
     ]),
   ]),
   ("Version & Lifecycle", "Versioning, data as-of dates, expiry and review of assets.", [
     ("Asset Version", [
       ("Version Number", "Version of the asset.", "Content Asset", "Text", "", "2.1", "Internal", "XMP", ""),
       ("Asset Lifecycle Status", "Lifecycle status of the asset version.", "Content Asset", "Code", "Asset Lifecycle Status", "Published", "Internal", "", "Y"),
       ("Data As-Of Date", "Date of the performance, holdings or market data shown in the asset.", "Content Asset", "Date", "ISO 8601", "2026-06-30", "Internal", "SEC Marketing Rule", "Y"),
       ("Publication Date", "Date the version was first made available to its audience.", "Content Asset", "Date", "ISO 8601", "2026-07-21", "Dublin Core", "", "", "dct:issued"),
       ("Expiry Date", "Date after which the version must be withdrawn from all channels.", "Content Asset", "Date", "ISO 8601", "2026-10-20", "Internal", "", "Y"),
       ("Withdrawal Reason", "Reason the asset was withdrawn early.", "Content Asset", "Code", "Withdrawal Reason", "Data Superseded", "Internal", "", ""),
     ]),
   ]),
   ("Compliance Linkage", "Content characteristics that drive compliance review, and the link to the review owned by 08 Distribution Compliance.", [
     ("Asset Compliance Reference", [
       ("Compliance Review Reference", "Compliance review that approved this asset version.", "Content Asset", "Reference (Compliance Review)", "", "REV-2026-02311", "Internal", "FINRA Rule 2210", "Y", "Owned by 08 Distribution Compliance."),
       ("Approval Status (Mirrored)", "Read-only copy of the review outcome, used to block distribution of unapproved assets.", "Content Asset", "Code", "External (08 Distribution Compliance: Review Status)", "Approved", "Internal", "", "Y", "Owned by 08; mirrored, never edited in marketing."),
       ("Performance Content Indicator", "Whether the asset presents investment performance.", "Content Asset", "Boolean", "", "Y", "SEC Marketing Rule", "ESMA Marketing Guidelines", ""),
       ("Hypothetical Performance Indicator", "Whether the asset contains model, back-tested, targeted or projected performance.", "Content Asset", "Boolean", "", "N", "SEC Marketing Rule", "", ""),
       ("Testimonial / Endorsement / Rating Indicator", "Whether the asset contains testimonials, endorsements or third-party ratings.", "Content Asset", "Boolean", "", "Y", "SEC Marketing Rule", "", ""),
     ]),
   ]),
   ("Rights & Accessibility", "Ownership, licensing and accessibility metadata, aligned to IPTC, XMP and WCAG.", [
     ("Asset Rights", [
       ("Copyright Notice", "Copyright statement identifying the current rights owner.", "Content Asset", "Text", "", "(c) 2026 Example Investments LLC", "IPTC", "Dublin Core", "", "dc:rights"),
       ("Licence Type", "Type of licence under which the firm uses the asset.", "Content Asset", "Code", "Licence Type", "Rights-Managed", "IPTC", "", ""),
       ("Rights Usage Terms", "What may and may not be done with the asset.", "Content Asset", "Text", "", "Digital and print use in US and UK only; no paid social", "IPTC", "XMP", ""),
       ("Licence Expiry Date", "Date the usage licence (image, music, third-party data) ends.", "Content Asset", "Date", "ISO 8601", "2027-06-30", "Internal", "IPTC", ""),
     ]),
     ("Asset Accessibility & Rendition", [
       ("Alt Text", "Short text alternative describing the purpose of an image for assistive technology.", "Content Asset", "Text", "", "Line chart of US 10-year Treasury yield, 2016-2026", "IPTC", "WCAG 2.2", ""),
       ("Captions / Transcript Available Indicator", "Whether captions (video) or a transcript (audio / video) are available.", "Content Asset", "Boolean", "", "Y", "WCAG 2.2", "", ""),
       ("Accessibility Conformance Level", "WCAG conformance level the asset has been checked against.", "Content Asset", "Code", "WCAG Conformance Level", "AA", "WCAG 2.2", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Events & Continuing Education", "MK-EVT",
  "Hosted and third-party events (conferences, roadshows, seminars, webinars, due-diligence forums), their sessions and speakers, registrations and attendance, continuing-education credits and sponsorships.",
  [
   ("Event Definition", "Core identity, format, schedule and audience of an event.", [
     ("Marketing Event", [
       ("Event ID", "Unique identifier of the event.", "Event", "Identifier", "", "EVT-00871", "Internal", "schema.org", "Y"),
       ("Event Name", "Name of the event.", "Event", "Text", "", "2026 RIA Fixed Income Forum - Chicago", "schema.org", "", ""),
       ("Event Type", "Type of event.", "Event", "Code", "Event Type", "Hosted Seminar", "Internal", "schema.org", "Y"),
       ("Attendance Mode", "Whether the event is in person, online or hybrid.", "Event", "Code", "Attendance Mode", "Mixed", "schema.org", "", "", "schema.org eventAttendanceMode"),
       ("Event Status", "Scheduling status of the event.", "Event", "Code", "Event Status", "Scheduled", "schema.org", "", "", "schema.org eventStatus"),
       ("Event Start", "Start date and time of the event.", "Event", "Timestamp", "ISO 8601", "2026-11-05T08:30:00-06:00", "schema.org", "", "Y"),
       ("Event Country", "Country in which the event takes place (or primary audience country for online events).", "Event", "Code", "ISO 3166-1 alpha-2", "US", "Internal", "", ""),
       ("Organiser", "Organisation running the event (the firm, a distributor or a conference organiser).", "Event", "Reference (Party)", "", "PTY-0015", "schema.org", "", ""),
       ("Owning Campaign", "Campaign the event belongs to.", "Event", "Reference (Campaign)", "", "CAM-004530", "Internal", "", ""),
       ("Event Audience Restriction", "Who may attend.", "Event", "Code", "Audience Restriction", "Financial Professional Use Only", "Internal", "FINRA Rule 2210", "Y"),
     ]),
   ]),
   ("Agenda & Speakers", "Sessions within an event and the people presenting them.", [
     ("Event Session", [
       ("Session Title", "Title of the session.", "Event", "Text", "", "Where to find yield in 2027", "schema.org", "", ""),
       ("Session Presentation Asset", "Approved presentation used in the session.", "Event", "Reference (Content Asset)", "", "AST-018402", "Internal", "", "", "Asset must carry its own REV- approval."),
     ]),
     ("Event Speaker", [
       ("Speaker", "Employee or external person presenting.", "Event", "Reference (Employee / Party)", "", "EMP-0107", "schema.org", "", "", "PII (named individual)."),
     ]),
   ]),
   ("Registration & Attendance", "Invitations, registrations, check-ins and attendance of individuals at events.", [
     ("Event Registration", [
       ("Registrant Party", "Party who registered or was invited.", "Registration", "Reference (Party)", "", "PTY-55120", "Internal", "", "Y", "PII (link to individual)."),
       ("Registrant Email (Captured)", "Email address entered on the registration form, before matching to a Party.", "Registration", "Text", "Email", "j.smith@exampleria.com", "Internal", "", "", "PII. Promoted to 02 contact point on match."),
       ("Registration Status", "Status of the registration.", "Registration", "Code", "Registration Status", "Attended", "Internal", "Salesforce", "Y"),
       ("Invited By Salesperson", "Wholesaler or salesperson who invited the registrant.", "Registration", "Reference (Employee)", "", "EMP-0233", "Internal", "", ""),
       ("Attended Indicator", "Whether the registrant attended (live or virtual).", "Registration", "Boolean", "", "Y", "Internal", "", ""),
       ("Accessibility / Dietary Requirements", "Requirements notified by the registrant.", "Registration", "Text", "", "Wheelchair access", "Internal", "GDPR", "", "PII; may be special-category data (GDPR Art. 9). Minimise and delete after event."),
       ("Gifts & Entertainment Record", "G&E / non-cash compensation record logged for the hospitality provided.", "Registration", "Reference (Gift / Entertainment)", "", "GNE-2026-04410", "Internal", "", "", "Owned by 08 Distribution Compliance."),
     ]),
   ]),
   ("Continuing Education", "Accreditation of events for professional continuing-education credit and the credits issued to attendees.", [
     ("CE Accreditation", [
       ("CE Accrediting Body", "Body that accredited the programme for CE / CPD credit.", "Event", "Code", "CE Accrediting Body", "CFP Board", "CFP Board CE", "IWI CE", ""),
       ("CE Program ID", "Programme identifier assigned by the accrediting body.", "Event", "Identifier", "", "312845", "CFP Board CE", "", ""),
       ("CE Credit Hours Approved", "Credit hours approved for full attendance (CFP Board: 1 hour per 50 minutes, rounded down to the half hour).", "Event", "Decimal", "", "1.5", "CFP Board CE", "IWI CE", "Y"),
       ("CE Subject Area", "Subject / topic category of the credit.", "Event", "Code", "CE Subject Area", "Investment Planning", "CFP Board CE", "", ""),
     ]),
     ("CE Credit Issued", [
       ("Credential Holder ID", "Attendee's designation / member number with the accrediting body.", "CE Credit", "Identifier", "", "CFP 123456", "CFP Board CE", "IWI CE", "", "PII."),
       ("CE Credits Earned", "Credit hours awarded to the attendee.", "CE Credit", "Decimal", "", "1.5", "CFP Board CE", "", "Y"),
       ("CE Reporting Status", "Status of reporting the credit to the accrediting body.", "CE Credit", "Code", "CE Reporting Status", "Reported", "Internal", "", ""),
       ("CE Reported Date", "Date credit was reported (CFP Board expects sponsor reporting within 14 days).", "CE Credit", "Date", "ISO 8601", "2026-11-12", "CFP Board CE", "", ""),
     ]),
   ]),
   ("Sponsorship", "Sponsorship of third-party conferences and events (e.g., distributor due-diligence conferences).", [
     ("Event Sponsorship", [
       ("Sponsorship Tier", "Level of sponsorship purchased.", "Event", "Code", "Sponsorship Tier", "Gold", "Internal", "", ""),
       ("Sponsorship Fee", "Fee paid for the sponsorship.", "Event", "Amount", "", "USD 45,000", "Internal", "", ""),
       ("Sponsorship Agreement", "Agreement under which a distributor conference sponsorship is paid.", "Event", "Reference (Agreement)", "", "AGR-00305", "Internal", "", "", "Payment arrangement owned by 05; non-cash compensation review by 08."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Digital Properties", "MK-WEB",
  "Websites, advisor and client portals, fund literature centres, apps and landing pages, their pages and forms, and the jurisdiction / investor-type gating that controls access.",
  [
   ("Digital Property", "Registry of owned digital properties.", [
     ("Digital Property", [
       ("Property ID", "Unique identifier of the digital property.", "Digital Property", "Identifier", "", "WEB-012", "Internal", "", "Y"),
       ("Property Name", "Name of the property.", "Digital Property", "Text", "", "Example Investments UK Professional Site", "Internal", "", ""),
       ("Property Type", "Type of digital property.", "Digital Property", "Code", "Property Type", "Public Website", "Internal", "", "Y"),
       ("Primary Domain", "Primary domain or app store identifier.", "Digital Property", "Text", "URI", "https://www.example.com/uk/professional", "Internal", "", ""),
       ("Property Audience Types", "Audiences the property serves.", "Digital Property", "Code (multi)", "Audience Type", "Financial Advisor; Institutional Investor", "Internal", "", ""),
       ("Jurisdictions Served", "Countries the property is designed for.", "Digital Property", "Code (multi)", "ISO 3166-1 alpha-2", "GB; IE", "Internal", "", "Y"),
       ("Property Status", "Lifecycle status of the property.", "Digital Property", "Code", "Property Status", "Live", "Internal", "", ""),
     ]),
   ]),
   ("Pages & Forms", "Pages and forms within a property, including product pages and gated-content forms.", [
     ("Web Page", [
       ("Page URL", "Canonical URL of the page.", "Web Page", "Text", "URI", "https://www.example.com/us/advisor/funds/active-core-bond", "GA4", "Adobe XDM", "Y", "GA4 page_location; XDM web.webPageDetails.URL"),
       ("Page Type", "Template type of the page.", "Web Page", "Code", "Page Type", "Product Page", "Internal", "", ""),
       ("Page Product / Share Class", "Product or share class the page describes.", "Web Page", "Reference (Product / Share Class)", "", "PRD-00981", "Internal", "", ""),
       ("Page Audience Restriction", "Audience the page is restricted to.", "Web Page", "Code", "Audience Restriction", "Financial Professional Use Only", "Internal", "FINRA Rule 2210", "Y"),
     ]),
     ("Web Form", [
       ("Form ID", "Identifier of the form.", "Web Page", "Identifier", "", "FRM-0057", "GA4", "", "", "GA4 form_id"),
       ("Form Purpose", "What the form captures.", "Web Page", "Code", "Form Purpose", "Content Download Gate", "Internal", "", ""),
       ("Linked Campaign", "Campaign credited with form submissions.", "Web Page", "Reference (Campaign)", "", "CAM-004512", "Salesforce MCAE", "", ""),
       ("Privacy Notice Version", "Version of the privacy notice displayed on the form.", "Web Page", "Text", "", "PN-UK-2026-02", "GDPR", "", "", "Notice content and legal basis owned by 02 / Privacy."),
     ]),
   ]),
   ("Gating & Self-Certification", "Jurisdiction and investor-type gates and the declarations visitors make to pass them.", [
     ("Access Gate", [
       ("Gate Type", "Mechanism used to restrict access.", "Web Page", "Code", "Gate Type", "Investor-Type Declaration", "Internal", "FCA COBS 4", ""),
       ("Gate Declaration Text Version", "Version of the declaration / disclaimer text presented.", "Web Page", "Text", "", "GATE-UK-PRO-v3", "Internal", "", "", "Text approved under a REV- review (08)."),
     ]),
     ("Self-Certification Record", [
       ("Declaring Visitor", "Visitor or authenticated user who made the declaration.", "Visitor", "Reference (Visitor)", "", "VIS-7f3a9c21", "Internal", "", "", "PII (pseudonymous identifier)."),
       ("Declared Country", "Country the visitor declared they are in / resident of.", "Visitor", "Code", "ISO 3166-1 alpha-2", "GB", "Internal", "", "", "PII."),
       ("Declared Investor Type", "Investor type the visitor self-declared.", "Visitor", "Code", "Declared Investor Type", "Professional Investor / Adviser", "Internal", "FCA COBS 4", "Y", "PII."),
       ("Declaration Timestamp", "When the declaration was made.", "Visitor", "Timestamp", "ISO 8601", "2026-09-29T09:14:55Z", "Internal", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Digital Identity & Engagement", "MK-DIG",
  "Identification of web visitors and known users, authentication and sessions, and the behavioural events they generate across web, email, video and webinars, plus third-party intent signals and engagement scores.",
  [
   ("Visitor Identity", "Identifiers and identity-resolution status of anonymous and known digital users.", [
     ("Web Visitor / Known User", [
       ("Visitor ID", "Firm-assigned persistent identifier for a browser / device or known user.", "Visitor", "Identifier", "", "VIS-7f3a9c21", "Adobe XDM", "GA4", "Y", "PII (pseudonymous)."),
       ("Identity Namespace", "Type of identifier held in the identity value.", "Visitor", "Code", "Identity Namespace", "GA Client ID", "Adobe XDM", "", ""),
       ("Identification Status", "Whether the visitor is anonymous, known or matched to a Party.", "Visitor", "Code", "Identification Status", "Known - Matched", "Internal", "", "Y"),
       ("Matched Party", "Party the visitor has been resolved to.", "Visitor", "Reference (Party)", "", "PTY-55120", "Internal", "", "Y", "PII (link to individual)."),
       ("Match Method", "How the visitor was matched to the Party.", "Visitor", "Code", "Identity Match Method", "Email Click-Through", "Internal", "", ""),
       ("Applied Tracking Consent", "Cookie / tracking categories permitted when events were collected.", "Visitor", "Code (multi)", "Tracking Consent Category", "Strictly Necessary; Analytics", "UK PECR", "GDPR", "Y", "Consent record and legal basis owned by 02; this is the state applied at collection."),
     ]),
   ]),
   ("Authentication & Sessions", "Portal accounts of registered users and the sessions in which digital activity occurs.", [
     ("Portal Account", [
       ("Portal User ID", "Login identifier of a registered portal user.", "Visitor", "Identifier", "", "jsmith@exampleria.com", "Internal", "", "", "PII."),
       ("Portal Account Party", "Party the portal account belongs to.", "Visitor", "Reference (Party)", "", "PTY-55120", "Internal", "", "", "PII (link to individual)."),
       ("Verified Professional Indicator", "Whether professional status was verified against a registry (e.g., CRD, FCA register) held in 02.", "Visitor", "Boolean", "", "Y", "Internal", "", ""),
     ]),
     ("Session", [
       ("Session ID", "Identifier of a visit.", "Session", "Identifier", "", "1727600001", "GA4", "", "", "GA4 ga_session_id. PII (behavioural)."),
       ("Session Source / Medium", "Traffic source and medium of the session (from UTM or referrer).", "Session", "Text", "", "linkedin / paid_social", "GA4", "UTM", ""),
       ("Session Campaign", "Campaign attributed to the session.", "Session", "Reference (Campaign)", "", "CAM-004512", "GA4", "UTM", ""),
     ]),
   ]),
   ("Web & App Interaction", "Individual behavioural events on owned digital properties.", [
     ("Engagement Event", [
       ("Event Timestamp", "When the event occurred.", "Engagement Event", "Timestamp", "ISO 8601", "2026-09-29T09:16:41Z", "Adobe XDM", "GA4", "Y"),
       ("Engagement Event Type", "Type of interaction.", "Engagement Event", "Code", "Engagement Event Type", "file_download", "GA4", "Adobe XDM", "Y"),
       ("Event Visitor / Party", "Visitor or Party who performed the event.", "Engagement Event", "Reference (Visitor / Party)", "", "VIS-7f3a9c21", "Adobe XDM", "", "Y", "PII (behavioural)."),
       ("Event Content Asset", "Content asset interacted with.", "Engagement Event", "Reference (Content Asset)", "", "AST-018233", "Internal", "", ""),
     ]),
   ]),
   ("Email Engagement", "Marketing email sends and recipient-level delivery and engagement.", [
     ("Email Send", [
       ("Email Template Asset", "Approved email template / creative used.", "Email", "Reference (Content Asset)", "", "AST-018560", "Internal", "", ""),
       ("Email Campaign", "Campaign the send belongs to.", "Email", "Reference (Campaign)", "", "CAM-004512", "Adobe XDM", "Salesforce MCAE", ""),
       ("Subject Line", "Subject line as sent.", "Email", "Text", "", "Duration is back: our Q4 fixed income view", "Internal", "CAN-SPAM", "", "Must not be misleading (CAN-SPAM)."),
       ("Email Send Type", "Commercial or transactional nature of the email.", "Email", "Code", "Email Send Type", "Commercial", "CAN-SPAM", "", "Y", "Transactional / relationship messages have different opt-out rules."),
       ("Email Subscription Topic", "Subscription topic the send is governed by.", "Email", "Reference (Subscription Topic)", "", "SUB-004", "Internal", "", ""),
     ]),
     ("Email Interaction", [
       ("Recipient Party", "Party who received the email.", "Email", "Reference (Party)", "", "PTY-55120", "Adobe XDM", "", "Y", "PII (link to individual)."),
       ("Recipient Email Address", "Email address the message was sent to.", "Email", "Text", "Email", "j.smith@exampleria.com", "Adobe XDM", "", "", "PII. Contact point mastered in 02."),
       ("Delivery Status", "Delivery outcome for the recipient.", "Email", "Code", "Email Delivery Status", "Delivered", "Adobe XDM", "", "Y"),
       ("First Open Timestamp", "First recorded open.", "Email", "Timestamp", "ISO 8601", "2026-10-14T13:42:10Z", "Adobe XDM", "", "", "Opens are inflated by mail privacy proxies; prefer clicks for scoring."),
       ("First Click Timestamp", "First recorded click.", "Email", "Timestamp", "ISO 8601", "2026-10-14T13:43:02Z", "Adobe XDM", "", ""),
       ("Unsubscribe Timestamp", "When the recipient unsubscribed via this email.", "Email", "Timestamp", "ISO 8601", "", "Adobe XDM", "CAN-SPAM", "Y", "Must flow to Communication Preference and suppression."),
     ]),
   ]),
   ("Video & Webinar Engagement", "Consumption of video, audio and webinar content.", [
     ("Media Engagement", [
       ("Viewing Mode", "Whether content was consumed live or on demand.", "Engagement Event", "Code", "Viewing Mode", "On-Demand", "Internal", "", ""),
       ("Percent Viewed", "Furthest progress through the media.", "Engagement Event", "Percentage", "", "75%", "GA4", "", "", "GA4 video_percent (10 / 25 / 50 / 75 milestones)."),
       ("Completion Indicator", "Whether the media was watched to the end.", "Engagement Event", "Boolean", "", "N", "GA4", "", ""),
     ]),
   ]),
   ("Intent & Scoring", "Third-party intent signals and engagement scores used to prioritise outreach.", [
     ("Third-Party Intent Signal", [
       ("Intent Provider", "Provider of the intent data.", "Engagement Event", "Code", "Intent Provider", "Bombora", "Internal", "", ""),
       ("Intent Organisation", "Organisation the signal relates to.", "Engagement Event", "Reference (Party)", "", "PTY-3301", "Bombora", "", ""),
       ("Intent Topic", "Topic on which elevated research was detected.", "Engagement Event", "Text", "", "Fixed Income ETFs", "Bombora", "", ""),
       ("Intent Score", "Provider score for the topic (Bombora Company Surge: 0-100, 60+ = surging).", "Engagement Event", "Integer", "", "72", "Bombora", "", ""),
     ]),
     ("Engagement Score", [
       ("Engagement Score Model", "Scoring model used.", "Engagement Event", "Code", "Firm-defined", "Advisor Engagement v2", "Internal", "", ""),
       ("Engagement Score Party", "Party (person or firm) being scored.", "Engagement Event", "Reference (Party)", "", "PTY-55120", "Internal", "", "", "PII (profiling). GDPR Art. 21 objection rights apply."),
       ("Engagement Score Value", "Calculated score.", "Engagement Event", "Integer", "", "84", "Internal", "Salesforce MCAE", "", "PII (profiling)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Audiences, Subscriptions & Preferences", "MK-AUD",
  "Marketing segments and their membership, subscription topics, channel-level opt-in / opt-out preferences and suppression lists. Base party data, consent legal basis and privacy status are mastered in 02 Client & Customer.",
  [
   ("Segments", "Definitions of target audiences and the parties that belong to them.", [
     ("Marketing Segment", [
       ("Segment ID", "Unique identifier of the segment.", "Segment", "Identifier", "", "SEG-0042", "Internal", "Adobe XDM", "Y"),
       ("Segment Name", "Name of the segment.", "Segment", "Text", "", "US RIA advisors - engaged with fixed income (90d)", "Internal", "", ""),
       ("Segment Type", "How membership is determined.", "Segment", "Code", "Segment Type", "Rule-Based (Dynamic)", "Internal", "Adobe XDM", ""),
       ("Segment Rule Definition", "Business-readable rule that selects members.", "Segment", "Text", "", "Party Type = Financial Advisor AND Channel = RIA AND Country = US AND FI content views >= 2 in last 90 days", "Internal", "", ""),
       ("Segment Audience Restriction", "Highest audience restriction compatible with the segment's members.", "Segment", "Code", "Audience Restriction", "Financial Professional Use Only", "Internal", "", ""),
     ]),
     ("Segment Membership", [
       ("Member Party", "Party included in the segment.", "Segment", "Reference (Party)", "", "PTY-55120", "Internal", "", "Y", "PII (link to individual)."),
       ("Membership Effective From", "Date the party entered the segment.", "Segment", "Date", "ISO 8601", "2026-09-12", "Internal", "", "Y"),
       ("Membership Effective To", "Date the party left the segment.", "Segment", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Subscriptions & Preferences", "Subscription topics offered and each party's per-topic, per-channel preferences.", [
     ("Subscription Topic", [
       ("Subscription Topic ID", "Unique identifier of the topic.", "Subscription", "Identifier", "", "SUB-004", "Internal", "Salesforce MCAE", "Y"),
       ("Subscription Topic Name", "Name shown in the preference centre.", "Subscription", "Text", "", "Fixed Income Insights", "Internal", "", ""),
       ("Subscription Category", "Category of the topic.", "Subscription", "Code", "Subscription Category", "Market Insights", "Internal", "", ""),
       ("Topic Audience Restriction", "Audience the topic is offered to.", "Subscription", "Code", "Audience Restriction", "Financial Professional Use Only", "Internal", "", ""),
     ]),
     ("Communication Preference", [
       ("Preference Party", "Party whose preference this is.", "Subscription", "Reference (Party)", "", "PTY-55120", "Internal", "", "Y", "PII (link to individual)."),
       ("Preference Topic", "Subscription topic the preference applies to (blank = all marketing).", "Subscription", "Reference (Subscription Topic)", "", "SUB-004", "Internal", "", ""),
       ("Preference Channel", "Channel the preference applies to.", "Subscription", "Code", "Communication Channel", "Email", "Internal", "", "Y"),
       ("Opt-In Status", "Current preference for the topic and channel.", "Subscription", "Code", "Opt-In Status", "Opted In", "Internal", "GDPR", "Y", "PII."),
       ("Opt-In Method", "How the opt-in was captured.", "Subscription", "Code", "Opt-In Method", "Double Opt-In", "Internal", "UK PECR", ""),
       ("Opt-In Timestamp", "When the opt-in was captured.", "Subscription", "Timestamp", "ISO 8601", "2026-03-02T16:25:44Z", "GDPR", "", "", "PII; evidence of consent."),
       ("Double Opt-In Confirmed Timestamp", "When the confirmation link was clicked.", "Subscription", "Timestamp", "ISO 8601", "2026-03-02T16:31:09Z", "Internal", "", "", "PII."),
       ("Opt-Out Timestamp", "When the opt-out was received.", "Subscription", "Timestamp", "ISO 8601", "", "CAN-SPAM", "GDPR", "Y", "PII. CAN-SPAM: honour within 10 business days."),
       ("Opt-Out Source", "How the opt-out was received.", "Subscription", "Code", "Opt-Out Source", "Unsubscribe Link", "Internal", "", ""),
       ("Consent Record Reference", "Consent / legal-basis record in 02 that the preference relies on.", "Subscription", "Reference (Consent)", "", "CNS-00918231", "Internal", "GDPR", "", "Owned by 02 Client & Customer."),
     ]),
   ]),
   ("Suppression", "Lists of identifiers that must be excluded from marketing regardless of segment or preference.", [
     ("Suppression Entry", [
       ("Suppressed Identifier", "Email address, hashed email or phone number suppressed.", "Suppression", "Text", "", "sha256:4f1c...e9", "Internal", "", "Y", "PII (hashed where possible)."),
       ("Suppression Reason", "Why the identifier is suppressed.", "Suppression", "Code", "Suppression Reason", "Hard Bounce", "Internal", "CAN-SPAM", "Y"),
       ("Suppression Scope", "Breadth of the suppression.", "Suppression", "Code", "Suppression Scope", "Global", "Internal", "", ""),
       ("Suppression Effective From", "Date the suppression started.", "Suppression", "Date", "ISO 8601", "2026-08-11", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Lead Management", "MK-LED",
  "Marketing leads from capture through qualification (MQL / SQL), scoring, routing to sales and conversion to opportunities.",
  [
   ("Lead Capture", "Identity, source and captured details of a lead before and after party matching.", [
     ("Marketing Lead", [
       ("Lead ID", "Unique identifier of the lead.", "Lead", "Identifier", "", "LEAD-0091234", "Salesforce", "", "Y"),
       ("Lead Type", "Type of prospect the lead represents.", "Lead", "Code", "Lead Type", "Individual Advisor", "Internal", "", ""),
       ("Lead Party", "Party the lead is matched to (blank until matched).", "Lead", "Reference (Party)", "", "PTY-55120", "Internal", "", "Y", "PII (link to individual)."),
       ("Captured Name", "First and last name as captured.", "Lead", "Text", "", "Jordan Smith", "Salesforce", "", "", "PII."),
       ("Captured Email", "Email address as captured.", "Lead", "Text", "Email", "j.smith@exampleria.com", "Salesforce", "", "", "PII."),
       ("Captured CRD Number", "FINRA CRD number given by the lead, used for matching.", "Lead", "Identifier", "", "5123456", "Internal", "", "", "PII."),
       ("Lead Source", "Origin of the lead.", "Lead", "Code", "Lead Source", "Webinar", "Salesforce", "", "Y"),
       ("Original Campaign", "First campaign that generated the lead.", "Lead", "Reference (Campaign)", "", "CAM-004530", "Salesforce MCAE", "", "Y"),
     ]),
   ]),
   ("Qualification & Scoring", "Lead status, lifecycle stage, behavioural score and fit grade.", [
     ("Lead Qualification", [
       ("Lead Status", "Current qualification status of the lead.", "Lead", "Code", "Lead Status", "MQL", "Salesforce", "", "Y"),
       ("Lead Status Effective Timestamp", "When the current status took effect.", "Lead", "Timestamp", "ISO 8601", "2026-10-15T08:00:00Z", "Internal", "", ""),
       ("Lifecycle Stage", "Funnel lifecycle stage.", "Lead", "Code", "Lifecycle Stage", "Marketing Qualified Lead", "Salesforce MCAE", "", ""),
       ("Behaviour Score", "Points reflecting engagement behaviour.", "Lead", "Integer", "", "135", "Salesforce MCAE", "", "", "PII (profiling)."),
       ("Fit Grade", "Grade reflecting fit to the ideal profile.", "Lead", "Code", "Fit Grade", "A-", "Salesforce MCAE", "", "", "PII (profiling)."),
       ("Disqualification Reason", "Why the lead was disqualified.", "Lead", "Code", "Disqualification Reason", "Not a Financial Professional", "Internal", "", ""),
     ]),
   ]),
   ("Routing & Conversion", "Assignment of leads to sales and the outcome of sales follow-up.", [
     ("Lead Assignment", [
       ("Assigned Salesperson", "Salesperson the lead is routed to.", "Lead", "Reference (Employee)", "", "EMP-0233", "Salesforce", "", "Y", "Personnel owned by 03 Sales."),
       ("Assigned Territory", "Territory used to route the lead.", "Lead", "Reference (Territory)", "", "TER-US-WEST-03", "Internal", "", "", "Owned by 07; coverage rules applied, not redefined."),
       ("Follow-Up SLA Due", "When sales must first act on the lead.", "Lead", "Timestamp", "ISO 8601", "2026-10-17T08:00:05Z", "Internal", "", ""),
       ("First Sales Activity", "First sales activity logged against the lead.", "Lead", "Reference (Activity)", "", "ACT-20261016-7781", "Internal", "", "", "Owned by 03 Sales."),
     ]),
     ("Lead Conversion", [
       ("Conversion Outcome", "Outcome of sales follow-up.", "Lead", "Code", "Conversion Outcome", "Converted to Opportunity", "Salesforce", "", ""),
       ("Converted Opportunity", "Opportunity created from the lead.", "Lead", "Reference (Opportunity)", "", "OPP-0044710", "Salesforce", "", "Y", "Owned by 03 Sales."),
       ("Conversion Timestamp", "When the lead was converted.", "Lead", "Timestamp", "ISO 8601", "2026-10-22T15:10:00Z", "Salesforce", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Social & Paid Media", "MK-SOC",
  "Owned social media accounts, posts and engagement, social listening, and paid media placements, creatives and delivery metrics. Social media supervision and archiving are owned by 08 Distribution Compliance.",
  [
   ("Social Accounts & Posts", "Owned and employee-advocacy social accounts and the posts published on them.", [
     ("Social Media Account", [
       ("Social Account ID", "Unique identifier of the social account.", "Social Account", "Identifier", "", "SMA-0008", "Internal", "", "Y"),
       ("Social Platform", "Platform of the account.", "Social Account", "Code", "Social Platform", "LinkedIn", "Internal", "", ""),
       ("Account Handle", "Public handle or page URL.", "Social Account", "Text", "", "linkedin.com/company/example-investments", "Internal", "", "", "PII where the account belongs to an individual employee."),
       ("Social Account Type", "Type of account.", "Social Account", "Code", "Social Account Type", "Corporate Brand", "Internal", "FINRA Rule 2210", ""),
       ("Archiving Enrolled Indicator", "Whether the account is connected to the firm's archiving / supervision tool.", "Social Account", "Boolean", "", "Y", "Internal", "FINRA Rule 2210", "Y", "Archiving and supervision owned by 08."),
     ]),
     ("Social Post", [
       ("Platform Post ID", "Platform identifier of the post.", "Social Post", "Identifier", "", "urn:li:share:7244011223344556677", "Internal", "schema.org", "Y"),
       ("Post Timestamp", "When the post was published.", "Social Post", "Timestamp", "ISO 8601", "2026-10-14T12:00:00Z", "schema.org", "", ""),
       ("Post Content Classification", "Whether the post is static (pre-approved) or interactive content.", "Social Post", "Code", "Social Content Classification", "Static", "FINRA Rule 2210", "", "", "Static content typically requires pre-approval; classification confirmed by 08."),
       ("Post Campaign", "Campaign the post belongs to.", "Social Post", "Reference (Campaign)", "", "CAM-004512", "Internal", "", ""),
       ("Post Compliance Review", "Compliance review that approved the post.", "Social Post", "Reference (Compliance Review)", "", "REV-2026-02350", "Internal", "FCA COBS 4", "Y", "Owned by 08."),
     ]),
   ]),
   ("Social Engagement & Listening", "Engagement metrics for owned posts and mentions captured through social listening.", [
     ("Social Engagement Metrics", [
       ("Post Impressions", "Times the post was shown.", "Social Post", "Integer", "", "18450", "Internal", "", ""),
       ("Engagement Rate", "Engagements divided by impressions.", "Social Post", "Percentage", "", "3.3%", "Internal", "", ""),
     ]),
     ("Social Listening Mention", [
       ("Mention Sentiment", "Sentiment of the mention.", "Social Post", "Code", "Sentiment", "Negative", "Internal", "", ""),
       ("Mention Author Handle", "Handle of the person who posted.", "Social Post", "Text", "", "@investor123", "Internal", "", "", "PII."),
       ("Escalated Complaint", "Complaint record raised if the mention is a potential complaint.", "Social Post", "Reference (Complaint)", "", "CPL-2026-00318", "Internal", "", "", "Owned by 08."),
     ]),
   ]),
   ("Paid Media", "Paid placements, ad creatives and their delivery and spend.", [
     ("Media Placement", [
       ("Placement ID", "Unique identifier of the placement / line item.", "Placement", "Identifier", "", "PLC-2026-0771", "Internal", "", "Y"),
       ("Placement Campaign", "Campaign the placement belongs to.", "Placement", "Reference (Campaign)", "", "CAM-004512", "Internal", "", "Y"),
       ("Paid Media Channel", "Channel of the paid placement.", "Placement", "Code", "Paid Media Channel", "Paid Social", "Internal", "IAB", ""),
       ("Placement Geo Targeting", "Countries targeted.", "Placement", "Code (multi)", "ISO 3166-1 alpha-2", "US", "Internal", "", ""),
       ("Planned Placement Spend", "Planned spend for the placement.", "Placement", "Amount", "", "USD 20,000", "Internal", "", ""),
       ("Ad Creative Asset", "Approved creative used in the placement.", "Placement", "Reference (Content Asset)", "", "AST-018601", "Internal", "", ""),
       ("Ad Format", "Format / size of the creative.", "Placement", "Code", "Ad Format", "Single Image Sponsored Content", "IAB", "", ""),
     ]),
     ("Paid Media Delivery", [
       ("Impressions", "Impressions served.", "Placement", "Integer", "", "45210", "IAB", "", ""),
       ("Actual Spend", "Amount spent.", "Placement", "Amount", "", "USD 1,356.30", "Internal", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Performance & Attribution", "MK-ATR",
  "Marketing touchpoints, attribution models and the pipeline, sales and flows they are credited with, plus campaign performance snapshots.",
  [
   ("Touchpoints", "Engagements attributed to a party and campaign, forming the input to attribution.", [
     ("Marketing Touchpoint", [
       ("Touchpoint Party", "Person or firm that engaged.", "Touchpoint", "Reference (Party)", "", "PTY-55120", "Internal", "", "Y", "PII (link to individual)."),
       ("Touchpoint Timestamp", "When the engagement occurred.", "Touchpoint", "Timestamp", "ISO 8601", "2026-10-14T13:43:02Z", "Internal", "", "Y"),
       ("Touchpoint Type", "Type of engagement.", "Touchpoint", "Code", "Touchpoint Type", "Email Click", "Internal", "", ""),
       ("Touchpoint Campaign", "Campaign credited with the touchpoint.", "Touchpoint", "Reference (Campaign)", "", "CAM-004512", "Salesforce", "", "Y"),
       ("Source Event", "Engagement event, registration or sales activity the touchpoint derives from.", "Touchpoint", "Reference (Engagement Event / Activity)", "", "evt_9b1d2e7c", "Internal", "", "", "Sales activities (ACT-) owned by 03."),
     ]),
   ]),
   ("Attribution Models", "Rules that distribute credit for outcomes across touchpoints.", [
     ("Attribution Model", [
       ("Attribution Model Type", "Method of distributing credit.", "Attribution", "Code", "Attribution Model Type", "Position-Based (U-Shaped)", "Salesforce", "GA4", "Y"),
       ("Lookback Window", "Days before the outcome in which touchpoints are eligible.", "Attribution", "Integer", "Days", "180", "Internal", "GA4", ""),
       ("Primary Model Indicator", "Whether this is the firm's primary reporting model.", "Attribution", "Boolean", "", "Y", "Internal", "", ""),
     ]),
   ]),
   ("Attributed Outcomes", "Credit given to campaigns for opportunities, sales and flows.", [
     ("Attributed Outcome", [
       ("Outcome Type", "Type of business outcome attributed.", "Attribution", "Code", "Outcome Type", "Influenced Gross Sales", "Internal", "", ""),
       ("Attributed Opportunity", "Opportunity credited (pipeline outcomes).", "Attribution", "Reference (Opportunity)", "", "OPP-0044710", "Salesforce", "", "", "Owned by 03 Sales."),
       ("Attributed Flow Record", "Attributed flow or transaction record credited (sales / flow outcomes).", "Attribution", "Reference (Transaction)", "", "TXN-2026-11-0099812", "Internal", "", "", "Flows and their advisor attribution owned by 06; marketing does not recalculate."),
       ("Attributed Campaign", "Campaign receiving credit.", "Attribution", "Reference (Campaign)", "", "CAM-004512", "Salesforce", "", "Y"),
       ("Attribution Weight", "Share of the outcome credited to the campaign under the model.", "Attribution", "Percentage", "", "40%", "Salesforce", "", "Y"),
       ("Attributed Amount", "Outcome amount multiplied by the attribution weight.", "Attribution", "Amount", "", "USD 1,200,000", "Salesforce", "", "Y"),
     ]),
   ]),
   ("Campaign Performance", "Periodic performance snapshots per campaign.", [
     ("Campaign Performance Snapshot", [
       ("Snapshot Date", "As-of date of the snapshot.", "Campaign", "Date", "ISO 8601", "2026-11-30", "Internal", "", ""),
       ("Responses Count", "Number of members with a responded status.", "Campaign", "Integer", "", "611", "Salesforce", "", ""),
       ("MQLs Generated", "Leads that became MQL with this campaign as source or influence.", "Campaign", "Integer", "", "212", "Internal", "", ""),
       ("Influenced Pipeline Amount", "Value of opportunities influenced by the campaign.", "Campaign", "Amount", "", "USD 310,000,000", "Salesforce", "", ""),
       ("Influenced Net Flows", "Net flows attributed to the campaign under the primary model.", "Campaign", "Amount", "", "USD 42,500,000", "Internal", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Marketing Data Management", "MK-DMM",
  "Marketing technology system registry and the data management metadata applied to every marketing record.",
  [
   ("Marketing Systems", "Registry of martech systems and what they are system of record for.", [
     ("Marketing System", [
       ("System Name", "Name of the system.", "All", "Text", "", "Marketing Automation Platform", "Internal", "", ""),
       ("System Category", "Category of martech system.", "All", "Code", "Martech System Category", "Marketing Automation (MAP)", "Internal", "", ""),
     ]),
   ]),
   ("Record Metadata", "Metadata applied to every record in the marketing domain.", [
     ("Record Metadata", [
       ("Data Owner", "Business role accountable for the data element.", "All", "Reference (Employee)", "", "Head of Marketing Operations", "DCAM (EDM Council)", "", ""),
       ("Data Steward", "Role responsible for day-to-day data quality.", "All", "Reference (Employee)", "", "Marketing Data Steward", "DCAM (EDM Council)", "", ""),
       ("System of Record", "System holding the authoritative value.", "All", "Code", "Firm-defined", "DAM", "Internal", "", ""),
       ("Personal Data Classification", "Personal-data classification of the record.", "All", "Code", "Personal Data Classification", "Personal Data", "GDPR", "", "Y"),
       ("Record Effective From", "Business-effective start date of the record version.", "All", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Record Effective To", "Business-effective end date of the record version.", "All", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Last Updated Timestamp", "System timestamp of the last change.", "All", "Timestamp", "ISO 8601", "2026-09-30T17:45:00Z", "Internal", "", ""),
       ("Data Quality Status", "Validation status of the record.", "All", "Code", "Data Quality Status", "Validated", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Brand Level": ("Internal", [("Corporate Brand","Masterbrand of the group"),("Affiliate / Boutique Brand","Investment affiliate in a multi-boutique firm"),("Sub-Brand","Capability or business-line brand"),("Product Range Brand","Brand for a range, e.g. an ETF range"),("Co-Brand","Joint brand with a distributor or partner")]),
 "Brand Status": ("Internal", [("Planned",""),("Active",""),("Being Retired","Rebrand in progress"),("Retired","")]),
 "Theme Type": ("Internal", [("Market Outlook",""),("Product / Capability",""),("Thought Leadership",""),("Retirement",""),("Practice Management","Content that helps advisors run their business"),("Sustainability / ESG",""),("Brand / Corporate","")]),
 "Audience Type": ("Internal (aligned to 02 party classification)", [("Financial Advisor","Registered rep / IAR / adviser"),("Home Office / Gatekeeper","Research, due diligence, product and model teams at distributors"),("Institutional Investor","Pension, endowment, foundation, insurer, sovereign"),("Investment Consultant",""),("Retirement Plan Advisor",""),("Plan Sponsor",""),("Recordkeeper / Platform",""),("End Investor","Retail investor, where permitted"),("Media / Press",""),("Internal Employee","")]),
 "Campaign Level": ("Internal (Salesforce campaign hierarchy)", [("Programme","Annual or multi-quarter umbrella"),("Campaign","Planned initiative with objective, audience and budget"),("Wave","Time-boxed release within a campaign"),("Tactic","Single executable item: an email, ad set, webinar")]),
 "Campaign Type": ("Salesforce / Internal", [("Product Launch",""),("Thought Leadership",""),("Nurture",""),("Event Promotion",""),("Brand / Advertising",""),("Sales Enablement","Content and kits for wholesalers"),("Retention / Cross-Sell",""),("Reactivation",""),("Partner Co-Marketing","Run with a distributor or platform"),("Account-Based Marketing","Targeted at named firms / home offices")]),
 "Campaign Status": ("Salesforce", [("Planned",""),("Awaiting Compliance","Assets in review with 08"),("In Progress",""),("Completed",""),("Aborted","")]),
 "Campaign Objective": ("Internal", [("Awareness",""),("Lead Generation",""),("Pipeline Acceleration",""),("Sales / Flows",""),("Retention",""),("Event Attendance",""),("Platform / Home-Office Adoption","")]),
 "Marketing KPI": ("Internal", [("Reach / Impressions",""),("Engaged Visits",""),("Content Downloads",""),("Registrations",""),("Attendees",""),("MQLs",""),("SQLs",""),("Influenced Pipeline",""),("Influenced Gross Sales",""),("Influenced Net Flows","")]),
 "Business Channel": ("Internal (aligned to 02 / 03)", [("Wirehouse",""),("Regional Broker-Dealer",""),("Independent Broker-Dealer",""),("RIA",""),("Bank / Trust",""),("Private Bank",""),("IFA / Wealth Manager","UK / EU"),("Fund Platform",""),("Insurance",""),("Institutional Direct",""),("Investment Consultant",""),("DCIO / Retirement","")]),
 "Marketing Channel": ("Internal (aligned to Adobe XDM channel types)", [("Email",""),("Website",""),("Advisor Portal",""),("Mobile App",""),("Webinar",""),("In-Person Event",""),("Organic Social",""),("Paid Social",""),("Paid Search",""),("Programmatic Display",""),("Trade Media",""),("Direct Mail",""),("SMS",""),("Podcast",""),("Sales-Delivered","Wholesaler forwards or presents marketing content")]),
 "Product Role": ("Internal", [("Featured","Main subject of the campaign"),("Secondary",""),("Mentioned","")]),
 "Spend Category": ("Internal", [("Media",""),("Agency / Creative",""),("Event Venue & Logistics",""),("Sponsorship Fee",""),("Technology & Data",""),("Print & Fulfilment",""),("Speaker Fees",""),("Content / Data Licensing","")]),
 "UTM Medium": ("UTM / GA4 default channel grouping", [("email",""),("paid_social",""),("organic_social",""),("cpc","Paid search"),("display",""),("video",""),("referral",""),("affiliate","Partner / distributor sites"),("sms",""),("qr","Print / event QR codes")]),
 "Campaign Member Status": ("Salesforce (CampaignMember.Status)", [("Targeted","Not yet sent"),("Sent",""),("Opened",""),("Clicked","Counts as responded"),("Registered","Counts as responded"),("Attended","Counts as responded"),("No-Show",""),("Responded","Generic responded status"),("Unsubscribed","")]),
 "Content Type": ("Internal (aligned to 08 review categories)", [("Fact Sheet",""),("Market Commentary",""),("White Paper",""),("Fund / Strategy Presentation",""),("Product Brochure",""),("Video",""),("Podcast Episode",""),("Webinar Recording",""),("Article / Blog",""),("Social Post",""),("Advertisement",""),("Email Template",""),("Landing Page",""),("Interactive Tool / Calculator",""),("Sales Kit / Advisor Toolkit",""),("Client-Approved Template","Advisor-to-client template"),("Press Release","")]),
 "Audience Restriction": ("Internal (aligned to FINRA 2210, FCA COBS 4, ESMA guidelines)", [("Public / Retail","May be shown to anyone in permitted jurisdictions"),("Financial Professional Use Only","Advisor-use-only; not for use with the public"),("Institutional Use Only","Institutional investors as defined by the applicable rule"),("Professional Investors Only","EU / UK professional clients and eligible counterparties"),("Partner-Specific","Approved only for named distributor(s)"),("Client-Specific","Single client or prospect"),("Internal Use Only","")]),
 "FINRA Communication Category": ("FINRA Rule 2210", [("Retail Communication","More than 25 retail investors within 30 calendar days"),("Institutional Communication","Only institutional investors"),("Correspondence","25 or fewer retail investors within 30 calendar days")]),
 "Investor Category": ("MiFID II / FINRA / Internal", [("US Retail Investor",""),("US Institutional Investor","FINRA Rule 2210 / 4512(c)"),("US Financial Professional",""),("EU/UK Retail Client",""),("EU/UK Professional Client",""),("EU/UK Eligible Counterparty",""),("Accredited Investor / Qualified Purchaser","US private funds")]),
 "Content Topic": ("Internal (cross-check IAB Content Taxonomy for paid media)", [("Interest Rates",""),("Credit",""),("Equities",""),("Alternatives / Private Markets",""),("Multi-Asset",""),("Macro / Economy",""),("Retirement",""),("Tax",""),("Sustainability / ESG",""),("Practice Management",""),("Model Portfolios",""),("ETFs","")]),
 "Asset Lifecycle Status": ("Internal", [("Draft",""),("In Compliance Review","Submitted to 08"),("Approved","Approved, not yet published"),("Published",""),("Expired","Past expiry date; auto-withdrawn"),("Withdrawn","Removed early"),("Archived","Retained for records only")]),
 "Withdrawal Reason": ("Internal", [("Data Superseded","Newer as-of data available"),("Product Change","Product merged, closed or changed"),("Compliance Request",""),("Licence Expired",""),("Error Found",""),("Campaign Ended","")]),
 "Licence Type": ("IPTC / Internal", [("Owned","Firm-created or work-for-hire"),("Royalty-Free",""),("Rights-Managed",""),("Creative Commons",""),("Data / Index Licence","Index or data vendor licence")]),
 "WCAG Conformance Level": ("W3C WCAG 2.2", [("A",""),("AA","Target for public digital properties"),("AAA",""),("Not Assessed","")]),
 "Event Type": ("Internal", [("Hosted Conference",""),("Hosted Seminar",""),("Roadshow",""),("Webinar",""),("Due Diligence Forum","Home-office / gatekeeper event"),("Client Dinner / Hospitality",""),("Third-Party Conference (Attending)",""),("Third-Party Conference (Sponsoring)",""),("Branch / Office Presentation",""),("Study Group","Advisor study group")]),
 "Attendance Mode": ("schema.org eventAttendanceMode", [("Offline","OfflineEventAttendanceMode"),("Online","OnlineEventAttendanceMode"),("Mixed","MixedEventAttendanceMode")]),
 "Event Status": ("schema.org eventStatus", [("Scheduled","EventScheduled"),("Rescheduled","EventRescheduled"),("Postponed","EventPostponed"),("Moved Online","EventMovedOnline"),("Cancelled","EventCancelled"),("Completed","Internal extension")]),
 "Registration Status": ("Internal", [("Invited",""),("Registered",""),("Waitlisted",""),("Cancelled",""),("Attended",""),("Attended On-Demand",""),("No-Show",""),("Declined","")]),
 "CE Accrediting Body": ("CFP Board / IWI / others", [("CFP Board","CFP professionals"),("Investments & Wealth Institute","CIMA, CPWA, RMA"),("CFA Institute","Professional learning (self-reported)"),("NASBA / State CPA Boards","CPE"),("State Insurance Departments","Insurance CE"),("CII / PFS","UK CPD"),("CISI","UK CPD")]),
 "CE Subject Area": ("CFP Board CE / Internal", [("Investment Planning",""),("Retirement Savings & Income Planning",""),("Tax Planning",""),("Estate Planning",""),("Risk Management & Insurance",""),("Professional Conduct / Ethics",""),("General Principles of Financial Planning","")]),
 "CE Reporting Status": ("Internal", [("Pending",""),("Reported",""),("Rejected",""),("Not Eligible","E.g. insufficient attendance time or missing ID")]),
 "Sponsorship Tier": ("Internal", [("Title",""),("Platinum",""),("Gold",""),("Silver",""),("Exhibitor",""),("Session Sponsor","")]),
 "Property Type": ("Internal", [("Public Website",""),("Product / Fund Website",""),("Fund Literature Centre",""),("Advisor Portal","Authenticated"),("Institutional Client Portal","Authenticated"),("Mobile App",""),("Microsite / Landing Page",""),("Partner Syndication","Content syndicated to distributor platforms")]),
 "Property Status": ("Internal", [("Planned",""),("Live",""),("Being Decommissioned",""),("Decommissioned","")]),
 "Page Type": ("Internal", [("Home",""),("Product Page",""),("Insight / Article",""),("Literature Library",""),("Landing Page",""),("Event Page",""),("Form / Gate",""),("Legal / Disclosure","")]),
 "Form Purpose": ("Internal", [("Content Download Gate",""),("Subscription Sign-Up",""),("Event Registration",""),("Contact Request","Request contact from a wholesaler"),("Preference Centre",""),("Portal Registration","")]),
 "Gate Type": ("Internal", [("Jurisdiction Selector",""),("Investor-Type Declaration","E.g. 'I am a professional investor'"),("Login Required",""),("Partner SSO",""),("Form Fill","")]),
 "Declared Investor Type": ("Internal (aligned to FCA COBS 4 / MiFID / FINRA)", [("Individual / Retail Investor",""),("Professional Investor / Adviser",""),("Financial Professional (US)",""),("Institutional Investor",""),("Investment Consultant","")]),
 "Identity Namespace": ("Adobe XDM identity namespaces / Internal", [("First-Party Cookie ID",""),("GA Client ID",""),("GA User ID",""),("CRM Contact ID",""),("Marketing Automation ID",""),("Hashed Email","SHA-256"),("Portal Login ID",""),("Mobile Advertising ID","")]),
 "Identification Status": ("Internal", [("Anonymous",""),("Known - Unmatched","Identifier captured, no Party yet"),("Known - Matched","Resolved to a Party")]),
 "Identity Match Method": ("Internal", [("Form Submission",""),("Email Click-Through",""),("Authenticated Login",""),("Partner SSO",""),("Deterministic CRM Match",""),("Probabilistic","Lower confidence; not used for 1:1 targeting")]),
 "Tracking Consent Category": ("Internal (aligned to ePrivacy / PECR cookie categories)", [("Strictly Necessary","No consent required"),("Functional",""),("Analytics",""),("Marketing / Advertising","")]),
 "Engagement Event Type": ("GA4 / Adobe XDM", [("page_view",""),("file_download",""),("form_start",""),("form_submit",""),("view_search_results",""),("video_start",""),("video_progress",""),("video_complete",""),("login",""),("webinar_join",""),("tool_use","Interactive tool / calculator")]),
 "Email Send Type": ("CAN-SPAM", [("Commercial","Primary purpose is promotional"),("Transactional / Relationship",""),("Sales-Sent Marketing","Sent by a wholesaler from a marketing template")]),
 "Email Delivery Status": ("Adobe XDM directMarketing", [("Sent",""),("Delivered",""),("Soft Bounce",""),("Hard Bounce",""),("Blocked",""),("Deferred","")]),
 "Viewing Mode": ("Internal", [("Live",""),("Simulive","Pre-recorded, broadcast at a set time"),("On-Demand","")]),
 "Intent Provider": ("Internal", [("Bombora","Company Surge"),("Other B2B Intent Provider",""),("Distributor Platform Data","Activity on partner research platforms, where licensed")]),
 "Segment Type": ("Internal / Adobe XDM", [("Rule-Based (Dynamic)",""),("Static List",""),("Account-Based (ABM)",""),("Lookalike",""),("Exclusion","")]),
 "Subscription Category": ("Internal", [("Market Insights",""),("Product Updates",""),("Event Invitations",""),("Fund Literature Alerts",""),("Practice Management",""),("Operational Notices","Not marketing; not opt-out-able per topic")]),
 "Communication Channel": ("Internal", [("Email",""),("SMS",""),("Postal Mail",""),("Telephone",""),("Push Notification",""),("Paid Media Targeting","Use of identifiers for ad audiences")]),
 "Opt-In Status": ("Internal", [("Opted In",""),("Pending Confirmation","Awaiting double opt-in"),("Opted Out",""),("Not Set","No preference recorded")]),
 "Opt-In Method": ("Internal", [("Web Form",""),("Double Opt-In",""),("Event Registration",""),("Salesperson-Recorded","Verbal / written request via wholesaler"),("Imported","Legacy or third-party list")]),
 "Opt-Out Source": ("Internal", [("Unsubscribe Link",""),("Preference Centre",""),("Email Reply / Request",""),("Salesperson Request",""),("Complaint",""),("Data Subject Request","Received via 02 / Privacy")]),
 "Suppression Reason": ("Internal", [("Global Unsubscribe",""),("Hard Bounce",""),("Spam Complaint",""),("Do Not Contact","Legal / client request"),("Competitor",""),("Regulatory Restriction","E.g. jurisdiction or firm prohibits contact"),("Internal Employee",""),("Deceased","")]),
 "Suppression Scope": ("Internal", [("Global","All marketing"),("Channel",""),("Topic",""),("Brand","")]),
 "Lead Type": ("Internal", [("Individual Advisor",""),("Home Office / Gatekeeper",""),("Institutional Prospect",""),("Investment Consultant",""),("Plan Sponsor",""),("Firm-Level (ABM)","")]),
 "Lead Source": ("Salesforce / Internal", [("Website Form",""),("Content Download",""),("Webinar",""),("Event",""),("Paid Media",""),("Social",""),("Intent Data",""),("Partner Referral",""),("Purchased / Rented List",""),("Sales-Created","")]),
 "Lead Status": ("Internal (aligned to MQL / SAL / SQL funnel)", [("New",""),("Nurture",""),("MQL","Marketing qualified"),("SAL","Sales accepted"),("SQL","Sales qualified"),("Converted",""),("Recycled","Returned to nurture"),("Disqualified","")]),
 "Lifecycle Stage": ("Salesforce MCAE lifecycle stages", [("Visitor",""),("Prospect",""),("Marketing Qualified Lead",""),("Sales Qualified Lead",""),("Won Opportunity","")]),
 "Fit Grade": ("Salesforce MCAE grading", [("A+",""),("A",""),("A-",""),("B+",""),("B",""),("B-",""),("C+",""),("C",""),("C-",""),("D+",""),("D",""),("D-",""),("F","")]),
 "Disqualification Reason": ("Internal", [("Not a Financial Professional",""),("Non-Permitted Jurisdiction",""),("Competitor",""),("Student / Job Seeker",""),("Duplicate",""),("Invalid Contact Data","")]),
 "Conversion Outcome": ("Salesforce / Internal", [("Converted to Opportunity",""),("Converted to Contact Only",""),("Merged",""),("Rejected","")]),
 "Social Platform": ("Internal", [("LinkedIn",""),("X",""),("YouTube",""),("Instagram",""),("Facebook",""),("Threads",""),("Other","")]),
 "Social Account Type": ("Internal (aligned to FINRA social media guidance)", [("Corporate Brand",""),("Product / Capability Brand",""),("Executive / Portfolio Manager",""),("Employee Advocacy / Wholesaler","")]),
 "Social Content Classification": ("FINRA Rule 2210 / FINRA Regulatory Notices on social media", [("Static","Pre-approved content"),("Interactive","Real-time interaction; supervised post-use"),("Third-Party Shared","Shared or linked third-party content")]),
 "Sentiment": ("Internal", [("Positive",""),("Neutral",""),("Negative",""),("Mixed","")]),
 "Paid Media Channel": ("Internal (cross-check IAB)", [("Paid Social",""),("Paid Search",""),("Programmatic Display",""),("Native",""),("Online Video / CTV",""),("Audio / Podcast",""),("Trade Publication - Digital",""),("Trade Publication - Print",""),("Sponsored Newsletter",""),("Out-of-Home","")]),
 "Ad Format": ("IAB New Ad Portfolio / platform formats", [("300x250 Medium Rectangle",""),("728x90 Leaderboard",""),("160x600 Skyscraper",""),("320x50 Mobile Banner",""),("Single Image Sponsored Content",""),("Carousel",""),("Video 15s",""),("Video 30s",""),("Native In-Feed",""),("Sponsored Message","")]),
 "Touchpoint Type": ("Internal", [("Email Click",""),("Web Visit",""),("Content Download",""),("Form Submission",""),("Event Attendance",""),("Webinar Attendance",""),("Paid Media Click",""),("Social Engagement",""),("Sales Activity","Meeting / call logged in 03")]),
 "Attribution Model Type": ("Salesforce Campaign Influence / GA4 / Internal", [("First Touch",""),("Last Touch",""),("Linear / Even",""),("Time Decay",""),("Position-Based (U-Shaped)","40/20/40"),("W-Shaped",""),("Data-Driven","Algorithmic")]),
 "Outcome Type": ("Internal", [("Opportunity Created",""),("Opportunity Won",""),("Influenced Pipeline",""),("Influenced Gross Sales",""),("Influenced Net Flows",""),("Platform / Model Placement",""),("New-to-Firm Advisor","First purchase by an advisor")]),
 "Martech System Category": ("Internal", [("CRM",""),("Marketing Automation (MAP)",""),("Customer Data Platform (CDP)",""),("Digital Asset Management (DAM)",""),("Content Management (CMS)",""),("Web Analytics",""),("Tag / Consent Management",""),("Event Management",""),("Webinar Platform",""),("Social Publishing",""),("Social Archiving","Operated for 08"),("Ad Platform / DSP",""),("Intent Data Provider","")]),
 "Personal Data Classification": ("GDPR / Internal", [("No Personal Data",""),("Pseudonymised Personal Data","E.g. cookie IDs, hashed emails"),("Personal Data",""),("Special Category Data","GDPR Art. 9")]),
 "Data Quality Status": ("Internal", [("Validated",""),("Pending Validation",""),("Exception",""),("Deprecated","")]),
}

# ---------------------------------------------------------------------------
# Relationships, sources
# ---------------------------------------------------------------------------
REL = [
 ("Brand","is parent of","Brand","1 : 0..n","Brand architecture."),
 ("Marketing Theme","is expressed by","Messaging Pillar","1 : 1..n",""),
 ("Campaign (Programme)","contains","Campaign (Campaign / Wave / Tactic)","1 : 0..n","Self-referencing hierarchy via Parent Campaign."),
 ("Campaign","executes","Marketing Theme","n : 0..1",""),
 ("Campaign","promotes","Product / Share Class (01 Product, PRD- / SHC-)","n : n","Via Campaign Product with Product Role."),
 ("Campaign","targets","Territory (07 Compensation & Territory, TER-)","n : n","For wholesaler alignment only; territory rules are not redefined."),
 ("Campaign","is co-funded under","Agreement (05 Agreements, AGR-)","n : 0..1","Partner co-marketing."),
 ("Campaign","has","Campaign Member","1 : 0..n",""),
 ("Campaign Member","is","Party (02 Client & Customer, PTY-) or Marketing Lead","n : 1",""),
 ("Campaign","is tracked by","Campaign Tracking Code","1 : 0..n","utm_id = Campaign ID."),
 ("Campaign","deploys","Content Asset / Marketing Event / Email Send / Social Post / Media Placement","1 : 0..n",""),
 ("Content Asset","is approved under","Compliance Review (08 Distribution Compliance, REV-)","n : 1","Per version; approval status mirrored read-only."),
 ("Content Asset","features","Product / Share Class (01 Product, PRD- / SHC-)","n : n",""),
 ("Content Asset","is derived from","Content Asset","n : 0..1","E.g. social cut-down of a webinar recording."),
 ("Marketing Event","has","Event Session / Event Speaker","1 : 0..n","Speakers are EMP- (03) or PTY- (02)."),
 ("Marketing Event","has","Event Registration","1 : 0..n",""),
 ("Event Registration","may create","Gifts & Entertainment record (08, GNE-)","1 : 0..1","When hospitality is provided."),
 ("Event Registration","may earn","CE Credit Issued","1 : 0..1",""),
 ("Event Sponsorship","is paid under","Agreement (05 Agreements, AGR-)","n : 1","Conference sponsorship payment arrangement."),
 ("Digital Property","contains","Web Page / Web Form / Access Gate","1 : 0..n",""),
 ("Web Visitor","makes","Self-Certification Record","1 : 0..n",""),
 ("Web Visitor","is resolved to","Party (02 Client & Customer, PTY-)","n : 0..1","Identity resolution; consent and legal basis held in 02."),
 ("Web Visitor","generates","Engagement Event","1 : 0..n",""),
 ("Email Send","produces","Email Interaction","1 : 0..n","One per recipient."),
 ("Marketing Segment","includes","Party (02 Client & Customer, PTY-)","n : n","Via effective-dated Segment Membership."),
 ("Party (02, PTY-)","holds","Communication Preference","1 : 0..n","Per Subscription Topic and Channel; references 02 consent record."),
 ("Communication Preference","references","Consent Record (02 Client & Customer)","n : 0..1","Legal basis owned by 02."),
 ("Marketing Lead","is routed to","Employee (03 Sales, EMP-) / Territory (07, TER-)","n : 0..1",""),
 ("Marketing Lead","converts to","Opportunity (03 Sales, OPP-)","1 : 0..1",""),
 ("Social Post","is approved under","Compliance Review (08, REV-)","n : 0..1","Archiving and supervision owned by 08."),
 ("Social Listening Mention","may raise","Complaint (08, CPL-)","1 : 0..1",""),
 ("Media Placement","uses","Content Asset (Ad Creative)","n : 1..n",""),
 ("Engagement Event / Event Registration / Sales Activity (03, ACT-)","becomes","Marketing Touchpoint","1 : 0..1","When attributable to a Party and Campaign."),
 ("Attributed Outcome","credits","Campaign","n : 1","Under one Attribution Model."),
 ("Attributed Outcome","references","Opportunity (03, OPP-) / Transaction (06, TXN-)","n : 1","Pipeline from 03; flows and advisor attribution from 06."),
]

SRC = [
 ("Salesforce Sales Cloud object reference (Campaign, CampaignMember, Lead, Campaign Influence)","Salesforce","https://developer.salesforce.com/docs/atlas.en-us.object_reference.meta/object_reference/sforce_api_objects_campaign.htm","Public documentation","Campaign hierarchy (ParentId), Type, Status, BudgetedCost, ActualCost, ExpectedRevenue; CampaignMember Status / HasResponded; Lead source / status / conversion; campaign influence","Campaign Management, Campaign Membership, Lead Management, Attribution",["Salesforce"]),
 ("Salesforce Marketing Cloud Account Engagement (Pardot) API - Prospect, Lifecycle Stage","Salesforce","https://developer.salesforce.com/docs/marketing/pardot/guide/lifecycle-stage-v5.html","Public documentation","Prospect score and grade, lifecycle stages (Visitor > Prospect > MQL > SQL > Won), forms, subscription lists","Lead Qualification & Scoring, Subscription Topic, Web Form",["Salesforce MCAE"]),
 ("Adobe Experience Data Model (XDM)","Adobe","https://github.com/adobe/xdm","Open source (Apache 2.0 / CC-BY)","ExperienceEvent class, identity namespaces, Web Details, Direct Marketing (email sent / delivered / opened / clicked / bounced / unsubscribed) and Campaign Marketing field groups","Digital Identity & Engagement, Email Engagement, Segments",["Adobe XDM"]),
 ("Adobe Experience League - XDM ExperienceEvent and Web Details field group","Adobe","https://experienceleague.adobe.com/en/docs/experience-platform/xdm/classes/experienceevent","Public documentation","Event _id, timestamp, eventType values; web.webPageDetails","Engagement Event, Web Page",[]),
 ("Google Analytics 4 - enhanced measurement events and UTM / campaign parameters","Google","https://support.google.com/analytics/answer/9216061","Public documentation","Event model (page_view, file_download, form_submit, video_progress, view_search_results) and parameters; utm_id, utm_source_platform, utm_creative_format, utm_marketing_tactic","Tracking Codes, Session, Engagement Event, Media Engagement",["GA4"]),
 ("UTM parameter convention (Urchin Tracking Module)","Google (de facto standard)","https://support.google.com/analytics/answer/10917952","Public documentation","utm_source, utm_medium, utm_campaign, utm_term, utm_content","Campaign Tracking Code",["UTM"]),
 ("DCMI Metadata Terms (Dublin Core)","Dublin Core Metadata Initiative","https://www.dublincore.org/specifications/dublin-core/dcmi-terms/","Open (CC BY 4.0)","title, description, creator, publisher, type, format, language, subject, rights, source, issued, replaces","Content Asset identity, classification and versioning",["Dublin Core"]),
 ("IPTC Photo Metadata Standard","IPTC","https://iptc.org/standards/photo-metadata/iptc-standard/","Open (CC BY 4.0)","Copyright Notice, Credit Line, Web Statement of Rights, Rights Usage Terms (XMP), Model Release Status, Keywords, Alt Text (Accessibility), Extended Description","Asset Rights, Accessibility",["IPTC"]),
 ("Adobe XMP specification (ISO 16684-1)","Adobe / ISO","https://www.adobe.com/devnet/xmp.html","Open specification; ISO purchase","Embedded metadata container for DAM assets (xmpRights, xmpMM version / document IDs)","Asset Version, Rights (secondary reference)",[]),
 ("schema.org Event and CreativeWork","schema.org","https://schema.org/Event","Open (CC BY-SA 3.0)","Event name, startDate, endDate, location, organizer, eventAttendanceMode, eventStatus; CreativeWork / SocialMediaPosting / VideoObject duration","Marketing Event, Social Post, Media Duration",["schema.org"]),
 ("W3C Web Content Accessibility Guidelines (WCAG) 2.2","W3C","https://www.w3.org/TR/WCAG22/","Open (W3C licence)","Text alternatives, captions, conformance levels A / AA / AAA","Asset Accessibility, Digital Properties",["WCAG 2.2"]),
 ("FINRA Rule 2210 - Communications with the Public (and social media Regulatory Notices)","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2210","Regulation (US broker-dealers)","Retail communication / institutional communication / correspondence definitions; approval, filing and record-keeping; static vs interactive social content","Audience Restriction, FINRA Communication Category, Social Accounts & Posts (reference only; owned by 08)",["FINRA Rule 2210"]),
 ("SEC Marketing Rule - Investment Advisers Act Rule 206(4)-1","US SEC","https://www.sec.gov/rules-regulations/2020/12/investment-adviser-marketing","Regulation (US advisers)","Advertisement definition; testimonials, endorsements, third-party ratings; performance and hypothetical performance","Compliance Linkage indicators, Data As-Of Date (reference only; owned by 08)",["SEC Marketing Rule"]),
 ("FCA Handbook COBS 4 (financial promotions) and FG24/1 (social media)","UK FCA","https://www.handbook.fca.org.uk/handbook/COBS/4/","Regulation (UK)","Fair, clear and not misleading; communicating to professional vs retail clients; investor-type gating; social media promotions","Audience Restriction, Gating & Self-Certification, Social Post (secondary reference; owned by 08)",[]),
 ("ESMA Guidelines on marketing communications (ESMA34-45-1272) under Regulation (EU) 2019/1156","ESMA","https://www.esma.europa.eu/document/guidelines-marketing-communications-under-regulation-cross-border-distribution-funds","Guidelines (EU, applicable from 2 Feb 2022)","Identification as marketing communication; risks and rewards; costs; past and future performance; sustainability claims","Audience Restriction, Compliance Linkage indicators (reference only; owned by 08)",["ESMA Marketing Guidelines"]),
 ("CAN-SPAM Act: A Compliance Guide for Business","US FTC","https://www.ftc.gov/business-guidance/resources/can-spam-act-compliance-guide-business","Regulation (US)","Commercial vs transactional email, non-misleading headers and subject lines, opt-out honoured within 10 business days","Email Send Type, Subject Line, Opt-Out, Suppression",["CAN-SPAM"]),
 ("GDPR / UK GDPR","EU / UK ICO","https://eur-lex.europa.eu/eli/reg/2016/679/oj","Regulation","Personal data, consent conditions, profiling and objection, special-category data","PII flags, Opt-In evidence, Personal Data Classification (legal basis owned by 02)",["GDPR"]),
 ("ePrivacy Directive / UK PECR","EU / UK ICO","https://ico.org.uk/for-organisations/direct-marketing-and-privacy-and-electronic-communications/","Regulation","Cookie consent and electronic direct marketing consent (soft opt-in)","Tracking Consent Category, Opt-In Method",["UK PECR"]),
 ("CASL (Canada's Anti-Spam Legislation)","Government of Canada / CRTC","https://crtc.gc.ca/eng/internet/anti.htm","Regulation (Canada)","Express vs implied consent; unsubscribe within 10 business days","Noted for completeness if Canadian advisors are targeted; not in current US + EU/UK scope",[]),
 ("CFP Board Continuing Education policies and CE sponsor resources","CFP Board","https://www.cfp.net/for-cfp-professionals/continuing-education/continuing-education-policies","Public","CE hours (50-minute hour, half-hour increments), subject areas, delivery methods, sponsor reporting within 14 days","CE Accreditation, CE Credit Issued",["CFP Board CE"]),
 ("Investments & Wealth Institute CE sponsor programme (CIMA / CPWA / RMA)","Investments & Wealth Institute","https://investmentsandwealth.org/certifications/ce-sponsors","Public","Registered CE sponsor programme; 40 hours every two years incl. ethics","CE Accreditation (secondary reference)",[]),
 ("IAB Tech Lab Taxonomies (Content, Audience, Ad Product) and ad format guidelines","IAB Tech Lab","https://github.com/InteractiveAdvertisingBureau/Taxonomies","Open (CC BY 3.0)","Standard content / audience categories and ad formats for paid media","Paid Media Channel, Ad Format, Content Topic cross-check",["IAB"]),
 ("Bombora Company Surge","Bombora","https://customers.bombora.com/crc-brand/thresholding","Commercial (licensed data)","Topic-level intent score 0-100; 60+ considered surging; weekly refresh","Third-Party Intent Signal",["Bombora"]),
 ("ISO 4217 / ISO 3166-1 / ISO 639-1 / ISO 8601 / IANA Time Zones / IANA Media Types","ISO; IANA","https://www.iso.org","Standard; code lists widely available","Currency, country, language, date / time, time zone and MIME type codes","Reference code lists used throughout",["ISO 4217"]),
 ("DCAM","EDM Council","https://edmcouncil.org","Member framework","Data ownership and stewardship","Marketing Data Management",["DCAM*"]),
]
