"""Business domain 05 - Distribution Agreements & Partners. Content module for taxonomy_builder.py."""

META = {
 "title": "Distribution Agreements & Partners Data Taxonomy",
 "subtitle": "Business domain 05 - Distribution Agreements & Partners | Asset manager (wholesale distributor) | Scope: US + EU/UK | Draft v0.1 | 2026-10-01",
 "output": "05_Distribution_Agreements_and_Partners/Distribution_Agreements_and_Partners_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the agreements an asset manager holds with its distribution partners, the payments made under them, the partner programmes it participates in, and the status of its products on each partner's shelf. Built from US regulation (SEC Rule 12b-1, FINRA Rule 2341, Regulation Best Interest, ERISA 408(b)(2), SEC staff guidance on sub-accounting fees), EU/UK regulation (MiFID II inducements and costs & charges, FCA COBS RDR and platform rules), and industry infrastructure and data standards (DTCC NSCC Fund/SERV and Networking, ISO 20022 funds messages, FinDatEx EMT). Use it as a starting point for an agreements repository, a partner-payments engine, a shelf/availability master, a data catalogue or a business glossary."),
  ("Scope", "In scope: agreement master (selling/dealer, distribution, platform, sub-TA/networking/omnibus servicing, revenue-sharing, DCIO/recordkeeper, model delivery/SMA sponsor, data licensing, placement agent, nominee, retrocession/rebate, Rule 22c-2 shareholder information); agreement scope by product, share class, jurisdiction, channel and investor type; payment and fee arrangements, rate schedules, caps and the partner payment cycle (calculation, invoice, payment); partner programmes and access rights; product shelf, approved/recommended/focus list and model-eligibility status, research ratings and watch lists by partner; partner operational set-up (dealer numbers, dealing and settlement routes, omnibus/networking set-up, data feed arrangements); partner-facing disclosures (revenue-sharing, 408(b)(2), MiFID costs & charges/EMT exchange); contract obligations and SLAs. Out of scope (referenced by ID only): party master and party identifiers such as CRD, LEI and firm hierarchy (02_Client_and_Customer, PTY-/ACC-); products, share classes, fees and product registrations (01_Product, PRD-/SHC-/MDL-); sales personnel, opportunities and DDQ/RFP responses (03_Sales, EMP-/OPP-/RFP-); events and campaigns (04_Marketing_and_Digital, EVT-/CAM-); transactions, positions, AUM and data-feed technical definitions (06_Sales_Transactions_and_AUM_Attribution, TXN-/POS-/FEED-); crediting rules and wholesaler compensation (07_Compensation_and_Territory); inducement assessments, distributor due diligence, non-cash compensation registers and marketing review (08_Distribution_Compliance, REV-/DDQ-/GNE-). General-ledger accounting of accruals is out of scope (Finance)."),
  ("Structure", "Four levels: Domain > Subdomain > Concept > Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Agreement (AGR-) between the firm's contracting entity and a Partner (PTY-) -> Agreement Scope (which products/share classes, jurisdictions, channels, investor and account types it covers) -> Payment Arrangements under the agreement (type, funding source, rate schedule and tiers, caps, payment terms) -> Payment Calculation -> Partner Invoice -> Partner Payment. Alongside the agreement: Partner Programme (PGM-) membership and benefits; Shelf Placement of a product/share class on a partner list or advisory programme with its Research Rating; Partner Operational Set-up (dealer number, dealing route, networking level, data feeds); Disclosures; Obligations and SLAs."),
  ("Design principles", "1) Separate the contract (agreement, scope, terms) from the money (payment arrangement, calculation, invoice, payment) and from shelf status, so each can change on its own effective dates. 2) Make funding source explicit on every payment arrangement: fund-paid under a Rule 12b-1 plan, fund-paid for non-distribution servicing (sub-TA), or paid by the adviser/distributor 'from own resources'. 3) Capture EU/UK inducement relevance on each arrangement and reference, rather than duplicate, the compliance assessment owned by 08. 4) Reference parties, products, accounts, feeds, employees and compliance records by ID; never copy their attributes. 5) Effective-date every status, rate, tier, placement and rating. 6) Use controlled code lists; normalise partner-specific ratings and list names to a firm scale while keeping the partner's own value."),
  ("Applies To", "Shows the record type each attribute is held on: Agreement, Agreement Party, Amendment, Agreement Document, Product Coverage, Distribution Scope, Account Link, Payment Arrangement, Rate Schedule, Rate Tier, Payment Calculation, Partner Invoice, Partner Payment, Programme, Programme Membership, Programme Benefit, Shelf Placement, Research Rating, Model Placement, Dealer Setup, Trading Setup, Networking Setup, Data Feed Arrangement, Disclosure, Obligation, SLA or All."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify an agreement or partner arrangement, calculate or pay partner fees correctly, evidence regulatory disclosure, or determine whether a product can be sold through a partner. Confirm with data owners."),
  ("Primary / Secondary Reference", "Standard, regulation or market infrastructure the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition (most contract and commercial terms fall here). Next step: map FinDatEx EMT- and ISO 20022-aligned attributes to exact field / message element IDs in the versions in use."),
  ("Tabs", "Hierarchy: domains, subdomains and concepts with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: concept-level cardinalities, including references to other business domains | Sources: standards used, owners, licences and links."),
  ("Suggested next steps", "1) Validate with Distribution / National Accounts, Legal, Intermediary Oversight, Fund Treasurer / Finance, Transfer Agency Operations and Compliance. 2) Inventory current agreements and payment arrangements and load a pilot of the top 20 partners. 3) Map attributes to source systems (contract repository, intermediary fee engine such as Broadridge or SS&C, TA, CRM, platform portals). 4) Agree the firm-normalised shelf and research-rating scales with Sales. 5) Confirm boundary with 06 (basis data for calculations) and 08 (inducement and due-diligence records). 6) Turn the Relationships tab into a logical data model."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

D("Agreement Master", "DA-AGR",
  "The contracts between the firm and its distribution partners: what kind of agreement it is, who the parties are, its term, amendments and side letters, and the executed documents.",
  [
   ("Agreement Definition", "Core identity, type and status of a distribution-related agreement.", [
     ("Distribution Agreement", [
       ("Agreement ID", "Unique internal identifier for the agreement.", "Agreement", "Identifier", "", "AGR-004512", "Internal", "", "Y"),
       ("Agreement Name", "Business name of the agreement as used in the contract repository and partner reporting.", "Agreement", "Text", "", "Wirehouse A - Revenue Sharing & Marketing Support Agreement 2024", "Internal", "", "Y"),
       ("Agreement Type", "Primary type of the agreement, which determines the terms and payment arrangements it can carry.", "Agreement", "Code", "Agreement Type", "Revenue Sharing / Marketing Support Agreement", "Internal", "FINRA Rule 2341", "Y"),
       ("Agreement Paper", "Whose standard form the agreement is based on, which drives negotiability and review effort.", "Agreement", "Code", "Agreement Paper", "Partner Paper", "Internal", "", ""),
       ("Master Agreement", "Reference to the master or framework agreement this agreement is a schedule or child of.", "Agreement", "Reference (Agreement)", "", "AGR-000210", "Internal", "", ""),
       ("Agreement Market", "Market or regulatory region the agreement is written for.", "Agreement", "Code", "Agreement Market", "US", "Internal", "", ""),
       ("Agreement Status", "Current lifecycle status of the agreement.", "Agreement", "Code", "Agreement Status", "Active", "Internal", "", "Y"),
       ("Governing Law", "Law that governs the agreement.", "Agreement", "Code", "Governing Law", "New York", "Internal", "", "Y"),
       ("Business Owner", "Internal employee accountable for the partner relationship and the agreement's commercial terms.", "Agreement", "Reference (Employee)", "", "EMP-01177", "Internal", "", "Y"),
       ("Most-Favoured-Nation Clause Indicator", "Whether the partner has a most-favoured-nation (MFN) right on pricing or terms compared with peer partners.", "Agreement", "Boolean", "", "N", "Internal", "", ""),
       ("Exclusivity Indicator", "Whether the agreement grants or requires exclusivity (for example, sole sub-advisor slot or exclusive model provider).", "Agreement", "Boolean", "", "N", "Internal", "", ""),
       ("Distributor Due Diligence Reference", "Reference to the latest know-your-distributor due diligence record for the partner, owned by Distribution Compliance.", "Agreement", "Reference (Distributor Due Diligence)", "", "DDQ-02231", "Internal", "", ""),
     ]),
   ]),
   ("Agreement Parties", "Parties to the agreement and the role each plays, including the firm's own contracting entities.", [
     ("Agreement Party Role", [
       ("Agreement Party", "Party who signs or is named in the agreement, from the party master.", "Agreement Party", "Reference (Party)", "", "PTY-3301", "Internal", "", "Y"),
       ("Agreement Party Role", "Role the party plays in the agreement.", "Agreement Party", "Code", "Agreement Party Role", "Selling Dealer", "Internal", "FINRA Rule 2341", "Y"),
       ("Firm Contracting Entity Indicator", "Whether the party is one of the firm's own legal entities (principal underwriter, adviser, management company) rather than the partner.", "Agreement Party", "Boolean", "", "Y", "Internal", "", ""),
       ("Signatory Name", "Name of the individual who signed for the party.", "Agreement Party", "Text", "", "Jane Smith", "Internal", "", "", "PII"),
       ("Notice Contact", "Contact designated to receive formal notices under the agreement.", "Agreement Party", "Reference (Party)", "", "PTY-3301-C04", "Internal", "", "", "PII"),
       ("Party Role Effective From", "Date the party's role in the agreement started (for example, after assignment or novation).", "Agreement Party", "Date", "ISO 8601", "2024-04-01", "Internal", "", ""),
       ("Party Role Effective To", "Date the party's role in the agreement ended.", "Agreement Party", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Term, Renewal & Termination", "When the agreement starts and ends, how it renews and the notice periods that apply.", [
     ("Agreement Term", [
       ("Execution Date", "Date the agreement was fully executed by all parties.", "Agreement", "Date", "ISO 8601", "2024-03-20", "Internal", "", ""),
       ("Agreement Effective Date", "Date from which the agreement's terms apply.", "Agreement", "Date", "ISO 8601", "2024-04-01", "Internal", "", "Y"),
       ("Term Type", "How the agreement's term is structured.", "Agreement", "Code", "Term Type", "Auto-Renewing", "Internal", "", ""),
       ("Initial Term End Date", "End date of the initial fixed term, if any.", "Agreement", "Date", "ISO 8601", "2027-03-31", "Internal", "", ""),
       ("Next Renewal Date", "Next date on which the agreement renews or expires unless action is taken.", "Agreement", "Date", "ISO 8601", "2027-04-01", "Internal", "", "Y"),
       ("Renewal Notice Period", "Days' notice required to prevent automatic renewal or to renegotiate.", "Agreement", "Integer", "Days", "90", "Internal", "", ""),
       ("Termination Notice Period", "Days' notice either party must give to terminate without cause.", "Agreement", "Integer", "Days", "60", "Internal", "", ""),
       ("Termination Date", "Date the agreement terminated or will terminate.", "Agreement", "Date", "ISO 8601", "", "Internal", "", "Y"),
       ("Termination Reason", "Reason the agreement was terminated.", "Agreement", "Code", "Termination Reason", "Replaced by New Agreement", "Internal", "", ""),
       ("Termination Initiated By", "Which side initiated termination.", "Agreement", "Code", "Initiating Party", "Partner", "Internal", "", ""),
       ("Post-Termination Payment Period", "Months for which payments (for example, trails on existing assets) continue after termination.", "Agreement", "Integer", "Months", "3", "Internal", "", ""),
     ]),
   ]),
   ("Amendments & Side Letters", "Effective-dated changes to an agreement: amendments, side letters, replacement schedules, assignments.", [
     ("Agreement Amendment", [
       ("Amendment ID", "Unique identifier for the amendment or side letter.", "Amendment", "Identifier", "", "AGR-004512-A03", "Internal", "", ""),
       ("Amendment Type", "Type of change instrument.", "Amendment", "Code", "Amendment Type", "Fee Schedule Replacement", "Internal", "", ""),
       ("Amendment Effective Date", "Date the amendment's changes take effect.", "Amendment", "Date", "ISO 8601", "2026-01-01", "Internal", "", "Y"),
       ("Amendment Summary", "Plain-language summary of what changed.", "Amendment", "Text", "", "Asset-based rate reduced from 15 bps to 12 bps; ETFs added to Schedule A", "Internal", "", ""),
       ("Confidential Side Letter Indicator", "Whether the instrument is a side letter whose terms are restricted to named internal users.", "Amendment", "Boolean", "", "N", "Internal", "", ""),
     ]),
   ]),
   ("Agreement Documents", "Executed documents and exhibits held in the contract repository.", [
     ("Agreement Document", [
       ("Agreement Document ID", "Identifier of the document in the contract repository.", "Agreement Document", "Identifier", "", "DOC-77821", "Internal", "", ""),
       ("Agreement Document Type", "Type of document.", "Agreement Document", "Code", "Agreement Document Type", "Executed Agreement", "Internal", "", ""),
       ("Agreement Document Location", "URI or repository path of the document.", "Agreement Document", "Text", "URI", "https://clm.example.com/agreements/AGR-004512/executed.pdf", "Internal", "", ""),
       ("Document Retention End Date", "Date until which the document must be kept under record-keeping rules.", "Agreement Document", "Date", "ISO 8601", "2033-03-31", "SEC Rule 17a-4", "", ""),
     ]),
   ]),
  ])

D("Agreement Scope", "DA-SCP",
  "What an agreement covers: products, share classes and models; jurisdictions, channels, investor and account types; and the accounts linked to it.",
  [
   ("Product Coverage", "Products, share classes and models included in or excluded from the agreement.", [
     ("Agreement Product Coverage", [
       ("Coverage Basis", "How the agreement's product coverage is expressed.", "Product Coverage", "Code", "Coverage Basis", "Specific Products", "Internal", "", ""),
       ("Covered Product", "Product included in or excluded from the agreement.", "Product Coverage", "Reference (Product)", "", "PRD-00981", "Internal", "", "Y"),
       ("Covered Share Class", "Share class included in or excluded from the agreement, where coverage is at share-class level.", "Product Coverage", "Reference (Share Class)", "", "SHC-004512", "Internal", "", "Y"),
       ("Covered Model Portfolio", "Model portfolio covered by a model delivery or SMA sponsor agreement.", "Product Coverage", "Reference (Model)", "", "MDL-0077", "Internal", "", ""),
       ("Covered Vehicle Types", "Vehicle types covered when coverage is expressed by vehicle type rather than product.", "Product Coverage", "Code (multi)", "External (01 Product - Vehicle Type)", "Open-Ended Fund; Exchange-Traded Fund", "Internal", "", ""),
       ("Inclusion Type", "Whether the line includes or excludes the product or share class.", "Product Coverage", "Code", "Inclusion Type", "Include", "Internal", "", "Y"),
       ("Coverage Effective From", "Date the product or share class came into scope.", "Product Coverage", "Date", "ISO 8601", "2024-04-01", "Internal", "", "Y"),
       ("Coverage Effective To", "Date the product or share class left scope.", "Product Coverage", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Distribution Scope", "Where, through which channels and to whom the partner may distribute under the agreement.", [
     ("Agreement Distribution Scope", [
       ("Permitted Jurisdictions", "Countries in which the partner may distribute under the agreement.", "Distribution Scope", "Code (multi)", "ISO 3166-1 alpha-2", "GB; IE; LU", "Internal", "MiFID II", "Y"),
       ("Permitted Channels", "Distribution channels the agreement covers.", "Distribution Scope", "Code (multi)", "Partner Channel", "Wirehouse; Independent Broker-Dealer", "Internal", "", "Y"),
       ("Permitted Investor Types", "Investor types the partner may sell to under the agreement.", "Distribution Scope", "Code (multi)", "External (01 Product - Investor Type)", "Retail; Professional", "MiFID II", "", ""),
       ("Permitted Service Models", "Service models under which the partner may distribute the products.", "Distribution Scope", "Code (multi)", "Service Model", "Fee-Based Advisory; Brokerage", "Internal", "MiFID II", ""),
       ("Covered Account Types", "Types of accounts the agreement applies to.", "Distribution Scope", "Code (multi)", "Account Structure", "Omnibus", "Internal", "", ""),
       ("Sub-Distribution Permitted Indicator", "Whether the partner may appoint sub-distributors or use nominees.", "Distribution Scope", "Boolean", "", "Y", "Internal", "MiFID II", ""),
     ]),
   ]),
   ("Account Coverage", "Accounts at the fund's transfer agent that are governed by the agreement.", [
     ("Agreement Account Link", [
       ("Linked Account", "Account (omnibus, networked or plan) governed by the agreement.", "Account Link", "Reference (Account)", "", "ACC-0091233", "Internal", "", "Y"),
       ("Account Link Role", "Role the account plays under the agreement.", "Account Link", "Code", "Account Link Role", "Omnibus Trading Account", "Internal", "", ""),
       ("Account Link Effective From", "Date the account became governed by the agreement.", "Account Link", "Date", "ISO 8601", "2024-04-01", "Internal", "", ""),
       ("Account Link Effective To", "Date the account ceased to be governed by the agreement.", "Account Link", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

D("Payment & Fee Arrangements", "DA-PAY",
  "The money terms agreed under an agreement: what is paid, by whom, from which source, at what rate and on what basis, with tiers, caps and payment terms.",
  [
   ("Payment Arrangement", "One payment stream agreed under an agreement, such as revenue sharing, sub-TA fees, 12b-1 pass-through, a platform fee or a retrocession.", [
     ("Payment Arrangement", [
       ("Payment Arrangement ID", "Unique identifier for the payment arrangement.", "Payment Arrangement", "Identifier", "", "PYA-00871", "Internal", "", "Y"),
       ("Governing Agreement", "Agreement under which the payment is made.", "Payment Arrangement", "Reference (Agreement)", "", "AGR-004512", "Internal", "", "Y"),
       ("Payment Type", "Type of payment.", "Payment Arrangement", "Code", "Payment Type", "Revenue Sharing - Asset-Based", "Internal", "ICI", "Y"),
       ("Payment Direction", "Whether the firm pays or receives the amount.", "Payment Arrangement", "Code", "Payment Direction", "Payable to Partner", "Internal", "", ""),
       ("Payer Entity", "Legal entity that pays (for example, the fund, the adviser or the principal underwriter).", "Payment Arrangement", "Reference (Party)", "", "PTY-0012", "Internal", "", "Y"),
       ("Payee Entity", "Legal entity that receives the payment.", "Payment Arrangement", "Reference (Party)", "", "PTY-3301", "Internal", "", "Y"),
       ("Funding Source", "Source of the money: fund assets under a Rule 12b-1 plan, fund assets for non-distribution services, or the adviser's or distributor's own resources.", "Payment Arrangement", "Code", "Funding Source", "Adviser - Own Resources", "SEC Rule 12b-1", "SEC IM Guidance 2016-01", "Y"),
       ("Services Compensated", "Services the payment is made for. This drives whether a fund-paid amount must go through a 12b-1 plan.", "Payment Arrangement", "Code (multi)", "Compensated Service", "Sub-Accounting / Recordkeeping; Shareholder Servicing", "SEC IM Guidance 2016-01", "", "Y"),
       ("Rule 12b-1 Plan Reference", "Reference to the fund's Rule 12b-1 plan under which a fund-paid distribution or service fee is authorised.", "Payment Arrangement", "Text", "", "Example Funds Trust Class A 12b-1 Plan (2019)", "SEC Rule 12b-1", "", ""),
       ("Payment Currency", "Currency in which the payment is calculated and settled.", "Payment Arrangement", "Code", "ISO 4217", "USD", "Internal", "", "Y"),
       ("Payment Arrangement Status", "Lifecycle status of the payment arrangement.", "Payment Arrangement", "Code", "Arrangement Status", "Active", "Internal", "", ""),
       ("Arrangement Effective From", "Date from which the arrangement applies.", "Payment Arrangement", "Date", "ISO 8601", "2024-04-01", "Internal", "", "Y"),
       ("Arrangement Effective To", "Date the arrangement ends.", "Payment Arrangement", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Prospectus Disclosure Indicator", "Whether the payment is described in the fund's current prospectus or SAI. Members may receive cash compensation from an offeror only if it is described there.", "Payment Arrangement", "Boolean", "", "Y", "FINRA Rule 2341", "SEC Form N-1A", "Y"),
       ("Inducement Relevance Indicator", "Whether the payment is a fee, commission or benefit paid to an EU/UK investment firm, and so in scope of the MiFID II / FCA inducement rules.", "Payment Arrangement", "Boolean", "", "Y", "MiFID II", "UK FCA COBS", "Y"),
       ("Inducement Assessment Reference", "Reference to the compliance assessment (quality-enhancement test or exemption) for the payment, owned by Distribution Compliance.", "Payment Arrangement", "Reference (Compliance Review)", "", "REV-55120", "MiFID II Delegated Directive 2017/593", "", ""),
     ]),
   ]),
   ("Rate Schedule & Tiers", "How the payment amount is calculated: basis, rate, tiers and breakpoints.", [
     ("Rate Schedule", [
       ("Calculation Basis", "Measure the rate is applied to.", "Rate Schedule", "Code", "Calculation Basis", "Average Daily Net Assets", "Internal", "ICI", "Y"),
       ("Rate Type", "Form in which the rate is expressed.", "Rate Schedule", "Code", "Rate Type", "Basis Points per Annum", "Internal", "", ""),
       ("Base Rate", "Rate applied when there are no tiers, or the rate of the first tier.", "Rate Schedule", "Decimal", "Basis points", "12", "Internal", "", "Y"),
       ("Flat Fee Amount", "Fixed amount payable per period for flat-fee arrangements (platform, data, sponsorship).", "Rate Schedule", "Amount", "", "USD 250,000", "Internal", "", ""),
       ("Tiering Method", "How tiers are applied.", "Rate Schedule", "Code", "Tiering Method", "Incremental", "Internal", "", "Y"),
       ("Tier Aggregation Level", "Level at which the basis is aggregated to determine the applicable tier.", "Rate Schedule", "Code", "Aggregation Level", "Partner Firm", "Internal", "", ""),
       ("Qualifying Asset Definition", "Contractual definition of the assets or sales that count towards the basis.", "Rate Schedule", "Text", "", "All assets in covered share classes held in partner brokerage and advisory accounts, excluding retirement plan assets", "Internal", "", ""),
       ("Excluded Asset Categories", "Categories of assets or sales excluded from the basis.", "Rate Schedule", "Code (multi)", "Asset Exclusion", "Money Market Funds; Retirement Plan Assets", "Internal", "", ""),
       ("Greater-of / Lesser-of Rule", "How alternative rates combine where the agreement sets more than one (for example, the greater of per-account or asset-based).", "Rate Schedule", "Code", "Alternative Rate Rule", "Greater Of", "Internal", "", ""),
       ("Rate Schedule Effective From", "Date the rate schedule applies from.", "Rate Schedule", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Rate Schedule Effective To", "Date the rate schedule ends.", "Rate Schedule", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Rate Tier", [
       ("Tier Sequence", "Order of the tier within the schedule.", "Rate Tier", "Integer", "", "2", "Internal", "", ""),
       ("Tier Lower Bound", "Inclusive lower bound of the tier, in basis units.", "Rate Tier", "Decimal", "", "1000000000", "Internal", "", "Y"),
       ("Tier Upper Bound", "Exclusive upper bound of the tier; blank for the top tier.", "Rate Tier", "Decimal", "", "5000000000", "Internal", "", ""),
       ("Tier Bound Unit", "Unit in which tier bounds are expressed.", "Rate Tier", "Code", "Tier Bound Unit", "Asset Amount", "Internal", "", ""),
       ("Tier Rate", "Rate applied within the tier.", "Rate Tier", "Decimal", "Basis points", "10", "Internal", "", "Y"),
     ]),
   ]),
   ("Sub-Accounting & Networking Fees", "Per-account and asset-based fees paid to intermediaries for sub-transfer agency, networking and recordkeeping services.", [
     ("Sub-Accounting Fee Terms", [
       ("Sub-Accounting Fee Unit", "Unit on which a per-account sub-accounting fee is charged.", "Payment Arrangement", "Code", "Account Fee Unit", "Per Open Position", "ICI", "SEC IM Guidance 2016-01", ""),
       ("Per-Account Fee Amount", "Annual fee per unit (account, position or participant).", "Payment Arrangement", "Amount", "", "USD 16.00", "Internal", "", "Y"),
       ("Applicable Networking Level", "DTCC Networking matrix level of the accounts the fee applies to.", "Payment Arrangement", "Code", "Networking Level", "Level 3", "DTCC NSCC Networking", "", ""),
       ("Fund-Paid Sub-TA Cap", "Maximum the fund may bear for sub-TA services, as approved by the fund board, typically the fund's own TA cost per account or a bps cap.", "Payment Arrangement", "Decimal", "Basis points", "10", "SEC IM Guidance 2016-01", "", "Y"),
       ("Excess Borne by Adviser Indicator", "Whether any amount above the fund-paid cap is paid by the adviser or distributor from its own resources.", "Payment Arrangement", "Boolean", "", "Y", "SEC IM Guidance 2016-01", "", ""),
       ("Account Count Source", "Data feed providing the account or position counts used to bill.", "Payment Arrangement", "Reference (Data Feed)", "", "FEED-0031", "Internal", "", ""),
     ]),
   ]),
   ("Distribution Fees, Trails & Retrocessions", "Pass-through of 12b-1 and servicing fees in the US, and trail commissions and retrocessions in the EU/UK.", [
     ("Distribution Fee Pass-Through", [
       ("12b-1 Fee Component", "Component of the 12b-1 fee being passed through.", "Payment Arrangement", "Code", "12b-1 Component", "Service Fee", "SEC Rule 12b-1", "FINRA Rule 2341", ""),
       ("Pass-Through Rate", "Annual rate of the 12b-1 or servicing fee paid to the dealer of record.", "Payment Arrangement", "Decimal", "Basis points", "25", "SEC Rule 12b-1", "", "Y"),
       ("Pass-Through Start Month", "Month of holding after which the trail starts (for example, month 13 where the first year is advanced).", "Payment Arrangement", "Integer", "Months", "13", "Internal", "", ""),
       ("Advance Commission Indicator", "Whether an up-front dealer commission is advanced and recovered from the first year's trail (typical for level-load share classes).", "Payment Arrangement", "Boolean", "", "Y", "Internal", "FINRA Rule 2341", ""),
       ("Retrocession Basis", "How an EU/UK retrocession or trail is expressed.", "Payment Arrangement", "Code", "Retrocession Basis", "% of Management Fee", "MiFID II", "", ""),
       ("Retrocession Rate", "Rate of the retrocession or trail commission.", "Payment Arrangement", "Percentage", "", "40%", "MiFID II", "", "Y"),
       ("Pass-On to Client Required Indicator", "Whether the partner must pass the payment on to the end client in full, as required for independent advice and portfolio management.", "Payment Arrangement", "Boolean", "", "Y", "MiFID II", "UK FCA COBS", ""),
       ("UK Legacy Trail Indicator", "Whether the payment is adviser trail commission on UK retail business arranged before the RDR (31 Dec 2012) and still allowed.", "Payment Arrangement", "Boolean", "", "N", "UK FCA COBS", "", ""),
     ]),
   ]),
   ("Caps, Minimums & Offsets", "Limits and ordering rules that apply across payment arrangements with the same partner.", [
     ("Payment Limit", [
       ("Annual Payment Cap", "Maximum total payable in a cap period.", "Payment Arrangement", "Amount", "", "USD 4,000,000", "Internal", "", "Y"),
       ("Cap Rate", "Maximum aggregate payment expressed as bps of qualifying assets.", "Payment Arrangement", "Decimal", "Basis points", "20", "Internal", "", ""),
       ("Minimum Annual Payment", "Minimum amount payable regardless of the basis (for example, a platform minimum fee).", "Payment Arrangement", "Amount", "", "USD 150,000", "Internal", "", ""),
       ("Offset Method", "How payments under other arrangements reduce this one (for example, revenue share net of 12b-1 already paid).", "Payment Arrangement", "Code", "Offset Method", "Net of 12b-1 and Sub-TA", "SEC IM Guidance 2016-01", "ICI", ""),
       ("Payment Waterfall Sequence", "Order in which this arrangement is applied when one total amount is funded from several sources.", "Payment Arrangement", "Integer", "", "3", "SEC IM Guidance 2016-01", "", ""),
     ]),
   ]),
   ("Payment Terms & Invoicing", "When and how the amount is billed and paid.", [
     ("Payment Terms", [
       ("Payment Frequency", "How often payment is made.", "Payment Arrangement", "Code", "Frequency", "Quarterly", "Internal", "", "Y"),
       ("Billing Method", "How the amount due is established and settled.", "Payment Arrangement", "Code", "Billing Method", "Partner Invoice", "Internal", "", ""),
       ("Payment Due Days", "Days after invoice or period end by which payment is due.", "Payment Arrangement", "Integer", "Days", "45", "Internal", "", ""),
       ("Basis Data Source", "Data feed or system supplying the assets, sales or counts used in the calculation.", "Payment Arrangement", "Reference (Data Feed)", "", "FEED-0012", "Internal", "", ""),
       ("VAT Applicable Indicator", "Whether VAT applies to the fee (relevant for EU/UK platform and service fees).", "Payment Arrangement", "Boolean", "", "N", "Internal", "", ""),
     ]),
   ]),
  ])

D("Partner Payment Processing", "DA-PPR",
  "The partner payment cycle: period calculations and accruals, partner invoices and their reconciliation, and settled payments.",
  [
   ("Payment Calculation & Accrual", "Calculated amount due under a payment arrangement for a period.", [
     ("Payment Calculation", [
       ("Calculation ID", "Unique identifier of the period calculation.", "Payment Calculation", "Identifier", "", "PCL-2026Q2-00871", "Internal", "", ""),
       ("Calculated Arrangement", "Payment arrangement being calculated.", "Payment Calculation", "Reference (Payment Arrangement)", "", "PYA-00871", "Internal", "", "Y"),
       ("Calculation Period Start", "First day of the period.", "Payment Calculation", "Date", "ISO 8601", "2026-04-01", "Internal", "", "Y"),
       ("Calculation Period End", "Last day of the period.", "Payment Calculation", "Date", "ISO 8601", "2026-06-30", "Internal", "", ""),
       ("Basis Value", "Value of the calculation basis for the period (average assets, sales, account count).", "Payment Calculation", "Decimal", "", "6250000000", "Internal", "", "Y"),
       ("Basis Position Snapshot", "Reference to the position or AUM data set used as the basis, held in Sales Transactions & AUM.", "Payment Calculation", "Reference (Position)", "", "POS-SNAP-20260630-3301", "Internal", "", ""),
       ("Applied Effective Rate", "Blended rate produced by the tiers for the period.", "Payment Calculation", "Decimal", "Basis points", "11.2", "Internal", "", ""),
       ("Calculated Amount", "Amount due for the period before adjustments.", "Payment Calculation", "Amount", "", "USD 1,745,000", "Internal", "", "Y"),
       ("Adjustment Amount", "Manual or rule-based adjustment (cap, offset, prior-period true-up).", "Payment Calculation", "Amount", "", "USD -12,400", "Internal", "", ""),
       ("Adjustment Reason", "Reason for the adjustment.", "Payment Calculation", "Code", "Adjustment Reason", "Prior Period True-Up", "Internal", "", ""),
       ("Accrual Amount", "Amount accrued in the books for the period before the invoice is received.", "Payment Calculation", "Amount", "", "USD 1,740,000", "Internal", "", ""),
       ("Calculation Status", "Workflow status of the calculation.", "Payment Calculation", "Code", "Calculation Status", "Approved", "Internal", "", ""),
     ]),
   ]),
   ("Partner Invoice", "Invoices or statements received from (or issued to) partners and their reconciliation to the calculation.", [
     ("Partner Invoice", [
       ("Partner Invoice Number", "Invoice number assigned by the partner.", "Partner Invoice", "Identifier", "", "INV-WHA-2026-0712", "Internal", "", ""),
       ("Invoice Date", "Date of the invoice.", "Partner Invoice", "Date", "ISO 8601", "2026-07-15", "Internal", "", ""),
       ("Invoiced Amount", "Total amount invoiced.", "Partner Invoice", "Amount", "", "USD 1,752,300", "Internal", "", "Y"),
       ("Invoice Variance Amount", "Difference between invoiced and calculated amount.", "Partner Invoice", "Amount", "", "USD 19,700", "Internal", "", ""),
       ("Invoice Status", "Status of the invoice in the review and approval workflow.", "Partner Invoice", "Code", "Invoice Status", "Disputed", "Internal", "", ""),
       ("Dispute Reason", "Reason an invoice is disputed.", "Partner Invoice", "Code", "Dispute Reason", "Basis Assets Mismatch", "Internal", "", ""),
     ]),
   ]),
   ("Partner Payment", "Payments settled with partners.", [
     ("Partner Payment", [
       ("Partner Payment ID", "Unique identifier of the payment.", "Partner Payment", "Identifier", "", "PMT-2026-004411", "Internal", "", ""),
       ("Payment Date", "Date the payment was made.", "Partner Payment", "Date", "ISO 8601", "2026-08-14", "Internal", "", "Y"),
       ("Payment Amount", "Amount paid.", "Partner Payment", "Amount", "", "USD 1,732,600", "Internal", "", "Y"),
       ("Charged Entity", "Entity whose books bear the payment (fund, adviser or distributor), which must match the arrangement's funding source.", "Partner Payment", "Reference (Party)", "", "PTY-0012", "SEC Rule 12b-1", "", "Y"),
       ("Payment Status", "Status of the payment.", "Partner Payment", "Code", "Payment Status", "Settled", "Internal", "", ""),
       ("Invoices Settled", "Invoices or calculations settled by this payment.", "Partner Payment", "Reference (Partner Invoice) (multi)", "", "INV-WHA-2026-0712", "Internal", "", ""),
     ]),
   ]),
  ])

D("Partner Programmes", "DA-PGM",
  "Commercial programmes run by partners (strategic partner, marketing support, education and conference programmes) and the firm's participation, tier and access rights.",
  [
   ("Programme Definition", "A partner-run programme the firm can join or pay into.", [
     ("Partner Programme", [
       ("Programme ID", "Unique identifier for the partner programme.", "Programme", "Identifier", "", "PGM-0042", "Internal", "", "Y"),
       ("Programme Name", "Name of the programme as the partner calls it.", "Programme", "Text", "", "Strategic Partner Program 2026", "Internal", "", ""),
       ("Programme Type", "Type of programme.", "Programme", "Code", "Programme Type", "Strategic Partnership", "Internal", "", "Y"),
       ("Programme Sponsor", "Partner that runs the programme.", "Programme", "Reference (Party)", "", "PTY-3301", "Internal", "", "Y"),
       ("Programme Status", "Status of the programme.", "Programme", "Code", "Arrangement Status", "Active", "Internal", "", ""),
     ]),
   ]),
   ("Programme Participation", "The firm's membership of a programme and the tier it holds.", [
     ("Programme Membership", [
       ("Member Programme", "Programme the firm participates in.", "Programme Membership", "Reference (Programme)", "", "PGM-0042", "Internal", "", ""),
       ("Partner Tier", "Tier or level the firm holds in the programme.", "Programme Membership", "Code", "Partner Tier", "Tier 1 / Platinum", "Internal", "", "Y"),
       ("Tier Qualification Basis", "Criteria the partner uses to assign the tier (assets, sales, payment level).", "Programme Membership", "Text", "", "Fund assets > USD 5bn on platform or payment > USD 2m p.a.", "Internal", "", ""),
       ("Funding Agreement", "Agreement under which programme fees are paid.", "Programme Membership", "Reference (Agreement)", "", "AGR-004512", "Internal", "", "Y"),
       ("Annual Commitment Amount", "Committed annual spend for the membership.", "Programme Membership", "Amount", "", "USD 750,000", "Internal", "", ""),
       ("Relationship Manager", "Internal national-accounts or partnership manager responsible for the membership.", "Programme Membership", "Reference (Employee)", "", "EMP-01177", "Internal", "", ""),
       ("Membership Effective From", "Start of membership.", "Programme Membership", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Membership Effective To", "End of membership.", "Programme Membership", "Date", "ISO 8601", "2026-12-31", "Internal", "", ""),
       ("Renewal Decision", "Internal decision on renewing the membership.", "Programme Membership", "Code", "Renewal Decision", "Renew - Same Tier", "Internal", "", ""),
     ]),
   ]),
   ("Access Rights & Benefits", "Benefits and access rights the membership grants and how far they are used.", [
     ("Programme Benefit", [
       ("Benefit Type", "Type of benefit or access right.", "Programme Benefit", "Code", "Benefit Type", "Home-Office Access", "Internal", "", ""),
       ("Entitled Quantity", "Number of units of the benefit available in the period.", "Programme Benefit", "Integer", "", "4", "Internal", "", ""),
       ("Used Quantity", "Number of units used to date.", "Programme Benefit", "Integer", "", "2", "Internal", "", ""),
       ("Linked Event", "Partner conference or event the benefit relates to, as held in Marketing & Digital.", "Programme Benefit", "Reference (Event)", "", "EVT-2026-0315", "Internal", "", ""),
       ("Non-Cash Compensation Relevance Indicator", "Whether the benefit involves training or education meetings or sponsorship that Compliance must review under the non-cash compensation rules.", "Programme Benefit", "Boolean", "", "Y", "FINRA Rule 2341", "", ""),
     ]),
   ]),
  ])

D("Product Shelf & Availability", "DA-SHF",
  "Whether and how each product and share class is available through each partner: shelf and list status, advisory-programme and model eligibility, share-class mapping, minimums, research ratings and watch lists.",
  [
   ("Shelf Placement", "Effective-dated status of a product or share class on a partner's shelf, approved list or recommended list.", [
     ("Shelf Placement", [
       ("Shelf Placement ID", "Unique identifier of the placement record.", "Shelf Placement", "Identifier", "", "SHF-0193344", "Internal", "", ""),
       ("Shelf Partner", "Partner on whose shelf or list the product is placed.", "Shelf Placement", "Reference (Party)", "", "PTY-3301", "Internal", "", "Y"),
       ("Partner Platform / Programme Name", "Platform, advisory programme or list within the partner (a partner may run several).", "Shelf Placement", "Text", "", "Wirehouse A Investment Advisory Program", "Internal", "", ""),
       ("Placed Product", "Product placed.", "Shelf Placement", "Reference (Product)", "", "PRD-00981", "Internal", "", "Y"),
       ("Placed Share Class", "Share class available for this placement.", "Shelf Placement", "Reference (Share Class)", "", "SHC-004512", "Internal", "", "Y"),
       ("Shelf List Type", "Type of list or shelf.", "Shelf Placement", "Code", "Shelf List Type", "Recommended List", "Internal", "", "Y"),
       ("Placement Status", "Status of the product on the list.", "Shelf Placement", "Code", "Placement Status", "Approved - Available", "Internal", "", "Y"),
       ("Placement Status Effective From", "Date the current status took effect.", "Shelf Placement", "Date", "ISO 8601", "2025-11-01", "Internal", "", "Y"),
       ("Placement Status Effective To", "Date the status ended.", "Shelf Placement", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Placement Change Reason", "Reason the placement status changed.", "Shelf Placement", "Code", "Placement Change Reason", "Research Upgrade", "Internal", "", ""),
       ("Trade-Enabled Date", "Date the share class could first be traded on the partner platform.", "Shelf Placement", "Date", "ISO 8601", "2025-11-10", "Internal", "", ""),
       ("Eligible Account Types", "Partner account types in which the product may be held.", "Shelf Placement", "Code (multi)", "Account Eligibility", "Fee-Based Advisory; IRA", "Internal", "SEC Reg BI", "Y"),
       ("Model Eligibility Indicator", "Whether the product may be used in partner-built or third-party models on the platform.", "Shelf Placement", "Boolean", "", "Y", "Internal", "", ""),
       ("Partner Product Code", "Partner's internal code for the product or share class.", "Shelf Placement", "Text", "", "WHA-MF-88213", "Internal", "", ""),
       ("Platform Minimum Initial Investment", "Minimum first investment set by the platform (may differ from the prospectus minimum).", "Shelf Placement", "Amount", "", "USD 1,000", "Internal", "openfunds", ""),
       ("Placement Opportunity", "Sales opportunity that tracked the pursuit of this placement.", "Shelf Placement", "Reference (Opportunity)", "", "OPP-118230", "Internal", "", ""),
     ]),
   ]),
   ("Research & Due Diligence", "Partner or gatekeeper research ratings, due-diligence review dates and watch-list status for the firm's products.", [
     ("Partner Research Rating", [
       ("Research Provider", "Partner research team or third-party gatekeeper issuing the rating.", "Research Rating", "Reference (Party)", "", "PTY-3390", "Internal", "", ""),
       ("Rated Product", "Product or strategy rated.", "Research Rating", "Reference (Product)", "", "PRD-00981", "Internal", "", ""),
       ("Partner Rating Value", "Rating in the provider's own scale, held as received.", "Research Rating", "Text", "External (Partner-defined)", "Focus List - Buy", "Internal", "", ""),
       ("Normalised Research Rating", "Rating mapped to the firm's common scale for cross-partner reporting.", "Research Rating", "Code", "Normalised Research Rating", "Recommended", "Internal", "", "Y"),
       ("Rating Date", "Date the current rating was issued.", "Research Rating", "Date", "ISO 8601", "2026-05-20", "Internal", "", ""),
       ("Due Diligence Review Type", "Type of review.", "Research Rating", "Code", "Review Type", "Annual Review", "Internal", "", ""),
       ("Last Due Diligence Review Date", "Date of the last due-diligence meeting or review by the partner.", "Research Rating", "Date", "ISO 8601", "2026-05-12", "Internal", "", "Y"),
       ("Next Scheduled Review Date", "Date of the next scheduled review.", "Research Rating", "Date", "ISO 8601", "2027-05-01", "Internal", "", ""),
       ("Watch List Indicator", "Whether the product is on the partner's watch list.", "Research Rating", "Boolean", "", "N", "Internal", "", "Y"),
       ("Watch List Reason", "Reason for the watch-list placement.", "Research Rating", "Code", "Watch List Reason", "Portfolio Manager Change", "Internal", "", ""),
       ("DDQ Response Reference", "Reference to the firm's due-diligence questionnaire response supplied to the partner, held in Sales.", "Research Rating", "Reference (RFP / DDQ)", "", "RFP-2026-0422", "Internal", "", ""),
       ("Research Analyst", "Partner analyst covering the product.", "Research Rating", "Reference (Party)", "", "PTY-3390-I17", "Internal", "", "", "PII"),
     ]),
   ]),
   ("Share Class Availability", "Which share class is used for which partner account type, with waivers and conversions.", [
     ("Share Class Mapping", [
       ("Mapped Share Class", "Share class the partner uses for the account type.", "Shelf Placement", "Reference (Share Class)", "", "SHC-004519", "Internal", "", "Y"),
       ("Mapped Account Type", "Partner account type the mapping applies to.", "Shelf Placement", "Code", "Account Eligibility", "Fee-Based Advisory", "Internal", "SEC Reg BI", ""),
       ("Default Share Class Indicator", "Whether this is the default class for the account type.", "Shelf Placement", "Boolean", "", "Y", "Internal", "", ""),
       ("Sales Charge Waiver Indicator", "Whether front-end or CDSC charges are waived for this account type at the partner (intermediary-specific waivers disclosed in the prospectus).", "Shelf Placement", "Boolean", "", "Y", "SEC Form N-1A", "", ""),
       ("Share Class Conversion Eligible Indicator", "Whether positions can be converted to this class (for example, brokerage to advisory, or after the CDSC period).", "Shelf Placement", "Boolean", "", "Y", "Internal", "", ""),
     ]),
   ]),
   ("Model & SMA Programme Placement", "Placement of model portfolios and SMA strategies on sponsor programmes and model marketplaces.", [
     ("Model Programme Placement", [
       ("Placed Model Portfolio", "Model portfolio or SMA strategy placed.", "Model Placement", "Reference (Model)", "", "MDL-0077", "Internal", "", "Y"),
       ("Sponsor Programme Type", "Type of sponsor programme.", "Model Placement", "Code", "Sponsor Programme Type", "UMA", "Internal", "", ""),
       ("Firm Role in Programme", "Whether the firm acts as discretionary manager or model provider.", "Model Placement", "Code", "Programme Role", "Model Provider", "Internal", "", ""),
       ("Programme Minimum Account Size", "Minimum account size for the strategy in the programme.", "Model Placement", "Amount", "", "USD 100,000", "Internal", "", ""),
       ("Model Placement Status", "Status of the model in the programme.", "Model Placement", "Code", "Placement Status", "Approved - Available", "Internal", "", ""),
       ("Model Placement Effective From", "Date the status took effect.", "Model Placement", "Date", "ISO 8601", "2026-02-01", "Internal", "", ""),
     ]),
   ]),
  ])

D("Partner Operational Setup", "DA-OPS",
  "The operational set-up needed to trade and service business with a partner: dealer and platform identifiers, dealing and settlement routes, account structure and networking level, and data-feed arrangements.",
  [
   ("Dealer & Platform Identification", "Identifiers assigned for dealing with the partner. Firm-level regulatory identifiers (CRD, LEI, FRN) belong to the party master.", [
     ("Partner Dealer Setup", [
       ("TA Dealer Number", "Dealer number assigned to the partner by the fund's transfer agent under the selling agreement.", "Dealer Setup", "Identifier", "", "0001234", "Internal", "", "Y"),
       ("NSCC Participant Number", "NSCC participant (member) number the partner uses for Fund/SERV and Networking.", "Dealer Setup", "Identifier", "", "0226", "DTCC NSCC Fund/SERV", "", "Y"),
       ("Clearing Firm", "Clearing firm that settles for the partner, where it is not self-clearing.", "Dealer Setup", "Reference (Party)", "", "PTY-3410", "DTCC NSCC Fund/SERV", "", ""),
       ("Platform Participant ID", "Identifier of the partner or the firm on an EU/UK dealing network or platform (for example, Calastone or Allfunds codes).", "Dealer Setup", "Identifier", "External (Platform-assigned)", "CAL-GB-001882", "Internal", "", ""),
       ("Dealing BIC", "SWIFT BIC used for order and settlement messaging.", "Dealer Setup", "Code", "ISO 9362", "ABCDGB2LXXX", "ISO 9362", "ISO 20022", ""),
       ("Dealer Setup Status", "Status of the dealer set-up.", "Dealer Setup", "Code", "Setup Status", "Live", "Internal", "", ""),
       ("Dealer Setup Effective Date", "Date the set-up went live.", "Dealer Setup", "Date", "ISO 8601", "2024-04-15", "Internal", "", ""),
     ]),
   ]),
   ("Trading & Settlement", "How orders from the partner are routed, matched and settled.", [
     ("Trading Setup", [
       ("Dealing Route", "Channel by which the partner places orders.", "Trading Setup", "Code", "Dealing Route", "NSCC Fund/SERV", "DTCC NSCC Fund/SERV", "ISO 20022", "Y"),
       ("Message Standard", "Message standard used for orders and confirmations.", "Trading Setup", "Code", "Message Standard", "ISO 20022", "ISO 20022", "", ""),
       ("Settlement Method", "How cash and units settle.", "Trading Setup", "Code", "Settlement Method", "NSCC Net Settlement", "DTCC NSCC Fund/SERV", "", ""),
       ("Settlement Cycle", "Standard settlement period for subscriptions and redemptions.", "Trading Setup", "Text", "T+n", "T+1", "Internal", "", ""),
       ("Account Structure", "How the partner's clients are held at the transfer agent.", "Trading Setup", "Code", "Account Structure", "Omnibus", "Internal", "SEC IM Guidance 2016-01", "Y"),
       ("Order Cut-Off Time", "Latest time for orders to receive the day's price, as agreed with the partner.", "Trading Setup", "Time", "HH:MM + time zone", "16:00 America/New_York", "Internal", "", ""),
       ("Dealing Restrictions", "Partner-specific dealing restrictions (for example, no exchanges, buy-only, no new accounts).", "Trading Setup", "Text", "", "Closed to new accounts; additional purchases allowed", "Internal", "", ""),
     ]),
   ]),
   ("Networking & Account Servicing", "DTCC Networking matrix level and who services and keeps records for underlying shareholder accounts.", [
     ("Networking Setup", [
       ("Networking Level", "DTCC Networking matrix level agreed for the partner's accounts.", "Networking Setup", "Code", "Networking Level", "Level 3", "DTCC NSCC Networking", "", "Y"),
       ("Recordkeeping Responsibility", "Party keeping the shareholder-level books and records.", "Networking Setup", "Code", "Servicing Responsibility", "Intermediary", "DTCC NSCC Networking", "SEC IM Guidance 2016-01", ""),
       ("Statement & Confirmation Responsibility", "Party sending confirmations and statements to underlying shareholders.", "Networking Setup", "Code", "Servicing Responsibility", "Intermediary", "DTCC NSCC Networking", "", ""),
       ("Sub-Accounting Platform", "Sub-accounting system the intermediary uses, where it acts as sub-TA.", "Networking Setup", "Code", "External (Vendor)", "SS&C / DST", "Internal", "", ""),
       ("Rule 22c-2 Agreement in Place Indicator", "Whether a shareholder information agreement under Rule 22c-2 is in place, allowing the fund to request underlying shareholder trading data.", "Networking Setup", "Boolean", "", "Y", "SEC Rule 22c-2", "", "Y"),
     ]),
   ]),
   ("Data Feed Arrangements", "Agreed data exchanges with the partner. Technical feed definitions and the data received belong to Sales Transactions & AUM.", [
     ("Partner Data Feed Arrangement", [
       ("Data Feed", "Feed delivered under the arrangement.", "Data Feed Arrangement", "Reference (Data Feed)", "", "FEED-0012", "Internal", "", "Y"),
       ("Data Content Types", "Content delivered.", "Data Feed Arrangement", "Code (multi)", "Data Content Type", "Positions / AUM; Transactions", "Internal", "", ""),
       ("Data Granularity", "Lowest level of detail delivered.", "Data Feed Arrangement", "Code", "Data Granularity", "Advisor / Rep", "Internal", "", ""),
       ("Governing Data Agreement", "Data licensing or data-sharing agreement under which the feed is supplied.", "Data Feed Arrangement", "Reference (Agreement)", "", "AGR-005130", "Internal", "", ""),
       ("Data Fee Arrangement", "Payment arrangement for the data, where data is paid for.", "Data Feed Arrangement", "Reference (Payment Arrangement)", "", "PYA-00902", "Internal", "", ""),
       ("Permitted Use Restrictions", "Contractual limits on how the data may be used (for example, no use for wholesaler compensation, no onward sharing).", "Data Feed Arrangement", "Text", "", "Internal sales analytics only; not for redistribution", "Internal", "", ""),
       ("Personal Data Included Indicator", "Whether the feed contains personal data on advisors or end investors.", "Data Feed Arrangement", "Boolean", "", "Y", "Internal", "GDPR", "", "Drives data protection controls"),
     ]),
   ]),
  ])

D("Partner Disclosures & Transparency", "DA-DSC",
  "Disclosures and data exchanged with or published about partner payments: revenue-sharing and conflicts disclosures, ERISA 408(b)(2) compensation disclosures, and MiFID II costs & charges and inducement information sent to distributors.",
  [
   ("Payment & Conflict Disclosures", "Public or client-facing disclosures that describe the firm's payments to a partner.", [
     ("Payment Disclosure", [
       ("Disclosure Type", "Type of disclosure.", "Disclosure", "Code", "Partner Disclosure Type", "Partner Revenue Sharing Disclosure", "SEC Reg BI", "FINRA Rule 2341", "Y"),
       ("Disclosing Party", "Party publishing the disclosure (the partner, the fund or the firm).", "Disclosure", "Reference (Party)", "", "PTY-3301", "Internal", "", ""),
       ("Disclosed Arrangements", "Payment arrangements the disclosure covers.", "Disclosure", "Reference (Payment Arrangement) (multi)", "", "PYA-00871; PYA-00872", "Internal", "", ""),
       ("Firm Listed Indicator", "Whether the firm is named in the partner's published list of revenue-sharing or marketing-support payers.", "Disclosure", "Boolean", "", "Y", "SEC Reg BI", "", ""),
       ("Disclosure Publication Date", "Date the current version was published.", "Disclosure", "Date", "ISO 8601", "2026-03-31", "Internal", "", "Y"),
       ("Disclosure Location", "URL or document where the disclosure is published.", "Disclosure", "Text", "URI", "https://www.example-wirehouse.com/disclosures/revenue-sharing", "Internal", "", ""),
       ("Last Verified Date", "Date the firm last checked the disclosure was accurate against current terms.", "Disclosure", "Date", "ISO 8601", "2026-06-15", "Internal", "", ""),
     ]),
   ]),
   ("ERISA 408(b)(2) Disclosure", "Indirect compensation the firm pays to recordkeepers and other covered service providers to ERISA plans, supplied so they can meet 408(b)(2).", [
     ("408(b)(2) Compensation Disclosure", [
       ("Covered Service Provider", "Recordkeeper or other covered service provider receiving the indirect compensation.", "Disclosure", "Reference (Party)", "", "PTY-5120", "DOL 408(b)(2)", "", "Y"),
       ("Indirect Compensation Description", "Description of the indirect compensation and the services it relates to.", "Disclosure", "Text", "", "Sub-TA fee of USD 12 per participant position and 10 bps shareholder servicing on R6-excluded classes", "DOL 408(b)(2)", "", "Y"),
       ("Indirect Compensation Payer", "Party paying the indirect compensation.", "Disclosure", "Reference (Party)", "", "PTY-0012", "DOL 408(b)(2)", "", ""),
       ("Compensation Formula", "Formula or rate used to determine the compensation, where no fixed amount can be given.", "Disclosure", "Text", "", "10 bps p.a. on average daily plan assets in covered share classes", "DOL 408(b)(2)", "", ""),
       ("Disclosure Provided Date", "Date the information was provided to the covered service provider.", "Disclosure", "Date", "ISO 8601", "2026-01-31", "DOL 408(b)(2)", "", ""),
       ("Change Notification Date", "Date a change to the compensation information was notified.", "Disclosure", "Date", "ISO 8601", "", "DOL 408(b)(2)", "", ""),
     ]),
   ]),
   ("MiFID Costs, Charges & Inducement Data", "Exchange of MiFID II product cost and inducement data with EU/UK distributors.", [
     ("Distributor Data Exchange", [
       ("Recipient Distributor", "Distributor or platform receiving the data.", "Disclosure", "Reference (Party)", "", "PTY-4402", "FinDatEx EMT", "", ""),
       ("EMT Version Delivered", "FinDatEx EMT template version delivered.", "Disclosure", "Text", "", "V4.2", "FinDatEx EMT", "", ""),
       ("EMT Delivery Channel", "How the EMT reaches the distributor.", "Disclosure", "Code", "Data Delivery Channel", "Data Vendor", "FinDatEx EMT", "", ""),
       ("Last EMT Delivery Date", "Date the latest EMT file was delivered to or made available for the distributor.", "Disclosure", "Date", "ISO 8601", "2026-09-05", "FinDatEx EMT", "", "Y"),
       ("Ex-Post Inducement Amount", "Amount of retrocession or trail paid to the distributor for a share class over the reporting period, supplied for its ex-post costs & charges reports.", "Disclosure", "Amount", "", "EUR 48,210", "MiFID II", "FinDatEx EMT", "Y"),
       ("Ex-Post Data Delivery Date", "Date ex-post costs and inducement data was delivered.", "Disclosure", "Date", "ISO 8601", "2026-02-28", "MiFID II", "", ""),
     ]),
   ]),
  ])

D("Contract Obligations & SLAs", "DA-OBL",
  "Obligations each party takes on under the agreement, the service levels that apply, measured performance and partner oversight attestations.",
  [
   ("Contractual Obligations", "Obligations defined in the agreement and tracked for compliance.", [
     ("Agreement Obligation", [
       ("Obligation ID", "Unique identifier of the obligation.", "Obligation", "Identifier", "", "AGR-004512-OB07", "Internal", "", ""),
       ("Obligation Category", "Category of the obligation.", "Obligation", "Code", "Obligation Category", "Data Delivery", "Internal", "", "Y"),
       ("Obligated Party", "Which side must perform the obligation.", "Obligation", "Code", "Initiating Party", "Partner", "Internal", "", ""),
       ("Obligation Description", "What must be done.", "Obligation", "Text", "", "Deliver monthly rep-level position file by business day 5", "Internal", "", ""),
       ("Obligation Frequency", "How often the obligation recurs.", "Obligation", "Code", "Frequency", "Monthly", "Internal", "", ""),
       ("Next Due Date", "Next date the obligation is due.", "Obligation", "Date", "ISO 8601", "2026-10-07", "Internal", "", ""),
       ("Obligation Owner", "Internal employee monitoring the obligation.", "Obligation", "Reference (Employee)", "", "EMP-00931", "Internal", "", ""),
       ("Obligation Compliance Status", "Current compliance status.", "Obligation", "Code", "Compliance Status", "Met", "Internal", "", "Y"),
     ]),
   ]),
   ("Service Levels", "Measurable service levels and actual performance against them.", [
     ("Service Level Agreement", [
       ("SLA Metric Name", "Name of the service-level metric.", "SLA", "Text", "", "Position file delivered by 08:00 ET T+1", "Internal", "", ""),
       ("SLA Metric Type", "Type of metric.", "SLA", "Code", "SLA Metric Type", "Timeliness", "Internal", "", ""),
       ("SLA Target Value", "Target to be met.", "SLA", "Decimal", "", "98", "Internal", "", ""),
       ("SLA Target Unit", "Unit of the target.", "SLA", "Code", "SLA Unit", "% of Deliveries", "Internal", "", ""),
       ("Measurement Frequency", "How often performance is measured.", "SLA", "Code", "Frequency", "Monthly", "Internal", "", ""),
       ("Service Credit Terms", "Fee reduction or credit for missed service levels.", "SLA", "Text", "", "5% reduction in monthly data fee if below 95%", "Internal", "", ""),
     ]),
     ("SLA Measurement", [
       ("Measurement Period", "Period measured.", "SLA", "Text", "", "2026-08", "Internal", "", ""),
       ("Actual Value", "Measured performance for the period.", "SLA", "Decimal", "", "96.2", "Internal", "", ""),
       ("SLA Met Indicator", "Whether the target was met.", "SLA", "Boolean", "", "N", "Internal", "", "Y"),
       ("Remediation Action", "Agreed corrective action.", "SLA", "Text", "", "Partner to move file generation to earlier batch window", "Internal", "", ""),
     ]),
   ]),
   ("Partner Oversight Attestations", "Periodic certifications, controls reports and attestations received from partners under the agreement.", [
     ("Partner Attestation", [
       ("Attestation Type", "Type of attestation or controls evidence.", "Obligation", "Code", "Attestation Type", "SOC 1 Type II Report", "Internal", "SEC IM Guidance 2016-01", ""),
       ("Attestation Received Date", "Date the attestation was received.", "Obligation", "Date", "ISO 8601", "2026-02-10", "Internal", "", ""),
       ("Next Attestation Due Date", "Date the next attestation is due.", "Obligation", "Date", "ISO 8601", "2027-02-15", "Internal", "", ""),
       ("Attestation Outcome", "Result of the internal review of the attestation.", "Obligation", "Code", "Attestation Outcome", "Satisfactory with Exceptions", "Internal", "", "Y"),
     ]),
   ]),
  ])

D("Data Management Metadata", "DA-DMM",
  "Metadata applied to every record in the distribution agreements and partners domain.",
  [
   ("Record Metadata", "Ownership, lineage, effective dating and quality status of each record.", [
     ("Record Metadata", [
       ("Data Owner", "Business role accountable for the data element.", "All", "Reference (Employee)", "", "Head of Intermediary Distribution", "DCAM (EDM Council)", "", ""),
       ("Data Steward", "Role responsible for day-to-day data quality.", "All", "Reference (Employee)", "", "Partner Data Steward", "DCAM (EDM Council)", "", ""),
       ("System of Record", "System holding the authoritative value.", "All", "Code", "Firm-defined", "Contract Lifecycle Management", "Internal", "", ""),
       ("Source Document Reference", "Agreement clause or document the value was taken from.", "All", "Text", "", "AGR-004512 Sched. B s.2.1", "Internal", "", ""),
       ("Record Effective From", "Business-effective start date of the record version.", "All", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Record Effective To", "Business-effective end date of the record version.", "All", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Last Updated Timestamp", "System timestamp of the last change.", "All", "Timestamp", "ISO 8601", "2026-09-30T17:45:00Z", "Internal", "", ""),
       ("Access Classification", "Confidentiality classification controlling who may see the record (commercial terms are often need-to-know).", "All", "Code", "Access Classification", "Restricted - Commercial Terms", "Internal", "", ""),
       ("Data Quality Status", "Validation status of the record.", "All", "Code", "Data Quality Status", "Validated", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Agreement Type": ("Internal (aligned to FINRA Rule 2341, SEC Rule 12b-1, MiFID II, DOL 408(b)(2))", [
   ("Selling / Dealer Agreement", "Principal underwriter appoints a broker-dealer to sell fund shares; sets concessions and 12b-1 payments"),
   ("Distribution Agreement", "Appointment of a distributor or sub-distributor (EU/UK: ManCo/global distributor with local distributor)"),
   ("Platform Agreement", "Access to a fund platform, supermarket or EU/UK platform (e.g. Allfunds, Fundsettle-style)"),
   ("Sub-TA / Shareholder Servicing Agreement", "Omnibus, sub-accounting, recordkeeping or shareholder services"),
   ("Networking Agreement", "DTCC Networking participation for broker-controlled or fund-controlled accounts"),
   ("Revenue Sharing / Marketing Support Agreement", "Payments from the adviser/distributor's own resources for distribution and marketing support"),
   ("DCIO / Recordkeeper Services Agreement", "Services and payments for defined-contribution recordkeeping platforms"),
   ("Model Delivery / SMA Sponsor Agreement", "Model provider or discretionary manager agreement with an SMA/UMA sponsor, TAMP or model marketplace"),
   ("Data Licensing / Data Sharing Agreement", "Supply of distribution data (positions, transactions, rep-level) and its permitted use"),
   ("Placement Agent Agreement", "Placement of private or institutional funds"),
   ("Nominee Agreement", "Nominee holding of units on behalf of underlying investors (EU/UK)"),
   ("Retrocession / Rebate Agreement", "EU/UK trail commission or management-fee rebate to a distributor or platform"),
   ("Shareholder Information Agreement (Rule 22c-2)", "Allows the fund to request shareholder trading data from the intermediary"),
   ("Unit-Linked / Insurance Distribution Agreement", "Fund access for insurer unit-linked wrappers"),
   ("Confidentiality Agreement", "NDA ahead of commercial negotiation")]),
 "Agreement Paper": ("Internal", [("Firm Paper","Firm's standard template"),("Partner Paper","Partner's standard template"),("Industry Standard Form","e.g. platform master agreement signed by all fund houses"),("Bespoke","Negotiated from scratch")]),
 "Agreement Market": ("Internal", [("US",""),("UK",""),("EU",""),("Switzerland",""),("Cross-Border / Global","")]),
 "Agreement Status": ("Internal", [("Draft",""),("In Negotiation",""),("Pending Signature",""),("Active",""),("Suspended","Payments or trading suspended pending remediation"),("Under Notice of Termination",""),("Terminated",""),("Expired",""),("Superseded","Replaced by a new agreement")]),
 "Governing Law": ("Internal", [("New York",""),("Delaware",""),("Massachusetts",""),("California",""),("England and Wales",""),("Scotland",""),("Luxembourg",""),("Ireland",""),("Germany",""),("Switzerland",""),("Other","")]),
 "Agreement Party Role": ("Internal (aligned to FINRA Rule 2341 and FIBO party roles)", [("Principal Underwriter / Distributor","Firm's registered distributor"),("Fund / Issuer",""),("Investment Adviser",""),("Management Company","EU UCITS ManCo / AIFM"),("Selling Dealer",""),("Clearing Firm",""),("Platform",""),("Sub-Transfer Agent / Servicer",""),("Recordkeeper",""),("Nominee",""),("SMA / UMA Sponsor",""),("Model Marketplace",""),("Insurer",""),("Placement Agent",""),("Data Provider",""),("Data Recipient","")]),
 "Term Type": ("Internal", [("Fixed Term",""),("Auto-Renewing",""),("Evergreen","Continues until terminated on notice")]),
 "Termination Reason": ("Internal", [("Replaced by New Agreement",""),("Commercial Non-Renewal",""),("Partner Exit / Acquisition",""),("Product Closure",""),("Regulatory Change",""),("Breach",""),("Due Diligence Failure",""),("Mutual Agreement","")]),
 "Initiating Party": ("Internal", [("Firm",""),("Partner",""),("Both / Mutual","")]),
 "Amendment Type": ("Internal", [("Amendment",""),("Side Letter",""),("Fee Schedule Replacement",""),("Product Schedule Update",""),("Addendum",""),("Assignment / Novation",""),("Waiver","")]),
 "Agreement Document Type": ("Internal", [("Executed Agreement",""),("Amendment",""),("Side Letter",""),("Fee Schedule",""),("Product Schedule",""),("Operating Procedures / Exhibit",""),("Notice Letter",""),("Termination Letter","")]),
 "Coverage Basis": ("Internal", [("All Products","All current and future products"),("All Products Except Listed",""),("Product Range",""),("Vehicle Type",""),("Specific Products",""),("Specific Share Classes","")]),
 "Inclusion Type": ("Internal", [("Include",""),("Exclude","")]),
 "Partner Channel": ("Internal", [("Wirehouse",""),("Regional Broker-Dealer",""),("Independent Broker-Dealer",""),("RIA Custodian",""),("Bank / Trust",""),("Private Bank",""),("Fund Platform / Supermarket",""),("Insurer / Unit-Linked",""),("DCIO / Recordkeeper",""),("TAMP",""),("Model Marketplace",""),("IFA Network",""),("Discretionary Fund Manager","UK DFM"),("Institutional Consultant","")]),
 "Service Model": ("Internal (aligned to MiFID II service types)", [("Execution-Only",""),("Brokerage","Commission-based advice (US)"),("Fee-Based Advisory",""),("Non-Independent Advice","MiFID"),("Independent Advice","MiFID; inducements must be passed on"),("Discretionary Portfolio Management",""),("Retirement Plan","")]),
 "Account Structure": ("Internal", [("Omnibus","Single account at TA; intermediary keeps sub-accounts"),("Networked","Individual accounts at TA via DTCC Networking"),("Fully Disclosed / Direct","Investor registered directly at TA"),("Nominee","EU/UK nominee holding"),("Plan-Level","Retirement plan omnibus")]),
 "Account Link Role": ("Internal", [("Omnibus Trading Account",""),("Networked Account Group",""),("Fee Billing Account",""),("Plan Account","")]),
 "Payment Type": ("Internal (aligned to ICI and SEC staff terminology)", [
   ("Revenue Sharing - Asset-Based","bps on qualifying assets"),("Revenue Sharing - Sales-Based","bps on gross sales"),("Revenue Sharing - Flat Fee",""),
   ("Sub-TA / Sub-Accounting Fee","Per-account or asset-based fee for recordkeeping"),("Networking Fee","Per-account fee for networked accounts"),
   ("12b-1 Distribution Fee",""),("12b-1 Service Fee",""),("Shareholder Servicing Fee (Non-12b-1)",""),
   ("Dealer Concession / Commission","Front-end sales charge reallowance or advance"),("Platform / Shelf Fee",""),("Data Fee",""),
   ("Conference / Education Sponsorship",""),("Model Delivery Fee",""),("DCIO Recordkeeping Fee",""),
   ("Trail Commission (EU/UK)",""),("Retrocession (EU/UK)",""),("Placement Fee","")]),
 "Payment Direction": ("Internal", [("Payable to Partner",""),("Receivable from Partner","e.g. platform data revenue share or fee rebate")]),
 "Funding Source": ("SEC Rule 12b-1 / SEC IM Guidance 2016-01 / Internal", [("Fund - Rule 12b-1 Plan","Fund assets used to finance distribution under a written plan"),("Fund - Non-Distribution Services","Fund-paid sub-TA / servicing that is not distribution"),("Adviser - Own Resources","Revenue sharing paid from the adviser's legitimate profits"),("Distributor - Own Resources","Principal underwriter pays, e.g. from retained sales charges"),("Management Company - Fee Share","EU/UK: retrocession paid out of the management fee"),("Share Class Distribution Fee (EU)","Separate distribution fee charged to the class")]),
 "Compensated Service": ("SEC IM Guidance 2016-01 / Internal", [("Distribution",""),("Marketing Support",""),("Shelf / Platform Access",""),("Sub-Accounting / Recordkeeping",""),("Shareholder Servicing",""),("Data Provision",""),("Education / Training",""),("Conference Participation",""),("Model Delivery","")]),
 "Arrangement Status": ("Internal", [("Proposed",""),("Active",""),("Suspended",""),("Ended","")]),
 "Calculation Basis": ("Internal (aligned to ICI intermediary payment terminology)", [("Average Daily Net Assets",""),("Month-End Assets",""),("Average Month-End Assets",""),("Gross Sales",""),("Net Sales",""),("Per Account",""),("Per Position",""),("Per Participant",""),("Flat Fee",""),("Per Event",""),("Management Fee Revenue","EU/UK retrocession basis")]),
 "Rate Type": ("Internal", [("Basis Points per Annum",""),("Basis Points on Sales",""),("Percentage of Fee",""),("Amount per Unit",""),("Flat Amount","")]),
 "Tiering Method": ("Internal", [("None",""),("Incremental","Each tier rate applies to the band of basis inside it"),("Cliff / Whole Balance","Rate of the tier reached applies to the entire basis")]),
 "Aggregation Level": ("Internal", [("Partner Firm",""),("Agreement",""),("Platform / Programme",""),("Fund Family",""),("Product",""),("Share Class","")]),
 "Asset Exclusion": ("Internal", [("Money Market Funds",""),("Retirement Plan Assets",""),("Assets Pre-Dating Agreement","Legacy assets"),("Proprietary / Affiliated Accounts",""),("Institutional Share Classes",""),("Assets in Other Payment Arrangements","Avoid double payment")]),
 "Alternative Rate Rule": ("Internal", [("Single Rate",""),("Greater Of",""),("Lesser Of",""),("Sum","")]),
 "Tier Bound Unit": ("Internal", [("Asset Amount",""),("Sales Amount",""),("Account Count",""),("Participant Count","")]),
 "Account Fee Unit": ("ICI / Internal", [("Per Open Account",""),("Per Open Position",""),("Per Closed Account",""),("Per Participant",""),("Per Networked Account","")]),
 "Networking Level": ("DTCC NSCC Networking", [("Level 0","Intermediary keeps all account records; fund does not deal with shareholder (commonly trust / plan accounts)"),("Level 1","Fund and intermediary may both update account; fund-controlled servicing"),("Level 3","Firm-controlled: intermediary handles all customer contact, orders, statements and tax reporting"),("Level 4","Fund-controlled: intermediary processes orders; fund provides statements, accounting and tax reporting"),("Not Networked","Omnibus or direct")]),
 "12b-1 Component": ("SEC Rule 12b-1 / FINRA Rule 2341", [("Distribution Fee","Asset-based sales charge"),("Service Fee","Personal service and account maintenance; FINRA caps at 0.25% p.a.")]),
 "Retrocession Basis": ("Internal", [("% of Management Fee",""),("bps of Assets",""),("% of Entry Charge","")]),
 "Offset Method": ("SEC IM Guidance 2016-01 / Internal", [("None",""),("Net of 12b-1",""),("Net of 12b-1 and Sub-TA",""),("Credited Against Cap","")]),
 "Frequency": ("Internal", [("Daily",""),("Weekly",""),("Monthly",""),("Quarterly",""),("Semi-Annual",""),("Annual",""),("Ad Hoc","")]),
 "Billing Method": ("Internal", [("Partner Invoice",""),("Firm-Generated Statement","Self-billing"),("Netted at Settlement",""),("Platform Deduction","Platform deducts from rebates or settlement")]),
 "Adjustment Reason": ("Internal", [("Prior Period True-Up",""),("Cap Applied",""),("Offset Applied",""),("Basis Data Correction",""),("Manual Override","")]),
 "Calculation Status": ("Internal", [("Draft",""),("Calculated",""),("Under Review",""),("Approved",""),("Accrued",""),("Settled","")]),
 "Invoice Status": ("Internal", [("Received",""),("Matched",""),("Under Review",""),("Disputed",""),("Approved",""),("Paid",""),("Rejected","")]),
 "Dispute Reason": ("Internal", [("Basis Assets Mismatch",""),("Account Count Mismatch",""),("Rate Mismatch",""),("Out-of-Scope Product",""),("Duplicate",""),("Agreement Not Active","")]),
 "Payment Status": ("Internal", [("Scheduled",""),("Released",""),("Settled",""),("Failed",""),("Reversed","")]),
 "Programme Type": ("Internal", [("Strategic Partnership",""),("Marketing Support",""),("Education / Practice Management",""),("Conference Sponsorship",""),("Data Partnership",""),("Model Marketplace Membership",""),("Platform Preferred Partner","")]),
 "Partner Tier": ("Internal", [("Tier 1 / Platinum",""),("Tier 2 / Gold",""),("Tier 3 / Silver",""),("Standard",""),("Not a Member","")]),
 "Renewal Decision": ("Internal", [("Renew - Same Tier",""),("Renew - Upgrade",""),("Renew - Downgrade",""),("Do Not Renew",""),("Pending","")]),
 "Benefit Type": ("Internal", [("Home-Office Access",""),("Field / Branch Access",""),("Conference Participation",""),("Speaking Slot",""),("Data Access",""),("Platform Listing / Featured Placement",""),("Research Team Access",""),("Education / CE Event",""),("Co-Branded Content","")]),
 "Shelf List Type": ("Internal", [("Platform Shelf","Available to trade"),("Approved List",""),("Recommended List",""),("Focus List",""),("Model Eligible List",""),("Advisory Programme Line-Up",""),("Retirement Plan Menu",""),("Sell-Only / Hold List","")]),
 "Placement Status": ("Internal", [("Proposed",""),("Under Review",""),("Approved - Pending Setup",""),("Approved - Available",""),("On Watch",""),("Closed to New Investors",""),("Restricted / Sell-Only",""),("Removed",""),("Declined","")]),
 "Placement Change Reason": ("Internal", [("New Placement",""),("Research Upgrade",""),("Research Downgrade",""),("Share Class Change",""),("Platform Rationalisation",""),("Commercial Terms",""),("Product Event","Merger, closure, PM change")]),
 "Account Eligibility": ("Internal (aligned to SEC Reg BI account types)", [("Brokerage",""),("Fee-Based Advisory",""),("Discretionary Advisory",""),("IRA",""),("Employer Retirement Plan",""),("SMA / Wrap",""),("UMA",""),("ISA / SIPP","UK wrappers"),("Unit-Linked Policy","")]),
 "Normalised Research Rating": ("Internal", [("Recommended",""),("Approved",""),("Neutral / Hold",""),("Watch",""),("Sell / Remove",""),("Not Rated","")]),
 "Review Type": ("Internal", [("Initial Review",""),("Annual Review",""),("Event-Driven Review",""),("Onsite Visit","")]),
 "Watch List Reason": ("Internal", [("Performance",""),("Portfolio Manager Change",""),("Organisational Change",""),("Asset Flows",""),("Style Drift",""),("Fee Competitiveness","")]),
 "Sponsor Programme Type": ("Internal", [("SMA - Single Contract / Wrap",""),("SMA - Dual Contract",""),("UMA",""),("Model Marketplace",""),("TAMP",""),("Mutual Fund Advisory Programme","")]),
 "Programme Role": ("Internal", [("Discretionary Manager",""),("Model Provider",""),("Sub-Adviser","")]),
 "Setup Status": ("Internal", [("Requested",""),("In Progress",""),("Live",""),("Suspended",""),("Closed","")]),
 "Dealing Route": ("Internal", [("NSCC Fund/SERV",""),("Calastone",""),("Clearstream Vestima",""),("Euroclear FundSettle",""),("Allfunds",""),("SWIFT Direct",""),("TA Direct / Manual","Fax, email or portal")]),
 "Message Standard": ("Internal", [("ISO 20022",""),("ISO 15022",""),("NSCC Record Formats",""),("Proprietary","")]),
 "Settlement Method": ("Internal", [("NSCC Net Settlement",""),("Calastone Settlement",""),("ICSD (Clearstream / Euroclear)",""),("Bank Transfer / Wire","")]),
 "Servicing Responsibility": ("DTCC NSCC Networking / Internal", [("Fund Transfer Agent",""),("Intermediary",""),("Shared","")]),
 "Data Content Type": ("Internal", [("Positions / AUM",""),("Transactions",""),("Account / Registration",""),("Advisor / Rep Hierarchy",""),("Shelf / Eligibility",""),("Fee / Payment Statement",""),("EMT / EPT / EET","FinDatEx templates"),("Model Holdings","")]),
 "Data Granularity": ("Internal", [("Firm",""),("Branch / Office",""),("Advisor / Rep",""),("Account",""),("Anonymised Account","")]),
 "Partner Disclosure Type": ("Internal (aligned to SEC Reg BI, FINRA Rule 2341, DOL 408(b)(2), MiFID II)", [("Partner Revenue Sharing Disclosure","Partner's published list of payments received from fund sponsors"),("Form CRS Conflicts Disclosure",""),("Prospectus / SAI Intermediary Payments",""),("DOL 408(b)(2) Indirect Compensation",""),("MiFID Ex-Ante Costs & Charges",""),("MiFID Ex-Post Costs & Charges",""),("MiFID Inducement Disclosure",""),("UK Platform Charges Disclosure","")]),
 "Data Delivery Channel": ("Internal", [("Direct","SFTP / API to distributor"),("Data Vendor","e.g. regulatory data distribution vendor"),("Platform Upload",""),("Website","")]),
 "Obligation Category": ("Internal", [("Data Delivery",""),("Regulatory Reporting",""),("AML / KYC",""),("Marketing Material Use",""),("Training",""),("Confidentiality / Data Protection",""),("Insurance",""),("Audit Rights",""),("Notice",""),("Exclusivity",""),("Most-Favoured Nation","")]),
 "Compliance Status": ("Internal", [("Met",""),("Not Yet Due",""),("Overdue",""),("Breached",""),("Waived","")]),
 "SLA Metric Type": ("Internal", [("Timeliness",""),("Accuracy",""),("Completeness",""),("Availability",""),("Response Time","")]),
 "SLA Unit": ("Internal", [("% of Deliveries",""),("% of Records",""),("Hours",""),("Business Days","")]),
 "Attestation Type": ("Internal", [("SOC 1 Type II Report","Controls report over sub-TA / recordkeeping"),("Sub-TA Services Certification",""),("AML / CIP Certification",""),("Rule 22c-2 Compliance Certification",""),("Data Protection Attestation",""),("Anti-Bribery Certification",""),("Inducement Quality-Enhancement Confirmation","EU/UK")]),
 "Attestation Outcome": ("Internal", [("Satisfactory",""),("Satisfactory with Exceptions",""),("Unsatisfactory",""),("Not Received","")]),
 "Access Classification": ("Internal", [("Internal",""),("Restricted - Commercial Terms",""),("Restricted - Legal",""),("Confidential - Side Letter","")]),
 "Data Quality Status": ("Internal", [("Draft",""),("Validated",""),("Exception",""),("Retired","")]),
}

# ---------------------------------------------------------------------------
# Relationships
# ---------------------------------------------------------------------------
REL = [
 ("Distribution Agreement","is signed by","Agreement Party Role -> Party (PTY-, 02 Client & Customer)","1 : 2..n","Firm contracting entity plus at least one partner."),
 ("Distribution Agreement","is a child of","Distribution Agreement (master)","n : 0..1","Platform master agreements and schedules."),
 ("Distribution Agreement","is changed by","Agreement Amendment","1 : 0..n","Effective-dated amendments and side letters."),
 ("Distribution Agreement","is evidenced by","Agreement Document","1 : 1..n",""),
 ("Distribution Agreement","covers","Agreement Product Coverage -> Product / Share Class / Model (PRD-/SHC-/MDL-, 01 Product)","1 : 1..n","Include/exclude lines, effective-dated."),
 ("Distribution Agreement","is limited by","Agreement Distribution Scope","1 : 1",""),
 ("Distribution Agreement","governs","Agreement Account Link -> Account (ACC-, 02 Client & Customer)","1 : 0..n","Omnibus, networked and plan accounts."),
 ("Distribution Agreement","provides for","Payment Arrangement","1 : 0..n","Selling agreement may carry 12b-1 pass-through and concessions; rev-share agreement carries rev-share."),
 ("Payment Arrangement","is priced by","Rate Schedule","1 : 1..n","Effective-dated versions."),
 ("Rate Schedule","has","Rate Tier","1 : 0..n",""),
 ("Payment Arrangement","is calculated from","Data Feed (FEED-) / Position (POS-), 06 Sales Transactions & AUM","n : 1..n","Basis assets, sales and account counts come from 06; 05 does not store flows or AUM."),
 ("Payment Arrangement","is calculated as","Payment Calculation","1 : 0..n","One per period."),
 ("Payment Calculation","is billed by","Partner Invoice","n : 0..1",""),
 ("Partner Invoice","is settled by","Partner Payment","n : 0..n",""),
 ("Payment Arrangement","is assessed by","Compliance Review (REV-, 08 Distribution Compliance)","n : 0..1","EU/UK inducement quality-enhancement assessment."),
 ("Distribution Agreement","relies on","Distributor Due Diligence (DDQ-, 08 Distribution Compliance)","n : 0..1","Know-your-distributor review before and during the agreement."),
 ("Partner Programme","is sponsored by","Party (PTY-)","n : 1",""),
 ("Partner Programme","has","Programme Membership","1 : 0..n","Firm membership by year and tier."),
 ("Programme Membership","is funded by","Distribution Agreement / Payment Arrangement","n : 1",""),
 ("Programme Membership","grants","Programme Benefit","1 : 0..n",""),
 ("Programme Benefit","is used at","Event (EVT-, 04 Marketing & Digital)","n : 0..n","Conference and education events."),
 ("Shelf Placement","places","Product / Share Class (PRD-/SHC-) on Party (PTY-)","n : 1 each","One record per partner x platform/programme x share class, effective-dated."),
 ("Shelf Placement","is mapped by","Share Class Mapping","1 : 0..n","Which class per partner account type."),
 ("Shelf Placement","was won through","Opportunity (OPP-, 03 Sales)","n : 0..1",""),
 ("Partner Research Rating","rates","Product (PRD-)","n : 1","Issued by a partner research team or gatekeeper (PTY-)."),
 ("Partner Research Rating","is supported by","RFP / DDQ Response (RFP-, 03 Sales)","n : 0..n",""),
 ("Model Programme Placement","places","Model Portfolio (MDL-, 01 Product)","n : 1",""),
 ("Partner Dealer Setup","is established under","Distribution Agreement","n : 1","Selling or platform agreement."),
 ("Trading Setup / Networking Setup","applies to","Partner Dealer Setup","n : 1",""),
 ("Partner Data Feed Arrangement","delivers","Data Feed (FEED-, 06 Sales Transactions & AUM)","1 : 1",""),
 ("Partner Data Feed Arrangement","is governed by","Distribution Agreement (data licensing)","n : 1",""),
 ("Payment Disclosure","discloses","Payment Arrangement","n : n",""),
 ("Distribution Agreement","imposes","Agreement Obligation / Service Level Agreement","1 : 0..n",""),
 ("Service Level Agreement","is measured by","SLA Measurement","1 : 0..n",""),
 ("Distribution Agreement / Programme Membership / Agreement Obligation","is owned by","Employee (EMP-, 03 Sales)","n : 1","Business owner, relationship manager, obligation owner."),
 ("Partner Payment","is recognised in","Crediting / compensation (07 Compensation & Territory)","n/a","Partner payments are not wholesaler compensation; 07 may use shelf status and programme tier as inputs only."),
]

# ---------------------------------------------------------------------------
# Sources: (source, owner, url, licence, coverage, used_in, [primary_ref labels])
# ---------------------------------------------------------------------------
SRC = [
 ("SEC Rule 12b-1 (17 CFR 270.12b-1)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.12b-1","Regulation (public)","Use of fund assets to finance distribution under a written plan; written agreements with recipients","Funding Source, 12b-1 Component, Pass-Through Rate, Rule 12b-1 Plan Reference",["SEC Rule 12b-1"]),
 ("SEC Division of Investment Management Guidance Update 2016-01: Mutual Fund Distribution and Sub-Accounting Fees","US SEC","https://www.sec.gov/investment/im-guidance-2016-01.pdf","Staff guidance (public)","Board oversight of sub-accounting fees; distribution-in-guise; tiered payment structures (12b-1, then sub-TA, then revenue share)","Services Compensated, Fund-Paid Sub-TA Cap, Offset Method, Payment Waterfall, Account Structure",["SEC IM Guidance 2016-01"]),
 ("FINRA Rule 2341 Investment Company Securities (formerly NASD Rule 2830)","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2341","Rule (public)","Sales charge limits incl. service fee cap, cash compensation must be described in the prospectus, non-cash compensation limits and records","Agreement Type, Prospectus Disclosure Indicator, 12b-1 Component, Non-Cash Compensation Relevance",["FINRA Rule 2341"]),
 ("SEC Regulation Best Interest (17 CFR 240.15l-1) and Form CRS","US SEC","https://www.sec.gov/rules/final/2019/34-86031.pdf","Regulation (public)","Broker-dealer disclosure and mitigation of conflicts including revenue sharing; account types","Partner Disclosure Type, Firm Listed Indicator, Account Eligibility",["SEC Reg BI"]),
 ("SEC Form N-1A","US SEC","https://www.sec.gov/files/formn-1a.pdf","Form (public)","Prospectus/SAI disclosure of payments to intermediaries and intermediary-specific sales charge waivers","Sales Charge Waiver Indicator; secondary on Prospectus Disclosure Indicator",["SEC Form N-1A"]),
 ("SEC Rule 22c-2 (17 CFR 270.22c-2)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.22c-2","Regulation (public)","Shareholder information agreements with financial intermediaries","Rule 22c-2 Agreement Indicator, Agreement Type",["SEC Rule 22c-2"]),
 ("SEC Rule 17a-4 (17 CFR 240.17a-4)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.17a-4","Regulation (public)","Broker-dealer record retention","Document Retention End Date",["SEC Rule 17a-4"]),
 ("DOL ERISA 408(b)(2) service provider fee disclosure (29 CFR 2550.408b-2)","US Department of Labor (EBSA)","https://www.law.cornell.edu/cfr/text/29/2550.408b-2","Regulation (public)","Covered service provider disclosure of direct and indirect compensation, payer and arrangement","408(b)(2) Compensation Disclosure",["DOL 408(b)(2)"]),
 ("DTCC NSCC Fund/SERV and Networking","DTCC","https://www.dtcc.com/wealth-management-services/mutual-fund-services","Participant documentation (some public)","Fund order processing and settlement; Networking matrix levels for broker- and fund-controlled accounts","Dealing Route, Settlement Method, Networking Level, Servicing Responsibility",["DTCC NSCC Fund/SERV","DTCC NSCC Networking"]),
 ("MiFID II Directive 2014/65/EU Art. 24(9) and Delegated Directive (EU) 2017/593 Art. 11","European Union / ESMA","https://eur-lex.europa.eu/eli/dir/2017/593/oj","Regulation (public)","Inducements: quality-enhancement test, disclosure, pass-on for independent advice and portfolio management; costs & charges","Inducement Relevance, Retrocession, Pass-On Required, Ex-Post Inducement Amount",["MiFID II","MiFID II Delegated Directive 2017/593"]),
 ("FCA Handbook COBS 2.3A, 6.1A, 6.1B and 6.1E (RDR adviser charging and platform rules)","UK FCA","https://www.handbook.fca.org.uk/handbook/COBS/6/1E.html","Regulation (public)","UK inducement rules, ban on commission for retail advice, platform remuneration only via platform charges, cash rebate restrictions","UK Legacy Trail Indicator, Pass-On Required, UK Platform Charges Disclosure",["UK FCA COBS"]),
 ("FinDatEx European MiFID Template (EMT)","FinDatEx","https://findatex.eu","Free template","Manufacturer-to-distributor exchange of target market and costs & charges data, including distribution fee data","Distributor Data Exchange",["FinDatEx EMT"]),
 ("ISO 20022 investment funds messages (setr, reda)","ISO / SWIFT (Registration Authority)","https://www.iso20022.org/catalogue-messages","Standard (free catalogue)","Fund order, confirmation and fund reference data messages; payment references","Message Standard, Dealing BIC, Bank Payment Reference",["ISO 20022"]),
 ("ISO 9362 (BIC)","ISO / SWIFT","https://www.swift.com/standards/data-standards/bic-business-identifier-code","Standard","Business Identifier Codes","Dealing BIC",["ISO 9362"]),
 ("ICI / IDC: Navigating Intermediary Relationships (2022) and ICI research on intermediary payments","Investment Company Institute / Independent Directors Council","https://www.idc.org/files/2022/22-ppr-navigating-intermediary-relationships.pdf","Free","Taxonomy of intermediary payments (distribution, sub-accounting, revenue sharing), oversight practices","Payment Type, Calculation Basis, Account Fee Unit, Offset Method",["ICI"]),
 ("Broadridge Intermediary Fee Management / SS&C (DST) intermediary payment solutions","Broadridge; SS&C","https://www.broadridge.com/financial-services/asset-management/mutual-funds-etf/drive-profitability-with-automated-revenue-and-expense-management/intermediary-fee-management","Proprietary / licensed","Rule libraries for distribution, servicing and revenue-sharing calculations, invoice reconciliation and payment workflow","Cross-check for Rate Schedule, Payment Calculation, Partner Invoice (not a primary source)",[]),
 ("Calastone, Clearstream Vestima, Euroclear FundSettle and Allfunds","Market infrastructure providers","https://www.calastone.com","Proprietary","EU/UK fund order routing, settlement and platform distribution models","Dealing Route, Settlement Method, Platform Participant ID (code values only)",[]),
 ("openfunds","openfunds Association","https://www.openfunds.org","Free open standard","Share-class minimum investment fields","Secondary reference for platform minimums (no Primary attributes)",[]),
 ("DCAM","EDM Council","https://edmcouncil.org","Member framework","Data ownership and stewardship","Data Management Metadata",["DCAM (EDM Council)"]),
]
