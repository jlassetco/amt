"""Business domain 06 - Sales Transactions & AUM Attribution. Content module for taxonomy_builder.py."""

META = {
 "title": "Sales Transactions & AUM Attribution Data Taxonomy",
 "subtitle": "Business domain 06 - Sales Transactions & AUM Attribution | Asset manager (wholesale distributor) | Scope: US + EU/UK | Draft v0.1 | 2026-10-01",
 "output": "06_Sales_Transactions_and_AUM_Attribution/Sales_Transactions_and_AUM_Attribution_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the sales transaction, holdings, flow/AUM measure and attribution data of an asset manager that distributes wholesale. It answers 'who sold what, where, and how much AUM sits with each distributor firm, office, advisor, territory, plan and institution', stitched together from industry processing standards (DTCC/NSCC Fund/SERV, Networking, Omni/SERV and DCC&S; ISO 20022 setr/semt investment-fund messages; FundsXML), industry flow definitions (ICI, EFAMA, Morningstar) and the data structures of distribution-data aggregators and EU/UK fund platforms (Broadridge, ISS Market Intelligence, Calastone, Clearstream Vestima, Allfunds). Use it as a starting point for a sales-data warehouse, an attribution engine, a data catalogue or a business glossary."),
  ("Scope", "In scope: transactions and their reference attributes (type, dates, amounts, sales charges, order channel, intermediary identifiers as delivered, cancellations and corrections, ETF primary-market creations/redemptions, SMA contributions/withdrawals); positions and holdings (direct, networked, omnibus and look-through, ETF holdings by broker/custodian, DCIO plan-level and SMA/UMA sponsor-reported assets); flow and AUM measure definitions and calculation rules; attribution of flows and assets to distributor hierarchy, territory, channel, plan, institution and salesperson; identity resolution / rep matching of source identifiers; data sources and feeds (FEED- master), file/load metadata; data quality and reconciliation; reporting periods, snapshots and restatements; light industry flow benchmarks. Out of scope (referenced by ID only): party master, distributor hierarchy, party identifiers and accounts (02 Client & Customer: PTY-, ACC-); products, share classes, fee rates and model portfolios (01 Product: PRD-, SHC-, MDL-); internal sales personnel (03 Sales: EMP-); data-licensing, selling, networking and platform agreements, payment arrangements such as 12b-1 pass-through, retrocessions and rev share (05 Distribution Agreements & Partners: AGR-); territories, alignment rules, crediting rules, goals and incentive payouts (07 Compensation & Territory: TER-, CRR-, GOL-, ICP-); distributor due diligence and inducement compliance (08 Distribution Compliance). Marketing attribution (campaign influence) belongs to 04 Marketing & Digital."),
  ("Nature of the data", "Transactions, positions and measure values are high-volume transactional / time-series data. This taxonomy does not hold values; it defines their structure (grain, keys, dates, measures) and the reference attributes and code lists that describe them, so that every data source can be mapped to one common model."),
  ("Structure", "Four levels: Domain > Subdomain > Concept > Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Data Feed (FEED-) -> Load -> Transaction (TXN-) and Position (POS-) as delivered, each carrying source intermediary identifiers -> Identity Resolution maps those identifiers to parties (PTY-) and accounts (ACC-) -> Attribution Record splits each transaction / position amount across distributor firm, office, advisor, territory (TER-), channel, plan and institution, and credits salespeople (EMP-) by applying crediting rules (CRR-) owned by 07 -> Measure Definitions (gross sales, redemptions, net flows, market movement, AUM, average AUM, organic growth, revenue estimate) aggregate attributed facts by period into Snapshots that are locked, reconciled and, where needed, restated."),
  ("Design principles", "1) Keep the as-delivered source values (dealer, branch, rep codes; source transaction codes) alongside resolved IDs, so lineage and re-matching are always possible. 2) Define each flow and AUM measure once, with an explicit formula, inclusion/exclusion rules and alignment to ICI / EFAMA definitions. 3) Every attribution carries a method and confidence; estimated and allocated amounts are never mixed silently with actuals. 4) Unattributed assets are held explicitly in suspense, never dropped. 5) Month-end results are snapshotted and locked; changes after lock are restatements with a reason and impact. 6) Reference parties, accounts, products, territories and crediting rules by ID; do not copy their attributes. 7) Flag Critical Data Elements (CDE) for governance and data-quality focus."),
  ("Applies To", "Shows the record type at which each attribute is held: Transaction, Position, Measure Definition, Measure Value, Attribution Record, Unattributed Item, Override, Identifier Crosswalk, Match Rule, Feed, Load, Reconciliation, Break, DQ Rule, Industry Dataset, Snapshot, Restatement or All."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify a transaction or position, calculate a published flow / AUM measure, attribute assets to a distributor or salesperson (and therefore drive incentive compensation), or reconcile to the books and records. Confirm with data owners."),
  ("Primary / Secondary Reference", "Standard or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Several sources (DTCC record layouts, aggregator data dictionaries, Calastone and Vestima message specifications) are member- or licence-restricted, so attribute names are aligned to their public descriptions; map to exact field IDs during implementation."),
  ("Tabs", "Hierarchy: domains, subdomains and concepts with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: concept-level cardinalities for the logical model, including cross-domain references | Sources: standards and data sources used, owners, licences and links."),
  ("Suggested next steps", "1) Validate measure definitions (especially net flows, exchanges, reinvestments and transfers) with Finance, Distribution Analytics and Sales Operations, and publish one certified measure catalogue. 2) Inventory actual feeds into the FEED- master and map each to the Transaction / Position concepts. 3) Agree attribution methods and the hierarchy of sources (TA direct > Networking > Omni/SERV > aggregator > estimate) per channel. 4) Agree with 02 Client & Customer who owns the source-identifier crosswalk and rep-matching stewardship. 5) Agree with 07 Compensation & Territory the hand-off of attributed flows to crediting and the restatement policy after comp close. 6) Map attributes to source systems (TA, sub-accounting, aggregator, data warehouse). 7) Consider a separate 'Market & Competitive Intelligence' business domain for industry flows and market share."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Transactions", "TX-TRN",
  "Individual purchases, redemptions, exchanges, transfers, reinvestments, conversions, ETF primary-market creations/redemptions and SMA contributions/withdrawals, as received from transfer agents, intermediaries, platforms, recordkeepers and sponsors.",
  [
   ("Transaction Core", "Identity, type, product and account of a transaction.", [
     ("Transaction", [
       ("Transaction ID", "Unique internal identifier for the transaction record after load and de-duplication.", "Transaction", "Identifier", "", "TXN-2026-000418273", "Internal", "", "Y"),
       ("Source Transaction Reference", "Identifier of the transaction in the delivering system (TA confirm number, Fund/SERV control number, platform order reference).", "Transaction", "Identifier", "", "FS2026091800017734", "DTCC Fund/SERV", "ISO 20022", ""),
       ("Source Feed", "Data feed from which the transaction was received.", "Transaction", "Reference (Feed)", "", "FEED-003", "Internal", "", ""),
       ("Transaction Type", "Normalised business type of the transaction.", "Transaction", "Code", "Transaction Type", "Purchase", "ICI", "ISO 20022", "Y"),
       ("Source Transaction Code", "Transaction code exactly as delivered by the source (TA, Omni/SERV, platform), retained for lineage and re-mapping.", "Transaction", "Code", "External (Source system)", "TA2000 'Purchase - New Money'", "SS&C DST", "", ""),
       ("Flow Direction", "Whether the transaction adds to, removes from or is neutral to the firm's assets.", "Transaction", "Code", "Flow Direction", "Inflow", "Internal", "", ""),
       ("Share Class", "Share class transacted.", "Transaction", "Reference (Share Class)", "", "SHC-004512", "Internal", "", "Y"),
       ("Product", "Product / vehicle of the share class, or the mandate / model for SMA flows; derived from 01 Product.", "Transaction", "Reference (Product)", "", "PRD-00981", "Internal", "", ""),
       ("Product Identifier As Delivered", "Product identifier exactly as received (CUSIP, ISIN, TA fund number, platform fund code).", "Transaction", "Identifier", "External (Source system)", "LU1234567890", "ISO 20022", "", ""),
       ("Account", "Investor, networked, omnibus or plan account against which the transaction was booked.", "Transaction", "Reference (Account)", "", "ACC-0081123", "Internal", "", "Y"),
       ("Look-Through Level", "Level of visibility the record provides into the underlying investor.", "Transaction, Position", "Code", "Look-Through Level", "Omnibus Sub-Account", "Internal", "DTCC Omni/SERV", "Y"),
       ("Networking Matrix Level (As Delivered)", "NSCC Networking matrix level reported with the record; authoritative value is held on the account in 02 Client & Customer.", "Transaction", "Code", "Networking Matrix Level", "Level 3 - Firm Controlled", "DTCC Networking", "", "", "Captured for lineage only"),
     ]),
   ]),
   ("Dates & Amounts", "Trade dates, quantities, prices and amounts of a transaction.", [
     ("Transaction Dates", [
       ("Trade Date", "Date the order was priced / executed at NAV (or traded on exchange).", "Transaction", "Date", "ISO 8601", "2026-09-18", "ISO 20022", "DTCC Fund/SERV", "Y"),
       ("Settlement Date", "Date cash and units settled.", "Transaction", "Date", "ISO 8601", "2026-09-19", "ISO 20022", "", ""),
       ("As-Of Date", "Effective date for back-dated (as-of) trades processed after the trade date, e.g. to correct a processing error.", "Transaction", "Date", "ISO 8601", "2026-09-15", "SS&C DST", "", "Y"),
     ]),
     ("Transaction Amounts", [
       ("Units", "Number of shares / units transacted (signed by Flow Direction in measures; stored unsigned).", "Transaction", "Decimal", "", "1,250.4472", "ISO 20022", "", "Y"),
       ("Price", "Dealing price applied (NAV, offer or exchange price).", "Transaction", "Decimal", "", "24.1873", "ISO 20022", "", ""),
       ("Gross Amount", "Transaction amount before sales charges and fees.", "Transaction", "Amount", "", "USD 30,250.00", "ISO 20022", "ICI", "Y"),
       ("Net Amount", "Amount invested or paid out after sales charges, CDSC and fees.", "Transaction", "Amount", "", "USD 29,190.25", "ISO 20022", "", ""),
       ("Transaction Currency", "Currency of the transaction amounts.", "Transaction", "Code", "ISO 4217", "USD", "ISO 4217", "", ""),
       ("Reporting Currency Amount", "Gross amount converted to the firm's reporting currency.", "Transaction", "Amount", "", "USD 30,250.00", "Internal", "", "Y"),
       ("FX Rate Applied", "Exchange rate used to convert to reporting currency.", "Transaction", "Decimal", "", "1.0000", "Internal", "", ""),
     ]),
   ]),
   ("Sales Charges & Commission", "Front-end and deferred sales charges, waivers and dealer concessions attached to a transaction.", [
     ("Transaction Sales Charge", [
       ("Sales Charge Type", "Type of sales charge applied to the transaction.", "Transaction", "Code", "Sales Charge Type", "Front-End Load", "FINRA Rule 2341", "SEC Form N-1A", ""),
       ("Sales Charge Rate", "Percentage sales charge applied after breakpoints.", "Transaction", "Percentage", "", "3.50%", "FINRA Rule 2341", "", ""),
       ("Sales Charge Amount", "Amount of front-end or initial sales charge deducted.", "Transaction", "Amount", "", "USD 1,058.75", "FINRA Rule 2341", "", ""),
       ("CDSC Amount", "Contingent deferred sales charge withheld on a redemption.", "Transaction", "Amount", "", "USD 0.00", "SEC Form N-1A", "", ""),
       ("Breakpoint Applied Indicator", "Whether a breakpoint discount (incl. rights of accumulation or letter of intent) reduced the sales charge.", "Transaction", "Boolean", "", "Y", "FINRA Rule 2341", "", ""),
       ("Sales Charge Waiver Reason", "Reason a sales charge was waived.", "Transaction", "Code", "Sales Charge Waiver Reason", "Fee-Based Account", "SEC Form N-1A", "", ""),
       ("Dealer Concession Amount", "Portion of the sales charge re-allowed to the selling dealer.", "Transaction", "Amount", "", "USD 907.50", "FINRA Rule 2341", "", "", "Ongoing trail / 12b-1 / retrocession terms are owned by 05 Agreements"),
     ]),
   ]),
   ("Order Source & Intermediary As Delivered", "How the order reached the transfer agent and which intermediary codes the source reported.", [
     ("Order Source", [
       ("Order Entry Channel", "Route by which the order reached the transfer agent or fund.", "Transaction", "Code", "Order Entry Channel", "NSCC Fund/SERV", "DTCC Fund/SERV", "Calastone", "Y"),
       ("Systematic Plan Indicator", "Whether the transaction arose from a systematic investment / withdrawal plan or recurring contribution.", "Transaction", "Boolean", "", "N", "Internal", "", ""),
       ("Contribution Source Type", "Source of money for retirement-plan and SMA contributions.", "Transaction", "Code", "Contribution Source Type", "Employee Deferral", "DTCC DCC&S", "", ""),
       ("Order Message Type", "Standard message used to submit the order, where messaging is ISO 20022 or proprietary.", "Transaction", "Code", "External (ISO 20022 message catalogue)", "setr.010 Subscription Order", "ISO 20022", "", ""),
     ]),
     ("Intermediary As Delivered", [
       ("Dealer / Firm Number", "Dealer, firm or distributor code exactly as delivered (NSCC dealer number, TA dealer ID, platform distributor code).", "Transaction, Position", "Identifier", "External (Source system)", "0158", "DTCC Fund/SERV", "SS&C DST", "Y"),
       ("Branch Number", "Branch / office code as delivered by the source.", "Transaction, Position", "Identifier", "External (Source system)", "A27", "DTCC Fund/SERV", "", ""),
       ("Representative Number", "Financial advisor / rep code as delivered by the source (firm-specific rep ID, not necessarily CRD).", "Transaction, Position", "Identifier", "External (Source system)", "RJ4471", "DTCC Fund/SERV", "", "Y"),
       ("Representative Name As Delivered", "Rep name text delivered with the record, used for matching.", "Transaction, Position", "Text", "", "SMITH JANE A", "Internal", "", "", "PII"),
       ("Clearing Firm Number", "NSCC participant number of the clearing / settling firm, where different from the introducing dealer.", "Transaction", "Identifier", "External (Source system)", "0226", "DTCC Fund/SERV", "", ""),
       ("Intermediary Identifier Scheme", "Scheme of the delivered firm / office / rep codes.", "Transaction, Position", "Code", "Intermediary Identifier Type", "NSCC Dealer Number", "Internal", "", ""),
       ("Resolved Distributor Firm", "Distributor firm party after identity resolution.", "Transaction, Position", "Reference (Party)", "", "PTY-10442", "Internal", "", "Y"),
       ("Resolved Office / Branch", "Distributor office / branch party after identity resolution.", "Transaction, Position", "Reference (Party)", "", "PTY-58812", "Internal", "", ""),
       ("Resolved Advisor / Rep", "Advisor party after identity resolution.", "Transaction, Position", "Reference (Party)", "", "PTY-301177", "Internal", "", "Y", "PII (individual)"),
     ]),
   ]),
   ("Exchanges, Transfers & Conversions", "Links between the legs of exchanges, transfers and share-class conversions.", [
     ("Linked Transaction", [
       ("Linked Transaction ID", "Other leg of an exchange, transfer or conversion.", "Transaction", "Reference (Transaction)", "", "TXN-2026-000418274", "Internal", "ISO 20022", ""),
       ("Contra Share Class", "Share class on the other side of an exchange or conversion.", "Transaction", "Reference (Share Class)", "", "SHC-004519", "Internal", "", ""),
       ("Transfer Type", "Mechanism of an account or asset transfer.", "Transaction", "Code", "Transfer Type", "ACATS", "Internal", "", ""),
       ("Contra Firm", "Distributor firm on the other side of a transfer in/out (e.g. advisor moving firms).", "Transaction", "Reference (Party)", "", "PTY-10077", "Internal", "", ""),
       ("Conversion Reason", "Reason for a share-class conversion.", "Transaction", "Code", "Conversion Reason", "Advisory Account Conversion", "Internal", "", ""),
       ("Same-Owner Indicator", "Whether a transfer moved assets without change of beneficial owner (used to exclude from sales).", "Transaction", "Boolean", "", "Y", "Internal", "ICI", ""),
     ]),
   ]),
   ("ETF Primary Market & SMA", "Authorised-participant creations/redemptions and separately managed account flows.", [
     ("ETF Creation / Redemption", [
       ("Authorised Participant", "Authorised participant that placed the creation or redemption order.", "Transaction", "Reference (Party)", "", "PTY-00871", "Internal", "", ""),
       ("Creation Units", "Number of creation units created or redeemed.", "Transaction", "Integer", "", "4", "Internal", "", ""),
       ("Basket Type", "Settlement form of the creation / redemption basket.", "Transaction", "Code", "ETF Basket Type", "In-Kind", "Internal", "", ""),
     ]),
     ("SMA Flow", [
       ("Sponsor Program", "Sponsor wrap / SMA / UMA programme under which the account is managed.", "Transaction, Position", "Reference (Agreement)", "", "AGR-00312", "Internal", "", ""),
       ("Model Portfolio", "Model portfolio or strategy sleeve the flow relates to.", "Transaction, Position", "Reference (Model)", "", "MDL-0077", "Internal", "", ""),
     ]),
   ]),
   ("Status, Cancellations & Corrections", "Lifecycle of the transaction record and corrections after the fact.", [
     ("Transaction Status", [
       ("Transaction Status", "Processing status of the transaction.", "Transaction", "Code", "Transaction Status", "Settled", "ISO 20022", "", "Y"),
       ("Cancel / Correct Indicator", "Whether the record cancels, corrects or reverses an earlier transaction.", "Transaction", "Code", "Cancel Correct Indicator", "Cancel", "ISO 20022", "", "Y"),
       ("Original Transaction ID", "Transaction being cancelled, corrected or reversed.", "Transaction", "Reference (Transaction)", "", "TXN-2026-000401118", "Internal", "", ""),
       ("Correction Reason", "Reason for the cancellation or correction.", "Transaction", "Code", "Correction Reason", "NAV Error", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Positions & Holdings", "TX-POS",
  "Point-in-time holdings of share classes, ETFs, SMA models and plan investments by account, omnibus sub-account, custodian/broker, plan and sponsor, as reported by each source.",
  [
   ("Account Position", "Units and market value held in an account on a valuation date.", [
     ("Position", [
       ("Position ID", "Unique identifier for the position record (account x share class x valuation date x source).", "Position", "Identifier", "", "POS-20260930-0081123-004512", "Internal", "", "Y"),
       ("Account", "Account holding the position.", "Position", "Reference (Account)", "", "ACC-0081123", "Internal", "", "Y"),
       ("Share Class", "Share class held.", "Position", "Reference (Share Class)", "", "SHC-004512", "Internal", "", "Y"),
       ("Valuation Date", "Date at which the position is stated.", "Position", "Date", "ISO 8601", "2026-09-30", "ISO 20022", "", "Y"),
       ("Units Held", "Number of shares / units held.", "Position", "Decimal", "", "18,402.1190", "ISO 20022", "DTCC Omni/SERV", "Y"),
       ("Market Value", "Units held multiplied by the valuation price, in position currency.", "Position", "Amount", "", "USD 447,192.04", "ISO 20022", "", "Y"),
       ("Market Value (Reporting Currency)", "Market value converted to reporting currency.", "Position", "Amount", "", "USD 447,192.04", "Internal", "", "Y"),
       ("Position Basis", "Whether units reflect trade-date or settlement-date accounting.", "Position", "Code", "Position Basis", "Trade Date", "Internal", "", ""),
       ("Position Source", "Feed that reported the position.", "Position", "Reference (Feed)", "", "FEED-007", "Internal", "", ""),
     ]),
   ]),
   ("Omnibus & Look-Through", "Relationship between an omnibus account on the register and the underlying sub-account positions reported by the intermediary.", [
     ("Omnibus Look-Through", [
       ("Omnibus Parent Account", "Omnibus account on the TA register / fund register that aggregates the sub-account.", "Position, Transaction", "Reference (Account)", "", "ACC-0000415", "Internal", "DTCC Omni/SERV", "Y"),
       ("Sub-Account Identifier As Delivered", "Identifier of the underlying sub-account at the intermediary.", "Position, Transaction", "Identifier", "External (Source system)", "8842-11937", "SEC Rule 22c-2", "DTCC Omni/SERV", "", "May be pseudonymised; treat as PII if linkable"),
       ("Look-Through Source", "Source of the underlying detail.", "Position", "Code", "Look-Through Source", "Omni/SERV Position File", "DTCC Omni/SERV", "", ""),
       ("Look-Through Coverage %", "Share of the omnibus position explained by underlying records on the valuation date.", "Position", "Percentage", "", "97.4%", "Internal", "", ""),
       ("Omnibus Residual Amount", "Omnibus market value not explained by underlying records.", "Position", "Amount", "", "USD 1,204,500.00", "Internal", "", ""),
       ("Nominee / Platform Account Indicator", "Whether the parent account is a nominee or platform account (EU/UK) rather than a US omnibus.", "Position", "Boolean", "", "Y", "Clearstream Vestima", "Allfunds", ""),
     ]),
   ]),
   ("ETF Holdings by Custodian / Broker", "Exchange-traded holdings reported by settlement participant or broker, the basis for ETF attribution.", [
     ("ETF Holding", [
       ("Holding Custodian / Broker", "Broker-dealer or custodian holding the ETF shares for its clients.", "Position", "Reference (Party)", "", "PTY-10442", "Internal", "", "Y"),
       ("DTC Participant Number", "Depository participant number of the holder, as delivered.", "Position", "Identifier", "External (Source system)", "0164", "Internal", "", ""),
       ("ETF Shares Held", "Number of ETF shares held at the broker / custodian.", "Position", "Decimal", "", "1,284,000", "Internal", "Broadridge", "Y"),
       ("ETF Holdings Source", "Source of ETF holdings data.", "Position", "Code", "ETF Holdings Source", "Aggregator Broker Data", "Internal", "", ""),
       ("Office-Level Detail Indicator", "Whether the source breaks the holding down to office or advisor level.", "Position", "Boolean", "", "Y", "Broadridge", "", ""),
     ]),
   ]),
   ("Plan & Sponsor Assets", "Plan-level (DCIO) and SMA/UMA sponsor-reported assets where account-level detail is not held.", [
     ("Plan Position", [
       ("Retirement Plan", "Retirement plan whose participants hold the investment.", "Position", "Reference (Party)", "", "PTY-77120", "Internal", "DTCC DCC&S", "Y"),
       ("Recordkeeper", "Plan recordkeeper reporting the assets.", "Position", "Reference (Party)", "", "PTY-20018", "Internal", "", ""),
       ("Plan Participant Count", "Number of participants holding the investment.", "Position", "Integer", "", "1,412", "Internal", "", ""),
       ("Plan Advisor", "Plan-level advisor of record, as reported by the recordkeeper.", "Position", "Reference (Party)", "", "PTY-301990", "Internal", "", ""),
     ]),
     ("Sponsor-Reported Assets", [
       ("Sponsor", "SMA / UMA / model-delivery sponsor reporting the assets.", "Position", "Reference (Party)", "", "PTY-10442", "Internal", "", ""),
       ("Sponsor Reporting Basis", "Whether the sponsor reports account-level, advisor-level or programme-level totals.", "Position", "Code", "Feed Grain", "Advisor", "Internal", "", ""),
       ("Model-Delivery Assets Indicator", "Whether the assets are model-delivery (sponsor-implemented, non-discretionary for the firm) rather than firm-managed.", "Position", "Boolean", "", "Y", "Internal", "", "", "Typically reported as AUA, not AUM"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Flow & AUM Measures", "TX-MEA",
  "Definitions, calculation rules and value structures for sales, redemption, net flow, market movement, AUM and revenue measures, aligned to ICI and EFAMA industry definitions.",
  [
   ("Measure Definition", "Catalogue entry for each certified measure.", [
     ("Measure Definition", [
       ("Measure ID", "Unique identifier of the measure.", "Measure Definition", "Identifier", "", "MSR-NETFLOW", "Internal", "", "Y"),
       ("Measure Name", "Business name of the measure.", "Measure Definition", "Text", "", "Net Flows", "Internal", "", ""),
       ("Measure Category", "Family the measure belongs to.", "Measure Definition", "Code", "Measure Category", "Flow", "Internal", "", ""),
       ("Business Definition", "Plain-language definition of the measure.", "Measure Definition", "Text", "", "Gross sales less redemptions, including net exchanges, excluding reinvested distributions.", "ICI", "EFAMA", "Y"),
       ("Calculation Formula", "Formula in terms of transaction types and other measures.", "Measure Definition", "Text", "", "Gross Sales + Exchanges In - Redemptions - Exchanges Out", "Internal", "ICI", "Y"),
       ("Included Transaction Types", "Transaction types counted in the measure.", "Measure Definition", "Code (multi)", "Transaction Type", "Purchase; Exchange In; Transfer In (New Owner)", "Internal", "", "Y"),
       ("Excluded Transaction Types", "Transaction types explicitly excluded.", "Measure Definition", "Code (multi)", "Transaction Type", "Reinvestment; Share Class Conversion", "Internal", "", ""),
       ("Sign Convention", "How inflows and outflows are signed in the measure.", "Measure Definition", "Code", "Sign Convention", "Outflows Negative", "Internal", "", ""),
       ("Aggregation Behaviour", "How the measure may be summed across time and dimensions.", "Measure Definition", "Code", "Aggregation Behaviour", "Additive", "Internal", "", ""),
       ("Time Basis", "Date driving period assignment.", "Measure Definition", "Code", "Time Basis", "Trade Date", "Internal", "", "Y"),
       ("Industry Definition Alignment", "Degree of alignment to the external industry definition.", "Measure Definition", "Code", "Industry Definition Alignment", "Aligned with Adjustments", "ICI", "EFAMA", ""),
       ("Certified Indicator", "Whether the measure is certified for external / management reporting.", "Measure Definition", "Boolean", "", "Y", "Internal", "", ""),
     ]),
   ]),
   ("Flow Treatment Rules", "Firm-level policy choices that drive flow measures where industry practice varies.", [
     ("Flow Treatment Rule", [
       ("Reinvestment Treatment", "Whether reinvested dividends / capital gains count as sales or as market movement.", "Measure Definition", "Code", "Treatment Option", "Exclude from Sales (Market Movement)", "ICI", "Morningstar", "Y"),
       ("Exchange Treatment", "Whether intra-family exchanges are counted in gross sales / redemptions or only as net exchanges.", "Measure Definition", "Code", "Treatment Option", "Include in Gross", "ICI", "", ""),
       ("Transfer Treatment", "Whether transfers in/out without change of owner are counted as flows.", "Measure Definition", "Code", "Treatment Option", "Exclude (Same Owner)", "Internal", "", ""),
       ("Share Class Conversion Treatment", "Whether conversions between share classes of the same fund are counted as flows.", "Measure Definition", "Code", "Treatment Option", "Exclude at Product Level", "Internal", "", ""),
       ("ETF Flow Basis", "Basis for ETF flows: primary-market creations/redemptions or change in shares outstanding.", "Measure Definition", "Code", "ETF Flow Basis", "Shares Outstanding Change x NAV", "Morningstar", "ICI", ""),
       ("Model-Delivery Inclusion", "Whether model-delivery assets are included in AUM measures or reported separately as AUA.", "Measure Definition", "Code", "Treatment Option", "Exclude (Report Separately)", "Internal", "SEC Form ADV", ""),
       ("Money Market Inclusion", "Whether money market funds are included in long-term flow measures.", "Measure Definition", "Code", "Treatment Option", "Exclude (Report Separately)", "EFAMA", "ICI", ""),
     ]),
   ]),
   ("Measure Value Structure", "Grain and qualifiers of every stored measure value (fact).", [
     ("Measure Value", [
       ("Measure", "Measure the value belongs to.", "Measure Value", "Reference (Measure)", "", "MSR-GROSSSALES", "Internal", "", ""),
       ("Period Type", "Length of the period the value covers.", "Measure Value", "Code", "Period Type", "Month", "Internal", "", ""),
       ("Period Start Date", "First day of the period.", "Measure Value", "Date", "ISO 8601", "2026-09-01", "Internal", "", ""),
       ("Period End Date", "Last day of the period.", "Measure Value", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
       ("Dimension Grain", "Set of dimensions the value is aggregated to.", "Measure Value", "Code (multi)", "Attribution Dimension", "Share Class; Distributor Office; Territory", "Internal", "", ""),
       ("Measure Amount", "Value of the measure in measure currency.", "Measure Value", "Amount", "", "USD 4,812,330.00", "Internal", "", "Y"),
       ("Data Basis", "Whether the value is actual, estimated or allocated.", "Measure Value", "Code", "Data Basis", "Actual", "Internal", "Morningstar", "Y"),
       ("Snapshot", "Snapshot / version the value belongs to.", "Measure Value", "Reference (Snapshot)", "", "SNP-2026-09-M-FINAL", "Internal", "", ""),
       ("Attributed Share %", "Share of the value attributed to a named distributor (vs unattributed).", "Measure Value", "Percentage", "", "93.8%", "Internal", "", ""),
     ]),
   ]),
   ("Core Measure Catalogue", "Starter catalogue of the measures the domain certifies; each row is a Measure Definition instance with its rule summarised here.", [
     ("Flow Measures", [
       ("Gross Sales", "Sum of purchases, exchanges in, new-owner transfers in, SMA contributions and ETF creations (or estimated ETF inflows) in the period; excludes reinvestments.", "Measure Definition", "Amount", "", "USD 412m", "ICI", "EFAMA", "Y"),
       ("Redemptions", "Sum of redemptions, exchanges out, new-owner transfers out, SMA withdrawals and ETF redemptions in the period, shown as a positive amount.", "Measure Definition", "Amount", "", "USD 388m", "ICI", "EFAMA", "Y"),
       ("Net Exchanges", "Exchanges in less exchanges out within the fund family.", "Measure Definition", "Amount", "", "USD -3m", "ICI", "", ""),
       ("Net Flows (Net Sales)", "Gross sales less redemptions; equals ICI net new cash flow where exchanges are included and reinvestments excluded, and EFAMA net sales.", "Measure Definition", "Amount", "", "USD 24m", "ICI", "EFAMA", "Y"),
       ("Reinvested Distributions", "Dividends and capital gains reinvested in additional units.", "Measure Definition", "Amount", "", "USD 9m", "ICI", "Morningstar", ""),
     ]),
     ("Asset Measures", [
       ("Beginning AUM", "Market value of assets at the end of the prior period.", "Measure Definition", "Amount", "", "USD 18.20bn", "GIPS", "Internal", ""),
       ("Ending AUM", "Market value of assets at period end (sum of position market values, or reported fund TNA for unattributed totals).", "Measure Definition", "Amount", "", "USD 18.61bn", "GIPS", "Internal", "Y"),
       ("Market Movement", "Change in AUM not explained by net flows: Ending AUM - Beginning AUM - Net Flows; includes appreciation, income, reinvestments (if excluded from flows) and FX.", "Measure Definition", "Amount", "", "USD 386m", "Morningstar", "", "Y"),
       ("FX Effect", "Portion of market movement from translating non-reporting-currency assets.", "Measure Definition", "Amount", "", "USD -41m", "Internal", "", ""),
       ("Average AUM", "Average of daily (or month-end) AUM over the period; method stated in Calculation Formula.", "Measure Definition", "Amount", "", "USD 18.43bn", "Internal", "", "Y"),
       ("Organic Growth Rate", "Net flows for the period divided by Beginning AUM, annualised where stated.", "Measure Definition", "Percentage", "", "1.6% annualised", "Internal", "", "Y"),
       ("Estimated Management Fee Revenue", "Average AUM multiplied by the share class net management fee rate (from 01 Product) for the period, pro-rated by days.", "Measure Definition", "Amount", "", "USD 11.7m", "Internal", "", "", "Fee rates referenced from SHC-; not a GL figure"),
       ("Market Share", "Firm (or product) assets or net flows as a proportion of the industry or peer category at the same grain.", "Measure Definition", "Percentage", "", "2.4% of Morningstar US Large Growth", "Broadridge", "ISS Market Intelligence", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Attribution", "TX-ATT",
  "Assignment of transaction and position amounts to distributor hierarchy, territory, channel, plan, institution and credited salesperson, with method, confidence, overrides and unattributed items.",
  [
   ("Attribution Record", "Split of one transaction or position across attribution dimensions.", [
     ("Attribution Record", [
       ("Attribution Record ID", "Unique identifier of the attribution record.", "Attribution Record", "Identifier", "", "ATR-2026-09-00918822", "Internal", "", "Y"),
       ("Source Record Type", "Whether a transaction, position or measure value was attributed.", "Attribution Record", "Code", "Source Record Type", "Transaction", "Internal", "", ""),
       ("Source Transaction", "Transaction attributed.", "Attribution Record", "Reference (Transaction)", "", "TXN-2026-000418273", "Internal", "", ""),
       ("Source Position", "Position attributed.", "Attribution Record", "Reference (Position)", "", "POS-20260930-0081123-004512", "Internal", "", ""),
       ("Attributed Amount", "Amount assigned to this combination of dimensions.", "Attribution Record", "Amount", "", "USD 30,250.00", "Internal", "", "Y"),
       ("Attribution Share %", "Proportion of the source amount assigned by this record (100% unless split).", "Attribution Record", "Percentage", "", "100%", "Internal", "", ""),
       ("Attribution Effective Date", "Business date the attribution applies to (trade or valuation date).", "Attribution Record", "Date", "ISO 8601", "2026-09-18", "Internal", "", ""),
     ]),
   ]),
   ("Attribution Dimensions", "Who and where the amount is attributed to.", [
     ("Distributor Hierarchy", [
       ("Distributor Firm", "Distributor / home-office firm credited.", "Attribution Record", "Reference (Party)", "", "PTY-10442", "Internal", "Broadridge", "Y"),
       ("Distributor Office / Branch", "Branch or office credited.", "Attribution Record", "Reference (Party)", "", "PTY-58812", "Broadridge", "Internal", ""),
       ("Advisor Team", "Advisor team credited, where teams are modelled.", "Attribution Record", "Reference (Party)", "", "PTY-60031", "Internal", "", ""),
       ("Advisor / Rep", "Individual advisor credited.", "Attribution Record", "Reference (Party)", "", "PTY-301177", "Broadridge", "Internal", "Y", "PII (individual)"),
       ("Hierarchy Version Date", "Date of the distributor hierarchy (02) used, so restated hierarchies are traceable.", "Attribution Record", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
     ]),
     ("Market & Client Dimensions", [
       ("Territory", "Sales territory the amount falls into after applying 07 alignment rules.", "Attribution Record", "Reference (Territory)", "", "TER-US-NE-014", "Internal", "", "Y"),
       ("Distribution Channel", "Channel of the sale, derived from distributor classification and account type.", "Attribution Record", "Code", "Distribution Channel", "Independent Broker-Dealer", "Internal", "Broadridge", "Y"),
       ("Retirement Plan", "Retirement plan credited for DCIO flows.", "Attribution Record", "Reference (Party)", "", "PTY-77120", "Internal", "", ""),
       ("Institutional Client", "Institution credited for institutional / direct flows.", "Attribution Record", "Reference (Party)", "", "PTY-22019", "Internal", "", ""),
       ("Consultant", "Investment consultant influencing the institutional or DC mandate.", "Attribution Record", "Reference (Party)", "", "PTY-30002", "Internal", "", ""),
       ("Platform / Fund Distributor (EU/UK)", "Platform, fund supermarket or nominee through which EU/UK flows were placed.", "Attribution Record", "Reference (Party)", "", "PTY-41108", "Calastone", "Allfunds", ""),
       ("Investor Country", "Country of the end investor or of the distributor's client base, where known.", "Attribution Record", "Code", "ISO 3166-1 alpha-2", "DE", "MiFID II", "Calastone", ""),
     ]),
     ("Salesperson Credit", [
       ("Credited Salesperson", "Internal salesperson credited for the amount.", "Attribution Record", "Reference (Employee)", "", "EMP-00412", "Internal", "", "Y", "PII (employee)"),
       ("Crediting Rule Applied", "Crediting rule (07) used to credit the salesperson and determine split.", "Attribution Record", "Reference (Crediting Rule)", "", "CRR-0031", "Internal", "", "Y"),
       ("Credit Split %", "Share of the attributed amount credited to the salesperson.", "Attribution Record", "Percentage", "", "50%", "Internal", "", ""),
       ("Credit Role", "Role in which the salesperson is credited.", "Attribution Record", "Code", "Credit Role", "External Wholesaler", "Internal", "", ""),
     ]),
   ]),
   ("Method & Confidence", "How the attribution was derived and how reliable it is.", [
     ("Attribution Method", [
       ("Attribution Method", "Method used to derive the attribution.", "Attribution Record", "Code", "Attribution Method", "Rep-Matched", "Internal", "", "Y"),
       ("Attribution Source", "Feed whose data drove the attribution (may differ from the source of the transaction).", "Attribution Record", "Reference (Feed)", "", "FEED-011", "Internal", "", ""),
       ("Match Confidence Score", "Numeric confidence (0-100) of the identity resolution behind the attribution.", "Attribution Record", "Integer", "", "92", "Internal", "", ""),
       ("Match Confidence Band", "Banded confidence for reporting.", "Attribution Record", "Code", "Match Confidence Band", "High", "Internal", "", "Y"),
       ("Allocation Basis", "Basis used when amounts are allocated or estimated rather than directly observed.", "Attribution Record", "Code", "Allocation Basis", "Pro-Rata Prior Period Known Assets", "Internal", "", ""),
     ]),
   ]),
   ("Unattributed Assets", "Amounts that cannot be attributed below a given level, held in suspense.", [
     ("Unattributed Item", [
       ("Lowest Resolved Level", "Lowest hierarchy level to which the amount could be attributed.", "Unattributed Item", "Code", "Attribution Dimension", "Distributor Firm", "Internal", "", ""),
       ("Unattributed Reason", "Why the amount could not be fully attributed.", "Unattributed Item", "Code", "Unattributed Reason", "Unmatched Rep Code", "Internal", "", "Y"),
       ("Unattributed Amount", "Amount held in suspense.", "Unattributed Item", "Amount", "", "USD 2,450,000.00", "Internal", "", "Y"),
       ("Suspense Territory / Bucket", "Holding territory or bucket used for the amount until resolved.", "Unattributed Item", "Reference (Territory)", "", "TER-US-HOUSE", "Internal", "", ""),
       ("First Seen Date", "Date the item first became unattributed (for ageing).", "Unattributed Item", "Date", "ISO 8601", "2026-07-31", "Internal", "", ""),
       ("Resolution Status", "Work status of the item.", "Unattributed Item", "Code", "Resolution Status", "Under Investigation", "Internal", "", ""),
     ]),
   ]),
   ("Overrides", "Manual changes to engine-derived attribution.", [
     ("Attribution Override", [
       ("Override Scope", "What the override applies to (single record, account, rep code, office).", "Override", "Code", "Override Scope", "Rep Code", "Internal", "", ""),
       ("Override Reason", "Business reason for the override.", "Override", "Code", "Override Reason", "Rep Moved Firms - Book Transferred", "Internal", "", "Y"),
       ("Override Value", "Dimension and new value applied (e.g. Advisor -> PTY-301990).", "Override", "Text", "", "Advisor: PTY-301177 -> PTY-301990", "Internal", "", ""),
       ("Approved By", "Person approving the override (segregated from requester where it affects compensation).", "Override", "Reference (Employee)", "", "EMP-00031", "Internal", "", ""),
       ("Override Effective From", "First business date the override applies.", "Override", "Date", "ISO 8601", "2026-09-01", "Internal", "", ""),
       ("Override Effective To", "Last business date the override applies.", "Override", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Identity Resolution & Rep Matching", "TX-IDR",
  "Rules and results that map firm, office, rep, plan and account identifiers delivered by each source to the party (PTY-) and account (ACC-) masters owned by 02 Client & Customer.",
  [
   ("Source Identifier Crosswalk", "Feed-specific identifiers and the party or account they resolve to.", [
     ("Identifier Crosswalk", [
       ("Source Feed", "Feed in which the identifier occurs.", "Identifier Crosswalk", "Reference (Feed)", "", "FEED-003", "Internal", "", ""),
       ("Source Identifier Type", "Type of identifier delivered.", "Identifier Crosswalk", "Code", "Intermediary Identifier Type", "Firm Rep ID", "Internal", "", ""),
       ("Source Identifier Value", "Identifier exactly as delivered (composite keys concatenated in agreed order).", "Identifier Crosswalk", "Identifier", "", "0158|A27|RJ4471", "Internal", "", "Y"),
       ("Source Name Text", "Name delivered with the identifier.", "Identifier Crosswalk", "Text", "", "SMITH JANE A", "Internal", "", "", "PII"),
       ("Source Address / Postcode", "Address or postcode delivered with the identifier, used as a match key.", "Identifier Crosswalk", "Text", "", "02110", "Internal", "", "", "PII where for an individual"),
       ("Resolved Party", "Party the identifier resolves to.", "Identifier Crosswalk", "Reference (Party)", "", "PTY-301177", "Internal", "", "Y"),
       ("Resolved Account", "Account the identifier resolves to, for account-level keys.", "Identifier Crosswalk", "Reference (Account)", "", "ACC-0081123", "Internal", "", ""),
       ("Resolved CRD Number", "FINRA CRD of the matched advisor or firm, copied for audit (master in 02).", "Identifier Crosswalk", "Identifier", "External (FINRA CRD)", "4417720", "FINRA BrokerCheck / CRD", "", "", "Authoritative identifier held by 02"),
       ("Crosswalk Effective From", "First date the mapping applies.", "Identifier Crosswalk", "Date", "ISO 8601", "2024-03-01", "Internal", "", ""),
       ("Crosswalk Effective To", "Last date the mapping applies (e.g. rep left the firm).", "Identifier Crosswalk", "Date", "ISO 8601", "2026-08-31", "Internal", "", ""),
     ]),
   ]),
   ("Match Rules", "Configured rules used to resolve identifiers.", [
     ("Match Rule", [
       ("Match Rule ID", "Identifier of the rule.", "Match Rule", "Identifier", "", "MRL-012", "Internal", "", ""),
       ("Match Rule Type", "Deterministic, probabilistic or manual.", "Match Rule", "Code", "Match Rule Type", "Deterministic", "Internal", "", ""),
       ("Match Keys", "Fields compared by the rule.", "Match Rule", "Text", "", "CRD; Last Name; First Initial; ZIP5", "Internal", "", ""),
       ("Auto-Accept Threshold", "Score at or above which a match is accepted without review.", "Match Rule", "Integer", "", "90", "Internal", "", ""),
       ("Review Threshold", "Score at or above which a match is queued for steward review.", "Match Rule", "Integer", "", "70", "Internal", "", ""),
       ("Applicable Feeds", "Feeds the rule applies to.", "Match Rule", "Reference (Feed)", "", "FEED-003; FEED-011", "Internal", "", ""),
     ]),
   ]),
   ("Match Results", "Outcome and audit trail of each match.", [
     ("Match Result", [
       ("Match Status", "Current state of the match.", "Identifier Crosswalk", "Code", "Match Status", "Matched - Auto", "Internal", "", "Y"),
       ("Match Source", "Evidence used to make the match.", "Identifier Crosswalk", "Code", "Match Source", "CRD Exact", "Internal", "", ""),
       ("Match Rule Applied", "Rule that produced the match.", "Identifier Crosswalk", "Reference (Match Rule)", "", "MRL-012", "Internal", "", ""),
       ("Match Score", "Score (0-100) produced by the rule.", "Identifier Crosswalk", "Integer", "", "96", "Internal", "", ""),
       ("Match Date", "Date the match was made or last confirmed.", "Identifier Crosswalk", "Date", "ISO 8601", "2026-09-19", "Internal", "", ""),
       ("Rejection Reason", "Reason a suggested match was rejected.", "Identifier Crosswalk", "Text", "", "Same name, different CRD and state", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Data Sources & Feeds", "TX-FED",
  "Master of every data source and feed that delivers transactions, positions or attribution detail (FEED-), and metadata of each file / load received.",
  [
   ("Feed Master", "Descriptive and contractual reference data for each feed.", [
     ("Data Feed", [
       ("Feed ID", "Unique identifier of the feed.", "Feed", "Identifier", "", "FEED-003", "Internal", "", "Y"),
       ("Feed Name", "Business name of the feed.", "Feed", "Text", "", "NSCC Omni/SERV Activity - Firm X", "Internal", "", ""),
       ("Data Provider", "Organisation delivering the data (TA, intermediary, aggregator, platform, recordkeeper, sponsor).", "Feed", "Reference (Party)", "", "PTY-10442", "Internal", "", "Y"),
       ("Feed Type", "Category of source.", "Feed", "Code", "Feed Type", "Intermediary Sub-Accounting", "Internal", "", "Y"),
       ("Data Content", "Kinds of data the feed carries.", "Feed", "Code (multi)", "Data Content", "Transactions; Positions", "Internal", "", ""),
       ("Delivery Frequency", "How often the feed is delivered.", "Feed", "Code", "Frequency", "Daily", "Internal", "", ""),
       ("File Format", "Format of the delivered data.", "Feed", "Code", "File Format", "Fixed-Width (DTCC layout)", "FundsXML", "ISO 20022", ""),
       ("Transport Method", "Transport mechanism.", "Feed", "Code", "Transport Method", "SFTP", "Internal", "", ""),
       ("Message Standard", "Message or record standard used.", "Feed", "Code", "Message Standard", "DTCC Omni/SERV Activity Record", "DTCC Omni/SERV", "ISO 20022", ""),
       ("Feed Grain", "Lowest level of detail the feed provides.", "Feed", "Code", "Feed Grain", "Sub-Account", "Internal", "", "Y"),
       ("Coverage - Channels", "Distribution channels covered.", "Feed", "Code (multi)", "Distribution Channel", "Wirehouse; Independent Broker-Dealer", "Internal", "", ""),
       ("Coverage - Markets", "Countries / markets covered.", "Feed", "Code (multi)", "ISO 3166-1 alpha-2", "US", "Internal", "", ""),
       ("Latency", "Lag between business date and availability.", "Feed", "Text", "T+n", "T+1", "Internal", "", ""),
       ("Historical Depth", "Earliest business date available from the feed.", "Feed", "Date", "ISO 8601", "2019-01-01", "Internal", "", ""),
       ("Governing Agreement", "Data-licensing, networking or sub-TA agreement governing the feed (owned by 05).", "Feed", "Reference (Agreement)", "", "AGR-00177", "Internal", "", "Y"),
       ("Licence Use Restriction", "Permitted use of the data under the licence.", "Feed", "Code (multi)", "Licence Use Restriction", "Internal Sales Use Only", "Internal", "", ""),
       ("Feed Status", "Lifecycle status of the feed.", "Feed", "Code", "Feed Status", "Production", "Internal", "", ""),
       ("Source Precedence Rank", "Default rank of the feed in the source hierarchy for attribution.", "Feed", "Integer", "1-7", "3", "Internal", "", ""),
     ]),
   ]),
   ("File & Load Metadata", "Each file or batch received and its processing outcome.", [
     ("Load", [
       ("Load ID", "Identifier of the load.", "Load", "Identifier", "", "LOAD-20260919-FEED003-01", "Internal", "", "Y"),
       ("Feed", "Feed the load belongs to.", "Load", "Reference (Feed)", "", "FEED-003", "Internal", "", ""),
       ("File Name", "Name of the file received.", "Load", "Text", "", "OMNIACT_0158_20260918.dat", "Internal", "", ""),
       ("Business Date", "Business / as-of date the data relates to.", "Load", "Date", "ISO 8601", "2026-09-18", "Internal", "", "Y"),
       ("Record Count", "Records in the file.", "Load", "Integer", "", "48,221", "Internal", "", ""),
       ("Control Total", "Header / trailer control total (amount or units) delivered with the file.", "Load", "Decimal", "", "112,483,901.22", "Internal", "", ""),
       ("Rejected Record Count", "Records rejected on validation.", "Load", "Integer", "", "14", "Internal", "", ""),
       ("Load Status", "Processing status.", "Load", "Code", "Load Status", "Loaded with Warnings", "Internal", "", ""),
       ("Completeness Status", "Whether the expected file for the business date was received.", "Load", "Code", "Completeness Status", "Received On Time", "Internal", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Data Quality & Reconciliation", "TX-DQR",
  "Reconciliations between transfer agent, fund accounting, intermediary feeds and attributed totals; breaks and their resolution; data-quality rules and results.",
  [
   ("Reconciliation Definition", "What is reconciled to what, at which grain and tolerance.", [
     ("Reconciliation", [
       ("Reconciliation ID", "Identifier of the reconciliation.", "Reconciliation", "Identifier", "", "RCN-007", "Internal", "", ""),
       ("Reconciliation Name", "Business name.", "Reconciliation", "Text", "", "Omnibus units: TA register vs Omni/SERV position", "Internal", "", ""),
       ("Reconciliation Type", "Category of reconciliation.", "Reconciliation", "Code", "Reconciliation Type", "TA vs Intermediary Feed", "Internal", "", "Y"),
       ("Left Source", "First source compared.", "Reconciliation", "Reference (Feed)", "", "FEED-001", "Internal", "", ""),
       ("Right Source", "Second source compared.", "Reconciliation", "Reference (Feed)", "", "FEED-003", "Internal", "", ""),
       ("Comparison Grain", "Level at which values are compared.", "Reconciliation", "Code", "Feed Grain", "Account x Share Class", "Internal", "", ""),
       ("Compared Measure", "Value compared (units, market value, flows).", "Reconciliation", "Code", "Compared Measure", "Units", "Internal", "", ""),
       ("Absolute Tolerance", "Maximum absolute difference accepted.", "Reconciliation", "Decimal", "", "0.001 units", "Internal", "", "Y"),
       ("Relative Tolerance %", "Maximum relative difference accepted.", "Reconciliation", "Percentage", "", "0.05%", "Internal", "", ""),
       ("Reconciliation Frequency", "How often the reconciliation runs.", "Reconciliation", "Code", "Frequency", "Daily", "Internal", "", ""),
     ]),
     ("Reconciliation Run", [
       ("Run Business Date", "Business date reconciled.", "Reconciliation", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
       ("Matched %", "Proportion of items within tolerance.", "Reconciliation", "Percentage", "", "99.82%", "Internal", "", "Y"),
     ]),
   ]),
   ("Breaks", "Differences outside tolerance and their resolution.", [
     ("Break", [
       ("Break ID", "Identifier of the break.", "Break", "Identifier", "", "BRK-2026-09-30-00045", "Internal", "", ""),
       ("Break Type", "Nature of the difference.", "Break", "Code", "Break Type", "Units Difference", "Internal", "", "Y"),
       ("Difference Amount", "Value of the difference (reporting currency).", "Break", "Amount", "", "USD 184,220.10", "Internal", "", "Y"),
       ("Root Cause Category", "Root cause once investigated.", "Break", "Code", "Root Cause Category", "Timing (Late Trade)", "Internal", "", ""),
       ("Break Status", "Work status.", "Break", "Code", "Break Status", "Open", "Internal", "", "Y"),
       ("Break Age (Days)", "Days since the break first appeared.", "Break", "Integer", "Days", "3", "Internal", "", ""),
       ("Resolution Action", "Action taken to resolve.", "Break", "Text", "", "Intermediary resent position file; units agreed", "Internal", "", ""),
       ("Resolution Date", "Date the break was closed.", "Break", "Date", "ISO 8601", "2026-10-02", "Internal", "", ""),
     ]),
   ]),
   ("Data Quality Rules & Results", "Rules applied to transaction, position and attribution data, and their scores.", [
     ("DQ Rule", [
       ("DQ Rule ID", "Identifier of the rule.", "DQ Rule", "Identifier", "", "DQR-TX-031", "Internal", "", ""),
       ("DQ Rule Description", "What the rule checks.", "DQ Rule", "Text", "", "Rep Number populated on all Fund/SERV purchases", "Internal", "", ""),
       ("DQ Dimension", "Data-quality dimension tested.", "DQ Rule", "Code", "DQ Dimension", "Completeness", "DCAM (EDM Council)", "", ""),
       ("DQ Threshold %", "Minimum pass rate.", "DQ Rule", "Percentage", "", "98%", "Internal", "", ""),
       ("DQ Result %", "Pass rate on the latest run.", "DQ Rule", "Percentage", "", "96.4%", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Reporting Periods, Snapshots & Restatements", "TX-SNP",
  "Reporting calendar, locked as-of snapshots of attributed flows and assets, and governed restatements after lock.",
  [
   ("Reporting Calendar", "Periods and close dates for flow and AUM reporting.", [
     ("Reporting Period", [
       ("Reporting Period ID", "Identifier of the period.", "Snapshot", "Identifier", "", "2026-09", "Internal", "", ""),
       ("Period Type", "Type of period.", "Snapshot", "Code", "Period Type", "Month", "Internal", "", ""),
       ("Final Close Date", "Date results are locked as final.", "Snapshot", "Date", "ISO 8601", "2026-10-15", "Internal", "", "Y"),
       ("Compensation Cut-Off Date", "Date after which changes no longer affect the period's incentive payouts (agreed with 07).", "Snapshot", "Date", "ISO 8601", "2026-10-20", "Internal", "", ""),
     ]),
   ]),
   ("Snapshots", "Immutable versions of results at a point in time.", [
     ("Snapshot", [
       ("Snapshot ID", "Identifier of the snapshot.", "Snapshot", "Identifier", "", "SNP-2026-09-M-FINAL", "Internal", "", "Y"),
       ("Snapshot Type", "Purpose / stage of the snapshot.", "Snapshot", "Code", "Snapshot Type", "Final", "Internal", "", ""),
       ("As-Of Date", "Business date the snapshot represents.", "Snapshot", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
       ("Snapshot Status", "Lock status.", "Snapshot", "Code", "Snapshot Status", "Locked", "Internal", "", "Y"),
       ("Supersedes Snapshot", "Earlier snapshot this one replaces.", "Snapshot", "Reference (Snapshot)", "", "SNP-2026-09-M-PRELIM", "Internal", "", ""),
       ("Approved By", "Person who signed off the snapshot.", "Snapshot", "Reference (Employee)", "", "EMP-00031", "Internal", "", ""),
     ]),
   ]),
   ("Restatements", "Governed changes to locked results.", [
     ("Restatement", [
       ("Restatement ID", "Identifier of the restatement.", "Restatement", "Identifier", "", "RST-2026-004", "Internal", "", ""),
       ("Restatement Reason", "Why the locked period is restated.", "Restatement", "Code", "Restatement Reason", "Late Source Data", "Internal", "", ""),
       ("Affected Periods", "Periods restated.", "Restatement", "Text", "", "2026-07; 2026-08", "Internal", "", ""),
       ("Net Impact Amount", "Net change to the measure(s) restated.", "Restatement", "Amount", "", "USD 12.4m", "Internal", "", "Y"),
       ("Compensation Impact Indicator", "Whether the restatement changes incentive credits already paid (handed to 07).", "Restatement", "Boolean", "", "Y", "Internal", "", "Y"),
       ("Restatement Approved By", "Approver.", "Restatement", "Reference (Employee)", "", "EMP-00031", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Industry Flow Benchmarks", "TX-MKT",
  "Light-touch reference to industry flow and asset datasets used for market share and peer benchmarking. Candidate for a future 'Market & Competitive Intelligence' business domain.",
  [
   ("Industry Dataset", "External industry or peer flow datasets subscribed to.", [
     ("Industry Dataset", [
       ("Industry Dataset ID", "Identifier of the dataset.", "Industry Dataset", "Identifier", "", "IND-ICI-TRENDS", "Internal", "", ""),
       ("Dataset Publisher", "Organisation publishing the data.", "Industry Dataset", "Reference (Party)", "", "PTY-90001", "Internal", "", ""),
       ("Dataset Name", "Name of the dataset.", "Industry Dataset", "Text", "", "ICI Monthly Trends in Mutual Fund Investing", "ICI", "", ""),
       ("Flow Methodology", "Whether flows are reported actuals or estimated from assets and returns.", "Industry Dataset", "Code", "Data Basis", "Actual", "ICI", "Morningstar", ""),
       ("Category Scheme", "Classification used to group funds.", "Industry Dataset", "Code", "Category Scheme", "ICI Investment Classification", "ICI", "EFAMA", ""),
       ("Coverage Description", "Markets, vehicles and channels covered.", "Industry Dataset", "Text", "", "US long-term mutual funds and ETFs", "ISS Market Intelligence", "Broadridge", ""),
     ]),
   ]),
   ("Industry Flow Observation", "Structure of an industry flow / asset value used as a denominator.", [
     ("Industry Flow Observation", [
       ("Industry Category", "Peer category or classification value.", "Industry Dataset", "Text", "External (Vendor)", "Morningstar US Large Growth", "Morningstar", "", ""),
       ("Industry Net Flow", "Category net flows for the period.", "Industry Dataset", "Amount", "", "USD -4.1bn", "ICI", "EFAMA", ""),
       ("Industry Assets", "Category assets at period end.", "Industry Dataset", "Amount", "", "USD 1.92tn", "EFAMA", "ICI", ""),
       ("Firm Products Mapped", "Firm share classes mapped into the category, for market share.", "Industry Dataset", "Reference (Share Class)", "", "SHC-004512; SHC-004519", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Data Management Metadata", "TX-DMM",
  "Metadata applied to every record in the sales transactions and attribution domain.",
  [
   ("Record Metadata", "Ownership, lineage and versioning of records.", [
     ("Record Metadata", [
       ("Data Owner", "Business role accountable for the data element.", "All", "Text", "Firm-defined", "Head of Distribution Analytics", "DCAM (EDM Council)", "", ""),
       ("Data Steward", "Role responsible for day-to-day data quality.", "All", "Text", "Firm-defined", "Sales Data Steward", "DCAM (EDM Council)", "", ""),
       ("System of Record", "System holding the authoritative value.", "All", "Code", "Firm-defined", "Distribution Data Warehouse", "Internal", "", ""),
       ("Source Load", "Load that created or last changed the record (lineage).", "All", "Reference (Load)", "", "LOAD-20260919-FEED003-01", "Internal", "", ""),
       ("Record Effective From", "Business-effective start date of the record version.", "All", "Date", "ISO 8601", "2026-09-18", "Internal", "", ""),
       ("Record Effective To", "Business-effective end date of the record version.", "All", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Last Updated Timestamp", "System timestamp of the last change.", "All", "Timestamp", "ISO 8601", "2026-09-19T06:15:10Z", "Internal", "", ""),
       ("Data Quality Status", "Validation status of the record.", "All", "Code", "Data Quality Status", "Validated", "Internal", "", ""),
       ("Data Classification", "Information-security / privacy classification of the record.", "All", "Code", "Data Classification", "Confidential - Personal Data", "Internal", "GDPR", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Transaction Type": ("Internal (aligned to ICI flow components and ISO 20022 setr order types)", [
   ("Purchase","New money subscription (setr.010 Subscription Order)"),("Redemption","Sale / repurchase (setr.004 Redemption Order)"),
   ("Exchange In","Switch into a fund of the same family (setr.013 Switch Order, buy leg)"),("Exchange Out","Switch out of a fund of the same family (sell leg)"),
   ("Transfer In","Re-registration or ACATS transfer of units into an account"),("Transfer Out","Re-registration or ACATS transfer of units out of an account"),
   ("Reinvestment","Dividend / capital gain reinvested"),("Share Class Conversion","Exchange between classes of the same fund"),
   ("ETF Creation","Authorised-participant creation of ETF shares"),("ETF Redemption","Authorised-participant redemption of ETF shares"),
   ("SMA Contribution","Cash or securities added to an SMA / UMA account"),("SMA Withdrawal","Cash or securities withdrawn from an SMA / UMA account"),
   ("Plan Contribution","DC plan contribution invested"),("Plan Distribution","DC plan withdrawal / distribution"),
   ("Mandate Funding","Institutional mandate initial funding or top-up"),("Mandate Withdrawal","Institutional mandate partial / full termination"),
   ("Fund Merger In","Units received from a merged fund"),("Fund Merger Out","Units removed by fund merger"),("Adjustment","Non-trade adjustment")]),
 "Flow Direction": ("Internal", [("Inflow",""),("Outflow",""),("Neutral","No change to firm assets, e.g. conversion")]),
 "Look-Through Level": ("Internal (aligned to DTCC Networking / Omni/SERV)", [
   ("Direct Account","Account on the TA register held directly by the investor"),("Networked Account","Account on the TA register serviced via NSCC Networking"),
   ("Omnibus Aggregate","Omnibus or nominee account on the register, no underlying detail"),("Omnibus Sub-Account","Underlying sub-account reported by the intermediary"),
   ("Plan Level","Retirement plan totals from the recordkeeper"),("Sponsor Programme Level","SMA / UMA / model totals from the sponsor"),
   ("Aggregator Estimate","Distributor / office / rep level data from a third-party aggregator")]),
 "Networking Matrix Level": ("DTCC / NSCC Networking", [("Level 0 - Non-Networked","Or networked trust account with trust indicator"),("Level 3 - Firm Controlled","Firm holds customer contact, statements and tax reporting"),("Level 4 - Fund Controlled","Fund provides statements and tax reporting; firm places orders"),("Legacy Level 1 / 2","Retired levels; map on historical data")]),
 "Sales Charge Type": ("FINRA Rule 2341 / SEC Form N-1A / UK-EU", [("Front-End Load",""),("CDSC","Contingent deferred sales charge"),("Initial Charge (EU/UK)",""),("Exit / Redemption Fee",""),("None","")]),
 "Sales Charge Waiver Reason": ("SEC Form N-1A (Appendix A intermediary waivers)", [("Fee-Based Account",""),("Retirement Plan",""),("Rights of Reinstatement",""),("Employee / Affiliate",""),("Breakpoint (NAV Purchase)","Purchase at or above the NAV breakpoint"),("Intermediary-Specific Waiver","Per prospectus Appendix A")]),
 "Order Entry Channel": ("Internal", [("NSCC Fund/SERV",""),("NSCC DCC&S","Defined Contribution Clearance & Settlement"),("Calastone",""),("Clearstream Vestima",""),("Euroclear FundSettle",""),("Allfunds",""),("SWIFT ISO 20022 Direct",""),("TA Direct (Web / Phone / Mail)",""),("Recordkeeper File",""),("Sponsor File","SMA / UMA sponsor"),("NSCC CNS / ETF Portal","ETF creations and redemptions")]),
 "Contribution Source Type": ("Internal", [("Employee Deferral",""),("Employer Match",""),("Employer Non-Elective",""),("Rollover In",""),("Client Cash",""),("Securities In-Kind","")]),
 "Intermediary Identifier Type": ("Internal", [("NSCC Dealer Number",""),("NSCC Branch ID",""),("Firm Rep ID","Firm-specific rep code"),("FINRA CRD",""),("SEC / IARD Number",""),("FCA FRN",""),("LEI","ISO 17442"),("Aggregator Firm / Office / Rep ID","Broadridge, ISS MI or similar"),("Platform Distributor Code",""),("Recordkeeper Plan ID",""),("Sponsor Advisor ID","")]),
 "Transfer Type": ("Internal", [("ACATS","Automated Customer Account Transfer Service"),("Re-Registration",""),("Intra-Firm",""),("Estate / Transmission",""),("Platform Re-Registration (UK)","")]),
 "Conversion Reason": ("Internal", [("Advisory Account Conversion",""),("Age-Based / Automatic Conversion","e.g. C to A after holding period"),("Clean Share Class Migration",""),("Platform Share Class Change","")]),
 "ETF Basket Type": ("Internal", [("In-Kind",""),("Cash",""),("Custom Basket","SEC Rule 6c-11"),("Hybrid","")]),
 "Transaction Status": ("ISO 20022 (order status) / Internal", [("Received",""),("Pending",""),("Confirmed",""),("Settled",""),("Cancelled",""),("Reversed",""),("Rejected","")]),
 "Cancel Correct Indicator": ("ISO 20022", [("New",""),("Cancel",""),("Correct",""),("Reversal","")]),
 "Correction Reason": ("Internal", [("NAV Error",""),("Processing Error",""),("Client Request",""),("Duplicate",""),("Late Trading Reversal",""),("Wrong Share Class","")]),
 "Position Basis": ("Internal", [("Trade Date",""),("Settlement Date","")]),
 "Look-Through Source": ("Internal", [("Omni/SERV Position File",""),("Intermediary Proprietary File",""),("Aggregator",""),("Nominee Disclosure (EU/UK)",""),("Platform Data Service","")]),
 "ETF Holdings Source": ("Internal", [("Aggregator Broker Data",""),("Depository Participant Report",""),("Broker Direct Feed",""),("13F Filings","Quarterly institutional holdings"),("Estimate","")]),
 "Feed Grain": ("Internal", [("Fund Total",""),("Distributor Firm",""),("Office",""),("Advisor",""),("Account",""),("Sub-Account",""),("Plan",""),("Programme",""),("Account x Share Class","")]),
 "Measure Category": ("Internal", [("Flow",""),("Asset",""),("Revenue",""),("Ratio",""),("Market Share","")]),
 "Sign Convention": ("Internal", [("Outflows Negative",""),("All Positive","Direction carried by measure")]),
 "Aggregation Behaviour": ("Internal", [("Additive","Sum across time and dimensions"),("Semi-Additive","Sum across dimensions, not time (e.g. AUM)"),("Non-Additive","Recalculate, do not sum (rates, %)")]),
 "Time Basis": ("Internal", [("Trade Date",""),("Settlement Date",""),("As-Of Date",""),("Processing Date",""),("Valuation Date","")]),
 "Industry Definition Alignment": ("Internal", [("Fully Aligned",""),("Aligned with Adjustments",""),("Firm-Specific","")]),
 "Treatment Option": ("Internal", [("Include in Gross",""),("Net Only",""),("Exclude from Sales (Market Movement)",""),("Exclude (Same Owner)",""),("Exclude at Product Level","Count at share-class level only"),("Exclude (Report Separately)",""),("Include","")]),
 "ETF Flow Basis": ("Morningstar / ICI", [("Primary Market Creations / Redemptions",""),("Shares Outstanding Change x NAV",""),("Aggregator Broker Holdings Change","")]),
 "Period Type": ("Internal", [("Day",""),("Week",""),("Month",""),("Quarter",""),("Year",""),("Year-to-Date",""),("Rolling 12 Months","")]),
 "Data Basis": ("Internal", [("Actual",""),("Estimated",""),("Allocated",""),("Mixed","")]),
 "Attribution Dimension": ("Internal", [("Share Class",""),("Product",""),("Distributor Firm",""),("Distributor Office",""),("Advisor Team",""),("Advisor",""),("Territory",""),("Distribution Channel",""),("Retirement Plan",""),("Institutional Client",""),("Consultant",""),("Platform",""),("Salesperson",""),("Investor Country","")]),
 "Distribution Channel": ("Internal (to harmonise with 02 Client & Customer channel segmentation)", [("Wirehouse",""),("Regional Broker-Dealer",""),("Independent Broker-Dealer",""),("RIA",""),("Bank / Trust",""),("Private Bank",""),("Insurance",""),("DCIO / Retirement",""),("Institutional Direct",""),("Institutional Consultant-Led",""),("Fund Platform (EU/UK)",""),("IFA / Wealth Manager (EU/UK)",""),("Discretionary Fund Manager (UK)",""),("Direct to Investor",""),("Sub-Advisory","")]),
 "Source Record Type": ("Internal", [("Transaction",""),("Position",""),("Measure Value","")]),
 "Credit Role": ("Internal", [("External Wholesaler",""),("Internal Wholesaler",""),("National Accounts",""),("Relationship Manager",""),("Consultant Relations",""),("Retirement Specialist","")]),
 "Attribution Method": ("Internal", [("Direct","Rep codes on TA / networked account"),("Rep-Matched","Source rep code matched to party master"),("Look-Through","Omnibus sub-account detail"),("Aggregator","Third-party distribution data"),("Allocated","Known total split by an allocation basis"),("Estimated","Modelled where no detail exists"),("Manual Override","")]),
 "Match Confidence Band": ("Internal", [("High","Score >= 90 or deterministic key"),("Medium","70-89"),("Low","< 70"),("Not Applicable","")]),
 "Allocation Basis": ("Internal", [("Pro-Rata Prior Period Known Assets",""),("Pro-Rata Aggregator Share",""),("Equal Split",""),("Territory Default",""),("Coverage Assignment","Per 07 coverage model")]),
 "Unattributed Reason": ("Internal", [("Unmatched Rep Code",""),("Missing Rep Code",""),("Omnibus No Look-Through",""),("ETF Unknown Holder",""),("Late / Missing Feed",""),("Party Not in Master",""),("Territory Not Aligned","")]),
 "Resolution Status": ("Internal", [("New",""),("Under Investigation",""),("Awaiting Source",""),("Resolved",""),("Written Off to House","")]),
 "Override Scope": ("Internal", [("Single Record",""),("Account",""),("Rep Code",""),("Office",""),("Plan","")]),
 "Override Reason": ("Internal", [("Rep Moved Firms - Book Transferred",""),("Team Split Agreement",""),("Data Error at Source",""),("Coverage Exception",""),("Sponsor Correction","")]),
 "Match Rule Type": ("Internal", [("Deterministic",""),("Probabilistic",""),("Manual","")]),
 "Match Status": ("Internal", [("Matched - Auto",""),("Matched - Manual",""),("Suggested",""),("Unmatched",""),("Rejected",""),("Retired","")]),
 "Match Source": ("Internal", [("CRD Exact",""),("Source Key Exact","Previously confirmed crosswalk"),("Name + Postcode Fuzzy",""),("Aggregator Mapping",""),("Steward Research",""),("Distributor Confirmation","")]),
 "Feed Type": ("Internal", [("Transfer Agent",""),("Intermediary Sub-Accounting",""),("Distribution Data Aggregator",""),("ETF Holdings",""),("SMA / UMA Sponsor",""),("Recordkeeper (DCIO)",""),("Fund Platform / Order Network",""),("Fund Accounting",""),("Industry Statistics","")]),
 "Data Content": ("Internal", [("Transactions",""),("Positions",""),("Hierarchy / Reference",""),("Flows (Aggregated)",""),("Assets (Aggregated)","")]),
 "Frequency": ("Internal", [("Intraday",""),("Daily",""),("Weekly",""),("Monthly",""),("Quarterly",""),("Ad Hoc","")]),
 "File Format": ("Internal", [("Fixed-Width (DTCC layout)",""),("Delimited (CSV / Pipe)",""),("XML (ISO 20022)",""),("XML (FundsXML)",""),("JSON / API",""),("Excel","")]),
 "Transport Method": ("Internal", [("SFTP",""),("API",""),("SWIFT",""),("NSCC Network",""),("Vendor Portal",""),("Email","Discouraged")]),
 "Message Standard": ("Internal", [("DTCC Fund/SERV",""),("DTCC Networking",""),("DTCC Omni/SERV Activity Record",""),("DTCC Omni/SERV Position Record",""),("ISO 20022 setr",""),("ISO 20022 semt",""),("FundsXML",""),("Vendor Proprietary","")]),
 "Licence Use Restriction": ("Internal (terms in 05 Agreements)", [("Internal Sales Use Only",""),("Compensation Use Permitted",""),("No Redistribution",""),("Aggregated Use Only",""),("Retention Limit","")]),
 "Feed Status": ("Internal", [("Planned",""),("Testing",""),("Production",""),("Suspended",""),("Decommissioned","")]),
 "Load Status": ("Internal", [("Received",""),("Loaded",""),("Loaded with Warnings",""),("Rejected",""),("Superseded","")]),
 "Completeness Status": ("Internal", [("Received On Time",""),("Received Late",""),("Missing",""),("Partial","")]),
 "Reconciliation Type": ("Internal", [("TA vs Fund Accounting","Shares outstanding / capital stock"),("TA vs Intermediary Feed","Omnibus vs sub-accounts"),("Feed vs Feed",""),("Attributed vs Total AUM",""),("Flows vs Asset Roll-Forward","")]),
 "Compared Measure": ("Internal", [("Units",""),("Market Value",""),("Flows",""),("Record Count","")]),
 "Break Type": ("Internal", [("Units Difference",""),("Value Difference",""),("Missing in Left",""),("Missing in Right",""),("Attribute Mismatch","")]),
 "Root Cause Category": ("Internal", [("Timing (Late Trade)",""),("Pricing",""),("Source Error",""),("Mapping Error",""),("Corporate Action / Merger",""),("Unknown","")]),
 "Break Status": ("Internal", [("Open",""),("Investigating",""),("Resolved",""),("Accepted (Within Materiality)","")]),
 "DQ Dimension": ("DCAM / DAMA-DMBOK", [("Completeness",""),("Validity",""),("Accuracy",""),("Consistency",""),("Timeliness",""),("Uniqueness","")]),
 "Snapshot Type": ("Internal", [("Flash",""),("Preliminary",""),("Final",""),("Restated","")]),
 "Snapshot Status": ("Internal", [("Open",""),("Locked",""),("Superseded","")]),
 "Restatement Reason": ("Internal", [("Late Source Data",""),("Source Correction",""),("Attribution Rule Change",""),("Hierarchy Change",""),("Measure Definition Change",""),("Error","")]),
 "Category Scheme": ("Internal", [("ICI Investment Classification",""),("EFAMA EFC",""),("Morningstar Category",""),("Lipper Global Classification",""),("IA Sector","")]),
 "Data Quality Status": ("Internal", [("Validated",""),("Pending Validation",""),("Failed Validation",""),("Estimated","")]),
 "Data Classification": ("Internal", [("Public",""),("Internal",""),("Confidential",""),("Confidential - Personal Data","")]),
}

REL = [
 ("Data Feed","delivers","Load","1 : 0..n","One load per file / business date."),
 ("Load","creates","Transaction / Position","1 : 0..n","Lineage via Source Load."),
 ("Data Feed","is governed by","Agreement (05 Distribution Agreements: AGR-)","n : 0..1","Data-licensing, networking or sub-TA agreement."),
 ("Data Feed","is provided by","Party (02 Client & Customer: PTY-)","n : 1","TA, intermediary, aggregator, platform, recordkeeper or sponsor."),
 ("Transaction","is for","Share Class (01 Product: SHC-)","n : 1",""),
 ("Transaction","is booked to","Account (02 Client & Customer: ACC-)","n : 0..1","Aggregator and sponsor data may have no account."),
 ("Transaction","is linked to","Transaction","0..1 : 0..1","Exchange legs, transfers, conversions, cancel / correct."),
 ("Transaction","is placed by","Party - Authorised Participant (PTY-)","n : 0..1","ETF primary market only."),
 ("Position","is held in","Account (02 Client & Customer: ACC-)","n : 0..1",""),
 ("Position","is for","Share Class (01 Product: SHC-) / Model Portfolio (MDL-)","n : 1",""),
 ("Position (Omnibus Sub-Account)","rolls up to","Account - Omnibus (ACC-)","n : 1","Look-through coverage tracked."),
 ("Identifier Crosswalk","resolves to","Party (02 Client & Customer: PTY-)","n : 0..1","Firm, office, advisor, plan, institution."),
 ("Identifier Crosswalk","is produced by","Match Rule","n : 0..1",""),
 ("Transaction / Position","is attributed by","Attribution Record","1 : 1..n","Split where more than one advisor / team / salesperson."),
 ("Attribution Record","credits","Distributor Firm / Office / Advisor (PTY-)","n : 0..1 each",""),
 ("Attribution Record","falls in","Territory (07 Compensation & Territory: TER-)","n : 0..1","Via 07 alignment rules."),
 ("Attribution Record","credits salesperson","Employee (03 Sales: EMP-)","n : 0..n",""),
 ("Attribution Record","applies","Crediting Rule (07 Compensation & Territory: CRR-)","n : 0..1","07 owns rule logic; 06 records rule applied."),
 ("Attribution Record","may be changed by","Attribution Override","n : 0..n",""),
 ("Transaction / Position","may create","Unattributed Item","1 : 0..1",""),
 ("Measure Definition","is valued as","Measure Value","1 : 0..n",""),
 ("Measure Value","belongs to","Snapshot","n : 1",""),
 ("Snapshot","may be superseded via","Restatement","1 : 0..n","Restatements with comp impact feed 07 adjustments."),
 ("Reconciliation","compares","Data Feed (left / right)","n : 2",""),
 ("Reconciliation","raises","Break","1 : 0..n",""),
 ("Measure Definition (Estimated Revenue)","uses fee rate of","Share Class (01 Product: SHC-)","n : n","Net management fee rate."),
 ("Industry Flow Observation","maps","Share Class (01 Product: SHC-)","n : n","For market share."),
 ("Attribution Record (Flows)","feeds","Goal / Incentive Comp Plan (07: GOL-, ICP-)","n : n","Attributed flows are the input to goal tracking and payouts."),
]

SRC = [
 ("DTCC / NSCC Fund/SERV","DTCC","https://www.dtcc.com/wealth-management-services/mutual-fund-services/fund-serv","Member service; record layouts behind login","Automated order processing and settlement for mutual funds; dealer, branch and rep fields on orders","Transaction core, intermediary as delivered, order entry channel",["DTCC Fund/SERV"]),
 ("DTCC / NSCC Networking (matrix levels)","DTCC","https://www.dtcc.com/wealth-management-services/mutual-fund-services/networking","Member service; layouts behind login","Account-level data exchange between funds and firms; matrix levels 0, 3, 4","Look-Through Level, Networking Matrix Level",["DTCC Networking"]),
 ("DTCC Omni/SERV","DTCC","https://dtcclearning.com/products-and-services/mutual-fund-services/omni-serv.html","Member service; layouts behind login","Omnibus Activity file and Omnibus Position file from sub-accounting firms","Omnibus look-through, sub-account positions and activity",["DTCC Omni/SERV"]),
 ("DTCC Defined Contribution Clearance & Settlement (DCC&S)","DTCC","https://www.dtcc.com/wealth-management-services/mutual-fund-services/defined-contribution-clearance-and-settlement","Member service","Retirement-plan trade processing for funds, CITs and stable value","Plan positions, contribution source",["DTCC DCC&S"]),
 ("ISO 20022 investment funds messages (setr order / confirmation, semt.002 statement of holdings, semt.006 statement of fund transactions)","ISO / SWIFT (RA)","https://www.iso20022.org/iso-20022-message-definitions","Free","Order, confirmation, cancellation, status and holdings message definitions","Transaction types, dates, amounts, status, cancel / correct, holdings",["ISO 20022"]),
 ("FundsXML","FundsXML Initiative","https://www.fundsxml.org","Free open standard","XML standard for fund data incl. holdings","File Format / Message Standard",["FundsXML"]),
 ("ICI Monthly Trends in Mutual Fund Investing and Fact Book definitions","Investment Company Institute","https://www.ici.org/monthly-trends-in-mutual-fund-investing","Free (summary); member data","New sales, exchange sales, redemptions, exchange redemptions, net new cash flow; reinvested dividends excluded from new sales","Flow measure definitions and alignment",["ICI"]),
 ("EFAMA statistical releases (monthly fact sheet, quarterly statistical release)","EFAMA","https://www.efama.org/data-research","Free","European UCITS / AIF net sales and net assets by domicile","Flow measure alignment (EU), industry flows",["EFAMA"]),
 ("Morningstar Estimated Net Cash Flow methodology","Morningstar","https://www.morningstar.com/content/dam/marketing/shared/research/methodology/765555_Estimated_Net_Cash_Flow_Methodology.pdf","Free methodology; data licensed","Estimated flows from TNA change and returns; reinvestment treatment; ETF shares-outstanding basis","Market Movement, ETF Flow Basis, Data Basis",["Morningstar"]),
 ("Broadridge Distribution Insight / Sales & Asset Reporting","Broadridge","https://www.broadridge.com/financial-services/asset-management/mutual-funds-etf/access-unique-distribution-insights/sales-and-asset-reporting","Licensed","Intermediary sales and assets by firm, office and advisor; ETF and mutual fund market share by channel and territory","Attribution dimensions, aggregator feeds, ETF holdings, market share",["Broadridge"]),
 ("ISS Market Intelligence Simfund","ISS Market Intelligence","https://www.issmarketintelligence.com","Licensed","Industry fund, ETF and CIT flows and assets","Industry flow benchmarks",["ISS Market Intelligence"]),
 ("SS&C DST TA2000 / FAN Mail / sub-accounting","SS&C Technologies","https://www.ssctech.com/solutions/subaccounting","Licensed","TA recordkeeping, as-of trades, intermediary data distribution","Source transaction codes, as-of dates, dealer IDs",["SS&C DST"]),
 ("Calastone (order routing and Data Services)","Calastone","https://www.calastone.com","Commercial network","Fund order routing / settlement; bottom-up distribution data","EU/UK order channel and platform attribution",["Calastone"]),
 ("Clearstream Vestima","Clearstream (Deutsche Börse)","https://clearstream.com/clearstream-en/funds-services/fund-centre","Commercial service","Cross-border fund order routing, settlement and custody","EU order channel, nominee holdings",["Clearstream Vestima"]),
 ("Allfunds","Allfunds Group","https://allfunds.com/allfunds-data-analytics","Commercial service","Fund distribution platform and data analytics","EU platform holdings and flows",["Allfunds"]),
 ("SEC Rule 22c-2 (shareholder information agreements)","US SEC","https://www.sec.gov/rules/final/ic-27255.htm","Regulation","Omnibus intermediaries to provide underlying shareholder ID, transaction type, amount and date on request","Omnibus sub-account identifiers",["SEC Rule 22c-2"]),
 ("FINRA Rule 2341 (Investment Company Securities)","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2341","Regulation","Sales charge limits, breakpoints and dealer concessions","Sales charge attributes",["FINRA Rule 2341"]),
 ("SEC Form N-1A (fee table, sales charge waivers)","US SEC","https://www.sec.gov/files/formn-1a.pdf","Regulation","Sales charge and intermediary-specific waiver disclosure","Sales charge types and waivers",["SEC Form N-1A"]),
 ("FINRA BrokerCheck / CRD","FINRA","https://brokercheck.finra.org","Public lookup","Registered representative and firm identifiers","Rep matching (CRD)",["FINRA BrokerCheck / CRD"]),
 ("MiFID II (distribution chain / target market feedback)","European Union / ESMA","https://www.esma.europa.eu","Regulation","Manufacturer knowledge of distribution, investor country","EU attribution dimensions",["MiFID II"]),
 ("GIPS Standards (firm / composite assets)","CFA Institute","https://www.gipsstandards.org","Free","Definitions of assets and valuation","AUM measure framing",["GIPS"]),
 ("DCAM","EDM Council","https://edmcouncil.org","Member framework","Data ownership, stewardship, data-quality dimensions","Data management metadata, DQ dimensions",["DCAM*"]),
]

