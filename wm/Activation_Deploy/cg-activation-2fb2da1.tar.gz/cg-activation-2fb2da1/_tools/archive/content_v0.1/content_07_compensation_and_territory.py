"""Business domain 07 - Compensation & Territory. Content module for taxonomy_builder.py."""

META = {
 "title": "Compensation & Territory Data Taxonomy",
 "subtitle": "Business domain 07 - Compensation & Territory | Asset manager (wholesale distributor) | Scope: US + EU/UK | Draft v0.1 | 2026-10-01",
 "output": "07_Compensation_and_Territory/Compensation_and_Territory_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the sales territory, coverage, goal, crediting and incentive compensation data of an asset manager that distributes wholesale. It draws on CRM territory models (Salesforce Enterprise Territory Management), incentive compensation management (ICM) platforms (Xactly, Salesforce Spiff, Varicent), official geography standards (ISO 3166, US Census/OMB, Eurostat NUTS, ONS) and the rules on sales remuneration (SEC Reg BI, FINRA 2341/3220, MiFID II and ESMA remuneration guidelines, UK FCA SYSC 19F/19E/19B). Use it as a starting point for a territory and comp data model, a data catalogue or a business glossary."),
  ("Scope", "In scope: territory models, territories and their hierarchy; geographic, channel, segment and product scope; territory potential; alignment rules, exceptions and realignment events; coverage models, salesperson-to-territory and party-to-salesperson coverage assignments; coverage tiering and call standards; goals and quotas, cascades, adjustments and attainment; crediting rules, splits, eligibility, transition credit and credit allocations; incentive compensation plans, components, rate tables and participant assignments; payout calculation, draws, disputes, statements, payroll hand-off and finance accruals; comp governance, remuneration conflict assessments, controls and audit trail. Out of scope (referenced only): sales personnel, sales org reporting lines, activities and opportunities (03_Sales, EMP-/ACT-/OPP-); the party master, firm/branch/advisor hierarchy, accounts and party segmentation (02_Client_and_Customer, PTY-/ACC-); products and share classes (01_Product, PRD-/SHC-); agreements and partner programmes (05_Distribution_Agreements_and_Partners, AGR-/PGM-); transactions, positions, flow/AUM measures and their attribution to territory (06_Sales_Transactions_and_AUM_Attribution, TXN-/POS-/FEED-); non-cash compensation, gifts and entertainment rules, licences and registrations (08_Distribution_Compliance, GNE-/LIC-/REV-); payroll, HR job architecture and base salary (HR systems)."),
  ("Structure", "Four levels: Domain > Subdomain > Concept > Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Territory Model (versioned plan year) -> Territory (division > region > territory > sub-territory) defined by geography, channel, segment and named firms -> Alignment Rules place parties (firm, branch, advisor, plan) into territories -> Coverage Assignments put salespeople (EMP-) into territory roles and onto parties -> Goals (GOL-) are set per territory/salesperson -> Crediting Rules (CRR-) turn TX-attributed flows and AUM into credit allocations for salespeople -> Incentive Comp Plans (ICP-) turn credits and attainment into earnings -> Statements, payroll payments and finance accruals."),
  ("Design principles", "1) Territory is a market partition, not an org chart: reporting lines stay in 03 Sales; territory hierarchy lives here. 2) Effective-date everything: territories, rules, assignments, splits, plans and tiers all carry Effective From / To so any historical credit or payout can be re-derived. 3) Separate attribution from crediting: 06 TX attributes flows to firm/advisor/territory; 07 applies crediting rules to pay people. 4) Rules are data: precedence, criteria and exceptions are stored, not hard-coded. 5) Reference, do not copy: parties, people, products, transactions and licences are held by ID. 6) Comp data is confidential personal data: restrict access and flag PII. 7) Flag Critical Data Elements (CDE) for governance and data-quality focus."),
  ("Applies To", "Shows the level at which each attribute is held: Territory Model, Territory, Geography, Alignment Rule, Coverage Assignment, Coverage Team, Goal, Crediting Rule, Credit Allocation, Plan, Plan Component, Participant, Period, Statement, Payment, Accrual, Control or All."),
  ("CDE", "Y = proposed Critical Data Element: needed to place a party in a territory, identify who covers it, set a goal, credit a sale, calculate or pay incentive compensation, or evidence a control. Confirm with Sales Operations, Sales Compensation, Finance and Compliance data owners."),
  ("Primary / Secondary Reference", "Standard or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition (most comp and crediting concepts are firm-specific). Vendor labels (Salesforce ETM, Xactly, Spiff) mean the concept is aligned to that platform's object or feature and should be mapped to the exact field during implementation."),
  ("Tabs", "Hierarchy: domains, subdomains and concepts with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: concept-level cardinalities for the logical model, including references to other business domains | Sources: standards, regulations and vendor models used, with links."),
  ("Suggested next steps", "1) Validate territory types, coverage roles and crediting rules with Sales Operations and the Sales Comp team for US and EU/UK. 2) Agree the attribution (06) vs crediting (07) boundary and the hand-off measure definitions. 3) Map attributes to source systems (CRM territory model, ICM platform, payroll, GL, market-sizing vendors). 4) Have Compliance review the remuneration conflict assessment fields against Reg BI, FINRA 2341 and MiFID/SYSC 19F. 5) Register the local record-ID prefixes used in examples here (TMD-, ALR-, RLN-, CVA-, CTM-, GPL-, CRA-, ERN-, CP-, STM-, DSP-, CTL-, RUN-) in the programme conventions or replace them with system keys. 6) Turn the Relationships tab into a logical data model."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Territory Structure", "CT-TER",
  "The versioned territory model and the territories, types and hierarchy that partition the market for sales coverage, goals and compensation.",
  [
   ("Territory Model & Version", "A complete, versioned set of territories for a market and plan year; only one model per market is active at a time.", [
     ("Territory Model", [
       ("Territory Model ID", "Unique identifier of the territory model (one complete version of the territory design).", "Territory Model", "Identifier", "", "TMD-US-FY2027", "Salesforce ETM", "", "Y"),
       ("Territory Model Name", "Business name of the territory model.", "Territory Model", "Text", "", "US Wholesale Territories FY2027", "Salesforce ETM", "", ""),
       ("Market Scope", "Market or legal sales region the model covers.", "Territory Model", "Code", "Market Scope", "US", "Internal", "", "Y"),
       ("Territory Model State", "Lifecycle state of the model; only one model per market may be Active.", "Territory Model", "Code", "Territory Model State", "Planning", "Salesforce ETM", "", "Y"),
       ("Model Effective From", "Date the model becomes the active basis for coverage, goals and crediting.", "Territory Model", "Date", "ISO 8601", "2027-01-01", "Internal", "Salesforce ETM", ""),
       ("Predecessor Territory Model", "Model this version replaces; used to trace realignments year over year.", "Territory Model", "Reference (Territory Model)", "", "TMD-US-FY2026", "Internal", "", ""),
     ]),
   ]),
   ("Territory Master", "The territory as a named, effective-dated unit of market coverage, and the types that classify territories.", [
     ("Territory", [
       ("Territory ID", "Unique identifier of the territory; stable across model versions where the territory is unchanged.", "Territory", "Identifier", "", "TER-US-0142", "Internal", "Salesforce ETM", "Y"),
       ("Territory Name", "Business name of the territory.", "Territory", "Text", "", "NY Metro North (Westchester / Fairfield)", "Salesforce ETM", "", "Y"),
       ("Territory Type", "Basis on which the territory is defined (geographic, national account, channel, segment, hybrid, overlay).", "Territory", "Code", "Territory Type", "Geographic", "Salesforce ETM", "Internal", "Y"),
       ("Territory Level", "Level of the territory in the hierarchy.", "Territory", "Code", "Territory Level", "Territory", "Internal", "", ""),
       ("Territory Model", "Territory model version the territory belongs to.", "Territory", "Reference (Territory Model)", "", "TMD-US-FY2027", "Salesforce ETM", "", ""),
       ("Territory Status", "Lifecycle status of the territory.", "Territory", "Code", "Territory Status", "Active", "Internal", "", ""),
       ("Territory Effective From", "Date the territory became effective.", "Territory", "Date", "ISO 8601", "2027-01-01", "Internal", "", ""),
       ("Territory Effective To", "Date the territory was retired, merged or split.", "Territory", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Primary Coverage Model", "Default coverage model applied to the territory.", "Territory", "Code", "Coverage Model", "External-Internal Pair", "Internal", "", ""),
     ]),
     ("Territory Type Definition", [
       ("Territory Type Priority", "Priority used to choose between territories of different types when a party is aligned to more than one (lower = higher priority).", "Territory Type", "Integer", "", "1", "Salesforce ETM", "", ""),
       ("Territory Type Description", "Narrative description of when this type is used.", "Territory Type", "Text", "", "Firm-based territory covering a wirehouse or large IBD home office and all its branches nationally", "Salesforce ETM", "", ""),
     ]),
   ]),
   ("Territory Hierarchy", "Parent-child structure of division, region, territory and sub-territory, used for roll-up of goals, credits and potential.", [
     ("Territory Hierarchy Node", [
       ("Parent Territory", "Territory one level up in the hierarchy; null for a division (top node).", "Territory", "Reference (Territory)", "", "TER-US-0010", "Salesforce ETM", "", "Y"),
       ("Hierarchy Type", "Which hierarchy the parent-child link belongs to, where more than one exists.", "Territory", "Code", "Territory Hierarchy Type", "Primary Wholesale", "Internal", "", ""),
       ("Hierarchy Effective From", "Date the parent-child link became effective.", "Territory", "Date", "ISO 8601", "2027-01-01", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Territory Geography & Market Scope", "CT-GEO",
  "The geographic, channel, segment and product definition of each territory, and the market-potential metrics used to size and balance territories.",
  [
   ("Geographic Definition", "The geographic units (country, subdivision, county, CBSA, postal code, NUTS region) that make up a geographic territory.", [
     ("Territory Geographic Unit", [
       ("Geographic Unit Type", "Type of geographic unit used to define the territory.", "Geography", "Code", "Geographic Unit Type", "ZIP Code", "Internal", "US Census (ZCTA)", "Y"),
       ("Geographic Unit Code", "Code of the geographic unit in the scheme named by its type.", "Geography", "Text", "", "10601", "Internal", "", "Y"),
       ("Country Code", "Country of the geographic unit.", "Geography", "Code", "ISO 3166-1 alpha-2", "US", "ISO 3166-1", "", ""),
       ("Country Subdivision Code", "State, province, region or nation within the country.", "Geography", "Code", "ISO 3166-2", "US-NY", "ISO 3166-2", "", ""),
       ("County FIPS Code", "Five-digit state + county FIPS code (US).", "Geography", "Code", "External (US Census FIPS)", "36119", "US Census (FIPS)", "", ""),
       ("CBSA Code", "Core Based Statistical Area (metropolitan / micropolitan) code (US).", "Geography", "Code", "External (OMB CBSA)", "35620", "OMB CBSA", "US Census (ZCTA)", "", "35620 = New York-Newark-Jersey City, NY-NJ"),
       ("NUTS Code", "NUTS region code (EU) used for sub-national territories in Europe.", "Geography", "Code", "External (Eurostat NUTS)", "DE212", "Eurostat NUTS", "", ""),
       ("UK Postcode District", "Outward part of a UK postcode (area + district) used for UK regional territories.", "Geography", "Text", "External (ONS NSPL)", "EC2V", "ONS NSPL", "", ""),
       ("Inclusion Type", "Whether the unit is included in or carved out of the territory.", "Geography", "Code", "Inclusion Type", "Include", "Internal", "", ""),
       ("Shared Geography Indicator", "Whether the unit is split across territories, so alignment must use firm, branch or named-account rules to resolve it.", "Geography", "Boolean", "", "N", "Internal", "", ""),
       ("Geography Reference Version", "Version of the external geography used (e.g. OMB bulletin, NUTS edition, NSPL release).", "Geography", "Text", "", "OMB Bulletin 23-01", "Internal", "", ""),
     ]),
     ("Sales Cluster", [
       ("Cluster Code", "Code of a multi-country sales cluster used by EU/UK distribution.", "Territory", "Code", "Firm-defined", "DACH", "Internal", "", ""),
       ("Cluster Member Countries", "Countries in the cluster.", "Territory", "Code (multi)", "ISO 3166-1 alpha-2", "DE; AT; CH; LI", "ISO 3166-1", "", ""),
     ]),
   ]),
   ("Channel, Segment & Product Scope", "The channels, client segments, named firms and products a territory is responsible for.", [
     ("Territory Scope", [
       ("Sales Channel in Scope", "Distribution channel(s) the territory covers.", "Territory", "Code (multi)", "Sales Channel", "Independent Broker-Dealer; RIA", "Internal", "", "Y"),
       ("Named Firm in Scope", "Distributor firm(s) explicitly covered by an account-based / national account territory.", "Territory", "Reference (Party)", "", "PTY-10045", "Internal", "", "Y"),
       ("Product Scope", "Product family the territory or overlay is responsible for selling.", "Territory", "Code", "Product Scope", "All Products", "Internal", "", ""),
     ]),
   ]),
   ("Territory Potential & Market Sizing", "Market-potential and workload metrics used to design, balance and set goals for territories.", [
     ("Territory Potential Metric", [
       ("Potential Metric Type", "Metric used to size the territory.", "Territory", "Code", "Territory Potential Metric", "Addressable Industry AUM", "Internal", "", "Y"),
       ("Potential Metric Value", "Value of the metric for the territory.", "Territory", "Decimal", "", "48200000000", "Internal", "", "Y"),
       ("Potential As-of Date", "Date the metric value is measured as of.", "Territory", "Date", "ISO 8601", "2026-06-30", "Internal", "", ""),
       ("Market Sizing Source", "Data source of the metric.", "Territory", "Code", "Market Sizing Source", "Intermediary Sales Data Vendor", "Internal", "", ""),
       ("Source Data Feed", "Data feed (owned by 06 TX) that supplied the metric.", "Territory", "Reference (Data Feed)", "", "FEED-0031", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Alignment Rules", "CT-ALN",
  "The rules, precedence, exceptions and resulting alignments that place parties (firms, offices, branches, advisors, plans) into territories, and the realignment events that change them.",
  [
   ("Alignment Rule Definition", "Rule-based assignment of parties to territories by geography, firm, channel or named account.", [
     ("Alignment Rule", [
       ("Alignment Rule ID", "Unique identifier of the alignment rule.", "Alignment Rule", "Identifier", "", "ALR-0381", "Salesforce ETM", "", "Y"),
       ("Alignment Rule Type", "Basis of the rule.", "Alignment Rule", "Code", "Alignment Rule Type", "Geo-Based", "Internal", "", "Y"),
       ("Target Territory", "Territory to which matching parties are aligned.", "Alignment Rule", "Reference (Territory)", "", "TER-US-0142", "Salesforce ETM", "", "Y"),
       ("Aligned Party Level", "Level of the party hierarchy the rule evaluates and assigns.", "Alignment Rule", "Code", "Aligned Party Level", "Branch", "Internal", "", ""),
       ("Rule Precedence", "Order of evaluation; when a party matches several rules, the lowest number wins unless both are allowed (overlay).", "Alignment Rule", "Integer", "", "20", "Internal", "", ""),
       ("Boolean Filter", "Logic combining the rule criteria.", "Alignment Rule", "Text", "", "(1 AND 2) OR 3", "Salesforce ETM", "", ""),
       ("Inherit to Child Parties Indicator", "Whether the alignment cascades down the party hierarchy (firm > branch > advisor) unless a lower-level rule overrides.", "Alignment Rule", "Boolean", "", "Y", "Internal", "", ""),
       ("Rule Effective From", "Date the rule became effective.", "Alignment Rule", "Date", "ISO 8601", "2027-01-01", "Internal", "", ""),
     ]),
     ("Alignment Rule Criterion", [
       ("Criterion Field", "Party attribute evaluated (owned by 02 CC).", "Alignment Rule", "Text", "", "Branch.PostalCode", "Salesforce ETM", "", ""),
       ("Criterion Operator", "Comparison operator.", "Alignment Rule", "Code", "Rule Operator", "In List", "Salesforce ETM", "", ""),
       ("Criterion Value", "Value or list compared against.", "Alignment Rule", "Text", "", "ZIPLIST-NE-14", "Salesforce ETM", "", ""),
     ]),
   ]),
   ("Alignment Exceptions", "Named overrides that place a specific party in a territory against the rules.", [
     ("Alignment Exception", [
       ("Excepted Party", "Party the exception applies to.", "Alignment Rule", "Reference (Party)", "", "PTY-55120", "Internal", "", "Y"),
       ("Exception Type", "Reason category for the override.", "Alignment Rule", "Code", "Alignment Exception Type", "Relationship Holdover", "Internal", "", ""),
       ("Override Territory", "Territory the party is aligned to under the exception.", "Alignment Rule", "Reference (Territory)", "", "TER-US-0139", "Internal", "", "Y"),
       ("Exception Effective From", "Date the exception became effective.", "Alignment Rule", "Date", "ISO 8601", "2027-02-01", "Internal", "", ""),
       ("Exception Expiry Date", "Date the exception lapses; exceptions should not be open-ended.", "Alignment Rule", "Date", "ISO 8601", "2027-12-31", "Internal", "", ""),
     ]),
   ]),
   ("Alignment Results", "The resulting effective-dated alignment of each party to one or more territories.", [
     ("Party Territory Alignment", [
       ("Aligned Party", "Party aligned to the territory (firm, office, branch, advisor or plan).", "Alignment", "Reference (Party)", "", "PTY-55120", "Salesforce ETM", "", "Y"),
       ("Aligned Territory", "Territory the party is aligned to.", "Alignment", "Reference (Territory)", "", "TER-US-0142", "Salesforce ETM", "", "Y"),
       ("Alignment Cause", "How the alignment was created.", "Alignment", "Code", "Alignment Cause", "Rule", "Salesforce ETM", "", "Y"),
       ("Source Alignment Rule", "Rule or exception that produced the alignment.", "Alignment", "Reference (Alignment Rule)", "", "ALR-0381", "Internal", "", ""),
       ("Primary Alignment Indicator", "Whether this is the party's primary (non-overlay) territory for goals and crediting.", "Alignment", "Boolean", "", "", "Internal", "", ""),
       ("Alignment Effective From", "Date the alignment became effective.", "Alignment", "Date", "ISO 8601", "2027-01-01", "Internal", "", ""),
       ("Alignment Effective To", "Date the alignment ended.", "Alignment", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Realignment", "Events that move parties, geography or people between territories, with their credit and goal consequences.", [
     ("Realignment Event", [
       ("Realignment Event ID", "Unique identifier of the realignment event.", "Realignment", "Identifier", "", "RLN-2027-03", "Internal", "", ""),
       ("Realignment Type", "Nature of the change.", "Realignment", "Code", "Realignment Type", "Territory Split", "Internal", "", ""),
       ("Realignment Effective Date", "Date from which new alignments apply to coverage, goals and crediting.", "Realignment", "Date", "ISO 8601", "2027-04-01", "Internal", "", "Y"),
       ("Transition Credit Rule", "Crediting rule governing holdover / transition credit for the event.", "Realignment", "Reference (Crediting Rule)", "", "CRR-0150", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Coverage Model & Assignments", "CT-COV",
  "Who covers what: coverage models and roles, salesperson-to-territory assignments, coverage teams and pairings, party coverage assignments, coverage tiers and call standards.",
  [
   ("Coverage Model", "Standard coverage designs combining roles and ratios (e.g. external-internal pair, hybrid, national account team).", [
     ("Coverage Model", [
       ("Coverage Model Code", "Code of the coverage model.", "Coverage Model", "Code", "Coverage Model", "External-Internal Pair", "Internal", "", ""),
       ("Coverage Roles Included", "Coverage roles that make up the model.", "Coverage Model", "Code (multi)", "Coverage Role", "External Wholesaler; Internal Wholesaler", "Internal", "", ""),
     ]),
   ]),
   ("Salesperson Territory Assignment", "Effective-dated assignment of salespeople (EMP-, owned by 03 Sales) to territories in a coverage role.", [
     ("Territory Salesperson Assignment", [
       ("Assigned Salesperson", "Employee assigned to the territory.", "Coverage Assignment", "Reference (Employee)", "", "EMP-01377", "Salesforce ETM", "", "Y", "PII"),
       ("Assigned Territory", "Territory the salesperson is assigned to.", "Coverage Assignment", "Reference (Territory)", "", "TER-US-0142", "Salesforce ETM", "", "Y"),
       ("Coverage Role", "Role the salesperson plays in the territory.", "Coverage Assignment", "Code", "Coverage Role", "External Wholesaler", "Salesforce ETM", "Internal", "Y"),
       ("Assignment Type", "Nature of the assignment.", "Coverage Assignment", "Code", "Assignment Type", "Permanent", "Internal", "", ""),
       ("Allocation Percentage", "Share of the salesperson's capacity, goal and credit allocated to this territory where they cover more than one.", "Coverage Assignment", "Percentage", "", "100%", "Internal", "", ""),
       ("Assignment Effective From", "Date the assignment became effective.", "Coverage Assignment", "Date", "ISO 8601", "2027-01-01", "Internal", "", ""),
       ("Assignment Effective To", "Date the assignment ended.", "Coverage Assignment", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Required Licence Reference", "Licence / registration (owned by 08 DC) that must be active for the salesperson to cover the territory (e.g. FINRA registration, state registration).", "Coverage Assignment", "Reference (Licence)", "", "LIC-77812", "FINRA Rule 1210", "Internal", ""),
     ]),
   ]),
   ("Coverage Team & Pairing", "Teams and pairings of salespeople that jointly cover a territory or account set.", [
     ("Coverage Team", [
       ("Coverage Team ID", "Unique identifier of the coverage team.", "Coverage Team", "Identifier", "", "CTM-0219", "Internal", "", ""),
       ("Coverage Team Type", "Type of team.", "Coverage Team", "Code", "Coverage Team Type", "External-Internal Pair", "Internal", "", ""),
       ("Team Member", "Employee who is a member of the team.", "Coverage Team", "Reference (Employee)", "", "EMP-01377", "Internal", "", "", "PII"),
       ("Pairing Partner", "Employee the member is paired with (e.g. the external wholesaler for an internal).", "Coverage Team", "Reference (Employee)", "", "EMP-01412", "Internal", "", "", "PII"),
       ("Team Membership Effective From", "Date the membership became effective.", "Coverage Team", "Date", "ISO 8601", "2027-01-01", "Internal", "", ""),
     ]),
   ]),
   ("Party Coverage Assignment", "Effective-dated link between an external party (PTY-, owned by 02 CC) and the salesperson(s) who cover it.", [
     ("Party Coverage Assignment", [
       ("Coverage Assignment ID", "Unique identifier of the party coverage assignment.", "Coverage Assignment", "Identifier", "", "CVA-1093345", "Internal", "", "Y"),
       ("Covered Party", "Party (firm, home office, branch, advisor, consultant, plan sponsor, fund selector) being covered.", "Coverage Assignment", "Reference (Party)", "", "PTY-55120", "Internal", "Salesforce FSC", "Y"),
       ("Covered Account", "Account (owned by 02 CC) covered, for institutional, plan or platform relationships.", "Coverage Assignment", "Reference (Account)", "", "ACC-300981", "Internal", "", ""),
       ("Covering Salesperson", "Employee covering the party.", "Coverage Assignment", "Reference (Employee)", "", "EMP-01377", "Internal", "", "Y", "PII"),
       ("Party Coverage Role", "Role the salesperson plays for the party.", "Coverage Assignment", "Code", "Coverage Role", "External Wholesaler", "Internal", "", "Y"),
       ("Primary Coverage Indicator", "Whether this salesperson is the primary contact for the party in this role.", "Coverage Assignment", "Boolean", "", "", "Internal", "", ""),
       ("Coverage Effective From", "Date the coverage became effective.", "Coverage Assignment", "Date", "ISO 8601", "2027-01-01", "Internal", "", ""),
       ("Coverage Effective To", "Date the coverage ended.", "Coverage Assignment", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Relationship Start Date", "Date the salesperson first covered the party, across reassignments; used for holdover and tenure rules.", "Coverage Assignment", "Date", "ISO 8601", "2023-05-01", "Internal", "", ""),
     ]),
   ]),
   ("Coverage Tiering & Service Standards", "Coverage tiers (A/B/C) assigned to covered parties and the call-frequency standards that each tier and role must meet.", [
     ("Coverage Tier Assignment", [
       ("Coverage Tier", "Coverage priority tier of the party for the territory.", "Coverage Assignment", "Code", "Coverage Tier", "A", "Internal", "", "Y"),
       ("Tier Effective From", "Date the tier became effective.", "Coverage Assignment", "Date", "ISO 8601", "2027-01-01", "Internal", "", ""),
     ]),
     ("Call Frequency Standard", [
       ("Standard Coverage Role", "Coverage role the standard applies to.", "Coverage Model", "Code", "Coverage Role", "External Wholesaler", "Internal", "", ""),
       ("Standard Coverage Tier", "Coverage tier the standard applies to.", "Coverage Model", "Code", "Coverage Tier", "A", "Internal", "", ""),
       ("Qualifying Activity Type", "Activity type (owned by 03 Sales) that counts towards the standard.", "Coverage Model", "Code (multi)", "External (03 Sales - Activity Type)", "In-Person Meeting; Virtual Meeting", "Internal", "", ""),
       ("Required Interactions per Period", "Minimum qualifying interactions per period.", "Coverage Model", "Integer", "", "6", "Internal", "", ""),
       ("Standard Period", "Period over which the standard is measured.", "Coverage Model", "Code", "Frequency", "Annual", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Goals & Quotas", "CT-GOL",
  "Sales goals and quotas set for territories, teams and salespeople, how they cascade and are adjusted, and how attainment against TX-sourced actuals is calculated.",
  [
   ("Goal Plan", "The annual goal-setting cycle and its periods.", [
     ("Goal Plan", [
       ("Goal Plan ID", "Unique identifier of the goal plan.", "Goal", "Identifier", "", "GPL-US-FY2027", "Internal", "", ""),
       ("Goal Plan Year", "Plan year the goals apply to.", "Goal", "Text", "", "FY2027", "Internal", "", ""),
       ("Goal Setting Method", "Primary method used to set goals.", "Goal", "Code", "Goal Setting Method", "Potential-Based", "Internal", "Xactly", ""),
     ]),
   ]),
   ("Goal Definition", "Individual goals by type, holder, period, measure and product scope.", [
     ("Goal", [
       ("Goal ID", "Unique identifier of the goal.", "Goal", "Identifier", "", "GOL-2027-018833", "Internal", "", "Y"),
       ("Goal Type", "What the goal measures.", "Goal", "Code", "Goal Type", "Net Sales", "Internal", "Xactly", "Y"),
       ("Goal Holder Type", "Kind of entity holding the goal.", "Goal", "Code", "Goal Holder Type", "Salesperson", "Internal", "", ""),
       ("Goal Holder", "Territory, team or salesperson that holds the goal.", "Goal", "Reference (Territory / Employee / Team)", "", "EMP-01377", "Internal", "", "Y", "PII when holder is a person"),
       ("Goal Period Start", "First day of the goal period.", "Goal", "Date", "ISO 8601", "2027-01-01", "Internal", "", ""),
       ("Goal Period End", "Last day of the goal period.", "Goal", "Date", "ISO 8601", "2027-12-31", "Internal", "", ""),
       ("Goal Value", "Target value for the period.", "Goal", "Decimal", "", "180000000", "Xactly", "", "Y"),
       ("Goal Unit", "Unit of the goal value.", "Goal", "Code", "Goal Unit", "Currency", "Internal", "", ""),
       ("Goal Measure Definition", "Flow / AUM / revenue measure (owned by 06 TX) the goal is measured on.", "Goal", "Code", "External (06 TX - Flow & AUM Measure)", "Net Sales (ex Money Market)", "Internal", "", "Y"),
       ("Goal Product Scope", "Product(s) or product group a product-specific or focus-fund goal applies to.", "Goal", "Reference (Product)", "", "PRD-00981", "Internal", "", ""),
       ("Goal Weight", "Weight of the goal in the participant's scorecard / plan.", "Goal", "Percentage", "", "60%", "Xactly", "", ""),
     ]),
   ]),
   ("Goal Cascade & Adjustment", "How goals cascade down and roll up the territory hierarchy, and controlled adjustments to set goals.", [
     ("Goal Cascade", [
       ("Parent Goal", "Higher-level goal this goal was allocated from.", "Goal", "Reference (Goal)", "", "GOL-2027-000412", "Internal", "", ""),
       ("Allocation Percentage", "Share of the parent goal allocated to this goal.", "Goal", "Percentage", "", "8.5%", "Internal", "", ""),
       ("Over-Allocation Factor", "Factor by which the sum of child goals exceeds the parent (deliberate cushion).", "Goal", "Percentage", "", "105%", "Internal", "", ""),
     ]),
     ("Goal Adjustment", [
       ("Goal Adjustment Reason", "Reason for the adjustment.", "Goal", "Code", "Goal Adjustment Reason", "Realignment", "Internal", "", ""),
       ("Adjusted Goal Value", "Goal value after the adjustment.", "Goal", "Decimal", "", "158000000", "Internal", "", ""),
       ("Goal Adjustment Effective Date", "Date from which the adjusted value applies.", "Goal", "Date", "ISO 8601", "2027-04-01", "Internal", "", ""),
       ("Goal Adjustment Approver", "Employee who approved the adjustment.", "Goal", "Reference (Employee)", "", "EMP-00045", "Internal", "", ""),
     ]),
   ]),
   ("Goal Attainment", "Actual results against goals, sourced from 06 TX measures through credit allocations.", [
     ("Goal Attainment", [
       ("Attainment As-of Date", "Date the actuals are measured to.", "Goal", "Date", "ISO 8601", "2027-06-30", "Internal", "", ""),
       ("Credited Actual Value", "Credited actual for the goal measure and period (sum of credit allocations).", "Goal", "Decimal", "", "97500000", "Internal", "Xactly", "Y"),
       ("Attainment Percentage", "Credited actual divided by goal value.", "Goal", "Percentage", "", "54.2%", "Xactly", "", "Y"),
       ("Attainment Calculation Method", "How attainment is calculated (cumulative to date, period-only, pro-rated goal).", "Goal", "Code", "Attainment Method", "Year-to-Date Cumulative", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Crediting Rules", "CT-CRR",
  "The crediting rule master (CRR-) that decides who is credited, on what basis and in what share for each attributed flow or asset, plus eligibility, transition credit, credit allocations, adjustments and clawbacks.",
  [
   ("Crediting Rule Master", "Rules that determine credit basis, credit type, trigger and precedence.", [
     ("Crediting Rule", [
       ("Crediting Rule ID", "Unique identifier of the crediting rule.", "Crediting Rule", "Identifier", "", "CRR-0101", "Internal", "Xactly", "Y"),
       ("Credit Basis", "Measure on which credit is given.", "Crediting Rule", "Code", "Credit Basis", "Gross Sales", "Internal", "Xactly", "Y"),
       ("Credit Type", "Type of credit the rule produces.", "Crediting Rule", "Code", "Credit Type", "Direct", "Xactly", "Internal", "Y"),
       ("Eligible Coverage Roles", "Coverage roles that receive credit under the rule.", "Crediting Rule", "Code (multi)", "Coverage Role", "External Wholesaler; Internal Wholesaler", "Internal", "", ""),
       ("Credit Trigger Event", "Event that creates credit.", "Crediting Rule", "Code", "Credit Trigger Event", "Trade Date", "Internal", "", ""),
       ("Crediting Rule Precedence", "Evaluation order when more than one rule matches a transaction.", "Crediting Rule", "Integer", "", "10", "Internal", "", ""),
       ("Minimum Holding Period", "Days an investment must remain invested before credit is final (anti-churn).", "Crediting Rule", "Integer", "Days", "90", "Internal", "", ""),
       ("Crediting Rule Status", "Lifecycle status of the rule.", "Crediting Rule", "Code", "Rule Status", "Active", "Internal", "", ""),
       ("Crediting Rule Effective From", "Date the rule became effective.", "Crediting Rule", "Date", "ISO 8601", "2027-01-01", "Internal", "", ""),
       ("Crediting Rule Effective To", "Date the rule ceased to be effective.", "Crediting Rule", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Split & Overlay Credit", "How credit is shared between recipients or given in full to more than one (overlay / double credit).", [
     ("Credit Split", [
       ("Split Recipient Role", "Coverage role receiving a share of the credit.", "Crediting Rule", "Code", "Coverage Role", "Internal Wholesaler", "Xactly", "", ""),
       ("Split Percentage", "Share of the credit given to the recipient role.", "Crediting Rule", "Percentage", "", "100%", "Xactly", "", "Y"),
       ("Overlay Credit Indicator", "Whether the recipient receives full credit in addition to primary credit (not counted against the 100% split).", "Crediting Rule", "Boolean", "", "Y", "Internal", "", ""),
     ]),
   ]),
   ("Product & Transaction Eligibility", "Which products, share classes and transaction types are creditable.", [
     ("Credit Eligibility Criterion", [
       ("Eligible Product Scope", "Products or share classes (owned by 01 Product) that are creditable under the rule.", "Crediting Rule", "Reference (Product / Share Class)", "", "All open-end funds and ETFs", "Internal", "", ""),
       ("Credit Exclusion Category", "Categories of product or flow excluded from credit.", "Crediting Rule", "Code (multi)", "Credit Exclusion Category", "Money Market; Internal Fund-of-Funds", "Internal", "", "Y"),
       ("Eligible Transaction Types", "Transaction types (owned by 06 TX) that create credit.", "Crediting Rule", "Code (multi)", "External (06 TX - Transaction Type)", "Purchase; Exchange In", "Internal", "", ""),
       ("Exchange Treatment", "How intra-family exchanges are credited.", "Crediting Rule", "Code", "Exchange Credit Treatment", "Net to Zero", "Internal", "", ""),
     ]),
   ]),
   ("Transition & Holdover Credit", "Credit rules applied for a period after realignment, vacancy or salesperson moves.", [
     ("Transition Credit Rule", [
       ("Holdover Period", "Months for which transition credit applies after the realignment effective date.", "Crediting Rule", "Integer", "Months", "6", "Internal", "", ""),
       ("Outgoing Salesperson Split", "Credit share retained by the previous coverer during the holdover.", "Crediting Rule", "Percentage", "", "50%", "Internal", "", ""),
     ]),
   ]),
   ("Credit Allocations & Adjustments", "The resulting credit records for each transaction or position, and controlled adjustments, reversals and clawbacks.", [
     ("Credit Allocation", [
       ("Credit Allocation ID", "Unique identifier of the credit record.", "Credit Allocation", "Identifier", "", "CRA-2027-0938841", "Xactly", "", "Y"),
       ("Source Transaction", "Transaction (owned by 06 TX) that generated the credit.", "Credit Allocation", "Reference (Transaction)", "", "TXN-2027-55018832", "Internal", "", "Y"),
       ("Source Position", "Position (owned by 06 TX) on which AUM-based credit is given.", "Credit Allocation", "Reference (Position)", "", "POS-881023", "Internal", "", ""),
       ("Credited Salesperson", "Employee receiving the credit.", "Credit Allocation", "Reference (Employee)", "", "EMP-01377", "Xactly", "", "Y", "PII"),
       ("Credited Territory", "Territory receiving the credit.", "Credit Allocation", "Reference (Territory)", "", "TER-US-0142", "Internal", "", ""),
       ("Applied Crediting Rule", "Crediting rule that produced the allocation.", "Credit Allocation", "Reference (Crediting Rule)", "", "CRR-0101", "Internal", "", "Y"),
       ("Credit Amount", "Amount credited (basis amount x split percentage).", "Credit Allocation", "Amount", "", "USD 250,000", "Xactly", "", "Y"),
       ("Credit Date", "Date the credit is recognised for period assignment.", "Credit Allocation", "Date", "ISO 8601", "2027-03-14", "Internal", "", ""),
       ("Credit Status", "Status of the credit.", "Credit Allocation", "Code", "Credit Status", "Final", "Internal", "", ""),
     ]),
     ("Credit Adjustment", [
       ("Credit Adjustment Type", "Type of adjustment.", "Credit Allocation", "Code", "Credit Adjustment Type", "Clawback", "Internal", "Salesforce Spiff", "Y"),
       ("Original Credit Allocation", "Credit record being adjusted or reversed.", "Credit Allocation", "Reference (Credit Allocation)", "", "CRA-2027-0938841", "Internal", "", ""),
       ("Credit Adjustment Amount", "Amount of the adjustment (negative for debits and clawbacks).", "Credit Allocation", "Amount", "", "USD -250,000", "Internal", "", ""),
       ("Clawback Window", "Days after the credit date within which a redemption triggers clawback.", "Crediting Rule", "Integer", "Days", "90", "Internal", "", ""),
       ("Credit Adjustment Approval Status", "Approval status of the adjustment.", "Credit Allocation", "Code", "Approval Status", "Approved", "Internal", "SOX", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Incentive Compensation Plans", "CT-ICP",
  "The incentive compensation plan master (ICP-), its components, rate tables and product comp tiers, SPIFs and MBOs, and the assignment of plans to participants (EMP-).",
  [
   ("Plan Master", "Identity, type, year and terms of each incentive plan.", [
     ("Incentive Compensation Plan", [
       ("Plan ID", "Unique identifier of the incentive compensation plan.", "Plan", "Identifier", "", "ICP-US-EW-2027", "Internal", "Xactly", "Y"),
       ("Plan Name", "Name of the plan.", "Plan", "Text", "", "US External Wholesaler Plan 2027", "Xactly", "", "Y"),
       ("Plan Type", "Overall structure of the plan.", "Plan", "Code", "Plan Type", "Commission + Bonus", "Internal", "", "Y"),
       ("Plan Year", "Plan year the plan applies to.", "Plan", "Text", "", "FY2027", "Internal", "", ""),
       ("Payout Frequency", "Frequency of incentive payments.", "Plan", "Code", "Frequency", "Monthly", "Internal", "", ""),
       ("Plan Status", "Lifecycle status of the plan.", "Plan", "Code", "Plan Status", "Approved", "Internal", "", ""),
       ("Plan Effective From", "Date the plan became effective.", "Plan", "Date", "ISO 8601", "2027-01-01", "Internal", "", ""),
     ]),
   ]),
   ("Plan Components", "Commission, bonus, accelerator, cap, threshold, SPIF and MBO components and the rate tables behind them.", [
     ("Plan Component", [
       ("Component ID", "Unique identifier of the plan component.", "Plan Component", "Identifier", "", "ICP-US-EW-2027-C02", "Xactly", "", ""),
       ("Component Type", "Type of component.", "Plan Component", "Code", "Plan Component Type", "Commission", "Xactly", "Salesforce Spiff", "Y"),
       ("Component Measure", "Credit basis on which the component pays.", "Plan Component", "Code", "Credit Basis", "Gross Sales", "Internal", "", ""),
       ("Component Weight", "Share of target incentive allocated to the component.", "Plan Component", "Percentage", "", "40%", "Xactly", "", ""),
       ("Threshold Attainment", "Attainment below which the component pays nothing.", "Plan Component", "Percentage", "", "50%", "Internal", "", ""),
       ("Component Cap", "Maximum payout for the component, as amount or % of target.", "Plan Component", "Text", "", "200% of component target", "Internal", "", ""),
     ]),
     ("Rate Table Tier", [
       ("Rate Product Tier", "Product compensation tier the rate applies to.", "Plan Component", "Code", "Product Compensation Tier", "Tier 2 - Core", "Internal", "", ""),
       ("Tier Lower Bound", "Lower bound of the attainment band (inclusive).", "Plan Component", "Percentage", "", "100%", "Xactly", "", ""),
       ("Tier Upper Bound", "Upper bound of the attainment band (exclusive).", "Plan Component", "Percentage", "", "125%", "Xactly", "", ""),
       ("Commission Rate", "Rate paid on credited amount in the band, in basis points.", "Plan Component", "Decimal", "Basis points", "5.0", "Xactly", "", "Y"),
       ("Rate Multiplier", "Accelerator (>1) or decelerator (<1) applied to the base rate in the band.", "Plan Component", "Decimal", "", "1.5", "Xactly", "", ""),
     ]),
     ("Product Compensation Tier Mapping", [
       ("Mapped Product / Share Class", "Product or share class (owned by 01 Product) assigned to a comp tier.", "Plan Component", "Reference (Product / Share Class)", "", "SHC-004512", "Internal", "", "Y"),
       ("Mapped Product Compensation Tier", "Comp tier assigned to the product.", "Plan Component", "Code", "Product Compensation Tier", "Tier 1 - Strategic", "Internal", "", ""),
       ("Tier Mapping Effective From", "Date the mapping became effective.", "Plan Component", "Date", "ISO 8601", "2027-01-01", "Internal", "", ""),
     ]),
     ("SPIF & MBO", [
       ("Incentive Objective Type", "What the SPIF / MBO rewards.", "Plan Component", "Code", "Incentive Objective Type", "New Advisors", "Internal", "", ""),
       ("Product-Specific Incentive Indicator", "Whether the incentive is based on sales of specific products or product types within a limited period (flagged for Reg BI / FINRA 2341 and MiFID review).", "Plan Component", "Boolean", "", "N", "SEC Reg BI", "FINRA Rule 2341", "Y"),
       ("Award Value", "Cash value of the award, or estimated value of a non-cash award.", "Plan Component", "Amount", "", "USD 5,000", "Internal", "", ""),
       ("Non-Cash Award Indicator", "Whether the award is non-cash (trip, merchandise); non-cash rules are owned by 08 DC.", "Plan Component", "Boolean", "", "N", "FINRA Rule 2341", "FINRA Rule 3220", ""),
       ("Compliance Review Reference", "Compliance review (owned by 08 DC) approving the SPIF or contest.", "Plan Component", "Reference (Compliance Review)", "", "REV-2027-0481", "Internal", "", ""),
     ]),
   ]),
   ("Plan Eligibility & Assignment", "Assignment of plans and target incentives to individual participants.", [
     ("Plan Participant Assignment", [
       ("Plan Participant", "Employee (owned by 03 Sales) assigned to the plan.", "Participant", "Reference (Employee)", "", "EMP-01377", "Xactly", "", "Y", "PII"),
       ("Assigned Plan", "Plan assigned to the participant.", "Participant", "Reference (Plan)", "", "ICP-US-EW-2027", "Xactly", "", "Y"),
       ("Target Incentive Amount", "Annual incentive at 100% attainment.", "Participant", "Amount", "", "USD 210,000", "Xactly", "", "Y", "PII; confidential"),
       ("Participant Eligibility Status", "Eligibility of the participant to earn and be paid.", "Participant", "Code", "Participant Eligibility Status", "Eligible", "Internal", "", ""),
       ("Plan Acknowledgement Date", "Date the participant acknowledged the plan document.", "Participant", "Date", "ISO 8601", "2027-01-20", "Internal", "SOX", ""),
       ("Participant Assignment Effective From", "Date the plan assignment became effective.", "Participant", "Date", "ISO 8601", "2027-01-01", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Payout Calculation & Statements", "CT-PAY",
  "Compensation periods, earnings calculations, draws, payout adjustments, disputes, statements, payroll hand-off and finance accruals.",
  [
   ("Compensation Period", "Calculation periods and their close status.", [
     ("Compensation Period", [
       ("Compensation Period ID", "Unique identifier of the compensation period.", "Period", "Identifier", "", "CP-2027-03", "Xactly", "", ""),
       ("Period Start Date", "First day of the period.", "Period", "Date", "ISO 8601", "2027-03-01", "Internal", "", ""),
       ("Period End Date", "Last day of the period.", "Period", "Date", "ISO 8601", "2027-03-31", "Internal", "", ""),
       ("Credit Cut-off Date", "Last date credits and adjustments are accepted into the period.", "Period", "Date", "ISO 8601", "2027-04-08", "Internal", "", ""),
       ("Period Status", "Processing status of the period.", "Period", "Code", "Period Status", "Locked", "Xactly", "", ""),
     ]),
   ]),
   ("Earnings Calculation", "Calculated incentive earnings per participant, component and period.", [
     ("Earnings Result", [
       ("Earnings Result ID", "Unique identifier of the earnings result.", "Statement", "Identifier", "", "ERN-2027-03-01377-C02", "Internal", "", "Y"),
       ("Earning Participant", "Employee who earned the amount.", "Statement", "Reference (Employee)", "", "EMP-01377", "Internal", "", "Y", "PII"),
       ("Earning Component", "Plan component that produced the earnings.", "Statement", "Reference (Plan Component)", "", "ICP-US-EW-2027-C02", "Internal", "", ""),
       ("Earning Period", "Compensation period of the earnings.", "Statement", "Reference (Compensation Period)", "", "CP-2027-03", "Internal", "", ""),
       ("Rate Applied", "Rate (bps) or multiplier applied.", "Statement", "Decimal", "Basis points", "5.0", "Internal", "", ""),
       ("Earned Amount", "Gross incentive earned for the component and period.", "Statement", "Amount", "", "USD 21,000", "Xactly", "", "Y", "PII; confidential"),
       ("Calculation Run ID", "Identifier of the calculation run that produced the result (for reproducibility).", "Statement", "Identifier", "", "RUN-2027-04-09-01", "Internal", "SOX", ""),
     ]),
   ]),
   ("Draws & Payout Adjustments", "Draws against future earnings and manual payout adjustments.", [
     ("Draw", [
       ("Draw Type", "Type of draw.", "Participant", "Code", "Draw Type", "Recoverable", "Xactly", "", ""),
       ("Draw Amount per Period", "Draw paid per period.", "Participant", "Amount", "", "USD 8,000", "Internal", "", "", "PII; confidential"),
     ]),
     ("Payout Adjustment", [
       ("Payout Adjustment Type", "Type of adjustment.", "Statement", "Code", "Payout Adjustment Type", "Guarantee Top-up", "Internal", "", ""),
       ("Payout Adjustment Amount", "Amount of the adjustment.", "Statement", "Amount", "", "USD 3,500", "Internal", "", ""),
       ("Payout Adjustment Approval Status", "Approval status.", "Statement", "Code", "Approval Status", "Approved", "Internal", "SOX", ""),
     ]),
   ]),
   ("Disputes & Inquiries", "Participant challenges to credits or earnings and their resolution.", [
     ("Compensation Dispute", [
       ("Dispute ID", "Unique identifier of the dispute.", "Statement", "Identifier", "", "DSP-2027-0219", "Salesforce Spiff", "", ""),
       ("Dispute Category", "Category of the dispute.", "Statement", "Code", "Dispute Category", "Missing Credit", "Internal", "", ""),
       ("Disputed Item", "Credit allocation or earnings result being disputed.", "Statement", "Reference (Credit Allocation / Earnings Result)", "", "CRA-2027-0938841", "Internal", "", ""),
       ("Dispute Status", "Status of the dispute.", "Statement", "Code", "Dispute Status", "Resolved - Upheld", "Internal", "", ""),
     ]),
   ]),
   ("Statements & Payment", "Compensation statements issued to participants and payment instructions sent to payroll.", [
     ("Compensation Statement", [
       ("Statement ID", "Unique identifier of the statement.", "Statement", "Identifier", "", "STM-2027-03-01377", "Salesforce Spiff", "Xactly", "Y"),
       ("Statement Participant", "Employee the statement is for.", "Statement", "Reference (Employee)", "", "EMP-01377", "Internal", "", "Y", "PII"),
       ("Total Earned", "Total earnings for the period across components.", "Statement", "Amount", "", "USD 27,400", "Internal", "", "", "PII; confidential"),
       ("Net Payable Amount", "Amount payable after draws, recoveries and adjustments.", "Statement", "Amount", "", "USD 19,400", "Internal", "", "Y", "PII; confidential"),
     ]),
     ("Payroll Payment Instruction", [
       ("Payment Amount", "Gross amount instructed to payroll.", "Payment", "Amount", "", "USD 19,400", "Internal", "", "Y", "PII; confidential"),
       ("Scheduled Pay Date", "Payroll date on which the incentive is paid.", "Payment", "Date", "ISO 8601", "2027-04-30", "Internal", "", ""),
       ("Payment Status", "Status of the payroll instruction.", "Payment", "Code", "Payment Status", "Paid", "Internal", "", ""),
     ]),
   ]),
   ("Finance Accruals", "Incentive compensation accruals and true-ups for the general ledger.", [
     ("Compensation Accrual", [
       ("Accrual Period", "Accounting period of the accrual.", "Accrual", "Text", "", "2027-03", "ASC 710", "", ""),
       ("Accrual Amount", "Incentive compensation expense accrued for the period.", "Accrual", "Amount", "", "USD 4,850,000", "ASC 710", "IAS 19", "Y"),
       ("GL Account", "General-ledger account for the expense.", "Accrual", "Code", "Firm-defined", "620150", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Compensation Governance & Controls", "CT-GOV",
  "Plan approvals, remuneration conflict assessments against US and EU/UK rules, financial controls, audit trail and data management metadata for the compensation and territory domain.",
  [
   ("Plan Governance & Approval", "Approval workflow for plans, rate tables, crediting rules and territory models.", [
     ("Governance Approval", [
       ("Approved Object", "Plan, crediting rule, territory model or adjustment being approved.", "Control", "Reference (Plan / Crediting Rule / Territory Model)", "", "ICP-US-EW-2027", "Internal", "", "Y"),
       ("Approval Stage", "Body or function giving the approval.", "Control", "Code", "Approval Stage", "Compliance", "Internal", "COSO", ""),
       ("Approver", "Employee who gave the decision.", "Control", "Reference (Employee)", "", "EMP-00031", "Internal", "", ""),
       ("Approval Decision", "Decision taken.", "Control", "Code", "Approval Status", "Approved", "Internal", "", "Y"),
       ("Approval Date", "Date of the decision.", "Control", "Date", "ISO 8601", "2026-12-04", "Internal", "", "Y"),
     ]),
   ]),
   ("Remuneration Conflict Assessment", "Assessment of plans and incentives against sales-remuneration and conflict-of-interest rules (rules owned by 08 DC; the assessment record lives with the plan).", [
     ("Remuneration Conflict Assessment", [
       ("Assessed Plan / Component", "Plan or component assessed.", "Plan", "Reference (Plan / Plan Component)", "", "ICP-US-EW-2027-C04", "Internal", "", "Y"),
       ("Applicable Remuneration Regime", "Regulatory regime(s) the assessment is made against.", "Plan", "Code (multi)", "Remuneration Regime", "SEC Reg BI; FINRA Rule 2341", "SEC Reg BI", "ESMA MiFID Remuneration Guidelines", "Y"),
       ("Qualitative Criteria Included Indicator", "Whether variable pay includes qualitative criteria (e.g. client outcomes, compliance) and not only sales volume.", "Plan", "Boolean", "", "Y", "ESMA MiFID Remuneration Guidelines", "UK FCA SYSC 19F", "Y"),
       ("Product Neutrality Assessment", "Whether rates and tiers create an incentive to favour one product over another for reasons other than client interest.", "Plan", "Code", "Assessment Outcome", "No Conflict Identified", "UK FCA SYSC 19F", "SEC Reg BI", ""),
       ("Assessment Outcome", "Overall outcome of the assessment.", "Plan", "Code", "Assessment Outcome", "Conflict Mitigated", "Internal", "", "Y"),
       ("Relevant Person Indicator", "Whether the participant is a 'relevant person' whose pay is in scope of MiFID II / SYSC 19F sales remuneration rules.", "Participant", "Boolean", "", "Y", "MiFID II", "ESMA MiFID Remuneration Guidelines", "", "PII"),
       ("Identified Staff Indicator", "Whether the participant is identified / Code staff under UCITS or AIFMD remuneration rules (usually set by HR / Reward).", "Participant", "Boolean", "", "N", "ESMA UCITS Remuneration Guidelines", "UK FCA SYSC 19E", "", "PII"),
     ]),
   ]),
   ("Controls & Audit Trail", "Financial and operational controls over crediting and payout, and the change history of comp data.", [
     ("Compensation Control", [
       ("Control ID", "Unique identifier of the control.", "Control", "Identifier", "", "CTL-ICM-07", "COSO", "SOX", "Y"),
       ("Control Description", "What the control does.", "Control", "Text", "", "Independent review of manual credit adjustments above USD 5m before period lock", "COSO", "", ""),
       ("SOX Key Control Indicator", "Whether the control is a key control over financial reporting.", "Control", "Boolean", "", "Y", "SOX", "", ""),
       ("Last Test Result", "Result of the latest control test.", "Control", "Code", "Control Test Result", "Effective", "SOX", "", ""),
     ]),
     ("Change Audit Record", [
       ("Changed Object ID", "Identifier of the record changed (rule, plan, assignment, credit, goal).", "All", "Identifier", "", "CRR-0101", "Internal", "SOX", ""),
       ("Changed Field", "Attribute changed.", "All", "Text", "", "Split Percentage", "Internal", "", ""),
       ("Previous Value", "Value before the change.", "All", "Text", "", "50%", "Internal", "", ""),
       ("New Value", "Value after the change.", "All", "Text", "", "60%", "Internal", "", ""),
       ("Changed By", "User who made the change.", "All", "Reference (Employee)", "", "EMP-00502", "Internal", "", "Y", "PII"),
       ("Change Timestamp", "When the change was made.", "All", "Timestamp", "ISO 8601", "2027-03-02T14:11:09Z", "Internal", "", ""),
     ]),
   ]),
   ("Data Management Metadata", "Metadata applied to every record in the compensation and territory domain.", [
     ("Record Metadata", [
       ("Data Owner", "Business role accountable for the data element.", "All", "Reference (Employee)", "", "Head of Sales Compensation", "DCAM (EDM Council)", "", ""),
       ("Data Steward", "Role responsible for day-to-day data quality.", "All", "Reference (Employee)", "", "Sales Operations Data Steward", "DCAM (EDM Council)", "", ""),
       ("System of Record", "System holding the authoritative value.", "All", "Code", "Firm-defined", "ICM Platform", "Internal", "", ""),
       ("Data Classification", "Confidentiality classification of the record.", "All", "Code", "Data Classification", "Confidential - Compensation", "Internal", "GDPR", ""),
       ("Record Effective From", "Business-effective start date of the record version.", "All", "Date", "ISO 8601", "2027-01-01", "Internal", "", ""),
       ("Record Effective To", "Business-effective end date of the record version.", "All", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Last Updated Timestamp", "System timestamp of the last change.", "All", "Timestamp", "ISO 8601", "2027-03-02T14:11:09Z", "Internal", "", ""),
       ("Data Quality Status", "Validation status of the record.", "All", "Code", "Data Quality Status", "Validated", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Market Scope": ("Internal", [("US",""),("UK",""),("EU","EU/EEA countries covered by the EU distribution entity"),("Switzerland",""),("Global","Global accounts spanning markets")]),
 "Territory Model State": ("Salesforce ETM", [("Planning","Being designed; not used for access, goals or crediting"),("Active","The single live model for the market"),("Archived","Retired; retained for history"),("Cloning","System state while a model is copied")]),
 "Territory Type": ("Internal (aligned to Salesforce ETM Territory2Type)", [("Geographic","Defined by states, counties, CBSAs, ZIPs, postcodes or countries"),("National Account","Account-based: one or more named distributor firms (wirehouse, large IBD, private bank), nationally"),("Key Account / Global Account","Named global or pan-European distributor relationships"),("Channel","Defined by channel, e.g. RIA, bank trust, insurance, platform"),("Segment","Defined by client segment, e.g. institutional public funds, endowments & foundations"),("Hybrid","Combination of geography and channel/firm, e.g. RIA channel within the Northeast"),("Overlay","Specialist coverage overlapping primary territories, e.g. ETF, alternatives, SMA/model, DCIO"),("Consultant Relations","Coverage of investment consultants and their research teams"),("Fund Selector","EU/UK coverage of fund selectors, discretionary managers and fund-of-fund buyers"),("House","Unassigned or house accounts with no individual coverage")]),
 "Territory Level": ("Internal", [("Division","Top level, e.g. US Retail Wholesale, EMEA Wholesale"),("Region","e.g. Northeast, West; or UK & Ireland, DACH"),("Territory","Primary unit covered by one salesperson or pair"),("Sub-Territory","Optional subdivision, e.g. for internal wholesaler desks")]),
 "Territory Status": ("Internal", [("Proposed",""),("Active",""),("Vacant","Active but no salesperson assigned"),("Merged",""),("Split",""),("Retired","")]),
 "Territory Hierarchy Type": ("Internal", [("Primary Wholesale","Geographic retail wholesale roll-up"),("National Accounts",""),("Institutional",""),("Overlay / Specialist",""),("Management Reporting","Alternative roll-up for finance or executive reporting")]),
 "Coverage Model": ("Internal", [("External-Internal Pair","External wholesaler partnered with an internal wholesaler"),("Hybrid Wholesaler","One salesperson covering in person and virtually, usually lower-density territory"),("Internal Only / Virtual","Virtual coverage of lower-tier or remote advisors"),("National Account Team","Key account manager plus home office specialists"),("Institutional RM","Relationship manager with consultant relations and product specialists"),("DCIO Team","DC specialist covering recordkeepers, advisers and plan consultants"),("Country Sales Team","EU/UK country or cluster sales team"),("Global Account Team","Pan-market coverage of a global distributor")]),
 "Geographic Unit Type": ("Internal (aligned to ISO 3166, US Census, Eurostat, ONS)", [("Country","ISO 3166-1"),("Country Subdivision","ISO 3166-2, e.g. US state, UK nation, German Land"),("County","US county by FIPS code"),("CBSA","US metropolitan / micropolitan statistical area (OMB)"),("ZIP Code","USPS 5-digit ZIP; ZCTA used for mapping"),("ZIP3","First 3 digits of ZIP (sectional centre)"),("UK Postcode Area",""),("UK Postcode District",""),("NUTS Region","NUTS 1, 2 or 3 region (EU)"),("City","")]),
 "Inclusion Type": ("Internal", [("Include",""),("Exclude","Carve-out from a larger included unit")]),
 "Sales Channel": ("Internal (to align with 02 CC channel classification)", [("Wirehouse",""),("Regional Broker-Dealer",""),("Independent Broker-Dealer",""),("RIA",""),("Bank / Trust",""),("Insurance / Annuity",""),("Retirement / DCIO",""),("Private Bank / Wealth Manager",""),("IFA / Financial Adviser","UK"),("Discretionary Fund Manager","UK / EU"),("Fund Platform",""),("Fund of Funds / Multi-Manager",""),("Institutional Direct",""),("Investment Consultant","")]),
 "Product Scope": ("Internal", [("All Products",""),("Mutual Funds / UCITS",""),("ETFs",""),("SMA / Models",""),("Alternatives / Private Markets",""),("Fixed Income",""),("Retirement / Target Date","")]),
 "Territory Potential Metric": ("Internal", [("Advisor Count","Advisors aligned to the territory"),("Producing Advisor Count","Advisors with sales to the firm in the last 12 months"),("Branch Count",""),("Addressable Industry AUM","Industry assets in categories where the firm has products"),("Addressable Industry Gross Sales",""),("Firm AUM","Firm assets attributed to the territory (06 TX)"),("Wallet Share","Firm AUM / addressable industry AUM"),("DC Plan Assets","Defined contribution assets of plans in the territory"),("Institutional Prospect Count",""),("Estimated Call Workload Hours","")]),
 "Market Sizing Source": ("Internal", [("Intermediary Sales Data Vendor","e.g. Broadridge, Morningstar distribution data"),("Industry Flow Database","e.g. ISS Market Intelligence / Simfund, Morningstar Direct"),("Advisor Database","e.g. Discovery Data, FINRA BrokerCheck derived"),("Firm CRM",""),("Transfer Agent / Sub-Accounting","Via 06 TX"),("Internal Estimate","")]),
 "Alignment Rule Type": ("Internal", [("Geo-Based","By location of the branch / office / advisor"),("Firm-Based","By parent distributor firm (national accounts)"),("Branch-Based","By named branch or office"),("Named Account","Explicit list of parties"),("Channel / Segment-Based","By channel or segment classification of the party"),("Overlay","Adds an overlay alignment in addition to the primary alignment"),("House","Default for unaligned parties")]),
 "Aligned Party Level": ("Internal (aligned to 02 CC firm hierarchy)", [("Firm",""),("Home Office",""),("Branch / Office",""),("Team / Practice",""),("Advisor / Rep",""),("Account",""),("Retirement Plan",""),("Consultant","")]),
 "Rule Operator": ("Salesforce ETM", [("Equals",""),("Not Equal To",""),("In List",""),("Not In List",""),("Starts With",""),("Contains",""),("Greater Than",""),("Less Than","")]),
 "Rule Status": ("Internal", [("Draft",""),("Active",""),("Inactive",""),("Retired","")]),
 "Alignment Exception Type": ("Internal", [("Named-Account Carve-Out",""),("Relationship Holdover","Previous coverer keeps a relationship for a period"),("Split Coverage","Party deliberately covered by two territories"),("Vacancy Coverage","Temporary coverage of an open territory"),("Data Correction","Party address or firm data is wrong at source")]),
 "Alignment Cause": ("Salesforce ETM (AssociationCause)", [("Rule","Assigned by the rules engine"),("Manual","Assigned by a user or via API"),("Exception","Assigned by an approved alignment exception"),("Inherited","Inherited from a parent party alignment")]),
 "Realignment Type": ("Internal", [("Annual Redesign",""),("Territory Split",""),("Territory Merge",""),("Party Transfer",""),("Firm Re-tiering","Firm moved to / from national accounts"),("Headcount Change",""),("Advisor Move","Advisor or team changed firm or branch")]),
 "Coverage Role": ("Internal (aligned to Salesforce ETM RoleInTerritory2)", [("External Wholesaler","Field-based regional / territory wholesaler"),("Internal Wholesaler","Desk-based partner of the external"),("Hybrid Wholesaler","Covers in person and virtually"),("Regional Sales Manager","Manages externals / internals in a region"),("Divisional Sales Manager",""),("National Account Manager","Key account / home office relationship manager"),("Institutional Relationship Manager",""),("Consultant Relations Manager",""),("DCIO Specialist",""),("Product Specialist","Overlay specialist, e.g. ETF, alternatives, SMA/model"),("Country / Cluster Sales Manager","EU/UK"),("Global Account Manager","")]),
 "Assignment Type": ("Internal", [("Permanent",""),("Interim / Vacancy Cover",""),("Shadow / Trainee","No credit"),("Shared","Covers jointly with another salesperson")]),
 "Coverage Team Type": ("Internal", [("External-Internal Pair",""),("Regional Team",""),("National Account Team",""),("Institutional Coverage Team",""),("Pod","Multi-person team sharing a book")]),
 "Coverage Tier": ("Internal", [("A","Highest priority: top producers / highest potential"),("B",""),("C",""),("D","Virtual / internal-only coverage"),("Prospect","No production; targeted for acquisition"),("Not Covered","")]),
 "Frequency": ("Internal", [("Weekly",""),("Monthly",""),("Quarterly",""),("Semi-Annual",""),("Annual","")]),
 "Goal Setting Method": ("Internal", [("Top-Down","Allocated from division / region goal"),("Bottom-Up","Built from territory plans"),("Potential-Based","Allocated in proportion to territory potential"),("Historical Growth","Prior year plus growth factor"),("Hybrid","")]),
 "Goal Type": ("Internal", [("Gross Sales",""),("Net Sales",""),("AUM","End-of-period or average assets"),("Revenue","Management fee revenue on attributed assets"),("New Advisors","Count of first-time producing advisors"),("Focus Fund Sales","Product-specific goal; subject to remuneration conflict review"),("Activities","Meetings / calls (03 Sales activities)"),("Platform / Model Placements",""),("Institutional Funded Mandates","")]),
 "Goal Holder Type": ("Internal", [("Division",""),("Region",""),("Territory",""),("Coverage Team",""),("Salesperson","")]),
 "Goal Unit": ("Internal", [("Currency",""),("Count",""),("Percentage",""),("Basis Points","")]),
 "Goal Adjustment Reason": ("Internal", [("Realignment",""),("Vacancy",""),("Leave of Absence",""),("New Hire Ramp",""),("Market Event","Extraordinary market movement"),("Product Event","Fund closure, merger or soft close"),("Large Ticket Exclusion",""),("Data Correction","")]),
 "Attainment Method": ("Internal", [("Year-to-Date Cumulative",""),("Period Only",""),("Pro-Rated Goal","Goal pro-rated to period elapsed")]),
 "Credit Basis": ("Internal", [("Gross Sales",""),("Net Sales","Gross sales less redemptions"),("AUM","Average or end-of-period assets"),("Revenue","Management fee revenue"),("Net Revenue","Revenue after distribution costs"),("Funded Mandate","Institutional mandate funding amount"),("Commitments","Private markets capital commitments")]),
 "Credit Type": ("Internal (aligned to Xactly / ICM practice)", [("Direct","Full credit to the primary coverer"),("Shared / Split","Credit divided by split percentage, total 100%"),("Overlay / Double Credit","Full credit to an overlay role in addition to primary"),("Roll-up","Credit to managers via hierarchy"),("Transition / Holdover","Credit during realignment holdover"),("House","Credited to a house account; no payout")]),
 "Credit Trigger Event": ("Internal", [("Trade Date",""),("Settlement Date",""),("Funding Date","Institutional / private markets"),("Month-End AUM",""),("Average Daily AUM","")]),
 "Credit Exclusion Category": ("Internal", [("Money Market",""),("Internal Fund-of-Funds","Flows from in-house funds or mandates"),("Seed / Firm Capital",""),("Affiliated Accounts",""),("Closed Funds",""),("Dividend Reinvestment",""),("Intra-Family Exchange",""),("Large Ticket","Above firm-defined threshold; handled manually")]),
 "Exchange Credit Treatment": ("Internal", [("Net to Zero","No credit for exchanges within the fund family"),("Credit Exchange In","Exchange-in treated as a sale"),("Credit Across Tiers Only","Credit only where exchange moves to a higher comp tier")]),
 "Credit Status": ("Internal", [("Pending","Within holding period"),("Final",""),("Reversed",""),("On Hold","Under dispute or review")]),
 "Credit Adjustment Type": ("Internal", [("Manual Credit",""),("Manual Debit",""),("Clawback","Reversal for early redemption"),("Reversal","Trade cancel / correction"),("Reclassification","Moved to another salesperson or territory"),("Late Trade","Credit for a prior period")]),
 "Approval Status": ("Internal", [("Pending",""),("Approved",""),("Rejected",""),("Withdrawn","")]),
 "Plan Type": ("Internal", [("Commission Only",""),("Commission + Bonus",""),("Bonus Only","Discretionary or formula bonus"),("Target Incentive","Payout as % of target incentive by attainment"),("MBO Only",""),("Team Pool","")]),
 "Plan Status": ("Internal", [("Draft",""),("In Approval",""),("Approved",""),("Published",""),("Closed","")]),
 "Plan Component Type": ("Internal (aligned to Xactly / Spiff)", [("Commission","Rate x credited amount"),("Quota Bonus","Paid on goal attainment"),("Accelerator","Higher rate above a threshold"),("Decelerator","Lower rate below a threshold"),("Threshold","Minimum attainment before payout"),("Cap","Maximum payout"),("SPIF","Short-term incentive"),("MBO","Management-by-objectives payout"),("Team Pool",""),("Guarantee","Guaranteed minimum"),("Holdback / Deferral","")]),
 "Product Compensation Tier": ("Internal", [("Tier 1 - Strategic","Highest rate"),("Tier 2 - Core",""),("Tier 3 - Standard",""),("Tier 4 - Reduced","e.g. index ETFs"),("Excluded","No credit, e.g. money market")]),
 "Incentive Objective Type": ("Internal", [("New Advisors",""),("Platform / Model Placement",""),("Activity / Engagement",""),("Gross Sales - Firm-Wide","Total production across all products"),("Product-Specific Sales","Requires remuneration conflict review"),("Training / Certification",""),("Client Retention","")]),
 "Participant Eligibility Status": ("Internal", [("Eligible",""),("Eligible - Pro-Rated",""),("On Leave",""),("Terminated - Payout Eligible",""),("Terminated - Forfeited",""),("Ineligible","")]),
 "Period Status": ("Internal (aligned to Xactly)", [("Open",""),("Calculating",""),("Locked","No further changes; under review"),("Closed","Paid")]),
 "Draw Type": ("Internal", [("Recoverable","Offset against future earnings"),("Non-Recoverable","Guaranteed minimum")]),
 "Payout Adjustment Type": ("Internal", [("Guarantee Top-up",""),("Draw Recovery",""),("Manual Bonus",""),("Correction",""),("Clawback Recovery",""),("Holdback Release","")]),
 "Dispute Category": ("Internal", [("Missing Credit",""),("Wrong Split",""),("Wrong Territory / Alignment",""),("Rate Applied",""),("Goal Value",""),("Payment","")]),
 "Dispute Status": ("Internal", [("Open",""),("Under Review",""),("Resolved - Upheld",""),("Resolved - Rejected",""),("Withdrawn","")]),
 "Payment Status": ("Internal", [("Scheduled",""),("Sent to Payroll",""),("Paid",""),("Failed",""),("Cancelled","")]),
 "Approval Stage": ("Internal", [("Sales Leadership",""),("Sales Compensation Committee",""),("Finance",""),("HR / Reward",""),("Legal",""),("Compliance",""),("Remuneration Committee","")]),
 "Remuneration Regime": ("Internal", [("SEC Reg BI","Conflict obligation on sales contests and quotas"),("FINRA Rule 2341","Investment company securities: cash and non-cash compensation"),("FINRA Rule 3220","Gifts to employees of others"),("MiFID II Art 24(10) / ESMA35-43-3565","EU"),("UK FCA SYSC 19F","UK MiFID remuneration incentives"),("UK FCA SYSC 19E / ESMA UCITS Remuneration Guidelines","UCITS management companies"),("UK FCA SYSC 19B / AIFMD","AIFMs"),("UK FCA Consumer Duty","")]),
 "Assessment Outcome": ("Internal", [("No Conflict Identified",""),("Conflict Mitigated",""),("Change Required",""),("Rejected","")]),
 "Control Test Result": ("Internal", [("Effective",""),("Effective with Exceptions",""),("Ineffective",""),("Not Tested","")]),
 "Data Classification": ("Internal", [("Internal",""),("Confidential",""),("Confidential - Compensation","Restricted to participant, management and comp team"),("Restricted - Personal Data","")]),
 "Data Quality Status": ("Internal", [("Validated",""),("Pending Validation",""),("Exception",""),("Deprecated","")]),
}

# ---------------------------------------------------------------------------
# Relationships, sources
# ---------------------------------------------------------------------------
REL = [
 ("Territory Model","contains","Territory","1 : 1..n","One model per market and plan year is Active."),
 ("Territory (parent)","is parent of","Territory (child)","1 : 0..n","Division > region > territory > sub-territory, effective-dated."),
 ("Territory","is defined by","Territory Geographic Unit","1 : 0..n","Geographic and hybrid territories."),
 ("Territory","is scoped by","Territory Scope","1 : 0..1","Channel, segment, product and named firms."),
 ("Territory","is sized by","Territory Potential Metric","1 : 0..n","Per metric type and as-of date."),
 ("Alignment Rule","targets","Territory","n : 1",""),
 ("Alignment Rule / Exception","produces","Party Territory Alignment","1 : 0..n",""),
 ("Party Territory Alignment","aligns","Party (02 CC, PTY-)","n : 1","Firm, home office, branch, advisor, plan or consultant."),
 ("Realignment Event","changes","Party Territory Alignment","1 : 1..n","And triggers Transition Credit Rules and Goal Adjustments."),
 ("Territory","is covered by","Territory Salesperson Assignment","1 : 0..n","Vacant territories have none."),
 ("Territory Salesperson Assignment","assigns","Employee (03 Sales, EMP-)","n : 1",""),
 ("Territory Salesperson Assignment","requires","Licence (08 DC, LIC-)","n : 0..n","Registration must be active to cover and be credited."),
 ("Party Coverage Assignment","links","Party (02 CC, PTY-) to Employee (03 Sales, EMP-)","n : 1 / n : 1","Effective-dated; may also reference Account (02 CC, ACC-)."),
 ("Coverage Team","groups","Employee (03 Sales, EMP-)","1 : 1..n","Pairs and pods."),
 ("Goal","is held by","Territory / Coverage Team / Employee","n : 1",""),
 ("Goal (child)","is allocated from","Goal (parent)","n : 0..1","Cascade."),
 ("Goal","is measured on","Flow & AUM Measure (06 TX)","n : 1","Actuals arrive via Credit Allocations."),
 ("Goal","may be scoped to","Product (01, PRD-)","n : 0..n","Focus-fund goals; subject to remuneration conflict assessment."),
 ("Crediting Rule","produces","Credit Allocation","1 : 0..n",""),
 ("Credit Allocation","credits","Transaction (06 TX, TXN-) / Position (06 TX, POS-)","n : 1","Attribution to territory is done in 06; crediting to people is done here."),
 ("Credit Allocation","is credited to","Employee (03 Sales, EMP-) and Territory","n : 1",""),
 ("Credit Eligibility Criterion","includes / excludes","Product / Share Class (01, PRD-/SHC-)","n : n",""),
 ("Incentive Compensation Plan","has","Plan Component","1 : 1..n",""),
 ("Plan Component","uses","Rate Table Tier","1 : 0..n",""),
 ("Product Compensation Tier Mapping","maps","Product / Share Class (01, PRD-/SHC-)","n : 1",""),
 ("Plan Participant Assignment","assigns","Incentive Compensation Plan to Employee (03 Sales, EMP-)","n : 1",""),
 ("SPIF & MBO","is reviewed by","Compliance Review (08 DC, REV-)","n : 0..1","Non-cash awards follow 08 DC non-cash compensation rules (GNE-)."),
 ("Earnings Result","is calculated from","Credit Allocation and Goal Attainment","n : n",""),
 ("Compensation Statement","summarises","Earnings Result, Draw and Payout Adjustment","1 : 1..n",""),
 ("Compensation Statement","is paid via","Payroll Payment Instruction","1 : 0..n",""),
 ("Remuneration Conflict Assessment","assesses","Incentive Compensation Plan / Plan Component","n : 1",""),
 ("Change Audit Record","records changes to","Any CT record","n : 1",""),
]

SRC = [
 ("Salesforce Enterprise Territory Management (Territory2, Territory2Model, Territory2Type, ObjectTerritory2Association, UserTerritory2Association, ObjectTerritory2AssignmentRule)","Salesforce","https://developer.salesforce.com/docs/atlas.en-us.object_reference.meta/object_reference/sforce_api_objects_territory2.htm","Vendor documentation (public)","CRM territory model: model states, territory types and priority, hierarchy, assignment rules with Boolean filters, association cause, user role in territory, access levels","Territory Structure, Alignment Rules, Salesperson Territory Assignment",["Salesforce ETM"]),
 ("Salesforce Financial Services Cloud","Salesforce","https://developer.salesforce.com/docs/atlas.en-us.financial_services_cloud_object_reference.meta/financial_services_cloud_object_reference/","Vendor documentation (public)","Financial services CRM objects for advisors, households and relationships","Party Coverage Assignment (cross-check)",[]),
 ("Xactly Incent Administrator Help Center","Xactly","https://helpcenter.xactlycorp.com/","Vendor documentation (partly login)","ICM concepts: plans, rules, credits and credit types, quotas, rate tables, periods, titles/positions","Goals, Crediting, Plan Components, Rate Tables, Periods",["Xactly"]),
 ("Salesforce Spiff (Trailhead: statements, rules, data filters)","Salesforce","https://trailhead.salesforce.com/content/learn/modules/statements-for-salesforce-spiff-admins","Vendor training (public)","Commission plans, line-by-line rules, statements, adjustments","Plan Components, Statements, Disputes, Credit Adjustments",["Salesforce Spiff"]),
 ("Varicent ICM","Varicent","https://www.varicent.com","Vendor (proprietary)","ICM and territory/quota planning","Optional cross-check during implementation; not used as primary source",[]),
 ("ISO 3166-1 / ISO 3166-2 country and subdivision codes","ISO","https://www.iso.org/iso-3166-country-codes.html","Standard; codes via ISO Online Browsing Platform","Country and country-subdivision codes","Geographic Definition, Sales Cluster",["ISO 3166*"]),
 ("ISO 4217 / ISO 8601","ISO","https://www.iso.org","Standard; code lists widely available","Currency and date/time formats","Date, timestamp and currency formats used throughout",[]),
 ("US Census Bureau ZIP Code Tabulation Areas (ZCTA) and FIPS codes","US Census Bureau","https://www.census.gov/programs-surveys/geography/guidance/geo-areas/zctas.html","Public domain","ZCTA definitions (approximations of USPS ZIP areas), county FIPS codes, TIGER/Line boundaries","Geographic Definition (US)",["US Census*"]),
 ("OMB Bulletin 23-01: Core Based Statistical Areas","US Office of Management and Budget","https://www.whitehouse.gov/wp-content/uploads/2023/07/OMB-Bulletin-23-01.pdf","Public domain","Metropolitan / micropolitan statistical area (CBSA) delineations","CBSA Code, Geography Reference Version",["OMB CBSA"]),
 ("Eurostat NUTS classification (NUTS 2024)","Eurostat / European Union","https://ec.europa.eu/eurostat/web/nuts","Open (EU regulation 1059/2003 as amended)","EU regional codes at NUTS 1-3","NUTS Code (EU territories)",["Eurostat NUTS"]),
 ("ONS National Statistics Postcode Lookup (NSPL)","UK Office for National Statistics","https://geoportal.statistics.gov.uk","Open Government Licence","UK postcodes to statutory geographies; postcode area / district","UK Postcode District",["ONS NSPL"]),
 ("SEC Regulation Best Interest, 17 CFR 240.15l-1(a)(2)(iii)(D)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-240/subject-group-ECFR64f52d737aea1ed/section-240.15l-1","Regulation","Requirement to identify and eliminate sales contests, quotas, bonuses and non-cash compensation based on specific securities within a limited period","Product-Specific Incentive Indicator, Remuneration Conflict Assessment",["SEC Reg BI"]),
 ("FINRA Rule 2341 (Investment Company Securities)","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2341","Rule","Cash and non-cash compensation and sales contests in connection with sale of investment company securities","SPIF & MBO, Remuneration Regime (reference only; rules owned by 08 DC)",["FINRA Rule 2341"]),
 ("FINRA Rule 3220 and Regulatory Notice 26-05","FINRA","https://www.finra.org/rules-guidance/notices/26-05","Rule","Gifts to employees of others; limit raised from USD 100 to USD 300 effective 2026-03-30 with conforming change to Rule 2341","Non-Cash Award Indicator (reference only; owned by 08 DC)",["FINRA Rule 3220"]),
 ("FINRA Rule 1210 (Registration Requirements)","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/1210","Rule","Registration of associated persons","Required Licence Reference (licences owned by 08 DC)",["FINRA Rule 1210"]),
 ("ESMA Guidelines on certain aspects of the MiFID II remuneration requirements (ESMA35-43-3565)","ESMA","https://www.esma.europa.eu/node/200606","Guidelines (apply from Oct 2023)","Remuneration policies for relevant persons; qualitative criteria; conflict management","Qualitative Criteria, Relevant Person Indicator, Remuneration Regime",["ESMA MiFID Remuneration Guidelines"]),
 ("ESMA Guidelines on sound remuneration policies under the UCITS Directive (ESMA/2016/575) and AIFMD equivalent","ESMA","https://handbook.fca.org.uk/L3G/UCITS/2016-575_ucits_remuneration_guidelines.pdf","Guidelines","Identified staff and remuneration policy for management companies","Identified Staff Indicator",["ESMA UCITS Remuneration Guidelines"]),
 ("UK FCA SYSC 19F (MiFID remuneration incentives), SYSC 19E (UCITS Remuneration Code), SYSC 19B (AIFM Remuneration Code)","UK FCA","https://www.handbook.fca.org.uk/handbook/SYSC/19F/","Regulation","Sales staff remuneration and performance management; note SYSC 19F excludes collective portfolio management investment firms, which fall under 19E / 19B","Remuneration Conflict Assessment",["UK FCA*"]),
 ("MiFID II Directive 2014/65/EU Art. 24(10) and Delegated Regulation (EU) 2017/565 Art. 27","European Union","https://eur-lex.europa.eu","Regulation","Remuneration of staff providing services to clients","Remuneration Regime",["MiFID II"]),
 ("Sarbanes-Oxley Act s.404 (ICFR) and COSO Internal Control - Integrated Framework (2013)","US Congress / SEC; COSO","https://www.coso.org","Law; framework","Internal control over financial reporting; control types and testing","Controls & Audit Trail, Approvals",["SOX","COSO"]),
 ("FASB ASC 710 (Compensation - General) / IAS 19 (Employee Benefits)","FASB; IFRS Foundation","https://asc.fasb.org","Standard (FASB codification subscription)","Accrual of compensation expense","Finance Accruals",["ASC 710"]),
 ("GDPR and US state privacy laws","European Union; US states","https://eur-lex.europa.eu/eli/reg/2016/679/oj","Regulation","Personal data handling for employee compensation records","Data Classification, PII flags (secondary reference)",[]),
 ("DCAM","EDM Council","https://edmcouncil.org","Member framework","Data management capability: ownership and stewardship","Data Management Metadata",["DCAM*"]),
]
