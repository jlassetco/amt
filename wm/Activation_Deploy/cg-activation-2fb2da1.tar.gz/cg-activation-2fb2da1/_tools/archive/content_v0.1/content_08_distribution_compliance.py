"""Business domain 08 - Distribution Compliance. Content module for taxonomy_builder.py."""

META = {
 "title": "Distribution Compliance Data Taxonomy",
 "subtitle": "Business domain 08 - Distribution Compliance | Asset manager (wholesale distributor) | Scope: US + EU/UK | Draft v0.1 | 2026-10-01",
 "output": "08_Distribution_Compliance/Distribution_Compliance_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the distribution compliance data of an asset manager that sells wholesale through intermediaries and to institutions. It covers the records that the affiliated FINRA broker-dealer (principal underwriter), the SEC-registered advisers and the EU/UK ManCo/AIFM and FCA-authorised firms need to evidence compliant marketing and sales. It draws on FINRA rules (2210, 2341, 3110, 3220, 4530, 1220/1240), SEC rules (Marketing Rule 206(4)-1, 17a-4, 204-2, Reg BI, 22c-2, Reg D), UK FCA rules (COBS 4, COBS 2.3A, s21 FSMA, ESG 4.3 anti-greenwashing rule, PRIN 2A Consumer Duty, DISP, SM&CR) and EU rules (Regulation (EU) 2019/1156 with the ESMA marketing communications guidelines, AIFMD pre-marketing under Directive (EU) 2019/1160, MiFID II product governance and inducements), together with FinDatEx feedback templates. Use it as a starting point for a compliance data model, a data catalogue or a business glossary."),
  ("Scope", "In scope: compliance review, approval and regulatory filing of marketing communications; distributor due diligence (know-your-distributor); product governance and Consumer Duty feedback exchanged with distributors; gifts, entertainment, non-cash compensation and inducements; licences and registrations of sales personnel; cross-border marketing and pre-marketing notifications, reverse solicitation and private placement compliance; complaints; communications capture, retention and surveillance; sales-practice monitoring and the distribution conflicts register; the regulatory obligations register and attestations. Out of scope (referenced by ID only): product master, share classes, target market and registration-for-sale status (01 Product, PRD-/SHC-); party master for distributor firms, advisers, investors and their identifiers such as CRD, LEI and FRN (02 Client & Customer, PTY-/ACC-); employee and sales-personnel master, and RFP/DDQ responses the firm gives to clients (03 Sales, EMP-/RFP-); marketing content assets, campaigns and events, including asset versioning and content expiry (04 Marketing & Digital, AST-/CAM-/EVT-); selling, platform, revenue-sharing and sponsorship agreements and their payment terms (05 Distribution Agreements & Partners, AGR-); transactions, positions and data feeds (06 Sales Transactions & AUM Attribution, TXN-/POS-/FEED-); compensation, crediting and territories (07 Compensation & Territory). Also out of scope: firm-wide AML/KYC of end investors (02), personal account dealing and the code of ethics beyond distribution, and enterprise records management outside distribution."),
  ("Structure", "Four levels: Domain > Subdomain > Concept > Attribute. The Hierarchy tab shows the first three levels with definitions. The Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard. Attribute IDs take the form DC-xxx-nnn."),
  ("Core model", "Five compliance masters, each keyed by a shared ID prefix: Compliance Review (REV-), Distributor Due Diligence (DDQ-), Gift / Entertainment (GNE-), Complaint (CPL-) and Licence / Registration (LIC-). Each master links to entities owned by other business domains rather than copying them. A review approves a content asset (AST-) used in a campaign (CAM-) for products (PRD-/SHC-). A due-diligence case assesses a distributor firm (PTY-) under an agreement (AGR-). A gift is given by an employee (EMP-) to a recipient (PTY-). A licence is held by an employee (EMP-). A complaint concerns a product, distributor, account (ACC-) or transaction (TXN-). Supporting records (notifications, alerts, conflicts, obligations, attestations) carry their own IDs and point to the masters."),
  ("Design principles", "1) Evidence first: every record carries who decided what, when and on what basis (reviewer, approver, timestamps, rule cited), because these records must be produced to FINRA, SEC, FCA and EU regulators. 2) Classify each record against every regime that applies. One communication can be a FINRA retail communication, a Marketing Rule advertisement and an FCA financial promotion at the same time, so each regime has its own attribute. 3) Reference, don't redefine: assets, parties, employees, products and agreements are held by ID only. 4) Effective-date statuses, approvals, registrations and certifications, and store expiry and next-review dates explicitly. 5) Use controlled code lists aligned to regulator taxonomies where they exist (FINRA 4530 product and problem codes, FCA complaints return categories, FINRA registration categories). 6) Flag personal data (PII). Disclosure events and vulnerability markers may be special-category or criminal-offence data under UK/EU GDPR (Art. 9/10). 7) Name clash: in this workbook, DDQ- means due diligence that the firm performs on its distributors. RFP/DDQ responses that the firm gives to clients are owned by 03 Sales (RFP-)."),
  ("Applies To", "Shows the record type each attribute belongs to, e.g. Review, Filing, DD Case, Feedback Report, G&E Item, Licence, Notification, Complaint, Comms Record, Alert, Conflict, Obligation, Attestation or All."),
  ("CDE", "Y = proposed Critical Data Element: needed to evidence a regulatory decision or deadline, to report to a regulator, or to link a compliance record to its subject. Confirm with the CCO, the FINRA principal(s) and data owners."),
  ("Primary / Secondary Reference", "The rule, regulation, guideline or template the attribute is aligned to (e.g. 'FINRA Rule 2210', 'SEC Marketing Rule', 'FCA COBS 4', 'EU CBDF Regulation', 'FinDatEx EFT'). 'Internal' means the attribute is firm-defined and has no authoritative external definition. Rule citations are given at rule level. Next step: have Compliance map each attribute to the exact paragraph."),
  ("Tabs", "Hierarchy: domains, subdomains and concepts with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: concept-level cardinalities, including cross-domain references | Sources: rules, guidelines and templates used, with owners and links."),
  ("Suggested next steps", "1) Validate the domains, CDEs and code lists with Compliance (US BD/RIA and EU/UK), Legal, Marketing Operations and Distribution Operations. 2) Map attributes to source systems: the advertising review workflow tool, FINRA Gateway/AREF, CRD/registration tracking, the G&E system, the complaints system, the archiving and surveillance platform, and the distributor oversight tool. 3) Confirm the boundaries with 03 Sales (EMP- master and CRD number), 04 Marketing (asset expiry vs approval expiry) and 05 Agreements (sponsorship and revenue-share payments vs inducement assessment). 4) Load the FINRA 4530 product/problem codes and the FCA consolidated complaints return categories (PS25/19, first period from 1 January 2027) in full. 5) Agree data owners and stewards per subdomain. 6) Turn the Relationships tab into a logical data model."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Communications Review & Approval", "DC-REV",
  "Compliance review, principal approval and regulatory filing of marketing and other communications with distributors, institutions and the public, under FINRA, SEC, FCA and EU rules.",
  [
   ("Review Request", "Submission of a communication for compliance review, and its link to the marketing asset and campaign.", [
     ("Compliance Review", [
       ("Review ID", "Unique identifier of the compliance review record (REV master).", "Review", "Identifier", "", "REV-2026-004518", "Internal", "", "Y"),
       ("Communication Asset", "Marketing content asset (and version) being reviewed. The asset is defined in 04 Marketing & Digital.", "Review", "Reference (Content Asset)", "", "AST-118204 v3", "Internal", "FINRA Rule 2210", "Y"),
       ("Campaign", "Marketing campaign in which the communication will be used, if any.", "Review", "Reference (Campaign)", "", "CAM-2026-031", "Internal", "", ""),
       ("Submitted By", "Employee who submitted the communication for review.", "Review", "Reference (Employee)", "", "EMP-20417", "Internal", "", "", "PII"),
       ("Submission Timestamp", "Date and time the communication was submitted for review.", "Review", "Timestamp", "ISO 8601", "2026-09-14T10:22:00-04:00", "Internal", "", ""),
       ("Review Type", "Nature of the review request.", "Review", "Code", "Review Type", "New Communication", "Internal", "", ""),
       ("Products Featured", "Products or share classes promoted or mentioned in the communication.", "Review", "Reference (Product / Share Class) (multi)", "", "PRD-00981; SHC-004512", "Internal", "FINRA Rule 2210", "Y"),
       ("Jurisdictions of Use", "Countries in which the communication will be distributed.", "Review", "Code (multi)", "ISO 3166-1 alpha-2", "US", "EU CBDF Regulation", "FCA COBS 4", "Y"),
       ("Intended Audience", "Audience the communication is designed for.", "Review", "Code (multi)", "Audience Category", "Financial Professional", "FINRA Rule 2210", "MiFID II", ""),
     ]),
   ]),
   ("Regulatory Classification", "Classification of the communication under each regime that applies. One communication can fall under several regimes at once.", [
     ("US Communication Classification", [
       ("FINRA Communication Category", "Category of communication under FINRA Rule 2210(a): retail communication, institutional communication or correspondence.", "Review", "Code", "FINRA Communication Category", "Retail Communication", "FINRA Rule 2210", "", "Y"),
       ("Financial Professional Use Only Indicator", "Whether the material is restricted to financial professionals and must not be passed on to retail investors.", "Review", "Boolean", "", "Y", "FINRA Rule 2210", "", ""),
       ("Investment Company Communication Type", "Securities Act / Investment Company Act basis for a fund communication (Rule 482 advertisement or Rule 34b-1 supplemental sales literature).", "Review", "Code", "Investment Company Communication Type", "Rule 482 Advertisement", "SEC Rule 482", "FINRA Rule 2210", ""),
       ("Marketing Rule Advertisement Indicator", "Whether the communication is an adviser advertisement under SEC Rule 206(4)-1(e)(1).", "Review", "Boolean", "", "Y", "SEC Marketing Rule", "", "Y"),
       ("Marketing Rule Advertisement Type", "Branch of the Marketing Rule advertisement definition that applies, or the exclusion relied on.", "Review", "Code", "Marketing Rule Advertisement Type", "One-to-Many Advertisement", "SEC Marketing Rule", "", ""),
       ("Testimonial / Endorsement Indicator", "Whether the communication contains a testimonial or endorsement.", "Review", "Boolean", "", "N", "SEC Marketing Rule", "SEC Form ADV", ""),
       ("Third-Party Rating Indicator", "Whether the communication includes a third-party rating, ranking or award.", "Review", "Boolean", "", "Y", "SEC Marketing Rule", "FINRA Rule 2212", ""),
     ]),
     ("EU / UK Communication Classification", [
       ("FCA Financial Promotion Indicator", "Whether the communication is a financial promotion (an invitation or inducement to engage in investment activity) under s21 FSMA.", "Review", "Boolean", "", "Y", "FCA FSMA s21", "FCA COBS 4", "Y"),
       ("Financial Promotion Type", "Form of the financial promotion under COBS 4.", "Review", "Code", "Financial Promotion Type", "Non-Real-Time", "FCA COBS 4", "", ""),
       ("FPO Exemption Relied On", "Financial Promotion Order exemption or COBS 4 basis relied on, where the communication is not approved for retail use.", "Review", "Code", "FPO Exemption", "Art 19 Investment Professionals", "FCA FSMA s21", "", ""),
       ("s21 Approval For Unauthorised Person Indicator", "Whether the firm is approving the promotion for an unauthorised person. This requires the s21 approver permission (FCA gateway, from 7 Feb 2024).", "Review", "Boolean", "", "N", "FCA FSMA s21", "FCA PS23/13", ""),
       ("ESMA Marketing Communication Indicator", "Whether the communication is a marketing communication on a UCITS or AIF under Art 4 of Regulation (EU) 2019/1156.", "Review", "Boolean", "", "Y", "EU CBDF Regulation", "ESMA Marketing Guidelines", "Y"),
       ("MiFID Client Category Targeted", "MiFID II client category the communication is addressed to.", "Review", "Code", "MiFID Client Category", "Professional Client", "MiFID II", "FCA COBS 4", ""),
       ("Sustainability Claims Indicator", "Whether the communication refers to sustainability characteristics. If so, the anti-greenwashing rule and ESMA sustainability guidance apply.", "Review", "Boolean", "", "Y", "FCA ESG 4.3", "ESMA Marketing Guidelines", ""),
     ]),
   ]),
   ("Content Characteristics", "Content features that trigger specific rules: performance, ratings and required disclosures.", [
     ("Performance Presentation", [
       ("Performance Shown Indicator", "Whether the communication presents investment performance.", "Review", "Boolean", "", "Y", "SEC Marketing Rule", "FINRA Rule 2210", ""),
       ("Performance Type", "Type(s) of performance presented.", "Review", "Code (multi)", "Performance Type", "Actual - Fund; Extracted", "SEC Marketing Rule", "ESMA Marketing Guidelines", "Y"),
       ("Gross / Net Presentation", "Whether performance is shown net, gross and net, or gross only (extracted, with a full gross and net portfolio overview per SEC staff FAQ of 19 March 2025).", "Review", "Code", "Gross Net Presentation", "Gross and Net", "SEC Marketing Rule", "", ""),
       ("Performance As-Of Date", "Date as of which the performance shown is calculated.", "Review", "Date", "ISO 8601", "2026-06-30", "SEC Rule 482", "FINRA Rule 2210", ""),
       ("Rating / Ranking Source", "Provider of any rating, ranking or award shown.", "Review", "Reference (Party)", "", "PTY-7710 (Morningstar)", "FINRA Rule 2212", "SEC Marketing Rule", ""),
     ]),
     ("Required Disclosures", [
       ("Disclosure Set Applied", "Standard disclosure block(s) inserted in the communication from the firm's disclosure library.", "Review", "Code (multi)", "Disclosure Set (firm-defined)", "US-MF-PERF-01; US-RISK-EQ-02", "Internal", "FINRA Rule 2210", ""),
       ("Risks and Rewards Equally Prominent Check", "Reviewer confirmation that risks are described as prominently as rewards.", "Review", "Boolean", "", "Y", "EU CBDF Regulation", "FCA COBS 4", ""),
       ("Offering Document Reference Included", "Whether the communication refers to the prospectus / KID / summary prospectus and where to obtain it.", "Review", "Boolean", "", "Y", "EU CBDF Regulation", "SEC Rule 482", ""),
     ]),
   ]),
   ("Review Workflow", "Workflow steps and reviewers that lead to the approval decision.", [
     ("Review Step", [
       ("Review Step Sequence", "Order of the step within the review workflow.", "Review Step", "Integer", "", "2", "Internal", "", ""),
       ("Reviewer", "Employee assigned to the step.", "Review Step", "Reference (Employee)", "", "EMP-10233", "FINRA Rule 3110", "", "", "PII"),
       ("Reviewer Role", "Function the reviewer represents.", "Review Step", "Code", "Reviewer Role", "Compliance - Advertising", "Internal", "", ""),
       ("Step Completed Timestamp", "Date and time the step was completed.", "Review Step", "Timestamp", "ISO 8601", "2026-09-16T15:40:00-04:00", "Internal", "", ""),
     ]),
   ]),
   ("Approval & Use Conditions", "Approval decision, approving principal, conditions of use, expiry and withdrawal.", [
     ("Compliance Approval", [
       ("Approval Status", "Outcome of the compliance review.", "Review", "Code", "Approval Status", "Approved with Conditions", "FINRA Rule 2210", "", "Y"),
       ("Approval Decision Date", "Date the approval decision was made. For retail communications this must be before the earlier of first use or filing.", "Review", "Date", "ISO 8601", "2026-09-18", "FINRA Rule 2210", "SEC Marketing Rule", "Y"),
       ("Approving Principal", "Appropriately qualified registered principal who approved the communication. The name must be retained with the communication.", "Review", "Reference (Employee)", "", "EMP-10011", "FINRA Rule 2210", "", "Y", "PII"),
       ("Approving Principal Licence", "Registration under which the principal approved (e.g. Series 24 or 26).", "Review", "Reference (Licence)", "", "LIC-000731", "FINRA Rule 2210", "FINRA Rule 1220", ""),
       ("Compliance Approval Code", "Unique approval reference printed on the communication for traceability.", "Review", "Identifier", "", "CR-2026-0918-4518", "Internal", "", ""),
       ("Approval Conditions", "Conditions attached to the approval (audience, channel, update triggers).", "Review", "Text", "", "Use only with performance updated quarterly; not for use in Germany.", "Internal", "", ""),
       ("Approval Expiry Date", "Date after which the communication must not be used without re-approval. This is distinct from asset expiry held in 04 Marketing.", "Review", "Date", "ISO 8601", "2026-12-31", "Internal", "", "Y"),
       ("Re-certification Frequency", "Frequency at which evergreen communications must be re-reviewed.", "Review", "Code", "Frequency", "Annual", "Internal", "", ""),
       ("Withdrawal Date", "Date the approval was withdrawn and the communication removed from use.", "Review", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Regulatory Filing", "Filing of communications with FINRA Advertising Regulation and other regulators, and their responses.", [
     ("FINRA Advertising Filing", [
       ("FINRA Filing Requirement", "Filing obligation that applies to the communication under FINRA Rule 2210(c).", "Filing", "Code", "FINRA Filing Requirement", "Post-Use - Within 10 Business Days", "FINRA Rule 2210", "", "Y"),
       ("FINRA Filing Reference", "Reference number assigned by FINRA Advertising Regulation (AREF) on submission.", "Filing", "Identifier", "", "2026-0915-123456", "FINRA Rule 2210", "", ""),
       ("Filed Date", "Date the communication was filed with FINRA.", "Filing", "Date", "ISO 8601", "2026-10-07", "FINRA Rule 2210", "", "Y"),
       ("First Use Date", "Date the communication was first used or published. The post-use filing deadline runs from this date.", "Filing", "Date", "ISO 8601", "2026-10-05", "FINRA Rule 2210", "", "Y"),
       ("Filing Due Date", "Date by which the filing must be made (derived from the requirement and first-use date).", "Filing", "Date", "ISO 8601", "2026-10-19", "FINRA Rule 2210", "", ""),
       ("FINRA Review Outcome", "Conclusion stated in the FINRA review letter.", "Filing", "Code", "FINRA Review Outcome", "May Be Consistent If Changes Made", "FINRA Rule 2210", "", ""),
       ("FINRA Comments Summary", "Summary of the comments in the FINRA review letter.", "Filing", "Text", "", "Balance YTD return with standardised returns; clarify rating methodology.", "FINRA Rule 2210", "", ""),
     ]),
     ("Other Regulator Filing", [
       ("Regulator", "Regulator with which the communication was filed or notified (e.g. an EU NCA requiring ex-ante filing).", "Filing", "Reference (Party)", "", "PTY-9020 (BaFin)", "EU CBDF Regulation", "", ""),
       ("Regulator Filing Type", "Type of non-FINRA submission.", "Filing", "Code", "Regulator Filing Type", "Ex-Ante Notification", "EU CBDF Regulation", "", ""),
       ("Regulator Submission Date", "Date of submission to the regulator.", "Filing", "Date", "ISO 8601", "2026-09-20", "EU CBDF Regulation", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Distributor Due Diligence", "DC-KYD",
  "Initial, periodic and event-driven due diligence on intermediaries that distribute the firm's products (know-your-distributor), including risk rating, screening, regulatory status checks, questionnaires, findings and remediation.",
  [
   ("Due Diligence Case", "One due diligence assessment of one distributor firm (DDQ master).", [
     ("Distributor Due Diligence", [
       ("Due Diligence ID", "Unique identifier of the due diligence case.", "DD Case", "Identifier", "", "DDQ-2026-00312", "Internal", "", "Y"),
       ("Distributor Firm", "Distributor firm under review. Firm details and identifiers (CRD, LEI, FRN) live in the 02 party master.", "DD Case", "Reference (Party)", "", "PTY-3301", "Internal", "ESMA Product Governance Guidelines", "Y"),
       ("Governing Agreement", "Distribution agreement under which the distributor operates.", "DD Case", "Reference (Agreement)", "", "AGR-00788", "Internal", "", ""),
       ("Due Diligence Review Type", "Trigger for the due diligence.", "DD Case", "Code", "DD Review Type", "Periodic", "Internal", "", ""),
       ("Distributor Role", "Role the intermediary plays in the distribution chain.", "DD Case", "Code", "Distributor Role", "Platform / Nominee", "Internal", "FCA PRIN 2A", ""),
       ("Case Status", "Current status of the case.", "DD Case", "Code", "DD Case Status", "In Review", "Internal", "", ""),
       ("Due Diligence Completed Date", "Date the due diligence was completed and signed off.", "DD Case", "Date", "ISO 8601", "2026-08-15", "Internal", "", "Y"),
       ("Next Review Due Date", "Date the next periodic review is due, based on the risk rating.", "DD Case", "Date", "ISO 8601", "2027-08-15", "Internal", "", "Y"),
     ]),
   ]),
   ("Risk Assessment", "Risk rating of the distributor, which drives the depth and frequency of oversight.", [
     ("Distributor Risk Rating", [
       ("Inherent Risk Rating", "Risk rating before controls, based on jurisdiction, distributor type, client base and products distributed.", "DD Case", "Code", "Risk Rating", "Medium", "Internal", "FATF", ""),
       ("Residual Risk Rating", "Risk rating after considering the distributor's controls and the due diligence findings.", "DD Case", "Code", "Risk Rating", "Low", "Internal", "", "Y"),
     ]),
   ]),
   ("Screening & Regulatory Status", "AML/sanctions screening of the distributor firm and verification of its regulatory status.", [
     ("Screening Result", [
       ("Screening Type", "Type of screening performed on the distributor firm and its key principals.", "DD Case", "Code", "Screening Type", "Sanctions", "OFAC", "UK MLR 2017", ""),
       ("Screening Date", "Date screening was performed.", "DD Case", "Date", "ISO 8601", "2026-07-03", "Internal", "", ""),
       ("Screening Result", "Result of the screening.", "DD Case", "Code", "Screening Result", "No Match", "Internal", "", "Y"),
     ]),
     ("Regulatory Status Check", [
       ("Register Checked", "Public register used to verify the distributor's authorisation.", "DD Case", "Code", "Regulatory Register", "FCA Financial Services Register", "Internal", "", ""),
       ("Authorisation Verified Indicator", "Whether the distributor's authorisation for the activities it performs was verified.", "DD Case", "Boolean", "", "Y", "Internal", "MiFID II", "Y"),
       ("Disciplinary History Indicator", "Whether the register or BrokerCheck shows disciplinary or regulatory events.", "DD Case", "Boolean", "", "N", "Internal", "", ""),
     ]),
   ]),
   ("Questionnaire & Findings", "Due diligence questionnaire, findings, remediation and the overall outcome.", [
     ("Questionnaire Response", [
       ("Questionnaire Template", "Questionnaire template issued to the distributor.", "DD Case", "Code", "Questionnaire Template (firm-defined)", "KYD Platform Questionnaire v2026", "Internal", "", ""),
       ("Questionnaire Received Date", "Date the completed questionnaire was received.", "DD Case", "Date", "ISO 8601", "2026-07-24", "Internal", "", ""),
     ]),
     ("Due Diligence Finding", [
       ("Finding Category", "Area the finding relates to.", "Finding", "Code", "DD Finding Category", "Target Market Controls", "Internal", "", ""),
       ("Finding Severity", "Severity of the finding.", "Finding", "Code", "Severity", "Medium", "Internal", "", ""),
       ("Finding Description", "Description of the finding.", "Finding", "Text", "", "No documented process to report sales outside target market to manufacturers.", "Internal", "", ""),
       ("Remediation Action", "Action agreed with the distributor.", "Finding", "Text", "", "Distributor to provide EFT feedback semi-annually.", "Internal", "", ""),
       ("Remediation Status", "Status of the remediation.", "Finding", "Code", "Remediation Status", "Open", "Internal", "", ""),
     ]),
     ("Due Diligence Outcome", [
       ("Due Diligence Outcome", "Overall decision on the relationship.", "DD Case", "Code", "DD Outcome", "Approved with Conditions", "Internal", "", "Y"),
       ("Outcome Conditions", "Conditions or restrictions imposed (e.g. products or investor types excluded).", "DD Case", "Text", "", "Not approved to distribute complex AIF share classes to retail clients.", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Product Governance & Distributor Feedback", "DC-PGF",
  "Information exchanged with distributors under MiFID II / UK PROD product governance and the UK Consumer Duty. It covers distributor feedback on sales against the target market and outcomes data shared along the distribution chain. The target market itself is owned by 01 Product.",
  [
   ("Target Market Feedback", "Periodic feedback from distributors on how products were distributed against the manufacturer's target market.", [
     ("Distributor Feedback Report", [
       ("Feedback Report ID", "Unique identifier of the feedback report received.", "Feedback Report", "Identifier", "", "FBK-2026-H1-0441", "Internal", "", ""),
       ("Reporting Distributor", "Distributor that provided the feedback.", "Feedback Report", "Reference (Party)", "", "PTY-3301", "FinDatEx EFT", "", "Y"),
       ("Reporting Period Start", "First day of the period covered.", "Feedback Report", "Date", "ISO 8601", "2026-01-01", "FinDatEx EFT", "", ""),
       ("Reporting Period End", "Last day of the period covered.", "Feedback Report", "Date", "ISO 8601", "2026-06-30", "FinDatEx EFT", "", "Y"),
       ("Feedback Template", "Template used for the feedback.", "Feedback Report", "Code", "Feedback Template", "FinDatEx EFT", "FinDatEx EFT", "", ""),
       ("Source Data Feed", "Data feed through which the report was received, if automated.", "Feedback Report", "Reference (Data Feed)", "", "FEED-0091", "Internal", "", ""),
     ]),
     ("Sales Against Target Market", [
       ("Share Class", "Share class the feedback line relates to.", "Feedback Line", "Reference (Share Class)", "", "SHC-004512", "FinDatEx EFT", "", "Y"),
       ("Distribution Strategy", "Distribution service through which the sales were made.", "Feedback Line", "Code", "Distribution Strategy", "Investment Advice", "FinDatEx EFT", "ESMA Product Governance Guidelines", ""),
       ("Sales Outside Target Market Indicator", "Whether any sales occurred outside the positive target market.", "Feedback Line", "Boolean", "", "Y", "ESMA Product Governance Guidelines", "FinDatEx EFT", "Y"),
       ("Sales in Negative Target Market Indicator", "Whether any sales occurred in the negative target market.", "Feedback Line", "Boolean", "", "N", "ESMA Product Governance Guidelines", "FinDatEx EFT", "Y"),
       ("Volume Outside Target Market", "Value of sales made outside the target market in the period.", "Feedback Line", "Amount", "", "EUR 420,000", "FinDatEx EFT", "", ""),
       ("Target Market Deviation Reason", "Reason given for sales outside the target market.", "Feedback Line", "Code", "Target Market Deviation Reason", "Portfolio Diversification", "ESMA Product Governance Guidelines", "FinDatEx EFT", ""),
       ("Distributor Complaints Count", "Number of complaints the distributor received about the product in the period.", "Feedback Line", "Integer", "", "1", "Internal", "FCA PRIN 2A", ""),
     ]),
   ]),
   ("Consumer Duty Information Sharing", "Information shared along the distribution chain to support the Consumer Duty outcomes and fair value assessments.", [
     ("Distribution Chain Information Exchange", [
       ("Exchange Direction", "Whether information went from manufacturer to distributor or the other way.", "Exchange", "Code", "Exchange Direction", "Manufacturer to Distributor", "FCA PRIN 2A", "", ""),
       ("Counterparty", "Distributor or co-manufacturer in the exchange.", "Exchange", "Reference (Party)", "", "PTY-3301", "FCA PRIN 2A", "", ""),
       ("Information Type", "Type of information shared.", "Exchange", "Code", "Consumer Duty Information Type", "Fair Value Assessment Summary", "FCA PRIN 2A", "FCA PROD 3", ""),
       ("Delivery Method", "How the information was delivered.", "Exchange", "Code", "Delivery Method", "EMT Data Feed", "Internal", "FinDatEx EMT", ""),
       ("Outcome Concern Raised Indicator", "Whether the exchange raised a concern about consumer outcomes that needs follow-up.", "Exchange", "Boolean", "", "N", "FCA PRIN 2A", "", ""),
     ]),
   ]),
   ("Product Review Input", "Distribution findings fed into the manufacturer's periodic product review.", [
     ("Distribution Review Finding", [
       ("Product Review Cycle", "Product review to which the finding is submitted. The review is owned by 01 Product governance.", "Review Finding", "Text", "", "PR-2026 Annual - PRD-00981", "ESMA Product Governance Guidelines", "FCA PROD 3", ""),
       ("Distribution Issue Identified", "Issue identified from distributor feedback, complaints or monitoring.", "Review Finding", "Text", "", "Persistent execution-only sales to investors with basic knowledge.", "ESMA Product Governance Guidelines", "", ""),
       ("Recommended Action", "Action proposed to the product governance committee.", "Review Finding", "Code", "Product Governance Action", "Restrict Distribution Strategy", "ESMA Product Governance Guidelines", "FCA PROD 3", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Gifts, Entertainment & Inducements", "DC-GNE",
  "Gifts, business entertainment and non-cash compensation given to or received from intermediaries and clients, training and education meetings, and the EU/UK inducements assessment of benefits.",
  [
   ("Gift & Entertainment Record", "One gift, entertainment or other benefit given or received (GNE master).", [
     ("Gift / Entertainment Item", [
       ("GNE ID", "Unique identifier of the gift or entertainment record.", "G&E Item", "Identifier", "", "GNE-2026-018834", "Internal", "", "Y"),
       ("Direction", "Whether the benefit was given or received by the firm's personnel.", "G&E Item", "Code", "Benefit Direction", "Given", "FINRA Rule 3220", "", ""),
       ("Benefit Type", "Type of benefit.", "G&E Item", "Code", "Benefit Type", "Business Entertainment", "FINRA Rule 3220", "FINRA Rule 2341", "Y"),
       ("Benefit Date", "Date the benefit was given or received.", "G&E Item", "Date", "ISO 8601", "2026-09-10", "Internal", "", "Y"),
       ("Giver", "Employee who gave the benefit (or received it, for inbound items).", "G&E Item", "Reference (Employee)", "", "EMP-20417", "FINRA Rule 3220", "", "Y", "PII"),
       ("Recipient Individual", "Individual at the intermediary or client who received or gave the benefit.", "G&E Item", "Reference (Party)", "", "PTY-559120", "FINRA Rule 3220", "", "Y", "PII"),
       ("Recipient Firm", "Firm employing the recipient individual.", "G&E Item", "Reference (Party)", "", "PTY-3301", "FINRA Rule 3220", "", ""),
       ("Host Present Indicator", "Whether a firm representative attended. Entertainment without the host present is treated as a gift.", "G&E Item", "Boolean", "", "Y", "FINRA Rule 3220", "", ""),
       ("Related Event", "Marketing event at which the benefit was provided, if any.", "G&E Item", "Reference (Event)", "", "EVT-2026-0412", "Internal", "", ""),
       ("Business Purpose", "Business purpose of the benefit.", "G&E Item", "Text", "", "Relationship review with home-office due diligence team", "Internal", "", ""),
     ]),
   ]),
   ("Valuation & Limits", "Valuation of the benefit and tests against regulatory and firm limits.", [
     ("Benefit Valuation", [
       ("Total Cost", "Total cost of the benefit.", "G&E Item", "Amount", "", "USD 640.00", "FINRA Rule 3220", "", ""),
       ("Per-Recipient Value", "Value attributed to each recipient (pro rata for multi-recipient items).", "G&E Item", "Amount", "", "USD 160.00", "FINRA Rule 3220", "", "Y"),
       ("Applicable Limit Rule", "Rule or policy limit the item is tested against.", "G&E Item", "Code", "G&E Limit Rule", "FINRA Rule 3220 Gift Limit", "FINRA Rule 3220", "FINRA Rule 2341", ""),
       ("Annual Limit Amount", "Annual per-person limit under the applicable rule. FINRA raised the Rule 3220 and Rule 2341 limit from USD 100 to USD 300, effective 30 March 2026 (Regulatory Notice 26-05).", "G&E Item", "Amount", "", "USD 300.00", "FINRA Rule 3220", "FINRA Rule 2341", ""),
       ("Recipient Year-to-Date Value", "Cumulative value of gifts given to the recipient in the calendar year, including this item.", "G&E Item", "Amount", "", "USD 210.00", "FINRA Rule 3220", "", "Y"),
       ("Limit Breach Indicator", "Whether the item causes the applicable limit to be exceeded.", "G&E Item", "Boolean", "", "N", "FINRA Rule 3220", "", "Y"),
       ("Excluded Gift Category", "Exclusion relied on for items that do not count towards the limit and need no record (personal, bereavement, de minimis, promotional, commemorative, disaster).", "G&E Item", "Code", "Excluded Gift Category", "Promotional Item", "FINRA Rule 3220", "", ""),
       ("Sales Target Precondition Indicator", "Whether the benefit was conditional on reaching a sales target. This is not permitted for investment-company non-cash compensation.", "G&E Item", "Boolean", "", "N", "FINRA Rule 2341", "", ""),
     ]),
   ]),
   ("Training & Education Meetings", "Offeror-sponsored training and education meetings for intermediary personnel under the non-cash compensation rules.", [
     ("Training / Education Meeting", [
       ("Meeting Event", "Event record of the meeting.", "Meeting", "Reference (Event)", "", "EVT-2026-0398", "FINRA Rule 2341", "", ""),
       ("Member Firm Prior Approval Indicator", "Whether the member firm approved its associated persons' attendance in advance.", "Meeting", "Boolean", "", "Y", "FINRA Rule 2341", "", ""),
       ("Guest Expenses Paid Indicator", "Whether the offeror paid for guests of attendees. This is not permitted.", "Meeting", "Boolean", "", "N", "FINRA Rule 2341", "", ""),
       ("Sponsorship Agreement", "Agreement governing any sponsorship payment to the intermediary.", "Meeting", "Reference (Agreement)", "", "AGR-01104", "Internal", "", ""),
     ]),
   ]),
   ("Inducements Assessment (EU/UK)", "Assessment of benefits against the MiFID II and UK COBS 2.3A inducement rules.", [
     ("Inducement Assessment", [
       ("Minor Non-Monetary Benefit Category", "Category of acceptable minor non-monetary benefit, where relied on.", "G&E Item", "Code", "MNMB Category", "Hospitality of De Minimis Value", "FCA COBS 2.3A", "MiFID II Delegated Directive", ""),
       ("Inducement Assessment Outcome", "Outcome of the inducement assessment.", "G&E Item", "Code", "Inducement Outcome", "Permitted - Minor Non-Monetary Benefit", "FCA COBS 2.3A", "MiFID II", "Y"),
       ("Related Payment Arrangement", "Agreement for any monetary payment to the distributor (e.g. retrocession, platform fee) assessed together with the benefit.", "G&E Item", "Reference (Agreement)", "", "AGR-00788", "Internal", "", ""),
     ]),
   ]),
   ("Special Recipients & Approval", "Recipient flags that trigger additional rules, and the approval of the benefit.", [
     ("Special Recipient Flags", [
       ("Union Official Indicator", "Whether the recipient is an officer or employee of a labour union (Taft-Hartley plan), which can trigger DOL Form LM-10 reporting.", "G&E Item", "Boolean", "", "N", "ERISA", "US DOL LMRDA", ""),
       ("ERISA Plan Fiduciary Indicator", "Whether the recipient is a fiduciary of an ERISA plan, which brings in plan-asset and kickback considerations.", "G&E Item", "Boolean", "", "N", "ERISA", "", ""),
       ("Government Official Indicator", "Whether the recipient is a government or public pension official (anti-bribery and pay-to-play policies).", "G&E Item", "Boolean", "", "N", "Internal", "SEC Rule 206(4)-5", ""),
     ]),
     ("G&E Approval", [
       ("G&E Approval Status", "Approval status of the item.", "G&E Item", "Code", "G&E Approval Status", "Approved", "Internal", "FINRA Rule 3110", ""),
       ("G&E Approver", "Supervisor or compliance officer who approved the item.", "G&E Item", "Reference (Employee)", "", "EMP-10011", "FINRA Rule 3110", "", "", "PII"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Licensing & Registration", "DC-LIC",
  "Regulatory registrations, qualifications, continuing education, Forms U4/U5 and disclosures of sales personnel, and UK SM&CR certification and EU MiFID knowledge-and-competence records. The individuals themselves are defined in 03 Sales (EMP-).",
  [
   ("Registration Record", "A registration held by an individual with a regulator or SRO (LIC master).", [
     ("Individual Registration", [
       ("Licence ID", "Unique identifier of the registration record.", "Licence", "Identifier", "", "LIC-000731", "Internal", "", "Y"),
       ("Registered Person", "Employee who holds the registration.", "Licence", "Reference (Employee)", "", "EMP-20417", "Internal", "", "Y", "PII"),
       ("Individual CRD Number", "FINRA Central Registration Depository number of the individual. Confirm with 03 Sales whether the EMP master also holds it.", "Licence", "Identifier", "", "7654321", "FINRA Form U4", "", "Y", "PII"),
       ("Registering Firm", "Group legal entity through which the individual is registered (e.g. the affiliated broker-dealer).", "Licence", "Code", "Legal Entity (firm-defined)", "Example Funds Distributors LLC", "FINRA Form U4", "", ""),
       ("Registration Category", "FINRA or state registration category held.", "Licence", "Code", "Registration Category", "IR", "FINRA Rule 1220", "", "Y"),
       ("Registration Jurisdiction", "Jurisdiction of the registration (FINRA, US state, or non-US regulator).", "Licence", "Code", "ISO 3166-2", "US-NY", "FINRA Form U4", "NASAA", ""),
       ("Registration Status", "Current status of the registration.", "Licence", "Code", "Registration Status", "Approved", "FINRA Form U4", "", "Y"),
       ("Registration Effective Date", "Date the registration became effective.", "Licence", "Date", "ISO 8601", "2019-03-11", "FINRA Form U4", "", "Y"),
     ]),
   ]),
   ("Qualification Exams", "Qualification exams taken and their validity.", [
     ("Exam Result", [
       ("Exam Code", "Qualification exam.", "Licence", "Code", "Qualification Exam", "Series 6", "FINRA Rule 1220", "NASAA", ""),
       ("Exam Result", "Pass or fail.", "Licence", "Code", "Exam Result", "Pass", "Internal", "", "", "PII"),
     ]),
   ]),
   ("Forms U4 / U5 & Disclosures", "Uniform registration filings and the disclosure events reported on them.", [
     ("Registration Filing", [
       ("Form Type", "Uniform form filed.", "Filing", "Code", "Uniform Form Type", "U4 Amendment", "FINRA Form U4", "FINRA Form U5", ""),
       ("Form Filing Date", "Date the form was filed in CRD.", "Filing", "Date", "ISO 8601", "2026-05-02", "FINRA Form U4", "", ""),
       ("Termination Reason", "Reason for termination reported on Form U5.", "Filing", "Code", "U5 Termination Reason", "Voluntary", "FINRA Form U5", "", "", "PII"),
     ]),
     ("Disclosure Event", [
       ("Disclosure Event Type", "Category of disclosure event.", "Disclosure", "Code", "Disclosure Event Type", "Customer Complaint", "FINRA Form U4", "", "", "PII; may be criminal-offence data (GDPR Art 10)"),
       ("Disclosure Status", "Status of the matter (pending, resolved, etc.).", "Disclosure", "Code", "Disclosure Status", "Pending", "FINRA Form U4", "", "", "PII"),
       ("Related Complaint", "Complaint record behind a complaint disclosure.", "Disclosure", "Reference (Complaint)", "", "CPL-2026-000418", "Internal", "", ""),
     ]),
   ]),
   ("Continuing Education", "Continuing education requirements and completion.", [
     ("CE Requirement", [
       ("CE Element", "Type of continuing education requirement.", "CE Record", "Code", "CE Element", "Regulatory Element", "FINRA Rule 1240", "", ""),
       ("CE Due Date", "Date by which the requirement must be completed. The Regulatory Element is due annually by 31 December.", "CE Record", "Date", "ISO 8601", "2026-12-31", "FINRA Rule 1240", "", ""),
       ("CE Status", "Status of the CE requirement.", "CE Record", "Code", "CE Status", "Complete", "FINRA Rule 1240", "", "Y"),
     ]),
   ]),
   ("UK & EU Competence", "UK SM&CR certification and MiFID II knowledge-and-competence records for sales personnel in the UK and EU.", [
     ("Certification & Competence", [
       ("SM&CR Population", "Population the individual belongs to under SM&CR.", "Licence", "Code", "SM&CR Population", "Certification Staff", "FCA SM&CR", "", "Y"),
       ("Certification Function", "FCA certification function performed.", "Licence", "Code", "Certification Function", "Client Dealing", "FCA SM&CR", "", ""),
       ("FCA Individual Reference Number", "Individual Reference Number on the FCA Financial Services Register / Directory.", "Licence", "Identifier", "", "ABC01234", "FCA SM&CR", "", "", "PII"),
       ("Certificate Renewal Due Date", "Date the annual re-certification is due.", "Licence", "Date", "ISO 8601", "2027-03-31", "FCA SM&CR", "", "Y"),
       ("Fitness and Propriety Outcome", "Outcome of the latest fitness and propriety assessment.", "Licence", "Code", "F&P Outcome", "Fit and Proper", "FCA SM&CR", "", "", "PII"),
       ("MiFID Competence Role", "Role under the ESMA knowledge-and-competence guidelines.", "Licence", "Code", "MiFID Competence Role", "Providing Information", "MiFID II", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Cross-Border Marketing & Private Placement", "DC-CBM",
  "Compliance evidence for marketing funds across borders: marketing and de-notification filings, AIFMD pre-marketing, reverse solicitation records, national private placement and US private offering compliance. Registration-for-sale status is owned by 01 Product.",
  [
   ("Marketing Notification", "Filing that permits marketing of a fund or share class in a host country.", [
     ("Cross-Border Marketing Notification", [
       ("Notification ID", "Unique identifier of the notification filing.", "Notification", "Identifier", "", "MKN-2026-0219", "Internal", "", ""),
       ("Notified Product / Share Class", "Product or share classes covered by the notification.", "Notification", "Reference (Product / Share Class) (multi)", "", "PRD-00981; SHC-004512", "Internal", "", "Y"),
       ("Host Country", "Country in which marketing is notified.", "Notification", "Code", "ISO 3166-1 alpha-2", "DE", "AIFMD", "UCITS Directive", "Y"),
       ("Notification Regime", "Legal basis of the notification.", "Notification", "Code", "Notification Regime", "UCITS Art 93", "UCITS Directive", "AIFMD", "Y"),
       ("Competent Authority", "Authority to which the notification was submitted.", "Notification", "Reference (Party)", "", "PTY-9001 (CSSF)", "UCITS Directive", "", ""),
       ("Notification Status", "Status of the notification.", "Notification", "Code", "Notification Status", "Effective", "Internal", "", "Y"),
       ("Marketing Permitted From", "Date from which marketing is permitted in the host country.", "Notification", "Date", "ISO 8601", "2026-06-12", "UCITS Directive", "", ""),
     ]),
   ]),
   ("AIFMD Pre-Marketing", "Pre-marketing to test professional investors' interest in an AIF not yet established or notified (Art 30a AIFMD).", [
     ("Pre-Marketing Episode", [
       ("Pre-Marketing ID", "Unique identifier of the pre-marketing episode.", "Pre-Marketing", "Identifier", "", "PMK-2026-0007", "Internal", "", ""),
       ("Strategy or Proposed Fund", "Strategy or draft fund being pre-marketed.", "Pre-Marketing", "Reference (Strategy / Product)", "", "STR-00412", "AIFMD", "", ""),
       ("Pre-Marketing Start Date", "Date pre-marketing began. The 18-month window starts from this date.", "Pre-Marketing", "Date", "ISO 8601", "2026-05-04", "AIFMD", "", "Y"),
       ("Pre-Marketing Countries", "Member States in which pre-marketing took place.", "Pre-Marketing", "Code (multi)", "ISO 3166-1 alpha-2", "NL; DE; FR", "AIFMD", "", ""),
       ("Informal Letter Submitted Date", "Date the informal letter was sent to the home NCA (due within two weeks of starting pre-marketing).", "Pre-Marketing", "Date", "ISO 8601", "2026-05-15", "AIFMD", "", "Y"),
       ("18-Month Window End Date", "End of the period in which professional-investor subscriptions are deemed to result from marketing.", "Pre-Marketing", "Date", "ISO 8601", "2027-11-04", "AIFMD", "", ""),
       ("Investors Approached", "Professional investors who received pre-marketing.", "Pre-Marketing", "Reference (Party) (multi)", "", "PTY-2201; PTY-2240", "AIFMD", "", "", "PII where investor is an individual"),
       ("Materials Provided", "Pre-marketing materials used. They must not allow investors to subscribe.", "Pre-Marketing", "Reference (Content Asset) (multi)", "", "AST-120001", "AIFMD", "", ""),
     ]),
   ]),
   ("Reverse Solicitation", "Evidence that an investor approached the firm on its own initiative.", [
     ("Reverse Solicitation Record", [
       ("Reverse Solicitation ID", "Unique identifier of the record.", "Reverse Solicitation", "Identifier", "", "RSL-2026-0031", "Internal", "", ""),
       ("Soliciting Investor", "Investor who made the unsolicited approach.", "Reverse Solicitation", "Reference (Party)", "", "PTY-2290", "AIFMD", "", "Y", "PII where investor is an individual"),
       ("Product Requested", "Product the investor asked about.", "Reverse Solicitation", "Reference (Product)", "", "PRD-01210", "AIFMD", "", ""),
       ("Approach Date", "Date of the investor's first approach.", "Reverse Solicitation", "Date", "ISO 8601", "2026-08-20", "AIFMD", "", ""),
       ("Prior Contact Check Indicator", "Whether a check confirmed no prior marketing or pre-marketing contact with the investor about the product.", "Reverse Solicitation", "Boolean", "", "Y", "AIFMD", "", "Y"),
     ]),
   ]),
   ("Private Placement & US Offering", "National private placement filings and US private offering exemption compliance.", [
     ("Private Offering Compliance", [
       ("Offering Exemption", "Exemption relied on for the private offering.", "Offering", "Code", "Offering Exemption", "Rule 506(b)", "SEC Reg D", "", "Y"),
       ("Form D Filed Date", "Date Form D was filed (within 15 days after first sale).", "Offering", "Date", "ISO 8601", "2026-03-20", "SEC Reg D", "", ""),
       ("General Solicitation Permitted Indicator", "Whether general solicitation is permitted for the offering (Rule 506(c)).", "Offering", "Boolean", "", "N", "SEC Reg D", "", ""),
       ("Investor Qualification Standard", "Investor eligibility standard applied.", "Offering", "Code", "Investor Qualification Standard", "Accredited Investor", "SEC Reg D", "", ""),
       ("NPPR Filing Reference", "Reference of a national private placement filing (e.g. UK AIFMD Art 42 notification).", "Offering", "Identifier", "", "FCA-NPPR-55102", "AIFMD", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Complaints", "DC-CPL",
  "Complaints about products, distribution or communications received from investors, distributors or regulators, with their handling, root cause, redress and regulatory reporting.",
  [
   ("Complaint Record", "Receipt, classification and links of a complaint (CPL master).", [
     ("Complaint", [
       ("Complaint ID", "Unique identifier of the complaint.", "Complaint", "Identifier", "", "CPL-2026-000418", "Internal", "", "Y"),
       ("Received Date", "Date the complaint was received.", "Complaint", "Date", "ISO 8601", "2026-04-15", "FCA DISP", "FINRA Rule 4530", "Y"),
       ("Complaint Source", "Type of party that raised the complaint.", "Complaint", "Code", "Complaint Source", "End Investor", "Internal", "", ""),
       ("Complainant", "Party who made the complaint.", "Complaint", "Reference (Party)", "", "PTY-881204", "FCA DISP", "", "Y", "PII"),
       ("Written Complaint Indicator", "Whether the complaint was in writing (including electronic). Written complaints fall within FINRA Rule 4530 reporting.", "Complaint", "Boolean", "", "Y", "FINRA Rule 4530", "", ""),
       ("Distributor Involved", "Distributor through which the complainant invested.", "Complaint", "Reference (Party)", "", "PTY-3301", "Internal", "", ""),
       ("Product / Share Class", "Product or share class complained about.", "Complaint", "Reference (Product / Share Class)", "", "SHC-004512", "FCA DISP", "FINRA Rule 4530", "Y"),
       ("Account", "Investor account concerned.", "Complaint", "Reference (Account)", "", "ACC-0045512", "Internal", "", "", "PII"),
       ("Related Transaction", "Transaction concerned, if any.", "Complaint", "Reference (Transaction)", "", "TXN-88120455", "Internal", "", ""),
       ("Related Communication", "Communication review record of a marketing communication complained about.", "Complaint", "Reference (Compliance Review)", "", "REV-2026-004518", "Internal", "", ""),
       ("Associated Person Named", "Employee named in the complaint.", "Complaint", "Reference (Employee)", "", "EMP-20417", "FINRA Rule 4530", "FINRA Form U4", "", "PII"),
       ("Complaint Summary", "Summary of the allegations.", "Complaint", "Text", "", "Investor alleges factsheet overstated income yield.", "Internal", "", "", "PII"),
       ("Vulnerable Customer Indicator", "Whether characteristics of vulnerability were identified.", "Complaint", "Boolean", "", "N", "FCA PRIN 2A", "", "", "PII; may be special-category data"),
     ]),
   ]),
   ("Classification & Root Cause", "Classification under firm and regulatory taxonomies and the root cause.", [
     ("Complaint Classification", [
       ("Complaint Category", "Firm complaint category.", "Complaint", "Code", "Complaint Category", "Marketing / Misleading Information", "Internal", "", ""),
       ("FINRA Problem Code", "FINRA Rule 4530 problem code for the most serious allegation.", "Complaint", "Code", "External (FINRA 4530 Problem Codes)", "Misrepresentation", "FINRA Rule 4530", "", "Y"),
       ("FCA Complaint Product Group", "Product group for the FCA complaints return.", "Complaint", "Code", "External (FCA Complaints Return)", "Investments", "FCA DISP", "FCA PS25/19", ""),
       ("Root Cause", "Root cause identified by the investigation.", "Complaint", "Code", "Complaint Root Cause", "Communication Content Error", "Internal", "FCA DISP", "Y"),
     ]),
   ]),
   ("Handling & Resolution", "Handling, deadlines, outcome and redress.", [
     ("Complaint Handling", [
       ("Complaint Status", "Current status.", "Complaint", "Code", "Complaint Status", "Closed", "Internal", "", ""),
       ("Final Response Due Date", "Regulatory deadline for the final response (e.g. eight weeks under DISP).", "Complaint", "Date", "ISO 8601", "2026-06-10", "FCA DISP", "", ""),
       ("Final Response Date", "Date of the final response.", "Complaint", "Date", "ISO 8601", "2026-05-28", "FCA DISP", "", "Y"),
       ("Complaint Outcome", "Outcome of the complaint.", "Complaint", "Code", "Complaint Outcome", "Partially Upheld", "FCA DISP", "", "Y"),
       ("Redress Amount", "Redress or goodwill paid.", "Complaint", "Amount", "", "GBP 350", "FCA DISP", "", "Y"),
     ]),
   ]),
   ("Regulatory Reporting", "Inclusion of the complaint in regulatory reports.", [
     ("Complaint Regulatory Report", [
       ("FINRA 4530(d) Reporting Quarter", "Quarter in which the complaint is reported statistically to FINRA (due by the 15th day after quarter end).", "Complaint", "Text", "", "2026-Q2", "FINRA Rule 4530", "", ""),
       ("FINRA 4530(a) Event Reportable Indicator", "Whether the complaint triggers individual event reporting (e.g. a theft or forgery allegation, or settlement above threshold).", "Complaint", "Boolean", "", "N", "FINRA Rule 4530", "", ""),
       ("FCA Return Reporting Period", "FCA complaints return period in which the complaint is reported (consolidated return from the 1 January - 30 June 2027 period).", "Complaint", "Text", "", "2026-H1", "FCA DISP", "FCA PS25/19", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Communications Surveillance & Records", "DC-SRV",
  "Approved electronic communication channels, capture and retention of business communications, lexicon and model-based surveillance, and supervision of social media use by distribution personnel.",
  [
   ("Channel Governance", "Channels approved for business communication and how they are captured.", [
     ("Approved Communication Channel", [
       ("Channel Type", "Type of electronic communication channel.", "Channel", "Code", "Electronic Channel Type", "Instant Message / Chat", "SEC Rule 17a-4", "MiFID II", ""),
       ("Approved for Business Use Indicator", "Whether the channel is approved for business communications.", "Channel", "Boolean", "", "Y", "SEC Rule 17a-4", "SEC Rule 204-2", "Y"),
       ("Capture Method", "How communications are captured and archived.", "Channel", "Code", "Capture Method", "Native Connector to Archive", "Internal", "", ""),
     ]),
   ]),
   ("Capture & Retention", "Captured communication records and the retention rules that apply to them.", [
     ("Captured Communication Record", [
       ("Communication Record ID", "Archive identifier of the captured communication.", "Comms Record", "Identifier", "", "ARC-2026-09-11-88412093", "Internal", "", "Y"),
       ("Participants", "Internal and external participants.", "Comms Record", "Text", "", "EMP-20417; jane.doe@advisorfirm.com", "Internal", "", "", "PII"),
       ("Communication Timestamp", "Date and time of the communication.", "Comms Record", "Timestamp", "ISO 8601", "2026-09-11T14:02:13Z", "SEC Rule 17a-4", "", ""),
       ("Retention Rule", "Retention rule applied to the record.", "Comms Record", "Reference (Retention Rule)", "", "RET-BD-COMMS", "SEC Rule 17a-4", "", ""),
       ("Retention Expiry Date", "Date the record becomes eligible for disposal.", "Comms Record", "Date", "ISO 8601", "2029-12-31", "SEC Rule 17a-4", "SEC Rule 204-2", "Y"),
       ("Legal Hold Indicator", "Whether the record is under legal hold and must not be disposed of.", "Comms Record", "Boolean", "", "N", "Internal", "", "Y"),
       ("Preservation Method", "Method of non-rewriteable or audit-trail preservation.", "Comms Record", "Code", "Preservation Method", "Audit-Trail System", "SEC Rule 17a-4", "", ""),
     ]),
     ("Retention Rule", [
       ("Record Class", "Class of record governed.", "Retention Rule", "Code", "Record Class", "Business Communications - BD", "SEC Rule 17a-4", "", ""),
       ("Governing Requirement", "Rule that sets the retention requirement.", "Retention Rule", "Code", "Retention Requirement", "SEA Rule 17a-4(b)(4)", "SEC Rule 17a-4", "", ""),
       ("Retention Period (Years)", "Minimum retention period.", "Retention Rule", "Integer", "Years", "3", "SEC Rule 17a-4", "MiFID II", "Y"),
     ]),
   ]),
   ("Surveillance & Review", "Surveillance alerts from lexicons, models and random sampling, and their review.", [
     ("Surveillance Alert", [
       ("Alert ID", "Unique identifier of the surveillance alert.", "Alert", "Identifier", "", "SRV-2026-0099120", "Internal", "", ""),
       ("Alert Source", "Mechanism that generated the alert.", "Alert", "Code", "Surveillance Alert Source", "Lexicon", "FINRA Rule 3110", "", ""),
       ("Policy / Lexicon Hit", "Lexicon category or policy that triggered the alert.", "Alert", "Code", "Lexicon Category (firm-defined)", "Guarantee / Promissory Language", "FINRA Rule 3110", "", ""),
       ("Flagged Communication", "Captured communication the alert relates to.", "Alert", "Reference (Comms Record)", "", "ARC-2026-09-11-88412093", "Internal", "", ""),
       ("Monitored Employee", "Employee whose communication was flagged.", "Alert", "Reference (Employee)", "", "EMP-20417", "FINRA Rule 3110", "", "", "PII"),
       ("Alert Review Status", "Review status of the alert.", "Alert", "Code", "Alert Review Status", "Closed", "Internal", "", ""),
       ("Alert Disposition", "Outcome of the review.", "Alert", "Code", "Alert Disposition", "No Issue", "FINRA Rule 3110", "", "Y"),
     ]),
   ]),
   ("Social Media Supervision", "Business and personal social media accounts used by personnel, and their supervision.", [
     ("Social Media Account", [
       ("Social Platform", "Social media platform.", "Social Account", "Code", "Social Platform", "LinkedIn", "Internal", "", ""),
       ("Account Owner", "Employee or business unit that owns the account.", "Social Account", "Reference (Employee)", "", "EMP-20417", "FINRA Rule 2210", "", "", "PII"),
       ("Account Use Type", "Whether the account is a firm account or a personal account approved for business use.", "Social Account", "Code", "Social Account Use", "Personal - Approved for Business", "FINRA Rule 2210", "", ""),
       ("Content Supervision Model", "Supervision model applied: pre-approval of static content, post-review of interactive content, or both.", "Social Account", "Code", "Social Supervision Model", "Static Pre-Approval + Interactive Post-Review", "FINRA Rule 2210", "FINRA Rule 3110", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Sales Practices & Conduct", "DC-SPC",
  "How the manufacturer monitors and supports compliant selling by intermediaries: information for Reg BI and Consumer Duty, share-class and breakpoint monitoring, frequent-trading surveillance, the distribution conflicts register and outcomes monitoring.",
  [
   ("Intermediary Support Information", "Information the firm provides to intermediaries so they can meet their own sales-practice obligations.", [
     ("Intermediary Information Package", [
       ("Recipient Distributor", "Distributor receiving the package.", "Info Package", "Reference (Party)", "", "PTY-3301", "SEC Reg BI", "", ""),
       ("Package Content Type", "Type of information provided.", "Info Package", "Code", "Intermediary Info Type", "Share Class Comparison & Breakpoints", "SEC Reg BI", "FCA PRIN 2A", ""),
       ("Related Agreement", "Agreement requiring the information (e.g. a revenue-sharing disclosure obligation).", "Info Package", "Reference (Agreement)", "", "AGR-00788", "Internal", "", ""),
     ]),
   ]),
   ("Share-Class & Breakpoint Monitoring", "Surveillance of transactions for share-class suitability and breakpoint or sales-charge discount errors.", [
     ("Sales Practice Alert", [
       ("Sales Practice Alert ID", "Identifier of the alert.", "SP Alert", "Identifier", "", "SPA-2026-001240", "Internal", "", ""),
       ("Alert Type", "Type of sales-practice exception.", "SP Alert", "Code", "Sales Practice Alert Type", "Breakpoint Not Applied", "SEC Form N-1A", "FINRA Rule 2341", "Y"),
       ("Triggering Transaction", "Transaction that raised the alert.", "SP Alert", "Reference (Transaction)", "", "TXN-88120455", "Internal", "", "Y"),
       ("Selling Distributor", "Distributor that placed the trade.", "SP Alert", "Reference (Party)", "", "PTY-3301", "Internal", "", ""),
       ("Alert Disposition", "Outcome of the review.", "SP Alert", "Code", "Alert Disposition", "Issue Confirmed - Remediated", "Internal", "", ""),
     ]),
   ]),
   ("Frequent Trading Surveillance", "Market-timing and excessive-trading surveillance and actions under the fund's frequent trading policy.", [
     ("Frequent Trading Case", [
       ("Frequent Trading Case ID", "Identifier of the case.", "FT Case", "Identifier", "", "FTC-2026-0102", "Internal", "", ""),
       ("Account or Omnibus", "Account or omnibus position where the trading pattern was found.", "FT Case", "Reference (Account)", "", "ACC-0091200", "SEC Rule 22c-2", "", ""),
       ("Round Trips Count", "Number of round trips (purchase and redemption) in the look-back window.", "FT Case", "Integer", "", "4", "SEC Form N-1A", "", ""),
       ("Shareholder Information Agreement", "Rule 22c-2 agreement with the intermediary.", "FT Case", "Reference (Agreement)", "", "AGR-00912", "SEC Rule 22c-2", "", ""),
       ("Action Taken", "Action taken against the trading.", "FT Case", "Code", "Frequent Trading Action", "Trading Restriction Imposed", "SEC Form N-1A", "", "Y"),
     ]),
   ]),
   ("Distribution Conflicts Register", "Conflicts of interest that arise in distribution, with their mitigation.", [
     ("Distribution Conflict of Interest", [
       ("Conflict ID", "Identifier of the conflict.", "Conflict", "Identifier", "", "COI-DST-0031", "FCA SYSC 10", "", ""),
       ("Conflict Category", "Category of the distribution conflict.", "Conflict", "Code", "Distribution Conflict Category", "Revenue Sharing / Payment for Shelf Space", "FCA SYSC 10", "SEC Reg BI", "Y"),
       ("Conflict Description", "Description of the conflict.", "Conflict", "Text", "", "Revenue-sharing payments to wirehouse platform may incentivise preferential placement.", "FCA SYSC 10", "", ""),
       ("Related Agreements", "Agreements that give rise to the conflict.", "Conflict", "Reference (Agreement) (multi)", "", "AGR-00788", "Internal", "", ""),
       ("Mitigating Controls", "Controls and disclosures that manage the conflict.", "Conflict", "Text", "", "Prospectus/SAI disclosure; fixed-rate schedule; annual oversight review.", "FCA SYSC 10", "MiFID II", ""),
       ("Disclosure Required Indicator", "Whether the conflict must be disclosed to clients or intermediaries.", "Conflict", "Boolean", "", "Y", "FCA SYSC 10", "SEC Reg BI", ""),
       ("Conflict Status", "Status of the register entry.", "Conflict", "Code", "Register Status", "Active", "Internal", "", ""),
     ]),
   ]),
   ("Consumer Duty Outcomes Monitoring", "Outcome metrics used in the board report and shared with distributors.", [
     ("Outcome Metric", [
       ("Consumer Duty Outcome", "Outcome the metric evidences.", "Metric", "Code", "Consumer Duty Outcome", "Price and Value", "FCA PRIN 2A", "", "Y"),
       ("Metric Name", "Name of the metric.", "Metric", "Text", "", "Share of retail AUM in clean share classes", "Internal", "", ""),
       ("Metric Value", "Measured value.", "Metric", "Decimal", "", "92.4", "Internal", "", ""),
       ("Tolerance Status", "Rating of the value against tolerance.", "Metric", "Code", "RAG Status", "Green", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Obligations, Attestations & Data Governance", "DC-GOV",
  "Register of distribution-related regulatory obligations and their controls, periodic attestations by personnel and supervisors, and data management metadata for the domain.",
  [
   ("Regulatory Obligations Register", "Inventory of the distribution compliance obligations the firm is subject to.", [
     ("Regulatory Obligation", [
       ("Obligation ID", "Unique identifier of the obligation.", "Obligation", "Identifier", "", "OBL-DC-0142", "Internal", "", "Y"),
       ("Source Regulation", "Regulation or rulebook the obligation comes from.", "Obligation", "Code", "Source Regulation", "FINRA Rules", "Internal", "", ""),
       ("Rule Citation", "Specific rule or article citation.", "Obligation", "Text", "", "FINRA Rule 2210(c)(3)(A)", "Internal", "", "Y"),
       ("Obligation Summary", "Plain-language summary of the obligation.", "Obligation", "Text", "", "File registered investment company retail communications within 10 business days of first use.", "Internal", "", ""),
       ("Applicable Legal Entity", "Group legal entity subject to the obligation.", "Obligation", "Code", "Legal Entity (firm-defined)", "Example Funds Distributors LLC", "Internal", "", ""),
       ("Obligation Owner", "Accountable owner of the obligation.", "Obligation", "Reference (Employee)", "", "EMP-10011", "Internal", "FCA SM&CR", "", "PII"),
       ("Compliance Assessment", "Result of the latest assessment.", "Obligation", "Code", "Compliance Assessment", "Compliant", "Internal", "", ""),
     ]),
   ]),
   ("Attestations & Certifications", "Periodic attestations by personnel and certifications by senior management.", [
     ("Attestation", [
       ("Attestation Type", "Type of attestation.", "Attestation", "Code", "Attestation Type", "Annual G&E Attestation", "Internal", "FINRA Rule 3130", ""),
       ("Attester", "Employee who attested.", "Attestation", "Reference (Employee)", "", "EMP-20417", "Internal", "", "Y", "PII"),
       ("Attestation Completed Date", "Date the attestation was completed.", "Attestation", "Date", "ISO 8601", "2027-01-12", "Internal", "", ""),
       ("Attestation Status", "Status of the attestation.", "Attestation", "Code", "Attestation Status", "Completed", "Internal", "", "Y"),
     ]),
   ]),
   ("Data Management Metadata", "Metadata applied to every record in the distribution compliance domain.", [
     ("Record Metadata", [
       ("Data Owner", "Business role accountable for the data element.", "All", "Reference (Party)", "", "Chief Compliance Officer - Distribution", "DCAM (EDM Council)", "", ""),
       ("Data Steward", "Role responsible for day-to-day data quality.", "All", "Reference (Party)", "", "Advertising Compliance Data Steward", "DCAM (EDM Council)", "", ""),
       ("System of Record", "System holding the authoritative value.", "All", "Code", "Firm-defined", "Advertising Review Workflow", "Internal", "", ""),
       ("Record Effective From", "Business-effective start date of the record version.", "All", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Record Effective To", "Business-effective end date of the record version.", "All", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Last Updated Timestamp", "System timestamp of the last change.", "All", "Timestamp", "ISO 8601", "2026-09-30T17:45:00Z", "Internal", "", ""),
       ("Record Retention Class", "Retention class assigned to the compliance record itself.", "All", "Reference (Retention Rule)", "", "RET-ADV-COMMS", "SEC Rule 17a-4", "SEC Rule 204-2", ""),
       ("Data Quality Status", "Validation status of the record.", "All", "Code", "Data Quality Status", "Validated", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 # Communications review
 "Review Type": ("Internal", [("New Communication",""),("Revision","Material change to an approved communication"),("Re-certification","Periodic re-review of an evergreen piece"),("Performance Update","Data refresh only, e.g. quarterly factsheet"),("Translation / Localisation",""),("Template Approval","Pre-approved template for repeated use, e.g. correspondence or social posts")]),
 "Audience Category": ("Internal (aligned to FINRA 2210 / MiFID II)", [("General Public / Retail Investor",""),("Financial Professional","Intermediary personnel"),("Institutional Investor","FINRA Rule 4512(c) institution"),("Consultant / Gatekeeper",""),("Retirement Plan Sponsor",""),("Existing Investor","")]),
 "FINRA Communication Category": ("FINRA Rule 2210(a)", [("Retail Communication","Distributed to more than 25 retail investors within any 30-day period"),("Institutional Communication","Distributed only to institutional investors"),("Correspondence","Distributed to 25 or fewer retail investors within any 30-day period")]),
 "Investment Company Communication Type": ("SEC Securities Act Rule 482 / ICA Rule 34b-1", [("Rule 482 Advertisement",""),("Rule 34b-1 Supplemental Sales Literature",""),("Rule 135a Generic Advertisement",""),("Not Applicable","")]),
 "Marketing Rule Advertisement Type": ("SEC Rule 206(4)-1(e)(1)", [("One-to-Many Advertisement","Offers advisory services to more than one person"),("One-on-One with Hypothetical Performance","One-on-one communication that is still an advertisement"),("Compensated Testimonial / Endorsement",""),("Private Fund Advertisement",""),("Not an Advertisement - One-on-One",""),("Not an Advertisement - Extemporaneous Live Oral",""),("Not an Advertisement - Required by Law",""),("Not an Advertisement - RIC / BDC Communication","Covered by Rule 482 / 34b-1")]),
 "Financial Promotion Type": ("FCA COBS 4", [("Non-Real-Time",""),("Real-Time Solicited",""),("Real-Time Unsolicited",""),("Direct Offer","")]),
 "FPO Exemption": ("FSMA 2000 (Financial Promotion) Order 2005 / FCA COBS 4.12", [("Art 19 Investment Professionals",""),("Art 49 High Net Worth Companies",""),("Art 48 Certified High Net Worth Individual",""),("Art 50 Certified Sophisticated Investor",""),("Art 50A Self-Certified Sophisticated Investor",""),("COBS 4.12 Permitted NMPI Promotion",""),("Not Applicable - Approved for Retail","")]),
 "MiFID Client Category": ("MiFID II Annex II", [("Retail Client",""),("Professional Client",""),("Elective Professional Client",""),("Eligible Counterparty","")]),
 "Performance Type": ("SEC Marketing Rule / ESMA Marketing Guidelines", [("Actual - Fund",""),("Actual - Composite",""),("Extracted","Subset of investments from a single portfolio"),("Hypothetical - Model",""),("Hypothetical - Backtested",""),("Hypothetical - Targeted / Projected",""),("Predecessor","Track record from a prior firm or vehicle"),("Related Performance","Portfolios with substantially similar strategy"),("Simulated Past Performance","ESMA / COBS 4.6 term"),("Future Performance Scenario","")]),
 "Gross Net Presentation": ("SEC Marketing Rule / SEC staff FAQ (March 2025)", [("Net Only",""),("Gross and Net",""),("Gross Only - Extracted with Net Overview","Permitted per March 2025 staff FAQ when the total portfolio gross and net is shown"),("Not Applicable","")]),
 "Disclosure Set (firm-defined)": ("Internal", [("US-MF-PERF-01","US mutual fund standardised performance disclosure"),("US-RISK-EQ-02","US equity risk disclosure"),("EU-MKTG-01","ESMA 'This is a marketing communication' disclaimer"),("UK-FP-PP-01","UK past performance warning"),("ESG-AGR-01","Sustainability claim substantiation disclosure")]),
 "Reviewer Role": ("Internal", [("Compliance - Advertising",""),("Compliance - EMEA",""),("Legal",""),("Registered Principal",""),("Performance Measurement",""),("Product Specialist",""),("Sustainability / ESG","")]),
 "Approval Status": ("Internal", [("Pending",""),("Approved",""),("Approved with Conditions",""),("Rejected",""),("Expired",""),("Withdrawn","")]),
 "Frequency": ("Internal", [("Monthly",""),("Quarterly",""),("Semi-Annual",""),("Annual",""),("Biennial",""),("Ad Hoc","")]),
 "FINRA Filing Requirement": ("FINRA Rule 2210(c)", [("Pre-Use - 10 Business Days","E.g. RIC communications with non-public rankings; new member firms' first year"),("Post-Use - Within 10 Business Days","E.g. RIC retail communications"),("Excluded from Filing","E.g. previously filed, prospectus, institutional communication"),("Voluntary Filing",""),("Spot-Check Request","Provided on FINRA request")]),
 "FINRA Review Outcome": ("FINRA Advertising Regulation review letters", [("Appears Consistent","Appears consistent with applicable standards"),("May Be Consistent If Changes Made",""),("Inconsistent","Must not be used; corrective action may be required"),("No Review Letter Issued","")]),
 "Regulator Filing Type": ("Internal", [("Ex-Ante Notification","Prior notification required by a host NCA under CBDF Art 7"),("Ex-Post Submission",""),("Regulator Information Request Response","")]),
 # Distributor due diligence
 "DD Review Type": ("Internal", [("Initial / Onboarding",""),("Periodic",""),("Event-Driven","E.g. regulatory sanction, ownership change, adverse media"),("Exit / Termination","")]),
 "Distributor Role": ("Internal (aligned to ESMA product governance / Consumer Duty)", [("Selling Group Broker-Dealer",""),("Wirehouse",""),("Platform / Nominee",""),("Fund Supermarket",""),("Private Bank / Wealth Manager",""),("IFA / Advisory Firm",""),("Discretionary Fund Manager",""),("Sub-Distributor",""),("Placement Agent",""),("Introducer / Finder",""),("Insurance Wrapper Provider",""),("Recordkeeper (DCIO)","")]),
 "DD Case Status": ("Internal", [("Not Started",""),("Questionnaire Issued",""),("In Review",""),("Pending Committee",""),("Completed",""),("Cancelled","")]),
 "Risk Rating": ("Internal", [("Low",""),("Medium",""),("High",""),("Prohibited","")]),
 "Screening Type": ("Internal", [("Sanctions",""),("PEP",""),("Adverse Media",""),("Regulatory Enforcement","")]),
 "Screening Result": ("Internal", [("No Match",""),("Potential Match",""),("Confirmed Match","")]),
 "Regulatory Register": ("Internal", [("FINRA BrokerCheck",""),("SEC IAPD",""),("FCA Financial Services Register",""),("ESMA Registers",""),("EU NCA Register","E.g. BaFin, AMF, CSSF, CBI"),("Other","")]),
 "Questionnaire Template (firm-defined)": ("Internal", [("KYD Platform Questionnaire v2026",""),("KYD Broker-Dealer Questionnaire v2026",""),("KYD Placement Agent Questionnaire v2026",""),("Industry Standard Questionnaire","Industry template accepted in place of the firm's own")]),
 "DD Finding Category": ("Internal", [("AML / Sanctions Controls",""),("Target Market Controls",""),("Complaints Handling",""),("Inducements / Remuneration",""),("Marketing Material Use",""),("Data Protection",""),("Operational Resilience",""),("Governance","")]),
 "Severity": ("Internal", [("Low",""),("Medium",""),("High",""),("Critical","")]),
 "Remediation Status": ("Internal", [("Open",""),("In Progress",""),("Closed - Remediated",""),("Closed - Risk Accepted",""),("Overdue","")]),
 "DD Outcome": ("Internal", [("Approved",""),("Approved with Conditions",""),("Restricted","Limited products, investor types or territories"),("Suspended",""),("Terminated","")]),
 # Product governance & feedback
 "Feedback Template": ("FinDatEx / UK trade associations", [("FinDatEx EFT","European Feedback Template, V1 published December 2020"),("UK Distributor Feedback Template","Joint trade association Consumer Duty template (Sept 2023)"),("Bespoke","Firm or distributor-specific format")]),
 "Distribution Strategy": ("FinDatEx EMT (as used in 01 Product)", [("Execution Only",""),("Execution with Appropriateness",""),("Non-Advised",""),("Investment Advice",""),("Portfolio Management","")]),
 "Target Market Deviation Reason": ("ESMA Product Governance Guidelines (illustrative)", [("Portfolio Diversification","Sale outside target market justified at portfolio level"),("Hedging",""),("Client Insistence / Execution-Only",""),("Target Market Data Unavailable",""),("Distributor Error",""),("Other","")]),
 "Exchange Direction": ("Internal", [("Manufacturer to Distributor",""),("Distributor to Manufacturer",""),("Manufacturer to Co-Manufacturer","")]),
 "Consumer Duty Information Type": ("FCA PRIN 2A (illustrative)", [("Target Market",""),("Fair Value Assessment Summary",""),("Distribution Strategy",""),("Consumer Support Information",""),("Outcomes MI",""),("Vulnerable Customer Insight","Aggregated, no personal data"),("Product Change Notification","")]),
 "Delivery Method": ("Internal", [("EMT Data Feed",""),("Distributor Portal",""),("Email",""),("API",""),("Data Vendor","")]),
 "Product Governance Action": ("ESMA Product Governance Guidelines / FCA PROD 3", [("No Action",""),("Amend Target Market",""),("Restrict Distribution Strategy",""),("Restrict Distributor",""),("Amend Product Terms",""),("Close Product to New Investors","")]),
 # G&E
 "Benefit Direction": ("Internal", [("Given",""),("Received","")]),
 "Benefit Type": ("FINRA Rules 3220 / 2341; FCA COBS 2.3A", [("Gift",""),("Business Entertainment","Host present"),("Meal",""),("Event Ticket",""),("Travel and Lodging",""),("Training / Education Meeting Expenses",""),("Conference Sponsorship","Payment terms in 05 Agreements"),("Charitable Contribution",""),("Promotional Item","Logo item of nominal value")]),
 "G&E Limit Rule": ("FINRA / FCA / Internal", [("FINRA Rule 3220 Gift Limit","USD 300 per person per year from 30 March 2026"),("FINRA Rule 2341 Non-Cash Compensation","Investment company securities; aligned USD 300 gift limit"),("Firm EMEA Gift Threshold","Firm policy threshold for MiFID/COBS business"),("Firm Entertainment Threshold",""),("Public Official Policy",""),("Union Official / LM-10 Threshold","Confirm current DOL threshold")]),
 "Excluded Gift Category": ("FINRA Rule 3220 as amended (RN 26-05)", [("Personal Gift","Life events, not business related"),("Bereavement Gift",""),("De Minimis Item",""),("Promotional Item",""),("Commemorative Item","Decorative deal toy; no cap"),("Disaster Donation","Federally declared major disaster"),("Not Excluded","")]),
 "MNMB Category": ("FCA COBS 2.3A.19R / Delegated Directive (EU) 2017/593 Art 12(3)", [("Generic or Personalised Product Information",""),("Issuer-Commissioned Written Material",""),("Conference / Seminar / Training on Specific Instrument",""),("Hospitality of De Minimis Value","E.g. food and drink at a business meeting or training event"),("Short-Term Research Trial",""),("Other Quality-Enhancing Minor Benefit",""),("Not an MNMB","")]),
 "Inducement Outcome": ("Internal", [("Permitted - Minor Non-Monetary Benefit",""),("Permitted - Quality Enhancing with Disclosure",""),("Not Permitted - Declined / Returned",""),("Not Permitted - Breach Recorded","")]),
 "G&E Approval Status": ("Internal", [("Not Required",""),("Pending",""),("Approved",""),("Rejected",""),("Retrospectively Approved","")]),
 # Licensing
 "Legal Entity (firm-defined)": ("Internal", [("Example Funds Distributors LLC","US affiliated broker-dealer / principal underwriter"),("Example Asset Management LLC","SEC-registered investment adviser"),("Example Asset Management (UK) Ltd","FCA-authorised firm"),("Example Asset Management S.A.","Luxembourg ManCo / AIFM")]),
 "Registration Category": ("FINRA Rule 1220 / CRD registration codes", [("GS","General Securities Representative (Series 7)"),("IR","Investment Company and Variable Contracts Products Representative (Series 6)"),("GP","General Securities Principal (Series 24)"),("IP","Investment Company and Variable Contracts Products Principal (Series 26)"),("OS","Operations Professional (Series 99)"),("AG","State Agent of a broker-dealer (Series 63 / 66)"),("RA","State Investment Adviser Representative (Series 65 / 66)")]),
 "Registration Status": ("FINRA CRD", [("Approved",""),("Pending",""),("Deficient",""),("CE Inactive",""),("Terminated",""),("Purged","")]),
 "Qualification Exam": ("FINRA / NASAA", [("SIE","Securities Industry Essentials"),("Series 6",""),("Series 7",""),("Series 24",""),("Series 26",""),("Series 63","NASAA Uniform Securities Agent State Law"),("Series 65","NASAA Uniform Investment Adviser Law"),("Series 66","NASAA Uniform Combined State Law"),("Series 99","")]),
 "Exam Result": ("Internal", [("Pass",""),("Fail",""),("Waived","")]),
 "Uniform Form Type": ("FINRA Forms U4 / U5", [("U4 Initial",""),("U4 Amendment",""),("U4 Relicense",""),("U5 Full Termination",""),("U5 Partial Termination",""),("U5 Amendment","")]),
 "U5 Termination Reason": ("FINRA Form U5", [("Voluntary",""),("Discharged",""),("Permitted to Resign",""),("Deceased",""),("Other","")]),
 "Disclosure Event Type": ("FINRA Form U4 disclosure questions", [("Criminal",""),("Regulatory Action",""),("Civil Judicial",""),("Customer Complaint / Arbitration",""),("Termination",""),("Financial (Bankruptcy / Compromise)",""),("Judgment / Lien",""),("Internal Review","")]),
 "Disclosure Status": ("Internal", [("Pending",""),("Resolved",""),("Final",""),("On Appeal","")]),
 "CE Element": ("FINRA Rule 1240", [("Regulatory Element","Annual, by 31 December, per registration category"),("Firm Element","Annual training plan based on needs analysis"),("Maintaining Qualifications Program","Optional CE after termination to extend qualification")]),
 "CE Status": ("FINRA Rule 1240", [("Not Started",""),("In Progress",""),("Complete",""),("Overdue - CE Inactive",""),("Extension Granted","")]),
 "SM&CR Population": ("FCA SM&CR", [("Senior Manager",""),("Certification Staff",""),("Conduct Rules Staff",""),("Not in Scope","")]),
 "Certification Function": ("FCA SYSC 27.8", [("Client Dealing",""),("Significant Management",""),("Manager of Certification Employees",""),("Material Risk Taker",""),("Function Requiring Qualification",""),("Proprietary Trader",""),("Algorithmic Trading","")]),
 "F&P Outcome": ("FCA SM&CR", [("Fit and Proper",""),("Not Fit and Proper",""),("Pending","")]),
 "MiFID Competence Role": ("ESMA Guidelines on knowledge and competence", [("Providing Information",""),("Giving Investment Advice",""),("Not in Scope","")]),
 # Cross-border
 "Notification Regime": ("UCITS Directive / AIFMD / UK", [("UCITS Art 93",""),("AIFMD Art 32 Marketing Passport",""),("AIFMD Art 42 NPPR",""),("AIFMD Art 36 NPPR (Non-EU AIF of EU AIFM)",""),("UK Overseas Funds Regime",""),("UK NPPR",""),("Swiss Representative / Paying Agent","CISA"),("Local Private Placement","")]),
 "Notification Status": ("Internal", [("Draft",""),("Submitted",""),("Effective",""),("Rejected",""),("De-Notification in Progress",""),("De-Notified","")]),
 "Offering Exemption": ("SEC Reg D / Securities Act", [("Rule 506(b)","No general solicitation"),("Rule 506(c)","General solicitation; verified accredited investors"),("Section 4(a)(2)",""),("Regulation S","Offshore offering"),("Rule 144A","")]),
 "Investor Qualification Standard": ("SEC / Investment Company Act", [("Accredited Investor","Reg D Rule 501(a)"),("Qualified Purchaser","ICA s2(a)(51)"),("Qualified Client","Advisers Act Rule 205-3"),("Qualified Institutional Buyer","Rule 144A"),("Professional Investor (AIFMD)","")]),
 # Complaints
 "Complaint Source": ("Internal", [("End Investor",""),("Distributor / Intermediary",""),("Institutional Client",""),("Regulator Referral",""),("Ombudsman",""),("Other","")]),
 "Complaint Category": ("Internal", [("Marketing / Misleading Information",""),("Product Performance",""),("Fees and Charges",""),("Dealing / Processing",""),("Service / Communication",""),("Suitability (via Distributor)",""),("Data Protection",""),("Other","")]),
 "Complaint Root Cause": ("Internal", [("Communication Content Error",""),("Process Failure",""),("System Failure",""),("Third-Party / Distributor Failure",""),("Product Design",""),("Customer Misunderstanding",""),("No Fault Found","")]),
 "Consumer Duty Outcome": ("FCA PRIN 2A", [("Products and Services",""),("Price and Value",""),("Consumer Understanding",""),("Consumer Support","")]),
 "Complaint Status": ("Internal", [("Open",""),("Under Investigation",""),("Awaiting Response",""),("Closed",""),("Referred to Ombudsman",""),("Reopened","")]),
 "Complaint Outcome": ("FCA DISP", [("Upheld",""),("Partially Upheld",""),("Not Upheld",""),("Withdrawn","")]),
 # Surveillance
 "Electronic Channel Type": ("Internal", [("Email",""),("Instant Message / Chat",""),("Bloomberg / Market Chat",""),("SMS / Text",""),("Messaging App","E.g. WhatsApp Business via approved capture"),("Voice - Recorded Line",""),("Video Conference",""),("Social Media","")]),
 "Capture Method": ("Internal", [("Native Connector to Archive",""),("Journaling",""),("Mobile Capture App",""),("Carrier-Level Capture",""),("Manual Upload","")]),
 "Preservation Method": ("SEC Rule 17a-4(f) as amended 2022", [("WORM Storage","Non-rewriteable, non-erasable"),("Audit-Trail System","Allows recreation of original record if modified"),("Paper","")]),
 "Record Class": ("Internal", [("Business Communications - BD",""),("Business Communications - RIA",""),("Advertisements / Retail Communications",""),("MiFID Telephone and Electronic Records",""),("Complaints Records",""),("Gifts & Entertainment Log",""),("Registration Records","")]),
 "Retention Requirement": ("SEC / FINRA / MiFID II / FCA", [("SEA Rule 17a-4(b)(4)","BD communications: 3 years, first 2 easily accessible"),("Advisers Act Rule 204-2(a)(7)","Adviser written communications: 5 years, first 2 in office"),("Advisers Act Rule 204-2(a)(11) / (a)(16)","Advertisements and performance support"),("FINRA Rule 2210(b)(4)","Communications retained per 17a-4 with approver and date"),("MiFID II Art 16(7)","Telephone / electronic communications: 5 years, up to 7 on NCA request"),("FCA COBS 11.8","UK recording of communications"),("FCA DISP 1.9","Complaint records")]),
 "Surveillance Alert Source": ("Internal", [("Lexicon",""),("Machine Learning Model",""),("Random Sample",""),("Targeted Review",""),("Manual Referral","")]),
 "Lexicon Category (firm-defined)": ("Internal", [("Guarantee / Promissory Language",""),("Off-Channel Communication",""),("Gifts / Entertainment",""),("Complaint Indicator",""),("Confidential Information",""),("Unapproved Performance Claims","")]),
 "Alert Review Status": ("Internal", [("New",""),("In Review",""),("Escalated",""),("Closed","")]),
 "Alert Disposition": ("Internal", [("No Issue",""),("Issue Confirmed - Remediated",""),("Issue Confirmed - Escalated",""),("Policy Reminder Issued",""),("False Positive","")]),
 "Social Platform": ("Internal", [("LinkedIn",""),("X",""),("YouTube",""),("Facebook",""),("Instagram",""),("Other","")]),
 "Social Account Use": ("FINRA Regulatory Notices 10-06 / 11-39", [("Firm Corporate Account",""),("Personal - Approved for Business",""),("Personal - Not for Business Use","")]),
 "Social Supervision Model": ("FINRA Regulatory Notices 10-06 / 11-39 / 17-18", [("Static Pre-Approval",""),("Interactive Post-Review",""),("Static Pre-Approval + Interactive Post-Review",""),("Not Permitted","")]),
 # Sales practices
 "Intermediary Info Type": ("Internal", [("Share Class Comparison & Breakpoints",""),("Revenue Sharing / Payment Disclosure",""),("Product Due Diligence Pack",""),("Complex Product Information",""),("Target Market & Fair Value Data",""),("Rule 22c-2 Policy","")]),
 "Sales Practice Alert Type": ("Internal", [("Breakpoint Not Applied",""),("Rights of Accumulation / LOI Not Applied",""),("Share Class Suitability (Large C-Share Purchase)",""),("Switching / Exchange Pattern",""),("Sale Outside Target Market",""),("Ineligible Investor Share Class","")]),
 "Frequent Trading Action": ("Internal", [("Monitor Only",""),("Warning Letter",""),("Trading Restriction Imposed",""),("Account Blocked",""),("Redemption Fee Applied","")]),
 "Distribution Conflict Category": ("Internal (aligned to SYSC 10 / Reg BI)", [("Revenue Sharing / Payment for Shelf Space",""),("Conference / Event Sponsorship",""),("Non-Cash Compensation",""),("Affiliated Distributor Preference",""),("Proprietary Product Preference",""),("Wholesaler Incentive Compensation","Plan defined in 07 Compensation"),("Personal Relationships","")]),
 "Register Status": ("Internal", [("Active",""),("Under Review",""),("Closed","")]),
 "RAG Status": ("Internal", [("Green",""),("Amber",""),("Red","")]),
 # Governance
 "Source Regulation": ("Internal", [("FINRA Rules",""),("SEC Exchange Act Rules",""),("SEC Advisers Act Rules",""),("SEC Investment Company Act Rules",""),("FCA Handbook",""),("EU Regulation / Directive",""),("ESMA Guidelines",""),("State Securities Law","")]),
 "Compliance Assessment": ("Internal", [("Compliant",""),("Partially Compliant",""),("Non-Compliant",""),("Not Assessed","")]),
 "Attestation Type": ("Internal", [("Annual Compliance Certification",""),("Annual G&E Attestation",""),("Code of Ethics Acknowledgement",""),("Social Media Policy Attestation",""),("Outside Business Activities Declaration",""),("FINRA Rule 3130 CEO Certification",""),("Supervisory Controls Attestation","")]),
 "Attestation Status": ("Internal", [("Issued",""),("Completed",""),("Completed with Exceptions",""),("Overdue","")]),
 "Data Quality Status": ("Internal", [("Validated",""),("Pending Validation",""),("Exception",""),("Deprecated","")]),
}

# ---------------------------------------------------------------------------
# Relationships, sources
# ---------------------------------------------------------------------------
REL = [
 ("Compliance Review (REV-)","approves use of","Content Asset (AST-, 04 Marketing)","n : 1","One asset version may be reviewed several times (revision, re-certification); each review covers one asset version."),
 ("Compliance Review (REV-)","supports","Campaign (CAM-, 04 Marketing)","n : 0..1",""),
 ("Compliance Review (REV-)","features","Product / Share Class (PRD-/SHC-, 01 Product)","n : n",""),
 ("Compliance Review (REV-)","is decided by","Approving Principal (EMP-, 03 Sales)","n : 1","Approver's qualifying registration held in Individual Registration (LIC-)."),
 ("Compliance Review (REV-)","has","Review Step","1 : 1..n",""),
 ("Compliance Review (REV-)","is filed as","FINRA Advertising Filing / Other Regulator Filing","1 : 0..n",""),
 ("Distributor Due Diligence (DDQ-)","assesses","Distributor Firm (PTY-, 02 Client & Customer)","n : 1","One case per review cycle per firm."),
 ("Distributor Due Diligence (DDQ-)","covers","Agreement (AGR-, 05 Agreements)","n : 0..1",""),
 ("Distributor Due Diligence (DDQ-)","raises","Due Diligence Finding","1 : 0..n",""),
 ("Distributor Feedback Report","reports sales of","Share Class (SHC-, 01 Product) against its Target Market","1 : 1..n","Target market owned by 01 Product."),
 ("Gift / Entertainment Item (GNE-)","is given by","Employee (EMP-, 03 Sales)","n : 1",""),
 ("Gift / Entertainment Item (GNE-)","is received by","Recipient Individual and Firm (PTY-, 02 Client & Customer)","n : 1","Year-to-date limit tested per recipient individual."),
 ("Gift / Entertainment Item (GNE-)","occurs at","Event (EVT-, 04 Marketing)","n : 0..1",""),
 ("Training / Education Meeting","is funded under","Sponsorship Agreement (AGR-, 05 Agreements)","n : 0..1","Payment terms owned by 05."),
 ("Individual Registration (LIC-)","is held by","Employee (EMP-, 03 Sales)","n : 1","An individual holds many registrations (FINRA categories, states, UK certification)."),
 ("Individual Registration (LIC-)","is evidenced by","Exam Result / Registration Filing / CE Requirement","1 : 0..n",""),
 ("Disclosure Event","may arise from","Complaint (CPL-)","n : 0..1",""),
 ("Cross-Border Marketing Notification","notifies","Product / Share Class (PRD-/SHC-) Country Registration (01 Product)","n : n","01 Product holds resulting registration status; 08 holds filing evidence."),
 ("Pre-Marketing Episode","may precede","Cross-Border Marketing Notification","1 : 0..n","Subscriptions within 18 months deemed to result from marketing."),
 ("Reverse Solicitation Record","is checked against","Pre-Marketing Episode","n : 0..n","No reverse solicitation for investors pre-marketed."),
 ("Complaint (CPL-)","concerns","Product / Share Class, Distributor (PTY-), Account (ACC-), Transaction (TXN-, 06)","n : 0..1 each",""),
 ("Complaint (CPL-)","may concern","Compliance Review (REV-)","n : 0..1","Links complaints about marketing to the approved communication."),
 ("Surveillance Alert","flags","Captured Communication Record","n : 1",""),
 ("Captured Communication Record","is governed by","Retention Rule","n : 1",""),
 ("Sales Practice Alert","is raised on","Transaction (TXN-, 06 Transactions)","n : 1",""),
 ("Frequent Trading Case","relies on","Shareholder Information Agreement (AGR-, 05 Agreements)","n : 0..1","Rule 22c-2 agreements."),
 ("Distribution Conflict of Interest","arises from","Agreement (AGR-, 05 Agreements)","n : 0..n","E.g. revenue sharing; wholesaler compensation plans (ICP-, 07) may also be linked."),
 ("Regulatory Obligation","is evidenced by","Compliance records in this workbook (REV-, DDQ-, GNE-, CPL-, LIC-)","1 : 0..n","Via linked controls."),
 ("Attestation","is given by","Employee (EMP-, 03 Sales)","n : 1",""),
]

SRC = [
 ("FINRA Rule 2210 (Communications with the Public) and filing chart","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2210 ; https://www.finra.org/rules-guidance/key-topics/advertising-regulation/chart","Public rulebook","Communication categories, principal approval, filing requirements and content standards","Communications Review & Approval, Regulatory Filing, Social Media",["FINRA Rule 2210"]),
 ("FINRA Rule 2212 (Use of Investment Company Rankings)","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2212","Public rulebook","Ranking content and disclosure","Performance Presentation (ratings)",["FINRA Rule 2212"]),
 ("FINRA Rule 3110 (Supervision) / Rule 3130","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110","Public rulebook","Supervision of correspondence and communications; CEO certification","Review Workflow, Surveillance, G&E approval, Attestations",["FINRA Rule 3110","FINRA Rule 3130"]),
 ("FINRA Rule 3220 and Regulatory Notice 26-05","FINRA","https://www.finra.org/rules-guidance/notices/26-05","Public rulebook","Gift limit raised from USD 100 to USD 300 effective 30 March 2026; exclusions, valuation, recordkeeping; conforming changes to Rules 2310, 2320, 2341, 5110","Gifts, Entertainment & Inducements",["FINRA Rule 3220"]),
 ("FINRA Rule 2341 (Investment Company Securities) - non-cash compensation","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2341","Public rulebook","Non-cash compensation limits, training and education meeting conditions","Training & Education Meetings, Valuation & Limits",["FINRA Rule 2341"]),
 ("FINRA Rule 4530 (Reporting Requirements)","FINRA","https://www.finra.org/filing-reporting/rule-4530-reporting-requirements","Public rulebook","Event reporting and quarterly statistical complaint reporting (by 15th day after quarter end); product and problem codes","Complaints",["FINRA Rule 4530"]),
 ("FINRA Rules 1210/1220/1240, Forms U4/U5, Continuing Education","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/1220 ; https://www.finra.org/registration-exams-ce/continuing-education","Public rulebook","Registration categories, qualification exams, CE Regulatory Element (annual, 31 Dec) and Firm Element, MQP; uniform registration forms","Licensing & Registration",["FINRA Rule 1210","FINRA Rule 1220","FINRA Rule 1240","FINRA Form U4","FINRA Form U5"]),
 ("SEC Marketing Rule (Advisers Act Rule 206(4)-1) and staff Marketing FAQ","US SEC","https://www.ecfr.gov/current/title-17/section-275.206(4)-1 ; https://www.sec.gov/rules-regulations/staff-guidance/division-investment-management-frequently-asked-questions","Regulation","Advertisement definition, testimonials/endorsements, third-party ratings, performance (gross/net, prescribed periods, extracted, hypothetical); March 2025 FAQ on extracted performance","Regulatory Classification, Performance Presentation",["SEC Marketing Rule","SEC Form ADV"]),
 ("SEC Securities Act Rule 482 / ICA Rule 34b-1","US SEC","https://www.ecfr.gov/current/title-17/section-230.482","Regulation","Investment company advertisements and standardised performance","US Communication Classification, Performance Presentation",["SEC Rule 482"]),
 ("SEC Exchange Act Rule 17a-4 (incl. 2022 amendments)","US SEC","https://www.ecfr.gov/current/title-17/section-240.17a-4","Regulation","Broker-dealer record retention; audit-trail alternative to WORM (compliance 3 May 2023)","Capture & Retention",["SEC Rule 17a-4"]),
 ("SEC Advisers Act Rule 204-2","US SEC","https://www.ecfr.gov/current/title-17/section-275.204-2","Regulation","Adviser books and records including communications and advertisements","Capture & Retention",["SEC Rule 204-2"]),
 ("SEC Regulation Best Interest, Rule 22c-2, Regulation D, Form N-1A, Rule 206(4)-5","US SEC","https://www.ecfr.gov/current/title-17/section-240.15l-1 ; https://www.ecfr.gov/current/title-17/section-270.22c-2 ; https://www.ecfr.gov/current/title-17/section-230.506","Regulation","Intermediary best-interest obligations, shareholder information agreements, private offering exemptions, prospectus disclosure of breakpoints and frequent trading policies","Sales Practices & Conduct, Private Placement & US Offering",["SEC Reg BI","SEC Rule 22c-2","SEC Reg D","SEC Form N-1A","SEC Rule 206(4)-5"]),
 ("NASAA (state registration exams and notice filings)","NASAA","https://www.nasaa.org","Public","Series 63/65/66 and state notice filings","Licensing, Private Placement",["NASAA"]),
 ("FCA COBS 4 (Communicating with clients, including financial promotions) and s21 FSMA / PS23/13 gateway","UK FCA","https://www.handbook.fca.org.uk/handbook/COBS/4/ ; https://www.fca.org.uk/publication/policy/ps23-13.pdf","Regulation","Fair, clear and not misleading; financial promotion types; s21 approver gateway from 7 Feb 2024","EU / UK Communication Classification, Required Disclosures",["FCA COBS 4","FCA FSMA s21","FCA PS23/13"]),
 ("FCA PS23/16 SDR and FG24/3 anti-greenwashing rule (ESG 4.3.1R)","UK FCA","https://www.fca.org.uk/publications/policy-statements/ps23-16-sustainability-disclosure-requirements-investment-labels","Regulation and guidance","Sustainability references must be consistent with product characteristics and fair, clear and not misleading (from 31 May 2024)","Sustainability Claims Indicator",["FCA ESG 4.3"]),
 ("FCA COBS 2.3A (Inducements)","UK FCA","https://www.handbook.fca.org.uk/handbook/COBS/2/3A.html","Regulation","Inducement rules and list of acceptable minor non-monetary benefits (COBS 2.3A.19R)","Inducements Assessment",["FCA COBS 2.3A"]),
 ("FCA PRIN 2A (Consumer Duty) and PROD 3","UK FCA","https://www.handbook.fca.org.uk/handbook/PRIN/2A/","Regulation","Four outcomes, fair value, distribution chain information sharing, product governance","Consumer Duty Information Sharing, Outcomes Monitoring",["FCA PRIN 2A","FCA PROD 3"]),
 ("FCA DISP and PS25/19 (complaints reporting)","UK FCA","https://www.handbook.fca.org.uk/handbook/DISP/1/ ; https://www.fca.org.uk/publication/policy/ps25-19.pdf","Regulation","Complaint handling deadlines and complaints return; consolidated return from 1 Jan 2027 reporting period","Complaints",["FCA DISP","FCA PS25/19"]),
 ("FCA SM&CR (SYSC 27) and SYSC 10 conflicts","UK FCA","https://www.fca.org.uk/firms/senior-managers-certification-regime","Regulation","Certification functions, annual certification, FCA Directory; conflicts of interest","UK & EU Competence, Distribution Conflicts Register",["FCA SM&CR","FCA SYSC 10"]),
 ("Regulation (EU) 2019/1156 (Cross-Border Distribution of Funds)","European Union","https://eur-lex.europa.eu/eli/reg/2019/1156/oj","Regulation","Marketing communication requirements (Art 4), NCA ex-ante filing (Art 7)","EU / UK Communication Classification, Required Disclosures",["EU CBDF Regulation"]),
 ("ESMA Guidelines on marketing communications (ESMA34-45-1272)","ESMA","https://www.esma.europa.eu/sites/default/files/library/esma34-45-1272_guidelines_on_marketing_communications.pdf","Guidelines (apply from 2 Feb 2022)","Identification, risks/rewards prominence, past and future performance, sustainability information","Content Characteristics, Required Disclosures",["ESMA Marketing Guidelines"]),
 ("Directive (EU) 2019/1160 / AIFMD Art 30a, 32, 42 and UCITS Art 93","European Union; CSSF guidance","https://eur-lex.europa.eu/eli/dir/2019/1160/oj ; https://cssf.lu/en/pre-marketing-aifms","Directive","Pre-marketing definition, informal letter within two weeks, 18-month rule, de-notification, facilities","Cross-Border Marketing & Private Placement",["AIFMD","UCITS Directive"]),
 ("ESMA Guidelines on MiFID II product governance (ESMA35-43-3448)","ESMA","https://www.esma.europa.eu/sites/default/files/2023-08/ESMA35-43-3448_Guidelines_on_product_governance.pdf","Guidelines (apply from 3 Oct 2023)","Distributor reporting of sales outside target market to manufacturers; periodic review","Product Governance & Distributor Feedback",["ESMA Product Governance Guidelines"]),
 ("MiFID II and Delegated Directive (EU) 2017/593","European Union","https://eur-lex.europa.eu/eli/dir_del/2017/593/oj","Directive","Inducements (Art 11-12), product governance, recording, knowledge and competence","Inducements, Competence, Retention",["MiFID II","MiFID II Delegated Directive"]),
 ("FinDatEx European Feedback Template (EFT) and EMT","FinDatEx","https://findatex.eu","Free template","Standardised distributor-to-manufacturer target market feedback (EFT V1, Dec 2020); EMT target market data","Target Market Feedback, Delivery Method",["FinDatEx EFT","FinDatEx EMT"]),
 ("UK joint trade association Distributor Feedback Template / data delivery frameworks","The Investment Association et al.","https://www.theia.org/industry-policy/guidelines/data-delivery-frameworks","Free template","Consumer Duty distributor feedback (sales by distribution strategy, outside target market)","Feedback Template",[]),
 ("Sanctions lists and AML frameworks (OFAC, OFSI, EU, FATF, UK MLR 2017)","US Treasury; HM Treasury; EU; FATF","https://ofac.treasury.gov ; https://www.gov.uk/government/organisations/office-of-financial-sanctions-implementation ; https://www.fatf-gafi.org","Public","Screening lists and risk-based approach","Screening & Regulatory Status, Distributor Risk Rating",["OFAC","FATF","UK MLR 2017"]),
 ("ERISA / DOL LMRDA Form LM-10","US Department of Labor","https://www.dol.gov/agencies/olms","Regulation","Plan fiduciary and union official payment reporting considerations","Special Recipient Flags",["ERISA"]),
 ("DCAM","EDM Council","https://edmcouncil.org","Member framework","Data management capability: ownership and stewardship","Data Management Metadata",["DCAM*"]),
]
