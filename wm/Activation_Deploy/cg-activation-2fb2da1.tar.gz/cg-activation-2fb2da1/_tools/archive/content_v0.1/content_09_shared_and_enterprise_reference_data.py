"""Business domain 09 - Shared & Enterprise Reference Data. Content module for taxonomy_builder.py."""

META = {
 "title": "Shared & Enterprise Reference Data Taxonomy",
 "subtitle": "Business domain 09 - Shared & Enterprise Reference Data | Asset manager (wholesale distributor) | Scope: US + EU/UK | Draft v0.1 | 2026-10-01",
 "output": "09_Shared_and_Enterprise_Reference_Data/Shared_and_Enterprise_Reference_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the shared, enterprise-wide reference data that every other business domain of a wholesale asset manager points to: geography, time zones and calendars, currencies and FX rate conventions, languages, locales and units, the firm's own legal entities and their regulatory authorisations, the internal organisation, industry classification schemes, and the enterprise code list registry. It is stitched together from ISO standards (3166, 4217, 639, 8601, 17442, 20275, ISO/IEC 11179), IETF BCP 47 and the IANA time zone database, official statistical geographies (US Census FIPS and ZCTA, OMB CBSA delineations, ONS ITL and postcodes, Eurostat NUTS), FX benchmark methodologies (LSEG WM/Reuters, ECB euro reference rates), GLEIF Level 1 and Level 2 data, FIBO Business Entities, regulator registers (SEC, FINRA, FCA, CSSF, CBI) and the DAMA-DMBOK and DCAM approaches to reference data management. Use it as the starting point for a reference data hub, a data catalogue or a business glossary."),
  ("Scope", "In scope: countries, subdivisions, US counties, CBSAs, ZIP codes and ZCTAs, UK postcodes and ITL regions, EU NUTS regions, firm-defined geographic groupings (sales regions, country clusters) and geographic hierarchies; IANA time zones; business, holiday, exchange and fund dealing calendar structures; the fiscal calendar and fiscal periods; reporting period definitions; ISO 4217 currencies and minor units; FX rate types, sources and conventions (no FX time series); ISO 639 languages, BCP 47 locales, units of measure and number/date conventions; internal legal entities (LEN-) with group hierarchy, LEI, entity-level regulatory authorisations, permissions, passports and distribution roles; internal organisation units, cost and profit centres and reorganisations (OU-); industry classification schemes (NAICS, US SIC, NACE, UK SIC, GICS) and their concordances; and the enterprise code list registry (CLR-) with versions, values, source-system mappings and change control. Out of scope (referenced by ID only): products, share classes and which entity plays which role for which fund (01 Investment Product, PRD-/SHC-); external parties, their addresses, industry codes and identifiers (02 Client & Customer, PTY-); employees and sales teams (03 Sales, EMP-/SLT-); digital properties and content language use (04 Marketing & Digital); agreements naming a group entity as contracting party (05 Distribution Agreements & Partners, AGR-); transactions, data feeds and party-matching crosswalks (06 Sales Transactions & AUM Attribution, FEED-/XWK-); territories built from geographic units (07 Compensation & Territory, TER-); individual licences and compliance obligations (08 Distribution Compliance, LIC-); chart of accounts, GL postings and cost allocation (10 Distribution Finance & Profitability); FX rate and market data licences (14 Third-Party Data & Licensing, DSET-/DLA-). Also out of scope: FX rate time series, prices and the security master."),
  ("Structure", "Four levels: Domain > Subdomain > Concept > Attribute. The Hierarchy tab shows the first three levels with definitions. The Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard. Attribute IDs take the form SR-xxx-nnn."),
  ("Core model", "Thin, shared masters keyed by stable IDs. Geographic Unit (GEO-) is one generic record for any country, subdivision, county, CBSA, ZIP/ZCTA, postcode, ITL or NUTS region, typed by scheme and vintage and linked by effective-dated hierarchies; Geographic Groups (sales regions, EU/UK country clusters) are GEO- records whose members are other GEO- units. Calendar (CAL-) holds holiday, exchange, dealing, fiscal and reporting calendars, with Calendar Dates and Periods underneath. Currency, FX Rate Type, Language, Locale and Time Zone use their natural ISO / IANA / BCP 47 codes as keys. Internal Legal Entity (LEN-) is linked to its parent entities, its regulatory authorisations (AUTH-) and passports, and the distribution roles it performs. Org Unit (OU-) forms management, legal and cost-centre hierarchies that change through governed reorganisations (REORG-). Classification Scheme (ICS-) holds NAICS, NACE, UK SIC, US SIC and GICS nodes and concordances. The Code List Registry (CLR-) describes every governed list, its versions (CLV-), values and source-system mappings (CLM-)."),
  ("Design principles", "1) Reference external standards, don't copy them: ISO, IANA, Census, ONS and Eurostat lists are loaded from their maintainers and tagged with version / vintage; this workbook defines only the structure and the firm-defined layers. 2) Effective-date everything: geographies, groupings, hierarchies, entity ownership, authorisations, org units and code values all carry Effective From / To so history can be restated. 3) One generic structure per pattern (one Geographic Unit, one Calendar, one Code List Registry) rather than one table per list. 4) Own the internal, reference the external: the firm's own legal entities live here (LEN-); every external organisation stays in the 02 party master (PTY-). Each LEN- carries a cross-reference to its PTY- record so that domains which model counterparties generically (01 product party roles, 05 agreements) can keep using PTY-. 5) Registry before harmonisation: the code list registry records owner, steward, version, consumers and source-system mappings for every shared list now; the harmonised enterprise value sets (Distribution Channel, Frequency, Investor Type, Lifecycle Status, Party Role) are left to the consolidation exercise. 6) Flag Critical Data Elements (CDE) where an error would mis-state regulatory reporting, cross-border permissions, valuation dates or roll-ups across domains."),
  ("Applies To", "Shows the record type each attribute belongs to, e.g. Country, Subdivision, Geographic Unit, Geographic Group, Time Zone, Calendar, Calendar Date, Fiscal Period, Reporting Period Definition, Currency, FX Rate Type, Language, Locale, Unit, Legal Entity, Authorisation, Passport, Entity Role, Org Unit, Reorganisation, Classification Scheme, Classification Code, Code List, Code List Version, Code Value, Code Mapping or All."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify a reference record, to derive dates, currencies or permissions used in valuation, dealing, regulatory reporting or compensation, or to roll up data consistently across business domains. Confirm with the reference data owner, Finance, Compliance and the Data Governance Office."),
  ("Primary / Secondary Reference", "The standard, register or methodology the attribute is aligned to (e.g. 'ISO 3166', 'ISO 4217', 'IANA tz', 'OMB CBSA', 'Eurostat NUTS', 'ONS ITL', 'LSEG WM/Reuters', 'ECB', 'GLEIF RR-CDF', 'FIBO BE', 'FCA Register', 'ISO/IEC 11179', 'DAMA-DMBOK'). 'Internal' means the attribute is firm-defined and has no authoritative external definition."),
  ("Tabs", "Hierarchy: domains, subdomains and concepts with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies (ISO and other external lists are referenced as formats, not reproduced) | Relationships: concept-level cardinalities, including links to every consuming business domain | Sources: standards, registers and methodologies used, with owners and links."),
  ("Suggested next steps", "1) Validate the domains, CDEs and code lists with the Data Governance Office, Finance (entity, fiscal calendar, cost centres), Legal Entity Management / Company Secretariat, Compliance (authorisations and passports), Fund Operations (dealing calendars) and Distribution Operations (geographies and sales regions). 2) Pick the reference data hub or MDM tool and the load sources for each external list (ISO 4217 from SIX, IANA tzdata, Census / OMB / HUD-USPS, ONS NSPL and ITL, Eurostat NUTS, GLEIF). 3) Populate the code list registry with all 575+ lists from 01-08, then run the harmonisation pass for the candidates in the Code Lists tab ('Shared Code List Candidate'). 4) Agree the LEN- / PTY- cross-reference rule with 02 and the entity-role boundary with 01. 5) Decide on an enterprise workforce master versus 03's EMP- (see the recommendation in Source_Notes.md). 6) Agree with 10 Finance who owns cost and profit centre codes (Finance) versus the org unit hierarchy (this domain). 7) Turn the Relationships tab into a logical data model."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Geography", "SR-GEO",
  "Countries, subdivisions and the statistical and postal geographies of the US, UK and EU, plus firm-defined geographic groupings and hierarchies that other domains use for addresses, territories, registrations and reporting.",
  [
   ("Countries & Subdivisions", "ISO 3166 countries and their principal subdivisions (US states, UK nations, German Länder, etc.), extended with firm-relevant flags.", [
     ("Country", [
       ("Country Code (Alpha-2)", "Two-letter ISO 3166-1 code; the enterprise key for country in every domain.", "Country", "Code", "ISO 3166-1 alpha-2", "LU", "ISO 3166", "", "Y"),
       ("Country Short Name", "English short name as published by the ISO 3166 Maintenance Agency.", "Country", "Text", "", "Luxembourg", "ISO 3166", "", ""),
       ("EU Member State Indicator", "Whether the country is an EU member state on the effective date.", "Country", "Boolean", "", "Y", "Internal", "UCITS Directive", ""),
       ("EEA Member Indicator", "Whether the country is in the European Economic Area (EU plus Iceland, Liechtenstein, Norway); drives UCITS / AIFMD passporting scope.", "Country", "Boolean", "", "Y", "Internal", "AIFMD", "Y"),
       ("Default Currency", "Principal legal-tender currency of the country.", "Country", "Code", "ISO 4217", "EUR", "ISO 4217", "", ""),
       ("Primary Time Zone", "Default IANA time zone of the country's capital / financial centre.", "Country", "Code", "IANA Time Zone", "Europe/Luxembourg", "IANA tz", "", ""),
     ]),
     ("Country Subdivision", [
       ("Subdivision Code", "ISO 3166-2 code (country code + hyphen + up to three characters).", "Subdivision", "Code", "ISO 3166-2", "US-NY", "ISO 3166", "", "Y"),
       ("Subdivision Name", "Name of the subdivision in English or the official romanisation.", "Subdivision", "Text", "", "New York", "ISO 3166", "", ""),
       ("Subdivision Category", "Type of subdivision as defined in ISO 3166-2 (state, nation, Land, canton, province, region).", "Subdivision", "Code", "Subdivision Category", "State", "ISO 3166", "", ""),
       ("Parent Country", "Country to which the subdivision belongs.", "Subdivision", "Code", "ISO 3166-1 alpha-2", "US", "ISO 3166", "", ""),
       ("US State FIPS Code", "Two-digit FIPS / ANSI code of a US state or territory.", "Subdivision", "Code", "External (US Census FIPS)", "36", "US Census (FIPS)", "", ""),
     ]),
   ]),
   ("US Statistical & Postal Geography", "US counties, Core Based Statistical Areas and ZIP codes used for territory design, market sizing and advisor mapping.", [
     ("US County", [
       ("County FIPS Code", "Five-digit state + county FIPS / ANSI code.", "Geographic Unit", "Code", "External (US Census FIPS)", "36119", "US Census (FIPS)", "", "Y"),
       ("County CBSA Code", "CBSA to which the county belongs under the current OMB delineation.", "Geographic Unit", "Code", "External (OMB CBSA)", "35620", "OMB CBSA", "", ""),
     ]),
     ("Core Based Statistical Area", [
       ("CBSA Code", "Five-digit OMB code of the metropolitan or micropolitan statistical area.", "Geographic Unit", "Code", "External (OMB CBSA)", "35620", "OMB CBSA", "US Census (FIPS)", "Y"),
       ("CBSA Title", "Official title of the CBSA.", "Geographic Unit", "Text", "", "New York-Newark-Jersey City, NY-NJ", "OMB CBSA", "", ""),
       ("CBSA Type", "Whether the CBSA is a metropolitan or micropolitan statistical area.", "Geographic Unit", "Code", "CBSA Type", "Metropolitan", "OMB CBSA", "", ""),
       ("Delineation Bulletin", "OMB bulletin that defines the delineation in force (vintage).", "Geographic Unit", "Text", "", "OMB Bulletin 23-01", "OMB CBSA", "", ""),
     ]),
     ("ZIP Code & ZCTA", [
       ("ZIP Code", "Five-digit USPS ZIP code.", "Geographic Unit", "Code", "External (USPS)", "10601", "USPS", "", "Y"),
       ("ZCTA Code", "Census ZIP Code Tabulation Area that approximates the ZIP code for statistical mapping.", "Geographic Unit", "Code", "External (US Census ZCTA)", "10601", "US Census (ZCTA)", "", ""),
       ("Preferred County", "County holding the largest share of the ZIP code's addresses, used for single-county assignment.", "Geographic Unit", "Code", "External (US Census FIPS)", "36119", "HUD-USPS Crosswalk", "", ""),
     ]),
   ]),
   ("UK & EU Statistical & Postal Geography", "UK postcode units and ITL regions, and EU NUTS regions, used for European territory design and reporting.", [
     ("UK Postcode", [
       ("Postcode District", "Outward code (area + district) of a UK postcode; the usual territory building block.", "Geographic Unit", "Code", "External (ONS NSPL)", "EC2V", "ONS (postcodes)", "", "Y"),
       ("Local Authority District Code", "Nine-character GSS code of the local authority district containing the postcode.", "Geographic Unit", "Code", "External (ONS GSS)", "E09000001", "ONS (postcodes)", "", ""),
     ]),
     ("ITL Region", [
       ("ITL Code", "International Territorial Level code at ITL1, ITL2 or ITL3.", "Geographic Unit", "Code", "External (ONS ITL)", "TLI3", "ONS ITL", "Eurostat NUTS", "Y"),
       ("ITL Level", "Level of the ITL region (1, 2 or 3).", "Geographic Unit", "Integer", "", "2", "ONS ITL", "", ""),
     ]),
     ("NUTS Region", [
       ("NUTS Code", "Eurostat NUTS code at level 1, 2 or 3 (country code + up to three characters).", "Geographic Unit", "Code", "External (Eurostat NUTS)", "DE212", "Eurostat NUTS", "", "Y"),
       ("NUTS Level", "Level of the NUTS region (0-3).", "Geographic Unit", "Integer", "", "3", "Eurostat NUTS", "", ""),
     ]),
   ]),
   ("Geographic Unit & Hierarchy", "The generic, effective-dated geographic record and the parent-child hierarchies that roll units up (ZIP > county > CBSA > state > country; postcode district > ITL3 > ITL1 > nation).", [
     ("Geographic Unit", [
       ("Geographic Unit ID", "Enterprise identifier of any geographic unit, independent of scheme.", "Geographic Unit", "Identifier", "", "GEO-US-CBSA-35620", "Internal", "", "Y"),
       ("Geographic Unit Type", "Type of unit (country, subdivision, county, CBSA, ZIP, ZCTA, postcode district, ITL, NUTS, city, group).", "Geographic Unit", "Code", "Geographic Unit Type", "CBSA", "Internal", "", "Y"),
       ("Geographic Scheme", "External scheme or authority that defines the unit's code.", "Geographic Unit", "Code", "Geographic Scheme", "OMB CBSA", "Internal", "", ""),
       ("Scheme Code", "The unit's code within its scheme.", "Geographic Unit", "Code", "Firm-defined (per scheme)", "35620", "Internal", "", ""),
       ("Geographic Unit Name", "Display name of the unit.", "Geographic Unit", "Text", "", "New York-Newark-Jersey City, NY-NJ", "Internal", "", ""),
       ("Scheme Vintage", "Version or release of the external scheme the unit comes from.", "Geographic Unit", "Text", "", "OMB Bulletin 23-01", "Internal", "", "Y"),
       ("Country", "Country containing the unit.", "Geographic Unit", "Code", "ISO 3166-1 alpha-2", "US", "ISO 3166", "", ""),
       ("Successor Geographic Unit", "Unit that replaces this one after a boundary or code change.", "Geographic Unit", "Reference (Geographic Unit)", "", "GEO-GB-ITL2-TLI7", "Internal", "", ""),
       ("Geographic Unit Status", "Lifecycle status of the unit in the enterprise list.", "Geographic Unit", "Code", "Reference Record Status", "Active", "Internal", "", ""),
       ("Effective From", "Date the unit became valid.", "Geographic Unit", "Date", "ISO 8601", "2023-07-21", "Internal", "", ""),
       ("Effective To", "Date the unit ceased to be valid.", "Geographic Unit", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Geographic Hierarchy", [
       ("Geographic Hierarchy Type", "Named hierarchy the parent-child link belongs to.", "Geographic Unit", "Code", "Geographic Hierarchy Type", "US Statistical (ZIP > County > CBSA)", "Internal", "", ""),
       ("Parent Geographic Unit", "Parent of the unit in this hierarchy.", "Geographic Unit", "Reference (Geographic Unit)", "", "GEO-US-ST-36", "Internal", "", "Y"),
       ("Child Geographic Unit", "Child of the unit in this hierarchy.", "Geographic Unit", "Reference (Geographic Unit)", "", "GEO-US-CNTY-36119", "Internal", "", ""),
       ("Hierarchy Effective From", "Date the link became valid.", "Geographic Unit", "Date", "ISO 8601", "2023-07-21", "Internal", "", ""),
     ]),
   ]),
   ("Geographic Groupings", "Firm-defined groups of geographic units: sales regions, EU/UK country clusters, regulatory regions and reporting regions. Territories (07) and market scopes in other domains are built from them.", [
     ("Geographic Group", [
       ("Geographic Group ID", "Identifier of the group (a Geographic Unit of type Group).", "Geographic Group", "Identifier", "", "GEO-GRP-EU-DACH", "Internal", "", "Y"),
       ("Geographic Group Name", "Name of the group.", "Geographic Group", "Text", "", "DACH (Germany, Austria, Switzerland)", "Internal", "", ""),
       ("Geographic Group Type", "Purpose of the group.", "Geographic Group", "Code", "Geographic Group Type", "Country Cluster", "Internal", "", "Y"),
       ("Consuming Domains", "Business domains that use the group.", "Geographic Group", "Code (multi)", "Business Domain", "03 Sales; 07 Compensation & Territory", "Internal", "", ""),
     ]),
     ("Geographic Group Membership", [
       ("Member Geographic Unit", "Geographic unit (or nested group) included in the group.", "Geographic Group", "Reference (Geographic Unit)", "", "GEO-AT", "Internal", "", "Y"),
       ("Membership Type", "Whether the unit is included or explicitly excluded (e.g. a state minus a county).", "Geographic Group", "Code", "Membership Type", "Include", "Internal", "", ""),
       ("Membership Effective From", "Date the unit joined the group.", "Geographic Group", "Date", "ISO 8601", "2027-01-01", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Time Zones & Calendars", "SR-CAL",
  "Time zones and the calendars that determine business days, holidays, market and fund dealing days, fiscal periods and reporting periods across the US, UK and EU.",
  [
   ("Time Zones", "IANA time zones used for cut-off times, valuation points and timestamps.", [
     ("Time Zone", [
       ("IANA Time Zone ID", "Area/Location identifier from the IANA time zone database; the enterprise key for time zone.", "Time Zone", "Code", "IANA Time Zone", "America/New_York", "IANA tz", "", "Y"),
       ("Daylight Saving Indicator", "Whether the zone observes daylight saving time.", "Time Zone", "Boolean", "", "Y", "IANA tz", "", ""),
       ("tzdata Release", "IANA tzdata release loaded (rules change several times a year).", "Time Zone", "Text", "", "2026b", "IANA tz", "", ""),
     ]),
   ]),
   ("Business & Holiday Calendars", "Calendars of business days and holidays by country, subdivision, market, settlement system or firm.", [
     ("Calendar", [
       ("Calendar ID", "Identifier of the calendar.", "Calendar", "Identifier", "", "CAL-US-NYSE", "Internal", "", "Y"),
       ("Calendar Name", "Name of the calendar.", "Calendar", "Text", "", "NYSE Trading Calendar", "Internal", "", ""),
       ("Calendar Type", "Kind of calendar.", "Calendar", "Code", "Calendar Type", "Exchange", "Internal", "", "Y"),
       ("Calendar Country", "Country the calendar applies to, where it is national.", "Calendar", "Code", "ISO 3166-1 alpha-2", "US", "ISO 3166", "", ""),
       ("Exchange MIC", "Market Identifier Code for exchange calendars.", "Calendar", "Code", "ISO 10383 (MIC)", "XNYS", "ISO 10383", "", ""),
       ("Calendar Time Zone", "Time zone in which calendar days start and end.", "Calendar", "Code", "IANA Time Zone", "America/New_York", "IANA tz", "", ""),
       ("Weekend Days", "Days of the week that are non-business days by default.", "Calendar", "Code (multi)", "Day of Week", "Saturday; Sunday", "Internal", "ISO 8601", ""),
       ("Calendar Source", "Authority or vendor publishing the holiday dates.", "Calendar", "Code", "Calendar Source", "Exchange Publication", "Internal", "", ""),
     ]),
     ("Composite Calendar", [
       ("Component Calendar", "Calendar combined into a composite (e.g. TARGET + London for a EUR/GBP settlement).", "Calendar", "Reference (Calendar)", "", "CAL-EU-TARGET", "Internal", "", ""),
       ("Combination Rule", "How the component calendars are combined.", "Calendar", "Code", "Calendar Combination Rule", "Holiday if Any Component Closed", "Internal", "", ""),
     ]),
     ("Calendar Date", [
       ("Calendar Date", "Date the entry applies to.", "Calendar Date", "Date", "ISO 8601", "2026-11-26", "ISO 8601", "", "Y"),
       ("Day Type", "Status of the date in the calendar.", "Calendar Date", "Code", "Day Type", "Holiday", "Internal", "", "Y"),
       ("Holiday Name", "Name of the holiday or closure.", "Calendar Date", "Text", "", "Thanksgiving Day", "Internal", "", ""),
     ]),
   ]),
   ("Fund Dealing Calendars", "Structure of fund dealing calendars: which underlying calendars and rules decide whether a fund deals on a day. 01 Product references the calendar by CAL- ID; dealing cut-off and valuation point stay in 01.", [
     ("Dealing Calendar Rule", [
       ("Dealing Calendar ID", "Calendar ID of the dealing calendar (Calendar Type = Fund Dealing).", "Calendar", "Identifier", "", "CAL-LU-01", "Internal", "", "Y"),
       ("Base Business Calendar", "Calendar of the fund's domicile / administrator whose business days are candidate dealing days.", "Calendar", "Reference (Calendar)", "", "CAL-LU-BANK", "Internal", "", "Y"),
       ("Market Closure Calendars", "Exchange calendars whose closure can make a day non-dealing.", "Calendar", "Reference (Calendar)", "", "CAL-US-NYSE; CAL-GB-XLON", "Internal", "", ""),
       ("Non-Dealing Day Threshold", "Share of portfolio assets traded on closed markets above which the day is non-dealing, as set in the prospectus.", "Calendar", "Percentage", "", "30%", "Prospectus", "", ""),
       ("Dealing Day Pattern", "Pattern of dealing days within the business days (daily, weekly on a weekday, month-end).", "Calendar", "Code", "Dealing Day Pattern", "Every Business Day", "Internal", "openfunds", ""),
     ]),
   ]),
   ("Fiscal Calendar & Periods", "The firm's fiscal calendar(s) and fiscal periods, used by Finance and every domain that reports on fiscal months, quarters and years.", [
     ("Fiscal Calendar", [
       ("Fiscal Calendar ID", "Calendar ID of the fiscal calendar (Calendar Type = Fiscal).", "Calendar", "Identifier", "", "CAL-FISCAL-GRP", "Internal", "", ""),
       ("Fiscal Year Start", "Month and day the fiscal year begins.", "Calendar", "Text", "MM-DD", "01-01", "Internal", "", ""),
       ("Period Structure", "Division of the fiscal year into periods.", "Calendar", "Code", "Fiscal Period Structure", "12 Calendar Months", "Internal", "", ""),
     ]),
     ("Fiscal Period", [
       ("Fiscal Period ID", "Identifier of the fiscal period.", "Fiscal Period", "Identifier", "", "FY2026-P09", "Internal", "", "Y"),
       ("Fiscal Year", "Fiscal year the period belongs to.", "Fiscal Period", "Integer", "", "2026", "Internal", "", ""),
       ("Fiscal Period Type", "Granularity of the period.", "Fiscal Period", "Code", "Period Type", "Month", "Internal", "", ""),
       ("Period Start Date", "First day of the period.", "Fiscal Period", "Date", "ISO 8601", "2026-09-01", "Internal", "", ""),
       ("Period End Date", "Last day of the period.", "Fiscal Period", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
       ("Fiscal Period Status", "Accounting status of the period (owned by 10 Finance; mirrored here for consumers).", "Fiscal Period", "Code", "Fiscal Period Status", "Open", "Internal", "", ""),
     ]),
   ]),
   ("Reporting Period Definitions", "Standard period definitions (month-to-date, quarter, rolling 12 months, since inception) and as-of conventions shared by sales, AUM, compensation, finance and client reporting. Close and lock dates for a domain's own results stay in that domain (e.g. 06 TX-SNP).", [
     ("Reporting Period Definition", [
       ("Reporting Period Definition Code", "Code of the standard period definition.", "Reporting Period Definition", "Code", "Reporting Period Basis", "QTD", "Internal", "", ""),
       ("Period Basis Calendar", "Calendar the period is computed on (Gregorian or fiscal).", "Reporting Period Definition", "Reference (Calendar)", "", "CAL-FISCAL-GRP", "Internal", "", ""),
       ("As-Of Date Convention", "Rule for the as-of date of a period end.", "Reporting Period Definition", "Code", "As-Of Date Convention", "Last Business Day", "Internal", "GIPS", "Y"),
       ("Business Day Convention", "Rule used to adjust a date that falls on a non-business day.", "Reporting Period Definition", "Code", "Business Day Convention", "Preceding", "ISDA", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Currency & FX Reference", "SR-CCY",
  "ISO 4217 currencies and the reference data describing FX rate types, sources and conventions used for valuation, reporting translation, fee and compensation calculations. FX rate time series are out of scope.",
  [
   ("Currency", "Currencies, funds codes and precious metals, with minor units and firm usage flags.", [
     ("Currency", [
       ("Currency Code", "Three-letter ISO 4217 alphabetic code; the enterprise key for currency.", "Currency", "Code", "ISO 4217", "GBP", "ISO 4217", "", "Y"),
       ("Currency Numeric Code", "Three-digit ISO 4217 numeric code.", "Currency", "Code", "ISO 4217", "826", "ISO 4217", "", ""),
       ("Currency Name", "Official English name of the currency.", "Currency", "Text", "", "Pound Sterling", "ISO 4217", "", ""),
       ("Minor Unit", "Number of decimal places of the minor unit (0-4), used for rounding and display of amounts.", "Currency", "Integer", "", "2", "ISO 4217", "", "Y"),
       ("Currency Type", "Kind of ISO 4217 entry.", "Currency", "Code", "Currency Type", "National Currency", "ISO 4217", "", ""),
       ("Currency Status", "Whether the code is current or historic in ISO 4217.", "Currency", "Code", "Currency Status", "Current", "ISO 4217", "", ""),
       ("Withdrawal Date", "Date the currency was withdrawn (ISO 4217 List Three).", "Currency", "Date", "ISO 8601", "2026-01-01", "ISO 4217", "", ""),
       ("Replacement Currency", "Currency that replaced a withdrawn currency, with the fixed conversion rate in notes.", "Currency", "Code", "ISO 4217", "EUR", "ISO 4217", "", "", "e.g. BGN replaced by EUR at 1.95583 from 2026-01-01 (ISO 4217 Amendment 180)."),
       ("Group Reporting Currency Indicator", "Whether the currency is a firm reporting currency for AUM, flows or financials.", "Currency", "Boolean", "", "N", "Internal", "", ""),
     ]),
     ("Currency Pair Convention", [
       ("Currency Pair", "Base and quote currency in market order.", "Currency", "Code", "Firm-defined (ISO 4217 pair)", "EURUSD", "Internal", "LSEG WM/Reuters", ""),
     ]),
   ]),
   ("FX Rate Types & Sources", "Named FX rate types (e.g. WM/Reuters 4pm London close, ECB reference rate) and the rules for which type each process uses.", [
     ("FX Rate Source", [
       ("FX Rate Source Code", "Code of the benchmark administrator or provider of rates.", "FX Rate Type", "Code", "FX Rate Source", "LSEG WM/Reuters", "Internal", "", ""),
       ("Benchmark Regulatory Status", "Status of the rate under EU / UK benchmark regulation.", "FX Rate Type", "Code", "Benchmark Regulatory Status", "Critical Benchmark (UK)", "UK BMR", "EU BMR", ""),
       ("Licensed Dataset", "Dataset under which the rates are licensed (owned by 14).", "FX Rate Type", "Reference (Dataset)", "", "DSET-0042", "Internal", "", ""),
     ]),
     ("FX Rate Type", [
       ("FX Rate Type Code", "Code of the rate type.", "FX Rate Type", "Code", "FX Rate Type", "WMR London 4pm Close Mid", "Internal", "", "Y"),
       ("FX Rate Type Name", "Descriptive name.", "FX Rate Type", "Text", "", "WM/Reuters London 4pm Closing Spot Mid", "LSEG WM/Reuters", "", ""),
       ("Fixing Time", "Time the rate is fixed or snapped.", "FX Rate Type", "Time", "HH:MM + time zone", "16:00 Europe/London", "LSEG WM/Reuters", "ECB", "Y"),
       ("Rate Side", "Side of the market the rate represents.", "FX Rate Type", "Code", "Rate Side", "Mid", "LSEG WM/Reuters", "", ""),
       ("Publication Calendar", "Calendar of days on which the rate is published.", "FX Rate Type", "Reference (Calendar)", "", "CAL-EU-TARGET", "ECB", "", ""),
       ("Quote Convention", "Whether rates are stored as base-per-quote per market convention or always against a pivot currency.", "FX Rate Type", "Code", "FX Quote Convention", "Units of Quote per 1 EUR", "ECB", "", "Y"),
       ("Fallback Rule", "Rule applied when the rate is not published for a date.", "FX Rate Type", "Code", "FX Fallback Rule", "Previous Published Rate", "Internal", "", ""),
       ("Approved Usage", "Processes for which the rate type is approved.", "FX Rate Type", "Code (multi)", "FX Rate Usage", "AUM Reporting Translation; Fee Calculation", "Internal", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Languages, Locales & Units", "SR-LOC",
  "Languages, BCP 47 locales, units of measure and the number, date and rounding conventions used in documents, digital channels, data exchange and reporting.",
  [
   ("Languages & Locales", "Languages and locale tags supported by the firm's documents, websites and client communications.", [
     ("Language", [
       ("Language Code (ISO 639-1)", "Two-letter language code; the enterprise key where one exists.", "Language", "Code", "ISO 639-1", "de", "ISO 639", "", "Y"),
       ("Language Code (ISO 639-3)", "Three-letter code, for languages without a two-letter code.", "Language", "Code", "ISO 639-3", "deu", "ISO 639", "", ""),
       ("Language Name (English)", "English name of the language.", "Language", "Text", "", "German", "ISO 639", "", ""),
       ("Firm-Supported Language Indicator", "Whether the firm produces client documents or web content in the language.", "Language", "Boolean", "", "Y", "Internal", "", ""),
     ]),
     ("Locale", [
       ("Locale Tag", "BCP 47 language tag combining language, optional script and region.", "Locale", "Code", "External (BCP 47)", "de-AT", "IETF BCP 47", "Unicode CLDR", "Y"),
       ("Fallback Locale", "Locale used when content is unavailable in this locale.", "Locale", "Code", "External (BCP 47)", "de-DE", "Internal", "", ""),
       ("Locale Usage", "Channels where the locale is enabled.", "Locale", "Code (multi)", "Locale Usage", "Website; Client Documents", "Internal", "", ""),
     ]),
   ]),
   ("Units & Formats", "Units of measure and enterprise conventions for numbers, dates and rounding.", [
     ("Unit of Measure", [
       ("Unit Code", "Code of the unit (UCUM or UN/ECE Recommendation 20 where available).", "Unit", "Code", "External (UN/ECE Rec 20)", "P1", "UN/ECE Rec 20", "UCUM", "", "P1 = percent."),
       ("Unit Name", "Name of the unit.", "Unit", "Text", "", "Percent", "UN/ECE Rec 20", "", ""),
       ("Unit Category", "Quantity the unit measures.", "Unit", "Code", "Unit Category", "Ratio", "Internal", "", ""),
       ("Conversion Factor to Base", "Multiplier converting the unit to the category's base unit.", "Unit", "Decimal", "", "0.01", "Internal", "", "", "e.g. 1 bp = 0.0001; 1 % = 0.01."),
     ]),
     ("Number & Date Convention", [
       ("Decimal Separator", "Character separating integer and fraction for the locale.", "Locale", "Text", "", ",", "Unicode CLDR", "", ""),
       ("Display Date Pattern", "Date pattern shown to users for the locale (storage always ISO 8601).", "Locale", "Text", "", "dd.MM.yyyy", "Unicode CLDR", "ISO 8601", ""),
       ("Rounding Rule", "Enterprise rounding method for amounts, rates and percentages.", "All", "Code", "Rounding Rule", "Half Even", "Internal", "", ""),
       ("Percentage Storage Convention", "How percentages are stored in data exchange (decimal fraction or percent).", "All", "Code", "Percentage Storage Convention", "Decimal Fraction", "Internal", "", "Y", "Avoids the frequent 0.75 vs 0.0075 error in fee and rate feeds."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Internal Legal Entities", "SR-LEN",
  "The firm's own legal entities (holding companies, investment advisers, broker-dealers, management companies, AIFMs, FCA-authorised firms and branches), their group hierarchy, identifiers, entity-level regulatory authorisations and passports, and the roles they perform in distribution.",
  [
   ("Legal Entity Master", "Identity, legal form and status of each group legal entity.", [
     ("Internal Legal Entity", [
       ("Legal Entity ID", "Enterprise identifier of the internal legal entity.", "Legal Entity", "Identifier", "", "LEN-0004", "Internal", "FIBO BE", "Y"),
       ("Legal Name", "Registered legal name.", "Legal Entity", "Text", "", "Example Asset Management S.A.", "GLEIF LEI-CDF", "FIBO BE", "Y"),
       ("Entity Legal Form", "ISO 20275 Entity Legal Form code.", "Legal Entity", "Code", "ISO 20275", "5GGB (Société anonyme, LU)", "ISO 20275", "GLEIF LEI-CDF", "", "Example ELF code illustrative; verify against the GLEIF ELF list."),
       ("Entity Category", "Business category of the entity within the group.", "Legal Entity", "Code", "Internal Entity Category", "Management Company / AIFM", "Internal", "FIBO FBC", "Y"),
       ("Jurisdiction of Formation", "Country or subdivision under whose law the entity is formed.", "Legal Entity", "Code", "ISO 3166-2", "LU", "GLEIF LEI-CDF", "", "", "Use ISO 3166-2 where formation is at state level, e.g. US-DE."),
       ("Company Registration Number", "Number in the company / trade register.", "Legal Entity", "Text", "", "B123456", "GLEIF LEI-CDF", "", ""),
       ("Entity Status", "Lifecycle status of the entity.", "Legal Entity", "Code", "Legal Entity Status", "Active", "GLEIF LEI-CDF", "", ""),
       ("Branch Indicator", "Whether the record is a branch (not a separate legal person) of another entity.", "Legal Entity", "Boolean", "", "N", "GLEIF LEI-CDF", "FIBO BE", ""),
       ("Head Office Entity", "Legal entity of which this record is a branch.", "Legal Entity", "Reference (Legal Entity)", "", "LEN-0002", "GLEIF LEI-CDF", "", ""),
       ("Accounting Company Code", "Company code of the entity in the general ledger (owned by 10 Finance).", "Legal Entity", "Code", "Firm-defined", "4100", "Internal", "", ""),
       ("Party Master Cross-Reference", "PTY- record representing the same entity in the party master, used where domains model counterparties generically.", "Legal Entity", "Reference (Party)", "", "PTY-0015", "Internal", "", "Y"),
     ]),
     ("Legal Entity Identifier", [
       ("LEI", "20-character Legal Entity Identifier.", "Legal Entity", "Identifier", "ISO 17442", "5493001ABCDEXAMPLE12", "ISO 17442 (GLEIF)", "GLEIF LEI-CDF", "Y", "Example LEI illustrative."),
       ("LEI Registration Status", "GLEIF registration status of the LEI.", "Legal Entity", "Code", "LEI Registration Status", "ISSUED", "GLEIF LEI-CDF", "", "Y"),
       ("LEI Next Renewal Date", "Date by which the LEI must be renewed to avoid lapsing.", "Legal Entity", "Date", "ISO 8601", "2027-03-14", "GLEIF LEI-CDF", "", ""),
       ("SEC CIK", "SEC Central Index Key of the entity for EDGAR filings.", "Legal Entity", "Identifier", "", "0001234567", "SEC EDGAR", "", ""),
       ("Firm CRD Number", "FINRA Central Registration Depository number of the firm (own entities only; external firms are in 02).", "Legal Entity", "Identifier", "", "123456", "FINRA", "SEC Form ADV", ""),
       ("FCA Firm Reference Number", "FCA FRN of a UK-authorised entity.", "Legal Entity", "Identifier", "", "123456", "FCA Register", "", ""),
     ]),
   ]),
   ("Group Structure & Ownership", "Effective-dated ownership and consolidation links between internal entities, aligned to GLEIF Level 2 and FIBO ownership and control.", [
     ("Entity Ownership Relationship", [
       ("Child Entity", "Entity that is owned or consolidated.", "Legal Entity", "Reference (Legal Entity)", "", "LEN-0004", "GLEIF RR-CDF", "FIBO BE", ""),
       ("Parent Entity", "Entity that owns or consolidates the child.", "Legal Entity", "Reference (Legal Entity)", "", "LEN-0001", "GLEIF RR-CDF", "FIBO BE", "Y"),
       ("Relationship Type", "Nature of the parent link.", "Legal Entity", "Code", "Ownership Relationship Type", "Direct Accounting Consolidation Parent", "GLEIF RR-CDF", "FIBO BE", "Y"),
       ("Ownership Percentage", "Share of equity held by the parent.", "Legal Entity", "Percentage", "", "100%", "FIBO BE", "", ""),
       ("Level 2 Reporting Exception", "Reason reported to GLEIF when no parent LEI is reported.", "Legal Entity", "Code", "GLEIF Reporting Exception", "NATURAL_PERSONS", "GLEIF RR-CDF", "", ""),
       ("Ownership Effective From", "Date the relationship started.", "Legal Entity", "Date", "ISO 8601", "2004-05-12", "GLEIF RR-CDF", "", ""),
     ]),
   ]),
   ("Regulatory Authorisations", "Entity-level registrations, licences and authorisations held with regulators (SEC, FINRA, FCA, CSSF, CBI and others), with permissions and conditions. Individual licences stay in 08 (LIC-).", [
     ("Entity Authorisation", [
       ("Authorisation ID", "Identifier of the entity authorisation record.", "Authorisation", "Identifier", "", "AUTH-0012", "Internal", "", "Y"),
       ("Authorised Entity", "Legal entity holding the authorisation.", "Authorisation", "Reference (Legal Entity)", "", "LEN-0004", "Internal", "", "Y"),
       ("Regulator", "Regulator or self-regulatory organisation granting the authorisation.", "Authorisation", "Code", "Regulator", "CSSF", "Internal", "", "Y"),
       ("Authorisation Type", "Kind of registration or licence.", "Authorisation", "Code", "Entity Authorisation Type", "UCITS Management Company (Chapter 15)", "Internal", "UCITS Directive", "Y"),
       ("Regulator Reference Number", "Number assigned by the regulator (SEC 801- file number, CRD, FRN, CSSF / CBI reference).", "Authorisation", "Identifier", "", "S00001234", "Internal", "FCA Register", "Y", "CSSF example format unverified."),
       ("Authorisation Status", "Current status with the regulator.", "Authorisation", "Code", "Authorisation Status", "Authorised", "Internal", "FCA Register", "Y"),
       ("Authorisation Effective Date", "Date the authorisation took effect.", "Authorisation", "Date", "ISO 8601", "2005-01-20", "Internal", "", ""),
       ("Permitted Activities", "Regulated activities or services covered (FCA Part 4A permissions, UCITS / AIFMD functions, MiFID top-up services, BD business lines).", "Authorisation", "Code (multi)", "Regulated Activity", "Collective Portfolio Management (UCITS); Investment Advice (MiFID top-up)", "FCA Handbook", "AIFMD", "Y"),
       ("Requirements / Limitations", "Conditions, limitations or requirements imposed by the regulator.", "Authorisation", "Text", "", "May not hold client money", "FCA Register", "", ""),
       ("Annual Filing Due Date", "Next periodic filing date for the registration (e.g. Form ADV annual updating amendment within 90 days of fiscal year end).", "Authorisation", "Date", "ISO 8601", "2027-03-31", "SEC Form ADV", "", ""),
     ]),
     ("Cross-Border Passport", [
       ("Passport Home Entity", "Entity exercising the passport.", "Passport", "Reference (Legal Entity)", "", "LEN-0004", "UCITS Directive", "", ""),
       ("Host Country", "Country into which the passport is exercised.", "Passport", "Code", "ISO 3166-1 alpha-2", "DE", "UCITS Directive", "AIFMD", "Y"),
       ("Passport Type", "Directive and service under which the passport is notified.", "Passport", "Code", "Passport Type", "UCITS ManCo - Freedom to Provide Services", "UCITS Directive", "AIFMD", "Y"),
       ("Notification Date", "Date the home regulator transmitted the notification.", "Passport", "Date", "ISO 8601", "2019-03-01", "UCITS Directive", "", ""),
       ("Passport Status", "Status of the passport.", "Passport", "Code", "Authorisation Status", "Authorised", "Internal", "", ""),
       ("Passport Effective From / To", "Effective period of the passport.", "Passport", "Text", "ISO 8601", "2019-03-15 / ", "Internal", "", "", "Product-level marketing notifications stay in 01 (registration) and 08 (cross-border marketing)."),
     ]),
   ]),
   ("Entity Roles in Distribution", "Which group entity performs which distribution role in which market, channel or product range. Fund-specific service-provider roles stay in 01 (Product Party Role).", [
     ("Entity Distribution Role", [
       ("Role Entity", "Entity performing the role.", "Entity Role", "Reference (Legal Entity)", "", "LEN-0003", "Internal", "FIBO FBC", "Y"),
       ("Distribution Role", "Role performed.", "Entity Role", "Code", "Entity Distribution Role", "Principal Underwriter / Distributor", "Internal", "FIBO FBC", "Y"),
       ("Role Market Scope", "Markets in which the entity performs the role.", "Entity Role", "Reference (Geographic Group)", "", "GEO-GRP-US", "Internal", "", ""),
       ("Role Channel Scope", "Channels in which the entity performs the role.", "Entity Role", "Code (multi)", "Firm-defined (enterprise Distribution Channel)", "Intermediary; Retirement / DCIO", "Internal", "", ""),
       ("Role Product Scope", "Product range or vehicle types covered.", "Entity Role", "Text", "", "All '40 Act mutual funds and ETFs", "Internal", "", ""),
       ("Default Contracting Entity Indicator", "Whether the entity signs distribution agreements (05) for this role and scope by default.", "Entity Role", "Boolean", "", "Y", "Internal", "", ""),
       ("Role Effective From", "Date the role started.", "Entity Role", "Date", "ISO 8601", "2010-01-01", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Internal Organisation", "SR-ORG",
  "Business units, departments, teams, cost and profit centres, offices and the effective-dated hierarchies and reorganisations that structure the firm internally.",
  [
   ("Org Units", "Units of the internal organisation and their attributes.", [
     ("Org Unit", [
       ("Org Unit ID", "Enterprise identifier of the org unit.", "Org Unit", "Identifier", "", "OU-DIST-US-WEST", "Internal", "", "Y"),
       ("Org Unit Name", "Name of the unit.", "Org Unit", "Text", "", "US Wholesale Distribution - West", "Internal", "", ""),
       ("Org Unit Type", "Kind of unit.", "Org Unit", "Code", "Org Unit Type", "Department", "Internal", "", "Y"),
       ("Business Function", "Enterprise function the unit belongs to.", "Org Unit", "Code", "Business Function", "Distribution", "Internal", "", ""),
       ("Employing / Booking Entity", "Legal entity in which the unit's staff and costs are booked.", "Org Unit", "Reference (Legal Entity)", "", "LEN-0003", "Internal", "", "Y"),
       ("Unit Head", "Employee leading the unit.", "Org Unit", "Reference (Employee)", "", "EMP-10233", "Internal", "", "", "PII (name resolved via the employee record)."),
       ("Org Unit Effective From", "Date the unit was created.", "Org Unit", "Date", "ISO 8601", "2024-01-01", "Internal", "", ""),
     ]),
     ("Cost & Profit Centre", [
       ("Cost Centre Code", "General-ledger cost centre to which the unit's costs are booked (code list owned by 10 Finance).", "Org Unit", "Code", "Firm-defined", "CC-41020", "Internal", "", "Y"),
       ("Profit Centre Code", "Profit centre the unit reports into for management P&L.", "Org Unit", "Code", "Firm-defined", "PC-DIST-US", "Internal", "", ""),
     ]),
     ("Office Location", [
       ("Office ID", "Identifier of an office or site.", "Office", "Identifier", "", "SITE-US-SFO", "Internal", "", ""),
       ("Office Country / Subdivision", "Location of the office.", "Office", "Code", "ISO 3166-2", "US-CA", "ISO 3166", "", ""),
       ("Office Time Zone", "Time zone of the office.", "Office", "Code", "IANA Time Zone", "America/Los_Angeles", "IANA tz", "", ""),
       ("Office Legal Entity", "Legal entity occupying or registering the office (e.g. FINRA branch office of the BD).", "Office", "Reference (Legal Entity)", "", "LEN-0003", "Internal", "FINRA", ""),
     ]),
   ]),
   ("Org Hierarchies", "Parallel, effective-dated hierarchies over org units (management, legal, cost centre).", [
     ("Org Hierarchy Link", [
       ("Org Hierarchy Type", "Hierarchy the link belongs to.", "Org Unit", "Code", "Org Hierarchy Type", "Management", "Internal", "", "Y"),
       ("Parent Org Unit", "Parent of the unit in this hierarchy.", "Org Unit", "Reference (Org Unit)", "", "OU-DIST-US", "Internal", "", "Y"),
       ("Child Org Unit", "Child of the unit in this hierarchy.", "Org Unit", "Reference (Org Unit)", "", "OU-DIST-US-WEST", "Internal", "", ""),
       ("Link Effective From", "Date the link became valid.", "Org Unit", "Date", "ISO 8601", "2024-01-01", "Internal", "", ""),
     ]),
     ("Org Unit Assignment", [
       ("Assigned Employee", "Employee assigned to the unit (sourced from the HR system).", "Org Unit", "Reference (Employee)", "", "EMP-20417", "Internal", "", "", "PII. See the workforce master recommendation in Source_Notes.md."),
       ("Assigned Org Unit", "Unit the employee belongs to.", "Org Unit", "Reference (Org Unit)", "", "OU-DIST-US-WEST", "Internal", "", ""),
       ("Assignment Effective From / To", "Validity of the assignment.", "Org Unit", "Text", "ISO 8601", "2025-04-01 / ", "Internal", "", ""),
     ]),
   ]),
   ("Reorganisations", "Governed changes to the organisation that merge, split, move or close units, with the mapping used to restate history.", [
     ("Reorganisation Event", [
       ("Reorganisation ID", "Identifier of the reorganisation.", "Reorganisation", "Identifier", "", "REORG-2027-01", "Internal", "", ""),
       ("Reorganisation Type", "Kind of change.", "Reorganisation", "Code", "Reorganisation Type", "Split", "Internal", "", ""),
       ("Reorganisation Effective Date", "Date the new structure takes effect.", "Reorganisation", "Date", "ISO 8601", "2027-01-01", "Internal", "", "Y"),
       ("Source Org Units", "Units affected before the change.", "Reorganisation", "Reference (Org Unit)", "", "OU-DIST-US-WEST", "Internal", "", ""),
       ("Target Org Units", "Units resulting from the change.", "Reorganisation", "Reference (Org Unit)", "", "OU-DIST-US-PNW; OU-DIST-US-SW", "Internal", "", ""),
       ("History Restatement Rule", "Whether history is restated to the new structure or kept as booked.", "Reorganisation", "Code", "Restatement Rule", "Restate Prior Periods", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Industry Classification", "SR-IND",
  "Scheme metadata, hierarchical codes and concordances of the industry classification systems used to classify organisations (NAICS, US SIC, NACE, UK SIC, GICS). Assignment of codes to parties stays in 02.",
  [
   ("Classification Schemes", "Industry classification schemes and versions held by the enterprise.", [
     ("Classification Scheme", [
       ("Classification Scheme ID", "Identifier of the scheme version.", "Classification Scheme", "Identifier", "", "ICS-NACE-2.1", "Internal", "", "Y"),
       ("Scheme Name", "Name of the classification system.", "Classification Scheme", "Code", "Industry Classification Scheme", "NACE", "Internal", "", ""),
       ("Scheme Version", "Edition of the scheme.", "Classification Scheme", "Text", "", "Rev. 2.1", "NACE", "", "Y"),
       ("Scheme Jurisdiction", "Country or region where the scheme is the official standard.", "Classification Scheme", "Code", "Firm-defined (ISO 3166 or region)", "EU", "Internal", "", ""),
       ("Number of Levels", "Depth of the hierarchy.", "Classification Scheme", "Integer", "", "4", "NACE", "", ""),
       ("Scheme Effective From", "Date the version came into force.", "Classification Scheme", "Date", "ISO 8601", "2025-01-01", "NACE", "", ""),
       ("Licence Required Indicator", "Whether use of the scheme needs a commercial licence (e.g. GICS); the licence is held in 14.", "Classification Scheme", "Boolean", "", "N", "Internal", "", ""),
     ]),
   ]),
   ("Classification Codes & Concordances", "Hierarchical nodes of each scheme and the correspondence tables between schemes and versions.", [
     ("Classification Code", [
       ("Classification Code", "Code of the node within the scheme.", "Classification Code", "Code", "Firm-defined (per scheme)", "66.30", "NACE", "NAICS", "Y"),
       ("Classification Label", "Official title of the node.", "Classification Code", "Text", "", "Fund management activities", "NACE", "", ""),
       ("Classification Level", "Level of the node in the hierarchy.", "Classification Code", "Integer", "", "4", "NACE", "", ""),
       ("Parent Classification Code", "Code of the node one level up.", "Classification Code", "Code", "Firm-defined (per scheme)", "66.3", "NACE", "", ""),
     ]),
     ("Classification Concordance", [
       ("Source Classification Code", "Code in the source scheme version.", "Classification Code", "Reference (Classification Code)", "", "NAICS 2022: 523940", "NAICS", "", ""),
       ("Target Classification Code", "Corresponding code in the target scheme version.", "Classification Code", "Reference (Classification Code)", "", "NACE Rev. 2.1: 66.30", "NACE", "", "Y"),
       ("Correspondence Type", "Cardinality / quality of the correspondence.", "Classification Code", "Code", "Correspondence Type", "Partial (Many-to-One)", "Internal", "", ""),
       ("Concordance Source", "Published correspondence table used.", "Classification Code", "Text", "", "Eurostat NACE Rev. 2 - Rev. 2.1 correspondence table", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Enterprise Code List Registry", "SR-CLR",
  "Governance metadata for every governed code list in the enterprise (shared, domain-specific and external), its versions, values, consumers and mappings to source-system values, following the ISO/IEC 11179 registry pattern.",
  [
   ("Code List Registry Entry", "Registration and ownership metadata of a code list.", [
     ("Code List", [
       ("Code List ID", "Registry identifier of the code list.", "Code List", "Identifier", "", "CLR-0031", "ISO/IEC 11179", "", "Y"),
       ("Code List Name", "Preferred name of the list.", "Code List", "Text", "", "Distribution Channel", "ISO/IEC 11179", "", "Y"),
       ("Code List Definition", "Business definition of what the list classifies.", "Code List", "Text", "", "Route through which products reach end investors, used for flow, sales and profitability reporting.", "ISO/IEC 11179", "", ""),
       ("Code List Class", "Whether the list is an enterprise shared list, a domain list, an external standard or a vendor list.", "Code List", "Code", "Code List Class", "Enterprise Shared", "Internal", "DAMA-DMBOK", ""),
       ("Source Standard", "External standard the list is taken from or aligned to.", "Code List", "Text", "", "Internal (Cerulli-style channel scheme)", "Internal", "", ""),
       ("Owning Business Domain", "Business domain accountable for the list.", "Code List", "Code", "Business Domain", "09 Shared & Enterprise Reference Data", "Internal", "", "Y"),
       ("Data Owner", "Role accountable for the list's content.", "Code List", "Reference (Employee)", "", "EMP-10044", "DCAM (EDM Council)", "DAMA-DMBOK", "Y"),
       ("Data Steward", "Role maintaining the list day to day.", "Code List", "Reference (Employee)", "", "EMP-10871", "DCAM (EDM Council)", "DAMA-DMBOK", ""),
       ("Registration Status", "Registration status of the list in the registry.", "Code List", "Code", "Registry Status", "Standard", "ISO/IEC 11179", "", "Y"),
       ("Current Version", "Version currently in force.", "Code List", "Reference (Code List Version)", "", "CLV-0031-004", "ISO/IEC 11179", "", ""),
       ("Harmonisation Candidate", "Shared concept the list is a candidate to be merged into during the consolidation exercise.", "Code List", "Code", "Shared Code List Candidate", "Distribution Channel", "Internal", "", "", "Harmonised value sets are out of scope for v0.1."),
       ("Extensibility", "Whether consuming domains may add local values.", "Code List", "Code", "Extensibility", "Closed", "Internal", "", ""),
     ]),
     ("Code List Consumer", [
       ("Consuming Domain", "Business domain that uses the list.", "Code List", "Code", "Business Domain", "06 Sales Transactions & AUM Attribution", "Internal", "", "Y"),
       ("Consuming Attribute", "Attribute ID(s) in the consuming taxonomy that take values from the list.", "Code List", "Text", "", "TX-ACC-014", "Internal", "", ""),
       ("Usage Type", "How the consumer uses the list.", "Code List", "Code", "Code List Usage Type", "Validate and Store", "Internal", "", ""),
     ]),
   ]),
   ("Versions & Values", "Versioned value sets of each list.", [
     ("Code List Version", [
       ("Code List Version ID", "Identifier of the version.", "Code List Version", "Identifier", "", "CLV-0031-004", "ISO/IEC 11179", "", "Y"),
       ("Version Effective From", "Date the version came into force.", "Code List Version", "Date", "ISO 8601", "2027-01-01", "ISO/IEC 11179", "", ""),
       ("Change Summary", "Summary of changes from the previous version.", "Code List Version", "Text", "", "Split 'Bank / Trust' into 'Bank Brokerage' and 'Trust Company'", "Internal", "", ""),
     ]),
     ("Code Value", [
       ("Code", "Stable code of the value.", "Code Value", "Code", "Firm-defined (per list)", "RIA", "ISO/IEC 11179", "", "Y"),
       ("Code Label", "Display label of the value.", "Code Value", "Text", "", "Registered Investment Adviser", "ISO/IEC 11179", "", ""),
       ("Parent Code", "Parent value in a hierarchical list.", "Code Value", "Code", "Firm-defined (per list)", "INTERMEDIARY", "Internal", "", ""),
       ("Code Value Status", "Status of the value.", "Code Value", "Code", "Reference Record Status", "Active", "Internal", "", "Y"),
       ("Replaced By Code", "Value that replaces a deprecated value.", "Code Value", "Code", "Firm-defined (per list)", "", "Internal", "", ""),
     ]),
   ]),
   ("Source-System Mappings", "Crosswalks from values used in source systems and vendor feeds to registered codes. Party-matching crosswalks stay in 06 (XWK-).", [
     ("Code Mapping", [
       ("Code Mapping ID", "Identifier of the mapping row.", "Code Mapping", "Identifier", "", "CLM-0031-00217", "Internal", "", ""),
       ("Source System", "System or vendor feed holding the source value.", "Code Mapping", "Code", "Firm-defined", "Broadridge Distribution Insight", "Internal", "", ""),
       ("Source Value", "Code or text as delivered by the source.", "Code Mapping", "Text", "", "RIA-IND", "Internal", "", "Y"),
       ("Target Code List", "Registered list the value maps into.", "Code Mapping", "Reference (Code List)", "", "CLR-0031", "Internal", "", ""),
       ("Target Code", "Registered code the source value maps to.", "Code Mapping", "Code", "Firm-defined (per list)", "RIA", "Internal", "", "Y"),
       ("Mapping Type", "Semantic match between source and target (SKOS mapping relations).", "Code Mapping", "Code", "Mapping Type", "Exact Match", "W3C SKOS", "ISO/IEC 11179", ""),
       ("Mapping Status", "Approval status of the mapping.", "Code Mapping", "Code", "Mapping Status", "Approved", "Internal", "", ""),
     ]),
   ]),
   ("Change Control", "Requests to add, change or retire code lists and values, and their decisions.", [
     ("Code List Change Request", [
       ("Change Request Reference", "Reference of the request in the governance workflow tool.", "Code List", "Identifier", "", "CR-2026-0145", "Internal", "", ""),
       ("Change Type", "Kind of change requested.", "Code List", "Code", "Code List Change Type", "Add Value", "Internal", "DAMA-DMBOK", ""),
       ("Impact Assessment", "Consumers, mappings and reports affected.", "Code List", "Text", "", "4 consuming systems; 12 mappings to re-point; channel AUM history restated", "Internal", "", ""),
       ("Change Decision", "Outcome of the request.", "Code List", "Code", "Change Decision", "Approved", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Reference Data Management", "SR-RDM",
  "Metadata applied to every record in the shared reference data domain, and the distribution of reference data to consuming systems.",
  [
   ("Record Metadata", "Ownership, lineage and quality metadata on each reference record.", [
     ("Record Metadata", [
       ("Data Owner", "Business role accountable for the reference data set.", "All", "Reference (Employee)", "", "Head of Reference Data", "DCAM (EDM Council)", "DAMA-DMBOK", ""),
       ("Data Steward", "Role responsible for day-to-day quality.", "All", "Reference (Employee)", "", "Reference Data Steward - Geography", "DCAM (EDM Council)", "DAMA-DMBOK", ""),
       ("System of Record", "System holding the authoritative value.", "All", "Code", "Firm-defined", "Reference Data Hub", "Internal", "", "Y"),
       ("External Source Release", "Release or vintage of the external list the record was loaded from.", "All", "Text", "", "ISO 4217 Amendment 180", "Internal", "", ""),
       ("Record Effective From", "Business-effective start date of the record version.", "All", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Last Updated Timestamp", "System timestamp of the last change.", "All", "Timestamp", "ISO 8601", "2026-09-30T17:45:00Z", "Internal", "", ""),
       ("Data Quality Status", "Validation status of the record.", "All", "Code", "Data Quality Status", "Validated", "Internal", "", ""),
     ]),
   ]),
   ("Reference Data Distribution", "Publication of reference data sets to consuming systems.", [
     ("Reference Data Subscription", [
       ("Reference Data Set", "Registered list or master published.", "All", "Reference (Code List)", "", "CLR-0002 (Currency)", "Internal", "", ""),
       ("Subscribing System", "System that receives the data.", "All", "Code", "Firm-defined", "Fund Accounting Platform", "Internal", "", ""),
       ("Distribution Method", "How the data is delivered.", "All", "Code", "Distribution Method", "API", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Subdivision Category": ("ISO 3166-2", [("State","US"),("District","e.g. US-DC"),("Outlying Area","e.g. US-PR"),("Nation","UK: England, Scotland, Wales, Northern Ireland"),("Land","Germany, Austria"),("Canton","Switzerland"),("Province",""),("Region",""),("Canton / Commune","Luxembourg")]),
 "CBSA Type": ("OMB", [("Metropolitan","Urban core of 50,000+ population"),("Micropolitan","Urban core of 10,000-49,999 population")]),
 "Geographic Unit Type": ("Internal (aligned to ISO 3166, US Census, OMB, ONS, Eurostat; to replace 07 'Geographic Unit Type')", [("Country","ISO 3166-1"),("Country Subdivision","ISO 3166-2"),("County","US county by FIPS"),("CBSA","OMB metropolitan / micropolitan area"),("Metropolitan Division",""),("CSA","Combined statistical area"),("ZIP Code","USPS 5-digit"),("ZIP3","First three digits of ZIP"),("ZCTA","Census ZIP Code Tabulation Area"),("UK Postcode Area",""),("UK Postcode District",""),("UK Postcode Sector",""),("ITL Region","ITL1-3"),("NUTS Region","NUTS 1-3"),("City / Locality",""),("Geographic Group","Firm-defined group of units")]),
 "Geographic Scheme": ("Internal", [("ISO 3166-1",""),("ISO 3166-2",""),("US Census FIPS",""),("OMB CBSA",""),("USPS ZIP",""),("US Census ZCTA",""),("ONS Postcode (NSPL)",""),("ONS ITL",""),("Eurostat NUTS",""),("Firm-Defined","")]),
 "Geographic Hierarchy Type": ("Internal", [("Political (Country > Subdivision > County)",""),("US Statistical (ZIP > County > CBSA)",""),("UK Statistical (Postcode > ITL3 > ITL2 > ITL1)",""),("EU Statistical (NUTS 3 > 2 > 1 > Country)",""),("Firm Sales Geography","Units > sales sub-region > sales region > market")]),
 "Geographic Group Type": ("Internal", [("Sales Region","e.g. US Northeast, UK & Ireland"),("Country Cluster","e.g. DACH, Nordics, Iberia, Benelux"),("Market","e.g. US, UK, EU, Switzerland - harmonises 03 'Sales Market', 05 'Agreement Market', 07 'Market Scope'"),("Regulatory Region","e.g. EEA, EU, Eurozone"),("Reporting Region","e.g. Americas, EMEA, APAC"),("Statistical Grouping","e.g. UN M49 region")]),
 "Membership Type": ("Internal", [("Include",""),("Exclude","Carve-out from an included parent")]),
 "Reference Record Status": ("Internal", [("Proposed",""),("Active",""),("Inactive",""),("Deprecated","Still valid for history, not for new records"),("Retired","")]),
 "Business Domain": ("CG Taxonomy programme", [("01 Investment Product",""),("02 Client & Customer",""),("03 Sales",""),("04 Marketing & Digital",""),("05 Distribution Agreements & Partners",""),("06 Sales Transactions & AUM Attribution",""),("07 Compensation & Territory",""),("08 Distribution Compliance",""),("09 Shared & Enterprise Reference Data",""),("10 Distribution Finance & Profitability",""),("11 Market & Competitive Intelligence",""),("12 Institutional Client Servicing & Reporting",""),("13 Investor Servicing & Shareholder Communications",""),("14 Third-Party Data & Licensing","")]),
 "Calendar Type": ("Internal", [("Public Holiday","National or subdivision public / bank holidays"),("Banking / Settlement","e.g. TARGET, US Federal Reserve, UK bank holidays"),("Exchange","Trading days of a MIC"),("Bond Market","e.g. SIFMA recommended closes"),("Fund Dealing","Dealing days of a fund or fund range"),("Fiscal","Firm fiscal calendar"),("Reporting","Firm reporting calendar"),("Firm Office","Office closure days"),("Composite","Combination of other calendars")]),
 "Day of Week": ("ISO 8601", [("Monday",""),("Tuesday",""),("Wednesday",""),("Thursday",""),("Friday",""),("Saturday",""),("Sunday","")]),
 "Calendar Source": ("Internal", [("Government Publication","e.g. gov.uk bank holidays, US OPM federal holidays"),("Central Bank","e.g. ECB TARGET closing days, Federal Reserve"),("Exchange Publication","e.g. NYSE, LSE"),("Industry Body","e.g. SIFMA"),("Market Data Vendor",""),("Fund Administrator / TA",""),("Internal","")]),
 "Calendar Combination Rule": ("Internal", [("Holiday if Any Component Closed","Joint / union of holidays"),("Holiday if All Components Closed","Intersection of holidays")]),
 "Day Type": ("Internal", [("Business Day",""),("Holiday",""),("Weekend",""),("Half Day / Early Close",""),("Non-Dealing Day","Fund-specific"),("Dealing Day","Fund-specific, for non-daily patterns")]),
 "Dealing Day Pattern": ("Internal (aligned to openfunds dealing frequency)", [("Every Business Day",""),("Weekly - Named Weekday",""),("Fortnightly",""),("Month-End",""),("Mid-Month and Month-End",""),("Quarter-End","")]),
 "Fiscal Period Structure": ("Internal", [("12 Calendar Months",""),("4-4-5 Weeks",""),("4-5-4 Weeks",""),("13 Four-Week Periods","")]),
 "Period Type": ("Internal", [("Day",""),("Week",""),("Month",""),("Quarter",""),("Half-Year",""),("Year","")]),
 "Fiscal Period Status": ("Internal (owned by 10 Finance)", [("Future",""),("Open",""),("Soft Close",""),("Closed","")]),
 "Reporting Period Basis": ("Internal (aligned to GIPS period conventions)", [("MTD","Month to date"),("QTD","Quarter to date"),("YTD","Calendar year to date"),("FYTD","Fiscal year to date"),("R3M","Rolling 3 months"),("R12M","Rolling 12 months"),("1Y",""),("3Y",""),("5Y",""),("10Y",""),("SI","Since inception"),("Custom","Explicit start and end dates")]),
 "As-Of Date Convention": ("Internal", [("Calendar Month-End",""),("Last Business Day",""),("Last Valuation Day","Fund valuation day"),("Trade Date",""),("Settlement Date","")]),
 "Business Day Convention": ("ISDA 2006 Definitions", [("Following",""),("Modified Following",""),("Preceding",""),("Modified Preceding",""),("Unadjusted","")]),
 "Currency Type": ("ISO 4217", [("National Currency",""),("Supranational Currency","e.g. EUR, XAF"),("Fund Code","e.g. USN, CLF"),("Precious Metal","e.g. XAU"),("Testing / No Currency","XTS, XXX"),("Non-ISO Market Convention","e.g. GBX, CNH - not ISO 4217; firm-defined extension")]),
 "Currency Status": ("ISO 4217", [("Current","List One"),("Historic","List Three")]),
 "FX Rate Source": ("Internal", [("LSEG WM/Reuters","WMR benchmark spot, forward and NDF rates"),("ECB","Euro foreign exchange reference rates"),("Bloomberg BFIX",""),("Federal Reserve H.10","US noon buying rates (statistical release)"),("Bank of England","Spot rates (statistical)"),("Fund Administrator","Rates applied in NAV calculation"),("Internal Treasury","Budget / planning rates")]),
 "Benchmark Regulatory Status": ("EU BMR / UK BMR", [("Critical Benchmark (UK)",""),("Critical Benchmark (EU)",""),("Significant Benchmark",""),("Non-Significant Benchmark",""),("Not a Regulated Benchmark","e.g. ECB reference rates (central bank exemption)")]),
 "FX Rate Type": ("Internal", [("WMR London 4pm Close Mid","WM/Reuters 16:00 London closing spot, mid"),("WMR London 4pm Close Bid / Offer",""),("WMR Intraday Fix",""),("ECB Euro Reference Rate","Published around 16:00 CET on TARGET days"),("Fund Valuation Point Rate","Rate at the fund's valuation point, per prospectus"),("Monthly Average Rate",""),("Budget Rate","Fixed planning rate for the fiscal year"),("Month-End Spot","Close rate on the reporting period end date")]),
 "Rate Side": ("Market convention", [("Mid",""),("Bid",""),("Offer","")]),
 "FX Quote Convention": ("Internal", [("Market Convention Pair","Base / quote as quoted in the market, e.g. EURUSD, GBPUSD, USDJPY"),("Units of Quote per 1 EUR","ECB convention"),("Units of Currency per 1 USD","Pivot USD"),("Units of Currency per 1 GBP","Pivot GBP")]),
 "FX Fallback Rule": ("Internal", [("Previous Published Rate",""),("Alternative Rate Type","Switch to a named alternate source"),("Triangulate via Cross Currency",""),("Manual Override with Approval","")]),
 "FX Rate Usage": ("Internal", [("NAV Valuation",""),("Share Class Hedging",""),("AUM Reporting Translation",""),("Flow Reporting Translation",""),("Fee Calculation",""),("Distribution Payment Calculation","05 rev share / retrocessions"),("Incentive Compensation","07"),("Financial Reporting","10"),("Budget / Forecast","10")]),
 "Locale Usage": ("Internal", [("Website",""),("Advisor / Client Portal",""),("Client Documents",""),("Email",""),("Statements","")]),
 "Unit Category": ("Internal", [("Monetary Amount",""),("Ratio","Percent, basis points, per mille"),("Count",""),("Duration","Days, months, years"),("Rate per Period",""),("Data Volume","")]),
 "Rounding Rule": ("IEEE 754 / Internal", [("Half Even","Banker's rounding"),("Half Up",""),("Truncate",""),("Up","")]),
 "Percentage Storage Convention": ("Internal", [("Decimal Fraction","0.0075 = 0.75%"),("Percent","0.75 = 0.75%"),("Basis Points","75 = 0.75%")]),
 "Internal Entity Category": ("Internal (aligned to FIBO FBC functional entities)", [("Ultimate Holding Company",""),("Intermediate Holding Company",""),("SEC-Registered Investment Adviser",""),("Broker-Dealer / Principal Underwriter","FINRA member"),("Management Company / AIFM","UCITS ManCo and / or AIFM"),("MiFID Investment Firm",""),("UK Authorised Firm","FCA-authorised, e.g. UK ACD / investment manager"),("Bank / Trust Company","e.g. CIT trustee"),("General Partner / Fund Vehicle Sponsor",""),("Service Company","Employment, shared services"),("Branch","Non-legal-person branch")]),
 "Legal Entity Status": ("GLEIF LEI-CDF / Internal", [("Active",""),("Dormant",""),("In Liquidation",""),("Merged",""),("Dissolved","")]),
 "LEI Registration Status": ("GLEIF LEI-CDF", [("PENDING_VALIDATION",""),("ISSUED",""),("LAPSED","Not renewed"),("MERGED",""),("RETIRED",""),("ANNULLED",""),("DUPLICATE",""),("TRANSFERRED",""),("PENDING_TRANSFER",""),("PENDING_ARCHIVAL","")]),
 "Ownership Relationship Type": ("GLEIF RR-CDF / FIBO BE", [("Direct Accounting Consolidation Parent","GLEIF IS_DIRECTLY_CONSOLIDATED_BY"),("Ultimate Accounting Consolidation Parent","GLEIF IS_ULTIMATELY_CONSOLIDATED_BY"),("Branch Of","GLEIF IS_INTERNATIONAL_BRANCH_OF"),("Minority Ownership","Not consolidated"),("Joint Venture","")]),
 "GLEIF Reporting Exception": ("GLEIF Level 2 reporting exceptions (verify against current GLEIF documentation)", [("NATURAL_PERSONS","Controlled by natural persons"),("NON_CONSOLIDATING","Parent does not consolidate"),("NO_KNOWN_PERSON","No known controlling person"),("NON_PUBLIC","Disclosure restricted"),("NO_LEI","Parent has no LEI")]),
 "Regulator": ("Internal", [("SEC","US Securities and Exchange Commission"),("FINRA","US self-regulatory organisation for broker-dealers"),("US State Securities Regulator","Via NASAA / IARD notice filings"),("CFTC / NFA","Commodity pool operator / trading adviser"),("OCC / State Banking Regulator","CIT trustee banks"),("FCA","UK Financial Conduct Authority"),("PRA","UK Prudential Regulation Authority"),("CSSF","Luxembourg"),("CBI","Central Bank of Ireland"),("BaFin","Germany"),("AMF France",""),("CONSOB / Banca d'Italia","Italy"),("CNMV","Spain"),("AFM","Netherlands"),("FINMA","Switzerland")]),
 "Entity Authorisation Type": ("Internal (aligned to SEC, FINRA, FCA, CSSF, CBI registers)", [("SEC Investment Adviser Registration","Form ADV"),("Exempt Reporting Adviser",""),("Broker-Dealer Registration and FINRA Membership","Form BD"),("Municipal Advisor / MSRB Registration",""),("CPO / CTA Registration","NFA"),("FCA Part 4A Permission",""),("UK UCITS Management Company / ACD",""),("UK AIFM (Full-Scope)",""),("UCITS Management Company (Chapter 15)","Luxembourg 2010 Law"),("Authorised AIFM","AIFMD Art. 6 / Lux 2013 Law"),("Registered (Sub-Threshold) AIFM",""),("Super ManCo","UCITS ManCo + AIFM"),("MiFID Investment Firm Licence",""),("Irish UCITS Management Company",""),("Irish AIFM","")]),
 "Authorisation Status": ("Internal (aligned to FCA Register statuses)", [("Applied",""),("Authorised",""),("Registered",""),("Suspended",""),("Restricted",""),("Withdrawn / Cancelled",""),("Lapsed","")]),
 "Regulated Activity": ("FCA Handbook PERG / UCITS Annex II / AIFMD Annex I / MiFID II Annex I", [("Managing a UCITS",""),("Managing an AIF",""),("Collective Portfolio Management - Investment Management",""),("Collective Portfolio Management - Administration",""),("Collective Portfolio Management - Marketing / Distribution",""),("Discretionary Portfolio Management (MiFID top-up)",""),("Investment Advice (MiFID top-up)",""),("Reception and Transmission of Orders (MiFID top-up)",""),("Arranging Deals in Investments","FCA RAO"),("Dealing as Agent","FCA RAO"),("Acting as Authorised Fund Manager / ACD","FCA"),("Investment Company Principal Underwriting","FINRA BD business line"),("Advisory Services to Registered Funds","SEC RIA")]),
 "Passport Type": ("UCITS Directive / AIFMD / MiFID II", [("UCITS ManCo - Freedom to Provide Services","UCITS Art. 18"),("UCITS ManCo - Branch","UCITS Art. 17"),("AIFM Management Passport","AIFMD Art. 33"),("AIFM Marketing Passport (EU AIF)","AIFMD Art. 32"),("MiFID Services Passport","MiFID II Art. 34"),("MiFID Branch Passport","MiFID II Art. 35")]),
 "Entity Distribution Role": ("Internal (aligned to FIBO FBC, 01 'Party Role Type')", [("Principal Underwriter / Distributor","US '40 Act funds"),("Global Distributor","UCITS / AIF ranges"),("Sub-Distributor",""),("Management Company",""),("AIFM",""),("Investment Manager",""),("Sub-Adviser",""),("Model Provider","Model portfolio delivery"),("Marketing Communication Issuer","Legal entity named on promotions"),("s21 Financial Promotion Approver","UK"),("Employing Entity for Sales Personnel",""),("Contracting Entity for Distribution Agreements","")]),
 "Org Unit Type": ("Internal", [("Division",""),("Business Unit",""),("Department",""),("Team",""),("Desk",""),("Cost Centre Node","Finance-only grouping"),("Committee","")]),
 "Business Function": ("Internal", [("Distribution",""),("Marketing",""),("Investment Management",""),("Product",""),("Operations",""),("Finance",""),("Legal & Compliance",""),("Technology & Data",""),("HR",""),("Executive","")]),
 "Org Hierarchy Type": ("Internal", [("Management","Reporting lines for people management"),("Legal Entity","Units by booking entity"),("Cost Centre","Finance roll-up (aligned to 10)"),("Distribution Organisation","Channel / region structure used by 03 and 07")]),
 "Reorganisation Type": ("Internal", [("Create",""),("Merge",""),("Split",""),("Move","Change of parent"),("Rename",""),("Close","")]),
 "Restatement Rule": ("Internal", [("Restate Prior Periods",""),("Keep As Booked",""),("Restate Current Year Only","")]),
 "Industry Classification Scheme": ("Various", [("NAICS","US / Canada / Mexico; OMB / Census"),("US SIC","Legacy US SIC 1987; still used by SEC EDGAR"),("NACE","EU; Eurostat"),("UK SIC","UK; ONS (SIC 2007 in use; SIC 2026 published)"),("GICS","MSCI / S&P - licensed"),("ISIC","UN")]),
 "Correspondence Type": ("Internal", [("One-to-One",""),("Partial (One-to-Many)",""),("Partial (Many-to-One)",""),("Many-to-Many","")]),
 "Code List Class": ("Internal (DAMA-DMBOK reference data categories)", [("Enterprise Shared","Governed by 09; used by more than one domain"),("Domain-Specific","Owned and used by one business domain"),("External Standard","ISO / regulator list, loaded not edited"),("External Vendor","Vendor-maintained, licensed via 14")]),
 "Registry Status": ("ISO/IEC 11179 registration status", [("Candidate",""),("Recorded",""),("Qualified",""),("Standard",""),("Preferred Standard",""),("Superseded",""),("Retired","")]),
 "Extensibility": ("Internal", [("Closed","No local values"),("Extensible with Approval",""),("Locally Extensible","Domain may add values mapped to a parent")]),
 "Code List Usage Type": ("Internal", [("Validate and Store",""),("Display Only",""),("Map Inbound",""),("Report / Aggregate","")]),
 "Mapping Type": ("W3C SKOS", [("Exact Match",""),("Close Match",""),("Broad Match","Source narrower than target"),("Narrow Match","Source broader than target"),("Related Match",""),("Unmapped","Held for steward review")]),
 "Mapping Status": ("Internal", [("Proposed",""),("Approved",""),("Rejected",""),("Retired","")]),
 "Code List Change Type": ("Internal", [("New List",""),("Add Value",""),("Change Label / Definition",""),("Deprecate Value",""),("Merge Values",""),("Split Value",""),("Retire List","")]),
 "Change Decision": ("Internal", [("Approved",""),("Approved with Changes",""),("Rejected",""),("Deferred","")]),
 "Distribution Method": ("Internal", [("API",""),("File (SFTP)",""),("Message / Event Stream",""),("Database Replication",""),("Catalogue Download","")]),
 "Data Quality Status": ("Internal (same values as 01-08; candidate shared list)", [("Validated",""),("Pending Validation",""),("Exception",""),("Deprecated","")]),
 "Shared Code List Candidate": ("CG Taxonomy cross-domain scan (draft v0.1); harmonised values to be agreed in the consolidation exercise", [("Distribution Channel","01 'Distribution Channel', 02 'Distribution Channel', 03 / 07 'Sales Channel', 04 'Business Channel', 05 'Partner Channel', 06 'Distribution Channel'"),("Frequency","01, 03, 05, 06, 07, 08 'Frequency'"),("Investor Type / Client Category","01 'Investor Type', 02 'Investor Type', 02 / 08 'MiFID Client Category'"),("Lifecycle / Record Status","01 'Lifecycle Status', 'Data Quality Status' in all of 01-08, plus many domain status lists"),("Party Role","01 'Party Role Type', 02 'Party Role Type'"),("Registration Status","01, 02, 04, 08 'Registration Status'"),("Market / Sales Market","03 'Sales Market', 05 'Agreement Market', 07 'Market Scope' - model as Geographic Group Type = Market"),("Approval Status","07, 08"),("Payment Status","05, 07"),("Distribution Strategy","01, 08 (FinDatEx EMT)"),("Networking Level","02, 05"),("Qualification Exam","02, 08"),("Screening Result","02, 08"),("Personal Data Category","02, 03"),("Social Platform","04, 08"),("Snapshot Type","03, 06"),("Message Standard","05, 06"),("Data Classification","06, 07"),("Geographic Unit Type","07 - replace with this domain's list"),("Legal Entity (firm-defined)","08 - replace with LEN- reference")]),
}

# ---------------------------------------------------------------------------
# Relationships, sources
# ---------------------------------------------------------------------------
REL = [
 ("Country","contains","Country Subdivision","1 : 0..n","ISO 3166-2 subdivisions; multi-level for e.g. GB."),
 ("Geographic Unit (parent)","is parent of","Geographic Unit (child)","1 : 0..n","Per Geographic Hierarchy Type; effective-dated; allocation share where a child spans parents."),
 ("Geographic Group","contains","Geographic Unit","n : m","Include / exclude membership, effective-dated; groups may nest."),
 ("Territory (07 CT, TER-)","is defined by","Geographic Unit / Geographic Group","n : m","07 owns territories and alignment; 09 owns the units and groups they are built from."),
 ("Postal Address (02 CC)","references","Country / Country Subdivision / Postal Code","n : 1","02 stores the address; codes validated against 09."),
 ("Country","uses","Currency; Time Zone; Language","n : m","Defaults only; products and parties hold their own values."),
 ("Composite Calendar","combines","Calendar","1 : 2..n","Union or intersection of holidays."),
 ("Calendar","has","Calendar Date","1 : 0..n",""),
 ("Fund Dealing Calendar","is based on","Business Calendar / Exchange Calendar","n : m","Base calendar plus market closure calendars and threshold rule."),
 ("Investment Product (01 PRD-)","deals according to","Fund Dealing Calendar (CAL-)","n : 1","01 'Dealing Calendar' attribute; cut-off and valuation point stay in 01."),
 ("Fiscal Calendar","has","Fiscal Period","1 : 1..n",""),
 ("Reporting Period Definition","is used by","Reporting Period / Snapshot (06), Goal (07), Profitability record (10), Client Report (12)","1 : 0..n","Consumers own their own close and lock dates."),
 ("FX Rate Type","is sourced from","FX Rate Source","n : 1",""),
 ("FX Rate Source","is licensed under","Dataset (14 TD, DSET-)","n : 0..1","Licence terms and entitlements owned by 14."),
 ("Currency","is used as","Base / Share Class / Reporting Currency (01, 06, 10)","1 : 0..n","ISO 4217 code is the enterprise key."),
 ("Locale","is used by","Digital Property / Content Asset (04 MK)","1 : 0..n","Language and locale of websites, portals and assets."),
 ("Internal Legal Entity (child)","is owned / consolidated by","Internal Legal Entity (parent)","n : 0..n","GLEIF Level 2 direct and ultimate parent; effective-dated."),
 ("Internal Legal Entity","is cross-referenced to","Party (02 CC, PTY-)","1 : 0..1","Lets 01 product party roles and 05 agreements keep using PTY- for group entities."),
 ("Internal Legal Entity","holds","Entity Authorisation (AUTH-)","1 : 0..n",""),
 ("Entity Authorisation","is exercised cross-border through","Cross-Border Passport","1 : 0..n","EU entities only; UK entities have no EU passport post-Brexit."),
 ("Internal Legal Entity","performs","Entity Distribution Role","1 : 0..n","Scoped by market (Geographic Group), channel and product range."),
 ("Internal Legal Entity","is contracting party to","Agreement (05 DA, AGR-)","1 : 0..n","Via the PTY- cross-reference until 05 adds a LEN- reference."),
 ("Internal Legal Entity","employs / registers","Employee (03 SL, EMP-) / Licence (08 DC, LIC-)","1 : 0..n","03 'Employing Legal Entity'; 08 'Registering Firm' and 'Applicable Legal Entity' should reference LEN-."),
 ("Org Unit (parent)","is parent of","Org Unit (child)","1 : 0..n","Per Org Hierarchy Type; effective-dated."),
 ("Org Unit","is booked in","Internal Legal Entity","n : 1",""),
 ("Org Unit","maps to","Cost Centre / Profit Centre (10 DF)","n : 1","Chart of accounts and allocations owned by 10."),
 ("Sales Team (03 SL, SLT-)","belongs to","Org Unit","n : 1",""),
 ("Reorganisation","changes","Org Unit","1 : 1..n","Source and target units with restatement rule."),
 ("Classification Scheme","contains","Classification Code","1 : 1..n","Hierarchical via Parent Classification Code."),
 ("Organisation (02 CC, PTY-)","is classified by","Classification Code","n : m","02 holds the assignment; 09 holds the scheme."),
 ("Code List Registry Entry (CLR-)","has","Code List Version (CLV-)","1 : 1..n",""),
 ("Code List Version","contains","Code Value","1 : 1..n",""),
 ("Code Value","is mapped from","Code Mapping (CLM-)","1 : 0..n","Source-system and vendor values; party-matching crosswalks stay in 06 XWK-."),
 ("Code List Registry Entry","is consumed by","Business Domain attribute (01-14)","1 : 0..n","Consumer registration drives change impact assessment."),
]

SRC = [
 ("ISO 3166 Country Codes (3166-1, 3166-2) and Online Browsing Platform","ISO 3166 Maintenance Agency","https://www.iso.org/iso-3166-country-codes.html ; https://www.iso.org/obp/ui","Standard; codes browsable free, data files licensed","Country and subdivision codes and statuses","Countries & Subdivisions, Geographic Unit",["ISO 3166"]),
 ("ISO 4217 Currency Codes and amendments","ISO; SIX Financial Information (Maintenance Agency secretariat)","https://www.six-group.com/en/products-services/financial-information/data-standards.html","Free lists (List One / Three) from SIX","Alphabetic / numeric codes, minor units, historic currencies; Amendment 180: BGN replaced by EUR from 1 Jan 2026","Currency",["ISO 4217"]),
 ("ISO 639 Language Codes","ISO 639 Registration Authority (Library of Congress / SIL)","https://www.loc.gov/standards/iso639-2/ ; https://iso639-3.sil.org","Free","Two- and three-letter language codes","Language",["ISO 639"]),
 ("IETF BCP 47 (RFC 5646 / 4647) and IANA Language Subtag Registry","IETF; IANA","https://www.rfc-editor.org/info/bcp47 ; https://www.iana.org/assignments/language-subtag-registry","Free","Locale / language tags","Locale",["IETF BCP 47"]),
 ("Unicode CLDR","Unicode Consortium","https://cldr.unicode.org","Free (Unicode licence)","Locale data: number and date formats, currency symbols, Windows-to-IANA zone mapping","Locale, Number & Date Convention, Time Zone",["Unicode CLDR"]),
 ("IANA Time Zone Database (tzdata)","IANA","https://www.iana.org/time-zones","Public domain","Time zone identifiers and rules, several releases per year","Time Zone, Calendar time zones",["IANA tz"]),
 ("ISO 8601 / ISO 10383 (MIC) / ISO 15924 / ITU-T E.164","ISO; SWIFT (MIC RA); Unicode (15924 RA); ITU","https://www.iso.org/iso-8601-date-and-time-format.html ; https://www.iso20022.org/market-identifier-codes","Standard; MIC list free","Date / time format, market identifiers, scripts, telephone codes","Calendars, Locale, Country",["ISO 8601","ISO 10383","ITU-T E.164"]),
 ("US Census Bureau FIPS / ANSI codes and ZIP Code Tabulation Areas","US Census Bureau","https://www.census.gov/library/reference/code-lists/ansi.html ; https://www.census.gov/programs-surveys/geography/guidance/geo-areas/zctas.html","Public domain","State and county codes; ZCTA approximations of ZIP codes","US County, ZIP Code & ZCTA, Subdivision",["US Census (FIPS)","US Census (ZCTA)"]),
 ("OMB Bulletin 23-01: Revised Delineations of Metropolitan / Micropolitan Statistical Areas","US Office of Management and Budget","https://www.whitehouse.gov/wp-content/uploads/2023/07/OMB-Bulletin-23-01.pdf ; https://www.census.gov/programs-surveys/metro-micro/about.html","Public domain","CBSA, metropolitan division and CSA delineations (21 Jul 2023, supersedes 20-01)","Core Based Statistical Area",["OMB CBSA"]),
 ("HUD-USPS ZIP Code Crosswalk Files and USPS ZIP data","US Department of Housing and Urban Development; USPS","https://www.huduser.gov/portal/datasets/usps_crosswalk.html","Free (registration)","ZIP-to-county / CBSA address ratios; ZIP types","Preferred County, ZIP-to-County Ratio",["HUD-USPS Crosswalk","USPS"]),
 ("ONS International Territorial Levels (ITL 2025) and National Statistics Postcode Lookup","Office for National Statistics (ONS Geography)","https://www.ons.gov.uk/methodology/geography/ukgeographies/eurostat ; https://geoportal.statistics.gov.uk","Open Government Licence","ITL1 (12) / ITL2 (46) / ITL3 (182) regions from 1 Jan 2025; postcode to LAD / ITL lookups","ITL Region, UK Postcode",["ONS ITL","ONS (postcodes)"]),
 ("Eurostat NUTS classification (NUTS 2024)","Eurostat / European Union","https://ec.europa.eu/eurostat/web/nuts","Open (Regulation (EC) 1059/2003, Delegated Reg. (EU) 2023/674)","NUTS 1 / 2 / 3 regions valid from 1 Jan 2024","NUTS Region",["Eurostat NUTS"]),
 ("LSEG WM/Reuters FX Benchmarks (WMR London 4pm Close)","LSEG Benchmark Services Ltd","https://www.lseg.com/en/data-analytics/financial-data/benchmarks/foreign-exchange-benchmarks","Licensed (via 14)","Spot, forward and NDF benchmark rates; 4pm fix from trades and quotes in a window around 16:00 London; critical benchmark under UK BMR","FX Rate Source, FX Rate Type",["LSEG WM/Reuters"]),
 ("ECB euro foreign exchange reference rates","European Central Bank","https://www.ecb.europa.eu/stats/policy_and_exchange_rates/euro_reference_exchange_rates/html/index.en.html","Free; for information only, not for transactions","Daily EUR reference rates, concertation around 14:10 CET, published around 16:00 CET on TARGET days","FX Rate Type, Quote Convention, Publication Calendar",["ECB"]),
 ("EU / UK Benchmarks Regulation (BMR)","European Union; UK FCA","https://eur-lex.europa.eu/eli/reg/2016/1011/oj ; https://www.handbook.fca.org.uk/handbook/BENCH/","Regulation","Benchmark administrator authorisation and critical benchmark designation","Benchmark Regulatory Status",["EU BMR","UK BMR"]),
 ("ISDA 2006 Definitions (business day conventions)","ISDA","https://www.isda.org","Member / purchase","Following, modified following and preceding conventions","Business Day Convention",["ISDA"]),
 ("GLEIF LEI-CDF 3.1, RR-CDF 2.1 (Level 2) and Entity Legal Form list; ISO 17442 / ISO 20275","GLEIF; ISO","https://www.gleif.org/en/about-lei/common-data-file-format/relationship-record-cdf-format ; https://www.gleif.org/en/about-lei/code-lists/iso-20275-entity-legal-forms-code-list","Open data (CC0)","Level 1 entity data, registration status, direct / ultimate accounting consolidation parents, reporting exceptions, legal forms","Legal Entity Master, Group Structure & Ownership",["GLEIF LEI-CDF","GLEIF RR-CDF","ISO 17442 (GLEIF)","ISO 20275"]),
 ("FIBO Business Entities (BE: Legal Entities, Ownership and Control) and FBC Functional Entities","EDM Council","https://spec.edmcouncil.org/fibo/ontology/BE/OwnershipAndControl/ ; https://spec.edmcouncil.org/fibo/ontology/FBC/FunctionalEntities/","Open (MIT licence)","Legal persons, ownership and control parties, regulated financial service providers","Legal Entity Master, Ownership, Entity Roles",["FIBO BE","FIBO FBC"]),
 ("SEC Form ADV / Form BD / EDGAR CIK and FINRA BrokerCheck / CRD","US SEC; FINRA","https://adviserinfo.sec.gov ; https://brokercheck.finra.org ; https://www.sec.gov/edgar","Public registers","Adviser and broker-dealer registration, CRD and SEC numbers, annual updating amendments","Entity Authorisation, identifiers",["SEC Form ADV","SEC EDGAR","FINRA"]),
 ("FCA Financial Services Register and FCA Handbook (PERG, SUP, COBS 3)","UK FCA","https://register.fca.org.uk ; https://www.handbook.fca.org.uk","Public register; regulation","FRN, Part 4A permissions, requirements and limitations, client categories","Entity Authorisation, Regulated Activity",["FCA Register","FCA Handbook"]),
 ("CSSF and Central Bank of Ireland entity registers","CSSF; Central Bank of Ireland","https://www.cssf.lu/en/search-entities/ ; https://registers.centralbank.ie","Public registers","Authorised ManCos, AIFMs and investment firms","Entity Authorisation",["CSSF","CBI"]),
 ("UCITS Directive 2009/65/EC, AIFMD 2011/61/EU (as amended by 2024/927), MiFID II 2014/65/EU","European Union","https://eur-lex.europa.eu/eli/dir/2009/65/oj ; https://eur-lex.europa.eu/eli/dir/2011/61/oj ; https://eur-lex.europa.eu/eli/dir/2014/65/oj","Regulation","Authorisation, permitted functions, management and marketing passports","Authorisations, Cross-Border Passport",["UCITS Directive","AIFMD","MiFID II"]),
 ("NAICS (2022; 2027 revision in progress)","US Census Bureau / OMB ECPC","https://www.census.gov/naics/","Public domain","North American industry classification; concordances","Industry Classification",["NAICS"]),
 ("NACE Rev. 2.1 (Delegated Reg. (EU) 2023/137, in force 1 Jan 2025) and correspondence tables","Eurostat","https://ec.europa.eu/eurostat/web/nace","Open","EU activity classification: 22 sections, 87 divisions, 287 groups, 651 classes","Industry Classification",["NACE"]),
 ("UK SIC 2007 and UK SIC 2026","ONS","https://www.ons.gov.uk/methodology/classificationsandstandards/ukstandardindustrialclassificationofeconomicactivities ; https://www.ons.gov.uk/methodology/classificationsandstandards/ukstandardindustrialclassificationofeconomicactivities/uksic2026","Open Government Licence","UK national version of NACE; SIC 2026 structure and SIC 2007-2026 correspondence published Aug 2026","Industry Classification",["UK SIC"]),
 ("US SIC (1987) as used by SEC EDGAR","US OMB (legacy); SEC","https://www.sec.gov/search-filings/standard-industrial-classification-sic-code-list","Public domain","Legacy industry codes still assigned to SEC registrants","Industry Classification",["US SIC"]),
 ("GICS","MSCI and S&P Dow Jones Indices","https://www.msci.com/indexes/index-resources/gics","Licensed (via 14)","Sector / industry group / industry / sub-industry for companies","Industry Classification",["GICS"]),
 ("ISO/IEC 11179-3:2023 Metadata registries - Registry metamodel","ISO/IEC JTC 1/SC 32","https://www.iso.org/standard/78915.html","Standard (purchase)","Registry items, designation, definition, registration status, classification and mapping","Enterprise Code List Registry",["ISO/IEC 11179"]),
 ("W3C SKOS Reference (mapping properties)","W3C","https://www.w3.org/TR/skos-reference/","Free","exactMatch, closeMatch, broadMatch, narrowMatch, relatedMatch","Code Mapping",["W3C SKOS"]),
 ("DAMA-DMBOK 2nd ed. (rev.), Ch. 10 Reference and Master Data","DAMA International","https://www.dama.org/cpages/body-of-knowledge","Book (purchase)","Reference data management: code lists, taxonomies, crosswalks, governance and change control","Code List Registry, Reference Data Management",["DAMA-DMBOK"]),
 ("DCAM","EDM Council","https://edmcouncil.org","Member framework","Data ownership, stewardship and governance","Data Owner / Steward",["DCAM*"]),
 ("UN/ECE Recommendation 20 and UCUM","UNECE; Regenstrief Institute","https://unece.org/trade/uncefact/cl-recommendations ; https://ucum.org","Free","Units of measure codes","Unit of Measure",["UN/ECE Rec 20","UCUM"]),
]
