"""Business domain 10 - Distribution Finance & Profitability. Content module for taxonomy_builder.py."""

META = {
 "title": "Distribution Finance & Profitability Data Taxonomy",
 "subtitle": "Business domain 10 - Distribution Finance & Profitability | Asset manager (wholesale distributor) | Scope: US + EU/UK | Draft v0.1 | 2026-10-01",
 "output": "10_Distribution_Finance_and_Profitability/Distribution_Finance_and_Profitability_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the finance view of distribution at a wholesale asset manager: what distribution earns (management, performance and distribution fee revenue, recognised under ASC 606 / IFRS 15), what it costs (distribution expense accounting, accruals, GL postings, capitalised contract costs under ASC 340-40 / IFRS 15), and how profitable each channel, partner firm, product, share class, territory, salesperson and client is after cost allocation. Built from accounting standards (ASC 606, ASC 340-40, IFRS 15, ASC 280 / IFRS 8), the AICPA Revenue Recognition Guide (asset management chapter), SEC Rule 12b-1, the OECD Transfer Pricing Guidelines, the US GAAP XBRL taxonomy and management-accounting practice (activity-based and time-driven activity-based costing). Use it as a starting point for a distribution profitability engine, a finance data mart, a chart-of-accounts mapping or a business glossary."),
  ("Scope", "In scope: revenue contracts and performance obligations; management / advisory, performance and distribution & servicing fee revenue records, sales charges retained and CDSC; fee waivers and expense reimbursements (financial impact) and adviser-borne fund costs; distribution expense items, accruals and true-ups; contract cost assets (incremental costs to obtain, legacy deferred sales commissions) and the commission capitalisation assessment; chart-of-accounts and external reporting line mapping and GL postings; cost pools, allocation methods, drivers, rules, runs and results; profitability records and measures (net revenue yield, revenue after distribution costs, contribution margin, cost-to-serve, operating margin); management reporting hierarchies and restatements; budgets, forecasts, scenarios and plan-vs-actual; intercompany distribution agreements, transfer pricing policies and intercompany charges; period close, controls and data management metadata. Out of scope (referenced by ID only): fee, expense cap and waiver TERMS on the share class (01_Product, SHC-/PRD-/MND-); parties, accounts and segmentation (02_Client_and_Customer, PTY-/ACC-); salespeople, activities and the sales pipeline forecast (03_Sales, EMP-/ACT-/FCS-); campaign budgets and spend (04_Marketing_and_Digital, CAM-); payment arrangements, rate schedules, payment calculations, partner invoices and payments (05_Distribution_Agreements_and_Partners, AGR-/PYA-/PCL-/PMT-); transactions, positions, flow / AUM measures and Estimated Management Fee Revenue (06_Sales_Transactions_and_AUM_Attribution, TXN-/POS-/MSR-/SNP-); territories, crediting, incentive plans, payout calculations and compensation statements (07_Compensation_and_Territory, TER-/ICP-/STM-); inducement assessments (08_Distribution_Compliance, REV-); fiscal calendar, FX rate types, legal entities and org units / cost centres (09_Shared_and_Enterprise_Reference_Data, CAL-/LEN-/OU-); segregated-mandate fee invoices (12_Institutional_Client_Servicing_and_Reporting, BIL-); data licence costs at contract level (14_Third_Party_Data_and_Licensing, DLA-)."),
  ("Structure", "Four levels: Domain > Subdomain > Concept > Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Revenue side: Revenue Contract (RVC-, e.g. the investment advisory agreement with a fund or the IMA for a mandate) -> Performance Obligation -> Fee Revenue Record (FRR-) per share class / mandate and period, net of Waiver Records (WVR-). Cost side: source calculations in other domains (05 PCL-/PMT-, 07 STM- and accruals, 04 CAM- spend, 14 DLA- costs) -> Distribution Cost Item (DCO-) -> Accrual (ACR-) / True-Up -> GL Posting (JNL-) via Account Mapping (ACM-); qualifying costs -> Contract Cost Asset (CCA-). Allocation: Cost Pool (CPO-) -> Allocation Rule (ARU-) using an Allocation Method (ALM-) and Driver (DRV-) -> Allocation Run (ARN-) -> Allocation Results. Output: Profitability Record (PNL-) at a declared dimension grain and version (actual, budget BUD-, forecast), rolled up through Management Hierarchies (MHY-) with Restatements (HRS-). Entity view: Intercompany Agreement (ICA-) under a Transfer Pricing Policy -> Intercompany Charge (ICC-)."),
  ("Design principles", "1) Account for, do not recalculate: amounts calculated in 05 (partner payments), 07 (payouts) and 04 (campaign spend) are referenced by ID; 10 adds the accounting attributes (period, entity, account, cost centre, accrual, capitalisation). 2) Separate actual (books) revenue from 06's Estimated Management Fee Revenue measure, and reconcile them. 3) Every profitability record declares its version, dimension grain, hierarchy version and allocation run so it is reproducible. 4) Funding source (fund-paid under 12b-1, fund-paid servicing, adviser / distributor own resources) and bearing legal entity are explicit on every cost. 5) Dual-GAAP aware: accounting framework and ledger are attributes, not assumptions. 6) Effective-date mappings, hierarchies, rules and TP policies; restate history only through a recorded restatement. 7) Controlled code lists, with enterprise lists (channel, fiscal period, FX rate type) referenced as External."),
  ("Applies To", "Shows the record type each attribute is held on: Revenue Contract, Performance Obligation, Fee Revenue Record, Performance Fee Record, Distribution Revenue Record, Waiver Record, Adviser-Borne Cost, Distribution Cost Item, Accrual, Contract Cost Asset, Capitalisation Assessment, Account Mapping, GL Posting, Cost Pool, Allocation Method, Allocation Driver, Allocation Rule, Allocation Run, Allocation Result, Profitability Record, Profitability Measure, Cost-to-Serve Profile, Management Hierarchy, Hierarchy Node, Hierarchy Restatement, Plan Version, Plan Line, Forecast, Variance, Intercompany Agreement, TP Policy, Intercompany Charge, Accounting Period, Control or All."),
  ("CDE", "Y = proposed Critical Data Element: needed to recognise or report revenue and expense correctly, to post to the ledger, to reproduce a profitability or allocation result, or to evidence arm's-length intercompany pricing. Confirm with data owners (Financial Reporting, FP&A, Distribution Finance, Tax)."),
  ("Primary / Secondary Reference", "Standard or source the attribute definition is aligned to (ASC 606, ASC 340-40, IFRS 15, ASC 280 / IFRS 8, AICPA Revenue Recognition Guide, SEC Rule 12b-1, OECD TPG, US GAAP Taxonomy, TDABC). 'Internal' = firm-defined; there is no authoritative external definition (most management-accounting attributes fall here). Next step: confirm the exact ASC paragraph and US GAAP Taxonomy element for each CDE with Financial Reporting."),
  ("Tabs", "Hierarchy: domains, subdomains and concepts with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: concept-level cardinalities, including references to other business domains | Sources: standards used, owners, licences and links."),
  ("Suggested next steps", "1) Validate with Financial Reporting / Technical Accounting, FP&A, Distribution Finance, Tax (transfer pricing) and Fund Treasury. 2) Confirm revenue-recognition positions (customer determination, principal vs agent on 12b-1, performance-fee constraint, capitalisation of wholesaler commissions) against the firm's accounting policy papers. 3) Map attributes to source systems (ERP / GL, fund accounting, fee-billing engine, intermediary-payment engine, ICM, planning tool, profitability engine). 4) Agree cost pools, allocation drivers and the management hierarchy with FP&A and Distribution leadership; pilot one quarter for one channel. 5) Agree the hand-off contracts with 05, 06, 07 and 04 (source record IDs and amounts). 6) Turn the Relationships tab into a logical data model."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Revenue & Revenue Recognition", "DF-REV",
  "Revenue earned from distribution-related contracts: management / advisory fees, performance fees, distribution and servicing fees and sales charges, with the ASC 606 / IFRS 15 attributes that govern when and how it is recognised.",
  [
   ("Revenue Contract & Performance Obligations", "The contract with a customer under ASC 606 / IFRS 15 and the promises within it.", [
     ("Revenue Contract", [
       ("Revenue Contract ID", "Unique identifier of the revenue contract as defined for revenue recognition.", "Revenue Contract", "Identifier", "", "RVC-000231", "Internal", "ASC 606", "Y"),
       ("Revenue Contract Type", "Type of contract that gives rise to revenue.", "Revenue Contract", "Code", "Revenue Contract Type", "Investment Advisory Agreement (Fund)", "ASC 606", "AICPA Revenue Recognition Guide", ""),
       ("Identified Customer", "Party identified as the customer for revenue recognition. For fund advisory and 12b-1 fees this is generally the fund, not the end investor.", "Revenue Contract", "Reference (Party)", "", "PTY-0012 (Example Funds Trust - Growth Fund)", "ASC 606", "AICPA Revenue Recognition Guide", "Y"),
       ("Customer Determination Basis", "Conclusion on who the customer is, which drives the treatment of sales loads and costs to obtain.", "Revenue Contract", "Code", "Customer Determination Basis", "Fund is Customer", "AICPA Revenue Recognition Guide", "ASC 606", ""),
       ("Underlying Agreement", "Legal agreement or mandate the revenue contract is based on (01 mandate or 05 agreement).", "Revenue Contract", "Reference (Agreement / Mandate)", "", "MND-00412", "Internal", "", ""),
       ("Contracting Legal Entity", "Internal legal entity that is party to the contract and records the revenue (adviser, ManCo, principal underwriter).", "Revenue Contract", "Reference (Legal Entity)", "", "LEN-0003", "Internal", "ASC 606", "Y"),
       ("Accounting Framework", "Framework under which the contracting entity reports.", "Revenue Contract", "Code", "Accounting Framework", "US GAAP", "Internal", "", "Y"),
       ("Contract Inception Date", "Date the contract became enforceable.", "Revenue Contract", "Date", "ISO 8601", "2019-04-01", "ASC 606", "IFRS 15", ""),
       ("Termination Notice Period", "Days' notice either party needs to terminate without penalty. Short notice periods limit the contract term for revenue and cost amortisation purposes.", "Revenue Contract", "Integer", "Days", "60", "ASC 606", "IFRS 15", ""),
     ]),
     ("Performance Obligation", [
       ("Performance Obligation Type", "Distinct promise to transfer services to the customer.", "Performance Obligation", "Code", "Performance Obligation Type", "Asset Management Services (Series)", "ASC 606", "IFRS 15", ""),
       ("Satisfaction Pattern", "Whether the obligation is satisfied over time or at a point in time.", "Performance Obligation", "Code", "Satisfaction Pattern", "Over Time", "ASC 606", "IFRS 15", "Y"),
       ("Series Guidance Applied Indicator", "Whether the obligation is a series of distinct service periods, so variable fees are allocated to the period in which they are earned.", "Performance Obligation", "Boolean", "", "Y", "ASC 606", "IFRS 15", ""),
       ("Revenue Stream", "Revenue stream the obligation generates.", "Performance Obligation", "Code", "Revenue Stream", "Management Fee", "Internal", "US GAAP Taxonomy", ""),
     ]),
   ]),
   ("Management & Advisory Fee Revenue", "Booked management / advisory fee revenue per share class or mandate and period, accrued from AUM x fee rate.", [
     ("Fee Revenue Record", [
       ("Fee Revenue Record ID", "Unique identifier of the fee revenue record.", "Fee Revenue Record", "Identifier", "", "FRR-2026-09-004512", "Internal", "", "Y"),
       ("Revenue Share Class / Mandate", "Share class or mandate the fee is earned on.", "Fee Revenue Record", "Reference (Share Class / Mandate)", "", "SHC-004512", "Internal", "", "Y"),
       ("Revenue Accounting Period", "Fiscal period the revenue is recognised in.", "Fee Revenue Record", "Code", "External (09 Shared - Fiscal Period)", "FY2026-P09", "Internal", "", "Y"),
       ("Fee Basis Average Assets", "Average net assets used to accrue the fee for the period.", "Fee Revenue Record", "Amount", "", "USD 1,842,500,000", "Internal", "SEC Form N-1A", ""),
       ("Fee Basis Source", "Where the asset basis came from.", "Fee Revenue Record", "Code", "Fee Basis Source", "Fund Accounting NAV", "Internal", "", ""),
       ("Applied Gross Fee Rate", "Annual fee rate applied for the period after breakpoints, as taken from 01 Product fee terms.", "Fee Revenue Record", "Decimal", "Basis points", "68.5", "Internal", "", ""),
       ("Gross Fee Revenue", "Fee earned before waivers and reimbursements.", "Fee Revenue Record", "Amount", "", "USD 1,051,800", "ASC 606", "US GAAP Taxonomy", "Y"),
       ("Waiver and Reimbursement Offset", "Waivers and reimbursements netted against revenue as consideration payable to the customer (detail on Waiver Record).", "Fee Revenue Record", "Amount", "", "USD -61,400", "ASC 606", "", ""),
       ("Net Fee Revenue", "Fee revenue after waivers and reimbursements; the amount recognised.", "Fee Revenue Record", "Amount", "", "USD 990,400", "ASC 606", "IFRS 15", "Y"),
       ("Effective Net Fee Rate", "Net fee revenue annualised over average assets.", "Fee Revenue Record", "Decimal", "Basis points", "64.5", "Internal", "", ""),
       ("Revenue Data Basis", "Whether the amount is actual (billed / settled), an accrued estimate or allocated.", "Fee Revenue Record", "Code", "Revenue Data Basis", "Accrued Estimate", "Internal", "", ""),
       ("Sub-Advisory Fee Payable", "Fee payable to a sub-adviser out of the advisory fee, needed to derive net advisory revenue.", "Fee Revenue Record", "Amount", "", "USD 210,000", "Internal", "ASC 606", ""),
     ]),
   ]),
   ("Performance Fee Revenue", "Performance fees and their recognition under the variable-consideration constraint.", [
     ("Performance Fee Record", [
       ("Performance Fee Record ID", "Unique identifier of the performance fee record.", "Performance Fee Record", "Identifier", "", "PFR-2026-12-00877", "Internal", "", ""),
       ("Performance Fee Share Class / Mandate", "Share class or mandate subject to the fee (terms held in 01 Product).", "Performance Fee Record", "Reference (Share Class / Mandate)", "", "SHC-008811", "Internal", "", ""),
       ("Crystallisation Date", "Date the fee crystallises and becomes payable.", "Performance Fee Record", "Date", "ISO 8601", "2026-12-31", "ESMA Performance Fee Guidelines", "ASC 606", ""),
       ("NAV-Accrued Performance Fee", "Performance fee accrued in the fund NAV but not yet crystallised.", "Performance Fee Record", "Amount", "", "EUR 3,400,000", "Internal", "", ""),
       ("Constraint Assessment Outcome", "Result of assessing whether it is highly probable (probable under US GAAP) that a significant reversal will not occur.", "Performance Fee Record", "Code", "Constraint Assessment Outcome", "Fully Constrained", "ASC 606", "IFRS 15", "Y"),
       ("Recognised Performance Fee Revenue", "Performance fee revenue recognised in the period.", "Performance Fee Record", "Amount", "", "EUR 0", "ASC 606", "IFRS 15", "Y"),
       ("Clawback Exposure Indicator", "Whether recognised fees may be clawed back.", "Performance Fee Record", "Boolean", "", "N", "AICPA Revenue Recognition Guide", "", ""),
     ]),
   ]),
   ("Distribution & Servicing Revenue", "12b-1 distribution and service fees, shareholder servicing fees and sales charges received by the distributor entity.", [
     ("Distribution Revenue Record", [
       ("Distribution Revenue Type", "Type of distribution-related revenue.", "Distribution Revenue Record", "Code", "Distribution Revenue Type", "12b-1 Service Fee", "SEC Rule 12b-1", "US GAAP Taxonomy", "Y"),
       ("Receiving Entity", "Internal entity (usually the principal underwriter / distributor) that receives the fee.", "Distribution Revenue Record", "Reference (Legal Entity)", "", "LEN-0007", "SEC Rule 12b-1", "", ""),
       ("Paying Share Class", "Share class whose assets pay the fee or whose sales generate the charge.", "Distribution Revenue Record", "Reference (Share Class)", "", "SHC-004513", "Internal", "", ""),
       ("Gross Distribution Revenue", "Amount received or receivable before pass-through to intermediaries.", "Distribution Revenue Record", "Amount", "", "USD 412,000", "ASC 606", "US GAAP Taxonomy", "Y"),
       ("Amount Passed Through", "Portion paid on to dealers of record, as calculated in 05 payment calculations.", "Distribution Revenue Record", "Amount", "", "USD 389,500", "Internal", "SEC Rule 12b-1", ""),
       ("Principal vs Agent Conclusion", "Whether the distributor controls the distribution service before transfer (principal, gross) or arranges it (agent, net).", "Distribution Revenue Record", "Code", "Principal vs Agent Conclusion", "Principal", "ASC 606", "IFRS 15", "Y"),
       ("Trailing Fee Constraint Indicator", "Whether trailing fees for past sales are constrained and recognised only as asset values become known.", "Distribution Revenue Record", "Boolean", "", "Y", "AICPA Revenue Recognition Guide", "ASC 606", ""),
       ("Sales Charge Source Transactions", "Purchase or redemption transactions generating front-end or contingent deferred sales charges.", "Distribution Revenue Record", "Reference (Transaction) (multi)", "", "TXN-2026-0912-88411", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Fee Waivers & Fund Expense Support", "DF-FWS",
  "Financial impact of fee waivers, expense caps, reimbursements, recoupment and fund costs borne by the adviser or distributor. The waiver and cap TERMS are owned by 01 Product.",
  [
   ("Waiver & Reimbursement Impact", "Period amounts waived or reimbursed under 01 Product expense cap terms.", [
     ("Waiver Record", [
       ("Waiver Record ID", "Unique identifier of the waiver or reimbursement record.", "Waiver Record", "Identifier", "", "WVR-2026-09-004512", "Internal", "", ""),
       ("Waiver Type", "Type of fee support.", "Waiver Record", "Code", "Waiver Type", "Contractual Fee Waiver", "SEC Form N-1A", "", "Y"),
       ("Supported Share Class", "Share class receiving the support.", "Waiver Record", "Reference (Share Class)", "", "SHC-004512", "Internal", "", ""),
       ("Expense Cap Terms Reference", "Share-class expense cap and waiver terms held in 01 Product (Expense Cap Rate, Waiver Expiry Date).", "Waiver Record", "Reference (Share Class Fee Terms)", "", "SHC-004512 / Expense Cap 0.95%", "Internal", "", ""),
       ("Waived Fee Amount", "Management or 12b-1 fee waived in the period.", "Waiver Record", "Amount", "", "USD 48,200", "Internal", "ASC 606", "Y"),
       ("Reimbursed Expense Amount", "Fund expenses reimbursed by the adviser in the period.", "Waiver Record", "Amount", "", "USD 13,200", "Internal", "ASC 606", ""),
       ("Waiver Accounting Treatment", "How the support is presented: reduction of revenue (consideration payable to a customer) or expense.", "Waiver Record", "Code", "Waiver Accounting Treatment", "Reduction of Revenue", "ASC 606", "IFRS 15", "Y"),
       ("Recoupment Eligible Indicator", "Whether the adviser may recoup the amount from the fund in later periods while staying under the cap.", "Waiver Record", "Boolean", "", "Y", "SEC Form N-1A", "", ""),
       ("Recoupment Expiry Date", "Last date the amount can be recouped (typically 3 years).", "Waiver Record", "Date", "ISO 8601", "2029-09-30", "SEC Form N-1A", "", ""),
     ]),
   ]),
   ("Adviser-Borne Fund Costs", "Fund-level costs the adviser or distributor pays from its own resources.", [
     ("Adviser-Borne Cost", [
       ("Adviser-Borne Cost Type", "Type of fund cost borne by the firm.", "Adviser-Borne Cost", "Code", "Adviser-Borne Cost Type", "Sub-TA Fee Above Fund Cap", "SEC IM Guidance 2016-01", "", ""),
       ("Related Payment Arrangement", "05 payment arrangement whose excess the firm bears.", "Adviser-Borne Cost", "Reference (Payment Arrangement)", "", "PYA-00871", "Internal", "", ""),
       ("Adviser-Borne Amount", "Amount borne for the period.", "Adviser-Borne Cost", "Amount", "", "USD 74,000", "Internal", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Distribution Expense Accounting", "DF-EXP",
  "Accounting records for distribution costs calculated elsewhere: partner payments (05), sales compensation (07), marketing spend (04) and data costs (14), with accruals, true-ups and cost-centre assignment.",
  [
   ("Distribution Cost Item", "One accounting cost line for distribution, linked to the source record that calculated it.", [
     ("Distribution Cost Item", [
       ("Distribution Cost Item ID", "Unique identifier of the distribution cost item.", "Distribution Cost Item", "Identifier", "", "DCO-2026-09-018822", "Internal", "", "Y"),
       ("Distribution Expense Category", "Category of distribution expense.", "Distribution Cost Item", "Code", "Distribution Expense Category", "Revenue Sharing", "Internal", "US GAAP Taxonomy", "Y"),
       ("Source Domain", "Business domain that calculated the amount.", "Distribution Cost Item", "Code", "Source Domain", "05 Distribution Agreements & Partners", "Internal", "", ""),
       ("Source Record", "ID of the calculating record (payment calculation, payment, statement, campaign, licence).", "Distribution Cost Item", "Reference (Source Record)", "", "PCL-2026Q2-00871", "Internal", "", "Y"),
       ("Cost Counterparty", "External party paid or payable.", "Distribution Cost Item", "Reference (Party)", "", "PTY-3301", "Internal", "", ""),
       ("Bearing Legal Entity", "Internal entity whose books bear the cost.", "Distribution Cost Item", "Reference (Legal Entity)", "", "LEN-0007", "Internal", "", "Y"),
       ("Funding Source", "Fund-paid under 12b-1, fund-paid for servicing, or adviser / distributor own resources (05 list).", "Distribution Cost Item", "Code", "External (05 DA - Funding Source)", "Adviser - Own Resources", "SEC Rule 12b-1", "SEC IM Guidance 2016-01", "Y"),
       ("Cost Centre", "Org unit / cost centre charged (09 OU-).", "Distribution Cost Item", "Reference (Org Unit)", "", "OU-CC-4410", "Internal", "", "Y"),
       ("Profit Centre", "Profit centre the cost belongs to, where different from the cost centre's default.", "Distribution Cost Item", "Reference (Org Unit)", "", "OU-PC-US-INT", "Internal", "", ""),
       ("Direct Product / Share Class", "Product or share class directly attributable, if any.", "Distribution Cost Item", "Reference (Product / Share Class)", "", "SHC-004512", "Internal", "", ""),
       ("Direct Channel", "Distribution channel directly attributable, if any.", "Distribution Cost Item", "Code", "External (Enterprise - Distribution Channel)", "Wirehouse", "Internal", "", ""),
       ("Service Period Start", "First day of the period the cost relates to.", "Distribution Cost Item", "Date", "ISO 8601", "2026-07-01", "Internal", "", ""),
       ("Service Period End", "Last day of the period the cost relates to.", "Distribution Cost Item", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
       ("Expense Amount", "Expense amount in transaction currency.", "Distribution Cost Item", "Amount", "", "USD 1,745,000", "Internal", "", "Y"),
       ("Directly Attributable Indicator", "Whether the cost is assigned directly to profitability dimensions or goes to a cost pool for allocation.", "Distribution Cost Item", "Boolean", "", "N", "Internal", "TDABC", ""),
       ("Capitalisation Outcome", "Whether the cost is expensed or capitalised as a contract cost asset.", "Distribution Cost Item", "Code", "Capitalisation Outcome", "Expense as Incurred", "ASC 340-40", "IFRS 15", ""),
       ("Inducement Assessment Reference", "08 compliance review covering the payment, carried for EU/UK cost reporting.", "Distribution Cost Item", "Reference (Compliance Review)", "", "REV-55120", "MiFID II", "", ""),
     ]),
   ]),
   ("Accruals & True-Ups", "Period-end accruals of distribution cost and their later true-up to invoiced or settled amounts.", [
     ("Accrual", [
       ("Accrual ID", "Unique identifier of the accrual.", "Accrual", "Identifier", "", "ACR-2026-09-00441", "Internal", "", ""),
       ("Accrued Cost Item", "Distribution cost item being accrued.", "Accrual", "Reference (Distribution Cost Item)", "", "DCO-2026-09-018822", "Internal", "", ""),
       ("Accrual Basis", "How the accrued amount was derived.", "Accrual", "Code", "Accrual Basis", "Engine Calculation", "Internal", "", ""),
       ("Accrual Period", "Fiscal period of the accrual.", "Accrual", "Code", "External (09 Shared - Fiscal Period)", "FY2026-P09", "Internal", "", ""),
       ("Accrued Amount", "Amount accrued.", "Accrual", "Amount", "", "USD 1,740,000", "Internal", "", "Y"),
       ("True-Up Amount", "Difference between accrued and final (invoiced, settled or recalculated) amount, booked in the true-up period.", "Accrual", "Amount", "", "USD 12,600", "Internal", "", "Y"),
       ("True-Up Reason", "Reason for the true-up.", "Accrual", "Code", "True-Up Reason", "Invoice Variance", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Contract Costs & Deferred Commissions", "DF-CCA",
  "Assets recognised for costs to obtain or fulfil contracts with customers (ASC 340-40 / IFRS 15 paras 91-98), legacy deferred sales commissions on back-end-load and level-load share classes, and the assessment of whether commissions qualify.",
  [
   ("Contract Cost Asset", "A capitalised contract cost and its amortisation and impairment.", [
     ("Contract Cost Asset", [
       ("Contract Cost Asset ID", "Unique identifier of the contract cost asset.", "Contract Cost Asset", "Identifier", "", "CCA-000118", "Internal", "", ""),
       ("Cost Asset Type", "Type of capitalised cost.", "Contract Cost Asset", "Code", "Cost Asset Type", "Deferred Sales Commission", "ASC 340-40", "IFRS 15", "Y"),
       ("Related Revenue Contract", "Revenue contract the cost relates to.", "Contract Cost Asset", "Reference (Revenue Contract)", "", "RVC-000231", "ASC 340-40", "", ""),
       ("Related Share Class", "Share class whose sales generated the cost (deferred commissions).", "Contract Cost Asset", "Reference (Share Class)", "", "SHC-004514", "Internal", "", ""),
       ("Originating Cost Items", "Distribution cost items capitalised into the asset.", "Contract Cost Asset", "Reference (Distribution Cost Item) (multi)", "", "DCO-2026-09-019001", "Internal", "", ""),
       ("Capitalised Amount", "Amount initially capitalised.", "Contract Cost Asset", "Amount", "", "USD 2,300,000", "ASC 340-40", "IFRS 15", "Y"),
       ("Amortisation Method", "Systematic basis of amortisation consistent with the transfer of related services.", "Contract Cost Asset", "Code", "Amortisation Method", "Straight-Line", "ASC 340-40", "IFRS 15", ""),
       ("Amortisation Period", "Months over which the asset is amortised (e.g. CDSC period for back-end-load shares).", "Contract Cost Asset", "Integer", "Months", "12", "ASC 340-40", "", ""),
       ("CDSC Recovery Offset", "Contingent deferred sales charges received on early redemption that reduce the unamortised asset.", "Contract Cost Asset", "Amount", "", "USD 41,000", "AICPA Revenue Recognition Guide", "", ""),
       ("Net Carrying Amount", "Capitalised amount less amortisation, recoveries and impairment.", "Contract Cost Asset", "Amount", "", "USD 1,684,000", "ASC 340-40", "IFRS 15", "Y"),
       ("Impairment Loss Amount", "Impairment recognised when carrying amount exceeds remaining consideration less costs.", "Contract Cost Asset", "Amount", "", "USD 0", "ASC 340-40", "IFRS 15", ""),
     ]),
   ]),
   ("Commission Capitalisation Assessment", "Policy assessment of whether a commission or fee is an incremental cost of obtaining a contract with the customer.", [
     ("Capitalisation Assessment", [
       ("Assessed Cost Source", "Compensation plan component (07 ICP-), payment arrangement (05 PYA-) or placement fee being assessed.", "Capitalisation Assessment", "Reference (Plan Component / Payment Arrangement)", "", "ICP-US-EW-2027-C02", "Internal", "", ""),
       ("Incremental Indicator", "Whether the cost would not have been incurred had the contract not been obtained.", "Capitalisation Assessment", "Boolean", "", "N", "ASC 340-40", "IFRS 15", ""),
       ("Customer Contract Linkage", "How the cost links to a contract with the identified customer. Wholesaler commissions on fund sales usually do not obtain a new contract with the fund.", "Capitalisation Assessment", "Code", "Customer Contract Linkage", "Linked to Fund Share Sales Only", "AICPA Revenue Recognition Guide", "ASC 340-40", ""),
       ("Practical Expedient Applied Indicator", "Whether the one-year practical expedient (expense if amortisation period is one year or less) is applied.", "Capitalisation Assessment", "Boolean", "", "Y", "ASC 340-40", "IFRS 15", ""),
       ("Assessment Conclusion", "Conclusion of the assessment.", "Capitalisation Assessment", "Code", "Capitalisation Outcome", "Expense as Incurred", "ASC 340-40", "IFRS 15", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Chart of Accounts & GL Posting", "DF-COA",
  "Mapping of distribution revenue and expense to management P&L lines, general-ledger accounts and external reporting lines, and the journal postings that carry them.",
  [
   ("Account Mapping", "Effective-dated mapping from management P&L line to GL account and external reporting line.", [
     ("Account Mapping", [
       ("Account Mapping ID", "Unique identifier of the mapping.", "Account Mapping", "Identifier", "", "ACM-0142", "Internal", "", ""),
       ("Management P&L Line", "Line on the distribution management P&L.", "Account Mapping", "Code", "Management P&L Line", "Revenue Sharing & Platform Fees", "Internal", "", "Y"),
       ("GL Natural Account", "General-ledger natural account.", "Account Mapping", "Code", "Firm-defined", "620410", "Internal", "", "Y"),
       ("Applicable Ledger", "Ledger the mapping applies to.", "Account Mapping", "Code", "Ledger", "Primary - US GAAP", "Internal", "", ""),
       ("External Reporting Line", "Line in the published income statement or note.", "Account Mapping", "Text", "", "Distribution and servicing fees", "US GAAP Taxonomy", "IFRS 15", ""),
       ("XBRL Element", "US GAAP Taxonomy element used to tag the external line (to be confirmed per filing).", "Account Mapping", "Text", "External (US GAAP Taxonomy)", "us-gaap:DistributionAndServicingFees (to confirm)", "US GAAP Taxonomy", "", ""),
       ("Revenue Disaggregation Category", "Category used in the ASC 606 / IFRS 15 disaggregation of revenue note.", "Account Mapping", "Code", "Revenue Stream", "Distribution Fee", "ASC 606", "IFRS 15", ""),
       ("Mapping Effective From", "Date the mapping applies from.", "Account Mapping", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Mapping Effective To", "Date the mapping ends.", "Account Mapping", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("GL Posting", "Journal lines posted to the ledger for distribution revenue and cost.", [
     ("GL Posting", [
       ("Journal ID", "Unique identifier of the journal.", "GL Posting", "Identifier", "", "JNL-2026-09-77120", "Internal", "SOX", ""),
       ("Journal Type", "Type of journal.", "GL Posting", "Code", "Journal Type", "Accrual", "Internal", "", ""),
       ("Posting Date", "Date the journal posted.", "GL Posting", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
       ("Posting Accounting Period", "Fiscal period of the posting.", "GL Posting", "Code", "External (09 Shared - Fiscal Period)", "FY2026-P09", "Internal", "", "Y"),
       ("Posting Legal Entity", "Internal legal entity whose ledger is posted.", "GL Posting", "Reference (Legal Entity)", "", "LEN-0007", "Internal", "", ""),
       ("Posted Account", "GL natural account posted.", "GL Posting", "Code", "Firm-defined", "620410", "Internal", "", ""),
       ("Posted Amount", "Amount of the journal line in ledger currency.", "GL Posting", "Amount", "", "USD 1,740,000", "Internal", "", "Y"),
       ("Source Finance Record", "Fee revenue record, cost item, accrual, allocation run or intercompany charge that generated the line.", "GL Posting", "Reference (FRR- / DCO- / ACR- / ARN- / ICC-)", "", "ACR-2026-09-00441", "Internal", "SOX", "Y"),
       ("Intercompany Partner Entity", "Counterparty internal entity for intercompany lines.", "GL Posting", "Reference (Legal Entity)", "", "LEN-0011", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Cost Allocation", "DF-ALC",
  "Cost pools, allocation methods, drivers and rules, and the runs that spread indirect distribution cost to profitability dimensions.",
  [
   ("Cost Pools", "Groupings of indirect cost to be allocated.", [
     ("Cost Pool", [
       ("Cost Pool ID", "Unique identifier of the cost pool.", "Cost Pool", "Identifier", "", "CPO-SALES-US", "Internal", "", ""),
       ("Cost Pool Type", "Functional type of cost in the pool.", "Cost Pool", "Code", "Cost Pool Type", "Sales", "Internal", "TDABC", ""),
       ("Contributing Cost Centres", "Cost centres (09 OU-) whose cost flows into the pool.", "Cost Pool", "Reference (Org Unit) (multi)", "", "OU-CC-4410; OU-CC-4420", "Internal", "", ""),
       ("Included Expense Categories", "Distribution expense categories included in the pool.", "Cost Pool", "Code (multi)", "Distribution Expense Category", "Sales Compensation; Travel & Entertainment", "Internal", "", ""),
     ]),
   ]),
   ("Allocation Methods & Drivers", "How cost is spread and the measured quantities that drive it.", [
     ("Allocation Method", [
       ("Allocation Method ID", "Unique identifier of the allocation method.", "Allocation Method", "Identifier", "", "ALM-007", "Internal", "", ""),
       ("Allocation Method Name", "Business name of the method.", "Allocation Method", "Text", "", "Wholesaler time by channel (TDABC)", "Internal", "", ""),
       ("Allocation Method Type", "Type of method.", "Allocation Method", "Code", "Allocation Method Type", "Time-Driven Activity-Based", "TDABC", "Internal", "Y"),
       ("Method Description", "How the method works, including treatment of unused capacity.", "Allocation Method", "Text", "", "Capacity cost rate x minutes per activity; unused capacity held at pool level", "TDABC", "", ""),
     ]),
     ("Allocation Driver", [
       ("Allocation Driver ID", "Unique identifier of the driver.", "Allocation Driver", "Identifier", "", "DRV-AVGAUM", "Internal", "", ""),
       ("Driver Type", "Quantity used to allocate.", "Allocation Driver", "Code", "Allocation Driver Type", "Average AUM", "Internal", "TDABC", "Y"),
       ("Driver Source Measure", "06 TX measure, 03 activity count or other source of the driver quantity.", "Allocation Driver", "Code", "External (06 TX - Flow & AUM Measure)", "MSR-AVGAUM", "Internal", "", ""),
       ("Capacity Cost Rate", "Cost per unit of practical capacity (e.g. per minute of wholesaler time).", "Allocation Driver", "Decimal", "", "USD 2.85 per minute", "TDABC", "", ""),
       ("Unit Time Estimate", "Minutes consumed per activity unit (TDABC time equation term).", "Allocation Driver", "Decimal", "", "45", "TDABC", "", ""),
     ]),
   ]),
   ("Allocation Rules", "Rules that apply a method and driver to a pool and target.", [
     ("Allocation Rule", [
       ("Allocation Rule ID", "Unique identifier of the rule.", "Allocation Rule", "Identifier", "", "ARU-0031", "Internal", "", ""),
       ("Source Cost Pool", "Pool the rule allocates from.", "Allocation Rule", "Reference (Cost Pool)", "", "CPO-SALES-US", "Internal", "", "Y"),
       ("Applied Allocation Method", "Method applied by the rule.", "Allocation Rule", "Reference (Allocation Method)", "", "ALM-007", "Internal", "", ""),
       ("Applied Driver", "Driver applied by the rule.", "Allocation Rule", "Reference (Allocation Driver)", "", "DRV-AVGAUM", "Internal", "", ""),
       ("Target Dimension", "Profitability dimension the cost is allocated to.", "Allocation Rule", "Code", "Profitability Dimension", "Partner Firm", "Internal", "", "Y"),
       ("Allocation Sequence", "Order of the rule in a step-down allocation.", "Allocation Rule", "Integer", "", "3", "Internal", "", ""),
       ("Rule Effective From", "Date the rule applies from.", "Allocation Rule", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Rule Effective To", "Date the rule ends.", "Allocation Rule", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Allocation Runs & Results", "Executions of the allocation rule set and the amounts produced.", [
     ("Allocation Run", [
       ("Allocation Run ID", "Unique identifier of the run.", "Allocation Run", "Identifier", "", "ARN-2026-09-A01", "Internal", "SOX", "Y"),
       ("Run Period", "Fiscal period allocated.", "Allocation Run", "Code", "External (09 Shared - Fiscal Period)", "FY2026-P09", "Internal", "", ""),
       ("Run Data Version", "Version of data allocated (actual, budget, forecast).", "Allocation Run", "Code", "Data Version", "Actual", "Internal", "", ""),
       ("Run Status", "Status of the run.", "Allocation Run", "Code", "Run Status", "Final", "Internal", "", ""),
       ("Unallocated Residual", "Pool cost left unallocated (e.g. unused capacity).", "Allocation Run", "Amount", "", "USD 312,000", "TDABC", "", ""),
     ]),
     ("Allocation Result", [
       ("Allocated Rule", "Rule that produced the result.", "Allocation Result", "Reference (Allocation Rule)", "", "ARU-0031", "Internal", "", ""),
       ("Target Dimension Member", "Member receiving the allocation (partner, channel, product, etc.).", "Allocation Result", "Reference (Dimension Member)", "", "PTY-3301", "Internal", "", ""),
       ("Driver Share", "Member's share of the driver quantity.", "Allocation Result", "Percentage", "", "6.4%", "Internal", "", ""),
       ("Allocated Amount", "Cost allocated to the member.", "Allocation Result", "Amount", "", "USD 228,500", "Internal", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Profitability & Cost-to-Serve", "DF-PNL",
  "Profitability records at a declared dimension grain and version, the certified profitability measures, and cost-to-serve profiles for partners and clients.",
  [
   ("Profitability Record", "One row of the distribution P&L at a declared grain, period and version.", [
     ("Profitability Record", [
       ("Profitability Record ID", "Unique identifier of the profitability record.", "Profitability Record", "Identifier", "", "PNL-2026-09-ACT-000918", "Internal", "", "Y"),
       ("Profitability Period", "Fiscal period of the record.", "Profitability Record", "Code", "External (09 Shared - Fiscal Period)", "FY2026-P09", "Internal", "", "Y"),
       ("Data Version", "Actual, budget, forecast or scenario.", "Profitability Record", "Code", "Data Version", "Actual", "Internal", "", "Y"),
       ("Dimension Grain", "Set of dimensions the record is held at.", "Profitability Record", "Code (multi)", "Profitability Dimension", "Channel; Partner Firm; Share Class", "Internal", "", "Y"),
       ("Channel", "Distribution channel.", "Profitability Record", "Code", "External (Enterprise - Distribution Channel)", "Wirehouse", "Internal", "", ""),
       ("Partner Firm", "Distributor firm (02 PTY-).", "Profitability Record", "Reference (Party)", "", "PTY-3301", "Internal", "", ""),
       ("Product / Share Class", "Product or share class (01).", "Profitability Record", "Reference (Product / Share Class)", "", "SHC-004512", "Internal", "", ""),
       ("Territory", "Sales territory (07 TER-).", "Profitability Record", "Reference (Territory)", "", "TER-US-NE-03", "Internal", "", ""),
       ("Salesperson", "Internal salesperson (03 EMP-).", "Profitability Record", "Reference (Employee)", "", "EMP-01377", "Internal", "", "", "PII; confidential"),
       ("Client / Account", "Institutional client or account (02 PTY-/ACC-).", "Profitability Record", "Reference (Party / Account)", "", "ACC-778120", "Internal", "", ""),
       ("Client Segment", "Client segment (02).", "Profitability Record", "Code", "External (02 CC - Client Segment)", "Large RIA", "Internal", "", ""),
       ("Reporting Legal Entity", "Internal legal entity the record belongs to.", "Profitability Record", "Reference (Legal Entity)", "", "LEN-0003", "Internal", "", ""),
       ("Hierarchy Version", "Management hierarchy version used to roll the record up.", "Profitability Record", "Reference (Management Hierarchy)", "", "MHY-CHANNEL-2026v2", "Internal", "", "Y"),
       ("Source Allocation Run", "Allocation run whose results are included.", "Profitability Record", "Reference (Allocation Run)", "", "ARN-2026-09-A01", "Internal", "", "Y"),
       ("Average AUM Reference", "Average AUM for the grain (06 measure value), used for bps measures.", "Profitability Record", "Amount", "", "USD 640,000,000", "Internal", "", ""),
       ("Reporting Currency", "Currency of the amounts.", "Profitability Record", "Code", "ISO 4217", "USD", "ISO 4217", "", ""),
     ]),
   ]),
   ("Profitability Measures", "Certified measures held on each profitability record.", [
     ("Profitability Measure", [
       ("Gross Revenue", "Management, performance and distribution fee revenue after waivers attributed to the grain.", "Profitability Record", "Amount", "", "USD 1,050,000", "Internal", "ASC 606", "Y"),
       ("Distribution Payments", "Revenue sharing, sub-TA, 12b-1 pass-through, platform fees and retrocessions charged to the grain.", "Profitability Record", "Amount", "", "USD 260,000", "Internal", "", ""),
       ("Net Revenue After Distribution Costs", "Gross revenue less distribution payments.", "Profitability Record", "Amount", "", "USD 790,000", "Internal", "", "Y"),
       ("Net Revenue Yield", "Net revenue after distribution costs, annualised over average AUM.", "Profitability Record", "Decimal", "Basis points", "49.4", "Internal", "McKinsey Performance Lens", "Y"),
       ("Direct Sales & Marketing Cost", "Directly attributable sales compensation, marketing and servicing cost.", "Profitability Record", "Amount", "", "USD 180,000", "Internal", "", ""),
       ("Contribution Margin", "Net revenue after distribution costs less direct sales and marketing cost.", "Profitability Record", "Amount", "", "USD 610,000", "Internal", "", "Y"),
       ("Allocated Indirect Cost", "Indirect cost allocated from cost pools.", "Profitability Record", "Amount", "", "USD 228,500", "Internal", "TDABC", ""),
       ("Operating Profit", "Contribution margin less allocated indirect cost (fully loaded).", "Profitability Record", "Amount", "", "USD 381,500", "Internal", "", "Y"),
       ("Operating Margin", "Operating profit divided by gross revenue.", "Profitability Record", "Percentage", "", "36.3%", "Internal", "McKinsey Performance Lens", ""),
     ]),
     ("Profitability Measure Definition", [
       ("Profitability Measure Code", "Identifier of the measure in the catalogue.", "Profitability Measure", "Code", "Profitability Measure", "Net Revenue Yield", "Internal", "", ""),
       ("Measure Formula", "Formula in terms of P&L lines and AUM.", "Profitability Measure", "Text", "", "(Gross Revenue - Distribution Payments) / Average AUM x 10,000 x (365 / days)", "Internal", "", ""),
     ]),
   ]),
   ("Cost-to-Serve", "Total cost of supporting a partner or client relationship, relative to the assets and revenue it produces.", [
     ("Cost-to-Serve Profile", [
       ("Served Party", "Partner firm or client the profile describes.", "Cost-to-Serve Profile", "Reference (Party)", "", "PTY-3301", "Internal", "", ""),
       ("Partner Payments Cost", "Total partner payments for the period (05 sourced, accounted in 10).", "Cost-to-Serve Profile", "Amount", "", "USD 1,745,000", "Internal", "", ""),
       ("Coverage and Servicing Cost", "Allocated wholesaling, national-accounts and client-service cost.", "Cost-to-Serve Profile", "Amount", "", "USD 640,000", "Internal", "TDABC", ""),
       ("Total Cost-to-Serve", "Sum of all costs to serve the party for the period.", "Cost-to-Serve Profile", "Amount", "", "USD 2,635,000", "Internal", "", "Y"),
       ("Cost-to-Serve Rate", "Total cost-to-serve annualised over average AUM.", "Cost-to-Serve Profile", "Decimal", "Basis points", "16.9", "Internal", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Management Reporting Hierarchies", "DF-HIR",
  "Versioned hierarchies for channel, product, region and entity P&L, their node structure, segment mapping and restatements when hierarchies change.",
  [
   ("Management Hierarchy", "A versioned rollup structure used for management P&L.", [
     ("Management Hierarchy", [
       ("Management Hierarchy ID", "Unique identifier of the hierarchy version.", "Management Hierarchy", "Identifier", "", "MHY-CHANNEL-2026v2", "Internal", "", "Y"),
       ("Hierarchy Type", "Dimension the hierarchy organises.", "Management Hierarchy", "Code", "Hierarchy Type", "Channel", "Internal", "", "Y"),
       ("Hierarchy Status", "Lifecycle status of the version.", "Management Hierarchy", "Code", "Hierarchy Status", "Active", "Internal", "", ""),
       ("Hierarchy Effective From", "Date the version applies from.", "Management Hierarchy", "Date", "ISO 8601", "2026-07-01", "Internal", "", ""),
       ("Hierarchy Effective To", "Date the version ends.", "Management Hierarchy", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Hierarchy Node", [
       ("Node ID", "Identifier of the node within the hierarchy.", "Hierarchy Node", "Identifier", "", "MHY-CHANNEL-2026v2.N0142", "Internal", "", ""),
       ("Parent Node", "Node directly above.", "Hierarchy Node", "Reference (Hierarchy Node)", "", "MHY-CHANNEL-2026v2.N0100", "Internal", "", "Y"),
       ("Leaf Member", "Dimension member mapped to a leaf node (channel code, SHC-, TER-, OU-, GEO-).", "Hierarchy Node", "Reference (Dimension Member)", "", "TER-US-NE-03", "Internal", "", ""),
       ("Operating Segment Mapping", "Reportable operating segment the node rolls into, where management and segment reporting align.", "Hierarchy Node", "Text", "", "Investment Management (single segment)", "ASC 280", "IFRS 8", ""),
     ]),
   ]),
   ("Hierarchy Restatement", "Recorded decisions to restate prior-period P&L when a hierarchy, allocation rule or mapping changes.", [
     ("Hierarchy Restatement", [
       ("Restatement ID", "Unique identifier of the restatement.", "Hierarchy Restatement", "Identifier", "", "HRS-2026-007", "Internal", "", ""),
       ("Restatement Trigger", "Change that triggered the restatement.", "Hierarchy Restatement", "Code", "Restatement Trigger", "Channel Reorganisation", "Internal", "", ""),
       ("Restatement Method", "How history is treated.", "Hierarchy Restatement", "Code", "Restatement Method", "Full Restatement", "Internal", "ASC 280", "Y"),
       ("Restated From Period", "First period restated.", "Hierarchy Restatement", "Code", "External (09 Shared - Fiscal Period)", "FY2025-P01", "Internal", "", ""),
       ("Restated To Period", "Last period restated.", "Hierarchy Restatement", "Code", "External (09 Shared - Fiscal Period)", "FY2026-P06", "Internal", "", ""),
       ("Prior Hierarchy Version", "Hierarchy version replaced.", "Hierarchy Restatement", "Reference (Management Hierarchy)", "", "MHY-CHANNEL-2026v1", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Budgets, Forecasts & Plans", "DF-BUD",
  "Distribution budgets, rolling forecasts, long-range plans and scenarios, flow and revenue forecasts, and plan-vs-actual variance.",
  [
   ("Plan Version", "A budget, forecast or scenario version.", [
     ("Plan Version", [
       ("Plan Version ID", "Unique identifier of the plan version.", "Plan Version", "Identifier", "", "BUD-FY2027-B1", "Internal", "", "Y"),
       ("Plan Type", "Type of plan.", "Plan Version", "Code", "Plan Type", "Annual Budget", "Internal", "", "Y"),
       ("Scenario", "Scenario the version represents.", "Plan Version", "Code", "Scenario", "Base", "Internal", "", ""),
       ("Plan Fiscal Year", "Fiscal year covered.", "Plan Version", "Code", "External (09 Shared - Fiscal Period)", "FY2027", "Internal", "", ""),
       ("Plan Version Status", "Workflow status.", "Plan Version", "Code", "Plan Version Status", "Approved", "Internal", "", ""),
       ("Market Return Assumption", "Assumed market appreciation applied to AUM.", "Plan Version", "Percentage", "", "5.0% p.a. equities; 3.0% p.a. fixed income", "Internal", "", ""),
     ]),
   ]),
   ("Plan Lines", "Planned amounts by P&L line and dimension.", [
     ("Plan Line", [
       ("Plan P&L Line", "Management P&L line planned.", "Plan Line", "Code", "Management P&L Line", "Marketing Spend", "Internal", "", ""),
       ("Plan Cost Centre", "Cost centre the amount is planned in.", "Plan Line", "Reference (Org Unit)", "", "OU-CC-4510", "Internal", "", ""),
       ("Plan Dimension Members", "Channel, partner or product the line is planned at, where below cost-centre level.", "Plan Line", "Reference (Dimension Member) (multi)", "", "Wirehouse; PTY-3301", "Internal", "", ""),
       ("Plan Period", "Fiscal period of the amount.", "Plan Line", "Code", "External (09 Shared - Fiscal Period)", "FY2027-P03", "Internal", "", ""),
       ("Planned Amount", "Planned amount.", "Plan Line", "Amount", "", "USD 420,000", "Internal", "", "Y"),
       ("Driver-Based Indicator", "Whether the amount is computed from drivers (AUM x bps) rather than entered.", "Plan Line", "Boolean", "", "Y", "Internal", "", ""),
     ]),
   ]),
   ("Flow & Revenue Forecast", "Forecast flows, AUM and revenue that drive distribution revenue and asset-based costs.", [
     ("Flow & Revenue Forecast", [
       ("Forecast Share Class / Product", "Share class or product forecast.", "Forecast", "Reference (Product / Share Class)", "", "SHC-004512", "Internal", "", ""),
       ("Sales Forecast Reference", "03 Sales pipeline forecast used as input, if any.", "Forecast", "Reference (Sales Forecast)", "", "FCS-2026-Q4-US", "Internal", "", ""),
       ("Forecast Gross Sales", "Forecast gross sales for the period (06 measure definition).", "Forecast", "Amount", "", "USD 120,000,000", "ICI", "", ""),
       ("Forecast Redemptions", "Forecast redemptions for the period.", "Forecast", "Amount", "", "USD 95,000,000", "ICI", "", ""),
       ("Forecast Average AUM", "Forecast average AUM.", "Forecast", "Amount", "", "USD 1,880,000,000", "Internal", "", ""),
       ("Forecast Net Fee Rate", "Forecast net fee rate after waivers.", "Forecast", "Decimal", "Basis points", "64.0", "Internal", "", ""),
       ("Forecast Net Revenue", "Forecast net fee revenue.", "Forecast", "Amount", "", "USD 1,002,700", "Internal", "", "Y"),
     ]),
   ]),
   ("Plan vs Actual Variance", "Variance between actual and a plan version, with driver decomposition.", [
     ("Variance", [
       ("Compared Plan Version", "Plan version compared with actual.", "Variance", "Reference (Plan Version)", "", "BUD-FY2026-B1", "Internal", "", ""),
       ("Variance Amount", "Actual minus plan.", "Variance", "Amount", "", "USD -84,000", "Internal", "", "Y"),
       ("Variance Driver", "Main cause of the variance.", "Variance", "Code", "Variance Driver", "Market", "Internal", "", ""),
       ("Variance Commentary", "Explanation provided by FP&A.", "Variance", "Text", "", "Lower equity markets reduced average AUM 6%", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Intercompany & Transfer Pricing", "DF-ICT",
  "Intercompany agreements between distributor entities, ManCos and investment managers, their transfer pricing policies and the resulting charges and settlements.",
  [
   ("Intercompany Agreement", "Agreement for services between internal legal entities.", [
     ("Intercompany Agreement", [
       ("Intercompany Agreement ID", "Unique identifier of the intercompany agreement.", "Intercompany Agreement", "Identifier", "", "ICA-0019", "Internal", "", "Y"),
       ("Service Provider Entity", "Internal entity providing the service.", "Intercompany Agreement", "Reference (Legal Entity)", "", "LEN-0021 (UK distributor)", "Internal", "OECD TPG", "Y"),
       ("Service Recipient Entity", "Internal entity receiving and paying for the service.", "Intercompany Agreement", "Reference (Legal Entity)", "", "LEN-0004 (Lux ManCo)", "Internal", "OECD TPG", ""),
       ("Intercompany Service Type", "Type of service.", "Intercompany Agreement", "Code", "Intercompany Service Type", "Distribution Services", "OECD TPG", "", "Y"),
       ("Covered Products", "Products or share classes in scope.", "Intercompany Agreement", "Reference (Product) (multi)", "", "PRD-00981", "Internal", "", ""),
       ("Agreement Effective From", "Date the agreement applies from.", "Intercompany Agreement", "Date", "ISO 8601", "2025-01-01", "Internal", "", ""),
       ("Agreement Effective To", "Date the agreement ends.", "Intercompany Agreement", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Transfer Pricing Policy", "Arm's-length pricing method and parameters for an intercompany agreement.", [
     ("TP Policy", [
       ("TP Method", "OECD transfer pricing method applied.", "TP Policy", "Code", "TP Method", "Transactional Net Margin Method", "OECD TPG", "", "Y"),
       ("Remuneration Basis", "How the provider is remunerated.", "TP Policy", "Code", "TP Remuneration Basis", "Share of Management Fee", "OECD TPG", "", ""),
       ("Remuneration Rate", "Mark-up on cost or fee-share percentage.", "TP Policy", "Percentage", "", "40% of net management fee", "OECD TPG", "", "Y"),
       ("Tested Party", "Entity whose result is tested against comparables.", "TP Policy", "Reference (Legal Entity)", "", "LEN-0021", "OECD TPG", "", ""),
       ("Arm's Length Range Lower Bound", "Lower bound of the arm's-length interquartile range for the profit level indicator.", "TP Policy", "Percentage", "", "4.2%", "OECD TPG", "", ""),
       ("Arm's Length Range Upper Bound", "Upper bound of the range.", "TP Policy", "Percentage", "", "9.8%", "OECD TPG", "", ""),
       ("TP Documentation Reference", "Master file / local file reference.", "TP Policy", "Text", "", "UK Local File FY2025 s.4.2", "OECD TPG", "", ""),
     ]),
   ]),
   ("Intercompany Charge", "Period charges calculated under an intercompany agreement and their settlement.", [
     ("Intercompany Charge", [
       ("Intercompany Charge ID", "Unique identifier of the charge.", "Intercompany Charge", "Identifier", "", "ICC-2026-09-0019", "Internal", "", ""),
       ("Charging Agreement", "Agreement under which the charge is made.", "Intercompany Charge", "Reference (Intercompany Agreement)", "", "ICA-0019", "Internal", "", ""),
       ("Charge Period", "Fiscal period of the charge.", "Intercompany Charge", "Code", "External (09 Shared - Fiscal Period)", "FY2026-P09", "Internal", "", ""),
       ("Charge Amount", "Amount charged.", "Intercompany Charge", "Amount", "", "EUR 980,000", "OECD TPG", "", "Y"),
       ("VAT Treatment", "VAT treatment of the charge (fund management exemption may apply).", "Intercompany Charge", "Code", "VAT Treatment", "Exempt - Fund Management", "Internal", "", ""),
       ("Settlement Status", "Settlement status of the charge.", "Intercompany Charge", "Code", "Settlement Status", "Settled", "Internal", "", ""),
       ("Elimination Indicator", "Whether the charge is eliminated on consolidation.", "Intercompany Charge", "Boolean", "", "Y", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Period Close, Controls & Data Management", "DF-DMM",
  "Accounting period status, FX translation, reconciliation controls and data management metadata for the distribution finance domain.",
  [
   ("Period Close & Translation", "Close status and currency translation applied to distribution finance records.", [
     ("Accounting Period Status", [
       ("Period Close Status", "Close status of the fiscal period for distribution finance.", "Accounting Period", "Code", "Period Close Status", "Soft Close", "Internal", "", ""),
       ("Translation Rate Type", "FX rate type used to translate to reporting currency (09 reference).", "Accounting Period", "Code", "External (09 Shared - FX Rate Type)", "Monthly Average", "Internal", "", ""),
     ]),
   ]),
   ("Controls & Reconciliation", "Reconciliations evidencing that finance records agree with source domains and the ledger.", [
     ("Control", [
       ("Reconciliation Type", "Reconciliation performed.", "Control", "Code", "Reconciliation Type", "Booked vs Estimated Revenue (06)", "Internal", "SOX", ""),
       ("Reconciliation Status", "Result of the reconciliation.", "Control", "Code", "Reconciliation Status", "Reconciled within Tolerance", "Internal", "SOX", ""),
       ("Control Reference", "Key control the reconciliation evidences.", "Control", "Text", "", "DF-KC-07", "SOX", "", ""),
     ]),
   ]),
   ("Data Management Metadata", "Metadata applied to every record in the distribution finance domain.", [
     ("Record Metadata", [
       ("Data Owner", "Business role accountable for the data element.", "All", "Reference (Employee)", "", "Head of Distribution Finance", "DCAM (EDM Council)", "", ""),
       ("Data Steward", "Role responsible for day-to-day data quality.", "All", "Reference (Employee)", "", "FP&A Data Steward", "DCAM (EDM Council)", "", ""),
       ("System of Record", "System holding the authoritative value.", "All", "Code", "Firm-defined", "ERP General Ledger", "Internal", "", ""),
       ("Data Classification", "Confidentiality classification of the record.", "All", "Code", "Data Classification", "Confidential - Financial", "Internal", "", ""),
       ("Record Effective From", "Business-effective start date of the record version.", "All", "Date", "ISO 8601", "2026-09-01", "Internal", "", ""),
       ("Record Effective To", "Business-effective end date of the record version.", "All", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Last Updated Timestamp", "System timestamp of the last change.", "All", "Timestamp", "ISO 8601", "2026-10-06T18:22:10Z", "Internal", "", ""),
       ("Data Quality Status", "Validation status of the record.", "All", "Code", "Data Quality Status", "Validated", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Revenue Contract Type": ("Internal (aligned to AICPA Revenue Recognition Guide, asset management)", [("Investment Advisory Agreement (Fund)","'40 Act or UCITS / AIF management agreement with the fund"),("Sub-Advisory Agreement","Firm acts as sub-adviser to a third-party fund"),("Investment Management Agreement (Mandate)","Segregated / separate account IMA"),("Principal Underwriting / Distribution Agreement","Distributor and fund under a 12b-1 plan or distribution agreement"),("Shareholder Servicing Agreement",""),("ManCo Services Agreement","Third-party ManCo / AIFM services"),("Model Delivery Licence","Model portfolio delivered to a sponsor"),("CIT Trustee / Advisory Agreement","")]),
 "Customer Determination Basis": ("AICPA Revenue Recognition Guide", [("Fund is Customer","Typical for '40 Act funds, UCITS and CITs"),("Investor is Customer","Typical for separate accounts / mandates"),("Platform Sponsor is Customer","Model delivery / wrap sponsor"),("Under Review","")]),
 "Accounting Framework": ("Internal", [("US GAAP",""),("IFRS (EU-adopted)",""),("UK-adopted IFRS",""),("FRS 102 (UK GAAP)",""),("Lux GAAP","")]),
 "Performance Obligation Type": ("ASC 606 / IFRS 15", [("Asset Management Services (Series)","Daily / monthly investment management"),("Distribution Service","Sale of fund shares; satisfied at the point of sale"),("Shareholder Servicing","Ongoing servicing over time"),("Administration Services",""),("Model Delivery Services","")]),
 "Satisfaction Pattern": ("ASC 606 / IFRS 15", [("Over Time",""),("Point in Time","")]),
 "Revenue Stream": ("Internal (aligned to US GAAP Taxonomy disaggregation)", [("Management Fee",""),("Performance Fee",""),("Distribution Fee","12b-1 distribution component"),("Service Fee","12b-1 service component / shareholder servicing"),("Sales Charge","Front-end loads retained and CDSC"),("Administration Fee",""),("Sub-Advisory Fee",""),("Other Revenue","")]),
 "Fee Basis Source": ("Internal", [("Fund Accounting NAV",""),("Transfer Agent Positions",""),("Custodian Valuation","Mandates"),("06 Average AUM Measure","Estimate only"),("Client Invoice (12 BIL-)","Segregated mandates")]),
 "Revenue Data Basis": ("Internal", [("Actual","Billed / settled"),("Accrued Estimate","Daily or month-end accrual"),("Allocated","Spread from a higher grain"),("Restated","")]),
 "Constraint Assessment Outcome": ("ASC 606 / IFRS 15", [("Fully Constrained","No revenue recognised"),("Partially Constrained","Recognised up to the unconstrained amount"),("Unconstrained","Crystallised / no longer subject to reversal")]),
 "Distribution Revenue Type": ("SEC Rule 12b-1 / FINRA Rule 2341", [("12b-1 Distribution Fee",""),("12b-1 Service Fee",""),("Shareholder Servicing Fee","Non-12b-1"),("Front-End Sales Charge Retained","Underwriter concession net of dealer reallowance"),("Contingent Deferred Sales Charge",""),("Placement Fee Received","")]),
 "Principal vs Agent Conclusion": ("ASC 606 / IFRS 15", [("Principal","Present gross; pass-through as expense"),("Agent","Present net of pass-through"),("Under Review","")]),
 "Waiver Type": ("SEC Form N-1A / Internal", [("Contractual Fee Waiver",""),("Voluntary Fee Waiver",""),("Expense Reimbursement",""),("Money Market Yield Waiver","Waiver to maintain non-negative yield"),("Acquired Fund Fee Waiver","Waiver for fees of affiliated underlying funds"),("12b-1 Fee Waiver","")]),
 "Waiver Accounting Treatment": ("ASC 606 / IFRS 15", [("Reduction of Revenue","Consideration payable to a customer"),("Operating Expense","Where payment is for a distinct service"),("Under Review","")]),
 "Adviser-Borne Cost Type": ("Internal", [("Sub-TA Fee Above Fund Cap",""),("Revenue Sharing (Own Resources)",""),("Fund Organisation and Offering Costs",""),("Fund Expense Above Cap",""),("Seed Capital Cost","")]),
 "Distribution Expense Category": ("Internal (aligned to US GAAP Taxonomy and ICI usage)", [("Revenue Sharing","Asset- or sales-based payments from own resources"),("Sub-TA / Networking Fees",""),("12b-1 Paid to Intermediaries",""),("Platform Fees",""),("Trail Commission / Retrocession","EU/UK"),("Dealer Commission (Advanced)","Up-front commission on level- or back-end-load shares"),("Conference & Programme Sponsorship",""),("Partner Data Fees","Sales and positions data from partners"),("Third-Party Data Licences","14 DLA- costs"),("Sales Compensation","Base, incentive and benefits from 07"),("Marketing Spend","04 CAM- actuals"),("Travel & Entertainment",""),("Sub-Advisory Fees",""),("Distribution Technology","")]),
 "Source Domain": ("Programme business domains", [("04 Marketing & Digital",""),("05 Distribution Agreements & Partners",""),("07 Compensation & Territory",""),("12 Institutional Client Servicing",""),("14 Third-Party Data & Licensing",""),("ERP / Accounts Payable","Direct supplier invoice")]),
 "Capitalisation Outcome": ("ASC 340-40 / IFRS 15", [("Expense as Incurred",""),("Capitalise - Cost to Obtain","Incremental cost of obtaining a contract"),("Capitalise - Cost to Fulfil",""),("Practical Expedient - Expensed","Amortisation period one year or less"),("Other GAAP Applies","e.g. ASC 946 legacy guidance")]),
 "Accrual Basis": ("Internal", [("Engine Calculation","From 05 / 07 calculation engine"),("Run-Rate Estimate",""),("Budget-Based",""),("Invoice Received","")]),
 "True-Up Reason": ("Internal", [("Invoice Variance",""),("Basis Data Restated",""),("Rate Change",""),("Late Agreement Execution",""),("Cap Applied",""),("Error Correction","")]),
 "Cost Asset Type": ("ASC 340-40 / IFRS 15", [("Incremental Cost to Obtain",""),("Cost to Fulfil",""),("Deferred Sales Commission","Back-end-load / level-load share class commissions"),("Placement Fee","Private fund / mandate placement")]),
 "Amortisation Method": ("ASC 340-40", [("Straight-Line",""),("Pattern of Revenue",""),("Pattern of Redemptions","Aligned to CDSC schedule")]),
 "Customer Contract Linkage": ("AICPA Revenue Recognition Guide / Internal", [("Directly Obtains New Customer Contract","e.g. new mandate IMA"),("Linked to Fund Share Sales Only","Customer is the fund; no new contract obtained"),("Not Incremental","Discretionary, salary or team-based")]),
 "Management P&L Line": ("Internal", [("Management Fee Revenue",""),("Performance Fee Revenue",""),("Distribution & Servicing Revenue",""),("Fee Waivers & Reimbursements",""),("Revenue Sharing & Platform Fees",""),("Sub-TA & Networking Fees",""),("12b-1 & Trail Payments",""),("Sales Compensation",""),("Marketing Spend",""),("Distribution Operations & Data",""),("Amortisation of Contract Costs",""),("Allocated Overhead",""),("Intercompany Distribution Fees","")]),
 "Ledger": ("Internal", [("Primary - US GAAP",""),("Secondary - IFRS",""),("Local Statutory",""),("Management","")]),
 "Journal Type": ("Internal", [("Accrual",""),("Reversal",""),("True-Up",""),("Allocation",""),("Reclassification",""),("Intercompany",""),("Amortisation","")]),
 "Cost Pool Type": ("Internal", [("Sales",""),("Marketing",""),("Client Service",""),("Distribution Operations",""),("Distribution Technology",""),("Product Management",""),("Corporate Overhead","")]),
 "Allocation Method Type": ("Internal / TDABC", [("Direct Assignment",""),("Driver-Based",""),("Activity-Based",""),("Time-Driven Activity-Based","Kaplan & Anderson TDABC"),("Proportional to Revenue",""),("Fixed Percentage",""),("Step-Down",""),("Reciprocal","")]),
 "Allocation Driver Type": ("Internal", [("Average AUM",""),("Gross Sales",""),("Net Flows",""),("Revenue",""),("Headcount",""),("Time / Effort",""),("Activity Count","03 ACT- counts"),("Account Count",""),("Transaction Count","")]),
 "Profitability Dimension": ("Internal", [("Channel",""),("Partner Firm",""),("Product",""),("Share Class",""),("Territory",""),("Salesperson",""),("Client",""),("Client Segment",""),("Legal Entity",""),("Region","")]),
 "Data Version": ("Internal", [("Actual",""),("Budget",""),("Forecast",""),("Scenario","")]),
 "Run Status": ("Internal", [("Draft",""),("Preliminary",""),("Final",""),("Superseded","")]),
 "Profitability Measure": ("Internal", [("Net Revenue Yield",""),("Net Revenue After Distribution Costs",""),("Contribution Margin",""),("Operating Margin",""),("Cost-to-Serve Rate",""),("Cost-Income Ratio","")]),
 "Hierarchy Type": ("Internal", [("Channel",""),("Product",""),("Region",""),("Legal Entity",""),("Cost Centre",""),("Client Segment","")]),
 "Hierarchy Status": ("Internal", [("Draft",""),("Active",""),("Retired","")]),
 "Restatement Trigger": ("Internal", [("Channel Reorganisation",""),("Territory Realignment","07 RLN-"),("Allocation Rule Change",""),("Account Mapping Change",""),("Product Reclassification",""),("Error Correction","")]),
 "Restatement Method": ("Internal", [("Full Restatement",""),("Prospective Only",""),("Pro Forma Side-by-Side","")]),
 "Plan Type": ("Internal", [("Annual Budget",""),("Rolling Forecast",""),("Long-Range Plan",""),("Scenario","")]),
 "Scenario": ("Internal", [("Base",""),("Upside",""),("Downside",""),("Market Stress","")]),
 "Plan Version Status": ("Internal", [("Draft",""),("Submitted",""),("Approved",""),("Locked","")]),
 "Variance Driver": ("Internal", [("Volume (Flows)",""),("Market",""),("Rate / Mix",""),("FX",""),("Timing",""),("Cost","")]),
 "Intercompany Service Type": ("OECD TPG / Internal", [("Distribution Services",""),("Delegated Portfolio Management",""),("Fee Sharing",""),("Shared Services",""),("Marketing Support","")]),
 "TP Method": ("OECD Transfer Pricing Guidelines (Ch. II)", [("Comparable Uncontrolled Price",""),("Resale Price Method",""),("Cost Plus Method",""),("Transactional Net Margin Method",""),("Transactional Profit Split","")]),
 "TP Remuneration Basis": ("Internal", [("Cost Plus Mark-Up",""),("Share of Management Fee",""),("Share of Distribution Fee",""),("Revenue Split","")]),
 "VAT Treatment": ("Internal", [("Standard Rated",""),("Exempt - Fund Management",""),("Out of Scope",""),("Reverse Charge","")]),
 "Settlement Status": ("Internal", [("Pending",""),("Invoiced",""),("Settled",""),("Netted","")]),
 "Period Close Status": ("Internal", [("Open",""),("Soft Close",""),("Hard Close",""),("Reopened","")]),
 "Reconciliation Type": ("Internal", [("Booked vs Estimated Revenue (06)",""),("Partner Payments Accrued vs Calculated (05)",""),("Comp Accrual vs ICM (07)",""),("Profitability vs GL","")]),
 "Reconciliation Status": ("Internal", [("Reconciled",""),("Reconciled within Tolerance",""),("Break Open",""),("Break Explained","")]),
 "Data Classification": ("Internal", [("Public",""),("Internal",""),("Confidential - Financial",""),("Restricted - MNPI","Pre-earnings results")]),
 "Data Quality Status": ("Internal", [("Validated",""),("Pending Validation",""),("Exception",""),("Estimated","")]),
}

# ---------------------------------------------------------------------------
# Relationships, sources
# ---------------------------------------------------------------------------
REL = [
 ("Revenue Contract","contains","Performance Obligation","1 : 1..n",""),
 ("Revenue Contract","is based on","Mandate (01 Product: MND-) / Agreement (05: AGR-)","n : 1","Fund advisory agreements are not in 05; held on the revenue contract."),
 ("Revenue Contract","has customer","Party (02 Client & Customer: PTY-)","n : 1","Customer determination per AICPA guide."),
 ("Revenue Contract","is recorded by","Legal Entity (09 Shared: LEN-)","n : 1",""),
 ("Fee Revenue Record","is earned on","Share Class / Mandate (01 Product: SHC-/MND-)","n : 1","Fee rate terms from 01."),
 ("Fee Revenue Record","reconciles to","Estimated Management Fee Revenue (06 TX: MSR-)","n : 1","Books vs estimate reconciliation."),
 ("Fee Revenue Record","is reduced by","Waiver Record","1 : 0..n",""),
 ("Waiver Record","applies terms of","Expense Cap terms (01 Product: SHC-)","n : 1","01 owns terms; 10 owns financial impact."),
 ("Distribution Revenue Record","passes through via","Payment Calculation (05 DA: PCL-)","1 : 0..n",""),
 ("Distribution Cost Item","is sourced from","Payment Calculation / Partner Payment (05 DA: PCL-/PMT-)","n : 1","Partner payments."),
 ("Distribution Cost Item","is sourced from","Compensation Statement / Accrual (07 CT: STM-)","n : 1","Sales comp expense."),
 ("Distribution Cost Item","is sourced from","Campaign spend (04 MK: CAM-)","n : 1","Marketing actuals."),
 ("Distribution Cost Item","is charged to","Org Unit / Cost Centre (09 Shared: OU-)","n : 1",""),
 ("Distribution Cost Item","is accrued by","Accrual","1 : 0..n",""),
 ("Distribution Cost Item","may be capitalised into","Contract Cost Asset","n : 0..1",""),
 ("Capitalisation Assessment","assesses","Incentive Comp Plan component (07 CT: ICP-)","n : 1",""),
 ("GL Posting","uses","Account Mapping","n : 1",""),
 ("Cost Pool","is allocated by","Allocation Rule","1 : 1..n",""),
 ("Allocation Rule","applies","Allocation Method / Allocation Driver","n : 1",""),
 ("Allocation Driver","is measured by","Flow & AUM Measure (06 TX: MSR-) / Activity (03 Sales: ACT-)","n : 1",""),
 ("Allocation Run","produces","Allocation Result","1 : 0..n",""),
 ("Profitability Record","is dimensioned by","Party, Share Class, Territory, Employee (02 PTY-, 01 SHC-, 07 TER-, 03 EMP-)","n : 0..1 each","Declared dimension grain."),
 ("Profitability Record","rolls up through","Management Hierarchy","n : 1",""),
 ("Management Hierarchy","is restated by","Hierarchy Restatement","1 : 0..n",""),
 ("Plan Version","contains","Plan Line","1 : 1..n",""),
 ("Flow & Revenue Forecast","uses","Sales Forecast (03 Sales: FCS-)","n : 0..1",""),
 ("Intercompany Agreement","is priced by","TP Policy","1 : 1..n","Effective-dated."),
 ("Intercompany Agreement","generates","Intercompany Charge","1 : 0..n",""),
]

SRC = [
 ("FASB ASC 606 Revenue from Contracts with Customers","FASB","https://asc.fasb.org (Topic 606)","Free basic view (registration)","Five-step model, variable consideration and constraint, principal vs agent, series guidance","Revenue Contract, Performance Obligation, Fee and Performance Fee Revenue, Waivers"),
 ("FASB ASC 340-40 Other Assets and Deferred Costs - Contracts with Customers","FASB","https://asc.fasb.org (Subtopic 340-40)","Free basic view (registration)","Incremental costs to obtain, costs to fulfil, amortisation, impairment, one-year practical expedient","Contract Cost Asset, Capitalisation Assessment"),
 ("IFRS 15 Revenue from Contracts with Customers","IFRS Foundation","https://www.ifrs.org/issued-standards/list-of-standards/ifrs-15-revenue-from-contracts-with-customers.html","Free (registration)","IFRS equivalent of ASC 606 including contract costs (paras 91-98)","Revenue and contract cost attributes for IFRS reporters"),
 ("AICPA Audit and Accounting Guide: Revenue Recognition (Ch. 4 Asset Management)","AICPA","https://www.aicpa-cima.com/","Licensed","Industry application: management fees, performance fees, customer determination, 12b-1 fees, CDSC, deferred distribution commissions","Customer Determination, Trailing Fee Constraint, CDSC, Commission linkage"),
 ("KPMG / RSM asset management revenue guidance","KPMG; RSM US","https://rsmus.com/content/dam/rsm/insights/financial-reporting/1pdf/Revenue-recognition-considerations-for-asset-managers-202311.pdf","Free","Practitioner summaries of ASC 606 / 340-40 for asset managers","Secondary support for revenue and contract cost attributes"),
 ("SEC Rule 12b-1 (17 CFR 270.12b-1)","US SEC","https://www.law.cornell.edu/cfr/text/17/270.12b-1","Regulation","Fund-paid distribution plans","Distribution Revenue Type, Funding Source"),
 ("SEC Form N-1A (fee table, waivers and recoupment)","US SEC","https://www.sec.gov/files/formn-1a.pdf","Regulation","Gross / net expense ratios, contractual waivers and recoupment disclosure","Waiver Record"),
 ("SEC IM Guidance Update 2016-01 (mutual fund distribution and sub-accounting fees)","US SEC","https://www.sec.gov/investment/im-guidance-2016-01.pdf","Guidance","Fund-paid vs adviser-paid sub-accounting fees","Adviser-Borne Cost, Funding Source"),
 ("FASB ASC 280 Segment Reporting / IFRS 8 Operating Segments","FASB; IFRS Foundation","https://www.ifrs.org/issued-standards/list-of-standards/ifrs-8-operating-segments/","Free (registration)","Management approach to segments (CODM)","Operating Segment Mapping, Restatement"),
 ("US GAAP Financial Reporting Taxonomy (XBRL)","FASB / XBRL US","https://xbrl.us/taxonomies","Free","Standard tags for revenue and expense lines in SEC filings","Account Mapping, Revenue Stream"),
 ("OECD Transfer Pricing Guidelines for Multinational Enterprises and Tax Administrations (2022)","OECD","https://doi.org/10.1787/0e655865-en","Free to read","Arm's length principle, TP methods, documentation","Intercompany & Transfer Pricing"),
 ("Time-Driven Activity-Based Costing (Kaplan & Anderson, HBR Nov 2004)","Harvard Business Review","https://hbswk.hbs.edu/item/adding-time-to-activity-based-costing","Article (licensed)","Capacity cost rate and time equations","Allocation Method, Allocation Driver, Cost-to-Serve"),
 ("McKinsey Performance Lens Global Asset Management Survey","McKinsey & Company","https://www.mckinsey.com/featured-insights/charts/assets-up-but-profits-stuck","Free summaries; survey for participants","Industry revenue yield, cost and operating margin benchmarks","Profitability measures"),
 ("ICI Trends in the Expenses and Fees of Funds, 2025","Investment Company Institute","https://www.ici.org/system/files/2026-03/per32-01.pdf","Free","Expense ratios, 12b-1 and load trends","Context for fee yield and distribution revenue"),
 ("SOX s.404 / COSO 2013 Internal Control","SEC; COSO","https://www.coso.org","Free framework summary","Controls over financial reporting","Journals, runs, reconciliations"),
 ("DCAM","EDM Council","https://edmcouncil.org","Member framework","Data management capability: ownership and stewardship","Data Management Metadata"),
]

_SRC_KEYS = {
 "FASB ASC 606": ["ASC 606"], "FASB ASC 340-40": ["ASC 340-40"], "IFRS 15": ["IFRS 15"],
 "AICPA": ["AICPA*"], "SEC Rule 12b-1": ["SEC Rule 12b-1"], "SEC Form N-1A": ["SEC Form N-1A"],
 "SEC IM": ["SEC IM*"], "FASB ASC 280": ["ASC 280", "IFRS 8"], "US GAAP Financial": ["US GAAP Taxonomy"],
 "OECD": ["OECD*"], "Time-Driven": ["TDABC"], "McKinsey": ["McKinsey*"], "ICI": ["ICI"], "SOX": ["SOX"], "DCAM": ["DCAM*"],
}
SRC = [tuple(s) + (next((v for k, v in _SRC_KEYS.items() if s[0].startswith(k)), []),) for s in SRC]
