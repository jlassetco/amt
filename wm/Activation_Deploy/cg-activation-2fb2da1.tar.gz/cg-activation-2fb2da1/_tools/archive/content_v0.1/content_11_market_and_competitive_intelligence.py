"""Business domain 11 - Market & Competitive Intelligence. Content module for taxonomy_builder.py."""

META = {
 "title": "Market & Competitive Intelligence Data Taxonomy",
 "subtitle": "Business domain 11 - Market & Competitive Intelligence | Asset manager (wholesale distributor) | Scope: US + EU/UK | Draft v0.1 | 2026-10-01",
 "output": "11_Market_and_Competitive_Intelligence/Market_and_Competitive_Intelligence_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the market and competitive intelligence data of an asset manager that distributes wholesale in the US and EU/UK. It answers 'where are industry flows going, what is our share by category, channel, vehicle, region and distributor, how do competitors and peer funds compare on performance, fees and ratings, how big is each advisor, firm and institutional opportunity, and what is changing in the market'. It is stitched together from industry statistics (ICI, EFAMA, Investment Association), vendor methodologies (Morningstar flows, Star, Medalist and Sustainability ratings; LSEG Lipper Leaders; FE fundinfo Crown ratings; Citywire manager ratings; ISS Market Intelligence Simfund; Broadridge; Cerulli; Nasdaq eVestment) and public filings (DOL Form 5500, SEC Form ADV, SEC EDGAR). Use it as a starting point for a market-intelligence data mart, a data catalogue or a business glossary."),
  ("Scope", "In scope: industry flow and AUM dataset profiles, releases, revisions and observations (taking over the light 06 TX-MKT subdomain at consolidation); external category-to-share-class mapping for market share; market share definitions, records (MSH-) and league-table rankings; competitor firm profiles (CPF-), competitor metrics, distribution footprint, strategic events and key personnel moves; peer universes (PEER-), peer funds (non-firm funds) and peer metric snapshots; third-party ratings, rankings and awards for own and peer funds and managers (Morningstar Star, Medalist and Sustainability ratings, Lipper Leaders, FE fundinfo Crowns, Citywire, industry awards); fee benchmarking and pricing inputs; market sizing and opportunity potential (MSZ-) for advisors, firms, channels, regions, institutional and DC/DCIO markets; intermediary market structure research and trends; aggregated win/loss and external mandate search intelligence; news, research and regulatory horizon scanning; data management metadata. Out of scope (referenced by ID only): own strategies, products, share classes, fees, Morningstar Category assignment of own share classes and benchmarks (01_Product, STR-/PRD-/SHC-/BMK-); the party master for competitors, distributors, advisors, consultants and plans, and practice AUM as a party attribute (02_Client_and_Customer, PTY-/ACC-); opportunities, competitor-on-opportunity and win/loss reasons of our own deals, consultant ratings received (03_Sales, OPP-/RFP-/EMP-); marketing use of ratings in content (04_Marketing_and_Digital, AST-); partner/home-office research ratings and shelf status (05_Distribution_Agreements_and_Partners, AGR-/SHF-); own flows, AUM, attribution and technical data feeds (06_Sales_Transactions_and_AUM_Attribution, FEED-/LOAD-); territory potential values used in territory design and goals (07_Compensation_and_Territory, TER-/GOL-); compliance approval of rating and award citations (08_Distribution_Compliance, REV-); geography, calendars and industry classification schemes (09_Shared_and_Enterprise_Reference_Data, GEO-/CAL-); data licences, entitlements and the dataset catalogue (14_Third_Party_Data_and_Licensing, DSET-/DLA-/ENT-)."),
  ("Structure", "Four levels: Domain > Subdomain > Concept > Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Licensed Dataset (DSET-, 14) -> Industry Dataset Profile (methodology, granularity, estimation basis) -> Industry Data Release (IDR-, as-of date, revision) -> Industry Flow & AUM Observation at a grain (category x channel x vehicle x region x distributor x fund) -> mapped to own Share Classes (SHC-, 01) via Category Mapping -> Market Share Record (MSH-) under a Market Share Definition. In parallel: Competitor Profile (CPF-, on a PTY- party) -> Competitor Metrics, Footprint, Strategic Events (CEV-) and Personnel Moves; Peer Universe (PEER-) -> members = own share classes (SHC-) and Peer Funds (PFD-) -> Peer Metric Snapshots -> Fee Benchmark Studies (FBS-) and Rating Observations (RTG-) / Awards (AWD-). Market Sizing Records (MSZ-) size advisor, firm, channel, region, institutional and DC markets and feed 07 territory potential. Mandate Search Events (MSE-), Market Research Reports (MRR-), Market Trends (TRD-) and Intelligence Items (MIN-) carry qualitative intelligence linked to competitors, products and topics."),
  ("Design principles", "1) Separate the dataset (licence and catalogue in 14) from its analytical profile (methodology here) and from each release (as-of date and revision), so restated vendor history is never silently overwritten. 2) Every flow, share and sizing value states its basis (reported, estimated, modelled), grain and as-of date. 3) Define market share once: numerator, denominator, measure basis and scope must be at the same grain; numerators come from 06 (own) or from the same industry dataset, never mixed without a flag. 4) One rating model for own and peer funds: the same Rating Observation structure holds Morningstar, Lipper, FE fundinfo and Citywire ratings regardless of whose fund it is. 5) Reference parties, products, opportunities, territories, feeds and licences by ID; do not copy their attributes. 6) Respect vendor licences: store vendor values with source and licence references (14) and keep redistribution flags. 7) Flag personal data (PII) on individuals (competitor personnel, rated fund managers). 8) Flag Critical Data Elements (CDE)."),
  ("Applies To", "Shows the record type each attribute is held on: Dataset Profile, Data Release, Flow Observation, Category Mapping, Share Definition, Share Record, Ranking, Competitor Profile, Competitor Metric, Footprint, Competitor Event, Personnel Move, Peer Universe, Universe Member, Peer Fund, Peer Snapshot, Rating Scheme, Rating Observation, Manager Rating, Award, Fee Study, Fee Result, Pricing Input, Sizing Record, Opportunity Potential, Plan Market, Research Report, Market Trend, Search Event, Win/Loss Analysis, Intelligence Item, Regulatory Item or All."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify a record, compute or explain market share, sizing or peer position, or to cite a rating or award correctly. Confirm with data owners."),
  ("Primary / Secondary Reference", "Standard or source the attribute definition is aligned to. Vendor references (Morningstar, LSEG Lipper, FE fundinfo, Citywire, ISS Market Intelligence, Broadridge, Cerulli, Nasdaq eVestment, Discovery Data) indicate where the data is usually sourced and how the vendor defines it; they are not a licence to reproduce vendor data. 'Internal' = firm-defined; there is no authoritative external definition."),
  ("Tabs", "Hierarchy: domains, subdomains and concepts with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: concept-level cardinalities, including cross-domain references | Sources: standards, vendor methodologies and public datasets with links."),
  ("Suggested next steps", "1) Validate with Distribution Strategy / Market Intelligence, Product Strategy and Pricing, Institutional Consultant Relations, Sales Operations and Compliance (rating citations). 2) Agree with 14 the split between the dataset catalogue / licence (DSET-) and the 11 dataset profile; inventory current subscriptions (Morningstar Direct, Simfund, Broadridge, Cerulli, eVestment, Discovery Data, FE fundinfo). 3) Execute the 06 TX-MKT hand-over listed in Source_Notes.md. 4) Ratify Medalist and third-party rating ownership in 11 with 01, 03 and 05. 5) Agree the MSZ- to 07 territory potential interface and the market-share definitions with Finance and Distribution Analytics. 6) Ask 02 to add a 'Competitor / Peer Asset Manager' party role. 7) Map attributes to source systems and extend code lists to firm values. 8) Turn the Relationships tab into a logical data model."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Industry Flow & AUM Data", "MI-FLW",
  "Analytical profiles, releases and observations of external industry flow and asset datasets (ICI, EFAMA, Investment Association, Morningstar, ISS Market Intelligence Simfund, Broadridge, Cerulli) used for market sizing, share and trend analysis. Takes over 06 TX-MKT at consolidation.",
  [
   ("Industry Dataset Profile", "Methodology and coverage profile of each industry dataset, keyed to the licensed dataset catalogued in 14.", [
     ("Industry Dataset Profile", [
       ("Licensed Dataset", "Dataset in the 14 Third-Party Data catalogue that this profile describes; carries publisher, licence and entitlements.", "Dataset Profile", "Reference (Dataset)", "", "DSET-0042", "Internal", "", "Y", "Replaces 06 'Industry Dataset ID' (IND-)."),
       ("Dataset Family", "Type of industry statistic the dataset provides.", "Dataset Profile", "Code", "Industry Dataset Family", "Industry Flow Statistics", "Internal", "", ""),
       ("Industry Data Provider", "Organisation compiling the data (trade association, vendor).", "Dataset Profile", "Code", "Industry Data Provider", "ICI", "Internal", "", "", "Provider party held in 02 via 14 vendor record."),
       ("Flow Estimation Method", "Whether flows are reported by funds, estimated from assets and returns, or modelled.", "Dataset Profile", "Code", "Flow Estimation Method", "Estimated from TNA and Return", "Morningstar", "ICI", "Y", "Replaces 06 'Flow Methodology'."),
       ("Reinvested Distribution Treatment", "Whether reinvested dividends and capital gains are counted in flows.", "Dataset Profile", "Code", "Reinvestment Treatment", "Excluded from Flows", "ICI", "Morningstar", ""),
       ("Category Scheme", "Classification used to group funds in the dataset.", "Dataset Profile", "Code", "Category Scheme", "Morningstar Category", "ICI", "EFAMA", "", "Moves from 06."),
       ("Lowest Grain Available", "Finest level at which the dataset reports values.", "Dataset Profile", "Code (multi)", "Data Grain", "Share Class; Distributor Firm", "ISS Market Intelligence", "Broadridge", ""),
       ("Vehicles Covered", "Vehicle types included in the dataset.", "Dataset Profile", "Code (multi)", "Industry Vehicle Type", "Mutual Fund; ETF; CIT", "ISS Market Intelligence", "ICI", ""),
       ("Coverage Basis", "Whether the dataset is organised by fund domicile, by country of sale or by distributor.", "Dataset Profile", "Code", "Coverage Basis", "Fund Domicile", "EFAMA", "Broadridge", ""),
       ("Publication Frequency", "How often the provider publishes the dataset.", "Dataset Profile", "Code", "Frequency", "Weekly", "ICI", "", ""),
       ("Revision Policy", "How the provider restates prior periods (rolling revisions, annual rebase, none).", "Dataset Profile", "Code", "Revision Policy", "Rolling Prior-Period Revisions", "ICI", "", ""),
     ]),
   ]),
   ("Industry Data Release", "Each published vintage of a dataset, so that revisions can be compared and analyses reproduced.", [
     ("Industry Data Release", [
       ("Data Release ID", "Unique identifier of the dataset release / vintage.", "Data Release", "Identifier", "", "IDR-ICI-WK-20260923", "Internal", "", "Y"),
       ("As-of Date", "Period-end date the values relate to.", "Data Release", "Date", "ISO 8601", "2026-09-23", "ICI", "EFAMA", "Y"),
       ("Publication Date", "Date the provider published the release.", "Data Release", "Date", "ISO 8601", "2026-10-01", "Internal", "", ""),
       ("Release Status", "Whether the release is preliminary, final or revised.", "Data Release", "Code", "Release Status", "Preliminary", "ICI", "", ""),
       ("Supersedes Release", "Earlier release this vintage revises.", "Data Release", "Reference (Data Release)", "", "IDR-ICI-WK-20260916", "Internal", "", ""),
       ("Source Load", "Load (owned by 06) that brought the release into the data platform.", "Data Release", "Reference (Load)", "", "LOAD-20261001-FEED041-01", "Internal", "", ""),
     ]),
   ]),
   ("Industry Flow & AUM Observation", "A flow or asset value at a stated grain from a given release.", [
     ("Industry Flow Observation", [
       ("Data Release", "Release the observation belongs to.", "Flow Observation", "Reference (Data Release)", "", "IDR-SIMF-M-202608", "Internal", "", ""),
       ("Industry Category", "Category value in the dataset's scheme.", "Flow Observation", "Code", "External (Vendor)", "Morningstar US Large Growth", "Morningstar", "ICI", "Y", "Moves from 06."),
       ("Distribution Channel", "Distribution channel of the observation, where the dataset splits by channel.", "Flow Observation", "Code", "Industry Channel", "Independent RIA", "Cerulli", "Broadridge", ""),
       ("Vehicle Type", "Vehicle type of the observation.", "Flow Observation", "Code", "Industry Vehicle Type", "ETF", "ISS Market Intelligence", "ICI", ""),
       ("Region / Market", "Market of the observation (domicile or sales country per Coverage Basis).", "Flow Observation", "Code", "ISO 3166-1 alpha-2", "LU", "EFAMA", "", ""),
       ("Distributor Firm", "Distributor firm, where the dataset reports at firm level.", "Flow Observation", "Reference (Party)", "", "PTY-100245", "Broadridge", "", ""),
       ("Fund Manager Firm", "Asset manager whose funds the observation covers (own firm or competitor).", "Flow Observation", "Reference (Competitor Profile)", "", "CPF-0112", "ISS Market Intelligence", "", ""),
       ("Fund / Share Class", "Peer fund or own share class, where the observation is at fund level.", "Flow Observation", "Reference (Peer Fund / Share Class)", "", "PFD-0045871", "Morningstar", "", ""),
       ("Gross Sales", "Industry gross sales at the grain, where reported.", "Flow Observation", "Amount", "", "USD 18.2bn", "ICI", "ISS Market Intelligence", ""),
       ("Redemptions", "Industry redemptions at the grain, where reported.", "Flow Observation", "Amount", "", "USD 22.3bn", "ICI", "ISS Market Intelligence", ""),
       ("Net Flow", "Net new cash flow / net sales / estimated net flow at the grain.", "Flow Observation", "Amount", "", "USD -4.1bn", "ICI", "EFAMA", "Y", "Moves from 06 'Industry Net Flow'."),
       ("Ending Assets", "Total net assets at period end.", "Flow Observation", "Amount", "", "USD 1.92tn", "EFAMA", "ICI", "Y", "Moves from 06 'Industry Assets'."),
       ("Observation Currency", "Currency of the amounts.", "Flow Observation", "Code", "ISO 4217", "USD", "Internal", "", ""),
       ("Value Basis", "Whether the value is reported, estimated or modelled.", "Flow Observation", "Code", "Value Basis", "Estimated", "Morningstar", "", "Y"),
     ]),
   ]),
   ("Category Mapping", "Mapping of external category values to own share classes and to the firm's internal market segments, used to build market share numerators.", [
     ("Category Mapping", [
       ("Category Scheme", "External scheme being mapped.", "Category Mapping", "Code", "Category Scheme", "Lipper Global Classification", "Internal", "", ""),
       ("External Category Value", "Category value in the external scheme.", "Category Mapping", "Code", "External (Vendor)", "Equity Global", "LSEG Lipper", "", "Y"),
       ("Mapped Share Class", "Own share class mapped into the category; own-fund category assignment itself is held in 01.", "Category Mapping", "Reference (Share Class)", "", "SHC-004512", "Internal", "", "Y", "Moves from 06 'Firm Products Mapped'."),
       ("Internal Market Segment", "Firm market segment the category rolls up to for share reporting.", "Category Mapping", "Code", "Firm-defined", "Global Equity - Growth", "Internal", "", ""),
       ("Mapping Effective From", "Date the mapping becomes valid.", "Category Mapping", "Date", "ISO 8601", "2026-01-31", "Internal", "", ""),
       ("Mapping Effective To", "Date the mapping ends, if applicable.", "Category Mapping", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Market Share", "MI-MSH",
  "Certified definitions and stored results of the firm's market share by category, channel, distributor firm, region and vehicle, and industry league-table rankings.",
  [
   ("Market Share Definition", "How each market share measure is calculated, so all reports compute share the same way.", [
     ("Market Share Definition", [
       ("Share Definition Code", "Unique code of the market share definition.", "Share Definition", "Identifier", "", "MSHD-NF-MSCAT-US", "Internal", "", "Y"),
       ("Share Definition Name", "Business name of the measure.", "Share Definition", "Text", "", "US Net Flow Share by Morningstar Category", "Internal", "", ""),
       ("Share Measure Basis", "What is being shared: assets, gross sales or net flows.", "Share Definition", "Code", "Share Measure Basis", "Net Flows", "Broadridge", "ISS Market Intelligence", "Y"),
       ("Share Dimension", "Dimension by which share is cut.", "Share Definition", "Code (multi)", "Share Dimension", "Category; Channel", "Internal", "", ""),
       ("Numerator Source", "Source of the firm's own value: 06 attributed flows/AUM or the same industry dataset.", "Share Definition", "Code", "Numerator Source", "Same Industry Dataset", "Internal", "", "Y", "Same-source numerators avoid basis mismatch."),
       ("Denominator Dataset", "Industry dataset profile supplying the denominator.", "Share Definition", "Reference (Dataset)", "", "DSET-0042", "Internal", "", "Y"),
       ("Calculation Formula", "Formula for share, including treatment of negative denominators for flow share.", "Share Definition", "Text", "", "Firm net flow / sum of positive category net flows (flow share of inflows)", "Internal", "", ""),
       ("Negative Flow Treatment", "How share is expressed when industry or firm flows are negative.", "Share Definition", "Code", "Negative Flow Treatment", "Report Not Meaningful", "Internal", "", ""),
     ]),
   ]),
   ("Market Share Record", "Stored share results at a grain and period.", [
     ("Market Share Record", [
       ("Market Share Record ID", "Unique identifier of the share result.", "Share Record", "Identifier", "", "MSH-2026-08-000981", "Internal", "", "Y"),
       ("Share Definition", "Definition the result is computed under.", "Share Record", "Reference (Share Definition)", "", "MSHD-NF-MSCAT-US", "Internal", "", "Y"),
       ("Period End Date", "Period end of the result.", "Share Record", "Date", "ISO 8601", "2026-08-31", "Internal", "", "Y"),
       ("Period Type", "Length of the measurement period.", "Share Record", "Code", "Period Type", "Trailing 12 Months", "Internal", "", ""),
       ("Category / Segment", "Category or internal segment value of the result.", "Share Record", "Text", "External (Vendor)", "Morningstar US Large Growth", "Morningstar", "", ""),
       ("Channel", "Channel of the result, where cut by channel.", "Share Record", "Code", "Industry Channel", "Wirehouse", "Cerulli", "", ""),
       ("Distributor Firm", "Distributor firm, where share is measured within a firm (share of firm's category sales).", "Share Record", "Reference (Party)", "", "PTY-100245", "Broadridge", "", ""),
       ("Region / Market", "Market of the result.", "Share Record", "Code", "ISO 3166-1 alpha-2", "GB", "Internal", "", ""),
       ("Vehicle Type", "Vehicle of the result.", "Share Record", "Code", "Industry Vehicle Type", "Mutual Fund", "Internal", "", ""),
       ("Firm Value", "Firm numerator value.", "Share Record", "Amount", "", "USD 412m", "Internal", "", ""),
       ("Industry Value", "Industry denominator value.", "Share Record", "Amount", "", "USD 17.2bn", "Internal", "", ""),
       ("Market Share", "Firm value as a percentage of industry value.", "Share Record", "Percentage", "", "2.40%", "Broadridge", "ISS Market Intelligence", "Y", "Replaces 06 TX-MEA 'Market Share' measure."),
     ]),
   ]),
   ("Industry Rankings", "League-table positions of the firm and competitors by assets or flows.", [
     ("Industry Ranking", [
       ("Ranking Basis", "Measure the table ranks on.", "Ranking", "Code", "Share Measure Basis", "Net Flows", "ISS Market Intelligence", "", ""),
       ("Ranked Firm", "Competitor profile (or own-firm profile) ranked.", "Ranking", "Reference (Competitor Profile)", "", "CPF-0001", "Internal", "", ""),
       ("Rank Position", "Position in the table.", "Ranking", "Integer", "", "14", "Internal", "", ""),
       ("Ranking Universe", "Scope of the table (market, channel, vehicle, category).", "Ranking", "Text", "", "US active mutual funds and ETFs, YTD", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Competitor Intelligence", "MI-CMP",
  "Profiles of competing asset managers, their size, growth, product range, distribution footprint, strategic moves and key personnel changes. The legal party is held in 02; this domain holds the competitive view of it.",
  [
   ("Competitor Profile", "The firm's analytical record of a competing asset manager.", [
     ("Competitor Profile", [
       ("Competitor Profile ID", "Unique identifier of the competitor profile.", "Competitor Profile", "Identifier", "", "CPF-0112", "Internal", "", "Y"),
       ("Competitor Party", "Party (02) of the competitor's ultimate parent or group.", "Competitor Profile", "Reference (Party)", "", "PTY-0400877", "Internal", "", "Y"),
       ("Competitor Display Name", "Short name used in analysis.", "Competitor Profile", "Text", "", "Example Global Investors", "Internal", "", ""),
       ("Competitor Tier", "Strategic importance of the competitor to the firm.", "Competitor Profile", "Code", "Competitor Tier", "Primary", "Internal", "", "Y"),
       ("Competitor Type", "Business model of the competitor.", "Competitor Profile", "Code", "Competitor Type", "Active Multi-Asset Manager", "Internal", "Cerulli", ""),
       ("Headquarters Country", "Country of the competitor's headquarters.", "Competitor Profile", "Code", "ISO 3166-1 alpha-2", "US", "Internal", "", ""),
       ("Vendor Manager Identifiers", "Identifiers of the competitor in vendor datasets (Morningstar BrandingId, Simfund manager code, eVestment firm ID).", "Competitor Profile", "Text", "External (Vendor)", "Morningstar BN00000XXX", "Morningstar", "ISS Market Intelligence", "", "Crosswalk; vendor IDs governed by 14 licence."),
       ("Competing Strategies", "Own strategies against which the competitor is most often benchmarked.", "Competitor Profile", "Reference (Strategy) (multi)", "", "STR-00123; STR-00456", "Internal", "", ""),
     ]),
   ]),
   ("Competitor Metrics", "Periodic size, growth and product-range metrics of the competitor.", [
     ("Competitor Metric Snapshot", [
       ("As-of Date", "Date the metrics relate to.", "Competitor Metric", "Date", "ISO 8601", "2026-06-30", "Internal", "", "Y"),
       ("Total AUM", "Competitor's total assets under management.", "Competitor Metric", "Amount", "", "USD 640bn", "SEC Form ADV", "ISS Market Intelligence", "Y", "Form ADV Item 5.F regulatory AUM for US RIAs."),
       ("Trailing 12-Month Net Flows", "Estimated net flows over the last 12 months.", "Competitor Metric", "Amount", "", "USD 4.2bn", "Morningstar", "ISS Market Intelligence", "Y"),
       ("Asset-Weighted Expense Ratio", "Asset-weighted average expense ratio of the competitor's funds.", "Competitor Metric", "Percentage", "", "0.48%", "Morningstar", "", ""),
     ]),
   ]),
   ("Distribution Footprint", "Where and how the competitor distributes.", [
     ("Competitor Distribution Footprint", [
       ("Channel", "Channel in which the competitor is active.", "Footprint", "Code", "Industry Channel", "Wirehouse", "Cerulli", "", ""),
       ("Market", "Country where the competitor distributes.", "Footprint", "Code", "ISO 3166-1 alpha-2", "DE", "Internal", "", ""),
       ("Presence Strength", "Assessed strength of presence in the channel / market.", "Footprint", "Code", "Presence Strength", "Strong", "Internal", "", ""),
       ("Estimated Wholesaler Headcount", "Estimated number of external wholesalers / sales staff.", "Footprint", "Integer", "", "140", "Cerulli", "", ""),
       ("Key Distribution Partners", "Distributor firms where the competitor has known placements or partnerships.", "Footprint", "Reference (Party) (multi)", "", "PTY-100245; PTY-100311", "Internal", "", ""),
     ]),
   ]),
   ("Competitor Strategic Events", "Material moves by competitors: launches, closures, fee cuts, M&A, partnerships, new markets.", [
     ("Competitor Event", [
       ("Competitor Event ID", "Unique identifier of the event.", "Competitor Event", "Identifier", "", "CEV-2026-00412", "Internal", "", "Y"),
       ("Competitor", "Competitor the event relates to.", "Competitor Event", "Reference (Competitor Profile)", "", "CPF-0112", "Internal", "", "Y"),
       ("Event Type", "Kind of strategic move.", "Competitor Event", "Code", "Competitor Event Type", "Fee Reduction", "Internal", "", "Y"),
       ("Event Date", "Date the event was announced or became effective.", "Competitor Event", "Date", "ISO 8601", "2026-09-02", "Internal", "", ""),
       ("Affected Peer Funds", "Competitor funds affected by the event.", "Competitor Event", "Reference (Peer Fund) (multi)", "", "PFD-0045871", "Internal", "", ""),
       ("Assessed Impact", "Firm's assessment of impact on its own business.", "Competitor Event", "Code", "Impact Level", "Medium", "Internal", "", ""),
     ]),
   ]),
   ("Key Personnel Moves", "Hires and departures of portfolio managers and senior distribution staff at competitors.", [
     ("Competitor Personnel Move", [
       ("Individual", "Party (02) of the person who moved.", "Personnel Move", "Reference (Party)", "", "PTY-0901234", "Internal", "", "", "PII"),
       ("Role", "Role of the individual.", "Personnel Move", "Code", "Personnel Role", "Portfolio Manager", "Internal", "", ""),
       ("Move Type", "Nature of the move.", "Personnel Move", "Code", "Personnel Move Type", "Departure", "Internal", "", ""),
       ("From Competitor", "Firm the individual left.", "Personnel Move", "Reference (Competitor Profile)", "", "CPF-0112", "Internal", "", ""),
       ("To Competitor", "Firm the individual joined, if known.", "Personnel Move", "Reference (Competitor Profile)", "", "CPF-0230", "Internal", "", ""),
       ("Move Date", "Date of the announcement.", "Personnel Move", "Date", "ISO 8601", "2026-07-21", "Internal", "", ""),
       ("Affected Strategies / Funds", "Funds the individual managed.", "Personnel Move", "Reference (Peer Fund) (multi)", "", "PFD-0045871", "Citywire", "Morningstar", "", "Manager moves drive Citywire and Medalist People pillar changes."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Peer Universes & Peer Funds", "MI-PEER",
  "Peer group definitions (vendor categories and custom peer sets), the non-firm funds in them, and periodic snapshots of peer performance, rank, fees, assets and flows.",
  [
   ("Peer Universe", "Definition of a set of funds against which own products are compared.", [
     ("Peer Universe", [
       ("Peer Universe ID", "Unique identifier of the peer universe.", "Peer Universe", "Identifier", "", "PEER-0031", "Internal", "", "Y"),
       ("Peer Universe Name", "Name of the universe.", "Peer Universe", "Text", "", "EAA Fund Global Large-Cap Growth Equity - Clean Classes", "Internal", "", ""),
       ("Universe Type", "Whether the universe is a vendor category, a consultant universe or a custom set.", "Peer Universe", "Code", "Peer Universe Type", "Vendor Category", "Morningstar", "LSEG Lipper", "Y"),
       ("Base Category Scheme", "Vendor scheme the universe is based on, if any.", "Peer Universe", "Code", "Category Scheme", "Morningstar Category", "Morningstar", "", ""),
       ("Base Category Value", "Vendor category value.", "Peer Universe", "Code", "External (Vendor)", "Global Large-Cap Growth Equity", "Morningstar", "", ""),
       ("Inclusion Rules", "Rules applied on top of the base category (share class type, domicile, minimum AUM, active only, oldest share class).", "Peer Universe", "Text", "", "Active only; oldest clean class per fund; AUM > EUR 50m; LU/IE domiciled", "Internal", "", ""),
       ("Representative Share Class Rule", "How one share class per fund is chosen for comparison.", "Peer Universe", "Code", "Representative Class Rule", "Oldest Share Class", "Morningstar", "", ""),
       ("Own Strategy Compared", "Own strategy the universe is primarily used for.", "Peer Universe", "Reference (Strategy)", "", "STR-00123", "Internal", "", ""),
       ("Universe Effective From", "Date the definition becomes valid.", "Peer Universe", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Universe Effective To", "Date the definition ends.", "Peer Universe", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Peer Universe Member", [
       ("Member Fund", "Peer fund or own share class in the universe.", "Universe Member", "Reference (Peer Fund / Share Class)", "", "PFD-0045871", "Internal", "", "Y"),
       ("Manual Override Indicator", "Whether membership was forced in or out by an analyst.", "Universe Member", "Boolean", "", "N", "Internal", "", ""),
     ]),
   ]),
   ("Peer Fund", "Non-firm funds and share classes tracked for comparison. Own funds stay in 01.", [
     ("Peer Fund", [
       ("Peer Fund ID", "Unique internal identifier of the peer fund / share class.", "Peer Fund", "Identifier", "", "PFD-0045871", "Internal", "", "Y"),
       ("Peer Fund Name", "Name of the fund and share class.", "Peer Fund", "Text", "", "Example Global Growth Fund I Acc USD", "Morningstar", "", ""),
       ("ISIN", "ISIN of the share class.", "Peer Fund", "Identifier", "ISO 6166", "LU0123456789", "ISO 6166", "", "Y"),
       ("Ticker", "Exchange or NASDAQ fund ticker.", "Peer Fund", "Identifier", "", "EXGGX", "Internal", "", ""),
       ("Morningstar SecId", "Morningstar security identifier.", "Peer Fund", "Identifier", "External (Morningstar)", "F00000XXXX", "Morningstar", "", ""),
       ("Managing Firm", "Competitor profile of the managing firm.", "Peer Fund", "Reference (Competitor Profile)", "", "CPF-0112", "Internal", "", "Y"),
       ("Vehicle Type", "Vehicle type of the peer fund.", "Peer Fund", "Code", "Industry Vehicle Type", "Mutual Fund", "Internal", "", ""),
       ("Domicile", "Fund domicile.", "Peer Fund", "Code", "ISO 3166-1 alpha-2", "LU", "Internal", "", ""),
       ("Peer Morningstar Category", "Morningstar category of the peer fund (own funds' category is held in 01).", "Peer Fund", "Code", "External (Morningstar)", "Global Large-Cap Growth Equity", "Morningstar", "", "Y"),
     ]),
   ]),
   ("Peer Metric Snapshot", "Periodic metrics of each member, for ranking and benchmarking.", [
     ("Peer Metric Snapshot", [
       ("Snapshot Date", "Period end of the snapshot.", "Peer Snapshot", "Date", "ISO 8601", "2026-08-31", "Internal", "", "Y"),
       ("Return Period", "Period of the return.", "Peer Snapshot", "Code", "Return Period", "3 Years Annualised", "Morningstar", "", ""),
       ("Total Return", "Total return net of fees for the period.", "Peer Snapshot", "Percentage", "", "11.4%", "Morningstar", "LSEG Lipper", ""),
       ("Category Percentile Rank", "Percentile rank in the universe (1 = best).", "Peer Snapshot", "Integer", "", "18", "Morningstar", "", "Y"),
       ("Quartile Rank", "Quartile in the universe.", "Peer Snapshot", "Code", "Quartile", "1st Quartile", "LSEG Lipper", "Morningstar", ""),
       ("Expense Ratio", "Ongoing charge / net expense ratio of the share class.", "Peer Snapshot", "Percentage", "", "0.85%", "Morningstar", "SEC Form N-1A", "Y"),
       ("Estimated Net Flow", "Estimated net flow for the period.", "Peer Snapshot", "Amount", "", "USD -120m", "Morningstar", "", ""),
       ("Peer Universe", "Universe in which the rank was computed.", "Peer Snapshot", "Reference (Peer Universe)", "", "PEER-0031", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Ratings, Rankings & Awards", "MI-RAT",
  "Third-party published fund, manager and ESG ratings and industry awards for both own and peer funds: Morningstar Star, Medalist and Sustainability ratings, LSEG Lipper Leaders, FE fundinfo Crown ratings, Citywire manager ratings, and industry awards. Consultant ratings (03) and partner research ratings (05) are excluded.",
  [
   ("Rating Scheme", "Reference description of each published rating scheme.", [
     ("Rating Scheme", [
       ("Rating Scheme Code", "Code of the rating scheme.", "Rating Scheme", "Code", "Rating Scheme", "Morningstar Medalist Rating", "Internal", "", "Y"),
       ("Rated Object Type", "Whether the scheme rates share classes, funds, managers or firms.", "Rating Scheme", "Code", "Rated Object Type", "Share Class", "Internal", "", ""),
       ("Rating Basis", "Whether the scheme is quantitative, analyst-driven or hybrid.", "Rating Scheme", "Code", "Rating Basis", "Hybrid (Analyst + Algorithm)", "Morningstar", "", ""),
       ("Peer Group Basis", "Peer group within which ratings are distributed.", "Rating Scheme", "Text", "", "Morningstar Category", "Morningstar", "", ""),
       ("Rebalance Frequency", "How often ratings are recalculated.", "Rating Scheme", "Code", "Frequency", "Monthly", "Morningstar", "FE fundinfo", ""),
       ("Minimum History Required", "Track record needed for a rating.", "Rating Scheme", "Integer", "Months", "36", "Morningstar", "FE fundinfo", ""),
     ]),
   ]),
   ("Fund Rating Observation", "A rating value assigned to an own or peer share class / fund at a date.", [
     ("Rating Observation", [
       ("Rating Observation ID", "Unique identifier of the rating observation.", "Rating Observation", "Identifier", "", "RTG-2026-08-0031277", "Internal", "", "Y"),
       ("Rating Scheme", "Scheme the rating belongs to.", "Rating Observation", "Code", "Rating Scheme", "Morningstar Rating (Star)", "Internal", "", "Y"),
       ("Rated Share Class / Fund", "Own share class (SHC-) or peer fund (PFD-) rated.", "Rating Observation", "Reference (Share Class / Peer Fund)", "", "SHC-004512", "Internal", "", "Y"),
       ("Rating Time Period", "Period the rating covers (overall, 3, 5 or 10 years).", "Rating Observation", "Code", "Rating Time Period", "Overall", "Morningstar", "LSEG Lipper", "Y"),
       ("Lipper Leaders Measure", "Lipper Leaders measure rated (Lipper only).", "Rating Observation", "Code", "Lipper Leaders Measure", "Consistent Return", "LSEG Lipper", "", ""),
       ("Rating Value", "Rating on the scheme's own scale (stars, medal, crowns, globes, score 1-5).", "Rating Observation", "Code", "Rating Value", "4 Stars", "Morningstar", "FE fundinfo", "Y"),
       ("Rating Date", "Month-end or rebalance date of the rating.", "Rating Observation", "Date", "ISO 8601", "2026-08-31", "Morningstar", "", "Y"),
       ("Number of Funds Rated in Peer Group", "Size of the peer group the rating was distributed across (required in many rating citations).", "Rating Observation", "Integer", "", "412", "Morningstar", "SEC Marketing Rule", "Y"),
       ("Rating Peer Group", "Category or classification the rating was computed within.", "Rating Observation", "Code", "External (Vendor)", "US Fund Large Growth", "Morningstar", "LSEG Lipper", ""),
     ]),
     ("Medalist Rating Detail", [
       ("People Pillar", "Morningstar People pillar score.", "Rating Observation", "Code", "Medalist Pillar Score", "Above Average", "Morningstar", "", ""),
       ("Process Pillar", "Morningstar Process pillar score.", "Rating Observation", "Code", "Medalist Pillar Score", "High", "Morningstar", "", ""),
       ("Parent Pillar", "Morningstar Parent pillar score.", "Rating Observation", "Code", "Medalist Pillar Score", "Average", "Morningstar", "", ""),
       ("Price Score", "Fee impact on the rating as expressed by Morningstar (current methodology states a score from -2.5 to +2.5).", "Rating Observation", "Decimal", "", "0.5", "Morningstar", "", "", "Verify against April 2026 methodology."),
       ("Analyst-Driven Percentage", "Share of pillar weight assigned directly by an analyst rather than by algorithm.", "Rating Observation", "Percentage", "", "100%", "Morningstar", "", "Y", "Needed to label rating as analyst or quantitative in citations."),
     ]),
     ("Sustainability Rating Detail", [
       ("Portfolio ESG Risk Score", "Asset-weighted ESG risk score of holdings used for the Morningstar Sustainability Rating.", "Rating Observation", "Decimal", "", "21.4", "Morningstar", "", ""),
       ("Sustainability Globes", "Morningstar Sustainability Rating (1-5 globes; more globes = lower ESG risk vs Global Category).", "Rating Observation", "Integer", "", "4", "Morningstar", "", ""),
     ]),
   ]),
   ("Manager Rating", "Ratings of individual fund managers (Citywire) independent of a single fund.", [
     ("Manager Rating", [
       ("Rated Manager", "Party (02) of the fund manager rated; may be an own employee-PM or a competitor PM.", "Manager Rating", "Reference (Party)", "", "PTY-0457", "Citywire", "", "", "PII"),
       ("Manager Rating Value", "Rating value (e.g. Citywire AAA, AA, A, +).", "Manager Rating", "Code", "Rating Value", "AA", "Citywire", "", "Y"),
       ("Rated Sector", "Citywire sector the rating relates to.", "Manager Rating", "Text", "External (Citywire)", "Equity - Global", "Citywire", "", ""),
       ("Manager Rating Date", "Month the rating applies to.", "Manager Rating", "Date", "ISO 8601", "2026-08-31", "Citywire", "", ""),
     ]),
   ]),
   ("Industry Awards", "Industry awards won or contested by own and competitor funds, managers and firms.", [
     ("Award", [
       ("Award ID", "Unique identifier of the award record.", "Award", "Identifier", "", "AWD-2026-0045", "Internal", "", "Y"),
       ("Award Programme", "Awarding programme (e.g. LSEG Lipper Fund Awards, Morningstar Awards, Citywire awards, Investment Week Fund Manager of the Year).", "Award", "Text", "", "LSEG Lipper Fund Awards United States 2026", "Internal", "", ""),
       ("Award Category", "Category within the programme.", "Award", "Text", "", "Global Multi-Cap Growth Funds - 5 Years", "Internal", "", ""),
       ("Award Outcome", "Result achieved.", "Award", "Code", "Award Outcome", "Winner", "Internal", "", "Y"),
       ("Recipient", "Own share class, peer fund, competitor profile or manager party.", "Award", "Reference (Share Class / Peer Fund / Competitor Profile / Party)", "", "SHC-004512", "Internal", "", "Y"),
       ("Award Date", "Date the award was announced.", "Award", "Date", "ISO 8601", "2026-03-12", "Internal", "", ""),
       ("Award Data Period", "Period of data the award was based on.", "Award", "Text", "", "Five years to 2025-11-30", "SEC Marketing Rule", "", "", "Required context when citing third-party ratings."),
       ("Paid to Participate Indicator", "Whether a fee was paid to enter or to use the award logo.", "Award", "Boolean", "", "N", "SEC Marketing Rule", "UK FCA", "", "Disclosure requirement under SEC Marketing Rule; review owned by 08."),
       ("Citation Approval", "Compliance review approving use of the rating or award in marketing.", "Award", "Reference (Compliance Review)", "", "REV-2026-08812", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Fee Benchmarking", "MI-FEE",
  "Comparison of own fees with peer universes: fee percentiles, competitiveness assessments and pricing inputs passed to Product. Actual fees are owned by 01.",
  [
   ("Fee Benchmark Study", "A fee comparison exercise for an own product or share class against a peer universe.", [
     ("Fee Benchmark Study", [
       ("Fee Study ID", "Unique identifier of the study.", "Fee Study", "Identifier", "", "FBS-2026-0019", "Internal", "", "Y"),
       ("Subject Share Class", "Own share class benchmarked.", "Fee Study", "Reference (Share Class)", "", "SHC-004512", "Internal", "", "Y"),
       ("Peer Universe", "Universe used for comparison.", "Fee Study", "Reference (Peer Universe)", "", "PEER-0031", "Internal", "", ""),
       ("Fee Measure Compared", "Fee measure compared.", "Fee Study", "Code", "Fee Measure", "Ongoing Charges Figure", "Internal", "UK FCA", "Y"),
       ("Study Date", "As-of date of peer fee data.", "Fee Study", "Date", "ISO 8601", "2026-08-31", "Internal", "", ""),
       ("Study Purpose", "Why the study was run.", "Fee Study", "Code", "Fee Study Purpose", "Assessment of Value", "Internal", "UK FCA", ""),
     ]),
   ]),
   ("Fee Benchmark Result", "Statistics of the peer fee distribution and the own product's position in it.", [
     ("Fee Benchmark Result", [
       ("Own Fee Rate", "Own share class fee rate as taken from 01 at study date.", "Fee Result", "Percentage", "", "0.75%", "Internal", "", "", "Copied for point-in-time evidence only; 01 is SoR."),
       ("Peer Median Fee", "Median fee in the universe.", "Fee Result", "Percentage", "", "0.82%", "Morningstar", "", "Y"),
       ("Peer 25th Percentile Fee", "25th percentile fee (cheaper quartile boundary).", "Fee Result", "Percentage", "", "0.65%", "Internal", "", ""),
       ("Peer 75th Percentile Fee", "75th percentile fee.", "Fee Result", "Percentage", "", "0.95%", "Internal", "", ""),
       ("Asset-Weighted Peer Average Fee", "Asset-weighted mean fee of the universe.", "Fee Result", "Percentage", "", "0.71%", "Morningstar", "", ""),
       ("Own Fee Percentile", "Percentile of own fee in the universe (1 = cheapest).", "Fee Result", "Integer", "", "38", "Internal", "", "Y"),
       ("Fee Competitiveness Assessment", "Firm assessment of fee competitiveness.", "Fee Result", "Code", "Fee Competitiveness", "Competitive", "Internal", "", "Y"),
     ]),
   ]),
   ("Pricing Recommendation Input", "Market evidence passed to 01 Product pricing governance; it is not the approved fee.", [
     ("Pricing Input", [
       ("Recommended Fee Range Low", "Lower bound of the recommended fee range.", "Pricing Input", "Percentage", "", "0.65%", "Internal", "", ""),
       ("Recommended Fee Range High", "Upper bound of the recommended fee range.", "Pricing Input", "Percentage", "", "0.75%", "Internal", "", ""),
       ("Rationale", "Narrative rationale, including flows and rating effects.", "Pricing Input", "Text", "", "Peers in Q1 by fee captured 70% of category inflows over 3 years", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Market Sizing & Opportunity Potential", "MI-MSZ",
  "Size of addressable markets and of each advisor, distributor firm, channel, region and institutional / DC opportunity, including wallet-share estimates. 07 holds the territory-level values used in territory design and goals and references these records.",
  [
   ("Market Sizing Record", "A sized market segment at a stated grain, method and as-of date.", [
     ("Market Sizing Record", [
       ("Market Sizing Record ID", "Unique identifier of the sizing record.", "Sizing Record", "Identifier", "", "MSZ-2026-06-004410", "Internal", "", "Y"),
       ("Sizing Subject Type", "What is being sized.", "Sizing Record", "Code", "Sizing Subject Type", "Channel", "Internal", "", "Y"),
       ("Sizing Metric", "Metric of the size.", "Sizing Record", "Code", "Sizing Metric", "Advisor-Controlled Assets", "Cerulli", "Discovery Data", "Y"),
       ("Channel", "Channel of the segment.", "Sizing Record", "Code", "Industry Channel", "Independent RIA", "Cerulli", "", ""),
       ("Geography", "Geographic unit (09) of the segment.", "Sizing Record", "Reference (Geographic Unit)", "", "GEO-US-CBSA-35620", "Internal", "", ""),
       ("Asset Class / Category", "Asset class or category the size relates to, if not total.", "Sizing Record", "Text", "", "Fixed Income", "Internal", "", ""),
       ("Sizing Value", "Value of the metric.", "Sizing Record", "Decimal", "", "8100000000000", "Cerulli", "", "Y"),
       ("Sizing Unit", "Unit of the value (currency amount, count).", "Sizing Record", "Code", "Sizing Unit", "USD", "Internal", "", ""),
       ("Sizing Method", "How the value was produced.", "Sizing Record", "Code", "Sizing Method", "Vendor Published", "Internal", "", "Y"),
       ("Sizing As-of Date", "Date the value relates to.", "Sizing Record", "Date", "ISO 8601", "2025-12-31", "Internal", "", "Y"),
       ("Projection Indicator", "Whether the value is a forward projection.", "Sizing Record", "Boolean", "", "N", "Cerulli", "", ""),
       ("Source Dataset", "Licensed dataset (14) or release used.", "Sizing Record", "Reference (Dataset)", "", "DSET-0057", "Internal", "", ""),
     ]),
   ]),
   ("Advisor & Firm Opportunity Potential", "Estimated opportunity at a distributor firm, office, team or advisor: addressable assets and wallet share.", [
     ("Opportunity Potential", [
       ("Target Party", "Distributor firm, branch, team or advisor (02) assessed.", "Opportunity Potential", "Reference (Party)", "", "PTY-2009981", "Internal", "", "Y", "PII when the party is an individual advisor."),
       ("Practice AUM Input", "Practice / firm assets used as input; taken from the 02 party attribute (vendor estimate).", "Opportunity Potential", "Amount", "", "USD 412m", "Discovery Data", "Broadridge", "", "02 is SoR for practice AUM."),
       ("Addressable Assets", "Portion of assets in vehicles and categories where the firm has products.", "Opportunity Potential", "Amount", "", "USD 160m", "Internal", "Broadridge", "Y"),
       ("Firm Assets with Party", "Own assets attributed to the party (from 06).", "Opportunity Potential", "Amount", "", "USD 6.4m", "Internal", "", ""),
       ("Wallet Share", "Firm assets with the party divided by addressable assets.", "Opportunity Potential", "Percentage", "", "4.0%", "Internal", "", "Y"),
       ("Potential Score", "Score or decile combining size, propensity and growth.", "Opportunity Potential", "Integer", "", "8", "Internal", "", ""),
       ("Potential As-of Date", "Date of the assessment.", "Opportunity Potential", "Date", "ISO 8601", "2026-06-30", "Internal", "", ""),
     ]),
   ]),
   ("Institutional & DC Plan Market", "Sizing of institutional and retirement-plan markets, including DCIO opportunity from Form 5500.", [
     ("Plan Market Record", [
       ("Plan Party", "Retirement plan (02) sized.", "Plan Market", "Reference (Party)", "", "PTY-3501144", "DOL Form 5500", "", ""),
       ("Form 5500 Plan Year", "Plan year of the filing used.", "Plan Market", "Integer", "", "2024", "DOL Form 5500", "", ""),
       ("Total Plan Assets", "Net assets at end of year from Schedule H / 5500-SF.", "Plan Market", "Amount", "", "USD 1.2bn", "DOL Form 5500", "", "Y"),
       ("Recordkeeper", "Recordkeeper (02) identified from Schedule C or vendor data.", "Plan Market", "Reference (Party)", "", "PTY-3300012", "DOL Form 5500", "", ""),
       ("DCIO Opportunity Value", "Estimated assets attainable for DCIO products.", "Plan Market", "Amount", "", "USD 45m", "Internal", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Market Structure Research", "MI-MKS",
  "Intermediary and institutional market structure research: channel trends, platform consolidation, model-portfolio adoption, vehicle shifts and fee compression, from Cerulli-type studies and internal analysis.",
  [
   ("Market Research Report", "Research studies purchased or produced on the market.", [
     ("Market Research Report", [
       ("Research Report ID", "Unique identifier of the report.", "Research Report", "Identifier", "", "MRR-2026-0031", "Internal", "", "Y"),
       ("Report Title", "Title of the report.", "Research Report", "Text", "", "U.S. Intermediary Distribution 2026", "Cerulli", "", ""),
       ("Research Publisher", "Publisher of the report.", "Research Report", "Code", "Industry Data Provider", "Cerulli Associates", "Internal", "", "Y"),
       ("Research Topics", "Topics covered.", "Research Report", "Code (multi)", "Market Topic", "Channel Trends; Model Portfolios", "Internal", "", ""),
       ("Licensed Dataset", "Licence / dataset record (14) governing use and sharing.", "Research Report", "Reference (Dataset)", "", "DSET-0061", "Internal", "", ""),
     ]),
   ]),
   ("Market Trend", "Tracked structural trends and their quantified indicators.", [
     ("Market Trend", [
       ("Market Trend ID", "Unique identifier of the trend.", "Market Trend", "Identifier", "", "TRD-0012", "Internal", "", "Y"),
       ("Trend Name", "Name of the trend.", "Market Trend", "Text", "", "Model-portfolio adoption by wirehouse advisors", "Internal", "", ""),
       ("Trend Topic", "Topic of the trend.", "Market Trend", "Code", "Market Topic", "Model Portfolios", "Internal", "", ""),
       ("Trend Indicator Metric", "Metric used to track the trend.", "Market Trend", "Text", "", "% of advisors using third-party models", "Cerulli", "", ""),
       ("Indicator Value", "Latest value of the indicator.", "Market Trend", "Decimal", "", "38", "Cerulli", "", ""),
       ("Indicator As-of Date", "Date of the indicator value.", "Market Trend", "Date", "ISO 8601", "2025-12-31", "Internal", "", ""),
       ("Trend Direction", "Direction of the trend.", "Market Trend", "Code", "Trend Direction", "Increasing", "Internal", "", ""),
       ("Implication for Firm", "Assessed implication for distribution or product strategy.", "Market Trend", "Text", "", "Prioritise model-delivery capability with top-5 platforms", "Internal", "", ""),
       ("Evidence Reports", "Research reports evidencing the trend.", "Market Trend", "Reference (Research Report) (multi)", "", "MRR-2026-0031", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Win/Loss & Mandate Search Intelligence", "MI-WLI",
  "External mandate search events (hires, terminations, searches announced) and aggregated win/loss analysis across the firm's own opportunities. The opportunities themselves and their reasons are owned by 03.",
  [
   ("Mandate Search Event", "Publicly reported or vendor-reported institutional search, hire or termination, including competitor wins.", [
     ("Mandate Search Event", [
       ("Search Event ID", "Unique identifier of the search event.", "Search Event", "Identifier", "", "MSE-2026-007712", "Internal", "", "Y"),
       ("Search Event Type", "Kind of event.", "Search Event", "Code", "Search Event Type", "Manager Hire", "Nasdaq eVestment", "", "Y"),
       ("Asset Owner", "Institution (02) running the search.", "Search Event", "Reference (Party)", "", "PTY-2208810", "Nasdaq eVestment", "", "Y"),
       ("Consultant", "Investment consultant (02) advising on the search.", "Search Event", "Reference (Party)", "", "PTY-0300112", "Nasdaq eVestment", "", ""),
       ("Mandate Asset Class", "Asset class / universe of the mandate.", "Search Event", "Text", "External (Vendor)", "Global Emerging Markets Equity", "Nasdaq eVestment", "", ""),
       ("Mandate Size", "Reported or estimated mandate size.", "Search Event", "Amount", "", "USD 250m", "Nasdaq eVestment", "", "Y"),
       ("Winning / Hired Manager", "Competitor (or own firm) hired.", "Search Event", "Reference (Competitor Profile)", "", "CPF-0230", "Nasdaq eVestment", "", "Y"),
       ("Terminated Manager", "Manager terminated, where reported.", "Search Event", "Reference (Competitor Profile)", "", "CPF-0112", "Nasdaq eVestment", "", ""),
       ("Event Date", "Date of the decision or announcement.", "Search Event", "Date", "ISO 8601", "2026-08-14", "Nasdaq eVestment", "", ""),
       ("Linked Opportunity", "Own opportunity (03) where the firm took part.", "Search Event", "Reference (Opportunity)", "", "OPP-2026-001877", "Internal", "", ""),
     ]),
   ]),
   ("Win/Loss Analysis", "Aggregated analysis of own opportunity outcomes and external search outcomes over a period.", [
     ("Win/Loss Analysis", [
       ("Analysis Period End", "End of the analysis period.", "Win/Loss Analysis", "Date", "ISO 8601", "2026-06-30", "Internal", "", ""),
       ("Analysis Segment", "Segment analysed (asset class, channel, region, consultant).", "Win/Loss Analysis", "Text", "", "US public plans - EM equity", "Internal", "", ""),
       ("Opportunities Decided", "Count of own opportunities with an outcome (from 03).", "Win/Loss Analysis", "Integer", "", "24", "Internal", "", ""),
       ("Win Rate", "Wins divided by decided opportunities.", "Win/Loss Analysis", "Percentage", "", "29%", "Internal", "", "Y"),
       ("Top Loss Reasons", "Most frequent loss reasons (03 Win Loss Reason list).", "Win/Loss Analysis", "Text", "", "Fees; Investment Performance", "Internal", "", ""),
       ("Most Frequent Winning Competitor", "Competitor winning most often in the segment.", "Win/Loss Analysis", "Reference (Competitor Profile)", "", "CPF-0230", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("News & Horizon Scanning", "MI-HZN",
  "Curated news, research and regulatory developments relevant to the firm's markets, tagged to competitors, products and topics, with relevance and actions.",
  [
   ("Intelligence Item", "A captured news article, research note or market event.", [
     ("Intelligence Item", [
       ("Intelligence Item ID", "Unique identifier of the item.", "Intelligence Item", "Identifier", "", "MIN-2026-018223", "Internal", "", "Y"),
       ("Headline", "Headline or title.", "Intelligence Item", "Text", "", "Example Global Investors cuts fees on 12 index funds", "Internal", "", ""),
       ("Source Type", "Kind of source.", "Intelligence Item", "Code", "Intelligence Source Type", "Trade Press", "Internal", "", ""),
       ("Source Name", "Publication or provider.", "Intelligence Item", "Text", "", "Citywire", "Internal", "", ""),
       ("Publication Date", "Date published.", "Intelligence Item", "Date", "ISO 8601", "2026-09-02", "Internal", "", ""),
       ("Topic Tags", "Topics covered.", "Intelligence Item", "Code (multi)", "Market Topic", "Fees / Pricing", "Internal", "", ""),
       ("Linked Competitors", "Competitor profiles mentioned.", "Intelligence Item", "Reference (Competitor Profile) (multi)", "", "CPF-0112", "Internal", "", ""),
       ("Linked Own Products", "Own strategies or products affected.", "Intelligence Item", "Reference (Strategy / Product) (multi)", "", "STR-00123", "Internal", "", ""),
       ("Relevance Rating", "Assessed relevance to the firm.", "Intelligence Item", "Code", "Impact Level", "High", "Internal", "", "Y"),
     ]),
   ]),
   ("Regulatory Horizon Item", "Upcoming regulatory changes affecting distribution and product competitiveness. Compliance obligations are owned by 08.", [
     ("Regulatory Horizon Item", [
       ("Regulator / Body", "Regulator or standard-setter.", "Regulatory Item", "Code", "Regulatory Body", "UK FCA", "Internal", "", ""),
       ("Regulatory Initiative", "Name of the rule or consultation.", "Regulatory Item", "Text", "", "Consumer Composite Investments (CCI) regime", "Internal", "", "Y"),
       ("Initiative Stage", "Current stage of the initiative.", "Regulatory Item", "Code", "Regulatory Stage", "Final Rules Published", "Internal", "", ""),
       ("Expected Effective Date", "Date the change is expected to apply.", "Regulatory Item", "Date", "ISO 8601", "2026-04-06", "Internal", "", "Y"),
       ("Market Impact Assessment", "Expected effect on competition, flows or channels.", "Regulatory Item", "Text", "", "Changes cost disclosure; may reshape UK platform fee comparisons", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Data Management Metadata", "MI-DMM",
  "Metadata applied to every record in the market and competitive intelligence domain.",
  [
   ("Record Metadata", "Ownership, lineage, licence and versioning of records.", [
     ("Record Metadata", [
       ("Data Owner", "Business role accountable for the data element.", "All", "Text", "Firm-defined", "Head of Market Intelligence", "DCAM (EDM Council)", "", ""),
       ("Data Steward", "Role responsible for day-to-day data quality.", "All", "Text", "Firm-defined", "Market Data Steward", "DCAM (EDM Council)", "", ""),
       ("System of Record", "System holding the authoritative value.", "All", "Code", "Firm-defined", "Market Intelligence Data Mart", "Internal", "", ""),
       ("Source Vendor Dataset", "Licensed dataset (14) the value derives from, for licence compliance.", "All", "Reference (Dataset)", "", "DSET-0042", "Internal", "", "Y"),
       ("Redistribution Permitted Indicator", "Whether the value may be shown to clients or distributors under the licence.", "All", "Boolean", "", "N", "Internal", "", "Y", "Derived from 14 licence terms."),
       ("Record Effective From", "Business-effective start date of the record version.", "All", "Date", "ISO 8601", "2026-09-01", "Internal", "", ""),
       ("Record Effective To", "Business-effective end date of the record version.", "All", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Last Updated Timestamp", "System timestamp of the last change.", "All", "Timestamp", "ISO 8601", "2026-09-19T06:15:10Z", "Internal", "", ""),
       ("Data Quality Status", "Validation status of the record.", "All", "Code", "Data Quality Status", "Validated", "Internal", "", ""),
       ("Data Classification", "Information-security / privacy classification of the record.", "All", "Code", "Data Classification", "Confidential - Licensed", "Internal", "GDPR", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Industry Dataset Family": ("Internal", [("Industry Flow Statistics","Trade-association aggregates (ICI, EFAMA, IA)"),("Fund-Level Flow & Asset Database","Morningstar Direct, ISS MI Simfund, LSEG Lipper"),("Intermediary Sales & Asset Data","Broadridge, Morningstar distribution data; firm/office/advisor grain"),("Advisor & Firm Universe","Discovery Data, FINRA/SEC-derived"),("Market Sizing Research","Cerulli, Casey Quirk-type studies"),("Institutional Search & Mandate Data","Nasdaq eVestment, consultant databases"),("Retirement Plan Data","DOL Form 5500, vendor-enriched"),("Ratings Data","Morningstar, LSEG Lipper, FE fundinfo, Citywire")]),
 "Industry Data Provider": ("Internal", [("ICI","Investment Company Institute (US)"),("EFAMA","European Fund and Asset Management Association"),("Investment Association","UK"),("Morningstar",""),("LSEG Lipper",""),("ISS Market Intelligence","Simfund"),("Broadridge",""),("Cerulli Associates",""),("Nasdaq eVestment",""),("Discovery Data",""),("FE fundinfo",""),("Citywire",""),("US Department of Labor","Form 5500 datasets"),("US SEC","Form ADV, EDGAR"),("Other","")]),
 "Flow Estimation Method": ("ICI / Morningstar / Internal", [("Reported by Funds","Actual sales and redemptions reported by members (ICI monthly, EFAMA, IA)"),("Estimated from TNA and Return","Change in net assets not explained by return (Morningstar)"),("Estimated from Sample","Weekly estimate scaled from reporting sample (ICI weekly)"),("ETF Shares Outstanding Change","Change in shares outstanding x NAV"),("Intermediary Reported","Distributor-level data contributed by intermediaries (Broadridge)"),("Modelled","Vendor or internal model")]),
 "Reinvestment Treatment": ("ICI / Morningstar", [("Excluded from Flows","Reinvested distributions treated as market movement"),("Included in Flows",""),("Not Applicable","")]),
 "Category Scheme": ("Internal (consolidates 06 Category Scheme)", [("ICI Investment Classification",""),("EFAMA EFC",""),("Morningstar Category",""),("Morningstar Global Category",""),("Lipper Global Classification",""),("IA Sector",""),("eVestment Universe",""),("Firm Market Segment","")]),
 "Data Grain": ("Internal", [("Industry Total",""),("Asset Class",""),("Category",""),("Fund Manager Firm",""),("Fund",""),("Share Class",""),("Channel",""),("Distributor Firm",""),("Branch / Office",""),("Advisor",""),("Geography","")]),
 "Industry Vehicle Type": ("ICI / ISS Market Intelligence", [("Mutual Fund",""),("ETF",""),("Closed-End Fund",""),("Interval Fund",""),("CIT","Collective investment trust"),("SMA / Model","Separately managed account or model-delivered"),("UCITS",""),("AIF",""),("Money Market Fund",""),("Variable Annuity Subaccount","")]),
 "Coverage Basis": ("Internal", [("Fund Domicile",""),("Country of Sale",""),("Distributor Reported",""),("Investor Residence","")]),
 "Frequency": ("Internal", [("Daily",""),("Weekly",""),("Monthly",""),("Quarterly",""),("Semi-Annual",""),("Annual",""),("Ad Hoc","")]),
 "Revision Policy": ("Internal", [("No Revisions",""),("Rolling Prior-Period Revisions","E.g. ICI weekly estimates revised for adjustments and reclassifications"),("Annual Rebase",""),("Full History Restatement","")]),
 "Release Status": ("Internal", [("Preliminary",""),("Final",""),("Revised",""),("Withdrawn","")]),
 "Industry Channel": ("Internal (Cerulli-style; harmonise with enterprise Distribution Channel list)", [("Wirehouse",""),("National / Regional Broker-Dealer",""),("Independent Broker-Dealer",""),("Hybrid RIA",""),("Independent RIA",""),("Bank Trust / Private Bank",""),("Insurance Broker-Dealer",""),("DC / Retirement",""),("Institutional",""),("Direct / Self-Directed",""),("UK Platform",""),("UK IFA / Wealth Manager / DFM",""),("EU Private Bank",""),("EU Retail Bank Network",""),("EU Fund Platform","")]),
 "Value Basis": ("Internal", [("Reported",""),("Estimated",""),("Modelled",""),("Interpolated","")]),
 "Share Measure Basis": ("Internal", [("Assets",""),("Gross Sales",""),("Net Flows",""),("Positive Net Flows Only","Share of inflows among funds in net inflow")]),
 "Share Dimension": ("Internal", [("Category",""),("Asset Class",""),("Channel",""),("Distributor Firm",""),("Region / Market",""),("Vehicle",""),("Total Industry","")]),
 "Numerator Source": ("Internal", [("Same Industry Dataset","Own value taken from the same vendor dataset as the denominator"),("06 Attributed Flows / AUM","Own value from internal attribution"),("Blended","Requires a disclosure flag")]),
 "Negative Flow Treatment": ("Internal", [("Report Not Meaningful",""),("Share of Gross Sales Instead",""),("Signed Share","Negative share allowed"),("Share of Positive Flows","")]),
 "Period Type": ("Internal", [("Month",""),("Quarter",""),("Year to Date",""),("Trailing 12 Months",""),("Calendar Year",""),("Point in Time","For asset share")]),
 "Competitor Tier": ("Internal", [("Primary","Head-to-head in core strategies and channels"),("Secondary",""),("Emerging / Disruptor",""),("Watch","")]),
 "Competitor Type": ("Internal", [("Active Multi-Asset Manager",""),("Passive / ETF Specialist",""),("Boutique / Specialist",""),("Insurer-Owned Manager",""),("Bank-Owned Manager",""),("Private Markets Manager",""),("Multi-Boutique / Affiliate Model",""),("Model Portfolio / TAMP Provider","")]),
 "Presence Strength": ("Internal", [("Dominant",""),("Strong",""),("Moderate",""),("Weak",""),("Not Present","")]),
 "Competitor Event Type": ("Internal", [("Product Launch",""),("Product Closure / Merger",""),("Fee Reduction",""),("Share Class Launch",""),("M&A",""),("Strategic Partnership",""),("New Market Entry",""),("Market Exit",""),("Distribution Agreement / Platform Win",""),("Rating Change",""),("Regulatory Action","")]),
 "Impact Level": ("Internal", [("High",""),("Medium",""),("Low",""),("None","")]),
 "Personnel Role": ("Internal", [("Portfolio Manager",""),("CIO",""),("CEO / Executive",""),("Head of Distribution",""),("Head of Product",""),("Senior Wholesaler / Key Account","")]),
 "Personnel Move Type": ("Internal", [("Hire",""),("Departure",""),("Retirement",""),("Internal Role Change","")]),
 "Peer Universe Type": ("Internal", [("Vendor Category","Morningstar Category, Lipper Global Classification, IA Sector"),("Consultant Universe","eVestment or consultant database universe"),("Custom Peer Set","Hand-picked competitors"),("Partner-Defined Peer Group","Peer group used by a distributor home office")]),
 "Representative Class Rule": ("Morningstar / Internal", [("Oldest Share Class",""),("Largest Share Class",""),("Clean / Institutional Class",""),("All Share Classes","")]),
 "Return Period": ("Morningstar / LSEG Lipper", [("1 Month",""),("Year to Date",""),("1 Year",""),("3 Years Annualised",""),("5 Years Annualised",""),("10 Years Annualised",""),("Since Inception","")]),
 "Quartile": ("LSEG Lipper / Morningstar", [("1st Quartile","Best 25%"),("2nd Quartile",""),("3rd Quartile",""),("4th Quartile","Worst 25%")]),
 "Rating Scheme": ("Vendor methodologies", [("Morningstar Rating (Star)","1-5 stars; risk-adjusted return vs Morningstar Category; 36-month minimum"),("Morningstar Medalist Rating","Gold, Silver, Bronze, Neutral, Negative"),("Morningstar Sustainability Rating","1-5 globes vs Morningstar Global Category"),("Lipper Leaders","1-5 per measure; 5 = Lipper Leader (top 20%)"),("FE fundinfo Crown Rating","1-5 crowns; top 10% = 5 crowns; rebalanced semi-annually"),("Citywire Manager Rating","AAA, AA, A, + for managers beating benchmark on rolling 36 months"),("Other Third-Party Rating","E.g. UK fund research agency ratings - confirm with 05")]),
 "Rated Object Type": ("Internal", [("Share Class",""),("Fund",""),("Fund Manager",""),("Firm","")]),
 "Rating Basis": ("Internal", [("Quantitative",""),("Analyst-Driven",""),("Hybrid (Analyst + Algorithm)","")]),
 "Rating Time Period": ("Morningstar / LSEG Lipper", [("Overall",""),("3 Years",""),("5 Years",""),("10 Years","")]),
 "Lipper Leaders Measure": ("LSEG Lipper", [("Total Return",""),("Consistent Return",""),("Preservation",""),("Expense",""),("Tax Efficiency","US only")]),
 "Rating Value": ("Vendor scales", [("1 Star",""),("2 Stars",""),("3 Stars",""),("4 Stars",""),("5 Stars",""),("Gold","Medalist"),("Silver","Medalist"),("Bronze","Medalist"),("Neutral","Medalist"),("Negative","Medalist"),("1 Globe",""),("2 Globes",""),("3 Globes",""),("4 Globes",""),("5 Globes",""),("Lipper 1",""),("Lipper 2",""),("Lipper 3",""),("Lipper 4",""),("Lipper 5 (Leader)",""),("1 Crown",""),("2 Crowns",""),("3 Crowns",""),("4 Crowns",""),("5 Crowns",""),("AAA","Citywire"),("AA","Citywire"),("A","Citywire"),("+","Citywire"),("Not Rated","")]),
 "Medalist Pillar Score": ("Morningstar", [("High",""),("Above Average",""),("Average",""),("Below Average",""),("Low","")]),
 "Award Outcome": ("Internal", [("Winner",""),("Highly Commended",""),("Shortlisted / Finalist",""),("Not Placed","")]),
 "Fee Measure": ("Internal / UK FCA / SEC Form N-1A", [("Ongoing Charges Figure","UK/EU OCF"),("Net Expense Ratio","US prospectus net"),("Gross Expense Ratio",""),("Management Fee",""),("PRIIPs Total Costs","Includes transaction costs"),("All-In Cost Including Platform","")]),
 "Fee Study Purpose": ("Internal", [("New Product Pricing",""),("Repricing Review",""),("Assessment of Value","UK FCA COLL 6.6.20R"),("Board 15(c) Review","US Investment Company Act s.15(c) contract renewal"),("Platform / Partner Negotiation",""),("RFP Support","")]),
 "Fee Competitiveness": ("Internal", [("Highly Competitive","Cheapest quartile"),("Competitive",""),("At Market",""),("Above Market",""),("Uncompetitive","Most expensive quartile")]),
 "Sizing Subject Type": ("Internal", [("Total Market",""),("Channel",""),("Distributor Firm",""),("Branch / Office",""),("Advisor / Team",""),("Geography",""),("Institutional Segment",""),("DC Plan Market",""),("DCIO Market","")]),
 "Sizing Metric": ("Internal / Cerulli", [("Advisor-Controlled Assets",""),("Advisor Count",""),("Producing Advisor Count",""),("Addressable Industry AUM","Assets in categories where the firm has products"),("Addressable Gross Sales",""),("Institutional Assets",""),("DC Plan Assets",""),("DCIO Addressable Assets","DC assets in non-proprietary investment-only products"),("Model Portfolio Assets",""),("Projected Asset Growth Rate","")]),
 "Sizing Unit": ("Internal", [("USD",""),("EUR",""),("GBP",""),("Count",""),("Percent","")]),
 "Sizing Method": ("Internal", [("Vendor Published",""),("Bottom-Up Aggregation","From advisor / plan records"),("Top-Down Allocation","Allocated from total by driver"),("Regression / Model",""),("Analyst Estimate","")]),
 "Market Topic": ("Internal", [("Channel Trends",""),("Platform Consolidation",""),("Model Portfolios",""),("Vehicle Shift (ETF, CIT, SMA)",""),("Fees / Pricing",""),("Private Markets in Wealth",""),("Retirement / DCIO",""),("ESG / Sustainability",""),("Advisor Demographics / Movement",""),("M&A",""),("Regulation",""),("Technology / AI","")]),
 "Trend Direction": ("Internal", [("Increasing",""),("Stable",""),("Decreasing",""),("Emerging","")]),
 "Search Event Type": ("Nasdaq eVestment / Internal", [("Search Announced",""),("RFP Issued",""),("Finalists Named",""),("Manager Hire",""),("Manager Termination",""),("Under Review / Watch",""),("Allocation Change","")]),
 "Intelligence Source Type": ("Internal", [("Trade Press",""),("Newswire",""),("Vendor Research",""),("Regulator Publication",""),("Competitor Filing / Website",""),("Sales Field Feedback","Captured from 03 activities"),("Social Media","")]),
 "Regulatory Body": ("Internal", [("US SEC",""),("FINRA",""),("US DOL",""),("UK FCA",""),("ESMA",""),("European Commission",""),("CSSF",""),("Central Bank of Ireland",""),("BaFin",""),("IOSCO","")]),
 "Regulatory Stage": ("Internal", [("Discussion / Call for Input",""),("Consultation",""),("Final Rules Published",""),("In Implementation",""),("In Force",""),("Withdrawn","")]),
 "Data Quality Status": ("Internal", [("Validated",""),("Pending Validation",""),("Exception",""),("Deprecated","")]),
 "Data Classification": ("Internal", [("Public",""),("Internal",""),("Confidential",""),("Confidential - Licensed","Vendor data under licence restrictions"),("Confidential - Personal Data","")]),
}

# ---------------------------------------------------------------------------
# Relationships, sources
# ---------------------------------------------------------------------------
REL = [
 ("Industry Dataset Profile","describes","Licensed Dataset (14 Third-Party Data: DSET-)","1 : 1","Licence, vendor and entitlements stay in 14; methodology here."),
 ("Industry Dataset Profile","is published as","Industry Data Release","1 : 1..n","Each vintage kept; revisions supersede earlier releases."),
 ("Industry Data Release","is loaded by","Load (06 Transactions: LOAD- / FEED-)","n : 1","Technical feed and load stay in 06."),
 ("Industry Data Release","contains","Industry Flow Observation","1 : 0..n",""),
 ("Category Mapping","maps external category to","Share Class (01 Product: SHC-)","n : n","Own-fund category assignment itself is held in 01 External Classification."),
 ("Market Share Definition","uses denominator from","Industry Dataset Profile","n : 1",""),
 ("Market Share Definition","may use numerator from","Measure Value (06 Transactions: attributed flows / AUM)","n : 0..1","When Numerator Source = 06 Attributed Flows / AUM."),
 ("Market Share Record","is computed under","Market Share Definition","n : 1",""),
 ("Market Share Record","may be scoped to","Party - Distributor Firm (02 Client & Customer: PTY-)","n : 0..1","Share within a distributor."),
 ("Competitor Profile","profiles","Party (02 Client & Customer: PTY-)","1 : 1","Legal entity and hierarchy in 02."),
 ("Competitor Profile","has","Competitor Metric Snapshot / Distribution Footprint","1 : 0..n",""),
 ("Competitor Profile","undergoes","Competitor Event","1 : 0..n",""),
 ("Competitor Personnel Move","concerns","Party - Individual (02 Client & Customer: PTY-)","n : 1","PII."),
 ("Peer Fund","is managed by","Competitor Profile","n : 1",""),
 ("Peer Universe","contains","Peer Fund / Share Class (01 Product: SHC-)","1 : 1..n","Via Peer Universe Member; effective-dated."),
 ("Peer Universe","is used to compare","Investment Strategy (01 Product: STR-)","n : 0..1",""),
 ("Peer Metric Snapshot","is ranked within","Peer Universe","n : 1",""),
 ("Rating Observation","rates","Share Class (01 Product: SHC-) / Peer Fund","n : 1","Same structure for own and peer funds."),
 ("Manager Rating","rates","Party - Fund Manager (02 Client & Customer: PTY-)","n : 1","Citywire; PII."),
 ("Award / Rating citation","is approved by","Compliance Review (08 Distribution Compliance: REV-)","n : 0..1","Marketing use of ratings and awards."),
 ("Fee Benchmark Study","benchmarks","Share Class fees (01 Product: SHC-)","n : 1","01 owns the actual fee."),
 ("Fee Benchmark Study","uses","Peer Universe","n : 1",""),
 ("Market Sizing Record","feeds","Territory Potential Metric (07 Comp & Territory: TER-)","1 : 0..n","07 holds territory values; 07 Market Sizing Source should reference MSZ-."),
 ("Market Sizing Record","is located in","Geographic Unit (09 Shared Reference: GEO-)","n : 0..1",""),
 ("Opportunity Potential","assesses","Party - Distributor / Advisor (02 Client & Customer: PTY-)","n : 1","Practice AUM input read from 02."),
 ("Opportunity Potential","uses firm assets from","Attribution Record (06 Transactions)","n : 0..n",""),
 ("Plan Market Record","sizes","Party - Retirement Plan (02 Client & Customer: PTY-)","n : 1","From DOL Form 5500."),
 ("Mandate Search Event","may link to","Sales Opportunity (03 Sales: OPP-)","n : 0..1","03 owns the opportunity and its win/loss reason."),
 ("Mandate Search Event","is won by","Competitor Profile","n : 0..1",""),
 ("Win/Loss Analysis","aggregates","Sales Opportunity outcomes (03 Sales: OPP-)","1 : 0..n",""),
 ("Market Trend","is evidenced by","Market Research Report","n : n",""),
 ("Intelligence Item","mentions","Competitor Profile / Strategy (01: STR-)","n : n",""),
 ("Market Research Report","is licensed under","Data Licence Agreement (14 Third-Party Data: DLA-)","n : 1",""),
]

SRC = [
 ("ICI Estimated Long-Term Mutual Fund Flows and ETF Net Issuance (weekly)","Investment Company Institute","https://www.ici.org/research/stats/flows","Free summary; member data","Weekly estimates covering >98% of mutual fund and ETF assets; prior weeks revised; monthly actuals collected separately","Flow Estimation Method, Revision Policy, Data Release",["ICI"]),
 ("ICI Monthly Trends in Mutual Fund Investing","Investment Company Institute","https://www.ici.org/monthly-trends-in-mutual-fund-investing","Free summary; member data","Reported sales, redemptions, net new cash flow by ICI classification","Industry Flow Observation, reinvestment treatment",[]),
 ("EFAMA Monthly Investment Fund Industry Fact Sheet / Quarterly Statistical Release","EFAMA","https://www.efama.org/data-research","Free","UCITS and AIF net sales and net assets by country of domicile, from ~29 national associations (~98% of assets)","Coverage Basis, EU Industry Flow Observation",["EFAMA"]),
 ("Investment Association monthly fund statistics","The Investment Association (UK)","https://www.theia.org/industry-data/fund-statistics","Free summary; member data","UK authorised funds net retail sales and FUM by IA Sector","UK Industry Flow Observation, IA Sector scheme",["Investment Association"]),
 ("Morningstar Estimated Net Cash Flow methodology","Morningstar","https://www.morningstar.com/content/dam/marketing/shared/research/methodology/765555_Estimated_Net_Cash_Flow_Methodology.pdf","Free methodology; data licensed","Flow = TNA(t) - TNA(t-1) x (1 + r); distribution adjustments; ETF shares outstanding","Flow Estimation Method, peer flows",["Morningstar"]),
 ("Morningstar Rating for Funds (Star Rating) methodology","Morningstar","https://www.morningstar.com/content/cs-images/v3/assets/blt9415ea4cc4157833/blt4746ec2633987fb2/67819c62694c4c0ed070ba0a/Morningstar_Rating_for_Funds.pdf","Free methodology; data licensed","Risk-adjusted return vs Morningstar Category; 36-month minimum; 3/5/10-year and overall","Rating Scheme, Rating Observation",[]),
 ("Morningstar Medalist Rating methodology (April 2026)","Morningstar","https://s25.q4cdn.com/634000362/files/doc_downloads/1/Morningstar_Medalist_Rating_Methodology-April-2026.pdf","Free methodology; data licensed","Gold/Silver/Bronze/Neutral/Negative; People, Process, Parent pillars; analyst-driven and data coverage %; price score","Medalist Rating Detail",[]),
 ("Morningstar Sustainability Rating methodology","Morningstar / Sustainalytics","https://www.morningstar.com/content/dam/marketing/shared/research/methodology/SustainabilityRatingMethodology_2021.pdf","Free methodology; data licensed","1-5 globes from portfolio ESG risk score vs Morningstar Global Category","Sustainability Rating Detail",[]),
 ("LSEG Lipper Leaders methodology","LSEG (Lipper)","https://lipperleaders.com/documents/LipperLeaders_Methodology_Intl.pdf","Free methodology; data licensed","Total Return, Consistent Return, Preservation, Expense (+Tax Efficiency US); quintile scores 1-5; 3/5/10-year and overall","Lipper Leaders Measure, Rating Observation",["LSEG Lipper"]),
 ("FE fundinfo Crown Fund Ratings methodology","FE fundinfo","https://www.fefundinfo.com/products/institutions/ratings/methodology","Free methodology; data licensed","Alpha, volatility and consistency tests; top 10% = 5 crowns; rebalanced Feb and Aug; 3-year minimum","Rating Scheme, Rating Observation",["FE fundinfo"]),
 ("Citywire Fund Manager Ratings","Citywire","https://citywire.com","Proprietary","Manager-level ratings AAA/AA/A/+ from rolling 36-month information ratio vs benchmark","Manager Rating",["Citywire"]),
 ("ISS Market Intelligence Simfund","ISS Market Intelligence","https://www.issmarketintelligence.com","Licensed","Fund, ETF, CIT and SMA flows and assets across managers, vehicles, regions","Industry Flow Observation, Competitor Metrics, CIT vehicle",["ISS Market Intelligence"]),
 ("Broadridge Distribution Insight / Sales & Asset Reporting","Broadridge","https://www.broadridge.com/financial-services/asset-management/mutual-funds-etf/access-unique-distribution-insights/sales-and-asset-reporting","Licensed","Intermediary sales and assets by firm, office and advisor; market share by channel","Market share within distributor, Opportunity Potential",["Broadridge"]),
 ("Cerulli Associates - U.S. Intermediary research (e.g. U.S. Intermediary Distribution)","Cerulli Associates","https://www.cerulli.com/research-areas/us-intermediary","Licensed","Advisor-controlled assets by channel, distributor rankings, market share projections","Industry Channel, Market Sizing, Market Trends",["Cerulli"]),
 ("Nasdaq eVestment Market Lens","Nasdaq","https://www.nasdaq.com/solutions/evestment/asset-managers/market-lens","Licensed","Plan documents, mandates, searches under review, manager rosters","Mandate Search Event, Win/Loss Analysis",["Nasdaq eVestment"]),
 ("DOL Form 5500 Datasets (EFAST2)","US Department of Labor, EBSA","https://www.dol.gov/agencies/ebsa/about-ebsa/our-activities/public-disclosure/foia/form-5500-datasets","Public","Form 5500 / 5500-SF and schedules (H financials, C service providers), updated monthly","Plan Market Record",["DOL Form 5500"]),
 ("SEC Form ADV / IAPD","US SEC","https://adviserinfo.sec.gov","Public","Regulatory AUM and firm data for US investment advisers","Competitor Metrics",["SEC Form ADV"]),
 ("SEC Marketing Rule 206(4)-1 (third-party ratings)","US SEC","https://www.sec.gov/rules-regulations/staff-guidance/division-investment-management-frequently-asked-questions/marketing-compliance-frequently-asked-questions","Regulation","Conditions for citing third-party ratings: date, period, provider, compensation disclosure","Award and rating citation attributes (review owned by 08)",["SEC Marketing Rule"]),
 ("UK FCA COLL 6.6.20R Assessment of Value and Consumer Duty","UK FCA","https://www.handbook.fca.org.uk/handbook/COLL/6/6.html","Regulation","Comparable market rates as an AoV criterion","Fee Benchmark purpose",["UK FCA"]),
 ("SEC Form N-1A fee table","US SEC","https://www.sec.gov/files/formn-1a.pdf","Regulation","Expense ratio definitions for US funds","Fee Measure",["SEC Form N-1A"]),
 ("Discovery Data","Discovery Data","https://discoverydata.com","Licensed","Advisor and firm universe, practice AUM estimates","Opportunity Potential inputs (via 02)",["Discovery Data"]),
 ("ISO 6166 (ISIN) / ISO 3166 / ISO 4217 / ISO 8601","ISO","https://www.iso.org","Standard","Identifiers and code lists","Peer Fund identifiers, geography, currency, dates",["ISO 6166"]),
 ("DCAM","EDM Council","https://edmcouncil.org","Member framework","Data ownership, stewardship and data-quality","Data Management Metadata",["DCAM*"]),
]
