"""Business domain 12 - Institutional Client Servicing & Reporting. Content module for taxonomy_builder.py."""

META = {
 "title": "Institutional Client Servicing & Reporting Data Taxonomy",
 "subtitle": "Business domain 12 - Institutional Client Servicing & Reporting | Asset manager (wholesale distributor) | Scope: US + EU/UK | Draft v0.1 | 2026-10-01",
 "output": "12_Institutional_Client_Servicing_and_Reporting/Institutional_Client_Servicing_and_Reporting_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for servicing institutional, sub-advisory, DCIO and platform/model clients after the mandate is won: who services the client, what we report to them and how, how we handle their requests, instructions and guideline breaches, how the mandate is set up operationally, how we bill them and how the relationship ends. Stitched together from GIPS 2020, ILPA Reporting and Performance Templates, the UK Cost Transparency Initiative (CTI) templates, MiFID II client reporting rules, ISO 15022/20022 settlement messaging, the UK Stewardship Code and CRM service-case models. Use it as a starting point for a client reporting platform, a service-case model, a billing system or a business glossary."),
  ("Scope", "In scope: client service model (tiers, standards/SLAs, service teams, coverage of service staff to clients and mandates); client reporting (report definitions, components, templates, packages, schedules, recipients and distribution lists, production runs, sign-off, versions and restatements, delivery); performance and holdings PRESENTATION reference (return types, fee basis, currency, periods, benchmarks shown, GIPS disclosures, look-through, ILPA and CTI templates); guideline monitoring arrangements and client-facing breach notification, cure and certification; client service requests and cases; contribution/withdrawal (cash flow) notifications; client reviews, feedback/NPS and relationship health; mandate operational set-up (custody accounts, SSIs, outbound data feeds to custodians and consultants, transitions and in-specie transfers); fee billing and invoicing for segregated mandates, SMAs/sub-advisory and DCIO separate accounts; termination and offboarding. Out of scope (referenced by ID): mandates, investment restrictions, fee terms, benchmarks and GIPS composites (01 Investment Product); parties, client accounts, contact points, consultant relationships, KYC and consent (02 Client & Customer); employees, sales activities and meetings, opportunities, RFPs and consultant database submissions (03 Sales); brands, portals and digital identity (04 Marketing & Digital); agreements (05 Distribution Agreements & Partners); transactions, positions, AUM and inbound feeds (06 Sales Transactions & AUM Attribution); service-staff coverage of sales territories (07 Compensation & Territory); compliance reviews and complaints (08 Distribution Compliance); calendars, legal entities and languages (09 Shared Reference Data); fee revenue accounting and cost-to-serve (10 Distribution Finance); shareholder servicing for funds (13 Investor Servicing). Return and holdings VALUES are produced by performance measurement and IBOR/ABOR platforms and are not modelled here."),
  ("Structure", "Four levels: Domain > Subdomain > Concept > Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Service Relationship (client PTY- with its mandates MND- and consultant) -> Service Tier and Service Standards (SLA-) -> Service Coverage Assignments of service staff (EMP-) in a service role. Reporting: Report Definition (RPT-) built from Components and a Template (TPL-), with a Performance Presentation Profile -> grouped into a Report Package (RPK-) per client -> scheduled -> produced as Report Runs (RRN-) with cut-off, review, sign-off and version -> delivered to Distribution Lists (DLS-) by channel. Servicing: Service Requests (CSR-), Cash Flow Notifications (CFN-), Breach Notifications (GBN-), Client Reviews (CRV-) and Feedback (CFS-). Set-up: Custody Accounts (CUA-), SSIs (SSI-), Client Data Feeds (CDF-), Transitions (TRN-). Commercial: Billing Arrangement (BLA-) -> Invoices (BIL-) -> Adjustments and Disputes (BDP-). Exit: Termination (TRM-)."),
  ("Design principles", "1) Reference, don't redefine: mandates, restrictions, fees, benchmarks and composites are 01's; parties, accounts and contact points are 02's; employees and activities are 03's. 2) Separate the definition (what we promised to report or bill) from the instance (the run, the invoice, the notification), so SLA compliance can be measured. 3) Presentation, not calculation: this domain records which return type, fee basis, currency and periods a client sees, not the return values. 4) Evidence trail: sign-off, delivery, client notification and acknowledgement timestamps are kept, because they support audits, client disputes and regulatory reporting obligations (MiFID II, GIPS). 5) Effective-date coverage, tiers, SSIs, billing arrangements and recipients. 6) Flag CDEs and personal data (PII)."),
  ("Applies To", "Shows the record each attribute belongs to: Service Relationship, Service Tier, Service Standard, Service Team, Service Assignment, Report Definition, Report Component, Template, Report Package, Presentation Profile, Report Schedule, Report Run, Distribution List, Delivery, Monitoring Arrangement, Breach Notification, Certificate, Service Request, Cash Flow Notification, Client Review, Feedback, Health Score, Custody Account, SSI, Data Feed, Transition, Billing Arrangement, Invoice, Performance Fee Calc, Fee Adjustment, Billing Dispute, Termination or All."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify the client relationship or mandate, meet a contractual or regulatory reporting or notification deadline, settle client assets correctly, or bill the client correctly. Confirm with data owners."),
  ("Primary / Secondary Reference", "Standard or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Next step: map GIPS-aligned attributes to the exact provision numbers in the 2020 GIPS Standards for Firms and the GIPS Handbook, and ILPA-aligned attributes to the 2025 template line items."),
  ("Tabs", "Hierarchy: domains, subdomains and concepts with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: concept-level cardinalities, including references to other business domains | Sources: standards used, owners, licences and links."),
  ("Suggested next steps", "1) Validate domains, service roles and CDEs with Client Service, Client Reporting, Investment Operations, Billing/Finance and Legal for US and EU/UK. 2) Map attributes to source systems (CRM service cloud, client reporting platform, performance system, OMS compliance engine, custody/SSI tools such as DTCC ALERT, billing engine). 3) Agree with 01 how mandate-specific restrictions and fee schedules are versioned so breaches and invoices reference the right version. 4) Agree with 02 who owns the custodian account record (02 'Custodian' on Institutional Account vs 12 Custody Account). 5) Agree with 03 whether client review meetings are logged as ACT- activities with a 12 governance wrapper. 6) Harmonise Frequency, Delivery Channel and Status lists with the enterprise code list registry (09). 7) Turn the Relationships tab into a logical data model."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Client Service Model", "IS-SVC",
  "How the firm services each institutional, sub-advisory, DCIO and platform/model client after the mandate is won: the service relationship, the tier and service standards it receives, and the service staff assigned to it.",
  [
   ("Service Relationship", "The servicing view of a client: which mandates and vehicles are serviced together, by which channel and in which tier.", [
     ("Service Relationship", [
       ("Service Relationship ID", "Unique identifier of the servicing relationship with a client.", "Service Relationship", "Identifier", "", "SVR-00412", "Internal", "Salesforce FSC", "Y"),
       ("Client", "Party reference of the client being serviced (asset owner, sub-advisory client, plan sponsor or platform sponsor).", "Service Relationship", "Reference (Party)", "", "PTY-2201", "Internal", "", "Y"),
       ("Servicing Segment", "Client segment that drives the service model.", "Service Relationship", "Code", "Servicing Segment", "Institutional - Segregated Mandate", "Internal", "", "Y"),
       ("Serviced Mandates", "Mandates serviced under the relationship.", "Service Relationship", "Reference (Mandate) (multi)", "", "MND-01234; MND-01240", "Internal", "", "Y"),
       ("Serviced Pooled Holdings", "Pooled products or share classes held by the client that are serviced under the relationship (e.g. CIT, QIAIF, private fund interests).", "Service Relationship", "Reference (Product / Share Class) (multi)", "", "PRD-00981", "Internal", "", ""),
       ("Advising Consultant", "Consultant or OCIO advising the client, taken from the 02 consultant relationship at the time of set-up.", "Service Relationship", "Reference (Party)", "", "PTY-100670", "Internal", "", ""),
       ("Service Tier", "Service tier assigned to the relationship.", "Service Relationship", "Code", "Service Tier", "Tier 1 - Strategic", "Internal", "", ""),
       ("Servicing Legal Entity", "Internal legal entity that contracts with and services the client (e.g. US RIA, UK MiFID firm, Lux ManCo).", "Service Relationship", "Reference (Legal Entity)", "", "LEN-UK-01", "Internal", "MiFID II", ""),
       ("Service Relationship Status", "Lifecycle status of the servicing relationship.", "Service Relationship", "Code", "Service Relationship Status", "Active", "Internal", "", ""),
     ]),
   ]),
   ("Service Tiers & Standards", "Tiers that bundle service entitlements, and the measurable service standards (SLAs) the firm commits to.", [
     ("Service Tier", [
       ("Service Tier Code", "Code of the tier.", "Service Tier", "Code", "Service Tier", "Tier 1 - Strategic", "Internal", "", "Y"),
       ("Tier Eligibility Criteria", "Rules that place a client in the tier (AUM, revenue, complexity, strategic value).", "Service Tier", "Text", "", "Relationship AUM > USD 1bn or > 2 mandates", "Internal", "", ""),
       ("Standard Review Meeting Cadence", "Number and type of review meetings the tier is entitled to.", "Service Tier", "Code", "Frequency", "Quarterly", "Internal", "", ""),
       ("Standard Reporting Frequency", "Default frequency of the core client report for the tier.", "Service Tier", "Code", "Frequency", "Monthly", "Internal", "", ""),
     ]),
     ("Service Standard", [
       ("Service Standard ID", "Unique identifier of the service standard / SLA.", "Service Standard", "Identifier", "", "SLA-0031", "Internal", "", ""),
       ("Service Standard Metric", "What the standard measures.", "Service Standard", "Code", "Service Standard Metric", "Report Delivery Timeliness", "Internal", "ITIL", "Y"),
       ("Target Value", "Target the firm commits to.", "Service Standard", "Decimal", "", "10", "Internal", "", ""),
       ("Target Unit", "Unit of the target value.", "Service Standard", "Code", "SLA Unit", "Business Days After Period End", "Internal", "", ""),
       ("Contractual Indicator", "Whether the standard is written into the IMA, side letter or service-level agreement (vs internal target).", "Service Standard", "Boolean", "", "Y", "Internal", "", ""),
       ("Applies To Tier / Relationship", "Tier or specific relationship the standard applies to.", "Service Standard", "Reference (Service Tier / Service Relationship)", "", "SVR-00412", "Internal", "", ""),
       ("Standard Effective From", "Date the standard took effect.", "Service Standard", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
     ]),
   ]),
   ("Service Team & Coverage", "Service teams and the effective-dated assignment of service staff to client relationships and mandates.", [
     ("Service Team", [
       ("Service Team ID", "Unique identifier of the service team or pod.", "Service Team", "Identifier", "", "SVT-EMEA-02", "Internal", "", ""),
       ("Service Team Name", "Name of the team.", "Service Team", "Text", "", "EMEA Pensions Client Service", "Internal", "", ""),
       ("Service Team Lead", "Employee leading the team.", "Service Team", "Reference (Employee)", "", "EMP-02210", "Internal", "", "", "PII"),
     ]),
     ("Service Coverage Assignment", [
       ("Service Assignment ID", "Unique identifier of the assignment.", "Service Assignment", "Identifier", "", "SVA-008812", "Internal", "", ""),
       ("Assigned Service Employee", "Employee assigned to service the client or mandate (EMP- master owned by 03).", "Service Assignment", "Reference (Employee)", "", "EMP-02231", "Internal", "", "Y", "PII"),
       ("Service Role", "Role the employee plays for the client.", "Service Assignment", "Code", "Service Role", "Client Service Manager", "Internal", "", "Y"),
       ("Covered Service Relationship", "Relationship covered.", "Service Assignment", "Reference (Service Relationship)", "", "SVR-00412", "Internal", "", ""),
       ("Covered Mandate", "Mandate covered, where the assignment is mandate-specific (e.g. a client portfolio manager per strategy).", "Service Assignment", "Reference (Mandate)", "", "MND-01234", "Internal", "", ""),
       ("Primary Contact Indicator", "Whether the employee is the client's primary contact for the role.", "Service Assignment", "Boolean", "", "Y", "Internal", "", ""),
       ("Service Team", "Team the assignment belongs to.", "Service Assignment", "Reference (Service Team)", "", "SVT-EMEA-02", "Internal", "", ""),
       ("Assignment Effective From", "Date the assignment started.", "Service Assignment", "Date", "ISO 8601", "2025-04-01", "Internal", "", ""),
       ("Assignment Effective To", "Date the assignment ended.", "Service Assignment", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Report Definition & Content", "IS-RDF",
  "What the firm reports to clients: report definitions and their content components, templates and branding, and the report packages assembled for each client.",
  [
   ("Report Definition", "The catalogue of standard and bespoke client reports.", [
     ("Report Definition", [
       ("Report Definition ID", "Unique identifier of the report definition.", "Report Definition", "Identifier", "", "RPT-0107", "Internal", "", "Y"),
       ("Report Name", "Name of the report.", "Report Definition", "Text", "", "Quarterly Investment Report - Segregated Equity", "Internal", "", ""),
       ("Report Type", "Type of client report.", "Report Definition", "Code", "Report Type", "Quarterly Investment Report", "Internal", "", "Y"),
       ("Report Scope Level", "Level the report is produced for.", "Report Definition", "Code", "Report Scope Level", "Mandate", "Internal", "", ""),
       ("Standard / Bespoke Indicator", "Whether the report is a standard firm report or built for one client.", "Report Definition", "Code", "Report Customisation", "Standard", "Internal", "", ""),
       ("Regulatory Driver", "Regulation or industry standard that requires or shapes the report, if any.", "Report Definition", "Code (multi)", "Reporting Driver", "MiFID II Periodic Statement", "MiFID II Delegated Reg 2017/565", "UK FCA COBS 16A", ""),
       ("Report Template", "Template used to render the report.", "Report Definition", "Reference (Template)", "", "TPL-0012", "Internal", "", ""),
       ("Available Languages", "Languages the report is produced in.", "Report Definition", "Code (multi)", "ISO 639-1", "en; de; fr", "Internal", "", ""),
     ]),
   ]),
   ("Report Components", "Reusable content blocks that make up a report.", [
     ("Report Component", [
       ("Component ID", "Unique identifier of the content component.", "Report Component", "Identifier", "", "RCM-0451", "Internal", "", ""),
       ("Component Type", "Kind of content the component shows.", "Report Component", "Code", "Report Component Type", "Performance Summary", "Internal", "", ""),
       ("Commentary Required Indicator", "Whether the component needs written commentary from the investment team.", "Report Component", "Boolean", "", "Y", "Internal", "", ""),
       ("Mandatory Component Indicator", "Whether the component is required (e.g. regulatory or GIPS disclosure) and cannot be removed for a client.", "Report Component", "Boolean", "", "Y", "Internal", "GIPS", ""),
     ]),
   ]),
   ("Templates & Branding", "Layouts and branding applied to client reports.", [
     ("Report Template", [
       ("Template ID", "Unique identifier of the template.", "Template", "Identifier", "", "TPL-0012", "Internal", "", ""),
       ("Template Name", "Name of the template.", "Template", "Text", "", "Institutional Quarterly - Corporate Brand v4", "Internal", "", ""),
       ("Output Format", "File or rendering format produced.", "Template", "Code", "Report Output Format", "PDF", "Internal", "", ""),
       ("Brand", "Brand applied to the template (owned by 04).", "Template", "Reference (Brand)", "", "BRD-001", "Internal", "", ""),
       ("Co-Branding / White-Label Type", "Whether the report carries the client's, consultant's or sponsor's branding.", "Template", "Code", "Branding Type", "Firm Brand", "Internal", "", ""),
     ]),
   ]),
   ("Report Packages", "The set of reports each client receives, with client-specific settings.", [
     ("Report Package", [
       ("Report Package ID", "Unique identifier of the client report package.", "Report Package", "Identifier", "", "RPK-00388", "Internal", "", "Y"),
       ("Package Client", "Client the package is produced for.", "Report Package", "Reference (Service Relationship)", "", "SVR-00412", "Internal", "", "Y"),
       ("Included Report Definitions", "Report definitions in the package, in order.", "Report Package", "Reference (Report Definition) (multi)", "", "RPT-0107; RPT-0115; RPT-0140", "Internal", "", "Y"),
       ("Covered Mandates / Holdings", "Mandates and pooled holdings the package reports on.", "Report Package", "Reference (Mandate / Product) (multi)", "", "MND-01234; MND-01240", "Internal", "", ""),
       ("Consolidation Level", "Whether the package reports mandates separately or consolidated.", "Report Package", "Code", "Consolidation Level", "Consolidated and by Mandate", "Internal", "", ""),
       ("Package Frequency", "Production frequency of the package.", "Report Package", "Code", "Frequency", "Quarterly", "Internal", "", ""),
       ("Package Effective From", "Date the package configuration took effect.", "Report Package", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Performance & Holdings Presentation", "IS-PPR",
  "Reference data that controls how performance, holdings, risk, costs and stewardship information are presented to each client. Return and holdings values are produced elsewhere; this domain records the presentation choices and disclosures.",
  [
   ("Performance Presentation Profile", "Return types, fee basis, currency, periods and benchmarks shown in a client's reports.", [
     ("Presentation Profile", [
       ("Presentation Profile ID", "Unique identifier of the presentation profile.", "Presentation Profile", "Identifier", "", "PPP-00211", "Internal", "", ""),
       ("Applies To Package / Mandate", "Report package or mandate the profile applies to.", "Presentation Profile", "Reference (Report Package / Mandate)", "", "RPK-00388", "Internal", "", ""),
       ("Return Methodology Shown", "Return methodology shown.", "Presentation Profile", "Code", "Return Methodology", "Time-Weighted", "GIPS", "", "Y"),
       ("Fee Basis Shown", "Whether returns are shown gross of fees, net of fees, or both.", "Presentation Profile", "Code", "Fee Basis", "Gross and Net", "GIPS", "SEC Marketing Rule", "Y"),
       ("Reporting Currency", "Currency in which returns and values are shown.", "Presentation Profile", "Code", "ISO 4217", "GBP", "Internal", "", "Y"),
       ("Primary Benchmark Shown", "Benchmark shown alongside the mandate's returns; normally the mandate's primary benchmark in 01, but may be client-specified.", "Presentation Profile", "Reference (Benchmark)", "", "BMK-0001", "GIPS", "", "Y"),
       ("Periods Shown", "Return periods shown.", "Presentation Profile", "Code (multi)", "Return Period", "QTD; YTD; 1Y; 3Y; 5Y; Since Inception", "GIPS", "", ""),
       ("Performance Start Date Shown", "Date from which the client's own track record is shown (usually mandate funding date).", "Presentation Profile", "Date", "ISO 8601", "2019-10-01", "Internal", "", ""),
       ("Net Return Fee Treatment", "Whether net returns use actual or model fees.", "Presentation Profile", "Code", "Net Fee Treatment", "Actual Fees", "GIPS", "SEC Marketing Rule", ""),
     ]),
   ]),
   ("Holdings & Look-Through Presentation", "How holdings, exposures and look-through are shown.", [
     ("Holdings Presentation", [
       ("Holdings Detail Level", "Level of holdings detail shown.", "Presentation Profile", "Code", "Holdings Detail Level", "Full Holdings", "Internal", "", ""),
       ("Look-Through Indicator", "Whether pooled fund holdings are shown on a look-through basis.", "Presentation Profile", "Boolean", "", "Y", "Internal", "Solvency II TPT", ""),
       ("Look-Through Template", "Industry template used for look-through data, if any.", "Presentation Profile", "Code", "Look-Through Template", "Solvency II TPT", "Solvency II TPT", "", ""),
       ("Holdings Disclosure Lag Days", "Lag applied before holdings are disclosed, where the client permits a lag (e.g. sub-advisory).", "Presentation Profile", "Integer", "Days", "30", "Internal", "", ""),
     ]),
   ]),
   ("GIPS Disclosure Requirements", "GIPS composite reporting for the strategy behind a mandate, and when GIPS Reports must be provided or updated.", [
     ("GIPS Report Provision", [
       ("Related GIPS Composite", "GIPS composite the mandate belongs to (owned by 01).", "Report Definition", "Reference (Composite)", "", "CMP-0045", "GIPS", "", "Y"),
       ("GIPS Report Type", "Type of GIPS Report provided.", "Report Definition", "Code", "GIPS Report Type", "Composite Time-Weighted Return Report", "GIPS", "", ""),
       ("GIPS Report Required Indicator", "Whether a GIPS Report must be provided (prospective clients) or is provided by choice (existing clients).", "Report Definition", "Boolean", "", "N", "GIPS", "", ""),
       ("GIPS Report As-Of Date", "Annual period end of the GIPS Report version provided; must be updated within 12 months of each annual period end.", "Report Definition", "Date", "ISO 8601", "2025-12-31", "GIPS", "", ""),
       ("Required Disclosure Set", "Set of GIPS numerical information and disclosures included (e.g. dispersion, 3-year standard deviation, composite and firm assets).", "Report Definition", "Code (multi)", "GIPS Disclosure Item", "Internal Dispersion; 3Y Ex-Post Std Dev; Composite Assets", "GIPS", "", ""),
     ]),
   ]),
   ("Industry Reporting Templates", "Templates used for private fund, cost and stewardship reporting to institutional clients.", [
     ("Template Adoption", [
       ("ILPA Reporting Template Version", "Version of the ILPA Reporting Template used for a private fund client's quarterly fee and expense reporting.", "Report Definition", "Code", "ILPA Template Version", "2025", "ILPA Reporting Template", "", ""),
       ("ILPA Performance Methodology", "ILPA Performance Template methodology used.", "Report Definition", "Code", "ILPA Performance Methodology", "Granular", "ILPA Performance Template", "", ""),
       ("CTI Template Type", "UK Cost Transparency Initiative template provided to UK pension scheme clients.", "Report Definition", "Code", "CTI Template Type", "Account Template", "CTI", "", ""),
       ("MiFID Ex-Post Cost Report Indicator", "Whether an annual ex-post costs and charges statement is produced for the client.", "Report Definition", "Boolean", "", "Y", "MiFID II Delegated Reg 2017/565", "UK FCA COBS 16A", ""),
       ("Stewardship Report Scope", "Stewardship content provided to the client (voting, engagement, outcomes).", "Report Definition", "Code (multi)", "Stewardship Content", "Voting Record; Engagement Case Studies", "UK Stewardship Code", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Report Production & Delivery", "IS-RPD",
  "When and how reports are produced and delivered: schedules and cut-offs, production runs with review, sign-off, versions and restatements, distribution lists and delivery records.",
  [
   ("Report Schedule", "Production calendar for a package or report.", [
     ("Report Schedule", [
       ("Scheduled Package / Report", "Package or report the schedule applies to.", "Report Schedule", "Reference (Report Package / Report Definition)", "", "RPK-00388", "Internal", "", ""),
       ("Data Cut-Off Offset", "Business days after period end at which data is frozen.", "Report Schedule", "Integer", "Days", "5", "Internal", "", ""),
       ("Delivery Due Offset", "Business days after period end by which the report must be delivered.", "Report Schedule", "Integer", "Days", "10", "Internal", "", "Y"),
       ("Business Calendar", "Business-day calendar used to compute the dates (owned by 09).", "Report Schedule", "Reference (Calendar)", "", "CAL-UK-LON", "Internal", "", ""),
     ]),
   ]),
   ("Report Production Run", "Each production instance of a report or package for a period, with its control evidence.", [
     ("Report Run", [
       ("Report Run ID", "Unique identifier of the production run.", "Report Run", "Identifier", "", "RRN-2026Q3-004512", "Internal", "", "Y"),
       ("Run Package / Report", "Package or report produced.", "Report Run", "Reference (Report Package / Report Definition)", "", "RPK-00388", "Internal", "", ""),
       ("Reporting Period End", "Last day of the period reported (as-of date).", "Report Run", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
       ("Data Cut-Off Timestamp", "When source data was frozen for the run.", "Report Run", "Timestamp", "ISO 8601", "2026-10-07T18:00:00Z", "Internal", "", ""),
       ("Production Status", "Status of the run.", "Report Run", "Code", "Production Status", "Signed Off", "Internal", "", "Y"),
       ("Signed Off By", "Employee who approved release to the client.", "Report Run", "Reference (Employee)", "", "EMP-02210", "Internal", "", "", "PII"),
       ("Sign-Off Timestamp", "When release was approved.", "Report Run", "Timestamp", "ISO 8601", "2026-10-12T15:20:00Z", "Internal", "", "Y"),
       ("Version Number", "Version of the run output; increments on reissue.", "Report Run", "Integer", "", "1", "Internal", "", ""),
       ("Restatement Indicator", "Whether the run restates a previously delivered report.", "Report Run", "Boolean", "", "N", "Internal", "GIPS", "Y"),
       ("Restatement Reason", "Why the report was restated.", "Report Run", "Code", "Restatement Reason", "Pricing Correction", "Internal", "GIPS", ""),
       ("Compliance Review", "Compliance review of the report content where required (e.g. one-on-one presentations with hypothetical performance); owned by 08.", "Report Run", "Reference (Compliance Review)", "", "REV-2026-08812", "SEC Marketing Rule", "", ""),
       ("SLA Met Indicator", "Whether delivery met the production SLA.", "Report Run", "Boolean", "", "Y", "Internal", "", ""),
     ]),
   ]),
   ("Recipients & Distribution", "Who receives each package and how.", [
     ("Distribution List", [
       ("Distribution List ID", "Unique identifier of the distribution list.", "Distribution List", "Identifier", "", "DLS-00977", "Internal", "", ""),
       ("Distribution Package", "Package distributed to the list.", "Distribution List", "Reference (Report Package)", "", "RPK-00388", "Internal", "", ""),
       ("Recipient", "Person or organisation that receives the package.", "Distribution List", "Reference (Party)", "", "PTY-500881", "Internal", "", "", "PII (where an individual)."),
       ("Delivery Channel", "Channel used to deliver to the recipient.", "Distribution List", "Code", "Delivery Channel", "Client Portal", "Internal", "", "Y"),
       ("Delivery Contact Point", "Email or postal contact point used (owned by 02).", "Distribution List", "Reference (Contact Point)", "", "PTY-500881 business email (02 contact point)", "Internal", "", "", "PII"),
       ("Delivery Endpoint", "SFTP host/path, portal space or API endpoint for non-email delivery.", "Distribution List", "Text", "URI", "sftp://reports.example.com/clients/PTY-2201/", "Internal", "", ""),
     ]),
     ("Report Delivery", [
       ("Delivered Run", "Run delivered.", "Delivery", "Reference (Report Run)", "", "RRN-2026Q3-004512", "Internal", "", ""),
       ("Delivery Recipient", "Recipient of the delivery.", "Delivery", "Reference (Party)", "", "PTY-500881", "Internal", "", "", "PII"),
       ("Delivery Status", "Outcome of the delivery.", "Delivery", "Code", "Delivery Status", "Delivered", "Internal", "", "Y"),
       ("Delivered Timestamp", "When the delivery completed.", "Delivery", "Timestamp", "ISO 8601", "2026-10-13T08:00:00Z", "Internal", "", "Y"),
       ("Portal Document Reference", "Identifier of the document on the client portal (portal owned by 04).", "Delivery", "Identifier", "", "WEB-004/doc/88123", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Guideline Monitoring & Breach Reporting", "IS-GBR",
  "How compliance with each mandate's investment guidelines is monitored and certified to the client, and how breaches and regulatory threshold events are notified, cured and evidenced. The restrictions themselves are owned by 01.",
  [
   ("Monitoring Arrangement", "Client-facing guideline monitoring and certification commitments per mandate.", [
     ("Guideline Monitoring Arrangement", [
       ("Monitored Mandate", "Mandate being monitored.", "Monitoring Arrangement", "Reference (Mandate)", "", "MND-01234", "Internal", "", "Y"),
       ("Monitored Restrictions", "Restrictions monitored (owned by 01).", "Monitoring Arrangement", "Reference (Restriction) (multi)", "", "RST-55012; RST-55013", "Internal", "", ""),
       ("Breach Notification Deadline", "Contractual deadline for notifying the client of an active breach.", "Monitoring Arrangement", "Integer", "Days", "2", "Internal", "", "Y"),
       ("Consultant Notification Required Indicator", "Whether the consultant must be copied on breach notifications.", "Monitoring Arrangement", "Boolean", "", "Y", "Internal", "", ""),
       ("Compliance Certificate Frequency", "How often the firm certifies guideline compliance to the client.", "Monitoring Arrangement", "Code", "Frequency", "Quarterly", "Internal", "", "Y"),
     ]),
   ]),
   ("Breach Notification", "Client-facing record of guideline breaches and their cure.", [
     ("Breach Notification", [
       ("Breach Notification ID", "Unique identifier of the breach record.", "Breach Notification", "Identifier", "", "GBN-2026-00143", "Internal", "", "Y"),
       ("Breached Mandate", "Mandate in breach.", "Breach Notification", "Reference (Mandate)", "", "MND-01234", "Internal", "", ""),
       ("Breached Restriction", "Restriction breached (owned by 01).", "Breach Notification", "Reference (Restriction)", "", "RST-55012", "Internal", "", "Y"),
       ("Breach Type", "Whether the breach was caused by the firm's action or by market movement.", "Breach Notification", "Code", "Breach Type", "Passive", "Internal", "", "Y"),
       ("Breach Detected Date", "Date the breach was detected.", "Breach Notification", "Date", "ISO 8601", "2026-09-14", "Internal", "", ""),
       ("Client Notification Required Indicator", "Whether the breach must be notified to the client under the IMA.", "Breach Notification", "Boolean", "", "Y", "Internal", "", "Y"),
       ("Client Notified Timestamp", "When the client was notified.", "Breach Notification", "Timestamp", "ISO 8601", "2026-09-15T10:12:00Z", "Internal", "", "Y"),
       ("Cure Action", "How the breach was cured.", "Breach Notification", "Code", "Cure Action", "Sell Down", "Internal", "", ""),
       ("Cure Date", "Date the mandate was back within limits.", "Breach Notification", "Date", "ISO 8601", "2026-09-16", "Internal", "", ""),
     ]),
   ]),
   ("Certification & Threshold Notifications", "Periodic compliance certificates and regulatory threshold notifications to clients.", [
     ("Compliance Certificate", [
       ("Certificate Period End", "Period end the certificate covers.", "Certificate", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
       ("Exceptions Reported Indicator", "Whether breaches or exceptions are listed in the certificate.", "Certificate", "Boolean", "", "Y", "Internal", "", ""),
       ("Certifying Officer", "Employee who signed the certificate.", "Certificate", "Reference (Employee)", "", "EMP-03010", "Internal", "", "", "PII"),
     ]),
     ("Depreciation Notification", [
       ("Depreciation Threshold Reached", "Multiple of 10% depreciation from the start-of-period value that triggered the notice.", "Breach Notification", "Percentage", "", "10%", "MiFID II Delegated Reg 2017/565", "UK FCA COBS 16A", "Y"),
       ("Threshold Breach Date", "Business day on which the threshold was exceeded.", "Breach Notification", "Date", "ISO 8601", "2026-04-07", "MiFID II Delegated Reg 2017/565", "", ""),
       ("Depreciation Notice Sent Timestamp", "When the notice was sent (by end of that business day).", "Breach Notification", "Timestamp", "ISO 8601", "2026-04-07T17:30:00+01:00", "MiFID II Delegated Reg 2017/565", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Client Service Requests & Instructions", "IS-CSR",
  "Requests and instructions received from clients and consultants, from data requests and ad-hoc reports to contribution and withdrawal notifications, with their SLA and resolution.",
  [
   ("Service Request", "Case record for each client or consultant request.", [
     ("Client Service Request", [
       ("Service Request ID", "Unique identifier of the request.", "Service Request", "Identifier", "", "CSR-2026-018832", "Salesforce FSC", "", "Y"),
       ("Request Type", "Type of request.", "Service Request", "Code", "Service Request Type", "Ad-Hoc Report", "Salesforce FSC", "Internal", "Y"),
       ("Requesting Party", "Person or organisation that raised the request (client, consultant, auditor, custodian).", "Service Request", "Reference (Party)", "", "PTY-500881", "Internal", "", "", "PII (where an individual)."),
       ("Request Service Relationship", "Relationship the request relates to.", "Service Request", "Reference (Service Relationship)", "", "SVR-00412", "Internal", "", ""),
       ("Request Mandate", "Mandate the request relates to, if specific.", "Service Request", "Reference (Mandate)", "", "MND-01234", "Internal", "", ""),
       ("Request Received Timestamp", "When the request was received.", "Service Request", "Timestamp", "ISO 8601", "2026-09-22T09:14:00Z", "Salesforce FSC", "", ""),
       ("Request Status", "Status of the request.", "Service Request", "Code", "Request Status", "In Progress", "Salesforce FSC", "", "Y"),
       ("Request Owner", "Employee accountable for resolution.", "Service Request", "Reference (Employee)", "", "EMP-02231", "Salesforce FSC", "", "", "PII"),
       ("Request SLA Due Timestamp", "When the request must be resolved under the applicable service standard.", "Service Request", "Timestamp", "ISO 8601", "2026-09-24T17:00:00Z", "Salesforce FSC", "", "Y"),
       ("Resolution Code", "How the request was resolved.", "Service Request", "Code", "Resolution Code", "Fulfilled", "Internal", "", ""),
       ("Related Complaint", "Complaint record raised from the request, where the request is an expression of dissatisfaction (owned by 08).", "Service Request", "Reference (Complaint)", "", "CPL-2026-00412", "Internal", "", ""),
     ]),
   ]),
   ("Cash Flow Notification", "Client notifications of contributions to and withdrawals from mandates. The resulting transactions are owned by 06.", [
     ("Cash Flow Notification", [
       ("Cash Flow Notification ID", "Unique identifier of the notification.", "Cash Flow Notification", "Identifier", "", "CFN-2026-00788", "Internal", "", ""),
       ("Notified Mandate", "Mandate the flow applies to.", "Cash Flow Notification", "Reference (Mandate)", "", "MND-01234", "Internal", "", "Y"),
       ("Flow Direction", "Whether the flow is a contribution or a withdrawal.", "Cash Flow Notification", "Code", "Flow Direction", "Withdrawal", "Internal", "", "Y"),
       ("Notified Amount", "Amount notified by the client.", "Cash Flow Notification", "Amount", "", "GBP 25,000,000", "Internal", "", "Y"),
       ("Settlement Form", "Whether the flow is in cash or in specie.", "Cash Flow Notification", "Code", "Settlement Form", "Cash", "Internal", "", ""),
       ("Requested Value Date", "Date the client wants the flow to settle.", "Cash Flow Notification", "Date", "ISO 8601", "2026-09-17", "Internal", "", "Y"),
       ("Notice Period Met Indicator", "Whether the contractual notice period was met.", "Cash Flow Notification", "Boolean", "", "Y", "Internal", "", ""),
       ("Authorised Signatory", "Client signatory who authorised the instruction.", "Cash Flow Notification", "Reference (Party)", "", "PTY-500890", "Internal", "", "", "PII"),
       ("Call-Back Verification Performed", "Whether the instruction was verified by call-back to a known contact (fraud control).", "Cash Flow Notification", "Boolean", "", "Y", "Internal", "", "Y"),
       ("Linked Transaction", "Resulting contribution or withdrawal transaction (owned by 06).", "Cash Flow Notification", "Reference (Transaction)", "", "TXN-88812345", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Client Reviews & Relationship Health", "IS-CRV",
  "Formal periodic reviews and governance meetings with clients, client feedback and satisfaction, and the relationship health score used to manage retention. Sales meetings are owned by 03.",
  [
   ("Client Review Meeting", "Governance wrapper for annual reviews, trustee and investment-committee meetings and consultant review meetings.", [
     ("Client Review", [
       ("Client Review ID", "Unique identifier of the review.", "Client Review", "Identifier", "", "CRV-2026-00315", "Internal", "", ""),
       ("Review Type", "Type of review or governance meeting.", "Client Review", "Code", "Client Review Type", "Annual Review", "Internal", "", "Y"),
       ("Reviewed Relationship", "Relationship reviewed.", "Client Review", "Reference (Service Relationship)", "", "SVR-00412", "Internal", "", ""),
       ("Reviewed Mandates", "Mandates covered.", "Client Review", "Reference (Mandate) (multi)", "", "MND-01234", "Internal", "", ""),
       ("Review Held Date", "Date the review took place.", "Client Review", "Date", "ISO 8601", "2026-11-18", "Internal", "", ""),
       ("Meeting Activity", "Activity record of the meeting in CRM (owned by 03).", "Client Review", "Reference (Activity)", "", "ACT-2026-0471120", "Internal", "", ""),
       ("Review Outcome", "Overall outcome reported by the relationship lead.", "Client Review", "Code", "Review Outcome", "Satisfied", "Internal", "", ""),
     ]),
   ]),
   ("Client Feedback", "Surveys and feedback captured from clients and consultants.", [
     ("Client Feedback Response", [
       ("Feedback ID", "Unique identifier of the response.", "Feedback", "Identifier", "", "CFS-2026-01120", "Internal", "", ""),
       ("Respondent", "Person who responded.", "Feedback", "Reference (Party)", "", "PTY-500881", "Internal", "", "", "PII"),
       ("Feedback Relationship", "Relationship the feedback concerns.", "Feedback", "Reference (Service Relationship)", "", "SVR-00412", "Internal", "", ""),
       ("Likelihood to Recommend Score", "0-10 answer to the likelihood-to-recommend question.", "Feedback", "Integer", "", "9", "Net Promoter System", "", "Y"),
       ("NPS Category", "Promoter (9-10), Passive (7-8) or Detractor (0-6).", "Feedback", "Code", "NPS Category", "Promoter", "Net Promoter System", "", ""),
       ("Verbatim Comment", "Free-text comment from the respondent.", "Feedback", "Text", "", "Reporting is clear; would like earlier flash returns", "Internal", "", "", "PII possible."),
     ]),
   ]),
   ("Relationship Health", "Periodic composite score of relationship health and retention risk.", [
     ("Relationship Health Score", [
       ("Health Score Date", "Date of the score snapshot.", "Health Score", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
       ("Scored Relationship", "Relationship scored.", "Health Score", "Reference (Service Relationship)", "", "SVR-00412", "Internal", "", ""),
       ("Overall Health Score", "Composite score 0-100.", "Health Score", "Decimal", "", "72", "Internal", "", ""),
       ("Health Status", "RAG status derived from the score.", "Health Score", "Code", "RAG Status", "Amber", "Internal", "", "Y"),
       ("At-Risk Indicator", "Whether the relationship is flagged as at risk of termination or reduction.", "Health Score", "Boolean", "", "N", "Internal", "", "Y"),
       ("At-Risk Reason", "Main driver of the at-risk flag.", "Health Score", "Code", "At-Risk Reason", "Underperformance", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Mandate Operational Set-Up", "IS-MOS",
  "Operational set-up that lets a mandate be funded, traded, settled and reported: custody accounts, standing settlement instructions, cash-flow arrangements, outbound data feeds to custodians and consultants, and transition and in-specie events.",
  [
   ("Custody Account Set-Up", "Accounts opened at the client's custodian for the mandate.", [
     ("Custody Account", [
       ("Custody Account Set-Up ID", "Unique identifier of the custody set-up record.", "Custody Account", "Identifier", "", "CUA-01877", "Internal", "", ""),
       ("Client Account", "Client account the custody account belongs to (owned by 02).", "Custody Account", "Reference (Account)", "", "ACC-00720011", "Internal", "", ""),
       ("Custody Mandate", "Mandate the account services.", "Custody Account", "Reference (Mandate)", "", "MND-01234", "Internal", "", ""),
       ("Custodian", "Custodian bank (party).", "Custody Account", "Reference (Party)", "", "PTY-100912", "Internal", "", "Y"),
       ("Custodian BIC", "BIC of the custodian.", "Custody Account", "Identifier", "ISO 9362", "IRVTUS3NXXX", "ISO 9362", "", "Y"),
       ("Safekeeping Account Number", "Securities account number at the custodian.", "Custody Account", "Identifier", "", "123456-01", "SWIFT ISO 15022", "ISO 20022", "Y", "Confidential; restrict access."),
     ]),
   ]),
   ("Standing Settlement Instructions", "Effective-dated settlement instructions per mandate, market and instrument type.", [
     ("Standing Settlement Instruction", [
       ("SSI ID", "Unique identifier of the SSI.", "SSI", "Identifier", "", "SSI-0045512", "Internal", "DTCC ALERT", ""),
       ("SSI Mandate", "Mandate the SSI applies to.", "SSI", "Reference (Mandate)", "", "MND-01234", "Internal", "", "Y"),
       ("SSI Asset Class", "Asset class or instrument type the SSI covers.", "SSI", "Code", "SSI Asset Class", "Equity", "DTCC ALERT", "", "Y"),
       ("SSI Market", "Country market the SSI covers.", "SSI", "Code", "ISO 3166-1 alpha-2", "GB", "DTCC ALERT", "", "Y"),
       ("Place of Settlement", "BIC of the CSD / place of settlement (PSET).", "SSI", "Identifier", "ISO 9362", "CRSTGB22XXX", "SWIFT ISO 15022", "ISO 20022", "Y"),
       ("Settlement Agent BIC", "BIC of the receiving/delivering agent.", "SSI", "Identifier", "ISO 9362", "IRVTGB2XXXX", "SWIFT ISO 15022", "ISO 20022", "Y"),
       ("Safekeeping Account", "Safekeeping account used for settlement.", "SSI", "Reference (Custody Account)", "", "CUA-01877", "SWIFT ISO 15022", "", ""),
       ("Settlement Message Standard", "Message standard used to instruct the custodian.", "SSI", "Code", "Settlement Message Standard", "ISO 15022 MT 541/543", "SWIFT ISO 15022", "ISO 20022", ""),
       ("SSI Verification Status", "Whether the SSI has been independently verified.", "SSI", "Code", "SSI Verification Status", "Verified", "Internal", "", "Y"),
       ("SSI Effective From", "Date the SSI took effect.", "SSI", "Date", "ISO 8601", "2026-02-01", "Internal", "", ""),
     ]),
   ]),
   ("Cash Flow Arrangements", "Agreed terms for contribution and withdrawal notifications per mandate.", [
     ("Cash Flow Arrangement", [
       ("Arrangement Mandate", "Mandate the arrangement applies to.", "Cash Flow Notification", "Reference (Mandate)", "", "MND-01234", "Internal", "", ""),
       ("Notice Period Days", "Business days' notice required for flows.", "Cash Flow Notification", "Integer", "Days", "5", "Internal", "", "Y"),
       ("Notification Cut-Off Time", "Time by which a notice counts as received that day.", "Cash Flow Notification", "Time", "HH:MM + time zone", "12:00 Europe/London", "Internal", "", ""),
     ]),
   ]),
   ("Client Data Feeds", "Outbound data feeds to custodians, consultants, OCIOs and clients. Inbound feeds are owned by 06 (FEED-).", [
     ("Client Data Feed", [
       ("Client Data Feed ID", "Unique identifier of the outbound feed.", "Data Feed", "Identifier", "", "CDF-00231", "Internal", "", ""),
       ("Feed Recipient", "Organisation receiving the feed.", "Data Feed", "Reference (Party)", "", "PTY-100670", "Internal", "", "Y"),
       ("Feed Content Type", "Data sent in the feed.", "Data Feed", "Code (multi)", "Feed Content Type", "Holdings; Transactions; Performance", "Internal", "", "Y"),
       ("Feed Transport", "Transport mechanism.", "Data Feed", "Code", "Delivery Channel", "SFTP", "Internal", "", ""),
       ("Feed Frequency", "Delivery frequency.", "Data Feed", "Code", "Frequency", "Daily", "Internal", "", ""),
       ("Data-Sharing Agreement", "Agreement that permits the data sharing (owned by 05).", "Data Feed", "Reference (Agreement)", "", "AGR-01102", "Internal", "", ""),
     ]),
   ]),
   ("Transitions & In-Specie Transfers", "Events that move assets into, out of or between mandates.", [
     ("Transition Event", [
       ("Transition ID", "Unique identifier of the transition event.", "Transition", "Identifier", "", "TRN-2026-0042", "Internal", "", "Y"),
       ("Transition Type", "Type of transition.", "Transition", "Code", "Transition Type", "Transition In", "Internal", "", "Y"),
       ("Transition Mandate", "Mandate affected.", "Transition", "Reference (Mandate)", "", "MND-01240", "Internal", "", ""),
       ("Transition Manager", "Transition manager appointed, if any.", "Transition", "Reference (Party)", "", "PTY-100455", "Internal", "", ""),
       ("In-Specie Indicator", "Whether assets transfer in specie rather than in cash.", "Transition", "Boolean", "", "Y", "Internal", "", "Y"),
       ("Actual Completion Date", "Actual completion date.", "Transition", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Post-Transition Report Delivered Indicator", "Whether the post-transition cost/implementation shortfall report was delivered to the client.", "Transition", "Boolean", "", "N", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Fee Billing & Invoicing", "IS-BIL",
  "How fees for segregated mandates, SMAs/sub-advisory and other billed relationships are calculated, invoiced, collected, adjusted and disputed. Fee terms (rates, tiers, performance fee terms) are owned by 01; revenue accounting by 10.",
  [
   ("Billing Arrangement", "Billing terms applied to a mandate.", [
     ("Billing Arrangement", [
       ("Billing Arrangement ID", "Unique identifier of the billing arrangement.", "Billing Arrangement", "Identifier", "", "BLA-00655", "Internal", "", ""),
       ("Billed Mandate", "Mandate billed.", "Billing Arrangement", "Reference (Mandate)", "", "MND-01234", "Internal", "", ""),
       ("Bill-To Party", "Party invoiced (client, plan, sponsor or sub-advisory principal).", "Billing Arrangement", "Reference (Party)", "", "PTY-2201", "Internal", "", "Y"),
       ("Applied Fee Schedule", "Fee schedule applied (owned by 01).", "Billing Arrangement", "Reference (Fee Schedule)", "", "MND-01234 fee schedule v3", "Internal", "", "Y"),
       ("Billing Frequency", "How often fees are billed.", "Billing Arrangement", "Code", "Frequency", "Quarterly", "Internal", "", ""),
       ("Billing Basis", "Asset value basis used to compute the fee.", "Billing Arrangement", "Code", "Billing Basis", "Average Month-End AUM", "Internal", "", "Y"),
       ("Fee Collection Method", "Whether the fee is invoiced or deducted from the account.", "Billing Arrangement", "Code", "Fee Collection Method", "Invoice", "Internal", "", ""),
       ("Billing Currency", "Currency of invoices.", "Billing Arrangement", "Code", "ISO 4217", "GBP", "Internal", "", ""),
       ("MFN Clause Indicator", "Whether the client has a most-favoured-nation fee clause.", "Billing Arrangement", "Boolean", "", "Y", "Internal", "", "Y"),
       ("Billing Effective From", "Date the arrangement took effect.", "Billing Arrangement", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
     ]),
   ]),
   ("Invoice", "Fee invoices issued to clients.", [
     ("Fee Invoice", [
       ("Invoice ID", "Unique identifier of the invoice.", "Invoice", "Identifier", "", "BIL-2026Q3-00921", "Internal", "", "Y"),
       ("Invoice Billing Arrangement", "Arrangement the invoice was produced under.", "Invoice", "Reference (Billing Arrangement)", "", "BLA-00655", "Internal", "", ""),
       ("Billing Period Start", "First day of the billed period.", "Invoice", "Date", "ISO 8601", "2026-07-01", "Internal", "", ""),
       ("Billing Period End", "Last day of the billed period.", "Invoice", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
       ("Billable Assets", "Asset value used for the fee.", "Invoice", "Amount", "", "GBP 612,400,000", "Internal", "", "Y"),
       ("Management Fee Amount", "Management fee billed.", "Invoice", "Amount", "", "GBP 643,020", "Internal", "", ""),
       ("Performance Fee Amount", "Performance fee billed.", "Invoice", "Amount", "", "GBP 0", "Internal", "", ""),
       ("Invoice Total", "Total amount due.", "Invoice", "Amount", "", "GBP 631,020", "Internal", "", "Y"),
       ("Invoice Date", "Date the invoice was issued.", "Invoice", "Date", "ISO 8601", "2026-10-10", "Internal", "", ""),
       ("Payment Status", "Status of payment.", "Invoice", "Code", "Payment Status", "Paid", "Internal", "", "Y"),
     ]),
   ]),
   ("Performance Fee Calculation", "Period calculations of performance fees for mandates.", [
     ("Performance Fee Calculation", [
       ("Calculation Period End", "End of the performance measurement period.", "Performance Fee Calc", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
       ("Hurdle Benchmark", "Benchmark used as the hurdle (owned by 01).", "Performance Fee Calc", "Reference (Benchmark)", "", "BMK-0001", "Internal", "ESMA Performance Fee Guidelines", ""),
       ("High-Water Mark Value", "High-water mark in force for the period.", "Performance Fee Calc", "Amount", "", "GBP 598,000,000", "Internal", "ESMA Performance Fee Guidelines", ""),
       ("Calculated Performance Fee", "Fee calculated before caps.", "Performance Fee Calc", "Amount", "", "GBP 1,240,000", "Internal", "", "Y"),
       ("Crystallised Indicator", "Whether the fee crystallised in the period.", "Performance Fee Calc", "Boolean", "", "Y", "ESMA Performance Fee Guidelines", "", ""),
       ("Calculation Approved By", "Employee who approved the calculation.", "Performance Fee Calc", "Reference (Employee)", "", "EMP-04120", "Internal", "", "", "PII"),
     ]),
   ]),
   ("Adjustments, Rebates & Disputes", "Credits, rebates, MFN true-ups and fee disputes.", [
     ("Fee Adjustment", [
       ("Adjustment Type", "Type of adjustment.", "Fee Adjustment", "Code", "Fee Adjustment Type", "MFN True-Up", "Internal", "", "Y"),
       ("Adjusted Invoice", "Invoice the adjustment applies to.", "Fee Adjustment", "Reference (Invoice)", "", "BIL-2026Q3-00921", "Internal", "", ""),
       ("Adjustment Amount Value", "Amount of the adjustment (negative = credit).", "Fee Adjustment", "Amount", "", "GBP -12,000", "Internal", "", ""),
     ]),
     ("Billing Dispute", [
       ("Billing Dispute ID", "Unique identifier of the dispute.", "Billing Dispute", "Identifier", "", "BDP-2026-0021", "Internal", "", ""),
       ("Disputed Invoice", "Invoice disputed.", "Billing Dispute", "Reference (Invoice)", "", "BIL-2026Q2-00877", "Internal", "", ""),
       ("Dispute Reason", "Reason given by the client.", "Billing Dispute", "Code", "Dispute Reason", "Asset Value Disagreement", "Internal", "", ""),
       ("Disputed Amount", "Amount in dispute.", "Billing Dispute", "Amount", "", "GBP 8,400", "Internal", "", ""),
       ("Dispute Status", "Status of the dispute.", "Billing Dispute", "Code", "Request Status", "Resolved", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Termination & Offboarding", "IS-TRM",
  "Ending a mandate or relationship: notice, transition out, final reporting and billing, and records retention.",
  [
   ("Termination", "Termination notice and offboarding checklist for a mandate.", [
     ("Mandate Termination", [
       ("Termination ID", "Unique identifier of the termination.", "Termination", "Identifier", "", "TRM-2026-0009", "Internal", "", ""),
       ("Terminated Mandate", "Mandate terminated.", "Termination", "Reference (Mandate)", "", "MND-01120", "Internal", "", "Y"),
       ("Termination Scope", "Whether the termination is full or partial.", "Termination", "Code", "Termination Scope", "Full", "Internal", "", ""),
       ("Notice Received Date", "Date written notice was received.", "Termination", "Date", "ISO 8601", "2026-07-31", "Internal", "", "Y"),
       ("Termination Reason", "Main reason for the termination.", "Termination", "Code", "Termination Reason", "Asset Allocation Change", "Internal", "", "Y"),
       ("Effective Termination Date", "Date management ceases.", "Termination", "Date", "ISO 8601", "2026-08-31", "Internal", "", "Y"),
       ("Transition-Out Event", "Transition event moving the assets out.", "Termination", "Reference (Transition)", "", "TRN-2026-0039", "Internal", "", ""),
       ("Final Report Run", "Final report delivered to the client.", "Termination", "Reference (Report Run)", "", "RRN-2026M08-003311", "Internal", "", ""),
       ("Final Invoice", "Final pro-rated invoice.", "Termination", "Reference (Invoice)", "", "BIL-2026Q3-00930", "Internal", "", ""),
       ("Records Retention End Date", "Date until which client records must be retained.", "Termination", "Date", "ISO 8601", "2033-08-31", "SEC Rule 204-2", "UK FCA SYSC 9", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Servicing Data Management", "IS-DMG",
  "Metadata applied to every record in the institutional servicing and reporting domain.",
  [
   ("Data Management Metadata", "Ownership, lineage and quality metadata for each record.", [
     ("Record Metadata", [
       ("Data Owner", "Business role accountable for the data element.", "All", "Reference (Party)", "", "Head of Client Service", "DCAM (EDM Council)", "", ""),
       ("Data Steward", "Role responsible for day-to-day data quality.", "All", "Reference (Party)", "", "Client Reporting Data Steward", "DCAM (EDM Council)", "", ""),
       ("System of Record", "System holding the authoritative value.", "All", "Code", "Firm-defined", "Client Reporting Platform", "Internal", "", ""),
       ("Record Effective From", "Business-effective start date of the record version.", "All", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Last Updated Timestamp", "System timestamp of the last change.", "All", "Timestamp", "ISO 8601", "2026-09-30T17:45:00Z", "Internal", "", ""),
       ("Data Quality Status", "Validation status of the record.", "All", "Code", "Data Quality Status", "Validated", "Internal", "", ""),
       ("Confidentiality Classification", "Information classification of the record (client-confidential data such as SSIs and fees).", "All", "Code", "Confidentiality Classification", "Client Confidential", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Servicing Segment": ("Internal", [("Institutional - Segregated Mandate",""),("Institutional - Pooled Vehicle","CIT, QIAIF, LP or other pooled vehicle held by an institution"),("Sub-Advisory",""),("SMA / UMA Sponsor","Separately managed account programme at a wealth platform"),("Model Delivery Client","Platform or sponsor receiving models"),("DCIO Plan",""),("OCIO / Fiduciary Manager","Client is an OCIO investing for underlying clients"),("Private Fund Investor","LP in a private markets fund")]),
 "Service Tier": ("Internal", [("Tier 1 - Strategic",""),("Tier 2 - Core",""),("Tier 3 - Standard",""),("Tier 4 - Digital / Pooled","Mainly self-service via portal")]),
 "Service Relationship Status": ("Internal", [("Onboarding",""),("Active",""),("Under Notice","Termination notice received"),("Terminated",""),("Dormant","No assets, relationship retained")]),
 "Frequency": ("Internal (harmonise with 09)", [("Daily",""),("Weekly",""),("Monthly",""),("Quarterly",""),("Semi-Annual",""),("Annual",""),("Ad Hoc",""),("On Event","")]),
 "Service Standard Metric": ("Internal", [("Report Delivery Timeliness",""),("Request Response Time",""),("Request Resolution Time",""),("Breach Notification Time",""),("Meeting Cadence Adherence",""),("Report Accuracy","Share of reports delivered without restatement"),("Invoice Timeliness","")]),
 "SLA Unit": ("Internal", [("Business Days After Period End",""),("Business Hours",""),("Business Days",""),("Calendar Days",""),("Percent","")]),
 "Service Role": ("Internal", [("Client Service Manager","Day-to-day relationship and service lead"),("Client Portfolio Manager / Investment Specialist","Represents the investment team to the client"),("Relationship Manager","Commercial relationship owner (EMP- in 03)"),("Reporting Analyst",""),("Client Onboarding Specialist",""),("Billing Analyst",""),("Investment Operations Contact","Settlement, SSI and cash flow contact"),("Client Service Associate","")]),
 "Report Type": ("Internal", [("Monthly Valuation Report",""),("Quarterly Investment Report",""),("Performance Report",""),("Holdings / Valuation Statement",""),("Transaction Statement",""),("Performance Attribution Report",""),("Risk Report",""),("ESG / Climate Report",""),("Stewardship / Voting Report",""),("Compliance Certificate",""),("Capital Account Statement","Pooled / private fund"),("Consultant Data Pack","Standard data for consultant monitoring"),("Cost & Charges Statement","MiFID ex-post costs / CTI"),("Fee Invoice Backup",""),("Flash Return","Early estimate after period end"),("Liability / LDI Report",""),("Transition Report","")]),
 "Report Scope Level": ("Internal", [("Mandate",""),("Client Relationship",""),("Pooled Fund",""),("Share Class / Investor Holding",""),("Model / SMA Programme","")]),
 "Report Customisation": ("Internal", [("Standard",""),("Standard with Client Options",""),("Bespoke","")]),
 "Reporting Driver": ("Internal", [("Client IMA / Contract",""),("MiFID II Periodic Statement","Quarterly statement for portfolio management"),("MiFID II Ex-Post Costs",""),("GIPS",""),("ILPA",""),("UK CTI",""),("UK Stewardship Code",""),("Solvency II Look-Through","Insurer clients"),("SFDR / TCFD","")]),
 "Report Component Type": ("Internal", [("Cover & Contents",""),("Market Commentary",""),("Portfolio Commentary",""),("Performance Summary",""),("Performance Attribution",""),("Holdings",""),("Sector / Country Exposure",""),("Transactions",""),("Risk Statistics",""),("ESG Metrics",""),("Voting & Engagement",""),("Cash Flows",""),("Fees & Costs",""),("Guideline Compliance",""),("GIPS Disclosures",""),("Regulatory Disclosures","")]),
 "Report Output Format": ("Internal", [("PDF",""),("Excel",""),("CSV",""),("XML",""),("Interactive Portal View",""),("API / JSON","")]),
 "Branding Type": ("Internal", [("Firm Brand",""),("Co-Branded",""),("White-Label","Sponsor or sub-advisory client brand"),("Unbranded Data","")]),
 "Consolidation Level": ("Internal", [("By Mandate",""),("Consolidated",""),("Consolidated and by Mandate","")]),
 "Return Methodology": ("GIPS", [("Time-Weighted",""),("Money-Weighted (IRR)",""),("Both","")]),
 "Fee Basis": ("GIPS", [("Gross of Fees",""),("Net of Fees",""),("Gross and Net","")]),
 "Return Period": ("GIPS / Internal", [("MTD",""),("QTD",""),("YTD",""),("1Y",""),("3Y",""),("5Y",""),("10Y",""),("Since Inception",""),("Calendar Years","")]),
 "Net Fee Treatment": ("GIPS", [("Actual Fees",""),("Model Fees",""),("Highest Fee","")]),
 "Holdings Detail Level": ("Internal", [("Full Holdings",""),("Top 10",""),("Exposures Only",""),("None","")]),
 "Look-Through Template": ("Industry", [("Solvency II TPT","Tripartite Template for insurers"),("Firm Look-Through File",""),("None","")]),
 "GIPS Report Type": ("GIPS", [("Composite Time-Weighted Return Report",""),("Composite Money-Weighted Return Report",""),("Pooled Fund Time-Weighted Return Report",""),("Pooled Fund Money-Weighted Return Report","")]),
 "GIPS Disclosure Item": ("GIPS", [("Compliance Statement",""),("Composite Description",""),("Benchmark Description",""),("Fee Schedule",""),("Number of Portfolios",""),("Composite Assets",""),("Total Firm Assets",""),("Internal Dispersion",""),("3Y Ex-Post Std Dev",""),("Composite Inception and Creation Dates",""),("Policies Available on Request","")]),
 "ILPA Template Version": ("ILPA", [("2016","Original Reporting Template"),("2025","Updated Reporting Template, adoption from Q1 2026")]),
 "ILPA Performance Methodology": ("ILPA", [("Granular",""),("Gross-Up","")]),
 "CTI Template Type": ("CTI (Pensions UK / IA)", [("Account Template",""),("Private Markets Sub-Template",""),("Fiduciary Management Template",""),("LDI Template","Preliminary"),("User Summary","")]),
 "Stewardship Content": ("UK Stewardship Code / Internal", [("Voting Record",""),("Engagement Case Studies",""),("Escalation Activity",""),("Policy and Context",""),("Outcomes","")]),
 "Production Status": ("Internal", [("Scheduled",""),("Data Pending",""),("In Production",""),("In Review",""),("Signed Off",""),("Delivered",""),("Restated",""),("Cancelled","")]),
 "Restatement Reason": ("Internal", [("Pricing Correction",""),("Transaction Correction",""),("Benchmark Correction",""),("Fee Correction",""),("Methodology Change",""),("Client Request","")]),
 "Delivery Channel": ("Internal", [("Client Portal",""),("Email",""),("Secure Email",""),("SFTP",""),("API",""),("Consultant Database Feed",""),("Post",""),("Data Vendor Platform","")]),
 "Delivery Status": ("Internal", [("Pending",""),("Delivered",""),("Opened","Portal or tracked email"),("Failed",""),("Recalled","")]),
 "Breach Type": ("Internal", [("Active","Caused by a firm action, e.g. a trade"),("Passive","Caused by market movement or a corporate action"),("Technical","Data or coding error, no actual exposure")]),
 "Cure Action": ("Internal", [("Sell Down",""),("Purchase",""),("Client Waiver",""),("Guideline Amended",""),("Self-Cured by Market","")]),
 "Service Request Type": ("Internal / Salesforce FSC", [("Data Request",""),("Ad-Hoc Report",""),("Cash Flow Notification",""),("Rebalancing Instruction",""),("Guideline Change",""),("Audit Confirmation",""),("Fee Query",""),("Contact / Signatory Update",""),("Portal Access",""),("Proxy Voting Query",""),("Consultant Questionnaire","Operational queries outside RFP/DDQ")]),
 "Request Status": ("Salesforce FSC", [("New",""),("In Progress",""),("Waiting on Client",""),("Escalated",""),("Resolved",""),("Closed",""),("Cancelled","")]),
 "Resolution Code": ("Internal", [("Fulfilled",""),("Partially Fulfilled",""),("Declined",""),("Duplicate",""),("Referred to Complaint","")]),
 "Flow Direction": ("Internal", [("Contribution",""),("Withdrawal","")]),
 "Settlement Form": ("Internal", [("Cash",""),("In Specie",""),("Mixed","")]),
 "Client Review Type": ("Internal", [("Annual Review",""),("Quarterly Review",""),("Trustee / Board Meeting",""),("Investment Committee Meeting",""),("Consultant Review Meeting",""),("Onsite Visit by Client","")]),
 "Review Outcome": ("Internal", [("Satisfied",""),("Concerns Raised",""),("Mandate Under Review",""),("Expansion Discussed","Hand off to 03 as opportunity")]),
 "NPS Category": ("Net Promoter System", [("Promoter","9-10"),("Passive","7-8"),("Detractor","0-6")]),
 "RAG Status": ("Internal", [("Red",""),("Amber",""),("Green","")]),
 "At-Risk Reason": ("Internal", [("Underperformance",""),("Personnel Change",""),("Service Issues",""),("Client Strategy Change",""),("Fee Pressure",""),("Consultant Rating Change","")]),
 "SSI Asset Class": ("DTCC ALERT / Internal", [("Equity",""),("Fixed Income",""),("Cash / FX",""),("Listed Derivatives",""),("OTC Collateral",""),("Funds","")]),
 "Settlement Message Standard": ("SWIFT / ISO", [("ISO 15022 MT 540/542","Free of payment"),("ISO 15022 MT 541/543","Against payment"),("ISO 20022 sese.023",""),("Proprietary / Portal","")]),
 "SSI Verification Status": ("Internal", [("Unverified",""),("Verified",""),("Rejected","")]),
 "Feed Content Type": ("Internal", [("Holdings",""),("Transactions",""),("Performance",""),("Valuations",""),("Analytics / Risk",""),("Characteristics","")]),
 "Transition Type": ("Internal", [("Initial Funding",""),("Transition In",""),("Transition Out",""),("Restructure",""),("Manager Replacement","")]),
 "Billing Basis": ("Internal", [("Average Daily AUM",""),("Average Month-End AUM",""),("Period-End AUM",""),("Beginning-of-Period AUM",""),("Committed Capital",""),("Fixed Fee","")]),
 "Fee Collection Method": ("Internal", [("Invoice",""),("Deducted from Account",""),("Paid by Sponsor","SMA/UMA programme or sub-advisory")]),
 "Payment Status": ("Internal", [("Issued",""),("Partially Paid",""),("Paid",""),("Overdue",""),("Disputed",""),("Written Off","")]),
 "Fee Adjustment Type": ("Internal", [("MFN True-Up",""),("Rebate",""),("Credit Note",""),("Fee Waiver",""),("Error Correction","")]),
 "Dispute Reason": ("Internal", [("Asset Value Disagreement",""),("Rate Applied Incorrectly",""),("Period Error",""),("Performance Fee Calculation",""),("MFN Claim","")]),
 "Termination Scope": ("Internal", [("Full",""),("Partial","")]),
 "Termination Reason": ("Internal", [("Underperformance",""),("Asset Allocation Change",""),("Move to Passive",""),("Consultant Recommendation",""),("Fees",""),("Organisational Change at Firm",""),("Client Merger / Consolidation",""),("Strategy Closed","")]),
 "Data Quality Status": ("Internal", [("Validated",""),("Pending Validation",""),("Failed Validation",""),("Stale","")]),
 "Confidentiality Classification": ("Internal", [("Public",""),("Internal",""),("Client Confidential",""),("Restricted","")]),
}

# ---------------------------------------------------------------------------
REL = [
 ("Service Relationship","services","Party (Client) [02]","n : 1","Client is PTY- in 02."),
 ("Service Relationship","covers","Investment Mandate [01]","1 : 1..n","Pooled holdings are referenced as Product / Share Class [01]."),
 ("Service Relationship","is advised by","Party (Consultant) [02]","n : 0..1","Copied from the 02 Consultant Advisory Relationship at set-up; 02 remains the master."),
 ("Service Relationship","is assigned","Service Tier","n : 1","Effective-dated."),
 ("Service Tier / Service Relationship","is governed by","Service Standard","1 : 0..n",""),
 ("Service Coverage Assignment","assigns","Sales Employee [03]","n : 1","EMP- master owned by 03; distinct from 07 sales coverage assignments (CVA-)."),
 ("Service Relationship","is covered by","Service Coverage Assignment","1 : 1..n","At least a Client Service Manager."),
 ("Report Definition","is composed of","Report Component","1 : 1..n","Ordered."),
 ("Report Definition","is rendered with","Report Template","n : 1",""),
 ("Report Template","applies","Brand [04]","n : 1",""),
 ("Report Package","includes","Report Definition","n : 1..n",""),
 ("Report Package","is presented per","Performance Presentation Profile","1 : 1..n",""),
 ("Performance Presentation Profile","shows","Benchmark [01]","n : 1..n",""),
 ("Report Definition","discloses","GIPS Composite [01]","n : 0..1",""),
 ("Report Package","is produced as","Report Run","1 : 0..n","One run per period and version."),
 ("Report Run","is delivered to","Distribution List","n : 1..n",""),
 ("Distribution List","uses","Contact Point [02]","n : 1",""),
 ("Report Delivery","is published on","Digital Property [04]","n : 0..1","Client portal."),
 ("Report Run","may be reviewed by","Compliance Review [08]","1 : 0..1",""),
 ("Guideline Monitoring Arrangement","monitors","Investment Restriction [01]","1 : 1..n",""),
 ("Breach Notification","concerns","Investment Restriction [01]","n : 1",""),
 ("Service Request","may raise","Complaint [08]","1 : 0..1",""),
 ("Cash Flow Notification","results in","Transaction [06]","1 : 0..n",""),
 ("Client Review","is held as","Sales Activity [03]","1 : 0..1",""),
 ("Client Review","may originate","Opportunity [03]","1 : 0..n","Expansion discussed -> hand-off to sales."),
 ("Custody Account","belongs to","Account [02]","n : 1",""),
 ("Custody Account","is held at","Party (Custodian) [02]","n : 1",""),
 ("Standing Settlement Instruction","settles via","Custody Account","n : 1",""),
 ("Client Data Feed","is permitted by","Agreement [05]","n : 0..1",""),
 ("Billing Arrangement","applies","Fee terms [01]","n : 1","Versioned fee schedule."),
 ("Billing Arrangement","produces","Fee Invoice","1 : 0..n",""),
 ("Fee Invoice","is recognised as","Revenue record [10]","1 : 0..n","Revenue accounting owned by 10."),
 ("Fee Invoice","may be subject to","Billing Dispute","1 : 0..n",""),
 ("Mandate Termination","triggers","Transition Event","1 : 0..1",""),
 ("Mandate Termination","closes","Investment Mandate [01]","n : 1","01 sets mandate lifecycle status."),
]

# ---------------------------------------------------------------------------
SRC = [
 ("GIPS Standards for Firms (2020) and GIPS Handbook","CFA Institute","https://www.gipsstandards.org/standards/gips-standards-for-firms/","Free","Composite and pooled fund reports, required numerical information and disclosures (Sections 4-7), 12-month update requirement (1.A.16), gross/net and TWR/MWR presentation","Performance & Holdings Presentation, GIPS Disclosure Requirements, Restatements",["GIPS"]),
 ("ILPA Reporting Template and Performance Template (2025)","Institutional Limited Partners Association","https://ilpa.org/industry-guidance/templates-standards-model-documents/reporting-template","Free","Private fund fee, expense and performance reporting to LPs; adoption from Q1 2026","Industry Reporting Templates (private fund clients)",["ILPA*"]),
 ("Cost Transparency Initiative (CTI) templates","Pensions UK, The Investment Association, LGPS Advisory Board","https://www.pensionsuk.org.uk/cti","Free, open source","Account, Private Markets, Fiduciary Management and LDI cost templates for UK pension schemes","Industry Reporting Templates, Cost & Charges reporting",["CTI"]),
 ("MiFID II Delegated Regulation (EU) 2017/565, Articles 60-62","European Union","https://eur-lex.europa.eu/eli/reg_del/2017/565/oj","Regulation","Periodic statements for portfolio management, ex-post costs, 10% depreciation notification","Report Definition regulatory drivers, Depreciation Notification",["MiFID II*"]),
 ("UK FCA Handbook COBS 16A and SYSC 9","UK FCA","https://www.handbook.fca.org.uk/handbook/COBS/16A/","Regulation","UK onshored periodic reporting and depreciation reporting; record-keeping","Depreciation Notification, Records Retention",["UK FCA*"]),
 ("UK Stewardship Code 2026","Financial Reporting Council","https://www.frc.org.uk/library/standards-codes-policy/stewardship/","Voluntary code","Policy and Context Disclosure and Activities and Outcomes Report for asset managers","Stewardship Report Scope",["UK Stewardship Code"]),
 ("SWIFT ISO 15022 MT 540-548 and MT 670/671 (SSI)","SWIFT","https://www.swift.com/standards/iso-15022","Standard (SWIFT member access for full specs)","Securities settlement instructions and SSI update notifications","Standing Settlement Instructions",["SWIFT ISO 15022"]),
 ("ISO 20022 sese.023 Securities Settlement Transaction Instruction","ISO / SWIFT","https://www.iso20022.org","Open standard","ISO 20022 settlement instruction message","Standing Settlement Instructions",["ISO 20022"]),
 ("DTCC ALERT (SSI database)","DTCC","https://www.dtcc.com/settlement-and-asset-services/settlement-instructions/alert","Commercial service","Global standing settlement instruction database for investment managers, brokers and custodians","SSI Source, SSI Asset Class",["DTCC ALERT"]),
 ("ISO 9362 (BIC), ISO 13616 (IBAN), ISO 4217, ISO 3166, ISO 639, ISO 8601","ISO / SWIFT","https://www.iso.org","Standard; code lists widely available","Bank identifiers, account numbers and reference code lists","Custody Account, SSI, reference formats",["ISO 9362"]),
 ("Salesforce Financial Services Cloud / Service Cloud Case object","Salesforce","https://developer.salesforce.com/docs/atlas.en-us.object_reference.meta/object_reference/sforce_api_objects_case.htm","Proprietary documentation (public)","Case status, priority, origin, SLA/entitlement fields","Service Request model",["Salesforce FSC"]),
 ("Solvency II Tripartite Template (TPT)","FinDatEx","https://findatex.eu","Free template","Look-through holdings data for insurer clients","Look-Through Presentation",["Solvency II TPT"]),
 ("ESMA Guidelines on performance fees in UCITS and certain AIFs","ESMA","https://www.esma.europa.eu","Guidance","Hurdle, high-water mark and crystallisation concepts (used by analogy for mandates)","Performance Fee Calculation",["ESMA*"]),
 ("SEC Marketing Rule 206(4)-1 and Books and Records Rule 204-2","US SEC","https://www.sec.gov/rules-regulations/2020/12/investment-adviser-marketing","Regulation","Gross/net presentation in advertisements; record retention","Fee Basis Shown, Compliance Review, Records Retention",["SEC*"]),
 ("Net Promoter System","Bain & Company","https://www.netpromotersystem.com","Proprietary methodology (public description)","Likelihood-to-recommend scoring and categories","Client Feedback",["Net Promoter System"]),
 ("ITIL 4 Service Level Management","PeopleCert / AXELOS","https://www.axelos.com","Licensed framework","Service level definitions and measurement","Service Standards",["ITIL"]),
 ("DCAM","EDM Council","https://edmcouncil.org","Member framework","Data ownership and stewardship","Data Management Metadata",["DCAM*"]),
]
