"""Business domain 13 - Investor Servicing & Shareholder Communications. Content module for taxonomy_builder.py."""

META = {
 "title": "Investor Servicing & Shareholder Communications Data Taxonomy",
 "subtitle": "Business domain 13 - Investor Servicing & Shareholder Communications | Asset manager (wholesale distributor) | Scope: US + EU/UK | Draft v0.1 | 2026-10-01",
 "output": "13_Investor_Servicing_and_Shareholder_Communications/Investor_Servicing_and_Shareholder_Communications_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the investor servicing and shareholder communications data of an asset manager whose funds are mostly held through intermediaries (omnibus / street name, platforms, nominees), with a smaller book of direct, networked and retirement accounts registered at an outsourced transfer agent (e.g. SS&C/DST, BNY, Computershare, Northern Trust). It covers what the fund and its TA must do for shareholders (service requests, statements, confirmations, tax forms, regulatory reports, notices, proxies, escheatment) and how the asset manager oversees that work. It draws on SEC rules (Rule 30e-1 and Form N-CSR tailored shareholder reports, Rules 154, 498, 10b-10, 14a-13, 14b-1, 17Ad-17), SEC e-delivery guidance, IRS information-return rules, NYSE Rule 451 / FINRA Rule 2251, US state unclaimed property law (NAUPA), the UCITS Directive, FCA COLL and the UK Dormant Assets Scheme."),
  ("Scope", "In scope: shareholder service requests (SRQ-) and contact-centre interactions for direct and TA-serviced accounts, standing account instructions (systematic plans, distribution options), quality checks; statements, trade confirmations and tax documents (STMT-) and their production and delivery; regulatory shareholder communications (COMM-): tailored shareholder reports, prospectus / summary prospectus and KID/KIID delivery, notices of mergers, liquidations, name and objective changes, UCITS and COLL change notices; e-delivery and householding elections; proxy solicitation and fund shareholder meetings (PRX-); beneficial-owner communications via intermediaries (Broadridge, platforms, nominees) and their fees; lost shareholders, escheatment, unclaimed property and UK dormant assets; TA and servicing-vendor oversight, SLAs, servicing errors and shareholder remediation (as-of / NAV error compensation). Out of scope (referenced by ID): parties, accounts, account party roles, contact points, consent legal basis and tax certification (02 Client & Customer); product documents, share classes and lifecycle events such as mergers (01 Product); transactions, positions and correction transactions (06 Sales Transactions & AUM Attribution); complaints, marketing-communication approval and records retention (08 Distribution Compliance); sub-TA, networking and other contractual intermediary payments (05 Distribution Agreements & Partners); accounting for servicing costs (10 Distribution Finance); institutional client reporting and service requests (12 Institutional Client Servicing); the asset manager voting proxies of portfolio companies (investment stewardship, not in this programme)."),
  ("Structure", "Four levels: Domain > Subdomain > Concept > Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Account (02, ACC-) and Party (02, PTY-) -> Service Request (SRQ-) / Contact Centre Interaction (CCI-) -> resulting Transaction (06, TXN-) or change to 02 records. Document Definition -> Production Run (PRUN-) -> Investor Document (STMT-: statement, confirmation, tax form). Product Document or Lifecycle Event (01) -> Shareholder Communication (COMM-) -> Communication Distribution (MAIL-) to registered holders and Intermediary Distribution Request (BOD-) to beneficial owners, governed by Delivery Elections (DEL-). Proxy Campaign (PRX-) -> Proposals (PRP-) -> Vote Tallies. Account -> Lost Shareholder Status -> Dormancy Assessment -> Escheatment Report (ESC-) / UK Reclaim Fund transfer -> Reclaim. Servicing Provider -> SLA (SLA-) -> Measurements; Servicing Error (ERR-) -> Shareholder Remediation (RMD-)."),
  ("Design principles", "1) Servicing records reference parties, accounts, products and transactions by ID; they never copy master data (an address change request updates the 02 contact point, it does not hold the address). 2) Record each regulatory deadline as a date with the rule that drives it, so timeliness can be measured. 3) Separate the communication (what), the distribution (to whom, how, when) and the recipient delivery outcome. 4) Treat registered holders and beneficial owners as two delivery paths for the same communication. 5) Effective-date elections, instructions and statuses. 6) Flag personal data (PII) and keep TINs masked. 7) The asset manager oversees outsourced servicing: every record carries the servicing provider so SLAs and errors can be attributed."),
  ("Applies To", "Shows the record type each attribute is held on: Service Request, Interaction, QA Review, Standing Instruction, Document Definition, Investor Document, Confirmation, Tax Form, Cost Basis Election, Production Run, Communication, Distribution, Recipient Delivery, Delivery Election, Householding Group, Proxy Campaign, Proposal, Vote Tally, Intermediary Distribution, Fee Invoice, Lost Shareholder Status, Dormancy Assessment, Escheatment Report, Reclaim, Servicing Provider, SLA, SLA Measurement, Servicing Error, Remediation or All."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify a servicing record, meet a regulatory delivery or reporting deadline, prove delivery or consent, determine escheatment, establish a proxy quorum or outcome, or quantify shareholder harm and compensation. Confirm with data owners (Fund Operations / TA Oversight, Fund Administration, Legal, Tax, Compliance)."),
  ("Primary / Secondary Reference", "Standard or rule the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Vendor references (SS&C DST, Broadridge) indicate common industry practice and record layouts that are licensed or member-only; verify field mapping with the TA."),
  ("Tabs", "Hierarchy: domains, subdomains and concepts with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: concept-level cardinalities for the logical model, including cross-domain references | Sources: rules, standards and vendor sources used, with links."),
  ("Suggested next steps", "1) Validate domains, CDEs and deadlines with Fund Operations / TA Oversight, Fund Legal, Fund Tax, Compliance and the TA relationship managers. 2) Map attributes to TA record layouts (e.g. SS&C DST TA2000 / NSCC Networking files, Computershare / Northern Trust register extracts) and to Broadridge job reports. 3) Agree with 02 who owns e-delivery and householding elections versus consent legal basis, and with 01 how Product Documents link to COMM- records. 4) Load the state-by-state dormancy and due-diligence rule table from the TA's escheatment vendor. 5) Agree SLA definitions and the NAV-error / as-of policy thresholds with the Board-approved policy. 6) Turn the Relationships tab into a logical data model."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Shareholder Service Requests & Interactions", "SV-SRQ",
  "Requests from shareholders, their representatives and intermediaries to change or act on a direct or TA-serviced account, the contact-centre interactions in which they arise, standing account instructions and quality checks. Complaints are owned by 08 Distribution Compliance.",
  [
   ("Service Request", "One request to service an account, from intake through good-order review to completion (SRQ- master).", [
     ("Service Request", [
       ("Service Request ID", "Unique identifier of the service request.", "Service Request", "Identifier", "", "SRQ-2026-0081245", "Internal", "", "Y"),
       ("Request Type", "Business type of the request.", "Service Request", "Code", "Service Request Type", "Address Change", "Internal", "SS&C DST", "Y"),
       ("Account", "Account the request relates to.", "Service Request", "Reference (Account)", "", "ACC-0049812", "Internal", "", "Y", "PII when held by individuals."),
       ("Requesting Party", "Party who made the request (shareholder, representative or intermediary).", "Service Request", "Reference (Party)", "", "PTY-500771", "Internal", "", "", "PII"),
       ("Requester Role", "Capacity in which the requester acts on the account.", "Service Request", "Code", "Requester Role", "Executor / Administrator", "Internal", "", ""),
       ("Intake Channel", "Channel through which the request was received.", "Service Request", "Code", "Service Channel", "Mail", "Internal", "", ""),
       ("Received Timestamp", "Date and time the request was received in good or not-in-good order; starts SLA timing.", "Service Request", "Timestamp", "ISO 8601", "2026-09-14T10:22:00-04:00", "Internal", "SEC Rule 17Ad-2", "Y", "Transfer-agent turnaround rules apply to some item types."),
       ("Servicing Provider", "Transfer agent or servicer processing the request.", "Service Request", "Reference (Party)", "", "PTY-100990", "Internal", "", "Y"),
       ("Good Order Status", "Whether the request has everything needed to process it.", "Service Request", "Code", "Good Order Status", "Not In Good Order", "Internal", "SS&C DST", "Y"),
       ("NIGO Reason", "Reason(s) the request is not in good order.", "Service Request", "Code (multi)", "NIGO Reason", "Missing Medallion Signature Guarantee", "Internal", "", ""),
       ("Request Status", "Current processing status.", "Service Request", "Code", "Service Request Status", "Completed", "Internal", "", ""),
       ("Completed Timestamp", "Date and time processing was completed.", "Service Request", "Timestamp", "ISO 8601", "2026-09-19T15:05:00-04:00", "Internal", "", "Y"),
       ("Resulting Transaction", "Transaction(s) created by the request (e.g. transfer, redemption).", "Service Request", "Reference (Transaction) (multi)", "", "TXN-2026-000418273", "Internal", "", ""),
       ("Escalated Complaint", "Complaint record raised when the requester expressed dissatisfaction.", "Service Request", "Reference (Complaint)", "", "CPL-2026-000418", "Internal", "FCA DISP", "", "Complaint handling owned by 08."),
     ]),
     ("Request Controls", [
       ("Signature Guarantee Type", "Signature guarantee or verification provided, where required.", "Service Request", "Code", "Signature Guarantee Type", "Medallion (STAMP)", "SEC Rule 17Ad-15", "", ""),
     ]),
   ]),
   ("Request Type Detail", "Additional data captured for specific request types. The resulting master data changes are made in 02 Client & Customer.", [
     ("Account Maintenance Change", [
       ("Maintained Data Element", "Account or party data element changed by the request.", "Service Request", "Code", "Maintained Data Element", "Mailing Address", "Internal", "", ""),
       ("Updated Master Record", "02 record (contact point, account role, account) updated as a result.", "Service Request", "Reference (Party / Account)", "", "ACC-0049812", "Internal", "", "", "The value itself is held in 02, not here."),
     ]),
     ("Transfer of Ownership & Estate", [
       ("Ownership Transfer Reason", "Reason for the re-registration or transfer of ownership.", "Service Request", "Code", "Ownership Transfer Reason", "Death of Owner", "Internal", "", ""),
       ("Decedent", "Party who has died, for estate and death claims.", "Service Request", "Reference (Party)", "", "PTY-500771", "Internal", "", "", "PII"),
       ("Date of Death", "Date of death as evidenced by the death certificate.", "Service Request", "Date", "ISO 8601", "2026-07-02", "Internal", "", "", "PII. Sets the 02 Deceased Indicator; may drive cost-basis step-up."),
       ("Estate Documents Outstanding", "Documents still needed to settle the claim.", "Service Request", "Code (multi)", "Estate Document Type", "Letters Testamentary", "Internal", "", ""),
       ("Beneficiary Allocation Percentage", "Share of the account assigned to a named beneficiary in a beneficiary-designation change.", "Service Request", "Percentage", "", "50%", "Internal", "", "", "PII. Resulting designation held as an Account Party Role in 02."),
     ]),
   ]),
   ("Standing Instructions", "Effective-dated instructions that generate recurring transactions or govern distributions on an account. The transactions themselves are owned by 06.", [
     ("Account Standing Instruction", [
       ("Standing Instruction ID", "Unique identifier of the instruction.", "Standing Instruction", "Identifier", "", "SIN-0045512", "Internal", "", ""),
       ("Instruction Type", "Type of instruction.", "Standing Instruction", "Code", "Standing Instruction Type", "Systematic Investment Plan", "Internal", "SS&C DST", ""),
       ("Instruction Account", "Account the instruction applies to.", "Standing Instruction", "Reference (Account)", "", "ACC-0049812", "Internal", "", "", "PII"),
       ("Distribution Option", "How dividends or capital gains are paid for the account and class.", "Standing Instruction", "Code", "Distribution Option", "Reinvest", "Internal", "SS&C DST", "Y"),
       ("Bank Instruction Reference", "Masked pointer to the bank account used for ACH / direct debit.", "Standing Instruction", "Text", "", "BANK-****4410", "Internal", "NACHA", "", "PII. Store masked."),
       ("Instruction Status", "Status of the instruction.", "Standing Instruction", "Code", "Instruction Status", "Active", "Internal", "", ""),
       ("Instruction Effective From", "Date the instruction starts.", "Standing Instruction", "Date", "ISO 8601", "2026-10-01", "Internal", "", ""),
     ]),
   ]),
   ("Contact Centre Interactions", "Calls, chats, emails and secure messages handled by the shareholder contact centre (TA-operated or in-house).", [
     ("Contact Centre Interaction", [
       ("Interaction ID", "Unique identifier of the interaction.", "Interaction", "Identifier", "", "CCI-2026-1184520", "Internal", "", "Y"),
       ("Interaction Channel", "Channel of the interaction.", "Interaction", "Code", "Service Channel", "Phone", "Internal", "", ""),
       ("Interaction Account", "Account discussed, where identified.", "Interaction", "Reference (Account)", "", "ACC-0049812", "Internal", "", "", "PII"),
       ("Interaction Start Timestamp", "Date and time the interaction started.", "Interaction", "Timestamp", "ISO 8601", "2026-09-14T10:15:42-04:00", "Internal", "", ""),
       ("Contact Reason", "Primary reason for contact.", "Interaction", "Code", "Contact Reason", "Statement / Tax Form Query", "Internal", "", ""),
       ("First Contact Resolution Indicator", "Whether the need was resolved without a follow-up.", "Interaction", "Boolean", "", "Y", "Internal", "", ""),
       ("Linked Service Request", "Service request created from the interaction.", "Interaction", "Reference (Service Request)", "", "SRQ-2026-0081245", "Internal", "", ""),
       ("Dissatisfaction Expressed Indicator", "Whether the contact expressed dissatisfaction that must be assessed as a complaint (08).", "Interaction", "Boolean", "", "N", "FCA DISP", "FINRA Rule 4530", "Y"),
       ("Recording Reference", "Pointer to the call recording or transcript.", "Interaction", "Text", "URI", "rec://ta-cc/2026/09/14/1184520", "Internal", "", "", "PII"),
     ]),
   ]),
   ("Quality Assurance", "Quality checks of service requests and interactions by the TA or the asset manager's oversight team.", [
     ("QA Review", [
       ("Reviewed Item", "Service request or interaction reviewed.", "QA Review", "Reference (Service Request / Interaction)", "", "CCI-2026-1184520", "Internal", "", ""),
       ("QA Score", "Score achieved against the quality scorecard.", "QA Review", "Percentage", "", "92%", "Internal", "", ""),
       ("QA Outcome", "Overall outcome of the review.", "QA Review", "Code", "QA Outcome", "Pass with Coaching", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Statements, Confirmations & Tax Documents", "SV-STM",
  "Account statements, trade confirmations and tax documents produced for shareholders of record, how they are produced and delivered, and the corrections and reprints made after the fact.",
  [
   ("Document Definition", "The catalogue of investor documents the fund complex produces, with their regulatory basis and timing.", [
     ("Investor Document Definition", [
       ("Document Definition Code", "Code of the document type in the catalogue.", "Document Definition", "Identifier", "", "US-QTR-STMT", "Internal", "", ""),
       ("Investor Document Category", "Category of the investor document.", "Document Definition", "Code", "Investor Document Category", "Periodic Statement", "Internal", "", ""),
       ("Document Regulatory Basis", "Rule or regulation requiring the document.", "Document Definition", "Code (multi)", "Document Regulatory Basis", "SEC Rule 10b-10", "Internal", "", ""),
       ("Recipient Furnish Deadline Rule", "Rule for the latest date the document must reach the recipient.", "Document Definition", "Text", "", "1099-DIV: by 31 January after the tax year", "IRS General Instructions for Information Returns", "", ""),
     ]),
   ]),
   ("Statement & Confirmation", "Individual statements and trade confirmations issued to a shareholder of record (STMT- master).", [
     ("Investor Document", [
       ("Investor Document ID", "Unique identifier of the document instance.", "Investor Document", "Identifier", "", "STMT-2026-Q3-0045123", "Internal", "", "Y"),
       ("Document Definition", "Catalogue entry the document instantiates.", "Investor Document", "Reference (Document Definition)", "", "US-QTR-STMT", "Internal", "", ""),
       ("Document Account", "Account the document reports on.", "Investor Document", "Reference (Account)", "", "ACC-0049812", "Internal", "", "Y", "PII"),
       ("Document Recipient", "Party the document is addressed to (owner, duplicate / interested party, advisor).", "Investor Document", "Reference (Party)", "", "PTY-500771", "Internal", "", "", "PII"),
       ("Period End Date", "Last date covered by the document.", "Investor Document", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
       ("Delivery Method", "How the document was delivered.", "Investor Document", "Code", "Delivery Method", "Electronic - Email Notification", "SEC E-Delivery Releases", "", "Y"),
       ("Delivery Status", "Delivery outcome.", "Investor Document", "Code", "Delivery Status", "Delivered", "Internal", "", ""),
       ("Delivered Date", "Date the document was mailed or made available electronically.", "Investor Document", "Date", "ISO 8601", "2026-10-09", "Internal", "", "Y"),
       ("Suppression Reason", "Reason a document was not produced or not mailed.", "Investor Document", "Code", "Document Suppression Reason", "Householded", "Internal", "SEC Rule 154", ""),
       ("Original Document", "Document this one reprints or corrects.", "Investor Document", "Reference (Investor Document)", "", "", "Internal", "", ""),
       ("Document Repository Reference", "Pointer to the stored image for reprints and records retention.", "Investor Document", "Text", "URI", "img://ta/stmt/2026Q3/0045123.pdf", "Internal", "SEC Rule 17a-4", "", "PII"),
     ]),
     ("Trade Confirmation", [
       ("Confirmed Transaction", "Transaction confirmed (06).", "Confirmation", "Reference (Transaction)", "", "TXN-2026-000418273", "SEC Rule 10b-10", "", "Y"),
       ("Confirmation Timing", "Whether the transaction is confirmed immediately or on a periodic statement (e.g. systematic plans, reinvestments).", "Confirmation", "Code", "Confirmation Timing", "Immediate", "SEC Rule 10b-10", "", ""),
       ("Confirmation Sent Date", "Date the confirmation was sent or made available.", "Confirmation", "Date", "ISO 8601", "2026-09-19", "SEC Rule 10b-10", "", ""),
     ]),
   ]),
   ("Tax Documents", "Tax forms and certificates furnished to shareholders and filed with tax authorities, and the cost-basis elections behind them.", [
     ("Tax Form Record", [
       ("Tax Document Type", "Type of tax document.", "Tax Form", "Code", "Investor Tax Document Type", "1099-DIV", "IRS Form 1099-DIV", "HMRC", "Y"),
       ("Tax Year", "Tax year reported (calendar year in the US; 6 April - 5 April in the UK).", "Tax Form", "Text", "", "2025", "IRS General Instructions for Information Returns", "HMRC", "Y"),
       ("Payer Fund", "Fund or share class reporting as payer / issuer.", "Tax Form", "Reference (Product)", "", "PRD-00981", "IRS General Instructions for Information Returns", "", ""),
       ("Recipient TIN (Masked)", "Recipient taxpayer identification number as printed, masked. The certified TIN is held in 02.", "Tax Form", "Identifier", "", "XXX-XX-1234", "IRS General Instructions for Information Returns", "", "", "PII. Truncation permitted on recipient copies; verify current rule."),
       ("Tax Form Version", "Whether the form is original, corrected or void.", "Tax Form", "Code", "Tax Form Version", "Corrected", "IRS General Instructions for Information Returns", "", "Y"),
       ("Form Box Code", "Box or line of the form reported.", "Tax Form", "Code", "External (IRS / HMRC form box)", "1a Total ordinary dividends", "IRS Form 1099-DIV", "", ""),
       ("Reported Amount", "Amount reported in the box.", "Tax Form", "Amount", "", "USD 1,284.55", "IRS Form 1099-DIV", "", "Y"),
       ("Recipient Furnish Due Date", "Date by which the recipient copy must be furnished.", "Tax Form", "Date", "ISO 8601", "2026-02-02", "IRS General Instructions for Information Returns", "", "Y"),
       ("Furnished Date", "Date the recipient copy was furnished.", "Tax Form", "Date", "ISO 8601", "2026-01-28", "Internal", "", "Y"),
       ("Authority Filing Date", "Date the return was filed with the tax authority (e.g. IRS FIRE / IRIS).", "Tax Form", "Date", "ISO 8601", "2026-03-31", "IRS General Instructions for Information Returns", "", ""),
       ("Reclassification Pending Indicator", "Whether distribution character may be reclassified after year-end (late REIT / RIC reclassification), triggering corrected forms.", "Tax Form", "Boolean", "", "N", "Internal", "ICI", ""),
     ]),
     ("Cost Basis Election", [
       ("Cost Basis Method", "Method used to compute cost basis of redeemed covered shares.", "Cost Basis Election", "Code", "Cost Basis Method", "Average Cost", "IRS Form 1099-B", "IRC Section 6045", "Y"),
       ("Default Method Applied Indicator", "Whether the fund's default method applies because the shareholder made no election.", "Cost Basis Election", "Boolean", "", "Y", "IRC Section 6045", "", ""),
       ("Covered Security Indicator", "Whether shares were acquired on or after the covered date for mutual funds (1 January 2012) and so basis is reported to the IRS.", "Cost Basis Election", "Boolean", "", "Y", "IRS Form 1099-B", "IRC Section 6045", ""),
     ]),
     ("UK & EU Tax Document", [
       ("UK Distribution Type", "Tax character of a UK fund distribution shown on the tax voucher.", "Tax Form", "Code", "UK Distribution Type", "Dividend Distribution", "HMRC", "", ""),
       ("Equalisation Amount", "Equalisation (return of capital) per unit for Group 2 units.", "Tax Form", "Decimal", "", "0.0412", "HMRC", "UK FCA COLL", ""),
       ("Excess Reportable Income per Unit", "Excess reportable income per unit for an offshore reporting fund, reported to investors within six months of period end.", "Tax Form", "Decimal", "", "0.1185", "HMRC", "", ""),
     ]),
   ]),
   ("Production & Delivery", "Batch production of statements, confirmations and tax forms by the TA or print / e-delivery vendor.", [
     ("Production Run", [
       ("Production Run ID", "Unique identifier of the production run.", "Production Run", "Identifier", "", "PRUN-2026-Q3-001", "Internal", "", ""),
       ("Print / Delivery Vendor", "Vendor that printed, mailed or posted the documents.", "Production Run", "Reference (Party)", "", "PTY-100995", "Internal", "", ""),
       ("Run Date", "Date the run was produced.", "Production Run", "Date", "ISO 8601", "2026-10-07", "Internal", "", ""),
       ("Documents Produced Count", "Number of documents produced.", "Production Run", "Integer", "", "48210", "Internal", "", ""),
       ("Documents Suppressed Count", "Number suppressed (householding, RPO, zero activity).", "Production Run", "Integer", "", "1215", "Internal", "", ""),
       ("Run Reconciliation Status", "Whether counts and amounts reconcile to the TA books and the vendor manifest.", "Production Run", "Code", "Reconciliation Status", "Reconciled", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Regulatory Shareholder Communications", "SV-COM",
  "Communications that fund regulation requires to be sent or made available to shareholders: tailored shareholder reports, prospectus and summary prospectus delivery, KID/KIID provision, and notices of mergers, liquidations, name, objective and other changes. The underlying documents are Product Documents in 01; the change events are Lifecycle Events in 01.",
  [
   ("Communication Master", "Identity, basis and deadlines of a shareholder communication (COMM- master).", [
     ("Shareholder Communication", [
       ("Communication ID", "Unique identifier of the communication.", "Communication", "Identifier", "", "COMM-2026-0145", "Internal", "", "Y"),
       ("Communication Type", "Type of communication.", "Communication", "Code", "Shareholder Communication Type", "Tailored Shareholder Report - Annual", "Internal", "", "Y"),
       ("Communication Regulatory Basis", "Rule requiring the communication.", "Communication", "Code", "Communication Regulatory Basis", "SEC Rule 30e-1", "Internal", "", ""),
       ("Covered Share Classes", "Share classes whose shareholders receive the communication.", "Communication", "Reference (Share Class) (multi)", "", "SHC-004512", "Internal", "", "Y"),
       ("Source Product Document", "Product Document (01) being delivered, where the communication is a document delivery.", "Communication", "Reference (Product Document)", "", "Annual Report 2026-06-30 (en)", "Internal", "", "", "Document master owned by 01."),
       ("Triggering Lifecycle Event", "Product lifecycle event (01) that triggers a notice, e.g. merger or liquidation.", "Communication", "Reference (Lifecycle Event)", "", "Merger SHC-004512 -> SHC-004700", "Internal", "", ""),
       ("Report Period End Date", "Period end for periodic reports.", "Communication", "Date", "ISO 8601", "2026-06-30", "SEC Form N-CSR", "UCITS Directive", ""),
       ("Required Delivery Deadline", "Latest date the communication must be transmitted or made available.", "Communication", "Date", "ISO 8601", "2026-08-29", "SEC Rule 30e-1", "UCITS Directive", "Y"),
       ("Communication Status", "Lifecycle status of the communication.", "Communication", "Code", "Communication Status", "Distributed", "Internal", "", ""),
       ("Regulatory Filing Reference", "Filing in which the communication was filed (e.g. EDGAR accession of Form N-CSR or 497).", "Communication", "Identifier", "", "0001193125-26-123456", "SEC Form N-CSR", "", ""),
     ]),
   ]),
   ("US Shareholder Reports & Prospectus Delivery", "US tailored shareholder reports, website availability and prospectus delivery.", [
     ("Tailored Shareholder Report", [
       ("TSR Period Type", "Annual or semi-annual report.", "Communication", "Code", "Report Period Type", "Annual", "SEC Rule 30e-1", "SEC Form N-1A", ""),
       ("Form N-CSR Filing Date", "Date the report was filed on Form N-CSR.", "Communication", "Date", "ISO 8601", "2026-09-05", "SEC Form N-CSR", "", ""),
       ("Website Availability Date", "Date financial statements and other N-CSR information were posted at the website address shown in the report.", "Communication", "Date", "ISO 8601", "2026-08-28", "SEC Rule 30e-1", "", "Y"),
     ]),
     ("Prospectus Delivery", [
       ("Prospectus Delivery Basis", "What is delivered to satisfy prospectus delivery.", "Communication", "Code", "Prospectus Delivery Basis", "Summary Prospectus", "SEC Rule 498", "", ""),
       ("Prospectus Delivery Trigger", "Event that requires delivery.", "Communication", "Code", "Prospectus Delivery Trigger", "Annual Update to Existing Holders", "SEC Rule 498", "", ""),
     ]),
   ]),
   ("Shareholder Notices", "Notices of changes and events, in the US and under UCITS / FCA COLL.", [
     ("Shareholder Notice", [
       ("Notice Type", "Type of notice.", "Communication", "Code", "Shareholder Notice Type", "Fund Merger", "Internal", "", ""),
       ("Change Classification", "Regulatory classification of the change under FCA COLL.", "Communication", "Code", "COLL Change Classification", "Significant", "UK FCA COLL", "", "Y"),
       ("Minimum Notice Period (Days)", "Minimum notice required before the effective date.", "Communication", "Integer", "Days", "60", "UK FCA COLL", "SEC Rule 35d-1", ""),
       ("Free Redemption Window End Date", "Last date shareholders may redeem or switch without charge (e.g. UCITS merger).", "Communication", "Date", "ISO 8601", "2026-12-05", "UCITS Directive", "", ""),
       ("Shareholder Approval Required Indicator", "Whether the change needs a shareholder vote (links to a Proxy Campaign).", "Communication", "Boolean", "", "N", "UK FCA COLL", "Investment Company Act 1940", ""),
     ]),
     ("EU/UK Investor Information Provision", [
       ("Provision Medium", "Medium used to provide the KID / KIID, reports or notice.", "Communication", "Code", "Durable Medium Type", "Website (Consented)", "UCITS Directive", "PRIIPs Regulation", ""),
     ]),
   ]),
   ("Distribution & Audience", "Who receives the communication, by which path and when (MAIL- master), and the recipient-level outcome.", [
     ("Communication Distribution", [
       ("Distribution Job ID", "Unique identifier of the distribution job.", "Distribution", "Identifier", "", "MAIL-2026-00318", "Internal", "", ""),
       ("Distributed Communication", "Communication distributed.", "Distribution", "Reference (Communication)", "", "COMM-2026-0145", "Internal", "", ""),
       ("Audience Basis", "Population the job targets.", "Distribution", "Code", "Audience Basis", "Registered Holders", "Internal", "", ""),
       ("Audience Record Date", "Date as of which holders are selected.", "Distribution", "Date", "ISO 8601", "2026-08-15", "Internal", "", "Y"),
       ("Notice-and-Access Indicator", "Whether a notice of internet availability is sent instead of a full set (where permitted, e.g. proxy materials under Rule 14a-16).", "Distribution", "Boolean", "", "N", "SEC Rule 14a-16", "", ""),
       ("Mail Date", "Date the job was mailed or released electronically.", "Distribution", "Date", "ISO 8601", "2026-08-26", "Internal", "", "Y"),
       ("Deadline Met Indicator", "Whether the job met the communication's required delivery deadline.", "Distribution", "Boolean", "", "Y", "Internal", "", "Y"),
       ("Suppression Rules Applied", "Suppression rules applied when selecting recipients.", "Distribution", "Code (multi)", "Document Suppression Reason", "Householded; RPO - Undeliverable Address", "Internal", "SEC Rule 154", ""),
     ]),
     ("Recipient Delivery Record", [
       ("Recipient Account", "Account to which the communication was delivered.", "Recipient Delivery", "Reference (Account)", "", "ACC-0049812", "Internal", "", "", "PII"),
       ("Recipient Delivery Method", "Method used for this recipient.", "Recipient Delivery", "Code", "Delivery Method", "Paper - First Class Mail", "Internal", "", ""),
       ("Recipient Delivery Status", "Delivery outcome for this recipient.", "Recipient Delivery", "Code", "Delivery Status", "Returned Undeliverable", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Delivery Elections & Householding", "SV-DEL",
  "Shareholder elections that govern how servicing and regulatory documents are delivered: e-delivery consent, householding and mail holds. The consent legal basis and global privacy suppression are owned by 02; marketing preferences by 04.",
  [
   ("E-Delivery Election", "A shareholder's consent to receive specified documents electronically, with its evidence (DEL- master).", [
     ("E-Delivery Election", [
       ("Delivery Election ID", "Unique identifier of the election.", "Delivery Election", "Identifier", "", "DEL-0045512", "Internal", "", "Y"),
       ("Election Account", "Account the election applies to.", "Delivery Election", "Reference (Account)", "", "ACC-0049812", "Internal", "", "Y", "PII"),
       ("Election Document Scope", "Document families the election covers.", "Delivery Election", "Code (multi)", "Delivery Election Scope", "Statements; Confirmations; Regulatory Reports and Prospectus", "SEC E-Delivery Releases", "", "Y"),
       ("Delivery Preference", "Elected delivery preference.", "Delivery Election", "Code", "Delivery Preference", "Electronic", "SEC E-Delivery Releases", "", "Y"),
       ("E-Delivery Consent Type", "Form of consent obtained.", "Delivery Election", "Code", "E-Delivery Consent Type", "Informed Affirmative Consent", "SEC E-Delivery Releases", "", ""),
       ("Consent Captured Timestamp", "When the election was captured.", "Delivery Election", "Timestamp", "ISO 8601", "2026-02-10T14:22:05Z", "SEC E-Delivery Releases", "", "Y", "PII"),
       ("Consent Evidence Reference", "Pointer to stored evidence (disclosure version, timestamp, IP / log).", "Delivery Election", "Text", "", "evidence://edel/2026/02/10/7781", "SEC E-Delivery Releases", "", "", "PII"),
       ("Delivery Email Contact Point", "Email contact point (02) used for notifications.", "Delivery Election", "Reference (Contact Point)", "", "CP-0091245", "Internal", "", "", "PII"),
       ("Tax Form Electronic Consent Indicator", "Whether separate consent to receive tax statements electronically has been obtained.", "Delivery Election", "Boolean", "", "Y", "IRS General Instructions for Information Returns", "", "Y", "IRS e-furnishing consent rules are form-specific; verify."),
       ("Election Revoked Timestamp", "When the election was revoked.", "Delivery Election", "Timestamp", "ISO 8601", "", "SEC E-Delivery Releases", "", ""),
       ("Linked Consent Record", "02 consent record, where consent is also the processing legal basis.", "Delivery Election", "Reference (Consent Record)", "", "CNS-0081223", "Internal", "EU GDPR", "", "Legal basis owned by 02."),
     ]),
   ]),
   ("Householding", "Delivery of one copy of prospectuses, shareholder reports and other permitted documents to shareholders sharing an address.", [
     ("Householding Group", [
       ("Householding Group ID", "Identifier of the delivery household. Distinct from the 02 Household (HH-) used for relationship purposes.", "Householding Group", "Identifier", "", "HHD-0012245", "Internal", "", ""),
       ("Member Accounts", "Accounts in the householding group.", "Householding Group", "Reference (Account) (multi)", "", "ACC-0049812; ACC-0049813", "SEC Rule 154", "", "", "PII"),
       ("Householding Consent Type", "Whether consent is written or implied.", "Householding Group", "Code", "Householding Consent Type", "Implied", "SEC Rule 154", "", ""),
       ("Householding Notice Sent Date", "Date the 60-day householding notice was sent (implied consent).", "Householding Group", "Date", "ISO 8601", "2026-03-01", "SEC Rule 154", "", ""),
       ("Householding Status", "Status of householding for the group.", "Householding Group", "Code", "Householding Status", "Active", "SEC Rule 154", "", "Y"),
       ("Householding Revocation Date", "Date a member revoked consent.", "Householding Group", "Date", "ISO 8601", "", "SEC Rule 154", "", "Y"),
       ("Individual Delivery Resume Due Date", "Date by which individual delivery must resume after revocation (30 days).", "Householding Group", "Date", "ISO 8601", "", "SEC Rule 154", "", ""),
       ("Annual Revocation Notice Date", "Date of the latest annual explanation of the right to revoke.", "Householding Group", "Date", "ISO 8601", "2026-03-01", "SEC Rule 154", "", ""),
     ]),
   ]),
   ("Mail Hold", "Temporary or permanent holds on mailings for an account.", [
     ("Mail Hold", [
       ("Mail Hold Indicator", "Whether mail is currently held.", "Delivery Election", "Boolean", "", "N", "Internal", "", ""),
       ("Mail Hold Reason", "Reason for the hold.", "Delivery Election", "Code", "Mail Hold Reason", "Undeliverable Address (RPO)", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Proxy Solicitation & Shareholder Meetings", "SV-PRX",
  "Meetings of fund shareholders and the solicitation of their votes, including votes by beneficial owners through intermediaries. This is fund shareholders voting on fund matters, not the asset manager voting the securities its funds hold.",
  [
   ("Proxy Campaign", "A shareholder meeting and its solicitation (PRX- master).", [
     ("Proxy Campaign", [
       ("Proxy Campaign ID", "Unique identifier of the meeting / campaign.", "Proxy Campaign", "Identifier", "", "PRX-2026-004", "Internal", "", "Y"),
       ("Meeting Type", "Type of meeting.", "Proxy Campaign", "Code", "Meeting Type", "Special Meeting", "Internal", "UK FCA COLL", ""),
       ("Registrant / Fund", "Fund, trust or scheme holding the meeting.", "Proxy Campaign", "Reference (Product)", "", "PRD-00900", "Internal", "", ""),
       ("Record Date", "Date determining who may vote.", "Proxy Campaign", "Date", "ISO 8601", "2026-09-12", "SEC Rule 14a-13", "", "Y"),
       ("Meeting Date", "Scheduled meeting date.", "Proxy Campaign", "Date", "ISO 8601", "2026-11-20", "Internal", "", "Y"),
       ("Proxy Mailing Date", "Date proxy materials were first sent.", "Proxy Campaign", "Date", "ISO 8601", "2026-09-29", "SEC Schedule 14A", "", ""),
       ("Solicitation Agent", "Proxy solicitor engaged.", "Proxy Campaign", "Reference (Party)", "", "PTY-101210", "Internal", "", ""),
       ("Shares Outstanding at Record Date", "Shares entitled to vote.", "Proxy Campaign", "Decimal", "", "84,512,330.112", "Internal", "", "Y"),
       ("Quorum Requirement", "Proportion of shares that must be present for a quorum, per the governing documents.", "Proxy Campaign", "Percentage", "", "30%", "Internal", "", ""),
       ("Meeting Status", "Status of the meeting.", "Proxy Campaign", "Code", "Meeting Status", "Adjourned", "Internal", "", ""),
       ("Adjourned To Date", "Date to which the meeting was adjourned.", "Proxy Campaign", "Date", "ISO 8601", "2026-12-04", "Internal", "", ""),
     ]),
   ]),
   ("Proposals & Vote Tallies", "The matters put to shareholders and the running and final vote counts.", [
     ("Proxy Proposal", [
       ("Proposal ID", "Unique identifier of the proposal.", "Proposal", "Identifier", "", "PRP-2026-004-02", "Internal", "", ""),
       ("Proposal Type", "Type of matter.", "Proposal", "Code", "Fund Proposal Type", "Approve Reorganisation", "Investment Company Act 1940", "UK FCA COLL", "Y"),
       ("Vote Standard", "Vote required for approval.", "Proposal", "Code", "Vote Standard", "1940 Act Majority", "Investment Company Act 1940", "UK FCA COLL", "Y"),
       ("Proposal Outcome", "Final outcome.", "Proposal", "Code", "Proposal Outcome", "Approved", "Internal", "", "Y"),
     ]),
     ("Vote Tally", [
       ("Tally As-Of Date", "Date of the tally.", "Vote Tally", "Date", "ISO 8601", "2026-11-13", "Internal", "", ""),
       ("Shares Voted For", "Shares voted for.", "Vote Tally", "Decimal", "", "31,004,118.4", "Internal", "", ""),
       ("Shares Voted Against", "Shares voted against.", "Vote Tally", "Decimal", "", "2,114,309.0", "Internal", "", ""),
       ("Broker Non-Votes", "Shares held by brokers without instructions and without discretion on the matter.", "Vote Tally", "Decimal", "", "0", "NYSE Rule 452", "", ""),
       ("Percent of Outstanding Voted", "Shares present or represented as a percentage of shares outstanding.", "Vote Tally", "Percentage", "", "40.4%", "Internal", "", ""),
       ("Quorum Achieved Indicator", "Whether the quorum has been reached.", "Vote Tally", "Boolean", "", "Y", "Internal", "", "Y"),
       ("Mirror / Echo Voted Shares", "Shares voted in proportion to other holders (e.g. affiliated funds of funds or insurance separate accounts).", "Vote Tally", "Decimal", "", "5,200,000.0", "Investment Company Act 1940", "", ""),
     ]),
   ]),
   ("Beneficial Owner Voting", "Voting instructions received from beneficial owners through intermediaries.", [
     ("Intermediary Vote Instruction", [
       ("Voting Intermediary", "Broker, bank or platform holding the shares in street name / nominee name.", "Vote Tally", "Reference (Party)", "", "PTY-100001", "SEC Rule 14b-1", "", ""),
       ("Instructions Received Count", "Number of beneficial owners who returned instructions.", "Vote Tally", "Integer", "", "5120", "Internal", "", ""),
       ("Shares Instructed", "Shares covered by instructions.", "Vote Tally", "Decimal", "", "9,880,412.5", "Internal", "", ""),
       ("Broker Discretionary Vote Permitted Indicator", "Whether the intermediary may vote uninstructed shares on the matter (routine matter).", "Vote Tally", "Boolean", "", "N", "NYSE Rule 452", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Beneficial-Owner Communications via Intermediaries", "SV-BOC",
  "How communications reach beneficial owners who hold through brokers, banks, platforms and nominees: broker searches, distribution through intermediary agents (e.g. Broadridge), NOBO lists, EU/UK platform cascades, and the fees paid for distribution.",
  [
   ("Intermediary Distribution", "Distribution of a communication to beneficial owners through an intermediary or its agent (BOD- master).", [
     ("Intermediary Distribution Request", [
       ("Intermediary Distribution ID", "Unique identifier of the request.", "Intermediary Distribution", "Identifier", "", "BOD-2026-01188", "Internal", "", "Y"),
       ("BOD Communication", "Communication distributed.", "Intermediary Distribution", "Reference (Communication)", "", "COMM-2026-0145", "Internal", "", "Y"),
       ("Intermediary", "Broker, bank, platform or nominee holding for beneficial owners.", "Intermediary Distribution", "Reference (Party)", "", "PTY-100001", "SEC Rule 14b-1", "", "Y"),
       ("Holding Model", "How the beneficial owners hold their shares.", "Intermediary Distribution", "Code", "Holding Model", "Street Name / Omnibus", "Internal", "", ""),
       ("Broker Search Date", "Date the search card / inquiry was sent to intermediaries to get beneficial-owner counts.", "Intermediary Distribution", "Date", "ISO 8601", "2026-08-20", "SEC Rule 14a-13", "", ""),
       ("Beneficial Owner Position Count", "Number of beneficial-owner positions reported by the intermediary.", "Intermediary Distribution", "Integer", "", "18450", "SEC Rule 14b-1", "", "Y"),
       ("Distribution Confirmed Date", "Date the intermediary or agent confirmed distribution.", "Intermediary Distribution", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
     ]),
     ("NOBO List Request", [
       ("NOBO List Request Date", "Date a non-objecting beneficial owner list was requested.", "Intermediary Distribution", "Date", "ISO 8601", "2026-09-15", "SEC Rule 14b-1", "", ""),
       ("NOBO Permitted Use", "Purpose for which NOBO data may be used.", "Intermediary Distribution", "Code", "NOBO Permitted Use", "Issuer Communications Only", "SEC Rule 14b-1", "", "", "PII. Retention per 02 / 08 rules."),
     ]),
   ]),
   ("EU/UK Platform & Nominee Cascade", "How platforms and nominees pass notices and reports on to underlying investors.", [
     ("Notice Cascade", [
       ("Cascading Platform / Nominee", "Platform or nominee on the register.", "Intermediary Distribution", "Reference (Party)", "", "PTY-3301", "Internal", "", ""),
       ("Cascade Method", "How the notice is passed on.", "Intermediary Distribution", "Code", "Cascade Method", "Electronic Notice to Platform", "Internal", "UK FCA COBS", ""),
       ("Cascade Confirmation Received Indicator", "Whether the platform confirmed it passed the notice on.", "Intermediary Distribution", "Boolean", "", "Y", "Internal", "", ""),
     ]),
   ]),
   ("Distribution Fees", "Fees billed for distributing communications to beneficial owners. Contractual servicing payments (sub-TA, networking) are owned by 05.", [
     ("Intermediary Communication Fee Invoice", [
       ("Fee Invoice ID", "Unique identifier of the invoice.", "Fee Invoice", "Identifier", "", "IFI-2026-00412", "Internal", "", ""),
       ("Invoicing Party", "Intermediary or agent issuing the invoice.", "Fee Invoice", "Reference (Party)", "", "PTY-100800", "Internal", "", ""),
       ("Invoiced Campaign / Communication", "Communication or proxy campaign billed.", "Fee Invoice", "Reference (Communication / Proxy Campaign)", "", "PRX-2026-004", "Internal", "", ""),
       ("Fee Type", "Fee component billed.", "Fee Invoice", "Code", "Intermediary Communication Fee Type", "Basic Processing Fee", "NYSE Rule 451", "FINRA Rule 2251", ""),
       ("Invoice Amount", "Total invoiced.", "Fee Invoice", "Amount", "", "USD 21,330.00", "Internal", "", ""),
       ("Fee Paid By", "Who bears the fee.", "Fee Invoice", "Code", "Cost Bearer", "Fund", "Internal", "", ""),
       ("Governing Agreement", "Agreement (05) under which a negotiated rate applies, if any.", "Fee Invoice", "Reference (Agreement)", "", "AGR-00981", "Internal", "", "", "Only where contractual; otherwise SRO rate schedule."),
       ("Invoice Validation Status", "Result of checking units and rates against the rate schedule and position counts.", "Fee Invoice", "Code", "Reconciliation Status", "Reconciled", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Escheatment, Unclaimed Property & Dormancy", "SV-ESC",
  "Lost shareholders and uncashed payments, state dormancy and escheatment of fund shares and proceeds in the US, the UK Dormant Assets Scheme, and reclaims by owners.",
  [
   ("Lost Shareholder & Unresponsive Payee", "Lost securityholder status and searches, and notices for uncashed cheques.", [
     ("Lost Shareholder Status", [
       ("Status Account", "Account assessed.", "Lost Shareholder Status", "Reference (Account)", "", "ACC-0049812", "Internal", "", "", "PII"),
       ("Lost Securityholder Indicator", "Whether the holder is a lost securityholder (correspondence returned undeliverable and no new address).", "Lost Shareholder Status", "Boolean", "", "Y", "SEC Rule 17Ad-17", "", "Y"),
       ("First Returned Mail Date", "Date mail was first returned undeliverable (RPO).", "Lost Shareholder Status", "Date", "ISO 8601", "2026-05-14", "SEC Rule 17Ad-17", "", "Y"),
       ("First Database Search Date", "Date of the first database search (between three and twelve months after becoming lost).", "Lost Shareholder Status", "Date", "ISO 8601", "2026-08-20", "SEC Rule 17Ad-17", "", ""),
       ("Second Database Search Date", "Date of the second search (between six and twelve months after the first).", "Lost Shareholder Status", "Date", "ISO 8601", "", "SEC Rule 17Ad-17", "", ""),
       ("Unresponsive Payee Indicator", "Whether the holder has a cheque not negotiated in the required period.", "Lost Shareholder Status", "Boolean", "", "N", "SEC Rule 17Ad-17", "", ""),
       ("Unresponsive Payee Notice Date", "Date the written notice of the unnegotiated cheque was sent (no later than seven months after the cheque).", "Lost Shareholder Status", "Date", "ISO 8601", "", "SEC Rule 17Ad-17", "", ""),
     ]),
   ]),
   ("Dormancy & Escheatment (US)", "Assessment of state dormancy, due diligence and reporting / remittance to states.", [
     ("Dormancy Assessment", [
       ("Owner State of Last Known Address", "State of the owner's last known address, which determines the reporting state under the priority rules.", "Dormancy Assessment", "Code", "ISO 3166-2", "US-CA", "US State Unclaimed Property Laws", "", "Y", "PII"),
       ("Last Owner-Generated Contact Date", "Date of the last owner-initiated activity or contact that resets dormancy.", "Dormancy Assessment", "Date", "ISO 8601", "2023-04-11", "US State Unclaimed Property Laws", "", "Y"),
       ("Dormancy Trigger Basis", "Basis on which the state starts the dormancy clock.", "Dormancy Assessment", "Code", "Dormancy Trigger Basis", "Returned Mail (RPO)", "US State Unclaimed Property Laws", "", ""),
       ("Dormancy Period (Years)", "Dormancy period applying to the property in the reporting state.", "Dormancy Assessment", "Integer", "Years", "3", "US State Unclaimed Property Laws", "NAUPA II", ""),
       ("Presumed Abandoned Date", "Date the property is presumed abandoned.", "Dormancy Assessment", "Date", "ISO 8601", "2026-05-14", "US State Unclaimed Property Laws", "", "Y"),
       ("Due Diligence Letter Sent Date", "Date the owner due diligence letter was sent before reporting.", "Dormancy Assessment", "Date", "ISO 8601", "2027-01-15", "US State Unclaimed Property Laws", "", "Y"),
       ("Property Type Code", "NAUPA property type code reported.", "Dormancy Assessment", "Code", "External (NAUPA II property codes)", "SC08", "NAUPA II", "", "", "Verify mutual fund code with the state / vendor."),
       ("Escheatment Status", "Status of the property in the escheatment process.", "Dormancy Assessment", "Code", "Escheatment Status", "Due Diligence Sent", "Internal", "", "Y"),
     ]),
     ("Escheatment Report & Remittance", [
       ("Escheatment Report ID", "Unique identifier of the holder report.", "Escheatment Report", "Identifier", "", "ESC-2027-CA-001", "Internal", "", ""),
       ("Reporting State", "State the report is filed with.", "Escheatment Report", "Code", "ISO 3166-2", "US-CA", "US State Unclaimed Property Laws", "", "Y"),
       ("Report Due Date", "Date the report and remittance are due.", "Escheatment Report", "Date", "ISO 8601", "2027-11-01", "US State Unclaimed Property Laws", "", ""),
       ("Remittance Form", "Whether shares are delivered in kind or liquidated to cash.", "Escheatment Report", "Code", "Remittance Form", "Shares in Kind", "US State Unclaimed Property Laws", "", ""),
       ("Amount Remitted", "Cash remitted to the state.", "Escheatment Report", "Amount", "", "USD 18,220.14", "Internal", "", "Y"),
       ("Report Filed Date", "Date the report was filed (typically in NAUPA standard electronic format).", "Escheatment Report", "Date", "ISO 8601", "2027-10-25", "NAUPA II", "", ""),
     ]),
   ]),
   ("UK Dormant Assets & Reclaims", "Transfers to the UK Reclaim Fund and reclaims of escheated or transferred property by owners.", [
     ("UK Dormant Asset Transfer", [
       ("UK Dormant Asset Category", "Category of dormant collective-investment asset.", "Dormancy Assessment", "Code", "UK Dormant Asset Category", "CIS Unit Conversion Proceeds", "Dormant Assets Act 2022", "", ""),
       ("Gone-Away Period (Years)", "Years the owner has been treated as gone-away (12 years for unit conversion proceeds, 6 for other amounts).", "Dormancy Assessment", "Integer", "Years", "12", "Dormant Assets Act 2022", "", ""),
       ("Reclaim Fund Transfer Date", "Date the amount was transferred to the authorised reclaim fund.", "Dormancy Assessment", "Date", "ISO 8601", "2026-09-30", "Dormant Assets Act 2022", "", "Y"),
     ]),
     ("Unclaimed Property Reclaim", [
       ("Reclaim ID", "Unique identifier of the reclaim.", "Reclaim", "Identifier", "", "RCL-2026-00045", "Internal", "", ""),
       ("Claimant", "Party reclaiming the property.", "Reclaim", "Reference (Party)", "", "PTY-500771", "Internal", "", "", "PII"),
       ("Reclaim Source", "Body from which the property is reclaimed.", "Reclaim", "Code", "Reclaim Source", "US State", "Internal", "", ""),
       ("Reclaim Status", "Status of the reclaim.", "Reclaim", "Code", "Reclaim Status", "Paid", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("TA Oversight & Servicing Quality", "SV-TAO",
  "The asset manager's oversight of outsourced transfer agents and servicing vendors: service levels and KPIs, servicing errors and incidents, and remediation of shareholders affected by processing or NAV errors.",
  [
   ("Servicing Providers", "Servicing vendors the fund complex relies on, by role, and the oversight applied to them.", [
     ("Servicing Provider Engagement", [
       ("Servicing Provider", "Party providing the service.", "Servicing Provider", "Reference (Party)", "", "PTY-100990", "Internal", "", "Y"),
       ("Servicing Role", "Service performed.", "Servicing Provider", "Code", "Servicing Provider Role", "Transfer Agent / Registrar", "Internal", "", "Y"),
       ("SEC Transfer Agent Registration Number", "Registration number on Form TA-1, where the provider is a US transfer agent.", "Servicing Provider", "Identifier", "", "084-01234", "SEC Form TA-1", "", ""),
       ("Last Oversight Review Date", "Date of the latest due-diligence / oversight review.", "Servicing Provider", "Date", "ISO 8601", "2026-06-15", "SEC Rule 38a-1", "", ""),
       ("Oversight Rating", "Overall rating from the latest review.", "Servicing Provider", "Code", "Oversight Rating", "Satisfactory", "Internal", "", ""),
     ]),
   ]),
   ("Service Levels & KPIs", "Agreed service levels and their periodic measurement.", [
     ("Service Level Definition", [
       ("SLA ID", "Unique identifier of the service level.", "SLA", "Identifier", "", "SLA-TA-012", "Internal", "", "Y"),
       ("Metric Name", "Name of the metric.", "SLA", "Text", "", "Average speed of answer", "Internal", "", ""),
       ("Target Value", "Target the provider must meet.", "SLA", "Decimal", "", "30", "Internal", "", ""),
       ("Metric Unit", "Unit of the target.", "SLA", "Code", "Metric Unit", "Seconds", "Internal", "", ""),
       ("Contractual SLA Indicator", "Whether the level is contractual (with service credits) rather than a monitored KPI.", "SLA", "Boolean", "", "Y", "Internal", "", ""),
     ]),
     ("Service Level Measurement", [
       ("Measurement Period", "Period measured.", "SLA Measurement", "Text", "", "2026-09", "Internal", "", ""),
       ("Actual Value", "Measured result.", "SLA Measurement", "Decimal", "", "41", "Internal", "", ""),
       ("SLA Met Indicator", "Whether the target was met.", "SLA Measurement", "Boolean", "", "N", "Internal", "", "Y"),
     ]),
   ]),
   ("Servicing Errors & Remediation", "Processing, as-of and NAV errors affecting shareholders, and the compensation or reprocessing that follows.", [
     ("Servicing Error", [
       ("Servicing Error ID", "Unique identifier of the error.", "Servicing Error", "Identifier", "", "ERR-2026-00218", "Internal", "", "Y"),
       ("Servicing Error Type", "Type of error.", "Servicing Error", "Code", "Servicing Error Type", "NAV Error", "Internal", "", "Y"),
       ("Error Occurrence Date", "Date the error first affected shareholders.", "Servicing Error", "Date", "ISO 8601", "2026-08-03", "Internal", "", ""),
       ("Responsible Party", "Party whose error it was (TA, fund administrator, adviser, intermediary).", "Servicing Error", "Reference (Party)", "", "PTY-100990", "Internal", "", ""),
       ("Root Cause Category", "Root cause category.", "Servicing Error", "Code", "Servicing Root Cause", "Manual Processing", "Internal", "", ""),
       ("NAV Error Magnitude", "Size of the NAV error as a percentage of the correct NAV.", "Servicing Error", "Percentage", "", "0.62%", "Internal", "UK FCA COLL", "", "Materiality thresholds per Board-approved policy (US) / COLL 6.6 (UK); verify."),
       ("Materiality Threshold Exceeded Indicator", "Whether the error exceeds the policy materiality threshold, requiring reprocessing / compensation.", "Servicing Error", "Boolean", "", "Y", "Internal", "UK FCA COLL", "Y"),
       ("Accounts Impacted Count", "Number of shareholder accounts affected.", "Servicing Error", "Integer", "", "3120", "Internal", "", ""),
       ("Total Financial Impact", "Total amount of shareholder and fund harm.", "Servicing Error", "Amount", "", "USD 84,110.00", "Internal", "", "Y"),
       ("Correction Transactions", "As-of or correction transactions booked in 06.", "Servicing Error", "Reference (Transaction) (multi)", "", "TXN-2026-000401118", "Internal", "", ""),
     ]),
     ("Shareholder Remediation", [
       ("Remediation ID", "Unique identifier of the remediation record.", "Remediation", "Identifier", "", "RMD-2026-00218-0012", "Internal", "", ""),
       ("Remediated Account", "Account compensated or reprocessed.", "Remediation", "Reference (Account)", "", "ACC-0049812", "Internal", "", "Y", "PII"),
       ("Remediation Type", "How the shareholder was made whole.", "Remediation", "Code", "Remediation Type", "Cash Compensation", "Internal", "", ""),
       ("Compensation Amount", "Amount paid or value of units adjusted.", "Remediation", "Amount", "", "USD 27.15", "Internal", "", "Y"),
       ("Compensation Paid Date", "Date compensation was paid or units adjusted.", "Remediation", "Date", "ISO 8601", "2026-09-12", "Internal", "", ""),
       ("Cost Borne By", "Who bore the cost.", "Remediation", "Code", "Cost Bearer", "Service Provider", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Data Management Metadata", "SV-DMM",
  "Metadata applied to every record in the investor servicing and shareholder communications domain.",
  [
   ("Record Metadata", "Ownership, lineage, retention and quality metadata.", [
     ("Record Metadata", [
       ("Data Owner", "Business role accountable for the data element.", "All", "Reference (Party)", "", "Head of Fund Operations", "DCAM (EDM Council)", "", ""),
       ("Data Steward", "Role responsible for day-to-day data quality.", "All", "Reference (Party)", "", "TA Oversight Data Steward", "DCAM (EDM Council)", "", ""),
       ("System of Record", "System holding the authoritative value (e.g. TA recordkeeping system, document vendor, proxy platform).", "All", "Code", "Firm-defined", "TA Recordkeeping System", "Internal", "", "Y"),
       ("Source Record ID", "Identifier of the record in the source system.", "All", "Identifier", "", "TA2000:0045-889123:WK-55120", "Internal", "", ""),
       ("Records Retention Class", "Retention class under the firm's records retention schedule (owned by 08).", "All", "Code", "External (08 Records Retention Schedule)", "Shareholder Records - 6 years", "SEC Rule 17Ad-7", "SEC Rule 31a-2", ""),
       ("Personal Data Indicator", "Whether the record contains personal data subject to GDPR / US privacy law.", "All", "Boolean", "", "Y", "EU GDPR", "SEC Regulation S-P", ""),
       ("Record Effective From", "Business-effective start date of the record version.", "All", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Record Effective To", "Business-effective end date of the record version.", "All", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Last Updated Timestamp", "System timestamp of the last change.", "All", "Timestamp", "ISO 8601", "2026-09-30T17:45:00Z", "Internal", "", ""),
       ("Data Quality Status", "Validation status of the record.", "All", "Code", "Data Quality Status", "Validated", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Service Request Type": ("Internal (aligned to common TA work types)", [("Address Change",""),("Account Maintenance","Name, registration detail, phone, email"),("Beneficiary Designation Change","TOD / IRA beneficiary"),("Transfer of Ownership","Re-registration between owners"),("Estate / Death Claim",""),("Systematic Plan Set-Up / Change","SIP, SWP, automatic exchange"),("Distribution Option Change","Dividend / capital gains option"),("Bank Instruction Change","ACH / direct debit details"),("Duplicate Statement Request","Interested party or advisor copy"),("Document Reprint","Statement, confirm or tax form"),("Lost / Uncashed Cheque Replacement","Stop payment and reissue"),("Redemption Request","Non-financial servicing of a financial request"),("Account Closure",""),("Power of Attorney Registration",""),("Cost Basis Method Election",""),("Delivery Preference Change","E-delivery / householding"),("Escheatment Reclaim","")]),
 "Requester Role": ("Internal", [("Account Owner",""),("Joint Owner",""),("Trustee",""),("Power of Attorney",""),("Executor / Administrator",""),("Beneficiary",""),("Financial Professional",""),("Intermediary Operations",""),("Third Party (Unauthorised)","Information only")]),
 "Service Channel": ("Internal", [("Phone",""),("Mail",""),("Fax",""),("Email",""),("Secure Message",""),("Shareholder Website","Self-service"),("Mobile App",""),("Chat",""),("Intermediary Portal",""),("NSCC Networking / Fund/SERV","Intermediary-submitted maintenance")]),
 "Good Order Status": ("Internal", [("In Good Order",""),("Not In Good Order",""),("Pending Review","")]),
 "NIGO Reason": ("Internal", [("Missing Signature",""),("Missing Medallion Signature Guarantee",""),("Missing Legal Documents",""),("Incomplete Form",""),("Account Not Identified",""),("Authority Not Established",""),("Conflicting Instructions","")]),
 "Service Request Status": ("Internal", [("Received",""),("Pending Good Order",""),("In Progress",""),("Pending Third Party",""),("Completed",""),("Rejected",""),("Cancelled","")]),
 "Signature Guarantee Type": ("SEC Rule 17Ad-15 / STAMP", [("Medallion (STAMP)","Securities Transfer Agents Medallion Program"),("Medallion (SEMP)","Stock Exchanges Medallion Program"),("Medallion (MSP)","NYSE Medallion Signature Program"),("Signature Validation Program (SVP)",""),("Notarisation",""),("None Required","")]),
 "Maintained Data Element": ("Internal", [("Mailing Address",""),("Residential Address",""),("Email Address",""),("Phone Number",""),("Account Name / Registration",""),("Beneficiary",""),("Bank Instruction",""),("Rep / Dealer of Record","Normally via NSCC Networking"),("Date of Birth",""),("Tax Certification","Held in 02")]),
 "Ownership Transfer Reason": ("Internal", [("Death of Owner",""),("Divorce / Court Order",""),("Gift",""),("Change of Trustee",""),("Retitling to Trust",""),("Account Consolidation",""),("IRA Distribution In Kind","")]),
 "Estate Document Type": ("Internal", [("Death Certificate",""),("Letters Testamentary",""),("Letters of Administration",""),("Affidavit of Domicile",""),("Small Estate Affidavit",""),("Grant of Probate (UK)",""),("Inheritance Tax Waiver","Certain US states"),("Medallion Guaranteed Letter of Instruction","")]),
 "Standing Instruction Type": ("Internal (aligned to SS&C DST options)", [("Systematic Investment Plan",""),("Systematic Withdrawal Plan",""),("Automatic Exchange",""),("Distribution Option",""),("Dividend Cross-Reinvestment",""),("Required Minimum Distribution","IRA")]),
 "Distribution Option": ("Internal", [("Reinvest",""),("Cash - Cheque",""),("Cash - ACH / Bank Transfer",""),("Dividends Cash, Capital Gains Reinvest",""),("Cross-Reinvest","Into another fund")]),
 "Instruction Status": ("Internal", [("Pending",""),("Active",""),("Suspended",""),("Cancelled",""),("Expired","")]),
 "Contact Reason": ("Internal", [("Account Balance / Value",""),("Transaction Status",""),("Statement / Tax Form Query",""),("Cost Basis Query",""),("Maintenance Request",""),("Estate / Death Notification",""),("Fund Information / Prospectus",""),("Proxy Vote",""),("Shareholder Notice Query",""),("Website / Login Help",""),("Escheatment / Reclaim",""),("Dissatisfaction","Assess as complaint (08)")]),
 "QA Outcome": ("Internal", [("Pass",""),("Pass with Coaching",""),("Fail",""),("Fail - Shareholder Impact","Raise servicing error")]),
 "Servicing Error Type": ("Internal", [("Procedural Error",""),("Data Entry Error",""),("Late Processing",""),("Incorrect Price Applied",""),("NAV Error",""),("As-Of Trade",""),("Misdirected Mail",""),("Privacy Incident",""),("Document Production Error",""),("Tax Form Error","")]),
 "Investor Document Category": ("Internal", [("Periodic Statement",""),("Trade Confirmation",""),("Tax Form",""),("Tax Voucher / Certificate","UK / EU"),("Account Change Confirmation",""),("Due Diligence Letter","Escheatment"),("Unresponsive Payee Notice",""),("Remediation Letter","")]),
 "Document Regulatory Basis": ("Internal", [("SEC Rule 10b-10","Confirmations"),("SEC Rule 17Ad-17","Lost securityholder / unresponsive payee"),("IRC Section 6042 / 6045 / 408","US information returns"),("ERISA / IRA Custodial Agreement",""),("FCA COBS 16","UK periodic reporting / confirmations"),("HMRC","UK tax vouchers"),("State Unclaimed Property Law",""),("Contractual / Prospectus","")]),
 "Delivery Method": ("Internal (aligned to SEC e-delivery guidance)", [("Paper - First Class Mail",""),("Paper - Bulk Mail",""),("Electronic - Email Notification","Notice with link"),("Electronic - Email Attachment",""),("Electronic - Portal Posting",""),("Notice of Internet Availability",""),("Website Availability Only","Where rules permit"),("Intermediary Distribution","Via Broadridge / platform")]),
 "Delivery Status": ("Internal", [("Pending",""),("Sent",""),("Delivered",""),("Email Bounced",""),("Returned Undeliverable",""),("Suppressed",""),("Failed","")]),
 "Document Suppression Reason": ("Internal", [("Householded",""),("E-Delivery Elected",""),("RPO - Undeliverable Address",""),("Mail Hold",""),("Zero Balance / No Activity",""),("Closed Account",""),("Duplicate",""),("Deceased - Pending Estate","")]),
 "Confirmation Timing": ("SEC Rule 10b-10", [("Immediate",""),("Periodic","Allowed for systematic plans and reinvestments, conditions apply"),("Not Required","")]),
 "Investor Tax Document Type": ("IRS / HMRC / Internal", [("1099-DIV","Dividends and distributions"),("1099-B","Proceeds and cost basis"),("1099-R","Retirement distributions"),("1099-INT",""),("5498","IRA contributions and FMV"),("5498-ESA",""),("1099-Q","Coverdell / 529 distributions"),("1042-S","Foreign persons' US source income"),("Form 8937 Reference","Issuer return of capital / corporate action"),("UK Tax Voucher",""),("UK Consolidated Tax Certificate",""),("UK Excess Reportable Income Report",""),("EU Annual Tax Statement","Country-specific")]),
 "Tax Form Version": ("IRS", [("Original",""),("Corrected",""),("Void","")]),
 "Cost Basis Method": ("IRS / IRC 6045", [("Average Cost",""),("FIFO",""),("LIFO",""),("High Cost",""),("Low Cost",""),("Specific Lot Identification",""),("Loss / Gain Utilisation","Tax-sensitive lot relief")]),
 "UK Distribution Type": ("HMRC", [("Dividend Distribution",""),("Interest Distribution",""),("Accumulation - Dividend",""),("Accumulation - Interest","")]),
 "Reconciliation Status": ("Internal", [("Reconciled",""),("Exceptions Open",""),("Not Reconciled","")]),
 "Shareholder Communication Type": ("Internal", [("Tailored Shareholder Report - Annual",""),("Tailored Shareholder Report - Semi-Annual",""),("Annual Report (UCITS / UK)",""),("Half-Yearly Report (UCITS / UK)",""),("Statutory Prospectus",""),("Summary Prospectus",""),("Prospectus Supplement / Sticker",""),("KID (PRIIPs) / KIID (UCITS)",""),("Shareholder Notice",""),("Proxy Materials",""),("Section 19(a) Notice","Sources of distribution"),("Privacy Notice","Content owned by 02")]),
 "Communication Regulatory Basis": ("Internal", [("SEC Rule 30e-1","Shareholder reports"),("SEC Rule 498","Summary prospectus"),("Securities Act Section 5 / 10","Prospectus delivery"),("SEC Rule 35d-1","Names rule 60-day notice"),("Investment Company Act Section 19(a)",""),("SEC Schedule 14A","Proxy"),("UCITS Directive",""),("PRIIPs Regulation",""),("UK FCA COLL",""),("Fund Constitutional Documents","")]),
 "Communication Status": ("Internal", [("Planned",""),("In Preparation",""),("Approved",""),("Filed",""),("Distributing",""),("Distributed",""),("Cancelled","")]),
 "Report Period Type": ("SEC Rule 30e-1", [("Annual",""),("Semi-Annual","")]),
 "Prospectus Delivery Basis": ("SEC Rule 498 / Securities Act", [("Statutory Prospectus",""),("Summary Prospectus",""),("Supplement Only",""),("Not Required","")]),
 "Prospectus Delivery Trigger": ("Internal", [("Initial Purchase",""),("Annual Update to Existing Holders",""),("Supplement",""),("On Request","")]),
 "Shareholder Notice Type": ("Internal", [("Fund Merger / Reorganisation",""),("Fund Liquidation",""),("Name Change",""),("Investment Objective / Policy Change",""),("80% Names Policy Change","SEC Rule 35d-1"),("Fee / Expense Change",""),("Service Provider Change",""),("Share Class Conversion",""),("Fund Closure to New Investors",""),("Dealing Suspension",""),("Distribution Source Notice","Section 19(a)")]),
 "COLL Change Classification": ("UK FCA COLL 4.3", [("Fundamental","Requires unitholder approval by extraordinary resolution"),("Significant","Prior written notice of at least 60 days"),("Notifiable","Inform unitholders appropriately, e.g. next report"),("Not Applicable","Non-UK fund")]),
 "Durable Medium Type": ("UCITS Directive / FCA Glossary", [("Paper",""),("Email / Electronic Document",""),("Website (Consented)","Website conditions met"),("Platform Delivery","")]),
 "Audience Basis": ("Internal", [("Registered Holders",""),("Beneficial Owners via Intermediaries",""),("New Purchasers",""),("Entitled Voters at Record Date",""),("Platform / Nominee Holders","")]),
 "Delivery Election Scope": ("Internal", [("All Documents",""),("Statements",""),("Confirmations",""),("Tax Forms","Separate IRS consent"),("Regulatory Reports and Prospectus",""),("Proxy Materials",""),("Notices","")]),
 "Delivery Preference": ("Internal", [("Electronic",""),("Paper",""),("No Preference","Default rules apply")]),
 "E-Delivery Consent Type": ("SEC E-Delivery Releases (1995 / 1996 / 2000)", [("Informed Affirmative Consent","Document-specific"),("Global Consent","Covers all documents; informed"),("Intermediary-Captured Consent",""),("Telephonic Consent","Recorded and confirmed"),("Not Given","")]),
 "Householding Consent Type": ("SEC Rule 154", [("Written",""),("Implied","No objection within 60 days of notice; existing holders"),("Not Householded","")]),
 "Householding Status": ("Internal", [("Pending Notice Period",""),("Active",""),("Revoked",""),("Not Eligible","")]),
 "Mail Hold Reason": ("Internal", [("Undeliverable Address (RPO)",""),("Shareholder Request",""),("Deceased - Pending Estate",""),("Legal Hold",""),("Fraud Investigation","")]),
 "Meeting Type": ("Internal", [("Special Meeting","US"),("Annual Meeting","Closed-end funds / where required"),("Extraordinary General Meeting","UK / EU"),("Adjourned Meeting",""),("Written Consent in Lieu","")]),
 "Cost Bearer": ("Internal", [("Fund",""),("Adviser",""),("Shared Fund / Adviser",""),("Service Provider",""),("Intermediary","")]),
 "Meeting Status": ("Internal", [("Planned",""),("Soliciting",""),("Adjourned",""),("Held - Concluded",""),("Withdrawn","")]),
 "Fund Proposal Type": ("Investment Company Act 1940 / UK FCA COLL", [("Elect Trustees / Directors",""),("Approve Advisory Agreement","Section 15"),("Approve Sub-Advisory Agreement",""),("Approve Reorganisation",""),("Change Fundamental Investment Policy",""),("Approve 12b-1 Plan",""),("Change Investment Objective",""),("Amend Declaration of Trust / Charter",""),("Fundamental Change (COLL)","UK extraordinary resolution"),("Approve Scheme of Arrangement","UK")]),
 "Vote Standard": ("Investment Company Act 1940 / UK", [("1940 Act Majority","Lesser of 67% of shares present if over 50% present, or over 50% of outstanding"),("Plurality",""),("Simple Majority of Votes Cast",""),("Extraordinary Resolution","UK: 75% of votes cast")]),
 "Proposal Outcome": ("Internal", [("Pending",""),("Approved",""),("Not Approved",""),("Withdrawn","")]),
 "Holding Model": ("Internal", [("Registered (Direct)",""),("Networked","NSCC Networking"),("Street Name / Omnibus",""),("Platform Nominee","UK / EU"),("Retirement Plan Omnibus","")]),
 "NOBO Permitted Use": ("SEC Rule 14b-1", [("Issuer Communications Only",""),("Proxy Solicitation",""),("Not Permitted","")]),
 "Cascade Method": ("Internal", [("Electronic Notice to Platform",""),("Paper Forwarded by Nominee",""),("Made Available on Platform Website",""),("Not Cascaded","")]),
 "Intermediary Communication Fee Type": ("NYSE Rule 451 / FINRA Rule 2251 (verify current schedule)", [("Basic Processing Fee","Per set / position"),("Intermediary Unit Fee",""),("Nominee Coordination Fee",""),("Notice and Access Fee",""),("Preference Management Fee","Suppressed paper"),("NOBO List Fee",""),("Postage and Handling","Pass-through")]),
 "Dormancy Trigger Basis": ("US State Unclaimed Property Laws", [("Owner Inactivity",""),("Returned Mail (RPO)",""),("Uncashed Cheque",""),("Account Maturity / Age","e.g. IRA at required age")]),
 "Escheatment Status": ("Internal", [("Active",""),("Dormancy Clock Running",""),("Presumed Abandoned",""),("Due Diligence Sent",""),("Reported and Remitted",""),("Reactivated",""),("Reclaimed","")]),
 "Remittance Form": ("US State Unclaimed Property Laws", [("Shares in Kind",""),("Liquidated to Cash",""),("Cash Proceeds","Uncashed distributions / redemptions")]),
 "UK Dormant Asset Category": ("Dormant Assets Act 2022", [("CIS Unit Conversion Proceeds",""),("CIS Distributions",""),("CIS Redemption Proceeds",""),("Orphan Moneys","")]),
 "Reclaim Source": ("Internal", [("US State",""),("UK Reclaim Fund",""),("Internal (Pre-Escheat)","")]),
 "Reclaim Status": ("Internal", [("Received",""),("Under Review",""),("Approved",""),("Paid",""),("Rejected","")]),
 "Servicing Provider Role": ("Internal", [("Transfer Agent / Registrar",""),("Contact Centre Operator",""),("Print and Mail Vendor",""),("E-Delivery Vendor",""),("Tax Form Vendor",""),("Proxy Solicitor",""),("Proxy Tabulator",""),("Lost Shareholder Search Vendor",""),("Escheatment Services Vendor","")]),
 "Oversight Rating": ("Internal", [("Satisfactory",""),("Needs Improvement",""),("Unsatisfactory","")]),
 "Metric Unit": ("Internal", [("Seconds",""),("Hours",""),("Business Days",""),("Percent",""),("Count","")]),
 "Servicing Root Cause": ("Internal", [("Manual Processing",""),("System Defect",""),("Third-Party Data",""),("Pricing Source",""),("Procedure Gap",""),("Intermediary Error","")]),
 "Remediation Type": ("Internal", [("Cash Compensation",""),("Unit / Share Adjustment",""),("As-Of Reprocessing",""),("Fund Reimbursement","Fund made whole"),("No Action - De Minimis","")]),
 "Data Quality Status": ("Internal", [("Validated",""),("Pending Validation",""),("Exception",""),("Deprecated","")]),
}

# ---------------------------------------------------------------------------
# Relationships, sources
# ---------------------------------------------------------------------------
REL = [
 ("Account (02 Client & Customer, ACC-)","is subject of","Service Request","1 : 0..n","Cross-domain. Master data changes requested are applied to 02 records."),
 ("Party (02 Client & Customer, PTY-)","raises","Service Request / Contact Centre Interaction","1 : 0..n","Cross-domain. Requester may be owner, representative or financial professional."),
 ("Contact Centre Interaction","creates","Service Request","1 : 0..n",""),
 ("Service Request","results in","Transaction (06 Sales Transactions, TXN-)","1 : 0..n","Cross-domain. Transfers, redemptions, re-registrations."),
 ("Service Request / Contact Centre Interaction","escalates to","Complaint (08 Distribution Compliance, CPL-)","0..n : 0..1","Cross-domain. Complaint handling owned by 08."),
 ("Account","has","Account Standing Instruction","1 : 0..n","Generated transactions are owned by 06."),
 ("Service Request / Contact Centre Interaction","is checked by","QA Review","1 : 0..n",""),
 ("Investor Document Definition","is produced in","Production Run","1 : 0..n",""),
 ("Production Run","produces","Investor Document","1 : 1..n",""),
 ("Investor Document (Confirmation)","confirms","Transaction (06, TXN-)","n : 1","Cross-domain."),
 ("Account","has","Cost Basis Election","1 : 0..n","Effective-dated."),
 ("Shareholder Communication","delivers","Product Document (01 Product)","n : 0..1","Cross-domain. Document metadata owned by 01."),
 ("Lifecycle Event (01 Product)","triggers","Shareholder Communication (Notice)","1 : 0..n","Cross-domain. Mergers, liquidations, renames, objective changes."),
 ("Shareholder Communication","is distributed by","Communication Distribution","1 : 1..n","Registered-holder path."),
 ("Shareholder Communication","is distributed by","Intermediary Distribution Request","1 : 0..n","Beneficial-owner path via intermediaries / platforms."),
 ("Communication Distribution","results in","Recipient Delivery Record","1 : 0..n",""),
 ("Account","has","E-Delivery Election","1 : 0..n","By document scope; effective-dated."),
 ("E-Delivery Election","references","Consent Record (02, CNS-)","n : 0..1","Cross-domain. Legal basis owned by 02; marketing preferences owned by 04."),
 ("E-Delivery Election","uses","Contact Point (02)","n : 1","Cross-domain."),
 ("Householding Group","groups","Account (02, ACC-)","1 : 2..n",""),
 ("Proxy Campaign","is held by","Investment Product (01, PRD-)","n : 1","Cross-domain."),
 ("Proxy Campaign","contains","Proxy Proposal","1 : 1..n",""),
 ("Proxy Proposal","is counted in","Vote Tally","1 : 0..n","Running and final tallies."),
 ("Proxy Campaign","is distributed as","Shareholder Communication (Proxy Materials)","1 : 1..n",""),
 ("Intermediary Distribution Request","is made to","Party (02) - Intermediary / Agent","n : 1","Cross-domain."),
 ("Intermediary Communication Fee Invoice","bills","Intermediary Distribution Request / Proxy Campaign","1 : 1..n",""),
 ("Intermediary Communication Fee Invoice","may be governed by","Agreement (05 Distribution Agreements, AGR-)","n : 0..1","Cross-domain, only where rates are contractual; accounting in 10."),
 ("Account","has","Lost Shareholder Status","1 : 0..1",""),
 ("Lost Shareholder Status","feeds","Dormancy Assessment","1 : 0..n",""),
 ("Dormancy Assessment","is reported in","Escheatment Report","n : 0..1",""),
 ("Escheatment Report / UK Dormant Asset Transfer","may be reversed by","Unclaimed Property Reclaim","1 : 0..n",""),
 ("Servicing Provider Engagement","is measured by","Service Level Definition","1 : 0..n",""),
 ("Service Level Definition","has","Service Level Measurement","1 : 0..n","One per period."),
 ("Servicing Error","is corrected by","Transaction (06, TXN-) - as-of / correction","1 : 0..n","Cross-domain."),
 ("Servicing Error","is remediated by","Shareholder Remediation","1 : 0..n","One per affected account."),
 ("Servicing Provider Engagement","references","Product Party Role (01 Product)","n : 0..1","Cross-domain. The fund's appointed TA is recorded in 01; oversight here."),
]

SRC = [
 ("SEC Tailored Shareholder Reports final rule (Release 33-11125, 2022; compliance date 24 July 2024)","US SEC","https://www.sec.gov/files/rules/final/2022/33-11125.pdf","Regulation","Tailored annual / semi-annual reports, Form N-CSR website availability, exclusion of N-1A funds from Rule 30e-3","Tailored Shareholder Report, Communication Master",["SEC Rule 30e-1","SEC Form N-CSR","SEC Form N-1A"]),
 ("SEC Rule 498 (summary prospectus) and Schedule 14A / Rule 14a-16 (proxy and notice-and-access)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-230/section-230.498","Regulation","Summary prospectus delivery and website conditions; proxy statement content and notice of internet availability","Prospectus Delivery, Proxy Campaign, Communication Distribution",["SEC Rule 498","SEC Schedule 14A","SEC Rule 14a-16"]),
 ("SEC Rule 154 householding (Release 33-7912, 2000)","US SEC","https://www.sec.gov/rules/final/33-7912.htm","Regulation","Householding of prospectuses and reports; written vs implied consent; 60-day notice; annual revocation notice","Householding",["SEC Rule 154"]),
 ("SEC electronic delivery interpretive releases (33-7233, 1995; 33-7288, 1996; 33-7856, 2000)","US SEC","https://www.sec.gov/files/rules/interp/33-7288.txt","Interpretive guidance","Notice, access, evidence of delivery; informed and global consent","E-Delivery Election, Delivery Method",["SEC E-Delivery Releases"]),
 ("SEC Rule 17Ad-17 lost securityholders and unresponsive payees (Release 34-68668, 2013)","US SEC","https://www.sec.gov/rules/final/2013/34-68668.pdf","Regulation","Database searches for lost securityholders; unresponsive payee notice within seven months","Lost Shareholder Status, Account Maintenance",["SEC Rule 17Ad-17"]),
 ("SEC transfer agent rules (Rules 17Ad-2, 17Ad-7, 17Ad-15; Form TA-1) and Rule 10b-10 confirmations","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-240","Regulation","TA turnaround, recordkeeping, signature guarantees, registration; customer confirmations","Service Request, Trade Confirmation, Servicing Provider",["SEC Rule 17Ad-*","SEC Rule 10b-10","SEC Form TA-1","SEC Rule 17a-4","SEC Rule 38a-1","SEC Rule 31a-2","SEC Regulation S-P"]),
 ("SEC Rules 14a-13 and 14b-1; NYSE Rule 451/452; FINRA Rule 2251","US SEC; NYSE; FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2251","Regulation / SRO rules","Broker searches, beneficial-owner distribution, NOBO lists, reimbursement rates, broker discretionary voting","Intermediary Distribution, NOBO List, Fee Invoice, Beneficial Owner Voting",["SEC Rule 14a-13","SEC Rule 14b-1","NYSE Rule 45*","FINRA Rule 2251"]),
 ("Broadridge Financial Solutions Form 10-K (description of beneficial-owner proxy and communications distribution)","Broadridge","https://www.sec.gov/Archives/edgar/data/1383312/000138331224000039/br-20240630.htm","Public filing","Role of intermediary agent, fee collection and remittance to nominees","Intermediary Distribution, Voting Channel",["Broadridge"]),
 ("Investment Company Act of 1940 (Sections 2(a)(42), 15, 19(a)) and SEC Rule 35d-1","US SEC / US Congress","https://www.sec.gov/about/divisions-offices/division-investment-management","Statute / regulation","1940 Act majority vote, advisory contract approval, distribution source notices, names-rule notice","Proxy Proposal, Shareholder Notice",["Investment Company Act 1940","SEC Rule 35d-1"]),
 ("IRS General Instructions for Certain Information Returns; Forms 1099-DIV, 1099-B, 1099-R, 5498; IRC Section 6045 cost basis","US IRS","https://www.irs.gov/pub/irs-pdf/i1099gi.pdf","Regulation / guidance","Furnish and filing deadlines, corrected returns, truncation, cost-basis reporting for covered mutual fund shares","Tax Form Record, Cost Basis Election, Document Definition",["IRS*","IRC Section 6045"]),
 ("HMRC guidance on fund distributions, equalisation and offshore reporting funds","HMRC","https://www.gov.uk/hmrc-internal-manuals/investment-funds","Guidance","Tax vouchers, distribution types, equalisation, excess reportable income","UK & EU Tax Document",["HMRC"]),
 ("UCITS Directive 2009/65/EC, Chapter IX (Articles 68-82) and Article 43 (merger information)","European Union / ESMA","https://www.esma.europa.eu/publications-and-data/interactive-single-rulebook/ucits/article-75","Regulation","Annual / half-yearly reports, provision of prospectus and KIID free of charge, durable medium, merger information","Communication Master, Shareholder Notice, Investor Information Provision",["UCITS Directive","PRIIPs Regulation"]),
 ("FCA Handbook COLL 4.3 (approvals and notifications), COLL 6.6, COBS 16 and Glossary (durable medium)","UK FCA","https://handbook.fca.org.uk/handbook/COLL/4/3.html","Regulation","Fundamental / significant / notifiable changes, 60-day notice, unitholder meetings, pricing error handling","Shareholder Notice, Proxy Proposal, Servicing Error",["UK FCA*"]),
 ("Dormant Assets Act 2022 and Dormant Assets Scheme expansion to investment and wealth management","UK Government; Reclaim Fund Ltd","https://www.legislation.gov.uk/ukpga/2022/5/contents","Statute","Eligible collective-investment assets, gone-away periods, transfer to reclaim fund, full restitution on reclaim","UK Dormant Asset Transfer, Reclaim",["Dormant Assets Act 2022"]),
 ("NAUPA standard reporting format and property codes; US state unclaimed property laws","NAUPA (National Association of State Treasurers); US states","https://unclaimed.org/reporting/","Public standard / state law","Holder reporting format, property type codes, dormancy periods, due diligence","Dormancy Assessment, Escheatment Report",["NAUPA II","US State Unclaimed Property Laws"]),
 ("AICPA SOC 1 / IAASB ISAE 3402","AICPA; IAASB","https://www.aicpa-cima.com/topic/audit-assurance/audit-and-assurance-greater-than-soc-1","Standard","Service organisation controls reporting used in TA oversight","Servicing Provider Engagement",["AICPA SOC 1","ISAE 3402"]),
 ("SS&C DST TA2000 / NSCC Networking record layouts (vendor practice)","SS&C Technologies; DTCC","https://www.dtcc.com/wealth-management-services/mutual-fund-services","Licensed / member documentation","Work types, good-order processing, account options, networking maintenance","Service Request, Standing Instructions",["SS&C DST","NACHA"]),
 ("EU GDPR / UK GDPR; FCA DISP; FINRA Rules 2165 and 4530","European Union; UK FCA; FINRA","https://eur-lex.europa.eu/eli/reg/2016/679/oj","Regulation","Personal data handling; complaint identification in servicing interactions; senior investor holds","Data Management Metadata, Contact Centre Interaction",["EU GDPR","FCA DISP","FINRA Rule 2165","FINRA Rule 4530"]),
 ("ICI resources on shareholder servicing, tax reporting and fund operations","Investment Company Institute","https://www.ici.org","Free","Industry practice for distribution reclassification and fund operations","Tax Form Record",["ICI"]),
 ("DCAM","EDM Council","https://edmcouncil.org","Member framework","Data ownership and stewardship","Data Management Metadata",["DCAM*"]),
]
