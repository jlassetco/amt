"""Business domain 14 - Third-Party Data & Licensing. Content module for taxonomy_builder.py."""

META = {
 "title": "Third-Party Data & Licensing Data Taxonomy",
 "subtitle": "Business domain 14 - Third-Party Data & Licensing | Asset manager (wholesale distributor) | Scope: US + EU/UK | Draft v0.1 | 2026-10-01",
 "output": "14_Third_Party_Data_and_Licensing/Third_Party_Data_and_Licensing_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the third-party data and licensing domain of an asset manager that distributes wholesale and relies on licensed external data: advisor and firm databases (Discovery Data, Broadridge, FINTRX), distribution and sales data (Broadridge Distribution Insight, ISS Market Intelligence), fund data and ratings (Morningstar, LSEG Lipper, FE fundinfo), index data and index licences (MSCI, S&P DJI, FTSE Russell, Bloomberg), consultant databases (Nasdaq eVestment), intent and marketing data (Bombora, ZoomInfo), market data (Bloomberg, LSEG) and ESG data. It defines what we buy, from whom, under which rights, who may use it, what it costs, and how compliance, vendor risk and data quality are managed. It draws on market data policy practice (FISD), regulation (EU BMR as amended by Regulation (EU) 2025/914, DORA and its register-of-information ITS, UK FCA operational resilience), assurance standards (AICPA SOC 2, ISO/IEC 27001) and data management frameworks (EDM Council DCAM and CDMC). Use it as a starting point for a data-licence inventory, an entitlement and usage system, a vendor management data model or a data catalogue."),
  ("Scope", "In scope: data vendor relationships (vendor role on a PTY- party, contacts, relationship owner, strategic tier, performance reviews); vendor risk and third-party risk management for data vendors (due diligence, SOC 2 / ISO 27001 evidence, DORA ICT third-party register fields for EU entities, UK operational resilience mapping); the dataset and data product catalogue (DSET-) with coverage, granularity, frequency, delivery, identifiers, history and lineage to consuming business domains; data licence agreements we purchase (DLA-) with licensed scope, licence model, term, renewal, termination, data destruction, audit and attribution clauses; permitted-use rights (display, non-display, derived data, redistribution, client reporting, marketing, index-tracking products, AI/ML); index and benchmark licensing (benchmark use, index-tracking product licences, AUM-based fees, BMR status of the index used); entitlements (ENT-) and the non-display application inventory; usage declarations, licence audits, findings and true-ups; data cost (contract value, invoices, cost allocation to OU-, renewals and optimisation); vendor data quality, SLAs and data challenges. Out of scope (referenced by ID only): party master, vendor legal identifiers and vendor contacts as persons (02 Client & Customer: PTY-); benchmarks, products and share classes (01 Product: BMK-, PRD-, SHC-); data-sharing and data-licensing agreements with distribution partners, and data fees paid to distributors (05 Distribution Agreements & Partners: AGR-); technical feeds, loads and the data received (06 Sales Transactions & AUM Attribution: FEED-); submissions we make to consultant databases (03 Sales: DBS-); intent signals and lead scores (04 Marketing & Digital); personnel licences (08 Distribution Compliance: LIC-); internal legal entities and org units (09 Shared Reference Data: LEN-, OU-); distribution cost accounting, accruals and allocation methods (10 Distribution Finance: ALM-, DCO-); the ratings, peer and market-share values themselves (11 Market & Competitive Intelligence); consultant data requests on mandates (12)."),
  ("Structure", "Four levels: Domain > Subdomain > Concept > Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Data Vendor (a PTY- party in the vendor role) -> Data Licence Agreement (DLA-, master agreement with order forms / schedules) -> Licensed Dataset Schedule (which DSET- datasets, territory, entities, user and application counts) -> Permitted Use Grants (display, non-display, derived, redistribution, client reporting, marketing, index-tracking, AI/ML) -> Entitlements (ENT-) of users and Consuming Applications (DAPP-) -> Usage Declarations (UDC-) and Licence Audits (LAU-) with findings and true-ups. Datasets (DSET-) are delivered through technical feeds (06 FEED-) and consumed by business domains (Dataset Consumption). Index licences are DLA- records of type Index Licence Agreement with Index Use and Product Licence Coverage (BMK- -> PRD-/SHC-). Commercials: Commercial Terms -> Data Invoices (DINV-) -> Cost Allocations to OU- -> Renewal Cases (RNW-). Assurance: Vendor Risk Assessments (VRA-), Assurance Reports and the ICT Third-Party Register Entry. Quality: Vendor Data SLAs and Vendor Data Issues (VDI-)."),
  ("Design principles", "1) A vendor is a party: vendor identity, LEI and contacts as persons are mastered in 02; this domain holds only the vendor relationship. 2) Rights are data, not prose: every permitted use is a coded grant with a status (permitted, conditional, prohibited, silent), so a use case can be checked against the licence before data is used. 3) One dataset, many feeds and consumers: the DSET- catalogue sits between the commercial licence and the technical feed (06 FEED-), so lineage runs vendor -> licence -> dataset -> feed -> consuming domain. 4) Effective-date grants, scopes, entitlements, allocations and coverage. 5) Hold contract facts once on the DLA- and derive notice deadlines and renewal pipeline from them. 6) Use FISD terminology (display, non-display, derived data) so that vendor policies can be compared. 7) Flag Critical Data Elements (CDE) for governance focus."),
  ("Applies To", "Shows the record type each attribute is held on: Vendor, Vendor Contact Role, Vendor Review, Risk Assessment, Assurance Report, ICT Register Entry, Dataset, Dataset Field, Dataset Delivery, Dataset Consumption, Agreement, Licensed Scope, Permitted Use Grant, Attribution Requirement, Index Use, Index Product Coverage, Entitlement, Consuming Application, Usage Declaration, Licence Audit, Audit Finding, Commercial Terms, Data Invoice, Cost Allocation, Renewal Case, Vendor SLA, Vendor Data Issue or All."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify a dataset or licence, prove the right to use data, meet a regulatory register obligation (DORA, BMR), pay or allocate data cost correctly, or manage the renewal and termination deadlines. Confirm with data owners."),
  ("Primary / Secondary Reference", "Standard or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Vendor references (Bloomberg, MSCI, Morningstar, Snowflake) reflect public descriptions of common licence and delivery models, not the terms of any specific contract. DORA register fields are aligned at concept level to Commission Implementing Regulation (EU) 2024/2956; map to the exact template column codes during implementation."),
  ("Tabs", "Hierarchy: domains, subdomains and concepts with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: concept-level cardinalities for the logical model, including references to other business domains | Sources: regulations, standards, frameworks and vendor material used, with owners, licences and links."),
  ("Suggested next steps", "1) Validate domains, permitted-use categories and CDEs with Market Data / Data Office, Procurement, Legal, Vendor Risk, Index/ETF Product, Distribution Analytics, Marketing and Finance. 2) Build the first inventory: top 25 vendors, their DLA- agreements, licensed datasets and renewal dates. 3) Have Legal interpret the permitted-use grants for the five highest-risk uses (redistribution to distributors, client reporting, marketing materials, index-tracking products, AI/ML). 4) Agree with 06 that purchased vendor feeds reference DLA- (not AGR-) and that the FEED- 'Licence Use Restriction' is replaced by a reference to the grants here. 5) Agree with 05 the boundary for data bought from distributors versus vendors. 6) Agree with Enterprise Risk whether the DORA register is mastered here for data vendors or in an enterprise TPRM tool. 7) Agree with 10 the hand-off of invoices and allocations to accounting. 8) Map attributes to source systems (contract lifecycle management, procurement / AP, entitlement tool such as a market data inventory platform, data catalogue, TPRM tool)."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

D("Data Vendor Relationship", "TD-VND",
  "The firm's relationship with each external provider of licensed data: vendor role, contacts, ownership, strategic tier and periodic performance governance. The vendor itself is a party mastered in 02.",
  [
   ("Vendor Profile", "Vendor role and relationship attributes held for a party that supplies data to the firm.", [
     ("Data Vendor", [
       ("Vendor Party", "Party reference of the data vendor legal entity (identity, LEI and addresses are mastered in 02).", "Vendor", "Reference (Party)", "", "PTY-500210", "Internal", "", "Y"),
       ("Vendor Display Name", "Short commercial name used in catalogues and reports.", "Vendor", "Text", "", "Morningstar", "Internal", "", ""),
       ("Vendor Type", "Primary type of data vendor.", "Vendor", "Code", "Vendor Type", "Fund Data & Ratings Provider", "Internal", "", "Y"),
       ("Vendor Group", "Ultimate parent or group of the vendor, used to aggregate spend and concentration risk.", "Vendor", "Reference (Party)", "", "PTY-500001 (LSEG)", "Internal", "", ""),
       ("Vendor Subject Areas", "Subject areas the vendor supplies to the firm.", "Vendor", "Code (multi)", "Dataset Subject Area", "Fund Data; Ratings; ESG", "Internal", "", ""),
       ("Vendor Relationship Status", "Lifecycle status of the relationship.", "Vendor", "Code", "Vendor Relationship Status", "Active", "Internal", "", ""),
       ("Strategic Tier", "Importance of the vendor to the firm, driving governance intensity and review frequency.", "Vendor", "Code", "Vendor Strategic Tier", "Tier 1 - Strategic", "Internal", "US Interagency TPRM Guidance", "Y"),
       ("Relationship Owner", "Internal person accountable for the vendor relationship.", "Vendor", "Reference (Employee)", "", "EMP-01877", "Internal", "DCAM", "Y", "Enterprise workforce master not yet agreed (see §8 row 09); EMP- used provisionally."),
       ("Procurement Supplier ID", "Supplier number of the vendor in the procurement / accounts payable system.", "Vendor", "Identifier", "External (Procurement system)", "SUP-0045521", "Internal", "", ""),
     ]),
     ("Vendor Contact Role", [
       ("Vendor Contact", "Party reference of the individual at the vendor (person mastered in 02).", "Vendor Contact Role", "Reference (Party)", "", "PTY-500877", "Internal", "", "", "PII"),
       ("Vendor Contact Role Type", "Role the individual plays for the firm.", "Vendor Contact Role", "Code", "Vendor Contact Role", "Account Manager", "Internal", "", ""),
       ("Primary Contact Indicator", "Whether this is the primary contact for the role.", "Vendor Contact Role", "Boolean", "", "Y", "Internal", "", ""),
       ("Contact Role Effective From", "Date the contact took on the role.", "Vendor Contact Role", "Date", "ISO 8601", "2025-01-15", "Internal", "", ""),
       ("Contact Role Effective To", "Date the contact left the role.", "Vendor Contact Role", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Vendor Performance Governance", "Periodic business review of the vendor's service, commercial position and open issues.", [
     ("Vendor Performance Review", [
       ("Review Date", "Date of the vendor business review.", "Vendor Review", "Date", "ISO 8601", "2026-06-20", "Internal", "", ""),
       ("Review Period", "Period the review covers.", "Vendor Review", "Text", "Firm-defined", "2026-H1", "Internal", "", ""),
       ("Overall Performance Rating", "Overall assessment of the vendor in the period.", "Vendor Review", "Code", "Performance Rating", "Meets Expectations", "Internal", "", ""),
       ("Next Review Date", "Scheduled date of the next review, set by strategic tier.", "Vendor Review", "Date", "ISO 8601", "2026-12-15", "Internal", "", ""),
     ]),
   ]),
  ])

D("Vendor Risk & Resilience", "TD-TPR",
  "Third-party risk management for data vendors: due diligence and periodic risk assessments, assurance evidence (SOC 2, ISO/IEC 27001), and the regulatory third-party registers and resilience mappings (DORA for EU entities, UK operational resilience).",
  [
   ("Vendor Risk Assessment", "Due diligence and periodic risk assessment of a data vendor or a specific service.", [
     ("Vendor Risk Assessment", [
       ("Risk Assessment ID", "Unique identifier of the vendor risk assessment.", "Risk Assessment", "Identifier", "", "VRA-002311", "Internal", "", "Y"),
       ("Assessed Vendor", "Vendor being assessed.", "Risk Assessment", "Reference (Party)", "", "PTY-500210", "Internal", "", ""),
       ("Assessment Type", "Trigger and stage of the assessment.", "Risk Assessment", "Code", "Risk Assessment Type", "Periodic Review", "US Interagency TPRM Guidance", "", ""),
       ("Risk Domains Assessed", "Risk areas covered by the assessment.", "Risk Assessment", "Code (multi)", "Vendor Risk Domain", "Information Security; Business Continuity; Data Privacy", "US Interagency TPRM Guidance", "DORA", ""),
       ("Inherent Risk Rating", "Risk before controls, driven by criticality, data sensitivity and substitutability.", "Risk Assessment", "Code", "Risk Rating", "High", "Internal", "", ""),
       ("Residual Risk Rating", "Risk after considering the vendor's controls and the firm's mitigants.", "Risk Assessment", "Code", "Risk Rating", "Medium", "Internal", "", "Y"),
       ("Personal Data Processed Indicator", "Whether the service involves the vendor processing personal data for the firm, or supplies personal data (e.g. advisor contact data).", "Risk Assessment", "Boolean", "", "Y", "GDPR", "", "Y", "Drives DPA / controller-controller terms and privacy review."),
       ("Substitutability", "How readily the vendor or dataset could be replaced.", "Risk Assessment", "Code", "Substitutability", "Difficult", "DORA RoI ITS", "", ""),
       ("Exit Strategy Documented Indicator", "Whether a documented exit plan exists for the service.", "Risk Assessment", "Boolean", "", "Y", "DORA", "", ""),
       ("Next Assessment Due Date", "Date the next periodic assessment is due.", "Risk Assessment", "Date", "ISO 8601", "2027-04-30", "Internal", "", "Y"),
     ]),
   ]),
   ("Assurance Evidence", "Independent assurance reports and certifications obtained from the vendor.", [
     ("Assurance Report", [
       ("Assurance Report Type", "Type of report or certificate received.", "Assurance Report", "Code", "Assurance Report Type", "SOC 2 Type II", "AICPA SOC 2", "ISO/IEC 27001", "Y"),
       ("Trust Services Categories Covered", "AICPA Trust Services Criteria categories in scope of a SOC 2 report (Security is always included).", "Assurance Report", "Code (multi)", "Trust Services Category", "Security; Availability; Confidentiality", "AICPA SOC 2", "", ""),
       ("Report Period Start", "Start of the period covered (Type II) or the as-of date (Type I).", "Assurance Report", "Date", "ISO 8601", "2025-07-01", "AICPA SOC 2", "", ""),
       ("Report Period End", "End of the period covered.", "Assurance Report", "Date", "ISO 8601", "2026-06-30", "AICPA SOC 2", "", ""),
       ("Auditor Opinion", "Opinion given by the service auditor.", "Assurance Report", "Code", "Auditor Opinion", "Unqualified", "AICPA SOC 2", "", ""),
       ("Exceptions Noted Indicator", "Whether testing exceptions were reported.", "Assurance Report", "Boolean", "", "N", "AICPA SOC 2", "", ""),
     ]),
   ]),
   ("ICT Third-Party Register & Resilience", "Fields needed to report data vendors in the DORA register of information (EU entities) and to map them to UK important business services.", [
     ("ICT Third-Party Register Entry", [
       ("DORA In-Scope Indicator", "Whether the arrangement is an ICT service to an EU financial entity of the group and must appear in its DORA register of information.", "ICT Register Entry", "Boolean", "", "Y", "DORA", "DORA RoI ITS", "Y"),
       ("Reporting Financial Entity", "Internal legal entity (e.g. Luxembourg ManCo) whose register includes the arrangement.", "ICT Register Entry", "Reference (Legal Entity)", "", "LEN-0012", "DORA RoI ITS", "", "Y"),
       ("Contractual Arrangement Reference", "Reference number of the contractual arrangement as reported in the register; normally the DLA- ID.", "ICT Register Entry", "Identifier", "", "DLA-000184", "DORA RoI ITS", "", ""),
       ("ICT Service Type", "Type of ICT service as classified in the register taxonomy.", "ICT Register Entry", "Code", "External (DORA RoI ICT service taxonomy)", "Data analysis / data provision service", "DORA RoI ITS", "", ""),
       ("Supports Critical or Important Function", "Whether the service supports a critical or important function of the entity.", "ICT Register Entry", "Boolean", "", "N", "DORA", "DORA RoI ITS", "Y"),
       ("Supported Functions", "Business functions supported by the service.", "ICT Register Entry", "Text", "", "Index-tracking portfolio management; NAV benchmark comparison", "DORA RoI ITS", "", ""),
       ("Data Storage Locations", "Countries where the vendor stores the firm's data.", "ICT Register Entry", "Code (multi)", "ISO 3166-1 alpha-2", "US; IE", "DORA RoI ITS", "", ""),
       ("Material Subcontractors", "Material subcontractors (fourth parties) in the ICT supply chain.", "ICT Register Entry", "Reference (Party)", "", "PTY-500990 (cloud host)", "DORA RoI ITS", "", ""),
       ("UK Important Business Service Mapping", "UK important business services that depend on the vendor service.", "ICT Register Entry", "Code (multi)", "Firm-defined", "Fund dealing and pricing; Client reporting", "UK FCA SYSC 15A", "", ""),
       ("Impact Tolerance Dependency Indicator", "Whether a vendor outage could breach a UK impact tolerance.", "ICT Register Entry", "Boolean", "", "N", "UK FCA SYSC 15A", "", ""),
     ]),
   ]),
  ])

D("Dataset & Data Product Catalogue", "TD-DST",
  "Catalogue of every licensed dataset and data product (DSET-): what it contains, coverage, structure, delivery, identifiers and the business domains that consume it.",
  [
   ("Dataset Definition", "Identity, classification and ownership of a dataset.", [
     ("Dataset", [
       ("Dataset ID", "Unique identifier of the dataset or data product.", "Dataset", "Identifier", "", "DSET-00412", "Internal", "DCAM", "Y"),
       ("Dataset Name", "Business name of the dataset.", "Dataset", "Text", "", "Discovery Data - Advisor Intelligence (US)", "Internal", "", "Y"),
       ("Dataset Vendor", "Vendor supplying the dataset.", "Dataset", "Reference (Party)", "", "PTY-500311", "Internal", "", "Y"),
       ("Vendor Product Code", "Vendor's product or package code, as shown on order forms.", "Dataset", "Identifier", "External (Vendor)", "MS-GFU-EQ", "Internal", "", ""),
       ("Dataset Description", "Narrative description of the content and intended use.", "Dataset", "Text", "", "Advisor, team and branch profiles with contact data, AUM estimates and product usage", "Internal", "", ""),
       ("Dataset Subject Area", "Primary subject area of the dataset.", "Dataset", "Code", "Dataset Subject Area", "Advisor & Firm Data", "Internal", "", "Y"),
       ("Data Basis", "Whether values are reported, estimated, modelled or survey-based.", "Dataset", "Code", "Data Basis", "Estimated", "Internal", "", ""),
       ("Contains Personal Data Indicator", "Whether the dataset includes personal data (e.g. advisor names, emails, phone numbers).", "Dataset", "Boolean", "", "Y", "GDPR", "CDMC", "Y", "Drives privacy notices, legal basis and retention."),
       ("Information Sensitivity", "Sensitivity classification of the dataset inside the firm.", "Dataset", "Code", "Information Classification", "Confidential", "CDMC", "", ""),
       ("Dataset Status", "Lifecycle status of the dataset in the catalogue.", "Dataset", "Code", "Dataset Status", "In Production", "Internal", "", ""),
       ("Dataset Business Owner", "Internal person accountable for the dataset's use and value.", "Dataset", "Reference (Employee)", "", "EMP-02231", "DCAM", "", ""),
     ]),
   ]),
   ("Coverage & Structure", "Universe, geography, granularity, frequency and history of a dataset.", [
     ("Dataset Coverage", [
       ("Geographic Coverage", "Countries covered by the dataset.", "Dataset", "Code (multi)", "ISO 3166-1 alpha-2", "US", "Internal", "", ""),
       ("Covered Entity Types", "Kinds of entity the dataset describes.", "Dataset", "Code (multi)", "Covered Entity Type", "Advisors; Branches; Firms", "Internal", "", ""),
       ("Universe Description", "Description of the universe covered.", "Dataset", "Text", "", "All FINRA-registered reps and SEC/state RIAs", "Internal", "", ""),
       ("Data Granularity", "Lowest level of detail delivered.", "Dataset", "Code", "Data Granularity", "Advisor", "Internal", "", "Y"),
       ("Update Frequency", "How often the vendor refreshes the data.", "Dataset", "Code", "Frequency", "Monthly", "Internal", "", ""),
       ("Data Latency", "Lag between the as-of date and availability.", "Dataset", "Text", "T+n", "T+20", "Internal", "", ""),
       ("Licensed History Depth", "Years of history the firm is licensed to receive and retain.", "Dataset", "Integer", "Years", "10", "Internal", "", ""),
     ]),
     ("Dataset Key Field", [
       ("Field Name", "Name of a key field in the vendor's data dictionary.", "Dataset Field", "Text", "", "RepCRD", "Internal", "", ""),
       ("Field Business Definition", "Business definition of the field.", "Dataset Field", "Text", "", "FINRA CRD number of the representative", "Internal", "", ""),
       ("Identifier Scheme", "Identifier scheme the field carries, used for matching to firm masters.", "Dataset Field", "Code", "Identifier Scheme", "FINRA CRD", "Internal", "", ""),
       ("Match Target Concept", "Firm concept the identifier is matched to.", "Dataset Field", "Text", "Firm-defined", "Party (02) - Advisor", "Internal", "", ""),
     ]),
   ]),
   ("Delivery", "How the dataset reaches the firm.", [
     ("Dataset Delivery", [
       ("Delivery Method", "Channel through which the data is delivered.", "Dataset Delivery", "Code", "Delivery Method", "Cloud Data Share", "Internal", "Snowflake Marketplace", "Y"),
       ("Delivery Format", "Format of the delivered data.", "Dataset Delivery", "Code", "Delivery Format", "Database Table / View", "Internal", "", ""),
       ("Technical Feed", "Technical feed that implements the delivery (owned by 06).", "Dataset Delivery", "Reference (Feed)", "", "FEED-031", "Internal", "", "Y"),
       ("Marketplace Listing / Share Name", "Cloud marketplace listing or share name, where delivered by data sharing.", "Dataset Delivery", "Text", "", "DISCOVERY_DATA.ADVISOR_INTEL_US", "Snowflake Marketplace", "", ""),
     ]),
   ]),
   ("Dataset Consumption & Lineage", "Which business domains, applications and use cases consume each dataset, under which permitted use.", [
     ("Dataset Consumption", [
       ("Consumed Dataset", "Dataset consumed.", "Dataset Consumption", "Reference (Dataset)", "", "DSET-00412", "Internal", "CDMC", ""),
       ("Consuming Business Domain", "Business domain whose concepts are populated or enriched by the dataset.", "Dataset Consumption", "Code", "Consuming Business Domain", "02 Client & Customer", "Internal", "DCAM", "Y"),
       ("Consuming Application", "Application that consumes the dataset.", "Dataset Consumption", "Reference (Consuming Application)", "", "DAPP-0042", "Internal", "", ""),
       ("Target Concept", "Concept or attribute populated in the consuming domain.", "Dataset Consumption", "Text", "", "02 Financial Professional Profile / Practice AUM", "Internal", "CDMC", ""),
       ("Use Case", "Business use the consumption supports.", "Dataset Consumption", "Code", "Use Case", "Advisor Targeting & Segmentation", "Internal", "", ""),
       ("Covering Permitted Use", "Permitted-use category under which the consumption is licensed.", "Dataset Consumption", "Code", "Permitted Use Category", "Internal Use - Non-Display", "FISD", "", "Y"),
       ("Authoritative Source Indicator", "Whether the dataset is the authoritative source for the target attribute.", "Dataset Consumption", "Boolean", "", "N", "CDMC", "DCAM", ""),
       ("Consumption Effective From", "Date the consumption began.", "Dataset Consumption", "Date", "ISO 8601", "2023-02-01", "Internal", "", ""),
       ("Consumption Effective To", "Date the consumption ended.", "Dataset Consumption", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

D("Data Licence Agreement", "TD-LIC",
  "Agreements under which the firm purchases data (DLA-): header, licensed scope, term and renewal, termination and data destruction, audit and reporting clauses.",
  [
   ("Agreement Header", "Identity, parties, type and term of a data licence agreement or order form.", [
     ("Data Licence Agreement", [
       ("Data Licence Agreement ID", "Unique identifier of the agreement or order form.", "Agreement", "Identifier", "", "DLA-000184", "Internal", "", "Y"),
       ("Agreement Name", "Name of the agreement.", "Agreement", "Text", "", "Morningstar Data Order Form 2026 - Global Fund Data", "Internal", "", ""),
       ("Licensor", "Vendor granting the licence.", "Agreement", "Reference (Party)", "", "PTY-500210", "Internal", "", "Y"),
       ("Licensee Legal Entity", "Internal legal entity that signs and holds the licence.", "Agreement", "Reference (Legal Entity)", "", "LEN-0001", "Internal", "", "Y"),
       ("Agreement Type", "Contractual type of the document.", "Agreement", "Code", "Data Agreement Type", "Order Form / Schedule", "Internal", "", ""),
       ("Parent Agreement", "Master agreement under which an order form or schedule is issued.", "Agreement", "Reference (Data Licence Agreement)", "", "DLA-000100", "Internal", "", ""),
       ("Licence Model", "Basis on which the licence is granted and priced.", "Agreement", "Code", "Licence Model", "Enterprise", "Internal", "Bloomberg", "Y"),
       ("Agreement Status", "Lifecycle status of the agreement.", "Agreement", "Code", "Agreement Status", "Active", "Internal", "", ""),
       ("Agreement Effective Date", "Date the licence term starts.", "Agreement", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Current Term End Date", "Date the current term ends.", "Agreement", "Date", "ISO 8601", "2027-12-31", "Internal", "", "Y"),
       ("Auto-Renewal Indicator", "Whether the agreement renews automatically unless notice is given.", "Agreement", "Boolean", "", "Y", "Internal", "", ""),
       ("Non-Renewal Notice Period", "Notice required to prevent automatic renewal.", "Agreement", "Integer", "Days", "90", "Internal", "", ""),
       ("Notice Deadline Date", "Last date to give non-renewal notice (term end minus notice period).", "Agreement", "Date", "ISO 8601", "2027-10-02", "Internal", "", "Y", "Derived."),
       ("Governing Law", "Jurisdiction whose law governs the agreement.", "Agreement", "Code", "ISO 3166-1 alpha-2", "US", "DORA RoI ITS", "", ""),
       ("Agreement Business Owner", "Internal person accountable for the licence.", "Agreement", "Reference (Employee)", "", "EMP-02231", "Internal", "", ""),
     ]),
   ]),
   ("Licensed Scope", "What is licensed under the agreement: datasets, territory, entities, users, applications and sites.", [
     ("Licensed Dataset Schedule", [
       ("Licensed Dataset", "Dataset licensed under the agreement.", "Licensed Scope", "Reference (Dataset)", "", "DSET-00412", "Internal", "", "Y"),
       ("Licensed Modules / Fields", "Modules, field packages or data categories included.", "Licensed Scope", "Text", "", "Fund static, performance, ratings; excludes holdings", "Internal", "", ""),
       ("Licensed Territory", "Countries in which the data may be used.", "Licensed Scope", "Code (multi)", "ISO 3166-1 alpha-2", "US; GB; LU", "Internal", "", "Y"),
       ("Licensed Legal Entities", "Group entities entitled to use the data (affiliates must be named if sharing is restricted).", "Licensed Scope", "Reference (Legal Entity)", "", "LEN-0001; LEN-0012", "Internal", "Morningstar", ""),
       ("Licensed Business Units", "Organisation units licensed, where the licence is departmental.", "Licensed Scope", "Reference (Org Unit)", "", "OU-0410 (US Distribution)", "Internal", "Morningstar", ""),
       ("Licensed User Count", "Maximum number of named or concurrent users.", "Licensed Scope", "Integer", "", "45", "Internal", "FISD", "Y"),
       ("Licensed Application Count", "Maximum number of non-display applications or systems.", "Licensed Scope", "Integer", "", "3", "Internal", "FISD", ""),
       ("Scope Effective From", "Date the scope line became effective.", "Licensed Scope", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Scope Effective To", "Date the scope line ended.", "Licensed Scope", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Termination & Exit Obligations", "What must happen to data and derived data when the licence ends.", [
     ("Termination Obligations", [
       ("Termination for Convenience Indicator", "Whether the firm may terminate before term end without cause.", "Agreement", "Boolean", "", "N", "Internal", "DORA", ""),
       ("Data Destruction Required Indicator", "Whether licensed data must be deleted or returned on termination.", "Agreement", "Boolean", "", "Y", "Internal", "", "Y"),
       ("Data Destruction Deadline", "Days after termination by which data must be destroyed.", "Agreement", "Integer", "Days", "30", "Internal", "", ""),
       ("Derived Data Survival Indicator", "Whether derived data created during the term may be kept after termination.", "Agreement", "Boolean", "", "Y", "FISD", "", "Y"),
       ("Regulatory Archive Exception Indicator", "Whether data embedded in records the firm must keep by law (e.g. client reports, marketing archives) is exempt from destruction.", "Agreement", "Boolean", "", "Y", "Internal", "", ""),
     ]),
   ]),
   ("Audit & Reporting Clauses", "Vendor audit rights and usage reporting obligations in the agreement.", [
     ("Compliance Clauses", [
       ("Vendor Audit Right Indicator", "Whether the vendor may audit the firm's use of the data.", "Agreement", "Boolean", "", "Y", "Internal", "FISD", "Y"),
       ("Audit Notice Period", "Advance notice the vendor must give before an audit.", "Agreement", "Integer", "Days", "30", "Internal", "", ""),
       ("Usage Reporting Frequency", "How often the firm must declare usage.", "Agreement", "Code", "Frequency", "Monthly", "Internal", "FISD", ""),
     ]),
   ]),
  ])

D("Permitted Use & Rights", "TD-USE",
  "Coded permitted-use grants under each licence (display, non-display, derived data, redistribution, client reporting, marketing, index-tracking, AI/ML) and the attribution and disclaimer requirements that apply to outputs.",
  [
   ("Permitted Use Grant", "One coded right per agreement, dataset and use category, with its status and conditions.", [
     ("Permitted Use Grant", [
       ("Grant Agreement", "Agreement that grants or restricts the use.", "Permitted Use Grant", "Reference (Data Licence Agreement)", "", "DLA-000184", "Internal", "", ""),
       ("Grant Dataset", "Dataset the grant applies to (blank = all datasets under the agreement).", "Permitted Use Grant", "Reference (Dataset)", "", "DSET-00077", "Internal", "", "Y"),
       ("Permitted Use Category", "Category of use addressed by the grant.", "Permitted Use Grant", "Code", "Permitted Use Category", "Use in Marketing Materials", "FISD", "Internal", "Y"),
       ("Permission Status", "Whether the use is permitted under the licence.", "Permitted Use Grant", "Code", "Permission Status", "Permitted with Conditions", "Internal", "", "Y"),
       ("Use Conditions", "Conditions or limits attached to the use.", "Permitted Use Grant", "Text", "", "Ratings only; must show rating date and attribution; no star ratings for funds < 3 years", "Internal", "Morningstar", ""),
       ("Non-Display Use Types", "Kinds of automated (non-display) processing permitted, using FISD terminology.", "Permitted Use Grant", "Code (multi)", "Non-Display Use Type", "Analytics & Reporting; Portfolio Management", "FISD", "", ""),
       ("Derived Data Ownership", "Who owns derived data created from the licensed data.", "Permitted Use Grant", "Code", "Derived Data Ownership", "Licensee, Non-Reverse-Engineerable", "FISD", "", ""),
       ("Redistribution Recipient Types", "Types of external recipients to whom data may be passed on.", "Permitted Use Grant", "Code (multi)", "Redistribution Recipient Type", "Clients; Distribution Partners", "Internal", "", ""),
       ("Redistribution Form Limits", "Limits on the form of redistributed data.", "Permitted Use Grant", "Code (multi)", "Redistribution Form Limit", "Non-Extractable Format; Limited Data Points", "Internal", "", ""),
       ("Delay Requirement", "Minimum delay before data may be shown or passed on.", "Permitted Use Grant", "Text", "", "15 minutes (real-time prices); month-end only (ratings)", "FISD", "", ""),
       ("Personal Data Use Restrictions", "Restrictions on using personal data in the dataset (e.g. no email to EU contacts without consent, no profiling).", "Permitted Use Grant", "Text", "", "No outbound email to EU/UK contacts without opt-in", "GDPR", "", "", "Coordinate with 02 privacy and consent."),
       ("Legal Interpretation Confirmed Indicator", "Whether Legal has confirmed the coded interpretation.", "Permitted Use Grant", "Boolean", "", "Y", "Internal", "", "Y"),
       ("Grant Effective From", "Date the grant became effective.", "Permitted Use Grant", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Grant Effective To", "Date the grant ended.", "Permitted Use Grant", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Attribution & Disclaimer Requirements", "Source attribution, trademark and disclaimer text that must accompany displayed or redistributed data.", [
     ("Attribution Requirement", [
       ("Attribution Agreement", "Agreement that imposes the requirement.", "Attribution Requirement", "Reference (Data Licence Agreement)", "", "DLA-000184", "Internal", "", ""),
       ("Required Attribution Text", "Source attribution that must appear with the data.", "Attribution Requirement", "Text", "", "Source: Morningstar, Inc. As of 30/09/2026.", "Internal", "Morningstar", "Y"),
       ("Required Disclaimer Text", "Disclaimer or notice text required by the vendor.", "Attribution Requirement", "Text", "", "(c) 2026 Morningstar. All Rights Reserved. The information contained herein ...", "Internal", "", ""),
       ("Trademark Use Permitted Indicator", "Whether the vendor's names or logos may be used.", "Attribution Requirement", "Boolean", "", "Y", "Internal", "MSCI Index Licence", ""),
       ("Applies To Output Types", "Outputs to which the requirement applies.", "Attribution Requirement", "Code (multi)", "Output Type", "Factsheet; Website; Client Report", "Internal", "", ""),
     ]),
   ]),
  ])

D("Index & Benchmark Licensing", "TD-IDX",
  "Licences to use indices: as benchmarks for funds and mandates, as the basis of index-tracking products, for index data display, together with product-level coverage, AUM-based fees and the EU/UK benchmark-register status of the index used.",
  [
   ("Index Use Licence", "How a licensed index (BMK- in 01) is used by the firm and the regulatory status of that use.", [
     ("Index Use", [
       ("Index Licence Agreement", "Agreement (DLA- of type Index Licence Agreement) covering the use.", "Index Use", "Reference (Data Licence Agreement)", "", "DLA-000231", "Internal", "MSCI Index Licence", ""),
       ("Licensed Index", "Benchmark or index licensed (master in 01).", "Index Use", "Reference (Benchmark)", "", "BMK-0001", "Internal", "", "Y"),
       ("Index Provider", "Index provider / benchmark administrator party.", "Index Use", "Reference (Party)", "", "PTY-500150 (MSCI)", "EU BMR", "", ""),
       ("Index Use Type", "Way the firm uses the index.", "Index Use", "Code", "Index Use Type", "Index-Tracking Product", "EU BMR", "MSCI Index Licence", "Y"),
       ("BMR Use Indicator", "Whether the use is a 'use of a benchmark' within the EU BMR (e.g. measuring fund performance to track the index, define asset allocation or compute performance fees).", "Index Use", "Boolean", "", "Y", "EU BMR", "", "Y"),
       ("Benchmark Category (BMR)", "BMR category of the benchmark, which determines whether it remains in scope after Regulation (EU) 2025/914.", "Index Use", "Code", "BMR Benchmark Category", "Significant", "EU BMR", "", ""),
       ("Administrator Register Status (EU)", "Status of the administrator or benchmark on the ESMA register.", "Index Use", "Code", "BMR Register Status", "Recognised (Third Country)", "ESMA BMR Register", "EU BMR", "Y"),
       ("Administrator Register Status (UK)", "Status on the FCA benchmarks register for UK use.", "Index Use", "Code", "BMR Register Status", "Authorised", "UK FCA Benchmarks Register", "", ""),
       ("Register Status Check Date", "Date the register status was last checked.", "Index Use", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
       ("Benchmark Contingency Plan Reference", "Reference to the written plan for actions if the benchmark changes materially or ceases.", "Index Use", "Text", "", "Index cessation plan v3, Board-approved 2026-03", "EU BMR", "", ""),
     ]),
   ]),
   ("Index Product Licence Coverage", "Products and share classes covered by an index-tracking product licence and the fees due for each.", [
     ("Index Product Coverage", [
       ("Covered Product", "Product that tracks or uses the index (01).", "Index Product Coverage", "Reference (Product)", "", "PRD-01207", "Internal", "MSCI Index Licence", "Y"),
       ("Covered Share Class", "Share class covered, where fees or rights differ by class.", "Index Product Coverage", "Reference (Share Class)", "", "SHC-04412", "Internal", "", ""),
       ("Index Name in Product Name Indicator", "Whether the product name uses the index trademark (normally needs explicit licence).", "Index Product Coverage", "Boolean", "", "Y", "MSCI Index Licence", "", ""),
       ("Licence Fee Basis", "How the product-level licence fee is calculated.", "Index Product Coverage", "Code", "Index Fee Basis", "Basis Points on Average AUM", "MSCI Index Licence", "", ""),
       ("Licence Fee Rate", "Fee rate in basis points of AUM.", "Index Product Coverage", "Decimal", "Basis points", "2.5", "MSCI Index Licence", "", "Y"),
       ("Minimum Annual Fee", "Minimum annual fee per product or family.", "Index Product Coverage", "Amount", "", "USD 25,000", "MSCI Index Licence", "", ""),
       ("Fee AUM Basis", "AUM measure used to compute the fee (measure values come from 06).", "Index Product Coverage", "Code", "AUM Basis", "Average Daily Net Assets", "MSCI Index Licence", "", ""),
       ("Fee Payment Frequency", "How often the fee is calculated and paid.", "Index Product Coverage", "Code", "Frequency", "Quarterly", "MSCI Index Licence", "", ""),
       ("Coverage Effective From", "Date the product became covered.", "Index Product Coverage", "Date", "ISO 8601", "2025-11-03", "Internal", "", ""),
       ("Coverage Effective To", "Date coverage ended (closure, index change).", "Index Product Coverage", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

D("Entitlements & Access", "TD-ENT",
  "Who and what may access licensed data (ENT-): user and application entitlements, terminal and seat assignments, request and approval, recertification, and the inventory of non-display applications.",
  [
   ("Entitlement", "An effective-dated right of one user or application to access a dataset under a licence.", [
     ("Entitlement", [
       ("Entitlement ID", "Unique identifier of the entitlement.", "Entitlement", "Identifier", "", "ENT-0098812", "Internal", "", "Y"),
       ("Entitlement Holder Type", "Whether the entitlement is held by a person, application or service account.", "Entitlement", "Code", "Entitlement Holder Type", "User", "FISD", "", ""),
       ("Entitled User", "Internal user holding the entitlement.", "Entitlement", "Reference (Employee)", "", "EMP-04410", "Internal", "", "", "PII"),
       ("Entitled Application", "Consuming application holding the entitlement.", "Entitlement", "Reference (Consuming Application)", "", "DAPP-0042", "Internal", "", ""),
       ("Entitled Dataset", "Dataset the entitlement grants access to.", "Entitlement", "Reference (Dataset)", "", "DSET-00077", "Internal", "", "Y"),
       ("Governing Licence", "Agreement that the entitlement counts against.", "Entitlement", "Reference (Data Licence Agreement)", "", "DLA-000184", "Internal", "", "Y"),
       ("Entitlement Type", "Kind of access granted.", "Entitlement", "Code", "Entitlement Type", "Terminal Seat", "Internal", "Bloomberg", ""),
       ("Vendor User ID", "Login or user ID assigned by the vendor.", "Entitlement", "Identifier", "External (Vendor)", "JSMITH123", "Internal", "", "", "PII"),
       ("Entitlement Status", "Lifecycle status of the entitlement.", "Entitlement", "Code", "Entitlement Status", "Active", "Internal", "", "Y"),
       ("Requested Date", "Date access was requested.", "Entitlement", "Date", "ISO 8601", "2026-02-03", "Internal", "", ""),
       ("Approver", "Person who approved the request.", "Entitlement", "Reference (Employee)", "", "EMP-02231", "Internal", "", ""),
       ("Approved Date", "Date the request was approved.", "Entitlement", "Date", "ISO 8601", "2026-02-04", "Internal", "", ""),
       ("Provisioned Date", "Date access became live.", "Entitlement", "Date", "ISO 8601", "2026-02-06", "Internal", "", ""),
       ("Revoked Date", "Date access was removed.", "Entitlement", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Last Recertification Date", "Date the entitlement was last recertified by the manager or owner.", "Entitlement", "Date", "ISO 8601", "2026-07-01", "Internal", "", "Y"),
       ("Last Used Date", "Last date the entitlement was used, from vendor or platform usage logs.", "Entitlement", "Date", "ISO 8601", "2026-09-28", "Internal", "", ""),
     ]),
   ]),
   ("Consuming Application Inventory", "Applications and systems that consume licensed data without a human viewing it (non-display) or that display it to users.", [
     ("Consuming Application", [
       ("Consuming Application ID", "Unique identifier of the consuming application.", "Consuming Application", "Identifier", "", "DAPP-0042", "Internal", "FISD", "Y"),
       ("Application Name", "Name of the application.", "Consuming Application", "Text", "", "Distribution Data Warehouse", "Internal", "", ""),
       ("Usage Mode", "Whether the application uses the data for display, non-display or both.", "Consuming Application", "Code", "Usage Mode", "Non-Display", "FISD", "", "Y"),
       ("Non-Display Use Types", "Non-display purposes the application serves.", "Consuming Application", "Code (multi)", "Non-Display Use Type", "Analytics & Reporting", "FISD", "", ""),
       ("External Output Indicator", "Whether outputs leave the firm (client, partner, website, regulator).", "Consuming Application", "Boolean", "", "Y", "Internal", "", ""),
       ("Declared to Vendor Indicator", "Whether the application has been declared to the relevant vendors.", "Consuming Application", "Boolean", "", "Y", "FISD", "", "Y"),
     ]),
   ]),
  ])

D("Usage & Licence Compliance", "TD-CMP",
  "Usage declarations made to vendors, licence audits (vendor-initiated or internal), findings, remediation and true-ups.",
  [
   ("Usage Declaration", "Periodic declarations of users, applications, recipients or AUM made to vendors.", [
     ("Usage Declaration", [
       ("Usage Declaration ID", "Unique identifier of the declaration.", "Usage Declaration", "Identifier", "", "UDC-2026-09-0031", "Internal", "", "Y"),
       ("Declaration Agreement", "Agreement the declaration is made under.", "Usage Declaration", "Reference (Data Licence Agreement)", "", "DLA-000231", "Internal", "", ""),
       ("Declaration Type", "What is being declared.", "Usage Declaration", "Code", "Declaration Type", "AUM-Linked Fee Declaration", "Internal", "FISD", "Y"),
       ("Declaration Period Start", "Start of the period declared.", "Usage Declaration", "Date", "ISO 8601", "2026-07-01", "Internal", "", ""),
       ("Declaration Period End", "End of the period declared.", "Usage Declaration", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
       ("Declared User Count", "Number of users declared.", "Usage Declaration", "Integer", "", "42", "Internal", "", ""),
       ("Declared Application Count", "Number of non-display applications declared.", "Usage Declaration", "Integer", "", "3", "FISD", "", ""),
       ("Declared AUM", "AUM declared for index-licence fees (sourced from 06 measures).", "Usage Declaration", "Amount", "", "USD 4,820,000,000", "MSCI Index Licence", "", "Y"),
       ("Submission Due Date", "Date the declaration is due to the vendor.", "Usage Declaration", "Date", "ISO 8601", "2026-10-15", "Internal", "", "Y"),
       ("Submitted Date", "Date the declaration was submitted.", "Usage Declaration", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Declaration Status", "Workflow status of the declaration.", "Usage Declaration", "Code", "Declaration Status", "In Preparation", "Internal", "", ""),
     ]),
   ]),
   ("Licence Audit & Findings", "Vendor audits and internal licence reviews, their findings, remediation and financial settlement.", [
     ("Licence Audit", [
       ("Licence Audit ID", "Unique identifier of the audit.", "Licence Audit", "Identifier", "", "LAU-0007", "Internal", "", "Y"),
       ("Audited Vendor", "Vendor whose data use is audited.", "Licence Audit", "Reference (Party)", "", "PTY-500210", "Internal", "", ""),
       ("Audit Type", "Who initiated and performs the audit.", "Licence Audit", "Code", "Licence Audit Type", "Vendor-Initiated", "Internal", "", ""),
       ("Audit Scope Period", "Usage period under review.", "Licence Audit", "Text", "", "2024-01-01 to 2025-12-31", "Internal", "", ""),
       ("Audit Status", "Workflow status of the audit.", "Licence Audit", "Code", "Licence Audit Status", "Fieldwork", "Internal", "", ""),
       ("Back-Fees Claimed", "Amount claimed by the vendor for past unlicensed use.", "Licence Audit", "Amount", "", "USD 180,000", "Internal", "", "Y"),
     ]),
     ("Licence Compliance Finding", [
       ("Finding Reference", "Identifier of the finding within the audit or review.", "Audit Finding", "Identifier", "", "LAU-0007-F03", "Internal", "", ""),
       ("Finding Type", "Kind of non-compliance found.", "Audit Finding", "Code", "Licence Finding Type", "Unlicensed User", "Internal", "FISD", "Y"),
       ("Finding Severity", "Severity of the finding.", "Audit Finding", "Code", "Severity", "High", "Internal", "", ""),
       ("Root Cause", "Root cause category.", "Audit Finding", "Code", "Licence Finding Root Cause", "Entitlement Not Revoked on Transfer", "Internal", "", ""),
       ("Remediation Action", "Agreed corrective action.", "Audit Finding", "Text", "", "Revoke 6 seats; add HR mover trigger to entitlement workflow", "Internal", "", ""),
       ("Remediation Due Date", "Date remediation must be complete.", "Audit Finding", "Date", "ISO 8601", "2026-11-30", "Internal", "", ""),
       ("True-Up Amount", "Additional licence fee payable to regularise the use.", "Audit Finding", "Amount", "", "USD 42,000", "Internal", "", "Y"),
       ("Finding Status", "Status of the finding.", "Audit Finding", "Code", "Finding Status", "In Remediation", "Internal", "", ""),
     ]),
   ]),
  ])

D("Data Cost & Commercials", "TD-CST",
  "Contract value and pricing terms, vendor invoices, allocation of data cost to organisation units, and the renewal and cost-optimisation pipeline.",
  [
   ("Commercial Terms", "Price and payment terms of a data licence agreement.", [
     ("Commercial Terms", [
       ("Annual Contract Value", "Annualised committed cost of the agreement.", "Commercial Terms", "Amount", "", "USD 412,000", "Internal", "", "Y"),
       ("Contract Currency", "Currency in which fees are charged.", "Commercial Terms", "Code", "ISO 4217", "USD", "ISO 4217", "", ""),
       ("Pricing Basis", "Unit on which the price is set.", "Commercial Terms", "Code", "Pricing Basis", "Per User per Month", "Internal", "", ""),
       ("Annual Price Escalator", "Contractual annual price increase.", "Commercial Terms", "Percentage", "", "5%", "Internal", "", ""),
     ]),
   ]),
   ("Data Invoice", "Vendor invoices for data, validated against the contract before payment.", [
     ("Data Invoice", [
       ("Data Invoice ID", "Unique internal identifier of the invoice.", "Data Invoice", "Identifier", "", "DINV-2026-01884", "Internal", "", "Y"),
       ("Vendor Invoice Number", "Invoice number assigned by the vendor.", "Data Invoice", "Identifier", "External (Vendor)", "INV-778120", "Internal", "", ""),
       ("Invoiced Agreement", "Agreement the invoice relates to.", "Data Invoice", "Reference (Data Licence Agreement)", "", "DLA-000184", "Internal", "", ""),
       ("Invoice Date", "Date of the invoice.", "Data Invoice", "Date", "ISO 8601", "2026-09-01", "Internal", "", ""),
       ("Service Period Start", "Start of the period invoiced.", "Data Invoice", "Date", "ISO 8601", "2026-10-01", "Internal", "", ""),
       ("Service Period End", "End of the period invoiced.", "Data Invoice", "Date", "ISO 8601", "2026-12-31", "Internal", "", ""),
       ("Invoice Net Amount", "Invoice amount before tax.", "Data Invoice", "Amount", "", "USD 103,000", "Internal", "", "Y"),
       ("Contract Validation Result", "Result of checking the invoice against contract price, scope and declared usage.", "Data Invoice", "Code", "Invoice Validation Result", "Matched", "Internal", "", ""),
       ("Invoice Status", "Processing status of the invoice.", "Data Invoice", "Code", "Invoice Status", "Approved for Payment", "Internal", "", ""),
       ("AP Document Reference", "Accounts payable document reference (accounting is handled by Finance / 10).", "Data Invoice", "Identifier", "External (ERP)", "AP-5100088123", "Internal", "", ""),
     ]),
   ]),
   ("Cost Allocation", "Agreed split of data cost to organisation units, the input to chargeback and to distribution profitability in 10.", [
     ("Data Cost Allocation", [
       ("Allocated Agreement", "Agreement whose cost is allocated.", "Cost Allocation", "Reference (Data Licence Agreement)", "", "DLA-000184", "Internal", "", ""),
       ("Allocated Org Unit", "Organisation unit receiving the cost (09).", "Cost Allocation", "Reference (Org Unit)", "", "OU-0410", "Internal", "", "Y"),
       ("Allocation Share", "Share of the cost allocated to the unit.", "Cost Allocation", "Percentage", "", "60%", "Internal", "", "Y"),
       ("Allocation Driver", "Driver used to set the share.", "Cost Allocation", "Code", "Allocation Driver", "Entitled Users", "Internal", "", ""),
       ("Allocation Method Reference", "Allocation method defined in 10, where a standard method applies.", "Cost Allocation", "Reference (Allocation Method)", "", "ALM-0012", "Internal", "", ""),
       ("Allocation Effective From", "Date the split became effective.", "Cost Allocation", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Allocation Effective To", "Date the split ended.", "Cost Allocation", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Renewal & Optimisation", "Renewal cases, decisions and savings tracked ahead of notice deadlines.", [
     ("Renewal Case", [
       ("Renewal Case ID", "Unique identifier of the renewal case.", "Renewal Case", "Identifier", "", "RNW-2027-0014", "Internal", "", ""),
       ("Renewing Agreement", "Agreement up for renewal.", "Renewal Case", "Reference (Data Licence Agreement)", "", "DLA-000184", "Internal", "", "Y"),
       ("Renewal Decision", "Decision taken on renewal.", "Renewal Case", "Code", "Renewal Decision", "Renew - Reduced Scope", "Internal", "", "Y"),
       ("Negotiated Annual Value", "Annual value agreed after negotiation.", "Renewal Case", "Amount", "", "USD 398,000", "Internal", "", ""),
       ("Optimisation Levers", "Levers used to reduce cost.", "Renewal Case", "Code (multi)", "Optimisation Lever", "Seat Reduction; Vendor Consolidation", "Internal", "", ""),
       ("Overlapping Datasets", "Other datasets with overlapping content considered during the decision.", "Renewal Case", "Reference (Dataset)", "", "DSET-00413; DSET-00519", "Internal", "", ""),
     ]),
   ]),
  ])

D("Vendor Data Quality & Service Levels", "TD-DQS",
  "Service levels agreed with vendors, their measurement, and the vendor data issues and challenges raised by consuming domains.",
  [
   ("Vendor Service Levels", "SLAs on delivery, quality and support for a dataset, with measured results.", [
     ("Vendor Data SLA", [
       ("SLA Dataset", "Dataset the SLA applies to.", "Vendor SLA", "Reference (Dataset)", "", "DSET-00077", "Internal", "", ""),
       ("SLA Metric", "Dimension measured.", "Vendor SLA", "Code", "SLA Metric", "Delivery Timeliness", "Internal", "DCAM", "Y"),
       ("SLA Target", "Target value of the metric.", "Vendor SLA", "Text", "", "Delivered by 06:00 ET on 99% of business days", "Internal", "", ""),
       ("Measurement Period", "Period over which the SLA is measured.", "Vendor SLA", "Code", "Frequency", "Monthly", "Internal", "", ""),
       ("Measured Result", "Result for the latest period.", "Vendor SLA", "Text", "", "97.6%", "Internal", "", ""),
       ("SLA Breach Indicator", "Whether the latest result breached the target.", "Vendor SLA", "Boolean", "", "Y", "Internal", "", "Y"),
     ]),
   ]),
   ("Vendor Data Issues & Challenges", "Data errors, late deliveries and value challenges raised with vendors, and their resolution.", [
     ("Vendor Data Issue", [
       ("Vendor Data Issue ID", "Unique identifier of the issue.", "Vendor Data Issue", "Identifier", "", "VDI-004417", "Internal", "", "Y"),
       ("Issue Dataset", "Dataset in which the issue was found.", "Vendor Data Issue", "Reference (Dataset)", "", "DSET-00077", "Internal", "", ""),
       ("Issue Type", "Category of the issue.", "Vendor Data Issue", "Code", "Vendor Data Issue Type", "Incorrect Value", "Internal", "DCAM", "Y"),
       ("Issue Severity", "Severity of business impact.", "Vendor Data Issue", "Code", "Severity", "Medium", "Internal", "", ""),
       ("Issue Description", "Description of the issue and the records affected.", "Vendor Data Issue", "Text", "", "Share class SHC-04412 shown with wrong Morningstar category after reclassification", "Internal", "", ""),
       ("Detected Date", "Date the issue was detected.", "Vendor Data Issue", "Date", "ISO 8601", "2026-09-03", "Internal", "", ""),
       ("Detected By Domain", "Business domain that detected the issue.", "Vendor Data Issue", "Code", "Consuming Business Domain", "11 Market & Competitive Intelligence", "Internal", "", ""),
       ("Own Data Challenge Indicator", "Whether the issue challenges data the vendor holds about the firm's own products or people (e.g. fund data, ratings inputs).", "Vendor Data Issue", "Boolean", "", "Y", "Internal", "", ""),
       ("Vendor Ticket Reference", "Reference of the case in the vendor's support system.", "Vendor Data Issue", "Identifier", "External (Vendor)", "CS-2026-118823", "Internal", "", ""),
       ("Root Cause Category", "Cause of the issue once known.", "Vendor Data Issue", "Code", "Issue Root Cause", "Vendor Processing Error", "Internal", "", ""),
       ("Resolution Outcome", "Outcome of the issue or challenge.", "Vendor Data Issue", "Code", "Resolution Outcome", "Corrected by Vendor", "Internal", "", ""),
       ("Resolved Date", "Date the issue was resolved.", "Vendor Data Issue", "Date", "ISO 8601", "2026-09-10", "Internal", "", ""),
       ("Issue Status", "Status of the issue.", "Vendor Data Issue", "Code", "Issue Status", "Resolved", "Internal", "", "Y"),
     ]),
   ]),
  ])

D("Data Management Metadata", "TD-DMM",
  "Metadata applied to every record in the third-party data domain.",
  [
   ("Data Management Metadata", "Ownership, versioning and quality metadata applied to every record.", [
     ("Record Metadata", [
       ("Data Owner", "Business role accountable for the data element.", "All", "Reference (Employee)", "", "Head of Market Data", "DCAM", "", ""),
       ("Data Steward", "Role responsible for day-to-day data quality.", "All", "Reference (Employee)", "", "Market Data Analyst", "DCAM", "", ""),
       ("System of Record", "System holding the authoritative value.", "All", "Code", "Firm-defined", "Market Data Inventory Platform", "Internal", "", ""),
       ("Record Effective From", "Business-effective start date of the record version.", "All", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Record Effective To", "Business-effective end date of the record version.", "All", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Last Updated Timestamp", "System timestamp of the last change.", "All", "Timestamp", "ISO 8601", "2026-09-30T17:45:00Z", "Internal", "", ""),
       ("Data Quality Status", "Validation status of the record.", "All", "Code", "Data Quality Status", "Validated", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Vendor Type": ("Internal", [("Advisor & Firm Database","e.g. Discovery Data, FINTRX, Broadridge advisor data"),("Distribution Data Provider","e.g. Broadridge Distribution Insight, ISS Market Intelligence"),("Fund Data & Ratings Provider","e.g. Morningstar, LSEG Lipper, FE fundinfo"),("Index Provider","e.g. MSCI, S&P DJI, FTSE Russell, Bloomberg Indices"),("Market Data Provider","e.g. Bloomberg, LSEG"),("Consultant / Manager Database","e.g. Nasdaq eVestment"),("Intent & Marketing Data Provider","e.g. Bombora, ZoomInfo"),("ESG Data Provider","e.g. MSCI ESG, Sustainalytics, ISS ESG"),("Research & Survey Provider","e.g. Cerulli"),("Data Platform / Marketplace","Marketplace or data platform reselling data")]),
 "Dataset Subject Area": ("Internal", [("Advisor & Firm Data",""),("Distribution / Sales Data","Intermediary sales and assets"),("Industry Flows & AUM",""),("Fund Data",""),("Ratings & Research",""),("Index Data",""),("Market Data","Prices, reference and corporate actions"),("ESG Data",""),("Consultant Database",""),("Intent Data",""),("Contact & Firmographic Data",""),("Economic & Alternative Data","")]),
 "Vendor Relationship Status": ("Internal", [("Prospective","Under evaluation or trial"),("Onboarding",""),("Active",""),("Under Review","Performance or risk concerns"),("Exiting","Termination notice given"),("Inactive","No active agreements")]),
 "Vendor Strategic Tier": ("Internal (aligned to TPRM criticality tiering)", [("Tier 1 - Strategic","Hard to replace; supports critical processes or products"),("Tier 2 - Important",""),("Tier 3 - Standard",""),("Tier 4 - Low / Tactical","")]),
 "Vendor Contact Role": ("Internal", [("Account Manager",""),("Relationship Executive",""),("Client Support",""),("Licensing / Compliance Contact","Receives usage declarations"),("Billing Contact",""),("Technical / Data Delivery Contact",""),("Information Security Contact","")]),
 "Performance Rating": ("Internal", [("Exceeds Expectations",""),("Meets Expectations",""),("Partially Meets",""),("Does Not Meet","")]),
 "Risk Assessment Type": ("Internal / US Interagency TPRM Guidance", [("Onboarding Due Diligence",""),("Periodic Review",""),("Event-Driven Review","Incident, breach, ownership change"),("Renewal Review",""),("Exit Assessment","")]),
 "Vendor Risk Domain": ("Internal / DORA", [("Information Security",""),("Business Continuity & Resilience",""),("Data Privacy",""),("Financial Viability",""),("Legal & Regulatory",""),("Concentration",""),("Subcontracting / Fourth Party",""),("Reputational",""),("ESG / Modern Slavery","")]),
 "Risk Rating": ("Internal", [("Critical",""),("High",""),("Medium",""),("Low","")]),
 "Substitutability": ("DORA RoI ITS (concept level)", [("Not Substitutable",""),("Highly Complex",""),("Medium Complexity",""),("Easily Substitutable","")]),
 "Assurance Report Type": ("AICPA / ISO", [("SOC 1 Type I",""),("SOC 1 Type II",""),("SOC 2 Type I","Design of controls at a point in time"),("SOC 2 Type II","Design and operating effectiveness over a period"),("SOC 3",""),("ISO/IEC 27001 Certificate",""),("Penetration Test Summary",""),("Security Questionnaire Response","e.g. SIG or firm questionnaire")]),
 "Trust Services Category": ("AICPA Trust Services Criteria", [("Security","Common criteria; always in scope"),("Availability",""),("Processing Integrity",""),("Confidentiality",""),("Privacy","")]),
 "Auditor Opinion": ("AICPA", [("Unqualified",""),("Qualified",""),("Adverse",""),("Disclaimer","")]),
 "Data Basis": ("Internal", [("Reported","Sourced from filings, registers or providers"),("Estimated",""),("Modelled",""),("Survey-Based",""),("Mixed","")]),
 "Information Classification": ("Internal (aligned to CDMC classification)", [("Public",""),("Internal",""),("Confidential","Default for licensed data and licence terms"),("Restricted","Personal or highly sensitive data")]),
 "Dataset Status": ("Internal", [("Proposed",""),("Trial / Evaluation",""),("Onboarding",""),("In Production",""),("Deprecated","Replacement planned"),("Retired","")]),
 "Covered Entity Type": ("Internal", [("Advisors",""),("Advisor Teams",""),("Branches",""),("Firms",""),("Institutional Investors",""),("Consultants",""),("Funds / Share Classes",""),("Indices",""),("Securities",""),("Companies (Issuers)",""),("Contacts (Marketing)","")]),
 "Data Granularity": ("Internal", [("Advisor",""),("Team",""),("Branch / Office",""),("Firm",""),("Share Class",""),("Fund",""),("Index",""),("Security",""),("Company",""),("Market / Category Aggregate","")]),
 "Frequency": ("Internal", [("Real-Time",""),("Intraday",""),("Daily",""),("Weekly",""),("Monthly",""),("Quarterly",""),("Semi-Annual",""),("Annual",""),("Ad Hoc","")]),
 "Identifier Scheme": ("Internal", [("FINRA CRD",""),("SEC File Number",""),("LEI","ISO 17442"),("FCA FRN / IRN",""),("ISIN","ISO 6166"),("CUSIP",""),("SEDOL",""),("FIGI",""),("Ticker",""),("Vendor Proprietary ID","e.g. Morningstar SecId, Discovery Data ID"),("Email Domain / Company Domain","Intent and firmographic data")]),
 "Delivery Method": ("Internal", [("API",""),("SFTP File",""),("Cloud Data Share","e.g. Snowflake Secure Data Sharing / Marketplace listing"),("Terminal / Desktop",""),("Web Platform",""),("Streaming Feed",""),("Excel Add-In",""),("Email","Discouraged")]),
 "Delivery Format": ("Internal", [("CSV / Delimited",""),("Fixed-Width",""),("XML",""),("JSON",""),("Parquet",""),("Database Table / View",""),("XLSX",""),("PDF","")]),
 "Consuming Business Domain": ("Program domain list", [("01 Investment Product",""),("02 Client & Customer",""),("03 Sales",""),("04 Marketing & Digital",""),("05 Distribution Agreements & Partners",""),("06 Sales Transactions & AUM Attribution",""),("07 Compensation & Territory",""),("08 Distribution Compliance",""),("09 Shared & Enterprise Reference Data",""),("10 Distribution Finance & Profitability",""),("11 Market & Competitive Intelligence",""),("12 Institutional Client Servicing & Reporting",""),("13 Investor Servicing & Shareholder Communications",""),("Investment Management (outside programme)","")]),
 "Use Case": ("Internal", [("Advisor Targeting & Segmentation",""),("CRM Enrichment",""),("Sales & AUM Attribution",""),("Territory Design & Potential",""),("Market Share & Competitive Analysis",""),("Product Development",""),("Marketing Campaigns",""),("Factsheets & Product Literature",""),("Client Reporting",""),("Benchmark Comparison",""),("Index-Tracking Portfolio Management",""),("RFP / Consultant Responses",""),("Analytics & AI Models","")]),
 "Permitted Use Category": ("FISD terminology / Internal", [("Internal Use - Display","Viewed by licensed users"),("Internal Use - Non-Display","Automated processing without human display"),("Derived Data Creation",""),("Redistribution to Clients",""),("Redistribution to Distribution Partners",""),("Use in Client Reporting",""),("Use in Marketing Materials","Factsheets, presentations, advertising"),("Public Website Display",""),("Use in Index-Tracking Product","Requires index licence"),("Use as Benchmark",""),("Use in Regulatory Documents","Prospectus, KID, shareholder reports"),("AI / ML Model Training",""),("Generative AI Input / Retrieval","Use as prompt or retrieval context"),("Affiliate Sharing",""),("Service Provider Processing","")]),
 "Permission Status": ("Internal", [("Permitted",""),("Permitted with Conditions",""),("Requires Additional Licence",""),("Prohibited",""),("Not Addressed","Silent; treat as not permitted until Legal confirms")]),
 "Non-Display Use Type": ("FISD (non-display categories) / Internal", [("Analytics & Reporting",""),("Portfolio Management",""),("Index Calculation",""),("Fund Valuation / Pricing",""),("Risk Management",""),("Automated Trading",""),("Data Enrichment / Mastering",""),("Model Training","")]),
 "Derived Data Ownership": ("FISD / Internal", [("Licensee, Non-Reverse-Engineerable","Firm owns derived data that cannot recreate the source"),("Licensor Retains Rights",""),("Shared / Joint",""),("Not Addressed","")]),
 "Redistribution Recipient Type": ("Internal", [("Clients",""),("Prospects",""),("Distribution Partners",""),("Consultants",""),("Public / Website",""),("Regulators",""),("Service Providers","")]),
 "Redistribution Form Limit": ("Internal", [("Non-Extractable Format","e.g. PDF or image"),("Limited Data Points",""),("Delayed Data Only",""),("Aggregated Only",""),("Own Products Only","Data about the firm's own funds only"),("With Attribution","")]),
 "Output Type": ("Internal", [("Factsheet",""),("Presentation",""),("Website",""),("Client Report",""),("RFP / DDQ Response",""),("Prospectus / KID",""),("Advertising",""),("Internal Report","")]),
 "Data Agreement Type": ("Internal", [("Master Licence Agreement",""),("Order Form / Schedule",""),("Data Licence Addendum",""),("Index Licence Agreement","Index data, benchmark use or index-tracking product licence"),("Redistribution Agreement",""),("Evaluation / Trial Agreement",""),("Marketplace / Click-Through Terms","e.g. listing terms on a cloud marketplace"),("Data Processing Agreement","")]),
 "Licence Model": ("Internal (common vendor models)", [("Enterprise","Firm-wide use, not priced per user"),("Per Named User",""),("Per Concurrent User",""),("Per Application / Non-Display",""),("Site",""),("Departmental",""),("AUM-Linked","Typical for index-tracking products"),("Usage / Consumption-Based","API calls, records or credits"),("Product-Specific","")]),
 "Agreement Status": ("Internal", [("Draft",""),("In Negotiation",""),("Executed - Not Yet Effective",""),("Active",""),("Notice Given",""),("Expired",""),("Terminated","")]),
 "Index Use Type": ("EU BMR Art. 3 / Internal", [("Benchmark - Performance Comparison","Comparator only"),("Benchmark - Asset Allocation","Defines the portfolio's allocation or constraint"),("Benchmark - Performance Fee",""),("Index-Tracking Product","ETF or index fund tracking the index"),("Index Data Display Only",""),("Custom Index","Bespoke index calculated for the firm"),("Research / Analytics Only","")]),
 "BMR Benchmark Category": ("EU BMR as amended by Regulation (EU) 2025/914", [("Critical",""),("Significant",""),("Non-Significant","Out of EU BMR scope from 2026-01-01 unless opted in"),("EU Climate Transition Benchmark",""),("EU Paris-Aligned Benchmark",""),("Commodity Benchmark (in scope)",""),("Not a Benchmark","")]),
 "BMR Register Status": ("ESMA / FCA benchmarks registers", [("Authorised",""),("Registered",""),("Recognised (Third Country)",""),("Endorsed (Third Country)",""),("Equivalence",""),("Transitional / Pending Application","Usable while application pending"),("Not on Register",""),("Out of BMR Scope","")]),
 "Index Fee Basis": ("Internal (public descriptions of index licences)", [("Basis Points on Average AUM",""),("Flat Annual Fee",""),("Minimum Fee plus Basis Points",""),("Per Product Fee",""),("Included in Data Subscription","")]),
 "AUM Basis": ("Internal", [("Average Daily Net Assets",""),("Month-End Net Assets",""),("Quarter-End Net Assets","")]),
 "Entitlement Holder Type": ("Internal / FISD", [("User",""),("Application",""),("Service Account",""),("Team / Shared","")]),
 "Entitlement Type": ("Internal", [("Terminal Seat","e.g. Bloomberg Terminal"),("Named Web User",""),("Concurrent User",""),("API Key",""),("Non-Display Application",""),("Data Share Access",""),("Excel Add-In User","")]),
 "Entitlement Status": ("Internal", [("Requested",""),("Approved",""),("Active",""),("Suspended",""),("Revoked",""),("Rejected","")]),
 "Usage Mode": ("FISD", [("Display",""),("Non-Display",""),("Display and Non-Display","")]),
 "Declaration Type": ("Internal", [("User Count Declaration",""),("Non-Display Application Declaration",""),("AUM-Linked Fee Declaration",""),("Redistribution Recipient Report",""),("Annual Licence Certification","")]),
 "Declaration Status": ("Internal", [("Not Started",""),("In Preparation",""),("Submitted",""),("Acknowledged",""),("Queried by Vendor",""),("Overdue","")]),
 "Licence Audit Type": ("Internal", [("Vendor-Initiated",""),("Third-Party Auditor on Vendor's Behalf",""),("Internal Self-Assessment",""),("Internal Audit","")]),
 "Licence Audit Status": ("Internal", [("Notified",""),("Planning",""),("Fieldwork",""),("Draft Findings",""),("Negotiation",""),("Closed","")]),
 "Licence Finding Type": ("Internal", [("Unlicensed User",""),("Unlicensed Application",""),("Use Outside Permitted Scope",""),("Unauthorised Redistribution",""),("Missing Attribution",""),("Late / Inaccurate Declaration",""),("Data Retained After Termination",""),("Affiliate Use Not Licensed","")]),
 "Licence Finding Root Cause": ("Internal", [("Entitlement Not Revoked on Transfer",""),("Shadow Data Copy",""),("Unclear Licence Terms",""),("Process Not Followed",""),("Inventory Gap",""),("Vendor Error","")]),
 "Severity": ("Internal", [("Critical",""),("High",""),("Medium",""),("Low","")]),
 "Finding Status": ("Internal", [("Open",""),("In Remediation",""),("Remediated",""),("Accepted Risk",""),("Closed","")]),
 "Pricing Basis": ("Internal", [("Flat Annual",""),("Per User per Month",""),("Per Application",""),("Per Record / Entity",""),("Basis Points on AUM",""),("Credits / Consumption","")]),
 "Invoice Validation Result": ("Internal", [("Matched",""),("Price Variance",""),("Scope Variance",""),("Usage Variance",""),("Duplicate","")]),
 "Invoice Status": ("Internal", [("Received",""),("Under Validation",""),("Disputed",""),("Approved for Payment",""),("Paid",""),("Credited","")]),
 "Allocation Driver": ("Internal (coordinate with 10)", [("Entitled Users",""),("Usage Volume",""),("Fixed Percentage",""),("Equal Split",""),("AUM of Covered Products","")]),
 "Renewal Decision": ("Internal", [("Renew - As Is",""),("Renew - Reduced Scope",""),("Renew - Expanded Scope",""),("Replace with Alternative Vendor",""),("Terminate",""),("Pending","")]),
 "Optimisation Lever": ("Internal", [("Seat Reduction",""),("Vendor Consolidation",""),("Licence Model Change",""),("Multi-Year Commitment",""),("Remove Unused Modules",""),("Enterprise Agreement","")]),
 "SLA Metric": ("Internal / DCAM data quality dimensions", [("Delivery Timeliness",""),("Completeness",""),("Accuracy",""),("Availability / Uptime",""),("Issue Response Time",""),("Issue Resolution Time","")]),
 "Vendor Data Issue Type": ("Internal / DCAM", [("Late Delivery",""),("Missing Records",""),("Incorrect Value",""),("Misclassification",""),("Identifier Mismatch",""),("Duplicate Records",""),("Unannounced Schema Change",""),("Stale Data","")]),
 "Issue Root Cause": ("Internal", [("Vendor Processing Error",""),("Vendor Source Error","Error in the vendor's upstream source"),("Firm-Supplied Data Error","Our own submission to the vendor was wrong"),("Mapping / Ingestion Error",""),("Methodology Difference",""),("Unknown","")]),
 "Resolution Outcome": ("Internal", [("Corrected by Vendor",""),("Challenge Rejected",""),("Partially Corrected",""),("Corrected Internally",""),("Accepted as Methodology","")]),
 "Issue Status": ("Internal", [("New",""),("Raised with Vendor",""),("In Progress",""),("Resolved",""),("Closed",""),("Cancelled","")]),
 "Data Quality Status": ("Internal", [("Validated",""),("Pending Validation",""),("Failed Validation",""),("Stale","")]),
}

REL = [
 ("Data Vendor","is a role of","Party (02 Client & Customer: PTY-)","1 : 1","Vendor identity, LEI and addresses are mastered in 02."),
 ("Data Vendor","has","Vendor Contact Role","1 : 0..n","Contact persons are PTY- individuals in 02."),
 ("Data Vendor","is reviewed in","Vendor Performance Review","1 : 0..n",""),
 ("Data Vendor","is assessed by","Vendor Risk Assessment","1 : 1..n",""),
 ("Vendor Risk Assessment","is supported by","Assurance Report","1 : 0..n","SOC 2, ISO/IEC 27001 and other evidence."),
 ("Data Licence Agreement","is reported in","ICT Third-Party Register Entry","1 : 0..n","One entry per reporting EU financial entity (09 LEN-)."),
 ("Data Vendor","licenses","Data Licence Agreement","1 : 1..n","Order forms reference a master agreement (Parent Agreement)."),
 ("Data Licence Agreement","is signed by","Internal Legal Entity (09: LEN-)","n : 1",""),
 ("Data Licence Agreement","includes","Licensed Dataset Schedule","1 : 1..n",""),
 ("Licensed Dataset Schedule","covers","Dataset","n : 1",""),
 ("Data Licence Agreement","grants","Permitted Use Grant","1 : 1..n","One grant per dataset and use category."),
 ("Data Licence Agreement","imposes","Attribution Requirement","1 : 0..n",""),
 ("Dataset","is delivered via","Technical Feed (06 Sales Transactions & AUM: FEED-)","1 : 0..n","06 FEED- should reference DSET-/DLA- for purchased vendor data."),
 ("Dataset","is consumed through","Dataset Consumption","1 : 0..n","Lineage to consuming business domains (02, 03, 04, 06, 07, 11 ...)."),
 ("Dataset Consumption","is permitted by","Permitted Use Grant","n : 1",""),
 ("Index Use","references","Benchmark (01 Product: BMK-)","n : 1",""),
 ("Index Use","is licensed under","Data Licence Agreement (Index Licence Agreement)","n : 1",""),
 ("Index Use","covers","Index Product Coverage","1 : 0..n",""),
 ("Index Product Coverage","references","Product / Share Class (01 Product: PRD-, SHC-)","n : 1",""),
 ("Entitlement","grants access to","Dataset","n : 1",""),
 ("Entitlement","counts against","Data Licence Agreement","n : 1",""),
 ("Entitlement","is held by","Employee (03 Sales: EMP-, pending workforce master) / Consuming Application","n : 1",""),
 ("Consuming Application","consumes","Dataset","n : n","Via Dataset Consumption."),
 ("Usage Declaration","is made under","Data Licence Agreement","n : 1","AUM figures for index fees come from 06 measures."),
 ("Licence Audit","produces","Licence Compliance Finding","1 : 0..n",""),
 ("Data Licence Agreement","has","Commercial Terms","1 : 1",""),
 ("Data Licence Agreement","is billed by","Data Invoice","1 : 0..n","Accounting of invoices is handled by Finance / 10."),
 ("Data Licence Agreement","is allocated by","Data Cost Allocation","1 : 0..n",""),
 ("Data Cost Allocation","references","Org Unit (09: OU-) / Allocation Method (10: ALM-)","n : 1",""),
 ("Data Licence Agreement","is renewed via","Renewal Case","1 : 0..n",""),
 ("Dataset","is governed by","Vendor Data SLA","1 : 0..n",""),
 ("Dataset","has","Vendor Data Issue","1 : 0..n","Issues may relate to the firm's own products (01) or people (02) as held by the vendor."),
 ("Data Licence Agreement","is distinct from","Distribution Agreement (05: AGR-)","n/a","Data bought from vendors = DLA- (14); data exchanged with distribution partners = AGR- (05)."),
]

SRC = [
 ("FISD (SIIA) market data policy best practices and terminology","Financial Information Services Division, SIIA","https://fisd.net","Member resources; public summaries","Display, non-display and derived data definitions; standardisation of market data policies","Permitted Use Category, Usage Mode, Non-Display Use Type, Derived Data Ownership, declarations",["FISD"]),
 ("EU Benchmarks Regulation (EU) 2016/1011, as amended by Regulation (EU) 2025/914","European Union","https://eur-lex.europa.eu/eli/reg/2016/1011","Regulation","Definition of benchmark and use of a benchmark by investment funds; scope reduced to critical, significant, EU climate and certain commodity benchmarks from 2026-01-01; contingency plans","Index Use, BMR Use Indicator, BMR Benchmark Category, Contingency Plan",["EU BMR"]),
 ("ESMA benchmarks register and BMR public statements","ESMA","https://www.esma.europa.eu","Public","Register of administrators and third-country benchmarks; transitional provisions under the BMR review (statement of 16 Dec 2025)","BMR Register Status",["ESMA BMR Register"]),
 ("UK Benchmarks Regulation and FCA benchmarks register","UK FCA","https://register.fca.org.uk/BenchmarksRegister","Public","UK register of benchmark administrators and benchmarks","Administrator Register Status (UK)",["UK FCA Benchmarks Register"]),
 ("Digital Operational Resilience Act (EU) 2022/2554","European Union","https://eur-lex.europa.eu/eli/reg/2022/2554/oj","Regulation","ICT third-party risk, contractual provisions, exit strategies, register of information (Art. 28)","Vendor Risk & Resilience, Termination and exit",["DORA"]),
 ("Commission Implementing Regulation (EU) 2024/2956 - register of information templates","European Union","https://eur-lex.europa.eu/eli/reg_impl/2024/2956/oj","Regulation","Standard templates for the register of information: contractual arrangements, ICT service types, function criticality, locations, subcontractors, substitutability","ICT Third-Party Register Entry",["DORA RoI ITS"]),
 ("FCA PS21/3 Building operational resilience (SYSC 15A)","UK FCA","https://www.fca.org.uk/publications/policy-statements/ps21-3-building-operational-resilience","Regulation","Important business services, impact tolerances, mapping of third-party dependencies","UK Important Business Service Mapping, Impact Tolerance Dependency",["UK FCA SYSC 15A"]),
 ("AICPA SOC 2 - Trust Services Criteria","AICPA","https://www.aicpa-cima.com/topic/audit-assurance/audit-and-assurance-greater-than-soc-2","Standard (attestation)","SOC 2 Type I / II reports on security, availability, processing integrity, confidentiality and privacy","Assurance Report",["AICPA SOC 2"]),
 ("ISO/IEC 27001","ISO / IEC","https://www.iso.org/standard/27001","Standard (purchase)","Information security management system certification","Assurance Report Type",[]),
 ("Interagency Guidance on Third-Party Relationships: Risk Management (2023)","US Federal Reserve, FDIC, OCC","https://www.federalregister.gov/documents/2023/06/09/2023-12340/interagency-guidance-on-third-party-relationships-risk-management","Public guidance (banking; used as good practice)","Third-party lifecycle: planning, due diligence, contract negotiation, monitoring, termination","Risk Assessment Type, Vendor Risk Domain, Strategic Tier",["US Interagency TPRM Guidance"]),
 ("DCAM - Data Management Capability Assessment Model","EDM Council","https://edmcouncil.org/frameworks/dcam/","Member framework","Data ownership, stewardship, data quality management, data sourcing","Dataset ownership, SLA Metric, Data Management Metadata",["DCAM"]),
 ("CDMC - Cloud Data Management Capabilities","EDM Council","https://edmcouncil.org/frameworks/cdmc/","Free licence","Cataloguing and classification, authoritative sources, data sharing and lineage controls in cloud","Dataset classification, Authoritative Source Indicator, Hosting Model, Lineage",["CDMC"]),
 ("Snowflake Marketplace / Secure Data Sharing documentation","Snowflake","https://docs.snowflake.com/en/collaboration/collaboration-marketplace-about","Public documentation","Listings, provider/consumer model, paid listings, secure data sharing","Delivery Method (Cloud Data Share), Marketplace Listing",["Snowflake Marketplace"]),
 ("Bloomberg Data License (public product description)","Bloomberg","https://professional.bloomberg.com/products/data/data-license/","Public description; licensed product","Enterprise data delivery across reference, pricing, ESG, regulatory data; pricing by data and applications rather than users","Licence Model, Entitlement Type",[]),
 ("MSCI Index License Agreement for Funds (SEC filed exhibit)","MSCI Inc. / SEC EDGAR","https://www.sec.gov/Archives/edgar/data/1408198/000119312512086989/d264713dex101.htm","Public filing","Index licence for funds: AUM-based fees on average daily net assets, quarterly in arrears, trademark use, product coverage","Index Product Coverage, Index Fee Basis, Usage Declaration (AUM)",["MSCI Index Licence"]),
 ("Morningstar data licensing (public reporting)","Morningstar / Financial Planning","https://www.financial-planning.com/news/consultants-call-morningstar-billing-unfair","Public article","Departmental licensing, affiliate sharing restrictions, redistribution fees","Licensed Business Units, Affiliate Sharing, Redistribution",[]),
 ("FTSE Russell EU Benchmark Regulation FAQs (July 2026)","LSEG FTSE Russell","https://www.lseg.com/content/dam/ftse-russell/en_us/documents/faq/eu-benchmark-regulation-faqs-july-2026.pdf","Public","Index provider position on BMR status after the 2026 review","BMR Register Status",[]),
 ("GDPR (EU) 2016/679 and UK GDPR","European Union / UK","https://eur-lex.europa.eu/eli/reg/2016/679/oj","Regulation","Personal data in purchased contact datasets; processing and legal basis","Contains Personal Data, Personal Data Use Restrictions",["GDPR"]),
 ("ISO 4217 / ISO 3166 / ISO 8601","ISO","https://www.iso.org","Standard; code lists widely available","Currency, country and date codes","Reference code lists used throughout",["ISO 4217"]),
]
