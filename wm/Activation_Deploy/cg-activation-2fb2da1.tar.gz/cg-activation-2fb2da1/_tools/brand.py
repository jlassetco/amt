"""Applies a brand theme (brand/<name>.css and brand/<name>-logo.svg) to the project's HTML outputs.

A page opts in with two empty marker pairs, which apply() fills (or empties for --brand none); re-applying is idempotent:
    <!--brand:css--><!--/brand:css-->     in <head>, after the page's own <style>
    <!--brand:logo--><!--/brand:logo-->   where the logo goes in the header
Usage: python brand.py [--brand kpmg|none] FILE.html ...   (rewrites each file in place)
"""
import os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT = "kpmg"


def arg(argv, default=DEFAULT):
    """Reads --brand NAME from argv (default kpmg) and removes it."""
    if "--brand" in argv:
        i = argv.index("--brand")
        name = argv[i + 1]
        del argv[i:i + 2]
        return name
    return default


def _fill(html, slot, content):
    pat = re.compile(rf"(<!--brand:{slot}-->).*?(<!--/brand:{slot}-->)", re.S)
    assert pat.search(html), f"page has no <!--brand:{slot}--> marker"
    return pat.sub(lambda m: m.group(1) + content + m.group(2), html, count=1)


def apply(html, name=DEFAULT):
    if name == "none":
        return _fill(_fill(html, "css", ""), "logo", "")
    css_path = os.path.join(HERE, "brand", f"{name}.css")
    assert os.path.exists(css_path), f"unknown brand {name!r}: no {css_path}"
    css = open(css_path, encoding="utf-8").read()
    logo_path = os.path.join(HERE, "brand", f"{name}-logo.svg")
    logo = open(logo_path, encoding="utf-8").read().strip() if os.path.exists(logo_path) else ""
    return _fill(_fill(html, "css", f"\n<style>\n{css}</style>\n"), "logo", logo)


if __name__ == "__main__":
    args = sys.argv[1:]
    name = arg(args)
    for path in args:
        with open(path, encoding="utf-8") as f:
            html = f.read()
        with open(path, "w", encoding="utf-8") as f:
            f.write(apply(html, name))
        print("branded", path, "|", name)
