"""Builds 00_Program/Business_Capability_Map.xlsx: the business capability map (Enterprise_Expansion_Plan.md §5) and the
area register (§8), from capability_map/content_capabilities.py and capability_map/areas.py.

Validates before writing (unique ids, known domains and areas, exactly one mastering domain per L2 capability, every Data
Domain in an area, every domain mastered by at least one capability or explained in COVERAGE_NOTES, an owner role on every
L2 capability, CHANGELOG and UNCOVERED_CONCEPTS entries that point at real capabilities, domains and concepts) and runs
the coverage test: every L2 capability is run by at least one live function of data_products/framework.FUNCTIONS
(framework.RETIRED_FUNCTIONS left out); capabilities a retired function still names are listed after the build line.
Wealth model (W0, CW-018): the registered Data Domains are read from domains.py (every domain not in RETIRED_DOMAINS);
capabilities may name only the live areas of areas.py. The W0 registers (REMOVED_W0, MOVED_W0, L1_CHANGES_W0) are
checked against the live ids and listed on the Overview sheet. If content_capabilities.py does not load or does not validate,
the errors are printed and the script exits 1 without a traceback and without writing the workbook.
Usage: /usr/bin/python3 build_capability_map.py
"""
import os, re, sys
from collections import Counter, defaultdict

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "capability_map"))
from openpyxl import Workbook  # noqa: E402
from taxonomy_builder import ROOT, DD_NAMES, header, cell, title, BODY, BOLD, MID, LIGHT, CENTER, WRAP  # noqa: E402
import areas as ar  # noqa: E402
from domains import DD_NAMES as REGISTERED, RETIRED_DOMAINS, WEALTH_DOMAINS  # noqa: E402
try:
    import content_capabilities as cc  # noqa: E402
except Exception as e:      # content mid-edit: report, do not trace back
    raise SystemExit(f"[capability map] capability_map/content_capabilities.py does not load: "
                     f"{e.__class__.__name__}: {e}")

OUT = os.path.join(ROOT, "00_Program", "Business_Capability_Map.xlsx")
L2_FIELDS = ("id", "name", "area", "masters", "reads", "lines", "owner_role", "definition", "added")
CHANGE_FIELDS = ("masters", "reads", "lines", "name", "definition", "added", "area", "note")
ADDED = ("", "Step 5", "Phase 2 review", "W0")
UK_SPELLINGS = re.compile(r"\b(organis\w*|authoris\w*|recognis\w*|prioritis\w*|categoris\w*|analys(e|ed|es|ing)|"
                          r"modell\w*|catalogu\w*|programme\w*|licence\w*|centre\w*|behaviour\w*|colour\w*|"
                          r"favour\w*|labour\w*|cheque\w*|defence|judgement)\b", re.I)


def l2s():
    return [(l1, c) for l1 in cc.CAPABILITIES for c in l1["l2"]]


def lines_of(c):
    return list(cc.BUSINESS_LINES) if c["lines"] == cc.ALL else list(c["lines"])


def validate():
    errs = []
    # the registered, non-retired Data Domains (domains.py) and the live areas (areas.py)
    names, area_ids = {n: REGISTERED[n] for n in WEALTH_DOMAINS}, set(ar.LIVE_AREA_IDS)
    # Areas and domains
    if ar.DOMAIN_NAMES != REGISTERED:
        errs.append("areas.DOMAIN_NAMES differs from domains.DD_NAMES")
    for n, nm in DD_NAMES.items():
        if REGISTERED.get(n) != nm:
            errs.append(f"domains.DD_NAMES[{n}] {REGISTERED.get(n)!r} differs from taxonomy_builder {nm!r}")
    for k, v in Counter(a["id"] for a in ar.AREAS).items():
        if v > 1: errs.append(f"area id {k} duplicated")
    if sum(1 for a in ar.AREAS if a.get("band")) != 1:
        errs.append("exactly one area must be flagged band")
    missing = sorted(set(names) - set(ar.DOMAIN_AREA))
    if missing:
        errs.append(f"Data Domains with no home area in DOMAIN_AREA: {missing}")
    unknown = sorted(set(ar.DOMAIN_AREA) - set(REGISTERED))
    if unknown:
        errs.append(f"DOMAIN_AREA names unregistered Data Domains: {unknown}")
    for n, a in ar.DOMAIN_AREA.items():
        if a not in area_ids: errs.append(f"DOMAIN_AREA[{n}] unknown area {a}")
    for n in ar.OPTIONAL_DOMAINS:
        if n not in names: errs.append(f"OPTIONAL_DOMAINS: {n} is not a registered, non-retired Data Domain")
    for d, dflt, alt, why in ar.ALTERNATIVES:
        if d not in names: errs.append(f"ALTERNATIVES: unknown domain {d}")
        elif ar.DOMAIN_AREA[d] != dflt: errs.append(f"ALTERNATIVES {d}: default {dflt} is not DOMAIN_AREA {ar.DOMAIN_AREA[d]}")
        if alt not in area_ids or alt == dflt: errs.append(f"ALTERNATIVES {d}: bad alternative area {alt}")
        if not why.strip(): errs.append(f"ALTERNATIVES {d}: no reason")
    # Capabilities
    ids = Counter([l1["id"] for l1 in cc.CAPABILITIES] + [c["id"] for _, c in l2s()])
    errs += [f"duplicate id {k}" for k, v in ids.items() if v > 1]
    cnames = Counter(c["name"] for _, c in l2s())
    errs += [f"duplicate L2 name {k}" for k, v in cnames.items() if v > 1]
    for l1 in cc.CAPABILITIES:
        if not re.fullmatch(r"C-\d{2}", l1["id"]): errs.append(f"{l1['id']}: L1 id format")
        if l1["area"] not in area_ids: errs.append(f"{l1['id']}: unknown area {l1['area']}")
        if not l1["l2"]: errs.append(f"{l1['id']}: no L2 capabilities")
    for l1, c in l2s():
        i = c.get("id")
        for f in L2_FIELDS:
            if f not in c: errs.append(f"{i}: missing {f}")
        if not re.fullmatch(re.escape(l1["id"]) + r"\.\d{2}", i): errs.append(f"{i}: id does not sit under {l1['id']}")
        if not isinstance(c["masters"], str): errs.append(f"{i}: masters must be exactly one domain")
        elif c["masters"] not in names:
            errs.append(f"{i}: masters {'retired' if c['masters'] in RETIRED_DOMAINS else 'unknown'} domain {c['masters']}")
        for r in c["reads"]:
            if r not in names: errs.append(f"{i}: reads {'retired' if r in RETIRED_DOMAINS else 'unknown'} domain {r}")
        if c["masters"] in c["reads"]: errs.append(f"{i}: reads its own mastering domain")
        if len(set(c["reads"])) != len(c["reads"]): errs.append(f"{i}: duplicate reads")
        if c["area"] not in area_ids: errs.append(f"{i}: unknown area {c['area']}")
        if not str(c.get("owner_role", "")).strip(): errs.append(f"{i}: no owner_role")
        if c.get("added") not in ADDED: errs.append(f"{i}: added must be one of {ADDED}")
        if c["lines"] != cc.ALL:
            if not c["lines"] or any(x not in cc.BUSINESS_LINES for x in c["lines"]):
                errs.append(f"{i}: bad lines {c['lines']}")
            elif set(c["lines"]) == set(cc.BUSINESS_LINES):
                errs.append(f"{i}: lists every business line; use ALL")
        d = c["definition"].strip()
        if not d.endswith(".") or re.search(r"\.\s+[A-Z]", d[:-1]): errs.append(f"{i}: definition must be one sentence")
        for text in (c["name"], d):
            for m in UK_SPELLINGS.finditer(text):
                errs.append(f"{i}: UK spelling {m.group(0)!r}")
    l2_ids = {c["id"] for _, c in l2s()}
    for cid, f, before, after, why in cc.CHANGELOG:
        if cid not in l2_ids: errs.append(f"CHANGELOG: unknown capability {cid}")
        if f not in CHANGE_FIELDS: errs.append(f"CHANGELOG {cid}: unknown field {f}")
        if not why.strip(): errs.append(f"CHANGELOG {cid} {f}: no reason")
        if f == "added" and cid in l2_ids and not next(c for _, c in l2s() if c["id"] == cid)["added"]:
            errs.append(f"CHANGELOG {cid}: logged as added but not flagged added")
    for _, c in l2s():
        if c["added"] and not any(x[0] == c["id"] and x[1] == "added" for x in cc.CHANGELOG):
            errs.append(f"{c['id']}: flagged added but no CHANGELOG entry")
    try:
        sys.path.insert(0, os.path.join(HERE, "consolidation"))
        import decisions as dec
        owned = {(cn, o) for cn, o, *_ in dec.CONCEPT_OWNERSHIP}
        names_by_owner = defaultdict(set)
        for cn, o in owned: names_by_owner[o].add(cn)
        for concept, d, why in cc.UNCOVERED_CONCEPTS:
            parts = [x.strip() for x in re.split(r"\s+and\s+", concept)]
            if not any(any(cn.startswith(p) for cn in names_by_owner[d]) for p in parts):
                errs.append(f"UNCOVERED_CONCEPTS: {concept!r} is not a concept owned by {d} in CONCEPT_OWNERSHIP")
    except ImportError:
        errs.append("cannot import consolidation/decisions.py to check UNCOVERED_CONCEPTS")
    for d, why in cc.COVERAGE_NOTES:
        if d not in names: errs.append(f"COVERAGE_NOTES: unknown domain {d}")
    mastered = {c["masters"] for _, c in l2s()}
    noted = {d for d, _ in cc.COVERAGE_NOTES}
    for n in names:
        if n not in mastered and n not in noted:
            errs.append(f"domain {n} masters no capability and has no COVERAGE_NOTES entry")
        if n in mastered and n in noted:
            errs.append(f"domain {n} is mastered but also listed in COVERAGE_NOTES")
    # W0 re-cut registers (CW-004, CW-018): removed and moved ids are not live, successors and new ids are
    l1_ids = {l1["id"] for l1 in cc.CAPABILITIES}
    removed = [x[0] for x in getattr(cc, "REMOVED_W0", [])]
    errs += [f"REMOVED_W0: {k} listed twice" for k, v in Counter(removed).items() if v > 1]
    for cid, nm, d, succ, why in getattr(cc, "REMOVED_W0", []):
        if cid in l2_ids: errs.append(f"REMOVED_W0: {cid} is still a live capability")
        if d not in REGISTERED: errs.append(f"REMOVED_W0 {cid}: unknown wholesale domain {d}")
        if not why.strip(): errs.append(f"REMOVED_W0 {cid}: no reason")
        ends = re.findall(r"C-\d{2}\.\d{2}", succ)
        for x in ends:
            if x not in l2_ids: errs.append(f"REMOVED_W0 {cid}: successor {x} is not a live capability")
        if " to " in succ and len(ends) == 2:
            lo, hi = ends
            if lo[:4] != hi[:4] or lo > hi: errs.append(f"REMOVED_W0 {cid}: bad successor range {succ}")
        if succ.strip() and not ends: errs.append(f"REMOVED_W0 {cid}: successor {succ!r} names no capability id")
    moved = getattr(cc, "MOVED_W0", {})
    errs += [f"MOVED_W0: {v} is the new id of more than one capability" for v, k in Counter(moved.values()).items() if k > 1]
    for old, new in moved.items():
        if old in l2_ids: errs.append(f"MOVED_W0: old id {old} is still a live capability")
        if old in removed: errs.append(f"MOVED_W0: {old} is also in REMOVED_W0")
        if new not in l2_ids: errs.append(f"MOVED_W0 {old}: new id {new} is not a live capability")
        elif old[:4] == new[:4]: errs.append(f"MOVED_W0 {old}: id {new} did not change L1")
    for lid, before, after, why in getattr(cc, "L1_CHANGES_W0", []):
        if after == "removed":
            if lid in l1_ids: errs.append(f"L1_CHANGES_W0: {lid} is listed as removed but is still live")
        elif lid not in l1_ids: errs.append(f"L1_CHANGES_W0: unknown L1 {lid}")
        if not why.strip(): errs.append(f"L1_CHANGES_W0 {lid}: no reason")
    return errs


# Capability coverage test (Wealth_Manager_Rework_Plan.md §7 and §8.1; W5, amended at WP0): every L2 capability has a
# mastering domain (validate() checks the domain) and is run by at least one live function of
# data_products/framework.FUNCTIONS. Retired functions are framework.RETIRED_FUNCTIONS (WP0, CW-200); a capability run
# only by retired functions fails, as in dp_model.py. Capabilities that a retired function still lists are reported.
def function_coverage():
    """(errors, notes): L2 capabilities with no live function and functions naming unknown capabilities are errors;
    notes list [(area, capability id, name, retired functions)] for capabilities a retired function still names."""
    sys.path.insert(0, os.path.join(HERE, "data_products"))
    try:
        import framework as fw
    except Exception as e:
        return [f"cannot import data_products/framework.py for the function coverage test ({e.__class__.__name__}: {e})"], []
    retired = dict(getattr(fw, "RETIRED_FUNCTIONS", {}))
    ids = {c["id"]: c for _, c in l2s()}
    run = defaultdict(list)
    errs = []
    for f in fw.FUNCTIONS:
        for cid in f[3]:
            if cid not in ids: errs.append(f"function {f[0]} runs unknown capability {cid}")
            run[cid].append(f[0])
    notes = []
    for cid, c in ids.items():
        live = [x for x in run[cid] if x not in retired]
        if not live:
            errs.append(f"{cid} {c['name']}: run by no live function in framework.FUNCTIONS"
                        + (f" (only retired {', '.join(run[cid])})" if run[cid] else ""))
        old = [x for x in run[cid] if x in retired]
        if old:
            notes.append((c["area"], cid, c["name"], old))
    return errs, sorted(notes)


try:
    errs = validate()
    fn_errs, fn_wp0 = function_coverage()
    errs += fn_errs
except Exception as e:      # content mid-edit (a missing key or field): report, do not trace back
    errs = [f"validation could not complete ({e.__class__.__name__}: {e}); check content_capabilities.py"]
if errs:
    raise SystemExit(f"[capability map] validation failed ({len(errs)} error(s)):\n  " + "\n  ".join(errs))

AN, DA = ar.AREA_NAMES, ar.DOMAIN_AREA
DN = {n: ar.DOMAIN_NAMES[n] for n in WEALTH_DOMAINS}     # retired domains are not rendered
dl = ar.label
caps = l2s()
mastered_by, read_by = defaultdict(list), defaultdict(list)
for _, c in caps:
    mastered_by[c["masters"]].append(c["id"])
    for r in c["reads"]:
        read_by[r].append(c["id"])
alt_by = {d: (alt, why) for d, _, alt, why in ar.ALTERNATIVES}
zero = [n for n in DN if not mastered_by[n]]
single = [n for n in DN if len(mastered_by[n]) == 1]
added = [c for _, c in caps if c["added"] == "Step 5"]
added_p2 = [c for _, c in caps if c["added"] == "Phase 2 review"]
roles = sorted({c["owner_role"] for _, c in caps})
lines_txt = lambda c: "All" if c["lines"] == cc.ALL else ", ".join(c["lines"])
CONFIRM = "Wealth-manager W0 draft (2026-10-14), coverage test at W5, for confirmation with the client's data office"

wb = Workbook()

# Overview -----------------------------------------------------------------------------------------------------------
ov = wb.active; ov.title = "Overview"
title(ov, "Business Capability Map and Area Register",
      f"Wealth manager (direct, advice and own funds; {len(cc.BUSINESS_LINES)} business lines) | Scope: US | {CONFIRM}")
header(ov, 4, ["Topic", "Detail"], [28, 120])
area_counts = Counter(c["area"] for _, c in caps)
rows = [
    ("Purpose", "Checks the Data Domain list against what the firm does (Enterprise_Expansion_Plan.md §5). Every L2 "
                "capability names the one Data Domain that masters its core data and the domains it reads. The map also "
                "assigns each Data Domain a home area (§8), which is a presentation layer: areas never master data."),
    ("Coverage test", "Every L2 capability must have exactly one mastering domain; a capability with none would be a "
                      "missing domain. Every Data Domain should master at least one capability; a domain with none is a "
                      "candidate to fold into a neighbor (see Domain Coverage)."),
    ("How to read", "Capabilities: L1 capability areas and L2 capabilities, with the mastering domain, the domains read, "
                    "the business lines served and the area where the function usually sits. 'Function area differs' "
                    "marks capabilities run in one area whose data is mastered by a domain homed in another; that is "
                    "expected and shows where owners cross area lines. Capability-Domain Map: one row per capability and "
                    "domain, with the role Masters or Reads. Areas: member domains of each area. Boundary Calls: domains "
                    "the client may place in another area. Business Lines: capabilities shared by every line and those "
                    "specific to some."),
    ("Ownership", "Data owners are assigned by capability (the function that runs it), so an owner sees every domain "
                  "their capabilities master, whichever area those domains are shown in."),
    ("Business lines", "; ".join(f"{k} = {v}" for k, v in cc.BUSINESS_LINES.items()) + ". 'All' means every line."),
    ("Counts", f"{len(cc.CAPABILITIES)} L1 capability areas | {len(caps)} L2 capabilities | {len(DN)} Data Domains in "
               f"{len(ar.AREAS)} areas | {len(DN) - len(zero)} domains master at least one capability, {len(zero)} master "
               f"none, {len(single)} master exactly one | {sum(len(c['reads']) for _, c in caps)} read links | "
               f"{len(roles)} owner roles | {len(ar.ALTERNATIVES)} boundary calls"),
    ("Step 5 coverage test", f"Re-run 2026-10-07 against the drafted Data Domains 17-44: {len(added)} capabilities added, "
                             f"{sum(1 for x in cc.CHANGELOG if x[1] == 'masters')} re-pointed to another mastering domain, "
                             f"{len(cc.CHANGELOG)} changes in all with the Phase 2 review (Step 5 Changes sheet). Domains that master exactly one "
                             f"capability: {', '.join(dl(n) for n in single) or 'none'}."),
    ("Phase 2 review", f"Re-checked 2026-10-14 against the per-area review findings: {len(added_p2)} capabilities added "
                       f"({', '.join(c['id'] for c in added_p2)}), "
                       f"{sum(1 for x in cc.CHANGELOG if x[1] == 'area')} function areas changed, findings kept with a "
                       f"note recorded as 'note' rows; listed at the end of the Step 5 Changes sheet."),
    ("W0 re-cut", f"Wealth-manager re-cut 2026-10-14 (CW-004, CW-018): "
                  f"{sum(1 for _, c in caps if c['added'] == 'W0')} capabilities added, "
                  f"{len(getattr(cc, 'REMOVED_W0', []))} removed, {len(getattr(cc, 'MOVED_W0', {}))} moved to another L1 "
                  f"(new id), {len(getattr(cc, 'L1_CHANGES_W0', []))} L1 capability areas changed. The wholesale map is "
                  f"kept at git tag wholesale-v1.0."),
] + [(f"W0 removed {cid}", f"{nm} (was mastered by {dl(d) if d in ar.DOMAIN_NAMES else d}). Successor: "
                           f"{succ or 'none'}. {why}") for cid, nm, d, succ, why in getattr(cc, "REMOVED_W0", [])] + [
    ("W0 moved", "; ".join(f"{o} to {n}" for o, n in getattr(cc, "MOVED_W0", {}).items()) +
                 ". Pre-W0 CHANGELOG entries of a moved capability carry its new id.")
] + [(f"W0 L1 {lid}", f"{before} to {after}. {why}") for lid, before, after, why in getattr(cc, "L1_CHANGES_W0", [])] + [
    ("Reads convention", cc.READS_CONVENTION),
    ("Owner roles", "Each L2 capability names the business role that owns its data (Owner Role). The Data Owners sheet "
                    "groups capabilities and mastered domains by role, to seed the data-owner assignments of Phase E."),
    ("Capabilities by function area", " | ".join(f"{AN[a]}: {area_counts.get(a, 0)}" for a in ar.AREA_IDS)),
    ("Optional domains", " ".join(f"{dl(n)}: {why}" for n, why in ar.OPTIONAL_DOMAINS.items())),
    ("Coverage notes", "None: every Data Domain masters at least one capability." if not cc.COVERAGE_NOTES else
                       " | ".join(f"{dl(d)}: {why}" for d, why in cc.COVERAGE_NOTES)),
] + [(f"Gap finding {i}", t) for i, t in enumerate(cc.GAP_NOTES, 1)] + [
    (f"Uncovered concept {i}", f"{c} ({dl(d)}): {why}") for i, (c, d, why) in enumerate(cc.UNCOVERED_CONCEPTS, 1)
] + [(f"Drafting note {i}", t) for i, t in enumerate(cc.DRAFTING_NOTES, 1)] + [
    ("Source", "Built by _tools/build_capability_map.py from _tools/capability_map/content_capabilities.py and "
               "areas.py. Edit those files and rebuild; do not edit this workbook."),
]
for r, (k, v) in enumerate(rows, 5):
    cell(ov, r, 1, k, BOLD); cell(ov, r, 2, v)

# Areas --------------------------------------------------------------------------------------------------------------
sh = wb.create_sheet("Areas")
title(sh, "Areas and Member Data Domains", "Each Data Domain has one home area (plan §8.1). Foundations is a band shown on "
      "every area view. Moving a domain is an edit to areas.py; the taxonomy does not change.")
header(sh, 4, ["#", "Area ID", "Area", "Description", "Band", "Member Data Domains", "# Domains",
               "# Capabilities sited here", "# Capabilities mastered by members"], [5, 9, 22, 50, 8, 52, 10, 12, 14])
r = 5
for a in sorted(ar.AREAS, key=lambda x: x["order"]):
    members = sorted(n for n, x in DA.items() if x == a["id"])
    vals = [a["order"], a["id"], a["name"], a["description"], "Yes" if a["band"] else "", "\n".join(dl(n) for n in members),
            len(members), area_counts.get(a["id"], 0), sum(len(mastered_by[n]) for n in members)]
    for ci, v in enumerate(vals, 1):
        cell(sh, r, ci, v, BOLD if ci == 3 else BODY, LIGHT if a["band"] else None, CENTER if ci in (1, 2, 5, 7, 8, 9) else WRAP)
    r += 1
sh.freeze_panes = "A5"

# Capabilities -------------------------------------------------------------------------------------------------------
sh = wb.create_sheet("Capabilities")
title(sh, "Business Capabilities (L1 > L2)", "Each L2 capability has exactly one mastering Data Domain. Function area is "
      "where the function usually sits; it may differ from the mastering domain's home area.")
header(sh, 4, ["L1 ID", "L1 Capability Area", "L2 ID", "L2 Capability", "Definition", "Masters (Data Domain)",
               "Mastering domain's area", "Reads (Data Domains)", "Business Lines", "Function Area", "Function area differs",
               "Owner Role", "Added"],
       [8, 26, 10, 30, 60, 30, 18, 40, 16, 18, 11, 28, 10])
r = 5
for li, l1 in enumerate(cc.CAPABILITIES):
    for ci, v in enumerate([l1["id"], l1["name"], "", "", l1["definition"], "", "", "", "", AN[l1["area"]], "", "", ""], 1):
        cell(sh, r, ci, v, BOLD, MID, WRAP)
    r += 1
    for c in l1["l2"]:
        differs = "Yes" if DA[c["masters"]] != c["area"] else ""
        vals = [l1["id"], l1["name"], c["id"], c["name"], c["definition"], dl(c["masters"]), AN[DA[c["masters"]]],
                "\n".join(dl(x) for x in c["reads"]), lines_txt(c), AN[c["area"]], differs, c["owner_role"], c["added"]]
        for ci, v in enumerate(vals, 1):
            cell(sh, r, ci, v, BOLD if ci == 4 else BODY, LIGHT if c["added"] else None,
                 CENTER if ci in (1, 3, 11, 13) else WRAP)
        r += 1
sh.freeze_panes = "E5"; sh.auto_filter.ref = f"A4:M{r-1}"

# Capability-Domain Map ----------------------------------------------------------------------------------------------
sh = wb.create_sheet("Capability-Domain Map")
title(sh, "Capability to Data Domain Register", "One row per capability and domain, with the role the domain plays. "
      "This register, not a hierarchy level, carries ownership (plan §5).")
header(sh, 4, ["L2 ID", "L2 Capability", "L1 Capability Area", "Data Domain", "Data Domain Name", "Role",
               "Domain's area", "Function area", "Crosses area", "Capability owner role"], [10, 32, 28, 8, 38, 10, 22, 22, 10, 28])
r = 5
for l1, c in caps:
    for d, role in [(c["masters"], "Masters")] + [(x, "Reads") for x in c["reads"]]:
        vals = [c["id"], c["name"], l1["name"], d, DN[d], role, AN[DA[d]], AN[c["area"]], "Yes" if DA[d] != c["area"] else "",
                c["owner_role"] if role == "Masters" else ""]
        for ci, v in enumerate(vals, 1):
            cell(sh, r, ci, v, BOLD if role == "Masters" and ci == 6 else BODY, MID if role == "Masters" else None,
                 CENTER if ci in (1, 4, 6, 9) else WRAP)
        r += 1
map_rows = r - 5
sh.freeze_panes = "C5"; sh.auto_filter.ref = f"A4:J{r-1}"

# Domain Coverage ----------------------------------------------------------------------------------------------------
sh = wb.create_sheet("Domain Coverage")
title(sh, "Data Domain Coverage", "Coverage test: every domain should master at least one capability. Zero mastered is "
      "flagged; a domain with none is a candidate to fold (plan §5).")
header(sh, 4, ["#", "Data Domain", "Home Area", "# Capabilities mastered", "# Capabilities reading", "Capabilities mastered",
               "Flag", "Note"], [6, 38, 22, 12, 12, 46, 22, 50])
r = 5
notes = dict(cc.COVERAGE_NOTES)
for n in sorted(DN):
    m, rd = mastered_by[n], read_by[n]
    flag = "Zero mastered" if not m else ("Read by none" if not rd else ("Masters one" if len(m) == 1 else ""))
    note = notes.get(n, ar.OPTIONAL_DOMAINS.get(n, ""))
    if n in ar.OPTIONAL_DOMAINS: note = "Optional domain. " + note
    vals = [n, DN[n], AN[DA[n]], len(m), len(rd), ", ".join(m), flag, note]
    for ci, v in enumerate(vals, 1):
        cell(sh, r, ci, v, BOLD if ci == 7 and flag else BODY,
             ("FCE4D6" if flag != "Masters one" else LIGHT) if flag else None,
             CENTER if ci in (1, 4, 5) else WRAP)
    r += 1
sh.freeze_panes = "C5"; sh.auto_filter.ref = f"A4:H{r-1}"

# Boundary Calls -----------------------------------------------------------------------------------------------------
sh = wb.create_sheet("Boundary Calls")
title(sh, "Area Boundary Calls for the Client", "Domains the client may home in another area. The draft area is used "
      "until the client confirms; the change is an edit to areas.py.")
header(sh, 4, ["#", "Data Domain", "Draft Area", "Alternative Area", "Reason", "# Capabilities mastered",
               "Function areas of those capabilities", "Client decision"], [5, 38, 22, 22, 62, 12, 34, 18])
fa = {c["id"]: c["area"] for _, c in caps}
for i, (d, dflt, alt, why) in enumerate(ar.ALTERNATIVES, 1):
    sites = Counter(AN[fa[x]] for x in mastered_by[d])
    vals = [i, dl(d), AN[dflt], AN[alt], why, len(mastered_by[d]), ", ".join(f"{k} ({v})" for k, v in sites.most_common()), ""]
    for ci, v in enumerate(vals, 1):
        cell(sh, 4 + i, ci, v, BODY, None, CENTER if ci in (1, 6) else WRAP)
sh.freeze_panes = "A5"

# Business Lines -----------------------------------------------------------------------------------------------------
sh = wb.create_sheet("Business Lines")
title(sh, "Capabilities by Business Line", "Shared by all lines: serves every line. Shared with some: serves more than one "
      "line but not all. Specific: serves this line only. Below the summary: the line-specific capabilities, then a matrix "
      "of every capability that does not serve all lines.")
LW = [10, 46, 11, 11, 11, 11, 11, 11, 14]
header(sh, 4, ["Code", "Business Line", "# Serving", "Shared by all lines", "Shared with some", "Specific"], LW[:6])
n_all = sum(1 for _, c in caps if c["lines"] == cc.ALL)
specific = defaultdict(list)
r = 5
for code, nm in cc.BUSINESS_LINES.items():
    serving = [c for _, c in caps if code in lines_of(c)]
    specific[code] = [c for c in serving if c["lines"] != cc.ALL and len(c["lines"]) == 1]
    vals = [code, nm, len(serving), n_all, len(serving) - n_all - len(specific[code]), len(specific[code])]
    for ci, v in enumerate(vals, 1):
        cell(sh, r, ci, v, BOLD if ci == 2 else BODY, None, WRAP if ci == 2 else CENTER)
    r += 1
r += 1
header(sh, r, ["Line", "Capability specific to the line", "Function Area", "Masters"], LW[:4]); r += 1
for code in cc.BUSINESS_LINES:
    for c in specific[code]:
        for ci, v in enumerate([code, f"{c['id']} {c['name']}", AN[c["area"]], c["masters"]], 1):
            cell(sh, r, ci, v, BODY, None, CENTER if ci in (1, 4) else WRAP)
        r += 1
r += 1
header(sh, r, ["L2 ID", "L2 Capability"] + list(cc.BUSINESS_LINES) + ["Scope"], LW); r += 1
for _, c in caps:
    if c["lines"] == cc.ALL:
        continue
    scope = "Specific" if len(c["lines"]) == 1 else "Some lines"
    vals = [c["id"], c["name"]] + ["X" if k in c["lines"] else "" for k in cc.BUSINESS_LINES] + [scope]
    for ci, v in enumerate(vals, 1):
        cell(sh, r, ci, v, BODY, LIGHT if scope == "Specific" else None, WRAP if ci == 2 else CENTER)
    r += 1
sh.freeze_panes = "A5"

# Data Owners -------------------------------------------------------------------------------------------------------
sh = wb.create_sheet("Data Owners")
title(sh, "Data Owner Roles by Capability", "Seed for the data-owner register (plan §5): each L2 capability's owner role, "
      "with the capabilities it owns and the Data Domains those capabilities master. Names are assigned in Phase E.")
header(sh, 4, ["Owner Role", "# Capabilities", "Capabilities owned", "Data Domains mastered", "Function areas", "Named owner"],
       [34, 10, 60, 46, 26, 20])
r = 5
for role in roles:
    cs = [c for _, c in caps if c["owner_role"] == role]
    doms = sorted({c["masters"] for c in cs})
    vals = [role, len(cs), "\n".join(f"{c['id']} {c['name']}" for c in cs), "\n".join(dl(d) for d in doms),
            ", ".join(sorted({AN[c["area"]] for c in cs})), ""]
    for ci, v in enumerate(vals, 1):
        cell(sh, r, ci, v, BOLD if ci == 1 else BODY, None, CENTER if ci == 2 else WRAP)
    r += 1
sh.freeze_panes = "B5"; sh.auto_filter.ref = f"A4:F{r-1}"

# Step 5 Changes -----------------------------------------------------------------------------------------------------
sh = wb.create_sheet("Step 5 Changes")
title(sh, "Step 5 Coverage Test: Changes to the Step 0 Map", "Every change made when the map was re-tested against the "
      "drafted Data Domains 17-44 (2026-10-07), and at the Phase 2 review (2026-10-14), with the reason. Owner roles were "
      "added to every capability.")
header(sh, 4, ["#", "L2 ID", "L2 Capability", "Change", "Before", "After", "Reason"], [5, 10, 32, 12, 30, 34, 70])
cname = {c["id"]: c["name"] for _, c in caps}
for i, (cid, f, before, after, why) in enumerate(cc.CHANGELOG, 1):
    vals = [i, cid, cname.get(cid, ""), f, before, after, why]
    for ci, v in enumerate(vals, 1):
        cell(sh, 4 + i, ci, v, BOLD if f in ("masters", "added") and ci == 4 else BODY,
             MID if f == "masters" else (LIGHT if f == "added" else None), CENTER if ci in (1, 2, 4) else WRAP)
sh.freeze_panes = "C5"; sh.auto_filter.ref = f"A4:G{4 + len(cc.CHANGELOG)}"

for ws in wb.worksheets:
    ws.sheet_view.showGridLines = False
wb.save(OUT)
print(f"[capability map] OK -> {os.path.relpath(OUT, ROOT)}: {len(cc.CAPABILITIES)} L1, {len(caps)} L2, "
      f"{map_rows} capability-domain links, {len(DN)} domains in {len(ar.AREAS)} areas, {len(zero)} with zero mastered"
      f"{' (' + ', '.join(zero) + ')' if zero else ''}, {len(single)} with one ({', '.join(single)}), "
      f"{len(added)} added at Step 5, {len(added_p2)} at the Phase 2 review, {len(cc.CHANGELOG)} changes logged, {len(roles)} owner roles, "
      f"{len(ar.ALTERNATIVES)} boundary calls")
print(f"[capability map] coverage test: {len(caps)} L2 capabilities, each with one mastering domain and at least one live "
      f"function (framework.RETIRED_FUNCTIONS left out); {len(fn_wp0)} still also named by a retired function"
      + (":" if fn_wp0 else "."))
for a, cid, nm, fns in fn_wp0:
    print(f"  {a:4} {cid} {nm} ({', '.join(fns)})")
