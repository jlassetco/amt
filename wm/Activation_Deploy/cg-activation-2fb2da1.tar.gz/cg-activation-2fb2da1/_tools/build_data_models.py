"""Builds 00_Program/Data_Product_Logical_Models.xlsx from data_models/ (keys.py + models_*.py), validated against the
consolidated taxonomy and the data product specs. build_explorer.py adds the same models to the explorer's product pages.
Usage: python build_data_models.py
"""
import os, sys
from openpyxl import Workbook

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "data_models"))
sys.path.insert(0, os.path.join(HERE, "data_products"))
from taxonomy_builder import ROOT, DD_NAMES, header, cell, title, BODY, BOLD, MID, LIGHT, CENTER, WRAP  # noqa: E402
import dm_model  # noqa: E402
import framework as fw  # noqa: E402

models, errs, warns = dm_model.validate()
if errs:
    raise SystemExit("Logical model validation failed:\n  " + "\n  ".join(errs))
for w in warns:
    print("WARN", w)
objs, specs, KEYS, REFS, _ = dm_model.load_all()
reg = {p[0]: p for p in fw.PRODUCTS}
order = [p[0] for p in fw.PRODUCTS if p[0] in models]          # live models only (dm_model.validate leaves out pending)
held = dm_model.pending_models()                                # products pending WP0 re-scope (CW-041): not built
dd = lambda n: f"{n} {DD_NAMES[n]}"
okey = lambda k: f"{k[0]} {k[1]}" if k else ""

wb = Workbook()
ov = wb.active; ov.title = "Overview"
title(ov, "Data Product Logical Models", f"Wealth manager (direct) | Scope: US | {fw.VERSION} | Built from _tools/data_models/ "
      "and validated against the taxonomy and the data product specs.")
header(ov, 4, ["Topic", "Description"], [30, 120])
n_ent = sum(len(models[p]["entities"]) for p in order)
n_rel = sum(len(models[p]["relationships"]) for p in order)
rows = [
    ("Purpose", "Shows how each data product's inputs fit together: entities, primary keys, foreign keys and relationships. "
     "Logical, not physical: no table names, platform data types, indexes or partitioning."),
    ("Scope", f"{len(order)} of {len([p for p in fw.PRODUCTS if not dm_model.dp_model.is_pending(p[0]) and not dm_model.dp_model.is_retired(p[0])])} live data products modeled ({n_ent} entities, {n_rel} relationships). "
     + (f"The models of the {len(held)} products pending WP0 re-scope are kept in models_*.py but not validated or "
        f"built here: {', '.join(held)}. " if held else "") +
     f"Key registry: {len(KEYS)} taxonomy objects with primary keys; {len(REFS)} reference attributes linked to their target objects."),
    ("Modeling style", "Foundational products are normalized (ER): one entity per core business object, child entities for "
     "repeating detail. Consumer-aligned products are star schemas: Fact entities at the product grain joined to conformed "
     "Dimension entities, with Bridge entities for many-to-many links."),
    ("Conformed dimensions", "A consumer model reuses a dimension from a foundational product's model (e.g. Salesperson "
     "from DP-009 Employee), inheriting its attributes and key, so every star shares the same, fully described dimension. "
     "The Entities tab shows the source in 'Conformed From'."),
    ("Two layers", "1) The key and link registry (keys.py) is defined once per taxonomy object: its primary key, whether an "
     "Attribute Group folds into its parent or becomes a child entity, and the target of each reference attribute. "
     "2) Product models (models_*.py) assemble a product's input objects into entities and relationships, reusing the registry."),
    ("Tabs", "Models: one row per product | Entities | Attributes: every attribute with PK / FK flags and its source taxonomy "
     "object | Relationships | Key Registry | Reference Links."),
    ("How to change", "Edit _tools/data_models/keys.py or models_*.py, then run python build_data_models.py and "
     "python build_explorer.py. Standard: _tools/data_models/CONTRACT.md."),
]
for i, (k, v) in enumerate(rows, 5):
    cell(ov, i, 1, k, BOLD); cell(ov, i, 2, v)

ms = wb.create_sheet("Models")
title(ms, "Models", "One row per modeled data product.")
header(ms, 4, ["Product ID", "Data Product", "Tier", "Style", "# Entities", "Facts", "Dimensions", "# Relationships",
               "# Attributes", "Notes"], [11, 34, 16, 8, 10, 30, 50, 12, 11, 60])
for i, pid in enumerate(order, 5):
    m = models[pid]
    E = m["entities"]
    vals = [pid, reg[pid][1], reg[pid][2], m["style"], len(E), ", ".join(e["name"] for e in E if e["role"] == "Fact"),
            ", ".join(e["name"] for e in E if e["role"] == "Dimension"), len(m["relationships"]),
            sum(len(e["attrs"]) for e in E), m["notes"]]
    for ci, v in enumerate(vals, 1):
        cell(ms, i, ci, v, BOLD if ci == 2 else BODY, None, CENTER if ci in (4, 5, 8, 9) else WRAP)
ms.freeze_panes = "C5"

es = wb.create_sheet("Entities")
title(es, "Entities", "Entities of each model, with role, grain, primary key and the taxonomy objects they hold.")
header(es, 4, ["Product ID", "Data Product", "Entity", "Role", "Grain", "Primary Key", "Taxonomy Objects", "# Attributes",
               "Conformed From", "Note"], [11, 30, 30, 11, 40, 36, 60, 10, 22, 50])
r = 5
for pid in order:
    for e in models[pid]["entities"]:
        vals = [pid, reg[pid][1], e["name"], e["role"], e["grain"], ", ".join(a["name"] for a in e["attrs"] if a["pk"]),
                "; ".join(okey(k) for k in e["objects"]), len(e["attrs"]),
                f"{e['conformed'][0]} {e['conformed'][1]}" if e.get("conformed") else "", e["note"]]
        for ci, v in enumerate(vals, 1):
            cell(es, r, ci, v, BOLD if ci == 3 else BODY, MID if e["role"] == "Fact" else None, CENTER if ci in (4, 8) else WRAP)
        r += 1
es.freeze_panes = "D5"; es.auto_filter.ref = f"A4:J{r-1}"

at = wb.create_sheet("Attributes")
title(at, "Attributes", "Every attribute of every entity. PK = part of the primary key; FK = carries the key of the named parent entity.")
header(at, 4, ["Product ID", "Entity", "Attribute", "PK", "FK To", "Type", "CDE", "PII", "Source Object", "Attribute ID", "Definition"],
       [11, 30, 32, 5, 26, 22, 6, 6, 36, 12, 70])
r = 5
for pid in order:
    for e in models[pid]["entities"]:
        for a in e["attrs"]:
            vals = [pid, e["name"], a["name"], "Y" if a["pk"] else "", a["fk"], a["type"], "Y" if a["cde"] else "",
                    "Y" if a["pii"] else "", okey(a["obj"]), a["id"], a["def"]]
            for ci, v in enumerate(vals, 1):
                cell(at, r, ci, v, BOLD if ci == 3 and a["pk"] else BODY, LIGHT if a["derived"] else None,
                     CENTER if ci in (4, 7, 8) else WRAP)
            r += 1
at.freeze_panes = "D5"; at.auto_filter.ref = f"A4:K{r-1}"

rs = wb.create_sheet("Relationships")
title(rs, "Relationships", "Child entity carries the foreign key; cardinality is child-to-parent (M:1 = many children per parent).")
header(rs, 4, ["Product ID", "Child Entity", "Parent Entity", "Foreign Key", "Cardinality", "Optional", "Note"], [11, 30, 30, 36, 11, 9, 60])
r = 5
for pid in order:
    for x in models[pid]["relationships"]:
        for ci, v in enumerate([pid, x["child"], x["parent"], ", ".join(x["fk"]), x["card"], "Y" if x["optional"] else "", x["note"]], 1):
            cell(rs, r, ci, v, BOLD if ci in (2, 3) else BODY, None, CENTER if ci in (5, 6) else WRAP)
        r += 1
rs.freeze_panes = "B5"; rs.auto_filter.ref = f"A4:G{r-1}"

kr = wb.create_sheet("Key Registry")
title(kr, "Key Registry", "Primary key of each taxonomy object, shared by every model. Attribute Groups either fold into their parent or "
      "become child entities keyed by the parent key plus the discriminator shown.")
header(kr, 4, ["Data Domain", "Data Business Object", "Kind", "Parent", "Grain", "Treatment", "Primary Key / Discriminator",
               "Key Type", "Note"], [30, 32, 15, 26, 40, 14, 40, 11, 50])
r = 5
for k in sorted(KEYS):
    v, o = KEYS[k], objs[k]
    treat = "Entity" if o["kind"] != "Attribute Group" else ("Folds into parent" if v.get("fold") else "Child entity")
    for ci, val in enumerate([dd(k[0]), k[1], o["kind"], o.get("parent", ""), o["grain"], treat, ", ".join(v.get("pk", [])),
                              v.get("key_type", ""), v.get("note", "")], 1):
        cell(kr, r, ci, val, BOLD if ci == 2 else BODY, None, WRAP)
    r += 1
kr.freeze_panes = "C5"; kr.auto_filter.ref = f"A4:I{r-1}"

rl = wb.create_sheet("Reference Links")
title(rl, "Reference Links", "The object each reference attribute points to. These are the candidate foreign keys of every model.")
header(rl, 4, ["Data Domain", "Data Business Object", "Reference Attribute", "Declared Type", "Target Domain", "Target Object"],
       [30, 32, 32, 26, 30, 32])
r = 5
for (n, on, a), t in sorted(REFS.items()):
    for ci, val in enumerate([dd(n), on, a, objs[(n, on)]["attrs"][a]["type"], dd(t[0]), t[1]], 1):
        cell(rl, r, ci, val, BOLD if ci in (3, 6) else BODY)
    r += 1
rl.freeze_panes = "D5"; rl.auto_filter.ref = f"A4:F{r-1}"

for ws in wb.worksheets:
    ws.sheet_view.showGridLines = False
out = os.path.join(ROOT, "00_Program", "Data_Product_Logical_Models.xlsx")
wb.save(out)
print("saved", out, "|", len(order), "models |", len(held), "pending WP0 re-scope (not built) |", n_ent, "entities |", n_rel, "relationships |", len(KEYS), "keys |",
      len(REFS), "reference links |", len(warns), "warning(s)")
