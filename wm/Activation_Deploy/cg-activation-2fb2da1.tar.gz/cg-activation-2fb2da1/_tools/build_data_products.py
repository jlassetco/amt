"""Builds 00_Program/Data_Product_Catalog.xlsx from data_products/ (framework.py + specs_*.py), validated against the
consolidated taxonomy. Lineage counts are snapshots taken at build time.
Usage: python build_data_products.py [--draft]   (--draft builds only the products specified so far)
"""
import os, sys
from collections import Counter, defaultdict
from openpyxl import Workbook
from openpyxl.styles import Alignment
from openpyxl.utils import get_column_letter

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "data_products"))
from domains import DD_NAMES as ALL_DOMAINS  # noqa: E402
sys.path.insert(0, os.path.join(HERE, "capability_map"))
import areas as ar  # noqa: E402
import content_capabilities as cc  # noqa: E402
from taxonomy_builder import ROOT, DD_NAMES, header, cell, title, BODY, BOLD, MID, LIGHT, WHITE, CENTER, WRAP  # noqa: E402
import dp_model  # noqa: E402
import framework as fw  # noqa: E402

objs = dp_model.load_taxonomy()
specs, _, errs = dp_model.load_specs()
DRAFT = "--draft" in sys.argv
e, warns = dp_model.validate(specs, objs, partial=DRAFT)
errs += e
if errs:
    raise SystemExit("Data product validation failed:\n  " + "\n  ".join(errs))
for w in warns:
    print("WARN", w)

dd = lambda n: f"{n} {DD_NAMES[n]}"
FN = {f[0]: f for f in fw.FUNCTIONS}
CAP = {c["id"]: c for l1 in cc.CAPABILITIES for c in l1["l2"]}
area_of = lambda n: ar.AREA_NAMES[ar.DOMAIN_AREA[n]]          # a product's area is its owning Data Domain's home area
fn_label = lambda c: f"{c} {FN[c][1]}"
# In-progress products (register entry, no spec yet) are left out; products pending WP0 re-scope (CW-041) keep only a
# status row on the Product Catalog tab and are left out of every count, lineage link and coverage figure.
# Retired products (framework.RETIRED_PRODUCTS, WP0) keep only a "Retired (CW-nnn)" status row and are left out of every
# count; a product both pending and retired counts as retired. Retired functions (framework.RETIRED_FUNCTIONS) are listed
# after the live ones on the Functions tab, greyed with their successor, and left out of the Function Matrix.
P = [p for p in fw.PRODUCTS if p[0] in specs and not dp_model.is_pending(p[0]) and not dp_model.is_retired(p[0])]
is_bl = getattr(fw, "is_backlog", lambda pid: False)
in_progress = [p for p in fw.PRODUCTS if p[0] not in specs and not dp_model.is_pending(p[0]) and not dp_model.is_retired(p[0])
               and not is_bl(p[0])]
# WP1 backlog (framework.WAVE_BACKLOG, WP1_Scope.md): registered consumer candidates not specified at WP1; a status row
# each on the Product Catalog tab, left out of every count, like the in-progress products.
wp1_backlog = [p for p in fw.PRODUCTS if is_bl(p[0]) and not dp_model.is_retired(p[0])]
pending = [p for p in fw.PRODUCTS if dp_model.is_pending(p[0]) and not dp_model.is_retired(p[0])]
retired = [p for p in fw.PRODUCTS if dp_model.is_retired(p[0])]
LIVE_FNS = dp_model.live_functions()
by_id = {p[0]: p for p in fw.PRODUCTS}

# Lineage rows and per-product stats
lineage, stats = [], {}
used_objs, used_attrs = set(), set()
for p in P:
    s = specs[p[0]]
    n_attr = n_cde = 0
    doms = set()
    for n, on, an in s["inputs"]:
        o = objs[(n, on)]
        used_objs.add((n, on)); doms.add(n)
        for a in an:
            x = o["attrs"][a]
            used_attrs.add((n, on, a))
            n_attr += 1; n_cde += x["cde"]
            lineage.append([p[0], p[1], dd(n), o["family"], o["code"], on, o["grain"], x["id"], a, x["def"],
                            "Y" if x["cde"] else "", "Y" if x["pii"] else "", x["flag"], dd(x["owner"] or n)])
    stats[p[0]] = (len(s["inputs"]), n_attr, n_cde, sorted(doms))
downstream = defaultdict(list)
for p in P:
    for u in specs[p[0]]["upstream"]:
        downstream[u].append(p[0])

wb = Workbook()
SUB = (f"Wealth manager (direct, with its own funds) | US | {fw.VERSION} | {fw.AS_OF} | Built from _tools/data_products/ "
       "and validated against the consolidated taxonomy (v0.3).")

# ---- Overview -------------------------------------------------------------------------------------------------------
ov = wb.active; ov.title = "Overview"
title(ov, "Data Product Catalog", SUB)
header(ov, 4, ["Topic", "Description"], [30, 120])
n_spec, n_bl = len(P), len(fw.BACKLOG)
wave = lambda pid: fw.WAVE.get(pid, "Wave 1")
n_w = Counter(wave(p[0]) for p in P)
tiers = Counter(p[2] for p in P); types = Counter(p[3] for p in P)
rows = [
    ("Purpose", f"Defines the data products of the reference model, drawn from the {len(DD_NAMES) - 2} live Data Domains of "
     "the enterprise data taxonomy of a US wealth manager that serves investors directly and manufactures its own funds. "
     "Each product serves named business functions, has an accountable owner, and is traced to the exact L3 Data Business "
     "Objects and L4 Data Business Attributes it uses."),
    ("What a data product is", "A governed, reusable data asset with a defined grain, owner, service levels and quality "
     "rules, built for consumers rather than for a source system. Data products sit on top of the taxonomy: the taxonomy "
     "defines what each concept means and which Data Domain masters it; a data product assembles those concepts to answer "
     "a function's questions. A product never remasters a concept."),
    ("Scope", f"{n_spec} live products with attribute-level specifications, serving {len(LIVE_FNS)} live business "
     f"functions ({len(fw.FUNCTIONS) - len(LIVE_FNS)} retired at WP0 are listed for traceability): "
     + ", ".join(f"{v} in {k}" for k, v in sorted(n_w.items()))
     + ". " + (f"{len(pending)} wholesale consumer products are pending WP0 re-scope and " if pending else "")
     + f"{len(retired)} products are retired (status rows only)" + (f"; {len(wp1_backlog)} consumer candidates are in the WP1 backlog (registered, not specified at WP1; "
                "status rows only)" if wp1_backlog else "") + (f", plus {n_bl} identified backlog products (named and defined, to be specified later)." if n_bl else ".")),
    ("Tiers", " | ".join(f"{k} ({tiers[k]}): {v}" for k, v in fw.TIERS.items())),
    ("Product types", " | ".join(f"{k} ({types[k]}): {v}" for k, v in fw.TYPES.items())),
    ("Ownership", "Each product has an owning Data Domain (usually the domain that masters its core facts) and an accountable "
     "product owner role. The owner is responsible for the product's definition, quality, service levels and access; "
     "input concepts stay owned by their mastering Data Domains."),
    ("Lineage", f"{len(lineage)} product-to-attribute lineage links across {len(used_objs)} of {len(objs)} L3 objects "
     f"({len(used_attrs)} distinct L4 attributes). Every link is validated against the consolidated taxonomy at build time, "
     "so a renamed or removed attribute breaks the build rather than leaving stale lineage."),
    ("Tabs", "Functions: the business functions and the products that serve them | Product Catalog: one row per product, "
     "with wave, priority and rationale | Function Matrix: primary (P) and supporting (S) use | Questions | Measures | Lineage: every "
     "input attribute | Domain Matrix: attributes drawn from each Data Domain | Dependencies | DQ Rules | " + ("Backlog | " if n_bl else "") + "Coverage: "
     "use of each Data Domain's objects and CDEs."),
    ("How to change", "Edit _tools/data_products/framework.py (register, functions, backlog) or specs_*.py (specifications), "
     "then run python build_data_products.py. See _tools/data_products/CONTRACT.md for the specification standard."),
    ("Status and next steps", "Desk draft. 1) Confirm functions, products and owners with the function heads and the "
     "Data Office. 2) Validate each specification with its product owner and primary-function consumers. 3) Map inputs to "
     "source systems (Phase D). 4) Agree service levels and certification criteria. 5) Sequence delivery: foundational products first, then Waves 1-3 by priority. "
     "See 00_Program/Data_Products_Approach.md."),
]
for i, (k, v) in enumerate(rows, 5):
    cell(ov, i, 1, k, BOLD); cell(ov, i, 2, v)

# ---- Functions ------------------------------------------------------------------------------------------------------
fs = wb.create_sheet("Functions")
title(fs, "Business Functions", "The business functions of the wealth manager by area (retired functions last, in grey), the capabilities each runs (Business_Capability_Map.xlsx) and the data products that serve each one.")
header(fs, 4, ["Code", "Function", "Area", "Capabilities Run", "Description", "Typical Roles", "Key Decisions", "Primary Products",
               "Supporting Products", "# Products"], [9, 30, 20, 40, 50, 36, 50, 40, 40, 10])
RFN = dp_model.RETIRED_FNS
for i, f in enumerate(LIVE_FNS + [f for f in fw.FUNCTIONS if f[0] in RFN], 5):
    prim = [p[0] for p in P if p[6] == f[0]]
    sup = [p[0] for p in P if f[0] in p[7]]
    caps = "; ".join(f"{c} {CAP[c]['name']}" for c in f[3])
    desc = f[4] if f[0] not in RFN else (f"Retired ({RFN[f[0]]}); successor {fw.FUNCTION_SUCCESSOR.get(f[0]) or 'none'}. " + f[4])
    for ci, v in enumerate([f[0], f[1], ar.AREA_NAMES[f[2]], caps, desc, f[5], f[6], ", ".join(prim), ", ".join(sup),
                            len(prim) + len(sup)], 1):
        cell(fs, i, ci, v, BOLD if ci == 2 else BODY, LIGHT if f[0] in RFN else None, CENTER if ci == 10 else WRAP)
fs.freeze_panes = "C5"

# ---- Product Catalog --------------------------------------------------------------------------------------------------
pc = wb.create_sheet("Product Catalog")
title(pc, "Product Catalog", "Every data product, with its wave" + (f", then the {len(pending)} products pending WP0 re-scope (status row only)" if pending else "")
      + (f", then the {len(retired)} retired products (status row only)" if retired else "")
      + (f", then the {len(wp1_backlog)} WP1 backlog products (status row only)" if wp1_backlog else "")
      + (", then the identified backlog" if n_bl else "") + ". Counts are build-time snapshots.")
H = ["Product ID", "Data Product", "Status", "Tier", "Type", "Owning Data Domain", "Area", "Topic", "Product Owner", "Primary Function",
     "Supporting Functions", "Definition", "Grain (one row =)", "Refresh", "Timeliness", "History", "Classification", "PII",
     "Delivery", "Upstream Products", "Downstream Products", "# Input Objects", "# Input Attributes", "# CDEs Used",
     "Data Domains Drawn On", "Priority (Waves 2-3)", "Rationale (Waves 2-3)", "Notes"]
header(pc, 4, H, [11, 32, 11, 16, 18, 28, 20, 28, 30, 30, 36, 60, 40, 11, 30, 30, 22, 6, 28, 22, 22, 9, 9, 9, 26, 10, 44, 50])
TOPIC = {t[0]: t[1] for t in fw.TOPICS}
r = 5
for p in P:
    s = specs[p[0]]
    no, na, nc, doms = stats[p[0]]
    pri, why, dep = fw.RATIONALE.get(p[0], ("", "", ""))
    vals = [p[0], p[1], wave(p[0]), p[2], p[3], dd(p[4]), area_of(p[4]), TOPIC[fw.topic_of(p)], p[5], fn_label(p[6]), "; ".join(fn_label(x) for x in p[7]),
            s["definition"], s["grain"], s["refresh"], s["timeliness"], s["history"], s["classification"], s["pii"],
            ", ".join(s["delivery"]), ", ".join(s["upstream"]), ", ".join(downstream[p[0]]), no, na, nc, ", ".join(doms),
            pri, why, s.get("notes", "")]
    for ci, v in enumerate(vals, 1):
        cell(pc, r, ci, v, BOLD if ci == 2 else BODY, None if p[2] == "Foundational" else WHITE,
             CENTER if ci in (3, 14, 18, 22, 23, 24, 26) else WRAP)
    r += 1
for p in pending:                                   # pending WP0 re-scope (CW-041): register row and decision only
    vals = [p[0], p[1], "Pending re-scope (WP0)", p[2], p[3], dd(p[4]), area_of(p[4]), TOPIC[fw.topic_of(p)], p[5], fn_label(p[6]),
            "; ".join(fn_label(x) for x in p[7]), "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",
            f"Pending WP0 re-scope ({fw.RESCOPE_PENDING[p[0]]}): the wholesale {wave(p[0])} consumer product is re-scoped or "
            "retired at WP0; its specification is kept but not validated or built."]
    for ci, v in enumerate(vals, 1):
        cell(pc, r, ci, v, BOLD if ci == 2 else BODY, LIGHT, CENTER if ci in (3,) else WRAP)
    r += 1
for p in retired:                                   # retired at WP0: register row and retiring decision only
    vals = [p[0], p[1], f"Retired ({dp_model.RETIRED[p[0]]})", p[2], p[3], dd(p[4]), area_of(p[4]) if p[4] in ar.DOMAIN_AREA else "",
            TOPIC.get(fw.topic_of(p), ""), p[5], fn_label(p[6]), "; ".join(fn_label(x) for x in p[7]),
            "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",
            f"Retired at WP0 ({dp_model.RETIRED[p[0]]}); the id is never reused. Not built or counted; live products that "
            "still read it are re-pointed at the WP1 integration."]
    for ci, v in enumerate(vals, 1):
        cell(pc, r, ci, v, BOLD if ci == 2 else BODY, LIGHT, CENTER if ci in (3,) else WRAP)
    r += 1
for p in wp1_backlog:                               # WP1 backlog: register row and merge target only
    t = fw.WAVE_BACKLOG_MERGES.get(p[0])
    vals = [p[0], p[1], "Backlog (WP1)", p[2], p[3], dd(p[4]), area_of(p[4]), TOPIC.get(fw.topic_of(p), ""), p[5], fn_label(p[6]),
            "; ".join(fn_label(x) for x in p[7]), "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",
            "WP1 backlog (WP1_Scope.md): registered, not specified at WP1"
            + (f"; overlaps {t}, into which its scope folds if it is picked up." if t else "; stands alone.")]
    for ci, v in enumerate(vals, 1):
        cell(pc, r, ci, v, BOLD if ci == 2 else BODY, LIGHT, CENTER if ci in (3,) else WRAP)
    r += 1
for b in fw.BACKLOG:
    vals = [b[0], b[1], "Identified", b[2], b[3], dd(b[4]), area_of(b[4]), TOPIC.get(fw.TOPIC_OF_DOMAIN.get(b[4], ""), ""), "", fn_label(b[5]), "; ".join(fn_label(x) for x in b[6]),
            b[7], "", "", "", "", "", "", "", "", "", "", "", "", ", ".join(b[8]), b[10], b[9], b[11]]
    for ci, v in enumerate(vals, 1):
        cell(pc, r, ci, v, BOLD if ci == 2 else BODY, LIGHT, CENTER if ci in (3,) else WRAP)
    r += 1
pc.freeze_panes = "C5"; pc.auto_filter.ref = f"A4:{get_column_letter(len(H))}{r-1}"

# ---- Function Matrix --------------------------------------------------------------------------------------------------
fm = wb.create_sheet("Function Matrix")
title(fm, "Function x Product Matrix", "P = primary function the product is designed for; S = supporting function that also consumes it." + (" Backlog products in grey." if n_bl else ""))
allp = [(p[0], p[1], p[6], p[7], False) for p in P] + [(b[0], b[1], b[5], b[6], True) for b in fw.BACKLOG]
header(fm, 4, ["Product ID", "Data Product"] + [f[0] for f in LIVE_FNS], [11, 34] + [7] * len(LIVE_FNS))
for ci, f in enumerate(LIVE_FNS, 3):
    fm.cell(row=3, column=ci, value=f[1]).alignment = Alignment(text_rotation=90, vertical="bottom", horizontal="center")
    fm.cell(row=3, column=ci).font = BODY
fm.row_dimensions[3].height = 190
for i, (pid, name, prim, sup, bl) in enumerate(allp, 5):
    fill = LIGHT if bl else None
    cell(fm, i, 1, pid, BODY, fill); cell(fm, i, 2, name, BOLD, fill)
    for ci, f in enumerate(LIVE_FNS, 3):
        v = "P" if f[0] == prim else ("S" if f[0] in sup else "")
        cell(fm, i, ci, v, BOLD if v == "P" else BODY, MID if v == "P" else fill, CENTER)
fm.freeze_panes = "C5"

# ---- Questions, Measures ------------------------------------------------------------------------------------------------
qs = wb.create_sheet("Questions")
title(qs, "Business Questions", "The questions each specified product is designed to answer, by its primary function.")
header(qs, 4, ["Product ID", "Data Product", "Primary Function", "#", "Business Question"], [11, 34, 32, 5, 100])
r = 5
for p in P:
    for k, q in enumerate(specs[p[0]]["business_questions"], 1):
        for ci, v in enumerate([p[0], p[1], fn_label(p[6]), k, q], 1):
            cell(qs, r, ci, v, BOLD if ci == 2 else BODY, None, CENTER if ci == 4 else WRAP)
        r += 1
qs.freeze_panes = "C5"; qs.auto_filter.ref = f"A4:E{r-1}"

ms = wb.create_sheet("Measures")
title(ms, "Measures, Dimensions and Grain", "Derived measures, scores and flags each product publishes, with their formula or rule and the taxonomy attributes (from the product's inputs) and other measures each one reads.")
header(ms, 4, ["Product ID", "Data Product", "Measure", "Definition / Formula", "Reads (taxonomy attributes and other measures)",
               "Product Grain", "Dimensions"], [11, 32, 30, 70, 60, 40, 50])
r = 5
for p in P:
    s = specs[p[0]]
    for mname, mdef, uses in s["measures"]:
        reads = "; ".join(f"[measure] {u}" if isinstance(u, str) else f"{u[0]} {u[1]} / {u[2]}" for u in uses)
        for ci, v in enumerate([p[0], p[1], mname, mdef, reads, s["grain"], "; ".join(s["dimensions"])], 1):
            cell(ms, r, ci, v, BOLD if ci == 3 else BODY)
        r += 1
ms.freeze_panes = "C5"; ms.auto_filter.ref = f"A4:G{r-1}"

# ---- Lineage ------------------------------------------------------------------------------------------------------------
ln = wb.create_sheet("Lineage")
title(ln, "Product Lineage (Input Attributes)", "Every L4 Data Business Attribute each product draws on, with its L3 object, CDE and PII flags and mastering Data Domain.")
header(ln, 4, ["Product ID", "Data Product", "Data Domain", "Data Family", "Object Code", "Data Business Object (L3)",
               "Object Grain", "Attribute ID", "Data Business Attribute (L4)", "Attribute Definition", "CDE", "PII",
               "Ownership", "Mastered In"], [11, 30, 30, 26, 12, 30, 34, 12, 30, 60, 6, 6, 14, 30])
for i, row in enumerate(lineage, 5):
    fill = None if by_id[row[0]][2] == "Foundational" else WHITE
    for ci, v in enumerate(row, 1):
        cell(ln, i, ci, v, BOLD if ci == 9 else BODY, fill, CENTER if ci in (11, 12) else WRAP)
ln.freeze_panes = "C5"; ln.auto_filter.ref = f"A4:N{4+len(lineage)}"

# ---- Domain Matrix ------------------------------------------------------------------------------------------------------
dm = wb.create_sheet("Domain Matrix")
title(dm, "Product x Data Domain Matrix", "Number of L4 attributes each product draws from each Data Domain (by the object's domain). Shaded = owning Data Domain.")
cnt = Counter((row[0], row[2][:2]) for row in lineage)
codes = [n for n in ALL_DOMAINS if any(cnt.get((p[0], n)) for p in P)]      # every Data Domain some product draws on
header(dm, 4, ["Product ID", "Data Product", "Owner"] + codes + ["Total"], [11, 34, 8] + [6] * len(codes) + [8])
for ci, n in enumerate(codes, 4):
    dm.cell(row=3, column=ci, value=DD_NAMES[n]).alignment = Alignment(text_rotation=90, vertical="bottom", horizontal="center")
    dm.cell(row=3, column=ci).font = BODY
dm.row_dimensions[3].height = 200
for i, p in enumerate(P, 5):
    cell(dm, i, 1, p[0]); cell(dm, i, 2, p[1], BOLD); cell(dm, i, 3, p[4], BODY, None, CENTER)
    for ci, n in enumerate(codes, 4):
        v = cnt.get((p[0], n), 0)
        cell(dm, i, ci, v or "", BOLD if n == p[4] else BODY, MID if n == p[4] else None, CENTER)
    cell(dm, i, 4 + len(codes), stats[p[0]][1], BOLD, None, CENTER)
tr = 5 + len(P)
cell(dm, tr, 2, "Products drawing on domain", BOLD, MID)
for ci, n in enumerate(codes, 4):
    cell(dm, tr, ci, sum(1 for p in P if cnt.get((p[0], n))), BOLD, MID, CENTER)
dm.freeze_panes = "D5"

# ---- Dependencies -------------------------------------------------------------------------------------------------------
dp = wb.create_sheet("Dependencies")
title(dp, "Product Dependencies", "Which products each product is built from. Consumer-aligned products build on foundational products; there are no cycles.")
header(dp, 4, ["Product ID", "Data Product", "Tier", "Depends On (ID)", "Depends On (Product)", "Upstream Tier"], [11, 34, 16, 14, 36, 16])
r = 5
for p in P:
    for u in specs[p[0]]["upstream"]:
        for ci, v in enumerate([p[0], p[1], p[2], u, by_id[u][1], by_id[u][2]], 1):
            cell(dp, r, ci, v, BOLD if ci in (2, 5) else BODY)
        r += 1
dp.freeze_panes = "C5"; dp.auto_filter.ref = f"A4:F{r-1}"

# ---- DQ Rules ------------------------------------------------------------------------------------------------------------
dq = wb.create_sheet("DQ Rules")
title(dq, "Data Quality Rules", "Testable rules each product's owner certifies before publishing. Starting point for the DQ rule backlog.")
header(dq, 4, ["Rule ID", "Product ID", "Data Product", "Rule", "Refresh", "Classification"], [16, 11, 32, 90, 12, 24])
r = 5
for p in P:
    s = specs[p[0]]
    for k, rule in enumerate(s["dq_rules"], 1):
        for ci, v in enumerate([f"DQ-{p[0][3:]}-{k:02d}", p[0], p[1], rule, s["refresh"], s["classification"]], 1):
            cell(dq, r, ci, v, BODY)
        r += 1
dq.freeze_panes = "D5"; dq.auto_filter.ref = f"A4:F{r-1}"

# ---- Backlog (only while identified products remain) ------------------------------------------------------------------
if n_bl:
    bl = wb.create_sheet("Backlog")
    title(bl, "Data Product Backlog", "Identified products: named and defined, to be specified at attribute level in a later pass.")
    header(bl, 4, ["Product ID", "Data Product", "Tier", "Type", "Owning Data Domain", "Primary Function", "Supporting Functions",
                   "Definition", "Main Input Data Domains", "Value / Rationale", "Priority", "Dependency / Taxonomy Gap"],
           [11, 32, 16, 18, 28, 30, 36, 60, 30, 44, 9, 44])
    for i, b in enumerate(fw.BACKLOG, 5):
        vals = [b[0], b[1], b[2], b[3], dd(b[4]), fn_label(b[5]), "; ".join(fn_label(x) for x in b[6]), b[7],
                ", ".join(dd(x) for x in b[8]), b[9], b[10], b[11]]
        for ci, v in enumerate(vals, 1):
            cell(bl, i, ci, v, BOLD if ci == 2 else BODY, MID if b[10] == "High" and ci == 11 else None, CENTER if ci == 11 else WRAP)
    bl.freeze_panes = "C5"; bl.auto_filter.ref = f"A4:L{4+len(fw.BACKLOG)}"

# ---- Coverage ----------------------------------------------------------------------------------------------------------
cv = wb.create_sheet("Coverage")
title(cv, "Taxonomy Coverage", "How much of each of the 44 Data Domains the specified products use. Objects with CDEs that no product uses are listed below "
      "the summary: each is either a gap in the product set or a candidate for removal from the taxonomy. Data Domains 17-44 gain their products in the "
      "data products expansion (Data_Products_Expansion_Plan.md).")
header(cv, 4, ["Data Domain", "Area", "L3 Objects", "Objects Used", "% Objects", "CDE Attributes", "CDEs Used", "% CDEs", "# Products",
               "# Products Owned"], [40, 20, 11, 11, 10, 13, 11, 10, 11, 11])
r = 5
for n in ALL_DOMAINS:
    o_all = [k for k in objs if k[0] == n]
    cde_all = [(k[0], k[1], a) for k in o_all for a, x in objs[k]["attrs"].items() if x["cde"]]
    ou = sum(1 for k in o_all if k in used_objs); cu = sum(1 for c in cde_all if c in used_attrs)
    np_ = sum(1 for p in P if cnt.get((p[0], n)))
    owned = sum(1 for p in P if p[4] == n)
    for ci, v in enumerate([dd(n), area_of(n), len(o_all), ou, ou / len(o_all) if o_all else 0, len(cde_all), cu, cu / len(cde_all) if cde_all else 0,
                            np_, owned], 1):
        x = cell(cv, r, ci, v, BOLD if ci == 1 else BODY, None, WRAP if ci <= 2 else CENTER)
        if ci in (5, 8): x.number_format = "0%"
    r += 1
r += 2
cv.cell(row=r, column=1, value="Objects with CDEs not used by any specified product").font = BOLD
r += 1
header(cv, r, ["Data Domain", "Data Family", "Data Business Object (L3)", "Grain", "# CDEs", "Kind", "", "", "", ""], [40, 20, 11, 11, 10, 13, 11, 10, 11, 11])
for c, w in zip("ABCD", [40, 28, 34, 40]):
    cv.column_dimensions[c].width = w
r += 1
for k, o in objs.items():
    nc = sum(1 for x in o["attrs"].values() if x["cde"])
    if k not in used_objs and nc:
        for ci, v in enumerate([dd(k[0]), o["family"], o["name"], o["grain"], nc, o["kind"]], 1):
            cell(cv, r, ci, v, BOLD if ci == 3 else BODY, None, CENTER if ci == 5 else WRAP)
        r += 1

for ws in wb.worksheets:
    ws.sheet_view.showGridLines = False
out = os.path.join(ROOT, "00_Program", "Data_Product_Catalog.xlsx")
wb.save(out)
print("saved", out, "|", len(P), "specified +", len(in_progress), "in progress +", len(pending), "pending WP0 re-scope +", len(retired), "retired +", len(wp1_backlog), "WP1 backlog +", len(fw.BACKLOG), "identified backlog products |", len(lineage), "lineage links |",
      len(used_objs), "of", len(objs), "objects used |", len(warns), "warning(s)")
