"""Builds 00_Program/Enterprise_Data_Taxonomy.xlsx - the consolidated view of all Data Domains (renamed from
Enterprise_Distribution_Data_Taxonomy.xlsx under CD-150). On the wealth-manager branch the Data Domains sheet carries each
domain's area (capability_map/areas.py) and its wealth disposition (domains.DISPOSITION: keep, adapt, replace or new).

Hierarchy: L1 Data Domain > L2 Data Family > L3 Data Business Object > L4 Data Business Attribute.
Inputs: content/ + consolidation/ (shared lists, decisions) + enrichment/ (grain, ownership, summaries)
Usage:  python build_enterprise.py
"""
import importlib, os, re, sys
from openpyxl import Workbook
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter
from taxonomy_builder import (CONTENT, CONSOLIDATION, ROOT, Consolidated, load_consolidation, validate, model, dd_label, DD_NAMES, header,
                              cell, title, BODY, BOLD, MID, LIGHT, CENTER, WRAP, FONT, NAVY)

sys.dont_write_bytecode = True
scl = load_consolidation()
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "capability_map"))
try:   # area register (read only; owned by the capability map)
    _areas = importlib.import_module("areas")
    AREA_OF = {n: _areas.AREA_NAMES[a] for n, a in _areas.DOMAIN_AREA.items()}
except (ModuleNotFoundError, AttributeError):
    AREA_OF = {}
from domains import DISPOSITION  # noqa: E402
sys.path.insert(0, CONSOLIDATION)
dec = importlib.import_module("decisions")
raw = [importlib.import_module(f[:-3]) for f in sorted(os.listdir(CONTENT)) if f.startswith("content_") and f.endswith(".py")]
mods = [Consolidated(m, scl) for m in raw]
for m in mods:
    errs = validate(m)
    assert not errs, (m.__name__, errs)
MODEL = {m.__name__.split("_")[1]: model(m) for m in mods}
bd_name = dd_label

wb = Workbook()
ov = wb.active; ov.title = "Overview"
sheets = {n: wb.create_sheet(n) for n in ["Data Domains", "Enterprise Hierarchy", "Enterprise Attributes", "Reference Flows",
          "Shared Code Lists", "Code List Crosswalk", "List Renames", "Core Entity Ownership", "ID Prefix Register",
          "Decision Log", "Term Conflicts", "Cross-Domain Relationships"]}

# ---- Enterprise Attributes (L4)
ea = sheets["Enterprise Attributes"]
header(ea, 1, ["Data Domain (L1)", "Attribute ID", "Data Family (L2)", "Data Business Object (L3)", "Data Business Attribute (L4)",
               "Definition", "Ownership", "Mastered In", "Applies To", "Data Type", "Code List / Format", "Code List Status",
               "Example", "Primary Reference", "Secondary Reference", "CDE", "Object Group", "Notes", "Row Ownership Rule"],
       [26, 14, 24, 26, 30, 55, 14, 26, 16, 18, 26, 14, 26, 22, 20, 6, 24, 28, 40])
r = 2
for mi, m in enumerate(mods):
    bd = m.__name__.split("_")[1]; fill = None if mi % 2 == 0 else LIGHT
    for f in MODEL[bd]:
        for o in f["objects"]:
            for x in o["attrs"]:
                a = x["a"]; cl = a[4]
                status = "Shared" if cl.startswith("Shared: ") else ("Local" if cl in m.CL else ("External / format" if cl else ""))
                vals = [bd_name(bd), x["id"], f["name"], o["name"], a[0], a[1], x["flag"], bd_name(x["owner"] or bd), a[2], a[3], cl,
                        status, a[5], a[6], a[7], a[8], o["group"], a[9] if len(a) > 9 else "", x["row_rule"]]
                for ci, v in enumerate(vals, 1):
                    cell(ea, r, ci, v, BOLD if ci == 5 else BODY, fill)
                r += 1
ea_last = r - 1
ea.freeze_panes = "F2"; ea.auto_filter.ref = f"A1:S{ea_last}"
rng = lambda col: f"'Enterprise Attributes'!${col}$2:${col}${ea_last}"

# ---- Data Domains (L1)
bs = sheets["Data Domains"]
title(bs, "Data Domains (L1)", "What each Data Domain masters and references. Counts are live formulas over the Enterprise Attributes tab. "
      "Area view: filter 'Area' (eight areas, Foundations as a band); 'Wealth Disposition' says whether the domain was kept, adapted, "
      "replaced or added in the wealth-manager rework (Wealth_Manager_Rework_Plan.md section 5).")
header(bs, 4, ["Data Domain", "Masters", "References", "Workbook", "Families (L2)", "Objects (L3)", "Attributes (L4)", "CDEs",
               "Shared-list attrs", "References out", "Derived copies", "Local code lists", "Area", "Wealth Disposition"],
       [30, 60, 60, 40, 9, 9, 10, 8, 10, 10, 10, 10, 22, 12])
r = 5
for m in mods:
    bd = m.__name__.split("_")[1]; S = getattr(m.enr, "SUMMARY", {}) if m.enr else {}
    vals = [bd_name(bd), S.get("masters", ""), S.get("references", ""), m.META["output"], len(MODEL[bd]),
            sum(len(f["objects"]) for f in MODEL[bd]),
            f'=COUNTIF({rng("A")},A{r})', f'=COUNTIFS({rng("A")},A{r},{rng("P")},"Y")',
            f'=COUNTIFS({rng("A")},A{r},{rng("L")},"Shared")', f'=COUNTIFS({rng("A")},A{r},{rng("G")},"Reference")',
            f'=COUNTIFS({rng("A")},A{r},{rng("G")},"Derived copy")', sum(1 for k in m.CL if not k.startswith("Shared: ")),
            AREA_OF.get(bd, ""), DISPOSITION.get(bd, ("", ""))[0].capitalize()]
    for ci, v in enumerate(vals, 1):
        cell(bs, r, ci, v, BOLD if ci == 1 else BODY, None, CENTER if ci > 4 and ci != 13 else WRAP)
    r += 1
bs.auto_filter.ref = f"A4:N{r-1}"
for ci in range(1, 5):
    cell(bs, r, ci, "Total" if ci == 1 else "", BOLD, MID)
for ci in range(5, 13):
    col = get_column_letter(ci)
    cell(bs, r, ci, f"=SUM({col}5:{col}{r-1})", BOLD, MID, CENTER)
bs_total = r
bs.freeze_panes = "B5"

# ---- Enterprise Hierarchy (L1-L3)
eh = sheets["Enterprise Hierarchy"]
title(eh, "Enterprise Hierarchy", "L1 Data Domain > L2 Data Family > L3 Data Business Object, with grain and kind. Counts are live formulas.")
header(eh, 4, ["Data Domain", "Level", "Code", "Data Family", "Data Business Object", "Object Group", "Definition",
               "Grain (one row =)", "Kind", "Parent Object", "# Attributes", "# CDEs", "# References Out"],
       [28, 12, 14, 26, 28, 24, 56, 32, 15, 22, 11, 9, 11])
r = 5
for m in mods:
    bd = m.__name__.split("_")[1]; bdl = bd_name(bd)
    S = getattr(m.enr, "SUMMARY", {}) if m.enr else {}
    for ci, v in enumerate([bdl, "L1 Domain", bd, "", "", "", S.get("masters", ""), "", "", "",
                            f'=COUNTIFS({rng("A")},A{r})', f'=COUNTIFS({rng("A")},A{r},{rng("P")},"Y")',
                            f'=COUNTIFS({rng("A")},A{r},{rng("G")},"<>Mastered here")'], 1):
        cell(eh, r, ci, v, BOLD, MID, CENTER if ci > 10 else WRAP)
    r += 1
    for f in MODEL[bd]:
        crit = lambda extra="": f'=COUNTIFS({rng("A")},A{r},{rng("C")},D{r}{extra})'
        for ci, v in enumerate([bdl, "L2 Family", f["code"], f["name"], "", "", f["def"], "", "", "",
                                crit(), crit(f',{rng("P")},"Y"'), crit(f',{rng("G")},"<>Mastered here"')], 1):
            cell(eh, r, ci, v, BOLD if ci == 4 else BODY, LIGHT, CENTER if ci > 10 else WRAP)
        r += 1
        for o in f["objects"]:
            crit = lambda extra="": f'=COUNTIFS({rng("A")},A{r},{rng("C")},D{r},{rng("D")},E{r}{extra})'
            grp = o["group"] if (o["group_size"] > 1 or o["group"] != o["name"]) else ""
            for ci, v in enumerate([bdl, "L3 Object", o["code"], f["name"], o["name"], grp, o["group_def"], o["grain"], o["kind"],
                                    o["parent"], crit(), crit(f',{rng("P")},"Y"'), crit(f',{rng("G")},"<>Mastered here"')], 1):
                cell(eh, r, ci, v, BODY, None, CENTER if ci > 10 else WRAP)
            r += 1
eh.freeze_panes = "A5"; eh.auto_filter.ref = f"A4:M{r-1}"

# ---- Reference Flows (who references whom)
rf = sheets["Reference Flows"]
title(rf, "Reference Flows", "Rows: the Data Domain holding the attribute. Columns: the Data Domain that masters the concept. Counts "
      "references plus derived copies (live formulas over Enterprise Attributes).")
codes = [m.__name__.split("_")[1] for m in mods]
header(rf, 4, ["Referencing \\ Mastered In"] + [c for c in codes] + ["Total out"], [34] + [7] * len(codes) + [9])
for j, c in enumerate(codes, 2):
    rf.cell(row=3, column=j, value=bd_name(c)).font = Font(name=FONT, size=8, italic=True)
for i, a_ in enumerate(codes, 5):
    cell(rf, i, 1, bd_name(a_), BOLD)
    for j, b_ in enumerate(codes, 2):
        cell(rf, i, j, "" if a_ == b_ else f'=COUNTIFS({rng("A")},$A{i},{rng("H")},"{bd_name(b_)}",{rng("G")},"<>Mastered here")',
             BODY, MID if a_ == b_ else None, CENTER)
    cell(rf, i, len(codes) + 2, f"=SUM(B{i}:{get_column_letter(len(codes) + 1)}{i})", BOLD, None, CENTER)
tr = 5 + len(codes)
cell(rf, tr, 1, "Total in (referenced by others)", BOLD, MID)
for j in range(2, len(codes) + 3):
    col = get_column_letter(j)
    cell(rf, tr, j, f"=SUM({col}5:{col}{tr-1})", BOLD, MID, CENTER)
rf.freeze_panes = "B5"

# ---- Shared Code Lists
sc = sheets["Shared Code Lists"]
title(sc, "Enterprise Shared Code Lists", "Harmonized value sets that replace duplicated local lists. Registered and stewarded via the 09 code list registry (CLR-).")
header(sc, 4, ["Shared List", "Steward", "Definition", "Source / Alignment", "Code", "Label", "Description",
               "Member lists replaced / direct users", "Attrs using (live)"], [30, 10, 44, 30, 28, 30, 44, 44, 11])
r = 5
for li, s in enumerate(scl.SHARED):
    fill = None if li % 2 == 0 else LIGHT; first = r
    members = "; ".join(f"{d}:{l}" for d, l in s["members"])
    if s.get("direct_users"):
        members += ("; " if members else "") + "used directly by " + ", ".join(s["direct_users"])
    for code, label, desc in s["values"]:
        for ci, v in enumerate([s["name"], s["steward"], s["definition"] if r == first else "", s["source"] if r == first else "",
                                code, label, desc, members if r == first else "",
                                f'=COUNTIF({rng("K")},"Shared: "&A{r})' if r == first else ""], 1):
            cell(sc, r, ci, v, BOLD if ci == 1 else BODY, fill, CENTER if ci == 9 else WRAP)
        r += 1
sc.freeze_panes = "A5"; sc.auto_filter.ref = f"A4:I{r-1}"

# ---- Code List Crosswalk
cw = sheets["Code List Crosswalk"]
title(cw, "Code List Crosswalk", "Every value of every replaced local list mapped to its enterprise shared code. Blank shared code = no equivalent (SME review).")
header(cw, 4, ["Data Domain", "Local List", "Local Value", "Shared List", "Shared Code", "Shared Label", "Review"],
       [30, 30, 36, 30, 28, 30, 12])
r = 5
for s in scl.SHARED:
    labels = {c: l for c, l, _ in s["values"]}
    for (d, l, v), code in s["value_map"].items():
        for ci, x in enumerate([bd_name(d), l, v, s["name"], code or "", labels.get(code, ""), "" if code else "Review"], 1):
            cell(cw, r, ci, x)
        r += 1
cw_last = r - 1
cw.freeze_panes = "A5"; cw.auto_filter.ref = f"A4:G{cw_last}"

# ---- List Renames
lr = sheets["List Renames"]
title(lr, "Code List Renames and Lists Kept Separate", "Same name with different meanings is renamed, not merged. Similar lists deliberately kept separate are recorded with the reason.")
header(lr, 4, ["Type", "Data Domain", "Local List", "New Name / Compared With", "Reason"], [16, 30, 32, 40, 70])
r = 5
for d, old, new, why in scl.LOCAL_RENAMES:
    for ci, v in enumerate(["Renamed", bd_name(d), old, new, why], 1):
        cell(lr, r, ci, v)
    r += 1
for d1, l1, d2, l2, why in scl.NOT_MERGED:
    for ci, v in enumerate(["Kept separate", bd_name(d1), l1, f"{bd_name(d2)}: {l2}", why], 1):
        cell(lr, r, ci, v)
    r += 1

# ---- Core Entity Ownership
co = sheets["Core Entity Ownership"]
title(co, "Core Entity Ownership", "Each core entity (a Data Business Object other domains rely on) is mastered in exactly one Data Domain and referenced by enterprise ID from the others.")
header(co, 4, ["Core Entity", "Mastered In", "ID Prefix", "Referenced By", "# Referencing", "Notes"], [32, 34, 12, 60, 12, 60])
for i, (c, owner, pfx, refs, note) in enumerate(dec.CONCEPT_OWNERSHIP, 5):
    for ci, v in enumerate([c, bd_name(owner), pfx, ", ".join(bd_name(x) for x in refs), len(refs), note], 1):
        cell(co, i, ci, v, BOLD if ci == 1 else BODY, None, CENTER if ci == 5 else WRAP)
co.freeze_panes = "A5"; co.auto_filter.ref = f"A4:F{4+len(dec.CONCEPT_OWNERSHIP)}"

# ---- ID Prefix Register
pr = sheets["ID Prefix Register"]
title(pr, "ID Prefix Register", "All entity ID prefixes used across the taxonomies after v0.2 consolidation.")
header(pr, 4, ["Prefix", "Entity", "Mastered In", "Status", "Note"], [12, 40, 34, 14, 60])
for i, (p, ent, owner, status, note) in enumerate(sorted(dec.PREFIXES), 5):
    for ci, v in enumerate([p, ent, bd_name(owner) if owner in DD_NAMES else owner, status, note], 1):
        cell(pr, i, ci, v, BOLD if ci == 1 else BODY)
pr.freeze_panes = "A5"; pr.auto_filter.ref = f"A4:E{4+len(dec.PREFIXES)}"

# ---- Decision Log
dl = sheets["Decision Log"]
title(dl, "Cross-Domain Decision Log", "Overlaps, boundary questions and ownership issues across Data Domains, with proposed resolutions.")
header(dl, 4, ["ID", "Theme", "Title", "Data Domains", "Issue", "Resolution", "Rationale", "Action", "Status", "Priority",
               "Owner Role"], [9, 18, 34, 22, 50, 55, 40, 16, 20, 10, 24])
for i, d in enumerate(dec.DECISIONS, 5):
    vals = [d["id"], d["theme"], d["title"], ", ".join(d["domains"]), d["issue"], d["resolution"], d["rationale"],
            d["action"], d["status"], d["priority"], d["owner_role"]]
    for ci, v in enumerate(vals, 1):
        cell(dl, i, ci, v, BOLD if ci in (1, 3) else BODY)
dl_last = 4 + len(dec.DECISIONS)
dl.freeze_panes = "D5"; dl.auto_filter.ref = f"A4:K{dl_last}"

# ---- Term Conflicts
tc = sheets["Term Conflicts"]
title(tc, "Business Term Conflicts", "Terms used with different meanings across domains, with the recommended enterprise definition, "
      "the glossary resolution (primary sense and how other uses are qualified) and its status (Resolved, or SME where a client choice is needed).")
header(tc, 4, ["Term", "Data Domain", "Local Term / List", "Local Meaning", "Recommendation", "Resolution", "Status"],
       [20, 30, 34, 50, 60, 55, 10])
r = 5
for t in dec.TERM_CONFLICTS:
    first = r
    for d, local, meaning in t["usages"]:
        for ci, v in enumerate([t["term"], bd_name(d) if d in DD_NAMES else d, local, meaning,
                                t["recommendation"] if r == first else "", t.get("resolution", "") if r == first else "",
                                t.get("status", "")], 1):
            cell(tc, r, ci, v, BOLD if ci == 1 else BODY)
        r += 1
tc_last = r - 1
tc.freeze_panes = "A5"; tc.auto_filter.ref = f"A4:G{tc_last}"

# ---- Cross-Domain Relationships
owner_of = {p: o for p, _, o, s, _ in dec.PREFIXES if not str(s).startswith("Retired")}
cr = sheets["Cross-Domain Relationships"]
title(cr, "Relationships (Enterprise View)", "All object relationships from every Data Domain. 'Cross-domain' = the row references an ID prefix mastered in another Data Domain.")
header(cr, 4, ["Data Domain", "From Object", "Relationship", "To Object", "Cardinality", "Notes", "Cross-Domain", "Other Data Domains Referenced"],
       [30, 34, 20, 38, 12, 50, 12, 30])
r = 5
for m in mods:
    bd = m.__name__.split("_")[1]
    for row in m.REL:
        text = " ".join(map(str, row))
        others = sorted({owner_of[p + "-"] for p in re.findall(r"\b([A-Z]{2,5})-", text) if owner_of.get(p + "-") not in (None, bd)})
        for ci, v in enumerate([bd_name(bd), *row, "Y" if others else "", ", ".join(others)], 1):
            cell(cr, r, ci, v, BOLD if ci in (2, 4) else BODY, None, CENTER if ci == 7 else WRAP)
        r += 1
cr.freeze_panes = "A5"; cr.auto_filter.ref = f"A4:H{r-1}"

# ---- Overview
ov.column_dimensions["A"].width = 34; ov.column_dimensions["B"].width = 100; ov.column_dimensions["C"].width = 14
ov["A1"] = "Enterprise Data Taxonomy (Consolidated)"; ov["A1"].font = Font(name=FONT, size=16, bold=True, color=NAVY)
ov["A2"] = (f"Wealth manager (direct, with its own funds) | {len(mods)} Data Domains (client and advice, brokerage and workplace, "
            "investment, fund operations and corporate functions) | Scope: US | W5 consolidation | 2026-10-16")
ov["A2"].font = Font(name=FONT, size=10, italic=True)
rows = [
    ("Purpose", f"Single consolidated view of the {len(mods)} Data Domain taxonomies: one attribute inventory, one hierarchy, shared enterprise code lists, "
                "a core entity ownership register, reference flows between Data Domains, an ID prefix register and a cross-domain decision log. "
                "Data Domain workbooks remain the working documents for each data owner; this workbook is the enterprise integration layer."),
    ("Hierarchy", "L1 Data Domain > L2 Data Family > L3 Data Business Object > L4 Data Business Attribute. 'Object Group' is a label grouping "
                "closely related objects within a family, not a level. Each L3 object states its grain (what one row represents) and its kind: "
                "a Business Object (independently identified record) or an Attribute Group (fields describing a parent object)."),
    ("Ownership rule", "The Data Domain that produces and maintains a concept masters it; every other Data Domain references it by enterprise ID. "
                "Each attribute is flagged 'Mastered here', 'Reference' (to the named Data Domain) or 'Derived copy' (a copied value mastered elsewhere). "
                "Consumption never remasters ownership."),
    ("What consolidation did", "1) Harmonized duplicated code lists into enterprise shared lists with value-level crosswalks (applied in every domain workbook as "
                "'Shared: <name>'). 2) Renamed same-name / different-meaning lists. 3) Resolved ID prefix collisions and moved industry flow benchmarks "
                "from 06 to 11. 4) Logged every cross-domain overlap with a proposed resolution, owner and priority. 5) Registered core entity ownership "
                "and all ID prefixes. 6) Flagged business terms used with different meanings. 7) v0.3: adopted the L1-L4 hierarchy and added grain, "
                "ownership flags and Data Domain summaries."),
    ("How to read", "Data Domains / Enterprise Hierarchy: the shape of the whole taxonomy and what each domain masters and references. Enterprise Attributes: "
                "every attribute, filterable by Data Domain, ownership, CDE and code list status. Reference Flows: which Data Domains rely on which. "
                "Shared Code Lists / Code List Crosswalk / List Renames: the harmonized vocabularies. Core Entity Ownership / ID Prefix Register / "
                "Cross-Domain Relationships: the integration model. Decision Log / Term Conflicts: what still needs a decision."),
    ("Status of decisions", "'Applied in v0.2' / 'Applied in v0.3' = implemented in the domain workbooks; 'Proposed' = resolution recommended, awaiting data-owner sign-off; "
                "'SME decision required' = a business choice for the named owner role."),
    ("Areas and the wholesale sibling", "Areas are a view of this workbook, not separate taxonomies: filter the Data Domains sheet on "
                "'Area'. 'Wealth Disposition' records how each domain came from the wholesale sibling (frozen at wholesale-v1.0): kept, "
                "adapted, replaced (new module under the same number) or new (45-52); 07 and 30 are retired and not shown. The workbook "
                "was named Enterprise_Distribution_Data_Taxonomy.xlsx until Step 5 (CD-150)."),
    ("Row ownership", "Ownership is flagged per attribute. Where one attribute holds rows mastered here and rows copied from or owned by "
                "another Data Domain (for example 39 Contract, whose declared owner 05 stands in for the typed owner of each row), the "
                "'Row Ownership Rule' column of Enterprise Attributes says which rows are which (CD-289)."),
    ("Rebuild", "cd _tools && python taxonomy_builder.py --all && python build_index.py && python build_enterprise.py && python build_explorer.py  "
                "(add --raw to taxonomy_builder.py to build without the consolidation layer; v0.1 modules are archived in _tools/archive/content_v0.1)."),
]
r = 4
for k, v in rows:
    cell(ov, r, 1, k, BOLD, MID); cell(ov, r, 2, v); r += 1
r += 1
ov.cell(row=r, column=1, value="Key Figures").font = Font(name=FONT, size=12, bold=True, color=NAVY); r += 1
figs = [
    ("Data Domains (L1)", len(mods)),
    ("Data Families (L2)", f"='Data Domains'!E{bs_total}"),
    ("Data Business Objects (L3)", f"='Data Domains'!F{bs_total}"),
    ("  - of which Attribute Groups", sum(o["kind"] == "Attribute Group" for fs in MODEL.values() for f in fs for o in f["objects"])),
    ("Data Business Attributes (L4)", f"='Data Domains'!G{bs_total}"),
    ("Critical Data Elements", f"='Data Domains'!H{bs_total}"),
    ("References to other Data Domains", f"='Data Domains'!J{bs_total}"),
    ("Derived copies", f"='Data Domains'!K{bs_total}"),
    ("Attributes using enterprise shared lists", f"='Data Domains'!I{bs_total}"),
    ("Enterprise shared code lists", len(scl.SHARED)),
    ("Local code lists replaced by shared lists", sum(len(m.replaced) for m in mods)),
    ("Remaining local code lists", f"='Data Domains'!L{bs_total}"),
    ("Crosswalk values needing review", f"=COUNTIF('Code List Crosswalk'!$G$5:$G${max(cw_last, 5)},\"Review\")"),
    ("Core entities in ownership register", len(dec.CONCEPT_OWNERSHIP)),
    ("ID prefixes registered", len(dec.PREFIXES)),
    ("Decisions logged", len(dec.DECISIONS)),
    ("  - Applied", f"=COUNTIF('Decision Log'!$I$5:$I${dl_last},\"Applied*\")"),
    ("  - Proposed", f"=COUNTIF('Decision Log'!$I$5:$I${dl_last},\"Proposed\")"),
    ("  - SME decision required", f"=COUNTIF('Decision Log'!$I$5:$I${dl_last},\"SME decision required\")"),
    ("  - High priority", f"=COUNTIF('Decision Log'!$J$5:$J${dl_last},\"High\")"),
    ("Business term conflicts", len(dec.TERM_CONFLICTS)),
    ("  - Resolved", sum(t.get("status") == "Resolved" for t in dec.TERM_CONFLICTS)),
    ("  - SME (client choice needed)", sum(t.get("status") == "SME" for t in dec.TERM_CONFLICTS)),
    ("Attributes with a Row Ownership Rule", f"=COUNTIF('Enterprise Attributes'!$S$2:$S${ea_last},\"?*\")"),
]
for k, v in figs:
    cell(ov, r, 1, k, BOLD if not k.startswith("  ") else BODY); cell(ov, r, 2, "")
    cell(ov, r, 3, v, BOLD, None, CENTER); r += 1

for ws in wb.worksheets:
    ws.sheet_view.showGridLines = False
wb.calculation.fullCalcOnLoad = True
out = os.path.join(ROOT, "00_Program", "Enterprise_Data_Taxonomy.xlsx")
wb.save(out)
print("saved", out, "| attributes:", ea_last - 1, "| shared lists:", len(scl.SHARED), "| decisions:", len(dec.DECISIONS),
      "| crosswalk rows:", cw_last - 4)
