"""Builds 00_Program/Taxonomy_Explorer.html - a self-contained, client-facing explorer of the consolidated taxonomy.

The page opens locally (double-click; no server or hosting). Data is inlined into explorer/template.html.
It deliberately leaves out review state, the decision log, prefix statuses and working notes.
Views: an area landing map and one landscape per area (areas and home areas from capability_map/areas.py, bands from
AREA_BANDS below, cross-area flows summed in the page from the domain reference flows), a capability view
(capability_map/content_capabilities.py) and an area view per non-band area (that area plus Foundations), with each view's
home page copy in explorer/views/view_<ID>.py.
On this branch the explorer presents the wealth-manager reference model (Wealth_Manager_Rework_Plan.md; areas of CW-018).
Every registered Data Domain is drafted since the W2-W4 merge (50 domains; 07 and 30 retired and never rendered). A
registered domain without a module would be named on its area and in the capability view with no landscape node; a
domain that domains.DISPOSITION retires would sit in a Retiring band until its module is removed. Core entities leave out
retired CONCEPT_OWNERSHIP rows, and their dependency links join the register's referencing domains with the references
found in the merged content (printed as register gaps for the register's owner).
Usage: python build_explorer.py [--brand kpmg|none]   (theme from brand/, default kpmg)
"""
import importlib, json, os, re, sys
import brand
from domains import DISPOSITION
from taxonomy_builder import CONTENT, CONSOLIDATION, ROOT, Consolidated, load_consolidation, model, L1_CODE, DD_NAMES

sys.dont_write_bytecode = True
BRAND = brand.arg(sys.argv)
HERE = os.path.dirname(os.path.abspath(__file__))
UK_SPELLINGS = re.compile(r"\b(organis\w*|authoris\w*|recognis\w*|prioritis\w*|categoris\w*|analys(e|ed|es|ing)|"
                          r"modell\w*|catalogu\w*|programme\w*|licence\w*|centre\w*|behaviour\w*|colour\w*|"
                          r"favour\w*|labour\w*|cheque\w*|defence|judgement)\b", re.I)
VIEW_FIELDS = ("short", "eyebrow", "title", "lede", "ladder", "bands", "roles")
scl = load_consolidation()
sys.path.insert(0, CONSOLIDATION)
dec = importlib.import_module("decisions")
mods = [Consolidated(importlib.import_module(f[:-3]), scl)
        for f in sorted(os.listdir(CONTENT)) if f.startswith("content_") and f.endswith(".py")]

# Value-chain bands of each area's landscape, left to right. Area membership comes from capability_map/areas.py (data, not
# code): a band shows only the listed domains whose home area is that area, and empty bands are dropped. Bands also list the
# domains that ALTERNATIVES could move into the area, so a register edit lands in a sensible band without a code change.
# Domains 45-52 sit in their bands since the W2-W4 merge (48, 49, 50 in Brokerage & Workplace Operations; 45, 46, 47, 51
# in Client & Advice; 52 in Investment).
# A domain in an area but in none of its bands goes to an "Also in this area" band; a domain that domains.DISPOSITION
# retires goes to a "Retiring" band at the end of its area until its module is removed.
AREA_BANDS = {
    "INV": [("view", "Form the view", "The research and market data that investment decisions start from.", ["22", "23"]),
            ("decide", "Decide", "Investment committees, capital-market assumptions, allocation, portfolio construction and model portfolios, and investment risk where it sits with the portfolio teams.", ["24", "31", "46", "36"]),
            ("managers", "Hire managers", "Searching, selecting and overseeing the sub-advisers the funds hire and the third-party funds the platform offers.", ["52"]),
            ("execute", "Execute", "Portfolio orders, executions, allocations and best execution.", ["25"]),
            ("own", "Act as owner", "Voting, engagement and the sustainability data behind them.", ["34"])],
    "IOP": [("record", "Price and record", "Approved prices and the investment book of record of the funds and institutional portfolios.", ["22", "18"]),
            ("settle", "Settle", "Confirmation, settlement, OTC lifecycle and collateral of portfolio trades.", ["26"]),
            ("oversee", "Measure and control", "Risk, performance and investment compliance: measuring and checking what the front office does, and the returns clients earn.", ["31", "32", "33"])],
    "FOP": [("books", "Fund books and assets", "Each fund's books, its valuation and NAV, and the fund assets held for it.", ["27", "28", "26"]),
            ("register", "Fund shareholder processing", "Fund orders from the brokerage platform, the plans, intermediaries and fund-only accounts, and transfer agent controls.", ["29", "16"]),
            ("govern", "Govern and file", "Fund boards, advisory agreements and fund regulatory filings.", ["35"])],
    "CLA": [("offer", "What we offer", "The funds, advice programs, service tiers and brokerage platform the firm offers, and how the range changes.", ["01", "36"]),
            ("know", "Who we serve", "Clients and households, their investor profiles, and the accounts they hold.", ["02", "15"]),
            ("advise", "How we advise", "Goals, plans and recommendations, accounts managed to models, and the advisors who deliver advice.", ["45", "46", "03"]),
            ("engage", "How we engage and serve", "Acquisition and digital engagement, client service and communications, and trust services.", ["04", "13", "51"]),
            ("protect", "Price and protect", "What clients pay and how it is billed, and the conduct and supervision rules around every recommendation.", ["47", "08"])],
    "BWO": [("trade", "Trade", "Client orders, routing, executions, confirmations and execution quality.", ["48"]),
            ("clear", "Clear and safeguard", "The brokerage book of record, clearing and settlement, customer protection, account transfers and margin.", ["49", "29", "51"]),
            ("cash", "Move money", "ACH, wire, check and card activity, cash sweep and program banks, holds and fraud.", ["50", "47"]),
            ("workplace", "Workplace", "The plans the firm recordkeeps, their participants and the rollovers they bring to the direct business.", ["16", "13"])],
    "DIS": [("channel", "Intermediary and institutional channel", "Partners, platforms and consultants, their agreements and payments, and institutional and plan sponsor servicing and reporting.", ["05", "12"]),
            ("assets", "Client assets and flows", "Client assets, flows and net new assets by channel, advisor, campaign and plan.", ["06"]),
            ("economics", "Client economics and insight", "Revenue, cost to serve and profitability by client segment, channel and offering, and the market the firm competes in.", ["10", "11"])],
    "CORP": [("money", "Money and capital", "The corporate books, cash, funding, net capital and insurance.", ["19", "10", "43", "32"]),
             ("people", "People and workplace", "Employees, reward and payroll, and the sites, facilities and services they work in.", ["20", "44"]),
             ("control", "Risk, compliance and legal", "Enterprise risk and controls, compliance, legal affairs and governance.", ["37", "38", "08", "33", "39", "35"]),
             ("enable", "Suppliers and technology", "Suppliers and outsourcing, and technology and security.", ["40", "41", "14", "21"]),
             ("voice", "Reputation", "Brand, media, publications, internal communications and public policy.", ["42"])],
    "FDN": [("found", "Foundations", "The shared reference data, instruments and issuers, licensed data and data governance every area relies on.", ["09", "17", "14", "21"])],
}
TAGLINES = {
    "01": "Strategies, vehicles and share classes: what we manufacture and sell.",
    "02": "The party master: distributor firms, advisors, institutions, plans and end investors.",
    "03": "The sales organization, activities, opportunities, RFPs and consultant relationships.",
    "04": "Campaigns, content, events, digital properties, engagement and leads.",
    "05": "Selling and platform agreements, partner payments and shelf access.",
    "06": "Flows, positions and AUM attributed to firms, advisors and territories.",
    "07": "Territories, coverage, goals, crediting and incentive compensation.",
    "08": "Marketing review, distributor due diligence, licensing, gifts and complaints.",
    "09": "Geography, calendars, currencies, legal entities, org units and shared code lists.",
    "10": "Revenue, distribution cost, allocation and profitability by channel and partner.",
    "11": "Industry flows, market share, peers, ratings and market sizing.",
    "12": "Service model, client reporting, mandate set-up and fee billing.",
    "13": "Shareholder servicing, statements, regulatory communications and proxy.",
    "14": "Data vendors, licensed datasets, permitted use, entitlements and data cost.",
    "15": "Accounts and their registrations, roles, features, instructions and restrictions.",
    "16": "Plans we recordkeep: plan documents, participants, contributions, loans, vesting, distributions and compliance.",
    "17": "The security master: instruments, identifiers, listings, issuers, classifications, credit ratings and corporate actions.",
    "18": "The investment book of record: portfolios, holdings, tax lots, cash and portfolio transactions.",
    "19": "The corporate books: chart of accounts, ledgers, journals, payables, receivables, statements, plans and corporate tax.",
    "20": "The employee master: jobs, positions, lifecycle events, recruiting, reward, payroll, performance and learning.",
    "21": "Data ownership, glossary, taxonomy register, data quality, catalog and lineage, metrics, data products and AI use.",
    "22": "Prices, approved prices and challenges, fair value decisions, FX rates, fixings, curves and index data.",
    "23": "Research coverage, recommendations, internal credit views, estimates, publications, issuer meetings and broker votes.",
    "24": "Investment committees, asset allocation, targets and constraints, investment decisions, rebalancing and ETF baskets.",
    "25": "Trade orders, blocks, executions and allocations, new issues, counterparty approval, commissions and best execution.",
    "26": "Confirmations, settlement instructions and fails, SSIs, OTC derivative and repo lifecycle, trading agreements and collateral.",
    "27": "Fund books, journals, ABOR valuation, NAV calculation and release, swing pricing, fund expenses, distributions and fund tax.",
    "28": "Custodians, safekeeping accounts, statements and reconciliation, corporate action and income processing and securities lending.",
    "29": "Fund orders, order settlement, ETF AP orders, identity verification and AML alerts, TA controls and price transmission.",
    "30": "Private fund profiles and closes, commitments, capital calls and distributions, capital accounts, deals, portfolio companies and carry.",
    "31": "Risk models and measures, exposures, stress tests, liquidity and derivatives programs, risk limits and exceedances.",
    "32": "Performance returns, benchmark returns, ex-post statistics, GIPS composites and attribution.",
    "33": "Coded compliance rules, pre- and post-trade checks, alerts, investment breaches, waivers and rule reviews.",
    "34": "Voting policies, investee votes, engagement, ESG data and assessments, exclusion lists and climate metrics.",
    "35": "Fund boards, meetings and resolutions, advisory agreements and 15(c) renewals, fund regulatory filings and disclosures.",
    "36": "Product proposals and approvals, product change initiatives, launch readiness and periodic product reviews.",
    "37": "Risk register, controls and RCSA, operational incidents and losses, KRIs, issues, resilience, model risk and internal audit.",
    "38": "Firm registrations and filings, policies and obligations, exams, personal trading, conflicts, AML cases and restricted lists.",
    "39": "Contracts, legal matters and holds, corporate boards and resolutions, officers, signing authority and trademarks.",
    "40": "Suppliers, sourcing, purchase orders and invoice matching, supplier performance and the outsourcing register.",
    "41": "Applications, IT assets, identity and access, IT incidents, changes and releases, security testing and projects.",
    "42": "Brand register and standards, media relations, publications, internal communications, crisis, public policy and lobbying.",
    "43": "Bank accounts, cash and forecasts, funding, seed capital, regulatory capital, hedging and corporate insurance.",
    "44": "Sites and leases, facilities, physical security, health and safety, travel and expense, and operational emissions.",
    "45": "Goals, financial plans and projections, recommendations and their best-interest evidence, rollover analyses and advice reviews.",
    "46": "Model assignment per account and household, targets and restrictions, drift, rebalancing, tax-loss harvesting and trade proposals.",
    "47": "Fee schedules and pricing tiers, householding and breakpoints, fee calculation and debits, waivers and fee disclosures.",
    "48": "Client orders, routing and venues, executions and allocations, confirmations, corrections, Rule 605 and 606 disclosure and CAT.",
    "49": "The brokerage book of record: client holdings, tax lots and cost basis, clearing, customer protection, ACATS and margin.",
    "50": "ACH, wire, check and card transactions, sweep programs and program banks, FDIC pass-through, holds, returns and fraud.",
    "51": "Trust instruments, trustees and beneficiaries, discretionary distributions, trust accounting, estates and fiduciary tax.",
    "52": "Manager search and due diligence, sub-advisory agreements and guidelines, oversight reviews and third-party fund approvals.",
}
# 03-06, 08, 10 and 13 carry their wealth-manager short names since the W2-W4 merge (as WEALTH_COPY below); 07 and 30
# keep theirs for history (retired by CW-907 and CW-930, never rendered).
SHORT = {"01": "Product & Offering", "02": "Client & Household", "03": "Advisor Organization", "04": "Marketing & Engagement",
         "05": "Intermediary & Institutional", "06": "Client Assets & Flows", "07": "Compensation & Territory",
         "08": "Retail Conduct & Supervision", "09": "Shared Reference Data", "10": "Client Economics",
         "11": "Market Intelligence", "12": "Institutional Servicing", "13": "Client Service & Communications",
         "14": "Third-Party Data", "15": "Account", "16": "Plan Administration", "17": "Instrument & Issuer",
         "18": "Portfolio & IBOR", "19": "Finance & Accounting", "20": "Human Capital", "21": "Data Governance",
         "22": "Market Data & Pricing", "23": "Investment Research", "24": "Portfolio Management", "25": "Portfolio Trading",
         "26": "Trade Operations", "27": "Fund Accounting", "28": "Fund Custody", "29": "Transfer Agency",
         "30": "Private Markets", "31": "Investment Risk", "32": "Performance & Attribution", "33": "Investment Compliance",
         "34": "Stewardship & ESG", "35": "Fund Governance & Filings", "36": "Product Development",
         "37": "Enterprise & Operational Risk", "38": "Corporate Compliance", "39": "Legal & Governance",
         "40": "Procurement & Vendors", "41": "Technology & InfoSec", "42": "Corporate Communications",
         "43": "Treasury & Capital", "44": "Workplace Services",
         "45": "Planning & Advice", "46": "Managed Portfolios", "47": "Pricing, Fees & Billing", "48": "Brokerage Orders",
         "49": "Clearing & Client Custody", "50": "Money Movement & Cash", "51": "Trust & Estate", "52": "Manager Oversight"}
# Wealth-manager short names and taglines of the adapted, replaced and renamed domains (Wealth_Manager_Rework_Plan.md §5.1),
# as the merged modules stand after W2-W4; they override the entries above (which keep the wholesale wording for history).
WEALTH_COPY = {
    "01": ("Products & Offerings", "Funds, ETFs, CITs and share classes, advice programs and service tiers, and the brokerage platform offering."),
    "02": ("Client & Household", "The party master: clients and households, joint owners and entities, trusted contacts, beneficiaries and the investor profile."),
    "03": ("Advisor Organization", "The firm's advisors and representatives, teams, branches and OSJs, client assignment, capacity and incentive plans."),
    "04": ("Marketing & Engagement", "Acquisition funnel and campaigns, content, digital identity and app events, personalization, experiments and NPS."),
    "05": ("Intermediary & Institutional", "Channel partners and their hierarchy, selling and platform agreements, model delivery, consultants and RFPs."),
    "06": ("Client Assets & Flows", "Client assets and transactions across every channel, net new assets and attribution to channel, advisor, campaign and plan."),
    "08": ("Retail Conduct & Supervision", "Reg BI and Form CRS, supervision and surveillance, complaints, senior investor protection, communications review and licensing."),
    "10": ("Client Economics", "Revenue by offering, channel and client segment, cost to serve, client lifetime value and expense allocation."),
    "13": ("Client Service & Communications", "Service interactions and cases, statements and confirmations, tax documents, e-delivery, escheatment and fund proxy."),
    "25": ("Portfolio Trading", "Portfolio orders, blocks, executions and allocations, new issues, counterparty approval, commissions and best execution."),
    "28": ("Fund Custody", "Fund custodians, safekeeping accounts, statements and reconciliation, corporate action and income processing and securities lending."),
    "11": ("Market Intelligence", "Retail, advice and workplace markets: competitor firms and offerings, fee and pricing comparisons, industry flows and market share."),
    "12": ("Institutional Servicing", "Institutional and OCIO clients and plan sponsors: service models, investment policy statements, mandate set-up, client reporting and reviews."),
    "16": ("Plan Administration", "Plans we recordkeep: plan documents, participants, contributions, loans, vesting, participant balances and ledger, distributions, rollovers and compliance."),
    "18": ("Portfolio & IBOR", "The investment book of record of the funds and institutional portfolios: portfolios, holdings, tax lots, cash and portfolio transactions."),
    "24": ("Portfolio Management", "Investment committees, capital market assumptions, strategic allocation and glide paths, model portfolios for advice and funds, and rebalancing."),
    "26": ("Trade Operations", "Fund-side confirmations, settlement instructions and fails, SSIs, OTC derivative and repo lifecycle, trading agreements and collateral."),
    "29": ("Transfer Agency", "The fund share register: register transactions and balances, the brokerage platform's omnibus position, fund orders and settlement, ETF AP orders and TA controls."),
    "32": ("Performance & Attribution", "Fund and composite returns, benchmark returns, attribution, GIPS composites and client account performance (personal rate of return)."),
    "36": ("Product Development", "Fund, advice service and platform feature proposals and approvals, product changes, launch readiness and periodic product reviews."),
    "38": ("Corporate Compliance", "Adviser and broker-dealer registrations and filings, Form CRS filing, policies and exams, personal trading, conflicts and the AML programs."),
}
WORKING = re.compile(r"verify|confirm|\bTBC\b|CD-\d|SME|open question", re.I)
clean = lambda s: re.sub(r"\s*\((?:see )?CD-\d+[^)]*\)", "", str(s or "")).strip()

# Areas (capability_map/areas.py) and the bands of each area's landscape
sys.path.insert(0, os.path.join(HERE, "capability_map"))
import areas as ar  # noqa: E402
import content_capabilities as cc  # noqa: E402
codes_all = [m.__name__.split("_")[1] for m in mods]
unhomed = [n for n in codes_all if ar.DOMAIN_AREA.get(n) not in ar.AREA_NAMES]
if unhomed:
    raise SystemExit("Data Domains with no home area in capability_map/areas.py: " + ", ".join(unhomed))
for n, (short, tag) in WEALTH_COPY.items():         # every module is merged since W4: the wealth-manager copy always applies
    SHORT[n], TAGLINES[n] = short, tag
missing = [n for n in DD_NAMES if n not in SHORT or n not in TAGLINES]
if missing:
    raise SystemExit("Data Domains with no SHORT name or TAGLINE in build_explorer.py: " + ", ".join(missing))
retiring = {n for n, d in DISPOSITION.items() if d[0] == "retire"}
# Registered Data Domains whose module is not drafted yet (45-52 until W2 and W3): named on their area and in capability
# chips, but with no landscape node, since a node needs the module's families and attributes.
pending = [n for n in DD_NAMES if n not in codes_all and n not in retiring]
bands = []
for a in sorted(ar.AREAS, key=lambda x: x["order"]):
    home = [n for n in codes_all if ar.DOMAIN_AREA[n] == a["id"]]
    placed = [n for n in home if n in retiring]
    for bid, name, desc, members in AREA_BANDS.get(a["id"], []):
        ms = [n for n in members if n in home and n not in placed]
        placed += ms
        if ms:
            bands.append({"id": f"{a['id']}-{bid}", "area": a["id"], "name": name, "desc": desc, "members": ms})
    rest = [n for n in home if n not in placed]
    if rest:
        bands.append({"id": f"{a['id']}-other", "area": a["id"], "name": "Also in this area" if not a["band"] else a["name"],
                      "desc": "Data Domains homed in this area by the area register.", "members": rest})
    ret = [n for n in home if n in retiring]
    if ret:
        bands.append({"id": f"{a['id']}-retiring", "area": a["id"], "name": "Retiring",
                      "desc": "Ruled for retirement (domains.DISPOSITION) but its module is still present; not part of "
                              "the wealth-manager model.", "members": ret})
group_of = {n: b["id"] for b in bands for n in b["members"]}
VIEW_AREAS = [a["id"] for a in sorted(ar.AREAS, key=lambda x: x["order"]) if not a["band"]]


def load_views():
    """Home page copy per area from explorer/views/view_<ID>.py, validated: one module per non-band area, every field."""
    vdir = os.path.join(HERE, "explorer", "views")
    sys.path.insert(0, vdir)
    views, errs = {}, []
    for f in sorted(os.listdir(vdir)):
        if not (f.startswith("view_") and f.endswith(".py")):
            continue
        aid = f[5:-3]
        if aid not in VIEW_AREAS:
            errs.append(f"{f}: {aid!r} is not a non-band area in capability_map/areas.py ({', '.join(VIEW_AREAS)})")
            continue
        v = getattr(importlib.import_module(f[:-3]), "VIEW", None)
        if not isinstance(v, dict):
            errs.append(f"{f}: no VIEW dict")
            continue
        for k in VIEW_FIELDS:
            if k not in v:
                errs.append(f"{f}: missing {k!r}")
        for k in sorted(set(v) - set(VIEW_FIELDS) - {"away"}):
            errs.append(f"{f}: unknown field {k!r}")
        texts = []
        for k in VIEW_FIELDS[:-1]:
            if k in v and not isinstance(v[k], str):
                errs.append(f"{f}: {k!r} must be a string")
            elif k in v and k != "eyebrow" and not v[k].strip():
                errs.append(f"{f}: {k!r} is empty")
            elif k in v:
                texts.append((k, v[k]))
        roles = v.get("roles")
        if not isinstance(roles, (list, tuple)) or not roles:
            errs.append(f"{f}: 'roles' must be a non-empty list of (role, text)")
            roles = []
        for j, r in enumerate(roles):
            if not (isinstance(r, (list, tuple)) and len(r) == 2 and all(isinstance(x, str) and x.strip() for x in r)):
                errs.append(f"{f}: roles[{j}] must be a (role, text) pair of non-empty strings")
            else:
                texts += [(f"roles[{j}]", r[0]), (f"roles[{j}]", r[1])]
        for k, t in texts:
            for m in UK_SPELLINGS.finditer(t):
                errs.append(f"{f} {k}: UK spelling {m.group(0)!r}")
        away = v.get("away", [])
        band_ids = {a["id"] for a in ar.AREAS if a["band"]}
        if not isinstance(away, (list, tuple)) or len(away) > 4:
            errs.append(f"{f}: 'away' must be a list of at most four Data Domain ids")
            away = []
        for n in away:
            if n not in codes_all:
                errs.append(f"{f}: away {n!r} is not a known Data Domain")
            elif ar.DOMAIN_AREA[n] == aid or ar.DOMAIN_AREA[n] in band_ids:
                errs.append(f"{f}: away {n} is in the view ({ar.AREA_NAMES[ar.DOMAIN_AREA[n]]}), not outside it")
        views[aid] = ({k: v.get(k, "") for k in VIEW_FIELDS[:-1]} | {"roles": [list(r) for r in roles]}
                      | ({"away": list(away)} if away else {}))
    errs += [f"no explorer/views/view_{a}.py for area {a} ({ar.AREA_NAMES[a]})" for a in VIEW_AREAS if a not in views]
    if errs:
        raise SystemExit("Area view validation failed:\n  " + "\n  ".join(errs))
    return views


VIEWS = load_views()
areas_out = [{"id": a["id"], "name": a["name"], "desc": a["description"], "band": bool(a["band"]),
              "pending": [n for n in pending if ar.DOMAIN_AREA.get(n) == a["id"]],
              **({"view": VIEWS[a["id"]]} if a["id"] in VIEWS else {})}
             for a in sorted(ar.AREAS, key=lambda x: x["order"])]
reg = {n: {"name": DD_NAMES[n], "short": SHORT[n], "tag": TAGLINES[n], "area": ar.DOMAIN_AREA[n]} for n in pending}
caps = {"lines": cc.BUSINESS_LINES,
        "l1": [{"id": c["id"], "name": c["name"], "area": c["area"], "def": c["definition"],
                "l2": [[x["id"], x["name"], x["area"], x["masters"], list(x["reads"]),
                        "all" if x["lines"] == cc.ALL else list(x["lines"]), x["definition"]] for x in c["l2"]]}
               for c in cc.CAPABILITIES]}
bds, attrs, flows = [], [], {}
drafted = {m.__name__.split("_")[1] for m in mods}   # flows to a registered-but-undrafted master have no node to land on
LOC, AIDX = {}, {}            # (domain, object) -> (family index, object index); (domain, object, attribute) -> attrs index
for m in mods:
    n = m.__name__.split("_")[1]
    ov = dict(m.META["overview"])
    S = getattr(m.enr, "SUMMARY", {}) if m.enr else {}
    fams = []
    for fi, f in enumerate(model(m)):
        objs = []
        for oi, o in enumerate(f["objects"]):
            LOC[(n, o["name"])] = (fi, oi)
            idx = []
            for x in o["attrs"]:
                a, note = x["a"], (x["a"][9] if len(x["a"]) > 9 else "")
                idx.append(len(attrs))
                AIDX[(n, o["name"], a[0])] = len(attrs)
                owner = x["owner"] if x["flag"] in ("Reference", "Derived copy") else ""
                attrs.append([a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], 1 if a[8] == "Y" else 0,
                              1 if re.search(r"\bPII\b", note) else 0, "" if WORKING.search(note) else clean(note),
                              {"Mastered here": 0, "Reference": 1, "Derived copy": 2}.get(x["flag"], 0), owner, x["id"]])
                if owner and owner in drafted:
                    flows[f"{n}>{owner}"] = flows.get(f"{n}>{owner}", 0) + 1
            objs.append({"name": o["name"], "grain": o["grain"], "kind": o["kind"], "parent": o["parent"],
                         "group": o["group"] if (o["group_size"] > 1 or o["group"] != o["name"]) else "", "gdef": o["group_def"], "a": idx})
        fams.append({"code": f["code"], "name": f["name"], "def": f["def"], "o": objs})
    bds.append({"n": n, "code": L1_CODE[n], "name": DD_NAMES[n], "short": SHORT[n],
                "tag": TAGLINES[n], "group": group_of[n], "area": ar.DOMAIN_AREA[n], "purpose": ov.get("Purpose", ""), "masters": clean(S.get("masters", "")),
                "references": clean(S.get("references", "")), "f": fams, "rel": [[clean(x) for x in r] for r in m.REL],
                "lists": {k: [v[0], [list(x) for x in v[1]]] for k, v in m.CL.items() if not k.startswith("Shared: ")}})

# Core entities: CONCEPT_OWNERSHIP rows of live, drafted domains (rows noted "Retired", and the rows of the retired 07 and
# 30 kept for traceability, are left out). The referencing domains are the register's list joined with the domains whose
# attributes reference the entity in the merged taxonomy (a Reference attribute typed "Reference (<concept>...)" that
# resolves to the entity's owner), so the dependency links of the books of record (49 Client Holding, 16 Participant
# Balance, 18 Portfolio Holding) and every other core entity follow the content, not only the register.
REFD = {}
for m in mods:
    n = m.__name__.split("_")[1]
    for f in model(m):
        for o in f["objects"]:
            for x in o["attrs"]:
                t = re.match(r"Reference \(([^,)]+)", x["a"][3])
                if x["flag"] == "Reference" and t and x["owner"] and x["owner"] != n:
                    REFD.setdefault((t.group(1).strip(), x["owner"]), set()).add(n)
entities, REG_GAPS = [], []
for c, o, p, refs, note in dec.CONCEPT_OWNERSHIP:
    if o not in drafted or str(note).startswith("Retired"):
        continue
    found = REFD.get((c, o), set()) | REFD.get((re.sub(r"\s*\(.*\)$", "", c), o), set())
    extra = sorted(found - set(refs) - {o})
    if extra:
        REG_GAPS.append(f"{c} ({o}): +{', '.join(extra)}")
    entities.append([c, o, p, sorted(set(r for r in refs if r != o and r in drafted) | set(extra))])
edges = {}
for c, o, p, refs in entities:
    for r in refs:
        edges.setdefault(f"{r}>{o}", []).append(c)
shared = [{"name": s["name"], "steward": s["steward"], "def": s["definition"], "source": s["source"],
           "values": [list(v) for v in s["values"]], "members": [list(x) for x in s["members"]]} for s in scl.SHARED]

# Data products (data_products/): lineage resolved to the explorer's family, object and attribute indexes
sys.path.insert(0, os.path.join(HERE, "data_products"))
import dp_model, framework as fw  # noqa: E402
specs, _, dp_errs = dp_model.load_specs()
e, _ = dp_model.validate(specs, dp_model.load_taxonomy(), partial=True)
# Every function, capability, area and topic check is fatal again: framework.FUNCTIONS was re-pointed to the W0
# capability map and areas on 2026-10-14 (Wealth_Manager_Rework_Plan.md §8.1; CW-013, CW-018).
if dp_errs + e:
    raise SystemExit("Data product validation failed:\n  " + "\n  ".join(dp_errs + e))
missing = [p[0] for p in fw.PRODUCTS if p[0] not in specs and not dp_model.is_pending(p[0]) and not dp_model.is_retired(p[0])]
if missing:
    print("WARN data products without a specification are left out:", ", ".join(missing))


def no_decisions(text):
    """Drop sentences that cite the decision log (CD-nnn), which the explorer deliberately leaves out."""
    return " ".join(x for x in re.split(r"(?<=[.;])\s+", clean(text)) if not re.search(r"CD-\d", x)).strip()


def dp_spec(s):
    return {"def": s["definition"], "q": s["business_questions"], "grain": s["grain"], "dims": s["dimensions"],
            "m": [[n_, d_, [u if isinstance(u, str) else [u[0], *LOC[(u[0], u[1])], AIDX[u]] for u in us]] for n_, d_, us in s["measures"]],
            "up": s["upstream"], "refresh": s["refresh"], "time": s["timeliness"],
            "hist": s["history"], "cls": s["classification"], "pii": s["pii"] == "Y", "dlv": s["delivery"],
            "dq": s["dq_rules"], "notes": no_decisions(s.get("notes", "")),
            "in": [[n, *LOC[(n, on)], [AIDX[(n, on, a)] for a in an]] for n, on, an in s["inputs"]]}


# Logical models (data_models/): optional per product; attributes link to the explorer's attribute index
sys.path.insert(0, os.path.join(HERE, "data_models"))
LM = {}
if os.path.exists(os.path.join(HERE, "data_models", "keys.py")):
    import dm_model  # noqa: E402
    lms, lm_errs, _ = dm_model.validate()
    if lm_errs:
        raise SystemExit("Logical model validation failed:\n  " + "\n  ".join(lm_errs))
    for pid, m in lms.items():
        LM[pid] = {"style": m["style"], "notes": no_decisions(m["notes"]),
                   "e": [{"n": e["name"], "r": e["role"], "g": e["grain"], "note": no_decisions(e["note"]), "c": e.get("conformed"),
                          "a": [[x["name"], int(x["pk"]), x["fk"], x["type"], int(x["cde"]), int(x["pii"]),
                                 AIDX.get((*x["obj"], x["name"]), -1) if x["obj"] else -1, int(x["derived"])] for x in e["attrs"]]}
                         for e in m["entities"]],
                   "rel": [[r["child"], r["parent"], r["fk"], r["card"], int(r["optional"])] for r in m["relationships"]]}

# fns: [code, name, description, roles, decisions, area, capabilities] (the page reads the first five by position), live
# functions only; fnret: the retired functions (framework.RETIRED_FUNCTIONS) as [code, name, decision, successor], so a
# product or semantic model that still names one shows it as retired; no function page or filter lists them.
# p: live products only. ret: retired products (framework.RETIRED_PRODUCTS) with their retirement note, no product page.
RFN = dp_model.RETIRED_FNS
dp = {"fns": [[f[0], f[1], f[4], f[5], f[6], f[2], list(f[3])] for f in dp_model.live_functions()],
      "fnret": [[f[0], f[1], RFN[f[0]], fw.FUNCTION_SUCCESSOR.get(f[0]) or ""] for f in fw.FUNCTIONS if f[0] in RFN],
      "tiers": fw.TIERS, "types": fw.TYPES,
      "topics": [list(t) for t in fw.TOPICS],
      "p": [dict(id=p[0], name=p[1], tier=p[2], type=p[3], owner=p[4], role=p[5], fn=p[6], sfn=p[7], wave=fw.WAVE.get(p[0], "Wave 1"), topic=fw.topic_of(p),
                 why=list(fw.RATIONALE.get(p[0], ("", "", "")))[:2], lm=LM.get(p[0]), **dp_spec(specs[p[0]]))
            for p in fw.PRODUCTS if p[0] in specs and not dp_model.is_pending(p[0]) and not dp_model.is_retired(p[0])],
      # pending WP0 re-scope (framework.RESCOPE_PENDING): listed in a collapsed group on the products page, no product page
      "pend": [dict(id=p[0], name=p[1], tier=p[2], type=p[3], owner=p[4], wave=fw.WAVE.get(p[0], "Wave 1"))
               for p in fw.PRODUCTS if dp_model.is_pending(p[0]) and not dp_model.is_retired(p[0])],
      "ret": [dict(id=p[0], name=p[1], tier=p[2], type=p[3], owner=p[4], dec=dp_model.RETIRED[p[0]],
                   note=f"Retired at product framing ({dp_model.RETIRED[p[0]]}); the id is never reused.")
              for p in fw.PRODUCTS if dp_model.is_retired(p[0])],
      "bl": [dict(id=b[0], name=b[1], tier=b[2], type=b[3], owner=b[4], fn=b[5], sfn=b[6], topic=fw.TOPIC_OF_DOMAIN.get(b[4], ""), **{"def": b[7]}, doms=b[8],
                  value=b[9], prio=b[10], gap=no_decisions(b[11])) for b in fw.BACKLOG]}

# Semantic models (semantic_model/): published when they validate. Open decisions are working notes and stay out.
SM = None
if os.path.exists(os.path.join(HERE, "semantic_model", "register.py")):
    sys.path.insert(0, os.path.join(HERE, "semantic_model"))
    import sm_model, register as smr  # noqa: E402
    sms, sm_logical, _, sm_gaps, sm_errs, _ = sm_model.load()
    if sm_errs:
        raise SystemExit("Semantic model validation failed:\n  " + "\n  ".join(sm_errs[:30]))

    def cd_free(v):
        """Model text without decision-log references: drop "(CD-041)" asides, then any sentence still citing one."""
        if isinstance(v, list):
            return [cd_free(x) for x in v]
        if not isinstance(v, str) or "CD-" not in v:
            return v
        v = re.sub(r"\s*\((?:see )?CD-\d+(?:\s*(?:,|;|and)\s*CD-\d+)*\)", "", v)
        return no_decisions(v) if "CD-" in v else v

    def sm_cols(pid, ent, cols):
        e = sm_model.entity(sm_logical, pid, ent)
        if e is None:          # table of a product pending WP0 re-scope inside a live model (CW-041)
            return []
        byname = {a["name"]: a for a in e["attrs"]}
        out = []
        for c in cols:
            a = byname[c["attr"]]
            out.append([c["name"], c["attr"], AIDX.get((*a["obj"], a["name"]), -1) if a["obj"] else -1, cd_free(c.get("note", ""))])
        return out

    def sm_doms(m):
        doms = set()
        for t in m["tables"]:
            e = sm_model.entity(sm_logical, t["product"], t["entity"])
            if e is None:          # a table of a product pending WP0 re-scope inside a live model (CW-041): not built
                continue
            doms |= {a["obj"][0] for a in e["attrs"] if a["obj"]}
        return sorted(doms)

    sm_list = []
    for mid, name, owner, fns, prods, purpose in smr.MODELS:
        if mid in sm_model.PENDING:          # pending WP0 re-scope (register.PENDING): not published
            continue
        m = sms.get(mid)
        row = dict(id=mid, name=name, owner=owner, fns=fns, prods=prods, prop=smr.PROPOSED.get(mid, []), purpose=purpose)
        if m:
            m = {k: (v if k in ("tables", "metrics", "relationships", "access", "verified_questions", "cannot_answer")
                     else cd_free(v)) for k, v in m.items()}
            row.update(status=m["status"], desc=m["description"], q=m["questions"], doms=sm_doms(m), shared=m["shared"],
                       tables=[dict(n=t["name"], p=t["product"], e=t["entity"], k=t["kind"], g=cd_free(t.get("grain", "")),
                                    af=cd_free(t.get("always_filter", [])), df=cd_free(t.get("default_filter", "")),
                                    d=sm_cols(t["product"], t["entity"], t.get("dimensions", [])),
                                    f=sm_cols(t["product"], t["entity"], t.get("facts", [])),
                                    h=[[h[0], cd_free(h[1])] for h in t.get("hidden", [])]) for t in m["tables"]],
                       rel=[[r["frm"], r["to"], cd_free(r["on"]), r["type"], cd_free(r.get("warning", ""))] for r in m["relationships"]],
                       hier=[[h["name"], h["levels"]] for h in m.get("hierarchies", [])],
                       metrics=[dict(n=x["name"], ref=x["ref"]) if x.get("ref") else
                                dict(n=x["name"], agg=x["aggregation"], expr=cd_free(x.get("expr", "")), num=cd_free(x.get("numerator", "")),
                                     den=cd_free(x.get("denominator", "")), time=cd_free(x.get("time_rule", "")), src=list(x["source"]),
                                     desc=cd_free(x["description"]), note=cd_free(x.get("note", "")),
                                     cert=x["name"] in smr.CERTIFIED) for x in m["metrics"]],
                       excl=[[x[0], x[1], cd_free(x[2])] for x in m.get("excluded", [])],
                       acc=dict(cls=m["access"]["classification"],
                                roles=[[r["role"], cd_free(r.get("rows", "")), cd_free(r.get("columns", "")), r.get("hidden", [])]
                                       for r in m["access"]["roles"]]),
                       vq=[[cd_free(q["question"]), cd_free(q["answer"]), q.get("sql", "")] for q in m["verified_questions"]],
                       ca=[[cd_free(c["question"]), cd_free(c["why"]), c.get("gap", ""), sm_gaps.get(c.get("gap", ""), {}).get("title", "")]
                           for c in m.get("cannot_answer", [])])
        sm_list.append(row)
    # Measures that more than one product defines under the same name: shown in the metric glossary so owners
    # can see where two numbers with one name can disagree.
    same = {}
    for pid, s in dp_model.live(specs).items():
        for n, d, _ in s["measures"]:
            same.setdefault(n.strip().lower(), []).append([pid, n, d])
    published = {tuple(x["source"]): mid for mid, m in sms.items() for x in m["metrics"] if not x.get("ref")}
    dupes = [[v[0][1], [[pid, cd_free(d), published.get((pid, n), "")] for pid, n, d in v]]
             for k, v in sorted(same.items()) if len(v) > 1 and k not in {c.lower() for c in smr.CERTIFIED}]
    SM = {"agg": smr.AGGREGATION, "cert": {k: list(v) for k, v in smr.CERTIFIED.items()}, "m": sm_list, "dupes": dupes}

data = {"asOf": "October 2026", "flows": flows, "groups": bands, "areas": areas_out, "caps": caps, "reg": reg,
        "bds": bds, "attrs": attrs, "entities": entities, "edges": edges, "shared": shared, "dp": dp, "sm": SM}


def scrub(v):
    """Last pass over every published string: decision-log citations (CD-nnn) are working notes and stay out of the page."""
    if isinstance(v, dict):
        return {k: scrub(x) for k, x in v.items()}
    if isinstance(v, list):
        return [scrub(x) for x in v]
    if not isinstance(v, str) or "CD-" not in v:
        return v
    v = re.sub(r"\s*\((?:see )?CD-\d+[^()]*\)", "", v)                       # "(CD-041)", "(CD-041, CD-052)"
    v = re.sub(r"\s*\(([^()]*?),\s*CD-\d+(?:\s*,\s*CD-\d+)*\)", r" (\1)", v)  # "(GL Posting, CD-210)" -> "(GL Posting)"
    v = re.sub(r"\s*[-;,]\s*(?:Stage \d+,\s*)?CD-\d+(?:\s*,\s*CD-\d+)*(?=[\s.;)]|$)", "", v)  # " - Stage 2, CD-143"
    return no_decisions(v) if "CD-" in v else v


data = scrub(data)
payload = json.dumps(data, separators=(",", ":"), ensure_ascii=False).replace("</", "<\\/")
tpl = open(os.path.join(HERE, "explorer", "template.html"), encoding="utf-8").read()
assert "/*__DATA__*/" in tpl
out = os.path.join(ROOT, "00_Program", "Taxonomy_Explorer.html")
with open(out, "w", encoding="utf-8") as f:
    f.write(brand.apply(tpl, BRAND).replace("/*__DATA__*/", payload))
if REG_GAPS:
    print(f"NOTE {len(REG_GAPS)} core entities referenced in the content by domains that CONCEPT_OWNERSHIP does not list "
          "(added to the dependency links): " + "; ".join(REG_GAPS[:12]) + (" ..." if len(REG_GAPS) > 12 else ""))
print("saved", out, f"{os.path.getsize(out)/1e6:.2f} MB |", len(bds), "data domains |", len(attrs), "attributes |",
      len(entities), "core entities |", len(edges), "dependency links |", len(dp["p"]), "+", len(dp["bl"]), "data products |", len(LM), "logical models |",
      sum(1 for m in (SM or {}).get("m", []) if m.get("status")), "semantic models |",
      len(areas_out), "areas |", len(caps["l1"]), "+", sum(len(c["l2"]) for c in caps["l1"]), "capabilities")
