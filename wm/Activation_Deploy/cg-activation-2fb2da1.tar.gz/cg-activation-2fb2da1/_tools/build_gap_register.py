"""Builds 00_Program/Gap_Register.xlsx: the consolidated triage register of gaps found while specifying data products and
modeling them (consolidation/gaps_*.py), validated against the taxonomy and the product register.
Usage: python build_gap_register.py
"""
import importlib, os, sys
from collections import Counter, defaultdict

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
for p in ("consolidation", "data_products"):
    sys.path.insert(0, os.path.join(HERE, p))
from taxonomy_builder import ROOT, DD_NAMES, header, cell, title, BODY, BOLD, MID, LIGHT, CENTER, WRAP  # noqa: E402
from openpyxl import Workbook  # noqa: E402
import dp_model  # noqa: E402
import framework as fw  # noqa: E402
import decisions as dec  # noqa: E402

CATEGORIES = ["Missing parent reference", "Missing attribute", "Missing link between objects", "Missing object",
              "Multi-type reference", "Spec input missing", "Key or grain ambiguity", "Modeling decision"]
CHANGE_TYPES = ["Taxonomy change", "Spec change", "Model change", "SME decision"]
PRIORITIES = ["High", "Medium", "Low"]
STATUSES = ["Proposed", "Partly resolved", "Resolved"]
FIELDS = ["id", "title", "category", "domains", "objects", "issue", "resolution", "change_type", "products",
          "occurrences", "priority", "status", "owner_role", "related"]

objs = dp_model.load_taxonomy()
reg = {p[0]: p for p in fw.PRODUCTS}
cds = {d["id"] for d in dec.DECISIONS}
gaps, errs, src = [], [], {}
for f in sorted(x[:-3] for x in os.listdir(os.path.join(HERE, "consolidation")) if x.startswith("gaps_") and x.endswith(".py")):
    for g in importlib.import_module(f).GAPS:
        gaps.append(g); src[g.get("id")] = f
ids = Counter(g.get("id") for g in gaps)
for g in gaps:
    i = g.get("id")
    if ids[i] > 1: errs.append(f"{i}: duplicate id")
    for k in FIELDS:
        if k not in g: errs.append(f"{i}: missing field {k}")
    if g.get("category") not in CATEGORIES: errs.append(f"{i}: category {g.get('category')!r}")
    if g.get("change_type") not in CHANGE_TYPES: errs.append(f"{i}: change_type {g.get('change_type')!r}")
    if g.get("priority") not in PRIORITIES: errs.append(f"{i}: priority {g.get('priority')!r}")
    if g.get("status") not in STATUSES: errs.append(f"{i}: status {g.get('status')!r}")
    for d in g.get("domains", []):
        if d not in DD_NAMES: errs.append(f"{i}: domain {d}")
    for o in g.get("objects", []):
        if tuple(o) not in objs: errs.append(f"{i}: object {o} not in taxonomy")
    for p in g.get("products", []):
        if p not in reg: errs.append(f"{i}: product {p}")
    for c in g.get("related", []):
        if c not in cds: errs.append(f"{i}: related decision {c} not in decision log")
if errs:
    raise SystemExit("Gap register validation failed:\n  " + "\n  ".join(errs[:60]))

prio_rank = {p: n for n, p in enumerate(PRIORITIES)}
gaps.sort(key=lambda g: (prio_rank[g["priority"]], g["domains"][0] if g["domains"] else "99", -len(g["products"]), g["id"]))
dd = lambda n: f"{n} {DD_NAMES[n]}"
wb = Workbook()

ov = wb.active; ov.title = "Overview"
title(ov, "Gap Register", f"Asset manager (wholesale distributor) | {fw.VERSION} | Consolidated from the data product specs, the logical "
      "models and the key registry. Status of each entry: see the Status column.")
header(ov, 4, ["Topic", "Description"], [30, 120])
occ = sum(g["occurrences"] for g in gaps)
rows = [
    ("Purpose", "One triage list of the gaps found while specifying the 91 data products and modeling them: missing attributes and "
     "references in the taxonomy, missing spec inputs, ambiguous keys and open modeling decisions. Each entry merges every "
     "product note that raised the same underlying fix."),
    ("Scope", f"{len(gaps)} issues consolidated from {occ} raw notes ('Taxonomy gap' in specs, 'Model gap' in models, unresolved "
     "reference links and validator warnings). Status: " + "; ".join(f"{s} ({sum(1 for g in gaps if g['status'] == s)})" for s in STATUSES) + "."),
    ("Categories", "; ".join(f"{c} ({sum(1 for g in gaps if g['category'] == c)})" for c in CATEGORIES)),
    ("Change types", "Taxonomy change: edit a Data Domain content module (new attribute, reference or object). Spec change: edit a "
     "data product specification. Model change: edit a logical model. SME decision: a business choice with no content change yet."),
    ("Priority", "High: affects a foundational product (DP-001 to DP-014, DP-075) or 3 or more products. Medium: exactly 2 "
     "products, or one product where the gap blocks evidence for a named regulation, pay, client billing or certified flows "
     "and AUM. Low: otherwise."),
    ("How to use", "Triage by Data Domain owner: accept, change or reject each issue. Accepted Taxonomy changes follow change control "
     "(edit the content module, rebuild, record a CD- decision). Spec and model changes are applied in _tools/data_products and "
     "_tools/data_models and re-validated by the builders."),
    ("Source", "_tools/consolidation/gaps_*.py; rebuild with python build_gap_register.py."),
]
for i, (k, v) in enumerate(rows, 5):
    cell(ov, i, 1, k, BOLD); cell(ov, i, 2, v)

sm = wb.create_sheet("Summary")
title(sm, "Summary", "Issues by primary Data Domain and priority, and by category and change type.")
header(sm, 4, ["Primary Data Domain", "High", "Medium", "Low", "Total", "Taxonomy change", "Spec change", "Model change", "SME decision"],
       [44, 9, 9, 9, 9, 14, 12, 12, 12])
r = 5
for n in sorted(DD_NAMES):
    G = [g for g in gaps if g["domains"] and g["domains"][0] == n]
    if not G: continue
    vals = [dd(n)] + [sum(1 for g in G if g["priority"] == p) for p in PRIORITIES] + [len(G)] + \
           [sum(1 for g in G if g["change_type"] == c) for c in CHANGE_TYPES]
    for ci, v in enumerate(vals, 1):
        cell(sm, r, ci, v, BOLD if ci in (1, 5) else BODY, None, WRAP if ci == 1 else CENTER)
    r += 1
vals = ["Total"] + [sum(1 for g in gaps if g["priority"] == p) for p in PRIORITIES] + [len(gaps)] + \
       [sum(1 for g in gaps if g["change_type"] == c) for c in CHANGE_TYPES]
for ci, v in enumerate(vals, 1):
    cell(sm, r, ci, v, BOLD, MID, WRAP if ci == 1 else CENTER)
r += 3
header(sm, r, ["Category"] + CHANGE_TYPES + ["Total"], [44, 14, 12, 12, 12, 9])
r += 1
for c in CATEGORIES:
    vals = [c] + [sum(1 for g in gaps if g["category"] == c and g["change_type"] == t) for t in CHANGE_TYPES] + \
           [sum(1 for g in gaps if g["category"] == c)]
    for ci, v in enumerate(vals, 1):
        cell(sm, r, ci, v, BOLD if ci == 1 else BODY, None, WRAP if ci == 1 else CENTER)
    r += 1
for c, w in zip("ABCDEFGHI", [44, 14, 12, 12, 12, 14, 12, 12, 12]):
    sm.column_dimensions[c].width = w

iss = wb.create_sheet("Issues")
title(iss, "Issues", "Every consolidated issue, highest priority first. Filter by Data Domain, owner, category or change type.")
H = ["Gap ID", "Priority", "Title", "Category", "Change Type", "Primary Data Domain", "Other Domains", "Objects", "Issue",
     "Proposed Resolution", "Products Affected", "# Products", "# Notes Merged", "Decision Owner", "Related Decisions", "Status",
     "Resolution Applied", "Triage Decision", "Triage Notes"]
header(iss, 4, H, [13, 9, 44, 22, 15, 30, 16, 36, 60, 60, 36, 9, 9, 30, 14, 12, 50, 16, 30])
for i, g in enumerate(gaps, 5):
    vals = [g["id"], g["priority"], g["title"], g["category"], g["change_type"], dd(g["domains"][0]) if g["domains"] else "",
            ", ".join(g["domains"][1:]), "; ".join(f"{o[0]} {o[1]}" for o in g["objects"]), g["issue"], g["resolution"],
            ", ".join(g["products"]), len(g["products"]), g["occurrences"], g["owner_role"], ", ".join(g["related"]),
            g["status"], g.get("applied", ""), "", ""]
    for ci, v in enumerate(vals, 1):
        cell(iss, i, ci, v, BOLD if ci == 3 else BODY, MID if ci == 2 and g["priority"] == "High" else None,
             CENTER if ci in (2, 12, 13, 16) else WRAP)
iss.freeze_panes = "D5"; iss.auto_filter.ref = f"A4:S{4 + len(gaps)}"

bp = wb.create_sheet("By Product")
title(bp, "By Product", "Open issues per data product, so each product owner sees what blocks or weakens their product.")
header(bp, 4, ["Product ID", "Data Product", "Tier", "# Issues", "# High", "Issue IDs"], [11, 40, 16, 9, 9, 90])
per = defaultdict(list)
for g in gaps:
    for p in g["products"]:
        per[p].append(g)
r = 5
for p in fw.PRODUCTS:
    G = per.get(p[0], [])
    vals = [p[0], p[1], p[2], len(G), sum(1 for g in G if g["priority"] == "High"), ", ".join(g["id"] for g in G)]
    for ci, v in enumerate(vals, 1):
        cell(bp, r, ci, v, BOLD if ci == 2 else BODY, LIGHT if not G else None, CENTER if ci in (4, 5) else WRAP)
    r += 1
bp.freeze_panes = "C5"; bp.auto_filter.ref = f"A4:F{r-1}"

bo = wb.create_sheet("By Owner")
title(bo, "By Decision Owner", "Issues grouped by the data owner role who decides them, for workshop planning.")
header(bo, 4, ["Decision Owner", "# Issues", "High", "Medium", "Low", "Issue IDs"], [36, 9, 9, 9, 9, 90])
r = 5
for o, G in sorted(defaultdict(list, {k: [g for g in gaps if g["owner_role"] == k] for k in {g["owner_role"] for g in gaps}}).items(),
                   key=lambda x: (-len(x[1]), x[0])):
    vals = [o, len(G)] + [sum(1 for g in G if g["priority"] == p) for p in PRIORITIES] + [", ".join(g["id"] for g in G)]
    for ci, v in enumerate(vals, 1):
        cell(bo, r, ci, v, BOLD if ci == 1 else BODY, None, CENTER if 2 <= ci <= 5 else WRAP)
    r += 1
bo.freeze_panes = "B5"

for ws in wb.worksheets:
    ws.sheet_view.showGridLines = False
out = os.path.join(ROOT, "00_Program", "Gap_Register.xlsx")
wb.save(out)
print("saved", out, "|", len(gaps), "issues from", occ, "notes |", dict(Counter(g["priority"] for g in gaps)), "|",
      dict(Counter(g["change_type"] for g in gaps)))
