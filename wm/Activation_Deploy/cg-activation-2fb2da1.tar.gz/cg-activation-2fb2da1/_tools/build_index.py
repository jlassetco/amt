"""Builds 00_Program/Taxonomy_Index.xlsx: one row per L2 Data Family / L3 Data Business Object across every Data Domain.

Counts are snapshots taken at build time from the content modules (cross-workbook formulas are deliberately avoided).
Usage: python build_index.py
"""
import importlib, os, sys
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment
from taxonomy_builder import CONTENT, ROOT, Consolidated, load_consolidation, model, header, cell, title, BODY, BOLD, MID, LIGHT, CENTER, WRAP, FONT

sys.dont_write_bytecode = True
_scl = load_consolidation()

mods = [importlib.import_module(f[:-3]) for f in sorted(os.listdir(CONTENT))
        if f.startswith("content_") and f.endswith(".py")]
if _scl:
    mods = [Consolidated(m, _scl) for m in mods]

wb = Workbook()
summ = wb.active; summ.title = "Data Domains"
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "capability_map"))
try:   # area register (read only; owned by the capability map)
    _areas = importlib.import_module("areas")
    AREA_OF = {n: _areas.AREA_NAMES[a] for n, a in _areas.DOMAIN_AREA.items()}
except (ModuleNotFoundError, AttributeError):
    AREA_OF = {}
from domains import DISPOSITION  # noqa: E402
title(summ, "Enterprise Data Taxonomy - Index (L1 Data Domains)",
      "Wealth manager (direct, with its own funds) | US | Counts are a snapshot at build time; see each workbook for live detail. "
      "Filter 'Area' for an area view; 'Wealth Disposition' says whether the domain was kept, adapted, replaced or added.")
header(summ, 4, ["#", "Data Domain", "Workbook", "Families (L2)", "Object Groups", "Objects (L3)", "Attributes (L4)", "CDEs", "Code Lists",
                 "Area", "Wealth Disposition"],
       [6, 40, 70, 10, 12, 10, 11, 9, 11, 22, 12])
r = 5
for m in mods:
    T = m.T
    vals = [m.__name__.split("_")[1], m.META["title"], m.META["output"], len(T), sum(len(d[3]) for d in T),
            sum(len(s[2]) for d in T for s in d[3]), sum(len(c[1]) for d in T for s in d[3] for c in s[2]),
            sum(1 for d in T for s in d[3] for c in s[2] for a in c[1] if a[8] == "Y"), len(m.CL)]
    n = m.__name__.split("_")[1]
    vals += [AREA_OF.get(n, ""), DISPOSITION.get(n, ("", ""))[0].capitalize()]
    for ci, v in enumerate(vals, 1):
        cell(summ, r, ci, v, BOLD if ci == 2 else BODY, None, CENTER if ci in (1, 4, 5, 6, 7, 8, 9, 11) else WRAP)
    r += 1
cell(summ, r, 1, "", BOLD, MID); cell(summ, r, 2, "Total", BOLD, MID); cell(summ, r, 3, "", BOLD, MID)
for ci in range(4, 10):
    col = "DEFGHI"[ci - 4]
    cell(summ, r, ci, f"=SUM({col}5:{col}{r-1})", BOLD, MID, CENTER)
summ.freeze_panes = "A5"; summ.auto_filter.ref = f"A4:K{r-1}"

idx = wb.create_sheet("Hierarchy Index")
title(idx, "Cross-Domain Hierarchy Index", "Every L2 Data Family > L3 Data Business Object across all Data Domains, with grain. Filter by Data Domain or search by object.")
header(idx, 4, ["Data Domain", "Family Code", "Data Family", "Object Code", "Data Business Object", "Object Group", "Grain (one row =)", "Kind", "# Attributes",
                "Row Ownership Rules"],
       [32, 12, 28, 14, 30, 26, 36, 16, 12, 60])
r = 5
for mi, m in enumerate(mods):
    fill = None if mi % 2 == 0 else LIGHT
    for f in model(m):
        for o in f["objects"]:
            grp = o["group"] if (o["group_size"] > 1 or o["group"] != o["name"]) else ""
            rules = "\n".join(f"{x['a'][0]}: {x['row_rule']}" for x in o["attrs"] if x["row_rule"])
            for ci, v in enumerate([m.META["title"], f["code"], f["name"], o["code"], o["name"], grp, o["grain"], o["kind"], len(o["attrs"]), rules], 1):
                cell(idx, r, ci, v, BODY, fill, CENTER if ci == 9 else WRAP)
            r += 1
idx.freeze_panes = "A5"; idx.auto_filter.ref = f"A4:J{r-1}"

pfx = wb.create_sheet("Code Lists Index")
title(pfx, "Code List Index", "All controlled vocabularies by Data Domain - use to spot lists that should be shared enterprise-wide.")
header(pfx, 4, ["Code List", "Data Domain", "# Values", "Source / Alignment"], [40, 44, 10, 50])
rows = sorted((name, m.META["title"], len(v[1]), v[0]) for m in mods for name, v in m.CL.items())
for i, row in enumerate(rows, 5):
    for ci, v in enumerate(row, 1):
        cell(pfx, i, ci, v, BOLD if ci == 1 else BODY, None, CENTER if ci == 3 else WRAP)
pfx.freeze_panes = "A5"; pfx.auto_filter.ref = f"A4:D{4+len(rows)}"

for ws in wb.worksheets:
    ws.sheet_view.showGridLines = False
wb.calculation.fullCalcOnLoad = True
out = os.path.join(ROOT, "00_Program", "Taxonomy_Index.xlsx")
wb.save(out)
print("saved", out, "-", len(mods), "data domains,", r - 5, "objects,", len(rows), "code lists")
