"""Builds the Data Domain walkthrough decks (00_Program/Walkthrough/<Domain_Name>_Taxonomy_Walkthrough.pptx).

One deck per Data Domain of the wealth-manager reference model, generated from what the taxonomy already holds, so a deck
is never edited by hand and is rebuilt whenever its domain changes:
  - the content module (content/content_NN_*.py), loaded through taxonomy_builder.Consolidated exactly as the workbook
    builder loads it (shared code lists, list renames and exclusions applied), and taxonomy_builder.model() for grain,
    kind, ownership flag and row rule of every attribute;
  - the enrichment file (enrichment/enrich_NN.py): GRAIN, DERIVED, ROW_OWNERSHIP and SUMMARY;
  - domains.py (name, L1 code, disposition and the decision that rules it) and consolidation/decisions.py (the CW-
    decisions naming the domain, the ID prefix register, CW-007 and CW-011 for the books of record and certified numbers);
  - every other content module, for the references made into this domain;
  - the domain's Source_Notes.md (why it exists, design decisions, SME questions presented as tailoring levers, next steps).

Slides, in order (one layout; numbers and wording come from the inputs, nothing is typed per domain):
   1 Title                      domain, number and L1 code, disposition and its decision, the domain's own decisions
   2 At a glance                counts; why it exists; what it masters; what it references; what the wealth model changed
   3 Purpose and scope          in scope and out of scope, as listed in the module's Scope overview
   4 Where the domain sits      the four levels, followed for one attribute; the core model
   5 The families               every family with object, attribute and CDE counts
   6+ The families in detail    what each family holds, its objects and example attributes (paginated)
   . Key business objects       business objects with prefix, grain and size
   . Books of record and certified numbers   only where the domain touches CW-007 or CW-011
   . Cross-domain references    references out (by owning domain) and in (from other domains)
   . Data ownership rules       mastered, referenced and derived; derived copies; row ownership rules
   . Code lists worth knowing   the most used controlled lists, shared and local
   . Sources                    external alignment, and the US rules and forms cited by number
   . Design decisions           from Source_Notes.md (fallback: the module's design principles)
   . Tailoring levers           the SME questions with the reference default (fallback: none recorded)
   . What to decide             the domain's proposed decisions and the next steps
Each slide carries speaker notes. Free text that still names a retired wholesale concept is dropped clause by clause
(BANNED below), so a deck never repeats wholesale-era wording.

Usage (from _tools, with /usr/bin/python3; needs python-pptx):
  python build_walkthroughs.py --domain 45            one deck (repeatable: --domain 45 --domain 46)
  python build_walkthroughs.py --all                  every Data Domain the wealth model renders (domains.WEALTH_DOMAINS)
  python build_walkthroughs.py --all --check          also re-open every deck and scan its text for BANNED wording
  --out DIR                                           write the decks to DIR instead (a trial run)
"""
import importlib, math, os, re, sys

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT_DIR = os.path.join(ROOT, "00_Program", "Walkthrough")
TEMPLATE = os.path.join(HERE, "walkthrough", "template.pptx")
sys.path.insert(0, HERE)

import taxonomy_builder as tb  # noqa: E402  (adds content/ and consolidation/ to the path)
import domains as dom  # noqa: E402
import ownership as ow  # noqa: E402
dec = importlib.import_module("decisions")

from pptx import Presentation  # noqa: E402
from pptx.util import Inches, Pt, Emu  # noqa: E402
from pptx.dml.color import RGBColor  # noqa: E402
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR  # noqa: E402
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR  # noqa: E402

# ---------------------------------------------------------------------------------------------------------------------
# Palette and type (firm-neutral; Arial throughout)
# ---------------------------------------------------------------------------------------------------------------------
NAVY, INK, GREY, MUTED = "0C233C", "1A2B3C", "535E6C", "8A94A3"
BLUE, PURPLE, MAGENTA, TEAL, CYAN = "1E49E2", "7213EA", "C8166F", "00796F", "ACEAFF"
PALE, LINE, WHITE = "EEF1F8", "D5DBE7", "FFFFFF"
ACCENTS = [BLUE, PURPLE, MAGENTA, TEAL]
FONT = "Arial"
SW, SH = 13.333, 7.5          # slide size, inches
LM, CW = 0.6, 12.133          # left margin and content width
TOP = 1.95                    # top of the content area
BOTTOM = 6.85                 # bottom of the content area
DATE = "Draft, October 2026"
MODEL = "Wealth Manager Reference Model"

# Wholesale-era wording that must not appear in a wealth-model deck. Free text containing any of these is dropped by
# clause (clean()); --check scans every generated deck for them.
OLD_NAMES = ["Client & Customer", "Sales Transactions & AUM Attribution", "Distribution Agreements & Partners",
             "Distribution Compliance", "Compensation & Territory", "Investor Servicing & Shareholder Communications",
             "Distribution Finance & Profitability", "Marketing & Digital", "Private Markets"]
BANNED = re.compile(r"wholesaler|wholesale|territor|UCITS|MiFID|\bFCA\b|\bUK\b|\bEU\b|\b01 Investment Product(?! & Service)|Investment Product (?:domain|\(01\))|"
                    r"\b03 Sales\b|\bSales domain\b|" + "|".join(re.escape(n) for n in OLD_NAMES), re.I)

DISPOSITION_TEXT = {"keep": "Carried over", "adapt": "Adapted", "replace": "Replaced", "new": "New domain",
                    "retire": "Retired"}
DISPOSITION_LONG = {
    "keep": "Carried from the reference foundation with the US-only pass and the wealth-manager perspective; objects and "
            "names unchanged except where a logged decision says otherwise.",
    "adapt": "Adapted for a direct wealth manager: families added or re-cut and the boundary moved, under logged "
             "decisions; the L1 code is kept.",
    "replace": "Replaced: a new module under the same number, drafted for a direct wealth manager with advice and own "
               "funds; carried modules keep resolving to the object names it kept.",
    "new": "New in the wealth-manager reference model: a domain the direct, advice-led business needs and the "
           "foundation did not have.",
}

# CW-007 (books of record) and CW-011 (certified numbers), with the decisions that executed them
BOOK_DECISIONS = ["CW-007", "CW-101", "CW-122", "CW-125", "CW-141"]
CERT_DECISIONS = ["CW-011", "CW-129", "CW-142"]
BOOKS = [("18", "Portfolio Holding", "Fund and institutional portfolio holdings (the IBOR)"),
         ("49", "Client Holding", "Every security and cash balance in a client brokerage account, at account grain"),
         ("06", "Fund Shareholder Position", "A view of 49 for direct accounts and of intermediary and TA data for the rest"),
         ("16", "Participant Balance", "The participant book of record of recordkept plans (CW-125)"),
         ("29", "Share Register Balance", "The fund share register kept by the transfer agent (CW-122)")]
CERTIFIED = [("Client Assets", "Market value of every client account at the firm, by channel and holding type (06)"),
             ("Firm AUM", "Own funds at NAV plus managed-account and institutional assets (27, 46, 18)"),
             ("Net New Assets", "External flows by channel, defined once in 06"),
             ("Advised Assets", "Fee-based assets under advice (06)"),
             ("Households, Clients and Accounts", "Counts from the party and account masters (02, 15)"),
             ("Personal Rate of Return", "Client-level time- and money-weighted returns (32)")]
BOOK_TERMS = re.compile(r"Client Holding|Portfolio Holding|Fund Shareholder Position|Participant Balance|"
                        r"Share Register Balance|Client Tax Lot|book of record", re.I)
CERT_TERMS = re.compile(r"Client Assets|Firm AUM|Net New Assets|Advised Assets|Personal Rate of Return", re.I)


# ---------------------------------------------------------------------------------------------------------------------
# Text helpers
# ---------------------------------------------------------------------------------------------------------------------
def md(s):
    """Strips Markdown emphasis, code and links."""
    s = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", s)
    s = s.replace("**", "").replace("`", "")
    s = re.sub(r"(?<![\w*])\*(?!\s)([^*]+?)\*(?!\w)", r"\1", s)
    s = re.sub(r"(?<!\w)_([^_]+)_(?!\w)", r"\1", s)
    return re.sub(r"\s+", " ", s).strip()


def ok(s):
    return not BANNED.search(s or "")


# Program tooling named in the notes (module files, register constants, merge stages): not for a client audience
TOOLING = re.compile(r"\.py\b|proposals_|\b[A-Z]{3,}_[A-Z_]{3,}\b|\bW[0-5][ab]?\b|\bWP[0-2]\b")


def untool(s):
    """Removes parentheticals that name program tooling; returns "" when tooling is still named."""
    s = re.sub(r"\s*\([^()]*\)", lambda m: "" if TOOLING.search(m.group(0)) else m.group(0), s)
    return "" if TOOLING.search(s) else s


def destage(s):
    """Drops the program-stage tags the drafts carry, e.g. '(49, W3)' -> '(49)', '(W2)' -> ''."""
    s = re.sub(r"\s*\((?:W[0-5][ab]?|WP[0-2])\)", "", s)
    s = re.sub(r",\s*(?:future owner at |left for )?W[0-5][ab]?\)", ")", s)
    s = re.sub(r"\((?:W[0-5][ab]?),\s*", "(", s)
    return s


def cap(s):
    s = s.strip()
    if s.startswith("(") and s.endswith(")") and s.count("(") == 1:
        s = s[1:-1].strip()
    return s[:1].upper() + s[1:]


def clean(s):
    """Drops every sentence (or semicolon clause) that carries wholesale-era wording; returns the rest."""
    s = destage(md(s or ""))
    if ok(s) and not TOOLING.search(s):
        return s
    out = [sent for sent in re.split(r"(?<=[.;])\s+", s) if ok(sent) and not TOOLING.search(sent)]
    t = " ".join(out).strip()
    return (t[:-1] + ".") if t.endswith(";") else t


def trim(s, n):
    """Shortens s to at most n characters at a sentence, clause or word boundary."""
    s = s.strip()
    if len(s) <= n:
        return s
    cut = s[:n]
    for sep in (". ", "; ", ": ", ", ", " "):
        i = cut.rfind(sep)
        if i > n * 0.5:
            t = cut[:i].rstrip(" ,;:")
            return t + ("." if not t.endswith(".") else "")
    return cut.rstrip() + "."


def first_sentences(s, n):
    return trim(s, n)


def plural(k, word, words=None):
    return f"{k} {word if k == 1 else (words or word + 's')}"


def dd(n):
    return f"{n} {dom.DD_NAMES.get(n, '')}".strip()


def deck_name(n):
    words = re.sub(r"[-,]", " ", dom.DD_NAMES[n].replace("&", "and")).split()
    return "_".join(words) + "_Taxonomy_Walkthrough.pptx"


def est_lines(text, width_in, size_pt, bold=False):
    """Estimated wrapped line count of text in a box width_in inches wide (Arial averages about 0.5 em per character)."""
    cw = size_pt * (0.54 if bold else 0.5) / 72.0
    per = max(1, int(width_in / cw))
    lines = 0
    for para in str(text).split("\n"):
        words, cur, n = para.split(" "), 0, 1
        for w in words:
            L = len(w) + (1 if cur else 0)
            if cur + L > per:
                n += 1
                cur = len(w)
            else:
                cur += L
        lines += n
    return lines


def fit_size(paras, width_in, height_in, size, min_size=9, bold=False, spacing=1.18, gap_pt=4):
    """Largest font size (<= size) at which paras (list of strings) fit the box."""
    s = size
    while s > min_size:
        h = sum(est_lines(p, width_in - 0.1, s, bold) * s * spacing / 72.0 + gap_pt / 72.0 for p in paras)
        if h <= height_in - 0.08:
            return s
        s -= 0.5
    return min_size


# ---------------------------------------------------------------------------------------------------------------------
# Drawing primitives
# ---------------------------------------------------------------------------------------------------------------------
def rgb(h):
    return RGBColor.from_string(h)


def rect(slide, x, y, w, h, fill=None, line=None, rounded=False, weight=0.75):
    shp = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if rounded else MSO_SHAPE.RECTANGLE,
                                 Inches(x), Inches(y), Inches(w), Inches(h))
    if rounded:
        shp.adjustments[0] = 0.06
    if fill:
        shp.fill.solid()
        shp.fill.fore_color.rgb = rgb(fill)
    else:
        shp.fill.background()
    if line:
        shp.line.color.rgb = rgb(line)
        shp.line.width = Pt(weight)
    else:
        shp.line.fill.background()
    shp.shadow.inherit = False
    shp.text_frame.text = ""
    return shp


def line(slide, x1, y1, x2, y2, color=LINE, weight=1.0):
    c = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Inches(x1), Inches(y1), Inches(x2), Inches(y2))
    c.line.color.rgb = rgb(color)
    c.line.width = Pt(weight)
    return c


def text(slide, x, y, w, h, paras, size=14, color=INK, bold=False, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP,
         min_size=9, fit=True, spacing=1.1, gap=4, caps=False):
    """A text box. paras: a string, or a list of paragraphs; a paragraph is a string or a list of runs
    (text, {bold, color, size, italic})."""
    if isinstance(paras, str):
        paras = [paras]
    plain = ["".join(r if isinstance(r, str) else r[0] for r in (p if isinstance(p, list) else [p])) for p in paras]
    if fit:
        size = fit_size(plain, w, h, size, min_size, bold, spacing + 0.08, gap)
    tb_ = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = tb_.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = Inches(0.04)
    tf.margin_top = tf.margin_bottom = Inches(0.02)
    tf.vertical_anchor = anchor
    for i, p in enumerate(paras):
        para = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        para.alignment = align
        para.line_spacing = spacing
        if i:
            para.space_before = Pt(gap)
        runs = p if isinstance(p, list) else [p]
        for r in runs:
            t, st = (r, {}) if isinstance(r, str) else r
            if t.startswith("\n"):            # a run that starts a new line opens a new paragraph
                t = t[1:]
                para = tf.add_paragraph()
                para.alignment, para.line_spacing = align, spacing
            run = para.add_run()
            run.text = t.upper() if caps else t
            f = run.font
            f.name = FONT
            f.size = Pt(st.get("size", size))
            f.bold = st.get("bold", bold)
            f.italic = st.get("italic", False)
            f.color.rgb = rgb(st.get("color", color))
    return tb_


def table(slide, x, y, w, widths, header, rows, size=11, head_size=11, row_heights=None, first_bold=True):
    """A plain table: navy header row, hairline rows, first column bold."""
    nr, nc = len(rows) + 1, len(header)
    total = sum(widths)
    widths = [w * c / total for c in widths]
    hs = [0.38] + (row_heights or [0.5] * len(rows))
    shp = slide.shapes.add_table(nr, nc, Inches(x), Inches(y), Inches(w), Inches(sum(hs)))
    t = shp.table
    t.first_row = True
    t.horz_banding = False
    for j, cw_ in enumerate(widths):
        t.columns[j].width = Inches(cw_)
    for i, h in enumerate(hs):
        t.rows[i].height = Inches(h)
    for i in range(nr):
        for j in range(nc):
            c = t.cell(i, j)
            c.margin_left = c.margin_right = Inches(0.08)
            c.margin_top = c.margin_bottom = Inches(0.04)
            c.vertical_anchor = MSO_ANCHOR.TOP if i else MSO_ANCHOR.MIDDLE
            c.fill.solid()
            c.fill.fore_color.rgb = rgb(NAVY if i == 0 else (WHITE if i % 2 else PALE))
            val = header[j] if i == 0 else rows[i - 1][j]
            tf = c.text_frame
            tf.word_wrap = True
            runs = val if isinstance(val, list) else [(str(val), {})]
            p = tf.paragraphs[0]
            for r in runs:
                t_, st = (r, {}) if isinstance(r, str) else r
                if t_.startswith("\n"):
                    t_ = t_[1:]
                    p = tf.add_paragraph()
                run = p.add_run()
                run.text = t_
                f = run.font
                f.name = FONT
                f.size = Pt(head_size if i == 0 else st.get("size", size))
                f.bold = True if i == 0 else st.get("bold", first_bold and j == 0)
                f.color.rgb = rgb(WHITE if i == 0 else st.get("color", INK))
    return shp


def row_height(cells, widths_in, size):
    """Estimated height of a table row whose cells are strings (or run lists) in columns widths_in wide."""
    best = 1
    for c, w in zip(cells, widths_in):
        s = c if isinstance(c, str) else "".join(r if isinstance(r, str) else r[0] for r in c)
        best = max(best, est_lines(s, w - 0.18, size))
    return 0.1 + best * size * 1.2 / 72.0


def paginate(rows, widths_in, size, avail):
    """Splits rows into pages whose estimated heights fit avail inches (below a 0.38-inch header)."""
    pages, cur, h = [], [], 0.38
    for r in rows:
        rh = row_height(r, widths_in, size)
        if cur and h + rh > avail:
            pages.append(cur)
            cur, h = [], 0.38
        cur.append((r, rh))
        h += rh
    if cur:
        pages.append(cur)
    return pages


# ---------------------------------------------------------------------------------------------------------------------
# Deck scaffolding
# ---------------------------------------------------------------------------------------------------------------------
class Deck:
    def __init__(self, n, name):
        self.n, self.name = n, name
        # The template is an empty 16:9 deck with one blank layout, an Arial theme and a notes master that Quick Look
        # and PowerPoint both open (python-pptx's default notes master stalls the macOS Quick Look renderer).
        self.prs = Presentation(TEMPLATE) if os.path.exists(TEMPLATE) else Presentation()
        self.prs.slide_width, self.prs.slide_height = Inches(SW), Inches(SH)
        self.blank = next((l for l in self.prs.slide_layouts if l.name == "DEFAULT"), self.prs.slide_layouts[-1])
        cp = self.prs.core_properties
        cp.title, cp.subject = f"The {name} taxonomy: a walkthrough", f"{MODEL}, Data Domain {n}"
        cp.author = cp.last_modified_by = MODEL
        cp.keywords, cp.comments, cp.category = "data taxonomy; walkthrough", "Generated by build_walkthroughs.py", ""

    def slide(self, kicker, title, notes, dark=False):
        s = self.prs.slides.add_slide(self.blank)
        bg = s.background.fill
        bg.solid()
        bg.fore_color.rgb = rgb(NAVY if dark else WHITE)
        k = len(self.prs.slides)
        if not dark:
            rect(s, 0, 0, SW, 0.09, fill=BLUE)
            text(s, LM, 0.42, 10.0, 0.32, kicker, size=12, bold=True, color=BLUE, fit=False, caps=True)
            text(s, LM, 0.78, CW, 0.95, title, size=30, bold=True, color=NAVY, min_size=22, anchor=MSO_ANCHOR.TOP)
            text(s, LM, 7.0, 9.5, 0.3, f"{self.name} taxonomy walkthrough  |  {MODEL}  |  {DATE}", size=10,
                 color=MUTED, fit=False)
            text(s, SW - LM - 0.6, 7.0, 0.6, 0.3, str(k), size=10, color=MUTED, fit=False, align=PP_ALIGN.RIGHT)
        s.notes_slide.notes_text_frame.text = notes
        return s

    def save(self, path):
        self.prs.save(path)


# ---------------------------------------------------------------------------------------------------------------------
# Inputs
# ---------------------------------------------------------------------------------------------------------------------
_SCL = None
_ALL = {}


def module_name(n):
    for f in sorted(os.listdir(os.path.join(HERE, "content"))):
        if f.startswith(f"content_{n}_") and f.endswith(".py"):
            return f[:-3]
    return None


def load(n):
    """(Consolidated module, families from taxonomy_builder.model) for Data Domain n."""
    global _SCL
    if n in _ALL:
        return _ALL[n]
    if _SCL is None:
        _SCL = tb.load_consolidation()
    name = module_name(n)
    if not name:
        return None
    c = tb.Consolidated(importlib.import_module(name), _SCL)
    _ALL[n] = (c, tb.model(c))
    return _ALL[n]


def inbound(n):
    """References made into Data Domain n by every other live domain: [(from_domain, object, attribute, target)]."""
    out = []
    for m in dom.WEALTH_DOMAINS:
        if m == n or not module_name(m):
            continue
        _, fams = load(m)
        for f in fams:
            for o in f["objects"]:
                for x in o["attrs"]:
                    if x["owner"] == n and x["flag"] in ("Reference", "Derived copy"):
                        out.append((m, o["name"], x["a"][0], ref_target(x["a"][3]) if x["flag"] == "Reference"
                                    else x["a"][0], x["flag"]))
    return out


def ref_target(dtype):
    t = re.sub(r"^Reference\s*\(?|\)?\s*(\(multi\))?$", "", dtype).strip()
    return re.sub(r",\s*\d\d$", "", t).strip() or "record"


def notes_sections(n):
    """Source_Notes.md of Data Domain n as {kind: [items]} (kinds: why, design, deviations, levers, next, carry)."""
    path = os.path.join(ROOT, dom.folder(n), "Source_Notes.md")
    if not os.path.exists(path):
        return {}
    secs, cur, kind = {}, [], None
    lines = open(path, encoding="utf-8").read().splitlines()

    def classify(h):
        h = h.lower()
        if "why this domain" in h:
            return "why"
        if "deviation" in h:
            return "deviations"
        if "wholesale" in h or "review" in h or "jurisdiction" in h or "consolidation" in h and "overlap" not in h:
            return None
        if "carry-over" in h or "adaptation" in h:
            return "carry"
        if "design" in h or "modeling decision" in h or "modelling decision" in h:
            return "design"
        if "sme" in h or "open question" in h:
            return "levers"
        if "validation step" in h or "next step" in h:
            return "next"
        return None

    for ln in lines:
        m = re.match(r"^(#{2,3})\s+(.*)", ln)
        if m:
            k = classify(m.group(2))
            if m.group(1) == "##" or k is not None:
                if kind:
                    secs.setdefault(kind, []).extend(cur)
                kind, cur = k, []
            continue
        if kind:
            cur.append(ln)
    if kind:
        secs.setdefault(kind, []).extend(cur)
    return {k: items(v, k) for k, v in secs.items()}


def items(lines, kind):
    """Bullet or numbered items of a section (continuation lines joined); for 'why', its paragraphs."""
    out, cur = [], None
    for ln in lines:
        if re.match(r"^\s*(?:[-*]|\d+[.)])\s+", ln) and not ln.startswith("    "):
            if cur:
                out.append(cur)
            cur = re.sub(r"^\s*(?:[-*]|\d+[.)])\s+", "", ln)
        elif ln.strip() == "" or ln.startswith("|"):
            if cur:
                out.append(cur)
            cur = None
            if kind == "why" and ln.strip() == "":
                continue
        elif cur is not None:
            cur += " " + ln.strip()
        elif kind == "why":
            out.append(ln.strip())
    if cur:
        out.append(cur)
    return [x for x in out if x.strip()]


def lead_and_body(item):
    """Splits '**Lead.** body' into (lead, body); without a bold lead, the first sentence is the lead."""
    m = re.match(r"^\*\*(.+?)\*\*[:.]?\s*(.*)$", item)
    if m:
        return md(m.group(1)).rstrip(".:"), md(m.group(2))
    s = md(item)
    m = re.match(r"^(.{10,90}?[.:])\s+(.*)$", s)
    return (m.group(1).rstrip(".:"), m.group(2)) if m else (trim(s, 80).rstrip("."), "")


def lever(item):
    """(question, reference default and lever) from one SME question."""
    s = md(item)
    s = re.sub(r"^\(Added\)\s*", "", s)
    i = s.find("?")
    if 0 < i < len(s) - 1:
        q, rest = s[:i + 1], s[i + 1:].strip()
    elif i > 0:
        q, rest = s, ""
    else:
        q, rest = s, ""
    rest = rest.strip(" []")
    rest = re.sub(r"\]\s*", ". ", rest).replace("[", "")
    rest = re.sub(r"^Default:\s*", "", rest)
    rest = re.sub(r"\s*Lever:\s*", " Lever: ", rest).strip()
    rest = re.sub(r";\s*lever:\s*", ". Lever: ", rest, flags=re.I)
    return q, rest


def numbered(text_):
    """Items of a '1) ... 2) ...' paragraph."""
    parts = re.split(r"\s*\d{1,2}\)\s+", " " + text_)
    return [p.strip() for p in parts if p.strip()]


def scope_split(scope):
    """(in-scope items, out-of-scope items) from the module's Scope overview text."""
    i = scope.find("Out of scope")
    ins, outs = scope[:i] if i >= 0 else scope, scope[i:] if i >= 0 else ""
    ins = re.sub(r"^In scope[^:]*:\s*", "", ins).strip()
    outs = re.sub(r"^Out of scope[^:]*:\s*", "", outs).strip()

    def split(s):
        s = s.rstrip(". ")
        parts, depth, cur = [], 0, ""
        for ch in s:
            depth += ch == "("
            depth -= ch == ")"
            if ch == ";" and depth == 0:
                parts.append(cur.strip())
                cur = ""
            else:
                cur += ch
        if cur.strip():
            parts.append(cur.strip())
        if len(parts) == 1 and len(parts[0]) > 120:      # a comma-separated list
            parts, depth, cur = [], 0, ""
            for ch in s:
                depth += ch == "("
                depth -= ch == ")"
                if ch == "," and depth == 0:
                    parts.append(cur.strip())
                    cur = ""
                else:
                    cur += ch
            parts.append(cur.strip())
            parts = [re.sub(r"^and\s+", "", x) for x in parts if x.strip()]
        return [p[0].upper() + p[1:] for p in (clean(x) for x in parts) if p]
    return split(ins), split(outs)


def prefix_of(o):
    """The ID prefix of a business object, read from its identifier attribute's example."""
    for x in o["attrs"]:
        a = x["a"]
        if x["flag"] == "Mastered here" and (a[3] == "Identifier" or a[0].endswith(" ID")):
            m = re.match(r"^([A-Z]{2,7}(?:-[A-Z]{2,4})?)-", str(a[5]))
            if m:
                p = m.group(1)
                if p.split("-")[0] in ow.PREFIX_OWNER or p in ow.PREFIX_OWNER:
                    return (p.split("-")[0] if p.split("-")[0] in ow.PREFIX_OWNER else p) + "-"
                return p + "-"
    return ""


RULE_LABEL = re.compile(r"(Rule|CFR|IRC|§|Form|Section|Reg(ulation)?\s|PTE|Act|ERISA|UCC|Release|Notice|FINRA|SEC|IRS|"
                        r"MSRB|DOL|NACHA|OCC|FDIC|Treas|ISO|IETF|ANSI|FIPS|OMB|X9|ASC|GAAP|NIST)", re.I)


def is_internal(ref):
    r = (ref or "").strip().lower()
    return not r or r.startswith("internal") or r in ("firm-defined", "n/a")


# ---------------------------------------------------------------------------------------------------------------------
# The deck
# ---------------------------------------------------------------------------------------------------------------------
def build(n, report=None):
    loaded = load(n)
    if not loaded:
        raise SystemExit(f"no content module for Data Domain {n}")
    c, fams = loaded
    enr = c.enr
    name, code = dom.DD_NAMES[n], dom.L1_CODE[n]
    disp = dom.DISPOSITION[n][0]
    ruling = dom.DISPOSITION_DECISION[n]
    ov = dict(c.META["overview"])
    S = getattr(enr, "SUMMARY", {}) if enr else {}
    notes = notes_sections(n)
    thin = []
    cw = [d for d in dec.DECISIONS if d["id"].startswith("CW-") and n in d["domains"]]
    own = [d for d in cw if d["domains"][0] == n]
    D = Deck(n, name)

    objs = [o for f in fams for o in f["objects"]]
    bos = [o for o in objs if o["kind"] != "Attribute Group"]
    attrs = [x for o in objs for x in o["attrs"]]
    cdes = [x for x in attrs if x["a"][8] == "Y"]
    refs = [x for x in attrs if x["flag"] == "Reference"]
    ders = [x for x in attrs if x["flag"] == "Derived copy"]
    mastered = [x for x in attrs if x["flag"] == "Mastered here"]
    rules = [(o, x) for o in objs for x in o["attrs"] if x["row_rule"]]

    # -- 1 Title --------------------------------------------------------------------------------------------------
    own_ids = [d["id"] for d in own]
    s = D.slide("", "", (
        f"This deck walks through Data Domain {n}, {name}, of the wealth-manager reference model: a hypothetical US "
        f"wealth manager that serves investors directly, gives advice and manufactures the funds it recommends. "
        f"Disposition: {DISPOSITION_TEXT[disp].lower()}, ruled by {ruling}. Every count is taken from the current draft "
        f"of the taxonomy when the deck was generated; client questions are presented as tailoring levers with the "
        f"reference default."), dark=True)
    text(s, LM, 1.45, 7.4, 0.35, f"DATA DOMAIN {n}  |  L1 {code}  |  {DISPOSITION_TEXT[disp].upper()}", size=12,
         bold=True, color=CYAN, fit=False)
    text(s, LM, 1.9, 7.4, 2.2, f"The {name} taxonomy: a walkthrough", size=40, bold=True, color=WHITE, min_size=28)
    text(s, LM, 4.25, 7.0, 0.9, "What the domain masters, what it borrows, the rules that keep it single-sourced, and "
         "the choices a firm makes when it adopts it", size=17, color=WHITE)
    dl = f"Ruled by {ruling}"
    if own_ids:
        dl += f"  |  The domain's own decisions: {compress_ids(own_ids, 9)}"
    text(s, LM, 5.35, 7.4, 0.6, dl, size=12, color=CYAN)
    text(s, LM, 6.55, 9.0, 0.3, f"{MODEL}  |  {DATE}  |  Counts are taken from the current drafts", size=11,
         color=CYAN, fit=False)
    top = sorted(bos, key=lambda o: (-sum(x["a"][8] == "Y" for x in o["attrs"]), objs.index(o)))[:3]
    top = sorted(top, key=objs.index)
    for i, o in enumerate(top):
        y = 1.55 + i * 1.5
        rect(s, 8.75, y, 3.95, 1.05, fill=ACCENTS[i], rounded=True)
        text(s, 9.0, y + 0.13, 3.5, 0.42, o["name"], size=18, bold=True, color=WHITE, min_size=13)
        g = f"One row per {grain_text(o['grain'])}" if o["grain"] else "Business object"
        text(s, 9.0, y + 0.55, 3.5, 0.45, trim(g, 70), size=12, color=WHITE, min_size=10)
        if i < len(top) - 1:
            line(s, 10.72, y + 1.05, 10.72, y + 1.5, color=CYAN, weight=1.25)

    # -- 2 At a glance ----------------------------------------------------------------------------------------------
    why = notes.get("why", [])
    why_t = clean(" ".join(why[:1])) if why else ""
    if not why_t:
        why_t = clean(ov.get("Purpose", ""))
        thin.append("why (from the module's Purpose)") if not why else None
    s = D.slide("At a glance", f"{name}: one owner for each fact", (
        f"The short version. {name} has {plural(len(fams), 'data family', 'data families')}, "
        f"{plural(len(objs), 'object')} ({len(bos)} business objects and {len(objs) - len(bos)} attribute groups) and "
        f"{len(attrs)} attributes, {len(cdes)} of them proposed critical data elements. {clean(S.get('masters', ''))} "
        f"{clean(S.get('references', ''))}"))
    rect(s, LM, TOP, 2.75, 4.75, fill=PALE, rounded=True)
    for i, (v, lab) in enumerate([(len(fams), "data families"), (len(objs), "objects"), (len(attrs), "attributes"),
                                  (len(cdes), "proposed critical data elements")]):
        y = TOP + 0.2 + i * 1.12
        text(s, LM + 0.3, y, 2.3, 0.6, str(v), size=34, bold=True, color=BLUE, fit=False)
        text(s, LM + 0.3, y + 0.6, 2.3, 0.4, lab, size=12, color=GREY, fit=False)
    cards = [("Why it exists", why_t),
             ("What it masters", clean(S.get("masters", "")) or clean(ov.get("Purpose", ""))),
             ("What it references", clean(S.get("references", ""))),
             ("What the wealth model did", DISPOSITION_LONG[disp] + f" Ruled by {ruling}.")]
    for i, (h, body) in enumerate(cards):
        x, y = LM + 3.05 + (i % 2) * 4.6, TOP + (i // 2) * 2.45
        rect(s, x, y, 4.45, 2.3, fill=WHITE, line=LINE, rounded=True)
        text(s, x + 0.2, y + 0.15, 0.45, 0.4, str(i + 1), size=14, bold=True, color=ACCENTS[i], fit=False)
        text(s, x + 0.6, y + 0.12, 3.7, 0.4, h, size=15, bold=True, color=NAVY, fit=False)
        text(s, x + 0.2, y + 0.58, 4.05, 1.65, trim(body, 420), size=12, color=INK, min_size=9)

    # -- 3 Purpose and scope ----------------------------------------------------------------------------------------
    ins, outs = scope_split(ov.get("Scope", ""))
    purpose = trim(clean(ov.get("Purpose", "")), 330)
    s = D.slide("Purpose and scope", "What is in the domain, and what it leaves to others", (
        f"Purpose: {clean(ov.get('Purpose', ''))} The scope lists {len(ins)} subjects in scope and {len(outs)} out of "
        f"scope; each excluded subject is referenced by ID from the domain that masters it, never copied except as a "
        f"declared derived copy."))
    text(s, LM, TOP - 0.15, CW, 0.75, purpose, size=13, color=GREY, min_size=10)
    for j, (h, lst, col) in enumerate([("In scope", ins, BLUE), ("Out of scope (referenced by ID)", outs, MAGENTA)]):
        x = LM + j * 6.15
        rect(s, x, TOP + 0.7, 5.95, 0.42, fill=col)
        text(s, x + 0.15, TOP + 0.74, 5.6, 0.34, h, size=13, bold=True, color=WHITE, fit=False)
        shown = [trim(t, 150) for t in lst[:9]]
        more = len(lst) - len(shown)
        paras = [[("•  ", {"color": col, "bold": True}), (t, {})] for t in shown]
        if more > 0:
            paras.append([(f"and {more} more in the workbook's Overview tab", {"italic": True, "color": GREY})])
        text(s, x + 0.05, TOP + 1.22, 5.85, BOTTOM - TOP - 1.25, paras, size=12, min_size=8.5, gap=3)
    if not ins:
        thin.append("scope")

    # -- 4 Where the domain sits ------------------------------------------------------------------------------------
    path_o = next((o for o in bos if any(x["a"][8] == "Y" and x["flag"] == "Mastered here" and
                                         not x["a"][0].endswith(" ID") for x in o["attrs"])), objs[0])
    path_f = next(f for f in fams if path_o in f["objects"])
    path_a = next((x for x in path_o["attrs"] if x["a"][8] == "Y" and x["flag"] == "Mastered here" and
                   not x["a"][0].endswith(" ID")), path_o["attrs"][0])
    nlive = len(dom.WEALTH_DOMAINS)
    s = D.slide("Context  |  Where the domain sits", f"One of {nlive} data domains, four levels deep", (
        f"The taxonomy has four levels: data domain, data family, business object and attribute. {name} is one of "
        f"{nlive} domains of the wealth-manager reference model. The highlighted path follows one attribute, "
        f"{path_a['a'][0]}, on {path_o['name']} in the {path_f['name']} family: {clean(path_a['a'][1])} "
        f"Core model: {clean(ov.get('Core model', ''))}"))
    levels = [("L1", "Data Domain", f"1 of {nlive}", name), ("L2", "Data Family", plural(len(fams), "family", "families"),
              path_f["name"]), ("L3", "Business Object", plural(len(objs), "object"), path_o["name"]),
              ("L4", "Attribute", plural(len(attrs), "attribute"), path_a["a"][0])]
    for i, (lv, lab, cnt, ex) in enumerate(levels):
        y = TOP + i * 1.12
        x = LM + i * 0.35
        rect(s, x, y, 5.6 - i * 0.35, 0.95, fill=PALE, rounded=True)
        text(s, x + 0.15, y + 0.12, 0.7, 0.7, lv, size=22, bold=True, color=BLUE, fit=False)
        text(s, x + 0.95, y + 0.1, 2.2, 0.35, lab, size=13, bold=True, color=NAVY, fit=False)
        text(s, x + 0.95, y + 0.5, 2.2, 0.35, cnt, size=11, color=GREY, fit=False)
        text(s, x + 3.1, y + 0.12, 2.4 - i * 0.35, 0.75, ex, size=13, bold=True, color=PURPLE, min_size=9,
             anchor=MSO_ANCHOR.MIDDLE)
    text(s, LM, TOP + 4.5, 5.6, 0.35, "Purple text: the path to one proposed critical data element", size=11,
         color=PURPLE, fit=False)
    x2 = LM + 6.1
    text(s, x2, TOP, 6.0, 0.35, "THE CORE MODEL", size=12, bold=True, color=BLUE, fit=False)
    text(s, x2, TOP + 0.4, 6.0, 2.35, trim(clean(ov.get("Core model", "")), 620), size=12, color=INK, min_size=9)
    text(s, x2, TOP + 2.9, 6.0, 0.35, "FOR EVERY ATTRIBUTE, IT RECORDS", size=12, bold=True, color=BLUE, fit=False)
    text(s, x2, TOP + 3.3, 6.0, 1.6, [
        "One definition, with an example value", "The data type and, where coded, the controlled code list",
        "The standard, rule or source it aligns to", "Whether it is a proposed critical data element and its PII tier",
        "Whether it is mastered here, a reference to another domain or a derived copy"],
        size=12, color=INK, min_size=10, gap=2)

    # -- 5 The families ---------------------------------------------------------------------------------------------
    s = D.slide(f"What is included  |  The {len(fams)} families", f"{plural(len(fams), 'family', 'families').capitalize()}"
                f" under the domain", (
        f"The domain has {plural(len(fams), 'data family', 'data families')}. "
        + " ".join(f"{f['name']}: {len(f['objects'])} objects, {sum(len(o['attrs']) for o in f['objects'])} attributes."
                   for f in fams)))
    ncol = 3 if len(fams) > 4 else 2
    rows_ = math.ceil(len(fams) / ncol)
    gw = (CW - (ncol - 1) * 0.2) / ncol
    gh = min(1.6, (BOTTOM - TOP - (rows_ - 1) * 0.15) / rows_)
    for i, f in enumerate(fams):
        x, y = LM + (i % ncol) * (gw + 0.2), TOP + (i // ncol) * (gh + 0.15)
        na = sum(len(o["attrs"]) for o in f["objects"])
        nc = sum(x_["a"][8] == "Y" for o in f["objects"] for x_ in o["attrs"])
        rect(s, x, y, gw, gh, fill=PALE, rounded=True)
        rect(s, x, y + 0.12, 0.07, gh - 0.24, fill=ACCENTS[i % 4])
        text(s, x + 0.2, y + 0.08, gw - 0.3, 0.38, f["name"], size=14, bold=True, color=NAVY, min_size=10)
        text(s, x + 0.2, y + 0.45, gw - 0.3, 0.28, f"{f['code']}  |  {len(f['objects'])} objects  |  {na} attributes  "
             f"|  {nc} critical", size=10.5, color=BLUE, bold=True, fit=False)
        if gh > 1.0:
            text(s, x + 0.2, y + 0.75, gw - 0.3, gh - 0.82, trim(clean(f["def"]), 210), size=10.5, color=GREY,
                 min_size=8)

    # -- 6+ Families in detail --------------------------------------------------------------------------------------
    widths = [2.6, 3.7, 3.0, 2.833]
    rows = []
    for f in fams:
        na = sum(len(o["attrs"]) for o in f["objects"])
        ob = [(o["name"] + (" (group)" if o["kind"] == "Attribute Group" else "")) for o in f["objects"]]
        ex = []
        for o in f["objects"]:
            for x in o["attrs"]:
                if x["a"][8] == "Y" and x["flag"] == "Mastered here" and not x["a"][0].endswith(" ID") and ok(x["a"][0]):
                    ex.append(x["a"][0])
                    break
        ex = ex[:5]
        rows.append([[(f["name"], {"bold": True}), (f"\n{len(f['objects'])} objects  |  {na} attributes",
                                                     {"bold": False, "color": GREY, "size": 9.5})],
                     trim(clean(f["def"]), 260), ", ".join(ob), ", ".join(ex)])
    pages = paginate(rows, [CW * w / sum(widths) for w in widths], 10.5, BOTTOM - TOP - 0.45)
    for pi, pg in enumerate(pages):
        lab = f"Group {pi + 1} of {len(pages)}" if len(pages) > 1 else "In detail"
        s = D.slide(f"What is included  |  {lab}", "The families in detail" + (f" ({pi + 1} of {len(pages)})"
                    if len(pages) > 1 else ""), " ".join(
            f"{r[0][0][0]}: {r[1]} Objects: {r[2]}." for r, _ in pg))
        table(s, LM, TOP, CW, widths, ["Family", "What it holds", "Objects", "Example critical attributes"],
              [r for r, _ in pg], size=10.5, row_heights=[h for _, h in pg])
        text(s, LM, BOTTOM - 0.3, CW, 0.3, "(group) = attribute group held on its parent object; every other object is "
             "a business object with its own key.", size=10, color=GREY, fit=False)

    # -- Key business objects ---------------------------------------------------------------------------------------
    key = sorted(bos, key=lambda o: (-sum(x["a"][8] == "Y" for x in o["attrs"]), objs.index(o)))
    shown = sorted(key[:9], key=objs.index)
    widths = [3.0, 1.35, 5.6, 2.2]
    rows = [[o["name"], prefix_of(o) or "composite key", grain_text(o["grain"]) or "not stated",
             f"{len(o['attrs'])} attributes, {sum(x['a'][8] == 'Y' for x in o['attrs'])} critical"] for o in shown]
    pg = paginate(rows, [CW * w / sum(widths) for w in widths], 11, BOTTOM - TOP - 0.4)[0]
    s = D.slide("Key business objects", "The records the domain keys, and what one row is", (
        f"{len(bos)} business objects carry their own key; {len(objs) - len(bos)} attribute groups hang off a parent. "
        f"The table shows the {len(pg)} business objects with the most proposed critical data elements, in model order. "
        + " ".join(f"{r[0]} ({r[1]}): " + (f"one row per {r[2]}." if r[2] != "not stated" else "grain not stated.")
                   for r, _ in pg)))
    table(s, LM, TOP, CW, widths, ["Business object", "Prefix", "Grain: one row per", "Size"], [r for r, _ in pg],
          size=11, row_heights=[h for _, h in pg])
    more = len(bos) - len(pg)
    text(s, LM, BOTTOM - 0.3, CW, 0.3, (f"{more} further business objects are listed in the workbook's Hierarchy tab. "
         if more > 0 else "") + "Prefixes are registered once for the model; a prefix is never reused.", size=10,
         color=GREY, fit=False)

    # -- Books of record and certified numbers (conditional) --------------------------------------------------------
    book_dec = [d for d in dec.DECISIONS if d["id"] in BOOK_DECISIONS + CERT_DECISIONS and n in d["domains"]]
    touch = [(o, x) for o in objs for x in o["attrs"] if BOOK_TERMS.search(x["a"][0] + " " + x["a"][1] + " " + x["a"][3])
             or CERT_TERMS.search(x["a"][0] + " " + x["a"][1])]
    if book_dec or len(touch) >= 2:
        s = book_slide(D, n, name, book_dec, touch)

    # -- Cross-domain references ------------------------------------------------------------------------------------
    by_owner = {}
    for o in objs:
        for x in o["attrs"]:
            if x["flag"] == "Reference":
                by_owner.setdefault(x["owner"], []).append(ref_target(x["a"][3]))
    inb = inbound(n)
    by_from = {}
    for m, oname, aname, tgt, flag in inb:
        by_from.setdefault(m, []).append((tgt, flag))
    s = D.slide("Cross-domain references", f"{len(refs)} references out, {len(inb)} in", (
        f"Out: {len(refs)} attributes of {name} hold the ID of a record mastered in {len(by_owner)} other domains, "
        f"and {len(ders)} hold a declared derived copy. In: {len(inb)} attributes in {len(by_from)} other domains "
        f"reference or copy a record mastered here. "
        + " ".join(f"{dd(k)}: {len(v)}." for k, v in sorted(by_owner.items(), key=lambda kv: -len(kv[1]))[:8])))
    for j, (h, data, col) in enumerate([("REFERENCES OUT: WHAT IT BORROWS", by_owner, BLUE),
                                        ("REFERENCES IN: WHO RELIES ON IT", by_from, PURPLE)]):
        x = LM + j * 6.15
        text(s, x, TOP - 0.1, 5.9, 0.35, h, size=12, bold=True, color=col, fit=False)
        ranked = sorted(data.items(), key=lambda kv: (-len(kv[1]), kv[0]))
        top8 = ranked[:7]
        tot = sum(len(v) for v in data.values()) or 1
        for i, (k, v) in enumerate(top8):
            y = TOP + 0.33 + i * 0.56
            names = [t[0] if isinstance(t, tuple) else t for t in v]
            freq = {}
            for t in names:
                if ok(t):
                    freq[t] = freq.get(t, 0) + 1
            main = ", ".join(t for t, _ in sorted(freq.items(), key=lambda kv: -kv[1])[:4])
            bw = max(0.12, 1.3 * len(v) / max(len(vv) for _, vv in top8))
            rect(s, x, y + 0.08, bw, 0.36, fill=col)
            text(s, x + bw + 0.08, y + 0.05, 0.6, 0.4, str(len(v)), size=13, bold=True, color=col, fit=False)
            text(s, x + 2.05, y, 3.85, 0.25, dd(k), size=11, bold=True, color=NAVY, min_size=8.5)
            text(s, x + 2.05, y + 0.25, 3.85, 0.3, main, size=9.5, color=GREY, min_size=7.5)
        if not top8:
            text(s, x, TOP + 0.4, 5.9, 0.6, "None recorded.", size=12, color=GREY)
        rest = ranked[7:]
        if rest:
            text(s, x, TOP + 0.33 + 7 * 0.56, 5.9, 0.3, f"and {sum(len(v) for _, v in rest)} more from "
                 f"{plural(len(rest), 'other domain')}", size=10.5, color=GREY, fit=False)
    text(s, LM, BOTTOM - 0.3, CW, 0.3, "Counts are attributes. A reference holds only the ID of a record mastered "
         "elsewhere; a derived copy holds a copied value, read-only here.", size=10, color=GREY, fit=False)

    # -- Data ownership rules ---------------------------------------------------------------------------------------
    s = D.slide("Data ownership rules", f"{len(mastered)} attributes mastered here, {len(refs) + len(ders)} borrowed", (
        f"Every attribute carries one ownership flag. {len(mastered)} of {len(attrs)} are mastered in {name}; "
        f"{len(refs)} are references and {len(ders)} are derived copies, display-only values mastered elsewhere and "
        f"never edited here. {len(rules)} attributes carry a row ownership rule: one attribute whose rows are mastered "
        f"in different domains, with the rule saying which rows are which."))
    rect(s, LM, TOP, 3.4, 4.6, fill=PALE, rounded=True)
    for i, (v, lab, col) in enumerate([(len(mastered), "mastered here", BLUE), (len(refs), "references", PURPLE),
                                       (len(ders), "derived copies", MAGENTA), (len(rules), "row ownership rules", TEAL)]):
        y = TOP + 0.2 + i * 1.08
        text(s, LM + 0.3, y, 2.9, 0.6, str(v), size=30, bold=True, color=col, fit=False)
        text(s, LM + 0.3, y + 0.58, 2.9, 0.35, lab, size=12, color=GREY, fit=False)
    x2 = LM + 3.7
    text(s, x2, TOP - 0.1, 8.4, 0.35, "DERIVED COPIES: VALUES SHOWN HERE, MASTERED ELSEWHERE", size=12, bold=True,
         color=MAGENTA, fit=False)
    dg = {}
    for o in objs:
        for x in o["attrs"]:
            if x["flag"] == "Derived copy" and ok(x["a"][0]):
                dg.setdefault(x["owner"], []).append(f"{x['a'][0]} ({o['name']})")
    paras = [[(dd(k) + ": ", {"bold": True, "color": NAVY}), (", ".join(v[:5]) + (f", and {len(v) - 5} more"
              if len(v) > 5 else ""), {})] for k, v in sorted(dg.items(), key=lambda kv: -len(kv[1]))[:6]]
    text(s, x2, TOP + 0.3, 8.4, 1.85, paras or ["None: every value here is either mastered here or held by reference."],
         size=11, color=INK, min_size=8.5, gap=3)
    text(s, x2, TOP + 2.3, 8.4, 0.35, "ROW OWNERSHIP RULES", size=12, bold=True, color=TEAL, fit=False)
    rr = []
    for o, x in rules:
        t = clean(re.sub(r"^Row rule(?: \([^)]*\))?:\s*", "", x["row_rule"]))
        if t:
            rr.append([(f"{o['name']}.{x['a'][0]}: ", {"bold": True, "color": NAVY}), (trim(t, 190), {})])
    text(s, x2, TOP + 2.7, 8.4, 1.95, rr[:4] or ["None: each attribute's rows all have one owner."], size=11,
         color=INK, min_size=8.5, gap=3)
    if len(rr) > 4:
        text(s, x2, TOP + 4.65, 8.4, 0.3, f"and {len(rr) - 4} more in the workbook's Taxonomy tab (Row Ownership Rule)",
             size=10, color=GREY, fit=False)

    # -- Code lists worth knowing -----------------------------------------------------------------------------------
    use = {}
    for x in attrs:
        cl = x["a"][4]
        if cl and cl in c.CL:
            u = use.setdefault(cl, [0, 0])
            u[0] += 1
            u[1] += x["a"][8] == "Y"
    ranked = sorted(use, key=lambda k: (-use[k][1], -use[k][0], k))
    shared = [k for k in c.CL if k.startswith("Shared: ")]
    pick = []
    for k in ranked:
        vals = [v for v, _ in c.CL[k][1] if ok(str(v))]
        if not ok(k) or len(vals) < 2:
            continue
        pick.append((k, vals))
        if len(pick) == 8:
            break
    widths = [3.1, 1.2, 1.4, 6.4]
    rows = [[k.replace("Shared: ", "") + (" (shared)" if k.startswith("Shared: ") else ""),
             str(len(c.CL[k][1])), f"{use[k][0]} ({use[k][1]} CDE)" if use[k][1] else str(use[k][0]),
             trim(", ".join(str(v) for v in vals[:8]) + (", ..." if len(vals) > 8 else ""), 210)] for k, vals in pick]
    pg = paginate(rows, [CW * w / sum(widths) for w in widths], 10.5, BOTTOM - TOP - 0.45)[0] if rows else []
    s = D.slide("Code lists worth knowing", f"{len(c.CL)} controlled lists, {len(shared)} of them shared", (
        f"{len(c.CL)} code lists govern the coded attributes of {name}; {len(shared)} are enterprise shared lists "
        f"stewarded once for the model and cited as 'Shared: <name>'. The table shows the lists that the most critical "
        f"data elements use. Values are the reference defaults; a firm replaces them with its own values, which is a "
        f"tailoring lever. " + " ".join(f"{r[0]}: {r[1]} values." for r, _ in pg)))
    if pg:
        table(s, LM, TOP, CW, widths, ["Code list", "Values", "Used by", "Values, for example"], [r for r, _ in pg],
              size=10.5, row_heights=[h for _, h in pg])
    else:
        text(s, LM, TOP, CW, 0.5, "No controlled code lists: every coded attribute uses an external format.", size=13)
        thin.append("code lists")
    text(s, LM, BOTTOM - 0.3, CW, 0.3, "Used by = attributes that take their values from the list. Shared lists are "
         "stewarded in the 09 code list registry.", size=10, color=GREY, fit=False)

    # -- Sources ----------------------------------------------------------------------------------------------------
    ext = [x for x in attrs if not is_internal(x["a"][6])]
    cnt = {}
    for x in attrs:
        for ref in (x["a"][6], x["a"][7]):
            ref = (ref or "").strip()
            if ref and not is_internal(ref) and ok(ref) and RULE_LABEL.search(ref) and re.search(r"\d", ref):
                cnt[ref] = cnt.get(ref, 0) + 1
    rules_cited = sorted(cnt.items(), key=lambda kv: (-kv[1], kv[0]))
    srcs = [sx for sx in c.SRC if ok(sx[0])]
    pct = round(100 * len(ext) / len(attrs)) if attrs else 0
    s = D.slide("Sources", f"{pct}% of attributes align to an external standard or rule", (
        f"{len(ext)} of {len(attrs)} attributes name an external standard, rule or register as their primary reference; "
        f"the rest are firm-defined. The workbook's Sources tab lists {len(srcs)} sources with owner, license and link. "
        f"US rules and forms cited most often: " + "; ".join(f"{k} ({v})" for k, v in rules_cited[:12]) + "."))
    rect(s, LM, TOP, 3.4, 4.6, fill=PALE, rounded=True)
    for i, (v, lab) in enumerate([(f"{pct}%", f"of attributes ({len(ext)} of {len(attrs)}) cite an external primary "
                                                f"reference"), (str(len(srcs)), "sources in the workbook, with owner, "
                                                                "license and link"),
                                  (str(len(rules_cited)), "distinct US rules, forms and standards cited by number")]):
        y = TOP + 0.2 + i * 1.45
        text(s, LM + 0.3, y, 2.9, 0.6, v, size=30, bold=True, color=BLUE, fit=False)
        text(s, LM + 0.3, y + 0.62, 2.9, 0.7, lab, size=11.5, color=GREY, min_size=9)
    x2 = LM + 3.7
    text(s, x2, TOP - 0.1, 8.4, 0.35, "RULES AND STANDARDS CITED MOST OFTEN (ATTRIBUTES)", size=12, bold=True,
         color=BLUE, fit=False)
    top_rules = rules_cited[:16]
    half = math.ceil(len(top_rules) / 2)
    for j, chunk in enumerate([top_rules[:half], top_rules[half:]]):
        text(s, x2 + j * 4.25, TOP + 0.3, 4.1, 3.0, [[(f"{v}  ", {"bold": True, "color": BLUE}), (k, {})]
                                                     for k, v in chunk] or [""], size=11.5, min_size=8.5, gap=3)
    text(s, x2, TOP + 3.45, 8.4, 0.35, "MAIN SOURCES", size=12, bold=True, color=BLUE, fit=False)
    text(s, x2, TOP + 3.8, 8.4, 1.0, trim("; ".join(sx[0] for sx in srcs[:10]), 520), size=10.5, color=INK, min_size=8)

    # -- Design decisions -------------------------------------------------------------------------------------------
    des = []
    for it in notes.get("design", []) + notes.get("carry", []):
        lead, body = lead_and_body(it)
        lead = re.sub(r"\s*\((?:program-lead ruling|ruling \d+)\)|\s*\(ruling \d+,\s*", lambda m: " (" if
                      m.group(0).rstrip().endswith(",") else "", clean(lead)).strip()
        body = cap(untool(clean(body)))
        if re.match(r"(outline|brief outline|structure) followed|^outline", lead, re.I):
            continue
        if lead and ok(lead) and body and len(body) > 30:
            des.append((lead, body))
    src = "Source_Notes.md"
    if len(des) < 3:
        des = []
        for it in numbered(clean(ov.get("Design principles", ""))):
            lead, body = lead_and_body(it)
            if lead and clean(body):
                des.append((clean(lead), cap(clean(body))))
        src = "the module's design principles"
        thin.append("design decisions (from the module's Design principles)")
    des = des[:6]
    s = D.slide("Design decisions", "The boundary calls that shape the domain", (
        f"The main design and boundary decisions, from {src}. " + " ".join(f"{a}: {trim(b, 300)}" for a, b in des)))
    for i, (lead, body) in enumerate(des):
        x, y = LM + (i % 3) * 4.11, TOP + (i // 3) * 2.45
        rect(s, x, y, 3.91, 2.3, fill=PALE if i % 2 == 0 else WHITE, line=None if i % 2 == 0 else LINE, rounded=True)
        rect(s, x, y + 0.15, 0.07, 0.5, fill=ACCENTS[i % 4])
        text(s, x + 0.2, y + 0.1, 3.6, 0.62, trim(lead, 80), size=13, bold=True, color=NAVY, min_size=10)
        text(s, x + 0.2, y + 0.75, 3.6, 1.48, trim(body, 280), size=11, color=INK, min_size=8.5)

    # -- Tailoring levers -------------------------------------------------------------------------------------------
    lv = []
    for it in notes.get("levers", []):
        q, rest = lever(it)
        q, rest = untool(clean(q)), cap(untool(clean(rest)))
        if q and ok(q):
            lv.append([trim(q, 200), trim(rest, 260) or "No default recorded: the draft models one choice; confirm it."])
    widths = [5.4, 6.733]
    pages = paginate(lv, [CW * w / sum(widths) for w in widths], 10.5, BOTTOM - TOP - 0.45) if lv else []
    pg = pages[0] if pages else []
    s = D.slide("Tailoring levers", "The choices a firm makes when it adopts the domain", (
        f"These are the open questions of the domain's Source Notes, presented as tailoring levers: each has the "
        f"reference default the model assumes for a direct wealth manager with advice and own funds, and the lever a "
        f"firm can pull. {len(lv)} levers are recorded; the table shows {len(pg)}. " +
        " ".join(f"{r[0]} {r[1]}" for r, _ in pg)))
    if pg:
        table(s, LM, TOP, CW, widths, ["Question", "Reference default and lever"], [r for r, _ in pg], size=10.5,
              row_heights=[h for _, h in pg], first_bold=True)
        if len(lv) > len(pg):
            text(s, LM, BOTTOM - 0.3, CW, 0.3, f"{plural(len(lv) - len(pg), 'more lever', 'more levers')} in {dom.folder(n)}/Source_Notes.md.",
                 size=10, color=GREY, fit=False)
    else:
        text(s, LM, TOP, CW, 0.8, "No SME questions are recorded for this domain yet; the reference defaults stand as "
             "drafted.", size=14, color=GREY)
        thin.append("tailoring levers (none recorded)")

    # -- What to decide ---------------------------------------------------------------------------------------------
    pending = [d for d in own if d["status"] in ("Proposed", "SME decision required")]
    if len(pending) < 3:
        pending += [d for d in cw if d["status"] in ("Proposed", "SME decision required") and d not in pending]
    pending = [dict(d, title=clean(d["title"])) for d in pending]
    pending = [d for d in pending if d["title"]][:5]
    nxt = [cap(untool(clean(md(x)))) for x in notes.get("next", [])]
    nxt = [x for x in nxt if x]
    if len(nxt) < 3:
        nxt += [cap(untool(clean(x))) for x in numbered(ov.get("Suggested next steps", ""))]
        nxt = [x for x in nxt if x]
    s = D.slide("Next steps", "What to decide", (
        f"{len(own)} logged decisions name {name} as their primary domain; {len(pending)} proposed decisions are shown "
        f"for confirmation. " + " ".join(f"{d['id']}: {d['title']}." for d in pending) + " Next steps: " +
        " ".join(trim(x, 200) for x in nxt[:5])))
    text(s, LM, TOP - 0.1, 5.9, 0.35, "DECISIONS TO CONFIRM", size=12, bold=True, color=BLUE, fit=False)
    for i, d in enumerate(pending):
        y = TOP + 0.35 + i * 0.9
        rect(s, LM, y, 5.9, 0.8, fill=PALE, rounded=True)
        text(s, LM + 0.15, y + 0.05, 1.1, 0.7, d["id"], size=13, bold=True, color=BLUE, fit=False,
             anchor=MSO_ANCHOR.MIDDLE)
        text(s, LM + 1.25, y + 0.06, 4.55, 0.7, trim(clean(d["title"]), 150), size=11, color=INK, min_size=8.5,
             anchor=MSO_ANCHOR.MIDDLE)
    x2 = LM + 6.25
    text(s, x2, TOP - 0.1, 5.9, 0.35, "NEXT STEPS", size=12, bold=True, color=PURPLE, fit=False)
    for i, t in enumerate(nxt[:5]):
        y = TOP + 0.35 + i * 0.9
        rect(s, x2, y + 0.12, 0.45, 0.45, fill=PURPLE, rounded=True)
        text(s, x2, y + 0.16, 0.45, 0.4, str(i + 1), size=13, bold=True, color=WHITE, fit=False, align=PP_ALIGN.CENTER)
        text(s, x2 + 0.6, y + 0.02, 5.3, 0.8, trim(t, 190), size=11, color=INK, min_size=8.5, anchor=MSO_ANCHOR.MIDDLE)
    if not pending:
        text(s, LM, TOP + 0.4, 5.9, 0.6, "No proposed decision is open for this domain.", size=12, color=GREY)

    os.makedirs(OUT_DIR, exist_ok=True)
    path = os.path.join(OUT_DIR, deck_name(n))
    D.save(path)
    nslides = len(D.prs.slides)
    if report is not None:
        report.append((n, deck_name(n), nslides, thin))
    print(f"[{n}] {deck_name(n)}: {nslides} slides" + (f"; thin: {', '.join(thin)}" if thin else ""))
    return path


def grain_text(g):
    """Grain without the key-format parentheticals (the prefix is shown on its own)."""
    g = re.sub(r"\s*\((?:[A-Z]{2,7}-[^()]*|[^()]*<[^()]*)\)", "", clean(g or ""))
    g = re.sub(r"\(([A-Z]{2,7}-[^;()]*);\s*", "(", g)
    return g.strip()


def compress_ids(ids, k):
    ids = sorted(set(ids), key=lambda s: int(s.split("-")[1]))
    shown = ids[:k]
    return ", ".join(shown) + (f" and {len(ids) - k} more" if len(ids) > k else "")


def book_slide(D, n, name, book_dec, touch):
    ids = [d["id"] for d in book_dec]
    s = D.slide("Books of record and certified numbers", "Where the domain meets the books of record", (
        f"CW-007 names the books of record of the wealth model, kept distinct in every definition: Portfolio Holding in "
        f"18, Client Holding in 49 and Fund Shareholder Position in 06, with the participant book in 16 and the fund "
        f"share register in 29. CW-011 certifies two families that overlap by design and are reconciled, never summed: "
        f"Client Assets and Firm AUM, with Net New Assets, Advised Assets, the household, client and account counts and "
        f"the Personal Rate of Return. {name} touches them through {plural(len(touch), 'attribute')}"
        + (f" and decisions {', '.join(ids)}." if ids else ".")))
    text(s, LM, TOP - 0.1, 5.9, 0.35, "THE BOOKS OF RECORD (CW-007)", size=12, bold=True, color=BLUE, fit=False)
    for i, (m, nm, desc) in enumerate(BOOKS):
        y = TOP + 0.32 + i * 0.66
        here = m == n
        rect(s, LM, y, 5.9, 0.58, fill=BLUE if here else PALE, rounded=True)
        text(s, LM + 0.15, y + 0.04, 2.3, 0.5, [[(nm, {"bold": True}), (f"\n{dd(m)}", {"size": 9})]], size=12,
             color=WHITE if here else NAVY, min_size=8, spacing=1.0, gap=0)
        text(s, LM + 2.5, y + 0.04, 3.3, 0.5, desc, size=10, color=WHITE if here else GREY, min_size=8,
             anchor=MSO_ANCHOR.MIDDLE)
    text(s, LM, TOP + 3.7, 5.9, 0.35, "CERTIFIED NUMBERS (CW-011)", size=12, bold=True, color=PURPLE, fit=False)
    text(s, LM, TOP + 4.05, 5.9, 0.85, "Client Assets and Firm AUM overlap by design (own funds held in client "
         "accounts appear in both) and are reconciled, never summed. Also certified: Net New Assets, Advised Assets, "
         "households, clients and accounts, Personal Rate of Return.", size=11, color=INK, min_size=9)
    x2 = LM + 6.25
    text(s, x2, TOP - 0.1, 5.9, 0.35, "HOW THIS DOMAIN TOUCHES THEM", size=12, bold=True, color=MAGENTA, fit=False)
    paras = []
    for d in book_dec:
        if clean(d["title"]):
            paras.append([(d["id"] + ": ", {"bold": True, "color": MAGENTA}), (trim(clean(d["title"]), 140), {})])
    seen = set()
    for o, x in touch:
        k = (o["name"], x["a"][0])
        if k in seen or not ok(x["a"][0]) or x["a"][0].endswith(" ID"):
            continue
        seen.add(k)
        flag = {"Mastered here": "mastered here", "Reference": f"reference to {x['owner']}",
                "Derived copy": f"derived copy of {x['owner']}"}.get(x["flag"], x["flag"])
        paras.append([(f"{o['name']}.{x['a'][0]}", {"bold": True, "color": NAVY}), (f"  ({flag})", {"color": GREY})])
        if len(paras) >= 11:
            break
    text(s, x2, TOP + 0.3, 5.9, 4.6, paras, size=11, color=INK, min_size=8.5, gap=3)
    return s


# ---------------------------------------------------------------------------------------------------------------------
# Check and command line
# ---------------------------------------------------------------------------------------------------------------------
def deck_text(path):
    prs = Presentation(path)
    out = []
    for s in prs.slides:
        for sh in s.shapes:
            if sh.has_text_frame:
                out.append(sh.text_frame.text)
            elif sh.has_table:
                out += [c.text for r in sh.table.rows for c in r.cells]
        if s.has_notes_slide:
            out.append(s.notes_slide.notes_text_frame.text)
    return len(prs.slides), "\n".join(out)


def check(paths):
    bad = 0
    for p in paths:
        k, t = deck_text(p)
        hits = sorted(set(m.group(0) for m in BANNED.finditer(t)))
        print(f"  check {os.path.basename(p)}: {k} slides, " + (f"WORDING: {hits}" if hits else "clean"))
        bad += bool(hits)
    return bad


if __name__ == "__main__":
    args = sys.argv[1:]
    todo = []
    if "--all" in args:
        todo = [n for n in dom.WEALTH_DOMAINS if module_name(n)]
    while "--domain" in args:
        i = args.index("--domain")
        todo.append(args[i + 1].zfill(2))
        del args[i:i + 2]
    if "--out" in args:                       # --out DIR: write somewhere else (for a trial run)
        i = args.index("--out")
        OUT_DIR = os.path.abspath(args[i + 1])
        del args[i:i + 2]
    if not todo:
        raise SystemExit(__doc__)
    report, paths = [], []
    for n in todo:
        paths.append(build(n, report))
    print(f"{len(paths)} deck(s) written to {os.path.relpath(OUT_DIR, ROOT)}")
    if "--check" in args:
        raise SystemExit(1 if check(paths) else 0)
