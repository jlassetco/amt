# Business capability map and area register

Step 0 artifacts for the enterprise expansion (`00_Program/Enterprise_Expansion_Plan.md` §5, §8 and §9.6), re-tested at Step 5 (2026-10-07) against the 44 drafted Data Domains.

## Files

| File | What it holds |
|---|---|
| `areas.py` | The area register. `AREAS` lists the six areas in display order; Foundations is flagged `band: True` because it is shown on every area view. `DOMAIN_AREA` gives every Data Domain (01 to 44) its home area, as drafted in plan §8.1. `DOMAIN_NAMES` has all 44 domain names. `ALTERNATIVES` lists the boundary calls for the client, as (domain, draft area, alternative area, reason). |
| `content_capabilities.py` | The capability map as data. `CAPABILITIES` holds the L1 capability areas, each with its L2 capabilities. Each L2 records the one domain that `masters` its core data, the domains it `reads` (drawn as `READS_CONVENTION` says), the business `lines` it serves, the `area` where the function usually sits, the `owner_role` that owns its data and `added` ("Step 5" for capabilities added at the Step 5 coverage test). `COVERAGE_NOTES` lists any domain that masters no capability, with the reason. `UNCOVERED_CONCEPTS` lists master concepts deliberately left without a capability, and `GAP_NOTES` the Step 5 gap findings. `DRAFTING_NOTES` lists judgment calls for the client to confirm. `CHANGELOG` records every Step 5 change to the Step 0 map, with the reason. |
| `../build_capability_map.py` | Validates both files and builds `00_Program/Business_Capability_Map.xlsx`. |

Areas are a presentation layer and never master data. Moving a domain to another area is an edit to `DOMAIN_AREA`; the taxonomy does not change. The explorer and the enterprise workbook will read `areas.py` later.

## Rebuild

From `_tools/`, with the Python that has `openpyxl`:

```
/usr/bin/python3 build_capability_map.py
```

The build stops with a list of errors if validation fails. It checks that:
- ids are unique and each L2 id sits under its L1
- every L2 has exactly one `masters` domain, and every `masters` and `reads` domain is in `DOMAIN_NAMES`
- every area id is in `AREAS`, every domain has a home area, and every `ALTERNATIVES` default matches `DOMAIN_AREA`
- business lines are valid codes (`"all"` when a capability serves all six)
- each definition is one sentence with no UK spellings
- the 01 to 16 names match `taxonomy_builder.DD_NAMES`
- every L2 has an `owner_role`; `added` is "" or "Step 5", and every added capability has a CHANGELOG entry
- every CHANGELOG entry names a real capability, a known field and a reason
- every `UNCOVERED_CONCEPTS` entry is a concept its domain owns in `consolidation/decisions.py` CONCEPT_OWNERSHIP

## Workbook sheets

Overview (with the Step 5 coverage result, gap findings and uncovered concepts), Areas, Capabilities (with Owner Role and Added), Capability-Domain Map (one row per capability and domain, with the role Masters or Reads and the capability owner role), Domain Coverage (flags Zero mastered, Read by none and Masters one), Boundary Calls, Business Lines, Data Owners (each owner role with the capabilities it owns and the domains they master, the seed of the data-owner register) and Step 5 Changes (the CHANGELOG).

## The coverage test

The test runs in both directions:

- **Every capability has a master.** Each L2 capability names exactly one domain that masters its core data. A capability that no domain could master would point to a missing domain.
- **Every domain masters something.** A domain that masters no capability may need to be folded into a neighbor. The Domain Coverage sheet flags it as "Zero mastered". The build fails unless the domain is explained in `COVERAGE_NOTES`; a capability is never invented to fill the gap. A domain that no capability reads is flagged "Read by none".

Plan §6 step 5 runs the test again after the new domains are drafted; see the Step 5 section below.

A capability's function area can differ from its mastering domain's home area. For example, Model Delivery to Sponsors runs in Distribution & Client, but its data is mastered by 24 Portfolio Management & Construction, which sits in Investment. These cases are marked on the Capabilities sheet, because they show where data owners cross area lines.

## Step 5 coverage test (2026-10-07)

Re-run once Data Domains 17-44 were drafted and merged (tag `stage4-v0.1`). The evidence was the concept ownership register (`consolidation/decisions.py` CONCEPT_OWNERSHIP, 562 master concepts), each domain's enrichment SUMMARY, `Domain_Ownership_and_Conventions.md` §14-§18 and a scan of every Reference and Derived copy attribute in the content modules (which domain each domain's objects point at). Every change is in `CHANGELOG` with its reason and on the Step 5 Changes sheet.

**Capability direction.** Every L2 capability has a mastering domain. Three were re-pointed to the domain that masters their data after drafting:

| Capability | Was | Now | Why |
|---|---|---|---|
| C-02.04 Model Delivery to Sponsors | 01 | 24 | The delivered model target allocations and model change summaries are 24's |
| C-06.10 Fund Service Provider Oversight | 35 | 40 | Supplier engagements, service levels, performance reviews and outsourcing arrangements are 40's |
| C-08.05 Participant Communications | 13 | 16 | Plan notices and fee disclosures (PNTC-) are 16's |

The other moves made during drafting were already reflected in the mastering domain (SSIs in 26, custody accounts in 28, models in 37, seed capital in 43, brand in 42) or are covered by the capabilities added at Step 5 (the fund advisory agreement in 35, the DORA register in 40, the restricted list in 38) and by widened definitions (entity authorizations in 38). The `reads` of almost every capability were redrawn from the reference scan.

**Domain direction.** Every Data Domain masters at least one capability. Seven master exactly one, each a coherent single function rather than a candidate to fold: 04 Marketing & Digital, 07 Compensation & Territory, 09 Shared & Enterprise Reference Data, 10 Distribution Finance & Profitability, 14 Third-Party Data & Licensing, 15 Account and 17 Instrument & Issuer Reference. Every domain is read by at least one capability.

**Gaps.** No capability lacks a master. Master concepts that no Step 0 capability covered were given 13 new L2 capabilities where a real function runs them (flagged `added = "Step 5"`): C-05.09, C-06.11, C-12.13 to C-12.16, C-13.13 to C-13.18 and C-14.10. Others were covered by widening a definition (`GAP_NOTES`). Three are deliberately uncovered (`UNCOVERED_CONCEPTS`): the 05 Funding Source code list, the 06 technical feed and load records, and the stale 01 Fund Advisory / Management Agreement row that CD-232 superseded.

**Areas.** No domain changed area. One boundary call was added (41 to Foundations) and the 08 reason widened (records retention). Plan §8.1 matches `areas.py`.

**Business lines.** Issuer meetings (C-01.03) and proxy voting (C-01.06) now serve the public-securities lines only; fund board support (C-06.08) adds private markets for LPACs; transfer agency oversight (C-07.08) covers every TA-processed line (MF, ETF, CIT, IDF).

**Owner roles.** Every L2 names an `owner_role` (72 distinct roles), drawn from the domains' Source_Notes and the owner roles used in the decision log. The Data Owners sheet groups them for the Phase E data-owner assignments.

Counts: 14 L1, 141 L2, 832 capability-domain links, 44 domains in 7 areas, 16 boundary calls.
