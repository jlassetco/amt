"""Area register of the wealth-manager reference model: the home area of every Data Domain (Wealth_Manager_Rework_Plan.md
§7; CW-018).

Areas are a presentation layer. They group Data Domains for navigation and for assigning owners; they never master data.
Moving a domain to another area is an edit to DOMAIN_AREA here; the taxonomy does not change. ALTERNATIVES records the
boundary calls the client must make.

W0 (2026-10-14): the wholesale model's six areas (Investment, Investment Operations, Fund Operations, Distribution &
Client, Corporate Functions, Foundations; tag wholesale-v1.0) are replaced by seven areas and the Foundations band, cut
for a direct-to-investor wealth manager that also manufactures funds (CW-004). Client & Advice is the new center: the
offerings and the product lifecycle (01, 36) sit with clients, households, accounts, advice, managed portfolios,
advisors, engagement, client service, billing, conduct and trust, because the firm's product is the client relationship
as much as the fund. Brokerage & Workplace Operations is a back office distinct from Fund Operations: client orders,
the brokerage book of record, money movement and plan recordkeeping run on account-level data at retail scale.
Distribution & Client is retired; its intermediary, flows, intelligence, institutional servicing and finance domains
form Distribution, Channels & Client Economics. 07 and 30 were retired at the W2-W4 merge (CW-907, CW-930); they keep a
home (07 in Distribution, Channels & Client Economics, 30 in Investment) only so that the pending WP0 products they
owned still resolve an area; retired domains are never rendered.

DOMAIN_NAMES is read from domains.py, so the two registers cannot drift. RETIRED_AREAS keeps any wholesale area ID that
another register still cites (empty since the W0 function re-pointing retired "DCL"); such IDs are accepted
by AREA_IDS and AREA_NAMES, are never rendered, and build_capability_map.py rejects them for capabilities.

Read by _tools/build_capability_map.py, build_explorer.py, build_enterprise.py, build_index.py, build_data_products.py,
build_review_pack.py and data_products/dp_model.py.
"""
import os
import sys

_TOOLS = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _TOOLS not in sys.path:
    sys.path.append(_TOOLS)
from domains import DD_NAMES  # noqa: E402

# Ordered as the areas are shown, Client & Advice first (CW-018, plan §7). Foundations is a band shown on every area view,
# not an area of its own.
AREAS = [
    {"id": "CLA", "name": "Client & Advice", "order": 1, "band": False,
     "description": "The client relationship: the offerings and services the firm provides and how they change, clients "
                    "and households, accounts, financial planning and advice, managed portfolios, the firm's advisors, "
                    "marketing and engagement, client service, pricing and billing, retail conduct and trust services."},
    {"id": "INV", "name": "Investment", "order": 2, "band": False,
     "description": "Front office: research, portfolio management, trading and stewardship of the funds and institutional "
                    "portfolios the firm manages, and the oversight of the external managers and sub-advisers it hires."},
    {"id": "IOP", "name": "Investment Operations", "order": 3, "band": False,
     "description": "Middle office: the investment book of record, pricing, trade support and the oversight that measures "
                    "what the front office does (risk, performance, investment compliance)."},
    {"id": "FOP", "name": "Fund Operations", "order": 4, "band": False,
     "description": "Fund back office: fund accounting, fund custody, transfer agency and fund governance for the fund "
                    "complex."},
    {"id": "BWO", "name": "Brokerage & Workplace Operations", "order": 5, "band": False,
     "description": "Client back office: brokerage orders and execution, clearing, settlement and custody of client "
                    "assets, money movement and cash sweep, and workplace retirement plan recordkeeping."},
    {"id": "DIS", "name": "Distribution, Channels & Client Economics", "order": 6, "band": False,
     "description": "Channels and their economics: the intermediary and institutional channel, client assets and flows "
                    "by channel, market intelligence, institutional servicing and reporting, and client revenue and "
                    "profitability."},
    {"id": "CORP", "name": "Corporate Functions", "order": 7, "band": False,
     "description": "Running the firm: finance, treasury, people, enterprise risk, compliance, legal, procurement, "
                    "technology, communications and workplace services."},
    {"id": "FDN", "name": "Foundations", "order": 8, "band": True,
     "description": "Cross-cutting reference and governance data used by every area: shared reference data, instruments "
                    "and issuers, third-party data and data governance."},
]

# Wholesale area IDs still cited by other registers (CW-018): id -> (name, decision, until). Not rendered.
RETIRED_AREAS = {}   # was {"DCL": ...} until the W0 function re-pointing; no register cites DCL now (CW-018)

LIVE_AREA_IDS = [a["id"] for a in AREAS]
AREA_IDS = LIVE_AREA_IDS + list(RETIRED_AREAS)
AREA_NAMES = {**{a["id"]: a["name"] for a in AREAS}, **{k: v[0] for k, v in RETIRED_AREAS.items()}}

# Data Domain names, from domains.py (the one register of numbers, names and L1 codes).
DOMAIN_NAMES = dict(DD_NAMES)

# Domains flagged optional: kept unless the client folds or drops them.
OPTIONAL_DOMAINS = {"43": "Fold into 19 if the client has no separate treasury function.",
                    "44": "Low priority, kept only if the client wants full coverage.",
                    "51": "Drop if the client has no trust company (CW-017)."}

# Home area of every Data Domain, as in plan §7.
DOMAIN_AREA = {
    # Investment (front office), including manager oversight
    "23": "INV", "24": "INV", "25": "INV", "34": "INV", "52": "INV",
    "30": "INV",    # retired at W4 (CW-930); not rendered, kept so the pending WP0 products it owned still find an area
    # Investment Operations (middle office)
    "18": "IOP", "22": "IOP", "26": "IOP", "31": "IOP", "32": "IOP", "33": "IOP",
    # Fund Operations (fund back office)
    "27": "FOP", "28": "FOP", "29": "FOP", "35": "FOP",
    # Client & Advice (the offerings and their lifecycle, clients, accounts, advice, advisors, service, billing, conduct)
    "01": "CLA", "36": "CLA", "02": "CLA", "15": "CLA", "45": "CLA", "46": "CLA", "03": "CLA", "04": "CLA", "13": "CLA",
    "47": "CLA", "08": "CLA", "51": "CLA",
    # Brokerage & Workplace Operations (client back office)
    "48": "BWO", "49": "BWO", "50": "BWO", "16": "BWO",
    # Distribution, Channels & Client Economics
    "05": "DIS", "06": "DIS", "10": "DIS", "11": "DIS", "12": "DIS",
    "07": "DIS",    # retired at W4 (CW-907); not rendered, kept so the pending WP0 products it owned still find an area
    # Corporate Functions
    "19": "CORP", "20": "CORP", "37": "CORP", "38": "CORP", "39": "CORP", "40": "CORP", "41": "CORP", "42": "CORP",
    "43": "CORP", "44": "CORP",
    # Foundations (band on every area view)
    "09": "FDN", "17": "FDN", "21": "FDN", "14": "FDN",
}

# Boundary calls for the client to confirm: (domain, default area, alternative area, reason).
ALTERNATIVES = [
    ("22", "IOP", "INV",
     "Many firms run market data and pricing as a front-office function next to trading and research."),
    ("31", "IOP", "INV",
     "Investment risk sits in the front office where risk managers are embedded with portfolio teams."),
    ("32", "IOP", "CORP",
     "At some firms performance measurement reports into finance rather than investment operations; the client-level "
     "personal rate of return may also be shown with Client & Advice."),
    ("33", "IOP", "CORP",
     "Investment compliance often reports to the Chief Compliance Officer with 38 rather than to operations."),
    ("26", "IOP", "FOP",
     "Fund-side settlement, collateral and OTC lifecycle are often run by the fund back office alongside fund custody "
     "(28)."),
    ("29", "FOP", "BWO",
     "At a self-clearing firm the transfer agent and the brokerage back office are often one operations organization; "
     "the platform's omnibus position in the funds is the largest account on the register."),
    ("35", "FOP", "CORP",
     "Fund boards and regulatory filings are often supported by legal and the fund treasurer rather than operations."),
    ("16", "BWO", "FOP",
     "Plan recordkeeping trades fund units through transfer agency (29), so a firm whose recordkeeper is part of fund "
     "operations may show it there; it sits in Brokerage & Workplace Operations because its reads from accounts (15), "
     "advice (45) and client holdings (49), for participant services and rollover capture, outweigh its reads from 29."),
    ("51", "CLA", "BWO",
     "Trust administration is often run as an operations function alongside custody of client assets (49) and money "
     "movement (50); it sits in Client & Advice because the fiduciary relationship and its discretionary decisions are "
     "client-facing."),
    ("47", "CLA", "BWO",
     "Fee calculation and debiting are a controlled operations process next to the brokerage book of record (49) and "
     "money movement (50); fee schedules, householding and disclosure are client-facing, so 47 is homed with clients."),
    ("46", "CLA", "INV",
     "Managed account programs may report to the investment team that builds the models (24); 46 is homed with clients "
     "because it runs on account-level targets, restrictions and tax decisions for each household."),
    ("36", "CLA", "INV",
     "At a manufacturer whose product committee is led by the investment team, fund development may be shown with "
     "Investment; 36 is homed with clients because it also develops the advice services and platform features."),
    ("13", "CLA", "BWO",
     "Contact centers, statements, confirmations and tax documents are often run by operations alongside the brokerage "
     "back office; 13 is homed with clients because it is the client's servicing record across every channel."),
    ("10", "DIS", "CORP",
     "Client revenue and profitability analysis is staffed by the finance function and may be shown with 19 Finance & "
     "Accounting."),
    ("08", "CLA", "CORP",
     "Retail conduct and supervision is part of the compliance function (38) in the organization chart; 08 is homed "
     "with clients because its records are recommendations, complaints and representatives' conduct toward clients."),
    ("14", "FDN", "CORP",
     "14 can be shown as the data-vendor specialization of 40 Procurement & Vendor Management."),
    ("21", "FDN", "CORP",
     "The Chief Data Office may be shown as a corporate function rather than as a foundation band."),
    ("41", "CORP", "FDN",
     "41 masters the application inventory (APPL-), the system of record cited by every Data Domain (CD-263), so the "
     "client may show it in the Foundations band beside 09, 17, 21 and 14; it stays in Corporate Functions because the "
     "technology function runs it."),
]

# Domain label helper, e.g. "17 Instrument & Issuer Reference".
label = lambda n: f"{n} {DOMAIN_NAMES[n]}"
