"""Business capability map for the whole firm (Enterprise_Expansion_Plan.md §5), as data.

L1 capability areas hold L2 capabilities. Each L2 capability records:
  id          "C-LL.NN", unique; LL is its L1
  name        short capability name
  definition  one plain sentence
  masters     the one Data Domain ("NN") that masters the capability's core data
  reads       other Data Domains it reads (see READS_CONVENTION)
  lines       "all", or the subset of BUSINESS_LINES it serves
  area        the area (areas.py) where the function usually sits; it may differ from the mastering domain's home area
  owner_role  the business role that owns the capability's data (seeds the data-owner register, plan §5 and Program_Plan
              Phase E); drawn from the domains' Source_Notes and the owner roles of the decision log
  added       "Step 5" when the capability was added at the Step 5 coverage test, "Phase 2 review" when added at the
              area review of 2026-10-14, "W0" when added at the wealth-manager re-cut, else ""

The firm: a US wealth manager that serves investors directly and also manufactures the funds it recommends (the
Vanguard-type archetype of Wealth_Manager_Rework_Plan.md §2; a hypothetical firm). It gives digital and human advice,
manages client accounts to models, carries and clears its clients' brokerage accounts (self-clearing), moves their cash
through program banks and money market sweeps, recordkeeps DC plans and captures their rollovers, runs its own funds,
ETFs and CITs (part of the active range sub-advised), advises institutions, sells its funds and models through third-party
advisors as a secondary channel and, optionally, administers trusts through a trust company. US only; eight business
lines (CW-004).

History: drafted at Step 0 for the wholesale sibling (a wholesale distributor, US + EU/UK, six business lines), re-tested
at Step 5 and reviewed at Phase 2 (2026-10-14); that map is frozen at git tag wholesale-v1.0. Re-cut at W0 of the
wealth-manager rework (CW-004, CW-018): every capability that still exists at this firm was kept with its mastering
domain, reads, lines and owner role re-checked; capabilities that exist only for the wholesale business were removed
(REMOVED_W0) or re-pointed; capabilities that changed L1 got a new id (MOVED_W0); new L1 areas and capabilities were
added for advice, managed accounts, brokerage and clearing, money movement, client service and digital, trust services,
manager oversight, workplace, client pricing and billing, retail conduct, the advisor workforce and intermediary and
institutional distribution. Every W0 change is in CHANGELOG under the W0 heading. Pre-W0 CHANGELOG entries of a moved
capability carry its W0 id; those of a removed capability are kept only at the tag. The reads of capabilities mastered
by 45-52 (and the W0 reads of the replaced domains 02, 03, 05, 08, 15) are drawn from the plan's boundaries (§4, §5) and
were re-tested at the W5 coverage test against the merged modules (CHANGELOG, W5 heading). Built by _tools/build_capability_map.py into
00_Program/Business_Capability_Map.xlsx.
"""

BUSINESS_LINES = {
    "DB": "Direct brokerage and self-directed investing",
    "DA": "Digital advice",
    "HA": "Human and hybrid advice",
    "PF": "Proprietary funds and ETFs",
    "WR": "Workplace retirement recordkeeping",
    "IA": "Institutional advisory",
    "IC": "Intermediary channel",
    "TR": "Personal trust services",
}
ALL = "all"
# Helper sets of business lines
ADVICE = ["DA", "HA"]                                 # advice relationships, digital and human
PORTFOLIOS = ["PF", "IA"]                             # portfolios the investment team runs (own funds, mandates)
ALLOCATION = ["PF", "IA", "DA", "HA", "WR", "IC"]     # lines that follow the house allocation views and models
CARRIED = ["DB", "DA", "HA", "TR"]                    # accounts the broker-dealer carries and clears (49's book)
RETAIL = ["DB", "DA", "HA", "WR", "TR"]               # individual investors the firm serves directly
MANAGED = ["DA", "HA", "TR", "WR"]                    # client accounts managed to an assigned model (in-plan too)
FEE_BILLED = ["DB", "DA", "HA", "IA", "TR"]           # lines billed client fees by 47 (fund expenses 27, plan fees 16)
SERVICED = ["DB", "DA", "HA", "WR", "TR", "PF"]       # clients served by 13, fund-only shareholders included
S5 = "Step 5"
P2 = "Phase 2 review"
W0 = "W0"

# How `reads` is drawn (Step 5): the domains whose records the capability's data references (Reference and Derived copy
# attributes in the mastering domain's objects for the capability) or consumes by a documented hand-off in the domain
# summaries. A domain that only reads this capability's output is not listed. Employees (20) and the 09 calendars, org
# units and legal entities are referenced almost everywhere; they are listed only where they are central to the
# capability (for example portfolio manager assignment, enterprise reference data).
READS_CONVENTION = ("Reads lists the domains whose records the capability's data references or copies, or consumes by a "
                    "documented hand-off; a domain that only reads the capability's output is not listed. Employees (20) "
                    "and the 09 calendars, org units and legal entities are listed only where they are central.")


def _c(cid, name, area, masters, reads, lines, owner_role, definition, added=""):
    return {"id": cid, "name": name, "area": area, "masters": masters, "reads": reads, "lines": lines,
            "owner_role": owner_role, "definition": definition, "added": added}


CAPABILITIES = [
    {"id": "C-01", "name": "Investment Research & Stewardship", "area": "INV",
     "definition": "Forming investment views on issuers, markets and sustainability, and acting as a shareholder in the "
                   "companies the firm's funds and mandates invest in.",
     "l2": [
         _c("C-01.01", "Fundamental Research", "INV", "23", ["17", "02", "22", "14"], PORTFOLIOS, "Director of Research",
            "Analyzing issuers and securities in equity and credit markets to produce ratings, recommendations, internal "
            "credit assessments, models and research notes."),
         _c("C-01.02", "Quantitative & Macro Research", "INV", "23", ["22", "17", "14", "21"], ALLOCATION,
            "Director of Research",
            "Building factor, signal and macroeconomic research that informs capital-market assumptions, asset allocation "
            "and security selection."),
         _c("C-01.03", "Issuer Meeting Management", "INV", "23", ["17", "02", "38"], PORTFOLIOS, "Director of Research",
            "Scheduling, recording and following up meetings between investment staff and issuer management, including "
            "wall crossings and MNPI flags."),
         _c("C-01.04", "Research Payment Management", "INV", "25", ["23", "02", "19"], PORTFOLIOS, "Head of Trading",
            "Budgeting, valuing and paying for third-party research, including commission sharing arrangements within "
            "the Section 28(e) safe harbor."),
         _c("C-01.05", "ESG Data & Sustainability Reporting", "INV", "34", ["17", "14", "02", "18", "01", "22", "37"],
            PORTFOLIOS, "Head of Sustainable Investing",
            "Sourcing and scoring ESG data on issuers and holdings and producing the stewardship and climate disclosures "
            "of the funds and mandates."),
         _c("C-01.06", "Proxy Voting & Engagement", "INV", "34", ["18", "17", "28", "02", "23", "13", "15"], PORTFOLIOS,
            "Head of Stewardship",
            "Voting proxies on securities held, including the voting policy choices offered to fund investors, and "
            "engaging with investee companies as a shareholder of those companies."),
     ]},
    {"id": "C-02", "name": "Portfolio Management", "area": "INV",
     "definition": "Deciding what each fund, mandate and model holds and turning those decisions into orders.",
     "l2": [
         _c("C-02.01", "Investment Policy & Asset Allocation", "INV", "24", ["01", "23", "18", "22"], ALLOCATION,
            "Chief Investment Officer",
            "Setting house views, capital-market assumptions, strategic and tactical allocations and the glide paths of "
            "target-date funds and advice models, and recording investment committee decisions."),
         _c("C-02.02", "Portfolio Construction & Rebalancing", "INV", "24", ["18", "01", "17", "22", "12"], PORTFOLIOS,
            "Head of Portfolio Management",
            "Setting fund and institutional portfolio targets against the mandate, forecasting investable cash and "
            "generating rebalancing trades."),
         _c("C-02.03", "Model Portfolio Management", "INV", "24", ["01", "18", "17"], ["DA", "HA", "WR", "IC"],
            "Head of Portfolio Management",
            "Maintaining the target allocations of the model portfolios that advice programs, managed accounts and "
            "intermediary platforms follow."),
         _c("C-02.04", "Model Delivery to Intermediary Platforms", "DIS", "24", ["01", "05", "02"], ["IC"],
            "Head of Intermediary Distribution",
            "Publishing model portfolio changes to third-party advisor and sponsor platforms that trade the model for "
            "their own clients."),
         _c("C-02.06", "ETF Basket Construction", "INV", "24", ["18", "17", "01", "27"], ["PF"],
            "Head of ETF Portfolio Management",
            "Designing the daily creation and redemption baskets and portfolio composition file for each ETF."),
         _c("C-02.07", "Portfolio Manager Assignment", "INV", "24", ["20", "01", "18"], ALLOCATION,
            "Chief Investment Officer",
            "Recording which portfolio managers and teams run each fund, mandate and model portfolio, with effective "
            "dates."),
     ]},
    {"id": "C-03", "name": "Portfolio Trading & Execution", "area": "INV",
     "definition": "Executing the investment decisions of the funds and institutional portfolios in the market at the best "
                   "available terms.",
     "l2": [
         _c("C-03.01", "Order Management", "INV", "25", ["24", "18", "17", "33", "12", "38"], PORTFOLIOS, "Head of Trading",
            "Capturing, routing and tracking portfolio orders from the investment decision through to execution, apart "
            "from the client orders of the brokerage."),
         _c("C-03.02", "Execution & Allocation", "INV", "25", ["22", "17", "02", "18", "38"], PORTFOLIOS, "Head of Trading",
            "Executing portfolio orders across asset classes, including IPOs and new issues, and allocating fills fairly "
            "to portfolios and sleeves."),
         _c("C-03.03", "Broker & Counterparty Approval", "INV", "25", ["02", "23", "26", "31"], PORTFOLIOS, "Head of Trading",
            "Approving brokers and trading counterparties, setting their limits and managing their status."),
         _c("C-03.04", "Best Execution & Transaction Cost Analysis", "INV", "25", ["22", "02"], PORTFOLIOS, "Head of Trading",
            "Measuring execution quality against benchmarks and evidencing best execution to oversight committees."),
         _c("C-03.05", "ETF Capital Markets", "INV", "05", ["02", "29", "22", "24"], ["PF"], "Head of ETF Capital Markets",
            "Managing authorized participant and market maker relationships to support ETF liquidity and spreads."),
     ]},
    {"id": "C-04", "name": "Investment Operations", "area": "IOP",
     "definition": "Keeping the reference data, book of record, prices and trade support the investment process runs on.",
     "l2": [
         _c("C-04.01", "Security & Issuer Master Management", "IOP", "17", ["02", "01", "14", "09"], ALL,
            "Head of Enterprise Data Management",
            "Setting up securities, including the listed options, CDs, municipal bonds and 529 portfolios clients trade, "
            "with their identifiers, terms and classifications, issuer hierarchies, credit ratings and announced corporate "
            "action events."),
         _c("C-04.02", "Portfolio Set-Up & Maintenance", "IOP", "18", ["01", "12", "05", "28", "09"], PORTFOLIOS,
            "Head of Investment Operations",
            "Opening and maintaining fund and institutional portfolios and their sleeves in the book of record and linking "
            "them to products and mandates."),
         _c("C-04.03", "Investment Book of Record", "IOP", "18", ["17", "25", "26", "28", "22"], PORTFOLIOS,
            "Head of Investment Operations",
            "Maintaining real-time and start-of-day positions, tax lots, cash and portfolio transactions for every fund "
            "and institutional portfolio, apart from the brokerage book of record of client holdings."),
         _c("C-04.04", "Pricing & Price Challenges", "IOP", "22", ["17", "14", "02", "27"], ALL,
            "Head of Pricing and Valuation",
            "Sourcing, validating and approving security prices and evaluated prices, and challenging prices with "
            "vendors."),
         _c("C-04.05", "Fair Value & Valuation Oversight", "IOP", "22", ["17", "18", "14", "37", "02"], PORTFOLIOS,
            "Head of Pricing and Valuation",
            "Determining fair values for illiquid and hard-to-value assets through the valuation committee."),
         _c("C-04.06", "Market & Index Data Management", "IOP", "22", ["14", "09", "01", "17", "27"], ALL, "Head of Market Data",
            "Maintaining FX rates, reference rate fixings, curves, index levels and constituents and ETF market "
            "statistics used across valuation, risk, performance and disclosure."),
         _c("C-04.07", "Trade Confirmation & Settlement", "IOP", "26", ["25", "28", "02", "18", "17", "29", "09"], PORTFOLIOS,
            "Head of Trade Operations",
            "Confirming, matching and settling portfolio trades and managing settlement fails."),
         _c("C-04.08", "OTC Derivatives & Collateral Management", "IOP", "26", ["25", "02", "17", "22", "18", "28"], PORTFOLIOS,
            "Head of Trade Operations",
            "Supporting the OTC derivative lifecycle and calling, posting and reconciling margin and collateral under "
            "ISDA and CSA terms."),
         _c("C-04.09", "Standing Settlement Instruction Management", "IOP", "26", ["12", "28", "02", "18", "01"], PORTFOLIOS,
            "Head of Trade Operations",
            "Maintaining standing settlement instructions for funds, portfolios, institutional mandates and "
            "counterparties."),
         _c("C-04.10", "Trade Support & Trade Error Management", "IOP", "25", ["18", "22", "37"], PORTFOLIOS,
            "Head of Trade Operations",
            "Resolving order and allocation exceptions after execution and recording trade errors, their gain or loss "
            "and how each affected portfolio was made whole.", P2),
     ]},
    {"id": "C-05", "name": "Investment Oversight", "area": "IOP",
     "definition": "Measuring and controlling the risk, return and rule compliance of what the portfolios hold, and "
                   "measuring the returns clients earn.",
     "l2": [
         _c("C-05.01", "Portfolio Risk Measurement", "IOP", "31",
            ["18", "22", "17", "01", "14", "02", "23", "25", "26", "34", "37"], PORTFOLIOS, "Head of Investment Risk",
            "Measuring exposures, ex-ante risk, VaR, tracking error, stress scenarios and counterparty exposure for each "
            "portfolio and monitoring them against risk limits."),
         _c("C-05.02", "Liquidity & Derivatives Risk", "IOP", "31", ["18", "22", "17", "27", "26", "35"], ["PF"],
            "Liquidity Risk Management Program Administrator",
            "Classifying portfolio liquidity and limiting derivatives risk under SEC Rules 22e-4 and 18f-4."),
         _c("C-05.03", "Performance Measurement", "IOP", "32", ["18", "27", "22", "01", "36"], PORTFOLIOS,
            "Head of Performance Measurement",
            "Calculating fund, share class, portfolio, composite and benchmark returns and maintaining GIPS composite "
            "membership."),
         _c("C-05.04", "Performance Attribution & Analytics", "IOP", "32", ["18", "22", "24", "31", "17", "37"], PORTFOLIOS,
            "Head of Performance Measurement",
            "Explaining returns by allocation, selection, currency and factor and producing risk-adjusted statistics."),
         _c("C-05.06", "Investment Guideline Coding", "IOP", "33", ["01", "02", "34", "38", "36", "14", "17", "52"],
            PORTFOLIOS, "Head of Investment Compliance",
            "Translating prospectus, mandate, sub-adviser, client and regulatory restrictions into coded compliance "
            "rules."),
         _c("C-05.07", "Pre- & Post-Trade Compliance Monitoring", "IOP", "33", ["25", "18", "17", "24", "31", "38"], PORTFOLIOS,
            "Head of Investment Compliance",
            "Testing orders and holdings against coded rules and managing the alerts they raise."),
         _c("C-05.08", "Investment Breach Management", "IOP", "33", ["25", "27", "18", "35", "17"], PORTFOLIOS,
            "Head of Investment Compliance",
            "Investigating, remediating and reporting breaches of investment guidelines and regulatory limits."),
         _c("C-05.10", "Client Account Performance", "IOP", "32", ["49", "15", "02", "46", "16", "22"], RETAIL,
            "Head of Performance Measurement",
            "Calculating each client's personal rate of return, time-weighted and money-weighted, at account and household "
            "grain from the brokerage book of record and the cash flows into and out of each account.", W0),
     ]},
    {"id": "C-06", "name": "Fund Accounting, Custody & Fund Governance", "area": "FOP",
     "definition": "Keeping the official books of each fund, safekeeping its assets and meeting its governance and "
                   "regulatory obligations.",
     "l2": [
         _c("C-06.01", "Fund Accounting & NAV Calculation", "FOP", "27", ["18", "17", "22", "28", "01", "29", "26"],
            ["PF"], "Head of Fund Accounting",
            "Maintaining fund ledgers and calculating and releasing the NAVs of the mutual funds and ETFs and the unit "
            "values of the CITs."),
         _c("C-06.02", "Fund Expenses, Distributions & Tax", "FOP", "27", ["01", "19", "28", "17", "18"], ["PF"],
            "Fund Treasurer",
            "Accruing fund expenses and income and calculating distributions, fund taxable income and tax provisions."),
         _c("C-06.03", "Swing Pricing & NAV Error Correction", "FOP", "27", ["01", "29", "22"], ["PF"],
            "Head of Fund Accounting",
            "Correcting and compensating for NAV errors and applying any swing pricing or anti-dilution adjustment a fund "
            "has adopted under Rule 22c-1."),
         _c("C-06.04", "Fund Custody & Safekeeping", "FOP", "28", ["02", "18", "01", "38", "39"], PORTFOLIOS,
            "Head of Asset Servicing",
            "Managing the custodian network and safekeeping accounts of the funds and institutional portfolios, apart "
            "from the custody of client assets in the brokerage."),
         _c("C-06.05", "Cash & Position Reconciliation", "FOP", "28", ["18", "27", "26", "17", "22", "29"], PORTFOLIOS,
            "Head of Asset Servicing",
            "Reconciling cash and positions between the book of record, fund accounting and custodians, and resolving "
            "breaks."),
         _c("C-06.06", "Corporate Action Processing & Income Collection", "FOP", "28", ["17", "24", "18", "27", "01"],
            PORTFOLIOS, "Head of Asset Servicing",
            "Processing corporate actions and elections on fund and portfolio holdings, collecting income and pursuing tax "
            "reclaims and class actions."),
         _c("C-06.07", "Securities Lending", "FOP", "28", ["02", "18", "27", "01"], PORTFOLIOS, "Head of Asset Servicing",
            "Lending portfolio securities through an agent, managing collateral and recalls and accounting for the "
            "revenue."),
         _c("C-06.08", "Fund Board & Trustee Support", "FOP", "35",
            ["01", "02", "20", "22", "27", "31", "33", "34", "36", "13", "52"], ["PF"],
            "Head of Fund Legal",
            "Supporting the fund boards and CIT trustee committees, their meetings and the approvals they record, "
            "including the approval of sub-advisers."),
         _c("C-06.09", "Fund Regulatory Reporting", "FOP", "35", ["18", "27", "31", "22", "24", "34", "17"],
            ["PF"], "Head of Fund Regulatory Reporting",
            "Preparing fund filings such as N-PORT, N-CEN and N-CSR and ETF daily portfolio disclosure, and recording RIC "
            "qualification and exemptive relief relied on."),
         _c("C-06.10", "Fund Service Provider Oversight", "FOP", "40", ["01", "28", "29", "27", "13", "35", "37"], ["PF"],
            "Head of Fund Administration",
            "Overseeing outsourced fund administrators, custodians and transfer agents against service levels and "
            "board reporting needs."),
         _c("C-06.11", "Advisory Agreements & 15(c) Renewals", "FOP", "35", ["01", "10", "11", "32", "39", "52"], ["PF"],
            "Head of Fund Legal",
            "Maintaining fund advisory agreements and their per-fund schedules and running the annual Section 15(c) "
            "renewal with its materials and findings, drawing on the sub-adviser renewal data kept by manager "
            "oversight.", S5),
         _c("C-06.12", "Fund Financial Statements & Audit", "FOP", "27", ["01", "02"], ["PF"], "Fund Treasurer",
            "Preparing the annual and semi-annual financial statements and per-class financial highlights of each fund "
            "from its accounting book and supporting the independent audit of them.", P2),
     ]},
    {"id": "C-07", "name": "Transfer Agency", "area": "FOP",
     "definition": "Keeping the fund shareholder register and processing fund orders from the brokerage platform, plans, "
                   "intermediaries and fund-only accounts.",
     "l2": [
         _c("C-07.02", "Fund Order Processing & Settlement", "FOP", "29",
            ["15", "01", "27", "05", "28", "02", "16", "06", "49"], ["PF", "WR", "IC"], "Head of Transfer Agency",
            "Setting up dealers operationally, capturing fund orders from the brokerage platform's omnibus account, "
            "recordkeeping, Fund/SERV and platform channels and fund-only accounts, settling cash and transmitting prices "
            "and rates."),
         _c("C-07.03", "ETF Creation & Redemption Processing", "FOP", "29", ["02", "05", "24", "26", "27", "28"], ["PF"],
            "Head of ETF Operations",
            "Processing authorized participant creation and redemption orders against the published basket."),
         _c("C-07.04", "Shareholder Identity & AML Monitoring", "FOP", "29", ["02", "15", "38"], ["PF"], "BSA / AML Officer",
            "Verifying the identity of fund-only shareholders and monitoring their accounts for money laundering and "
            "fraud."),
         _c("C-07.05", "Sub-Accounting & Intermediary Reconciliation", "DIS", "06", ["15", "29", "05", "02"], ["PF", "IC"],
            "Head of Client & Channel Analytics",
            "Reconciling omnibus and sub-accounted positions and transactions from intermediaries to the transfer "
            "agency record."),
         _c("C-07.08", "Transfer Agency Oversight", "FOP", "29", ["13", "37", "35", "40"], ["PF"], "Head of Transfer Agency",
            "Monitoring transfer agency controls, service levels and exceptions, including those of an outsourced "
            "transfer agent."),
     ]},
    {"id": "C-08", "name": "Workplace Retirement Services", "area": "BWO",
     "definition": "Recordkeeping and administering the defined contribution plans the firm services, serving their "
                   "participants and capturing the rollovers that bring their savings into the direct business.",
     "l2": [
         _c("C-08.01", "Plan Onboarding & Investment Menus", "BWO", "16", ["02", "15", "05", "01"], ["WR"],
            "Head of Retirement Recordkeeping",
            "Setting up and converting plans, their documents, provisions, service and fee arrangements, and "
            "maintaining each plan's investment menu."),
         _c("C-08.02", "Participant Enrollment & Contributions", "BWO", "16", ["02", "15", "06"], ["WR"],
            "Head of Retirement Recordkeeping",
            "Enrolling participants, recording their elections and processing payroll contributions."),
         _c("C-08.03", "Loans, Withdrawals & Distributions", "BWO", "16", ["15", "06", "13", "02"], ["WR"],
            "Head of Retirement Recordkeeping",
            "Processing participant loans, hardship withdrawals, distributions and rollovers and applying vesting."),
         _c("C-08.04", "Plan Compliance Testing & Government Reporting", "BWO", "16", ["02", "15", "06", "08"], ["WR"],
            "Head of Retirement Recordkeeping",
            "Running nondiscrimination and limit testing, correcting plans and preparing Form 5500 and other "
            "government reporting."),
         _c("C-08.05", "Participant Communications", "BWO", "16", ["13", "04", "15", "02"], ["WR"],
            "Head of Retirement Recordkeeping",
            "Producing participant statements, required plan notices and fee disclosures, and education material."),
         _c("C-08.06", "CIT Plan Participation", "BWO", "05", ["02", "16", "01", "39"], ["PF", "WR"],
            "Head of Retirement Recordkeeping",
            "Confirming participating-plan eligibility and maintaining CIT participation agreements."),
         _c("C-08.07", "Rollover Capture & Participant Transition", "BWO", "16", ["02", "15", "45", "13", "04"],
            ["WR", "DB", "DA", "HA"], "Head of Workplace Solutions",
            "Identifying separating and retiring participants, offering them the firm's IRA and advice services and "
            "recording the rollovers that move their savings into the direct business.", W0),
         _c("C-08.08", "Plan Sponsor Relationship Management", "BWO", "16", ["02", "12", "05"], ["WR"],
            "Head of Workplace Solutions",
            "Managing each plan sponsor relationship: its decision makers, plan committee and plan advisor contacts, "
            "service reviews and renewals.", W0),
         _c("C-08.09", "In-Plan Managed Accounts & Advice", "BWO", "16", ["46", "45", "01", "15"], ["WR"],
            "Head of Workplace Solutions",
            "Recording participant enrollment in the plan's managed account and advice services and the investment "
            "elections those services direct.", W0),
     ]},
    {"id": "C-10", "name": "Product & Offering Management", "area": "CLA",
     "definition": "Deciding what the firm offers, from its own funds to its advice programs and brokerage platform, and "
                   "managing each offering through its lifecycle.",
     "l2": [
         _c("C-10.01", "Product Strategy & Range Planning", "CLA", "36", ["11", "10", "01", "06"], ALL, "Head of Product",
            "Assessing the fund range, advice programs and platform features against client demand, competition and "
            "economics to set product priorities."),
         _c("C-10.02", "New Product Approval & Launch", "CLA", "36",
            ["01", "35", "05", "14", "22", "27", "28", "29", "33", "41", "18", "43", "47"], ALL,
            "Head of Product Development",
            "Taking fund, advice service and platform feature proposals through business case, approval committee and "
            "launch readiness."),
         _c("C-10.03", "Product Changes & Corporate Events", "CLA", "36", ["01", "35", "13", "31", "06", "41"], ALL,
            "Head of Product Development",
            "Managing share class additions, fee changes, mergers, conversions and liquidations of funds and changes to "
            "advice programs and their terms."),
         _c("C-10.04", "Product Governance Reviews", "CLA", "36", ["32", "10", "08", "11", "21", "35"], ALL,
            "Head of Product Governance",
            "Running periodic reviews of funds and advice programs against performance, fees, client outcomes and "
            "competitors."),
         _c("C-10.05", "Product Reference Data & Registration", "CLA", "01", ["09", "02", "05", "41"], ALL, "Head of Product",
            "Maintaining the authoritative record of strategies, funds, share classes, mandates, model portfolios, "
            "investment restrictions, fee terms and service provider appointments, and their registrations and state "
            "notice filings for sale."),
         _c("C-10.06", "Product Documents & Commentary", "CLA", "01", ["31", "32", "27"], ["PF", "IA", "IC"],
            "Head of Product",
            "Maintaining prospectuses, summary prospectuses, fact sheets and market and investment commentary for each "
            "fund and strategy."),
         _c("C-10.07", "Benchmark Assignment", "CLA", "01", ["22", "14"], ALL, "Head of Product",
            "Defining the benchmarks and composites used for each strategy and product."),
         _c("C-10.09", "Competitive & Peer Analysis", "DIS", "11", ["01", "14", "02", "06"], ALL,
            "Head of Market Intelligence",
            "Comparing funds, advice programs and brokerage pricing with peers on performance, fees, ratings and flows."),
         _c("C-10.10", "Advice & Service Offering Management", "CLA", "01", ["47", "36", "08"], ["DA", "HA", "TR"],
            "Head of Advice Products",
            "Defining the advice programs and service tiers the firm offers, their eligibility rules and minimums and the "
            "fee schedules they reference.", W0),
         _c("C-10.11", "Brokerage Platform Offering", "CLA", "01", ["17", "52", "47"], ["DB", "DA", "HA"],
            "Head of Brokerage Products",
            "Setting the brokerage platform's tradable universe policy, the third-party funds and ETFs it offers, "
            "fractional and extended-hours eligibility and access to alternative investments through feeder funds.", W0),
     ]},
    {"id": "C-11", "name": "Intermediary & Institutional Distribution", "area": "DIS",
     "definition": "Winning and serving assets in the firm's funds, models and mandates through third-party advisors, "
                   "platforms, consultants and institutions.",
     "l2": [
         _c("C-11.04", "Sales Coverage & Pipeline", "DIS", "05", ["02", "04", "01"], ["IA", "IC"],
            "Head of Intermediary Distribution",
            "Planning coverage of intermediary firms, consultants and institutions, logging interactions and managing "
            "opportunities through the pipeline."),
         _c("C-11.05", "RFP, DDQ & Consultant Database Management", "DIS", "05", ["01", "02", "08", "11"], ["IA", "IC"],
            "Head of Institutional Sales",
            "Answering RFPs and due diligence questionnaires and keeping consultant database profiles current."),
         _c("C-11.08", "Intermediary Agreements & Platform Placement", "DIS", "05", ["02", "01", "39", "08"], ["IC"],
            "Head of Intermediary Distribution",
            "Negotiating selling, platform and model delivery agreements with third-party firms and tracking which funds "
            "and models each platform offers."),
         _c("C-11.09", "Intermediary Payments", "DIS", "05", ["06", "01", "02", "19"], ["IC"],
            "Head of Intermediary Distribution",
            "Calculating revenue sharing, servicing fees and 12b-1 payments owed to intermediary platforms."),
         _c("C-11.15", "Relationship & Mandate Servicing", "DIS", "12", ["02", "05", "01", "15", "26", "28"], ["IA", "WR"],
            "Head of Institutional Client Service",
            "Assigning service teams to institutional and OCIO clients and plan sponsors, setting up and transitioning "
            "mandates and handling client reviews and requests."),
         _c("C-11.16", "Client Reporting", "DIS", "12", ["32", "18", "31", "27", "33", "34", "42"], ["IA", "WR"],
            "Head of Client Reporting",
            "Producing and delivering performance, holdings and guideline reports to institutional clients, consultants "
            "and plan sponsors."),
         _c("C-11.19", "Intermediary Firm & Advisor Profiles", "DIS", "05", ["02", "14", "09"], ["IA", "IC"],
            "Head of Intermediary Distribution",
            "Maintaining the profiles and hierarchy of the intermediary firms, offices and third-party advisors the firm "
            "sells through and of the consultants it works with.", W0),
     ]},
    {"id": "C-12", "name": "Risk, Compliance & Legal", "area": "CORP",
     "definition": "Protecting the firm through enterprise risk management, regulatory compliance, legal services and "
                   "independent audit.",
     "l2": [
         _c("C-12.01", "Risk & Control Assessment", "CORP", "37", ["09", "21", "39", "41"], ALL, "Head of Operational Risk",
            "Maintaining the risk taxonomy, register and appetite, assessing risks and controls through self-assessment "
            "and tracking key risk indicators."),
         _c("C-12.02", "Incident & Loss Event Management", "CORP", "37",
            ["27", "26", "29", "25", "13", "16", "33", "31", "41", "44", "19", "48", "49", "50"], ALL,
            "Head of Operational Risk",
            "Recording operational incidents, their regulatory notifications and losses and tracking the resulting "
            "issues and actions."),
         _c("C-12.03", "Operational Resilience & Business Continuity", "CORP", "37", ["41", "40", "21"], ALL,
            "Head of Operational Resilience",
            "Mapping important business services and planning and testing recovery from disruption."),
         _c("C-12.04", "Model Risk Management", "CORP", "37", ["31", "21", "41", "02"], ALL, "Head of Model Risk",
            "Keeping the model inventory and validating, tiering and monitoring models used across the firm."),
         _c("C-12.05", "Internal Audit", "CORP", "37", ["38", "39", "35", "41", "19"], ALL, "Chief Audit Executive",
            "Planning and performing independent audits of the firm's activities and tracking findings to closure."),
         _c("C-12.06", "Regulatory Registrations, Exams & Change", "CORP", "38", ["09", "11", "39", "37", "17", "18"], ALL,
            "Chief Compliance Officer",
            "Maintaining firm registrations, including the broker-dealer's FINRA membership and the adviser's Form ADV "
            "and Form CRS filings, firm filings and the regulatory obligations register, managing regulatory exams and "
            "inquiries and tracking regulatory change."),
         _c("C-12.07", "Code of Ethics & Conflicts", "CORP", "38", ["20", "17", "02"], ALL, "Chief Compliance Officer",
            "Administering personal trading, political contribution, outside activity and conflict of interest rules "
            "for employees and the firm."),
         _c("C-12.08", "AML & Sanctions Program", "CORP", "38", ["02", "29", "15", "40", "50"], ALL, "BSA / AML Officer",
            "Setting firm-wide anti-money laundering, customer identification and sanctions policy for the adviser and "
            "the broker-dealer under FINRA Rule 3310, screening and reporting."),
         _c("C-12.09", "Trade Surveillance & Compliance Testing", "CORP", "38", ["25", "08", "37", "17", "48"], ALL,
            "Chief Compliance Officer",
            "Surveilling portfolio and client trading for market abuse and testing that compliance policies work as "
            "designed."),
         _c("C-12.10", "Contract Management", "CORP", "39",
            ["05", "14", "40", "01", "10", "16", "26", "28", "35", "43", "44", "02", "52"], ALL, "General Counsel",
            "Keeping the enterprise contract repository and tracking contract terms, renewals and obligations."),
         _c("C-12.11", "Legal Matters & Holds", "CORP", "39", ["02", "19", "38", "21", "41", "08", "20"], ALL, "General Counsel",
            "Managing litigation and legal matters and applying legal holds to records."),
         _c("C-12.12", "Corporate Secretarial & Entity Governance", "CORP", "39", ["09", "20", "38", "42", "43", "37"], ALL,
            "Company Secretary",
            "Governing internal legal entities, their boards, resolutions, officers and signing authorities, and "
            "protecting trademarks."),
         _c("C-12.13", "Third-Party Risk Assessment", "CORP", "37", ["40", "14", "41", "02"], ALL, "Head of Third-Party Risk",
            "Assessing the residual risk of suppliers and outsourced providers by risk domain and tracking the issues it "
            "raises.", S5),
         _c("C-12.14", "Policy Library & Attestations", "CORP", "38", ["20", "39", "37"], ALL, "Chief Compliance Officer",
            "Maintaining the firm's policies and their versions, collecting employee attestations and reviewing the "
            "compliance program.", S5),
         _c("C-12.15", "Restricted Lists & Information Barriers", "CORP", "38", ["23", "34", "17", "20"], ALL,
            "Chief Compliance Officer",
            "Escalating material nonpublic information, maintaining restricted, watch and insider lists and enforcing "
            "information barriers.", S5),
         _c("C-12.16", "Records Retention Management", "CORP", "08", ["21", "39", "41"], ALL, "Head of Records Management",
            "Maintaining the enterprise records retention schedule, including the broker-dealer's Rule 17a-4 retention "
            "periods, and the retention class applied to each kind of record.", S5),
         _c("C-12.17", "Privacy Program", "CORP", "02", ["08", "39"], ALL, "Privacy Officer",
            "Recording the privacy regimes, personal data categories and opt-outs that apply to each client under "
            "Regulation S-P and state privacy laws, answering consumer privacy requests and scheduling the erasure of "
            "personal data.", P2),
     ]},
    {"id": "C-13", "name": "Corporate Management", "area": "CORP",
     "definition": "Running the firm's finances, capital, people, suppliers, reputation and workplace.",
     "l2": [
         _c("C-13.01", "General Ledger & Financial Close", "CORP", "19", ["09", "10", "22", "01", "43"], ALL,
            "Finance Controller",
            "Maintaining the chart of accounts and entity ledgers and closing, consolidating and reporting the books."),
         _c("C-13.02", "Payables & Receivables", "CORP", "19", ["40", "47", "05", "13", "14", "02", "43"], ALL,
            "Finance Controller",
            "Paying suppliers and partners and collecting fees and other amounts owed to the firm."),
         _c("C-13.03", "Revenue Accounting", "CORP", "19", ["27", "47", "10"], ALL, "Finance Controller",
            "Recognizing management, advisory, brokerage and account fee revenue at entity level."),
         _c("C-13.04", "Financial Planning & Analysis", "CORP", "19", ["10", "20", "06"], ALL, "Head of FP&A",
            "Budgeting, forecasting and analyzing the firm's financial results."),
         _c("C-13.05", "Corporate Tax", "CORP", "19", ["09", "10", "02"], ALL, "Head of Tax",
            "Calculating, filing and paying the firm's own corporate taxes and documenting transfer pricing."),
         _c("C-13.06", "Corporate Cash, Funding & Hedging", "CORP", "43", ["19", "09", "02", "10", "22", "25", "26"], ALL,
            "Group Treasurer",
            "Managing corporate bank accounts, cash, funding and intercompany balances and hedging the firm's own "
            "exposures."),
         _c("C-13.07", "Seed & Co-Investment Capital", "CORP", "43", ["36", "18", "01", "27", "29", "15"], ["PF", "IA"],
            "Group Treasurer",
            "Allocating, tracking and hedging firm capital invested in the firm's own funds and strategies."),
         _c("C-13.08", "Workforce & Talent Management", "CORP", "20", ["09", "19", "02", "08"], ALL,
            "Chief Human Resources Officer",
            "Maintaining the employee record and organization and recruiting, developing and assessing employees."),
         _c("C-13.09", "Compensation & Benefits", "CORP", "20", ["03", "19", "01", "16"], ALL, "Chief Human Resources Officer",
            "Setting pay and running payroll inputs, bonuses, deferred awards and benefits for all employees."),
         _c("C-13.10", "Procurement & Supplier Management", "CORP", "40", ["02", "19", "39", "14", "13", "28", "01"], ALL,
            "Head of Procurement",
            "Sourcing and buying goods and services and tiering and monitoring supplier performance, spend and "
            "criticality."),
         _c("C-13.11", "Corporate Brand & Communications", "CORP", "42", ["04", "39", "37", "41", "44", "20", "34", "43"], ALL,
            "Head of Corporate Communications",
            "Governing the corporate brand and managing media, internal and crisis communications, corporate "
            "publications and corporate events."),
         _c("C-13.12", "Real Estate & Facilities Management", "CORP", "44", ["09", "19", "39", "40", "02"], ALL,
            "Head of Corporate Real Estate",
            "Managing sites, leases, space and facilities and recording the utility consumption of each site."),
         _c("C-13.13", "Outsourcing & Critical Vendor Register", "CORP", "40", ["37", "41", "39", "14", "02"], ALL,
            "Head of Procurement",
            "Keeping the register of outsourced and critical service providers with their exit plans and the regulator "
            "notifications they require.", S5),
         _c("C-13.14", "Net Capital & Regulatory Capital", "CORP", "43", ["19", "38", "37", "09", "49"], ALL,
            "Head of Regulatory Capital",
            "Calculating the broker-dealer's net capital under Rule 15c3-1 and the capital requirements of the other "
            "regulated entities and notifying regulators of capital adequacy events.", S5),
         _c("C-13.15", "Corporate Insurance", "CORP", "43", ["37", "39", "41", "35", "02"], ALL, "Group Treasurer",
            "Placing the firm's corporate insurance program and managing its coverage layers and claims.", S5),
         _c("C-13.16", "Government Relations & Lobbying Disclosure", "CORP", "42", ["02", "38", "09"], ALL,
            "Head of Government Relations",
            "Setting public policy positions, responding to consultations, recording contacts with officials and "
            "filing lobbying registrations and disclosure reports.", S5),
         _c("C-13.17", "Travel & Expense Management", "CORP", "44", ["20", "19", "08", "38", "02"], ALL, "Finance Controller",
            "Booking employee travel, issuing corporate cards and processing expense reports against expense policy "
            "limits.", S5),
         _c("C-13.18", "Physical Security, Health & Safety", "CORP", "44", ["20", "09", "37", "02"], ALL,
            "Head of Workplace Services",
            "Controlling physical access to sites, registering visitors and recording physical security and health and "
            "safety incidents.", S5),
         _c("C-13.19", "Corporate Sustainability Reporting", "CORP", "44", ["09", "19", "34"], ALL,
            "Head of Corporate Sustainability",
            "Calculating the greenhouse gas emissions of the firm's own operations by entity, site and scope and "
            "supplying them to corporate sustainability reports and climate disclosures.", P2),
     ]},
    {"id": "C-14", "name": "Technology & Data", "area": "FDN",
     "definition": "Providing the systems, security, reference data and data governance the whole firm runs on.",
     "l2": [
         _c("C-14.01", "Application & IT Asset Management", "CORP", "41", ["02", "39", "21", "37"], ALL,
            "Chief Information Officer",
            "Keeping the inventory of applications, systems of record, interfaces and IT assets and their owners."),
         _c("C-14.02", "Information Security & Access Management", "CORP", "41", ["20", "14", "38", "02"], ALL,
            "Chief Information Security Officer",
            "Granting and reviewing system access, testing security and responding to vulnerabilities and security "
            "incidents."),
         _c("C-14.03", "Change & Project Portfolio Management", "CORP", "41", ["19", "36", "21", "38"], ALL,
            "Head of Enterprise PMO",
            "Prioritizing and tracking programs, projects and their milestones and scope."),
         _c("C-14.04", "Data Governance & Stewardship", "FDN", "21", ["20", "41", "09"], ALL, "Chief Data Officer",
            "Assigning data owners and stewards and governing critical data elements, the taxonomy and the business "
            "glossary."),
         _c("C-14.05", "Data Quality, Catalog & Lineage", "FDN", "21", ["41", "14", "06", "12"], ALL,
            "Head of Data Governance",
            "Defining data quality rules, measuring results and cataloging datasets and their lineage."),
         _c("C-14.06", "Business Intelligence & Data Products", "FDN", "21", ["06", "10", "11", "41"], ALL,
            "Chief Data Officer",
            "Managing governed data products, the KPI registry and the reports and dashboards built on them."),
         _c("C-14.07", "AI & Analytics Model Governance", "FDN", "21", ["37", "41"], ALL, "Chief Data Officer",
            "Registering and governing AI and analytics models and their permitted uses."),
         _c("C-14.08", "Enterprise Reference Data", "FDN", "09", ["14", "19", "41", "20", "02"], ALL,
            "Head of Enterprise Data Management",
            "Maintaining geographies, calendars, currencies, internal legal entities, org units, classification schemes "
            "and shared code lists."),
         _c("C-14.09", "Third-Party Data Licensing & Entitlements", "FDN", "14", ["40", "19", "41", "20", "01", "10", "02", "39"],
            ALL, "Head of Market Data",
            "Selecting data vendors, managing data licenses and costs and controlling and reporting who uses licensed "
            "data, including the real-time quote entitlements of clients."),
         _c("C-14.10", "IT Service & Incident Management", "CORP", "41", ["02", "20", "37", "38"], ALL,
            "Chief Information Officer",
            "Running IT services, resolving IT incidents and problems and approving and releasing changes to "
            "production.", S5),
     ]},
    # ---- W0 (wealth-manager rework): new L1 areas
    {"id": "C-15", "name": "Client & Account Management", "area": "CLA",
     "definition": "Knowing each client and household and opening and maintaining the accounts they hold.",
     "l2": [
         _c("C-15.01", "Client & Household Master", "CLA", "02", ["09", "13"], ALL, "Head of Client Data",
            "Maintaining the master record of clients and their households, joint owners, entities, minors and "
            "custodians, trusted contacts, authorized agents and beneficiaries, and the roles every party plays."),
         _c("C-15.02", "Client Onboarding, CIP & KYC", "CLA", "02", ["38", "15", "09", "04"], ALL,
            "Head of Client Onboarding",
            "Onboarding individuals, entities and institutions, verifying identity under the customer identification "
            "program and completing know-your-customer and beneficial ownership checks before accounts open."),
         _c("C-15.03", "Investor Profile Management", "CLA", "02", ["45", "15", "08"], RETAIL, "Head of Client Onboarding",
            "Capturing and refreshing each client's investment objectives, risk tolerance, time horizon, financial "
            "situation and tax status, which best-interest and suitability decisions rely on.", W0),
         _c("C-15.04", "Consent & Contact Preferences", "CLA", "02", ["04", "15", "01", "13"], ALL, "Privacy Officer",
            "Recording privacy consents, contact preferences and client restrictions on how parties may be "
            "contacted."),
         _c("C-15.05", "Account Opening & Maintenance", "CLA", "15", ["02", "01", "08", "16", "51"], ALL,
            "Head of Account Services",
            "Opening, maintaining and closing brokerage, advisory, retirement, education, trust, participant and "
            "fund-only accounts with their registrations, agreements, features and standing instructions."),
         _c("C-15.06", "Beneficiary, Election & RMD Management", "CLA", "15", ["02", "49", "50", "08"], RETAIL,
            "Head of Account Services",
            "Recording beneficiary and transfer-on-death designations, cost-basis method, margin, options and sweep "
            "elections and the required minimum distribution status of each account.", W0),
         _c("C-15.07", "Advisory Program Enrollment", "CLA", "15", ["01", "45", "46", "47"], ["DA", "HA", "TR"],
            "Head of Account Services",
            "Enrolling accounts in advice and managed account programs and recording the program agreement, service "
            "tier and enrollment dates.", W0),
     ]},
    {"id": "C-16", "name": "Advice & Planning", "area": "CLA",
     "definition": "Understanding each client's goals and giving the plans and recommendations that serve them, in the "
                   "client's best interest.",
     "l2": [
         _c("C-16.01", "Goals & Financial Planning", "CLA", "45", ["02", "15", "49", "14", "24", "37"], ADVICE,
            "Head of Financial Planning",
            "Recording client goals and building, versioning and reviewing financial plans with their assumptions, "
            "aggregated external assets and projections.", W0),
         _c("C-16.02", "Recommendations & Best-Interest Evidence", "CLA", "45", ["02", "15", "01", "47", "08", "37"],
            ["DB", "DA", "HA"], "Head of Advice",
            "Recording each recommendation, its rationale and the care-obligation and fiduciary evidence behind it under "
            "Regulation Best Interest and the Advisers Act.", W0),
         _c("C-16.03", "Rollover Analysis & Documentation", "CLA", "45", ["16", "02", "15", "47", "01"], ["DA", "HA", "WR"],
            "Head of Advice",
            "Comparing a client's plan and IRA options and documenting each rollover recommendation as DOL PTE 2020-02 "
            "requires.", W0),
         _c("C-16.04", "Advice Engagements & Reviews", "CLA", "45", ["02", "03", "15", "13"], ADVICE, "Head of Advice",
            "Recording advice engagements, their delivery channel (digital, phone, video or in person), the advisor "
            "assigned and the periodic reviews held with each client.", W0),
     ]},
    {"id": "C-17", "name": "Managed Accounts", "area": "CLA",
     "definition": "Managing client accounts to their assigned models at scale, with tax-aware rebalancing.",
     "l2": [
         _c("C-17.01", "Model Assignment & Account Targets", "CLA", "46", ["24", "01", "15", "02", "45"], MANAGED,
            "Head of Managed Account Operations",
            "Assigning a model portfolio to each managed account and household and recording account-level targets, "
            "restrictions and constraints.", W0),
         _c("C-17.02", "Drift Monitoring & Rebalancing", "CLA", "46", ["49", "24", "17", "15"], MANAGED,
            "Head of Managed Account Operations",
            "Measuring each account's drift from its targets, triggering rebalances and generating the trade proposals "
            "and batches handed to brokerage order management.", W0),
         _c("C-17.03", "Tax-Loss Harvesting & Asset Location", "CLA", "46", ["49", "15", "02", "17"], ["DA", "HA", "TR"],
            "Head of Managed Account Operations",
            "Deciding tax-loss harvests and asset location across a household's accounts and controlling wash sales "
            "under IRC section 1091.", W0),
         _c("C-17.04", "Managed Account Program Composites", "CLA", "46", ["32", "01", "15", "47"], MANAGED,
            "Head of Managed Account Operations",
            "Grouping managed accounts into program-level composites and keeping the program records that Rule 3a-4 and "
            "the wrap fee brochure rely on.", W0),
     ]},
    {"id": "C-18", "name": "Client Pricing & Billing", "area": "CLA",
     "definition": "Setting what clients pay for advice, brokerage and account services and billing it accurately.",
     "l2": [
         _c("C-18.01", "Fee Schedules & Pricing Tiers", "CLA", "47", ["01", "02", "15"], FEE_BILLED,
            "Head of Pricing & Billing",
            "Maintaining advisory, commission and account-service fee schedules, pricing tiers and the householding and "
            "breakpoint rules that apply them.", W0),
         _c("C-18.02", "Advisory Fee Calculation & Debiting", "CLA", "47", ["49", "15", "02", "46", "01"],
            ["DA", "HA", "TR"], "Head of Pricing & Billing",
            "Calculating advisory and managed account fees on billable assets, deducting them from client accounts and "
            "recording the custody-rule conditions on each deduction.", W0),
         _c("C-18.03", "Institutional Fee Billing & Invoicing", "CLA", "47", ["18", "01", "19"], ["IA"],
            "Head of Pricing & Billing",
            "Calculating and invoicing advisory fees for institutional and OCIO mandates."),
         _c("C-18.04", "Fee Waivers, Credits & Disclosures", "CLA", "47", ["02", "15", "13", "08"], FEE_BILLED,
            "Head of Pricing & Billing",
            "Approving fee waivers, credits and refunds, handling billing exceptions and recording the fee disclosures "
            "delivered to each client.", W0),
     ]},
    {"id": "C-19", "name": "Retail Conduct & Supervision", "area": "CLA",
     "definition": "Supervising the firm's recommendations, representatives and communications so that retail clients are "
                   "treated fairly under SEC and FINRA rules.",
     "l2": [
         _c("C-19.01", "Reg BI & Form CRS Compliance", "CLA", "08", ["45", "02", "15", "13", "38"], RETAIL,
            "Head of Retail Conduct",
            "Maintaining the firm's Regulation Best Interest policies and conflict mitigation and the record of Form CRS "
            "delivered to each retail client.", W0),
         _c("C-19.02", "Supervisory Review & Surveillance", "CLA", "08", ["45", "48", "49", "15", "03"], RETAIL,
            "Head of Retail Supervision",
            "Reviewing accounts, recommendations and transactions under FINRA Rules 3110 and 3120 and working the "
            "surveillance alerts they raise.", W0),
         _c("C-19.03", "Complaints & Senior Investor Protection", "CLA", "08", ["02", "13", "50", "03"], RETAIL,
            "Head of Retail Supervision",
            "Recording and reporting client complaints under FINRA Rule 4530 and the temporary holds and trusted contact "
            "outreach used to protect senior and vulnerable investors under Rule 2165.", W0),
         _c("C-19.04", "Communications Review", "CLA", "08", ["04", "01"], ALL, "Head of Advertising Review",
            "Approving retail communications, advertisements and social media content under FINRA Rule 2210 and the "
            "Advisers Act marketing rule.", W0),
         _c("C-19.05", "Representative Licensing & Registration", "CLA", "08", ["03", "20", "38"], ALL,
            "Head of Registration & Licensing",
            "Registering the firm's representatives on Forms U4 and U5 and tracking their qualification exams, IAR "
            "registrations and continuing education.", W0),
         _c("C-19.06", "Options & Margin Approval Oversight", "CLA", "08", ["15", "02", "49", "48"], ["DB", "HA"],
            "Head of Retail Supervision",
            "Reviewing options level and margin approvals against each client's profile and supervising the accounts "
            "that use them.", W0),
     ]},
    {"id": "C-20", "name": "Advisor Workforce", "area": "CLA",
     "definition": "Organizing the firm's own advisors and representatives, assigning clients to them and rewarding their "
                   "work.",
     "l2": [
         _c("C-20.01", "Advisor Organization & Supervisory Structure", "CLA", "03", ["20", "09", "08"], RETAIL,
            "Head of Advisor Workforce",
            "Maintaining the firm's advisors and representatives, their teams, branches and offices of supervisory "
            "jurisdiction and the supervisor assigned to each.", W0),
         _c("C-20.02", "Client Assignment, Advisor Capacity & Activity", "CLA", "03", ["02", "15", "01", "06", "04", "13"],
            ["DB", "HA", "TR", "IA", "IC"],
            "Head of Advisor Workforce",
            "Assigning clients and households to advisors and service teams under the firm's service models, tracking "
            "each advisor's capacity and book and recording advisors' client activities, interactions and channel "
            "referrals.", W0),
         _c("C-20.03", "Advisor Goals & Incentive Compensation", "CLA", "03", ["06", "20", "02", "01", "45"], ALL,
            "Head of Sales Compensation",
            "Setting goals for advisors, representatives and intermediary sales staff and calculating the incentive "
            "payouts their results earn."),
     ]},
    {"id": "C-21", "name": "Client Service & Digital", "area": "CLA",
     "definition": "Acquiring clients and serving and communicating with them across digital, phone and in-person "
                   "channels.",
     "l2": [
         _c("C-21.01", "Client Acquisition & Marketing", "CLA", "04", ["08", "01", "02", "03", "41", "42"], ALL,
            "Head of Marketing",
            "Running direct-to-consumer campaigns, content and acquisition funnels, and scoring and routing the leads and "
            "prospects they produce."),
         _c("C-21.02", "Digital Experience & Engagement", "CLA", "04", ["02", "15", "41", "45"], RETAIL, "Head of Digital",
            "Recording digital identities, web and app sessions, personalization, nudges and experiments and measuring "
            "client satisfaction and net promoter scores.", W0),
         _c("C-21.03", "Client Service & Contact Center", "CLA", "13", ["15", "02", "29", "06", "49", "50"], SERVICED,
            "Head of Client Service",
            "Handling client calls, chats, secure messages and service requests for every account type, including "
            "dormant accounts and escheatment."),
         _c("C-21.04", "Statements, Confirmations & Tax Documents", "CLA", "13",
            ["06", "15", "27", "01", "02", "35", "48", "49"], SERVICED, "Head of Client Communications",
            "Producing account statements under FINRA Rule 2231, trade confirmations, tax documents, regulatory "
            "shareholder reports and fund proxy solicitations, with e-delivery and householding."),
     ]},
    {"id": "C-22", "name": "Trust Services", "area": "CLA",
     "definition": "Administering trusts and estates as a fiduciary through the firm's trust company.",
     "l2": [
         _c("C-22.01", "Trust Administration & Distributions", "CLA", "51", ["02", "15", "49", "50"], ["TR"],
            "Head of Trust Services",
            "Recording trust instruments, trustees, grantors and beneficiaries and deciding and documenting "
            "discretionary distributions.", W0),
         _c("C-22.02", "Trust Accounting & Fiduciary Tax", "CLA", "51", ["49", "15", "02"], ["TR"],
            "Head of Trust Services",
            "Keeping principal and income accounting for each trust and preparing fiduciary income tax returns on Form "
            "1041.", W0),
         _c("C-22.03", "Estate Settlement", "CLA", "51", ["02", "15", "49", "13"], ["TR", "DB", "DA", "HA"],
            "Head of Trust Services",
            "Managing estate settlement cases from notice of death through the transfer of assets to the "
            "beneficiaries.", W0),
     ]},
    {"id": "C-23", "name": "Brokerage & Clearing", "area": "BWO",
     "definition": "Taking client orders to market and keeping, settling, safeguarding and transferring the assets in "
                   "client accounts.",
     "l2": [
         _c("C-23.01", "Client Order Management & Routing", "BWO", "48", ["15", "17", "22", "49", "46", "01"], CARRIED,
            "Head of Brokerage Trading",
            "Capturing client orders in stocks, ETFs, options, bonds, CDs and funds, checking their eligibility and "
            "routing them to venues.", W0),
         _c("C-23.02", "Executions, Allocations & Confirmations", "BWO", "48", ["15", "17", "22", "49", "02"], CARRIED,
            "Head of Brokerage Trading",
            "Recording executions and fills, allocating them to accounts, issuing Rule 10b-10 confirmations and "
            "correcting or canceling trades.", W0),
         _c("C-23.03", "Execution Quality & CAT Reporting", "BWO", "48", ["22", "17", "02", "15"], CARRIED,
            "Head of Brokerage Trading",
            "Measuring execution quality, publishing the Rule 605 and 606 disclosures and reporting orders and their "
            "events to the Consolidated Audit Trail.", W0),
         _c("C-23.04", "Brokerage Book of Record", "BWO", "49", ["15", "17", "22", "48", "50", "29"], CARRIED,
            "Head of Brokerage Operations",
            "Keeping client holdings, tax lots and cost basis, cash and sweep balances and pending and settled activity "
            "for every brokerage account.", W0),
         _c("C-23.05", "Client Clearing & Settlement", "BWO", "49", ["48", "17", "29", "02", "43"], CARRIED,
            "Head of Brokerage Operations",
            "Clearing and settling client trades through NSCC and DTC, and fund trades through the transfer agent, on the "
            "T+1 cycle.", W0),
         _c("C-23.06", "Customer Protection & Reserve", "BWO", "49", ["43", "50", "17", "15"], CARRIED,
            "Financial and Operations Principal",
            "Computing the customer reserve under Rule 15c3-3, keeping client securities in possession and control and "
            "running the security counts and reconciliations that prove it.", W0),
         _c("C-23.07", "Account Transfers", "BWO", "49", ["15", "02", "17", "29"], CARRIED, "Head of Brokerage Operations",
            "Processing incoming and outgoing account transfers through ACATS under FINRA Rule 11870 and transfers "
            "outside ACATS.", W0),
         _c("C-23.08", "Margin & Fully Paid Lending", "BWO", "49", ["15", "22", "17", "02"], ["DB", "HA"],
            "Head of Margin & Credit",
            "Calculating margin requirements and calls under Regulation T and FINRA Rule 4210 and running the fully paid "
            "securities lending program.", W0),
         _c("C-23.09", "Client Asset Servicing & Cost Basis Reporting", "BWO", "49", ["17", "15", "13"], CARRIED,
            "Head of Brokerage Operations",
            "Posting corporate actions, dividends and interest to client accounts, reinvesting dividends and reporting "
            "cost basis on Form 1099-B.", W0),
     ]},
    {"id": "C-24", "name": "Money Movement & Cash", "area": "BWO",
     "definition": "Moving clients' money into and out of their accounts and managing the cash they hold.",
     "l2": [
         _c("C-24.01", "Money Movement Processing", "BWO", "50", ["15", "02", "43", "49"], RETAIL, "Head of Money Movement",
            "Processing ACH, wire, check and debit-card transactions into and out of client accounts against their "
            "standing instructions.", W0),
         _c("C-24.02", "Cash Sweep & Program Banks", "BWO", "50", ["15", "49", "01", "02", "43"], CARRIED,
            "Head of Cash Programs",
            "Running the bank sweep and money market sweep programs and allocating client cash among program banks "
            "within FDIC pass-through limits.", W0),
         _c("C-24.03", "Holds, Returns & Fraud Prevention", "BWO", "50", ["02", "15", "08", "38"], RETAIL,
            "Head of Money Movement",
            "Placing and releasing holds, handling returns and investigating suspected fraud and elder financial "
            "exploitation on money movements.", W0),
         _c("C-24.04", "Cash Movement AML Monitoring", "BWO", "50", ["02", "15", "38"], RETAIL, "BSA / AML Officer",
            "Monitoring money movements for suspicious activity and referring cases to the firm's AML program.", W0),
     ]},
    {"id": "C-25", "name": "Manager Oversight", "area": "INV",
     "definition": "Selecting, contracting and overseeing the external managers the firm hires and the third-party funds "
                   "it offers.",
     "l2": [
         _c("C-25.01", "Manager Research & Selection", "INV", "52", ["02", "32", "22", "14", "24"], PORTFOLIOS,
            "Head of Manager Research",
            "Searching, screening and scoring external managers and recommending them for sub-advisory mandates.", W0),
         _c("C-25.02", "Sub-Advisory Agreements & Mandate Guidelines", "INV", "52", ["01", "35", "39", "33"], ["PF"],
            "Head of Manager Research",
            "Maintaining sub-advisory agreements and the mandate guidelines given to each sub-adviser and compiling their "
            "Section 15(c) renewal data.", W0),
         _c("C-25.03", "Sub-Adviser Oversight Reviews", "INV", "52", ["32", "33", "31", "02"], PORTFOLIOS,
            "Head of Manager Research",
            "Running periodic oversight reviews of sub-advisers on performance, guideline compliance and operations and "
            "tracking their findings to closure.", W0),
         _c("C-25.04", "Third-Party Product Due Diligence", "INV", "52", ["17", "01", "32", "14", "22", "24"], ["DB", "DA", "HA"],
            "Head of Manager Research",
            "Reviewing third-party funds and ETFs for the brokerage platform and advice models and keeping the approved "
            "and watch lists.", W0),
     ]},
    {"id": "C-26", "name": "Client Assets, Economics & Insight", "area": "DIS",
     "definition": "Counting client assets and flows across every channel and measuring what clients and offerings earn "
                   "and cost.",
     "l2": [
         _c("C-26.01", "Client Assets & Net New Assets", "DIS", "06", ["49", "29", "15", "02", "01", "05", "16", "04", "03"],
            ALL, "Head of Client & Channel Analytics",
            "Summarizing client assets and transactions across every channel and attributing net new assets to channel, "
            "advisor, campaign and plan."),
         _c("C-26.02", "Client & Offering Profitability", "DIS", "10", ["19", "06", "47", "01", "27", "02", "05"], ALL,
            "Head of Client Economics",
            "Measuring revenue, cost to serve and profitability by client segment, channel and offering, and client "
            "lifetime value."),
         _c("C-26.03", "Market Intelligence & Sizing", "DIS", "11", ["14", "06", "02"], ALL, "Head of Market Intelligence",
            "Sizing the retail, advice and workplace markets and tracking industry flows, market share and competitors' "
            "offerings."),
     ]},
]

# Domains with no mastering L2 capability, with the reason. Empty when every domain masters at least one capability.
# The 07 and 30 rows were removed at the W2-W4 merge: 07 was retired by CW-907 (its coverage and incentive compensation
# moved to 03, C-20.03) and 30 by CW-930 (private markets manufacturing is out of scope; feeder-fund access to
# alternatives is a family of 01 and 15, C-10.11). A retired domain is not rendered and build_capability_map.py accepts
# COVERAGE_NOTES only for registered, non-retired domains; the numbers stay registered in domains.py and are never reused.
COVERAGE_NOTES = []

# Capabilities removed at W0 (the wealth-manager re-cut), as (id, name, wholesale mastering domain, successor, reason).
# Their pre-W0 CHANGELOG history is kept at git tag wholesale-v1.0.
REMOVED_W0 = [
    ("C-02.05", "SMA Customization & Tax Management", "24", "C-17.01, C-17.03",
     "Account-level restrictions and tax management of client accounts are mastered by 46 (CW-009); 24 keeps fund and "
     "institutional construction."),
    ("C-05.05", "Private Markets Performance", "32", "",
     "Private markets manufacturing is out of scope (CW-016); 30 is retired."),
    ("C-05.09", "Product Risk Indicator Calculation", "31", "",
     "PRIIPs SRI, UCITS SRRI and PRIIPs scenarios are EU/UK-only (CW-003); removed with the US-only pass of 31."),
    ("C-09.01", "Fund Formation & Closes", "30", "", "Private markets retired (CW-016)."),
    ("C-09.02", "Investor Commitments & Subscriptions", "30", "C-10.11",
     "Private markets retired (CW-016); feeder-fund access to alternatives is offered through the brokerage platform."),
    ("C-09.03", "Capital Calls, Distributions & Capital Accounts", "30", "", "Private markets retired (CW-016)."),
    ("C-09.04", "Deal Pipeline & Due Diligence", "30", "", "Private markets retired (CW-016)."),
    ("C-09.05", "Portfolio Company Monitoring", "30", "", "Private markets retired (CW-016)."),
    ("C-09.06", "Fund Financing", "30", "", "Private markets retired (CW-016)."),
    ("C-09.07", "Waterfall & Carried Interest", "30", "", "Private markets retired (CW-016)."),
    ("C-09.08", "Private Fund Investor Reporting", "30", "", "Private markets retired (CW-016)."),
    ("C-09.09", "Placement Agent Management", "05", "", "Private markets retired (CW-016); no placement agents."),
    ("C-10.08", "Insurance-Dedicated Fund Management", "01", "", "Insurance-dedicated funds are out of scope (CW-004)."),
    ("C-11.06", "DCIO Distribution", "03", "C-11.04",
     "The firm recordkeeps its own plans; selling investment-only to plans recordkept by others is part of the thin "
     "intermediary and institutional coverage of 05 (CW-013)."),
    ("C-11.12", "Distribution Compliance", "08", "C-19.01 to C-19.06",
     "08 is replaced by Retail Conduct & Supervision (CW-015); marketing review, licensing and complaints become "
     "C-19.04, C-19.05 and C-19.03; know-your-distributor, inducements and cross-border marketing are wholesale or EU/UK "
     "only."),
    ("C-11.17", "Insurer Reporting", "12", "", "Insurance-dedicated funds are out of scope (CW-004)."),
]

# L1 capability areas changed at W0, as (id, wholesale name and area, W0 name and area, reason). New L1s C-15 to C-26 are
# listed in CHANGELOG through their capabilities' "added" and "note" entries; C-09 Private Markets is removed (REMOVED_W0).
L1_CHANGES_W0 = [
    ("C-03", "Trading & Execution (Investment)", "Portfolio Trading & Execution (Investment)",
     "25 is renamed Portfolio Trading & Execution to separate it from client orders in 48 (CW-010)."),
    ("C-05", "Investment Oversight (Investment Operations)", "Investment Oversight (Investment Operations)",
     "Definition widened to the returns clients earn (C-05.10)."),
    ("C-07", "Transfer Agency & Investor Servicing (Fund Operations)", "Transfer Agency (Fund Operations)",
     "Accounts (15) and client service and communications (13) move to Client & Advice (C-15, C-21)."),
    ("C-08", "Retirement Plan Services (Fund Operations)", "Workplace Retirement Services (Brokerage & Workplace Operations)",
     "16 sits in Brokerage & Workplace Operations (CW-018, plan section 15 ruling 8) and adds rollover capture, plan sponsor "
     "relationships and in-plan managed accounts."),
    ("C-09", "Private Markets (Investment)", "removed", "Private markets manufacturing is out of scope (CW-016)."),
    ("C-10", "Product Management (Distribution & Client)", "Product & Offering Management (Client & Advice)",
     "01 and 36 add advice and service offerings and the brokerage platform offering (plan section 5.1)."),
    ("C-11", "Distribution & Client Servicing (Distribution & Client)",
     "Intermediary & Institutional Distribution (Distribution, Channels & Client Economics)",
     "The intermediary business is a channel (CW-013); client, account, marketing, service, flow, profitability, "
     "intelligence and incentive capabilities move to C-15, C-20, C-21 and C-26 (MOVED_W0)."),
    ("C-01", "Investment Research & Stewardship (Investment)", "Investment Research & Stewardship (Investment)",
     "Definition narrowed to the companies the firm's funds and mandates invest in."),
    ("C-02", "Portfolio Management (Investment)", "Portfolio Management (Investment)",
     "Definition widened to model portfolios; account-level management of client portfolios is 46's (C-17)."),
]

# Capabilities that changed L1 at W0 and so changed id: old id -> W0 id.
MOVED_W0 = {
    "C-07.01": "C-15.05", "C-07.06": "C-21.03", "C-07.07": "C-21.04",
    "C-11.01": "C-15.01", "C-11.02": "C-15.02", "C-11.03": "C-15.04", "C-11.07": "C-21.01", "C-11.10": "C-26.01",
    "C-11.11": "C-20.03", "C-11.13": "C-26.02", "C-11.14": "C-26.03", "C-11.18": "C-18.03",
}

# Step 5 coverage test, concept direction: master concepts in CONCEPT_OWNERSHIP that no capability covers, deliberately
# left uncovered, as (concept, owner domain, reason). Every other concept falls within the definition of a capability
# that its owner domain masters (or, where marked in GAP_NOTES, one it is read by).
UNCOVERED_CONCEPTS = [
    ("Funding Source (code list)", "05",
     "Reference data: a code list on partner payment arrangements, maintained with C-11.09 data but run by no function of "
     "its own."),
    ("Fund Advisory / Management Agreement", "01",
     "Stale register row: CD-232 superseded CD-022 and the agreement is mastered by 35 (Fund Advisory Agreement, ADVA-), "
     "covered by C-06.11. The 01 row should be retired from CONCEPT_OWNERSHIP (question for the program lead)."),
    ("Data Feed (technical) and Load", "06",
     "Technical lineage records of the 06 data pipeline; they support C-26.01 and C-07.05 but no business function owns "
     "them."),
]

# Step 5 gap findings, both directions, shown on the Overview sheet.
GAP_NOTES = [
    "W0 (wealth-manager re-cut): every capability names a registered Data Domain that masters its core data. The eight "
    "new domains 45-52 each master at least one capability, although their modules are drafted at W2 and W3; the reads "
    "of their capabilities are drawn from the plan's boundaries and are re-tested at the W5 coverage test. 07 and 30 "
    "master nothing and are explained in COVERAGE_NOTES (retired at W4).",
    "W0 concepts with no wholesale capability, now covered: investor profile (02, C-15.03); account elections, "
    "beneficiaries and RMD status (15, C-15.06); advisory program enrollment (15, C-15.07); advice and service offerings "
    "and the brokerage platform offering (01, C-10.10, C-10.11); goals, plans, recommendations, rollover analyses and "
    "advice engagements (45, C-16); managed account model assignment, rebalancing, tax management and composites (46, "
    "C-17); client fees and billing (47, C-18); retail conduct and supervision (08, C-19); the advisor organization and "
    "client assignment (03, C-20); digital engagement (04, C-21.02); client orders, executions and execution quality "
    "(48, C-23.01 to C-23.03); the brokerage book of record, clearing, customer protection, transfers, margin and client "
    "asset servicing (49, C-23.04 to C-23.09); money movement and cash programs (50, C-24); trust and estate services "
    "(51, C-22); manager and third-party product oversight (52, C-25); client account performance (32, C-05.10); "
    "rollover capture, plan sponsor relationships and in-plan managed accounts (16, C-08.07 to C-08.09); intermediary "
    "firm and advisor profiles (05, C-11.19).",
    "Capabilities with no mastering domain: none. Every L2 capability, including the 13 added at Step 5 and the four "
    "added at the Phase 2 review, names a drafted Data Domain that masters its core data.",
    "Concepts no Step 0 capability covered, now covered by capabilities added at Step 5: fund advisory agreements and "
    "15(c) renewals (35, C-06.11); third-party risk assessments (37, C-12.13); the policy library and attestations (38, "
    "C-12.14); restricted lists, MNPI escalations and insider lists (38, C-12.15); the records retention schedule (08, "
    "C-12.16); the outsourcing register (40, C-13.13); regulatory capital (43, C-13.14); corporate insurance (43, "
    "C-13.15); lobbying and government relations (42, C-13.16); travel and expense (44, C-13.17); physical security and "
    "health and safety (44, C-13.18); IT service, incident, problem, change and release records (41, C-14.10).",
    "Concepts covered by widening a definition rather than adding a capability: risk limits and exceedances (C-05.01), "
    "reference rate fixings and ETF market statistics (C-04.06), RIC qualification and exemptive relief (C-06.09), "
    "the obligations register moved to 38 (C-12.06), outside business activities (C-12.07), powers of attorney and "
    "signing authority (C-12.12), credit ratings (C-04.01), model portfolios, restrictions and service provider "
    "appointments (C-10.05), plan notices and fee disclosures (C-08.05), plan service and fee arrangements (C-08.01), "
    "price and rate transmission (C-07.02), corporate publications and events (C-13.11).",
    "Phase 2 review (2026-10-14): four capabilities that the per-area reviews found missing were added for concepts a real "
    "function runs: fund financial statements and financial highlights (27, C-06.12); trade errors and post-execution "
    "exceptions (25, C-04.10); privacy profiles and consumer privacy requests (02, C-12.17); operational greenhouse gas "
    "emissions (44, C-13.19, split from C-13.12, which had covered them by a widened definition).",
    "Concepts covered only as a read of another domain's capability: the 23 Research Evaluation Round (the broker vote) "
    "is part of C-01.04 Research Payment Management, mastered by 25.",
    "Deliberately uncovered reference data: see UNCOVERED_CONCEPTS (three entries).",
]

# Judgment calls in this map, shown on the Overview sheet for the client to confirm.
DRAFTING_NOTES = [
    "W0: business lines are the eight of CW-004. Capabilities of the investment value chain serve the portfolios the "
    "investment team runs (PF, IA); advice, brokerage and workplace lines reach them as holders of the firm's funds and "
    "models, so they are tagged only where they consume the capability's data directly (allocation views, models).",
    "W0: client account performance (C-05.10) is mastered by 32, which adds a Client Account Performance family (plan "
    "§5.1); it is run by the performance function in Investment Operations although its consumers sit in Client & "
    "Advice.",
    "W0: workplace (C-08) stays an L1 of its own in Brokerage & Workplace Operations (plan §15 ruling 8): its reads from "
    "15, 45 and 49 outweigh its reads from 29.",
    "W0: institutional fee billing (C-18.03) is re-pointed from 12 to 47 with the Fee Billing & Invoicing family (CW-012); "
    "12 keeps servicing and reporting (C-11.15, C-11.16).",
    "W0: sales coverage and RFPs (C-11.04, C-11.05) are re-pointed from 03 to 05, which becomes Intermediary & "
    "Institutional Distribution (CW-013); 03 becomes the firm's own advisor workforce and takes incentive compensation "
    "from 07 (C-20.03).",
    "W0: records retention (C-12.16) stays mastered by 08 although 08 is replaced by Retail Conduct & Supervision; the "
    "08 brief decides whether the schedule (with the Rule 17a-4 periods) stays in 08 or moves to 21 or 39 (question for "
    "the program lead at W2).",
    "Research payments (C-01.04) are mastered by 25 Trading & Execution, which masters commissions, research budgets and "
    "research payments, although the function sits with research; 23 masters the broker vote it reads.",
    "ETF capital markets (C-03.05) and CIT plan participation (C-08.06) are mastered by 05, since the authorized "
    "participant agreement and the CIT participation agreement are agreement types there (39 indexes both as typed "
    "contracts).",
    "Sub-accounting reconciliation (C-07.05) stays with 06, which masters the omnibus look-through, identifier crosswalk "
    "and reconciliation records; 29 did not claim it when drafted. W0: identity resolution in 06 is kept for "
    "intermediary data only (plan §5.1).",
    "Benchmark assignment (C-10.07) is mastered by 01, which defines benchmarks and assigns them to strategies and "
    "products; 32 masters only the Benchmark Return computed from 22 index levels (CD-217). Its function area is Client "
    "& Advice, with product management that runs it; performance in Investment Operations reads the assignment.",
    "Step 5: model delivery (C-02.04) is mastered by 24, which holds the model target allocations and model change "
    "summaries that are delivered; 01 keeps the model definition and 05 the platform placement.",
    "Step 5: fund service provider oversight (C-06.10) is mastered by 40, which holds the supplier engagements, "
    "contracted service levels, performance reviews and outsourcing arrangements of administrators, custodians and "
    "transfer agents; 35 reads the results for board reporting.",
    "Phase 2 review: cash and position reconciliation (C-06.05) stays mastered by 28 and sited in Fund Operations. "
    "Boundary: 28 masters the reconciliation and break records against custodian statements; 18 (IBOR) and 27 (ABOR) "
    "are the books reconciled. Many firms run the IBOR-to-custodian reconciliation in the middle office, in which case "
    "the client may site it in Investment Operations without changing the data. W0: client security counts and "
    "reconciliations are 49's (C-23.06).",
    "Phase 2 review: fair value and valuation oversight (C-04.05) stays mastered by 22 and sited in Investment "
    "Operations with the pricing and valuation function. At many fund complexes the fund treasurer leads the valuation "
    "designee's committee under Rule 2a-5, in which case the client may show it with Fund Operations; 35 records the "
    "board's oversight and references the 22 fair value determinations.",
    "Phase 2 review: privacy program (C-12.17) is mastered by 02, which holds privacy profiles, consent records and "
    "privacy requests; 38 masters no privacy record. Consent and contact preferences stay a separate capability (C-15.04) "
    "run by marketing and client data.",
    "Phase 2 review: corporate sustainability reporting (C-13.19) is mastered by 44, which masters the Operational "
    "Emission Record (CD-281); 42 publishes the figures in the corporate responsibility report through Publication "
    "Source Links and 34 copies the entity totals into its entity-level indicators.",
]

# Every change to the map, as (capability, field, before, after, reason). Fields: masters, reads, lines, name, definition,
# added (a new capability), area (function area), note (a finding checked and kept, or a W0 move of id). owner_role was
# added to every capability at Step 5. Pre-W0 entries of a capability that moved at W0 carry its W0 id (MOVED_W0).
CHANGELOG = [
    # ---- Re-pointed mastering domain
    ("C-02.04", "masters", "01", "24",
     "The delivered content is the model target allocation set and its model change summary, mastered by 24; 01 keeps the "
     "model definition (MDL-) and 05 the Model Program Placement."),
    ("C-06.10", "masters", "35", "40",
     "Supplier engagements, contracted service levels, service level results, performance reviews and outsourcing "
     "arrangements of fund administrators, custodians and transfer agents are mastered by 40; 35 holds no oversight "
     "record and reads the results for board reports."),
    ("C-08.05", "masters", "13", "16",
     "Plan notices and fee disclosures (PNTC-: 408(b)(2), 404(a)(5), safe harbor, QDIA, blackout) are mastered by 16; 13 "
     "holds no participant-specific record and is read for production and delivery."),
    # ---- Added at Step 5
    ("C-06.11", "added", "", "35", "CD-232 moved the fund advisory agreement (ADVA-) and its 15(c) renewals (RENEW-) to 35, "
     "superseding CD-022 (01). Run by fund legal; renewal materials read 10, 11 and 32."),
    ("C-12.13", "added", "", "37", "37 masters Third-Party Risk Assessment and its domain results (CD-090 resolved across "
     "37, 40 and 14). Run by third-party risk, separately from procurement."),
    ("C-12.14", "added", "", "38", "38 masters Policy, Policy Version, Attestation (moved from 08, CD-252) and Compliance "
     "Program Review; no Step 0 capability covered the policy library."),
    ("C-12.15", "added", "", "38", "38 masters the Firm Restricted List, Restricted List Entry, MNPI Escalation and Insider "
     "List Entry (CD-255, CD-256); 23, 30 and 34 escalate to it and 33 codes it into pre-trade rules."),
    ("C-12.16", "added", "", "08", "08 masters the enterprise Records Retention Rule (CD-062), read by 02, 03, 12, 13, 21 "
     "and 39; records management runs it."),
    ("C-13.13", "added", "", "40", "40 masters the Outsourcing Arrangement, Outsourcing Notification and the DORA register "
     "of information (CD-260, CD-261); 14 copies five fields."),
    ("C-13.14", "added", "", "43", "43 masters regulated entity capital profiles, capital requirement calculations, ICARA "
     "assessments and capital adequacy notifications (CD-277); split from C-13.06 because a different role owns it."),
    ("C-13.15", "added", "", "43", "43 masters Corporate Insurance Policy, Insurance Coverage Layer and Insurance Claim; no "
     "Step 0 capability covered them."),
    ("C-13.16", "added", "", "42", "42 masters public policy positions, consultation responses, government official "
     "contacts, trade associations and the lobbying registrations and disclosure reports; run by government relations."),
    ("C-13.17", "added", "", "44", "44 masters expense reports and lines, corporate cards, card transactions, travel "
     "bookings and expense policy limits; split from C-13.12 because finance, not real estate, runs it."),
    ("C-13.18", "added", "", "44", "44 masters access badges, zone grants, visitor registrations, physical security and "
     "health and safety incidents, workplace risk assessments and emergency roles; run by workplace services."),
    ("C-14.10", "added", "", "41", "41 masters IT services, IT incidents, problem records, change requests, change "
     "approvals, releases and deployments; no Step 0 capability covered IT service management."),
    # ---- Renamed or widened
    ("C-12.06", "definition", "registrations, exams, change", "+ entity authorizations, firm filings, obligations register",
     "Entity authorizations and passports moved from 09 (CD-250) and the obligations register from 08 (CD-252) to 38."),
    ("C-06.08", "definition", "fund boards, CIT trustee committees, 15(c)", "fund boards, CIT trustee committees, LPACs",
     "15(c) renewals moved to C-06.11; 35 also governs private fund LPACs."),
    ("C-13.06", "name", "Treasury & Regulatory Capital", "Corporate Cash, Funding & Hedging",
     "Regulatory capital split out to C-13.14; 43 masters treasury deals and hedge relationships."),
    ("C-13.10", "name", "Procurement & Third-Party Risk", "Procurement & Supplier Management",
     "Third-party risk assessment is 37's (C-12.13) and the outsourcing and DORA registers are split out (C-13.13)."),
    ("C-13.11", "name", "Corporate Communications & Public Affairs", "Corporate Brand & Communications",
     "Brand register moved from 04 to 42 (CD-271); government relations split out to C-13.16."),
    ("C-13.12", "name", "Workplace & Travel Services", "Real Estate & Facilities Management",
     "Travel and expense (C-13.17) and physical security (C-13.18) split out; 44 masters sites, leases and facilities."),
    ("C-01.01", "definition", "", "+ internal credit assessments", "23 masters internal credit assessments (Rule 2a-7)."),
    ("C-01.03", "definition", "", "+ wall crossings and MNPI flags", "23 Issuer Meeting holds the MNPI flag (CD-255)."),
    ("C-02.01", "definition", "", "+ glide paths", "24 masters asset allocation policies and glide path points."),
    ("C-04.01", "definition", "", "+ credit ratings", "17 masters credit rating assignments."),
    ("C-04.06", "definition", "", "+ reference rate fixings, ETF market statistics", "22 masters both."),
    ("C-04.09", "definition", "", "+ funds, client mandates", "26 widened SSIs to fund, portfolio and counterparty (CD-155)."),
    ("C-05.01", "definition", "", "+ risk limits", "31 masters risk limits, utilization and exceedances."),
    ("C-05.03", "definition", "", "+ account", "32 masters account-level returns."),
    ("C-06.01", "definition", "disseminating", "releasing", "27 masters NAV releases; 29 masters the per-channel transmission."),
    ("C-06.09", "definition", "", "+ RIC qualification, exemptive relief", "35 masters both."),
    ("C-07.02", "definition", "", "+ price and rate transmission", "29 masters Price & Rate Transmission."),
    ("C-08.01", "definition", "", "+ service and fee arrangements", "16 masters PSVA- and PFEE-."),
    ("C-08.04", "definition", "", "+ plan corrections", "16 masters EPCRS / VFCP plan corrections."),
    ("C-10.05", "definition", "", "+ model portfolios, restrictions, provider appointments, target markets",
     "01 concepts with no explicit capability at Step 0."),
    ("C-12.01", "definition", "", "+ appetite, key risk indicators", "37 masters risk appetite statements and KRIs."),
    ("C-12.02", "definition", "", "+ regulatory notifications", "37 masters incident regulatory notifications (DORA, SUP 15)."),
    ("C-12.04", "definition", "", "+ monitoring", "37 masters model performance monitoring."),
    ("C-12.07", "definition", "", "+ outside activities, firm conflicts", "38 masters outside business activities and the firm conflicts register."),
    ("C-12.12", "definition", "", "+ signing authorities", "39 masters powers of attorney and signing authority grants."),
    ("C-13.01", "definition", "", "+ consolidating", "19 masters consolidation scope and intercompany balances."),
    ("C-13.05", "definition", "", "+ transfer pricing", "19 masters transfer pricing documentation."),
    ("C-13.09", "definition", "", "+ material risk takers, deferred awards", "20 masters both."),
    ("C-08.05", "definition", "", "+ plan fee disclosures", "16 masters plan notices and fee disclosures (PNTC-)."),
    ("C-13.06", "definition", "", "+ bank accounts and hedging; - regulatory capital", "Follows the rename and the C-13.14 split."),
    ("C-13.10", "definition", "", "+ spend and criticality; - third-party risk", "Follows the rename and the C-12.13 and C-13.13 splits."),
    ("C-13.11", "definition", "", "+ publications and events; - policymakers", "Follows the rename and the C-13.16 split."),
    ("C-13.12", "definition", "", "+ leases, space, operational emissions; - travel and expenses", "Follows the rename and the C-13.17 and C-13.18 splits."),
    ("C-14.01", "definition", "", "+ interfaces", "41 masters application interfaces."),
    ("C-14.02", "definition", "", "+ security tests, vulnerabilities", "41 masters both."),
    ("C-14.03", "definition", "IT changes", "milestones and scope", "IT changes moved to C-14.10; 41 masters project milestones and the Project Scope Link."),
    ("C-14.04", "definition", "", "+ the taxonomy", "21 masters the taxonomy element register."),
    ("C-14.08", "definition", "", "+ classification schemes", "09 masters industry classification schemes (ICS-)."),
    # ---- Business lines
    ("C-01.03", "lines", "all", "MF, ETF, CIT, SMA, IDF",
     "23 issuer meetings are with public issuers; private markets meets portfolio company management under 30."),
    ("C-01.06", "lines", "all", "MF, ETF, CIT, SMA, IDF",
     "34 votes proxies on public holdings; private fund investments carry no proxy ballot."),
    ("C-06.08", "lines", "MF, ETF, CIT, IDF", "MF, ETF, CIT, IDF, PM", "35 governs private fund LPACs."),
    ("C-07.08", "lines", "MF, CIT", "MF, ETF, CIT, IDF",
     "29 TA control checks cover every TA-processed line: IDF orders and ETF AP orders as well."),
    # ---- Reads (evidence: cross-domain references in the content modules and the enrichment summaries)
    ("C-01.01", "reads", "17, 22, 14, 34", "17, 02, 22, 14", "+02 issuers and providers; -34, which reads 23, not the reverse."),
    ("C-01.02", "reads", "22, 17, 31, 14", "22, 17, 14, 21", "+21 AI use cases on signals; -31, not referenced by 23."),
    ("C-01.03", "reads", "17, 02", "17, 02, 38", "+38 MNPI escalation (CD-255)."),
    ("C-01.05", "reads", "17, 14, 23, 18, 01, 12, 35", "17, 14, 02, 18, 01, 22, 30, 37",
     "+02 issuers, +22 and +30 EVIC inputs, +37 models (CD-246); -23, -12, -35, which read 34."),
    ("C-01.06", "reads", "18, 17, 23, 02", "18, 17, 28, 02, 23, 13, 15",
     "+28 entitlements and loan recalls, +13 own-fund proxy campaigns, +15 voting authority by account."),
    ("C-02.01", "reads", "23, 22, 31", "01, 23, 18, 30",
     "+01 strategies and benchmarks, +18 portfolios, +30 private investment approvals; -22, -31, not referenced by 24."),
    ("C-02.02", "reads", "18, 31, 22, 33, 17, 29, 27, 30", "18, 01, 17, 22, 15, 12, 30",
     "+01, +15 SMA accounts, +12 transition events; -31, -33 (33 reads 24's proposed trades), -29, -27."),
    ("C-02.03", "reads", "01, 18, 22", "01, 18, 17", "+17 instruments in target lines; -22."),
    ("C-02.04", "reads", "24, 05, 02", "01, 05, 02", "Re-pointed to 24; reads the 01 model definition in place of 24."),
    ("C-02.06", "reads", "18, 17, 22, 27", "18, 17, 01, 27", "+01 creation unit size; -22."),
    ("C-03.01", "reads", "24, 18, 17, 33", "24, 18, 17, 33, 15, 12, 38",
     "+15 SMA accounts, +12 transition events, +38 restricted list on order handling."),
    ("C-03.03", "reads", "02, 31, 26, 37", "02, 23, 26, 31", "+23 internal credit assessments in counterparty reviews; -37."),
    ("C-03.04", "reads", "22, 38", "22, 02", "+02 TCA providers; -38, which reads 25 for surveillance."),
    ("C-03.05", "reads", "02, 29, 22", "02, 29, 22, 24", "+24 ETF baskets."),
    ("C-04.01", "reads", "14, 22, 09, 02, 28", "02, 01, 14, 09", "+01 own share classes; -22, -28, which read 17."),
    ("C-04.02", "reads", "01, 15, 12, 09", "01, 15, 12, 05, 28, 09", "+05 sponsor programs, +28 safekeeping accounts (CD-194)."),
    ("C-04.04", "reads", "17, 14, 18", "17, 14, 02, 27", "+02 vendors and brokers, +27 own share class NAVs; -18."),
    ("C-04.05", "reads", "30, 35, 17, 18", "17, 18, 14, 37, 02",
     "+14 fair value factors, +37 valuation models (CD-246), +02 valuation agents; -30, -35, which read 22."),
    ("C-04.06", "reads", "14, 09, 01", "14, 09, 01, 17, 27", "+17 instruments, +27 own ETF NAVs for market statistics."),
    ("C-04.07", "reads", "25, 28, 02, 09", "25, 28, 02, 18, 17, 29, 09", "+18, +17, +29 in-kind AP basket deliveries."),
    ("C-04.08", "reads", "25, 31, 39, 28, 22", "25, 02, 17, 22, 18, 28",
     "+02 counterparties, +17 OTC products, +18; -31 (reads 26), -39 (indexes 26 agreements from its side)."),
    ("C-04.09", "reads", "12, 15, 28, 02", "12, 15, 28, 02, 18, 01", "+18 portfolios, +01 funds."),
    ("C-05.01", "reads", "18, 22, 17, 25, 26, 02", "18, 22, 17, 01, 14, 02, 23, 25, 26, 34, 37",
     "+01, +14, +23 credit assessments, +34 climate metrics, +37 risk models."),
    ("C-05.02", "reads", "18, 22, 29, 26, 35", "18, 22, 17, 27, 26, 35", "+17, +27 net assets; -29, not referenced by 31."),
    ("C-05.03", "reads", "18, 27, 22, 01", "18, 27, 22, 01, 15, 36", "+15 accounts, +36 product change initiatives."),
    ("C-05.04", "reads", "18, 22, 24, 31", "18, 22, 24, 31, 17, 37", "+17, +37 attribution models."),
    ("C-05.06", "reads", "01, 02, 12, 35", "01, 02, 34, 38, 36, 14, 17",
     "+34 exclusion lists, +38 restricted list, +36 product changes, +14, +17; -12, -35, which read 33."),
    ("C-05.07", "reads", "25, 18, 17, 24", "25, 18, 17, 24, 31, 38, 30",
     "+31 risk measures, +38 restricted list, +30 deals in pre-trade checks."),
    ("C-05.08", "reads", "12, 35, 37, 27", "25, 27, 18, 35, 17", "+25 trade errors, +18, +17; -12, -37, which read 33."),
    ("C-06.01", "reads", "18, 17, 22, 28, 01", "18, 17, 22, 28, 01, 29, 30, 26",
     "+29 fund orders, +30 capital calls, +26 settlement instructions."),
    ("C-06.02", "reads", "01, 19, 28, 13, 35, 18", "01, 19, 28, 17, 18", "+17 book-tax detail; -13, -35, which read 27."),
    ("C-06.03", "reads", "29, 31, 37, 35", "01, 29, 22", "+01 swing terms, +22 prices; -31, -37, -35, which read 27."),
    ("C-06.04", "reads", "02, 40, 15, 38", "02, 15, 18, 01, 38, 39", "+18, +01, +39 custody contracts; -40, which reads 28."),
    ("C-06.05", "reads", "18, 27, 26", "18, 27, 26, 17, 22, 29", "+17, +22, +29 on reconciliation breaks."),
    ("C-06.06", "reads", "17, 24, 18, 27", "17, 24, 18, 27, 01, 15", "+01 funds, +15 accounts on class actions."),
    ("C-06.07", "reads", "31, 02, 18, 25", "02, 18, 27, 01", "+27 revenue allocation, +01; -31, -25."),
    ("C-06.08", "reads", "39, 01, 20, 32, 10, 19, 09, 16", "01, 02, 20, 22, 27, 31, 33, 34, 36, 13",
     "Board reports and approvals read 22, 27, 31, 33, 34, 36 and 13; 10, 32 moved with 15(c) to C-06.11; -39, -19, -09, -16."),
    ("C-06.09", "reads", "18, 27, 31, 30, 17", "18, 27, 31, 30, 22, 24, 34, 17", "+22, +24 ETF baskets, +34 N-PX."),
    ("C-06.10", "reads", "40, 01, 37, 29", "01, 28, 29, 27, 13, 35, 37", "Re-pointed to 40; reads the overseen providers' records."),
    ("C-15.05", "reads", "02, 05, 29", "02, 05, 01, 28", "+01, +28 custodian account numbers; -29, which reads 15."),
    ("C-07.02", "reads", "15, 01, 27, 05, 28, 02", "15, 01, 27, 05, 28, 02, 16, 06", "+16 contribution batches, +06."),
    ("C-07.03", "reads", "02, 05, 24, 28", "02, 05, 24, 26, 27, 28", "+26 in-kind settlement, +27 NAVs."),
    ("C-07.05", "reads", "15, 29, 05", "15, 29, 05, 02", "+02 intermediaries."),
    ("C-21.03", "reads", "15, 02, 29", "15, 02, 29, 06", "+06 transactions on service requests."),
    ("C-07.08", "reads", "37, 35, 40", "13, 37, 35, 40", "+13 TA service levels and servicing errors."),
    ("C-08.01", "reads", "02, 15, 05, 39, 01, 36", "02, 15, 05, 01", "-39, -36, not referenced by 16."),
    ("C-08.02", "reads", "02, 15, 29, 06", "02, 15, 06", "-29, which reads 16 contribution batches."),
    ("C-08.03", "reads", "15, 29, 13", "15, 06, 13, 02", "+06, +02; -29."),
    ("C-08.04", "reads", "02, 15, 06", "02, 15, 06, 08", "+08 on plan corrections."),
    ("C-08.05", "reads", "16, 04, 15", "13, 04, 15, 02", "Re-pointed to 16; 13 produces and delivers."),
    ("C-08.06", "reads", "02, 16, 01", "02, 16, 01, 39", "+39 typed contract."),
    ("C-10.02", "reads", "01, 35, 08, 41, 29, 27", "01, 35, 05, 14, 22, 27, 28, 29, 33, 41, 18, 43",
     "Readiness checks reference 05, 14, 22, 27, 28, 29, 33; +18 seed portfolios, +43 seed capital; -08."),
    ("C-10.03", "reads", "01, 35, 13, 29, 27", "01, 35, 13, 31, 06, 41", "+31, +06 impact assessments, +41 projects; -29, -27."),
    ("C-10.04", "reads", "32, 10, 08, 27", "32, 10, 08, 11, 21, 35", "+11 peer studies, +21 metrics, +35; -27."),
    ("C-10.05", "reads", "09, 35, 36, 08", "09, 02, 05, 41", "+02, +05, +41 systems of record; -35, -36, -08, which read 01."),
    ("C-10.06", "reads", "31, 27, 32, 24, 39", "31, 32, 27", "-24, -39, not referenced by 01."),
    ("C-10.09", "reads", "01, 32, 14", "01, 14, 02, 06", "+02, +06; -32, not referenced by 11."),
    ("C-15.04", "reads", "04, 38", "04, 15, 01, 39", "+15, +01 client restrictions, +39 legal hold; -38."),
    ("C-11.05", "reads", "32, 31, 01, 38, 11", "01, 02, 08, 11", "+02, +08 compliance review; -32, -31, -38."),
    ("C-21.01", "reads", "08, 01, 02, 03, 41", "08, 01, 02, 03, 05, 41, 42", "+05, +42 brand register (CD-271)."),
    ("C-11.08", "reads", "02, 39, 01, 11", "02, 01, 39, 08", "+08 inducements; -11."),
    ("C-11.09", "reads", "06, 10, 19", "06, 01, 02, 19", "+01, +02; -10, which reads 05."),
    ("C-26.01", "reads", "15, 07, 02, 29, 30", "15, 07, 02, 29, 01, 05, 30", "+01, +05."),
    ("C-20.03", "reads", "03, 06, 20, 02", "06, 20, 02, 01, 19, 09", "+01, +19, +09 geography; -03, which reads 07."),
    ("C-26.02", "reads", "19, 06, 05, 07", "19, 06, 05, 07, 01, 27", "+01, +27 waiver accruals (CD-188)."),
    ("C-11.15", "reads", "02, 03, 01, 15, 18, 26, 28", "02, 03, 01, 15, 26, 28", "-18, not referenced by 12."),
    ("C-11.16", "reads", "32, 18, 31, 27, 33", "32, 18, 31, 27, 33, 34, 42", "+34 client sustainability hand-off, +42 brand."),
    ("C-18.03", "reads", "18, 01, 19", "18, 01, 19, 06", "+06 assets on fee invoices."),
    ("C-12.01", "reads", "09, 41", "09, 21, 39, 41", "+21 KRI metric definitions, +39 risk appetite approvals."),
    ("C-12.02", "reads", "27, 26, 29", "27, 26, 29, 25, 13, 16, 33, 31, 30, 41, 44, 19",
     "Incident source records reference 13, 16, 25, 26, 27, 29, 30, 31, 33, 41, 44; loss amounts post to 19."),
    ("C-12.03", "reads", "41, 40, 44", "41, 40, 21", "+21 data assets in resource mapping; -44."),
    ("C-12.04", "reads", "31, 21, 24", "31, 21, 41, 02", "+41 model deployments, +02 model vendors; -24, which copies from 37."),
    ("C-12.05", "reads", "38, 41, 19", "38, 39, 35, 41, 19", "+39 corporate bodies, +35 fund audit committees."),
    ("C-12.06", "reads", "09, 20, 08, 39, 36", "09, 11, 39, 37, 17, 18",
     "+11 horizon items, +37, +17 and +18 for ownership disclosures; -20, -08, -36."),
    ("C-12.07", "reads", "20, 17, 25, 42", "20, 17, 02", "+02 political recipients; -25, -42, which read 38."),
    ("C-12.08", "reads", "02, 29", "02, 29, 15, 40", "+15, +40 supplier onboarding cases."),
    ("C-12.09", "reads", "25, 22, 37", "25, 08, 37, 17", "+08 communications surveillance, +17; -22."),
    ("C-12.10", "reads", "05, 14, 40", "05, 14, 40, 01, 10, 16, 26, 28, 30, 35, 43, 44, 02",
     "Typed contract owners under CD-257: 01, 05, 10, 14, 16, 26, 28, 30, 35, 40, 43, 44."),
    ("C-12.11", "reads", "20, 41", "02, 19, 38, 21, 41, 08, 20", "+02, +19, +38, +21, +08 retention."),
    ("C-12.12", "reads", "09, 20", "09, 20, 38, 42, 43, 37", "+38, +42 brands, +43, +37 resolution subjects."),
    ("C-13.01", "reads", "09, 10, 27", "09, 10, 22, 01, 43", "+22 FX, +01 consolidated funds, +43 bank accounts; -27."),
    ("C-13.02", "reads", "40, 12, 05", "40, 12, 05, 13, 14, 02, 43", "+13, +14 invoices, +02, +43."),
    ("C-13.05", "reads", "09, 20", "09, 10, 02", "+10 transfer pricing, +02 tax authorities; -20."),
    ("C-13.06", "reads", "19, 09", "19, 09, 02, 10, 22, 25, 26", "+02, +10, +22, +25, +26 treasury deals."),
    ("C-13.07", "reads", "36, 18, 30", "36, 18, 30, 01, 27, 29, 15", "+01, +27, +29, +15 seed movements and valuations."),
    ("C-13.08", "reads", "09, 19, 38", "09, 19, 02, 08", "+02, +08; -38, which reads 20."),
    ("C-13.09", "reads", "07, 19", "07, 19, 01, 16", "+01 fund-linked awards, +16 own 401(k)."),
    ("C-13.10", "reads", "02, 19, 37, 39", "02, 19, 39, 14, 13, 28, 01", "+14, +13, +28, +01 engagement specializations; -37."),
    ("C-13.11", "reads", "04, 39, 38, 37", "04, 39, 37, 41, 44, 20, 34, 43",
     "+41, +44 incidents, +20, +34, +43 publication sources; -38 moved to C-13.16."),
    ("C-13.12", "reads", "19, 09, 20", "09, 19, 39, 40, 02, 34", "+39 leases, +40, +02, +34; -20 moved to C-13.17/18."),
    ("C-14.01", "reads", "40, 21", "02, 39, 21, 37", "+02 vendors, +39 license contracts, +37 models; -40."),
    ("C-14.02", "reads", "20, 14, 37", "20, 14, 38, 02", "+38 policies, +02; -37, which reads 41."),
    ("C-14.03", "reads", "19, 36", "19, 36, 21, 38", "+21, +38 on Project Scope Link."),
    ("C-14.05", "reads", "41, 14", "41, 14, 06, 12", "+06, +12 lineage."),
    ("C-14.06", "reads", "06, 19, 32, 41", "06, 10, 11, 41", "+10, +11 metric definitions; -19, -32."),
    ("C-14.08", "reads", "14, 21, 39, 20", "14, 19, 41, 20, 02", "+19, +41, +02; -21, -39."),
    ("C-14.09", "reads", "40, 39, 19, 41, 20", "40, 19, 41, 20, 01, 10, 02, 39", "+01 index use, +10 cost allocation, +02."),
    # ---- Phase 2 review (2026-10-14): findings of the per-area reviews of 2026-10-07. Field "area" is the function area;
    # field "note" records a finding that was checked and kept, or a content finding for domain owners (no map change).
    ("C-10.07", "area", "Investment Operations", "Distribution & Client",
     "Phase 2 review: 01 masters the benchmark definition and its assignment to strategies and products; 32 masters only "
     "the Benchmark Return (CD-217), so the masters stay 01. Product management (FN-10, Distribution & Client) runs the "
     "capability in the function model and the owner role is Head of Product; performance reads the assignment."),
    ("C-12.16", "note", "masters 08, Corporate Functions", "kept",
     "Phase 2 review: no other domain masters a retention schedule; 38 masters policies and 39 legal holds, and CD-258 "
     "keeps the Retention Rule in 08 (CD-062). Area stays Corporate Functions (firm-wide records management); the "
     "function model files it under distribution compliance (FN-13). See the drafting note."),
    ("C-06.05", "note", "masters 28, Fund Operations", "kept",
     "Phase 2 review: 28 masters the reconciliation and break records; 18 and 27 are the books reconciled. Often run in "
     "the middle office; boundary note added to the drafting notes."),
    ("C-04.05", "note", "masters 22, Investment Operations", "kept",
     "Phase 2 review: 22 masters the fair value determinations, run by pricing and valuation (FN-28). Often led by the "
     "fund treasurer for the valuation designee under Rule 2a-5; note added to the drafting notes."),
    ("C-04.10", "added", "", "25", "Phase 2 review: 25 masters the Trade Error (type, affected order, allocation and "
     "portfolio, gain or loss, reimbursement); no capability covered post-execution trade support. Run by trade "
     "operations (FN-29); 37 receives the operational incident raised for an error (CD-244)."),
    ("C-06.12", "added", "", "27", "Phase 2 review: 27 masters the Fund Financial Statement set and Financial Highlights "
     "per class; 35 references them for board and audit committee approval (CD-235). Run by fund accounting and the "
     "fund treasurer (FN-33); reads 01 share classes and the 02 audit firm."),
    ("C-12.17", "added", "", "02", "Phase 2 review: 02 masters the Privacy Profile, Processing Legal Basis, Consent Record and "
     "Data Subject Request, and the personal data retention category mapped to 08 RET- rules (CD-062); 38 masters no "
     "privacy record. Run by the privacy officer under corporate compliance (FN-44); consent stays C-11.03."),
    ("C-13.19", "added", "", "44", "Phase 2 review: 44 masters the Operational Emission Record and the Utility Consumption "
     "Record it is computed from (CD-281); 42 publishes the figures and 34 copies the entity totals. Run by workplace "
     "and corporate services (FN-48); split from C-13.12."),
    ("C-13.12", "definition", "+ energy use and emissions of own operations", "+ utility consumption of each site",
     "Phase 2 review: operational emissions moved to C-13.19."),
    ("C-13.12", "reads", "09, 19, 39, 40, 02, 34", "09, 19, 39, 40, 02",
     "Phase 2 review: -34, read only by the emission records now under C-13.19."),
    ("C-12.10", "note", "", "content finding for the 39 and 05 owners",
     "Phase 2 review, reference flows: 39 Contract carries contract status, dates and governing law as Derived copies "
     "flagged with owner 05, although 39 is the firm-wide contract record. CD-257 covers it: on typed rows those fields "
     "are copies of the typed record, and 05 is a stand-in owner because the enrichment takes one owner per attribute; "
     "the per-row owner is in the attribute note. The explorer therefore draws a 05-to-39 flow that is partly a flow "
     "from 26, 35, 40 or another typed-contract owner. No capability map change; for the 39 and 05 owners to confirm "
     "when the Row Ownership Rule is ratified."),
    # ---- W0 (wealth-manager rework, 2026-10-14): re-cut for the direct wealth manager (CW-004, CW-018). Removed
    # capabilities are in REMOVED_W0, ids that moved with their L1 in MOVED_W0, renamed L1s in L1_CHANGES_W0.
    ("C-01.01", "lines", "MF, ETF, CIT, SMA, IDF", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-01.02", "definition", "", "+ capital-market assumptions",
     "W0: 23 macro research feeds the capital-market assumptions 24 adds (plan §5.1)."),
    ("C-01.02", "lines", "MF, ETF, CIT, SMA, IDF", "PF, IA, DA, HA, WR, IC",
     "W0: re-tagged to the business lines of CW-004."),
    ("C-01.03", "lines", "MF, ETF, CIT, SMA, IDF", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-01.04", "definition", "", "MiFID II research payment accounts -> Section 28(e) commission sharing",
     "W0: US only (CW-003)."),
    ("C-01.04", "lines", "MF, ETF, CIT, SMA, IDF", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-01.05", "definition", "", "- SFDR principal adverse impact disclosures", "W0: US only (CW-003)."),
    ("C-01.05", "reads", "17, 14, 02, 18, 01, 22, 30, 37", "17, 14, 02, 18, 01, 22, 37",
     "W0: -30; private markets EVIC inputs gone (CW-016)."),
    ("C-01.05", "lines", "all", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-01.06", "definition", "", "+ voting policy choices offered to fund investors",
     "W0: 34 adds investor-choice proxy voting options (plan §5.1)."),
    ("C-01.06", "lines", "MF, ETF, CIT, SMA, IDF", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-02.01", "definition", "", "+ capital-market assumptions, glide paths of advice models",
     "W0: 24 adds CMAs and SAA for advice models and target-date funds (CW-009)."),
    ("C-02.01", "reads", "01, 23, 18, 30", "01, 23, 18, 22",
     "W0: +22, -30; +22 market data for capital-market assumptions; 30 retired."),
    ("C-02.01", "lines", "all", "PF, IA, DA, HA, WR, IC", "W0: re-tagged to the business lines of CW-004."),
    ("C-02.02", "definition", "", "fund and institutional portfolios",
     "W0: Client accounts are rebalanced in 46 (CW-009)."),
    ("C-02.02", "reads", "18, 01, 17, 22, 15, 12, 30", "18, 01, 17, 22, 12",
     "W0: -15, -30; client accounts are rebalanced in 46, not as SMA sleeves (CW-009); 30 retired."),
    ("C-02.02", "lines", "all", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-02.03", "definition", "", "models for advice programs, managed accounts and intermediary platforms",
     "W0: Models are consumed by 46 through the 01 model portfolio (CW-009)."),
    ("C-02.03", "lines", "SMA, MF, ETF", "DA, HA, WR, IC", "W0: re-tagged to the business lines of CW-004."),
    ("C-02.04", "name", "Model Delivery to Sponsors", "Model Delivery to Intermediary Platforms",
     "W0: Models are delivered to third-party advisor and sponsor platforms of the intermediary channel."),
    ("C-02.04", "area", "Distribution & Client", "Distribution, Channels & Client Economics",
     "W0: the wealth-manager areas (CW-018)."),
    ("C-02.04", "definition", "", "sponsor platforms -> third-party advisor and sponsor platforms",
     "W0: Follows the rename."),
    ("C-02.04", "lines", "SMA", "IC", "W0: re-tagged to the business lines of CW-004."),
    ("C-02.04", "note", "owner Head of Managed Accounts", "owner Head of Intermediary Distribution",
     "W0: owner role re-cut for the wealth manager."),
    ("C-02.06", "lines", "ETF", "PF", "W0: re-tagged to the business lines of CW-004."),
    ("C-02.07", "definition", "", "+ funds, mandates and model portfolios",
     "W0: Model portfolios are managed by named teams too."),
    ("C-02.07", "lines", "all", "PF, IA, DA, HA, WR, IC", "W0: re-tagged to the business lines of CW-004."),
    ("C-03.01", "definition", "", "portfolio orders, apart from client brokerage orders",
     "W0: Client orders are 48's (CW-010)."),
    ("C-03.01", "reads", "24, 18, 17, 33, 15, 12, 38", "24, 18, 17, 33, 12, 38",
     "W0: -15; SMA accounts are client accounts in 46 and 48 (CW-009, CW-010)."),
    ("C-03.01", "lines", "MF, ETF, CIT, SMA, IDF", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-03.02", "definition", "", "- accounts", "W0: Fills to client accounts are 48's (CW-010)."),
    ("C-03.02", "reads", "22, 17, 02, 18, 15, 38", "22, 17, 02, 18, 38",
     "W0: -15; fills to client accounts are 48's (CW-010)."),
    ("C-03.02", "lines", "MF, ETF, CIT, SMA, IDF", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-03.03", "lines", "all", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-03.04", "lines", "MF, ETF, CIT, SMA, IDF", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-03.05", "area", "Distribution & Client", "Distribution, Channels & Client Economics",
     "W0: the wealth-manager areas (CW-018)."),
    ("C-03.05", "lines", "ETF", "PF", "W0: re-tagged to the business lines of CW-004."),
    ("C-04.01", "definition", "", "+ retail-tradable instruments",
     "W0: 17 adds listed options, CDs, municipal securities and 529 portfolios (plan §5.1)."),
    ("C-04.01", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-04.02", "definition", "", "- SMA sleeves and accounts", "W0: Client accounts are 15 and 46 (CW-006, CW-009)."),
    ("C-04.02", "reads", "01, 15, 12, 05, 28, 09", "01, 12, 05, 28, 09", "W0: -15; no SMA sleeves in 18 (CW-007)."),
    ("C-04.02", "lines", "all", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-04.03", "definition", "", "fund and institutional portfolios, apart from the brokerage book of record",
     "W0: Three books of record (CW-007)."),
    ("C-04.03", "lines", "all", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-04.04", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-04.05", "definition", "", "- private assets", "W0: Private markets retired (CW-016)."),
    ("C-04.05", "lines", "all", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-04.06", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-04.07", "definition", "", "- settlement penalties", "W0: CSDR penalties are EU-only (CW-003)."),
    ("C-04.07", "lines", "MF, ETF, CIT, SMA, IDF", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-04.08", "lines", "MF, ETF, CIT, SMA, IDF", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-04.09", "definition", "", "client mandates -> institutional mandates",
     "W0: Retail client settlement is 49's (CW-007)."),
    ("C-04.09", "reads", "12, 15, 28, 02, 18, 01", "12, 28, 02, 18, 01",
     "W0: -15; client account settlement is 49's (CW-007)."),
    ("C-04.09", "lines", "all", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-04.10", "lines", "MF, ETF, CIT, SMA, IDF", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-05.01", "lines", "all", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-05.02", "definition", "", "- UCITS rules", "W0: US only (CW-003)."),
    ("C-05.02", "lines", "MF, ETF, IDF", "PF", "W0: re-tagged to the business lines of CW-004."),
    ("C-05.03", "definition", "", "- account returns", "W0: Client account returns move to C-05.10."),
    ("C-05.03", "reads", "18, 27, 22, 01, 15, 36", "18, 27, 22, 01, 36", "W0: -15; account returns move to C-05.10."),
    ("C-05.03", "lines", "all", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-05.04", "lines", "MF, ETF, CIT, SMA, IDF", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-05.06", "definition", "", "+ sub-adviser restrictions",
     "W0: 52 masters the mandate guidelines given to sub-advisers; 33 codes them (CW-014)."),
    ("C-05.06", "reads", "01, 02, 34, 38, 36, 14, 17", "01, 02, 34, 38, 36, 14, 17, 52",
     "W0: +52; +52 sub-adviser mandate guidelines (CW-014)."),
    ("C-05.06", "lines", "all", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-05.07", "reads", "25, 18, 17, 24, 31, 38, 30", "25, 18, 17, 24, 31, 38", "W0: -30; 30 retired."),
    ("C-05.07", "lines", "all", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-05.08", "lines", "all", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-05.10", "added", "", "32",
     "W0: 32 adds Client Account Performance (plan §5.1): personal rate of return at account and household grain, the "
     "certified Personal Rate of Return of CW-011."),
    ("C-06.01", "definition", "", "- NAVs reported to insurers; + ETF NAVs",
     "W0: Insurance-dedicated funds out of scope (CW-004)."),
    ("C-06.01", "reads", "18, 17, 22, 28, 01, 29, 30, 26", "18, 17, 22, 28, 01, 29, 26", "W0: -30; 30 retired."),
    ("C-06.01", "lines", "MF, ETF, CIT, IDF, PM", "PF", "W0: re-tagged to the business lines of CW-004."),
    ("C-06.02", "lines", "MF, ETF, CIT, IDF", "PF", "W0: re-tagged to the business lines of CW-004."),
    ("C-06.03", "definition", "", "+ Rule 22c-1 swing pricing as adopted",
     "W0: US only (CW-003); swing pricing is optional under Rule 22c-1."),
    ("C-06.03", "lines", "MF, ETF, CIT, IDF", "PF", "W0: re-tagged to the business lines of CW-004."),
    ("C-06.04", "name", "Custody, Safekeeping & Client Assets", "Fund Custody & Safekeeping",
     "W0: Fund assets only; client assets are custodied in the brokerage (49, CW-007) and CASS is removed (CW-003)."),
    ("C-06.04", "definition", "", "fund assets only; - CASS",
     "W0: Client assets are 49's (CW-007); CASS is UK-only (CW-003)."),
    ("C-06.04", "reads", "02, 15, 18, 01, 38, 39", "02, 18, 01, 38, 39", "W0: -15; client assets are 49's (CW-007)."),
    ("C-06.04", "lines", "all", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-06.05", "lines", "all", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-06.06", "definition", "", "fund and portfolio holdings",
     "W0: Corporate actions on client accounts are 49's (C-23.09)."),
    ("C-06.06", "reads", "17, 24, 18, 27, 01, 15", "17, 24, 18, 27, 01",
     "W0: -15; class actions on client accounts are handled by 49."),
    ("C-06.06", "lines", "MF, ETF, CIT, SMA, IDF", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-06.07", "lines", "MF, ETF, CIT, SMA, IDF", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-06.08", "definition", "", "- private fund advisory committees; + sub-adviser approval",
     "W0: Private markets retired (CW-016); boards approve sub-advisers (CW-014)."),
    ("C-06.08", "reads", "01, 02, 20, 22, 27, 31, 33, 34, 36, 13", "01, 02, 20, 22, 27, 31, 33, 34, 36, 13, 52",
     "W0: +52; +52 sub-adviser oversight for board approvals (CW-014)."),
    ("C-06.08", "lines", "MF, ETF, CIT, IDF, PM", "PF", "W0: re-tagged to the business lines of CW-004."),
    ("C-06.09", "definition", "", "- Form PF, AIFMD Annex IV; + N-CSR",
     "W0: Private funds retired (CW-016); EU/UK filings removed (CW-003)."),
    ("C-06.09", "reads", "18, 27, 31, 30, 22, 24, 34, 17", "18, 27, 31, 22, 24, 34, 17", "W0: -30; 30 retired."),
    ("C-06.09", "lines", "MF, ETF, IDF, PM", "PF", "W0: re-tagged to the business lines of CW-004."),
    ("C-06.10", "lines", "all", "PF", "W0: re-tagged to the business lines of CW-004."),
    ("C-06.11", "definition", "", "+ sub-adviser renewal data from manager oversight",
     "W0: 52 compiles the sub-adviser 15(c) data (CW-014)."),
    ("C-06.11", "reads", "01, 10, 11, 32, 39", "01, 10, 11, 32, 39, 52",
     "W0: +52; +52 sub-adviser 15(c) data (CW-014)."),
    ("C-06.11", "lines", "MF, ETF, IDF", "PF", "W0: re-tagged to the business lines of CW-004."),
    ("C-06.12", "lines", "MF, ETF, CIT, IDF, PM", "PF", "W0: re-tagged to the business lines of CW-004."),
    ("C-07.02", "definition", "", "+ brokerage platform omnibus; - EU routing",
     "W0: 29 adapted (plan §5.1); US only (CW-003)."),
    ("C-07.02", "reads", "15, 01, 27, 05, 28, 02, 16, 06", "15, 01, 27, 05, 28, 02, 16, 06, 49",
     "W0: +49; +49 brokerage platform omnibus orders (plan §5.1, 29)."),
    ("C-07.02", "lines", "MF, CIT, IDF", "PF, WR, IC", "W0: re-tagged to the business lines of CW-004."),
    ("C-07.03", "lines", "ETF", "PF", "W0: re-tagged to the business lines of CW-004."),
    ("C-07.04", "definition", "", "retail investors -> fund-only shareholders",
     "W0: CIP for brokerage clients is at onboarding (02, C-15.02)."),
    ("C-07.04", "lines", "MF", "PF", "W0: re-tagged to the business lines of CW-004."),
    ("C-07.05", "lines", "MF, CIT", "PF, IC", "W0: re-tagged to the business lines of CW-004."),
    ("C-07.05", "note", "owner Head of Distribution Data", "owner Head of Client & Channel Analytics",
     "W0: owner role re-cut for the wealth manager."),
    ("C-07.08", "lines", "MF, ETF, CIT, IDF", "PF", "W0: re-tagged to the business lines of CW-004."),
    ("C-08.01", "area", "Fund Operations", "Brokerage & Workplace Operations",
     "W0: the wealth-manager areas (CW-018)."),
    ("C-08.01", "lines", "MF, CIT", "WR", "W0: re-tagged to the business lines of CW-004."),
    ("C-08.02", "area", "Fund Operations", "Brokerage & Workplace Operations",
     "W0: the wealth-manager areas (CW-018)."),
    ("C-08.02", "lines", "MF, CIT", "WR", "W0: re-tagged to the business lines of CW-004."),
    ("C-08.03", "area", "Fund Operations", "Brokerage & Workplace Operations",
     "W0: the wealth-manager areas (CW-018)."),
    ("C-08.03", "lines", "MF, CIT", "WR", "W0: re-tagged to the business lines of CW-004."),
    ("C-08.04", "area", "Fund Operations", "Brokerage & Workplace Operations",
     "W0: the wealth-manager areas (CW-018)."),
    ("C-08.04", "lines", "MF, CIT", "WR", "W0: re-tagged to the business lines of CW-004."),
    ("C-08.05", "area", "Fund Operations", "Brokerage & Workplace Operations",
     "W0: the wealth-manager areas (CW-018)."),
    ("C-08.05", "lines", "MF, CIT", "WR", "W0: re-tagged to the business lines of CW-004."),
    ("C-08.06", "area", "Fund Operations", "Brokerage & Workplace Operations",
     "W0: the wealth-manager areas (CW-018)."),
    ("C-08.06", "lines", "CIT", "PF, WR", "W0: re-tagged to the business lines of CW-004."),
    ("C-08.07", "added", "", "16",
     "W0: 16 adds participant-to-retail hand-off and rollover capture (plan §5.1); 45 documents the rollover "
     "recommendation (C-16.03)."),
    ("C-08.08", "added", "", "16",
     "W0: 16 adds the plan sponsor relationship (plan §5.1); 12 keeps institutional servicing and reporting."),
    ("C-08.09", "added", "", "16",
     "W0: 16 adds managed accounts in plan (plan §5.1); 46 runs the models, 45 the advice."),
    ("C-10.01", "area", "Distribution & Client", "Client & Advice", "W0: the wealth-manager areas (CW-018)."),
    ("C-10.01", "definition", "", "+ advice programs and platform features",
     "W0: 01 and 36 widen to the wealth manager's offerings (plan §5.1)."),
    ("C-10.01", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-10.02", "area", "Distribution & Client", "Client & Advice", "W0: the wealth-manager areas (CW-018)."),
    ("C-10.02", "definition", "", "+ advice services and platform features",
     "W0: 36 adds advice-service and platform-feature development (plan §5.1)."),
    ("C-10.02", "reads", "01, 35, 05, 14, 22, 27, 28, 29, 33, 41, 18, 43", "01, 35, 05, 14, 22, 27, 28, 29, 33, 41, 18, 43, 47",
     "W0: +47; +47 fee schedules of new advice services."),
    ("C-10.02", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-10.03", "area", "Distribution & Client", "Client & Advice", "W0: the wealth-manager areas (CW-018)."),
    ("C-10.03", "definition", "", "+ changes to advice programs", "W0: 36 adapted (plan §5.1)."),
    ("C-10.03", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-10.04", "area", "Distribution & Client", "Client & Advice", "W0: the wealth-manager areas (CW-018)."),
    ("C-10.04", "definition", "", "- Consumer Duty and UK assessments of value; + advice programs, client outcomes",
     "W0: US only (CW-003); 36 adapted."),
    ("C-10.04", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-10.05", "area", "Distribution & Client", "Client & Advice", "W0: the wealth-manager areas (CW-018)."),
    ("C-10.05", "definition", "", "- target markets; + state notice filings",
     "W0: MiFID target market removed (CW-003)."),
    ("C-10.05", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-10.06", "area", "Distribution & Client", "Client & Advice", "W0: the wealth-manager areas (CW-018)."),
    ("C-10.06", "definition", "", "- KIDs; + summary prospectuses", "W0: PRIIPs KIDs removed (CW-003)."),
    ("C-10.06", "lines", "all", "PF, IA, IC", "W0: re-tagged to the business lines of CW-004."),
    ("C-10.07", "area", "Distribution & Client", "Client & Advice", "W0: the wealth-manager areas (CW-018)."),
    ("C-10.07", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-10.09", "area", "Distribution & Client", "Distribution, Channels & Client Economics",
     "W0: the wealth-manager areas (CW-018)."),
    ("C-10.09", "definition", "", "+ advice programs and brokerage pricing",
     "W0: 11 adapted to the retail and wealth market (plan §5.1)."),
    ("C-10.09", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-10.10", "added", "", "01",
     "W0: 01 adds Advice & Service Offerings: programs, service tiers, eligibility and fee schedule references to 47 "
     "(plan §5.1, CW-008)."),
    ("C-10.11", "added", "", "01",
     "W0: 01 adds the brokerage platform offering: tradable universe policy, fractional and extended-hours "
     "eligibility, alternatives through feeders (plan §5.1, CW-016); 52 vets third-party products."),
    ("C-11.04", "masters", "03", "05",
     "W0: 03 becomes the firm's own advisor workforce; intermediary and institutional coverage and pipeline move to "
     "05 Intermediary & Institutional Distribution (CW-013)."),
    ("C-11.04", "area", "Distribution & Client", "Distribution, Channels & Client Economics",
     "W0: the wealth-manager areas (CW-018)."),
    ("C-11.04", "definition", "", "intermediary firms, consultants and institutions",
     "W0: Follows the re-point to 05."),
    ("C-11.04", "reads", "02, 07, 04, 01", "02, 04, 01", "W0: -07; 07 retired (CW-013)."),
    ("C-11.04", "lines", "all", "IA, IC", "W0: re-tagged to the business lines of CW-004."),
    ("C-11.04", "note", "owner Head of Sales Operations", "owner Head of Intermediary Distribution",
     "W0: owner role re-cut for the wealth manager."),
    ("C-11.05", "masters", "03", "05",
     "W0: RFPs and consultant relations move to 05 with institutional sales (CW-013)."),
    ("C-11.05", "area", "Distribution & Client", "Distribution, Channels & Client Economics",
     "W0: the wealth-manager areas (CW-018)."),
    ("C-11.05", "lines", "all", "IA, IC", "W0: re-tagged to the business lines of CW-004."),
    ("C-11.05", "note", "owner Head of Sales Operations", "owner Head of Institutional Sales",
     "W0: owner role re-cut for the wealth manager."),
    ("C-11.08", "name", "Distribution Agreements & Shelf Management", "Intermediary Agreements & Platform Placement",
     "W0: Thin intermediary channel: platform agreements and placement replace national-accounts shelf management "
     "(CW-013)."),
    ("C-11.08", "area", "Distribution & Client", "Distribution, Channels & Client Economics",
     "W0: the wealth-manager areas (CW-018)."),
    ("C-11.08", "definition", "", "selling, platform and model delivery agreements", "W0: Follows the rename."),
    ("C-11.08", "lines", "all", "IC", "W0: re-tagged to the business lines of CW-004."),
    ("C-11.08", "note", "owner Head of National Accounts", "owner Head of Intermediary Distribution",
     "W0: owner role re-cut for the wealth manager."),
    ("C-11.09", "area", "Distribution & Client", "Distribution, Channels & Client Economics",
     "W0: the wealth-manager areas (CW-018)."),
    ("C-11.09", "definition", "", "- retrocessions", "W0: Retrocessions are EU/UK practice (CW-003)."),
    ("C-11.09", "lines", "MF, ETF, CIT, SMA", "IC", "W0: re-tagged to the business lines of CW-004."),
    ("C-11.09", "note", "owner Head of National Accounts", "owner Head of Intermediary Distribution",
     "W0: owner role re-cut for the wealth manager."),
    ("C-11.15", "area", "Distribution & Client", "Distribution, Channels & Client Economics",
     "W0: the wealth-manager areas (CW-018)."),
    ("C-11.15", "definition", "", "+ OCIO clients and plan sponsors",
     "W0: 12 adapted to institutional advisory and plan sponsor servicing (plan §5.1)."),
    ("C-11.15", "reads", "02, 03, 01, 15, 26, 28", "02, 05, 01, 15, 26, 28",
     "W0: +05, -03; institutional sales move from 03 to 05 (CW-013)."),
    ("C-11.15", "lines", "SMA, CIT, IDF, PM", "IA, WR", "W0: re-tagged to the business lines of CW-004."),
    ("C-11.16", "area", "Distribution & Client", "Distribution, Channels & Client Economics",
     "W0: the wealth-manager areas (CW-018)."),
    ("C-11.16", "definition", "", "+ plan sponsors", "W0: 12 adapted (plan §5.1)."),
    ("C-11.16", "lines", "SMA, CIT, IDF", "IA, WR", "W0: re-tagged to the business lines of CW-004."),
    ("C-11.19", "added", "", "05",
     "W0: Intermediary firms, advisors and consultants remain party roles with thin profiles in 05 (CW-005, CW-013); "
     "the wholesale distributor hierarchy of 02 is not carried."),
    ("C-12.01", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-12.02", "reads", "27, 26, 29, 25, 13, 16, 33, 31, 30, 41, 44, 19", "27, 26, 29, 25, 13, 16, 33, 31, 41, 44, 19, 48, 49, 50",
     "W0: +48, +49, +50, -30; +48, +49, +50 brokerage and money movement incidents; 30 retired."),
    ("C-12.02", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-12.03", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-12.04", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-12.05", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-12.06", "definition", "", "+ FINRA membership, Form ADV and Form CRS filings; - entity authorizations",
     "W0: 38 adds broker-dealer registration and Form CRS filing (CW-015); passports are EU-only."),
    ("C-12.06", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-12.07", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-12.08", "definition", "", "+ customer identification, broker-dealer program under FINRA Rule 3310",
     "W0: 38 adds the BD AML program (plan §5.1)."),
    ("C-12.08", "reads", "02, 29, 15, 40", "02, 29, 15, 40, 50", "W0: +50; +50 cash-movement AML referrals (CW-016)."),
    ("C-12.08", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-12.09", "definition", "", "+ client trading",
     "W0: The broker-dealer surveils client orders for market abuse (48)."),
    ("C-12.09", "reads", "25, 08, 37, 17", "25, 08, 37, 17, 48", "W0: +48; +48 client orders surveilled."),
    ("C-12.09", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-12.10", "reads", "05, 14, 40, 01, 10, 16, 26, 28, 30, 35, 43, 44, 02", "05, 14, 40, 01, 10, 16, 26, 28, 35, 43, 44, 02, 52",
     "W0: +52, -30; +52 sub-advisory agreements as typed contracts; 30 retired."),
    ("C-12.10", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-12.11", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-12.12", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-12.13", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-12.14", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-12.15", "reads", "23, 30, 34, 17, 20", "23, 34, 17, 20", "W0: -30; 30 retired."),
    ("C-12.15", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-12.16", "definition", "", "+ Rule 17a-4 retention periods",
     "W0: The broker-dealer's books-and-records retention (plan §5.2, 49)."),
    ("C-12.16", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-12.17", "definition", "", "lawful basis and data subject requests -> Regulation S-P and state privacy opt-outs and requests",
     "W0: GDPR removed (CW-003)."),
    ("C-12.17", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-13.01", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-13.02", "reads", "40, 12, 05, 13, 14, 02, 43", "40, 47, 05, 13, 14, 02, 43",
     "W0: +47, -12; fee invoices move from 12 to 47 (CW-012)."),
    ("C-13.02", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-13.03", "definition", "", "+ advisory, brokerage and account fee revenue",
     "W0: 47 bills client fees (CW-012)."),
    ("C-13.03", "reads", "27, 12, 30, 10", "27, 47, 10",
     "W0: +47, -12, -30; fee revenue from 47 (CW-012); 30 retired."),
    ("C-13.03", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-13.04", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-13.05", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-13.06", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-13.07", "definition", "", "- GP commitments", "W0: Private markets retired (CW-016)."),
    ("C-13.07", "reads", "36, 18, 30, 01, 27, 29, 15", "36, 18, 01, 27, 29, 15", "W0: -30; 30 retired."),
    ("C-13.07", "lines", "all", "PF, IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-13.08", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-13.09", "definition", "", "- material risk takers", "W0: EU/UK remuneration rules removed (CW-003)."),
    ("C-13.09", "reads", "07, 19, 01, 16", "03, 19, 01, 16",
     "W0: +03, -07; incentive plans move from 07 to 03 (CW-013)."),
    ("C-13.09", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-13.10", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-13.11", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-13.12", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-13.13", "name", "Outsourcing & ICT Third-Party Register", "Outsourcing & Critical Vendor Register",
     "W0: The DORA register of information is EU-only (CW-003); the outsourcing register stays."),
    ("C-13.13", "definition", "", "- DORA register of information", "W0: US only (CW-003)."),
    ("C-13.13", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-13.14", "name", "Regulatory Capital & ICARA", "Net Capital & Regulatory Capital",
     "W0: ICARA is UK-only (CW-003); broker-dealer net capital (Rule 15c3-1) is added (plan §5.1, 43)."),
    ("C-13.14", "definition", "", "+ broker-dealer net capital; - ICARA",
     "W0: 43 adds Rule 15c3-1 net capital; ICARA removed (plan §5.1)."),
    ("C-13.14", "reads", "19, 38, 37, 09", "19, 38, 37, 09, 49",
     "W0: +49; +49 customer reserve interplay with net capital (plan §5.1, 43)."),
    ("C-13.14", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-13.15", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-13.16", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-13.17", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-13.18", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-13.19", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-14.01", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-14.02", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-14.03", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-14.04", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-14.05", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-14.06", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-14.07", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-14.08", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-14.09", "definition", "", "+ client real-time quote entitlements", "W0: 14 examples re-cut (plan §5.1)."),
    ("C-14.09", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-14.10", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-15.01", "note", "C-11.01", "C-15.01",
     "W0: moved from C-11.01 (L1 C-11) to L1 C-15 Client & Account Management; id changed with the L1."),
    ("C-15.01", "name", "Party & Distributor Hierarchy Management", "Client & Household Master",
     "W0: 02 is replaced by Client & Household (CW-005); the distributor hierarchy is not carried."),
    ("C-15.01", "area", "Distribution & Client", "Client & Advice", "W0: the wealth-manager areas (CW-018)."),
    ("C-15.01", "definition", "", "clients and households", "W0: Follows the rename (CW-005)."),
    ("C-15.01", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-15.01", "note", "owner Head of Distribution Data", "owner Head of Client Data",
     "W0: owner role re-cut for the wealth manager."),
    ("C-15.02", "note", "C-11.02", "C-15.02",
     "W0: moved from C-11.02 (L1 C-11) to L1 C-15 Client & Account Management; id changed with the L1."),
    ("C-15.02", "name", "Client Onboarding & KYC", "Client Onboarding, CIP & KYC",
     "W0: Customer identification program named: onboarding is retail and direct (CW-005)."),
    ("C-15.02", "area", "Distribution & Client", "Client & Advice", "W0: the wealth-manager areas (CW-018)."),
    ("C-15.02", "definition", "", "+ individuals and entities, CIP, beneficial ownership",
     "W0: 31 CFR 1023.220 and 1010.230 (CW-005)."),
    ("C-15.02", "reads", "38, 15, 09", "38, 15, 09, 04", "W0: +04; +04 onboarding events from the acquisition funnel."),
    ("C-15.02", "lines", "SMA, PM, CIT, IDF", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-15.03", "added", "", "02",
     "W0: 02 masters the investor profile that Reg BI and the Advisers Act fiduciary duty require (CW-005)."),
    ("C-15.04", "note", "C-11.03", "C-15.04",
     "W0: moved from C-11.03 (L1 C-11) to L1 C-15 Client & Account Management; id changed with the L1."),
    ("C-15.04", "area", "Distribution & Client", "Client & Advice", "W0: the wealth-manager areas (CW-018)."),
    ("C-15.04", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-15.05", "note", "C-07.01", "C-15.05",
     "W0: moved from C-07.01 (L1 C-07) to L1 C-15 Client & Account Management; id changed with the L1."),
    ("C-15.05", "area", "Fund Operations", "Client & Advice", "W0: the wealth-manager areas (CW-018)."),
    ("C-15.05", "definition", "", "brokerage, advisory, retirement, education, trust, participant and fund-only accounts",
     "W0: 15 replaced (CW-006)."),
    ("C-15.05", "reads", "02, 05, 01, 28", "02, 01, 08, 05",
     "W0: +08, -28; +08 option and margin approvals; -28 custodian account numbers (fund-only)."),
    ("C-15.05", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-15.05", "note", "owner Head of Transfer Agency", "owner Head of Account Services",
     "W0: owner role re-cut for the wealth manager."),
    ("C-15.06", "added", "", "15",
     "W0: 15 masters beneficiary and TOD designations, feature elections, cost-basis method election and RMD status "
     "(CW-006)."),
    ("C-15.07", "added", "", "15",
     "W0: 15 masters advisory program enrollment; the program is an 01 offering and the advice is 45's (CW-008)."),
    ("C-16.01", "added", "", "45",
     "W0: New domain 45 Financial Planning & Advice masters goals, plans, assumptions and projections (CW-008)."),
    ("C-16.02", "added", "", "45",
     "W0: 45 masters recommendations and the Reg BI care-obligation and fiduciary evidence (CW-008)."),
    ("C-16.03", "added", "", "45", "W0: 45 masters rollover analyses and the DOL PTE 2020-02 documentation (CW-008)."),
    ("C-16.04", "added", "", "45",
     "W0: 45 masters advice engagements and reviews, with delivery channel as an attribute (CW-008, plan §15 ruling "
     "4)."),
    ("C-17.01", "added", "", "46",
     "W0: New domain 46 Managed Portfolios & Rebalancing masters model assignment and account targets (CW-009); "
     "replaces C-02.05."),
    ("C-17.02", "added", "", "46",
     "W0: 46 masters drift, rebalance triggers and the trade proposals handed to 48 (CW-009)."),
    ("C-17.03", "added", "", "46",
     "W0: 46 masters tax-loss-harvesting and asset-location decisions and wash-sale control (CW-009); replaces "
     "C-02.05."),
    ("C-17.04", "added", "", "46", "W0: 46 masters program-level composites of client accounts (CW-009)."),
    ("C-18.01", "added", "", "47",
     "W0: New domain 47 Pricing, Fees & Billing masters fee schedules, tiers, householding and breakpoints (CW-012)."),
    ("C-18.02", "added", "", "47",
     "W0: 47 masters fee calculation runs, fee debits and the custody-rule conditions on fee deduction (CW-012)."),
    ("C-18.03", "note", "C-11.18", "C-18.03",
     "W0: moved from C-11.18 (L1 C-11) to L1 C-18 Client Pricing & Billing; id changed with the L1."),
    ("C-18.03", "masters", "12", "47", "W0: 12's Fee Billing & Invoicing family moves to 47 (CW-012)."),
    ("C-18.03", "name", "Fee Billing & Invoicing", "Institutional Fee Billing & Invoicing",
     "W0: Institutional only; client advisory fees are C-18.02."),
    ("C-18.03", "area", "Distribution & Client", "Client & Advice", "W0: the wealth-manager areas (CW-018)."),
    ("C-18.03", "definition", "", "institutional and OCIO mandates", "W0: Follows the re-point to 47."),
    ("C-18.03", "reads", "18, 01, 19, 06", "18, 01, 19, 06, 12", "W0: +12; +12 institutional mandates billed."),
    ("C-18.03", "lines", "SMA, CIT, IDF", "IA", "W0: re-tagged to the business lines of CW-004."),
    ("C-18.03", "note", "owner Head of Institutional Client Service", "owner Head of Pricing & Billing",
     "W0: owner role re-cut for the wealth manager."),
    ("C-18.04", "added", "", "47", "W0: 47 masters waivers, credits and the fee disclosures delivered (CW-012)."),
    ("C-19.01", "added", "", "08", "W0: 08 is replaced by Retail Conduct & Supervision (CW-015): Reg BI and Form CRS."),
    ("C-19.02", "added", "", "08",
     "W0: 08 masters supervision under FINRA Rules 3110, 3120 and 3130 and surveillance alerts (CW-015)."),
    ("C-19.03", "added", "", "08",
     "W0: 08 masters complaints (Rule 4530) and senior investor protection (Rule 2165) (CW-015); successor of the "
     "complaints part of C-11.12."),
    ("C-19.04", "added", "", "08",
     "W0: 08 masters communications review (Rule 2210, Advisers Act marketing rule) (CW-015); successor of the "
     "marketing review part of C-11.12."),
    ("C-19.05", "added", "", "08",
     "W0: 08 masters licensing and registration of own representatives (CW-015); successor of the licensing part of "
     "C-11.12."),
    ("C-19.06", "added", "", "08", "W0: 08 masters options and margin suitability oversight (CW-015)."),
    ("C-20.01", "added", "", "03",
     "W0: 03 is replaced by Advisor Organization, Coverage & Supervision (CW-013): own advisors, teams, branches and "
     "OSJs."),
    ("C-20.02", "added", "", "03",
     "W0: 03 masters client-to-advisor assignment, capacity and service models (CW-013)."),
    ("C-20.03", "note", "C-11.11", "C-20.03",
     "W0: moved from C-11.11 (L1 C-11) to L1 C-20 Advisor Workforce; id changed with the L1."),
    ("C-20.03", "masters", "07", "03", "W0: 07 is retired; coverage and incentive compensation move to 03 (CW-013)."),
    ("C-20.03", "name", "Territory, Goals & Incentive Compensation", "Advisor Goals & Incentive Compensation",
     "W0: Territories survive only as advisor assignment (CW-013)."),
    ("C-20.03", "area", "Distribution & Client", "Client & Advice", "W0: the wealth-manager areas (CW-018)."),
    ("C-20.03", "definition", "", "territories -> advisors, representatives and intermediary sales staff",
     "W0: 07 retired (CW-013)."),
    ("C-20.03", "reads", "06, 20, 02, 01, 19, 09", "06, 20, 02, 01, 19, 45",
     "W0: +45, -09; +45 advice engagements credited; territories gone."),
    ("C-20.03", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-21.01", "note", "C-11.07", "C-21.01",
     "W0: moved from C-11.07 (L1 C-11) to L1 C-21 Client Service & Digital; id changed with the L1."),
    ("C-21.01", "name", "Marketing & Digital Engagement", "Client Acquisition & Marketing",
     "W0: 04 adapted to direct-to-consumer acquisition (plan §5.1); digital engagement split out to C-21.02."),
    ("C-21.01", "area", "Distribution & Client", "Client & Advice", "W0: the wealth-manager areas (CW-018)."),
    ("C-21.01", "definition", "", "direct-to-consumer campaigns and funnels; - events, advisor portals",
     "W0: 04 adapted (plan §5.1)."),
    ("C-21.01", "reads", "08, 01, 02, 03, 05, 41, 42", "08, 01, 02, 03, 41, 42",
     "W0: -05; intermediary partners out of direct marketing."),
    ("C-21.01", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-21.01", "note", "owner Head of Marketing Operations", "owner Head of Marketing",
     "W0: owner role re-cut for the wealth manager."),
    ("C-21.02", "added", "", "04",
     "W0: 04 adapted to Marketing, Digital & Client Engagement: digital identity, app events, personalization, "
     "experiments, NPS (plan §5.1)."),
    ("C-21.03", "note", "C-07.06", "C-21.03",
     "W0: moved from C-07.06 (L1 C-07) to L1 C-21 Client Service & Digital; id changed with the L1."),
    ("C-21.03", "name", "Shareholder Service", "Client Service & Contact Center",
     "W0: 13 becomes Client Service & Communications for every account type (plan §5.1)."),
    ("C-21.03", "area", "Fund Operations", "Client & Advice", "W0: the wealth-manager areas (CW-018)."),
    ("C-21.03", "definition", "", "shareholder -> client, every account type", "W0: 13 adapted (plan §5.1)."),
    ("C-21.03", "reads", "15, 02, 29, 06", "15, 02, 29, 06, 49, 50",
     "W0: +49, +50; +49 holdings and +50 money movements on service requests."),
    ("C-21.03", "lines", "MF, CIT", "DB, DA, HA, WR, TR, PF", "W0: re-tagged to the business lines of CW-004."),
    ("C-21.03", "note", "owner Head of Shareholder Services", "owner Head of Client Service",
     "W0: owner role re-cut for the wealth manager."),
    ("C-21.04", "note", "C-07.07", "C-21.04",
     "W0: moved from C-07.07 (L1 C-07) to L1 C-21 Client Service & Digital; id changed with the L1."),
    ("C-21.04", "name", "Shareholder Statements & Communications", "Statements, Confirmations & Tax Documents",
     "W0: Statements, confirmations and tax documents for every account type (FINRA Rule 2231, Rule 10b-10)."),
    ("C-21.04", "area", "Fund Operations", "Client & Advice", "W0: the wealth-manager areas (CW-018)."),
    ("C-21.04", "definition", "", "+ FINRA Rule 2231 statements, trade confirmations, e-delivery and householding",
     "W0: 13 adapted (plan §5.1)."),
    ("C-21.04", "reads", "06, 15, 27, 01, 02, 35", "06, 15, 27, 01, 02, 35, 48, 49",
     "W0: +48, +49; +48 confirmations, +49 statements and cost basis."),
    ("C-21.04", "lines", "MF, ETF, CIT, IDF", "DB, DA, HA, WR, TR, PF",
     "W0: re-tagged to the business lines of CW-004."),
    ("C-21.04", "note", "owner Head of Shareholder Services", "owner Head of Client Communications",
     "W0: owner role re-cut for the wealth manager."),
    ("C-22.01", "added", "", "51", "W0: New optional domain 51 Trust & Estate Services (CW-017)."),
    ("C-22.02", "added", "", "51",
     "W0: 51 masters trust accounting (principal and income) and fiduciary tax (CW-017)."),
    ("C-22.03", "added", "", "51", "W0: 51 masters estate settlement cases (CW-017)."),
    ("C-23.01", "added", "", "48",
     "W0: New domain 48 Brokerage Orders & Execution masters client orders and routing (CW-010)."),
    ("C-23.02", "added", "", "48",
     "W0: 48 masters executions, allocations to accounts, confirmations and corrections (CW-010)."),
    ("C-23.03", "added", "", "48",
     "W0: 48 masters execution-quality and routing disclosure and CAT reporting (CW-010)."),
    ("C-23.04", "added", "", "49", "W0: New domain 49 masters the brokerage book of record (CW-007)."),
    ("C-23.05", "added", "", "49", "W0: 49 masters street-side clearing and settlement (CW-007)."),
    ("C-23.06", "added", "", "49",
     "W0: 49 masters customer protection: reserve computation, possession and control, counts (CW-007)."),
    ("C-23.07", "added", "", "49", "W0: 49 masters account transfers (ACATS) (plan §5.2)."),
    ("C-23.08", "added", "", "49", "W0: 49 masters margin, Reg T and fully paid lending (plan §5.2)."),
    ("C-23.09", "added", "", "49",
     "W0: 49 masters corporate actions and income posting to client accounts, DRIP and cost-basis reporting (plan "
     "§5.2)."),
    ("C-24.01", "added", "", "50", "W0: New domain 50 Money Movement, Cash & Sweep (CW-016)."),
    ("C-24.02", "added", "", "50",
     "W0: 50 masters sweep programs, program banks and FDIC pass-through allocation (CW-016)."),
    ("C-24.03", "added", "", "50", "W0: 50 masters holds, returns and fraud and elder-exploitation holds (CW-016)."),
    ("C-24.04", "added", "", "50", "W0: 50 masters cash-movement AML monitoring; the program stays 38's (CW-016)."),
    ("C-25.01", "added", "", "52", "W0: New domain 52 External Manager & Sub-Adviser Oversight (CW-014)."),
    ("C-25.02", "added", "", "52",
     "W0: 52 masters sub-advisory agreements, mandate guidelines and 15(c) renewal data (CW-014)."),
    ("C-25.03", "added", "", "52", "W0: 52 masters oversight reviews and findings (CW-014)."),
    ("C-25.04", "added", "", "52",
     "W0: 52 masters third-party fund and ETF due diligence and approved and watch lists (CW-014)."),
    ("C-26.01", "note", "C-11.10", "C-26.01",
     "W0: moved from C-11.10 (L1 C-11) to L1 C-26 Client Assets, Economics & Insight; id changed with the L1."),
    ("C-26.01", "name", "Flow & AUM Attribution", "Client Assets & Net New Assets",
     "W0: 06 becomes Client Assets, Flows & Channel Attribution (plan §5.1, CW-011)."),
    ("C-26.01", "area", "Distribution & Client", "Distribution, Channels & Client Economics",
     "W0: the wealth-manager areas (CW-018)."),
    ("C-26.01", "definition", "", "firms, offices, advisors and territories -> channel, advisor, campaign and plan",
     "W0: 06 adapted (plan §5.1)."),
    ("C-26.01", "reads", "15, 07, 02, 29, 01, 05, 30", "49, 29, 15, 02, 01, 05, 16, 04, 03",
     "W0: +03, +04, +16, +49, -07, -30; +49 client holdings, +16 plan flows, +04 campaigns, +03 advisors; 07 and 30 "
     "retired."),
    ("C-26.01", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-26.01", "note", "owner Head of Sales Operations", "owner Head of Client & Channel Analytics",
     "W0: owner role re-cut for the wealth manager."),
    ("C-26.02", "note", "C-11.13", "C-26.02",
     "W0: moved from C-11.13 (L1 C-11) to L1 C-26 Client Assets, Economics & Insight; id changed with the L1."),
    ("C-26.02", "name", "Distribution Profitability", "Client & Offering Profitability",
     "W0: 10 becomes Client Revenue, Pricing Economics & Profitability (CW-012)."),
    ("C-26.02", "area", "Distribution & Client", "Distribution, Channels & Client Economics",
     "W0: the wealth-manager areas (CW-018)."),
    ("C-26.02", "definition", "", "channel and partner -> client segment, channel and offering; + lifetime value",
     "W0: 10 adapted (CW-012)."),
    ("C-26.02", "reads", "19, 06, 05, 07, 01, 27", "19, 06, 47, 01, 27, 02, 05",
     "W0: +02, +47, -07; +47 fee revenue, +02 client segments; 07 retired."),
    ("C-26.02", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    ("C-26.02", "note", "owner Head of Distribution Finance", "owner Head of Client Economics",
     "W0: owner role re-cut for the wealth manager."),
    ("C-26.03", "note", "C-11.14", "C-26.03",
     "W0: moved from C-11.14 (L1 C-11) to L1 C-26 Client Assets, Economics & Insight; id changed with the L1."),
    ("C-26.03", "area", "Distribution & Client", "Distribution, Channels & Client Economics",
     "W0: the wealth-manager areas (CW-018)."),
    ("C-26.03", "definition", "", "+ retail, advice and workplace markets, competitors' offerings",
     "W0: 11 adapted (plan §5.1)."),
    ("C-26.03", "lines", "all", "all", "W0: re-tagged to the business lines of CW-004."),
    # ---- W5 coverage test (2026-10-16): the reads of the capabilities mastered by 45-52 and the replaced 02, 03, 05, 08
    # and 15 re-tested against the merged modules (Reference and Derived copy attributes and the documented hand-offs in
    # the module overviews and enrichment summaries, READS_CONVENTION); field "area" is the function area.
    ("C-03.05", "area", "Distribution, Channels & Client Economics", "Investment",
     "W5: run by FN-23 Trading & ETF Capital Markets (Investment), under L1 C-03 Portfolio Trading & Execution; 05 keeps "
     "the authorized participant agreement it masters."),
    ("C-07.05", "area", "Fund Operations", "Distribution, Channels & Client Economics",
     "W5: run by FN-77 Client & Channel Analytics (Distribution, Channels & Client Economics) and mastered by 06 "
     "(intermediary feed reconciliations to the 29 register)."),
    ("C-15.01", "reads", "09, 14", "09, 13", "W5: +13 (Authority Grant and Death Notification intake service requests); "
     "-14 (no reference in 02)."),
    ("C-15.04", "reads", "04, 15, 01, 39", "04, 15, 01, 13", "W5: +13 (Initial Privacy Notice, returned mail); -39 (no "
     "reference in 02)."),
    ("C-15.05", "reads", "02, 01, 08, 05", "02, 01, 08, 16, 51", "W5: +16 (Plan Participant Account copies the participant "
     "plan membership and status), +51 (Governing Trust of a trust registration); -05 (no reference in 15)."),
    ("C-16.01", "reads", "02, 15, 49, 14, 24", "02, 15, 49, 14, 24, 37", "W5: +37 (planning and projection engines are 37 "
     "Model Inventory Entries)."),
    ("C-16.02", "reads", "02, 15, 01, 52, 47, 08", "02, 15, 01, 47, 08, 37", "W5: +37 (recommendation engine); -52 (45 "
     "holds no reference to the 52 approved lists)."),
    ("C-17.02", "reads", "49, 24, 22, 17, 15", "49, 24, 17, 15", "W5: -22 (drift is measured on 49 valuations; no 22 "
     "reference in 46)."),
    ("C-18.03", "reads", "18, 01, 19, 06, 12", "18, 01, 19", "W5: -06, -12 (no reference in 47; mandate valuations are 18 "
     "and the institutional client a 02 party)."),
    ("C-19.02", "reads", "45, 48, 49, 15, 03, 46", "45, 48, 49, 15, 03", "W5: -46 (no reference in 08)."),
    ("C-19.04", "reads", "04, 01, 42, 32", "04, 01", "W5: -42, -32 (no reference in 08)."),
    ("C-20.02", "name", "Client Assignment & Advisor Capacity", "Client Assignment, Advisor Capacity & Activity",
     "W5: 03 is the one activity master (CW-062; W2-W4 merge ruling): Advisor Activities & Interactions and Channel Referrals "
     "had no capability."),
    ("C-20.02", "definition", "", "+ recording advisors' client activities, interactions and channel referrals",
     "W5: as the name."),
    ("C-20.02", "reads", "02, 15, 01, 06", "02, 15, 01, 06, 04, 13", "W5: +04 (Related Campaign, Content Assets Shared, "
     "Resulting Marketing Lead), +13 (Originating Service Request, Client Notice Delivery)."),
    ("C-20.02", "lines", "DB, HA, TR", "DB, HA, TR, IA, IC", "W5: partner and consultant meetings are 03 activity types."),
    ("C-20.03", "reads", "06, 20, 02, 01, 19, 45", "06, 20, 02, 01, 45", "W5: -19 (no reference in 03)."),
    ("C-22.01", "reads", "02, 15, 49, 46", "02, 15, 49, 50", "W5: +50 (distribution payments); -46 (46 reads the 51 "
     "trust terms, not the reverse)."),
    ("C-22.02", "reads", "49, 15, 19, 02", "49, 15, 02", "W5: -19 (the firm's own tax is a boundary, not a read)."),
    ("C-23.09", "reads", "17, 15, 13, 28", "17, 15, 13", "W5: -28 (no 49 object copies a 28 object; 49 summary)."),
    ("C-25.01", "reads", "02, 32, 23, 22, 14", "02, 32, 22, 14, 24", "W5: +24 (Search Outcome approving Investment "
     "Committee Decision); -23 (security and issuer research is 23, not 52)."),
    ("C-25.04", "reads", "17, 01, 32, 14, 22", "17, 01, 32, 14, 22, 24", "W5: +24 (Product Approving Decision)."),
    ("C-12.16", "note", "function FN-13", "function FN-68", "W5: the Phase 2 note named FN-13 (distribution compliance); "
     "the capability is run by FN-68 Retail Supervision & Conduct (Client & Advice) and its area stays Corporate Functions "
     "(firm-wide records management); a boundary call, not a mismatch."),
    ("C-08.06", "note", "masters 05", "kept", "W5: no merged module holds a CIT participation agreement or participating-plan "
     "eligibility object (05 agreement types do not list one); content finding for the 05 and 16 owners (B), kept "
     "until one is added."),
]
