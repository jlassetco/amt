"""Baseline regression check for the protected Data Domains and everything built on them.

The distribution taxonomy is frozen at git tag distribution-v0.4. During the enterprise expansion (Data Domains 17+),
this script proves after each stage that the protected domains (01-16 for distribution-v0.4 and stage1-v0.1; every
domain merged so far for later snapshots such as stage2-v0.1, recorded in the snapshot's meta.domains), the
consolidation registers, the data products, the logical models and the semantic models are unchanged, except where a
logged decision (CD-nnn, or CW-nnn on the wealth-manager branch) says so.
See 00_Program/Enterprise_Expansion_Plan.md sections 2 and 9.

Wealth-manager sibling (branch feature/wealth-manager; Wealth_Manager_Rework_Plan.md sections 3 and 9; CW-019). The
branch is checked against wholesale-v1.0 (Data Domains 01-44) until wealth-taxonomy-v0.1 is taken at W5:
- Carried domains (DISPOSITION keep or adapt in domains.py) are compared in full, as before.
- A domain with DISPOSITION "replace" (02, 03, 05, 08, 15) whose current module name differs from the baseline's, or
  whose object or attribute count differs by more than 50 percent, is "replaced": it is compared by counts only and
  reported as "Data Domain NN replaced (counts only; CW-nnn)", not as a difference. --replaced NN,NN forces it for
  any domain (for a replacement that kept the module name and lands near the old size).
- A domain in RETIRED_DOMAINS is reported as "retired by CW-nnn", not as a removal (07 by CW-907 and 30 by CW-930 at
  the W2-W4 merge; their modules and folders are deleted, their numbers stay registered).
- A PREFIXES row whose status became "Retired (sibling)" (a wholesale-origin prefix retired in the wealth model, live
  in the wholesale sibling, never reused; W2-W4 merge ruling 3) is reported with the wealth-model additions as
  "retired in the wealth model", not as a changed entry; any other change to the row still fails.
- The replaced 03, 05 and 08 (W2-W4 merge) are compared by counts only, as 02 and 15 were at W1: their module names
  changed. The adapted domains renamed at the merge (04, 06, 10, 13) keep their module names and are compared in full
  under their new names.
- Domains absent from the baseline (45-52, and any other) are expansion additions, as before.
- A new register entry whose decision id starts with "CW-", a TERM_CONFLICTS entry carrying "decision": "CW-nnn", or an
  entry that names a new wealth domain (DISPOSITION "new", 45-52) is reported under "Wealth-model additions (not
  failures)". Any change to or removal of an existing entry still fails, and so does any other new entry that names
  a protected domain.
- Products and functions retired at WP0 (framework.RETIRED_PRODUCTS, RETIRED_FUNCTIONS) are reported with the retired
  domains as "retired by CW-nnn" (and whether they were live or pending in the baseline), never as removals or changes;
  they are left out of per_product and per_function, and warnings about them go with the pending list.
- Products, logical models and semantic models pending WP0 re-scope (framework.RESCOPE_PENDING and
  register.PENDING; CW-041) are listed under "Pending WP0 re-scope (not failures; CW-041)" with their counts. They stay
  in the totals and are never reported as removals or changes; warnings that only reflect the pending state go with them.

Everything is computed in memory from the content modules, the consolidation layer and enrichment (the .xlsx outputs
are never read or written).

Usage (from _tools/):
  python check_baseline.py --snapshot [name]          write baseline/<name>.json (default distribution-v0.4)
  python check_baseline.py [--check [name]]           compare against baseline/<name>.json; exit 1 on any difference
  python check_baseline.py --check --allow CD-101,CD-102
                                                      annotate the report with the decisions the differences must
                                                      trace to (never suppresses a difference)
  python check_baseline.py --check wholesale-v1.0 --replaced 02,15
                                                      compare 02 and 15 by counts only, as replaced domains
  --replaced NN,...   Data Domains to compare by counts only as replaced domains, in addition to those detected from
                      domains.DISPOSITION "replace" (a changed module name or a count off by more than 50 percent). Use it
                      for a replacement that kept its module name and lands near the old size. Since the W2-W4 merge the
                      detected set against wholesale-v1.0 and wealth-w1b-v0.1 is 02, 03, 05, 08 and 15; against
                      wealth-w4-v0.1 every domain is compared in full and nothing needs --replaced. Unknown numbers exit 2.

The summary prints two lines per side: the headline totals cover the compared set (the snapshot's protected domains)
only; the second line gives the full build (compared set plus the expansion additions not in it), so a "42 domains"
headline against an older snapshot is not misread as the size of the model.

Both modes also run the whole-build validators (taxonomy_builder validation of every content module, enrichment
checks, data products, logical models, semantic models) and fail if any fails or any domain has an unresolved
reference.
"""
import argparse, collections, contextlib, datetime, hashlib, importlib, io, json, os, subprocess, sys, time

sys.dont_write_bytecode = True
TOOLS = os.path.dirname(os.path.abspath(__file__))
for p in (os.path.join(TOOLS, "data_products"), os.path.join(TOOLS, "data_models"), os.path.join(TOOLS, "semantic_model"),
          os.path.join(TOOLS, "consolidation"), os.path.join(TOOLS, "enrichment"), TOOLS):
    if p not in sys.path:
        sys.path.insert(0, p)

import taxonomy_builder as tb  # noqa: E402

BASELINE_DIR = os.path.join(TOOLS, "baseline")
from domains import DISTRIBUTION_DOMAINS as BASELINE_DOMAINS  # noqa: E402  ("01".."16")
from domains import DISPOSITION, DISPOSITION_DECISION, RETIRED_DOMAINS, NEW_DOMAINS  # noqa: E402  (wealth model, CW-019)
DEFAULT_NAME = "distribution-v0.4"
RETIRED_SIBLING = "Retired (sibling)"     # prefix status of a wholesale-origin prefix retired in the wealth model


# ------------------------------------------------------------------------------------------------------------ helpers
def _plain(o):
    """JSON fallback: sets in a stable order, anything else by repr."""
    if isinstance(o, (set, frozenset)):
        return sorted(o, key=repr)
    return repr(o)


def canon(o):
    """Nested structure with non-string dict keys (e.g. tuple keys) turned into their repr."""
    if isinstance(o, dict):
        return {k if isinstance(k, str) else repr(k): canon(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [canon(x) for x in o]
    if isinstance(o, (set, frozenset)):
        return [canon(x) for x in sorted(o, key=repr)]
    return o


def h(obj):
    """Short stable hash of any nested structure (tuples and lists hash the same; dict keys are sorted)."""
    s = json.dumps(canon(obj), sort_keys=True, ensure_ascii=False, default=_plain)
    return hashlib.sha256(s.encode("utf-8")).hexdigest()[:16]


def strip_private(d):
    """Drop keys starting with '_' (validator scratch fields such as _file, _cols) from nested dicts."""
    if isinstance(d, dict):
        return {k: strip_private(v) for k, v in d.items() if not str(k).startswith("_")}
    if isinstance(d, (list, tuple)):
        return [strip_private(x) for x in d]
    return d


def content_modules():
    """{NN: module name} for every content_NN_*.py."""
    out = {}
    for f in sorted(os.listdir(tb.CONTENT)):
        if f.startswith("content_") and f.endswith(".py"):
            out[f.split("_")[1]] = f[:-3]
    return out


def git_head():
    try:
        return subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=TOOLS, capture_output=True, text=True,
                              timeout=10).stdout.strip()
    except Exception:
        return ""


# ------------------------------------------------------------------------------------------------------ taxonomy
def domain_record(m):
    """Counts and hashes for one Consolidated module, matching the builder's per-domain summary line."""
    fams = tb.model(m)
    objs = [(f, o) for f in fams for o in f["objects"]]
    xs = [x for _, o in objs for x in o["attrs"]]
    obj_hashes, attr_rows, own_rows = {}, [], []
    for f, o in objs:
        key = f"{f['name']} / {o['name']}"
        obj_hashes[key] = h([o["code"], o["group"], o["group_def"], o["grain"], o["kind"], o["parent"],
                             [[x["id"], list(x["a"]), x["flag"], x["owner"]] for x in o["attrs"]]])
        for x in o["attrs"]:
            attr_rows.append([f["name"], o["name"], x["id"], list(x["a"])])
            own_rows.append([f["name"], o["name"], x["a"][0], x["flag"], x["owner"]])
    own_rows += [[f["name"], o["name"], o["grain"], o["kind"], o["parent"]] for f, o in objs]
    shared = sorted(k for k in m.CL if k.startswith("Shared: "))
    return {
        "module": m.__name__,
        "families": len(fams),
        "objects": len(objs),
        "attribute_groups": sum(o["kind"] == "Attribute Group" for _, o in objs),
        "without_grain": sum(not o["grain"] for _, o in objs),
        "attributes": len(xs),
        "cdes": sum(x["a"][8] == "Y" for x in xs),
        "references": sum(x["flag"] == "Reference" for x in xs),
        "derived": sum(x["flag"] == "Derived copy" for x in xs),
        "unresolved": sum(x["flag"].startswith("Unres") for x in xs),
        "code_lists_local": len(m.CL) - len(shared),
        "code_lists_shared": len(shared),
        "relationships": len(m.REL),
        "object_list": sorted([f["name"], o["name"]] for f, o in objs),
        "attributes_hash": h(attr_rows),
        "ownership_grain_hash": h(own_rows),
        "families_hash": h([[f["code"], f["name"], f["def"]] for f in fams]),
        "code_lists_hash": h(sorted([k, list(v[0:1]) + [list(map(list, v[1]))]] for k, v in m.CL.items())),
        "relationships_hash": h(m.REL),
        "sources_hash": h(m.SRC),
        "object_hashes": obj_hashes,
    }


def taxonomy(scl, report, protected=BASELINE_DOMAINS):
    """Validate every content module (the --all build, without writing workbooks) and record the protected domains
    (01-16 for distribution-v0.4 and stage1-v0.1; every domain merged so far for later snapshots)."""
    domains, expansion, ok = {}, {}, True
    mods = content_modules()
    for n, name in mods.items():
        try:
            m = tb.Consolidated(importlib.import_module(name), scl)
            errs = tb.validate(m)
            rec = domain_record(m)
        except Exception as e:                        # a module that does not load is a failure, not a traceback
            ok = False
            report.append(f"FAIL  {name}: does not load ({e.__class__.__name__}: {str(e)[:300]})")
            continue
        if errs:
            ok = False
            report.append(f"FAIL  taxonomy_builder validation [{name}]: " + "; ".join(errs[:5]))
        if rec["unresolved"]:
            ok = False
            report.append(f"FAIL  {n}: {rec['unresolved']} unresolved reference(s) (must be 0)")
        if n in protected:
            domains[n] = rec
        else:
            expansion[n] = {k: rec[k] for k in ("module", "families", "objects", "attributes", "cdes", "references",
                                                 "unresolved", "relationships")}
    extra = sorted(n for n in mods if n not in protected)
    report.append(f"{'ok  ' if ok else 'FAIL'}  taxonomy_builder validation: {len(mods)} content module(s)"
                  f"{' (not in baseline: ' + ', '.join(extra) + ')' if extra else ''}; unresolved references: "
                  f"{'0 in every domain' if ok else 'see above'}")
    return domains, expansion, ok


def enrichment(report):
    """Run enrichment/check_enrichment.py NN for every domain that has an enrichment file."""
    bad = []
    nn = [n for n in content_modules() if os.path.exists(os.path.join(TOOLS, "enrichment", f"enrich_{n}.py"))]
    for n in nn:
        r = subprocess.run([sys.executable, os.path.join(TOOLS, "enrichment", "check_enrichment.py"), n], cwd=TOOLS,
                           capture_output=True, text=True, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
        if r.returncode != 0:
            bad.append(n)
            tail = (r.stdout + r.stderr).strip().splitlines()[-3:]
            report.append(f"FAIL  check_enrichment.py {n}: " + " | ".join(tail))
    report.append(f"{'ok  ' if not bad else 'FAIL'}  check_enrichment.py: {len(nn)} domain(s), {len(bad)} failed")
    return not bad


def registers(scl):
    import decisions as dec
    import exclusions as exc
    return {
        "decisions": {d["id"]: h(d) for d in dec.DECISIONS},
        "prefixes": {p[0]: h(p) for p in dec.PREFIXES},
        "concept_ownership": {c[0]: h(c) for c in dec.CONCEPT_OWNERSHIP},
        "term_conflicts": {t["term"]: h(t) for t in dec.TERM_CONFLICTS},
        "shared_code_lists": {s["name"]: h(s) for s in scl.SHARED},
        "local_renames": h(scl.LOCAL_RENAMES),
        "excluded_objects": sorted(exc.EXCLUDED_OBJECTS),
    }


def register_domains(scl):
    """{register: {key: [Data Domains the entry names]}}, used to tell expansion additions (17+ only) from changes to 01-16.
    Informational: never compared."""
    import decisions as dec
    return {
        "decisions": {d["id"]: list(d.get("domains", [])) for d in dec.DECISIONS},
        "prefixes": {p[0]: [p[2]] for p in dec.PREFIXES},
        "concept_ownership": {c[0]: [c[1]] for c in dec.CONCEPT_OWNERSHIP},
        "term_conflicts": {t["term"]: sorted({u[0] for u in t.get("usages", [])}) for t in dec.TERM_CONFLICTS},
        "shared_code_lists": {s["name"]: sorted({s["steward"]} | {d for d, _ in s["members"]} | set(s.get("direct_users", [])))
                              for s in scl.SHARED},
    }


def wealth_keys():
    """{register: [keys]} of entries the wealth model added by series: CW- decisions, TERM_CONFLICTS entries that carry
    a CW- "decision" and PREFIXES rows with status "Reserved". Informational: never compared (entries that name 45-52 are found from register_domains)."""
    import decisions as dec
    return {"decisions": sorted(d["id"] for d in dec.DECISIONS if d["id"].startswith("CW-")),
            "term_conflicts": sorted(t["term"] for t in dec.TERM_CONFLICTS if str(t.get("decision", "")).startswith("CW-")),
            # a reserved prefix is a reservation for a brief, not a change to any domain's content (W1 briefs, CW-040)
            "prefixes": sorted(p[0] for p in dec.PREFIXES if len(p) > 3 and str(p[3]).startswith("Reserved")),
            # a wholesale-origin prefix retired in the wealth model (W2-W4 merge ruling 3): a retirement, not a change
            "retired_prefixes": sorted(p[0] for p in dec.PREFIXES if len(p) > 3 and str(p[3]) == RETIRED_SIBLING)}


def expansion_only(domains, protected=BASELINE_DOMAINS):
    """True when an entry names at least one Data Domain and every one of them is outside the protected domains (17 or
    higher against distribution-v0.4 and stage1-v0.1; 31 or higher against stage2-v0.1)."""
    return bool(domains) and all(str(d).isdigit() and str(d) not in protected for d in domains)


# ------------------------------------------------------------------------------------------------ products layer
def products_layer(report):
    """Data products (dp_model), logical models (dm_model) and semantic models (sm_model), validated in-process."""
    import dp_model, dm_model, sm_model
    import framework as fw
    out = {}

    def dp():
        objs = dp_model.load_taxonomy()
        specs, _, load_errs = dp_model.load_specs()
        errs, warns = dp_model.validate(specs, objs)
        errs = load_errs + errs
        links_by_domain, per = {}, {}
        reg = {p[0]: p for p in fw.PRODUCTS}
        for pid, s in sorted(specs.items()):
            for n, _, a in s["inputs"]:
                links_by_domain[n] = links_by_domain.get(n, 0) + len(a)
            per[pid] = {"links": sum(len(a) for _, _, a in s["inputs"]), "hash": h(s)}
        gone = {pid: per[pid] for pid in per if dp_model.is_retired(pid)}     # retired at WP0 (RETIRED_PRODUCTS)
        held = {pid: per[pid] for pid in per if dp_model.is_pending(pid) and pid not in gone}   # pending WP0 re-scope (CW-041)
        return {
            "products": len(fw.PRODUCTS), "specified": len(specs), "backlog": len(fw.BACKLOG),
            "functions": len(fw.FUNCTIONS),
            "measures": sum(len(s["measures"]) for s in specs.values()),
            "dq_rules": sum(len(s["dq_rules"]) for s in specs.values()),
            "input_objects": sum(len(s["inputs"]) for s in specs.values()),
            "attribute_links": sum(p["links"] for p in per.values()),
            "upstream_edges": sum(len(s["upstream"]) for s in specs.values()),
            "links_by_domain": dict(sorted(links_by_domain.items())),
            "register_hash": h([fw.BACKLOG]),
            "errors": len(errs), "warnings": sorted(warns),
            "per_function": {f[0]: h(f) for f in fw.FUNCTIONS if f[0] not in dp_model.RETIRED_FNS},
            "per_product": {pid: {**per[pid], "register": h(reg[pid]), "domain": reg[pid][4]} for pid in per
                            if pid not in held and pid not in gone},
            "pending": {pid: {**held[pid], "register": h(reg[pid]), "domain": reg[pid][4]} for pid in held},
            "retired_products": {pid: dp_model.RETIRED[pid] for pid in sorted(dp_model.RETIRED)},
            "retired_functions": dict(sorted(dp_model.RETIRED_FNS.items())),
        }, errs, (f"{len(specs) - len(held) - len(gone)} live spec(s)" + (f" + {len(held)} pending WP0 re-scope" if held else "")
                  + (f" + {len(gone)} retired" if gone else ""))

    def dm():
        logical, errs, warns = dm_model.validate()
        held = dict(dm_model.PENDING_OUT)          # pending WP0 re-scope (CW-041): counted in the totals, listed apart
        rec = lambda ms: {pid: {"entities": len(m["entities"]), "relationships": len(m["relationships"]), "hash": h(m)}
                          for pid, m in sorted(ms.items())}
        both = {**logical, **held}
        return {
            "models": len(both),
            "entities": sum(len(m["entities"]) for m in both.values()),
            "relationships": sum(len(m["relationships"]) for m in both.values()),
            "errors": len(errs), "warnings": sorted(warns),
            "per_model": rec(logical), "pending": rec(held),
        }, errs, f"{len(logical)} model(s)" + (f" + {len(held)} pending WP0 re-scope" if held else "")

    def sm():
        models, _, _, _, errs, warns = sm_model.load()
        held = {mid: m for mid, m in sm_model.load_models()[0].items() if mid in sm_model.PENDING}   # CW-041
        both = {**models, **held}
        mets = [x for m in both.values() for x in m.get("metrics", [])]
        return {
            "models": len(both),
            "tables": sum(len(m.get("tables", [])) for m in both.values()),
            "metrics_defined": sum(1 for x in mets if not x.get("ref")),
            "metrics_referenced": sum(1 for x in mets if x.get("ref")),
            "errors": len(errs), "warnings": sorted(warns),
            "per_model": {mid: h(strip_private(m)) for mid, m in sorted(models.items())},
            "pending": {mid: h(strip_private(m)) for mid, m in sorted(held.items())},
        }, errs, f"{len(models)} model(s)" + (f" + {len(held)} pending WP0 re-scope" if held else "")

    ok = True
    for key, script, fn in (("data_products", "dp_model.py", dp), ("data_models", "dm_model.py", dm),
                            ("semantic_models", "sm_model.py", sm)):
        if not ok and key == "semantic_models":
            report.append(f"FAIL  {script}: not run (an earlier layer failed)")
            out[key] = {"crashed": "not run"}
            continue
        try:
            rec, errs, what = fn()
        except (Exception, SystemExit) as e:          # a validator that crashes is a failure, not a traceback
            msg = f"{e.__class__.__name__}: {e}"
            report.append(f"FAIL  {script}: crashed ({msg[:300]})")
            out[key], ok = {"crashed": msg}, False
            continue
        ok &= not errs
        report.append(f"{'ok  ' if not errs else 'FAIL'}  {script}: {what}, {len(errs)} error(s), "
                      f"{len(rec['warnings'])} warning(s)")
        report += [f"        ERROR {e}" for e in errs[:10]]
        out[key] = rec
    return out, ok


# ------------------------------------------------------------------------------------------------------- compute
def compute(protected=BASELINE_DOMAINS):
    report = []
    scl = tb.load_consolidation()
    with contextlib.redirect_stdout(io.StringIO()):     # keep imported modules quiet
        domains, expansion, ok1 = taxonomy(scl, report, protected)
    ok2 = enrichment(report)
    with contextlib.redirect_stdout(io.StringIO()):
        prod, ok3 = products_layer(report)
    snap = {"domains": domains, "registers": registers(scl), **prod,
            "expansion_modules": expansion, "register_domains": register_domains(scl), "wealth_keys": wealth_keys()}
    snap["totals"] = {k: sum(d[k] for d in domains.values())
                      for k in ("families", "objects", "attribute_groups", "attributes", "cdes", "references", "derived",
                                "unresolved", "code_lists_local", "code_lists_shared", "relationships")}
    snap["totals"]["domains"] = len(domains)
    return snap, report, ok1 and ok2 and ok3


# ---------------------------------------------------------------------------------------------------------- diff
COUNTS = ["families", "objects", "attribute_groups", "without_grain", "attributes", "cdes", "references", "derived",
          "unresolved", "code_lists_local", "code_lists_shared", "relationships"]
HASHES = {"attributes_hash": "attributes changed (names, definitions, types, code lists, examples, references, CDE or notes)",
          "ownership_grain_hash": "ownership flags or grain changed",
          "families_hash": "family codes, names or definitions changed",
          "code_lists_hash": "code list values changed",
          "relationships_hash": "relationships changed",
          "sources_hash": "sources changed"}


def delta(a, b):
    if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):   # a renamed product or other text field
        return f"{a!r} -> {b!r}"
    d = b - a
    return f"{a} -> {b} ({'+' if d > 0 else ''}{d})"


def diff_keyed(label, old, new, out, info, doms, protected=BASELINE_DOMAINS, wealth=None, wkeys=(), retired=()):
    """Added / removed / changed keys of a {key: hash} register. Additions that name only unprotected Data Domains go to
    info; additions of the wealth model (a CW- key, or an entry naming a new wealth domain) go to wealth. Changed keys in
    retired (prefixes now 'Retired (sibling)') go to wealth as retirements in the wealth model."""
    add = sorted(set(new) - set(old)); rem = sorted(set(old) - set(new))
    if wealth is not None and retired:
        rt = sorted(k for k in set(old) & set(new) if k in retired and old[k] != new[k])
        if rt:
            wealth.append(f"  {label}: {len(rt)} retired in the wealth model (status '{RETIRED_SIBLING}'): " + ", ".join(rt))
            old = {k: v for k, v in old.items() if k not in rt}
            new = {k: v for k, v in new.items() if k not in rt}
    if wealth is not None:
        wk = [k for k in add if k in wkeys or any(str(d) in NEW_DOMAINS for d in doms.get(k, []))]
        if wk:
            wealth.append(f"  {label}: {len(wk)} added: " + ", ".join(
                f"{k} ({'/'.join(map(str, doms[k]))})" if doms.get(k) else k for k in wk))
        add = [k for k in add if k not in wk]
    exp = [k for k in add if expansion_only(doms.get(k, []), protected)]
    if exp:
        info.append(f"  {label}: {len(exp)} added for Data Domains {int(max(protected)) + 1}+: "
                    + ", ".join(f"{k} ({'/'.join(doms[k])})" for k in exp))
    add = [k for k in add if k not in exp]
    chg = sorted(k for k in set(old) & set(new) if old[k] != new[k])
    if add or rem or chg:
        out.append(f"  {label}: {len(add)} added, {len(rem)} removed, {len(chg)} changed (total {delta(len(old), len(new))})")
        for tag, ks in (("added", add), ("removed", rem), ("changed", chg)):
            if ks:
                out.append(f"    {tag}: " + ", ".join(ks[:25]) + (f" ... (+{len(ks) - 25} more)" if len(ks) > 25 else ""))


def diff_domain(n, a, b, out):
    lines = []
    for k in COUNTS:
        if a.get(k) != b.get(k):
            lines.append(f"  {k.replace('_', ' ')}: {delta(a.get(k, 0), b.get(k, 0))}")
    ao = {tuple(x) for x in a["object_list"]}; bo = {tuple(x) for x in b["object_list"]}
    for tag, s in (("objects added", bo - ao), ("objects removed", ao - bo)):
        if s:
            lines.append(f"  {tag}: " + "; ".join(f"{f} / {o}" for f, o in sorted(s)))
    for k, msg in HASHES.items():
        if a.get(k) != b.get(k):
            lines.append(f"  {msg}")
    chg = sorted(k for k in set(a["object_hashes"]) & set(b["object_hashes"]) if a["object_hashes"][k] != b["object_hashes"][k])
    if chg:
        lines.append("  objects whose content or position-based IDs changed: " + "; ".join(chg))
    if lines:
        out.append(f"Data Domain {n} {tb.DD_NAMES.get(n, '')} [{b.get('module', a.get('module'))}]")
        out += lines


def replaced_how(n, a, b, forced=()):
    """Why Data Domain n counts as replaced against the baseline (CW-019), or None. a and b are the baseline and current
    domain records."""
    if n in forced:
        return "--replaced"
    if DISPOSITION.get(n, ("",))[0] != "replace":
        return None
    if a["module"] != b["module"]:
        return f"module {a['module']} -> {b['module']}"
    for k in ("objects", "attributes"):
        if a.get(k) and abs(b.get(k, 0) - a[k]) / a[k] > 0.5:
            return f"{k} {delta(a[k], b.get(k, 0))}, more than 50 percent"
    return None


def counts_line(r):
    return (f"{r['families']} families, {r['objects']} objects, {r['attributes']} attributes, {r['cdes']} CDEs, "
            f"{r['references']} references, {r['relationships']} relationships")


def diff(old, new, protected=BASELINE_DOMAINS, replaced=()):
    """Returns (differences, expansion additions, wealth-model additions, replaced and retired domains, pending WP0
    re-scope). Differences fail the check; the other four do not."""
    out, info, wealth, swaps, held = [], [], [], [], []
    for n, e in sorted(new.get("expansion_modules", {}).items()):
        b = old.get("expansion_modules", {}).get(n)
        if b:     # merged in an earlier stage but recorded in this baseline by counts only: a count change is a difference
            lines = [f"  {k}: {delta(b[k], e[k])}" for k in b if k != "module" and b[k] != e.get(k)]
            if lines:
                out.append(f"Data Domain {n} {tb.DD_NAMES.get(n, '')} [{e['module']}] (counts only in this baseline)")
                out += lines
            continue
        info.append(f"  Data Domain {n} {tb.DD_NAMES.get(n, '')} [{e['module']}]: {e['families']} families, {e['objects']} "
                    f"objects, {e['attributes']} attributes, {e['cdes']} CDEs, {e['references']} references, "
                    f"{e['unresolved']} unresolved, {e['relationships']} relationships")
    built = set(new.get("expansion_modules", {})) | set(new.get("domains", {}))
    pending = [n for n in NEW_DOMAINS if n not in built and n not in protected]
    if pending:                                           # registered in domains.py, module not yet drafted
        wealth.append(f"  Data Domains registered in domains.py, no content module yet: "
                      + ", ".join(f"{n} {tb.DD_NAMES.get(n, '')} ({DISPOSITION_DECISION.get(n, '')})" for n in pending))
    rdoms = new.get("register_domains", {})
    for n in protected:
        a, b = old["domains"].get(n), new["domains"].get(n)
        if n in RETIRED_DOMAINS:                          # CW-019: retired, not removed
            was = f"was {a['module']}: {counts_line(a)}" if a else "not in the baseline"
            swaps.append(f"  Data Domain {n} {tb.DD_NAMES.get(n, '')} retired by {RETIRED_DOMAINS[n]} ({was})"
                         + ("; its content module is still present" if b else ""))
            continue
        how = replaced_how(n, a, b, replaced) if a and b else None
        if how:                                           # CW-019: replaced, compared by counts only
            name = DISPOSITION.get(n, ("", ""))[1] or tb.DD_NAMES.get(n, "")
            swaps.append(f"  Data Domain {n} replaced (counts only; {DISPOSITION_DECISION.get(n, 'CW-019')}): {name} "
                         f"[{b['module']}] ({how})")
            swaps += [f"    {k.replace('_', ' ')}: {delta(a.get(k, 0), b.get(k, 0))}" for k in COUNTS
                      if a.get(k) != b.get(k)] or ["    counts unchanged"]
            continue
        if a and not b:
            out.append(f"Data Domain {n}: content module missing or does not load (was {a['module']})")
        elif b and not a:
            out.append(f"Data Domain {n}: not in the baseline")
        elif a and b:
            diff_domain(n, a, b, out)

    reg, wkeys = [], new.get("wealth_keys", {})
    for k in ("decisions", "prefixes", "concept_ownership", "term_conflicts", "shared_code_lists"):
        diff_keyed(k.replace("_", " ").capitalize(), old["registers"][k], new["registers"][k], reg, info, rdoms.get(k, {}),
                   protected, wealth, set(wkeys.get(k, [])), set(wkeys.get("retired_" + k, [])))
    if old["registers"]["local_renames"] != new["registers"]["local_renames"]:
        reg.append("  Local code list renames changed")
    if old["registers"]["excluded_objects"] != new["registers"]["excluded_objects"]:
        reg.append(f"  Excluded objects: {old['registers']['excluded_objects']} -> {new['registers']['excluded_objects']}")
    if reg:
        out += ["Registers (consolidation/decisions.py, shared_code_lists.py, exclusions.py)"] + reg

    # products added since the baseline count as additions in every layer (a warning about one is not a difference)
    new_products = set(new.get("data_products", {}).get("per_product", {})) - set(old.get("data_products", {}).get("per_product", {}))
    for layer, per_key, title in (("data_products", "per_product", "Data products"),
                                  ("data_models", "per_model", "Logical data models"),
                                  ("semantic_models", "per_model", "Semantic models")):
        a, b, lines, added_info = old.get(layer, {}), new.get(layer, {}), [], []
        if "crashed" in a or "crashed" in b:
            if a != b:
                out += [title, f"  not comparable: {b.get('crashed') or a.get('crashed')}"]
            continue
        pa, pb = a.get(per_key, {}), b.get(per_key, {})
        hh = lambda v: v["hash"] if isinstance(v, dict) else v
        # Retired at WP0 (framework.RETIRED_PRODUCTS, RETIRED_FUNCTIONS): reported as "retired by CW-nnn", as retired
        # Data Domains are, never as removals or changes
        rp, rf = b.get("retired_products", {}), b.get("retired_functions", {})
        if rp or rf:
            names = {p[0]: p[1] for p in __import__("framework").PRODUCTS}
            was = lambda k: "live" if k in pa else ("pending" if k in a.get("pending", {}) else "not in the baseline")
            newly = [k for k in sorted(rp) if k not in a.get("retired_products", {})]
            if newly:
                swaps.append(f"  {title}: {len(newly)} retired: " + "; ".join(
                    f"{k} {names.get(k, '')} retired by {rp[k]} (was {was(k)})" for k in newly))
            fnew = [k for k in sorted(rf) if k not in a.get("retired_functions", {})]
            if fnew:
                swaps.append(f"  {title}: {len(fnew)} function(s) retired: " + ", ".join(f"{k} by {rf[k]}" for k in fnew))
            pa = {k: v for k, v in pa.items() if k not in rp}
            a = {**a, "per_function": {k: v for k, v in a.get("per_function", {}).items() if k not in rf},
                 "pending": {k: v for k, v in a.get("pending", {}).items() if k not in rp}}
        # Pending WP0 re-scope (CW-041): listed apart with their counts, never as removals or changes
        pend = {**a.get("pending", {}), **b.get("pending", {})}
        pb_all = {**pb, **b.get("pending", {})}
        if b.get("pending"):
            pn = b["pending"]
            moved = sorted(k for k in pn if k in pa or k in a.get("pending", {}))
            changed = [k for k in moved if hh(pn[k]) != hh(pa.get(k) or a.get("pending", {}).get(k))]
            extra = ""
            if pn and isinstance(next(iter(pn.values())), dict) and "entities" in next(iter(pn.values())):
                extra = (f"; {sum(v['entities'] for v in pn.values())} entities, "
                         f"{sum(v['relationships'] for v in pn.values())} relationships")
            elif pn and isinstance(next(iter(pn.values())), dict) and "links" in next(iter(pn.values())):
                extra = f"; {sum(v['links'] for v in pn.values())} attribute links"
            held.append(f"  {title}: {len(pn)} pending" + extra + ": " + ", ".join(sorted(pn))
                        + (f" ({len(changed)} changed since the baseline: {', '.join(changed)})" if changed else ""))
        add, rem = sorted(set(pb_all) - set(pa) - set(a.get("pending", {}))), sorted(set(pa) - set(pb_all))
        chg = sorted(k for k in set(pa) & set(pb) if hh(pa[k]) != hh(pb[k]) and k not in pend)
        fa, fb = a.get("per_function", {}), b.get("per_function", {})
        fadd = sorted(set(fb) - set(fa)); frem = sorted(set(fa) - set(fb))
        fchg = sorted(k for k in set(fa) & set(fb) if fa[k] != fb[k])
        # Additions are the data products expansion at work (Data_Products_Expansion_Plan.md §3): information, not
        # differences. Count deltas and new warnings that only reflect additions go with them.
        additions_only = (add or fadd) and not (rem or chg or frem or fchg)
        if add:
            added_info.append(f"  {title}: {len(add)} added: " + ", ".join(
                f"{k} ({pb[k]['domain']})" if isinstance(pb[k], dict) and "domain" in pb[k] else k for k in add))
        if fadd:
            added_info.append(f"  {title}: {len(fadd)} function(s) added: " + ", ".join(fadd))
        for k in a:
            if k in (per_key, "per_function", "warnings", "pending"):
                continue
            if additions_only and a.get(k) != b.get(k) and isinstance(a.get(k), (int, dict)):
                if isinstance(a[k], int):
                    added_info.append(f"  {k.replace('_', ' ')}: {delta(a[k], b[k])}")
                continue
            if a.get(k) != b.get(k):
                if isinstance(a.get(k), int) and isinstance(b.get(k), int):
                    lines.append(f"  {k.replace('_', ' ')}: {delta(a[k], b[k])}")
                elif isinstance(a.get(k), dict):
                    ks = sorted(set(a[k]) | set(b.get(k, {})))
                    lines.append(f"  {k.replace('_', ' ')}: " + ", ".join(
                        f"{x} {delta(a[k].get(x, 0), b.get(k, {}).get(x, 0))}" for x in ks if a[k].get(x) != b.get(k, {}).get(x)))
                else:
                    lines.append(f"  {k.replace('_', ' ')} changed")
        wa, wb = set(a.get("warnings", [])), set(b.get("warnings", []))
        # warnings on pending items, or that only report the pending state, go with the pending list (CW-041)
        held_ids = (set(pend) | set(new.get("data_products", {}).get("pending", {}))
                    | set(new.get("data_products", {}).get("retired_products", {})))
        about_held = lambda w: ("pending WP0 re-scope" in w or "re-point at WP0" in w or "re-point at WP1" in w
                                or "is retired (" in w or any(w.startswith(i + ":") for i in held_ids))
        hw_new, hw_gone = [w for w in wb - wa if about_held(w)], [w for w in wa - wb if about_held(w)]
        if hw_new or hw_gone:
            rp = sum(1 for w in hw_new if "re-point at WP0" in w)
            held.append(f"  {title}: {len(hw_new)} warning(s) added and {len(hw_gone)} cleared by the pending and retired registers"
                        + (f" ({rp} are dependencies to re-point at WP0)" if rp else ""))
        wa, wb = wa - set(hw_gone), wb - set(hw_new)
        new_ids = set(add) | set(fadd) | new_products
        on_add = [w for w in sorted(wb - wa) if any(w.startswith(i + ":") for i in new_ids)]
        if on_add:
            added_info.append(f"  {len(on_add)} new warning(s) on additions, e.g. {on_add[0]}")
        for w in sorted(wb - wa):
            if w not in on_add:
                lines.append(f"  new warning: {w}")
        lines += [f"  warning cleared: {w}" for w in sorted(wa - wb)]
        if rem:
            lines.append("  removed: " + ", ".join(rem))
        if frem:
            lines.append("  functions removed: " + ", ".join(frem))
        if fchg:
            lines.append("  functions changed: " + ", ".join(fchg))
        for k in chg:
            extra = ""
            if isinstance(pa[k], dict):
                extra = "; ".join(f"{f} {delta(pa[k][f], pb[k][f])}" for f in pa[k] if f != "hash" and pa[k][f] != pb[k].get(f))
            lines.append(f"  {k} changed" + (f" ({extra})" if extra else " (content or inherited taxonomy definitions)"))
        if lines:
            out += [title] + lines
        info += added_info
    return out, info, wealth, swaps, held


# ---------------------------------------------------------------------------------------------------------- main
def path_for(name):
    return os.path.join(BASELINE_DIR, f"{name}.json")


def headline(s):
    t = s["totals"]
    dp, dm, sm = (collections.defaultdict(lambda: "?", s[k]) for k in ("data_products", "data_models", "semantic_models"))
    return (f"{t['domains']} domains, {t['families']} families, {t['objects']} objects ({t['attribute_groups']} attribute "
            f"groups), {t['attributes']} attributes, {t['cdes']} CDEs, {t['references']} references, {t['derived']} derived, "
            f"{t['unresolved']} unresolved, {t['code_lists_local']} local + {t['code_lists_shared']} shared code list uses, "
            f"{t['relationships']} relationships | {len(s['registers']['shared_code_lists'])} shared code lists, "
            f"{len(s['registers']['decisions'])} decisions, {len(s['registers']['prefixes'])} prefixes, "
            f"{len(s['registers']['concept_ownership'])} concept owners, {len(s['registers']['term_conflicts'])} term conflicts | "
            f"{dp['specified']} data products, {dp['measures']} measures, {dp['dq_rules']} DQ rules, "
            f"{dp['attribute_links']} product-to-attribute links | {dm['models']} logical models, {dm['entities']} entities, "
            f"{dm['relationships']} relationships | {sm['models']} semantic models, {sm['metrics_defined']} metrics")


def full_build(s):
    """The domain count line for the full build: the compared set (the protected domains, in the totals) and every other
    content module (expansion additions such as 45-52 against an older snapshot), so the totals are not misread as the
    whole model."""
    t, ex = s["totals"], s.get("expansion_modules", {})
    k = lambda key: t.get(key, 0) + sum(e.get(key, 0) for e in ex.values())
    return (f"{t['domains'] + len(ex)} domains in the full build ({t['domains']} compared"
            + (f"; {len(ex)} not in the compared set: {', '.join(sorted(ex))}" if ex else "")
            + f"), {k('families')} families, {k('objects')} objects, {k('attributes')} attributes, {k('cdes')} CDEs, "
            f"{k('references')} references, {k('unresolved')} unresolved")


def main():
    ap = argparse.ArgumentParser(description="Baseline regression check for the protected Data Domains and the layers built on them.")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--snapshot", nargs="?", const=DEFAULT_NAME, metavar="NAME", help="write baseline/NAME.json")
    g.add_argument("--check", nargs="?", const=DEFAULT_NAME, metavar="NAME", help="compare to baseline/NAME.json (default)")
    ap.add_argument("--allow", default="", metavar="CD-nnn,...",
                    help="decisions the differences must trace to (annotation only; never suppresses a difference)")
    ap.add_argument("--replaced", default="", metavar="NN,...",
                    help="Data Domains to compare by counts only as replaced domains (CW-019), in addition to those "
                         "detected from domains.DISPOSITION")
    args = ap.parse_args()
    replaced = [x.strip().zfill(2) for x in args.replaced.split(",") if x.strip()]
    bad = [x for x in replaced if x not in tb.DD_NAMES]
    if bad:
        print(f"--replaced: unknown Data Domain(s) {', '.join(bad)}"); return 2
    t0 = time.time()
    if args.snapshot:     # a new snapshot protects every Data Domain merged so far (distribution-v0.4 keeps 01-16)
        protected = BASELINE_DOMAINS if args.snapshot == DEFAULT_NAME else sorted(content_modules())
    else:
        name = args.check or DEFAULT_NAME
        if not os.path.exists(path_for(name)):
            print(f"No baseline at baseline/{name}.json; run --snapshot {name} first."); return 2
        with open(path_for(name), encoding="utf-8") as f:
            old = json.load(f)
        protected = old.get("meta", {}).get("domains") or BASELINE_DOMAINS
    snap, report, ok = compute(protected)

    if args.snapshot:
        print("Validators:"); print("\n".join("  " + r for r in report))
        if not ok:
            print("\nNot snapshotting: the build does not validate."); return 1
        os.makedirs(BASELINE_DIR, exist_ok=True)
        import decisions as dec
        snap = {"meta": {"name": args.snapshot, "created": datetime.date.today().isoformat(), "git_head": git_head(),
                         "domains": protected, "model": getattr(dec, "MODEL", "wholesale"),
                         "retired": dict(RETIRED_DOMAINS)}, **snap}
        with open(path_for(args.snapshot), "w", encoding="utf-8") as f:
            json.dump(snap, f, indent=1, sort_keys=False, ensure_ascii=False)
            f.write("\n")
        print(f"\nWrote baseline/{args.snapshot}.json: {headline(snap)}")
        print(f"  {full_build(snap)}")
        print(f"({time.time() - t0:.1f}s)")
        return 0

    snap = json.loads(json.dumps(snap, default=_plain))         # same shape as the JSON on disk
    meta = old.get("meta", {})
    print(f"Baseline check against {name} (snapshot {meta.get('created', '?')}, commit {meta.get('git_head', '?')})")
    print("\nValidators:"); print("\n".join("  " + r for r in report))
    d, info, wealth, swaps, held = diff(old, snap, protected, replaced)
    if info:
        print("\nExpansion additions (not failures):")
        print("\n".join("  " + x for x in info))
    if wealth:
        print("\nWealth-model additions (not failures):")
        print("\n".join("  " + x for x in wealth))
    if swaps:
        print("\nReplaced and retired Data Domains, products and functions (not failures; CW-019, framework.RETIRED_*):")
        print("\n".join("  " + x for x in swaps))
    if held:
        print("\nPending WP0 re-scope (not failures; CW-041):")
        print("\n".join("  " + x for x in held))
    print("\nDifferences from the baseline:" if d else f"\nNo differences from the baseline in Data Domains {protected[0]}-"
          f"{protected[-1]}{' (replaced and retired domains by counts, as listed above)' if swaps else ''}, the "
          f"registers, the data products, the logical models or the semantic models.")
    if d:
        print("\n".join("  " + x for x in d))
        new_cds = sorted(set(snap["registers"]["decisions"]) - set(old["registers"]["decisions"]))
        allow = [x.strip() for x in args.allow.split(",") if x.strip()]
        print("\nEvery difference must trace to a logged decision (CD-nnn or CW-nnn).")
        if allow:
            unknown = [x for x in allow if x not in snap["registers"]["decisions"]]
            print("Differences must trace to: " + ", ".join(allow)
                  + (f"  (not in decisions.py: {', '.join(unknown)})" if unknown else ""))
        if new_cds:
            print("Decisions added since the baseline: " + ", ".join(new_cds))
    print(f"\nNow:      {headline(snap)}")
    print(f"          {full_build(snap)}")
    print(f"Baseline: {headline(old)}")
    print(f"          {full_build(old)}")
    result = ok and not d
    print(f"\n{'PASS' if result else 'FAIL'}: {'validators failed; ' if not ok else ''}"
          f"{len([x for x in d if not x.startswith('  ')])} section(s) differ ({time.time() - t0:.1f}s)")
    return 0 if result else 1


if __name__ == "__main__":
    sys.exit(main())
