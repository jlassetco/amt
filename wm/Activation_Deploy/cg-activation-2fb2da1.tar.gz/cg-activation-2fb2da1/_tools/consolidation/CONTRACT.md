# Consolidation data contract (v0.2)

The consolidation layer is **declarative**. Content modules (`_tools/content/content_NN_*.py`) remain the authored v0.1 drafts. The files in this folder say how they are harmonized. `taxonomy_builder.py` applies them at build time, and `build_enterprise.py` produces the consolidated enterprise workbook.

Business domains are referred to by their two-digit number as a string: "01" … "52" (07 and 30 retired in the wealth model).

## shared_code_lists.py

```python
SHARED = [
  {
    "name": "Frequency",                       # enterprise list name; attributes will show "Shared: Frequency"
    "steward": "09",                           # business domain that stewards the list (usually 09; regulatory lists may be 08, product lists 01)
    "definition": "Standard recurrence periods used across the enterprise.",
    "source": "Internal (aligned to ISO 20022 Frequency code set)",
    "values": [("DAILY", "Daily", "description"), ...],   # (code, label, description) - codes UPPER_SNAKE
    "members": [("01", "Frequency"), ("03", "Frequency"), ("05", "Frequency")],   # local lists this replaces
    "direct_users": ["19", "20"],              # optional: domains that cite "Shared: Frequency" directly, with no local list
                                               # (17+ are drafted after the harmonization pass); the builder adds the list
                                               # to their workbooks, and a domain that is not registered here gets none
    "value_map": {                              # EVERY value of EVERY member list -> shared code, or None (= dropped / needs SME review)
       ("01", "Frequency", "Daily"): "DAILY",
       ...
    },
  },
]

LOCAL_RENAMES = [   # same list name, different meaning in different domains: rename to disambiguate, do not merge
  ("01", "Party Role Type", "Product Party Role Type", "01 lists roles of service providers to a fund; 02 lists roles a party plays with the firm"),
]

NOT_MERGED = [      # similar lists deliberately kept separate (for the record)
  ("02", "Registration Status", "08", "Registration Status", "Different concepts: product registration for sale vs individual license registration"),
]
```

### Validation of the shared lists (W5, 2026-10-16)

`taxonomy_builder.py` checks `shared_code_lists.py` against the authored content modules before it builds (`validate_shared`; every run, scoped to the named modules' lists on a single-module run; not with `--raw`):

- **Errors** (the run stops): a `"Shared: <name>"` citation of a list that does not exist; a citing domain that is neither a member (with the local list in its module) nor in the list's `direct_users` (the builder gives it no entry, which `validate()` would report as an undefined list); a duplicate shared list name.
- **Warnings** (printed, `--strict-shared` makes them errors): a `value_map` entry that maps to a code the list does not hold; a `value_map` key that is not a registered member, or not a value of the member's local list; a member value with no `value_map` entry (the rule above: EVERY value of EVERY member list); a member in a retired or missing Data Domain, or without its local list; a direct user that does not cite the list; a list below two values; duplicate codes or labels; a steward that is not a live Data Domain; a `LOCAL_RENAMES` row that names a list the module no longer holds.

The summary line is `shared lists: <n> checked; <e> error(s), <w> warning(s)`. The warnings become errors once the W5 consolidation has cleared them.

## decisions.py

```python
DECISIONS = [
  {"id": "CD-001", "theme": "Identifiers", "title": "Individual CRD number held in 02 and 08",
   "domains": ["02", "08"], "issue": "...", "resolution": "...", "rationale": "...",
   "action": "Retain - clarify",      # one of: Reference | Move | Merge | Rename | Retire | Retain - clarify | SME decision
   "status": "Proposed",              # "Applied in v0.2" | "Proposed" | "SME decision required"
   "priority": "High",                # High | Medium | Low
   "owner_role": "Head of Distribution Data"},
]

CONCEPT_OWNERSHIP = [   # every core entity / master concept that other domains reference
  ("Party", "02", "PTY-", ["01", "03", ...], "Single external party master (organizations and individuals)"),
]

PREFIXES = [            # every ID prefix used in any content module, after consolidation
  ("PTY-", "External party", "02", "Registered", ""),   # status: Registered | Proposed | Renamed | Retired ; last field = note (e.g. "renamed from SMA-")
]

PREFIX_FORMATS = [      # key format published by the owning domain (Stage 2 onward; 01-21 prefixes added at Step 5, CD-288); sibling examples follow it
  ("PRICE-", "22", "PRICE-<price date YYYYMMDD>-<instrument number, 8 digits>-<pricing point, 2 digits>-<version, 2 digits>", "PRICE-20261005-00104477-01-01"),
]

TERM_CONFLICTS = [      # same business term defined differently across domains (e.g. "Revenue", "AUM", "Net Flow", "Channel")
  {"term": "Revenue", "usages": [("06", "Estimated Management Fee Revenue", "..."), ("10", "...", "...")],
   "recommendation": "Define enterprise term ... ; qualify local terms as ...",
   "resolution": "Primary sense: 10 booked fee revenue. Other uses are qualified as ...",   # Step 5 (CD-287): which domain's
                                              # meaning is the glossary's primary sense, and how the others are qualified
   "status": "Resolved",                      # "Resolved" (follows from applied decisions or is a naming rule) | "SME" (client choice needed)
   "decision": "CW-007"},                     # optional (wealth model): the CW- decision behind an entry added on that branch
]
```

`decisions.py` also holds `MODEL = "wealth"` on branch `feature/wealth-manager`. Decision ids are `CD-nnn` (inherited from the wholesale model, never renumbered or edited) or `CW-nnn` (the wealth model's own, CW-002); both use the format above. CW- statuses are "Ruled (W0)", "Applied (W<n>)" and "SME decision required".

## Changes applied directly to content modules in v0.2 (by the program lead, not by agents)

- **Prefix renames:**
  - 04 `SMA-` → `SOC-` (social account)
  - 06 `RST-` → `RSM-` (restatement)
  - 13 `SLA-` → `SVL-` (12 keeps `SLA-`)
  - 13 `HHD-` → `MHG-` (mailing householding group)
  - 07 `STM-` → `CPS-` (compensation statement)
- **Domain move:** 06 TX-MKT "Industry Flow Benchmarks" is removed from 06. 11 already covers it (`MI-FLW` / `MI-MSH`). If 06 has a separate Market Share measure, it is removed too, and the 06 `IND-` prefix is retired.

## Stage 1 consolidation (2026-10-06)

The proposals of Data Domains 17-21 (`proposals_expansion.py`, `proposals_17.py` … `proposals_21.py`) were merged into `decisions.py` and `shared_code_lists.py` (CD-143 to CD-166). The moves CD-151 (employees 09 -> 20), CD-152 (GL postings and period status 10 -> 19) and CD-156 (DQ rules 06 -> 21) were applied to the content modules. What was applied, deferred and reconciled is in `stage1_consolidation_notes.md`. The proposals files are kept as the record of what each domain asked for.

## Stage 2 consolidation (2026-10-06)

The proposals of Data Domains 22-30 (`proposals_stage2_a.py`, `proposals_stage2_b.py`, `proposals_22.py` … `proposals_30.py`) were merged into `decisions.py` and `shared_code_lists.py` (CD-167 to CD-210):
- Eight reserved prefixes were renamed: CREC- to CUREC-, CAEL- to ELECT-, DVD- to FDIV-, FCL- to CLOSE-, SCA- to SCAC-, TAO- to FNDO-, TAS- to FBAT-, TAC- to TACK-.
- Key formats are recorded in `PREFIX_FORMATS`.
- CD-155 option A (SSIs 12 to 26), CD-194 option A (safekeeping accounts in 28) and the hand-offs into 06, 10, 12, 13, 15, 17, 18 and 19 were applied.
- A shared Business Line list was created, with 01's list renamed Client Segment (CD-209).

What was applied, deferred and reconciled is in `stage2_consolidation_notes.md`. The proposals files keep the reserved names as the record of what each domain asked for, apart from proposals_22 … proposals_30, which use the registered names.

## Stage 3 consolidation (2026-10-06)

The proposals of Data Domains 31-36 (`proposals_stage3_a.py`, `proposals_stage3_b.py`, `proposals_31.py` … `proposals_36.py`) were merged into `decisions.py` and `shared_code_lists.py` (CD-211 to CD-242):
- The 25 reserved prefixes were registered without renames. Key formats are in `PREFIX_FORMATS`.
- The program lead's rulings were applied to 01-30:
  - CD-212: 01 SRI and SRRI
  - CD-218: 01 Composite Member
  - CD-222: 12 Breach Notification
  - CD-180 / CD-221: 25 Compliance Check Outcome
  - CD-226: 17 meeting event types and Meeting Date
  - CD-232: 10 Underlying Agreement; CD-022 is superseded
  - CD-237: board approvals linked only from 35, amending CD-225
- Six shared lists were created (CD-242). 31-36 cite shared lists directly as registered users (CD-241).

What was applied, deferred and reconciled is in `stage3_consolidation_notes.md`. The proposals files keep the names the drafts used as the record of what each domain asked for.

## Stage 4 consolidation (2026-10-07)

The proposals of Data Domains 37-44 (`proposals_stage4_a.py`, `proposals_stage4_b.py`, `proposals_37.py` … `proposals_44.py`) were merged into `decisions.py` and `shared_code_lists.py` (CD-243 to CD-285):
- 56 prefixes were registered; COVG- was withdrawn for MCOV-; AUTH- and OBL- moved to 38 and BRD- to 42; DAPP- is retired. Key formats are in `PREFIX_FORMATS`, and two new informational registers, `FIRM_KEY_FORMATS` and `GRAIN_KEY_FORMATS`, publish the keys written without a hyphenated stem and the composite keys of 37-44.
- The program lead's rulings were applied to 01-36: the moves CD-250 (09 Entity Authorization and Cross-Border Passport to 38), CD-252 (08 Regulatory Obligation and Attestation to 38) and CD-271 (04 Brand to 42), and the re-typings and derived copies under CD-246, CD-255 to CD-258, CD-260, CD-261, CD-263, CD-264, CD-267, CD-274, CD-276 and CD-277; CD-257 and CD-248 were amended.
- Four shared lists were created (CD-284); 37-44 cite shared lists directly as registered users (CD-283); future-owner texts in 01-36 were resolved (CD-285).

What was applied, deferred and reconciled is in `stage4_consolidation_notes.md`. This was the last drafting-stage merge.

## Step 5 consolidation (2026-10-07)

The cross-domain pass over all 44 Data Domains (plan §6 step 5) added CD-286 to CD-290 and applied CD-150:
- CD-286: 41 shared code lists from the deferred Stage 1-4 candidates. Members keep their local list in the content module; label-identical copies in 17-44 and "External (NN list)" citations were re-pointed to "Shared: <name>" and the local copies removed.
- CD-287: every TERM_CONFLICTS entry has `resolution` and `status` (above). build_enterprise.py shows both on the Term Conflicts sheet.
- CD-288: PREFIX_FORMATS covers every Registered or Proposed prefix that has an example; lossless example alignments.
- CD-289: optional enrichment `ROW_OWNERSHIP` (see `enrichment/CONTRACT.md`).
- CD-150: the enterprise workbook is `00_Program/Enterprise_Data_Taxonomy.xlsx`, with the distribution view as a filter on its Data Domains sheet.
- CONCEPT_OWNERSHIP rows whose note starts with "Retired" are kept for traceability and skipped by the ownership resolver (the 01 Fund Advisory / Management Agreement row, superseded by CD-232).

What was applied, rejected and reconciled is in `step5_consolidation_notes.md`.

## jurisdiction.py (wealth model, W0, 2026-10-14)

The Jurisdiction register of CW-003: every EU/UK object, attribute, code-list value and source that the US-only pass removes from a carried-over or adapted Data Domain (Wealth_Manager_Rework_Plan.md §6). It lets a UK extension be restored from the wholesale sibling (tag `wholesale-v1.0`) object by object. Declarative; the builder does not read it.

```python
REGIMES = ["UCITS", "AIFMD", "MiFID II", ..., "Other EU/UK"]   # the regimes a removal may name

REMOVALS = [
  {"domain": "28",                                   # Data Domain number as a string
   "object": "CASS Client Money Reconciliation",      # object name in the wholesale module; "Code list: <name>" or "Sources" for values and sources
   "attribute": "",                                  # attribute name, code value or source title; "" when the whole object was removed
   "regime": "CASS",                                 # one of REGIMES
   "decision": "CW-0nn",                             # the CW- decision of that domain's US-only pass
   "note": "Client money is not held at fund level in the US model; 49 masters the Rule 15c3-3 reserve."},
]

CHECKLIST = [           # the drafters' remove / keep table (plan §6): (what, remove, keep)
  ("Objects", "Objects that exist only for an EU/UK regime: ...", "Objects that are generic with a US instance, re-sourced to the US rule."),
]
```

Rules: one CW- decision per domain lists that domain's removals in its resolution; every removal has a REMOVALS entry; a generic object with a US instance is kept and re-sourced, never removed. REMOVALS is empty at W0; the W1, W1b and W2 to W4 drafters append to it.

