"""Objects excluded from every taxonomy output (workbooks, enterprise view, explorer, review page).

Excluded at build time only: the content modules keep them, so restoring is a one-line change (remove the entry).
Families left with no objects are dropped too; code lists used only by excluded attributes disappear from the domain workbooks.
"""

EXCLUDED_OBJECTS = {
    "Record Metadata": "Record-level governance metadata (data owner, data steward, system of record, effective dating, "
                       "data quality status). Documented separately by the program; excluded from the taxonomy views on 2026-10-01 "
                       "to avoid confusion. Restore by deleting this entry.",
}
