"""The Jurisdiction register of the wealth-manager reference model (CW-003; Wealth_Manager_Rework_Plan.md section 6).

The wealth model is US only. Every carried-over and adapted Data Domain gets one CW- decision listing what its US-only
pass removed, and each removal is recorded here, object by object or attribute by attribute, so that a UK extension
(plan section 13) can be restored from the wholesale sibling (tag wholesale-v1.0) without a rebuild.

Declarative only: nothing here edits a content module, and the builder does not read this file. The drafters of the
US-only pass (W1, W1b, W2 to W4) never edit this file while a stage runs: each writes JURISDICTION = [...] in its
proposals_NN.py in the REMOVALS entry format, under the domain's pre-allocated decision CW-9NN (CW-022), and the
program lead appends the entries to REMOVALS and merges the decision when the stage is merged. Format: CONTRACT.md in this folder, section "jurisdiction.py".

REMOVALS entry keys:
  domain     Data Domain number as a string, e.g. "28"
  object     the object name in the wholesale module (wholesale-v1.0), e.g. "CASS Client Money Reconciliation"
  attribute  the attribute name, or "" when the whole object was removed
  regime     the EU/UK regime the content existed for, one of REGIMES below
  decision   the CW- decision of the domain's US-only pass, e.g. "CW-031"
  note       what replaced it in the US model, if anything ("re-sourced to SEC Rule 15c3-3"), or why nothing did

Code-list values and sources removed are recorded the same way, with object set to "Code list: <list name>" or
"Sources" and attribute set to the value or the source title.
"""

# The regimes a removal can name. Extend only with a regime the US-only checklist covers.
REGIMES = ["UCITS", "AIFMD", "MiFID II", "MiFIR", "PRIIPs", "SFDR", "EU Taxonomy", "CASS", "CSDR", "EMIR", "SFTR", "DORA",
           "ICARA", "SM&CR", "Consumer Duty", "FCA", "FinDatEx", "GDPR / UK GDPR", "BMR", "CRS", "UK Stewardship Code",
           "EU market practice", "UK market practice", "Other EU/UK",
           "Other non-US",   # Canada, Switzerland and other non-US regulation or distribution content (CW-022 scope)
           "Other US scope"]   # W5 (CW-177): US content removed for scope, not for an EU/UK regime (CW-165 insurance-dedicated residues)

REMOVALS = [
    # W1 (2026-10-14): the entries of the W1 domains are kept in their proposals files as the record and merged here at
    # the bottom of this file (CW-901 for 01, CW-902 for 02, CW-909 for 09, CW-915 for 15, CW-917 for 17; CW-022).
    # {"domain": "28", "object": "CASS Client Money Reconciliation", "attribute": "", "regime": "CASS",
    #  "decision": "CW-0nn", "note": "Client money is not held at fund level in the US model; 49 masters the Rule 15c3-3 reserve."},
]

# The drafters' checklist (plan section 6): what the US-only pass removes and what it keeps. Each row is
# (what, remove, keep). Work from this list, not from a global search.
CHECKLIST = [
    ("Objects",
     "Objects that exist only for an EU/UK regime: UCITS and AIFMD filings, KID and PRIIPs documents, SFDR classifications "
     "and principal adverse impacts, CASS records, CSDR penalties, EMIR reporting, DORA registers, ICARA, SM&CR "
     "responsibilities, Consumer Duty assessments, MiFID target market and costs, FinDatEx EMT and EPT, EU order routing "
     "and settlement platforms.",
     "Objects that are generic with a US instance (filings, disclosures, cost figures, order routing), re-sourced to the "
     "US rule."),
    ("Attributes",
     "Attributes that hold only an EU/UK regime value or identifier (for example an FCA Firm Reference Number, an SFDR "
     "article classification, a UCITS eligibility flag).",
     "Attributes of a generic object that hold the US instance; a jurisdiction attribute stays if the US value set needs it."),
    ("Code-list values",
     "Values naming EU/UK regulators, entity types, wrappers, platforms and messages.",
     "The value list re-cut to the US set, with 'Other' where the standard has it."),
    ("Sources",
     "Sources that are EU/UK regulation or market practice.",
     "US rules and the ISO and vendor standards that are market-neutral."),
    ("Perspective text",
     "'US + EU/UK' and 'wholesale distributor' in META, overviews and Source_Notes.",
     "Rewritten to 'Wealth manager (direct) | Scope: US'."),
    ("Records",
     "Nothing is removed without a REMOVALS entry naming its domain, object, attribute, regime and decision.",
     "One CW- decision per domain lists the removals in its resolution; the jurisdiction register holds the detail."),
]


# ---------------------------------------------------------------------------------------------------------------------
# W1 merge (2026-10-14): 280 removals recorded by the W1 drafters and editors (program lead merge; CW-022).
# ---------------------------------------------------------------------------------------------------------------------
import proposals_w1_01 as _w101, proposals_w1_02 as _w102, proposals_w1_09 as _w109, proposals_w1_15 as _w115, proposals_w1_17 as _w117
REMOVALS += _w101.JURISDICTION + _w102.JURISDICTION + _w109.JURISDICTION + _w115.JURISDICTION + _w117.JURISDICTION


# ---------------------------------------------------------------------------------------------------------------------
# W1b merge (2026-10-14): 682 removals recorded by the W1b editors for the 22 kept domains (program lead merge; CW-022).
# ---------------------------------------------------------------------------------------------------------------------
import proposals_w1b_14 as _b14, proposals_w1b_18 as _b18, proposals_w1b_19 as _b19, proposals_w1b_20 as _b20, proposals_w1b_21 as _b21, proposals_w1b_22 as _b22, proposals_w1b_23 as _b23, proposals_w1b_25 as _b25, proposals_w1b_26 as _b26, proposals_w1b_27 as _b27, proposals_w1b_28 as _b28, proposals_w1b_31 as _b31, proposals_w1b_33 as _b33, proposals_w1b_34 as _b34, proposals_w1b_35 as _b35, proposals_w1b_37 as _b37, proposals_w1b_39 as _b39, proposals_w1b_40 as _b40, proposals_w1b_41 as _b41, proposals_w1b_42 as _b42, proposals_w1b_43 as _b43, proposals_w1b_44 as _b44
REMOVALS += _b14.JURISDICTION + _b18.JURISDICTION + _b19.JURISDICTION + _b20.JURISDICTION + _b21.JURISDICTION + _b22.JURISDICTION + _b23.JURISDICTION + _b25.JURISDICTION + _b26.JURISDICTION + _b27.JURISDICTION + _b28.JURISDICTION + _b31.JURISDICTION + _b33.JURISDICTION + _b34.JURISDICTION + _b35.JURISDICTION + _b37.JURISDICTION + _b39.JURISDICTION + _b40.JURISDICTION + _b41.JURISDICTION + _b42.JURISDICTION + _b43.JURISDICTION + _b44.JURISDICTION


# ---------------------------------------------------------------------------------------------------------------------
# W2-W4 merge (2026-10-15, program lead; CW-022): the removals of the replaced and adapted domains, from the domain
# proposals files (the brief-level files carry none; proposals_w3_brokerage.JURISDICTION is empty), plus the eight 12
# items the 47 drafter recorded (proposals_w2_47.CW912_ITEMS, CW-912). Rulings: 03's entries for 07 objects are filed
# under CW-907 (merge-prep ruling 6); an entry repeated across files, or within one, is kept once, the first occurrence
# winning (the 12 file's own entries before the 47 copies).
# ---------------------------------------------------------------------------------------------------------------------
import proposals_w2_03 as _x03, proposals_w2_04 as _x04, proposals_w2_08 as _x08, proposals_w2_13 as _x13
import proposals_w2_45 as _x45, proposals_w2_46 as _x46, proposals_w2_47 as _x47, proposals_w2_51 as _x51
import proposals_w3_16 as _x16, proposals_w3_24 as _x24, proposals_w3_29 as _x29, proposals_w3_32 as _x32
import proposals_w3_48 as _x48, proposals_w3_49 as _x49, proposals_w3_50 as _x50, proposals_w3_52 as _x52
import proposals_w4_05 as _x05, proposals_w4_06 as _x06, proposals_w4_10 as _x10, proposals_w4_11 as _x11
import proposals_w4_12 as _x12, proposals_w4_36 as _x36, proposals_w4_38 as _x38
_W24_FILES = [_x03, _x04, _x05, _x06, _x08, _x10, _x11, _x12, _x13, _x16, _x24, _x29, _x32, _x36, _x38,
              _x45, _x46, _x47, _x48, _x49, _x50, _x51, _x52]
_W24_REFILE = {("proposals_w2_03", "07"): "CW-907"}     # merge-prep ruling 6
_seen = {(r["domain"], r["object"], r["attribute"]) for r in REMOVALS}
W24_DUPLICATES_DROPPED = []
for _m, _rows in [(m, getattr(m, "JURISDICTION", [])) for m in _W24_FILES] + [(_x47, _x47.CW912_ITEMS)]:
    for _r in _rows:
        _r = dict(_r)
        _r["decision"] = _W24_REFILE.get((_m.__name__, _r["domain"]), _r["decision"])
        _k = (_r["domain"], _r["object"], _r["attribute"])
        if _k in _seen:
            W24_DUPLICATES_DROPPED.append((_m.__name__,) + _k)
            continue
        _seen.add(_k)
        REMOVALS.append(_r)

# ---------------------------------------------------------------------------------------------------------------------
# W5 consolidation (2026-10-16, program lead; CW-177): the entries recorded without a note get one line derived from their
# decision (proposals_w5_registers.jurisdiction_note); the two Third-Party Risk Domain label entries are added (CW-175).
# W24_DUPLICATES_DROPPED above stays as the record of the duplicates dropped at the W2-W4 merge.
# ---------------------------------------------------------------------------------------------------------------------
import proposals_w5_registers as _w5r
REMOVALS += [dict(_r) for _r in _w5r.JURISDICTION if (_r["domain"], _r["object"], _r["attribute"]) not in _seen]
import proposals_w5_content as _w5c                      # agent B's content sweep: the CW-165 removals (insurance-dedicated scope)
REMOVALS += [dict(_r) for _r in _w5c.JURISDICTION_CW165 if (_r["domain"], _r["object"], _r["attribute"]) not in _seen]
W5_NOTES_FILLED = 0
for _r in REMOVALS:
    if not _r["note"].strip():
        _r["note"] = _w5r.jurisdiction_note(_r)
        W5_NOTES_FILLED += 1

# Schema check (CONTRACT.md 'jurisdiction.py'): the six keys, a listed regime and a CW- decision on every entry.
_KEYS = {"domain", "object", "attribute", "regime", "decision", "note"}
_bad = [r for r in REMOVALS if set(r) != _KEYS or r["regime"] not in REGIMES or not str(r["decision"]).startswith("CW-")]
assert not _bad, f"jurisdiction.REMOVALS schema: {len(_bad)} bad entries, e.g. {_bad[:2]}"
