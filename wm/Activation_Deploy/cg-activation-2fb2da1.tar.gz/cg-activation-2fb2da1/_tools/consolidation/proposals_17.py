"""Consolidation proposals from the Data Domain 17 (Instrument & Issuer Reference) draft, 2026-10-06.

Proposal fragment only: the builder does not read this file. The Stage 1 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Formats follow CONTRACT.md in this folder.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES  (prefix, entity, owner domain, status, note) - decisions.PREFIXES format
# No prefixes beyond the five reserved in proposals_expansion.py (INS-, IID-, ISR-, LST-, CAE-) are used. Issuers are keyed
# by 02 PTY-; coupon periods, redemption events, classification assignments, issuer relationships, credit ratings and
# corporate action options keep composite keys.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED LISTS: 17 local lists that mirror an existing enterprise shared list (add ("17", <list>) to "members"),
#    with the value_map to apply and any values the shared list must gain.
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIP = [
    {"shared": "Frequency", "local": "Frequency",
     "value_map": {"Daily": "DAILY", "Weekly": "WEEKLY", "Monthly": "MONTHLY", "Quarterly": "QUARTERLY",
                   "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL", "On Event": "ON_EVENT", "Ad Hoc": "AD_HOC"},
     "new_values": []},
    {"shared": "Record Status", "local": "Record Status",
     "value_map": {"Draft": "DRAFT", "Active": "ACTIVE", "Inactive": "INACTIVE", "Retired": "RETIRED"},
     "new_values": []},
    {"shared": "Case Status", "local": "Case Status",
     "value_map": {"New / Received": "NEW", "In Progress": "IN_PROGRESS", "Pending Third Party": "PENDING_THIRD_PARTY",
                   "Escalated": "ESCALATED", "Resolved / Completed": "RESOLVED", "Rejected": "REJECTED", "Canceled": "CANCELED"},
     "new_values": []},
    {"shared": "Approval Status", "local": "Approval Status",
     "value_map": {"Not Required": "NOT_REQUIRED", "Pending": "PENDING", "Approved": "APPROVED", "Rejected": "REJECTED",
                   "Withdrawn": "WITHDRAWN"},
     "new_values": []},
    {"shared": "Message Standard", "local": "Message Standard",
     "value_map": {"ISO 15022": "ISO_15022", "ISO 20022": "ISO_20022", "Proprietary": "PROPRIETARY"},
     "new_values": [],
     "note": "Shared definition says 'used for a partner data feed or transaction and position feed'; widen it to any "
             "inbound or outbound message, including corporate action notifications (MT564, seev.031) and security reference (reda)."},
    {"shared": "Data Provider", "local": "Data Provider",
     "value_map": {"Morningstar": "MORNINGSTAR", "Other": "OTHER"},
     "new_values": [
         ("BLOOMBERG", "Bloomberg", "Market, reference, corporate action and classification (BICS) data; FIGI registration authority."),
         ("ICE_DATA_SERVICES", "ICE Data Services", "Fixed income reference data and evaluated pricing."),
         ("LSEG_DATA_ANALYTICS", "LSEG Data & Analytics", "Reference and market data (RIC, SEDOL); distinct from LSEG Lipper fund data."),
         ("SP_GLOBAL_MI", "S&P Global Market Intelligence", "Company, issuer and reference data (Capital IQ)."),
         ("MOODYS", "Moody's", "Credit ratings and research data (Moody's Ratings, Moody's Analytics)."),
         ("FITCH", "Fitch Ratings", "Credit ratings data."),
         ("MSCI", "MSCI", "Index, GICS classification and ESG data."),
         ("FTSE_RUSSELL", "FTSE Russell", "Index and ICB classification data."),
         ("DTCC", "DTCC", "Corporate action announcements (Global Corporate Actions) and settlement reference."),
         ("ANNA_DSB", "ANNA DSB", "OTC ISIN, UPI and CFI for OTC derivatives."),
         ("CUSIP_GLOBAL_SERVICES", "CUSIP Global Services", "CUSIP and CINS identifiers and issuer numbers."),
     ],
     "note": "Brief asked to check coverage of Bloomberg, ICE, LSEG, S&P, Moody's, Fitch and DTCC: none are in the shared list. "
             "The 17 local list carries them as proposed additions. 'Other' also covers values assigned internally by the firm. "
             "'S&P Global Ratings' as a rating agency is a separate 17 list (Credit Rating Agency) because agencies rate "
             "issuers, they are not data vendors; each provider and agency should also resolve to a 02 PTY- party."},
]

# 17 lists that copy a 01 Investment Product local list by name and value (subset), used on Fund Instrument Terms, where
# the attribute is a Derived copy (01) for own share classes. Proposal: make each a shared list stewarded by 01, with 17
# as a member, or let 17 reference the 01 list directly at consolidation.
MIRRORS_OF_01 = [
    ("Vehicle Type", "01 Vehicle Type, 8 of 12 values (the separate-account and model values do not apply to held funds)."),
    ("Regulatory Regime", "01 Regulatory Regime, 8 of 15 values."),
    ("Distribution Policy", "01 Distribution Policy, all values."),
    ("MMF Type", "01 MMF Type, all values."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: 17 local lists that look like enterprise lists
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Identifier Status", ["02", "15", "17"],
     "Same four values (Active, Inactive, Retired, Unverified) in 02 party identifiers, 15 account identifiers and 17 "
     "instrument identifiers. Propose one shared 'Identifier Status' list stewarded by 09 (NOT_MERGED already keeps it apart "
     "from Reference Record Status because of 'Unverified')."),
    ("Instrument Asset Class", ["01", "12", "17"],
     "01 'Asset Class' (product / strategy, EFAMA EFC), 12 'SSI Asset Class' and 17 'Instrument Asset Class' (instrument level 1). "
     "Propose an enterprise asset-class hierarchy (level 1 shared, product and instrument levels below) stewarded by 17 or 09; "
     "until then keep the 17 list name distinct so it is not merged with 01 by name."),
    ("Instrument Type", ["17", "18", "25", "26", "31", "33"],
     "Every investment domain will classify instruments; 17 should steward the list (aligned to ISO 10962 CFI) and the "
     "Stage 1/2 domains reference it rather than define their own."),
    ("Instrument Identifier Scheme", ["01", "11", "14", "17"],
     "01 Security Identifier and External Cross-Reference hold ISIN, CUSIP, SEDOL, FIGI, Valoren, WKN, Bloomberg ticker as "
     "columns; 11 Peer Fund holds ISIN and ticker; 14 'Identifier Scheme' lists ISIN, CUSIP, SEDOL, FIGI and Ticker beside "
     "party schemes. One shared instrument scheme list (stewarded by 17) would let 01, 11 and 14 tag identifiers consistently."),
    ("Vehicle Type / Regulatory Regime / Distribution Policy / MMF Type", ["01", "17"],
     "See MIRRORS_OF_01: same names and values as 01; share them with 01 as steward."),
    ("Day Count Convention / Business Day Convention", ["17", "26", "22"],
     "ISDA conventions will be needed by 26 trade economics and 22 curves; steward in 17 (or 09) as shared lists."),
    ("Credit Rating Agency", ["17", "33"],
     "Credit rating agencies (17). Not the same as 11 Rating Observation providers (Morningstar, Lipper). Share only if 33 "
     "Investment Compliance needs the same agency list for rating-based limits."),
    ("Corporate Action Event Type / Corporate Action Option Type / Corporate Action Mandatory Voluntary / Corporate Action Announcement Status", ["17", "28"],
     "ISO 15022 / 20022 CAEV, CAOP, CAMV and announcement status lists will be used by 28 entitlements and elections; 17 stewards them."),
    ("Settlement Method / Option Style", ["17", "26"],
     "Will recur in 26 trade economics for OTC trades."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (decisions.TERM_CONFLICTS format). The first entry adds 17 to the existing "Rating" conflict.
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Rating",
     "usages": [("17", "Credit Rating Assignment (Credit Rating Value, Credit Rating Agency)",
                 "Credit rating of an instrument or issuer by a credit rating agency (S&P, Moody's, Fitch), used by compliance and risk.")],
     "recommendation": "Add to the existing 'Rating' conflict: 'Credit Rating' means an agency credit rating of an instrument or "
                       "issuer (17); 'Published Fund Rating' (11 RTG-) stays the peer-relative fund rating. Never use 'Rating' "
                       "alone in 17; NAIC designations are a regulatory classification, not a credit rating."},
    {"term": "Listing",
     "usages": [("01", "Listing (attribute group of Share Class)", "Exchange listing of an own ETF or closed-end share class."),
                ("17", "Instrument Listing (LST-)", "Listing of a third-party instrument on a venue (instrument x MIC).")],
     "recommendation": "Keep both: 01 masters own share-class listings, 17 masters third-party listings. Glossary: 'Share Class "
                       "Listing' (01) vs 'Instrument Listing' (17). 17 copies the own ETF primary MIC as a Derived copy only."},
    {"term": "Asset Class",
     "usages": [("01", "Asset Class / Product Asset Class", "Product and strategy asset class (EFAMA EFC aligned)."),
                ("12", "SSI Asset Class", "Asset class an SSI covers."),
                ("17", "Asset Class (list 'Instrument Asset Class')", "Level 1 of the firm asset-class taxonomy of an instrument.")],
     "recommendation": "Define one enterprise asset-class hierarchy; qualify local terms as 'Product Asset Class' (01) and "
                       "'Instrument Asset Class' (17). See SHARED_CANDIDATES."},
    {"term": "Issuer",
     "usages": [("03", "Issuer Feedback (RFP)", "The organization issuing an RFP."),
                ("08", "Issuer-Commissioned Written Material (MNMB Category)", "Issuer of research material under MiFID inducement rules."),
                ("13", "Issuer Communications Only (NOBO Permitted Use)", "Issuer of shares communicating with beneficial owners."),
                ("17", "Issuer (Instrument), Issuer Profile", "Party that issued a security held or traded by the firm.")],
     "recommendation": "'Issuer' unqualified means a securities issuer (17 Issuer Profile on a 02 party). Rename 03 to 'RFP Issuer'."},
    {"term": "Fund Domicile / Domicile",
     "usages": [("01", "Fund Domicile (Fund Legal Structure)", "Domicile of own funds."),
                ("17", "Fund Domicile (Fund Instrument Terms)", "Domicile of held third-party funds and underlying private funds; Derived copy (01) for own share classes.")],
     "recommendation": "Same meaning and name: 01 masters it for own funds, 17 for third-party funds; on Own Fund Share "
                       "Class instruments the 17 value is a Derived copy of 01 (declared in enrich_17.py)."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. PARTY ROLE TYPE values proposed for 02 (CD-143). 17 does not edit 02.
# ---------------------------------------------------------------------------------------------------------------------
PARTY_ROLE_TYPE_ADDITIONS = [
    # Roles of parties that 17 attributes reference by PTY-
    ("02", "Party Role Type", "Issuer", "Issuer of a security held, traded or referenced by the firm (Instrument.Issuer); profile in 17 Issuer Profile."),
    ("02", "Party Role Type", "Guarantor", "Guarantor of an issuer or a specific instrument (Issuer Relationship, Debt Guarantor)."),
    ("02", "Party Role Type", "Portfolio Company", "Private company held by a private markets portfolio (CD-143); an Issuer with an issuer profile in 17."),
    ("02", "Party Role Type", "Depositary Bank", "Depositary receipt issuing bank (Equity Terms.Depositary Bank)."),
    ("02", "Party Role Type", "Loan Administrative Agent", "Agent bank of a loan (Private Asset Terms.Administrative Agent)."),
    ("02", "Party Role Type", "Collateral Manager / Servicer", "CLO manager or loan servicer of a securitization (Securitized Product Terms)."),
    ("02", "Party Role Type", "Third-Party Fund Manager / General Partner", "Manager or GP of a held third-party fund or underlying private fund (Fund Instrument Terms); 30 will also use it."),
    ("02", "Party Role Type", "Clearing House / CCP", "Central counterparty (Listed Derivative Contract Terms.Clearing House); 26 will also use it."),
    ("02", "Party Role Type", "Offeror", "Party making a tender, exchange or takeover offer (Corporate Action Event.Offeror)."),
    ("02", "Party Role Type", "Numbering Agency", "National numbering agency, registration authority or identifier vendor (Instrument Identifier.Issuing Agency)."),
    # Roles the brief (CD-143) asks for, referenced through codes rather than PTY- attributes in 17
    ("02", "Party Role Type", "Rating Agency", "Credit rating agency. 17 holds the agency as a Credit Rating Agency code; each code value maps to the agency's PTY- party (kept because the brief requires agencies as 02 parties)."),
    ("02", "Party Role Type", "Exchange Operator", "Operator of a trading venue. 17 holds venues as ISO 10383 MICs; each operating MIC maps to the operator's PTY- party (kept because the brief requires it)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Register INS-, IID-, ISR-, LST-, CAE- in decisions.PREFIXES (owner 17). Self-references in 17 already use "
    "'Reference (X, 17)', the same form as sibling 18.",
    "Add CONCEPT_OWNERSHIP rows: Instrument (17, INS-), Instrument Identifier (17, IID-), Instrument Listing (17, LST-), "
    "Issuer Profile (17, keyed by PTY-), Credit Rating Assignment (17), Corporate Action Event (17, CAE-), referenced by 18, 22, "
    "25, 26, 27, 28, 31, 33.",
    "Employee references (Requested By, Approved By, Relationship Approved By, Scrubbed By) are forced to 20 in enrich_17.py "
    "because EMP- still resolves to 09 until CD-151 is applied.",
    "09 Classification Scheme (ICS-): 17 now references the scheme version only (no separate scheme code). Widen ICS- from "
    "'Industry Classification Scheme' (schemes used to classify organizations) to investment classification schemes, and add "
    "ICB, BICS, Firm Asset Class, Firm Industry Sector and Firm Credit Sector to the 09 'Industry Classification Scheme' list "
    "(or rename it 'Classification Scheme'). Without this, Firm Asset Class has no ICS- record.",
    "02 Party Identifier: 17 keeps the CUSIP Issuer Number and Bloomberg Company ID on Issuer Profile as security-master issuer "
    "identifiers. Confirm with 02; the alternative is two new 02 Party Identifier schemes and no identifier columns in 17.",
    "18 (sibling): Fund Interest Holding Detail 'Underlying Fund Manager' repeats 17 Fund Instrument Terms 'Fund Manager or General "
    "Partner'. Ask 18 to drop it and read the 17 value through the instrument.",
    "Own Fund Share Class instruments: name, FISN, CFI, currency, country of issue, issue date, vehicle type, regulatory regime, "
    "domicile, dealing frequency, distribution policy and MMF type are Derived copy (01) in enrich_17.py; issuer and fund manager "
    "are blank; identifier rows carry 'Derived from Own Share Class Indicator' = Y; 17 creates no listing rows for own share classes.",
    "CFI Code is kept on the Instrument (the code is allocated with the ISIN and published in FIRDS). If the business prefers, "
    "register CFI as an ICS- scheme and drop the column.",
    "No Index object: underlying indices reference 01 Benchmark (BMK-). If 01 Benchmark does not cover every index used as "
    "a derivative underlying (SME question 4), 01 should widen Benchmark rather than 17 add an Index object.",
    "Credit ratings are in 17 pending SME question 3 (17 vs 22). If moved to 22, Credit Rating Assignment moves with its name.",
    "Regulatory Instrument Classification is now an effective-dated Business Object; 33 Investment Compliance should reference "
    "it rather than re-derive eligibility.",
]
