"""Consolidation proposals from Data Domain 18 - Portfolio & Investment Book of Record (Stage 1 draft v0.1, 2026-10-06).

Proposal fragment only: the builder does not read it. The stage consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Format follows CONTRACT.md in this folder.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones (prefix, entity, owner domain, status, note). None needed.
#    18 uses only the reserved PORT-, HLD-, LOT- and PTXN- (proposals_expansion.py). Records without their own prefix
#    (Portfolio Identifier, Implementation / Hierarchy Link, Lifecycle Event, Lot Relief, Cash Balance, Projected Cash
#    Movement, Capital Activity, Transaction Event, Snapshot, Adjustment, Valuation Summary) are keyed by their grain.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_CANDIDATES: local 18 lists that look like enterprise lists, and shared-list membership to register.
#    (list name in 18, proposed shared list name, likely other users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Business Line", "Business Line", ["21", "10", "24", "27", "30", "32", "33"],
     "18 uses exactly the six enterprise business lines (Mutual Fund, ETF, Collective Investment Trust, Separately Managed "
     "Account, Private Markets, Insurance-Dedicated Fund), the same values as 21 'Business Line'. Make it one shared list "
     "(steward 21 or 09, from the capability map). 01 'Business Line' (Retail, Institutional, Wealth, Insurance, Retirement) "
     "means client segment, not business line: rename it locally in 01 (e.g. 'Client Segment') via LOCAL_RENAMES so the "
     "shared name is free. Mandates and seed books are not business lines: 18 records them through Implements Mandate "
     "links and the Proprietary Capital Indicator."),
    ("IBOR Operating Model", "Operating Model", ["26", "27", "28", "29", "30"],
     "CD-147 asks every affected master to carry an operating-model attribute. Generalize the values (In House, Outsourced, "
     "Hybrid, Received from Client / Third Party) into one shared list stewarded with the operating model register."),
    ("Portfolio Transaction Type", "Investment Transaction Type", ["25", "26", "27", "28"],
     "Trading, settlement, fund accounting and custody will need the same transaction type vocabulary; keep it distinct from "
     "06 shareholder transaction types."),
    ("Quantity Unit", "Quantity Unit", ["17", "25", "26", "28"],
     "Aligned to the ISO 20022 FinancialInstrumentQuantity choice (units, face amount, amortized value) plus contracts, "
     "notional and commitment."),
    ("Long / Short Indicator", "Long / Short Indicator", ["24", "25", "31", "33"], "Trivial but universal; share it."),
    ("Transaction Cost Category", "Transaction Cost Category", ["01", "25", "27"],
     "01 Cost Disclosure reports transaction costs to investors (MiFID II / PRIIPs); 25 will add implicit costs (TCA)."),
    ("Lot Relief Method", None, ["15"],
     "NOT_MERGED candidate: 15 'Cost Basis Method' is the shareholder's election on fund shares (IRC 6045); 18 'Lot Relief "
     "Method' is how a managed portfolio relieves its own lots, including the UK share identification rules. Overlapping "
     "values, different subject; record the pair in NOT_MERGED. Shared labels are aligned (FIFO, LIFO, High Cost, Low Cost, "
     "Specific Lot Identification, Average Cost); 15 'Loss / Gain Utilization' and 18 'Tax-Optimized' are close and could "
     "use one label."),
    ("Portfolio Identifier Scheme", None, ["15"],
     "NOT_MERGED candidate against 15 'Account Identifier Scheme': both have custodian numbers but identify different records."),
]

# Shared lists 18 uses directly as "Shared: <name>" (no local copy). Register 18 as a user in the 09 code list registry:
SHARED_LISTS_USED = ["Record Status", "Approval Status", "Flow Direction", "Period Type",
                     "Reconciliation Status", "Data Basis"]

# ---------------------------------------------------------------------------------------------------------------------
# 3. TERM_CONFLICTS noticed with existing domains (decisions.py format)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Business Line",
     "usages": [("01", "Investment Product.Business Line", "Client segment that owns the product commercially (Retail, Institutional, Wealth, Insurance, Retirement)"),
                ("18", "Portfolio.Business Line", "One of the six enterprise business lines"),
                ("21", "Business Line list", "The six enterprise business lines (capability map)")],
     "recommendation": "Reserve 'Business Line' for the six enterprise lines (18, 21, capability map); rename the 01 attribute "
                       "and list to 'Client Segment' (or similar) at consolidation."},
    {"term": "SMA Sponsor Program key",
     "usages": [("15", "Platform Program Enrollment.Enrolled Partner Program", "Sponsor program keyed by 05 PGM-"),
                ("18", "SMA Portfolio Detail.Sponsor Program Agreement", "Sponsor program agreement keyed by 05 AGR-")],
     "recommendation": "Agree with 05 whether an SMA sponsor program is identified by its agreement (AGR-) or its partner "
                       "program (PGM-); 18 follows the brief (AGR-) and can add the PGM- reference if 05 decides otherwise."},
    {"term": "Position",
     "usages": [("06", "Position (POS-)", "Units of a share class held by an account at a valuation date"),
                ("18", "Portfolio Holding (HLD-)", "Quantity of an instrument held by a portfolio at a holding date and holding view"),
                ("18", "Portfolio Position Snapshot / Position Adjustment", "Snapshot of, and manual correction to, portfolio holdings"),
                ("30", "Investor Capital Account (Stage 2)", "Investor commitment and capital in a private fund")],
     "recommendation": "CD-146 glossary terms: 'Shareholder Position' (06), 'Portfolio Holding' (18), 'Investor Capital Account' (30). "
                       "'Position' is not used bare in 18; the two 18 object names that keep 'Position' are qualified (Portfolio "
                       "Position Snapshot, Position Adjustment) and follow IBOR industry usage. Own-fund holdings link to the 06 "
                       "Shareholder Position through 'Corresponding Shareholder Position'."},
    {"term": "Transaction",
     "usages": [("06", "Transaction (TXN-)", "Shareholder purchase, redemption, exchange or transfer in a share class"),
                ("18", "Portfolio Transaction (PTXN-)", "Booked effect of a trade, income, corporate action, fee or transfer on a portfolio"),
                ("25", "Order / Execution / Allocation (Stage 2)", "Trading lifecycle before booking")],
     "recommendation": "Glossary: 'Shareholder Transaction' (06) vs 'Portfolio Transaction' (18); 'Transaction' alone resolves to 06 "
                       "in ownership.py aliases and must stay that way."},
    {"term": "Portfolio",
     "usages": [("01", "Model Portfolio (MDL-)", "Model allocation delivered to sponsors or followed by books; holds no assets"),
                ("18", "Portfolio (PORT-)", "Managed book of instruments the firm runs to deliver a product, mandate or SMA account"),
                ("12", "Holdings Presentation", "Presentation of a mandate's holdings to the client")],
     "recommendation": "Define 'Portfolio' as the 18 managed book. A model portfolio is never a Portfolio (CD-145); always say "
                       "'Model Portfolio' for 01. 'Portfolio Manager Assignment' (01) assigns managers to products today; 24 "
                       "should decide whether it moves to the 18 Portfolio."},
    {"term": "Market Value / AUM",
     "usages": [("06", "Position.Market Value; Asset Measures", "Shareholder position value and AUM measures for distribution"),
                ("18", "Holding Valuation.Market Value Base; Portfolio Valuation Summary.Total IBOR Market Value",
                 "IBOR investment estimate of holdings, cash and accrued income"),
                ("27", "NAV (Stage 2)", "Official net asset value")],
     "recommendation": "Qualify: 'IBOR Market Value' (18, estimate), 'Net Asset Value' (27, official), 'AUM' (06 measures). "
                       "AUM must not be summed from 18 IBOR values without the 06 measure definitions."},
    {"term": "Holding",
     "usages": [("06", "ETF Holding", "ETF shares held at a broker or custodian (distribution view)"),
                ("12", "Holdings Presentation", "How holdings are shown to an institutional client"),
                ("18", "Portfolio Holding", "Instrument held by a managed portfolio")],
     "recommendation": "Keep 06 'ETF Holding' (it is a shareholder position by broker); the glossary should say so."},
    {"term": "Snapshot",
     "usages": [("06", "Snapshot (SNP-)", "Frozen period view of distribution measures"),
                ("18", "Portfolio Position Snapshot", "Frozen view of a portfolio's holdings and cash")],
     "recommendation": "Different subjects; keep both, qualified."},
    {"term": "Cost Basis",
     "usages": [("15", "Cost Basis Election", "Shareholder's elected method for fund shares"),
                ("18", "Tax Lot.Adjusted Cost Basis Base", "Portfolio's adjusted basis in an instrument lot")],
     "recommendation": "Glossary: 'Shareholder Cost Basis' (15 / 13) vs 'Portfolio Lot Cost' (18)."},
    {"term": "Capital Activity / Flow",
     "usages": [("06", "Flow Measures", "Gross sales, redemptions and net flows by distribution dimensions"),
                ("18", "Portfolio Capital Activity", "Subscription and redemption cash expected into or out of a portfolio"),
                ("12", "Cash Flow Notification (CFN-)", "Client notice of a mandate contribution or withdrawal")],
     "recommendation": "Portfolio Capital Activity is cash to the portfolio for investment decisions, not a flow measure; it may "
                       "reference 12 CFN- and should never feed 06 flow measures."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Shared lists: content_18 defines 'Shared: <name>' entries in its CL by loading the values from shared_code_lists.py "
    "(helper _shared). Domain 18 is not a member of any shared list, so the builder would not add them; the loaded entries "
    "match what the builder would emit. If 18 is added as a member later, remove the helper and the 'Shared: ' CL keys.",
    "Prefix register: add PORT-, HLD-, LOT- and PTXN- (owner 18) to decisions.PREFIXES. Until then, references to 18 objects "
    "are typed 'Reference (<Object>, 18)' and references to 17 as 'Reference (Instrument, 17)' / 'Reference (Corporate Action "
    "Event, 17)' so ownership.py resolves them; the ', NN' can be dropped once INS-, CAE- and the 18 prefixes are registered.",
    "EMP-: three employee references are forced to 20 by OWNERSHIP_OVERRIDES in enrich_18.py; remove them once EMP- moves "
    "to 20 in decisions.PREFIXES (CD-151).",
    "CONCEPT_OWNERSHIP: add ('Portfolio', '18', 'PORT-', ['01','12','15','24','25','26','27','28','31','32','33'], "
    "'Managed book (IBOR)'), ('Portfolio Holding', '18', 'HLD-', [...]), ('Tax Lot', '18', 'LOT-', [...]) and "
    "('Portfolio Transaction', '18', 'PTXN-', [...]). Do not add a bare 'Position' alias for 18.",
    "Derived copies to hand over: Price Used, Price Date, Price Source, Holding FX Rate, Cash FX Rate, Delta Used (22); "
    "Source Allocation ID (25, becomes Reference (Allocation) once 25 registers a prefix); Settlement Confirmed Indicator (26).",
    "01 'Portfolio Manager Assignment' assigns managers to products; 24 should decide whether portfolio-level assignment "
    "references 18 PORT-. 18 does not model it.",
    "Cash Flow Notification (CFN-) is referenced by 18 Portfolio Capital Activity: 12 should add a reverse note that client "
    "cash notices feed the portfolio's capital activity.",
    "06 Position: consider an optional 'Holding Portfolio' reference (PORT-) on positions held by own fund-of-funds "
    "portfolios, mirroring 18 'Corresponding Shareholder Position' (CD-146).",
    "Seed capital: 18 records it once (Portfolio.Proprietary Capital Indicator). gaps_register proposes a 15 Account Seed "
    "Capital Indicator for the same fact; decide one owner with 43 Corporate Treasury & Capital (seed investment status).",
    "Removed from 18 after review because 01 masters them: master-feeder role and fund-of-funds flag, valuation frequency, "
    "fund administrator, sub-advisory (mandate type), in-kind dealing. 18 keeps only Daily Holdings Publication Indicator "
    "as a Derived copy of an 01 transparency term. 01 ETF Characteristics has no such term today: propose that 01 add 'ETF Transparency Type' (fully transparent under Rule 6c-11, semi-transparent / non-transparent under exemptive relief), after which the 18 attribute becomes its copy. Underlying fund manager is 17 'General Partner'.",
    "'Book of Record System' and 'Event Source System' use 'Firm-defined' values until 41 (application inventory) exists.",
]
