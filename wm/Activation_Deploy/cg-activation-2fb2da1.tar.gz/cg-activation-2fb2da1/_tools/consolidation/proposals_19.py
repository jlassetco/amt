"""Consolidation proposals from the Data Domain 19 (Finance & Accounting) draft, 2026-10-06 (revised after review 19_review.md).

Proposal fragment only: the builder does not read this file. The Stage 1 consolidation step merges accepted entries into
decisions.py, shared_code_lists.py and the 07, 09, 10, 14 and 20 content modules. Formats follow CONTRACT.md.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES  (prefix, entity, owner domain, status, note) - decisions.PREFIXES format
# No prefixes beyond those reserved in proposals_expansion.py (GLA-, LDG-, JNL-, APV-, FPL-, TAXR-) are used. Chart of
# Accounts, Chart Segment Value, Financial Statement Line, Supplier Payment, Supplier Payment Application, Receivable Item,
# Cash Receipt Application, Financial Statement and Transfer Pricing Documentation keep natural or composite keys (ERP
# document numbers; entity x framework x period x statement type; entity or group x fiscal year x document type).
# JNL- must be re-registered from 10 to 19 when CD-152 is applied; until then enrich_19.py forces journal references to
# "mastered here".
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

PREFIX_CHANGES = [
    ("JNL-", "Journal entry (header) and GL posting (journal x line)", "10 -> 19", "CD-152; note becomes 'Transferred from 10'."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED LISTS used directly (attributes show "Shared: <name>"; the content module reads the values from
#    shared_code_lists.py so they cannot drift). Add "19" as a consumer; no value_map is needed because 19 has no local
#    member list. Stewardship changes per CD-158.
# ---------------------------------------------------------------------------------------------------------------------
SHARED_USAGE = [
    ("Payable Invoice Status", "Payable Invoice.Payable Invoice Status", "Steward 10 -> 19 (CD-158)."),
    ("Outgoing Payment Status", "Supplier Payment.Outgoing Payment Status", "Steward 10 -> 19 (CD-158)."),
    ("Approval Status", "Financial Statement.Statement Approval Status", ""),
    ("Record Status", "Chart of Accounts, GL Account, Chart Segment Value status", ""),
    ("Regulator", "Regulatory Financial Return.Return Regulator", "Bank regulators (OCC, Federal Reserve) are already present for a group trust bank (SME Q3)."),
    ("Period Type", "Financial Statement.Statement Period Type", ""),
    ("Reporting Period Basis", "Financial Statement Line Value.Value Period Basis", ""),
    ("Frequency", "GL Account.Account Reconciliation Frequency; Regulatory Financial Return.Return Frequency", ""),
    ("Reconciliation Status", "GL Account Balance.Account Reconciliation Status; Intercompany Balance.Intercompany Match Status",
     "Replaces the draft local list Intercompany Match Status; elimination is the separate Eliminated Indicator."),
    ("RAG Status", "Close Task.Close Task RAG", ""),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: 19 local lists that look like enterprise lists  (list, domains, note)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Accounting Basis", ["10", "19", "27", "30"],
     "10 'Accounting Framework' (US GAAP, IFRS EU-adopted, UK-adopted IFRS, FRS 102, Lux GAAP) is a subset of 19 'Accounting "
     "Basis'. Propose one shared list stewarded by 19; 27 fund accounting will need it too (plus investment company bases)."),
    ("Plan Version Status", ["10", "19"],
     "19 copies the 10 values and adds 'Superseded'. Merge into one shared list stewarded by 19."),
    ("Plan Type", ["10", "19"],
     "Same four values as 10 'Plan Type' (Annual Budget, Rolling Forecast, Long-Range Plan, Scenario). The draft's 'Stress "
     "Scenario' value was removed from Plan Type; stress is a Plan Scenario value. Merge into one list stewarded by 19."),
    ("Plan Scenario", ["10", "19"],
     "10 'Scenario' values (Base, Upside, Downside, Market Stress) plus 19 'Capital and Liquidity Stress'. Merge; rename 10 "
     "'Scenario' to 'Plan Scenario' to avoid collision with risk scenarios in 31."),
    ("Journal Type", ["10", "19"],
     "Moved from 10 under CD-152; 10 retires its copy once GL Posting moves. A move, not a shared list."),
    ("Period Close Status", ["09", "10", "19"],
     "Moved from 10 under CD-152. 09 'Fiscal Period Status' becomes a derived copy; see VALUE_MAPS."),
    ("Payment Method", ["05", "12", "13", "15", "19", "29"],
     "Outgoing and incoming payment instruments (ACH, wire, SEPA, BACS, CHAPS, check). Propose a shared 'Payment Method' list "
     "aligned to ISO 20022, stewarded by 19 or 43."),
    ("Tax Type", ["13", "16", "19", "27", "28"],
     "Taxes only (country-by-country reporting moved to TP Documentation Type; FATCA registrations sit under Withholding Tax). "
     "A shared list becomes natural if CD-149 creates a Tax domain."),
    ("Financial Statement Type", ["19", "27", "35"],
     "Fund financial statements (27, 35) use the same statement types plus the schedule of investments."),
    ("Regulatory Return Type", ["09", "19", "35", "38"],
     "Entity regulatory returns will also be filed by 35 (e.g. Form N-PORT, AIFMD Annex IV) and 38. Propose an enterprise "
     "'Regulatory Filing Type' list with 19 owning the financial and capital returns."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. VALUE_MAPS for lists that become derived copies of 19 values  {(domain, list, value): 19 value}
# ---------------------------------------------------------------------------------------------------------------------
VALUE_MAPS = {
    # 09 Fiscal Period Status (Future, Open, Soft Close, Closed) -> 19 Period Close Status of the group primary ledger
    ("09", "Fiscal Period Status", "Future"): "Not Yet Opened",
    ("09", "Fiscal Period Status", "Open"): "Open",
    ("09", "Fiscal Period Status", "Soft Close"): "Soft Close",
    ("09", "Fiscal Period Status", "Closed"): "Hard Close",
    # reverse direction for publishing the 19 status into 09: Reopened -> Open; Permanently Closed -> Closed
    # 12 Fee Invoice Payment Status -> 19 Receivable Status of the Receivable Item that records the invoice
    ("12", "Payment Status", "Issued"): "Open",
    ("12", "Payment Status", "Partially Paid"): "Partially Paid",
    ("12", "Payment Status", "Paid"): "Cleared",
    ("12", "Payment Status", "Overdue"): "Open",          # overdue is derived from Receivable Due Date, not a status in 19
    ("12", "Payment Status", "Disputed"): "In Dispute",
    ("12", "Payment Status", "Written Off"): "Written Off",
    # 19 'Credited' has no 12 equivalent; propose adding 'Credited' to the 12 list or mapping it to 'Paid'.
}

# ---------------------------------------------------------------------------------------------------------------------
# 5. TERM_CONFLICTS  (decisions.TERM_CONFLICTS format). Updates to existing entries are marked "update".
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Account", "update": True,
     "usages": [("19", "GL Account (GLA-)", "Natural account of a chart of accounts (moved from 10 under CD-152)."),
                ("10", "Account Mapping (ACM-)", "Management P&L line -> 19 GL Account mapping (narrowed).")],
     "recommendation": "Replace the 10 'GL Account' usage with 19 GL Account (GLA-). Bare 'Account' stays the 15 ACC- client "
                       "account; finance always says 'GL Account', 'Natural Account' or 'Account Combination'."},
    {"term": "Revenue", "update": True,
     "usages": [("19", "Financial Statement Line Value (revenue lines); Receivable Item", "Reported revenue in published statements; fees receivable.")],
     "recommendation": "Enterprise 'Revenue' remains booked revenue (10 FRR-, CD-040). 'Reported Revenue' = the 19 statement "
                       "line value after consolidation and eliminations; reconcile 10 FRR- totals to 19 revenue GL balances."},
    {"term": "Budget / Plan",
     "usages": [("10", "Plan Version (BUD-), Plan Line", "Distribution budget, forecast and scenario versions at management P&L line grain."),
                ("19", "Financial Plan Version (FPL-), Financial Plan Line", "Enterprise budget, forecast and long-range plan at legal entity x GL account combination grain."),
                ("03", "Forecast (FCS-)", "Sales pipeline forecast."),
                ("20", "Workforce Position (WFP-) budget", "Budgeted positions with FTE, approved in an FPL- version.")],
     "recommendation": "'Financial Plan' = 19 FPL- (the enterprise plan of record). 10 'Plan Version' is 'Distribution Plan "
                       "Version' in the glossary and references the FPL- version it rolls into. 03 is a 'Sales Forecast'; 20 "
                       "positions are the 'Workforce Plan'; 19 Planned FTE is a top-down target only."},
    {"term": "Invoice",
     "usages": [("19", "Payable Invoice (APV-)", "Generic accounting record of any supplier invoice or credit note."),
                ("05", "Partner Invoice", "Partner's invoice for revenue sharing and platform fees, with variance and dispute."),
                ("12", "Fee Invoice (BIL-)", "Outgoing invoice to an institutional / SMA client."),
                ("13", "Intermediary Communication Fee Invoice (IFI-)", "Intermediary's invoice for shareholder communication fees."),
                ("14", "Data Invoice (DINV-)", "Vendor's invoice for licensed data, validated against the license.")],
     "recommendation": "Apply CD-158: 'Payable Invoice' and 'Receivable Item' are the accounting records and hold the links to "
                       "the domain invoices; domain invoices keep qualified names. Bare 'Invoice' is not used."},
    {"term": "Payment",
     "usages": [("19", "Supplier Payment; Supplier Payment Application", "Outgoing payment executed by AP / treasury and its application to invoices."),
                ("05", "Partner Payment (PMT-)", "Calculated and settled partner payment."),
                ("07", "Payroll Payment Instruction", "Instruction to payroll for incentive pay."),
                ("15", "Bank Instruction", "Investor's bank details on an account."),
                ("16", "Distribution / Payment", "Plan distributions to participants.")],
     "recommendation": "'Supplier Payment' = the 19 cash movement; it holds the link to the 05 Partner Payment it executes (CD-158)."},
    {"term": "Period",
     "usages": [("09", "Fiscal Period", "Calendar definition of the period."),
                ("19", "Accounting Period Status", "Open / closed state of a fiscal period for a ledger (moved from 10)."),
                ("06 / 07", "Reporting and compensation periods", "Domain-specific periods (CPRD-).")],
     "recommendation": "09 defines the period; 19 holds its close status per ledger. 09 'Fiscal Period Status' becomes a "
                       "derived copy of the group primary ledger's status (VALUE_MAPS)."},
    {"term": "Tax",
     "usages": [("19", "Entity Tax Registration, Tax Return (TAXR-), Tax Provision, Transfer Pricing Documentation", "Corporate tax of own entities."),
                ("02", "Tax Profile", "Party FATCA / CRS classification."),
                ("15", "Account Tax Certification / Reporting Status", "Investor withholding and reporting status."),
                ("13", "Tax Form Record", "Investor tax documents."),
                ("16", "Tax Withholding & 1099-R Detail", "Participant distribution tax.")],
     "recommendation": "Qualify as 'Corporate Tax' (19) vs 'Investor Tax' (02, 13, 15, 16) and 'Fund Tax' (27) until CD-149 "
                       "is decided."},
    {"term": "Payroll",
     "usages": [("20", "Payroll Result", "Employee x payroll run x pay date; compensation detail."),
                ("19", "GL Posting.Source Payroll Run", "Run-level summary posting; no employee detail.")],
     "recommendation": "The GL sees payroll only at run level (section 6, 20 Payroll Run)."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. CHANGES PROPOSED TO OTHER DOMAINS (to apply at consolidation; not applied now).
#    (domain, family, object, attribute, change, data type, example, note)
#    CD-158 link direction: invoice and payment links are held on the 19 records only (Payable Invoice.Source Data
#    Invoice / Source Intermediary Communication Fee Invoice / Source Partner Invoice; Supplier Payment.Settled Partner
#    Payment; Receivable Item.Source Fee Invoice / Source Fee Revenue Record / Source Intercompany Charge). No reverse link
#    attribute is proposed for 05, 12 or 13: each of them can find its 19 record through those references. 14's existing
#    'AP Document Reference' is the one exception because it already exists; it becomes a derived copy, not a new link.
# ---------------------------------------------------------------------------------------------------------------------
CROSS_DOMAIN_CHANGES = [
    # ---- CD-158 (invoices)
    ("14", "(family holding Data Invoice)", "Data Invoice", "AP Document Reference", "Re-flag as Derived copy of 19 Payable Invoice ID (owner 19)",
     "Identifier", "APV-2026-0018833", "Existing attribute (example AP-5100088123); name unchanged. The authoritative link is 19 Payable Invoice.Source Data Invoice."),
    ("12", "(family holding Fee Invoice)", "Fee Invoice", "Payment Status", "Re-flag as Derived copy of 19 Receivable Status (owner 19)",
     "Code", "Paid", "Value map in VALUE_MAPS. Not a link: 12 finds the Receivable Item through 19 Receivable Item.Source Fee Invoice."),
    # ---- CD-152 (chart of accounts, ledgers, plans) in 10
    ("10", "Chart of Accounts & GL Posting", "Account Mapping", "GL Natural Account", "Re-type", "Reference (GL Account)", "GLA-GRPCOA-620410", "Name unchanged."),
    ("10", "Chart of Accounts & GL Posting", "Account Mapping", "Applicable Ledger", "Re-type", "Reference (Ledger)", "LDG-4100-USGAAP-USD", "Name unchanged; local list 'Ledger' retired."),
    ("10", "Chart of Accounts & GL Posting", "Account Mapping", "External Reporting Line; XBRL Element; Revenue Disaggregation Category", "Remove (moved to 19)",
     "", "", "19 Financial Statement Line (FI-COA-040, -041) and Financial Statement Line Mapping (FI-COA-044)."),
    ("10", "Chart of Accounts & GL Posting", "GL Posting", "(object)", "Remove (moved to 19)", "", "", "19 Journal Entry and GL Posting."),
    ("10", "Period Close, Controls & Data Management", "Accounting Period Status", "(object)", "Remove (moved to 19)", "", "", "19 Accounting Period Status."),
    ("10", "Budgets, Forecasts & Plans", "Plan Version", "Enterprise Financial Plan Version", "Add", "Reference (Financial Plan Version)", "FPL-2027-BUD",
     "The 10 -> 19 roll-up link is held on 10 only (19 Financial Plan Line has no reverse reference)."),
    ("10", "Distribution Expense Accounting", "Distribution Cost Item", "Cost Center", "Re-type", "Reference (Chart Segment Value)", "41020",
     "Today Reference (Org Unit), example OU-CC-4410. The cost center charged is a GL segment value; the org unit is reached through 19 Represented Org Unit."),
    ("10", "Cost Allocation", "Cost Pool", "Contributing Cost Centers", "Re-type", "Reference (Chart Segment Value) (multi)", "44100; 44200",
     "Today Reference (Org Unit) (multi), example OU-CC-4410; OU-CC-4420."),
    ("10", "Budgets, Forecasts & Plans", "Plan Line", "Plan Cost Center", "Re-type", "Reference (Chart Segment Value)", "45100",
     "Today Reference (Org Unit), example OU-CC-4510."),
    ("10", "Intercompany & Transfer Pricing", "TP Policy", "TP Documentation Reference", "Re-type", "Reference (Transfer Pricing Documentation)", "UK Local File FY2025",
     "Today Text ('UK Local File FY2025 s.4.2'); 19 Transfer Pricing Documentation is now a Business Object with an identifier."),
    # ---- CD-152 in 09
    ("09", "(family holding Cost & Profit Center)", "Cost & Profit Center", "Cost Center Code; Profit Center Code", "Re-type",
     "Reference (Chart Segment Value)", "41020", "Codes mastered in 19 Chart Segment Value (amends CD-084)."),
    ("09", "(family holding Internal Legal Entity)", "Internal Legal Entity", "Accounting Company Code", "Re-flag as Derived copy (owner 19)",
     "Code", "4100", "Copy of the 19 Chart Segment Value of segment 'Company' that represents the entity; definition 'owned by 10 Finance' becomes 'mastered in 19 as the Company segment value'. Not a reference to Ledger."),
    ("09", "(family holding Fiscal Period)", "Fiscal Period", "Fiscal Period Status", "Re-flag as Derived copy (owner 19); reword definition",
     "Code", "Open", "Definition: 'Close status of the period for the group primary ledger, copied from 19 Accounting Period Status.' List values mapped in VALUE_MAPS."),
    ("09", "(code lists)", "Fiscal Period Status list; Org Hierarchy Type 'Cost Center' description", "", "Reword list source / description",
     "", "", "'Internal (owned by 10 Finance)' -> 'Derived from 19 Period Close Status'; 'Finance roll-up (aligned to 10)' -> 'Finance roll-up (aligned to 19 Chart Segment Value hierarchy)'."),
    ("09", "(relationships)", "REL 'Org Unit maps to Cost Center / Profit Center (10 DF)'", "", "Reword",
     "", "", "-> 'Org Unit is represented by Chart Segment Value (cost / profit center) [19]'; note 'Chart of accounts owned by 19 (CD-152)'."),
    # ---- 07
    ("07", "(family holding Compensation Accrual)", "Compensation Accrual", "GL Account", "Re-type", "Reference (GL Account)", "GLA-GRPCOA-620150", "CD-152."),
    # ---- 20 (program lead decision: payroll posts in summary)
    ("20", "Compensation, Benefits & Payroll", "Payroll Run", "(new object)", "Add Business Object",
     "", "UK-M-2026-09", "One row per legal entity x pay period x payroll run: Payroll Run Identifier (key), Payroll Legal Entity, Pay Period, Pay Date, "
     "Run Type (regular / off-cycle / bonus), Run Status, Payroll Currency. Payroll Result rows (employee x run x pay date) roll up to it through "
     "'Payroll Run Identifier' re-typed as Reference (Payroll Run). 19 GL Posting.Source Payroll Run is then re-typed to Reference (Payroll Run, 20)."),
    ("20", "Compensation, Benefits & Payroll", "Payroll Result", "Payroll GL Posting", "Remove",
     "", "", "Employee-level results are never linked to GL lines; the run-level link is held on 19 GL Posting. 20 REL 'Payroll Result is posted to GL Posting n : 1' "
     "becomes 'Payroll Run is posted by GL Posting 1 : 1..n' (held on 19)."),
    # ---- 02
    ("02", "(party identifiers)", "Organization / Party Identifier", "VAT Registration Number", "Consider adding",
     "Identifier", "GB123456789", "02 masters no VAT number today, so 19 Indirect Tax Detail.Supplier VAT Number is mastered here 'as printed on the invoice'. "
     "Own-entity EINs exist in both 02 Organization (on the LEN- mirror PTY-) and 19 Entity Tax Registration; recommend 19 masters own-entity tax registrations and the 02 mirror copies them."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. DECISION TEXT UPDATES
# ---------------------------------------------------------------------------------------------------------------------
DECISION_UPDATES = [
    ("CD-083", "resolution", "'10 owns fiscal period status, mirrored in 09.' -> '19 owns fiscal period status per ledger (Accounting Period Status, CD-152); 09 Fiscal Period Status is a derived copy for the group primary ledger.'"),
    ("CD-084", "resolution", "Cost and profit center codes are mastered in 19 Chart Segment Value (bare GL codes, e.g. 41020); the 09 org unit keeps its OU-CC- key and is linked through Chart Segment Value.Represented Org Unit. The OU-CC-nnnn format remains the org unit key, not the posting code."),
    ("CONCEPT_OWNERSHIP", "Org Unit row note", "'Cost center codes owned by 10 (CD-084)' -> 'Cost center codes mastered in 19 Chart Segment Value (CD-152)'."),
    ("CONCEPT_OWNERSHIP", "new rows", "GL Account (19, GLA-); Ledger (19, LDG-); Journal Entry / GL Posting (19, JNL-); Payable Invoice (19, APV-); Financial Plan Version (19, FPL-); Tax Return (19, TAXR-); Chart Segment Value / Cost & Profit Center Code (19, no prefix) replacing the 10 row 'Cost / Profit Center Code and GL Account'. Until then 19 self-references are typed 'Reference (X, 19)'."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 8. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "CD-152 moves: 10 'GL Posting' and 'Accounting Period Status' are re-created in 19 with names and attribute names kept. "
    "External Reporting Line and XBRL Element now sit on the new 19 Financial Statement Line (not on the mapping), Revenue "
    "Disaggregation Category on Financial Statement Line Mapping. Source_Notes.md section 2 lists every moved attribute with "
    "its 10 and 19 IDs.",
    "GL Posting 'Posted Account' was re-typed from Code (Firm-defined) to Reference (GL Account, 19); 'Journal ID' on GL "
    "Posting is the reference to the Journal Entry header (the key moved to Journal Entry). 'Source Finance Record' is "
    "extended to WVR- and CCA-; it remains a multi-target reference resolved to 10 and is a candidate for a typed "
    "(record type + ID) reference at consolidation.",
    "Revenue Disaggregation Category keeps the 10 'Revenue Stream' list, cited as 'External (10 - Revenue Stream)'; re-point "
    "it if Revenue Stream becomes a shared list.",
    "Fiscal periods and FX rate types are carried as Code with 'External (09 Shared - ...)' as in 10, with ownership forced "
    "to 09 in enrich_19.py. Year-type examples (FY2027-Y) assume 09 issues year-type fiscal period IDs; confirm the format "
    "with 09. Employee references are forced to 20 (CD-151 not yet applied).",
    "Applied Exchange Rate on GL Posting and GL Account Balance is a derived copy with owner 22 (CD-153). GL Posting "
    "'Source Payroll Run' is a derived copy with owner 20 until 20 adds Payroll Run.",
    "Supplier Payment 'Paying Bank Account' is a firm-defined code until 43 Corporate Treasury (or 19, if no treasury "
    "function exists) masters bank accounts; a Cash Receipt header (receipt amount, currency, bank account) belongs to the "
    "same owner.",
    "Payable Invoice 'Purchase Order Reference' is text until 40 Procurement masters purchase orders; then re-type.",
    "Receivable Item 'Other Source Document Reference' carries carried interest and incentive allocation sources as text "
    "until 30 Private Markets is drafted; then add a typed reference.",
    "US GAAP Taxonomy source URL: 19 cites https://www.fasb.org/xbrl; 10 cites https://xbrl.us/taxonomies. Align 10 to the "
    "FASB page at consolidation (FASB is the taxonomy owner).",
    "Tax (CD-149): the Corporate Tax family (FI-TAX) is self-contained and can move unchanged with TAXR- if a Tax domain is created.",
]
