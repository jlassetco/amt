"""Consolidation proposals from the Data Domain 20 Human Capital draft (Stage 1, 2026-10-06; revised after independent review).

A proposal fragment in the decisions.py formats (see CONTRACT.md). The builder does not read it; the Stage 1 consolidation step
merges accepted entries into decisions.py, shared_code_lists.py and the enrichment files, and applies the CD-151 removal from 09.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond those reserved in the brief: none. The draft uses only the reserved EMP-, JOB-, WFP-, ELE-, JRQ- and
#    VPA- (proposals_expansion.py). Candidate Application, Benefit Plan, Learning Item, Mandatory Training Requirement and
#    Payroll Run are keyed by source-system or firm-defined identifiers (ATS application and candidate numbers, benefits plan
#    code + plan year, LMS item code, requirement code, payroll run identifier) without an enterprise prefix.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# 2. CONCEPT_OWNERSHIP changes and additions (decisions.CONCEPT_OWNERSHIP tuple format)
# ---------------------------------------------------------------------------------------------------------------------
CONCEPT_OWNERSHIP = [
    # Change (CD-151): replaces ("Employee", "09", "EMP-", [...], "...") in decisions.py.
    ("Employee", "20", "EMP-", ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "12", "14", "15", "16", "17", "18", "19", "21"],
     "Enterprise employee master owned by HR, sourced from the HRIS; moved 03 -> 09 (CD-120) -> 20 (CD-151). 03 Sales extends it with the Sales Person profile (CD-144). 09 Org Unit 'Unit Head' references it."),
    ("Job Profile", "20", "JOB-", [], "Job family, level, SOC / ISCO occupation, FLSA status, regulatory status the role requires."),
    ("Workforce Position", "20", "WFP-", ["19"], "Authorized position; never 'Position' (06 POS-, 18 HLD-). Cost center and plan line reference 19."),
    ("Employee Lifecycle Event", "20", "ELE-", ["08"], "Hire to termination; not 16 Employment Event (PEMP-), which is a plan-participant event."),
    ("Job Requisition", "20", "JRQ-", [], ""),
    ("Variable Compensation Award", "20", "VPA-", ["19"], "Discretionary, deferred, fund-linked, carried interest and co-investment awards; excludes 07 sales incentive plans (ICP-)."),
    ("Payroll Run", "20", "", ["19"], "Legal entity x pay period x run; 19 journal entries (JNL-) carry the Payroll Run Identifier, one run : one or more journals."),
    ("Payroll Result", "20", "", ["07"], "Employee x payroll run; receives 07 Payroll Payment Instructions."),
    ("Material Risk Taker Identification", "20", "", ["07", "37", "38"],
     "Mastered in 20 (program lead decision: HR runs it). 07 Remuneration Conflict Assessment keeps only a derived copy (Identified Staff Indicator)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. Changes proposed to other domains (applied by the program lead; no content module outside 20 was edited)
# ---------------------------------------------------------------------------------------------------------------------
CROSS_DOMAIN_CHANGES = [
    {"domain": "07", "object": "Remuneration Conflict Assessment", "attribute": "Identified Staff Indicator",
     "change": "Keep the attribute but make it a Derived copy of 20 Material Risk Taker Identification / Material Risk Taker Indicator: add "
               "('Compensation Governance & Controls', 'Remuneration Conflict Assessment', 'Identified Staff Indicator'): '20' to enrich_07.DERIVED, "
               "and reword the definition to 'Copy of the identified staff / material risk taker status mastered in 20 Human Capital.'",
     "reason": "Program lead decision on review High A-1: 20 masters MRT identification; two domains must not master the same fact."},
    {"domain": "19", "object": "GL Posting", "attribute": "Source Payroll Result",
     "change": "Re-type to a reference to the 20 Payroll Run (by Payroll Run Identifier, e.g. 'UK-M-2027-04-R1'), not to the employee-level Payroll Result. 20 holds the reverse link on Payroll Run / Payroll Journal Entries (JNL-, 1 : 1..n).",
     "reason": "Review High G-1. 19 is being changed in parallel by its drafter; the two sides meet at the run."},
    {"domain": "07", "object": "Payroll Payment Instruction", "attribute": "(new) Payroll Payment Instruction ID",
     "change": "Add an identifier so 20 Payroll Result can reference instructions directly instead of the Compensation Statement (CPS-).",
     "reason": "Payroll Payment Instruction has no identifier today."},
    {"domain": "08", "object": "CE Requirement", "attribute": "(new) Evidencing Learning Completion",
     "change": "Add Reference (Learning Completion, 20), multi, so CE tracking in 08 points to completions held in 20. 20 dropped its 'Credited Individual Registration' attribute so that the link runs from 08 to 20.",
     "reason": "Review Medium A-4: CE tracking is owned by 08 (brief §4)."},
    {"domain": "03 / 07 / 08", "object": "definition text",
     "change": "Re-point text that will be stale after CD-151: 03 Sales Personnel and Sales Structure ('mastered by HR in 09 Workforce', several occurrences); "
               "07 'Plan Participant' and 'Salesperson Territory Assignment' ('owned by 03 Sales'); 08 Registration family ('The individuals themselves are defined in 03 Sales'). All should say 20 Human Capital.",
     "reason": "Review Low A-10."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. SHARED_CANDIDATES: local lists that look like enterprise lists, or that should join an existing shared list.
#    (local list in 20, proposed shared list, steward, other domains with the same concept, note)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Employment Type", "Employment Type (moved list)", "20", ["03", "09"],
     "Identical values exist in 03 (left behind by CD-120) and 09 (moved here by CD-151). Retire both copies at merge; 03 and 09 reference EMP- only. Contingent Worker Type refines it (mapping in the list descriptions)."),
    ("Employment Status", "Employment Status (moved list)", "20", ["03", "09"], "As above."),
    ("Job Family", "Job Family", "20", ["09"],
     "Employee 'Job Family' (moved from 09) is typed Code / Firm-defined; propose retyping it to this list and treating it as derived from the Job Profile of the primary assignment."),
    ("Regulated Role Category", "SM&CR Population (extended)", "08", ["08"],
     "08 'SM&CR Population' (Senior Manager, Certification Staff, Conduct Rules Staff, Not in Scope) is the individual's status; 20 holds what the role requires, plus FINRA categories. Recommend one 08-stewarded list for the SM&CR values, used by both, with 20 keeping the FINRA values locally or in a second 08 list. Depends on SME question 3."),
    ("Employee Termination Reason", "Separation Reason", "20", ["16"],
     "16 participant employment events carry a separation reason for plan purposes; align values where the firm recordkeeps its own plan."),
    ("Gender Identity", "Gender Identity", "02", ["02"], "02 may collect gender for individuals (client look-through); align the value set and the special-category handling."),
    ("Completion Status", "Training Completion Status", "20", ["08"],
     "08 'CE Status' uses 'Complete' where 20 uses 'Completed', and 'Overdue - CE Inactive' / 'Extension Granted' are CE-specific. Reconcile the labels if a shared list is created."),
    ("Readiness", "Readiness", "20", [], "Candidate for reuse by 37 key-person risk and 35 board succession."),
]

# Shared lists referenced directly by this draft as 'Shared: <name>' (the module copies their values from
# shared_code_lists.py so it validates on its own): Record Status, Severity, Frequency, Regulator, Period Type,
# Information Classification. Approval Status was used in v0.1 and dropped when the approval attributes were trimmed.
SHARED_DIRECT_USE = ["Record Status", "Severity", "Frequency", "Regulator", "Period Type", "Information Classification"]

# Similar lists deliberately kept apart (shared_code_lists.NOT_MERGED format)
NOT_MERGED = [
    ("20", "Background Screening Result", "08", "Screening Result",
     "Different concepts: pre-employment background check outcome vs sanctions / PEP / adverse-media match disposition. The brief named the local list 'Screening Result', which collides with the shared list name."),
    ("20", "Background Screening Type", "08", "Screening Type", "Employment background checks vs party compliance screening (sanctions, PEP, adverse media)."),
    ("20", "Employee Benefit Type", "08", "Benefit Type", "Employee benefits vs gifts, entertainment and non-cash compensation."),
    ("20", "Employee Benefit Type", "05", "Benefit Type", "Employee benefits vs partner program benefits."),
    ("20", "Award Vesting Basis", "16", "Vesting Basis", "Deferred award vesting vs IRC 411(a) retirement plan vesting."),
    ("20", "Job Assignment Type", "07", "Assignment Type", "Employee job assignment vs coverage assignment."),
    ("20", "Employee Lifecycle Event Type", "01", "Lifecycle Event Type", "Employment events vs product lifecycle events."),
    ("20", "Performance Review Type", "05", "Review Type", "Performance review vs partner due diligence review (08 has a third, communication review)."),
    ("20", "MRT Remuneration Regime", "07", "Remuneration Regime",
     "07 lists conduct and inducement rules for sales pay (Reg BI, FINRA 2341 / 3220, SYSC 19F, Consumer Duty); 20 lists the remuneration rules that drive MRT deferral (UCITS, AIFMD, MIFIDPRU, IFD)."),
    ("20", "Learning Item Type", "08", "Attestation Type", "Training items vs policy attestations; 'Attestation' was removed from the 20 list."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. TERM_CONFLICTS (decisions.TERM_CONFLICTS format)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Position",
     "usages": [("06", "Position (POS-)", "Shareholder holding of a share class in an account"),
                ("18", "Portfolio Holding (HLD-)", "Holding of an instrument in a managed portfolio"),
                ("20", "Workforce Position (WFP-)", "Authorized seat in an org unit filled by an employee")],
     "recommendation": "Never use 'Position' unqualified in HR data: 'Workforce Position'. Glossary entry for 'Position' points to all three."},
    {"term": "Award",
     "usages": [("11", "Award (AWD-)", "Industry award or rating won by a product or the firm"),
                ("20", "Variable Compensation Award (VPA-)", "Bonus, deferred award, carried interest or co-investment granted to an employee")],
     "recommendation": "Qualify as 'Variable Compensation Award' in 20 and 'Industry Award' in 11."},
    {"term": "Bonus",
     "usages": [("07", "Plan Type 'Bonus Only'", "Discretionary or formula bonus under a sales incentive compensation plan (ICP-)"),
                ("20", "Variable Award Type 'Annual Cash Bonus'", "Discretionary bonus not paid under a 07 ICP-")],
     "recommendation": "A bonus paid under a 07 ICP- is never recorded as a 20 award; it reaches 20 only as a Payroll Payment Instruction included in a Payroll Result. 20 'Annual Cash Bonus' covers discretionary bonuses outside 07 plans."},
    {"term": "Goal / Objective",
     "usages": [("07", "Goal (GOL-)", "Sales goal or quota for a territory or salesperson"),
                ("20", "Performance Objective", "Individual objective assessed in a performance review")],
     "recommendation": "07 keeps 'Goal' for quotas; 20 uses 'Performance Objective'. A Performance Objective links to quantitative measures only through 21 Metric Definition (KPI-); it does not reference a 07 Goal."},
    {"term": "Plan",
     "usages": [("07", "Incentive Compensation Plan (ICP-)", "Sales incentive plan"),
                ("16", "Retirement Plan (recordkept)", "Retirement plan administered for clients, possibly including the firm's own 401(k)"),
                ("19", "Financial Plan Version (FPL-) / Financial Plan Line", "Budget or forecast"),
                ("20", "Benefit Plan; Succession Plan Entry", "Employee benefit plan offered by an employing entity; successor named for a position")],
     "recommendation": "Always qualify 'Plan'. The firm's own 401(k) is a 16 recordkept plan when recordkept in house; 20 Benefit Plan carries only the offering and links enrollments to 16 PMEM-."},
    {"term": "Employment Event",
     "usages": [("16", "Employment Event (PEMP-)", "Plan participant's hire, rehire or separation as reported by a plan sponsor"),
                ("20", "Employee Lifecycle Event (ELE-)", "The firm's own employee's hire, transfer, promotion or termination")],
     "recommendation": "Keep both names. For the firm's own 401(k), 20 ELE- events feed 16 PEMP- through the payroll / sponsor interface; 16 does not read 20 directly."},
    {"term": "Remuneration Regime / Identified Staff",
     "usages": [("07", "Remuneration Regime; Identified Staff Indicator", "Rules constraining sales pay design; identified staff flag on a plan participant"),
                ("20", "MRT Remuneration Regime; Material Risk Taker Indicator", "Remuneration rules under which a material risk taker / identified staff member is identified")],
     "recommendation": "20 masters identification; 07 Identified Staff Indicator becomes a derived copy (CROSS_DOMAIN_CHANGES). Keep the two regime lists apart (NOT_MERGED)."},
    {"term": "Screening",
     "usages": [("08", "Screening Result / Screening Type", "Sanctions, PEP and adverse-media screening of parties"),
                ("20", "Background Screening", "Pre-employment and periodic background checks of candidates and employees")],
     "recommendation": "Use 'Background Screening' for HR checks. Sanctions, PEP and adverse-media screening of employees, including any done by the background-check vendor, is recorded with the 08 lists; 20 Background Screening Type no longer has a sanctions value."},
    {"term": "Attestation",
     "usages": [("08", "Attestation (Attestation Type: Code of Ethics Acknowledgment, Outside Business Activities Declaration, ...)", "Policy attestation by an individual"),
                ("20", "Learning Item / Mandatory Training Requirement", "Training items and training requirements")],
     "recommendation": "Policy attestations stay in 08 (later 38 for codes of ethics). 20 removed 'Attestation' from Learning Item Type and 'Code of Ethics and Personal Trading' from Training Requirement Type."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "CD-151 in content_20: 'Employee' (16 attributes), 'Employee Reporting Line' (5) and 'Org Unit Assignment' (3) keep every name, definition, type, example, reference and CDE flag of their 09 tuples (old IDs SR-WFC-001..016, SR-WFC-017..021 and SR-ORG-018..020). Follow-up applied under the program lead's PII decision: the Notes column now says PII on every moved attribute (it was missing on Employee ID, Job Title, Job Family, Employing Legal Entity, Home Org Unit, Work Location, Employment Type, Employment Status, Reporting Employee, Line Manager, Reporting Line Type, the two reporting dates, Assigned Org Unit and Assignment Effective From / To). At merge: delete the 09 Workforce family and Org Unit Assignment, delete the 09 code lists Employment Type, Employment Status and Reporting Line Type, and update 09 REL 'Internal Legal Entity employs Employee (03 SL, EMP-)' to point at 20.",
    "After the merge, update decisions.PREFIXES EMP- owner to 20 and register JOB-, WFP-, ELE-, JRQ-, VPA-; then the 33 OWNERSHIP_OVERRIDES in enrich_20.py that force EMP- and own-object references to 'mastered here' can be removed (keep the JNL- -> 19 override on Payroll Run / Payroll Journal Entries until CD-152 transfers JNL- from 10).",
    "ownership.ALIASES maps 'employee' and 'salesperson' to 09; change both to 20 when CD-151 is applied.",
    "Proposal: split 'Org Unit Assignment' / 'Assignment Effective From / To' (Text, '2025-04-01 / ') into 'Assignment Effective From' and 'Assignment Effective To' (Date), and relabel its Applies To from 'Org Unit' to 'Org Unit Assignment'. Not done in the draft because CD-151 requires the move to be unchanged.",
    "Authoritative source for each piece of org placement (review B-1): Employing Legal Entity on Employee is the employment contract; Position Legal Entity must equal it except during a secondment (inbound: Contingent Worker Detail / Secondment Home Entity; outbound: Job Assignment Type 'Secondment'). Org Unit Assignment is the authoritative HR org placement; Position Org Unit is the budget owner and may differ in a matrix organization. Employee Home Org Unit, Work Location, Job Title and Job Family are current-state copies of the primary Org Unit Assignment and Employee Job Assignment (its position's location and job profile); Hire Date and Termination Date are current-state copies of the Hire and Termination Employee Lifecycle Events. Propose flagging these as derived within 20 after the merge (no cross-domain effect).",
    "03 Sales still holds local lists 'Employment Type' and 'Employment Status' from before CD-120; propose retiring them (03 references EMP-).",
    "Workforce Position 'Authorized FTE' is the position's authorized FTE, not the budget; each position references the 19 Financial Plan Line ('Budget Plan Line') whose Planned FTE should equal the sum of the Authorized FTE of its positions (a reconciliation control for 19 and 21). 'Position Cost Center' is typed Reference (Chart Segment Value, 19) with a bare code example because 19 has no reserved prefix for segment values; the 09 'Cost Center Code' example 'OU-CC-41020' looks like an org unit ID.",
    "CD-143 note to extend: where the firm recordkeeps its own 401(k), 16 keys each participating employee as a 02 PTY- (Participant Plan Membership). That PTY- is for the participant role only; Employee / Client Party Cross-Reference links it and Benefit Enrollment / Own Plan Membership links the PMEM-.",
    "Human Capital Metric Value references 21 Metric Definition (KPI-); 21 should register the ISO 30414 / ESRS S1 / EEO-1 / gender pay gap metrics as KPI- entries with this domain as producer, and list for each the breakdown dimensions allowed in 'Metric Breakdown'.",
    "Information Classification: compensation objects (Base Pay Record, Variable Compensation Award, Deferred Award Tranche, Payroll Run, Payroll Result) should default to 'Confidential - Compensation' and diversity, screening and leave data to 'Restricted - Personal Data' in the 21 Object Governance Profile.",
]
