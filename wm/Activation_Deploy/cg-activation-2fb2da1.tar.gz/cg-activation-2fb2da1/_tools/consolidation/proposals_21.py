"""Consolidation proposals from the Data Domain 21 (Data Governance & Analytics) draft, 2026-10-06 (revised after review).

A proposal fragment in the decisions.py / shared_code_lists.py formats (see CONTRACT.md). The builder does not read it; the
Stage 1 consolidation step merges accepted entries. Nothing here changes another domain's content module.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. DECISIONS proposed by 21 (decisions.py format). IDs are placeholders; the consolidation step numbers them after CD-160.
# ---------------------------------------------------------------------------------------------------------------------

DECISIONS = [
    {"id": "CD-21-A", "theme": "Enterprise Structure",
     "title": "Authoritative source: 21 System of Record Designation is the element-level master; 14's dataset-level indicator is reconciled to it",
     "domains": ["21", "14"],
     "issue": "14 Dataset Consumption carries 'Authoritative Source Indicator' (whether the dataset is the authoritative source "
              "for its Target Concept) and 21 System of Record Designation (Designation Type 'Authoritative Source') designates "
              "the authoritative system or asset per taxonomy element. Two domains could state the same fact.",
     "resolution": "Program lead decision (review High A1): 21 masters the designation per taxonomy element (object or attribute), "
                   "naming a system or a cataloged asset (a licensed dataset is a Data Asset referencing DSET-). 14 keeps its "
                   "dataset-level Authoritative Source Indicator as its own fact about a dataset consumption and does not "
                   "re-master it; a consolidation check reconciles it: where the indicator is Y, a 21 designation of type "
                   "Authoritative Source must exist for the target element with Designated Data Asset = the dataset's asset, and "
                   "vice versa. 21 holds no copy of 14 Dataset Consumption facts (consuming domain, use case, permitted use, "
                   "target concept). Amends CD-160.",
     "rationale": "One element-level answer to 'which source is authoritative', without moving licensing facts out of 14.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Chief Data Officer"},

    {"id": "CD-21-B", "theme": "Identifiers",
     "title": "Stable taxonomy element identity; positional attribute codes are release-specific labels",
     "domains": ["21", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16"],
     "issue": "taxonomy_builder.model() numbers attributes by position ({family code}-{n:03d}); inserting one attribute "
              "renumbers every later code in the family. Governance records (CDE, classification, DQ rules, mappings, "
              "system-of-record designations, ownership, profiles, data product inputs) anchored on those codes would attach to "
              "the wrong element after a release.",
     "resolution": "Program lead decision (review High D1): 21 Taxonomy Element is the stable identity (Data Domain, family, "
                   "object and attribute by name, key 'NN | Family | Object | Attribute'); Taxonomy Element Registration is its "
                   "per-release version and carries the positional code as 'Published Element Code'. Every governance record "
                   "references the Taxonomy Element and records the release it was registered in. Renames and moves create a "
                   "new element linked by Successor Taxonomy Element. Recommend the builder and baseline JSON emit the name-path "
                   "key next to the positional ID, and that check_baseline.py reports renames as successor links.",
     "rationale": "Governance metadata must survive releases; names are what the business recognizes and what the data "
                  "product contract already uses ('exact L3 object and L4 attribute names').",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Program Lead"},

    {"id": "CD-21-C", "theme": "Transactions & Measures",
     "title": "Metric certification is mastered in 21; 06 Measure Definition 'Certified Indicator' becomes a derived copy",
     "domains": ["21", "06", "10", "11"],
     "issue": "06 Measure Definition carries 'Certified Indicator'; 21 Metric Definition carries 'Metric Certification Status' "
              "for the metric that registers the same measure.",
     "resolution": "21 masters certification (status, owning semantic model, source product). 06 keeps the measure definition "
                   "and formula; its Certified Indicator is flagged Derived copy (owner 21) at consolidation. 10 and 11 measure "
                   "definitions follow the same rule.",
     "rationale": "Certification is a governance act of the data office; the definition is the producing domain's.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Data Officer"},

    {"id": "CD-21-D", "theme": "Reference Data",
     "title": "Licensed datasets: 14 masters owner, classification and personal data flag; 21 references them",
     "domains": ["21", "14"],
     "issue": "A 21 Data Asset of type Licensed Dataset could repeat 14 Dataset Business Owner, Information Sensitivity and "
              "Contains Personal Data Indicator.",
     "resolution": "For licensed datasets the 14 Dataset is the master of owner, classification and personal data flag. 21 "
                   "references DSET- from the Data Asset and does not create Data Classification Assignments or ownership "
                   "assignments for them.",
     "rationale": "Keeps license-related facts with the licensing function (CD-160).",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Data Officer"},

    {"id": "CD-21-E", "theme": "Code Lists",
     "title": "Classification precedence: record > element or asset assignment > object default",
     "domains": ["21", "02", "41"],
     "issue": "Information Classification and personal data categories can be stated on a record (Record Governance Metadata), "
              "on an element or asset (Data Classification Assignment), on an object (Object Governance Profile default) and "
              "on a data product's output.",
     "resolution": "A record's own value overrides an element or asset assignment, which overrides the object default. A data "
                   "product's classification describes its published output and must be at least as restrictive as its inputs.",
     "rationale": "One deterministic answer for access control.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Data Officer"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. PREFIXES (prefix, entity, owner domain, status, note)
# No prefix beyond those reserved in proposals_expansion.py (DQR-, DQI-, DAS-, BTM-, KPI-, DP-, CD-, AIU-) was needed.
# Objects without a reserved prefix use numeric system keys (governance body, ownership assignment, CDE, DQ result, lineage
# link, system-of-record designation) or composite keys (term relationship, classification assignment, element mapping,
# profiles, data product input, AI data usage approval). Taxonomy Element uses a name-path key (CD-21-B).
# ---------------------------------------------------------------------------------------------------------------------

PREFIXES = []

PREFIX_NOTES = [
    ("DQR-", "decisions.PREFIXES registers DQR- to 06 as Proposed. Until CD-156 is applied, enrich_21.py forces the 21 "
             "references to Data Quality Rule to 'mastered here' with OWNERSHIP_OVERRIDES; remove those once DQR- is "
             "re-registered to 21."),
    ("EMP-", "decisions.PREFIXES still registers EMP- to 09. enrich_21.py forces the 7 employee references to 20 (CD-151); "
             "remove those overrides once EMP- is re-registered to 20."),
    ("DP-", "Data contract IDs are shown as '<product>-Cnn' (e.g. DP-008-C02), a child key of DP-, not a new prefix. Any "
            "prefix scan will read it as a data product; acceptable for v0.1."),
    ("SM-", "Semantic models (SM-00 to SM-07, _tools/semantic_model/register.py) are carried as the local code list "
            "'Semantic Model'. Model-level facts (owner, functions, access) stay in register.py. If semantic models need "
            "their own records, register SM- to 21 and make Semantic Model a Business Object (SME question 13)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED CODE LISTS
# 21 now references shared lists directly as 'Shared: <name>' with values loaded from shared_code_lists.py at import (the
# 18-20 pattern): Data Quality Status, Information Classification, Personal Data Category, Record Status, Approval Status,
# Severity, Case Status, Frequency. No membership value_map is needed for these.
# Business Domain is a local copy (shared values plus proposed additions) until the change below is applied; then 21
# joins as a member with an identity value_map.
# ---------------------------------------------------------------------------------------------------------------------

SHARED_MEMBERSHIP = [
    ("Business Domain", "Business Domain", "identity map for 01-14 and the two EXT_ values; 15-21 map to the codes added below"),
]

SHARED_CHANGES = [
    {"list": "Business Domain", "change": "Add values",
     "values": [("ACCOUNT", "15 Account", ""), ("RETIREMENT_PLAN_ADMINISTRATION", "16 Retirement Plan Administration", ""),
                ("INSTRUMENT_ISSUER_REFERENCE", "17 Instrument & Issuer Reference", ""),
                ("PORTFOLIO_IBOR", "18 Portfolio & Investment Book of Record", ""),
                ("FINANCE_ACCOUNTING", "19 Finance & Accounting", ""), ("HUMAN_CAPITAL", "20 Human Capital", ""),
                ("DATA_GOVERNANCE_ANALYTICS", "21 Data Governance & Analytics", "")],
     "note": "15 and 16 (wave 3) are also missing today. Recommend generating the list from domains.DD_NAMES so 22-44 are "
             "added as each stage is drafted, keeping the two EXT_ values. Codes for 15-21 are proposals."},
    {"list": "Data Quality Status", "change": "Steward 09 -> 21", "values": [],
     "note": "CD-148. The list describes record validation against 21 data quality rules."},
    {"list": "Information Classification", "change": "Steward to be decided (21 or 41)", "values": [],
     "note": "Brief SME question 11. Recommended: 41 stewards the scheme and its labels; 21 stewards the assignments and the "
             "precedence rule (CD-21-E). Until 41 exists, 21 stewards both."},
]

SHARED_CANDIDATES = [
    ("System", "Interim list of systems of record and hosting platforms used by 21 (Data Asset, System of Record "
               "Designation, Record Governance Metadata). Consolidate at 41 with 04 'Marketing System' (a small martech "
               "system registry), 14 'Consuming Application' names (e.g. Distribution Data Warehouse), 09 Code Mapping "
               "'Source System' and the free 'System of Record' values in the excluded Record Metadata blocks (CD-160)."),
    ("Business Line", "21 now uses 18's list name and all eight values (no third variant). Register one shared 'Business "
                      "Line' list from 18 and 21 (steward 09, or 01 if product owns the line definition). 01's list of the "
                      "same name means client segment (Retail, Institutional, Wealth, Insurance, Retirement): LOCAL_RENAME "
                      "it to 'Client Business Segment'."),
    ("Governance Role", "Data Owner, Data Steward, Data Custodian, Data Product Owner, Metric Owner, Glossary Steward, DQ "
                        "Rule Owner. 09 Code List and 14 Dataset hold owner / steward attributes; at consolidation they "
                        "resolve through 21 Data Ownership Assignment (steward 21)."),
    ("DQ Dimension", "06 has 'DQ Dimension' (six values); 21 adds Integrity. When CD-156 moves DQ Rule, 06's list is retired "
                     "into 21's (all six 06 values map one to one)."),
    ("Governance Certification Status", "Candidate shared list for any certified asset (metric, data product, report, "
                                        "object). Named to avoid 15 'Certification Status' (tax form certification)."),
    ("Governance Priority", "High / Medium / Low, used by the decision log and the data product framework; candidate to "
                            "merge with any other plain priority list."),
    ("Semantic Model", "Generate from semantic_model/register.py MODELS rather than maintaining by hand."),
    ("Data Product Business Function", "The 19 functions of the data product framework (FN-01 to FN-19); generate from "
                                       "data_products/framework.py. Named to avoid 09 'Business Function'."),
    ("Data Product Delivery Mode", "Generate from data_products/framework.py DELIVERY."),
    ("Metric Aggregation Rule", "Same values as semantic_model register.AGGREGATION and close to 06 'Aggregation Behavior'; "
                                "one shared list (steward 21)."),
    ("Metric Unit", "Unit of measure for metric values; 20 Human Capital Metric Value reads it from the 21 metric. Candidate "
                    "shared list if other value objects carry units."),
]

NOT_MERGED = [
    ("09", "Mapping Type", "21", "Element Mapping Type", "09 maps code values between schemes (Exact / Close / Broad Match); 21 maps physical elements to taxonomy attributes (Direct / Transformed / Derived)."),
    ("11", "Release Status", "21", "Taxonomy Release Status", "11 is the status of an industry data release; 21 is the publication status of a taxonomy release."),
    ("15", "Certification Status", "21", "Governance Certification Status", "15 is tax form certification; 21 is data asset certification."),
    ("09", "Business Function", "21", "Data Product Business Function", "Different granularity and purpose."),
    ("14", "Permitted Use Category", "21", "Permitted AI Data Use", "Different grain: 14 codes what a license permits per dataset; 21 codes how an AI use case uses data. Each 21 value names its 14 counterpart in the description, and the approval references the 14 Permitted Use Grant."),
    ("04", "Personal Data Classification", "21", "Personal Data Sensitivity", "Not a merge but a rename: 21's list carries 04's four values (No Personal Data, Pseudonymized, Personal Data, Special Category); propose 04 maps to it at consolidation."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM CONFLICTS (decisions.py TERM_CONFLICTS format)
# ---------------------------------------------------------------------------------------------------------------------

TERM_CONFLICTS = [
    {"term": "Report",
     "usages": [("12", "Report Definition (RPT-)", "A client report produced and delivered to an institutional client or consultant."),
                ("08", "Regulatory filings and reports", "A filing or report to a regulator."),
                ("21", "Analytics Report", "An internal BI report or dashboard cataloged as a Data Asset.")],
     "recommendation": "'Report' alone means a 12 client report. Use 'Analytics Report' and 'Dashboard' for internal BI content "
                       "(21) and 'Regulatory Report' or the form name for filings. Client reports are lineage endpoints in 21, not Data Assets."},
    {"term": "Data Quality",
     "usages": [("06", "DQ Rule, Reconciliation, Break", "Rules and reconciliations on distribution feeds."),
                ("14", "Vendor Data Issue, Vendor Data SLA", "Quality of licensed vendor data and the vendor's commitments."),
                ("21", "Data Quality Rule, Result, Issue", "The enterprise rule catalog, results and issues."),
                ("All", "Data Quality Status", "Validation state of a record.")],
     "recommendation": "Data quality rules, results and issues are 21's (CD-156). A reconciliation compares two feeds and stays 06; "
                       "a vendor data issue is a ticket with the vendor and stays 14, linked from a 21 Data Quality Issue."},
    {"term": "Measure / Metric / KPI",
     "usages": [("06", "Measure Definition (MSR-)", "Certified flow and AUM measures with definition and formula."),
                ("10", "Profitability Measure Definition", "Profitability measures with formula."),
                ("11", "Market Share Definition (MSHD-)", "Market share formulas."),
                ("data products", "measures", "Derived measures of a data product spec."),
                ("21", "Metric Definition (KPI-)", "Registry entry for any certified business metric: unit, aggregation, direction, certification."),
                ("20", "Human Capital Metric Value", "Values of 21 workforce metrics.")],
     "recommendation": "'Measure Definition' is the definition and formula owned by the producing domain; 'Metric' is the registered, "
                       "certified business metric in 21, which references the measure definition and restates neither its definition "
                       "nor its formula; 'KPI' is a metric with a target. Certification is 21's (CD-21-C). A business term that names "
                       "a metric points at the metric (Business Term 'Defining Metric')."},
    {"term": "Dataset / Data Asset / Data Product",
     "usages": [("14", "Dataset (DSET-)", "A licensed external dataset with license terms."),
                ("06", "Data Feed (FEED-)", "A technical inbound feed."),
                ("12", "Client Data Feed (CDF-)", "An outbound feed to a client."),
                ("21", "Data Asset (DAS-)", "Any cataloged internal asset."),
                ("21", "Data Product (DP-)", "A governed product with an owner, inputs, contract and SLA.")],
     "recommendation": "Dataset = licensed external data (14); Data Asset = any cataloged asset (21), one of whose types is Licensed "
                       "Dataset and another Feed; Data Product = a governed product (21). 14's family name 'Dataset & Data Product "
                       "Catalog' should become 'Licensed Dataset Catalog' (CD-160)."},
    {"term": "Owner",
     "usages": [("01, 02, 08, 12, 13, 15, 16", "Data Owner (excluded Record Metadata)", "Typed Reference (Party)."),
                ("03, 04, 05, 07, 09, 10, 14", "Data Owner (excluded Record Metadata)", "Typed Reference (Employee)."),
                ("06, 11", "Data Owner (excluded Record Metadata)", "Typed Text (firm-defined role)."),
                ("09", "Code List Data Owner", "Reference (Employee)."),
                ("14", "Dataset Business Owner", "Reference (Employee)."),
                ("21", "Data Ownership Assignment", "Employee in a governance role over a typed scope; the only master of data ownership."),
                ("various", "Account owner, product owner, plan owner", "Business ownership, not data ownership.")],
     "recommendation": "'Data Owner' is a governance role held by an employee (20 EMP-), recorded only in 21 Data Ownership Assignment; "
                       "never a Party or free text. Record-level overrides use 'Record Data Owner'. Business ownership keeps its own qualified names."},
    {"term": "System of Record / Authoritative Source",
     "usages": [("01-16", "System of Record (excluded Record Metadata)", "Free firm-defined code on each record."),
                ("14", "Dataset Consumption / Authoritative Source Indicator", "Whether a licensed dataset is the authoritative source for its target concept."),
                ("21", "System of Record Designation", "Effective-dated designation of a system or asset per taxonomy element and business line.")],
     "recommendation": "21's designation is the element-level master; 14's indicator stays as a dataset fact and is reconciled to it "
                       "(CD-21-A); the record-level System of Record in Record Governance Metadata must agree with the designation."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------

NOTES = [
    "CD-148: Record Governance Metadata covers the union of the 16 excluded 'Record Metadata' objects (27 distinct names). "
    "Harmonized: Data / Confidentiality / Access Classification -> Information Classification; Source System Record ID + "
    "Source Record ID -> Source System Record ID; Records Retention Class (03, 13, typed Code) + Record Retention Class (08) "
    "-> Records Retention Rule (Reference (Retention Rule), 08 RET-); Personal Data Classification (04) + Personal Data "
    "Indicator (13) -> Personal Data Sensitivity; Personal Data Category (03) -> Personal Data Category; Source Vendor Dataset "
    "-> Source Dataset (DSET-); Data Owner / Data Steward -> Record Data Owner / Record Data Steward (Reference (Employee), "
    "only where they differ from the object-level assignment). Not carried: Source Servicing Provider (15), External Source "
    "Release (09) and Redistribution Permitted Indicator (11). Recommend CD-006 is marked superseded by CD-148.",
    "CD-148 Data Owner typing in 01-16 was mixed: Reference (Party) in 01, 02, 08, 12, 13, 15, 16; Reference (Employee) in "
    "03, 04, 05, 07, 09, 10, 14; Text in 06, 11. All become Reference (Employee) to 20.",
    "CD-156: 06 'DQ Rule' attributes DQ Rule ID, DQ Rule Description, DQ Dimension and DQ Threshold % are in 21 Data Quality "
    "Rule with names kept; DQ Result % is in 21 Data Quality Result. When applied, remove 'DQ Rule' and its 'DQ Dimension' "
    "list from 06, re-register DQR- to 21 and drop the DQR- overrides in enrich_21.py.",
    "CD-157: Taxonomy Element Registration 'Element Code List' and Business Term 'Governing Code List' reference 09 CLR-; "
    "Governed Scope Type has 'Code List', so code list ownership is assigned in 21. 09 Code List 'Data Owner' / 'Data "
    "Steward' become derived from 21 Data Ownership Assignment at consolidation.",
    "CD-159: AI Use Case 'Model Name' is text; replace with Reference (Model, 37) when 37 is drafted.",
    "CD-160 / data products: every field of data_products/framework.py PRODUCTS, WAVE and RATIONALE and every section of "
    "data_products/CONTRACT.md has a home in 21: Data Product (ID, name, definition, tier, type, owning domain, owner role, "
    "primary and supporting functions, wave, priority, value rationale, dependency note, upstream products, grain, "
    "dimensions, refresh, timeliness, history, classification, PII, delivery, measure / question / DQ rule counts, spec "
    "reference, status) and Data Product Input (inputs). Measures with formulas and business questions stay in the spec "
    "files (counted, referenced); measures certified in the semantic layer are Metric Definitions.",
    "Lineage: element-level lineage (Lineage Source / Target Element) is Text in v0.1; a later tightening could reference the "
    "Data Element Mapping rows of the source and target assets.",
    "Capability-based ownership: Governed Business Capability holds capability IDs (C-LL.NN) from "
    "capability_map/content_capabilities.py as text; C-14.04 to C-14.07 are the capabilities 21 masters.",
    "20 Human Capital Metric Value reads Metric Unit of Measure, Metric Aggregation Rule and Metric Disclosure Frameworks "
    "(ISO 30414, ESRS S1) from 21 Metric Definition.",
]
