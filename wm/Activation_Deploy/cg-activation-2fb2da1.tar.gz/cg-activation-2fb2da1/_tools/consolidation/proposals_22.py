"""Consolidation proposals from Data Domain 22 - Market Data & Pricing (Stage 2 draft v0.1, 2026-10-06).

Proposal fragment only: the builder does not read it. The Stage 2 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py, and applies the derived-copy re-notes to 06, 18 and 19. Formats follow CONTRACT.md.
Decisions implemented: CD-153 / CD-168 (FX rate observations), CD-167 (prices, own-fund row rule), CD-169 option A
(index data keyed by BMK-), CD-170 (fair value), CD-171 (price challenges), CD-147 (pricing operating model).
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones (prefix, entity, owner domain, status, note). None needed.
#    22 uses only the reserved PRICE-, PCHL-, FVD-, FXR- and CURVE- (proposals_stage2_a.py). IDX- stays unused (CD-169
#    option A). Observations, exceptions, overrides, inputs, points, trigger events and memberships are keyed by grain
#    (surrogate numeric keys in examples). Policy, tolerance rule, pricing point and committee codes are firm-defined
#    codes, not enterprise prefixes.
# PREFIX_REGISTRATIONS: move these from Reserved to Registered when 22 is merged.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []
PREFIX_REGISTRATIONS = ["PRICE-", "PCHL-", "FVD-", "FXR-", "CURVE-"]

# Key formats of the prefixes 22 owns (program lead decision 11). Siblings should align their examples at consolidation
# (review C: 23, 26, 27 and 28 use other PRICE- shapes; 27 and 30 use other FVD- shapes).
KEY_FORMATS = [
    ("PRICE-", "PRICE-<price date YYYYMMDD>-<instrument number, 8 digits>-<pricing point number, 2 digits>-<version, 2 digits>", "PRICE-20261005-00104477-01-01"),
    ("PCHL-", "PCHL-<year>-<sequence, 5 digits>", "PCHL-2026-00318"),
    ("FVD-", "FVD-<year>-<sequence, 6 digits>", "FVD-2026-001187"),
    ("FXR-", "FXR-<rate date YYYYMMDD>-<rate type short code>-<base and quote currency>-<tenor or basis code>", "FXR-20261005-WMR16-EURUSD-SP"),
    ("CURVE-", "CURVE-<currency or underlying>-<curve short name>", "CURVE-USD-UST"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local lists in content_22 that carry the exact name and values of an enterprise shared list.
#    Register "22" as a member (identity value_map), or as a direct user and switch the attributes to "Shared: <name>".
#    (shared list name, domain, local list name, attributes that use it)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    ("Record Status", "22", "Record Status", "Pricing Point.Pricing Point Status; Valuation Committee.Committee Status; Curve Definition.Curve Status"),
    ("Approval Status", "22", "Approval Status", "Pricing Policy.Policy Approval Status; Approved Price.Price Approval Status; Price Override.Override Approval Status; Fair Value Determination.Determination Approval Status"),
    ("Case Status", "22", "Case Status", "Price Validation Exception.Exception Workflow Status; Price Challenge.Price Challenge Status"),
    ("Severity", "22", "Severity", "Price Tolerance Rule.Exception Severity Assigned"),
    ("Frequency", "22", "Frequency", "Pricing Point.Pricing Point Frequency"),
    ("Data Provider", "22", "Data Provider", "Pricing Source Hierarchy Rule.Ranked Data Provider (Derived copy of the provider of the ranked 14 dataset)"),
]

# Values to add to shared lists (list, value, description, reason)
SHARED_VALUE_ADDITIONS = [
    ("Data Provider", "S&P Dow Jones Indices", "Index levels, constituents and changes.", "Index data (22 MD-IDX); brief 22 section 8."),
    ("Data Provider", "J.P. Morgan PricingDirect", "Evaluated pricing service.", "Ranked source in fixed income hierarchies."),
    ("Data Provider", "Tradeweb", "Composite and evaluated prices, trade data.", "Ranked source in fixed income hierarchies."),
    ("Data Provider", "MarketAxess", "Composite prices and trade data.", "Ranked source in credit hierarchies."),
    ("Data Provider", "STOXX", "Index data.", "Index levels and constituents."),
    ("Data Provider", "Solactive", "Index data.", "Index levels and constituents."),
    ("Data Provider", "FINRA", "TRACE trade prints.", "Trade Print (TRACE) price source."),
    ("Message Standard", "FIX", "FIX Protocol messages (market data MsgType W, allocations).", "Price and quote feeds; also 25 trading."),
    ("Message Standard", "ISO 20022 reda", "Reference data messages, including reda.001 PriceReport.", "Price report feeds."),
]

# 02 Party Role Type additions (also in CD-179): roles 22 attributes reference.
PARTY_ROLE_TYPE_ADDITIONS = [
    ("02", "Party Role Type", "Pricing Vendor", "Evaluated pricing service, market data vendor or fair value factor vendor (Price Observation source, Price Challenge.Challenged Vendor)."),
    ("02", "Party Role Type", "Index Administrator", "Administrator of an index or interest rate benchmark (Reference Rate Fixing.Rate Administrator; 01 Benchmark Administrator)."),
    ("02", "Party Role Type", "Valuation Agent", "Third-party valuer of private or hard-to-value assets (Fair Value Determination.External Valuation Agent; AIFMD external valuer)."),
    ("02", "Party Role Type", "Quoting Broker", "Broker-dealer giving price quotes used as evidence (Broker Quote Detail.Quoting Broker); may already hold Executing Broker."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: local 22 lists that look like enterprise lists (list, proposed shared name, likely users, note)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Price Type", "Price Type", ["18", "25", "26", "27", "28"],
     "Side or kind of price (official close, bid, ask, mid, evaluated, NBBO midpoint, settlement, NAV per unit, trade print). "
     "25 execution prices and 26 margin valuations need the same vocabulary. Steward 22."),
    ("Price Origin", "Price Origin", ["25", "26", "27", "28"],
     "Where an observed price came from (exchange, vendor, broker, TRACE, administrator, GP statement, counterparty, model). Split "
     "from the draft 'Price Source Type' after review F. Steward 22."),
    ("Approved Price Basis", "Approved Price Basis", ["18", "27", "35"],
     "How an approved value was reached (selected observation, override, fair value determination, fair value factor, own fund NAV, "
     "carried forward, amortized cost, contract value). Replaces 18 Holding Valuation 'Price Source' placeholder (CD-167). 27 "
     "'ABOR Valuation Method' (Market Quotation, Evaluated Price, Fair Value, NAV of Underlying Fund, Amortized Cost, Contract "
     "Value) overlaps it: propose that 27 read its method from 22, or map the two lists."),
    ("FX Rate Basis", None, ["09", "19"],
     "Spot, forward outright, period average, budget. Must agree with 09 FX Rate Type values; 09 could carry the basis on each rate type."),
    ("Fair Value Hierarchy Level", "Fair Value Hierarchy Level", ["27", "30", "32", "35"],
     "ASC 820 / IFRS 13 Levels 1-3 plus NAV Practical Expedient; needed by fund financial statements (27), private markets (30) "
     "and N-PORT (35)."),
    ("Rate Tenor", "Rate Tenor", ["25", "26", "17"],
     "Brief called it 'FX Rate Tenor'; widened because FX observations, reference rate fixings, curve points and surface expiries "
     "use the same tenor codes. 17 'Reference Rate Term' (Text) could adopt it."),
    ("Measure Unit", None, ["30", "31"],
     "Units for tolerance thresholds, valuation inputs and strikes (percent, basis points, multiple, delta). Check against 09 Unit "
     "Category and 18 Quantity Unit before proposing it as shared; candidate only if 31 Investment Risk needs the same."),
    ("Pricing Operating Model", "Operating Model", ["18", "26", "27", "28", "29", "30"],
     "CD-147 values, alongside 18 'IBOR Operating Model'. 22 adds 'Sponsor or Client Priced' for SMAs (SME question 3)."),
    ("Index Level Variant", "Return Type", ["01", "32"],
     "Same three values as 01 'Return Type' (CD-169). Either make 01 Return Type a shared list and register 22, or keep the local "
     "copy under a distinct name, as here."),
    ("Observation Status", None, ["17", "23", "31"],
     "Preliminary / final / corrected / rejected / superseded / withdrawn state of an observed value. Keep separate from Record "
     "Status (lifecycle of master records) and Approval Status."),
    ("Valuation Committee Type", "Committee Member Role / Governance Body Type", ["21", "24", "35", "39"],
     "proposals_24 proposes a shared 'Committee Member Role'; 22 records voting status as a Boolean on Valuation Committee Member and "
     "would use that list if it is created."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS noticed with existing domains (decisions.py format)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Price",
     "usages": [("06", "Transaction.Price", "Dealing price of a shareholder transaction (NAV or offer price)"),
                ("18", "Holding Valuation.Price Used", "Price applied to value a holding (Derived copy of 22)"),
                ("22", "Approved Price (PRICE-)", "Approved unit price of an instrument at a pricing point and date, versioned"),
                ("22", "Price Observation", "Any price received from a source, before approval"),
                ("27", "Share Class NAV", "Net asset value per share of an own fund")],
     "recommendation": "Glossary: 'Approved Price' (22) is the only price used for valuation; 'Price Observation' is evidence; "
                       "'Dealing Price' (06) and 'NAV per Share' (27) are not instrument prices. The 22 Approved Price of an Own "
                       "Fund Share Class is a copy of the 27 NAV (row rule)."},
    {"term": "Valuation",
     "usages": [("01", "Valuation Terms", "Fund valuation frequency, valuation point and pricing model"),
                ("18", "Holding Valuation; Portfolio Valuation Summary", "IBOR estimate of holding and book value"),
                ("22", "Fair Value Determination; Valuation Committee", "Good-faith fair value decision and its governance"),
                ("27", "ABOR Valuation Record; Fund NAV Calculation", "Official book valuation and NAV")],
     "recommendation": "Qualify: 'Valuation Terms' (01), 'IBOR Valuation' (18), 'Fair Value Determination' (22), 'NAV Valuation' "
                       "(27). 22 Pricing Point is read alongside 01 Valuation Point and does not repeat it."},
    {"term": "Index / Benchmark",
     "usages": [("01", "Benchmark (BMK-)", "Benchmark or index definition"),
                ("14", "Index Use", "License to use an index"),
                ("17", "Instrument Relationship to BMK-", "Index as an underlying"),
                ("22", "Index Level Observation / Index Constituent / Index Change Announcement", "Observed index data keyed by BMK-")],
     "recommendation": "CD-169 option A: 01 Benchmark is widened to every index the firm references; 22 creates no index master. "
                       "Glossary: 'Benchmark' = the 01 definition record, whatever its use; 'Index Level' etc. = 22 observations."},
    {"term": "Fair Value",
     "usages": [("18", "Fund Interest Holding Detail.Adjusted NAV", "GP NAV rolled forward (becomes a Derived copy of 22)"),
                ("22", "Fair Value Determination.Fair Value Amount / Fair Value per Unit", "Approved fair value"),
                ("30", "Private Markets valuations (Stage 2)", "Portfolio company and fund valuations")],
     "recommendation": "One fair value per instrument, date and pricing point, mastered in 22 (CD-170); 18 and 30 reference or copy it."},
    {"term": "Challenge / Issue",
     "usages": [("14", "Vendor Data Issue (VDI-)", "Dataset-level issue with a vendor"),
                ("21", "Data Quality Issue (DQI-)", "Enterprise data quality issue"),
                ("22", "Price Challenge (PCHL-)", "Challenge to one vendor price")],
     "recommendation": "CD-171: per-price challenges are 22; systemic vendor problems are 14 VDI-, referenced from the challenge."},
    {"term": "FX Rate",
     "usages": [("06", "Transaction.FX Rate Applied", "Rate used to convert a shareholder transaction to reporting currency"),
                ("09", "FX Rate Type", "Definition of a rate (fixing time, side, convention)"),
                ("18", "Holding FX Rate / Cash FX Rate / Trade FX Rate", "Rates applied in the IBOR"),
                ("19", "Applied Exchange Rate", "Rate applied on GL postings and balances"),
                ("22", "FX Rate Observation (FXR-)", "Observed rate by type, pair, tenor and timestamp"),
                ("25", "Execution (FX trade)", "Rate agreed on an executed FX trade")],
     "recommendation": "CD-168: 09 defines, 22 observes, 18 / 19 / 06 copy; an executed FX trade rate is 25 data, not market data."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. DERIVED_COPY_RENOTES to apply to other domains at consolidation (domain, object, attribute, copy of, decision)
# ---------------------------------------------------------------------------------------------------------------------
DERIVED_COPY_RENOTES = [  # amended after review A / D / F and program lead decisions 3, 5, 6 and 10
    ("18", "Holding Valuation", "Price Used", "22 Approved Price.Approved Price Value", "CD-167"),
    ("18", "Holding Valuation", "Price Date", "22 Approved Price.Price Date (the business date; amend the 18 definition to 'business date of the approved price applied'; the market data date of a carried-forward price is 22 Underlying Market Date)", "CD-167"),
    ("18", "Holding Valuation", "Price Source", "22 Approved Price.Approved Price Basis (list 'Approved Price Basis' replaces the placeholder; amend the 18 definition from 'vendor or method' to 'how the approved price was reached')", "CD-167"),
    ("18", "Holding Valuation", "Holding FX Rate", "22 FX Rate Observation.Spot Rate, its inverse or a cross computed from two observations of the same rate type and timestamp; recommend 18 also carry a reference to the FXR- record(s) used", "CD-168"),
    ("18", "Cash Balance", "Cash FX Rate", "22 FX Rate Observation.Spot Rate, its inverse or a cross computed from it; recommend an FXR- reference", "CD-168"),
    ("18", "Portfolio Transaction", "Trade FX Rate", "22 FX Rate Observation.Spot Rate (or its inverse / cross) for market-rate rows; 25 Execution.Executed FX Rate for executed FX trade rows (row rule)", "CD-168"),
    ("18", "Derivative Holding Detail", "Delta Used", "22 Pricing Analytics Observation.Analytic Measure Value of the row with Approved Analytics Value Indicator = Y and Pricing Analytic Measure = Option Delta", "CD-167"),
    ("18", "Fund Interest Holding Detail", "Adjusted NAV", "22 Fair Value Determination.Fair Value Amount of the approved determination for the same portfolio (Valued Portfolio is mandatory for fund interests); redefine the 18 attribute as 'fair value of the interest approved in 22', since it can include adjustments beyond the roll-forward", "CD-170"),
    ("19", "GL Posting", "Applied Exchange Rate", "22 FX Rate Observation.Spot Rate, or Period Rate for income and expense translated at a period average (FX Rate Basis), or its inverse / cross", "CD-168"),
    ("19", "Account Balance", "Applied Exchange Rate", "22 FX Rate Observation.Spot Rate or Period Rate, or its inverse / cross", "CD-168"),
    ("06", "Transaction", "FX Rate Applied", "22 FX Rate Observation.Spot Rate (proposed; 06 change only if the program lead accepts it)", "CD-168"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Row rule (program lead decision 1, CD-167): on Own Fund Share Class rows Approved Price Value copies 27 Share Class NAV "
    "'NAV per Share' (unswung) from the Share Class NAV record whose parent Fund NAV Calculation is the latest version with NAV "
    "Status 'Final' (Original or Re-Strike) for the latest valuation point at or before the pricing point; Approved Price Currency "
    "copies 27 'NAV Currency'. The swung price, where used, is the separate Own Fund Swung Price (copy of 27 'Swung NAV per Share') "
    "with Own Fund Swing Decision referencing 27 Swing Pricing Decision (SWG-). A 27 Restatement creates a new Approved Price "
    "version (Supersedes Approved Price); the version a NAV used is never overwritten.",
    "Fair value hierarchy level (decision 2): every Approved Price version carries 'Approved Price Fair Value Level'; Fair Value "
    "Determinations are for Level 3 and adjusted quotations. Register 27 and 35 as users of the Fair Value Hierarchy Level list.",
    "ETF market statistics (decision 4): 22 computes and masters ETF Market Statistic (own ETF instrument x date): market price, "
    "premium / discount against the 27 Share Class NAV, and the Rule 6c-11 30-day median bid-ask spread from intraday NBBO data. "
    "35 discloses it and 31 may read it. Log as a CD (owner 22, users 27, 31, 35). This needs 17 to set up an Own Fund Share Class "
    "instrument for every own ETF (17 SME question 5).",
    "CD-187 (proposals_stage2_b) still names the 22 objects 'Security Price' and 'Fair Value Decision'; ask for 'Approved Price' "
    "and 'Fair Value Determination'.",
    "17 hand-backs: prepayment speeds (CPR, CDR, PSA) are Pricing Analytic Measure values; CPI-U, UK RPI and HICPxT levels are "
    "Reference Rate Fixings with Fixing Value Type 'Inflation Index Level', from which the Inflation Index Ratio factor is computed.",
    "IPEV: 22 cites the 2025 edition at privateequityvaluation.com (confirmed by search). 30 cites the December 2022 edition at a "
    "mistyped domain; align 30.",
    "Example key alignment: 22 DSET- examples now use 14's five-digit format; the NAV- example follows 27 (NAV-<date><share class, 6 "
    "digits><version, 2 digits>).",
    "Per-row ownership (plan section 4 item 9): Approved Price Value, Approved Price Currency and Own Fund Swung Price are flagged "
    "Derived copy (27) in enrich_22, and Private Asset Valuation Detail Valuation Basis Date Derived copy (18), each with the row rule "
    "in its definition. If the program lead ratifies a per-object Row Ownership Rule column, move the text there.",
    "Private Asset Valuation Detail.Underlying NAV Used is a Derived copy of 18 Fund Interest Holding Detail 'GP Reported NAV', which "
    "stays mastered in 18 as a received statement value (CD-170).",
    "Valued Portfolio Company was removed after review A: the company is reached through the Fair Valued Instrument's 17 issuer, "
    "and 30 Private Investment references FVD-. Company metrics behind Valuation Inputs are 30 Portfolio Company Financial Metric "
    "records (noted on Input Value); add a reference when 30 gives that record a key.",
    "References to sibling objects use the names in the 27 and 30 briefs and drafts: 'Share Class NAV' (27, NAV-) and 'Portfolio "
    "Company Profile' (30). Confirm against the final 27 and 30 modules.",
    "Once PRICE-, PCHL-, FVD-, FXR- and CURVE- are registered, the ', 22' in 22's own reference types can stay (it is harmless) or "
    "be dropped; resolution is unchanged.",
    "CONCEPT_OWNERSHIP: add ('Approved Price', '22', 'PRICE-', ['18','24','25','26','27','30'], 'Approved instrument price'), "
    "('Fair Value Determination', '22', 'FVD-', ['18','27','30','35'], 'Good-faith fair value decision'), ('FX Rate Observation', "
    "'22', 'FXR-', ['06','18','19','25','26','27'], 'Observed FX rate'), ('Price Challenge', '22', 'PCHL-', ['14'], ''), "
    "('Curve Definition', '22', 'CURVE-', ['26','31'], ''). Do not add a bare 'Price' alias.",
    "CD-169 dependency: Index Level Observation, Index Constituent and Index Change Announcement reference 01 Benchmark (BMK-). "
    "This needs the deferred Stage 1 item to widen 01 Benchmark to every index used as an underlying, research index or curve "
    "input. If 01 declines, apply option B (22 Index Reference, IDX-) and re-type these three references.",
    "Vendor identity (decision 8): observations and hierarchy ranks identify the vendor by 14 Dataset (DSET-); Ranked Data Provider "
    "is a Derived copy (14) of the dataset's provider; broker quotes keep the 02 party. The Message Standard and Data Basis lists named in the brief are not used: the "
    "feed format is 06 / 14 metadata, and the estimated-vs-actual question is answered by Observation Status and Unobservable "
    "Input Indicator. The proposed FIX and ISO 20022 reda values are still useful to 25 and 27.",
    "21 may catalog tolerance checks as Data Quality Rules: Price Tolerance Rule.Cataloged Data Quality Rule references DQR-; "
    "21 should not restate thresholds (CD-171).",
    "'Valuation Model Name' on Fair Value Determination is text until 37 (model inventory) exists; then re-type it as a reference.",
]
