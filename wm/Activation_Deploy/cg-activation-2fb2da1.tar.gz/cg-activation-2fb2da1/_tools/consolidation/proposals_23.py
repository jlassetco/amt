"""Consolidation proposals from the Data Domain 23 (Investment Research) draft, 2026-10-06.

Proposal fragment only: the builder does not read this file. The Stage 2 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Formats follow CONTRACT.md in this folder. Decisions implemented: CD-172, CD-173,
CD-174 (proposals_stage2_a.py); working assumption CD-143 / CD-179 (research providers and expert networks are 02 parties).
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES  (prefix, entity, owner domain, status, note) - decisions.PREFIXES format
# Only the four prefixes reserved in proposals_stage2_a.py are used: RCOV-, RREC-, RPUB-, IMTG-. Universes, research
# models and signals use plain codes without a hyphenated prefix (e.g. USLC_FOCUS, RM_EQ_TECH_0412_DCF, SIG_VALUE_COMP), with versions as separate attributes;
# every other object is keyed by grain, and the research provider profile by 02 PTY-.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: 23 local lists that copy an enterprise shared list by name (values are a subset). Register 23
#    as a member (or direct user) and apply the value_map. No new values are needed.
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Record Status", "local": "Record Status",
     "value_map": {"Draft": "DRAFT", "Active": "ACTIVE", "Inactive": "INACTIVE", "Deprecated": "DEPRECATED", "Retired": "RETIRED"},
     "new_values": []},
    {"shared": "Approval Status", "local": "Approval Status",
     "value_map": {"Not Required": "NOT_REQUIRED", "Pending": "PENDING", "Approved": "APPROVED",
                   "Approved with Conditions": "APPROVED_WITH_CONDITIONS", "Rejected": "REJECTED", "Expired": "EXPIRED",
                   "Withdrawn": "WITHDRAWN"},
     "new_values": []},
    {"shared": "Period Type", "local": "Period Type",
     "value_map": {"Quarter": "QUARTER", "Half-Year": "HALF_YEAR", "Year": "YEAR",
                   "Rolling / Trailing 12 Months": "ROLLING_12_MONTHS"},
     "new_values": [],
     "note": "Used for issuer fiscal periods (Analyst Estimate), forecast periods and provider evaluation periods."},
    {"shared": "Sentiment", "local": "Sentiment",
     "value_map": {"Positive": "POSITIVE", "Neutral": "NEUTRAL", "Negative": "NEGATIVE", "Mixed": "MIXED", "Unknown": "UNKNOWN"},
     "new_values": []},
    {"shared": "Information Classification", "local": "Information Classification",
     "value_map": {"Internal": "INTERNAL", "Confidential": "CONFIDENTIAL",
                   "Confidential - Personal Data": "CONFIDENTIAL_PERSONAL_DATA", "Confidential - Licensed": "CONFIDENTIAL_LICENSED",
                   "Restricted": "RESTRICTED", "Restricted - MNPI": "RESTRICTED_MNPI", "Public": "PUBLIC"},
     "new_values": [],
     "note": "Publication Classification and Meeting Notes Classification; meeting notes are set to Restricted - MNPI "
             "when the Meeting MNPI Assessment requires it."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: 23 local lists that look like enterprise lists  (list, [domains], note)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Internal Credit Rating Scale", ["23", "31", "33"],
     "Firm credit scales (and the Internal Credit Rating values) will be read by 33 compliance limits and 31 risk. "
     "Steward 23 (Head of Credit Research); register the mapping to the 17 Normalized Credit Rating Notch."),
    ("Internal Credit Rating", ["23", "31", "33"],
     "Firm-defined values per scale (ICR 1-10, D; ST1-ST3) are placeholders pending SME question 2/3."),
    ("Credit Outlook", ["17", "23"],
     "Four of the five values of 17 'Credit Rating Outlook' (23 leaves out 'Not Assigned', because an internal outlook is always "
     "assigned). Propose one shared 'Credit Outlook' list (agency and internal) with 'Not Assigned' allowed for agency rows only."),
    ("Research Subject Type", ["23", "24", "34"],
     "Issuer / Instrument / Sector / Country / Rates Market / Theme; 34 engagements and 24 decision rationales may classify subjects the same way."),
    ("Meeting Channel", ["03", "12", "23", "34"],
     "In Person / Video / Telephone. 03 Activity Type mixes channel with activity kind; a shared channel list would help 03 and 34."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (decisions.TERM_CONFLICTS format). Extends the 'Research' and 'Coverage' entries already in
#    proposals_stage2_a.py and the 'Rating' entry (CD-173).
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Rating",
     "usages": [("23", "Research Recommendation: Recommendation Rating", "Analyst's buy / hold / sell or overweight / underweight view on a firm scale"),
                ("23", "Internal Credit Assessment: Internal Credit Rating", "Firm's own credit rating of an issuer or instrument"),
                ("17", "Credit Rating Assignment", "Agency credit rating"),
                ("11", "Rating Observation / Manager Rating", "Third-party ratings of funds and managers"),
                ("05", "Partner Research Rating", "Distributor's rating of the firm's funds"),
                ("03", "Consultant Rating", "Consultant's rating of a strategy")],
     "recommendation": "Never use 'Rating' bare. 'Recommendation Rating' and 'Internal Credit Rating' (23), 'Agency Credit Rating' (17), "
                       "'Fund Rating' (11), 'Partner Research Rating' (05), 'Consultant Rating' (03) (CD-173)."},
    {"term": "Recommendation",
     "usages": [("23", "Research Recommendation", "Analyst view on a subject; input to investment decisions"),
                ("05", "Shelf Placement (recommended list status)", "Distributor's recommended list"),
                ("24", "Decision Rationale: Linked Research Recommendation", "Reference to 23")],
     "recommendation": "'Research Recommendation' (23) vs 'Recommended List Status' (05). EU MAR 'investment recommendation' applies "
                       "only to an externally released 23 publication (Publication Review)."},
    {"term": "Model",
     "usages": [("23", "Research Model", "Analyst valuation, credit, macro or signal model held as a research record"),
                ("01", "Model Portfolio", "Model delivered to SMA / UMA sponsors as a product"),
                ("24", "Target Allocation Set (model targets)", "Intended model weights"),
                ("37", "Model inventory (planned)", "Model risk management inventory")],
     "recommendation": "Always qualify: 'Research Model' (23), 'Model Portfolio' (01), 'Model Risk Inventory Entry' (37). "
                       "23 flags Model Inventory Candidate Indicator for models 37 must register."},
    {"term": "Universe",
     "usages": [("23", "Research Universe", "Focus, coverage, approved research and signal lists"),
                ("11", "Peer Universe", "Peer funds compared with own strategies"),
                ("03", "Database Profile: Database Universe", "Consultant database universe")],
     "recommendation": "Qualify: 'Research Universe' (23), 'Peer Universe' (11), 'Consultant Database Universe' (03)."},
    {"term": "Coverage Role",
     "usages": [("23", "Research Coverage Assignment: Research Coverage Role (list 'Research Coverage Role')", "Analyst's role on a research subject"),
                ("07", "Coverage Role (list)", "Salesperson's role on a party")],
     "recommendation": "Resolved in the 23 draft: the 23 list and attribute are named 'Research Coverage Role'; 07 keeps 'Coverage Role'. Do not merge."},
    {"term": "Evaluation",
     "usages": [("23", "Research Evaluation Round / Evaluation Criterion Score", "Broker vote: provider x period x evaluator, scored by criterion"),
                ("22", "Evaluated Price Detail / Evaluation Method", "Evaluated pricing of instruments"),
                ("14", "Vendor Performance Review", "Data vendor review")],
     "recommendation": "'Research Evaluation Round' (23) is not an evaluated price (22) or a data vendor review (14)."},
    {"term": "Meeting",
     "usages": [("23", "Issuer Meeting (IMTG-)", "Meeting with issuer management"),
                ("03", "Sales Activity (Activity Type 'Meeting')", "Meeting with a client or prospect"),
                ("22", "Valuation Committee Meeting", "Pricing and fair value governance meeting"),
                ("24", "Investment Committee Meeting", "Investment committee meeting"),
                ("35", "Board meeting (planned, MTG-)", "Governance meeting")],
     "recommendation": "'Issuer Meeting' (23) is never a 03 Sales Activity (CD-172); qualify committee meetings as 'Valuation Committee Meeting' (22) and 'Investment Committee Meeting' (24)."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------------------
# 5. KEY FORMATS owned by 23 (for siblings to adopt at consolidation)
# ---------------------------------------------------------------------------------------------------------------------
KEY_FORMATS = [
    ("RREC-", "RREC- followed by seven digits, e.g. RREC-0091377", "24 Decision Rationale example 'RREC-2026-004512' should adopt this format."),
    ("RCOV-", "RCOV- followed by six digits, e.g. RCOV-000412", ""),
    ("RPUB-", "RPUB- followed by seven digits, e.g. RPUB-0045512; the version is a separate attribute", ""),
    ("IMTG-", "IMTG- followed by seven digits, e.g. IMTG-0012874", ""),
    ("Research Evaluation Round", "Composite key: provider PTY- / evaluation period end date / evaluator EMP-, e.g. 'PTY-1003320 / 2026-06-30 / EMP-30412'",
     "25 Research Payment.Provider Evaluation should become Reference (Research Evaluation Round, 23) with this key (its example uses '2026-H1')."),
    ("Internal Credit Assessment", "Composite key: assessed party PTY- (and instrument INS- if issue-level) / credit analyst EMP- / internal credit rating scale / effective date",
     "25 Counterparty Review.Credit View example should add the rating scale."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. PROPOSED_TO_38: MNPI control fields removed from 23 (brief §4 rule 5, review finding A) for 38 (Stage 4) to master
# ---------------------------------------------------------------------------------------------------------------------
PROPOSED_TO_38 = [
    ("Compliance MNPI Determination", "Whether Compliance confirmed that the information received in an issuer meeting is MNPI.", "Keyed by the 23 MNPI Escalation Reference and IMTG-."),
    ("Compliance Reviewer", "Compliance officer who reviewed the MNPI declaration (PII, employee).", ""),
    ("Compliance Notified Timestamp", "Date and time Compliance was told that MNPI may have been received.", ""),
    ("Market Sounding Indicator", "Whether the meeting was a market sounding under EU or UK MAR Art 11.", "23 keeps per-participant wall-crossing consent and timestamp."),
    ("Expected Cleansing Date / Cleansed Date", "When the information is expected to become, and was confirmed, public or no longer material.", ""),
    ("Expert Network Due Diligence", "Compliance due diligence on expert networks' MNPI controls (23 holds only the last date, noted 'future owner 14 or 38').", ""),
]

NOTES = [
    "Review response (2026-10-06): Research Provider Evaluation was split into Research Evaluation Round (provider x period x "
    "evaluator: overall score, vote allocation share, approval) and Evaluation Criterion Score (round x criterion). 25 Research "
    "Payment should reference the round (KEY_FORMATS).",
    "Research Recommendation 1 : 0..n Investment Decision [24]: a recommendation informs many decisions; 24 holds the single "
    "Linked Research Recommendation. 24 should adopt the RREC- format in KEY_FORMATS.",
    "Price at Recommendation is a Derived copy (22): the Approved Price Value for the recommended instrument at the firm's primary "
    "pricing point and the recommendation date; the PRICE- example follows 22's format (PRICE-yyyymmdd-instrument-nn).",
    "Research Payment Route and the copied 25 'Research Payment Source' list were removed (CD-174); 25 Research Payment holds the route.",
    "Internal Credit Assessment's subject is now Assessed Party (issuer or trading counterparty, PTY-), so 25 Counterparty Review "
    "can read it for counterparties without a 17 Issuer Profile.",
    "House View Indicator was removed: house views are 24 Investment Committee Decisions. Rates and country views remain analyst "
    "recommendations (Research Subject Type 'Rates Market' and 'Country') that inform 24.",
    "Wall crossing (consent and timestamp) moved to Issuer Meeting Participant, per person; Meeting MNPI Assessment keeps only "
    "the MNPI Received Indicator and the MNPI Escalation Reference. See PROPOSED_TO_38.",
    "The 'Money Market Eligible List' universe type was removed; the eligible list is a view of Internal Credit Assessments in force "
    "with Minimal Credit Risk Indicator = Y. 33 should read the assessments.",
    "Research Provider Type now holds the business model only; the research specialty is a separate list 'Research Specialty'.",
    "Row Ownership Rule (plan §4 item 9): Recommended Issuer and Assessed Party are derived from the 17 Instrument issuer on rows "
    "with an instrument, and entered otherwise; both stay References to 02.",
    "30: the relationship to 30 Due Diligence Workstream is proposed; content_30 does not yet reference RPUB-.",
    "CD-147: the optional 'Research Management System' attribute on Research Publication was not added; the system of "
    "record is SME question 1 and belongs in the 21 data catalog once known.",
    "CD-179: ask 02 to add Party Role Type values 'Research Provider', 'Expert Network' and 'Corporate Access Provider' "
    "(the last is new from 23; it may be covered by 'Research Provider').",
    "34 (Stage 3): Issuer Meeting Topic.Stewardship Objective Indicator is the hand-off flag for 34 Engagement.",
    "Private credit: an internal credit view of a private credit loan needs the loan as a 17 instrument; see SME question 7.",
]
