"""Consolidation proposals from Data Domain 24 - Portfolio Management & Construction (Stage 2 draft v0.1, 2026-10-06).

Proposal fragment only: the builder does not read it. The Stage 2 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Format follows CONTRACT.md in this folder. Decisions implemented: CD-145, CD-175
(drafted under option B, see NOTES), CD-176, CD-177, CD-178 and CD-180 in proposals_stage2_a.py.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones (prefix, entity, owner domain, status, note). None needed.
#    24 uses only the reserved IDEC-, TGT-, RBAL- and BSKT- (proposals_stage2_a.py). Committees are keyed by a short
#    committee code; meetings, committee decisions, assignments, policies, lines, constraints, pacing plans, results,
#    proposed trades, lot selections, tax budgets, forecasts and adjustments are keyed by their grain.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# Key formats of the reserved prefixes, as 24 issues them (29 adopts the BSKT- format at consolidation):
KEY_FORMATS = [
    ("BSKT-", "BSKT-YYYYMMDD-nnnnn", "Basket date and a five-digit daily sequence, e.g. BSKT-20261006-00031. The share class is an "
     "attribute of the basket, not part of the key; 29 examples such as 'BSKT-SHC008801-20261005-C' should change to this format."),
    ("IDEC-", "IDEC-YYYY-nnnnnnn", "Year and sequence, e.g. IDEC-2026-0088412."),
    ("TGT-", "TGT-nnnnnnnn", "Sequence, e.g. TGT-00041207."),
    ("RBAL-", "RBAL-YYYY-nnnnnn", "Year and sequence, e.g. RBAL-2026-001877."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local 24 lists that are verbatim copies of enterprise shared lists (same name, same values).
#    Register "24" as a member (or direct user) of each so the builder replaces the local copy with "Shared: <name>".
#    (shared list name, local list name in 24, where 24 uses it)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    ("Record Status", "Record Status", "Investment Committee status, Asset Allocation Policy status, Portfolio Construction Constraint status"),
    ("Approval Status", "Approval Status", "Portfolio Management Assignment, Target Allocation Set, Commitment Pacing Plan, Custom Basket Approval"),
    ("Frequency", "Frequency", "Committee meeting frequency, policy rebalance frequency"),
    ("Period Type", "Period Type", "Commitment Pacing Plan period"),
    ("Data Basis", "Data Basis", "Cash Forecast Adjustment basis"),
    ("Flow Direction", "Flow Direction", "Cash Forecast Adjustment direction (Inflow / Outflow only; Neutral unused, as in 18)"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: local 24 lists that look like enterprise lists.
#    (list name in 24, proposed shared list name, likely other users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Instrument Asset Class", "Asset Class", ["01", "17", "31", "32", "33"],
     "24 copies the 17 'Instrument Asset Class' values exactly (policy lines, glide path points, tactical views, target lines). "
     "01 has a different local 'Asset Class' (Equity, Fixed Income, Multi-Asset, Money Market, Real Estate, Private Equity, "
     "Private Credit, Infrastructure, Hedge / Absolute Return, Commodities, Other) on strategies and products. Make one enterprise "
     "list stewarded by 17 (or 09), map the 01 values, and register 01, 17 and 24 as members."),
    ("Basket Type", "ETF Basket Type", ["06", "29", "35"],
     "06 'ETF Basket Type' (In-Kind, Cash, Custom Basket, Hybrid) mixes settlement form with the Rule 6c-11 standard / custom "
     "distinction. 24 'Basket Type' holds only Standard / Custom (per 6c-11(a)); 29 already defines 'Basket Settlement Form' "
     "(In-Kind, Cash, Hybrid). Map 06 In-Kind / Cash / Hybrid to the 29 list and 06 'Custom Basket' to 24 Custom, and share "
     "the 24 list with 29 and 35."),
    ("Business Line", "Business Line", ["18", "24"],
     "Same six values as 18 (deferred shared-list candidate; see proposals_18). 21 'Business Line' has eight values (adds "
     "Institutional Mandate and Proprietary / Seed) and 01 has a different list with the same name (client segments): resolve "
     "both name clashes before sharing. 24 uses it for the committee remit."),
    ("Committee Decision Outcome", "Approval Status", ["24"],
     "NOT_MERGED candidate: Approved, Approved with Conditions and Rejected map one to one to the shared Approval Status; "
     "Deferred and Noted have no Approval Status equivalent, which is why the local list is kept."),
    ("Investment Decision Cause", None, ["24", "25"],
     "Map, do not merge: 24 Rebalance Trigger (Drift, Scheduled -> Rebalance to Target; Cash Flow -> Client Flow; Model "
     "Change, Policy Change -> Model Change / Committee View; Index Change -> Index Change; Tax Harvest -> Tax Management; "
     "Transition, Client Restriction Change, Manager Initiated -> no single cause) and 25 Order Reason (New Investment -> "
     "Fundamental Research or Valuation; Rebalance -> Rebalance to Target; Subscription / Redemption Cash Flow -> Client Flow; "
     "Model Change -> Model Change; Index Rebalance -> Index Change). The action (Initiate, Add, Trim, Exit, Switch, Reweight, "
     "Hedge) is the separate 24 Investment Decision Action list."),
    ("Lot Relief Method", "Lot Relief Method", ["18", "24"],
     "24 'Lot Relief Method' is a verbatim copy of 18's list, used for the lot selection method on a proposed trade. Steward 18; "
     "register 24 as a member. Keep NOT_MERGED against 15 'Cost Basis Method' as proposals_18 says."),
    ("Portfolio Management Role", None, ["01"],
     "Under option A of CD-175 this list replaces 01 'PM Role' (its first three labels are the 01 values). Under option B keep "
     "both and map 01 Lead / Co-Manager / Associate / Deputy one to one."),
    ("Proposed Trade Side", "Trade Side", ["25", "18"],
     "Aligned to FIX Side (tag 54). 25 Trade Order will need the same values; one shared list stewarded by 25."),
    ("Committee Member Role", "Committee Member Role", ["21", "22", "35", "39"],
     "21 governance bodies, 22 valuation committee, 35 fund boards and 39 corporate governance will all record committee "
     "membership roles; consider one enterprise list."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS noticed with existing domains (decisions.py format)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Target",
     "usages": [("01", "Target Market", "MiFID II product governance target market of a product"),
                ("07", "Goal / Sales Target", "Sales goal or quota of a salesperson or territory"),
                ("24", "Target Allocation Set / Target Allocation Line / Target Weight", "Intended weights of a portfolio or model")],
     "recommendation": "Never use 'Target' bare in the glossary: 'Target Market' (01), 'Sales Goal' (07), 'Target Allocation' / "
                       "'Target Weight' (24)."},
    {"term": "Allocation",
     "usages": [("24", "Asset Allocation Policy / Target Allocation", "Intended split of a portfolio across asset classes or components"),
                ("25", "Trade Allocation (ALLOC-)", "Split of an executed block across portfolios or accounts"),
                ("07", "Credit Allocation (CRA-)", "Split of sales credit across salespeople"),
                ("10", "Allocation Method (ALM-)", "Cost allocation method"),
                ("30", "Deal Allocation", "Split of a private markets deal across funds, parallel funds and co-investors")],
     "recommendation": "Always qualify: 'Asset Allocation' and 'Target Allocation' (24), 'Trade Allocation' (25), 'Credit "
                       "Allocation' (07), 'Cost Allocation' (10), 'Deal Allocation' (30)."},
    {"term": "Decision",
     "usages": [("21", "Governance Decision (CD-)", "Decision about data, the taxonomy or governance"),
                ("24", "Investment Decision (IDEC-)", "Decision to change a portfolio or model"),
                ("24", "Investment Committee Decision", "Decision item of an investment committee meeting"),
                ("22", "Fair Value Determination (FVD-)", "Valuation committee decision on a fair value")],
     "recommendation": "Never 'Decision' bare: 'Governance Decision' (21), 'Investment Decision' (24), 'Investment Committee "
                       "Decision' (24), 'Fair Value Determination' (22)."},
    {"term": "Model",
     "usages": [("01", "Model Portfolio (MDL-)", "Model offered to sponsors or followed by portfolios"),
                ("23", "Research Model", "Analyst valuation or credit model"),
                ("24", "Target Allocation Set with subject Model Portfolio", "The model's weights over time (CD-176)"),
                ("37", "Model inventory (Stage 4)", "Model risk management inventory")],
     "recommendation": "'Model Portfolio' (01) for the offering, 'Model Weights' or 'Model Target Allocation' (24) for its "
                       "weights, 'Research Model' (23), 'Quantitative Model' (37)."},
    {"term": "Basket",
     "usages": [("06", "ETF Creation / Redemption.Basket Type", "Settlement form of a primary-market flow (In-Kind, Cash, Custom Basket, Hybrid)"),
                ("24", "ETF Basket (BSKT-)", "Composition of a creation or redemption basket for a share class and date"),
                ("25", "List / program order (Stage 2)", "Trading 'basket' of orders sent together")],
     "recommendation": "'ETF Basket' is reserved for the 6c-11 creation / redemption basket (24). 25 should say 'Program Trade' or "
                       "'List Order', not basket. Split the 06 list as in SHARED_CANDIDATES."},
    {"term": "Portfolio Manager Assignment",
     "usages": [("01", "Portfolio Manager Assignment", "Disclosed portfolio managers of a product or mandate (Form N-1A Item 5)"),
                ("01", "Investment Strategy.Lead Portfolio Manager / Investment Team", "Lead manager and team of a strategy"),
                ("24", "Portfolio Management Assignment", "Operational assignment of managers and teams to 18 portfolios")],
     "recommendation": "CD-175. Option A: one object, 'Portfolio Manager Assignment', moved to 24. Option B (drafted): keep both, "
                       "with distinct names, and reconcile 01 rows to 24 rows through the 18 implementation link."},
    {"term": "Committee",
     "usages": [("21", "Governance Body", "Data governance council or committee"),
                ("22", "Valuation Committee", "Fair value and pricing oversight"),
                ("24", "Investment Committee", "House views, allocation and glide path decisions")],
     "recommendation": "Qualify every committee by kind; a later 39 Legal & Corporate Governance domain may master a generic "
                       "committee register with these as profiles."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "CD-175 drafted under option B (program lead instruction, 2026-10-06): 01 'Portfolio Manager Assignment' is unchanged and "
    "holds the disclosure (role and length of service as disclosed under Form N-1A Item 5). 24 masters only the operational "
    "'Portfolio Management Assignment' at portfolio grain (Assigned Portfolio PORT-, Assigned Manager EMP-, Assigned Investment "
    "Team OU-, Portfolio Management Role, effective period); 24 cites no N-1A requirement and holds no disclosed facts (the "
    "former Prospectus Disclosed Indicator was removed after review). Proposed consolidation check: every 01 Portfolio Manager "
    "Assignment row must match an active 24 assignment of the same employee, in a role of the same label, to a portfolio that "
    "implements that product or mandate (18 Implements Product / Implements Mandate); differences in dates are allowed and "
    "reported, differences in role are reported for review (sleeve managers legitimately differ). The join needs 01 to re-type "
    "Portfolio Manager from Reference (Party) (PTY- example, forced to 20 by enrich_01) to Reference (Employee) with an EMP- "
    "example: an open 01 item. 01 Investment Strategy 'Lead Portfolio Manager' remains a third record of who manages what "
    "under option B. If option A is chosen instead: move the 01 object here with its names, add product / mandate references "
    "for the disclosed rows, rename this object back to 'Portfolio Manager Assignment', and make 01 'Lead Portfolio Manager' "
    "a Derived copy (24).",
    "CD-180 clarification: the link from proposal to order is held once, by 25 (Trade Order 'Originating Proposed Trade', with "
    "Order Created Timestamp and Order Originator). 24 removed Released Trade Order, Release Timestamp and Released By; it keeps "
    "only Proposed Trade Status 'Released'. 24 Proposed Trade now has a system key 'Proposed Trade ID' (no prefix, e.g. "
    "2026100500143) issued for run-generated and manual proposals alike; 25 'Originating Proposed Trade' examples ('RBAL-... / "
    "line 14') should use it. Manual proposals carry 'Originating Investment Decision' so the MiFIR trail does not break.",
    "Investment decisions may cover several portfolios or models through 'Investment Decision Scope' rows (decision x portfolio "
    "or model); a 25 Trade Order references one IDEC- and its own portfolio, which must be one of the decision's scope rows.",
    "CD-205 hand-off with 30: 24 owns the investment committee decision for private deals (Committee Decision Type 'Private "
    "Investment Approval' / 'Private Investment Exit Approval', Decision Scope Deal = Reference (Deal, 30)). 30 Deal also "
    "references the 24 decision ('Investment Committee Decision'), and 30 Ownership Period references follow-on and exit "
    "decisions. Keep one direction at consolidation (recommended: 30 keeps its references, which carry the business meaning of "
    "initial vs follow-on / exit approval; 24 Decision Scope Deal then becomes a Derived copy or is dropped). Deal Allocation "
    "across funds is 30's.",
    "Prefix register: add IDEC-, TGT-, RBAL- and BSKT- (owner 24) to decisions.PREFIXES as Registered, with the KEY_FORMATS "
    "above. Own-object references are typed 'Reference (<Object>, 24)' so they resolve now.",
    "OWNERSHIP_OVERRIDES in enrich_24.py: four own-object references are forced to 'mastered here' because their composite "
    "example keys start with an 01 STR- or 18 PORT- value (Line Allocation Policy, Glide Path Policy, Governing Allocation "
    "Policy, Adjusted Cash Forecast); they go away if the asset allocation policy and the forecast get their own keys. The 22 "
    "index change reference is forced to 22 because its key starts with an 01 BMK- value.",
    "CONCEPT_OWNERSHIP: add ('Investment Decision', '24', 'IDEC-', ['25','32','33','35'], 'Decision to change portfolios or "
    "models'), ('Target Allocation Set', '24', 'TGT-', ['01','25','31','32','33'], 'Versioned targets of a portfolio or model'), "
    "('Rebalance Run / Proposed Trade', '24', 'RBAL-', ['25','33'], ''), ('ETF Basket', '24', 'BSKT-', ['29','35','06'], "
    "'Rule 6c-11 creation / redemption basket'), ('Investment Committee / Investment Committee Decision', '24', '', "
    "['22','30','35'], '').",
    "Hand-offs other domains make: 25 Trade Order references Investment Decision (IDEC-) and Proposed Trade (Proposed Trade "
    "ID); 29 AP Creation / Redemption Order references ETF Basket (BSKT-) and holds the actual cash per order, and 29 Basket "
    "Settlement Line references ETF Basket Constituent; 30 Deal and Ownership Period reference Investment Committee Decision; "
    "33 pre-trade checks reference Proposed Trade; 32 attribution reads Target Allocation Sets; 35 ETF disclosure reads ETF Basket.",
    "ETF basket cash (CD-177, program lead decision): Basket Balancing Amount is the one estimated cash fact, mastered here as "
    "the Rule 6c-11(a) cash balancing amount; the former Estimated Cash Component (Derived copy 27) was removed. NAV per "
    "Creation Unit is computed here as 27 Share Class NAV 'NAV per Share' x 01 Creation Unit Size and flagged Derived copy (27). "
    "29 holds the actual cash per AP order.",
    "Asset allocation policy (program lead decision): Neutral Weight is a Derived copy (01) of the component weight in the 01 "
    "Benchmark 'Blend Components' of the policy benchmark, and Line Proxy Benchmark is the matching component; row rule: "
    "mastered here only for a policy with no blended policy benchmark. 01 should keep blend weights effective-dated so the "
    "copy can follow policy versions. A policy may now be held for an 01 model portfolio (target-date model series on 16 "
    "recordkept plan menus).",
    "22 index changes: referenced through the child object 'Rebalance Index Change Trigger' (one row per announced change), "
    "keyed as 22 keys Index Change Announcement: benchmark x instrument x change type x effective date (no prefix).",
    "Derived copies from 18 (CD-178): Opening Cash (Cash Balance) and Projected Cash Net (all Projected Cash Movement sources, "
    "including capital activity) and Tax Budget Realized Gain to Date (Lot Relief). The former Capital Activity Net term was "
    "removed so capital activity is counted once; Cash Forecast Adjustment sources are limited to items not yet in 18. 24 "
    "creates no projected cash.",
    "Decision Supervising Branch Country (RTS 22 field 58) is a Derived copy (20) of the decision maker's work assignment; 20 "
    "should confirm it holds the work location or legal entity needed.",
    "Target classification lines reference the 09 classification scheme register (ICS-) through Target Classification Scheme, "
    "as 17 does; glide path and policy sub-classes use level 2 of the 17 firm asset-class scheme.",
    "CD-176 gap: a model delivery event (version sent to sponsor X at time T) belongs to 01; 24 marks the version with Sponsor "
    "Publication Indicator and Sponsor Release Timestamp only. Record the 01 gap in gaps_register.",
    "01 boundary: Model Portfolio Rebalance Frequency and Model Delivery Method are not repeated; ETF Characteristics Creation "
    "Unit Size is copied (Derived copy 01) onto ETF Basket; Replication Method is read, not copied.",
    "Client and account restrictions (02 CRX-, 15 ARX-) are applied per portfolio at proposal (relationship on Rebalance "
    "Portfolio Result) and never copied; 15 ARX- rows are account trading blocks, 02 CRX- rows are investment customizations.",
    "Realized gain limits are held once, on Tax Budget; the constraint value 'Realized Gain Limit' was removed.",
    "Business Line: 24 keeps a local copy of the six values (as 18) until the deferred shared list is created.",
]
