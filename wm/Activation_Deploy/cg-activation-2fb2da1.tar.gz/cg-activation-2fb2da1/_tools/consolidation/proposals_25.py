"""Consolidation proposals from Data Domain 25 - Trading & Execution (Stage 2 draft v0.1, 2026-10-06).

Proposal fragment only: the builder does not read it. The Stage 2 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Format follows CONTRACT.md in this folder. Decisions implemented: CD-143 (working
assumption), CD-147, CD-168, CD-174, CD-179, CD-180 and CD-184 (proposals_stage2_a.py).
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones (prefix, entity, owner domain, status, note). None needed.
#    25 uses only the reserved TORD-, BLOCK-, EXEC-, ALLOC- and TCA- (proposals_stage2_a.py). Every other record is keyed
#    by its grain. Trade Error and New Issue Offering carry an internal reference without a hyphenated prefix
#    ("TE 2026/0042", "NI 2026/0117"); broker IDs in examples are written without hyphens so they do not look like prefixes.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# Registration of the reserved prefixes once accepted (decisions.PREFIXES format):
PREFIXES_TO_REGISTER = [
    ("TORD-", "Trade order (portfolio-level securities or FX order)", "25", "Registered", "Stage 2 (CD-180)."),
    ("BLOCK-", "Block order (aggregated for execution; a block of one when not aggregated)", "25", "Registered", "Stage 2."),
    ("EXEC-", "Execution (fill, correction or cancellation)", "25", "Registered", "Stage 2."),
    ("ALLOC-", "Trade allocation (block or internal cross x broker x trade order x portfolio or SMA account)", "25", "Registered", "Stage 2 (CD-180); 18 Source Allocation ID and 26 confirmations reference it."),
    ("TCA-", "Transaction cost analysis result", "25", "Registered", "Stage 2."),
]

# CONCEPT_OWNERSHIP rows (decisions.py format). Grain-keyed objects have a blank prefix; the counterparty profile is keyed
# by PTY- but registers no prefix, so the resolver never reads a PTY- example as 25.
CONCEPT_OWNERSHIP = [
    ("Trade Order", "25", "TORD-", ["18", "24", "26", "33", "38"], "Portfolio-level securities or FX order; never 'Order' bare (CD-180)"),
    ("Block Order", "25", "BLOCK-", ["26", "38"], "Orders aggregated for execution"),
    ("Execution", "25", "EXEC-", ["18", "22", "26", "33", "38"], "Fill received from a broker or venue; source of the executed FX rate (CD-168)"),
    ("Trade Allocation", "25", "ALLOC-", ["18", "26", "27"], "Allocation of executed or crossed quantity to a portfolio or SMA account (CD-180)"),
    ("Approved Counterparty Profile", "25", "", ["26", "31", "33"], "Trading role profile on a 02 party, keyed by PTY- (CD-179)"),
    ("Counterparty Approval Scope", "25", "", ["26", "31"], "Approved activity per counterparty, trading entity and fund"),
    ("Counterparty Trading Limit", "25", "", ["31"], "Approved trading limit per counterparty; usage measured by 31"),
    ("Counterparty Review", "25", "", ["23", "31"], "Periodic and event-driven counterparty review"),
    ("Research Payment", "25", "", ["19", "23"], "Payment to a research provider for a period (CD-174)"),
    ("TCA Result", "25", "TCA-", ["32", "33"], "Transaction cost analysis result"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local lists in content_25 that are exact copies of enterprise shared lists. Register 25 as a
#    direct user, or as a member with an identity value_map (every local value maps to the shared code of the same label),
#    then delete the local copy. (shared list name, local list name in 25, note)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    ("Approval Status", "Approval Status", "Cross Trade, New Issue Allocation fairness review, Research Budget. Values identical."),
    ("Record Status", "Record Status", "Commission Sharing Arrangement status. Values identical."),
    ("Case Status", "Case Status", "Trade Error status. Values identical."),
    ("Severity", "Severity", "Trade Error severity. Values identical."),
    ("Frequency", "Frequency", "Counterparty review frequency. Values identical."),
    ("Regulator", "Regulator", "MiFIR receiving competent authority. Values identical."),
    ("Outgoing Payment Status", "Outgoing Payment Status", "Research Payment status, a Derived copy of 19. Values identical."),
    ("Period Type", "Period Type", "Research Payment and Broker Execution Review periods. Values identical."),
    ("Message Standard", "Message Standard", "Broker Placement protocol. Values identical PLUS one proposed value, agreed "
     "with 22: ('FIX', 'FIX', 'FIX Protocol messages, e.g. NewOrderSingle, ExecutionReport, AllocationInstruction.'). Add it "
     "to the shared list (steward 06) once, for 22 and 25, before registering 25."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: local 25 lists that look like enterprise lists. (list in 25, proposed shared name, other users, note)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Order Side", "Order Side", ["18", "24", "26"],
     "FIX Side based. 24 'Proposed Trade Side' (Buy, Sell, Sell Short, Buy to Cover) is a subset of the 25 list (which adds "
     "Sell Short Exempt and Subscribe); reconcile by making 24 a member with an identity map for its four values. 26 "
     "settlement direction needs the same values; 18 Portfolio Transaction Type folds side into type, so 18 maps rather "
     "than adopts it. 29 fund orders use purchase / redemption, not this list."),
    ("Allocation Method", "Trade Allocation Method", ["24", "26", "30"],
     "Pro rata, rotation, random. Keep New Issue Allocation Method separate unless the desks agree one list."),
    ("Counterparty Approved Activity", "Counterparty Approved Activity", ["26", "31", "28"],
     "26 needs it to know which agreements a scope requires, 31 to aggregate exposure by activity; 28 securities lending "
     "agents may add a value."),
    ("Trading Asset Class", "Trading Asset Class", ["17", "26", "31", "32"],
     "17 'Instrument Asset Class' is the security master classification; this list is the desk / policy cut. Map, or "
     "record as NOT_MERGED if the cuts must differ."),
    ("Trading Operating Model", "Operating Model", ["18", "26", "27", "28", "29", "30"],
     "Same CD-147 pattern as 18 'IBOR Operating Model'; generalize into one Operating Model list."),
    ("Review Outcome", "Review Outcome", ["23", "33", "40"],
     "Counterparty, broker and best execution reviews; 40 vendor reviews and 23 provider evaluations are similar."),
    ("Execution Factor", None, [],
     "MiFID II Article 27 factors; regulatory list, keep local unless 08 or 33 needs it."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS noticed with existing and sibling domains (decisions.py format). Adds detail to the stage 2 entries
#    'Order', 'Allocation' and 'CSA' in proposals_stage2_a.py.
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Order",
     "usages": [("25", "Trade Order / Block Order", "Securities order for a portfolio, aggregated for execution"),
                ("29", "Fund Order (FNDO-)", "Shareholder order to buy or sell units of the firm's funds"),
                ("06", "Transaction.Order Source", "How a shareholder transaction was entered"),
                ("24", "Proposed Trade", "Intended trade from a rebalance run, before release as a Trade Order")],
     "recommendation": "Never use 'Order' bare. 'Trade Order' and 'Block Order' (25), 'Fund Order' (29)."},
    {"term": "Allocation",
     "usages": [("25", "Trade Allocation (ALLOC-)", "Split of executed quantity to portfolios and SMA accounts"),
                ("25", "New Issue Allocation", "Share of a primary offering received and passed to portfolios"),
                ("07", "Credit Allocation", "Split of sales credit"), ("10", "Allocation Rule / Run", "Cost allocation"),
                ("24", "Target Allocation Set / Asset Allocation Policy", "Intended weights")],
     "recommendation": "Qualify every use: Trade Allocation, New Issue Allocation, Credit Allocation, Cost Allocation, Target Allocation."},
    {"term": "Placement",
     "usages": [("25", "Broker Placement", "Release of a block to a broker, venue or algorithm"),
                ("04", "Paid Placement (PLC-)", "Paid media placement"),
                ("05", "Shelf Placement (SHF-)", "Product placement on a distributor's shelf")],
     "recommendation": "Always qualify: Broker Placement, Paid Placement, Shelf Placement."},
    {"term": "Execution",
     "usages": [("25", "Execution (EXEC-)", "Fill received from a broker or venue"),
                ("05", "Agreement execution / 'Executed - Not Yet Effective'", "Signature of an agreement")],
     "recommendation": "'Execution' alone means a trade fill only in 25; agreements use 'signed' or 'executed agreement'."},
    {"term": "CSA",
     "usages": [("26", "Credit Support Terms", "Credit Support Annex to an ISDA Master Agreement"),
                ("25", "Commission Sharing Arrangement", "Research credits from execution commissions")],
     "recommendation": "Spell both out; 25 uses no 'CSA' name. The broker's arrangement code is 'Arrangement Reference'."},
    {"term": "Trade",
     "usages": [("25", "Trade Order / Execution / Trade Allocation", "Order, fill and allocation"),
                ("18", "Portfolio Transaction (PTXN-)", "Booked effect on the portfolio"),
                ("24", "Proposed Trade", "Intended trade before release"),
                ("26", "OTC Derivative Trade (OTC-) / Repo Trade", "Contract lifecycle after execution")],
     "recommendation": "No object is called 'Trade' bare; glossary links Proposed Trade -> Trade Order -> Execution -> Trade Allocation -> Portfolio Transaction / Trade Confirmation."},
    {"term": "Counterparty",
     "usages": [("25", "Approved Counterparty Profile", "Approval role profile on a 02 party"),
                ("18", "Portfolio Transaction.Transaction Counterparty", "Party on the booked transaction"),
                ("26", "Trading Agreement counterparty", "Party to an ISDA, GMRA or clearing agreement"),
                ("31", "Counterparty exposure (planned)", "Measured credit exposure")],
     "recommendation": "Counterparty is always a 02 party (PTY-); 25 masters only the approval facts (CD-179)."},
    {"term": "Trading Setup",
     "usages": [("05", "Trading Setup", "Fund dealing set-up with a distributor (dealing route, settlement cycle, order cut-off)"),
                ("25", "Order Management / Counterparty Approval", "Securities trading for portfolios")],
     "recommendation": "Rename 05 'Trading Setup' to 'Fund Dealing Setup' at the next 05 revision; 25 has no object of that name."},
    {"term": "Research Payment",
     "usages": [("25", "Research Payment", "Payment to a research provider for a period"),
                ("18", "Transaction Cost & Charge.Research Payment Component", "Research part of a booked commission (copy of 25)"),
                ("23", "Research Evaluation Round", "Broker vote that sets the payment")],
     "recommendation": "Keep the names; 18's attribute becomes Derived copy (25) (CD-174)."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. PARTY_ROLE_TYPE_ADDITIONS for 02 (CD-179), each matched to the 25 attribute that references the role
# ---------------------------------------------------------------------------------------------------------------------
PARTY_ROLE_TYPE_ADDITIONS = [   # (target domain + list, value, description incl. the 25 attribute that uses it)
    ("02 Party Role Type", "Executing Broker", "Broker that executes trades for the firm: Placement Broker, Executing Broker, Directed Broker, Schedule Broker, Reviewed Broker."),
    ("02 Party Role Type", "Clearing Broker / FCM", "Also proposed by 26 (one value). Differs from 02 'Clearing Firm' (clearing broker-dealer of a distributor). Counterparty Approval Scope activity."),
    ("02 Party Role Type", "Prime Broker", "Counterparty Approval Scope activity Prime Broker."),
    ("02 Party Role Type", "Step-Out Broker", "Order Handling Instruction.Step-Out Broker."),
    ("02 Party Role Type", "OTC Derivative Counterparty", "Counterparty Approval Scope, Counterparty Trading Limit."),
    ("02 Party Role Type", "FX Counterparty", "Counterparty Approval Scope, Counterparty Trading Limit."),
    ("02 Party Role Type", "Repo Counterparty", "Counterparty Approval Scope, Counterparty Trading Limit."),
    ("02 Party Role Type", "Underwriter / Bookrunner", "New Issue Offering.Lead Bookrunner; Rule 10f-3 Purchase.Purchased From."),
    ("02 Party Role Type", "Research Provider", "Research Payment.Paid Research Provider (profile in 23)."),
    ("02 Party Role Type", "TCA Provider", "TCA Result.TCA Provider."),
    ("02 Party Role Type", "Approved Reporting Mechanism", "MiFIR Transaction Report.Approved Reporting Mechanism."),
    ("02 Party Role Type", "Outsourced Trading Provider", "Best Execution Policy.Outsourced Trading Provider."),
]

# 17 addition requested by the program lead (FX orders and executions have no instrument today).
INSTRUMENT_ADDITIONS = [
    ("17 Instrument Type", "FX Contract (Spot / Forward / Swap / NDF)",
     "One instrument per currency pair x FX instrument type x value date (and far date for swaps), or a generic pair instrument, "
     "so that 25 Trade Order and 18 Portfolio Transaction FX rows can reference INS-. 25 keeps Currency Pair, Dealt Currency "
     "and value dates on the order until 17 decides; Order Instrument is optional for FX."),
]

# 25 -> 18 attribute mapping for trade rows booked from an allocation (row rule, plan §4 item 9). Same-name pairs
# (Commission Amount, Research Payment Component, Exchange and Clearing Fee Amount, Transaction Tax Amount, Accrued
# Interest Amount, Contractual Settlement Date, Executing Broker) map one to one. (25 attribute, 18 attribute, rule)
TRADE_FIELD_MAPPING = [
    ("Trade Allocation.Gross Trade Amount", "Portfolio Transaction.Principal Amount", "Derived copy (25) on rows with a Source Allocation."),
    ("Trade Allocation.Net Trade Amount", "Portfolio Transaction.Net Settlement Amount", "Derived copy (25) on rows with a Source Allocation."),
    ("Trade Allocation.Allocation Average Price", "Portfolio Transaction.Transaction Price", "Derived copy (25) on rows with a Source Allocation."),
    ("Trade Allocation.Allocation Trade Date", "Portfolio Transaction.Trade Date", "Derived copy (25) on rows with a Source Allocation."),
    ("Allocation Cost Detail.Regulatory Transaction Fee Amount", "Transaction Cost & Charge.Exchange and Clearing Fee Amount", "18 has no regulatory fee attribute: it adds the 25 regulatory fee to its fee amount (or 18 adds a 'Regulatory Transaction Fee Amount')."),
    ("Execution.Executed FX Rate", "Portfolio Transaction.Trade FX Rate", "Derived (25) with a stated conversion, not a copy: see NOTES (CD-168)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "CD-180: re-type 18 Portfolio Transaction 'Source Allocation ID' to Reference (Trade Allocation, 25) with ALLOC- examples "
    "(today an Identifier flagged Derived copy (25), example 'A-20261005-0041277').",
    "CD-180: the order holds the proposal link (Trade Order.Originating Proposed Trade, keyed by the 24 Proposed Trade grain "
    "'rebalance run x portfolio x instrument x side'); 24 drops its reverse 'Released Trade Order' copy.",
    "CD-174: re-note 18 Transaction Cost & Charge 'Commission Amount' and 'Research Payment Component' as Derived copy (25) of "
    "Allocation Cost Detail. Beyond CD-174: 18 'Exchange and Clearing Fee Amount' (including the 25 regulatory fee) and "
    "'Transaction Tax Amount' take the same row rule: Derived copy (25) on rows booked from an allocation, mastered in 18 "
    "otherwise (e.g. custody transaction charges). The trade fields with different names are in TRADE_FIELD_MAPPING.",
    "CD-168 (changed): 18 Trade FX Rate on rows booked from an FX trade is DERIVED from 25 Execution.Executed FX Rate, not "
    "copied. The executed rate is the dealt rate in the quoted direction of the order's Currency Pair (quote units per base "
    "unit). Conversion to the portfolio base currency: (a) quote currency = base currency: use the executed rate; (b) pair "
    "base currency = portfolio base currency: use 1 / executed rate; (c) neither leg in base currency (e.g. EUR/JPY in a USD "
    "fund): cross through base, combining the executed rate with the 22 FX Rate Observation of one leg against base, and the "
    "18 row records which leg rate was used. Forward and swap far legs use Far Leg FX Rate. Securities trades whose FX is "
    "bundled by the broker in settlement have no 25 FX execution: 18 keeps Derived copy (22). Ask the CD-168 owner to amend "
    "the decision text before 18 is re-flagged.",
    "17: FX orders and executions have no instrument today (see INSTRUMENT_ADDITIONS). 18 books 'FX Spot' and 'FX Forward' "
    "transaction types without an instrument; once 17 adds FX contracts, 25 Order Instrument becomes mandatory for FX too.",
    "Cross trades: an internal cross produces two Trade Allocations with Allocation Source 'Internal Cross' and no block or "
    "executing broker; Cross Trade references both. The independent price is a reference to the 22 Price Observation at the "
    "time of the cross (not the end-of-day Approved Price), with the value as Derived copy (22).",
    "CD-184: MiFIR Transaction Report is a business object covering the market-side report of an aggregated block against the "
    "aggregate client account (INTC) and each client-side allocation report, pending SME question 4. If the firm does not "
    "report for any entity, drop it. Investment Decision Maker is a Derived copy (24) of the Investment Decision's Decision "
    "Maker or Decision Algorithm Code.",
    "Large Trader ID is mastered in 25 (Order Handling Instruction) until 38 Compliance owns the Form 13H registration; no 09 "
    "copy is proposed. Re-flag it as a copy of 38 then.",
    "23: Research Payment references the 23 Research Evaluation Round (provider x period x evaluator); 25 holds no research "
    "payment route for 23 to copy (23 is removing 'Research Payment Route'). Credit View references 23 Internal Credit "
    "Assessment by its grain key (issuer x analyst x scale x effective date).",
    "26: OTC Derivative Trade 'OTC Trade Date' is a Derived copy (25) of Trade Allocation.Allocation Trade Date for trades "
    "created from an allocation. 26 Trade Confirmation and Settlement Instruction reference ALLOC-; 31 references Counterparty "
    "Trading Limit.",
    "Compliance Check Outcome on Trade Order Event is Derived copy (33); 33 should reference TORD- when drafted (Stage 3).",
    "Grain-keyed references (Applied Commission Schedule, Applied / Funding Commission Sharing Arrangement, Balance "
    "Arrangement, Funding Research Budget, Supporting Eligibility Certification) are forced to 'mastered here' by "
    "OWNERSHIP_OVERRIDES in enrich_25.py because their examples start with PTY-, LEN- or PORT-. Research Evaluation Round "
    "and Credit View are forced to 23 for the same reason.",
    "29 AP order is referenced as 'Reference (AP Creation / Redemption Order, 29)' with prefix ECR- from the 29 brief; align "
    "if 29 changes the name.",
    "Syndicated loan trades: documentation (par / distressed) and assignment vs participation are treated as 26 settlement "
    "data; 25 holds the order, execution and allocation only.",
    "Shared lists: content_25 holds local copies named exactly as the shared lists (see SHARED_MEMBERSHIPS); no import-time "
    "helper. Once 25 is registered, delete the copies and cite 'Shared: <name>'.",
    "05 'Trading Setup' is fund dealing, not trading: term conflict logged; no 05 change is proposed in Stage 2.",
]
