"""Consolidation proposals from Data Domain 26 - Trade Operations, Settlement & Collateral (Stage 2 draft v0.2, 2026-10-06).

Proposal fragment only: the builder does not read it. The stage consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Format follows CONTRACT.md in this folder. v0.2 applies the independent review
(00_Program/Expansion/Reviews/26_review.md) and the program lead's decisions on it.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones (prefix, entity, owner domain, status, note). None needed.
#    26 uses the reserved CNFM-, SETL-, CSDP-, OTC-, TAGR- and MCALL- (proposals_stage2_a.py), and SSI-, which transfers
#    from 12 under CD-155 option A. CPSI- is unused. Repo Trade is keyed by a firm Repo Trade Reference without a
#    hyphenated prefix (review C); a prefix can be added after a near-collision check if the client wants one.
#    Status events, fails, cycle rules, legs, lifecycle events, cash flows, trade reports, credit support terms,
#    schedules, triggers, movements, balances and IM calculations are keyed by their grain.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# Re-registration needed under CD-155 option A (decisions.PREFIXES today: ("SSI-", ..., "12", "Proposed", ...)).
PREFIX_CHANGES = [
    ("SSI-", "Standing settlement instruction", "12 -> 26",
     "CD-155 option A: change the owner to 26 and status to Registered. Until then enrich_26 forces the two SSI references "
     "on Settlement Instruction to 'mastered here' (OWNERSHIP_OVERRIDES); remove those overrides once the register says 26."),
    ("CPSI-", "Counterparty and portfolio settlement instruction", "26 (Reserved) -> Retired",
     "Retire if CD-155 option A is ratified; keep reserved only if option B is chosen."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local 26 lists that are exact copies of enterprise shared lists. Register 26 as a member
#    (value_map identity) or as a direct user, then the local copies can be dropped.
#    (local list name in 26, shared list name, note)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    ("Record Status", "Record Status", "SSI Status."),
    ("Approval Status", "Approval Status", "SSI change four-eyes approval; margin call dispute resolution."),
    ("Case Status", "Case Status", "Match exceptions, settlement fails, penalty appeals, margin call disputes."),
    ("Message Standard", "Message Standard", "Settlement instruction message standard. See the value proposals below."),
    ("Flow Direction", "Flow Direction", "Securities movement, cash payment, penalty, OTC cash flow and collateral movement direction. Neutral is not used."),
    ("Regulator", "Regulator", "Margin Rule Regulators on Credit Support Terms (CFTC / NFA, SEC, FINRA, ESMA, FCA ...)."),
    ("Frequency", "Frequency", "Margin call frequency; OTC leg payment frequency."),
    ("Agreement Status", "Agreement Status", "Trading Agreement status; 26 joins 05 as a user (CD-182)."),
    ("Reconciliation Status", "Reconciliation Status", "Only for agreement of a collateral balance with the counterparty; custody reconciliation is 28."),
]

# Values proposed for shared and other domains' lists (list, value, description). Message Standard values are proposed at
# business-area granularity, coordinated with 25 (FIX) and 28 (seev, camt) (review F); MT-level detail stays in the 26
# list Settlement Message Standard.
SHARED_VALUE_PROPOSALS = [
    ("Message Standard", "ISO 20022 sese", "Securities settlement (instruction, status advice, confirmation)."),
    ("Message Standard", "ISO 20022 colr", "Collateral management (margin calls, collateral proposals, disputes)."),
    ("Message Standard", "ISO 20022 pacs", "Interbank payments (pacs.009) for cash-only settlements."),
    ("Message Standard", "ISO 20022 seev", "Corporate action messages (28 proposal; listed here for one coordinated change)."),
    ("Message Standard", "ISO 20022 camt", "Cash management statements (28 proposal; listed here for one coordinated change)."),
    ("Message Standard", "FpML", "OTC derivative confirmations and trade reporting."),
    ("Message Standard", "FIX Protocol", "Order and allocation messages (25 proposal; listed here for one coordinated change)."),
    ("02 Party Role Type", "Central Securities Depository", "CSD or ICSD that settles instructions and computes CSDR penalties."),
    ("02 Party Role Type", "Clearing Broker / FCM", "Clearing member through which a fund clears futures and swaps."),
    ("02 Party Role Type", "Tri-Party Agent", "Agent that allocates and holds repo or margin collateral."),
    ("02 Party Role Type", "Collateral Segregation Custodian", "Third-party custodian holding regulatory initial margin."),
    ("02 Party Role Type", "Trade Repository", "EMIR / UK EMIR trade repository, CFTC swap data repository, SEC SBS data repository or SFTR repository."),
    ("02 Party Role Type", "Loan Administrative Agent", "Already proposed by 17; 26 Loan Settlement Detail also uses it."),
    ("09 Calendar Type", "Settlement (CSD / Payment System)",
     "CD-185. Note: 09 already has 'Banking / Settlement' (TARGET, Fed, UK bank holidays). Either split that value into "
     "'Banking' and 'Settlement (CSD / Payment System)' or keep it and document that CSD calendars use it."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: local 26 lists that look like enterprise lists.
#    (list name in 26, proposed shared list name, likely other users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Settlement Type", "Settlement Type", ["28", "29", "27"],
     "Business purpose of a settlement (trade, in-kind creation / redemption, collateral, repo legs, transfer, syndicated "
     "loan trade, FX settlement, derivative payment). Payment basis and direction are separate attributes. 29 fund order "
     "settlement methods (NSCC net, wire, ACH) are a different list (see TERM_CONFLICTS)."),
    ("Trade Settlement Status", "Trade Settlement Status", ["28", "29", "27"],
     "Renamed from 'Settlement Status' (review F: 10 has a 'Settlement Status' list with other values). Settlement status "
     "only; processing status and matching are separate attributes on Settlement Status Event."),
    ("Collateral Type", "Collateral Type", ["28", "31"],
     "26 labels now match 28 'Lending Collateral Type' where the asset is the same (Cash, US Treasury Securities, Agency "
     "Securities, Other Government Bonds, Equities). Proposal for 28 (not edited here): adopt the shared list and keep "
     "'Letters of Credit' and 'Other' as lending-only values, or add them to the shared list."),
    ("Trade Report Regime", "Regulatory Trade Report Regime", ["25", "28"],
     "26 values now use 28's labels (EU SFTR, UK SFTR) and add EU EMIR, UK EMIR, CFTC Part 45, SEC Regulation SBSR. "
     "Proposal for 28 (not edited here): adopt the shared list, which would also carry SEC Rule 10c-1a; 25 MiFIR "
     "transaction reports could add MiFIR Article 26 / UK MiFIR."),
    ("Message Processing Status", "Regulatory Report Status", ["25", "28", "29", "35", "38"],
     "Three report-status lists exist: 26 Message Processing Status, 28 Loan Report Status, 25 Transaction Report Status. "
     "Recommend one shared list (Pending, Submitted, Acknowledged, Accepted, Rejected, Corrected, Canceled, Not Required) "
     "with 26's instruction processing keeping the same values."),
    ("Trading Agreement Type", "Contract Type (enterprise)", ["28", "39", "05", "14"],
     "39 will index TAGR-, AGR-, DLA- and the 28 securities lending agreements; one enterprise contract-type list with "
     "domain-specific subsets avoids four agreement type lists. Now includes MSFTA, Prime Brokerage Agreement and "
     "Tri-Party Collateral Agreement."),
    ("Responsible Party Type", None, ["25", "28", "29"],
     "Candidate only: 25 trade errors and 29 settlement exceptions also attribute fault."),
    ("SSI Asset Class", None, ["12"],
     "Moved from 12 unchanged (CD-155 option A). Remove from content_12 at merge."),
    ("Settlement Message Standard", "Message Standard", ["12"],
     "Moved from 12 unchanged with the SSI. Its MT-level values stay local; map each to the shared business-area value."),
]

# Local list names that collide with other domains' lists of different meaning (review F). Resolved by renaming in 26.
LOCAL_RENAMES_DONE = [
    ("26", "Settlement Status", "Trade Settlement Status", "10 'Settlement Status' (Pending / Invoiced / Settled / Netted) is a different concept."),
    ("26", "Dispute Reason", "Collateral Dispute Reason", "05 and 12 'Dispute Reason' lists hold billing and agreement disputes."),
    ("26", "Settlement Fail Reason", "Settlement Status Reason", "Covers unmatched and pending reasons, not only fails; ISO codes now in the code position."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS noticed with existing domains (decisions.py format)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Settlement",
     "usages": [("26", "Settlement Instruction (SETL-)", "Trade-level securities, cash, FX and loan settlement"),
                ("05", "Trading Setup: Settlement Method / Settlement Cycle", "How fund orders with a distribution partner settle (NSCC, Calastone, ICSD)"),
                ("29", "Settlement Obligation / Intermediary Settlement Batch", "Settlement of fund orders with intermediaries"),
                ("18", "Settled / Unsettled Quantity, Settlement Confirmed Indicator", "IBOR view of settlement")],
     "recommendation": "'Securities Settlement' (26) vs 'Fund Order Settlement' (05, 29). 29 still writes 'Trade Settlement' "
                       "in places; the 26 object is 'Settlement Instruction' (SETL-)."},
    {"term": "Settlement Cycle",
     "usages": [("05", "Trading Setup.Settlement Cycle", "Fund dealing cycle agreed with a partner (T+n)"),
                ("26", "Settlement Cycle Rule.Standard Settlement Cycle", "Securities market cycle per market, instrument and settlement type")],
     "recommendation": "CD-185: keep both, qualified ('Fund Dealing Settlement Cycle' in 05)."},
    {"term": "Settlement Method",
     "usages": [("05", "Settlement Method list", "NSCC net, Calastone, ICSD, wire"),
                ("17", "Settlement Method list", "Cash or physical delivery of a derivative contract")],
     "recommendation": "26 does not use the term: payment basis is 'Against Payment Indicator'. Rename one of the 05 / 17 lists "
                       "(17 'Delivery Method' or 05 'Fund Order Settlement Method') via LOCAL_RENAMES."},
    {"term": "Standing Instruction",
     "usages": [("15", "Account Standing Instruction (SIN-)", "Shareholder systematic plans and distribution options"),
                ("26", "Standing Settlement Instruction (SSI-)", "Where securities and cash settle for a mandate, fund, portfolio or counterparty")],
     "recommendation": "Never use 'Standing Instruction' bare; the glossary entries are distinct."},
    {"term": "Confirmation",
     "usages": [("26", "Trade Confirmation (CNFM-)", "Broker or counterparty confirmation and affirmation of a trade"),
                ("13", "Shareholder confirmation / statement", "Confirmation sent to a shareholder (Rule 10b-10)")],
     "recommendation": "'Trade Confirmation' (26) vs 'Shareholder Confirmation' (13)."},
    {"term": "CSA",
     "usages": [("26", "Trading Agreement Type 'CSA - Variation Margin' / 'CSA - Initial Margin'", "ISDA Credit Support Annex"),
                ("25", "Commission Sharing Arrangement", "Research payment arrangement with a broker")],
     "recommendation": "Never abbreviate in names: 'Credit Support Annex' (26), 'Commission Sharing Arrangement' (25)."},
    {"term": "Agreement",
     "usages": [("05", "Distribution Agreement (AGR-)", "Selling and servicing agreements"),
                ("14", "Data License Agreement (DLA-)", ""), ("10", "Intercompany Agreement (ICA-)", ""),
                ("26", "Trading Agreement (TAGR-)", "ISDA, CSA, GMRA, MRA, MSFTA, clearing and give-up agreements"),
                ("28", "Securities Lending Agreement", "GMSLA and agency lending agreements")],
     "recommendation": "Bare 'agreement' resolves to 05 in ownership.py ALIASES; 26 always writes 'Trading Agreement' and the "
                       "type includes the domain number. 39 indexes all agreements (CD-182)."},
    {"term": "Collateral",
     "usages": [("17", "Securitized Product Terms (collateral pool)", "Assets backing a securitization"),
                ("26", "Collateral Movement / Collateral Balance", "Margin, repo and cleared collateral under trading agreements"),
                ("28", "Lending Collateral Received", "Securities lending collateral"),
                ("29", "AP Order: Collateral Posted Amount", "Cash an authorized participant posts against undelivered basket securities")],
     "recommendation": "'Margin Collateral' (26), 'Lending Collateral' (28), 'AP Order Collateral' (29), 'Collateral Pool' (17)."},
    {"term": "Margin",
     "usages": [("26", "Margin Type / Margin Call", "Variation, initial, cleared and repo margin under trading agreements"),
                ("10", "Profitability margin measures", "Financial margin")],
     "recommendation": "Use 'Collateral Margin' in the glossary when ambiguity is possible."},
    {"term": "Safekeeping Account",
     "usages": [("12", "Standing Settlement Instruction.Safekeeping Account (CUA-)", "Moved to 26 unchanged; points to the 12 custody set-up"),
                ("26", "Own Safekeeping Account / Settlement Safekeeping Account (SKA-)", "28 safekeeping account"),
                ("28", "Safekeeping Account (SKA-)", "Account at a custodian")],
     "recommendation": "Exclusive row rule by SSI Owner Type in 26 now. Under CD-194 option A re-type the moved 'Safekeeping "
                       "Account' to SKA- and retire 'Own Safekeeping Account'; under option B CUA- moves to 28 and the same "
                       "merge applies. This is a CD-194 consequence, not part of the CD-155 move."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "CD-155 option A drafted: 'Standing Settlement Instruction' and its 10 attributes are copied from content_12 exactly "
    "(names, definitions, types, examples, CDE flags), as are the lists SSI Asset Class, Settlement Message Standard and SSI "
    "Verification Status. The only change to a moved tuple is the row-rule note on 'Safekeeping Account' (program lead "
    "decision on review A). At merge: remove the object and the three lists from content_12, add a 12 reference from "
    "Custody Account to the 26 SSI it caused, re-register SSI- to 26 and drop the two OWNERSHIP_OVERRIDES in enrich_26.",
    "Merge-time CDE changes on the moved SSI (left unchanged now because the tuples are copied exactly): flag 'SSI ID' as CDE "
    "(SSI- becomes a registered 26 key every instruction references), and consider moving the CDE on 'SSI Mandate' (blank "
    "for fund, portfolio and counterparty SSIs) to 'SSI Owner Type' plus the owner reference.",
    "CD-194 consequence (not CD-155): if CD-194 option A is ratified, re-type the moved SSI 'Safekeeping Account' from "
    "Reference (Custody Account) CUA- to Reference (Safekeeping Account, 28) SKA-, add the PII note, and retire 'Own "
    "Safekeeping Account' into it. Until then the exclusive row rule by SSI Owner Type applies (Client Mandate -> CUA-; "
    "Fund / Portfolio -> SKA-; Counterparty -> Counterparty Safekeeping Account Number).",
    "CD-181 row rules for the 18 values (replaces the v0.1 'column copy' wording; update the CD-181 resolution text and the "
    "Notes on the 18 attributes): "
    "(a) 18 Settlement Confirmed Indicator (Portfolio Transaction) = Derived copy (26): Y when the latest Settlement Status "
    "Event of the Settlement Instruction that settles the transaction has Trade Settlement Status 'Settled'. "
    "(b) 18 Initial Margin Posted (Derivative Holding Detail, portfolio x instrument x date x view) = Derived (26) "
    "allocation: for each Trading Agreement and date, the posted Collateral Value of Collateral Balance rows with Margin Type "
    "Initial Margin or Cleared Initial Margin for the holding's portfolio is allocated to that portfolio's derivative "
    "holdings under the agreement pro rata to each holding's contribution to the Initial Margin Calculation (Gross IM "
    "Amount) where the calculation provides it, otherwise pro rata to gross notional (sum of OTC Trade Leg notional, or the "
    "CCP's margin for cleared positions). State the basis used in the 18 Notes. "
    "(c) 18 Encumbered Quantity (Portfolio Holding, portfolio x instrument x date x view) = row rule: Derived (26) sum of "
    "Balance Quantity over Collateral Balance rows with Balance Direction 'Posted', the holding's portfolio and instrument and "
    "the holding date, across all agreements and margin types (Variation, Initial, Cleared Initial and Cleared Variation "
    "Margin, and Repo Collateral for securities delivered out on repo); plus Derived (28) on-loan quantity for securities "
    "lending. "
    "(d) 18 Settled Quantity and Unsettled Quantity remain 18 computations from 26 settlement status; replace their "
    "'future owner 26' Notes with 'computed from 26 Settlement Status Event'.",
    "CD-183: 27 and 28 already reference 'Settlement Instruction, 26'. 29 Basket Settlement Line (Line Delivery Settlement) "
    "owns the line-level link to SETL-; 26 'Related AP Order' is an order-level reference only. 29 Line Settlement Status "
    "should read Trade Settlement Status from 26 for lines 26 settles rather than restate it.",
    "27 hand-off: settlement penalties (CSDP-), variation margin movements and OTC payments reach the 27 ledger only through "
    "the Settlement Instruction that settles them (Settlement Type Collateral / Derivative Payment, or a payment SETL- for a "
    "penalty). Confirm with 27 that every posting arrives through SETL-, or add a Reference (Settlement Penalty, 26) to 27.",
    "CD-184: Derivative Trade Report covers EU EMIR, UK EMIR, CFTC Part 45, SEC Regulation SBSR, EU SFTR and UK SFTR (repo). "
    "It now carries Reporting Counterparty (02 PTY-), Entity Responsible for Reporting (09 LEN-, EMIR Article 9(1d)) and "
    "Report Submitting Entity (02 PTY-). Reporting obligations and counterparty classifications (FC / NFC, swap dealer, "
    "SBS entity) are read from 38 Corporate Compliance (09 Entity Authorization until 38 exists), not mastered in 26. "
    "Report event types are cited as an external code set pending confirmation of the EMIR Refit and CFTC values.",
    "Cross-domain example keys aligned to owners' formats: ALLOC-2026-00412nn (25), PRICE-yyyymmdd-<instrument>-nn (22), "
    "ECR-2026-000512 (29), SKA-nnnnnn (28).",
    "FX settlement is in scope here as a Settlement Instruction of type FX Settlement with Cash Payment Detail (CLS or gross "
    "payment); FX trade economics stay in 25. A later fund cash / treasury domain may take over cash management, but not "
    "trade-level FX settlement.",
    "Stage 2 shared-list question: 26 cites local copies of nine shared lists (exact values). Register 26 per "
    "SHARED_MEMBERSHIPS and drop the copies.",
]
