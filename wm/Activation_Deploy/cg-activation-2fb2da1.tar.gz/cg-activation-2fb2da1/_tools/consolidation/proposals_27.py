"""Consolidation proposals from the Data Domain 27 (Fund Accounting & Valuation) draft v0.1, 2026-10-06.

Proposal fragment only: the builder does not read this file. The Stage 2 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Formats follow CONTRACT.md in this folder. Boundary decisions CD-186 to CD-193 are in
proposals_stage2_b.py; this file holds what the draft found while implementing them.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES (prefix, entity, owner domain, status, note) - decisions.PREFIXES format
# None beyond the six reserved in proposals_stage2_b.py (NAV-, FJNL-, FDIV-, NEC-, SWG-, FTAX-). Books, ledger accounts,
# journal lines, trial balances, valuations, accruals, NAV calculations, allocations, disseminations, parameters, budgets,
# payments, estimates, differences, tests, impacts, checks and statements keep composite keys.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED MEMBERSHIPS: 27 local lists that carry an enterprise shared list's exact name and values (copied from
#    shared_code_lists.py). Register 27 as a member (or direct user) of each.
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": 'Outgoing Payment Status', "local": 'Outgoing Payment Status',
     "value_map": {'Scheduled': 'SCHEDULED', 'Released': 'RELEASED', 'Paid / Settled': 'PAID', 'Failed': 'FAILED', 'Reversed': 'REVERSED', 'Canceled': 'CANCELED'},
     "new_values": []},
    {"shared": 'Approval Status', "local": 'Approval Status',
     "value_map": {'Not Required': 'NOT_REQUIRED', 'Pending': 'PENDING', 'Approved': 'APPROVED', 'Approved with Conditions': 'APPROVED_WITH_CONDITIONS', 'Retrospectively Approved': 'RETROSPECTIVELY_APPROVED', 'Rejected': 'REJECTED', 'Expired': 'EXPIRED', 'Withdrawn': 'WITHDRAWN'},
     "new_values": []},
    {"shared": 'Severity', "local": 'Severity',
     "value_map": {'Low': 'LOW', 'Medium': 'MEDIUM', 'High': 'HIGH', 'Critical': 'CRITICAL'},
     "new_values": []},
    {"shared": 'Regulator', "local": 'Regulator',
     "value_map": {'SEC': 'US_SEC', 'FINRA': 'US_FINRA', 'US State Securities Regulator': 'US_STATE_SECURITIES_REGULATOR', 'CFTC / NFA': 'US_CFTC_NFA', 'OCC': 'US_OCC', 'US State Banking Regulator': 'US_STATE_BANKING_REGULATOR', 'Federal Reserve': 'US_FEDERAL_RESERVE', 'DOL / EBSA': 'US_DOL_EBSA', 'US State Insurance Regulator': 'US_STATE_INSURANCE_REGULATOR', 'FCA': 'UK_FCA', 'PRA': 'UK_PRA', 'CSSF': 'LU_CSSF', 'Central Bank of Ireland': 'IE_CBI', 'BaFin': 'DE_BAFIN', 'AMF': 'FR_AMF', "CONSOB / Banca d'Italia": 'IT_CONSOB_BANCA_D_ITALIA', 'CNMV': 'ES_CNMV', 'AFM': 'NL_AFM', 'FINMA': 'CH_FINMA', 'Other EU NCA': 'OTHER_EU_NCA', 'ESMA': 'EU_ESMA', 'European Commission': 'EU_COMMISSION', 'IOSCO': 'INTL_IOSCO'},
     "new_values": []},
    {"shared": 'Record Status', "local": 'Record Status',
     "value_map": {'Draft': 'DRAFT', 'Proposed': 'PROPOSED', 'Pending': 'PENDING', 'Active': 'ACTIVE', 'Paused': 'PAUSED', 'Inactive': 'INACTIVE', 'Deprecated': 'DEPRECATED', 'Retired': 'RETIRED'},
     "new_values": []},
    {"shared": 'Case Status', "local": 'Case Status',
     "value_map": {'New / Received': 'NEW', 'Pending Good Order': 'PENDING_GOOD_ORDER', 'In Progress': 'IN_PROGRESS', 'Waiting on Client': 'WAITING_ON_CLIENT', 'Pending Third Party': 'PENDING_THIRD_PARTY', 'Escalated': 'ESCALATED', 'Resolved / Completed': 'RESOLVED', 'Closed': 'CLOSED', 'Rejected': 'REJECTED', 'Canceled': 'CANCELED'},
     "new_values": []},
    {"shared": 'Data Basis', "local": 'Data Basis',
     "value_map": {'Reported / Actual': 'REPORTED', 'Estimated': 'ESTIMATED', 'Modeled': 'MODELED', 'Allocated': 'ALLOCATED', 'Interpolated': 'INTERPOLATED', 'Survey-Based': 'SURVEY_BASED', 'Mixed': 'MIXED'},
     "new_values": []},
    {"shared": 'Flow Direction', "local": 'Flow Direction',
     "value_map": {'Inflow': 'INFLOW', 'Outflow': 'OUTFLOW', 'Neutral': 'NEUTRAL'},
     "new_values": []},
    {"shared": 'Reconciliation Status', "local": 'Reconciliation Status',
     "value_map": {'Reconciled': 'RECONCILED', 'Reconciled within Tolerance': 'RECONCILED_WITHIN_TOLERANCE', 'Break Open': 'BREAK_OPEN', 'Break Explained': 'BREAK_EXPLAINED', 'Not Reconciled': 'NOT_RECONCILED'},
     "new_values": []},
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: local 27 lists that look like enterprise lists
#    (list name in 27, proposed shared list name or None, likely other users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Business Line", "Business Line", ["18", "21", "24", "30", "32", "33"],
     "Same six values as 18 and 21 (shared list deferred, stage1_consolidation_notes §2). 27 never uses 'Separately Managed "
     "Account' (SMAs have no fund book) but keeps the value so the list stays identical. The list name collides with 01 'Business Line' (client segment "
     "values); 27 adds a user of the enterprise meaning, so the 01 rename (proposals_18) becomes more pressing."),
    ("Accounting Basis", "Accounting Basis", ["19", "30"],
     "Copied from 19 with identical values. Make it one shared list stewarded by 19; 27 adds no values. Fund-specific "
     "frameworks (IMA SORP with FRS 102) are notes, not values."),
    ("Waiver Type", "Waiver Type", ["10"],
     "Identical values to 10 Waiver Type (CD-188). Recommend one shared list stewarded by 27 (the accrual is the source) or "
     "by 01 (the term); record as a membership rather than NOT_MERGED."),
    ("Fund Accounting Operating Model", "Operating Model", ["18", "26", "28", "29", "30"],
     "CD-147: same idea as 18 'IBOR Operating Model'. 27 adds 'Outsourced with Shadow NAV' and 'Trustee Bank'. Generalize."),
    ("Fund Expense Type", None, ["01", "10"],
     "Overlaps 01 Management Fee / Cost Disclosure fee categories and 10 fee revenue types, but describes fund expenses "
     "by financial statement caption. Keep local; map to 01 for the expense ratio build."),
    ("Distribution Character", None, ["13"],
     "13 Tax Form Record reports the same characters by 1099-DIV box. Share it with 13 if 13 has a matching list."),
    ("Income Type", "Investment Income Type", ["18", "28"],
     "18 Portfolio Transaction Type and 28 Income Collection will carry income kinds; one vocabulary helps the expected vs "
     "received income reconciliation."),
    ("NAV Control Check Type", None, ["29", "28", "22"],
     "NAV-level checks only. Capital stock proof is a 29 TA Control Type that 27 references; price checks are 22 tolerance rules."),
    ("NAV Calculation Source", "Operating Model", ["18", "28", "29"],
     "Same CD-147 concept as Fund Accounting Operating Model, seen per NAV calculation; keep the values aligned."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS noticed with existing and sibling domains (decisions.py format)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "NAV",
     "usages": [("27", "Share Class NAV (NAV-)", "Official per-share value struck by fund accounting (Rule 22c-1 price)"),
                ("18", "Portfolio Valuation Summary.Total IBOR Market Value", "IBOR investment estimate of a portfolio's value"),
                ("06", "Transaction.Price; Asset Measures", "Dealing price as delivered; AUM measures"),
                ("01", "iNAV ticker / Valuation Terms", "Indicative intraday value of an ETF; NAV publication terms"),
                ("22", "Approved Price (Own Fund Share Class rows)", "Copy of the 27 NAV used to value own-fund holdings")],
     "recommendation": "Reserve 'NAV' / 'Net Asset Value' for 27 Share Class NAV. Qualify the others: 'IBOR Market Value' (18), "
                       "'Dealing Price as Delivered' (06), 'Indicative NAV (iNAV)' (01). 06 Transaction Price gets the note "
                       "'as delivered; official NAV is 27' (CD-187)."},
    {"term": "Distribution",
     "usages": [("27", "Distribution Declaration (FDIV-)", "Dividend or capital gain declared by an open-end fund on a share class"),
                ("30", "Distribution (PDIS-)", "Private fund distribution to investors under the waterfall"),
                ("16", "Distribution Request (DIST-)", "Payout from a recordkept plan to a participant"),
                ("05", "Distribution Agreement", "Selling or platform agreement with an intermediary"),
                ("01", "Income Distribution / Distribution Policy", "Distribution terms of a share class")],
     "recommendation": "Glossary: 'Fund Distribution Declaration' (27), 'Private Fund Distribution' (30), 'Plan Distribution' "
                       "(16), 'Distribution Agreement' (05). 'Distribution' alone means the business of selling (the "
                       "distribution taxonomy) and should not be used bare for any of these records."},
    {"term": "Accrual",
     "usages": [("27", "Income Accrual; Expense Accrual; Expense Cap & Waiver Accrual", "Fund-side daily accruals in the fund book"),
                ("10", "Distribution accrual (ACR-)", "Adviser's accrual of distribution expense payable to partners"),
                ("07", "Compensation Accrual", "Accrual of sales incentive compensation")],
     "recommendation": "Qualify by book: 'Fund Expense Accrual' (27) vs 'Distribution Expense Accrual' (10) vs 'Compensation "
                       "Accrual' (07). A management fee is a fund expense accrual in 27 and fee revenue in 10 (CD-186)."},
    {"term": "Reconciliation / Control Check",
     "usages": [("27", "NAV Control Check", "Checks on a NAV before release, including capital stock proof"),
                ("29", "TA Control Check (TACK-)", "TA capital stock and cash proofs"),
                ("28", "Custody Reconciliation Run (CUREC-)", "IBOR / ABOR vs custodian positions and cash"),
                ("06", "Reconciliation (RCN-)", "Distribution data reconciliations")],
     "recommendation": "CD-196: reconciliations by producer, one shared Reconciliation Status. Capital stock proof: decide "
                       "whether it is a 29 control that 27 references (as drafted) or a 27 check."},
    {"term": "Book",
     "usages": [("27", "Fund Accounting Book", "Official books of a fund under one accounting basis (ABOR)"),
                ("19", "Ledger (LDG-)", "Corporate books of a group entity"),
                ("18", "Portfolio (managed book) / IBOR", "Investment book of record of a portfolio")],
     "recommendation": "Glossary: 'Fund Book (ABOR)' (27), 'Corporate Ledger' (19), 'Investment Book of Record' (18)."},
    {"term": "Journal Entry",
     "usages": [("27", "Fund Journal Entry (FJNL-)", "Entry in a fund's book"),
                ("19", "Journal Entry (JNL-)", "Entry in a corporate ledger")],
     "recommendation": "Always say 'Fund Journal Entry' for 27. ownership.py alias 'journal entry' -> 19 must stay; 27 types "
                       "its references as 'Reference (Fund Journal Entry, 27)'."},
    {"term": "NAV Release / Price Transmission",
     "usages": [("27", "NAV Dissemination (NAV release)", "Release of a share class NAV for use: released NAV, release timestamp, status, correction flag and corrected release"),
                ("29", "Price & Rate Transmission", "Per-channel transmission of the released NAV and rates (channel, timestamp, deadline, recipient, format)")],
     "recommendation": "Applied split (program lead decision on review finding A-High): 27 masters the release only; 29 masters every "
                       "per-channel transmission, including insurer, vendor, website and platform feeds, and references the 27 release "
                       "(share class NAV x release sequence). One channel vocabulary, in 29. Record as a CD at consolidation "
                       "(extends CD-187 / CD-193). Glossary: 'NAV Release' (27) vs 'Price Transmission' (29). 27 keeps the object "
                       "name 'NAV Dissemination' for continuity with the brief; rename to 'NAV Release' at consolidation if 29 agrees."},
    {"term": "Expense Ratio",
     "usages": [("27", "Financial Highlights.Highlights Gross / Net Expense Ratio", "Actual ratios for the period in the annual report"),
                ("01", "Cost Disclosure.Gross / Net Expense Ratio", "Prospectus fee-table ratios")],
     "recommendation": "Qualify: 'Financial Highlights Expense Ratio' (27, actual) vs 'Prospectus Expense Ratio' (01). SME question 10 "
                       "decides whether 01 copies 27 for the annual-report figures (row rule)."},
    {"term": "Waiver",
     "usages": [("27", "Expense Cap & Waiver Accrual", "Fund-side daily waiver and reimbursement amounts"),
                ("10", "Waiver Record (WVR-)", "Adviser revenue offset of the waiver"),
                ("01", "Cost Disclosure.Expense Cap Rate / Waiver Expiry Date", "Contractual terms")],
     "recommendation": "CD-188 as drafted; glossary 'Fund Waiver Accrual' (27) vs 'Waiver Record' (10)."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. DERIVED COPIES to create elsewhere at consolidation (attribute in another domain -> 27 source)
# ---------------------------------------------------------------------------------------------------------------------
FUTURE_DERIVED_COPIES = [
    ("10", "Waiver Record", "Waived Fee Amount", "27 Expense Cap & Waiver Accrual.Waived Fee Amount (summed over the period)", "CD-188"),
    ("10", "Waiver Record", "Reimbursed Expense Amount", "27 Expense Cap & Waiver Accrual.Reimbursed Expense Amount", "CD-188"),
    ("13", "Servicing Error", "NAV Error Magnitude", "27 NAV Error Impact.NAV Error Percentage (largest affected class and date)", "CD-189"),
    ("13", "Servicing Error", "Materiality Threshold Exceeded Indicator", "27 NAV Error Impact.Threshold Exceeded Indicator", "CD-189"),
    ("22", "Approved Price", "(value) for Own Fund Share Class rows", "27 Share Class NAV.NAV per Share", "CD-167 row rule in 22"),
    ("29", "TA Control Check", "Comparison Value (Capital Stock Proof rows)", "27 Share Class NAV.Shares Outstanding", "29 row rule; already drafted"),
    ("18", "Portfolio Identifier", "Identifier Value (scheme 'Accounting System Fund Code')", "27 Fund Accounting Book.Book Code", "Book code mastered in 27"),
    ("28", "Income Collection", "Expected Net Income Amount", "27 Income Accrual (already drafted as a copy in 28)", "CD-196"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Review applied (00_Program/Expansion/Reviews/27_review.md); what was not applied is in Source_Notes §2 'Review response'.",
    "ID formats owned by 27, for siblings to align their examples: NAV-<valuation date YYYYMMDD><share class number, 6 digits>"
    "<version, 2 digits> (e.g. NAV-2026100500451201, as 22 already uses); FJNL-<year>-<MMDD of posting>-<daily sequence> "
    "(e.g. FJNL-2026-1005-00412, as 28 uses); FDIV-<year>-<6-digit sequence>; NEC-<year>-<4-digit sequence>; "
    "SWG-<year>-<MMDD>-<fund number>; FTAX-<fund number>-<tax year>-<country>. 29 should change NAV-0045120051 to this format.",
    "Composite keys to agree with siblings: 28 keys Income Accrual and ABOR Valuation Record as '<book name> / <ISIN> / <date>'; "
    "27 keys them as '<fund PRD-> / <accounting basis> / <INS-> / <date>' (plus income type for accruals). The NAV release key is "
    "'<NAV-> / <release sequence>' (29 Price & Rate Transmission should reference it).",
    "ABOR quantity is mastered in 27 (program lead decision): the book keeps its own quantity and reconciles it to 18 holdings in "
    "ABOR to IBOR Reconciliation (book x portfolio x instrument x date) and to the custodian in 28 (CD-196). The book accounts "
    "for one or more 18 portfolios through Fund Book Portfolio Link.",
    "Capital stock proof is a 29 TA control that 27 relies on (NAV Control Check 'Relied-On TA Control Check'); 27 holds no proof "
    "result. Price Movement and Stale Price checks were removed (22 price validation); 27 keeps 'Price Exceptions Cleared' as a "
    "NAV-level gate.",
    "13 Servicing Error 'Materiality Threshold Exceeded Indicator' (future Derived copy of 27, CD-189): reword to 'reaches or "
    "exceeds' to match 27 and CSSF Circular 24/856.",
    "CD-188 text: the grain of Expense Cap & Waiver Accrual is share class x waiver type x accrual date (one row per waiver type).",
    "CD-186 'Fund ...' naming: Expense Accrual renamed Fund Expense Accrual. Income Accrual keeps its name because 28 references it.",
    "Prefix register: move NAV-, FJNL-, FDIV-, NEC-, SWG-, FTAX- from Reserved to Registered (owner 27). Until then, own-object "
    "references are typed 'Reference (<Object>, 27)'. Nine own-object references use composite examples starting 'PRD-' and "
    "are forced to 'mastered here' in enrich_27 OWNERSHIP_OVERRIDES; keep those overrides or add the objects to CONCEPT_OWNERSHIP.",
    "Sibling names used (checked against content_22, 26, 28, 29, 30): 22 Approved Price (PRICE-), Reference Rate Fixing, FX "
    "Rate Observation (FXR-), Fair Value Determination (FVD-); 26 Settlement Instruction (SETL-); 28 Income Collection, "
    "Safekeeping Account (SKA-); 29 Fund Order (FNDO-), AP Creation / Redemption Order (ECR-), TA Control Check (TACK-); 30 Capital "
    "Call (CCN-), Distribution (PDIS-), Fund Credit Facility (FCF-), Waterfall Calculation (DWF-); 17 Coupon Schedule.",
    "enrich_27 forces 'Related Income Collection' to 28 because its composite example starts with SKA- (unregistered). Drop the "
    "override when SKA- is registered.",
    "CONCEPT_OWNERSHIP: add ('Share Class NAV', '27', 'NAV-', ['06','12','13','22','29','32','35'], 'Official NAV'), "
    "('NAV Dissemination', '27', '', ['29'], 'NAV release'), ('Fund NAV Calculation', '27', '', ['30'], ''), "
    "('Fund Ledger Account', '27', '', [], ''), ('Swing Pricing Parameter', '27', '', [], ''), ('ABOR Valuation Record', '27', '', ['28'], ''), "
    "('Income Accrual', '27', '', ['28'], ''), "
    "('Fund Accounting Book', '27', '', ['18','28','30'], 'Fund ABOR'), ('Fund Journal Entry', '27', 'FJNL-', ['30'], ''), "
    "('Distribution Declaration', '27', 'FDIV-', ['06','13','15'], ''), ('NAV Error Case', '27', 'NEC-', ['13','29'], ''), "
    "('Swing Pricing Decision', '27', 'SWG-', ['29'], ''), ('Fund Tax Year Record', '27', 'FTAX-', ['35'], '').",
    "13 Servicing Error: add 'Related NAV Error Case' (Reference NEC-), CD-189. 29 As-Of Order Detail already plans the NEC- reference.",
    "06 Transaction 'Price': add note 'as delivered; official NAV is 27 Share Class NAV' (CD-187, not applied here).",
    "Shares outstanding (Share Class NAV) is drafted as mastered here (booked capital stock), reconciled to the TA register by "
    "the 29 capital stock proof. If SMEs decide the TA register is the master, flag it Derived copy (29 or 06).",
    "01 Cost Disclosure expense ratios: if financial highlights become the source (SME question 10), 01 Gross / Net Expense "
    "Ratio should be flagged Derived copy (27) for the annual-report figures and stay mastered in 01 for prospectus figures "
    "(row rule).",
    "Future owners held as notes only (no placeholders): RIC qualification status, N-CSR / N-PORT filings and the valuation "
    "designee (35); fund mergers that close a book (36); returns from NAV (32; Financial Highlights Total Return is the "
    "statement figure).",
    "Swing direction: 27 uses the shared Flow Direction list for net activity direction instead of a local Swing Direction "
    "list (the swing direction follows from it); 'Neutral' means zero net activity here. The brief listed both.",
    "Partner-level tax allocations (K-1) of private funds are 30 Partner Tax Allocation; 27 Fund Tax Year Record holds only "
    "fund-level results for the Partnership regime.",
    "CD-191: if a Tax domain is created, the whole FA-FTX family (Fund Tax Year Record, Book-Tax Difference, RIC Test Result) "
    "and the lists Fund Tax Regime, Book-Tax Difference Type and RIC Test Type move with FTAX-; Distributable Income Estimate "
    "and Distribution Character stay in 27.",
]
