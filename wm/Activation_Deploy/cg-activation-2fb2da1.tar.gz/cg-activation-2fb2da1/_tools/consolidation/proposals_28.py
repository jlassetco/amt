"""Consolidation proposals from the Data Domain 28 (Custody & Asset Servicing) draft, 2026-10-06.

Proposal fragment only: the builder does not read this file. The Stage 2 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Formats follow CONTRACT.md in this folder. Boundary decisions CD-194 to CD-198 are in
proposals_stage2_b.py; this file holds what the draft found while implementing them.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES  (prefix, entity, owner domain, status, note) - decisions.PREFIXES format
# No prefixes beyond the eight reserved in proposals_stage2_b.py (SKA-, CUREC-, CAEN-, ELECT-, WHTR-, SCAC-, SBL-, CMC-).
# Breaks are keyed CUREC-n-Bnn; statements, statement lines, notifications, payments, income collections, tax relief
# documentation, lending programs, revenue allocations, acknowledgment letters and CASS firm profiles keep composite keys.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED MEMBERSHIPS: 28 local lists that carry an enterprise shared list's exact name and values. Register 28 as a
#    member (or as a direct user) of each, with the value_map below. Values are copied from shared_code_lists.py.
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Record Status", "local": "Record Status",
     "value_map": {"Draft": "DRAFT", "Proposed": "PROPOSED", "Pending": "PENDING", "Active": "ACTIVE", "Paused": "PAUSED",
                   "Inactive": "INACTIVE", "Deprecated": "DEPRECATED", "Retired": "RETIRED"},
     "new_values": []},
    {"shared": "Approval Status", "local": "Approval Status",
     "value_map": {"Not Required": "NOT_REQUIRED", "Pending": "PENDING", "Approved": "APPROVED",
                   "Approved with Conditions": "APPROVED_WITH_CONDITIONS", "Retrospectively Approved": "RETROSPECTIVELY_APPROVED",
                   "Rejected": "REJECTED", "Expired": "EXPIRED", "Withdrawn": "WITHDRAWN"},
     "new_values": [],
     "note": "Used for foreign custody eligibility decisions and tax relief documentation acceptance."},
    {"shared": "Case Status", "local": "Case Status",
     "value_map": {"New / Received": "NEW", "Pending Good Order": "PENDING_GOOD_ORDER", "In Progress": "IN_PROGRESS",
                   "Waiting on Client": "WAITING_ON_CLIENT", "Pending Third Party": "PENDING_THIRD_PARTY", "Escalated": "ESCALATED",
                   "Resolved / Completed": "RESOLVED", "Closed": "CLOSED", "Rejected": "REJECTED", "Canceled": "CANCELED"},
     "new_values": [],
     "note": "Workflow status of custody reconciliation breaks. Reclaims and class action claims use local lifecycle lists "
             "(Reclaim Status, Class Action Claim Status) because their states are set by a tax authority or claims administrator."},
    {"shared": "Reconciliation Status", "local": "Reconciliation Status",
     "value_map": {"Reconciled": "RECONCILED", "Reconciled within Tolerance": "RECONCILED_WITHIN_TOLERANCE",
                   "Break Open": "BREAK_OPEN", "Break Explained": "BREAK_EXPLAINED", "Not Reconciled": "NOT_RECONCILED"},
     "new_values": [], "note": "CD-196."},
    {"shared": "Severity", "local": "Severity",
     "value_map": {"Low": "LOW", "Medium": "MEDIUM", "High": "HIGH", "Critical": "CRITICAL"}, "new_values": []},
    {"shared": "Risk Rating", "local": "Risk Rating",
     "value_map": {"Low": "LOW", "Medium": "MEDIUM", "High": "HIGH", "Critical": "CRITICAL", "Prohibited": "PROHIBITED"},
     "new_values": [], "note": "Foreign custody and depository risk rating (Rule 17f-7)."},
    {"shared": "Data Basis", "local": "Data Basis",
     "value_map": {"Reported / Actual": "REPORTED", "Estimated": "ESTIMATED", "Modeled": "MODELED", "Allocated": "ALLOCATED",
                   "Interpolated": "INTERPOLATED", "Survey-Based": "SURVEY_BASED", "Mixed": "MIXED"},
     "new_values": []},
    {"shared": "Message Standard", "local": "Message Standard",
     "value_map": {"ISO 20022": "ISO_20022", "ISO 20022 setr": "ISO_20022_SETR", "ISO 20022 semt": "ISO_20022_SEMT",
                   "ISO 15022": "ISO_15022", "DTCC NSCC Record Formats": "DTCC_NSCC", "DTCC Fund/SERV": "DTCC_FUNDSERV",
                   "DTCC Networking": "DTCC_NETWORKING", "DTCC Omni/SERV Activity Record": "DTCC_OMNISERV_ACTIVITY",
                   "DTCC Omni/SERV Position Record": "DTCC_OMNISERV_POSITION", "FundsXML": "FUNDSXML",
                   "Proprietary": "PROPRIETARY", "ISO 20022 seev": "ISO_20022_SEEV", "ISO 20022 camt": "ISO_20022_CAMT"},
     "new_values": [
         ("ISO_20022_SEEV", "ISO 20022 seev", "Securities events: corporate action notification, instruction, status, movement confirmation and reversal (seev.031-seev.037)."),
         ("ISO_20022_CAMT", "ISO 20022 camt", "Cash management: bank-to-customer statements and reports (camt.052, camt.053, camt.054)."),
     ],
     "note": "Brief §8 asked to add seev and camt. 17 already asked to widen the shared definition to any inbound or "
             "outbound message; 28 uses it for custodian statements and corporate action notifications."},
]
# Frequency is not used: the brief listed it, but statement frequency was cut as a property of the feed (06 FEED- / 41).
# Regulator is not used: Prudential Regulator was removed from Custody Provider Profile (review A); 02 Organization masters
# 'Primary Regulator'.

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: local 28 lists that look like enterprise lists
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Custody Provider Role", ["02", "28"],
     "Values are custody roles of an external party. They should map one to one to 02 Party Role Type values (see "
     "PARTY_ROLE_TYPE_ADDITIONS); keep the 28 list only if 02 does not want role granularity below 'Custodian'."),
    ("Custody Holding Model", ["13", "26", "28"],
     "Direct, omnibus, individual client segregated, nominee (CSDR Article 38). 26 will need the same values for "
     "settlement accounts at CSDs; steward in 28. 13 'Holding Model' (Registered (Direct), Networked, Street Name / Omnibus) "
     "is a different concept (how a fund shareholder holds the firm's shares) and is not a merge candidate unless the SME "
     "agrees; the 28 list was renamed to avoid the collision (LOCAL_RENAMES)."),
    ("Custodian Balance Type", ["18", "26", "28"],
     "ISO 20022 sub-balance types (AWAS, BLOK, LOAN, COLI, PEND...; LOAN per MT535 field 93a, corrected from LEND). 18 encumbered and unsettled quantities and 26 "
     "settlement status could reference the same list."),
    ("Custody Break Type / Break Root Cause", ["06", "27", "28", "29"],
     "Reconciliation and control exceptions in 06 (BRK-), 27 NAV Control Check, 28 and 29 TA Control Exception share a "
     "core of types (quantity, amount, missing, valuation, timing) and causes. Propose a shared Exception Type list with "
     "local extensions, alongside the shared Reconciliation Status (CD-196)."),
    ("Lending Collateral Type", ["26", "28"],
     "26 will have a collateral type list for OTC and margin collateral; the eligible-collateral vocabulary (cash, "
     "government bonds, equities) overlaps. Share the asset vocabulary, keep the two collateral objects apart (CD-198)."),
    ("Safekeeping Account Type / Account Assignment Purpose", ["18", "26", "29", "28"],
     "18 Cash Account Purpose, 29 Cash Movement fund account and 26 settlement accounts all describe accounts mastered here. "
     "Once 18 re-points to SKA- (NOTES), 18 Cash Account Purpose should be replaced by the 28 Account Assignment Purpose."),
    ("Tax Relief Method / Tax Reclaim Status", ["27", "28", "35"],
     "Fund tax (27 Fund Tax, future 35) uses the same relief methods; candidate for a Tax list family if CD-149 creates a Tax domain."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3b. LOCAL_RENAMES (shared_code_lists.LOCAL_RENAMES format: domain, old name, new name, reason). Already applied in the
#     28 draft after review F; recorded so the consolidation does not merge the 28 lists with same-named lists elsewhere.
# ---------------------------------------------------------------------------------------------------------------------
LOCAL_RENAMES = [
    ("28", "Break Type", "Custody Break Type", "06 'Break Type' lists distribution data reconciliation breaks (Units Difference, Missing in Left...)."),
    ("28", "Holding Model", "Custody Holding Model", "13 'Holding Model' is how a shareholder holds fund shares (registered, networked, street name)."),
    ("28", "Reclaim Status", "Tax Reclaim Status", "13 'Reclaim Status' is the unclaimed property (escheatment) reclaim."),
    ("28", "Loan Status", "Securities Loan Status", "16 'Loan Status' is the participant plan loan."),
    ("28", "Lending Agreement Framework", "Lending Agreement Type", "Widened to include the authorization agreement once the lending agreement became a 28 record (CD-182)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. PARTY ROLE TYPE values proposed for 02 (CD-143, CD-195). 28 does not edit 02.
# ---------------------------------------------------------------------------------------------------------------------
PARTY_ROLE_TYPE_ADDITIONS = [
    ("02", "Party Role Type", "Sub-Custodian", "Local bank appointed by a global custodian in a market (Sub-Custodian Network Arrangement)."),
    # 26 brief also proposes CSD, CCP and tri-party agent roles; deduplicate with proposals_26 at consolidation.
    ("02", "Party Role Type", "Central Securities Depository", "CSD or ICSD in which securities are held (Securities Depository, Place of Safekeeping)."),
    ("02", "Party Role Type", "Agent Lender", "Lends securities on a fund's behalf (Securities Lending Program.Agent Lender)."),
    ("02", "Party Role Type", "Securities Borrower", "Borrows securities from the firm's funds (Securities Loan.Borrower)."),
    ("02", "Party Role Type", "Tri-Party Collateral Agent", "Holds and manages non-cash lending collateral (Lending Collateral Received)."),
    ("02", "Party Role Type", "Tax Reclaim Agent", "Files withholding tax relief documentation and reclaims (Withholding Tax Reclaim.Filing Agent)."),
    ("02", "Party Role Type", "Class Action Claims Filer", "Claims service that files class action claims (Class Action Claim.Claim Filing Agent)."),
    ("02", "Party Role Type", "Client Money Bank", "Bank holding CASS client money accounts (Safekeeping Account of type Bank Deposit Account)."),
    ("02", "Party Role Type", "Nominee Company", "Company in whose name securities are registered (Safekeeping Account.Registered Nominee)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. TERM_CONFLICTS (decisions.TERM_CONFLICTS format)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Custody Account / Safekeeping Account",
     "usages": [("12", "Custody Account (CUA-)", "Mandate custody set-up record: account opened at the client's custodian for a mandate."),
                ("18", "Portfolio.Safekeeping Custody Account; Cash Balance.Cash Account Number", "Account at the custodian holding the book's assets or cash."),
                ("28", "Safekeeping Account (SKA-)", "Every securities, cash or collateral account at a custodian or sub-custodian, for funds, portfolios and client mandates.")],
     "recommendation": "CD-194 option A: 'Safekeeping Account' (28) is the enterprise term for an account at a custodian; "
                       "'Custody Account Set-Up' (12) is the workflow record that caused one to be opened. 'Account' alone "
                       "means a 15 client account."},
    {"term": "Reconciliation",
     "usages": [("06", "Reconciliation (RCN-) / Break (BRK-)", "Distribution data reconciliation (TA, intermediary and AUM data)."),
                ("27", "NAV Control Check", "Fund accounting NAV controls (sibling)."),
                ("28", "Custody Reconciliation Run (CUREC-) / Custody Reconciliation Break", "IBOR, ABOR, cash and CASS external reconciliations against the custodian."),
                ("29", "TA Control Check (TACK-)", "Capital stock and cash proofs (sibling).")],
     "recommendation": "CD-196: keep one record per producing function; qualify the term ('Custody Reconciliation', "
                       "'Distribution Data Reconciliation', 'NAV Control Check', 'TA Control Check'); all use the shared Reconciliation Status."},
    {"term": "Entitlement",
     "usages": [("14", "Entitlement (ENT-)", "User or system entitlement to a licensed dataset."),
                ("28", "Corporate Action Entitlement (CAEN-)", "Right of a safekeeping account to cash or securities under a corporate action event.")],
     "recommendation": "Never use 'Entitlement' alone: 'Data Entitlement' (14) vs 'Corporate Action Entitlement' (28)."},
    {"term": "Collateral",
     "usages": [("18", "Holding.Encumbered Quantity; Derivative Holding Detail.Initial Margin Posted", "Derived copies of collateral positions."),
                ("26", "Collateral Movement / Collateral Balance (sibling brief)", "Collateral posted and received on derivatives and financing."),
                ("28", "Lending Collateral Received", "Collateral received from borrowers on securities loans.")],
     "recommendation": "CD-198: 'Lending Collateral' (28) vs 'Margin Collateral' / 'OTC Collateral' (26). Glossary entry for 'Collateral' must name both."},
    {"term": "Statement",
     "usages": [("07", "Compensation Statement (CPS-)", "Incentive compensation statement."),
                ("13", "Statement (STMT-)", "Investor statement, confirmation or tax document."),
                ("28", "Custodian Statement", "Holdings or cash statement received from a custodian (semt.002, MT535, camt.053, MT950).")],
     "recommendation": "Qualify: 'Investor Statement' (13), 'Custodian Statement' (28), 'Compensation Statement' (07)."},
    {"term": "Position / Holding (custodian)",
     "usages": [("06", "Position (POS-)", "Shareholder position in the firm's share classes."),
                ("18", "Portfolio Holding (HLD-)", "Instrument held by a portfolio in the IBOR."),
                ("28", "Custodian Holding Statement Line", "Holding as asserted by the custodian.")],
     "recommendation": "Extend CD-146: the custodian's view is a 'Custodian Holding Statement Line', never a 'Position'."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. CHANGES PROPOSED TO OTHER DOMAINS (for the program lead; 28 does not edit them)
# ---------------------------------------------------------------------------------------------------------------------
CHANGES_TO_OTHER_DOMAINS = [
    ("18", "Portfolio Master / Portfolio / Safekeeping Custody Account",
     "Retype from Reference (Custody Account) CUA- to Reference (Safekeeping Account, 28) SKA-, and widen the definition to all "
     "books (fund books included), or drop it in favor of 28 Safekeeping Account Assignment (Owning Portfolio). CD-194."),
    ("18", "Cash / Cash Balance / Cash Account Number",
     "Replace with 'Cash Safekeeping Account' Reference (Safekeeping Account, 28); the number itself is mastered on the SKA- record."),
    ("18", "Cash / Cash Balance / Cash Custodian",
     "Remove, or flag Derived copy (28): the custodian is the SKA- Account Provider."),
    ("18", "Holdings / Portfolio Holding / Encumbered Quantity",
     "Future owners now drafted: on-loan quantity is 28 Securities Loan.Loan Quantity (Derived copy 28); pledged collateral stays 26."),
    ("12", "Mandate Operational Set-Up / Custody Account",
     "Option A: add 'Created Safekeeping Account' Reference (Safekeeping Account, 28); flag Custodian BIC as Derived copy (02, "
     "CD-013) and Safekeeping Account Number as Derived copy (28), or remove both. Option B: move the object to 28 unchanged."),
    ("12", "Mandate Operational Set-Up / Standing Settlement Instruction / Safekeeping Account",
     "Retype to Reference (Safekeeping Account, 28) SKA- (neutral to CD-155; the same change applies if SSIs move to 26)."),
    ("15", "Intermediary, Institutional & Program Servicing / relationship 'Account (Institutional) is set up at the custodian as Custody Account [12]'",
     "Add: 'Account is the owner of Safekeeping Account [28] via Safekeeping Account Assignment'. No 15 Account Type is added (CD-194)."),
    ("15", "Account Identifier / Account Identifier Scheme value 'Custodian Account Number'",
     "Program lead decision 3: the safekeeping account number is mastered in 28 (Safekeeping Account Number). Where a 15 "
     "Account Identifier of scheme 'Custodian Account Number' identifies an SMA or mandate account at its custodian, flag the "
     "value Derived copy (28) with the row rule 'equals the Safekeeping Account Number of the SKA- assigned to the ACC-'. Rows "
     "that carry an investor's brokerage or intermediary account number (RIA channel) stay mastered in 15."),
    ("01", "Product Parties & Roles / Product Party Role (Custodian, Depositary / Trustee)",
     "No change. Consistency check for 21 data quality: the Account Provider of a fund's Main Safekeeping account (28) must "
     "equal the party appointed as Custodian or Depositary / Trustee on the fund in 01. 01 holds the appointment, 28 the accounts."),
    ("17", "Corporate Action Events / Corporate Action Event (type Class Action, CLSA)",
     "28 Class Action Claim now references the 17 event for case facts. Ask 17 to hold, for Class Action events: case name, "
     "court or jurisdiction, class period start and end (or as event dates), and the claim filing deadline as the option's "
     "Market Deadline. 28 removed Case Name, Case Jurisdiction, Class Period Start / End, Settlement Class Instrument and "
     "Claim Filing Deadline from the claim."),
    ("27", "ABOR Investment Accounting / Income Accrual",
     "28 Income Collection references the accrual row booked on the ex-date (dividends) or payment date (interest) and derives "
     "the expected net amount as Accrued Income Balance less Withholding Tax Accrued Amount. 27 has no separate declared "
     "income entitlement or receivable object; if 27 adds one (for example an Income Receivable on ex-date), 28 should "
     "reference it instead. 27's Related Income Collection example key should become the CAEN- of the income entitlement."),
    ("01", "Investment Objective & Policy / Securities Lending Permitted Indicator",
     "No change; 28 Securities Lending Program requires it to be Y. Add the fund's maximum on-loan percentage to 01 as a "
     "policy limit; 28 Maximum On-Loan Percentage is marked provisional (future owner 01)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Register SKA-, CUREC-, CAEN-, ELECT-, WHTR-, SCAC-, SBL-, CMC- (owner 28) in decisions.PREFIXES. Self-references in 28 "
    "use 'Reference (X, 28)', so they resolve before and after registration.",
    "Add CONCEPT_OWNERSHIP rows: Safekeeping Account (28, SKA-), Custody Reconciliation Run (28, CUREC-), Corporate Action "
    "Entitlement (28, CAEN-), Corporate Action Election (28, ELECT-), Withholding Tax Reclaim (28, WHTR-), Class Action Claim "
    "(28, SCAC-), Securities Loan (28, SBL-), Client Money Calculation (28, CMC-), Custody Provider Profile (28, keyed by PTY-), "
    "CASS Firm Profile (28, keyed by LEN-). Expected referrers: 12, 18, 26, 27, 29, 38.",
    "Sibling references made: 22 'Approved Price' (PRICE-), 24 'Investment Decision' (IDEC-), 26 'Settlement Instruction' (SETL-; "
    "the 26 brief appeared during drafting, so the reference was changed from a placeholder 'Trade Settlement'), 27 'ABOR Valuation Record', "
    "'Income Accrual' and 'Fund Journal Entry' (FJNL-), 29 'AP Creation / Redemption Order' (ECR-). Re-check these names when "
    "the sibling drafts land.",
    "27 Income Accrual should reference 28 Income Collection (its brief says so); 29 Cash Movement references 28 SKA- for the "
    "fund dealing account; 27 Fund Expense Payment covers custody fees, so 28 Custodian Service Review holds only a fee-review indicator.",
    "Derived copies in 28: Income Collection Expected Net Income Amount (27) and Income Due Date (17, the event payment date).",
    "Per-row ownership (plan §4 item 9): no 28 object mixes rows mastered here with rows copied from another domain. "
    "Custodian statements, lines and entries are the custodian's records as received and are mastered here as such.",
    "CD-197: 38 (Stage 4) should reference Client Money Calculation, CASS Acknowledgment Letter, the CASS reconciliation types "
    "of Custody Reconciliation Run and CASS Firm Profile, and not master CASS records itself.",
    "Securities lending SEC Rule 10c-1a: compliance date moved to 28 September 2028 by SEC exemptive order of December 2025 "
    "(after the Fifth Circuit remand); Loan Regulatory Report carries a Reporting Deferred Indicator.",
    "CD-182 applied: 28 masters the securities lending agreement (Securities Lending Agreement, keyed lending program x agent "
    "x counterparty) for both the authorization agreement and master agreements with borrowers. 39 will index the document only. "
    "Custody and depositary agreements stay a document code on Custody Provider Profile until 39 exists.",
    "Income recorded once (review B, program lead decision 1): Corporate Action Payment holds income received and tax withheld; "
    "Income Collection is the control record (one per income entitlement) and holds no received amount; Withholding Tax Reclaim "
    "references the payment and holds no withheld amount.",
    "Composite keys of 28 lending objects start with PRD- / PTY- in examples; enrich_28.py forces them to mastered here with "
    "OWNERSHIP_OVERRIDES. Registering a concept-ownership row for 'Securities Lending Program' and 'Securities Lending "
    "Agreement' (28) does not remove the need, because example prefixes take precedence in ownership.py.",
    "CITs: an internal trustee bank that self-custodies is recorded as Provider Legal Entity (09 LEN-) on Custody Provider "
    "Profile and Internal Account Provider on Safekeeping Account, with the rule that exactly one of the party and entity "
    "references is filled (program lead decision 7).",
    "Verified assets (AIFMD 'other assets', private fund interests) are a Safekeeping Account Type value 'Ownership "
    "Verification Record' and a statement type, not a separate family, as the brief proposed.",
]
