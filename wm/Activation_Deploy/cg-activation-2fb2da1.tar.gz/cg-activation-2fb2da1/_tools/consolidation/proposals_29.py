"""Consolidation proposals from Data Domain 29 - Transfer Agency Operations (Stage 2 draft v0.1, revised after review, 2026-10-06).

Proposal fragment only: the builder does not read it. The Stage 2 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Format follows CONTRACT.md in this folder. Boundary decisions CD-199 to CD-202
are in proposals_stage2_b.py; this file lists only what the draft found beyond them, including the program lead's
decisions on the 29 review (00_Program/Expansion/Reviews/29_review.md).
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones. None needed.
#    29 uses only the reserved FNDO-, FBAT-, ECR-, CIP-, AMA- and TACK- (proposals_stage2_b.py). Records without their own
#    prefix are keyed by their grain or a firm-defined key: Cash Movement ID (e.g. "PAY 20261006 000123"), Interface
#    Session Key ("FUNDSERV-20261005-EOD") and Price Transmission Key ("NAV-... / channel / attempt").
#    Settlement Obligation IDs are formed from the order ID plus a sequence ("FNDO-2026-00418273-S1", "ECR-...-S1"):
#    the FNDO- / ECR- part identifies the parent order, not a second entity type.
#    Settlement batch IDs carry a data-basis suffix ("FBAT-20261006-0226-USD-E" estimated, "-F" final).
#    Examples cite sibling prefixes as their owners write them: BSKT- (24), SETL- (26), NAV- / NEC- (27), SKA- (28),
#    and TACK- in the format 27 uses ("TACK-2026-1005-004512").
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local lists in 29 that carry the exact name and values of an enterprise shared list.
#    Register 29 as a member (or direct user) of each. (local list name in 29, shared list name, note)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    ("Dealing Route", "Dealing Route", "Order routing, AP order channel and interface sessions. Values copied unchanged."),
    ("Message Standard", "Message Standard", "Order message standard. Values copied unchanged."),
    ("Networking Level", "Networking Level", "Networking level as delivered on the order. Values copied unchanged."),
    ("Flow Direction", "Flow Direction", "Settlement obligation, batch, payment and AP cash component direction; only Inflow and Outflow are used."),
    ("Data Basis", "Data Basis", "Estimated vs final settlement batch totals (part of the batch key); only Reported / Actual and Estimated are used."),
    ("Case Status", "Case Status", "Work status of order exceptions, settlement exceptions, alerts, 22c-2 requests and control exceptions."),
    ("Screening Result", "Screening Result", "Payment screening and sanctions alert match outcome. The party's latest result stays in 02 KYC Profile."),
    ("Severity", "Severity", "Alert priority and control exception severity."),
    ("Reconciliation Status", "Reconciliation Status", "TA control results and interface session balancing (CD-196)."),
    ("Information Classification", "Information Classification", "Alert disposition classification; 'Restricted - Legal' for SAR-related records (31 CFR 1024.320(e))."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: local 29 lists that look like enterprise lists.
#    (list name in 29, proposed shared list name, likely other users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Cost Bearer", "Cost Bearer", ["13", "27"],
     "29 copies 13 'Cost Bearer' (Fund, Adviser, Shared Fund / Adviser, Service Provider, Intermediary) for as-of dilution. 27 "
     "NAV Error Case (reimbursing party) needs the same list. Make it shared, steward 13 or 27."),
    ("NAV Dissemination Channel", "NAV Dissemination Channel", ["27"],
     "29 copies 27 'NAV Dissemination Channel' unchanged for Price & Rate Transmission / Transmission Channel. Register it as a "
     "shared list stewarded by 27 with 29 as a member, so the release (27) and the transmission (29) use one channel vocabulary."),
    ("Order Settlement Method", "Fund Dealing Settlement Method", ["05"],
     "Settlement venue or arrangement only (DvP / FoP removed; securities settlement is 26 Settlement Instruction / Against "
     "Payment Indicator). The first four values are exactly 05 'Settlement Method' (Trading Setup); merge 05 into it. Keep it "
     "apart from 17 'Settlement Method' (cash vs physical settlement of derivatives)."),
    ("Order Payment Method", "Payment Method", ["19"],
     "Payment instrument or rail of a cash movement. 19 has a local 'Payment Method' (ACH Credit, Wire Transfer, SEPA Credit "
     "Transfer, UK Faster Payment, BACS, CHAPS, Check, Corporate Card, Netting) for supplier payments; 29 renamed its list to "
     "avoid the collision. Candidate enterprise list covering both (wire split into Fedwire / CHAPS / TARGET2; add NSCC "
     "Settlement Payment, Internal Book Transfer, Bacs Direct Debit)."),
    ("Order Settlement Status", "Settlement Status", ["10", "26"],
     "Renamed from 'Settlement Status' because 10 has one (Pending, Invoiced, Settled, Netted: distribution payments) and 26 has "
     "one (Pending, Failing, Partially Settled, Settled, Canceled, Reversed: securities settlement). 29 values: Pending, "
     "Instructed, Settled, Partially Settled, Failed, Returned, Canceled. 26 and 29 are close (cash vs securities settlement); "
     "consider one enterprise list with Failing/Failed and Returned/Reversed aligned. 10 stays NOT_MERGED."),
    ("Order Exception Type", None, ["13"],
     "NOT_MERGED with 13 'NIGO Reason': after review the 29 list holds dealing exceptions only; request NIGO reasons (signature, "
     "documents, authority, account not identified on a letter) are recorded on the originating 13 Service Request."),
    ("Basket Settlement Form", None, ["06", "24"],
     "06 'ETF Basket Type' (In-Kind, Cash, Custom Basket, Hybrid) mixes settlement form with standard vs custom basket. 29 keeps "
     "settlement form only; standard vs custom is the 24 ETF Basket's type. Value map once 06 Basket Type becomes a Derived copy "
     "(29): In-Kind -> In-Kind, Cash -> Cash, Hybrid -> Hybrid, Custom Basket -> read from 24."),
    ("Fund Order Status", None, ["06"],
     "NOT_MERGED with 06 'Transaction Status' (status of the confirmed transaction record). 29 is the order lifecycle only; "
     "'Settled' was removed (settlement state is read from Settlement Obligation)."),
    ("Monitoring Alert Disposition", None, ["08"],
     "Renamed from 'Alert Disposition' because 08 has one for surveillance alerts. Different alert families; NOT_MERGED."),
    ("TA Control Type", None, ["27"],
     "NOT_MERGED with 27 'NAV Control Check Type': both carry 'Capital Stock Proof' and 'Cash Proof'. 29 TACK- is the control; 27 "
     "NAV Control Check references it (Related TA Control Check) and does not compute its own difference (CD-196)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS noticed with existing and sibling domains (decisions.py format)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Price Transmission / NAV Dissemination",
     "usages": [("27", "NAV Dissemination", "Release of a share class NAV: what was released, to which channel, when, and whether it corrects an earlier release"),
                ("29", "Price & Rate Transmission", "Delivery of a 27 release to one channel: transmission timestamp, status, acknowledgment and late flag per channel and attempt")],
     "recommendation": "Program lead decision on the 29 review: one record each. 27 NAV Dissemination masters the release; 29 Price & Rate Transmission masters the per-channel transmission and references the 27 release (Transmitted Dissemination). 29 no longer holds the NAV record, correction flag, NAV error case or rates-included flag. 27 'TA Transmission Record' can reference 29 Price Transmission Key and drop its ownership override; 27 Late Dissemination Indicator should be read as the release deadline, 29 Transmission Late Indicator as the channel deadline."},
    {"term": "Order",
     "usages": [("29", "Fund Order (FNDO-)", "Instruction to subscribe, redeem, exchange or transfer fund shares, as received and processed by the TA"),
                ("25", "Trade Order (TORD-)", "Order to buy or sell a security for a managed portfolio"),
                ("06", "Order Source (attribute group of Transaction)", "How the order behind a confirmed transaction reached the TA")],
     "recommendation": "Never use 'Order' bare in the glossary: 'Fund Order' (shareholder dealing, 29), 'AP Order' (ETF primary market, 29), 'Trade Order' (portfolio trading, 25)."},
    {"term": "Transaction",
     "usages": [("06", "Transaction (TXN-)", "Confirmed shareholder dealing for attribution and AUM"),
                ("29", "Fund Order (FNDO-) / Resulting Transaction", "The order that results in a 06 transaction"),
                ("16", "Contribution Record / Distribution Request", "Participant-level plan transactions in firm-recordkept plans"),
                ("18", "Portfolio Transaction (PTXN-)", "Investment transaction in a managed book")],
     "recommendation": "Shareholder transaction = 06; the operational instruction before confirmation = 29 Fund Order (CD-199); participant plan activity = 16, which reaches 29 only as an aggregated plan-level order."},
    {"term": "Settlement",
     "usages": [("29", "Settlement Obligation / Intermediary Settlement Batch (FBAT-)", "Money settlement of fund orders and of the AP cash leg with intermediaries, NSCC, APs and investors"),
                ("26", "Settlement Instruction (SETL-)", "Settlement of securities trades, including in-kind ETF basket deliveries (type In-Kind Creation / Redemption)"),
                ("10", "Settlement Status", "Settlement of distribution payments")],
     "recommendation": "Qualify: 'Order Settlement' (29), 'Trade Settlement' (26), 'Payment Settlement' (10). 29 Basket Settlement Line references the 26 Settlement Instruction (line level); 26 references the AP order (order level). Both links are kept because the grains differ."},
    {"term": "Reconciliation",
     "usages": [("06", "Reconciliation Type 'TA vs Fund Accounting'", "Distribution data reconciliation of shares outstanding between TA feed and fund accounting"),
                ("29", "TA Control Check 'Capital Stock Proof'", "Daily TA control proving the register against 27 shares outstanding"),
                ("27", "NAV Control Check (Related TA Control Check)", "Fund accounting side of the same proof")],
     "recommendation": "The capital stock proof is one control (29 TACK-) that 27 references (SME question 6). Rename the 06 value 'TA Feed vs Fund Accounting Feed' or retire it in favor of 29 TACK- (CD-196)."},
    {"term": "Alert",
     "usages": [("29", "Account Monitoring Alert (AMA-) / Account Monitoring Alert ID", "AML, sanctions and fraud alert on a shareholder account"),
                ("08", "Surveillance Alert (SURV-) / Alert ID", "Communications and sales practice surveillance")],
     "recommendation": "Qualify every alert by family. 29 renamed its key to 'Account Monitoring Alert ID'; 08 could rename 'Alert ID' to 'Surveillance Alert ID'."},
    {"term": "Trade Date",
     "usages": [("29", "Fund Order.Trade Date Assigned / As-Of Order Detail.As-Of Trade Date", "Dealing day assigned (processing day for as-of orders) and the earlier pricing day of an as-of order"),
                ("06", "Transaction Dates.Trade Date / As-Of Date", "Same split on the confirmed transaction")],
     "recommendation": "For TA-sourced rows 06 Trade Date and As-Of Date become Derived copy (29) under the same row rule as Order Source (CD-199)."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. CROSS_DOMAIN_CHANGES proposed (not applied; the 29 draft does not edit other modules)
# ---------------------------------------------------------------------------------------------------------------------
CROSS_DOMAIN_CHANGES = [
    ("13", "Service Request", "Add 'Resulting Order' (Reference (Fund Order, 29), FNDO-) beside 'Resulting Transaction' (CD-199)."),
    ("06", "Transaction", "Add 'Originating Fund Order' (FNDO-) and 'Originating AP Order' (ECR-) (CD-199, CD-200)."),
    ("06", "Order Source", "Order Entry Channel and Order Message Type become Derived copy (29) for TA-processed rows; row rule note (plan §4 item 9)."),
    ("06", "Intermediary As Delivered", "Dealer / Firm Number, Clearing Firm Number, Branch Number and Representative Number become Derived copy (29) for TA-processed rows (29 Order Routing Detail as-delivered codes). The resolved firm, office and rep stay mastered in 06; 29 Resolved Dealer and Resolved Representative are Derived copies (06). 06 Representative Number should carry the same PII flag as 29."),
    ("06", "Transaction", "Source Transaction Reference becomes Derived copy (29) of Fund/SERV Control Number or Platform Order Reference for TA-processed rows."),
    ("06", "Transaction Dates", "Trade Date and As-Of Date become Derived copy (29) for TA-processed rows (Trade Date Assigned, As-Of Trade Date)."),
    ("06", "Transaction Amounts", "Net Amount stays mastered in 06; 29 Settlement Obligation / Obligation Amount is its Derived copy for fund orders (program lead decision)."),
    ("06", "ETF Creation / Redemption", "Authorized Participant, Creation Units and Basket Type become Derived copy (29) for orders the TA processed; Basket Type maps to Basket Settlement Form."),
    ("02", "Identity Document (new)", "Propose an 02 Identity Document record (party x document type x issuing country; number masked, place of issuance, issue and expiry dates; restricted) to hold the document details 31 CFR 1024.220(a)(3) requires to be recorded. 29 CIP Verification will then reference it ('Verified Identity Document'); until then 29 holds only the method and outcome."),
    ("02", "Party Role Type", "Add 'Authorized Participant' (CD-143, CD-200)."),
    ("05", "Agreement Type", "Add 'Authorized Participant Agreement' if missing (CD-200)."),
    ("18", "Portfolio Capital Activity", "Add optional 'Source Settlement Batch' (Reference (Intermediary Settlement Batch, 29), FBAT-). 18 'Capital Activity Source' already has 'Transfer Agent Estimate', 'Transfer Agent Final' and 'Authorized Participant Order', so no new value is needed."),
    ("27", "Swing Pricing Decision", "Net Capital Activity Estimate is sourced from 29 Fund Order 'Estimated Order Value' totals and estimated Intermediary Settlement Batches."),
    ("27", "NAV Dissemination", "TA Transmission Record references 29 Price Transmission Key; the 27 ownership override for it can be dropped."),
    ("26", "Settlement Instruction", "No change: Related AP Order (ECR-) stays; 29 Basket Settlement Line references SETL- per line."),
    ("16", "Payroll Contribution Batch", "No change: 29 Fund Order references it (Source Plan Contribution Batch) for plan-level orders from the firm's own recordkeeping platform."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Brief §5 objects all kept (6 families, 22 objects, 18 BO / 4 AG). Shared list copies follow the Stage 2 addendum: local lists with the shared name and values, registered via SHARED_MEMBERSHIPS.",
    "Local list renames to avoid collisions: 'Settlement Status' -> 'Order Settlement Status' (10, 26), 'Alert Disposition' -> 'Monitoring Alert Disposition' (08), 'Settlement Method' -> 'Order Settlement Method' (05, 17), 'Payment Method' -> 'Order Payment Method' (19), 'CIP Exemption Reason' -> 'CIP Exemption or Exclusion Reason'.",
    "Review changes that alter grain: Settlement Obligation now covers fund orders and the AP cash leg (row rule: one of the two order references); Intermediary Settlement Batch key includes Data Basis; Settlement Exception may attach to a batch; TA Processing Calendar Event is keyed by dealing calendar with an optional share class; Cash Movement, Order Interface Session and Price & Rate Transmission have firm-defined keys.",
    "Row-rule derived copies (plan §4 item 9): Obligation Amount (06 for fund orders, mastered here for AP cash legs) and Comparison Value (27 for capital stock proof, 28 for cash proof, blank for threshold controls) are flagged by their main source; the catalog should show the row-rule note.",
    "SAR confidentiality: Alert Disposition value 'Escalated for SAR Decision', Escalation Case Reference, Alert Status and Disposition Rationale are restricted (31 CFR 1024.320(e)); Disposition Information Classification records 'Restricted - Legal'. When 38 exists, Escalation Case Reference becomes a Reference to the 38 case.",
    "Local list count is 27, above the brief's 18 to 24, because review fixes split mixed lists (Order Payment Method from Order Settlement Method) and added Identity Verification Regime, Control Measure Unit and Transmission Status.",
]
