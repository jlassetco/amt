"""Consolidation proposals from the Data Domain 30 (Private Markets) draft, 2026-10-06 (revised after review 30_review.md).

Proposal fragment only: the builder does not read this file. The Stage 2 consolidation step merges accepted entries into
decisions.py, shared_code_lists.py and the 01, 02, 06, 13, 15, 17, 18, 20, 21, 22, 24 and 27 content modules. Formats follow
CONTRACT.md. Boundary decisions CD-203 to CD-205 are in proposals_stage2_b.py; this file adds only what the draft found.
Program lead decision applied: 30 masters every fund-level fact about the firm's own private funds.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES (decisions.PREFIXES format). None beyond the eight reserved in proposals_stage2_b.py:
#    ICMT-, CAPA-, CCN-, PDIS-, PDL-, FCF-, DWF-, CLOSE-. Move them from Reserved to Registered at consolidation.
#    All other 30 objects use composite keys (e.g. Capital Call Allocation = CCN- x ICMT-; Private Investment =
#    fund x portfolio company x initial investment date; Facility Drawdown = FCF- x drawdown number).
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

PREFIX_REGISTRATIONS = ["ICMT-", "CAPA-", "CCN-", "PDIS-", "PDL-", "FCF-", "DWF-", "CLOSE-"]

# ---------------------------------------------------------------------------------------------------------------------
# 2. CONCEPT_OWNERSHIP rows (decisions.CONCEPT_OWNERSHIP format: concept, owner, prefix, referencing domains, note)
# ---------------------------------------------------------------------------------------------------------------------
CONCEPT_OWNERSHIP = [
    ("Private Fund Profile", "30", "", ["17", "18"], "Keyed by 01 PRD-. Planned: 17 Fund Interest Terms and 18 Private Fund Portfolio Detail derive own-fund values (ROW_RULES), 35 Form PF."),
    ("Fund Close", "30", "CLOSE-", ["17"], "Final close date is the source of 17 Final Close Date for own private funds (row rule)."),
    ("Investor Commitment", "30", "ICMT-", ["15", "18"], "Held on a 15 ACC- (CD-203). Planned: 18 Fund Interest Holding Detail (own funds), 21 metric definitions, 12 ILPA reports."),
    ("Investor Capital Account", "30", "CAPA-", ["18", "12"], "Commitment x period x basis; the third kind of position (CD-146, CD-203). 18 own-fund holding values derive from it."),
    ("Capital Call", "30", "CCN-", ["27", "18"], "27 Fund Journal Line 'Source Capital Call'; 18 Portfolio Capital Activity 'Capital Call Proceeds' rows derive from it."),
    ("Private Fund Distribution", "30", "PDIS-", ["18", "27"], "18 Portfolio Capital Activity 'Distribution to Investors' rows derive from it. Term: 'Private Fund Distribution' (not 27 FDIV-)."),
    ("Deal (private markets)", "30", "PDL-", ["24"], "24 expects Deal Allocation (30) and references deal approvals through its Investment Committee Decision."),
    ("Deal Allocation", "30", "", ["24"], "Deal x recipient fund or co-investor; satisfies the proposals_24 'Deal Allocation' term entry."),
    ("Portfolio Company Profile", "30", "", ["22"], "Keyed by 02 PTY-; 22 Fair Value Determination 'Valued Portfolio Company' (proposals_22 needs an ownership override because the key is PTY-)."),
    ("Private Investment", "30", "", ["22"], "Fund x portfolio company x initial investment date; valued by 22 FVD- per instrument."),
    ("Fund Credit Facility", "30", "FCF-", ["27"], "Planned: 27 facility interest accruals, 35 Form PF / Annex IV borrowings; 18 Subscription Credit Facility Indicator derives from it."),
    ("Waterfall Calculation", "30", "DWF-", ["27"], "Planned: 27 carry accrual journals."),
    ("Partner Tax Allocation", "30", "", ["13"], "CD-149; proposed: 13 Tax Form Record rows of type 'Schedule K-1' reference it and hold no amounts of their own."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_MEMBERSHIPS: local lists in content_30 that carry the exact name and values of an enterprise shared list.
#    Register "30" as a member (identity value_map), or as a direct user and switch the attributes to "Shared: <name>".
#    (shared list name, domain, local list name, attributes that use it)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    ("Record Status", "30", "Record Status", "Fund Credit Facility.Facility Status"),
    ("Approval Status", "30", "Approval Status", "Subscription Document Review.Review Decision; Commitment Transfer.GP Consent Status; Deal Allocation.Allocation Approval Status; Waterfall Calculation.Calculation Approval Status"),
    ("Data Basis", "30", "Data Basis", "Investor Capital Account.Capital Account Data Basis; Partner Tax Allocation.Tax Allocation Data Basis; Portfolio Company Financial Metric.Metric Data Basis; Carried Interest Position.Carry Data Basis"),
    ("Period Type", "30", "Period Type", "Investor Capital Account.Capital Account Period Type; Portfolio Company Financial Metric.Metric Period Type"),
    ("Reporting Period Basis", "30", "Reporting Period Basis", "Capital Account Fee & Expense Detail.Line Period Basis"),
    ("Frequency", "30", "Frequency", "Portfolio Company Profile.Company Reporting Frequency"),
    ("Outgoing Payment Status", "30", "Outgoing Payment Status", "Distribution Allocation.Payment Status"),
    ("Measure Unit (proposed by 22)", "30", "Measure Unit", "Portfolio Company Financial Metric.Metric Unit (copy of the 22 local list; proposals_22 lists 30 as a user)"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. SHARED_CANDIDATES: local lists that look like enterprise lists (list, domains, note)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Private Fund Strategy", ["01", "17", "30", "24"],
     "Decision (program lead): 01 Asset Class / Sub-Asset Class owns the classification; Private Fund Strategy is its private-markets "
     "sub-class, flagged Derived copy (01) on Private Fund Profile, each value mapped to a 01 Asset Class. Propose the values as the "
     "01 Sub-Asset Class values for private strategies, with 17 and 30 reading them."),
    ("Administration Operating Model", ["18", "27", "28", "29", "30"],
     "In House / Outsourced / Co-Sourced (CD-147). 18 has an IBOR Operating Model; the 27-29 modules have similar fields. "
     "Propose one shared 'Operating Model' list."),
    ("Capital Call Purpose", ["18", "30"],
     "Align values with the ILPA Capital Call & Distribution Template (2025) transaction types."),
    ("Portfolio Company Ownership Type", ["17", "22", "30"],
     "Control vs minority drives IPEV valuation approach (22) and Form PF reporting (35). Candidate shared list stewarded by 30."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. CHANGE PROPOSALS to other domains (proposed, not applied)
#    (domain, object / list, proposed change, rationale)
# ---------------------------------------------------------------------------------------------------------------------
VALUE_PROPOSALS = [
    ("15", "list Account Type", "Add value 'Private Fund Investor Account'", "CD-203: account on which an Investor Commitment (ICMT-) is held."),
    ("02", "list Party Role Type", "Add values Limited Partner Investor; Fund Lender; Placement Agent; Fund Holding Vehicle",
     "CD-143 / CD-205 (Portfolio Company already proposed by 17)."),
    ("13", "list Investor Tax Document Type and object Tax Form Record", "Add value 'Schedule K-1'; for K-1 rows add Reference (Partner Tax Allocation, 30) and hold no box amounts (Reported Amount for K-1 rows is a Derived copy (30) if kept); 13 Tax Form Version 'Corrected' maps to a 30 Allocation Version Number above 1",
     "Program lead decision: Partner Tax Allocation masters the allocation; 13 delivers it (CD-149)."),
    ("06", "attribute group Flow Treatment Rule (of Measure Definition)", "Add attribute 'Private Fund Treatment' using the Treatment Option list, with a value such as 'Exclude (Private Fund Drawdown)'",
     "CD-204: 06 Flow Measures explicitly exclude Vehicle Type 'Private Fund (Drawdown)'. Evergreen private funds pending SME question 3."),
    ("21", "object Metric Definition (records)", "Register four metric definition records: Private Fund Commitments Raised; Private Fund Capital Called; Private Fund Distributions; Private Fund Net Invested Capital",
     "CD-204: sourced from 30 Commitment Change, Capital Call Allocation and Distribution Allocation."),
    ("24", "list Committee Decision Type", "Add values 'Private Investment Approval'; 'Private Investment Follow-On or Exit Approval'",
     "30 Deal (initial approval) and Investment Ownership Period (follow-on or exit) reference the 24 Investment Committee Decision."),
    ("24", "proposals_24 TERM_CONFLICTS 'Allocation'", "Confirm '30 Deal Allocation (Stage 2)' now exists: object Deal Allocation (deal x recipient fund or co-investor)", "Review finding A (Deal / Target Fund)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. ROW RULES (plan §4 item 9): attributes in other domains that become Derived copies of 30 for the firm's own private
#    funds (program lead decision 1). Third-party fund rows stay mastered where they are. Do not edit 17 or 18 here.
#    (domain, object, attribute(s), 30 source, rule)
# ---------------------------------------------------------------------------------------------------------------------
ROW_RULES = [
    ("18", "Fund Interest Holding Detail",
     "Commitment Amount; Called Capital to Date; Recallable Distributions; Unfunded Commitment; Distributions Received to Date",
     "Investor Commitment.Commitment Amount; Investor Capital Account.Cumulative Contributions, Recallable Distribution Balance, Unfunded Commitment, Cumulative Distributions",
     "Where the held instrument is an interest in an own private fund, Derived copy (30) from the commitment on the portfolio's 15 account and its latest final capital account."),
    ("18", "Fund Interest Holding Detail", "GP Reported NAV; GP Statement Date",
     "Investor Capital Account.Ending Capital Balance; Capital Account Period End Date (latest final version)",
     "Own private fund rows: Derived copy (30)."),
    ("18", "Fund Interest Holding Detail", "Adjusted NAV",
     "Ending Capital Balance rolled forward for Capital Call Allocations and Distribution Allocations after the period end",
     "Own private fund rows: Derived copy (30). CD-170 makes the third-party value a 22 Fair Value Determination; for own funds the roll-forward inputs are 30."),
    ("18", "Private Fund Portfolio Detail", "Vintage Year",
     "Private Fund Profile.Vintage Year", "Books that implement an own private fund: Derived copy (30)."),
    ("18", "Private Fund Portfolio Detail", "Subscription Credit Facility Indicator",
     "Exists a Fund Credit Facility of type Subscription Line or Hybrid Facility with Facility Status Active for the implemented fund",
     "Books that implement an own private fund: Derived copy (30)."),
    ("18", "Portfolio Capital Activity", "Activity Amount Base (and dates) for Capital Activity Type 'Capital Call Proceeds' and 'Distribution to Investors'",
     "Capital Call (CCN-) Total Called Amount and Call Due Date; Distribution (PDIS-) Total Distribution Amount and Distribution Payment Date",
     "Rows of these two types on a private fund's own book are Derived copy (30); propose a Reference (Capital Call, 30) / (Distribution, 30) on the row for lineage."),
    ("17", "Fund Interest Terms",
     "Vintage Year; Private Fund Strategy; Commitment Currency; Final Close Date; Investment Period End Date; Fund Term Years; Fund Term Extension Years",
     "Private Fund Profile (same attribute names; Commitment Currency itself derives from 01 Base Currency) and Fund Close.Close Date where Close Type = 'Final Close'",
     "Instruments that are interests in an own private fund: Derived copy (30). 30 renamed 'Maximum Term Extension Years' to 'Fund Term Extension Years' to match 17."),
    ("30", "Fund Structure Link", "Fund Structure Link Type",
     "01 Product Relationship (Parallel Vehicle, Master - Feeder)",
     "Rows of type Parallel Fund and Feeder Fund are Derived copies of 01; all other rows are mastered in 30. Flagged Derived copy (01) in enrich_30.py."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. TERM_CONFLICTS (decisions.TERM_CONFLICTS format)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Position",
     "usages": [("06", "Position", "Units of an own share class held by an account (POS-)"),
                ("18", "Portfolio Holding", "Instrument held by a portfolio (HLD-)"),
                ("30", "Investor Capital Account", "Investor's commitment and capital in a private fund for a period (CAPA-)"),
                ("30", "Carried Interest Position", "Fund-level carry accrued, paid and exposed to clawback")],
     "recommendation": "Extend the CD-146 conflict: the three kinds of position are Shareholder Position (06), Portfolio Holding (18) "
                       "and Investor Capital Account (30). 'Carried Interest Position' keeps its brief name pending a program lead decision "
                       "(review suggests 'Carried Interest Balance'); never use 'Position' bare."},
    {"term": "Vintage Year",
     "usages": [("30", "Private Fund Profile", "Year of the fund's first capital call for investment purposes"),
                ("17", "Fund Interest Terms", "Year of the underlying fund's first close or first capital call, per firm convention"),
                ("18", "Private Fund Portfolio Detail", "Year of the book's first investment")],
     "recommendation": "One enterprise definition, mastered in 30 for own funds: the year of the fund's first capital call for investment "
                       "purposes (ILPA / GIPS practice; confirm with performance, future 32). 17 and 18 copy it for own funds (ROW_RULES) "
                       "and use the same definition for third-party funds."},
    {"term": "Close",
     "usages": [("30", "Fund Close", "Admission of investors to a private fund"),
                ("19", "Accounting Period Close", "Period-end close of the corporate books"),
                ("27", "Fund accounting period end", "Fund accounting period end")],
     "recommendation": "Use 'Fund Close' (30) and 'Period Close' (19, 27)."},
    {"term": "Carried Interest / Carry",
     "usages": [("30", "Carried Interest Position; Distribution Waterfall Terms", "Fund-level carry pool and terms"),
                ("20", "Variable Compensation Award (Carried Interest Points)", "Employee's share of a fund's carry pool"),
                ("01", "Performance Fee", "Open-end and mandate performance fee; not carry")],
     "recommendation": "'Carried Interest' is the fund-level 30 concept; 20 keeps Variable Compensation Award with Carried Interest Points "
                       "for the employee share; 01 Performance Fee never holds carry (CD-205)."},
    {"term": "Deal",
     "usages": [("30", "Deal", "Private markets investment opportunity (PDL-)"),
                ("03", "Opportunity", "Sales opportunity (OPP-)"),
                ("25", "Trade", "Executed trade")],
     "recommendation": "Use 'Private Markets Deal' (30) in the glossary; 03 keeps 'Opportunity'; 25 uses 'Trade'."},
    {"term": "Due Diligence",
     "usages": [("30", "Due Diligence Workstream", "Firm's diligence on a target company"),
                ("08", "Distributor Due Diligence", "Firm's diligence on a distributor (DDQ-)"),
                ("03", "RFP / DDQ response", "Firm's answers to an investor's DDQ, including the ILPA DDQ (RFP-)")],
     "recommendation": "Qualify: Deal Due Diligence (30), Distributor Due Diligence (08), Client DDQ Response (03)."},
    {"term": "Equalization",
     "usages": [("30", "Equalization", "Rebalancing among investors admitted or increased at different closes"),
                ("27", "Income equalization", "Open-end fund income equalization on subscriptions")],
     "recommendation": "Use 'Close Equalization' (30) and 'Income Equalization' (27)."},
    {"term": "Benefit Plan Investor",
     "usages": [("30", "Investor Commitment.Benefit Plan Investor Indicator", "ERISA 25% test status, includes IRAs and plan-asset entities"),
                ("02", "Institutional Client.ERISA Plan Indicator", "Party is an ERISA plan")],
     "recommendation": "Glossary note: related but different; 30 may read the 02 indicator as one input. Optionally propose a 02 classification value."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 8. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Sibling references use the module names: 22 'Fair Value Determination' (relationship only; no attribute pointer), 24 "
    "'Investment Committee Decision' (key committee / meeting date / item), 27 'Fund NAV Calculation' and 'Fund Tax Year Record' "
    "(FTAX-), 28 'Safekeeping Account' (SKA-). They resolve through the domain number in the type until their prefixes are registered.",
    "27 links Fund Journal Line to Capital Call ('Source Capital Call'); 30 holds the matching relationship. 30 holds 'Fund NAV Used' "
    "as a Derived copy (27) with a Reference (Fund NAV Calculation, 27) for lineage.",
    "Portfolio companies are referenced inside 30 as Reference (Portfolio Company Profile, 30) with a PTY- key; enrich_30 forces these "
    "to 'mastered here', as proposals_22 does for 22's reference.",
    "Fund Administrator is not held on Private Fund Profile: it is the 01 Product Party Role 'Fund Administrator'.",
    "Object count is 36 (brief 30 +/- 3) after the program lead's grain decisions (Commitment Change, Capital Call Purpose Line, "
    "Distribution Source Line, Investment Ownership Period) and additions (Deal Allocation, Real Asset Metric).",
    "Local list count is 33 (brief target 20-28) plus 7 shared-list copies and a copy of the 22 Measure Unit list; candidates to "
    "fold are in SHARED_CANDIDATES.",
    "No 30 attribute uses Business Line; every 30 record is the Private Markets line except funds of one (Fund of One Indicator).",
]
