"""Consolidation proposals from Data Domain 31 - Investment Risk (Stage 3 draft v0.1, 2026-10-06).

Proposal fragment only: the builder does not read it. The Stage 3 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Format follows CONTRACT.md in this folder. Decisions implemented: CD-211 to
CD-216, CD-223 and CD-225 (proposals_stage3_a.py), with the program lead's working assumptions (CD-143 accepted, shared
Business Line list CD-209, governance metadata in 21, per-attribute ownership with row rules).
Changes proposed below for 01, 02, 18, 22, 24 and 25 are proposals only; no other domain's file was edited.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones (prefix, entity, owner domain, status, note). None needed.
#    31 uses only the reserved RLMT-, RLEX- and STRESS- (proposals_stage3_a.py). Risk models are keyed by a firm-defined
#    name without a hyphenated stem plus a version; factors, runs, measures, classifications, tests and designations are
#    keyed by their grain. Family codes avoid printing registered prefixes in attribute IDs: RK-MEA (not RK-MSR: MSR- is
#    registered), RK-STT (not RK-STR: STR- is 01 strategy), RK-LQD (not RK-LIQ: LIQ- is left free for 36) and RK-DER
#    (not RK-DRV: DRV- is registered).
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# Registration of the reserved prefixes once accepted (decisions.PREFIXES format):
PREFIXES_TO_REGISTER = [
    ("RLMT-", "Risk limit (risk-program or risk committee limit on a 31 measure)", "31", "Registered", "Stage 3 (CD-223)."),
    ("RLEX-", "Risk limit exceedance (of a 31 risk limit or a 25 counterparty trading limit)", "31", "Registered", "Stage 3 (CD-223, CD-215). Never called a breach."),
    ("STRESS-", "Stress scenario (version separate)", "31", "Registered", "Stage 3 (CD-216)."),
]

# Key formats published by 31 (decisions.PREFIX_FORMATS format), used in every 31 example.
PREFIX_FORMATS = [
    ("RLMT-", "31", "RLMT-<sequence, 6 digits>", "RLMT-000418"),
    ("RLEX-", "31", "RLEX-<year>-<sequence, 5 digits>", "RLEX-2026-00073"),
    ("STRESS-", "31", "STRESS-<sequence, 4 digits>; the version is a separate attribute", "STRESS-0042"),
]

# Grain keys other domains should write when they reference a grain-keyed 31 object (' / ' between parts).
GRAIN_KEY_FORMATS = [
    ("Risk Model", "<risk model code> / <version>", "Global Equity Long-Term 2024 / 3"),
    ("Risk Factor", "<risk model code> / <version> / <factor code>", "Global Equity Long-Term 2024 / 3 / Momentum"),
    ("Risk Calculation Run", "<risk model code> / <version> / <as-of date> / <run scope>", "Global Equity Long-Term 2024 / 3 / 2026-10-05 / US Registered Funds"),
    ("Portfolio Risk Measure", "<run key> / <PORT-> / <risk measure> / <horizon days> / <confidence level> / <BMK- or (none)>", "Global Equity Long-Term 2024 / 3 / 2026-10-05 / US Registered Funds / PORT-000412 / Value at Risk / 20 / 99% / (none)"),
    ("Liquidity Classification", "<PRD-> / <INS-> / <classification date> / <portion number>", "PRD-00981 / INS-00104477 / 2026-09-30 / 1"),
    ("Highly Liquid Investment Minimum", "<PRD-> / <effective from>", "PRD-00981 / 2026-01-01"),
    ("Fund Liquidity Profile", "<PRD-> / <measurement date>", "PRD-00981 / 2026-09-30"),
    ("Designated Reference Portfolio", "<PRD-> / <effective from>", "PRD-00981 / 2025-08-19"),
    ("VaR Test Result", "<PRD-> / <test date> / <VaR test regime>", "PRD-00981 / 2026-10-05 / Rule 18f-4 Relative VaR"),
    ("Leverage & Exposure Measurement", "<PRD- or PORT-> / <measurement date> / <exposure method>", "PRD-00981 / 2026-10-05 / Rule 18f-4 Derivatives Exposure"),
    ("Liquidity Horizon Bucket", "<PRD-> / <measurement date> / <bucket>", "PRD-00512 / 2026-09-30 / 2-7 Days"),
    ("Risk Program Designation", "<PRD-> / <risk program type> / <effective from>", "PRD-00981 / Liquidity Risk Management Program (Rule 22e-4) / 2018-12-01"),
    ("Instrument Factor Loading", "<risk model code> / <version> / <INS-> / <factor code> / <loading date>", "Global Equity Long-Term 2024 / 3 / INS-00104477 / Momentum / 2026-10-05"),
    ("Counterparty Exposure", "<PTY-> / <date> / <counterparty exposure measure> / <PORT-, LEN- or (firm)> / <TAGR- or (none)>", "PTY-100221 / 2026-10-05 / OTC Derivative Gross Notional / PORT-000412 / TAGR-00118"),
    ("Risk Limit Utilization", "<RLMT- or 25 limit key in brackets> / <date> / <PORT- or (none)>", "RLMT-000502 / 2026-09-22 / PORT-000412"),
    ("Source Measure Record (text on Risk Limit Utilization)", "<31 object name>: <grain key>", "VaR Test Result: PRD-00981 / 2026-10-05 / Rule 18f-4 Relative VaR"),
    ("Stress Test Result", "<STRESS-> / <version> / <PORT-> / <test date>", "STRESS-0042 / 2 / PORT-000412 / 2026-10-02"),
    ("Product Risk Indicator Calculation", "<SHC-> / <indicator type> / <calculation date>", "SHC-004512 / PRIIPs SRI / 2026-09-30"),
]

# CONCEPT_OWNERSHIP rows (decisions.py format). Grain-keyed objects have a blank prefix.
CONCEPT_OWNERSHIP = [
    ("Risk Model", "31", "", ["24", "32", "37"], "The risk function's use of a model, by version; inventory and validation are 37 (CD-211, CD-216)"),
    ("Risk Factor", "31", "", ["32"], "Factor of a risk model version; sustainability factors included (CD-216)"),
    ("Instrument Factor Loading", "31", "", ["32"], "Model loading of an instrument on a factor; not 22 vendor analytics or 22 instrument factors (CD-211)"),
    ("Risk Factor Return", "31", "", ["32"], "Daily return and volatility of a risk factor"),
    ("Portfolio Risk Measure", "31", "", ["33", "12", "35"], "Ex-ante tracking error, volatility, VaR, expected shortfall, beta (CD-211); ex-post statistics are 32"),
    ("Counterparty Exposure", "31", "", ["25", "33"], "Exposure per counterparty, date, measure and scope, including every measure a 25 Counterparty Trading Limit caps (CD-215)"),
    ("Leverage & Exposure Measurement", "31", "", ["33", "35"], "UCITS commitment, AIFMD gross and commitment, Rule 18f-4 derivatives exposure (CD-214)"),
    ("Stress Scenario", "31", "STRESS-", ["35"], "Historical, hypothetical, liquidity and climate scenarios (CD-216)"),
    ("Stress Test Result", "31", "", ["35"], "Scenario applied to a portfolio on a date"),
    ("Liquidity Classification", "31", "", ["35"], "Rule 22e-4 category per position and portion (CD-213)"),
    ("Highly Liquid Investment Minimum", "31", "", ["35"], "HLIM per fund and period (CD-213); never also a Risk Limit"),
    ("Fund Liquidity Profile", "31", "", ["35"], "Fund-level liquidity program result per date (CD-213)"),
    ("Liquidity Horizon Bucket", "31", "", ["35"], "Annex IV and Form PF buckets (CD-213)"),
    ("Designated Reference Portfolio", "31", "", ["35"], "Rule 18f-4 DRP per fund and period (CD-214)"),
    ("VaR Test Result", "31", "", ["35", "33"], "Rule 18f-4 and UCITS VaR tests (CD-214)"),
    ("Risk Program Designation", "31", "", ["35"], "Fund x program type x period: LRMP, DRMP, limited derivatives user, UCITS RMP, AIFMD policy"),
    ("Risk Limit", "31", "RLMT-", ["33", "35"], "Risk-program and risk committee limits (CD-223)"),
    ("Risk Limit Utilization", "31", "", ["25", "35"], "Daily measurement of a 31 risk limit or a 25 counterparty trading limit per portfolio in scope (CD-215)"),
    ("Risk Limit Exceedance", "31", "RLEX-", ["35", "25", "37"], "Exceedance of a 31 risk limit or a 25 counterparty trading limit (CD-215, CD-223)"),
    ("Product Risk Indicator Calculation", "31", "", ["01", "13"], "PRIIPs SRI and UCITS SRRI calculation; 01 discloses (CD-212)"),
    ("PRIIPs Performance Scenario", "31", "", ["01", "13"], "Stress, unfavorable, moderate, favorable scenarios (CD-212)"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local lists in content_31 that are exact copies of enterprise shared lists. Register 31 as a
#    direct user (or a member with an identity value_map), then delete the local copy and cite 'Shared: <name>'.
#    (shared list name, local list name in 31, note)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    ("Record Status", "Record Status", "Risk Model, Stress Scenario and Risk Limit status. Values identical."),
    ("Approval Status", "Approval Status", "Run, scenario, HLIM, DRP, risk indicator approvals. Values identical."),
    ("Frequency", "Frequency", "Stress Test Frequency. Values identical."),
    ("Severity", "Severity", "Exceedance Severity. Values identical."),
    ("RAG Status", "RAG Status", "Utilization RAG Status. Values identical."),
    ("Case Status", "Case Status", "Exceedance Workflow Status. Values identical."),
    ("Data Basis", "Data Basis", "Factor return, factor loading, liquidity classification and bucket, return history basis. Values identical."),
    ("Regulator", "Regulator", "Program Regulator. Values identical."),
    ("Business Line", "Business Line", "Risk Limit 'Limit Business Lines' only (CD-209). Values identical."),
]
# Brief §8 also named Period Type; no 31 attribute needed it (horizons are held in days), so no copy was made.

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: local 31 lists (or lists 31 cites from another domain) that look like enterprise lists.
#    (list in 31, proposed shared name, other users, note)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Exposure Method", "Exposure Method", ["01"],
     "Values qualified by regime: 'Commitment Approach (UCITS)' = 01 Risk Measurement Method 'Commitment'; 'Gross Method (AIFMD)' "
     "and 'Commitment Method (AIFMD)' = 01 Leverage Method 'Gross Method' and 'Commitment Method'; plus 'Sum of Notionals (UCITS)' "
     "and 'Rule 18f-4 Derivatives Exposure'. 01's 'Relative VaR' and 'Absolute VaR' are test "
     "regimes, matching 31 VaR Test Regime. Option: one shared 'Exposure Method' list for 01 and 31, with 01 Risk "
     "Measurement Method split into exposure method plus VaR test regime."),
    ("Liquidity Category", "Liquidity Category", ["35"],
     "Rule 22e-4(a) four categories; 35 reports them on N-PORT and in board reports. Regulatory list, steward 31."),
    ("Liquidity Horizon Bucket", "Liquidity Horizon Bucket", ["35", "30"],
     "Annex IV and Form PF buckets; 35 files them, 30 may use them for investor liquidity."),
    ("Confidence Level", "Confidence Level", ["32"],
     "32 ex-post VaR-style statistics, if any, would use the same values."),
    ("Risk Measure", "Risk Measure", ["32"],
     "Keep 'Ex-Ante' prefixes; 32 Ex-Post Risk Statistic needs a separate 'Ex-Post' list (CD-211). Record as NOT_MERGED "
     "if 32 drafts its own list."),
    ("External (22 Measure Unit)", "Measure Unit", ["22", "31"],
     "31 cites the 22 local list 'Measure Unit' for exposure, shock and limit threshold units (Percent, Basis Points, "
     "Currency Amount, Years, Ratio...). Make it an enterprise shared list stewarded by 22, or let 31 copy it."),
    ("External (22 Rate Tenor)", "Rate Tenor", ["22", "26", "31"],
     "31 Shock Tenor uses 22's tenor list."),
    ("Risk Limit Measure", None, [],
     "Holds program test measures only (VaR ratios, commitment exposure, derivatives exposure percent for the 10% limited "
     "derivatives user test, illiquid percent, stress loss); risk appetite limits use Risk Measure and Exposure Measure. No overlap left."),
    ("Counterparty Exposure Measure", "Counterparty Limit Measure", ["25"],
     "Five values equal the 25 Limit Type values by name (CD-215); 25 Limit Type and these values should be one list, stewarded by 25."),
    ("Risk Dimension", "Risk Dimension", ["32"],
     "32 attribution segments use a similar cut (sector, country, currency, factor)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS noticed with existing and sibling domains (decisions.py format).
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Risk",
     "usages": [("31", "Investment Risk", "Market, liquidity, counterparty and derivatives risk of portfolios"),
                ("37", "Enterprise & Operational Risk (Stage 4)", "Firm-level risk register, operational incidents, model inventory"),
                ("02", "AML Risk Rating / Risk Rating", "Client financial crime risk rating"),
                ("14", "Vendor risk / TPRM", "Third-party risk of data vendors"),
                ("01", "Risk Profile / Product Risk Indicator", "Disclosed product risk")],
     "recommendation": "Always qualify: Investment Risk (31), Enterprise / Operational Risk (37), Client Risk Rating (02), Vendor Risk (14), Product Risk Indicator (01 disclosure, 31 calculation)."},
    {"term": "Exposure",
     "usages": [("31", "Portfolio Exposure / Counterparty Exposure / Leverage & Exposure Measurement", "Measured market, credit and regulatory exposure"),
                ("18", "Derivative Holding Detail.Delta-Adjusted Exposure Base", "Holding-level economic exposure (N-PORT)"),
                ("26", "Margin Call Exposure Amount", "Exposure under a CSA for a margin call"),
                ("30", "Clawback Exposure", "GP clawback liability")],
     "recommendation": "Qualify every use; 31 aggregates the 18 delta-adjusted exposure base and does not re-master it (CD-211). The 26 margin exposure is the CSA calculation, not 31 counterparty exposure."},
    {"term": "Limit",
     "usages": [("31", "Risk Limit (RLMT-)", "Risk-program and risk committee limit on a 31 measure"),
                ("33", "Compliance Rule (CRULE-)", "Coded investment restriction"),
                ("01", "Investment Restriction.Limit Type / Limit Value", "Restriction as written"),
                ("25", "Counterparty Trading Limit", "Approved trading limit per counterparty"),
                ("24", "Portfolio Construction Constraint", "PM constraint / risk budget"),
                ("16", "Annual Limit Tracking", "Retirement plan contribution limits")],
     "recommendation": "One limit, one owner (CD-223). 'Risk Limit' means only RLMT-; 24 budgets are 'constraints'; 33 'rules'."},
    {"term": "Exceedance / Breach",
     "usages": [("31", "Risk Limit Exceedance (RLEX-)", "Measure above a 31 limit or a 25 counterparty limit"),
                ("33", "Investment Breach (BREACH-)", "Failure of a coded investment restriction"),
                ("12", "Breach Notification (GBN-)", "Client notification of a guideline breach")],
     "recommendation": "'Breach' is reserved for 33 and 12; 31 uses 'exceedance' only (CD-223)."},
    {"term": "Factor",
     "usages": [("31", "Risk Factor / Risk Factor Return / Instrument Factor Loading", "Risk model factors, their returns and instrument loadings"),
                ("22", "Instrument Factor Observation", "Pool factors, inflation index ratios and amortization factors of an instrument"),
                ("22", "Fair Value Factor", "Adjustment factor applied to a foreign close for fair valuation")],
     "recommendation": "Qualify: 'Risk Factor' (31), 'Instrument Factor' (22, pool and inflation), 'Fair Value Factor' (22). 31 objects were renamed to avoid 22's 'Instrument Factor Observation'."},
    {"term": "Liquidity",
     "usages": [("31", "Liquidity Classification / Fund Liquidity Profile", "Rule 22e-4 asset liquidity"),
                ("01", "Liquidity Profile (Strategy)", "Dealing liquidity offered to investors"),
                ("25", "Execution Liquidity Indicator", "Added or removed liquidity on a fill"),
                ("36", "Fund liquidation (LIQ- left free)", "Closing a fund")],
     "recommendation": "Qualify: 'Asset Liquidity' or the 22e-4 terms (31), 'Dealing Liquidity' (01), 'Execution Liquidity' (25), 'Liquidation' (36)."},
    {"term": "Scenario",
     "usages": [("31", "Stress Scenario (STRESS-) / PRIIPs Performance Scenario", "Loss scenario; KID performance scenario"),
                ("34", "Climate scenario metrics (if any)", "Climate pathways used in reporting"),
                ("24", "What-if rebalance runs", "Optimizer scenarios")],
     "recommendation": "Never 'Scenario' bare: 'Stress Scenario', 'PRIIPs Performance Scenario', 'Climate Scenario Pathway' (an attribute of a 31 Stress Scenario)."},
    {"term": "Model (extend existing entry)",
     "usages": [("31", "Risk Model", "Risk function's use of a model version"),
                ("24", "Optimizer / Rebalance Run 'Risk Model Used'", "Optimizer risk estimate (to be re-typed to 31)"),
                ("23", "Research Model", "Analyst valuation model"),
                ("01", "Model Portfolio (MDL-)", "Delivered model portfolio"),
                ("37", "Model inventory (Stage 4)", "Model risk management")],
     "recommendation": "Qualify: Risk Model, Research Model, Model Portfolio, Attribution Model (32); the inventory record is 37."},
    {"term": "Counterparty (extend existing entry)",
     "usages": [("31", "Counterparty Exposure", "Measured credit exposure per netting set (CD-215)")],
     "recommendation": "Counterparty remains a 02 party; 25 approves and limits, 26 documents and collateralizes, 31 measures."},
    {"term": "Tracking Error",
     "usages": [("31", "Risk Measure 'Ex-Ante Tracking Error'", "Model forecast of the held book"),
                ("24", "Rebalance Portfolio Result.Pre-Trade / Post-Trade Tracking Error", "Optimizer estimate for a proposal"),
                ("32", "Ex-Post Risk Statistic 'Ex-Post Tracking Error'", "From realized returns")],
     "recommendation": "Always prefix Ex-Ante / Ex-Post; 24 values are optimizer estimates and stay 24 (CD-211)."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. PROPOSED_CHANGES to other domains (proposals only; nothing was edited). (domain, object.attribute, change, decision)
# ---------------------------------------------------------------------------------------------------------------------
PROPOSED_CHANGES = [
    ("01", "Product Risk Indicator.Summary Risk Indicator (SRI)", "Re-note Derived copy (31) of Product Risk Indicator Calculation.Calculated Indicator Value, latest approved row with type 'PRIIPs SRI' for the share class.", "CD-212"),
    ("01", "Product Risk Indicator.SRRI", "Re-note Derived copy (31) of Product Risk Indicator Calculation.Calculated Indicator Value, latest approved row with type 'UCITS SRRI'.", "CD-212"),
    ("01", "Product Risk Indicator.Global Exposure Method; Investment Objective & Policy.Leverage Calculation Method, Maximum Leverage, Derivatives Usage", "No change: declared values that 31 measures against and 33 rules test (CD-214, CD-223). Consider the Exposure Method shared list (SHARED_CANDIDATES).", "CD-214"),
    ("01", "Investment Objective & Policy.Recommended Holding Period", "No change; 31 copies it into Recommended Holding Period Used (Derived copy 01).", "CD-212"),
    ("02", "Party Role Type", "Add 'Risk Model Vendor' (31 Risk Model.Model Vendor). Counterparty roles proposed by 25 already cover Counterparty Exposure.", "CD-143"),
    ("18", "Derivative Holding Detail.Delta-Adjusted Exposure Base", "No change: stays mastered in 18; 31 Portfolio Exposure aggregates it.", "CD-211"),
    ("22", "Pricing Analytic Measure (list)", "Optional: if the firm wants 22 to own per-instrument liquidity market inputs, add 'Average Daily Trading Volume' and 'Quoted Bid-Ask Spread'; otherwise vendor liquidity datasets (14) stay direct inputs to 31 Liquidity Classification. SME question 3.", "CD-211, CD-213"),
    ("22", "Measure Unit, Rate Tenor (lists)", "Promote to enterprise shared lists or allow 31 to cite them (31 cites them as 'External (22 ...)').", ""),
    ("24", "Rebalance Run.Risk Model Used", "Re-type from Text to Reference (Risk Model, 31) with example 'Global Equity Long-Term 2024 / 3'.", "CD-211"),
    ("24", "Rebalance Portfolio Result.Pre-Trade Tracking Error, Post-Trade Tracking Error", "No change (optimizer estimates); replace the note 'future owner 31' with 'optimizer estimate; the held-book measure is 31 Portfolio Risk Measure (CD-211)'.", "CD-211"),
    ("25", "Counterparty Trading Limit", "No change; add a note that each Limit Type is measured by the 31 Counterparty Exposure row of the same measure, and that utilization and exceedances are 31 Risk Limit Utilization and Risk Limit Exceedance (RLEX-). New 25 Limit Type values need a matching 31 Counterparty Exposure Measure.", "CD-215"),
    ("35", "Resolution Subject Link", "Holds the board approval links to 31 Highly Liquid Investment Minimum and Risk Program Designation (administrator and program approvals); 31 dropped its HLIM Board Approval and Program Board Approval references, and the DRP board reporting reference (Board Report Received holds it). Add Risk Program Designation as a subject if 35 links only HLIM today.", "CD-237"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Sibling names used (confirm at the Stage 3 consolidation): 34 'Portfolio Climate Metric' (grain portfolio or product x "
    "measurement date x metric x methodology); 35 'Fund Officer Appointment' (grain registrant or entity x officer role x person x effective period). 35's brief expects 31 objects "
    "named 'Derivatives VaR Test Result' and 'Liquidity Risk Program Report': 31 uses 'VaR Test Result' (it covers UCITS "
    "tests too), and the program report to the board is a 35 Board Report Received that references 31 results; 31 has no "
    "report object.",
    "33 Compliance Rules that read a 31 measure (client tracking error caps, AIFMD leverage caps, UCITS Article 52 "
    "counterparty limits) name the 31 object and measure; they do not copy the value (CD-223).",
    "35 Reportable Fund Event (N-RN triggers) should reference RLEX- for the 15% illiquid limit and VaR test exceedances, "
    "and Fund Liquidity Profile for HLIM shortfalls (the HLIM is not a Risk Limit, so an HLIM shortfall is not an RLEX-).",
    "Overrides in enrich_31.py: grain-keyed references whose example begins with PORT-, PRD-, PTY- or INS- are forced to "
    "the right owner (31 own objects, 22, 23, 25, 27, 34, 35).",
    "Shared lists: content_31 holds local copies named exactly as the shared lists (SHARED_MEMBERSHIPS); no import-time "
    "helper. Once 31 is registered as a direct user, delete the copies and cite 'Shared: <name>'.",
    "CD-237 over CD-225 (program lead ruling): board approvals of 31 records are linked once, from 35 Resolution Subject Link. "
    "31 holds no Board Resolution or Board Meeting reference. If a 31 consumer needs it later, add only a derived 'Board Approved "
    "Indicator' or 'Board Approval Date' read from 35 (Derived copy 35).",
    "CD-215 (program lead ruling): Counterparty Exposure carries every measure a 25 limit caps (gross notional, settlement, repo, "
    "unsettled-trade exposure, trading volume) beside net MTM, collateral held and PFE, so every 25 limit has a 31 value; RLEX- stays "
    "the one exceedance record. No 31 Risk Limit is set on counterparty exposure (the former value 'Counterparty Net Exposure' was removed).",
    "Fund vs portfolio keys: 22e-4, 18f-4, UCITS and AIFMD program results (Liquidity Classification, HLIM, Fund Liquidity Profile, "
    "Liquidity Horizon Bucket, Designated Reference Portfolio, VaR Test Result, Leverage & Exposure Measurement, Risk Program "
    "Designation) are keyed by PRD- and measured on the fund's whole 18 book (all portfolios linked by 18 Portfolio Implementation Link); "
    "measures, exposures, stress results and back-tests are keyed by PORT-.",
    "Model Inventory Reference on Risk Model is Text with 'future owner 37' (CD-216); re-type when 37 is drafted.",
]
