"""Consolidation proposals from the Data Domain 32 (Performance & Attribution) draft v0.1, 2026-10-06.

Proposal fragment only: the builder does not read this file. The Stage 3 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Formats follow CONTRACT.md in this folder. Boundary decisions CD-211 and CD-217 to
CD-220 and CD-225 are in proposals_stage3_a.py; this file holds what the draft found while implementing them.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES (prefix, entity, owner domain, status, note) - decisions.PREFIXES format
# None beyond the three reserved in proposals_stage3_a.py (RETURN-, PAAN-, GVER-). Policies, profiles, benchmark returns,
# statistics, memberships, composite statistics, cash flow events, carve-outs, attribution models, segments, effects,
# contributions, private measures, PMEs, period closes and restatements keep composite keys.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

KEY_FORMATS = [
    ("RETURN-", "32", "RETURN-<year>-<sequence, 10 digits>; the version is a separate attribute", "RETURN-2026-0004518832"),
    ("PAAN-", "32", "PAAN-<year>-<sequence, 8 digits>; the version is a separate attribute", "PAAN-2026-00031877"),
    ("GVER-", "32", "GVER-<year>-<sequence, 3 digits>", "GVER-2026-001"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED MEMBERSHIPS: 32 local lists that carry an enterprise shared list's exact name and values (copied from
#    shared_code_lists.py). Register 32 as a direct user of each and drop the local copies.
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Reporting Period Basis", "local": "Reporting Period Basis",
     "value_map": {"Month to Date": "MTD", "Quarter to Date": "QTD", "Year to Date": "YTD", "Fiscal Year to Date": "FYTD", "Trailing 1 Month": "TRAILING_1M", "Rolling 3 Months": "ROLLING_3M", "Rolling 12 Months": "ROLLING_12M", "1 Year": "TRAILING_1Y", "3 Years": "TRAILING_3Y", "5 Years": "TRAILING_5Y", "10 Years": "TRAILING_10Y", "Since Inception": "SINCE_INCEPTION", "Calendar Years": "CALENDAR_YEARS", "Custom": "CUSTOM"},
     "new_values": []},
    {"shared": "Period Type", "local": "Period Type",
     "value_map": {"Day": "DAY", "Week": "WEEK", "Month": "MONTH", "Quarter": "QUARTER", "Half-Year": "HALF_YEAR", "Year": "YEAR", "Year-to-Date": "YEAR_TO_DATE", "Rolling / Trailing 12 Months": "ROLLING_12_MONTHS", "Point in Time": "POINT_IN_TIME"},
     "new_values": []},
    {"shared": "Performance Fee Basis", "local": "Performance Fee Basis",
     "value_map": {"Gross of Fees": "GROSS_OF_FEES", "Net of Fees": "NET_OF_FEES", "Gross and Net": "GROSS_AND_NET"},
     "new_values": [],
     "note": "32 never uses 'Gross and Net' on a return, statistic or private measure row (one row is one number); the value stays so the list is identical. Consider describing it as 'presentation choice only (12)'."},
    {"shared": "Frequency", "local": "Frequency",
     "value_map": {"Real-Time": "REAL_TIME", "Intraday": "INTRADAY", "Daily": "DAILY", "Weekly": "WEEKLY", "Fortnightly": "FORTNIGHTLY", "Monthly": "MONTHLY", "Quarterly": "QUARTERLY", "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL", "Biennial": "BIENNIAL", "On Event": "ON_EVENT", "Ad Hoc": "AD_HOC"},
     "new_values": [],
     "note": "Used for calculation frequency, observation frequency of ex-post statistics (the brief's local 'Observation Frequency' list was not created) and blend rebalancing frequency."},
    {"shared": "Approval Status", "local": "Approval Status",
     "value_map": {"Not Required": "NOT_REQUIRED", "Pending": "PENDING", "Approved": "APPROVED", "Approved with Conditions": "APPROVED_WITH_CONDITIONS", "Retrospectively Approved": "RETROSPECTIVELY_APPROVED", "Rejected": "REJECTED", "Expired": "EXPIRED", "Withdrawn": "WITHDRAWN"},
     "new_values": []},
    {"shared": "Business Line", "local": "Business Line",
     "value_map": {"Mutual Fund": "MUTUAL_FUND", "ETF": "ETF", "Collective Investment Trust": "COLLECTIVE_INVESTMENT_TRUST", "Separately Managed Account": "SEPARATELY_MANAGED_ACCOUNT", "Private Markets": "PRIVATE_MARKETS", "Insurance-Dedicated Fund": "INSURANCE_DEDICATED_FUND"},
     "new_values": []},
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: local 32 lists that look like enterprise lists
#    (list name in 32, proposed shared list name or None, likely other users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Return Methodology", "Return Methodology", ["12"],
     "Byte-identical copy of 12 Return Methodology (GIPS). Make it shared, stewarded by 32. 'Both' is valid only on a "
     "profile or presentation choice, never on a return row; add that to the value description."),
    ("Net Fee Treatment", "Net Fee Treatment", ["12"],
     "Byte-identical copy of 12 Net Fee Treatment. Shared, stewarded by 32. The brief called it 'Fee Schedule Basis'; the 12 "
     "name was kept so the merge is a membership."),
    ("Return Type", "Return Type", ["01", "22"],
     "Byte-identical copy of 01 Return Type; 22 Index Level Variant holds the same values (CD-169). Shared, stewarded by 01."),
    ("Price Basis", "Price Basis", ["35"],
     "NAV / Market Price / Portfolio Valuation. 35 public disclosures (premium / discount) use the same distinction. 22 ETF "
     "Market Price Type (official close vs NBBO midpoint) is a different dimension; overlap with 22 is partial only."),
    ("Return Status", None, ["31", "33", "35"],
     "Preliminary / Final / Restated / Superseded. Reused here for benchmark returns, statistics, attribution and private "
     "measures. Siblings with versioned calculated results (31 risk measures) may want the same list."),
    ("Measured Subject Type", None, ["12", "31"],
     "Subject kinds of performance records. 31 Portfolio Risk Measure subjects overlap (portfolio, fund). Keep local unless 31 "
     "adopts it."),
    ("Return Source", None, ["30"],
     "Calculated In House / Fund Administrator / Recordkeeping Platform / Index Provider. Aligns with 30 Administration "
     "Operating Model; keep local."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS noticed with existing and sibling domains (decisions.py format)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Return",
     "usages": [("32", "Performance Return (RETURN-)", "Official investment return of a subject for a period"),
                ("19", "Regulatory Financial Return; Corporate Tax Return (TAXR-)", "Regulatory and tax filings of a group entity"),
                ("11", "Peer Metric Snapshot.Total Return", "Vendor-reported return of a peer or own fund"),
                ("27", "Financial Highlights.Total Return", "Fiscal-period total return in the financial statements (CD-217)"),
                ("30", "Preferred Return (waterfall terms)", "Hurdle in the distribution waterfall"),
                ("16", "Form 5500 / tax filings", "Government returns of a plan")],
     "recommendation": "Never use 'Return' bare. Glossary: 'Performance Return' (32), 'Published Peer Return' (11), "
                       "'Financial Highlights Total Return' (27), 'Preferred Return (Hurdle)' (30), 'Regulatory Return' / "
                       "'Tax Return' (19)."},
    {"term": "Performance",
     "usages": [("32", "Performance Return and statistics", "Investment performance"),
                ("20", "Performance review / rating", "Employee performance management"),
                ("10", "Performance Fee Record (PFR-); Performance Obligation", "Fee revenue; ASC 606 performance obligation"),
                ("04", "Campaign / content performance", "Marketing engagement metrics"),
                ("14", "Vendor performance", "Data vendor service performance")],
     "recommendation": "Qualify: 'Investment Performance' (32), 'Employee Performance' (20), 'Campaign Performance' (04), "
                       "'Vendor Performance' (14), 'Performance Obligation' (10, accounting term)."},
    {"term": "Attribution",
     "usages": [("32", "Attribution Result (PAAN-)", "Decomposition of active return into effects"),
                ("06", "Attribution Record (ATR-)", "Crediting of sales and assets to the distribution hierarchy"),
                ("04", "Marketing attribution", "Crediting of conversions to campaigns and touches"),
                ("14", "Attribution (license)", "Source attribution required by a data license")],
     "recommendation": "Glossary: 'Performance Attribution' (32), 'Sales Attribution' (06), 'Marketing Attribution' (04), "
                       "'License Attribution Requirement' (14). ownership.py must never alias 'attribution' alone."},
    {"term": "Composite",
     "usages": [("01", "GIPS Composite (CMP-)", "Definition of a GIPS composite"),
                ("32", "Composite Membership; Composite Period Statistic", "Membership and statistics of the 01 composite"),
                ("09", "Composite Calendar", "Calendar combining several calendars")],
     "recommendation": "'Composite' alone means the GIPS composite (01 definition, 32 membership and statistics); 09 keeps "
                       "'Composite Calendar'."},
    {"term": "Benchmark",
     "usages": [("01", "Benchmark (BMK-)", "Benchmark definition and blend weights"),
                ("32", "Benchmark Return", "Calculated return of a benchmark for a period"),
                ("22", "Index Level Observation", "Published index levels"),
                ("11", "Fee Benchmark Study", "Fee comparison, not an index")],
     "recommendation": "Extend the 'Index / Benchmark' conflict: 'Benchmark' (01 definition), 'Benchmark Return' (32), "
                       "'Index Level' (22), 'Fee Benchmark' (11)."},
    {"term": "Restatement",
     "usages": [("32", "Performance Restatement", "Correction of a Final performance return"),
                ("06", "Restatement (RSM-)", "Restatement of distribution flow and AUM data"),
                ("10", "Hierarchy Restatement", "Re-cut of management reporting hierarchies")],
     "recommendation": "Qualify: 'Performance Restatement' (32), 'Flow Restatement' (06), 'Hierarchy Restatement' (10)."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. DERIVED COPIES / RE-NOTES to apply elsewhere at consolidation (domain, object, attribute, source, decision)
# ---------------------------------------------------------------------------------------------------------------------
FUTURE_DERIVED_COPIES = [
    ("01", "GIPS Composite", "Composite Member",
     "CD-218 option A reworded: 32 Composite Membership is by 18 portfolio (CMP- x PORT-), while 01 Composite Member is typed "
     "Reference (Product / Mandate). 01 keeps it only as a derived roll-up: the products and mandates implemented by the "
     "current member portfolios, derived through 18 Portfolio Implementation Link, flagged Derived copy (32, via 18). If the "
     "roll-up is not wanted, option B (retire it from 01) is cleaner and is recommended as the fallback.", "CD-218"),
    ("01", "Share Class (Performance Track Record)", "Performance Calculation Basis",
     "Derived copy (32) of the share class's Performance Measurement Profile (Return Methodology and Net Fee Treatments "
     "Produced) in effect, or retire it. 01's list mixes fee basis and methodology (shared_code_lists NOT_MERGED says split "
     "01 before aligning).", "CD-217"),
    ("27", "Financial Highlights", "Total Return",
     "32 Performance Return of the share class for the fiscal period (Net of Fees, Actual Fees, Time-Weighted, NAV, Before "
     "Taxes, not sales charge adjusted), CD-217 option A; option B keeps 27 mastered with a 32 reconciliation", "CD-217"),
    ("12", "Presentation Profile", "Fee Basis Shown",
     "No copy; 12 keeps the presentation choice. Recommend 12 re-points its local 'Fee Basis' list to the shared Performance "
     "Fee Basis; 12 Net Return Fee Treatment selects on 32 Return Net Fee Basis", "CD-217"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Prefix register: move RETURN-, PAAN- and GVER- from Reserved to Registered (owner 32) with KEY_FORMATS above. RETURN- has "
    "six letters, so ownership.py's prefix regex ([A-Z]{2,5}) never matches it; references resolve via the '32' in the type.",
    "CONCEPT_OWNERSHIP: add ('Performance Return', '32', 'RETURN-', ['08','10','12','13','16','35','36'], 'Official returns'), "
    "('Benchmark Return', '32', '', ['10','12','35'], ''), ('Composite Membership', '32', '', ['01'], 'CD-218'), "
    "('Attribution Result', '32', 'PAAN-', ['12'], 'Performance attribution'), ('GIPS Verification', '32', 'GVER-', [], ''), "
    "('Private Markets Performance Measure', '32', '', ['12','35'], 'CD-219'), ('Investor Performance Measure', '32', '', ['12','30'], '').",
    "enrich_32 overrides (9): composite keys that start with a third domain's prefix: 22 Index Level Observation (BMK-) and "
    "ETF Market Statistic (INS-) forced to 22; 30 Private Investment (PRD-) forced to 30 twice; 27 Fund NAV Calculation (PRD-) "
    "forced to 27; own-object Benchmark Return Record (BMK-) and Significant Cash Flow Removals (PORT-) forced to 'mastered "
    "here'. Drop them if the resolver prefers the concept name over the example prefix.",
    "Family code PF-RAS replaces the brief's PF-RET, which prints 08's registered RET- prefix (same rule the 36 brief applied to PD-REV).",
    "Performance Return key (program lead decision on review D-High): subject x period start x period end x fee basis x net fee "
    "basis (actual / model / highest, blank on gross) x calculation type (time- / money-weighted) x price basis x tax basis x "
    "sales charge basis x currency x version. Defaults on non-fund rows: Before Taxes and N (no sales charge). 35 and 13 select "
    "N-PORT and shareholder report rows as Net of Fees, Actual Fees, Time-Weighted, NAV, Before Taxes, N; Rule 482 standardized "
    "rows as sales charge Y.",
    "Row Ownership Rule convention (plan section 4 item 9): 32 splits every polymorphic subject into typed references, one per "
    "subject kind, exactly one filled per row (Return / Profiled / Statistic Portfolio 18, Share Class 01, Account 15, "
    "Composite 01, Model Portfolio 01, Benchmark 01; private measures Private Fund 01, Private Investment 30, Composite 01), "
    "with the Subject Type as discriminator. Recommend ratifying this pattern alongside a Row Ownership Rule note for "
    "multi-source Derived copies (Beginning / Ending Portfolio Value: 18 only, populated on portfolio and account rows).",
    "Versioning: Benchmark Return, Ex-Post Risk Statistic, Private Markets Performance Measure, Investor Performance Measure "
    "and Public Market Equivalent carry a version in the key and status as an attribute; the first three and Investor measure "
    "carry a Supersedes reference. Attribution Result keys on the portfolio return version and the full benchmark return key "
    "including version.",
    "Sibling names used: 31 Risk Model; 35 Fund Regulatory Filing (REGF-); 36 Product Change Initiative (LCHG-); checked against "
    "content_33-36 on 2026-10-06, which already reference 'Performance Return, 32' and 'Benchmark Return, 32'.",
    "Ask 12 to drop its local 'Return Period' list in favor of shared Reporting Period Basis when it adopts Return Methodology and "
    "Net Fee Treatment as shared lists.",
]
