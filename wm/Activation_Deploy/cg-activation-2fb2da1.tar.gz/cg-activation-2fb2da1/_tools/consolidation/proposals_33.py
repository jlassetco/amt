"""Consolidation proposals from Data Domain 33 - Investment Compliance (Stage 3 draft v0.1, 2026-10-06; revised after the independent review 33_review.md).

Proposal fragment only: the builder does not read it. The Stage 3 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Format follows CONTRACT.md in this folder. Decisions implemented: CD-221 to CD-225
(proposals_stage3_a.py), confirming CD-180; working assumptions CD-143 and CD-209.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones (prefix, entity, owner domain, status, note). None needed.
#    33 uses only the reserved CRULE-, CCHK-, CALERT- and BREACH-. Libraries, provisions and instrument lists are keyed by
#    firm codes without a hyphenated stem ("UCITS 5/10/40", "ICA 5(b)(1) single issuer 5%", "ERISA PII Issuers"); rule
#    coding requests and guideline waivers carry internal references without a prefix ("RCR 2026/0187", "GW 2026/0031").
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

PREFIXES_TO_REGISTER = [
    ("CRULE-", "Compliance rule (coded investment guideline or regulatory limit; version separate)", "33", "Registered", "Stage 3 (CD-221)."),
    ("CCHK-", "Compliance check run (pre-trade, intraday, post-trade batch, what-if, deal pre-approval)", "33", "Registered", "Stage 3 (CD-221)."),
    ("CALERT-", "Compliance alert", "33", "Registered", "Stage 3 (CD-221). Qualifies the 'Alert' term (29 AMA-, 08 SURV-)."),
    ("BREACH-", "Investment breach", "33", "Registered", "Stage 3 (CD-222). 12 keeps GBN- for the client notification."),
]

PREFIX_FORMATS = [
    ("CRULE-", "33", "CRULE-<sequence, 6 digits>; version is the separate attribute Rule Version", "CRULE-004512"),
    ("CCHK-", "33", "CCHK-<year>-<sequence, 9 digits>", "CCHK-2026-000918822"),
    ("CALERT-", "33", "CALERT-<year>-<sequence, 7 digits>", "CALERT-2026-0041877"),
    ("BREACH-", "33", "BREACH-<year>-<sequence, 5 digits>", "BREACH-2026-00143"),
]
# Resolver note: ownership.py reads prefixes of 2-5 capitals, so CALERT- and BREACH- examples are never matched by prefix.
# 33's own references therefore carry ", 33" in the data type, and other domains should write
# "Reference (Investment Breach, 33)" / "Reference (Compliance Alert, 33)" (or the consolidation widens the regex to 6).

CONCEPT_OWNERSHIP = [
    ("Regulatory Limit Provision", "33", "", ["01", "35"], "Single master of statutory investment limit values; 01 Regulatory restrictions restate it (proposed)"),
    ("Compliance Rule", "33", "CRULE-", ["12", "25", "31", "34", "35"], "Coded, versioned test of an investment restriction or regulatory limit; never 'Rule' bare (CD-221)"),
    ("Rule Library", "33", "", ["12"], "Named rule set; a library version is a dated set of rule versions"),
    ("Rule Instrument List", "33", "", ["34", "38"], "List a rule tests membership of; members held only for firm-maintained lists (CD-224)"),
    ("Compliance Check Run", "33", "CCHK-", ["24", "25", "30", "35"], "Pre-trade, intraday, post-trade, what-if or deal pre-approval run"),
    ("Check Subject Member", "33", "", ["25"], "Per-order pre-trade outcome; 25 Trade Order Event copies Compliance Check Outcome (CD-180)"),
    ("Compliance Rule Result", "33", "", ["35", "12"], "Run x portfolio x rule version x evaluated issuer, instrument or group"),
    ("Compliance Alert", "33", "CALERT-", ["21", "37"], "Alert raised from a failing, warning or unevaluated rule result"),
    ("Investment Breach", "33", "BREACH-", ["12", "35", "37"], "Breach of a coded investment rule; 31 risk limit exceedances are RLEX- (CD-222, CD-223)"),
    ("Breach Review", "33", "", ["35"], "Root cause, escalation decision and CCO sign-off of a breach"),
    ("Restriction Coding Status", "33", "", ["12"], "Coded / partially coded / manual monitoring status of each 01 and 02 restriction"),
    ("Manual Compliance Check", "33", "", ["12"], "Attested check of a non-codable restriction; read by 12 Compliance Certificate"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local lists in content_33 that are exact copies of enterprise shared lists. Register 33 as a
#    direct user (identity value_map), then delete the local copy. (shared list name, local list name in 33, note)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    ("Record Status", "Record Status", "Rule Library, Compliance Rule, Rule Instrument List status. Values identical."),
    ("Approval Status", "Approval Status", "Rule version, coding request, override, loss calculation and waiver approval. Values identical."),
    ("Case Status", "Case Status", "Compliance Alert and Investment Breach workflow status. Values identical."),
    ("Severity", "Severity", "Alert and breach severity. Values identical."),
    ("Regulator", "Regulator", "Provision regulator; notified regulator on Breach Review. Values identical."),
    ("Inclusion Type", "Inclusion Type", "Rule Assignment and Rule Instrument List Member. Values identical."),
    ("Frequency", "Frequency", "Rule Instrument List refresh frequency. Values identical."),
    ("Business Line", "Business Line", "Rule Library business lines (CD-209). Values identical."),
    ("Information Classification", "Information Classification", "Rule Instrument List classification. Values identical."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: local 33 lists that look like enterprise lists. (list in 33, proposed shared name, other users, note)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Compliance Check Outcome", "Compliance Check Outcome", ["25"],
     "Values identical to 25's list (Passed, Passed with Warning, Failed - Blocked, Failed - Override Approved, Not Checked). "
     "CD-221: the list becomes 33's; steward 33, 25 a member with an identity map."),
    ("Breach Type", "Breach Type", ["12"],
     "Values identical to 12 (Active, Passive, Technical). Steward 33 (breach master, CD-222); 12 a member with an identity map."),
    ("Cure Action", "Cure Action", ["12"],
     "Values identical to 12 (Sell Down, Purchase, Client Waiver, Guideline Amended, Self-Cured by Market). Steward 33; 12 a member."),
    ("Rule Limit Type", "Limit Type (Restriction)", ["01"],
     "Values identical to 01 'Limit Type'. Named 'Rule Limit Type' here because 25 has a different 'Limit Type' (counterparty "
     "trading limits). Recommend a shared list named 'Restriction Limit Type', steward 01, with 01 and 33 as members, and a "
     "LOCAL_RENAMES entry for 25 'Limit Type' -> 'Counterparty Limit Type'."),
    ("Measurement Basis", "Measurement Basis", ["01"],
     "33 copies the five 01 values and PROPOSES four additions needed to code statutory limits: '% of Total Assets' (ICA 5(b)(1), "
     "Rule 2a-7, IRC 817(h)), 'Days' (WAM / WAL), 'Ratio' (Section 18 asset coverage, leverage multiple) and 'Rating Notch'. "
     "Also proposes '% of Commitments' (private fund document limits) and '% of Capital' (AIFMD II 20% single-borrower "
     "limit). Steward 01; add the six values to 01 so its restrictions can express the same bases, then make 33 a member."),
    ("Regulatory Regime", "Regulatory Regime", ["01", "35", "36"],
     "01's 15 values plus two proposed additions so 817(h) and ERISA libraries can be scoped: 'IRC 817(h) Insurance-Dedicated' "
     "and 'ERISA Plan Assets'. Steward 01 (see PROPOSED_CHANGES); 01 may prefer a separate 'Tax / Plan Status Regime' list, "
     "in which case 33 splits its two values into that list."),
    # Rule Review Outcome withdrawn as a candidate: 25 'Review Outcome' values (Continue, Continue with Conditions, Reduce
    # Scope or Limits, Watch List, Suspend, Terminate) do not match (review finding F).
    ("Rule Instrument List Type", None, ["34", "38"],
     "Keep local; 34 exclusion lists and the 38 restricted list (Stage 4) feed two of its values."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS noticed with existing and sibling domains (decisions.py format).
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Rule",
     "usages": [("33", "Compliance Rule (CRULE-)", "Coded test of an investment restriction run by the compliance engine"),
                ("07", "Crediting Rule (CRR-) / Alignment Rule (ALR-)", "Sales crediting and territory alignment logic"),
                ("10", "Allocation Rule", "Cost allocation logic"),
                ("21", "Data Quality Rule (DQR-)", "Data quality test"),
                ("22", "Tolerance Rule / pricing policy rules", "Price validation tolerance")],
     "recommendation": "Never use 'Rule' bare. 33 objects are 'Compliance Rule' and 'Rule Library'; regulatory citations keep 'SEC Rule nn'."},
    {"term": "Breach",
     "usages": [("33", "Investment Breach (BREACH-)", "Portfolio outside the limit of a coded investment rule"),
                ("12", "Breach Notification (GBN-)", "Client-facing notification of an investment breach (references 33, CD-222)"),
                ("22", "Tolerance breach", "Price movement outside a validation tolerance"),
                ("27", "Swing threshold breach / NAV error materiality", "Threshold crossed for swing pricing or NAV error"),
                ("28", "CASS client money breach", "Client money calculation shortfall"),
                ("31", "Risk Limit Exceedance (RLEX-)", "Exceedance of a risk-program limit; never called a breach (CD-223)")],
     "recommendation": "Extend the proposals_31 'Exceedance / Breach' entry rather than adding a new one; also covers 12 Depreciation "
                       "Notification 'Threshold Breach Date'. 'Investment Breach' is reserved for 33; other domains say 'exceedance', "
                       "'tolerance exception' or 'threshold crossed'."},
    {"term": "Restriction",
     "usages": [("01", "Investment Restriction (RST-)", "Restriction as written in the prospectus, SAI or mandate"),
                ("02", "Client Restriction (CRX-)", "Client-imposed restriction, including investment exclusions"),
                ("15", "Account Restriction (ARX-)", "Stop-purchase, freeze or hold on a shareholder account; not a rule source"),
                ("17", "Instrument restrictions (e.g. transfer or selling restrictions)", "Terms of an instrument"),
                ("38", "Restricted list (Stage 4)", "Firm restricted and watch lists"),
                ("33", "Restriction Coding Status", "Whether a 01 or 02 restriction is coded")],
     "recommendation": "Always qualify: Investment Restriction, Client Restriction, Account Restriction, Restricted List; 33 implements restrictions as Compliance Rules."},
    {"term": "Alert",
     "usages": [("33", "Compliance Alert (CALERT-)", "Work item from a failing, warning or unevaluated rule result"),
                ("29", "Account Monitoring Alert (AMA-)", "AML, sanctions or fraud alert on an account"),
                ("08", "Surveillance alert (SURV-) and its 'Alert Disposition' attribute and list", "Communications surveillance alert; shares the value False Positive with 33 Alert Disposition Outcome")],
     "recommendation": "Extend the existing 'Alert' entry; always qualify by the monitored subject."},
    {"term": "Waiver",
     "usages": [("33", "Guideline Waiver", "Client- or board-approved exception to a compliance rule for a portfolio"),
                ("27", "Expense Cap & Waiver Accrual", "Fee waiver and expense reimbursement"),
                ("10", "Waiver Record", "Distribution fee waiver accounting")],
     "recommendation": "Extend the existing decisions.py 'Waiver' entry: 'Guideline Waiver' for investment exceptions; 'Fee Waiver' for 10 and 27."},
    {"term": "Review",
     "usages": [("33", "Breach Review / Periodic Rule Review", "Compliance review of a breach or of a rule or library"),
                ("36", "Product Review (PRVW-)", "Product governance review"),
                ("08", "Compliance Review (REV-)", "Marketing material review")],
     "recommendation": "Extend the 'Review' entry in proposals_36 with the two 33 objects."},
    {"term": "Limit",
     "usages": [("33", "Compliance Rule.Rule Limit Value", "Coded investment limit (including AIFMD leverage caps)"),
                ("31", "Risk Limit (RLMT-)", "Risk-program or risk committee limit on a risk measure"),
                ("25", "Counterparty Trading Limit", "Approved trading limit per counterparty"),
                ("24", "Portfolio Construction Constraint", "PM constraint used by the optimizer"),
                ("01", "Investment Restriction.Limit Value", "Limit as written")],
     "recommendation": "One limit, one owner (CD-223). Qualify every use; a 24 constraint is not a rule and a 31 limit is not a 33 rule."},
    {"term": "Exception",
     "usages": [("33", "Alert Disposition 'Approved Exception' / Guideline Waiver", "Approved departure from a rule"),
                ("22", "Price validation exception", "Price failing a tolerance check")],
     "recommendation": "Qualify as 'compliance exception' and 'pricing exception'."},
    {"term": "Check",
     "usages": [("33", "Compliance Check Run (CCHK-) / Manual Compliance Check", "Compliance test"),
                ("29", "TA Control Check (TACK-)", "Transfer agency operational control"),
                ("27", "NAV Control Check", "NAV production control")],
     "recommendation": "Qualify every use by the control domain."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. CHANGES PROPOSED TO OTHER DOMAINS (proposals only; 33 did not edit them)
# ---------------------------------------------------------------------------------------------------------------------
PROPOSED_CHANGES = [
    ("25", "Order Management / Trade Order Event / Compliance Check Outcome",
     "Re-note Derived copy (33) of Checks & Results / Check Subject Member / Compliance Check Outcome (same name, same values; "
     "one row per tested order, including each member order of a block). Row rule: 25 copies the outcome of the latest run "
     "before release that covered the order, alone or in a block; when an override changes the outcome, 25 records a second "
     "Compliance Checked event. 33 records a run even when no rule applies, so 'Not Checked' also has a 33 master. Optionally "
     "add 'Source Compliance Check Run' Reference (Compliance Check Run, 33). CD-180, CD-221."),
    ("12", "Guideline Monitoring & Breach Reporting / Breach Notification",
     "Add 'Related Investment Breach' Reference (Investment Breach, 33), example BREACH-2026-00143, CDE. Re-note Derived copy "
     "(33): Breach Type, Breach Detected Date, Breached Restriction, Cure Action, Cure Date (33 Investment Breach attributes of "
     "the same names). Add 'Breached Client Restriction' (Reference (Client Restriction)) beside Breached Restriction, because "
     "33 holds the primary source as a typed pair (01 RST- or 02 CRX-). 12 'Breached Mandate' stays mastered in 12 or is "
     "derived from the breach's portfolio (18 Portfolio Implementation Link); 33 holds no mandate on the breach. 12 keeps Client "
     "Notification Required Indicator, Client Notified Timestamp and Breach Notification Deadline (CD-222)."),
    ("12", "Certification & Threshold Notifications / Compliance Certificate",
     "Optional: add 'Supporting Manual Checks' Reference (Manual Compliance Check, 33) (multi) and read the evidential "
     "period-end run (Compliance Check Run.Evidential Period-End Run Indicator)."),
    ("01", "Investment Restrictions / Investment Restriction",
     "Statutory limits are mastered once in 33 Regulatory Limit Provision. A 01 restriction with Restriction Source 'Regulatory' "
     "is the prospectus restatement: add 'Restated Regulatory Provision' Reference (Regulatory Limit Provision, 33), and treat its "
     "Limit Value as the disclosed value, with the statutory value read from 33."),
    ("01", "Lists Measurement Basis and Regulatory Regime",
     "Add to Measurement Basis: '% of Total Assets', 'Days', 'Ratio', 'Rating Notch', '% of Commitments', '% of Capital'. Add to "
     "Regulatory Regime: 'IRC 817(h) Insurance-Dedicated', 'ERISA Plan Assets' (or create a separate scope list; see "
     "SHARED_CANDIDATES)."),
    ("09", "Shared list Regulator",
     "Add 'IRS / US Treasury' (Internal Revenue Service and US Department of the Treasury) so 33 Regulatory Limit Provisions for "
     "IRC 817(h) and Section 851 have a regulator. 33's local copy is unchanged until the shared list changes."),
    ("02", "ERISA party-in-interest lists",
     "If 02 maintains party-in-interest lists for plan clients (SME question 10), 33's 'ERISA Party-in-Interest Issuers' list "
     "becomes a sourced list (Members Held Here Indicator = N) and reads 02."),
    ("24", "Portfolio Construction Constraint", "No change; a note that constraints are not compliance rules (CD-221)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Open naming decision for the consolidation (flag only): 33 names its objects 'Investment Breach' and 'Compliance Rule', "
    "as do the 33 brief, CD-222 and the 35 module. 'Compliance Breach' survives in the 35 brief, in CD-234 "
    "(proposals_stage3_b) and in the 35 Board Report Type value 'Compliance Breach Summary'; the 35 brief also calls the rule "
    "object 'Guideline Rule'.",
    "Sibling object names used by 33, all present in the sibling modules: 31 Leverage & Exposure Measurement, Counterparty "
    "Exposure, Portfolio Risk Measure; 34 Sustainability Exclusion List; 35 Board Resolution and Reportable Fund Event; 36 "
    "Product Change Initiative.",
    "Lists sourced from 34 exclusion lists or the 38 restricted list hold no members in 33 (Members Held Here Indicator = N); "
    "no MNPI names are stored in 33. Rule Instrument List.Restricted List Source is text with Notes 'future owner 38' until "
    "Stage 4, then Reference (Restricted List, 38) (CD-224).",
    "Regulator notification of a breach is mastered by 35 Reportable Fund Event (Notified Regulator, Resulting Filing); 33 "
    "Breach Review keeps only Regulatory Notification Required Indicator and Resulting Reportable Fund Event.",
    "RIC and 817(h) determinations: 35 RIC Qualification Determination relies on 33 Compliance Rule Results, while CD-224 "
    "says the determination is 27 RIC Test Result. 27 vs 35 ownership is a consolidation question; 33 marks the evidential "
    "period-end run with Evidential Period-End Run Indicator.",
    "37 incidents (Stage 4) will reference BREACH-; nothing in 33 references 37 today.",
    "Rule 22e-4 (HLIM, 15% illiquid), Rule 18f-4 VaR tests and UCITS global exposure are deliberately absent: 31 Risk Limits "
    "(CD-223). UCITS Article 52(1) counterparty limits and AIFMD leverage caps are 33 rules reading 31 measurements.",
    "Rule 2a-7 daily and weekly liquid asset minimums are coded as 33 'Liquidity' rules (portfolio limits in a rule), unlike "
    "the Rule 22e-4 program (31). Confirm with 31 that this split matches its brief (SME question 7).",
]
