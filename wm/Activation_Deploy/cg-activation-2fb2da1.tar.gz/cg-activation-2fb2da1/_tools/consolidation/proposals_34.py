"""Consolidation proposals from the Data Domain 34 (Stewardship & Sustainable Investing) draft, 2026-10-06.

Proposal fragment only: the builder does not read this file. The Stage 3 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Formats follow CONTRACT.md in this folder. Boundary decisions CD-226 to CD-230 are in
proposals_stage3_b.py; this file holds what the draft found while implementing them.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES  (prefix, entity, owner domain, status, note) - decisions.PREFIXES format
# No prefixes beyond the five reserved in proposals_stage3_b.py CD-240 (VOTE-, ENGM-, ESGA-, PAIC-, VPOL-). Agenda items,
# recommendations, ballots, recall decisions, objectives, interactions, observations, determinations, exclusion lists,
# PAI results, outcomes, climate metrics, targets and reports keep composite keys (KEY_FORMATS).
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# 2. KEY_FORMATS (prefix or object, format, note)
# ---------------------------------------------------------------------------------------------------------------------
KEY_FORMATS = [
    ("VOTE-", "VOTE-<year>-<sequence, 8 digits>, e.g. VOTE-2026-00412873", "Vote instruction (ballot x agenda item)."),
    ("ENGM-", "ENGM-<year>-<sequence, 5 digits>, e.g. ENGM-2026-00318", "Engagement case."),
    ("ESGA-", "ESGA-<sequence, 7 digits>, e.g. ESGA-0004512", "Firm ESG assessment version."),
    ("PAIC-", "PAIC-<scope code: LEN or PRD plus number>-<reference year>-<version, 2 digits>, e.g. PAIC-LEN0004-2025-01, PAIC-PRD00431-2025-01", "PAI statement."),
    ("VPOL-", "VPOL-<policy code>-<version>, e.g. VPOL-HOUSE-2026", "Voting policy version."),
    ("Investee Meeting Agenda Item", "Composite: CAE- / agenda item number, e.g. 'CAE-2026-0012345 / 4a'", "Starts with 17's prefix; enrich_34 forces 'mastered here'."),
    ("Ballot", "Composite: CAE- (or 13 PRX- for an own fund) / SKA-, e.g. 'CAE-2026-0012345 / SKA-000231'", "Starts with 17's prefix; enrich_34 forces 'mastered here'."),
    ("Vote Rationale", "Composite: agenda item key / VPOL-, e.g. 'CAE-2026-0012345 / 4a / VPOL-HOUSE-2026'", "One decision per item and policy applied (review D)."),
    ("Voting Authority Arrangement", "Composite: PORT- (or ACC-) / effective from date, e.g. 'PORT-000412 / 2026-01-01'", "Starts with 18's prefix; enrich_34 forces 'mastered here'."),
    ("Engagement Interaction", "Firm-defined text: ENGM- key, '#', interaction number, e.g. 'ENGM-2026-00318 #03'", "No new prefix."),
    ("Sustainability Indicator Definition", "Composite: firm indicator code / version, e.g. 'GHG_SCOPE1 / 2', 'CARBON_FOOTPRINT / 1'", "Codes use underscores, not hyphens, so they never read as a prefix; one level per code."),
    ("Portfolio Sustainability Metric", "Composite: PORT- (or PRD-, LEN-) / period end / indicator code / emission scopes / measurement basis, e.g. 'PORT-000412 / 2025-12-31 / CARBON_FOOTPRINT / Scope 1+2 / Point in Time'",
     "Replaces 'Portfolio Climate Metric'; 31 Stress Test Result.Climate Metric Input should re-point to it and add the scopes and basis to its example."),
    ("Sustainability Exclusion List", "Composite: list code / version, e.g. 'TCOAL / 3'; members reference the list code only", "33 Rule Instrument List and 01 Investment Restriction cite this key."),
    ("Issuer Sustainability Observation", "System surrogate key (10 digits), e.g. 7700412881", "22 Price Observation pattern."),
    ("Proxy Voting Report", "Firm-defined text: period end year, report type code, reporting person key, e.g. '2026 NPX-FUND PRD-00431'", "35 Filing Document rows should use it (35's current example is descriptive text)."),
    ("Stewardship Report", "Firm-defined text: period end year, framework code, entity or product key, e.g. '2025 UKSC-AOR LEN-0004'", "Contains LEN-; enrich_34 forces 'mastered here' on references to it."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED MEMBERSHIPS: 34 local lists that carry an enterprise shared list's exact name and values. Register 34 as a
#    member (or as a direct user) of each. Values copied from shared_code_lists.py on 2026-10-06.
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Record Status", "local": "Record Status",
     "value_map": {"Draft": "DRAFT", "Proposed": "PROPOSED", "Pending": "PENDING", "Active": "ACTIVE", "Paused": "PAUSED",
                   "Inactive": "INACTIVE", "Deprecated": "DEPRECATED", "Retired": "RETIRED"},
     "new_values": [], "note": "Voting policies, indicator definitions, initiative memberships."},
    {"shared": "Approval Status", "local": "Approval Status",
     "value_map": {"Not Required": "NOT_REQUIRED", "Pending": "PENDING", "Approved": "APPROVED",
                   "Approved with Conditions": "APPROVED_WITH_CONDITIONS", "Retrospectively Approved": "RETROSPECTIVELY_APPROVED",
                   "Rejected": "REJECTED", "Expired": "EXPIRED", "Withdrawn": "WITHDRAWN"},
     "new_values": [], "note": "Policies, assessments, exclusion lists, PAI calculations, voting and stewardship reports."},
    {"shared": "Case Status", "local": "Case Status",
     "value_map": {"New / Received": "NEW", "Pending Good Order": "PENDING_GOOD_ORDER", "In Progress": "IN_PROGRESS",
                   "Waiting on Client": "WAITING_ON_CLIENT", "Pending Third Party": "PENDING_THIRD_PARTY", "Escalated": "ESCALATED",
                   "Resolved / Completed": "RESOLVED", "Closed": "CLOSED", "Rejected": "REJECTED", "Canceled": "CANCELED"},
     "new_values": [], "note": "Engagement workflow only (CD-227); the result is the local Engagement Outcome list."},
    {"shared": "Data Basis", "local": "Data Basis",
     "value_map": {"Reported / Actual": "REPORTED", "Estimated": "ESTIMATED", "Modeled": "MODELED", "Allocated": "ALLOCATED",
                   "Interpolated": "INTERPOLATED", "Survey-Based": "SURVEY_BASED", "Mixed": "MIXED"},
     "new_values": [], "note": "Sustainability observations and PAI results; separate from the source dataset (CD-228)."},
    {"shared": "Data Provider", "local": "Data Provider",
     "value_map": {"ICI": "ICI", "EFAMA": "EFAMA", "Investment Association": "INVESTMENT_ASSOCIATION", "Morningstar": "MORNINGSTAR",
                   "LSEG Lipper": "LSEG_LIPPER", "ISS Market Intelligence": "ISS_MARKET_INTELLIGENCE", "Broadridge": "BROADRIDGE",
                   "Cerulli Associates": "CERULLI", "Nasdaq eVestment": "NASDAQ_EVESTMENT", "Discovery Data": "DISCOVERY_DATA",
                   "FINTRX": "FINTRX", "FE fundinfo": "FE_FUNDINFO", "Citywire": "CITYWIRE", "US Department of Labor": "US_DOL",
                   "US SEC": "US_SEC", "Other": "OTHER", "Bloomberg": "BLOOMBERG", "ICE Data Services": "ICE_DATA_SERVICES",
                   "LSEG Data & Analytics": "LSEG_DATA_ANALYTICS", "S&P Global Market Intelligence": "SP_GLOBAL_MI",
                   "Moody's": "MOODYS", "Fitch Ratings": "FITCH", "MSCI": "MSCI", "FTSE Russell": "FTSE_RUSSELL", "DTCC": "DTCC",
                   "ANNA DSB": "ANNA_DSB", "CUSIP Global Services": "CUSIP_GLOBAL_SERVICES",
                   "S&P Dow Jones Indices": "SP_DOW_JONES_INDICES", "J.P. Morgan PricingDirect": "JPM_PRICINGDIRECT",
                   "Tradeweb": "TRADEWEB", "MarketAxess": "MARKETAXESS", "STOXX": "STOXX", "Solactive": "SOLACTIVE", "FINRA": "FINRA"},
     "new_values": [
         ("ISS_STOXX", "ISS STOXX", "Proxy research, voting recommendations and ESG data (ISS Governance, ISS ESG); distinct from ISS Market Intelligence."),
         ("GLASS_LEWIS", "Glass Lewis", "Proxy research and voting recommendations."),
         ("SUSTAINALYTICS", "Sustainalytics", "ESG risk ratings and controversy research (Morningstar company)."),
         ("CDP", "CDP", "Company-reported climate, water and forest disclosures."),
         ("MSCI_ESG_RESEARCH", "MSCI ESG Research", "ESG ratings, climate and controversy data. Optional: keep 'MSCI' and identify the product through the 14 dataset."),
     ],
     "note": "Brief §8 proposed ISS, Glass Lewis, MSCI ESG, Sustainalytics and CDP. 'ISS STOXX' is used rather than 'ISS' to avoid "
             "confusion with the existing ISS Market Intelligence value. The 34 local copy is identical to the "
             "shared list (review F); the five values are proposed here only. Used for Originating Provider, whose example is 'Other' "
             "until CDP is added."},
    {"shared": "Inclusion Type", "local": "Inclusion Type",
     "value_map": {"Include": "INCLUDE", "Exclude": "EXCLUDE"}, "new_values": [],
     "note": "Exclusion List Member: Exclude is the main case and Include a carve-back (e.g. a green bond of an excluded issuer). "
             "Ask 09 to widen the shared definition of Exclude, now 'carve-out from a larger included unit', to cover a listed exclusion."},
    {"shared": "Severity", "local": "Severity",
     "value_map": {"Low": "LOW", "Medium": "MEDIUM", "High": "HIGH", "Critical": "CRITICAL"}, "new_values": [],
     "note": "Vendor controversy severity and the firm's controversy view."},
    {"shared": "RAG Status", "local": "RAG Status",
     "value_map": {"Green": "GREEN", "Amber": "AMBER", "Red": "RED"}, "new_values": [], "note": "Climate target progress."},
    {"shared": "Information Classification", "local": "Information Classification",
     "value_map": {"Public": "PUBLIC", "Internal": "INTERNAL", "Confidential": "CONFIDENTIAL",
                   "Confidential - Personal Data": "CONFIDENTIAL_PERSONAL_DATA", "Confidential - Client": "CONFIDENTIAL_CLIENT",
                   "Confidential - Financial": "CONFIDENTIAL_FINANCIAL", "Confidential - Compensation": "CONFIDENTIAL_COMPENSATION",
                   "Confidential - Licensed": "CONFIDENTIAL_LICENSED", "Restricted": "RESTRICTED",
                   "Restricted - Personal Data": "RESTRICTED_PERSONAL_DATA", "Restricted - MNPI": "RESTRICTED_MNPI",
                   "Restricted - Commercial Terms": "RESTRICTED_COMMERCIAL_TERMS", "Restricted - Legal": "RESTRICTED_LEGAL"},
     "new_values": [], "note": "Engagement classification (MNPI)."},
]
# Not used although the brief §8 listed them: Frequency, Period Type, Reporting Period Basis, Regulator and Business Line.
# Reporting Period Type and Receiving Regulator were cut to stay within the attribute target (the reporting period end and
# report type carry the meaning); Engagement Business Lines was cut because the engaged holdings are derivable from 18.

# ---------------------------------------------------------------------------------------------------------------------
# 4. SHARED_CANDIDATES: local 34 lists that look like enterprise lists, or overlap another domain's list
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Proposal Category", ["13", "34"],
     "Compare with 13 'Fund Proposal Type' (matters put to our own funds' shareholders: elect trustees, approve advisory agreement, "
     "reorganization). Different concept and taxonomy (34 is the 14 Form N-PX categories). Recommend NOT_MERGED; 35 may want 34's "
     "list if it reports N-PX category counts."),
    ("ESG Rating Type", ["11", "34"],
     "11 'Rating Scheme' lists fund-level rating schemes (Morningstar star rating, Sustainability Rating). 34 lists kinds of "
     "issuer-level vendor assessment. Recommend NOT_MERGED; record the split in the 'Rating' term conflict."),
    ("Engagement Theme", ["23", "34"],
     "23 'Meeting Topic Category' overlaps on Governance and Board, Executive Remuneration, Environmental and Social values. "
     "Candidate shared list 'ESG Topic' stewarded by 34, with 23 keeping research-only topics (Financial Results, Strategy) local."),
    ("Engagement Contact Medium", ["23", "34"],
     "23 'Meeting Channel' (in person, video, phone) describes how a 23 meeting was held; 34 Engagement Contact Medium is the "
     "medium of any contact (meeting or call, letter, email). Keep both; the glossary must qualify them."),
    ("Metric Framework", ["31", "34", "35"],
     "Framework tags on portfolio sustainability metrics; 31 climate stress and 35 regulatory reporting may want the same values."),
    ("Exclusion Policy Basis", ["01", "33", "34"],
     "01 Investment Restriction (Restriction Source 'ESG Exclusion Policy') and 33 Rule Instrument List may need the same basis "
     "values; candidate shared list stewarded by 34."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. PARTY ROLE TYPE values proposed for 02 (CD-143). 34 does not edit 02.
# ---------------------------------------------------------------------------------------------------------------------
PARTY_ROLE_TYPE_ADDITIONS = [
    ("02", "Party Role Type", "Proxy Advisor", "Proxy voting advice business that issues voting recommendations (Proxy Advisor Recommendation.Proxy Advisor; Voting Policy.Benchmark Proxy Advisor)."),
    ("02", "Party Role Type", "Proxy Voting Agent", "Platform that receives ballots and transmits vote instructions (Voting Authority Arrangement.Voting Platform Provider)."),
    ("02", "Party Role Type", "Collaborative Engagement Initiative", "Investor initiative or network the firm joins (Collaborative Initiative Membership, Engagement.Collaborative Initiative, Climate Target.Target Initiative)."),
    ("02", "Party Role Type", "Stewardship Framework Body", "Body that grants signatory status on a stewardship report, such as the FRC (Signatory Status.Status Granting Body). PRI is a Collaborative Engagement Initiative, not a framework body here."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. TERM_CONFLICTS (decisions.TERM_CONFLICTS format)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Proxy / Vote",
     "usages": [("13", "Proxy Campaign (PRX-), Proxy Proposal, Vote Tally, Intermediary Vote Instruction", "Solicitation of our own funds' shareholders."),
                ("34", "Investee Meeting Agenda Item, Ballot, Vote Instruction (VOTE-)", "How the firm votes the shares its portfolios hold.")],
     "recommendation": "CD-226: always qualify: 'Fund Proxy Campaign' (13) vs 'Investee Proxy Vote' (34). '13 Intermediary Vote Instruction' and '34 Vote Instruction' must not share a glossary entry."},
    {"term": "Engagement",
     "usages": [("34", "Engagement (ENGM-)", "Stewardship engagement case with an investee or market participant."),
                ("03", "Activity (ACT-)", "Sales activity with intermediaries."),
                ("04", "Digital engagement", "Web and email engagement events."),
                ("13", "Servicing Provider Engagement", "Contract with a servicing provider.")],
     "recommendation": "As proposals_stage3_b: unqualified 'Engagement' is the 34 stewardship case; others qualify ('Sales Activity', 'Digital Engagement', 'Provider Engagement')."},
    {"term": "Meeting",
     "usages": [("13", "Proxy Campaign meeting", "Own fund shareholder meeting."),
                ("17", "Corporate Action Event (meeting types proposed)", "Investee general meeting as a reference event."),
                ("23", "Issuer Meeting (IMTG-)", "Research meeting with issuer management."),
                ("24", "Investment Committee meeting", ""), ("35", "Board Meeting (BMEET-)", ""), ("36", "Product governance meeting", ""),
                ("34", "Investee Meeting Agenda Item, Ballot", "Agenda and ballots of a 17 meeting; no meeting object.")],
     "recommendation": "As proposals_stage3_b: 'Investee Shareholder Meeting' (17 CAE-), 'Fund Shareholder Meeting' (13 PRX-), 'Issuer Meeting' (23), 'Board Meeting' (35); 34 holds no meeting record."},
    {"term": "Rating",
     "usages": [("11", "Rating Observation (RTG-)", "Fund-level ratings, including sustainability ratings."),
                ("17", "Credit Rating Assignment", "Agency credit ratings."),
                ("23", "Internal Credit Assessment", "Internal credit view."),
                ("34", "ESG Rating Observation; Firm ESG Assessment (ESGA-)", "Issuer-level vendor ESG ratings; the firm's own ESG score.")],
     "recommendation": "CD-228: 'ESG Rating Observation' (vendor, issuer-level, 34) vs 'Fund Sustainability Rating' (11) vs 'Credit Rating' (17); the firm's own view is an 'ESG Assessment', never a 'rating'."},
    {"term": "Assessment",
     "usages": [("08", "Distributor due diligence assessments", ""), ("36", "Product review / value assessment", ""),
                ("34", "Firm ESG Assessment", "Firm's ESG view of an issuer.")],
     "recommendation": "Qualify as 'ESG Assessment' (34), 'Value Assessment' (36), 'Distributor Due Diligence' (08)."},
    {"term": "Metric",
     "usages": [("21", "Metric Definition (KPI-)", "Enterprise KPI registry."),
                ("34", "Sustainability Indicator Definition; Portfolio Sustainability Metric", "Sustainability indicators (issuer, portfolio, entity level) and their portfolio values.")],
     "recommendation": "34 sustainability indicators are not 21 KPIs (brief §4); name them 'Sustainability Indicator' and 'Portfolio Sustainability Metric'. 21 may catalog them by reference."},
    {"term": "Policy",
     "usages": [("08", "Compliance policies", ""), ("22", "Pricing Policy", ""), ("25", "Best Execution Policy", ""),
                ("34", "Voting Policy (VPOL-)", "")],
     "recommendation": "Always qualify ('Voting Policy')."},
    {"term": "Exclusion",
     "usages": [("01", "Investment Restriction (Restriction Source 'ESG Exclusion Policy')", "Product-level limit."),
                ("02", "Client Restriction (Exclusion List Reference)", "Client-supplied list."),
                ("33", "Rule Instrument List (Source Sustainability Exclusion List)", "Coded compliance list fed from the 34 list."),
                ("34", "Sustainability Exclusion List", "Firm's own list and members.")],
     "recommendation": "34 masters the firm's list; 01 and 33 reference it; 02 client lists stay client-supplied."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. CHANGES PROPOSED TO OTHER DOMAINS (for the program lead; 34 does not edit them)
# ---------------------------------------------------------------------------------------------------------------------
CHANGES_TO_OTHER_DOMAINS = [
    ("17", "Corporate Action Events / Corporate Action Event Type list",
     "CD-226: add Annual General Meeting (MEET), Extraordinary General Meeting (XMET), Ordinary General Meeting (OMET), "
     "Bondholder Meeting (BMET) and Court Meeting (CMET, UK schemes of arrangement). Add a 'Meeting Date' attribute to Corporate "
     "Action Event for meeting types: 17 has Record Date but no meeting date, Form N-PX reports the meeting date for every vote, "
     "and 34 does not repeat it. This is a blocker for complete N-PX content."),
    ("02", "Party Role Type", "Add the values in PARTY_ROLE_TYPE_ADDITIONS."),
    ("28", "Securities Lending / Securities Loan",
     "Add a dated on-loan quantity (loan quantity history by date, or a loan position by business date) so 34 Ballot.Shares on "
     "Loan Not Recalled can be derived as 'quantity on loan at the record date and not returned before it'. Today Loan Quantity "
     "is the latest state only. Recall Date stays 28; 34 Lending Recall Decision.Recall Requested Date is the stewardship "
     "team's request to the agent lender. Optionally add a 28 recall reason value 'Proxy Vote'."),
    ("28", "Corporate Action Entitlement / Eligible Balance",
     "No change. 34 Ballot.Record Date Shares is a Derived copy of Eligible Balance through Ballot Entitlement; confirm it includes shares on loan."),
    ("13", "Proxy Campaign / Proxy Proposal / Vote Tally",
     "No change. A meeting of an own fund is a 13 Proxy Campaign. 34 records a Ballot only where an own portfolio holds the fund, "
     "referencing the PRX- (not a 17 CAE-), and its Vote Instructions reference 13 Proxy Proposals (PRP-). 13's Mirror / Echo "
     "Voted Shares stays the tally and 34 never copies it."),
    ("31", "Stress Testing / Stress Test Result / Climate Metric Input",
     "Re-point from Reference (Portfolio Climate Metric, 34) to Reference (Portfolio Sustainability Metric, 34), and use the new "
     "key format (with emission scopes and measurement basis). The methodology value for WACI is 'IFRS S2 / TCFD', not 'PCAF'."),
    ("09", "Shared code lists / Inclusion Type; Unit of Measure",
     "Widen the definition of Inclusion Type 'Exclude' (see SHARED_MEMBERSHIPS). Add units used by 34 indicators to Unit of "
     "Measure: tCO2e, tCO2e per EUR (or USD) million invested, tCO2e per EUR million revenue, degrees Celsius (implied temperature rise)."),
    ("01", "Investment Policy & Risk / Investment Restriction",
     "Optional: add 'Cited Exclusion List' Reference (Sustainability Exclusion List, 34) where Restriction Source is 'ESG Exclusion Policy'."),
    ("01", "ESG Classification",
     "Proposed, not applied (CD-229): Derived copies (34) of the latest Achieved Sustainable Investment Percentage and Achieved "
     "Taxonomy-Aligned Investment Percentage for EET delivery."),
    ("12", "Report Definition / Stewardship Report Scope",
     "No change; 12 presents 34 votes, engagements and metrics, including the SMA Client Voting Report content. 12 'Stewardship "
     "Content' values should match 34 report types."),
    ("23", "Issuer Meeting Topic / Stewardship Objective Indicator",
     "No change (CD-172). 34 Engagement Interaction references IMTG-; a data quality rule (21) can check that interactions with an "
     "IMTG- reference point at a meeting with at least one topic flagged."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 8. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Register VOTE-, ENGM-, ESGA-, PAIC-, VPOL- (owner 34) in decisions.PREFIXES with the KEY_FORMATS above. Self-references "
    "use 'Reference (X, 34)'; nine composite keys starting with CAE-, PORT- or LEN- are forced to 'mastered here' in enrich_34, "
    "and three 13 references with blank examples are forced to 13.",
    "Add CONCEPT_OWNERSHIP rows: Voting Policy (34, VPOL-), Voting Authority Arrangement (34), Investee Meeting Agenda Item (34), "
    "Ballot (34), Vote Rationale (34), Vote Instruction (34, VOTE-), Engagement (34, ENGM-), Sustainability Indicator Definition (34), "
    "Issuer Sustainability Observation (34), Firm ESG Assessment (34, ESGA-), Sustainability Exclusion List (34), PAI Calculation "
    "(34, PAIC-), Portfolio Sustainability Metric (34), Product Sustainability Outcome (34), Proxy Voting Report (34), Stewardship "
    "Report (34), Signatory Status (34). Expected referrers: 01, 12, 31, 33, 35.",
    "Stage-wide ruling (CD-237 over CD-225), applied: board approval of a voting policy is held only on 35 Resolution Subject Link, "
    "and the N-PX filing link only on 35's Filing Document rows (one per series' Proxy Voting Report). 34 holds no reference to "
    "35. The earlier requests to 33 (Source Sustainability Exclusion List) and 35 (Filed Proxy Voting Report, Voting Policy "
    "subject type) were removed: 33 and 35 have done them.",
    "Program lead decision 1, applied: Sustainability Indicator Definition carries Indicator Level (Issuer / Portfolio / Entity) and "
    "a unit per level; PAI Indicator Result and Portfolio Climate Metric were merged into Portfolio Sustainability Metric, tagged "
    "by Metric Framework, so one financed emissions value serves SFDR PAI and TCFD / ISSB. The 'Climate Metric' code list was "
    "retired; climate targets reference indicators.",
    "Derived copies in 34: Ballot.Record Date Shares (28 Corporate Action Entitlement.Eligible Balance; 18 holding for own-fund "
    "meetings), Ballot.Shares on Loan Not Recalled (28, needs a dated loan quantity), Financed Emissions Holding Detail.Holding "
    "Value Used (18) and Attribution Denominator Value (owner by row: 22 listed EVIC as primary, 14 vendor EVIC, 30 private "
    "company fair value, 14 sovereign dataset for PPP-adjusted GDP).",
    "Proxy Voting Report reports Vote Instructions n : n by a selection rule (reporting person, period, category); no report line "
    "is stored. If report content must be frozen at filing, add a report line object at consolidation.",
    "Dependency: the entity-level PAI scope depends on the SFDR review proposal of 20 November 2025; product scope is unaffected.",
    "Dependency and blocker: 17 must add the meeting event types and a meeting date before 34 agenda items and ballots can key to "
    "a meeting CAE- and before the N-PX content is complete (add to CD-226).",
    "Future owners: 37 Model Risk (ESG scoring and temperature models; held as text 'Assessment Methodology Name', 'Metric "
    "Model Name'); 38 Corporate Compliance (Schedule 13G determination; 34 holds only Passive Status Review Indicator).",
]
