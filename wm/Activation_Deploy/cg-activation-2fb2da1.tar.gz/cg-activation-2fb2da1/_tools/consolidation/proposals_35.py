"""Consolidation proposals from the Data Domain 35 (Fund Governance & Regulatory Reporting) draft v0.1, 2026-10-06.

Proposal fragment only: the builder does not read this file. The Stage 3 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Formats follow CONTRACT.md in this folder. Boundary decisions CD-230 to CD-235 and
CD-237 are in proposals_stage3_b.py; this file holds what the draft found while implementing them. Nothing here changes
another domain's module.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES (prefix, entity, owner domain, status, note) - decisions.PREFIXES format
# None beyond the six reserved in proposals_stage3_b.py (BOARD-, BMEET-, RESO-, ADVA-, RENEW-, REGF-). Coverage,
# memberships, officer appointments, agenda items, reports, subject links, bonds, materials, findings, obligations,
# certifications, sources, disclosures, determinations, events and relief keep composite keys.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

PREFIX_REGISTRATIONS = ["BOARD-", "BMEET-", "RESO-", "ADVA-", "RENEW-", "REGF-"]

# Key formats published by 35 (decisions.PREFIX_FORMATS format: prefix, owner, format, example)
KEY_FORMATS = [
    ("BOARD-", "35", "BOARD-<sequence, 4 digits>", "BOARD-0012"),
    ("BMEET-", "35", "BMEET-<body number, 4 digits>-<meeting date YYYYMMDD>-<sequence, 2 digits>; a written consent takes its effective date", "BMEET-0012-20261118-01"),
    ("RESO-", "35", "RESO-<year>-<sequence, 5 digits>", "RESO-2026-00412"),
    ("ADVA-", "35", "ADVA-<sequence, 5 digits>", "ADVA-00041"),
    ("RENEW-", "35", "RENEW-<agreement number, 5 digits>-<renewal year>", "RENEW-00041-2026"),
    ("REGF-", "35", "REGF-<form code, letters and digits only>-<year>-<sequence, 6 digits>", "REGF-NPORT-2026-004512"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. CONCEPT_OWNERSHIP rows (concept, owner, prefix, referencing domains, note)
# ---------------------------------------------------------------------------------------------------------------------
CONCEPT_OWNERSHIP = [
    ("Fund Governing Body", "35", "BOARD-", ["01", "31", "36", "39"], "CD-231. Registrant boards, committees, ManCo / AIFM / AFM boards, CIT trustee fiduciary committees, LPACs."),
    ("Board Meeting", "35", "BMEET-", ["36"], "Includes actions by written consent (meeting type)."),
    ("Board Resolution", "35", "RESO-", ["13", "27", "31", "33", "34", "36"], "CD-237 (prevails over CD-225): what a resolution approved is held only on Resolution Subject Link; consumers hold a derived status at most."),
    ("Agreement Fund Schedule", "35", "", ["10"], "Agreement x fund x approval cycle: 01 fee schedule, 13 proxy proposal, per-fund 15(c) outcome."),
    ("Fund Advisory Agreement", "35", "ADVA-", ["10", "39"], "CD-232 (closes CD-022). Fee terms stay 01."),
    ("Advisory Contract Renewal", "35", "RENEW-", ["11"], "CD-232. Section 15(c) continuance."),
    ("Filing Obligation", "35", "", ["01"], "CD-233. 01 'Regulatory Reporting Obligations' becomes a Derived copy. Periodic forms only; event-driven filings have no obligation row."),
    ("Fund Regulatory Filing", "35", "REGF-", ["01", "13", "27", "34", "36"], "CD-233. One record per fund-level submission."),
    ("RIC Qualification Determination", "35", "", ["27"], "CD-191, CD-235."),
    ("Reportable Fund Event", "35", "", ["31", "33"], "N-RN, N-CR, UCITS / AIFMD / COLL notifications."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_MEMBERSHIPS: 35 local lists that carry an enterprise shared list's exact name and values (copied from
#    shared_code_lists.py). Register 35 as a member (identity value_map) or as a direct user and switch the attributes to
#    "Shared: <name>".
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Record Status", "local": "Record Status", "attributes": "Fund Governing Body.Governing Body Status",
     "value_map": {"Draft": "DRAFT", "Proposed": "PROPOSED", "Pending": "PENDING", "Active": "ACTIVE", "Paused": "PAUSED", "Inactive": "INACTIVE", "Deprecated": "DEPRECATED", "Retired": "RETIRED"},
     "new_values": []},
    {"shared": "Approval Status", "local": "Approval Status", "attributes": "Board Meeting.Minutes Approval Status",
     "value_map": {"Not Required": "NOT_REQUIRED", "Pending": "PENDING", "Approved": "APPROVED", "Approved with Conditions": "APPROVED_WITH_CONDITIONS", "Retrospectively Approved": "RETROSPECTIVELY_APPROVED", "Rejected": "REJECTED", "Expired": "EXPIRED", "Withdrawn": "WITHDRAWN"},
     "new_values": []},
    {"shared": "Agreement Status", "local": "Agreement Status", "attributes": "Fund Advisory Agreement.Advisory Agreement Status",
     "value_map": {"Draft": "DRAFT", "In Negotiation": "IN_NEGOTIATION", "Pending Signature": "PENDING_SIGNATURE", "Executed - Not Yet Effective": "EXECUTED_NOT_EFFECTIVE", "Active": "ACTIVE", "Suspended": "SUSPENDED", "Under Notice of Termination": "UNDER_NOTICE", "Terminated": "TERMINATED", "Expired": "EXPIRED", "Superseded": "SUPERSEDED"},
     "new_values": []},
    {"shared": "Frequency", "local": "Frequency", "attributes": "Filing Obligation.Filing Frequency",
     "value_map": {"Real-Time": "REAL_TIME", "Intraday": "INTRADAY", "Daily": "DAILY", "Weekly": "WEEKLY", "Fortnightly": "FORTNIGHTLY", "Monthly": "MONTHLY", "Quarterly": "QUARTERLY", "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL", "Biennial": "BIENNIAL", "On Event": "ON_EVENT", "Ad Hoc": "AD_HOC"},
     "new_values": []},
    {"shared": "Regulator", "local": "Regulator", "attributes": "Filing Obligation.Obligation Regulator; Reportable Fund Event.Notified Regulator",
     "value_map": {"SEC": "US_SEC", "FINRA": "US_FINRA", "US State Securities Regulator": "US_STATE_SECURITIES_REGULATOR", "CFTC / NFA": "US_CFTC_NFA", "OCC": "US_OCC", "US State Banking Regulator": "US_STATE_BANKING_REGULATOR", "Federal Reserve": "US_FEDERAL_RESERVE", "DOL / EBSA": "US_DOL_EBSA", "US State Insurance Regulator": "US_STATE_INSURANCE_REGULATOR", "FCA": "UK_FCA", "PRA": "UK_PRA", "CSSF": "LU_CSSF", "Central Bank of Ireland": "IE_CBI", "BaFin": "DE_BAFIN", "AMF": "FR_AMF", "CONSOB / Banca d'Italia": "IT_CONSOB_BANCA_D_ITALIA", "CNMV": "ES_CNMV", "AFM": "NL_AFM", "FINMA": "CH_FINMA", "Other EU NCA": "OTHER_EU_NCA", "ESMA": "EU_ESMA", "European Commission": "EU_COMMISSION", "IOSCO": "INTL_IOSCO", "IRS": None},
     "new_values": [("US_IRS", "IRS", "US Internal Revenue Service (Form 1120-RIC and Form 8613 obligations of RICs).")],
     "note": "35 adds IRS locally (review finding F); register the value in the shared list, or 35 drops it at consolidation."},
    {"shared": "Severity", "local": "Severity", "attributes": "Reportable Fund Event.Event Severity",
     "value_map": {"Low": "LOW", "Medium": "MEDIUM", "High": "HIGH", "Critical": "CRITICAL"},
     "new_values": []},
    {"shared": "Information Classification", "local": "Information Classification", "attributes": "Board Meeting.Board Materials Classification",
     "value_map": {"Public": "PUBLIC", "Internal": "INTERNAL", "Confidential": "CONFIDENTIAL", "Confidential - Personal Data": "CONFIDENTIAL_PERSONAL_DATA", "Confidential - Client": "CONFIDENTIAL_CLIENT", "Confidential - Financial": "CONFIDENTIAL_FINANCIAL", "Confidential - Compensation": "CONFIDENTIAL_COMPENSATION", "Confidential - Licensed": "CONFIDENTIAL_LICENSED", "Restricted": "RESTRICTED", "Restricted - Personal Data": "RESTRICTED_PERSONAL_DATA", "Restricted - MNPI": "RESTRICTED_MNPI", "Restricted - Commercial Terms": "RESTRICTED_COMMERCIAL_TERMS", "Restricted - Legal": "RESTRICTED_LEGAL"},
     "new_values": []},
    {"shared": "Business Line", "local": "Business Line", "attributes": "Governed Fund Coverage.Covered Business Line (Derived copy 18)",
     "value_map": {"Mutual Fund": "MUTUAL_FUND", "ETF": "ETF", "Collective Investment Trust": "COLLECTIVE_INVESTMENT_TRUST", "Separately Managed Account": "SEPARATELY_MANAGED_ACCOUNT", "Private Markets": "PRIVATE_MARKETS", "Insurance-Dedicated Fund": "INSURANCE_DEDICATED_FUND"},
     "new_values": [], "note": "35 never uses 'Separately Managed Account' (SMAs have no fund board) but keeps it so the list stays identical."},
    {"shared": "Data Basis", "local": "Data Basis", "attributes": "Filing Data Source.Source Data Basis",
     "value_map": {"Reported / Actual": "REPORTED", "Estimated": "ESTIMATED", "Modeled": "MODELED", "Allocated": "ALLOCATED", "Interpolated": "INTERPOLATED", "Survey-Based": "SURVEY_BASED", "Mixed": "MIXED"},
     "new_values": []},
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. SHARED_CANDIDATES: local 35 lists that look like enterprise lists
#    (list name in 35, proposed shared list name or None, likely other users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Filing Form Type", None, ["08", "16", "19", "36", "38"],
     "08 Regulator Filing Type (notification kinds), 16 Government Filing Form (5500 series) and 19 regulatory returns name "
     "different filings for different filers. Record as NOT_MERGED; 36 Change Regulatory Requirement should reference 35 form "
     "types, and 38 (Stage 4) firm filings (Form ADV, 13F) should get their own list."),
    ("Filing Status", "Regulatory Filing Status", ["16", "19"],
     "Same lifecycle as 16 Filing Status (EFAST2) and 19 Return Filing Status, but with different values (16 has signature "
     "steps, 19 has 'Amended' and 'Extended', which 35 models as an amending filing and a due date). A shared lifecycle list "
     "is possible if 'Amended' is dropped as a status. Recommend NOT_MERGED for v0.1, review at Stage 4 with 38."),
    ("Board Meeting Type", None, ["22", "24", "36"],
     "22 Valuation Committee Meeting, 24 Investment Committee Meeting and 36 Product Committee Meeting have similar types. The "
     "bodies are different (CD-231), so keep local; consider one 'Committee Meeting Type' list if 39 adopts the 35 pattern."),
    ("Meeting Format", "Meeting Format", ["03", "04", "13", "23", "34"],
     "In Person / Virtual / Hybrid / Telephonic appears as meeting or interaction channel in 03, 04 (events), 13 (shareholder "
     "meetings), 23 (issuer meetings) and 34. Candidate shared list stewarded by 09."),
    ("Fund Officer Role", None, ["01", "20", "31"],
     "01 Product Party Role Type covers service-provider firms, not individual officers. 31 Risk Program Designation names "
     "the program administrator; propose 31 references the 35 Fund Officer Appointment instead of holding the administrator."),
    ("Consent Type", None, ["30"],
     "30 Side Letter Provision Type has 'LPAC Seat'; LPAC consents are recorded here (SME question 7). Keep local."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. CHANGE PROPOSALS to other domains (proposed, not applied): (domain, object / list, proposed change, rationale)
# ---------------------------------------------------------------------------------------------------------------------
VALUE_PROPOSALS = [
    ("01", "Product Governance.Governing Body", "Re-type from Reference (Party) to Reference (Fund Governing Body, 35), example BOARD-0012.", "CD-231."),
    ("01", "list Product Party Role Type", "Retire value 'Board of Directors'; the body is a 35 Fund Governing Body.", "CD-231."),
    ("01", "Regulatory Authorization.Regulatory Reporting Obligations", "Make a Derived copy (35) of Filing Obligation (form types with an open obligation for the product).", "CD-233."),
    ("02", "list Party Role Type", "Add values 'Independent Fund Director / Trustee', 'Independent Counsel to Fund Directors', 'Fidelity Bond Insurer', 'Fund Filing Agent', 'LPAC Member Representative', 'CIT Trustee Bank'.", "CD-143; 35 references these parties (third-party CIT trustee on Fund Governing Body.Governed Trustee Party)."),
    ("10", "Revenue Contract.Underlying Agreement", "Re-type to Reference (Fund Advisory Agreement, 35) on rows of revenue contract type 'Investment Advisory Agreement (Fund)'; mandate rows keep MND-.", "CD-232 (closes CD-022). Row rule."),
    ("13", "Shareholder Communication.Regulatory Filing Reference; Tailored Shareholder Report.Form N-CSR Filing Date",
     "Make Derived copies (35) of Fund Regulatory Filing.Accession Number and Official Filing Date of the N-CSR / N-CSRS or 497 filing whose Filing Document lists the communication.", "CD-233; review finding C (official filing date, not the submission timestamp)."),
    ("13", "Shareholder Communication.Website Availability Date", "No change: 13 masters it; 35 Fund Public Disclosure.Publication Timestamp is a Derived copy (13) on 'Shareholder Report Website Availability' rows.", "Program lead decision 5."),
    ("13", "Shareholder Communication (approval)", "Hold no board approval reference; the approval of a shareholder report is held on 35 Resolution Subject Link (subject type 'Shareholder Communication (13)').", "CD-235, CD-237."),
    ("27", "Fund Tax Year Record.Fund Tax Return Type (filing evidence)", "Add Reference (Fund Regulatory Filing, 35) for the Form 1120-RIC and Form 8613 filings; Filing Form Type includes both.", "CD-191. SME question 11."),
    ("27", "Fund Financial Statement (approval)", "Hold no board approval reference; the approval is on 35 Resolution Subject Link (subject type 'Fund Financial Statement (27)').", "CD-235, CD-237."),
    ("31", "Highly Liquid Investment Minimum.HLIM Board Approval", "Drop the Reference (Board Resolution, 35), or replace it with a derived approval status read from 35 Resolution Subject Link (Subject Highly Liquid Investment Minimum).", "CD-237 prevails over CD-225 (program lead ruling)."),
    ("31", "Risk Program Designation.Program Board Approval", "Drop the Reference (Board Resolution, 35), or replace it with a derived approval status read from 35 Resolution Subject Link (Subject Risk Program Designation). 'Administrator Appointment' (Reference (Fund Officer Appointment, 35)) stays: the appointment is a 35 record that carries its own resolution.", "CD-237 prevails over CD-225."),
    ("33", "Guideline Waiver.Approving Board Resolution", "Drop it for board-approved fund waivers, or replace it with a derived approval status read from 35 Resolution Subject Link (Subject Guideline Waiver). Client-approved waivers keep their client approver.", "CD-237 prevails over CD-225."),
    ("33", "Breach Review (regulatory notification required)", "Where the notification is made, find it through 35 Reportable Fund Event.Source Investment Breach and its Resulting Filing; 33 holds no REGF- reference.", "CD-234; one direction."),
    ("34", "Voting Policy.Approving Board Resolution", "Drop it, or replace it with a derived approval status read from 35 Resolution Subject Link (Subject Voting Policy).", "CD-237 prevails over CD-225."),
    ("34", "Proxy Voting Report.Voting Report Filing", "Drop the Reference (Fund Regulatory Filing, 35); the N-PX link is held only on 35 Filing Document.Filed Proxy Voting Report. Hold no filing date or accession number.", "CD-230; program lead decision 5."),
    ("36", "Change Regulatory Requirement.Satisfying Filing", "No change: 36 holds the change-to-filing link; 35 dropped 'Originating Change Initiative'.", "Program lead decision 1 (CD-233)."),
    ("36", "Change Regulatory Requirement rows of type 'Fund Board Approval' and 'CIT Trustee Approval'", "Derived copy (35) from the Board Resolution of the 35 Resolution Subject Link whose subject is the change; CIT trustee committees are 35 Fund Governing Bodies of type 'CIT Trustee Fiduciary Committee'.", "CD-231, CD-237; program lead decision 3."),
    ("36", "Product Proposal, Product Change Initiative, Product Review (approval)", "Hold no board approval reference; derived status only.", "CD-237."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. TERM_CONFLICTS (decisions.TERM_CONFLICTS format)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Board",
     "usages": [("35", "Fund Governing Body (BOARD-)", "Board of a registrant, ManCo, AIFM, AFM; trustee fiduciary committee; LPAC"),
                ("01", "Product Governance.Governing Body; Product Party Role Type 'Board of Directors'", "Party reference to the fund board"),
                ("39", "Corporate board (future)", "Boards of the adviser, broker-dealer and holding companies")],
     "recommendation": "'Board' means a 35 Fund Governing Body until 39 is built; 01 re-types (CD-231). Corporate boards are named 'Corporate Board' in 39."},
    {"term": "Committee",
     "usages": [("35", "Fund Governing Body of type 'Board Committee'", "Committee of a fund board (audit, contracts, governance)"),
                ("22", "Valuation Committee", "Management committee acting for the valuation designee"),
                ("24", "Investment Committee", "Management committee that approves investment decisions"),
                ("36", "Product Governance Committee", "Management committee that approves products"),
                ("21", "Data Governance Body", "Data governance council")],
     "recommendation": "Always qualify: 'Board Committee' (35) vs 'Valuation Committee' (22), 'Investment Committee' (24), 'Product Governance Committee' (36). 35 list value 'Valuation Oversight' names the board committee, never the 22 committee."},
    {"term": "Meeting",
     "usages": [("35", "Board Meeting (BMEET-)", "Meeting or written consent of a fund governing body"),
                ("13", "Proxy Campaign / shareholder meeting", "Meeting of fund shareholders"),
                ("23", "Issuer Meeting (IMTG-)", "Research meeting with an issuer"),
                ("34", "Investee meeting (17 CAE-)", "General meeting of an investee company")],
     "recommendation": "Qualify: 'Board Meeting' (35), 'Shareholder Meeting' (13), 'Issuer Meeting' (23), 'Investee General Meeting' (34 / 17)."},
    {"term": "Filing",
     "usages": [("35", "Fund Regulatory Filing (REGF-)", "Fund-level regulatory submission"),
                ("08", "FINRA Advertising Filing; Other Regulator Filing; Registration Filing", "Distribution and marketing filings"),
                ("16", "Government Filing (GFIL-)", "Plan filings (Form 5500)"),
                ("19", "Regulatory Financial Return", "Firm prudential and financial returns")],
     "recommendation": "As CD-233: 'Fund Regulatory Filing', 'Marketing Filing', 'Plan Government Filing', 'Firm Regulatory Return'."},
    {"term": "Agreement",
     "usages": [("35", "Fund Advisory Agreement (ADVA-)", "Advisory, sub-advisory and delegation agreement of a fund"),
                ("05", "Agreement (AGR-)", "Distribution agreements with intermediaries"),
                ("10", "Revenue Contract (RVC-) / Intercompany Agreement", "Revenue recognition contract; intercompany service agreement"),
                ("26", "Trading Agreement (TAGR-)", "ISDA / GMRA and credit support terms")],
     "recommendation": "Qualify by kind; 39 (future) indexes all as contract types without re-mastering them."},
    {"term": "Resolution",
     "usages": [("35", "Board Resolution (RESO-)", "Action adopted by a fund governing body"),
                ("08 / 12 / 13", "Complaint or case resolution", "Closure of a complaint or service case")],
     "recommendation": "'Board Resolution' for 35; 'Case Resolution' elsewhere."},
    {"term": "Resolution Outcome (list name)",
     "usages": [("35", "Board Resolution Outcome", "Result of a board vote (renamed from 'Resolution Outcome' after review)"),
                ("14", "Resolution Outcome", "Outcome of a vendor data challenge")],
     "recommendation": "Keep the 35 list as 'Board Resolution Outcome'; record as NOT_MERGED."},
    {"term": "Disclosure",
     "usages": [("35", "Fund Public Disclosure", "Website disclosure required by rule (6c-11, 2a-7, 30e-1)"),
                ("05", "Disclosure terms in agreements", "Contractual disclosure obligations"),
                ("08", "Required Disclosures; Disclosure Event", "Disclosures in marketing materials; individual registration disclosure events")],
     "recommendation": "'Fund Website Disclosure' (35), 'Marketing Disclosure' (08), 'Registration Disclosure Event' (08)."},
    {"term": "Approval",
     "usages": [("35", "Board Resolution / Resolution Subject Link", "Approval by a fund governing body"),
                ("36", "Product Approval Decision (PAPR-)", "Approval by the product governance committee"),
                ("08", "Compliance Approval", "Approval of marketing material")],
     "recommendation": "Qualify by approving body; a product change approved by both 36 and the board has two approvals, each held once (CD-237)."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "CD-225 amendment (program lead ruling, Stage 3 review): for board approvals CD-237 prevails over CD-225. The approval link is held "
    "ONLY on 35 Resolution Subject Link. Consumers (31 Highly Liquid Investment Minimum and Risk Program Designation, 33 Guideline "
    "Waiver, 34 Voting Policy and Proxy Voting Report, 36 Product Proposal / Product Change Initiative / Product Review, 13 shareholder "
    "communications, 27 fund financial statements) hold no approval reference, only a derived status where they need one. Amend the "
    "CD-225 resolution sentence '35 and 36 hold board approvals referenced by 31 ...; the consumer holds the reference' to except board "
    "approvals. 35 records whose grain is an approval event (renewal, fidelity bond, officer appointment, exemptive relief reliance) "
    "carry their own resolution and get no subject link.",
    "Program lead decision 1: 36 Change Regulatory Requirement.Satisfying Filing holds the change-to-filing link; 35 holds none.",
    "Sibling names were checked against the 31-34 and 36 modules (all exist): 31 Highly Liquid Investment Minimum, Risk Program "
    "Designation, Risk Limit Exceedance (RLEX-), Fund Liquidity Profile, VaR Test Result; 32 Performance Return (RETURN-), Benchmark "
    "Return; 33 Investment Breach (BREACH-), Guideline Waiver, Compliance Rule Result; 34 Proxy Voting Report, Voting Policy (VPOL-); 36 "
    "PPSL-, LCHG-, PRVW-. Register RLEX-, RETURN-, BREACH-, VPOL-, PPSL-, LCHG-, PRVW- so examples resolve by prefix.",
    "Fund Regulatory Filing grain (program lead decision 4): filer x form type x reporting period end or event / as-of date x event "
    "reference x submission sequence. 485 / 497 / N-14 use Event or As-Of Date; event-driven forms carry an Event Reference so "
    "same-day filings do not collide. Periodic filings reference their Filing Obligation (Met Obligation); event-driven forms have no "
    "obligation row. Filing Frequency is a copy of the shared Frequency list, so 'On Event' stays in the list but is excluded by "
    "definition on obligations. Official Filing Date (CDE) is distinct from Submitted and Acceptance Timestamps.",
    "An action by written consent is a Board Meeting of type 'Written Consent in Lieu of Meeting' so that the adoption date is held "
    "once (the meeting date); Board Consent Record holds LPAC consent detail, and board written consent votes are on Resolution Vote Count.",
    "Agreement Fund Schedule (agreement x fund x approval cycle) holds the 01 fee schedule, the 13 proxy proposal and the per-fund 15(c) "
    "outcome (program lead decision 5); one renewal resolution may continue several agreements.",
    "Derived copies in 35: Governed Fund Coverage.Covered Business Line (18, CD-209); Agreement Fund Schedule.Shareholder Approval Date "
    "(13); Fund Public Disclosure.Publication Timestamp on shareholder report website availability rows (13, row rule).",
    "Counts after the review pass: 6 families, 29 objects (23 BO, 6 AG), 248 attributes, 76 CDEs (30.6%), 28 local lists plus 9 "
    "shared copies (Period Type dropped), 47 relationships, 21 sources.",
]
