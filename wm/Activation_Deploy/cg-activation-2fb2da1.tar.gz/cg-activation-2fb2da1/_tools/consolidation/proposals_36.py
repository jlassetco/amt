"""Consolidation proposals from Data Domain 36 - Product Development & Lifecycle (Stage 3 draft v0.1, 2026-10-06).

Proposal fragment only: the builder does not read it. The Stage 3 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Format follows CONTRACT.md in this folder. Decisions implemented: CD-236, CD-237,
CD-238, CD-239 (and the 36 side of CD-233) in proposals_stage3_b.py. Nothing here edits 01, 08, 13 or 35.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones. None needed.
#    36 uses only the reserved PPSL-, PAPR-, LCHG- and PRVW- (proposals_stage3_b.py, CD-240). Committees are keyed by a
#    short committee code written without a hyphenated stem (GPAC); meetings, memberships, stage history, business cases,
#    scope rows, term changes, specifications, impact assessments, requirements, readiness plans and checks, criterion
#    results and review actions are keyed by their grain.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# Key formats of the reserved prefixes, as 36 issues them (decisions.PREFIX_FORMATS tuple format).
KEY_FORMATS = [
    ("PPSL-", "36", "PPSL-<year>-<sequence, 4 digits>", "PPSL-2026-0031"),
    ("PAPR-", "36", "PAPR-<year>-<sequence, 5 digits>", "PAPR-2026-00412"),
    ("LCHG-", "36", "LCHG-<year>-<sequence, 5 digits>", "LCHG-2026-00118"),
    ("PRVW-", "36", "PRVW-<year of review period end>-<product or model number, 5 digits>-<review type code, 3 letters>-<sequence, "
     "2 digits>", "PRVW-2026-00981-AOV-01"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local 36 lists that are verbatim copies (labels) of enterprise shared lists.
#    (shared list name, local list name in 36, where 36 uses it)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    ("Business Line", "Business Line", "Product Proposal, Product Governance Committee, Product Change Initiative"),
    ("Distribution Market", "Distribution Market", "Product Proposal target markets, Product Governance Committee markets"),
    ("Record Status", "Record Status", "Product Business Case status, Product Governance Committee status"),
    ("RAG Status", "RAG Status", "Readiness Plan overall status, Readiness Check status, Value Assessment Criterion rating"),
    ("Frequency", "Frequency", "Committee meeting frequency, Product Review frequency"),
    ("Severity", "Severity", "Change Impact Assessment severity"),
    ("Regulator", "Regulator", "Change Regulatory Requirement regulator"),
    ("Data Basis", "Data Basis", "Product Business Case projection basis"),
]
# Value maps: every local value is the shared label one to one (e.g. 'Mutual Fund' -> MUTUAL_FUND, 'EU / EEA' -> EU,
# 'Reported / Actual' -> REPORTED). Approval Status, Period Type and Case Status are not used: approvals are Product Approval
# Decisions with the 24 Committee Decision Outcome list, review periods are dates, and review actions use the local Review Status.
# Copies of lists owned by other domains (same name and values, to be replaced by references to the owner's list at
# consolidation): 01 Vehicle Type, Asset Class, Regulatory Regime, Share Class Type, Hedging Type, Distribution Policy,
# Investor Type; 13 COLL Change Classification; 24 Committee Decision Outcome.

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: local 36 lists that look like enterprise lists.
#    (list name in 36, proposed shared list name, likely other users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Product Change Type", "Product Lifecycle Event Type", ["01", "13", "16"],
     "CD-236. 36 Product Change Type is a superset of 01 Lifecycle Event Type: all ten 01 values are kept with the same labels "
     "(Launch, Soft Close, Hard Close, Reopen, Merger, Liquidation, Conversion, Rename, Change of Objective / Policy, Change of "
     "Service Provider) and 36 adds Share Class Launch, ETF Conversion, Share Class Conversion, Share Class Closure, Fee Change, "
     "Expense Cap Change, Benchmark Change, Dealing Terms Change, Redomiciliation, Fund Substitution and SFDR Reclassification, "
     "with a precedence rule. Steward 36; 01 Lifecycle Event Type becomes a member; 13 Shareholder Notice Type values such as "
     "'Fund Merger' map to it. 36 Review Action Type reuses six of its labels."),
    ("COLL Change Classification", "COLL Change Classification", ["13", "36"],
     "Verbatim copy of the 13 list. The classification is determined per product on the 36 Changed Product Scope; steward 36 "
     "and make 13's Shareholder Notice Change Classification a Derived copy (36)."),
    ("Product Review Outcome", "Value Assessment Outcome", ["01", "36"],
     "The 36 list holds the three 01 Value Assessment Outcome values verbatim for value reviews plus three appropriateness "
     "outcomes for other review types. Steward 36 (CD-236, CD-238); 01 Value Assessment Outcome becomes a Derived copy that "
     "uses the three value outcomes only."),
    ("Product Committee Member Role", "Committee Member Role", ["21", "22", "24", "35", "39"],
     "Renamed locally (review finding) because 24's 'Committee Member Role' has different values (Vice Chair, Voting Member, "
     "Non-Voting Member, Standing Attendee). Recommend one enterprise list without voting status mixed in (voting as an "
     "indicator, as 36 does) and map 36 Deputy Chair -> Vice Chair, Member -> Member, Observer / Adviser -> Standing Attendee."),
    ("Committee Decision Outcome", "Committee Decision Outcome", ["22", "24", "35"],
     "36 now uses 24's list by name with identical values (was 'Product Decision Outcome'), so the merge is a rename-free join."),
    ("Cost Bearer", None, ["10", "19", "35"],
     "Reorganization and liquidation cost bearers; 10 and 19 record the cost itself (SME question 8)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS noticed (decisions.py format). Review / Assessment, Change and Board / Committee are already in
#    proposals_stage3_b.py; the entries below add 36 usages or new terms.
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Launch",
     "usages": [("36", "Product Change Initiative (type Launch / Share Class Launch)", "Decision and change that creates a product or class"),
                ("01", "Product Inception Date / Share Class Launch Date", "Date the product or class was first priced"),
                ("04", "Campaign (launch campaigns)", "Marketing launch of a product")],
     "recommendation": "'Product Launch' is the 36 change initiative; 01 dates keep 'Inception' and 'Launch Date' as the effected "
                       "fact; marketing uses 'Launch Campaign'."},
    {"term": "Decision",
     "usages": [("36", "Product Approval Decision (PAPR-)", "Decision of the product governance committee"),
                ("24", "Investment Committee Decision / Investment Decision (IDEC-)", "Investment decisions"),
                ("35", "Board Resolution (RESO-)", "Fund board decision"),
                ("21", "Governance Decision (CD-)", "Data governance decision")],
     "recommendation": "Never 'Decision' bare: 'Product Approval Decision' (36), 'Investment Committee Decision' (24), 'Board "
                       "Resolution' (35), 'Governance Decision' (21)."},
    {"term": "Reorganization",
     "usages": [("36", "Fund Reorganization Detail", "Merger or conversion of funds (Rule 17a-8, IRC 368)"),
                ("09", "Reorganization Event (REORG-)", "Internal organization change"),
                ("17", "Corporate Action Event (MRGR)", "Merger of an issuer of a held security")],
     "recommendation": "'Fund Reorganization' (36), 'Organization Change' (09), 'Issuer Merger' corporate action (17)."},
    {"term": "Readiness / Set-up",
     "usages": [("36", "Product Readiness Plan / Readiness Check", "Evidence that operating domains are ready for a launch"),
                ("05", "Partner Dealer Setup / Trading Setup", "Operational set-up of a distribution partner"),
                ("12", "Custody Account", "Custody set-up workflow")],
     "recommendation": "Set-up records stay with their owners; 36 'Readiness Check' only points to them (CD-239)."},
    {"term": "Review",
     "usages": [("36", "Product Review (PRVW-)", "Manufacturer periodic review, assessment of value, fair value assessment"),
                ("33", "Periodic Rule Review", "Rule 38a-1 review of compliance rules"),
                ("25", "Best execution review", "Execution quality review")],
     "recommendation": "Adds 33 and 25 usages to the CD-240 'Review / Assessment' entry; always qualify."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    # CD-236: proposed changes to 01 (not applied)
    "CD-236 re-notes to 01 (proposed, not applied): Product Governance 'Product Approval Date' -> Derived copy (36), the meeting "
    "date of the first Approved / Approved with Conditions Product Approval Decision of type Launch Approval on the product's "
    "launch; 'Last Product Review Date' -> Derived copy (36), Review Period End of the latest completed Product Review; 'Next "
    "Product Review Date' -> Derived copy (36), Next Review Due Date; 'Value Assessment Outcome' -> Derived copy (36), Review "
    "Outcome of the latest completed review of type Assessment of Value or Fair Value Assessment (value outcomes only); 'Product "
    "Owner' re-types Reference (Party) -> Reference (Employee) with an EMP- example.",
    "CD-236 re-notes to 01 Lifecycle Event (proposed, not applied): add 'Originating Change Initiative' Reference (Product Change "
    "Initiative, 36), example LCHG-2026-00118; 'Event Effective Date' becomes a Derived copy (36) of Actual Effective Date; "
    "'Event Reason' becomes a Derived copy (36) of Change Rationale; 'Investor Notice Date' becomes a Derived copy (13) of the "
    "Mail Date of the notice the 36 requirement references; 'Lifecycle Event Type' joins the shared Product Lifecycle Event Type list.",
    "CD-236 row rule: 36 Proposed Term Change 'Current Term Rate' and 'Current Term Text' are Derived copies (01) as at Term "
    "Proposed Date and are never refreshed; the current benchmark is not copied (01 Product Benchmark Assignment). 36 holds no "
    "current fee, status, name, listing or target market. Liquidation dates are planned dates; 01 Lifecycle Event holds the "
    "effected closes. New share classes are created in 01 with Lifecycle Status 'In Development' and referenced from Share Class "
    "Specification 'Created Share Class'.",
    # CD-237
    "CD-237: 36 holds no reference to a 35 Board Resolution. Requirement rows of types 'Fund Board Approval' and 'CIT Trustee "
    "Approval' (the trustee fiduciary committee is a 35 Fund Governing Body under CD-231) and Product Review 'AFM Board Approval "
    "Date' are Derived copies (35) read through 35 Resolution Subject Link. 35 should add 'Trustee Fiduciary Committee' approvals "
    "of CIT plan amendments to its Resolution Type list if absent. The 35 example 'PRVW-2026-00981-AOV' should follow the revised "
    "36 key format 'PRVW-2026-00981-AOV-01'.",
    # CD-233
    "CD-233 (program lead decision on review finding A-High-1): the filing-to-change link is held once, on the 36 side, because "
    "the requirement is the thing that needs satisfying: Change Regulatory Requirement 'Satisfying Filing' Reference (Fund "
    "Regulatory Filing, 35). Proposed for 35 (not applied): drop Fund Regulatory Filing 'Originating Change Initiative' "
    "(content_35, Reference (Product Change Initiative, 36)) and the relationship 'Fund Regulatory Filing is required by Product "
    "Change Initiative [36]'. The CD-233 resolution wording '36 holds the change and its filing requirement and reads REGF- status' "
    "should read '36 holds the change, its filing requirement and the link to the satisfying REGF-, and derives the requirement "
    "status from the filing'.",
    "Row Ownership Rule for Change Regulatory Requirement 'Requirement Status' and 'Requirement Satisfied Date' (review High 3; "
    "plan §4 item 9): every Regulatory Requirement Type belongs to one evidence group with one source. (1) Board or Trustee "
    "Approval -> 35 Resolution Subject Link / Board Resolution (Resolution Outcome mapped; Resolution Effective Date). (2) Fund "
    "Filing -> 35 Fund Regulatory Filing in Satisfying Filing (Effectiveness Date for 485APOS / 485BPOS / N-14, otherwise Filing "
    "Status Accepted and Submitted Timestamp). (3) Exemptive Relief -> 35 Exemptive Relief Reliance in Satisfying Exemptive "
    "Relief (Order Date). (4) Shareholder Notice or Vote -> 13 Communication Distribution Mail Date of the communication in "
    "Satisfying Shareholder Communication, or 13 Proxy Proposal Outcome and Proxy Campaign Meeting Date of Satisfying Proxy "
    "Proposal. (5) Regulator Prior Approval (Competent Authority Prior Approval, UCITS Merger Authorization) -> mastered here. "
    "Declared with the primary derived owner 35 in enrich_36; the 13 rows are the documented exception. Requirement Status values "
    "are a mapping (Open, Evidence Pending, Satisfied, Not Obtained), stated per group in the attribute notes. Proposed "
    "convention: show this as the object's Row Ownership Rule note in the catalog.",
    # 13
    "13 hand-offs (proposed, not applied): the links from a requirement to the notice (Shareholder Communication COMM-) and the "
    "vote (Proxy Proposal PRP-) are held once, on the 36 requirement, so 13 does not need to re-type 'Triggering Lifecycle Event' "
    "to LCHG- (it may keep its 01 Lifecycle Event reference; CD-025's planned 01 -> COMM- link should not be duplicated by 36). "
    "Shareholder Notice 'Change Classification' becomes a Derived copy (36) of Changed Product Scope 'COLL Change Classification' "
    "for the notified product; 'Shareholder Approval Required Indicator' becomes derived from the existence of a 36 Shareholder "
    "Vote requirement row for the product.",
    # 08
    "08 hand-off (proposed, not applied): Distribution Review Finding 'Product Review Cycle' (Text, defined as 'owned by 01 "
    "Product governance') re-types to Reference (Product Review, 36) with a PRVW- example. 08 Distributor Feedback Report, Sales "
    "Against Target Market and Outcome Metric stay 08 (CD-238); 36 references FBK- and Outcome Metric and copies only the 'sales "
    "outside target market' indicator.",
    # Siblings
    "Sibling names used (checked against content_31 to content_35 on 2026-10-06): 35 Fund Regulatory Filing (REGF-), Exemptive "
    "Relief Reliance, Resolution Subject Link; 32 Performance Return (RETURN-) and Benchmark Return; 31 Fund Liquidity Profile; 33 "
    "Rule Coding Request. 32's 'fund merger or conversion event' and 33's 'product change event' should reference LCHG-. 34 SFDR "
    "reclassifications are LCHG- of type 'SFDR Reclassification'; 34 Product Sustainability Outcome is not referenced.",
    # 30 / 41 / 43
    "Private fund launches: 36 holds the proposal, approval and launch change initiative; the 'New' scope row's PRD- is the key "
    "30 Private Fund Profile is held against, so no separate reference is added. Formation, closes and investor terms are 30. "
    "Launch Project Code is text until 41 exists; seed capital commitments are future 43.",
    # Prefix check
    "Examples use the published formats of other owners: REGF-N14-2026-000118 (35), RETURN-2026-0004518832 (32), "
    "TACK-2026-1005-004512 (29), SKA-000231 (28), PORT-000877 (18), KPI-0311 (21), FBS-, CEV-, MSZ-, PEER- (11), PNL- (10), "
    "FBK- (08), COMM-, PRP- (13). Grain-keyed references (Benchmark Return, Model Program Placement) whose examples start with "
    "another domain's prefix are forced by OWNERSHIP_OVERRIDES. The committee code 'GPAC' has no hyphenated stem.",
]
