"""Consolidation proposals from Data Domain 37 - Enterprise & Operational Risk (Stage 4 draft v0.1, 2026-10-06).

Proposal fragment only: the builder does not read it. The Stage 4 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Format follows CONTRACT.md in this folder. Decisions implemented: CD-243 to CD-249
and the 37 part of CD-262 (proposals_stage4_a.py). Nothing here edits 01-36 or a sibling module.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones. None needed: 37 uses only RISK-, CNTRL-, OPINC-, LOSS-, ISSUE-, MODEL-, AUDIT-,
#    AUDF- (CD-262). Other objects are keyed by grain or by firm codes without a hyphenated stem.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

KEY_FORMATS = [
    ("RISK-", "37", "RISK-<sequence, 5 digits>", "RISK-00412"),
    ("CNTRL-", "37", "CNTRL-<sequence, 6 digits>; the version is the separate attribute Control Version", "CNTRL-004120"),
    ("OPINC-", "37", "OPINC-<year>-<sequence, 5 digits>", "OPINC-2026-01187"),
    ("LOSS-", "37", "LOSS-<year>-<sequence, 5 digits>", "LOSS-2026-00213"),
    ("ISSUE-", "37", "ISSUE-<year>-<sequence, 5 digits>", "ISSUE-2026-00877"),
    ("MODEL-", "37", "MODEL-<sequence, 4 digits>; the version is the separate attribute Model Version", "MODEL-0412"),
    ("AUDIT-", "37", "AUDIT-<plan year>-<sequence, 3 digits>", "AUDIT-2026-014"),
    ("AUDF-", "37", "AUDF-<plan year>-<engagement sequence, 3 digits>-<finding, 2 digits>", "AUDF-2026-014-03"),
]

# One entry per grain-keyed object (stage3_consolidation_notes §4): (object, grain key as written in references, example)
GRAIN_KEY_FORMATS = [
    ("Risk Taxonomy Category", "NFR <level>.<sequence> / <taxonomy version>", "NFR 3.07 / 4"),
    ("Risk Assessment", "<RISK- id> / <assessment date>", "RISK-00412 / 2026-09-30"),
    ("Risk Appetite Statement", "RAS <year> <Appetite Category code from the list description, e.g. OPS, CAP> <sequence, 2 digits>", "RAS 2026 OPS 04"),
    ("RCSA Campaign", "RCSA <year><half or quarter> / <OU- id>", "RCSA 2026H2 / OU-0217"),
    ("Risk Control Link", "<RISK- id> / <CNTRL- id> / <effective from>", "RISK-00412 / CNTRL-004120 / 2025-07-01"),
    ("Control Test", "<CNTRL- id> / <version> / <test date> / <sequence>", "CNTRL-004120 / 3 / 2026-09-30 / 1"),
    ("Incident Source Record", "<OPINC- id> / <source record key>", "OPINC-2026-01187 / NEC-2026-0031"),
    ("Incident Regulatory Notification", "<OPINC- id> / <authority> / <stage>", "OPINC-2026-01187 / CSSF / DORA Initial Notification"),
    ("Loss Event Amount", "<LOSS- id> / <sequence>", "LOSS-2026-00213 / 1"),
    ("Key Risk Indicator", "KRI <sequence, 4 digits> / <version>", "KRI 0412 / 2"),
    ("KRI Observation", "KRI <sequence> / <version> / <observation date>", "KRI 0412 / 2 / 2026-09-30"),
    ("Issue Action", "<ISSUE- id> / <sequence>", "ISSUE-2026-00877 / 1"),
    ("Important Business Service", "IBS <sequence, 2 digits>", "IBS 07"),
    ("Critical or Important Function", "CIF <sequence, 2 digits> (unique across entities)", "CIF 03"),
    ("Resilience Resource Mapping", "<IBS or CIF code> / <resource key> / <effective from>", "IBS 07 / APPL-00412 / 2026-06-30"),
    ("Business Impact Analysis", "<business process code> / <BIA date>", "FP 07.03 / 2026-05-31"),
    ("Business Continuity Plan", "BCP <sequence, 3 digits> / <version>", "BCP 014 / 6"),
    ("Resilience Test", "RTEST <year>/<sequence, 3 digits>", "RTEST 2026/011"),
    ("Impact Tolerance", "<IBS code> / <impact tolerance metric> / <effective from>", "IBS 07 / Maximum Duration of Disruption / 2022-03-31"),
    ("Third-Party Risk Assessment", "TPRA <year>/<sequence, 5 digits>", "TPRA 2026/00412"),
    ("Third-Party Risk Domain Result", "<TPRA reference> / <risk domain>", "TPRA 2026/00412 / Information Security"),
    ("Model Tier Assignment", "<MODEL- id> / <effective from>", "MODEL-0412 / 2025-01-01"),
    ("Model Validation", "<MODEL- id> / <version> / <sequence>", "MODEL-0412 / 3 / 2"),
    ("Model Performance Monitoring", "<MODEL- id> / <version> / <test> / <period end>", "MODEL-0412 / 3 / VaR exceptions count / 2026-09-30"),
    ("Auditable Entity", "AUE <sequence, 4 digits>", "AUE 0118"),
    ("Audit Plan", "<plan year> / <version>", "2026 / 2"),
    ("Finding Closure Validation", "<AUDF- id> / <attempt sequence>", "AUDF-2026-014-03 / 1"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local 37 lists that are verbatim copies of enterprise shared lists (CD-241 pattern: register 37 as
#    a direct user and drop the local copy). (shared list name, local list name in 37, where 37 uses it)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    ("Risk Rating", "Risk Rating", "Risk Assessment inherent and residual, Third-Party Risk Assessment and Domain Result, Auditable Entity inherent audit risk"),
    ("Severity", "Severity", "Operational Incident, Risk Issue, Audit Finding"),
    ("RAG Status", "RAG Status", "KRI Observation"),
    ("Case Status", "Case Status", "RCSA Campaign, Operational Incident, Risk Issue"),
    ("Approval Status", "Approval Status", "Control version, Business Continuity Plan"),
    ("Record Status", "Record Status", "Enterprise Risk, Model Use Status"),
    ("Frequency", "Frequency", "Control, Key Risk Indicator"),
    ("Regulator", "Regulator", "Incident Regulatory Notification"),
    ("Business Line", "Business Line", "Enterprise Risk, Operational Loss Event"),
    ("Information Classification", "Information Classification", "Operational Incident"),
]
# Value maps: every local value is the shared label one to one. Period Type is not used.

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: (list name in 37, proposed shared list name, likely other users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Third-Party Risk Domain", "Third-Party Risk Domain", ["14", "40"],
     "Built from the 14 Vendor Risk Domain values verbatim plus 'Conduct and MNPI' (expert networks). Steward 37 (CD-248). "
     "Value map: every 14 value maps one to one to the same label; 37 'Conduct and MNPI' is new."),
    ("Audit Rating", None, ["38", "16"],
     "NOT_MERGED recommended: 38 Examination Finding uses Shared: Severity, and audit opinions (Satisfactory / Needs "
     "Improvement / Unsatisfactory) are a different dimension from finding severity."),
    ("Basel Event Type Level 1", "Basel Event Type Level 1", ["38", "41", "44"],
     "Regulatory reference list (BCBS); steward 37, with Level 2 as its child list."),
    ("Basel Event Type Level 2", "Basel Event Type Level 2", ["38", "41", "44"], "As Level 1."),
    ("Model Type", "Model Type", ["21", "31", "41"],
     "Used by 41 AI System Profile and any consumer that classifies models; steward 37."),
    ("Control Type", "Control Type", ["07", "10", "38"], "COSO preventive / detective / corrective; steward 37."),
    ("Assessment Level", None, [], "Generic Low / Medium / High scale; candidate to merge into a 09 shared 'Level' list if others exist."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (decisions.py format)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Incident",
     "usages": [("37", "Operational Incident (OPINC-)", "Business-impact record of an operational failure, with regulatory notifications"),
                ("41", "IT Incident (ITINC-)", "Technical ITIL incident record, including security incidents"),
                ("44", "Physical Security Incident / Health & Safety Incident", "Workplace technical records"),
                ("25", "Trade Error 'Related Incident Reference'", "Text placeholder, to re-type to OPINC-")],
     "recommendation": "Never 'Incident' bare: 'Operational Incident' (37), 'IT Incident' (41), 'Physical Security Incident' and "
                       "'Health & Safety Incident' (44). The link is held once, on the 37 Incident Source Record."},
    {"term": "Risk",
     "usages": [("37", "Enterprise Risk (RISK-)", "Non-financial risk register entry"),
                ("31", "Risk Model / Risk Limit / Risk Measure", "Investment risk measurement"),
                ("14", "Vendor Risk Assessment", "Data-vendor third-party risk")],
     "recommendation": "Extends the existing entry: 'Enterprise Risk' for the register; investment risk terms stay qualified."},
    {"term": "Control",
     "usages": [("37", "Control (CNTRL-)", "Control library entry"),
                ("07", "Compensation Control (CTL-)", "Comp control with last test result"),
                ("10", "Control", "Reconciliation evidencing a key control"),
                ("19", "Close Task 'Key Control Reference'", "Text"),
                ("29", "TA Control Check", "Execution record")],
     "recommendation": "Write 'Control Library Entry' in definitions where confusion is possible; 07, 10, 19, 27 and 29 records "
                       "are executions of a 37 Control (CD-243). 07 'Last Test Result' should become a Derived copy (37) of the "
                       "latest Control Test where a library control is linked."},
    {"term": "Issue",
     "usages": [("37", "Risk Issue (ISSUE-)", "Remediation register"),
                ("21", "Data Quality Issue (DQI-)", "Data defect"),
                ("14", "Vendor Data Issue (VDI-)", "Vendor data defect"),
                ("42", "Communications Issue (CRIS-)", "Communications issue or crisis")],
     "recommendation": "Never 'Issue' bare. 21 data quality issues do not raise Risk Issues directly; a DQ defect with control impact is raised through a control test or incident."},
    {"term": "Model",
     "usages": [("37", "Model Inventory Entry (MODEL-)", "Governed inventory entry"),
                ("01", "Model Portfolio (MDL-)", "Model portfolio delivered to platforms"),
                ("31 / 32 / 23", "Risk Model / Attribution Model / Research Model", "Models as used")],
     "recommendation": "Never 'Model' bare; consumers reference the Model Inventory Entry (CD-246)."},
    {"term": "Audit",
     "usages": [("37", "Audit Engagement (AUDIT-) / Audit Finding (AUDF-)", "Internal audit"),
                ("14", "License Audit", "Vendor audit of license use"),
                ("16", "Plan Audit (PAUD-)", "Independent audit of a recordkept plan"),
                ("38", "Regulatory Examination (EXAM-)", "Supervisory examination")],
     "recommendation": "'Audit Engagement' (37, the internal audit engagement); 'Examination' never 'Audit' for regulators."},
    {"term": "Exception",
     "usages": [("37", "Control Test 'Exceptions Found Count'", "Sampled executions where the control failed"),
                ("22", "Price Validation Exception", "Pricing tolerance exception")],
     "recommendation": "Extend the existing entry; 37 uses 'control test exception'."},
    {"term": "Appetite / Limit",
     "usages": [("37", "Risk Appetite Statement", "Board-approved tolerance for non-financial risk"),
                ("31", "Risk Limit (RLMT-)", "Investment risk program limit")],
     "recommendation": "Appetite is 37; numeric investment limits are 31 or 33 (CD-223)."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. PROPOSED_CHANGES to 01-36 (not applied; the program lead decides at consolidation)
# ---------------------------------------------------------------------------------------------------------------------
PROPOSED_CHANGES = [
    ("25", "Trade Error", "Related Incident Reference", "Re-type Text -> Reference (Operational Incident, 37), example OPINC-2026-01187; drop the 'until 37' note.", "CD-244"),
    ("10", "Control", "Control Reference", "Re-type Text -> Reference (Control, 37), example CNTRL-004120.", "CD-243"),
    ("19", "Close Task", "Key Control Reference", "Re-type Text -> Reference (Control, 37), example CNTRL-004120.", "CD-243"),
    ("07", "Compensation Control", "(new) Library Control", "Add optional Reference (Control, 37); 'Last Test Result' becomes Derived copy (37) where linked.", "CD-243"),
    ("31", "Risk Model", "Model Inventory Reference", "Re-type Text -> Reference (Model Inventory Entry, 37) with the version in the key, example 'MODEL-0412 / 3'; Risk Model Version equals Model Inventory Entry.Model Version. Model Vendor, Risk Model Owner and Risk Model Status become Derived copies (37) of Model Vendor, Model Owner and Model Use Status (status mapped). Update the relationship and the SR 11-7 note to SR 26-2.", "CD-246"),
    ("32", "Attribution Model", "Model Inventory Reference", "Re-type Text -> Reference (Model Inventory Entry, 37), example 'MODEL-0418 / 2'; Attribution Model Version equals Model Inventory Entry.Model Version.", "CD-246"),
    ("21", "AI Use Case", "Model Name", "Re-type Text -> Reference (Model Inventory Entry, 37), example MODEL-0451; relationship 'runs on Model [37]' becomes Model Inventory Entry.", "CD-246 / CD-159"),
    ("22", "Fair Value Determination", "Valuation Model Name", "Re-type Text -> Reference (Model Inventory Entry, 37), example MODEL-0233.", "CD-246"),
    ("34", "Firm ESG Assessment", "Assessment Methodology Name", "Re-type Text -> Reference (Model Inventory Entry, 37), example MODEL-0302.", "CD-246"),
    ("34", "Portfolio Sustainability Metric", "Metric Model Name", "Re-type Text -> Reference (Model Inventory Entry, 37).", "CD-246"),
    ("24", "Investment Decision", "Decision Algorithm Code", "Flag Derived copy (37) of Model Inventory Entry.Trading Algorithm Code; replace the 'later domain (37)' note.", "CD-246"),
    ("23", "Research Model", "Model Inventory Candidate Indicator", "Keep; note that a Y value requires a 37 Model Inventory Entry.", "CD-246"),
    ("14", "Vendor Risk Assessment", "Residual Risk Rating", "Derived copy (37) of Third-Party Risk Assessment.Third-Party Residual Risk Rating on rows linked to an enterprise assessment.", "CD-248"),
    ("14", "Vendor Risk Assessment", "Inherent Risk Rating", "No change: stays mastered in 14 as the data-vendor specialization (CD-248 amendment, program lead ruling 5). The earlier 'Derived copy (40)' proposal is withdrawn.", "CD-248 (amended)"),
    ("14", "Vendor Risk Assessment", "(new) Enterprise Third-Party Risk Assessment", "Add Reference (Third-Party Risk Assessment, 37), example 'TPRA 2026/00412'; 37 no longer holds the link to VRA- (consumer holds the reference).", "CD-248"),
    ("23", "Research Provider Profile", "Expert Network Due Diligence Date", "Derived copy (37) of Third-Party Risk Assessment.Third-Party Assessment Completed Date for type 'Expert Network MNPI Controls'.", "CD-248"),
    ("20", "Workforce Position", "Key-Person Risk Indicator", "Keep in 20; replace 'input to 37' with 'read by 37 Resilience Resource Mapping (Mapped Workforce Position)'.", "CD-249"),
    ("14", "ICT Third-Party Register Entry", "UK Important Business Service Mapping / Supports Critical or Important Function", "Become Derived copies (40) per CD-261; the services and functions themselves are 37 Important Business Service and Critical or Important Function.", "CD-249 / CD-261"),
    ("33", "(overview)", "'referenced ... in Stage 4, 37'", "Resolves to 37 Incident Source Record (Source Investment Breach).", "CD-244"),
    ("38", "Examination Finding", "Remediating Risk Issue", "Drop: the link is held once, on 37 Risk Issue.Source Examination Finding (program lead ruling 4).", "CD-253"),
    ("38", "Compliance Program Review", "Review Findings Raised", "Drop: held once, on 37 Risk Issue.Source Compliance Program Review (program lead ruling 4).", "CD-253"),
    ("41", "Vulnerability Finding", "Risk Acceptance Issue", "Drop: held once, on 37 Risk Issue.Source Vulnerability Finding (program lead ruling 4).", "CD-245"),
    ("39", "Corporate Resolution Subject Link", "Subject Risk Appetite Statement / Subject Audit Plan", "Use 37 keys in examples ('RAS 2026 OPS 04', '2026 / 2') instead of prose.", "CD-259"),
    ("02", "Party Role Type", "(values)", "Add 'Insurer', 'External Model Validator', 'Co-Sourced Internal Audit Provider'.", "CD-143"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Sibling names checked against the 38-44 modules (2026-10-06): 38 Examination Finding, Compliance Program Review; 39 "
    "Legal Matter (LMAT-), Corporate Resolution Subject Link; 40 Supplier Engagement (VENG-), Supplier Risk Tiering, Exit Plan; "
    "41 Application (APPL-), IT Service ('SVC 0118'), IT Incident (ITINC-), Security & Resilience Test, Vulnerability Finding "
    "(VULN-); 43 Insurance Claim, Capital Profile; 44 Physical Security Incident ('PSI 2026-0007', the format 44 agreed with 37), "
    "Health & Safety Incident (HSEI-). 41 AI System Profile already references Model Inventory Entry by name.",
    "Program lead rulings applied: (1) Risk Appetite Statement and Audit Plan hold no approval reference; 39 Subject Link holds "
    "both, and 37 keeps Derived copies (39) Appetite Approval Date and Audit Plan Approval Status. (2) No insurance claim "
    "reference on Loss Event Amount; 43 Insurance Claim.Related Operational Loss Event is the only link and recoveries are read "
    "at claim level (cumulative Amount Recovered), not copied per booking. (3) Loss Amount = gross loss borne by the firm "
    "(25 Reimbursement Amount, 27 Fund Loss Amount where reimbursed by an internal entity, 33 Compensation Amount, 26 Penalty "
    "Amount where absorbed); Operational Loss Event.Impact Amount = client or portfolio harm (25 Error Gain or Loss Amount, 27 "
    "Fund Loss Amount, 33 Breach Loss Amount, sum of 13 Shareholder Remediation by servicing error). (4) Issue-source links held "
    "once, on Risk Issue (typed sources; no free-text source). (5) CD-248 amended: 14 Inherent Risk Rating stays mastered in 14.",
    "Row rules: DERIVED names a primary owner (Loss Amount 25, Impact Amount 27, KRI Definition and Direction 21) because the "
    "contract takes one domain; the attribute notes state every source and the rows mastered in 37. Proposed convention: show "
    "these as the object's Row Ownership Rule in the catalog.",
    "43 Capital Profile 'Capital Appetite Statement' (RAS 2026 CAP 01) resolves: Appetite Category gains 'Capital and Liquidity' "
    "(code CAP); capital and liquidity appetite is held in 37 although the rest of the domain is non-financial risk.",
    "Assessed Third Party is a Reference, so it cannot carry the Derived copy flag; its note states the row rule (copy of the 40 "
    "engagement's supplier; mastered only for prospective suppliers).",
    "Key-format mismatches for consolidation: 40 cites critical functions as 'Fund administration and NAV calculation (F03)' "
    "while 37 publishes 'CIF 03'; 39 Subject Link examples cite the appetite statement and audit plan in prose.",
    "Business process codes (Incident Business Process, Analyzed Business Process, Mapped Business Process) use the business "
    "capability map code as 21 and 41 hold it ('C-08.03 ...'); no domain masters the capability map yet (open item).",
    "Control execution records (27 NAV Control Check, 29 TA Control Check, 06 Reconciliation) carry no CNTRL- link; the 37 "
    "relationship is by record type only. Optional Reference (Control, 37) columns on them are a later option, not proposed now.",
    "09 keeps SITE- and 44 Site Profile profiles it (CD-279); Mapped Site stays a 09 reference.",
    "Shared lists are local copies (SHARED_MEMBERSHIPS); register 37 as a direct user and remove the copies, as CD-241 did for 31-36.",
    "No 'future owner 37' note in 01-36 is left unresolved: 21, 22, 23, 24, 31, 32, 34 -> Model Inventory Entry; 25 and 33 -> "
    "Operational Incident; 20 -> Resilience Resource Mapping; 23 Expert Network -> Third-Party Risk Assessment.",
]
