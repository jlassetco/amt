"""Consolidation proposals from Data Domain 38 - Corporate Compliance & Regulatory Affairs (Stage 4 draft v0.1, 2026-10-06).

Proposal fragment only: the builder does not read it. The Stage 4 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Format follows CONTRACT.md in this folder. Decisions implemented: CD-250 and CD-252
under option A (MOVE, program lead ruling), CD-251, CD-253 to CD-256 and the 38 rows of CD-262
(proposals_stage4_a.py); CD-267 and CD-273 (proposals_stage4_b.py) for the 41 and 42 links; working assumptions CD-143
and CD-209. Revised after the independent review 38_review.md and the program lead rulings of 2026-10-06 (links held
once; Restricted and PII flags; Political Contribution identifier; insider list parent).
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones. None needed: 38 uses the reserved FILNG-, EXAM-, POLCY-, REGCH-, RLIST-, TRSV-,
#    CONFL- and MNPI-, plus the transferred AUTH- (09) and OBL- (08). AML cases keep the restricted firm case number
#    without a prefix ("AML case 2026-0441"); firm restricted lists are keyed by a short list code ("GRL"); political
#    contributions by a firm number without a hyphenated stem ("PCON 2026-00007"); STOR references are authority text.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

PREFIXES_TO_REGISTER = [
    ("FILNG-", "Firm regulatory filing", "38", "Registered", "Stage 4 (CD-251)."),
    ("EXAM-", "Regulatory examination, sweep or inquiry", "38", "Registered", "Stage 4 (CD-253)."),
    ("POLCY-", "Firm policy (version separate)", "38", "Registered", "Stage 4 (CD-252)."),
    ("REGCH-", "Regulatory change item", "38", "Registered", "Stage 4 (CD-252)."),
    ("RLIST-", "Restricted list entry", "38", "Registered", "Stage 4 (CD-256)."),
    ("TRSV-", "Trade surveillance alert", "38", "Registered", "Stage 4 (CD-256)."),
    ("CONFL-", "Conflict of interest (firm register)", "38", "Registered", "Stage 4 (CD-254)."),
    ("MNPI-", "MNPI escalation", "38", "Registered", "Stage 4 (CD-256)."),
]

PREFIX_TRANSFERS = [
    ("AUTH-", "09", "38", "Entity Authorization moves with names unchanged (CD-250); format AUTH-<sequence, 4 digits>, e.g. AUTH-0012."),
    ("OBL-", "08", "38", "Regulatory Obligation moves with names unchanged (CD-252); existing format OBL-<regime code>-<sequence, 4 digits>, e.g. OBL-DC-0142."),
]

KEY_FORMATS = [   # confirms proposals_stage4_a.PREFIX_FORMATS without change
    ("FILNG-", "38", "FILNG-<form code, letters and digits only>-<year>-<sequence, 5 digits>", "FILNG-13F-2026-00004"),
    ("EXAM-", "38", "EXAM-<year>-<sequence, 4 digits>", "EXAM-2026-0007"),
    ("POLCY-", "38", "POLCY-<sequence, 4 digits>; the version is the separate attribute Policy Version Number", "POLCY-0118"),
    ("REGCH-", "38", "REGCH-<year>-<sequence, 4 digits>", "REGCH-2026-0042"),
    ("RLIST-", "38", "RLIST-<year>-<sequence, 6 digits>", "RLIST-2026-000318"),
    ("TRSV-", "38", "TRSV-<year>-<sequence, 7 digits>", "TRSV-2026-0012281"),
    ("CONFL-", "38", "CONFL-<sequence, 5 digits>", "CONFL-00231"),
    ("MNPI-", "38", "MNPI-<year>-<sequence, 5 digits>", "MNPI-2026-00412"),
    ("AUTH-", "38", "AUTH-<sequence, 4 digits> (format kept from 09)", "AUTH-0012"),
    ("OBL-", "38", "OBL-<regime code>-<sequence, 4 digits> (format kept from 08)", "OBL-DC-0142"),
]

FIRM_KEY_FORMATS = [   # firm-defined keys without a hyphenated stem (no prefix registered); published so siblings align
    ("Political Contribution ID", "38", "PCON <year>-<sequence, 5 digits>", "PCON 2026-00007",
     "42 Lobbying Disclosure Report.Reported Political Contributions should use this example in place of '(38 key pending)'."),
    ("Restricted List Code", "38", "<2-6 capital letters>", "GRL", "33 Rule Instrument List.Restricted List Source reads it."),
    ("Personal Account Key", "38", "PTA <sequence, 7 digits>", "PTA 0041877", "Firm key of a reportable personal trading account."),
    ("AML Case Number", "38", "AML case <year>-<sequence, 4 digits>", "AML case 2026-0441", "Restricted; already used by 29."),
]

GRAIN_KEY_FORMATS = [   # objects keyed by their grain, not by a prefix (object, key format, example)
    ("Cross-Border Passport", "<LEN- of home entity>|<host country ISO 3166-1>|<passport type>", "LEN-0004|DE|UCITS ManCo - Freedom to Provide Services"),
    ("Ownership Disclosure Determination", "<security class INS- (or issuer PTY-)>|<disclosure regime>|<aggregation LEN->|<determination date>", "INS-00104477|US Section 13(d) / 13(g)|LEN-0001|2026-10-05"),
    ("Regulatory Change Impact", "<REGCH->|<LEN- or business line or Data Domain number> (exactly one scope reference filled)", "REGCH-2026-0042|LEN-0004"),
    ("Regulator Request Item", "<EXAM->|<request sequence>", "EXAM-2026-0007|14"),
    ("Examination Finding", "<EXAM->|<finding sequence>", "EXAM-2026-0007|3"),
    ("Policy Version", "<POLCY-> v<version number>", "POLCY-0118 v7.0"),
    ("Attestation", "<EMP->|<attestation type>|<period>", "EMP-20417|Code of Ethics Acknowledgment|2026"),
    ("Compliance Program Review", "<LEN->|<program review type>|<review period end>", "LEN-0004|Advisers Act Rule 206(4)-7 Annual Review|2026-06-30"),
    ("Conduct Population Designation", "<EMP->|<designation type>|<LEN->|<effective from>", "EMP-20417|Access Person|LEN-0004|2024-05-01"),
    ("Personal Trading Account", "Personal Account Key (firm key)", "PTA 0041877"),
    ("Personal Securities Report", "<EMP->|<personal report type>|<as-of date>", "EMP-20417|Quarterly Transaction Report|2026-09-30"),
    ("Personal Transaction", "<Personal Account Key>|<Broker Transaction Reference>", "PTA 0041877|TRD 88123401"),
    ("Pre-Clearance Request", "<EMP->|<request timestamp>", "EMP-20417|2026-09-14T09:12:00-04:00"),
    ("Code of Ethics Violation", "<EMP->|<Violation Detected Date>|<Violation Sequence>", "EMP-20417|2026-10-02|1"),
    ("Conflict Mitigation", "<CONFL->|<mitigation type>|<CNTRL- or POLCY- or sequence>", "CONFL-00231|Control|CNTRL-004120"),
    ("Outside Business Activity", "<EMP->|<organization PTY->|<effective from>", "EMP-20417|PTY-8812004|2025-01-15"),
    ("AML Program Assessment", "<LEN- or PRD- (exactly one)>|<assessment year>", "LEN-0003|2026"),
    ("AML and Sanctions Report", "<AML case number>|<report sequence> (Restricted)", "AML case 2026-0441|1"),
    ("Firm Restricted List", "Restricted List Code", "GRL"),
    ("Insider List Entry", "<insider list code>|<MNPI- or PERMANENT>|<EMP- or PTY->|<access obtained timestamp>", "INSL|MNPI-2026-00412|EMP-30412|2026-10-06T09:30:00-04:00"),
    ("Suspicious Transaction and Order Report", "<TRSV->|<submitted timestamp>", "TRSV-2026-0012281|2026-10-09T11:20:00+01:00"),
]

CONCEPT_OWNERSHIP = [
    ("Entity Authorization", "38", "AUTH-", ["09", "25", "26", "28", "35"], "Moved from 09 (CD-250); 25 Large Trader ID copies the SEC Large Trader row"),
    ("Cross-Border Passport", "38", "", ["01", "08"], "Moved from 09 (CD-250)"),
    ("Firm Regulatory Filing", "38", "FILNG-", ["34", "39"], "Firm-level filings; fund filings are 35 REGF- (CD-251)"),
    ("Ownership Disclosure Determination", "38", "", ["34"], "13D / 13G, major holdings and short position determinations (CD-251)"),
    ("Regulatory Obligation", "38", "OBL-", ["08", "37"], "Moved from 08, widened to all regimes (CD-252)"),
    ("Regulatory Change Item", "38", "REGCH-", ["11", "41"], "41 Project Scope Link targets it (CD-267)"),
    ("Regulatory Examination", "38", "EXAM-", ["37", "39"], "Exams, sweeps, inquiries; enforcement is 39 (CD-253)"),
    ("Policy", "38", "POLCY-", ["08", "21", "22", "24", "25", "32", "34", "40", "41", "42", "44"], "Firm policy library; domain policy objects keep parameters (CD-252)"),
    ("Attestation", "38", "", ["08", "20"], "Moved from 08 (CD-252)"),
    ("Compliance Program Review", "38", "", ["35", "37"], "Rule 206(4)-7 / 38a-1 annual review; 35 Board Report Source Item references it"),
    ("Conduct Population Designation", "38", "", ["20"], "Access persons, covered associates (CD-254)"),
    ("Pre-Clearance Request", "38", "", [], "Single home of the pre-clearance decision"),
    ("Political Contribution", "38", "", ["42"], "Keyed by Political Contribution ID (PCON <year>-<sequence>); 42 LD-203 reports reference it (CD-273)"),
    ("Conflict of Interest", "38", "CONFL-", ["08"], "Firm conflicts register; 08 COI- is the distribution profile (CD-254)"),
    ("AML Case", "38", "", ["02", "29", "40"], "Restricted firm case number, no prefix (CD-255)"),
    ("Firm Restricted List", "38", "", ["33"], "Keyed by Restricted List Code; 33 Rule Instrument List reads it (CD-224, CD-256); insider lists are lists of type Insider List"),
    ("Restricted List Entry", "38", "RLIST-", ["23", "33"], "Only home of restricted names (CD-256)"),
    ("MNPI Escalation", "38", "MNPI-", ["23", "30", "34"], "23 flags, 38 decides (CD-256)"),
    ("Trade Surveillance Alert", "38", "TRSV-", ["25"], "Trade surveillance; communications surveillance stays 08 SURV- (CD-256)"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local lists in content_38 that are exact copies of enterprise shared lists. Register 38 as a
#    direct user (identity value_map), then delete the local copy. (shared list name, local list name in 38, note)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    ("Regulator", "Regulator", "Entity Authorization.Regulator (the 09 local 'Regulator' list is already a member, so the moved attribute shows the same shared list), Cross-Border Passport, exams, change items, STORs. Values identical to the shared list; see PROPOSED_CHANGES for the CD-255 additions."),
    ("Approval Status", "Approval Status", "Policy versions, holdings report review, contribution pre-clearance, OBAs. Values identical."),
    ("Case Status", "Case Status", "Exams, change impacts, AML cases, surveillance alerts. Values identical."),
    ("Severity", "Severity", "Exam finding severity and change impact rating. Values identical."),
    ("Record Status", "Record Status", "Policy and restricted list status, conflict register status. Values identical."),
    ("Frequency", "Frequency", "Policy review frequency. Values identical."),
    ("Information Classification", "Information Classification", "Restricted list visibility, MNPI escalations, AML case and report classification. Values identical."),
    ("Business Line", "Business Line", "Change impact scope (CD-209). Values identical."),
    ("Risk Rating", "Risk Rating", "AML program risk assessment. Values identical."),
]
# Screening Result (steward 08) was not needed: screening results stay on 02 KYC, 29 alerts and 40 onboarding cases.

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: local 38 lists that look like enterprise lists. (list in 38, proposed shared name, other users, note)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Firm Filing Status", None, ["35", "08", "16"],
     "Compare 35 Regulatory Filing Status, 08 filing status and 16 Government Filing status. Lifecycles differ (EDGAR acceptance vs "
     "FINRA review vs DOL EFAST); recommend NOT_MERGED."),
    ("Surveillance Disposition", None, ["08", "29", "33"],
     "08 Alert Disposition, 29 Monitoring Alert Disposition and 33 Alert Disposition Outcome share 'no issue / escalated' ideas "
     "but escalate to different records; report only, keep local."),
    ("Personal Trade Side", None, ["25", "24"],
     "Renamed from 'Trade Side' (26 uses that attribute name); spellings aligned to 25 Order Side (Sell Short, Buy to Cover). Keep local."),
    ("Entity Authorization Type", None, ["09"],
     "Moves with Entity Authorization (CD-250); after the 09 removal 38 is the only user. Five values added: 'SEC Large Trader "
     "(Form 13H)', 'US State Notice Filing', 'National Trust Bank Charter (OCC)', 'State Trust Company Charter', 'State Insurance License'."),
    ("Policy Domain", None, ["41", "44", "21"],
     "Siblings that reference 38 Policy filter by it; keep local to 38 (they read the Policy row)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS noticed with existing and sibling domains (decisions.py format).
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Filing",
     "usages": [("38", "Firm Regulatory Filing (FILNG-)", "Submission for an adviser, broker-dealer or other firm entity"),
                ("35", "Fund Regulatory Filing (REGF-)", "Submission for a fund"),
                ("08", "Communications filing / Form D", "Distribution filings"),
                ("16", "Government Filing (GFIL-)", "Plan filings (Form 5500)"),
                ("39", "Entity Statutory Filing", "Corporate law filings (annual reports, PSC register)")],
     "recommendation": "Extend the 'Filing' entry: never 'Filing' bare; qualify Firm, Fund, Government, Entity Statutory."},
    {"term": "Policy",
     "usages": [("38", "Policy (POLCY-)", "Governed document in the firm policy library"),
                ("34", "Voting Policy (VPOL-)", "Proxy voting parameters"),
                ("22", "Pricing Policy", "Pricing parameters"), ("25", "Best Execution Policy", "Execution parameters"),
                ("32", "Calculation Policy", "Performance calculation parameters"),
                ("43", "Corporate insurance policy (INPOL-)", "Insurance contract"),
                ("42", "Public Policy Position (PUBP-)", "Advocacy position")],
     "recommendation": "Extend the proposals_stage4_b entry: 'Policy' unqualified is the 38 library; domain policy objects reference it and keep only parameters."},
    {"term": "Restriction",
     "usages": [("38", "Restricted List Entry (RLIST-) / Restriction Reason", "Firm restricted and watch lists"),
                ("01", "Investment Restriction (RST-)", "Prospectus or mandate restriction"),
                ("02", "Client Restriction (CRX-)", ""), ("15", "Account Restriction (ARX-)", "")],
     "recommendation": "Extend the 'Restriction' entry (proposals_33): 'Restricted List' is 38's."},
    {"term": "Alert",
     "usages": [("38", "Trade Surveillance Alert (TRSV-)", "Orders, executions and personal transactions"),
                ("08", "Surveillance Alert (SURV-)", "Communications surveillance"),
                ("29", "Account Monitoring Alert (AMA-)", "Shareholder-account AML"),
                ("33", "Compliance Alert (CALERT-)", "Coded rule result")],
     "recommendation": "Extend the 'Alert' entry; always qualify by the monitored subject."},
    {"term": "Conflict",
     "usages": [("38", "Conflict of Interest (CONFL-)", "Firm register entry"),
                ("08", "Distribution Conflict of Interest (COI-)", "Distribution profile of a firm conflict"),
                ("07", "Remuneration Conflict Assessment", "Remuneration policy conflict check")],
     "recommendation": "Never 'Conflict' bare; the firm register is 38."},
    {"term": "Registration / Authorization",
     "usages": [("38", "Entity Authorization (AUTH-)", "Registration of an internal legal entity with a regulator"),
                ("08", "Individual Registration (LIC-)", "Registration of a person"),
                ("01", "Regulatory Authorization / product registration", "Registration of a product for sale"),
                ("13", "TA registration", "Shareholder registration of an account"),
                ("39", "Signing Authority Grant / Power of Attorney", "Internal authority, not a regulatory authorization")],
     "recommendation": "Qualify: Entity Authorization, Individual Registration, Product Registration, Account Registration, Signing Authority."},
    {"term": "Attestation",
     "usages": [("38", "Attestation", "Person's sign-off on a policy or certification (moved from 08)"),
                ("20", "Learning Completion", "Training completion, not an attestation"),
                ("33", "Manual Compliance Check", "Attested manual check")],
     "recommendation": "Extend: 'Attestation' is 38's; 20 Learning Item Type note names it."},
    {"term": "Examination / Audit",
     "usages": [("38", "Regulatory Examination (EXAM-)", "Supervisory exam or inquiry by a regulator"),
                ("37", "Audit Engagement (AUDIT-)", "Internal audit"),
                ("16", "Plan Audit (PAUD-)", "Plan financial statement audit"),
                ("14", "License Audit", "Vendor license audit"),
                ("08", "Qualification Exam", "Individual licensing exam")],
     "recommendation": "Qualify: Regulatory Examination, Audit Engagement, Plan Audit, License Audit, Qualification Exam."},
    {"term": "Exception",
     "usages": [("38", "Pay-to-Play exceptions (de minimis, returned contribution); attestation with exceptions", "Rule exceptions"),
                ("33", "Approved Exception / Guideline Waiver", ""), ("22", "Price validation exception", "")],
     "recommendation": "Qualify every use."},
    {"term": "Case",
     "usages": [("38", "AML Case", "Financial crime investigation"), ("08", "Frequent Trading Case", ""),
                ("02", "Onboarding Case (ONB-)", ""), ("27", "NAV Error Case (NEC-)", ""), ("40", "Supplier Onboarding Case", "")],
     "recommendation": "Qualify every case object by its subject."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. CHANGES PROPOSED TO OTHER DOMAINS (proposals only; 38 did not edit them). Resolves every 'future owner 38' note (CD-262).
# ---------------------------------------------------------------------------------------------------------------------
PROPOSED_CHANGES = [
    ("09", "Legal Entities / Regulatory Authorizations: Entity Authorization, Cross-Border Passport; lists Entity Authorization Type, Authorization Status, Regulated Activity, Passport Type",
     "Remove at merge (CD-250 option A). 38 holds them with identical tuples and values (verified 2026-10-06), plus 38 additions. "
     "The 09 relationships 'Internal Legal Entity holds Entity Authorization' and 'Entity Authorization is exercised cross-border "
     "through Cross-Border Passport' move to 38; 09 Sources rows on authorization registers may stay as identifier sources. "
     "AUTH- transfers to 38. 09 keeps Internal Legal Entity, Legal Entity Identifier, Entity Ownership Relationship and Entity Distribution Role."),
    ("08", "Obligations, Attestations & Data Governance: Regulatory Obligation, Attestation; lists Source Regulation, Compliance Assessment, Attestation Type, Attestation Status",
     "Remove at merge (CD-252 option A). 38 holds them with identical tuples and values. The 08 relationships 'Regulatory "
     "Obligation is evidenced by compliance records' and 'Attestation is given by Employee' re-point to 38 (08 records evidence "
     "38 obligations by reference). OBL- transfers to 38. Update the 08 overview Scope and Core model text."),
    ("08", "Distribution Conflicts Register / Distribution Conflict of Interest",
     "Add 'Firm Conflict' Reference (Conflict of Interest, 38), example CONFL-00231 (CD-254). This is the only holder of the link: "
     "38 dropped its Distribution Conflict Profile reference. COI- stays the distribution profile."),
    ("25", "Trade Order / Large Trader ID",
     "Re-note as Derived copy (38) of Entity Authorization.Regulator Reference Number where Authorization Type is 'SEC Large "
     "Trader (Form 13H)' (CD-250)."),
    ("25", "Relationships: 'Surveillance Alert [38]'",
     "Rename the target to 'Trade Surveillance Alert [38]' (CD-256); 25 overview market abuse surveillance -> 38 Trade Surveillance Alert."),
    ("26", "Trade Reporting family text and Reporting Counterparty note; relationship 'obligations read from 38 / 09'",
     "Read 38 Entity Authorization (names unchanged, owner 38) (CD-250)."),
    ("28", "CASS Firm Profile / CASS Entity Authorization",
     "Owner changes to 38 (Reference (Entity Authorization) resolves via AUTH-); text '09 authorization' -> '38 authorization'. "
     "28 overview 'CASS policy and audit (38)' -> 38 Policy (policy domain Compliance) and Firm Regulatory Filing (form CASS CMAR)."),
    ("29", "Account Monitoring Alert / Escalation Case Reference",
     "Re-type to Reference (AML Case, 38), example 'AML case 2026-0441', keeping the Restricted note (CD-255, brief §7). Monitoring "
     "Alert Disposition value "
     "'Escalated for SAR Decision' description and the relationship 'AML case (future 38)' -> 'AML Case [38]'."),
    ("23", "Meeting MNPI Assessment / MNPI Escalation Reference",
     "Re-type to Reference (MNPI Escalation, 38), example MNPI-2026-00412 (CD-256). Relationship 'Restricted list entry [38]' -> "
     "'Restricted List Entry [38]'. Wall-Crossing Timestamp note: 38 Insider List Entry.Access Obtained Timestamp copies it (row rule)."),
    ("23", "Research Provider Profile / Expert Network Due Diligence Date",
     "No 38 change: resolves to 37 Third-Party Risk Assessment (CD-248)."),
    ("33", "Rule Instrument List / Restricted List Source",
     "Re-type to Reference (Firm Restricted List, 38); the list is keyed by Restricted List Code (example 'GRL') (CD-224, CD-256)."),
    ("34", "Engagement / Passive Status Review Indicator",
     "Re-note: 'Flag only; the filing determination is 38 Ownership Disclosure Determination' (CD-251)."),
    ("35", "Board Report Source Item / Source Record Description example '38a-1 annual compliance program review (firm program, future 38)'",
     "Add 'Source Compliance Program Review' Reference (Compliance Program Review, 38), or re-note the example. 35 overview "
     "'firm filings such as Form ADV and 13F and the CCO's firm-level program (future 38)' -> 38 Firm Regulatory Filing and Compliance Program Review."),
    ("20", "Learning Item Type list source text 'policy attestations are 08, later 38'; overview 'codes of ethics and personal trading (38)'",
     "Re-word to '38 Attestation' and '38 Code of Ethics & Personal Trading' (CD-252, CD-254)."),
    ("09", "Shared list Regulator (steward 09)",
     "Add 'FinCEN' (US_FINCEN), 'OFAC' (US_TREASURY_OFAC), 'UK HM Treasury OFSI' (UK_HMT_OFSI) and 'UK National Crime Agency' "
     "(UK_NCA) (CD-255). 38's local copy is unchanged until the shared list changes; AML and Sanctions Report.Report Authority "
     "then uses them."),
    ("02", "Party Role Type",
     "Add 'Personal Account Broker' and 'Political Candidate / Committee' (CD-143 working assumption)."),
    ("41", "IT policies; Project Scope Link",
     "41 IT and information security policies are 38 Policy rows (policy domain Technology) referenced by 41. Project Scope Link "
     "is the only link from a project to a 38 Regulatory Change Item (CD-267); 38 holds no project reference."),
    ("42", "Lobbying Disclosure Report (LOBR-) / Reported Political Contributions",
     "Replace the example '(38 key pending)' with 'PCON 2026-00007' (Political Contribution ID). No amount copied (CD-273)."),
    ("37", "Risk Issue / Source Examination Finding; Other Issue Source Reference",
     "Keep the typed 'Source Examination Finding' (37 holds the link; 38 dropped its side). Add a typed 'Source Compliance Program "
     "Review' Reference (Compliance Program Review, 38) in place of the text key for that source type; 38 holds no risk issue reference."),
    ("39", "Corporate Resolution Subject Link / Subject Policy Version; Legal Matter / Originating Examination",
     "No change: these are the only holders of the policy approval and exam referral links (program lead ruling, CD-253). 38 Policy "
     "Version.Version Approval Date is a Derived copy (39) on entity-board rows."),
    ("08", "Regulatory Obligation / Applicable Legal Entity (moved to 38)",
     "After the merge, re-type the moved attribute from Code ('Legal Entity (firm-defined)') to Reference (Legal Entity) with a LEN- "
     "example. Not done in the draft because the tuple must stay identical until the move is applied."),
    ("38", "enrich_38 OWNERSHIP_OVERRIDES",
     "Remove the two overrides (Affected Obligations, Policy Regulatory Basis) once AUTH- and OBL- are transferred to 38 in "
     "decisions.PREFIXES, so they cannot mask a later mis-registration."),
    ("44", "Expense Policy Limit; travel, expense and health and safety policies",
     "Policy text is a 38 Policy row (policy domain Corporate Services); 44 keeps the limits."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "MOVE option drafted for CD-250 and CD-252 (program lead ruling). The four moved objects keep every attribute tuple of "
    "content_09 and content_08 unchanged, as the first rows of each object (re-verified by script after the review); 38 additions "
    "follow. The code lists Entity Authorization Type (five values appended: SEC Large Trader (Form 13H), US State Notice Filing, "
    "National Trust Bank Charter (OCC), State Trust Company Charter, State Insurance License), Authorization Status, Regulated "
    "Activity, Passport Type, Source Regulation, Compliance Assessment, Attestation Type and Attestation Status are copied value "
    "for value. Remove them from 09 and 08 at merge.",
    "The brief calls the list 'Authorization Type'; 38 keeps the 09 list name 'Entity Authorization Type' because names are unchanged.",
    "Resolver: OBL- is registered to 08 until the transfer, so enrich_38 OWNERSHIP_OVERRIDES force 'Affected Obligations' and "
    "'Policy Regulatory Basis' to 'mastered here' (see PROPOSED_CHANGES for their removal after the transfer).",
    "Links held once (program lead ruling and review 38_review.md): policy version approvals on 39 Corporate Resolution Subject Link "
    "(fund boards on 35, CD-237); exam referral on 39 Legal Matter.Originating Examination; finding and program review remediation "
    "on 37 Risk Issue; project delivery on 41 Project Scope Link (CD-267); distribution conflict profile on 08 'Firm Conflict'; "
    "obligation-to-policy on 38 Policy.Policy Regulatory Basis. 38 keeps relationship rows naming the holder.",
    "AML case keys stay restricted text without a prefix; AML and Sanctions Report.Reported Case is a Reference (AML Case, 38) whose "
    "example is the restricted case number. The AML Case holds the source references to 29, 02, 40 and 38 alerts.",
    "Insider lists: a Firm Restricted List of type Insider List holds Insider List Entries (MAR Art 18); deal-specific sections "
    "reference an MNPI Escalation and the permanent insiders section has none. Restricted List Entries belong to Restricted and "
    "Watch / Grey lists only.",
    "Row rules: Insider List Entry.Access Obtained Timestamp is a Derived copy (23) on rows sourced from an issuer meeting; Policy "
    "Version.Version Approval Date is a Derived copy (39) on rows approved by an entity board.",
    "Compliance monitoring tests are 37 Control Test rows (CD-243); 38 holds no test object. Regulatory Obligation.Monitoring Control references the 37 Control.",
    "Sibling object names used were checked against the drafted modules (review 38_review.md G): 37 Control (CNTRL-); 39 Corporate "
    "Officer Appointment; 40 Supplier Onboarding Case; 42 Lobbying Disclosure Report (relationship only); 39 Legal Matter, 39 "
    "Corporate Resolution, 37 Risk Issue and 41 Project appear only in relationship rows.",
    "Code lists: 53 in the module: 8 moved, 9 exact copies of shared lists (Regulator, Approval Status, Case Status, Severity, Record "
    "Status, Frequency, Information Classification, Business Line, Risk Rating) and 36 new local lists. The 44 local lists exceed "
    "the brief's 26-32 because they keep dimensions apart (Filing Submission Type vs Firm Filing Status; Restricted List Type vs "
    "Restriction Reason; AML Case Type vs SAR Decision vs AML Case Action; Pre-Clearance Decision vs Decision Reason).",
]
