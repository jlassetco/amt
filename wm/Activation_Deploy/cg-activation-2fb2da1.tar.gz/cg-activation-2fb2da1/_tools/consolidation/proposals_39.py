"""Consolidation proposals from the Data Domain 39 (Legal & Corporate Governance) draft v0.1, 2026-10-06.

Proposal fragment only: the builder does not read this file. The Stage 4 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Formats follow CONTRACT.md in this folder. Boundary decisions CD-253, CD-257, CD-258,
CD-259 and CD-262 are in proposals_stage4_a.py; this file holds what the draft found while implementing them. Nothing here
changes another domain's module.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES (prefix, entity, owner domain, status, note) - decisions.PREFIXES format
# None beyond the seven reserved in proposals_stage4_a.py. Parties, signatories, document versions, key dates, clauses,
# requests, matter parties, events, assessments, engagements, invoice reviews, custodians, scope rows, memberships,
# appointments, meetings, subject links, statutory filings, authority grants, docket deadlines and license grants keep
# composite keys (GRAIN_KEY_FORMATS).
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

PREFIX_REGISTRATIONS = ["CTRCT-", "LMAT-", "LHOLD-", "CGOV-", "CGRES-", "POWER-", "TMARK-"]

KEY_FORMATS = [
    ("CTRCT-", "39", "CTRCT-<sequence, 7 digits>", "CTRCT-0041877"),
    ("LMAT-", "39", "LMAT-<year opened>-<sequence, 4 digits>", "LMAT-2026-0019"),
    ("LHOLD-", "39", "LHOLD-<year issued>-<sequence, 4 digits>", "LHOLD-2026-0007"),
    ("CGOV-", "39", "CGOV-<sequence, 4 digits>", "CGOV-0003"),
    ("CGRES-", "39", "CGRES-<year adopted>-<sequence, 5 digits>", "CGRES-2026-00041"),
    ("POWER-", "39", "POWER-<year granted>-<sequence, 5 digits>", "POWER-2026-00112"),
    ("TMARK-", "39", "TMARK-<sequence, 5 digits>", "TMARK-00318"),
]

# Grain keys of objects without a prefix (object, key format, example). No hyphenated letter stem, so none reads as a prefix.
GRAIN_KEY_FORMATS = [
    ("Contract Document Version", "<CTRCT- key> v<version number> / <document sequence>", "CTRCT-0040012 v2 / 1"),
    ("Contract Key Date", "<CTRCT- key> / <key date type> / <key date sequence>", "CTRCT-0041877 / Renewal Notice Deadline / 2"),
    ("Matter Financial Assessment", "<LMAT- key> / <LEN- key of reporting entity> / <assessment date>", "LMAT-2026-0019 / LEN-0001 / 2026-09-30"),
    ("Legal Service Request", "<year>/<sequence, 5 digits>", "2026/00318"),
    ("Corporate Board Meeting", "<CGOV- key> / <meeting date YYYY-MM-DD> / <sequence>", "CGOV-0003 / 2026-11-18 / 1"),
    ("Outside Counsel Engagement", "<engagement letter CTRCT- key> / <LMAT- key, empty for general advisory>", "CTRCT-0042011 / LMAT-2026-0019"),
    ("Signing Authority Grant", "Employee <number> / <authority type> / entity <number> / <effective from>", "Employee 30412 / Contract Signature / entity 0004 / 2026-01-01"),
    ("Entity Statutory Filing", "<LEN- key> / <statutory filing type> / <period end>", "LEN-0021 / UK Confirmation Statement / 2026-08-31"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. CONCEPT_OWNERSHIP rows (concept, owner, prefix, referencing domains, note)
# ---------------------------------------------------------------------------------------------------------------------
CONCEPT_OWNERSHIP = [
    ("Contract", "39", "CTRCT-", ["05", "10", "14", "16", "20", "26", "28", "30", "35", "40", "41", "43", "44"], "CD-257. Generic record of every executed instrument; typed records keep commercial terms."),
    ("Contract Document Version", "39", "", ["28", "35"], "CD-257. The only place a contract document location is held (05 Agreement Document stays 05, SME question 2)."),
    ("Legal Matter", "39", "LMAT-", ["37", "38", "42", "43"], "CD-253, CD-258. Includes regulatory enforcement investigations and proceedings."),
    ("Legal Hold", "39", "LHOLD-", ["02", "08", "38"], "CD-258. Legal Hold Scope is the source of the 02 and 08 Legal Hold Indicators."),
    ("Corporate Governing Body", "39", "CGOV-", ["35", "37"], "CD-259. Boards and committees of internal entities other than funds, fund-management entities and private fund general partners (35)."),
    ("Corporate Resolution", "39", "CGRES-", [], "CD-259 and program lead ruling: what it approved (including memberships, officer appointments, powers of attorney and authority grants) is held only on Corporate Resolution Subject Link; 37, 38, 42 and 43 hold no approving-resolution reference."),
    ("Corporate Officer Appointment", "39", "", ["38"], "CD-259. Adviser CCO, BSA / AML officer, MLRO and SM&CR function holders as entity appointments; the individual's SM&CR approval stays 08."),
    ("Power of Attorney", "39", "POWER-", [], "CD-259."),
    ("Signing Authority Grant", "39", "", ["43"], "CD-259. Bank mandates and signatories are 43."),
    ("Trademark Registration", "39", "TMARK-", ["04", "42"], "CD-259. Brands stay 04 / 42."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_MEMBERSHIPS: 39 local lists that carry an enterprise shared list's exact name and values. Register 39 as a
#    direct user and switch the attributes to "Shared: <name>" (identity value maps).
# ---------------------------------------------------------------------------------------------------------------------
_ident = lambda pairs: {label: code for label, code in pairs}
SHARED_MEMBERSHIPS = [
    {"shared": "Agreement Status", "local": "Agreement Status", "attributes": "Contract.Contract Status",
     "value_map": _ident([("Draft", "DRAFT"), ("In Negotiation", "IN_NEGOTIATION"), ("Pending Signature", "PENDING_SIGNATURE"), ("Executed - Not Yet Effective", "EXECUTED_NOT_EFFECTIVE"), ("Active", "ACTIVE"), ("Suspended", "SUSPENDED"), ("Under Notice of Termination", "UNDER_NOTICE"), ("Terminated", "TERMINATED"), ("Expired", "EXPIRED"), ("Superseded", "SUPERSEDED")]), "new_values": []},
    {"shared": "Approval Status", "local": "Approval Status", "attributes": "Corporate Board Meeting.Minutes Approval Status; Outside Counsel Invoice Review.Invoice Review Status",
     "value_map": _ident([("Not Required", "NOT_REQUIRED"), ("Pending", "PENDING"), ("Approved", "APPROVED"), ("Approved with Conditions", "APPROVED_WITH_CONDITIONS"), ("Retrospectively Approved", "RETROSPECTIVELY_APPROVED"), ("Rejected", "REJECTED"), ("Expired", "EXPIRED"), ("Withdrawn", "WITHDRAWN")]), "new_values": []},
    {"shared": "Case Status", "local": "Case Status", "attributes": "Legal Service Request.Legal Request Status; Legal Matter.Matter Status",
     "value_map": _ident([("New / Received", "NEW"), ("Pending Good Order", "PENDING_GOOD_ORDER"), ("In Progress", "IN_PROGRESS"), ("Waiting on Client", "WAITING_ON_CLIENT"), ("Pending Third Party", "PENDING_THIRD_PARTY"), ("Escalated", "ESCALATED"), ("Resolved / Completed", "RESOLVED"), ("Closed", "CLOSED"), ("Rejected", "REJECTED"), ("Canceled", "CANCELED")]), "new_values": []},
    {"shared": "Record Status", "local": "Record Status", "attributes": "Corporate Governing Body.Corporate Body Status",
     "value_map": _ident([("Draft", "DRAFT"), ("Proposed", "PROPOSED"), ("Pending", "PENDING"), ("Active", "ACTIVE"), ("Paused", "PAUSED"), ("Inactive", "INACTIVE"), ("Deprecated", "DEPRECATED"), ("Retired", "RETIRED")]), "new_values": []},
    {"shared": "Regulator", "local": "Regulator", "attributes": "Legal Matter.Matter Regulator",
     "value_map": _ident([("SEC", "US_SEC"), ("FINRA", "US_FINRA"), ("US State Securities Regulator", "US_STATE_SECURITIES_REGULATOR"), ("CFTC / NFA", "US_CFTC_NFA"), ("OCC", "US_OCC"), ("US State Banking Regulator", "US_STATE_BANKING_REGULATOR"), ("Federal Reserve", "US_FEDERAL_RESERVE"), ("DOL / EBSA", "US_DOL_EBSA"), ("US State Insurance Regulator", "US_STATE_INSURANCE_REGULATOR"), ("IRS / US Treasury", "US_IRS_TREASURY"), ("FCA", "UK_FCA"), ("PRA", "UK_PRA"), ("CSSF", "LU_CSSF"), ("Central Bank of Ireland", "IE_CBI"), ("BaFin", "DE_BAFIN"), ("AMF", "FR_AMF"), ("CONSOB / Banca d'Italia", "IT_CONSOB_BANCA_D_ITALIA"), ("CNMV", "ES_CNMV"), ("AFM", "NL_AFM"), ("FINMA", "CH_FINMA"), ("Other EU NCA", "OTHER_EU_NCA"), ("ESMA", "EU_ESMA"), ("European Commission", "EU_COMMISSION"), ("IOSCO", "INTL_IOSCO")]),
     "new_values": [], "note": "Matter Regulator is the only record of a matter's regulator (review B2). Add 'US Department of Justice' and 'US State Attorney General' to the shared list so DOJ and state actions can be coded; add the CD-255 values (FinCEN, OFAC, OFSI, NCA) once applied."},
    {"shared": "Information Classification", "local": "Information Classification", "attributes": "Legal Matter.Matter Classification",
     "value_map": _ident([("Public", "PUBLIC"), ("Internal", "INTERNAL"), ("Confidential", "CONFIDENTIAL"), ("Confidential - Personal Data", "CONFIDENTIAL_PERSONAL_DATA"), ("Confidential - Client", "CONFIDENTIAL_CLIENT"), ("Confidential - Financial", "CONFIDENTIAL_FINANCIAL"), ("Confidential - Compensation", "CONFIDENTIAL_COMPENSATION"), ("Confidential - Licensed", "CONFIDENTIAL_LICENSED"), ("Restricted", "RESTRICTED"), ("Restricted - Personal Data", "RESTRICTED_PERSONAL_DATA"), ("Restricted - MNPI", "RESTRICTED_MNPI"), ("Restricted - Commercial Terms", "RESTRICTED_COMMERCIAL_TERMS"), ("Restricted - Legal", "RESTRICTED_LEGAL")]), "new_values": []},
    {"shared": "Severity", "local": "Severity", "attributes": "Legal Matter.Matter Significance",
     "value_map": _ident([("Low", "LOW"), ("Medium", "MEDIUM"), ("High", "HIGH"), ("Critical", "CRITICAL")]), "new_values": []},
    {"shared": "Frequency", "local": "Frequency", "attributes": "Corporate Governing Body.Meeting Frequency",
     "value_map": _ident([("Real-Time", "REAL_TIME"), ("Intraday", "INTRADAY"), ("Daily", "DAILY"), ("Weekly", "WEEKLY"), ("Fortnightly", "FORTNIGHTLY"), ("Monthly", "MONTHLY"), ("Quarterly", "QUARTERLY"), ("Semi-Annual", "SEMI_ANNUAL"), ("Annual", "ANNUAL"), ("Biennial", "BIENNIAL"), ("On Event", "ON_EVENT"), ("Ad Hoc", "AD_HOC")]), "new_values": []},
    {"shared": "Committee Decision Outcome", "local": "Committee Decision Outcome", "attributes": "Corporate Resolution.Corporate Resolution Outcome",
     "value_map": _ident([("Approved", "APPROVED"), ("Approved with Conditions", "APPROVED_WITH_CONDITIONS"), ("Rejected", "REJECTED"), ("Deferred", "DEFERRED"), ("Noted", "NOTED")]), "new_values": [],
     "note": "Brief §8 names this list for the resolution outcome. 35 uses its own Board Resolution Outcome (Adopted, Not Adopted, ...); a corporate resolution is 'Approved' when adopted."},
    {"shared": "Business Line", "local": "Business Line", "attributes": "Contract.Contract Business Lines",
     "value_map": _ident([("Mutual Fund", "MUTUAL_FUND"), ("ETF", "ETF"), ("Collective Investment Trust", "COLLECTIVE_INVESTMENT_TRUST"), ("Separately Managed Account", "SEPARATELY_MANAGED_ACCOUNT"), ("Private Markets", "PRIVATE_MARKETS"), ("Insurance-Dedicated Fund", "INSURANCE_DEDICATED_FUND")]), "new_values": []},
    {"shared": "Inclusion Type", "local": "Inclusion Type", "attributes": "Legal Hold Scope.Scope Inclusion Type",
     "value_map": _ident([("Include", "INCLUDE"), ("Exclude", "EXCLUDE")]), "new_values": []},
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. SHARED_CANDIDATES (list name in 39, proposed shared list name or None, likely other users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Governing Law", "Governing Law", ["05", "26", "28", "40", "43", "44"],
     "39 copies the 05 list value for value and adds 'Maryland'. Contract Governing Law is a Derived copy of 05 on 05 rows, so "
     "the values must agree: promote to a shared list stewarded by 05 or 39 (recommend 39) with 'Maryland' added; 40 ICT "
     "Register of Information Entry (governing law of the arrangement) should cite it."),
    ("Corporate Member Role", "Committee Member Role", ["24", "35", "36"],
     "Stage 3 deferred a shared Committee Member Role (24, 35, 36). 39 adds 'Executive Director', 'Non-Executive Director', "
     "'Independent Non-Executive Director', 'Manager', 'Company Secretary'. Recommend NOT_MERGED with 35 Governing Body "
     "Member Role (fund independence under s.2(a)(19) differs), but a shared list for management committees (24, 36) is possible."),
    ("Corporate Officer Role", None, ["35", "38"],
     "35 Fund Officer Role names fund officers (Rule 38a-1 CCO of the fund, PFO, liquidity administrator). Record as NOT_MERGED: "
     "the 39 list holds entity officers (adviser CCO under Rule 206(4)-7, BSA officer, MLRO, SMF holders)."),
    ("Corporate Meeting Type", None, ["35"],
     "Parallels 35 Board Meeting Type (written consent as a meeting type). Keep local; a 'Committee Meeting Type' shared list "
     "was suggested in proposals_35 and could take both."),
    ("Contract Family / Contract Subtype", None, ["05", "14", "26", "28", "35", "40"],
     "Each typed owner keeps its own type list (05 Agreement Type, 26 trading agreement type, 28 Lending Agreement Type, 35 "
     "Advisory Agreement Type). 39 Contract Subtype is the cross-domain index; publish a crosswalk from each typed list to "
     "Contract Subtype at consolidation rather than merging."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. PROPOSED_CHANGES to other domains (proposed, not applied): (domain, object.attribute / list, proposed change, rationale)
#    Every "future owner 39" note in 01-36 is resolved here (CD-262).
# ---------------------------------------------------------------------------------------------------------------------
PROPOSED_CHANGES = [
    ("28", "Custody Provider Profile.Service Agreement Reference", "Re-type from Text to Reference (Contract, 39), example CTRCT-0041877; drop the 'future owner 39' note.", "CD-257, CD-262."),
    ("28", "Securities Lending Agreement.Agreement Document Reference", "Drop, or make a Derived copy (39) of Contract Document Version.Document Location of the executed version; the note '39 Legal will index the document' resolves to Contract Document Version.", "CD-257. Document location held once."),
    ("35", "Fund Governing Body.Charter Reference", "Re-type from Text to Reference (Contract Document Version, 39), example 'CTRCT-0040012 v2'; drop 'The contract repository is future 39'.", "CD-257, CD-262."),
    ("35", "Fund Advisory Agreement.Agreement Document Location", "Re-type to Reference (Contract Document Version, 39), or drop it and find the executed copy through 39 Typed Contract Link.Linked Fund Advisory Agreement.", "CD-257, CD-262. Document location held once."),
    ("35", "family text FG-GOV 'Corporate boards ... are future 39'; overview 'contract repository and corporate boards ... (future 39)'; FG-ADV 'contract repository is future 39'", "Name 39 Corporate Governing Body (CGOV-) and 39 Contract (CTRCT-).", "CD-259, CD-262."),
    ("26", "overview text 'enterprise contract repository (39)'", "Name 39 Contract (CTRCT-); 26 Trading Agreement is the typed record (Typed Record Type 'Trading Agreement (26)').", "CD-257, CD-262."),
    ("30", "overview text 'LPA and side letter documents as contracts (future 39)'", "Name 39 Contract: fund LPAs are Constitutional Document contracts typed by 30 Private Fund Profile, subscription agreements are typed by 30 Investor Commitment, and side letters by the 30 side letter (commitment x side letter date).", "CD-257, CD-262. SME question 9."),
    ("20", "Contingent Worker Detail.Supplier Contract Reference", "Re-type to Reference (Contract, 39) (the SOW or agency contract), or to Reference (Purchase Order, 40) per CD-260; 39 recommends Contract for the SOW and 40 for the PO.", "CD-257, CD-260."),
    ("02", "Retention.Legal Hold Indicator", "Make a Derived copy (39): true while any Legal Hold Scope row with Hold Scope Type 'Party' and Scoped Party = the party has Disposal Suspended Indicator = Y.", "CD-258."),
    ("08", "Captured Communication Record.Legal Hold Indicator", "Make a Derived copy (39): true while a Legal Hold Scope row covers the record's Retention Rule (record class), date and custodian with Disposal Suspended Indicator = Y.", "CD-258. 08 Retention Rule stays 08."),
    ("15", "list Account Restriction Type value 'Legal Hold'", "No change; note that the account restriction is placed on instruction from a 39 Legal Hold (an account-level transaction block, not record preservation).", "CD-258 clarity."),
    ("05", "Agreement Document (DOC-)", "No change now. If Legal's repository becomes the system of record for executed copies, Agreement Document Location becomes a Derived copy (39) of Contract Document Version.", "CD-257, SME question 2."),
    ("05", "Distribution Agreement.Agreement Status, Governing Law, effective and end dates", "No change: 05 masters them; 39 Contract holds Derived copies on 05-typed rows.", "CD-257 row rule."),
    ("02", "list Party Role Type", "Add 'Outside Counsel', 'Opposing Party', 'Non-Executive Director', 'Attorney-in-Fact' (outside counsel are referenced from Outside Counsel Engagement, not Matter Party).", "CD-143 working assumption (brief §9)."),
    ("37", "Risk Appetite Statement.Approving Corporate Resolution; Audit Plan.Audit Committee Approval", "Drop both (program lead ruling: approval links are held only on 39 Corporate Resolution Subject Link). Where the date is needed, hold it as a Derived copy (39) of Corporate Resolution Effective Date.", "Ruling 2 (one link per approval, CD-237 pattern)."),
    ("38", "Policy Version.Approving Corporate Resolution", "Drop (ruling); entity-board approvals are on 39 Corporate Resolution Subject Link (Subject Policy Version); fund board approvals stay 35. A Derived copy (39) of the approval date may be held.", "Ruling 2."),
    ("42", "Corporate Publication.Publication Approval Resolution", "Drop (ruling); the link is 39 Corporate Resolution Subject Link (Subject Corporate Publication).", "Ruling 2."),
    ("43", "Intra-Group Capital Transaction, ICARA Assessment, Debt Facility, Seed Capital Commitment (approval)", "Hold no CGRES- reference (the 43 draft already states this in its relationships); the link is 39 Corporate Resolution Subject Link.", "Ruling 2."),
    ("38", "Regulatory Examination.Referred Legal Matter", "Drop (ruling, CD-253); the link is 39 Legal Matter.Originating Examination. A Derived copy (39) is acceptable if 38 needs to show it.", "Ruling 2."),
    ("37", "Operational Loss Event", "37 holds the link to the 39 Legal Matter that caused a settlement or fine; 39 holds none.", "CD-258; one direction."),
    ("44", "Lease.Lease Contract", "Keep: 44 holds the lease-to-contract link (ruling); 39 dropped Linked Lease and keeps the Typed Record Type value 'Lease (44)'.", "Ruling 2; CD-257 one direction."),
    ("43", "Corporate Bank Account (bank mandate); relationship 'Contract [39] is typed by Corporate Bank Account / Debt Facility / Corporate Insurance Policy'", "43 keeps no mandate agreement record, so a bank mandate is an untyped 39 Contract (subtype Bank Account Mandate) that references the account (39 Contract.Related Corporate Bank Account). Amend the 43 relationship to 'is typed by Debt Facility / Corporate Insurance Policy' plus 'Contract (bank mandate) governs Corporate Bank Account'.", "Ruling 3."),
    ("43", "Debt Facility; Corporate Insurance Policy", "No change: the link is held once on 39 Typed Contract Link (Linked Debt Facility, Linked Insurance Policy), as the 43 draft states.", "CD-257."),
    ("40", "Supplier Contract Profile (keyed by CTRCT-)", "No change: 40 holds the link; 39 dropped Linked Supplier Contract Profile (it always equaled Contract ID).", "Review A9."),
    ("30", "Side Letter Provision", "Confirm that a side letter is identified by commitment x side letter date (the letter), which 39 Linked Side Letter references, or add a 30 Side Letter header object. Investor Commitment and Private Fund Profile are typed owners of subscription agreements and fund LPAs.", "Ruling 5."),
    ("35", "Fund Governing Body.Governed Entity definition ('general partner')", "No change: private fund general partner boards are 35 (ruling 6, CD-259); 39 removed 'General Partner Board'. Carry vehicles and holding entities with no fund-governing role are 39.", "Ruling 6."),
    ("13", "Servicing Provider Engagement", "Add Reference (Contract, 39) for the TA or servicing agreement (an untyped contract); 39 holds no link back.", "Review A11; brief §7."),
    ("08", "SM&CR records", "No change: the individual's SM&CR approval stays 08; 39 dropped Regulatory Approval Date from Corporate Officer Appointment.", "Ruling 6."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. TERM_CONFLICTS (decisions.TERM_CONFLICTS format)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Agreement / Contract / License",
     "usages": [("39", "Contract (CTRCT-)", "Generic record of any executed instrument"),
                ("05", "Distribution Agreement (AGR-)", "Typed distribution agreement"),
                ("14", "Data License Agreement (DLA-)", "Typed data license"),
                ("26", "Trading Agreement (TAGR-)", "Typed trading agreement"),
                ("35", "Fund Advisory Agreement (ADVA-)", "Typed advisory agreement"),
                ("10", "Intercompany Agreement (ICA-); Revenue Contract", "Typed intercompany agreement; revenue recognition contract"),
                ("39", "Trademark License Grant", "License of a mark the firm owns (outbound)")],
     "recommendation": "'Contract' means the 39 generic record only; every typed record keeps its qualified name. 'License' alone is not used: 'Data License Agreement' (14, inbound) vs 'Trademark License Grant' (39, outbound) vs 08 'License' (individual registration)."},
    {"term": "Board",
     "usages": [("35", "Fund Governing Body (BOARD-)", "Fund and fund-management boards"),
                ("39", "Corporate Governing Body (CGOV-)", "Boards and committees of other internal entities"),
                ("13", "BOD- (beneficial-owner distribution request)", "Unrelated prefix")],
     "recommendation": "Always qualify: 'Fund Governing Body' (35) vs 'Corporate Governing Body' (39) (CD-231, CD-259)."},
    {"term": "Resolution",
     "usages": [("35", "Board Resolution (RESO-)", "Fund board action"),
                ("39", "Corporate Resolution (CGRES-)", "Corporate body action"),
                ("08 / 12 / 13", "Case resolution", "Closure of a case")],
     "recommendation": "'Board Resolution' (35), 'Corporate Resolution' (39), 'Case Resolution' elsewhere."},
    {"term": "Committee",
     "usages": [("39", "Corporate Governing Body of type Audit / Risk / Remuneration Committee", "Committees of the corporate group's boards"),
                ("35", "Board Committee", "Fund board committees"),
                ("22 / 24 / 36", "Valuation, Investment, Product Governance Committee", "Management committees")],
     "recommendation": "Qualify by parent: 'Corporate Board Committee' (39), 'Fund Board Committee' (35), management committees by function."},
    {"term": "Hold",
     "usages": [("39", "Legal Hold (LHOLD-)", "Suspension of record disposal"),
                ("18", "Portfolio Holding (HLD-)", "Position in a portfolio"),
                ("15", "Account Restriction type 'Legal Hold'", "Transaction block on an account")],
     "recommendation": "'Legal Hold' (39) always qualified; 15 value renamed 'Legal Restriction' or kept with a note (proposed)."},
    {"term": "Matter",
     "usages": [("39", "Legal Matter (LMAT-)", "Dispute, litigation or enforcement"),
                ("38", "Regulatory Examination", "Supervisory exam or inquiry"),
                ("35", "Material Compliance Matter Indicator", "Rule 38a-1 board reporting term")],
     "recommendation": "'Legal Matter' for 39; 'compliance matter' stays a 38a-1 term."},
    {"term": "Filing",
     "usages": [("39", "Entity Statutory Filing", "Company registry and BOI filings"),
                ("38", "Firm Regulatory Filing (FILNG-)", "Form ADV, BD, 13F and similar"),
                ("35", "Fund Regulatory Filing (REGF-)", "Fund-level filings"),
                ("16", "Government Filing (GFIL-)", "Plan filings")],
     "recommendation": "Add 'Entity Statutory Filing' (39) to the CD-233 naming set."},
    {"term": "Brand / Trademark",
     "usages": [("04", "Brand (BRD-)", "Brand architecture (moving to 42, CD-271)"),
                ("42", "Corporate brand standard; Brand Use Authorization", "Brand use"),
                ("39", "Trademark Registration (TMARK-); Trademark License Grant", "Legal registration and license of the mark")],
     "recommendation": "Brand is the marketing identity (04 / 42); trademark is the legal right (39). 42 Brand Use Authorization approves use; 39 Trademark License Grant is the legal license."},
    {"term": "Authority / Authorization",
     "usages": [("39", "Signing Authority Grant; Power of Attorney", "Who may sign for an entity"),
                ("09 / 38", "Entity Authorization (AUTH-)", "Regulatory license of an entity (moving to 38, CD-250)"),
                ("43", "Bank Account Signatory", "Bank mandate authority")],
     "recommendation": "'Signing Authority' (39), 'Regulatory Authorization' (38), 'Bank Signatory Authority' (43)."},
    {"term": "Signatory",
     "usages": [("39", "Contract Signatory", "Person who signed a contract"),
                ("43", "Bank Account Signatory", "Person on a bank mandate")],
     "recommendation": "Qualify; 43 signatories may rely on a 39 Signing Authority Grant of type 'Payment Approval'."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "CD-257 amendment (program lead ruling 3): the typed-owner list is 01, 05, 10, 14, 16, 26, 28, 30, 35, 40, 43, 44. Leases are "
    "typed 44 rows (remove 'lease' from the untyped list in the CD-257 resolution text). 40 rows are typed but 39 masters their "
    "dates, status, law and parties (40 holds procurement terms only). Bank mandates are untyped 39 contracts that reference the 43 "
    "Corporate Bank Account, because 43 keeps no mandate agreement record. The links to 40 Supplier Contract Profile and to 44 Lease "
    "are held on their side; every other typed link is held on 39 Typed Contract Link.",
    "Row rule owner (ruling 4): Contract Status, Contract Effective Date, Contract Expiry Date, Governing Law, Contract Party Role and "
    "Key Date Value stay flagged Derived copy with declared owner '05'; each note states 'owner = domain of the typed link; mastered "
    "in 39 on untyped rows', and the note is the authority. The catalog needs a per-row owner mechanism (Enterprise_Expansion_Plan "
    "§4 item 9, 'Row Ownership Rule') so these attributes stop printing 05 on rows 05 does not own.",
    "Approval links (rulings 1 and 2): no 39 object holds its own approving resolution; memberships, officer appointments, powers of "
    "attorney and signing authority grants are subject types of Corporate Resolution Subject Link. 37, 38 and 42 drop their consumer-"
    "side references (PROPOSED_CHANGES); 43 already holds none.",
    "Amendments (ruling 5): every executed amendment is its own Contract with a Parent Contract and its own typed link where one exists "
    "(05 Agreement Amendment); otherwise its dates are mastered here. One contract carries the link to a given typed record.",
    "Corporate Resolution Subject Link is a 29th object (brief §5 put subject fields on Corporate Resolution); it mirrors 35 Resolution Subject Link.",
    "42 renames its COVG- prefix (anagram of CGOV-); CGOV- is kept as reserved.",
    "04 Brand moves to 42 under CD-271 (the 42 draft already masters BRD-): Trademark Registration.Protected Brand then resolves to 42; re-check after consolidation.",
    "Overrides: 28 Securities Lending Agreement has no key (forced 28); 30 Private Fund Profile is keyed by PRD- (forced 30).",
    "Local list count is 33 (brief target 24-30): the brief's list less UTBMS Task Code and Nice Class (external formats), with Loss "
    "Contingency Likelihood split into ASC 450 and IAS 37 lists (review C1), plus Contract Hierarchy Role, Governing Law, Corporate "
    "Meeting Type, Power of Attorney Type, Document Role and Deadline Action Status.",
]
