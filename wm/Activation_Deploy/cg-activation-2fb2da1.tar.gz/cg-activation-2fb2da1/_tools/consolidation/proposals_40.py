"""Consolidation proposals from Data Domain 40 - Procurement & Vendor Management (Stage 4 draft v0.1, 2026-10-06).

Proposal fragment only: the builder does not read it. The Stage 4 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Format follows CONTRACT.md in this folder. Decisions implemented: CD-248, CD-257,
CD-260, CD-261 and CD-262 (proposals_stage4_a.py), and the program lead's ruling that 40 masters the DORA register of
information with 41 IT services and applications cited from it (CD-249 / CD-268). Nothing here edits 01-36.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones. None needed: 40 uses only VENG-, SRCG-, PREQ-, PURCH- and OUTS- (CD-262).
#    The ERP supplier number is an attribute written without a hyphenated stem ("SUP 0045521"; SUP- is one letter from SUB-).
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# Key formats of the reserved prefixes, as 40 issues them (decisions.PREFIX_FORMATS tuple format). Confirms CD-262.
KEY_FORMATS = [
    ("VENG-", "40", "VENG-<sequence, 6 digits>", "VENG-001877"),
    ("SRCG-", "40", "SRCG-<year>-<sequence, 4 digits>", "SRCG-2026-0031"),
    ("PREQ-", "40", "PREQ-<year>-<sequence, 7 digits>", "PREQ-2026-0018840"),
    ("PURCH-", "40", "PURCH-<ERP purchase order number, 10 digits>", "PURCH-4500021877"),
    ("OUTS-", "40", "OUTS-<sequence, 4 digits>", "OUTS-0042"),
]

# Grain keys of the objects without a prefix (object, key format, example).
GRAIN_KEY_FORMATS = [
    ("Supplier Profile", "PTY-<party number> (02 key) + Supplier Status Effective From", "PTY-702114 / 2025-03-14"),
    ("Supplier Remittance Detail", "PTY-<party number> + remittance sequence + Remittance Effective From", "PTY-702114 / 1 / 2025-03-14"),
    ("Supplier Onboarding Case", "PTY-<party number> + onboarding sequence", "PTY-702114 / 2"),
    ("Supplier Category Assignment", "VENG- + procurement category + Category Effective From", "VENG-001877 / IT Software and SaaS / 2025-04-01"),
    ("Sourcing Award", "SRCG- + PTY- of the awarded supplier (one row per supplier in a split award)", "SRCG-2026-0031 / PTY-702114"),
    ("Sourcing Invitation", "SRCG- + PTY- of the invited supplier", "SRCG-2026-0031 / PTY-702114"),
    ("Purchase Order Line", "PURCH- + PO line number", "PURCH-4500021877 / 10"),
    ("Goods and Service Receipt", "PURCH- + PO line number + receipt sequence", "PURCH-4500021877 / 10 / 3"),
    ("Invoice Match Result", "APV- + invoice line number + PURCH- + PO line number", "APV-2026-0018833 / 1 / PURCH-4500021877 / 10"),
    ("Supplier Contract Profile", "CTRCT- (39 key; untyped contracts or typed 'Supplier Contract Profile (40)' only)", "CTRCT-0041877"),
    ("Contracted Service Level", "CTRCT- + metric name + Service Level Effective From", "CTRCT-0041877 / Platform availability / 2026-05-01"),
    ("Supplier Performance Review", "VENG- + Review Period End", "VENG-001877 / 2026-06-30"),
    ("Service Level Measurement Result", "CTRCT- + metric name + Service Level Effective From + Measurement Period End", "CTRCT-0041877 / Platform availability / 2026-05-01 / 2026-08-31"),
    ("Supplier Spend Summary", "PTY- + LEN- + fiscal period", "PTY-702114 / LEN-0004 / FY2026-P09"),
    ("Supplier Risk Tiering", "VENG- + Tier Effective From", "VENG-001877 / 2026-03-20"),
    ("Exit Plan", "OUTS- (one plan per arrangement)", "OUTS-0042"),
    ("Outsourcing Notification", "OUTS- + authority + notification type + Notification Date", "OUTS-0042 / CSSF / Prior Notification of Material Outsourcing / 2025-04-15"),
    ("ICT Register Arrangement Header", "CTRCT- + ICT service type identifier (DORA B_07.01 key; provider is the contract counterparty)", "CTRCT-0041877 / S19"),
    ("ICT Register of Information Entry", "LEN- of the entity making use + CTRCT- + ICT service type + 37 function code (DORA B_02.02 key)", "LEN-0012 / CTRCT-0041877 / S19 / CIF 03"),
    ("Supply Chain Subcontractor", "CTRCT- + ICT service type + PTY- of the subcontractor + rank (DORA B_05.02 key)", "CTRCT-0041877 / S19 / PTY-500990 / 2"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local 40 lists that are verbatim copies (labels) of enterprise shared lists; register 40 as a
#    direct user. (shared list name, local list name in 40, where 40 uses it)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    ("Screening Result", "Screening Result", "Supplier Onboarding Case Sanctions Screening Result"),
    ("Approval Status", "Approval Status", "Onboarding, Sourcing Award and Purchase Requisition approval"),
    ("Case Status", "Case Status", "Supplier Onboarding Case status"),
    ("Payable Invoice Status", "Payable Invoice Status", "Invoice Match Result Invoice Status at Match (Derived copy of 19)"),
    ("Agreement Status", "Agreement Status", "Supplier Contract Profile Contract Status (Derived copy of 39)"),
    ("SLA Unit", "SLA Unit", "Contracted Service Level unit"),
    ("Regulator", "Regulator", "Outsourcing Notification authority"),
    ("Record Status", "Record Status", "Supplier Engagement and Outsourcing Arrangement status"),
    ("Business Line", "Business Line", "Supplier Engagement business lines"),
]
# Value maps: every local value is the shared label one to one (e.g. 'No Match' -> NO_MATCH, 'Approved for Payment' ->
# APPROVED, 'Under Notice of Termination' -> UNDER_NOTICE, 'CSSF' -> LU_CSSF, 'Mutual Fund' -> MUTUAL_FUND).
# 'Information Classification', 'Frequency' and 'Risk Rating' are not used: remittance details carry the shared labels
# 'Restricted - Personal Data' / 'Restricted' in their notes, and the inherent tier uses the local Third-Party Criticality Tier
# (Risk Rating values describe risk, not criticality; CD-248).
# Copy of a list owned by another domain (same name and values, to be replaced by a reference to the owner's list):
# 02 Tax Form Type (Supplier Profile Tax Form on File).

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES (list name in 40, proposed shared list name, likely other users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("DORA ICT Service Type", "DORA ICT Service Type", ["14", "41"],
     "ITS (EU) 2024/2956 Annex III identifiers S01-S19 with the Annex labels verbatim (only the identifier is reported). "
     "Steward 40. 41 IT Service 'ICT Service Type' adopts the 40 values and labels (its labels differ: 'Cloud computing "
     "services: SaaS'); 14 ICT Third-Party Register Entry replaces its external format with this list."),
    ("DORA Substitutability", "DORA Substitutability", ["14"],
     "14 Substitutability has the same four concepts with shorter labels ('Highly Complex', 'Medium Complexity'); map one to one; steward 40."),
    ("Supplier Status", None, ["14"],
     "Report only: 14 Vendor Relationship Status mixes the relationship lifecycle with permission to be ordered from; keep separate."),
    ("Supplier Performance Rating", "Performance Rating", ["13", "14"],
     "Labels now identical to 14 Performance Rating, so the merge is direct; 13 Oversight Rating maps to it. Steward 40."),
    ("Third-Party Criticality Tier", "Third-Party Criticality Tier", ["14"],
     "Qualified to avoid the 41 'Criticality Tier' (application recovery tiers); 14 Vendor Strategic Tier may become a Derived copy (40) (SME)."),
    ("Payment Terms", "Payment Terms", ["05", "12", "19"],
     "Payment terms appear on partner agreements, fee invoices and payables; propose a shared list stewarded by 19."),
    ("Procurement Category", None, ["10", "19"],
     "Firm categories mapped to UNSPSC; 10 cost pools and 19 expense accounts may map to it for spend analytics."),
]
# List names qualified in this draft to avoid same-name collisions with different values elsewhere: Contract Pricing Model
# (01 Pricing Model), Sourcing Disqualification Reason (04), Invoice Match Status (06 Match Status), Outsourcing Notification
# Status (08 Notification Status), Purchase Requisition Status (20 Requisition Status, job requisitions), Third-Party
# Criticality Tier (41 Criticality Tier), DORA Substitutability (14 Substitutability), DORA ICT Service Type (41 ICT Service
# Type). No LOCAL_RENAMES are needed.

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Vendor / Supplier",
     "usages": [("40", "Supplier Profile", "Role profile of a 02 party the firm buys from"),
                ("14", "Data Vendor", "Data-vendor specialization of the supplier"),
                ("02", "Party Role Type", "No 'Supplier' value today")],
     "recommendation": "Enterprise term 'Supplier' (40); 'Data Vendor' stays as the 14 specialization; bare 'Vendor' is not used in new names."},
    {"term": "RFP",
     "usages": [("40", "Sourcing Event (type Sourcing RFP, SRCG-)", "Request the firm issues to suppliers"),
                ("03", "RFP Request (RFP-)", "Request the firm receives from clients and consultants")],
     "recommendation": "Always qualify: 'Sourcing RFP' (40) and 'Client RFP' (03)."},
    {"term": "Invoice",
     "usages": [("40", "Invoice Match Result", "Procurement match of an invoice line to an order line"),
                ("19", "Payable Invoice (APV-)", "Accounting record of a supplier invoice"),
                ("14", "Data Invoice (DINV-)", "Data-vendor invoice validated against the license")],
     "recommendation": "Extend the existing entry: the supplier invoice is 19 Payable Invoice; 40 holds only the match."},
    {"term": "Payment",
     "usages": [("40", "Supplier Remittance Detail", "Where a supplier is paid"),
                ("19", "Supplier Payment", "The payment itself")],
     "recommendation": "Extend the existing entry: 40 holds remit-to details, 19 the payment, 43 the paying bank account."},
    {"term": "Service Level / SLA",
     "usages": [("40", "Contracted Service Level", "Service levels in supplier contracts no specialization measures"),
                ("13", "Service Level Definition (SVL-)", "Servicing provider SLAs"),
                ("14", "Vendor Data SLA", "Data delivery and quality SLAs"),
                ("05", "Service Level Agreement", "Partner SLAs"),
                ("12", "Service Level", "Client service levels the firm gives")],
     "recommendation": "Qualify by side: supplier SLAs (40, 13, 14) vs partner and client SLAs (05, 12); 40 rows only where 13, 14 and 05 do not measure."},
    {"term": "Outsourcing",
     "usages": [("40", "Outsourcing Arrangement (OUTS-)", "Regulatory outsourcing register entry"),
                ("25", "Outsourced Trading Provider (party role)", "Trading delegated to a provider")],
     "recommendation": "Outsourcing Arrangement is the register record; 25 keeps the trading profile and is linked from the engagement."},
    {"term": "Category",
     "usages": [("40", "Procurement Category", "What is bought"), ("11", "Fund categories", "Peer categories of funds")],
     "recommendation": "Always qualify as 'Procurement Category'."},
    {"term": "Order",
     "usages": [("40", "Purchase Order (PURCH-)", "Firm purchase commitment"), ("25", "Trade Order (TORD-)", ""), ("29", "Fund Order (FNDO-)", "")],
     "recommendation": "Extend the existing entry: never use bare 'Order'."},
    {"term": "Register",
     "usages": [("40", "ICT Register of Information Entry; Outsourcing Arrangement", "Regulatory registers"),
                ("14", "ICT Third-Party Register Entry", "Data-vendor view of the 40 register"),
                ("37", "Third-Party Risk Assessment", "Enterprise TPRM register of assessments")],
     "recommendation": "'Register of information' and 'outsourcing register' are 40's; '37 third-party risk register' is the assessment record."},
    {"term": "Engagement",
     "usages": [("40", "Supplier Engagement (VENG-)", "What the firm buys from a supplier"),
                ("34", "Engagement (ENGM-)", "Stewardship engagement with an investee"),
                ("39", "Outside Counsel Engagement", "Law firm engagement on a matter")],
     "recommendation": "Bare 'engagement' resolves to 34 in ownership.ALIASES; always write 'Supplier Engagement'."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. PROPOSED_CHANGES to 01-36 (not applied; for the Stage 4 consolidation step)
# ---------------------------------------------------------------------------------------------------------------------
PROPOSED_CHANGES = [
    ("19", "Payables", "Payable Invoice", "Purchase Order Reference",
     "Re-type Text -> Reference (Purchase Order, 40); example 'PO 4500021877' -> 'PURCH-4500021877'; drop 'future reference to 40'.", "CD-260, CD-262"),
    ("19", "(overview)", "", "Core model / Scope",
     "Replace the 'future 40 Procurement' notes with 40 Purchase Order and Invoice Match Result.", "CD-262"),
    ("19", "Payables", "Payable Invoice Line", "Invoiced Quantity, Invoiced Unit Price (new)",
     "Add Invoiced Quantity (Decimal) and Invoiced Unit Price (Amount) to Payable Invoice Line, so 40 Invoice Match Result Unit Price Used becomes a Derived copy (19) and the match can be re-run from 19 data.", "CD-158, CD-260"),
    ("19", "Payables", "Supplier Payment", "Remit-To Account (new)",
     "Add Reference (Supplier Remittance Detail, 40) keyed by supplier party + remittance sequence, so each payment shows the call-back-verified account it was paid to (SME question 2).", "CD-260"),
    ("02", "Party Master", "(party tax attributes)", "Tax Form Type, Tax Identification Number",
     "Extend Applies To from 'Institutional Client, End Investor' to include the Supplier role, so one W-9 / W-8 and one masked TIN are held per party; 40 Supplier Profile Tax Form on File is then a Derived copy (02).", "CD-143, CD-260"),
    ("02", "(code list)", "Party Role Type", "",
     "Add 'Supplier', 'ICT Third-Party Service Provider', 'Subcontractor' and 'Staffing Agency'.", "CD-143, CD-260"),
    ("14", "Data Vendor Relationship", "Data Vendor", "Procurement Supplier ID",
     "Flag Derived copy (40) of Supplier Profile.ERP Supplier Number; example 'SUP-0045521' -> 'SUP 0045521' (SUP- is one letter from SUB-).", "CD-260"),
    ("14", "Vendor Risk & Resilience", "ICT Third-Party Register Entry", "(row grain)",
     "One 14 row (data license x reporting entity) summarizes the 40 ICT Register of Information Entries of the DLA's contract, found by translating DLA- to CTRCT- through 39 Typed Contract Link (Linked Data License Agreement); cardinality 40 entries n : 0..1 14 row.", "CD-261"),
    ("14", "Vendor Risk & Resilience", "ICT Third-Party Register Entry", "DORA In-Scope Indicator",
     "Derived copy (40): Y when at least one 40 ICT Register of Information Entry exists for the DLA's contract and the reporting entity.", "CD-261"),
    ("14", "Vendor Risk & Resilience", "ICT Third-Party Register Entry", "Reporting Financial Entity",
     "Derived copy (40) of ICT Register of Information Entry.Entity Making Use of ICT Service.", "CD-261"),
    ("14", "Vendor Risk & Resilience", "ICT Third-Party Register Entry", "Contractual Arrangement Reference",
     "Re-type to Reference (Contract, 39) with a CTRCT- example, read from 39 Typed Contract Link for the DLA (not a copy of the DLA- ID).", "CD-257, CD-261"),
    ("14", "Vendor Risk & Resilience", "ICT Third-Party Register Entry", "ICT Service Type",
     "Derived copy (40) of ICT Register Arrangement Header.Header ICT Service Type, coded with the DORA ICT Service Type list.", "CD-261"),
    ("14", "Vendor Risk & Resilience", "ICT Third-Party Register Entry", "Supports Critical or Important Function, Supported Functions",
     "Derived copy (40): Y / the list of Supported Function codes of the 40 entries of the contract and entity.", "CD-261"),
    ("14", "Vendor Risk & Resilience", "ICT Third-Party Register Entry", "Data Storage Locations",
     "Derived copy (40): union of Data at Rest Locations of the 40 entries.", "CD-261"),
    ("14", "Vendor Risk & Resilience", "ICT Third-Party Register Entry", "Material Subcontractors",
     "Derived copy (40): Subcontractor of the 40 Supply Chain Subcontractor rows of the contract.", "CD-261"),
    ("14", "Vendor Risk & Resilience", "ICT Third-Party Register Entry", "UK Important Business Service Mapping, Impact Tolerance Dependency Indicator",
     "No 40 source (the register holds DORA functions, not UK services): removed from the CD-261 derived-copy list; stays mastered in 14 until 37 Resilience Resource Mapping (Mapped Supplier Engagement) replaces it.", "CD-249, CD-261"),
    ("14", "Vendor Risk & Resilience", "Vendor Risk Assessment", "Substitutability, Exit Strategy Documented Indicator",
     "Derived copy (40) of ICT Register Arrangement Header Substitutability and Exit Plan Exists Indicator on ICT rows.", "CD-248, CD-261"),
    ("14", "Data Vendor Relationship", "Data Vendor", "Strategic Tier",
     "Consider a Derived copy (40) of Supplier Risk Tiering.Third-Party Criticality Tier, or rename to make clear it is a commercial tier (SME).", "CD-248"),
    ("20", "Employee Master", "Contingent Worker Detail", "Supplier Contract Reference",
     "Re-type Text -> Reference (Purchase Order, 40) where workers are bought on POs or SOWs, else Reference (Contract, 39) (SME question 6).", "CD-257, CD-260"),
    ("37", "Operational Resilience & Continuity", "Critical or Important Function", "(object scope)",
     "Widen to a Business Function register (DORA B_06.01: every function an ICT service supports) with a Critical or Important Indicator and keep 'CIF nn' codes; until then 40 register entries exist only for designated critical or important functions.", "CD-249, CD-261"),
    ("39", "Contract Repository", "Contract Key Date", "Notifying Side (new)",
     "Add which side (firm or counterparty) a Termination Notice Deadline's Notice Period Days applies to, so 40 Entity Notice Period and Provider Notice Period can be derived.", "CD-257"),
    ("39", "(code list)", "Governing Law", "",
     "Carry the ISO 3166-1 country of each Governing Law value (New York -> US, England and Wales -> GB) so the 40 register's Governing Law Country is a deterministic derivation.", "CD-257, CD-261"),
    ("41", "IT Service & Incident Management", "IT Service", "ICT Service Type",
     "Adopt the 40 DORA ICT Service Type list (S01-S19 identifiers with the Annex III labels).", "CD-268"),
    ("13", "", "Servicing Provider Engagement", "",
     "No copy; referenced from 40 Supplier Engagement (Specialized Servicing Provider Engagement); its oversight reviews are the only performance review of those engagements.", "CD-260"),
    ("28", "", "Custody Provider Profile", "",
     "No copy; referenced from 40 Supplier Engagement (Specialized Custody Provider Profile); Custodian Service Reviews are the only performance review of those engagements.", "CD-260"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Ownership resolver: 'Reference (Data Vendor, 14)', '(Servicing Provider Engagement, 13)', '(Custody Provider Profile, 28)', "
    "'(Approved Counterparty Profile, 25)' and '(Product Party Role, 01)' use PTY- or PRD- examples and are forced in "
    "enrich_40 OWNERSHIP_OVERRIDES. When VENG-, SRCG-, PREQ-, PURCH- and OUTS- are registered, references to them resolve by "
    "prefix; until then they carry ', 40' in the type. Add aliases 'supplier engagement', 'purchase order', 'outsourcing "
    "arrangement' -> 40; keep bare 'engagement' -> 34.",
    "Sibling names used, checked against the Stage 4 modules: 37 Critical or Important Function ('CIF 03'), Important "
    "Business Service ('IBS 07'), Third-Party Risk Assessment and Resilience Resource Mapping (37 holds the references to "
    "40); 38 AML Case (holds the only link to Supplier Onboarding Case); 39 Contract (CTRCT-), Contract Effective Date, "
    "Contract Expiry Date, Governing Law, Contract Key Date, Typed Contract Link; 41 IT Service ('SVC 0118'), Application "
    "(APPL-00412); 16 Service Arrangement (PSVA-); 44 Facility Work Order (Work Order Purchase Order).",
    "39 Typed Contract Link allows one link per contract: a 14 data license or 44 lease therefore carries no 40 Supplier "
    "Contract Profile; its commercial terms stay in 14 or 44. If procurement needs spend commitments on those contracts, "
    "39 should allow a second link of type 'Supplier Contract Profile (40)' (SME).",
    "25 holds the outsourced trading provider as an attribute of Best Execution Policy, not as an Approved Counterparty "
    "Profile role; the draft link from Supplier Engagement was dropped. The engaged supplier is the same 02 party.",
    "CD-248: Supplier Risk Tiering holds the inherent tier only; no residual rating is held in 40, and 37 Third-Party Risk "
    "Assessment should hold no tier. 37 Resilience Resource Mapping reads 40 Supplier Engagement (VENG-).",
    "CD-249 / CD-268 (program lead ruling): the DORA register of information is mastered in 40; 14 rows are the data-vendor "
    "view; 41 holds no register object. Critical or Important Outsourcing Indicator is a Derived copy (37).",
    "CD-257: 40 holds no contract date, party or clause; the register's start and end dates are Derived copies (39) of "
    "Contract.Contract Effective Date and Contract Expiry Date, notice periods of Contract Key Date.Notice Period Days, and "
    "Governing Law Country is derived from Contract.Governing Law through a jurisdiction-to-country map. 39 Typed Contract Link should list 'Supplier Contract "
    "Profile (40)' as a typed record.",
    "CD-158: 40 holds no invoice header, tax or payment amounts. Invoice Match Result is keyed by the 19 invoice and its line "
    "number (19 Payable Invoice Line has no ID of its own) and holds the matched quantity, matched amount, unit price used and "
    "tolerance it applied; Supplier Spend Summary Invoiced and Paid Amount are Derived copies (19), credit notes signed negative.",
    "DORA register grain (program lead decision 1): B_02.01 contract fields on Supplier Contract Profile (contract grain), "
    "B_07.01 assessment on ICT Register Arrangement Header (contract x ICT service type), B_02.02 rows on ICT Register of "
    "Information Entry (entity x contract x ICT service type x function), B_05.02 on Supply Chain Subcontractor.",
    "Rule 4 (firm purchases only): fund-paid provider fees (27 Fund Expense) and private-fund deal costs (30) are never 40 "
    "purchase orders; the engagement and outsourcing records still apply where the firm oversees the provider.",
    "Stage 4 siblings: 43 pays through 19 from Corporate Bank Accounts (BKAC-); 19 Supplier Payment 'Paying Bank Account' "
    "should reference 43. 44 facilities and travel suppliers are 40 suppliers; 44 facilities service contracts are 39 "
    "contracts with a 40 Supplier Contract Profile (leases are typed 44 Lease); 44 Facility Work Order references the 40 "
    "Purchase Order; 44 Expense Reports are paid outside purchase orders.",
    "Code list count: 32 local lists against a brief target of 22 to 28; the excess is seven DORA register enumerations "
    "(DORA ICT Service Type, DORA Substitutability, Reintegration Possibility, DORA Assessment Level, Level of Reliance, "
    "Contractual Arrangement Type, Arrangement Termination Reason) and Payment Terms, which are candidates for sharing above.",
]
