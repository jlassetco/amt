"""Consolidation proposals from Data Domain 41 - Technology & Information Security (Stage 4 draft v0.1, 2026-10-06).

Proposal fragment only: the builder does not read it. The Stage 4 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Format follows CONTRACT.md in this folder. Decisions implemented: CD-263 to CD-270
and the 41 part of CD-282 (proposals_stage4_b.py), aligned with CD-245 and CD-249 (proposals_stage4_a.py) and with the
program lead rulings of 2026-10-06 (DORA major-incident classification and authority reports on 37; the register of
information in 40; IT policies are rows in the 38 Policy library). Nothing here edits 01-40.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones. None needed.
#    41 uses only the reserved APPL-, CFGI-, ACSG-, ITINC-, VULN-, CHRQ-, RLSE- and PRJT- (CD-282). Records without a
#    reserved prefix are keyed by grain or by a firm code written without a hyphenated stem, so the resolver never reads
#    them as prefixes: interfaces 'IFC 00412-0031', IT services 'SVC 0118', problems 'PRB 2026-00318', access review
#    campaigns 'UAR 2026Q3-07' (not ARC-, which is 08's archive item), tests 'SRT 2026-0031', change programs by name code
#    (not PGM-, which is 05's partner program), digital identities by directory object GUID.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# Key formats of the reserved prefixes, as 41 issues them (decisions.PREFIX_FORMATS tuple format); unchanged from the brief.
KEY_FORMATS = [
    ("APPL-", "41", "APPL-<sequence, 5 digits>", "APPL-00412"),
    ("CFGI-", "41", "CFGI-<sequence, 7 digits>", "CFGI-0041877"),
    ("ACSG-", "41", "ACSG-<year>-<sequence, 8 digits>", "ACSG-2026-00418812"),
    ("ITINC-", "41", "ITINC-<year>-<sequence, 6 digits>", "ITINC-2026-004512"),
    ("VULN-", "41", "VULN-<year>-<sequence, 6 digits>", "VULN-2026-018832"),
    ("CHRQ-", "41", "CHRQ-<year>-<sequence, 6 digits>", "CHRQ-2026-007731"),
    ("RLSE-", "41", "RLSE-<application number, 5 digits>-<sequence, 4 digits>", "RLSE-00412-0087"),
    ("PRJT-", "41", "PRJT-<start year>-<sequence, 4 digits>", "PRJT-2026-0114"),
]

# Firm codes that other domains reference but that take no new prefix (review E-1; program lead decision 4). Written with a
# space after a three-letter stem so the ownership resolver never reads them as prefixes. (code, owner, format, example, users)
FIRM_CODE_FORMATS = [
    ("SVC", "41", "SVC <sequence, 4 digits>", "SVC 0118", "IT Service Code: cited by 40 ICT Register of Information Entry.Supported IT Services, 14 ICT Third-Party Register Entry (proposed) and 37 Resilience Resource Mapping; 40 and 37 should use this format in their examples (40 currently shows 'Enterprise data platform service')."),
    ("SRT", "41", "SRT <year>-<sequence, 4 digits>", "SRT 2026-0031", "Security & Resilience Test Code: cited by 37 Resilience Test for ICT DR results."),
    ("IFC", "41", "IFC <application number, 5 digits>-<sequence, 4 digits>", "IFC 00412-0031", "Application Interface Code; optional reference from 29 Order Interface Session."),
    ("PRB", "41", "PRB <year>-<sequence, 5 digits>", "PRB 2026-00318", "Problem Code (41 only)."),
    ("UAR", "41", "UAR <year>Q<quarter>-<sequence, 2 digits>", "UAR 2026Q3-07", "Access Review Campaign Code (41 only)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local 41 lists that are verbatim copies of enterprise shared lists.
#    (shared list name, local list name in 41, where 41 uses it)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    ("Record Status", "Record Status", "Application Interface, Configuration Item, IT Service, Change Program status"),
    ("Approval Status", "Approval Status", "Change Approval"),
    ("Severity", "Severity", "Vulnerability Finding severity (no separate Vulnerability Severity list)"),
    ("Risk Rating", "Risk Rating", "Change Request risk ('Prohibited' unused)"),
    ("RAG Status", "RAG Status", "Project Status Report overall, schedule, budget, scope and risk"),
    ("Frequency", "Frequency", "Application Interface schedule"),
    ("Message Standard", "Message Standard", "Application Interface message standard"),
    ("Information Classification", "Information Classification", "Application Access Role data classification ceiling (21 stewards, CD-148 / CD-270)"),
    ("Business Line", "Business Line", "Application Capability Mapping, Change Program"),
    ("Case Status", "Case Status", "Problem Record status only"),
    ("Business Domain", "Business Domain", "Project impacted Data Domains"),
]
# Value maps: every local value is the shared label one to one. Business Domain: the 23 current values map one to one; the
# local copy adds '22 Market Data & Pricing' ... '44 Workplace & Corporate Services' as proposed additions (CD-282 asks for
# 37-44; values 22-36 are also missing from the shared list today and are proposed with them). Regulator is not used: the
# authority reports are 37's.

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: local 41 lists that look like enterprise lists.
#    (list name in 41, proposed shared list name, likely other users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("ICT Service Type", "ICT Service Type", ["14", "40", "41"],
     "Program lead decision 1 (review F-1, High). One shared list, steward 41, holding the codes S01-S19 with the Annex III "
     "labels of Implementing Regulation (EU) 2024/2956 verbatim (official spelling 'licencing' kept), verified on EUR-Lex "
     "2026-10-06: S01 ICT project management; S02 ICT Development; S03 ICT help desk and first level support; S04 ICT security "
     "management services; S05 Provision of data; S06 Data analysis; S07 ICT, facilities and hosting services (excluding Cloud "
     "services); S08 Computation; S09 Non-Cloud Data storage; S10 Telecom carrier; S11 Network infrastructure; S12 Hardware and "
     "physical devices; S13 Software licencing (excluding SaaS); S14 ICT operation management (including maintenance); S15 ICT "
     "Consulting; S16 ICT Risk management; S17 Cloud services: IaaS; S18 Cloud services: PaaS; S19 Cloud services: SaaS. "
     "Shared codes S01..S19 (label = Annex text). 40 must adopt it at consolidation (40 is adding the codes; its labels 'Cloud "
     "Services: SaaS' and 'ICT Facilities and Hosting Services (excluding Cloud)' map to S19 and S07); 14 ICT Third-Party "
     "Register Entry ICT Service Type (example 'Data analysis / data provision service') maps to S06 or S05."),
    ("Environment", "Environment", ["21", "41"],
     "CD-282 candidate. 21 has no Environment list in its module today; the candidate applies if 21 data assets or data "
     "products record an environment. Steward 41."),
    ("Root Cause Category", "Root Cause Category", ["21", "37", "41"],
     "41 incidents and problems (values made exclusive after review: Human Error vs Malicious Action, social engineering under "
     "Malicious Action); 37 Operational Incident root cause; 21 DQ Issue Root Cause overlaps on 'Source System Defect' "
     "/ 'Software Defect'. Recommend a shared technical cause list stewarded by 41 that 37 maps its cause categories to."),
    ("Test Outcome", None, ["37", "41"],
     "37 Resilience Test outcome should use the same values when it reads 41 DR results."),
    ("Ownership Role", "Application Ownership Role", ["41"],
     "Keep local; rename at consolidation if any other domain introduces an 'Ownership Role' list (21 Data Ownership "
     "Assignment uses governance roles, a different concept)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS noticed (decisions.py format). Incident, Application, Project / Program, Access / Entitlement, Asset
#    and Release are already in proposals_stage4_b.py; the entries below add usages found in the draft.
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Service",
     "usages": [("41", "IT Service", "Business or technical service delivered by technology"),
                ("37", "Important Business Service", "FCA SYSC 15A service to clients or markets"),
                ("12", "Client Service Request / Client service model", "Institutional client servicing"),
                ("13", "Shareholder Service Request", "Investor servicing")],
     "recommendation": "Never 'Service' bare: 'IT Service' (41), 'Important Business Service' (37), 'Client Service' (12), "
                       "'Shareholder Service' (13). The 37 mapping links an important business service to 41 applications, not to "
                       "IT services, unless 37 chooses otherwise (SME)."},
    {"term": "Interface",
     "usages": [("41", "Application Interface", "Technical connection between applications or to an external endpoint"),
                ("29", "Order Interface Session", "Business cycle of fund orders exchanged over a connection")],
     "recommendation": "'Application Interface' (41) is the technical link; 29 keeps the session as the business record. 29 may "
                       "add a Reference (Application Interface, 41) by Interface Code (optional)."},
    {"term": "Change",
     "usages": [("41", "Change Request (CHRQ-)", "ITIL change to applications or configuration items"),
                ("41", "Change Program", "Group of projects"),
                ("36", "Product Change Initiative (LCHG-)", "Change to the product range"),
                ("38", "Regulatory Change Item (REGCH-)", "Change in regulation")],
     "recommendation": "Qualify: 'IT Change Request' in definitions (41), 'Product Change Initiative' (36), 'Regulatory Change "
                       "Item' (38). A product launch is delivered by a 41 Project through Project Scope Link, never by a Change "
                       "Request."},
    {"term": "Test",
     "usages": [("41", "Security & Resilience Test", "Penetration, TLPT, DR failover, red team, tabletop"),
                ("37", "Resilience Test / Control Test", "Scenario test against impact tolerance; control testing"),
                ("16", "Nondiscrimination Test", "Plan compliance testing")],
     "recommendation": "Always qualify; 37 Resilience Test references the 41 test for ICT DR results (CD-249, CD-270)."},
    {"term": "Identity",
     "usages": [("41", "Digital Identity", "Directory account of a person or service"),
                ("04", "Digital identity and web / email engagement", "Visitor identity for marketing (VIS-)"),
                ("02", "Party identity attributes", "Legal identity of a person or organization")],
     "recommendation": "'Digital Identity' is the 41 directory account; 04 uses 'Web Visitor'; 02 'Party'."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. VALUE_PROPOSALS: changes 41 asks of other domains (domain, object / attribute or list, proposed change, basis).
#    Every 'System', 'Source System' and 'Book of Record System' identifier found in 01-36 is listed (scan of 2026-10-06).
# ---------------------------------------------------------------------------------------------------------------------
VALUE_PROPOSALS = [
    # ---- CD-263: system references resolve to Application (APPL-)
    ("21", "Data Asset.Hosting System", "Re-type Code ('System') -> Reference (Application, 41), example APPL-00521.", "CD-263 (closes CD-160's deferred item)."),
    ("21", "System of Record Designation.Designated System", "Re-type Code ('System') -> Reference (Application, 41), example APPL-00412. Stays the only authority record (no flag on 41 Application).", "CD-263."),
    ("21", "Record Governance Metadata.System of Record; Record Governance Metadata.Source System", "Re-type Code ('System') -> Reference (Application, 41). Source System Record ID stays an identifier.", "CD-263."),
    ("21", "list System", "Retire the interim list once the four attributes above are re-typed; map its 19 values to APPL- rows when loading the inventory ('Vendor Platform' and 'Other' need an application each).", "CD-263."),
    ("21", "AI Use Case 'runs on' Model [37] relationship; overview 'application inventory (41, not yet built)'", "Add the relationship 'AI Use Case is served by Application [41] via AI System Use Case Link'; update the overview text. 21 adds no APPL- attribute.", "CD-269."),
    ("18", "Portfolio.Book of Record System", "Re-type Code (Firm-defined) -> Reference (Application, 41), example APPL-00387; drop the note 'future 41'.", "CD-263."),
    ("18", "Portfolio Transaction Event.Event Source System", "Re-type Code (Firm-defined) -> Reference (Application, 41).", "CD-263."),
    ("09", "Code Mapping.Source System; Reference Data Subscription.Subscribing System", "Re-type Code (Firm-defined) -> Reference (Application, 41); vendor feeds are Applications of hosting model Provider-Hosted or SaaS.", "CD-263."),
    ("01", "System Cross-Reference.Source System", "Re-type Code (Firm-defined) -> Reference (Application, 41); provider systems (fund administrator, TA) are Applications with hosting model 'Provider-Hosted' (CD-147). Source System Code stays an identifier.", "CD-263."),
    ("02", "Record Metadata.Source System", "Re-type Code (Firm-defined) -> Reference (Application, 41) (object excluded from outputs, §11; apply in the content module).", "CD-263."),
    ("01, 02, 03, 04, 05, 06, 07, 08, 09, 10, 11, 12, 13, 14, 15, 16", "Record Metadata.System of Record (excluded objects)", "Re-type Code (Firm-defined) -> Reference (Application, 41) in each module, or retire with the objects when 21 Record Governance Metadata replaces them.", "CD-263; Conventions §11."),
    ("03", "Activity Capture.Activity Source System (list Activity Source System)", "Optional: re-type to Reference (Application, 41); Zoom, Teams, Webex, CRM and mailbox capture tools are Applications of type Business Application / SaaS.", "CD-263 ('may follow')."),
    ("05", "Networking Setup.Sub-Accounting Platform; 30 Private Fund Profile.Private Fund Platform", "Keep as vendor-product codes (they name the provider's product, not the firm's instance); optional Reference (Application, 41) where the firm inventories the platform.", "CD-263; SME question 2."),
    ("28", "overview 'SWIFT connectivity (41)'", "Replace with 'SWIFT connectivity: 41 Application Interface of mechanism SWIFT Network (message standard ISO 15022 / ISO 20022)'.", "CD-263."),
    # ---- CD-264
    ("14", "Consuming Application (DAPP-)", "Option A: key by Reference (Application, 41) (APPL-); retire DAPP-; Application Name becomes a Derived copy (41) of Application.Application Name; Usage Mode, Non-Display Use Types, External Output Indicator and Declared to Vendor Indicator stay 14. Re-key the examples of Dataset Consumption.Consuming Application and Entitlement.Entitled Application to APPL-.", "CD-264 (SME question 10)."),
    ("04", "Marketing System", "Add 'Inventoried Application' Reference (Application, 41); System Name becomes a Derived copy (41); System Category stays 04's martech classification.", "CD-264."),
    # ---- CD-265
    ("20", "overview 'identity and access entitlements (41)'", "Replace with '41 Digital Identity and System Access Grant (a grant references the 20 lifecycle event; 20 holds no access record)'.", "CD-265."),
    ("14", "Entitlement", "No change: license counting stays 14; the 41 System Access Grant references ENT- (Provisioned Data Entitlement). 14 holds no ACSG- reference.", "CD-265."),
    # ---- CD-266
    ("37", "Operational Incident (source references)", "Cite 'Reference (IT Incident, 41)' with example ITINC-2026-004512 (the 37 brief expected INC-). It is the only link between the two records.", "CD-266, CD-245."),
    ("37", "Incident Regulatory Notification / DORA classification", "Read the technical data points from the 41 IT Incident: Incident Occurrence Timestamp and Occurrence Time Estimated Indicator (start of the DORA duration criterion), Incident Detected Timestamp, Service Restored Timestamp, Service Downtime Minutes, Data Impact Types, Incident Root Cause Category, Affected Applications, IT Services and Legal Entities. 41 holds no classification or report.", "CD-245, program lead ruling."),
    ("42", "Communications Issue", "Cite 'Reference (IT Incident, 41)', example ITINC-2026-004512, for cyber-triggered issues.", "CD-272."),
    ("13 / 12", "Shareholder Communication / client communication (Reg S-P customer notices)", "Add 'Related IT Incident' Reference (IT Incident, 41), example ITINC-2026-004512, on notices sent under Regulation S-P, so the 41 determination and the notice join (Reg S-P recordkeeping); 41 holds no notice reference. The 41 relationship 'notifies customers of' depends on it.", "CD-266; review G-2."),
    # ---- CD-267
    ("36", "Product Change Initiative.Launch Project Code", "Make a Derived copy (41) of Project.Project ID read through the 41 Project Scope Link whose Delivered Change Initiative is this LCHG-; example 'PRJ 2026 114' -> 'PRJT-2026-0114'; replace the note 'Future owner 41 Change & Project Portfolio'. Keep data type Text (a derived copy cannot be a Reference).", "CD-267, CD-239."),
    ("38", "Regulatory Change Impact.Implementing Project", "38 is dropping the attribute (program lead decision 3); the link is 41 Project Scope Link (Delivered Regulatory Change Item). If 38 needs the project ID, hold it as Text Derived copy (41).", "CD-267; review A-1."),
    ("21", "Data Product / Data Quality Issue", "No project reference; the link is 41 Project Scope Link.", "CD-267."),
    # ---- CD-268
    ("40", "ICT Register of Information Entry", "Add 'Supported IT Service' Reference (IT Service, 41) (example 'SVC 0118') and, where needed, 'Supported Applications' Reference (Application, 41), in place of free-text service descriptions; the ICT service type is a Derived copy (41) of IT Service.ICT Service Type on rows that cite an IT service.", "CD-268, CD-261."),
    ("14", "ICT Third-Party Register Entry.ICT Service Type; .Supported Functions", "Add 'Supported IT Service' Reference (IT Service, 41); ICT Service Type joins the shared ICT Service Type list.", "CD-268."),
    # ---- CD-249 / CD-270
    ("37", "Resilience Resource Mapping (application resources); Resilience Test (DR results)", "Application rows reference APPL-; the DR test result references the 41 Security & Resilience Test by Test Code ('SRT 2026-0031').", "CD-249, CD-270."),
    ("37", "Model Inventory Entry", "No change: 41 AI System Profile.Deployed Model references MODEL-; 21 AI Use Case Model Name re-types to 37 per CD-246.", "CD-246, CD-269."),
    ("37", "Risk Issue (source)", "The VULN- to ISSUE- link is held once, on 37: the Risk Issue's typed source (source type 'Vulnerability Finding (41)', Reference (Vulnerability Finding, 41), example VULN-2026-018832); 37 drops its text source field for it. 41 holds no ISSUE- reference.", "CD-270; program lead decision 3."),
    ("37", "Resilience Resource Mapping / Resilience Test examples", "Use the 41 firm code formats 'SVC 0118' and 'SRT 2026-0031' (FIRM_CODE_FORMATS).", "Program lead decision 4."),
    ("40", "ICT Register of Information Entry.Supported IT Services (example); ICT Service Type list", "Use 'SVC 0118' as the example; adopt the shared ICT Service Type list (S01-S19, Annex III labels) at consolidation.", "Program lead decisions 1 and 4."),
    ("21", "AI Use Case.EU AI Act Operator Roles", "No change: 21 stays the only holder of the firm's operator roles; 41 AI System Profile holds none (review A-3).", "CD-269."),
    ("43", "Insurance Claim.Related IT Incident", "No change: the link is held on 43 (ITINC-).", "Review G-3."),
    ("39", "Legal Hold Scope (application)", "Cite Reference (Application, 41), example APPL-00521.", "CD-263."),
    ("38", "Policy", "41 references Policy (POLCY-) for the access control and vulnerability management standards; IT and security policies are rows of policy domain 'Technology' in the 38 library. 41 holds no policy object.", "Program lead ruling."),
    # ---- CD-143 / CD-282 list values
    ("02", "list Party Role Type", "Add values 'ICT Service Provider' and 'Security Testing Provider'.", "CD-143, CD-282."),
    ("09", "shared list Business Domain", "Add values 22-44 ('22 Market Data & Pricing' ... '44 Workplace & Corporate Services').", "CD-282 (37-44); 22-36 also missing."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Deviations from the brief (all recorded in Source_Notes §2): (1) Release holds no 'linked changes' list; the link is held "
    "once, on Change Request.Implemented Release. (2) Security categorization is three attributes (FIPS 199 confidentiality, "
    "integrity and availability impact levels) with a local Security Impact Level list. (3) AI System Profile holds no "
    "'general-purpose model basis' attribute (a property of the 37 model, already on 21 AI Use Case) and, after review, no "
    "operator role (21's); the deployed models are dated rows of AI System Model Deployment. (4) Access Review Campaign scope is the "
    "reviewed application plus a privileged-only indicator, not a scope list. (5) Business Domain is used on Project for "
    "impacted Data Domains. (6) Local lists added beyond the brief: Security Impact Level, DR Strategy, Identity Status, IT "
    "Service Category, IT Incident Status, Detection Source, Data Impact Type, Threat Actor Category, Delivery Methodology, "
    "Test Outcome, Project Status, Change Approval Step, Interface Mechanism (replacing Interface Type); EU AI Act Operator Role was removed after review.",
    "Row rules: none. 41 holds no Derived copy; every cross-domain fact is a typed reference. Criticality is held only on "
    "Application, recovery tier only on Application Recovery Profile, incident timing only on IT Incident.",
    "One-direction links held here: APPL- -> AIU- (AI System Use Case Link), ACSG- -> ELE- (granting and revoking) and ENT-, "
    "PRJT- -> LCHG- / DP- / DQI- / APPL- / REGCH- (Project Scope Link), AI system -> MODEL- (AI System Model Deployment). "
    "Links held by others: 37 OPINC- -> ITINC-, 37 ISSUE- -> VULN-, 37 Resilience Test -> 41 test, 13 / 12 notices -> ITINC- "
    "(proposed), 43 Insurance Claim -> ITINC-, 37 mapping -> APPL-, 40 / 14 register -> IT Service, 42 CRIS- -> ITINC-, 21 "
    "designation -> APPL-, 39 Legal Hold Scope -> APPL-.",
    "Sibling object names used, checked against the 37-39 drafts by the reviewer: 37 Model Inventory Entry (MODEL-); 38 Policy "
    "(POLCY-), Regulatory Change Item (REGCH-); 39 Contract (CTRCT-). Examples follow proposals_stage4_a.py formats.",
    "Firm codes without a prefix are published in FIRM_CODE_FORMATS (IT Service Code and Test Code are referenced by 37, 40 "
    "and 14); none is requested as a prefix (the brief allows only eight new prefixes).",
    "DORA 'major incident' vs ITIL 'major incident': IT Incident.Major Incident Indicator is the ITIL procedure flag only; the "
    "DORA classification is held on 37. The definition says so; keep both names distinct in the glossary.",
]
