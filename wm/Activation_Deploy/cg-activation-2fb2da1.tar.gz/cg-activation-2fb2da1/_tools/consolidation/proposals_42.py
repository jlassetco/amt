"""Consolidation proposals from Data Domain 42 - Corporate Communications & Public Affairs (Stage 4 draft v0.1, 2026-10-06).

Proposal fragment only: the builder does not read it. The Stage 4 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Format follows CONTRACT.md in this folder. Decisions implemented: CD-271 (option A,
MOVE, per the program lead's ruling), CD-272, CD-273 and the 42 part of CD-282 in proposals_stage4_b.py. Nothing here
edits 02, 04, 08, 11, 12, 13 or any sibling module.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones.
#    One rename, ruled by the program lead on 2026-10-06: the reserved COVG- (media coverage item) is an anagram of
#    39's reserved CGOV- (corporate governing body), so 42 uses MCOV- ("media coverage"). The brief had rejected MCOV-
#    as one letter from RCOV- (23 research coverage assignment); the program lead accepted that near-collision because
#    the leading M / R differ in meaning and the anagram is the worse confusion. NEWS-, MEDQ-, CRIS-, PUBP- and LOBR- are
#    used as reserved. BRD- is the transferred 04 prefix (CD-271), format unchanged.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = [
    ("MCOV-", "Media coverage item", "42", "Proposed",
     "Replaces the reserved COVG- (anagram of CGOV-, 39), program lead ruling 2026-10-06. One letter from RCOV- (23); "
     "accepted. Withdraw COVG- from the CD-282 reservation list."),
]

PREFIX_TRANSFERS = [
    ("BRD-", "Brand", "04", "42", "CD-271 option A (MOVE, program lead ruling); the 04 format BRD-<3 digits> is kept."),
]

# Key formats of the prefixes 42 issues (decisions.PREFIX_FORMATS tuple format).
KEY_FORMATS = [
    ("BRD-", "42", "BRD-<sequence, 3 digits> (format kept from 04)", "BRD-003"),
    ("NEWS-", "42", "NEWS-<year>-<sequence, 4 digits>", "NEWS-2026-0042"),
    ("MEDQ-", "42", "MEDQ-<year>-<sequence, 5 digits>", "MEDQ-2026-00318"),
    ("MCOV-", "42", "MCOV-<publication date YYYYMMDD>-<sequence, 5 digits>", "MCOV-20261006-00012"),
    ("CRIS-", "42", "CRIS-<year>-<sequence, 3 digits>", "CRIS-2026-007"),
    ("PUBP-", "42", "PUBP-<sequence, 4 digits>; the version is a separate attribute", "PUBP-0031"),
    ("LOBR-", "42", "LOBR-<report type code: LD2, LD203, EUTR, STATE>-<period: 2026Q3, 2026H1 or 2026>-<registration sequence, 3 digits>-"
     "<filer: R00 for the registrant, L<lobbyist sequence, 2 digits> for an LD-203 filed by a lobbyist>-<amendment sequence, 2 digits, 00 = original>",
     "LOBR-LD2-2026Q3-001-R00-00"),
]

# Firm-defined keys without a prefix (review finding D; program lead decision 3), for grain-keyed objects that others reference.
GRAIN_KEY_FORMATS = [
    ("Corporate Publication", "42", "<publication type code>/<publishing entity number, 4 digits>/<period end year>/<version>", "MSA/0021/2025/1"),
    ("Corporate Event", "42", "CE/<year>/<sequence, 4 digits>", "CE/2026/0031"),
    ("Government Official Contact", "42", "GOC/<year>/<sequence, 4 digits>", "GOC/2026/0118"),
    ("Crisis Communication Plan", "42", "CCP <sequence, 3 digits>; the version is separate", "CCP 004"),
    ("Internal Communication", "42", "<year>-<sequence, 5 digits> (intranet system key)", "2026-00412"),
]
# Lobbying Registration is keyed by the regime's own number (LDA Senate / House ID, EU TR identification number); the other
# objects by their grain (enrich_42.GRAIN).

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local 42 lists that are verbatim copies of enterprise shared lists.
#    (shared list name, local list name in 42, where 42 uses it)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    ("Case Status", "Case Status", "Media Inquiry status, Communications Issue status (workflow only; Issue Level is separate)"),
    ("Record Status", "Record Status", "Crisis Communication Plan status"),
    ("Sentiment", "Sentiment", "Media Coverage Item sentiment"),
    ("Regulator", "Regulator", "Consultation Response consulting regulator"),
    ("Data Basis", "Data Basis", "Reputation Measurement data basis"),
    ("Delivery Method", "Delivery Method", "Issue Statement delivery methods"),
]
# Value maps: every local value is the shared label one to one (e.g. 'Approved with Conditions' -> APPROVED_WITH_CONDITIONS,
# 'Reported / Actual' -> REPORTED). Business Line, Frequency, Approval Status, Information Classification and Social Platform,
# named in brief §8, are not used after trimming to the target size and applying the review (social mentions are 04's). Moved lists (CD-271, names and values
# unchanged): Brand Level, Brand Status (04 removes them at merge).

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: local 42 lists that look like enterprise lists.
#    (list name in 42, proposed shared list name, likely other users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Award Result", "Award Outcome", ["11", "42"],
     "CD-282 candidate. 42 Award Result holds the four 11 Award Outcome values verbatim (Winner, Highly Commended, Shortlisted / "
     "Finalist, Not Placed). Steward 11; 42 joins as a member with a one-to-one value map."),
    ("Stakeholder Group", "Stakeholder Group", ["34", "37", "42"],
     "Stakeholder groups for issues, statements, events and reputation surveys; 34 stewardship and 37 incident notifications "
     "may need the same list. Steward 42."),
    ("Policy Topic", None, ["38", "42"],
     "38 Regulatory Change Item may classify topics the same way; keep local until 38 is drafted."),
    ("EU TR Cost Band", None, ["38", "42"],
     "Cost bands of the EU Transparency Register form; external list, steward 42. LDA general issue area codes and the LDA "
     "houses and agencies list are now cited as external formats (review finding F), not local lists."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS noticed (decisions.py format). Release, Brand, Event, Communication, Position, Issue are already in
#    proposals_stage4_b.py; the entries below add terms or usages.
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Coverage",
     "usages": [("42", "Media Coverage Item (MCOV-)", "Article or post mentioning the firm"),
                ("23", "Research Coverage Assignment (RCOV-)", "Analyst coverage of an issuer"),
                ("07", "Coverage Assignment (CVA-)", "Salesperson coverage of a party"),
                ("43", "Insurance Coverage Layer", "Insurance policy layer")],
     "recommendation": "Always qualify: 'Media Coverage' (42), 'Research Coverage' (23), 'Sales Coverage' (07), 'Insurance Coverage' (43)."},
    {"term": "Statement",
     "usages": [("42", "Issue Statement; Modern Slavery Statement", "Public or stakeholder message; statutory publication"),
                ("13", "Statement (STMT-)", "Account statement"),
                ("19", "Financial Statement", "Financial reporting"),
                ("34", "PAI Statement", "SFDR entity statement")],
     "recommendation": "Qualify: 'Issue Statement' and named statutory publications (42), 'Account Statement' (13), 'Financial Statement' (19)."},
    {"term": "Publication",
     "usages": [("42", "Corporate Publication", "Statutory or voluntary corporate report"),
                ("23", "Research Publication (RPUB-)", "Investment research note")],
     "recommendation": "Qualify: 'Corporate Publication' (42), 'Research Publication' (23)."},
    {"term": "Engagement",
     "usages": [("42", "Internal Communication Engagement", "Aggregate staff readership"),
                ("34", "Engagement (ENGM-)", "Investee engagement"),
                ("04", "Engagement Event", "Digital engagement of a person"),
                ("40", "Supplier Engagement (VENG-)", "Contracted supplier relationship")],
     "recommendation": "Qualify every usage; 42 uses 'Internal Communication Engagement' only."},
    {"term": "Registration",
     "usages": [("42", "Lobbying Registration", "Registration under a lobbying disclosure regime"),
                ("01", "Product Registration", "Registration of a product for sale"),
                ("08", "Individual Registration (LIC-)", "Sales-staff license")],
     "recommendation": "Qualify: 'Lobbying Registration' (42)."},
    {"term": "Authorization",
     "usages": [("42", "Brand Use Authorization; Spokesperson Authorization", "Permission to use a brand or speak"),
                ("38", "Entity Authorization (AUTH-)", "Regulatory permission of an entity")],
     "recommendation": "Qualify; never 'Authorization' bare."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "CD-271 (MOVE, program lead ruling): 42 Brand carries the 04 Brand's six attribute tuples verbatim except the CDE flag on Brand Level (Brand ID, Brand Name, "
    "Brand Level, Parent Brand, Brand Status, Brand Permitted Jurisdictions) and the lists Brand Level and Brand Status with "
    "identical values (verified programmatically against content_04 on 2026-10-06). content_04 was not edited. At merge: remove "
    "04 'Brand' (family 'Brand & Messaging', group 'Brand Architecture'), the lists Brand Level and Brand Status, the 04 "
    "relationship 'Brand is parent of Brand', and the enrich_04 GRAIN entry; 04 keeps Marketing Theme and Messaging Pillar. "
    "Transfer BRD- to 42 in PREFIXES and drop the four OWNERSHIP_OVERRIDES in enrich_42 once BRD- resolves to 42. Update the "
    "04 overview 'Core model' text, which begins 'Brand / Marketing Theme'.",
    "CD-271 additions on 42 Brand: Brand Owning Entity (row rule on the object group: Corporate Brand, Affiliate / Boutique "
    "Brand and Co-Brand rows stewarded by Corporate Communications; Sub-Brand and Product Range Brand rows by 04 Marketing). All rows are mastered in 42; stewardship differs per row (not a derived copy). Option B (04 keeps the "
    "register; 42 holds only Brand Standard Version and Brand Use Authorization keyed by BRD-) remains on record for SME Q1.",
    "CD-271 for 12: Report Template 'Brand' note 'owned by 04' becomes 'owned by 42'; the attribute itself is unchanged.",
    "CD-272 for 04 (proposed, not applied): add Property Type value 'Corporate Website / Newsroom'. Social Account Type "
    "'Corporate Brand' already exists. 42 holds no URL or handle register; Press Release and Corporate Publication reference WEB-.",
    "CD-272 trigger links: Communications Issue holds Trigger Operational Incident (37 OPINC-), Trigger IT Incident (41 ITINC-), "
    "Trigger Legal Matter (39 LMAT-), Trigger Health and Safety Incident (44 HSEI-) and Trigger Physical Security Incident (44, "
    "'PSI 2026 0042'), one filled per row by Issue Trigger Type. 37, 39, 41 and 44 should hold no reference back.",
    "CD-272 for 11: Corporate Award Entry 'Fund or Manager Award Record' references AWD-; 42 holds a result only on firm-level "
    "award rows ('Firm Award Result').",
    "CD-273: Lobbying Disclosure Report 'Reported Political Contributions' is Reference (Political Contribution, 38) (multi) on "
    "LD-203 rows; no amount, recipient or date is copied. 38's Political Contribution has no reserved prefix (grain 'covered "
    "associate or firm x contribution sequence'); the example '38 contribution 2026-0007' is a placeholder until 38 publishes "
    "a key format. Government Official Contact references 08 GNE- for hospitality.",
    "CD-273 tax: Trade Association Membership holds Annual Dues Amount and the association-reported lobbying percentage; the "
    "IRC 162(e) deduction treatment is 19. LD-2 expenses of an in-house registrant may use the IRC 162(e) method "
    "(LDA Expense Reporting Method).",
    "CD-143 (02 Party Role Type values proposed): Journalist, Media Outlet, Government Official, Trade Association, Award "
    "Organizer (from CD-282), plus Newswire Service, Media Monitoring Provider, Reputation Research Provider, Lobbying Firm and "
    "Legislative Body / Government Agency, which 42 references as PTY-.",
    "Sibling names used, re-checked against the 37-41, 43 and 44 modules after review: 37 Operational Incident (OPINC-), "
    "Business Continuity Plan; 38 Policy (POLCY-), Political Contribution; 39 Legal Matter (LMAT-), Contract (CTRCT-), "
    "Corporate Resolution (CGRES-); 41 IT Incident (ITINC-); 43 Capital Requirement Calculation (RCAP-); 44 Health & Safety "
    "Incident (HSEI-), Operational Emission Record. 40 Supplier Profile is not referenced (PR agencies and monitoring vendors "
    "are referenced as 02 parties). All match.",
    "Derived copy: Spokesperson Authorization 'Media Training Completion Date' copies the completion date of the 20 Learning "
    "Completion for the media training item.",
    "CD-271 CDE change (program lead decision after review): Brand Level is a CDE in 42 (it drives the stewardship row rule, "
    "which is stated on the Brand Register object group; the Brand Steward Function attribute and list were dropped). The "
    "moved tuple is otherwise identical to 04; apply the same CDE flag at merge. Brand Owner was dropped in trimming.",
    "CD-272 for 04 (proposed): retire the Content Type value 'Press Release' (content_04 Content Type list), or define a 04 "
    "asset of that type as content metadata only, keyed to the 42 NEWS- release. 42 Press Release is the master.",
    "CD-272 row rule for social coverage (program lead decision): 04 Social Listening Mention is the master of every social "
    "media mention, including posts by journalists; 42 Media Coverage Item holds articles and broadcasts only and references "
    "mentions from Communications Issue 'Related Social Mentions'. 04 Social Listening Mention has no identifier; propose "
    "that 04 add one so the reference can be keyed.",
    "11 / paid entries: Corporate Award Entry no longer holds a paid-entry flag; 11 Award 'Paid to Participate Indicator' is "
    "the master on fund and manager awards (reached through 'Fund or Manager Award Record'). Firm-level paid entries are not "
    "recorded (SME question).",
    "38 dependency (program lead decision): 38 Political Contribution needs an identifier (attribute and key format) so that "
    "42 'Reported Political Contributions' can be keyed; its example is '(38 key pending)'. Its scope must cover every "
    "LD-203-reportable item, not only Rule 206(4)-5 pay-to-play: FECA contributions of USD 200 or more to federal candidates, "
    "leadership PACs and party committees, honorary expenses, payments for events honoring covered officials, presidential "
    "library and inaugural committee contributions.",
    "39: Corporate Resolution Subject Link 'Subject Corporate Publication' should use the 42 Corporate Publication ID format "
    "(e.g. 'MSA/0021/2025/1') instead of text. 42 holds no approval link; 'Publication Board Approval Date' is a Derived "
    "copy (39). Stewardship Report and Entity PAI Statement were removed from Publication Type: 34 masters them.",
    "44: Space Reservation 'Reserved For Corporate Event' can now use the Corporate Event ID ('CE/2026/0031'). The 44 "
    "Physical Security Incident key 'PSI 2026 0042' is referenced by Communications Issue 'Trigger Physical Security Incident'.",
    "Examples use published formats: PTY-104588 (02), LEN-0004 (09), EMP-30588 (20), REV-2026-004518, GNE-2026-018834 (08), "
    "AWD-2026-0045 (11), WEB-012 (04), COMM-2026-0145 (13), LCHG-2026-00118 (36), PAIC-PRD00431-2025-01 (34), and the Stage 4 "
    "formats OPINC-2026-01187, POLCY-0118, CTRCT-0041877, CGRES-2026-00041, LMAT-2026-0019, ITINC-2026-004512, "
    "RCAP-0003-20260930-01, HSEI-2026-0031 (matches 44's HSEI-<year>-<4 digits>), PSI 2026 0042, BCP 014, PAIC-LEN0004-2025-01.",
]
