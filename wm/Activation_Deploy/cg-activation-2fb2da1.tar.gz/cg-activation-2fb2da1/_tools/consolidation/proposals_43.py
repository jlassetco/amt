"""Consolidation proposals from Data Domain 43 - Corporate Treasury & Capital (Stage 4 draft v0.1, 2026-10-06).

Proposal fragment only: the builder does not read it. The Stage 4 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Format follows CONTRACT.md in this folder. Decisions implemented: CD-274 to CD-278
and the 43 part of CD-282 (proposals_stage4_b.py), with the program lead's rulings on CD-276 (seed capital) and CD-278
(folding into 19). Nothing here edits 01-42 or 44.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones. None needed.
#    43 uses only the reserved BKAC-, DEBT-, ICLN-, SDCAP-, RCAP-, TDEAL-, HEDG- and INPOL- (CD-282). Signatories, cash
#    pool memberships, relationship profiles, fee statements, bank statements and entries, cash positions, forecasts and
#    lines, drawdowns, covenant tests, seed movements and valuations, capital profiles and components, ICARA assessments,
#    notifications, exposures, deal valuations, effectiveness tests, coverage layers and claims are keyed by their grain.
#    Short-term investments ("Placement 2026/0318"), capital transactions ("IGCT 2026/007") and cash forecasts ("Group
#    13-week 2026-10-05 v1") carry firm keys written without a hyphenated stem.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# Key formats of the reserved prefixes, as 43 issues them (decisions.PREFIX_FORMATS tuple format).
KEY_FORMATS = [
    ("BKAC-", "43", "BKAC-<sequence, 5 digits>", "BKAC-00118"),
    ("DEBT-", "43", "DEBT-<sequence, 4 digits>", "DEBT-0003"),
    ("ICLN-", "43", "ICLN-<year>-<sequence, 4 digits>", "ICLN-2026-0012"),
    ("SDCAP-", "43", "SDCAP-<sequence, 5 digits>", "SDCAP-00041"),
    ("RCAP-", "43", "RCAP-<entity number, 4 digits>-<regime code, 2 letters>-<as-of date YYYYMMDD>-<version, 2 digits>; regime codes NC, MP, IP, UC, AI, CB, OC (Capital Regime list)", "RCAP-0003-NC-20260930-01"),
    ("TDEAL-", "43", "TDEAL-<year>-<sequence, 6 digits>", "TDEAL-2026-000318"),
    ("HEDG-", "43", "HEDG-<sequence, 5 digits>", "HEDG-00027"),
    ("INPOL-", "43", "INPOL-<coverage line code: PI, DO, CR, CY, FL, PR, GL, EP, OT>-<policy year>-<sequence, 2 digits>", "INPOL-DO-2026-01"),
]

# Grain keys other domains cite (written as 43 publishes them).
GRAIN_KEY_FORMATS = [
    ("Bank Statement", "<BKAC- key> / <Bank Statement Type> / <statement date> / <statement sequence number>", "BKAC-00118 / End-of-Day Statement / 2026-10-05 / 198"),
    ("Bank Statement Entry", "<Bank Statement key> / <entry sequence>", "BKAC-00118 / End-of-Day Statement / 2026-10-05 / 198 / 12"),
    ("Debt Facility Drawdown", "<DEBT- key> / <drawdown number, 2 digits>", "DEBT-0003 / 07"),
    ("Seed Capital Movement", "<SDCAP- key> / <movement number, 2 digits>", "SDCAP-00041 / 01"),
    ("Seed Product Holding", "<PRD- key> / <measurement date>", "PRD-00981 / 2026-09-30"),
    ("Intra-Group Capital Transaction", "IGCT <year>/<sequence, 3 digits>", "IGCT 2026/007"),
    ("ICARA Assessment", "<LEN- key> / ICARA / <review date>", "LEN-0021 / ICARA / 2026-06-30"),
    ("Insurance Claim", "<INPOL- key> / claim <sequence, 2 digits>", "INPOL-DO-2026-01 / claim 03"),
    ("Corporate Exposure", "<LEN- key> / <Corporate Exposure Type> / <currency or rate index> / <period start> [/ <SDCAP- or DEBT- key>]",
     "LEN-0004 / Forecast Foreign Currency Revenue / EUR / 2027-01-01"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local 43 lists that are verbatim copies (labels) of enterprise shared lists.
#    (shared list name, local list name in 43, where 43 uses it)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    ("Record Status", "Record Status", "Corporate Bank Account status, Hedge Relationship status"),
    ("Approval Status", "Approval Status", "Cash Forecast approval, Capital Requirement Calculation approval"),
    ("Reconciliation Status", "Reconciliation Status", "Bank Statement Entry reconciliation, Bank Fee Statement review"),
    ("Data Basis", "Data Basis", "Cash Position, Cash Forecast Line, Corporate Exposure"),
    ("Regulator", "Regulator", "Capital Adequacy Notification regulator"),
    ("Message Standard", "Message Standard", "Bank Statement message standard"),
]
# Value maps: every local value is the shared label one to one (e.g. 'Active' -> ACTIVE, 'Reported / Actual' -> REPORTED,
# 'ISO 20022 camt' -> ISO_20022_CAMT, 'Central Bank of Ireland' -> IE_CBI). Descriptions were shortened in a few local
# copies; labels are unchanged. Not used: Severity and Risk Rating (attributes trimmed after review to stay within size), Frequency, Information Classification
# (account number classification is stated in the notes as 'Restricted'), Business Line (the seeded product's line is
# read from 01), Case Status (claims use the local Insurance Claim Status).

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: local 43 lists that look like enterprise lists.
#    (list name in 43, proposed shared list name, likely other users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("(none: external format)", "Reference Rate", ["17", "22", "26", "30", "43"],
     "Review finding: 43 now cites the same external format as 22, 26 and 30 ('External (ISO 20022 benchmark curve name / "
     "FpML floating rate index or inflation index)') with the tenor separate ('External (22 Rate Tenor list)'). If an "
     "enterprise list is wanted, raise it stewarded by 22 with benchmark and tenor as two lists; 22 Rate Tenor is the "
     "tenor half."),
    ("Covenant Metric", "Covenant Metric", ["30", "43"],
     "CD-282 candidate. 30 'Covenant Type' (Borrowing Base Coverage, Loan-to-Value, Minimum Uncalled Commitments, Investor "
     "Concentration Limit) is fund-level; 43 metrics are corporate (leverage, interest cover, net worth, liquidity, AUM). "
     "One list with both sets is possible; recommend steward 43 (or 19 if folded) and a 'Facility Level' column."),
    ("Cash Flow Category", None, ["19", "10", "43"],
     "Could align with a 19 cash flow statement classification if 19 adds one; keep local until then."),
    ("Capital Regime", None, ["09", "38", "43"],
     "Derivable in part from the 09 / 38 Entity Authorization Type; kept local because one authorization can imply two "
     "regimes (MIFIDPRU and UCITS ManCo own funds for a UK firm with both permissions). Map at consolidation."),
    ("Insurance Coverage Line", None, ["35", "37", "41", "43"],
     "37 loss events and 41 cyber incidents may want to name the line claimed under; they read it from the claim instead."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS noticed (decisions.py format). CD-282 already lists Account, Commitment, Facility, Policy, Position,
#    Exposure and Claim with 43 usages; the entries below add terms not yet listed or name the 43 qualifier.
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Facility Drawdown",
     "usages": [("30", "Facility Drawdown", "Drawdown under a Fund Credit Facility (FCF-)"),
                ("43", "Debt Facility Drawdown", "Drawdown under a corporate Debt Facility (DEBT-)")],
     "recommendation": "Same object name in two domains: 43 renamed its object 'Debt Facility Drawdown' (deviation from "
                       "the brief, which named it 'Facility Drawdown'). Recommend 30 renames to 'Fund Credit Facility "
                       "Drawdown' at consolidation for symmetry."},
    {"term": "Statement",
     "usages": [("43", "Bank Statement; Bank Fee Statement", "Bank-to-customer cash statement; bank billing statement"),
                ("28", "Custodian Statement", "Custody holdings and cash statement for fund accounts"),
                ("13", "Statement (STMT-)", "Shareholder account statement"),
                ("19", "Financial Statement", "Entity financial statements")],
     "recommendation": "Always qualify: Bank Statement (43), Custodian Statement (28), Shareholder Statement (13), "
                       "Financial Statement (19)."},
    {"term": "Capital",
     "usages": [("43", "Seed Capital Commitment; Capital Requirement Calculation; Intra-Group Capital Transaction",
                 "Firm capital: seed investment, regulatory capital, equity moved between entities"),
                ("30", "Investor Capital Account; Capital Call", "Investor economics in a private fund"),
                ("20", "Carried Interest / co-investment awards", "Employee awards, not firm capital")],
     "recommendation": "Qualify: Seed Capital (43), Regulatory Capital (43), Intra-Group Capital (43), Investor Capital "
                       "(30); never 'capital' alone."},
    {"term": "Hedge",
     "usages": [("43", "Hedge Relationship (HEDG-)", "Hedge accounting designation for the firm's own exposures"),
                ("01", "Share Class Hedging", "Currency hedging policy of a hedged share class"),
                ("27", "Class allocation of hedge results", "Fund accounting of share class hedges")],
     "recommendation": "'Hedge Relationship' is the accounting designation (43); share class hedging stays 01 / 27."},
    {"term": "Covenant Test",
     "usages": [("30", "Covenant Test", "Fund credit facility covenant"),
                ("43", "Corporate Covenant Test", "Corporate debt covenant")],
     "recommendation": "Kept apart by name as the brief required; see Covenant Metric shared candidate."},
    {"term": "Position",
     "usages": [("43", "Cash Position; Seed Position Valuation", "Entity cash by value date; value of firm seed holdings"),
                ("06", "Position (POS-)", "Shareholder position"), ("18", "Portfolio Holding", "Book holding")],
     "recommendation": "43 never masters units: Seed Position Valuation copies 06 units (row rule)."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. VALUE_PROPOSALS: changes 43 asks of other domains (domain, object / attribute or list, proposed change, basis).
#    Every 'future 43' text found in 01-36 (scan of 2026-10-06) is listed and resolves to a 43 object.
# ---------------------------------------------------------------------------------------------------------------------
VALUE_PROPOSALS = [
    # ---- CD-274: bank accounts
    ("19", "Supplier Payment.Paying Bank Account",
     "Re-type Code (Firm-defined) -> Reference (Corporate Bank Account, 43), example BKAC-00118; drop the note 'until a "
     "bank account master exists in 43 or 19'.", "CD-274."),
    ("19", "Cash Receipt Application.Bank Statement Entry Reference",
     "Re-type Identifier -> Reference (Bank Statement Entry, 43), example 'BKAC-00118 / End-of-Day Statement / 2026-10-05 / "
     "198 / 12'. Program lead decision on review High 2: the link is held only on the 19 side (one entry is applied to many "
     "receivable items); 43 dropped 'Matched Cash Receipt'. If 19 wants supplier payments matched to entries, add the same "
     "reference on 19 Supplier Payment; 43 holds none.", "CD-274, CD-275; review High 2."),
    ("19", "list Regulatory Return Type",
     "Add value 'FCA MIF007 ICARA Questionnaire' (regulator FCA), referenced by 43 ICARA Assessment 'ICARA Questionnaire "
     "Return' with key 'LEN-0021 / FCA / FCA MIF007 ICARA Questionnaire / 2026-06-30'.", "CD-277; review Medium."),
    ("19", "overview Scope 'bank accounts ... (future 43)'",
     "Re-word: 'corporate bank accounts, statements and cash positions are 43 (BKAC-); 19 holds the cash GL account and "
     "its balance'.", "CD-274."),
    # ---- CD-277: regulatory capital
    ("19", "Regulatory Financial Return.Capital Requirement Amount; Capital Resources Amount",
     "Flag Derived copy (43) of Capital Requirement Calculation 'Treasury Capital Requirement Amount' and 'Treasury Capital "
     "Resources Amount' (renamed in 43 so a folded 19 holds no duplicate names). Row rule: the calculation of the return's "
     "filing entity and regime (regime code in the RCAP- key) with Calculation As-Of Date = Return Reporting Period End and "
     "Calculation Approval Status 'Approved' (the latest version if several). Replace the note 'capital management is 43'.",
     "CD-277."),
    # ---- CD-276: seed capital (program lead ruling: Seed Capital Commitment is the only master)
    ("18", "Portfolio.Proprietary Capital Indicator",
     "Flag Derived copy (43). Row rule: 'Y' while the portfolio is the Seed Book of a 43 Seed Capital Commitment whose "
     "Seed Commitment Status is Approved, Funded or Partially Redeemed; 'N' otherwise. Replace the note 'decided by 43 ... "
     "(SME question)'.", "CD-276; Stage 1 consolidation item 12."),
    ("15", "Account (no change)",
     "No Seed Capital Indicator is added to 15 (GAP-02-021 closed by reference): a seed account is the 'Seed Holding "
     "Account' of a 43 Seed Capital Commitment. Any future 15 indicator would be a Derived copy (43).",
     "CD-276; GAP-02-021."),
    ("36", "Product Business Case.Seed Capital Required",
     "Keep as 36's projection; re-word the note 'Future owner of seed capital commitments: 43' to 'Projection before "
     "approval; the approved commitment is 43 Seed Capital Commitment (SDCAP-)'.", "CD-276."),
    ("36", "Readiness Check (evidence references); list Readiness Workstream value 'Seed Capital'",
     "Add 'Evidence Seed Capital Commitment' Reference (Seed Capital Commitment, 43), example SDCAP-00041, as the evidence "
     "for checks of workstream Seed Capital; update the list description from 'Future 43' to '43 Seed Capital "
     "Commitment'.", "CD-276."),
    ("36", "Product Readiness Plan.Seed Investor; Planned Seed Amount; Planned Seed Date; Seed Portfolio",
     "Keep as plans; re-word the Seed Investor note 'Seed capital commitments are future 43' to 'An affiliate seed is a 43 "
     "Seed Capital Commitment; a third-party seed investor stays a 02 party here'.", "CD-276."),
    ("30", "Private Fund Profile.GP Commitment Percentage; Investor Commitment",
     "No change: the percentage stays an LPA term and the GP's commitment stays the 30 ICMT-, which 43 Seed Capital "
     "Commitment references (GP Investor Commitment).", "CD-276."),
    ("19", "Consolidation Scope Entity.Group Ownership Percentage",
     "On rows with a Consolidated Fund Product or Seed Portfolio, flag Derived copy (43) of Seed Product Holding 'Firm "
     "Ownership Percentage' (one row per product and date) at the scope fiscal period end (row rule); other rows (subsidiaries) stay mastered in 19. "
     "Consolidation Method and Control Assessment Basis stay 19.", "CD-276."),
    # ---- CD-275: funding
    ("30", "family Fund Financing (PV-LEV) definition",
     "Re-word 'Borrowing by the GP or the firm is out of scope (future 43 / 19)' to 'Borrowing by the GP or the firm is "
     "43 Debt Facility (DEBT-)'.", "CD-275."),
    # ---- CD-278: insurance
    ("37", "Loss Event Amount.Amount Source Insurance Claim; relationship 'Insurance Claim [43] recovers Operational Loss Event'",
     "Program lead decision on review High 1: drop 'Amount Source Insurance Claim'. 43 Insurance Claim 'Related Operational "
     "Loss Event' is the only direction. A loss recovered under several policies or layers is several claim rows that "
     "reference the same loss; the 37 'recovery from insurance' Loss Amount is a Derived copy (43): the sum of Amount "
     "Recovered over the claims that reference the loss (claim-level read). Keep the 37 relationship text as 'is recovered "
     "by Insurance Claim [43] (link held on 43)'.", "CD-278; review High 1."),
    # ---- CD-257 / sibling links held once on the 39 side
    ("39", "Typed Contract Link; list Typed Record Type",
     "39 already holds Linked Debt Facility, Linked Corporate Bank Account and Linked Insurance Policy (43); 43 therefore "
     "holds no contract reference (removed from the 43 draft). Add 'Linked Intercompany Loan' Reference (Intercompany Loan, "
     "43), example ICLN-2026-0012, for loans documented outside a 10 Intercompany Agreement (SME question 10).",
     "CD-257 row rule; CD-275."),
    ("39", "Corporate Resolution Subject Link; list Corporate Resolution Subject Type",
     "39 already holds Subject Debt Facility, Subject Capital Transaction and Subject ICARA Assessment; 43 holds no "
     "resolution reference (CD-237 pattern). Add subject types 'Seed Capital Commitment (43)' (43 Commitment Approval Date is a Derived "
     "copy (39) of the resolution date on those rows) and 'Corporate Bank Account Mandate (43)'. Use the 43 grain keys in "
     "examples: 'IGCT 2026/007' for capital transactions and 'LEN-0021 / ICARA / 2026-06-30' for ICARA assessments.",
     "CD-259, CD-277."),
    ("39", "Signing Authority Grant",
     "Confirmed: bank mandates are 43 Bank Account Signatory (effective-dated, with authority level, joint rule and limit).",
     "CD-274."),
    ("41", "relationship 'Insurance Claim [43] may arise from IT Incident'",
     "43 holds the link: Insurance Claim 'Related IT Incident' Reference (IT Incident, 41), example ITINC-2026-004512.",
     "CD-266, CD-278."),
    ("42", "Publication Source Link.Source Capital Requirement Calculation",
     "Update the example to the amended format and a UK entity, since a MIFIDPRU 8 disclosure publishes the UK firm's "
     "calculation: RCAP-0021-MP-20260930-01.", "CD-277; review High 3 and Low."),
    ("44", "relationship 'Office Location [09] is insured under Corporate Insurance Policy [43]'",
     "The link is held nowhere (44 holds no policy reference, 43 no location). Re-word to 'Property cover for the site is "
     "a 43 Corporate Insurance Policy of line Property for the site's legal entity' or drop it; 43 keeps no location "
     "schedule (mapping detail of the insurance register).", "CD-278; review Low."),
    ("38", "Entity Authorization", "No change: 43 Governing Authorization is typed Reference (Entity Authorization, 38) and "
     "forced to 38 in enrich_43 until the AUTH- prefix owner moves from 09 to 38 (CD-250).", "CD-250."),
    # ---- CD-143 / CD-282 party roles
    ("02", "list Party Role Type", "Add values 'Relationship Bank', 'Corporate Lender' and 'Insurance Broker' ('Insurer' is "
     "proposed by 37).", "CD-143, CD-282."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Folding rule (CD-278, program lead ruling): if 43 folds into 19, move the seven families with object, attribute and "
    "code list names unchanged; change TY-BNK, TY-CSH, TY-FND, TY-SED, TY-CAP, TY-HDG, TY-IPG to FI-BNK, FI-CSH, FI-FND, "
    "FI-SED, FI-CAP, FI-HDG, FI-IPG (no clash with 19's FI-COA, FI-JNL, FI-CLS, FI-AP, FI-AR, FI-RPT, FI-PLN, FI-TAX); change "
    "'Reference (<object>, 43)' to '(<object>, 19)'; in enrich, the references to 19 objects become mastered and the "
    "override for ICARA Questionnaire Return becomes ''. Checked: no 43 object, family, local list or attribute name equals "
    "a 19 name; the capital amounts are 'Treasury Capital Requirement Amount' and 'Treasury Capital Resources Amount' so "
    "the 19 return keeps 'Capital Requirement Amount' and 'Capital Resources Amount' as its derived copies. No 43 object depends "
    "on a structure that exists only in 43 except its own objects.",
    "Program lead ruling CD-276: Seed Capital Commitment is the only master of firm seed and co-investment status. 18 "
    "Proprietary Capital Indicator becomes a Derived copy (proposal above); no indicator is added to 15; the GP commitment "
    "itself stays 30 Investor Commitment, referenced from 'GP Investor Commitment'.",
    "Program lead ruling CD-275: corporate hedges are 43 Treasury Deals; portfolio FX trades are 25 / 26 records; rates are "
    "22's (Valuation Spot Rate and Reference Rate Fixing Value are Derived copies (22); the dealt rate is mastered).",
    "Program lead ruling CD-257: bank mandates, facility agreements and insurance policy wordings are typed contracts on 39 "
    "Contract. The 43 draft first held reverse references (Bank Mandate Contract, Facility Agreement Contract, Policy "
    "Contract) and approval references (five Approving Resolution attributes); they were removed after reading content_39, "
    "which holds both links (Typed Contract Link, Corporate Resolution Subject Link), so each link is held once.",
    "Deviation: Treasury Deal covers FX and rate derivatives only; deposits, money market fund units, bills and commercial "
    "paper are Short-Term Investments (brief listed 'deposit' under both, which would hold the same placement twice).",
    "Deviation: 'Facility Drawdown' renamed 'Debt Facility Drawdown' (30 has an object named Facility Drawdown). A 32nd "
    "object, Cash Pool Membership, was added so pool roles are effective-dated (review checklist 'memberships of cash pools "
    "are effective-dated'); the brief put Cash Pool Role and header account on the account.",
    "Deviation: Seed Commitment approval is held as Commitment Approval Date (Derived copy (39) on rows approved by a corporate resolution, mastered for treasury or seed committee approvals); the 36 launch "
    "approval is reached through Launch Change Initiative (LCHG-) rather than a separate PAPR- reference.",
    "Entity Authorization (AUTH-) is referenced as 09's (registered owner today); under CD-250 it moves to 38 with names "
    "unchanged, and the reference re-resolves without an edit once the prefix owner changes.",
    "Sibling names used (checked against content_37, 39, 41 and 42 on 2026-10-06): 37 Risk Appetite Statement (key "
    "'RAS 2026 CAP 01', no hyphenated stem), Operational Loss Event (LOSS-); 39 Legal Matter (LMAT-); 41 Application "
    "(APPL-), IT Incident (ITINC-). 42 Publication Source Link cites RCAP- in the 43 format.",
    "Examples use the published formats of other owners: GLA-GRPCOA-110210, JNL-2026-10-80112, FPL-2027-BUD (19), ICA-0019 "
    "(10), ICMT-000188, CCN-0431-017, PDIS-0431-009 (30), FXR-20261005-WMR16-EURUSD-SP, CURVE-USD-SOFR (22), TAGR-00131 (26), "
    "NAV-2026093000451201 (27), FNDO-2026-00418273, ECR-2026-000512 (29), LCHG-2026-00118 (36), ACC- (15), PORT- (18), "
    "SHC- / PRD- (01), AUTH-0012 (09), LOSS-2026-00213 (37), LMAT-2026-0019 (39), APPL-00412, ITINC-2026-004512 (41).",
    "Review response (43_review.md, 2026-10-06): all three Highs applied as decided by the program lead; Mediums and Lows "
    "applied except those listed in Source_Notes §2 'Review response'. New object Seed Product Holding (product x date) "
    "holds the group ownership share; Debt Facility Drawdown and Seed Capital Movement have firm-defined references; "
    "Cash Position is keyed by account; Bank Statement by sequence; Capital Requirement Component by sequence; Insurance "
    "Coverage Layer by carrier.",
]
