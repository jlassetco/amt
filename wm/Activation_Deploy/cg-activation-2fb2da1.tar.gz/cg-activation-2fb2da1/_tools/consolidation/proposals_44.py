"""Consolidation proposals from the Data Domain 44 (Workplace & Corporate Services) draft, 2026-10-06.

Proposal fragment only: the builder does not read this file. The Stage 4 consolidation step merges accepted entries into
decisions.py and shared_code_lists.py. Formats follow CONTRACT.md in this folder. Boundary decisions CD-279 to CD-282 are in
proposals_stage4_b.py; this file holds what the draft found while implementing them and the program lead's rulings.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES  (prefix, entity, owner domain, status, note) - decisions.PREFIXES format
# No prefixes beyond the six reserved in proposals_stage4_b.py CD-282 (LEASE-, FMWO-, BADGE-, HSEI-, EXPR-, TRIP-).
# Every other object keeps a firm-defined natural or composite key written without a hyphenated stem (KEY_FORMATS).
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# 2. KEY_FORMATS (prefix or object, format, note)
# ---------------------------------------------------------------------------------------------------------------------
KEY_FORMATS = [
    ("LEASE-", "LEASE-<sequence, 5 digits>, e.g. LEASE-00031", "Lease (real estate and non-IT equipment). Confirms the brief."),
    ("FMWO-", "FMWO-<year>-<sequence, 7 digits>, e.g. FMWO-2026-0004512", "Facility work order. Confirms the brief."),
    ("BADGE-", "BADGE-<sequence, 7 digits>, e.g. BADGE-0018832", "Access badge. Confirms the brief."),
    ("HSEI-", "HSEI-<year>-<sequence, 4 digits>, e.g. HSEI-2026-0017", "Health and safety incident. Confirms the brief."),
    ("EXPR-", "EXPR-<year>-<sequence, 7 digits>, e.g. EXPR-2026-0418812", "Expense report. Confirms the brief."),
    ("TRIP-", "TRIP-<year>-<sequence, 7 digits>, e.g. TRIP-2026-0091377", "Travel booking. Confirms the brief."),
    ("Site Profile", "Composite: SITE- / profile effective from, e.g. 'SITE-US-SFO / 2026-01-01'", "No 44 object references a Site Profile; all reference the 09 SITE- key directly."),
    ("Building Space", "Firm-defined: <site code without hyphens>.<floor>[.<space>], e.g. 'USSFO.12', 'USSFO.12.D045'", "Dots, not hyphens, so the key never reads as a prefix."),
    ("Facility Asset", "Firm-defined tag: <site code>.<asset class code>.<sequence, 4 digits>, e.g. 'USSFO.HVAC.0012'", "Fixed Asset Number is a separate identifier (SME question 3)."),
    ("Visitor Registration", "Firm-defined: <site code> <arrival date YYYYMMDD> <sequence, 4 digits>, e.g. 'USSFO 20261006 0045'", "VIS- is 04's web visitor prefix and was avoided."),
    ("Physical Security Incident", "Firm-defined: PSI <year>-<sequence, 4 digits>, e.g. 'PSI 2026-0007'", "Format used by 37 Source Physical Security Incident (review G); the hyphen follows digits, so it never reads as a prefix."),
    ("Physical Access Zone Grant", "Composite: BADGE- / SITE- / access zone / space (or '-') / effective from, e.g. 'BADGE-0018832 / SITE-UK-LON / Trading Floor / UKLON.04 / 2026-01-12'", "Review D: site and space make the key unique."),
    ("Workplace Risk Assessment", "Firm-defined: <assessment type code> <site, workstation or employee number> <assessment date YYYYMMDD>, e.g. 'FRA USSFO 20260311', 'DSE 01234 20260311'", "Review D: per-person assessments are keyed by employee."),
    ("Corporate Card", "Firm-defined: issuer card account ID or T&E platform token, written without a hyphenated stem, e.g. 'CA 004471889'", "Program lead decision (review E, High): the masked number is a display attribute only. CCRD- / CARD- rejected in CD-282; the full card number is never held (PCI DSS)."),
    ("Card Transaction", "Composite: card account ID / issuer transaction reference, e.g. 'CA 004471889 / 74129836250112'", ""),
    ("Lease Accounting Measurement", "Composite: LEASE- / LDG- / measurement date, e.g. 'LEASE-00031 / LDG-4100-USGAAP-USD / 2021-07-01'", "One row per framework ledger and measurement event."),
    ("Operational Emission Record", "Composite: LEN- / SITE- or 'ENTITY' / reporting year / GHG scope category / calculation method, e.g. 'LEN-0004 / ENTITY / 2025 / Scope 2 (Market-Based) / Market-Based', 'LEN-0004 / SITE-UK-LON / 2025 / Scope 1 / Fuel-Based'",
     "Program lead decision (review D, High). 42 Publication Source Link 'Source Operational Emission Record' should use this format (its example is descriptive text today); 34 derives from ENTITY rows only."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED MEMBERSHIPS: 44 local lists that carry an enterprise shared list's exact name and values. Register 44 as a
#    member (or as a direct user) of each. Values copied from shared_code_lists.py on 2026-10-06.
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Record Status", "local": "Record Status",
     "value_map": {"Draft": "DRAFT", "Proposed": "PROPOSED", "Pending": "PENDING", "Active": "ACTIVE", "Paused": "PAUSED",
                   "Inactive": "INACTIVE", "Deprecated": "DEPRECATED", "Retired": "RETIRED"},
     "new_values": [], "note": "Facility Asset Status."},
    {"shared": "Approval Status", "local": "Approval Status",
     "value_map": {"Not Required": "NOT_REQUIRED", "Pending": "PENDING", "Approved": "APPROVED",
                   "Approved with Conditions": "APPROVED_WITH_CONDITIONS", "Retrospectively Approved": "RETROSPECTIVELY_APPROVED",
                   "Rejected": "REJECTED", "Expired": "EXPIRED", "Withdrawn": "WITHDRAWN"},
     "new_values": [], "note": "Expense Approval Status."},
    {"shared": "Case Status", "local": "Case Status",
     "value_map": {"New / Received": "NEW", "Pending Good Order": "PENDING_GOOD_ORDER", "In Progress": "IN_PROGRESS",
                   "Waiting on Client": "WAITING_ON_CLIENT", "Pending Third Party": "PENDING_THIRD_PARTY", "Escalated": "ESCALATED",
                   "Resolved / Completed": "RESOLVED", "Closed": "CLOSED", "Rejected": "REJECTED", "Canceled": "CANCELED"},
     "new_values": [], "note": "Work order and physical security incident workflow only."},
    {"shared": "Frequency", "local": "Frequency",
     "value_map": {"Real-Time": "REAL_TIME", "Intraday": "INTRADAY", "Daily": "DAILY", "Weekly": "WEEKLY", "Fortnightly": "FORTNIGHTLY",
                   "Monthly": "MONTHLY", "Quarterly": "QUARTERLY", "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL",
                   "Biennial": "BIENNIAL", "On Event": "ON_EVENT", "Ad Hoc": "AD_HOC"},
     "new_values": [], "note": "Maintenance Frequency."},
    {"shared": "Severity", "local": "Severity",
     "value_map": {"Low": "LOW", "Medium": "MEDIUM", "High": "HIGH", "Critical": "CRITICAL"}, "new_values": [],
     "note": "Security Incident Severity."},
    {"shared": "Risk Rating", "local": "Risk Rating",
     "value_map": {"Low": "LOW", "Medium": "MEDIUM", "High": "HIGH", "Critical": "CRITICAL", "Prohibited": "PROHIBITED"},
     "new_values": [], "note": "Workplace Risk Assessment overall rating; not in the brief's §8 list (added)."},
    {"shared": "Data Basis", "local": "Data Basis",
     "value_map": {"Reported / Actual": "REPORTED", "Estimated": "ESTIMATED", "Modeled": "MODELED", "Allocated": "ALLOCATED",
                   "Interpolated": "INTERPOLATED", "Survey-Based": "SURVEY_BASED", "Mixed": "MIXED"},
     "new_values": [], "note": "Utility consumption and operational emissions."},
    {"shared": "Agreement Status", "local": "Agreement Status",
     "value_map": {"Draft": "DRAFT", "In Negotiation": "IN_NEGOTIATION", "Pending Signature": "PENDING_SIGNATURE",
                   "Executed - Not Yet Effective": "EXECUTED_NOT_EFFECTIVE", "Active": "ACTIVE", "Suspended": "SUSPENDED",
                   "Under Notice of Termination": "UNDER_NOTICE", "Terminated": "TERMINATED", "Expired": "EXPIRED",
                   "Superseded": "SUPERSEDED"},
     "new_values": [], "note": "Lease Status; not in the brief's §8 list (added instead of a local Lease Status list). 39 Contract uses the same list."},
    {"shared": "Outgoing Payment Status", "local": "Outgoing Payment Status",
     "value_map": {"Scheduled": "SCHEDULED", "Released": "RELEASED", "Paid / Settled": "PAID", "Failed": "FAILED",
                   "Reversed": "REVERSED", "Canceled": "CANCELED"},
     "new_values": [], "note": "Expense Report Reimbursement Status (Derived copy 19, row rule)."},
]
# Not used although the brief §8 listed them: Business Line (the recharge target is the fund PRD-, whose business line is
# derivable from 01) and Information Classification (no classified-record attribute was needed).

# ---------------------------------------------------------------------------------------------------------------------
# 4. SHARED_CANDIDATES: local 44 lists that look like enterprise lists, or overlap another domain's list
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("GHG Scope Category", ["34", "44"],
     "CD-281 / CD-282 candidate. 34 'Sustainability Indicator Scope' has Scope 1, Scope 2 (Location-Based), Scope 2 (Market-Based), "
     "Scope 3, Not Applicable. 44 keeps the same Scope 1 and Scope 2 labels and splits Scope 3 into the operational categories "
     "1, 3, 5, 6, 7. Proposal: one shared list 'GHG Scope Category' stewarded by 34 holding the 34 values plus the fifteen Scope 3 "
     "categories; 34 indicators use 'Scope 3' or a category, 44 uses categories only (never category 15)."),
    ("Assurance Level", ["34", "35", "42", "44"],
     "None / Limited / Reasonable assurance applies to any sustainability or regulatory figure that is externally assured; "
     "candidate shared list stewarded by 21 or 34."),
    ("Emission Factor Source", ["34", "44"], "34 may cite the same factor publishers for issuer estimates."),
    ("Calculation Method", ["34", "44"],
     "Emission calculation methods (fuel-based, location-based, market-based, distance-based, spend-based, supplier-specific, "
     "average-data) apply to 34 issuer estimates as well; candidate shared list stewarded by 34 with GHG Scope Category."),
    ("Job Level", ["20", "44"],
     "44 Expense Policy Limit.Applicable Job Level holds a value of 20 'Job Level' (cited as 'Firm-defined (20 Job Level)' to "
     "avoid a copied list). Register 44 as a user of the 20 list at consolidation, or make Job Level a shared list stewarded by 20."),
    ("Lease Classification", ["19", "44"],
     "If Lease Accounting Measurement moves to 19, the list moves with it unchanged."),
    ("Expense Type", ["08", "10", "44"],
     "08 Gift / Entertainment type values (gift, entertainment, non-cash compensation) overlap the 44 entertainment values; "
     "10 distribution expense categories differ. Recommend NOT_MERGED; map 44 Client Entertainment and Gift to External Party "
     "to the 08 types in a crosswalk."),
    ("Badge Status / Card Status", ["41", "44"],
     "41 Digital Identity status may use similar values (active, suspended, deactivated). Recommend NOT_MERGED: physical and "
     "logical credentials have different lifecycles."),
    ("Emergency Role", ["37", "44"],
     "37 Business Continuity Plan roles (crisis team) differ from site emergency roles. Recommend NOT_MERGED."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. PARTY ROLE TYPE values proposed for 02 (CD-143, as CD-282 lists them). 44 does not edit 02.
# ---------------------------------------------------------------------------------------------------------------------
PARTY_ROLE_TYPE_ADDITIONS = [
    ("02", "Party Role Type", "Landlord", "Lessor of real estate or equipment to the firm (Lease.Lease Counterparty where Lease Role = Lessee)."),
    ("02", "Party Role Type", "Facility Service Provider", "Facilities management, maintenance, cleaning or security contractor (Planned Maintenance Schedule.Maintenance Vendor, Facility Work Order.Assigned Vendor)."),
    ("02", "Party Role Type", "Card Issuer", "Bank or card company issuing corporate cards (Corporate Card.Card Issuer)."),
    ("02", "Party Role Type", "Travel Management Company", "Agency that books the firm's travel (Travel Booking.Booking Agency)."),
    ("02", "Party Role Type", "Subtenant", "Party to which the firm sublets space (Lease.Lease Counterparty where Lease Role = Sublessor). Not in CD-282's list; added."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. TERM_CONFLICTS (decisions.TERM_CONFLICTS format). CD-282 already lists Incident, Access, Asset, Card, Facility,
#    Expense, Site and Emission; the entries below add what the draft found.
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Lease",
     "usages": [("16", "Participant Loan (LOAN-)", "Plan loans; not a lease."),
                ("28", "Securities Lending Agreement / Securities Loan (SBL-)", "Securities lent by funds."),
                ("44", "Lease (LEASE-)", "Real estate and non-IT equipment leases of the firm as lessee or sublessor.")],
     "recommendation": "'Lease' unqualified is the 44 real estate or equipment lease; securities lending is always 'Securities Loan' (28)."},
    {"term": "Space",
     "usages": [("44", "Building Space", "Physical space in a building."),
                ("04", "Digital property / placement", "Ad space or web space in marketing usage.")],
     "recommendation": "Use 'Building Space' (44); marketing uses 'Placement'."},
    {"term": "Site",
     "usages": [("09", "Office Location (SITE-)", "Organizational key of an office or site."),
                ("44", "Site Profile", "Real estate profile keyed by SITE-."),
                ("04", "Digital Property (WEB-)", "'Website' / 'site' in marketing usage.")],
     "recommendation": "As CD-282: SITE- is the one key; 'Site Profile' names the 44 record; web properties are never 'sites' in the glossary."},
    {"term": "Visitor",
     "usages": [("04", "Web Visitor (VIS-)", "Anonymous or known visitor to a digital property."),
                ("44", "Visitor Registration", "Person visiting a physical site.")],
     "recommendation": "Qualify: 'Web Visitor' (04), 'Site Visitor' (44)."},
    {"term": "Reservation / Booking",
     "usages": [("04", "Event Registration", "Registration to a marketing event."),
                ("44", "Space Reservation; Travel Booking (TRIP-)", "Room or desk booking; travel itinerary.")],
     "recommendation": "Qualify: 'Space Reservation', 'Travel Booking' (44), 'Event Registration' (04)."},
    {"term": "Measurement",
     "usages": [("31", "Risk measurements", ""), ("32", "Performance measurement profile", ""),
                ("44", "Site Occupancy Measurement; Lease Accounting Measurement", "")],
     "recommendation": "Always qualify; 'Lease Accounting Measurement' moves to 19 unchanged if the ERP runs lease accounting."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. CHANGES PROPOSED TO OTHER DOMAINS (for the program lead; 44 does not edit them)
# ---------------------------------------------------------------------------------------------------------------------
CHANGES_TO_OTHER_DOMAINS = [
    ("09", "Internal Organization / Office Location",
     "Recorded ruling (program lead): Office Location stays in 09 and is referenced by 44, not moved. Proposed only: widen the "
     "object definition to 'office or site' (Office ID already says so), so data centers, DR sites and storage are added as "
     "SITE- rows before 44 profiles them."),
    ("39", "Typed Contract Link / Linked Lease; CD-257",
     "Program lead decision: the lease-to-contract link is held once, on 44 (Lease.Lease Contract -> CTRCT-). Drop 39 'Linked "
     "Lease'. Amend the CD-257 resolution so that leases are typed 44 rows (CD-279): on lease rows 44 masters dates, status and "
     "parties and the 39 copies are Derived copies (44). Exception to that row rule: 44 holds no governing law and no contract "
     "effective date (Lease Commencement Date is the date the asset is available, not the date the instrument took effect), so "
     "39 Governing Law and Contract Effective Date stay mastered in 39 on lease rows."),
    ("19 / 40", "Supplier Payment / Payee Supplier",
     "Program lead decision: employees are never 02 parties (CD-151), so employee expense reimbursements go through 20 payroll, "
     "and 44 references a 19 Supplier Payment only where the payee is a 02 party (for example a contingent worker's agency). "
     "If a country reimburses employees through AP, 19 must accept an employee payee on reimbursement rows (Reference (Employee) "
     "on Supplier Payment) rather than an employee party; SME question 4."),
    ("37", "Operational Incident / Incident Source",
     "Add 'Source Health & Safety Incident' Reference (Health & Safety Incident, 44) (HSEI-) and an Incident Source Type value "
     "'Health & Safety Incident', as for physical security incidents (CD-280 rule 4). The 44 relationship is marked proposed "
     "until 37 adds it. 44 adopted 37's 'PSI 2026-0007' key format. Drop the stale Resilience Resource Mapping 'Mapped Site' "
     "note ('44 Site Profile may take SITE-'): SITE- stays 09's."),
    ("42", "Publication Source Link / Source Operational Emission Record",
     "Use the 44 KEY_FORMATS format for the example, e.g. 'LEN-0004 / ENTITY / 2025 / Scope 2 (Market-Based) / Market-Based', "
     "and publish Entity Total rows only."),
    ("27", "Fund Expense Accrual",
     "Optional: add 'Recharged Expense Line' Reference (Expense Line, 44) (EXPR- / line number) on accruals of recharged deal "
     "costs, so the row rule in 44's relationship to 27 has a key. No 44 change."),
    ("40", "Purchase Order",
     "No change: 44 Facility Work Order now holds 'Work Order Purchase Order' (PURCH-), matching 40's relationship. Expense "
     "reports are paid outside purchase orders."),
    ("09", "Units & Formats / Unit of Measure",
     "Confirm UN/ECE Rec 20 codes FTK (square foot), MTK (square meter), KWH (kilowatt hour), MTQ (cubic meter), TNE (tonne) are "
     "available; add tCO2e if 34 has not already asked (proposals_34)."),
    ("19", "Journals & Balances / Journal Source",
     "CD-279 / CD-280: add values 'Lease Accounting' (postings from 44 Lease Accounting Measurement and lease payments) and "
     "'Travel & Expense' (postings of 44 Expense Reports)."),
    ("19", "Lease Accounting Measurement (contingent)",
     "CD-279 / program lead ruling: if lease accounting runs in the ERP (SME question 2), move the 44 attribute group 'Lease "
     "Accounting Measurement' to 19 unchanged (object and attribute names kept; parent stays Reference (Lease, 44)). No change otherwise."),
    ("20", "Job Level", "See SHARED_CANDIDATES: register 44 as a user of the 20 Job Level list."),
    ("19", "Fixed assets",
     "19 has no fixed-asset register object; 44 Facility Asset holds 'Fixed Asset Number' as an identifier (SME question 3). "
     "If 19 adds a Fixed Asset object, re-type it to a reference."),
    ("20", "Payroll Result",
     "No change. Expense reimbursements paid through payroll are referenced from 44 Expense Report (row rule); 20 holds no 44 reference."),
    ("34", "Portfolio Sustainability Metric",
     "CD-281: rows with a Metric Legal Entity and an own-operations indicator (codes proposed: OWN_GHG_SCOPE1, OWN_GHG_SCOPE2_LB, "
     "OWN_GHG_SCOPE2_MB, OWN_GHG_SCOPE3_CAT6, ...) are Derived copies (44) of Operational Emission Record.Emissions tCO2e on "
     "Entity Total rows only (Emission Record Level = Entity Total), summed over calculation methods within the entity, year and "
     "scope category; Site rows are never added. Add the row rule to the 34 attribute note; add the indicator definitions at Indicator Level 'Entity'."),
    ("08", "Gift / Entertainment Item",
     "No change. 44 Expense Line references GNE-; 08 holds no 44 reference."),
    ("42", "Communications Issue",
     "No change. 42 references 44 incidents; 44 holds no 42 reference."),
    ("43", "Corporate Insurance Policy",
     "No change in 44. Property cover may list insured SITE- rows; 44 holds no policy reference."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 8. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Register LEASE-, FMWO-, BADGE-, HSEI-, EXPR-, TRIP- (owner 44) with the KEY_FORMATS above. Self-references use "
    "'Reference (X, 44)'; no OWNERSHIP_OVERRIDES were needed.",
    "Add CONCEPT_OWNERSHIP rows: Site Profile (44), Building Space (44), Lease (44, LEASE-), Facility Asset (44), Facility Work Order "
    "(44, FMWO-), Access Badge (44, BADGE-), Visitor Registration (44), Physical Security Incident (44), Health & Safety Incident "
    "(44, HSEI-), Expense Report (44, EXPR-), Corporate Card (44), Card Transaction (44), Travel Booking (44, TRIP-), Operational "
    "Emission Record (44). Expected referrers: 34, 37, 42 (and 19 if lease accounting moves).",
    "CD-280 exception recorded: casual visitors (and injured non-employees on H&S incidents) are recorded by name as PII text, "
    "like job candidates in 20; known visitors are referenced by PTY-.",
    "Review applied 2026-10-06 (00_Program/Expansion/Reviews/44_review.md): program lead decisions 1-4 applied; findings not "
    "applied are listed in Source_Notes §2 'Review response'. Local code lists are now 33 (brief 24-30): Lease Recognition "
    "Exemption, Emission Record Level and Calculation Method were added on review findings.",
    "Object count 28 (brief 27): Space Assignment was split out of Building Space so that org unit assignments are effective-dated "
    "without versioning the space.",
    "Sibling references: 38 Policy (POLCY-), 39 Contract (CTRCT-), 40 Purchase Order (PURCH-), 42 Corporate Event (CE/2026/0031). "
    "Names checked against the 37-42 modules at review.",
]
