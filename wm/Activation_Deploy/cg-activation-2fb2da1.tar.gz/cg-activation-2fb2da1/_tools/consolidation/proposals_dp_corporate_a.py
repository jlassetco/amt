"""Wave E0 candidate products for Corporate Functions A: 19 Finance & Accounting, 20 Human Capital, 43 Corporate Treasury
& Capital and 44 Workplace & Corporate Services. Brief: 00_Program/Expansion/Product_Briefs/Corporate_Finance_and_People.md.
Reserved product IDs DP-190 to DP-209; reserved decision IDs CD-340 to CD-349. Read by
data_products/candidate_coverage.py; merged by the integrator, never edited into framework.py or decisions.py here.
Upstream names that are not DP- ids are Wave E1 candidates of other briefs, named as in plan §7 E1.

Briefs accepted 2026-10-08: DECISIONS below are merged into decisions.py (kept here as the record of the proposal);
CANDIDATES remain the input to Waves E1 to E4 (read by data_products/candidate_coverage.py).
"""

CANDIDATES = [
    # ---- Foundational (Wave E1) ---------------------------------------------------------------------------------------
    dict(id="DP-190", name="Chart of Accounts & Ledger", tier="Foundational", type="Master & Reference", domain="19",
         owner_role="Finance Controller", primary="FN-38",
         supporting=["FN-12", "FN-39", "FN-40", "FN-33", "FN-49", "FN-46", "FN-43"], wave="E1",
         definition="The conformed chart of accounts of every group legal entity: charts, GL accounts, chart segment values "
                    "(cost and profit centers, company codes, product and intercompany segments), ledgers by entity, "
                    "accounting basis, currency and role, financial statement lines with their GL mapping, and the "
                    "status of each ledger's fiscal periods. It gives every finance, treasury, people and distribution "
                    "finance product one GL Account, Cost Center and Ledger dimension with effective-dated history.",
         objects=[("19", "Chart of Accounts"), ("19", "GL Account"), ("19", "Chart Segment Value"), ("19", "Ledger"),
                  ("19", "Financial Statement Line"), ("19", "Financial Statement Line Mapping"),
                  ("19", "Accounting Period Status"), ("09", "Internal Legal Entity"), ("09", "Fiscal Period"),
                  ("09", "Org Unit")],
         upstream=["DP-013", "DP-004"],
         notes="Concept ownership rows: 'GL Account' (19, GLA-), 'Chart Segment Value / Cost & Profit Center Code' (19), "
               "'Ledger' (19, LDG-), 'Accounting Period Status' (19) (CD-152). Publishes the SM-00 GL Account, Cost "
               "Center and Ledger dimensions (CD-296). DP-013 keeps legal entity, org unit and fiscal calendar; this "
               "product joins them to the segment values that represent them and never repeats them. Fund ledgers are "
               "27 (CD-186) and are out of scope. Represented Product resolves through DP-004."),
    dict(id="DP-191", name="General Ledger Journals & Balances", tier="Foundational", type="Conformed Facts",
         domain="19", owner_role="Finance Controller", primary="FN-38",
         supporting=["FN-12", "FN-39", "FN-40", "FN-41", "FN-43", "FN-01"], wave="E1",
         definition="Every journal entry and GL posting of the group ledgers with its subledger source, and the period "
                    "balances by ledger, account combination, fiscal period and balance type. It is the certified home "
                    "of the P&L and operating expense family (CD-293, CD-340), so that FP&A, distribution finance, tax "
                    "and treasury read one booked actual.",
         objects=[("19", "Journal Entry"), ("19", "GL Posting"), ("19", "GL Account Balance"),
                  ("19", "Accounting Period Status")],
         upstream=["DP-190", "DP-013", "DP-192"],
         notes="Concept ownership row: 'Journal Entry / GL Posting' (19, JNL-). Second 19 foundational product, beyond "
               "plan §7 E1's single 'Chart of Accounts & Ledger': the certified P&L and operating expense need a "
               "foundational fact product, and DP-012, DP-056, DP-074 and DP-089 read Journal Entry and GL Posting "
               "directly today (CD-343 re-points them). Payroll posts in summary per run (no employee-level cost). "
               "Journal Prepared By / Approved By resolve through DP-192 for segregation-of-duties checks only; the "
               "published fact carries no names (PII = N in the wide view)."),
    dict(id="DP-192", name="Employee & Position Master", tier="Foundational", type="Master & Reference", domain="20",
         owner_role="Head of HR Data & People Analytics", primary="FN-41",
         supporting=["FN-08", "FN-11", "FN-38", "FN-51", "FN-44", "FN-21", "FN-50", "FN-13"], wave="E1",
         definition="The conformed record of every worker (employees, contractors, consultants and secondees) with job "
                    "profile, budgeted position, job and org unit assignments, reporting lines, employing entity, "
                    "location, cost center and the lifecycle events that change them, with full effective-dated "
                    "history. It publishes the SM-00 Employee dimension for the firm and the certified headcount and "
                    "FTE family (CD-293, CD-341), and is the joiner, mover and leaver feed for access and badge products.",
         objects=[("20", "Employee"), ("20", "Employee Reporting Line"), ("20", "Employee Personal Detail"),
                  ("20", "Contingent Worker Detail"), ("20", "Job Profile"), ("20", "Workforce Position"),
                  ("20", "Employee Job Assignment"), ("20", "Org Unit Assignment"), ("20", "Employee Lifecycle Event"),
                  ("09", "Org Unit"), ("09", "Internal Legal Entity"), ("09", "Office Location")],
         upstream=["DP-013", "DP-190"],
         notes="Concept ownership rows: 'Employee' (20, EMP-, CD-151), 'Job Profile' (JOB-), 'Workforce Position' "
               "(WFP-), 'Employee Lifecycle Event' (ELE-). Re-points DP-009's employee dimension (plan §7 E1; CD-342): "
               "DP-009 publishes the sales-role subset and the 03 Sales Person profile on top of this product. "
               "Employee Personal Detail is published only as a restricted extension (work authorization, country of "
               "residence, national identifier for payroll and regulatory registration); diversity data is never here "
               "(DP-201, CD-344). No pay data (DP-198)."),

    # ---- 19 Finance & Accounting: consumer (Wave E4) -------------------------------------------------------------------
    dict(id="DP-193", name="Financial Close, Consolidation & Statements", tier="Consumer-aligned",
         type="Regulatory & Control", domain="19", owner_role="Head of Financial Reporting", primary="FN-38",
         supporting=["FN-43", "FN-12", "FN-33", "FN-40", "FN-45", "FN-42"], wave="E4",
         definition="Close progress, account reconciliation, consolidation scope, intercompany matching and the "
                    "resulting financial statements by reporting entity, framework and period. It lets the Controller "
                    "run the close calendar against key controls, evidence consolidation conclusions for seeded funds "
                    "and GP entities, and tie each statement line to ledger balances.",
         objects=[("19", "Accounting Period Status"), ("19", "Close Task"), ("19", "Consolidation Scope Entity"),
                  ("19", "Intercompany Balance"), ("19", "GL Account Balance"), ("19", "Financial Statement"),
                  ("19", "Financial Statement Line Value"), ("19", "Financial Statement Line"),
                  ("43", "Seed Product Holding"), ("09", "Entity Ownership Relationship")],
         upstream=["DP-190", "DP-191", "DP-192", "DP-013", "DP-204"],
         notes="Statement line values are certified only as reported; they must equal DP-191 balances mapped through "
               "DP-190 (CD-340). Close Task executions are sampled by 37 control tests (CD-243); this product does not "
               "hold the control library. Seed consolidation triggers come from DP-204 (Seed Product Holding); the "
               "consolidation decision stays 19."),
    dict(id="DP-194", name="Enterprise Budget, Forecast & Operating Expense", tier="Consumer-aligned",
         type="Analytical", domain="19", owner_role="Head of FP&A", primary="FN-38",
         supporting=["FN-01", "FN-12", "FN-41", "FN-40", "FN-37"], wave="E4",
         definition="Actual P&L and operating expense against the enterprise budget, forecasts and long-range plan by "
                    "legal entity, cost center, statement line and period, with planned against authorized and actual "
                    "FTE. It is the FP&A view of the firm, into which the distribution budgets (10 Plan Version) roll.",
         objects=[("19", "Financial Plan Version"), ("19", "Financial Plan Line"), ("19", "GL Account Balance"),
                  ("19", "Financial Statement Line Mapping"), ("19", "Chart Segment Value"), ("10", "Plan Version"),
                  ("10", "Plan Line"), ("20", "Workforce Position")],
         upstream=["DP-190", "DP-191", "DP-192", "DP-013"],
         notes="Actuals are DP-191's certified P&L and operating expense; headcount and FTE are DP-192's certified "
               "numbers (CD-340, CD-341). DP-056 Distribution Budget vs Actual stays the distribution cost-center view "
               "with partner program commitments; its actuals must equal this product's for the same cost centers. "
               "Management P&L lines and profitability stay 10 (DP-035)."),
    dict(id="DP-195", name="Payables, Receivables & Working Capital", tier="Consumer-aligned", type="Operational",
         domain="19", owner_role="Head of Accounting Operations", primary="FN-38",
         supporting=["FN-46", "FN-40", "FN-12", "FN-14", "FN-33", "FN-17", "FN-39"], wave="E4",
         definition="Open and settled payable invoices, supplier payments, receivable items and cash receipt "
                    "applications with aging, due dates and payment status, by legal entity, supplier or debtor and "
                    "source document. It drives payment runs, collections and accrual cut-off, and measures days "
                    "payable and days sales outstanding for the firm's own books.",
         objects=[("19", "Payable Invoice"), ("19", "Payable Invoice Line"), ("19", "Indirect Tax Detail"),
                  ("19", "Supplier Payment"), ("19", "Supplier Payment Application"), ("19", "Receivable Item"),
                  ("19", "Cash Receipt Application"), ("43", "Bank Statement Entry")],
         upstream=["DP-190", "DP-191", "DP-210", "DP-012", "DP-004", "DP-013"],
         notes="Grain is the subledger open item (payable invoice or receivable item) x as-of date. Purchase orders, "
               "receipts, invoice matching and supplier spend are 40 (Corporate B brief); this product starts at the "
               "accounting record (CD-158). Fee revenue comes from DP-012 and is not recalculated; partner payments "
               "settle DP-034 accruals. Supplier and Payee Supplier are flagged PII (sole traders) and resolve through "
               "'Vendor Master'."),
    dict(id="DP-196", name="Corporate Tax Provision, Filings & Transfer Pricing", tier="Consumer-aligned",
         type="Regulatory & Control", domain="19", owner_role="Head of Tax", primary="FN-39",
         supporting=["FN-38", "FN-12", "FN-45", "FN-40"], wave="E4",
         definition="Tax registrations, returns and their due dates, current and deferred tax provision by entity, "
                    "jurisdiction and component, indirect tax recoverability and transfer pricing documentation "
                    "coverage of intercompany agreements. It gives the Head of Tax one view of filing status, effective "
                    "tax rate and transfer pricing evidence for every group entity.",
         objects=[("19", "Entity Tax Registration"), ("19", "Tax Return"), ("19", "Tax Provision"),
                  ("19", "Transfer Pricing Documentation"), ("19", "Indirect Tax Detail"),
                  ("10", "Intercompany Agreement"), ("10", "TP Policy"), ("10", "Intercompany Charge")],
         upstream=["DP-190", "DP-191", "DP-074", "DP-013"],
         notes="Corporate tax only (CD-149): fund tax is 27 and shareholder tax reporting is DP-091. DP-074 keeps the "
               "arm's length test of distribution intercompany charges; this product reads its results as evidence "
               "and does not recalculate them. If the client creates a Tax domain, the product moves with the 19 "
               "Corporate Tax family unchanged."),

    # ---- 20 Human Capital: consumer (Wave E4) -------------------------------------------------------------------------
    dict(id="DP-197", name="Workforce Movement, Hiring & Screening", tier="Consumer-aligned", type="Analytical",
         domain="20", owner_role="Head of HR Data & People Analytics", primary="FN-41",
         supporting=["FN-38", "FN-01", "FN-44", "FN-13", "FN-51"], wave="E4",
         definition="Hires, internal moves, leaves and terminations against budgeted positions and open requisitions, "
                    "with turnover, time to fill, vacancy and pre-employment screening outcomes by org unit, entity, "
                    "job level and location. It supports the headcount plan and evidences that regulated roles were "
                    "screened before start and that terminations requiring regulatory notice were flagged.",
         objects=[("20", "Employee Lifecycle Event"), ("20", "Leave of Absence"), ("20", "Employee Job Assignment"),
                  ("20", "Workforce Position"), ("20", "Job Requisition"), ("20", "Candidate Application"),
                  ("20", "Background Screening")],
         upstream=["DP-192", "DP-190"],
         notes="Headcount and FTE are taken from DP-192 (CD-341); turnover rates are this product's derived measures. "
               "Background screening results and medical leave types are special category data: published only in a "
               "restricted HR view (CD-344). Form U5 filing stays 08 (DP-039)."),
    dict(id="DP-198", name="Pay, Payroll & Benefits", tier="Consumer-aligned", type="Operational", domain="20",
         owner_role="Head of Reward", primary="FN-41",
         supporting=["FN-38", "FN-11", "FN-12", "FN-19"], wave="E4",
         definition="Base pay, variable awards paid, payroll results by run and the benefit plans and enrollments of "
                    "every employee, reconciled run by run to the payroll journals in the ledger. It supports the "
                    "compensation cycle, payroll accuracy, incentive payout execution and benefit cost.",
         objects=[("20", "Base Pay Record"), ("20", "Payroll Run"), ("20", "Payroll Result"), ("20", "Benefit Plan"),
                  ("20", "Benefit Enrollment"), ("20", "Variable Compensation Award"),
                  ("07", "Compensation Statement"), ("07", "Payroll Payment Instruction"), ("19", "Journal Entry")],
         upstream=["DP-192", "DP-191", "DP-033"],
         notes="Confidential - Compensation. Incentive earned is DP-033's number; this product shows what payroll paid "
               "against it; compensation expense is DP-191 (CD-347). Outsourced payroll (SME Q11 of 20): the grain "
               "becomes the provider's run register and result file, with the same run-level journal tie-out "
               "(CD-297). Own 401(k) memberships resolve to DP-094."),
    dict(id="DP-199", name="Remuneration Code: Material Risk Takers & Deferred Awards", tier="Consumer-aligned",
         type="Regulatory & Control", domain="20", owner_role="Head of Reward", primary="FN-41",
         supporting=["FN-44", "FN-11", "FN-26", "FN-38", "FN-45", "FN-18"], wave="E4",
         definition="Material risk taker identification by entity, regime and performance year, with each identified "
                    "person's variable awards, deferral, instruments, vesting tranches, malus and clawback and the "
                    "conduct adjustments from performance review. It evidences compliance with the UCITS, AIFMD and "
                    "MIFIDPRU remuneration codes and feeds the remuneration disclosures.",
         objects=[("20", "Material Risk Taker Identification"), ("20", "Variable Compensation Award"),
                  ("20", "Deferred Award Tranche"), ("20", "Performance Review"),
                  ("07", "Remuneration Conflict Assessment")],
         upstream=["DP-192", "DP-198"],
         notes="20 masters MRT status; 07 Identified Staff Indicator is a derived copy and is read only to test "
               "consistency (CD-151). DP-082 keeps sales compensation governance and the 07 conflict assessment; it "
               "takes MRT status from this product. Carried interest points are read here; carry allocation and "
               "waterfalls are 30 (CD-205)."),
    dict(id="DP-200", name="Talent, Succession & Mandatory Training", tier="Consumer-aligned",
         type="Regulatory & Control", domain="20", owner_role="Head of Talent & Learning", primary="FN-41",
         supporting=["FN-44", "FN-13", "FN-42", "FN-01"], wave="E4",
         definition="Performance ratings and objectives, succession cover for key-person positions, and assignment and "
                    "completion of mandatory and regulatory training by population and due date. It supports talent "
                    "reviews and shows compliance and resilience functions where training is overdue or a key position "
                    "has no ready successor.",
         objects=[("20", "Performance Review"), ("20", "Performance Objective"), ("20", "Succession Plan Entry"),
                  ("20", "Learning Item"), ("20", "Learning Completion"), ("20", "Mandatory Training Requirement"),
                  ("20", "Workforce Position"), ("08", "CE Requirement")],
         upstream=["DP-192", "DP-039"],
         notes="Key-Person Risk Indicator is on Workforce Position; resilience mapping of people to important "
               "business services is 37 (CD-249). FINRA and FCA CE status stays 08 / DP-039; this product shows "
               "completions only. Performance Objective's Linked Metric Definition resolves to 21."),
    dict(id="DP-201", name="Workforce Diversity, Pay Equity & Human Capital Disclosure", tier="Consumer-aligned",
         type="Regulatory & Control", domain="20", owner_role="Head of HR Data & People Analytics", primary="FN-41",
         supporting=["FN-47", "FN-38", "FN-24", "FN-50"], wave="E4",
         definition="Self-identified diversity by org unit, level and entity, gender and ethnicity pay gaps, and the "
                    "published human capital metric values (EEO-1, UK gender pay gap, ESRS S1, ISO 30414). It is the "
                    "only product that reads special category diversity data, and publishes aggregates with minimum "
                    "cell sizes.",
         objects=[("20", "Employee Diversity Profile"), ("20", "Employee Personal Detail"), ("20", "Job Profile"),
                  ("20", "Base Pay Record"), ("20", "Variable Compensation Award"), ("20", "Human Capital Metric Value")],
         upstream=["DP-192", "DP-198", "DP-101"],
         notes="Special category data (CD-344): access limited to named HR analytics roles; only aggregates leave the "
               "product. Human Capital Metric Value rows for headcount must equal DP-192's certified numbers "
               "(CD-341). Metric definitions resolve to 21 (KPI-)."),

    # ---- 43 Corporate Treasury & Capital: consumer (Wave E4) ----------------------------------------------------------
    dict(id="DP-202", name="Corporate Cash, Bank Accounts & Liquidity", tier="Consumer-aligned", type="Operational",
         domain="43", owner_role="Group Treasurer", primary="FN-40",
         supporting=["FN-38", "FN-45", "FN-42"], wave="E4",
         definition="Bank accounts and mandates of every group entity, intraday and end-of-day statements, cash "
                    "positions, the cash forecast by entity, currency and category, short-term investments and bank "
                    "fees, reconciled to the cash GL accounts. It supports daily liquidity, funding and investment "
                    "decisions and bank mandate control.",
         objects=[("43", "Corporate Bank Account"), ("43", "Bank Account Signatory"), ("43", "Cash Pool Membership"),
                  ("43", "Bank Relationship Profile"), ("43", "Bank Fee Statement"), ("43", "Bank Statement"),
                  ("43", "Bank Statement Entry"), ("43", "Cash Position"), ("43", "Cash Forecast"),
                  ("43", "Cash Forecast Line"), ("43", "Short-Term Investment"), ("19", "GL Account Balance")],
         upstream=["DP-190", "DP-191", "DP-192", "DP-013", "DP-004"],
         notes="Corporate accounts only (CD-274): fund cash and CASS client money are 28 (Fund Operations brief). Cash "
               "GL balances come from DP-191. Corporate Bank Account is the SM-00 Bank Account dimension source until "
               "a foundational treasury product is justified. Folds to 19 with 43 (CD-345)."),
    dict(id="DP-203", name="Corporate Funding, Intercompany Loans & Hedging", tier="Consumer-aligned",
         type="Analytical", domain="43", owner_role="Group Treasurer", primary="FN-40",
         supporting=["FN-38", "FN-39", "FN-29", "FN-45"], wave="E4",
         definition="Debt facilities, drawdowns and covenant headroom, intercompany loans and intra-group capital "
                    "transactions, corporate FX and rate exposures, treasury deals with their valuations, and hedge "
                    "relationships with effectiveness results. It supports funding, dividend and capital repatriation "
                    "decisions and the hedge accounting evidence the Controller books.",
         objects=[("43", "Debt Facility"), ("43", "Debt Facility Drawdown"), ("43", "Corporate Covenant Test"),
                  ("43", "Intercompany Loan"), ("43", "Intra-Group Capital Transaction"), ("43", "Corporate Exposure"),
                  ("43", "Treasury Deal"), ("43", "Treasury Deal Valuation"), ("43", "Hedge Relationship"),
                  ("43", "Hedge Effectiveness Test"), ("19", "Intercompany Balance")],
         upstream=["DP-190", "DP-191", "DP-013", "DP-143", "DP-115",
                   "DP-204"],
         notes="43 decides, 19 books (CD-275): no balance or journal is mastered here. Seed-book hedges traded "
               "through the OMS are 25 / 26 records designated by reference (Investment Operations brief). Valuation "
               "rates come from 'Prices, FX & Curves'. Fund-level facilities are 30."),
    dict(id="DP-204", name="Seed & Co-Investment Capital", tier="Consumer-aligned", type="Analytical", domain="43",
         owner_role="Group Treasurer", primary="FN-40",
         supporting=["FN-37", "FN-38", "FN-21", "FN-26", "FN-33", "FN-10"], wave="E4",
         definition="Every seed, incubation, GP and co-investment commitment of firm capital with its movements, "
                    "valuation and the group's ownership share of each seeded product over time. It supports seed "
                    "deployment and recycling against exit triggers and gives consolidation and launch teams one "
                    "seed status.",
         objects=[("43", "Seed Capital Commitment"), ("43", "Seed Capital Movement"), ("43", "Seed Position Valuation"),
                  ("43", "Seed Product Holding")],
         upstream=["DP-004", "DP-007", "DP-093", "DP-013", "DP-165", "DP-116",
                   "DP-140"],
         notes="43 is the only master of seed status (CD-276). Seed position value is a treasury measure, never AUM; "
               "net assets of seeded funds count in Firm AUM through 27 (CD-292, CD-346). Units from DP-007, NAV per "
               "share from 'NAV & Fund Financials', private fund balances from 'Investor Capital Accounts'."),
    dict(id="DP-205", name="Regulatory Capital & ICARA", tier="Consumer-aligned", type="Regulatory & Control",
         domain="43", owner_role="Head of Regulatory Capital", primary="FN-40",
         supporting=["FN-38", "FN-42", "FN-44", "FN-45"], wave="E4",
         definition="Capital requirements, resources, surplus and liquid assets by regulated entity and regime with "
                    "their components (K-factors, fixed overheads, permanent minimum), ICARA thresholds, early-warning "
                    "and notification events, and the status of each regulatory financial return. It evidences "
                    "capital adequacy to the board and regulators.",
         objects=[("43", "Regulated Entity Capital Profile"), ("43", "Capital Requirement Calculation"),
                  ("43", "Capital Requirement Component"), ("43", "ICARA Assessment"),
                  ("43", "Capital Adequacy Notification"), ("19", "Regulatory Financial Return")],
         upstream=["DP-191", "DP-193", "DP-013"],
         notes="43 calculates, 19 files (CD-277): capital amounts are this product's; the 19 return's amounts are "
               "derived copies and are compared, not re-published. Entity authorizations come from 38 through DP-013."),
    dict(id="DP-206", name="Corporate Insurance Program & Claims", tier="Consumer-aligned", type="Analytical",
         domain="43", owner_role="Group Treasurer", primary="FN-40",
         supporting=["FN-42", "FN-45", "FN-36", "FN-51", "FN-48"], wave="E4",
         definition="The corporate insurance tower by coverage line, layer and carrier with limits, retentions and "
                    "premium, and every claim with reserves and recoveries linked to the loss, legal matter or IT "
                    "incident behind it. It supports renewal decisions and gives operational risk the recoveries it "
                    "nets against losses.",
         objects=[("43", "Corporate Insurance Policy"), ("43", "Insurance Coverage Layer"), ("43", "Insurance Claim")],
         upstream=["DP-013"],
         notes="Loss recoveries in 37 are derived copies of Amount Recovered (CD-278). The fund fidelity bond is 35 and "
               "is referenced, not copied. The Corporate B brief's risk products read claims from here."),

    # ---- 44 Workplace & Corporate Services: consumer (Wave E4) ---------------------------------------------------------
    dict(id="DP-207", name="Real Estate, Occupancy & Operational Footprint", tier="Consumer-aligned",
         type="Analytical", domain="44", owner_role="Head of Corporate Real Estate", primary="FN-48",
         supporting=["FN-38", "FN-47", "FN-24", "FN-41"], wave="E4",
         definition="Sites, space and its assignment to org units, occupancy and desk use, leases with rent schedules, "
                    "options and critical dates and their ASC 842 / IFRS 16 measurement, and site energy use and the "
                    "operational Scope 1, 2 and 3 emissions of the firm. It supports site strategy, lease decisions and "
                    "the firm's own-operations climate disclosures.",
         objects=[("44", "Site Profile"), ("44", "Building Space"), ("44", "Space Assignment"),
                  ("44", "Site Occupancy Measurement"), ("44", "Space Reservation"), ("44", "Lease"),
                  ("44", "Leased Space"), ("44", "Lease Payment Schedule Line"), ("44", "Lease Option & Critical Date"),
                  ("44", "Lease Accounting Measurement"), ("44", "Utility Consumption Record"),
                  ("44", "Operational Emission Record")],
         upstream=["DP-013", "DP-190", "DP-191", "DP-192"],
         notes="09 keeps SITE- (CD-279). Lease accounting rows are produced by the 19 Controller; journals are DP-191. "
               "Financed emissions are 34 (CD-281); 34 own-operations indicators are derived copies of the Entity "
               "Total rows here. Withdrawn if the client drops 44 (CD-345)."),
    dict(id="DP-208", name="Workplace Services, Physical Security & Safety", tier="Consumer-aligned",
         type="Regulatory & Control", domain="44", owner_role="Head of Workplace Services", primary="FN-48",
         supporting=["FN-42", "FN-41", "FN-51", "FN-46"], wave="E4",
         definition="Facility assets, planned maintenance and work orders against SLA, badges and access zone grants "
                    "reconciled to employee status, visitors, physical security and health and safety incidents, "
                    "workplace risk assessments and emergency role cover by site. It evidences that leavers lose "
                    "physical access promptly, that statutory maintenance and OSHA / RIDDOR recording are done, and "
                    "that every site has certified emergency roles.",
         objects=[("44", "Facility Asset"), ("44", "Planned Maintenance Schedule"), ("44", "Facility Work Order"),
                  ("44", "Access Badge"), ("44", "Physical Access Zone Grant"), ("44", "Visitor Registration"),
                  ("44", "Physical Security Incident"), ("44", "Health & Safety Incident"),
                  ("44", "Workplace Risk Assessment"), ("44", "Emergency Role Assignment"),
                  ("20", "Learning Completion")],
         upstream=["DP-192", "DP-013", "DP-210"],
         notes="Two decisions in one product, kept together because both are run by FN-48 at site grain. Health and "
               "safety incidents are special category health data. 37 Operational Incident references these "
               "incidents (CD-266, CD-280); IT assets are 41. Withdrawn if the client drops 44 (CD-345)."),
    dict(id="DP-209", name="Travel & Expense Spend and Policy Compliance", tier="Consumer-aligned",
         type="Regulatory & Control", domain="44", owner_role="Finance Controller", primary="FN-38",
         supporting=["FN-48", "FN-13", "FN-12", "FN-44", "FN-26", "FN-01"], wave="E4",
         definition="Expense reports and lines, corporate card transactions and travel bookings by employee, cost "
                    "owner, expense type and period, tested against expense policy limits, with reimbursement status "
                    "and recharges to funds. It supports expense policy enforcement, card reconciliation and cost "
                    "control, and links entertainment lines to the gifts and entertainment register.",
         objects=[("44", "Expense Report"), ("44", "Expense Line"), ("44", "Corporate Card"),
                  ("44", "Card Transaction"), ("44", "Travel Booking"), ("44", "Expense Policy Limit"),
                  ("08", "Gift / Entertainment Item")],
         upstream=["DP-192", "DP-191", "DP-038", "DP-013"],
         notes="C-13.17 is owned by the Finance Controller, so FN-38 is primary. Compliance facts on entertainment stay "
               "08 / DP-038. Closes the DP-057 taxonomy gap (no employee-level T&E): DP-057 may take salesperson T&E "
               "from this product (CD-343). If 44 is dropped, the T&E family should move to 19 and this product "
               "with it (CD-345)."),
]

DECISIONS = [
    {"id": "CD-340", "theme": "Transactions & Measures",
     "title": "Certified P&L and operating expense are published once, from the 19 ledger (DP-191); distribution revenue stays DP-012 and reconciles to it",
     "domains": ["19", "10", "06"],
     "issue": "CD-293 proposes P&L and operating expense (19) as a certified family. DP-012 already publishes certified fee "
              "and distribution revenue by share class and mandate, and DP-056 and DP-035 report distribution expense. "
              "Without a rule the semantic layer could publish two revenue numbers and three expense numbers.",
     "resolution": "Proposed: DP-191 General Ledger Journals & Balances is the certified source of booked P&L and operating "
                   "expense at ledger x account combination x fiscal period, mapped to statement lines through DP-190. "
                   "DP-012 stays the certified management revenue by share class and mandate; its GL reconciliation "
                   "control must tie to DP-191 revenue lines, and a difference is a reconciling item, not a second "
                   "number. DP-056, DP-035, DP-057 and DP-194 take actual expense from DP-191 by cost center and never "
                   "re-aggregate GL postings into a differently defined actual. Financial statement line values (DP-193) "
                   "must equal mapped DP-191 balances.",
     "rationale": "Plan §4 item 3; semantic_model/CONTRACT.md (a certified metric is defined once); same pattern as CD-292.",
     "action": "SME decision", "status": "Proposed", "priority": "High", "owner_role": "Finance Controller"},
    {"id": "CD-341", "theme": "Transactions & Measures",
     "title": "Certified headcount and FTE are published once, from the Employee & Position Master (DP-192)",
     "domains": ["20", "10", "19", "07"],
     "issue": "CD-293 proposes headcount and FTE (20) as a certified family. Headcount is counted today in DP-056 (Cost per "
              "Head) and DP-009 (active salespeople), FTE is planned on 19 Financial Plan Line and authorized on 20 "
              "Workforce Position, and 20 Human Capital Metric Value can hold published headcount rows.",
     "resolution": "Proposed: DP-192 publishes certified Headcount (workers with Employment Status active at the period end, "
                   "split by Employment Type, contingent workers reported separately and excluded from employee headcount) "
                   "and certified FTE (sum of Assignment FTE of primary job assignments effective at the period end). "
                   "DP-056, DP-194, DP-197 and DP-201 take both from DP-192. Planned FTE (19) and Authorized FTE (20) are "
                   "plan and authorization measures compared with them, not alternative headcounts. Human Capital Metric "
                   "Value rows for headcount must equal DP-192. DP-009 keeps its sales-role counts (Active Producing "
                   "Salespeople), which are a sales measure, not headcount.",
     "rationale": "Plan §4 item 3; one definition of headcount for HR, FP&A and distribution.",
     "action": "SME decision", "status": "Proposed", "priority": "High", "owner_role": "Chief Human Resources Officer"},
    {"id": "CD-342", "theme": "Enterprise Structure",
     "title": "DP-009's employee dimension re-pointed to the Employee & Position Master (DP-192); other distribution readers of 20 Employee follow",
     "domains": ["20", "03", "07", "08", "14", "38"],
     "issue": "Plan §7 E1 re-points DP-009 Sales Organization & Coverage's employee dimension to the new 20 product. DP-009 "
              "conforms Employee from 20 today (and its notes still say the HR record is mastered in 09, pre CD-151), and "
              "DP-039, DP-044, DP-078, DP-082 and DP-083 read 20 Employee directly.",
     "resolution": "Proposed (Wave E1): DP-192 conforms the Employee for the firm (all workers, job, position, assignment, "
                   "org placement, lifecycle). DP-009 adds DP-192 upstream, keeps its 20 inputs as lineage taken through "
                   "DP-192, and publishes only the sales-role subset with the 03 Sales Person profile, 07 coverage and 08 "
                   "registration status; it no longer conforms Employee. DP-009's note is corrected from 09 to 20. "
                   "DP-039 and DP-082 keep DP-009 as their employee source (sales staff); DP-044, DP-078 and DP-083, "
                   "which cover all staff, add DP-192 upstream. SM-00 Employee is sourced from DP-192 and Salesperson "
                   "stays a role-filtered view from DP-009.",
     "rationale": "Plan §3 (existing products change by a logged decision) and §7 E1; CD-151, CD-144.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Chief Data Officer"},
    {"id": "CD-343", "theme": "Enterprise Structure",
     "title": "Distribution finance products take GL inputs through the 19 foundational products",
     "domains": ["19", "10", "44"],
     "issue": "DP-012, DP-056, DP-074 and DP-089 read 19 Journal Entry, GL Posting, Accounting Period Status and Financial "
              "Statement Line Mapping directly (re-pointed by lineage under CD-152) with no foundational upstream. DP-057 "
              "records a taxonomy gap for employee-level travel and expense that 44 now fills.",
     "resolution": "Proposed (Wave E1 lineage, no change of grain or measures): DP-012, DP-056, DP-074 and DP-089 add DP-190 "
                   "and DP-191 upstream and keep their 19 inputs as lineage taken through them. Optional Wave E4 extension: "
                   "DP-057 takes salesperson travel and expense from DP-209 and closes its T&E gap; DP-074 becomes an "
                   "upstream of DP-196 for transfer pricing evidence.",
     "rationale": "Data_Products_Approach.md: consumer products build on foundational ones; plan §3 guardrail.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Distribution Finance"},
    {"id": "CD-344", "theme": "Enterprise Structure",
     "title": "People products are separated by personal data tier: master, compensation, special category",
     "domains": ["20", "44"],
     "issue": "20 flags 172 of 240 attributes PII, 12 of them special category (diversity, health, criminal records). A "
              "product boundary drawn only by business topic would put compensation or diversity data in front of every "
              "consumer of the employee dimension.",
     "resolution": "Proposed: DP-192 publishes identity, job, position, placement and lifecycle (Confidential - Personal "
                   "Data) with Employee Personal Detail only as a restricted extension, and no pay or diversity data. Pay "
                   "and awards are published only by DP-198 and DP-199 (Confidential - Compensation). Diversity data is "
                   "read only by DP-201, which releases aggregates with minimum cell sizes. Background screening results, "
                   "medical leave types (DP-197) and health and safety incidents (DP-208) are restricted views. Any new "
                   "product that needs one of these tiers takes it from the product named here.",
     "rationale": "GDPR Articles 9 and 10, UK GDPR, state privacy law; Data_Products_Approach.md §7 (privacy review of PII products).",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Data Protection Officer"},
    {"id": "CD-345", "theme": "Enterprise Structure",
     "title": "Product disposition if 43 is folded into 19 or 44 is dropped",
     "domains": ["43", "44", "19"],
     "issue": "areas.OPTIONAL_DOMAINS flags 43 (fold into 19 if no separate treasury function, CD-278) and 44 (low priority). "
              "The briefs must say what happens to their products in either case.",
     "resolution": "Proposed: if 43 folds, DP-202 to DP-206 keep their IDs, names and scope; owning domain becomes 19, owner "
                   "roles move to the Finance treasury lead, FN-40 is merged into FN-38 or kept as a sub-function, and no "
                   "product merges with a 19 product (the 43 names were drafted to be unique in 19). If 44 is dropped, "
                   "DP-207 and DP-208 are withdrawn; Lease Accounting Measurement moves to 19 (CD-279) and is read by "
                   "DP-193; the T&E family should move to 19 so that DP-209 survives with owning domain 19, otherwise it "
                   "is withdrawn and DP-057's T&E gap reopens.",
     "rationale": "Plan §9 acceptance criterion 3 (a domain owns a product or the log says why not).",
     "action": "SME decision", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Financial Officer"},
    {"id": "CD-346", "theme": "Transactions & Measures",
     "title": "Seed position value is a treasury measure, never AUM; seeded fund net assets count in Firm AUM through 27",
     "domains": ["43", "27", "06", "30"],
     "issue": "DP-204 values seed positions from 06 units, 27 NAV per share and 30 capital balances; Firm AUM (CD-292) is "
              "fund net assets from 27. A seed value published beside AUM could be added to it.",
     "resolution": "Proposed: DP-204 publishes Seed Position Value and firm ownership share as treasury and consolidation "
                   "measures only. Firm AUM includes seeded funds' net assets in full (27); the firm-capital share is a "
                   "reconciling attribute for the Wave E5 Firm AUM Reconciliation, never an addition. DP-193 reads the "
                   "ownership share for the consolidation trigger and does not revalue seed.",
     "rationale": "CD-292, CD-276; a certified number is defined once.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Group Treasurer"},
    {"id": "CD-347", "theme": "Transactions & Measures",
     "title": "Three compensation numbers, three owners: incentive earned (DP-033), compensation paid (DP-198), compensation expense (DP-191)",
     "domains": ["07", "20", "19"],
     "issue": "Sales incentive pay is calculated in 07 (DP-033), paid through 20 payroll and posted to 19 in summary per "
              "payroll run. Each layer can be summed by employee or cost center and called 'compensation'.",
     "resolution": "Proposed: incentive earned and accrued stays DP-033's measure; compensation paid by employee and run is "
                   "DP-198's, reconciled run by run to payroll journals; compensation expense by cost center and period is "
                   "DP-191's certified operating expense. DP-057 Compensation Cost and DP-198 compare against these and do "
                   "not redefine them.",
     "rationale": "CD-151 (07 sends payroll instructions to 20); payroll posts in summary (19 Source_Notes, lead decision 1).",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Reward"},
]
