"""Wave E0 product brief proposals: Corporate Functions B (risk, compliance, legal, procurement, technology and
communications). Data Domains 37, 38, 39, 40, 41 and 42.

Brief: 00_Program/Expansion/Product_Briefs/Corporate_Risk_Compliance_Legal_and_Technology.md
Reserved product IDs DP-210 to DP-239 (DP-239 left unused as slack for review); reserved decision IDs CD-350 to CD-359.
Check: python data_products/candidate_coverage.py proposals_dp_corporate_b (from _tools).

Upstream entries that are not DP- ids name Wave E1 foundational candidates of other briefs by the plan's names
(Data_Products_Expansion_Plan.md §7.1): Employee & Position Master (20), Chart of Accounts & Ledger (19), Security Master
& Identifiers and Issuer Hierarchy & Classifications (17), Portfolio Master & Mandate Link and Holdings, Tax Lots & Cash
(18), Approved Broker & Counterparty Master (25), Governance Metadata & Enterprise Catalog (21).

Briefs accepted 2026-10-08: DECISIONS below are merged into decisions.py (kept here as the record of the proposal);
CANDIDATES remain the input to Waves E1 to E4 (read by data_products/candidate_coverage.py).
"""

EMP = "DP-192"   # Employee & Position Master
GL = "DP-190"   # Chart of Accounts & Ledger
SECM = "DP-097"   # Security Master & Identifiers
ISSR = "DP-098"   # Issuer Hierarchy & Classifications (DP-098 Issuer Hierarchy, Classifications & Ratings)
PORT = "DP-140"   # Portfolio Master & Mandate Link
HOLD = "DP-142"   # Holdings, Tax Lots & Cash
BRKR = "DP-115"   # Approved Broker & Counterparty Master
CAT21 = "DP-101"   # Governance Metadata & Enterprise Catalog

CANDIDATES = [
    # ======================================= Foundational (Wave E1) =======================================
    dict(id="DP-210", name="Vendor Master", tier="Foundational", type="Master & Reference", domain="40",
         owner_role="Head of Procurement", primary="FN-46",
         supporting=["FN-42", "FN-33", "FN-17", "FN-50", "FN-38", "FN-51", "FN-34", "FN-15"], wave="E1",
         definition="The conformed record of every supplier of every group entity: the 02 party in the supplier role "
                    "with its ERP supplier number, dated supplier status and onboarding outcome, each supplier "
                    "engagement (VENG-) with its buying entity, business owner, procurement category, inherent "
                    "criticality tier and the 39 contract that governs it, and the link to the specialized data "
                    "vendor (14), servicing provider (13), custody provider (28) or fund service provider role (01). "
                    "It is the Vendor dimension of SM-00 (CD-296), so procurement, third-party risk, finance, the "
                    "DORA register and the fund service provider oversight products count the same supplier once.",
         objects=[("40", "Supplier Profile"), ("40", "Supplier Onboarding Case"), ("40", "Supplier Engagement"),
                  ("40", "Supplier Category Assignment"), ("40", "Supplier Risk Tiering"),
                  ("40", "Supplier Contract Profile"), ("02", "Party"), ("02", "Party Role"),
                  ("14", "Data Vendor"), ("13", "Servicing Provider Engagement")],
         upstream=["DP-213", "DP-013", EMP, "DP-240"],
         notes="Conforms the concept ownership rows Supplier Profile (40, keyed by 02 PTY-) and Supplier Engagement "
               "(40, VENG-), with Supplier Risk Tiering and Supplier Contract Profile as dated attributes of the "
               "engagement. Party name, LEI and address are read from 02 Party, never copied (CD-143, CD-260). "
               "Remittance bank details are deliberately left out of the shared dimension and published only in "
               "DP-221. No residual risk rating here: that is 37's (CD-248). Outsourced procurement (CD-297): the "
               "grain is unchanged; the source is the provider's procurement suite extract."),

    dict(id="DP-211", name="Application & System Inventory", tier="Foundational", type="Master & Reference",
         domain="41", owner_role="Chief Information Officer", primary="FN-51",
         supporting=["FN-50", "FN-49", "FN-42", "FN-46", "FN-17", "FN-45", "FN-48"], wave="E1",
         definition="The enterprise inventory of applications (APPL-), including provider-hosted platforms of "
                    "outsourced functions, with owners, criticality and security categorization, business capability "
                    "mappings, lifecycle (TIME) assessments, interfaces, recovery profiles, AI system facts, the IT "
                    "services they deliver and the configuration items that run them. It is the system of record "
                    "that every Data Domain cites (CD-263) and the Application dimension of SM-00, so lineage, "
                    "resilience mapping, access, incidents, the DORA register and legal holds resolve to one "
                    "application key.",
         objects=[("41", "Application"), ("41", "Application Ownership Assignment"),
                  ("41", "Application Capability Mapping"), ("41", "Application Lifecycle Assessment"),
                  ("41", "Application Interface"), ("41", "Application Recovery Profile"), ("41", "IT Service"),
                  ("41", "Configuration Item"), ("41", "Configuration Item Relationship"),
                  ("41", "AI System Profile"), ("41", "AI System Use Case Link")],
         upstream=["DP-210", "DP-013", EMP],
         notes="Conforms the concept ownership rows Application (41, APPL-), IT Service (41) and Configuration Item "
               "(41, CFGI-). Which application is authoritative for a taxonomy element is 21 System of Record "
               "Designation, published by the 21 Governance Metadata & Enterprise Catalog product, which takes its "
               "application keys from this product; this product must not list that one as upstream (no cycle). "
               "Outsourced platforms (CD-147, CD-297) are inventoried with hosting model Provider-Hosted; the grain "
               "does not change."),

    dict(id="DP-212", name="Model Inventory & Validation", tier="Foundational", type="Master & Reference",
         domain="37", owner_role="Head of Model Risk", primary="FN-42",
         supporting=["FN-50", "FN-30", "FN-31", "FN-28", "FN-21", "FN-23", "FN-24", "FN-08", "FN-43"], wave="E1",
         definition="The registry of every quantitative, AI and trading-algorithm model the firm uses (MODEL- x "
                    "version): purpose, owner, vendor, use status, dated tier with materiality, complexity and "
                    "uncertainty, validation history with outcomes and conditions, ongoing performance monitoring "
                    "breaches and the applications that deploy each version. Under CD-294 it is the reference every "
                    "data product that publishes a score, forecast or recommendation cites by model ID, version and "
                    "run date, so model risk can see which products depend on an unvalidated or breached model.",
         objects=[("37", "Model Inventory Entry"), ("37", "Model Tier Assignment"), ("37", "Model Validation"),
                  ("37", "Model Performance Monitoring"), ("41", "AI System Model Deployment")],
         upstream=["DP-211", EMP],
         notes="Conforms the concept ownership row Model Inventory Entry (37, MODEL-) with its tier, validation and "
               "monitoring objects (CD-246). It holds no list of uses (37 holds none); product-to-model usage is "
               "built from the consuming specs' notes and the 21 catalog export (CD-295). Scores and forecasts stay "
               "measures of the products that compute them (CD-294). Proposed decision CD-352 re-points the "
               "distribution model-based products to this product."),

    dict(id="DP-213", name="Enterprise Contract Register", tier="Foundational", type="Master & Reference",
         domain="39", owner_role="General Counsel", primary="FN-45",
         supporting=["FN-46", "FN-04", "FN-17", "FN-36", "FN-26", "FN-40", "FN-48", "FN-38"], wave="E1",
         definition="One record of every executed legal instrument of the group (CTRCT-): family and subtype, "
                    "hierarchy and amendments, contracting entity or fund, parties and their roles, signatories, "
                    "document versions, key dates and notice periods, negotiated clause positions, and the typed "
                    "record (distribution agreement, data license, trading agreement, advisory agreement, side "
                    "letter, supplier contract, lease and others) that keeps its commercial terms. It gives every "
                    "product one contract key and one set of dates, status and governing law under the row rule of "
                    "CD-257.",
         objects=[("39", "Contract"), ("39", "Typed Contract Link"), ("39", "Contract Party"),
                  ("39", "Contract Signatory"), ("39", "Contract Document Version"), ("39", "Contract Key Date"),
                  ("39", "Contract Clause Position")],
         upstream=["DP-013", EMP, "DP-240"],
         notes="Conforms the concept ownership row Contract (39, CTRCT-) and its parts. Row rule (CD-257, CD-289): "
               "on typed rows the dates, status, governing law and parties are derived copies of the typed record "
               "(05, 14, 26, 28, 30, 35, 01, 10, 16, 43, 44) and the product publishes them as received; it does "
               "not publish commercial terms. Not in the plan's Wave E1 list: proposed decision CD-354 adds it, "
               "because 40, 41, 42, 43, 44, 28 and 20 all key to CTRCT-."),

    # ======================================= 37 Enterprise & Operational Risk =======================================
    dict(id="DP-214", name="Enterprise Risk Profile, Controls & KRIs", tier="Consumer-aligned", type="Analytical",
         domain="37", owner_role="Head of Operational Risk", primary="FN-42",
         supporting=["FN-43", "FN-44", "FN-38", "FN-40", "FN-13", "FN-51"], wave="E4",
         definition="The firm's risk profile at enterprise risk x assessment period: inherent and residual ratings "
                    "against appetite, the controls that mitigate each risk with their latest test results by line "
                    "of defense, RCSA campaign completion, and key risk indicators against their amber and red "
                    "thresholds. It is the risk and control dimension other risk, compliance and audit products "
                    "join to, and tells the risk committee which risks are outside appetite and which key controls "
                    "are failing.",
         objects=[("37", "Risk Taxonomy Category"), ("37", "Enterprise Risk"), ("37", "Risk Assessment"),
                  ("37", "Risk Appetite Statement"), ("37", "RCSA Campaign"), ("37", "Control"),
                  ("37", "Risk Control Link"), ("37", "Control Test"), ("37", "Key Risk Indicator"),
                  ("37", "KRI Threshold"), ("37", "KRI Observation"), ("21", "Metric Definition")],
         upstream=["DP-013", EMP, CAT21],
         notes="Control executions in 06, 07, 10, 19, 27, 29 and 33 are sampled by Control Test as evidence keys; "
               "the product copies no execution result (CD-243). A KRI defined on a 21 Metric Definition reads the "
               "definition from the 21 catalog product; the observed value is 37's. If a KRI is a certified metric "
               "(for example a liquidity or headcount measure), the KRI Observation must equal the certified value "
               "for the date (CD-293)."),

    dict(id="DP-215", name="Operational Incidents, Losses & Regulatory Notifications", tier="Consumer-aligned",
         type="Regulatory & Control", domain="37", owner_role="Head of Operational Risk", primary="FN-42",
         supporting=["FN-51", "FN-38", "FN-40", "FN-33", "FN-23", "FN-32", "FN-45", "FN-35", "FN-19"], wave="E4",
         definition="Every operational incident with its typed source records (trade errors, NAV errors, "
                    "investment breaches, IT and physical security incidents and others), Basel classification, "
                    "DORA major-incident classification and authority notifications against their deadlines, and "
                    "the loss events with gross firm-borne loss, client impact and insurance recovery. It lets "
                    "operational risk see what went wrong, what it cost and whether every regulator was notified in "
                    "time, without counting a loss twice.",
         objects=[("37", "Operational Incident"), ("37", "Incident Source Record"), ("37", "Incident Classification"),
                  ("37", "Incident Regulatory Notification"), ("37", "Operational Loss Event"),
                  ("37", "Loss Event Amount"), ("41", "IT Incident"), ("43", "Insurance Claim"),
                  ("25", "Trade Error"), ("27", "NAV Error Case"), ("33", "Investment Breach"),
                  ("19", "Journal Entry")],
         upstream=["DP-214", "DP-211", "DP-013", "DP-191", EMP],
         notes="One loss, one home (CD-244): Loss Event Amount rows with a source record are derived copies of 25, "
               "27, 33, 26, 13 and 16 amounts and are published as received. Losses are operational measures that "
               "reconcile to the 19 GL evidence journal, not P&L (proposed CD-353). DORA and FCA SUP 15 reports are "
               "37 rows (CD-245); the 41 IT incident is read only as the cause."),

    dict(id="DP-216", name="Risk Issues & Remediation Tracker", tier="Consumer-aligned", type="Operational",
         domain="37", owner_role="Head of Operational Risk", primary="FN-42",
         supporting=["FN-43", "FN-44", "FN-51", "FN-46", "FN-45", "FN-36"], wave="E4",
         definition="One tracker of every risk issue and its actions, whatever raised it: audit findings, "
                    "regulatory examination findings, compliance program reviews, incidents, failed control tests, "
                    "model validations, third-party assessments, resilience tests and vulnerability findings, with "
                    "owners, due dates, overdue actions and risk acceptances nearing expiry. It is the single "
                    "remediation status that audit, compliance, technology and the boards read.",
         objects=[("37", "Risk Issue"), ("37", "Issue Action"), ("37", "Audit Finding"),
                  ("38", "Examination Finding"), ("41", "Vulnerability Finding"), ("37", "Model Validation"),
                  ("37", "Third-Party Risk Assessment"), ("37", "Control Test"), ("37", "Operational Incident")],
         upstream=["DP-214", "DP-212", EMP, "DP-013"],
         notes="Source objects are read for their keys, ratings and dates only. Proposed decision CD-356: every "
               "product in this group reports remediation status from this product and does not compute its own."),

    dict(id="DP-217", name="Operational Resilience & Impact Tolerances", tier="Consumer-aligned",
         type="Regulatory & Control", domain="37", owner_role="Head of Operational Resilience", primary="FN-42",
         supporting=["FN-51", "FN-46", "FN-47", "FN-48", "FN-33", "FN-35"], wave="E4",
         definition="Important business services and critical or important functions with their impact "
                    "tolerances, the people, applications, IT services, sites, suppliers and data assets each "
                    "depends on, business impact analyses, continuity plans and resilience test results against "
                    "tolerance. It answers the UK operational resilience self-assessment and the DORA critical "
                    "function questions: can each service stay within tolerance, and which dependencies have no "
                    "tested recovery.",
         objects=[("37", "Important Business Service"), ("37", "Impact Tolerance"),
                  ("37", "Critical or Important Function"), ("37", "Resilience Resource Mapping"),
                  ("37", "Business Impact Analysis"), ("37", "Business Continuity Plan"), ("37", "Resilience Test"),
                  ("41", "Application Recovery Profile"), ("41", "Security & Resilience Test"),
                  ("40", "Outsourcing Arrangement")],
         upstream=["DP-211", "DP-210", "DP-214", "DP-013", EMP],
         notes="CD-249 and CD-270: recovery tier, RTO and RPO of an application come from 41 through DP-211; the "
               "37 BIA holds the business requirement. The gap between them is the product's main measure."),

    dict(id="DP-218", name="Internal Audit Universe, Plan & Findings", tier="Consumer-aligned", type="Analytical",
         domain="37", owner_role="Chief Audit Executive", primary="FN-43",
         supporting=["FN-42", "FN-45", "FN-36", "FN-44"], wave="E4",
         definition="The audit universe with inherent audit risk and cycle, the approved audit plan and its "
                    "delivery, engagements with ratings, findings by rating and age, and closure validation "
                    "outcomes, joined to the remediation status of the risk issue each finding raised. It gives the "
                    "Chief Audit Executive and the audit committee coverage against cycle, plan completion and "
                    "overdue or reopened findings.",
         objects=[("37", "Auditable Entity"), ("37", "Audit Plan"), ("37", "Audit Engagement"),
                  ("37", "Audit Finding"), ("37", "Finding Closure Validation"), ("37", "Risk Issue")],
         upstream=["DP-216", "DP-214", "DP-013", EMP],
         notes="Owned by the Chief Audit Executive, not the CRO (CD-247), so the audit opinion is not reshaped by "
               "the risk products it audits. Co-sourced audit (CD-297): the grain is unchanged; Co-Sourced Provider "
               "identifies engagements delivered by the provider."),

    # ======================================= 40 Procurement & Vendor Management =======================================
    dict(id="DP-219", name="Third-Party Oversight: Risk, Performance & Renewals", tier="Consumer-aligned",
         type="Regulatory & Control", domain="40", owner_role="Head of Vendor Management", primary="FN-46",
         supporting=["FN-42", "FN-17", "FN-50", "FN-33", "FN-34", "FN-35", "FN-15", "FN-51", "FN-38"], wave="E4",
         definition="One oversight view per supplier engagement of inherent tier, residual risk by domain, "
                    "performance reviews, service level results and credits, software license true-up exposure and "
                    "the notice and renewal dates of the governing contract. It lets vendor management and "
                    "third-party risk prepare every renewal and exit decision before the notice deadline, and is the "
                    "enterprise product of which DP-073 becomes the data-vendor view (CD-298, proposed CD-350).",
         objects=[("40", "Supplier Engagement"), ("40", "Supplier Risk Tiering"),
                  ("37", "Third-Party Risk Assessment"), ("37", "Third-Party Risk Domain Result"),
                  ("40", "Supplier Performance Review"), ("40", "Contracted Service Level"),
                  ("40", "Service Level Measurement Result"), ("39", "Contract Key Date"),
                  ("41", "Software License Position"), ("14", "Vendor Risk Assessment")],
         upstream=["DP-210", "DP-213", "DP-211", "DP-216", "DP-013"],
         notes="CD-248: tier from 40, residual rating from 37, never copied into each other. Fund service providers "
               "(C-06.10): engagement, tier, risk, contract and exit are here; TA, custody and fund administration "
               "service levels stay in the 13, 28, 29 and 27 products (DP-043 and the Fund Operations brief), per "
               "proposed CD-355. Outsourced function (CD-297): this product is the oversight grain for every "
               "outsourced provider."),

    dict(id="DP-220", name="Outsourcing & DORA Register of Information", tier="Consumer-aligned",
         type="Regulatory & Control", domain="40", owner_role="Head of Procurement", primary="FN-46",
         supporting=["FN-42", "FN-51", "FN-44", "FN-17", "FN-33", "FN-36", "FN-18"], wave="E4",
         definition="The outsourcing register with exit plans and regulator notifications, and the DORA register of "
                    "information at the grain of each ITS template (arrangement header, entity and function entries, "
                    "ICT supply chain), including the data-vendor rows from 14. It produces the register each EU "
                    "financial entity submits and the outsourcing notifications FCA, CSSF and the Central Bank "
                    "expect, and shows which critical or important functions rest on a non-substitutable provider "
                    "without a tested exit plan.",
         objects=[("40", "Outsourcing Arrangement"), ("40", "Exit Plan"), ("40", "Outsourcing Notification"),
                  ("40", "ICT Register Arrangement Header"), ("40", "ICT Register of Information Entry"),
                  ("40", "Supply Chain Subcontractor"), ("40", "Supplier Contract Profile"),
                  ("37", "Critical or Important Function"), ("41", "IT Service"),
                  ("14", "ICT Third-Party Register Entry")],
         upstream=["DP-210", "DP-211", "DP-213", "DP-217", "DP-013"],
         notes="CD-261 and CD-268: 40 masters the register, 14 rows are its data-vendor slice, 41 supplies IT "
               "services and applications, 37 the functions. Delivered as a regulatory report; it is a candidate "
               "input to the Wave E5 Regulatory Filing Data Hub."),

    dict(id="DP-221", name="Source-to-Pay Controls & Supplier Spend", tier="Consumer-aligned", type="Operational",
         domain="40", owner_role="Head of Procurement", primary="FN-46",
         supporting=["FN-38", "FN-12", "FN-48", "FN-51"], wave="E4",
         definition="The purchase-to-pay control chain from sourcing event and award through requisition, purchase "
                    "order, receipt and invoice match to the 19 payable invoice, with remittance-detail verification, "
                    "plus supplier spend by buying entity and fiscal period. It shows procurement and accounts "
                    "payable which invoices are on match hold, which spend bypassed a purchase order or sourcing "
                    "threshold, and where committed spend sits against contract value.",
         objects=[("40", "Sourcing Event"), ("40", "Sourcing Invitation"), ("40", "Sourcing Award"),
                  ("40", "Purchase Requisition"), ("40", "Purchase Order"), ("40", "Purchase Order Line"),
                  ("40", "Goods and Service Receipt"), ("40", "Invoice Match Result"),
                  ("40", "Supplier Remittance Detail"), ("40", "Supplier Spend Summary"),
                  ("19", "Payable Invoice"), ("19", "Payable Invoice Line")],
         upstream=["DP-210", "DP-213", "DP-013", "DP-191", EMP],
         notes="Invoiced and paid amounts are derived copies of 19 (CD-158, CD-260). Supplier spend is an "
               "operational measure that reconciles to 19 accounts payable; certified operating expense is "
               "published only from the 19 Corporate Finance products (CD-293, proposed CD-353). Fund-paid "
               "engagements carry no purchase order. Outsourced P2P (CD-297): grain unchanged, sourced from the "
               "provider's suite."),

    # ======================================= 38 Corporate Compliance & Regulatory Affairs =======================================
    dict(id="DP-222", name="Firm Authorizations, Filings & Ownership Disclosures", tier="Consumer-aligned",
         type="Regulatory & Control", domain="38", owner_role="Head of Regulatory Affairs", primary="FN-44",
         supporting=["FN-36", "FN-18", "FN-45", "FN-23", "FN-21", "FN-13"], wave="E4",
         definition="The calendar and status of every regulated entity's authorizations, state notice filings and "
                    "cross-border passports, its firm-level regulatory filings (Form ADV, Form BD, 13F, 13H, CASS "
                    "CMAR and others) against due dates, and the ownership disclosure determinations (13D / 13G, EU "
                    "and UK major holdings, short positions) with the aggregated percentage and filing outcome. It "
                    "tells regulatory affairs which filings are due or late and which holdings crossed a threshold.",
         objects=[("38", "Entity Authorization"), ("38", "Firm Regulatory Filing"),   # W4: Cross-Border Passport removed (CW-938)
                  ("38", "Ownership Disclosure Determination"), ("18", "Portfolio Holding"),
                  ("17", "Issuer Profile")],
         upstream=["DP-013", HOLD, ISSR, SECM],
         notes="DP-013 keeps publishing Entity Authorization as legal entity reference and DP-041 as cross-border "
               "eligibility (CD-298: DP-013 stays); this product monitors filing obligations and status changes. "
               "Fund filings are 35 (CD-233, CD-251) and belong to the Fund Operations brief. Holdings are "
               "aggregated from the 18 product; Aggregated Ownership Percentage is mastered in 38."),

    dict(id="DP-223", name="Regulatory Examinations & Change Management", tier="Consumer-aligned",
         type="Operational", domain="38", owner_role="Head of Regulatory Affairs", primary="FN-44",
         supporting=["FN-45", "FN-42", "FN-51", "FN-13", "FN-36", "FN-50", "FN-37"], wave="E4",
         definition="Regulatory examinations, sweeps and inquiries with request items and response timeliness, "
                    "findings and their remediation, and regulatory change items from horizon to compliance date "
                    "with their impact by entity, business line and Data Domain and the projects that deliver them. "
                    "It lets the CCO see which regulator requests are late, which findings are open, and which "
                    "changes with a near compliance date have no impact assessment or delivering project.",
         objects=[("38", "Regulatory Examination"), ("38", "Regulator Request Item"), ("38", "Examination Finding"),
                  ("38", "Regulatory Change Item"), ("38", "Regulatory Change Impact"),
                  ("11", "Regulatory Horizon Item"), ("41", "Project Scope Link"), ("39", "Legal Matter")],
         upstream=["DP-013", "DP-216", "DP-234", EMP],
         notes="CD-253: enforcement is a 39 legal matter referencing the exam; remediation is a 37 risk issue. "
               "CD-267: delivery is held on 41 Project Scope Link. The 11 horizon item is read only as the change "
               "item's source; DP-083 keeps the distribution horizon view."),

    dict(id="DP-224", name="Compliance Program, Policies & Attestations", tier="Consumer-aligned",
         type="Regulatory & Control", domain="38", owner_role="Chief Compliance Officer", primary="FN-44",
         supporting=["FN-13", "FN-36", "FN-41", "FN-43", "FN-51", "FN-18"], wave="E4",
         definition="The firm's compliance program per regulated entity: the regulatory obligations register with "
                    "owners and monitoring controls, the policy library with versions due for review, attestation "
                    "campaigns and completion by population, and the annual compliance program reviews (Rule "
                    "206(4)-7, Rule 38a-1, MLRO report, FINRA 3130) with their conclusions. It is the evidence the "
                    "CCO presents to boards and regulators, and the enterprise product of which DP-083 becomes the "
                    "distribution view (proposed CD-351).",
         objects=[("38", "Regulatory Obligation"), ("38", "Policy"), ("38", "Policy Version"),
                  ("38", "Attestation"), ("38", "Compliance Program Review"), ("37", "Control"),
                  ("20", "Employee")],
         upstream=["DP-013", "DP-214", EMP],
         notes="CD-252: policy library, obligations and attestations are 38. Compliance monitoring tests are 37 "
               "Control Test rows (CD-243) read through DP-214. Attestation completion is computed here once; "
               "DP-083 takes it rather than recomputing (CD-351)."),

    dict(id="DP-225", name="Code of Ethics: Personal Trading, Conflicts & Political Contributions",
         tier="Consumer-aligned", type="Regulatory & Control", domain="38", owner_role="Chief Compliance Officer",
         primary="FN-44", supporting=["FN-41", "FN-47", "FN-05", "FN-13", "FN-25"], wave="E4",
         definition="Code of ethics monitoring for access persons and covered associates: personal accounts, "
                    "holdings and transaction reports against due dates, pre-clearance decisions matched to trades, "
                    "violations and sanctions, outside business activities, political contributions with pay-to-play "
                    "outcomes, and the firm conflicts register with its mitigations. It shows compliance which people "
                    "are late, which trades lacked pre-clearance or hit the restricted list, and which conflicts lack "
                    "an effective mitigation.",
         objects=[("38", "Conduct Population Designation"), ("38", "Personal Trading Account"),
                  ("38", "Personal Securities Report"), ("38", "Reported Personal Holding"),
                  ("38", "Personal Transaction"), ("38", "Pre-Clearance Request"),
                  ("38", "Code of Ethics Violation"), ("38", "Political Contribution"), ("38", "Pay-to-Play Review"),
                  ("38", "Conflict of Interest"), ("38", "Conflict Mitigation"), ("38", "Outside Business Activity")],
         upstream=["DP-227", EMP, SECM, "DP-003", "DP-013"],
         notes="CD-254. Every individual-level output is PII and Restricted; aggregates by entity and population "
               "for wide use. HR sanctions stay in 20. 08 keeps the distribution conflict profile and gifts and "
               "entertainment (DP-038)."),

    dict(id="DP-226", name="AML & Sanctions Program Cases", tier="Consumer-aligned", type="Regulatory & Control",
         domain="38", owner_role="BSA / AML Officer", primary="FN-44",
         supporting=["FN-35", "FN-46", "FN-13", "FN-19", "FN-26"], wave="E4",
         definition="The AML and sanctions program per legal entity and fund: program assessments and independent "
                    "test dates, AML cases from shareholder account alerts, KYC reviews, supplier onboarding and "
                    "trade surveillance, SAR and blocking decisions, and SAR, OFAC and OFSI reports against their "
                    "deadlines. It lets the BSA / AML Officer evidence case timeliness and filing deadlines without "
                    "exposing case detail beyond the restricted population.",
         objects=[("38", "AML Program Assessment"), ("38", "AML Case"), ("38", "AML and Sanctions Report"),
                  ("29", "Account Monitoring Alert"), ("02", "KYC Profile"), ("40", "Supplier Onboarding Case")],
         upstream=["DP-093", "DP-077", "DP-210", "DP-013"],
         notes="CD-201 and CD-255: shareholder account monitoring is 29 (Fund Operations brief), party KYC is 02 "
               "(DP-077), the program, cases and reports are 38. Restricted under SAR confidentiality (31 CFR "
               "1024.320(e)). If the TA runs fund AML (CD-297), the 29 alert is received as provider data and the "
               "case remains 38's."),

    dict(id="DP-227", name="Restricted, Watch & Insider Lists", tier="Consumer-aligned", type="Operational",
         domain="38", owner_role="Head of Compliance Control Room", primary="FN-44",
         supporting=["FN-32", "FN-20", "FN-23", "FN-25", "FN-24", "FN-21"], wave="E4",
         definition="The current and dated content of the firm's restricted, watch and insider lists by issuer and "
                    "instrument, with MNPI escalation decisions, cleansing dates and insider list entries under MAR "
                    "Article 18. It is the one published feed of restricted names that pre-trade investment "
                    "compliance (33), personal trading pre-clearance and research consume intraday.",
         objects=[("38", "Firm Restricted List"), ("38", "Restricted List Entry"), ("38", "MNPI Escalation"),
                  ("38", "Insider List Entry")],
         upstream=[ISSR, SECM, EMP],
         notes="CD-224 and CD-256: 33 Rule Instrument List reads the list by code and stores no members; 23 flags, "
               "38 decides. Classified Restricted - MNPI; watch list content is visible to the control room only."),

    dict(id="DP-228", name="Trade Surveillance & Market Abuse Reporting", tier="Consumer-aligned",
         type="Regulatory & Control", domain="38", owner_role="Head of Compliance Surveillance", primary="FN-44",
         supporting=["FN-23", "FN-32", "FN-13", "FN-22"], wave="E4",
         definition="Trade surveillance alerts by scenario on firm orders, executions and personal transactions, "
                    "their review and disposition, the related communications alert, and suspicious transaction and "
                    "order reports to competent authorities. It shows compliance alert volumes, ageing and outcomes "
                    "by desk and scenario and evidences MAR Article 16 and FINRA surveillance obligations.",
         objects=[("38", "Trade Surveillance Alert"),   # W4: Suspicious Transaction and Order Report removed (CW-938)
                  ("25", "Trade Order"), ("25", "Execution"), ("38", "Personal Transaction"),
                  ("08", "Surveillance Alert")],
         upstream=["DP-227", "DP-078", SECM, BRKR, PORT],
         notes="CD-256 and CD-298: communications surveillance stays in DP-078 (08); this product reads the 08 "
               "alert only through Related Communications Alert and counts no communications alert. Outsourced "
               "surveillance vendor (CD-297): alerts arrive as provider data; the grain is unchanged."),

    # ======================================= 39 Legal & Corporate Governance =======================================
    dict(id="DP-229", name="Legal Matters, Holds & Outside Counsel", tier="Consumer-aligned", type="Analytical",
         domain="39", owner_role="General Counsel", primary="FN-45",
         supporting=["FN-38", "FN-42", "FN-13", "FN-51", "FN-41", "FN-44", "FN-47"], wave="E4",
         definition="Legal matters (litigation, regulatory enforcement, investigations) with parties, events and "
                    "deadlines, ASC 450 and IAS 37 assessments and reserves, outside counsel engagements against "
                    "budget and invoice reductions, legal service request workload, and legal holds with custodian "
                    "acknowledgment and the applications and records where disposal is suspended. It gives the "
                    "General Counsel matter exposure and spend, and evidences that every hold reached its custodians "
                    "and systems.",
         objects=[("39", "Legal Matter"), ("39", "Matter Party"), ("39", "Matter Event"),
                  ("39", "Matter Financial Assessment"), ("39", "Outside Counsel Engagement"),
                  ("39", "Outside Counsel Invoice Review"), ("39", "Legal Service Request"), ("39", "Legal Hold"),
                  ("39", "Legal Hold Custodian"), ("39", "Legal Hold Scope"), ("20", "Employee Lifecycle Event"),
                  ("19", "Payable Invoice")],
         upstream=["DP-213", "DP-211", "DP-013", "DP-191", EMP],
         notes="CD-253 and CD-258. Reserve Amount is Legal's assessment; the booked reserve is the 19 journal and "
               "certified P&L stays with 19 (proposed CD-353). Legal Hold Scope is the source of the 02 and 08 "
               "legal hold indicators that DP-078 and DP-080 read. Classified Restricted - Legal; privileged "
               "matters are excluded from wide aggregates."),

    dict(id="DP-230", name="Entity Governance, Officers & Signing Authority", tier="Consumer-aligned",
         type="Regulatory & Control", domain="39", owner_role="Company Secretary", primary="FN-45",
         supporting=["FN-44", "FN-40", "FN-38", "FN-36", "FN-43"], wave="E4",
         definition="The governance record of each internal legal entity other than fund and general partner "
                    "boards: boards and committees with membership and independence, officer appointments, "
                    "meetings with quorum and minutes status, resolutions with what each approved, statutory filings "
                    "against due dates, powers of attorney and signing authority grants with limits. It tells the "
                    "Company Secretary which entities are short of quorum or late on filings and lets finance and "
                    "treasury check who may sign for which entity and amount.",
         objects=[("39", "Corporate Governing Body"), ("39", "Corporate Body Membership"),
                  ("39", "Corporate Officer Appointment"), ("39", "Corporate Board Meeting"),
                  ("39", "Corporate Resolution"), ("39", "Corporate Resolution Subject Link"),
                  ("39", "Entity Statutory Filing"), ("39", "Power of Attorney"), ("39", "Signing Authority Grant"),
                  ("09", "Internal Legal Entity")],
         upstream=["DP-013", "DP-213", EMP],
         notes="CD-231 and CD-259: fund, fund-management entity and GP boards are 35 (Fund Operations brief). What a "
               "resolution approved is held only on Corporate Resolution Subject Link; other products read approval "
               "dates from here."),

    # ======================================= 41 Technology & Information Security =======================================
    dict(id="DP-231", name="IT Service Management: Incidents, Problems & Changes", tier="Consumer-aligned",
         type="Operational", domain="41", owner_role="Head of IT Service Management", primary="FN-51",
         supporting=["FN-42", "FN-46", "FN-49", "FN-27"], wave="E4",
         definition="IT service performance from the ITSM record: incidents by service, priority and application "
                    "with detection and restoration times and downtime, problems and known errors, and changes with "
                    "approvals, outcomes and the incidents they caused, through releases and deployments. It lets "
                    "the CIO manage service availability and change success and gives operational risk the technical "
                    "facts behind 37 incidents.",
         objects=[("41", "IT Service"), ("41", "IT Incident"), ("41", "Problem Record"), ("41", "Change Request"),
                  ("41", "Change Approval"), ("41", "Release"), ("41", "Release Deployment")],
         upstream=["DP-211", "DP-013", EMP],
         notes="CD-266: 41 holds the technical record; the 37 incident holds the link and the authority reports. "
               "Managed service provider (CD-297): incidents and changes arrive from the provider's ITSM; the grain "
               "is unchanged."),

    dict(id="DP-232", name="Security Incidents, Testing & Vulnerabilities", tier="Consumer-aligned",
         type="Regulatory & Control", domain="41", owner_role="Chief Information Security Officer", primary="FN-51",
         supporting=["FN-42", "FN-44", "FN-45", "FN-15", "FN-43"], wave="E4",
         definition="Security events with attack vector, personal data affected, the Regulation S-P customer "
                    "notification determination and deadline, penetration, TLPT and recovery tests with outcomes, "
                    "and vulnerability findings by severity, known exploitation and remediation deadline. It shows "
                    "the CISO which notices are due, which critical vulnerabilities are past due, and which "
                    "applications have not been tested.",
         objects=[("41", "IT Incident"), ("41", "Security Incident Detail"), ("41", "Security & Resilience Test"),
                  ("41", "Vulnerability Finding")],
         upstream=["DP-211", "DP-216", "DP-013"],
         notes="CD-245, CD-266, CD-270: DORA classification and authority reports are in DP-215; customer notices are "
               "13 / 12 communications; risk acceptance of a vulnerability is a 37 risk issue read from DP-216."),

    dict(id="DP-233", name="Identity, Access & Device Lifecycle", tier="Consumer-aligned",
         type="Regulatory & Control", domain="41", owner_role="Chief Information Security Officer", primary="FN-51",
         supporting=["FN-43", "FN-44", "FN-41", "FN-17", "FN-50", "FN-38"], wave="E4",
         definition="Digital identities, access roles and grants by application with privileged and segregation of "
                    "duties flags, access review campaigns and decisions, and end-user device assignments, joined to "
                    "joiner, mover and leaver events. It evidences that leavers lost access and returned wiped "
                    "devices on time, that privileged access was certified, and that licensed-data entitlements "
                    "match provisioned grants.",
         objects=[("41", "Digital Identity"), ("41", "Application Access Role"), ("41", "System Access Grant"),
                  ("41", "Access Review Campaign"), ("41", "Access Review Decision"), ("41", "IT Asset Assignment"),
                  ("20", "Employee Lifecycle Event"), ("14", "Entitlement")],
         upstream=["DP-211", EMP, "DP-044"],
         notes="CD-265: system access is 41, the person and lifecycle events are 20, licensed-data entitlements stay "
               "14 (DP-044 counts licenses; this product checks provisioning). PII = Y; aggregates by application "
               "and org unit for wide use."),

    dict(id="DP-234", name="Change & Project Portfolio", tier="Consumer-aligned", type="Analytical", domain="41",
         owner_role="Head of Enterprise PMO", primary="FN-51",
         supporting=["FN-37", "FN-44", "FN-38", "FN-50", "FN-01"], wave="E4",
         definition="Change programs and projects with sponsor, phase, milestones against baseline, RAG status, "
                    "budget, actual cost and forecast at completion, and what each delivers: product change "
                    "initiatives, regulatory change items, data products, data quality fixes and applications. It "
                    "lets the PMO and portfolio committee prioritize and see slippage, and lets compliance and "
                    "product development see which commitments depend on a late project.",
         objects=[("41", "Change Program"), ("41", "Project"), ("41", "Project Milestone"),
                  ("41", "Project Status Report"), ("41", "Project Scope Link"),
                  ("36", "Product Change Initiative"), ("19", "Financial Plan Version")],
         upstream=["DP-211", "DP-191", EMP],
         notes="CD-239 and CD-267: launch projects resolve through Project Scope Link; DP-058 keeps launch readiness. "
               "Project cost is an operational measure that reconciles to 19; capitalization and certified expense "
               "stay with 19 (proposed CD-353)."),

    # ======================================= 42 Corporate Communications & Public Affairs =======================================
    dict(id="DP-235", name="Brand Register, Usage Rights & Trademark Protection", tier="Consumer-aligned",
         type="Master & Reference", domain="42", owner_role="Head of Corporate Communications", primary="FN-47",
         supporting=["FN-45", "FN-09", "FN-37", "FN-04"], wave="E4",
         definition="The brand register with brand levels, permitted jurisdictions and standard versions, who may "
                    "use each brand under which contract, and the trademark registrations, docket deadlines and "
                    "license grants that protect it. It shows where a brand is used or permitted without a "
                    "registered mark, which renewals are due, and which licensees use a brand outside their "
                    "authorization.",
         objects=[("42", "Brand"), ("42", "Brand Standard Version"), ("42", "Brand Use Authorization"),
                  ("39", "Trademark Registration"), ("39", "Trademark Docket Deadline"),
                  ("39", "Trademark License Grant")],
         upstream=["DP-213", "DP-013", EMP],
         notes="CD-271 (brand moved from 04 to 42) and CD-259 (trademarks in 39). DP-090 keeps reading 42 Brand as "
               "its brand dimension; it may take it from this product once specified."),

    dict(id="DP-236", name="Media, Coverage & Reputation", tier="Consumer-aligned", type="Analytical", domain="42",
         owner_role="Head of Media Relations", primary="FN-47", supporting=["FN-09", "FN-13", "FN-37", "FN-16"],
         wave="E4",
         definition="Media inquiries with response timeliness, press releases with compliance review and timing, "
                    "coverage by outlet, sentiment, reach and spokesperson, reputation measurements by brand and "
                    "stakeholder group, and corporate events and award entries. It tells corporate communications "
                    "which topics drive coverage and sentiment, whether deadlines were met and whether releases about "
                    "funds in offering were reviewed.",
         objects=[("42", "Media Contact Profile"), ("42", "Media Inquiry"), ("42", "Press Release"),
                  ("42", "Media Coverage Item"), ("42", "Spokesperson Authorization"), ("42", "Reputation Measurement"),
                  ("42", "Corporate Event"), ("42", "Corporate Award Entry"), ("11", "Award")],
         upstream=["DP-235", "DP-036", "DP-004", EMP],
         notes="CD-272: 04 keeps web and social channels (DP-090), 08 the compliance review (DP-036), 11 the fund and "
               "manager award results. Journalist profiles are PII; publish outlet-level aggregates."),

    dict(id="DP-237", name="Issues, Crisis & Internal Communications", tier="Consumer-aligned", type="Operational",
         domain="42", owner_role="Head of Corporate Communications", primary="FN-47",
         supporting=["FN-42", "FN-51", "FN-45", "FN-41", "FN-44"], wave="E4",
         definition="Communications issues by level and trigger (operational incident, IT incident, legal matter, "
                    "health and safety, external event) with statements by audience and release time, crisis "
                    "communication plans and their link to continuity plans, and internal communications with "
                    "audiences reached and aggregate engagement. It shows how quickly the firm spoke to each "
                    "stakeholder group in an issue and whether policy and crisis announcements reached the intended "
                    "staff.",
         objects=[("42", "Communications Issue"), ("42", "Issue Statement"), ("42", "Crisis Communication Plan"),
                  ("42", "Internal Communication"), ("42", "Internal Communication Audience"),
                  ("42", "Internal Communication Engagement"), ("37", "Business Continuity Plan")],
         upstream=["DP-215", "DP-217", "DP-013", EMP],
         notes="CD-272: the issue holds its trigger once; 37, 39, 41 and 44 hold no reference back. Internal "
               "engagement is aggregate only (42 SME question 7)."),

    dict(id="DP-238", name="Corporate Disclosures, Public Policy & Lobbying", tier="Consumer-aligned",
         type="Regulatory & Control", domain="42", owner_role="Head of Government Relations", primary="FN-47",
         supporting=["FN-44", "FN-41", "FN-40", "FN-39", "FN-45"], wave="E4",
         definition="Corporate publications (modern slavery statement, gender pay gap report, MIFIDPRU 8 disclosure, "
                    "tax strategy) against deadlines with their board approval and source figures, public policy "
                    "positions and consultation responses, contacts with officials, trade association dues and "
                    "lobbying portions, and lobbying registrations and LD-2, LD-203 and EU Transparency Register "
                    "reports. It shows which statutory disclosures and lobbying reports are due and that every "
                    "published figure traces to its owning domain.",
         objects=[("42", "Corporate Publication"), ("42", "Publication Source Link"), ("42", "Public Policy Position"),
                  ("42", "Consultation Response"), ("42", "Government Official Contact"),
                  ("42", "Trade Association Membership"), ("42", "Lobbying Registration"),
                  ("42", "Registered Lobbyist"), ("42", "Lobbying Disclosure Report"),
                  ("42", "Lobbying Report Issue Line"), ("38", "Political Contribution"),
                  ("20", "Human Capital Metric Value"), ("43", "Capital Requirement Calculation")],
         upstream=["DP-230", "DP-225", "DP-013", EMP],
         notes="CD-272 and CD-273: 42 publishes, 20, 34, 43 and 44 produce the figures; headcount and capital figures "
               "are read from their owners as certified (CD-293), never recomputed. Political contributions are "
               "38's; LD-203 rows reference them."),
]

DECISIONS = [
    {"id": "CD-350", "theme": "Enterprise Structure",
     "title": "DP-073 Data Vendor Risk & Renewals becomes the data-vendor view of DP-219 Third-Party Oversight",
     "domains": ["14", "40", "37", "39"],
     "issue": "CD-298 proposes that DP-073 becomes the data-vendor slice of the 40 vendor product. DP-073 reads 14 "
              "Vendor Risk Assessment, ICT Third-Party Register Entry and license terms, which now overlap the 40 "
              "engagement, tier and register (CD-260, CD-261) and the 37 residual assessment (CD-248).",
     "resolution": "Proposed: DP-073 keeps its ID, owner (FN-17) and its license-specific measures (license audits, "
                   "back-fees, usage from DP-044, vendor data SLAs and data issues). It gains DP-219 and DP-210 as "
                   "upstream and takes supplier identity, inherent tier, 37 residual risk, contract notice and expiry "
                   "dates and DORA register flags from them on rows where Supplier Engagement.Specialized Data Vendor "
                   "is filled; it stops computing its own risk and renewal dates for those rows. 14 Inherent Risk "
                   "Rating stays mastered in 14 (CD-248 amendment) and is shown beside the 40 tier, not merged.",
     "rationale": "One owner per concept for products as for objects (CD-298); the distribution view keeps what only "
                  "14 knows.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Data Officer"},

    {"id": "CD-351", "theme": "Enterprise Structure",
     "title": "DP-083 Regulatory Obligations, Attestations & Horizon becomes the distribution view of DP-224 "
              "Compliance Program, Policies & Attestations",
     "domains": ["38", "08", "11"],
     "issue": "DP-083 is already owned by 38 (CD-290) but serves FN-13 for distribution entities. The enterprise "
              "compliance program (FN-44) needs the same obligations and attestations for every regulated entity, "
              "plus the policy library and program reviews. Two products computing attestation completion would "
              "publish two numbers.",
     "resolution": "Proposed: DP-224 is the enterprise product; DP-083 keeps its ID, primary function FN-13 and its "
                   "11 horizon view, gains DP-224 as upstream, and takes obligation ownership and attestation "
                   "completion from it, filtered to distribution entities and populations. No change to DP-083's "
                   "name. Regulatory change items (38) are published by DP-223; DP-083 keeps reading 11 horizon items "
                   "only.",
     "rationale": "Same pattern as CD-298 for DP-073 and DP-075; the guardrail (plan §3) requires the change to an "
                  "existing product to be logged.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Compliance Officer"},

    {"id": "CD-352", "theme": "Enterprise Structure",
     "title": "Model-based distribution products cite DP-212 Model Inventory & Validation",
     "domains": ["37", "03", "04", "06", "11"],
     "issue": "CD-294 makes the 37 model inventory the registry for every scoring, forecasting and recommendation "
              "model. DP-018, DP-046 and DP-047 record a 'no model registry' taxonomy gap; DP-049, DP-052 and DP-055 "
              "also publish estimates, intent scores or forecasts from a model.",
     "resolution": "Proposed: each of these products gains DP-212 as upstream by lineage, records its model ID and "
                   "version in notes, and its score or forecast measures carry the model reference and run date. The "
                   "'no model registry' gaps of DP-018, DP-046 and DP-047 are re-triaged as closed by CD-294. New enterprise products that publish "
                   "scores (31 risk models, 32 attribution models, 22 valuation models, 34 ESG scores) do the same in "
                   "their specs.",
     "rationale": "CD-294 and CD-246; a foundational product makes the registry joinable.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Model Risk"},

    {"id": "CD-353", "theme": "Transactions & Measures",
     "title": "Corporate cost and loss measures in 37 to 42 products are operational views that reconcile to 19",
     "domains": ["19", "37", "39", "40", "41"],
     "issue": "Supplier spend (40), project actual cost (41), outside counsel spend and legal reserves (39) and "
              "operational losses (37) are money amounts that also land in the 19 ledger, whose P&L and operating "
              "expense are certified (CD-293).",
     "resolution": "Proposed: DP-215, DP-219, DP-221, DP-229 and DP-234 publish these amounts as operational "
                   "measures under their own names (Supplier Spend, Project Actual Cost, Outside Counsel Approved "
                   "Amount, Legal Reserve Assessed, Gross Operational Loss), never as expense or P&L, and each carries "
                   "a reconciliation measure to the 19 figure it should match (payable invoices, GL evidence journal, "
                   "reserve journal entry). The semantic layer publishes certified expense only from the 19 product.",
     "rationale": "A certified number is defined once (semantic_model/CONTRACT.md, CD-293).",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Finance Controller"},

    {"id": "CD-354", "theme": "Enterprise Structure",
     "title": "Wave E1 gains Model Inventory & Validation (37) and Enterprise Contract Register (39) as foundational "
              "products",
     "domains": ["37", "39", "40", "41"],
     "issue": "Plan §7.1 lists Vendor Master (40) and Application & System Inventory (41) as the corporate risk and "
              "technology foundational products. CD-294 makes the model inventory the registry every scoring product "
              "cites, and CD-257 makes the 39 contract the generic record that 40, 41, 42, 43, 44, 28 and 20 key to.",
     "resolution": "Proposed: DP-212 Model Inventory & Validation and DP-213 Enterprise Contract Register are "
                   "foundational, Wave E1, so that foundational products of other briefs (31 Risk Measures, 25 "
                   "broker master, 30 investor capital accounts) and DP-210 Vendor Master can depend on them. The "
                   "risk register and control library stay consumer-aligned (DP-214); SM-00 gains Model and Contract "
                   "dimensions (CD-296).",
     "rationale": "Foundational products may depend only on foundational products; both registries are needed "
                  "upstream of foundational products.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Data Officer"},

    {"id": "CD-355", "theme": "Fund Operations",
     "title": "Fund service provider oversight: engagement, tier, risk and contract in DP-219; service levels in the "
              "Fund Operations products",
     "domains": ["40", "13", "27", "28", "29", "37"],
     "issue": "C-06.10 Fund Service Provider Oversight masters in 40 and is run by FN-46 with FN-33 supporting. "
              "Service levels of the TA, custodian and fund administrator are measured in 13, 28 and 29 (CD-260 "
              "row rule), and DP-043 already oversees the TA.",
     "resolution": "Proposed: DP-219 publishes every fund service provider's engagement, inherent tier, 37 residual "
                   "risk, contract and exit plan; 40 Contracted Service Level rows exist only where no specialized "
                   "domain measures the service. TA, custody and fund administration service level results and "
                   "board oversight packs are published by DP-043 and the Fund Operations brief's products, which "
                   "take provider identity and tier from DP-210 and DP-219. Under an outsourced model (CD-297) the "
                   "same split holds.",
     "rationale": "Avoids two service level scores for the same provider.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Procurement"},

    {"id": "CD-356", "theme": "Enterprise Structure",
     "title": "One remediation status: DP-216 Risk Issues & Remediation Tracker",
     "domains": ["37", "38", "41"],
     "issue": "Audit findings, examination findings, program reviews, incidents, control tests, model validations, "
              "third-party assessments, resilience tests and vulnerabilities all remediate through a 37 Risk Issue "
              "(CD-247, CD-253, CD-270). Each product that shows its source records could compute its own overdue "
              "count.",
     "resolution": "Proposed: overdue, open and accepted-risk counts of remediation are computed once, in DP-216; "
                   "DP-218, DP-223, DP-224, DP-232, DP-219 and the Wave E5 Enterprise Risk & Control view take them "
                   "from it. Source-specific status (finding closure validation, vulnerability remediation status) "
                   "stays with the source product.",
     "rationale": "The taxonomy already holds the link once on 37; the products follow.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Low", "owner_role": "Head of Operational Risk"},
]
