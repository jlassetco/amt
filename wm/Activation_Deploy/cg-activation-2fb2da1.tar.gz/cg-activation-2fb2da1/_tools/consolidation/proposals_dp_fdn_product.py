"""Wave E0 product brief proposals: Foundations and the product range (Data Domains 17, 21 and 36).

Brief: 00_Program/Expansion/Product_Briefs/Foundations_and_Product_Range.md
Reserved product IDs DP-097 to DP-114 (DP-097 to DP-109 used); reserved decision IDs CD-300 to CD-309 (CD-300 to CD-304
used). Checked with: python data_products/candidate_coverage.py proposals_dp_fdn_product (from _tools).
Upstream names that are not DP- ids are Wave E1 candidates of other briefs, named as the plan names them (§7 E1).

Briefs accepted 2026-10-08: DECISIONS below are merged into decisions.py (kept here as the record of the proposal);
CANDIDATES remain the input to Waves E1 to E4 (read by data_products/candidate_coverage.py).
"""

EMP = "DP-192"   # Employee & Position Master (20, Wave E1)
APP = "DP-211"   # Application & System Inventory (41, Wave E1)
RET = "DP-145"   # Official Returns (32, Wave E1)
NAV = "DP-165"   # NAV & Fund Financials (27, Wave E1)
PORT = "DP-140"   # Portfolio Master & Mandate Link (18, Wave E1)

CANDIDATES = [
    # --- Foundational (Wave E1) ---------------------------------------------------------------------------------------
    dict(id="DP-097", name="Security Master & Identifiers", tier="Foundational", type="Master & Reference", domain="17",
         owner_role="Head of Enterprise Data Management", primary="FN-49",
         supporting=["FN-27", "FN-28", "FN-23", "FN-29", "FN-30", "FN-32", "FN-33", "FN-34", "FN-21", "FN-36"],
         wave="E1",
         definition=("The golden record of every instrument the firm holds, trades, prices or references as an underlying, "
                     "with its identifiers across schemes, listings, asset-class terms, schedules, classifications and "
                     "regulatory eligibility flags, versioned by effective period. It is the one instrument dimension of "
                     "the firm: holdings, prices, orders, settlements, corporate actions, risk and compliance products "
                     "key on its Instrument ID and never build their own."),
         objects=[("17", "Instrument"), ("17", "Instrument Identifier"), ("17", "Instrument Relationship"),
                  ("17", "Instrument Listing"), ("17", "Instrument Classification Assignment"),
                  ("17", "Regulatory Instrument Classification"), ("17", "Equity Terms"),
                  ("17", "Fund Instrument Terms"), ("17", "Debt Terms"), ("17", "Coupon Schedule"),
                  ("17", "Redemption Schedule"), ("17", "Securitized Product Terms"),
                  ("17", "Listed Derivative Contract Terms"), ("17", "OTC Derivative Product Terms"),
                  ("17", "Private Asset Terms"), ("17", "Fund Interest Terms"), ("01", "Benchmark")],
         upstream=["DP-004", "DP-013"],
         notes=("Concept ownership rows: Instrument (security master), Instrument Identifier, Instrument Listing (CD-154). "
                "Own share classes held by own portfolios are 'Own Fund Share Class' rows whose identifiers and fund terms "
                "are Derived copies of 01, conformed through DP-004; DP-097 never re-publishes 01 share class attributes "
                "beyond the instrument key, type and the derived identifiers (CD-300). Excludes prices, evaluated "
                "analytics and pool factors (22, CD-167), internal credit assessments (23, CD-173), ESG data (34), risk "
                "measures (31) and holdings (18). Issuer attributes come from DP-098; the instrument row carries only "
                "the issuer party key. Operating model (CD-297): if security master operations are outsourced (vendor "
                "golden copy or an IBOR provider), the grain is unchanged and the product adds the provider's daily "
                "golden-copy delivery and exception feed as its source; the firm still owns the record.")),
    dict(id="DP-098", name="Issuer Hierarchy, Classifications & Ratings", tier="Foundational", type="Master & Reference",
         domain="17", owner_role="Head of Enterprise Data Management", primary="FN-49",
         supporting=["FN-20", "FN-21", "FN-30", "FN-32", "FN-36", "FN-24", "FN-34"], wave="E1",
         definition=("The issuer dimension: every issuer party with its security-master role profile, legal parent and "
                     "ultimate parent from the party master, the credit parent overrides research maintains, sector "
                     "classifications by scheme, and agency credit ratings of issuers and issues with history. It gives "
                     "concentration limits, exposure reporting, regulatory filings and research one answer to 'who is "
                     "the issuer, who stands behind it, what sector is it and how is it rated'."),
         objects=[("17", "Issuer Profile"), ("17", "Issuer Relationship"), ("17", "Issuer Classification Assignment"),
                  ("17", "Credit Rating Assignment"),
                  ("02", "Party"), ("02", "Organization"), ("02", "Legal Entity Hierarchy"), ("02", "Party Identifier"),
                  ("02", "LEI Record")],
         upstream=["DP-097", "DP-013", "DP-240"],
         notes=("Concept ownership rows: Issuer Profile and Credit Rating Assignment (17, CD-154); the party core stays "
                "02 PTY- (CD-143) and is read from 02, not copied. Publishes both the legal parent (02 Legal Entity "
                "Hierarchy) and the credit parent (17 Issuer Relationship override); which one drives concentration "
                "limits is 17 SME question 6, so both rollups are published and the default is flagged (CD-300). "
                "Agency ratings only; internal credit assessments are 23 (CD-173). If 17 SME question 3 moves credit "
                "ratings to 22, Credit Rating Assignment leaves this product for the 22 prices product. Licensed "
                "sector schemes (GICS, BICS, ICB) and agency ratings are licensed data (14): published only to "
                "entitled consumers.")),
    dict(id="DP-099", name="Corporate Action Event Golden Copy", tier="Foundational", type="Conformed Facts",
         domain="17", owner_role="Head of Enterprise Data Management", primary="FN-49",
         supporting=["FN-34", "FN-27", "FN-24", "FN-21", "FN-33", "FN-28"], wave="E1",
         definition=("The scrubbed golden copy of every announced corporate action event on an instrument the firm holds "
                     "or follows, with its options, key dates, rates and announcement status, including investee "
                     "shareholder meetings. Asset servicing, the book of record, fund accounting and proxy voting work "
                     "from the same event and option keys instead of reconciling custodian and vendor versions."),
         objects=[("17", "Corporate Action Event"), ("17", "Corporate Action Option")],
         upstream=["DP-097", "DP-013"],
         notes=("Concept ownership row: Corporate Action Event (17, CAE-). Event reference only (CD-195): entitlements, "
                "elections and payments are 28 (Fund Operations brief), the position effect is an 18 Portfolio "
                "Transaction, investee ballots and votes are 34 (CD-226). Who scrubs events (security master team or 28 "
                "asset servicing) is 17 SME question 9; the product owner follows the answer. Operating model (CD-297): "
                "if asset servicing is outsourced to the custodian, the custodian's notification becomes a source "
                "(28 Corporate Action Notification Receipt) and this product records which source the golden copy "
                "took per event.")),
    dict(id="DP-100", name="Taxonomy, Glossary & Data Ownership Register", tier="Foundational",
         type="Master & Reference", domain="21", owner_role="Head of Data Governance", primary="FN-50",
         supporting=["FN-17", "FN-49", "FN-51", "FN-42", "FN-44"], wave="E1",
         definition=("The governed register of what the firm's data means and who is accountable for it: the taxonomy "
                     "elements with their release-by-release registrations, the business glossary, the decision log, "
                     "governance bodies, effective-dated ownership and stewardship assignments, critical data elements "
                     "and data classification assignments. Every other product resolves an attribute's meaning, owner, "
                     "CDE status and classification here."),
         objects=[("21", "Taxonomy Element"), ("21", "Taxonomy Release"), ("21", "Taxonomy Element Registration"),
                  ("21", "Business Term"), ("21", "Business Term Relationship"), ("21", "Governance Decision"),
                  ("21", "Data Governance Body"), ("21", "Data Ownership Assignment"),
                  ("21", "Critical Data Element"), ("21", "Data Classification Assignment"),
                  ("09", "Code List")],
         upstream=["DP-013", EMP],
         notes=("Concept ownership rows: Taxonomy Element, Business Term and Governance Decision (21, CD-160, CD-162). "
                "Loaded by the build from the consolidated taxonomy, its baseline and decisions.py (CD-295): the "
                "register is generated, not keyed. Owners and stewards are 20 employees, so PII = Y for the assignment "
                "rows; the published dimension shows role and org unit and restricts names to governance users. Code "
                "lists stay 09 (CD-157) and are read through DP-013. Licensed dataset ownership and classification "
                "are 14's (CD-164) and are not restated.")),
    dict(id="DP-101", name="Governance Metadata & Enterprise Catalog", tier="Foundational",
         type="Master & Reference", domain="21", owner_role="Chief Data Officer", primary="FN-50",
         supporting=["FN-17", "FN-49", "FN-51", "FN-38", "FN-36", "FN-44"], wave="E1",
         definition=("The enterprise catalog of the firm's data estate: cataloged data assets, reports and dashboards, "
                     "physical-to-taxonomy element mappings, lineage links, system of record designations and object "
                     "governance profiles, together with the data product catalog itself (products, inputs, contracts, "
                     "semantic model bindings and registered metric definitions) exported from the build. It is the "
                     "enterprise successor of DP-075: discovery, trust level and change impact for every product and "
                     "asset in every area."),
         objects=[("21", "Data Asset"), ("21", "Analytics Report & Dashboard Detail"), ("21", "Data Element Mapping"),
                  ("21", "Lineage Link"), ("21", "System of Record Designation"), ("21", "Object Governance Profile"),
                  ("21", "Data Product"), ("21", "Data Product Input"), ("21", "Data Contract"),
                  ("21", "Semantic Model Binding"), ("21", "Metric Definition"),
                  ("14", "Dataset"), ("06", "Data Feed"), ("06", "Measure Definition")],
         upstream=["DP-100", "DP-013", APP],
         notes=("Concept ownership rows: Data Asset (catalog entry), Data Product and Metric Definition (21, CD-160, "
                "CD-163). Applies CD-295: Data Product, Data Product Input, Metric Definition, Semantic Model Binding and "
                "Data Contract rows are the build's export of framework.py, the specs and semantic_model/register.py; a "
                "field the 21 objects cannot hold is a taxonomy gap in 21 to fix first. DP-075 becomes the distribution "
                "view of this product (CD-298, CD-301); its 'Taxonomy gap' notes close. Holds metric definitions and "
                "certification status, never metric values: values stay with the owning product (DP-008, DP-012 and the "
                "CD-293 owners), and the Wave E5 Enterprise KPI & Metrics Registry builds on this product (CD-301). "
                "Systems resolve to 41 Application (CD-263) through the 41 Wave E1 product. Licensed datasets are Data "
                "Assets referencing 14 (CD-160, CD-164).")),
    # --- Consumer-aligned -------------------------------------------------------------------------------------------
    dict(id="DP-102", name="Instrument Setup & Security Master Quality", tier="Consumer-aligned", type="Operational",
         domain="17", owner_role="Head of Enterprise Data Management", primary="FN-49",
         supporting=["FN-23", "FN-27", "FN-28", "FN-50", "FN-25"], wave="E2",
         definition=("The security master team's daily work queue and service record: instrument setup requests from "
                     "trading, operations and private markets with their due times, approvals and outcomes, together "
                     "with golden-copy completeness, vendor disagreements, rule results and open vendor data issues on "
                     "instrument data. It shows which setups block a trade, which instruments fail their CDE rules, and "
                     "how fast the team turns requests around."),
         objects=[("17", "Instrument Setup Request"), ("21", "Data Quality Result"), ("14", "Vendor Data Issue")],
         upstream=["DP-097", "DP-098", "DP-099", "DP-100", EMP],
         notes=("Measures setup cycle time against Required By Timestamp, setups completed after first trade, CDE rule "
                "pass rate on 17 objects (rules from DP-103, which owns enterprise DQ), and vendor issues by dataset. PII "
                "= Y for requester and approver (20). Operating model (CD-297): if security master operations are "
                "outsourced, the request queue is the provider's ticket feed and the product becomes SLA oversight with "
                "the same grain.")),
    dict(id="DP-103", name="Enterprise Data Quality, Issues & Certification", tier="Consumer-aligned",
         type="Regulatory & Control", domain="21", owner_role="Head of Data Governance", primary="FN-50",
         supporting=["FN-17", "FN-49", "FN-42", "FN-51", "FN-43"], wave="E2",
         definition=("Data quality across the firm: rule results against thresholds by critical data element, data "
                     "product and asset, open data quality issues by severity, age and owner, record-level quality "
                     "status, and the certification state of products, reports and metrics against their contracts. "
                     "The Chief Data Officer uses it to set DQ priorities, certify products and report data risk to "
                     "enterprise risk and audit."),
         objects=[("21", "Data Quality Rule"), ("21", "Data Quality Result"), ("21", "Data Quality Issue"),
                  ("21", "Record Governance Metadata"), ("21", "Critical Data Element"), ("21", "Data Contract"),
                  ("21", "Analytics Report & Dashboard Detail")],
         upstream=["DP-100", "DP-101", EMP],
         notes=("Boundary with DP-045 (CD-301): DP-045 keeps distribution data supply-chain health (06 feeds, loads, "
                "reconciliations, matching, attribution) and reads its DQ rows filtered to distribution assets; DP-103 is "
                "the enterprise view of rules, results, issues and certification for all 44 Data Domains. Record "
                "Governance Metadata is read as an aggregate (counts by quality status, classification and system of "
                "record per object); record keys are not published, so the product is PII = Y only for issue owners. "
                "Vendor data issues stay 14's (linked, not restated).")),
    dict(id="DP-104", name="AI Use Case Register & Data Usage Approvals", tier="Consumer-aligned",
         type="Regulatory & Control", domain="21", owner_role="Chief Data Officer", primary="FN-50",
         supporting=["FN-42", "FN-44", "FN-51", "FN-45"], wave="E4",
         definition=("The register of the firm's AI and analytics use cases with their EU AI Act and internal risk "
                     "classification, the models and deployed systems behind them, and every approval to use a data "
                     "asset, with the permitted uses, personal data categories, conditions and expiry. It evidences AI "
                     "governance to compliance and risk and stops a use case from running on data it is not approved or "
                     "licensed for."),
         objects=[("21", "AI Use Case"), ("21", "AI Risk Classification"), ("21", "AI Data Usage Approval"),
                  ("37", "Model Inventory Entry"), ("37", "Model Tier Assignment"), ("41", "AI System Profile"),
                  ("41", "AI System Use Case Link"), ("14", "Permitted Use Grant")],
         upstream=["DP-101", "DP-100", APP, EMP],
         notes=("Use case in 21, model in 37, deployed system in 41 (CD-246, CD-269); the product reads 37 and 41 from "
                "their masters and adds no model attributes. Scores and forecasts in other products reference the 37 "
                "model (CD-294); this product shows which use cases they belong to. Wave E4 so that the Corporate B "
                "brief's model inventory and AI system products can be named upstream once they exist. PII = Y (use "
                "case business owners).")),
    dict(id="DP-105", name="Product Proposal Pipeline & Approval Decisions", tier="Consumer-aligned", type="Analytical",
         domain="36", owner_role="Head of Product Development", primary="FN-37",
         supporting=["FN-10", "FN-01", "FN-16", "FN-40", "FN-12"], wave="E3",
         definition=("The product development pipeline from idea to decision: proposals by stage and age, business case "
                     "versions with projected AUM, revenue, breakeven and seed requirement, the market evidence they "
                     "cite, and every product governance committee meeting and decision with conditions. Product "
                     "leadership uses it to steer the range plan, and the committee uses it to see what is coming, what "
                     "it approved and which conditions are still open."),
         objects=[("36", "Product Proposal"), ("36", "Proposal Stage History"), ("36", "Product Business Case"),
                  ("36", "Business Case Market Evidence"), ("36", "Product Governance Committee"),
                  ("36", "Product Committee Membership"), ("36", "Product Committee Meeting"),
                  ("36", "Product Approval Decision")],
         upstream=["DP-004", "DP-014", "DP-013", EMP],
         notes=("Business case figures are projections, never certified numbers; realized flows, AUM and revenue for "
                "launched products come from DP-008 and DP-012 when the pipeline is compared with outcomes (CD-303). The "
                "committee is a management committee, never a fund board (CD-237); board approvals are read from 35 "
                "through DP-106. Seed capital approval is 43 (CD-276). Proposals not yet public are Restricted - MNPI "
                "where the parent is listed. PII = Y (sponsors and committee members).")),
    dict(id="DP-106", name="Product Change Calendar & Regulatory Clock", tier="Consumer-aligned", type="Operational",
         domain="36", owner_role="Head of Product Development", primary="FN-37",
         supporting=["FN-36", "FN-15", "FN-35", "FN-33", "FN-10", "FN-13", "FN-04", "FN-12", "FN-19"], wave="E3",
         definition=("Every approved and in-flight change to the product range (launches, share class additions, fee, "
                     "name, objective and benchmark changes, closes and substitutions) with the products and classes in "
                     "scope, proposed terms and new class specifications, and each filing, vote, notice and approval the "
                     "change needs against its due date. Fund legal, transfer agency, fund accounting, distribution and "
                     "partner teams work from one dated calendar of what changes when, and see which regulatory "
                     "requirement is late."),
         objects=[("36", "Product Change Initiative"), ("36", "Changed Product Scope"), ("36", "Proposed Term Change"),
                  ("36", "Share Class Specification"), ("36", "Change Regulatory Requirement"),
                  ("35", "Fund Regulatory Filing"), ("35", "Resolution Subject Link"), ("13", "Shareholder Notice"),
                  ("41", "Project")],
         upstream=["DP-004", "DP-013", APP],
         notes=("36 holds proposed values only; after the effective date the 01 record is the master again and DP-004 "
                "shows it (CD-236). Requirement status follows the 36 row rule (five evidence groups; filings from 35, "
                "CD-233; board and trustee approvals through 35 Resolution Subject Link, CD-237; shareholder notices and "
                "proxies from 13). The 35 filings and 13 notices are read from their masters until the Fund Operations "
                "brief names its filing products. Changes approved but not announced are Restricted - MNPI where the "
                "parent is listed.")),
    dict(id="DP-107", name="Product Launch Readiness & Go / No-Go", tier="Consumer-aligned", type="Operational",
         domain="36", owner_role="Head of Product Development", primary="FN-37",
         supporting=["FN-10", "FN-33", "FN-34", "FN-35", "FN-28", "FN-32", "FN-40", "FN-04"], wave="E3",
         definition=("The enterprise readiness plan for each launch, share class addition and conversion: plan dates "
                     "(seed, first NAV, listing), every readiness check by workstream with its owner, due date, status "
                     "and the set-up record that evidences it in the owning domain, and the go / no-go decision. "
                     "Launch project managers and the product committee see which operational workstream will miss the "
                     "launch date before it does."),
         objects=[("36", "Product Readiness Plan"), ("36", "Readiness Check"), ("27", "Fund Accounting Book"),
                  ("28", "Safekeeping Account"), ("29", "TA Control Check"), ("43", "Seed Capital Commitment")],
         upstream=["DP-004", "DP-005", PORT, NAV, EMP],
         notes=("Boundary with DP-058 (CD-302): DP-107 owns readiness up to the go / no-go and the launch date across all "
                "workstreams (fund accounting, custody, TA, pricing, index, rule coding, seed, distribution); DP-058 stays "
                "the distribution go-to-market tracker (trade enablement, approved materials, first sales, days to first "
                "sale) and takes its registration, shelf, listing and document workstream status from the 36 Readiness "
                "Check rows instead of inferring them. Readiness checks reference the set-up record and master none of "
                "it (CD-239). Operating model (CD-297): where fund accounting, custody or TA are outsourced the evidence "
                "is the provider's set-up confirmation, recorded against the same check.")),
    dict(id="DP-108", name="Fund Mergers, Conversions & Liquidations", tier="Consumer-aligned", type="Operational",
         domain="36", owner_role="Head of Product Development", primary="FN-37",
         supporting=["FN-35", "FN-33", "FN-36", "FN-15", "FN-39", "FN-04", "FN-07", "FN-19", "FN-30"], wave="E3",
         definition=("The execution record of fund reorganizations: mergers and shell reorganizations, mutual fund to ETF "
                     "conversions and liquidations, with the successor share class mapping, structure and tax status, "
                     "conversion route and treatment of ineligible accounts, liquidation dates and final distribution "
                     "approach, cost bearer, and the impact assessment by area (accounts, assets, liquidity, foreseeable "
                     "harm). Transfer agency, fund accounting, partners and plan services plan the account and position "
                     "moves from it."),
         objects=[("36", "Fund Reorganization Detail"), ("36", "ETF Conversion Detail"), ("36", "Liquidation Detail"),
                  ("36", "Change Impact Assessment"), ("36", "Changed Product Scope")],
         upstream=["DP-004", "DP-008", "DP-093", "DP-005", NAV],
         notes=("Affected AUM in the impact assessment is a reference to 06; the product shows attributed AUM by "
                "intermediary from DP-008 and fund net assets from the 27 Wave E1 product, and computes neither (CD-292, "
                "CD-303). Accounts affected come from DP-093 (15). Liquidity evidence is a reference to the 31 fund "
                "liquidity profile (Investment Operations brief). Resulting transactions are 29 and 06 (CD-239). Plan "
                "menus the firm recordkeeps (16) need the Retirement Account Default Treatment, so FN-19 supports.")),
    dict(id="DP-109", name="Product Reviews & Value Assessments", tier="Consumer-aligned", type="Regulatory & Control",
         domain="36", owner_role="Head of Product Governance", primary="FN-37",
         supporting=["FN-13", "FN-18", "FN-36", "FN-10", "FN-12"], wave="E3",
         definition=("The manufacturer's record of periodic product reviews: UK assessments of value with the seven "
                     "criteria rated per share class and the evidence behind each rating, Consumer Duty fair value and "
                     "PROD target market reviews, and the actions raised with owners, due dates and the change "
                     "initiatives they trigger. Product governance uses it to run the review calendar and to evidence "
                     "the conclusions to the AFM board and regulators."),
         objects=[("36", "Product Review"), ("36", "Target Market Review Result"),
                  ("36", "Value Assessment Criterion Result"), ("36", "Review Action")],
         upstream=["DP-004", "DP-040", "DP-035", "DP-030", "DP-008", "DP-101", RET],
         notes=("Boundary with DP-040 (CD-303): DP-040 keeps the distributor-side evidence (08 feedback, sales outside "
                "target market, complaints, outcome metrics) and is an input; DP-109 holds the review, criterion "
                "results, conclusions and actions (CD-238). Performance and benchmark returns come from the 32 Official "
                "Returns product, costs from DP-035 profitability, fee comparisons from DP-030, flows from DP-008; none "
                "is recalculated. AFM board approval is a 35 date read through the review. PII = Y (approvers and action "
                "owners).")),
]

DECISIONS = [
    {"id": "CD-300", "theme": "Enterprise Structure",
     "title": "Security master products: DP-097 is the firm's one instrument dimension; issuers and corporate action events are conformed once in DP-098 and DP-099",
     "domains": ["17", "01", "02", "18", "22", "23", "25", "26", "28", "31", "33", "34"],
     "issue": ("CD-154 makes 17 the master of the security master and CD-296 makes SM-00 the one spine, but no rule says "
               "which data product publishes the instrument and issuer dimensions. Six parallel briefs (18, 22, 25, 26, 28, "
               "31, 33, 34) need an instrument dimension and would otherwise each conform their own, and the own share "
               "class held by an own portfolio would appear both as a 01 share class and a 17 instrument."),
     "resolution": ("Proposed: DP-097 Security Master & Identifiers publishes the only instrument dimension (Instrument ID, "
                    "identifiers by scheme, listings, terms, schedules, firm asset-class classification and regulatory "
                    "eligibility flags). Own share classes held by own portfolios appear as 'Own Fund Share Class' rows "
                    "carrying the DP-004 Share Class ID; their identifiers and fund terms are Derived copies of 01 taken "
                    "through DP-004, and DP-004 stays the share class master. DP-098 publishes the issuer dimension (02 "
                    "party core plus the 17 issuer role, both legal and credit parent rollups, sector classifications and "
                    "agency ratings); DP-099 publishes corporate action event and option reference. DP-097 holds no "
                    "prices, analytics or pool factors (22), internal credit assessments (23), ESG data (34), risk measures "
                    "(31) or holdings (18). Every product in the other briefs that slices by instrument, issuer or "
                    "corporate action event names DP-097, DP-098 or DP-099 upstream and does not read the 17 objects to "
                    "build its own dimension."),
     "rationale": ("The governing rule (a product assembles what the Data Domains master and never remasters it) applied "
                   "to the dimension every investment product joins to; the distribution layer did the same with DP-004 "
                   "for the share class."),
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Head of Enterprise Data Management"},
    {"id": "CD-301", "theme": "Technology",
     "title": "21 governance products: DP-100 register and DP-101 catalog; DP-075 becomes the distribution view of DP-101; DP-045 and the Wave E5 KPI registry keep declared boundaries",
     "domains": ["21", "06", "09", "14"],
     "issue": ("CD-298 proposes that DP-075 Distribution Metadata & Lineage Catalog becomes a view of a 21 enterprise "
               "catalog product, and CD-295 exports the catalog as 21 instances, but neither says which product holds "
               "which 21 objects, how DP-045's data quality slice relates to an enterprise data quality product, or how "
               "the Wave E5 Enterprise KPI & Metrics Registry relates to 21 Metric Definition."),
     "resolution": ("Proposed: DP-100 Taxonomy, Glossary & Data Ownership Register holds the taxonomy element register, "
                    "glossary, decision log, governance bodies, ownership assignments, CDEs and classification "
                    "assignments. DP-101 Governance Metadata & Enterprise Catalog holds data assets, lineage, element "
                    "mappings, system of record designations, object governance profiles and the CD-295 export (Data "
                    "Product, Data Product Input, Data Contract, Semantic Model Binding, Metric Definition). DP-075 keeps "
                    "its ID, owner and FN-17 consumer and becomes the distribution-scoped view of DP-101 (filter: assets, "
                    "products and metrics owned by Data Domains 01-16); its upstream gains DP-101 and its own lineage "
                    "inputs move to DP-101. DP-045 stays separate: distribution supply-chain health, reading DQ rows for "
                    "distribution assets only; DP-103 is the enterprise data quality and certification product. The Wave "
                    "E5 Enterprise KPI & Metrics Registry builds on DP-101 for definitions and certification and takes "
                    "metric values from each owning product; it defines no metric of its own."),
     "rationale": "CD-298 settled pair by pair; one owner per concept applies to metadata products as to taxonomy objects.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Data Officer"},
    {"id": "CD-302", "theme": "Enterprise Structure",
     "title": "Launch readiness: DP-107 owns the enterprise readiness plan and go / no-go; DP-058 stays the distribution go-to-market tracker and reads its workstream status from 36",
     "domains": ["36", "01", "05", "08", "06"],
     "issue": ("DP-058 Product Launch Readiness & Tracking infers launch workstreams from pending 01, 05 and 08 records "
               "because no launch plan object existed (its Taxonomy gap). 36 now masters Product Readiness Plan and "
               "Readiness Check (CD-239), and FN-37 is split from FN-10 for launches (CD-291)."),
     "resolution": ("Proposed: DP-107 Product Launch Readiness & Go / No-Go (36, FN-37) holds the readiness plan, every "
                    "workstream check with its evidence reference and the go / no-go, up to the launch date. DP-058 keeps "
                    "its ID, owner (01) and FN-10 as primary consumer and narrows to go-to-market: trade enablement at "
                    "partner platforms, approved marketing materials, first purchases and days to first sale. Its "
                    "registration, shelf, listing and document checklist items are read from 36 Readiness Check, and its "
                    "Readiness Score % is the share of those distribution workstream checks complete, not a separate "
                    "inference. DP-058's launch-plan Taxonomy gap closes."),
     "rationale": "One owner per readiness fact; DP-058 already answers the distribution question and is extended, not duplicated.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Product Development"},
    {"id": "CD-303", "theme": "Enterprise Structure",
     "title": "Product range products take certified numbers from their owners; DP-040 stays the distributor-side evidence for DP-109 reviews",
     "domains": ["36", "08", "06", "10", "11", "27", "32"],
     "issue": ("The 36 products cite flows, AUM, revenue, profitability, fee benchmarks and returns as evidence (business "
               "cases, impact assessments, value assessment criteria). DP-040 Product Governance & Target Market Feedback "
               "already reads 01 Product Governance review dates and 08 evidence, and records a gap for review-cycle "
               "tracking that 36 Product Review now closes."),
     "resolution": ("Proposed: DP-105, DP-108 and DP-109 compute none of these numbers. Flows and attributed AUM come from "
                    "DP-008, fund net assets from the 27 NAV & Fund Financials product (CD-292), revenue from DP-012, "
                    "profitability from DP-035, fee comparisons from DP-030, official returns from the 32 Official Returns "
                    "product (CD-217). Business case projections are labeled projections and are never published under a "
                    "certified metric name. DP-040 stays separate as the distributor-side evidence (08) and is upstream of "
                    "DP-109; its Product Review Overdue Flag reads 36 Product Review Next Review Due Date through DP-109's "
                    "source instead of the 01 derived copy once CD-236 is applied."),
     "rationale": "CD-293 and the program rule that a certified number lives in one product; CD-238 for the review boundary.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Product Governance"},
    {"id": "CD-304", "theme": "Enterprise Structure",
     "title": "DP-013 Enterprise Reference & Calendars: primary consumer moves from FN-17 to FN-49 Enterprise Data Management",
     "domains": ["09", "21"],
     "issue": ("FN-49 Enterprise Data Management runs C-14.08 Enterprise Reference Data (09) and FN-50 is the enterprise "
               "successor of FN-17 (CD-291), but DP-013, the product that conforms 09, still names FN-17 (distribution "
               "data management) as its primary function. CD-298 keeps DP-013 and extends it rather than duplicating it."),
     "resolution": ("Proposed: DP-013 keeps its ID, scope and owner role; its primary function becomes FN-49 and FN-17 "
                    "moves to supporting. No input or measure changes. The legal entity re-point named in plan §7 E1 is "
                    "made separately by the Corporate A brief."),
     "rationale": "The function that runs the capability is the product's primary consumer, as for every other foundational product.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Low", "owner_role": "Head of Enterprise Data Management"},
]
