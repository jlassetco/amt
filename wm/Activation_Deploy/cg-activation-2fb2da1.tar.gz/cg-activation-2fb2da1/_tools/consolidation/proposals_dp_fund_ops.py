"""Wave E0 product brief proposals: Fund Operations (Data Domains 27, 28, 29 and 35).

Brief: 00_Program/Expansion/Product_Briefs/Fund_Operations.md
Reserved product IDs DP-165 to DP-189 (DP-165 to DP-186 used; DP-187 to DP-189 left free for review); reserved decision
IDs CD-330 to CD-339 (CD-330 to CD-336 used). Checked with: python data_products/candidate_coverage.py proposals_dp_fund_ops
(from _tools). Upstream names that are not DP- ids are Wave E1 candidates of other briefs, named as the plan names them
(§7 E1) or, for DP-099, as the Foundations brief named it.
The domains' other products are reused, not redone: 13 (DP-043, DP-069, DP-070, DP-071, DP-085, DP-091), 15 (DP-093)
and 16 (DP-094 to DP-096) keep their scope; the boundaries are in the brief §3 and §6.

Briefs accepted 2026-10-08: DECISIONS below are merged into decisions.py (kept here as the record of the proposal);
CANDIDATES remain the input to Waves E1 to E4 (read by data_products/candidate_coverage.py).
"""

# Wave E1 candidates of other briefs (plan §7 E1 names; DP-097 and DP-099 are the Foundations brief's ids)
SEC = "DP-097"   # Security Master & Identifiers (17, Wave E1)
CAE = "DP-099"   # Corporate Action Event Golden Copy (17, Wave E1)
PORT = "DP-140"   # Portfolio Master & Mandate Link (18, Wave E1)
HOLD = "DP-142"   # Holdings, Tax Lots & Cash (18, Wave E1)
PTXN = "DP-141"   # Portfolio Transactions (18, Wave E1)
PRICE = "DP-143"   # Prices, FX & Curves (22, Wave E1)
GL = "DP-190"   # Chart of Accounts & Ledger (19, Wave E1)
EMP = "DP-192"   # Employee & Position Master (20, Wave E1)
CPTY = "DP-115"   # Approved Broker & Counterparty Master (25, Wave E1)
VEND = "DP-210"   # Vendor Master (40, Wave E1)
CAT = "DP-101"   # Governance Metadata & Enterprise Catalog (21, Wave E1)
RET = "DP-145"   # Official Returns (32, Wave E1)
RISK = "DP-146"   # Risk Measures (31, Wave E1)
ICA = "DP-116"   # Investor Capital Accounts (30, Wave E1)

CANDIDATES = [
    # --- Foundational (Wave E1) ---------------------------------------------------------------------------------------
    dict(id="DP-165", name="NAV & Fund Financials", tier="Foundational", type="Conformed Facts", domain="27",
         owner_role="Head of Fund Accounting", primary="FN-33",
         supporting=["FN-15", "FN-10", "FN-12", "FN-14", "FN-36", "FN-38", "FN-28", "FN-31", "FN-01", "FN-19"],
         wave="E1",
         definition=("The official, approved NAV of every fund and share class by valuation date (total and class net "
                     "assets, NAV per share, swung and market-based NAV, shares outstanding, CIT unit values and "
                     "insurance-dedicated fund NAVs) with its release, the Rule 18f-3 class allocation behind it and the "
                     "fund's audited statement sets and financial highlights. It is the source of the certified Firm AUM, "
                     "NAV, total net assets and fund expense ratios (CD-292, CD-293, CD-330), so every product that needs "
                     "a fund's size, price or expense ratio takes it from here and never recalculates it."),
         objects=[("27", "Fund NAV Calculation"), ("27", "Share Class NAV"), ("27", "CIT Unit Value Detail"),
                  ("27", "Class Allocation"), ("27", "NAV Dissemination"), ("27", "Fund Accounting Book"),
                  ("27", "Fund Book Operating Period"), ("27", "Fund Financial Statement"),
                  ("27", "Financial Highlights"), ("27", "Fund Expense Accrual"),
                  ("27", "Expense Cap & Waiver Accrual"),
                  ("01", "Investment Product"), ("01", "Share Class")],
         upstream=["DP-166", "DP-004", "DP-013", PORT],
         notes=("Concept ownership rows: Share Class NAV (NAV-), Fund NAV Calculation, NAV Dissemination (CD-187, "
                "CD-207). Certified metrics (CD-330): Firm AUM = sum of Fund Net Assets Amount of the NAV of record "
                "(approved, latest version, official calculation source; the firm shadow NAV is never the NAV of "
                "record); Class Net Assets, NAV per Share and Shares Outstanding of the NAV of record; Net and Gross "
                "Expense Ratio (accrual basis, annualized over a trailing period) from Fund Expense Accrual and Expense "
                "Cap & Waiver Accrual over average class net assets; Audited Gross and Net Expense Ratio from Financial "
                "Highlights. Financial Highlights Total Return is not certified here: it waits for CD-217 (option A "
                "reads Official Returns). Private fund NAV is read from Investor Capital Accounts (30) under CD-292 and "
                "added to Firm AUM, not restruck. Operating model (CD-297, CD-331): in house the source is the fund "
                "accounting platform; if an administrator keeps the book the grain is unchanged, the official "
                "calculation source becomes 'Administrator' (Fund Book Operating Period names it), and the firm "
                "shadow NAV rows feed DP-168 only. DP-008 stays certified as Attributed AUM and reconciles to Firm AUM "
                "in the Wave E5 Firm AUM Reconciliation.")),
    dict(id="DP-166", name="Fund Ledger & ABOR Positions", tier="Foundational", type="Conformed Facts", domain="27",
         owner_role="Head of Fund Accounting", primary="FN-33",
         supporting=["FN-34", "FN-27", "FN-36", "FN-38", "FN-39"], wave="E1",
         definition=("The fund accounting book of record (ABOR): each fund's books by accounting basis and the 18 "
                     "portfolios they account for, the fund chart of accounts, journal entries and lines with their typed "
                     "source records, daily trial balances, ABOR valuation records with the book's own quantity, cost and "
                     "unrealized gain, and daily income accruals. It is the one conformed fund ledger and fund position "
                     "set that NAV, reconciliations, expenses, distributions, tax and fund filings read."),
         objects=[("27", "Fund Accounting Book"), ("27", "Fund Book Operating Period"),
                  ("27", "Fund Book Portfolio Link"), ("27", "Fund Ledger Account"), ("27", "Fund Journal Entry"),
                  ("27", "Fund Journal Line"), ("27", "Fund Trial Balance"), ("27", "ABOR Valuation Record"),
                  ("27", "Income Accrual")],
         upstream=["DP-004", "DP-013", SEC, PORT, HOLD, PTXN, PRICE],
         notes=("Concept ownership rows: Fund Accounting Book, Fund Ledger Account, Fund Journal Entry (FJNL-), ABOR "
                "Valuation Record, Income Accrual (CD-186). A fund's transactions never post to a 19 ledger; the "
                "adviser side of waivers and fees is 19 and reaches this product only by reference (CD-186, CD-188). "
                "ABOR quantity is mastered in 27 and compared with the 18 IBOR quantity in DP-172, not here. Journal "
                "line sources (18 PTXN-, 26 SETL-, 29 FNDO- / ECR-, 27 FDIV-, 30 CCN- / PDIS-) are published as keys "
                "only. Operating model (CD-297, CD-331): in house, the grain is the platform's full journal; if an "
                "administrator keeps the book, the firm usually receives the trial balance, valuation and accrual "
                "files but not journal lines, so Fund Journal Entry and Fund Journal Line are optional and the "
                "product is certified at trial balance and ABOR valuation grain.")),
    dict(id="DP-167", name="Custody Network & Safekeeping Accounts", tier="Foundational", type="Master & Reference",
         domain="28", owner_role="Head of Asset Servicing", primary="FN-34",
         supporting=["FN-29", "FN-27", "FN-33", "FN-35", "FN-14", "FN-26", "FN-46"], wave="E1",
         definition=("The custodian and safekeeping account dimension: each custody provider by role, the global "
                     "custodian's sub-custodian and depository network by market, and every safekeeping, cash, bank "
                     "deposit and collateral account (SKA-) with its effective-dated assignment to a fund, portfolio or "
                     "client account and its CASS designation. Settlement, reconciliation, corporate action, lending, "
                     "fund order settlement and client money products key on its Safekeeping Account ID and custodian, "
                     "so no product keeps its own list of custody accounts."),
         objects=[("28", "Custody Provider Profile"), ("28", "Sub-Custodian Network Arrangement"),
                  ("28", "Safekeeping Account"), ("28", "Safekeeping Account Assignment"),
                  ("28", "Client Asset Designation")],
         upstream=["DP-004", "DP-013", "DP-093", PORT, VEND],
         notes=("Concept ownership rows: Safekeeping Account (SKA-, CD-194 option A), Custody Provider Profile. "
                "Publishes the Custodian dimension CD-296 names for SM-00. The provider's party and supplier record "
                "come from Vendor Master (40) and 02; the 01 Product Party Role custodian appointment is read through "
                "DP-004 and checked against the fund's main account. Safekeeping Account Number, Name and Cash Account "
                "IBAN are personal data on individual SMA client rows (PII = Y); an account-key-only view is "
                "published widely. 12 Custody Account (CUA-) stays the mandate set-up workflow (DP-086). Operating "
                "model (CD-297): custody is outsourced (28 Source_Notes); the grain is the accounts as opened at the "
                "custodians plus the firm's assignments, which the firm keeps whoever the custodian is, so the product "
                "does not change if a CIT trustee self-custodies (Provider Legal Entity filled instead).")),

    # --- Consumer-aligned: 27 Fund Accounting & Valuation (Wave E3) -----------------------------------------------------
    dict(id="DP-168", name="NAV Oversight & Release Control", tier="Consumer-aligned", type="Regulatory & Control",
         domain="27", owner_role="Head of Fund Accounting", primary="FN-33",
         supporting=["FN-15", "FN-36", "FN-28", "FN-42"], wave="E3",
         definition=("The daily evidence that each NAV was checked, approved and released on time: NAV control checks "
                     "by type and result, the comparison of the administrator NAV with the firm shadow NAV, NAV versions "
                     "and re-strikes, release timestamps and corrected releases, and the per-channel transmission to "
                     "Profile, Nasdaq, platforms and insurers. Fund accounting and fund oversight use it to release NAVs "
                     "within tolerance and deadline and to evidence NAV oversight to the board."),
         objects=[("27", "NAV Control Check"), ("27", "Fund NAV Calculation"), ("27", "Share Class NAV"),
                  ("27", "NAV Dissemination"), ("27", "Fund Book Operating Period"),
                  ("29", "Price & Rate Transmission"), ("29", "TA Control Check")],
         upstream=["DP-165", "DP-166", "DP-181", "DP-013", PRICE],
         notes=("Takes NAV of record and NAV values from DP-165 and adds only control facts. The capital stock proof is "
                "a 29 TA control relied on by reference (Relied-On TA Control Check), published by DP-181 (CD-196). "
                "Price exception clearance is a 22 price validation read through Prices, FX & Curves; this product "
                "holds no price check. Price & Rate Transmission (29) is read here so that release and delivery are "
                "one timeline (CD-207). Operating model (CD-297, CD-331): in house the checks are the firm's own; if "
                "fund accounting is outsourced the grain becomes the administrator's NAV control report plus the "
                "firm's oversight checks (Oversight Check Indicator = Y) and the shadow NAV tolerance comparison, "
                "which is then the product's main measure.")),
    dict(id="DP-169", name="Swing Pricing & NAV Error Correction", tier="Consumer-aligned", type="Regulatory & Control",
         domain="27", owner_role="Head of Fund Accounting", primary="FN-33",
         supporting=["FN-15", "FN-36", "FN-35", "FN-18", "FN-42", "FN-13"], wave="E3",
         definition=("Swing pricing and anti-dilution decisions per fund and valuation date against the effective "
                     "parameters, and every NAV error case with its affected share classes and dates, materiality test, "
                     "fund loss, reimbursing entity, correction method and the as-of orders and dilution that caused or "
                     "corrected it. It supports swing governance, NAV error materiality decisions and regulator and board "
                     "notification, and feeds shareholder remediation in 13."),
         objects=[("27", "Swing Pricing Parameter"), ("27", "Swing Pricing Decision"), ("27", "NAV Error Case"),
                  ("27", "NAV Error Impact"), ("29", "As-Of Order Detail"), ("29", "Fund Order"),
                  ("13", "Servicing Error"), ("13", "Shareholder Remediation")],
         upstream=["DP-165", "DP-177", "DP-043", "DP-004", "DP-013", EMP],
         notes=("The net capital activity estimate is read from the 29 fund orders through DP-177; swung NAV per share "
                "itself is DP-165. Shareholder remediation stays 13 (CD-189) and is read through DP-043, which keeps "
                "the TA oversight view. Fund losses that are operational losses are 37 Operational Loss Events "
                "(CD-244) and are referenced, not copied. Case Owner and approvers are employees (PII = Y; an "
                "aggregate board view without names). Operating model (CD-297): if fund accounting is outsourced, the "
                "administrator calculates swing and proposes NAV error cases; the grain is unchanged and the product "
                "records the firm's approval and the administrator as the source of the calculation.")),
    dict(id="DP-170", name="Fund Expense, Cap & Waiver Management", tier="Consumer-aligned", type="Operational",
         domain="27", owner_role="Fund Treasurer", primary="FN-33",
         supporting=["FN-12", "FN-10", "FN-38", "FN-36", "FN-46"], wave="E3",
         definition=("Each fund's expenses by type: budget against daily accrual, expense cap and waiver accruals with "
                     "recoupable balances and the adviser receivable or payable they create, and payments to each "
                     "payee with whether the adviser paid. The Fund Treasurer uses it to set and true up accrual rates, "
                     "manage caps and waivers before expiry and approve fund payments."),
         objects=[("27", "Fund Expense Budget"), ("27", "Fund Expense Accrual"),
                  ("27", "Expense Cap & Waiver Accrual"), ("27", "Fund Expense Payment"), ("01", "Management Fee"),
                  ("10", "Waiver Record")],
         upstream=["DP-165", "DP-166", "DP-167", "DP-004", "DP-013", VEND, GL],
         notes=("Expense ratios are read from DP-165 (CD-330), not recalculated. Boundary with DP-059 and DP-012: the "
                "10 Waiver Record amounts are Derived copies of 27 (CD-188), so DP-059 (pricing and waiver strategy) "
                "and DP-012 (net revenue) keep reading 10; this product owns the fund-side accrual and payment view. "
                "Fees paid by the fund to intermediaries (12b-1, sub-transfer agency) appear as expense types here; "
                "the arrangement and payment calculation stay in DP-034. Operating model (CD-297): if fund accounting "
                "is outsourced, budgets and accrual rates are still set by the Fund Treasurer and the administrator "
                "delivers the accruals; the grain does not change.")),
    dict(id="DP-171", name="Fund Distributions, Excise & RIC Compliance", tier="Consumer-aligned",
         type="Regulatory & Control", domain="27", owner_role="Fund Treasurer", primary="FN-33",
         supporting=["FN-39", "FN-36", "FN-15", "FN-18", "FN-21"], wave="E3",
         definition=("Distribution declarations by share class and ex-date with rates, reinvest NAV, estimated and final "
                     "tax character, together with each fund's distributable income estimates, tax year record, "
                     "book-tax differences, excise distribution requirement and RIC diversification and income test "
                     "results, and the RIC qualification determination. The Fund Treasurer and fund tax use it to set "
                     "distribution rates that avoid excise tax and protect RIC status, and the board reviews the "
                     "determination."),
         objects=[("27", "Distribution Declaration"), ("27", "Distribution Character"),
                  ("27", "Distributable Income Estimate"), ("27", "Fund Tax Year Record"),
                  ("27", "Book-Tax Difference"), ("27", "RIC Test Result"),
                  ("35", "RIC Qualification Determination")],
         upstream=["DP-165", "DP-166", "DP-004", "DP-013", SEC],
         notes=("Distribution policy stays 01 (DP-004); reinvestment transactions are 06 (DP-006); 1099-DIV and UK tax "
                "documents are 13 and DP-091, which is extended to read the final Distribution Character from this "
                "product (CD-336). The 35 determination is read here, not in a 35 product, because it is the "
                "conclusion of the 27 tests (CD-191, CD-235); Section 817(h) results come from 33 by reference. Fund "
                "tax moves with a Tax domain if CD-149 creates one; the product keeps its ID. Operating model "
                "(CD-297): if fund tax is outsourced, the provider's tax year and test files are the source and the "
                "grain is unchanged.")),

    # --- Consumer-aligned: 28 Custody & Asset Servicing (Wave E3) -------------------------------------------------------
    dict(id="DP-172", name="Custody & Book Reconciliation Breaks", tier="Consumer-aligned", type="Regulatory & Control",
         domain="28", owner_role="Head of Asset Servicing", primary="FN-34",
         supporting=["FN-27", "FN-33", "FN-29", "FN-42", "FN-43"], wave="E3",
         definition=("Position and cash reconciliation of the investment book (18) and the fund book (27) against "
                     "custodian statements, and of the fund book against the investment book, with every break, its "
                     "type, signed difference, age, owner, root cause and resolution. Asset servicing uses it to clear "
                     "breaks before NAV and settlement deadlines, and risk and audit use the break aging as control "
                     "evidence."),
         objects=[("28", "Custodian Statement"), ("28", "Custodian Holding Statement Line"),
                  ("28", "Custodian Cash Statement Entry"), ("28", "Custody Reconciliation Run"),
                  ("28", "Custody Reconciliation Break"), ("27", "ABOR to IBOR Reconciliation")],
         upstream=["DP-167", "DP-166", "DP-013", SEC, HOLD, PORT, PRICE, EMP],
         notes=("Reconcile, do not remaster (CD-196, CD-335): breaks hold signed differences only; book quantities come "
                "from DP-166 and Holdings, Tax Lots & Cash. The 27 ABOR to IBOR reconciliation is published here so "
                "that one product shows every position reconciliation of a fund; the 29 capital stock proof stays "
                "DP-181 and the 06 TA versus fund accounting AUM check stays DP-045. Settlement fails and AP order "
                "causes are referenced (26 SETL-, 29 ECR-). Operating model (CD-297): custody is outsourced; if "
                "middle office or fund accounting is also outsourced, the provider runs the reconciliation and the "
                "grain becomes the provider's break report (same break grain) with the firm's sign-off.")),
    dict(id="DP-173", name="Corporate Actions, Income & Tax Recovery", tier="Consumer-aligned", type="Operational",
         domain="28", owner_role="Head of Asset Servicing", primary="FN-34",
         supporting=["FN-21", "FN-27", "FN-33", "FN-39", "FN-14", "FN-24"], wave="E3",
         definition=("Per safekeeping account and portfolio: corporate action notifications, entitlements, elections "
                     "against internal deadlines and payments received, the income collection control against the 27 "
                     "expected accrual, withholding tax relief documentation and reclaims, and class action claims "
                     "with recoveries. Asset servicing uses it to meet election deadlines, chase unpaid income and "
                     "recover tax and class action money for the funds and client accounts."),
         objects=[("28", "Corporate Action Notification Receipt"), ("28", "Corporate Action Entitlement"),
                  ("28", "Corporate Action Election"), ("28", "Corporate Action Payment"), ("28", "Income Collection"),
                  ("28", "Tax Relief Documentation"), ("28", "Withholding Tax Reclaim"),
                  ("28", "Class Action Claim"), ("27", "Income Accrual")],
         upstream=["DP-167", "DP-166", "DP-004", "DP-093", "DP-013", CAE, SEC, PORT, EMP],
         notes=("Event terms and options come from the Corporate Action Event Golden Copy (17, CD-195); the booked "
                "position effect is 18 Portfolio Transactions; elections reference 24 investment decisions; investee "
                "proxy votes are 34. Class action claims for SMA client accounts and the recognized loss are personal "
                "data (PII = Y); fund-level view without client accounts. Operating model (CD-297): custody is "
                "outsourced; the grain is the custodian's notifications and payments as received plus the firm's "
                "elections and controls. If corporate action processing is also outsourced to the custodian or a "
                "middle-office provider, elections and reclaims become the provider's records and the product adds "
                "the provider's deadline and claim-aging exceptions.")),
    dict(id="DP-174", name="Securities Lending Program & Revenue", tier="Consumer-aligned", type="Analytical",
         domain="28", owner_role="Head of Asset Servicing", primary="FN-34",
         supporting=["FN-36", "FN-30", "FN-24", "FN-21", "FN-12", "FN-29"], wave="E3",
         definition=("Each lending program's loans, utilization against the maximum on-loan percentage, collateral and "
                     "margin coverage by borrower, recalls, regulatory loan reports and the gross revenue, agent fee and "
                     "fund net revenue by period. Asset servicing and the board use it to set program parameters, monitor "
                     "borrower exposure and evidence the fund's revenue share."),
         objects=[("28", "Securities Lending Program"), ("28", "Securities Lending Agreement"),
                  ("28", "Securities Loan"), ("28", "Lending Collateral Received"), ("28", "Loan Regulatory Report"),
                  ("28", "Lending Revenue Allocation")],
         upstream=["DP-167", "DP-165", "DP-166", "DP-004", "DP-013", SEC, CPTY, PRICE],
         notes=("Utilization uses fund net assets from DP-165, not a recomputed AUM. Cash collateral reinvestment is an "
                "18 portfolio (CD-198); OTC and margin collateral is 26. Revenue booked to the fund is the 27 journal "
                "referenced by Booked Fund Journal Entry (DP-166). Rule 10c-1a and SFTR report status is shown but "
                "the reports stay 28 records (CD-233). Supplies the securities lending items of N-CEN to DP-185. "
                "Operating model (CD-297): lending is run by an agent lender (custodian or third party); the grain is "
                "the agent's loan, collateral and revenue files as received, which does not change if the agent "
                "changes.")),
    dict(id="DP-175", name="Client Money & Client Assets (CASS)", tier="Consumer-aligned", type="Regulatory & Control",
         domain="28", owner_role="CASS Operational Oversight Officer", primary="FN-34",
         supporting=["FN-44", "FN-40", "FN-14", "FN-43"], wave="E3",
         definition=("For each UK CASS firm: the daily client money requirement against resource with shortfalls, "
                     "excesses and breach notifications, the designation of each client money and safe custody account, "
                     "acknowledgment letters outstanding, and the firm's CASS classification against its highest "
                     "balances. The CASS oversight officer uses it to evidence compliance with CASS 6 and 7 and to "
                     "prepare the CMAR and the CASS audit."),
         objects=[("28", "Client Money Calculation"), ("28", "CASS Acknowledgment Letter"),
                  ("28", "CASS Firm Profile"), ("28", "Client Asset Designation"), ("28", "Safekeeping Account")],
         upstream=["DP-167", "DP-172", "DP-013", EMP],
         notes=("CASS policy, oversight and audit are 38 (CD-197); the CASS external reconciliations are CUREC- runs "
                "published by DP-172. EU safeguarding is out of scope unless 28 SME question 12 says otherwise. "
                "Operating model (CD-297): CASS records are kept by the firm whether custody is outsourced or not; "
                "the grain does not change. If no group entity holds client money, the product reduces to safe "
                "custody asset designations.")),
    dict(id="DP-176", name="Fund Service Provider Oversight", tier="Consumer-aligned", type="Regulatory & Control",
         domain="28", owner_role="Head of Fund Administration", primary="FN-33",
         supporting=["FN-34", "FN-35", "FN-15", "FN-36", "FN-46", "FN-42"], wave="E3",
         definition=("One oversight scorecard per fund service provider (fund administrator, custodian and sub-custodian "
                     "network, transfer agent, securities lending agent): contracted service levels against results, "
                     "periodic service reviews, SOC 1 receipt, Rule 17f-5 and 17f-7 foreign custody assessments, and "
                     "the operational evidence each provider generates (NAV errors, reconciliation breaks, TA control "
                     "exceptions). Fund administration uses it for the annual provider reviews and for the board's "
                     "service provider and foreign custody reports."),
         objects=[("28", "Foreign Custody Assessment"), ("28", "Custodian Service Review"),
                  ("28", "Custody Provider Profile"), ("27", "Fund Book Operating Period"),
                  ("40", "Supplier Engagement"), ("40", "Contracted Service Level"),
                  ("40", "Service Level Measurement Result"), ("40", "Supplier Performance Review"),
                  ("40", "Outsourcing Arrangement"), ("13", "Servicing Provider Engagement")],
         upstream=["DP-167", "DP-168", "DP-169", "DP-172", "DP-181", "DP-043", "DP-013", VEND, "DP-219"],
         notes=("Owned in 28, not 40 (CD-333): the fund-specific assessments (17f-5, 17f-7, custodian service review) "
                "are 28 records, and C-06.10 is a Fund Operations capability; the engagement, contracted service "
                "levels and outsourcing arrangement are read from 40 through Vendor Master and never re-mastered. "
                "This is the fund-provider slice of the enterprise vendor performance product of the Corporate B "
                "brief, as DP-073 is the data-vendor slice (CD-298). DP-043 stays the shareholder servicing and TA SLA "
                "view and is read, not repeated. This is the product CD-297 means by 'oversight data': it exists "
                "whatever the operating model, and grows in weight the more is outsourced.")),

    # --- Consumer-aligned: 29 Transfer Agency Operations (Wave E3) ------------------------------------------------------
    dict(id="DP-177", name="Fund Order Processing & Cut-Off Control", tier="Consumer-aligned", type="Operational",
         domain="29", owner_role="Head of Transfer Agency", primary="FN-35",
         supporting=["FN-15", "FN-13", "FN-19", "FN-33", "FN-08", "FN-18"], wave="E3",
         definition=("Every fund order as received and processed: receipt and TA timestamps, cut-off result and trade "
                     "date assigned, routing and intermediary codes as delivered, events, exceptions and blocking "
                     "restrictions, exchanges and as-of corrections with their dilution, by dealing route and interface "
                     "session, against the processing calendar. Transfer agency uses it to work exceptions and as-of "
                     "requests, and compliance uses the cut-off and as-of evidence for Rule 22c-1 forward pricing."),
         objects=[("29", "Fund Order"), ("29", "Order Routing Detail"), ("29", "As-Of Order Detail"),
                  ("29", "Order Event"), ("29", "Order Exception"), ("29", "Exchange Link"),
                  ("29", "Order Interface Session"), ("29", "TA Processing Calendar Event")],
         upstream=["DP-093", "DP-004", "DP-079", "DP-001", "DP-013", "DP-165", EMP],
         notes=("Boundary with DP-006 (CD-199): the executed price, units and amounts and the attribution of the "
                "transaction stay 06 and DP-006; this product holds the order before execution and its processing "
                "facts, and flows are never counted from it. Resolved dealer and rep are Derived copies of 06 and are "
                "published as keys. Plan-level orders from firm-recordkept plans link to DP-095 batches. Account and "
                "representative fields are personal data (PII = Y). Operating model (CD-297): in house, the TA "
                "platform's order record; if the TA is outsourced the grain is the same order record received from "
                "the TA (Processing Provider names it) and the product is the firm's evidence of the TA's processing; "
                "if the firm only receives batch totals (29 SME question 2), the grain falls back to order interface "
                "session and the order-level measures are marked not available.")),
    dict(id="DP-178", name="Shareholder Settlement with Intermediaries", tier="Consumer-aligned", type="Operational",
         domain="29", owner_role="Head of Transfer Agency", primary="FN-35",
         supporting=["FN-40", "FN-33", "FN-34", "FN-15", "FN-44"], wave="E3",
         definition=("Settlement of every fund order and AP cash leg: obligations by contractual date and method, net "
                     "batches per intermediary, settlement date and currency, cash movements into and out of the fund "
                     "cash accounts with their screening result, and settlement exceptions such as shortfalls, returns "
                     "and cancellations for non-payment. Transfer agency and treasury use it to fund and collect on time "
                     "and to chase late intermediaries."),
         objects=[("29", "Settlement Obligation"), ("29", "Intermediary Settlement Batch"), ("29", "Cash Movement"),
                  ("29", "Settlement Exception"), ("28", "Safekeeping Account")],
         upstream=["DP-177", "DP-167", "DP-093", "DP-001", "DP-013"],
         notes=("Obligation Amount is a Derived copy of the 06 net amount for fund orders (CD-199) and is mastered here "
                "only for AP cash legs (CD-183). Fund cash accounts are 28 safekeeping accounts (DP-167); corporate "
                "bank accounts are 43 (CD-274). Payment Reference, investor bank instruction and payment amounts of "
                "individual accounts are personal data (PII = Y); intermediary batch view without them. Operating "
                "model (CD-297): if the TA is outsourced the TA's settlement and exception reports are the source "
                "and the grain is unchanged; with NSCC net settlement the obligation level may not be received "
                "(29 SME question 11) and the product is certified at batch grain.")),
    dict(id="DP-179", name="ETF Creation & Redemption Operations", tier="Consumer-aligned", type="Operational",
         domain="29", owner_role="Head of ETF Operations", primary="FN-35",
         supporting=["FN-23", "FN-22", "FN-33", "FN-29", "FN-04"], wave="E3",
         definition=("Every authorized participant creation and redemption order: units ordered against the applied "
                     "basket, cut-off result, cash component estimated and actual, transaction fees and collateral, "
                     "basket line delivery and cash in lieu, and settlement status. ETF operations and capital markets "
                     "use it to manage AP activity, failed basket deliveries and collateral, and fund accounting books "
                     "the capital stock from it."),
         objects=[("29", "AP Creation / Redemption Order"), ("29", "AP Order Fee"), ("29", "Basket Settlement Line"),],
         upstream=["DP-004", "DP-005", "DP-165", "DP-178", "DP-013", SEC, CPTY, "DP-131"],
         notes=("Boundary with DP-006 (CD-200): 06 ETF Creation / Redemption is the primary-market flow that DP-006 "
                "attributes and DP-008 certifies; this product is the order and settlement record and is never a "
                "flow source. Baskets are 24 (CD-177), in-kind settlement instructions 26, AP agreements 05 (DP-005). "
                "Operating model (CD-297): AP orders may be processed by the TA, the custodian or a distributor portal "
                "(29 SME question 3); the grain is the AP order either way and AP Order Processing Provider names the "
                "processor.")),
    dict(id="DP-180", name="Shareholder CIP, AML & Fraud Alerts", tier="Consumer-aligned", type="Regulatory & Control",
         domain="29", owner_role="BSA / AML Officer", primary="FN-35",
         supporting=["FN-44", "FN-15", "FN-13", "FN-42"], wave="E3",
         definition=("Identity verification of direct shareholders (US CIP and UK CDD) by method and result, and every "
                     "AML, sanctions and fraud monitoring alert on shareholder accounts with its trigger, review, "
                     "disposition, escalation, fraud loss and the account restriction it caused. The BSA / AML officer "
                     "uses it to manage alert backlogs and evidence the CIP and monitoring controls of the AML program."),
         objects=[("29", "CIP Verification"), ("29", "Account Monitoring Alert"), ("29", "Alert Disposition")],
         upstream=["DP-093", "DP-077", "DP-085", "DP-177", "DP-178", "DP-013", EMP],
         notes=("Boundary with DP-085 (CD-332): DP-085 detects account maintenance and redemption patterns on 13 "
                "servicing events; 29 Account Monitoring Alert is the alert of record, published only here, and "
                "DP-085 is read as a signal source. Party KYC state stays 02 (DP-077); AML cases and SAR / OFAC "
                "reports are 38 (CD-255) and are referenced by Escalation Case Reference only. Restricted - Legal "
                "fields (SAR decision, disposition rationale) are never published outside the AML unit (31 CFR "
                "1024.320(e)); PII = Y throughout. Operating model (CD-297): if the TA is outsourced, alerts may be "
                "generated and first-reviewed by the TA; the grain is unchanged and Alert Reviewer may be an external "
                "party, with the firm's second review recorded.")),
    dict(id="DP-181", name="TA Daily Controls & Capital Stock Proof", tier="Consumer-aligned",
         type="Regulatory & Control", domain="29", owner_role="Head of Transfer Agency", primary="FN-35",
         supporting=["FN-33", "FN-15", "FN-36", "FN-43"], wave="E3",
         definition=("Daily transfer agency control results by share class: capital stock proof against fund accounting "
                     "shares outstanding, cash proof, unprocessed items and as-of dilution against threshold, with every "
                     "exception's cause, severity, owner and resolution. Transfer agency signs off each business day "
                     "from it and fund accounting relies on its capital stock proof before releasing the NAV."),
         objects=[("29", "TA Control Check"), ("29", "TA Control Exception")],
         upstream=["DP-165", "DP-177", "DP-178", "DP-004", "DP-013", EMP],
         notes=("Boundary with DP-043 (CD-202, CD-333): DP-043 keeps outsourced-TA service levels and servicing errors "
                "(13); this product holds the daily operational control results (29). Comparison values are read "
                "from DP-165 (NAV of record) and not stored twice. A 37 Control Test samples these results by "
                "reference (CD-243). Operating model (CD-297): if the TA is outsourced, the TA's daily control report "
                "is the source (Control Processing Provider names it) and the firm's sign-off is the oversight fact; "
                "the grain is unchanged.")),

    # --- Consumer-aligned: 35 Fund Governance & Regulatory Reporting (Wave E3) ------------------------------------------
    dict(id="DP-182", name="Fund Board Governance, Reporting & Approvals", tier="Consumer-aligned",
         type="Regulatory & Control", domain="35", owner_role="Head of Fund Legal", primary="FN-36",
         supporting=["FN-33", "FN-32", "FN-30", "FN-28", "FN-37", "FN-44", "FN-45"], wave="E3",
         definition=("The fund governance record across boards, trustee committees, ManCo and AIFM boards and LPACs: "
                     "governed funds, members and independence, officers, governance standards and self-assessments, "
                     "meetings, the reports each board received against the reports required by rule, the material "
                     "matters they cited, every resolution with its subject, votes and consents, fidelity bonds and "
                     "exemptive relief relied on. Fund legal and the board secretariat use it to plan agendas, evidence "
                     "required approvals and reports, and answer 'what did the board approve, and when'."),
         objects=[("35", "Fund Governing Body"), ("35", "Governed Fund Coverage"),
                  ("35", "Governing Body Membership"), ("35", "Fund Officer Appointment"),
                  ("35", "Governance Standards Profile"), ("35", "Board Meeting"), ("35", "Board Agenda Item"),
                  ("35", "Board Report Received"), ("35", "Board Report Source Item"),
                  ("35", "Board Self-Assessment"), ("35", "Board Resolution"), ("35", "Resolution Subject Link"),
                  ("35", "Resolution Vote Count"), ("35", "Board Consent Record"), ("35", "Fund Fidelity Bond"),
                  ("35", "Exemptive Relief Reliance")],
         upstream=["DP-004", "DP-013", EMP],
         notes=("Publishes the Governing Body dimension for SM-11 and the derived board-approval status that 31, 33, 34 "
                "and 36 products read (CD-237); the Foundations brief's DP-105 and DP-107 read approvals from here. "
                "Board report source items are references to 31, 33 and 22 records; their measures are never copied "
                "(CD-234). The Wave E5 Board and Management Reporting pack reads certified metrics; this product "
                "holds the governance record, not the pack's numbers. Membership, officer and interested person "
                "fields are personal data (PII = Y). Operating model: fund legal is in house; if a third-party "
                "trustee or ManCo governs a fund, its body is a 35 Fund Governing Body with a Governed Trustee Party "
                "and the grain is unchanged.")),
    dict(id="DP-183", name="Advisory Agreements & 15(c) Renewal", tier="Consumer-aligned", type="Regulatory & Control",
         domain="35", owner_role="Head of Fund Legal", primary="FN-36",
         supporting=["FN-10", "FN-12", "FN-38", "FN-31", "FN-33", "FN-45"], wave="E3",
         definition=("Every fund advisory and sub-advisory agreement with its per-fund schedule, term and continuation "
                     "date, and each annual Section 15(c) renewal: request and delivery dates, the materials assembled "
                     "(fees, peers, expenses, profitability, performance) by reference to their owning products, the "
                     "board's findings by factor and the approving resolution. Fund legal uses it to run the renewal "
                     "calendar and evidence the board's process."),
         objects=[("35", "Fund Advisory Agreement"), ("35", "Agreement Fund Schedule"),
                  ("35", "Advisory Contract Renewal"), ("35", "Renewal Material Item"), ("35", "Board 15(c) Finding"),
                  ("35", "Board Resolution")],
         upstream=["DP-182", "DP-165", "DP-170", "DP-059", "DP-035", "DP-030", "DP-004", "DP-013", RET],
         notes=("Takes every number from its owner (CD-330, CD-334): fees and waivers from DP-059 and DP-170, peer fees "
                "from DP-030, adviser profitability from DP-035, expense ratios and net assets from DP-165, "
                "performance from Official Returns (32). The fee terms stay 01 (CD-232). Shareholder approval of "
                "agreements is 13 (DP-071). Operating model: if 15(c) materials are prepared by a vendor (35 SME "
                "question 2), Materials Preparer names it and the grain is unchanged.")),
    dict(id="DP-184", name="Fund Regulatory Filing Calendar & Evidence", tier="Consumer-aligned",
         type="Regulatory & Control", domain="35", owner_role="Head of Fund Regulatory Reporting", primary="FN-36",
         supporting=["FN-33", "FN-32", "FN-30", "FN-44", "FN-50", "FN-22"], wave="E3",
         definition=("Every fund filing obligation and submission across forms (N-PORT, N-CEN, N-CSR, N-MFP, N-RN, N-PX, "
                     "24F-2, 485 and 497, Form PF, AIFMD Annex IV, UK and EU fund returns) and every reportable fund "
                     "event and public website disclosure: due date against official filing date, amendments, "
                     "certifications, documents filed and the sign-off and reconciliation of each data source. "
                     "Regulatory reporting uses it to run the filing calendar and evidence timely, certified and "
                     "reconciled filings."),
         objects=[("35", "Filing Obligation"), ("35", "Fund Regulatory Filing"), ("35", "Filing Document"),
                  ("35", "Filing Certification"), ("35", "Filing Data Source"), ("35", "Reportable Fund Event"),
                  ("35", "Fund Public Disclosure")],
         upstream=["DP-182", "DP-004", "DP-013", EMP, CAT],
         notes=("The register of submissions for every fund form; DP-185 and DP-186 hold the assembled data of the "
                "periodic forms they cover (CD-334). Reportable events reference 31 and 33 records (exceedances, "
                "breaches); their measures are not copied. Filing Data Source's data quality result links to the 21 "
                "catalog (Governance Metadata & Enterprise Catalog). Distribution, firm and transaction filings stay "
                "08, 38, 25, 26 and 28 (CD-233). Operating model (CD-297): if an administrator or filing agent "
                "prepares a form (Filing Preparation Model), the grain is unchanged and the agent's draft and sign-off "
                "are recorded as data sources.")),
    dict(id="DP-185", name="Registered Fund Report Data (N-PORT, N-CEN, N-MFP)", tier="Consumer-aligned",
         type="Regulatory & Control", domain="35", owner_role="Head of Fund Regulatory Reporting", primary="FN-36",
         supporting=["FN-33", "FN-30", "FN-31", "FN-34", "FN-35", "FN-32"], wave="E3",
         definition=("The as-filed data set of each US registered fund's periodic structured reports: N-PORT holdings, "
                     "liquidity classification, risk metrics, returns and flows; N-CEN service providers, securities "
                     "lending, ETF and fund operational items; N-MFP money market data, each item keyed to the filing "
                     "and to the certified source product and record it came from. Regulatory reporting uses it to "
                     "assemble, review and reconcile the reports before certification, and to answer what was filed."),
         objects=[("35", "Fund Regulatory Filing"), ("35", "Filing Data Source"), ("27", "Share Class NAV"),
                  ("27", "Fund NAV Calculation"), ("18", "Portfolio Holding"), ("31", "Liquidity Classification"),
                  ("31", "Fund Liquidity Profile"), ("32", "Performance Return"), ("28", "Securities Loan")],
         upstream=["DP-184", "DP-165", "DP-166", "DP-174", "DP-176", "DP-177", "DP-171", "DP-004", "DP-008",
                   HOLD, SEC, PRICE, RISK, RET],
         notes=("Assembles, never remasters (CD-234, CD-334): net assets and NAV from DP-165, holdings from Holdings, "
                "Tax Lots & Cash, prices from Prices, FX & Curves, liquidity and VaR from Risk Measures, returns from "
                "Official Returns, securities lending from DP-174, service providers from DP-176, sales and "
                "redemptions from DP-008 (fund-level flows; CD-292 rules which AUM is reported). The as-filed snapshot "
                "is evidence keyed by REGF- and is not a source for other consumers of those numbers. The Wave E5 "
                "Regulatory Filing Data Hub reads this product. Depends on Wave E2 for 31 and 32 inputs. Operating "
                "model (CD-297): if an administrator prepares N-PORT, the administrator's file is loaded as a data "
                "source and reconciled to the certified sources; the grain is unchanged.")),
    dict(id="DP-186", name="Private & Alternative Fund Report Data (Form PF, AIFMD Annex IV)", tier="Consumer-aligned",
         type="Regulatory & Control", domain="35", owner_role="Head of Fund Regulatory Reporting", primary="FN-36",
         supporting=["FN-26", "FN-30", "FN-33", "FN-18", "FN-44"], wave="E3",
         definition=("The as-filed data set of the adviser's Form PF and each AIFM's Annex IV reports: fund and adviser "
                     "net and gross assets, borrowing and leverage, investor concentration, liquidity, exposures and "
                     "private fund information, each item keyed to the filing and its certified source. Regulatory "
                     "reporting uses it to assemble and reconcile the reports and to answer regulator queries about "
                     "what was filed."),
         objects=[("35", "Fund Regulatory Filing"), ("35", "Filing Data Source"), ("27", "Fund NAV Calculation"),
                  ("30", "Private Fund Profile"), ("31", "Leverage & Exposure Measurement"),
                  ("31", "Fund Liquidity Profile")],
         upstream=["DP-184", "DP-165", "DP-004", "DP-013", ICA, HOLD, RISK, RET],
         notes=("Same assembly rule as DP-185 (CD-334). Private fund NAV and investor data come from Investor Capital "
                "Accounts (30); IRR and multiples from Official Returns (32, CD-219); leverage and exposure from Risk "
                "Measures (31, CD-214). Form PF is an adviser filing (Filer Entity) and Annex IV an AIFM filing per "
                "fund; both are 35 REGF- records (CD-233). Operating model (CD-297): if private fund administration "
                "is outsourced, the administrator's investor and NAV files enter through Investor Capital Accounts, "
                "not here.")),
]

DECISIONS = [
    {"id": "CD-330", "theme": "Transactions & Measures",
     "title": "Fund Operations certified metrics: DP-165 publishes Firm AUM, NAV, net assets, shares outstanding and fund expense ratios from the NAV of record",
     "domains": ["27", "01", "06", "10", "30", "35"],
     "issue": ("CD-292 and CD-293 name 27 as the owner of Firm AUM, NAV and fund expense ratios but not which product "
               "publishes them, which of several NAV rows is the official one (calculation source Fund Accounting, "
               "Administrator or Firm Shadow; versions Original, Re-Strike, Restatement), or which expense ratio is "
               "certified when 27 holds an accrual basis and an audited Financial Highlights basis and 01 Cost "
               "Disclosure holds the prospectus figure."),
     "resolution": ("Proposed: DP-165 NAV & Fund Financials is the only product that publishes the certified fund "
                    "metrics. The NAV of record is the Fund NAV Calculation with NAV Approval Status approved, the latest "
                    "NAV Version Number, and the official calculation source of the book's operating period (Fund "
                    "Accounting in house, Administrator if outsourced); Firm Shadow rows are never the NAV of record and "
                    "are published only to DP-168. Certified: Firm AUM (sum of Fund Net Assets Amount of the NAV of "
                    "record, plus private fund NAV from Investor Capital Accounts under CD-292), Class Net Assets, NAV per "
                    "Share, Shares Outstanding, Net and Gross Expense Ratio (accrual basis, trailing twelve months, from "
                    "Fund Expense Accrual and Expense Cap & Waiver Accrual over average class net assets) and Audited "
                    "Net and Gross Expense Ratio (Financial Highlights). The 01 prospectus ratio stays a disclosure "
                    "published by DP-004 and is not a certified actual. Financial Highlights Total Return is not "
                    "certified by DP-165 until CD-217 is decided. Every other product (DP-059, DP-174, DP-183, DP-185, "
                    "DP-186, the Wave E5 products) reads these by reference."),
     "rationale": ("Plan §4 items 2 and 3 and semantic_model/CONTRACT.md: a certified number is defined once, by the "
                   "function that produces it; naming the NAV of record removes the ambiguity the shadow NAV and "
                   "re-strikes create."),
     "action": "SME decision", "status": "Proposed", "priority": "High", "owner_role": "Head of Fund Accounting"},

    {"id": "CD-331", "theme": "Fund Operations",
     "title": "Operating model is a dimension of the Fund Operations products, not a reason for a second product",
     "domains": ["27", "28", "29", "35", "40"],
     "issue": ("CD-297 says an outsourced function gets oversight data rather than the operational record, and asks "
               "specs to draft the operational grain and state the change. The client is mixed by business line and "
               "may outsource fund accounting for some funds only (27 SME question 1), so two products per function "
               "(operational and oversight) would split one fund range across two products."),
     "resolution": ("Proposed: each Fund Operations product keeps one ID and one grain whichever way the function is "
                    "run. The provider of record is a dimension taken from the domain's own attribute (27 Fund Book "
                    "Operating Period, 29 Processing Provider / Control Processing Provider / AP Order Processing "
                    "Provider, 28 Custody Provider Profile, 35 Filing Preparation Model), so a mixed operating model is "
                    "rows, not products. Where an outsourced provider does not deliver a level of detail (journal lines, "
                    "order-level records, settlement obligations under NSCC netting), the spec declares the fallback "
                    "grain and marks the dependent measures not available for those rows. The oversight-only facts "
                    "(firm shadow NAV, oversight checks, sign-offs, provider scorecards) are carried by DP-168, DP-176 "
                    "and DP-181, which exist under every operating model."),
     "rationale": "Applies CD-297 and CD-147 at product level; one product per concept keeps the certified numbers in one place.",
     "action": "SME decision", "status": "Proposed", "priority": "High", "owner_role": "Chief Operating Officer"},

    {"id": "CD-332", "theme": "Fund Operations",
     "title": "Shareholder fraud and AML: DP-180 publishes the alert of record; DP-085 stays the servicing-pattern signal",
     "domains": ["29", "13", "15", "02", "38"],
     "issue": ("DP-085 Shareholder Account Maintenance & Fraud Monitoring flags account takeover patterns from 13 "
               "maintenance events, and 29 now masters the Account Monitoring Alert (AML, sanctions and fraud) with its "
               "disposition and fraud loss (CD-201). Without a rule both products would count fraud cases and losses."),
     "resolution": ("Proposed: DP-180 Shareholder CIP, AML & Fraud Alerts is the only product that publishes alerts, "
                    "dispositions, fraud loss amounts and CIP results; DP-085 keeps the pattern flags on 13 events and "
                    "is upstream of DP-180 as a signal source, unchanged, with no alert or loss measure. Party KYC state "
                    "stays DP-077 (02); AML cases and SAR reports stay 38 and are referenced only. SAR-restricted "
                    "fields are never published outside DP-180's restricted audience."),
     "rationale": "CD-201, CD-255 and plan §7 E3 (shareholder AML and fraud, boundary with DP-085).",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "BSA / AML Officer"},

    {"id": "CD-333", "theme": "Fund Operations",
     "title": "Fund service provider oversight: DP-176 owned in 28 reads 40; DP-043 keeps TA servicing SLAs; DP-181 keeps daily TA controls",
     "domains": ["28", "29", "13", "40", "27", "37"],
     "issue": ("C-06.10 Fund Service Provider Oversight is a Fund Operations capability mastered by 40 (Step 5), while "
               "the fund-specific evidence sits in 28 (Rule 17f-5 / 17f-7 assessments, custodian service reviews), 29 "
               "(daily TA controls), 27 (administrator of record, NAV errors) and 13 (DP-043 servicing SLAs, CD-202)."),
     "resolution": ("Proposed: DP-176 Fund Service Provider Oversight is owned in 28 by the Head of Fund Administration "
                    "and reads the 40 engagement, contracted service levels, results, reviews and outsourcing "
                    "arrangement through Vendor Master without re-mastering them; it is the fund-provider slice of the "
                    "enterprise vendor performance product, as DP-073 is the data-vendor slice (CD-298). DP-043 stays "
                    "separate as the shareholder servicing and outsourced-TA SLA view (13) and is upstream of DP-176. "
                    "DP-181 publishes the daily TA control results (29) and DP-176 reads them; neither copies the "
                    "other's measures. Provider risk ratings stay 37 / 40 (CD-248)."),
     "rationale": "Keeps C-06.10 in the Fund Operations area view while honoring 40 as master of the engagement.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Fund Administration"},

    {"id": "CD-334", "theme": "Fund Operations",
     "title": "Fund filing data products assemble certified sources by reference; the as-filed snapshot is evidence, not a source",
     "domains": ["35", "18", "22", "27", "30", "31", "32", "06"],
     "issue": ("N-PORT, N-CEN, Form PF and Annex IV report holdings, NAV, returns, liquidity, leverage and flows that "
               "other products certify. 35 masters none of these values (CD-234), and the Wave E5 Regulatory Filing "
               "Data Hub will read fund, firm and distribution filings together."),
     "resolution": ("Proposed: DP-185 and DP-186 hold the as-filed item values of the periodic structured fund forms, "
                    "each item keyed to its REGF- filing and to the certified product and record it came from (DP-165, "
                    "Holdings, Tax Lots & Cash, Prices, FX & Curves, Risk Measures, Official Returns, Investor Capital "
                    "Accounts, DP-008, DP-174, DP-176). They never compute a measure their source certifies and are "
                    "never upstream of a product that needs the current value. DP-184 is the register of every fund "
                    "submission. The Wave E5 Regulatory Filing Data Hub reads DP-184 to DP-186 and does not reassemble "
                    "the fund forms. Fund flows reported on N-PORT are fund-level sales and redemptions from DP-008 "
                    "until CD-292 says otherwise."),
     "rationale": "CD-233 and CD-234 at product level; plan §7 E3 and E5.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Fund Regulatory Reporting"},

    {"id": "CD-335", "theme": "Fund Operations",
     "title": "Reconciliation products: custody and ABOR-IBOR in DP-172, capital stock proof in DP-181, distribution AUM checks in DP-045, Firm AUM in Wave E5",
     "domains": ["28", "27", "29", "06", "18"],
     "issue": ("CD-196 keeps one reconciliation record per producing domain, but four products could show a fund's "
               "reconciliations: custody breaks (28), ABOR to IBOR (27), capital stock proof (29) and the 06 TA versus "
               "fund accounting AUM check, plus the Wave E5 Firm AUM Reconciliation."),
     "resolution": ("Proposed: DP-172 publishes every position and cash reconciliation of a fund's books against the "
                    "custodian and of the 27 book against the 18 book (28 Custody Reconciliation Run and Break, 27 ABOR "
                    "to IBOR Reconciliation). DP-181 publishes the 29 capital stock and cash proofs; DP-168 references "
                    "them. DP-045 keeps the 06 distribution data checks. The Wave E5 Firm AUM Reconciliation compares "
                    "certified totals (DP-165, DP-008, Holdings) by cause and reads these products for the explanation; "
                    "it holds no break records."),
     "rationale": "CD-196; plan §4 item 2.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Low", "owner_role": "Head of Asset Servicing"},

    {"id": "CD-336", "theme": "Fund Operations",
     "title": "Existing products extended with Fund Operations sources: DP-084, DP-091 and DP-086",
     "domains": ["29", "27", "28", "08", "13", "12"],
     "issue": ("Plan §3: an existing product changes only by a logged decision. Three distribution products answer "
               "questions whose source is now in 27, 28 or 29: 29 Shareholder Information Request (Rule 22c-2) is the "
               "evidence DP-084 Frequent Trading & Market Timing Surveillance describes; DP-091 Shareholder Tax & Cost "
               "Basis Reporting checks 1099-DIV against transactions but not against the fund's final distribution "
               "character; DP-086 Mandate Onboarding reads 12 Custody Account, which now references the 28 Safekeeping "
               "Account (CD-194)."),
     "resolution": ("Proposed, at Wave E3: DP-084 adds 29 Shareholder Information Request to its inputs (request, "
                    "intermediary, period, response dates, restriction instruction sent), which makes it the only product "
                    "reading that object; DP-091 adds DP-171 upstream and 27 Distribution Character (final basis) for a "
                    "character consistency rule; DP-086 adds DP-167 upstream for the safekeeping account. No measure "
                    "definition changes; grains are unchanged."),
     "rationale": "Reuse before creating a product (Wave E0 brief rule); CD-199, CD-192, CD-194.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Low", "owner_role": "Chief Data Officer"},
]
