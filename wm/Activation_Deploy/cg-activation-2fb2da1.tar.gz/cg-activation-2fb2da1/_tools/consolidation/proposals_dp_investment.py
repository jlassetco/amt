"""Wave E0 product brief proposals: the Investment area (front office).

Data Domains 23 Investment Research, 24 Portfolio Management & Construction, 25 Trading & Execution,
34 Stewardship & Sustainable Investing and 30 Private Markets. Brief: 00_Program/Expansion/Product_Briefs/Investment.md.
Reserved product IDs DP-115 to DP-139; reserved decision IDs CD-310 to CD-319.

Check from _tools:  /usr/bin/python3 data_products/candidate_coverage.py proposals_dp_investment

Upstream names that are not DP- ids are Wave E1 candidates of other briefs, named as in the expansion plan §7 E1:
Security Master & Identifiers, Issuer Hierarchy & Classifications (17); Portfolio Master & Mandate Link, Holdings, Tax
Lots & Cash, Portfolio Transactions (18); Prices, FX & Curves, Index Levels & Constituents (22); Chart of Accounts &
Ledger (19); Employee & Position Master (20); Official Returns (32); Risk Measures (31); NAV & Fund Financials (27).

Briefs accepted 2026-10-08: DECISIONS below are merged into decisions.py (kept here as the record of the proposal);
CANDIDATES remain the input to Waves E1 to E4 (read by data_products/candidate_coverage.py).
"""

# Owner roles follow the capability map owner of the capability each product mainly serves.
R_RES = "Director of Research"
R_TRD = "Head of Trading"
R_CIO = "Chief Investment Officer"
R_PM = "Head of Portfolio Management"
R_MA = "Head of Managed Accounts"
R_ETF = "Head of ETF Portfolio Management"
R_STW = "Head of Stewardship"
R_SUS = "Head of Sustainable Investing"
R_PVT = "Head of Private Markets"
R_PVO = "Head of Private Markets Operations"

SEC = "DP-097"   # Security Master & Identifiers
ISS = "DP-098"   # Issuer Hierarchy & Classifications
PORT = "DP-140"   # Portfolio Master & Mandate Link
HLD = "DP-142"   # Holdings, Tax Lots & Cash
PTX = "DP-141"   # Portfolio Transactions
PRC = "DP-143"   # Prices, FX & Curves
IDX = "DP-144"   # Index Levels & Constituents
GL = "DP-190"   # Chart of Accounts & Ledger
EMP = "DP-192"   # Employee & Position Master
RET = "DP-145"   # Official Returns
RSK = "DP-146"   # Risk Measures
NAV = "DP-165"   # NAV & Fund Financials
TAG = "DP-147"   # 26, Investment Operations brief (DP-147)
CUS = "DP-167"           # 28, Fund Operations brief (DP-167)
IPM = "DP-160"        # 32 consumer, Investment Operations brief (DP-160)

CANDIDATES = [
    # =============================================== Foundational (Wave E1) ===============================================
    dict(id="DP-115", name="Approved Broker & Counterparty Master", tier="Foundational", type="Master & Reference",
         domain="25", owner_role=R_TRD, primary="FN-23",
         supporting=["FN-21", "FN-22", "FN-29", "FN-30", "FN-32", "FN-42", "FN-44"], wave="E1",
         definition="The conformed record of every broker, dealer and trading counterparty the firm may trade with: the 02 "
                    "party and its legal hierarchy, the approval status, the activities, trading entities and funds each "
                    "approval covers, the trading limits set and the periodic reviews with the status each set. It is the "
                    "one source of the Counterparty and Broker dimension, so that order routing, settlement, exposure "
                    "measurement and compliance rules all mean the same counterparty and the same approval.",
         objects=[("25", "Approved Counterparty Profile"), ("25", "Counterparty Approval Scope"),
                  ("25", "Counterparty Trading Limit"), ("25", "Counterparty Review"),
                  ("02", "Party"), ("02", "Organization"), ("02", "Party Role"), ("02", "LEI Record"),
                  ("02", "Legal Entity Hierarchy")],
         upstream=["DP-013", "DP-004", ISS, TAG, EMP, "DP-240"],
         notes="Concept ownership rows: Approved Counterparty Profile, Counterparty Approval Scope, Counterparty Trading "
               "Limit (25, CD-179). Party facts (name, LEI, legal parent) are read from 02 and never copied (CD-143); where the "
               "counterparty is also an issuer, the party core and parent rollups are taken from Issuer Hierarchy & "
               "Classifications (DP-098) so the party is conformed once, and 02 is read directly only for counterparties "
               "that are not issuers. Portfolio Transactions (18) lists this product upstream, so it must never depend on "
               "an 18 product. The governing trading agreement comes from Trading Agreements & Settlement Instructions "
               "(26); the credit view (23 Internal Credit Assessment) is carried as a key only, so the product stays "
               "foundational; limit utilization and exceedance are 31 (CD-215) and are "
               "not computed here. Outsourced trading desk (CD-147, CD-297): the approval record stays the firm's; add the "
               "provider's approved list as a received scope with data basis 'Provider'."),
    dict(id="DP-116", name="Investor Capital Accounts", tier="Foundational", type="Conformed Facts",
         domain="30", owner_role=R_PVO, primary="FN-26",
         supporting=["FN-25", "FN-05", "FN-14", "FN-31", "FN-33", "FN-36", "FN-40"], wave="E1",
         definition="The investor ledger of every private fund the firm manages: the fund's private terms, each investor "
                    "commitment held on a 15 account and its changes, and the period capital account (beginning balance, "
                    "contributions, distributions, income, fees net of offsets, gains, carried interest allocation, ending "
                    "balance and unfunded commitment) by data basis and version. It is the third kind of position (CD-146, "
                    "CD-203) and the source of private fund net assets for Firm AUM (CD-292).",
         objects=[("30", "Private Fund Profile"), ("30", "Investor Commitment"), ("30", "Commitment Change"),
                  ("30", "Investor Capital Account"), ("30", "Capital Account Fee & Expense Detail")],
         upstream=["DP-093", "DP-004", "DP-003", "DP-005", "DP-013"],
         notes="Concept ownership rows: Private Fund Profile, Investor Commitment (ICMT-), Investor Capital Account "
               "(CAPA-) (30, CD-203, CD-205). Must not depend on NAV & Fund Financials (27): that product takes the "
               "private fund balance from here for Firm AUM (CD-292, CD-310), so a dependency back would be a cycle. "
               "Publishes no flow measure and nothing reaches DP-008 (CD-204). PII = Y (every commitment and capital "
               "account attribute is flagged); an anonymized fund-level aggregate is the wide view. Outsourced private "
               "fund administration (CD-297): grain unchanged; rows arrive with Capital Account Data Basis "
               "'Administrator' and the product adds receipt and approval timeliness."),
    dict(id="DP-117", name="Private Fund Capital Calls & Distributions", tier="Foundational", type="Conformed Facts",
         domain="30", owner_role=R_PVO, primary="FN-26",
         supporting=["FN-25", "FN-31", "FN-33", "FN-34", "FN-40", "FN-14"], wave="E1",
         definition="Every capital call and distribution of the firm's private funds at fund level with its purpose or "
                    "source lines, allocated to each commitment with amounts called, excused, received, distributed, "
                    "withheld and recallable, and the equalization paid when investors join at later closes. It is the "
                    "dated cash flow series that private markets IRR and multiples (32), fund accounting (27) and "
                    "investor reporting are computed from, mastered once (CD-204).",
         objects=[("30", "Capital Call"), ("30", "Capital Call Purpose Line"), ("30", "Capital Call Allocation"),
                  ("30", "Distribution"), ("30", "Distribution Source Line"), ("30", "Distribution Allocation"),
                  ("30", "Equalization")],
         upstream=["DP-116", "DP-004", "DP-093", "DP-013"],
         notes="Concept ownership rows: Capital Call (CCN-), Private Fund Distribution (PDIS-) (30, CD-204). Foundational "
               "because Official Returns (32: private markets IRR, TVPI, DPI under CD-219) and NAV & Fund Financials (27) "
               "read these flows and may depend only on foundational products; the plan's E1 list named only Investor "
               "Capital Accounts for 30. Private fund calls and distributions never enter DP-008 flow measures (CD-204, "
               "CD-292); fundraising KPIs are 21 Metric Definitions sourced from here and DP-116. Outsourced "
               "administration (CD-297): notices are produced by the administrator; the product keeps the same grain and "
               "adds notice status and timeliness as oversight data."),

    # =============================================== 23 Investment Research (Wave E2) =====================================
    dict(id="DP-118", name="Research Coverage, Recommendations & Publications", tier="Consumer-aligned", type="Analytical",
         domain="23", owner_role=R_RES, primary="FN-20",
         supporting=["FN-21", "FN-22", "FN-24", "FN-32", "FN-44"], wave="E2",
         definition="Who covers which issuer, sector and country, what each analyst currently recommends with price "
                    "target and conviction, how recommendations have changed and performed since issue, and which research "
                    "notes were published and reviewed, set against the issuers the firm actually holds. It lets the "
                    "Director of Research close coverage gaps on held names and gives portfolio managers one current "
                    "research view per subject.",
         objects=[("23", "Research Coverage Assignment"), ("23", "Research Universe"), ("23", "Research Universe Member"),
                  ("23", "Research Recommendation"), ("23", "Recommendation Valuation Basis"),
                  ("23", "Research Publication"), ("23", "Publication Subject"), ("23", "Publication Review")],
         upstream=[SEC, ISS, PRC, HLD, PORT, EMP, "DP-013", "DP-004"],
         notes="Current recommendation follows the 23 rule: latest row per subject x rating scale x analyst; the team view "
               "is the primary analyst's. House views are 24 Investment Committee Decisions (DP-126), not research rows. "
               "Recommendation return since issue is computed from Prices, FX & Curves and is a product measure, not an "
               "official return (CD-217). Externally released publications hand off to 01 commentary and 04 content "
               "(read by key only). PII = Y (analyst names)."),
    dict(id="DP-119", name="Internal Credit Views & Money Market Eligibility", tier="Consumer-aligned",
         type="Regulatory & Control", domain="23", owner_role=R_RES, primary="FN-20",
         supporting=["FN-21", "FN-23", "FN-32", "FN-36", "FN-30"], wave="E2",
         definition="The current internal credit rating, outlook and Rule 2a-7 minimal credit risk and first tier "
                    "determination for every issuer, counterparty and instrument the firm assesses, compared with agency "
                    "ratings and joined to the money market fund and credit holdings that depend on them. It evidences "
                    "that every eligible security has a current, approved determination and flags overdue reviews and "
                    "internal-to-agency divergences.",
         objects=[("23", "Internal Credit Assessment")],
         upstream=[SEC, ISS, HLD, PORT, EMP, "DP-115", "DP-004"],
         notes="CD-173: internal assessments in 23, agency ratings in 17, read through Issuer Hierarchy & Classifications (Foundations brief DP-098), never copied; holdings come from Holdings, Tax Lots & Cash. The coded 2a-7 limit and "
               "its breaches are 33 (CD-221, CD-222); this product supplies the determination, not the compliance result. "
               "Counterparty reviews in DP-115 hold the assessment key; this product is where the assessment content is "
               "read."),
    dict(id="DP-120", name="Research Estimates, Models & Signals", tier="Consumer-aligned", type="Analytical",
         domain="23", owner_role=R_RES, primary="FN-20",
         supporting=["FN-21", "FN-42", "FN-50"], wave="E2",
         definition="Analyst estimates by issuer, metric and fiscal period, economic forecasts by geography and indicator, "
                    "the research models behind them and the quantitative signal definitions with their dated scores per "
                    "instrument. It shows estimate revisions and signal coverage for security selection and asset "
                    "allocation, and lists the models and signals that should be in the 37 model inventory.",
         objects=[("23", "Analyst Estimate"), ("23", "Research Model"), ("23", "Economic Forecast"),
                  ("23", "Research Signal Definition"), ("23", "Research Signal Score"),
                  ("37", "Model Inventory Entry")],
         upstream=[SEC, ISS, EMP, "DP-013", "DP-044"],
         notes="CD-294 and CD-246: a research model or signal used in investment decisions is registered in the 37 model "
               "inventory; the product flags Model Inventory Candidate Indicator rows with no 37 entry. Signal scores stay "
               "23 records (they are taxonomy objects), not product-owned scores. Licensed input datasets are read through "
               "DP-044 by key."),
    dict(id="DP-121", name="Issuer Meetings & MNPI Control", tier="Consumer-aligned", type="Regulatory & Control",
         domain="23", owner_role=R_RES, primary="FN-20",
         supporting=["FN-44", "FN-24", "FN-21"], wave="E2",
         definition="Every meeting between investment staff and issuer management with its participants, topics, "
                    "per-person wall crossings and MNPI flag, linked to the compliance escalation and restricted list "
                    "entry that followed. It evidences that MNPI received in a meeting was escalated and the issuer "
                    "restricted before anyone traded, and shows which meetings served stewardship objectives.",
         objects=[("23", "Issuer Meeting"), ("23", "Issuer Meeting Participant"), ("23", "Issuer Meeting Topic"),
                  ("23", "Meeting MNPI Assessment"), ("38", "MNPI Escalation"), ("38", "Restricted List Entry")],
         upstream=[ISS, EMP, "DP-013"],
         notes="CD-224 and CD-256: the MNPI flag is 23, the escalation, insider list and restricted list are 38. Trade "
               "surveillance against the restriction is a 38 product (Corporate B brief), which may read this product. "
               "Meeting notes stay in the document store (Meeting Notes Location only). PII = Y (internal and external "
               "participants)."),

    # =============================================== 25 Trading & Execution (Wave E2) =====================================
    dict(id="DP-122", name="Research Valuation, Commissions & Research Payments", tier="Consumer-aligned",
         type="Regulatory & Control", domain="25", owner_role=R_TRD, primary="FN-23",
         supporting=["FN-20", "FN-38", "FN-36", "FN-44"], wave="E2",
         definition="The research unbundling record from use to payment: approved research providers and subscriptions, "
                    "research consumed, the broker vote and its criterion scores, research budgets, commission schedules, "
                    "commission sharing arrangements with their dated balances, and every research payment with its source "
                    "and invoice status. It evidences the MiFID II and FCA quality assessment, the Section 28(e) basis of "
                    "soft-dollar spend and the budget-to-payment position per legal entity and strategy.",
         objects=[("23", "Research Provider Profile"), ("23", "Research Service Subscription"),
                  ("23", "Research Consumption Record"), ("23", "Research Evaluation Round"),
                  ("23", "Evaluation Criterion Score"), ("25", "Commission Schedule"),
                  ("25", "Commission Sharing Arrangement"), ("25", "Commission Sharing Balance"),
                  ("25", "Research Budget"), ("25", "Research Payment"), ("25", "Allocation Cost Detail"),
                  ("19", "Payable Invoice")],
         upstream=["DP-115", "DP-123", "DP-191", EMP, "DP-013", "DP-044"],
         notes="CD-174: commissions and research payments in 25, the broker vote in 23, invoices in 19. Commission spend is "
               "summed from 25 Allocation Cost Detail through DP-123, never from the 18 copies (CD-312). Owned by 25 "
               "because C-01.04 is mastered by 25 and run by FN-23; research is the main supporting consumer. Expert "
               "network approvals in Research Consumption Record are also read by Corporate Compliance (FN-44)."),
    dict(id="DP-123", name="Trade Order, Execution & Allocation Record", tier="Consumer-aligned", type="Operational",
         domain="25", owner_role=R_TRD, primary="FN-23",
         supporting=["FN-21", "FN-22", "FN-27", "FN-29", "FN-32", "FN-44"], wave="E2",
         definition="The trading record from the portfolio manager's order to the allocated fill: orders with their "
                    "handling instructions and event trail, blocks and block membership, broker placements, executions and "
                    "allocations to portfolios and SMA accounts with commission and fee detail, each traced to the 24 "
                    "investment decision and proposed trade that caused it. It gives trading, operations and compliance "
                    "one order-to-allocation chain with fill rates, working times and decision traceability.",
         objects=[("25", "Trade Order"), ("25", "Order Handling Instruction"), ("25", "Trade Order Event"),
                  ("25", "Block Order"), ("25", "Block Order Membership"), ("25", "Broker Placement"),
                  ("25", "Execution"), ("25", "Trade Allocation"), ("25", "Allocation Cost Detail")],
         upstream=["DP-115", "DP-126", "DP-128", SEC, PORT, "DP-093", EMP, "DP-013"],
         notes="CD-180: order, execution and allocation in 25; 18 books the allocation (Portfolio Transactions joins by "
               "ALLOC- key and does not depend on this product, CD-314). Consumer-aligned: trade confirmation and "
               "settlement (26), trade surveillance (38) and compliance (33) products read it as upstream rather than "
               "re-assembling orders (CD-314). Compliance Check Outcome is the 33 copy (CD-221). PII = Y: SMA account "
               "allocations and order portfolio fields are flagged. Outsourced trading (CD-147): the provider's fills "
               "arrive as executions with the provider as placement broker; grain unchanged."),
    dict(id="DP-124", name="Best Execution & Transaction Cost Analysis", tier="Consumer-aligned",
         type="Regulatory & Control", domain="25", owner_role=R_TRD, primary="FN-23",
         supporting=["FN-21", "FN-36", "FN-44"], wave="E2",
         definition="Execution quality by order, block, execution, broker, venue and asset class: implementation "
                    "shortfall and cost against each TCA benchmark, outliers, broker execution reviews and the best "
                    "execution committee's periodic reviews against the policy in force. It is the evidence the best "
                    "execution committee, fund boards and regulators see, and the input to broker allocation decisions.",
         objects=[("25", "Best Execution Policy"), ("25", "TCA Result"), ("25", "TCA Benchmark Result"),
                  ("25", "Broker Execution Review"), ("25", "Best Execution Review"), ("25", "Execution"),
                  ("25", "Broker Placement")],
         upstream=["DP-123", "DP-115", PRC, SEC, EMP, "DP-013"],
         notes="TCA measures are held once on TCA Result and TCA Benchmark Result (25) and used as given; the product does "
               "not recompute shortfall from 22 prices except as a DQ check. Rule 606 report counts are read from Best "
               "Execution Review. Outsourced trading (CD-147): Best Execution Policy names the provider; the review covers "
               "the provider's executions."),
    dict(id="DP-125", name="Trade Allocation Fairness & Trading Regulatory Controls", tier="Consumer-aligned",
         type="Regulatory & Control", domain="25", owner_role=R_TRD, primary="FN-23",
         supporting=["FN-22", "FN-32", "FN-36", "FN-44"], wave="E2",
         definition="The controls on how trades are shared and reported: new issue indications and allocations against "
                    "FINRA 5130 and 5131 eligibility, Rule 10f-3 purchases from affiliated syndicates, internal cross "
                    "trades against independent prices (Rule 17a-7), reallocations, trade errors with gains, losses and "
                    "reimbursements, and MiFIR transaction reports. It gives compliance, the fund boards and the EU and UK "
                    "entities one evidence set for fair allocation and trade reporting.",
         objects=[("25", "New Issue Offering"), ("25", "New Issue Indication"), ("25", "New Issue Allocation"),
                  ("25", "Rule 10f-3 Purchase"), ("25", "New Issue Eligibility Certification"),
                  ("25", "Cross Trade"), ("25", "Trade Error"), ("25", "MiFIR Transaction Report"),
                  ("25", "Trade Allocation")],
         upstream=["DP-123", "DP-115", "DP-126", PRC, SEC, PORT, "DP-093", "DP-004", "DP-013"],
         notes="CD-184: MiFIR transaction reports in 25, derivative and SFT reports in 26, fund filings in 35. Board "
               "reporting of 10f-3 and 17a-7 is assembled by the 35 board reporting product from this one (CD-234). "
               "A trade error that causes a loss is also a 37 Operational Loss Event (CD-244); the product carries the "
               "incident reference only. PII = Y (SMA accounts, restricted person status)."),

    # =============================================== 24 Portfolio Management & Construction (Wave E2) =====================
    dict(id="DP-126", name="Investment Governance, Decisions & Manager Assignment", tier="Consumer-aligned",
         type="Regulatory & Control", domain="24", owner_role=R_CIO, primary="FN-21",
         supporting=["FN-25", "FN-23", "FN-31", "FN-32", "FN-44", "FN-36"], wave="E2",
         definition="The record of who decides and what was decided: investment committees, members, meetings with "
                    "quorum and decisions, each investment decision with its scope, maker and rationale, and the "
                    "operational assignment of portfolio managers and teams to portfolios. It evidences the reasonable "
                    "basis of decisions, supplies the decision maker for MiFIR field 57, and reconciles the operational "
                    "manager to the manager disclosed in 01.",
         objects=[("24", "Investment Committee"), ("24", "Investment Committee Member"),
                  ("24", "Investment Committee Meeting"), ("24", "Investment Committee Decision"),
                  ("24", "Investment Decision"), ("24", "Decision Rationale"), ("24", "Investment Decision Scope"),
                  ("24", "Portfolio Management Assignment")],
         upstream=[PORT, EMP, SEC, "DP-004", "DP-013"],
         notes="CD-175 (option B drafted): the 24 assignment is the operational manager of record for investment, risk and "
               "performance products; DP-004 keeps the 01 disclosed manager for distribution; this product reads it through DP-004 and reconciles "
               "the two (CD-311). Private deal approvals: 30 references the 24 committee decision (CD-208); DP-137 reads "
               "them from here. CD-237: product governance (36) and fund boards (35) are separate bodies. PII = Y "
               "(employees)."),
    dict(id="DP-127", name="Asset Allocation Policy, Glide Paths & Commitment Pacing", tier="Consumer-aligned",
         type="Analytical", domain="24", owner_role=R_CIO, primary="FN-21",
         supporting=["FN-37", "FN-07", "FN-25", "FN-30", "FN-31"], wave="E2",
         definition="Strategic allocation policies with neutral weights and ranges, glide path points for target-date "
                    "series, house and strategy tactical views, and private markets commitment pacing plans, set against "
                    "actual allocations, benchmark weights and realized calls and distributions. It shows where portfolios "
                    "and target-date series sit against policy, tilt and pacing, for the investment committee and the "
                    "multi-asset teams.",
         objects=[("24", "Asset Allocation Policy"), ("24", "Asset Allocation Policy Line"), ("24", "Glide Path Point"),
                  ("24", "Tactical Allocation View"), ("24", "Commitment Pacing Plan")],
         upstream=["DP-126", PORT, HLD, PTX, IDX, RET, "DP-117", "DP-004", "DP-013"],
         notes="Neutral Weight is a derived copy of the policy benchmark blend (01) except where no blend exists (row rule). "
               "Actual weights come from Holdings, Tax Lots & Cash; policy-relative return comes from Official Returns "
               "and is not recomputed (CD-217). Pacing actuals: own private funds from DP-117, third-party funds from 18 "
               "Portfolio Capital Activity through Portfolio Transactions. Glide path ownership (24 or 36) is SME question 5 in 24."),
    dict(id="DP-128", name="Portfolio Targets, Investable Cash & Rebalancing", tier="Consumer-aligned",
         type="Operational", domain="24", owner_role=R_PM, primary="FN-21",
         supporting=["FN-22", "FN-23", "FN-27", "FN-30", "FN-32"], wave="E2",
         definition="Each portfolio's effective target set and construction constraints, its drift against holdings, the "
                    "day's investable cash after the portfolio manager's adjustments, and every rebalance run with its "
                    "per-portfolio result, index change triggers and proposed trades through to release. It drives the "
                    "daily rebalance and cash deployment decision and shows which proposals became orders.",
         objects=[("24", "Target Allocation Set"), ("24", "Target Allocation Line"),
                  ("24", "Portfolio Construction Constraint"), ("24", "Rebalance Run"),
                  ("24", "Rebalance Index Change Trigger"), ("24", "Rebalance Portfolio Result"),
                  ("24", "Proposed Trade"), ("24", "Investable Cash Forecast"), ("24", "Cash Forecast Adjustment")],
         upstream=["DP-126", PORT, HLD, SEC, PRC, IDX, "DP-004", "DP-013"],
         notes="CD-178: opening and projected cash are derived copies of 18 and are read from Holdings, Tax Lots & Cash; "
               "the product adds only the 24 adjustments, target and investable result. CD-211: pre- and post-trade "
               "tracking error are optimizer estimates, not 31 risk measures. Client and account restrictions apply at "
               "proposal and are 33-coded rules (CD-221), not constraints. Middle office outsourced (CD-297): the 18 "
               "inputs become provider-delivered IBOR; this product is unchanged."),
    dict(id="DP-129", name="Model Portfolio Delivery to Sponsors", tier="Consumer-aligned", type="Operational",
         domain="24", owner_role=R_MA, primary="FN-22",
         supporting=["FN-04", "FN-23", "FN-10"], wave="E2",
         definition="Every model portfolio version delivered to sponsor platforms: the target lines, model change "
                    "description and turnover, sponsor publication and release time, by model, sponsor program and "
                    "delivery method. It lets the managed accounts team prove that each model change reached every "
                    "placement on time and in the same sequence as the firm's own trading (trade rotation).",
         objects=[("24", "Target Allocation Set"), ("24", "Target Allocation Line"), ("24", "Model Change Summary")],
         upstream=["DP-128", "DP-004", "DP-005", SEC, "DP-013"],
         notes="CD-176 and C-02.04: the delivered content is the 24 target set of a model subject; 01 keeps the model, 05 "
               "the placement. Boundary with DP-050 Model Portfolio & SMA Placement and Flows: DP-050 stays the "
               "distribution view of placements, assets and flows; this product is the content and its delivery "
               "timeliness. Taxonomy gap (CD-176): no delivery-event record per sponsor; delivery is evidenced by the "
               "Sponsor Release Timestamp of the version."),
    dict(id="DP-130", name="SMA Customization & Tax Management", tier="Consumer-aligned", type="Operational",
         domain="24", owner_role=R_MA, primary="FN-22",
         supporting=["FN-14", "FN-04", "FN-21"], wave="E2",
         definition="For each tax-aware separately managed account: the tax budget for the year against gains realized to "
                    "date, the lots selected for each proposed sale with estimated gains and wash sale risk, and the client "
                    "and account restrictions applied. It drives tax-loss harvesting and gain budgeting decisions and "
                    "gives client service an account-level view of tax outcomes.",
         objects=[("24", "Tax Budget"), ("24", "Proposed Lot Selection"), ("24", "Proposed Trade")],
         upstream=["DP-128", HLD, PORT, "DP-093", "DP-077", "DP-013"],
         notes="Realized Gain to Date is a derived copy (18) and is read from Holdings, Tax Lots & Cash. PII = Y: amounts and "
               "quantities of individual SMAs are personal financial data (24 personal data rule); classification "
               "Restricted - Personal Data. Client restrictions are read through DP-077 Client Restrictions & KYC Status."),
    dict(id="DP-131", name="ETF Baskets & Custom Basket Evidence", tier="Consumer-aligned", type="Operational",
         domain="24", owner_role=R_ETF, primary="FN-22",
         supporting=["FN-23", "FN-35", "FN-36", "FN-33"], wave="E2",
         definition="Each ETF's daily creation and redemption baskets with constituents, weights, cash in lieu and the "
                    "Rule 6c-11 cash balancing amount, the custom baskets with their reason, policy basis and approval, "
                    "and their dissemination. It drives basket publication and is the Rule 6c-11(d) record "
                    "of baskets and custom basket compliance.",
         objects=[("24", "ETF Basket"), ("24", "ETF Basket Constituent"), ("24", "Custom Basket Approval"),
                  ("01", "ETF Characteristics")],
         upstream=[NAV, HLD, SEC, PORT, "DP-004", "DP-005", "DP-013"],
         notes="CD-177 and CD-200: basket construction in 24, AP order processing in 29, the creation and redemption "
               "transaction in 06, the AP agreement in 05. NAV per Creation Unit is a derived copy (27) read from NAV & "
               "Fund Financials. The daily website disclosure is 35 (CD-235). ETF capital markets (C-03.05, FN-23) reads "
               "this product for AP engagement; its own AP relationship data is 05 and is out of this brief. AP orders that "
               "used a basket are measured in the Fund Operations brief's ETF Creation & Redemption Operations (29), which "
               "should list this product upstream rather than read 24 ETF Basket again; this product does not read 29, so "
               "there is no cycle."),

    # =============================================== 34 Stewardship & Sustainable Investing (Wave E2) ===================
    dict(id="DP-132", name="Proxy Voting Record & Disclosure", tier="Consumer-aligned", type="Regulatory & Control",
         domain="34", owner_role=R_STW, primary="FN-24",
         supporting=["FN-36", "FN-14", "FN-34", "FN-21", "FN-44"], wave="E2",
         definition="Every investee meeting the firm's portfolios could vote: agenda items, proxy advisor and management "
                    "recommendations, ballots by safekeeping account with record date shares and shares on loan, the "
                    "firm's vote decision and rationale, each vote instruction with against-management and against-policy "
                    "flags, recall decisions and the proxy voting reports built from them. It is the Form N-PX, SRD II "
                    "and client voting report content and the evidence that votes followed policy and authority.",
         objects=[("34", "Voting Policy"), ("34", "Voting Guideline"), ("34", "Voting Authority Arrangement"),
                  ("34", "Investee Meeting Agenda Item"), ("34", "Proxy Advisor Recommendation"), ("34", "Ballot"),
                  ("34", "Vote Rationale"), ("34", "Vote Instruction"), ("34", "Lending Recall Decision"),
                  ("34", "Proxy Voting Report")],
         upstream=[SEC, ISS, "DP-099", CUS, PORT, HLD, "DP-093", "DP-004", EMP, "DP-013"],
         notes="CD-226 and CD-230: investee votes in 34, own-fund proxy in 13 (DP-071 stays separate), meeting event in 17, "
               "N-PX submission in 35. Record Date Shares and Shares on Loan Not Recalled are derived copies (28) and are "
               "read as given; safekeeping accounts come from Custody Network & Safekeeping Accounts (28) and entitlements are "
               "read by key. PII = Y (SMA client accounts, override "
               "approvers)."),
    dict(id="DP-133", name="Engagement & Stewardship Reporting", tier="Consumer-aligned", type="Analytical",
         domain="34", owner_role=R_STW, primary="FN-24",
         supporting=["FN-20", "FN-14", "FN-06", "FN-25"], wave="E2",
         definition="Engagement cases with investee companies, portfolio companies and market bodies: objectives and "
                    "milestones, interactions, escalations and outcomes, collaborative initiative memberships, and the "
                    "stewardship reports, signatory status and case studies built from them. It tracks engagement "
                    "progress for the stewardship team and supplies UK Stewardship Code, PRI and client stewardship "
                    "reporting.",
         objects=[("34", "Engagement"), ("34", "Engagement Objective"), ("34", "Engagement Interaction"),
                  ("34", "Escalation Action"), ("34", "Collaborative Initiative Membership"),
                  ("34", "Stewardship Report"), ("34", "Signatory Status"), ("34", "Reported Engagement")],
         upstream=["DP-121", "DP-132", ISS, HLD, EMP, "DP-004", "DP-013"],
         notes="CD-227: engagement is 34, issuer meetings are 23 (read through DP-121 by key), 03 sales activities are never "
               "used. Escalations that lead to a vote or an investment decision link to DP-132 and DP-126. Private "
               "company engagement reads the 30 portfolio company through its 02 party. PII = Y (issuer contacts, "
               "interaction summaries)."),
    dict(id="DP-134", name="ESG Data, Firm Assessments & Exclusion Lists", tier="Consumer-aligned", type="Analytical",
         domain="34", owner_role=R_SUS, primary="FN-24",
         supporting=["FN-20", "FN-21", "FN-32", "FN-30", "FN-10"], wave="E2",
         definition="The issuer-level sustainability view: indicator definitions, vendor and company-reported "
                    "observations, vendor ESG ratings, the firm's own ESG assessments, sustainable investment "
                    "determinations with EU Taxonomy alignment, and the exclusion lists with their members, joined to "
                    "holdings for coverage. It is the one source that portfolio construction, coded compliance rules and "
                    "product disclosures read for an issuer's ESG standing.",
         objects=[("34", "Sustainability Indicator Definition"), ("34", "Issuer Sustainability Observation"),
                  ("34", "ESG Rating Observation"), ("34", "Firm ESG Assessment"),
                  ("34", "Sustainable Investment Determination"), ("34", "Sustainability Exclusion List"),
                  ("34", "Exclusion List Member")],
         upstream=[ISS, SEC, HLD, "DP-044", EMP, "DP-013"],
         notes="CD-228: datasets and licenses in 14 (DP-044), observations, assessments and exclusion lists in 34; 33 rules "
               "reference the 34 list version and store no members. Consumer-aligned by design; if the Risk Measures (31) "
               "or Investment Compliance E1 product needs exclusion lists or ESG observations as upstream, promote this "
               "product to foundational (see brief §9). Assessment methodology is a 37 model (CD-246)."),
    dict(id="DP-135", name="Sustainability Metrics, PAI & Product Outcomes", tier="Consumer-aligned",
         type="Regulatory & Control", domain="34", owner_role=R_SUS, primary="FN-24",
         supporting=["FN-18", "FN-36", "FN-30", "FN-14", "FN-10", "FN-13"], wave="E2",
         definition="Portfolio, product and entity sustainability metrics in one indicator vocabulary, the PAI statements "
                    "that select them, financed emissions attributed holding by holding, achieved product sustainability "
                    "outcomes against commitments, and climate targets with progress. It produces the SFDR PAI statement "
                    "and periodic disclosures, UK SDR, TCFD and NZAM reporting, and the achieved values the EET feed "
                    "delivers.",
         objects=[("34", "PAI Calculation"), ("34", "Portfolio Sustainability Metric"),
                  ("34", "Product Sustainability Outcome"), ("34", "Financed Emissions Holding Detail"),
                  ("34", "Climate Target"), ("01", "ESG Classification")],
         upstream=["DP-134", HLD, PORT, PRC, "DP-116", "DP-004", "DP-013"],
         notes="CD-229: metrics and outcomes in 34, commitments and SFDR classification in 01. Attribution denominators by "
               "row rule (22 EVIC, 14 vendor EVIC, 30 fair value, 14 GDP). DP-064 FinDatEx feed gains this product as "
               "upstream for the EET achieved values (CD-313). Climate stress results stay 31 (CD-216). Entity-level PAI "
               "depends on the SFDR review."),

    # =============================================== 30 Private Markets (Wave E3) ========================================
    dict(id="DP-136", name="Private Fund Investor Onboarding, Side Letters & ILPA Reporting", tier="Consumer-aligned",
         type="Operational", domain="30", owner_role=R_PVO, primary="FN-26",
         supporting=["FN-25", "FN-05", "FN-14", "FN-39", "FN-44", "FN-15"], wave="E3",
         definition="The investor relations workflow of each private fund: closes and fund structure, subscription "
                    "document review and AML clearance, side letter provisions and MFN elections, commitment transfers, and "
                    "the quarterly ILPA capital account, fee and expense, and performance report and partner tax "
                    "allocations per investor. It drives closes and investor admission and is the content of every "
                    "investor statement, ILPA template and K-1.",
         objects=[("30", "Fund Close"), ("30", "Fund Structure Link"), ("30", "Subscription Document Review"),
                  ("30", "Side Letter Provision"), ("30", "MFN Election"), ("30", "Commitment Transfer"),
                  ("30", "Partner Tax Allocation"), ("30", "Investor Capital Account"),
                  ("30", "Capital Account Fee & Expense Detail")],
         upstream=["DP-116", "DP-117", RET, IPM, "DP-003", "DP-093", "DP-077", "DP-005", "DP-004", "DP-013"],
         notes="Investor IRR and multiples are read from Private Markets Investor Performance & PME (32 Investor "
               "Performance Measure, CD-219), fund-level measures from Official Returns, never recalculated. Report presentation and delivery are 12 (DP-068) and K-1 delivery is 13 (DP-091 boundary); "
               "the partner tax split is 30 under CD-149 and reads the 27 Fund Tax Year Record by key. Placement agents "
               "(C-09.09) stay with 05 and DP-034. Outsourced administration (CD-297): ILPA reports and K-1s arrive from "
               "the administrator; the product becomes review, approval and delivery oversight at the same grain. "
               "PII = Y."),
    dict(id="DP-137", name="Private Deal Pipeline & Allocation", tier="Consumer-aligned", type="Analytical",
         domain="30", owner_role=R_PVT, primary="FN-25",
         supporting=["FN-21", "FN-32", "FN-44", "FN-40"], wave="E3",
         definition="Every private investment opportunity from sourcing to close: deal stage history, due diligence "
                    "workstreams and material findings, the investment committee decision and the allocation of the deal "
                    "across funds and co-investors. It shows pipeline conversion and time in stage for the deal teams and "
                    "evidences fair allocation across funds and co-investment vehicles.",
         objects=[("30", "Deal"), ("30", "Deal Stage Event"), ("30", "Due Diligence Workstream"),
                  ("30", "Deal Allocation")],
         upstream=["DP-126", "DP-116", ISS, EMP, "DP-004", "DP-013"],
         notes="CD-208: the 30 deal references the 24 committee decision (read through DP-126). Pre-trade compliance on deals "
               "is 33 (CD-221). Restricted list entries for deal targets are 38 (CD-256). Co-investment by the firm's own "
               "capital is 43 (CD-276). PII = Y (direct co-investors who are individuals, deal leads)."),
    dict(id="DP-138", name="Portfolio Company Monitoring & Realizations", tier="Consumer-aligned", type="Analytical",
         domain="30", owner_role=R_PVT, primary="FN-25",
         supporting=["FN-26", "FN-28", "FN-24", "FN-30", "FN-31"], wave="E3",
         definition="Each private investment from entry to exit: the portfolio company, ownership over time and "
                    "investment status, reported financial and real asset operating metrics, the latest fair value, and "
                    "realizations with gross proceeds. It supports portfolio company reviews, valuation committee "
                    "preparation and exit decisions, and supplies the deal-level inputs to private markets performance.",
         objects=[("30", "Portfolio Company Profile"), ("30", "Private Investment"),
                  ("30", "Investment Ownership Period"), ("30", "Real Asset Metric"),
                  ("30", "Portfolio Company Financial Metric"), ("30", "Realization"),
                  ("22", "Private Asset Valuation Detail")],
         upstream=["DP-137", PRC, RET, SEC, ISS, "DP-004", "DP-013"],
         notes="CD-170: fair values and the valuation committee are 22 and are read, never set here (Fair Value "
               "Determination through Prices, FX & Curves; Private Asset Valuation Detail directly). Deal-level IRR and "
               "multiples are 32 Private Markets Performance Measure (CD-219), read from Official Returns. ESG data on "
               "portfolio companies is 34 through the 02 party (DP-134)."),
    dict(id="DP-139", name="Fund Financing, Waterfall & Carried Interest", tier="Consumer-aligned",
         type="Regulatory & Control", domain="30", owner_role=R_PVO, primary="FN-26",
         supporting=["FN-25", "FN-38", "FN-41", "FN-33", "FN-40"], wave="E3",
         definition="Fund-level leverage and GP economics: credit facilities with drawdowns, days outstanding and covenant "
                    "tests, the waterfall terms in force, each waterfall calculation with its tier results, and accrued "
                    "and paid carried interest with clawback exposure and escrow. It controls facility usage against LPA "
                    "limits and evidences every carry distribution before approval.",
         objects=[("30", "Fund Credit Facility"), ("30", "Facility Drawdown"), ("30", "Covenant Test"),
                  ("30", "Distribution Waterfall Terms"), ("30", "Waterfall Calculation"),
                  ("30", "Waterfall Tier Result"), ("30", "Carried Interest Position")],
         upstream=["DP-116", "DP-117", NAV, "DP-115", "DP-004", EMP, "DP-013"],
         notes="CD-205: waterfall and carry in 30, carry awards to employees in 20, GP entity books in 19. The fund NAV used "
               "is a derived copy (27) read from NAV & Fund Financials. A hurdle IRR inside a waterfall stays a 30 "
               "calculation value, not a reported return (CD-219). Fund lenders are 02 parties; DP-115 is read only where "
               "the lender is also an approved counterparty. Outsourced administration (CD-297): calculations arrive "
               "from the administrator (Calculation Performed By); the product adds GP review and approval."),
]

DECISIONS = [
    {"id": "CD-310", "theme": "Transactions & Measures",
     "title": "Private fund net assets in Firm AUM: the latest final investor capital accounts, rolled forward by later calls and distributions",
     "domains": ["30", "27", "06", "32"],
     "issue": "CD-292 says Firm AUM takes private funds from 30 investor capital accounts, but capital accounts are "
              "produced quarterly (often 45 to 90 days after quarter-end) on estimated and final bases, while calls and "
              "distributions occur daily. Without a rule, Firm AUM for a private fund can be stale, double count a call, "
              "or switch basis from month to month.",
     "resolution": "Proposed: for Firm AUM at a month-end, a private fund's net assets = the sum of Ending Capital Balance "
                   "of the latest capital account version on the 'Final' data basis (DP-116), plus contributions less "
                   "distributions allocated after that period end and up to the month-end (DP-117). Where only an "
                   "'Estimated' basis exists for the latest quarter, it is used and flagged as estimated. NAV & Fund "
                   "Financials (27) publishes the result as the private fund row of Firm AUM; DP-116 and DP-117 publish "
                   "no AUM measure of their own. The Wave E5 Firm AUM Reconciliation shows the roll-forward as a separate "
                   "cause. Private fund cash flows never enter DP-008 (CD-204).",
     "rationale": "One certified number with a stated basis and as-of rule; it keeps the cash flows in 30 and the "
                  "certified AUM in 27, as CD-292 and CD-204 require.",
     "action": "SME decision", "status": "Proposed", "priority": "High", "owner_role": "Head of Fund Accounting"},
    {"id": "CD-311", "theme": "Portfolio Management",
     "title": "Portfolio manager in data products: 24 operational assignment for investment products, 01 disclosed manager for distribution, reconciled in DP-126",
     "domains": ["24", "01", "20", "18"],
     "issue": "CD-175 (option B drafted) leaves two records of who manages what: the 24 Portfolio Management Assignment at "
              "portfolio grain and the 01 Portfolio Manager Assignment at product grain (disclosed). Products could pick "
              "either and show different managers for the same fund.",
     "resolution": "Proposed: investment, risk, performance attribution and MiFIR products take the manager from the 24 "
                   "assignment through DP-126; distribution products (DP-004 and its consumers) keep the 01 disclosed "
                   "manager; DP-126 carries a reconciliation measure (disclosed managers with no operational assignment on "
                   "an implementing portfolio, and the reverse). If the client chooses option A, DP-004 is re-pointed to "
                   "DP-126 by decision.",
     "rationale": "Keeps DP-004 unchanged under option B and gives one named place where the two records meet.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Investment Officer"},
    {"id": "CD-312", "theme": "Trading",
     "title": "Commission and research spend is reported from 25 through DP-123 and DP-122, never summed from the 18 transaction copies",
     "domains": ["25", "18", "19", "27", "35"],
     "issue": "CD-174 makes 18 Commission Amount and Research Payment Component derived copies of 25 Allocation Cost "
              "Detail for trades booked from allocations, mastered in 18 otherwise. Board soft-dollar reports, MiFID costs "
              "and charges, fund expense analysis and broker reviews could sum either and disagree.",
     "resolution": "Proposed: commission, research component and broker spend by broker, fund, strategy and period are "
                   "published by DP-122 from DP-123 allocations; products in Investment Operations, Fund Operations and "
                   "Fund Governance (35 board reporting) take them from DP-122. 18 rows not booked from an allocation "
                   "(transfers, corporate actions, external manager trades) are reported by the 18 products as a separate "
                   "line, not added to broker commission.",
     "rationale": "One number per concept across products, following CD-174's master.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Trading"},
    {"id": "CD-313", "theme": "Product",
     "title": "DP-064 FinDatEx feed takes EET achieved sustainability values from DP-135",
     "domains": ["34", "01", "05"],
     "issue": "DP-064 assembles the EET from 01 ESG Classification (commitments). The achieved values (sustainable "
              "investment share, taxonomy alignment, PAI considered) are mastered in 34 (CD-229), which proposed but did not "
              "apply a 01 derived copy for EET delivery.",
     "resolution": "Proposed: DP-064 gains DP-135 as upstream and reads the achieved values from the latest approved 34 "
                   "Product Sustainability Outcome; no 01 derived copy is added. The DP-064 change is a lineage change to an "
                   "existing product traced to this decision (CD-299).",
     "rationale": "Avoids a second copy of the achieved values and keeps the EET consistent with the SFDR periodic "
                  "disclosure.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Sustainable Investing"},
    {"id": "CD-314", "theme": "Trading",
     "title": "The order-to-allocation record (DP-123) is consumer-aligned; the 18 book of record joins it by key",
     "domains": ["25", "18", "26", "33", "38"],
     "issue": "Trade allocations feed the 18 book of record, 26 confirmations, 33 post-trade checks and 38 trade "
              "surveillance. If the 18 foundational product (Portfolio Transactions) depended on a 25 product, the 25 "
              "product would have to be foundational, and the order-to-allocation chain would be pulled into Wave E1.",
     "resolution": "Proposed: DP-123 Trade Order, Execution & Allocation Record is consumer-aligned (Wave E2). Portfolio "
                   "Transactions (18) carries Source Allocation ID (ALLOC-, CD-180) as a key and does not list DP-123 as "
                   "upstream. Consumer products in 26, 33 and 38 that need order, execution or allocation attributes list "
                   "DP-123 as upstream instead of reading the 25 objects again.",
     "rationale": "Keeps the E1 list to masters and lets every trading consumer share one assembled chain.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Trading"},
    {"id": "CD-315", "theme": "Enterprise Structure",
     "title": "The Counterparty and Broker dimension of SM-00 is sourced from DP-115",
     "domains": ["25", "02", "26", "31", "33"],
     "issue": "CD-296 adds Counterparty and Broker to the one SM-00 spine but does not name the source product. Brokers and "
              "counterparties are 02 parties; DP-003 and DP-001 conform other 02 roles (institutional clients, "
              "distributors).",
     "resolution": "Proposed: the Counterparty and Broker dimension is published from DP-115 (02 party facts plus the 25 "
                   "approval profile, scope and tier), tagged Investment area. Settlement (26), exposure (31), compliance "
                   "(33) and surveillance (38) products join to it; limit utilization and exceedance stay 31 (CD-215).",
     "rationale": "One dimension, one source product, as CD-296 requires.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Trading"},
]
