"""Wave E0 product brief proposals: Investment Operations (middle office).

Brief: 00_Program/Expansion/Product_Briefs/Investment_Operations.md
Data Domains: 18 Portfolio & Investment Book of Record, 22 Market Data & Pricing, 26 Trade Operations, Settlement &
Collateral, 31 Investment Risk, 32 Performance & Attribution, 33 Investment Compliance.
Reserved product IDs DP-140 to DP-164 (DP-164 left unused); reserved decision IDs CD-320 to CD-329 (CD-320 to CD-324 used).
Check: /usr/bin/python3 data_products/candidate_coverage.py proposals_dp_investment_ops  (from _tools)

Upstream names that are not DP- ids are Wave E1 candidates of the parallel briefs, by the plan's names (§7 E1):
"Security Master & Identifiers" and "Issuer Hierarchy & Classifications" (17, Foundations); "Approved Broker &
Counterparty Master" (25, Investment); "NAV & Fund Financials" (27, Fund Operations); "Investor Capital Accounts"
(30, Investment); "Employee & Position Master" (20, Corporate A); "Application & System Inventory" (41, Corporate B).

Briefs accepted 2026-10-08: DECISIONS below are merged into decisions.py (kept here as the record of the proposal);
CANDIDATES remain the input to Waves E1 to E4 (read by data_products/candidate_coverage.py).
"""

SEC = "DP-097"   # Security Master & Identifiers
ISS = "DP-098"   # Issuer Hierarchy & Classifications
BRK = "DP-115"   # Approved Broker & Counterparty Master
NAV = "DP-165"   # NAV & Fund Financials
ICA = "DP-116"   # Investor Capital Accounts
EMP = "DP-192"   # Employee & Position Master
APP = "DP-211"   # Application & System Inventory

CANDIDATES = [
    # ================================================ Foundational (Wave E1) ================================================
    dict(id="DP-140", name="Portfolio Master & Mandate Link", tier="Foundational", type="Master & Reference", domain="18",
         owner_role="Head of Investment Operations", primary="FN-27",
         supporting=["FN-21", "FN-22", "FN-30", "FN-31", "FN-32", "FN-33", "FN-14"], wave="E1",
         definition="The conformed record of every portfolio (managed book) the firm runs, with its identifiers, IBOR "
                    "accounting basis, lifecycle events and business-line detail, and the dated links that join it to "
                    "the funds, mandates, SMA accounts and model portfolios it implements and to its parent, sleeve and "
                    "carve-out books. It is the one place any product resolves a portfolio to a fund, mandate or "
                    "account, so risk, performance, compliance and the Firm AUM reconciliation slice by the same book.",
         objects=[("18", "Portfolio"), ("18", "Portfolio Identifier"), ("18", "Portfolio Implementation Link"),
                  ("18", "Portfolio Hierarchy Link"), ("18", "Portfolio Accounting Basis"),
                  ("18", "Portfolio Lifecycle Event"), ("18", "Fund Portfolio Detail"), ("18", "SMA Portfolio Detail"),
                  ("18", "Private Fund Portfolio Detail")],
         upstream=["DP-004", "DP-093", "DP-005", "DP-013", APP],
         notes="Concept ownership row 'Portfolio (managed book)', 18, PORT- (CD-145). Fund, mandate and model "
               "dimensions come from DP-004 once it carries 01 Investment Mandate (CD-322); SMA accounts from DP-093; "
               "sponsor program agreements from DP-005. CD-324: no other product carries its own portfolio-to-fund "
               "mapping. CD-297 / CD-147: IBOR Operating Model and Middle Office Provider are attributes of the "
               "record; if the middle office is outsourced the grain is unchanged (portfolio set-up is still the "
               "firm's) but set-up events arrive from the provider. Portfolio Name and identifiers are personal data "
               "for individuals' SMAs."),

    dict(id="DP-141", name="Portfolio Transactions", tier="Foundational", type="Conformed Facts", domain="18",
         owner_role="Head of Investment Operations", primary="FN-27",
         supporting=["FN-29", "FN-31", "FN-33", "FN-23", "FN-39"], wave="E1",
         definition="Every transaction booked to a portfolio in the IBOR (trades, corporate action bookings, "
                    "transfers, in-kind movements and adjustments) with its explicit costs and booking and amendment "
                    "history, plus the portfolio capital activity that moves cash and assets into and out of each "
                    "book. It gives performance its external cash flows, trade operations the booked trades it "
                    "settles, and fund accounting and tax one record of what each portfolio did.",
         objects=[("18", "Portfolio Transaction"), ("18", "Transaction Cost & Charge"),
                  ("18", "Portfolio Transaction Event"), ("18", "Portfolio Capital Activity")],
         upstream=["DP-140", "DP-143", "DP-004", "DP-093", SEC, BRK],
         notes="Concept ownership row 'Portfolio Transaction', 18, PTXN-. 'Transaction' bare stays 06. Portfolio "
               "Capital Activity is the book's cash flow, not a sales flow: net flows stay certified in DP-008 and "
               "are never re-derived from it (CD-292 logic, CD-320). Commission Amount and Research Payment Component "
               "are 25 copies (CD-174); Settlement Confirmed Indicator is a 26 copy (CD-181), and settlement detail "
               "is read from DP-151. Trade allocations arrive from the Investment brief's order and execution "
               "product (25); only the allocation reference is carried here."),

    dict(id="DP-142", name="Holdings, Tax Lots & Cash", tier="Foundational", type="Conformed Facts", domain="18",
         owner_role="Head of Investment Operations", primary="FN-27",
         supporting=["FN-21", "FN-22", "FN-30", "FN-31", "FN-32", "FN-33", "FN-34", "FN-36"], wave="E1",
         definition="What each portfolio holds by holding view and date, valued from approved prices and FX rates, "
                    "with derivative and fund-interest detail, open tax lots and lot relief, cash balances and "
                    "projected cash, the locked position snapshots and the IBOR valuation summary. It is the conformed "
                    "holdings set that risk, performance, compliance, fund filings and portfolio management read, "
                    "and the source of portfolio market value.",
         objects=[("18", "Portfolio Holding"), ("18", "Holding Valuation"), ("18", "Derivative Holding Detail"),
                  ("18", "Fund Interest Holding Detail"), ("18", "Tax Lot"), ("18", "Lot Relief"),
                  ("18", "Cash Balance"), ("18", "Projected Cash Movement"), ("18", "Portfolio Position Snapshot"),
                  ("18", "Portfolio Valuation Summary")],
         upstream=["DP-140", "DP-141", "DP-143", SEC],
         notes="Concept ownership rows 'Portfolio Holding', 18, HLD- and 'Tax Lot', 18, LOT- (CD-146). CD-292 / "
               "CD-320: Total IBOR Market Value is published as 'Portfolio Market Value (IBOR)', one of the three "
               "numbers the Wave E5 Firm AUM Reconciliation compares; it is never labeled or published as AUM and is "
               "not certified. Prices, FX and deltas are 22 copies (CD-167, CD-168); Encumbered Quantity and Initial "
               "Margin Posted are 26 copies (CD-181) and are read as held in 18, so no consumer product is upstream. "
               "Holding views published: start of day and end of day (18 SME question 6 on intraday). Projected "
               "Cash Movement feeds the 24 investable cash forecast (CD-178). If the middle office is outsourced the "
               "grain stays portfolio x instrument x date, sourced from the provider's IBOR file, and DP-150 carries "
               "the oversight measures."),

    dict(id="DP-143", name="Prices, FX & Curves", tier="Foundational", type="Conformed Facts", domain="22",
         owner_role="Head of Pricing and Valuation", primary="FN-28",
         supporting=["FN-27", "FN-29", "FN-30", "FN-31", "FN-33", "FN-38", "FN-23"], wave="E1",
         definition="The approved price of every instrument at every pricing point and date (with its fair value "
                    "level and the approved fair value determinations behind Level 3 marks), FX rate observations, "
                    "reference rate fixings, curves and volatility surfaces, approved pricing analytics and instrument "
                    "factors, and the Rule 6c-11 market statistics of own ETFs. Every valuation in the firm (IBOR, "
                    "NAV, risk, collateral, performance and the general ledger) applies these values by reference "
                    "instead of sourcing its own.",
         objects=[("22", "Pricing Point"), ("22", "Approved Price"), ("22", "Fair Value Determination"),
                  ("22", "FX Rate Observation"), ("22", "Reference Rate Fixing"), ("22", "Curve Definition"),
                  ("22", "Curve Point Observation"), ("22", "Volatility Surface Point"),
                  ("22", "Pricing Analytics Observation"), ("22", "Instrument Factor Observation"),
                  ("22", "ETF Market Statistic")],
         upstream=[SEC, "DP-013"],
         notes="Concept ownership rows: Approved Price (PRICE-), Fair Value Determination (FVD-), FX Rate Observation "
               "(FXR-), Reference Rate Fixing, Curve Definition (CURVE-), ETF Market Statistic (CD-167, CD-168, "
               "CD-170, CD-206). CD-321: own fund share class rows carry the 27 NAV as the 22 record holds it (CD-167 "
               "row rule), so NAV & Fund Financials is downstream of this product and never upstream. One current "
               "approved version per key is published, with version history for restated NAVs. FX: the pair as "
               "quoted only; inverses and crosses are computed by consumers (CD-168). Classification Confidential - "
               "Licensed: redistribution follows the 14 permitted uses (DP-044). If pricing is outsourced (Pricing "
               "Policy 'Pricing Operating Model'), the approved price is received from the provider and DP-148 holds "
               "the oversight measures."),

    dict(id="DP-144", name="Index Levels & Constituents", tier="Foundational", type="Conformed Facts", domain="22",
         owner_role="Head of Market Data", primary="FN-28",
         supporting=["FN-31", "FN-21", "FN-22", "FN-30", "FN-32", "FN-14"], wave="E1",
         definition="Daily levels of every benchmark and index the firm references, by return variant and currency, "
                    "with constituents, weights and announced index changes, all keyed by the 01 Benchmark. It is the "
                    "single index data set for benchmark returns, attribution, index-relative risk and compliance "
                    "rules, and ETF and index-fund rebalancing.",
         objects=[("22", "Index Level Observation"), ("22", "Index Constituent"), ("22", "Index Change Announcement")],
         upstream=["DP-004", "DP-013", SEC],
         notes="Concept ownership row 'Index Level Observation / Index Constituent / Index Change Announcement', 22 "
               "(CD-169 option A). The benchmark dimension needs DP-004 to carry 01 Benchmark and Product Benchmark "
               "Assignment (CD-322). Boundary with DP-072 Index Licensing Fees: DP-072 keeps the 14 license and fee "
               "record and stays separate; DP-144 holds the data. Licensed data: classification Confidential - "
               "Licensed; constituent weights are usually restricted to internal use."),

    dict(id="DP-145", name="Official Returns", tier="Foundational", type="Conformed Facts", domain="32",
         owner_role="Head of Performance Measurement", primary="FN-31",
         supporting=["FN-14", "FN-01", "FN-16", "FN-10", "FN-13", "FN-36", "FN-21", "FN-26", "FN-37"], wave="E1",
         definition="The firm's official, signed-off performance: portfolio, share class, account, composite and "
                    "model portfolio returns by fee, price, tax and sales-charge basis, benchmark returns, private "
                    "fund and investment IRRs and multiples, with the calculation policy and profile in force, the "
                    "period close and every restatement. Every client report, shareholder report, marketing piece, "
                    "regulatory filing and scorecard takes its returns from here and never recalculates them.",
         objects=[("32", "Performance Calculation Policy"), ("32", "Performance Measurement Profile"),
                  ("32", "Performance Return"), ("32", "Return Component Detail"),
                  ("32", "Hypothetical Performance Detail"), ("32", "Benchmark Return"),
                  ("32", "Private Markets Performance Measure"), ("32", "Performance Period Close"),
                  ("32", "Performance Restatement")],
         upstream=["DP-140", "DP-141", "DP-142", "DP-143", "DP-144", "DP-004", "DP-093", NAV, ICA, "DP-117"],
         notes="Concept ownership rows 'Performance Return', 32, RETURN- and 'Benchmark Return', 32 (CD-217); "
               "'Private Markets Performance Measure', 32 (CD-219). Certified families per CD-293 / CD-320: official "
               "returns and private fund IRR and multiples are published only here; certified rows are Return Status "
               "Final or Restated, Preliminary rows are flagged. Share class returns use the 27 NAV (NAV & Fund "
               "Financials); portfolio and account rows use 18 values. Account returns per CD-220 option A are "
               "personal data. Hypothetical (model) returns carry the Marketing Rule flag. CD-217 SME: the 27 "
               "Financial Highlights Total Return reads the fiscal-period share class row (option A). If returns are "
               "calculated by an administrator or recordkeeper (Return Source), the product holds them as received "
               "and approved."),

    dict(id="DP-146", name="Risk Measures", tier="Foundational", type="Conformed Facts", domain="31",
         owner_role="Head of Investment Risk", primary="FN-30",
         supporting=["FN-21", "FN-32", "FN-36", "FN-14", "FN-10", "FN-42"], wave="E1",
         definition="Independent ex-ante risk of every portfolio: the risk models, factors and loadings used, each "
                    "approved calculation run, portfolio risk measures (VaR, expected shortfall, tracking error, "
                    "volatility, beta), their decomposition, exposures by dimension and VaR back-tests. It is the one "
                    "source of certified VaR and tracking error that limit monitoring, fund risk programs, compliance "
                    "rules and client reports read.",
         objects=[("31", "Risk Model"), ("31", "Risk Factor"), ("31", "Risk Factor Return"),
                  ("31", "Instrument Factor Loading"), ("31", "Risk Calculation Run"), ("31", "Portfolio Risk Measure"),
                  ("31", "Risk Decomposition"), ("31", "VaR Back-Test"), ("31", "Portfolio Exposure")],
         upstream=["DP-140", "DP-142", "DP-143", "DP-144", "DP-004", SEC, NAV],
         notes="Concept ownership rows 'Risk Model', 'Risk Factor', 'Instrument Factor Loading', 'Risk Calculation "
               "Run', 'Portfolio Risk Measure', 'Portfolio Exposure', 31 (CD-211). Certified per CD-293 / CD-320: "
               "ex-ante VaR and tracking error are published only here and only from approved runs. Ex-post "
               "statistics are 32 (DP-157); optimizer estimates are 24. Risk models reference the 37 model inventory "
               "(CD-246, CD-294). Realized Daily P&L on back-tests is a 27 copy, hence NAV & Fund Financials "
               "upstream. Measured Portfolio is personal data for individuals' SMAs. If the risk engine is a vendor "
               "service the grain is unchanged; the run record names the vendor dataset."),

    dict(id="DP-147", name="Trading Agreements & Settlement Instructions", tier="Foundational",
         type="Master & Reference", domain="26", owner_role="Head of Trade Operations", primary="FN-29",
         supporting=["FN-23", "FN-34", "FN-35", "FN-14", "FN-30", "FN-45"], wave="E1",
         definition="The counterparty-facing reference terms of trade operations: ISDA, CSA, GMRA, MRA, MSFTA, "
                    "clearing and give-up agreements with their credit support terms, eligible collateral and "
                    "termination triggers, and the verified standing settlement instructions of funds, portfolios, "
                    "client mandates and counterparties with the settlement cycle rules by market. Settlement, "
                    "collateral, counterparty exposure, broker approval and custody set-up all read these terms from "
                    "one governed record.",
         objects=[("26", "Trading Agreement"), ("26", "Credit Support Terms"), ("26", "Eligible Collateral Schedule"),
                  ("26", "Termination Event Trigger"), ("26", "Standing Settlement Instruction"),
                  ("26", "SSI Verification"), ("26", "Settlement Cycle Rule")],
         upstream=["DP-140", "DP-004", "DP-013"],
         notes="Concept ownership rows 'Trading Agreement', 26, TAGR- (CD-182) and 'Standing Settlement Instruction', "
               "26, SSI- (CD-155 option A). CD-321: the 25 Approved Broker & Counterparty Master reads agreement "
               "status from this product, so this product takes counterparty identity as the 02 party key and does "
               "not list the 25 product upstream. The enterprise contract record is 39 (CD-257); this product holds "
               "the typed trading terms. DP-086 re-points its SSI read here (CD-323). SSI cash account and client "
               "safekeeping account numbers are personal data on individual mandates. If trade support is "
               "outsourced, SSIs are still the firm's record (they authorize payments); the provider's SSI changes "
               "arrive for verification."),

    # ============================================ Consumer-aligned (Waves E2, E3) ============================================
    dict(id="DP-148", name="Pricing Control & Price Challenges", tier="Consumer-aligned", type="Regulatory & Control",
         domain="22", owner_role="Head of Pricing and Valuation", primary="FN-28",
         supporting=["FN-33", "FN-49", "FN-36", "FN-42"], wave="E2",
         definition="Daily evidence of how each approved price was reached: the pricing policy, source hierarchy and "
                    "tolerance rules in force, every observation received, the validation exceptions raised, the "
                    "overrides applied and the challenges sent to vendors with their outcomes. Pricing works the "
                    "day's exceptions before the NAV strike from it, and the valuation designee and fund boards see "
                    "stale, overridden and challenged prices by vendor and asset class.",
         objects=[("22", "Pricing Policy"), ("22", "Pricing Source Hierarchy Rule"), ("22", "Price Tolerance Rule"),
                  ("22", "Pricing Point"), ("22", "Price Observation"), ("22", "Evaluated Price Detail"),
                  ("22", "Broker Quote Detail"), ("22", "Approved Price"), ("22", "Price Validation Exception"),
                  ("22", "Price Override"), ("22", "Price Challenge")],
         upstream=["DP-143", "DP-044", SEC, EMP],
         notes="Price challenges are 22, dataset-level vendor issues stay 14 (CD-171). If pricing is outsourced, the "
               "grain becomes the provider's daily exception, override and challenge report against the firm's "
               "policy, plus SLA results (CD-297)."),

    dict(id="DP-149", name="Fair Value & Valuation Committee Oversight", tier="Consumer-aligned",
         type="Regulatory & Control", domain="22", owner_role="Head of Pricing and Valuation", primary="FN-28",
         supporting=["FN-36", "FN-33", "FN-25", "FN-42", "FN-30"], wave="E2",
         definition="The valuation designee's record under SEC Rule 2a-5 and the AIFMD valuation function: "
                    "committees, membership and meetings, every fair value determination with its method, inputs, "
                    "triggers and factors, private asset valuation detail and back-tests against later trades and "
                    "prices. It answers which holdings are fair valued, how, by whom and how well the marks held up, "
                    "and feeds the board's valuation reporting.",
         objects=[("22", "Valuation Committee"), ("22", "Valuation Committee Member"),
                  ("22", "Valuation Committee Meeting"), ("22", "Fair Value Determination"),
                  ("22", "Private Asset Valuation Detail"), ("22", "Valuation Input"),
                  ("22", "Fair Value Trigger Event"), ("22", "Fair Value Factor"), ("22", "Valuation Back-Test"),
                  ("22", "Approved Price")],
         upstream=["DP-143", "DP-142", "DP-140", SEC, EMP],
         notes="CD-170. The approved fair value amount is published by DP-143; this product holds the governance "
               "and evidence around it. The board report itself is a 35 Board Report Received (Fund Operations "
               "brief) that reads this product (CD-234). Valuation models reference the 37 model inventory. Private "
               "asset values feed 30 and 32 through DP-143."),

    dict(id="DP-150", name="IBOR Control, Adjustments & Book Differences", tier="Consumer-aligned",
         type="Regulatory & Control", domain="18", owner_role="Head of Investment Operations", primary="FN-27",
         supporting=["FN-33", "FN-34", "FN-21", "FN-42"], wave="E2",
         definition="The control view of the book of record: start-of-day snapshot status and locks, manual position "
                    "and cost adjustments with their approvals, back-dated and amended bookings, and the daily "
                    "difference between IBOR portfolio market value and the fund accounting book. It drives "
                    "investment operations' exception queue and evidences that portfolio managers trade on a "
                    "controlled start-of-day position.",
         objects=[("18", "Portfolio Position Snapshot"), ("18", "Position Adjustment"),
                  ("18", "Portfolio Transaction Event"), ("18", "Portfolio Valuation Summary"),
                  ("18", "Portfolio Holding"), ("18", "Cash Balance")],
         upstream=["DP-140", "DP-141", "DP-142", NAV, EMP],
         notes="The IBOR versus fund accounting difference is an operational exception measure by portfolio and "
               "date. It is not the Wave E5 Firm AUM Reconciliation (CD-292), not a 27 NAV Control Check and not a 28 "
               "custody reconciliation (CD-196); those stay with their producers. If the middle office is outsourced "
               "this product becomes the oversight product: provider IBOR break and SLA reports against the firm's "
               "own snapshot (CD-297)."),

    dict(id="DP-151", name="Trade Confirmation, Settlement & Fails", tier="Consumer-aligned", type="Operational",
         domain="26", owner_role="Head of Trade Operations", primary="FN-29",
         supporting=["FN-23", "FN-27", "FN-33", "FN-34", "FN-35"], wave="E2",
         definition="Every allocated trade from confirmation and affirmation through instruction, status advices and "
                    "settlement, with match exceptions, fails, buy-ins and CSDR penalties, measured against the "
                    "settlement cycle and affirmation cut-offs of each market. Trade operations works fails and "
                    "penalty disputes from it, and trading, fund accounting and custody see which trades will not "
                    "settle on time and why.",
         objects=[("26", "Trade Confirmation"), ("26", "Confirmation Match Exception"),
                  ("26", "Settlement Instruction"), ("26", "Cash Payment Detail"), ("26", "Loan Settlement Detail"),
                  ("26", "Settlement Status Event"), ("26", "Settlement Fail"), ("26", "Buy-In Notice"),
                  ("26", "Settlement Penalty"), ("26", "Settlement Cycle Rule")],
         upstream=["DP-147", "DP-141", "DP-140", "DP-013", SEC, BRK],
         notes="CD-183: trade-level settlement only; custody statements and reconciliations are 28, ledger entries 27. "
               "ETF in-kind deliveries reference the 29 AP order (CD-200). Trade allocations come from the "
               "Investment brief's order and execution product (25); name it upstream at spec time. Penalties the "
               "firm absorbs reach 37 as Loss Event Amount copies (CD-244). If trade support is outsourced, the grain "
               "becomes the provider's daily confirmation, fail and penalty report with SLA results (CD-297)."),

    dict(id="DP-152", name="OTC Derivative Lifecycle & Trade Reporting", tier="Consumer-aligned",
         type="Regulatory & Control", domain="26", owner_role="Head of Trade Operations", primary="FN-29",
         supporting=["FN-30", "FN-33", "FN-44", "FN-36", "FN-23"], wave="E2",
         definition="OTC derivative and repo trades after execution: UTIs, legs, clearing, lifecycle events and "
                    "scheduled cash flows, with every EMIR, UK EMIR, CFTC Part 45, SEC Regulation SBSR and SFTR report "
                    "submitted for them. It shows derivatives operations the trades and payments due, and shows "
                    "compliance whether every reportable event was reported on time and accepted.",
         objects=[("26", "OTC Derivative Trade"), ("26", "Clearing Detail"), ("26", "OTC Trade Leg"),
                  ("26", "OTC Lifecycle Event"), ("26", "OTC Cash Flow"), ("26", "Repo Trade"),
                  ("26", "Derivative Trade Report")],
         upstream=["DP-147", "DP-140", "DP-143", SEC, BRK],
         notes="CD-184: derivatives and repo reports here, MiFIR transaction reports in 25, SFTR for securities "
               "lending in 28, fund filings in 35. Reporting obligations and counterparty classifications come from "
               "38 (Corporate B brief). Product terms (UPI) are 17. If derivatives operations or reporting are "
               "delegated, the grain becomes the delegate's submission and rejection report (CD-297)."),

    dict(id="DP-153", name="Margin, Collateral & Counterparty Exposure", tier="Consumer-aligned", type="Operational",
         domain="26", owner_role="Head of Trade Operations", primary="FN-29",
         supporting=["FN-30", "FN-23", "FN-33", "FN-40", "FN-32"], wave="E2",
         definition="Daily margin calls and disputes, collateral movements and balances, initial margin "
                    "calculations and counterparty exposure after collateral, by trading agreement, netting set and "
                    "portfolio, with the termination triggers that could let a counterparty close out a fund. "
                    "Collateral management decides calls, disputes and eligible collateral from it, and risk and "
                    "trading see net exposure to each counterparty.",
         objects=[("26", "Margin Call"), ("26", "Margin Call Dispute"), ("26", "Collateral Movement"),
                  ("26", "Collateral Balance"), ("26", "Initial Margin Calculation"), ("31", "Counterparty Exposure"),
                  ("26", "Trading Agreement"), ("26", "Credit Support Terms"), ("26", "Eligible Collateral Schedule"),
                  ("26", "Termination Event Trigger")],
         upstream=["DP-147", "DP-152", "DP-143", "DP-142", "DP-140", NAV, BRK],
         notes="CD-215: Counterparty Exposure is mastered in 31 and read here with the 26 collateral it copies; "
               "utilization and exceedance of 25 counterparty trading limits are published by DP-154 only. CD-181: "
               "the 18 encumbrance and initial margin copies are derived from these balances. CD-198: securities "
               "lending collateral is 28 (Fund Operations brief). Termination triggers are tested against the 27 "
               "NAV. If collateral management is outsourced (tri-party agent, collateral manager), the grain becomes "
               "the agent's call, dispute and balance report (CD-297)."),

    dict(id="DP-154", name="Risk Limits, Stress Tests & Exceedances", tier="Consumer-aligned",
         type="Regulatory & Control", domain="31", owner_role="Head of Investment Risk", primary="FN-30",
         supporting=["FN-21", "FN-23", "FN-36", "FN-42", "FN-24"], wave="E2",
         definition="Every risk limit with its daily utilization by portfolio, the exceedances raised and their "
                    "escalation, and the stress scenarios, shocks and results run against each portfolio, including "
                    "climate scenarios. Risk escalates breaches of appetite from it, portfolio managers and trading "
                    "see headroom, and fund boards receive the exceedance record.",
         objects=[("31", "Risk Limit"), ("31", "Risk Limit Utilization"), ("31", "Risk Limit Exceedance"),
                  ("31", "Stress Scenario"), ("31", "Stress Scenario Shock"), ("31", "Stress Test Result"),
                  ("31", "Portfolio Risk Measure"), ("31", "Counterparty Exposure")],
         upstream=["DP-146", "DP-153", "DP-140", EMP],
         notes="CD-223: risk-program limits and their exceedances (RLEX-) are 31 and published here; coded "
               "restrictions and breaches are 33 (DP-163); 'breach' is never used for an RLEX-. CD-215: utilization "
               "of 25 counterparty trading limits is a 31 row published here. CD-244: an exceedance is not an "
               "operational incident unless it causes a loss. Climate scenarios read 34 portfolio sustainability "
               "metrics from the Investment brief's ESG product (CD-216)."),

    dict(id="DP-155", name="Fund Liquidity & Derivatives Risk Programs", tier="Consumer-aligned",
         type="Regulatory & Control", domain="31", owner_role="Liquidity Risk Management Program Administrator",
         primary="FN-30", supporting=["FN-36", "FN-21", "FN-33", "FN-37", "FN-32"], wave="E2",
         definition="The fund-level results of the liquidity and derivatives risk programs: Rule 22e-4 liquidity "
                    "classifications, HLIM tests and fund liquidity profiles, liquidity stress tests and horizon "
                    "buckets, Rule 18f-4 reference portfolios and VaR tests, UCITS global exposure and AIFMD leverage, "
                    "with the program designations and exceedances. Program administrators and the derivatives risk "
                    "manager act on it, and N-PORT, N-RN, N-CEN, Form PF and Annex IV take their values from it.",
         objects=[("31", "Risk Program Designation"), ("31", "Liquidity Classification"),
                  ("31", "Highly Liquid Investment Minimum"), ("31", "Fund Liquidity Profile"),
                  ("31", "Liquidity Horizon Bucket"), ("31", "Stress Test Result"), ("31", "Liquidity Stress Detail"),
                  ("31", "Designated Reference Portfolio"), ("31", "VaR Test Result"),
                  ("31", "Leverage & Exposure Measurement"), ("31", "Risk Limit Exceedance")],
         upstream=["DP-146", "DP-154", "DP-142", "DP-140", "DP-143", "DP-004", NAV],
         notes="CD-213, CD-214. Certified per CD-293 / CD-320: the liquidity classification family (percent of net "
               "assets by liquidity category, HLIM shortfall, illiquid percent) is published only here. Fund-keyed "
               "results are measured on the fund's whole 18 book through DP-140 (CD-324). 35 files from this product "
               "and holds board approvals (CD-225, CD-234, CD-237). Rule 2a-7 liquid asset minimums are 33 rules, "
               "not here."),

    dict(id="DP-156", name="Product Risk Indicators & PRIIPs Scenarios", tier="Consumer-aligned",
         type="Regulatory & Control", domain="31", owner_role="Head of Investment Risk", primary="FN-30",
         supporting=["FN-10", "FN-18", "FN-37", "FN-36"], wave="E2",
         definition="The PRIIPs summary risk indicator, UCITS SRRI and PRIIPs performance scenarios calculated for each "
                    "share class, with their market and credit risk classes, return history basis and approval. "
                    "Product documents, the FinDatEx feed and product governance take the disclosed indicator from "
                    "this calculation instead of keying it.",
         objects=[("31", "Product Risk Indicator Calculation"), ("31", "PRIIPs Performance Scenario"),
                  ("32", "Performance Return")],
         upstream=["DP-145", "DP-004"],
         notes="CD-212: the 01 SRI and SRRI are derived copies of this calculation; DP-064 re-points to this product "
               "(CD-323). The SRRI ex-post volatility reads 32 returns from DP-145. UK Consumer Composite Investments "
               "regime may change the indicator (31 SME question 8). If a vendor calculates the indicators, the grain "
               "is unchanged and the approval status evidences the firm's sign-off."),

    dict(id="DP-157", name="Performance Attribution & Ex-Post Analytics", tier="Consumer-aligned", type="Analytical",
         domain="32", owner_role="Head of Performance Measurement", primary="FN-31",
         supporting=["FN-21", "FN-20", "FN-14", "FN-30", "FN-05"], wave="E2",
         definition="Why each portfolio beat or trailed its benchmark: attribution results and effects by segment "
                    "under the approved attribution model, contribution to return by instrument and segment, and "
                    "ex-post risk statistics (realized tracking error, information ratio, Sharpe, beta, drawdown). "
                    "Portfolio managers, the CIO and client reporting use it to explain results with one methodology.",
         objects=[("32", "Attribution Model"), ("32", "Attribution Result"), ("32", "Attribution Segment Result"),
                  ("32", "Attribution Effect"), ("32", "Contribution to Return"), ("32", "Ex-Post Risk Statistic"),
                  ("32", "Performance Return"), ("32", "Benchmark Return")],
         upstream=["DP-145", "DP-146", "DP-142", "DP-144", "DP-013", SEC],
         notes="CD-211: ex-post statistics here, ex-ante in DP-146; names say 'Ex-Post'. Attribution and contribution "
               "reference return versions in DP-145 and never restate the return. Attribution models reference the 37 "
               "model inventory (CD-246, CD-294). Reference target allocations (24) come from the Investment brief's "
               "portfolio targets product."),

    dict(id="DP-158", name="GIPS Composites & Verification", tier="Consumer-aligned", type="Regulatory & Control",
         domain="32", owner_role="Head of Performance Measurement", primary="FN-31",
         supporting=["FN-05", "FN-06", "FN-13", "FN-14", "FN-01"], wave="E2",
         definition="The firm's GIPS compliance record: the GIPS firm and its assets, composite membership by "
                    "portfolio with inclusion and exclusion dates, significant cash flow removals, carve-outs, "
                    "composite statistics (assets, dispersion, 3-year standard deviation) and verification "
                    "engagements. It answers whether every fee-paying discretionary portfolio is in the right "
                    "composite and supplies the statistics GIPS reports, RFPs and marketing must show.",
         objects=[("32", "GIPS Firm"), ("32", "GIPS Firm Assets"), ("32", "Composite Membership"),
                  ("32", "Composite Period Statistic"), ("32", "Significant Cash Flow Event"),
                  ("32", "Carve-Out Allocation"), ("32", "GIPS Verification"), ("32", "Performance Return")],
         upstream=["DP-145", "DP-140", "DP-141", "DP-004", EMP],
         notes="CD-218. CD-320: GIPS Total Firm Assets and Composite Assets are GIPS-defined figures; they are never "
               "published as AUM and the Wave E5 Firm AUM Reconciliation explains their difference from Firm AUM "
               "(CD-292). The composite definition stays in 01 and reaches this product through DP-004 (CD-322). "
               "DP-062, DP-068 and DP-023 read composite statistics from here."),

    dict(id="DP-159", name="Investment Performance Scorecard", tier="Consumer-aligned", type="Analytical",
         domain="32", owner_role="Head of Performance Measurement", primary="FN-31",
         supporting=["FN-01", "FN-16", "FN-10", "FN-21", "FN-37", "FN-05"], wave="E2",
         definition="One firm view of investment results by strategy, fund, share class and composite: official "
                    "returns against benchmark and peer median over standard periods, ex-post and ex-ante risk, and "
                    "the asset-weighted share of assets ahead of benchmark. Investment, distribution and product "
                    "leadership read the same numbers instead of rebuilding them from vendor data.",
         objects=[("32", "Performance Return"), ("32", "Benchmark Return"), ("32", "Ex-Post Risk Statistic"),
                  ("32", "Composite Period Statistic"), ("32", "Performance Measurement Profile"),
                  ("31", "Portfolio Risk Measure")],
         upstream=["DP-145", "DP-157", "DP-146", "DP-158", "DP-014", "DP-004", NAV],
         notes="Own returns only from DP-145; peer returns stay 11 'Published Peer Return' read through DP-014 "
               "(CD-217). Asset weights use the certified Firm AUM from NAV & Fund Financials (CD-292), not DP-008 "
               "attributed AUM and not DP-142 portfolio market value. Serves the FN-37 product reviews and value "
               "assessments (36) as an input; it holds no review outcome."),

    dict(id="DP-160", name="Private Markets Investor Performance & PME", tier="Consumer-aligned", type="Analytical",
         domain="32", owner_role="Head of Performance Measurement", primary="FN-31",
         supporting=["FN-26", "FN-25", "FN-14", "FN-36"], wave="E3",
         definition="Investor-level net IRR and multiples for each private fund commitment, and public market "
                    "equivalents for private funds and investments, alongside the certified fund and investment "
                    "measures. Investor relations and ILPA reporting take investor performance from it, and deal "
                    "teams compare private results with the public market.",
         objects=[("32", "Investor Performance Measure"), ("32", "Public Market Equivalent"),
                  ("32", "Private Markets Performance Measure")],
         upstream=["DP-145", "DP-144", "DP-093", ICA],
         notes="CD-219; CD-203 (commitments on a 15 account). Fund and investment IRR and multiples are certified in "
               "DP-145 and only read here. Investor measures are personal data where the investor is an individual. "
               "Wave E3 with the private markets products (ILPA reporting) of the other briefs. If the fund "
               "administrator calculates the measures (Measure Source), they are held as received and approved."),

    dict(id="DP-161", name="Guideline Coding & Rule Library", tier="Consumer-aligned", type="Regulatory & Control",
         domain="33", owner_role="Head of Investment Compliance", primary="FN-32",
         supporting=["FN-14", "FN-37", "FN-36", "FN-44", "FN-24"], wave="E2",
         definition="The coded rule base and its coverage: statutory limit provisions, rule libraries, versioned "
                    "compliance rules with their sources and assignments to portfolios, rule instrument lists, coding "
                    "requests, the coding status of every prospectus and client restriction and the periodic rule "
                    "reviews. Investment compliance uses it to show that every restriction is coded or monitored "
                    "manually, and to answer which rule version applied to a portfolio on a date.",
         objects=[("33", "Regulatory Limit Provision"), ("33", "Rule Library"), ("33", "Rule Library Membership"),
                  ("33", "Compliance Rule"), ("33", "Rule Source Link"), ("33", "Rule Assignment"),
                  ("33", "Rule Instrument List"), ("33", "Rule Instrument List Member"),
                  ("33", "Rule Coding Request"), ("33", "Restriction Coding Status"), ("33", "Periodic Rule Review"),
                  ("01", "Investment Restriction"), ("02", "Client Restriction")],
         upstream=["DP-140", "DP-004", "DP-077", SEC, ISS, EMP],
         notes="CD-221: the restriction stays in 01 or 02; the rule is 33. CD-224: lists sourced from 34 exclusion "
               "lists and the 38 restricted list are read at source and their members are not stored. Candidate "
               "for promotion to foundational at review if 25 or 35 products need the rule master directly. 01 "
               "Investment Restriction is read directly because no foundational product publishes it."),

    dict(id="DP-162", name="Compliance Monitoring, Alerts & Overrides", tier="Consumer-aligned", type="Operational",
         domain="33", owner_role="Head of Investment Compliance", primary="FN-32",
         supporting=["FN-23", "FN-21", "FN-22", "FN-25", "FN-44"], wave="E2",
         definition="Every pre-trade, intraday and post-trade compliance run with its rule results, the alerts raised, "
                    "their dispositions and pre-trade overrides, guideline waivers in force and manual checks of "
                    "restrictions the engine cannot test. Compliance analysts work the alert queue from it, and "
                    "trading and portfolio management see why an order was blocked or released.",
         objects=[("33", "Compliance Check Run"), ("33", "Pre-Trade Check Subject"), ("33", "Check Subject Member"),
                  ("33", "Compliance Rule Result"), ("33", "Compliance Alert"), ("33", "Alert Disposition"),
                  ("33", "Pre-Trade Override Approval"), ("33", "Guideline Waiver"),
                  ("33", "Manual Compliance Check"), ("33", "Compliance Rule")],
         upstream=["DP-161", "DP-140", "DP-142", "DP-146", "DP-153", SEC, ISS],
         notes="CD-180 / CD-221: 25 copies the per-order outcome from Check Subject Member; trade orders come from the "
               "Investment brief's order and execution product (25). Rules that read 31 measures name them; values "
               "come from DP-146 and DP-153 (CD-223). Evidential period-end runs support RIC and 817(h) tests (27, "
               "35)."),

    dict(id="DP-163", name="Investment Breaches & Remediation", tier="Consumer-aligned", type="Regulatory & Control",
         domain="33", owner_role="Head of Investment Compliance", primary="FN-32",
         supporting=["FN-14", "FN-36", "FN-42", "FN-44", "FN-21", "FN-33"], wave="E2",
         definition="Every breach of a coded investment rule from detection to cure: source restrictions, cause, "
                    "severity and materiality, remediation actions, loss calculations and the CCO's review with "
                    "board, depositary and regulator escalation decisions. Compliance manages cure deadlines from it, "
                    "client service notifies clients, and boards and risk see breach trends by cause.",
         objects=[("33", "Investment Breach"), ("33", "Breached Source Restriction"),
                  ("33", "Breach Remediation Action"), ("33", "Breach Loss Calculation"), ("33", "Breach Review"),
                  ("33", "Compliance Rule"), ("33", "Guideline Waiver")],
         upstream=["DP-161", "DP-162", "DP-140", EMP],
         notes="CD-222: breaches are 33; 12 Breach Notification (client notification, DP-042) and 35 Reportable Fund "
               "Event (regulator notification) reference them. CD-244: one loss, one home (25 Trade Error, 27 NAV "
               "Error Case or Breach Loss Calculation); 37 reads it. DP-042 re-points its breach facts here "
               "(CD-323). CD-223: risk exceedances are DP-154."),
]

DECISIONS = [
    {"id": "CD-320", "theme": "Transactions & Measures",
     "title": "Investment certified numbers: the one product that publishes each, and the investment values that are never AUM",
     "domains": ["18", "31", "32", "27", "06"],
     "issue": "CD-293 names the certified families and the semantic model that owns each, and CD-292 names the three "
              "AUM-like numbers, but neither says which data product publishes each certified investment number. "
              "Several Investment Operations candidates could compute the same figure: returns in Official Returns, "
              "the scorecard and GIPS; liquidity percentages in Risk Measures and the program product; portfolio "
              "market value in holdings, the IBOR control product and GIPS firm assets.",
     "resolution": "Proposed: official returns, benchmark returns and private fund and investment IRR and multiples "
                   "are published only by DP-145 Official Returns (Final and Restated rows certified); ex-ante VaR and "
                   "tracking error only by DP-146 Risk Measures from approved runs; the Rule 22e-4 liquidity "
                   "classification family only by DP-155. Every other product reads them from those products. DP-142 "
                   "publishes 'Portfolio Market Value (IBOR)', which is not certified and is never labeled AUM; DP-158 "
                   "publishes GIPS Total Firm Assets and Composite Assets as GIPS figures, never as AUM. Both are "
                   "inputs to the Wave E5 Firm AUM Reconciliation. Portfolio Capital Activity (DP-141) is never "
                   "re-labeled as net flows, which stay DP-008.",
     "rationale": "CD-292, CD-293, CD-217; Data_Products_Approach §7: a certified number is defined once and taken from "
                  "its owner.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High",
     "owner_role": "Head of Performance Measurement"},

    {"id": "CD-321", "theme": "Enterprise Structure",
     "title": "Dependency direction between the investment foundational products: prices before NAV, agreements before the broker master",
     "domains": ["22", "27", "26", "25", "18"],
     "issue": "Foundational products may depend only on foundational products and the graph may have no cycles. "
              "Two pairs are mutual in the taxonomy: 22 Approved Price copies the 27 NAV on own fund share class rows "
              "while 27 applies 22 prices (CD-167, CD-187); 25 Governing Trading Agreement references 26 TAGR- while "
              "26 agreements name 02 counterparties that 25 approves (CD-179, CD-182).",
     "resolution": "Proposed: NAV & Fund Financials (27) depends on DP-143 Prices, FX & Curves; DP-143 publishes own "
                   "fund rows as the 22 record holds them and never lists the NAV product upstream. The Approved "
                   "Broker & Counterparty Master (25) depends on DP-147 Trading Agreements & Settlement Instructions "
                   "for agreement status; DP-147 takes counterparty identity as the 02 party key and does not list the "
                   "25 product upstream. DP-142 Holdings depends on DP-141 Transactions, not the reverse. Products "
                   "that need both sides (Official Returns, Risk Measures, collateral) list both.",
     "rationale": "framework rule: foundational products depend only on foundational products, without cycles; the "
                  "direction follows who masters the value (CD-167, CD-182).",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Chief Data Officer"},

    {"id": "CD-322", "theme": "Product",
     "title": "DP-004 extended with 01 Benchmark, Product Benchmark Assignment, GIPS Composite and Investment Mandate",
     "domains": ["01", "18", "22", "31", "32", "33"],
     "issue": "DP-004 Product & Share Class Distribution Reference is the only foundational product for 01, but it "
              "does not read 01 Benchmark, Product Benchmark Assignment, GIPS Composite or Investment Mandate. Index "
              "data, benchmark returns, tracking error, composite membership and portfolio implementation links all "
              "key on these, and today only consumer products (DP-062, DP-072, DP-086) read them.",
     "resolution": "Proposed for Wave E1: DP-004 adds the four objects as inputs, so the benchmark, composite and "
                   "mandate dimensions are conformed once and DP-140, DP-144, DP-145, DP-146 and DP-158 take them from "
                   "DP-004. DP-004 keeps its name, owner and grain; this is a lineage extension recorded under "
                   "CD-299, not a new product.",
     "rationale": "Reuse an existing foundational product rather than create a second 01 master product (Approach §3).",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Head of Product Data"},

    {"id": "CD-323", "theme": "Enterprise Structure",
     "title": "Distribution products that read copies of 26, 31, 32 and 33 values re-point to the investment products in Wave E2",
     "domains": ["01", "12", "26", "31", "32", "33", "11"],
     "issue": "Contract rule 2 says take a concept from its mastering domain. Several of the 96 products read "
              "Derived copies whose master now has a product: DP-064 reads 01 SRI and SRRI (copies of 31, CD-212); "
              "DP-042 reads 12 Breach Notification fields that copy 33 (CD-222); DP-062 and DP-068 show performance "
              "with no return source; DP-030 compares peers using vendor-reported own fund returns (11); DP-086 reads "
              "26 SSIs directly.",
     "resolution": "Proposed, applied in Wave E2 by lineage only: DP-064 adds DP-156 upstream and takes SRI, SRRI and "
                   "PRIIPs scenarios from 31; DP-042 adds DP-163 upstream for breach facts; DP-062 and DP-068 add "
                   "DP-145 (and DP-158 for composite statistics) upstream; DP-030 takes own share class returns from "
                   "DP-145 while peer returns stay 11 'Published Peer Return'; DP-086 adds DP-147 upstream for SSIs. "
                   "No grain, measure name or owner changes.",
     "rationale": "Expansion plan §3: existing products change only by a logged decision that re-points them to an "
                  "enterprise product.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Data Officer"},

    {"id": "CD-324", "theme": "Enterprise Structure",
     "title": "Portfolio-to-fund, mandate and account resolution only through DP-140 Portfolio Master & Mandate Link",
     "domains": ["18", "01", "15", "31", "32", "33", "27"],
     "issue": "31 fund-keyed program results are measured on the fund's whole 18 book, 32 returns and 33 rule "
              "assignments are by portfolio, 27 NAV is by fund and 06 AUM by share class. Each consumer could build "
              "its own portfolio-to-fund mapping, and the Firm AUM reconciliation would then compare numbers on "
              "different mappings.",
     "resolution": "Proposed: the only portfolio-to-product, mandate, account and model mapping in the catalog is 18 "
                   "Portfolio Implementation Link and Portfolio Hierarchy Link as published by DP-140, as of the date "
                   "being measured. Every product that rolls portfolio values to a fund, share class, mandate or "
                   "account lists DP-140 upstream and uses its effective-dated links; none carries its own mapping.",
     "rationale": "CD-145 (portfolio separate from product, joined by the implementation link) applied to products.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium",
     "owner_role": "Head of Investment Operations"},
]
