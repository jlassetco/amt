"""Wave E0 integration proposals of the program lead (Data_Products_Expansion_Plan.md §7, E0): the cross-brief products
and decisions the six area briefs asked for. Merged with the area proposals when the briefs are accepted.

Briefs accepted 2026-10-08: DECISIONS below are merged into decisions.py (kept here as the record of the proposal);
CANDIDATES remain the input to Waves E1 to E4 (read by data_products/candidate_coverage.py).
"""

CANDIDATES = [
    dict(id="DP-240", name="Enterprise Party & Role Master", tier="Foundational", type="Master & Reference",
         domain="02", owner_role="Head of Enterprise Data Management", primary="FN-49",
         supporting=["FN-08", "FN-23", "FN-29", "FN-34", "FN-44", "FN-45", "FN-46", "FN-47"], wave="E1",
         definition=("The one conformed record of every external organization and individual the firm deals with, in any "
                     "role: the 02 Party identity, its organization or individual profile, legal entity hierarchy, "
                     "identifiers (LEI, regulatory, market infrastructure and vendor identifiers), roles and effective "
                     "periods, and party-to-party relationships and beneficial ownership. Distribution's DP-001, DP-002 "
                     "and DP-003 keep their role-specific profiles and take the party identity from here; the broker and "
                     "counterparty, issuer, vendor, contract, custodian, outside counsel, journalist and official records "
                     "of the enterprise products key on it (CD-143, CD-360)."),
         objects=[("02", "Party"), ("02", "Organization"), ("02", "Legal Entity Hierarchy"), ("02", "Individual"),
                  ("02", "Party Role"), ("02", "Party Identifier"), ("02", "LEI Record"), ("02", "US Regulatory Identifier"),
                  ("02", "UK & EU Regulatory Identifier"), ("02", "Market Infrastructure & Vendor Identifier"),
                  ("02", "Party Relationship"), ("02", "Beneficial Ownership")],
         upstream=["DP-013"],
         notes=("Raised by the Investment, Investment Operations and Corporate B briefs: no product conformed 02 Party for "
                "counterparties, CCPs, trade repositories, pricing vendors, suppliers, outside counsel, journalists and "
                "officials, so DP-115 and DP-210 read 02 directly. Ownership of the party identity moves to enterprise "
                "data management per role (CD-143); the client data organization keeps the client and advisor profiles. "
                "Open: whether DP-001 and DP-002 are re-pointed to this product by lineage in Wave E1 or left as they are "
                "until Phase 2.")),
]

DECISIONS = [
    {"id": "CD-360", "theme": "Party & Account", "title": "An enterprise party master (DP-240) conforms 02 Party for every role; DP-115 and DP-210 key on it",
     "domains": ["02", "25", "40", "39", "17"],
     "issue": "Three Wave E0 briefs found the same gap: DP-001 to DP-003 conform parties only in distribution roles, so the broker and counterparty master (DP-115), the vendor master (DP-210) and the contract register (DP-213) would each read 02 Party directly, and banks that are both issuers and counterparties would have two party records (DP-098 and DP-115).",
     "resolution": "Proposed: DP-240 Enterprise Party & Role Master (owned by 02, owner role Head of Enterprise Data Management, primary function FN-49) conforms the party identity, identifiers, roles and relationships once; DP-115, DP-210 and DP-213 list it upstream; DP-098 keeps the issuer profile and takes the party identity from DP-240. DP-001, DP-002 and DP-003 keep their role profiles and are re-pointed by lineage when their owners agree.",
     "rationale": "CD-143 extended PTY- to every external party with ownership per role; the product layer needs the same single identity or every area rebuilds its own party dimension (CD-296).",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Head of Enterprise Data Management"},
    {"id": "CD-361", "theme": "Enterprise Structure", "title": "Wave E0 cross-brief resolutions: ledger facts from DP-191, third-party oversight boundary, basket source, returns inputs",
     "domains": ["19", "28", "40", "24", "29", "30", "32", "21", "41"],
     "issue": "The six briefs were drafted in parallel and named each other's Wave E1 candidates in words. Four corrections were flagged between them at hand-back.",
     "resolution": "Applied at E0 integration (2026-10-08) in the proposals files: (1) products that need postings rather than the chart (DP-122, DP-215, DP-221, DP-229, DP-234) take DP-191 General Ledger Journals & Balances upstream, not DP-190; (2) DP-176 Fund Service Provider Oversight (28) keeps the fund-level service results and reads engagement, tier, risk and contract from DP-219 Third-Party Oversight (40), so neither duplicates the other (CD-333, CD-355); (3) DP-179 ETF Creation & Redemption Operations takes the basket from DP-131 instead of reading 24 ETF Basket directly; (4) DP-145 Official Returns adds DP-117 Private Fund Capital Calls & Distributions upstream for IRR; (5) DP-101 depends on DP-211 Application & System Inventory, never the reverse. Every named upstream was resolved to its DP- id; 'Issuer Hierarchy & Classifications' resolves to DP-098 Issuer Hierarchy, Classifications & Ratings.",
     "rationale": "One owner per fact and no dependency cycles (data_products/CONTRACT.md).",
     "action": "Retain - clarify", "status": "Applied", "priority": "Medium", "owner_role": "Chief Data Officer"},
    {"id": "CD-362", "theme": "Enterprise Structure", "title": "Wave E0 result: 134 candidate products (27 foundational) against the plan's estimate of about 110; ID blocks and Wave E5",
     "domains": ["17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44"],
     "issue": "Plan §5.2 estimated about 110 new products, 18 to 20 foundational. The briefs, applying the coverage rule to every object with CDEs, produced 134 candidates, 27 of them foundational, with every object with CDEs in Data Domains 17-44 read by at least one candidate except 29 Shareholder Information Request, which CD-336 gives to the existing DP-084.",
     "resolution": "Proposed: accept the candidate list as the Phase 1 scope, subject to the client's review at the end of Phase 1 (plan §9 item 8). The extra foundational products are masters other foundational products key on (journals, corporate action events, fund ledger, custody network, trading agreements, model inventory, contract register, capital calls, the enterprise party master) and are kept. ID blocks as used: DP-097 to DP-114 Foundations and product range; DP-115 to DP-139 Investment; DP-140 to DP-164 Investment Operations; DP-165 to DP-189 Fund Operations; DP-190 to DP-209 Corporate finance and people; DP-210 to DP-239 Corporate risk, compliance, legal and technology; DP-240 the enterprise party master; DP-241 to DP-249 Wave E5 (amends CD-299).",
     "rationale": "The coverage rule, not the estimate, is the acceptance test (plan §9 item 2).",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Data Officer"},
]
