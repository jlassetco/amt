"""Decision proposals for the enterprise expansion, Stage 1 (Data Domains 17-21).

Format: identical to decisions.py (see CONTRACT.md in this folder). This file is a proposal fragment: the builder does not
read it, and nothing here changes a content module. The stage consolidation step (Enterprise_Expansion_Plan.md §9.3 step 5)
merges accepted entries into decisions.py.

Sources: Enterprise_Expansion_Plan.md v0.3 §3, §4 (the eight structural decisions) and §9; Domain_Ownership_and_Conventions.md
§3, §6, §8, §9, §11, §12; the Stage 1 briefs in 00_Program/Expansion/Briefs/; a scan of the 16 content modules on 2026-10-06.

IDs continue after the highest CD- in use (CD-142). Every entry has status "Proposed"; where the business must choose,
action is "SME decision" and the resolution gives the recommended option.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. DECISIONS
# ---------------------------------------------------------------------------------------------------------------------

DECISIONS = [
    # ===================================== Plan §4: structural decisions =====================================
    {"id": "CD-143", "theme": "Enterprise Structure", "title": "Party master scope: 02 PTY- covers every external party, with stewardship set per role",
     "domains": ["02", "17", "18", "19", "20", "25", "26", "28", "29", "30", "40"],
     "issue": "The expansion brings new kinds of external party: issuers, guarantors, rating agencies, brokers, counterparties, custodians and sub-custodians, fund administrators, suppliers, authorized participants, GPs of underlying funds and portfolio companies. 02 Party Role Type today lists only distribution roles (distributor firm, advisor, institutional client, consultant, plan, recordkeeper, custodian, clearing firm, fund service provider). Without a rule, each new domain would build its own counterparty, issuer or supplier master (plan §4 item 1).",
     "resolution": "Extend 02 so that PTY- is the one key for every external organization and individual the firm deals with. The party core (name, legal form, LEI, legal parents, NAICS/NACE, contact points) stays in 02. Each new domain masters a role profile keyed by PTY- for the facts only it maintains (17 Issuer Profile, 25 approved broker and counterparty, 40 supplier, 30 portfolio company) and is the steward of that role, following the reasoning that split Account (15) out of 02. New Party Role Type values are proposed by the domains in their proposals_NN.py files. Exceptions: own employees and job candidates are not 02 parties (20 Human Capital; an employee who is also a client keeps a PTY- for the client role, linked by cross-reference as in CD-001); own legal entities stay 09 LEN- with a PTY- mirror (CD-010).",
     "rationale": "One external party key avoids reconciling issuer, counterparty and supplier masters later; per-role stewardship matches how the data is actually produced (security master team, trading, procurement).",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Head of Enterprise Data Management"},

    {"id": "CD-144", "theme": "Enterprise Structure", "title": "Shared-concept pattern: the enterprise domain masters the generic record, the distribution domain keeps a profile keyed to it",
     "domains": ["03", "04", "05", "10", "14", "19", "20", "39", "40", "42"],
     "issue": "Several concepts modeled in distribution domains are enterprise concepts: employees (03, now 09), the ledger (10), vendors and data invoices (14), contracts (05, 14) and the corporate brand (04). Plan §4 item 2.",
     "resolution": "The enterprise domain masters the generic record and its key; the distribution domain keeps a profile or specialization keyed to it, holding only the facts it produces. Applied pairs: 20 Employee (EMP-) / 03 Sales Person; 19 GL Account, Ledger, GL Posting / 10 Account Mapping and distribution finance records; 19 Payable Invoice / 14 Data Invoice and 05 Partner Invoice (CD-158); later 40 supplier / 14 Data Vendor; 39 contract / 05 AGR- and 14 DLA-; 42 corporate brand / 04 BRD-. The profile never copies identity attributes of the master; where a copy is needed for performance it is flagged Derived copy.",
     "rationale": "Already proven with EMP- and the Sales Person profile (CD-120); keeps the 01-16 domains intact while giving the enterprise one master per concept.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Head of Enterprise Data Management"},

    {"id": "CD-145", "theme": "Enterprise Structure", "title": "Portfolio (18 PORT-) is a separate concept from product, mandate and model (01), joined by a Portfolio Implementation Link",
     "domains": ["01", "15", "18", "05", "24", "30"],
     "issue": "01 masters products (PRD-), share classes (SHC-), mandates (MND-) and model portfolios (MDL-) but no portfolio; the managed book of instruments has no master. SMA sleeves, master-feeder structures and private fund portfolios test where one ends and the other starts (plan §4 item 3).",
     "resolution": "A product is what the firm sells and the client owns; a Portfolio (18, PORT-) is the book of instruments the firm manages to deliver it. They are joined by an effective-dated Portfolio Implementation Link (portfolio x implemented object x link type) with link types Implements Product (fund, ETF, CIT, insurance-dedicated fund, private fund), Implements Mandate (01 MND-), Manages Account (SMA account, 15 ACC-) and Follows Model (01 MDL-). A feeder fund is a product linked to its master's portfolio. A model portfolio is never a Portfolio; model-delivery-only programs have no portfolio. Sleeves are child portfolios via Portfolio Hierarchy Link. Portfolio manager assignment and targets are 24.",
     "rationale": "Keeps product reference data (01) stable while the IBOR models what is actually run; one link object covers all six business lines.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Head of Investment Operations"},

    {"id": "CD-146", "theme": "Enterprise Structure", "title": "Two kinds of position: Shareholder Position (06 POS-) and Portfolio Holding (18 HLD-); Investor Capital Account (30) is a third",
     "domains": ["06", "18", "30", "12", "15"],
     "issue": "06 Position (POS-) is units of the firm's share classes held by an account. The IBOR needs holdings of instruments by portfolio. Private fund investors' capital accounts are a third concept. Bare 'Position' would collide (plan §4 item 4).",
     "resolution": "Glossary terms: 'Shareholder Position' = 06 Position (POS-), account x share class x valuation date; 'Portfolio Holding' = 18 Portfolio Holding (HLD-), portfolio x instrument x holding date x holding view; 'Investor Capital Account' = 30 (Stage 2), investor x private fund. New domains never use 'Position' bare (20 uses 'Workforce Position'). When an own portfolio holds an own fund, the same units are a Portfolio Holding of an own-share-class instrument (17) and a Shareholder Position on the portfolio's account (06); both are kept and the glossary explains the link. 06 object names do not change; the qualified terms are added to TERM_CONFLICTS at consolidation.",
     "rationale": "Distinct names and prefixes prevent AUM, holdings reporting and flow measures from being joined on the wrong concept.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Head of Investment Operations"},

    {"id": "CD-147", "theme": "Enterprise Structure", "title": "Operating model recorded per function and business line (in house or outsourced)",
     "domains": ["18", "26", "27", "28", "29", "30"],
     "issue": "Fund accounting, custody, middle office, transfer agency and private fund administration may be outsourced, which changes the grain of the data the firm holds from operational records to oversight data received from a provider (plan §4 item 5, §7 item 2).",
     "resolution": "Recommended: every domain is modeled whether the function is in house or outsourced. Each affected master carries an operating-model attribute (e.g. 18 Portfolio 'IBOR Operating Model', 'Book of Record System'), and an operating model register (function x business line x in house / outsourced x provider PTY-) is kept beside the capability map. Where a function is outsourced, the domain models the records received from the provider and the oversight data (SLAs, breaks, errors) rather than the provider's internal process.",
     "rationale": "The client has not yet said which functions are outsourced; one model with an operating-model flag avoids redrafting when the answer comes.",
     "action": "SME decision", "status": "Proposed", "priority": "High", "owner_role": "COO"},

    {"id": "CD-148", "theme": "Enterprise Structure", "title": "Record-level governance metadata modeled once in 21 and attached to every object by reference",
     "domains": ["21", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16"],
     "issue": "Each of the 16 domains defines its own 'Record Metadata' object (16 objects, 135 attributes: data owner, data steward, system of record, record effective dates, last updated, data quality status, classifications, retention class, source identifiers). They were excluded from all outputs on 2026-10-01 (exclusions.py, conventions §11). CD-006 had proposed a pattern in 09 (plan §4 item 6).",
     "resolution": "21 Data Governance & Analytics models this metadata once: Object Governance Profile (one per L3 object: owner, steward, system of record, retention class referencing 08 RET-, default classification) and Record Governance Metadata (the record-level pattern, harmonized from the union of the excluded attributes). Domains attach it by reference and do not restore their own blocks; the 16 excluded objects remain in the content modules and remain excluded. The 21 objects must not be named 'Record Metadata', because exclusions.py excludes by that name. Supersedes CD-006. Stewardship of the shared list Data Quality Status moves from 09 to 21; stewardship of Information Classification is an SME question (21 or 41).",
     "rationale": "Removes 16 near-duplicate blocks and puts governance metadata under the office that produces it.",
     "action": "Move", "status": "Proposed", "priority": "High", "owner_role": "Chief Data Officer"},

    {"id": "CD-149", "theme": "Enterprise Structure", "title": "Tax: one Tax domain, or tax data split by producing domain",
     "domains": ["19", "27", "35", "13", "28", "30", "02", "15", "16"],
     "issue": "Tax data is produced in 19 (corporate tax), 27 and 35 (fund tax and RIC qualification), 13 (investor tax documents), 28 (withholding tax reclaims), 30 (K-1s and partnership tax), 02 (party FATCA/CRS classification), 15 (account tax certification) and 16 (1099-R detail). Tax is one function with one owner at most firms (plan §4 item 7).",
     "resolution": "Recommended for Stage 1: keep the split by producer and draft corporate tax as a family of 19 (Entity Tax Registration, Tax Return TAXR-, Tax Provision, Transfer Pricing Documentation). Ask the client whether to create a single Tax domain that masters tax positions and filings and references the rest; if so, the 19 Corporate Tax family and the TAXR- prefix move to it unchanged.",
     "rationale": "Mirrors where tax data is produced today without blocking Stage 1; the move is cheap if the family is kept self-contained.",
     "action": "SME decision", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Tax"},

    {"id": "CD-150", "theme": "Enterprise Structure", "title": "Rename the enterprise workbook and program documents to the enterprise scope, keeping a distribution view",
     "domains": ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16"],
     "issue": "00_Program/Enterprise_Distribution_Data_Taxonomy.xlsx, the explorer and the program documents are named for distribution (plan §4 item 8, §8.2).",
     "resolution": "Rename to Enterprise_Data_Taxonomy.xlsx at the end of Stage 1 and add the Area column (plan §8.2); keep a distribution view (Area = Distribution & Client plus Foundations) so the v0.4 deliverables can still be produced. Update builder output paths, README and the conventions document in the same change, and keep the old file name as a redirect note for one release.",
     "rationale": "One taxonomy with many views (plan §8); renaming once, after Stage 1 merges, avoids breaking links mid-stage.",
     "action": "Rename", "status": "Proposed", "priority": "Low", "owner_role": "Program Lead"},

    # ===================================== Stage 1 moves =====================================
    {"id": "CD-151", "theme": "Workforce", "title": "Employee master (EMP-) moves from 09 Workforce to 20 Human Capital",
     "domains": ["09", "20", "01", "02", "03", "04", "05", "06", "07", "08", "10", "12", "14", "15", "16"],
     "issue": "CD-120 moved the employee master from 03 to a Workforce family in 09 because no HR domain existed. 20 Human Capital now masters the HR record (jobs, positions, employment events, reward, talent, learning), and 09 should return to reference data.",
     "resolution": "Move to 20 unchanged (object and attribute names kept): 09 Workforce 'Employee' (16 attributes) and 'Employee Reporting Line' (5), 09 Internal Organization 'Org Unit Assignment' (3), and the code lists Employment Type, Employment Status and Reporting Line Type. EMP- ownership moves 09 -> 20 and all references re-point as under CD-120; CONCEPT_OWNERSHIP 'Employee' owner becomes 20. 09 keeps Org Unit (OU-, including 'Unit Head' as a reference to EMP-), Org Hierarchy Link, Reorganization Event (REORG-), Office Location (SITE-), Internal Legal Entity (LEN-) and Cost & Profit Center; the empty Workforce family is removed. 03 keeps the Sales Person profile; 07 keeps incentive compensation (ICP-) and sends Payroll Payment Instructions to 20; 08 keeps sales-staff licenses (LIC-) unless the client moves firm-wide registrations to 20 or 38.",
     "rationale": "HR produces and maintains employee data; the move completes CD-120 without changing any employee key.",
     "action": "Move", "status": "Proposed", "priority": "High", "owner_role": "Chief Human Resources Officer"},

    {"id": "CD-152", "theme": "Finance", "title": "Chart of accounts, ledgers, GL postings and period status move from 10 to 19 Finance & Accounting",
     "domains": ["10", "19", "07", "09"],
     "issue": "10 Distribution Finance & Profitability models the chart-of-accounts mapping (Account Mapping, ACM-), GL Posting (JNL-) and Accounting Period Status because no enterprise finance domain existed. CD-030 moved 07's GL Account to 10 and CD-084 gave 10 the cost and profit center codes.",
     "resolution": "19 masters: GL Account (GLA-), Chart Segment Value (including cost and profit center codes, amending CD-084), Ledger (LDG-), Journal Entry (JNL-, ownership moves from 10) and Financial Statement Line Mapping. Moved unchanged from 10: 'GL Posting' (grain becomes journal x line; header attributes Journal Type, Posting Date, Posting Accounting Period and Posting Legal Entity move to Journal Entry with names kept), 'Accounting Period Status' (CD-083's fiscal period status now reads 19), and the Account Mapping attributes External Reporting Line, XBRL Element and Revenue Disaggregation Category. 10 keeps Account Mapping (ACM-) narrowed to Management P&L Line -> GL Account, with GL Natural Account and Applicable Ledger re-typed as references to GLA- and LDG-; it also keeps revenue, waivers, expense accounting, contract costs, allocation, profitability, management hierarchies, budgets (BUD-, which reference the 19 Financial Plan Version they roll into), intercompany agreements and TP policy, and its reconciliation controls. 09 Cost & Profit Center and Internal Legal Entity 'Accounting Company Code' become references to 19. 07 Compensation Accrual references GLA-. The 10 local list 'Ledger' is retired in favor of LDG-.",
     "rationale": "Finance owns the ledger for every entity; 10 keeps the distribution view on top of it (CD-144).",
     "action": "Move", "status": "Proposed", "priority": "High", "owner_role": "Finance Controller"},

    {"id": "CD-153", "theme": "Reference Data", "title": "FX rate time series stay out of 09 and are mastered in 22 Market Data & Pricing",
     "domains": ["09", "22", "19", "10", "06", "07"],
     "issue": "09 deliberately holds currencies, FX rate types and sources but no FX time series; 19 needs translation rates for consolidation and 06, 07 and 10 use rates for AUM, compensation and revenue translation. CD-102 (approved rate type per use) is open.",
     "resolution": "09 keeps Currency, FX Rate Source and FX Rate Type (reference only). FX rate observations (rate type x currency pair x timestamp) are mastered in 22 Market Data & Pricing (Stage 2), licensed through 14 DSET-. Until 22 exists, 19 and other consumers carry the applied rate on their own record as a Derived copy with Notes 'future owner 22'; no Stage 1 domain creates an FX rate object.",
     "rationale": "Rates are market data with their own sourcing, timing and licensing; keeping them out of 09 keeps reference data slow-changing.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Market Data"},

    {"id": "CD-154", "theme": "Product", "title": "Security master mastered in 17 Instrument & Issuer Reference; 01 keeps own share-class identifiers",
     "domains": ["01", "17", "02", "11", "14", "18"],
     "issue": "01 Investment Product excludes the instrument / security master for holdings, yet holds ISIN, CUSIP, SEDOL, FIGI, Valoren, WKN, FISN and listings for own share classes (Security Identifier, External Cross-Reference, Listing). 11 Peer Fund carries ISIN and ticker for peer funds. Own funds can also be held by own portfolios.",
     "resolution": "17 masters the instrument master (INS-), instrument identifiers (IID-), listings of third-party instruments (LST-), issuer profiles keyed by 02 PTY-, classifications, credit ratings and corporate action event reference (CAE-). 01 keeps Security Identifier, External Cross-Reference and Listing as the master for own share classes. When an own share class is held by an own portfolio, 17 creates an instrument of type 'Own Fund Share Class' referencing SHC-, whose identifiers and listings are Derived copies of 01. 11 Peer Fund keeps its identifiers as market-intelligence attributes and may reference INS- where the fund is also held. Instrument sector schemes stay registered in 09 (ICS-); statutory industry codes (NAICS/NACE) stay on the 02 Organization.",
     "rationale": "The security master team produces instrument data for every asset class; the product team produces own share-class data. One owner per fact, with a cross-reference for the overlap.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Head of Investment Operations"},

    {"id": "CD-155", "theme": "Servicing", "title": "Who masters standing settlement instructions: 12 (mandate set-up) or 26 (trade operations)",
     "domains": ["12", "26", "18", "28"],
     "issue": "12 Institutional Client Servicing holds Standing Settlement Instruction (SSI-) captured at mandate set-up, keyed to the mandate and custody account (CUA-). 26 Trade Operations, Settlement & Collateral (Stage 2) will need SSIs for every portfolio, fund and counterparty, including counterparty SSIs received via DTCC ALERT. Plan §3 row 26 flags the decision.",
     "resolution": "Recommended: 26 masters all settlement instructions (own-side SSIs for every portfolio and fund, and counterparty SSIs), keyed by SSI-; 12 keeps the mandate set-up workflow and references the 26 SSI it caused to be created, as 13 references 15 for account changes. The SSI- prefix would move from 12 to 26 with object and attribute names unchanged. Alternative: 12 keeps client-mandate SSIs and 26 masters fund and counterparty SSIs, which leaves two masters of one concept. Decide before Stage 2 drafting.",
     "rationale": "Settlement operations is the function that maintains and verifies SSIs for all portfolios; mandate onboarding is only one source.",
     "action": "SME decision", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Investment Operations"},

    # ===================================== Consequential Stage 1 decisions =====================================
    {"id": "CD-156", "theme": "Identifiers", "title": "06 DQ Rule (DQR-) becomes the first instances of the 21 Data Quality Rule",
     "domains": ["06", "21"],
     "issue": "06 holds a 'DQ Rule' object (DQ Rule ID DQR-, Description, Dimension, Threshold %, Result %) for distribution feeds. 21 masters the enterprise data quality framework (rules, results, issues).",
     "resolution": "Move 06 'DQ Rule' to 21; DQR- ownership moves 06 -> 21 with attribute names kept; 'DQ Result %' moves to 21 Data Quality Result. 06 keeps Reconciliation (RCN-), Reconciliation Run and Break (BRK-), which are business reconciliations of feeds, not quality rules. 14 Vendor Data Issue (VDI-) stays in 14 and may reference a 21 Data Quality Issue (DQI-).",
     "rationale": "One rule catalog for the enterprise; 06 rules were the only quality rules modeled in any domain.",
     "action": "Move", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Data Officer"},

    {"id": "CD-157", "theme": "Code Lists", "title": "Code list registry (CLR-) stays in 09; 21 references it",
     "domains": ["09", "21"],
     "issue": "Plan §3 row 21: '09 keeps the code list registry (CLR-), or hands it to 21'. The registry holds code lists, versions, values, mappings and change requests and is the target of the 46 shared lists (CD-110).",
     "resolution": "Recommended: 09 keeps Code List (CLR-), Code List Version (CLV-), Code Value, Code Mapping (CLM-) and Code List Change Request, because code values are reference data distributed to systems. 21 registers code lists as governed assets by reference (Business Term and Taxonomy Element Registration point to CLR-) and owns the governance roles over them. The 09 'Data Owner' and 'Data Steward' attributes on Code List become references resolved through 21 Data Ownership Assignment at consolidation.",
     "rationale": "Avoids moving a working registry while keeping one place for ownership metadata.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Low", "owner_role": "Chief Data Officer"},

    {"id": "CD-158", "theme": "Finance", "title": "Payables and receivables: 19 holds the generic invoice, payment and receivable; domain records keep their detail",
     "domains": ["19", "05", "12", "13", "14", "10", "40"],
     "issue": "Invoices and payments are modeled in several domains: 05 Partner Invoice and Partner Payment (PMT-), 12 Fee Invoice (BIL-), 13 Intermediary Communication Fee Invoice (IFI-), 14 Data Invoice (DINV-, with an 'AP Document Reference' AP-... pointing at the ERP). 10 stewards the shared lists Payable Invoice Status and Outgoing Payment Status. 40 Procurement (Stage 4) will hold purchase orders.",
     "resolution": "19 masters the generic accounting records: Payable Invoice (APV-), Payable Invoice Line, Supplier Payment, Receivable Item and Cash Receipt Application. Domain records keep their operational detail and reference 19 (14 'AP Document Reference' becomes Reference (Payable Invoice) APV-; 12 BIL- is the source document of a 19 Receivable Item). Stewardship of the shared lists Payable Invoice Status and Outgoing Payment Status moves from 10 to 19. 40 will master purchase orders and reference 19 Payable Invoice for matching. No 05, 12, 13 or 14 change is made in Stage 1; the reference attributes are proposed in proposals_19.py and applied at consolidation.",
     "rationale": "Applies the shared-concept pattern (CD-144) to invoices: one accounting record, with domain detail kept where it is produced.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Finance Controller"},

    {"id": "CD-159", "theme": "Enterprise Structure", "title": "AI use cases and their data governance in 21; model inventory, validation and tiering in 37",
     "domains": ["21", "37", "14", "02"],
     "issue": "Plan §3 gives 21 'model and AI governance' and 37 a Model Risk Management family (model inventory, validation, tiering). Without a split, both would build a model inventory.",
     "resolution": "21 masters AI Use Case (AIU-), AI Data Usage Approval and AI Risk Classification (EU AI Act, NIST AI RMF): what data an AI or analytical use may consume and on what basis. 37 masters the model inventory, validation and tiering for all quantitative and AI models. Until 37 is drafted (Stage 4), the AI Use Case holds 'Model Name' as text; it becomes a reference to the 37 model at consolidation. Personal data processing records stay with 02 (and later 38/39).",
     "rationale": "Data governance and model risk are run by different functions with different regulators' expectations (data governance vs SR 11-7 model risk).",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Data Officer"},

    {"id": "CD-160", "theme": "Enterprise Structure", "title": "Catalog boundaries: 21 Data Asset vs 14 Dataset, 06 Data Feed and 12 Client Data Feed; data products as 21 instances",
     "domains": ["21", "14", "06", "12"],
     "issue": "14 has a 'Dataset & Data Product Catalog' for licensed data (DSET-, Dataset Consumption, Consuming Application DAPP-); 06 masters technical feeds (FEED-) and loads (LOAD-); 12 masters outbound client data feeds (CDF-). 21 masters the internal data catalog, lineage and data products, and the existing catalog of 96 data products (DP-nnn) and semantic models are to become instances of 21 objects.",
     "resolution": "21 Data Asset (DAS-) is the catalog entry for any internal asset; a licensed dataset is a Data Asset of type 'Licensed Dataset' that references 14 DSET- (license terms stay in 14); a feed is a lineage node referencing 06 FEED-; 12 CDF- outbound feeds are lineage targets. 14 Consuming Application is not extended into an application inventory (41, Stage 4); 21 uses an interim firm-defined 'System' list. 21 Data Product formalizes the existing DP- IDs and Governance Decision formalizes the CD- IDs, both registered as 21 prefixes. The data product build (_tools/data_products) is unchanged in the expansion (plan §2).",
     "rationale": "One catalog without remastering license, feed or client-delivery data owned elsewhere.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Data Officer"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. PREFIXES reserved by the Stage 1 briefs  (prefix, entity, owner domain, status, note)
# Checked against decisions.PREFIXES (234 entries), conventions §3/§6/§8/§9, unregistered prefix-like strings in the
# content modules (AP-, INV-, GL-, WD-, SUP-, AI-, CC-, ...), data product / framework IDs (DP-nnn, FN-nn) and each other.
# Transferred prefixes (EMP-, JNL-, DQR-) are listed with their new owner.
# ---------------------------------------------------------------------------------------------------------------------

PREFIXES = [
    # ---- 17 Instrument & Issuer Reference
    ("INS-", "Instrument", "17", "Reserved", "Stage 1 brief. Not IND- (06, retired) or INV- (invoice text); family code IN-MST avoids look-alike attribute IDs."),
    ("IID-", "Instrument identifier record (instrument x scheme x value)", "17", "Reserved", "Stage 1 brief. Not IDR- (11) or IFI- (13)."),
    ("ISR-", "Instrument setup request", "17", "Reserved", "Stage 1 brief. Not SRQ- (13) or RSL- (08)."),
    ("LST-", "Instrument listing (third-party instruments; own listings stay in 01)", "17", "Reserved", "Stage 1 brief. Not LIC- (08), LEN- (09) or LOT- (18)."),
    ("CAE-", "Corporate action event (reference)", "17", "Reserved", "Stage 1 brief. Not CAM- (04) or CAL- (09). Entitlements and elections will be 28."),
    # ---- 18 Portfolio & Investment Book of Record
    ("PORT-", "Portfolio (managed book)", "18", "Reserved", "Stage 1 brief (CD-145). PTF- rejected as one letter from PTY-; not POS- (06 shareholder position)."),
    ("HLD-", "Portfolio holding", "18", "Reserved", "Stage 1 brief (CD-146). Not HRS- (10) or HH- (02, retired)."),
    ("LOT-", "Tax lot", "18", "Reserved", "Stage 1 brief. Confusable with LOAD- (06), LOAN- (16) and LST- (17)."),
    ("PTXN-", "Portfolio transaction (as booked in the IBOR)", "18", "Reserved", "Stage 1 brief. Deliberately related to TXN- (06 shareholder transaction) but owned by 18; not PTY- or PTRM- (16)."),
    # ---- 19 Finance & Accounting
    ("GLA-", "GL account (chart x natural account)", "19", "Reserved", "Stage 1 brief (CD-152). Not GOL- (07) or GEO- (09); GL- appears only as text."),
    ("LDG-", "Ledger (legal entity x accounting basis x currency)", "19", "Reserved", "Stage 1 brief (CD-152). Replaces the 10 local list 'Ledger'. Not LEN- (09) or LEAD- (04)."),
    ("JNL-", "Journal entry / GL posting", "19", "Reserved", "Transferred from 10 under CD-152 (registered to 10 as Proposed)."),
    ("APV-", "Payable invoice (AP voucher)", "19", "Reserved", "Stage 1 brief (CD-158). 14 'AP Document Reference' examples (AP-...) become references to APV-. Not ABI- (15)."),
    ("FPL-", "Financial plan version (enterprise budget / forecast)", "19", "Reserved", "Stage 1 brief. 10 BUD- distribution plans roll into it. Not FRM- (04) or FRR- (10)."),
    ("TAXR-", "Corporate tax return", "19", "Reserved", "Stage 1 brief. Moves with the Corporate Tax family if a Tax domain is created (CD-149). Not TXN- (06) or TRN- (12)."),
    # ---- 20 Human Capital
    ("EMP-", "Employee (enterprise workforce master)", "20", "Reserved", "Transferred from 09 under CD-151 (registered to 09 since CD-120). Not PEMP- (16 participant employment event)."),
    ("JOB-", "Job profile", "20", "Reserved", "Stage 1 brief. Not JNL- (19)."),
    ("WFP-", "Workforce position (budgeted position)", "20", "Reserved", "Stage 1 brief. 'Position' alone is avoided (06 POS-, 18 HLD-). Not WVR- (10) or WD- (Workday number text)."),
    ("ELE-", "Employee lifecycle event", "20", "Reserved", "Stage 1 brief. Confusable with ALE- (15 account lifecycle event); 16 'Employment Event' is PEMP-."),
    ("JRQ-", "Job requisition", "20", "Reserved", "Stage 1 brief. Not SRQ- (13) or ISR- (17)."),
    ("VPA-", "Variable compensation award (bonus, deferred award, carry)", "20", "Reserved", "Stage 1 brief. VCA- rejected (anagram of CVA-, 07); AWD- is 11. Confusable with PYA- (05) and VRA- (14)."),
    # ---- 21 Data Governance & Analytics
    ("DQR-", "Data quality rule", "21", "Reserved", "Transferred from 06 under CD-156 (registered to 06 as Proposed)."),
    ("DQI-", "Data quality issue", "21", "Reserved", "Stage 1 brief. Same family as DQR-; not DDQ- (08) or VDI- (14)."),
    ("DAS-", "Data asset (catalog entry)", "21", "Reserved", "Stage 1 brief (CD-160). Not DAPP- or DSET- (14), DSP- (07)."),
    ("BTM-", "Business term (glossary)", "21", "Reserved", "Stage 1 brief. GLT- rejected (one letter from GLA-, 19). Not BMK- (01)."),
    ("KPI-", "Metric definition (enterprise metric and KPI registry)", "21", "Reserved", "Stage 1 brief. References 06 MSR- where a measure is already defined."),
    ("DP-", "Data product", "21", "Reserved", "Formalizes the existing DP-001 ... DP-096 catalog IDs (CD-160). Two letters like a domain code; DP is not a domain code."),
    ("CD-", "Governance decision (decision log entry)", "21", "Reserved", "Formalizes the existing decision log IDs (CD-160). Not CC- (02 domain code)."),
    ("AIU-", "AI use case", "21", "Reserved", "Stage 1 brief (CD-159). AI- appears only as text ('AI-Assisted'); not AUTH- (09)."),
]
