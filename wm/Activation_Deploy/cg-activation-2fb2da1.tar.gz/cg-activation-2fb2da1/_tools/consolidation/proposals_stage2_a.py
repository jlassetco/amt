"""Decision proposals for the enterprise expansion, Stage 2, investment chain (Data Domains 22-26).

Format: identical to decisions.py (see CONTRACT.md in this folder). This file is a proposal fragment: the builder does not
read it, and nothing here changes a content module. The Stage 2 consolidation step (Enterprise_Expansion_Plan.md §9.3
step 5) merges accepted entries into decisions.py.

Sources: Enterprise_Expansion_Plan.md v0.4 §3, §4 and §9; Domain_Ownership_and_Conventions.md §2, §8, §13, §14; the
Stage 1 Source_Notes of 17 and 18 (derived copies held for 22, 25 and 26); stage1_consolidation_notes.md §2-§3; the
Phase A briefs 22-26 in 00_Program/Expansion/Briefs/; a scan of content_01, 03, 05, 06, 09, 11, 12, 14, 17, 18 and 19 on
2026-10-06; Business_Capability_Map content (C-01 to C-04).

IDs CD-167 to CD-185 are reserved for this fragment (Stage 2 briefs, investment chain). The fund operations briefs
(27-30) use their own range. Every entry has status "Proposed"; where the business must choose, action is
"SME decision" and the resolution gives the recommended option. CD-155 (SSIs, 12 vs 26) is not restated here; brief 26
gives both of its options.

Merged at the Stage 2 consolidation (2026-10-06; CD-210): the decisions are in decisions.py with the prefixes renamed
there (CREC- to CUREC-, CAEL- to ELECT-, DVD- to FDIV-, FCL- to CLOSE-, SCA- to SCAC-, TAO- to FNDO-, TAS- to FBAT-,
TAC- to TACK-); this file keeps the names as reserved. See stage2_consolidation_notes.md.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. DECISIONS
# ---------------------------------------------------------------------------------------------------------------------

DECISIONS = [
    # ===================================== 22 Market Data & Pricing =====================================
    {"id": "CD-167", "theme": "Market Data", "title": "Security prices, evaluated prices and approved prices are mastered in 22; 17 holds no prices and 18 holds copies",
     "domains": ["22", "17", "18", "27", "06", "01"],
     "issue": "17 Instrument & Issuer Reference excludes prices, yields, factors and index levels (boundary rule 3). 18 Portfolio & IBOR holds Price Used, Price Date, Price Source and Delta Used on Holding Valuation and Derivative Holding Detail as Derived copies with Notes 'future owner 22'. 06 Transaction 'Price' is the dealing price of a shareholder transaction (NAV or offer price). Own fund share classes held by own portfolios are priced at their NAV, which 27 Fund Accounting & Valuation will master.",
     "resolution": "22 masters Price Observation (instrument x price type x source x as-of timestamp), the Approved Price (PRICE-, instrument x pricing point x price date) and Pricing Analytics Observation (vendor yield, spread, duration and option delta per instrument and date). At consolidation the 18 attributes Price Used, Price Date and Price Source (Holding Valuation) are re-noted as Derived copy (22) of the Approved Price, and Delta Used (Derivative Holding Detail) as Derived copy (22) of Pricing Analytics Observation. 18's Price Source list placeholder 'External (future 22 price source list)' is replaced by the 22 list Price Source Type. Row rule on the Approved Price: for instruments of type 'Own Fund Share Class' (17) the approved value is a Derived copy of the 27 share class NAV; for every other instrument it is mastered in 22. 06 Transaction 'Price' is not a 22 price and does not change.",
     "rationale": "The pricing team sources, validates and approves prices under the valuation policy; the security master team keeps static terms. One owner per observed value, with a stated row rule for own funds.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Head of Pricing and Valuation"},

    {"id": "CD-168", "theme": "Market Data", "title": "FX rate observations mastered in 22 (implements CD-153); Stage 1 rate copies re-pointed",
     "domains": ["22", "09", "18", "19", "06", "25"],
     "issue": "CD-153 keeps FX rate types and sources in 09 and puts FX rate time series in 22. Stage 1 left rate values as derived copies: 18 Holding FX Rate, Cash FX Rate and Trade FX Rate; 19 GL Posting and Account Balance 'Applied Exchange Rate'. 06 Transaction 'FX Rate Applied' is mastered in 06 today. A rate agreed on an executed FX trade is a trade price, not market data.",
     "resolution": "22 masters FX Rate Observation (FXR-): 09 FX Rate Type x currency pair x tenor x as-of timestamp, with spot and forward points. 09 FX Rate Type (fixing time, rate side, quote convention, fallback rule, approved usage) and FX Rate Source are referenced, never repeated. At consolidation: 18 Holding FX Rate and Cash FX Rate and 19 Applied Exchange Rate (both objects) are re-noted 'Derived copy (22)'. 18 Trade FX Rate takes a row rule: Derived copy (22) where the rate is a market rate applied at booking, Derived copy (25) where it is the rate of an executed FX trade (25 Execution). 06 Transaction 'FX Rate Applied' is proposed as a Derived copy (22) for a later 06 decision; no 06 change is made in Stage 2 unless the program lead accepts it.",
     "rationale": "Closes CD-153 and gives every Stage 1 rate copy a named master.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Market Data"},

    {"id": "CD-169", "theme": "Market Data", "title": "Index levels and constituents in 22, keyed by the 01 Benchmark; no second index master",
     "domains": ["22", "01", "14", "17", "24", "32"],
     "issue": "Plan §3 gives 22 'index levels and constituents' and 01 'defines benchmarks'. 01 Benchmark (BMK-) covers indices used as benchmarks; 17 uses BMK- for index underlyings and proposals_17 asked 01 to widen Benchmark to every index used as an underlying (stage1_consolidation_notes §3 item 4, deferred). 14 Index Use holds the index licenses.",
     "resolution": "Recommended (option A): 01 widens Benchmark to every index the firm references (benchmark, underlying, index tracked, research index), and 22 keys Index Level Observation, Index Constituent and Index Change Announcement by BMK-. 22 creates no index definition attributes (administrator, currency, return type stay in 01). Option B, only if 01 declines: 22 masters an 'Index Reference' object for indices that are not benchmarks, with the contingent prefix IDX-, and 01 BMK- references it. The 22 Index Level Variant list reuses the 01 Return Type values (Price Return, Net Total Return, Gross Total Return).",
     "rationale": "One master for what an index is; 22 owns only what is observed about it. Depends on the deferred Stage 1 item.",
     "action": "SME decision", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Market Data"},

    {"id": "CD-170", "theme": "Market Data", "title": "Fair value determinations and the valuation committee are mastered in 22",
     "domains": ["22", "30", "27", "18", "35", "37", "01"],
     "issue": "SEC Rule 2a-5 requires a fund's board or its valuation designee to determine fair value in good faith, with methodologies, testing and pricing-service oversight (records under Rule 31a-4). AIFMD Art 19 and Delegated Regulation 231/2013 Arts 67-74 require a functionally independent valuation function. Plan §3 rows 22 and 30 put fair value decisions, including private asset valuations, in 22. 18 Fund Interest Holding Detail holds 'Adjusted NAV' (GP NAV adjusted for subsequent activity), which is a fair value.",
     "resolution": "22 masters Fair Value Determination (FVD-: instrument x valuation date x pricing point), its Valuation Inputs (including unobservable Level 3 inputs), Fair Value Factors applied to foreign securities, Fair Value Trigger Events, Valuation Back-Tests, the Valuation Committee and its meetings. 30 Private Markets references FVD- for portfolio company and fund-interest valuations and keeps deal and investor economics. 27 applies the approved value in NAV. 35 Fund Governance (Stage 3) masters board oversight and the 2a-5 board reports and references 22. 37 (Stage 4) masters the valuation model inventory; until then 22 holds 'Valuation Model Name' as text. At consolidation, 18 Fund Interest Holding Detail 'Adjusted NAV' is re-noted Derived copy (22); 'GP Reported NAV' stays mastered in 18 as a received statement value.",
     "rationale": "One record of each fair value decision, kept by the valuation function that the rules require to be independent of portfolio management.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Valuation Designee / Head of Pricing and Valuation"},

    {"id": "CD-171", "theme": "Market Data", "title": "Price challenges in 22; 14 Vendor Data Issue keeps dataset-level issues",
     "domains": ["22", "14", "21"],
     "issue": "14 Vendor Data Issue (VDI-) records issues with licensed datasets, with 'Own Data Challenge Indicator' and vendor ticket. A price challenge is a valuation control on one instrument's price (challenged and proposed value, vendor response, effect on NAV). 21 Data Quality Issue (DQI-) is the enterprise data quality issue.",
     "resolution": "22 masters Price Challenge (PCHL-) and Price Validation Exception. A challenge that reveals a systemic feed problem references a 14 VDI- (Related Vendor Data Issue); 14 does not record per-price challenges. Price tolerance rules are valuation controls mastered in 22 (Price Tolerance Rule); 21 may catalog them as Data Quality Rules by reference but does not restate thresholds.",
     "rationale": "Keeps per-price valuation evidence (needed for 2a-5 pricing-service oversight) with the pricing team, and vendor management with 14.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Pricing and Valuation"},

    # ===================================== 23 Investment Research =====================================
    {"id": "CD-172", "theme": "Research", "title": "Investment research (23) is distinct from market intelligence (11), commentary (01), sales activity (03) and stewardship engagement (34)",
     "domains": ["23", "11", "01", "03", "04", "34", "38", "05"],
     "issue": "'Research' is used in 11 (Market Research Report MRR-, Market Trend), 03 (Consultant Research Review), 05 (Partner Research Rating) and 01 (Investment Commentary CMT-). 03 Sales Activity (ACT-) could be used for meetings with issuers. 34 (Stage 3) will record engagements with investee companies, and 38 (Stage 4) the restricted list and MNPI controls.",
     "resolution": "23 masters research coverage, research recommendations, internal credit assessments, estimates and models, research publications, issuer meetings, third-party research consumption and research provider evaluation. 11 keeps distribution and competitor intelligence; 01 keeps client-facing commentary (a 23 publication made public is a 01 commentary or 04 content asset linked to it); 03 Sales Activity is never used for issuer meetings; 34 Engagement will reference the 23 Issuer Meeting (IMTG-) when a meeting has a stewardship objective; 38 masters the restricted and watch lists and insider lists, and 23 records only that MNPI may have been received on a meeting. Glossary qualifiers: 'Investment Research' (23), 'Market Research' (11), 'Partner Research Rating' (05), 'Consultant Research Review' (03).",
     "rationale": "Different producers (research analysts vs distribution strategy vs sales) and different controls (MNPI, MiFID inducements).",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Director of Research"},

    {"id": "CD-173", "theme": "Research", "title": "Internal credit assessments (including Rule 2a-7 minimal credit risk determinations) in 23; agency ratings stay in 17",
     "domains": ["23", "17", "33", "27", "11"],
     "issue": "17 Credit Rating Assignment holds agency ratings (Credit Rating Agency list). Credit analysts also assign internal ratings, and Rule 2a-7 requires the adviser to determine that a money market fund security presents minimal credit risks. TERM_CONFLICTS already holds 'Rating' (11 fund ratings, 17 credit ratings, 05 partner research ratings).",
     "resolution": "23 masters Internal Credit Assessment (issuer or instrument x analyst x effective date: internal rating, outlook, recovery view, minimal credit risk determination for 2a-7 eligible securities). 17 adds no 'Internal' agency value. 33 (Stage 3) reads both for limits. Extend the 'Rating' term conflict with 'Internal Credit Rating' (23) and 'Research Recommendation' (23).",
     "rationale": "Internal ratings are research output, with analyst accountability and history; agency ratings are reference data.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Credit Research"},

    {"id": "CD-174", "theme": "Trading", "title": "Commissions and research payments in 25; research valuation in 23; booked commission in 18 becomes a copy",
     "domains": ["25", "23", "18", "19", "14"],
     "issue": "Plan §3 row 25 gives 25 commissions and research payments; capability C-01.04 Research Payment Management is mastered by 25 and reads 23. MiFID II (Delegated Directive 2017/593 Art 13, amended for joint payment by Directive (EU) 2024/2811) and FCA COBS 2.3B (PS24/9) govern research payment accounts and budgets; Exchange Act Section 28(e) governs US commission sharing. 18 Transaction Cost & Charge holds Commission Amount and Research Payment Component as mastered.",
     "resolution": "25 masters Commission Schedule, Commission Sharing Arrangement, Research Budget (with the research payment account) and Research Payment, and the commission and fees on each Trade Allocation (ALLOC-). 23 masters Research Provider Evaluation (the broker vote), which 25 Research Payment references. 19 masters the accounting (Payable Invoice APV- for research invoices). 14 keeps research subscriptions that are licensed datasets (DLA-). At consolidation, 18 Commission Amount and Research Payment Component are re-noted Derived copy (25) of the allocation's commission; 18 keeps its own totals and capitalization flag. The acronym 'CSA' is not used in 25 names, because 26 uses it for the Credit Support Annex.",
     "rationale": "One owner for the commission, decided where the trade is allocated; the value of research is judged by the people who use it.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Trading"},

    # ===================================== 24 Portfolio Management & Construction =====================================
    {"id": "CD-175", "theme": "Portfolio Management", "title": "Portfolio Manager Assignment: move from 01 to 24, or keep the disclosed manager in 01",
     "domains": ["24", "01", "20", "18", "03"],
     "issue": "01 Product Parties & Roles holds 'Portfolio Manager Assignment' (Portfolio Manager typed Reference (Party) with a PTY- example, forced to 20 by override; Portfolio Manager Role; PM Start Date; PM End Date) at product / mandate grain, and 01 Investment Strategy holds 'Lead Portfolio Manager' and 'Investment Team'. Plan §3 row 24 and capability C-02.07 make 24 the master of portfolio manager assignments, which run at portfolio (18 PORT-) grain. Form N-1A Item 5 requires the fund's portfolio managers to be named, so a product-level disclosed list also exists.",
     "resolution": "Recommended (option A): move 01 'Portfolio Manager Assignment' to 24 with object and attribute names unchanged (as in the v0.4 Account move), re-type Portfolio Manager to Reference (Employee) EMP-, add Assigned Portfolio (PORT-) and Assigned Investment Team (09 OU-) and a 'Prospectus Disclosed Indicator'; the product / mandate references stay for the disclosed list. 01 Investment Strategy 'Lead Portfolio Manager' becomes Derived copy (24). Option B: 01 keeps the object as the disclosed product-level list, and 24 masters a separate 'Portfolio Management Assignment' at portfolio grain, with 01 rows reconciled to it by a consolidation check. Option A leaves one master; option B keeps 01 unchanged but leaves two records of who manages what.",
     "rationale": "Assignments are maintained by the investment platform team per book; disclosure is a view of them.",
     "action": "SME decision", "status": "Proposed", "priority": "Medium", "owner_role": "CIO Office"},

    {"id": "CD-176", "theme": "Portfolio Management", "title": "Model portfolio target allocations are mastered in 24; the model as a delivered product stays 01 MDL-",
     "domains": ["24", "01", "05", "15", "18"],
     "issue": "01 Model Portfolio (MDL-) holds name, strategy, sponsor / platform, rebalance frequency and delivery method, but no constituents or weights. CD-145 says a model portfolio is never a Portfolio. Capability C-02.03 (Model Portfolio Management) is 24's; C-02.04 (Model Delivery to Sponsors) is 01's. 05 Model Program Placement and 15 Platform Program Enrollment 'Assigned Model Portfolio' reference the model.",
     "resolution": "24 masters Target Allocation Set (TGT-) and Target Allocation Line for both portfolios (18 PORT-) and models (01 MDL-), so a model's weights over time are 24 data with Target Subject = MDL-. 01 keeps the model record and its delivery terms; 05 and 15 are unchanged. A model change delivered to sponsors is a published Target Allocation Set version; any delivery-event record belongs to 01 (gap noted, not created in 24).",
     "rationale": "The investment team produces model weights the same way it produces portfolio targets; the product team owns the model as an offering.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "CIO Office"},

    {"id": "CD-177", "theme": "Portfolio Management", "title": "ETF basket construction in 24; AP order processing in 29; primary-market flows stay in 06",
     "domains": ["24", "29", "06", "01", "18", "27", "35"],
     "issue": "SEC Rule 6c-11 requires written custom basket policies (c)(3) and daily website disclosure of portfolio holdings (c)(1)(i), with basket records kept under (d). 01 ETF Characteristics holds Replication Method, Creation Unit Size and Index Tracked. 06 ETF Creation / Redemption holds Authorized Participant, Creation Units and Basket Type as primary-market flow data. 18 books in-kind transfers. 29 (Stage 2, fund operations) processes AP orders.",
     "resolution": "24 masters ETF Basket (BSKT-: ETF share class x basket date x creation / redemption x standard / custom), ETF Basket Constituent and Custom Basket Approval. The basket's estimated cash component is a Derived copy (27) of fund accounting values. 29's AP order object will reference the 24 ETF Basket (BSKT-); 06 keeps its flow record and Basket Type; 01 keeps creation unit size and replication method; 18 books the in-kind transfer; 35 (Stage 3) masters the daily website disclosure filing.",
     "rationale": "Basket design is a portfolio management decision; order processing with APs is a transfer agency operation.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of ETF Portfolio Management"},

    {"id": "CD-178", "theme": "Portfolio Management", "title": "Investable cash forecast in 24 builds on 18 projected cash; it never restates it",
     "domains": ["24", "18", "06", "29", "12"],
     "issue": "Plan §3 row 24 lists cash forecasts. 18 already masters Projected Cash Movement (from pending transactions, income and capital activity) and Portfolio Capital Activity (expected and actual subscriptions and redemptions as cash to the portfolio, including 12 Cash Flow Notifications).",
     "resolution": "24 masters Investable Cash Forecast (portfolio x forecast date x value date) and Cash Forecast Adjustment (portfolio manager estimates of flows and planned decisions). The projected amounts taken from 18 are Derived copy (18); 24 adds only its own estimates, cash target and investable result. 24 never creates projected cash movements or capital activity.",
     "rationale": "Avoids a second cash projection while giving portfolio managers their decision view.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Low", "owner_role": "CIO Office"},

    # ===================================== 25 Trading & Execution =====================================
    {"id": "CD-179", "theme": "Trading", "title": "Approved broker and counterparty master in 25, as a role profile keyed by 02 PTY-",
     "domains": ["25", "02", "26", "31", "23", "37"],
     "issue": "Plan §3 row 25 makes 25 the master of the approved broker and counterparty list (approval, credit limits, status). CD-143 (working assumption: accepted) makes every broker and counterparty a 02 party with a role profile in the domain that stewards the role. 26 holds the legal and collateral terms with counterparties; 31 (Stage 3) measures counterparty exposure.",
     "resolution": "25 masters Approved Counterparty Profile (keyed by PTY-, like 17 Issuer Profile), Counterparty Approval Scope (party x approved activity x trading legal entity or fund x region), Counterparty Trading Limit and Counterparty Review. Party name, LEI and legal parents stay in 02; ISDA, CSA, GMRA and clearing agreements are 26 (TAGR-); exposure measurement is 31; any internal credit opinion on a counterparty is a 23 Internal Credit Assessment. Proposed 02 Party Role Type values: Executing Broker, Clearing Broker / FCM, Prime Broker, OTC Derivative Counterparty, FX Counterparty, Repo Counterparty, Research Provider, Expert Network, Trading Venue Operator, Central Securities Depository, Pricing Vendor, Index Administrator (Clearing House / CCP and Exchange Operator are already proposed by 17).",
     "rationale": "Approval and limits are set by the counterparty approval committee and maintained by trading; one party key avoids a second counterparty master.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Head of Trading"},

    {"id": "CD-180", "theme": "Trading", "title": "Trade orders, executions and allocations in 25; 18 Source Allocation ID becomes a reference",
     "domains": ["25", "24", "18", "26", "33", "12", "29"],
     "issue": "18 Portfolio Transaction holds 'Source Allocation ID' as a Derived copy (25) Identifier, because 25 had no prefix. 24 produces proposed trades; 33 (Stage 3) runs pre-trade checks; 12 Transition Event (TRN-) moves assets between mandates; 29 processes fund orders, which are a different kind of order.",
     "resolution": "25 masters Trade Order (TORD-), Block Order (BLOCK-), Broker Placement, Execution (EXEC-) and Trade Allocation (ALLOC-). At consolidation 18 'Source Allocation ID' is re-typed Reference (Trade Allocation, 25) with ALLOC- examples. A 24 Proposed Trade becomes a Trade Order when released, and the order references it. A Trade Order references 12 TRN- when it implements a transition. 33 masters compliance checks; the order carries only a Derived copy of the check outcome. 'Order' is never used bare in 25; 29's fund order and 06 'Order Source' are different concepts.",
     "rationale": "Gives the allocation one key that 18 (booking) and 26 (confirmation and settlement) both reference.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Head of Trading"},

    # ===================================== 26 Trade Operations, Settlement & Collateral =====================================
    {"id": "CD-181", "theme": "Trade Operations", "title": "Settlement status and collateral values held in 18 are copies of 26 (and 28 for securities lending)",
     "domains": ["26", "18", "28"],
     "issue": "18 holds Settlement Confirmed Indicator (Portfolio Transaction), Encumbered Quantity (Portfolio Holding) and Initial Margin Posted (Derivative Holding Detail) as Derived copies with future owner 26 (Encumbered Quantity: 26 collateral or 28 securities lending). Settled and Unsettled Quantity are IBOR computations from settlement status.",
     "resolution": "26 masters Settlement Instruction (SETL-) and Settlement Status Event; Collateral Balance; and Initial Margin Calculation. At consolidation: 18 Settlement Confirmed Indicator is Derived copy (26) of the latest settlement status; Initial Margin Posted is Derived copy (26) of Collateral Balance (initial margin, posted); Encumbered Quantity takes a row rule, Derived copy (26) for collateral pledged under a 26 Trading Agreement and Derived copy (28) for securities on loan. 18 Settled and Unsettled Quantity stay mastered in 18 as computations.",
     "rationale": "Names the master for every settlement and collateral value Stage 1 left open.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Trade Operations"},

    {"id": "CD-182", "theme": "Trade Operations", "title": "Trading agreements (ISDA, CSA, GMRA, clearing and give-up agreements) mastered in 26",
     "domains": ["26", "05", "14", "39", "28", "25"],
     "issue": "05 Distribution Agreement (AGR-), 14 Data License Agreement (DLA-), 10 Intercompany Agreement (ICA-) and 12 Billing Arrangement are domain agreements that 39 Legal (Stage 4) will index. No domain holds the ISDA Master Agreement, the Credit Support Annex, repo master agreements (GMRA, MRA), futures clearing or give-up agreements. Securities lending agreements (GMSLA, agency lending) belong with 28.",
     "resolution": "26 masters Trading Agreement (TAGR-), Credit Support Terms, Eligible Collateral Schedule and Termination Event Trigger. 25 Counterparty Approval Scope may require an executed TAGR- before trading. 39 will index TAGR- in the enterprise contract repository as it will 05 AGR- and 14 DLA-. 28 masters securities lending agreements. 05 is unchanged.",
     "rationale": "The collateral and documentation team maintains these terms and uses them daily for margin; they are not distribution agreements.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Trade Operations"},

    {"id": "CD-183", "theme": "Trade Operations", "title": "Hand-off from settlement (26) to fund accounting (27) and custody reconciliation (28)",
     "domains": ["26", "27", "28", "29", "18"],
     "issue": "Settled trades feed the fund ledgers (27) and custody reconciliations (28). Without a rule, 26 could build cash and position reconciliations against custodian statements, and 27 or 28 could rebuild settlement status. ETF in-kind baskets settle between the fund and authorized participants whose orders 29 processes.",
     "resolution": "26 masters trade-level settlement (instruction, status advices, confirmations, fails, penalties). 27's fund ledger entries will reference the 26 Settlement Instruction (SETL-) and its settled status; 28's custody position and cash reconciliations will reference 26 settlements and SSIs but 26 holds no statement-of-holdings reconciliation (semt.002 / MT 535 belong to 28; sese.024 / MT 548 status advices belong to 26). Securities deliveries of ETF in-kind baskets are 26 Settlement Instructions (type In-Kind Creation / Redemption) that reference the 29 AP order; 29 keeps the order and its cash component.",
     "rationale": "Separates trade-level settlement from accounting and safekeeping, matching the ISO 20022 sese / semt split.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Investment Operations"},

    {"id": "CD-184", "theme": "Trade Operations", "title": "Regulatory trade and transaction reporting: derivatives and SFTs in 26, MiFIR transaction reports in 25, fund filings in 35",
     "domains": ["26", "25", "35", "38", "28"],
     "issue": "EMIR (Regulation 648/2012, reporting RTS 2022/1855 from 29 April 2024), UK EMIR (Refit live 30 September 2024) and CFTC Part 45 require derivative trade reports; SFTR (Regulation 2015/2365) requires repo reports; MiFIR Art 26 (RTS 22, Delegated Regulation 2017/590) applies to MiFID investment firms, including portfolio management of EU / UK SMAs, unless the transmission conditions are met; CAT reporting falls on broker-dealers (Industry Members), not on the firm as adviser, while Rule 13h-1 requires the large trader ID to be given to brokers. N-PORT, Form PF and Annex IV are fund filings (35).",
     "resolution": "26 masters Derivative Trade Report (EMIR, UK EMIR, CFTC Part 45 and SFTR repo reports, by UTI and submission). 25 masters MiFIR transaction reports if SME question confirms the firm reports (otherwise none) and carries the Large Trader ID on orders as a Derived copy of the 38 firm registration (09 Entity Authorization until 38 exists). SFTR reports on securities lending are 28. Fund regulatory filings stay 35. No CAT objects are modeled.",
     "rationale": "Each report is produced where its source record is mastered.",
     "action": "SME decision", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Regulatory Reporting"},

    {"id": "CD-185", "theme": "Reference Data", "title": "Settlement cycle rules in 26; settlement calendars stay 09 calendars",
     "domains": ["26", "09", "05", "29"],
     "issue": "Plan §3 asks for a 09 scope check on settlement calendars for 26. 09 Calendar (CAL-) holds business, holiday, exchange and dealing calendars. US T+1 applied from 28 May 2024 (SEC Rules 15c6-1 and 15c6-2); EU (Regulation (EU) 2025/2075) and UK move to T+1 on 11 October 2027. 05 Trading Setup holds 'Settlement Cycle' for fund order dealing with partners, which is a different settlement (29).",
     "resolution": "Settlement calendars are 09 Calendars; 26 proposes a 09 Calendar Type value 'Settlement (CSD / Payment System)' and does not model calendar dates. 26 masters Settlement Cycle Rule (market x instrument type x trade type x effective period: standard cycle, same-day affirmation cut-off). 05 Trading Setup Settlement Cycle is unchanged and is a fund-dealing term (term conflict 'Settlement Cycle').",
     "rationale": "Calendars are shared reference data; the cycle convention per market is maintained by settlement operations and changes with T+1 migrations.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Low", "owner_role": "Head of Trade Operations"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. PREFIXES reserved by the Stage 2 investment chain briefs  (prefix, entity, owner domain, status, note)
# Checked against decisions.PREFIXES (260 entries), conventions §3/§6/§8/§9/§14, a scan of prefix-like strings in
# _tools/content, data_products, data_models, capability_map and consolidation (e.g. NAV-, PERF-, REC-, SAF-, DRV-),
# DP-nnn / FN-nn / GAP- / CD- IDs, Stage 1-4 domain codes, and the prefixes the fund operations briefs (27-30) would
# naturally choose (NAV-, CUST-, TAO-, ORD-, CMT-, CAP-, DEAL-, VAL-, REC- / RECN-), none of which is used here.
# ---------------------------------------------------------------------------------------------------------------------

PREFIXES = [
    # ---- 22 Market Data & Pricing
    ("PRICE-", "Approved price (instrument x pricing point x price date)", "22", "Reserved", "Stage 2 brief (CD-167). PRC- rejected (one letter from PRD- 01, near PRX-/PRP- 13). Observations are keyed by grain."),
    ("PCHL-", "Price challenge", "22", "Reserved", "Stage 2 brief (CD-171). PCH- avoided (near PCL- 05). Not 14 VDI-."),
    ("FVD-", "Fair value determination", "22", "Reserved", "Stage 2 brief (CD-170). VAL- left free for 30 Private Markets; not FVD-like strings in content."),
    ("FXR-", "FX rate observation (09 rate type x pair x tenor x timestamp)", "22", "Reserved", "Stage 2 brief (CD-168). Confusable with FRR- (10 fee revenue record); 09 keeps FX Rate Type and Source."),
    ("CURVE-", "Curve definition (yield, credit spread, inflation, volatility surface)", "22", "Reserved", "Stage 2 brief. CRV- is 12 client review; CRV/CRR/CRA/CRX crowded."),
    ("IDX-", "Index reference (only if 01 Benchmark is not widened; CD-169 option B)", "22", "Reserved", "Contingent reservation. Unused under CD-169 option A, where index observations key on 01 BMK-. Not IND- (06, retired) or IDR- (11)."),
    # ---- 23 Investment Research
    ("RCOV-", "Research coverage assignment", "23", "Reserved", "Stage 2 brief. COV- avoided (07 CVA- coverage assignment, 12 SVA-); RCN-, RCL-, RCM- are 3-letter neighbors."),
    ("RREC-", "Research recommendation (analyst rating, price target)", "23", "Reserved", "Stage 2 brief (CD-173). REC-/RECO- avoided (reconciliation names likely in 28; RCN- 06); not RTG- (11)."),
    ("RPUB-", "Research publication (note, initiation, update)", "23", "Reserved", "Stage 2 brief. Not RPT-/RPK- (12) or MRR- (11 market research report)."),
    ("IMTG-", "Issuer meeting", "23", "Reserved", "Stage 2 brief (CD-172). MTG- left free (35 board meetings); not ACT- (03 sales activity)."),
    # ---- 24 Portfolio Management & Construction
    ("IDEC-", "Investment decision", "24", "Reserved", "Stage 2 brief. DEC- avoided (generic; 35 / 36 decisions; CD- is 21's governance decision). Not IDR- (11) or IID- (17)."),
    ("TGT-", "Target allocation set (portfolio or model target version)", "24", "Reserved", "Stage 2 brief (CD-176). Not TER-/TMD- (07) or TPL- (12)."),
    ("RBAL-", "Rebalance run", "24", "Reserved", "Stage 2 brief. RBL- avoided (near RLN- 07); not RUN- family members (RUN-, ARN-, RRN-, PRUN-)."),
    ("BSKT-", "ETF creation / redemption basket", "24", "Reserved", "Stage 2 brief (CD-177). BSK- rejected (one letter from BRK- 06 break). 29 AP orders reference it."),
    # ---- 25 Trading & Execution
    ("TORD-", "Trade order (portfolio-level securities order)", "25", "Reserved", "Stage 2 brief (CD-180). ORD- left free for 29 fund orders; not TRD- (11 market trend) or TRN- (12)."),
    ("BLOCK-", "Block order (aggregated for execution)", "25", "Reserved", "Stage 2 brief. BLK- rejected (one letter from BLA- 12 billing arrangement)."),
    ("EXEC-", "Execution (fill)", "25", "Reserved", "Stage 2 brief. Not ESC- (13) or EXE text."),
    ("ALLOC-", "Trade allocation", "25", "Reserved", "Stage 2 brief (CD-180). ALC- rejected (ALE- 15, ALM- 10, ALR- 07); 18 Source Allocation ID becomes a reference to it."),
    ("TCA-", "Transaction cost analysis result", "25", "Reserved", "Stage 2 brief. Not CCA- (10) or TPA text."),
    # ---- 26 Trade Operations, Settlement & Collateral
    ("CNFM-", "Trade confirmation / affirmation record", "26", "Reserved", "Stage 2 brief. CONF- rejected (one letter from CONT- 16); TCF- rejected (one letter from TCA- 25). Not CNS- (02)."),
    ("SETL-", "Settlement instruction (trade-level)", "26", "Reserved", "Stage 2 brief (CD-183). STL- avoided (near SLT- 03); not SSI- (standing instruction) or SIN- (15)."),
    ("CSDP-", "Settlement penalty (CSDR cash penalty, fails charge)", "26", "Reserved", "Stage 2 brief. PEN- left free (generic). Not CSD- party role text."),
    ("OTC-", "OTC derivative trade (contract lifecycle record, carries the UTI)", "26", "Reserved", "Stage 2 brief. 17 OTC Derivative Product Terms are product level (UPI); attribute names using 'OTC' carry no hyphenated value."),
    ("TAGR-", "Trading agreement (ISDA, CSA, GMRA, clearing, give-up)", "26", "Reserved", "Stage 2 brief (CD-182). Deliberately related to AGR- (05), owned by 26. CTA- rejected (near CTM- 07, CTL- 07)."),
    ("MCALL-", "Margin call", "26", "Reserved", "Stage 2 brief. MCL- rejected (one letter from MRL- 06 match rule)."),
    ("CPSI-", "Counterparty and portfolio settlement instruction (only under CD-155 option B)", "26", "Reserved", "Contingent reservation. Unused under CD-155 option A, where SSI- transfers from 12 to 26."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. TERM_CONFLICTS raised by the briefs (draft agents add detail in proposals_22 ... proposals_26)
# ---------------------------------------------------------------------------------------------------------------------

TERM_CONFLICTS = [
    {"term": "Order",
     "usages": [("25", "Trade Order / Block Order", "Securities order for a portfolio, aggregated for execution"),
                ("29", "Fund order (planned)", "Shareholder order to buy or sell units of the firm's funds"),
                ("06", "Order Source", "How a shareholder transaction was entered")],
     "recommendation": "Never use 'Order' bare. 'Trade Order' and 'Block Order' for 25; 29 qualifies its own term."},
    {"term": "Allocation",
     "usages": [("25", "Trade Allocation", "Split of executed quantity to portfolios and accounts"),
                ("07", "Credit Allocation", "Split of sales credit"), ("10", "Allocation Rule / Run", "Cost allocation"),
                ("24", "Target Allocation Set / Asset Allocation Policy", "Intended weights")],
     "recommendation": "Qualify every use: Trade Allocation, Credit Allocation, Cost Allocation, Target Allocation, Asset Allocation."},
    {"term": "CSA",
     "usages": [("26", "Credit Support Terms", "Credit Support Annex to an ISDA Master Agreement"),
                ("25", "Commission Sharing Arrangement", "US commission sharing under Section 28(e)")],
     "recommendation": "Spell both out in names; never use the acronym alone."},
    {"term": "Research",
     "usages": [("23", "Research Publication", "Investment research on issuers and markets"),
                ("11", "Market Research Report", "Distribution market research"),
                ("05", "Partner Research Rating", "Distributor's rating of the firm's funds"),
                ("03", "Consultant Research Review", "Consultant reviewing the firm")],
     "recommendation": "'Investment Research' is 23 only (CD-172)."},
    {"term": "Coverage",
     "usages": [("23", "Research Coverage Assignment", "Analyst covers an issuer or sector"),
                ("07", "Party Coverage Assignment", "Salesperson covers a party"),
                ("12", "Service Coverage Assignment", "Service team covers a client")],
     "recommendation": "Always qualify: Research, Party or Service coverage."},
    {"term": "Settlement",
     "usages": [("26", "Settlement Instruction / Settlement Cycle Rule", "Securities settlement of portfolio trades"),
                ("05", "Trading Setup: Settlement Method / Settlement Cycle", "Fund order settlement with partners"),
                ("12", "Cash Flow Notification: Settlement Form", "Client contribution form")],
     "recommendation": "26 uses 'Securities Settlement' in definitions; 05 and 29 use 'Fund Order Settlement' (CD-185)."},
    {"term": "Confirmation",
     "usages": [("26", "Trade Confirmation", "Broker / counterparty confirmation and affirmation of a trade"),
                ("13", "Investor statement / confirmation (STMT-)", "Confirmation sent to a shareholder")],
     "recommendation": "'Trade Confirmation' (26) vs 'Shareholder Confirmation' (13)."},
    {"term": "Price",
     "usages": [("22", "Approved Price / Price Observation", "Market or fair value of one instrument unit"),
                ("06", "Transaction: Price", "Dealing price of a shareholder transaction"),
                ("27", "Share class NAV (planned)", "Net asset value per share")],
     "recommendation": "Qualify as 'Instrument Price' (22) and 'Dealing Price' (06); NAV is never called a price in 22 except as the Derived copy row rule (CD-167)."},
    {"term": "Basket",
     "usages": [("24", "ETF Basket", "Creation / redemption basket"), ("06", "ETF Creation / Redemption: Basket Type", "Flow attribute"),
                ("17", "Instrument Relationship: Basket Weight", "Weight of an underlying in a basket instrument")],
     "recommendation": "'ETF Basket' for 24; 17 keeps 'Basket Weight' for derivative underlyings."},
    {"term": "Target",
     "usages": [("24", "Target Allocation Set", "Intended portfolio or model weights"), ("01", "Target Market", "MiFID target market"),
                ("07", "Goal", "Sales goal")],
     "recommendation": "Qualify as 'Target Allocation' in 24."},
]
