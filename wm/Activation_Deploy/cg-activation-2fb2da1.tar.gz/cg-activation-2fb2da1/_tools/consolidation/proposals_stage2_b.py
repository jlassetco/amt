"""Decision proposals for the enterprise expansion, Stage 2, brief set B: Data Domains 27-30
(Fund Accounting & Valuation, Custody & Asset Servicing, Transfer Agency Operations, Private Markets).

Format: identical to decisions.py (see CONTRACT.md in this folder). This file is a proposal fragment: the builder does not
read it, and nothing here changes a content module. The Stage 2 consolidation step (Enterprise_Expansion_Plan.md §9.3
step 5) merges accepted entries into decisions.py.

Sources: Enterprise_Expansion_Plan.md v0.4 §3, §4 and §9; Domain_Ownership_and_Conventions.md §2, §8, §13, §14; the Stage 2
briefs 27-30 in 00_Program/Expansion/Briefs/; a scan of content modules 01-21 on 2026-10-06.

IDs CD-186 to CD-205 are reserved for this brief set (brief set A, domains 22-26, uses the range below it). Every entry has
status "Proposed"; where the business must choose, action is "SME decision" and the resolution gives the recommended
option. Working assumptions of the program lead (CD-143 accepted, six enterprise business lines, governance metadata in 21,
per-attribute ownership with row rules) apply to every entry. Names of objects in domains 22-26 are the names these briefs
expect and must be confirmed against the 22-26 briefs.

Merged at the Stage 2 consolidation (2026-10-06; CD-210): the decisions are in decisions.py with the prefixes renamed
there (CREC- to CUREC-, CAEL- to ELECT-, DVD- to FDIV-, FCL- to CLOSE-, SCA- to SCAC-, TAO- to FNDO-, TAS- to FBAT-,
TAC- to TACK-); this file keeps the names as reserved. See stage2_consolidation_notes.md.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. DECISIONS
# ---------------------------------------------------------------------------------------------------------------------

DECISIONS = [
    # ===================================== 27 Fund Accounting & Valuation =====================================
    {"id": "CD-186", "theme": "Finance", "title": "Fund ledgers, fund chart of accounts and fund journals are mastered in 27 Fund Accounting & Valuation, not 19",
     "domains": ["19", "27", "10"],
     "issue": "19 Finance & Accounting holds the corporate books of group entities and excludes fund books by design (19 brief §3). The books of the funds the firm manages (ABOR) have no owner. Without a rule, fund journals could be modeled as 19 Journal Entries (JNL-) or fund GL accounts as 19 GL Accounts (GLA-).",
     "resolution": "27 masters Fund Accounting Book (fund x accounting basis), Fund Ledger Account, Fund Journal Entry (FJNL-), Fund Journal Line and Fund Trial Balance. A fund's transactions never post to a 19 ledger. A fee the fund pays the adviser is two records: a fund expense accrual in 27 and management company revenue in 10 / 19. Fund objects are named 'Fund ...' so they never collide with 19 names. 19 Receivable Item 'Debtor Fund Product' remains the adviser side of reimbursements owed by or to a fund.",
     "rationale": "The fund is a separate reporting entity with its own auditor and regulator; fund accounting (in house or administrator) is stewarded apart from the Controller's group.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Head of Fund Accounting"},

    {"id": "CD-187", "theme": "Fund Operations", "title": "Official NAV and share class NAV mastered in 27; holding prices and FX rates applied by reference to 22",
     "domains": ["27", "22", "18", "06", "13", "01", "32"],
     "issue": "06 Transaction carries 'Price' (dealing price applied) and Position 'Market Value'; 18 Portfolio Valuation Summary carries an IBOR total market value; 01 carries Valuation Terms and the iNAV ticker. No domain masters the NAV struck by fund accounting. 22 (Stage 2) will master prices and FX (CD-153).",
     "resolution": "27 masters Fund NAV Calculation and Share Class NAV (NAV-), including CIT unit values and insurance-dedicated fund NAVs. 27 applies security prices, fair values and FX rates by reference to 22 objects (expected names Security Price, FX Rate Observation, Fair Value Decision; confirm against the 22 brief) and never masters them. 06 Transaction 'Price' stays as delivered with a note that the official NAV is 27; 13, 32 and 12 read NAV from 27. 'NAV' is added to TERM_CONFLICTS (18 IBOR valuation, 06 AUM and 01 iNAV are not NAV).",
     "rationale": "The NAV is the regulated price of every shareholder order (Rule 22c-1); one master avoids conflicting NAVs in servicing, performance and reporting.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Head of Fund Accounting"},

    {"id": "CD-188", "theme": "Fund Operations", "title": "Expense caps and waivers: terms in 01, fund-level accrual in 27, adviser financial impact in 10",
     "domains": ["01", "27", "10", "19"],
     "issue": "01 Cost Disclosure holds Expense Cap Rate and Waiver Expiry Date; 10 Waiver Record (WVR-) holds Waived Fee Amount and Reimbursed Expense Amount as the adviser's revenue offset. The fund-side accrual that produces those amounts has no owner.",
     "resolution": "01 keeps the cap and waiver terms. 27 masters Expense Cap & Waiver Accrual (share class x accrual date). At consolidation, 10 Waiver Record Waived Fee Amount and Reimbursed Expense Amount become Derived copies of 27, and 10 keeps the accounting treatment and recoupment fields. 19 holds the resulting receivable or payable of the adviser.",
     "rationale": "One economic event seen from two books; the fund-side accrual is the source amount that the adviser's revenue offset must equal.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Fund Accounting"},

    {"id": "CD-189", "theme": "Fund Operations", "title": "NAV errors: case mastered in 27; shareholder impact and remediation stay in 13",
     "domains": ["27", "13", "06"],
     "issue": "13 Servicing Error (ERR-) has a type 'NAV Error' and the attributes NAV Error Magnitude and Materiality Threshold Exceeded Indicator; 06 has Correction Reason 'NAV Error'. The fund-level error (published vs corrected NAV by class and date, fund loss, reimbursing party) has no owner.",
     "resolution": "27 masters NAV Error Case (NEC-) and NAV Error Impact (case x share class x valuation date). 13 Servicing Error adds 'Related NAV Error Case' (Reference NEC-) and its NAV Error Magnitude and Materiality Threshold Exceeded Indicator become Derived copies of 27. 13 keeps accounts impacted and Shareholder Remediation (RMD-); 06 keeps correction transactions; 29 As-Of Order Detail references NEC-.",
     "rationale": "The NAV error is a fund accounting fact governed by the board-approved error policy (US) and COLL / CSSF rules (UK / EU); its servicing consequences are 13's.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Fund Accounting"},

    {"id": "CD-190", "theme": "Fund Operations", "title": "Swing pricing: mechanism and maximum in 01, operating parameters and daily decisions in 27",
     "domains": ["01", "27", "29"],
     "issue": "01 Investor Transaction Charge holds Anti-Dilution Mechanism and Maximum Swing Factor, and Valuation Terms holds Pricing Model. Swing thresholds, the factor applied and the daily decision have no owner. US swing pricing is optional under Rule 22c-1(a)(3); the SEC's 2022 mandatory swing pricing proposal was not adopted.",
     "resolution": "01 keeps the prospectus mechanism and maximum. 27 masters Swing Pricing Parameter (fund x effective period) and Swing Pricing Decision (SWG-, fund x valuation date), using the net capital activity estimate from 29 orders. Dilution levies on UK dual-priced funds are recorded on the same decision.",
     "rationale": "Terms are product disclosures; thresholds and daily decisions are operated by fund accounting under a pricing committee.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Low", "owner_role": "Head of Fund Accounting"},

    {"id": "CD-191", "theme": "Tax", "title": "Fund tax calculations in 27 under the CD-149 split; RIC qualification status in 35; corporate tax in 19",
     "domains": ["27", "35", "19", "13"],
     "issue": "CD-149 keeps tax split by producer pending a client decision. Fund tax (taxable income, book-tax differences, excise distribution requirement, RIC asset and income tests, distribution character) needs a home; plan §3 gives 'RIC qualification' to 35.",
     "resolution": "27 masters Fund Tax Year Record (FTAX-), Book-Tax Difference and RIC Test Result; 35 records the RIC qualification status and filings; 13 Tax Form Record reads distribution character from 27. If the client creates a Tax domain, the 27 Fund Tax family moves unchanged with FTAX-, as the 19 Corporate Tax family would with TAXR-.",
     "rationale": "Fund tax is computed from the fund books; qualification is a governance determination.",
     "action": "SME decision", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Fund Tax"},

    {"id": "CD-192", "theme": "Fund Operations", "title": "Distributions: policy in 01, declaration and character in 27, reinvestment in 06, tax forms in 13, election in 15",
     "domains": ["01", "27", "06", "13", "15", "16"],
     "issue": "01 Income Distribution holds policy, frequency and payment method; 06 has Reinvestment transactions and Reinvested Distributions; 13 reports distributions on tax forms; 15 Account Standing Instruction holds the distribution option; 16 uses 'Distribution' for plan payouts. The declaration itself has no owner.",
     "resolution": "27 masters Distribution Declaration (DVD-: share class x distribution type x ex-date) with Distribution Character, and Distributable Income Estimate. 06, 13 and 15 reference DVD- where they need the declaration. 'Distribution' is logged as a term conflict (27 declaration, 30 private fund distribution PDIS-, 16 distribution request DIST-, 05 distribution agreement).",
     "rationale": "The declaration is a fund accounting and fund tax output approved by the board; its downstream uses are servicing and attribution.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Fund Accounting"},

    {"id": "CD-193", "theme": "Fund Operations", "title": "CIT unit values and insurance-dedicated fund NAVs are 27 Share Class NAV rows; delivery is 12",
     "domains": ["27", "12", "01"],
     "issue": "Plan §3 names CIT unit values and NAVs reported to insurers as 27 scope, and the business-line scope check asks where NAV and holdings reporting to insurers sits (27, 12).",
     "resolution": "A CIT unit value is a Share Class NAV of a 01 CIT unit class, with a CIT Unit Value Detail attribute group (12 CFR 9.18). Insurance-dedicated fund NAVs are Share Class NAV rows disseminated through NAV Dissemination to the insurer recipient. Holdings and NAV report packages to insurers are 12 Report Definitions and Runs.",
     "rationale": "One NAV object for every pooled vehicle avoids a second unit value master; presentation stays in 12.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Low", "owner_role": "Head of Fund Accounting"},

    # ===================================== 28 Custody & Asset Servicing =====================================
    {"id": "CD-194", "theme": "Fund Operations", "title": "Custody (safekeeping) accounts: mastered in 28, not 15; option A (12 CUA- references 28) or option B (CUA- moves to 28)",
     "domains": ["28", "12", "15", "18"],
     "issue": "Plan §3 row 28 asks whether custody accounts belong in 15 Account or 28. 12 holds Custody Account (CUA-) as the mandate custody set-up (custodian, BIC, safekeeping account number), CD-013. 18 Portfolio carries 'Safekeeping Custody Account' (Reference CUA-) and Cash Balance carries 'Cash Account Number' and 'Cash Custodian'. Fund custody accounts have no owner.",
     "resolution": "Custody accounts are not 15 accounts: 15 ACC- is the investor's account with the firm or its funds; a safekeeping account is an account at a custodian. Recommended option A: 28 masters every safekeeping and custody cash account (Safekeeping Account, SKA-) for funds, portfolios and client mandates, with Safekeeping Account Assignment to PRD-, PORT- or ACC-; 12 keeps CUA- as the mandate set-up workflow record and references the SKA- it caused to be created. Option B: 12 Custody Account moves to 28 with object and attribute names unchanged and CUA- becomes 28's prefix for mandate accounts, beside fund accounts. Either way 18 Safekeeping Custody Account, Cash Account Number and Cash Custodian are re-pointed to 28 at consolidation.",
     "rationale": "Mirrors the CD-155 recommendation for SSIs: one operational master, with the onboarding workflow referencing it.",
     "action": "SME decision", "status": "Proposed", "priority": "High", "owner_role": "Head of Investment Operations"},

    {"id": "CD-195", "theme": "Fund Operations", "title": "Corporate actions: event in 17, entitlement, election and payment in 28, booking in 18, investee proxy voting in 34",
     "domains": ["17", "28", "18", "24", "34", "13"],
     "issue": "17 masters Corporate Action Event (CAE-) and Corporate Action Option as reference. Entitlements per account, elections and payments have no owner; voluntary decisions may be recorded by portfolio managers (24).",
     "resolution": "28 masters Corporate Action Notification Receipt, Corporate Action Entitlement (CAEN-: CAE- x safekeeping account), Corporate Action Election (CAEL-) and Corporate Action Payment. Event dates, types and option terms are read from 17. The position effect is an 18 Portfolio Transaction. The voluntary decision references the 24 Investment Decision where 24 records it (confirm against the 24 brief). Investee meetings and votes are 34; own-fund proxy is 13 PRX-. 28 proposes 02 Party Role Type values Sub-Custodian, Central Securities Depository, Agent Lender and Securities Borrower.",
     "rationale": "Separates announcement golden copy (security master) from per-account processing (asset servicing), as ISO 20022 seev separates notification from instruction and confirmation.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Asset Servicing"},

    {"id": "CD-196", "theme": "Transactions & Measures", "title": "Reconciliations are mastered by the producing domain (06, 27, 28, 29) on the shared Reconciliation Status list",
     "domains": ["06", "27", "28", "29", "18"],
     "issue": "06 holds Reconciliation (RCN-) and Break (BRK-) for distribution data, including a type 'TA vs Fund Accounting'. 28 needs custody reconciliations (IBOR and ABOR vs custodian, cash, CASS external), 29 a capital stock proof, 27 NAV control checks. One generic reconciliation object would mix four stewards.",
     "resolution": "Keep one reconciliation record per producing function: 06 Reconciliation (distribution data), 27 NAV Control Check, 28 Custody Reconciliation Run (CREC-, breaks keyed CREC-n-Bnn), 29 TA Control Check (TAC-). All use the shared Reconciliation Status list. 'Reconciliation' is logged as a term conflict; 06 'TA vs Fund Accounting' is restated as an AUM data check, distinct from the 29 capital stock proof.",
     "rationale": "Each control has a different owner, frequency and regulatory basis; a shared status keeps them comparable without merging ownership.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Investment Operations"},

    {"id": "CD-197", "theme": "Compliance", "title": "Client assets and client money (UK CASS) records in 28; CASS policy, oversight and audit in 38",
     "domains": ["28", "38", "09", "15", "12"],
     "issue": "Plan §3 names client assets and client money as an explicit 28 family and gives the rules to 38. No domain holds CASS records; 09 holds entity authorizations.",
     "resolution": "28 masters Client Money Calculation (CMC-), CASS Acknowledgment Letter, Client Asset Designation on the safekeeping account, CASS external reconciliations (as a CREC- type) and a CASS Firm Profile keyed by 09 LEN-. 09 Entity Authorization stays the authorization record. 38 (Stage 4) will master the CASS policy, the CASS resolution pack governance and CASS audit, referencing 28 records.",
     "rationale": "Records are produced by operations daily; rules and assurance are compliance's.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "CASS Operational Oversight Officer"},

    {"id": "CD-198", "theme": "Fund Operations", "title": "Securities lending in 28; OTC and margin collateral in 26; lending permission in 01; cash collateral reinvestment in 18",
     "domains": ["28", "26", "01", "18", "27"],
     "issue": "01 holds Securities Lending Permitted Indicator. 26 (Stage 2) masters margin and collateral for OTC derivatives. Lending programs, loans, collateral received and revenue splits have no owner.",
     "resolution": "28 masters Securities Lending Program, Securities Loan (SBL-), Lending Collateral Received, Lending Revenue Allocation and Loan Regulatory Report (SEC Rule 10c-1a, compliance deferred to 2028; SFTR). 26 keeps OTC, margin and repo collateral (confirm against the 26 brief). Cash collateral reinvestment vehicles are 18 portfolios; lending income is booked in 27.",
     "rationale": "Lending is run through the custodian or an agent lender and serviced by asset servicing, a different process from derivatives collateral management.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Low", "owner_role": "Head of Asset Servicing"},

    # ===================================== 29 Transfer Agency Operations =====================================
    {"id": "CD-199", "theme": "Transactions & Measures", "title": "Fund order (29) vs confirmed transaction (06) vs servicing request (13) vs account instruction (15)",
     "domains": ["29", "06", "13", "15"],
     "issue": "06 Transaction (TXN-) holds the processed shareholder transaction from the attribution lens, with Order Source attributes (Order Entry Channel, Order Message Type). 13 Service Request (SRQ-) holds requests with 'Resulting Transaction'. 15 holds standing instructions (SIN-) that generate systematic orders. The operational order (receipt timestamp under Rule 22c-1, cut-off, good order, settlement) has no owner (plan §3 row 29).",
     "resolution": "29 masters Fund Order (TAO-), its events, exceptions, routing detail and settlement. Chain: a 13 servicing request (what the shareholder asked for and how it was handled) may create a 29 fund order (the dealing instruction as received and processed), which results in a 06 transaction (the confirmed dealing for attribution and AUM). 29 references SRQ- (Originating Service Request), SIN- (Originating Standing Instruction) and TXN- (Resulting Transaction); executed units, price and amounts stay in 06. Proposed changes to 01-16 (not applied): 13 Service Request adds 'Resulting Order' (Reference TAO-); 06 Transaction adds 'Originating Fund Order' (Reference TAO-) and flags Order Entry Channel and Order Message Type as Derived copy (29) for TA-sourced rows.",
     "rationale": "Each record has a different steward and purpose (servicing, operations, distribution reporting); linking them by reference keeps each fact once.",
     "action": "SME decision", "status": "Proposed", "priority": "High", "owner_role": "Head of Transfer Agency"},

    {"id": "CD-200", "theme": "Transactions & Measures", "title": "ETF primary market: basket construction in 24, AP order processing in 29, creation / redemption transaction in 06, AP agreement in 05",
     "domains": ["24", "29", "06", "05", "02", "01", "26"],
     "issue": "06 holds ETF Creation / Redemption (Authorized Participant, Creation Units, Basket Type) as a transaction; 01 Product Party Role Type has 'Authorized Participant' but 02 Party Role Type does not; plan §3 gives basket construction to 24 and AP order processing to 29.",
     "resolution": "24 masters the ETF creation / redemption basket (confirm the name against the 24 brief). 29 masters AP Creation / Redemption Order (ECR-), Basket Settlement Line and AP Order Fee. 06 keeps ETF Creation / Redemption; its Authorized Participant, Creation Units and Basket Type become Derived copies (29) for orders the TA processed. 05 holds the AP agreement (add an Agreement Type value 'Authorized Participant Agreement' if missing). Propose 02 Party Role Type 'Authorized Participant'. DTC / CNS delivery of in-kind baskets is 26 Trade Settlement where 26 settles it.",
     "rationale": "Follows the business-line scope check for ETFs (plan §3) and keeps one owner per stage of the creation process.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Head of ETF Operations"},

    {"id": "CD-201", "theme": "Compliance", "title": "Retail CIP, AML transaction monitoring and fraud alerts on shareholder accounts in 29; party KYC state in 02; AML program and SARs in 38",
     "domains": ["29", "02", "38", "08", "15"],
     "issue": "02 KYC Profile holds AML Risk Rating, PEP Status and Sanctions Screening Result for a party; 08 holds Frequent Trading Case (FTC-); 15 holds Account Restriction (ARX-). Customer identification verification for TA-opened accounts (31 CFR 1024.220) and transaction-level monitoring have no owner (plan §3 rows 29 and 38).",
     "resolution": "29 masters CIP Verification (CIP-), Account Monitoring Alert (AMA-: AML, sanctions and fraud categories) and Alert Disposition. 02 KYC Profile remains the party-level KYC state; 29 never stores a party risk rating. 15 Account Restriction is the freeze or block an alert may cause (referenced). 08 Frequent Trading Case stays in 08. SAR decisions, filing and the AML program are 38 (Stage 4); until then 29 holds an escalation case reference as an Identifier.",
     "rationale": "Monitoring runs on the TA's transaction data and is staffed by TA operations; the program and regulatory reporting belong to compliance.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "AML Officer"},

    {"id": "CD-202", "theme": "Fund Operations", "title": "Dealer set-up stays in 05, rep codes in 02, outsourced-TA oversight in 13; 29 holds only daily TA control results",
     "domains": ["29", "05", "02", "13"],
     "issue": "Plan §3 lists 'dealer and rep operational set-up as used by the TA' and 'oversight of an outsourced TA' under 29, but 05 Partner Dealer Setup, Trading Setup and Networking Setup already hold dealer set-up, 02 holds TA Dealer Number and rep codes (CD-003, CD-004), and 13 TA Oversight & Servicing Quality holds Servicing Provider Engagement, Service Level Definition (SVL-) and Servicing Error (ERR-).",
     "resolution": "No object moves. 29 has no dealer, branch or rep object; orders carry the dealer and rep as delivered and the resolved PTY-. 13 remains the oversight record of an outsourced TA. 29 masters TA Control Check (TAC-) and TA Control Exception, the daily operational controls (capital stock proof, cash proof, unprocessed items, as-of dilution).",
     "rationale": "Avoids a second dealer master and a second provider-oversight record; the plan's wording is satisfied by reference.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Transfer Agency"},

    # ===================================== 30 Private Markets =====================================
    {"id": "CD-203", "theme": "Enterprise Structure", "title": "Investor Capital Account (30) is the third kind of position; investor commitments are held on a 15 account",
     "domains": ["30", "15", "06", "18", "02"],
     "issue": "CD-146 names the Investor Capital Account (30) as a third concept beside Shareholder Position (06 POS-) and Portfolio Holding (18 HLD-). Plan §3 asks for the investor commitment as an account type in 15 referencing 30. 15 Account Type has no private fund value; 18 Fund Interest Holding Detail models the firm as LP in other funds.",
     "resolution": "30 masters Investor Commitment (ICMT-: investor account ACC- x fund x investor class) and Investor Capital Account (CAPA-: commitment x reporting period), never keyed by units and NAV. 'Position' is not used bare in 30. Propose (not applied) a 15 Account Type value 'Private Fund Investor Account'. When an own portfolio invests in an own private fund, 18 holds the Portfolio Holding and 30 the commitment and capital account on the portfolio's account; 18 Fund Interest Holding Detail values and 17 Fund Interest Terms are Derived copies (30) for own private funds (row rule). Add 'Investor Capital Account' to the CD-146 term conflict.",
     "rationale": "Completes CD-146 and the private markets scope check; the account stays in 15 as for every other investor.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Head of Private Markets Operations"},

    {"id": "CD-204", "theme": "Transactions & Measures", "title": "Private fund cash flows (commitments, calls, distributions, equalization) are mastered in 30 and kept out of 06 flow measures",
     "domains": ["30", "06", "21", "11", "29"],
     "issue": "06 Flow Measures (gross sales, redemptions, net flows) and Asset Measures are open-end measures. Counting capital calls as sales or distributions as redemptions would distort flows (plan §3 scope check: kept out or flagged).",
     "resolution": "Capital Call (CCN-), Distribution (PDIS-), their allocations and Equalization are mastered in 30 and never loaded as 06 Transactions or Positions. 06 Flow Treatment Rule records an explicit exclusion for Vehicle Type 'Private Fund (Drawdown)' (proposed, not applied). Private fund fundraising measures (commitments raised, capital called, distributions, net invested capital) are defined as 21 Metric Definitions (KPI-) sourced from 30. Evergreen private funds with periodic subscriptions and redemptions: recommended to follow the open-end model (29 orders, 06 transactions) while keeping capital accounts in 30 where the vehicle is a partnership; SME decision.",
     "rationale": "Keeps 06 flows comparable with industry flow data while giving distribution a governed view of private fund fundraising.",
     "action": "SME decision", "status": "Proposed", "priority": "High", "owner_role": "Head of Distribution Data"},

    {"id": "CD-205", "theme": "Product", "title": "Private fund structure and investor economics in 30: fund in 01, GP entities in 09, SPVs in 02, waterfall and carry in 30, carry awards in 20, values in 22, books in 27",
     "domains": ["30", "01", "09", "02", "20", "22", "24", "27", "05", "12", "13"],
     "issue": "01 models the private fund as an Investment Product (Vehicle Type 'Private Fund (Drawdown)', 'Evergreen Private Fund') with Management Fee and Performance Fee terms; 09 holds internal legal entities; 20 holds Variable Compensation Award (VPA-, including carry); 05 placement agent agreements; 12 ILPA Template Adoption; plan §3 gives fair value to 22 and fund accounting to 27. The fund's structure, closes, waterfall and carry have no owner.",
     "resolution": "The fund and its investor classes stay 01 PRD- / SHC-. 30 masters Private Fund Profile (keyed by PRD-), Fund Close (FCL-), Fund Structure Link (to PRD- feeders, parallels and AIVs, PTY- SPVs and blockers, LEN- GP entities), Distribution Waterfall Terms, Waterfall Calculation (DWF-), Carried Interest Position, Deal (PDL-), Portfolio Company Profile (keyed by PTY-), Private Investment and Fund Credit Facility (FCF-). Carried interest is not a 01 Performance Fee. Employee carry points are 20 VPA-. Fair values and the valuation committee are 22; the investment committee decision is 24 (confirm names against the 22 and 24 briefs); fund ledgers 27; placement agreements 05; ILPA report presentation and delivery 12; K-1 delivery 13 (add 'Schedule K-1' to 13 Investor Tax Document Type), with Partner Tax Allocation in 30 under CD-149. Propose 02 Party Role Type values Limited Partner Investor, Fund Lender, Placement Agent and Fund Holding Vehicle.",
     "rationale": "Private markets operations steward the structure and investor economics; each neighbor keeps the facts it already produces.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Head of Private Markets Operations"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. PREFIXES (reserved by the briefs; registered at Stage 2 consolidation)
# ---------------------------------------------------------------------------------------------------------------------

PREFIXES = [
    # ---- 27 Fund Accounting & Valuation
    ("NAV-", "Share class NAV record (share class x valuation date x NAV version)", "27", "Reserved", "Stage 2 brief (CD-187). Text labels 'NAV-to-NAV' (01), 'NAV-Accrued' (10) and 'NAV-error' (13) are not IDs; examples must be NAV- plus digits."),
    ("FJNL-", "Fund journal entry", "27", "Reserved", "Stage 2 brief (CD-186). Deliberately related to JNL- (19) but owned by 27, like PTXN- / TXN-."),
    ("DVD-", "Fund distribution declaration (share class x distribution type x ex-date)", "27", "Reserved", "Stage 2 brief (CD-192). Not DIST- (16), DSET- (14) or DSP- (07)."),
    ("NEC-", "NAV error case", "27", "Reserved", "Stage 2 brief (CD-189). Referenced by 13 ERR-; NAVE- rejected as confusable with NAV-."),
    ("SWG-", "Swing pricing decision (fund x valuation date)", "27", "Reserved", "Stage 2 brief (CD-190). Not SVL- / SVR- (12, 13) or SNP- (06)."),
    ("FTAX-", "Fund tax year record", "27", "Reserved", "Stage 2 brief (CD-191). Moves with the Fund Tax family if a Tax domain is created (CD-149). Not TAXR- (19)."),
    # ---- 28 Custody & Asset Servicing
    ("SKA-", "Safekeeping account (securities, cash or collateral account at a custodian or sub-custodian)", "28", "Reserved", "Stage 2 brief (CD-194, option A). Not CUA- (12 custody set-up), SIN- (15) or SSI- (12)."),
    ("CREC-", "Custody reconciliation run (breaks keyed CREC-n-Bnn)", "28", "Reserved", "Stage 2 brief (CD-196). Deliberately related to RCN- (06) but owned by 28; not CRR-/CRA-/CRV-/CRX-."),
    ("CAEN-", "Corporate action entitlement (event x safekeeping account)", "28", "Reserved", "Stage 2 brief (CD-195). Same family as CAE- (17 event)."),
    ("CAEL-", "Corporate action election (entitlement x option x instruction)", "28", "Reserved", "Stage 2 brief (CD-195). Same family as CAE- and CAEN-."),
    ("WHTR-", "Withholding tax reclaim", "28", "Reserved", "Stage 2 brief (CD-149 split). Not RCL- (13), TAXR- (19) or WVR- (10)."),
    ("SCA-", "Securities class action claim", "28", "Reserved", "Stage 2 brief. CLA- rejected (CLR-/CLV-/CLM- of 09)."),
    ("SBL-", "Securities loan (securities lending)", "28", "Reserved", "Stage 2 brief (CD-198). Not SLA- (12) or SLT- (03)."),
    ("CMC-", "Client money calculation (UK CASS)", "28", "Reserved", "Stage 2 brief (CD-197). Not CMP- or CMT- (01)."),
    # ---- 29 Transfer Agency Operations
    ("TAO-", "Fund order (transfer agency order as received and processed)", "29", "Reserved", "Stage 2 brief (CD-199). ORD- is left to 25 trade orders; not TXN- (06)."),
    ("TAS-", "Intermediary settlement batch (settling party x settlement date x currency)", "29", "Reserved", "Stage 2 brief. SETL- is left to 26."),
    ("ECR-", "ETF authorized participant creation / redemption order", "29", "Reserved", "Stage 2 brief (CD-200). APO- rejected (one letter from APV-, 19); basket prefixes left to 24."),
    ("CIP-", "Customer identification program verification", "29", "Reserved", "Stage 2 brief (CD-201). Not CPL- (08) or CPS- (07)."),
    ("AMA-", "Account monitoring alert (AML, sanctions, fraud)", "29", "Reserved", "Stage 2 brief (CD-201). TMA- rejected (one letter from TMD-, 07); SAR filing is 38's."),
    ("TAC-", "TA control check (control type x share class x business date)", "29", "Reserved", "Stage 2 brief (CD-196, CD-202). Transposed letters of TCA- (a natural 25 choice); not CTL- (07)."),
    # ---- 30 Private Markets
    ("ICMT-", "Investor commitment to a private fund", "30", "Reserved", "Stage 2 brief (CD-203). Not CMT- (01), ICP- (07), ICA- / ICC- (10) or ICS- (09)."),
    ("CAPA-", "Investor capital account (commitment x reporting period)", "30", "Reserved", "Stage 2 brief (CD-146, CD-203). ICA- (10) and PCA- / CPA- rejected."),
    ("CCN-", "Capital call (fund x call number)", "30", "Reserved", "Stage 2 brief (CD-204). Not CCI- (13), CCA- (10) or CFN- (12); CALL- rejected (reads as CAL-, 09)."),
    ("PDIS-", "Private fund distribution (fund x distribution number)", "30", "Reserved", "Stage 2 brief (CD-204). Not DIST- (16) or DVD- (27)."),
    ("PDL-", "Private markets deal (pipeline opportunity)", "30", "Reserved", "Stage 2 brief (CD-205). DEAL- rejected as a natural trading or FX choice for 25 / 26; not PDOC- (16)."),
    ("FCF-", "Fund credit facility (subscription line, NAV facility)", "30", "Reserved", "Stage 2 brief (CD-205). Not FCS- (03)."),
    ("DWF-", "Distribution waterfall calculation", "30", "Reserved", "Stage 2 brief (CD-205). WFC- rejected (09 family code SR-WFC appears in IDs); WFL- rejected (WFP-, 20)."),
    ("FCL-", "Private fund close (fund x close number)", "30", "Reserved", "Stage 2 brief (CD-205). Not FCS- (03) or FCF-; PFC- rejected (PF* family of 11 and 16)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. TERM_CONFLICTS (for the Stage 2 consolidation)
# ---------------------------------------------------------------------------------------------------------------------

TERM_CONFLICTS = [
    {"term": "NAV",
     "usages": [("27", "Share Class NAV", "Official per-share value struck by fund accounting"),
                ("18", "Portfolio Valuation Summary", "IBOR total market value; an investment estimate, not NAV"),
                ("06", "Asset Measures", "AUM measures; not NAV"),
                ("01", "Listing (iNAV Ticker)", "Indicative intraday value of an ETF; not NAV")],
     "recommendation": "Reserve 'NAV' for the 27 official value. Other domains use 'IBOR Market Value', 'AUM' or 'Indicative NAV (iNAV)'."},
    {"term": "Distribution",
     "usages": [("27", "Distribution Declaration", "Income or capital gain distribution declared by an open-end fund"),
                ("30", "Distribution", "Private fund distribution to investors under the waterfall"),
                ("16", "Distribution Request", "Retirement plan payout to a participant"),
                ("05", "Distribution Agreement", "Selling agreement with a distributor")],
     "recommendation": "Qualify every use: Fund Distribution Declaration (27), Private Fund Distribution (30), Plan Distribution (16), Distribution Agreement (05)."},
    {"term": "Order",
     "usages": [("29", "Fund Order", "Shareholder order to deal in a share class, processed by the TA"),
                ("25", "Order (expected name)", "Trade order in an instrument placed by a portfolio manager")],
     "recommendation": "Use 'Fund Order' (29) and 'Trade Order' (25); never 'Order' bare. Confirm the 25 name against the 25 brief."},
    {"term": "Reconciliation",
     "usages": [("06", "Reconciliation", "Distribution data reconciliation (feeds, TA vs fund accounting AUM check)"),
                ("27", "NAV Control Check", "NAV and capital stock checks"),
                ("28", "Custody Reconciliation Run", "IBOR / ABOR vs custodian positions and cash"),
                ("29", "TA Control Check", "Capital stock and cash proof")],
     "recommendation": "Keep per producer (CD-196) on the shared Reconciliation Status list; qualify names by function."},
    {"term": "Custody Account",
     "usages": [("12", "Custody Account", "Mandate custody set-up record (CUA-)"),
                ("28", "Safekeeping Account", "Account at a custodian holding a fund's or client's assets (SKA-)"),
                ("15", "Account", "Investor account with the firm; never a custody account")],
     "recommendation": "Resolve through CD-194; the enterprise term is Safekeeping Account."},
    {"term": "Commitment",
     "usages": [("30", "Investor Commitment", "Investor's commitment to an own private fund"),
                ("18", "Fund Interest Holding Detail (Commitment Amount)", "Firm portfolio's commitment to an underlying fund"),
                ("05", "Program Membership (Annual Commitment Amount)", "Partner program funding commitment")],
     "recommendation": "Use 'Investor Commitment' (30) and 'Fund Interest Commitment' (18); 05 keeps its program term."},
]
