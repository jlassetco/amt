"""Decision proposals for the enterprise expansion, Stage 3, investment oversight (Data Domains 31-33).

Format: identical to decisions.py (see CONTRACT.md in this folder). This file is a proposal fragment: the builder does not
read it, and nothing here changes a content module. The Stage 3 consolidation step (Enterprise_Expansion_Plan.md §9.3
step 5) merges accepted entries into decisions.py.

Sources: Enterprise_Expansion_Plan.md §3, §4 and §9; Domain_Ownership_and_Conventions.md §2, §8, §13, §14, §15;
stage2_consolidation_notes.md; the Phase A briefs 31-33 in 00_Program/Expansion/Briefs/; a scan of content_01, 02, 11,
12, 13, 15, 16, 17, 18, 22, 23, 24, 25, 26, 27 and 30 on 2026-10-06; Business_Capability_Map content (C-05.01 to C-05.08).

IDs CD-211 to CD-225 are reserved for this fragment (Stage 3 briefs, investment oversight). The product governance briefs
(34-36) use their own range. Every entry has status "Proposed"; where the business must choose, action is
"SME decision" and the resolution gives the recommended option. Objects of 34, 35 and 36 are named as "(name set by the
NN brief)" until those briefs publish their names; the consolidation aligns them.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. DECISIONS
# ---------------------------------------------------------------------------------------------------------------------

DECISIONS = [
    # ===================================== 31 Investment Risk =====================================
    {"id": "CD-211", "theme": "Investment Risk", "title": "Risk measures and exposures are mastered in 31; vendor instrument analytics stay in 22, holding exposure in 18, optimizer estimates in 24, ex-post statistics in 32",
     "domains": ["31", "22", "18", "24", "32", "17"],
     "issue": "22 Pricing Analytics Observation holds vendor yield, spread, duration, convexity and option delta per instrument. 18 Derivative Holding Detail holds Delta-Adjusted Exposure Base (N-PORT). 24 Rebalance Portfolio Result holds Pre-Trade and Post-Trade Tracking Error, and 24 Rebalance Run holds 'Risk Model Used' as text. 32 will compute realized statistics (standard deviation, ex-post tracking error, Sharpe). Without a rule, tracking error and duration would have up to four homes.",
     "resolution": "31 masters model outputs and portfolio aggregates: Risk Model, Risk Factor, Instrument Factor Exposure, Risk Calculation Run, Portfolio Risk Measure (ex-ante tracking error, volatility, VaR, expected shortfall, beta), Risk Decomposition, Portfolio Exposure, VaR Back-Test. Per-instrument published analytics stay 22 and are read, never stored as 31 values. 18 Delta-Adjusted Exposure Base stays mastered in 18. 24 Pre- and Post-Trade Tracking Error stay mastered in 24 as optimizer estimates for a proposal, distinct from the 31 measure of the held book. At consolidation 24 Rebalance Run 'Risk Model Used' is re-typed Reference (Risk Model, 31). Ex-post statistics from realized returns are 32 Ex-Post Risk Statistic; attribute names say 'Ex-Ante' or 'Ex-Post' wherever both could apply.",
     "rationale": "Separates observation (22), book (18), intent (24), forecast (31) and realized result (32), each with its own producer.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Head of Investment Risk"},

    {"id": "CD-212", "theme": "Investment Risk", "title": "01 SRI and SRRI become Derived copies of the 31 Product Risk Indicator Calculation; PRIIPs performance scenarios in 31",
     "domains": ["31", "01", "32", "13"],
     "issue": "01 Product Risk Indicator holds Summary Risk Indicator (SRI) and SRRI as mastered values with no calculation (market risk class, credit risk class, volatility band) behind them. PRIIPs performance scenarios (stress, unfavorable, moderate, favorable) have no home. Past performance belongs to 32.",
     "resolution": "31 masters Product Risk Indicator Calculation (share class x indicator type x calculation date: MRM class from VaR-equivalent volatility, CRM class, resulting SRI; SRRI volatility band) and PRIIPs Performance Scenario. At consolidation 01 'Summary Risk Indicator (SRI)' and 'SRRI' are re-noted Derived copy (31) of the latest approved calculation. 01 'Global Exposure Method' and 'Local Regulatory Risk Rating' stay 01 as declared values. SME decision on who produces scenarios (risk, product data or vendor); recommended 31.",
     "rationale": "The disclosed indicator is a product fact; its calculation is a risk measurement with inputs and history that must be evidenced.",
     "action": "SME decision", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Investment Risk"},

    {"id": "CD-213", "theme": "Investment Risk", "title": "Liquidity classification and liquidity risk program results (SEC Rule 22e-4, UCITS / AIFMD, ESMA LST) are mastered in 31; 35 files them",
     "domains": ["31", "35", "22", "01", "29"],
     "issue": "Rule 22e-4 requires each fund to classify each investment at least monthly into four liquidity categories, set a highly liquid investment minimum (HLIM), limit illiquid investments to 15% and report shortfalls and exceedances to the board and on Form N-RN (formerly N-LIQUID). N-PORT carries the classification. ESMA34-39-897 requires liquidity stress tests for UCITS and AIFs; Annex IV and Form PF carry liquidity buckets. 22 ETF Market Statistic holds bid-ask spreads (CD-206). 01 Liquidity Profile is the dealing liquidity offered to investors.",
     "resolution": "31 masters Liquidity Classification (portfolio x instrument x date x portion), Highly Liquid Investment Minimum, Fund Liquidity Profile, Liquidity Horizon Bucket, liquidity Stress Test Results and the Risk Program Designation (program administrator, in-kind ETF exemption). 35 Fund Governance & Regulatory Reporting files N-PORT, N-RN, N-CEN, Form PF and Annex IV by referencing these objects (names set by the 35 brief) and holds filing status and board approvals; 31 holds none. 22 ETF Market Statistic stays 22 and is read. 01 Liquidity Profile and dealing terms are unchanged.",
     "rationale": "Program results come from the program administrator in the risk function; filing is a fund governance process.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Liquidity Risk Management Program Administrator"},

    {"id": "CD-214", "theme": "Investment Risk", "title": "Derivatives risk (SEC Rule 18f-4), UCITS global exposure and AIFMD leverage are measured in 31",
     "domains": ["31", "35", "01", "33", "18"],
     "issue": "Rule 18f-4 requires a derivatives risk management program, a derivatives risk manager, a relative VaR test against a designated reference portfolio (200%, 250% for closed-end funds) or an absolute test (20% / 25%), weekly stress tests and back-tests, and an exception for limited derivatives users (10% derivatives exposure). CESR/10-788 sets UCITS commitment and VaR methods. Delegated Regulation 231/2013 Arts 6-11 set AIFMD gross and commitment leverage. 01 holds Global Exposure Method, Leverage Calculation Method and Maximum Leverage as declared terms.",
     "resolution": "31 masters Designated Reference Portfolio, VaR Test Result (regime 18f-4, UCITS relative, UCITS absolute) and Leverage & Exposure Measurement (UCITS commitment, AIFMD gross, AIFMD commitment, 18f-4 derivatives exposure). The statutory VaR test limits are 31 Risk Limits (RLMT-) referenced by each VaR Test Result. AIFMD leverage caps in fund documents (01 Maximum Leverage) and AIFMD II loan-origination leverage limits are 33 Compliance Rules that read the 31 measurement (CD-223). 35 files N-PORT, N-RN Parts E-G and Annex IV from 31.",
     "rationale": "One measurement, many readers; the limit owner follows CD-223.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Derivatives Risk Manager"},

    {"id": "CD-215", "theme": "Investment Risk", "title": "Counterparty exposure measured in 31 against 25 Counterparty Trading Limits and with 26 collateral",
     "domains": ["31", "25", "26", "33", "02"],
     "issue": "CD-179 gives 25 the approved counterparty profile and Counterparty Trading Limit and says exposure measurement is 31. 26 masters Trading Agreement (TAGR-), Collateral Balance and Initial Margin Calculation (SIMM). UCITS Art 52(1) also limits OTC counterparty exposure to 5% / 10% of net assets.",
     "resolution": "31 masters Counterparty Exposure (counterparty PTY- x portfolio x netting set TAGR- x date: mark-to-market, collateral held as Derived copy (26) of Collateral Balance, net exposure, PFE) with a reference to the applicable 25 Counterparty Trading Limit. Utilization of a 25 limit is a 31 Risk Limit Utilization row and its exceedance a 31 Risk Limit Exceedance (RLEX-), because 25 has no exceedance record. The UCITS Art 52 counterparty limit is a 33 Compliance Rule reading Counterparty Exposure. 26 Initial Margin Calculation and Margin Call Exposure Amount stay 26.",
     "rationale": "Completes CD-179 without giving 25 a monitoring role or 26 a risk role.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Investment Risk"},

    {"id": "CD-216", "theme": "Investment Risk", "title": "ESG-related risk: 34 masters ESG and climate data, 31 masters climate stress scenarios and results; risk models reference the 37 model inventory",
     "domains": ["31", "34", "37", "24", "21"],
     "issue": "34 Stewardship & Sustainable Investing will master ESG data and scores, SFDR principal adverse impacts and climate metrics. Climate scenario analysis (NGFS scenarios, transition and physical risk shocks) produces risk measures. Plan §3 puts Model Risk Management (inventory, validation, tiering) in 37 (Stage 4).",
     "resolution": "34 masters ESG and climate metric observations (names set by the 34 brief); 31 masters climate Stress Scenarios, their shocks and Stress Test Results, reading 34 metrics by reference and never copying them. Sustainability risk as a factor in a risk model is a 31 Risk Factor. 31 Risk Model carries 'Model Inventory Reference' as text with Notes 'future owner 37' until 37 exists; the same applies to 32 attribution models and 24 optimizers.",
     "rationale": "Data about issuers (34) vs loss under a scenario (31); model governance stays independent of model users.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Investment Risk"},

    # ===================================== 32 Performance & Attribution =====================================
    {"id": "CD-217", "theme": "Performance", "title": "Official returns are mastered in 32; 12, 13, 11, 35 and data products read them; 27 Financial Highlights Total Return to be decided",
     "domains": ["32", "27", "12", "13", "11", "35", "08", "03", "10", "21"],
     "issue": "No domain masters returns. 27 Share Class NAV is the input for share class returns. 27 Financial Highlights holds 'Total Return' for the fiscal period. 11 Peer Metric Snapshot holds vendor-reported 'Total Return' for peer and own funds. 12 Presentation Profile chooses what is shown, 13 Tailored Shareholder Report publishes, 35 files N-PORT monthly returns, 10 and 12 compute performance fees.",
     "resolution": "32 masters Performance Return (RETURN-) for portfolios, share classes, accounts, composites and model portfolios, and Benchmark Return computed from 22 Index Level Observation and 01 Blend Components. Consumers reference RETURN-; any stored copy is a Derived copy naming the 32 record. 11 keeps vendor-reported returns as market intelligence (not the firm's return); glossary qualifier 'Published Peer Return'. SME decision on 27 Financial Highlights 'Total Return': option A (recommended) re-note as Derived copy (32) of the fiscal-period share class return; option B keep it mastered in 27 as the audited financial statement figure, with a 32 reconciliation check.",
     "rationale": "One official number per subject and period, with methodology and restatement history, read by every presenter.",
     "action": "SME decision", "status": "Proposed", "priority": "High", "owner_role": "Head of Performance Measurement"},

    {"id": "CD-218", "theme": "Performance", "title": "GIPS composite definition stays in 01; composite membership, composite statistics, GIPS firm and verification are mastered in 32",
     "domains": ["32", "01", "12", "18"],
     "issue": "01 GIPS Composite (CMP-) holds the definition, benchmark, minimum size and significant cash flow policy, plus 'Composite Member' (Reference Product / Mandate, effective-dated text). GIPS 2020 membership is by portfolio, changes over time and drives dispersion and composite assets. 12 GIPS Report Provision references CMP- and lists required disclosures.",
     "resolution": "32 masters Composite Membership (CMP- x PORT- x start date, exclusion reason), Composite Period Statistic, Significant Cash Flow Event, Carve-Out Allocation, GIPS Firm and GIPS Verification (GVER-). 01 keeps the composite definition fields. Option A (recommended): 01 'Composite Member' is re-noted Derived copy (32) as a summary of current members. Option B: retire it from 01. 12 GIPS Report Provision is unchanged and reads 32 statistics.",
     "rationale": "Definition is product reference data; membership is a performance-team control evidenced for verification.",
     "action": "SME decision", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Performance Measurement / GIPS Officer"},

    {"id": "CD-219", "theme": "Performance", "title": "Private markets IRR, multiples and PME are mastered in 32; 30 keeps cash flows, capital accounts and waterfall calculations",
     "domains": ["32", "30", "12", "35", "22", "27"],
     "issue": "30 masters capital calls (CCN-), distributions (PDIS-), investor capital accounts (CAPA-), commitments (ICMT-), realizations, credit facilities (FCF-) and waterfall calculations (DWF-), and holds no IRR or multiple. GIPS 2020 and the ILPA Performance Template (2025) require since-inception IRR and multiples, gross and net, with and without subscription facility.",
     "resolution": "32 masters Private Markets Performance Measure (fund, private investment or composite x date x fee basis x facility basis: IRR, TVPI, DPI, RVPI, PIC), Investor Performance Measure (ICMT- x date) and Public Market Equivalent. Inputs are referenced from 30, 22 (FVD-) and 27. A hurdle IRR computed inside a 30 Waterfall Calculation stays a 30 calculation value and is not a reported performance measure. Where the administrator calculates IRRs, 32 holds them as received and approved (data basis).",
     "rationale": "Plan §3 row 32; keeps investor economics (30) apart from performance measures (32).",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Performance Measurement"},

    {"id": "CD-220", "theme": "Performance", "title": "Account-level returns, including participant and direct shareholder personal rates of return",
     "domains": ["32", "15", "16", "13", "12"],
     "issue": "Plan §3 row 32 covers account-level returns. SMA and institutional account returns are core performance. Recordkept plan participants (15 Plan Participant Account, 16) and direct shareholders receive personal rates of return on statements (13); 16 has no return object today.",
     "resolution": "Option A (recommended): 32 Performance Return covers every 15 account, with a money-weighted methodology for participant and direct shareholder accounts; 13 statements and 16 participant disclosures reference it. Option B: personal rates of return are produced by the recordkeeping platform and mastered in 16, and 32 covers only SMA and institutional accounts. Investment option returns shown in DOL 404a-5 disclosures are 32 share class or unit class returns in both options.",
     "rationale": "One methodology owner for every published return; volume and platform location are the SME question.",
     "action": "SME decision", "status": "Proposed", "priority": "Low", "owner_role": "Head of Performance Measurement / Head of Retirement Recordkeeping"},

    # ===================================== 33 Investment Compliance =====================================
    {"id": "CD-221", "theme": "Investment Compliance", "title": "Coded compliance rules, rule libraries and pre- and post-trade checks are mastered in 33; restrictions originate in 01 and 02; 25 copies the check outcome",
     "domains": ["33", "01", "02", "15", "24", "25", "12", "30"],
     "issue": "01 Investment Restriction (RST-) and 02 Client Restriction (CRX-) hold restrictions as written. 15 Account Restriction (ARX-) holds stop-purchase blocks and freezes on shareholder accounts. 24 Portfolio Construction Constraint holds PM constraints. 25 Trade Order Event holds 'Compliance Check Outcome' as a copy with 'future owner 33' (CD-180). 12 Guideline Monitoring Arrangement lists monitored restrictions.",
     "resolution": "33 masters Regulatory Limit Provision, Rule Library, Compliance Rule (CRULE-, versioned), Rule Source Link, Rule Assignment, Rule Instrument List, Rule Coding Request, Restriction Coding Status, Compliance Check Run (CCHK-) with its Pre-Trade Check Subject, Compliance Rule Result, Compliance Alert (CALERT-) and Pre-Trade Override Approval. Rule sources are 01 RST-, 02 CRX- and regulatory provisions; 15 ARX- is not a rule source (it is enforced by 29). 24 constraints are not rules. Pre-trade checks run on 24 Proposed Trade, 25 Trade Order and Block Order, and 30 Deal. At consolidation 25 'Compliance Check Outcome' is flagged Derived copy (33) of the Pre-Trade Check Subject outcome; its list values become the 33 list 'Compliance Check Outcome' unchanged.",
     "rationale": "A coded rule is a separate, versioned artifact from the restriction text, and every test must cite the rule version in force.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Chief Compliance Officer / Head of Investment Compliance"},

    {"id": "CD-222", "theme": "Investment Compliance", "title": "Investment breaches are mastered in 33 (BREACH-); 12 Breach Notification and 35 board reporting reference them",
     "domains": ["33", "12", "35", "25", "27", "37"],
     "issue": "12 Breach Notification (GBN-) holds Breached Mandate, Breached Restriction, Breach Type, Breach Detected Date, Cure Action and Cure Date with no breach master. 25 Trade Error holds error gain or loss and reimbursement. 27 NAV Error Case (NEC-) holds NAV impacts. 35 will report breaches to fund boards; 37 (Stage 4) will hold operational incidents and loss events.",
     "resolution": "33 masters Investment Breach (BREACH-), Breach Remediation Action, Breach Loss Calculation and Breach Review. At consolidation 12 Breach Notification gains 'Related Investment Breach' (Reference Investment Breach, 33), and Breach Type, Breach Detected Date, Breached Restriction, Cure Action and Cure Date are re-noted Derived copy (33); 12 keeps the client notification facts (deadline, notified timestamp, consultant notice). 33 reuses the 12 Breach Type and Cure Action values. A breach caused by a trade error references the 25 Trade Error, which keeps the loss; Breach Loss Calculation is used only otherwise. NAV impact is a 27 NAV Error Case referenced from the breach. 35 board reports (name set by the 35 brief) and 37 incidents reference BREACH-.",
     "rationale": "One breach record, reported to clients, boards and regulators by reference; one home for each loss.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Head of Investment Compliance"},

    {"id": "CD-223", "theme": "Investment Oversight", "title": "One limit, one owner: risk-program limits in 31, coded investment restrictions in 33; an exceedance is recorded where its limit lives",
     "domains": ["31", "33", "24", "25", "01", "35"],
     "issue": "Limits on the same portfolio are set by different functions: the risk committee (VaR, tracking error), the Rule 22e-4 program (HLIM, 15% illiquid), Rule 18f-4 (VaR test), UCITS global exposure, the prospectus and mandate (01 RST-), clients (02 CRX-), statutes (ICA Sections 5, 12, 18; Rule 2a-7; UCITS Arts 52-57; IRC 817(h); ERISA; NAIC), the PM (24 constraints) and trading (25 counterparty limits). Some coded restrictions test a risk measure (a client tracking error cap, an AIFMD leverage cap).",
     "resolution": "31 Risk Limit (RLMT-) holds limits approved under a risk program or by the risk committee: risk appetite limits, the 22e-4 15% illiquid limit (the HLIM itself stays on Highly Liquid Investment Minimum), 18f-4 and UCITS VaR test limits, UCITS global exposure. 33 Compliance Rule (CRULE-) holds every coded investment restriction from 01, 02 or statute, including AIFMD leverage caps and AIFMD II loan-origination limits, even when the rule reads a 31 measure (the rule names the 31 measure; the value is not copied). 24 constraints and 25 counterparty limits stay where they are. Exceedances: 31 Risk Limit Exceedance (RLEX-) for 31 limits and for 25 counterparty limits (CD-215); 33 Investment Breach (BREACH-) for 33 rules. 'Breach' is never used for RLEX-.",
     "rationale": "Prevents the same limit being held twice and gives each exceedance one escalation path.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Chief Risk Officer / Chief Compliance Officer"},

    {"id": "CD-224", "theme": "Investment Compliance", "title": "Investment compliance (33) vs corporate compliance (38), MNPI escalation (23) and fund tax tests (27)",
     "domains": ["33", "38", "23", "27", "25", "08"],
     "issue": "Plan §3 puts code of ethics, personal trading, the restricted list and trade surveillance in 38 (Stage 4). 23 Meeting MNPI Assessment records possible MNPI from issuer meetings. 27 RIC Test Result holds Subchapter M diversification tests. 25 holds cross trades (Rule 17a-7) and Rule 10f-3 purchases. 08 keeps distribution compliance.",
     "resolution": "38 masters the firm restricted and watch lists, code of ethics and personal trading. A 33 Rule Instrument List may take the 38 restricted list as a source (text reference 'future owner 38' until Stage 4), and a 33 rule of type 'Firm Restricted List' blocks orders; the list entries are never mastered in 33. MNPI flow: 23 Meeting MNPI Assessment, then 38 restricted list, then 33 pre-trade block. 27 RIC Test Result stays the fund tax determination; 33 rules on RIC diversification are pre-trade monitoring only. 25 Cross Trade and Rule 10f-3 Purchase stay 25; 33 may test them. 08 is unchanged.",
     "rationale": "Separates firm-level conduct controls from portfolio-level investment restrictions while keeping the pre-trade block in one engine.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Compliance Officer"},

    # ===================================== Hand-offs =====================================
    {"id": "CD-225", "theme": "Investment Oversight", "title": "Hand-offs from 31, 32 and 33 to 35 (filings and board reporting), 34 and 36, by object name",
     "domains": ["31", "32", "33", "34", "35", "36", "01", "13"],
     "issue": "The Stage 3 product governance briefs (34-36) are written in parallel. 35 files N-PORT, N-RN, N-CEN, Form PF and AIFMD Annex IV and reports to boards; 34 masters ESG data; 36 holds product changes that alter rules and track records. Their object names are not yet published.",
     "resolution": "31 to 35: Liquidity Classification, Highly Liquid Investment Minimum, Fund Liquidity Profile, Liquidity Horizon Bucket, Designated Reference Portfolio, VaR Test Result, Leverage & Exposure Measurement, Stress Test Result and Risk Limit Exceedance (RLEX-). 32 to 35: Performance Return (RETURN-, N-PORT monthly returns, Form PF, Annex IV) and Benchmark Return. 33 to 35: Investment Breach (BREACH-) and Breach Review for board and regulator reporting. 31 from 34: climate and ESG metric observations into climate Stress Scenarios; 33 from 34: ESG data into Rule Instrument Lists. 36 to 33: product changes trigger Rule Coding Requests; 36 to 32: mergers and conversions set track-record continuity (01 Track Record Source). 35 and 36 hold board approvals referenced by 31 Highly Liquid Investment Minimum and Designated Reference Portfolio. Direction: the consumer holds the reference. Names in 34-36 are aligned at the Stage 3 consolidation.",
     "rationale": "Lets the six Stage 3 drafts reference each other before they exist (plan §9.2).",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. PREFIXES reserved by the Stage 3 investment oversight briefs  (prefix, entity, owner domain, status, note)
# Checked by edit distance (one letter) and anagram against decisions.PREFIXES (314 entries) and PREFIX_FORMATS,
# conventions §3-§15, prefix-like strings in _tools (US-MF-PERF-01, US-RISK-EQ-02 are disclosure codes), DP-nnn / FN-nn /
# GAP- / CD- IDs, Stage 1-4 domain codes, each other, and the prefixes the 34-36 briefs would naturally choose
# (VOTE-, ENG-, ESG-, PAI-, BRD-, FIL-, NPD-, LAUNCH-, PRJ-, MTG-, LIQ-, SCN-), none of which is reserved here.
# Proposed key formats are given in the notes; the owners publish them in PREFIX_FORMATS at consolidation.
# ---------------------------------------------------------------------------------------------------------------------

PREFIXES = [
    # ---- 31 Investment Risk
    ("RLMT-", "Risk limit (risk-program or risk committee limit on a risk measure)", "31", "Reserved", "Stage 3 brief (CD-223). Format RLMT-<sequence, 6 digits>, e.g. RLMT-000418. RLIM- rejected (one letter from PLIM- 16); RKL- rejected (one letter from RCL-). Two edits from RLN- (07) and RST- (01)."),
    ("RLEX-", "Risk limit exceedance", "31", "Reserved", "Stage 3 brief (CD-223, CD-215). Format RLEX-<year>-<sequence, 5 digits>, e.g. RLEX-2026-00073. Deliberate family with RLMT-; never called a breach (33 BREACH-)."),
    ("STRESS-", "Stress scenario (historical, hypothetical, regulatory, liquidity, climate)", "31", "Reserved", "Stage 3 brief (CD-216). Format STRESS-<sequence, 4 digits>, version separate, e.g. STRESS-0042. SCEN- rejected (one letter from SCN-, a likely 34 prefix); STSC- crowded by STR-, SCAC-."),
    # ---- 32 Performance & Attribution
    ("RETURN-", "Performance return (subject x period x fee basis x price basis x currency x version)", "32", "Reserved", "Stage 3 brief (CD-217). Format RETURN-<year>-<sequence, 10 digits>, version separate, e.g. RETURN-2026-0004518832. PRTN- rejected (one letter from PRUN- 13); RTN- / RETN- rejected (near RET- 08); PERF- rejected (same sense as PFR- 10)."),
    ("PAAN-", "Performance attribution result (attribution analysis)", "32", "Reserved", "Stage 3 brief. Format PAAN-<year>-<sequence, 8 digits>, e.g. PAAN-2026-00031877. ATTR-, ATRB-, PATR- rejected (one letter from ATR-, the 06 sales attribution record); PFA- rejected (one letter from PFD- / PFR-). Two edits from PAI- (34, expected)."),
    ("GVER-", "GIPS verification engagement", "32", "Reserved", "Stage 3 brief (CD-218). Format GVER-<year>-<sequence, 3 digits>, e.g. GVER-2026-001. Two edits from OVR-, WVR-, SVR-, GEO-."),
    # ---- 33 Investment Compliance
    ("CRULE-", "Compliance rule (coded investment guideline or regulatory limit; version separate)", "33", "Reserved", "Stage 3 brief (CD-221). Format CRULE-<sequence, 6 digits>, e.g. CRULE-004512. RULE- avoided (generic: 07, 10, 21, 22 rules); IGR- rejected (one letter from IDR- 11)."),
    ("CCHK-", "Compliance check run (pre-trade, intraday, post-trade, what-if)", "33", "Reserved", "Stage 3 brief (CD-221). Format CCHK-<year>-<sequence, 9 digits>, e.g. CCHK-2026-000918822. Two edits from PCHL- (22), CCN- (30), CCA- / CCI- (10)."),
    ("CALERT-", "Compliance alert", "33", "Reserved", "Stage 3 brief (CD-221). Format CALERT-<year>-<sequence, 7 digits>, e.g. CALERT-2026-0041877. CMAL- rejected (one letter from CAL- 09); qualifies the 'Alert' term conflict (29 AMA-, 08 SURV-)."),
    ("BREACH-", "Investment breach", "33", "Reserved", "Stage 3 brief (CD-222). Format BREACH-<year>-<sequence, 5 digits>, e.g. BREACH-2026-00143. BRCH- / BRC- rejected (crowded by BRK- 06, BRD- 04); IBR- rejected (one letter from IDR- 11). 12 keeps GBN- for the client notification."),
]
