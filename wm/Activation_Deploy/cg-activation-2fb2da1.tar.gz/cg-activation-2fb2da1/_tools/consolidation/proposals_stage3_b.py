"""Decision proposals for the enterprise expansion, Stage 3, brief set B: Data Domains 34-36
(Stewardship & Sustainable Investing, Fund Governance & Regulatory Reporting, Product Development & Lifecycle).

Format: identical to decisions.py (see CONTRACT.md in this folder). This file is a proposal fragment: the builder does not
read it, and nothing here changes a content module. The Stage 3 consolidation step (Enterprise_Expansion_Plan.md §9.3
step 5) merges accepted entries into decisions.py.

Sources: Enterprise_Expansion_Plan.md §3, §4 and §9; Domain_Ownership_and_Conventions.md §2, §8, §13, §14, §15; the
Stage 3 briefs 34-36 in 00_Program/Expansion/Briefs/; a scan of content modules 01-30 on 2026-10-06.

IDs CD-226 to CD-240 are reserved for this brief set (brief set A, domains 31-33, uses the range below it). Every entry has
status "Proposed"; where the business must choose, action is "SME decision" and the resolution gives the recommended
option. Working assumptions of the program lead (CD-143 accepted, the shared Business Line list (CD-209), governance
metadata in 21, per-attribute ownership with row rules, shared lists joined at consolidation) apply to every entry.
Names of objects in domains 31-33 are the names these briefs expect and must be confirmed against the 31-33 briefs.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. DECISIONS
# ---------------------------------------------------------------------------------------------------------------------

DECISIONS = [
    # ===================================== 34 Stewardship & Sustainable Investing =====================================
    {"id": "CD-226", "theme": "Investment Oversight", "title": "Investee proxy voting is mastered in 34; fund shareholder proxy stays in 13; the meeting event is a 17 corporate action; ballots key to 28 safekeeping accounts",
     "domains": ["34", "13", "17", "28", "18"],
     "issue": "13 Investor Servicing family SV-PRX (Proxy Campaign PRX-, Proxy Proposal PRP-, Vote Tally, Intermediary Vote Instruction) holds meetings of our own funds' shareholders. The firm voting the shares its portfolios hold in investee companies has no owner. 17 Corporate Action Event (CAE-) has no meeting event types (its list stops at ISO CAEV selections such as DVCA, MRGR, CONS), and 28 Securities Loan holds Recall Date and status Recalled but not the decision to recall for a vote. CD-195 already says investee meetings and votes are 34.",
     "resolution": "34 masters Investee Meeting Agenda Item (CAE- x item number), Proxy Adviser Recommendation, Ballot (CAE- x 28 Safekeeping Account SKA-), Vote Instruction (VOTE-), Vote Rationale and Lending Recall Decision (meeting x 28 SBL-). 17 adds Corporate Action Event Type values Annual General Meeting (MEET), Extraordinary General Meeting (XMET), Ordinary General Meeting (OMET) and Bondholder Meeting (BMET), so the meeting is a CAE- with its record and meeting dates; 34 creates no meeting object. 28 keeps the loan, Recall Date and loan status. Ballot record-date shares are a Derived copy (28 custodian statement, or 18 holding where no statement; row rule) and shares on loan not recalled a Derived copy (28). 13 objects are never used for investee votes. Where an own fund of funds votes an own-fund meeting, 13 Vote Tally 'Mirror / Echo Voted Shares' stays the tally and 34 holds the vote instruction only. Glossary qualifiers: 'Investee Proxy Vote' (34), 'Fund Proxy Campaign' (13).",
     "rationale": "Opposite directions of the same word: the firm as shareholder vs the firm's funds as issuers. Meeting announcements arrive with corporate action data (ISO 20022 seev.001), so they belong in the 17 golden copy; agenda items and votes are stewardship records with N-PX consequences.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Head of Stewardship"},

    {"id": "CD-227", "theme": "Investment Oversight", "title": "Engagement is mastered in 34 and references 23 issuer meetings; 03 sales activities are never used; 12 presents stewardship content",
     "domains": ["34", "23", "03", "12", "30"],
     "issue": "CD-172 says 34 Engagement will reference 23 Issuer Meeting (IMTG-), and 23 Issuer Meeting Topic carries 'Stewardship Objective Indicator'. 12 Report Definition carries 'Stewardship Report Scope' (Voting Record, Engagement Case Studies). Without a rule an engagement could repeat meeting dates and participants, or be logged as a 03 Sales Activity.",
     "resolution": "34 masters Engagement (ENGM-: case with an engaged issuer PTY-, objective, theme, status, outcome), Engagement Objective, Engagement Interaction, Escalation Action and Collaborative Initiative Membership. An interaction that was an issuer meeting references IMTG- and repeats none of its date, participant or topic attributes. 03 Sales Activity (ACT-) is never used for issuer engagement. Engagement with private portfolio companies uses the 30 Portfolio Company Profile party (PTY-). 12 presents engagements and votes in client reports and holds no stewardship facts. Engagement Status uses Shared: Case Status for workflow only; outcome is a separate local list.",
     "rationale": "An engagement is a multi-interaction case with an objective, owned by the stewardship team; a meeting is one research event owned by 23.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Stewardship"},

    {"id": "CD-228", "theme": "Investment Oversight", "title": "ESG data: vendor datasets licensed in 14; observations, firm assessments, sustainable investment determinations and exclusion lists mastered in 34",
     "domains": ["34", "14", "11", "17", "23", "22", "01", "02", "33"],
     "issue": "Vendor ESG scores and emissions data are licensed datasets (14 DSET-); 11 holds fund-level Morningstar Sustainability ratings (Rating Observation RTG-, Sustainability Rating Detail); 17 holds Sustainable Bond Label at issue and notes that 'assessments of the label are 34'; 23 Research Specialty includes ESG; 01 Investment Restriction has Restriction Source 'ESG Exclusion Policy' and 02 Client Restriction holds a client 'Exclusion List Reference' as text. Nobody masters issuer-level sustainability time series, the firm's own ESG score, SFDR sustainable investment tests or the firm's exclusion lists.",
     "resolution": "34 masters Sustainability Indicator Definition, Issuer Sustainability Observation (issuer or instrument x indicator x reporting period x source dataset x as-of; the 22 observation pattern, never overwritten), ESG Rating Observation (issuer-level vendor ratings), Firm ESG Assessment (ESGA-), Sustainable Investment Determination (SFDR Art 2(17), DNSH, good governance, EU Taxonomy alignment, assessment of a 17 Sustainable Bond Label) and Sustainability Exclusion List with members. 14 keeps the dataset and license; 11 keeps fund-level vendor ratings; 17 keeps the label claimed at issue; 23 Research Recommendation holds no ESG score; 02 client lists stay client-supplied text. 33 coded rules and 01 restrictions reference the 34 list (confirm the 33 object name against the 31-33 briefs). 'Rating' term conflict extended with 34 ESG Rating Observation.",
     "rationale": "The firm's sustainability view and the vendor inputs behind it are produced by one team and feed PAI, product commitments and compliance; one master avoids three ESG scores.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Head of Sustainable Investing"},

    {"id": "CD-229", "theme": "Investment Oversight", "title": "Principal adverse impacts, product sustainability outcomes and climate metrics are mastered in 34; commitments and SFDR classification stay in 01",
     "domains": ["34", "01", "31", "18", "12"],
     "issue": "01 ESG Classification holds SFDR Classification, Sustainability Label, Minimum Sustainable Investment %, Minimum Taxonomy-Aligned Investment % and Principal Adverse Impacts Considered: commitments. The achieved values, entity and product PAI indicators (Delegated Regulation 2022/1288 Annex I), financed emissions (PCAF), WACI and climate targets have no owner. The Commission's SFDR review proposal (20 November 2025) would remove the entity-level PAI statement for most firms and keep product-level PAI.",
     "resolution": "34 masters PAI Calculation (PAIC-: entity LEN- or product PRD- x reference period x version) and PAI Indicator Result, Product Sustainability Outcome (achieved sustainable investment %, taxonomy-aligned %), Portfolio Climate Metric with Financed Emissions Holding Detail, and Climate Target. 01 keeps classification and commitments; 34 attributes are named 'Achieved ...'. Climate scenario stress results, if modeled, are 31's (confirm against the 31-33 briefs). The entity-level PAI scope stays modeled but is flagged as dependent on the SFDR review; product scope is unaffected. Proposed (not applied): 01 may later carry a Derived copy of the latest achieved values for EET delivery.",
     "rationale": "Commitment vs outcome is the same split as terms (01) vs calculations (27) used for fees and NAVs.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Sustainable Investing"},

    {"id": "CD-230", "theme": "Investment Oversight", "title": "Voting authority and voting disclosures: content in 34, Form N-PX submission in 35, client presentation in 12",
     "domains": ["34", "35", "12", "15", "18", "01", "38"],
     "issue": "Form N-PX (Rule 30b1-4, amended November 2022, effective July 1, 2024) requires funds to report votes by category, and Rule 14Ad-1 requires 13(f) managers to report say-on-pay votes including shares on loan not recalled. No domain records who holds voting authority on a portfolio or account (searched 01, 02, 12, 15, 16, 18, 30: no attribute).",
     "resolution": "34 masters Voting Authority Arrangement (18 PORT- or 15 ACC- x effective period: firm, client retained, trustee, pass-through), Voting Policy (VPOL-) and Proxy Voting Report (reporting person fund series PRD- or manager LEN- x report type x period: N-PX fund, N-PX manager say-on-pay, SRD II voting disclosure). 35 Fund Regulatory Filing (REGF-) is the submission for both the fund and the manager N-PX (one EDGAR form, joint filing permitted) and references the 34 report. 12 presents client voting reports. 13F and Form ADV remain firm filings for 38 (Stage 4).",
     "rationale": "Content is produced by stewardship; filing operations, deadlines and EDGAR evidence sit with fund regulatory reporting.",
     "action": "SME decision", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Stewardship"},

    # ===================================== 35 Fund Governance & Regulatory Reporting =====================================
    {"id": "CD-231", "theme": "Fund Governance", "title": "Fund governing bodies, meetings and resolutions are mastered in 35; corporate boards of other group entities are 39; management committees stay in 22, 24 and 36",
     "domains": ["35", "01", "09", "39", "22", "24", "36", "02", "20"],
     "issue": "01 Product Governance 'Governing Body' is a Reference (Party) and 01 Party Role Type includes 'Board of Directors'. 09 holds the entities (Management Company / AIFM, Bank / Trust Company) but not their boards. 22 Valuation Committee, 24 Investment Committee and (Stage 3) 36 product committees are committees with meetings. 39 (Stage 4) will hold governance of internal legal entities.",
     "resolution": "35 masters Fund Governing Body (BOARD-: registrant boards and their committees, ManCo / AIFM boards, UK AFM boards, CIT trustee fiduciary committees, private fund LPACs), Governed Fund Coverage, Governing Body Membership (independent members PTY-, interested members EMP-), Fund Officer Appointment, Board Meeting (BMEET-), Board Agenda Item, Board Report Received, Board Resolution (RESO-) and Resolution Subject Link. 39 masters boards of the other group entities (holding companies, adviser, broker-dealer) and may reuse the 35 pattern by widening it; it does not re-master the bodies listed here. 22, 24 and 36 committees are management committees and are never modeled as governing bodies. Proposed (not applied): 01 Governing Body re-types to Reference (Fund Governing Body, 35) and the 01 Party Role Type value 'Board of Directors' is retired.",
     "rationale": "Fund boards act for the fund (1940 Act Section 10 and 15, UCITS and AIFMD ManCo governance, 12 CFR 9.4); they are stewarded by fund legal and the fund secretary, not by corporate secretarial.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Fund Secretary / Head of Fund Legal"},

    {"id": "CD-232", "theme": "Fund Governance", "title": "CD-022 resolution: the fund advisory agreement and its Section 15(c) renewal are mastered in 35; fee terms stay in 01; 10 references the agreement",
     "domains": ["35", "01", "10", "05", "11", "39"],
     "issue": "CD-022 (SME decision required) recommended that 01 own the fund advisory agreement with board approval and 15(c) renewal date. The Stage 3 plan puts advisory contract renewals and CD-022 in 35. 10 Revenue Contract (RVC-, type 'Investment Advisory Agreement (Fund)') has an 'Underlying Agreement' with no target; 11 Fee Benchmark Study has purpose 'Board 15(c) Review'.",
     "resolution": "35 masters Fund Advisory Agreement (ADVA-: fund PRD-, adviser LEN-, agreement type, effective date, initial term end, shareholder approval, termination) and Advisory Contract Renewal (RENEW-: agreement x renewal year) with Renewal Material Items and Board 15(c) Findings. Fee rates, breakpoints and fee schedules stay 01 Management Fee and Fee Schedule (FSCH-); 01 Product Party Role 'Investment Adviser' stays the role. 10 Revenue Contract 'Underlying Agreement' re-types to Reference (Fund Advisory Agreement, 35) on fund advisory rows. 05 stays distribution-only. 39 later indexes ADVA- as a contract type without re-mastering it. 01 Investment Management Agreement Date stays on mandates. Supersedes the CD-022 recommendation; CD-022 is closed by this entry.",
     "rationale": "The agreement exists because the board approves it and must renew it annually; its record and the renewal evidence are produced by fund legal for the board.",
     "action": "SME decision", "status": "Proposed", "priority": "High", "owner_role": "Head of Fund Legal"},

    {"id": "CD-233", "theme": "Regulatory Reporting", "title": "Fund regulatory filings are mastered in 35; distribution, plan, firm and transaction reporting stay with their owners",
     "domains": ["35", "01", "08", "13", "16", "19", "25", "26", "28", "36", "38"],
     "issue": "01 Regulatory Authorization holds 'Regulatory Reporting Obligations' as free text; 13 Shareholder Communication holds 'Regulatory Filing Reference' and 'Form N-CSR Filing Date'; 27 says N-CSR / N-PORT filing evidence is future 35; 08 holds FINRA Advertising Filing, Other Regulator Filing and Registration Filing; 16 holds Government Filing (GFIL-); 19 holds Regulatory Financial Return; CD-184 put fund filings in 35.",
     "resolution": "35 masters Filing Obligation and Fund Regulatory Filing (REGF-) for every fund-level submission: N-PORT, N-CEN, N-CSR, N-MFP, N-RN, N-CR, N-PX, 24F-2, 40-17G, N-8F, Rule 485(a) / 485(b) and 497 filings, N-14, Form PF, AIFMD Annex IV, UCITS and UK fund reports and returns, with Filing Certification and Filing Data Source. 36 holds the change and its filing requirement and reads REGF- status. 08 keeps distribution filings, 16 plan filings, 19 firm regulatory returns, 25 MiFIR, 26 derivative and repo reports, 28 SFTR and Rule 10c-1a reports, 38 (Stage 4) Form ADV, 13F and firm registrations. Proposed (not applied): 01 'Regulatory Reporting Obligations' becomes a Derived copy (35) of Filing Obligation; 13 'Regulatory Filing Reference' and 'Form N-CSR Filing Date' become Derived copies (35).",
     "rationale": "One submission record per fund filing, with the evidence of what data it relied on, is what fund regulatory reporting teams and examiners ask for.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Head of Fund Regulatory Reporting"},

    {"id": "CD-234", "theme": "Regulatory Reporting", "title": "35 filings and board reports reference measures mastered in 18, 22, 27, 31, 32 and 33; 35 masters none of them",
     "domains": ["35", "31", "32", "33", "27", "22", "18", "28", "30", "21"],
     "issue": "N-PORT reports holdings (18), fair value levels (22 Approved Price Fair Value Level), returns (32), liquidity classifications (31, Rule 22e-4) and derivatives exposure (31, Rule 18f-4); N-RN is triggered by 31 liquidity and VaR events; board reports summarize 33 breaches; Form PF and Annex IV read 30.",
     "resolution": "35 Fund Regulatory Filing, Filing Data Source, Board Report Received and Reportable Fund Event reference the producing objects by name: 31 Liquidity Classification, Highly Liquid Investment Minimum and Derivatives VaR Test Result; 32 Share Class Return and Benchmark Return; 33 Compliance Breach (all to be confirmed against the 31-33 briefs); 27 Share Class NAV, Fund Financial Statement and RIC Test Result; 22 Approved Price and ETF Market Statistic; 18 Portfolio Holding; 30 Private Fund Profile. 35 holds as-of, reconciled indicator and sign-off per filing source, which is record-level evidence and not a 21 Lineage Link.",
     "rationale": "Filings repeat measures that have masters; re-mastering them in 35 would create a second liquidity bucket, return or breach.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Head of Fund Regulatory Reporting"},

    {"id": "CD-235", "theme": "Fund Governance", "title": "RIC qualification determination, ETF public disclosure and shareholder report approval in 35 (confirms CD-191, CD-177, CD-206)",
     "domains": ["35", "27", "22", "24", "13", "18"],
     "issue": "27 RIC Test Result notes that qualification status is future 35; CD-177 gives 35 the ETF daily holdings disclosure; CD-206 has 22 compute ETF market statistics that 35 discloses; 27 prepares financial statements, 13 delivers tailored shareholder reports.",
     "resolution": "35 masters RIC Qualification Determination (fund x tax year, with IRC §817(h) results for insurance-dedicated funds) referencing 27 RIC Test Results; Fund Public Disclosure (ETF daily holdings from 18, premium / discount and median bid-ask spread from 22, MMF daily website data); and the board approval and N-CSR filing of shareholder reports. 27 keeps the statements, 13 the delivery (COMM-). 27 Fund Tax Return Type 'filing evidence' becomes a REGF- reference.",
     "rationale": "Tests and numbers are fund accounting; determinations, publication and filing are the fund's regulatory acts.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Fund Treasurer"},

    # ===================================== 36 Product Development & Lifecycle =====================================
    {"id": "CD-236", "theme": "Product", "title": "01 describes the product as it stands; 36 masters proposals, approvals, change initiatives and reviews; 01 lifecycle and governance attributes become derived copies",
     "domains": ["36", "01", "13"],
     "issue": "01 family LCG holds Lifecycle Event (Lifecycle Event Type, Event Effective Date, Successor Product / Share Class, Event Reason, Investor Notice Date) and Product Governance (Product Owner as Reference (Party), Product Approval Date, Last / Next Product Review Date, Value Assessment Outcome, Governing Body). These are outcomes of 36 processes.",
     "resolution": "36 masters Product Proposal (PPSL-), Product Approval Decision (PAPR-), Product Change Initiative (LCHG-) with Proposed Term Change and reorganization, conversion and liquidation details, and Product Review (PRVW-). 36 holds proposed values only; on the effective date 01 is updated and is the master again (Proposed Term Change 'current value' is a Derived copy (01) as at the proposal date). Proposed (not applied): 01 Product Approval Date, Last and Next Product Review Date and Value Assessment Outcome become Derived copies (36); 01 Product Owner re-types to Reference (Employee); 01 Lifecycle Event keeps the effected event and gains 'Originating Change Initiative' (LCHG-), its Event Reason becomes a Derived copy (36) and Investor Notice Date a Derived copy (13); 01 Lifecycle Event Type becomes a shared list 'Product Lifecycle Event Type' with the 36 change types as a superset.",
     "rationale": "The plan's rule for 01 and 36; the same split as terms in 01 and calculations in 27.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Head of Product Development"},

    {"id": "CD-237", "theme": "Product", "title": "Product governance committee (36), investment committee (24) and fund board (35) are distinct; a board approval is linked once, from 35",
     "domains": ["36", "24", "35"],
     "issue": "Three bodies approve product matters: the product approval committee (36), the investment committee (24 Investment Committee Decision) and the fund board (35 Board Resolution). If both 35 and 36 hold the link between a resolution and the change it approves, the same fact is held twice.",
     "resolution": "36 masters Product Governance Committee, Product Committee Membership, Product Committee Meeting and Product Approval Decision (PAPR-). 24 decisions are investment decisions and never approve a product. The link from a board approval to the 36 subject (PPSL-, LCHG-, PRVW-) is held only on 35 Resolution Subject Link; 36 Change Regulatory Requirement derives its 'satisfied' status from it.",
     "rationale": "One direction per link is the rule applied in CD-208 for private deal approvals.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Product Governance"},

    {"id": "CD-238", "theme": "Product", "title": "Periodic product reviews and value assessments (COLL 6.6.20, Consumer Duty) are mastered in 36; the distributor side stays in 08",
     "domains": ["36", "08", "01", "13", "10", "11", "32"],
     "issue": "08 family DC-PGF holds Distributor Feedback Report (FBK-), Sales Against Target Market, Distribution Chain Information Exchange, Distribution Review Finding and Outcome Metric (Consumer Duty). 01 holds Value Assessment Outcome and the document type 'Assessment of Value Report'. The manufacturer's review, criteria and actions have no owner.",
     "resolution": "36 masters Product Review (PRVW-), Value Assessment Criterion Result (the seven COLL 6.6.20 criteria per share class), Review Action and Target Market Review Result. Inputs are references: 08 distributor feedback and outcome metrics, 10 Profitability Record, 11 Fee Benchmark Study and Peer Universe, 32 returns (confirm against the 31-33 briefs). 01 Value Assessment Outcome becomes a Derived copy (CD-236). 13 publishes the report; 35 records the AFM board approval.",
     "rationale": "The manufacturer and distributor obligations under PROD 3 and PRIN 2A are separate and produced by different teams.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Product Governance"},

    {"id": "CD-239", "theme": "Product", "title": "Launch readiness references set-up records in 05, 14, 22, 27, 28 and 29; conversions to ETFs in 36; launch projects in 41",
     "domains": ["36", "27", "28", "29", "22", "14", "05", "01", "15", "06", "30", "41"],
     "issue": "A launch, share class addition or mutual fund to ETF conversion needs fund accounting books (27), safekeeping accounts (28), TA set-up (29), pricing (22), index licenses (14), platform agreements and shelf placement (05) and registrations (01). The ETF share class route (exemptive relief noticed September 2025) adds the treatment of accounts that cannot hold ETFs.",
     "resolution": "36 Product Readiness Plan and Readiness Check reference the set-up record in its owning domain and master none of it. 36 ETF Conversion Detail holds the route and account treatment; the resulting transactions are 29 and 06, the accounts 15. Private fund formation and closes are 30. Project management of large launches is 41 Change & Project Portfolio (Stage 4); until then the project code is text.",
     "rationale": "Readiness is evidence that other domains are ready, not a second copy of their set-up.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Product Development"},

    # ===================================== Registers =====================================
    {"id": "CD-240", "theme": "Identifiers", "title": "Stage 3 brief set B registers: 15 prefixes reserved for 34-36, family codes and term conflicts",
     "domains": ["34", "35", "36", "21"],
     "issue": "The 34-36 drafts need reserved prefixes that cannot collide or be confused with the register, with each other or with the natural choices of the 31-33 author, and the terms they share with earlier domains need qualifiers.",
     "resolution": "Reserve VOTE-, ENGM-, ESGA-, PAIC-, VPOL- (34); BOARD-, BMEET-, RESO-, ADVA-, RENEW-, REGF- (35); PPSL-, PAPR-, LCHG-, PRVW- (36). Each is at least two edits from every registered, renamed or retired prefix and from each other, and from VAR-, EXPO-, STRESS-, LIQ-, RET-, ATTR-, COMP-, RULE-, BRCH-, ALERT-. Rejected: ENG-, PAIS-, STWR-, CLMT-, SDP-, BMTG-, FFIL-, RFIL-, RNWL-, FAGR-, PCHG-, PLCE-, PREV-, PRPS-, NPP-, PDP-. Family codes avoid printing registered prefixes (ST-CLI, ST-DSC, PD-IDE, PD-PRV). Drafts publish KEY_FORMATS. Term conflicts are listed in TERM_CONFLICTS below.",
     "rationale": "Stage 2 renamed eight prefixes at consolidation for confusability; checking now avoids that rework.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Low", "owner_role": "Head of Data Governance"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. PREFIXES (reserved by the briefs)
# ---------------------------------------------------------------------------------------------------------------------

PREFIXES = [
    # ---- 34 Stewardship & Sustainable Investing
    ("VOTE-", "Investee proxy vote instruction (ballot x agenda item)", "34", "Reserved", "Stage 3 brief (CD-226). Not PRX- / PRP- (13 fund proxy)."),
    ("ENGM-", "Stewardship engagement (case with an investee issuer)", "34", "Reserved", "Stage 3 brief (CD-227). ENG- rejected (one letter from ENT-, 14)."),
    ("ESGA-", "Firm ESG assessment (issuer x assessment date x version)", "34", "Reserved", "Stage 3 brief (CD-228). Not ESC- (13)."),
    ("PAIC-", "Principal adverse impact calculation (entity or product x reference period x version)", "34", "Reserved", "Stage 3 brief (CD-229). PAIS- rejected (one letter from PDIS-, 30)."),
    ("VPOL-", "Voting policy version", "34", "Reserved", "Stage 3 brief (CD-230). Not VPA- (20) or PLY- (03)."),
    # ---- 35 Fund Governance & Regulatory Reporting
    ("BOARD-", "Fund governing body (board, board committee, ManCo / AIFM board, trustee fiduciary committee, LPAC)", "35", "Reserved", "Stage 3 brief (CD-231). Not BOD- (13) or BRD- (04)."),
    ("BMEET-", "Board meeting (body x meeting date x sequence)", "35", "Reserved", "Stage 3 brief (CD-231). BMTG- rejected (one letter from IMTG-, 23)."),
    ("RESO-", "Board resolution", "35", "Reserved", "Stage 3 brief (CD-231). Not REV- or RET- (08)."),
    ("ADVA-", "Fund advisory agreement", "35", "Reserved", "Stage 3 brief (CD-232, closes CD-022). FAGR- rejected (one insertion from AGR-, 05)."),
    ("RENEW-", "Section 15(c) advisory contract renewal (agreement x renewal year)", "35", "Reserved", "Stage 3 brief (CD-232). RNWL- rejected (one insertion from RNW-, 14)."),
    ("REGF-", "Fund regulatory filing (submission)", "35", "Reserved", "Stage 3 brief (CD-233). RFIL- / FFIL- rejected (one letter from GFIL-, 16)."),
    # ---- 36 Product Development & Lifecycle
    ("PPSL-", "Product proposal", "36", "Reserved", "Stage 3 brief (CD-236). PRPS- (PRP-, 13), NPP- (PPP-, 12) and PDP- (PDL-, 30) rejected."),
    ("PAPR-", "Product approval decision (product committee meeting x agenda item)", "36", "Reserved", "Stage 3 brief (CD-237). Not PAMD- / PAUD- (16) or APV- (19)."),
    ("LCHG-", "Product change initiative (launch, share class addition, fee change, merger, conversion, liquidation)", "36", "Reserved", "Stage 3 brief (CD-236). PCHG- rejected (one letter from PCHL-, 22); PLCE- (one insertion from PLC-, 04)."),
    ("PRVW-", "Product review (periodic review, assessment of value, fair value assessment)", "36", "Reserved", "Stage 3 brief (CD-238). PREV- rejected (one insertion from REV-, 08)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. TERM_CONFLICTS (for the Stage 3 consolidation)
# ---------------------------------------------------------------------------------------------------------------------

TERM_CONFLICTS = [
    {"term": "Proxy",
     "usages": [("13", "Proxy Campaign", "Meeting of our own funds' shareholders and the solicitation of their votes"),
                ("34", "Vote Instruction", "The firm voting shares its portfolios hold in investee companies")],
     "recommendation": "Use 'Fund Proxy Campaign' (13) and 'Investee Proxy Vote' (34); never 'Proxy' bare (CD-226)."},
    {"term": "Board / Committee",
     "usages": [("35", "Fund Governing Body", "Fund board, ManCo / AIFM board, trustee fiduciary committee, LPAC"),
                ("22", "Valuation Committee", "Management committee approving fair values"),
                ("24", "Investment Committee", "Management committee for investment decisions"),
                ("36", "Product Governance Committee", "Management committee for product decisions"),
                ("21", "Data Governance Body", "Data governance forum"),
                ("01", "Product Governance (Governing Body)", "Party reference to the board overseeing the product")],
     "recommendation": "'Board' means a 35 Fund Governing Body (39 corporate boards when built); other bodies are always named by function (CD-231, CD-237)."},
    {"term": "Meeting",
     "usages": [("13", "Proxy Campaign (Meeting Date)", "Fund shareholder meeting"),
                ("17", "Corporate Action Event (meeting types, proposed)", "Investee shareholder meeting"),
                ("23", "Issuer Meeting", "Research meeting with issuer management"),
                ("24", "Investment Committee Meeting", ""),
                ("35", "Board Meeting", ""),
                ("36", "Product Committee Meeting", "")],
     "recommendation": "Always qualify: Investee Shareholder Meeting, Fund Shareholder Meeting, Issuer Meeting, Board Meeting, Committee Meeting."},
    {"term": "Engagement",
     "usages": [("34", "Engagement", "Stewardship engagement case with an investee"),
                ("04", "Digital engagement", "Web and email engagement events"),
                ("13", "Servicing Provider Engagement", "Contract with a servicing provider")],
     "recommendation": "Enterprise 'Engagement' (unqualified) is the 34 stewardship case; others qualify ('Digital Engagement', 'Provider Engagement')."},
    {"term": "Filing",
     "usages": [("35", "Fund Regulatory Filing", "Fund-level regulatory submission"),
                ("08", "FINRA Advertising Filing / Other Regulator Filing", "Distribution materials"),
                ("16", "Government Filing", "Plan filings such as Form 5500"),
                ("19", "Regulatory Financial Return", "Firm financial returns")],
     "recommendation": "Qualify by subject: Fund Regulatory Filing, Marketing Filing, Plan Government Filing, Firm Regulatory Return (CD-233)."},
    {"term": "Review / Assessment",
     "usages": [("36", "Product Review", "Manufacturer periodic review and assessment of value"),
                ("08", "Compliance Review; Distribution Review Finding", "Marketing review; distributor-side product governance"),
                ("12", "Client Review", "Institutional client review meeting"),
                ("34", "Firm ESG Assessment", "Firm ESG score of an issuer")],
     "recommendation": "Qualify: Product Review, Compliance Review, Client Review, ESG Assessment."},
    {"term": "Change",
     "usages": [("36", "Product Change Initiative", "Change to a product or share class"),
                ("16", "Plan Fund Change", "Change to a plan's investment menu"),
                ("09", "Reorganization Event", "Internal organization change")],
     "recommendation": "Use 'Product Change' (36), 'Plan Fund Change' (16), 'Organization Change' (09)."},
]
