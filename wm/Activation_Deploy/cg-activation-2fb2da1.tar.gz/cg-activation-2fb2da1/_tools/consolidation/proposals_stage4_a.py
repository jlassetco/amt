"""Decision proposals for the enterprise expansion, Stage 4, risk, compliance, legal and procurement (Data Domains 37-40).

Format: identical to decisions.py (see CONTRACT.md in this folder). This file is a proposal fragment: the builder does not
read it, and nothing here changes a content module. The Stage 4 consolidation step (Enterprise_Expansion_Plan.md §9.3
step 5) merges accepted entries into decisions.py.

Sources: Enterprise_Expansion_Plan.md §3, §4 and §9; Domain_Ownership_and_Conventions.md §2, §8, §13-16;
stage3_consolidation_notes.md (§3 deferred decisions and §4 key-format follow-up); the Phase A briefs 37-40 in
00_Program/Expansion/Briefs/; a scan of content_01 ... content_36 on 2026-10-06 for every "future owner 37 / 38 / 39 / 40"
note and every text placeholder for a control, incident, model, policy, restricted list, AML case, contract, legal hold,
purchase order or supplier.

IDs CD-243 to CD-262 are reserved for this fragment (Stage 4 briefs A: 37-40). The Stage 4 briefs B (41-44) use their own
range. Every entry has status "Proposed"; where the business must choose, action is "SME decision" and the resolution gives
the recommended option. Objects of 41-44 are named "(name set by the 41 brief)" etc. until those briefs publish names.
Stage 4 is the last drafting stage: CD-262 lists how every "future owner 37 / 38 / 39 / 40" note in 01-36 is resolved.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. DECISIONS
# ---------------------------------------------------------------------------------------------------------------------

DECISIONS = [
    # ===================================== 37 Enterprise & Operational Risk =====================================
    {"id": "CD-243", "theme": "Enterprise Risk", "title": "The control library, risk register and RCSA are mastered in 37; domain control checks are executions of 37 controls",
     "domains": ["37", "06", "07", "10", "19", "27", "29", "38"],
     "issue": "Controls appear in many domains as executions or text codes: 10 Control 'Control Reference' (text, 'DF-KC-07'), 19 Close Task 'Key Control Reference', 07 Compensation Control (CTL-, with 'SOX Key Control Indicator'), 29 TA Control Check (TACK-), 27 NAV control checks, 06 Reconciliation (RCN-). There is no control library, risk register or RCSA. 38 compliance monitoring tests and 37 control tests could become two test records.",
     "resolution": "37 masters Risk Taxonomy Category, Enterprise Risk (RISK-), Risk Assessment, Risk Appetite Statement, RCSA Campaign, Control (CNTRL-, versioned), Risk Control Link and Control Test. Domain records (TACK-, RCN-, NAV control checks, Close Task, 07 Compensation Control, 10 Control) stay in their domains as executions; a 37 Control Test samples them by reference and copies no result. Compliance monitoring tests performed by 38 are 37 Control Test rows with testing line 'Compliance'. Proposed (not applied): 10 Control 'Control Reference' and 19 Close Task 'Key Control Reference' re-type to Reference (Control, 37) with a CNTRL- example; 07 Compensation Control gains an optional 'Library Control' reference. A KRI may be defined on a 21 Metric Definition (KPI-); the KRI Observation value is mastered in 37.",
     "rationale": "One control library assessed by the three lines; execution evidence stays where it is produced.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Chief Risk Officer"},

    {"id": "CD-244", "theme": "Enterprise Risk", "title": "Operational incidents and loss events are mastered in 37; investment breaches and risk exceedances are not incidents unless they cause a loss; one loss, one home",
     "domains": ["37", "13", "16", "25", "26", "27", "31", "33"],
     "issue": "25 Trade Error 'Related Incident Reference' is text ('INC 2026-1187', 'until 37 registers incidents'). Loss amounts are mastered on 25 Trade Error (Error Gain or Loss Amount, Reimbursement Amount), 27 NAV Error Case (Fund Loss Amount), 33 Breach Loss Calculation and 13 Shareholder Remediation; 26 Settlement Penalty and 16 Plan Correction carry costs. 33 Investment Breach and 31 Risk Limit Exceedance are investment events whose relation to operational incidents is undefined (33 overview: 'referenced ... in Stage 4, 37').",
     "resolution": "37 masters Operational Incident (OPINC-), Incident Classification (Basel event types), Incident Regulatory Notification, Operational Loss Event (LOSS-) and Loss Event Amount. An Investment Breach (BREACH-) or Risk Limit Exceedance (RLEX-) becomes an operational incident only when an operational failure caused it or it caused a loss; the incident references it and copies none of its facts. Loss Event Amount rows that reference a source record (25 Trade Error, 27 NEC-, 33 Breach Loss Calculation, 13 Shareholder Remediation, 26 Settlement Penalty, 16 Plan Correction) are Derived copies of the source amount (row rule); 37 masters amounts only where no source exists (fraud, legal settlements and fines from 39, disruption costs). Proposed (not applied): 25 Trade Error 'Related Incident Reference' re-types to Reference (Operational Incident, 37) with an OPINC- example.",
     "rationale": "Keeps the investment-oversight records intact while giving the firm one loss database for operational risk capital, ICARA and board reporting.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Head of Operational Risk"},

    {"id": "CD-245", "theme": "Enterprise Risk", "title": "Operational incidents (37) vs security incidents (41); DORA major ICT-related incident reporting on the 37 incident",
     "domains": ["37", "41"],
     "issue": "Plan §3 gives 37 'incidents and loss events' and 41 'security incidents'. DORA Articles 17-19 require classification and reporting of major ICT-related incidents, which include non-security ICT outages. Without a rule, both domains would hold incident registers and regulatory notifications.",
     "resolution": "41 masters security incidents (name and prefix set by the 41 brief; INC- is left to it) and the technical response. 37 masters the Operational Incident whenever a business service is disrupted or a loss arises, referencing the 41 security incident as its cause. DORA major ICT-related incident classification and the initial, intermediate and final reports, and FCA SUP 15 notifications, are held on 37 Incident Regulatory Notification. 41 does not hold regulatory incident notifications. The 41 brief is asked to confirm by object name.",
     "rationale": "One regulatory notification record per incident, held by the function that assesses business impact.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "High", "owner_role": "Chief Risk Officer"},

    {"id": "CD-246", "theme": "Model Risk", "title": "The model inventory, tiering, validation and monitoring are mastered in 37; consumers hold the reference (resolves CD-159 and CD-216)",
     "domains": ["37", "21", "22", "23", "24", "31", "32", "34"],
     "issue": "Model names are text with 'future owner 37': 31 Risk Model 'Model Inventory Reference', 32 Attribution Model 'Model Inventory Reference', 21 AI Use Case 'Model Name', 22 Fair Value Determination 'Valuation Model Name', 34 Firm ESG Assessment 'Assessment Methodology Name', 34 Portfolio Sustainability Metric 'Metric Model Name'; 24 Investment Decision 'Decision Algorithm Code' notes 'the algorithm inventory is a later domain (37)'; 23 Research Model carries 'Model Inventory Candidate Indicator'. SR 11-7 was rescinded on 2026-04-17 and replaced by SR 26-2.",
     "resolution": "37 masters Model Inventory Entry (MODEL-, versioned), Model Tier Assignment, Model Validation and Model Performance Monitoring for every quantitative, AI and trading-algorithm model. Consumers hold the reference and 37 holds no use list by ID. Proposed (not applied): the six text attributes above re-type to Reference (Model Inventory Entry, 37) with MODEL- examples (a Reference cannot be flagged Derived copy, so the type changes); 24 Decision Algorithm Code is noted as a Derived copy (37) of the trading-algorithm entry's code; 23 keeps its candidate indicator. 21 keeps AI Use Case, AI Risk Classification and AI Data Usage Approval (CD-159). 24 Rebalance Run 'Risk Model Used' stays a 31 reference (stage3 §3 item 26). Sources cite SR 26-2 and SR 11-7 (historical).",
     "rationale": "Model governance stays independent of model users; one inventory satisfies SR 26-2 and PRA SS1/23 practice and the EU AI Act inventory needs alongside 21.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Head of Model Risk"},

    {"id": "CD-247", "theme": "Internal Audit", "title": "Internal Audit is a family of 37 owned by the Chief Audit Executive; audit findings vs risk issues",
     "domains": ["37", "38", "39", "14", "16"],
     "issue": "Plan §3 asks for Internal Audit as an explicit family that keeps its independence through its own ownership, and allows a split into its own domain. Audit findings, regulatory exam findings (38), model validation findings and self-identified issues could each become a separate remediation register. 14 License Audit and 16 Plan Audit use 'audit' for other things.",
     "resolution": "37 Internal Audit family (Auditable Entity, Audit Plan, Audit Engagement AUDIT-, Audit Finding AUDF-, Finding Closure Validation) with data owner role Chief Audit Executive, distinct from the CRO-owned families. Findings are mastered by Internal Audit; management remediation is a 37 Risk Issue (ISSUE-) whose source is the finding, and only Finding Closure Validation closes a finding. 38 Examination Findings and 37 Model Validation findings remediate through Risk Issues with their own source type. The audit plan is approved by the audit committee (39 Corporate Resolution). Option B (SME): Internal Audit becomes its own Data Domain with the same objects and prefixes.",
     "rationale": "Ownership per family gives independence without a separate workbook; one remediation register avoids duplicated action tracking.",
     "action": "SME decision", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Audit Executive"},

    {"id": "CD-248", "theme": "Third-Party Risk", "title": "Third-party risk: 40 tiers and registers, 37 assesses (the enterprise register), 14 and 13 keep their specializations (resolves CD-090)",
     "domains": ["37", "40", "14", "13", "28", "23"],
     "issue": "CD-090 asks for one enterprise TPRM register. 14 holds Vendor Risk Assessment (VRA-: Inherent and Residual Risk Rating, Substitutability, Exit Strategy Documented) for data vendors only; 13 Servicing Provider Engagement holds an Oversight Rating; 28 Custody Provider Profile a Custody Risk Rating and Foreign Custody Assessment; 23 Research Provider Profile 'Expert Network Due Diligence Date' says 'future owner 14 vendor risk or 38'.",
     "resolution": "40 masters the supplier engagement (VENG-) and Supplier Risk Tiering (inherent criticality and due-diligence depth). 37 masters Third-Party Risk Assessment (third party x engagement x cycle, residual rating) and Third-Party Risk Domain Result: this is the enterprise register of CD-090. 14 keeps data-vendor and license-specific risk (VRA-, Assurance Report); proposed (not applied): VRA- Inherent and Residual Risk Rating become Derived copies (37) on rows with an enterprise assessment. 13 keeps operational oversight and SLAs; 28 keeps custody-specific assessments (Rule 17f-5 / 17f-7). 23 Expert Network Due Diligence Date becomes a Derived copy (37) of the Third-Party Risk Assessment of type 'Expert Network MNPI Controls'. Neither 37 nor 40 copies the other's rating.",
     "rationale": "Inherent tier (procurement input) and residual risk (risk output) are produced by different functions; one assessment record per third party satisfies CD-090 without re-mastering the specializations.",
     "action": "SME decision", "status": "Proposed", "priority": "High", "owner_role": "Head of Enterprise Risk (TPRM)"},

    {"id": "CD-249", "theme": "Operational Resilience", "title": "Important business services, critical or important functions, mapping, continuity plans and resilience tests are mastered in 37",
     "domains": ["37", "40", "41", "44", "09", "20"],
     "issue": "FCA SYSC 15A (important business services, impact tolerances, mapping, scenario testing) and DORA (critical or important functions) need a home. 14 ICT Third-Party Register Entry holds 'Supports Critical or Important Function' and 'UK Important Business Service Mapping' as values; 20 Workforce Position holds 'Key-Person Risk Indicator ... an input to 37 operational risk'.",
     "resolution": "37 masters Important Business Service with Impact Tolerance, Critical or Important Function, Resilience Resource Mapping (people 20 WFP-, applications 41, sites 09 SITE- or 44, third parties 40 VENG-, information 21 DAS-), Business Impact Analysis, Business Continuity Plan and Resilience Test. 41 masters ICT continuity and disaster recovery plans and their technical test results (names set by the 41 brief); 37 Resilience Test references them. 40 ICT Register of Information Entry and Outsourcing Arrangement reference the 37 function or service they support. 20 Key-Person Risk Indicator is read by the mapping, not copied.",
     "rationale": "Resilience is assessed per business service across all resource types; the technical recovery of systems is 41's.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Operational Resilience"},

    # ===================================== 38 Corporate Compliance & Regulatory Affairs =====================================
    {"id": "CD-250", "theme": "Corporate Compliance", "title": "Entity authorizations and cross-border passports move from 09 to 38 with names unchanged; Large Trader ID becomes a 38 copy",
     "domains": ["38", "09", "25", "26", "28", "35", "08", "20"],
     "issue": "09 holds Entity Authorization (AUTH-) and Cross-Border Passport as reference data; 26 says reporting obligations are 'read from 38 (09 Entity Authorization until 38 exists)'; 25 Trade Order 'Large Trader ID' is 'mastered here until 38 Compliance owns the Form 13H registration'; 20 asks whether firm-wide registrations move to 38; plan §3 gives 38 firm registrations and licenses.",
     "resolution": "Option A (recommended): Entity Authorization and Cross-Border Passport move to 38 with object, attribute and code-list names unchanged; AUTH- transfers to 38; 09 keeps Internal Legal Entity, Legal Entity Identifier, Entity Ownership Relationship and Entity Distribution Role. Authorization Type gains 'SEC Large Trader (Form 13H)' and 'US State Notice Filing'. 25 Large Trader ID becomes a Derived copy (38) of Entity Authorization.Regulator Reference Number for type SEC Large Trader. References in 28 CASS Firm Profile, 35 and 26 re-point to 38 at consolidation (names unchanged, so only the owner changes). 08 Individual Registration (LIC-) stays 08 for all registered individuals. Option B: 09 keeps Entity Authorization as reference data and 38 holds only maintenance filings (Firm Regulatory Filing).",
     "rationale": "Corporate Compliance maintains registrations and answers for them to regulators; moving the object with its names unchanged follows the v0.4 Account move.",
     "action": "Move", "status": "Proposed", "priority": "High", "owner_role": "Chief Compliance Officer"},

    {"id": "CD-251", "theme": "Corporate Compliance", "title": "Firm regulatory filings and ownership disclosure determinations are mastered in 38; fund filings stay 35, distribution filings 08",
     "domains": ["38", "35", "08", "18", "34", "02", "19"],
     "issue": "CD-233 leaves Form ADV, 13F and firm registrations to 38. 34 Engagement 'Passive Status Review Indicator' says 'the filing determination is future owner 38'. 02 Form ADV Profile describes external RIAs. 19 Regulatory Financial Return holds capital returns (FOCUS, ICARA).",
     "resolution": "38 masters Firm Regulatory Filing (FILNG-): Form ADV Parts 1, 2A, 2B and 3 (CRS), Form BD, Form 13F, Schedules 13D and 13G, Form 13H, Form SHO (compliance deferred to the January 2028 reporting period by SEC order of 2025-12-03), EU and UK major holdings and net short position notifications, CASS CMAR and other non-financial firm returns; and Ownership Disclosure Determination (issuer x regime x date: aggregated percentage from 18 holdings, threshold crossed, 13G eligibility, resulting filing). 35 keeps fund filings (REGF-), 08 distribution filings, 19 financial and capital returns, 02 Form ADV Profile of external advisers. 34 Passive Status Review Indicator stays a flag; its note names the 38 determination.",
     "rationale": "One submission record per filing, held by the function that signs it.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Compliance Officer"},

    {"id": "CD-252", "theme": "Corporate Compliance", "title": "The policy library, regulatory obligations and attestations are mastered in 38; 08 Regulatory Obligation and Attestation move with names unchanged",
     "domains": ["38", "08", "20", "22", "24", "25", "32", "34", "41"],
     "issue": "08 holds Regulatory Obligation (OBL-, distribution only) and Attestation (types include Code of Ethics Acknowledgment, Annual Compliance Certification, Outside Business Activities Declaration). 20 Learning Item Type says 'policy attestations are 08, later 38'. There is no policy library; 22 Pricing Policy, 24 asset allocation policies, 25 Best Execution Policy, 32 Calculation Policy and 34 Voting Policy hold domain parameters; 41 will hold IT policies.",
     "resolution": "Option A (recommended): 08 Regulatory Obligation and Attestation move to 38 with object, attribute and list names unchanged (OBL- transfers; the 08 'is evidenced by' relationship re-points); the obligation register widens to all regimes. 38 masters Policy (POLCY-) and Policy Version as the governed documents of every firm policy, including IT and information security policies (policy domain Technology) that 41 references, and the distribution policies 08 references. Domain policy objects keep the parameters they run on and may reference the governing 38 Policy; they are not re-mastered. Regulatory Change Item (REGCH-) and Regulatory Change Impact are new in 38; 11 Regulatory Horizon Item stays the market-intelligence view and may be cited as the first flag. Option B: 08 keeps distribution obligations and attestations with a row split by type.",
     "rationale": "One obligations register and one attestation record per person and period are what examiners test; a type split would hold the same fact twice.",
     "action": "Move", "status": "Proposed", "priority": "High", "owner_role": "Chief Compliance Officer"},

    {"id": "CD-253", "theme": "Corporate Compliance", "title": "Regulatory examinations and inquiries in 38; enforcement matters in 39; findings remediate as 37 Risk Issues",
     "domains": ["38", "39", "37"],
     "issue": "Plan §3 gives 38 'regulatory exams and inquiries' and 39 'legal matters and litigation'. An exam can turn into an enforcement investigation, and exam findings need remediation tracking that 37 already provides.",
     "resolution": "38 masters Regulatory Examination (EXAM-: routine and for-cause exams, sweeps, informal inquiries, thematic reviews), Regulator Request Item and Examination Finding. A formal order of investigation, subpoena, Wells notice or enforcement proceeding is a 39 Legal Matter (LMAT-) that references the originating exam. Remediation of an exam finding is a 37 Risk Issue with source 'Regulatory Finding'. Correspondence is held by the exam or matter it concerns; 39 reviews privilege on request items.",
     "rationale": "Separates the supervisory relationship (compliance) from adversarial proceedings (legal) and keeps one remediation register.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Compliance Officer"},

    {"id": "CD-254", "theme": "Corporate Compliance", "title": "Code of ethics, personal trading, political contributions, outside activities and the firm conflicts register are mastered in 38; 08 keeps distribution conduct records",
     "domains": ["38", "08", "20", "02", "42", "35"],
     "issue": "08 holds Gift / Entertainment Item (GNE-), Individual Registration (LIC-), Distribution Conflict of Interest (COI-) and the Attestation types above; 20 overview lists codes of ethics and personal trading as 38; 42 will hold lobbying; Rule 206(4)-5 applies to covered associates.",
     "resolution": "38 masters Conduct Population Designation, Personal Trading Account, Personal Holdings Report, Personal Transaction, Pre-Clearance Request, Code of Ethics Violation, Political Contribution with Pay-to-Play Review, Conflict of Interest (CONFL-), Conflict Mitigation and Outside Business Activity. 08 keeps GNE-, LIC- and COI-; proposed (not applied): 08 Distribution Conflict of Interest gains 'Firm Conflict' Reference (Conflict of Interest, 38), and COI- becomes the distribution profile of the firm register entry (CD-144 pattern). 42 masters lobbying registrations and disclosures; 38 masters political contributions of the firm and covered associates. HR sanctions stay 20; 38 records the violation.",
     "rationale": "Firm-wide conduct records evidence the Advisers Act code of ethics and pay-to-play rules; distribution-specific records stay with distribution compliance.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Compliance Officer"},

    {"id": "CD-255", "theme": "Corporate Compliance", "title": "The AML and sanctions program, AML cases and SAR / OFAC reports are mastered in 38; 02 keeps KYC, 29 keeps account monitoring; Regulator list additions",
     "domains": ["38", "02", "29", "40", "09"],
     "issue": "29 Account Monitoring Alert 'Escalation Case Reference' is a restricted identifier with 'future owner 38 (AML program, SAR case and filing)', and its disposition value 'Escalated for SAR Decision' points to an AML case with no home. 02 KYC Profile holds AML Risk Rating, PEP Status and Sanctions Screening Result. The FinCEN investment adviser AML rule (2024) was postponed to 2028-01-01 by exemptive order (August 2025) and is being revisited. The shared Regulator list has no FinCEN, OFAC, OFSI or NCA value.",
     "resolution": "38 masters AML Program Assessment (entity x year, BSA institution type and applicability date), AML Case (keyed by the restricted firm case number, no prefix) and AML and Sanctions Report (FinCEN SAR, UK SAR to the NCA, OFAC blocked and rejected property reports). 02 keeps the client KYC record and screening results, 29 the shareholder-account alerts and CIP, 40 supplier screening on Supplier Onboarding Case; all escalate to the 38 AML Case. Proposed (not applied): 29 'Escalation Case Reference' re-types to Reference (AML Case, 38); the 29 disposition value and relationship name AML Case. Add to the shared Regulator list (steward 09): 'FinCEN' (US_FINCEN), 'OFAC' (US_TREASURY_OFAC), 'UK HM Treasury OFSI' (UK_HMT_OFSI), 'UK National Crime Agency' (UK_NCA).",
     "rationale": "The program and its confidential reports belong to the BSA / MLRO officer; the screening facts stay with the domains that onboard the party.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "BSA / AML Officer"},

    {"id": "CD-256", "theme": "Corporate Compliance", "title": "Restricted and watch lists, MNPI escalations, insider lists and trade surveillance are mastered in 38; communications surveillance stays 08",
     "domains": ["38", "23", "25", "33", "08", "30", "34"],
     "issue": "33 Rule Instrument List 'Restricted List Source' is text ('future owner 38', CD-224); 23 Issuer Meeting 'MNPI Escalation Reference' is text ('future owner 38') and the 23 relationship names 'Restricted list entry [38]'; 25 names 'Surveillance Alert [38]' and market abuse surveillance as 38; 08 Surveillance Alert (SURV-) reviews communications.",
     "resolution": "38 masters Firm Restricted List, Restricted List Entry (RLIST-), MNPI Escalation (MNPI-) with Insider List Entry (MAR Article 18), Trade Surveillance Alert (TRSV-) and Suspicious Transaction and Order Report (MAR Article 16). 33 Rule Instrument List reads the list and stores no members (CD-224). Proposed (not applied): 33 'Restricted List Source' re-types to Reference (Firm Restricted List, 38); 23 'MNPI Escalation Reference' re-types to Reference (MNPI Escalation, 38); the 23 and 25 relationships name Restricted List Entry and Trade Surveillance Alert. 08 Surveillance Alert stays the communications surveillance record.",
     "rationale": "Completes the MNPI flow of CD-224 (23 flag, 38 decision and list, 33 block) with one owner for the list.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Chief Compliance Officer"},

    # ===================================== 39 Legal & Corporate Governance =====================================
    {"id": "CD-257", "theme": "Legal", "title": "39 masters the enterprise contract record; business domains keep typed contract profiles; the CD-144 contract pairs extended",
     "domains": ["39", "05", "14", "26", "28", "30", "35", "10", "16", "01", "20", "40"],
     "issue": "CD-144 names '39 contract / 05 AGR- and 14 DLA-'. Typed contracts are also mastered in 26 (TAGR-), 35 (ADVA-), 28 (Securities Lending Agreement), 30 (side letters, fund credit facilities), 10 (ICA-), 16 (PSVA-) and 01 (IMA on MND-). Custody agreements (28 'Service Agreement Reference'), charters (35 'Charter Reference'), executed advisory agreements (35 'Agreement Document Location'), LPAs (30) and statements of work (20 'Supplier Contract Reference') are text with 'future owner 39'.",
     "resolution": "39 masters Contract (CTRCT-), Typed Contract Link, Contract Party, Contract Document Version, Contract Signatory, Contract Key Date and Contract Clause Position for every executed instrument. Where a domain masters a typed record, the Contract links to it and the typed record keeps its commercial and operational terms; Contract dates, governing law, status and parties are Derived copies on typed rows (row rule) and mastered in 39 on untyped rows (custody, administration, NDA, engagement letter, lease, constitutional documents) and on rows typed by a 40 Supplier Contract Profile. Proposed (not applied): 28 Service Agreement Reference, 35 Charter Reference and Agreement Document Location, and 20 Supplier Contract Reference re-type to Reference (Contract, 39) or (Contract Document Version, 39). No typed record moves; 05 Agreement Document (DOC-) stays 05 (SME question).",
     "rationale": "One repository answers what the firm has signed with a party and under which entity, without re-mastering business terms.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "General Counsel"},

    {"id": "CD-258", "theme": "Legal", "title": "Legal matters and legal holds are mastered in 39; 02 and 08 legal hold indicators become Derived copies; 08 keeps retention rules",
     "domains": ["39", "02", "08", "19", "21", "37"],
     "issue": "02 Retention 'Legal Hold Indicator' and 08 Captured Communication Record 'Legal Hold Indicator' are mastered with no hold record behind them. Litigation reserves (ASC 450) and outside counsel invoices have no owner.",
     "resolution": "39 masters Legal Matter (LMAT-), Matter Party, Matter Event, Matter Financial Assessment (reserve, likelihood, disclosure), Outside Counsel Engagement and Outside Counsel Invoice Review (referencing 19 APV-), and Legal Hold (LHOLD-) with Legal Hold Custodian and Legal Hold Scope (08 RET- record class, 21 DAS-, 41 application, 02 party, date range). Proposed (not applied): 02 and 08 Legal Hold Indicator become Derived copies (39) of Legal Hold Scope (true while an active hold covers the record). 08 Retention Rule stays 08. Settlements and fines feed 37 Operational Loss Event.",
     "rationale": "An indicator without the hold cannot show who issued it, what it covers or when it was released.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "General Counsel"},

    {"id": "CD-259", "theme": "Corporate Governance", "title": "Corporate boards, officers, resolutions, statutory filings, signing authority and trademarks of internal entities are mastered in 39; fund boards stay 35",
     "domains": ["39", "35", "09", "04", "42", "43", "38"],
     "issue": "CD-231 keeps fund governing bodies in 35 and leaves corporate boards of the adviser, broker-dealer and holding companies to 39 (35 family text 'future 39'). 09 Internal Legal Entity holds entity identity and ownership. 04 Brand (BRD-) holds brand architecture; 42 will hold the corporate brand. Powers of attorney and signatories have no home.",
     "resolution": "39 masters Corporate Governing Body (CGOV-), Corporate Body Membership, Corporate Officer Appointment (including the adviser CCO, MLRO / BSA officer and SM&CR function holders as entity appointments), Corporate Board Meeting, Corporate Resolution (CGRES-), Entity Statutory Filing, Power of Attorney (POWER-), Signing Authority Grant, Trademark Registration (TMARK-), Trademark Docket Deadline and Trademark License Grant. A body that governs a fund or a fund-management entity (ManCo, AIFM, ACD, CIT trustee committee) stays 35. 09 keeps entity identity and ownership. Bank account mandates are 43. 04 and 42 keep brands; 39 holds the legal registration. Risk appetite, audit plans and policy versions approved by entity boards reference the Corporate Resolution.",
     "rationale": "Mirrors CD-231 for the corporate group and gives company secretariat records one owner.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Company Secretary"},

    # ===================================== 40 Procurement & Vendor Management =====================================
    {"id": "CD-260", "theme": "Procurement", "title": "Supplier profiles, sourcing, purchase orders, receipts and invoice matching are mastered in 40; 14, 13 and 28 are specializations; 03 keeps RFPs the firm answers",
     "domains": ["40", "02", "03", "13", "14", "19", "20", "28"],
     "issue": "19 Payable Invoice 'Purchase Order Reference' is text ('future reference to 40 Procurement'); 14 Data Vendor 'Procurement Supplier ID' is an external identifier; 20 Contingent Worker Detail 'Supplier Contract Reference' is text; 03 RFP Request (RFP-) holds RFPs the firm receives; CD-144 names the pair '40 supplier / 14 Data Vendor'.",
     "resolution": "40 masters Supplier Profile (keyed by PTY-), Supplier Remittance Detail, Supplier Onboarding Case, Supplier Engagement (VENG-), Supplier Category Assignment, Sourcing Event (SRCG-, issued by the firm), Sourcing Invitation and Award, Purchase Requisition (PREQ-), Purchase Order (PURCH-) and lines, Goods and Service Receipt, Invoice Match Result, Supplier Contract Profile (keyed by 39 CTRCT-), Contracted Service Level, Supplier Performance Review and Supplier Spend Summary. 19 keeps the payable invoice and payment (CD-158); 03 keeps RFPs the firm answers. Proposed (not applied): 19 Purchase Order Reference re-types to Reference (Purchase Order, 40) with a PURCH- example; 14 Procurement Supplier ID becomes a Derived copy (40) shown without a hyphenated stem ('SUP 0045521'; 'SUP-' is one letter from SUB-); 20 Supplier Contract Reference re-types to Reference (Purchase Order, 40) or (Contract, 39). Party Role Type gains 'Supplier', 'ICT Third-Party Service Provider', 'Subcontractor' and 'Staffing Agency' (CD-143).",
     "rationale": "Applies the shared-concept pattern to suppliers and closes the purchase-to-pay gap between 19 and the domains that buy.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Head of Procurement"},

    {"id": "CD-261", "theme": "Procurement", "title": "Outsourcing arrangements and the DORA register of information are mastered in 40; 14 ICT Third-Party Register Entry becomes a data-vendor view",
     "domains": ["40", "14", "13", "37", "39"],
     "issue": "14 ICT Third-Party Register Entry holds DORA register fields for data vendors only; DORA (ITS (EU) 2024/2956) requires one register of information per entity covering every ICT third-party arrangement; EBA/GL/2019/02, FCA SYSC 8 and CSSF Circular 22/806 require outsourcing registers and notifications. The SEC outsourcing-by-advisers proposal (2022) was withdrawn on 2025-06-12.",
     "resolution": "40 masters Supplier Risk Tiering, Outsourcing Arrangement (OUTS-) with Exit Plan, ICT Register of Information Entry (entity x contractual arrangement x ICT service, templates B_01 to B_07), Supply Chain Subcontractor and Outsourcing Notification. The contractual arrangement is a 39 Contract; the supported function is a 37 Critical or Important Function or Important Business Service. Proposed (not applied): 14 ICT Third-Party Register Entry fields (DORA In-Scope Indicator, Reporting Financial Entity, Contractual Arrangement Reference, ICT Service Type, Supports Critical or Important Function, Supported Functions, Data Storage Locations, Material Subcontractors, UK Important Business Service Mapping) become Derived copies (40) on data-vendor rows, or the object is retired in favor of 40 (SME). US service-provider oversight rests on Rules 38a-1 and 206(4)-7; the withdrawn SEC proposal is recorded as status only.",
     "rationale": "DORA requires one register per entity; two partial registers do not satisfy it (CD-090 rationale).",
     "action": "SME decision", "status": "Proposed", "priority": "High", "owner_role": "Head of Procurement / Head of Enterprise Risk (TPRM)"},

    # ===================================== Registers =====================================
    {"id": "CD-262", "theme": "Code Lists", "title": "Stage 4 briefs A: reserved prefixes for 37-40 and the resolution of every 'future owner 37 / 38 / 39 / 40' note in 01-36",
     "domains": ["37", "38", "39", "40", "19", "20", "21", "22", "23", "24", "25", "26", "28", "29", "30", "31", "32", "33", "34", "35"],
     "issue": "Stage 4 is the last drafting stage, so every text placeholder that names 37-40 as future owner must resolve to a named object. The 37-40 drafts need prefixes that cannot collide with, or be confused with, the register (339 entries), each other, or the natural choices of the 41-44 author (APP-, SYS-, INC-, CHG-, ACCESS-, PRESS-, CASH-, SITE-).",
     "resolution": "Reserve RISK-, CNTRL-, OPINC-, LOSS-, ISSUE-, MODEL-, AUDIT-, AUDF- (37); FILNG-, EXAM-, POLCY-, REGCH-, RLIST-, TRSV-, CONFL-, MNPI- (38; AUTH- and OBL- transfer under CD-250 and CD-252); CTRCT-, LMAT-, LHOLD-, CGOV-, CGRES-, POWER-, TMARK- (39); VENG-, SRCG-, PREQ-, PURCH-, OUTS- (40). Each is at least two edits from, and no anagram of, every registered, proposed, renamed or retired prefix and each other. Rejected: CTRL-, CNTL-, KCTL-, CTR-, CTRT-, LCTR-, CONTR-, KRI-, MRM-, MINV-, MDLI-, MODL-, INC-, OREV-, BCP-, IBS-, POL-, PLCY-, POLY-, CPOL-, FPOL-, FFIL-, CFIL-, RFIL-, FREG-, FRMF-, RCHG-, RSTL-, RESL-, TSRV-, TSURV-, MAS-, SAR-, HOLD-, LHLD-, CRES-, ERES-, CRSL-, POA-, POAT-, TMK-, TRMK-, IPR-, SRC-, RFX-, SEVT-, SENG-, PORD-, POR-, PCO-. Family codes avoid printing registered prefixes (ER-CSA not ER-CTL, ER-INL not ER-EVT, CO-CNF not CO-COI, LG-PRS not LG-HLD, LG-CGV not LG-ENT). Drafts publish KEY_FORMATS and GRAIN_KEY_FORMATS. Future-owner resolution: 21 AI Use Case Model Name, 22 Valuation Model Name, 24 Decision Algorithm Code, 31 and 32 Model Inventory Reference, 34 Assessment Methodology Name and Metric Model Name -> 37 Model Inventory Entry (CD-246); 23 Research Model candidate indicator -> 37 Model Inventory Entry; 25 Related Incident Reference and 33 overview incidents -> 37 Operational Incident (CD-244); 20 Key-Person Risk Indicator -> 37 Resilience Resource Mapping (CD-249); 23 Expert Network Due Diligence Date -> 37 Third-Party Risk Assessment (CD-248); 23 MNPI Escalation Reference -> 38 MNPI Escalation and 23 'Restricted list entry [38]' -> 38 Restricted List Entry, 33 Restricted List Source -> 38 Firm Restricted List, 25 'Surveillance Alert [38]' -> 38 Trade Surveillance Alert (CD-256); 25 Large Trader ID and 26 reporting obligations -> 38 Entity Authorization (CD-250); 29 Escalation Case Reference -> 38 AML Case (CD-255); 34 Passive Status Review Indicator and 35 'Form ADV and 13F' -> 38 Firm Regulatory Filing and Ownership Disclosure Determination (CD-251); 35 '38a-1 annual compliance program review' -> 38 Compliance Program Review; 20 'policy attestations ... later 38' -> 38 Attestation (CD-252); 28 'CASS policy and audit (38)' -> 38 Policy and Firm Regulatory Filing (CMAR); 28 Service Agreement Reference, 26 and 30 overview contracts, 35 Charter Reference and Agreement Document Location -> 39 Contract / Contract Document Version (CD-257); 35 'corporate boards ... future 39' -> 39 Corporate Governing Body (CD-259); 19 Purchase Order Reference and overview -> 40 Purchase Order (CD-260). Not resolved here (41-44 author): 18 Book of Record System (41), 36 Launch Project Code (41), 36 seed capital and 30 GP borrowing (43). 24 Rebalance Run Risk Model Used stays 31 (stage3 §3 item 26).",
     "rationale": "Stage 2 renamed eight prefixes at consolidation for confusability; checking now avoids that rework, and the sweep closes the last future-owner notes.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Low", "owner_role": "Head of Data Governance"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. PREFIXES  (prefix, entity, owner domain, status, note) - decisions.py tuple format
# ---------------------------------------------------------------------------------------------------------------------

PREFIXES = [
    # ---- 37 Enterprise & Operational Risk
    ("RISK-", "Enterprise risk (risk register entry)", "37", "Reserved", "Stage 4 brief (CD-243). Format RISK-<sequence, 5 digits>, e.g. RISK-00412. Two edits from RST-, RSM-, RSL-, RESO-, ISR-."),
    ("CNTRL-", "Control (control library entry; version separate)", "37", "Reserved", "Stage 4 brief (CD-243). Format CNTRL-<sequence, 6 digits>, e.g. CNTRL-004120. CTRL-, CNTL-, KCTL- rejected (one letter from CTL-, 07 Compensation Control)."),
    ("OPINC-", "Operational incident", "37", "Reserved", "Stage 4 brief (CD-244, CD-245). Format OPINC-<year>-<sequence, 5 digits>, e.g. OPINC-2026-01187. INC- left to 41 (security incidents); OREV- rejected (one letter from REV-)."),
    ("LOSS-", "Operational loss event", "37", "Reserved", "Stage 4 brief (CD-244). Format LOSS-<year>-<sequence, 5 digits>, e.g. LOSS-2026-00213. Two edits from LOT-, LOAN-, LOAD-, LST-, POS-."),
    ("ISSUE-", "Risk issue (issues and actions register)", "37", "Reserved", "Stage 4 brief (CD-243, CD-247). Format ISSUE-<year>-<sequence, 5 digits>, e.g. ISSUE-2026-00877. DQI- (21) and VDI- (14) stay for data issues."),
    ("MODEL-", "Model inventory entry (version separate)", "37", "Reserved", "Stage 4 brief (CD-246). Format MODEL-<sequence, 4 digits>, e.g. MODEL-0412. MDLI-, MODL- rejected (one insertion from MDL-, 01 model portfolio); MRM- rejected (one letter from MRL-, MRR-); MINV- rejected (one letter from MIN-)."),
    ("AUDIT-", "Internal audit engagement", "37", "Reserved", "Stage 4 brief (CD-247). Format AUDIT-<plan year>-<sequence, 3 digits>, e.g. AUDIT-2026-014. No registered prefix within two edits."),
    ("AUDF-", "Internal audit finding", "37", "Reserved", "Stage 4 brief (CD-247). Format AUDF-<plan year>-<engagement sequence, 3 digits>-<finding, 2 digits>, e.g. AUDF-2026-014-03. Two edits from PAUD- (16), AUTH-, AUDIT-."),
    # ---- 38 Corporate Compliance & Regulatory Affairs
    ("FILNG-", "Firm regulatory filing (Form ADV, BD, 13F, 13D/G, 13H, SHO, EU/UK holdings and short positions)", "38", "Reserved", "Stage 4 brief (CD-251). Format FILNG-<form code, letters and digits only>-<year>-<sequence, 5 digits>, e.g. FILNG-13F-2026-00004. FFIL-, CFIL-, RFIL- rejected (one letter from GFIL-, 16); FREG- rejected (anagram of REGF-, 35)."),
    ("EXAM-", "Regulatory examination, sweep or inquiry", "38", "Reserved", "Stage 4 brief (CD-253). Format EXAM-<year>-<sequence, 4 digits>, e.g. EXAM-2026-0007. Two edits from EXEC- (25), ENGM- (34)."),
    ("POLCY-", "Firm policy (policy library; version separate)", "38", "Reserved", "Stage 4 brief (CD-252). Format POLCY-<sequence, 4 digits>, e.g. POLCY-0118. POL- rejected (one letter from POS-); PLCY-, POLY- rejected (one insertion from PLC-, PLY-); CPOL-, FPOL- rejected (one insertion from CPO-, FPL-). VPOL- (34) stays the voting policy."),
    ("REGCH-", "Regulatory change item", "38", "Reserved", "Stage 4 brief (CD-252). Format REGCH-<year>-<sequence, 4 digits>, e.g. REGCH-2026-0042. RCHG- rejected (one letter from LCHG-, 36). Two edits from REGF-."),
    ("RLIST-", "Restricted list entry (restricted, watch, insider lists)", "38", "Reserved", "Stage 4 brief (CD-256). Format RLIST-<year>-<sequence, 6 digits>, e.g. RLIST-2026-000318. RSTL-, RESL- rejected (one insertion from RST-, RSL-, RESO-)."),
    ("TRSV-", "Trade surveillance alert", "38", "Reserved", "Stage 4 brief (CD-256). Format TRSV-<year>-<sequence, 7 digits>, e.g. TRSV-2026-0012281. TSURV-, TSRV- rejected (one letter from SURV-, 08, and the renamed SRV-)."),
    ("CONFL-", "Conflict of interest (firm conflicts register)", "38", "Reserved", "Stage 4 brief (CD-254). Format CONFL-<sequence, 5 digits>, e.g. CONFL-00231. Two edits from CONT-, CONB-, CNFM-; COI- (08) stays the distribution conflict profile."),
    ("MNPI-", "MNPI escalation", "38", "Reserved", "Stage 4 brief (CD-256). Format MNPI-<year>-<sequence, 5 digits>, e.g. MNPI-2026-00412. Two edits from MND-, KPI-, SNP-."),
    # ---- 39 Legal & Corporate Governance
    ("CTRCT-", "Contract (enterprise contract record)", "39", "Reserved", "Stage 4 brief (CD-257). Format CTRCT-<sequence, 7 digits>, e.g. CTRCT-0041877. CTR-, CTRT- rejected (one letter from CTL-, CTP- or CTRL-); CONTR- rejected (one insertion from CONT-); LCTR- rejected (anagram of CTRL-)."),
    ("LMAT-", "Legal matter", "39", "Reserved", "Stage 4 brief (CD-253, CD-258). Format LMAT-<year>-<sequence, 4 digits>, e.g. LMAT-2026-0019. Two edits from LST-, LOT-, LOAN-, LAU-, RLMT-."),
    ("LHOLD-", "Legal hold", "39", "Reserved", "Stage 4 brief (CD-258). Format LHOLD-<year>-<sequence, 4 digits>, e.g. LHOLD-2026-0007. HOLD-, LHLD- rejected (one letter from HLD-, 18)."),
    ("CGOV-", "Corporate governing body (board or committee of an internal entity)", "39", "Reserved", "Stage 4 brief (CD-259). Format CGOV-<sequence, 4 digits>, e.g. CGOV-0003. Two edits from RCOV-, GOL-, COI-; BOARD- (35) and BOD- (13) kept apart."),
    ("CGRES-", "Corporate resolution", "39", "Reserved", "Stage 4 brief (CD-259). Format CGRES-<year>-<sequence, 5 digits>, e.g. CGRES-2026-00041. CRES-, ERES- rejected (one letter from each other); CRSL- rejected (one insertion from RSL-). RESO- (35) stays the fund board resolution."),
    ("POWER-", "Power of attorney", "39", "Reserved", "Stage 4 brief (CD-259). Format POWER-<year>-<sequence, 5 digits>, e.g. POWER-2026-00112. POA- rejected (one letter from PYA-, POS-); POAT- rejected (one letter from PORT-)."),
    ("TMARK-", "Trademark registration (mark x jurisdiction x office)", "39", "Reserved", "Stage 4 brief (CD-259). Format TMARK-<sequence, 5 digits>, e.g. TMARK-00318. TMK- rejected (one letter from TMD-, 07); TRMK- rejected (one insertion from TRM-, 12); IPR- rejected (one letter from IDR-, 11)."),
    # ---- 40 Procurement & Vendor Management
    ("VENG-", "Supplier engagement", "40", "Reserved", "Stage 4 brief (CD-248, CD-260). Format VENG-<sequence, 6 digits>, e.g. VENG-001877. SENG- rejected (one letter from SEG-, 04). Two edits from ENGM- (34), LEN-, ENT-."),
    ("SRCG-", "Sourcing event (RFI, RFP, RFQ issued by the firm)", "40", "Reserved", "Stage 4 brief (CD-260). Format SRCG-<year>-<sequence, 4 digits>, e.g. SRCG-2026-0031. SRC- rejected (one letter from SRQ-, SRV-); RFX- rejected (one letter from RFP-, 03, which holds RFPs the firm answers)."),
    ("PREQ-", "Purchase requisition", "40", "Reserved", "Stage 4 brief (CD-260). Format PREQ-<year>-<sequence, 7 digits>, e.g. PREQ-2026-0018840. Two edits from JRQ-, PRP-, PRX-, RREC-, PRVW-."),
    ("PURCH-", "Purchase order", "40", "Reserved", "Stage 4 brief (CD-260). Format PURCH-<ERP purchase order number, 10 digits>, e.g. PURCH-4500021877. PORD-, POR- rejected (one letter from PORT-, 18, and TORD-, 25); PCO- rejected (anagram of CPO-, 10)."),
    ("OUTS-", "Outsourcing arrangement", "40", "Reserved", "Stage 4 brief (CD-261). Format OUTS-<sequence, 4 digits>, e.g. OUTS-0042. Two edits from OTC- (26), OU- (09), AUTH-."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. PREFIX_FORMATS  (prefix, owner domain, format, example) - decisions.py tuple format; drafts confirm or amend them
# ---------------------------------------------------------------------------------------------------------------------

PREFIX_FORMATS = [
    ("RISK-", "37", "RISK-<sequence, 5 digits>", "RISK-00412"),
    ("CNTRL-", "37", "CNTRL-<sequence, 6 digits>; the version is a separate attribute", "CNTRL-004120"),
    ("OPINC-", "37", "OPINC-<year>-<sequence, 5 digits>", "OPINC-2026-01187"),
    ("LOSS-", "37", "LOSS-<year>-<sequence, 5 digits>", "LOSS-2026-00213"),
    ("ISSUE-", "37", "ISSUE-<year>-<sequence, 5 digits>", "ISSUE-2026-00877"),
    ("MODEL-", "37", "MODEL-<sequence, 4 digits>; the version is a separate attribute", "MODEL-0412"),
    ("AUDIT-", "37", "AUDIT-<plan year>-<sequence, 3 digits>", "AUDIT-2026-014"),
    ("AUDF-", "37", "AUDF-<plan year>-<engagement sequence, 3 digits>-<finding, 2 digits>", "AUDF-2026-014-03"),
    ("FILNG-", "38", "FILNG-<form code, letters and digits only>-<year>-<sequence, 5 digits>", "FILNG-13F-2026-00004"),
    ("EXAM-", "38", "EXAM-<year>-<sequence, 4 digits>", "EXAM-2026-0007"),
    ("POLCY-", "38", "POLCY-<sequence, 4 digits>; the version is a separate attribute", "POLCY-0118"),
    ("REGCH-", "38", "REGCH-<year>-<sequence, 4 digits>", "REGCH-2026-0042"),
    ("RLIST-", "38", "RLIST-<year>-<sequence, 6 digits>", "RLIST-2026-000318"),
    ("TRSV-", "38", "TRSV-<year>-<sequence, 7 digits>", "TRSV-2026-0012281"),
    ("CONFL-", "38", "CONFL-<sequence, 5 digits>", "CONFL-00231"),
    ("MNPI-", "38", "MNPI-<year>-<sequence, 5 digits>", "MNPI-2026-00412"),
    ("CTRCT-", "39", "CTRCT-<sequence, 7 digits>", "CTRCT-0041877"),
    ("LMAT-", "39", "LMAT-<year>-<sequence, 4 digits>", "LMAT-2026-0019"),
    ("LHOLD-", "39", "LHOLD-<year>-<sequence, 4 digits>", "LHOLD-2026-0007"),
    ("CGOV-", "39", "CGOV-<sequence, 4 digits>", "CGOV-0003"),
    ("CGRES-", "39", "CGRES-<year>-<sequence, 5 digits>", "CGRES-2026-00041"),
    ("POWER-", "39", "POWER-<year>-<sequence, 5 digits>", "POWER-2026-00112"),
    ("TMARK-", "39", "TMARK-<sequence, 5 digits>", "TMARK-00318"),
    ("VENG-", "40", "VENG-<sequence, 6 digits>", "VENG-001877"),
    ("SRCG-", "40", "SRCG-<year>-<sequence, 4 digits>", "SRCG-2026-0031"),
    ("PREQ-", "40", "PREQ-<year>-<sequence, 7 digits>", "PREQ-2026-0018840"),
    ("PURCH-", "40", "PURCH-<ERP purchase order number, 10 digits>", "PURCH-4500021877"),
    ("OUTS-", "40", "OUTS-<sequence, 4 digits>", "OUTS-0042"),
]
