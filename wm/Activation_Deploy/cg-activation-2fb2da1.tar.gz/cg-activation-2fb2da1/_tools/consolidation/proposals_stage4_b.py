"""Decision proposals for the enterprise expansion, Stage 4, brief set B: Data Domains 41-44
(Technology & Information Security, Corporate Communications & Public Affairs, Corporate Treasury & Capital,
Workplace & Corporate Services).

Format: identical to decisions.py (see CONTRACT.md in this folder). This file is a proposal fragment: the builder does not
read it, and nothing here changes a content module. The Stage 4 consolidation step (Enterprise_Expansion_Plan.md §9.3
step 5) merges accepted entries into decisions.py.

Sources: Enterprise_Expansion_Plan.md §3, §4 and §9; Domain_Ownership_and_Conventions.md §2, §8, §13 to §16; the
Stage 4 briefs 41-44 in 00_Program/Expansion/Briefs/; the sibling brief 37_Enterprise_and_Operational_Risk.md
(CD-245, CD-249); a scan of content modules 01-36 on 2026-10-06 for "future owner 41" / "future 43" notes and for
system, application, bank account, seed and site references.

IDs CD-263 to CD-282 are reserved for this brief set (brief set A, domains 37-40, uses CD-243 to CD-262). Every entry
has status "Proposed"; where the business must choose, action is "SME decision" and the resolution gives the
recommended option. Working assumptions of the program lead (CD-143 accepted, the shared Business Line list (CD-209),
governance metadata in 21, per-attribute ownership with row rules, shared lists joined at consolidation) apply to every
entry. Names of objects in domains 38-40 are the names the 37 brief cites and must be confirmed against the 38-40 briefs.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. DECISIONS
# ---------------------------------------------------------------------------------------------------------------------

DECISIONS = [
    # ===================================== 41 Technology & Information Security =====================================
    {"id": "CD-263", "theme": "Technology", "title": "41 Application (APPL-) is the enterprise application inventory; every system reference in 01-36 resolves to it; the 21 interim 'System' list is retired",
     "domains": ["41", "21", "18", "09", "01", "28", "03"],
     "issue": "Every domain cites a system of record, but no domain masters what a system is. 21 holds an interim firm-defined 'System' list (Data Asset Hosting System, System of Record Designation Designated System, Record Governance Metadata System of Record and Source System), noted 'until the 41 application inventory exists (CD-160)'. 18 Portfolio Book of Record System is a firm-defined code noted 'future 41', and 18 Transaction Event Event Source System is another. 09 Code Mapping Source System and Reference Data Subscription Subscribing System, and 01 System Cross-Reference Source System, are firm-defined codes. 28's overview leaves 'SWIFT connectivity (41)'.",
     "resolution": "41 masters Application (APPL-), Application Ownership Assignment, Application Capability Mapping, Application Lifecycle Assessment, Application Interface and Application Recovery Profile. Re-type to Reference (Application, 41) with APPL- examples: 21 Hosting System, Designated System, System of Record, Source System (and retire the 21 list 'System'); 18 Book of Record System and Event Source System; 09 Code Mapping Source System and Subscribing System; 01 System Cross-Reference Source System (outsourced provider platforms are inventoried as Applications with hosting model 'Provider-Hosted', CD-147). 03 Activity Source System may follow (optional). SWIFT and host-to-host connectivity are Application Interfaces of type SWIFT. 21 System of Record Designation stays the only record of which application is authoritative for a taxonomy element; Application Capability Mapping carries no authority flag. 21 BI Tool is unchanged.",
     "rationale": "Closes CD-160's deferred item. One inventory lets lineage, resilience mapping (37) and access (41) join on the same key; the 21 designation keeps the governance fact in 21.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Chief Information Officer"},

    {"id": "CD-264", "theme": "Technology", "title": "14 Consuming Application and 04 Marketing System become profiles keyed by the 41 Application",
     "domains": ["41", "14", "04"],
     "issue": "14 Consuming Application (DAPP-) is an application list kept for market data declarations (Usage Mode, Non-Display Use Types, External Output, Declared to Vendor) with its own Application Name; CD-160 said it must not be extended into an inventory. 04 Marketing System (System Name, System Category) is a martech list. Both name the same systems the 41 inventory holds.",
     "resolution": "Option A (recommended): apply CD-144. 14 Consuming Application is keyed by APPL- (DAPP- retired; 14 Dataset Consumption and Entitlement 'Consuming Application' / 'Entitled Application' examples re-keyed); 14 keeps Usage Mode, Non-Display Use Types, External Output Indicator and Declared to Vendor Indicator; Application Name becomes a Derived copy (41). 04 Marketing System gains 'Inventoried Application' Reference (Application, 41); System Name becomes a Derived copy (41) and System Category stays 04's martech classification. Option B: keep DAPP- and add a reference to APPL- on the 14 profile.",
     "rationale": "Same pattern as 20 Employee / 03 Sales Person: the master holds identity, the profile holds what only the specialist function maintains.",
     "action": "SME decision", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Market Data"},

    {"id": "CD-265", "theme": "Technology", "title": "Identity and access: system access is 41; the person and lifecycle events are 20; licensed-data entitlements stay 14",
     "domains": ["41", "20", "14", "44"],
     "issue": "20's overview leaves 'identity and access entitlements (41)'. 14 Entitlement (ENT-) records users' and applications' rights to licensed datasets, including approval, provisioning and recertification dates, which look like access-management facts.",
     "resolution": "41 masters Digital Identity (workforce, external user, service and privileged accounts; owner EMP- or PTY-), Application Access Role, System Access Grant (ACSG-), Access Review Campaign and Access Review Decision. A grant references the 20 Employee Lifecycle Event (ELE-) that triggered it; 20 holds no access record. 14 Entitlement remains the license-counting record; a grant that provisions licensed data references ENT- (the link is held once, on 41). 44 Physical Access Zone Grant is a separate object; the two meet only through the holder EMP-.",
     "rationale": "System access is maintained by IT security under ISO 27001 A.5.15-5.18 and DORA Art 9; license counting is maintained by market data administration.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Information Security Officer"},

    {"id": "CD-266", "theme": "Technology", "title": "IT and security incidents: 41 holds the technical record; 37 holds the operational incident, the loss and the authority reports (aligned with CD-245)",
     "domains": ["41", "37", "44", "13", "12"],
     "issue": "The 37 brief (CD-245) holds the Operational Incident (OPINC-), its DORA major ICT-related incident classification and the Incident Regulatory Notification, and lists '41 security incident' as a source reference on the operational incident. 41 needs an incident record for ICT disruptions and cyber events, and SEC Regulation S-P (2024 amendments) requires an incident response program and customer notification determinations.",
     "resolution": "41 masters IT Incident (ITINC-; class service disruption, security event or data integrity), Security Incident Detail (attack vector, personal data affected, sensitive customer information compromised, customer notification determination and date, service provider notice received timestamp) and Problem Record. 41 holds no regulatory notification object and no 37 reference: the link is held once, on the 37 Operational Incident. Notices to affected customers are delivered as 13 or 12 communications. 44 Physical Security Incident and Health & Safety Incident follow the same rule. The 37 draft cites ITINC- (the 37 brief expected INC-).",
     "rationale": "One record per layer and one link direction; DORA reporting sits with the operational incident that 37 classifies.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Chief Information Security Officer"},

    {"id": "CD-267", "theme": "Technology", "title": "Change & Project Portfolio in 41: Project (PRJT-) and Project Scope Link resolve 36 Launch Project Code and CD-239",
     "domains": ["41", "36", "21", "38", "19"],
     "issue": "36 Product Change Initiative 'Launch Project Code' is text noted 'Future owner 41 Change & Project Portfolio (Stage 4)'; CD-239 says project management of large launches is 41. Data initiatives (21 data products, DQ remediation) and regulatory change programs (38) also run as projects.",
     "resolution": "41 masters Change Program, Project (PRJT-), Project Milestone, Project Status Report and Project Scope Link. Project Scope Link is the only link between a project and what it delivers (36 LCHG-, 21 DP- and DQI-, 41 APPL-, 38 regulatory change item). 36 Launch Project Code becomes a Derived copy (41) of the Project ID where Project Scope Link targets the LCHG- (example PRJT-2026-0114, which re-keys 'PRJ 2026 114'); 21 and 38 add no project reference. Project budgets reference 19 Financial Plan Version lines; capitalization is 19's decision (SME question).",
     "rationale": "One direction for the project link, as CD-237 did for board approvals.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Enterprise PMO"},

    {"id": "CD-268", "theme": "Technology", "title": "DORA register of information: 40 masters the register (with 14 data-vendor rows); 41 masters the IT services and applications it cites (aligned with CD-249)",
     "domains": ["41", "40", "14", "37"],
     "issue": "The program lead's Stage 4 scope placed the DORA ICT register with 41; the sibling 37 brief (CD-249) places the register of information in 40 (ICT Register of Information Entry) and the critical or important function designation in 37. 14 already holds ICT Third-Party Register Entry for data-vendor arrangements, with ICT Service Type and Supported Functions as text.",
     "resolution": "Recommended (coherent with CD-249): 40 masters the register of information; 14 ICT Third-Party Register Entry stays the data-vendor rows of it (no move); 37 masters Critical or Important Function and Resilience Resource Mapping. 41 masters IT Service (with ICT Service Type in the Implementing Regulation (EU) 2024/2956 taxonomy) and Application, and the 40 / 14 entries gain a 'Supported IT Service' Reference (IT Service, 41) in place of free-text service descriptions. 41 holds no contractual-arrangement, provider-criticality or function attribute. Alternative (the original scope): the register entry is drafted in 41 and the 14 object moves to 41 with names unchanged; choose one before drafting so that 40 and 41 do not both draft it. ICT Service Type is a shared-list candidate for 14, 40 and 41.",
     "rationale": "The register is a list of contractual arrangements (procurement data) annotated with ICT services (technology data) and functions (risk data); each annotation stays with its producer.",
     "action": "SME decision", "status": "Proposed", "priority": "High", "owner_role": "Head of Third-Party Risk"},

    {"id": "CD-269", "theme": "Technology", "title": "AI systems: use case in 21, model in 37, deployed system in 41",
     "domains": ["41", "21", "37"],
     "issue": "21 AI Use Case (AIU-) holds purpose, EU AI Act risk category and operator roles, and 'Model Name' as text pending the 37 model inventory (CD-159). The EU AI Act places deployer obligations (Art 26: use per instructions, human oversight, log retention, monitoring) on the system as deployed, which no domain holds.",
     "resolution": "41 masters AI System Profile (an attribute group of Application: provider PTY-, general-purpose model basis, deployed model Reference (Model Inventory Entry, 37), log retention period, human oversight assignee, input data controls) and AI System Use Case Link (APPL- x AIU- x period, the only link). 21 keeps use-case governance and adds no application reference; 37 keeps the model inventory, tiering and validation.",
     "rationale": "Three facts with three producers: the business use (data governance), the model (model risk), the running system (technology).",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Information Officer"},

    {"id": "CD-270", "theme": "Technology", "title": "Technology resilience and testing in 41; operational resilience in 37; Information Classification stewarded by 21",
     "domains": ["41", "37", "21"],
     "issue": "37 (CD-249) masters important business services, impact tolerances, BCP and resilience tests and expects 'DR test result received from 41'. CD-148 left open whether 21 or 41 stewards the shared Information Classification list.",
     "resolution": "41 masters Application Recovery Profile (recovery tier, RTO, RPO, DR strategy), Security & Resilience Test (penetration test, TLPT, ICT DR failover, red team) and Vulnerability Finding (VULN-); risk acceptance of a vulnerability is a 37 Risk Issue action. 37 Resilience Test references the 41 test for DR results. The Information Classification shared list stays stewarded by 21 (recommended); 41 applies it as an access-role data ceiling and does not create a security classification list.",
     "rationale": "ICT continuity is a technology record; tolerances and business continuity are risk records; one classification scheme.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Medium", "owner_role": "Chief Information Security Officer"},

    # ===================================== 42 Corporate Communications & Public Affairs =====================================
    {"id": "CD-271", "theme": "Communications", "title": "Brand register (BRD-) moves from 04 to 42 with names unchanged; stewardship per brand level",
     "domains": ["42", "04", "12"],
     "issue": "04 Brand (BRD-; Brand ID, Brand Name, Brand Level, Parent Brand, Brand Status, Brand Permitted Jurisdictions) holds every brand from the corporate masterbrand to product range brands. CD-144 lists '42 corporate brand / 04 BRD-' as a shared-concept pair. 12 Report Template 'Brand' references BRD- ('owned by 04').",
     "resolution": "Option A (recommended): move 04 Brand and the lists Brand Level and Brand Status to 42 with names unchanged; BRD- transfers to 42 and keeps 04's format (BRD-003). Stewardship per row: Corporate Brand, Affiliate / Boutique Brand and Co-Brand rows by Corporate Communications; Sub-Brand and Product Range Brand rows by 04 Marketing (row rule in the object note). 04 keeps Marketing Theme and Messaging Pillar; the 12 note becomes 'owned by 42'. 42 adds Brand Standard Version, Brand Use Authorization and Reputation Measurement. Option B: 04 keeps the register; 42 holds only Brand Standard Version and Brand Use Authorization keyed by BRD-.",
     "rationale": "One register with per-row stewardship, as CD-143 does for parties; the light footprint (one 12 reference) makes the move cheap.",
     "action": "SME decision", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Corporate Communications"},

    {"id": "CD-272", "theme": "Communications", "title": "Media, publications, crisis communications, corporate events and awards: 42 masters the corporate message; 04, 08, 11 and 13 keep their records",
     "domains": ["42", "04", "08", "11", "13", "12", "37", "39", "41", "02"],
     "issue": "04 holds Digital Property (WEB-), Social Media Account (SOC-, with type 'Corporate Brand'), Marketing Event (EVT-) and content assets; 08 reviews communications (REV-); 11 Award (AWD-) holds product and manager awards; 13 delivers shareholder communications. Press releases, media inquiries, coverage, corporate publications, crisis statements and corporate events have no owner.",
     "resolution": "42 masters Media Contact Profile (keyed by PTY-), Media Inquiry (MEDQ-), Press Release (NEWS-), Media Coverage Item (COVG-), Spokesperson Authorization, Corporate Publication and Publication Source Link (42 publishes; 20, 34, 43 and 44 produce the figures), Internal Communication (with audiences and aggregate engagement), Communications Issue (CRIS-), Issue Statement, Crisis Communication Plan, Corporate Event and Corporate Award Entry. 04 keeps WEB-, SOC- and EVT- as the only registers (propose Property Type value 'Corporate Website / Newsroom'). 08 Compliance Review is referenced where a release is a regulated communication. 11 AWD- stays the only fund and manager award result; 42 holds entries for any award and the result only for firm-level awards. A Communications Issue references its trigger once (37 OPINC-, 41 ITINC-, 39 Legal Matter, 44 incidents); those domains hold no reference back. Propose 02 Party Role Type values Journalist, Media Outlet, Award Organizer.",
     "rationale": "Corporate statements are approved by leadership and corporate communications, not by the product marketing chain; channels and compliance records stay with their owners.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Corporate Communications"},

    {"id": "CD-273", "theme": "Communications", "title": "Government relations and lobbying disclosure in 42; political contributions and pay-to-play in 38",
     "domains": ["42", "38", "08", "19", "02"],
     "issue": "The plan places lobbying disclosures in 42 and political contributions (Rule 206(4)-5) in 38. The LDA LD-203 semiannual report discloses FECA contributions by the registrant and its lobbyists, and LD-2 reports include the lobbying share of trade association dues; officials' hospitality is an 08 gifts and entertainment matter.",
     "resolution": "42 masters Public Policy Position (PUBP-), Consultation Response, Government Official Contact, Trade Association Membership, Lobbying Registration (LDA, EU Transparency Register, US states), Registered Lobbyist, Lobbying Disclosure Report (LOBR-; LD-2, LD-203, EU TR annual update) and Lobbying Report Issue Line. 38 masters political contribution records and pre-clearance; an LD-203 report references them and copies no amount. Government Official Contact references 08 GNE- for hospitality. The tax treatment of the dues lobbying portion (IRC 162(e)) is 19. Propose 02 Party Role Type values Government Official and Trade Association.",
     "rationale": "Same split as CD-233 (file vs produce): 42 files the lobbying disclosure, 38 owns the contribution facts.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Government Relations"},

    # ===================================== 43 Corporate Treasury & Capital =====================================
    {"id": "CD-274", "theme": "Treasury", "title": "Corporate bank accounts (BKAC-) mastered in 43; 19 Paying Bank Account re-typed; 28 safekeeping and 15 client accounts stay separate",
     "domains": ["43", "19", "28", "15", "02"],
     "issue": "19 Supplier Payment 'Paying Bank Account' is a firm-defined code 'until a bank account master exists in 43 or 19'; 19's scope defers bank accounts to 'future 43'. 28 Safekeeping Account (SKA-) holds fund and portfolio custody accounts and 15 Account holds client accounts, both easily confused with corporate bank accounts.",
     "resolution": "43 masters Corporate Bank Account (BKAC-), Bank Account Signatory, Bank Relationship Profile (keyed by PTY-), Bank Fee Statement, Bank Statement and Bank Statement Entry. The account references its cash GL account (19 GLA-), held once on 43. 19 Supplier Payment Paying Bank Account becomes Reference (Corporate Bank Account, 43). A corporate bank account is never a 28 SKA- or a 15 ACC-. Propose 02 Party Role Type value Relationship Bank.",
     "rationale": "Treasury opens, mandates and closes the accounts; the ledger only records them.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Group Treasurer"},

    {"id": "CD-275", "theme": "Treasury", "title": "Cash, funding, intercompany loans and corporate hedging: 43 decides, 19 books; portfolio and seed-book trades stay 25 / 26",
     "domains": ["43", "19", "10", "22", "25", "26", "30"],
     "issue": "30 Fund Credit Facility notes 'Borrowing by the GP or the firm is out of scope (future 43 / 19)'. 19 holds Intercompany Balance and 10 holds Intercompany Agreement (ICA-). Corporate FX hedges could be confused with 25 portfolio orders and 26 OTC trades, and FX rates are 22's.",
     "resolution": "43 masters Cash Position, Cash Forecast and lines, Short-Term Investment, Debt Facility (DEBT-), Facility Drawdown, Corporate Covenant Test, Intercompany Loan (ICLN-, referencing 10 ICA- where an agreement exists), Intra-Group Capital Transaction, Corporate Exposure, Treasury Deal (TDEAL-, under a 26 Trading Agreement TAGR-), Treasury Deal Valuation (rates as Derived copies of 22), Hedge Relationship (HEDG-) and Hedge Effectiveness Test. 19 keeps journals, balances and the Intercompany Balance match. Seed-book hedges traded through the OMS stay 25 / 26 records, which a Hedge Relationship may designate by reference. Fund-level facilities stay 30 FCF-.",
     "rationale": "Treasury decisions are evidenced before booking; trades of managed books are investment records.",
     "action": "Reference", "status": "Proposed", "priority": "Medium", "owner_role": "Group Treasurer"},

    {"id": "CD-276", "theme": "Treasury", "title": "Seed and co-investment capital mastered in 43 (SDCAP-); resolves Stage 1 item 12 and GAP-02-021; 18, 36 and 30 re-noted",
     "domains": ["43", "18", "15", "36", "30", "19", "20"],
     "issue": "Stage 1 consolidation item 12 asked for one owner of seed status: 18 Portfolio Proprietary Capital Indicator ('decided by 43') and GAP-02-021 (add a mastered Seed Capital Indicator to 15 Account). 36 Product Business Case Seed Capital Required and the Readiness Check workstream 'Seed Capital' are noted 'Future 43'. 30 Fund Profile holds GP Commitment Percentage, and the GP's actual commitment is a 30 Investor Commitment (ICMT-) on a 15 account. 20 holds employee co-investment awards.",
     "resolution": "43 masters Seed Capital Commitment (SDCAP-; types seed, incubation account, GP commitment, co-investment), Seed Capital Movement and Seed Position Valuation. 18 Proprietary Capital Indicator becomes a Derived copy (43): true while the book is the seed book of an active commitment. GAP-02-021 is closed without a mastered 15 attribute (any 15 indicator would be a Derived copy (43)). 36 Seed Capital Required stays a projection (note re-worded); 36 Readiness Check gains evidence Reference (Seed Capital Commitment, 43). 30 GP Commitment Percentage stays an LPA term; the commitment references ICMT-. Seed valuations are Derived copies of 27 NAV with 06 / 15 units, or of 30 CAPA- (row rule). 19 Consolidation Scope Entity keeps the consolidation decision and reads the ownership percentage. 20 employee co-investment awards are not firm capital.",
     "rationale": "Seed status is a balance-sheet decision made by treasury or a seed committee; every other domain sees its consequences.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Group Treasurer"},

    {"id": "CD-277", "theme": "Treasury", "title": "Regulatory capital calculated in 43 (RCAP-); 19 Regulatory Financial Return keeps the filing and derives the capital amounts",
     "domains": ["43", "19", "09", "39", "42"],
     "issue": "19 Regulatory Financial Return holds Capital Requirement Amount and Capital Resources Amount noted 'Reported value; capital management is 43'. No domain holds net capital computations (SEC Rule 15c3-1), MIFIDPRU own funds and K-factor requirements, the ICARA, Luxembourg and Irish ManCo own funds, or early-warning notifications (Rule 17a-11, FINRA 4110).",
     "resolution": "43 masters Regulated Entity Capital Profile (entity x regime, permission from 09 AUTH-), Capital Requirement Calculation (RCAP-), Capital Requirement Component, ICARA Assessment (approved by a 39 Corporate Resolution) and Capital Adequacy Notification. 19 Capital Requirement Amount and Capital Resources Amount become Derived copies (43) of the calculation at the return's period end; the return, its status and due date stay 19. 42 Corporate Publication publishes the MIFIDPRU 8 disclosure by reference.",
     "rationale": "The calculation is produced by treasury or regulatory finance and drives decisions daily; the return is one filing of it.",
     "action": "Reference", "status": "Proposed", "priority": "High", "owner_role": "Head of Regulatory Capital"},

    {"id": "CD-278", "theme": "Treasury", "title": "Corporate insurance program in 43 (INPOL-); fund fidelity bond stays 35; loss recoveries derived in 37; folding rule if there is no treasury function",
     "domains": ["43", "35", "37", "39", "19"],
     "issue": "35 Fund Fidelity Bond masters the fund's Rule 17g-1 bond. The firm's E&O / professional indemnity, D&O, crime, cyber and property policies have no owner, and the 37 brief holds insurance recovery on Loss Event Amount. The plan marks 43 optional: 'fold into 19 if the client has no separate treasury function'.",
     "resolution": "43 masters Corporate Insurance Policy (INPOL-), Insurance Coverage Layer and Insurance Claim. A joint program references the 35 Fund Fidelity Bond and copies none of it. The claim references the 37 Operational Loss Event or 39 Legal Matter (one direction); 37 Loss Event Amount rows of component 'recovery from insurance' are Derived copies (43). Folding rule: if the client has no treasury function, every 43 family moves to 19 with object and attribute names unchanged; only the domain number, the TY- family codes (to FI-) and the prefix owner change in the registers.",
     "rationale": "Insurance placement and claims are a treasury or risk-finance function in most asset managers; the fund bond is a fund governance record.",
     "action": "SME decision", "status": "Proposed", "priority": "Medium", "owner_role": "Group Treasurer"},

    # ===================================== 44 Workplace & Corporate Services =====================================
    {"id": "CD-279", "theme": "Workplace", "title": "Sites, leases and facility assets: 09 keeps the SITE- key, 44 masters the Site Profile, leases and facility assets; lease accounting produced by 19",
     "domains": ["44", "09", "19", "20", "41", "39"],
     "issue": "09 Office Location (SITE-) is a four-attribute organizational reference used by 20 Work Location and Position Location. 19 has no lease, right-of-use or fixed-asset object (only the statement class 'Fixed Assets and Right-of-Use Assets'). 41 holds IT assets.",
     "resolution": "09 keeps Office Location and SITE- as the only site key (non-office sites are added there first). 44 masters Site Profile (keyed by SITE-; never repeats country, time zone or legal entity), Building Space, Site Occupancy Measurement, Lease (LEASE-), Leased Space, Lease Payment Schedule Line, Lease Option & Critical Date, Facility Asset, Facility Work Order (FMWO-), Planned Maintenance Schedule and Space Reservation. Lease Accounting Measurement (ASC 842 / IFRS 16 classification, discount rate, initial ROU asset and liability) is drafted as an attribute group of Lease with a row-ownership note naming the 19 Controller as producer; if lease accounting runs in the ERP it moves to 19 unchanged. Journals and balances are 19; lease documents are 39 contracts; anything in the 41 CMDB is never a Facility Asset. Propose 19 Journal Source values 'Lease Accounting' and 'Travel & Expense'.",
     "rationale": "Lease abstraction is produced from the lease document by real estate; the accounting measurement is produced by finance; the SITE- key is already referenced by 20.",
     "action": "SME decision", "status": "Proposed", "priority": "Low", "owner_role": "Head of Corporate Real Estate"},

    {"id": "CD-280", "theme": "Workplace", "title": "Travel and expense, physical security and health and safety in 44; payment in 19 / 20; compliance in 08; incidents linked from 37; casual visitors are not 02 parties",
     "domains": ["44", "19", "20", "08", "37", "41", "02"],
     "issue": "Expense reports are paid through 19 payables or 20 payroll and posted by 19; client entertainment is an 08 gifts and entertainment record (GNE-). Physical security and workplace injuries have no owner. CD-143 makes every external individual a 02 party, which would put every office visitor in the party master.",
     "resolution": "44 masters Expense Report (EXPR-), Expense Line (references GNE- for entertainment; rechargeable PRD- for private fund deal costs), Corporate Card (masked number only), Card Transaction, Travel Booking (TRIP-), Expense Policy Limit, Access Badge (BADGE-), Physical Access Zone Grant, Visitor Registration, Physical Security Incident, Health & Safety Incident (HSEI-), Workplace Risk Assessment and Emergency Role Assignment. Reimbursement is a 19 Supplier Payment or a 20 Payroll Result (row rule). 37 Operational Incident references 44 incidents (one direction, as CD-266). Exception to CD-143 (like job candidates in 20): casual visitors are recorded by name as PII text; a visitor who is already a 02 party is referenced by PTY-.",
     "rationale": "These records live in the T&E platform, badge system and EHS tool; a visitor log is not a relationship with the firm.",
     "action": "Reference", "status": "Proposed", "priority": "Low", "owner_role": "Head of Workplace Services"},

    {"id": "CD-281", "theme": "Workplace", "title": "Operational footprint in 44 feeds 34 entity-level metrics; financed emissions stay 34",
     "domains": ["44", "34", "42"],
     "issue": "34 Portfolio Sustainability Metric has a Metric Legal Entity for entity-level PAI and climate reports, and 34 Sustainability Indicator Definition has GHG scope values. The firm's own Scope 1, Scope 2 and operational Scope 3 (business travel, commuting, purchased goods, waste) have no owner, and SB 253, CSRD (after Omnibus I) and UK SECR may require them.",
     "resolution": "44 masters Utility Consumption Record and Operational Emission Record (entity or site x year x scope category x method; location- and market-based Scope 2 as separate rows). Scope 3 category 15 (financed emissions) stays 34. A 34 Portfolio Sustainability Metric row for an own-operations indicator is a Derived copy (44). 42 Corporate Publication publishes own-footprint figures by reference. Propose a shared GHG scope list (44 GHG Scope Category, 34 Sustainability Indicator Scope).",
     "rationale": "Facilities and travel data produce the operational footprint; investment data produce financed emissions.",
     "action": "Reference", "status": "Proposed", "priority": "Low", "owner_role": "Head of Corporate Sustainability"},

    # ===================================== Registers =====================================
    {"id": "CD-282", "theme": "Identifiers", "title": "Stage 4 brief set B registers: 28 prefixes reserved for 41-44, BRD- transfer, family codes, party roles, shared-list candidates and term conflicts",
     "domains": ["41", "42", "43", "44", "02", "04", "09", "21"],
     "issue": "The 41-44 drafts need reserved prefixes that cannot collide or be confused with the register, with each other or with the 37-40 reservations, and the terms they share with earlier domains need qualifiers.",
     "resolution": "Reserve APPL-, CFGI-, ACSG-, ITINC-, VULN-, CHRQ-, RLSE-, PRJT- (41); NEWS-, MEDQ-, COVG-, CRIS-, PUBP-, LOBR- (42); BKAC-, DEBT-, ICLN-, SDCAP-, RCAP-, TDEAL-, HEDG-, INPOL- (43); LEASE-, FMWO-, BADGE-, HSEI-, EXPR-, TRIP- (44). Transfer BRD- from 04 to 42 under CD-271 option A. Each new prefix is at least two edits from, and no anagram of, every registered, proposed, renamed or retired prefix, the 37 reservations (RISK-, CNTRL-, OPINC-, LOSS-, ISSUE-, MODEL-, AUDIT-, AUDF-), the 38-40 names the 37 brief cites (EXAM-, POLCY-, LMAT-, CTRCT-, CGRES-, VENG-, OUTS-) and each other. Rejected: APP-, CITM-, ACG-, SAG-, ACCS-, ITIN-, CHG-, RFC-, REL-, RELS-, PROJ-, PRJ-, PJT-, PREL-, PRS-, MINQ-, CLIP-, MCOV-, PPOS-, POSN-, PLCY-, ADVO-, BACC-, CBA-, BKA-, SEED-, SCAP-, CAPC-, TDL-, TRSD-, INSP-, CINS-, INSR-, IPOL-, POLY-, LEAS-, LSE-, WORD-, CCRD-, CARD-. Five-letter prefixes (ITINC-, SDCAP-, TDEAL-, INPOL-, LEASE-, BADGE-) resolve in ownership.py. Family codes avoid printing registered prefixes (TY-IPG, not TY-INS). Domain code CP prints the renamed 07 prefix CP- (now CPRD-, CD-135): attribute IDs only, no record key starts with CP-. Business Domain shared list gains 37-44 values. 02 Party Role Type values proposed: ICT Service Provider, Security Testing Provider, Journalist, Media Outlet, Government Official, Trade Association, Award Organizer, Relationship Bank, Corporate Lender, Insurance Broker, Landlord, Facility Service Provider, Card Issuer, Travel Management Company. Shared-list candidates: ICT Service Type (14, 40, 41), GHG scope (34, 44), Award Result (11, 42), Reference Rate (26, 30, 43), Covenant Metric (30, 43), Environment (21, 41). Drafts publish KEY_FORMATS; term conflicts are listed below.",
     "rationale": "Stage 2 renamed eight prefixes at consolidation for confusability; checking now avoids that rework.",
     "action": "Retain - clarify", "status": "Proposed", "priority": "Low", "owner_role": "Head of Data Governance"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. PREFIXES (reserved by the briefs)
# ---------------------------------------------------------------------------------------------------------------------

PREFIXES = [
    # ---- 41 Technology & Information Security
    ("APPL-", "Application (enterprise application inventory)", "41", "Reserved", "Stage 4 brief (CD-263). APP- rejected (one letter from APV-, 19); two edits from DAPP- (14)."),
    ("CFGI-", "Configuration item", "41", "Reserved", "Stage 4 brief. CITM- rejected (anagram of ICMT-, 30; one letter from CTM-, 07)."),
    ("ACSG-", "System access grant (identity x access role x period)", "41", "Reserved", "Stage 4 brief (CD-265). ACG- (one letter from ACI-, ACM-, ACR-, ACT-), SAG- (one letter from SEG-) and ACCS- (one insertion from ACC-) rejected."),
    ("ITINC-", "IT incident (including security incidents)", "41", "Reserved", "Stage 4 brief (CD-266). ITIN- rejected (reads as the IRS ITIN). Two edits from OPINC- (37)."),
    ("VULN-", "Vulnerability finding", "41", "Reserved", "Stage 4 brief (CD-270)."),
    ("CHRQ-", "IT change request", "41", "Reserved", "Stage 4 brief. CHG- rejected (one deletion from LCHG-, 36); RFC- (one letter from RFP-, 03)."),
    ("RLSE-", "Application release", "41", "Reserved", "Stage 4 brief. REL- (one letter from RET-, REV-) and RELS- rejected."),
    ("PRJT-", "Project (Change & Project Portfolio)", "41", "Reserved", "Stage 4 brief (CD-267). PROJ- (one letter from PROL-, 16), PRJ- (PRP-, PRD-) and PJT- (PMT-) rejected."),
    # ---- 42 Corporate Communications & Public Affairs (BRD- is transferred from 04 under CD-271, see PREFIX_TRANSFERS)
    ("NEWS-", "Press release", "42", "Reserved", "Stage 4 brief (CD-272). PREL- rejected (one letter from PIEL-, 16); PRS- (PRX-, PRP-, PRD-)."),
    ("MEDQ-", "Media inquiry", "42", "Reserved", "Stage 4 brief (CD-272). MINQ- rejected (one insertion from MIN-)."),
    ("COVG-", "Media coverage item", "42", "Reserved", "Stage 4 brief (CD-272). CLIP- (one insertion from CIP-, 29) and MCOV- (one letter from RCOV-, 23) rejected."),
    ("CRIS-", "Communications issue or crisis", "42", "Reserved", "Stage 4 brief (CD-272). Two edits from RISK- (37), CIP-, CRR-, CRX-."),
    ("PUBP-", "Public policy position", "42", "Reserved", "Stage 4 brief (CD-273). PPOS- / POSN- (POS-), PLCY- (PLC-, PLY-), ADVO- (ADVA-) rejected; two edits from RPUB-."),
    ("LOBR-", "Lobbying disclosure report (LD-2, LD-203, EU TR update)", "42", "Reserved", "Stage 4 brief (CD-273). Two edits from LOT-, LOAD-, LOAN-, LOSS- (37)."),
    # ---- 43 Corporate Treasury & Capital
    ("BKAC-", "Corporate bank account", "43", "Reserved", "Stage 4 brief (CD-274). BACC- / CBA- / BKA- rejected (ACC-, CCA-, SKA-)."),
    ("DEBT-", "Corporate debt facility", "43", "Reserved", "Stage 4 brief (CD-275). Not FCF- (30 fund credit facility)."),
    ("ICLN-", "Intercompany loan", "43", "Reserved", "Stage 4 brief (CD-275). Two edits from ICA- and ICC- (10)."),
    ("SDCAP-", "Seed and co-investment capital commitment", "43", "Reserved", "Stage 4 brief (CD-276). SEED- rejected (one letter from FEED-, 06); SCAP- (one letter from SCAC-, 28)."),
    ("RCAP-", "Regulatory capital requirement calculation", "43", "Reserved", "Stage 4 brief (CD-277). CAPC- rejected (one letter from CAPA-, 30)."),
    ("TDEAL-", "Treasury deal (corporate FX, rate or deposit transaction)", "43", "Reserved", "Stage 4 brief (CD-275). TDL- (PDL-, 30) and TRSD- (TRD-, 11) rejected."),
    ("HEDG-", "Hedge relationship (hedge accounting designation)", "43", "Reserved", "Stage 4 brief (CD-275). Two edits from HLD-, LDG-, SEG-."),
    ("INPOL-", "Corporate insurance policy", "43", "Reserved", "Stage 4 brief (CD-278). INSP- / CINS- / INSR- (INS-, 17), IPOL- (VPOL-, 34) and POLY- (PLY-) rejected."),
    # ---- 44 Workplace & Corporate Services
    ("LEASE-", "Lease (real estate and non-IT equipment)", "44", "Reserved", "Stage 4 brief (CD-279). LEAS- (one letter from LEAD-, 04) and LSE- (LST-, 17) rejected."),
    ("FMWO-", "Facility work order", "44", "Reserved", "Stage 4 brief (CD-279). WORD- rejected (one letter from TORD-, 25)."),
    ("BADGE-", "Physical access badge", "44", "Reserved", "Stage 4 brief (CD-280)."),
    ("HSEI-", "Health and safety incident", "44", "Reserved", "Stage 4 brief (CD-280). Two edits from SEG-, MSE-, SSI-."),
    ("EXPR-", "Expense report", "44", "Reserved", "Stage 4 brief (CD-280). Two edits from EXEC-, ECR-, FXR-, EXAM- (38)."),
    ("TRIP-", "Travel booking (trip)", "44", "Reserved", "Stage 4 brief (CD-280). CCRD- / CARD- for corporate cards rejected (one letter from CPRD-, 07)."),
]

# Prefix ownership transfers proposed (not new reservations).
PREFIX_TRANSFERS = [
    ("BRD-", "Brand", "04", "42", "CD-271 option A; the 04 format BRD-<3 digits> is kept."),
]

# Key formats the briefs ask the drafts to publish (decisions.PREFIX_FORMATS tuple format).
PREFIX_FORMATS = [
    ("APPL-", "41", "APPL-<sequence, 5 digits>", "APPL-00412"),
    ("CFGI-", "41", "CFGI-<sequence, 7 digits>", "CFGI-0041877"),
    ("ACSG-", "41", "ACSG-<year>-<sequence, 8 digits>", "ACSG-2026-00418812"),
    ("ITINC-", "41", "ITINC-<year>-<sequence, 6 digits>", "ITINC-2026-004512"),
    ("VULN-", "41", "VULN-<year>-<sequence, 6 digits>", "VULN-2026-018832"),
    ("CHRQ-", "41", "CHRQ-<year>-<sequence, 6 digits>", "CHRQ-2026-007731"),
    ("RLSE-", "41", "RLSE-<application number, 5 digits>-<sequence, 4 digits>", "RLSE-00412-0087"),
    ("PRJT-", "41", "PRJT-<start year>-<sequence, 4 digits>", "PRJT-2026-0114"),
    ("NEWS-", "42", "NEWS-<year>-<sequence, 4 digits>", "NEWS-2026-0042"),
    ("MEDQ-", "42", "MEDQ-<year>-<sequence, 5 digits>", "MEDQ-2026-00318"),
    ("COVG-", "42", "COVG-<publication date YYYYMMDD>-<sequence, 5 digits>", "COVG-20261006-00012"),
    ("CRIS-", "42", "CRIS-<year>-<sequence, 3 digits>", "CRIS-2026-007"),
    ("PUBP-", "42", "PUBP-<sequence, 4 digits>; the version is a separate attribute", "PUBP-0031"),
    ("LOBR-", "42", "LOBR-<report type code>-<period>-<registration sequence, 3 digits>", "LOBR-LD2-2026Q3-001"),
    ("BKAC-", "43", "BKAC-<sequence, 5 digits>", "BKAC-00118"),
    ("DEBT-", "43", "DEBT-<sequence, 4 digits>", "DEBT-0003"),
    ("ICLN-", "43", "ICLN-<year>-<sequence, 4 digits>", "ICLN-2026-0012"),
    ("SDCAP-", "43", "SDCAP-<sequence, 5 digits>", "SDCAP-00041"),
    ("RCAP-", "43", "RCAP-<entity number, 4 digits>-<as-of date YYYYMMDD>-<version, 2 digits>", "RCAP-0003-20260930-01"),
    ("TDEAL-", "43", "TDEAL-<year>-<sequence, 6 digits>", "TDEAL-2026-000318"),
    ("HEDG-", "43", "HEDG-<sequence, 5 digits>", "HEDG-00027"),
    ("INPOL-", "43", "INPOL-<coverage line code>-<policy year>-<sequence, 2 digits>", "INPOL-DO-2026-01"),
    ("LEASE-", "44", "LEASE-<sequence, 5 digits>", "LEASE-00031"),
    ("FMWO-", "44", "FMWO-<year>-<sequence, 7 digits>", "FMWO-2026-0004512"),
    ("BADGE-", "44", "BADGE-<sequence, 7 digits>", "BADGE-0018832"),
    ("HSEI-", "44", "HSEI-<year>-<sequence, 4 digits>", "HSEI-2026-0017"),
    ("EXPR-", "44", "EXPR-<year>-<sequence, 7 digits>", "EXPR-2026-0418812"),
    ("TRIP-", "44", "TRIP-<year>-<sequence, 7 digits>", "TRIP-2026-0091377"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. TERM_CONFLICTS (for the Stage 4 consolidation)
# ---------------------------------------------------------------------------------------------------------------------

TERM_CONFLICTS = [
    {"term": "Incident",
     "usages": [("41", "IT Incident", "Technical record of an ICT disruption or security event"),
                ("37", "Operational Incident", "Operational risk event, classification and authority reports"),
                ("44", "Physical Security Incident; Health & Safety Incident", "Workplace events"),
                ("25", "Trade Error", "Trading error that may raise an operational incident")],
     "recommendation": "Never 'Incident' bare: IT Incident (41), Operational Incident (37), Physical Security Incident and Health & Safety Incident (44) (CD-266, CD-280)."},
    {"term": "Application / System",
     "usages": [("41", "Application", "Enterprise application inventory entry"),
                ("21", "System (interim list)", "Retired by CD-263"),
                ("14", "Consuming Application", "Market data usage profile of an application"),
                ("20", "Candidate Application", "Job application"),
                ("15", "Application Channel", "Account opening application")],
     "recommendation": "'Application' unqualified is the 41 inventory entry; qualify 'Job Application' (20) and 'Account Application' (15)."},
    {"term": "Project / Program / Initiative",
     "usages": [("41", "Project; Change Program", "Change & Project Portfolio"),
                ("36", "Product Change Initiative", "Change to a product"),
                ("05", "Partner Program", "Distribution partner program")],
     "recommendation": "Use 'Project' and 'Change Program' (41), 'Product Change Initiative' (36), 'Partner Program' (05). The family is 'Change & Project Portfolio'; 'portfolio' alone always means an 18 Portfolio."},
    {"term": "Access / Entitlement",
     "usages": [("41", "System Access Grant", "Role in an application"),
                ("14", "Entitlement", "Right to licensed data under a license"),
                ("28", "Corporate Action Entitlement", "Holder entitlement to an event"),
                ("44", "Physical Access Zone Grant", "Badge access to a zone")],
     "recommendation": "Qualify: System Access (41), Data Entitlement (14), Corporate Action Entitlement (28), Physical Access (44)."},
    {"term": "Asset",
     "usages": [("04", "Content Asset", "Marketing content"),
                ("41", "Configuration Item", "IT asset"),
                ("44", "Facility Asset", "Building plant and non-IT equipment"),
                ("21", "Data Asset", "Cataloged data")],
     "recommendation": "Never 'Asset' bare: Content Asset, IT Asset (Configuration Item), Facility Asset, Data Asset."},
    {"term": "Release",
     "usages": [("41", "Release", "Application software release"),
                ("27", "NAV release", "Publication of a NAV"),
                ("42", "Press Release", "Media statement")],
     "recommendation": "Qualify: Software Release (41), NAV Release (27), Press Release (42)."},
    {"term": "Brand",
     "usages": [("42", "Brand (moved from 04)", "Brand register"),
                ("04", "Marketing Theme / Messaging Pillar", "Campaign messaging")],
     "recommendation": "Brand is the 42 register (CD-271); 04 uses Marketing Theme for campaign-level identity."},
    {"term": "Event",
     "usages": [("04", "Marketing Event", "Client and prospect events"),
                ("42", "Corporate Event", "Non-marketing corporate events"),
                ("17", "Corporate Action Event", "Issuer event"),
                ("20", "Employee Lifecycle Event", "HR event")],
     "recommendation": "Always qualify the kind of event."},
    {"term": "Communication / Statement",
     "usages": [("13", "Shareholder Communication; Statement", "Delivered fund communications and account statements"),
                ("08", "FINRA communication category", "Regulated communications"),
                ("42", "Internal Communication; Issue Statement; Corporate Publication", "Corporate messages"),
                ("19", "Financial Statement", "Accounting statement"),
                ("43", "Bank Statement", "camt.053 statement")],
     "recommendation": "Qualify: Shareholder Communication, Internal Communication, Issue Statement, Account Statement, Financial Statement, Bank Statement."},
    {"term": "Account",
     "usages": [("15", "Account", "Client or investor account"),
                ("28", "Safekeeping Account", "Custody account"),
                ("19", "GL Account", "Ledger account"),
                ("43", "Corporate Bank Account", "Firm's own bank account"),
                ("44", "Corporate Card", "Card account")],
     "recommendation": "Never 'Account' bare outside 15 (CD-274)."},
    {"term": "Capital / Commitment",
     "usages": [("30", "Investor Commitment; Investor Capital Account", "Investor economics of private funds"),
                ("43", "Seed Capital Commitment; Capital Requirement Calculation", "Firm capital"),
                ("20", "Variable Compensation Award (co-investment)", "Employee awards")],
     "recommendation": "Qualify: Investor Commitment (30), Seed Capital Commitment (43), Regulatory Capital (43)."},
    {"term": "Facility / Covenant",
     "usages": [("30", "Fund Credit Facility; Covenant Test", "Fund-level borrowing"),
                ("43", "Debt Facility; Corporate Covenant Test", "Firm-level borrowing"),
                ("44", "Facility Asset; Facility Work Order", "Buildings")],
     "recommendation": "Qualify: Fund Credit Facility (30), Corporate Debt Facility (43), Facilities (44 buildings)."},
    {"term": "Policy",
     "usages": [("38", "Policy (policy library)", "Firm policies"),
                ("34", "Voting Policy", "Proxy voting policy"),
                ("43", "Corporate Insurance Policy", "Insurance contract"),
                ("42", "Public Policy Position", "Advocacy position"),
                ("44", "Expense Policy Limit", "Expense limit")],
     "recommendation": "'Policy' unqualified is the 38 policy library; qualify Insurance Policy, Voting Policy, Public Policy Position."},
    {"term": "Position",
     "usages": [("06", "Position", "Shareholder position"),
                ("18", "Holding", "Portfolio holding"),
                ("43", "Cash Position; Seed Position Valuation", "Treasury positions"),
                ("42", "Public Policy Position", "Advocacy")],
     "recommendation": "Qualify: Shareholder Position, Cash Position, Seed Position, Policy Position."},
    {"term": "Exposure / Hedge",
     "usages": [("31", "Portfolio Exposure", "Investment exposure"),
                ("43", "Corporate Exposure; Hedge Relationship", "Firm's own currency and rate exposure"),
                ("01", "Share class hedging", "Hedged share classes")],
     "recommendation": "Qualify: Portfolio Exposure (31), Corporate Exposure (43), Share Class Hedging (01)."},
    {"term": "Claim",
     "usages": [("28", "Class Action Claim", "Securities class action"),
                ("43", "Insurance Claim", "Claim under a corporate policy")],
     "recommendation": "Always qualify."},
    {"term": "Site / Office",
     "usages": [("09", "Office Location", "Organizational site key (SITE-)"),
                ("44", "Site Profile; Building Space", "Real estate profile of the site")],
     "recommendation": "SITE- is the one key (CD-279); 'Site Profile' names the 44 record."},
    {"term": "Emissions",
     "usages": [("34", "Financed emissions; Portfolio Sustainability Metric", "Investee emissions"),
                ("44", "Operational Emission Record", "Firm's own Scope 1-3 (excluding category 15)")],
     "recommendation": "Qualify: Financed Emissions (34), Operational Emissions (44) (CD-281)."},
    {"term": "Expense",
     "usages": [("27", "Fund Expense Accrual", "Fund expenses"),
                ("10", "Distribution Cost Item", "Distribution expense"),
                ("44", "Expense Report; Expense Line", "Employee travel and expense")],
     "recommendation": "Qualify: Fund Expense (27), Distribution Expense (10), Employee Expense (44)."},
    {"term": "Issue",
     "usages": [("37", "Risk Issue", "Risk and control issue"),
                ("21", "Data Quality Issue", "DQ issue"),
                ("42", "Communications Issue", "Reputational issue or crisis")],
     "recommendation": "Always qualify (37 brief and CD-272)."},
]
