"""Consolidation proposals from the W1 draft of Data Domain 01 Investment Product & Service Offering (wealth manager), 2026-10-14.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py,
shared_code_lists.py and jurisdiction.REMOVALS at the W1 merge. Formats follow CONTRACT.md in this folder. The brief is
00_Program/Rework/Briefs/01_Investment_Product_and_Service_Offering.md; it implements CW-003, CW-004, CW-022 and CW-036 to
CW-040 (proposals_wealth_w1.py) and drafts CW-901, the US-only pass of 01.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES (decisions.PREFIXES tuple format). None beyond the reserved OFFR-, ELIG-, TUP-, OFWN- (proposals_wealth_w1)
#    and the kept STR-, PRD-, SHC-, MND-, MDL-, BMK-, CMP-, RST-, CMT-, FSCH-. Service Tier is keyed by its tier code.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED MEMBERSHIPS: 01 local lists that carry a shared list's exact name. Values are the re-cut US values (CW-039);
#    value_map maps each local value to the shared code; new_values are values the shared list does not hold yet.
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Business Line", "local": "Business Line",
     "value_map": {"Direct Brokerage and Self-Directed Investing": "DIRECT_BROKERAGE", "Digital Advice": "DIGITAL_ADVICE",
                   "Human and Hybrid Advice": "HUMAN_HYBRID_ADVICE", "Proprietary Funds and ETFs": "PROPRIETARY_FUNDS_ETFS",
                   "Workplace Retirement Recordkeeping": "WORKPLACE_RETIREMENT", "Institutional Advisory": "INSTITUTIONAL_ADVISORY",
                   "Intermediary Channel": "INTERMEDIARY_CHANNEL", "Personal Trust Services": "PERSONAL_TRUST"},
     "new_values": ["DIRECT_BROKERAGE", "DIGITAL_ADVICE", "HUMAN_HYBRID_ADVICE", "PROPRIETARY_FUNDS_ETFS", "WORKPLACE_RETIREMENT",
                    "INSTITUTIONAL_ADVISORY", "INTERMEDIARY_CHANNEL", "PERSONAL_TRUST"],
     "note": "CW-004 values. The shared list in shared_code_lists.py still holds the six wholesale values (CD-209) until the "
             "program lead re-cuts it at merge (CW-004, CW-039). LOCAL_RENAMES currently renames 01 'Business Line' to "
             "'Client Segment' (CD-209): that entry must be removed and 01 registered as a member of the shared Business Line, "
             "otherwise the eight values appear under 'Client Segment'. The wholesale 01 values (Retail, Institutional, Wealth, "
             "Insurance, Retirement) were client segments, not business lines, and are dropped (CW-901). Codes are UPPER_SNAKE like every "
             "shared list; the CW-004 two-letter abbreviations (DB, DA, HA, PF, WR, IA, IC, TR) are kept in the descriptions. The 18 and "
             "21 memberships still map the wholesale six and need the same re-cut at W1b; the shared definition still says 'six lines'."},
    {"shared": "Investor Qualification Standard", "local": "Investor Qualification Standard",
     "value_map": {"None Evidenced": "NONE_EVIDENCED", "Accredited Investor": "ACCREDITED_INVESTOR", "Qualified Client": "QUALIFIED_CLIENT",
                   "Qualified Purchaser": "QUALIFIED_PURCHASER", "Qualified Institutional Buyer": "QUALIFIED_INSTITUTIONAL_BUYER"},
     "new_values": [],
     "note": "New 01 user (Feeder Access Terms.Required Investor Qualification, CW-038). AIFMD_PROFESSIONAL_INVESTOR not copied "
             "(CW-039; the steward 02 records its removal)."},
    {"shared": "Vehicle Type", "local": "Vehicle Type",
     "value_map": {"Open-Ended Fund": "OPEN_ENDED_FUND", "Exchange-Traded Fund": "EXCHANGE_TRADED_FUND", "Closed-End Fund": "CLOSED_END_FUND",
                   "Interval Fund": "INTERVAL_FUND", "Tender-Offer Fund": "TENDER_OFFER_FUND", "Feeder Fund": "FEEDER_FUND",
                   "Collective Investment Trust": "COLLECTIVE_INVESTMENT_TRUST", "Unit Investment Trust": "UNIT_INVESTMENT_TRUST",
                   "Private Fund (Drawdown)": "PRIVATE_FUND_DRAWDOWN", "Evergreen Private Fund": "EVERGREEN_PRIVATE_FUND",
                   "Separately Managed Account": "SEPARATELY_MANAGED_ACCOUNT", "Segregated Mandate": "SEGREGATED_MANDATE",
                   "Model Portfolio": "MODEL_PORTFOLIO"},
     "new_values": ["FEEDER_FUND", "TENDER_OFFER_FUND"],
     "note": "01 is steward. Add Feeder Fund and Tender-Offer Fund (CW-039); retire POOLED_PENSION_UNIT_LINKED_FUND (JURISDICTION). "
             "Open-Ended Fund description no longer names UCITS / OEIC."},
    {"shared": "Regulatory Regime", "local": "Regulatory Regime",
     "value_map": {"US 1940 Act Registered": "US_1940_ACT_REGISTERED", "US Private Fund 3(c)(1)": "US_PRIVATE_FUND_3_C_1",
                   "US Private Fund 3(c)(7)": "US_PRIVATE_FUND_3_C_7", "US Bank CIT": "US_BANK_CIT"},
     "new_values": [],
     "note": "01 is steward. US values only (CW-039); eleven EU, UK, Luxembourg, Irish and Cayman values retired (JURISDICTION). "
             "17 and 36 are direct users: check their examples."},
    {"shared": "MMF Type", "local": "MMF Type",
     "value_map": {"Government MMF": "GOVERNMENT_MMF", "Prime MMF - Institutional": "PRIME_MMF_INSTITUTIONAL",
                   "Prime MMF - Retail": "PRIME_MMF_RETAIL", "Tax-Exempt MMF": "TAX_EXEMPT_MMF"},
     "new_values": [],
     "note": "01 is steward. Rule 2a-7 values only (CW-039); the four EU MMFR values retired (JURISDICTION). 17 is a direct user."},
    {"shared": "Investor Category", "local": "Investor Type",
     "value_map": {"Retail": "RETAIL", "Institutional": "INSTITUTIONAL", "Accredited Investor": "ACCREDITED_INVESTOR",
                   "Qualified Purchaser": "QUALIFIED_PURCHASER"},
     "new_values": [],
     "note": "Steward 02. PROFESSIONAL, ELIGIBLE_COUNTERPARTY, QUALIFIED_INVESTOR removed from the 01 list (CW-039; JURISDICTION)."},
    {"shared": "Distribution Channel", "local": "Distribution Channel",
     "value_map": {"Direct Brokerage (Self-Directed)": None, "Advice Program": None, "Workplace Plan Menu": None,
                   "Intermediary": "INTERMEDIARY", "Institutional": "INSTITUTIONAL"},
     "new_values": ["DIRECT_BROKERAGE", "ADVICE_PROGRAM", "WORKPLACE_PLAN_MENU"],
     "note": "Steward 09; the shared list is re-cut at W4 (CW-039). 01 now uses the five wealth channels of the brief; the three "
             "new codes are proposed (DIRECT_TO_INVESTOR could map to DIRECT_BROKERAGE). Insurance / Unit-Linked removed "
             "(JURISDICTION); the other wholesale 01 values were re-cut, not removed for jurisdiction (CW-901)."},
    {"shared": "Audience Restriction", "local": "Audience Restriction",
     "value_map": {"Public / Retail": "PUBLIC_RETAIL", "Financial Professional Use Only": "FINANCIAL_PROFESSIONAL_ONLY",
                   "Institutional Use Only": "INSTITUTIONAL_ONLY", "Partner-Specific": "PARTNER_SPECIFIC",
                   "Client-Specific": "CLIENT_SPECIFIC", "Internal Use Only": "INTERNAL_ONLY"},
     "new_values": [],
     "note": "Steward 08. 'Professional Investors Only' (PROFESSIONAL_INVESTOR_ONLY, MiFID professional client) removed from the 01 list."},
    {"shared": "Share Class Type", "local": "Share Class Type",
     "value_map": {"Retail": "RETAIL", "Institutional": "INSTITUTIONAL", "Front-End Load": "FRONT_END_LOAD", "Level Load": "LEVEL_LOAD",
                   "Clean": "CLEAN", "Founder / Seed": "FOUNDER_SEED", "Employee": "EMPLOYEE", "ETF Share Class": "ETF_SHARE_CLASS",
                   "Internal": "INTERNAL"},
     "new_values": ["FRONT_END_LOAD", "LEVEL_LOAD"],
     "note": "01 is steward. Add Front-End Load and Level Load (IC line intermediary classes); retire PLATFORM_SUPER_CLEAN (UK RDR, JURISDICTION)."},
    {"shared": "Distribution Policy", "local": "Distribution Policy",
     "value_map": {"Accumulating": "ACCUMULATING", "Distributing": "DISTRIBUTING"},
     "new_values": [],
     "note": "01 is steward. Retire DISTRIBUTING_GROSS_INCOME (fees charged to capital, UK and Irish income-share practice; JURISDICTION). "
             "17 and 36 are direct users."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: local 01 lists that look like enterprise lists
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Firm Risk Rating", ["01", "02", "45", "46"],
     "The firm's 1-5 risk scale is shared by the share class rating (01), the investor profile risk tolerance (02), the "
     "recommendation match (45) and model risk levels (46/01). Candidate shared list stewarded by 01 or 45."),
    ("Offering Type", ["01", "15", "45", "46", "47"],
     "15 enrollment, 45 advice engagement, 46 program operations and 47 fee schedules classify by the same offering types; "
     "they should reference OFFR- and read the type, or register as direct users."),
    ("Comparison Operator", ["01", "33", "21"],
     "Generic operator list (At Least, Less Than, In List ...); 33 compliance rules and 21 DQ rules hold similar lists."),
    ("Availability Status", ["01", "05"],
     "Platform availability status (01) and partner shelf status (05, W4) share values (Available, Closed to New Investors)."),
    ("Discretion Type", ["01", "15"], "15 Program Enrollment holds discretion per enrollment (CW-032); same values."),
    ("Derivatives Category", ["01", "31", "35"],
     "Rule 18f-4 category; 31 risk (derivatives risk management program) and 35 (Form N-PORT / N-CEN) may hold it."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (decisions.TERM_CONFLICTS format), from the brief's watchlist and what the draft found
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Program",
     "usages": [("01", "Service Offering (OFFR-)", "An advice or service program the firm defines (digital advice, wrap fee program)."),
                ("50", "Sweep Program (SWP-)", "Bank sweep program with program banks."),
                ("46", "Managed account program operations", "Operational record of running a program's accounts.")],
     "recommendation": "'Advisory program' and 'service offering' name the 01 definition; '15 Program Enrollment' the account in it; "
                       "'sweep program' is always qualified (50).",
     "resolution": "Primary sense: 01 Service Offering. Other uses are qualified as Sweep Program (50) and program operations (46).",
     "status": "Resolved", "decision": "CW-036"},
    {"term": "Model",
     "usages": [("01", "Model Portfolio (MDL-)", "Target allocation a strategy or offering implements."),
                ("46", "Model assignment", "Which model an account follows."),
                ("37", "Model Inventory Entry", "Quantitative or risk model under model risk management.")],
     "recommendation": "Bare 'Model' is the 37 model (ownership alias); always write 'Model Portfolio' for 01 and 'model assignment' for 46.",
     "resolution": "Primary sense: 37 model inventory (existing alias). 01 and 46 are qualified.", "status": "Resolved", "decision": "CW-009"},
    {"term": "Fee",
     "usages": [("01", "Management Fee / Other Ongoing Fees / Cost Disclosure (FSCH-)", "Prospectus expense terms of a share class."),
                ("47", "Fee schedule", "Client fees for advice, commission and account services, and their billing."),
                ("27", "Fund expense accrual", "Accrued expenses in the fund's books.")],
     "recommendation": "'Fund expense' or 'fund fee schedule' for 01, 'client fee schedule' for 47, 'expense accrual' for 27; "
                       "Offering Fee Schedule Link always points to the 47 client fee schedule.",
     "resolution": "Primary sense: 47 client fee. 01 fund expense terms and 27 accruals are qualified.", "status": "Resolved",
     "decision": "CW-036"},
    {"term": "Plan",
     "usages": [("01", "Offering Type 'Planning Only'", "An offering that delivers a financial plan."),
                ("45", "Financial plan", "The plan and its versions."),
                ("16", "Retirement plan", "A recordkept workplace plan.")],
     "recommendation": "'Financial plan' (45), 'retirement plan' (16 / 02); 01 says 'planning offering'.",
     "resolution": "No bare 'Plan' in 01.", "status": "Resolved", "decision": "CW-036"},
    {"term": "Investor Qualification",
     "usages": [("01", "Investor Eligibility.Eligible Investor Type (Investor Type: Accredited Investor, Qualified Purchaser)", "Share class eligibility."),
                ("01", "Feeder Access Terms.Required Investor Qualification (shared Investor Qualification Standard)", "Feeder qualification."),
                ("02", "Investor qualification evidence", "What the client has evidenced.")],
     "recommendation": "At W5 drop Accredited Investor and Qualified Purchaser from the Investor Type list so Eligible Investor Type "
                       "carries only the investor category, and qualification uses the shared Investor Qualification Standard.",
     "status": "SME", "decision": "CW-039"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION (jurisdiction.REMOVALS entry format; CW-022). A whole removed object or code list has attribute "".
# ---------------------------------------------------------------------------------------------------------------------
_D, _C = "01", "CW-901"


def _j(obj, attr, regime, note):
    return {"domain": _D, "object": obj, "attribute": attr, "regime": regime, "decision": _C, "note": note}


JURISDICTION = [
    # Objects
    _j("Target Market", "", "MiFID II", "MiFID II product governance target market (9 attributes: Target Investor Type, Knowledge & Experience, Ability to Bear Losses, Risk Tolerance, Client Objective, Minimum Investment Horizon, Sustainability Preferences Met, Distribution Strategy, Negative Target Market), exchanged through FinDatEx EMT. Suitability and best-interest evidence is 45; the product's risk is the Firm Risk Rating."),
    _j("Country Registration", "", "UCITS", "UCITS and AIFMD marketing passports and national registrations (6 attributes: Registration Country, Registration Status, Registration Date, Permitted Investor Type, Marketing Basis, Local Facilities / Paying Agent). US registration and state notice filings of registered funds are 35 Fund Regulatory Filing (SME question 3)."),
    _j("Share Class Tax Reporting", "", "Other EU/UK", "UK HMRC reporting fund status, German InvStG partial exemption and Austrian OeKB reporting (4 attributes: UK Reporting Fund Status, UK Reporting Fund Status Effective Date, German Investment Tax Classification, Austrian Tax Reporting Indicator). US distribution character is 27."),
    # Attributes of kept objects
    _j("Regulatory Classification", "MiFID Complexity", "MiFID II", "Complex / non-complex under MiFID II. CFI Code and US Fund Type stay."),
    _j("ESG Classification", "SFDR Classification", "SFDR", "SFDR Article 6 / 8 / 9. ESG Investment Approach and ESG Term in Name Indicator (SEC Rule 35d-1) stay."),
    _j("ESG Classification", "Sustainability Label", "FCA", "UK FCA SDR labels and EU national labels (ISR, Towards Sustainability, LuxFLAG, FNG-Siegel)."),
    _j("ESG Classification", "Minimum Sustainable Investment %", "SFDR", "SFDR pre-contractual commitment."),
    _j("ESG Classification", "Minimum Taxonomy-Aligned Investment %", "EU Taxonomy", "EU Taxonomy alignment commitment (SFDR RTS)."),
    _j("ESG Classification", "Principal Adverse Impacts Considered", "SFDR", "SFDR principal adverse impacts."),
    _j("Product Risk Indicator", "Summary Risk Indicator (SRI)", "PRIIPs", "PRIIPs KID SRI, a derived copy of 31 (CD-212). Replaced by Firm Risk Rating (renamed from Local Regulatory Risk Rating) and Derivatives Risk Category (SEC Rule 18f-4)."),
    _j("Product Risk Indicator", "SRRI", "UCITS", "UCITS KIID SRRI, a derived copy of 31 (CD-212)."),
    _j("Product Risk Indicator", "Global Exposure Method", "UCITS", "UCITS global exposure (commitment / VaR); leverage risk re-sourced to SEC Rule 18f-4 in Leverage Calculation Method and Derivatives Risk Category."),
    _j("Investment Objective & Policy", "Recommended Holding Period", "PRIIPs", "PRIIPs KID recommended holding period."),
    _j("Cost Disclosure", "Ongoing Charges Figure (OCF)", "UCITS", "UCITS KIID ongoing charges; the Form N-1A expense ratios stay and Acquired Fund Fees and Expenses is added."),
    _j("Cost Disclosure", "Transaction Costs", "PRIIPs", "PRIIPs slippage methodology."),
    _j("Cost Disclosure", "Ex-Ante Ongoing Costs", "MiFID II", "MiFID II ex-ante costs and charges disclosure."),
    _j("Other Ongoing Fees", "Trail Commission Indicator", "MiFID II", "Trail commission / retrocession flag (MiFID II inducements, UK RDR). US distribution payments are the 12b-1 and shareholder servicing fees, which stay."),
    _j("Income Distribution", "Fees Charged to Capital Indicator", "UK market practice", "Charging fees to capital to enhance distributable income is UK and Irish (COLL / UCITS) income-share practice; US RICs do not use it."),
    _j("Product Tax Status", "CRS Entity Classification", "CRS", "OECD CRS entity classification; the US does not apply CRS (CW-039). FATCA GIIN stays."),
    _j("External Classification", "EFAMA European Fund Category", "EU market practice", "EFAMA European Fund Classification. Morningstar, Lipper and ICI stay."),
    _j("External Classification", "IA Sector", "UK market practice", "UK Investment Association sectors."),
    _j("Security Identifier", "SEDOL", "UK market practice", "LSEG SEDOL. The firm lists and distributes its own share classes in the US only and never requests this number (CD-154 covers own-class identifiers); if a vendor assigns one to an own ETF it is held, if ever, as a 17 Instrument Identifier (Derived from Own Share Class Indicator = N). ISIN, CUSIP, FIGI and FISN stay; readers are re-pointed to 17 at merge."),
    _j("Security Identifier", "Valoren", "Other non-US", "Swiss SIX Valoren number. The firm lists and distributes its own share classes in the US only and never requests this number (CD-154 covers own-class identifiers); if a vendor assigns one to an own ETF it is held, if ever, as a 17 Instrument Identifier (Derived from Own Share Class Indicator = N)."),
    _j("Security Identifier", "WKN", "EU market practice", "German WKN. The firm lists and distributes its own share classes in the US only and never requests this number (CD-154 covers own-class identifiers); if a vendor assigns one to an own ETF it is held, if ever, as a 17 Instrument Identifier (Derived from Own Share Class Indicator = N)."),
    _j("Benchmark", "BMR Register Status", "BMR", "EU / UK BMR register status, a derived copy of 14 (CD-024). Benchmark Administrator is re-sourced to the IOSCO principles."),
    _j("Product Governance", "Value Assessment Outcome", "Consumer Duty", "UK FCA COLL assessment of value and Consumer Duty fair value. Product approval and review dates stay, re-sourced to FINRA Notice to Members 05-26."),
    # Whole code lists removed
    _j("Code list: Knowledge & Experience", "", "MiFID II", "Basic, Informed, Advanced (FinDatEx EMT)."),
    _j("Code list: Ability to Bear Losses", "", "MiFID II", "No Capital Loss, Limited Capital Loss, No Capital Guarantee, Loss Beyond Capital (FinDatEx EMT)."),
    _j("Code list: Client Objective", "", "MiFID II", "Preservation, Growth, Income, Hedging, Option or Leveraged, Other (FinDatEx EMT)."),
    _j("Code list: Distribution Strategy", "", "MiFID II", "Execution Only, Execution with Appropriateness, Non-Advised, Investment Advice, Portfolio Management. Shared list retired (CW-039)."),
    _j("Code list: Marketing Basis", "", "UCITS", "UCITS Passport, AIFMD Marketing Passport, National Private Placement, Domestic Authorization, Professional Investors Only (Exempt); UCITS and AIFMD."),
    _j("Code list: Registration Status", "", "UCITS", "Registered, Pending, Notified, Private Placement Only, Deregistered; used only by Country Registration (UCITS and AIFMD)."),
    _j("Code list: MiFID Complexity", "", "MiFID II", "Complex, Non-Complex."),
    _j("Code list: SFDR Classification", "", "SFDR", "Article 6, Article 8, Article 8 with Sustainable Investment, Article 9, Not in Scope."),
    _j("Code list: Sustainability Label", "", "FCA", "UK SDR labels and EU national labels (nine values)."),
    _j("Code list: Risk Measurement Method", "", "UCITS", "Commitment, Relative VaR, Absolute VaR (UCITS global exposure); the US VaR tests are in Leverage Method (Rule 18f-4)."),
    _j("Code list: CRS Classification", "", "CRS", "Investment Entity, Active NFE, Passive NFE. Shared CRS Entity Classification retired (CW-039)."),
    _j("Code list: German Investment Tax Classification", "", "Other EU/UK", "German InvStG fund types (five values)."),
    _j("Code list: Value Assessment Outcome", "", "Consumer Duty", "Value Delivered, Value Delivered - Action Required, Value Not Delivered (UK FCA COLL)."),
    # Code-list values
    _j("Code list: Regulatory Regime", "UCITS", "UCITS", ""),
    _j("Code list: Regulatory Regime", "UK UCITS", "UCITS", "UK UCITS."),
    _j("Code list: Regulatory Regime", "EU AIF", "AIFMD", ""),
    _j("Code list: Regulatory Regime", "ELTIF", "Other EU/UK", "EU ELTIF Regulation."),
    _j("Code list: Regulatory Regime", "EU MMF", "Other EU/UK", "EU Money Market Funds Regulation."),
    _j("Code list: Regulatory Regime", "UK NURS", "FCA", "UK non-UCITS retail scheme (FCA COLL)."),
    _j("Code list: Regulatory Regime", "UK QIS", "FCA", "UK qualified investor scheme (FCA COLL)."),
    _j("Code list: Regulatory Regime", "Lux SIF", "AIFMD", "Luxembourg specialized investment fund."),
    _j("Code list: Regulatory Regime", "Lux RAIF", "AIFMD", "Luxembourg reserved alternative investment fund."),
    _j("Code list: Regulatory Regime", "Irish QIAIF", "AIFMD", "Irish qualifying investor AIF."),
    _j("Code list: Regulatory Regime", "Cayman Regulated Mutual Fund", "Other non-US", "Cayman (UK overseas territory) CIMA regime, removed per the brief; a client firm with offshore feeders restores it."),
    _j("Code list: Legal Form", "SICAV", "UCITS", "Luxembourg / EU fund company form."),
    _j("Code list: Legal Form", "SICAF", "AIFMD", "Luxembourg closed-ended fund company form."),
    _j("Code list: Legal Form", "FCP", "UCITS", "Luxembourg / French contractual fund form."),
    _j("Code list: Legal Form", "ICAV", "UCITS", "Irish collective asset-management vehicle."),
    _j("Code list: Legal Form", "Investment Company (PLC)", "UCITS", "Irish / UK investment company PLC."),
    _j("Code list: Legal Form", "Unit Trust", "UK market practice", "UK authorized unit trust (the US unit investment trust is a Vehicle Type)."),
    _j("Code list: Legal Form", "OEIC / ICVC", "FCA", "UK open-ended investment company."),
    _j("Code list: Legal Form", "Authorised Contractual Scheme", "FCA", "UK authorized contractual scheme."),
    _j("Code list: Legal Form", "SCSp", "AIFMD", "Luxembourg special limited partnership."),
    _j("Code list: MMF Type", "Public Debt CNAV", "Other EU/UK", "EU MMFR."),
    _j("Code list: MMF Type", "LVNAV", "Other EU/UK", "EU MMFR."),
    _j("Code list: MMF Type", "Short-Term VNAV", "Other EU/UK", "EU MMFR."),
    _j("Code list: MMF Type", "Standard VNAV", "Other EU/UK", "EU MMFR."),
    _j("Code list: Party Role Type", "Management Company", "UCITS", "UCITS management company (ManCo); the US fund's investment adviser is the Investment Adviser role."),
    _j("Code list: Party Role Type", "AIFM", "AIFMD", ""),
    _j("Code list: Party Role Type", "Depositary / Trustee", "UCITS", "UCITS / AIFMD depositary; replaced by Trustee (CIT or trust-form fund) next to Custodian."),
    _j("Code list: Party Role Type", "Paying / Facilities Agent", "UCITS", "Local paying and facilities agent of a UCITS registration."),
    _j("Code list: Document Type", "KID (PRIIPs)", "PRIIPs", "The US summary prospectus (Rule 498) stays."),
    _j("Code list: Document Type", "KIID (UCITS)", "UCITS", ""),
    _j("Code list: Document Type", "SFDR Pre-Contractual Annex", "SFDR", ""),
    _j("Code list: Document Type", "SFDR Periodic Annex", "SFDR", ""),
    _j("Code list: Document Type", "Consumer-Facing Disclosure", "FCA", "UK SDR consumer-facing disclosure."),
    _j("Code list: Document Type", "Assessment of Value Report", "Consumer Duty", "UK FCA COLL assessment of value report."),
    _j("Code list: Investor Type", "Professional", "MiFID II", "MiFID professional client (CW-039)."),
    _j("Code list: Investor Type", "Eligible Counterparty", "MiFID II", "MiFID eligible counterparty (CW-039)."),
    _j("Code list: Investor Type", "Qualified Investor", "Other EU/UK", "Swiss CISA / EU well-informed investor (CW-039)."),
    _j("Code list: Leverage Method", "Gross Method", "AIFMD", "AIFMD leverage method; re-cut to the SEC Rule 18f-4 VaR tests."),
    _j("Code list: Leverage Method", "Commitment Method", "AIFMD", "AIFMD leverage method."),
    _j("Code list: Anti-Dilution Mechanism", "Dilution Levy", "UK market practice", "UK dilution levy; the US redemption fee (Rule 22c-2) is added."),
    _j("Code list: Anti-Dilution Mechanism", "Dual Pricing", "UK market practice", "UK dual-priced unit trusts."),
    _j("Code list: Pricing Model", "Dual Price (Bid / Offer)", "UK market practice", "UK dual-priced unit trusts; US funds are single priced (Rule 22c-1)."),
    _j("Code list: Distribution Policy", "Distributing - Gross Income", "UK market practice", "Fees charged to capital (UK and Irish income shares)."),
    _j("Code list: Pricing Basis", "Historic", "UK market practice", "Historic pricing; US redeemable securities are forward priced (SEC Rule 22c-1)."),
    _j("Code list: Anti-Dilution Mechanism", "Full Swing Pricing", "EU market practice", "Every-day swing is European practice; Rule 22c-1(a)(3) swings only past a swing threshold (Partial Swing Pricing stays)."),
    _j("Code list: Derivatives Usage", "Hedging and EPM", "UCITS", "Efficient portfolio management is a UCITS concept; Hedging Only and Investment Purposes stay."),
    _j("Code list: Audience Restriction", "Professional Investors Only", "MiFID II", "MiFID professional client audience."),
    _j("Code list: Share Class Type", "Platform / Super-Clean", "UK market practice", "UK RDR platform and super-clean classes; Clean stays (US clean shares)."),
    _j("Code list: Vehicle Type", "Pooled Pension / Unit-Linked Fund", "EU market practice", "EU / UK insurance unit-linked wrapper; insurance-dedicated funds are also out of scope (CW-004)."),
    _j("Code list: Distribution Channel", "Insurance / Unit-Linked", "EU market practice", "EU / UK unit-linked insurance channel."),
    # Sources
    _j("Sources", "FinDatEx EMT (European MiFID Template)", "FinDatEx", ""),
    _j("Sources", "FinDatEx EPT (European PRIIPs Template)", "FinDatEx", ""),
    _j("Sources", "FinDatEx EET (European ESG Template)", "FinDatEx", ""),
    _j("Sources", "EFAMA European Fund Classification (EFC)", "EU market practice", "Asset Class and Strategy Classification re-aligned to ICI and Morningstar."),
    _j("Sources", "IA Sectors", "UK market practice", ""),
    _j("Sources", "SFDR and SFDR RTS", "SFDR", ""),
    _j("Sources", "PRIIPs Regulation and RTS", "PRIIPs", ""),
    _j("Sources", "MiFID II product governance", "MiFID II", "Product governance re-sourced to FINRA Notice to Members 05-26."),
    _j("Sources", "UCITS Directive, AIFMD, EU MMFR, EU BMR", "UCITS", "UCITS, AIFMD, EU MMFR and EU BMR in one source row; re-sourced to the Investment Company Act and its rules, Rule 2a-7 and IOSCO."),
    _j("Sources", "ESMA guidelines and Q&A (performance fees, fund names, UCITS benchmarks)", "UCITS", "ESMA guidance under UCITS; re-sourced to Advisers Act Rule 205-1, SEC Rule 35d-1 and Form N-1A."),
    _j("Sources", "UK FCA COLL, SDR and Consumer Duty", "FCA", "FCA COLL, SDR and Consumer Duty."),
    _j("Sources", "HMRC Reporting Funds / German InvStG / OeKB", "Other EU/UK", "UK, German and Austrian tax reporting."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. DECISIONS: the US-only pass of 01 (pre-allocated CW-901, CW-022)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-901", "theme": "Scope", "title": "01 Investment Product & Service Offering: US-only pass and wealth-manager adaptation (amends CW-028, CW-036, CW-037 and CW-038)",
     "domains": ["01", "02", "05", "14", "15", "17", "27", "31", "35", "45", "46", "47", "52"],
     "issue": "The wholesale 01 Investment Product carries the EU/UK distribution apparatus of a UCITS and AIFMD manufacturer "
              "(MiFID target market, country registrations, PRIIPs and UCITS risk and cost figures, SFDR classification, UK and "
              "German tax reporting, EU identifiers and categories, BMR and Consumer Duty fields) and has no home for the service "
              "offerings, brokerage platform policy and alternative-investment access of a US wealth manager (CW-036 to CW-038).",
     "resolution": "Removed (101 JURISDICTION entries: 3 objects, 23 attributes, 13 whole code lists, 50 code values, 12 sources): "
                   "objects Target Market, Country Registration and Share Class Tax Reporting; attributes Regulatory Classification."
                   "MiFID Complexity; ESG Classification.SFDR Classification, Sustainability Label, Minimum Sustainable Investment %, "
                   "Minimum Taxonomy-Aligned Investment %, Principal Adverse Impacts Considered; Product Risk Indicator.Summary Risk "
                   "Indicator (SRI), SRRI, Global Exposure Method; Investment Objective & Policy.Recommended Holding Period; Cost "
                   "Disclosure.Ongoing Charges Figure (OCF), Transaction Costs, Ex-Ante Ongoing Costs; Other Ongoing Fees.Trail "
                   "Commission Indicator; Income Distribution.Fees Charged to Capital Indicator; Product Tax Status.CRS Entity "
                   "Classification; External Classification.EFAMA European Fund Category, IA Sector; Security Identifier.SEDOL, "
                   "Valoren, WKN (held, if ever, as 17 Instrument Identifiers); Benchmark.BMR Register Status; Product Governance."
                   "Value Assessment Outcome. Values removed include Distributing - Gross Income, Historic pricing and Full Swing "
                   "Pricing. Also dropped (not jurisdiction): the excluded Record Metadata object (CD-160) with its Data Quality Status "
                   "list, and the DCAM source that only it cited. "
                   "Kept and re-sourced to US rules: Fund Legal Structure (Investment Company Act; US legal forms, US regimes "
                   "only), Money Market Fund Type (Rule 2a-7), Leverage Calculation Method (Rule 18f-4 VaR tests), Maximum "
                   "Borrowing (ICA §18(f)), Benchmark Usage Type and Prospectus Disclosed Indicator (Form N-1A), ESG Term in Name "
                   "Indicator (Rule 35d-1), Performance Fee limited to fund-level terms of own funds (fulcrum fee, Advisers Act "
                   "§205(b)(2) and Rules 205-1 and 205-2; incentive fee of own feeder and other qualified-client funds, Rule 205-3, "
                   "with High-Water Mark Indicator and Crystallization Frequency kept), Investor Transaction Charge (sales loads per "
                   "Form N-1A and FINRA Rule 2341, redemption fee per Rule 22c-2, Switching Charge as the Form N-1A Item 3 exchange "
                   "fee, swing pricing per Rule 22c-1(a)(3)), Cost Disclosure (Form N-1A fee table), Regulatory Authorization (SEC, "
                   "OCC), Product Document (Rule 498, Rule 30e-1, CIT disclosure), Product Governance (FINRA NTM 05-26), Delegated "
                   "Function Indicator (ICA §15(a)), Distribution Availability (channels re-cut to direct brokerage, advice program, "
                   "workplace plan menu, intermediary, institutional), and the examples, definitions, applies-to and secondary "
                   "references of kept attributes moved to US values. Fee Accrual Basis and Fee Breakpoint Schedule now apply to "
                   "share classes only: a mandate's fee schedule is a client fee in 47 (CW-036, CW-037). Mandate Type loses SMA / "
                   "Wrap Program and UMA Sleeve: a retail managed account is a 15 account with a 46 model assignment (CW-006, "
                   "CW-009); institutional separate-account mandates stay. "
                   "Renamed: Product Risk Indicator.Local Regulatory Risk Rating to Firm Risk Rating (CDE; the scale 45 uses). "
                   "Re-cut code lists: Business Line takes the CW-004 values (the five wholesale values were client segments); "
                   "Distribution Channel, Vehicle Type (+Feeder Fund, Tender-Offer Fund), Share Class Type (+Front-End Load, Level "
                   "Load), Party Role Type (+Trustee, Placement Agent), Document Type (+Tailored Shareholder Report, CIT Disclosure "
                   "Document), Anti-Dilution Mechanism (+Redemption Fee), Leverage Method (Rule 18f-4), US Tax Classification "
                   "(+Group Trust), Product Relationship Type (+Feeder Of), Lifecycle Event Type (+Change of Offering Terms). "
                   "Added to kept objects: Product Risk Indicator.Derivatives Risk Category (Rule 18f-4), Cost Disclosure.Acquired "
                   "Fund Fees and Expenses (Form N-1A Item 3), ETF Characteristics.ETF Share Class Indicator; Lifecycle Event "
                   "applies to Service Offerings. Added families (CW-036 to CW-038, codes PR-ASO, PR-PLT, PR-ALT): Service "
                   "Offering (OFFR-), Offering Feature, Offering Eligibility Rule (ELIG-, with effective period), Offering Fee "
                   "Schedule Link, Service Tier, Tradable Universe Policy Rule (TUP-, with name, status and effective period), "
                   "Platform Product Availability, Feeder Access Terms (underlying fund for a feeder fund only), Offering Window "
                   "(OFWN-). Every other family, object and attribute name is unchanged. "
                   "CW-901 amends CW-028, CW-037 and CW-038 (and CW-036 for two fields): these fields the decisions assign to 01 are "
                   "not held as attributes, because another object already carries the fact. CW-028: the Service Tier fee discount "
                   "reference (47 references the tier in its schedules or waivers, so the pricing fact has one owner). CW-036: the "
                   "Service Offering minimum (an Offering Eligibility Rule of criterion Minimum Assets) and launch and close dates "
                   "(Lifecycle Events of the offering); the local Offering Status list (Offering Status uses Lifecycle Status). "
                   "CW-037: the approving committee of a Tradable Universe Policy Rule (approval is a 36 change initiative), "
                   "platform minimums (share class Minimum Initial Investment, and 17 instrument terms for third-party products) and "
                   "the restriction reason (a Purchase Restriction policy rule and the availability status). CW-038: Feeder Access "
                   "Terms minimum commitment (share class Minimum Initial Investment), placement agent (Product Party Role, role "
                   "Placement Agent) and liquidity terms (Dealing Terms: notice period, lock-up, redemption gate); the access "
                   "structure uses the shared Vehicle Type values instead of a local list.",
     "rationale": "The wealth model is US only (CW-003); foreign strategies, benchmarks, currencies and listings stay because US "
                  "only narrows distribution and regulation, not the investment universe (CW-022). Kept names keep the products "
                  "and models that read 01 resolving, except the readers of removed content listed in proposals_w1_01.NOTES "
                  "(18 data products, 15 data model files, 5 semantic models), which the WP0 product pass re-cuts or retires. "
                  "Lever: a firm with a UCITS range restores the removed items from the jurisdiction register and the wholesale sibling.",
     "action": "W1 (01); W1 merge (jurisdiction.REMOVALS, shared lists, LOCAL_RENAMES); WP0 (readers)", "status": "Proposed",
     "priority": "High", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    # Readers of removed content (review finding D, ruling 1). Lines are as of 2026-10-14; text matches checked by hand.
    "READERS OF REMOVED 01 CONTENT (WP0). Data products (18): "
    "DP-004 specs_a_foundational.py 305-353 (Country Registration, SEDOL, IA Sector, EFAMA European Fund Category, Trail Commission "
    "Indicator, OCF, Marketing Basis) and further DP-004 references in specs_f_compliance.py 470-480 and 593-606, specs_i_product_data.py "
    "107 and 297-320, specs_o_operations.py 122, specs_e3_private_markets_product_range.py 1223; "
    "DP-029 specs_d_marketing_product.py 447-462 (Country Registration); DP-030 specs_d_marketing_product.py 585 (IA Sector); "
    "DP-040 specs_f_compliance.py 413-451 and framework.py 633 (Target Market, Distribution Strategy, Value Assessment Outcome); "
    "DP-041 specs_f_compliance.py 512-560 (Country Registration, Marketing Basis); "
    "DP-058 specs_i_product_data.py 27-67 (Country Registration, SEDOL; Switching Charge is kept); "
    "DP-059 specs_i_product_data.py 171 (OCF); "
    "DP-064 specs_i_product_data.py 235-292 (Target Market, Country Registration, OCF, Ex-Ante Ongoing Costs, Transaction Costs, SRI, "
    "SRRI, SFDR fields, MiFID Complexity, Recommended Holding Period, Distribution Strategy); "
    "DP-065 specs_j_compliance_2.py 511-550 (Trail Commission Indicator); "
    "DP-067 specs_k_events_institutional.py 226 (High-Water Mark Indicator, Crystallization Frequency: kept, no action); "
    "DP-076 specs_i_product_data.py 581-619 (Target Market, Recommended Holding Period); "
    "DP-079 specs_o_operations.py 59-95 (Share Class Tax Reporting, SEDOL, CRS Entity Classification, Fees Charged to Capital Indicator); "
    "DP-091 specs_o_operations.py 471 (Share Class Tax Reporting); "
    "DP-097 specs_e1_foundations.py 25-182 (SEDOL); "
    "DP-135 specs_e2_portfolio_stewardship.py 1197-1246 (SFDR and Taxonomy fields, Sustainability Label, PAI); "
    "DP-144 specs_e1_book_of_record.py 541 (BMR Register Status); "
    "DP-156 specs_e2_invops_a.py 1602-1702 (SRI, SRRI, Recommended Holding Period); "
    "DP-242 specs_e5_cross_area.py 309 (SRRI, text). "
    "Also naming removed content in text, to check at WP0: DP-013 specs_a_foundational.py 376 (OCF), DP-134 "
    "specs_e2_portfolio_stewardship.py 1268 (SFDR), DP-145 specs_e2_invops_a.py 1717-1729 (SRRI, holding period), DP-142 and "
    "DP-155 specs_e3_ta_fund_governance.py 1286 and 1456 (SRRI), DP-107 and DP-109 specs_e3_private_markets_product_range.py "
    "875-920 and 1161-1195 (Country Registration, Target Market), DP-077 specs_m_clients_privacy_digital.py 63-83 and DP-043 "
    "specs_o_operations.py 498 (CRS, UK reporting fund status), DP-008 specs_d_marketing_product.py 492 and DP-015 framework.py "
    "581 (Target Market, Distribution Strategy).",
    "READERS (continued). Data models (15 files): keys_g1_01_02.py 84-87, 209; keys_e7_30_36.py 173, 337-366; keys_e7_31_33.py 580; "
    "keys_g4_08_09.py 48, 212; models_c2_marketing_product.py 417-459; models_c4_compliance.py 376-547; models_c7_product_data.py "
    "48-49, 233-249, 450-451, 545; models_c8_compliance2.py 536; models_c10_shareholder_ops.py 632, 659; models_e8_foundations.py 33-106 "
    "(SEDOL); models_e8c_cross_area.py 332; models_e8c_invops_a.py 967-979; models_e8c_private_markets_product_range.py 83-970; "
    "models_f1.py 258, 296. Semantic models (5): sm_00_shared_dimensions.py 199-975 (Country Registration, Marketing Basis, SEDOL, "
    "Trail Commission Indicator); sm_06_product_market.py 596-1853 (Country Registration, OCF, SRRI, Target Market); "
    "sm_08_investment_book_performance.py 105 (BMR Register Status); sm_10_investment_risk_compliance.py 47-1600 (Recommended "
    "Holding Period, SRRI); sm_11_fund_accounting_custody_governance.py 412 (OCF).",
    "READERS (disposition). DP-064 (FinDatEx EMT/EPT/EET feed), DP-040 (MiFID target market feedback) and DP-065 (EU/UK "
    "distribution compliance) lose their purpose and are retired at WP0. SEDOL readers (DP-004, DP-058, DP-079, DP-097, "
    "models_e8_foundations.py, sm_00) are re-pointed to the 17 Instrument Identifier at merge. Elsewhere the removed columns are "
    "dropped; Country Registration readers move to 35 Fund Regulatory Filing where they need US registration status.",
    "Rename for the baseline check: Product Risk Indicator.Local Regulatory Risk Rating -> Firm Risk Rating (CW-901); "
    "data_products/_catalog.txt (generated) still names the old attribute.",
    "Remove LOCAL_RENAMES ('01', 'Business Line', 'Client Segment') and register 01 as a member of the shared Business Line "
    "with the value map above; until then the builder shows the eight values under 'Client Segment'.",
    "Stale shared registrations to remove at merge: memberships ('01', 'Data Quality Status') in Data Quality Status (the list left "
    "with Record Metadata), ('01', 'Distribution Strategy') in Distribution Strategy (retired, CW-039) and ('01', 'CRS Classification') "
    "in CRS Entity Classification (retired, CW-039); LOCAL_RENAMES ('01', 'Registration Status', 'Product Registration Status') "
    "(the list is removed). Reword the reason of LOCAL_RENAMES ('01', 'Party Role Type', ...): it cites ManCo and depositary, which "
    "were removed; say 'roles of service providers to a fund (adviser, custodian, transfer agent, trustee)'.",
    "Built workbooks show the shared lists Regulatory Regime, MMF Type, Vehicle Type, Share Class Type, Distribution Policy, Investor "
    "Category, Distribution Channel and Audience Restriction with their wholesale values until the W5 re-cut (CW-039); the 01 local "
    "lists already hold the US values.",
    "47 brief: take the fee schedules of institutional mandates (management, breakpoint and performance fees billed to IA clients) "
    "and of advisory offerings; 01 holds only fund-level prospectus and offering-document fee terms of own funds (FSCH-), including "
    "feeder incentive fees (Rule 205-3) and fulcrum fees (§205(b)(2)).",
    "Attribute IDs are positional within a family (taxonomy_builder.model): the removals renumber later attributes in SHC, IDN, CLS, "
    "POL, BMK, FEE, REG and LCG. Products and models read 01 by name, not by attribute ID.",
    "Size: 320 attributes against the brief's band of 280 to 300. The built wholesale 01 had 307 (Record Metadata excluded); the "
    "EU/UK removals now take 42 (after restoring Switching Charge, High-Water Mark Indicator and Crystallization Frequency), leaving 265; "
    "additions are 55 (52 in the nine new objects, including the rule periods, name and status asked for in review, and 3 in kept objects). Reaching 300 needs dropping kept "
    "non-EU attributes, which breaks names. Proposal: widen the 01 band to 300-325.",
    "Add CONCEPT_OWNERSHIP rows (owner 01): Service Offering (OFFR-), Offering Eligibility Rule (ELIG-), Offering Fee Schedule Link, "
    "Service Tier, Tradable Universe Policy Rule (TUP-), Platform Product Availability, Feeder Access Terms, Offering Window (OFWN-). "
    "Expected referrers: 02 (Service Tier), 15 (OFFR-, OFWN-), 17 (TUP-), 45, 46, 47, 48.",
    "Key formats: OFWN-<year>-Q<quarter>-<seq> (OFWN-2026-Q4-0005, matching 15's OFWN-2026-Q2-0981); TUP-<seq> (01 uses TUP-0011 "
    "for an extended-hours rule; 17's TUP-0008 is its fractional rule); Service Tier is keyed by its tier code (01 example PREMIER, "
    "matching 02's 'Premier').",
    "'Fee schedule' resolves to 01 (FSCH- concept row); the 47 client fee schedule is forced with OWNERSHIP_OVERRIDES in "
    "enrich_01.py until the 47 brief registers its prefix and concept name.",
    "Removed derived copies: SRI and SRRI (CD-212, from 31) and BMR Register Status (CD-024, from 14). 31 Product Risk Indicator "
    "Calculation and 14 BMR checks lose their 01 consumer; the 31 and 14 US-only passes should check those objects.",
    "Feeder access: 15 Alternative Investment Subscription references OFWN- and PRD-; 17 holds the underlying fund interest "
    "(Fund Interest Terms per its brief) referenced by Feeder Access Terms.Underlying Fund Instrument (INS-), filled for feeder funds only.",
    "Shared Frequency (steward 09): propose relabeling 'Fortnightly' as 'Biweekly' (American usage); 01 keeps the shared label until then.",
]
