"""Consolidation proposals from Data Domain 02 - Client & Household (wealth model W1 draft v0.1, 2026-10-14).

Proposal fragment only: the builder does not read it. The program lead merges accepted entries into decisions.py,
shared_code_lists.py and jurisdiction.py at the W1 merge. Format follows CONTRACT.md in this folder (DECISIONS dict format,
PREFIXES tuple format, the jurisdiction.py REMOVALS entry format). The brief names this file proposals_02.py; the
assignment named it proposals_w1_02.py, which is used.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones (program-lead ruling on the 02 review, Medium "keys and links with 15"):
#    Vulnerability Concern and Death Notification get their own identifiers so that 15 Account Restriction and 50 Money
#    Movement Hold reference a key instead of a composite text. Checked against decisions.PREFIXES, the W1 proposals files
#    (01, 02, 09, 15, 17) and every prefix-like token in the content and consolidation modules, for one-letter edits
#    (substitution, insertion, deletion) and anagrams.
#    Rejected for Vulnerability Concern: VULN- (registered by 41, vulnerability finding), VCN- (one edit from RCN- 06 and
#    CCN- 30), CONC- (one edit from CONB- and CONT- 16), VUC- (reads as a vendor code). VCON- has no confusable.
#    Rejected for Death Notification: DTN- (anagram of NDT-, 16), DNOT- (reads "do not"), DECD- (reads as an abbreviation of
#    "deceased" used for account titles), DCSD- (opaque). DTHN- has no confusable.
#    Investor Qualification stays an attribute group keyed by PTY- plus the qualification standard (no prefix).
#    Consumer Privacy Request keeps a firm-defined number. HH- stays Retired (CW-040).
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = [
    ("VCON-", "Vulnerability concern (party x concern raised; special category, CD-344)", "02", "Reserved",
     "02 review fix pass (CW-030). Rejected VULN- (41), VCN-, CONC-, VUC-. 15 Account Restriction and 50 Money Movement Hold reference it."),
    ("DTHN-", "Death notification (deceased party x notification)", "02", "Reserved",
     "02 review fix pass (CW-026). Rejected DTN- (anagram of NDT-), DNOT-, DECD-, DCSD-."),
]

# Proposed key formats for the reserved prefixes (decisions.PREFIX_FORMATS format), as the examples use them.
PREFIX_FORMATS = [
    ("INPR-", "02", "INPR-<party number, the digits of the client's PTY- key>-<profile version, 2 digits>", "INPR-104588-03"),  # 02 owns the format; 15 aligns its example (INPR-500771-0004 -> INPR-500771-04) at merge
    ("KYCV-", "02", "KYCV-<year>-<sequence, 7 digits>", "KYCV-2026-0041877"),
    ("BOWN-", "02", "BOWN-<year>-<sequence, 6 digits>", "BOWN-2026-001877"),
    ("AGNT-", "02", "AGNT-<sequence, 7 digits>", "AGNT-0004512"),
    ("TCNT-", "02", "TCNT-<sequence, 7 digits>", "TCNT-0002215"),
    ("VCON-", "02", "VCON-<year>-<sequence, 6 digits>", "VCON-2026-000217"),
    ("DTHN-", "02", "DTHN-<year>-<sequence, 6 digits>", "DTHN-2026-000318"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local lists in 02 carrying the exact name and (US) values of an enterprise shared list.
#    (local list name in 02, shared list name, note). VALUE_MAPS gives the local label -> shared code where needed.
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    # Kept memberships (02 is a real user); VALUE_MAPS below rewritten to the new US labels.
    ("Regulator", "Regulator", "Keep ('02', 'Regulator'). Organization Primary Regulator; US values, MSRB and IOSCO copied (CW-039). The 02 workbook shows the shared list's EU/UK values only until 09's CW-909 re-cut is applied."),
    ("Screening Result", "Screening Result", "Keep ('02', 'Screening Result'). KYC Profile Sanctions Screening Result; 'True Match' is now 'Confirmed Match'."),
    ("Personal Data Category", "Personal Data Category", "Keep ('02', 'Personal Data Category'). Privacy Profile; all shared values copied."),
    ("Risk Rating", "Risk Rating", "Rename ('02', 'AML Risk Rating') -> ('02', 'Risk Rating'). KYC Profile AML Risk Rating; adds Critical."),
    # Renamed memberships
    ("Investor Qualification Standard", "Investor Qualification Standard", "Rename ('02', 'US Investor Qualification') -> ('02', 'Investor Qualification Standard'). AIFMD_PROFESSIONAL_INVESTOR left out (CW-039)."),
    ("Record Status", "Record Status", "Rename ('02', 'Role Status') -> ('02', 'Record Status'). Role Status, Household Membership Status (Proposed = system-suggested), Investor Profile Status, Beneficial Ownership Certification Status, Client Restriction Status."),
    # New memberships
    ("Identifier Status", "Identifier Status", "Party Identifier. Values copied unchanged (already a member)."),
    ("LEI Registration Status", "LEI Registration Status", "LEI Record. Labels copied unchanged (already a member)."),
    ("Case Status", "Case Status", "New member: Onboarding Case, Death Notification, Consumer Privacy Request, Vulnerability Concern."),
    ("Investor Category", "Investor Category", "New member (steward 02). 02 uses the communications-audience subset Retail, Institutional, Financial Professional; qualification values are Investor Qualification. PROFESSIONAL, ELIGIBLE_COUNTERPARTY, QUALIFIED_INVESTOR removed (CW-039)."),
    ("Business Line", "Business Line", "Local copy of the eight CW-004 codes; register 02 when 09's re-cut is applied."),
]

# Memberships to REMOVE for 02 at merge: ('02', 'MiFID Client Category') and ('02', 'CRS Entity Classification') (lists retired,
# CW-039; 08 is still a member of MiFID Client Category until its re-cut); ('02', 'Data Quality Status') (Record Metadata dropped,
# CD-160). Memberships to RE-REGISTER for 05 at W4 (the lists move with 05 objects): ('02', 'Distribution Channel'),
# ('02', 'Qualification Exam') and ('02', 'Data Vendor') become 05 members, so that Data Vendor does not keep 11 as its only
# member and Qualification Exam only 08.
MEMBERSHIPS_REMOVE = [("02", "MiFID Client Category"), ("02", "CRS Entity Classification"), ("02", "Data Quality Status")]
MEMBERSHIPS_RENAME = [(("02", "US Investor Qualification"), ("02", "Investor Qualification Standard")),
                      (("02", "AML Risk Rating"), ("02", "Risk Rating")),
                      (("02", "Role Status"), ("02", "Record Status"))]
MEMBERSHIPS_TO_05_AT_W4 = [("02", "Distribution Channel"), ("02", "Qualification Exam"), ("02", "Data Vendor")]

VALUE_MAPS = {   # new 02 local label -> shared code
    "Regulator": {"SEC": "US_SEC", "FINRA": "US_FINRA", "US State Securities Regulator": "US_STATE_SECURITIES_REGULATOR", "CFTC / NFA": "US_CFTC_NFA", "OCC": "US_OCC", "US State Banking Regulator": "US_STATE_BANKING_REGULATOR", "Federal Reserve": "US_FEDERAL_RESERVE", "DOL / EBSA": "US_DOL_EBSA", "US State Insurance Regulator": "US_STATE_INSURANCE_REGULATOR", "IRS / US Treasury": "US_IRS_TREASURY", "FinCEN": "US_FINCEN", "OFAC": "US_TREASURY_OFAC", "US Department of Justice": "US_DOJ", "US State Attorney General": "US_STATE_ATTORNEY_GENERAL", "MSRB": "US_MSRB", "IOSCO": "INTL_IOSCO"},
    "Screening Result": {"No Match": "NO_MATCH", "Potential Match - Under Review": "POTENTIAL_MATCH", "False Positive": "FALSE_POSITIVE", "Confirmed Match": "CONFIRMED_MATCH"},
    "Risk Rating": {"Low": "LOW", "Medium": "MEDIUM", "High": "HIGH", "Critical": "CRITICAL", "Prohibited": "PROHIBITED"},
    "Personal Data Category": {"No Personal Data": "NONE", "Identity": "IDENTITY", "Contact": "CONTACT", "Professional / Employment": "PROFESSIONAL_EMPLOYMENT", "Registration / Licensing": "REGISTRATION_LICENSING", "HR / Employee": "HR_EMPLOYEE", "Financial": "FINANCIAL", "Government Identifier": "GOVERNMENT_IDENTIFIER", "Online Identifiers / Engagement": "ONLINE_IDENTIFIERS_ENGAGEMENT", "Inferences / Segmentation": "INFERENCES_SEGMENTATION", "Opinion About Individual": "OPINION_ABOUT_INDIVIDUAL", "Free Text - May Contain Personal Data": "UNSTRUCTURED_MAY_CONTAIN"},
    "Record Status": {"Active": "ACTIVE", "Inactive": "INACTIVE", "Pending": "PENDING", "Proposed": "PROPOSED", "Deprecated": "DEPRECATED", "Retired": "RETIRED", "Paused": "PAUSED", "Draft": "DRAFT"},
    "Investor Category": {"Retail": "RETAIL", "Institutional": "INSTITUTIONAL", "Financial Professional": "FINANCIAL_PROFESSIONAL"},
    "Investor Qualification Standard": {"None Evidenced": "NONE_EVIDENCED", "Accredited Investor": "ACCREDITED_INVESTOR", "Qualified Client": "QUALIFIED_CLIENT", "Qualified Purchaser": "QUALIFIED_PURCHASER", "Qualified Institutional Buyer": "QUALIFIED_INSTITUTIONAL_BUYER"},
    "Business Line": {"DB": "DB", "DA": "DA", "HA": "HA", "PF": "PF", "WR": "WR", "IA": "IA", "IC": "IC", "TR": "TR"},
    "Case Status": {"New / Received": "NEW", "Pending Good Order": "PENDING_GOOD_ORDER", "In Progress": "IN_PROGRESS", "Waiting on Client": "WAITING_ON_CLIENT", "Pending Third Party": "PENDING_THIRD_PARTY", "Escalated": "ESCALATED", "Resolved / Completed": "RESOLVED", "Closed": "CLOSED", "Rejected": "REJECTED", "Canceled": "CANCELED"},
}

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: (list name in 02, proposed shared list name, likely other users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Investment Objective", "Investment Objective", ["15", "45", "46"], "15 Account Investment Profile and 45 recommendations use the same values; make it shared, steward 02 (brief section 8)."),
    ("Risk Tolerance", "Risk Tolerance", ["15", "45", "46"], "As above; steward 02."),
    ("Time Horizon", "Time Horizon", ["15", "45"], "As above; steward 02."),
    ("Liquidity Need", "Liquidity Need", ["15", "45"], "15 Account Investment Profile holds liquidity needs per account; steward 02."),
    ("Communication Channel", "Communication Channel", ["04", "13"], "Channel of contact and delivery preferences; 04 and 13 hold similar lists. Steward 02 or 13."),
    ("Party Relationship Type", None, ["15", "51"], "NOT a merge candidate with 15 Account Role Type (roles on an account) or 51 trust roles; keep separate and list in NOT_MERGED."),
    ("Marital Status", "Marital Status", ["15", "20", "45"], "15 (spousal consent, community property), 20 (employees) and 45 (planning) need it; steward 09."),
    ("Retirement Plan Type", "Retirement Plan Type", ["16", "15"], "16 Administered Plan Type is finer; keep 02 list as the coarse plan type and map 16 values to it."),
    ("Assignment Method", None, ["04"], "Segment and tier assignment method; 04 segments may reuse it."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS noticed (plan section 5.3 watchlist names), decisions.TERM_CONFLICTS format.
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Household (wealth model)",
     "usages": [("02", "Household (Client Household, PTY-HH-)", "Party of type Household grouping members planned and served together"),
                ("13", "Householding Group (MHG-)", "Mailing household for SEC householding of documents"),
                ("47", "Fee Household (per the 47 brief)", "Accounts aggregated for breakpoints")],
     "recommendation": "Glossary terms Client Household, Mailing Household, Fee Household; every definition says which.",
     "resolution": "Primary sense: 02 Client Household. 13 and 47 groupings are always qualified (CW-027).",
     "status": "Resolved", "decision": "CW-027"},
    {"term": "Client (wealth model)",
     "usages": [("02", "Party Role Type 'Client'; Relationship Stage 'Client'", "Party holding or applying for an account"),
                ("12", "Institutional Client", "Institutional advisory client profile (W4)"),
                ("16", "Plan Sponsor / Plan Participant", "Workplace client roles")],
     "recommendation": "Bare 'client' means a 02 party with the Client role; the others are qualified.",
     "resolution": "As recommended (CW-005).", "status": "Resolved", "decision": "CW-005"},
    {"term": "Advisor (wealth model)",
     "usages": [("02", "Party Role Type 'Financial Advisor'", "External advisor in the intermediary channel; profile in 05"),
                ("03", "Advisor (own representative)", "Employee of the firm (20 EMP-)")],
     "recommendation": "02 holds no advisor-of-record attribute; client-to-advisor assignment is 03. External advisors are qualified 'external'.",
     "resolution": "As recommended (CW-013, CW-023).", "status": "Resolved", "decision": "CW-013"},
    {"term": "Profile",
     "usages": [("02", "Investor Profile (INPR-)", "Versioned client investor profile"),
                ("15", "Account Investment Profile", "Objective, risk tolerance and horizon recorded for one account, referencing the 02 version"),
                ("05", "Practice / firm profiles (W4)", "Role profiles of intermediaries"),
                ("02", "KYC Profile; Privacy Profile; Tax Profile", "Party attribute groups")],
     "recommendation": "Always qualified: Investor Profile, Account Investment Profile, KYC Profile, Privacy Profile, Tax Profile, Advisor Practice.",
     "resolution": "As recommended (CW-024).", "status": "Resolved", "decision": "CW-024"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION: EU/UK content of the wholesale 02 (wholesale-v1.0) that the replacement does not carry (CW-022 item 2).
#    Format: jurisdiction.REMOVALS. Whole objects and whole lists have attribute "".
# ---------------------------------------------------------------------------------------------------------------------
_D = "CW-902"
def _j(obj, attr, regime, note):
    return {"domain": "02", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}

JURISDICTION = [
    # Objects
    _j("UK & EU Regulatory Identifier", "", "FCA", "FCA FRN, FCA IRN and EU NCA register IDs dropped; Business Identifier Code re-homed as Party Identifier scheme 'BIC'."),
    _j("Processing Legal Basis", "", "GDPR / UK GDPR", "GDPR Article 6 lawful basis records (with Legitimate Interests Assessment Reference); US model uses Privacy Profile opt-outs and Consent Record (CW-029)."),
    # Attributes
    _j("Regulatory Classification", "MiFID Client Category", "MiFID II", "US classification is Reg BI Retail Customer Indicator and FINRA Rule 4512(c) Institutional Account Indicator."),
    _j("Regulatory Classification", "Categorization Basis", "MiFID II", "No US equivalent; Categorization Date kept."),
    _j("Financial Professional", "UK Certification Status", "SM&CR", "Financial Professional moves to 05 at W4 (CW-023); this attribute is not restored there."),
    _j("End Investor", "Vulnerable Customer Indicator", "Consumer Duty", "End Investor dropped (CW-023); the US concept is Specified Adult Status and Vulnerability Concern (FINRA Rule 2165, CW-030)."),
    _j("Tax Profile", "CRS Entity Classification", "CRS", "FATCA Status (IRC chapter 4) kept."),
    _j("Retirement Plan", "UK Pension Scheme Registry Number", "Other EU/UK", "The Pensions Regulator (UK) registry number; plans are keyed by EIN + plan number."),
    _j("Privacy Profile", "Processing Restriction Indicator", "GDPR / UK GDPR", "GDPR Articles 18 and 21; US opt-outs are Nonaffiliated Sharing, Affiliate Marketing and Sale / Sharing Opt-Out."),
    _j("Organization", "Industry Classification (NACE / UK SIC schemes)", "Other EU/UK", "The wholesale attribute allowed NACE and UK SIC codes; the attribute is kept with NAICS only (External (NAICS))."),
    _j("Retention", "Scheduled Erasure Date", "GDPR / UK GDPR", "Retention object dropped (retention metadata is 21, CD-160); GDPR erasure scheduling not carried."),
    # Whole code lists
    _j("Code list: MiFID Client Category", "", "MiFID II", "Whole list: Retail Client, Per Se Professional, Elective Professional, Eligible Counterparty, Elective Eligible Counterparty. Shared list retired (CW-039)."),
    _j("Code list: Categorization Basis", "", "MiFID II", "Whole list: Per Se (Annex II Section I), Opt-Up (Annex II Section II), Opt-Down, Default Retail."),
    _j("Code list: CRS Entity Classification", "", "CRS", "Whole list (five OECD CRS entity classes). Shared list retired (CW-039)."),
    _j("Code list: Lawful Basis", "", "GDPR / UK GDPR", "Whole list: Consent, Contract, Legal Obligation, Vital Interests, Public Task, Legitimate Interests."),
    _j("Code list: Processing Purpose", "", "GDPR / UK GDPR", "Whole list (GDPR Art. 5(1)(b) purposes); replaced by Consent Purpose (US consents)."),
    _j("Code list: UK Certification Status", "", "SM&CR", "Whole list: Senior Manager, Certified - SPS Held, Certified, Conduct Rules Staff Only, Not Applicable."),
    # Code-list values
    _j("Code list: Identifier Scheme", "FCA FRN", "FCA", ""),
    _j("Code list: Identifier Scheme", "FCA IRN", "FCA", ""),
    _j("Code list: Identifier Scheme", "EU NCA Register ID", "Other EU/UK", "EU national competent authority register numbers (CSSF, CBI, BaFin, AMF)."),
    _j("Code list: Identifier Scheme", "TPR Pension Scheme Registry Number", "Other EU/UK", "UK Pensions Regulator."),
    _j("Code list: Party Role Type", "Approved Reporting Mechanism", "MiFIR", "MiFIR transaction reporting."),
    _j("Code list: Party Role Type", "Client Money Bank", "CASS", "Client money under FCA CASS; US client cash is 49 and 50."),
    _j("Code list: Party Origin", "Regulatory Register - FCA", "FCA", ""),
    _j("Code list: Privacy Regime", "EU GDPR", "GDPR / UK GDPR", ""),
    _j("Code list: Privacy Regime", "UK GDPR / DPA 2018", "GDPR / UK GDPR", ""),
    _j("Code list: Privacy Regime", "Swiss FADP", "Other non-US", "Swiss Federal Act on Data Protection (non-US; no closer regime)."),
    _j("Code list: Data Subject Request Type", "Restriction", "GDPR / UK GDPR", "GDPR Art. 18; list renamed Privacy Request Type (CCPA rights)."),
    _j("Code list: Data Subject Request Type", "Objection", "GDPR / UK GDPR", "GDPR Art. 21."),
    _j("Code list: Data Subject Request Type", "Portability", "GDPR / UK GDPR", "GDPR Art. 20; the CCPA portable copy is part of 'Access - Specific Pieces'."),
    _j("Code list: Tax Form Type", "CRS Self-Certification - Individual", "CRS", "Tax forms on file are 15 Account Tax Certification."),
    _j("Code list: Tax Form Type", "CRS Self-Certification - Entity", "CRS", ""),
    _j("Code list: Organization Type", "Independent Financial Adviser Firm", "Other EU/UK", "UK/EU intermediary type; Organization Type not carried (Party Type re-cut)."),
    _j("Code list: Organization Type", "Discretionary Fund Manager", "Other EU/UK", "UK/EU intermediary type."),
    _j("Code list: Retirement Plan Type", "UK DC Trust-Based", "Other EU/UK", "UK pension scheme types."),
    _j("Code list: Retirement Plan Type", "UK Master Trust", "Other EU/UK", ""),
    _j("Code list: Retirement Plan Type", "UK Group Personal Pension", "Other EU/UK", ""),
    _j("Code list: Retirement Plan Type", "UK DB Scheme", "Other EU/UK", ""),
    _j("Code list: Regulator", "UK FCA", "FCA", "Wholesale 02 local list; the shared list is re-cut by 09 (CW-039)."),
    _j("Code list: Regulator", "UK PRA", "Other EU/UK", "UK Prudential Regulation Authority."),
    _j("Code list: Regulator", "CSSF", "Other EU/UK", "Luxembourg."),
    _j("Code list: Regulator", "Central Bank of Ireland", "Other EU/UK", ""),
    _j("Code list: Regulator", "BaFin", "Other EU/UK", "Germany."),
    _j("Code list: Regulator", "AMF", "Other EU/UK", "France."),
    _j("Code list: Regulator", "Other EU NCA", "Other EU/UK", ""),
    _j("Code list: Investor Category", "PROFESSIONAL", "MiFID II", "Shared list value (steward 02), CW-039."),
    _j("Code list: Investor Category", "ELIGIBLE_COUNTERPARTY", "MiFID II", "Shared list value, CW-039."),
    _j("Code list: Investor Category", "QUALIFIED_INVESTOR", "Other non-US", "Swiss CISA / EU well-informed investor; CW-039."),
    _j("Code list: Investor Qualification Standard", "AIFMD_PROFESSIONAL_INVESTOR", "AIFMD", "Shared list value, CW-039."),
    _j("Code list: Due Diligence Level", "Simplified", "Other EU/UK", "EU AMLD / UK MLR 2017 simplified due diligence; US list is Standard CDD, Enhanced, Special (31 CFR 1010.610/620)."),
    # Sources
    _j("Sources", "FCA Financial Services Register and SM&CR", "FCA", ""),
    _j("Sources", "FCA Handbook COBS 3 and MiFID II Annex II (client categorization)", "MiFID II", "Includes the ESMA client categorization practice the brief names."),
    _j("Sources", "EU GDPR and UK GDPR / Data Protection Act 2018", "GDPR / UK GDPR", "Re-sourced to Reg S-P, Reg S-AM, GLBA and CCPA/CPRA."),
    _j("Sources", "UK FCA Consumer Duty (vulnerable customers)", "Consumer Duty", "Re-sourced to FINRA Rule 2165 and the Senior Safe Act."),
    _j("Sources", "The Pensions Regulator - Pension Scheme Registry", "Other EU/UK", ""),
    _j("Sources", "Companies House and EU business registers", "Other EU/UK", "GLEIF registration authority data kept."),
    _j("Sources", "EU AML Directives / AMLR; UK MLR 2017 (part of the FATF / AML source)", "Other EU/UK", "Re-sourced to 31 CFR 1010.230, 1023.220 and FINRA Rule 3310; FATF and OFAC kept."),
    _j("Sources", "OECD Common Reporting Standard (part of the IRS / FATCA source)", "CRS", "IRS Forms W-9, W-8 and FATCA kept."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. DECISIONS: the US-only pass of 02 (pre-allocated id, CW-022).
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-902", "theme": "Scope", "title": "US-only pass of Data Domain 02 Client & Household (replacement of the wholesale 02)",
     "domains": ["02"],
     "issue": "The wholesale 02 Client & Customer carried EU/UK content (MiFID client categorization, FCA/EU regulatory identifiers, SM&CR certification, Consumer Duty vulnerability, OECD CRS, GDPR lawful basis, erasure and data subject rights, UK pension scheme identifiers, EU/UK regulator, organization, plan type and identifier scheme values, EU/UK sources). The replacement (CW-005) is designed US only and must record what it leaves out so a UK extension can be restored.",
     "resolution": "Not carried (58 JURISDICTION entries in proposals_w1_02.py: 2 objects, 9 attributes, 6 whole lists, 33 values, 8 sources): objects UK & EU Regulatory Identifier and Processing Legal Basis; attributes Regulatory Classification MiFID Client Category and Categorization Basis, Financial Professional UK Certification Status, End Investor Vulnerable Customer Indicator, Tax Profile CRS Entity Classification, Retirement Plan UK Pension Scheme Registry Number, Privacy Profile Processing Restriction Indicator, Retention Scheduled Erasure Date, the NACE / UK SIC schemes of Organization Industry Classification; lists MiFID Client Category, Categorization Basis, CRS Entity Classification, Lawful Basis, Processing Purpose, UK Certification Status; EU/UK values of Identifier Scheme, Party Role Type, Party Origin, Privacy Regime, Data Subject Request Type, Tax Form Type, Organization Type, Retirement Plan Type, Regulator, Investor Category, Investor Qualification Standard and Due Diligence Level; eight EU/UK sources; text-only EU/UK wording not carried (the UK PECR reference on the wholesale Opt-In Method; 'OFAC, UK, EU, UN lists' in the wholesale sanctions screening definition, now OFAC only). Kept and re-sourced to US rules: regulatory classification (Reg BI Rule 15l-1, FINRA Rules 4512(c) and 2210); KYC and due diligence (31 CFR 1010.230, 1010.610/620, FINRA Rules 2090 and 3310, OFAC); identity verification (31 CFR 1023.220, 1024.220, 1020.220); privacy and consent (Reg S-P, Reg S-AM, GLBA, CCPA/CPRA, E-SIGN, TCPA, CAN-SPAM); vulnerability (FINRA Rule 2165, Senior Safe Act); tax (IRS Forms W-9 and W-8, FATCA); BIC kept as a Party Identifier scheme; industry classification re-cut to NAICS. Related non-jurisdiction re-cut recorded here at the program lead's ruling: Party Role Type drops the distributor hierarchy levels Division / Home Office and Region / Complex (the hierarchy moves to 05 Hierarchy Node, CW-023); intermediary role values (Distributor Firm, Branch / Office, Advisor Team, Financial Advisor, Gatekeeper / Research, Investment Consultant / OCIO, Plan Sponsor, Recordkeeper) stay thin (CW-005). Foreign individuals and entities stay clients where US law allows (nonresident aliens on Form W-8BEN); foreign addresses, countries, LEIs and tax residences stay.",
     "rationale": "US only narrows where the firm is regulated and serves clients (CW-003, CW-022); the register keeps the UK extension restorable from tag wholesale-v1.0. Objects moved to 05, 12 and 16 (CW-023) keep their EU/UK values for those domains' passes, except UK Certification Status, recorded here per the 02 brief.",
     "action": "Merge JURISDICTION into jurisdiction.REMOVALS at the W1 merge", "status": "Proposed", "priority": "High",
     "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. NOTES for the consolidation step.
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "29 re-cut (CW-025, W3): 29 CIP Verification (CIP-) becomes a Reference (Identity Verification, 02) with KYCV- examples and CIP- is retired, unless the 29 brief keeps an outsourced-TA oversight copy. ROW_OWNERSHIP on 02 Identity Verification / Verification Result states the interim rule.",
    "15 (CW-026): Account Role Type loses Trusted Contact Person and Power of Attorney; Associated Person Disclosure Indicator now lives on 02 Individual. 15 references Investor Profile (INPR-), Identity Verification (KYCV-), Authority Grant (AGNT-), Onboarding Case (ONB-), Client Restriction (CRX-), Vulnerability Concern (now VCON-) and Investor Qualification (PTY- plus standard) by these names.",
    "15 at merge: (a) align the INPR- example to the 02 format INPR-<party number>-<2-digit version> (INPR-500771-0004 -> INPR-500771-04); (b) Account Restriction 'Source Vulnerability Concern' (content_15_account.py:448) and Investor Qualification references (244) use VCON- and PTY- + standard instead of composite text keys. The concern-to-hold link is held once, on the 15 (ARX-) and 50 (MMH-) side; 02 dropped Resulting Account Restrictions.",
    "15 Account Tax Certification (ATC-) is referenced from 02 Tax Profile 'Tax Status Evidence'; the form is held once (15). TIN Type is the party's TIN type in 02; 15 Account Tax Certification 'Tax ID Type' (content_15_account.py:262) should reference or derive it.",
    "13: E-Delivery Election (DEL-) keeps its link to Consent Record (CNS-); privacy notice delivery is a 13 Shareholder Communication referenced by Privacy Profile 'Initial Privacy Notice'. 13 Householding Group (MHG-) is the Mailing Household; never the 02 Client Household. Confirm with 13 who masters returned mail (02 Postal Address Mail Returned Date).",
    "Shared-list membership plan (see SHARED_MEMBERSHIPS, MEMBERSHIPS_REMOVE, MEMBERSHIPS_RENAME, MEMBERSHIPS_TO_05_AT_W4): remove ('02','MiFID Client Category'), ('02','CRS Entity Classification'), ('02','Data Quality Status'); rename ('02','US Investor Qualification') -> 'Investor Qualification Standard', ('02','AML Risk Rating') -> 'Risk Rating', ('02','Role Status') -> 'Record Status'; keep Regulator, Screening Result, Risk Rating and Personal Data Category with VALUE_MAPS rewritten to the new US labels; re-register Distribution Channel, Qualification Exam and Data Vendor for 05 at W4. Until 09's CW-909 Regulator re-cut is applied the 02 workbook shows the shared Regulator list with EU/UK values.",
    "Business Line: 02 holds a local copy with the CW-004 codes because the shared list still has the six CD-209 values.",
    "Service Tier (01) has no prefix; 02 references it as 'Reference (Service Tier, 01)' with the tier code (TIER2) as example.",
    "Escalation Case Reference on Vulnerability Concern is an Identifier forced to 08 by OWNERSHIP_OVERRIDES; re-type to Reference (<case object>, 08) when the 08 brief names the object (W2).",
    "Qualifying Client Assets (Service Tier Assignment) is the only client-assets copy, Derived (06); 06 does not yet publish Client Assets (W4). The Household copy was dropped (review fix pass).",
    "34 adaptation: Party Role Type 'Stewardship Framework Body' reads as the UK Stewardship Code signatory body; the 34 pass decides whether it stays.",
    "W4: content_10_distribution_finance_and_profitability.py references 'Reference (Hierarchy Node)', which leaves 02 for 05 at W4; re-point it then.",
    "Party Status history is not held as effective-dated rows in 02; record versions are 21 governance metadata (CD-160).",
    "Wholesale-only lists not carried and not EU/UK (Organization Type, Data Vendor, Address Usage, Phone Type, Opt-In Method, Opt-Out Source, Preference Source, Age Band, Wealth Tier, Look-Through Data Basis, Investor Type) left with dropped or moved objects; the lists that go with moved objects (Distribution Channel, Firm Registration Type, ...) are for the 05, 12 and 16 drafters.",
    "check_enrichment.py picks the first content_02_* module from an unsorted os.listdir; on this machine it lists content_02_client_and_household.py first, so the plain run checked the new module. Delete the wholesale module at merge before relying on it.",
    # ---- Readers of the wholesale 02 (from the 02 review, section F2; the program lead re-points them at merge) ----
    "READERS - summary: a scan for ('02', object, attribute) tuples finds 707 references that do not resolve in the new module: 406 to objects moved to 05, 12 or 16; 178 to attributes dropped from kept objects; 50 to the re-cut contact-point objects and Data Subject Request; 46 to EU/UK objects; 27 to dropped objects (End Investor, Digital Profile, Retention, Record Metadata). Restored in the fix pass to cut the work: Party Display Name (Party), Preferred Name (Individual), Ultimate Parent (Legal Entity Hierarchy).",
    "READERS - re-point map for dropped attributes of kept objects: Organization Trading Name, Formation Date, Organization Type, Regulated Entity Indicator -> Party Type, Legal Name, Primary Regulator (no direct replacement for Trading Name / Formation Date); Individual Deceased Indicator -> Individual Date of Death not blank; Individual Nationality -> Citizenship Countries; Party Role Role Source -> Party Origin; Party Identifier Last Verified Date -> dropped; LEI Entity Category -> dropped; Beneficial Ownership Control Person Indicator -> Ownership Prong = Control; Regulatory Classification US Investor Qualification -> Investor Qualification; Regulatory Classification MiFID Client Category and Categorization Basis -> EU/UK, removed (CW-902); Privacy Profile Processing Restriction Indicator -> US opt-outs (Nonaffiliated Sharing, Affiliate Marketing, Sale / Sharing); Client Restriction Restricted Account -> Restricted Accounts; Client Restriction Restricted Products / Strategies -> Excluded Instruments (17); Segment Assignment Segment Score -> dropped; Retirement Plan Plan Assets, Active Participants, Form 5500 Filing Year, QDIA Type, Fiduciary Investment Adviser Type -> 16 (W3); Household Household ID -> Party ID; Household Investable Assets -> Service Tier Assignment Qualifying Client Assets (06 copy); Contact Point Address / Email / Phone / Usage -> Contact Point and Postal Address; Data Subject Request -> Consumer Privacy Request.",
    "READERS - data products: specs_a_foundational.py DP-001 (24-54, 46), DP-002 (107-166, 74), DP-003 (212-248, 49); specs_e1_foundations.py DP-240 Enterprise Party & Role Master (899-937, 19: Party Display Name, Organization Trading Name, Organization Type, Formation Date, Regulated Entity Indicator, Ultimate Parent, Preferred Name, Deceased Indicator, Role Source, Last Verified Date, LEI Entity Category, UK & EU Regulatory Identifier BIC/FRN/NCA, Control Person Indicator), DP-098 (285-336, 6); specs_c_sales.py DP-017 (130-159, 33), DP-018 (374-405, 24), DP-020 (585-602), DP-021 (682-726), DP-022 (789-806, 11), DP-023 (903-904), DP-024 (947-984, 14), DP-092 (236-281, 20); specs_g_advisor_analytics.py DP-046 (32-66, 10), DP-047 (132-154), DP-048 (210-240, 38), DP-049 (298-341, 15), DP-052 (428-432, 9), DP-053 (495); specs_m_clients_privacy_digital.py DP-077 (33-87, 16), DP-080 (153-187, 24), DP-087 (276-305); specs_h_planning_partners.py DP-054 (211), DP-066 (555-590, 26); specs_d_marketing_product.py DP-028 (330-369, 22); specs_i_product_data.py DP-076 (586-602, 11); specs_j_compliance_2.py DP-061, DP-063, DP-065 (522-548); specs_f_compliance.py DP-037 (169-172), DP-038 (265-266); specs_e1_masters.py DP-115 (60-83), DP-210 (781), DP-213 (1123); specs_e2_invops_b.py DP-161 (915); specs_e2_portfolio_stewardship.py DP-130 (599-623), DP-132 (861), DP-133 (983); specs_e2_research_trading.py DP-121 (574), DP-122 (768); specs_e3_private_markets_product_range.py DP-136 to DP-139 (145-540); specs_e4_compliance_legal.py DP-222, DP-225, DP-227, DP-229, DP-230; specs_e4_risk_audit_third_party.py DP-218 to DP-220; specs_e4_technology_communications.py DP-235, DP-236; specs_e5_cross_area.py DP-243 (487-499); specs_l_shareholder_vendor.py DP-070 (212-271); specs_o_operations.py DP-085 (316-342); specs_p_inst_intel_finance.py DP-088 (225); specs_q_accounts_plans.py DP-093 (135), DP-094 (282), DP-096 (526). 23 files.",
    "READERS - data models: keys_g1_01_02.py (95-229, 28 entries: key registrations for every moved, re-cut and dropped object, including Contact Point Address 128/229, Data Subject Request 151, Processing Legal Basis 148, Retention 154, End Investor 110/218); keys.py (28-195, 22 entries, including Client Restriction Restricted Account 159, Restricted Products / Strategies 160, Ultimate Parent 150); models_f1.py DP-002 (9-49, 11), DP-003 (126-154, 5); models_c1_sales.py (18 entries); models_c5_advisor_privacy.py (17 entries; DP-080 at 806-815); models_pilot_er.py (10-36); models_c4_compliance.py; models_c6_planning_finance.py; models_c8_compliance2.py; models_e8_foundations.py:567 (DP-240, UK & EU identifier); models_e8c_compliance_legal.py; models_e8c_cross_area.py; models_c7_product_data.py; keys_g2 to keys_g6 and keys_e7_39_41.py (1 to 3 each). 18 files.",
    "READERS - semantic model (by attribute name): sm_00_shared_dimensions.py lines 54, 72, 96, 135, 149, 156, 437 (Party Display Name, restored), 62 and 450 (Ultimate Parent, restored), 114-116 (Preferred Name, restored), 461 (Deceased Indicator -> Date of Death not blank); sm_02_advisors_field_sales.py:249 (Party Display Name, restored).",
    "READERS - objects moved, by receiving stage: to 05 at W4 (Distributor Firm, Form ADV Profile, Hierarchy Node, Branch / Office, Advisor Team, Gatekeeper Profile, Financial Professional, Advisor Practice, Employment Affiliation, Team Membership, External Classification, Consultant Profile, Consultant Advisory Relationship); to 12 at W4 (Institutional Client); to 16 at W3 (Recordkeeper Profile, Plan Service Provider, Retirement Plan statistics). Readers of these keep their tuples until the receiving stage restores the objects from tag wholesale-v1.0, then re-point the domain number.",
]
