"""W1 proposals of Data Domain 09 Shared & Enterprise Reference Data (wealth model; carry-over with the US-only and
perspective pass). Brief: 00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 3 (09); decisions CW-003, CW-004,
CW-020, CW-022, CW-039. Declarative only: the program lead merges DECISIONS into decisions.py, appends JURISDICTION to
jurisdiction.REMOVALS and applies SHARED_RECUTS to shared_code_lists.py at merge (W5 for the shared lists, CW-039).
"""

_D = "CW-909"


def _j(obj, attr, regime, note):
    return {"domain": "09", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


# ---------------------------------------------------------------------------------------------------------------------
# Jurisdiction register entries (jurisdiction.REMOVALS format). Objects and attributes use the wholesale-v1.0 names.
# ---------------------------------------------------------------------------------------------------------------------
_GEO_US = "The wealth model is US only (CW-003); US statistical geography (FIPS, CBSA, ZIP/ZCTA) stays."
JURISDICTION = [
    # Objects (with the object group "UK & EU Statistical & Postal Geography", which held only these three)
    _j("UK Postcode", "", "UK market practice", "UK postal geography (Postcode District, Local Authority District Code) for UK territory design; no UK distribution. " + _GEO_US),
    _j("ITL Region", "", "UK market practice", "ONS International Territorial Levels (ITL Code, ITL Level). " + _GEO_US),
    _j("NUTS Region", "", "EU market practice", "Eurostat NUTS regions (NUTS Code, NUTS Level). " + _GEO_US),
    # Attributes
    _j("Country", "EU Member State Indicator", "EU market practice", "Drove EU distribution scope; no EU distribution. Membership can be modeled as a Geographic Group if an exposure report needs it."),
    _j("Country", "EEA Member Indicator", "AIFMD", "Drove UCITS / AIFMD passporting scope (CDE); no passports in the US model."),
    _j("Dealing Calendar Rule", "Non-Dealing Day Threshold", "EU market practice", "UCITS-style non-dealing day when a share of markets is closed; '40 Act funds price every day the NYSE is open (SEC Rule 22c-1) and handle foreign closures by fair valuation (Rule 2a-5, mastered in 22)."),
    _j("FX Rate Source", "Benchmark Regulatory Status", "BMR", "EU / UK Benchmarks Regulation status (derived copy from 14); no US equivalent. The FX sources themselves stay (market data)."),
    _j("Legal Entity Identifier", "FCA Firm Reference Number", "FCA", "No UK-authorized entity; SEC file numbers (801-, 8-, 84-) and the OCC charter number are held per registration in 38 Entity Authorization; CRD and CIK stay on 09."),
    # Code-list values (local lists of 09)
    *[_j("Code list: Geographic Unit Type", v, r, "Removed with the UK and EU geography objects; also proposed for the shared list (SHARED_RECUTS).")
      for v, r in (("UK Postcode Area", "UK market practice"), ("UK Postcode District", "UK market practice"),
                   ("UK Postcode Sector", "UK market practice"), ("ITL Region", "UK market practice"), ("NUTS Region", "EU market practice"))],
    *[_j("Code list: Geographic Scheme", v, r, "Scheme of a removed UK / EU geography.")
      for v, r in (("ONS Postcode (NSPL)", "UK market practice"), ("ONS ITL", "UK market practice"), ("Eurostat NUTS", "EU market practice"))],
    _j("Code list: Geographic Hierarchy Type", "UK Statistical (Postcode > ITL3 > ITL2 > ITL1)", "UK market practice", "Hierarchy of removed UK geography."),
    _j("Code list: Geographic Hierarchy Type", "EU Statistical (NUTS 3 > 2 > 1 > Country)", "EU market practice", "Hierarchy of removed EU geography."),
    *[_j("Code list: Benchmark Regulatory Status", v, "BMR", "Whole list removed with FX Rate Source.Benchmark Regulatory Status.")
      for v in ("Critical Benchmark (UK)", "Critical Benchmark (EU)", "Significant Benchmark", "Non-Significant Benchmark", "Not a Regulated Benchmark")],
    _j("Code list: Internal Entity Category", "Management Company / AIFM", "AIFMD", "UCITS ManCo and AIFM (also UCITS); the US entity set is in the re-cut list (Fund Adviser, Fund Trust (registrant), Transfer Agent and others)."),
    _j("Code list: Internal Entity Category", "MiFID Investment Firm", "MiFID II", "No EU investment firm; the US broker-dealer and RIA categories replace it."),
    _j("Code list: Internal Entity Category", "UK Authorized Firm", "FCA", "No FCA-authorized entity (UK ACD or investment manager)."),
    _j("Code list: Entity Distribution Role", "Global Distributor", "UCITS", "Distributor of UCITS / AIF ranges; no EU fund range."),
    _j("Code list: Entity Distribution Role", "Management Company", "UCITS", "UCITS management company role; the '40 Act fund adviser role is Investment Manager."),
    _j("Code list: Entity Distribution Role", "AIFM", "AIFMD", "No AIFM."),
    _j("Code list: Entity Distribution Role", "s21 Financial Promotion Approver", "FCA", "UK FSMA s21 approver; US communications approval is a FINRA Rule 2210 principal, recorded in 04 / 08."),
    _j("Code list: Industry Classification Scheme", "NACE", "EU market practice", "EU activity classification; NAICS, US SIC, GICS and ISIC remain."),
    _j("Code list: Industry Classification Scheme", "UK SIC", "UK market practice", "UK national version of NACE."),
    _j("Code list: FX Rate Usage", "Share Class Hedging", "UCITS", "Currency-hedged share classes are a UCITS practice; '40 Act share classes share one portfolio (Rule 18f-3), so hedging is at fund level (NAV Valuation)."),
    _j("Code list: FX Quote Convention", "Units of Currency per 1 GBP", "UK market practice", "GBP pivot of a UK reporting firm; the USD pivot and market convention cover a US firm."),
    _j("Code list: Entity Distribution Role", "Sub-Distributor", "EU market practice", "EU cross-border sub-distribution; the US roles are Selling Dealer or Agent and Placement Agent."),
    _j("Code list: Entity Distribution Role", "Marketing Communication Issuer", "MiFID II", "MiFID marketing communication term; US communications are FINRA Rule 2210 and Advisers Act Rule 206(4)-1, approved by principals (04 / 08)."),
    _j("Code list: Delivery Method", "FinDatEx EMT exchange practice (source and definition wording)", "FinDatEx", "Shared list (steward 09): the source and the 'EMT/target-market data' example leave the definition; no value removed (SHARED_RECUTS)."),
    _j("Code list: Shared Code List Candidate", "Distribution Strategy", "FinDatEx", "FinDatEx EMT / MiFID distribution strategy candidate; the shared list retires under CW-039."),
    # Code-list values of shared lists stewarded by 09 (applied by the program lead; see SHARED_RECUTS)
    *[_j("Code list: Regulator", v, r, "Shared list re-cut to US authorities (CW-039).")
      for v, r in (("UK_FCA", "FCA"), ("UK_PRA", "Other EU/UK"), ("UK_HMT_OFSI", "Other EU/UK"), ("UK_NCA", "Other EU/UK"),
                   ("LU_CSSF", "Other EU/UK"), ("IE_CBI", "Other EU/UK"), ("DE_BAFIN", "Other EU/UK"), ("FR_AMF", "Other EU/UK"),
                   ("IT_CONSOB_BANCA_D_ITALIA", "Other EU/UK"), ("ES_CNMV", "Other EU/UK"), ("NL_AFM", "Other EU/UK"),
                   ("OTHER_EU_NCA", "Other EU/UK"), ("EU_ESMA", "Other EU/UK"), ("EU_COMMISSION", "Other EU/UK"))],
    _j("Code list: Regulator", "CH_FINMA", "Other non-US", "Swiss regulator (not EU/UK); removed by the US-only re-cut of CW-039."),
    *[_j("Code list: Distribution Market", v, r, "Shared list re-cut to US only (CW-039); EU sub-markets and European groupings.")
      for v, r in (("UK", "UK market practice"), ("EU", "EU market practice"), ("EU_IRELAND", "EU market practice"),
                   ("EU_GERMANY_AUSTRIA", "EU market practice"), ("EU_FRANCE_BENELUX", "EU market practice"),
                   ("EU_ITALY", "EU market practice"), ("EU_IBERIA", "EU market practice"), ("EU_NORDICS", "EU market practice"),
                   ("PAN_EUROPEAN", "EU market practice"))],
    _j("Code list: Distribution Market", "SWITZERLAND", "Other non-US", "Non-US market (Switzerland, not EU/UK); removed by the US-only re-cut of CW-039."),
    _j("Code list: Distribution Market", "CANADA", "Other non-US", "Non-US market (Canada); removed by the US-only re-cut of CW-039."),
    _j("Code list: Distribution Market", "GLOBAL", "Other non-US", "Cross-border accounts spanning markets; the firm distributes in the US only (CW-003)."),
    # Sources
    _j("Sources", "ONS International Territorial Levels (ITL 2025) and National Statistics Postcode Lookup", "UK market practice", "Source of the removed UK geography."),
    _j("Sources", "Eurostat NUTS classification (NUTS 2024)", "EU market practice", "Source of the removed NUTS regions."),
    _j("Sources", "EU / UK Benchmarks Regulation (BMR)", "BMR", "Source of the removed Benchmark Regulatory Status."),
    _j("Sources", "FCA Financial Services Register and FCA Handbook (PERG, SUP, COBS 3)", "FCA", "Replaced by the SEC / FINRA registers (Form ADV, BD, TA-1) and the OCC."),
    _j("Sources", "CSSF and Central Bank of Ireland entity registers", "Other EU/UK", "Luxembourg and Irish registers (CSSF, Central Bank of Ireland)."),
    _j("Sources", "UCITS Directive 2009/65/EC, AIFMD 2011/61/EU (as amended by 2024/927), MiFID II 2014/65/EU", "UCITS", "Also AIFMD and MiFID II; authorization and passports, which left 09 under CD-250."),
    _j("Sources", "NACE Rev. 2.1 (Delegated Reg. (EU) 2023/137, in force 1 Jan 2025) and correspondence tables", "EU market practice", "Industry Classification examples re-sourced to NAICS 2022."),
    _j("Sources", "UK SIC 2007 and UK SIC 2026", "UK market practice", "UK SIC removed from Industry Classification Scheme."),
    _j("Sources", "openfunds (secondary reference of Dealing Day Pattern)", "EU market practice", "Reference tag only (no source row); re-sourced to SEC Rule 22c-1."),
]

# ---------------------------------------------------------------------------------------------------------------------
# Shared lists stewarded by 09: proposed re-cuts (program lead applies them in shared_code_lists.py; CW-039, CW-004).
# ---------------------------------------------------------------------------------------------------------------------
SHARED_RECUTS = [
    {"list": "Regulator", "decision": _D,
     "remove": ["UK_FCA", "UK_PRA", "UK_HMT_OFSI", "UK_NCA", "LU_CSSF", "IE_CBI", "DE_BAFIN", "FR_AMF", "IT_CONSOB_BANCA_D_ITALIA",
                "ES_CNMV", "NL_AFM", "CH_FINMA", "OTHER_EU_NCA", "EU_ESMA", "EU_COMMISSION"],
     "add": [("US_MSRB", "MSRB", "Municipal Securities Rulemaking Board: rules for dealers in municipal securities and 529 municipal fund securities (the broker-dealer sells both; CW-037).")],
     "source": "Internal (official names per each authority)",
     "note": "US authorities kept (SEC, FINRA, state securities regulators, CFTC / NFA, OCC, state banking regulators, Federal Reserve, DOL / EBSA, state insurance regulators, IRS / Treasury, FinCEN, OFAC, DOJ, state attorneys general) and IOSCO as standard setter. US_STATE_INSURANCE_REGULATOR is an insurance-dedicated residue candidate for W4 (kept). Consumers (02, 11 members; 19, 20, 25, 26, 27, 31, 33, 35, 36, 37, 38, 39, 40, 42, 43 direct) must drop the removed codes in their own passes."},
    {"list": "Distribution Market", "decision": _D,
     "remove": ["CANADA", "UK", "SWITZERLAND", "EU", "EU_IRELAND", "EU_GERMANY_AUSTRIA", "EU_FRANCE_BENELUX", "EU_ITALY", "EU_IBERIA",
                "EU_NORDICS", "PAN_EUROPEAN", "GLOBAL"],
     "add": [],
     "definition": "Commercial market in which the firm sells, contracts or sets territories, modeled in 09 as a Geographic Group of type Market; US only in the wealth model (CW-003); steward 09.",
     "note": "Leaves the single value US, below the two-value floor: propose at W4 to retire the list or turn it into US sales and service regions (Geographic Group Type = Market). Members 03, 05, 07 are replaced or retired at W2 / W4; whether the list survives (or becomes US sales regions as Geographic Groups) is for the W4 decision on 03 and 05."},
    {"list": "Geographic Unit Type", "decision": _D,
     "remove": ["UK_POSTCODE_AREA", "UK_POSTCODE_DISTRICT", "UK_POSTCODE_SECTOR", "ITL_REGION", "NUTS_REGION"],
     "add": [],
     "relabel": [("COUNTRY_SUBDIVISION", "Country Subdivision", "ISO 3166-2, e.g. US state, district or outlying area.")],
     "source": "ISO 3166-1/-2; US Census FIPS, ZCTA; OMB Bulletin 23-01 (CBSA, CSA)",
     "note": "The value_map keys ('09', 'Geographic Unit Type', 'UK Postcode Area' ... 'NUTS Region') go with the values; the 07 member keeps its UK values until 07 retires (W4)."},
    {"list": "Delivery Method", "decision": _D,
     "remove": [], "add": [],
     "definition": "Method or route by which a document, report or data set is delivered to its recipient (client and shareholder documents, client reports, licensed vendor data); steward 09.",
     "source": "Internal (aligned to SEC e-delivery guidance and SEC Rule 30e-3 notice-and-access)",
     "note": "Wording only: drops 'EMT/target-market data' and 'FinDatEx EMT exchange practice' (JURISDICTION entry, FinDatEx). INTERMEDIARY_DISTRIBUTION stays for the IC line."},
    {"list": "Business Line", "decision": _D,
     "remove": ["MUTUAL_FUND", "ETF", "COLLECTIVE_INVESTMENT_TRUST", "SEPARATELY_MANAGED_ACCOUNT", "PRIVATE_MARKETS", "INSURANCE_DEDICATED_FUND"],
     "add": [("DB", "Direct brokerage and self-directed investing", ""),
             ("DA", "Digital advice", ""),
             ("HA", "Human and hybrid advice", ""),
             ("PF", "Proprietary funds and ETFs", "Own mutual funds, ETFs and CITs."),
             ("WR", "Workplace retirement recordkeeping", ""),
             ("IA", "Institutional advisory", "OCIO, institutional mandates in own funds and separate accounts."),
             ("IC", "Intermediary channel", ""),
             ("TR", "Personal trust services", "Optional line.")],
     "definition": "Enterprise business line of the wealth manager (CW-004): the eight lines of the business capability map whose clients, books, products or records a row belongs to; steward 09.",
     "source": "Internal (Business_Capability_Map business lines, CW-004)",
     "note": "CW-004 records the list as applied at W0, but shared_code_lists.py still carries the six CD-209 values; codes are the CW-004 two-letter codes (DB ... TR) and labels the CW-004 names, as ruled by the program lead, so the capability map, the shared list and 01's local list agree (01's labels use title case; its value_map should map to these codes). Not a JURISDICTION matter: PRIVATE_MARKETS and INSURANCE_DEDICATED_FUND leave under CW-004 and the W4 retirement of 30; the 18 and 21 member value_maps need re-mapping (MUTUAL_FUND, ETF, COLLECTIVE_INVESTMENT_TRUST -> PF; SEPARATELY_MANAGED_ACCOUNT -> IA or the advice lines) by their editors."},
]

# ---------------------------------------------------------------------------------------------------------------------
# Decision
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-909", "theme": "Scope", "title": "US-only pass of 09 Shared & Enterprise Reference Data",
     "domains": ["09"],
     "issue": "09 described the reference data of a wholesale asset manager distributing in the US and EU/UK: UK postcode, ITL and NUTS geography, EU and EEA membership flags, a UCITS-style non-dealing threshold, EU / UK BMR status of FX sources, an FCA Firm Reference Number, EU/UK entity categories and distribution roles (ManCo, AIFM, MiFID firm, UK authorized firm, Global Distributor, s21 approver), NACE and UK SIC, and EU/UK regulator and market values in the shared lists it stewards; Luxembourg and German examples; and 'wholesale' perspective text.",
     "resolution": "Removals (JURISDICTION, 74 entries: 3 objects, 5 attributes, 57 code values of which 28 in the shared Regulator, Distribution Market and Delivery Method lists, 9 sources; by regime: EU market practice 19, UK market practice 14, Other EU/UK 14, BMR 7, FCA 5, UCITS 4, Other non-US 4, AIFMD 3, MiFID II 2, FinDatEx 2): objects UK Postcode, ITL Region and NUTS Region with their object group 'UK & EU Statistical & Postal Geography'; Country.EU Member State Indicator and EEA Member Indicator; Dealing Calendar Rule.Non-Dealing Day Threshold; FX Rate Source.Benchmark Regulatory Status (and its DERIVED entry) with the list Benchmark Regulatory Status; Legal Entity Identifier.FCA Firm Reference Number; EU/UK values of Geographic Unit Type, Geographic Scheme, Geographic Hierarchy Type, Internal Entity Category, Entity Distribution Role (Global Distributor, Management Company, AIFM, s21 Financial Promotion Approver, Sub-Distributor, Marketing Communication Issuer), Industry Classification Scheme and Shared Code List Candidate; FX Rate Usage value Share Class Hedging (UCITS practice); FX Quote Convention value Units of Currency per 1 GBP; 8 EU/UK source rows and the openfunds reference tag. Attribute IDs after a removed row renumber within the Geography, Time Zones & Calendars, Currency & FX Reference and Internal Legal Entities families. "
                   "Re-sourcing: Internal Entity Category re-cut to the US set (Parent Holding Company renamed from Ultimate Holding Company; Registered Investment Adviser from SEC-Registered Investment Adviser; Broker-Dealer (self-clearing) from Broker-Dealer / Principal Underwriter; National Trust Company from Bank / Trust Company; Fund Adviser, Fund Trust (registrant), Transfer Agent, Recordkeeper added; Intermediate Holding Company, Service Company, Branch kept; General Partner / Fund Vehicle Sponsor kept for the W4 retirement decision) and sourced to Form ADV, Form BD, Form TA-1 and the OCC charter (new source row OCC; SEC source row extended to Form TA-1 and SEC file numbers); entity regulatory identifiers: CRD and CIK stay, the SEC file numbers (801-, 8-, 84-) and OCC charter number are stated as held per registration in 38 (note on Firm CRD Number; no new attribute, to avoid re-mastering 38's Regulator Reference Number); Entity Distribution Role re-cut to the US roles (Principal Underwriter / Distributor split into Principal Underwriter and Distributor; Selling Dealer or Agent, Placement Agent, Transfer Agent, Recordkeeper and 529 Program Manager added; Investment Manager, Sub-Adviser, Model Provider and the employing and contracting roles kept); SEC file number 811- (fund trusts) added to the source row and the Firm CRD note; Dealing Day Pattern to SEC Rule 22c-1 (new source row); Industry Classification examples from NACE to NAICS 2022 (523940, concordance from NAICS 2017 523920). "
                   "Named additions (plan section 5.1): Calendar Type value 'Banking / Settlement' renamed 'Settlement (CSD / Payment System)' as CD-185 proposed (US examples Fedwire Funds Service, FedACH, DTC; bank holidays move to 'Public Holiday'), a CAL-US-FEDWIRE example on Composite Calendar.Component Calendar, and the Bond Market value described as SIFMA US bond market closes, Calendar Source Central Bank described with the Federal Reserve holiday schedule; source rows SIFMA holiday recommendations and Federal Reserve Financial Services holiday schedules; Internal Legal Entity examples and an Entity Category note listing the plan section 2 entities (LEN-0001 to LEN-0009). "
                   "Perspective: META subtitle 'Wealth manager (direct) | Scope: US' dated 2026-10-14; overview Purpose, Scope, Core model, Design principles, CDE, Primary / Secondary Reference and Suggested next steps rewritten; family definitions of Geography, Time Zones & Calendars, Internal Legal Entities and Industry Classification and the object-group texts of Countries & Subdivisions, Geographic Unit & Hierarchy and Geographic Groupings rewritten; Geographic Group Type value descriptions re-cut to US examples (country clusters kept for investment exposure reporting); FX Rate Usage 'retrocessions' wording and the 'MiFID Client Category' mention in Shared Code List Candidate removed; LSEG source text no longer cites UK BMR; examples re-cut to US instances in Country, Currency (USD), Geographic Unit (successor), Geographic Group, Geographic Group Membership, Dealing Calendar Rule, Language, Locale, Number & Date Convention, Internal Legal Entity (Head Office Entity blank), Entity Distribution Role (role, channel scope), Org Unit (name; booked in the RIA LEN-0004) and the Industry Classification objects; US Statistical & Postal Geography group text, overview design principle 5 and next step 3 (shared lists now exist), REL Fund Dealing Calendar note ('threshold rule' dropped) and the Federal Reserve source wording (Sundays and weekday holidays) corrected; enrich_09 SUMMARY rewritten and GRAIN of the three removed objects dropped; Source_Notes rewritten with a 'Wealth model carry-over (W1)' section, and its boundary statements corrected (registrations in 38, accounting period status and cost centers in 19, employee master in 20; workforce recommendation deleted). "
                   "Shared lists (SHARED_RECUTS, applied by the program lead at W5): Regulator to US authorities plus MSRB; Distribution Market to US (retire or convert at W4); Geographic Unit Type without UK/EU values; Delivery Method definition and source without FinDatEx; Business Line to the eight CW-004 lines with codes DB, DA, HA, PF, WR, IA, IC, TR. Downstream readers of the removed items (data products, data models, semantic model) are listed in NOTES item 6 and re-pointed by the program lead at merge. Kept: Country and subdivisions of every country, currencies, time zones, foreign exchange, bond and settlement calendars (TARGET, London), FX rate types and sources (WM/Reuters, ECB, Bank of England), NAICS, US SIC, GICS, ISIC. No re-points needed: 09 has no Reference (Account) and its Reference (Party) resolves (CW-021).",
     "rationale": "CW-003 and CW-022: US only narrows where the firm is regulated and distributes, not the investment universe, so foreign calendars, currencies and FX sources used by the international funds stay; every removal is restorable from wholesale-v1.0 through the JURISDICTION entries.",
     "action": "W1", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

SHARED_CANDIDATES = [
    ("Calendar Type", "09", "Value 'Banking / Settlement' renamed 'Settlement (CSD / Payment System)' (CD-185, the value 26 proposed; US examples Fedwire Funds Service, FedACH, DTC); bank holidays move to 'Public Holiday'. No content module outside 09 uses the old value."),
    ("Calendar Type", "09", "49 (client settlement) and 50 (money movement) will cite the Bond Market and Payment System calendars; register them as direct users of a shared Calendar Type, or have them reference CAL- calendars only."),
]

NOTES = """
W1 (wealth) - 09 carry-over notes (CW-909)

1. Remaining grep hits, kept by the investment-universe principle (CW-022 point 4): CAL-EU-TARGET (Composite Calendar
   description and FX Rate Type.Publication Calendar example), CAL-GB-XLON (Market Closure Calendars example),
   'UK bank holidays' and 'TARGET' in Calendar Type, Subdivision Category values Nation (UK), Land, Canton and
   Canton / Commune (Luxembourg) (ISO 3166-2 categories of foreign countries), the ECB, Bank of England and LSEG
   WM/Reuters FX sources and the 16:00 Europe/London fixing time.
2. References to retiring or later-replaced domains left for W2 / W4 (not changed): Scope overview mentions 03 Sales
   (SLT-), 04, 05 (AGR-), 06 (FEED-/XWK-), 07 (TER-), 08 (LIC-), 10; Geographic Group.Consuming Domains example
   '03 Sales; 07 Compensation & Territory'; Code List Consumer example '06 Sales Transactions & AUM Attribution';
   FX Rate Usage values Distribution Payment Calculation (05), Incentive Compensation (07), Financial Reporting and
   Budget / Forecast (10); Org Hierarchy Type 'Distribution Organization' (03 and 07); Entity Distribution Role
   'Default Contracting Entity Indicator' (05); REL rows Territory (07 TER-), Agreement (05 AGR-), License (08 LIC-),
   Sales Team (03 SLT-), Reporting Period Definition (06, 07, 10, 12), Locale (04), Currency (01, 06, 10).
3. W4 retirement candidates (private markets / insurance-dedicated): Internal Entity Category value 'General Partner /
   Fund Vehicle Sponsor'; shared Regulator value US_STATE_INSURANCE_REGULATOR.
4. Business Domain list (09 local, shared 'Business Domain') still names '02 Client & Customer' and the wholesale 01-14
   names; domains.py renames at the W1 merge (CW-040) and the shared list follows, not this module.
5. Distribution Channel (steward 09) carries UK/EU values (INTERMEDIARY_IFA_WEALTH, INTERMEDIARY_DFM,
   INTERMEDIARY_EU_BANK, UK and EU platforms) and a 'UK/EU wholesale' source: re-cut at W4 per CW-039, not here.
   Delivery Method (steward 09): wording re-cut proposed in SHARED_RECUTS with a JURISDICTION entry (FinDatEx).
6. Readers of the removed 09 objects, attributes and values outside 09 (not edited; the program lead re-points them
   at merge under CW-909). Source files (grep of _tools on 2026-10-14):
   - data_products/specs_b_foundational.py:457 (Country: EU Member State Indicator, EEA Member Indicator), :480
     (Legal Entity Identifier: FCA Firm Reference Number), :495 (UK Postcode), :496 (ITL Region), :497 (NUTS Region),
     :503 (FX Rate Source: Benchmark Regulatory Status), :542 (text naming UK Postcode, ITL Region, NUTS Region).
   - data_products/specs_o_operations.py:29-30 and :98 (Dealing Calendar Rule: Non-Dealing Day Threshold).
   - data_products/specs_f_compliance.py:573 (Country: EU Member State Indicator, EEA Member Indicator).
   - data_products/specs_e4_technology_communications.py:640 and :687 (Country: EU Member State Indicator).
   - data_products/specs_e4_compliance_legal.py:98 (Legal Entity Identifier: FCA Firm Reference Number).
   - data_products/specs_n_compliance_controls.py:281 (Legal Entity Identifier: FCA Firm Reference Number).
   - data_models/models_f3.py:337 and :341 (UK Postcode, ITL Region, NUTS Region folded into Geographic Unit).
   - data_models/keys_g4_08_09.py:121-123 (UK Postcode, ITL Region, NUTS Region).
   - data_models/models_c7_product_data.py:268 (note citing EEA Member Indicator).
   - semantic_model/models/sm_00_shared_dimensions.py:412-413 (EU Member State Indicator, EEA Member Indicator).
   - enrichment/enrich_07.py:76 (DERIVED 07 'UK Postcode District' -> 09; check_enrichment 07 still prints OK) and the
     07 Geographic Unit Type list (UK / NUTS values); 07 retires at W4.
   Generated outputs that follow when rebuilt: data_products/_catalog.txt (lines 675, 897, 906-910, 931, 945, 963),
   data_models/_conformed.txt:159, semantic_model/out/spine.yaml (2631-2632, 3145) and semantic_model/out/models/SM-00.yaml
   (878, 880). No reader uses the removed code values (Share Class Hedging, Sub-Distributor, Marketing Communication
   Issuer, Banking / Settlement, Units of Currency per 1 GBP). Readers of 02's 'FCA Firm Reference Number' (02 UK & EU
   Regulatory Identifier) are 02's, not 09's.
   Other faults seen (not edited): 38 Entity Authorization.Regulator Reference Number definition and example cite FRN
   and CSSF / CBI references (example S00001234) and the Entity Authorization Type list is 'aligned to SEC, FINRA, FCA,
   CSSF, CBI registers': for the 38 US-only pass (W4), re-cut to SEC file numbers (801-, 8-, 84-, 811-) and the OCC
   charter number; wholesale content_02_client_and_customer.py still holds Organization.FCA Firm Reference Number (the
   W1 02 replacement handles it); proposals_26.py CD-185 proposal is now applied in 09 (Calendar Type rename).
7. Unverified: the ISO 20275 ELF code of a Delaware LLC (example states 'confirm'); the SIFMA holiday-schedule page URL
   (source row points to sifma.org); the OCC charter-register page (source row points to occ.gov). Verified by search on
   2026-10-14: Federal Reserve holiday schedule page (frbservices.org/about/holiday-schedules) and the NAICS 2022 merge of
   523920 and 523930 into 523940. Fedwire Sunday and weekday-holiday operation (no earlier than 2028) is marked 'confirm'.
   Dealing Day Pattern values Weekly - Named Weekday, Fortnightly, Mid-Month and Month-End are kept pending Fund
   Operations confirmation that a CIT uses them (Source_Notes question 3).
8. Counts: builder before 47 objects, 223 attributes, 67 CDEs (30.0%), 57 code lists; after 44 objects, 212 attributes,
   63 CDEs (29.7%), 56 code lists. Sources 32 -> 28 (8 removed, 4 added: OCC, SIFMA, Federal Reserve Financial
   Services, SEC Rule 22c-1).
9. Left as they are (review Lows, with reason): Code List examples (Code List Definition 'Route through which products
   reach end investors', Source Standard 'Internal (Cerulli-style channel scheme)', Change Summary 'Bank / Trust') follow
   the Distribution Channel registry example and change with the W4 Distribution Channel re-cut; REL labels
   'Postal Address (02 CC)', 'Party (02 CC, PTY-)' and 'Organization (02 CC, PTY-)' use the wholesale 02 family code and
   the wholesale Postal Address object; they are labels only, still resolve, and change when the wealth 02 merges
   (CW-040: HH; Postal Address becomes an attribute group of Contact Point).
10. Plan section 5.1 row 09 says 'EU calendars ... removed', which contradicts CW-022; TARGET and London calendars are
   kept here; the plan row is the program lead's to amend.
"""
