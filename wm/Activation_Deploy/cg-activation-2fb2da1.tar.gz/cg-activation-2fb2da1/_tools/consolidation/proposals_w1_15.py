"""Consolidation proposals from the W1 draft of Data Domain 15 Account (wealth manager, replaced in place, CW-006), 2026-10-14.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py,
jurisdiction.py and shared_code_lists.py at the W1 merge. Formats follow CONTRACT.md in this folder. Decisions implemented:
CW-006, CW-021, CW-024, CW-026, CW-031 to CW-035, CW-039, CW-040 (proposals_wealth_w0.py, proposals_wealth_w1.py).
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES  (prefix, entity, owner domain, status, note) - decisions.PREFIXES format
# None beyond the four reserved in proposals_wealth_w1.py (AFEA-, AAG-, ENRL-, AISB-) and the eight kept 15 prefixes
# (ACC-, ACI-, ABD-, ATC-, SIN-, ABI-, ALE-, ARX-). RMD Record, Cash Sweep Election, Account Disclosure Delivery and
# Retirement Distribution Election keep composite keys (brief section 6).
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

KEY_FORMATS = [
    ("AFEA-", "AFEA-<sequence, 7 digits>, e.g. AFEA-0031207", "Account feature (account x feature type x period)."),
    ("AAG-", "AAG-<sequence, 7 digits>, e.g. AAG-0012901", "Account agreement (account x agreement type x version)."),
    ("ENRL-", "ENRL-<year>-<sequence, 7 digits>, e.g. ENRL-2025-0004418", "Program enrollment (account x service offering x period)."),
    ("AISB-", "AISB-<year>-<sequence, 6 digits>, e.g. AISB-2026-000231", "Alternative investment subscription."),
    ("RMD Record", "Composite: ACC- / distribution year, e.g. 'ACC-0061230 / 2026'", "No prefix (brief section 6: ARMD-, IRMD-, RMDS- rejected)."),
    ("Cash Sweep Election", "Composite: ACC- / sweep vehicle type / effective from", ""),
    ("Account Disclosure Delivery", "Composite: ACC- / disclosure type / version / delivered date", ""),
    ("Retirement Distribution Election", "Composite: ACC- / withholding election type / effective from", ""),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED MEMBERSHIPS: local 15 lists carrying an enterprise shared list's exact name and values (copied 2026-10-14).
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Networking Level", "local": "Networking Level",
     "value_map": {"Level 0": "LEVEL_0", "Level 1": "LEVEL_1", "Level 3": "LEVEL_3", "Level 4": "LEVEL_4",
                   "Not Networked": "NOT_NETWORKED"},
     "new_values": [], "note": "15 stays steward (CW-039); kept for the IC line. Local descriptions now identical to the shared ones (review F); both still to be confirmed against the current DTCC Networking matrix."},
    {"shared": "Identifier Status", "local": "Identifier Status",
     "value_map": {"Active": "ACTIVE", "Inactive": "INACTIVE", "Retired": "RETIRED", "Unverified": "UNVERIFIED"},
     "new_values": [], "note": "Account Identifier Status."},
    {"shared": "Frequency", "local": "Frequency",
     "value_map": {"Weekly": "WEEKLY", "Fortnightly": "FORTNIGHTLY", "Monthly": "MONTHLY", "Quarterly": "QUARTERLY",
                   "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL", "On Event": "ON_EVENT", "Ad Hoc": "AD_HOC"},
     "new_values": [], "note": "Instruction Frequency, Statement Frequency."},
    {"shared": "Delivery Method", "local": "Delivery Method",
     "value_map": {"Paper Mail": "PAPER_MAIL", "Email - Notification with Link": "EMAIL_NOTIFICATION_LINK",
                   "Email - Attachment": "EMAIL_ATTACHMENT", "Portal Posting": "PORTAL"},
     "new_values": [], "note": "Disclosure Delivery Method (subset)."},
    {"shared": "Case Status", "local": "Case Status",
     "value_map": {"New / Received": "NEW", "Pending Good Order": "PENDING_GOOD_ORDER", "In Progress": "IN_PROGRESS",
                   "Waiting on Client": "WAITING_ON_CLIENT", "Resolved / Completed": "RESOLVED", "Rejected": "REJECTED",
                   "Canceled": "CANCELED"},
     "new_values": [], "note": "Alternative Investment Subscription.Subscription Documents Status (subset)."},
    {"shared": "Business Line", "local": "Business Line",
     "value_map": {"DB": "DB", "DA": "DA", "HA": "HA", "PF": "PF", "WR": "WR", "IA": "IA", "IC": "IC", "TR": "TR"},
     "new_values": ["DB", "DA", "HA", "PF", "WR", "IA", "IC", "TR"],
     "note": "CW-004 values encoded as the two-letter codes (program lead ruling for 01, 02, 09 and 15); the names are the "
             "descriptions. shared_code_lists.py still carries the six wholesale values (CD-209); apply at W5 (CW-039). Account.Account Business Line."},
    {"shared": "Agreement Status", "local": "Agreement Status",
     "value_map": {"Pending Signature": "PENDING_SIGNATURE", "Executed - Not Yet Effective": "EXECUTED_NOT_EFFECTIVE",
                   "Active": "ACTIVE", "Terminated": "TERMINATED", "Superseded": "SUPERSEDED"},
     "new_values": [], "note": "Account Agreement.Agreement Status (subset of the 05 steward list; replaces the local list of the same name, review F)."},
]
# Brief section 8 listed Record Status and Approval Status; not used: Feature Status needs Suspended and Revoked, which
# neither has. Frequency keeps the shared value 'Fortnightly'; steward 09 is asked to rename it 'Biweekly' (US usage).

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Cost Basis Method", ["15", "18"],
     "Brief: candidate to join the shared Lot Relief Method (steward 18) once its UK value (TCGA 1992 s105-106A) is removed "
     "(CW-039). 15 adds 'Loss / Gain Utilization', which Lot Relief Method calls 'Tax-Optimized'. 49 client lots should use the same list."),
    ("RMD Status", ["15", "16"], "Same values as the 16 RMD Status except 'Satisfied from Another IRA' (16: '... Plan / IRA'). One list, steward 16 or 15."),
    ("Account Risk Tolerance / Time Horizon / Liquidity Needs", ["02", "15", "45"],
     "15 cites the 02 Investor Profile scales as External; make them shared lists stewarded by 02 when the 02 module lands (CW-024)."),
    ("Withholding Election Type", ["15", "16"], "16 Tax Withholding & 1099-R Detail uses W-4R and W-4P elections on plan distributions."),
    ("Beneficiary Relationship", ["02", "15", "51"], "Overlaps 02 Party Relationship Type values (spouse, child, ...); 51 trust beneficiaries will need the same."),
    ("Tax Form Type", ["02", "15"], "15 Tax ID Type was removed (a 02 party fact, TIN Type); Tax Form Type may join a 02 tax list."),
    ("Restriction Imposed By / Closure Initiator / Lifecycle Event Source", ["15"], "Overlapping 'who' lists kept separate for now (review F); merge candidates at W5."),
    ("Account Restriction Type / Restriction Scope", ["15", "48", "50"], "48 and 50 test these at order and disbursement time; they may want them shared."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (plan section 5.3 watchlist names)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Account",
     "usages": [("15", "Account (ACC-)", "Every client account kind: Brokerage, Fund-Only, Managed Advisory, Participant, Plan, Fiduciary, Institutional Separate Account (CW-035)."),
                ("29", "TA-registered account", "Processing view of a fund-only or omnibus account; the master is 15 ACC-."),
                ("16", "Participant Account", "15 account type; 16 holds Participant Plan Membership (PMEM-)."),
                ("43", "Corporate Bank Account (BKAC-)", "The firm's own bank accounts; never a 15 account.")],
     "recommendation": "Bare 'Account' is 15 ACC-. Glossary terms Brokerage Account, Fund-Only Account, Participant Account, Fiduciary Account are 15 Account Type values."},
    {"term": "Program",
     "usages": [("01", "Service Offering (OFFR-)", "Definition of an advisory or managed program."),
                ("15", "Program Enrollment (ENRL-)", "An account's enrollment in a 01 offering."),
                ("50", "Sweep Program (SWP-)", "Bank deposit sweep program."),
                ("46", "Managed program operations", "Model assignment and rebalancing per enrolled account.")],
     "recommendation": "Always qualify: 'Advisory Program' or 'Service Offering' (01), 'Program Enrollment' (15), 'Sweep Program' (50)."},
    {"term": "Sweep",
     "usages": [("15", "Cash Sweep Election", "The client's election of sweep vehicle, excluded banks."),
                ("50", "Sweep Program (SWP-)", "The program, program banks, allocations."),
                ("49", "Sweep balance", "Balance by reference.")],
     "recommendation": "Follows the existing register entry: 15 holds the 'Cash Sweep Election' (the brief's 'Sweep Election' was renamed to match)."},
    {"term": "Transfer",
     "usages": [("49", "Account Transfer (CAX-)", "ACATS transfer of assets between firms."),
                ("50", "Money Movement (MMT-)", "Cash transfers, recurring transfers between accounts."),
                ("29", "Fund Order transfer / exchange", "TA share transfers."),
                ("15", "Recurring Transfer Between Accounts (Standing Instruction Type); Transfer Out (ACATS) closure reason", "Instruction and reason only.")],
     "recommendation": "Always qualify: 'Account Transfer' (49), 'Cash Transfer' / 'Money Movement' (50), 'Share Transfer' (29)."},
    {"term": "Plan",
     "usages": [("16", "Retirement Plan / Participant Plan Membership", "Workplace plans the firm recordkeeps."),
                ("45", "Financial Plan", "Advice plan."),
                ("15", "Plan Account, 529 Plan registration", "Account types and registrations only.")],
     "recommendation": "Always qualify: 'Retirement Plan' (16, 02), 'Financial Plan' (45), '529 Plan' (registration type)."},
    {"term": "Agreement",
     "usages": [("15", "Account Agreement (AAG-)", "Customer, margin, options, advisory, custodial agreements accepted by the client for an account."),
                ("39", "Contract (CTRCT-)", "Negotiated contracts, incl. institutional investment management agreements."),
                ("05", "Agreement (AGR-)", "Intermediary agreements (W4)."),
                ("35", "Fund Advisory Agreement", "Fund-level advisory contracts.")],
     "recommendation": "15 uses 'Account Agreement'; negotiated institutional agreements are 39 Contracts (Institutional Account.Governing Agreement re-pointed)."},
    {"term": "Enrollment",
     "usages": [("15", "Program Enrollment (ENRL-)", "Advisory program enrollment of an account."),
                ("16", "Participant Plan Membership enrollment", "Plan enrollment of a participant.")],
     "recommendation": "Always qualify: 'Program Enrollment' (15), 'Plan Enrollment' (16)."},
    {"term": "Hold",
     "usages": [("15", "Account Restriction (ARX-)", "Holds on securities transactions or the whole account, incl. FINRA Rule 2165 holds of that kind."),
                ("50", "Money Movement Hold (MMH-)", "Holds on disbursements, incl. FINRA Rule 2165 disbursement holds."),
                ("02", "Vulnerability Concern", "The concern; the 15 restriction references it (15 to 02).")],
     "recommendation": "Row rule (program lead ruling 10): a disbursement hold is 50 MMH-, a transaction or account-wide hold is 15 ARX-; each references the 02 concern. Rule 2165 citation: confirm (SR-FINRA-2026-018 pending)."},
    {"term": "Subscription",
     "usages": [("15", "Alternative Investment Subscription (AISB-)", "Feeder-fund subscription of an account."),
                ("04", "Subscription (SUB-)", "Marketing content subscription.")],
     "recommendation": "Always qualify: 'Alternative Investment Subscription' (15), 'Content Subscription' (04)."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION: EU/UK concepts of the wholesale 15 (tag wholesale-v1.0) that the wealth 15 leaves out (CW-915).
# ---------------------------------------------------------------------------------------------------------------------
_D = "CW-915"
JURISDICTION = [
    {"domain": "15", "object": "Code list: Account Registration Type", "attribute": "ISA", "regime": "Other EU/UK", "decision": _D,
     "note": "UK Individual Savings Account (HMRC ISA Regulations 1998). Plan section 13 UK extension restores it."},
    {"domain": "15", "object": "Code list: Account Registration Type", "attribute": "SIPP", "regime": "Other EU/UK", "decision": _D,
     "note": "UK self-invested personal pension. US retirement wrappers are the IRA family."},
    {"domain": "15", "object": "Code list: Account Registration Type", "attribute": "General Investment Account", "regime": "Other EU/UK", "decision": _D,
     "note": "UK platform term for a taxable account; the US equivalent is a brokerage account with an Individual or Joint registration."},
    {"domain": "15", "object": "Code list: Account Registration Type", "attribute": "Nominee", "regime": "Other EU/UK", "decision": _D,
     "note": "UK / EU nominee registration on platforms."},
    {"domain": "15", "object": "Code list: Account Type", "attribute": "Platform / Nominee Account", "regime": "Other EU/UK", "decision": _D,
     "note": "UK / EU fund platform nominee accounts. US intermediary accounts are Networked Investor or Omnibus at Transfer Agent."},
    {"domain": "15", "object": "Intermediary Account Servicing", "attribute": "Nominee Designation", "regime": "Other EU/UK", "decision": _D,
     "note": "Nominee designation on UK / EU platform accounts."},
    {"domain": "15", "object": "Account Tax Reporting Status", "attribute": "Self-Certification on File Indicator", "regime": "CRS", "decision": _D,
     "note": "OECD CRS self-certification; the US does not apply CRS. FATCA status is the W-9 / W-8 in Account Tax Certification."},
    {"domain": "15", "object": "Account Tax Reporting Status", "attribute": "Self-Certification Received Date", "regime": "CRS", "decision": _D,
     "note": "CRS reading; W-8 and W-9 dates stay in Account Tax Certification."},
    {"domain": "15", "object": "Account Tax Reporting Status", "attribute": "Reportable Account Indicator", "regime": "CRS", "decision": _D,
     "note": "CRS / FATCA reportable account flag held for foreign-reporting regimes; FATCA Form 8966 stays as a Tax Reporting Regime value."},
    {"domain": "15", "object": "Account Tax Reporting Status", "attribute": "Tax Residence Country", "regime": "CRS", "decision": _D,
     "note": "CRS reading removed; residence for chapter 3 and treaty purposes is 02 Tax Profile.Tax Residence Countries and the W-8 Treaty Country."},
    {"domain": "15", "object": "Code list: Tax Form Type", "attribute": "CRS Self-Certification - Individual", "regime": "CRS", "decision": _D, "note": ""},
    {"domain": "15", "object": "Code list: Tax Form Type", "attribute": "CRS Self-Certification - Entity", "regime": "CRS", "decision": _D, "note": ""},
    {"domain": "15", "object": "Code list: Tax Reporting Regime", "attribute": "CRS", "regime": "CRS", "decision": _D, "note": ""},
    {"domain": "15", "object": "Code list: Tax Reporting Regime", "attribute": "UK ISA Reporting", "regime": "Other EU/UK", "decision": _D,
     "note": "HMRC ISA manager returns."},
    {"domain": "15", "object": "Bank Instruction", "attribute": "Bank Routing Identifier (UK sort code and ISO 9362 BIC formats)", "regime": "Other EU/UK", "decision": _D,
     "note": "Attribute kept and re-sourced to the ABA routing transit number (NACHA). Foreign bank wires are 50 money movements."},
    {"domain": "15", "object": "Bank Instruction", "attribute": "Bank Account Number (Masked) (ISO 13616 IBAN format)", "regime": "Other EU/UK", "decision": _D,
     "note": "Attribute kept for US bank account numbers; IBAN accounts are foreign wire beneficiaries in 50."},
    {"domain": "15", "object": "Code list: Account Identifier Scheme", "attribute": "Platform Account Number", "regime": "Other EU/UK", "decision": _D,
     "note": "Described as the UK / EU platform or nominee number."},
    {"domain": "15", "object": "Code list: Application Channel", "attribute": "Platform Feed", "regime": "Other EU/UK", "decision": _D,
     "note": "Described as the UK / EU platform or nominee feed."},
    {"domain": "15", "object": "Code list: Application Channel", "attribute": "ISO 20022 acmt.001", "regime": "EU market practice", "decision": _D,
     "note": "Account opening by ISO 20022 acmt message is European fund platform practice; US fund accounts open through NSCC Networking and Fund/SERV (values kept). ISO 20022 itself is market-neutral and stays elsewhere."},
    {"domain": "15", "object": "Code list: Custodial Statute", "attribute": "Other (non-US equivalent, e.g. UK bare trust for a minor)", "regime": "Other EU/UK", "decision": _D,
     "note": "Value kept as 'Other' with a US description (other state statute or court order)."},
    {"domain": "15", "object": "Sources", "attribute": "UK Individual Savings Account Regulations 1998 and HMRC ISA manager guidance; FCA COLL", "regime": "Other EU/UK", "decision": _D,
     "note": "Sources of the ISA, SIPP and GIA registration types and ISA reporting (HMRC and FCA)."},
    {"domain": "15", "object": "Sources", "attribute": "OECD Common Reporting Standard (CRS) self-certification and due diligence", "regime": "CRS", "decision": _D,
     "note": "CRS half of the wholesale 'FATCA and OECD CRS' source; the FATCA half is kept in the W-8 / Form 1042-S / FATCA source."},
    {"domain": "15", "object": "Sources", "attribute": "ISO 9362 (BIC) / ISO 13616 (IBAN) in the ISO formats source", "regime": "Other EU/UK", "decision": _D,
     "note": "Bank identifier formats no longer used on 15 bank instructions; ISO 3166, 639 and 8601 kept."},
    {"domain": "15", "object": "Sources", "attribute": "ISO 20022 Account Management (acmt) messages", "regime": "EU market practice", "decision": _D,
     "note": "Used only for the acmt account opening and maintenance channel and message references, which the wealth 15 drops."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. DECISIONS: the US-only pass of 15 (pre-allocated CW-915, CW-022)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-915", "theme": "Scope", "title": "US-only pass of 15 Account (replaced domain)",
     "domains": ["15", "02", "50"],
     "issue": "The wholesale 15 Account (tag wholesale-v1.0) carried UK and EU registration types (ISA, SIPP, General Investment Account, Nominee), platform nominee accounts and designations, OECD CRS self-certification, tax residence and reporting, UK ISA reporting, UK sort code, BIC and IBAN bank formats, the ISO 20022 acmt opening channel of European fund platforms, and their sources (HMRC, FCA COLL, OECD CRS). Its META and overview said 'Asset manager (wholesale distributor) | Scope: US + EU/UK' and defined PII under GDPR / UK GDPR.",
     "resolution": "Not carried into the wealth 15 (24 JURISDICTION entries in proposals_w1_15.py): Code list Account Registration Type - ISA, SIPP, General Investment Account, Nominee; Code list Account Type - Platform / Nominee Account; Intermediary Account Servicing - Nominee Designation; Account Tax Reporting Status - Self-Certification on File Indicator, Self-Certification Received Date, Reportable Account Indicator, Tax Residence Country (US reading in 02 Tax Profile); Code list Tax Form Type - two CRS self-certifications; Code list Tax Reporting Regime - CRS, UK ISA Reporting; Bank Instruction - UK sort code, BIC and IBAN formats; Code list Account Identifier Scheme - Platform Account Number; Code list Application Channel - Platform Feed, ISO 20022 acmt.001; Code list Custodial Statute - the UK bare trust reading of Other; Sources - UK ISA Regulations / HMRC / FCA COLL, OECD CRS, ISO 9362 and ISO 13616, ISO 20022 acmt. Kept and re-sourced to the US rule: Bank Routing Identifier (ABA routing transit number, NACHA); Account Tax Certification (W-9, W-8 family, treaty claims) and Account Tax Reporting Status (backup withholding, B-notices, chapter 3 rate, FATCA exemption code, FATCA Form 8966 and Form 1042-S); Registration Jurisdiction and Custodial State (US states, ISO 3166-2); nonresident-alien accounts stay. Amends the wording of CW-031 (program lead ruling, review W9): 'pattern day trader designation' on Margin Account Detail is replaced by the intraday margin standard of FINRA Rule 4210 as amended (Regulatory Notice 26-10, effective June 4, 2026, phase-in to October 20, 2027; confirm), held at account level as Intraday Margin Standard Indicator and Intraday Margin Requirement Basis; Regulation T Account Type moves from Margin Account Detail to Account; Feature Agreements may hold several agreements per feature. The program lead amends CW-031 in decisions.py at merge. META and overview rewritten to 'Wealth manager (direct) | Scope: US'; personal data is described under GLBA / Regulation S-P and US state privacy law, not GDPR.",
     "rationale": "The firm is regulated, distributes and services clients in the US only (CW-003); foreign persons may still hold accounts, so W-8 certification, treaty claims and chapter 3 withholding stay. The register lets a UK extension restore the removed items from the sibling.",
     "action": "W1 merge: append the 24 JURISDICTION entries to jurisdiction.REMOVALS; merge this decision; amend the CW-031 wording", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. NOTES for the W1 merge and WP0
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Fix pass 2026-10-14 applied 00_Program/Rework/Reviews/15_review.md (2 High, 30 Medium, 25 Low) and the program-lead "
    "rulings 1-13. Size: 9 families, 35 objects (21 BO, 14 AG; Account Investment Profile is now an effective-dated BO), 290 "
    "attributes, 97 CDEs (33%), 62 code lists, 51 relationships, 30 sources. Code lists stay above the brief's 35-45: the "
    "kept wholesale attributes need about 20 wholesale lists (listed in Source_Notes section 2).",
    "Add CONCEPT_OWNERSHIP rows (owner 15): Account Investment Profile; Retirement Account Detail; Education & Health Savings "
    "Account Detail; Account Feature (AFEA-); Options Approval Detail; Margin Account Detail; Cash Sweep Election; Account "
    "Agreement (AAG-); Account Disclosure Delivery; Program Enrollment (ENRL-); Alternative Investment Subscription (AISB-); RMD "
    "Record; Retirement Distribution Election; New Issue Eligibility. Retire the rows for Platform Program Enrollment and Account "
    "Privilege (decisions.py CONCEPT_OWNERSHIP still names Platform Program Enrollment).",
    "Sibling references (resolve by prefix or domain number): 02 Investor Profile (INPR-), Identity Verification (KYCV-), "
    "Onboarding Case (ONB-), Client Restriction (CRX-), Investor Qualification and Vulnerability Concern (PTY- composite keys), "
    "Party / Retirement Plan (PTY-); 01 Service Offering (OFFR-), Offering Window (OFWN-), Investment Product (PRD-), Share Class "
    "(SHC-), Investment Mandate (MND-); 16 Participant Plan Membership (PMEM-; Plan Participant Account.Participant is forced to 16 "
    "by OWNERSHIP_OVERRIDES); future: Recommendation (RCO-, 45), Account Transfer (CAX-, 49), Money Movement (MMT-, 50), Sweep "
    "Program (SWP-, 50), Program Bank (PBK-, 50), Trust (TRS-, 51). No 47 attribute.",
    "For the 02 editor: (a) drop 02 Vulnerability Concern.Resulting Account Restrictions; the link is mastered on 15 Account "
    "Restriction.Source Vulnerability Concern (15 to 02; ruling 5). (b) The initial Regulation S-P privacy notice evidence lives in "
    "02 only; 15 dropped its Disclosure Type value. (c) Tax ID Type was removed from 15; 02 Tax Profile.TIN Type is the only record.",
    "Program lead ruling 3 on participant balances: recordkept participant account balances are mastered in 16 (the recordkeeping "
    "book of record), not in 49 and not in 15. The lead corrects content_16 line 12 (design principle 'the participant account and "
    "its balances are 15'), content_16 line 175 (Membership.Participant Account 'balances by money source (owned by 15)') and "
    "enrich_16.py line 68 (DERIVED 'Deferred Vested Benefit Amount' -> '15') at merge.",
    "WP0 READERS of the wholesale 15 to re-point (complete list from the review): data_products/specs_q_accounts_plans.py (DP-093: "
    "lines 51-52, 66, 76, 85-86, 93, 95, 96, 104, 109, 121-122, 124, 127, 132, 165); specs_a_foundational.py lines 634 and 660 "
    "(DP-007, Advisory Program Indicator); specs_j_compliance_2.py lines 68 and 90 (DP-060, Advisory Program Indicator); "
    "specs_o_operations.py line 333 (DP-085, Bank Instruction Reference) and lines 431, 460 (DP-091, Covered Security Indicator: "
    "waits for 49 at W3 or drops the measure), plus Account Standing Instruction.Distribution Option; specs_l_shareholder_vendor.py "
    "line 413 (DP-071) and specs_n_compliance_controls.py line 389 (DP-084), Nominee Designation; data_models/keys_g6_15_16.py "
    "(line 52 Platform Program Enrollment key, line 76 Account Privilege key, lines 169-170 FKs to PARTNER_PROGRAM and "
    "MODEL_PORTFOLIO, line 185 Opening Servicing Provider, line 168 Governing Agreement FK to AGREEMENT 05 -> 39 CONTRACT, lines "
    "188, 191, 195 Initial Funding / Triggering / Final Transaction FKs to TRANSACTION 06 -> 50 MONEY MOVEMENT, unresolved until "
    "W3, plus Omnibus Parent Account and Plan Participant Account.Participant); data_models/models_f4_accounts_plans.py (line 22 "
    "Platform Program Enrollment, line 24 Account Privilege, line 114 FK Opening Servicing Provider, line 119 Governing Agreement to "
    "Distribution Agreement, lines 120-121 FKs Enrolled Partner Program and Assigned Model Portfolio, line 158 transactions to "
    "DP-006); data_models/models_f2.py line 164 and models_c8_compliance2.py line 64 (DP-007, Advisory Program Indicator); "
    "data_models/models_f1.py line 214 (Account.Governing Agreement to DP-005); content_18 lines 69, 123 and 422 ('15 Platform "
    "Program Enrollment': re-point to 15 Program Enrollment ENRL- and 46 model assignment); content_16 lines 12 and 175 and "
    "enrich_16.py line 68 (ruling 3 above); semantic_model/out/spine.yaml lines 1334, 2818, 5290, 7717 (Advisory Program "
    "Indicator) and 1354, 5310 (Nominee Designation): regenerate after WP0.",
    "Wholesale attribute names DROPPED: Account.Advisory Program Indicator (-> current Program Enrollment); Account Registration "
    "Detail.Associated Person Disclosure Indicator (-> 02 Individual); Intermediary Account Servicing.Nominee Designation (CW-915) "
    "and Omnibus Parent Account (-> Account Hierarchy Link 'Omnibus to Sub-Account'); Beneficiary Designation.Designation Evidence "
    "Reference; Account Tax Certification.Tax ID Type (-> 02 Tax Profile.TIN Type), Electronic Signature Indicator, Certification "
    "Document Reference; Account Tax Reporting Status.Tax Residence Country, Self-Certification on File Indicator, "
    "Self-Certification Received Date, Reportable Account Indicator (CW-915); Cost Basis Election.Covered Security Indicator (-> 49 "
    "client lot); Account Standing Instruction.Bank Instruction Reference (-> Linked Bank Instruction) and Distribution Option (-> "
    "Account Feature of type Dividend Reinvestment (DRIP)); Account Opening.Opening Servicing Provider (-> Account.Carrying Entity) "
    "and Opening Message Reference; Account Lifecycle Event.Message Reference; whole object Platform Program Enrollment (Enrolled "
    "Partner Program -> Program Enrollment.Enrolled Service Offering; Program Enrollment Date -> Enrollment Effective Date; Program "
    "Exit Date -> Enrollment Termination Date; Assigned Model Portfolio -> 46; Program Account Type dropped); whole object Account "
    "Privilege (five privilege indicators -> Account Feature rows of the same Feature Type values; Privilege Effective From -> "
    "Feature Effective From); Record Metadata (CD-160). MOVED within 15: Account Investment Objective to Account Investment Profile "
    "(now a Business Object keyed by Profile Account; code list now the 02 objective scale). RE-TYPED, name kept: Initial Funding "
    "Transaction, Triggering Transaction, Final Transaction (06 TXN- -> 50 MMT-); Institutional Account.Governing Agreement (05 "
    "AGR- -> 39 CTRCT-); Institutional Account.Related Mandate (type name Investment Mandate); Account Preference.Duplicate Statement "
    "Recipient (now multi); Plan Participant Account.Participant (now a reference to 16). Applies To of Account Party Role and "
    "Account Restriction changed from 'Account' to the object name.",
    "Code-list values readers may filter on: Account Type re-cut (CW-035); Account Status loses Restricted (read open Account "
    "Restrictions) and gains Escheated; Account Role Type keeps Primary Owner, Joint Owner, Custodian (UTMA), Guardian / "
    "Conservator, Authorized Signatory, Executor / Administrator, Inherited IRA Owner, Designated Beneficiary (529), Successor Owner "
    "(529) and loses Power of Attorney and Trusted Contact Person (02), Beneficiary (Beneficiary Designation), Successor Custodian "
    "(Custodial Account Detail), Plan Participant (16), Rep and Dealer of Record (Intermediary Account Servicing), Trustee (51), "
    "Interested Party (Duplicate Statement Recipient), Plan Sponsor and Plan Trustee (16 Plan Role Assignment); Account Restriction "
    "Type re-cut to kinds (Regulation T Freeze, Intraday Margin Deficit, Market Timing, Legal Process, CIP Pending, AML / Sanctions, "
    "Deceased Owner, Escheatment, Address Unknown, Financial Exploitation, Tax Certification, Plan Blackout, Client Request, Other) "
    "with Freeze, Stop Purchase, Stop Redemption and the like moved to Restriction Scope; Standing Instruction Type renamed "
    "(Automatic Investment, Systematic Withdrawal, Automatic RMD) and loses Distribution Option and Dividend Cross-Reinvestment; "
    "Business Line uses the two-letter CW-004 codes; Closure Initiator 'Shareholder' -> 'Account Owner'; Account Identifier Scheme "
    "'Sub-Accounting Position ID' -> 'Sub-Accounting Record ID'.",
    "Family renames (attribute IDs AC-FAM-nnn change at W5): AC-PPA merged into 'Participant, Institutional & Intermediary "
    "Accounts' (AC-INT); 'Account Tax Status' -> 'Tax, Cost Basis & Distributions'; 'Account Restrictions & Privileges' -> "
    "'Account Restrictions & Eligibility'; new AC-FEA and AC-PRG; AC-DMG retired.",
    "Brief file name: the brief (sections 1 and 4a) names proposals_15.py; this file is proposals_w1_15.py as assigned, matching "
    "the W1 siblings. Record the name in the brief.",
]
