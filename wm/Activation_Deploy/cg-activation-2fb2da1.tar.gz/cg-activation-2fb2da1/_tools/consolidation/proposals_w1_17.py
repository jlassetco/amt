"""W1 proposals of Data Domain 17 Instrument & Issuer Reference (wealth model; kept with the US-only and perspective pass
and the retail-tradable additions). Brief: 00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 3 (17); decisions
CW-003, CW-022, CW-037, CW-039; plan section 5.1 row 17. Declarative only: the program lead merges DECISIONS into
decisions.py, appends JURISDICTION to jurisdiction.REMOVALS and applies SHARED_CANDIDATES to shared_code_lists.py at merge
(W5 for the shared lists, CW-039). The existing proposals_17.py (expansion) is unchanged.
"""

_D = "CW-917"


def _j(obj, attr, regime, note):
    return {"domain": "17", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


# ---------------------------------------------------------------------------------------------------------------------
# Jurisdiction register entries (jurisdiction.REMOVALS format). Objects and attributes use the wholesale-v1.0 names.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = [
    # Attributes
    _j("Regulatory Instrument Classification", "UCITS Eligible Asset Indicator", "UCITS",
       "Eligibility for a UCITS fund (Directive 2007/16/EC); no UCITS range. US fund eligibility tests are Rule 2a-7 Eligible Security Indicator and the 33 rule library (1940 Act)."),
    _j("Regulatory Instrument Classification", "UCITS Eligible Asset Category", "UCITS",
       "UCITS Article 50 category; removed with the indicator."),
    _j("Regulatory Instrument Classification", "MiFID II Complex Instrument Indicator", "MiFID II",
       "MiFID appropriateness classification. US instance not added in W1 (tailoring lever): FINRA Regulatory Notices 09-31 (leveraged and inverse ETPs) and 12-03 (complex products) may call for an instrument-level complex-product flag; the model leaves complex-product handling to 01 platform policy and 48 order checks (CW-036, CW-037), with the 15 options and margin approvals."),
    _j("Regulatory Instrument Classification", "EU or UK Trading Venue Indicator", "MiFIR",
       "Drove MiFIR transaction reporting scope (ESMA and FCA FIRDS); no MiFIR reporting. US venues are Instrument Listing MICs."),
    _j("Regulatory Instrument Classification", "Solvency II CIC Code", "FinDatEx",
       "Insurer look-through code (FinDatEx TPT); no EU insurer clients. NAIC designations stay until the W4 decision on insurance-dedicated funds."),
    _j("Securitized Product Terms", "STS Securitization Indicator", "Other EU/UK",
       "EU and UK Securitisation Regulations (STS designation); no US equivalent designation."),
    # Code-list values: UCITS Eligible Asset Category (whole local list)
    *[_j("Code list: UCITS Eligible Asset Category", v, "UCITS", "Whole list removed with the attribute.")
      for v in ("Transferable Security", "Money Market Instrument", "UCITS or Other UCI Units", "Deposit",
                "Financial Derivative Instrument", "Other (10% Limit)", "Not Eligible")],
    _j("Code list: Credit Rating Agency", "Scope Ratings", "Other EU/UK",
       "EU-registered agency under the EU CRA Regulation and not an NRSRO. Limiting the list to NRSROs is a firm policy lever, not a regime requirement: a firm whose international bond funds use non-NRSRO ratings of foreign issuers restores Scope or widens Other."),
    # Sources
    _j("Sources", "ESMA Financial Instruments Reference Data System (FIRDS)", "MiFIR",
       "Was a cross-check reference on 20 attributes; they now cite ISO 20022, ISO 10962, ISO 6166 (ANNA), FIBO SEC, FINOS CDM, the exchange or OCC."),
    _j("Sources", "FCA Financial Instruments Reference Data System (UK FIRDS)", "FCA", "Removed with the EU or UK Trading Venue Indicator."),
    _j("Sources", "EMIR (Regulation (EU) No 648/2012) Article 4", "EMIR",
       "Clearing Mandate Indicator re-sourced to the CFTC clearing requirement (17 CFR Part 50) alone; the source row is retitled to the CFTC rule."),
    _j("Sources", "FinDatEx Tripartite Template (TPT) and Solvency II CIC table", "FinDatEx", "Removed with the Solvency II CIC Code."),
    _j("Sources", "Commission Directive 2007/16/EC (UCITS eligible assets) and UCITS Directive 2009/65/EC Article 50", "UCITS",
       "Removed with the UCITS eligibility attributes and list."),
    _j("Sources", "MiFID II (Directive 2014/65/EU) and MiFIR reference data", "MiFID II",
       "Removed with the MiFID II complexity and trading venue attributes."),
    _j("Sources", "EU Securitisation Regulation (Regulation (EU) 2017/2402) and the UK Securitisation Regulation", "Other EU/UK",
       "Removed with the STS Securitization Indicator."),
    _j("Sources", "EU Money Market Funds Regulation (Regulation (EU) 2017/1131)", "Other EU/UK",
       "Was the secondary reference of Money Market Fund Type; Rule 2a-7 stays the primary."),
    _j("Sources", "EU Credit Rating Agencies Regulation (Regulation (EC) No 1060/2009)", "Other EU/UK",
       "Credit Rating Agency re-sourced to SEC NRSROs only; the source row is retitled to the SEC Office of Credit Ratings."),
]

# ---------------------------------------------------------------------------------------------------------------------
# Decision of the US-only pass of 17 (decisions.DECISIONS format)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-917", "theme": "Scope", "title": "US-only pass of 17 Instrument & Issuer Reference",
     "domains": ["17", "01", "48", "49"],
     "issue": "The wholesale 17 carried EU/UK-only regulatory classifications (UCITS eligibility and category, MiFID II complexity, the EU or UK trading venue flag, the Solvency II CIC code), the STS securitization flag, EU values of the fund regime and money market fund type it cites from 01, a non-NRSRO rating agency and EU/UK sources (ESMA and FCA FIRDS, EMIR, FinDatEx TPT, UCITS, MiFID II, Securitisation, MMF and CRA Regulations). Its text described an asset manager that distributes wholesale, and it did not cover the instruments clients trade on a US retail brokerage platform (option series, brokered CDs, municipal detail, 529 portfolios) or the platform's fractional and extended-hours flags (plan section 5.1, CW-037).",
     "resolution": "1) Removed (23 JURISDICTION entries: UCITS 10, Other EU/UK 5, MiFID II 2, MiFIR 2, FinDatEx 2, FCA 1, EMIR 1): Regulatory Instrument Classification.UCITS Eligible Asset Indicator, UCITS Eligible Asset Category, MiFID II Complex Instrument Indicator, EU or UK Trading Venue Indicator, Solvency II CIC Code; Securitized Product Terms.STS Securitization Indicator; local list UCITS Eligible Asset Category (7 values); Credit Rating Agency value Scope Ratings (a policy lever); sources ESMA FIRDS, FCA FIRDS, EMIR Article 4, FinDatEx TPT and Solvency II CIC, Directive 2007/16/EC and UCITS Article 50, MiFID II and MiFIR, EU and UK Securitisation Regulations, EU MMF Regulation, EU CRA Regulation. "
                   "The EU/UK values of the shared Regulatory Regime and MMF Type lists cited on Fund Instrument Terms are removed and recorded by their steward 01 under CW-901 (17 holds no copy); the 17 example and definition already use US values. 2) Re-sourced: Clearing Mandate Indicator to the CFTC clearing requirement (17 CFR Part 50); Credit Rating Agency and Credit Ratings to SEC NRSROs only (DBRS Morningstar renamed Morningstar DBRS); Tax-Exempt Indicator to IRC section 103; the 20 attributes that cited ESMA FIRDS (FISN, CFI Code, Denomination Currency, Issue Date, Coupon Rate, Reference Rate, Reference Rate Term, Floating Rate Spread, Maturity Date, Amount Issued, Debt Seniority, Contract Multiplier, Expiry Date, Strike Price, Option Style, Settlement Method, Listing Venue MIC, Listing Trading Currency, Listing Date, Delisting Date) to ISO 20022, ISO 10962, ISO 6166 (ANNA), FIBO SEC, FINOS CDM, the exchange or OCC; list source alignment of Debt Seniority, Option Style and Settlement Method; Fund Regulatory Regime definition and example to the US regimes (1940 Act registered, sections 3(c)(1) and 3(c)(7), bank CIT); Fund Domicile example US; Money Market Fund Type to Rule 2a-7 alone. "
                   "3) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose, Scope, Core model, Design principles (principle 9: policy in 01, flag in 17, check in 48), Applies To, CDE, Notes and Suggested next steps; family and object texts of Instrument Setup, Instrument Classification, Regulatory Classification, Fund Instrument Terms, Listed Derivative Contract Terms, Private Market Instruments, Issuers & Ratings, Credit Ratings and Corporate Action Events; NAICS/NACE reads NAICS; books of record named (18 fund and institutional portfolio holdings, 49 client holdings, 28 and 49 entitlements, 48 client orders); Issuer Type note no longer says 'for distribution purposes'; Debt Seniority value Senior Non-Preferred description reworded (kept: non-US bank issuers); enrich_17 SUMMARY and the Regulatory Instrument Classification grain text. No object or attribute is renamed. "
                   "4) Added (plan section 5.1; CW-037; CW-039): Instrument.Fractional Trading Eligible Indicator, Fractional Trading Eligibility Rule (Reference (Tradable Universe Policy Rule, 01), TUP-), Extended-Hours Eligible Indicator, Extended-Hours Eligibility Rule (TUP-); Listed Derivative Contract Terms.Option Expiration Type (listing cycle: Standard Monthly, Weekly, Quarterly, End-of-Month, Other) and Adjusted Option Indicator (one instrument per OCC series; an OCC adjustment re-symbols the same instrument with a new effective-dated OSI identifier row); Debt Terms.FDIC Insured Indicator; new attribute group Municipal Security Terms (Municipal Issuer State, Municipal Security Type, AMT Subject Indicator, Bond Insurer); new attribute group Municipal Fund Security Terms (Municipal Fund Security Type, Plan Sponsoring State, Program Manager, Plan Sales Channel, Plan Portfolio Allocation Type, Target Enrollment Year; the plan is the Issuer party in 02; row rule in ROW_OWNERSHIP: Derived copies of 01 where the firm is program manager, mastered here otherwise); values Instrument Type Certificate of Deposit and Municipal Fund Security, Instrument Identifier Scheme OCC Option Symbol (OSI) and MSRB EMMA Security ID, Redemption Event Type Survivor Option; local lists Option Expiration Type, Municipal Security Type, Municipal Fund Security Type, Municipal Fund Plan Sales Channel, Municipal Fund Portfolio Allocation Type; sources OCC symbology, FDIC 12 CFR Part 330, MSRB Rules D-12 and G-45 and EMMA, IRC sections 103, 529 and 57, FINRA Rule 2265; two relationships (Tradable Universe Policy Rule [01], Client Holding [49]). No new prefix. "
                   "5) Kept on purpose (CW-022 investment-universe principle): foreign instruments, listings, issuers and corporate actions, SEDOL / Valoren / WKN schemes, 30E/360, Senior Non-Preferred, the CMET court meeting event, Option Style European, NAIC designations (listed for W4). Own Fund Share Class instruments exist for any own share class held in a client account (49) or an own portfolio (18). Bare 'holding' text about private assets reads 'private equity interest' or names the book of record. Counts: 23 to 25 objects, 268 to 279 attributes, 85 to 90 CDEs (32%), 48 to 52 code lists, 31 to 29 sources, 31 to 33 relationships.",
     "rationale": "CW-003 and CW-022: the wealth model is regulated and distributes in the US only, but its funds hold a global universe, so only EU/UK regime content leaves. Plan section 5.1 row 17 and CW-037 put the retail-tradable instrument facts and the platform flags in the security master, with policy in 01 and checks in 48. Names are kept so that DP-097, DP-098, DP-099 and the other readers of 17 keep resolving; the six removed attributes are read by DP-097, DP-125, the SM-00 shared dimensions and a models_e8c note, all listed in NOTES. Lever: a firm without options, municipal or 529 business drops the corresponding attributes; a UK extension restores the removed rows from wholesale-v1.0 through the jurisdiction register.",
     "action": "W1", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# Prefixes: none needed. The new term groups are attribute groups of Instrument (INS-); the flags reference 01 TUP-.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# Shared list proposals (17 is steward of Instrument Type)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Instrument Type", ["17", "18", "25", "26", "31", "33", "48", "49"],
     "Steward 17. Add CERTIFICATE_OF_DEPOSIT 'Certificate of Deposit' (brokered CD of an FDIC-insured bank) and MUNICIPAL_FUND_SECURITY "
     "'Municipal Fund Security' (529 or ABLE portfolio, MSRB Rule D-12), as named in CW-039; update the descriptions of Money Market "
     "Instrument (brokered CDs move to Certificate of Deposit), Own Fund Share Class (held by own portfolios or by clients) and Listed "
     "Option (one instrument per OCC series). 48 and 49 become members at W3. Candidate rename at W5: 'Private Equity Holding' to "
     "'Private Equity Interest' (bare 'Holding', review checklist 1); not renamed now because the shared list carries the value."),
    ("Instrument Identifier Scheme", ["01", "11", "14", "17", "48", "49"],
     "Adds OCC Option Symbol (OSI) and MSRB EMMA Security ID to the 17 list; the existing proposal in proposals_17.py stands."),
    ("Regulatory Regime", ["01", "17"],
     "US re-cut of CW-039 (steward 01): keep a value for foreign regulated funds held by the international funds (for example "
     "'Non-US Regulated Fund' or 'Other'), since Cayman Regulated Mutual Fund is the only non-US value left once the EU/UK values go."),
    ("Vehicle Type / MMF Type", ["01", "17"],
     "For the steward 01 at W5: the Vehicle Type value Open-Ended Fund still reads 'Mutual fund / UCITS / OEIC' (reword to 'Mutual fund'), and the MMF Type list source cites the EU MMFR beside Rule 2a-7 (Rule 2a-7 only)."),
    ("Option Expiration Type", ["17", "48"],
     "Local to 17 now; 48 option order checks (W3) may need it."),
]

# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "W1 (wealth), CW-917, after the review fix pass. Validation: taxonomy_builder.py content_17_instrument_and_issuer_reference OK (9 families, 25 objects, 279 attributes, 90 CDEs, 32 references, 16 derived, 0 unresolved, 52 code lists); check_enrichment.py 17 OK.",
    "Readers of removed attributes (not edited; for the program lead and the product and model owners): data_products/specs_e1_foundations.py DP-097 metric 'Regulatory Classification Coverage %' (lines 82-87) and its 17 input list (lines 132-137) read UCITS Eligible Asset Indicator, UCITS Eligible Asset Category, MiFID II Complex Instrument Indicator, EU or UK Trading Venue Indicator and Solvency II CIC Code, and line 165 reads STS Securitization Indicator; data_products/specs_e2_research_trading.py DP-125 (lines 1218-1278, MiFIR transaction reporting) reads EU or UK Trading Venue Indicator and retires with MiFIR reporting in 25; semantic_model/models/sm_00_shared_dimensions.py lines 547-554 map ucits_eligible, ucits_eligible_category, mifid_complex and solvency_ii_cic; data_models/models_e8c_research_trading.py line 831 cites the trading venue flag in a note.",
    "Proposal for the list owner 01 (not recorded in 17's JURISDICTION, which holds no copy): the shared Regulatory Regime values UCITS, UK UCITS, EU AIF, ELTIF, EU MMF, UK NURS, UK QIS, Lux SIF, Lux RAIF, Irish QIAIF and the MMF Type values Public Debt CNAV, LVNAV, Short-Term VNAV, Standard VNAV are cited by 17 Fund Instrument Terms and leave at W5 under CW-901 / CW-039.",
    "Text readers of the removed attributes (not edited): data_products/specs_e1_foundations.py line 19 (DP-097 description: UCITS ... Solvency II CIC) and line 27 (DP-097 question: UCITS eligible ... MiFID II complex ... Solvency II CIC); data_models/models_e8_foundations.py line 59 (Regulatory Instrument Classification entity note: UCITS ... Solvency II CIC). Generated outputs refresh on rebuild.",
    "Readers can add the new attributes by name: 48 (fractional and extended-hours checks, option series, CDs, 529 orders under MSRB Rules G-45 and G-8), 49 (client holdings of options, CDs, municipal and 529 positions; FDIC coverage per depositor) and 45 (529 in-state tax question).",
    "References to retiring domains left as they are (W4): Private Market Instruments family text 'Deal economics and investment-level facts (close date, holding vehicle) are 30'; Overview Scope 'deal economics and investment-level facts such as close dates and holding vehicles (30)'; Fund Interest Terms and Private Asset Terms remain (instruments, CW-038). NAIC Designation Category and NAIC SVO Filing Status and their lists and source are an insurance-dedicated residue, kept for the W4 retirement decision. Fund Manager or General Partner cites ILPA; the Third-Party Fund Manager / General Partner role note in proposals_17.py names 30.",
    "Other domains' content seen: 02 should hold the issuing bank's FDIC certificate number as a US Regulatory Identifier scheme if 49 needs it for FDIC aggregation; 01 TUP- Tradable Universe Policy Rule must exist with that name for the two references to resolve by concept (they resolve now by the registered TUP- prefix).",
    "Remaining hits of the step 1 grep, justified: 'UK scheme of arrangement' on the Court Meeting (CMET) event value (foreign issuer corporate action, kept); '30E/360 Eurobond basis' (foreign bond convention, kept); 'EU/UK' in the Overview Notes (states the removal); 'insurance' only in FDIC deposit insurance, the FDIC source and the AM Best agency description; 'Private Equity Holding' is a shared Instrument Type value (see SHARED_CANDIDATES).",
    "Unverified: OCC symbology page and expiration-cycle names; MSRB Rule G-45 as the source of program manager and sales channel; MSRB EMMA identifier format (EMMA may key everything by CUSIP, in which case the scheme value goes); eCFR paths of 12 CFR Part 330 and 17 CFR Part 50 follow the standard pattern. All are marked confirm in Source_Notes.",
]
