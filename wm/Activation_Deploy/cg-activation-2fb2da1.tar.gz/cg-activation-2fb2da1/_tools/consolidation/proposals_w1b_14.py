"""W1b proposals of Data Domain 14 Third-Party Data & Licensing (wealth model; kept with the US-only and perspective pass
and the plan section 5.1 additions: real-time quote entitlements, account aggregation data, planning data). Brief:
00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (row 14); decisions CW-003, CW-022, CW-039 (DORA Substitutability
retires). Declarative only: the program lead merges DECISIONS into decisions.py, appends JURISDICTION to
jurisdiction.REMOVALS and applies SHARED_RECUTS to shared_code_lists.py at merge (W5 for the shared lists, CW-039). The
existing proposals_14.py (expansion), if any, is unchanged.
"""

_D = "CW-914"


def _j(obj, attr, regime, note):
    return {"domain": "14", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


_BMR = "Code list: BMR Benchmark Category"
_BRS = "Code list: BMR Register Status"

JURISDICTION = [
    # Object
    _j("ICT Third-Party Register Entry", "", "DORA",
       "Whole object (and its object group ICT Third-Party Register & Resilience): the DORA register of information for EU financial entities "
       "(DORA In-Scope Indicator, Reporting Financial Entity, Contractual Arrangement Reference, ICT Service Type, Supports Critical or Important "
       "Function, Supported Functions, Data Storage Locations, Material Subcontractors). No US register; data-vendor risk stays on Vendor Risk "
       "Assessment and the enterprise third-party program is 40 (FINRA Regulatory Notice 21-29, Regulation S-P service-provider oversight)."),
    _j("ICT Third-Party Register Entry", "UK Important Business Service Mapping", "FCA",
       "UK operational resilience (FCA SYSC 15A). The brief names it on Vendor Risk Assessment; it sat on this object and leaves with it."),
    _j("ICT Third-Party Register Entry", "Impact Tolerance Dependency Indicator", "FCA", "UK impact tolerance (FCA SYSC 15A); leaves with the object."),
    # Index Use
    _j("Index Use", "BMR Use Indicator", "BMR", "EU BMR 'use of a benchmark'; no US equivalent. Index use stays coded by Index Use Type."),
    _j("Index Use", "Benchmark Category (BMR)", "BMR", "EU BMR category after Regulation (EU) 2025/914."),
    _j("Index Use", "Administrator Register Status (EU)", "BMR", "ESMA benchmarks register status."),
    _j("Index Use", "Administrator Register Status (UK)", "BMR", "FCA benchmarks register status (UK BMR)."),
    _j("Index Use", "Register Status Check Date", "BMR", "Dated the EU/UK register checks only; leaves with them."),
    _j("Index Use", "Benchmark Contingency Plan Reference", "BMR", "EU BMR Article 28(2) written plan; no US requirement for the firm's funds."),
    # Whole local lists
    *[_j(_BMR, v, "BMR", "Whole list removed with Benchmark Category (BMR).")
      for v in ("Critical", "Significant", "Non-Significant", "EU Climate Transition Benchmark", "EU Paris-Aligned Benchmark",
                "Commodity Benchmark (in scope)", "Not a Benchmark")],
    *[_j(_BRS, v, "BMR", "Whole list removed with the Administrator Register Status attributes.")
      for v in ("Authorized", "Registered", "Recognized (Third Country)", "Endorsed (Third Country)", "Equivalence",
                "Transitional / Pending Application", "Not on Register", "Out of BMR Scope")],
    *[_j("Code list: Substitutability", v, "DORA",
         "Local list (member of the shared DORA Substitutability, which retires, CW-039) removed; Substitutability is re-sourced to a firm-defined scale (code list 'Firm-defined').")
      for v in ("Not Substitutable", "Highly Complex", "Medium Complexity", "Easily Substitutable")],
    # Other values
    _j("Code list: Identifier Scheme", "FCA FRN / IRN", "FCA", "FCA firm and individual reference numbers; FINRA CRD and SEC File Number stay."),
    _j("Code list: Output Type", "Prospectus / KID", "PRIIPs", "Relabeled 'Prospectus / Shareholder Report' (US prospectus, summary prospectus, tailored shareholder report)."),
    # Sources
    _j("Sources", "EU Benchmarks Regulation (EU) 2016/1011, as amended by Regulation (EU) 2025/914", "BMR", "Removed with the BMR attributes; Index Provider and Index Use Type read Internal with the MSCI index license."),
    _j("Sources", "ESMA benchmarks register and BMR public statements", "BMR", "Removed with Administrator Register Status (EU)."),
    _j("Sources", "UK Benchmarks Regulation and FCA benchmarks register", "BMR", "Removed with Administrator Register Status (UK)."),
    _j("Sources", "FTSE Russell EU Benchmark Regulation FAQs (July 2026)", "BMR", "Index-provider BMR status source; removed with the register attributes."),
    _j("Sources", "Digital Operational Resilience Act (EU) 2022/2554", "DORA",
       "Exit Strategy Documented Indicator, Termination for Convenience Indicator and Risk Domains Assessed re-sourced to the US interagency third-party risk management guidance."),
    _j("Sources", "Commission Implementing Regulation (EU) 2024/2956 - register of information templates", "DORA",
       "Removed with the ICT Third-Party Register Entry; Substitutability and Governing Law no longer cite it."),
    _j("Sources", "FCA PS21/3 Building operational resilience (SYSC 15A)", "FCA", "Removed with the UK operational resilience attributes."),
    _j("Sources", "GDPR (EU) 2016/679 and UK GDPR", "GDPR / UK GDPR",
       "Personal-data fields re-sourced to SEC Regulation S-P (service-provider oversight) and the CCPA as amended by the CPRA (new source rows)."),
]

DECISIONS = [
    {"id": "CW-914", "theme": "Scope", "title": "US-only pass of 14 Third-Party Data & Licensing", "domains": ["14", "40", "02", "45"],
     "issue": "The wholesale 14 carried the DORA register of information for EU entities (ICT Third-Party Register Entry, with UK important "
              "business service and impact tolerance fields), EU and UK Benchmarks Regulation fields on Index Use with two BMR lists, a DORA "
              "substitutability scale (member of the shared DORA Substitutability), an FCA identifier scheme, a KID output type and GDPR, DORA, "
              "BMR and FCA sources. Its text described an asset manager that distributes wholesale, with intermediary data (Discovery Data, "
              "Broadridge) as the leading examples and '02 Client & Customer' and the wholesale 02 Financial Professional Profile as targets, "
              "and it did not cover the data a direct wealth manager licenses for clients: real-time quotes by subscriber, account aggregation "
              "and planning data (plan section 5.1).",
     "resolution": "1) Removed (38 JURISDICTION entries: BMR 25, DORA 7, FCA 4, GDPR / UK GDPR 1, PRIIPs 1): object ICT Third-Party Register "
                   "Entry with its object group (ten attributes, among them UK Important Business Service Mapping and Impact Tolerance "
                   "Dependency Indicator, which the brief places on Vendor Risk Assessment), its relationship and 14's use of the shared DORA ICT "
                   "Service Type; Index Use.BMR Use Indicator, Benchmark Category (BMR), Administrator Register Status (EU), Administrator Register "
                   "Status (UK), Register Status Check Date, Benchmark Contingency Plan Reference; local lists BMR Benchmark Category (7 values), "
                   "BMR Register Status (8) and Substitutability (4, the DORA scale); values Identifier Scheme FCA FRN / IRN and Output Type "
                   "Prospectus / KID (relabeled Prospectus / Shareholder Report); sources EU BMR, ESMA register, UK BMR and FCA register, FTSE "
                   "Russell EU BMR FAQs, DORA, CIR (EU) 2024/2956, FCA PS21/3, GDPR. "
                   "2) Re-sourced: Vendor Risk Assessment.Substitutability to a firm-defined scale (14 leaves the retiring DORA Substitutability, "
                   "CW-039); Exit Strategy Documented Indicator, Termination for Convenience Indicator, Risk Domains Assessed and the Vendor Risk "
                   "Domain list to the US interagency third-party risk management guidance; Governing Law to Internal; Personal Data Processed "
                   "Indicator, Contains Personal Data Indicator and Personal Data Use Restrictions to SEC Regulation S-P (primary: client account data is GLBA "
                   "nonpublic personal information) with the CCPA / CPRA for non-GLBA data (new source rows); Index Provider, Index Use Type and its list to Internal with the MSCI index license. "
                   "3) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose, Scope, Core model, Applies To, CDE, Primary "
                   "/ Secondary Reference and Suggested next steps 1, 3 and 6; family texts of Vendor Risk & Resilience, Index & Benchmark Licensing "
                   "and Entitlements & Access; dataset examples re-cut from intermediary data to account aggregation (Dataset Name, Description, "
                   "Subject Area, Marketplace Listing, Consuming Business Domain, Target Concept), Licensed Business Units example, Vendor Type "
                   "descriptions of the intermediary datasets; SUMMARY and ROW_OWNERSHIP in enrich_14.py; Source_Notes header, sources, design "
                   "notes, unverified list, SME questions 2 and 4, next steps 2 and 4, overlap 4 and section 7. "
                   "4) Re-pointed: '02 Client & Customer' reads '02 Client & Household' (Scope, REL, Consuming Business Domain, SUMMARY) and '01 "
                   "Investment Product' reads '01 Investment Product & Service Offering' in the Consuming Business Domain list; Target Concept no "
                   "longer names the wholesale 02 Financial Professional Profile (05 role profile from W4, CW-023); the Entitlement holder REL reads "
                   "Employee (20 Human Capital: EMP-) instead of the stale '03 Sales: EMP-'. "
                   "5) Added (plan section 5.1): Entitlement.Entitled Client (Reference (Party), PII); new object Market Data Subscriber (object group "
                   "Market Data Subscribers, grain client subscriber x status effective date: Subscriber Client, Market Data Subscriber Status (CDE; "
                   "new list Professional / Non-Professional, aligned to the CTA / OPRA non-professional definition), Subscriber Status Attested "
                   "Date, Subscriber Status Effective From), so that the status is held once per client, not on each entitlement (program-lead "
                   "ruling, review fix pass); Entitlement grain and group text read user, client subscriber or application; values Entitlement Holder Type Client Subscriber, Entitlement Type Client Real-Time Quote "
                   "Display, Declaration Type Exchange Subscriber Report, Vendor Type Exchange & Quote Provider, Account Aggregation Provider, "
                   "Planning Data Provider, Dataset Subject Area Real-Time Market Data, Account Aggregation Data, Financial Planning Data, Consuming "
                   "Business Domain 45 Financial Planning & Advice; sources SEC Regulation S-P, CCPA / CPRA, CTA and UTP plans with OPRA. "
                   "6) IDs: the removed object was the last of Vendor Risk & Resilience (no other code changes there); attribute IDs renumber in "
                   "Index & Benchmark Licensing after Index Use Type and in Entitlements & Access after Entitled User (Market Data Subscriber is "
                   "appended as the family's last object). Counts: 30 objects (one removed, one added), 243 to 232 attributes, 73 to 70 CDEs "
                   "(30.2%), 63 to 60 code lists, 19 to 14 sources, 33 relationships (one removed, one added), 25 references, 13 to 5 derived "
                   "copies (builder count; check_enrichment 5).",
     "rationale": "CW-003 and CW-022: the wealth model is regulated in the US only, so the DORA register, UK operational resilience, EU and UK "
                  "benchmark-register status and GDPR leave; foreign indices and their licenses stay. Generic vendor risk keeps its US instance "
                  "(interagency TPRM guidance, Regulation S-P service-provider oversight, state privacy law). Plan section 5.1 names the data a "
                  "direct wealth manager licenses for its clients, so client subscribers of real-time quotes and their professional or "
                  "non-professional status, account aggregation and planning data are added. A UK extension restores the removed rows from "
                  "wholesale-v1.0.",
     "action": "W1b", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
]

SHARED_RECUTS = [
    ("DORA Substitutability", "40",
     "Retires under CW-039. 14 is no longer a member: its local list Substitutability is removed and the attribute cites 'Firm-defined'. "
     "Drop ('14', 'Substitutability') from members and the 14 value map (shared_code_lists.py lines 2651 and 2654)."),
    ("DORA ICT Service Type", "40",
     "Retires under CW-039. 14 no longer cites it (the ICT Third-Party Register Entry left); drop '14' from direct_users (line 1769)."),
    ("Business Domain", "09",
     "14 is a member through Consuming Business Domain, whose local values now read '01 Investment Product & Service Offering', '02 Client "
     "& Household' and add '45 Financial Planning & Advice'. Relabel INVESTMENT_PRODUCT and CLIENT_CUSTOMER to the domains.py names, add "
     "the wealth Data Domains 45 to 50 (registered at W0, CW-002), and extend the 14 value map (line 71) with the three labels. Until "
     "then the 14 workbook shows the shared labels."),
    ("Third-Party Risk Domain", "37",
     "14 is a member through Vendor Risk Domain; values unchanged. The list's 'ESG / Modern Slavery' value names a UK statute for 37 to "
     "judge in its own pass (CW-937)."),
]

SHARED_CANDIDATES = [
    ("Market Data Subscriber Status", ["14", "48", "49"],
     "Local to 14 (Professional, Non-Professional), held once per client on Market Data Subscriber. 48 (client order and quote display) and "
     "49 may need the same status if the subscriber agreement is held on the client account; candidate for a shared list at W3."),
]

NOTES = [
    "W1b (wealth), CW-914. Validation: taxonomy_builder.py content_14_third_party_data_and_licensing OK (10 families, 30 objects, 232 "
    "attributes, 70 CDEs, 25 references, 5 derived, 0 unresolved, 60 code lists) after the review fix pass; before: 30 objects, 243 attributes, 73 CDEs, 25 "
    "references, 13 derived, 63 code lists, 19 sources; after: 14 sources. check_enrichment.py 14 OK.",
    "READERS of the removed object and attributes (not edited; for the program lead's lineage pass): ICT Third-Party Register Entry: "
    "data_products/specs_e4_risk_audit_third_party.py lines 961-963 (input list), 983 and 987 (quality rule and note); "
    "data_products/specs_l_shareholder_vendor.py lines 492-495 (Critical Dependency Flag reads Supports Critical or Important Function), "
    "546-549 (input list including UK Important Business Service Mapping and Impact Tolerance Dependency Indicator) and 586 (quality rule); "
    "data_models/keys_g5_11_12_13_14.py lines 198 and 454-455 (keys and reference roles); data_models/models_c10_shareholder_ops.py "
    "lines 382-389 and 410-415 (dimension and relationships); data_models/models_e8c_risk_audit_third_party.py lines 527-528 and 587 "
    "(Fact Data Vendor Register Entry). Index Use BMR attributes: data_products/specs_i_product_data.py lines 370-373 (metric BMR Register "
    "Exception), 382-385 (input list) and 424 (quality rule on Register Status Check Date). No semantic model reads them. Added in the review fix pass: data_products/specs_e4_risk_audit_third_party.py lines 858-866 (DP-220 "
    "definition names the 14 ICT Third-Party Register Entry as its data-vendor slice); data_models/models_e8c_risk_audit_third_party.py "
    "lines 588-589 (relationship on Contractual Arrangement Reference) and 612 (model-gap note); data_models/models_c10_shareholder_ops.py "
    "line 443 (note on Contractual Arrangement Reference); data_products/specs_l_shareholder_vendor.py lines 497-499 (metric Exit Readiness "
    "Gap tests the re-sourced Vendor Risk Assessment.Substitutability for the value 'low'; the scale is now firm-defined, so the test value "
    "must be restated); data_products/_catalog.txt lines 1368-1369 and 1401 (generated). No reader of the removed values FCA FRN / IRN, "
    "Prospectus / KID or the Substitutability list values beyond that metric. Entitlement.Market Data Subscriber Status moved to the new "
    "Market Data Subscriber object before any reader existed.",
    "For W3 (48, 49): where the client's market data subscriber agreement acceptance is held (02 Consent Record or 15 account level) and whether 48 quote display reads Market Data Subscriber; see SHARED_CANDIDATES.",
    "Lists 01 should judge in its own pass: 01 Benchmark carries a static BMR Register Status flag (Source_Notes overlap 4).",
    "References to retiring or later-replaced domains left as they are: 05 Distribution Agreements & Partners (Scope, Suggested next step "
    "5, REL 'Data License Agreement is distinct from Distribution Agreement (05: AGR-)', Permitted Use Category 'Redistribution to "
    "Distribution Partners', Redistribution Recipient Type 'Distribution Partners'); 03 Sales (consultant database submissions DBS-); 06 "
    "(FEED-, Declared AUM derived copy, Technical Feed); 07, 08 (personnel licenses LIC-) and 10 (allocation methods ALM-, cost hand-off); "
    "11 and 12 in Scope. Wholesale use cases kept for the 05 and 03 replacements (W4): Use Case values Advisor Targeting & Segmentation, "
    "CRM Enrichment, Sales & AUM Attribution, Territory Design & Potential; Vendor Type Intent & Marketing Data Provider and Consultant / "
    "Manager Database; Covered Entity Type and Data Granularity advisor values.",
    "Remaining hits of the step 1 grep, justified: 'distributors' and 'distribution partners' only in the 05 references above; the "
    "Substitutability source note 'replaces the DORA values' was removed with the local list; no EU/UK hit remains in the module.",
    "37 should judge the Third-Party Risk Domain value 'ESG / Modern Slavery' (UK statute name) in CW-937; 14 cites it unchanged.",
    "Unverified: CTA, UTP and OPRA plan URLs and the paraphrased professional / non-professional subscriber definitions; "
    "eCFR path of 17 CFR Part 248 Subpart A (marked confirm in Source_Notes).",
    "Seen in other domains (not edited): 40 ICT Register Arrangement Header, ICT Register of Information Entry and Supply Chain "
    "Subcontractor leave under CW-940 (the derived copies here pointed at them); 37 Critical or Important Function leaves under CW-937.",
]
