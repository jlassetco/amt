"""W1b proposals of Data Domain 18 Portfolio & Investment Book of Record (wealth model; kept with the US-only and
perspective pass). Brief: 00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (18); decisions CW-003, CW-004,
CW-007, CW-009, CW-021, CW-022, CW-039; plan section 5.1 row 18. Declarative only: the program lead merges DECISIONS into
decisions.py, appends JURISDICTION to jurisdiction.REMOVALS and applies SHARED_RECUTS and SHARED_CANDIDATES to
shared_code_lists.py at merge (W5 for the shared lists, CW-039). The existing proposals_18.py (expansion) is unchanged.
"""

_D = "CW-918"


def _j(obj, attr, regime, note):
    return {"domain": "18", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


# ---------------------------------------------------------------------------------------------------------------------
# Jurisdiction register entries (jurisdiction.REMOVALS format). Objects and attributes use the wholesale-v1.0 names.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = [
    # Attributes
    _j("Lot Relief", "UK Matching Rule Applied", "Other EU/UK",
       "UK share identification rules (HMRC CG51500, TCGA 1992 s105-106A); no UK books. US lot identification is Relief Method Applied (Treas. Reg. 1.1012-1)."),
    _j("Tax Lot", "Pooled Lot Indicator", "Other EU/UK",
       "UK Section 104 pooled holding (TCGA 1992 s104); US books keep identified lots, and average cost is a Lot Relief Method value."),
    _j("Portfolio Accounting Basis", "Lot Rule Jurisdiction", "Other EU/UK",
       "Generic attribute removed for the US model, not an EU/UK-only attribute: it named the country whose tax rules govern lot identification, and under US-only scope its value set has one value (jurisdiction CHECKLIST: a jurisdiction attribute stays only if the US value set needs it). Its only non-US use was the UK share identification rules. Every 18 book follows US lot identification (IRS Publication 550, Treas. Reg. 1.1012-1); tax-exempt books are Holding Period Term 'Not Applicable'. Filed under 'Other EU/UK' because REGIMES has no generic value."),
    _j("Transaction Cost & Charge", "Cost Categories Applied", "MiFID II",
       "MiFID II costs and charges categories (Delegated Regulation 2017/565 Art 50, Annex II); the explicit cost amounts stay, re-sourced to the FIX Protocol."),
    # Code lists
    *[_j("Code list: UK Matching Rule", v, "Other EU/UK", "Whole list removed with UK Matching Rule Applied.")
      for v in ("Same Day", "Next 30 Days", "Section 104 Holding")],
    _j("Code list: Lot Relief Method", "UK Share Identification Rules (TCGA 1992 s105-106A)", "Other EU/UK",
       "18 is steward of the shared Lot Relief Method; the shared value UK_SHARE_IDENTIFICATION_RULES_TCGA_1992_S105_106A leaves at W5 (CW-039; SHARED_RECUTS)."),
    *[_j("Code list: Transaction Cost Category", v, "MiFID II",
         "Whole list removed with Cost Categories Applied, its only reader; the expansion proposal to share it (proposals_18.py) lapses.")
      for v in ("Commission", "Research Payment", "Exchange and Clearing Fee", "Stamp Duty / Transaction Tax",
                "Financial Transaction Tax", "Custody Transaction Charge", "Other Charge")],
    # Sources
    _j("Sources", "HMRC Capital Gains Manual CG51500 onward: share identification rules (TCGA 1992 s104 pooling, s105 same-day and s106A 30-day rules; CG51620 for corporation tax)",
       "Other EU/UK", "Removed with the UK lot rules; Default Lot Relief Method, Relief Method Applied and Original Cost Local keep IRS Publication 550 and Treas. Reg. 1.1012-1."),
    _j("Sources", "MiFID II costs and charges: Commission Delegated Regulation (EU) 2017/565 Article 50 and Annex II", "MiFID II",
       "Commission Amount, Exchange and Clearing Fee Amount, Transaction Tax Amount and Total Explicit Cost re-sourced to the FIX Protocol and Internal."),
    _j("Sources", "MiFID II research payments: Commission Delegated Directive (EU) 2017/593 Article 13", "MiFID II",
       "Research Payment Component re-sourced to Exchange Act Section 28(e) and SEC release 34-54165 (soft dollars)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# Decision of the US-only pass of 18 (decisions.DECISIONS format)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-918", "theme": "Scope", "title": "US-only pass of 18 Portfolio & Investment Book of Record",
     "domains": ["18", "06", "15", "46", "49"],
     "issue": "The wholesale 18 carried the UK share identification rules (the UK Matching Rule Applied attribute and list, the Pooled Lot Indicator, the Lot Rule Jurisdiction switch and the Lot Relief Method value UK Share Identification Rules, sourced to HMRC CG51500), the MiFID II costs and charges categories (Cost Categories Applied and the Transaction Cost Category list) and MiFID II sources on the cost amounts and the research payment component. Its text described an asset manager running every portfolio in house for a wholesale range including SMAs, private markets and insurance-dedicated funds, with 'SMA account' books that in the wealth model would collide with retail managed accounts and with the client book of record in 49 (CW-007, CW-009); its Business Line list held the six wholesale lines.",
     "resolution": "1) Removed (18 JURISDICTION entries: MiFID II 10, Other EU/UK 8): Lot Relief.UK Matching Rule Applied; Tax Lot.Pooled Lot Indicator; Portfolio Accounting Basis.Lot Rule Jurisdiction (a generic attribute removed for the US model because its value set became single-valued, not an EU/UK-only attribute; filed under Other EU/UK); Transaction Cost & Charge.Cost Categories Applied; local lists UK Matching Rule (3 values) and Transaction Cost Category (7 values); Lot Relief Method value UK Share Identification Rules (TCGA 1992 s105-106A) (18 is the shared-list steward); sources HMRC CG51500, Delegated Regulation (EU) 2017/565 Art 50 and Delegated Directive (EU) 2017/593 Art 13. No object removed. "
                   "2) Re-sourced: Research Payment Component to Exchange Act Section 28(e) and SEC release 34-54165 (soft dollars; new source row, as cited by 23); Commission Amount, Exchange and Clearing Fee Amount (definition names the SEC Section 31 fee) and Transaction Tax Amount to the FIX Protocol, Total Explicit Cost to Internal / FIX; the HMRC cross-references on Default Lot Relief Method, Relief Method Applied and Original Cost Local replaced by Treas. Reg. 1.1012-1 or IRS Publication 550; Lot Relief Method list source IRS Publication 550 / Treas. Reg. 1.1012-1. "
                   "3) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose, Scope, Core model, Design principle 2, Notes (Regulation S-P, GLBA and state law in place of GDPR) and Suggested next steps; family texts of Portfolio Master, Business-Line Detail, Holdings, Tax Lots and Portfolio Activity; enrich_18 SUMMARY and the SMA Portfolio Detail grain. "
                   "4) Re-points and books of record (CW-007, CW-009, CW-021): the overview states the three books of record (Portfolio Holding 18, Client Holding 49, Fund Shareholder Position 06) and the 18 / 49 boundary: retail managed accounts are 15 accounts managed in 46 that hold Client Holdings in 49, never 18 portfolios; the Manages Account link, the Managed Account reference and SMA Portfolio Detail serve only the firm's own institutional separate accounts (IA line) and the sponsor program accounts it manages inside third-party wrap or model programs (intermediary channel, IC line; program lead ruling at the W1b fix pass); 'SMA account' reads 'institutional separate account' or 'sponsor program account (intermediary channel)' in the definitions, notes and group texts, code values (Sponsor Account Number, Sponsor Notification, Manages Account and others) and relationships; the Business Line note names IC for sponsor program books; Managing Entity covers oversight of external sub-advisers (52); Followed Model Portfolio reconciles to a 15 Program Enrollment only where the account has one; client tax lots and cost basis are named as 49 and the election as 15 Cost Basis Election; 'insurance-dedicated fund' leaves the pooled-fund texts (CW-004); 02 is named Client & Household (party core). Reference (Party) and Reference (Account) are unchanged and resolve. "
                   "5) Business Line (CW-004): the local copy of the shared list holds the eight two-letter codes DB, DA, HA, PF, WR, IA, IC, TR (as 02 and 15); the six wholesale values leave; example PF; the note states PF for fund books, IA for institutional books and TR for an optional common trust fund book. "
                   "6) Additions: none (brief: boundary sentence only). Object and attribute names unchanged; four attributes removed in the families Portfolio Master, Tax Lots and Portfolio Activity, so attribute positions renumber there. "
                   "7) Kept on purpose (CW-022): local-currency amounts, stamp duty and financial transaction tax on foreign trades, the WMR fixing as an FX rate type example. Counts: 24 to 24 objects, 220 to 216 attributes, 68 to 68 CDEs (31.5%), 31 to 29 code lists (24 to 22 local), 20 to 18 sources, 42 relationships, 37 references, 15 derived.",
     "rationale": "CW-003 and CW-022: the firm is regulated and distributes in the US only, so the UK capital gains matching rules and the MiFID II cost reporting categories have no book to apply to, while the foreign instruments and transaction taxes its funds incur stay. CW-007 and CW-009 make 18 the book of the firm's own funds and institutional portfolios only; saying so in the overview and the account-facing definitions stops a retail managed account from being modeled twice (18 and 49). Names are kept so that DP-140, DP-141, DP-142 and SM-08 keep resolving; the four removed attributes are read by DP-140, DP-141, DP-142 and SM-08 (NOTES). Lever: a UK extension restores the removed rows from wholesale-v1.0 through the jurisdiction register.",
     "action": "W1b", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# Shared list re-cuts (18 is steward of Lot Relief Method and Holding View and a member of Business Line)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_RECUTS = [
    ("Lot Relief Method", "18",
     "Delete UK_SHARE_IDENTIFICATION_RULES_TCGA_1992_S105_106A and its value-map entry; source becomes 'IRS Publication 550 / Treas. Reg. 1.1012-1' (CW-039)."),
    ("Business Line", "09",
     "Member 18 now holds the CW-004 codes: replace the 18 value map (Mutual Fund ... Insurance-Dedicated Fund) by the identity map on DB, DA, HA, PF, WR, IA, IC, TR, as for 02 and 15; drop the comment '18 and 21 still carry the wholesale six' for 18."),
]

SHARED_CANDIDATES = [
    ("Transaction Cost Category", None, ["01", "25", "27"],
     "Withdrawn: the expansion candidate in proposals_18.py (share Transaction Cost Category with 01, 25, 27) lapses because 18 no longer holds the list (MiFID II costs and charges)."),
]

# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "W1b (wealth), CW-918. Validation: taxonomy_builder.py content_18_portfolio_and_investment_book_of_record OK (7 families, 24 objects (8 attribute groups, 0 without grain), 216 attributes, 68 CDEs, 37 references, 15 derived, 0 unresolved, 29 code lists); before: 220 attributes, 68 CDEs, 31 code lists. check_enrichment.py 18 OK.",
    "READERS of removed attributes (not edited; for the program lead and the product and model owners): "
    "data_products/specs_e1_book_of_record.py line 71 (DP-140 inputs, Portfolio Accounting Basis: Lot Rule Jurisdiction); line 186 (DP-141 inputs, Transaction Cost & Charge: Cost Categories Applied); line 303 (DP-142 inputs, Tax Lot: Pooled Lot Indicator); line 304 (DP-142 inputs, Lot Relief: UK Matching Rule Applied); "
    "semantic_model/models/sm_08_investment_book_performance.py line 219 (tax_lot dimension pooled_lot = Pooled Lot Indicator) and line 226 (lot_relief dimension uk_matching_rule = UK Matching Rule Applied). "
    "No data model (data_models/) names them. Shared lists: consolidation/shared_code_lists.py lines 2183-2197 (Lot Relief Method source and UK value; SHARED_RECUTS) and lines 1625-1629 (18 Business Line value map). Generated outputs refresh on rebuild.",
    "Business Line readers by value: DP-140 and the e2 investment operations products read 18 Portfolio.Business Line (specs_e1_book_of_record.py lines 30, 61, 193, 782; specs_e2_invops_a.py lines 440, 526, 740, 916, 1223, 1313) by attribute name only; no product filters on a wholesale value. 27 Fund Book.Business Line is a Derived copy of this attribute and is re-cut in CW-927.",
    "References to later-stage domains left as they are: Sponsor Program Agreement (Reference (Agreement), 05, replaced at W4) and the relationship 'SMA Portfolio Detail is run under Distribution Agreement (05, AGR-)'; Related Transition Event and Source Cash Flow Notification (12, adapted at W4); Overview Scope '(05 Distribution Agreements & Partners)', '(12 Institutional Client Servicing & Reporting)' and 'investor capital accounts of private funds (30)'; Fund Interest Holding Detail.Adjusted NAV note '30 proposes a row rule (deferred)'. Corresponding Shareholder Position references 06 Position (POS-), re-pointed when 06 becomes a view of 49 at W4 (CW-007).",
    "Private-markets residue for the W4 decision on 30 (listed, not removed): Private Fund Portfolio Detail (Vintage Year, Valuation Lag Days, Fund Interest Holdings Indicator, Subscription Credit Facility Indicator); Fund Interest Holding Detail (kept: own alternative feeder funds of 01 and 15 may hold fund interests); code values Portfolio Identifier Scheme 'Private Markets System Code', Projected Cash Source 'Capital Call' and 'Distribution Received', Capital Activity Type 'Capital Call Proceeds' and 'Distribution to Investors', Capital Activity Source 'Private Fund Administrator', Portfolio Transaction Type 'Capital Call Paid' and 'Distribution Received', Position Adjustment Reason 'Private Asset Statement Update'; sources ILPA Reporting Template and eFront / FIS Investran. Insurance-dedicated funds: no 18 value names them after the pass (SME question 9 in Source_Notes keeps the sub-advised insurer separate account question).",
    "The rename of 25 to Portfolio Trading & Execution is used in the 18 texts (CW-010; 25 META carries it, domains.py at merge).",
    "Remaining hits of the step 1 grep, justified: 'EUR' amounts in examples (foreign instruments); 'Stamp Duty' and 'financial transaction tax' in Transaction Tax Amount (foreign transaction taxes the funds pay); 'WMR London 4pm Close Mid' (FX source, kept); 'UK' and 'MiFID' only in the Overview Notes sentence that states the removal; 'SMA' only in the kept object and group names SMA Portfolio Detail and SMA Detail and the Form ADV and IRC source rows that name the object.",
    "Other domains' content seen: 21 Business Line still carries the wholesale values plus 'Institutional Mandate' and 'Proprietary / Seed' (21 is in W1b editor 1's set); 23 cites the 28(e) release at a URL this pass reuses; 15 Cost Basis Election is the client election the 18 Tax Lots family text now names.",
    "Unverified: the SEC release 34-54165 URL is copied from 23 (confirm); the SEC Section 31 fee wording on Exchange and Clearing Fee Amount (confirm booking practice with fund accounting).",
    "W1b fix pass (review 00_Program/Rework/Reviews/W1b_18_25_26_27_review.md): sponsor and wrap program accounts reworded as IC-line sponsor program accounts (ruling 1; Business Line note, SMA Detail group, Managed Account, Sponsor Program Agreement, Manages Account value and relationship, Sponsor Account Number, Sponsor Notification, the sponsor relationship, the Form ADV source and the SMA Portfolio Detail grain); Lot Rule Jurisdiction note reworded (ruling 5); Followed Model Portfolio note; Managing Entity note naming 52; Source_Notes question 11, the 05 / 15 overlap (ENRL-, not PGM-) and the 15 Cost Basis Election wording. No Low skipped.",
    "For the 52 brief (W3 / W4): whether a sleeve run by an external sub-adviser is an 18 book with the firm's adviser as Managing Entity (as now worded) or held only as 52 oversight data from the sub-adviser's records.",
]
