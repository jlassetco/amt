"""W1b proposals of Data Domain 19 Finance & Accounting (wealth model; kept with the US-only and perspective pass). Brief:
00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (row 19); decisions CW-003, CW-022, CW-039 (Accounting Basis
re-cut). Declarative only: the program lead merges DECISIONS into decisions.py, appends JURISDICTION to
jurisdiction.REMOVALS and applies SHARED_RECUTS to shared_code_lists.py at merge (W5 for the shared lists, CW-039). The
existing proposals_19.py (expansion) is unchanged.
"""

_D = "CW-919"


def _j(obj, attr, regime, note):
    return {"domain": "19", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


_RRT = "Code list: Regulatory Return Type"
_AB = "Code list: Accounting Basis"
_PM = "Code list: Payment Method"

JURISDICTION = [
    # Attribute
    _j("Indirect Tax Detail", "Supplier VAT Number", "Other EU/UK",
       "EU/UK VAT registration number (Council Directive 2006/112/EC; UK VAT); US sales tax has no invoice-level supplier registration number in the model."),
    # Regulatory Return Type
    _j(_RRT, "FCA MIF001 Own Funds Return", "FCA", "MIFIDPRU own funds; the US capital return is the FOCUS Report under SEC Rules 17a-5 and 15c3-1."),
    _j(_RRT, "FCA MIF002 Liquid Assets Return", "FCA", "MIFIDPRU liquid assets; no UK investment firm."),
    _j(_RRT, "FCA Financial Return (other)", "FCA", "IPRU-INV returns of UK ManCos and AIFMs; no UK entity."),
    _j(_RRT, "CSSF Management Company Return", "Other EU/UK", "Luxembourg CSSF return of a UCITS ManCo / AIFM; no Luxembourg entity."),
    _j(_RRT, "Central Bank of Ireland Return", "Other EU/UK", "Irish ManCo / AIFM return; no Irish entity."),
    _j(_RRT, "FCA MIF007 ICARA Questionnaire", "ICARA", "ICARA leaves 43 under CW-943; no UK investment firm."),
    # Accounting Basis (shared, steward 19)
    *[_j(_AB, v, "Other EU/UK", "Basis of the former EU/UK group entities; the US group keeps US GAAP, Tax Basis and Regulatory (shared list re-cut at W5, CW-039).")
      for v in ("IFRS (EU-adopted)", "UK-adopted IFRS", "FRS 102 (UK GAAP)", "Lux GAAP", "Irish GAAP (FRS 102)")],
    # Payment Method
    _j(_PM, "SEPA Credit Transfer", "EU market practice", "Payment scheme of the former EU entities; foreign suppliers are paid by Wire Transfer."),
    _j(_PM, "UK Faster Payment", "UK market practice", "UK payment scheme; named in the brief."),
    _j(_PM, "BACS", "UK market practice", "UK payment scheme; ACH Credit is the US equivalent."),
    _j(_PM, "CHAPS", "UK market practice", "UK high-value payment scheme; Wire Transfer (Fedwire) is the US equivalent."),
    # Control Assessment Basis
    _j("Code list: Control Assessment Basis", "IFRS 10 Control - Principal", "Other EU/UK",
       "IFRS 10 basis of the EU/UK group entities; US GAAP control is assessed under the ASC 810 voting interest and VIE models."),
    _j("Code list: Control Assessment Basis", "IFRS 10 - Agent", "Other EU/UK", "As above; decision-maker fees are analyzed under the ASC 810 VIE model."),
    # Indirect Tax Recoverability (VAT terms)
    _j("Code list: Indirect Tax Recoverability", "Partially Recoverable", "Other EU/UK", "VAT partial exemption method; no US equivalent."),
    _j("Code list: Indirect Tax Recoverability", "Reverse Charge - Self-Accounted", "Other EU/UK", "VAT reverse charge; replaced by 'Use Tax - Self-Assessed' (state use tax)."),
    _j("Code list: Indirect Tax Recoverability", "Exempt Supply", "Other EU/UK", "VAT exempt supply; replaced by 'Exempt Purchase' (exemption or resale certificate)."),
    # Tax Type
    _j("Code list: Tax Type", "VAT", "Other EU/UK", "No EU/UK entity is VAT-registered; Sales and Use Tax is the US indirect tax."),
    # Sources
    _j("Sources", "IFRS Standards (IFRS 9, IFRS 10, IFRS 15, IAS 1, IAS 8, IAS 12, IAS 21, IAS 28)", "Other EU/UK",
       "Reporting basis of the former EU/UK group entities (EU- and UK-adopted IFRS); 25 secondary references and five list alignments removed; the FASB ASC stays."),
    _j("Sources", "FCA Handbook MIFIDPRU and FCA regulatory reporting (RegData)", "FCA",
       "Regulatory Financial Return re-sourced to the FOCUS Report (SEC Rule 17a-5) and Form ADV financial items."),
    _j("Sources", "Council Directive 2006/112/EC on the common system of VAT", "Other EU/UK",
       "Indirect Tax Detail and Output VAT Amount re-sourced to US sales and use tax (SSUTA and state law)."),
    _j("Sources", "UK Companies Act 2006 Part 15 (accounts and reports)", "Other EU/UK", "Statutory accounts of UK group entities; none in the US group."),
]

DECISIONS = [
    {"id": "CW-919", "theme": "Scope", "title": "US-only pass of 19 Finance & Accounting", "domains": ["19"],
     "issue": "The wholesale 19 kept the books of an asset management group with EU and UK entities: FCA, CSSF, Central Bank of Ireland "
              "and ICARA return types, the EU- and UK-adopted IFRS, FRS 102, Lux and Irish GAAP bases (shared Accounting Basis, steward 19), "
              "SEPA, Faster Payments, BACS and CHAPS, IFRS 10 control values, VAT recoverability, a Supplier VAT Number and a VAT tax "
              "type, with IFRS, FCA MIFIDPRU, the EU VAT Directive and the UK Companies Act as sources and GBP examples. Its text said "
              "'not only for distribution', cited GDPR and named '02 Client & Customer'.",
     "resolution": "1) Removed (26 JURISDICTION entries: Other EU/UK 17, FCA 4, UK market practice 3, EU market practice 1, ICARA 1): "
                   "Indirect Tax Detail.Supplier VAT Number; Regulatory Return Type values FCA MIF001, FCA MIF002, FCA Financial Return (other), "
                   "CSSF Management Company Return, Central Bank of Ireland Return, FCA MIF007 ICARA Questionnaire; Accounting Basis values IFRS "
                   "(EU-adopted), UK-adopted IFRS, FRS 102 (UK GAAP), Lux GAAP, Irish GAAP (FRS 102); Payment Method values SEPA Credit Transfer, "
                   "UK Faster Payment, BACS, CHAPS; Control Assessment Basis values IFRS 10 Control - Principal, IFRS 10 - Agent; Indirect Tax "
                   "Recoverability values Partially Recoverable, Reverse Charge - Self-Accounted, Exempt Supply; Tax Type value VAT; sources IFRS "
                   "Standards, FCA MIFIDPRU and RegData, Council Directive 2006/112/EC, UK Companies Act 2006 Part 15. No object removed. "
                   "2) Re-sourced: Regulatory Financial Return to the FOCUS Report (Form X-17A-5, SEC Rule 17a-5) and Form ADV financial items "
                   "(new source row; new value Form ADV Financial Information; example FOCUS Report Part II for the self-clearing broker-dealer; "
                   "Bank Call Report for the optional national trust company; list alignment SEC / FINRA / OCC; FCA MIFIDPRU removed from five "
                   "attributes and the capital amounts read Rule 15c3-1 net capital only); Indirect Tax Detail (Indirect Tax Type, Rate, "
                   "Recoverability with its list re-cut to Irrecoverable, Use Tax - Self-Assessed, Exempt Purchase, Fully Recoverable; Recoverable "
                   "Percentage kept and redefined) and Receivable Item.Output VAT Amount (name kept) to US sales and use tax (primary 'State sales "
                   "and use tax law', secondary SSUTA; one new source row; the example state Pennsylvania is not an SSUTA member); EU VAT Directive removed from Payable Document Type, Supplier Invoice Number and Invoice Date; IFRS 10, IFRS 15, "
                   "IAS 1, IAS 12 and IAS 21 removed from 25 secondary references and from the alignment of Consolidation Method, Control "
                   "Assessment Basis (now ASC 810 / ASC 946), Financial Statement Type and Provision Component and two value notes. "
                   "3) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose (the US wealth manager group entities: "
                   "holding company, advisers, self-clearing broker-dealer, transfer agent, recordkeeper, service company, optional national trust "
                   "company; every business line), Scope, Design principle 2, Primary / Secondary Reference and Notes (US privacy law); the "
                   "Regulatory Financial Return and Indirect Tax Detail group texts; USD examples in Payables and Receivables and US examples for "
                   "chart segment, close task, payroll run, payment run, payment method, tax registration and TP documentation; Plan Scenario "
                   "'Capital and Liquidity Stress' no longer cites ICARA; review fix pass: capital examples for a carrying broker-dealer (requirement USD "
                   "250,000 under Rule 15c3-1, resources USD 412,000,000), Intercompany Balance and Covered Transaction Value examples in USD (no "
                   "euro-ledger entity), Form ADV Financial Information described as Part 2A Item 18 with Item 5.F as a reported amount, Design "
                   "principle 1 'revenue of the adviser'; SUMMARY and the Indirect Tax Detail grain in enrich_19.py; "
                   "Source_Notes status line, rationale, sources, design note, unverified list, SME questions 6 and 10 and section 6. "
                   "4) Re-pointed: '02 Client & Customer' reads '02 Client & Household' and '01 Investment Product' reads '01 Investment Product & Service Offering' (SUMMARY); Party references resolve unchanged (CW-021). "
                   "5) Added: none named by the brief; the value Form ADV Financial Information and two source rows serve the re-sourcing. "
                   "6) IDs: the attribute IDs of the Payables family renumber after Indirect Tax Detail (one attribute removed); no other family "
                   "changes. Counts: 29 objects, 249 to 248 attributes, 82 CDEs (33.1%), 38 code lists, 18 to 16 sources, 45 relationships.",
     "rationale": "CW-003 and CW-022: the wealth model's group is US only, so the firm's own EU/UK entities and their returns, accounting "
                  "bases, payment schemes and VAT leave; foreign currency translation (ASC 830) stays. The US instances are the FOCUS Report "
                  "and Rule 15c3-1 for the self-clearing broker-dealer, Form ADV financial items for the advisers, a Call Report for the "
                  "optional trust company, US GAAP and state sales and use tax. A UK extension restores the removed rows from wholesale-v1.0.",
     "action": "W1b", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

SHARED_RECUTS = [
    ("Accounting Basis", "19",
     "Steward 19 (CW-039). Remove IFRS_EU_ADOPTED, UK_ADOPTED_IFRS, FRS_102_UK_GAAP, LUX_GAAP and IRISH_GAAP_FRS_102 "
     "(shared_code_lists.py lines 2221-2229), leaving US_GAAP, TAX_BASIS and REGULATORY; drop those keys from the 19 value map "
     "(line 2234). The member 10 'Accounting Framework' (W4) and the direct user 27 (W1b editor 2, CW-927) drop their EU/UK values in "
     "their own passes; 10's map (line 2235) loses the same four keys."),
]

SHARED_CANDIDATES = []

NOTES = [
    "W1b (wealth), CW-919. Validation: taxonomy_builder.py content_19_finance_and_accounting OK (8 families, 29 objects, 248 attributes, "
    "82 CDEs, 63 references, 4 derived, 0 unresolved, 38 code lists); before: 249 attributes, 82 CDEs, 38 code lists, 18 sources; after: 16 "
    "sources. check_enrichment.py 19 OK.",
    "READERS (not edited; for the program lead's lineage pass): the removed attribute Supplier VAT Number has no reader in "
    "data_products, data_models or semantic_model/models. Recoverable Percentage was kept (redefined) because it is read by "
    "data_products/specs_e4_finance_tax_treasury.py lines 334-335 and 496-497 (metric Irrecoverable Indirect Tax), lines 371 and 510 (19 "
    "input lists) and semantic_model/models/sm_14_corporate_finance_treasury_tax.py line 205; the metric text at line 334 names the removed "
    "Indirect Tax Recoverability values 'Reverse Charge - Self-Accounted' and 'Exempt Supply' (re-word to 'Use Tax - Self-Assessed' at "
    "0% recovery and 'Exempt Purchase'). No product, model or semantic model names the removed Regulatory Return Type, Accounting Basis, "
    "Payment Method or Control Assessment Basis values.",
    "References to retiring or later-replaced domains left as they are: 10 Distribution Finance & Profitability throughout (overview "
    "Scope, Core model, Suggested next steps 3 and 5, Journal Source 'Distribution Finance', Receivable Source Type, SUMMARY; W4 "
    "adaptation of 10); 05 Partner Invoice and Partner Payment (Source Partner Invoice, Settled Partner Payment, two REL; 05 replaced at "
    "W4); 07 Compensation Accrual (Journal Source 'Incentive Compensation', REL 'GL Posting is sourced from Compensation Accrual [07]'; 07 "
    "retires at W4); 13 Intermediary Communication Fee Invoice (W2); 30 Private Markets (Other Source Document Reference note, "
    "Receivable Source Type 'Carried Interest / Incentive Allocation', Journal Type 'Management Fee Offset', Financial Statement Class "
    "'Revenue - Performance Fees and Carried Interest': private-markets content for the W4 retirement decision).",
    "Remaining hits of the step 1 grep, justified: 'a foreign VAT or GST a supplier charges' on Indirect Tax Detail and the Output VAT "
    "Amount name (kept for continuity; the attribute holds US sales tax); OECD SAF-T (market-neutral structure); OECD TPG and Pillar Two "
    "(international tax, open question 2 in Source_Notes); Revenue Disaggregation example 'Distribution Fee' (10's revenue stream, W4).",
    "Rename candidate for the W5 consolidation decision: Receivable Item.Output VAT Amount to 'Output Indirect Tax Amount' (the US model holds sales tax in it; name kept now under the names-unchanged rule).",
    "Tailoring lever (not applied): a purely domestic US group is outside the GloBE rules and files no country-by-country report "
    "(Form 8975); Tax Type 'Pillar Two Top-Up Tax', Provision Components for Pillar Two and the TP Documentation Type 'Country-by-Country "
    "Report' could leave at W5.",
    "Unverified: Form ADV and SSUTA URLs; Form ADV Part 1A Item 5.F and Part 2A Item 18 as the adviser's financial items; whether a "
    "trust-only national bank files the FFIEC Call Report (all marked confirm).",
    "Seen in other domains (not edited): 27 holds Accounting Basis EU/UK values and fund tax return types (CW-927); 43 ICARA Assessment "
    "(CW-943) is the target of the removed MIF007 value; 10 Accounting Framework (member of Accounting Basis) carries the same EU/UK values.",
]
