"""W1b proposals of Data Domain 20 Human Capital (wealth model; kept with the US-only and perspective pass). Brief:
00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (row 20); decisions CW-003, CW-004, CW-021, CW-022, CW-039.
Declarative only: the program lead merges DECISIONS into decisions.py, appends JURISDICTION to jurisdiction.REMOVALS and
applies SHARED_RECUTS to shared_code_lists.py at merge (W5 for the shared lists, CW-039). The existing proposals_20.py
(expansion) is unchanged.
"""

_D = "CW-920"


def _j(obj, attr, regime, note):
    return {"domain": "20", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


_MRT = "Removed with Material Risk Taker Identification (no EU/UK remuneration code applies to a US-only firm)."

# ---------------------------------------------------------------------------------------------------------------------
# Jurisdiction register entries (jurisdiction.REMOVALS format). Objects and attributes use the wholesale-v1.0 names.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = [
    # Object
    _j("Material Risk Taker Identification", "", "Other EU/UK",
       "Identification of material risk takers (MIFIDPRU, FCA SYSC 19G) and identified staff (UCITS SYSC 19E / Directive Art 14a-14b; "
       "AIFMD SYSC 19B / Annex II; IFD) that drove regulated deferral, payment in instruments and retention. Whole object (8 attributes: "
       "MRT Employee, MRT Performance Year, Remuneration Regime, Identifying Legal Entity, Material Risk Taker Indicator, MRT Criteria Met, "
       "Deferral Exemption Applied Indicator, Identification Approval Date) and its two relationships. No US equivalent: deferral, malus "
       "and clawback stay on Variable Compensation Award and Deferred Award Tranche under firm policy. The 07 Identified Staff Indicator "
       "copy loses its master (NOTES)."),
    # Attributes
    _j("Employee Diversity Profile", "UK Ethnic Group", "Other EU/UK",
       "UK ONS harmonized ethnic groups for UK employees; no UK workforce. US race and ethnicity is US Race / Ethnicity Category (EEO-1)."),
    _j("Contingent Worker Detail", "Off-Payroll Working Determination", "Other EU/UK",
       "UK off-payroll working rules (IR35, ITEPA 2003 Chapter 10). US worker classification is not added (tailoring lever: IRS common-law "
       "and state ABC tests would be a firm addition)."),
    _j("Job Profile", "ISCO-08 Code", "Other EU/UK",
       "ILO occupation code held only for EU and UK statistical and ESRS S1 reporting; the US SOC 2018 code stays."),
    _j("Deferred Award Tranche", "Retention Period End Date", "FCA",
       "Post-vesting retention of instrument-based awards required by the UK and EU remuneration codes (SYSC 19G, 19E, 19B). Vesting, "
       "malus and clawback dates stay."),
    # Code-list values: whole local lists
    _j("Code list: MRT Remuneration Regime", "UCITS Directive (Art 14a-14b)", "UCITS", "Whole list removed with the object. " + _MRT),
    _j("Code list: MRT Remuneration Regime", "AIFMD (Annex II)", "AIFMD", "Whole list removed with the object."),
    _j("Code list: MRT Remuneration Regime", "MIFIDPRU Remuneration Code", "FCA", "Whole list removed with the object."),
    _j("Code list: MRT Remuneration Regime", "IFD (Directive (EU) 2019/2034)", "Other EU/UK", "Whole list removed with the object."),
    _j("Code list: MRT Remuneration Regime", "Firm Policy Only", "Other EU/UK", "Regime-neutral value, removed with the list (whole list removed with the object); firm policy is the only basis left."),
    *[_j("Code list: MRT Criterion", v, "FCA", "Whole list removed with the object (MIFIDPRU SYSC 19G.5.3R criterion).")
      for v in ("Management Body - Management Function", "Management Body - Supervisory Function", "Senior Management",
                "Head of Regulated Business Unit", "Control Function", "Money Laundering Prevention", "Material Risk Management",
                "IT, Information Security or Critical Outsourcing", "New Product Approval Authority")],
    *[_j("Code list: MRT Criterion", v, "UCITS", "Whole list removed with the object (UCITS / AIFMD identified staff criterion, ESMA guidelines).")
      for v in ("Head of Portfolio Management, Administration, Marketing or HR", "Remuneration Bracket")],
    *[_j("Code list: UK Ethnic Group", v, "Other EU/UK", "Whole list removed with the attribute (UK ONS standard).")
      for v in ("Asian or Asian British", "Black, Black British, Caribbean or African", "Mixed or Multiple Ethnic Groups", "White",
                "Other Ethnic Group", "Prefer Not to Say")],
    *[_j("Code list: IR35 Determination", v, "Other EU/UK", "Whole list removed with the attribute (HMRC IR35).")
      for v in ("Inside IR35", "Outside IR35", "Not Applicable", "Under Review")],
    # Code-list values: single values
    _j("Code list: National Identifier Type", "UK National Insurance Number", "Other EU/UK", "No UK payroll; US Social Security Number and ITIN stay, with Other."),
    _j("Code list: National Identifier Type", "EU National Tax Identifier", "Other EU/UK", "No EU payroll."),
    _j("Code list: Work Authorization Type", "EU Free Movement", "Other EU/UK", "EU / EEA free movement; the list is the USCIS Form I-9 set."),
    _j("Code list: Work Authorization Type", "Citizen / Settled Status", "Other EU/UK",
       "Label named the UK EU Settlement Scheme status; relabeled 'US Citizen or Noncitizen National' (Form I-9 category), same meaning for the US."),
    *[_j("Code list: Regulated Role Category", v, "SM&CR", "FCA SM&CR role status. Re-sourced to FINRA Rule 1220 categories and SEC Rule 203A-3 (investment adviser representative).")
      for v in ("Senior Management Function", "Certification Function", "Conduct Rules Staff")],
    _j("Code list: Diversity Data Processing Basis", "Equality Monitoring", "GDPR / UK GDPR",
       "UK DPA 2018 Schedule 1 equality monitoring condition (GDPR Art 9(2)(g)); the list is re-cut to US bases (EEO-1 / OFCCP, state law)."),
    _j("Code list: Background Screening Type", "Regulatory References", "SM&CR",
       "FCA SYSC 22 regulatory references; replaced by Prior Form U5 Review (FINRA Rule 3110(e))."),
    _j("Code list: Tranche Vesting Status", "Released After Retention", "FCA", "Removed with Retention Period End Date."),
    _j("Code list: Regulatory Credit Type", "UK Structured CPD", "Other EU/UK", "UK professional body CPD; FINRA CE, CFA Institute and CFP Board credits stay."),
    _j("Code list: Training Requirement Type", "Conduct Rules", "SM&CR",
       "FCA conduct rules training; replaced by Code of Ethics and Conduct (Advisers Act Rule 204A-1 and the firm code)."),
    _j("Code list: Training Requirement Type", "Market Abuse", "Other EU/UK",
       "EU Market Abuse Regulation term; relabeled 'Insider Trading and MNPI' (Advisers Act section 204A, Exchange Act section 15(g)), same meaning for the US."),
    # Sources
    _j("Sources", "International Standard Classification of Occupations (ISCO-08)", "Other EU/UK", "Removed with ISCO-08 Code."),
    _j("Sources", "FCA Handbook SYSC 19G MIFIDPRU Remuneration Code (including SYSC 19G.5.3R MRT criteria and 19G.5.9R)", "FCA",
       "Was the reference of the award, tranche, MRT, review and objective attributes; those that stay now cite Internal (firm policy)."),
    _j("Sources", "FCA Handbook SYSC 19E UCITS Remuneration Code", "UCITS", "Removed with the MRT object and the award instrument references."),
    _j("Sources", "FCA Handbook SYSC 19B AIFM Remuneration Code", "AIFMD", "Removed with the MRT object and the carried interest references."),
    _j("Sources", "ESMA Guidelines on sound remuneration policies under the UCITS Directive (ESMA/2016/575); AIFMD remuneration guidelines as amended following the ESMA/2016/411 final report", "UCITS",
       "Removed with the MRT object; Variable Award Type, Linked Fund and Malus / Clawback Status cite firm policy."),
    _j("Sources", "FCA Senior Managers & Certification Regime", "SM&CR",
       "Regulated Role Category re-sourced to FINRA Rule 1220 and SEC Rule 203A-3; screening to FINRA Rule 3110(e) and FCRA."),
    _j("Sources", "UK Money Laundering, Terrorist Financing and Transfer of Funds (Information on the Payer) Regulations 2017, regulation 24 (training)", "Other EU/UK",
       "AML training stays on FINRA Rule 3310(e)."),
    _j("Sources", "UK gender pay gap reporting (Equality Act 2010 (Gender Pay Gap Information) Regulations 2017)", "Other EU/UK",
       "No UK employer; metric references re-sourced to EEO-1 and ISO 30414; Hours Worked to the US FLSA (CD-364 definition unchanged)."),
    _j("Sources", "EU Pay Transparency Directive (EU) 2023/970", "Other EU/UK", "No EU employer; Job Level cites firm leveling only."),
    _j("Sources", "ESRS S1 Own workforce, in Commission Delegated Regulation (EU) 2023/2772 (European Sustainability Reporting Standards)", "Other EU/UK",
       "CSRD workforce disclosure; metric, termination, working pattern and diversity references re-sourced to ISO 30414, EEO-1 or Internal."),
    _j("Sources", "GDPR (Regulation (EU) 2016/679) Articles 9, 10 and 88; UK GDPR and Data Protection Act 2018 Schedule 1", "GDPR / UK GDPR",
       "Special category handling re-sourced to CD-344 and state law (California CCPA as amended by the CPRA; FCRA and state fair chance laws for criminal history)."),
    _j("Sources", "UK right to work checks (Home Office employer guidance)", "Other EU/UK", "Work authorization cites USCIS Form I-9 alone."),
    _j("Sources", "HMRC off-payroll working rules (IR35)", "Other EU/UK", "Removed with Off-Payroll Working Determination."),
    _j("Sources", "UK Government Analysis Function ethnicity harmonized standard (ONS)", "Other EU/UK", "Removed with UK Ethnic Group."),
    _j("Sources", "FINRA Rule 4511 and MiFID II Article 16(7) (records and recording of communications)", "MiFID II",
       "The MiFID II half of the source; the row is retitled 'FINRA Rule 4511 (general requirements for books and records)' and Business Phone Number cites Rule 4511."),
]

# ---------------------------------------------------------------------------------------------------------------------
# Decision of the US-only pass of 20 (decisions.DECISIONS format)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-920", "theme": "Scope", "title": "US-only pass of 20 Human Capital",
     "domains": ["20"],
     "issue": "The wholesale 20 described an asset manager that distributes wholesale with employees in the US, the UK and the EU. It mastered material risk taker identification under the UCITS, AIFMD, MIFIDPRU and IFD remuneration codes, sourced the variable compensation, tranche, review and objective attributes to FCA SYSC 19G / 19E / 19B and the ESMA remuneration guidelines, defined the regulated role requirement by SM&CR functions, held UK ethnic group, UK IR35 status and an ISCO-08 code for EU/UK reporting, cited the UK gender pay gap regulations, the EU Pay Transparency Directive, ESRS S1, UK MLR 2017 and GDPR / UK GDPR, and carried UK and EU code values (National Insurance number, EU free movement, UK structured CPD, FCA conduct rules, regulatory references) and GBP examples.",
     "resolution": "Affects the readers in 07 (Identified Staff Indicator copy) and 08 (registrations, CE) noted below. 1) Removed (59 JURISDICTION entries: Other EU/UK 30, FCA 13, SM&CR 6, UCITS 5, AIFMD 2, GDPR / UK GDPR 2, MiFID II 1): object Material Risk Taker Identification (8 attributes, two relationships) with its lists MRT Remuneration Regime (5 values) and MRT Criterion (11 values); attributes Employee Diversity Profile.UK Ethnic Group (list UK Ethnic Group, 6 values), Contingent Worker Detail.Off-Payroll Working Determination (list IR35 Determination, 4 values), Job Profile.ISCO-08 Code, Deferred Award Tranche.Retention Period End Date; values National Identifier Type UK National Insurance Number and EU National Tax Identifier, Work Authorization Type EU Free Movement (and Citizen / Settled Status relabeled US Citizen or Noncitizen National), Regulated Role Category Senior Management Function, Certification Function and Conduct Rules Staff, Diversity Data Processing Basis Equality Monitoring, Background Screening Type Regulatory References, Tranche Vesting Status Released After Retention, Regulatory Credit Type UK Structured CPD, Training Requirement Type Conduct Rules (and Market Abuse relabeled Insider Trading and MNPI); 14 sources (ILO ISCO-08, FCA SYSC 19G, 19E, 19B, ESMA remuneration guidelines, FCA SM&CR, UK MLR 2017, UK gender pay gap regulations, EU Pay Transparency Directive, ESRS S1, GDPR / UK GDPR / DPA 2018, UK right to work guidance, HMRC IR35, UK ONS ethnicity standard) and the MiFID II Article 16(7) half of the FINRA Rule 4511 source (retitled). "
                   "2) Re-sourced: Job Profile.Regulated Role Category to FINRA Rule 1220 registration categories and SEC Rule 203A-3(a), with values FINRA Registered Representative, FINRA Registered Principal, FINRA Operations Professional (new), Investment Adviser Representative (new), Not Regulated; mandatory training to FINRA Rule 3310(e) and FINRA Rule 1240 (Training Requirement Type value Code of Ethics and Conduct, Advisers Act Rule 204A-1, replaces Conduct Rules; Data Protection cites Regulation S-P, S-ID and state law); diversity to EEO-1 (Diversity Data Processing Basis re-cut to Explicit Consent, Employment Law Obligation, US Voluntary Self-Identification, Not Collected, sourced to EEO-1 / OFCCP and the CPRA); special category handling to CD-344 and state law (CPRA, state biometric laws, FCRA and state fair chance laws) in the overview Notes and every attribute note; Background Screening Type to FINRA Rule 3110(e) and the FCRA (value Prior Form U5 Review replaces Regulatory References); Candidate Data Retention End Date to 29 CFR 1602.14 and the CPRA; Variable Compensation Award, Deferred Award Tranche, Performance Review and Performance Objective references from SYSC 19G / 19E / 19B and ESMA to Internal (firm compensation, deferral and clawback policy) and the five reward and objective list sources likewise; Work Authorization Type to USCIS Form I-9 alone; Metric Breakdown and Metric Period End Date to EEO-1; Metric Legal Entity and Metric Country to Internal; Termination Reason and Voluntary Termination Indicator to ISO 30414; Gender Identity, Disability Status, Working Pattern, Metric Definition, Disclosure Classification, Job Level, Legal Gender and Standard Weekly Hours lose their EU/UK secondary references; Hours Worked secondary reference to the US FLSA (CD-364 definition unchanged); Regulatory Notification Required Indicator secondary to FINRA Form U4; Business Phone Number to FINRA Rule 4511; four sources added (FINRA Rule 1220 and SEC Rule 203A-3(a), 29 CFR 1602.14, Fair Credit Reporting Act, California CCPA / CPRA). "
                   "3) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose, Scope, Core model, Applies To, CDE, Notes and Suggested next steps; family texts of Compensation, Benefits & Payroll, Variable Compensation and Workforce Analytics; examples to USD, a US payroll run (US-M-2027-04-R1), US address and country codes, a masked SSN, a financial advisor job profile (SOC 13-2052); UK-flavored value descriptions (Leave Type, Employee Benefit Type, Enrollment Event, Pay Component, Working Pattern, Job Family Distribution) reworded; the DPO reads privacy officer; enrich_20 SUMMARY; Source_Notes header, purpose paragraph, section 1 sources and section 6. Attribute IDs renumber within Employee Master (Diversity Profile, Contingent Worker Detail), Jobs, Positions & Assignments (Job Profile) and Compensation, Benefits & Payroll (Deferred Award Tranche, the MRT object, and everything after them). "
                   "4) Re-pointed (CW-021, CW-023): Client Party Cross-Reference and the Party relationship read 'client' instead of 'client or investor'; 02 is named Client & Household, 01 Investment Product & Service Offering. No reference was retyped. 5) Added: none (brief row 20). "
                   "6) Kept on purpose: deferral, fund-linked awards, malus and clawback (generic, firm policy); the certified headcount, FTE and pay definitions of CD-341 and CD-364; Garden Leave; Protected Veteran Status and Section 503 self-identification (federal contractor lever). Counts: 29 to 28 objects, 243 to 231 attributes, 80 to 74 CDEs (32%), 63 to 59 code lists, 40 to 38 relationships, 30 to 20 sources, 174 to 163 PII attributes.",
     "rationale": "CW-003 and CW-022: the wealth firm is regulated and employs in the US only, so the EU/UK remuneration codes, SM&CR, UK and EU workforce reporting and GDPR have nothing to apply to; the generic HR record (deferral, clawback, diversity, screening, training) stays and is sourced to the US rule or to firm policy. Names are kept so that DP-192, DP-194, DP-197, DP-198, DP-201 and the people models keep resolving; DP-199 loses its purpose with the MRT object and the 07 Identified Staff Indicator loses its master (NOTES, READERS). Levers: a firm with a UK or EU employing entity restores the removed rows from wholesale-v1.0 through the jurisdiction register.",
     "action": "W1b", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# Shared list re-cuts (20 stewards no shared list; it uses six directly and is party to two NOT_MERGED pairs)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_RECUTS = [
    ("NOT_MERGED", "09",
     "Delete the pair ('20', 'MRT Remuneration Regime', '07', 'Remuneration Regime') in shared_code_lists.py line 2774: the 20 list is removed (CW-920)."),
]

SHARED_CANDIDATES = [
    ("Regulated Role Category", None, ["08"],
     "Withdrawn: the expansion candidate in proposals_20.py (one 08-stewarded list for the SM&CR values) lapses with the SM&CR values. "
     "The FINRA Rule 1220 and investment adviser representative values may be shared with the replaced 08 Regulatory Compliance (W2), "
     "whose individual registration list should use the same labels."),
]

# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "W1b (wealth), CW-920. Validation: taxonomy_builder.py content_20_human_capital OK (7 families, 28 objects (3 attribute groups, 0 "
    "without grain), 231 attributes, 74 CDEs, 29 references, 0 derived, 0 unresolved, 59 code lists); before: 29 objects, 243 attributes, "
    "80 CDEs, 30 references, 63 code lists. check_enrichment.py 20 OK. JURISDICTION 59 entries (review fix pass: Market Abuse relabel added).",
    "READERS of the removed object and attributes (not edited; for the program lead and the product, model and semantic owners): "
    "data_products/framework.py line 1075 (DP-199 'Remuneration Code: Material Risk Takers & Deferred Awards', whose purpose was the "
    "MRT population: retire or re-scope to deferred awards and clawback at WP0); data_products/specs_e4_people_workplace_ai.py lines "
    "293, 309-323 (Identified MRTs, Identifications Not Approved, Senior Managers Not Identified, which also reads the removed Regulated "
    "Role Category value Senior Management Function, Total Variable Remuneration), 329-333 (Deferral Shortfalls, Invalid Deferral "
    "Exemptions, GBP 167,000 MIFIDPRU test), 352 and 355-356 (Remuneration Under Clawback and Early Releases Before Retention End read "
    "the removed value Released After Retention and Retention Period End Date), 358-362 (Identified Staff Copy Mismatches), 365-367 and "
    "373 (DP-199 inputs), 396 and 399 (quality rules), 402-403 (notes); lines 578-580, 597-598 and 623 (DP-201 Representation % and "
    "Ethnicity Pay Gap % read UK Ethnic Group); data_products/specs_e1_masters.py line 646 (Off-Payroll Working Determination) and 648 "
    "(ISCO-08 Code) in the DP-192 inputs; specs_e4_people_workplace_ai.py lines 296-302 (DP-199 business questions on MRTs, senior "
    "management function holders and the 07 identified staff flag) and 404-415 (DP-199 notes: SYSC 19G.5.9R, IFD entities, MRT exit "
    "date gap); the generated data_products/_catalog.txt line 1843 (UK Ethnic Group in the DP-201 inputs; refreshes on rebuild); consolidation/proposals_dp_corporate_a.py lines 159-170 (DP-199 proposal); data_models/"
    "keys_e7_19_21.py lines 146-147 and 358-359 (MRT key); data_models/models_e8c_people_workplace_ai.py lines 6, 280-281, 308, 316, "
    "320, 325-326 and 351 (Fact MRT Identification and its relationships); semantic_model/models/sm_15_people_workplace.py lines 14 "
    "and 74 (off_payroll_determination), 21 (REMUNERATION_CODE), 275-292 (mrt_identification entity and retention_period_end_date), "
    "1226 (measure testing 'Released After Retention'), "
    "727-735 (joins), 1161-1170, 1191-1199, 1231-1239 and 1761-1762 (MRT measures and the sample question).",
    "Registers that name the removed content (not edited): consolidation/decisions.py line 2125 (concept row Material Risk Taker "
    "Identification, 20, users 07) and line 2118 (Job Profile note 'SOC / ISCO occupation'); decisions.py lines 4044-4048 (TERM_CONFLICTS "
    "'Remuneration Regime / Identified Staff'); consolidation/gaps_register.py lines 2946 and 2953-2957 (GAP-20-005 'MRT Exit Date' "
    "lapses); consolidation/shared_code_lists.py line 2774 (NOT_MERGED pair, SHARED_RECUTS); proposals_20.py CONCEPT_OWNERSHIP, "
    "CROSS_DOMAIN_CHANGES (07 Identified Staff Indicator) and NOT_MERGED rows on MRT (kept unchanged as the expansion record).",
    "Other domains' content seen (not edited; for their own stages): content_07_compensation_and_territory.py line 469 (Identified "
    "Staff Indicator, 'Copy of ... mastered in 20 Human Capital (Material Risk Taker Identification)', ESMA source) and enrichment/"
    "enrich_07.py line 84 (DERIVED from 20) lose their master; 07 retires at W4 (CW-013), so the W4 decision drops them. "
    "content_08_distribution_compliance.py lines 312, 594-595 (SM&CR Population, Certification Function) are replaced with 08 at W2.",
    "References to retiring or later-replaced domains left as they are (W2, W4): 07 Payroll Result.Incentive Payout Statements "
    "(Reference (Compensation Statement), CPS-) and the Payroll Run Type value 'Bonus / Incentive' description; overview Scope and "
    "Design principle 4 (07 sales incentive plans); REL rows 'Payroll Result pays Payroll Payment Instruction / Compensation Statement "
    "[07]'; Variable Award Type value 'Annual Cash Bonus' description (07 ICP-); 08 Background Screening.Related Individual Registration "
    "(Reference (Individual Registration), LIC-), REL rows 'Employee Lifecycle Event may trigger Registration Filing (Form U5) [08]', "
    "'Background Screening supports Individual Registration [08]' and 'CE Requirement [08] may reference Learning Completion'; 03 Sales "
    "Person profile (overview, Design principle 1, REL 'Employee is extended by Sales Person [03]'); 30 carry vehicle (Award "
    "Instrument value Carry Vehicle Interest, Linked Fund definition, REL 'Variable Compensation Award may be linked to Product [01]' "
    "note).",
    "W4 retirement candidates (private markets residue, not removed): Variable Award Type values Carried Interest Allocation and "
    "Co-Investment Entitlement, Award Instrument value Carry Vehicle Interest, Award Vesting Basis value Realization-Based, attribute "
    "Variable Compensation Award.Carried Interest Points ('Private markets only'). A Vanguard-type firm has no carried interest.",
    "Rename candidates for the lead (names kept under the name-continuity rule): Remuneration Committee Approval Date to "
    "'Compensation Committee Approval Date' (definition already reads 'compensation (remuneration) committee').",
    "Business lines: 20 holds no Business Line value. The Job Family value 'Distribution' keeps its name (firm job architecture); its "
    "description now reads 'Advice, sales, relationship management and client service'. Org unit examples OU-DIST-US-WEST are kept.",
    "Remaining hits of the step 1 grep, justified: overview Purpose line names the removed regimes ('EU/UK remuneration codes ..., "
    "SM&CR, UK and EU workforce reporting and GDPR were removed under CW-920'); 'Garden Leave' (Employment Status value, used by US "
    "firms); 'Redundancy / Reduction in Force' (termination reason label, kept; reduction in force is the US term); 'Pension Allowance' "
    "(generic cash in lieu value).",
    "Tailoring levers recorded in Source_Notes section 6: Diversity Collection Jurisdiction holds a country (a state may be the useful "
    "value in a US-only firm); Protected Veteran Status and Section 503 apply only to federal contractors; US worker classification "
    "(IRS common-law and state ABC tests) is not modeled in place of IR35; state pay transparency and pay data reports are not modeled.",
    "Unverified (marked confirm in Source_Notes): eCFR paths of SEC Rule 203A-3 and 29 CFR 1602.14; FINRA Rule 1220 sub-paragraph "
    "numbers on the Regulated Role Category values; the FTC FCRA page and the CPPA home page as citations; the Rule 3110(e) review of the "
    "prior Form U5.",
]
