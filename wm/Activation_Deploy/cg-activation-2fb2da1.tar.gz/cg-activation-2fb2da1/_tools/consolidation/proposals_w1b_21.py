"""W1b proposals of Data Domain 21 Data Governance & Analytics (wealth model; kept with the US-only and perspective pass and
the Business Line re-cut to CW-004). Brief: 00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (row 21); decisions
CW-003, CW-004, CW-022, CW-039; w1_merge_notes.md section 5 (Business Line examples in 21). Declarative only: the program
lead merges DECISIONS into decisions.py, appends JURISDICTION to jurisdiction.REMOVALS and applies SHARED_RECUTS to
shared_code_lists.py at merge (W5 for the shared lists, CW-039). The existing proposals_21.py (expansion) is unchanged.
"""

_D = "CW-921"


def _j(obj, attr, regime, note):
    return {"domain": "21", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


_AIA = "EU AI Act (Regulation (EU) 2024/1689; no EU AI Act entry in REGIMES)."

JURISDICTION = [
    # Attributes
    _j("AI Risk Classification", "EU AI Act Risk Category", "Other EU/UK",
       _AIA + " AI risk classification re-sourced to the NIST AI RMF: Internal AI Risk Tier and NIST AI RMF Profile stay; the CDE flag moves with the classification to Internal AI Risk Tier (already a CDE)."),
    _j("AI Risk Classification", "EU AI Act Operator Roles", "Other EU/UK", _AIA + " Provider or deployer roles have no US regime equivalent."),
    _j("AI Risk Classification", "Article 50 Transparency Obligations", "Other EU/UK", _AIA + " Client-facing AI disclosure is a firm policy and communications matter (FINRA Rule 2210, Advisers Act Rule 206(4)-1) outside 21."),
    _j("AI Risk Classification", "Fundamental Rights Impact Assessment Required Indicator", "Other EU/UK", _AIA + " Article 27 FRIA; no US equivalent."),
    _j("Data Classification Assignment", "GDPR Special Category Data Indicator", "GDPR / UK GDPR",
       "Removed as named (GDPR Articles 9 and 10); the attribute stays as 'Special Category Data Indicator', defined by the CD-344 special category tier with CCPA / CPRA as secondary reference."),
    # Code-list values: whole local lists removed with the attributes
    *[_j("Code list: AI Risk Category", v, "Other EU/UK", "Whole list removed with EU AI Act Risk Category.")
      for v in ("Prohibited Practice", "High Risk", "Transparency Obligations Only", "Minimal Risk", "Out of Scope")],
    *[_j("Code list: Article 50 Obligation", v, "Other EU/UK", "Whole list removed with Article 50 Transparency Obligations.")
      for v in ("AI Interaction Disclosure", "Synthetic Content Marking", "Emotion Recognition / Biometric Categorization Notice",
                "Deep Fake Disclosure", "Public-Interest Text Disclosure", "None")],
    *[_j("Code list: EU AI Act Operator Role", v, "Other EU/UK", "Whole list removed with EU AI Act Operator Roles.")
      for v in ("Provider", "Deployer", "Authorized Representative", "Importer", "Distributor", "Product Manufacturer", "Not Applicable")],
    # Code-list values: re-cut lists
    _j("Code list: CDE Regulatory Driver", "UCITS / PRIIPs KID", "PRIIPs", "EU / UK key information documents; no EU/UK range. US drivers added: CAT, Rules 17a-3 / 17a-4, 15c3-3, Reg BI."),
    _j("Code list: CDE Regulatory Driver", "EMIR / MiFIR Transaction Reporting", "MiFIR", "EMIR and MiFIR reporting; the US trade reporting drivers are 26's (CW-926) and CAT (SEC Rule 613) here."),
    _j("Code list: CDE Regulatory Driver", "AIFMD Annex IV", "AIFMD", "No AIFs; SEC Form PF stays."),
    _j("Code list: CDE Regulatory Driver", "FATCA / CRS Reporting", "CRS", "Relabeled 'FATCA Reporting' (chapter 4, Form 1042-S); the US does not report under the OECD CRS."),
    _j("Code list: Data Product Business Function", "EU / UK Cross-Border Distribution", "Other EU/UK",
       "FN-18; the data product framework keeps the FN-18 code with an empty capability list until WP0 (framework.py lines 24 and 131)."),
    _j("Code list: Contract Standard", "FinDatEx TPT", "FinDatEx", "Insurer look-through deliveries under Solvency II; no EU insurer clients."),
    _j("Code list: Metric Disclosure Framework", "ESRS S1", "Other EU/UK", "CSRD own-workforce standard (no CSRD entry in REGIMES); SEC Regulation S-K Item 101(c) and ISO 30414 stay."),
    # Sources
    _j("Sources", "Regulation (EU) 2024/1689 (Artificial Intelligence Act)", "Other EU/UK", "AI fields re-sourced to the NIST AI RMF and ISO/IEC 42001."),
    _j("Sources", "Ethics Guidelines for Trustworthy AI (European Commission High-Level Expert Group on AI)", "Other EU/UK",
       "Human Oversight Mode re-sourced to the NIST AI RMF (human-AI configuration and oversight)."),
    _j("Sources", "EU General Data Protection Regulation (Regulation (EU) 2016/679) and UK GDPR", "GDPR / UK GDPR",
       "Personal data fields re-sourced to SEC Regulation S-P (new source row) and the CCPA as amended by the CPRA."),
    _j("Sources", "FinDatEx Tripartite Template (TPT)", "FinDatEx", "Removed with the Contract Standard value."),
]

DECISIONS = [
    {"id": "CW-921", "theme": "Scope", "title": "US-only pass of 21 Data Governance & Analytics", "domains": ["21"],
     "issue": "The wholesale 21 classified AI use cases under the EU AI Act (risk category, operator roles, Article 50 obligations, FRIA "
              "flag and three local lists), sourced human oversight to the EU HLEG guidelines, named a GDPR special category indicator, "
              "cited GDPR on six personal data fields, and carried EU/UK values in CDE Regulatory Driver (UCITS / PRIIPs KID, EMIR / MiFIR, "
              "AIFMD Annex IV, CRS), Data Product Business Function (FN-18 EU / UK Cross-Border Distribution), Contract Standard (FinDatEx "
              "TPT) and Metric Disclosure Framework (ESRS S1). Its local Business Line list held the wholesale lines, its text described "
              "an asset manager with SMAs, private markets and insurance-dedicated funds and named '02 Client & Customer'.",
     "resolution": "1) Removed (34 JURISDICTION entries: Other EU/UK 26, GDPR / UK GDPR 2, FinDatEx 2, PRIIPs 1, MiFIR 1, AIFMD 1, CRS 1): "
                   "AI Risk Classification.EU AI Act Risk Category, EU AI Act Operator Roles, Article 50 Transparency Obligations, Fundamental "
                   "Rights Impact Assessment Required Indicator; local lists AI Risk Category (5 values), Article 50 Obligation (6), EU AI Act "
                   "Operator Role (7); Data Classification Assignment.GDPR Special Category Data Indicator as named (kept as 'Special Category "
                   "Data Indicator', CD-344, the one rename the brief directs); values CDE Regulatory Driver UCITS / PRIIPs KID, EMIR / MiFIR "
                   "Transaction Reporting, AIFMD Annex IV, FATCA / CRS Reporting (relabeled FATCA Reporting), Data Product Business Function EU / "
                   "UK Cross-Border Distribution, Contract Standard FinDatEx TPT, Metric Disclosure Framework ESRS S1; sources EU AI Act, EU HLEG "
                   "Ethics Guidelines, EU and UK GDPR, FinDatEx TPT. No object removed. "
                   "2) Re-sourced: AI Use Case Purpose, Human Oversight Mode (attribute and list), Uses General-Purpose AI Model Indicator, "
                   "Permitted AI Data Uses, the AI Technique value Rules-Based Automation and the Permitted AI Data Use alignment to the NIST AI "
                   "RMF (AI 100-1, AI 600-1) and ISO/IEC 42001; Assigned Personal Data Categories, Default Personal Data Categories, Personal "
                   "Data Category, Data Product Contains Personal Data and Personal Data Categories Used to SEC Regulation S-P (new source row) "
                   "with the CCPA / CPRA, Personal Data Sensitivity and its list values to the CPRA; CDE Regulatory Driver to the US set with "
                   "new values Form CRS, Consolidated Audit Trail (SEC Rule 613), Broker-Dealer Books and Records (SEC Rules 17a-3 and 17a-4), Customer "
                   "Protection Reserve (SEC Rule 15c3-3) and Regulation Best Interest (new source row; Form N-PORT already a value); FinDatEx TPT "
                   "and ESRS S1 secondary references removed. "
                   "3) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose (every CW-004 business line), Scope, "
                   "Notes (Regulation S-P and state privacy law), Suggested next steps 2 and 7; Provider Delivery and Providing Party examples "
                   "(CIT administrator and intermediary sponsor platform files instead of SMA sponsor files); Consumer External Party definition "
                   "and REL note; SUMMARY in enrich_21.py; Source_Notes status line, sources, design notes, unverified list, SME questions 10 and "
                   "12, next step 6 and section 6. "
                   "4) Business Line (CW-004): the local list (member of the shared list, steward 09) re-cut to DB, DA, HA, PF, WR, IA, IC, TR "
                   "with labels as descriptions; Mutual Fund, ETF, Collective Investment Trust, Separately Managed Account, Institutional Mandate "
                   "and Proprietary / Seed removed (not EU/UK; no JURISDICTION entry); Private Markets and Insurance-Dedicated Fund also removed in "
                   "the review fix pass (program-lead ruling: the local copy carries the eight CW-004 codes only; the shared list's None mapping is "
                   "a crosswalk record, not a value to keep; this overrides carryover_common step 5 for 21); Designation Business Lines example "
                   "'DB; HA'. Review fix pass, perspective: Special Category Data Indicator defined for every data subject per CD-344 (health and "
                   "disability, cognitive impairment and diminished capacity, FINRA Rule 2165 specified-adult, exploitation and hold data, financial "
                   "hardship, and the employee categories) with the restricted-view rule, secondary reference FINRA Rule 2165 (new source row); "
                   "metric and data product dimension examples re-cut to wealth 02 names (Party, Household, Client, Account, Business Line) instead "
                   "of Distributor Firm, Advisor, Territory and Distributor Hierarchy; Regulation Best Interest value re-described (Rule 15l-1) and "
                   "value Form CRS (Rule 17a-14, Rule 204-5) added. "
                   "5) Re-pointed: '02 Client & Customer' reads '02 Client & Household' (overview Scope, Release Scope Domains example, SUMMARY); "
                   "'01 Investment Product' reads '01 Investment Product & Service Offering' in that example. "
                   "6) Added: none (brief row 21) beyond the US CDE driver values and the two source rows the re-sourcing needs. "
                   "7) IDs: the attribute IDs of the AI & Model Data Governance family renumber from AI Risk Classification onward (four "
                   "attributes removed); the CDEs & Classification family keeps its IDs (the special category attribute is renamed in place). "
                   "Counts: 28 objects, 295 to 291 attributes, 92 to 91 CDEs (31.3%), 61 to 58 code lists, 24 to 23 sources, 51 relationships.",
     "rationale": "CW-003, CW-004 and CW-022: the wealth model is regulated in the US only, so EU AI Act, GDPR, EU/UK reporting and "
                  "distribution content leaves and the generic objects keep their US instance: the NIST AI RMF for AI risk, Regulation S-P "
                  "and state privacy law for personal data, and the reports and controls of a self-clearing broker-dealer and adviser for "
                  "CDE drivers. The Business Line re-cut follows CW-004 and the W1 merge note on 21. A UK extension restores the removed rows "
                  "from wholesale-v1.0.",
     "action": "W1b", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

SHARED_RECUTS = [
    ("Business Line", "09",
     "21 is a member: its local list now holds the eight CW-004 codes DB, DA, HA, PF, WR, IA, IC, TR only. Replace the 21 value map in "
     "shared_code_lists.py (_m('21', 'Business Line', ...), lines 1630-1635) with the identity map on the eight codes; none of the six "
     "wholesale values nor Institutional Mandate and Proprietary / Seed occur any more."),
    ("Business Domain", "09",
     "Labels lag domains.py: '01 Investment Product' should read '01 Investment Product & Service Offering' and '02 Client & Customer' "
     "'02 Client & Household' (CW-021); 21's Release Scope Domains example already uses the new labels."),
    ("Personal Data Category", "02",
     "Source alignment still reads 'GDPR / UK GDPR Art. 4, 9; CCPA / CPRA ...'; for the steward 02 at W5: 'SEC Regulation S-P; CCPA / "
     "CPRA Cal. Civ. Code 1798.140 personal information categories'. 21 cites the list unchanged."),
]

SHARED_CANDIDATES = []

NOTES = [
    "W1b (wealth), CW-921. Validation: taxonomy_builder.py content_21_data_governance_and_analytics OK (8 families, 28 objects, 291 "
    "attributes, 91 CDEs, 32 references, 0 derived, 0 unresolved, 58 code lists); before: 295 attributes, 92 CDEs, 61 code lists, 24 "
    "sources; after: 23 sources (review fix pass added FINRA Rule 2165). check_enrichment.py 21 OK.",
    "READERS of removed or renamed attributes (not edited; for the program lead's lineage pass): "
    "data_products/specs_e4_people_workplace_ai.py lines 1158-1166 (metrics Registered Use Cases, Unclassified Use Cases and Prohibited "
    "Practice Use Cases read EU AI Act Risk Category), line 1182 (GDPR Special Category Data Indicator), lines 1195-1197 (High-Risk "
    "Deployer Obligation Gaps reads EU AI Act Risk Category), lines 1202-1204 (FRIA Required Use Cases reads Fundamental Rights Impact "
    "Assessment Required Indicator and EU AI Act Operator Roles), lines 1209-1211 (21 input list: EU AI Act Risk Category, EU AI Act "
    "Operator Roles, Article 50 Transparency Obligations, Fundamental Rights Impact Assessment Required Indicator), line 1218 (GDPR "
    "Special Category Data Indicator) and line 1244 (quality rule: every live use case has an EU AI Act Risk Category); "
    "data_products/specs_e1_foundations.py lines 571-573 and 626 (Personal Data Elements metric and input list read GDPR Special "
    "Category Data Indicator; re-point to 'Special Category Data Indicator'); semantic_model/models/sm_17_technology_data_communications.py "
    "line 123 (gdpr_special_category), lines 363-365 and 369 (eu_ai_act_risk_category, eu_ai_act_operator_roles, "
    "article_50_transparency_obligations, fria_required); added in the review fix pass: the same file line 25 (model description), line 1460 "
    "(expression on gdpr_special_category), lines 1663, 1667 and 1669-1671 (measures and descriptions on eu_ai_act_risk_category and "
    "'Prohibited Practice'), line 1701 (Article 26 deployer controls), line 1707 (fria_required by eu_ai_act_operator_roles) and lines "
    "2288-2289 (question and answer by eu_ai_act_risk_category); data_products/specs_e4_people_workplace_ai.py lines 1136-1152 (DP "
    "definition and dimensions 'EU AI Act risk category and operator role'), 1179, 1239 and 1260-1262; "
    "data_models/models_e8c_people_workplace_ai.py line 911 (note: AI Risk Classification folds there, naming the EU AI Act). The removed "
    "Business Line values Private Markets and Insurance-Dedicated Fund are read by no product (the shared value map is the only record). Removed code values: data_products/framework.py "
    "keeps FN-18 (lines 24 and 131) and many products list it as a supporting function until WP0; the AIFMD Annex IV value is named in "
    "text by framework.py line 245, specs_e2_invops_a.py line 1369, specs_e3_ta_fund_governance.py lines 974 and 1308 and "
    "data_models/models_e8c_ta_fund_governance.py line 1095 (DP-186, 35's filings, CW-935).",
    "References to retiring or later-replaced domains left as they are: 08 Distribution Compliance (overview Scope 'records retention "
    "schedule (08 ...)', CDE Regulatory Driver note 'May later reference the 08 Regulatory Obligation', Object Records Retention Rule and "
    "Records Retention Rule notes '08 object Retention Rule (CD-062)', REL 'Object Governance Profile applies Retention Rule [08]', the "
    "Record Data Owner harmonization note naming 03, 05, 07, 08); 06, 10, 11, 12 in the overview Scope, Core model and SUMMARY (adapted "
    "at W4); 03 and 07 in the harmonization notes. Private markets: Contract Standard 'ILPA Reporting Template' and the ILPA source, "
    "Providing Party and Data Asset Type examples 'private fund administrator capital account files (PM)' (for the W4 retirement "
    "decision); the Business Line values Private Markets and Insurance-Dedicated Fund were removed in the review fix pass.",
    "Wholesale distribution examples left for WP0 (data product framework re-scope, not EU/UK): Data Product Business Function values "
    "FN-01 to FN-17 and FN-19 (wholesale functions retained by framework.py until WP0; the wealth functions FN-60 onward are not in the "
    "list); Owning Semantic Model example 'Distribution Performance'; flows-by-distributor descriptions; the "
    "distribution-v0.4 release in examples.",
    "Remaining hits of the step 1 grep, justified: 'EU' and 'UK' only in the removal notes of Source_Notes section 6 and in the shared "
    "Business Domain example; no other EU/UK hit remains in the module.",
    "Unverified: Colorado SB 24-205 as an example state AI law (confirm); eCFR paths of 17 CFR Part 248 Subpart A and 17 CFR 242.613 "
    "(confirm).",
    "Seen in other domains (not edited): 41 AI System Profile carries EU AI Act fields (CW-941) and the High-Risk Deployer Obligation "
    "Gaps metric joins it; 20 diversity and special-category data (CW-920) is the content behind the CD-344 tier.",
]
