"""W1b proposals of Data Domain 22 Market Data & Pricing (wealth model; kept with the US-only and perspective pass). Brief:
00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (row 22); decisions CW-003, CW-007, CW-022, CW-039. Declarative
only: the program lead merges DECISIONS into decisions.py and appends JURISDICTION to jurisdiction.REMOVALS at integration.
The existing proposals_22.py (expansion) is unchanged.
"""

_D = "CW-922"


def _j(obj, attr, regime, note):
    return {"domain": "22", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


JURISDICTION = [
    # Code-list values
    _j("Code list: Valuation Regulatory Framework", "AIFMD Article 19", "AIFMD",
       "No AIF range; valuation governance re-sourced to SEC Rule 2a-5 and Rule 31a-4 (and 12 CFR 9.18 for CITs)."),
    _j("Code list: Valuation Regulatory Framework", "UCITS Directive", "UCITS", "No UCITS range."),
    _j("Code list: Valuation Regulatory Framework", "FCA COLL", "FCA", "No UK authorized funds."),
    _j("Code list: Valuation Regulatory Framework", "ASC 820 / IFRS 13", "Other EU/UK",
       "Relabeled 'ASC 820': IFRS 13 served the financial statements of the EU/UK funds (EU- and UK-adopted IFRS); the US funds report under US GAAP."),
    _j("Code list: Valuation Committee Type", "AIFM Valuation Function", "AIFMD",
       "Functionally independent valuation function under AIFMD Art 19; the US committees are the Rule 2a-5 valuation designee committee and the CIT trustee committee."),
    _j("Code list: Valuation Committee Type", "ManCo Valuation Committee", "UCITS",
       "UCITS management company or UK ACD; no EU/UK funds."),
    # Sources
    _j("Sources", "AIFMD Article 19 and Commission Delegated Regulation (EU) No 231/2013 Articles 67-74", "AIFMD",
       "Six attribute references re-sourced to SEC Rule 2a-5 (primary) or 12 CFR 9.18 (secondary)."),
    _j("Sources", "UCITS Directive 2009/65/EC", "UCITS", "Removed with the Valuation Regulatory Framework value."),
    _j("Sources", "FCA Handbook COLL 6.3 (Valuation and pricing)", "FCA",
       "Was the secondary reference of Own Fund Swung Price; SEC Rule 22c-1 stays."),
    _j("Sources", "IFRS 13 Fair Value Measurement", "Other EU/UK",
       "Reporting basis of the EU/UK funds; ASC 820 stays the reference of the fair value hierarchy fields."),
    _j("Sources", "IAS 21 The Effects of Changes in Foreign Exchange Rates (part of the ASC 830 and IAS 21 row)", "Other EU/UK",
       "The row now reads FASB ASC 830 only; Period Rate cites ASC 830."),
    _j("Sources", "EU Benchmarks Regulation (EU) 2016/1011 and UK BMR", "BMR",
       "Rate Administrator re-sourced to Internal with the IOSCO Principles for Financial Benchmarks; the foreign reference rates and their administrators stay (investment universe)."),
]

DECISIONS = [
    {"id": "CW-922", "theme": "Scope", "title": "US-only pass of 22 Market Data & Pricing", "domains": ["22"],
     "issue": "The wholesale 22 valued EU/UK funds beside the US range: Valuation Regulatory Framework and Valuation Committee Type carried "
              "AIFMD, UCITS and FCA COLL values (AIFM valuation function, ManCo valuation committee); six valuation governance attributes cited "
              "AIFMD Article 19; Own Fund Swung Price cited FCA COLL 6.3; the fair value hierarchy fields cited IFRS 13 and Period Rate IAS 21 "
              "(the reporting basis of the EU/UK funds); Rate Administrator cited the EU and UK Benchmarks Regulations. Its text described an "
              "asset manager with SMAs, private markets and insurance-dedicated funds, cited GDPR and named '02 Client & Customer'.",
     "resolution": "1) Removed (12 JURISDICTION entries: Other EU/UK 3, AIFMD 3, UCITS 3, FCA 2, BMR 1): Valuation Regulatory Framework values "
                   "AIFMD Article 19, UCITS Directive, FCA COLL, and 'ASC 820 / IFRS 13' relabeled 'ASC 820'; Valuation Committee Type values AIFM "
                   "Valuation Function and ManCo Valuation Committee; sources AIFMD Art 19 with Delegated Regulation 231/2013, UCITS Directive, FCA "
                   "COLL 6.3, IFRS 13, IAS 21 (row retitled to ASC 830), EU and UK BMR. No object or attribute removed. "
                   "2) Re-sourced: valuation governance to SEC Rule 2a-5 and Rule 31a-4, with 12 CFR 9.18 for the CITs (Policy Owner Entity, "
                   "Committee Owner Entity and Valuation Committee Type secondary 12 CFR 9.18; Outsourced Pricing Provider, Portfolio Management "
                   "Function Indicator and External Valuation Agent primary SEC Rule 2a-5; list Valuation Committee Type alignment); Own Fund "
                   "Swung Price to SEC Rule 22c-1 alone; Approved Price Fair Value Level (secondary SEC Form N-PORT), Fair Value Hierarchy Level "
                   "and Unobservable Input Indicator to ASC 820 alone, list Fair Value Hierarchy Level to ASC 820 and the NAV Practical "
                   "Expedient description reworded; Period Rate, Rate Period Start, Rate Period End and the FX Rate Basis list alignment to ASC 830 alone (the last three in the review fix pass); Rate Administrator to Internal with the IOSCO Principles for "
                   "Financial Benchmarks (new source row). "
                   "3) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose, Scope, Core model and Notes (US privacy "
                   "law); family text of Fair Value & Valuation Governance; definitions of Policy Owner Entity, Policy Approval Status, Committee "
                   "Owner Entity, Portfolio Management Function Indicator and Valuation Committee Name; the NBBO notes on ETF Market Statistic "
                   "(own ETFs are US-listed); descriptions of Fund NAV Valuation Point, SMA Month-End Valuation (relabeled 'Institutional Separate Account "
                   "Month-End Valuation' in the review fix pass), Sponsor or Client Priced and Contract Value (insurance-dedicated funds no longer named); REL note on Pricing "
                   "Policy ownership; SUMMARY in enrich_22.py; Source_Notes status line, rationale paragraph, source table, unverified list, SME "
                   "questions 2 and 3 and section 7. "
                   "4) Re-pointed: '02 Client & Customer' reads '02 Client & Household' and '01 Investment Product' reads '01 Investment Product & Service Offering' (overview Scope, SUMMARY); the client book of record (49) "
                   "named as a reader of approved prices beside 18 (CW-007). "
                   "5) Added: none (brief row 22; reference rates and FX sources stay), beyond the IOSCO benchmarks source row and, in the review "
                   "fix pass, the Valuation Committee Type value 'Board (no valuation designee)' (Rule 2a-5 lets the board determine fair value "
                   "itself); 'Client Holdings (49)' named as in CW-007 in the Purpose and SUMMARY. "
                   "6) IDs: no attribute removed, so no attribute ID changes. Counts: 31 objects, 269 attributes, 85 CDEs (31.6%) and 40 code "
                   "lists unchanged; 31 to 27 sources; 52 relationships.",
     "rationale": "CW-003 and CW-022: the wealth model is regulated and distributes in the US only, so EU/UK valuation regimes and the "
                  "reporting basis of EU/UK funds leave; its international funds still hold foreign instruments, so foreign markets, reference "
                  "rates, FX fixes, indices and their administrators stay. The US instance of valuation governance is SEC Rule 2a-5 and Rule "
                  "31a-4 for the registered funds and 12 CFR 9.18 for the CITs. A UK extension restores the removed rows from wholesale-v1.0.",
     "action": "W1b", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

# 22 stewards no shared list whose values change. Its local lists Valuation Regulatory Framework and Valuation Committee Type
# were re-cut in the module (above).
SHARED_RECUTS = []

SHARED_CANDIDATES = []

NOTES = [
    "W1b (wealth), CW-922. Validation: taxonomy_builder.py content_22_market_data_and_pricing OK (8 families, 31 objects, 269 attributes, "
    "85 CDEs, 55 references, 6 derived, 0 unresolved, 40 code lists), unchanged from before except sources (31 to 27); check_enrichment.py 22 OK.",
    "READERS: no attribute or object was removed. grep of data_products/*.py, data_models/*.py and semantic_model/models/*.py finds no reader "
    "of the removed code values (AIFMD Article 19, UCITS Directive, FCA COLL, ASC 820 / IFRS 13, AIFM Valuation Function, ManCo Valuation "
    "Committee). The value 'SMA Month-End Valuation' was relabeled 'Institutional Separate Account Month-End Valuation' in the review fix "
    "pass; its text reader data_products/specs_e1_book_of_record.py line 355 (portfolio business line convention) is to be updated at merge.",
    "References to retiring domains left as they are (W4, retirement of 30): overview Scope '30 Private Markets references fair value "
    "determinations'; Design principles 2 'Every consumer (18, 25, 26, 27, 30)'; Suggested next steps 5 'Agree with 30 ...'; Valuation "
    "Input.Input Value note '30 Portfolio Company Financial Metric'; REL 'Approved Price is referenced by ... private markets (30)' and 'Fair "
    "Value Determination is referenced by Private Investment and fund interest records (30)'. Private-asset content that serves 30 only, "
    "candidates for the W4 decision: Private Asset Valuation Detail (and its grain), Pricing Point Purpose 'Private Asset Quarter-End', "
    "Price Origin 'GP Statement', Fair Value Determination Reason 'Periodic Private Asset Valuation', Back-Test Comparison Types "
    "'Subsequent Financing Round' and 'Exit Realization', the IPEV source and the 'PRIVMKT-QTR-END' example. The Valued Portfolio rule for "
    "private fund interests stays while 18 holds fund interests. Contract Value (stable value) stays for CITs.",
    "Remaining hits of the step 1 grep, justified (investment universe, CW-022): SONIA, EUR STR, EURIBOR, UK RPI, HICP and HICPxT; Bank of "
    "England, ECB and EMMI sources; 'Bank of England SONIA' as the secondary reference of Fixing Value; the list Fixing Value Type alignment "
    "naming the Bank of England and ONS. The Source_Notes review-history rows (section 2 review table) still name UCITS ETF listings and FCA "
    "COLL as the record of the wholesale review.",
    "Unverified: IOSCO Principles for Financial Benchmarks URL (IOSCOPD415) and the FASB ASC 830 topic page (confirm in Source_Notes).",
    "Seen in other domains (not edited): 27 Swing Pricing Decision and Dilution Levy fields (CW-927, W1b editor 2); 35 board oversight of "
    "valuation cites COLL (CW-935).",
]
