"""W1b proposals of Data Domain 23 Investment Research (wealth model; kept with the US-only and perspective pass). Brief:
00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (row 23); decisions CW-003, CW-022, CW-039. Declarative only: the
program lead merges DECISIONS into decisions.py and appends JURISDICTION to jurisdiction.REMOVALS at integration. The
existing proposals_23.py (expansion) is unchanged.
"""

_D = "CW-923"


def _j(obj, attr, regime, note):
    return {"domain": "23", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


# ---------------------------------------------------------------------------------------------------------------------
# Jurisdiction register entries (jurisdiction.REMOVALS format). Objects and attributes use the wholesale-v1.0 names.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = [
    # Publication Review.Investment Recommendation Disclosure Indicator is kept, re-sourced to FINRA Rules 2241 and 2210 (review fix
    # pass, program-lead ruling): no JURISDICTION entry.
    _j("Code list: Corporate Access Charge Basis", "Minor Non-Monetary Benefit", "MiFID II",
       "MiFID II inducement exemption (Delegated Directive (EU) 2017/593 Art 12); corporate access is No Charge, Paid Separately or Included in Research Service under Section 28(e)."),
    _j("Sources", "Commission Delegated Directive (EU) 2017/593, Art 12-13, read with Directive 2014/65/EU (MiFID II) Art 24", "MiFID II",
       "Research payment and evaluation fields re-sourced to Exchange Act Section 28(e) (SEC Release 34-54165)."),
    _j("Sources", "Directive (EU) 2024/2811 (Listing Act amendment of MiFID II Art 24, joint payment)", "MiFID II",
       "Joint payment option; no US equivalent beyond Section 28(e) commission sharing (25)."),
    _j("Sources", "FCA Handbook COBS 2.3B and Policy Statement PS24/9 (payment optionality for investment research)", "FCA",
       "Re-sourced to Section 28(e)."),
    _j("Sources", "Regulation (EU) No 596/2014 (Market Abuse Regulation), Art 7, 11 and 20", "Other EU/UK",
       "MAR (no MAR entry in REGIMES). Wall-crossing and MNPI fields re-sourced to Advisers Act Section 204A with FINRA Rule 3110(d)."),
    _j("Sources", "Commission Delegated Regulation (EU) 2016/958 (objective presentation of investment recommendations)", "Other EU/UK",
       "MAR delegated act. Recommendation fields cite FINRA Rule 2241 as the sell-side reference point or Internal."),
    _j("Sources", "Commission Delegated Regulation (EU) 2016/960 (market soundings) and ESMA Guidelines ESMA/2016/1477", "Other EU/UK",
       "MAR delegated act and ESMA guidelines. Wall crossing re-sourced to Advisers Act Section 204A policies and FINRA Rule 3110(d)."),
    _j("Sources", "UK Stewardship Code 2026", "UK Stewardship Code",
       "Stewardship Objective Indicator reads Internal; the hand-off to 34 Engagement stays."),
]

# ---------------------------------------------------------------------------------------------------------------------
# Decision of the US-only pass of 23 (decisions.DECISIONS format)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-923", "theme": "Scope", "title": "US-only pass of 23 Investment Research", "domains": ["23"],
     "issue": "The wholesale 23 cited EU and UK research and market abuse rules throughout: the MiFID II inducement rules on research "
              "(Delegated Directive 2017/593, Directive 2024/2811, FCA COBS 2.3B and PS24/9) on the provider, consumption and evaluation records; "
              "EU MAR and its delegated acts (2016/958, 2016/960 and the ESMA market soundings guidelines) on recommendations, wall crossing and "
              "MNPI; a MAR Article 20 basis for the disclosure flag on Publication Review; the MiFID minor non-monetary benefit as a corporate access value; "
              "the UK Stewardship Code on the stewardship flag. Its text described an asset manager with SMAs, private markets and "
              "insurance-dedicated funds, cited GDPR for personal data and named '02 Client & Customer'.",
     "resolution": "1) Removed (8 JURISDICTION entries: Other EU/UK 3, MiFID II 3, FCA 1, UK Stewardship Code 1): Corporate Access Charge Basis value Minor Non-Monetary Benefit; sources Delegated "
                   "Directive (EU) 2017/593, Directive (EU) 2024/2811, FCA COBS 2.3B and PS24/9, EU MAR, Delegated Regulations (EU) 2016/958 and "
                   "2016/960 with the ESMA guidelines, UK Stewardship Code 2026. No object or attribute removed: Publication Review.Investment Recommendation Disclosure Indicator is kept and re-sourced to FINRA Rules 2241 and 2210 (review fix pass, program-lead ruling; redefined as the required research report and retail communication disclosures where the affiliated broker-dealer distributes the research to clients; new source row FINRA Rule 2210). "
                   "2) Re-sourced: Corporate Access Charge Basis, Subscribed Service Type, Research Interaction Type, Overall Evaluation Score "
                   "and Evaluation Criterion to Exchange Act Section 28(e) (SEC Release 34-54165), with the source alignment of the lists "
                   "Corporate Access Charge Basis, Research Provider Type and Evaluation Criterion; Evaluation Period End Date to Internal; "
                   "Meeting Start Timestamp, Wall-Crossing Consent Indicator and Wall-Crossing Timestamp to Advisers Act Section 204A alone and MNPI "
                   "Received Indicator to Section 204A with FINRA Rule 3110(d) (new source row; 3110(d) covers transaction review for insider "
                   "trading, not wall-crossing records, review fix pass); Recommendation Change Type, "
                   "Valuation Method and Key Risks to FINRA Rule 2241 (Recommendation Horizon Months to Internal: Rule 2241 sets no horizon) as the sell-side reference point, and Previous Recommendation, Price Target "
                   "(secondary), Recommendation Timestamp, Price at Recommendation, Key Assumptions, Publication Timestamp, External Release "
                   "Indicator and External Release Date to Internal; list Recommendation Change Type to FINRA Rule 2241; Stewardship Objective "
                   "Indicator to Internal. "
                   "3) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose (investment management arm of a US "
                   "direct wealth manager: proprietary funds, advice model portfolios, institutional separate accounts; lines PF, DA, HA, IA; "
                   "sub-advised funds use the sub-adviser's research), Scope, CDE, Notes (US privacy law: state laws such as CCPA/CPRA, "
                   "Regulation S-P where the individual is a client) and Suggested next steps item 5; SUMMARY in enrich_23.py; Source_Notes "
                   "perspective lines, source table, SME questions 9 and 11 and section 6. "
                   "4) Re-pointed: '02 Client & Customer' reads '02 Client & Household' and '01 Investment Product' reads '01 Investment Product & Service Offering' (overview Scope, SUMMARY); references to Party "
                   "resolve unchanged (CW-021). "
                   "5) Added: none (brief row 23), beyond the FINRA Rule 3110(d) and FINRA Rule 2210 source rows. "
                   "6) IDs: no attribute removed (the disclosure flag is restored in its place, last in RS-PUB), so no attribute ID changes. "
                   " Counts: 23 objects, 202 attributes, 63 CDEs (31.2%) and 31 code lists unchanged, 16 to 11 "
                   "sources, 43 relationships.",
     "rationale": "CW-003 and CW-022: the wealth model is regulated and distributes in the US only. Research on foreign issuers, countries "
                  "and rates markets stays (investment universe); only EU/UK regime content leaves. The US rules that govern the same "
                  "facts are Section 28(e) for research paid with client commissions, Advisers Act Section 204A and FINRA Rule 3110(d) for "
                  "MNPI, and FINRA Rule 2241 as the sell-side reference for ratings and price targets. A UK extension restores the removed "
                  "rows from wholesale-v1.0 through the jurisdiction register.",
     "action": "W1b", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

# 23 stewards no shared list whose values change; it cites Record Status, Approval Status, Period Type, Sentiment, Information
# Classification and Credit Outlook unchanged.
SHARED_RECUTS = []

SHARED_CANDIDATES = []

NOTES = [
    "W1b (wealth), CW-923, after the review fix pass. Validation: taxonomy_builder.py content_23_investment_research OK (6 families, "
    "23 objects, 202 attributes, 63 CDEs, 60 references, 1 derived, 0 unresolved, 31 code lists); before: 202 attributes, 63 CDEs, 31 "
    "code lists, 16 sources; after: 11 sources. check_enrichment.py 23 OK.",
    "READERS: no object or attribute is removed. Publication Review.Investment Recommendation Disclosure Indicator stays (re-sourced), so "
    "its readers data_products/specs_e2_research_trading.py line 160 and semantic_model/models/sm_09_research_trading_operations.py line "
    "821 keep resolving; their wording may need the US disclosure meaning. The removed value Minor Non-Monetary Benefit has no reader.",
    "References to retiring or later-replaced domains left as they are: REL 'Research Publication may be cited by Due Diligence Workstream "
    "[30]' (W4, retirement of 30); overview Purpose 'sales activity (03)' and the Issuer Meetings family text and REL note 'Never a 03 Sales "
    "Activity' (03 replaced at W4); Source_Notes SME question 7 (private-company research outside 30 deal due diligence).",
    "Remaining hits of the step 1 grep, justified: 'non-GAAP or non-IFRS' on Adjusted Basis Indicator (foreign issuers' reporting basis); "
    "'core HICP for the euro area' on the Economic Indicator list and 'euro area' on Forecast Geography (investment universe); the "
    "Source_Notes section 6 text that names the removed sources.",
    "Unverified: FINRA Rule 3110 rulebook URL and paragraph (d), and FINRA Rule 2210 as the communications rule for research released to clients (marked confirm in Source_Notes).",
    "Seen in other domains (not edited): 25 Research Budget and Commission Sharing Arrangement carry the MiFID research payment account and "
    "joint payment fields (W1b editor 2, CW-925); 34 Engagement cites the UK Stewardship Code (CW-934).",
]
