"""W1b proposals of Data Domain 25 Portfolio Trading & Execution (wholesale name Trading & Execution; wealth model; kept
with the US-only and perspective pass and renamed). Brief: 00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (25);
decisions CW-003, CW-010, CW-021, CW-022, CW-039; plan section 5.1 row 25. Declarative only: the program lead merges
DECISIONS into decisions.py, appends JURISDICTION to jurisdiction.REMOVALS, applies the rename in domains.py and applies
SHARED_RECUTS to shared_code_lists.py at merge (W5 for the shared lists, CW-039). The existing proposals_25.py
(expansion) is unchanged.
"""

_D = "CW-925"


def _j(obj, attr, regime, note):
    return {"domain": "25", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


# ---------------------------------------------------------------------------------------------------------------------
# Jurisdiction register entries (jurisdiction.REMOVALS format). Objects and attributes use the wholesale-v1.0 names.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = [
    # Object
    _j("MiFIR Transaction Report", "", "MiFIR",
       "Whole object (11 attributes: Transaction Reference Number, Aggregated Market-Side Report Indicator, Reported Block Order, Reported Trade Allocation, Transmission Conditions Met Indicator, Reporting Legal Entity, Approved Reporting Mechanism, Receiving Competent Authority, Investment Decision Maker, Execution Decision Maker, Transaction Report Status) and its object group Transaction Reports: MiFIR Article 26 and RTS 22 transaction reporting; no EU/UK investment firm. No US instance in 25: an adviser does not report its portfolio trades; CAT reporting falls on the broker-dealer and is 48 for client orders (CW-010); large trader identification stays as Large Trader ID (SEC Rule 13h-1)."),
    # Attributes
    _j("Research Budget", "Research Payment Account Indicator", "MiFID II",
       "MiFID II research payment account (Delegated Directive 2017/593 Art 13); US research is paid from own resources or Section 28(e) commission sharing."),
    _j("Research Budget", "Client Research Charge Rate", "MiFID II",
       "Client research charge funding a MiFID II research payment account; removed with the indicator."),
    _j("Commission Sharing Arrangement", "Joint Payment Indicator", "MiFID II",
       "EU joint payment option (Directive (EU) 2024/2811) and the UK equivalent (FCA PS24/9, COBS 2.3B); Section 28(e) Safe Harbor Indicator stays as the US instance."),
    # Code lists
    *[_j("Code list: Transaction Report Status", v, "MiFIR",
         "Whole local list removed with MiFIR Transaction Report; 25 was the steward member of the shared Regulatory Report Status (SHARED_RECUTS).")
      for v in ("Pending", "Submitted", "Accepted", "Rejected", "Corrected", "Canceled")],
    _j("Code list: Cross Trade Basis", "Firm Conflicts Policy (EU / UK funds)", "Other EU/UK",
       "Crosses of EU/UK funds under a conflicts policy (no specific cross trade rule); US crosses are SEC Rule 17a-7 or ERISA Section 408(b)(19)."),
    _j("Code list: Research Payment Source", "Research Payment Account", "MiFID II",
       "Funded by a client research charge (MiFID II); the remaining values are Own Resources and Commission Sharing Arrangement (Section 28(e))."),
    # Sources
    _j("Sources", "MiFID II Directive 2014/65/EU, Article 27 (best execution)", "MiFID II",
       "Best Execution Policy and Execution Factor re-sourced to SEC Release IA-5248 (adviser duty of best execution) and FINRA Rule 5310."),
    _j("Sources", "Commission Delegated Regulation (EU) 2017/565, Articles 64-65 (best execution for portfolio managers) and Article 50 (costs and charges)", "MiFID II",
       "Re-sourced as above; Execution Factor Priority and Approved Execution Venues no longer cite it."),
    _j("Sources", "Directive (EU) 2024/790 (MiFID II review, removal of RTS 27 / RTS 28 reports) and FCA PS21/20 (UK removal of RTS 27 / RTS 28)", "MiFID II",
       "Scope note only (no RTS 28 object); no longer needed."),
    _j("Sources", "MiFIR Regulation (EU) No 600/2014, Article 26 (transaction reporting)", "MiFIR", "Removed with MiFIR Transaction Report."),
    _j("Sources", "Commission Delegated Regulation (EU) 2017/590 (RTS 22)", "MiFIR", "Removed with MiFIR Transaction Report."),
    _j("Sources", "Commission Delegated Directive (EU) 2017/593, Article 13 (inducements in relation to research), as amended by Directive (EU) 2024/2811", "MiFID II",
       "Research Budget re-sourced to Internal and Exchange Act Section 28(e); Research Payment Component and Research Payment Source to Section 28(e)."),
    _j("Sources", "FCA PS24/9 Payment optionality for investment research; FCA Handbook COBS 2.3B", "FCA",
       "Removed with Joint Payment Indicator; Research Credit Balance cites Section 28(e) alone."),
]

# ---------------------------------------------------------------------------------------------------------------------
# Decision of the US-only pass of 25 (decisions.DECISIONS format)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-925", "theme": "Scope", "title": "US-only pass of 25 Portfolio Trading & Execution (renamed from Trading & Execution)",
     "domains": ["25", "18", "24", "28", "46", "48"],
     "issue": "The wholesale 25 carried a MiFIR Transaction Report business object (RTS 22 fields, ARM, competent authority with the example FCA, a removed shared Regulator value), the MiFID II research payment account (Research Payment Account Indicator, Client Research Charge Rate, the Research Payment Source value Research Payment Account), the EU and UK joint payment option (Joint Payment Indicator), a cross trade basis for EU/UK funds, MiFID II best execution sources on the Best Execution Policy and Execution Factor list, and MiFID / MiFIR cross-references on order, execution and cost attributes. Its text described the trading desk of a wholesale asset manager with SMA accounts and did not separate portfolio orders from the client orders of a brokerage (CW-010).",
     "resolution": "1) Removed (19 JURISDICTION entries: MiFIR 9, MiFID II 8, FCA 1, Other EU/UK 1): object MiFIR Transaction Report (11 attributes) with its object group, relationship, grain and Derived copy (24) rows; Research Budget.Research Payment Account Indicator and Client Research Charge Rate; Commission Sharing Arrangement.Joint Payment Indicator; local list Transaction Report Status (6 values); Cross Trade Basis value Firm Conflicts Policy (EU / UK funds); Research Payment Source value Research Payment Account; sources MiFID II Art 27, Delegated Regulation 2017/565 Art 64-65 and 50, Directive 2024/790 with FCA PS21/20, MiFIR Art 26, RTS 22, Delegated Directive 2017/593 Art 13 with Directive 2024/2811, FCA PS24/9 and COBS 2.3B. "
                   "2) Re-sourced: Best Execution Policy (Policy Legal Entity, Execution Factor Priority, Reviewed Policy) and the Execution Factor list to the adviser's duty of best execution under Advisers Act Section 206 (SEC Release IA-5248) and FINRA Rule 5310 for the affiliated broker-dealer (two new source rows); Policy Asset Class, Approved Execution Venues and Explicit Cost bps to Internal; Research Budget's four remaining attributes to Internal and Exchange Act Section 28(e) (examples USD and LEN-0004); Research Payment Source and Research Payment Component to Section 28(e); Commission Amount, Exchange and Clearing Fee Amount and Transaction Tax Amount to the FIX Protocol; MiFIR / MiFID cross-references on Originating Investment Decision, Order Originator, Trading Legal Entity, Block Trader, Execution Strategy, Execution Timestamp and Execution Venue to Advisers Act Rule 204-2, SEC Rule 31a-1, SEC Form ADV, FIX or nothing. Cross trades stay on Rule 17a-7 (and ERISA 408(b)(19) for plan assets). "
                   "3a) Sponsor and wrap program accounts (program lead ruling at the W1b fix pass): Directed Broker note, Trade-Away Indicator, Trade Rotation Program and the Order Reason value Model Change read as sponsor program accounts the firm manages inside third-party wrap or model programs (intermediary channel, IC line); 'institutional separate account' is kept for the firm's own institutional mandates (IA line); Trading Legal Entity is the firm's adviser entity, and orders of external sub-advisers are not held here (52). 3) Rename and boundary (CW-010): META title and subtitle read Portfolio Trading & Execution (domains.py at merge; output path and folder unchanged); the overview states that fund and institutional portfolio orders are mastered here and client orders, routing, executions, allocations to client accounts, confirmations, Rule 605 / 606 disclosure and CAT reporting are 48, including retail managed account rebalancing orders (46); Design principle 1 names 48 client orders. "
                   "4) Perspective: overview Purpose, Scope, Core model, Applies To, Notes (Regulation S-P, GLBA and state law in place of GDPR) and Suggested next step 6; family texts of Order Management, Allocation, Commissions & Research Payments and Best Execution & TCA; 'SMA account' reads 'institutional separate account' (IA line) in the two PII note constants, Allocated, Indicating, Receiving and Certified Account, Directed Broker, Trade-Away Indicator, Trade Rotation Program and the Order Reason value Model Change; 02 named Client & Household (party core); enrich_25 docstring, SUMMARY and four grain texts. Reference (Party) and Reference (Account) are unchanged and resolve (CW-021). The Regulator example FCA left with the removed object; 25 holds no other Regulator value. "
                   "5) Additions: none (rename only). Object and attribute names unchanged; attribute positions renumber in the families Allocation and Commissions & Research Payments. "
                   "6) Kept on purpose (CW-022): foreign venues and brokers, FX orders and fills, the WM/Reuters fix, Hedged Share Class, foreign transaction taxes. Counts: 31 to 30 objects, 280 to 266 attributes, 84 to 84 CDEs (31.6%), 37 to 35 code lists (28 to 27 local), 24 to 19 sources, 44 to 43 relationships, 63 to 60 references, 5 to 4 derived.",
     "rationale": "CW-003 and CW-022: the firm's advisers and funds are regulated in the US, so MiFIR reporting, the MiFID research payment account, the joint payment option and the MiFID best execution regime have no US instance, while the generic best execution, research payment and cross trade objects keep their US rules. CW-010 separates portfolio orders (25) from client orders (48): different regulation, systems and grain, and different prefixes. Names are kept so that DP-122, DP-123, DP-124, DP-125 and SM-09 keep resolving; the removed object and attributes are read by DP-122, DP-125, keys_e7_25_26, models_e8c and SM-09 (NOTES). Lever: a UK extension restores the removed rows from wholesale-v1.0 through the jurisdiction register.",
     "action": "W1b", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# Shared list re-cuts (25 is steward of Order Side and Regulatory Report Status)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_RECUTS = [
    ("Regulatory Report Status", "25",
     "25 no longer holds a member list (Transaction Report Status left with MiFIR Transaction Report). The remaining member is 28 Loan Report Status (Rule 10c-1a securities loan reporting): move the steward to 28 (or 26 if 26 takes a trade report status, see proposals_w1b_26), drop the 25 value map, and change the source 'Internal / MiFIR / SFTR' to 'Internal / SEC Rule 10c-1a / CFTC Part 45'. The definition's 'ARM' wording goes."),
]

SHARED_CANDIDATES = []

# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "W1b (wealth), CW-925. Validation: taxonomy_builder.py content_25_trading_and_execution OK (7 families, 30 objects (2 attribute groups, 0 without grain), 266 attributes, 84 CDEs, 60 references, 4 derived, 0 unresolved, 35 code lists); before: 31 objects, 280 attributes, 84 CDEs, 63 references, 5 derived, 37 code lists. check_enrichment.py 25 OK.",
    "Rename: domains.py DD_NAMES['25'] is still 'Trading & Execution' (DISPOSITION carries the target 'Portfolio Trading & Execution'). As instructed, META title and subtitle and the module docstring already use the new name; the program lead applies DD_NAMES at merge. Output path and folder 25_Trading_and_Execution unchanged. The 18, 26 and 27 W1b texts use the new name.",
    "READERS of the removed object and attributes (not edited): "
    "data_products/specs_e2_research_trading.py DP-122 inputs line 744 (Commission Sharing Arrangement: Joint Payment Indicator) and line 748 (Research Budget: Research Payment Account Indicator, Client Research Charge Rate), DP-122 text lines 705 and 798-801 (research payment accounts, RPA balances, joint payment option); "
    "DP-125 metrics 'Unreported MiFIR Transactions' (lines 1217-1225), 'Rejected MiFIR Reports Open' (lines 1226-1230) and 'MiFIR Decision Maker Mismatches' (lines 1231-1236), DP-125 inputs lines 1260-1264 (the whole MiFIR Transaction Report object), quality rule line 1297, notes lines 1314 and 1318 (which already say the object retires when 25 is re-cut); "
    "data_models/keys_e7_25_26.py line 60 (MiFIR Transaction Report key) and lines 212-216 (its reference keys), line 371 (comment naming Investment Decision Maker ->24); "
    "data_models/models_e8c_research_trading.py lines 797-800 (entity Fact MiFIR Transaction Report), lines 875-879 (its relationships) and line 897 (model gap note naming the MiFIR Execution Decision Maker); "
    "semantic_model/models/sm_09_research_trading_operations.py lines 72 (joint_payment), 90-91 (research_payment_account, client_research_charge_rate), 312-320 (mifir_report entity), 1092-1097 (its joins), 1653-1666 (the three MiFIR measures) and 1451-1454 (measure text 'research payment accounts'); line 215 (hidden note naming MiFIR Decision Maker Mismatches). "
    "Also (W1b fix pass, review D): DP-125 description and questions (specs_e2_research_trading.py lines 1122, 1131, 1134), timeliness (line 1287, MiFIR reports due by close of T+1), notes (line 1300) and SME-question notes (lines 1310-1311); data_models/models_e8c_research_trading.py notes line 775 (MiFIR control fact) and line 841 (Trading and MiFIR reporting entity); semantic_model/models/sm_09_research_trading_operations.py line 2319 (rows note naming MiFIR reports) and line 2364 (gap note GAP-25-003, research payment account). Readers outside 25 whose purpose was the removed report, to retire with it: DP-126 measure 'MiFIR Decision Maker Completeness %' (data_products/specs_e2_portfolio_stewardship.py lines 11, 14, 20, 74 and 127), data_models/models_e8c_portfolio_stewardship.py line 101 (measure note), semantic_model/models/sm_08_investment_book_performance.py line 472 (hidden note) and lines 1708-1713 (the measure); data_products/specs_e1_masters.py line 964 (question on algorithm codes for MiFIR transaction reports). "
    "Gap register: consolidation/gaps_register.py GAP-25-003 'No research payment account balance object' (line 3228) lapses with the research payment account. Shared lists: consolidation/shared_code_lists.py lines 2445-2462 (Regulatory Report Status; SHARED_RECUTS). Generated outputs refresh on rebuild.",
    "Readers of re-sourced attributes are unaffected (names unchanged): DP-122 to DP-124 read Best Execution Policy, Research Budget, Research Payment and Allocation Cost Detail by name.",
    "References to later-stage domains left as they are: Trade Rotation Program (Reference (Agreement), 05, replaced at W4) and the relationship 'trade rotation keyed to Distribution Agreement [05]'; Related Transition Event (12, adapted at W4); Overview Scope names 05 for sponsor and consultant program agreements and 05 'Trading Setup' as a different concept. No reference to 30 or 07.",
    "Rename-related: 18 Portfolio Transaction.Source Allocation ID and 26 references to ALLOC- keep resolving (TORD-, BLOCK-, EXEC-, ALLOC-, TCA- unchanged). 48 (W3) will need its own order, execution and allocation prefixes distinct from these (CW-010 'the prefixes differ').",
    "Remaining hits of the step 1 grep, justified: 'SMA' and 'SMAP' are the names of the two PII note constants (their text now reads institutional separate account); 'wrap' in Trade-Away Indicator and the Form ADV source (sponsor and wrap programs of institutional separate accounts); XLON in the approved venue example and EUR/USD FX examples (investment universe); 'Section 31' (US fee).",
    "Tailoring levers recorded for the program lead (not added): Section 17(e) and Rule 17e-1 commissions paid to an affiliated broker-dealer would apply if the affiliated broker executes fund trades (SME question 1 in Source_Notes section 7); Hedged Share Class and the Order Reason 'Share Class Hedge' are a UCITS-style feature rare in US funds, kept as generic.",
    "Other domains' content seen: 24 Investment Decision keeps Decision Maker and Decision Algorithm Code, which no longer feed a MiFIR report (24 is adapted at W2); 38 Entity Authorization type 'SEC Large Trader (Form 13H)' still feeds Large Trader ID.",
    "Unverified: SEC Release IA-5248 URL; FINRA Rule 5310 URL (rulebook pattern); the mapping of the Execution Factor values to FINRA 5310(a)(1) is by analogy. All marked confirm in Source_Notes section 7.",
    "W1b fix pass (review 00_Program/Rework/Reviews/W1b_18_25_26_27_review.md): both Mediums applied (sponsor program wording per ruling 1; READERS completed per ruling 2). Lows applied: Trading Legal Entity (external sub-advisers, 52); Source_Notes section 3 RTS 22 and Directive 2024/2811 items removed and the RTS 22 INTC clause dropped; Regulator removed from the shared-list sentence. No Low skipped.",
]
