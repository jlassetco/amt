"""W1b proposals of Data Domain 26 Trade Operations, Settlement & Collateral (wealth model; kept with the US-only and
perspective pass). Brief: 00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (26); decisions CW-003, CW-007,
CW-021, CW-022, CW-039; plan section 5.1 row 26. Declarative only: the program lead merges DECISIONS into decisions.py,
appends JURISDICTION to jurisdiction.REMOVALS and applies SHARED_RECUTS to shared_code_lists.py at merge (W5 for the
shared lists, CW-039). The existing proposals_26.py (expansion) is unchanged.
"""

_D = "CW-926"


def _j(obj, attr, regime, note):
    return {"domain": "26", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


# ---------------------------------------------------------------------------------------------------------------------
# Jurisdiction register entries (jurisdiction.REMOVALS format). Objects and attributes use the wholesale-v1.0 names.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = [
    # Attributes
    _j("Repo Trade", "Repo UTI", "SFTR",
       "UTI for SFTR repo reporting; US funds have no repo trade-reporting duty in the model (OFR bilateral repo collection falls on covered reporters; confirm). Repo Trade Reference stays the key."),
    _j("Derivative Trade Report", "Reported Repo Trade", "SFTR",
       "Repo reports existed only under EU and UK SFTR; Derivative Trade Report now covers swaps (CFTC Part 45) and security-based swaps (SEC Regulation SBSR)."),
    _j("Derivative Trade Report", "Entity Responsible for Reporting", "EMIR",
       "EMIR Article 9(1d) responsibility of the UCITS management company or AIFM; no US equivalent (the CFTC Part 45 reporting counterparty is Reporting Counterparty)."),
    # Code-list values
    _j("Code list: Trade Report Regime", "EU EMIR", "EMIR", "US values CFTC Part 45 and SEC Regulation SBSR stay; shared Regulatory Trade Report Regime re-cut (SHARED_RECUTS)."),
    _j("Code list: Trade Report Regime", "UK EMIR", "EMIR", "As above."),
    _j("Code list: Trade Report Regime", "EU SFTR", "SFTR", "As above."),
    _j("Code list: Trade Report Regime", "UK SFTR", "SFTR", "As above."),
    _j("Code list: Trade Report Action Type", "Early Termination (ETRM)", "SFTR", "SFTR-only action type; Termination (TERM) stays."),
    _j("Code list: Trade Report Action Type", "Collateral Update (COLU)", "SFTR", "SFTR-only action type; Margin Update (MARU) stays (CFTC Part 45 margin and collateral data; confirm label)."),
    _j("Code list: Trade Report Action Type", "Reuse Update (REUU)", "SFTR", "SFTR-only collateral reuse report."),
    _j("Code list: Buy-In Basis", "CSDR Mandatory Buy-In", "CSDR",
       "Never in force (CSDR Refit made it contingent on an implementing act). Re-sourced: FINRA Rule 11810 Buy-In and Regulation SHO Rule 204 Close-Out added as the US values."),
    # Sources
    _j("Sources", "EMIR (Regulation (EU) No 648/2012) and reporting RTS (EU) 2022/1855; UK EMIR", "EMIR",
       "Trade reporting and the OTC trade, clearing, leg and event attributes re-sourced to CFTC Part 45 and SEC Regulation SBSR."),
    _j("Sources", "Securities Financing Transactions Regulation (Regulation (EU) 2015/2365)", "SFTR",
       "Removed with Repo UTI and Reported Repo Trade; Repo Trade attributes re-sourced to ICMA GMRA and SIFMA MRA."),
    _j("Sources", "Commission Delegated Regulation (EU) 2016/2251 (risk-mitigation techniques for uncleared OTC derivatives)", "EMIR",
       "EU uncleared margin RTS; Segregation Required Indicator, Eligible Collateral Type and Concentration Limit re-sourced to the CFTC margin rules (17 CFR 23.150-23.161) and BCBS-IOSCO."),
]

# ---------------------------------------------------------------------------------------------------------------------
# Decision of the US-only pass of 26 (decisions.DECISIONS format)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-926", "theme": "Scope", "title": "US-only pass of 26 Trade Operations, Settlement & Collateral",
     "domains": ["26", "18", "25", "27", "28", "49"],
     "issue": "The wholesale 26 carried EU and UK trade reporting (EU EMIR, UK EMIR, EU SFTR and UK SFTR regimes, the SFTR repo UTI and repo report link, the EMIR Article 9(1d) entity responsible for reporting naming the UCITS management company or AIFM, SFTR-only action types), the CSDR mandatory buy-in, the EU uncleared margin RTS, an ESMA example on Margin Rule Regulators (a removed shared Regulator value) and EMIR, SFTR and CSDR cross-references on generic attributes. Its text described a wholesale asset manager with SMA accounts and did not state that client-side clearance and settlement belong to the self-clearing broker-dealer (49).",
     "resolution": "1) Removed (14 JURISDICTION entries: SFTR 8, EMIR 5, CSDR 1): Repo Trade.Repo UTI; Derivative Trade Report.Reported Repo Trade and Entity Responsible for Reporting (with its relationship to Internal Legal Entity); Trade Report Regime values EU EMIR, UK EMIR, EU SFTR, UK SFTR; Trade Report Action Type values ETRM, COLU, REUU; Buy-In Basis value CSDR Mandatory Buy-In; sources EMIR with RTS 2022/1855 and UK EMIR, SFTR, Delegated Regulation 2016/2251. The Margin Rule Regulators example ESMA is replaced by SEC (the value left the shared Regulator list under CW-909). No object removed. "
                   "2) Re-sourced: Buy-In Notice (five attributes) to FINRA Rule 11810 and Regulation SHO Rule 204, with two new source rows and the Buy-In Basis values FINRA Rule 11810 Buy-In and Regulation SHO Rule 204 Close-Out; Derivative Trade Report (ten attributes) to CFTC Part 45 and SEC Regulation SBSR; the EMIR cross-references on 13 OTC trade, clearing, leg and event attributes to CFTC Part 45; Repo Trade (eight attributes) from SFTR to ICMA GMRA, SIFMA MRA or Internal; Segregation Required Indicator, Eligible Collateral Type and Concentration Limit to the CFTC margin rules and BCBS-IOSCO; CSDR cross-references on Intended Settlement Date, Partial Settlement Allowed Indicator, Fail Start Date and Standard Settlement Cycle to SEC Rule 15c6-1, SMPG or ISO 20022; Clearing Status and Trade Report Action Type list sources to CFTC Part 45. "
                   "3) Kept on purpose, against the brief's removal list (CW-022 investment-universe principle; confirmed by the program lead at the W1b fix pass, with the attribute names kept because DP-151 reads them; primary references on the penalty attributes made generic, 'Internal', with CSDR, the TMPG fails charge or Delegated Regulation 2017/389 as secondary; Penalty Calculating CSD redefined as the CSD that computed a penalty or the counterparty that claimed a fails charge; the Buy-In Basis value Regulation SHO Rule 204 Close-Out states that the close-out duty is the broker-dealer's): Settlement Penalty (whole object) with its Penalty Type values LMFP and SEFP and the sources CSDR (with Refit and Regulation 2025/2075), Delegated Regulations 2018/1229 and 2017/389 and the UK T+1 publication, relabeled as the market rules of foreign CSDs and markets where the funds settle: the object also holds the US Fails Charge (TMPG), EU CSDs charge cash penalties on every participant's fails and custodians pass them to the funds whatever their regulator, and DP-151 and the 37 loss-event product read the object. "
                   "4) Perspective and boundary: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose and Scope state that 26 is fund-side settlement only and that clearance, settlement and custody of client trades are 49 and client money movement 50 (plan section 5.1, CW-007); Core model, Design principles 1 and 6, CDE, Notes (Regulation S-P, GLBA and state law in place of GDPR), Suggested next steps 1, 4 and 5; family and group texts of Settlement Penalties, Settlement Instructions & Cycles, OTC Derivative & Financing Lifecycle and Trade Reporting; 'SMA account' reads 'institutional separate account' in Settlement SMA Account (name kept), Principal Account, four PII notes and two code values; 01, 02 and 25 named with their wealth names; enrich_26 SUMMARY and the Derivative Trade Report grain. Reference (Account) and Reference (Party) unchanged and resolve (CW-021). "
                   "5) Additions: none beyond the boundary sentence. Object and attribute names unchanged; attribute positions renumber in the family OTC Derivative & Financing Lifecycle. "
                   "6) Counts: 28 to 28 objects, 300 to 297 attributes, 93 to 93 CDEs (31.3%), 42 code lists, 30 to 29 sources, 50 to 49 relationships, 53 to 52 references, 4 derived.",
     "rationale": "CW-003 and CW-022: the funds and their adviser are regulated in the US, so EMIR, UK EMIR and SFTR reporting duties and the EU margin RTS do not apply to them, while the generic confirmation, settlement, buy-in, OTC lifecycle, reporting and margin objects keep their US rules (Rule 15c6-1 T+1, FINRA Rule 11810, Regulation SHO Rule 204, CFTC Part 45, Regulation SBSR, the CFTC margin rules). Foreign CSDs and their settlement discipline are part of the investment universe the international funds settle in, like foreign transaction taxes, so the Settlement Penalty object stays. The plan's boundary keeps 26 on the fund side and the self-clearing broker-dealer's client settlement in 49. Names are kept so that DP-151, DP-152 and SM-09 keep resolving; the three removed attributes are read by DP-152, keys_e7_25_26, models_e8c_invops_a and SM-09 (NOTES). Lever: a UK extension restores the removed rows from wholesale-v1.0 through the jurisdiction register.",
     "action": "W1b", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# Shared list re-cuts (26 is steward of Collateral Type and Regulatory Trade Report Regime)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_RECUTS = [
    ("Regulatory Trade Report Regime", "26",
     "Delete EU_EMIR, UK_EMIR, EU_SFTR, UK_SFTR and their 26 value-map entries (CW-039 names this list); keep CFTC_PART_45, SEC_REGULATION_SBSR and SEC_RULE_10C_1A (28 Loan Reporting Regime, Rule 10c-1a). 28's EU/UK loan reporting values are recorded by editor 3 under CW-928."),
    ("Regulatory Report Status", "25",
     "See proposals_w1b_25: 25's member list left with MiFIR Transaction Report. 26 has no member list of its own (Report Processing Status uses the 26 Message Processing Status list), so the steward should move to 28."),
]

SHARED_CANDIDATES = []

# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "W1b (wealth), CW-926. Validation: taxonomy_builder.py content_26_trade_operations_settlement_and_collateral OK (6 families, 28 objects (6 attribute groups, 0 without grain), 297 attributes, 93 CDEs, 52 references, 4 derived, 0 unresolved, 42 code lists); before: 300 attributes, 93 CDEs, 53 references. check_enrichment.py 26 OK.",
    "READERS of removed attributes and values (not edited): "
    "data_products/specs_e2_invops_a.py DP-152 description line 789 (EMIR, UK EMIR and SFTR reports), inputs line 852 (Derivative Trade Report: Reported Repo Trade), line 903 (Repo Trade: Repo UTI), lines 907-909 (Derivative Trade Report: Reported Repo Trade, Entity Responsible for Reporting), quality rule line 930 (exactly one of Reported OTC Trade and Reported Repo Trade) and note line 943 (Submitting Entity differs from Entity Responsible for Reporting); "
    "data_models/keys_e7_25_26.py lines 336 and 338 (reference keys of Reported Repo Trade and Entity Responsible for Reporting); "
    "data_models/models_e8c_invops_a.py lines 601 and 603 (relationships of Fact Derivative Trade Report to Fact Repo Trade and Internal Legal Entity); "
    "semantic_model/models/sm_09_research_trading_operations.py lines 1235-1236 (join trade_report.reported_repo_trade = repo_trade). "
    "Also (W1b fix pass, review D): EMIR and SFTR text in data_products/specs_e2_invops_a.py line 822 (EMIR timely confirmation), line 923 (history: EMIR Article 9(2)), line 935 (notes: SFTR reports on securities lending) and line 996 (disputes flagged for the EMIR dispute report); data_models/keys_e7_25_26.py line 147 (repo key note: the UTI exists only for SFTR-reportable trades); semantic_model/models/sm_09_research_trading_operations.py lines 2070-2073 (live measure Open Collateral Disputes, DP-153: over 15 business days feed the EMIR dispute report). The 15-business-day dispute flag has no EMIR basis in the US model: its owners should re-source it to the CFTC portfolio reconciliation and dispute reporting rule (17 CFR 23.502, confirm) or to firm policy. "
    "Shared lists: consolidation/shared_code_lists.py Regulatory Trade Report Regime (EU_EMIR, UK_EMIR, EU_SFTR, UK_SFTR and the 26 value map; SHARED_RECUTS). Gap register: GAP-26-003 'Derivative trade reporting obligation and deadline are not held per trade and regime' (gaps_register.py line 3292) now concerns CFTC Part 45 and SBSR only. Generated outputs refresh on rebuild.",
    "Readers of Settlement Penalty (kept; listed for the program lead's ruling on open question 1): data_products/specs_e2_invops_a.py DP-151 lines 689-692 and 730; data_products/specs_e4_risk_audit_third_party.py lines 185-192, 241 and 253 (37 loss events, Amount Source Settlement Penalty). If the brief's removal is preferred: JURISDICTION gains one object entry (Settlement Penalty, CSDR), the Penalty Type values LMFP and SEFP and the four source rows (CSDR, 2018/1229, 2017/389, UK Accelerated Settlement), and the US Fails Charge (TMPG) needs a home (for example a Fails Charge Amount on Settlement Fail, which would be an addition the brief does not name).",
    "References to later-stage domains left as they are: Safekeeping Account (Reference (Custody Account), 12 CUA-) and the relationships to 12 Custody Account and its set-up (12 adapted at W4); SSI Mandate (Reference (Mandate), 01). No reference to 30, 07, 03, 05 or 08.",
    "Boundary with 49 (W3): 49 will master client SSIs, client trade settlement with DTC and NSCC and the Rule 15c3-3 reserve; 26 keeps the fund-side SSIs moved from 12 under CD-155. 49 may want Settlement Status Reason, Trade Settlement Status and Settlement Cycle Rule shared; proposed for W3, not changed here.",
    "Remaining hits of the step 1 grep, justified: CSDR, Delegated Regulations 2018/1229 and 2017/389, EU T+1 (Regulation 2025/2075) and the UK T+1 publication on Settlement Penalty and Settlement Cycle Rule (foreign market rules; decision item 3); CREST place of settlement, GB market, GBP and a GB IBAN in SSI examples (foreign markets the funds settle in); ICMA Buy-In Rules and GMRA (international bond and repo market practice); LMA beside LSTA (loan market practice); 'SMA' only in the kept attribute name Settlement SMA Account; 'EU/UK' only in the Overview Notes sentence that states the removal.",
    "Other domains' content seen: 28 Loan Reporting Regime (labels aligned with 26) is editor 3's; 38 Entity Authorization carries the reporting classifications 26 reads (EMIR FC / NFC classifications there would be 38's W4 pass).",
    "Unverified: FINRA Rule 11810 and Regulation SHO Rule 204 URLs (patterns); CFTC Part 45 action type labels; OFR repo collection scope. Marked confirm in Source_Notes section 6.",
    "W1b fix pass (review 00_Program/Rework/Reviews/W1b_18_25_26_27_review.md): the Medium (READERS) applied per ruling 2; both Lows applied (Settlement Penalty primary references and Penalty Calculating CSD per ruling 3; Regulation SHO Rule 204 value description). Open question 1 on Settlement Penalty is closed by the ruling. No Low skipped.",
]
