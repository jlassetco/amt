"""W1b proposals of Data Domain 27 Fund Accounting & Valuation (wealth model; kept with the US-only and perspective pass).
Brief: 00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (27); decisions CW-003, CW-004, CW-021, CW-022, CW-039;
plan section 5.1 row 27. Declarative only: the program lead merges DECISIONS into decisions.py and appends JURISDICTION
to jurisdiction.REMOVALS at merge. The existing proposals_27.py (expansion) is unchanged.
"""

_D = "CW-927"


def _j(obj, attr, regime, note):
    return {"domain": "27", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


# ---------------------------------------------------------------------------------------------------------------------
# Jurisdiction register entries (jurisdiction.REMOVALS format). Objects and attributes use the wholesale-v1.0 names.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = [
    # Attributes
    _j("Distribution Declaration", "Equalization per Share", "Other EU/UK",
       "UK group 2 equalization of authorised funds (IA SORP, UK tax): a per-share amount returned with a distribution declaration. US registered funds use a different mechanism, tax equalization on redemptions (earnings and profits distributed to redeeming shareholders counted toward the dividends-paid deduction, limited since the RIC Modernization Act of 2010; confirm), which is a redemption-side book-tax item, not a declaration attribute. No attribute added in W1b; raised as a fund-tax tailoring question (Source_Notes section 4, question 13)."),
    _j("Distribution Declaration", "Excess Reportable Income per Unit", "Other EU/UK",
       "UK reporting fund regime (Offshore Funds (Tax) Regulations 2009, HMRC); no UK-distributed classes."),
    _j("Swing Pricing Parameter", "Dilution Levy Rate", "FCA",
       "Dilution levy of UK authorised funds (FCA COLL 6.3); US funds use swing pricing under SEC Rule 22c-1(a)(3), which the generic swing objects keep."),
    _j("Swing Pricing Decision", "Dilution Levy Amount", "FCA", "Removed with Dilution Levy Rate."),
    _j("Share Class NAV", "Bid Price", "FCA",
       "Cancellation or bid price of UK dual-priced funds (FCA COLL 6.3); US funds are single-priced at NAV (Offer Price stays for load classes). Found by the grep, not in the brief."),
    # Code-list values
    _j("Code list: Distribution Type", "UK Income Allocation", "Other EU/UK", "UK fund distribution or accumulation of income; US values follow IRC section 852."),
    _j("Code list: Distribution Requirement Period", "UK Reporting Period", "Other EU/UK", "UK reporting fund period; US periods are the fund fiscal year and the IRC section 4982 excise years."),
    _j("Code list: Fund Tax Regime", "UK Authorised Investment Fund", "Other EU/UK", "No UK funds; US regimes are Regulated Investment Company (Subchapter M), Group Trust (CIT), Partnership, Taxable Corporation, Other."),
    _j("Code list: Fund Tax Regime", "Offshore Fund (UK tax)", "Other EU/UK", "UK investor-side tax classification of non-UK funds; no UK distribution."),
    _j("Code list: Fund Tax Regime", "Irish Investment Undertaking", "Other EU/UK", "No Irish-domiciled funds."),
    _j("Code list: Fund Tax Regime", "Luxembourg Subscription Tax Fund", "Other EU/UK", "No Luxembourg-domiciled funds (taxe d'abonnement)."),
    _j("Code list: Fund Tax Return Type", "UK Company Tax Return (CT600)", "Other EU/UK", "US returns are Form 1120-RIC, Form 8613 and Form 1065."),
    _j("Code list: Fund Tax Return Type", "Luxembourg Subscription Tax Return", "Other EU/UK", "As above."),
    _j("Code list: Materiality Basis", "FCA COLL (UK)", "FCA", "NAV error materiality re-sourced to SEC staff practice and the board-approved policy (confirm source)."),
    _j("Code list: Materiality Basis", "CSSF Circular 24/856", "Other EU/UK", "Luxembourg NAV error regime; as above."),
    _j("Code list: Materiality Basis", "Central Bank of Ireland Guidance", "Other EU/UK", "Irish NAV error guidance; as above."),
    # Sources
    _j("Sources", "FCA Handbook COLL 6.3 (valuation and pricing) and COLL 6.6 (powers and duties of the scheme, the authorised fund manager and the depositary)", "FCA",
       "Valuation Date, NAV per Share, Offer Price, Swung NAV per Share, Swing Factor Applied, Correction Methods and NAV Error Percentage no longer cite it; Rule 2a-4 and 22c-1 or Internal."),
    _j("Sources", "IA SORP: Statement of Recommended Practice for Financial Statements of UK Authorised Funds (May 2014, amended June 2017)", "UK market practice",
       "Removed with Equalization per Share; Accounting Basis secondary reference is SEC Regulation S-X Article 6."),
    _j("Sources", "CSSF Circular 24/856 (protection of investors in case of NAV calculation errors and non-compliance with investment rules; replaces Circular 02/77 from 1 January 2025)", "Other EU/UK",
       "NAV Error Type, Materiality Basis, Materiality Threshold and NAV Error Percentage re-sourced to Internal (board-approved policy; ICI practice row)."),
    _j("Sources", "UCITS Directive 2009/65/EC", "UCITS", "Context source only (valuation and depositary duties of UCITS); no attribute cited it."),
    _j("Sources", "Offshore Funds (Tax) Regulations 2009 (UK reporting fund regime)", "Other EU/UK", "Removed with Excess Reportable Income per Unit and the Offshore Fund tax regime value."),
    _j("Sources", "ALFI Swing Pricing Guidelines", "EU market practice",
       "Luxembourg industry guidance; Swing Factor Method, Swing Threshold and the swing factors re-sourced to SEC Rule 22c-1(a)(3)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# Decision of the US-only pass of 27 (decisions.DECISIONS format)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-927", "theme": "Scope", "title": "US-only pass of 27 Fund Accounting & Valuation",
     "domains": ["27", "01", "13", "18", "19", "49"],
     "issue": "The wholesale 27 carried UK and EU fund content: UK equalization and reporting-fund excess reportable income on Distribution Declaration, UK dilution levies on the swing objects, the UK dual-pricing bid price, UK, Irish and Luxembourg fund tax regimes and returns, UK, Luxembourg and Irish NAV error materiality bases, a CSSF example on Regulators Notified (a removed shared Regulator value), a wholesale Business Line example (Mutual Fund) and sources FCA COLL 6.3 and 6.6, IA SORP, CSSF Circular 24/856, the UCITS Directive, the Offshore Funds (Tax) Regulations and the ALFI swing pricing guidelines. Its text described the books of an asset manager's wholesale range including insurance-dedicated funds.",
     "resolution": "1) Removed (22 JURISDICTION entries: Other EU/UK 14, FCA 5, UK market practice 1, UCITS 1, EU market practice 1): Distribution Declaration.Equalization per Share and Excess Reportable Income per Unit; Swing Pricing Parameter.Dilution Levy Rate; Swing Pricing Decision.Dilution Levy Amount; Share Class NAV.Bid Price (found by the grep); values Distribution Type UK Income Allocation, Distribution Requirement Period UK Reporting Period, Fund Tax Regime UK Authorised Investment Fund, Offshore Fund (UK tax), Irish Investment Undertaking, Luxembourg Subscription Tax Fund, Fund Tax Return Type UK Company Tax Return (CT600), Luxembourg Subscription Tax Return, Materiality Basis FCA COLL (UK), CSSF Circular 24/856, Central Bank of Ireland Guidance; sources FCA COLL 6.3 and 6.6, IA SORP, CSSF Circular 24/856, UCITS Directive, Offshore Funds (Tax) Regulations 2009, ALFI Swing Pricing Guidelines. The EU/UK Accounting Basis values are the shared list's (steward 19, CW-919); 27 holds no copy and no longer names them. No object removed. "
                   "2) Re-sourced: swing pricing (Swing Factor Method, Swing Threshold, Inflow and Outflow Swing Factor, Swing Factor Applied, Swing Factor Method list, the Rule 22c-1 source row) to SEC Rule 22c-1(a)(3), keeping the generic swing objects because US funds may swing price; NAV error materiality (Materiality Basis with a new definition and note, Materiality Threshold, NAV Error Type, NAV Error Percentage, Correction Methods, the NAV Error Type, Correction Method and Materiality Basis lists, the ICI practice row) to SEC staff practice and the board-approved policy (confirm source); Valuation Date and NAV per Share to Rule 2a-4 in place of COLL 6.3; Offer Price and Swung NAV per Share drop COLL; Accounting Basis secondary reference to Regulation S-X Article 6; Regulators Notified example SEC in place of CSSF; fund tax remains Subchapter M (IRC sections 851-855), section 4982 and Form 1120-RIC. "
                   "3) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose (own funds of the PF line; 49 named as the client book of record), Scope (Rule 22c-1(a)(3) swing pricing, no insurance-dedicated NAVs, 26 fund-side, 49 client holdings), Notes (Regulation S-P, GLBA and state law in place of GDPR; the British-spelling sentence removed) and Suggested next step 7; family and group texts of Swing Pricing & Anti-Dilution (family name kept); Identified Cost Amount no longer names IFRS books; enrich_27 SUMMARY. Business Line example PF (CW-004 codes; Derived copy of 18) and 'institutional separate accounts have no fund book' (attribute note and relationship). 01 and 02 named with their wealth names. 47 Pricing, Fees & Billing named in the fee boundary (Scope and Design principle 1; W1b fix pass). Fund Journal Source Type value 'Swing Pricing / Dilution' kept, described as Rule 22c-1(a)(3) swing adjustments. "
                   "4) Re-points: none needed beyond the names (Reference (Party) resolves, CW-021). References to 30 left for W4 (NOTES). "
                   "5) Additions: none. Object and attribute names unchanged; attribute positions renumber in the families NAV Calculation, Swing Pricing & Anti-Dilution and Income & Distributions. "
                   "6) Counts: 32 to 32 objects, 280 to 275 attributes, 95 to 95 CDEs (34.5%), 42 code lists, 23 to 17 sources, 51 relationships, 59 references, 7 derived.",
     "rationale": "CW-003 and CW-022: the firm's funds are US registered funds and bank CITs, so UK and EU fund pricing, tax and NAV error regimes do not apply, while foreign-currency accounting, foreign income and foreign taxes of the international funds stay. Swing pricing is permitted for US open-end funds under Rule 22c-1(a)(3), so the swing objects are kept and re-sourced rather than removed. Names are kept so that DP-165 to DP-176 and SM-11 keep resolving; the five removed attributes are read by DP-165, DP-169, DP-171 and SM-11 (NOTES). Lever: a UK extension restores the removed rows from wholesale-v1.0 through the jurisdiction register.",
     "action": "W1b", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

SHARED_RECUTS = [
    ("Accounting Basis", "19",
     "27 is a direct user; no 27 change. For the steward 19 (CW-919): drop IFRS_EU_ADOPTED, UK_ADOPTED_IFRS, FRS_102_UK_GAAP, LUX_GAAP, IRISH_GAAP_FRS_102; 27 uses US GAAP and Tax Basis."),
    ("Business Line", "09",
     "27 is a direct user: its example now uses the CW-004 code PF, matching the 18 re-cut (proposals_w1b_18 SHARED_RECUTS)."),
]

SHARED_CANDIDATES = []

# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "W1b (wealth), CW-927. Validation: taxonomy_builder.py content_27_fund_accounting_and_valuation OK (9 families, 32 objects (3 attribute groups, 0 without grain), 275 attributes, 95 CDEs, 59 references, 7 derived, 0 unresolved, 42 code lists); before: 280 attributes. check_enrichment.py 27 OK.",
    "READERS of removed attributes (not edited): "
    "data_products/specs_e3_fund_accounting_custody.py DP-169 inputs line 204 (Swing Pricing Parameter: Dilution Levy Rate) and line 207 (Swing Pricing Decision: Dilution Levy Amount), DP-169 history text line 234 (cites CSSF Circular 24/856); DP-171 inputs line 466 (Distribution Declaration: Equalization per Share, Excess Reportable Income per Unit); "
    "data_products/specs_e1_book_of_record.py DP-165 inputs line 1074 (Share Class NAV: Bid Price); "
    "semantic_model/models/sm_11_fund_accounting_custody_governance.py line 83 (bid_price), line 320 (dilution_levy_amount), line 328 (dilution_levy_rate) and lines 427-428 (equalization_per_share, excess_reportable_income_per_unit); "
    "data_models/models_e8c_fund_accounting_custody.py line 353 (entity note 'Rate, dates, equalization and the reinvest NAV of each declaration'). "
    "Code-value readers: none found (no product filters on the removed Fund Tax Regime, Fund Tax Return Type, Distribution Type, Distribution Requirement Period or Materiality Basis values). The 13 'UK & EU Tax Document' readers in specs_o_operations.py (lines 397-514) are 13's (W2), not 27's. Generated outputs refresh on rebuild.",
    "References to retiring domains left as they are (W4): Fund Journal Line.Source Capital Call (Reference (Capital Call, 30)), Source Private Fund Distribution (Reference (Distribution, 30)), Source Credit Facility (Reference (Fund Credit Facility, 30)), Source Waterfall Calculation (Reference (Waterfall Calculation, 30)); Fund Journal Source Type values Capital Call, Private Fund Distribution, Credit Facility, Carried Interest; relationships 'Fund Journal Line books Capital Call / Distribution / Fund Credit Facility / Waterfall Calculation [30]' and 'Fund Tax Year Record (Partnership) is allocated to partners by Partner Tax Allocation [30]'; Fund Tax Regime value Partnership ('partner allocations are 30'); Fund Tax family and Fund Tax Year Record group texts (partner allocations are 30); overview Scope and Core model; enrich_27 SUMMARY references. A wealth manager with own alternative feeder funds (01, 15) may keep the partnership regime.",
    "Insurance-dedicated residue for the W4 decision: overview Scope 'delivery of NAV and holdings packages to insurers (12 Report Runs, CD-193)' and the Corrected Release note 'Insurer, vendor and platform deliveries ... NAV and holdings packages to insurers are 12 Report Runs'. No 27 code value names insurance-dedicated funds.",
    "Business Line: 27 Fund Accounting Book.Business Line is a Derived copy of 18 Portfolio.Business Line (re-cut to CW-004 codes in CW-918); the shared Business Line list already holds the codes.",
    "Remaining hits of the step 1 grep, justified: EUR amounts and the WMR FX observation key (foreign-currency accounting); 'Swing Pricing & Anti-Dilution' family name and the 'Swing Pricing / Dilution' journal source value (generic; swing pricing under Rule 22c-1(a)(3)); 'UK' and 'EU/UK' only in the Overview Notes sentence and the Accounting Basis note that state the removal; 'insurer' in the two W4 residue texts above.",
    "Other domains' content seen: 01 Share Class UK Reporting Fund Status was named by the removed Excess Reportable Income note (01 is W1, CW-901); 13 'UK & EU Tax Document' (equalization, excess reportable income) is 13's W2 pass; 22 Valuation Regulatory Framework and Valuation Committee Type EU values are editor 1's (CW-922); 35 RIC Qualification Determination is referenced by text only.",
    "Unverified: the NAV error materiality source (SEC staff practice; no single citable SEC source; ICI practice commonly 0.5% / one cent); the 2% swing factor upper limit stated in the Rule 22c-1 source row. Marked confirm in Source_Notes section 6.",
    "W1b fix pass (review 00_Program/Rework/Reviews/W1b_18_25_26_27_review.md): all three Lows applied per ruling 4 (equalization note reworded with a fund-tax tailoring question; 47 Pricing, Fees & Billing named in the Scope out-of-scope list and Design principle 1; the stale FCA COLL 6.6 'confirm' row of the Source_Notes review table removed). No Low skipped.",
]
