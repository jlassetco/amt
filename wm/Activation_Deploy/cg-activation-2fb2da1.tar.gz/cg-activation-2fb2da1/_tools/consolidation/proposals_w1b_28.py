"""W1b proposals of Data Domain 28 Fund Custody & Asset Servicing (wealth model; kept with the US-only and perspective
pass and the rename of plan section 5.1). Brief: 00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (28); decisions
CW-003, CW-007, CW-021, CW-022, CW-039; plan section 5.1 row 28. Declarative only: the program lead merges DECISIONS into
decisions.py, appends JURISDICTION to jurisdiction.REMOVALS and applies SHARED_RECUTS to shared_code_lists.py at merge (W5
for the shared lists, CW-039). The existing proposals_28.py (expansion) is unchanged.
"""

_D = "CW-928"


def _j(obj, attr, regime, note):
    return {"domain": "28", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


_CASS_US = "Custody of client assets and the US customer-protection record (SEC Rule 15c3-3 possession or control and reserve computation) are 49's (CW-007)."

# ---------------------------------------------------------------------------------------------------------------------
# Jurisdiction register entries (jurisdiction.REMOVALS format). Objects and attributes use the wholesale-v1.0 names.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = [
    # Objects (whole)
    _j("Client Asset Designation", "", "CASS",
       "FCA CASS 6 / 7 designation of safekeeping and bank accounts of the UK CASS firms; the firm has no UK entity. " + _CASS_US),
    _j("Client Money Calculation", "", "CASS",
       "CASS 7 client money requirement against resource (CMC-). " + _CASS_US + " CMC- is left registered to 28 for the program lead to retire."),
    _j("CASS Acknowledgment Letter", "", "CASS",
       "CASS 7 / CASS 6 acknowledgment letters. The US analogue (the bank's written notice for the Special Reserve Bank Account under Rule 15c3-3(f)) belongs to 49."),
    _j("CASS Firm Profile", "", "CASS",
       "CASS 1A firm classification and CASS operational oversight officer of a UK investment firm entity; no US equivalent profile."),
    # Code lists removed whole with the objects
    *[_j("Code list: CASS Account Designation", v, "CASS", "Whole list removed with Client Asset Designation.")
      for v in ("General Client Bank Account", "Designated Client Bank Account", "Designated Client Fund Account",
                "Client Transaction Account", "Safe Custody Asset Account", "Not Client Asset Account")],
    *[_j("Code list: Client Money Calculation Method", v, "CASS", "Whole list removed with Client Money Calculation.")
      for v in ("Standard Method", "Non-Standard Method")],
    *[_j("Code list: Acknowledgment Letter Type", v, "CASS", "Whole list removed with CASS Acknowledgment Letter.")
      for v in ("Client Bank Account", "Client Transaction Account", "Authorized Central Counterparty", "Custodian Agreement Confirmation")],
    *[_j("Code list: Acknowledgment Letter Status", v, "CASS", "Whole list removed with CASS Acknowledgment Letter.")
      for v in ("Draft", "Sent", "Countersigned", "Rejected - Redraft", "Superseded", "Overdue")],
    *[_j("Code list: CASS Firm Classification", v, "CASS", "Whole list removed with CASS Firm Profile.")
      for v in ("CASS Large Firm", "CASS Medium Firm", "CASS Small Firm", "Not a CASS Firm")],
    # Code-list values of kept lists
    _j("Code list: Custody Reconciliation Type", "CASS External Custody Reconciliation", "CASS",
       "CASS 6 external reconciliation; fund reconciliations against custodians stay (IBOR, ABOR, cash). The broker-dealer's possession-or-control reconciliations are 49's."),
    _j("Code list: Custody Reconciliation Type", "CASS External Client Money Reconciliation", "CASS",
       "CASS 7 client money reconciliation against bank statements; client cash is 49 and 50."),
    _j("Code list: Foreign Custody Assessment Type", "UCITS Depositary Delegation Due Diligence", "UCITS",
       "UCITS V depositary delegation; no UCITS range. Foreign custody of US fund assets is assessed under SEC Rules 17f-5 and 17f-7 (values kept)."),
    _j("Code list: Foreign Custody Assessment Type", "AIFMD Delegation Due Diligence", "AIFMD",
       "AIFMD Article 21 depositary delegation; no AIF range. Re-sourced to Rules 17f-5 and 17f-7."),
    _j("Code list: Foreign Custody Assessment Type", "CASS 6 Third-Party Custodian Review", "CASS",
       "UK firm's custodian selection and review under CASS 6; the periodic provider review is Custodian Service Review (kept)."),
    _j("Code list: Loan Reporting Regime", "EU SFTR", "SFTR",
       "No EU reporting entity. Securities loans are reported under SEC Rule 10c-1a (value kept)."),
    _j("Code list: Loan Reporting Regime", "UK SFTR", "SFTR", "No UK reporting entity. Re-sourced to SEC Rule 10c-1a."),
    _j("Code list: Custody Provider Role", "Depositary", "UCITS",
       "UCITS and AIF depositary with oversight duties (also AIFMD Article 21). US funds appoint a custodian under Investment Company Act Section 17(f); the Global Custodian and Trustee Custodian values cover them."),
    _j("Code list: Custody Provider Role", "Client Money Bank", "CASS",
       "Bank holding CASS client money accounts; client cash of the brokerage is 49 and 50 (the 02 Party Role Type value was removed under CW-902 on the same ground)."),
    _j("Code list: Custody Service Type", "Depositary Oversight", "UCITS",
       "UCITS / AIFMD depositary oversight duties; US fund boards oversee the custodian under Rules 17f-5 and 17f-7 (Foreign Custody Assessment, Custodian Service Review)."),
    _j("Code list: Custody Service Type", "Ownership Verification", "AIFMD",
       "AIFMD 'other assets' record keeping by a depositary; no AIF range."),
    _j("Code list: Safekeeping Account Type", "Ownership Verification Record", "AIFMD",
       "Depositary record of AIFMD 'other assets' and private fund interests; no AIF range. Feeder access to alternatives (CW-038) is held as client holdings in 49."),
    _j("Code list: Custodian Statement Type", "Depositary Ownership Verification Statement", "AIFMD",
       "Removed with the Ownership Verification Record."),
    # Sources
    _j("Sources", "CSDR, Regulation (EU) No 909/2014 (Article 38 protection of securities of participants and their clients)", "CSDR",
       "Cited for Custody Holding Model, Market Holding Model, Account Holding Model, Securities Depository and Market Claim Indicator; re-sourced to ISSA market practice and SMPG (market-level holding models of the foreign markets stay, CW-022)."),
    _j("Sources", "FCA Handbook, Client Assets sourcebook (CASS 1A, CASS 6, CASS 7)", "CASS",
       "Removed with the Client Assets & Money family, Client Asset Designation and the CASS values; also the secondary reference of Custody Reconciliation Type and Signed Off By."),
    _j("Sources", "UCITS Directive 2009/65/EC as amended by Directive 2014/91/EU (UCITS V depositary rules)", "UCITS",
       "Was secondary on Custody Provider Role, Sub-Custodian, Foreign Custody Assessment Type and Owning Fund; re-sourced to Investment Company Act Section 17(f) and SEC Rules 17f-5 and 17f-7."),
    _j("Sources", "AIFMD, Directive 2011/61/EU, Article 21 (depositary)", "AIFMD",
       "Was secondary on Eligibility Decision and Safekeeping Account Type; removed with the ownership-verification values."),
    _j("Sources", "Securities Financing Transactions Regulation, Regulation (EU) 2015/2365 (and UK SFTR)", "SFTR",
       "Was cited on 16 securities lending attributes; re-sourced to SEC Rule 10c-1a (Loaned Instrument, Loan Quantity, Reported Loan, Loan Reporting Regime, Reporting Party, Unique Transaction Identifier, Loan Report Status, Lending Collateral Type), the ISLA GMSLA (Loan Value, Loan Mark Date, Collateral Mark Date, Collateral Value) or Internal (Collateralized Loan, Collateral Pool Borrower, Collateral Instrument, Tri-Party Agent)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# Decision of the US-only pass of 28 (decisions.DECISIONS format)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-928", "theme": "Scope", "title": "US-only pass of 28 Custody & Asset Servicing (renamed Fund Custody & Asset Servicing)",
     "domains": ["28", "49"],
     "issue": "The wholesale 28 described custody for an asset manager whose funds, SMAs, private funds and insurance-dedicated funds are distributed in the US and EU/UK. It carried the UK client asset (CASS) records of the firm's UK investment firm entities as a family (Client Money Calculation, CASS Acknowledgment Letter, CASS Firm Profile) and a designation object (Client Asset Designation), UCITS and AIFMD depositary roles, services, delegation assessments and ownership-verification records, EU and UK SFTR loan reporting, CSDR holding-model citations and EU/UK sources. The wealth firm has no UK or EU entity, and CW-007 puts custody of client assets (the Rule 15c3-3 record) in 49, so 28 must say it holds fund assets only.",
     "resolution": "1) Removed (44 JURISDICTION entries: CASS 31, AIFMD 5, UCITS 4, SFTR 3, CSDR 1): the family Client Assets & Money (CU-CAS) with its objects Client Money Calculation (9 attributes), CASS Acknowledgment Letter (7) and CASS Firm Profile (9); the object Client Asset Designation (6 attributes, the last object of Safekeeping Accounts, so no attribute ID of a kept object moves); the local lists CASS Account Designation, Client Money Calculation Method, Acknowledgment Letter Type, Acknowledgment Letter Status and CASS Firm Classification (22 values); the values Custody Reconciliation Type 'CASS External Custody Reconciliation' and 'CASS External Client Money Reconciliation', Foreign Custody Assessment Type 'UCITS Depositary Delegation Due Diligence', 'AIFMD Delegation Due Diligence' and 'CASS 6 Third-Party Custodian Review', Loan Reporting Regime 'EU SFTR' and 'UK SFTR', Custody Provider Role 'Depositary' and 'Client Money Bank', Custody Service Type 'Depositary Oversight' and 'Ownership Verification', Safekeeping Account Type 'Ownership Verification Record', Custodian Statement Type 'Depositary Ownership Verification Statement'; the sources CSDR, FCA CASS, UCITS V depositary rules, AIFMD Article 21 and EU/UK SFTR; four relationships (Client Asset Designation, Client Money Calculation, CASS Acknowledgment Letter, CASS Firm Profile). "
                   "2) Re-sourced: Foreign Custody Assessment and its type list to Investment Company Act Section 17(f) and SEC Rules 17f-4, 17f-5 and 17f-7 (secondary UCITS and AIFMD references dropped on Custody Provider Role, Sub-Custodian, Foreign Custody Assessment Type, Eligibility Decision, Owning Fund, Safekeeping Account Type); Loan Regulatory Report, Loan Reporting Regime (a deliberate one-value list, SEC Rule 10c-1a, kept because the grain is loan x regime and the list is the 28 member of the shared Regulatory Trade Report Regime; to be recorded under CW-039 so that the W5 two-value floor check does not flag it), Unique Transaction Identifier (now the FINRA-assigned loan identifier; example changed), Loan Report Status, Reporting Party, Loaned Instrument, Loan Quantity and Lending Collateral Type to SEC Rule 10c-1a; Loan Value, Loan Mark Date, Collateral Mark Date and Collateral Value to the ISLA GMSLA; Collateralized Loan, Collateral Pool Borrower, Collateral Instrument and Tri-Party Agent to Internal; Custody Holding Model, Market Holding Model and Account Holding Model from CSDR to ISSA; CSDR secondary dropped on Securities Depository and Market Claim Indicator; FCA CASS 6 secondary dropped on Custody Reconciliation Type and Signed Off By. Sources 26 to 21. "
                   "3) Perspective and rename (plan section 5.1): META title and subtitle 'Fund Custody & Asset Servicing | Wealth manager (direct) | Scope: US' (output path and folder unchanged until domains.py and the folder move at merge); overview Purpose, Scope, Core model, Design principles (new 6: fund assets here, client assets in 49 under Rule 15c3-3; new 10: the custody universe is global, CW-022), Applies To, CDE, Notes (GDPR replaced by Regulation S-P, GLBA and state privacy law) and Suggested next steps (CASS steps replaced by the 28 / 49 boundary); the boundary is stated in the family texts of Custody Network, Safekeeping Accounts and Corporate Action Processing and in the definitions of Safekeeping Account, Owning Client Account, Class Action Claim and Claiming Client Account; 'SMA or mandate account' reads 'institutional separate account' (IA line, CW-009), and retail brokerage, retirement and managed accounts are stated to have no safekeeping account (49 client holdings); 'custodian or depositary' reads 'custodian' or 'securities depository'; Cash Account IBAN example is a German IBAN of a sub-custodian cash account; SUMMARY in enrich_28.py. "
                   "Review fix pass: bare 'position' and 'holding' now name the books of record (18 Portfolio Holding, 49 Client Holding, 06 Fund Shareholder Position) in Design principles 2 and 6, the Corporate Action Processing family text, Book Holding, Entitled Portfolio, the Projected entitlement status and the Corporate Action Payment relationship; Design principle 6 no longer suggests a record shared with 49; Tax Relief Method takes OECD TRACE as primary and the EU FASTER Directive as secondary; Custody Provider Role takes Investment Company Act Section 17(f) as primary; the Rule 17f-4 assessment value is marked optional; the Reporting Deferred Indicator note and Suggested next step 5 state the Fifth Circuit remand (August 2025) and the deferral to 28 September 2028 and 29 March 2029 (confirm). 4) Re-points: '02 Client & Customer' reads the 02 party core (CD-143); Loan Regulatory Report.Unique Transaction Identifier keeps its name (read by DP-174) but now holds the FINRA-assigned loan identifier (REPOINTS); no Reference type changes (Party and Account keep their names, CW-021). 5) Additions: none beyond the rename and the boundary sentence. 6) Kept on purpose (CW-022): foreign sub-custodians, ICSDs (Euroclear Bank, Clearstream Banking), market holding models, foreign currency cash accounts and IBANs, withholding tax relief and reclaims including the EU FASTER Directive (relief procedure of EU source countries for income on EU securities the funds hold), the OECD TRACE package, the ISLA GMSLA (market-neutral contract standard), the Opt-Out Indicator's non-US collective action. Counts: 7 to 6 families, 29 to 25 objects, 257 to 226 attributes, 87 to 76 CDEs (33.6%), 39 to 34 code lists, 39 to 35 relationships, 26 to 21 sources.",
     "rationale": "CW-003 and CW-022: the firm is regulated in the US only, so the UK client asset rules, the EU depositary regime and EU/UK SFTR have no entity to apply to, while the custody network of its international funds stays global. CW-007: custody of client assets and the Rule 15c3-3 record are 49's, so the US customer-protection record is not rebuilt here; 28 is fund custody, which the rename states. Names of kept objects and attributes are unchanged so that DP-167, DP-172 to DP-174 and their models keep resolving; the readers of the removed objects (DP-167, DP-175, SM-00, SM-11, the e8 and e8c models and the keys registry) are listed in NOTES.",
     "action": "W1b", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# Prefixes: none added. CMC- (Client Money Calculation) loses its object: the program lead retires it at merge.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# Shared list re-cuts (28 is a member of Regulatory Trade Report Regime through its local Loan Reporting Regime)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_RECUTS = [
    ("Regulatory Trade Report Regime", "26",
     "Member 28 (Loan Reporting Regime) now holds only 'SEC Rule 10c-1a': drop 'EU SFTR' and 'UK SFTR' from the 28 value map "
     "(shared_code_lists.py line 2506). The shared values EU_SFTR and UK_SFTR leave with 26's own EU and UK EMIR / SFTR values "
     "(CW-926, CW-039); SEC_RULE_10C_1A stays."),
]

SHARED_CANDIDATES = []

# ---------------------------------------------------------------------------------------------------------------------
# Re-points: (object, attribute, before, after, decision)
# ---------------------------------------------------------------------------------------------------------------------
REPOINTS = [
    ("Loan Regulatory Report", "Unique Transaction Identifier", "UTI of the EU / UK SFTR report (trade repository)",
     "Identifier FINRA assigns to the reported loan under SEC Rule 10c-1a (name kept for DP-174)", _D),
    ("Safekeeping Account Assignment", "Owning Client Account", "SMA or mandate account",
     "Institutional separate account (15 Institutional Account, IA line); retail accounts are 49 client holdings", _D),
    ("Class Action Claim", "Claiming Client Account", "SMA or mandate account", "Institutional separate account; retail claims are 49's", _D),
]

# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "W1b (wealth), CW-928. Validation: taxonomy_builder.py content_28_custody_and_asset_servicing OK (6 families, 25 objects "
    "(0 attribute groups, 0 without grain), 226 attributes, 76 CDEs, 57 references, 2 derived, 0 unresolved, 34 code lists); "
    "before: 7 families, 29 objects, 257 attributes, 87 CDEs, 63 references, 39 code lists. check_enrichment.py 28 OK.",
    "Rename: META carries 'Fund Custody & Asset Servicing' (domains.py PLAN already names it); the output path, the folder "
    "28_Custody_and_Asset_Servicing, the module file name and the L1 code CU are unchanged. domains.py DOMAINS['28'] and any "
    "folder move are the program lead's at merge.",
    "READERS of removed objects and attributes (not edited; for the program lead and the product and model owners): "
    "data_products/framework.py line 1032 (DP-175 'Client Money & Client Assets (CASS)', owner CASS Operational Oversight Officer: the whole product reads only removed objects; retire or re-scope to 49 at WP0) and line 235 (framework text 'CASS compliance'); "
    "data_products/specs_e3_fund_accounting_custody.py lines 931-1041 (DP-175 spec: grain line 946, metrics lines 950-983 read Client Money Calculation, CASS Firm Profile, CASS Acknowledgment Letter and Client Asset Designation, inputs lines 986-996, quality rules lines 1014-1018, notes lines 1031-1034); line 640 (DP-172 note: CASS external reconciliations are runs read by DP-175; the two CASS values of Custody Reconciliation Type are removed); line 623 (DP-172 history: CASS record keeping); "
    "lines 810, 850-851, 881 and 914 (DP-174: questions and notes on SFTR, the 'Unreported Loans' metric and inputs read Loan Reporting Regime, kept, whose EU SFTR and UK SFTR values are removed); "
    "data_products/specs_e1_book_of_record.py lines 1296, 1307, 1312 (DP-167 definition, question and 'CASS designation' view column), lines 1336-1339 (DP-167 metric 'Client Accounts Without CASS Designation' reads Client Asset Designation), lines 1355-1356 (DP-167 inputs: Client Asset Designation with Statutory Trust Indicator), line 1365 (history: designations), lines 1392-1397 (notes: CASS taxonomy gap and SME questions 5 and 12, which are withdrawn); "
    "data_models/models_e8_book_of_record.py lines 1085-1088 (DP-167 entity Client Asset Designation), 1113 (note: designating CASS firms), 1128-1129 (relationships), 1145 and 1150 (model notes); "
    "data_models/models_e8c_fund_accounting_custody.py line 4 (module docstring), line 66 (CADESIG conformed entity of DP-167), lines 650-651 (DP-174 Loan Regulatory Report grain 'SEC 10c-1a, SFTR'), lines 727-780 (DP-175 model: Fact Client Money Calculation, Fact CASS Acknowledgment Letter, CASS Firm Profile, conformed Client Asset Designation, relationships 765-776, notes 780); "
    "data_models/keys_e7_27_29.py lines 157 (Client Asset Designation key), 206-209 (Client Assets & Money keys), 382-383 and 455-461 (reference targets of the removed attributes); "
    "semantic_model/models/sm_00_shared_dimensions.py lines 655-658 (client_asset_designation dimension with cass_designation and statutory_trust), line 947 (DP-167/Client Asset Designation in the shared entity list), line 1213 (join client_asset_designation.designating_cass_firm = internal_legal_entity.legal_entity_id, which fails once the dimension goes), line 1705 (DP-167 metric note); data_products/specs_e2_invops_a.py line 935 (text 'SFTR reports on securities lending are 28'); data_models/_conformed.txt line 569 (generated conformed entity DP-167 Client Asset Designation); "
    "semantic_model/models/sm_11_fund_accounting_custody_governance.py line 2 and line 47 (model docstring and audience), lines 638-665 (DP-175 entities client_money_calc, cass_letter, cass_firm_profile), line 1070 (CASS block), lines 1764-1796 (DP-175 metrics: Client Money Shortfall Days, Client Money Excess, Calculation Completeness, Tie-Out Exceptions, CASS external reconciliation coverage, CASS Classification Mismatches, CASS Firm Permission Exceptions), line 2165 (CASS rows), line 612 (loan_reporting_regime dimension, kept attribute). "
    "Registers: consolidation/gaps_register.py lines 3404 and 3413-3415 (GAP entries on Client Asset Designation, CASS Firm Profile and Client Money Calculation: drop as for W1); consolidation/decisions.py lines 2330 and 2332 (object register rows Client Money Calculation and CASS Firm Profile), line 2775 (prefix CMC- 'Registered': retire), line 3175 (CMC- format row), line 949 (CD-197 resolution, historical); consolidation/proposals_dp_fund_ops.py lines 96 and 255-256 and proposals_38.py line 225 (historical proposals naming the objects); consolidation/shared_code_lists.py line 2506 (SHARED_RECUTS). Generated outputs (workbooks, explorer, review app) refresh on rebuild.",
    "Text in other domains naming the removed CASS content (not edited; for their own passes): content_38_corporate_compliance_and_regulatory_affairs.py line 9 (Scope, CASS policy and CMAR) and line 489 (Firm Filing Form Type, FCA forms); content_43_corporate_treasury_and_capital.py line 461 (Bank Account Purpose source note 'CASS client money ... are 28 Safekeeping Accounts'); data_products/specs_e4_finance_tax_treasury.py lines 563 and 685 and specs_e4_compliance_legal.py line 14 (CASS client money and CMAR wording).",
    "28 / 49 boundary for the 49 drafter (W3): no safekeeping account (SKA-) for a retail brokerage, retirement or managed account; "
    "the broker-dealer's own accounts at DTC and its banks (customer securities, the Special Reserve Bank Account), the "
    "possession-or-control reconciliations, client-level corporate action entitlements and elections and class action claims "
    "for retail clients are 49's. 28 and 49 share the 17 Corporate Action Event and the 02 custodian and depository parties. "
    "An open question for 49: whether the broker-dealer's depository and bank accounts are modeled on the SKA- pattern or in 49 alone.",
    "References to domains adapted or replaced later, left as they are: Reference (Custody Account, 12) relationship (12 adapted at W4); "
    "Related AP Order (29, adapted at W3); 38 Entity Authorization is no longer referenced (CASS Entity Authorization removed). "
    "No reference to 30 or 07. No Business Line value is used in 28.",
    "Remaining hits of the step 1 grep, justified: 'EU' in the Purpose ('the EU markets the international funds invest in') and the EU FASTER Directive source and Tax Relief Method references (relief procedure of foreign source countries, CW-022 foreign tax reclaim); "
    "'Euroclear Bank or Clearstream Banking' in the ICSD value description (foreign depositories); 'ISLA' (market-neutral lending agreement standard; English governing law is a legal fact, CW-022); 'EUR' amounts and the 'BZST' German reclaim filing example (foreign markets); "
    "'DE' IBAN example (sub-custodian cash account). No MiFID, UCITS, AIFMD, FCA, CASS, CSDR, SFTR, GDPR or 'SMA' hit remains in the module.",
    "Unverified (marked confirm in Source_Notes): the status of Rule 10c-1a (remanded by the Fifth Circuit in August 2025; reporting deferred to 2028-09-28 and public dissemination to 2029-03-29 by the December 2025 order); whether FASTER relief at source and quick refund are open to US-resident beneficial owners; the format of the FINRA-assigned loan identifier under Rule 10c-1a (SLATE) used in the Unique Transaction Identifier example; that Rule 10c-1a reports the type of collateral (cited as secondary on Lending Collateral Type); the shared-list line number cited for the value map.",
]
