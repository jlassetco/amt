"""W1b proposals of Data Domain 31 Investment Risk (wealth model; kept with the US-only and perspective pass). Brief:
00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (31); decisions CW-003, CW-004, CW-009, CW-021, CW-022, CW-039;
plan section 5.1 row 31. Declarative only: the program lead merges DECISIONS into decisions.py, appends JURISDICTION to
jurisdiction.REMOVALS and applies SHARED_RECUTS to shared_code_lists.py at merge (W5 for the shared lists, CW-039). The
existing proposals_31.py (expansion) is unchanged.
"""

_D = "CW-931"


def _j(obj, attr, regime, note):
    return {"domain": "31", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


# ---------------------------------------------------------------------------------------------------------------------
# Jurisdiction register entries (jurisdiction.REMOVALS format). Objects and attributes use the wholesale-v1.0 names.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = [
    # Objects (whole): the family Product Risk Indicators (RK-PRI) is removed with them
    _j("Product Risk Indicator Calculation", "", "PRIIPs",
       "PRIIPs KID summary risk indicator and UCITS KII SRRI per share class (14 attributes); 01 removed the disclosed SRI and SRRI under CW-901. "
       "US funds disclose risk narratively in the Form N-1A risk/return summary; no numeric indicator is computed."),
    _j("PRIIPs Performance Scenario", "", "PRIIPs",
       "PRIIPs KID performance scenarios (8 attributes); no US equivalent (Form N-1A shows past performance, which is 32)."),
    # Code lists removed whole with the objects
    _j("Code list: Product Risk Indicator Type", "PRIIPs SRI", "PRIIPs", "Whole list removed with Product Risk Indicator Calculation."),
    _j("Code list: Product Risk Indicator Type", "UCITS SRRI", "UCITS", "Whole list removed with Product Risk Indicator Calculation."),
    _j("Code list: Product Risk Indicator Type", "UK CCI Risk Indicator", "FCA", "UK Consumer Composite Investments regime; removed with the list."),
    *[_j("Code list: PRIIPs Scenario Type", v, "PRIIPs", "Whole list removed with PRIIPs Performance Scenario.")
      for v in ("Stress", "Unfavorable", "Moderate", "Favorable")],
    # Code-list values of kept lists
    _j("Code list: Counterparty Exposure Method", "UCITS Positive Mark-to-Market", "UCITS",
       "CESR/10-788 OTC counterparty exposure; the generic Current Exposure Method, SA-CCR and Internal PFE Simulation values stay."),
    _j("Code list: Exposure Method", "Commitment Approach (UCITS)", "UCITS", "UCITS global exposure; US derivatives exposure is 'Rule 18f-4 Derivatives Exposure' (kept). Shared list, steward 31 (SHARED_RECUTS)."),
    _j("Code list: Exposure Method", "Sum of Notionals (UCITS)", "UCITS", "UCITS VaR-approach leverage disclosure (CESR/10-788)."),
    _j("Code list: Exposure Method", "Gross Method (AIFMD)", "AIFMD", "AIFMD Article 7 leverage; no AIF range."),
    _j("Code list: Exposure Method", "Commitment Method (AIFMD)", "AIFMD", "AIFMD Article 8 leverage; no AIF range."),
    _j("Code list: VaR Test Regime", "UCITS Relative VaR", "UCITS", "Re-sourced to the Rule 18f-4 relative VaR test (value kept)."),
    _j("Code list: VaR Test Regime", "UCITS Absolute VaR", "UCITS", "Re-sourced to the Rule 18f-4 absolute VaR test (value kept)."),
    _j("Code list: Risk Program Type", "UCITS Risk Management Process", "UCITS",
       "Directive 2010/43/EU Articles 38-45; the US programs are the Rule 22e-4 liquidity risk management program and the Rule 18f-4 derivatives risk management program (kept)."),
    _j("Code list: Risk Program Type", "AIFMD Risk Management Policy", "AIFMD", "AIFMD Article 15; no AIF range."),
    _j("Code list: Risk Limit Measure", "Commitment Global Exposure Percent", "UCITS",
       "UCITS commitment exposure limit; Rule 18f-4 limits are Relative VaR Ratio, Absolute VaR Percent of Net Assets and Derivatives Exposure Percent of Net Assets (kept)."),
    # Sources
    _j("Sources", "CESR/10-788 Guidelines on risk measurement and the calculation of global exposure and counterparty risk for UCITS", "UCITS",
       "Cited on 21 attributes as primary or secondary; re-sourced to SEC Rule 18f-4 (VaR tests, back-testing, horizon, lookback), Basel MAR concepts, ISDA or Internal (counterparty exposure)."),
    _j("Sources", "Commission Directive 2010/43/EU, Articles 38-45 (UCITS risk management)", "UCITS",
       "Was primary on Program Risk Lead (now Internal) and the source of the UCITS Risk Management Process value."),
    _j("Sources", "Directive 2009/65/EC (UCITS Directive), Articles 51-52", "UCITS",
       "Was primary on Counterparty Exposure Percent of Net Assets (now Internal; counterparty concentration limits are 33 rules)."),
    _j("Sources", "AIFMD (Directive 2011/61/EU) Articles 15-16 and Delegated Regulation (EU) 231/2013 Articles 6-11, 38-49 and Annex IV; ESMA AIFMD reporting IT technical guidance", "AIFMD",
       "Liquidity Horizon Bucket re-sourced to SEC Form PF; Exposure Method secondary dropped; Fund Borrowing Facility re-sourced to Form PF (private funds, W4)."),
    _j("Sources", "ESMA Guidelines on liquidity stress testing in UCITS and AIFs (ESMA34-39-897)", "Other EU/UK",
       "ESMA guidelines for UCITS and AIFs; Liquidity Stress Detail re-sourced to SEC Rule 22e-4 (assessment under reasonably foreseeable stressed conditions)."),
    _j("Sources", "Commission Delegated Regulation (EU) 2017/653 (PRIIPs KID RTS) as amended by Delegated Regulation (EU) 2021/2268, Annexes II, IV and V", "PRIIPs",
       "Removed with the Product Risk Indicators family."),
    _j("Sources", "Commission Regulation (EU) 583/2010 (UCITS KII) and CESR/10-673 SRRI methodology", "UCITS",
       "Removed with the Product Risk Indicators family."),
]

# ---------------------------------------------------------------------------------------------------------------------
# Decision of the US-only pass of 31 (decisions.DECISIONS format)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-931", "theme": "Scope", "title": "US-only pass of 31 Investment Risk",
     "domains": ["31", "01", "33", "35"],
     "issue": "The wholesale 31 measured risk for an asset manager running mutual funds, ETFs, CITs, SMAs, private markets and insurance-dedicated funds in the US and EU/UK. It carried the PRIIPs and UCITS product risk indicators and PRIIPs performance scenarios as a family, UCITS and AIFMD exposure methods, VaR tests, risk programs and a commitment limit measure, the UCITS positive mark-to-market counterparty method, and EU/UK sources (CESR/10-788, Directive 2010/43/EU, UCITS Articles 51-52, AIFMD and Regulation 231/2013, ESMA liquidity stress testing guidelines, the PRIIPs RTS, Regulation 583/2010). Its Business Line example used removed wholesale values.",
     "resolution": "1) Removed (26 JURISDICTION entries: UCITS 12, PRIIPs 8, AIFMD 4, FCA 1, Other EU/UK 1): the family Product Risk Indicators (RK-PRI, the last family, so no kept attribute ID moves) with Product Risk Indicator Calculation (14 attributes) and PRIIPs Performance Scenario (8 attributes); the local lists Product Risk Indicator Type and PRIIPs Scenario Type; the values Counterparty Exposure Method 'UCITS Positive Mark-to-Market', Exposure Method 'Commitment Approach (UCITS)', 'Sum of Notionals (UCITS)', 'Gross Method (AIFMD)', 'Commitment Method (AIFMD)', VaR Test Regime 'UCITS Relative VaR', 'UCITS Absolute VaR', Risk Program Type 'UCITS Risk Management Process', 'AIFMD Risk Management Policy', Risk Limit Measure 'Commitment Global Exposure Percent'; seven sources; two relationships; the derived and grain entries of the removed objects in enrich_31.py. "
                   "2) Re-sourced: VaR tests, designated reference portfolios, back-testing, horizon and lookback to SEC Rule 18f-4 alone (CESR/10-788 dropped from 21 attributes; Exceptions in Window, Back-Test Window Days, Back-Test P&L Basis and VaR Method gain Rule 18f-4 as secondary); risk programs to the Rule 22e-4 liquidity risk management program, the Rule 18f-4 derivatives risk management program and limited derivatives user policies, and Rule 2a-7 stress testing (Program Risk Lead to Internal); Liquidity Stress Detail (redemption shock, horizon, liquid assets, coverage ratio, days to meet redemptions) and the stress Model Inventory Entry to SEC Rule 22e-4; Stress Scenario Type to Rules 18f-4 and 22e-4; Liquidity Horizon Bucket (seven attributes and the list) and Fund Borrowing Facility to SEC Form PF; Exposure Counterparty to ISDA, Counterparty Exposure Amount, Counterparty Exposure Method and Counterparty Exposure Percent of Net Assets to Internal (counterparty concentration limits are 33 rules); Exposure Method to Rule 18f-4 alone. Sources 23 to 16. "
                   "3) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose (the firm's own funds, PF and IA lines; client account risk is 02, 45 and 46, CW-009), Scope, Core model, Design principles (3: 01 declares the Rule 18f-4 leverage calculation method and maximum leverage; 4: prospectus leverage and counterparty concentration limits are 33 rules; 7: 18 portfolios are never retail client accounts), Applies To, CDE, Primary / Secondary Reference, Notes (Regulation S-P, GLBA and state law; institutional separate accounts in place of SMA accounts) and Suggested next steps (the SRI step replaced by agreeing the 46 boundary); the shared PII note on portfolios reads 'institutional separate account'; '01 Global Exposure Method' re-pointed to 01 Leverage Calculation Method (CW-901 removed the former); '02 Client & Customer' reads the 02 party core; 25 is named Portfolio Trading & Execution; Stress Scenario Source 'Client Requested' reads institutional advisory client; SUMMARY in enrich_31.py. "
                   "4) Business Line (CW-004): Risk Limit.Limit Business Lines example 'Mutual Fund; ETF; Insurance-Dedicated Fund' becomes 'PF; IA'. 5) Re-points: none of a Reference type (Party, Investment Product, Share Class keep their names, CW-021). 6) Review fix pass (program-lead rulings): Exposure Method gains the US value 'Section 18 Asset Coverage' (Investment Company Act Section 18(f)(1) asset coverage of senior securities; the prospectus borrowing and leverage limit of a US fund), so the shared list (steward 31) has two values, 'Rule 18f-4 Derivatives Exposure' and 'Section 18 Asset Coverage'; the Leverage Percent of Net Assets note now points 33 derivatives exposure limits at the 18f-4 rows and borrowing and senior securities limits at the Section 18 rows; the Exposure Method note distinguishes the declared VaR test (01 Leverage Calculation Method) from the exposure measure; the UCITS term 'global exposure' is replaced in the Exposures family text, and the object group 'Leverage & Global Exposure' is renamed 'Leverage & Derivatives Exposure' (the object Leverage & Exposure Measurement keeps its name); source Investment Company Act Section 18 added. Counts: 8 to 7 families, 27 to 25 objects, 264 to 242 attributes, 85 to 79 CDEs (32.6%), 36 to 34 code lists, 44 to 42 relationships, 23 to 17 sources (16 after the pass, plus the Investment Company Act Section 18 source of the review fix pass).",
     "rationale": "CW-003 and CW-022: the firm sponsors US registered funds and CITs only, so the UCITS, AIFMD and PRIIPs regimes have no fund to apply to; the Rule 18f-4 and Rule 22e-4 programs, which already stood beside them, carry every generic object. Names of kept objects and attributes are unchanged so that DP-154 and DP-155 and the SM-10 model keep resolving; the readers of the removed family (DP-156, DP-242, SM-06, SM-10, the e8c models and the keys registry) are listed in NOTES. Private-fund items (Form PF buckets, 30 references) and the insurance-dedicated residue are left for the W4 decisions.",
     "action": "W1b", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
]

PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# Shared list re-cuts (31 is steward of Exposure Method and Risk Measure and a direct user of Business Line)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_RECUTS = [
    ("Exposure Method", "31",
     "Delete COMMITMENT_APPROACH_UCITS, SUM_OF_NOTIONALS_UCITS, GROSS_METHOD_AIFMD and COMMITMENT_METHOD_AIFMD and their "
     "value-map entries (shared_code_lists.py lines 2570-2573 and 2579); add SECTION_18_ASSET_COVERAGE 'Section 18 Asset "
     "Coverage' ('Asset coverage of senior securities under Investment Company Act Section 18(f)(1), including reverse "
     "repurchase agreements and similar financing a fund does not elect to treat as derivatives transactions under Rule "
     "18f-4(d)') and its value-map entry; keep RULE_18F_4_DERIVATIVES_EXPOSURE. Source becomes 'SEC Rule 18f-4 / Investment "
     "Company Act Section 18' (CW-039, program-lead ruling in the review fix pass). Two values, at the floor; direct user 33 "
     "(Exposure Method Read) names both in its example."),
    ("Risk Measure", "31",
     "Values unchanged; source becomes 'Internal / Basel MAR (concepts)' (CESR/10-788 dropped)."),
    ("Business Line", "09",
     "31 is a direct user: its one example now uses the CW-004 codes (PF; IA); no value map change."),
]

SHARED_CANDIDATES = []

# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "W1b (wealth), CW-931. Validation: taxonomy_builder.py content_31_investment_risk OK (7 families, 25 objects (1 attribute "
    "groups, 0 without grain), 242 attributes, 79 CDEs, 56 references, 4 derived, 0 unresolved, 34 code lists); before: 8 "
    "families, 27 objects, 264 attributes, 85 CDEs, 60 references, 5 derived, 36 code lists. check_enrichment.py 31 OK.",
    "READERS of removed objects and attributes (not edited; for the program lead and the product and model owners): "
    "data_products/framework.py line 979 (DP-156 'Product Risk Indicators & PRIIPs Scenarios': the whole product reads only the removed family; retire at WP0); "
    "data_products/specs_e2_invops_a.py lines 1601-1751 (DP-156 spec: metrics lines 1620-1683 read Product Risk Indicator Calculation and PRIIPs Performance Scenario, inputs lines 1686-1695, quality rules lines 1714-1717, notes lines 1719-1748); "
    "data_products/specs_e5_cross_area.py lines 309-311 and 366-367 (DP-242 'Current Approved Indicator' metric and inputs read Product Risk Indicator Calculation); "
    "data_models/models_e8c_invops_a.py lines 961-992 (DP-156 model: Fact Product Risk Indicator Calculation line 964, Fact PRIIPs Performance Scenario line 970, relationships lines 988-992); "
    "data_models/models_e8c_cross_area.py lines 330-331 and 416 (DP-242 Fact Product Risk Indicator); "
    "data_models/keys_e7_31_33.py lines 146-150 (keys of the two objects) and 393-397 (reference targets); "
    "semantic_model/models/sm_10_investment_risk_compliance.py line 4 (docstring), lines 403-445 (DP-156 entities risk_indicator and priips_scenario), lines 921-923 (joins), lines 1270-1317 (DP-156 metrics: Current Approved Indicator, MRM Class Tie-Out, SRRI Band Tie-Out, SRI Combination Tie-Out, SRRI Volatility Check, Proxy History Share, Calculations Overdue, Indicator Band Changes, Scenario Completeness and Order), lines 1504, 1578 and 1602-1605 (notes); "
    "semantic_model/models/sm_06_product_market.py lines 812-818 (DP-242 fund_risk_indicator entity: Product Risk Indicator Type, Calculated Indicator Value, Market Risk Class; SM-06 retires at WP0). "
    "Readers of removed values: semantic_model/models/sm_10_investment_risk_compliance.py lines 361-362 (liquidity_stress always_filter names 'UCITS Risk Management Process') and data_products/specs_e2_invops_a.py line 1439 (DP-155 metric 'Liquidity Stress Coverage' names the same value); data_products/specs_e2_invops_a.py line 1367 (DP-155 definition 'UCITS global exposure and AIFMD leverage'), lines 1376-1377 (DP-155 question names the UCITS VaR test) and line 1488 ('UCITS or AIFMD program types'); semantic_model/models/sm_10_investment_risk_compliance.py line 47 (question 'PRIIPs SRI or UCITS SRRI band'), line 1239 (metric 'Rule 18f-4 or UCITS VaR test') and line 1263 ('UCITS or AIFMD program'); semantic_model/models/sm_06_product_market.py lines 728-729 (risk_indicator attribute 'from DP-156') and line 1047 (join on fund_risk_indicator.indicator_share_class); data_products/specs_e3_ta_fund_governance.py lines 1285-1286 and 1456 (DP-156 named as PRIIPs and SRRI); data_models/models_e8c_invops_a.py line 998 (DP-156 notes); data_products/specs_e3_ta_fund_governance.py line 1351 (DP-186 metric reads Leverage & Exposure Measurement for the removed AIFMD gross and commitment Exposure Method values) and data_models/models_e8c_ta_fund_governance.py line 992 (DP-186 note 'AIFMD gross and commitment leverage'); shared_code_lists.py lines 2566-2580 (Exposure Method, SHARED_RECUTS). "
    "Registers: consolidation/gaps_register.py lines 3675-3679 (GAP-31-003 on PRIIPs Performance Scenario and Product Risk Indicator Calculation: drop) and line 3935 (resolved GAP naming Product Risk Indicator Calculation). Generated outputs refresh on rebuild.",
    "References to domains retiring or replaced later, left as they are (W4): Leverage & Exposure Measurement.Fund Borrowing Facility (Reference (Fund Credit Facility, 30)); Liquidity Horizon Bucket.Bucket Private Fund Profile (Reference (Private Fund Profile, 30)) and the Investor Liquidity Percent note (30 investor holdings); the two relationships to 30; overview Scope '(30 Private Markets)' and Core model '30 fund credit facilities'; SUMMARY references. "
    "Private-fund content for the W4 decision with 30: the Liquidity Horizon Bucket object (now sourced to Form PF only), Form PF in the Purpose and the 35 filing relationship. Insurance-dedicated residue for the W4 decision: the NAIC Model 280 source and the Stress Scenario Source value 'Insurer Requested'.",
    "Shared Regulator: Risk Program Designation.Program Regulator example 'SEC' is a kept US value.",
    "Other domains' content seen: 01 Leverage Method values are 'Relative VaR Test' and 'Absolute VaR Test' (the VaR Test Regime list source names them); 35 Reportable Fund Event and Fund Regulatory Filing read RLEX- and the liquidity objects (unchanged).",
    "Remaining hits of the step 1 grep, justified: 'NAIC Model 280' in the Purpose and source and 'Insurer Requested' (W4 insurance residue, listed above). No MiFID, UCITS, AIFMD, CESR, ESMA, PRIIPs, SRRI, GDPR or 'SMA' hit remains in the module text (the Python constant SMA keeps its name and now reads 'institutional separate account').",
    "Group rename (review fix pass): object group 'Leverage & Global Exposure' is now 'Leverage & Derivatives Exposure' in family Exposures; no reader keys on the group name (GRAIN keys are family x object).",
    "Unverified: none of the re-sourcing introduces a new rule number; Rule 22e-4(b)(1)(i) is cited for liquidity stress as the assessment of liquidity risk under normal and reasonably foreseeable stressed conditions (confirm the paragraph).",
]
