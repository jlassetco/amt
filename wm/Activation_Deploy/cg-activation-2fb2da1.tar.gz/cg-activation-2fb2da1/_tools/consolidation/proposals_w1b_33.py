"""W1b proposals of Data Domain 33 Investment Compliance (wealth model; kept with the US-only and perspective pass). Brief:
00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (33); decisions CW-003, CW-004, CW-009, CW-021, CW-022, CW-039;
plan section 5.1 row 33. Declarative only: the program lead merges DECISIONS into decisions.py, appends JURISDICTION to
jurisdiction.REMOVALS and applies SHARED_RECUTS to shared_code_lists.py at merge (W5 for the shared lists, CW-039). The
existing proposals_33.py (expansion) is unchanged.
"""

_D = "CW-933"


def _j(obj, attr, regime, note):
    return {"domain": "33", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


_RR = "Local copy of the 01 Regulatory Regime list; removed as in 01 (CW-901, CW-039)."

# ---------------------------------------------------------------------------------------------------------------------
# Jurisdiction register entries (jurisdiction.REMOVALS format). Objects and attributes use the wholesale-v1.0 names.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = [
    # Attributes
    _j("Breach Review", "Depositary Notification Date", "UCITS",
       "Notice of a breach to the UCITS depositary (UCITS Directive) or the UK depositary or trustee (FCA COLL); US funds have a custodian, not a depositary with oversight duties. "
       "Board escalation stays (Board Reportable Indicator); a CIT trustee is informed through the same board and trustee reporting (35)."),
    # Code-list values: Regulatory Regime (local copy of the 01 list)
    _j("Code list: Regulatory Regime", "UCITS", "UCITS", _RR),
    _j("Code list: Regulatory Regime", "UK UCITS", "UCITS", _RR),
    _j("Code list: Regulatory Regime", "EU AIF", "AIFMD", _RR),
    _j("Code list: Regulatory Regime", "ELTIF", "Other EU/UK", "EU ELTIF Regulation. " + _RR),
    _j("Code list: Regulatory Regime", "EU MMF", "Other EU/UK", "EU Money Market Funds Regulation; US money market funds are Rule 2a-7 funds under 'US 1940 Act Registered'. " + _RR),
    _j("Code list: Regulatory Regime", "UK NURS", "FCA", "UK non-UCITS retail scheme (FCA COLL 5). " + _RR),
    _j("Code list: Regulatory Regime", "UK QIS", "FCA", "UK qualified investor scheme (FCA COLL 8). " + _RR),
    _j("Code list: Regulatory Regime", "Lux SIF", "AIFMD", "Luxembourg specialized investment fund. " + _RR),
    _j("Code list: Regulatory Regime", "Lux RAIF", "AIFMD", "Luxembourg reserved alternative investment fund. " + _RR),
    _j("Code list: Regulatory Regime", "Irish QIAIF", "AIFMD", "Irish qualifying investor AIF. " + _RR),
    _j("Code list: Regulatory Regime", "Cayman Regulated Mutual Fund", "Other non-US",
       "Cayman CIMA regime of an own offshore fund; removed as in 01 (CW-901). A client firm with offshore feeders restores it."),
    # Sources
    _j("Sources", "UCITS Directive 2009/65/EC, Articles 50-57, and Commission Directive 2007/16/EC (eligible assets)", "UCITS",
       "Rule libraries re-sourced to the Investment Company Act (Sections 5(b)(1), 12(d), 18), SEC Rules 2a-7, 12d1-4, 12d3-1, 18f-4 and 35d-1 and IRC Subchapter M; "
       "Look-Through Indicator to Rule 12d1-4, Cure Deadline Date to Rule 35d-1, Breach Type secondary dropped."),
    _j("Sources", "UK FCA Handbook COLL 5 (investment and borrowing powers)", "FCA", "Removed with the UK regime values and Depositary Notification Date."),
    _j("Sources", "EU Money Market Funds Regulation (EU) 2017/1131", "Other EU/UK", "Money market fund rules are SEC Rule 2a-7 (kept)."),
    _j("Sources", "AIFMD 2011/61/EU, Delegated Regulation (EU) 231/2013 Articles 6-11, and AIFMD II Directive (EU) 2024/927", "AIFMD",
       "Exposure Method Read re-sourced to SEC Rule 18f-4 (prospectus derivatives exposure caps); the AIFMD II loan-origination leverage and single-borrower limits have no US fund to apply to."),
    _j("Sources", "MiFID II Delegated Regulation (EU) 2017/565 Article 54 (suitability, sustainability preferences)", "MiFID II",
       "Client restrictions of institutional mandates rest on the investment management agreement (Rule Source Type 'Client Restriction'); retail suitability is Reg BI in 45 and 48."),
    _j("Sources", "CSSF Circular 24/856 (investor protection in case of NAV calculation error, non-compliance with investment rules and other errors, 29 March 2024)", "Other EU/UK",
       "Luxembourg CSSF circular; Material Breach Indicator rests on SEC Rule 38a-1 (material compliance matters), Loss Calculation Method, Related NAV Error Case and Regulatory Notification Required Indicator on Internal (firm breach and NAV error policy)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# Decision of the US-only pass of 33 (decisions.DECISIONS format)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-933", "theme": "Scope", "title": "US-only pass of 33 Investment Compliance",
     "domains": ["33", "01", "31", "45", "46", "48"],
     "issue": "The wholesale 33 coded investment restrictions for an asset manager with UCITS, UK, Luxembourg and Irish fund ranges beside its US funds. It carried a depositary breach notification date, a local copy of the 01 Regulatory Regime list with EU, UK, Luxembourg, Irish and Cayman values, UCITS rule libraries and rule examples (UCITS 5/10/40, 52(1) single issuer 10%), AIFMD leverage cap examples, ManCo and AIFM compliance functions, and EU/UK sources (UCITS Directive and Directive 2007/16/EC, FCA COLL 5, the EU MMF Regulation, AIFMD and AIFMD II, MiFID II Delegated Regulation 2017/565 Article 54, CSSF Circular 24/856). Its Business Line example used removed wholesale values.",
     "resolution": "1) Removed (18 JURISDICTION entries: AIFMD 5, UCITS 4, Other EU/UK 4, FCA 3, MiFID II 1, Other non-US 1): Breach Review.Depositary Notification Date (the two later attributes of Breach Review, CCO Sign-Off By and CCO Sign-Off Date, move up one attribute ID within the family Breaches & Remediation); Regulatory Regime values UCITS, UK UCITS, EU AIF, ELTIF, EU MMF, UK NURS, UK QIS, Lux SIF, Lux RAIF, Irish QIAIF and Cayman Regulated Mutual Fund (as in 01, CW-901); six sources. No object removed. "
                   "2) Re-sourced: rule libraries and examples to the 1940 Act (the library example becomes '1940 Act Diversified 75-5-10', Library Regulatory Regimes 'US 1940 Act Registered', the rule example 'ICA 12(d)(1)(A)(iii) investment companies 10% hard' with measurement basis '% of Total Assets' and the provision example 'ICA 12(d)(1)(A)(iii) investment companies 10%'; the Core model cites Sections 5(b)(1), 12(d)(1)(A)(iii) and IRC 851(b)(3)); Look-Through Indicator to SEC Rule 12d1-4; Exposure Method Read to SEC Rule 18f-4 (example: a prospectus cap on derivatives exposure); Cure Deadline Date to SEC Rule 35d-1; Material Breach Indicator to Rule 38a-1 alone; Loss Calculation Method (and its list), Related NAV Error Case and Regulatory Notification Required Indicator to Internal; Breach Type secondary dropped; Rule Type values Concentration, Liquidity and Risk Measure Limit reworded to US rules (OTC counterparty exposure, Rule 2a-7, Rule 18f-4); ERISA, OCC 12 CFR 9.18, IRC 851 and 817(h) kept. Sources 20 to 14. "
                   "3) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose (PF and IA lines; answers to the CCO under Rule 38a-1 and Rule 206(4)-7; client-account checks are 45, 46 and 48), Scope (02 Client & Household, Client Restriction keeps its name; 25 Portfolio Trading & Execution; 15 Account Restrictions, client order checks, Reg BI evidence and managed account drift out of scope), Core model, Design principles (3: prospectus leverage and derivatives exposure caps), Notes (Regulation S-P, GLBA and state law; institutional separate accounts in place of SMA portfolios) and Suggested next steps (ManCo and AIFM officers replaced by the fund boards; agree the client-account boundary with 46 and 48); the shared PII constant SMAP (on Assigned Portfolio, Result Portfolio, Breached Portfolio, Waived Portfolio and Checked Portfolio) keeps its name and now reads 'PII where the portfolio implements an institutional separate account held by an individual or a personal trust' (corrected in the review fix pass); Interpretation Note example no longer names a depositary; Waiver Basis 'Client Written Consent' reads institutional client and 'Board Approval' reads fund board or CIT trustee; Board Reportable Indicator reads fund board or CIT trustee; SUMMARY in enrich_33.py. "
                   "4) Business Line (CW-004): Rule Library.Library Business Lines example 'Mutual Fund; ETF' becomes 'PF'. 5) Re-points: Reference (Client Restriction) kept (CW-021); 'SMA' text reads 'institutional separate account' (IA line, CW-009). 6) Additions: none. Counts: 6 families and 25 objects unchanged, 240 to 239 attributes, 74 CDEs (31.0%), 33 code lists, 41 relationships, 20 to 14 sources.",
     "rationale": "CW-003 and CW-022: the firm sponsors US registered funds and CITs and manages US institutional mandates, so the EU/UK fund regimes have no portfolio to test; every generic object (rules, libraries, breaches, waivers) keeps its US instance under the 1940 Act, ERISA, the OCC CIT rule and the Internal Revenue Code. Names are unchanged so that DP-161 to DP-163 and SM-10 keep resolving; the one removed attribute is read by DP-163 and SM-10 (NOTES).",
     "action": "W1b", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# Shared list re-cuts (33 is steward of Compliance Check Outcome, Breach Type and Cure Action, which carry no EU/UK value,
# and a direct user of Business Line, Measurement Basis, Exposure Method and Regulator)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_RECUTS = [
    ("Measurement Basis", "01",
     "For the steward 01: the value PCT_OF_CAPITAL '% of Capital' is described as 'AIFMD II single-borrower limit (20% of AIF "
     "capital)' (shared_code_lists.py line 2018); 33 no longer cites AIFMD. Re-describe it as 'Private fund document limits on "
     "a share of fund capital' (W4 decision with 30) or remove it if no 01 restriction uses it."),
    ("Business Line", "09",
     "33 is a direct user: its one example now uses the CW-004 code PF; no value map change."),
    ("Regulatory Regime", "01",
     "33 keeps a local copy of the 01 list (US 1940 Act Registered, US Private Fund 3(c)(1) and 3(c)(7), US Bank CIT) plus its two "
     "proposed additions (IRC 817(h) Insurance-Dedicated, ERISA Plan Assets). At W5 33 may cite the shared list directly once the "
     "steward decides the two additions; IRC 817(h) Insurance-Dedicated is a W4 retirement candidate (insurance-dedicated funds)."),
]

SHARED_CANDIDATES = []

# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "W1b (wealth), CW-933. Validation: taxonomy_builder.py content_33_investment_compliance OK (6 families, 25 objects (1 "
    "attribute groups, 0 without grain), 239 attributes, 74 CDEs, 57 references, 1 derived, 0 unresolved, 33 code lists); "
    "before: 240 attributes, 74 CDEs, 57 references, 33 code lists. check_enrichment.py 33 OK.",
    "READERS of the removed attribute (not edited; for the program lead and the product and model owners): "
    "data_products/specs_e2_invops_b.py line 1247 (DP-163 metric 'Escalations Pending' inputs: Breach Review.Depositary Notification Date) and line 1286 (DP-163 inputs list); "
    "semantic_model/models/sm_10_investment_risk_compliance.py line 821 (breach_review dimension depositary_notification_date); "
    "data_products/specs_e2_invops_b.py lines 1164 and 1173 (DP-163 definition and question name 'board, depositary and regulator escalation'). "
    "No data model or key registry names it. Readers of the removed Regulatory Regime values: none found in data_products, data_models or semantic_model "
    "(the 01 list's own readers are recorded under CW-901). Generated outputs refresh on rebuild.",
    "References to domains retiring or replaced later, left as they are (W4): Pre-Trade Check Subject.Tested Deal (Reference (Deal, 30)); Compliance Check Run Type value 'Deal Pre-Approval' (private markets deals, 30); the relationship to Deal [30]; overview Scope 'deals (30 Private Markets)' and Core model '30 Deal for a private fund'; SUMMARY. "
    "12 Breach Notification, Guideline Monitoring Arrangement and Compliance Certificate references (12 adapted at W4) are unchanged. "
    "Insurance-dedicated residue for the W4 decision: Regulatory Regime value 'IRC 817(h) Insurance-Dedicated', the IRC 817(h) and Treasury Regulation 1.817-5 source, the NAIC Model 280 / 283 source, Evidential Period-End Run Indicator's 817(h) example (kept beside the RIC test), Provision Regulator note on 817(h).",
    "Boundary stated (CW-009, CW-010, CW-008): client-account checks of the brokerage and advice businesses (order suitability and restrictions in 48, Reg BI evidence in 45, managed account drift in 46) are outside 33; 33 tests fund, CIT and institutional separate account portfolios (18).",
    "Remaining hits of the step 1 grep, justified: IRC 817(h), Treasury Regulation 1.817-5 and NAIC Models 280 / 283 (US insurance-dedicated residue, W4). No MiFID, UCITS, AIFMD, FCA, COLL, CSSF, ManCo, depositary, GDPR or 'SMA' hit remains in the module text (the Python constant SMAP keeps its name).",
    "Other domains' content seen: 01 Measurement Basis value '% of Capital' still describes the AIFMD II limit (SHARED_RECUTS); 12 Breach Type and Cure Action copies are unaffected.",
    "Unverified: none; the new examples cite statute sections already in the module's sources (ICA Section 12(d)(1)(A)(iii) under the Investment Company Act source; Rule 12d1-1 money market fund exclusion in the Interpretation Note example is from working knowledge, confirm with fund counsel).",
]
