"""W1b proposals of Data Domain 34 Stewardship & Sustainable Investing (wealth model; kept with the US-only and
perspective pass and the investor choice addition of plan section 5.1 row 34). Brief: 00_Program/Rework/Briefs/
W1b_Carry_Over_Pass.md section 4 (row 34); decisions CW-003, CW-004, CW-021, CW-022, CW-039. Declarative only: the program
lead merges DECISIONS into decisions.py and appends JURISDICTION to jurisdiction.REMOVALS at merge. The existing
proposals_34.py (expansion) is unchanged.
"""

_D = "CW-934"


def _j(obj, attr, regime, note):
    return {"domain": "34", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


# ---------------------------------------------------------------------------------------------------------------------
# Jurisdiction register entries (jurisdiction.REMOVALS format). Objects and attributes use the wholesale-v1.0 names.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = [
    # Objects
    _j("Sustainable Investment Determination", "", "SFDR",
       "SFDR Article 2(17) sustainable investment test (contribution, DNSH, good governance) with EU Taxonomy-aligned turnover and "
       "CapEx; 10 attributes and one relationship. No US regime defines a sustainable investment; the firm's own ESG view stays in "
       "Firm ESG Assessment and the exclusion lists, and sustainable bond labels stay in 17."),
    _j("PAI Calculation", "", "SFDR",
       "SFDR Article 4 and 7 principal adverse impact statement header (PAIC-); 9 attributes and two relationships. Portfolio "
       "Sustainability Metric keeps the indicator values without the statement."),
    _j("Product Sustainability Outcome", "", "SFDR",
       "Achieved proportions of SFDR Article 8 and 9 periodic disclosures (Annex IV, V) and the UK SDR 70% asset test; 13 attributes "
       "and one relationship. US ESG funds have no achieved-proportion disclosure; 01 keeps the ESG characteristics."),
    _j("Signatory Status", "", "UK Stewardship Code",
       "FRC signatory status granted on a UK Stewardship Code report; 6 attributes and one relationship. PRI signatory status is a "
       "Collaborative Initiative Membership and PRI scores sit on Stewardship Report.Framework Assessment Result."),
    # Attributes
    _j("Sustainability Indicator Definition", "SFDR PAI Table", "SFDR", "SFDR RTS Annex I table of the indicator."),
    _j("Sustainability Indicator Definition", "SFDR PAI Indicator Number", "SFDR", "SFDR RTS Annex I indicator number."),
    _j("Portfolio Sustainability Metric", "Reporting PAI Calculation", "SFDR", "Reference to the removed PAI statement."),
    _j("Portfolio Sustainability Metric", "PAI Actions Taken", "SFDR", "SFDR Annex I actions taken column of a PAI statement."),
    # Code-list values: whole local lists
    *[_j("Code list: SFDR PAI Table", v, "SFDR", "Whole list removed with the attribute.")
      for v in ("Table 1 - Mandatory", "Table 2 - Additional Climate and Environment", "Table 3 - Additional Social and Governance",
                "Not an SFDR PAI Indicator")],
    _j("Code list: Sustainable Investment Framework", "SFDR Article 2(17) Sustainable Investment", "SFDR", "Whole list removed with the object."),
    _j("Code list: Sustainable Investment Framework", "EU Taxonomy Alignment", "EU Taxonomy", "Whole list removed with the object."),
    _j("Code list: Sustainable Investment Framework", "UK SDR Sustainability Objective", "FCA", "Whole list removed with the object (FCA ESG 4)."),
    _j("Code list: Sustainable Investment Framework", "ICMA Use-of-Proceeds Assessment", "SFDR",
       "Regime tag is that of the removed object (SFDR); ICMA itself is market-neutral. Removed with the object it framed. A firm assessment of labeled bonds can be added to Firm ESG Assessment if needed."),
    _j("Code list: Sustainable Investment Framework", "EU Green Bond Standard", "Other EU/UK", "Regulation (EU) 2023/2631; whole list removed with the object."),
    *[_j("Code list: Sustainability Objective Type", v, "SFDR", "Whole list removed with Contribution Objective Type (SFDR Art 2(17)).")
      for v in ("Environmental", "Social", "Environmental and Social")],
    _j("Code list: Outcome Disclosure Regime", "SFDR Article 8 (Annex IV)", "SFDR", "Whole list removed with the object."),
    _j("Code list: Outcome Disclosure Regime", "SFDR Article 9 (Annex V)", "SFDR", "Whole list removed with the object."),
    _j("Code list: Outcome Disclosure Regime", "UK SDR Product Disclosure", "FCA", "Whole list removed with the object."),
    *[_j("Code list: Signatory Status", v, "UK Stewardship Code", "Whole list removed with the object (FRC).")
      for v in ("Applicant", "Signatory", "Not Approved", "Withdrawn", "Lapsed")],
    # Code-list values: single values
    _j("Code list: Metric Framework", "SFDR PAI", "SFDR", "TCFD / ISSB, NZAM Progress and Internal stay."),
    _j("Code list: Metric Framework", "FCA ESG Sourcebook", "FCA", "FCA ESG 2 entity and product reports."),
    _j("Code list: Metric Framework", "EU Climate Benchmark", "BMR", "EU climate benchmark reporting of the firm's own metrics; tracked-index exclusions stay on Exclusion Policy Basis."),
    _j("Code list: Metric Calculation Standard", "SFDR RTS Annex I", "SFDR", "PAI indicator formulas."),
    _j("Code list: Metric Calculation Standard", "EU Climate Benchmark", "BMR", "Delegated Regulation (EU) 2020/1818 calculation of the firm's own metrics."),
    _j("Code list: Proxy Voting Report Type", "SRD II Voting Disclosure", "Other EU/UK",
       "Shareholder Rights Directive II Art 3g(1)(b) public voting disclosure; Form N-PX and the client account voting report stay."),
    _j("Code list: Stewardship Framework", "UK Stewardship Code 2026 - Policy and Context Disclosure", "UK Stewardship Code",
       "Replaced in the US list by Firm Stewardship Report (voluntary)."),
    _j("Code list: Stewardship Framework", "UK Stewardship Code 2026 - Activities and Outcomes Report", "UK Stewardship Code", "As above."),
    _j("Code list: Stewardship Framework", "FCA ESG Sourcebook - Entity Report", "FCA", "Replaced by Voluntary Climate Report (TCFD / IFRS S2)."),
    _j("Code list: Stewardship Framework", "FCA ESG Sourcebook - Product Report", "FCA", "As above."),
    _j("Code list: Stewardship Framework", "SRD II Engagement Policy Disclosure", "Other EU/UK", "SRD II Art 3g(1)(a)."),
    # Sources
    _j("Sources", "UK Stewardship Code 2026 (FRC, in force 1 January 2026) and How to report on the UK Stewardship Code 2026", "UK Stewardship Code",
       "Was the reference of engagement, escalation, rationale and report attributes; they now cite Internal, PRI or ICGN."),
    _j("Sources", "Shareholder Rights Directive II: Directive (EU) 2017/828 amending Directive 2007/36/EC, Art 3c (confirmation of votes) and Art 3g (engagement policy and voting disclosure)", "Other EU/UK",
       "Vote confirmation re-sourced to ISO 20022 seev.006 / seev.007; voting disclosure to Form N-PX and Rule 206(4)-6."),
    _j("Sources", "SFDR: Regulation (EU) 2019/2088, Art 2(17), Art 4 and Art 7", "SFDR", "Removed with the determination, PAI statement and outcome objects."),
    _j("Sources", "SFDR RTS: Commission Delegated Regulation (EU) 2022/1288 (Annex I PAI statement template and indicators; Annex IV and Annex V periodic disclosures for Article 8 and Article 9 products)", "SFDR",
       "Metric and indicator references re-sourced to Internal, IFRS S2, PCAF or the GHG Protocol."),
    _j("Sources", "European Commission proposal to amend SFDR (20 November 2025)", "SFDR", "Dependency of the removed entity PAI statement."),
    _j("Sources", "EU Taxonomy Regulation (EU) 2020/852 and Disclosures Delegated Act (Delegated Regulation (EU) 2021/2178)", "EU Taxonomy",
       "Removed with the taxonomy-alignment attributes of the determination and outcome objects."),
    _j("Sources", "FCA ESG sourcebook (ESG 2 TCFD entity and product reports; ESG 4 sustainability labels) and PS23/16 Sustainability Disclosure Requirements", "FCA",
       "Entity climate references re-sourced to IFRS S2; UK SDR label test removed."),
    _j("Sources", "FinDatEx European ESG Template (EET)", "FinDatEx", "Fed the removed product outcome."),
    _j("Sources", "ICMA Green Bond, Social Bond and Sustainability Bond Principles", "SFDR",
       "Regime tag is that of the removed object (SFDR); ICMA is market-neutral, used only by the removed Sustainable Investment Determination; 17 keeps ICMA for the sustainable bond label."),
]

# ---------------------------------------------------------------------------------------------------------------------
# Wording re-points (object, attribute, before, after, decision)
# ---------------------------------------------------------------------------------------------------------------------
REPOINTS = [
    ("Stewardship Policies (family)", "", "for each portfolio or SMA account", "for each portfolio or client account (an institutional separate account or another account that delegates voting)", _D),
    ("Voting Authority (group)", "", "each portfolio or SMA account", "each portfolio or client account", _D),
    ("Voting Authority Arrangement", "Authority Account", "SMA or institutional account the arrangement covers", "Client account the arrangement covers: an institutional separate account of the IA line, or another client account that delegates voting authority to the firm", _D),
    ("Ballot", "Ballot Safekeeping Account", "individual SMA client", "individual client", _D),
    ("Proxy Voting Report", "Reporting Client Account", "SMA or institutional client account", "Client account (an institutional separate account or another account that delegates voting)", _D),
    ("Code list: Proxy Voting Report Type", "SMA Client Voting Report", "SMA Client Voting Report", "Client Account Voting Report", _D),
    ("Relationships", "Voting Authority Arrangement may cover Account [15]", "SMA and institutional client accounts.", "Institutional separate accounts (IA line) and other client accounts that delegate voting authority.", _D),
    ("Overview Scope", "", "(02 Client & Customer)", "(02 Client & Household)", _D),
]

# ---------------------------------------------------------------------------------------------------------------------
# Decision of the US-only pass of 34 (decisions.DECISIONS format)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-934", "theme": "Scope", "title": "US-only pass of 34 Stewardship & Sustainable Investing",
     "domains": ["34"],
     "issue": "The wholesale 34 described an asset manager that votes for funds, ETFs, CITs, SMAs, private funds and insurance-dedicated portfolios and distributes in the US, the EU and the UK. It mastered three SFDR objects (Sustainable Investment Determination with EU Taxonomy alignment, PAI Calculation, Product Sustainability Outcome with the UK SDR asset test) and the FRC Signatory Status, tagged metrics with SFDR PAI and FCA ESG frameworks, cited the UK Stewardship Code 2026 and SRD II on engagement, rationale, vote confirmation and reports, and listed SFDR, EU Taxonomy, UK SDR, EU Green Bond Standard, FCA ESG and SRD II values. It did not hold the investor choice proxy voting options plan section 5.1 names for 34.",
     "resolution": "Affects 01 (ESG characteristics stay there) and 13 (the investor choice election, W2), noted below. 1) Removed (48 JURISDICTION entries: SFDR 24, UK Stewardship Code 9, FCA 6, Other EU/UK 4, BMR 2, EU Taxonomy 2, FinDatEx 1): objects Sustainable Investment Determination (10 attributes), PAI Calculation (9), Product Sustainability Outcome (13), Signatory Status (6) and their five relationships; attributes Sustainability Indicator Definition.SFDR PAI Table and SFDR PAI Indicator Number, Portfolio Sustainability Metric.Reporting PAI Calculation and PAI Actions Taken; lists SFDR PAI Table, Sustainable Investment Framework, Sustainability Objective Type, Outcome Disclosure Regime, Signatory Status; values Metric Framework SFDR PAI, FCA ESG Sourcebook, EU Climate Benchmark, Metric Calculation Standard SFDR RTS Annex I and EU Climate Benchmark, Proxy Voting Report Type SRD II Voting Disclosure, Stewardship Framework (two UK Stewardship Code reports, two FCA ESG reports, SRD II engagement policy); sources UK Stewardship Code 2026, SRD II, SFDR, SFDR RTS, the SFDR review proposal, EU Taxonomy Regulation, FCA ESG sourcebook, FinDatEx EET and the ICMA principles (used only by the removed determination). "
                   "2) Re-sourced: proxy voting disclosure to Form N-PX (Rule 30b1-4), Rule 14Ad-1 and Rule 206(4)-6 (Vote Rationale Text, Pre-Declared Vote Indicator, Policy Document Location, Reporting Manager Entity; Client Account Voting Report); Vote Confirmation Status to ISO 20022 seev.006 / seev.007; engagement to SEC Schedule 13D / 13G guidance (Engagement family text, source retitled) with the UK Stewardship Code references of Engagement ID, Engaged Party, Engagement Theme, Engagement Outcome, Objective Description, Interaction Summary, Escalation Action Type and two list sources replaced by PRI, ICGN or Internal; indicator and metric references (Indicator Name, Level, Unit, Metric Product, Legal Entity, Indicator, Period End Date, Emission Scopes Included, Measurement Basis, Value, Normalization Currency, Coverage, Data Basis, Observation Data Basis) to Internal, IFRS S2, PCAF or the GHG Protocol with USD examples; Stewardship Framework re-cut to Firm Stewardship Report, Voluntary Climate Report (TCFD / IFRS S2), PRI Reporting Framework, NZAM Progress Report, Other, and the report attributes to Internal; Exclusion Policy Basis and Revenue Threshold Percentage to Internal, with EU BMR Delegated Regulation 2020/1818 Art 12 kept as a secondary reference and source for the Paris-aligned and climate transition index exclusions (index methodology of tracked indexes, CW-022). "
                   "3) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose, Scope, Core model, Design principles (6 rewritten, 10 added on investor choice), Applies To, CDE, Notes and Suggested next steps; family and group texts of Stewardship Policies, Voting Policies & Guidelines, Voting Authority, Engagement, ESG Data & Assessments, Firm Assessments, Portfolio Sustainability Metrics & Product Outcomes (name and code kept), Stewardship Disclosure & Reporting and Stewardship Reports & Status; enrich_34 SUMMARY; Source_Notes header, purpose, section 1 and section 6. Attribute IDs renumber within Stewardship Policies (Voting Policy additions), ESG Data & Assessments (Indicator Definition, the determination), Portfolio Sustainability Metrics & Product Outcomes and Stewardship Disclosure & Reporting. "
                   "4) Re-pointed (CW-021, CW-023, IA line): 'SMA account' and 'SMA or institutional account' read client account (an institutional separate account of the IA line or another account that delegates voting) in five places; Proxy Voting Report Type value SMA Client Voting Report relabeled Client Account Voting Report; 02 Client & Household (REPOINTS, 8 entries). No reference retyped. "
                   "5) Added (plan section 5.1 row 34): Voting Policy.Voting Choice Option Type (local list Voting Choice Option Type: Fund Adviser Policy, Board-Aligned, Third-Party Benchmark, Values-Based, Not Voting, Other) and Voting Policy.Voting Choice Offered Funds (Reference (Product) (multi)); relationship Voting Policy is offered as an investor choice option to shareholders of Investment Product [01]; the shareholder's election is left to 13 (W2). "
                   "6) Kept on purpose: foreign investee meetings and markets; IFRS S2, PCAF, GHG Protocol, NZAM, PRI, ICGN (market-neutral standards); EU BMR 2020/1818 index exclusions (tracked-index methodology). Counts: 30 to 26 objects, 277 to 237 attributes, 90 to 74 CDEs (31%), 42 to 38 code lists, 53 to 49 relationships, 26 to 17 sources, 20 to 19 PII attributes. SM-08 certified metric sources unchanged.",
     "rationale": "CW-003 and CW-022: the firm is regulated and distributes in the US only, so SFDR, the EU Taxonomy, UK SDR, the UK Stewardship Code and SRD II have no disclosure to feed, while voting, engagement, ESG data and climate metrics are generic and stay with US or market-neutral sources; the investment universe (foreign investee companies, tracked indexes) is not narrowed. Plan section 5.1 row 34 adds the investor choice voting options that a Vanguard-type firm offers its fund shareholders. Names are kept so that DP-133, DP-134 and the SM-08 sustainability views keep resolving; DP-135 and the 42 publication link lose the removed objects (READERS). Lever: a UK or EU extension restores the removed rows from wholesale-v1.0 through the jurisdiction register.",
     "action": "W1b", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# Shared lists: 34 stewards GHG Scope Category (unchanged) and cites nine enterprise lists directly (no EU/UK values used).
# ---------------------------------------------------------------------------------------------------------------------
SHARED_RECUTS = []

SHARED_CANDIDATES = [
    ("Voting Choice Option Type", None, ["13"],
     "New local list (W1b). The 13 drafter (W2) records each fund shareholder's investor choice election against these options; if "
     "13 needs the option type on the election row, make it a shared list stewarded by 34 rather than a 13 copy."),
]

# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "W1b (wealth), CW-934. Validation: taxonomy_builder.py content_34_stewardship_and_sustainable_investing OK (7 families, 26 objects "
    "(2 attribute groups, 0 without grain), 237 attributes, 74 CDEs, 65 references, 4 derived, 0 unresolved, 38 code lists); before: "
    "30 objects, 277 attributes, 90 CDEs, 72 references, 42 code lists. check_enrichment.py 34 OK. JURISDICTION 48 entries.",
    "READERS of the removed objects and attributes (not edited; for the program lead and the product, model and semantic owners): "
    "data_products/specs_e2_portfolio_stewardship.py line 777 (DP-132 definition names the removed SRD II disclosure), lines 952-955, 977-978 (DP-133), 1054-1056, 1087, 1096-1099 (DP-134), 1124, 1139, "
    "1169-1180, 1199-1237, 1245, 1268-1269, 1285, 1300-1302 (DP-135 reads PAI Calculation, SFDR PAI Table, Sustainable Investment "
    "Determination, Product Sustainability Outcome and the taxonomy and sustainable investment shares; already listed for WP0 as largely "
    "EU in scope); data_products/specs_i_product_data.py line 290 (01 minimum sustainable and taxonomy-aligned investment %, removed by "
    "CW-901); data_products/specs_e4_technology_communications.py lines 1037 and 1090 (42 Publication Source Link.Source PAI Calculation); "
    "data_models/keys_e7_34_35.py lines 43, 100-101, 111, 118, 131, 280-281, 288-290, 296, 298-299, 316-318 (keys of the four removed "
    "objects); data_models/models_e8c_portfolio_stewardship.py lines 729-730, 773-775, 818-819, 857-858, 894-897, 927, 935-941; "
    "data_models/keys_e7_42_44.py lines 57 and 270 and data_models/models_e8c_technology_communications.py lines 717 and 804 (42 link to "
    "PAI Calculation); semantic_model/models/sm_08_investment_book_performance.py lines 649-798, 1103-1175, 1842, 1878, 1949-1994 (DP-135 "
    "sustainability entities and measures; no certified SM-08 measure reads 34); semantic_model/models/sm_17_technology_data_communications.py "
    "lines 537, 1000, 1849; semantic_model/models/sm_16_risk_compliance_legal_audit.py line 284.",
    "Registers that name the removed content (not edited): consolidation/decisions.py lines 1167 (CD-228) and 1174 (CD-229 PAI and outcomes), 1727 (DP-064 outcome reads), "
    "2417, 2419 and 2421 (concept rows of the removed objects), 2805 and 3205 (prefix PAIC- registered: retire or keep reserved); "
    "proposals_stage3_b.py lines 41, 47-48; proposals_dp_investment.py lines 366, 382, 394, 397-398, 524 (DP-135 proposal); "
    "consolidation/gaps_register.py lines 3786-3798 (GAP-34 entries on PAI and outcomes lapse); proposals_31.py line 106 and "
    "proposals_w1b_31.py lines 37 and 69; proposals_36.py line 172; proposals_w1_01.py lines 172, 244, 284 (the 01 SFDR commitments, "
    "already removed under CW-901).",
    "Other domains' content seen: at the start of this pass content_42_corporate_communications_and_public_affairs.py carried "
    "'Source PAI Calculation' (Reference (PAI Calculation, 34)) on Publication Source Link; it no longer appears in content_42 at the "
    "end of the pass (the 42 editor, CW-942). If it returns it will not resolve. content_31 Climate Metric Input references Portfolio "
    "Sustainability Metric, which stays.",
    "References to retiring or later-replaced domains left as they are (W2, W4): 13 Proxy Campaign and Proxy Proposal (Ballot.Own Fund "
    "Proxy Campaign, Vote Rationale.Rationale Fund Proxy Proposal, Vote Instruction.Voted Fund Proxy Proposal, three REL rows, three "
    "OWNERSHIP_OVERRIDES) and the investor choice election (Voting Choice Offered Funds note, Design principle 10, Suggested next step "
    "6); 30 Private Markets: Attribution Denominator Value note and ROW_OWNERSHIP-style text (private company equity plus debt from 30 "
    "fair value), DERIVED comment in enrich_34, REL 'Engagement engages Party' note (portfolio company profile in 30), the Engaged Party "
    "and Observed Issuer 'private portfolio company' wording, PCAF Business Loans and Unlisted Equity description.",
    "For the 13 drafter (W2): Voting Choice Offered Funds sits on a versioned Voting Policy and has no dates of its own; decide whether "
    "the offering needs its own effective-dated link (policy x fund x period) when 13 models the election.",
    "W4 retirement candidates (private markets residue, not removed): ESG Data Convergence Initiative source (private company metrics); "
    "the private portfolio company wording above. The Purpose no longer names private funds or insurance-dedicated portfolios.",
    "Business lines: 34 holds no Business Line value.",
    "Remaining hits of the step 1 grep, justified: overview Purpose and Notes name the removed regimes; EU BMR Delegated Regulation "
    "2020/1818 kept as tracked-index methodology (Exclusion Policy Basis secondary reference, list source and one source row); the "
    "family name 'Portfolio Sustainability Metrics & Product Outcomes' and code ST-PAI are kept (names unchanged; rename candidate "
    "'Portfolio Sustainability Metrics' for the lead, since the family no longer holds outcomes or PAI statements).",
    "Tailoring levers: California SB 253 and SB 261 climate disclosure (status and applicability to the firm to confirm) are not "
    "modeled; a firm that reports under them tags metrics with a new Metric Framework value.",
    "Unverified (marked confirm in Source_Notes): the Voting Choice Option Type values (public program descriptions, not a rule).",
]
