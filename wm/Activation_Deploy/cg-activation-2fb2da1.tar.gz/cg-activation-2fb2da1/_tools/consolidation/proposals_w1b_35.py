"""W1b proposals of Data Domain 35 Fund Governance & Regulatory Reporting (wealth model; kept with the US-only and
perspective pass). Brief: 00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (35); decisions CW-003, CW-004,
CW-021, CW-022, CW-039; plan section 5.1 row 35. Declarative only: the program lead merges DECISIONS into decisions.py,
appends JURISDICTION to jurisdiction.REMOVALS and applies SHARED_RECUTS to shared_code_lists.py at merge (W5 for the shared
lists, CW-039). The existing proposals_35.py (expansion) is unchanged.
"""

_D = "CW-935"


def _j(obj, attr, regime, note):
    return {"domain": "35", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


# ---------------------------------------------------------------------------------------------------------------------
# Jurisdiction register entries (jurisdiction.REMOVALS format). Objects and attributes use the wholesale-v1.0 names.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = [
    # Attributes
    _j("Governance Standards Profile", "UK AFM Independence Requirement Met Indicator", "FCA",
       "FCA COLL 6.6.25R independent members of a UK AFM board; the US standards are the Rule 0-1(a)(7) indicators (kept)."),
    # Code-list values
    _j("Code list: Governing Body Type", "UCITS Management Company Board", "UCITS", "No UCITS management company; US funds are governed by registrant boards (kept)."),
    _j("Code list: Governing Body Type", "AIFM Board", "AIFMD", "No AIFM."),
    _j("Code list: Governing Body Type", "Self-Managed Fund Board", "UCITS", "Board of a SICAV, ICAV or OEIC (EU/UK corporate fund forms); a US corporate fund's board is a Registrant Board."),
    _j("Code list: Governing Body Type", "UK AFM Board", "FCA", "UK authorized fund manager (ACD or unit trust manager)."),
    _j("Code list: Governed Fund Coverage Basis", "Sub-Fund of Umbrella", "UCITS", "UCITS or AIF umbrella sub-fund; a US series is 'Series of Registrant' (kept)."),
    _j("Code list: Governed Fund Coverage Basis", "Fund Managed by Management Company", "UCITS", "UCITS management company coverage."),
    _j("Code list: Governed Fund Coverage Basis", "AIF Managed by AIFM", "AIFMD", "AIFM coverage."),
    _j("Code list: Governed Fund Coverage Basis", "Authorized Fund of AFM", "FCA", "UK authorized fund operated by an AFM."),
    _j("Code list: Interested Person Status", "Independent - Non-US Standard", "Other EU/UK", "Independence under FCA COLL 6.6.25R or a national standard (CSSF Circular 18/698); US boards apply Section 2(a)(19) (kept)."),
    _j("Code list: Interested Person Status", "Not Independent - Non-US Standard", "Other EU/UK", "Removed with the non-US standard."),
    _j("Code list: Fund Officer Role", "Conducting Officer", "Other EU/UK", "Luxembourg management company conducting officer (CSSF Circular 18/698)."),
    _j("Code list: Fund Officer Role", "Designated Person", "Other EU/UK", "Irish fund management company managerial function (Central Bank of Ireland)."),
    _j("Code list: Fund Officer Role", "Money Laundering Reporting Officer", "Other EU/UK", "UK and EU funds; the US fund AML role is 'AML Compliance Officer' (kept)."),
    _j("Code list: Board Report Type", "Conducting Officer Report", "Other EU/UK", "Luxembourg management company report (CSSF Circular 18/698)."),
    _j("Code list: Board Report Type", "Assessment of Value Report", "FCA", "UK AFM assessment of value (COLL 6.6.20R); the US analogue is the Section 15(c) renewal (kept)."),
    _j("Code list: Advisory Agreement Type", "Management Company Investment Management Delegation", "UCITS", "UCITS Article 13 delegation of portfolio management."),
    _j("Code list: Advisory Agreement Type", "AIFM Portfolio Management Delegation", "AIFMD", "AIFMD Article 20 delegation; external sub-advisers of US funds use 'Sub-Advisory Agreement' (kept)."),
    _j("Code list: Filing Form Type", "AIFMD Annex IV", "AIFMD", "AIFM reporting (AIFMD Article 24, Regulation 231/2013 Annex IV); private fund reporting is Form PF (kept, W4 with 30)."),
    _j("Code list: Filing Form Type", "UCITS Annual Report Filing", "UCITS", "US annual shareholder reports are filed on Form N-CSR (kept)."),
    _j("Code list: Filing Form Type", "UCITS Semi-Annual Report Filing", "UCITS", "US semi-annual reports are filed on Form N-CSRS (kept)."),
    _j("Code list: Filing Form Type", "CSSF Periodic Return", "Other EU/UK", "Luxembourg CSSF fund returns."),
    _j("Code list: Filing Form Type", "Central Bank of Ireland Fund Return", "Other EU/UK", "Irish fund returns."),
    _j("Code list: Filing Form Type", "FCA Authorized Fund Report or Notification", "FCA", "UK authorized fund reports and notifications (COLL 4)."),
    _j("Code list: Filing Certification Type", "Annex IV Submission Sign-Off", "AIFMD", "Removed with AIFMD Annex IV."),
    _j("Code list: Filing Certification Type", "UK Fund Report Directors' Statement", "FCA", "UK authorized fund report statement (COLL 4.5); US certifications are Rule 30a-2 and Form Signature (kept)."),
    _j("Code list: Reportable Event Type", "UCITS Investment Limit Breach Notification", "UCITS", "No UCITS range; US current reports are Forms N-RN and N-CR (kept)."),
    _j("Code list: Reportable Event Type", "AIFMD Leverage Notification", "AIFMD", "No AIF range."),
    _j("Code list: Reportable Event Type", "UK Fund Material Breach Notification", "FCA", "No UK authorized funds."),
    # Sources
    _j("Sources", "AIFMD (Directive 2011/61/EU) Art 24, Delegated Regulation (EU) 231/2013 Annex IV, and AIFMD II (Directive (EU) 2024/927, transposition by 16 April 2026)", "AIFMD",
       "Obligated Entity and Filer Entity re-sourced to SEC Form PF; removed with Annex IV, AIFM boards and delegation."),
    _j("Sources", "UCITS Directive 2009/65/EC (as amended by UCITS V) and CSSF Circular 18/698", "UCITS",
       "Governing Body Type re-sourced to the Investment Company Act Section 10 and OCC 12 CFR 9; Governed Entity and Officer Entity to OCC 12 CFR 9."),
    _j("Sources", "FCA Handbook COLL (Collective Investment Schemes sourcebook): COLL 4 (investor relations, changes, reports) and COLL 6.6 (AFM duties, assessment of value, independent members)", "FCA",
       "Coverage Basis and Interested Person Status secondary dropped; Subject Product Review and Subject Fund Financial Statement re-sourced to Internal."),
]

# ---------------------------------------------------------------------------------------------------------------------
# Decision of the US-only pass of 35 (decisions.DECISIONS format)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-935", "theme": "Scope", "title": "US-only pass of 35 Fund Governance & Regulatory Reporting",
     "domains": ["35", "01", "08", "30", "31", "36"],
     "issue": "The wholesale 35 held the governance and filings of funds sponsored in the US and EU/UK: UCITS management company, AIFM, self-managed (SICAV, ICAV, OEIC) and UK AFM boards, their coverage bases, the UK AFM independence indicator, non-US independence statuses, Luxembourg, Irish and UK officer roles and board reports, UCITS and AIFMD delegation agreements, AIFMD Annex IV, UCITS, CSSF, Central Bank of Ireland and FCA filings and certifications, UCITS, AIFMD and UK breach notifications, and their sources (AIFMD and Regulation 231/2013, UCITS V and CSSF Circular 18/698, FCA COLL). Its Business Line example used a removed wholesale value.",
     "resolution": "1) Removed (32 JURISDICTION entries: UCITS 9, FCA 8, Other EU/UK 8, AIFMD 7): Governance Standards Profile.UK AFM Independence Requirement Met Indicator (Governance Standards Met Indicator, the attribute after it, moves up one attribute ID within the family Governing Bodies); values Governing Body Type 'UCITS Management Company Board', 'AIFM Board', 'Self-Managed Fund Board', 'UK AFM Board'; Governed Fund Coverage Basis 'Sub-Fund of Umbrella', 'Fund Managed by Management Company', 'AIF Managed by AIFM', 'Authorized Fund of AFM'; Interested Person Status 'Independent - Non-US Standard', 'Not Independent - Non-US Standard'; Fund Officer Role 'Conducting Officer', 'Designated Person', 'Money Laundering Reporting Officer'; Board Report Type 'Conducting Officer Report', 'Assessment of Value Report'; Advisory Agreement Type 'Management Company Investment Management Delegation', 'AIFM Portfolio Management Delegation'; Filing Form Type 'AIFMD Annex IV', 'UCITS Annual Report Filing', 'UCITS Semi-Annual Report Filing', 'CSSF Periodic Return', 'Central Bank of Ireland Fund Return', 'FCA Authorized Fund Report or Notification'; Filing Certification Type 'Annex IV Submission Sign-Off', 'UK Fund Report Directors' Statement'; Reportable Event Type 'UCITS Investment Limit Breach Notification', 'AIFMD Leverage Notification', 'UK Fund Material Breach Notification'; three sources. No object removed. "
                   "2) Re-sourced: filings to the SEC forms already listed (N-PORT, N-CEN, N-CSR and N-CSRS, N-1A, N-PX, 24F-2NT and the rest) and, as the brief names, state notice filings: Filing Form Type gains 'State Notice Filing (NSMIA)' and the sources gain Securities Act Section 18 (NSMIA, paragraphs to confirm); Obligated Entity and Filer Entity to SEC Form PF (adviser-level filing; private funds, W4 with 30); Governing Body Type secondary to OCC 12 CFR 9; Governed Entity and Officer Entity to OCC 12 CFR 9 (affiliated trustee bank or trust company, general partner); Coverage Basis and Interested Person Status secondary FCA COLL dropped; Subject Product Review to Internal (example key PRVW-...-AOV-01 left as 36 writes it, for 36's own pass); Subject Fund Financial Statement secondary dropped; Reportable Event Type to Forms N-RN and N-CR and Section 22(e), with 'Suspension of Dealing' described as a Section 22(e) suspension of redemptions; Resolution Type 'Financial Statements Approval' described for US boards, audit committees and CIT trustees; RIC Qualification Status 'Not Applicable' no longer names UCITS. Sources 21 to 19. "
                   "3) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose (the PF line's registered funds, CITs and, where offered, private feeder funds; firm-level filings are 38 and 19), Scope (02 party core; 08 distribution and FINRA filings; 25 MiFIR reports dropped; 28 Rule 10c-1a reports; 39 boards include the trust company; 52 sub-adviser oversight), Core model (no ManCo, AIFM or AFM bodies or conducting officers; reportable events N-RN, N-CR and suspensions), Notes (Regulation S-P, GLBA and state law) and Suggested next step 6 (EDGAR mapping and the owner of state notice filings, 08 or 35); family texts of Bodies & Coverage, Governance Standards and Filing Obligations; definitions of Governed Entity, Governed Product, Interested Member Employee, Interested Person Status, Officer Entity, Adviser Entity, Obligated Entity, Filer Entity, Accession Number, Confidential Treatment Indicator and Source VaR Test Result; two relationship notes; SUMMARY in enrich_35.py. "
                   "4) Business Line (CW-004): Governed Fund Coverage.Covered Business Line example 'Mutual Fund' becomes 'PF'. 5) Re-points: none of a Reference type (CW-021). 6) Additions: the Filing Form Type value 'State Notice Filing (NSMIA)' and its source, named by the brief as the re-sourcing target; in the review fix pass (program-lead ruling) Filing Obligation.Obligation Filing State and Fund Regulatory Filing.Filing State (Code, ISO 3166-2 US subdivision, Securities Act Section 18), so that a state notice filing is one obligation and one filing row per state, and both grains carry the state (enrich_35). The two attributes are inserted after Obligation Regulator and Filing Form Type, so the attribute IDs that follow them in the family Regulatory Filings & Disclosures move down. Whether 35 or 08 owns state notice filings is settled at W2 (08 is replaced as Retail Conduct & Supervision); if 08 takes them, the value, the two attributes and the source move with them. Also in the fix pass: Covered Series no longer says 'sub-funds'; Governed Registrant reads 'Registrant (series trust or corporation)'. Counts: 6 families and 29 objects unchanged, 248 to 249 attributes (one removed, two added), 76 CDEs (30.5%), 37 code lists, 47 relationships, 21 to 19 sources.",
     "rationale": "CW-003 and CW-022: the firm sponsors US registered funds and CITs, so EU/UK fund governance bodies, officers, filings and notifications have no fund to apply to; the 1940 Act filings (N-PORT, N-CEN, N-CSR, N-PX, N-RN, N-CR, 24F-2) stay. Form PF, LPACs, the Deal reference and the 817(h) determination stay for the W4 decisions on 30 and on insurance-dedicated funds. Names are unchanged so that DP-182 to DP-186 and SM-11 keep resolving; their readers of the removed attribute and values are listed in NOTES.",
     "action": "W1b", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# Shared list re-cuts (35 is a direct user of Business Line, Regulator and others; it stewards Meeting Format, no EU value)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_RECUTS = [
    ("Business Line", "09",
     "35 is a direct user: its one example now uses the CW-004 code PF; no value map change."),
]

SHARED_CANDIDATES = []

# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "W1b (wealth), CW-935. Validation: taxonomy_builder.py content_35_fund_governance_and_regulatory_reporting OK (6 families, "
    "29 objects (6 attribute groups, 0 without grain), 249 attributes after the review fix pass (247 after the pass), 76 CDEs, 78 references, 3 derived, 0 unresolved, 37 code "
    "lists); before: 248 attributes, 76 CDEs, 78 references, 37 code lists. check_enrichment.py 35 OK.",
    "READERS of the removed attribute and values (not edited; for the program lead and the product and model owners): "
    "data_products/specs_e3_ta_fund_governance.py line 646 (DP-182 definition 'ManCo and AIFM boards'), line 746 (DP-182 inputs: Governance Standards Profile.UK AFM Independence Requirement Met Indicator) and line 803 (DP-182 operating model 'third-party trustee or ManCo'); "
    "data_models/models_e8c_ta_fund_governance.py lines 521 and 543 (DP-182 model notes 'ManCo') and line 754 (DP-184 model note 'Filer entity (adviser, AIFM, depositor)'); "
    "data_products/specs_e4_compliance_legal.py line 1207 (DP-230 notes 'ManCo, AIFM, ACD'); "
    "line 974 (DP-184 definition names 'AIFMD Annex IV, UK and EU fund returns'); lines 1307-1468 (DP-186 'Private & Alternative Fund Report Data (Form PF, AIFMD Annex IV)': definition line 1308, question line 1316, grain line 1322 (Annex IV per AIFM and fund), line 1351 (reads the removed 31 AIFMD exposure methods), timeliness line 1437, notes lines 1457-1468; the Form PF part stays for W4, the Annex IV part goes); "
    "data_products/framework.py line 245 (framework text 'AIFMD Annex IV') and line 1054 (DP-186 name); "
    "data_models/models_e8c_ta_fund_governance.py lines 975-1095 (DP-186 model: grain line 981, notes lines 992, 1037, 1063 and 1095 name Annex IV and AIFMs); "
    "semantic_model/models/sm_11_fund_accounting_custody_governance.py lines 2130 and 2229 (filters and questions on 'Form PF and Annex IV filings'); "
    "text mentions in data_products/specs_e2_invops_a.py lines 1369 and 1573 (DP-155, 'AIFMD Annex IV take their values from it') and specs_e4_compliance_legal.py line 126 (fund filings 'Form PF, Annex IV'). "
    "Registers: consolidation/gaps_register.py line 3587 (GAP on Investor Commitment for Form PF and Annex IV, 30) and lines 3832-3835 (GAP-35-001, form item object for N-PORT, Form PF and Annex IV: re-word to N-PORT and Form PF). "
    "No product, model or semantic filter names the removed Governing Body Type, Coverage Basis, Interested Person Status, Fund Officer Role, Board Report Type, Advisory Agreement Type, Filing Certification Type or Reportable Event Type values (searched), but the DP-182, DP-184 and e4 texts above describe the removed body types. Generated outputs refresh on rebuild.",
    "Form PF stays (the assignment and CW-038: private feeder funds may file it); it goes with 30 at W4 if the firm has no private funds: Filing Form Type 'Form PF', Obligated Entity and Filer Entity (now sourced to Form PF), Confidential Treatment Indicator's Form PF mention, Filing Certification Type 'Form Signature' text, the Form PF source row, Filing Data Source Type values '30 Private Fund Profile' and '30 Fund Credit Facility' and '31 Liquidity Horizon Bucket'.",
    "References to domains retiring or replaced later, left as they are (W4): Board Consent Record.Related Private Fund Deal (Reference (Deal), PDL-); Governing Body Type 'Private Fund LPAC', Governed Fund Coverage Basis 'Private Fund (LPAC)', Interested Person Status 'Not Applicable - LPAC Member', Consent Type LPAC values and Resolution Type 'LPAC Consent' with the ILPA source (private funds); the relationship 'Board Consent Record concerns Deal [30]'; Filing Data Source Type '30 ...' values; SUMMARY 'deals from 30'. "
    "08 Distribution Compliance (replaced at W2) is still named for distribution and FINRA filings in Scope; 13 (adapted at W2), 10 and 11 (W4) references unchanged. "
    "Insurance-dedicated residue for the W4 decision: RIC Qualification Determination.Section 817(h) Result and Relied 817(h) Rule Results, the Section 817(h) Result list, Exemptive Relief Type 'Mixed and Shared Funding', the IRC 817(h) source text, the family text 'with IRC Section 817(h) for insurance-dedicated funds'.",
    "Other domains' content seen: 36 Product Review keys its examples PRVW-...-AOV-01 and its Product Review Type list still carries 'Assessment of Value' (COLL 6.6.20R), 'Periodic Product Review' (MiFID / FCA PROD 3) and 'Fair Value Assessment' (FCA PRIN 2A): for 36's own pass (W4); 35 keeps the example key until 36 re-keys it. 01 Product Governance 'Governing Body' and Regulatory Authorization 'Regulatory Reporting Obligations' re-typing proposals (CD-231, CD-233) are unchanged.",
    "Remaining hits of the step 1 grep, justified: 'shareholder' always means the shareholders of the fund (not the firm's direct client); IRC 817(h) and insurance-dedicated text (W4 residue); 'AOV' in the 36 example key. No MiFID, UCITS, AIFMD, FCA, COLL, CSSF, Central Bank of Ireland, ManCo, AFM, Annex IV, GDPR or 'SMA' hit remains.",
    "Unverified (marked confirm in Source_Notes): Securities Act Section 18(b)(2) and 18(c)(2) as the NSMIA paragraphs for registered fund covered securities and state notice filings; whether the state notice filings are owned by 35 or by 08 (replaced at W2 as Retail Conduct & Supervision).",
]
