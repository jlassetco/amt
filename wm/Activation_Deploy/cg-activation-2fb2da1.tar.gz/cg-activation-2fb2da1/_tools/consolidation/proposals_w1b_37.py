"""W1b proposals of Data Domain 37 Enterprise & Operational Risk (wealth model; kept with the US-only and perspective
pass). Brief: 00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (row 37); decisions CW-003, CW-004, CW-021,
CW-022, CW-039; W1 merge notes section 5 (Business Line and Regulator examples). Declarative only: the program lead merges
DECISIONS into decisions.py and appends JURISDICTION to jurisdiction.REMOVALS at merge. The existing proposals_37.py
(expansion) is unchanged.
"""

_D = "CW-937"


def _j(obj, attr, regime, note):
    return {"domain": "37", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


# ---------------------------------------------------------------------------------------------------------------------
# Jurisdiction register entries (jurisdiction.REMOVALS format). Objects and attributes use the wholesale-v1.0 names.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = [
    # Objects
    _j("Important Business Service", "", "FCA",
       "UK operational resilience regime (FCA SYSC 15A, PS21/3): important business services with client harm and market integrity "
       "bases; 8 attributes. Relationships: 'Operational Incident disrupts Important Business Service' and 'Important Business Service has "
       "Impact Tolerance' removed; the 'depends on' and 'supports' relationships rewritten to Critical or Important Function. The US instance is the critical function of the interagency guidance, kept as "
       "Critical or Important Function, and the FINRA Rule 4370 business continuity plan."),
    _j("Impact Tolerance", "", "FCA",
       "UK impact tolerance per important business service and metric (SYSC 15A); 5 attributes and one relationship. Recovery "
       "objectives stay on Business Impact Analysis (RTO, RPO, MTPD). Its one relationship (has Impact Tolerance) is the one counted on Important Business Service."),
    # Attributes
    _j("Operational Incident", "Impacted Business Services", "FCA", "Reference to the removed Important Business Service."),
    _j("Incident Classification", "DORA Major ICT-Related Incident Indicator", "DORA",
       "DORA major ICT-related incident classification (RTS 2024/1772). US notifications are Incident Regulatory Notification rows "
       "(FINRA Rule 4530, Regulation S-P, state breach laws)."),
    _j("Incident Classification", "DORA Classification Timestamp", "DORA", "Started the DORA reporting clock (RTS 2025/301); Notification Deadline Timestamp stays."),
    _j("Critical or Important Function", "Related Important Business Service", "FCA",
       "Reference to the removed Important Business Service; the function itself is kept and re-sourced to the interagency guidance."),
    _j("Resilience Resource Mapping", "Mapped Business Service", "FCA", "Reference to the removed Important Business Service; Mapped Function is the mapping's subject."),
    _j("Resilience Test", "Tested Business Service", "FCA", "Reference to the removed Important Business Service; Tested Continuity Plan stays."),
    _j("Model Inventory Entry", "Trading Algorithm Code", "MiFIR",
       "MiFIR RTS 22 algorithm code for transaction reports; no MiFIR reporting. 24 Investment Decision.Decision Algorithm Code "
       "(Derived copy (37)) loses its source (NOTES)."),
    # Code-list values
    *[_j("Code list: Impact Tolerance Metric", v, "FCA", "Whole list removed with Impact Tolerance.")
      for v in ("Maximum Duration of Disruption", "Clients Affected", "Transaction Value Affected", "Point in Time")],
    _j("Code list: Incident Notification Stage", "DORA Initial Notification", "DORA",
       "Replaced by the split of the review fix pass: Incident Notification Regime (Regulation S-P Customer Notification, State Breach Notification, FINRA Rule 4530 Report, SEC or Other Regulator Notification, Internal) and Incident Notification Stage (Initial, Update or Amendment, Final)."),
    _j("Code list: Incident Notification Stage", "DORA Intermediate Report", "DORA", "As above."),
    _j("Code list: Incident Notification Stage", "DORA Final Report", "DORA", "As above."),
    _j("Code list: Incident Notification Stage", "FCA SUP 15 Notification", "FCA", "As above."),
    # Sources
    _j("Sources", "Regulation (EU) 2022/2554 (DORA)", "DORA",
       "Critical or Important Function re-sourced to the interagency guidance; incident classification and notifications to US rules."),
    _j("Sources", "Commission Delegated Regulation (EU) 2024/1772 (RTS on classification of ICT-related incidents)", "DORA", "Removed with the DORA indicator."),
    _j("Sources", "Commission Delegated Regulation (EU) 2025/301 and Implementing Regulation (EU) 2025/302 (incident reporting content, time limits and templates)", "DORA",
       "Notification attributes re-sourced to FINRA Rule 4530 and Regulation S-P."),
    _j("Sources", "FCA Handbook SYSC 15A Operational Resilience (PS21/3)", "FCA",
       "Resilience attributes re-sourced to FINRA Rule 4370, ISO 22301 and the interagency sound practices (SR 20-24)."),
    _j("Sources", "FCA Handbook SUP 15 Notifications to the FCA", "FCA", "Notification re-sourced to FINRA Rule 4530."),
    _j("Sources", "PRA SS1/23 Model risk management principles for banks", "Other EU/UK", "Model tiering re-sourced to SR 26-2 and Internal."),
    _j("Sources", "EBA Guidelines on outsourcing arrangements (EBA/GL/2019/02)", "Other EU/UK", "Third-party references re-sourced to the 2023 interagency guidance."),
    _j("Sources", "MiFIR RTS 22 (Commission Delegated Regulation (EU) 2017/590) transaction reporting", "MiFIR", "Removed with Trading Algorithm Code."),
    _j("Sources", "CSDR, Regulation (EU) 909/2014, and Delegated Regulation (EU) 2018/1229 (settlement discipline)", "CSDR",
       "Amount Source Settlement Penalty is kept (26 keeps Settlement Penalty for US fails charges under CW-926) and cites Internal."),
]

# ---------------------------------------------------------------------------------------------------------------------
# Wording re-points and shared-value fixes (object, attribute, before, after, decision)
# ---------------------------------------------------------------------------------------------------------------------
REPOINTS = [
    ("Enterprise Risk", "Risk Business Lines", "Mutual Fund; ETF", "PF; DB", _D),
    ("Operational Loss Event", "Loss Business Line", "Mutual Fund", "PF", _D),
    ("Incident Regulatory Notification", "Notification Authority", "FCA", "FINRA", _D),
    ("Operational Incident", "Impacted Portfolios", "PII where the portfolio implements an SMA account held by an individual", "PII only where the portfolio is an institutional separate account of an individual (rare); retail managed accounts are 15 accounts, not 18 portfolios (CW-007)", _D),
    ("Incident Source Record", "Source Model Portfolio", "delivery to an SMA or model platform", "delivery to a model platform sponsor (IC line) or an institutional separate account", _D),
    ("SUMMARY (enrich_37)", "references", "02 Client & Customer", "02 Client & Household", _D),
]

# ---------------------------------------------------------------------------------------------------------------------
# Decision of the US-only pass of 37 (decisions.DECISIONS format)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-937", "theme": "Scope", "title": "US-only pass of 37 Enterprise & Operational Risk",
     "domains": ["37"],
     "issue": "The wholesale 37 described an asset manager running mutual funds, ETFs, CITs, SMAs, private markets and insurance-dedicated funds in the US, the EU and the UK. It mastered the UK operational resilience objects (Important Business Service, Impact Tolerance under FCA SYSC 15A / PS21/3), a DORA Critical or Important Function, the DORA major-incident classification and DORA and FCA SUP 15 notification stages, a MiFIR trading algorithm code, and cited DORA and its technical standards, FCA SYSC 15A and SUP 15, PRA SS1/23, EBA/GL/2019/02, MiFIR RTS 22 and CSDR. Its Business Line examples used the removed wholesale values and its notification example the removed FCA regulator value.",
     "resolution": "Affects 40 (Outsourcing Arrangement references to Critical or Important Function), 24 (Decision Algorithm Code loses its source) and 26 (Settlement Penalty kept), noted below. 1) Removed (26 JURISDICTION entries: FCA 13, DORA 8, MiFIR 2, Other EU/UK 2, CSDR 1): objects Important Business Service (8 attributes) and Impact Tolerance (5) with the list Impact Tolerance Metric (4 values) and three relationships; attributes Operational Incident.Impacted Business Services, Incident Classification.DORA Major ICT-Related Incident Indicator and DORA Classification Timestamp, Critical or Important Function.Related Important Business Service, Resilience Resource Mapping.Mapped Business Service, Resilience Test.Tested Business Service, Model Inventory Entry.Trading Algorithm Code; Incident Notification Stage values DORA Initial Notification, DORA Intermediate Report, DORA Final Report, FCA SUP 15 Notification; sources DORA, RTS 2024/1772, RTS 2025/301 and ITS 2025/302, FCA SYSC 15A, FCA SUP 15, PRA SS1/23, EBA/GL/2019/02, MiFIR RTS 22, CSDR. No ICARA content was present. "
                   "2) Kept and re-sourced, a deviation from the brief row: Critical or Important Function stays as the critical activity (2023 interagency third-party guidance) or critical operation (2020 interagency sound practices, SR 20-24), because 40 keeps Outsourcing Arrangement.Supported Critical or Important Functions on that basis (CW-940) and the resource mapping needs a subject; code, name, entity and dates re-sourced, the UCITS example and the EU designating-entity wording replaced. "
                   "3) Re-sourced: business continuity to FINRA Rule 4370 and the adviser's and funds' plans under SEC Rules 206(4)-7 and 38a-1 (Business Continuity Plan, Resilience Resource Mapping, Resilience Test, the Tolerance Met Indicator now defined against the BIA recovery time objectives, list sources); incident notification to Regulation S-P customer notification and state breach laws for customer-data incidents, and to FINRA Rule 4530 only where the incident also involves a 4530 reportable event (violation, customer complaint, disciplinary item); review fix pass: the notification is split into Incident Notification Regime (new attribute and local list: Regulation S-P Customer Notification, State Breach Notification, FINRA Rule 4530 Report, SEC or Other Regulator Notification, Internal) and Incident Notification Stage (name kept so readers resolve; values Initial, Update or Amendment, Final); Notification Authority, Notifying Legal Entity, deadline, sent and reference attributes re-sourced; FINRA Regulatory Notice 21-29 added as the broker-dealer's third-party source; third-party references from EBA and DORA to the interagency guidance; model risk references from PRA SS1/23 to SR 26-2 or Internal; Incident Discovery Date, Source IT Incident and Amount Source Settlement Penalty lose their DORA and CSDR references; five sources added (FINRA Rules 4370 and 4530, Regulation S-P, SR 20-24, FINRA Regulatory Notice 21-29). Reg SCI does not apply (no SCI entity). "
                   "4) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose, Scope, Core model, Design principles 6 and 10, Applies To, CDE, Primary / Secondary Reference, Notes and Suggested next steps; the Operational Resilience & Continuity, Business Services & Functions and Third-Party Risk texts; enrich_37 SUMMARY and the mapping grain; Source_Notes header, purpose, sections 1 to 4 and 6, and section 7. Attribute IDs renumber within Operational Incidents & Losses, Operational Resilience & Continuity and Model Risk Management. "
                   "5) Re-pointed and shared values (W1 merge notes section 5): Risk Business Lines and Loss Business Line examples to the CW-004 values; Notification Authority example FINRA; the SMA PII note on Impacted Portfolios (retail managed accounts are 15 accounts, CW-007); Source Model Portfolio wording; 02 Client & Household (REPOINTS, 6 entries). No reference retyped. 6) Added: none (brief row 37); the relationships 'Resilience Test exercises Business Continuity Plan' and 'Outsourcing Arrangement [40] supports Critical or Important Function' replace the removed relationships. "
                   "Counts: 37 to 35 objects, 297 to 278 attributes, 89 to 85 CDEs (31%), 45 to 45 code lists, 42 to 41 relationships, 27 to 23 sources, 19 to 18 PII attributes.",
     "rationale": "CW-003 and CW-022: the firm is regulated and operates in the US only, so the UK operational resilience regime, DORA, FCA notifications, PRA and EBA guidance and MiFIR codes have nothing to apply to; the generic risk, incident, continuity, third-party, model risk and audit record stays and is sourced to FINRA Rules 4370 and 4530, Regulation S-P, the SEC compliance rules and the interagency guidance. Keeping the critical function as a US concept keeps 40's reference and the resilience mapping whole (CW-940). Names are kept so that DP-212, DP-214 to DP-216, DP-218 and SM-16 keep resolving; DP-217 loses its core objects; the readers of the removed objects are listed in NOTES. Lever: a UK or EU extension restores the removed rows from wholesale-v1.0 through the jurisdiction register.",
     "action": "W1b", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# Shared lists: 37 is a direct user of Business Line and Regulator (examples fixed above); it stewards none.
# ---------------------------------------------------------------------------------------------------------------------
SHARED_RECUTS = []

SHARED_CANDIDATES = [
    ("Incident Notification Regime", None, ["41", "38"],
     "New local list (review fix pass). 41 IT Incident and 38 compliance filings may need the same regime vocabulary (Regulation S-P, state breach, FINRA Rule 4530); share it, stewarded by 37, if they do."),
    ("Incident Notification Stage", None, ["41"],
     "Re-cut to Initial, Update or Amendment, Final (review fix pass); a generic stage list that 41 could share."),
]

# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "W1b (wealth), CW-937. Validation: taxonomy_builder.py content_37_enterprise_and_operational_risk OK (9 families, 35 objects (2 "
    "attribute groups, 0 without grain), 277 attributes, 84 CDEs, 68 references, 6 derived, 0 unresolved, 44 code lists); before: 37 "
    "objects, 297 attributes, 89 CDEs, 70 references, 45 code lists. check_enrichment.py 37 OK. JURISDICTION 26 entries. After the review fix pass: 278 attributes, 85 CDEs, 45 code lists.",
    "Deviation for the lead: Critical or Important Function is kept and re-sourced (brief row 37 lists it for removal). If removed, "
    "content_40_procurement_and_vendor_management.py Outsourcing Arrangement.Supported Critical or Important Functions and Critical or "
    "Important Outsourcing Indicator (lines 303-304 at the end of this pass), the 40 Criticality Driver value 'Supports Critical or "
    "Important Function' (line 350) and REL line 388 lose their target, and Resilience Resource Mapping needs a new subject.",
    "READERS of the removed objects and attributes (not edited): data_products/specs_e4_risk_audit_third_party.py lines 185-241 and "
    "270 (DP-215 incidents, losses and regulatory notifications: DORA indicator, DORA timestamp, Impacted Business Services, notification stages), 431-548 (DP-217 "
    "'Operational Resilience & Impact Tolerances', which loses its core objects and needs re-scoping at WP0 to continuity and critical functions: Important Business Service, Impact Tolerance, Tested Business Service, Mapped Business Service, "
    "tolerance metrics), 895-1005 (DP-220 critical function and outsourcing links); data_products/specs_e1_masters.py lines 996-997, "
    "1001, 1025; data_products/specs_e5_cross_area.py lines 1157-1159, 1204, 1206; data_products/specs_e2_portfolio_stewardship.py "
    "lines 74, 77, 108 (24 Decision Algorithm Code from 37 Trading Algorithm Code); data_products/specs_e4_compliance_legal.py lines "
    "444, 446, 504; data_products/specs_l_shareholder_vendor.py lines 495, 548-549, 586; data_products/framework.py line 1103 (DP-217 name); "
    "consolidation/proposals_dp_corporate_b.py lines 167, 176-177, 233; data_models/keys_e7_37_38.py lines 38, 95-99, 171-173, 250, "
    "281, 303-309, 317, 378; data_models/models_e8c_risk_audit_third_party.py lines 10, 15, 66-67, 319-419, 429, 542-607, 743; "
    "data_models/models_e8c_cross_area.py lines 1132-1133, 1189; data_models/models_e8c_compliance_legal.py lines 320, 402; "
    "data_models/models_e8c_portfolio_stewardship.py line 161; data_models/keys_e7_39_41.py lines 374-375, 389 (40 link to Important "
    "Business Service); semantic_model/models/sm_16_risk_compliance_legal_audit.py lines 144-150, 248-278, 732-753, 1078-1084, "
    "1149-1160; semantic_model/models/sm_00_shared_dimensions.py line 852; semantic_model/models/sm_08_investment_book_performance.py "
    "line 992.",
    "Registers that name the removed content (not edited): consolidation/decisions.py lines 1295, 1315-1316, 1400, 1449 (CD-245, "
    "CD-246 and CD-249 texts), 2465-2467 (concept rows Important Business Service, Impact Tolerance, Critical or Important Function), "
    "3549-3555, 5205-5209; consolidation/gaps_register.py lines 3998-4009; proposals_stage4_a.py lines 69-70 and 157; "
    "proposals_stage4_b.py line 65; proposals_40.py lines 177-214; proposals_41.py lines 101 and 104; proposals_w1b_40.py lines 43-132 "
    "(editor 5 left the critical function link to the 37 editor).",
    "Other domains' content seen (not edited): content_24_portfolio_management_and_construction.py line 243 Decision Algorithm Code "
    "('MiFIR RTS 22 ... Derived copy (37) of Trading Algorithm Code') loses its source; 24 is adapted at W3. "
    "content_14_third_party_data_and_licensing.py lines 92, 96-97 and 561 and enrichment/enrich_14.py line 56 (ICT Third-Party Register "
    "Entry: Supports Critical or Important Function, UK Important Business Service Mapping, Impact Tolerance Dependency Indicator, FCA "
    "PS21/3 source) are the 14 editor's (CW-914 removes the object).",
    "References to retiring or later-replaced domains left as they are (W2, W4): 30 Private Markets (Incident Source Record.Source "
    "Waterfall Calculation and Source Capital Call, Incident Source Type values Waterfall Calculation Error and Capital Call Error, the "
    "REL row naming Waterfall Calculation [30] / Capital Call [30], the Core model text '30 capital calls'); 13 (Source Servicing Error, "
    "Impact Source Servicing Error, Shareholder Remediation in Impact Amount and REL); 07 (Control Execution Record Type value "
    "'07 Compensation Control', Scope and Core model mentions); 08 is not referenced.",
    "W4 retirement candidates: none beyond the 30 sources above (the Purpose no longer names private markets or insurance-dedicated "
    "funds).",
    "Business lines and regulators: Risk Business Lines and Loss Business Line examples now use CW-004 labels; Notification Authority "
    "example FINRA. These were the 37 items in W1 merge notes section 5.",
    "Remaining hits of the step 1 grep, justified: overview Purpose names the removed regimes; 'TPRA' (firm reference prefix of "
    "third-party assessments) matches PRA in a naive grep; 'insurance claims (43)' is corporate insurance, not insurance-dedicated "
    "funds. The group name 'Business Services & Functions' is kept (rename candidate 'Critical Functions' for the lead).",
    "Review fix pass (2026-10-14): Notification split into Incident Notification Regime (new attribute and list) and Incident "
    "Notification Stage (name kept; Initial, Update or Amendment, Final); FINRA Rule 4530 source row and overview corrected (4530 applies "
    "only where a 4530 reportable event is involved); FINRA Regulatory Notice 21-29 added; Business Line examples use codes (PF, DB); "
    "Regulation S-P amendments stated as in force.",
    "Candidates for the lead (not added): a link from Critical or Important Function or Business Continuity Plan to Business Impact "
    "Analysis, so Tolerance Met Indicator can be evaluated without matching Plan Scope text; rename Tolerance Met Indicator to "
    "'Recovery Objective Met Indicator' (name kept under the name-continuity rule).",
    "Tailoring levers: Reg SCI if the firm operates an SCI entity; FINRA Rule 4370 emergency contact persons; Regulation S-ID red flags "
    "program (41).",
    "Unverified (marked confirm in Source_Notes): SR 20-24 letter number and URL; Regulation S-P amendment compliance dates and notice "
    "period; FINRA Rule 4530 reporting period.",
]
