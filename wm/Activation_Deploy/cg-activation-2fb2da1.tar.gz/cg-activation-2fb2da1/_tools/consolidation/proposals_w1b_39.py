"""W1b proposals of Data Domain 39 Legal & Corporate Governance (wealth model; kept with the US-only and perspective
pass). Brief: 00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (row 39); decisions CW-003, CW-004, CW-021,
CW-022, CW-039; W1 merge notes section 5 (Business Line example). Declarative only: the program lead merges DECISIONS into
decisions.py and appends JURISDICTION to jurisdiction.REMOVALS at merge. The existing proposals_39.py (expansion) is
unchanged.
"""

_D = "CW-939"


def _j(obj, attr, regime, note):
    return {"domain": "39", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


_REG = "No UK or EU group entity; statutory filings re-cut to Delaware, Maryland and other state annual reports (the firm's domestic entities file no FinCEN BOI report under the August 2026 final rule)."

JURISDICTION = [
    # Attribute
    _j("Corporate Resolution Subject Link", "Subject ICARA Assessment", "ICARA",
       "Board approval of the 43 ICARA Assessment (FCA MIFIDPRU 7), which 43 removes under CW-943."),
    # Code-list values
    _j("Code list: Corporate Officer Role", "SM&CR Senior Management Function Holder", "SM&CR", "UK SM&CR role; the US officer roles (CCO, AML / BSA officer) stay."),
    _j("Code list: Corporate Officer Role", "Money Laundering Reporting Officer (MLRO)", "SM&CR", "UK SMF17; the US AML Compliance Officer / BSA Officer (31 CFR 1023.210) stays."),
    _j("Code list: Corporate Resolution Subject Type", "ICARA Assessment (43)", "ICARA", "Removed with Subject ICARA Assessment."),
    _j("Code list: Statutory Filing Type", "UK Confirmation Statement", "Other EU/UK", "UK Companies Act 2006 (CS01). " + _REG),
    _j("Code list: Statutory Filing Type", "UK PSC Register Update", "Other EU/UK", "UK people with significant control register. No US counterpart for the firm's domestic entities: FinCEN's August 2026 final rule exempts domestic entities and US persons from BOI reporting; the FinCEN BOI Report value stays only as a lever for a foreign-formed subsidiary registered in a state (confirm)."),
    _j("Code list: Statutory Filing Type", "UK Annual Accounts Filing", "Other EU/UK", "Companies House accounts filing. " + _REG),
    _j("Code list: Statutory Filing Type", "UK Officer Appointment / Termination", "Other EU/UK", "Companies House AP01 / TM01."),
    _j("Code list: Statutory Filing Type", "Luxembourg RCS Filing", "Other EU/UK", "Luxembourg trade and companies register."),
    _j("Code list: Statutory Filing Type", "Luxembourg RBE Beneficial Owner Filing", "Other EU/UK", "Luxembourg register of beneficial owners."),
    _j("Code list: Statutory Filing Type", "Irish CRO Annual Return", "Other EU/UK", "Irish Companies Registration Office B1."),
    _j("Code list: Forum Type", "UK Court", "Other EU/UK", "Relabeled into Non-US Court with EU Member State Court (program lead ruling, CW-022): the funds claim in foreign collective actions and English-law contracts stay. Other added."),
    _j("Code list: Forum Type", "EU Member State Court", "Other EU/UK", "Relabeled into Non-US Court, as above."),
    _j("Code list: Forum Type", "Employment Tribunal", "Other EU/UK", "UK employment tribunal; US employment claims sit in court, arbitration or an agency (Regulator)."),
    _j("Code list: Corporate Meeting Type", "Written Resolution", "Other EU/UK", "UK Companies Act 2006 Part 13 Chapter 2; DGCL written consents stay."),
    _j("Code list: Clause Type", "Data Protection (GDPR Article 28 DPA)", "GDPR / UK GDPR",
       "Replaced by Data Protection and Privacy Terms (Regulation S-P service-provider oversight, 17 CFR 248.30, and state privacy law terms)."),
    _j("Code list: Contract Subtype", "Depositary Agreement", "UCITS", "UCITS / AIFMD depositary; US funds use custody agreements (Custody Agreement stays)."),
    _j("Code list: IP Office", "EUIPO", "Other EU/UK", "No EU distribution; WIPO Madrid and Other National Office stay for any foreign protection (lever)."),
    _j("Code list: IP Office", "UKIPO", "Other EU/UK", "As above."),
    _j("Code list: IP Office", "Benelux Office for IP (BOIP)", "Other EU/UK", "As above."),
    _j("Code list: Docket Deadline Type", "EU / UK Renewal", "Other EU/UK", "EU and UK ten-year renewal; US and Madrid deadlines stay."),
    # Relabels of UK corporate vocabulary (review fix pass)
    _j("Code list: Corporate Member Role", "Non-Executive Director", "UK market practice", "Relabeled 'Independent / Outside Director' (US term), same meaning."),
    _j("Code list: Corporate Member Role", "Company Secretary", "UK market practice", "Relabeled 'Corporate Secretary', same meaning."),
    _j("Code list: Corporate Meeting Type", "Annual General Meeting", "UK market practice", "Relabeled 'Annual Meeting of Stockholders' (DGCL s.211), same meaning."),
    _j("Code list: Corporate Meeting Type", "General Meeting", "UK market practice", "Relabeled 'Special Meeting of Stockholders', same meaning."),
    _j("Code list: Corporate Body Type", "Remuneration Committee", "UK market practice", "Relabeled 'Compensation Committee', same meaning."),
    # Sources
    _j("Sources", "UK Companies Act 2006 (directors, secretary, resolutions Part 13, confirmation statement, PSC register)", "Other EU/UK",
       "Governance references re-sourced to DGCL or Internal."),
    _j("Sources", "Companies House filing guidance (CS01 confirmation statement, AP01 / TM01 officer changes, PSC)", "Other EU/UK", "Statutory filing references re-sourced to DGCL and FinCEN BOI."),
    _j("Sources", "Luxembourg Business Registers: RCS and RBE", "Other EU/UK", "Removed with the Luxembourg filing values."),
    _j("Sources", "EUIPO EU trade mark registration and renewal", "Other EU/UK", "Trademark references cite USPTO alone."),
    _j("Sources", "GDPR Article 28 (processor contracts)", "GDPR / UK GDPR", "Clause Type re-sourced to Regulation S-P (source row added)."),
    _j("Sources", "FCA Senior Managers and Certification Regime (SYSC 24-26, SUP 10C) and Form A", "SM&CR", "Officer roles cite DGCL and SEC Rule 206(4)-7."),
    _j("Sources", "SEC Form ADV and Rule 206(4)-7; FCA MIFIDPRU 7 (ICARA); UK Modern Slavery Act 2015 s.54", "ICARA",
       "The FCA MIFIDPRU 7 part of the source row; the row is retitled 'SEC Form ADV and Rule 206(4)-7'."),
    _j("Sources", "UK Modern Slavery Act 2015 s.54 (part of the SEC Form ADV source row)", "Other EU/UK",
       "Board approval of the modern slavery statement; Subject Corporate Publication now cites Internal with a corporate responsibility report example (42 removes the statement under CW-942)."),
]

REPOINTS = [
    ("Contract", "Contract Business Lines", "Mutual Fund; ETF", "PF", _D),
    ("Corporate Resolution Subject Link", "Subject Corporate Publication", "MSA/0021/2025/1 (modern slavery statement)", "CRR/0004/2025/1 (corporate responsibility report)", _D),
]

DECISIONS = [
    {"id": "CW-939", "theme": "Scope", "title": "US-only pass of 39 Legal & Corporate Governance",
     "domains": ["39"],
     "issue": "The wholesale 39 described the legal record of an asset manager and its group companies in the US and EU/UK. It held UK Companies Act, Companies House, PSC register, Luxembourg RCS / RBE and Irish CRO statutory filings, SM&CR officer roles (senior management function holder, MLRO), the approval link to the 43 ICARA Assessment, a GDPR Article 28 clause type, UK and EU court and employment tribunal forums, the UK written resolution, a UCITS depositary agreement subtype, EUIPO, UKIPO and Benelux trademark offices and EU / UK renewals, and cited the UK Companies Act, Companies House, Luxembourg registers, EUIPO, GDPR Article 28, FCA SM&CR, FCA MIFIDPRU 7 and the UK Modern Slavery Act. Its Business Line example used the removed wholesale values.",
     "resolution": "Affects 43 (ICARA Assessment removed under CW-943) and 42 (corporate publications), noted below. 1) Removed (34 JURISDICTION entries: Other EU/UK 20, UK market practice 5, ICARA 3, SM&CR 3, GDPR / UK GDPR 2, UCITS 1): attribute Corporate Resolution Subject Link.Subject ICARA Assessment; values Corporate Officer Role SM&CR Senior Management Function Holder and MLRO, Corporate Resolution Subject Type ICARA Assessment (43), Statutory Filing Type UK Confirmation Statement, UK PSC Register Update, UK Annual Accounts Filing, UK Officer Appointment / Termination, Luxembourg RCS Filing, Luxembourg RBE Beneficial Owner Filing, Irish CRO Annual Return, Forum Type UK Court and EU Member State Court (relabeled into one Non-US Court, with Other added, program lead ruling) and Employment Tribunal (removed), Corporate Meeting Type Written Resolution, Clause Type Data Protection (GDPR Article 28 DPA), Contract Subtype Depositary Agreement, IP Office EUIPO, UKIPO, BOIP, Docket Deadline Type EU / UK Renewal; UK corporate vocabulary relabeled (Non-Executive Director to Independent / Outside Director, Company Secretary to Corporate Secretary, Annual General Meeting to Annual Meeting of Stockholders, General Meeting to Special Meeting of Stockholders, Remuneration Committee to Compensation Committee); sources UK Companies Act 2006, Companies House, Luxembourg Business Registers, EUIPO, GDPR Article 28, FCA SM&CR, and the MIFIDPRU 7 and Modern Slavery Act parts of the Form ADV source row. No object removed. "
                   "2) Re-sourced: data-protection clauses to Regulation S-P service-provider oversight (17 CFR 248.30) and state privacy law terms (Clause Type value Data Protection and Privacy Terms, list source, secondary reference, Data Processing Agreement description; Regulation S-P source added); statutory filings to Delaware and state annual reports and FinCEN BOI (Statutory Filing Type re-cut with the new value Other State Annual Report; filing attributes cite DGCL, FinCEN BOI or Internal; Delaware franchise tax examples; FinCEN's August 2026 final rule exempts the firm's domestic entities from BOI reporting, so the FinCEN BOI Report value is kept only as a lever for a foreign-formed subsidiary (confirm) and the source row cites the final rule); governance attributes from the UK Companies Act to DGCL or Internal; Corporate Officer Role to SEC Rule 206(4)-7; Regulatory Notification Filing to Form ADV or Form BD; Matter Regulator and trademark attributes lose FCA and EUIPO references; GDPR Article 10 notes read criminal history data (CD-344); Subject Corporate Publication to Internal. "
                   "3) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose, Core model, Design principles 2 and 8, Notes; Corporate Entity Governance and Statutory Filings texts; enrich_39 SUMMARY; the ICARA ownership override removed; Source_Notes header, purpose, section 1 and section 6. Attribute IDs renumber within Corporate Entity Governance after the removed attribute. "
                   "4) Re-pointed: Contract Business Lines example to the CW-004 code PF (W1 merge notes section 5); no reference retyped (REPOINTS, 2 entries). 5) Added: none (brief row 39). "
                   "6) Kept on purpose: Governing Law values (England and Wales, Scotland, Luxembourg, Ireland, Germany, Switzerland), the eIDAS source beside ESIGN, IAS 37 (IFRS reporters, a lever), WIPO Madrid; the 1940 Act fund board items stay 35's. Counts: 29 to 29 objects, 238 to 237 attributes, 83 to 83 CDEs (35%), 44 to 44 code lists, 35 relationships, 24 to 19 sources, 50 PII attributes.",
     "rationale": "CW-003 and CW-022: the firm's entities are organized and regulated in the US only, so UK and Luxembourg company law filings, SM&CR, ICARA, GDPR processor terms and EU/UK trademark offices have no entity or market to apply to; contract governing law and foreign signature law stay as legal facts of the instrument. Names are kept so that DP-213 and the legal models keep resolving; the readers of the removed attribute are listed in NOTES. Lever: a UK or EU entity restores the removed rows from wholesale-v1.0 through the jurisdiction register.",
     "action": "W1b", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

SHARED_RECUTS = []

SHARED_CANDIDATES = [
    ("Governing Law", None, ["05"],
     "No change: the 39 copy of the 05 Governing Law list keeps its non-US values (contract governing law is a legal fact, CW-022); the existing proposal in proposals_39.py stands."),
]

NOTES = [
    "W1b (wealth), CW-939. Validation: taxonomy_builder.py content_39_legal_and_corporate_governance OK (6 families, 29 objects (1 "
    "attribute groups, 0 without grain), 237 attributes, 83 CDEs, 65 references, 7 derived, 0 unresolved, 44 code lists); before: 29 "
    "objects, 238 attributes, 83 CDEs, 66 references, 44 code lists. check_enrichment.py 39 OK. JURISDICTION 34 entries (review fix pass: 5 relabels of UK corporate vocabulary added).",
    "READERS of the removed attribute and values (not edited): data_products/specs_e4_compliance_legal.py DP-230 Corporate Entity "
    "Governance, line 1081 (definition names the removed MLRO and SM&CR function holders: re-scope) and line 1176 (input list includes "
    "Subject ICARA Assessment); data_models/keys_e7_39_41.py line 310 (Subject ICARA Assessment link to "
    "43 ICARA Assessment); data_models/models_e8c_compliance_legal.py line 909 (note naming Subject ICARA Assessment); "
    "data_products/specs_e4_compliance_legal.py line 1176 (Corporate Resolution Subject Link input list includes Subject ICARA "
    "Assessment); data_products/specs_e4_technology_communications.py lines 637 and 721 (trademark coverage by IP Office, may read "
    "the removed EUIPO / UKIPO values); consolidation/decisions.py line 1555; proposals_43.py line 198; proposals_w1b_43.py lines "
    "83-84 and 88 (43's removal of ICARA Assessment, consistent with this pass); proposals_w1b_35.py lines 35 and 67.",
    "References to retiring or later-replaced domains left as they are (W2, W4): 05 Distribution Agreements & Partners (Typed "
    "Contract Link.Linked Distribution Agreement, Reference (Agreement Amendment, 05), Reference (Agreement Document, 05), Typed "
    "Record Type values Distribution Agreement (05) and Agreement Amendment (05), Contract Family Distribution and Intermediary "
    "Agreement); 30 Private Markets (Linked Side Letter, Linked Investor Commitment, Linked Private Fund Profile, Linked Fund Credit "
    "Facility, Typed Record Type values Side Letter, Fund Credit Facility, Investor Commitment, Private Fund Profile, Contract Family "
    "Private Fund Investor Document, ILPA source, the row rule RR naming 30); 08 (retention rules on Legal Hold Scope).",
    "W4 retirement candidates (not removed): Contract Subtype Fund Participation Agreement ('insurance-dedicated funds'); carry vehicles "
    "in the Corporate Entity Governance text; the ILPA Principles and Model LPA in the leases / intercompany source row.",
    "Remaining hits of the step 1 grep, justified: overview Purpose names the removed content; Governing Law values England and Wales, "
    "Luxembourg, Ireland (contract governing law, CW-022); eIDAS (signature validity under a foreign governing law); IAS 37 (IFRS "
    "reporters).",
    "Other domains' content seen: none needing action; 43 already removed ICARA Assessment (CW-943), so the removed attribute would "
    "otherwise have been unresolved after merge.",
    "Review fix pass (2026-10-14): FinCEN BOI wording updated to the August 2026 final rule; Forum Type Non-US Court and Other restored; "
    "UK corporate vocabulary relabeled; DP-230 added to READERS; Business Line example uses the code PF; Regulation S-P amendments "
    "stated as in force.",
    "Unverified (marked confirm in Source_Notes): FinCEN BOI final rule Federal Register citation; Regulation S-P 248.30 service-provider paragraph and "
    "compliance dates.",
]
