"""W1b proposals of Data Domain 40 Procurement & Vendor Management (wealth model; kept with the US-only and perspective
pass). Brief: 00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (row 40); decisions CW-003, CW-004, CW-021,
CW-022, CW-023, CW-039. Declarative only: the program lead merges DECISIONS into decisions.py, appends JURISDICTION to
jurisdiction.REMOVALS and applies SHARED_RECUTS to shared_code_lists.py at merge (W5 for the shared lists, CW-039). The
existing proposals_40.py (expansion) is unchanged.
"""

_D = "CW-940"


def _j(obj, attr, regime, note):
    return {"domain": "40", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


_REG = "Removed with the DORA register of information; the US rules (FINRA Rule 3110, Regulatory Notice 21-29, the 2023 interagency guidance) prescribe no register layout."

# Values of the whole local lists removed with their objects (wholesale-v1.0 values).
_DORA_LISTS = {
    "DORA ICT Service Type": ["S01", "S02", "S03", "S04", "S05", "S06", "S07", "S08", "S09", "S10", "S11", "S12", "S13", "S14",
                              "S15", "S16", "S17", "S18", "S19"],
    "DORA Substitutability": ["Not Substitutable", "Highly Complex Substitutability", "Medium Complexity Substitutability",
                              "Easily Substitutable"],
    "Reintegration Possibility": ["Easy", "Difficult", "Highly Complex"],
    "DORA Assessment Level": ["Low", "Medium", "High"],
    "Level of Reliance": ["Not Significant", "Low Reliance", "Material Reliance", "Full Reliance"],
    "Contractual Arrangement Type": ["Standalone Arrangement", "Overarching Arrangement", "Subsequent or Associated Arrangement"],
    "Arrangement Termination Reason": ["Expired Not Renewed", "Provider Breach of Law or Contract", "Impediment to Supported Function",
                                       "Data Management or Security Weakness", "Competent Authority Request", "Other"],
}
_NOTIF_LISTS = {
    "Outsourcing Notification Type": ["Prior Notification of Material Outsourcing", "Material Change Notification", "Termination Notification"],
    "Outsourcing Notification Status": ["Draft", "Submitted", "Acknowledged", "Further Information Requested", "Objection Raised", "Closed"],
}

# ---------------------------------------------------------------------------------------------------------------------
# Jurisdiction register entries (jurisdiction.REMOVALS format). Objects and attributes use the wholesale-v1.0 names.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = [
    # Objects
    _j("ICT Register Arrangement Header", "", "DORA",
       "DORA register of information template B_07.01 (contract x ICT service type: substitutability, reintegration, discontinuation impact, exit plan, last audit, 41 IT services and applications). " + _REG + " Exit planning stays on Exit Plan; criticality on Supplier Risk Tiering."),
    _j("ICT Register of Information Entry", "", "DORA",
       "DORA register of information template B_02.02 (entity x contract x ICT service type x function: dates, notice periods, governing law country, data locations, sensitiveness, reliance). " + _REG + " The function link stays on Outsourcing Arrangement.Supported Critical or Important Functions."),
    _j("Supply Chain Subcontractor", "", "DORA",
       "DORA register of information template B_05.02 (ICT supply chain rank). " + _REG + " Fourth-party (subcontractor) review is part of due diligence under the interagency guidance and is evidenced on the onboarding case, not as a register."),
    _j("Outsourcing Notification", "", "Other EU/UK",
       "Prior notification of material outsourcing to a competent authority (FCA SYSC 8, CSSF Circular 22/806, EBA/GL/2019/02). No US rule requires the adviser, broker-dealer or funds to notify an outsourcing in advance; restorable from wholesale-v1.0 if the trust company's chartering authority requires one (open question)."),
    # Attributes
    _j("Supplier Contract Profile", "ICT Contractual Arrangement Type", "DORA",
       "DORA B_02.01 arrangement type (standalone, overarching, subsequent); the overarching contract stays 39 Parent Contract."),
    _j("Supplier Contract Profile", "Annual ICT Expense", "DORA",
       "DORA B_02.01 annual expense in the register reporting currency; contract value stays Total Contract Value, spend stays Supplier Spend Summary."),
    _j("Outsourcing Arrangement", "Supported Important Business Services", "FCA",
       "UK important business services (FCA SYSC 15A operational resilience); the 37 critical or important function link stays."),
    # Code-list values: whole local lists removed with the register and notification objects
    *[_j("Code list: " + cl, v, "DORA", "Whole list removed with the DORA register of information.")
      for cl, vals in _DORA_LISTS.items() for v in vals],
    *[_j("Code list: " + cl, v, "Other EU/UK", "Whole list removed with Outsourcing Notification.")
      for cl, vals in _NOTIF_LISTS.items() for v in vals],
    # Code-list values: Outsourcing Regime re-cut to the US set
    _j("Code list: Outsourcing Regime", "EBA Outsourcing Guidelines", "Other EU/UK", "EBA/GL/2019/02; replaced by the US values FINRA Rule 3110 Supervision of Outsourced Functions and Interagency Third-Party Guidance (Trust Company)."),
    _j("Code list: Outsourcing Regime", "ESMA Cloud Outsourcing Guidelines", "Other EU/UK", "ESMA50-164-4285; no US cloud-specific regime (cloud outsourcings fall under FINRA Regulatory Notice 21-29)."),
    _j("Code list: Outsourcing Regime", "FCA SYSC 8", "FCA", "UK outsourcing rules; no UK entity."),
    _j("Code list: Outsourcing Regime", "CSSF Circular 22/806", "Other EU/UK", "Luxembourg ManCo and AIFM outsourcing; no Luxembourg entity."),
    _j("Code list: Outsourcing Regime", "DORA ICT Third-Party (ICT service supporting critical or important function)", "DORA", "Marked outsourcings that were also DORA ICT arrangements."),
    _j("Code list: Outsourcing Regime", "UCITS / AIFMD Delegation", "Other EU/UK", "UCITS and AIFMD delegation of portfolio or risk management; no EU fund range. US sub-adviser oversight is SEC Rule 38a-1 and the 15(c) process in 35."),
    _j("Code list: Diversity Certification Type", "UK SME", "Other EU/UK", "UK definition of small and medium-sized enterprise; the US SBA size standard (Small Business) stays."),
    _j("Code list: Tax Form Type", "CRS Self-Certification - Individual", "CRS", "OECD CRS self-certification; the US is not a CRS participant. The list is aligned to the IRS forms of 15 Tax Form Type."),
    _j("Code list: Tax Form Type", "CRS Self-Certification - Entity", "CRS", "As above."),
    # Sources
    _j("Sources", "Regulation (EU) 2022/2554 on digital operational resilience for the financial sector (DORA), Articles 28-30", "DORA",
       "Removed with the register; exit, contract and due-diligence fields re-sourced to the 2023 interagency guidance and FINRA Regulatory Notice 21-29."),
    _j("Sources", "Commission Implementing Regulation (EU) 2024/2956 laying down ITS on the register of information (templates B_01.01 to B_07.01, Annex III ICT service types)", "DORA",
       "Removed with the register objects, the B_02.01 fields and the seven register lists."),
    _j("Sources", "Commission Delegated Regulation (EU) 2024/1773 (RTS on the policy for ICT services supporting critical or important functions)", "DORA",
       "Was cited for tiering and onboarding; re-sourced to the interagency guidance."),
    _j("Sources", "EBA Guidelines on outsourcing arrangements (EBA/GL/2019/02)", "Other EU/UK",
       "Outsourcing Arrangement and Exit Plan re-sourced to FINRA Regulatory Notice 21-29 and the interagency guidance."),
    _j("Sources", "ESMA Guidelines on outsourcing to cloud service providers (ESMA50-164-4285)", "Other EU/UK", "Removed with the regime value."),
    _j("Sources", "FCA Handbook SYSC 8 (Outsourcing) and SYSC 15A (Operational resilience)", "FCA",
       "Removed with Outsourcing Notification, Supported Important Business Services and the regime value."),
    _j("Sources", "CSSF Circular 22/806 on outsourcing arrangements", "Other EU/UK", "Removed with Outsourcing Notification and the regime value."),
    _j("Sources", "GDPR Articles 9 and 28; ISO/IEC 27001 Annex A", "GDPR / UK GDPR",
       "Replaced by SEC Regulation S-P (17 CFR Part 248 Subpart A, service-provider oversight) and the CCPA as amended by the CPRA; ISO/IEC 27001 kept on the Regulation S-P row."),
    _j("Sources", "UK OFSI consolidated list (part of 'OFAC sanctions programs and UK OFSI consolidated list')", "Other EU/UK",
       "Sanctions screening re-sourced to OFAC alone; the source row is retitled to the OFAC programs and SDN List."),
]

# ---------------------------------------------------------------------------------------------------------------------
# Decision of the US-only pass of 40 (decisions.DECISIONS format)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-940", "theme": "Scope", "title": "US-only pass of 40 Procurement & Vendor Management",
     "domains": ["40", "14", "37", "41"],
     "issue": "The wholesale 40 carried the DORA register of information (ICT Register Arrangement Header, ICT Register of Information Entry, Supply Chain Subcontractor, the B_02.01 fields on Supplier Contract Profile and seven register lists), EU/UK outsourcing notifications to competent authorities (Outsourcing Notification and its two lists), the UK important business service link, EU/UK outsourcing regime values, a UK SME certification, CRS self-certification values and EU/UK sources (DORA, its ITS and RTS, EBA and ESMA outsourcing guidelines, FCA SYSC 8 and 15A, CSSF Circular 22/806, GDPR, UK OFSI). Its text described an asset manager distributing wholesale in the US and the EU/UK, with personal data framed by GDPR.",
     "resolution": "1) Removed (76 JURISDICTION entries: DORA 51, Other EU/UK 19, FCA 3, CRS 2, GDPR / UK GDPR 1): objects ICT Register Arrangement Header, ICT Register of Information Entry, Supply Chain Subcontractor, Outsourcing Notification; attributes Supplier Contract Profile.ICT Contractual Arrangement Type and Annual ICT Expense, Outsourcing Arrangement.Supported Important Business Services; local lists DORA ICT Service Type, DORA Substitutability, Reintegration Possibility, DORA Assessment Level, Level of Reliance, Contractual Arrangement Type, Arrangement Termination Reason, Outsourcing Notification Type, Outsourcing Notification Status; values Outsourcing Regime (EBA, ESMA cloud, FCA SYSC 8, CSSF 22/806, DORA ICT Third-Party, UCITS / AIFMD Delegation), Diversity Certification Type UK SME, Tax Form Type CRS Self-Certification (Individual, Entity); sources DORA Articles 28-30, ITS 2024/2956, RTS 2024/1773, EBA/GL/2019/02, ESMA50-164-4285, FCA SYSC 8 and 15A, CSSF 22/806, GDPR Articles 9 and 28, UK OFSI. GRAIN of the three register objects and Outsourcing Notification and the five DERIVED entries of the register entry removed from enrich_40. "
                   "2) Re-sourced: Outsourcing Arrangement (ID, Outsourcing Entity, Outsourced Function Description, Outsourcing Regimes, Supported Critical or Important Functions, Critical or Important Outsourcing Indicator, Outsourcing Contract, Intragroup Outsourcing Indicator, Service Commencement Date) to FINRA Regulatory Notice 21-29, FINRA Rule 3110, the 2023 interagency third-party guidance and Regulation S-P; Exit Plan (all four attributes) and Supplier Contract Profile.Exit Assistance Period to the interagency guidance and FINRA Regulatory Notice 21-29; Supplier Risk Tiering (tier and drivers) and the Criticality Driver and Exit Strategy Type lists the same way; Outsourcing Regime re-cut to FINRA Rule 3110 Supervision of Outsourced Functions, SEC Rule 38a-1 Service Provider Oversight, Advisers Act Rule 206(4)-7 Service Provider Oversight, Reg S-P Service Provider Oversight, Interagency Third-Party Guidance (Trust Company), Other (the historical value SEC Outsourcing Proposal (withdrawn), Release IA-6176 withdrawn June 12, 2025, is dropped and its history kept in Source_Notes; Release IA-6176 also leaves the SEC Rule 38a-1 source row); Shared Data Assets and the Data Protection Assessment onboarding step to Regulation S-P (17 CFR 248.30); diversity certification sensitivity to state privacy law (CCPA as amended by the CPRA); Sanctions Screening Result to OFAC alone; Bank Identifier to the ABA routing number (BIC abroad; UK sort code dropped) and Bank Account Number (Masked) to a US example; Ownership ruled by the program lead: 40 masters the supplier's tax form on file (payee Form W-9 and W-8); the wealth 02 holds no form type and 15 covers accounts only, so the Derived (02) flag is removed and the Supplier Management family text, the first relationship row and Source_Notes sections 1 and 2 say so; the local Tax Form Type is aligned to 15 (Substitute Form W-9 and W-8ECI added, CRS values removed).  Sources added: SEC Regulation S-P (2024 amendments), CCPA / CPRA, FINRA Rule 3110 and Regulatory Notice 21-29; the SEC Rule 38a-1 and interagency rows reworded; the OFAC row retitled. "
                   "3) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose, Scope, Core model, Design principles 5, 7 and 9, Applies To, CDE, Primary / Secondary Reference, Notes and Suggested next steps; Criticality & Outsourcing family text and Supplier Contract Profile object text; Outsourced Function Description example; enrich_40 SUMMARY; Source_Notes status, purpose and section 6. "
                   "4) Re-points (REPOINTS list): Engagement Business Lines example 'Mutual Fund; ETF' to 'PF; DB' (CW-004); 02 named Client & Household, the party core for every external party (CW-023); Tax Form on File wording to the wealth 02 Tax Profile and 15 Account Tax Certification; Reference (Party) unchanged (CW-021). 40 no longer references 41 and no longer cites the shared Regulator list. "
                   "5) Additions: none (the brief names none for 40). Attribute IDs renumber in the Supplier Contracts and Criticality & Outsourcing families. Counts: 25 to 21 objects, 219 to 172 attributes, 69 to 57 CDEs (33%), 50 to 38 references, 12 to 6 derived, 42 to 32 code lists (33 to 24 local), 42 to 35 relationships, 19 to 14 sources, 20 to 17 PII attributes.",
     "rationale": "CW-003 and CW-022: the wealth model is regulated in the US only. DORA, the EU/UK outsourcing notifications and the UK operational resilience regime do not apply; the vendor oversight they also served is a US obligation under FINRA Rule 3110 and Regulatory Notice 21-29 (broker-dealer), SEC Rule 38a-1 (funds), Regulation S-P (customer information) and the 2023 interagency guidance (trust company), so the generic outsourcing register, exit plan and tiering stay, re-sourced. Names are kept so that DP-210, DP-217 and DP-219 keep resolving; DP-220 (Outsourcing & DORA Register of Information) loses most of its inputs and is a WP0 re-scope candidate (NOTES). Lever: a UK extension restores the register objects from wholesale-v1.0 through the jurisdiction register.",
     "action": "W1b", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# Shared list re-cuts proposed (applied by the program lead at W5, CW-039)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_RECUTS = [
    ("DORA Substitutability", "retire",
     "Steward 40. CW-039 retires the list. Its member ('40', 'DORA Substitutability') left with the removed ICT Register Arrangement Header (CW-940); "
     "the other member ('14', 'Substitutability') is re-sourced to a firm-defined scale under CW-914, so the shared list and its value map are deleted."),
    ("DORA ICT Service Type", "retire (member 40 leaves)",
     "Steward 41. CW-039 retires the list. 40's member ('40', 'DORA ICT Service Type') left with the register (CW-940); 41 replaces its member "
     "with a firm-defined ICT Service Type under CW-941; direct user 14 drops it under CW-914."),
    ("Regulator", "drop direct user 40",
     "40 cited Shared: Regulator only on Outsourcing Notification.Notified Authority (removed); remove '40' from direct_users."),
]

SHARED_CANDIDATES = [
    ("Tax Form Type", ["15", "40"],
     "Steward 15. 40's local list now has the same seven IRS values as 15 (W-9, Substitute Form W-9, W-8BEN, W-8BEN-E, W-8IMY, W-8EXP, W-8ECI); register 40 as a member at W5. The 02 record should note that Tax Profile.Tax Status Evidence has no supplier counterpart (40 masters the supplier form on file, CW-940)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# Re-points of wording (carryover_common step 4): (object, attribute, before, after, decision)
# ---------------------------------------------------------------------------------------------------------------------
REPOINTS = [
    ("Supplier Engagement", "Engagement Business Lines", "example 'Mutual Fund; ETF'", "example 'PF; DB' (CW-004 codes)", "CW-940"),
    ("Supplier Engagement", "Specialized Servicing Provider Engagement", "'where the supplier services shareholders'", "'where the supplier services fund shareholders'", "CW-940"),
    ("Supplier Profile", "Tax Form on File", "'Derived copy (02) of the party's Tax Form Type, once 02 extends Tax Form Type ... to the Supplier role'", "'Mastered here for suppliers (CW-940): the wealth 02 Tax Profile holds the tax classification and masked TIN; client forms are 15 Account Tax Certifications'", "CW-940"),
    ("Supplier Management (family text)", "", "'tax forms and TINs are mastered in 02'", "'tax status and TINs are mastered in 02; the supplier's tax form on file is mastered here'", "CW-940"),
    ("Supplier Profile (relationship to Party [02])", "", "'tax forms and TINs stay in 02'", "'tax status and TINs stay in 02; the tax form on file is mastered here'", "CW-940"),
    ("META overview (Scope)", "", "'tax forms and TINs (02 Client & Customer)'", "'tax status (02 Client & Household, the party core for every external party)'", "CW-940, CW-023"),
    ("enrich_40 SUMMARY", "", "'02 Client & Customer'", "'02 Client & Household (the party core for every external party)'", "CW-940, CW-023"),
]

# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "W1b (wealth), CW-940. Validation: taxonomy_builder.py content_40_procurement_and_vendor_management OK (6 families, 21 objects, 172 attributes, 57 CDEs, 38 references, 6 derived, 0 unresolved, 32 code lists); check_enrichment.py 40 OK. Before: 6 families, 25 objects, 219 attributes, 69 CDEs, 50 references, 12 derived, 42 code lists.",
    "READERS of removed objects and attributes (not edited; for the program lead and the product, model and semantic owners; line numbers at 2026-10-14): "
    "data_products/specs_e4_risk_audit_third_party.py DP-220 'Outsourcing & DORA Register of Information' lines 875, 882-897, 904-925, 930, 935-937, 943, 951-954, 981, 994, 1004 (grain, metrics Register Entries, Register Completeness %, Missing Outsourcing Notifications, Open Authority Responses, Annual ICT Expense in Register and the input list read the three register objects, Outsourcing Notification, ICT Contractual Arrangement Type, Annual ICT Expense and Supported Important Business Services: WP0 re-scope to a US outsourcing register product or retire); "
    "same file DP-217 lines 461, 466, 510 (Supported Important Business Services); DP-219 lines 725, 729-731, 794-796 (Exit Readiness Gap reads the register header and entry); "
    "data_products/specs_e1_masters.py DP-210 lines 754-755, 780 (metric ICT Suppliers Without LEI and its input read ICT Contractual Arrangement Type); data_products/framework.py line 1109 (DP-220 catalog entry title); "
    "data_models/models_e8c_risk_audit_third_party.py lines 69-70 (ICTHDR, ICTENTRY entity constants), 419 (DP-217), 514, 521-524, 531-532, 557-572, 579, 583-586 (DP-220 entities), 675-677, 723-726, 736 (DP-219); "
    "data_models/keys_e7_39_41.py lines 153-159 (keys of Outsourcing Notification and the three register objects), 375 (Supported Important Business Services link to 37 Important Business Service), 379-392 (links of the removed objects); "
    "semantic_model/models/sm_00_shared_dimensions.py line 800 (SM-00 dimension ict_arrangement_type on supplier_contract_profile); capability_map/content_capabilities.py line 1038 (C-13.13 note: '40 masters the Outsourcing Arrangement, Outsourcing Notification and the DORA register'). Generated outputs (data_products/_catalog.txt, semantic_model/out) refresh on rebuild.",
    "References to domains that retire or are replaced later, left as they are: overview Design principles 4 'deal costs (30) are not firm purchase orders' (30 retires at W4); Sourcing family text '03 RFP Requests (RFP-)' and Scope 'RFPs the firm answers (03)' (03 replaced later); Contracted Service Level row rule '05 Service Level Agreement' (05 replaced at W4); Specialized Servicing Provider Engagement (13, adapted at W2).",
    "Other domains' content seen (not edited): 14 ICT Third-Party Register Entry was the data-vendor view of the 40 register (CD-261) and loses its 40 source (CW-914); 37 Important Business Service is UK-only (SYSC 15A) and 37 Critical or Important Function cites DORA Article 3(22), for the 37 editor (CW-937); 41 IT Service and Application lose their only 40 reader. 02: the wealth 02 has no Tax Form Type list (15 holds it); if 02 or 15 extends the form on file to suppliers, 40 Tax Form on File becomes a Derived copy again.",
    "Remaining hits of the step 1 grep, justified: 'EU or UK' in the Scope overview (states the removal); 'ISO 13616' (IBAN for a supplier paid abroad, a payment format, kept) and 'ISO 9362' (BIC); OECD SAF-T on Matched Invoice Line Number (OECD invoice line concept, kept); 'Customer information' (Regulation S-P term); 'fund shareholders' (13 servicing, fund level).",
    "Unverified (marked confirm in Source_Notes): the CPRA sensitive personal information basis of the restricted diversity values. Verified by the W1b review: FINRA Regulatory Notice 21-29, the 72-hour Regulation S-P service-provider notice, the withdrawal of Release IA-6176 on June 12, 2025.",
    "READERS (added after review): consolidation/gaps_register.py GAP-37-009 (lines 4005-4008; objects include 40 ICT Register of Information Entry), GAP-40-002 (lines 4197-4201; Outsourcing Notification and ICT Register Arrangement Header; its resolution proposes a 'Register of Information Submission' object, which lapses with CW-940) and GAP-40-001 (line 4191 issue text 'outside the DORA register'); capability_map/content_capabilities.py line 1060 ('the outsourcing and DORA registers are split out (C-13.13)').",
    "For the lead and the W5 gap review: the removed ICT Register Arrangement Header held the only 40 to 41 links (Supported IT Services, Supported Applications) and generic third-party facts the 2023 interagency guidance also expects (Last Audit Date, Data at Rest Locations, Data Processing Locations, Substitutability). GAP-40-001 (Supplier Engagement and Application not linked, High) now has no interim path. Candidate for a US outsourcing-register re-scope together with DP-220; no attribute added in W1b.",
    "Dependency: Outsourcing Arrangement.Supported Critical or Important Functions resolves only because the 37 editor kept 37 Critical or Important Function as a deviation from brief row 37 (CW-937, proposals_w1b_37 NOTES); the lead should rule CW-937 and CW-940 together.",
]
