"""W1b proposals of Data Domain 41 Technology & Information Security (wealth model; kept with the US-only and perspective
pass and the Regulation S-P and S-ID additions). Brief: 00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (row 41);
decisions CW-003, CW-004, CW-021, CW-022, CW-039; plan section 5.1 row 41. Declarative only: the program lead merges
DECISIONS into decisions.py, appends JURISDICTION to jurisdiction.REMOVALS and applies SHARED_RECUTS at W5 (CW-039). The
existing proposals_41.py (expansion) is unchanged.
"""

_D = "CW-941"


def _j(obj, attr, regime, note):
    return {"domain": "41", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


_ICT = ["ICT project management", "ICT Development", "ICT help desk and first level support", "ICT security management services",
        "Provision of data", "Data analysis", "ICT, facilities and hosting services (excluding Cloud services)", "Computation",
        "Non-Cloud Data storage", "Telecom carrier", "Network infrastructure", "Hardware and physical devices",
        "Software licencing (excluding SaaS)", "ICT operation management (including maintenance)", "ICT Consulting",
        "ICT Risk management", "Cloud services: IaaS", "Cloud services: PaaS", "Cloud services: SaaS"]

# ---------------------------------------------------------------------------------------------------------------------
# Jurisdiction register entries (jurisdiction.REMOVALS format). Objects and attributes use the wholesale-v1.0 names.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = [
    # Attributes
    _j("AI System Profile", "Input Data Controlled Indicator", "Other EU/UK",
       "EU AI Act Article 26(4) deployer duty on input data; no US rule. Data relevance for AI is governed through the NIST AI RMF (Map, Measure) on 21 AI Use Case; the other AI System Profile attributes stay, re-sourced to the NIST AI RMF."),
    _j("IT Incident", "Occurrence Time Estimated Indicator", "DORA",
       "DORA incident report data point (RTS 2024/1772, ITS 2025/302); Incident Occurrence Timestamp stays, re-sourced to NIST SP 800-61."),
    _j("Security & Resilience Test", "TLPT Attestation Date", "DORA",
       "Competent-authority attestation of a threat-led penetration test (DORA Article 26, RTS 2025/1190); no US attestation. Red team exercises stay a Test Type."),
    # Code-list values
    _j("Code list: Test Type", "Threat-Led Penetration Test (TLPT)", "DORA", "DORA Article 26; Red Team Exercise and Penetration Test stay."),
    *[_j("Code list: ICT Service Type", v, "DORA",
         "DORA Annex III ICT service taxonomy (ITS 2024/2956, S01-S19); the attribute IT Service.ICT Service Type stays with a firm-defined list (CW-039 retires the shared DORA ICT Service Type).")
      for v in _ICT],
    # Sources
    _j("Sources", "Regulation (EU) 2022/2554 on digital operational resilience for the financial sector (DORA), Articles 8, 9, 11, 17-19, 24-28", "DORA",
       "Asset, access, incident, testing and recovery references re-sourced to NIST CSF 2.0, NIST SP 800-53, 800-61, 800-115 and 800-34, FINRA Rule 4370 and the FFIEC handbook."),
    _j("Sources", "Commission Implementing Regulation (EU) 2024/2956, register of information templates (ICT services taxonomy)", "DORA",
       "Removed with the S01-S19 values of ICT Service Type."),
    _j("Sources", "Commission Delegated Regulation (EU) 2024/1772 (classification of ICT-related incidents) and Delegated Regulation (EU) 2025/301 / Implementing Regulation (EU) 2025/302 (content and templates of incident reports)", "DORA",
       "Incident timing and data impact re-sourced to NIST SP 800-61, ITIL 4 and FIPS 199."),
    _j("Sources", "Commission Delegated Regulation (EU) 2025/1190, RTS on threat-led penetration testing (OJ L 18.6.2025)", "DORA",
       "Removed with TLPT Attestation Date and the TLPT test type; testers re-sourced to NIST SP 800-115."),
    _j("Sources", "Regulation (EU) 2024/1689 (Artificial Intelligence Act), Articles 3 and 26, as amended by the Digital Omnibus on AI (in force July 27, 2026)", "Other EU/UK",
       "AI System Profile and AI System Model Deployment re-sourced to the NIST AI RMF (NIST AI 100-1), FINRA Regulatory Notice 24-09 and SEC Rule 17a-4."),
    _j("Sources", "UK FCA SYSC 15A Operational resilience", "FCA",
       "Important business services are UK only; the 37 critical or important function mapping stays."),
    _j("Sources", "Regulation (EU) 2016/679 (GDPR) Articles 4(12), 33 and 34", "GDPR / UK GDPR",
       "Personal Data Affected Indicator re-sourced to Regulation S-P and state breach notification laws."),
]

# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-941", "theme": "Scope", "title": "US-only pass of 41 Technology & Information Security",
     "domains": ["41", "14", "37", "40"],
     "issue": "The wholesale 41 carried DORA content (the ICT Service Type S01-S19 taxonomy of the register of information, IT incident data points for DORA major-incident classification, TLPT test type and attestation, DORA references on access, criticality, recovery, testing and legal entities), EU AI Act deployer facts on AI System Profile, the UK important business service mapping and GDPR breach references, and EU/UK sources. Its text described an asset manager distributing wholesale in the US and the EU/UK. It held the Regulation S-P incident facts but no record of the written programs that Regulation S-P and Regulation S-ID require.",
     "resolution": "1) Removed (30 JURISDICTION entries: DORA 26, Other EU/UK 2, FCA 1, GDPR / UK GDPR 1): attributes AI System Profile.Input Data Controlled Indicator, IT Incident.Occurrence Time Estimated Indicator, Security & Resilience Test.TLPT Attestation Date; Test Type value Threat-Led Penetration Test (TLPT); the 19 DORA values of ICT Service Type; sources DORA, ITS 2024/2956, RTS 2024/1772 with 2025/301 and 2025/302, RTS 2025/1190, EU AI Act, FCA SYSC 15A, GDPR. No NIS2 or UK cyber content was found. "
                   "2) Re-sourced: IT Service.ICT Service Type to a firm-defined list (14 values; CW-039 retires the shared DORA ICT Service Type); AI System Profile (AI System Provider, Log Retention Months, Human Oversight Assignee), AI System Model Deployment and the Application Type value AI System to the NIST AI RMF, FINRA Regulatory Notice 24-09 and SEC Rule 17a-4; IT Incident (Incident Occurrence Timestamp, Incident Detected Timestamp, Service Restored Timestamp, Service Downtime Minutes, Data Impact Types, Detection Source, Incident Root Cause Category, Affected Legal Entities, Major Incident Indicator wording) to NIST SP 800-61, ITIL 4, FIPS 199 and Regulation S-P; Security Incident Detail.Personal Data Affected Indicator and Affected Individuals Estimate to Regulation S-P and state breach notification laws; Security & Resilience Test (Test Type, Tested Applications, Tested IT Services, Tested Financial Entity, External Tester) to NIST SP 800-115, 800-34, FINRA Rule 4370 and the FFIEC handbook; Application.Owning Legal Entity and Criticality Tier, Application Recovery Profile.Recovery Tier and System Access Grant dates lose their DORA references; lists Detection Source, Data Impact Type, Root Cause Category and Test Type re-sourced. "
                   "3) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose, Scope, Core model, Design principles 2 and 6, Applies To, CDE, Primary / Secondary Reference, Notes and Suggested next steps; family texts of IT Service & Incident Management and Security Testing & Vulnerabilities; object texts of AI System, IT Service and Security Incident Detail; examples (capability C-15.05, IT service and access role names, interface endpoints); 'investor-portal' reads 'client-portal'; 02 named Client & Household; FFIEC source reworded to the optional trust company; enrich_41 SUMMARY and docstring. "
                   "4) Re-points (REPOINTS list, 10 entries; after review: Application Recovery Profile object text no longer cites important business services, Program Approval Date wording per 17 CFR 248.201(e)(1), Purpose reads 'every Data Domain'): Business Lines Served example to 'DB; DA; HA' and Program Business Lines to 'PF; WR' (CW-004); the IT Service Code note and the relationship citing 40 ICT Register of Information Entry and 14 ICT Third-Party Register Entry removed (both objects leave under CW-940 and CW-914); Reference (Party) unchanged (CW-021). "
                   "5) Added (plan section 5.1): object Information Security Program (Security Program Code, Security Program Type, Covered Legal Entities, Program Policy, Program Owner, Program Approval Date, Program Last Review Date, Last Board Report Date, Program Compliance Date, Security Program Status; 4 CDEs); Security Incident Detail.Governing Response Program (Reference (Information Security Program, 41), CDE) and Identity Theft Red Flag Indicator (CDE); local list Security Program Type (Regulation S-P Safeguards and Incident Response, Regulation S-ID Identity Theft Prevention, Firm Information Security Program, Regulation SCI Policies and Procedures, Other); three relationships; sources 17 CFR 248.30, Regulation S-ID (17 CFR Part 248 Subpart C), FINRA Rule 4370 and cybersecurity guidance, Regulation SCI (only for an SCI entity), NIST AI RMF, FINRA Regulatory Notice 24-09, NIST SP 800-115 and 800-84, state breach notification laws, SEC Rules 17a-4 and 204-2; GRAIN entry in enrich_41. No new prefix (firm code 'ISP nnnn'). Attribute IDs renumber in the Application Portfolio, IT Service & Incident Management and Security Testing & Vulnerabilities families. Counts: 33 to 34 objects, 280 to 289 attributes, 81 to 87 CDEs (30.1%), 43 to 46 references, 55 to 56 code lists, 57 to 59 relationships, 31 to 33 sources.",
     "rationale": "CW-003 and CW-022: DORA, the EU AI Act, UK operational resilience and GDPR do not apply to a US-only firm; the generic technology records they also served stay, re-sourced to NIST and the US rules. Plan section 5.1 asks 41 to state the Regulation S-P safeguards and incident response program and the Regulation S-ID red flags program as program and incident attributes: the incident facts already existed, the program facts did not. Regulation SCI is stated as applying only to an SCI entity, which the firm is not by default. Names are kept so that DP-211, DP-231, DP-232 and SM-17 keep resolving; the readers of the three removed attributes and of the DORA values are listed in NOTES.",
     "action": "W1b", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
SHARED_RECUTS = [
    ("DORA ICT Service Type", "retire",
     "Steward 41. CW-039 retires the list. 41's member ('41', 'ICT Service Type') now holds a firm-defined list (14 values) and leaves the membership; "
     "40's member left with the register (CW-940); direct user 14 drops it (CW-914). Delete the shared list and its value map; if another domain "
     "later needs a shared ICT service taxonomy, promote 41 ICT Service Type under its own name."),
    ("DORA Substitutability", "retire",
     "Not used by 41; recorded here only because the brief pairs it with DORA ICT Service Type (steward 40, CW-940)."),
]

REPOINTS = [
    ("Application Capability Mapping", "Business Lines Served", "example 'Mutual Fund; ETF'", "example 'DB; DA; HA' (CW-004 codes)", "CW-941"),
    ("Change Program", "Program Business Lines", "example 'Mutual Fund; Collective Investment Trust'", "example 'PF; WR' (CW-004 codes)", "CW-941"),
    ("IT Service", "IT Service Name", "example 'Shareholder recordkeeping service'", "example 'Client brokerage account servicing'", "CW-941"),
    ("Application Access Role", "Access Role Name", "example 'Shareholder correspondence approver'", "example 'Client correspondence approver'", "CW-941"),
    ("Application Capability Mapping", "Supported Business Capability", "example 'C-07.02 Shareholder Recordkeeping'", "example 'C-15.05 Account Opening & Maintenance'", "CW-941"),
    ("Code list: Identity Type", "External User", "'Investor-portal, data-room or supplier user'", "'Client-portal, data-room or supplier user'", "CW-941"),
    ("META overview (Notes, Scope)", "", "'external investor-portal users'; '02 Client & Customer parties'", "'external client-portal users'; '02 Client & Household parties'", "CW-941, CW-023"),
    ("Application", "Owning Legal Entity", "'the CIT trustee bank or a DORA financial entity'", "'the broker-dealer or the trust company'", "CW-941"),
    ("IT Incident", "Affected Legal Entities", "'a DORA financial entity or the CIT trustee bank'", "'the broker-dealer, the adviser, the funds or the trust company and the programs that cover them'", "CW-941"),
    ("Application Recovery Profile (object text)", "", "'the ICT continuity facts 37 reads for important business services'", "'the recovery objectives of BIA-critical applications, read by 37 for critical or important functions and the FINRA Rule 4370 plan'", "CW-941"),
]

SHARED_CANDIDATES = [
    ("Security Program Type", ["41", "38"],
     "Local to 41 now; 38 compliance program inventories may cite it if 38 records the Regulation S-P and S-ID programs in its compliance calendar (W4)."),
]

# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "W1b (wealth), CW-941. Validation: taxonomy_builder.py content_41_technology_and_information_security OK (7 families, 34 objects, 289 attributes, 87 CDEs, 46 references, 0 derived, 0 unresolved, 56 code lists); check_enrichment.py 41 OK. Before: 7 families, 33 objects, 280 attributes, 81 CDEs, 43 references, 0 derived, 55 code lists.",
    "READERS of removed attributes (not edited; line numbers at 2026-10-14): data_products/specs_e1_masters.py DP-211 line 902 (AI System Profile input list reads Input Data Controlled Indicator); data_products/specs_e4_people_workplace_ai.py DP-104 line 1227 (Input Data Controlled Indicator); "
    "data_products/specs_e4_technology_communications.py DP-231 lines 42-44 and 103 (Occurrence Time Estimated Indicator), DP-232 lines 249-250 and 267 (TLPT Attestation Date, TLPT metric); semantic_model/models/sm_17_technology_data_communications.py lines 416 (occurrence_time_estimated), 536 and 1858 (tlpt_attestation). "
    "READERS of removed values (the attribute stays): the DORA S-codes and labels of ICT Service Type and the TLPT test type are named in data_products/specs_e4_risk_audit_third_party.py DP-217 line 533, DP-220 lines 877 and 982; data_products/specs_e4_technology_communications.py DP-232 lines 171, 181, 235, 249-250, 267, 313; data_models/models_e8c_risk_audit_third_party.py line 359 (DP-217); data_models/models_e8c_technology_communications.py lines 197, 210 (DP-232); semantic_model/models/sm_16_risk_compliance_legal_audit.py line 280; semantic_model/models/sm_17_technology_data_communications.py lines 536, 1845, 1857-1859 and 2362 (DP-245). Readers of IT Service.ICT Service Type by name keep resolving (DP-211 lines 902-905).",
    "READERS (added after review): consolidation/gaps_register.py GAP-41-003 (lines 4243-4247, 'No TLPT cycle due date or DORA TLPT scope designation'; resolution proposes TLPT In Scope Indicator on 09 and Next TLPT Due Date in 41): to be closed with CW-941 (TLPT removed).",
    "For the 38 stage (W4): Information Security Program.Program Last Review Date and Last Board Report Date may overlap 38 Compliance Program Review (content_38 line 199) if 38 adds a Regulation S-ID review type; one of the two should reference the other.",
    "W5 rename candidate: Security & Resilience Test.Tested Financial Entity keeps the DORA defined term 'financial entity' under the name-continuity rule; candidate name 'Tested Legal Entity'.",
    "The new Information Security Program has no reader yet; 38 (compliance calendar, W4) and 37 (control testing) may reference it by name.",
    "References to domains replaced or retired later, left as they are: Security Incident Detail texts and the relationship 'Shareholder Communication [13] / Client communication [12]' (13 adapted at W2, 12 at W4; the wealth customer notice is likely a 45 or 13 client communication); Hosting Model value Provider-Hosted names a 'private fund administrator' (30 retires at W4); Source_Notes section 5 lists '30 Private Fund Platform' and '05 Sub-Accounting Platform' system re-typings (W4).",
    "Other domains' content seen (not edited): 37 Resilience Resource Mapping and Operational Incident carry the DORA classification and important business services (CW-937); 14 ICT Third-Party Register Entry cited 41 IT services (CW-914); 21 AI Use Case may still hold EU AI Act operator roles and risk classes (CW-921).",
    "Remaining hits of the step 1 grep, justified: 'EU' only in the ICT Service Type note stating the retirement; 'Customer' in Regulation S-P terms (sensitive customer information, customer notice); 'Shareholder Communication [13]' (13's object name).",
    "Unverified (marked confirm in Source_Notes): FINRA cybersecurity key-topics URL and Regulatory Notice 24-09 title; NCSL breach-law URL; eCFR section URLs of 17 CFR 242.1000 and 240.17a-4; Regulation S-ID board approval and annual report wording; the NIST AI RMF definition wording; that the broker-dealer is not an SCI entity.",
]
