"""W1b proposals of Data Domain 42 Corporate Communications & Public Affairs (wealth model; kept with the US-only and
perspective pass). Brief: 00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (row 42); decisions CW-003, CW-022,
CW-023. Declarative only: the program lead merges DECISIONS into decisions.py and appends JURISDICTION to
jurisdiction.REMOVALS. The existing proposals_42.py (expansion) is unchanged.
"""

_D = "CW-942"


def _j(obj, attr, regime, note):
    return {"domain": "42", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


_BANDS = ["EUR 0 - 9,999", "EUR 10,000 - 24,999", "EUR 25,000 - 49,999", "EUR 50,000 - 99,999", "EUR 100,000 - 199,999",
          "EUR 200,000 - 299,999", "EUR 300,000 - 399,999", "EUR 400,000 - 499,999", "EUR 500,000 - 599,999",
          "EUR 600,000 - 699,999", "EUR 700,000 - 799,999", "EUR 800,000 - 899,999", "EUR 900,000 - 999,999",
          "EUR 1,000,000 or more"]

JURISDICTION = [
    # Attributes
    _j("Lobbying Disclosure Report", "EU TR Cost Band", "Other EU/UK",
       "EU Transparency Register annual cost band; the LD-2 Lobbying Expense Amount and the reporting-floor indicator stay."),
    _j("Corporate Publication", "Government Portal Submission Date", "Other EU/UK",
       "Submission to the UK gender pay gap service and the UK modern slavery statement registry; no US publication in the model is submitted to a government portal."),
    _j("Publication Source Link", "Source PAI Calculation", "SFDR",
       "Link to the 34 principal adverse impact calculation (SFDR entity statement); the 34 PAI content leaves under CW-934."),
    # Code-list values
    *[_j("Code list: EU TR Cost Band", v, "Other EU/UK", "Whole list removed with the attribute.") for v in _BANDS],
    _j("Code list: Lobbying Regime", "EU Transparency Register", "Other EU/UK", "Interinstitutional Agreement of 20 May 2021; the LDA and US state regimes stay."),
    _j("Code list: Lobbying Regime", "UK Register of Consultant Lobbyists", "Other EU/UK", "UK Transparency of Lobbying Act 2014."),
    _j("Code list: Registrant Category", "EU TR Category II - Company or Group", "Other EU/UK", "EU Transparency Register Annex I."),
    _j("Code list: Registrant Category", "UK Client of Consultant Lobbyist", "Other EU/UK", "UK consultant lobbyist register."),
    _j("Code list: Lobbying Report Type", "EU TR Annual Update", "Other EU/UK", "EU Transparency Register annual update (key code EUTR)."),
    _j("Code list: Publication Type", "Modern Slavery Statement", "Other EU/UK", "UK Modern Slavery Act 2015 s.54; no federal US equivalent for a financial services firm (the California supply-chain disclosure applies to retailers and manufacturers)."),
    _j("Code list: Publication Type", "Gender Pay Gap Report", "Other EU/UK", "UK gender pay gap regulations 2017; no US publication duty."),
    _j("Code list: Publication Type", "MIFIDPRU 8 Disclosure", "FCA", "FCA public disclosure; the US capital publication is the broker-dealer statement of financial condition (SEC Rule 17a-5(c)), added to the list."),
    _j("Code list: Publication Type", "Tax Strategy", "Other EU/UK", "UK Finance Act 2016 Schedule 19."),
    # Sources
    _j("Sources", "EU Transparency Register: Interinstitutional Agreement of 20 May 2021 on a mandatory transparency register", "Other EU/UK", "Lobbying re-sourced to the LDA and state lobbying statutes."),
    _j("Sources", "Transparency of Lobbying, Non-Party Campaigning and Trade Union Administration Act 2014, Part 1", "Other EU/UK", "Removed with the UK regime and registrant values."),
    _j("Sources", "Modern Slavery Act 2015 section 54 (transparency in supply chains)", "Other EU/UK", "Removed with the publication type; publication attributes re-sourced to Internal and SEC Rule 17a-5(c)."),
    _j("Sources", "Equality Act 2010 (Gender Pay Gap Information) Regulations 2017", "Other EU/UK", "Removed with the publication type and Government Portal Submission Date."),
    _j("Sources", "FCA Handbook MIFIDPRU 8 (disclosure requirements)", "FCA", "Source Capital Requirement Calculation re-sourced to SEC Rules 17a-5(c) and 15c3-1."),
    _j("Sources", "Finance Act 2016 Schedule 19 (publication of tax strategies)", "Other EU/UK", "Removed with the publication type."),
    _j("Sources", "CIPR Code of Conduct", "UK market practice", "UK professional code for public relations; the PRSA Code of Ethics stays."),
]

DECISIONS = [
    {"id": "CW-942", "theme": "Scope", "title": "US-only pass of 42 Corporate Communications & Public Affairs",
     "domains": ["42", "34", "43"],
     "issue": "The wholesale 42 carried the EU Transparency Register (a cost band attribute and list, a regime, a registrant category and a report type), the UK consultant lobbyist register, UK statutory publications (modern slavery statement, gender pay gap report and its government portal submission, MIFIDPRU 8 disclosure, tax strategy), the SFDR entity PAI link to 34, the UK CIPR code and their sources. Its text described an asset manager distributing wholesale in the US and the EU/UK, with personal data framed by GDPR.",
     "resolution": "1) Removed (33 JURISDICTION entries: Other EU/UK 29, FCA 2, SFDR 1, UK market practice 1): attributes Lobbying Disclosure Report.EU TR Cost Band, Corporate Publication.Government Portal Submission Date, Publication Source Link.Source PAI Calculation; local list EU TR Cost Band (14 values); values Lobbying Regime (EU Transparency Register, UK Register of Consultant Lobbyists), Registrant Category (EU TR Category II, UK Client of Consultant Lobbyist), Lobbying Report Type EU TR Annual Update, Publication Type (Modern Slavery Statement, Gender Pay Gap Report, MIFIDPRU 8 Disclosure, Tax Strategy); sources EU Transparency Register IIA, UK Transparency of Lobbying Act 2014, Modern Slavery Act 2015, UK gender pay gap regulations, FCA MIFIDPRU 8, Finance Act 2016 Schedule 19, CIPR Code of Conduct. "
                   "2) Re-sourced: lobbying to the Lobbying Disclosure Act (LD-1, LD-2, LD-203) and state lobbying registers (Lobbying Registration ID, Lobbying Regime, Registrant Category, Lobbying Report Type and Registration Jurisdiction texts and secondary references; source 'State lobbying statutes' added); Publication Type re-cut to Statement of Financial Condition (SEC Rule 17a-5(c)), Corporate Responsibility Report, Annual Review, Other; Corporate Publication Type, Publication Signatory, Publication Board Approval Date and Publication Property to Internal and SEC Rule 17a-5(c); Source Capital Requirement Calculation to the 43 net capital calculation in the statement's net capital note (SEC Rules 17a-5(c) and 15c3-1; source added); Source Human Capital Metric Value to headcount and workforce composition (GRI 2); Consultation Reference examples to US bodies; Inquiry Response Type list source to PRSA practice. Regulation FD was not in the module and is not added (it binds issuers with registered securities and closed-end funds; the firm is neither by default; tailoring lever). "
                   "3) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose, Scope, Core model, Design principles, Notes and Suggested next steps; Corporate Publications and Lobbying Disclosure family texts; examples (publication IDs, publication type, RCAP-0003-NC key, headcount metric); brand licensee and co-branding texts (intermediary firms and plan sponsor partners, not distributors); enrich_42 SUMMARY and docstring. "
                   "4) Re-points (REPOINTS list, 8 entries; after review the publication examples tell one story: SFC/0003/2025/1, no board approval date, RCAP-0003-NC-20251231-01): 02 named Client & Household, the party core for every external party (CW-023); 01 named Investment Product & Service Offering in SUMMARY; Reference (Party) unchanged (CW-021); the 34 source link and its relationship text removed. "
                   "5) Additions: none (the brief names none for 42). Attribute IDs renumber in the Corporate Publications and Lobbying Disclosure families. Counts: 27 objects (unchanged), 230 to 227 attributes, 69 CDEs (30.0% to 30.4%), 67 to 66 references, 36 to 35 code lists, 38 relationships, 17 to 12 sources.",
     "rationale": "CW-003 and CW-022: the wealth model lobbies and publishes in the US only. The EU and UK registers and the UK publication duties do not apply; the LDA and state lobbying regimes already modeled stay, and the broker-dealer statement of financial condition is the US statutory corporate publication that cites 43 capital figures, so the publication and source-link objects stay with a US instance. Names are kept so that DP-238 and SM-17 keep resolving; the readers of the three removed attributes and of the removed values are listed in NOTES.",
     "action": "W1b", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

SHARED_RECUTS = []

REPOINTS = [
    ("Brand Use Authorization", "Licensee Party", "'(distributor, sponsor partner, event organizer)'", "'(intermediary firm, plan sponsor partner, event organizer)'", "CW-942"),
    ("Code list: Brand Use Scope", "Co-Branding", "'Joint materials with a distributor or partner'", "'Joint materials with an intermediary firm or partner'", "CW-942"),
    ("Consultation Response", "Consultation Reference", "'an SEC file number, an FCA CP number, an ESMA reference'", "'an SEC file number, a FINRA Regulatory Notice number, a Federal Register docket number'", "CW-942"),
    ("Corporate Publication", "Corporate Publication Type", "example 'Modern Slavery Statement'", "example 'Statement of Financial Condition'", "CW-942"),
    ("Publication Source Link", "Source Human Capital Metric Value", "'(gender pay gap, headcount)'", "'(headcount, workforce composition)'", "CW-942"),
    ("Publication Source Link", "Source Capital Requirement Calculation", "'published in the MIFIDPRU 8 disclosure'", "'published in the net capital note of the broker-dealer statement of financial condition'", "CW-942"),
    ("Publication Source Link", "Other Source Record Key", "'(e.g. 19 figures in a tax strategy)'", "'(e.g. 19 balance sheet figures in the statement of financial condition)'", "CW-942"),
    ("META overview and enrich_42 SUMMARY", "", "'02 Client & Customer'; '01 Investment Product'", "'02 Client & Household, the party core for every external party'; '01 Investment Product & Service Offering'", "CW-942, CW-023"),
]
SHARED_CANDIDATES = []

NOTES = [
    "W1b (wealth), CW-942. Validation: taxonomy_builder.py content_42_corporate_communications_and_public_affairs OK (8 families, 27 objects, 227 attributes, 69 CDEs, 66 references, 2 derived, 0 unresolved, 35 code lists); check_enrichment.py 42 OK. Before: 8 families, 27 objects, 230 attributes, 69 CDEs, 67 references, 2 derived, 36 code lists.",
    "READERS of removed attributes and values (not edited; line numbers at 2026-10-14): data_products/specs_e4_technology_communications.py DP-238 lines 994, 998, 1005 (description and questions name the modern slavery statement, gender pay gap report, MIFIDPRU 8 disclosure and EU Transparency Register reports), 1023-1027 (Late Publications reads Government Portal Submission Date; Publications Without Board Approval names Modern Slavery Statements and Tax Strategy), 1035-1037 (Untraced Publication Figures reads Source PAI Calculation and names Gender Pay Gap Reports and MIFIDPRU 8 Disclosures), 1043, 1051-1053 (Reported Lobbying Expense reads EU TR Cost Band), 1089-1090, 1110 (input lists), 1128, 1134, 1149 (timeliness, DQ rule and supporting functions FN-41 gender pay gap and FN-40 MIFIDPRU 8); "
    "data_models/keys_e7_42_44.py lines 57 (Publication Source Link key includes Source PAI Calculation) and 270 (link to 34 PAI Calculation); data_models/models_e8c_technology_communications.py lines 717, 804 (DP-238 entities); semantic_model/models/sm_17_technology_data_communications.py lines 939, 952, 1000, 2174, 2178, 2183 (SM-17 measures and dimensions on the publication types, EU TR cost band and the portal date); data_products/specs_e4_finance_tax_treasury.py DP-205 line 1130 (text: '42 publishes the MIFIDPRU 8 disclosure by reference'). DP-201 (gender pay gap metrics, lines 589-671) and SM-15 (lines 1349-1352) read 20, not 42, and are for the 20 editor.",
    "References to domains replaced or retired later, left as they are: Press Release.Coordinated Shareholder Communication (Reference (Shareholder Communication), 13 adapted at W2) and its relationship; Release Compliance Review and Related Hospitality Item (08 replaced at W2); Corporate Award Entry result in 11 (adapted at W4); Statement Delivery Methods note naming 12 and 13; SUMMARY names 08 Distribution Compliance and 13 Investor Servicing & Shareholder Communications.",
    "READERS (added after review): semantic_model/models/sm_17_technology_data_communications.py lines 2187 and 2195 (EU TR reports in a measure expression and note); data_products/specs_e4_technology_communications.py line 1160 (DP-238 open SME question on 'LDA and EU TR').",
    "Left for W4: Press Release.Fund in Offering Indicator (line 121) names 'its 30 Private Fund Profile' in its note; 30 retires at W4, while the Regulation D basis may survive for feeder funds (CW-037).",
    "Other domains' content seen (not edited): 43 Capital Requirement Calculation relationship 'is published in Corporate Publication [42]' says 'MIFIDPRU 8 disclosure' (fixed in 43 under CW-943); 34 PAI Calculation (SFDR) for the 34 editor (CW-934); 20 holds gender pay gap metrics (CW-920).",
    "Remaining hits of the step 1 grep, justified: 'Fund Shareholders' and 'Investors in the Firm' in Stakeholder Group (fund shareholders and the firm's own owners are stakeholders); 'institutional communication' (FINRA Rule 2210 term); 'Affiliate / Boutique Brand' (generic brand level).",
    "Unverified (marked confirm in Source_Notes): website availability of the 17a-5(c) statement; the New York lobbying page URL as the state example; the eCFR section URL of 17 CFR 240.17a-5.",
]
