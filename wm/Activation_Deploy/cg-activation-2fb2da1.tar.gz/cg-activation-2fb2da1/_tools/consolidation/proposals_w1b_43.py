"""W1b proposals of Data Domain 43 Corporate Treasury & Capital (wealth model; kept with the US-only and perspective pass
and the broker-dealer net capital additions). Brief: 00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (row 43);
decisions CW-003, CW-021, CW-022, CW-023; plan section 5.1 row 43. Declarative only: the program lead merges DECISIONS
into decisions.py and appends JURISDICTION to jurisdiction.REMOVALS. The existing proposals_43.py (expansion) is unchanged.
"""

_D = "CW-943"


def _j(obj, attr, regime, note):
    return {"domain": "43", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


_KF = ["K-AUM", "K-CMH", "K-ASA", "K-COH", "K-NPR", "K-CMG", "K-TCD", "K-DTF", "K-CON"]

JURISDICTION = [
    # Object
    _j("ICARA Assessment", "", "ICARA",
       "UK internal capital adequacy and risk assessment (MIFIDPRU 7, FG20/1) with its threshold requirements, wind-down cost and MIF007 return. No US equivalent for the broker-dealer, adviser or funds; capital adequacy is evidenced by the Rule 15c3-1 calculations and Rule 17a-11 notices kept in 43."),
    # Attributes
    _j("Regulated Entity Capital Profile", "MIFIDPRU Firm Category", "FCA", "SNI / non-SNI classification of a UK investment firm."),
    _j("Capital Requirement Calculation", "Liquid Assets Requirement Amount", "FCA", "MIFIDPRU 6 basic liquid assets requirement; the broker-dealer's liquidity is reflected in net capital haircuts and non-allowable assets."),
    _j("Capital Requirement Calculation", "Liquid Assets Held Amount", "FCA", "As above."),
    _j("Capital Requirement Component", "K-Factor", "FCA", "MIFIDPRU 4 K-factor; components are haircuts, non-allowable assets, aggregate indebtedness and aggregate debit items requirements, and the trust company's tier items."),
    # Whole local lists
    *[_j("Code list: MIFIDPRU Firm Category", v, "FCA", "Whole list removed with the attribute.") for v in ("SNI", "Non-SNI")],
    *[_j("Code list: K-Factor", v, "FCA", "Whole list removed with the attribute.") for v in _KF],
    # Capital Regime
    _j("Code list: Capital Regime", "FCA MIFIDPRU", "FCA", "Code MP; no UK investment firm."),
    _j("Code list: Capital Regime", "FCA IPRU-INV 11", "FCA", "Code IP; no UK collective portfolio management firm."),
    _j("Code list: Capital Regime", "UCITS Management Company Own Funds", "UCITS", "Code UC; no UCITS management company."),
    _j("Code list: Capital Regime", "AIFM Own Funds", "AIFMD", "Code AI; no EU AIFM."),
    _j("Code list: Capital Regime", "Central Bank of Ireland Fund Management Company", "Other EU/UK", "Code CB; no Irish management company. State Trust Company Capital (code ST) added for a state-chartered trust company."),
    # Capital Component Type
    _j("Code list: Capital Component Type", "Fixed Overheads Requirement", "FCA", "MIFIDPRU / UCITS fixed overheads requirement."),
    _j("Code list: Capital Component Type", "K-Factor Requirement", "FCA", "MIFIDPRU 4."),
    _j("Code list: Capital Component Type", "Own Funds Deduction", "Other EU/UK", "EU/UK own funds term; the trust company's deductions are Regulatory Capital Deduction (12 CFR 3.22) and the broker-dealer's are haircuts and non-allowable assets."),
    _j("Code list: Capital Component Type", "AUM-Based Additional Own Funds", "UCITS", "0.02% of AUM above EUR 250 million under UCITS Article 7 and AIFMD Article 9."),
    _j("Code list: Capital Component Type", "Professional Liability Additional Own Funds", "AIFMD", "AIFMD Article 9(7)."),
    # Capital Notification Trigger
    _j("Code list: Capital Notification Trigger", "MIFIDPRU Own Funds Early Warning", "FCA", "MIFIDPRU 7; the US early warning is Rule 17a-11(b), kept."),
    _j("Code list: Capital Notification Trigger", "MIFIDPRU Liquid Assets Early Warning", "FCA", "MIFIDPRU 7."),
    _j("Code list: Capital Notification Trigger", "MIFIDPRU Own Funds Reduction", "FCA", "FCA prior permission; the US withdrawal notice is Rule 15c3-1(e) and FINRA Rule 4110(c)(2), kept."),
    _j("Code list: Capital Notification Trigger", "CSSF Own Funds Notification", "Other EU/UK", "Luxembourg ManCo and AIFM."),
    _j("Code list: Capital Notification Trigger", "Central Bank of Ireland Capital Notification", "Other EU/UK", "Irish management company."),
    # Hedge Accounting Framework (IFRS is not the firm's own basis)
    _j("Code list: Hedge Accounting Framework", "IFRS 9", "Other EU/UK", "The firm and its entities report under US GAAP; hedge accounting is ASC 815 only (plan section 6; same regime as the IFRS removal of CW-919)."),
    _j("Code list: Hedge Accounting Framework", "IAS 39 (Policy Choice Retained)", "Other EU/UK", "As above."),
    # Sources
    _j("Sources", "FCA Handbook MIFIDPRU (prudential sourcebook for MiFID investment firms), including MIFIDPRU 3-8", "FCA", "Capital re-sourced to SEC Rules 15c3-1 and 17a-11, FINRA Rule 4110 and OCC capital rules."),
    _j("Sources", "FCA FG20/1 Assessing adequate financial resources", "ICARA", "Removed with ICARA Assessment."),
    _j("Sources", "Directive 2011/61/EU (AIFMD), Article 9, and Directive 2009/65/EC (UCITS), Article 7", "AIFMD", "Removed with the UCITS and AIFM own funds values (also UCITS)."),
    _j("Sources", "CSSF Circular 18/698 on the authorization and organization of Luxembourg investment fund managers", "Other EU/UK", "Removed with the Luxembourg regime and trigger values."),
    _j("Sources", "Central Bank of Ireland Fund Management Companies Guidance (December 2016, CP86 framework), minimum capital requirement", "Other EU/UK", "Removed with the Irish regime and trigger values."),
    _j("Sources", "IFRS 9 Financial Instruments (hedge accounting); IFRS 10 Consolidated Financial Statements; IFRS 13 Fair Value Measurement", "Other EU/UK",
       "Not the firm's basis; the 19 attributes that cited IFRS 9, 10 or 13 now cite ASC 815, 810 or 820 only."),
    _j("Sources", "Regulation (EU) No 648/2012 (EMIR) and UK EMIR; ISO 23897 Unique Transaction Identifier", "EMIR",
       "Source retitled to CFTC swap data reporting (17 CFR Part 45) and ISO 23897."),
    _j("Sources", "LMA / LSTA recommended form facility agreements (structure only)", "UK market practice",
       "Loan Market Association forms; the source is retitled to the LSTA and the 21 attributes citing LMA cite LSTA."),
    _j("Sources", "Association of Corporate Treasurers (ACT): treasury policy and counterparty risk guidance", "UK market practice",
       "UK treasury practice body; the six attributes and three list sources citing ACT cite AFP."),
]

DECISIONS = [
    {"id": "CW-943", "theme": "Scope", "title": "US-only pass of 43 Corporate Treasury & Capital",
     "domains": ["43", "19", "39", "42", "49"],
     "issue": "The wholesale 43 carried UK and EU regulatory capital (the ICARA Assessment object, the MIFIDPRU firm category, liquid assets requirement and K-factor fields with their lists, the MIFIDPRU, IPRU-INV, UCITS, AIFM and Irish capital regimes, own funds components and notification triggers, the FCA, CSSF and Central Bank of Ireland sources), IFRS hedge accounting and consolidation references although the firm reports under US GAAP, EMIR, UK market practice references (LMA, ACT) and GBP and EUR examples on corporate accounts. Its text described an asset manager running private markets and insurance-dedicated funds in the US and the EU/UK. It held broker-dealer net capital only at the total level, without the computation fields a self-clearing broker-dealer needs or a link to the customer reserve computation.",
     "resolution": "1) Removed (42 JURISDICTION entries: FCA 23, Other EU/UK 9 (of which IFRS 3, regime aligned with CW-919), AIFMD 3, ICARA 2, UCITS 2, UK market practice 2, EMIR 1); after review, also removed (not EU/UK, so not in JURISDICTION): Regulated Entity Capital Profile.Early Warning Threshold Amount, a static duplicate of the calculated early-warning level, which an alternative-standard broker-dealer cannot hold as a constant: object ICARA Assessment; attributes Regulated Entity Capital Profile.MIFIDPRU Firm Category, Capital Requirement Calculation.Liquid Assets Requirement Amount and Liquid Assets Held Amount, Capital Requirement Component.K-Factor; local lists MIFIDPRU Firm Category and K-Factor; values of Capital Regime (5), Capital Component Type (5), Capital Notification Trigger (5) and Hedge Accounting Framework (IFRS 9, IAS 39); sources FCA MIFIDPRU, FG20/1, AIFMD Article 9 and UCITS Article 7, CSSF 18/698, Central Bank of Ireland guidance, IFRS 9/10/13, EMIR, LMA, ACT. GRAIN of ICARA Assessment and its OWNERSHIP_OVERRIDES entry removed from enrich_43; REL 'ICARA Assessment is submitted on Regulatory Financial Return' removed. "
                   "2) Re-sourced: capital to SEC Rule 15c3-1, Rule 17a-11 and FINRA Rule 4110 for the broker-dealer and OCC 12 CFR Part 3 / 12 CFR 5.46 or state law for the optional trust company (Capital Regime, Permanent Minimum Capital Amount, Early Warning Threshold Amount, Calculation Entity, Treasury Capital Requirement Amount, Treasury Capital Resources Amount, Capital Surplus Amount, Capital Coverage Ratio and the six Capital Requirement Component attributes); Capital Regime re-cut to SEC Rule 15c3-1 Net Capital, OCC National Trust Bank Capital, State Trust Company Capital, Other; Rule 17a-11 cited by paragraph: deficiency (a)(1), early warning (b); Capital Component Type re-cut (Aggregate Indebtedness Requirement, Alternative Standard Requirement, Ownership Equity, Allowable Subordinated Liabilities and Regulatory Capital Deduction added; tier 1 and tier 2 items kept for the trust company); Capital Notification Trigger re-cut (Trust Company Capital Notification added); Regulatory Prior Notice Required Indicator to the trust company regulator; hedge accounting and seed consolidation to US GAAP (ASC 815, 810, 820; IFRS references removed from 19 attributes and five list sources; Highly Effective Indicator text); LMA to LSTA (21 attributes, two list sources, the source row); ACT to AFP (six attributes, three list sources); EMIR to CFTC Part 45; USD, SOFR and IRC 482 examples on accounts, statements, positions, forecasts, the drawdown fixing and the intercompany loan; Signatory Party text (no Luxembourg or Irish management company); CASS wording on the Bank family and Bank Account Purpose re-pointed to client cash in 49 and 50. Sources added: SEC Rule 15c3-3 (referenced) and OCC capital rules. "
                   "3) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose, Scope, Core model, Applies To, Primary / Secondary Reference, Notes and Suggested next steps; Regulatory Capital & Liquidity family text; object group 'ICARA & Notifications' renamed 'Capital Notifications'; 02 named Client & Household; 42 publication relationship to the statement of financial condition; enrich_43 SUMMARY, docstring and the Capital Requirement Calculation grain text. The certified treasury and seed definitions are untouched. "
                   "4) Re-points (REPOINTS list): Reference (Party) and Reference (Account) unchanged (CW-021); references to 30 (GP commitments, capital calls, distributions, fund credit facilities) and the SMA and insurance-dedicated seed wording left for W4. "
                   "5) Added (plan section 5.1): Capital Requirement Calculation.Aggregate Indebtedness Amount (CDE), Aggregate Indebtedness Ratio, Aggregate Debit Items Amount (Derived copy (49); DERIVED entry in enrich_43), Net Capital Early Warning Level Amount (CDE; the higher of 120% of the minimum and 5% of aggregate debit items, with the aggregate-indebtedness test under the basic method; the only record of the level) and Reserve Computation (Reference (Customer Reserve Computation, 49), anchor RSV-, CDE); relationship Capital Requirement Calculation reads Customer Reserve Computation [49]. Net capital is Treasury Capital Resources Amount and excess net capital is Capital Surplus Amount (noted); 43 does not compute the reserve. Attribute IDs renumber in the Regulatory Capital & Liquidity family. Aggregate debit items are held once (Component Input Measure is blank on the alternative standard row). Counts: 33 to 32 objects, 279 to 273 attributes, 92 CDEs (33.0% to 33.7%), 64 to 63 references, 7 to 8 derived, 39 to 37 code lists, 49 relationships, 20 to 15 sources.",
     "rationale": "CW-003 and CW-022: the firm's licensed entities are a US broker-dealer, a US adviser, US funds and an optional US trust company, so UK and EU capital regimes, the ICARA and IFRS (not the firm's basis) leave; currencies and foreign exposures stay. Plan section 5.1 row 43 asks for the broker-dealer net capital computation and the customer reserve interplay with 49 (the alternative standard reads the reserve formula's aggregate debit items). Names are kept so that DP-205, SM-14 and the 19 return derived copies keep resolving; the readers of the removed object and attributes are listed in NOTES, including the 39 Corporate Resolution Subject Link that references ICARA Assessment.",
     "action": "W1b", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
]

SHARED_RECUTS = []

REPOINTS = [
    ("Bank Accounts & Relationships (family text)", "", "'Fund custody accounts and CASS client money accounts (28 Safekeeping Account)'", "'Fund custody accounts (28 Safekeeping Account), client accounts (15) and client cash (49, 50)'", "CW-943"),
    ("Code list: Bank Account Purpose", "(list source)", "'CASS client money and fund cash accounts are 28 Safekeeping Accounts'", "'Client cash (49, 50) and fund cash accounts (28 Safekeeping Accounts)'", "CW-943"),
    ("Capital Requirement Calculation", "Calculation Entity", "'for a consolidated MIFIDPRU calculation, the parent of the investment firm group'", "'(the broker-dealer, or the trust company)'", "CW-943"),
    ("Bank Account Signatory", "Signatory Party", "'outsourced conducting officer of a Luxembourg or Irish management company'", "'independent director of a fund board or of the trust company'", "CW-943"),
    ("Capital Requirement Calculation (relationship to Corporate Publication [42])", "", "'MIFIDPRU 8 disclosure'", "'net capital note of the broker-dealer statement of financial condition (SEC Rule 17a-5(c))'", "CW-943"),
    ("META overview and enrich_43 SUMMARY", "", "'02 Client & Customer'", "'02 Client & Household'", "CW-943, CW-023"),
]
SHARED_CANDIDATES = []

NOTES = [
    "W1b (wealth), CW-943. Validation: taxonomy_builder.py content_43_corporate_treasury_and_capital OK (7 families, 32 objects, 273 attributes, 92 CDEs, 63 references, 8 derived, 0 unresolved, 37 code lists; after the review fix pass); check_enrichment.py 43 OK. Before: 7 families, 33 objects, 279 attributes, 92 CDEs, 64 references, 7 derived, 39 code lists.",
    "READERS of the removed object and attributes (not edited; line numbers at 2026-10-14): content_39_legal_and_corporate_governance.py line 308 'Subject ICARA Assessment' (Reference (ICARA Assessment, 43)) with enrich_39.py lines 64-65 and 86 and the 39 Corporate Resolution Subject Type list (line 422) and relationship (line 461): the 39 editor removes them under CW-939, otherwise the reference points at a removed object (it still 'resolves' by domain number, so the builder will not flag it); data_models/keys_e7_39_41.py line 310 (link to 43 ICARA Assessment); "
    "data_products/specs_e4_finance_tax_treasury.py DP-205 lines 993, 1000-1008, 1024-1032, 1066-1067, 1077, 1083-1088, 1113, 1129 (ICARA, MIFIDPRU firm category, liquid assets, K-factor metrics and inputs) and value or text readers at lines 992, 1112, 1119, 1130; data_products/framework.py lines 266 (catalog text 'capital, ICARA') and 1087 (DP-205 entry); data_products/specs_e4_compliance_legal.py DP-230 line 1176 and data_models/models_e8c_compliance_legal.py line 909 (Subject ICARA Assessment); "
    "data_models/keys_e7_42_44.py lines 151 and 391-392 (keys and links of ICARA Assessment); data_models/models_e8c_finance_tax_treasury.py lines 876-878, 922-924, 949 (DP-205 entities); semantic_model/models/sm_14_corporate_finance_treasury_tax.py lines 520, 536-537, 543-549, 578, 1633-1645, 1681-1685 (SM-14 measures and dimensions on ICARA, liquid assets, K-factor and MIFIDPRU values); capability_map/content_capabilities.py line 1040 (C-13.14 note naming ICARA; lines 1578-1581 already record its removal at W0). Value readers elsewhere: DP-199 lines 295 and 332 and SM-15 line 1197 name MIFIDPRU remuneration (20's, not 43's); DP-220 line 866 and DP-238 lines 994, 1035, 1134, 1149 and SM-17 line 2183 name MIFIDPRU disclosure (42's).",
    "READERS (added after review): consolidation/gaps_register.py GAP-43-001 (lines 4344-4351; fixed overheads deductions 'under IFPR / MIFIDPRU'); semantic_model/models/sm_14_corporate_finance_treasury_tax.py lines 948-949 (icara_assessment join) and 1650-1659; data_products/specs_e4_finance_tax_treasury.py lines 1034, 1041, 1137; data_models/models_e8c_finance_tax_treasury.py lines 893, 953. Readers of the removed Early Warning Threshold Amount: data_products/specs_e4_finance_tax_treasury.py DP-205 lines 1020-1021, 1057, 1078; semantic_model/models/sm_14_corporate_finance_treasury_tax.py lines 580 and 1628 (re-point to Capital Requirement Calculation.Net Capital Early Warning Level Amount).",
    "For the lead: rule in CW-943 whether certified seed text yields to the brief section 5 re-wording at W4 (Seeded Product, Seed Holding Account and the Seed Commitment Type value Incubation Account still say 'SMA'). Fix the object name 'Customer Reserve Computation' (RSV-) in the 49 brief: the builder resolves the reference by domain number only, so the name is never checked.",
    "New readers expected: 49 Customer Reserve Computation (RSV-) must exist with that name and publish its aggregate debit items for Reserve Computation and Aggregate Debit Items Amount; 19 Regulatory Financial Return can add the FOCUS Report return type and copy the new net capital fields; 38 Entity Authorization holds the trust company charter that sets the capital regime.",
    "References to domains retired or replaced later, left as they are (W4): Seed Capital Commitment.GP Investor Commitment (30), Seed Capital Movement.Resulting Capital Call and Resulting Private Fund Distribution (30), Seed Position Valuation.Seed Capital Balance (30) and Source Shareholder Position (06), the Seed Commitment Type values GP Commitment, Co-Investment and Incubation Account (SMA line), 'insurance-dedicated fund rows' on Seed Units Held, 'SMA strategy vehicle or private fund' on Seeded Product, the Seed family text, Cash Flow Category values Performance Fee and Carry Receipts and GP Commitment Funding, the Scope and Core model mentions of 30 (investor commitments, capital calls, fund credit facilities) and the REL rows to 30; Loan Intercompany Agreement (10, W4). These are certified seed definitions and were not edited.",
    "Other domains' content seen (not edited): 39 holds Subject ICARA Assessment and cites 'FCA MIFIDPRU 7 (ICARA)' in a source (CW-939); 42 published the MIFIDPRU 8 disclosure (fixed under CW-942); 19 Regulatory Financial Return may hold MIF001/MIF002/MIF007 return types (CW-919).",
    "Remaining hits of the step 1 grep, justified: 'IBAN' and 'ISO 13616' on Account IBAN (any account held abroad; a payment format, kept); EUR on Corporate Exposure, Treasury Deal and Hedged Exposure examples (foreign currency exposures stay, CW-022); SONIA, ESTR and EURIBOR in the benchmark administrators source (reference rates stay); 'Net Investment in Foreign Subsidiary' and Hedged Net Investment Entity (a lever: a US-only firm normally has none); the docstring of enrich_43 states the removals.",
    "Unverified (marked confirm in Source_Notes): the 15c3-1 dollar minimums and early-warning percentages; 12 CFR 5.46 and 12 CFR Part 3 as the OCC capital rules for a non-depository national trust bank; the eCFR section URL of 17 CFR 240.15c3-3; the RSV- key format.",
]
