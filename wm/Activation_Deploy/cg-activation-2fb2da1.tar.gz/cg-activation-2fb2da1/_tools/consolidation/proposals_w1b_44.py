"""W1b proposals of Data Domain 44 Workplace & Corporate Services (wealth model; kept with the US-only and perspective
pass). Brief: 00_Program/Rework/Briefs/W1b_Carry_Over_Pass.md section 4 (row 44); decisions CW-003, CW-022, CW-023.
Declarative only: the program lead merges DECISIONS into decisions.py and appends JURISDICTION to jurisdiction.REMOVALS.
The existing proposals_44.py (expansion) is unchanged.
"""

_D = "CW-944"


def _j(obj, attr, regime, note):
    return {"domain": "44", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}


JURISDICTION = [
    _j("Health & Safety Incident", "RIDDOR Reportable Indicator", "Other EU/UK",
       "RIDDOR 2013 (UK HSE); the US instance is OSHA Recordable Indicator (29 CFR 1904.7) and the OSHA severe injury report date (1904.39), both kept."),
    _j("Code list: Emission Factor Source", "UK Government GHG Conversion Factors", "Other EU/UK", "DESNZ / DEFRA factors for UK reporting; US EPA eGRID and the GHG Emission Factors Hub stay."),
    _j("Code list: Emission Factor Source", "AIB European Residual Mix", "Other EU/UK", "Market-based Scope 2 residual mix for Europe; no European sites."),
    _j("Code list: H&S Incident Type", "Dangerous Occurrence", "Other EU/UK", "RIDDOR Schedule 2 event; OSHA has no equivalent class (Near Miss stays)."),
    _j("Code list: Risk Assessment Type", "DSE Workstation Assessment", "Other EU/UK", "UK DSE Regulations 1992; replaced by Ergonomic Workstation Assessment (firm practice; no US regulation)."),
    _j("Code list: Risk Assessment Type", "New or Expectant Mother Assessment", "Other EU/UK", "UK Management of Health and Safety at Work Regulations; replaced by Workplace Accommodation Assessment (ADA, Pregnant Workers Fairness Act)."),
    *[_j("Code list: Building Certification", v, "UK market practice", "BRE BREEAM (UK scheme; BREEAM USA exists but is not used by the firm's US portfolio); LEED, WELL and ENERGY STAR stay.")
      for v in ("BREEAM Pass", "BREEAM Good", "BREEAM Very Good", "BREEAM Excellent", "BREEAM Outstanding")],
    _j("Code list: Escalation Basis", "Upward-Only Review", "UK market practice", "UK lease rent review convention."),
    _j("Code list: Lease Classification", "Single Lessee Model", "Other EU/UK", "IFRS 16; the firm reports under US GAAP (ASC 842) (plan section 6; same regime as the IFRS removal of CW-919)."),
    _j("Code list: Lease Classification", "Sublease - Finance", "Other EU/UK", "IFRS 16 intermediate lessor classification."),
    _j("Code list: Lease Recognition Exemption", "Low-Value Asset", "Other EU/UK", "IFRS 16 only; the ASC 842 short-term election stays."),
    _j("Sources", "IFRS 16 Leases", "Other EU/UK", "Not the firm's basis; the lease attributes cite ASC 842 only."),
    _j("Sources", "Reporting of Injuries, Diseases and Dangerous Occurrences Regulations 2013 (RIDDOR) and HSE guidance", "Other EU/UK", "Health and safety re-sourced to OSHA 29 CFR Part 1904."),
    _j("Sources", "Health and Safety (Display Screen Equipment) Regulations 1992 and HSE guidance", "Other EU/UK", "Workstation assessments re-sourced to firm practice and the ADA."),
    _j("Sources", "Regulatory Reform (Fire Safety) Order 2005", "Other EU/UK", "Fire risk assessment and fire wardens re-sourced to OSHA 29 CFR 1910.38 and 1910.39."),
    _j("Sources", "CSRD as amended by the Omnibus I Directive (published February 26, 2026; in force March 18, 2026; scope above 1,000 employees and EUR 450m turnover)", "Other EU/UK", "Own-operations emissions reporting stays under the GHG Protocol and California SB 253."),
    _j("Sources", "UK Streamlined Energy and Carbon Reporting (SECR) - Environmental Reporting Guidelines", "Other EU/UK", "Removed with the UK factor value and the SECR references on utility and emission attributes."),
    _j("Sources", "HMRC Employment Income Manual (expenses) (part of 'IRS accountable plan rules, Treas. Reg. 1.62-2, and HMRC Employment Income Manual')", "Other EU/UK", "Expense substantiation re-sourced to IRS Treas. Reg. 1.62-2 alone; the source row is retitled."),
    _j("Sources", "BRE BREEAM certification scheme (part of 'USGBC LEED and BRE BREEAM certification schemes')", "UK market practice", "Source retitled to LEED and ENERGY STAR."),
]

DECISIONS = [
    {"id": "CW-944", "theme": "Scope", "title": "US-only pass of 44 Workplace & Corporate Services",
     "domains": ["44", "19", "34"],
     "issue": "The wholesale 44 carried UK health and safety law (the RIDDOR Reportable Indicator, the Dangerous Occurrence incident type, DSE and new or expectant mother assessments, Fire Safety Order references), EU and UK sustainability reporting (CSRD, UK SECR, the UK Government conversion factors and the AIB European residual mix), IFRS 16 lease references although the firm reports under ASC 842, BREEAM and the UK upward-only rent review, the HMRC expense manual, GDPR special-category wording and UK site examples. Its text described an asset manager occupying offices in the US and the EU/UK.",
     "resolution": "1) Removed (23 JURISDICTION entries: Other EU/UK 16 (of which IFRS 16 4, regime aligned with CW-919), UK market practice 7): attribute Health & Safety Incident.RIDDOR Reportable Indicator; values Emission Factor Source (UK Government GHG Conversion Factors, AIB European Residual Mix), H&S Incident Type Dangerous Occurrence, Risk Assessment Type (DSE Workstation Assessment, New or Expectant Mother Assessment), Building Certification (five BREEAM levels), Escalation Basis Upward-Only Review, Lease Classification (Single Lessee Model, Sublease - Finance), Lease Recognition Exemption Low-Value Asset; sources IFRS 16, RIDDOR, UK DSE Regulations, Fire Safety Order 2005, CSRD with Omnibus I, UK SECR, HMRC EIM, BREEAM. "
                   "2) Re-sourced: health and safety to OSHA 29 CFR Part 1904 (H&S Incident Type, Occurred Timestamp, Affected Non-Employee Name, Regulatory Report Date, Days Away From Work, the H&S Incident Type list); risk assessments and emergency roles to OSHA 29 CFR 1910.38, 1910.39, 1910.151 and the ADA (Risk Assessment Type re-cut with Ergonomic Workstation Assessment and Workplace Accommodation Assessment; Assessed Workstation, Assessed Employee, Next Review Date, Emergency Role; the Statutory Requirement example); leases to ASC 842 only (IFRS 16 references removed from the lease attributes and five list sources; Measurement Ledger text; RPI dropped from Index-Linked); emission factors to the EPA GHG Emission Factors Hub and eGRID (example and references); Utility Resource, Consumption Quantity and Assurance Level lose UK SECR and CSRD; expense attributes to IRS Treas. Reg. 1.62-2 only; Meter Identifier to a US meter number; GDPR special-category wording to sensitive health data under state privacy laws with ADA medical confidentiality. Sources added: ADA Title I and the Pregnant Workers Fairness Act, OSHA 29 CFR 1910.39/1910.151/1910.157, the EPA GHG Emission Factors Hub; the IRS and LEED rows retitled. "
                   "3) Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview Purpose, Scope, Core model, Design principles, Notes and Suggested next steps; Health & Safety family text; site examples SITE-US-PHL; Attendance Count note; enrich_44 SUMMARY, docstring and the Workplace Risk Assessment grain text. "
                   "4) Re-points (REPOINTS list, 7 entries; after review Escalation Basis Open Market Review reads Fair Market Value Reset, Lone Working Assessment cites the OSHA General Duty Clause, next step 4 reads 'by entity'): 02 named Client & Household (CW-023); Reference (Party) unchanged (CW-021). "
                   "5) Additions: none (the brief names none for 44). Attribute IDs renumber in the Health & Safety family. Counts: 28 objects (unchanged), 239 to 238 attributes, 74 to 73 CDEs (30.7%), 59 references, 1 derived, 43 code lists, 56 relationships, 22 to 19 sources, 99 to 98 PII attributes.",
     "rationale": "CW-003 and CW-022: the firm occupies and employs in the US only; UK workplace law and EU/UK sustainability reporting do not apply, and IFRS is not the firm's basis. OSHA, the ADA and ASC 842 already govern the generic records, which stay. Names are kept so that DP-207, DP-208 and SM-15 keep resolving; the readers of the removed attribute and values are listed in NOTES.",
     "action": "W1b", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

SHARED_RECUTS = []

REPOINTS = [
    ("META overview (Scope) and enrich_44 SUMMARY", "", "'02 Client & Customer'; '(02)'", "'02 Client & Household, the party core for every external party'", "CW-944, CW-023"),
    ("Workplace Risk Assessment", "Assessed Employee", "'on DSE and new or expectant mother assessments'", "'on ergonomic workstation and workplace accommodation assessments'", "CW-944"),
    ("Workplace Risk Assessment", "Assessed Workstation", "'for display screen equipment assessments'", "'for ergonomic workstation assessments'", "CW-944"),
    ("Lease Accounting Measurement", "Measurement Ledger", "'so US GAAP and IFRS measurements of one lease are separate rows'", "'so measurements of one lease in different ledgers (US GAAP, tax) are separate rows'", "CW-944"),
    ("Utility Consumption Record", "Meter Identifier", "'(for example a UK MPAN or MPRN)', example 'MPAN 1200050023471'", "'(the utility's meter or service point number)', example 'Meter 98765432'", "CW-944"),
    ("Health & Safety Incident", "Regulatory Report Date", "'(HSE under RIDDOR, or OSHA for a severe injury report)'", "'reported to OSHA (or the state plan agency) as a fatality or severe injury report'", "CW-944"),
    ("Code list: Escalation Basis", "Open Market Review", "'Open Market Review' (UK rent review convention)", "'Fair Market Value Reset' (US lease term)", "CW-944"),
]
SHARED_CANDIDATES = []

NOTES = [
    "W1b (wealth), CW-944. Validation: taxonomy_builder.py content_44_workplace_and_corporate_services OK (7 families, 28 objects, 238 attributes, 73 CDEs, 59 references, 1 derived, 0 unresolved, 43 code lists); check_enrichment.py 44 OK. Before: 7 families, 28 objects, 239 attributes, 74 CDEs, 59 references, 1 derived, 43 code lists.",
    "READERS of the removed attribute and values (not edited; line numbers at 2026-10-14): data_products/specs_e4_people_workplace_ai.py DP-208 lines 847, 853, 897-903, 944, 959 (RIDDOR Reportable Indicator in metrics, inputs and DQ rules) and DP-207 lines 682 and 835 (removed values: BREEAM, IFRS 16, Dangerous Occurrence or the UK factor source); semantic_model/models/sm_15_people_workplace.py lines 570 and 1575-1584 (SM-15 dimension and measures on RIDDOR reportable incidents).",
    "References to domains replaced or retired later, left as they are: Expense Line.Recharge Fund ('private fund deal costs', 27 accrual, '30 LPA expense rules'; W4); Related Gift / Entertainment Item and the Scope mention of 08 Distribution Compliance (08 replaced at W2); Scope mention of 01 and 27 for fund recharges.",
    "Other domains' content seen (not edited): 34 holds the own-operations indicator definitions that copy 44 entity totals (CW-934); 09 has only the SITE-US-SFO site example, so SITE-US-PHL is an illustrative new key that 09 would add.",
    "Remaining hits of the step 1 grep: none in the content module; the enrich_44 docstring states the removals.",
    "Not present and not added: the brief and assignment name ADA as a regime that stays; the wholesale module did not cite it, and it is now cited as the re-source of the accommodation assessment and the health-data confidentiality note (no new attribute).",
    "Unverified (marked confirm in Source_Notes): the ada.gov landing page as the ADA source; OSHA 1910.39 and 1910.157 citations; ASHRAE Standard 188 for Legionella.",
]
