"""Consolidation proposals from Data Domain 03 - Advisor Organization, Coverage & Supervision (wealth model W2 draft v0.1,
2026-10-14; replaces the wholesale 03 Sales and absorbs the coverage and incentive objects of 07, CW-013, CW-061 to CW-065).

Proposal fragment only: the builder does not read it. The program lead merges accepted entries into decisions.py,
shared_code_lists.py and jurisdiction.py at the W2 merge. Format follows CONTRACT.md in this folder (DECISIONS dict format,
PREFIXES tuple format, the jurisdiction.py REMOVALS entry format). The brief names this file proposals_03.py and the module
content_03_advisor_organization.py; the assignment named them proposals_w2_03.py and
content_03_advisor_organization_coverage_and_supervision.py, which are used.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones: none. The module uses only the reserved RFRL-, REAS-, ASRL-, RECG-, the kept ACT- and
#    SLT- and the transferred CVA-, ICP- (components ICP-n-Cnn) and CPS- (proposals_w2_conduct.py PREFIX_CHANGES). Advisor
#    keys by EMP- (20), Firm Branch Office by SITE- (09); the other objects keep composite keys (KEY_FORMATS in
#    proposals_w2_conduct.py). Until the merge moves CVA-, ICP- and CPS- to 03, enrich_03.py OWNERSHIP_OVERRIDES forces the
#    internal references that carry those prefixes to "mastered here".
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local lists in 03 carrying the exact name and (US) values of an enterprise shared list.
#    (local list name, shared list name, instruction for the consolidation step)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    ("Business Line", "Business Line", "New member ('03', 'Business Line'); local copy of the eight CW-004 codes (the shared list already carries them). Used by Advisor Business Lines."),
    ("Frequency", "Frequency", "Keep ('03', 'Frequency'). Call Frequency Standard Standard Period, Incentive Compensation Plan Payout Frequency; all shared labels copied."),
    ("Record Status", "Record Status", "Rename ('03', 'Sales Play Status') -> ('03', 'Record Status'). Credential Status, Team Status, Branch Status, Coverage Model Status, Rule Status; all shared labels copied."),
    ("Approval Status", "Approval Status", "New member ('03', 'Approval Status'). Incentive Compensation Plan Plan Approval Status; all shared labels copied."),
    ("Information Classification", "Information Classification", "Rename ('03', 'Confidentiality Type') -> ('03', 'Information Classification'). Advisor Activity Activity Classification; all shared labels copied (the wholesale three-value Public / Internal / Confidential list is superseded)."),
    ("Sentiment", "Sentiment", "Rename ('03', 'Client Sentiment') -> ('03', 'Sentiment'). Discussion Content Client Sentiment keeps its attribute name; adds Mixed."),
    ("Personal Data Category", "Personal Data Category", "Keep ('03', 'Personal Data Category'); steward 02. Discussion Content Notes Personal Data Categories; the wholesale labels None, Contact Data, HR Data become the shared labels No Personal Data, Contact, HR / Employee."),
]

VALUE_MAPS = {   # new 03 local label -> shared code
    ("03", "Business Line"): {"DB": "DB", "DA": "DA", "HA": "HA", "PF": "PF", "WR": "WR", "IA": "IA", "IC": "IC", "TR": "TR"},
    ("03", "Record Status"): {"Draft": "DRAFT", "Proposed": "PROPOSED", "Pending": "PENDING", "Active": "ACTIVE", "Paused": "PAUSED",
                              "Inactive": "INACTIVE", "Deprecated": "DEPRECATED", "Retired": "RETIRED"},
    ("03", "Approval Status"): {"Not Required": "NOT_REQUIRED", "Pending": "PENDING", "Approved": "APPROVED",
                                "Approved with Conditions": "APPROVED_WITH_CONDITIONS", "Retrospectively Approved": "RETROSPECTIVELY_APPROVED",
                                "Rejected": "REJECTED", "Expired": "EXPIRED", "Withdrawn": "WITHDRAWN"},
    ("03", "Sentiment"): {"Positive": "POSITIVE", "Neutral": "NEUTRAL", "Negative": "NEGATIVE", "Mixed": "MIXED", "Unknown": "UNKNOWN"},
    ("03", "Personal Data Category"): {"No Personal Data": "NONE", "Identity": "IDENTITY", "Contact": "CONTACT",
                                       "Professional / Employment": "PROFESSIONAL_EMPLOYMENT", "Registration / Licensing": "REGISTRATION_LICENSING",
                                       "HR / Employee": "HR_EMPLOYEE", "Financial": "FINANCIAL", "Government Identifier": "GOVERNMENT_IDENTIFIER",
                                       "Online Identifiers / Engagement": "ONLINE_IDENTIFIERS_ENGAGEMENT",
                                       "Inferences / Segmentation": "INFERENCES_SEGMENTATION", "Opinion About Individual": "OPINION_ABOUT_INDIVIDUAL",
                                       "Free Text - May Contain Personal Data": "UNSTRUCTURED_MAY_CONTAIN"},
    # Information Classification and Frequency: the labels are the shared labels one for one.
}

# Memberships of the wholesale 03 that the replacement does not carry (brief section 8).
MEMBERSHIPS_REMOVE = [("03", "Sales Channel"), ("03", "Sales Market"), ("03", "Audience Type"), ("03", "Performance Basis"),
                      ("03", "Data Quality Status")]
MEMBERSHIPS_RENAME = [(("03", "Sales Play Status"), ("03", "Record Status")),
                      (("03", "Confidentiality Type"), ("03", "Information Classification")),
                      (("03", "Client Sentiment"), ("03", "Sentiment"))]
# Stale LOCAL_RENAMES entries of the wholesale 03: ('03', 'Snapshot Type', 'Pipeline Snapshot Point') goes with the dropped
# Pipeline Snapshot; ('03', 'Capture Method', 'Activity Capture Method') is applied in the module itself (the list is authored
# as 'Activity Capture Method'), so the entry can be removed. 07 memberships (Frequency, Distribution Channel, Information
# Classification, Approval Status, Distribution Market, Geographic Unit Type, Record Status, Inclusion Type, Outgoing Payment
# Status, Data Quality Status) stay until 07 retires at W4 (CW-080).
LOCAL_RENAMES_REMOVE = [("03", "Snapshot Type"), ("03", "Capture Method")]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: (list name in 03, proposed shared list name, likely other users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Interaction Medium", "Interaction Channel", ["13", "45", "04"], "13 Contact Center Interaction channel and 45 Advice Delivery Channel hold close values (45 proposals NOTES); one shared list, steward 13, with 03 Interaction Medium and 45 Advice Delivery Channel as members."),
    ("Attendance Status", "Attendance Status", ["04"], "04 Event Registration attendance uses the same values; steward 04."),
    ("Referral Channel", None, ["04", "16", "51"], "Internal channel names; 04 Client Referral is a different concept (CW-065). Keep local unless 16 rollover capture needs the same list."),
    ("Credential Type", "Professional Credential", ["20", "45"], "20 Learning or Employee may hold professional certifications; 45 shows the planner's designation. Steward 20 if 20 adopts it."),
    ("Rule Operator", "Rule Operator", ["01", "33", "21"], "Generic comparison operators of rule criteria (01 eligibility rules, 33 compliance rules, 21 data quality rules); steward 09."),
    ("Advisor Role", None, ["08", "20", "45"], "08 Supervisory Review routes by role and 45 records the advisor's role on an engagement; both should read 03, not copy the list."),
    ("Personal Data Category", "Personal Data Category", ["02", "13", "45", "08", "20"], "Add a value SPECIAL_CATEGORY 'Special Category (CD-344)' (health, diminished capacity, specified adult status, suspected exploitation, criminal history) to the shared list; program-lead ruling names steward 21 for the change. Until then 03 drives the restricted view of Meeting Notes from the local Special Category Content Indicator on Discussion Content."),
    ("Delivery Mode (01)", "Delivery Mode", ["01", "03", "45"], "03 no longer has its own Delivery Mode or Coverage Model list: Coverage Model.Delivery Mode cites the 01 list as 'External (01 Delivery Mode)' (same dimension; steward 01). Register 03 as a direct user when 01's list becomes shared."),
    ("Activity Type", None, ["04", "13"], "NOT a merge candidate with 13 interaction types or 04 event types (different records, CW-061); list in NOT_MERGED."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS noticed (plan section 5.3 watchlist names and CW-078), decisions.TERM_CONFLICTS format.
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Advisor (wealth model)",
     "usages": [("03", "Advisor (profile of a 20 employee, EMP-)", "The firm's own representative: advisor, planner, relationship manager, service associate, trust officer"),
                ("05", "External Advisor (per the 05 brief, W4)", "Intermediary channel advisor; a 02 party with a 05 profile"),
                ("02", "Party Role Type 'Financial Advisor'", "External advisor role on a party")],
     "recommendation": "Bare 'Advisor' is the own representative; the external one is always 'External Advisor'.",
     "resolution": "As recommended (CW-013, CW-078).", "status": "Resolved", "decision": "CW-078"},
    {"term": "Advisor of record",
     "usages": [("03", "Party Coverage Assignment, Primary Coverage Indicator = Y (CVA-)", "The one advisor-of-record master"),
                ("45", "Advice Engagement 'advisor of record' (per the 45 brief and CW-044)", "Advisor named on an engagement"),
                ("45", "Recommendation advisor (per the 45 brief)", "Advisor who made the recommendation")],
     "recommendation": "45 keeps the advisor who delivers the engagement as Engagement Advisor and reads the advisor of record from 03 as of a date (CW-063).",
     "resolution": "Resolved: the 45 draft names Engagement Advisor and defers the household advisor of record to 03 Party Coverage Assignment.", "status": "Resolved", "decision": "CW-063"},
    {"term": "Team",
     "usages": [("03", "Coverage Team (SLT-)", "Own advisors serving households together"),
                ("05", "Advisor Team (moved from the wholesale 02, W4)", "External advisor team")],
     "recommendation": "Always qualified.", "resolution": "As recommended (CW-078).", "status": "Resolved", "decision": "CW-078"},
    {"term": "Review",
     "usages": [("08", "Supervisory Review (PRNR-)", "Principal review"), ("45", "Advice Review (AVREV-)", "Advice review with the client, incl. the Rule 3a-4 annual contact"),
                ("03", "Call Frequency Standard Contact Type 'Annual Review'; Activity Purpose 'Annual Review'", "Contact standard and activity purpose; the review record is 45's"),
                ("08", "Incentive Conflict Review", "Reg BI review of a 03 incentive component")],
     "recommendation": "03 holds no review record; 'Annual Review' in 03 names a contact type or purpose and references 45 AVREV-.",
     "resolution": "As recommended (CW-078).", "status": "Resolved", "decision": "CW-078"},
    {"term": "Plan",
     "usages": [("03", "Incentive Compensation Plan (ICP-)", "Advisor incentive plan; attributes say 'Incentive Plan'"),
                ("45", "Financial Plan (FPLAN-)", ""), ("16", "Retirement Plan", "")],
     "recommendation": "Never bare 'Plan' in 03: Incentive Compensation Plan, Incentive Plan ID, Incentive Plan Name.",
     "resolution": "As recommended (CW-078).", "status": "Resolved", "decision": "CW-078"},
    {"term": "Referral",
     "usages": [("03", "Channel Referral (RFRL-)", "Internal handoff between channels"),
                ("04", "Client Referral (CRFL-)", "Client-to-friend referral program")],
     "recommendation": "Always qualified; a Channel Referral may produce a 04 Marketing Lead, never a Client Referral.",
     "resolution": "As recommended (CW-065).", "status": "Resolved", "decision": "CW-065"},
    {"term": "Interaction / Activity",
     "usages": [("03", "Advisor Activity (ACT-)", "The advisor's own interaction"),
                ("13", "Contact Center Interaction (CCI-)", "Assisted-channel service interaction"),
                ("45", "Advice Review (AVREV-)", "Advice record held in an activity")],
     "recommendation": "A contact-center interaction is never an Advisor Activity; an activity references the 13 service request it came from.",
     "resolution": "As recommended (CW-061).", "status": "Resolved", "decision": "CW-061"},
    {"term": "Branch",
     "usages": [("03", "Firm Branch Office (profile of SITE-)", "Supervisory classification of the office"),
                ("08", "Branch Registration; Branch Inspection (BRIN-)", "Form BR filing and Rule 3110(c) inspection"),
                ("09", "Office Location (SITE-)", "The office itself"),
                ("02", "Party Role Type 'Branch / Office' (moved to 05 at W4)", "Intermediary firm branch")],
     "recommendation": "'Branch' alone means the firm's own branch office (03); an intermediary's branch is qualified.",
     "resolution": "As recommended (CW-072).", "status": "Resolved", "decision": "CW-072"},
    {"term": "Coverage",
     "usages": [("03", "Party Coverage Assignment (CVA-)", "Advisor coverage of a household or client"),
                ("12", "Service coverage (SVA-)", "Institutional client service coverage (CD-055)")],
     "recommendation": "12 service coverage stays qualified; the IA relationship manager of record is a 03 CVA- row.",
     "resolution": "Open: the 12 adaptation (W4) decides whether SVA- folds into CVA-.", "status": "Open", "decision": "CW-063"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. REPOINTS: map for readers of the wholesale 03 and of the 07 objects absorbed here (CW-062). Keys and values are
#    (domain, object, attribute); a value None means the attribute was dropped (the reader drops it or waits for 05 at W4).
#    Object-level map first; attributes not listed keep their name under the new object.
# ---------------------------------------------------------------------------------------------------------------------
OBJECT_MAP = {
    ("03", "Sales Person"): ("03", "Advisor"),
    ("03", "Sales Role"): ("03", "Advisor Role Assignment"),
    ("03", "License & Registration Reference"): ("03", "License & Registration Reference"),
    ("03", "Sales Team"): ("03", "Coverage Team"),
    ("03", "Team Membership & Channel Assignment"): ("03", "Coverage Team Membership"),
    ("03", "Sales Pairing & Alignment"): ("03", "Coverage Team Membership"),
    ("03", "Sales Activity"): ("03", "Advisor Activity"),
    ("03", "Internal Participant"): ("03", "Internal Participant"),
    ("03", "External Participant"): ("03", "External Participant"),
    ("03", "Discussion Content"): ("03", "Discussion Content"),
    ("03", "Outcome & Follow-Up"): ("03", "Outcome & Follow-Up"),
    ("03", "Activity Capture"): ("03", "Activity Capture"),
    ("07", "Coverage Model"): ("03", "Coverage Model"),
    ("07", "Call Frequency Standard"): ("03", "Call Frequency Standard"),
    ("07", "Party Coverage Assignment"): ("03", "Party Coverage Assignment"),
    ("07", "Incentive Compensation Plan"): ("03", "Incentive Compensation Plan"),
    ("07", "Compensation Statement"): ("03", "Compensation Statement"),
    ("07", "Coverage Team"): ("03", "Coverage Team"),
    ("07", "Alignment Rule"): ("03", "Coverage Assignment Rule"),
    ("07", "Alignment Rule Criterion"): ("03", "Coverage Assignment Rule Criterion"),
    ("07", "Alignment Exception"): ("03", "Coverage Assignment Rule"),
    ("07", "Realignment Event"): ("03", "Coverage Reassignment"),
    ("07", "Plan Component"): ("03", "Incentive Plan Component"),
    ("07", "Rate Table Tier"): ("03", "Incentive Plan Component"),
    ("07", "SPIF & MBO"): ("03", "Incentive Plan Component"),
    ("07", "Product Compensation Tier Mapping"): ("03", "Incentive Plan Component"),
    ("07", "Plan Participant Assignment"): ("03", "Incentive Plan Participation"),
    ("07", "Earnings Result"): ("03", "Incentive Earnings Line"),
    ("07", "Coverage Tier Assignment"): ("02", "Service Tier Assignment"),
}

REPOINTS = {
    # 03 Sales Person / Sales Role / teams
    ("03", "Sales Person", "Employee"): ("03", "Advisor", "Employee"),
    ("03", "Sales Person", "Sales Profile Status"): ("03", "Advisor", "Advisor Status"),
    ("03", "Sales Person", "CRM User ID"): None,
    ("03", "Sales Person", "Home Market"): None,                                   # EU/UK, CW-903
    ("03", "Sales Role", "Primary Sales Role"): ("03", "Advisor Role Assignment", "Advisor Role"),
    ("03", "Sales Role", "Producing Indicator"): ("03", "Advisor Role Assignment", "Producing Indicator"),
    ("03", "Sales Role", "Client-Facing Title"): ("03", "Advisor", "Client-Facing Title"),
    ("03", "Sales Team", "Sales Team ID"): ("03", "Coverage Team", "Coverage Team ID"),
    ("03", "Sales Team", "Sales Team Name"): ("03", "Coverage Team", "Coverage Team Name"),
    ("03", "Sales Team", "Sales Team Type"): ("03", "Coverage Team", "Coverage Team Type"),
    ("03", "Sales Team", "Parent Team"): ("03", "Coverage Team", "Parent Coverage Team"),
    ("03", "Sales Team", "Team Leader"): ("03", "Coverage Team", "Lead Advisor"),
    ("03", "Sales Team", "Primary Channel"): None,
    ("03", "Sales Team", "Sales Market"): None,                                    # EU/UK, CW-903
    ("03", "Team Membership & Channel Assignment", "Member Employee"): ("03", "Coverage Team Membership", "Member Advisor"),
    ("03", "Team Membership & Channel Assignment", "Member Sales Team"): ("03", "Coverage Team Membership", "Member Coverage Team"),
    ("03", "Team Membership & Channel Assignment", "Assigned Channel"): None,
    ("03", "Sales Pairing & Alignment", "Paired Employee"): ("03", "Coverage Team Membership", "Member Advisor"),
    ("03", "Sales Pairing & Alignment", "Partner Employee"): ("03", "Coverage Team Membership", "Member Advisor"),
    ("03", "Sales Pairing & Alignment", "Sales Pairing Type"): ("03", "Coverage Team Membership", "Membership Role"),
    ("03", "Sales Pairing & Alignment", "Pairing Effective From"): ("03", "Coverage Team Membership", "Membership Effective From"),
    ("03", "Sales Pairing & Alignment", "Pairing Effective To"): ("03", "Coverage Team Membership", "Membership Effective To"),
    ("03", "Sales Role", "Secondary Sales Roles"): ("03", "Advisor Role Assignment", "Advisor Role"),          # rows with Primary Role Indicator = N
    ("03", "Sales Role", "Sales Function"): ("03", "Advisor Role Assignment", "Advisor Role"),                # function grouping is a roll-up of Advisor Role
    ("03", "Sales Activity", "Activity Subject"): None,
    # 03 Sales Activity and its groups
    ("03", "Sales Activity", "Activity Territory"): None,
    ("03", "Sales Activity", "Related Opportunity"): None,                         # OPP- held for 05 at W4
    ("03", "Sales Activity", "Related Sales Play"): None,                          # PLY- retired
    ("03", "Sales Activity", "Related Marketing Event"): None,
    ("03", "Sales Activity", "Activity Sales Channel"): None,
    ("03", "Sales Activity", "Activity Location Type"): None,
    ("03", "Sales Activity", "Confidentiality Type"): ("03", "Advisor Activity", "Activity Classification"),
    ("03", "External Participant", "Participant Firm"): None,
    ("03", "External Participant", "External Attendee Count"): None,
    ("03", "Discussion Content", "Products Discussed"): ("03", "Discussion Content", "Products Discussed"),   # retyped Reference (Investment Product), PRD-
    ("03", "Activity Capture", "Communication Archive Reference"): ("03", "Activity Capture", "Communication Archive Reference"),  # now a typed Reference to 08 ARC-
    # 07 objects absorbed
    ("07", "Party Coverage Assignment", "Covering Salesperson"): ("03", "Party Coverage Assignment", "Covering Advisor"),
    ("07", "Call Frequency Standard", "Standard Coverage Tier"): ("03", "Call Frequency Standard", "Standard Service Tier"),
    ("07", "Call Frequency Standard", "Standard Coverage Role"): None,
    ("07", "Coverage Team", "Coverage Team ID"): ("03", "Coverage Team", "Coverage Team ID"),          # CTM- -> SLT-
    ("07", "Coverage Team", "Coverage Team Type"): ("03", "Coverage Team", "Coverage Team Type"),
    ("07", "Coverage Team", "Team Member"): ("03", "Coverage Team Membership", "Member Advisor"),
    ("07", "Coverage Team", "Pairing Partner"): None,
    ("07", "Coverage Team", "Team Membership Effective From"): ("03", "Coverage Team Membership", "Membership Effective From"),
    ("07", "Coverage Tier Assignment", "Coverage Tier"): ("02", "Service Tier Assignment", "Assigned Service Tier"),
    ("07", "Coverage Tier Assignment", "Tier Effective From"): ("02", "Service Tier Assignment", "Tier Effective From"),
    ("07", "Incentive Compensation Plan", "Plan ID"): ("03", "Incentive Compensation Plan", "Incentive Plan ID"),
    ("07", "Incentive Compensation Plan", "Plan Name"): ("03", "Incentive Compensation Plan", "Incentive Plan Name"),
    ("07", "Incentive Compensation Plan", "Plan Type"): ("03", "Incentive Compensation Plan", "Incentive Plan Type"),
    ("07", "Incentive Compensation Plan", "Plan Year"): ("03", "Incentive Compensation Plan", "Incentive Plan Year"),
    ("07", "Incentive Compensation Plan", "Plan Status"): ("03", "Incentive Compensation Plan", "Plan Approval Status"),
    ("07", "Plan Component", "Component Type"): ("03", "Incentive Plan Component", "Component Measure"),
    ("07", "Rate Table Tier", "Commission Rate"): None,
    ("07", "Rate Table Tier", "Rate Multiplier"): None,
    ("07", "Rate Table Tier", "Rate Product Tier"): None,
    ("07", "Rate Table Tier", "Tier Lower Bound"): None,
    ("07", "Rate Table Tier", "Tier Upper Bound"): None,
    ("07", "Product Compensation Tier Mapping", "Mapped Product / Share Class"): None,
    ("07", "Product Compensation Tier Mapping", "Mapped Product Compensation Tier"): None,
    ("07", "Product Compensation Tier Mapping", "Tier Mapping Effective From"): None,
    ("07", "Plan Component", "Component Cap"): ("03", "Incentive Plan Component", "Cap Percentage"),      # or Cap Amount; Text split in two
    ("07", "SPIF & MBO", "Incentive Objective Type"): ("03", "Incentive Plan Component", "Component Measure"),
    ("07", "SPIF & MBO", "Non-Cash Award Indicator"): ("03", "Recognition Award", "Recognition Award Type"),  # every Recognition Award row is non-cash
    ("07", "SPIF & MBO", "Product-Specific Incentive Indicator"): ("03", "Incentive Plan Component", "Product-Specific Time-Limited Indicator"),
    ("07", "SPIF & MBO", "Compliance Review Reference"): ("03", "Incentive Plan Component", "Incentive Conflict Review Reference"),
    ("07", "SPIF & MBO", "Award Value"): ("03", "Recognition Award", "Non-Cash Award Value"),
    ("07", "Plan Participant Assignment", "Participant Assignment Effective From"): ("03", "Incentive Plan Participation", "Participation Effective From"),
    ("07", "Earnings Result", "Earning Participant"): ("03", "Compensation Statement", "Statement Participant"),
    ("07", "Earnings Result", "Earning Period"): ("03", "Compensation Statement", "Statement Period End"),
    ("07", "Earnings Result", "Rate Applied"): None,
    ("07", "Earnings Result", "Earnings Result ID"): None,
    ("07", "Earnings Result", "Calculation Run ID"): None,
    ("07", "Alignment Rule", "Alignment Rule ID"): ("03", "Coverage Assignment Rule", "Assignment Rule ID"),
    ("07", "Alignment Rule", "Alignment Rule Type"): ("03", "Coverage Assignment Rule", "Assignment Rule Type"),
    ("07", "Alignment Rule", "Target Territory"): ("03", "Coverage Assignment Rule", "Target Coverage Team"),
    ("07", "Alignment Rule", "Aligned Party Level"): None,
    ("07", "Alignment Rule", "Inherit to Child Parties Indicator"): None,
    ("07", "Alignment Exception", "Excepted Party"): ("03", "Coverage Assignment Rule", "Excepted Party"),   # rule type Named Exception
    ("07", "Alignment Exception", "Exception Type"): ("03", "Coverage Assignment Rule", "Assignment Rule Type"),
    ("07", "Alignment Exception", "Override Territory"): ("03", "Coverage Assignment Rule", "Target Coverage Team"),
    ("07", "Alignment Exception", "Exception Expiry Date"): ("03", "Coverage Assignment Rule", "Rule Effective To"),
    ("07", "Alignment Exception", "Exception Effective From"): ("03", "Coverage Assignment Rule", "Rule Effective From"),
    ("07", "Realignment Event", "Realignment Event ID"): ("03", "Coverage Reassignment", "Reassignment ID"),
    ("07", "Realignment Event", "Realignment Effective Date"): ("03", "Coverage Reassignment", "Reassignment Effective Date"),
    ("07", "Realignment Event", "Transition Credit Rule"): None,
    ("07", "Realignment Event", "Realignment Type"): ("03", "Coverage Reassignment", "Reassignment Reason"),
}

# One-line reasons for the attributes mapped to None (readers drop them or wait for 05 at W4).
REPOINT_REASONS = {
    ("03", "Sales Person", "CRM User ID"): "System user key, not a business attribute; the CRM maps users to EMP-.",
    ("03", "Sales Person", "Home Market"): "EU/UK markets; US only (CW-903).",
    ("03", "Sales Team", "Primary Channel"): "Intermediary channel moves to 05 (W4); teams carry Coverage Team Type.",
    ("03", "Sales Team", "Sales Market"): "EU/UK markets; US only (CW-903).",
    ("03", "Team Membership & Channel Assignment", "Assigned Channel"): "Intermediary channel moves to 05 (W4).",
    ("03", "Sales Activity", "Activity Territory"): "No territories (CW-013).",
    ("03", "Sales Activity", "Related Opportunity"): "OPP- held for 05 at W4 (CW-062).",
    ("03", "Sales Activity", "Related Sales Play"): "PLY- retired with Sales Play.",
    ("03", "Sales Activity", "Related Marketing Event"): "Events are 04; not on the retail activity (brief section 5).",
    ("03", "Sales Activity", "Activity Sales Channel"): "Intermediary channel moves to 05 (W4).",
    ("03", "Sales Activity", "Activity Location Type"): "Branch meetings use the 03 office; offsite hospitality is an 08 gift.",
    ("03", "Sales Activity", "Activity Subject"): "Free-text subject dropped to keep the activity within the attribute target; Activity Purpose classifies it.",
    ("03", "External Participant", "Participant Firm"): "Affiliation snapshot of an intermediary advisor; 05 at W4.",
    ("03", "External Participant", "External Attendee Count"): "Seminar head counts are 04 event registrations.",
    ("07", "Call Frequency Standard", "Standard Coverage Role"): "The coverage model's roles cover it (Coverage Roles Included).",
    ("07", "Coverage Team", "Pairing Partner"): "Pairing becomes a Membership Role; the pair is two membership rows of one team.",
    ("07", "Rate Table Tier", "Commission Rate"): "Rate tables dropped: a direct firm pays bonus on client outcomes (CW-064).",
    ("07", "Rate Table Tier", "Rate Multiplier"): "As above (CW-064).",
    ("07", "Rate Table Tier", "Rate Product Tier"): "Product compensation tiers dropped: product-based pay is a Reg BI conflict (CW-064).",
    ("07", "Rate Table Tier", "Tier Lower Bound"): "Attainment bands dropped with rate tables; Threshold Attainment and caps remain (CW-064).",
    ("07", "Rate Table Tier", "Tier Upper Bound"): "As above (CW-064).",
    ("07", "Product Compensation Tier Mapping", "Mapped Product / Share Class"): "Product tiering dropped (CW-064; Reg BI).",
    ("07", "Product Compensation Tier Mapping", "Mapped Product Compensation Tier"): "Product tiering dropped (CW-064; Reg BI).",
    ("07", "Product Compensation Tier Mapping", "Tier Mapping Effective From"): "Product tiering dropped (CW-064; Reg BI).",
    ("07", "Earnings Result", "Rate Applied"): "No rate tables (CW-064); Incentive Earnings Line holds Measured Result and Attainment Percentage.",
    ("07", "Earnings Result", "Earnings Result ID"): "Earnings lines are keyed by statement x component.",
    ("07", "Earnings Result", "Calculation Run ID"): "Calculation runs are the incentive tool's operational log; the statement keeps the result.",
    ("07", "Alignment Rule", "Aligned Party Level"): "No distributor hierarchy; rules place households.",
    ("07", "Alignment Rule", "Inherit to Child Parties Indicator"): "No distributor hierarchy.",
    ("07", "Realignment Event", "Transition Credit Rule"): "No crediting (CW-013, CW-064).",
}
# Primary keys that change for the model readers (models_f2.py, DP-009): the Sales Pairing entity (models_f2.py:278) has
# pk Paired Employee / Partner Employee / Sales Pairing Type / Pairing Effective From; it becomes two Coverage Team Membership
# rows (Member Coverage Team / Member Advisor / Membership Role / Membership Effective From), so the entity folds into Sales
# Team Membership (pk Member Coverage Team, Member Advisor, Membership Effective From) and DP-009's pairing measures count
# memberships of the same team with complementary Membership Roles. Paired Employee and Partner Employee both map to Member
# Advisor: the pair relationship is recovered by joining two membership rows of one Coverage Team.
PK_CHANGES = {
    "models_f2.py:278 Sales Pairing": (["Paired Employee", "Partner Employee", "Sales Pairing Type", "Pairing Effective From"],
                                       ["Member Coverage Team", "Member Advisor", "Membership Role", "Membership Effective From"]),
    "models_f2.py:271 Sales Team": (["Sales Team ID"], ["Coverage Team ID"]),
    "models_f2.py:274 Sales Team Membership": (["Member Employee", "Member Sales Team", "Membership Effective From"],
                                               ["Member Advisor", "Member Coverage Team", "Membership Effective From"]),
    "models_f2.py:325 Coverage Model": (["Coverage Model Code"], ["Coverage Model Code"]),   # unchanged name; values now firm-defined
}

# ---------------------------------------------------------------------------------------------------------------------
# 6. JURISDICTION: EU/UK content of the wholesale 03 (wholesale-v1.0) and of the 07 objects 03 absorbs that the replacement
#    does not carry (CW-022 item 2; brief section 4a). Format: jurisdiction.REMOVALS. 07 content is recorded with domain
#    "07" under CW-903 (CW-079); whole objects and whole lists have attribute "".
# ---------------------------------------------------------------------------------------------------------------------
_D = "CW-903"
def _j(obj, attr, regime, note, domain="03"):
    return {"domain": domain, "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}

JURISDICTION = [
    # 03 attributes
    _j("Sales Person", "Home Market", "Other EU/UK", "Country or market sold into (UK, EU markets, Switzerland, Canada); the firm is US only. Not carried on Advisor."),
    _j("Sales Team", "Sales Market", "Other EU/UK", "Market a team sells into (Sales Market list); not carried on Coverage Team."),
    _j("License & Registration Reference", "License Reference (FCA Certification Regime and local EU registrations in the definition)", "SM&CR", "Kept as License Reference; definition re-sourced to FINRA Rule 1210 and SEC Rule 203A-3 (08 Individual Registration)."),
    _j("License & Registration Reference", "Registered Representative Indicator (secondary reference FCA SM&CR)", "SM&CR", "Kept; secondary reference now FINRA Rule 1220."),
    _j("Activity Capture", "Recorded Communication Indicator (primary reference MiFID II Art 16(7))", "MiFID II", "Kept; re-sourced to SEC Rule 17a-4(b)(4)."),
    _j("Activity Capture", "Recorded Communication Indicator (secondary reference FCA SYSC 10A)", "FCA", "Kept; re-sourced to Advisers Act Rule 204-2(a)(7)."),
    _j("Activity Capture", "Gifts & Entertainment Reference (secondary reference FCA COBS 2.3A)", "FCA", "Kept; FINRA Rule 3220 only."),
    # 03 code-list values
    _j("Code list: Sales Market", "Canada", "Other non-US", "Whole list not carried (Sales Market membership of Distribution Market removed); US-only value US is implicit."),
    _j("Code list: Sales Market", "UK", "Other EU/UK", ""),
    _j("Code list: Sales Market", "Ireland", "Other EU/UK", ""),
    _j("Code list: Sales Market", "Germany / Austria", "Other EU/UK", ""),
    _j("Code list: Sales Market", "Switzerland", "Other non-US", ""),
    _j("Code list: Sales Market", "France / Benelux", "Other EU/UK", ""),
    _j("Code list: Sales Market", "Italy", "Other EU/UK", ""),
    _j("Code list: Sales Market", "Iberia", "Other EU/UK", ""),
    _j("Code list: Sales Market", "Nordics", "Other EU/UK", ""),
    _j("Code list: Sales Market", "Pan-European", "Other EU/UK", ""),
    _j("Code list: Sales Channel", "Intermediary - IFA / Wealth Manager", "Other EU/UK", "UK/EU IFAs and DFMs; the rest of the list moves to 05 at W4 with the intermediary channel."),
    _j("Code list: Sales Role", "Key Account Manager", "Other EU/UK", "Strategic distributor relationships (EU/UK); Advisor Role is a retail list."),
    _j("Code list: Sales Role", "Wealth / IFA Sales Manager", "Other EU/UK", "Field coverage of UK/EU IFAs, DFMs and wealth managers."),
    _j("Code list: Audience Type", "Professional Client (UK/EU)", "MiFID II", "Audience Type went with the dropped Content Usage Event; Audience Restriction membership removed."),
    _j("Code list: Audience Type", "Source FCA COBS 4", "FCA", "List source attribution; FINRA Rule 2210 is the US source (08)."),
    _j("Code list: Personal Data Category", "Source GDPR", "GDPR / UK GDPR", "List source re-attributed to SEC Regulation S-P and CCPA / CPRA (shared list, steward 02)."),
    # 03 sources
    _j("Sources", "MiFID II Article 16(7) and FCA SYSC 10A (recording of communications)", "MiFID II", "Re-sourced to SEC Rule 17a-4 and Advisers Act Rule 204-2. FCA SYSC 10A recorded with it."),
    _j("Sources", "FCA COBS (2.3A inducements, 4 financial promotions) and SM&CR", "FCA", "Re-sourced to FINRA Rules 3220, 2210 and 1210 / 1220."),
    _j("Sources", "GDPR (Regulation (EU) 2016/679) / UK GDPR", "GDPR / UK GDPR", "Re-sourced to Regulation S-P and the CCPA / CPRA."),
    _j("Sources", "ICI Investment Funds Distributor Due Diligence Questionnaire (UCITS / AIF distributors)", "UCITS", "Boundary source for distributor due diligence (moves with 08 Distributor Due Diligence to 05 at W4); not carried."),
    # 07: the objects and attributes 03 absorbs or that the brief lists
    _j("Territory Geographic Unit", "NUTS Code", "Other EU/UK", "Eurostat NUTS regions; assignment geography is 09 US Geographic Group (Coverage Assignment Rule Criterion).", "07"),
    _j("Territory Geographic Unit", "UK Postcode District", "Other EU/UK", "ONS postcode districts; not carried.", "07"),
    _j("Sales Cluster", "", "Other EU/UK", "Multi-country EU/UK sales clusters (Cluster Code, Cluster Member Countries, e.g. DACH); not carried.", "07"),
    _j("Remuneration Conflict Assessment", "", "MiFID II", "Removed as an EU/UK object (MiFID II Art 24(10), FCA SYSC 19F/19E/19B, ESMA remuneration guidelines, UCITS and AIFMD identified staff). Its US content was re-sourced, not removed: Applicable Remuneration Regime values SEC Reg BI, FINRA Rule 2341 and FINRA Rule 3220 -> the Reg BI test is 08 Incentive Conflict Review (Rule 15l-1(a)(2)(iii)) referenced from 03 Incentive Plan Component, with the 03 Product-Specific Time-Limited, Proprietary Product Linked and Rollover Neutral indicators; Rules 2341 and 3220 non-cash compensation -> 03 Recognition Award and 08 Gift / Entertainment Item; Product Neutrality Assessment -> 08 Incentive Conflict Review (its proprietary product finding) fed by the 03 Proprietary Product Linked Indicator; Assessment Outcome -> 08 Incentive Conflict Review outcome; Qualitative Criteria Included Indicator -> dropped, because every 03 Incentive Measure is a client-outcome or firm-level measure by design (the indicator would always be true).", "07"),
    _j("Remuneration Conflict Assessment", "Relevant Person Indicator", "MiFID II", "MiFID II / SYSC 19F relevant person; recorded with the object.", "07"),
    _j("Remuneration Conflict Assessment", "Identified Staff Indicator", "UCITS", "UCITS / AIFMD identified staff (SYSC 19E, 19B); recorded with the object.", "07"),
    _j("SPIF & MBO", "Product-Specific Incentive Indicator (MiFID review in the definition)", "MiFID II", "Kept as Incentive Plan Component Product-Specific Time-Limited Indicator, sourced to Reg BI and FINRA Rule 2341 only.", "07"),
    _j("Code list: Geographic Unit Type", "UK Postcode Area", "Other EU/UK", "", "07"),
    _j("Code list: Geographic Unit Type", "UK Postcode District", "Other EU/UK", "", "07"),
    _j("Code list: Geographic Unit Type", "NUTS Region", "Other EU/UK", "", "07"),
    _j("Code list: Coverage Model", "Country Sales Team", "Other EU/UK", "EU/UK country or cluster team; the 03 Coverage Model list is re-cut to retail values.", "07"),
    _j("Code list: Coverage Role", "Country / Cluster Sales Manager", "Other EU/UK", "", "07"),
    _j("Code list: Remuneration Regime", "MiFID II Art 24(10) / ESMA35-43-3565", "MiFID II", "List not carried (object removed).", "07"),
    _j("Code list: Remuneration Regime", "UK FCA SYSC 19F", "FCA", "", "07"),
    _j("Code list: Remuneration Regime", "UK FCA SYSC 19E / ESMA UCITS Remuneration Guidelines", "UCITS", "", "07"),
    _j("Code list: Remuneration Regime", "UK FCA SYSC 19B / AIFMD", "AIFMD", "", "07"),
    _j("Code list: Remuneration Regime", "UK FCA Consumer Duty", "Consumer Duty", "", "07"),
    _j("Sources", "Eurostat NUTS classification (NUTS 2024)", "Other EU/UK", "", "07"),
    _j("Sources", "ONS National Statistics Postcode Lookup (NSPL)", "UK market practice", "", "07"),
    _j("Sources", "ESMA Guidelines on certain aspects of the MiFID II remuneration requirements (ESMA35-43-3565)", "MiFID II", "Re-sourced to Reg BI Rule 15l-1(a)(2)(iii).", "07"),
    _j("Sources", "ESMA Guidelines on sound remuneration policies under the UCITS Directive (ESMA/2016/575) and AIFMD equivalent", "UCITS", "", "07"),
    _j("Sources", "UK FCA SYSC 19F, SYSC 19E and SYSC 19B", "FCA", "", "07"),
    _j("Sources", "MiFID II Directive 2014/65/EU Art. 24(10) and Delegated Regulation (EU) 2017/565 Art. 27", "MiFID II", "", "07"),
    _j("Sources", "GDPR and US state privacy laws (EU part)", "GDPR / UK GDPR", "US state privacy laws kept (CCPA / CPRA source).", "07"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. DECISIONS: the US-only pass of 03 (pre-allocated id, CW-022, CW-079).
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-903", "theme": "Scope", "title": "US-only pass of Data Domain 03 Advisor Organization, Coverage & Supervision (replacement of the wholesale 03 Sales and the 07 objects it absorbs)",
     "domains": ["03", "07"],
     "issue": "The wholesale 03 Sales carried EU/UK markets, channels, roles, recording and inducement sources and SM&CR wording; the 07 objects that 03 absorbs (and the 07 geography the brief names) carried NUTS and UK postcode geography, EU/UK sales clusters and the MiFID / SYSC 19F / ESMA / UCITS / AIFMD remuneration conflict assessment. The replacement (CW-013, CW-061) is designed US only and must record what it leaves out so that a UK extension can be restored.",
     "resolution": "Not carried (51 JURISDICTION entries in proposals_w2_03.py: 27 for 03 and 24 for 07; 2 objects, 12 attributes or attribute wordings, 26 code-list values and list attributions, 11 sources). 03: attributes Sales Person Home Market and Sales Team Sales Market; the SM&CR wording of License Reference and Registered Representative Indicator, re-sourced to FINRA Rules 1210 and 1220 and SEC Rule 203A-3; the MiFID II Art 16(7) and FCA SYSC 10A sources of Recorded Communication Indicator, re-sourced to SEC Rule 17a-4(b)(4) and Advisers Act Rule 204-2(a)(7); the FCA COBS 2.3A source of Gifts & Entertainment Reference (FINRA Rule 3220 kept); the ten non-US values of Sales Market (Canada and Switzerland as Other non-US); Sales Channel Intermediary - IFA / Wealth Manager; Sales Role Key Account Manager and Wealth / IFA Sales Manager; Audience Type Professional Client (UK/EU) and its FCA COBS 4 source; the GDPR attribution of Personal Data Category; sources MiFID II / SYSC 10A, FCA COBS and SM&CR, GDPR / UK GDPR and the ICI distributor DDQ (UCITS / AIF). 07: Territory Geographic Unit NUTS Code and UK Postcode District; Sales Cluster; Remuneration Conflict Assessment with Relevant Person and Identified Staff Indicators; the MiFID wording of the SPIF Product-Specific Incentive Indicator; Geographic Unit Type values UK Postcode Area, UK Postcode District, NUTS Region; Coverage Model Country Sales Team; Coverage Role Country / Cluster Sales Manager; five EU/UK Remuneration Regime values; sources Eurostat NUTS, ONS NSPL, the two ESMA remuneration guidelines, FCA SYSC 19F/19E/19B, MiFID II Art 24(10) and the EU part of the GDPR source. Kept and re-sourced: activity capture and retention (SEC Rule 17a-4, Advisers Act Rule 204-2), gifts and non-cash compensation (FINRA Rules 3220 and 2341), the incentive conflict test (Reg BI Rule 15l-1(a)(2)(iii), reviewed in 08 Incentive Conflict Review), registration references (FINRA Rules 1210 and 1220, SEC Rule 203A-3) and personal data (Regulation S-P, CCPA / CPRA). Foreign-language service and clients resident abroad stay where US law allows (Languages Spoken; Covered Party is any 02 party).",
     "rationale": "US only narrows where the firm is regulated, distributes and serves clients (CW-003, CW-022). Objects moved to 05 at W4 (opportunities, RFPs, answer library, consultant databases, account plans) keep their EU/UK values for 05's pass (for example Manager Database 'bfinance'); 07 content is recorded here only for the objects 03 absorbs and the items brief section 4a names (Territory Geographic Unit with its Geographic Unit Type values, Sales Cluster, Remuneration Conflict Assessment with its Remuneration Regime values, and their sources); every other 07 object and list (Market Scope, Sales Channel, Territory Type, Territory Level, Product Scope and the rest) retires with 07 at W4 and is restorable from tag wholesale-v1.0, so the W4 retirement records nothing twice. Lever: UK extension.",
     "action": "Merge JURISDICTION into jurisdiction.REMOVALS at the W2 merge", "status": "Proposed", "priority": "Medium",
     "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 8. NOTES for the consolidation step.
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Module and files: content_03_advisor_organization_coverage_and_supervision.py (beside the wholesale content_03_sales.py, which the lead removes at integration), enrichment/enrich_03.py (rewritten), 03_Advisor_Organization_Coverage_and_Supervision/Source_Notes.md, this file. check_enrichment.py picks the first content_03_* from an unsorted os.listdir; on this machine it listed the new module first and checked it (32 objects).",
    "Size after the review fix pass: 7 families, 32 objects (22 BO, 10 AG; the brief says 30 / 20 / 10 but its own table lists 32), 249 attributes (246 before), 74 CDEs (30%; 69 before), 43 code lists (36 local and 7 shared copies; 38 local before), 54 relationships, 21 sources; 53 references, 7 derived copies, 21 overrides, 2 row ownership rules, 0 unresolved.",
    "PREFIXES at merge (CW-062, CW-080): move CVA-, ICP-, CPS- to owner 03; relabel ACT- 'Advisor activity' and SLT- 'Coverage team'; then the five OWNERSHIP_OVERRIDES '' entries in enrich_03.py for CVA- and ICP- examples become redundant (harmless). CONCEPT_OWNERSHIP: 'Sales Team' -> 'Coverage Team', 'Sales Activity' -> 'Advisor Activity', 'Coverage Assignment' (07) -> 'Party Coverage Assignment' (03), 'Incentive Compensation Plan' and 'Compensation Statement' -> 03; add Advisor (03, keyed EMP-), Firm Branch Office (03, keyed SITE-), Channel Referral (RFRL-), Coverage Reassignment (REAS-), Coverage Assignment Rule (ASRL-), Recognition Award (RECG-). ownership.py ALIASES: 'activity' -> 03 stays; 'territory' -> 07 stays until W4.",
    "45 dependency (CW-063): the 45 brief and CW-044 give Advice Engagement an 'advisor of record' (20 EMP-). TERM_CONFLICTS 'Advisor of record' asks 45 to rename it Engagement Advisor and read the advisor of record from 03 CVA- as of a date. 45 prefixes used here: ADENG- (Advice Engagement), AVREV- (Advice Review), RECOM- (Recommendation), not the plan anchors ADE- and RCO- the 03 brief cites.",
    "08 dependency: references typed by the 08 brief's names: Individual Registration (LIC-), Branch Registration (composite SITE- / branch CRD, forced to 08), Heightened Supervision Plan (HSPL-), Captured Communication Record (ARC-), Gift / Entertainment Item (GNE-), Complaint (CPL-), Incentive Conflict Review (composite ICP- component or RECG- award / review date, forced to 08). The 08 brief's Incentive Conflict Review is keyed by component only; this module also references it from Recognition Award: 08 should allow a recognition program as review subject (or the lead drops Award Conduct Review Reference).",
    "13 dependency: Service Request (SRQ-) and Recipient Delivery Record (MAIL- / ACC- composite) by their kept names; the reassignment notice is a per-recipient delivery, not a Shareholder Communication master (review A). 13 'advisor from 03' types Reference (Advisor, 03) by EMP- and reads the coverage by CVA-.",
    "04 dependency: Campaign (CAM-), Content Asset (AST-), Marketing Lead (LEAD-). 04 Lead Assignment 'Assigned Advisor or Team (03)' should be Reference (Advisor, 03) / Reference (Coverage Team) with SLT-; 04 Lead Conversion no longer converts to a 03 opportunity. 04 Client Referral (CRFL-) is distinct from Channel Referral (TERM_CONFLICTS 'Referral').",
    "05 (W4): no External Advisor, intermediary firm, opportunity, RFP or consultant object or reference here. OPP-, RFP-, ANS-, DBS-, KAP- stay held for 05 (CW-062); their wholesale objects are not restored here.",
    "51: Resulting Trust is Reference (Trust, 51) with TRUST-; trust officers are Advisors with role Trust Officer (SME question 8 default).",
    "06 (W4): Advisor Capacity Snapshot Book Client Assets is a Derived copy of 06 Client Assets (future owner 06, W4), the only client-assets copy here. 06 flow attribution by advisor reads Party Coverage Assignment (Primary Coverage Indicator) as of the trade date.",
    "20: the relationship text 'Employee is extended by Sales Person [03]' (content_20_human_capital.py:464) -> 'Advisor [03]'; 'Payroll Result pays Payroll Payment Instruction / Compensation Statement [07]' (489) -> 'Compensation Statement [03]'; Payroll Result 'Incentive Payout Statements' definition says '07 compensation statements' (297) -> 03; Employee Termination Date note (48) 'coverage reassignment in 07' -> 03. CPS- examples resolve unchanged once CPS- moves.",
    "Supervisory structure (CW-072): Firm Branch Office holds no supervising OSJ and no branch manager attribute; both are held once, in Supervisory Hierarchy Link and Principal Designation (type Branch Manager). Advisor Role no longer has Branch Manager or Supervising Principal values. The inspection cycle is not held: it follows from Branch Type and Supervises Non-Branch Locations Indicator (FINRA Rule 3110(c)(1)); 08 Branch Inspection records the inspections.",
    "FOR 08 (program-lead ruling on the 03 review): (1) 03 masters the Branch Type list; its values are the Rule 3110 location classes Office of Supervisory Jurisdiction, Branch Office, Non-Branch Location, and a residential supervisory location is Firm Branch Office.Residential Supervisory Location Indicator (on a Non-Branch Location). 08 Branch Inspection 'Branch Type at Inspection' and 08 Branch Registration 'Registered Branch Type' become Derived copies (03) of these values, and 08's own Branch Type list (Supervisory / Non-Supervisory Branch Office, separate RSL value) is removed; the supervisory split is Firm Branch Office.Supervises Non-Branch Locations Indicator. (2) 03 Supervisory Assignment masters the heightened-supervision supervisor (Supervisory Assignment Type 'Heightened Supervision Supervisor' with the HSPL- reference); 08 Heightened Supervision Plan.Heightened Supervisor becomes a Derived copy (03). The 08 fix pass applies both; enrich_03.py ROW_OWNERSHIP states the 03 side.",
    "Advisor of record precedence (CW-063, program-lead ruling): one primary per scope per date; for 06 attribution and 47 billing the advisor of record of an account resolves at account scope, then client, then household. Stated on Party Coverage Assignment.Primary Coverage Indicator and in enrich_03.py ROW_OWNERSHIP.",
    "Typing: references to a person who must hold an Advisor profile are Reference (Advisor) (13 attributes), forced to 'mastered here' in OWNERSHIP_OVERRIDES because the EMP- key resolves to 20 by prefix; staff who need not be advisors stay Reference (Employee): Advisor.Employee (the key), Internal Participant, Activity Owner (05 partner and consultant meetings are activities too, CW-138), Designated Principal, Supervised Person, Assigned Supervisor, Reassignment Approver, Referring Employee, Status Changed By. At the merge add 'Advisor' (03, keyed EMP-) to CONCEPT_OWNERSHIP so sibling references 'Reference (Advisor, 03)' keep resolving to 03 if the prefix rule changes.",
    "05 needs (CW-138): Activity Type gains Partner Meeting, Consultant Meeting, Plan Sponsor Review and Finals Presentation; Activity Participant Role gains External Advisor, Investment Consultant, Plan Sponsor Contact and Partner Firm Contact; the activity subject is Activity Party (a household, client or partner party).",
    # ---- Readers of the wholesale 03 and the absorbed 07 objects (scan of data_products, data_models, semantic_model) ----
    "READERS - scan of ('03'|'07' absorbed, object, ...) tuples (counts by file): data_products specs_c_sales.py 162, specs_h_planning_partners.py 63, specs_b_foundational.py 52 (DP-009 at 5-151, DP-010 at 152-, DP-015), specs_g_advisor_analytics.py 31, specs_e_comp_finance_service.py 26 (DP-032, DP-033), specs_n_compliance_controls.py 22, specs_d_marketing_product.py 21, specs_e5_cross_area.py 8 (DP-243), specs_p_inst_intel_finance.py 8, specs_f_compliance.py 7, specs_e4_people_workplace_ai.py 3 (DP-198, 191-194); data_models keys_g2_03_04_05.py 117 (259-332), keys_g3_06_07_10.py 34 (232-258), keys.py 19 (122-176), keys_g5_11_12_13_14.py 2 (293: 11 Mandate Search Event Linked Opportunity -> 03 Sales Opportunity, 05 at W4; 328: 12 Client Review Meeting Activity -> Advisor Activity), keys_e7_19_21.py 1; models_c1_sales.py 69, models_c6_planning_finance.py 29, models_f2.py 22 (DP-009 and DP-010 entities, 255-549; primary keys in PK_CHANGES), models_c5_advisor_privacy.py 16, models_c3_comp_finance_service.py 9 (Rate Table Tier columns, dropped), models_c4_compliance.py 8, models_016_pilot.py 5, models_e8c_cross_area.py 4, models_c9_events_inst_intel.py 3, models_e8c_people_workplace_ai.py 1 (191, Fact Compensation Statement 07 -> 03); models_c2_marketing_product.py reads DP-009 Territory as a conformed dimension (97-142), dropped with territories (CW-013). Semantic models: sm_05_marketing.py:162 (DP-026 entity Sales Activity -> Advisor Activity, a direct read); sm_00_shared_dimensions.py 292 and 322 and sm_02_advisors_field_sales.py 209 (DP-009 Primary Coverage Model and Primary Coverage Indicator); sm_15_people_workplace.py 250 (hides Total Earned). framework.py: DP-009 owner domain '07' (568) becomes '03' at W4 (CW-080); DP-010 (570), DP-017 and DP-092 (585-587) already '03'.",
    "READERS - content relationship texts: content_20_human_capital.py 464 (Sales Person [03] -> Advisor [03]) and 489 (Compensation Statement [07] -> [03]); content_12_institutional_client_servicing_and_reporting.py 540 (Service Coverage Assignment assigns Sales Employee [03] -> Advisor [03]; 'distinct from 07 sales coverage assignments (CVA-)' -> 03), 559 (Client Review is held as Sales Activity [03] -> Advisor Activity [03]) and 560 (Opportunity [03] -> 05 at W4); content_32_performance_and_attribution.py 466 (Database Submission [03] -> 05 at W4); content_10_distribution_finance_and_profitability.py 367 (Sales Forecast Reference, FCS- retired: drop at 10's W4 adaptation) and 175 (Assessed Cost Source '07 ICP-' -> 03 ICP-).",
    "READERS - by object (counts of tuples): resolve unchanged under 03 by name: External Participant (12; Participant Firm dropped), Internal Participant (3), Discussion Content (4), Outcome & Follow-Up (1), Activity Capture (3), License & Registration Reference (2), Sales Activity -> Advisor Activity (36; Activity Territory, Related Sales Play, Related Opportunity, Related Marketing Event dropped), Sales Person -> Advisor (7), Sales Role -> Advisor Role Assignment (2), Sales Team -> Coverage Team (2), Team Membership & Channel Assignment and Sales Pairing & Alignment -> Coverage Team Membership (4); 07 -> 03: Party Coverage Assignment (10; Covering Salesperson renamed), Call Frequency Standard (8), Compensation Statement (10), Incentive Compensation Plan (3; Plan Year renamed), Coverage Model (models only), Coverage Team (4), Plan Component (4), Plan Participant Assignment (3), Earnings Result (5), SPIF & MBO (4), Alignment Rule / Criterion / Exception (21), Realignment Event (1), Rate Table Tier (2, dropped), Product Compensation Tier Mapping (1, dropped), Coverage Tier Assignment (3, -> 02). See OBJECT_MAP and REPOINTS. Dropped until 05 restores them at W4 (DP-243 and specs_c_sales / specs_h_planning_partners): Sales Opportunity (15), Opportunity Value (15), Pipeline Status (13), Placement, Model & DCIO Detail (18), RFP Request (14), RFP Submission (6), Request Question (5), Answer Library Entry (7), Consultant Rating (9), Consultant Research Review (4), Consultant Notification (4), Database Profile (3), Database Submission (3), Institutional Search Detail (4), Opportunity Team (4), Opportunity Product (2), Opportunity Competitor (1), Win / Loss (5), Stage History (3), Account Plan (4), Plan Objective (2), Plan Action (4), Stakeholder Map (6). Dropped for good: Content Usage Event (8), Sales Play (4), Forecast Submission (6), Pipeline Snapshot (2).",
    "READERS - carried content modules: 04 Lead Assignment First Sales Activity and 12 Client Review Meeting Activity (ACT-) resolve unchanged; 20 Payroll Result Incentive Payout Statements (CPS-) and 10 Capitalization Assessment (ICP-) resolve once the prefixes move; the W4 list of CW-062 (04, 05, 06, 10, 11 territory, opportunity and crediting references) is unchanged.",
]

READERS = {
    "live_products": ["DP-009", "DP-010"],
    # Every product whose spec reads a wholesale 03 or absorbed 07 object; all but DP-009 and DP-010 are wholesale products
    # pending their re-cut at WP0 (CW-013).
    "products": {"DP-009": "live", "DP-010": "live", "DP-006": "pending, WP0 (upstream DP-009 territory alignment)",
                 "DP-007": "pending, WP0 (upstream DP-009 territory alignment)", "DP-015": "pending, WP0",
                 **{f"DP-0{n}": "pending, WP0" for n in (16, 17, 18, 19, 20, 21, 22, 23, 24, 26, 27, 30, 32, 33, 38, 39, 46, 47, 48,
                                                         50, 53, 54, 55, 57, 66, 78, 82, 86, 89, 92)},
                 "DP-198": "pending, WP0", "DP-243": "pending, WP0 (pipeline objects wait for 05 at W4)"},
    "product_files": {"specs_b_foundational.py": ["DP-009", "DP-010", "DP-015"],
                      "specs_c_sales.py": ["DP-016", "DP-017", "DP-018", "DP-019", "DP-020", "DP-021", "DP-022", "DP-023", "DP-024", "DP-092"],
                      "specs_d_marketing_product.py": ["DP-026", "DP-027", "DP-030"],
                      "specs_e_comp_finance_service.py": ["DP-032", "DP-033"],
                      "specs_e4_people_workplace_ai.py": ["DP-198"],
                      "specs_e5_cross_area.py": ["DP-243"],
                      "specs_f_compliance.py": ["DP-038", "DP-039"],
                      "specs_g_advisor_analytics.py": ["DP-046", "DP-047", "DP-048", "DP-053"],
                      "specs_h_planning_partners.py": ["DP-050", "DP-054", "DP-055", "DP-057", "DP-066"],
                      "specs_n_compliance_controls.py": ["DP-078", "DP-082"],
                      "specs_p_inst_intel_finance.py": ["DP-086", "DP-089"],
                      "specs_a_foundational.py": ["DP-006", "DP-007"],
                      "framework.py": ["DP-009", "DP-010", "DP-017", "DP-092"]},
    "models": ["models_f2.py", "models_c1_sales.py", "models_c2_marketing_product.py", "models_c3_comp_finance_service.py",
               "models_c4_compliance.py", "models_c5_advisor_privacy.py", "models_c6_planning_finance.py", "models_c9_events_inst_intel.py",
               "models_016_pilot.py", "models_e8c_cross_area.py", "models_e8c_people_workplace_ai.py"],
    "keys": ["keys.py", "keys_g2_03_04_05.py", "keys_g3_06_07_10.py", "keys_g5_11_12_13_14.py", "keys_e7_19_21.py"],
    "semantic": ["sm_05_marketing.py", "sm_00_shared_dimensions.py", "sm_02_advisors_field_sales.py", "sm_15_people_workplace.py"],
    "content_relationship_texts": ["content_20_human_capital.py:464", "content_20_human_capital.py:489",
                                   "content_12_institutional_client_servicing_and_reporting.py:540",
                                   "content_12_institutional_client_servicing_and_reporting.py:559",
                                   "content_12_institutional_client_servicing_and_reporting.py:560",
                                   "content_32_performance_and_attribution.py:466",
                                   "content_10_distribution_finance_and_profitability.py:367",
                                   "content_10_distribution_finance_and_profitability.py:175"],
}
