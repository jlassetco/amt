"""Consolidation proposals from the W2 draft of Data Domain 04 Marketing, Digital & Client Engagement (wealth manager),
2026-10-14.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py,
shared_code_lists.py and jurisdiction.REMOVALS at the W2 merge. Formats follow CONTRACT.md in this folder. The brief is
00_Program/Rework/Briefs/04_Marketing_Digital_and_Client_Engagement.md; the draft implements CW-003, CW-004, CW-013, CW-022,
CW-029, CW-083 to CW-087 and CW-091 to CW-094 (proposals_w2_engagement.py, treated as accepted) and drafts CW-904, the US-only
pass and wealth adaptation of 04. Content module: _tools/content/content_04_marketing_and_digital.py (rewritten in place; the
wholesale version stays at tag wholesale-v1.0).
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES (decisions.PREFIXES tuple format). None beyond the eight reserved in proposals_w2_engagement.py (JRNY-,
#    NUDG-, EXPMT-, PROMO-, CRFL-, CSVY-, SRSP-, DIGP-) and the kept CAM-, AST-, EVT-, LEAD-, WEB-, VIS-, SEG-, SUB-, SOC-,
#    PLC-, FRM-, THM-. Acquisition Milestone, Nudge Delivery, Experiment Assignment, Promotion Enrollment and Tracking
#    Consent Choice use the composite keys of proposals_w2_engagement.KEY_FORMATS. Attribution Model is keyed by a model
#    code (Attribution Model ID, e.g. position_based_ms_v1), not a prefix.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED MEMBERSHIPS: 04 local lists that carry a shared list's exact name (value_map local value -> shared code).
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Business Line", "local": "Business Line",
     "value_map": {"DB": "DB", "DA": "DA", "HA": "HA", "PF": "PF", "WR": "WR", "IA": "IA", "IC": "IC", "TR": "TR"},
     "new_values": [],
     "note": "New member (CW-004): Campaign.Campaign Business Line and Campaign Targeting.Target Business Lines. Same codes "
             "and descriptions as the 02 and 15 copies."},
    {"shared": "Audience Restriction", "local": "Audience Restriction",
     "value_map": {"Public / Retail": "PUBLIC_RETAIL", "Financial Professional Use Only": "FINANCIAL_PROFESSIONAL_ONLY",
                   "Institutional Use Only": "INSTITUTIONAL_ONLY", "Client-Specific": "CLIENT_SPECIFIC",
                   "Internal Use Only": "INTERNAL_ONLY"},
     "new_values": [],
     "note": "Existing member, re-cut. Remove the value_map rows ('04', 'Audience Restriction', 'Professional Investors Only') "
             "(JURISDICTION, MiFID II) and ('04', 'Audience Restriction', 'Partner-Specific') (intermediary-only, CW-013). The "
             "steward (08) retires PROFESSIONAL_INVESTOR_ONLY and, if no other member uses it, PARTNER_SPECIFIC at the W5 shared-list "
             "re-cut; the shared source text still cites FCA COBS 4 and the ESMA guidelines. Until then the built workbook shows "
             "the seven wholesale values under 'Shared: Audience Restriction'."},
    {"shared": "Investor Category", "local": "Investor Category",
     "value_map": {"Retail": "RETAIL", "Institutional": "INSTITUTIONAL", "Financial Professional": "FINANCIAL_PROFESSIONAL"},
     "new_values": [],
     "note": "Existing member, re-cut to the 02 US values (CW-039). Replace the seven wholesale 04 value_map rows ('US Retail "
             "Investor', 'US Institutional Investor', 'US Financial Professional', three EU/UK values and 'Accredited Investor / "
             "Qualified Purchaser') with the three rows above. The EU/UK values are JURISDICTION entries; Accredited Investor / "
             "Qualified Purchaser is a qualification, not a communications audience (02 Investor Qualification), and is dropped."},
    {"shared": "Personal Data Category", "local": "Personal Data Category",
     "value_map": {"No Personal Data": "NONE", "Identity": "IDENTITY", "Contact": "CONTACT",
                   "Professional / Employment": "PROFESSIONAL_EMPLOYMENT", "Registration / Licensing": "REGISTRATION_LICENSING",
                   "HR / Employee": "HR_EMPLOYEE", "Financial": "FINANCIAL", "Government Identifier": "GOVERNMENT_IDENTIFIER",
                   "Online Identifiers / Engagement": "ONLINE_IDENTIFIERS_ENGAGEMENT",
                   "Inferences / Segmentation": "INFERENCES_SEGMENTATION", "Opinion About Individual": "OPINION_ABOUT_INDIVIDUAL",
                   "Free Text - May Contain Personal Data": "UNSTRUCTURED_MAY_CONTAIN"},
     "new_values": [],
     "note": "New member: Marketing System.Personal Data Categories Processed. Replaces the local Personal Data Classification "
             "(GDPR), which left with Record Metadata (CD-160; JURISDICTION)."},
    {"shared": "FINRA Communication Category", "local": "FINRA Communication Category", "value_map": {}, "new_values": [],
     "note": "Unchanged membership and values (steward 08)."},
    {"shared": "Social Platform", "local": "Social Platform", "value_map": {}, "new_values": [],
     "note": "Unchanged; 04 remains steward."},
    {"shared": "Delivery Status", "local": "Email Delivery Status", "value_map": {}, "new_values": [],
     "note": "Unchanged membership and values (steward 09)."},
    {"shared": "Sentiment", "local": "Sentiment", "value_map": {}, "new_values": [],
     "note": "Unchanged membership and values (steward 09)."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES (list name, member domains, note)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Communication Channel", ["02", "04", "13"],
     "The brief names it a shared candidate (steward 02). The adapted 04 no longer uses a list of this name (the wholesale copy "
     "was unused and held 'Paid Media Targeting'); Nudge Delivery now uses the 04 Marketing Channel (the local Nudge Channel "
     "was folded into it in the fix pass); 13 Service Channel and 04 Marketing Channel overlap with the 02 values."),
    ("Recommendation Risk Class", ["04", "08", "45"],
     "04 holds a Derived copy of the 08 determination per nudge (Pending Determination, Determined Not a Recommendation, "
     "Determined Recommendation, Advice Program Communication; CW-091). 08 should master the list (steward 08)."),
    ("Promotion Award Type", ["04", "47", "50"],
     "Award types map to 47 Fee Waiver Type (promotional waiver) and 50 money movement purpose (cash bonus); a shared mapping "
     "avoids divergent promotion reporting."),
    ("Acquisition Milestone Type", ["04", "06", "10"],
     "06 net new assets by campaign and 10 lifetime value by acquisition channel group by the same milestones (CW-085)."),
    ("Login Method / MFA Factor Type", ["04", "13", "41"],
     "13 Authentication Method (assisted service) and the 41 IAM policy hold similar authenticator values (CW-086); candidate "
     "shared list stewarded by 41."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (decisions.TERM_CONFLICTS format), from the brief's watchlist and what the draft found
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Profile",
     "usages": [("04", "Digital Profile (DIGP-)", "The client's online login profile."),
                ("02", "Investor Profile (INPR-)", "Versioned financial situation, objectives and risk tolerance."),
                ("02", "Privacy Profile", "Privacy regimes and opt-outs of a party.")],
     "recommendation": "Never write 'profile' bare: 'Digital Profile' (04), 'Investor Profile' and 'Privacy Profile' (02).",
     "resolution": "Qualified everywhere; no alias for bare 'profile'.", "status": "Resolved", "decision": "CW-086"},
    {"term": "Account",
     "usages": [("04", "Portal Account (retired)", "Wholesale login record, renamed Digital Profile."),
                ("15", "Account (ACC-)", "The client account.")],
     "recommendation": "'Account' means the 15 account only; the wholesale 'Portal Account' is retired (renamed Digital Profile).",
     "resolution": "Rename recorded in CW-904; readers listed in NOTES.", "status": "Resolved", "decision": "CW-904"},
    {"term": "Referral",
     "usages": [("04", "Client Referral (CRFL-)", "A client refers a friend; reward and marketing-rule disclosure."),
                ("03", "Channel Referral (RFRL-)", "Hand-off of a client between the firm's channels or to an advisor.")],
     "recommendation": "Always qualify: 'client referral' (04) or 'channel referral' (03).",
     "resolution": "Qualified (CW-092).", "status": "Resolved", "decision": "CW-092"},
    {"term": "Household",
     "usages": [("02", "Client Household (PTY-HH-)", "Audience criterion when an audience is built by household."),
                ("13", "Mailing Household (MHG-)", "Householding of mailings."),
                ("47", "Fee Household (FHHG-)", "Breakpoint aggregation.")],
     "recommendation": "04 builds household audiences from the 02 Client Household only; it never uses the 13 mailing household.",
     "resolution": "04 holds no household object.", "status": "Resolved", "decision": "CW-027"},
    {"term": "Program",
     "usages": [("04", "Promotion Offer / Client Referral", "Promotion and referral programs."),
                ("01", "Service Offering (OFFR-)", "Advice and service programs."),
                ("16", "Retirement plan", "Workplace plans.")],
     "recommendation": "04 never writes 'program' bare: 'promotion offer', 'referral', 'campaign (program level)'. Campaign Level "
                       "keeps the value 'Program' as the top of the campaign hierarchy (Salesforce usage).",
     "resolution": "Qualified; Campaign Level 'Program' kept.", "status": "SME", "decision": "CW-036"},
    {"term": "Event",
     "usages": [("04", "Marketing Event (EVT-)", "Seminar, webinar or client event."),
                ("04", "Engagement Event", "A digital behavioral event (page view, login, feature use)."),
                ("15", "Account Lifecycle Event (ALE-)", "Opening, re-registration, closure."),
                ("17", "Corporate action event", "Issuer event.")],
     "recommendation": "Bare 'event' resolves to 04 Marketing Event (existing alias); the others are always qualified.",
     "resolution": "Existing alias kept.", "status": "Resolved", "decision": "CW-904"},
    {"term": "Journey",
     "usages": [("04", "Application Journey (JRNY-)", "Digital application up to submission."),
                ("15", "Account Opening", "Application from receipt."),
                ("45", "Advice Engagement (ADENG-)", "Digital advice engagement after enrollment.")],
     "recommendation": "The journey ends at submission (CW-085); 'onboarding' means the 02 Onboarding Case.",
     "resolution": "Boundary stated in the definitions.", "status": "Resolved", "decision": "CW-085"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION (jurisdiction.REMOVALS entry format; CW-022, CW-904). EU/UK and other non-US content only. A whole removed
#    object or code list has attribute "". Re-sourced attributes record the EU/UK reference or example that was removed.
#    Intermediary-only removals (CE, sponsorship, intent data, advisor portal residue) are NOT jurisdiction items (brief §4a):
#    they are listed in SCOPE_REMOVALS below, in the same format but without a regime.
# ---------------------------------------------------------------------------------------------------------------------
_D, _C = "04", "CW-904"


def _j(obj, attr, regime, note):
    return {"domain": _D, "object": obj, "attribute": attr, "regime": regime, "decision": _C, "note": note}


JURISDICTION = [
    # Perspective text
    _j("META and overview", "Subtitle; Purpose; Primary / Secondary Reference; PII", "Other EU/UK",
       "'Asset manager (wholesale distributor) | Scope: US + EU/UK', FCA COBS 4, ESMA marketing guidelines and GDPR / PECR as "
       "drivers (FCA, ESMA, GDPR / UK GDPR). Rewritten to FINRA Rule 2210, Advisers Act Rule 206(4)-1, CAN-SPAM, the TCPA, "
       "FINRA Rule 3230, Reg BI, Reg S-P and the CCPA / CPRA; subtitle 'Wealth manager (direct) | Scope: US'."),
    # Objects
    _j("Access Gate", "", "FCA",
       "Investor-type and jurisdiction gate of a professional-investor website (2 attributes: Gate Type, Gate Declaration Text "
       "Version, example GATE-UK-PRO-v3), designed for FCA COBS 4 financial promotion restrictions. The US use (financial-"
       "professional-only and institutional-only content under FINRA Rule 2210) is kept as Web Page.Audience Gate with the "
       "Audience Gate Type list (fix pass ruling 5); only the FCA design and values leave."),
    _j("Self-Certification Record", "", "FCA",
       "Visitor self-certification as a professional investor (4 attributes: Declaring Visitor, Declared Country, Declared "
       "Investor Type, Declaration Timestamp) under FCA COBS 4.12A / 4.12B. No US equivalent for a direct retail firm."),
    # Attributes removed
    _j("Audience Restriction", "Marketing Communication Label Indicator", "Other EU/UK",
       "ESMA guidelines on marketing communications (ESMA34-45-1272) under Regulation (EU) 2019/1156 (regime: ESMA, cross-border "
       "distribution of funds). No US labeling requirement of this kind; FINRA Rule 2210 content standards are applied by 08."),
    # Code-list values removed
    _j("Code list: Audience Restriction", "Professional Investors Only", "MiFID II",
       "EU / UK professional clients and eligible counterparties."),
    _j("Code list: Investor Category", "EU/UK Retail Client", "MiFID II", "MiFID II / COBS 3 retail client; US Retail stays."),
    _j("Code list: Investor Category", "EU/UK Professional Client", "MiFID II", "MiFID II / COBS 3 professional client."),
    _j("Code list: Investor Category", "EU/UK Eligible Counterparty", "MiFID II", "MiFID II / COBS 3 eligible counterparty."),
    _j("Code list: Business Channel", "IFA / Wealth Manager", "UK market practice",
       "UK / EU independent financial adviser channel. The rest of the list is intermediary-only and left with Target Business "
       "Channels (SCOPE_REMOVALS)."),
    _j("Code list: CE Accrediting Body", "CII / PFS", "UK market practice", "UK CPD body; the list left with CE Accreditation."),
    _j("Code list: CE Accrediting Body", "CISI", "UK market practice", "UK CPD body; the list left with CE Accreditation."),
    # Whole code lists removed
    _j("Code list: Declared Investor Type", "", "FCA",
       "Individual / Retail Investor, Professional Investor / Adviser, Financial Professional (US), Institutional Investor, "
       "Investment Consultant; aligned to FCA COBS 4 / MiFID; left with Self-Certification Record."),
    _j("Code list: Gate Type", "", "FCA",
       "Jurisdiction Selector, Investor-Type Declaration, Login Required, Partner SSO, Form Fill (FCA COBS 4 gating); left with "
       "Access Gate."),
    _j("Code list: Personal Data Classification", "", "GDPR / UK GDPR",
       "No Personal Data, Pseudonymized Personal Data, Personal Data, Special Category Data (GDPR Art. 9); left with the "
       "excluded Record Metadata (CD-160). Replaced by the shared Personal Data Category (Marketing System.Personal Data "
       "Categories Processed) and the CD-344 special-category notes."),
    # Kept attributes re-sourced (the EU/UK reference or example removed)
    _j("Content Asset", "Publishing Entity", "FCA",
       "Secondary reference FCA COBS 4 and the note on entities permitted to communicate in each jurisdiction removed; re-sourced "
       "to FINRA Rule 2210(d)(3) (firm name in retail communications)."),
    _j("Audience Restriction", "Permitted Investor Categories", "FCA",
       "Secondary reference FCA COBS 4 removed; re-sourced to FINRA Rule 2210; EU/UK values removed (entries above)."),
    _j("Audience Restriction", "Permitted Jurisdictions", "Other EU/UK",
       "Secondary reference ESMA marketing guidelines, example 'GB; IE; LU; DE' and the cross-border notification note removed; "
       "re-sourced to FINRA Rule 2210, example US."),
    _j("Campaign Targeting", "Target Jurisdictions", "Other EU/UK",
       "Secondary reference ESMA marketing guidelines removed; re-sourced to FINRA Rule 2210."),
    _j("Asset Compliance Reference", "Performance Content Declared Indicator", "Other EU/UK",
       "Secondary reference ESMA marketing guidelines removed; re-sourced to FINRA Rule 2210 (with the SEC Marketing Rule primary)."),
    _j("Social Post", "Post Compliance Review", "FCA",
       "Secondary reference FCA COBS 4 (FG24/1 social media guidance) removed; re-sourced to FINRA Rule 2210."),
    _j("Web Visitor / Known User", "Applied Tracking Consent", "Other EU/UK",
       "Primary UK PECR and secondary GDPR (ePrivacy cookie consent; regime ePrivacy / PECR) removed; re-sourced to the CCPA / "
       "CPRA sale and sharing opt-out; the Tracking Consent Category list re-aligned from ePrivacy / PECR cookie categories."),
    _j("Web Form", "Privacy Notice Version", "GDPR / UK GDPR",
       "Primary reference GDPR and example PN-UK-2026-02 removed; re-sourced to the CCPA / CPRA notice at collection, example "
       "PN-US-2026-02."),
    _j("Event Registration", "Accessibility / Dietary Requirements", "GDPR / UK GDPR",
       "Secondary reference GDPR and the GDPR Art. 9 note removed; marked 'PII - may contain special category (CD-344)'."),
    _j("Engagement Score", "Engagement Score Party", "GDPR / UK GDPR",
       "Note citing GDPR Art. 21 objection rights removed; re-sourced to US state privacy laws on profiling (confirm)."),
    _j("Digital Property", "Property Name", "Other EU/UK",
       "Example 'Example Investments UK Professional Site' replaced by a US client app."),
    _j("Digital Property", "Primary Domain", "Other EU/UK", "Example https://www.example.com/uk/professional replaced."),
    _j("Digital Property", "Jurisdictions Served", "Other EU/UK", "Example 'GB; IE' replaced by US."),
    _j("Asset Rights", "Rights Usage Terms", "Other EU/UK", "Example 'US and UK only' replaced by 'US only'."),
    # Sources removed
    _j("Sources", "FCA Handbook COBS 4 (financial promotions) and FG24/1 (social media)", "FCA",
       "Re-sourced to FINRA Rule 2210 and Advisers Act Rule 206(4)-1."),
    _j("Sources", "ESMA Guidelines on marketing communications (ESMA34-45-1272) under Regulation (EU) 2019/1156", "Other EU/UK",
       "ESMA (cross-border distribution of funds). Re-sourced to FINRA Rule 2210."),
    _j("Sources", "GDPR / UK GDPR", "GDPR / UK GDPR", "Re-sourced to Regulation S-P, the CCPA / CPRA and CD-344."),
    _j("Sources", "ePrivacy Directive / UK PECR", "Other EU/UK",
       "ePrivacy / PECR cookie and electronic marketing consent. Re-sourced to the CCPA / CPRA, Global Privacy Control, CAN-SPAM "
       "and the TCPA."),
    _j("Sources", "CASL (Canada's Anti-Spam Legislation)", "Other non-US",
       "Canada; noted in the wholesale only in case Canadian advisors were targeted."),
]

# Intermediary-only and other scope removals of CW-904 (CW-013, CD-160, CW-083, CW-085): same keys as REMOVALS, regime "".
# Not for jurisdiction.REMOVALS; recorded here for the W2 merge notes and the baseline check.
def _s(obj, attr, basis, note):
    return {"domain": _D, "object": obj, "attribute": attr, "regime": "", "decision": _C, "basis": basis, "note": note}


SCOPE_REMOVALS = [
    _s("CE Accreditation", "", "CW-013", "Advisor continuing-education accreditation (4 attributes). Lever: restore from the sibling (SME question 6)."),
    _s("CE Credit Issued", "", "CW-013", "CE credits issued to external advisors (4 attributes)."),
    _s("Event Sponsorship", "", "CW-013", "Distributor conference sponsorship (3 attributes; 05 payment terms)."),
    _s("Third-Party Intent Signal", "", "CW-013", "B2B intent data on advisor firms (Bombora; 4 attributes)."),
    _s("Campaign Performance Snapshot", "", "CW-904", "Stored campaign metrics (5 attributes); products compute them (DP-025) and 21 governs metric definitions."),
    _s("Record Metadata", "", "CD-160", "Excluded governance metadata (8 attributes; modeled once in 21)."),
    _s("Campaign Member", "Added By Salesperson", "CW-013", "Wholesaler nomination; no successor."),
    _s("Event Registration", "Gifts & Entertainment Record", "CW-013", "FINRA Rule 3220 covers gifts to other firms' employees, not retail clients."),
    _s("Audience Restriction", "Partner-Specific Restriction", "CW-013", "Distributor-specific material; value Partner-Specific also dropped from the local list."),
    _s("Campaign Targeting", "Target Territories", "CW-013", "07 territories retire (W4); targeting by business line and audience instead."),
    _s("Campaign Targeting", "Target Business Channels", "CW-004", "Distribution channels; replaced by Target Business Lines and Target Segments."),
    _s("Marketing Lead", "Captured CRD Number", "CW-013", "Advisor lead matching; consumer leads have no CRD."),
    _s("Lead Assignment", "Assigned Territory", "CW-013", "07 territories retire; routing by 03 coverage rules."),
    _s("Portal Account", "Verified Professional Indicator", "CW-013", "Advisor-portal professional verification."),
    _s("Portal Account", "Portal User ID", "CW-086", "Login name; replaced by Digital Profile ID (never the login name or a credential)."),
    _s("Lead Conversion", "Converted Opportunity", "CW-083", "03 opportunities retire; replaced by Converted Party and Resulting Application Journey."),
    _s("Attributed Outcome", "Attributed Opportunity", "CW-085", "Replaced by Attributed Milestone."),
    _s("Attributed Outcome", "Attributed Flow Record", "CW-085", "Replaced by Attributed Milestone; 06 applies the weights to flows."),
    _s("Code list: Business Channel", "", "CW-004", "Wirehouse, regional / independent broker-dealer, RIA, bank / trust, private bank, platform, insurance, consultant, DCIO (left with Target Business Channels)."),
    _s("Code list: CE Accrediting Body", "", "CW-013", "Left with CE Accreditation (UK values in JURISDICTION)."),
    _s("Code list: CE Subject Area", "", "CW-013", "Left with CE Accreditation."),
    _s("Code list: CE Reporting Status", "", "CW-013", "Left with CE Credit Issued."),
    _s("Code list: Sponsorship Tier", "", "CW-013", "Left with Event Sponsorship."),
    _s("Code list: Intent Provider", "", "CW-013", "Left with Third-Party Intent Signal."),
    _s("Code list: Opt-In Status", "", "CW-084", "Unused in the wholesale 04; 02 masters the list."),
    _s("Code list: Opt-In Method", "", "CW-084", "Unused in the wholesale 04."),
    _s("Code list: Opt-Out Source", "", "CW-084", "Unused in the wholesale 04."),
    _s("Code list: Communication Channel", "", "CW-084", "Unused in the wholesale 04; 02 holds the list."),
    _s("Code list: Data Quality Status", "", "CD-160", "Left with Record Metadata."),
    _s("Code list: Nudge Channel", "", "CW-904", "Fix pass: folded into Marketing Channel (Nudge Delivery.Delivery Channel)."),
    _s("Code list: Email Send Type", "Advisor-Sent Marketing", "CW-904", "Fix pass: a sender, not a CAN-SPAM nature; advisor-sent marketing email is Commercial (channel Advisor-Delivered)."),
    _s("Promotion Enrollment", "Award Money Movement", "CW-092", "Fix pass: 50 Money Movement (MMVMT-) holds the link to the enrollment."),
    _s("Code list: Outcome Type", "", "CW-085", "Merged into Acquisition Milestone Type (Outcome Type attribute kept)."),
    _s("Code list: Investor Category", "Accredited Investor / Qualified Purchaser", "CW-039", "A qualification (02 Investor Qualification), not a communications audience."),
    _s("Sources", "CFP Board Continuing Education policies and CE sponsor resources", "CW-013", "Left with CE."),
    _s("Sources", "Investments & Wealth Institute CE sponsor program (CIMA / CPWA / RMA)", "CW-013", "Left with CE."),
    _s("Sources", "Bombora Company Surge", "CW-013", "Left with intent data."),
    _s("Sources", "DCAM", "CD-160", "Cited only by Record Metadata."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. REPOINTS (object, attribute, before, after, decision)
# ---------------------------------------------------------------------------------------------------------------------
REPOINTS = [
    ("Portal Account", "", "Object Portal Account (wholesale advisor and client portal login)", "Object Digital Profile (DIGP-; re-cut: Digital Profile ID, Digital Profile Party, Digital Profile Status, MFA Factors Enrolled, Biometric Login Enabled Indicator, Last Login Timestamp)", "CW-086"),
    ("Digital Profile", "Digital Profile Party", "Portal Account Party", "Digital Profile Party (Reference (Party), 02)", "CW-086"),
    ("Event Registration", "Invited By Advisor", "Invited By Salesperson: Reference (Employee), wholesaler", "Invited By Advisor: Reference (Advisor, 03), own advisor (EMP- key, override 03)", "CW-904"),
    ("Lead Assignment", "Assigned Advisor", "Assigned Salesperson: Reference (Employee), routed by 07 territory", "Assigned Advisor: Reference (Advisor / Coverage Team, 03), routed by 03 coverage rules", "CW-904"),
    ("Lead Assignment", "First Sales Activity", "03 Sales Activity (ACT-)", "03 Advisor Activity (ACT- kept); name kept for readers", "CW-904"),
    ("Lead Conversion", "Converted Party", "Converted Opportunity (03 OPP-)", "Converted Party (02 PTY-, Relationship Stage Prospect) and Resulting Application Journey (04 JRNY-)", "CW-083"),
    ("Attributed Outcome", "Attributed Milestone", "Attributed Opportunity (03 OPP-) and Attributed Flow Record (06 TXN-)", "Attributed Milestone (04 Acquisition Milestone) and Applied Attribution Model", "CW-085"),
    ("Attributed Outcome", "Attributed Amount", "Mastered amount (Salesforce influence)", "Derived copy of 06 net new assets by campaign (W4)", "CW-085"),
    ("Campaign Product", "Campaign Product / Share Class", "Reference (Product / Share Class)", "Reference (Product / Share Class / Service Offering), accepts 01 OFFR-", "CW-904"),
    ("Marketing Theme", "Theme Strategies / Products", "Reference (Strategy / Product)", "Reference (Strategy / Product / Service Offering)", "CW-904"),
    ("Campaign", "Co-Marketing Agreement", "Distributor co-marketing (05)", "Intermediary channel (IC) only; 05 at W4", "CW-013"),
    ("Asset Compliance Reference", "Compliance Review Reference; Approval Status (Mirrored)", "08 Distribution Compliance", "08 Retail Conduct & Supervision (REV- kept)", "CW-904"),
    ("Web Visitor / Known User", "Matched Party", "Matched to any party (advisor, gatekeeper, investor)", "Matched at the CW-083 identity threshold; 02 creates the Prospect party", "CW-083"),
    ("Email Interaction", "Unsubscribe Timestamp", "Flows to Communication Preference (04 wholesale wording)", "Written to 02 Communication Preference within 10 business days, evidenced by Unsubscribe Written Back Timestamp", "CW-084"),
    ("Marketing System", "", "Family Marketing Data Management (MK-DMM)", "Family Digital Properties & Martech (MK-WEB); object name unchanged", "CW-904"),
    ("Asset Compliance Reference", "Performance Content Declared Indicator", "Performance Content Indicator (mastered flag)", "Submitter's declaration; 08 Compliance Review masters the classification", "CW-904"),
    ("Asset Compliance Reference", "Hypothetical Performance Declared Indicator", "Hypothetical Performance Indicator", "Submitter's declaration; 08 masters", "CW-904"),
    ("Asset Compliance Reference", "Testimonial / Endorsement / Rating Declared Indicator", "Testimonial / Endorsement / Rating Indicator", "Submitter's declaration; 08 masters", "CW-904"),
    ("Promotion Enrollment", "Award Money Movement", "Reference (Money Movement, 50), MMT- example", "Dropped; 50 Money Movement (MMVMT-) references the Promotion Enrollment", "CW-092"),
    ("Content Asset", "Publishing Entity", "Reference (Party) PTY-, override to 09", "Reference (Internal Legal Entity) LEN- (09); override removed", "CW-904"),
    ("Families", "", "Events & Continuing Education; Digital Properties; Audiences, Subscriptions & Preferences; Lead Management; Marketing Data Management", "Client Events & Webinars; Digital Properties & Martech; Audiences, Subscriptions & Suppression; Leads & Acquisition Funnel; (MK-DMM dropped); new Personalization & Experiments (MK-PEX) and Referrals, Promotions & Voice of Client (MK-PRO)", "CW-904"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. DECISIONS: the US-only pass and wealth adaptation of 04 (pre-allocated CW-904, CW-022)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-904", "theme": "Scope", "title": "04 Marketing, Digital & Client Engagement: US-only pass and wealth-manager adaptation",
     "domains": ["04", "02", "03", "06", "08", "13", "15", "45", "47", "50"],
     "issue": "The wholesale 04 Marketing & Digital marketed funds B2B2C to financial advisors, gatekeepers and consultants in the "
              "US and the EU/UK (FCA COBS 4 and ESMA guidelines, GDPR / PECR, professional-investor gating, CE credits, "
              "sponsorships, intent data, territory routing, opportunity and flow attribution) and had no home for the direct "
              "client's digital login, application journey, acquisition milestones, nudges, experiments, promotions, referrals "
              "or surveys (CW-083 to CW-086, CW-091 to CW-094).",
     "resolution": "Title 'Marketing, Digital & Client Engagement'; subtitle 'Wealth manager (direct) | Scope: US'; L1 code MK, "
                   "folder and output path kept. "
                   "Removed, jurisdiction (33 JURISDICTION entries: 2 objects, 1 attribute, 7 code values, 3 whole code lists, 5 "
                   "sources, 14 re-sourced attributes and the perspective text): objects Access Gate and Self-Certification Record "
                   "(FCA COBS 4); attribute Audience Restriction.Marketing Communication Label Indicator (ESMA); values Professional "
                   "Investors Only, the three EU/UK investor categories, IFA / Wealth Manager, CII / PFS and CISI; lists Declared "
                   "Investor Type, Gate Type and Personal Data Classification; sources FCA COBS 4 / FG24/1, ESMA34-45-1272, GDPR, "
                   "ePrivacy / PECR and CASL. "
                   "Removed, scope (not jurisdiction; SCOPE_REMOVALS): objects CE Accreditation, CE Credit Issued, Event "
                   "Sponsorship, Third-Party Intent Signal (CW-013) and Campaign Performance Snapshot (stored metrics; DP-025 "
                   "computes them), Record Metadata (CD-160); attributes Campaign Member.Added By Salesperson, Event Registration."
                   "Gifts & Entertainment Record, Audience Restriction.Partner-Specific Restriction, Campaign Targeting.Target "
                   "Territories and Target Business Channels, Marketing Lead.Captured CRD Number, Lead Assignment.Assigned "
                   "Territory, Portal Account.Verified Professional Indicator and Portal User ID, Lead Conversion.Converted "
                   "Opportunity, Attributed Outcome.Attributed Opportunity and Attributed Flow Record; the CE, sponsorship, intent, "
                   "Business Channel, opt-in and Data Quality Status lists; the CFP Board, IWI, Bombora and DCAM sources. "
                   "Fix pass (2026-10-15, program-lead rulings): the three Marketing Rule flags renamed Performance Content Declared "
                   "Indicator, Hypothetical Performance Declared Indicator and Testimonial / Endorsement / Rating Declared Indicator "
                   "(the submitter's declaration; 08 masters the determination); FINRA Communication Category and Recommendation "
                   "Risk Class declared Derived copies of 08, the latter re-cut to Pending Determination, Determined Not a "
                   "Recommendation, Determined Recommendation and Advice Program Communication, with Linked Recommendation "
                   "mandatory for Determined Recommendation; Award Money Movement dropped (50 holds the link, MMVMT-); added "
                   "Referral Reward Enrollment, Offer Start Date, Offer End Date, Award Value, Promotion Campaign, Session Visitor, "
                   "Event Session, Revoked Consent Record and Web Page.Audience Gate (US replacement of Access Gate); list Referral "
                   "Status renamed Referral Program Status; Nudge Channel folded into Marketing Channel; Email Send Type loses "
                   "Advisor-Sent Marketing; Publishing Entity typed Reference (Internal Legal Entity) with LEN-; co-marketed IC "
                   "pieces use Financial Professional Use Only plus the Co-Marketing Agreement (no Partner-Specific value). "
                   "Kept and re-sourced to US rules: Publishing Entity (FINRA Rule 2210(d)(3)), Permitted Investor Categories and "
                   "Permitted Jurisdictions, Target Jurisdictions, Performance Content Declared Indicator and Post Compliance Review (FINRA "
                   "Rule 2210, Advisers Act Rule 206(4)-1), Applied Tracking Consent and the Tracking Consent Category list (CCPA / "
                   "CPRA), Privacy Notice Version (CCPA notice at collection), Accessibility / Dietary Requirements (CD-344), "
                   "Engagement Score Party (state privacy law), Suppression Reason (CAN-SPAM, TCPA, FTC Telemarketing Sales Rule, "
                   "FINRA Rule 3230), US examples throughout; Investor Category re-cut to Retail, Institutional, Financial "
                   "Professional (CW-039). "
                   "Renamed: object Portal Account to Digital Profile (DIGP-, CW-086) with Portal Account Party to Digital Profile "
                   "Party; Event Registration.Invited By Salesperson to Invited By Advisor; Lead Assignment.Assigned Salesperson to "
                   "Assigned Advisor (advisor or coverage team, 03); families Events & Continuing Education to Client Events & "
                   "Webinars, Digital Properties to Digital Properties & Martech, Audiences, Subscriptions & Preferences to "
                   "Audiences, Subscriptions & Suppression, Lead Management to Leads & Acquisition Funnel; Marketing System moves to "
                   "MK-WEB and MK-DMM is dropped. Attribute IDs renumber inside every touched family (positional IDs); readers read "
                   "by name. Every other kept object and attribute name is unchanged. "
                   "Added to kept objects: Campaign Business Line; Target Business Lines, Target Segments; Personal Data Categories "
                   "Processed (shared Personal Data Category); Digital Profile ID, Digital Profile Status, MFA Factors Enrolled, "
                   "Biometric Login Enabled Indicator, Last Login Timestamp; Session Login Method; Digital Feature Used, Event "
                   "Application Journey, Exposed Experiment; Unsubscribe Written Back Timestamp; Score As-Of Date; Registry Scrub "
                   "Date; Converted Party, Resulting Application Journey; Attribution Model ID; Attributed Milestone, Applied "
                   "Attribution Model. Attributed Amount becomes a Derived copy of 06. "
                   "Added objects (CW-083 to CW-086, CW-091 to CW-093): Tracking Consent Choice, Application Journey (JRNY-), "
                   "Acquisition Milestone, Nudge Definition (NUDG-), Nudge Delivery, Experiment (EXPMT-), Experiment Assignment, "
                   "Promotion Offer (PROMO-), Promotion Enrollment, Client Referral (CRFL-), Client Survey (CSVY-), Survey Response "
                   "(SRSP-); families Personalization & Experiments (MK-PEX) and Referrals, Promotions & Voice of Client (MK-PRO). "
                   "Result: 12 families, 61 objects, 318 attributes, 106 CDEs (33.3%), 83 code lists, 59 relationships, 28 sources; "
                   "band 290 to 320 (program-lead ruling).",
     "rationale": "The wealth model is US only (CW-003) and direct (CW-001, CW-013); foreign-address clients and foreign "
                  "visitors stay (Permitted Jurisdictions, Target Jurisdictions). Kept names keep Campaign, Content Asset, "
                  "Digital Property, Marketing Event, Social Listening Mention and Subscription Topic resolving for 02, 03, 08, 23, "
                  "42 and 44 (CW-021 by analogy). Lever: a firm with an EU/UK or advisor-marketing business restores the removed "
                  "items from the jurisdiction register and the wholesale sibling.",
     "action": "W2 (04); W2 merge (jurisdiction.REMOVALS, shared lists, prefixes, readers)", "status": "Proposed",
     "priority": "High", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 8. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    # Readers of removed or renamed 04 content. Lines as of 2026-10-14, checked by grep.
    "READERS - LIVE. DP-011 Marketing Engagement, data_products/specs_b_foundational.py 226-302: inputs Campaign Member.Added "
    "By Salesperson (line 263, removed: drop), Event Registration.Invited By Salesperson (line 276, renamed Invited By Advisor), "
    "CE Credit Issued (line 277, removed: drop the input, business question line 235, definition line 228, the CE clause of the "
    "DQ rule line 294); notes line 300 cite GDPR / PECR (text: re-word to CCPA / CPRA). DP-011 keeps Applied Tracking Consent "
    "(kept, re-sourced). Model data_models/models_f3.py: CE Credit Issued entity 78-81, relationship 125-127, notes 145 and 166-168; "
    "Salesperson joins on Added By Salesperson and Invited By Salesperson 134-136 and note 152. Semantic model "
    "semantic_model/models/sm_05_marketing.py: event_registration hidden or listed Invited By Salesperson (57), ce_credit fact "
    "(58-63). DP-075: specs_i_product_data.py 489 and 518 read Marketing System.System Name and System Category (kept; the object "
    "moved family, products read by object). DP-002 lost Digital Profile at W1 (specs_a_foundational.py 182): 04 Digital "
    "Profile is its successor for WP0.",
    "READERS - PENDING (CW-041, re-cut at WP0). DP-025 specs_d_marketing_product.py 31-46, 64, 74, 76, 90 (Campaign Performance "
    "Snapshot, Target Business Channels, Attributed Opportunity, Attributed Flow Record, Outcome Type values); model "
    "models_c2_marketing_product.py 49-57, 74, 111-114, 130-132, 144; sm_05_marketing.py 101 (campaign_snapshot), 109-113. "
    "DP-026 specs_d_marketing_product.py 161-173 (Theme Strategies / Products: kept, type widened). DP-027 "
    "specs_d_marketing_product.py 233-235, 265-266, 289-291 (Assigned Salesperson renamed Assigned Advisor; Assigned Territory and "
    "Converted Opportunity removed; Conversion Outcome values re-cut); models_c2_marketing_product.py 244, 257-258, 285-286. "
    "DP-046 specs_g_advisor_analytics.py 25, 71 (Partner-Specific Restriction). DP-051 specs_k_events_institutional.py 30-149 "
    "(Event Sponsorship, CE Accreditation, CE Credit Issued, Invited By Salesperson, Gifts & Entertainment Record, Attributed Flow "
    "Record); models_c9_events_inst_intel.py 32-37, 59-61, 81, 134-143, 158-160, 179, 197-201; sm_05_marketing.py 236-245, 677. "
    "DP-052 specs_g_advisor_analytics.py 396-427 (Third-Party Intent Signal, Portal Account, Verified Professional Indicator, "
    "Portal User ID); models_c5_advisor_privacy.py 583-584, 612, 657, 672. DP-053 specs_g_advisor_analytics.py 507 (Invited By "
    "Salesperson); models_c5_advisor_privacy.py 761. DP-054 specs_h_planning_partners.py 161 (Target Territories). DP-087 "
    "specs_m_clients_privacy_digital.py 249-336 (Access Gate, Self-Certification Record, Declared Investor Type, Portal Account, "
    "Verified Professional Indicator, Portal User ID): retire or re-cut to Digital Profile and Tracking Consent Choice; model "
    "models_c2_marketing_product.py 653-714. DP-090 specs_m_clients_privacy_digital.py 389-409 (Messaging Compliance Review and "
    "Theme Strategies / Products: kept). Key registry data_models/keys_g2_03_04_05.py 85, 102, 106-107, 114, 118-119, 137, 140, 145, "
    "162-164, 335-397 (superseded at WP2). Semantic model SM-05 (sm_05_marketing.py) is pending.",
    "Renames for the baseline check (check_baseline reports renamed products without failing, per the W1b merge): object Portal "
    "Account -> Digital Profile; Portal Account.Portal Account Party -> Digital Profile.Digital Profile Party; Event Registration."
    "Invited By Salesperson -> Invited By Advisor; Lead Assignment.Assigned Salesperson -> Assigned Advisor. "
    "data_products/_catalog.txt (generated) still names the old attributes and families.",
    "Concept register: add CONCEPT_OWNERSHIP rows (owner 04) for Digital Profile (DIGP-), Application Journey (JRNY-), "
    "Acquisition Milestone, Nudge Definition (NUDG-), Experiment (EXPMT-), Promotion Offer (PROMO-), Client Referral (CRFL-), "
    "Client Survey (CSVY-), Survey Response (SRSP-); and the eight prefixes of proposals_w2_engagement.PREFIXES. Until then 04 "
    "references its own new objects as 'Reference (<Object>, 04)'. EXPMT- and PROMO- have five letters: the resolver reads "
    "prefixes of two to five letters, so they resolve once registered.",
    "Ownership overrides in enrich_04.py: Invited By Advisor and Assigned Advisor are forced to 03 (the advisor is keyed by the "
    "20 EMP-; the 03 brief's Advisor object); Attributed Milestone is forced to 04 (its composite key starts with PTY-). When 03 "
    "registers an Advisor concept the first two can stay.",
    "For the 02 owner at the W2 merge (CW-084, CW-094): 02 Communication Preference.Preference Topic keeps reading 04 SUB-; the "
    "Digital Engagement Segment scheme, if kept, is a Derived copy of 04 Engagement Score; the 02 Privacy Profile Sale / Sharing "
    "Opt-Out Indicator is written from 04 Tracking Consent Choice once the visitor is matched.",
    "For the 13 drafter: Survey Response.Triggering Interaction references 13 Contact Center Interaction (CCI-); the Promotion "
    "Enrollment 1099-MISC flag expects a 13 Tax Form Record of type 1099-MISC to hold the link (not modeled in 04).",
    "MERGE ITEM for the lead (45): add a Recommendation Source value 'Digital Nudge' to the 45 Recommendation Source list "
    "(content_45 line 467), for recommendations delivered by a 04 nudge Determined Recommendation (fix pass ruling 4). "
    "For the 45 drafter: Nudge Delivery.Linked Recommendation references 45 Recommendation (RECOM-) and is mandatory for "
    "Determined Recommendation nudges; Application Journey of type "
    "Digital Advice Enrollment hands off to the 45 Advice Engagement (ADENG-) through the 15 account and 02 onboarding case; no "
    "direct reference is held in 04 (size).",
    "For 06 at W4: Attributed Outcome.Attributed Amount is declared a Derived copy of 06 (net new assets by campaign); 06 reads "
    "Attribution Weight, Applied Attribution Model and Attributed Milestone. For 50 at W3: the 04 side no longer holds Award "
    "Money Movement; the 50 Money Movement (MMVMT-) references Promotion Enrollment (50 brief rows 67 and 160), and the REL row "
    "'Promotion Enrollment is paid by Money Movement [50]' says 50 holds the link. Acquisition Milestone dates for Account "
    "Funded, Rollover Completed and Recurring Investment Set Up become Derived copies of 50 (ROW_OWNERSHIP).",
    "References to domains replaced or retired later, left as they are: Campaign.Co-Marketing Agreement (05 AGR-, replaced at "
    "W4; content_04 line 63 area, family MK-CAM); Lead Assignment.First Sales Activity (03 ACT-, re-cut in the W2 03 as Advisor "
    "Activity with ACT- kept). No 07 or 30 references remain.",
    "Size (fix pass): 318 attributes, within the band of 290 to 320 set by the program-lead ruling (the brief said 260 to 295). "
    "The wholesale built 253; removals take 39 (26 in removed objects, 13 attributes), leaving 214; additions are 104. Promotions "
    "and referrals stay in scope. For a firm that runs no promotions or referrals, the lever is -23 (Promotion Offer 10, "
    "Promotion Enrollment 6, Client Referral 7), to 295.",
    "Code lists: 83 used (75 local, 8 shared), above the brief's 50-60 local: the 16 new lists the brief names plus Tracking Choice "
    "Source, Digital Profile Status, Journey Status, Audience Gate Type, Suppression Check Result, Nudge Response, Promotion Enrollment "
    "Status, Survey Trigger and the Business Line and Personal Data Category copies. Outcome Type was merged into Acquisition "
    "Milestone Type.",
    "Fix pass readers of the renamed Marketing Rule flags: DP-062 (pending) data_products/specs_j_compliance_2.py 267 "
    "(Performance Content Indicator), 278 (Hypothetical Performance Indicator), 318-319 (input list with all three) and 338 "
    "(DQ rule): re-point to the '... Declared Indicator' names or, better, to the 08 Compliance Review classification.",
    "07 and 30 retirement (CW-907, CW-930; W4_Retirement_of_07_and_30.md section 5): grep of content_04 and enrich_04 for 07 "
    "(Compensation & Territory: TER-, CVA-, CPS-, ICP-, territory, crediting) and 30 (Private Markets: PDL-, deal, commitment, "
    "capital call, carried interest) finds no remaining object, list or prefix; Target Territories and Assigned Territory were "
    "already removed (SCOPE_REMOVALS) and the Content Topic value Alternatives / Private Markets was dropped in the adapt. No "
    "edit was needed in the fix pass.",
    "Code list 'Referral Status' renamed 'Referral Program Status' in place (03 holds 'Referral Status' for Channel Referral); "
    "no LOCAL_RENAMES entry is needed.",
    "NPS Category: 12 holds an identical list (content_12 line 517); 12 retires its Client Feedback to 04 Survey Response "
    "(CW-093), so the 12 copy goes when 12 is rewritten at W4.",
    "For 08: the Nudge, Promotion and Messaging Compliance Review references point at the review of the content asset that "
    "carries the nudge, offer terms or message; the review of a nudge's targeting and trigger is a subject the 08 Compliance "
    "Review does not yet cover (08 owner to decide).",
    "For the W2 merge note: until the W5 shared-list re-cut, the built 04 workbook shows the wholesale values of the shared "
    "Audience Restriction and Investor Category (Professional Investors Only, Partner-Specific, Professional, Eligible "
    "Counterparty) with FCA / MiFID source text; do not hand it to an SME as US-clean before W5.",
    "LOCAL_RENAMES ('04', 'Registration Status', 'Event Registration Status', ...) stays valid (list name unchanged).",
    "Shared Audience Restriction and Investor Category still hold EU/UK values until the W5 re-cut; built workbooks show them.",
    "Value re-cuts (not recorded value by value): Audience Type, Campaign Type, Campaign Objective, Marketing KPI, Marketing "
    "Channel (Advisor Portal, Trade Media, Sales-Delivered out; Mobile App, Push, Connected TV, Workplace Plan Communications, "
    "Advisor-Delivered in), Spend Category (Sponsorship Fee out), Content Type (Sales Kit / Advisor Toolkit, Client-Approved "
    "Template out), Content Topic, Event Type (Due Diligence Forum, Study Group, Roadshow, sponsoring conferences out), Property "
    "Type (Advisor Portal, Partner Syndication out), Form Purpose, Identity Namespace, Identity Match Method (Partner SSO out), "
    "Engagement Event Type, Email Send Type (Sales-Sent Marketing to Advisor-Sent Marketing), Segment Type (ABM out), "
    "Subscription Category, Suppression Reason (National Do Not Call Registry, Firm-Specific Do-Not-Call, TCPA Consent Revoked, "
    "Reassigned Number added), Suppression Scope (Brand to Business Line), Lead Type, Lead Source, Lead Status (SAL / SQL to "
    "Accepted), Lifecycle Stage, Disqualification Reason, Conversion Outcome, Social Account Type, Paid Media Channel, Ad Format, "
    "Touchpoint Type, Martech System Category (Intent Data Provider out).",
]
