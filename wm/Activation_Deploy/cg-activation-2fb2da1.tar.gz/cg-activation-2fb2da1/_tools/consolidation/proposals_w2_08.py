"""Consolidation proposals from Data Domain 08 - Retail Conduct & Supervision (wealth model W2 draft v0.1, 2026-10-14).

Proposal fragment only: the builder does not read it. The program lead merges accepted entries into decisions.py,
shared_code_lists.py and jurisdiction.py at the W2 merge. Format follows CONTRACT.md in this folder (DECISIONS dict format,
PREFIXES tuple format, the jurisdiction.py REMOVALS entry format). The brief names this file proposals_08.py; the
assignment named it proposals_w2_08.py, which is used. The 08 drafter implemented CW-015, CW-021, CW-066 to CW-074,
CW-078 and CW-079 (proposals_w2_conduct.py) as accepted.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones: none. The draft uses only the reserved PRNR-, SCEN-, CORAC-, BRIN-, SFND-, HSPL-,
#    SNRC- and the kept REV-, CPL-, LIC-, GNE-, ARC-, SURV-, SPA-, FTC-. Composite keys follow KEY_FORMATS of
#    proposals_w2_conduct.py; two more composite keys are used (no prefix): Approved Communication Channel
#    (EMP- or firm channel / platform / approval effective from) and Disclosure Event (LIC- / event number).
#    RET- is referenced (21, CW-068), never defined; DDQ- is not used (held for 05 at W4).
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

KEY_FORMATS = [
    ("Approved Communication Channel", "Composite: EMP- (advisor account) or firm channel name / platform / approval effective from", "e.g. EMP-20417 / LinkedIn / 2026-01-12"),
    ("Disclosure Event", "Composite: EMP- / event number (per person; the registration link is optional)", "e.g. EMP-20417 / event 03"),
    ("Incentive Conflict Review", "Composite: ICP- component or RECG- recognition award / review date", "e.g. RECG-2026-00218 / 2026-02-20"),
    ("Exam Result", "Composite: EMP- / exam code / attempt sequence", "e.g. EMP-20417 / Series 66 / 1"),
    ("Supervisory Control Test", "Composite: POLCY- / control number / test period end", "e.g. POLCY-0204 / control 014 / 2026-06-30"),
    ("Registration Filing", "Composite: EMP- / form type / filing date", "e.g. EMP-20417 / U4 Amendment / 2026-05-02"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local lists in 08 carrying the exact name and (US) values of an enterprise shared list.
#    (local list name in 08, shared list name, note). VALUE_MAPS gives local label -> shared code.
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    # Kept memberships (08 is already a member)
    ("FINRA Communication Category", "FINRA Communication Category", "Keep ('08', ...); steward 08. Values unchanged."),
    ("Qualification Exam", "Qualification Exam", "Keep; steward 08. Adds Series 4 (Registered Options Principal) and Series 51 (MSRB municipal fund securities limited principal) as new shared values SERIES_4 and SERIES_51; Series 9 / 10 now used."),
    ("Approval Status", "Approval Status", "Keep (Compliance Approval, Review Step Outcome)."),
    ("G&E Approval Status", "Approval Status", "Keep (G&E Approval)."),
    ("Frequency", "Frequency", "Keep; Daily, Weekly and On Event now used."),
    ("Severity", "Severity", "Keep (Supervisory Finding)."),
    ("Social Platform", "Social Platform", "Keep (Approved Communication Channel); Threads now used."),
    # New memberships
    ("Case Status", "Case Status", "New member: Conduct Corrective Action, Supervisory Finding, Surveillance Alert review status, Complaint Status and Senior Investor Case Status (replaces the wholesale local Alert Review Status, Remediation Status and Complaint Status, and the draft Senior Case Status; fix pass)."),
    ("Record Status", "Record Status", "New member: Surveillance Scenario, Supervisory Control."),
    ("Regulator", "Regulator", "New member: FINRA Advertising Filing.Filing Regulator (replaces the wholesale local Regulator Filing Type and the Other Regulator Filing party reference); FINRA, SEC, state securities regulator, MSRB."),
    ("Investor Category", "Investor Category", "New member (steward 02): Compliance Review.Intended Audience uses the communications-audience subset Retail, Institutional, Financial Professional (replaces the wholesale local Audience Category)."),
    ("Flow Direction", "Flow Direction", "New member (steward 06): Gift / Entertainment Item.Direction, Inflow = received, Outflow = given (replaces the wholesale local Benefit Direction; fix pass)."),
    ("Performance Fee Basis", "Performance Fee Basis", "New member (steward 12): Performance Presentation.Gross / Net Presentation (replaces the wholesale local Gross Net Presentation)."),
]

# Memberships to REMOVE for 08 at merge: lists retired or no longer used by the replacement.
MEMBERSHIPS_REMOVE = [("08", "MiFID Client Category"), ("08", "Distribution Strategy"), ("08", "Investor Qualification Standard"),
                      ("08", "Data Quality Status"), ("08", "Screening Result"), ("08", "Risk Rating"), ("08", "RAG Status"),
                      ("08", "Delivery Method")]
# Screening Result and Audience Restriction: 08 stays steward (brief section 8) with no local member (no screening or audience
# restriction attribute in the replacement; 04 Content Asset holds Audience Restriction, and 29 and 40 are direct users of
# Screening Result). Audience Restriction re-cut (CW-039): drop PROFESSIONAL_INVESTOR_ONLY and PARTNER_SPECIFIC at W4.
# Risk Rating, RAG Status and Delivery Method left with the Distributor Due Diligence objects (05 at W4) and the dropped
# Distribution Chain Information Exchange and Outcome Metric; re-register for 05 at W4 if its brief keeps them.

VALUE_MAPS = {   # 08 local label -> shared code
    "FINRA Communication Category": {"Retail Communication": "RETAIL_COMMUNICATION", "Institutional Communication": "INSTITUTIONAL_COMMUNICATION", "Correspondence": "CORRESPONDENCE"},
    "Qualification Exam": {"SIE": "SIE", "Series 4": "SERIES_4", "Series 6": "SERIES_6", "Series 7": "SERIES_7", "Series 9 / 10": "SERIES_9_10", "Series 24": "SERIES_24", "Series 26": "SERIES_26", "Series 51": "SERIES_51", "Series 63": "SERIES_63", "Series 65": "SERIES_65", "Series 66": "SERIES_66", "Series 99": "SERIES_99"},
    "Approval Status": {"Not Required": "NOT_REQUIRED", "Pending": "PENDING", "Approved": "APPROVED", "Approved with Conditions": "APPROVED_WITH_CONDITIONS", "Retrospectively Approved": "RETROSPECTIVELY_APPROVED", "Rejected": "REJECTED", "Expired": "EXPIRED", "Withdrawn": "WITHDRAWN"},
    "G&E Approval Status": {"Not Required": "NOT_REQUIRED", "Pending": "PENDING", "Approved": "APPROVED", "Rejected": "REJECTED", "Retrospectively Approved": "RETROSPECTIVELY_APPROVED"},
    "Frequency": {"Daily": "DAILY", "Weekly": "WEEKLY", "Monthly": "MONTHLY", "Quarterly": "QUARTERLY", "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL", "On Event": "ON_EVENT", "Ad Hoc": "AD_HOC"},
    "Severity": {"Low": "LOW", "Medium": "MEDIUM", "High": "HIGH", "Critical": "CRITICAL"},
    "Social Platform": {"LinkedIn": "LINKEDIN", "X": "X", "YouTube": "YOUTUBE", "Instagram": "INSTAGRAM", "Facebook": "FACEBOOK", "Threads": "THREADS", "Other": "OTHER"},
    "Flow Direction": {"Inflow": "INFLOW", "Outflow": "OUTFLOW"},
    "Case Status": {"New / Received": "NEW", "In Progress": "IN_PROGRESS", "Waiting on Client": "WAITING_ON_CLIENT", "Pending Third Party": "PENDING_THIRD_PARTY", "Escalated": "ESCALATED", "Resolved / Completed": "RESOLVED", "Closed": "CLOSED", "Canceled": "CANCELED"},
    "Record Status": {"Draft": "DRAFT", "Proposed": "PROPOSED", "Pending": "PENDING", "Active": "ACTIVE", "Paused": "PAUSED", "Inactive": "INACTIVE", "Deprecated": "DEPRECATED", "Retired": "RETIRED"},
    "Regulator": {"FINRA": "US_FINRA", "SEC": "US_SEC", "US State Securities Regulator": "US_STATE_SECURITIES_REGULATOR", "MSRB": "US_MSRB"},
    "Investor Category": {"Retail": "RETAIL", "Institutional": "INSTITUTIONAL", "Financial Professional": "FINANCIAL_PROFESSIONAL"},
    "Performance Fee Basis": {"Gross of Fees": "GROSS_OF_FEES", "Net of Fees": "NET_OF_FEES", "Gross and Net": "GROSS_AND_NET"},
}

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: (list name in 08, proposed shared list name, likely other users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Registration Category", None, ["20", "03"],
     "NOT a merge with 20 Regulated Role Category: 20 lists the registration a ROLE requires (FINRA Registered Representative, "
     "Registered Principal, Operations Professional, IAR), 08 the CRD registration codes an INDIVIDUAL holds (GS, IR, GP, IP, OP, "
     "SU, OS, AG, RA). Keep both; publish a concordance (08 code -> 20 category) so that 03 can derive 'role requirement met' "
     "(CW-072, CW-920). List in NOT_MERGED."),
    ("(03) Branch Type", None, ["03"],
     "Fix pass (program-lead ruling 1): 03 masters Branch Type (Office of Supervisory Jurisdiction, Branch Office, Non-Branch Location; "
     "residential supervisory location is a 03 indicator). 08 has no local Branch Type: Branch Inspection.Branch Type at Inspection and "
     "Branch Registration.Registered Branch Type cite External (03 Branch Type) and are Derived copies (03). The draft's claim of 'same "
     "values' was wrong and is withdrawn."),
    ("Conduct Rule Basis", None, ["38", "33"],
     "Rule citations for scenarios and controls; 38 Regulatory Obligation already registers rules. Candidate for a reference to "
     "38 obligations instead of a list at W5."),
    ("(37) Incident Notification Regime / Incident Notification Stage", None, ["37", "41", "38"],
     "CW-937 notification lists are not taken here: 08 Complaint Regulatory Report records FINRA Rule 4530 reporting as "
     "attributes (reporting quarter, event reportable indicator) and External Protection Report uses its own Protection Report "
     "Recipient list (agencies under the Senior Safe Act), a different dimension from 37's regulator notification regime. No "
     "08 membership proposed."),
    ("Standard of Conduct (withdrawn)", None, ["45"],
     "Fix pass: Best Interest Review Detail.Standard of Conduct Applied cites External (45 Best Interest Component). Request to 45 at "
     "merge: add the values 'PTE 2020-02 Impartial Conduct Standards' and 'FINRA Rule 2111 Suitability', which an 08 review can apply."),
]

NOT_MERGED = [
    ("08", "Heightened Supervision Basis", "08", "Disclosure Event Type", "Fix pass: de-overlapped; the plan basis says 'Disclosure Event' and the kind of disclosure is the Related Disclosure Event's type."),
    ("08", "Conduct Rule Basis", "45", "Best Interest Component", "Fix pass: Conduct Rule Basis holds rule numbers only; the obligation components are 45's."),
    ("08", "Registration Category", "20", "Regulated Role Category", "Held registration codes of an individual vs registrations a role requires (CW-072, CW-920)."),
    ("08", "Review Outcome", "45", "Advice Review outcome (per the 45 brief)", "Supervisory review result vs the outcome of a client advice review."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (plan section 5.3 watchlist names and CW-078), decisions.TERM_CONFLICTS format.
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Review (wealth model)",
     "usages": [("08", "Supervisory Review (PRNR-)", "Principal review of a recommendation, approval, transaction or correspondence"),
                ("08", "Compliance Review (REV-)", "Advertising and communications review under FINRA Rule 2210"),
                ("45", "Advice Review (AVREV-)", "Periodic review of the advice engagement with the client, including the Rule 3a-4 annual contact"),
                ("51", "Fiduciary Account Review (FIRV-)", "12 CFR 9.6 review of a fiduciary account"),
                ("38", "Compliance Program Review", "Rule 206(4)-7 and 38a-1 annual program review")],
     "recommendation": "Never bare: Supervisory Review, Compliance Review, Advice Review, Fiduciary Account Review, Compliance Program Review.",
     "resolution": "As recommended (CW-078).", "status": "Resolved", "decision": "CW-078"},
    {"term": "Case (wealth model)",
     "usages": [("08", "Senior Investor Case (SNRC-)", "FINRA Rule 2165 supervisory case"),
                ("08", "Frequent Trading Case (FTC-)", "Own-fund round-trip surveillance case"),
                ("38", "AML Case", "Suspicious activity investigation"),
                ("51", "Estate Settlement Case (ESTATE-)", "Trust and estate settlement"),
                ("13", "Service Request (SRQ-)", "Not a case")],
     "recommendation": "Always qualified; 13 requests are never called cases.",
     "resolution": "As recommended (CW-078).", "status": "Resolved", "decision": "CW-078"},
    {"term": "Advisor (wealth model)",
     "usages": [("03", "Advisor", "Firm's own representative, profile of 20 Employee (EMP-)"),
                ("05", "External Advisor", "Intermediary advisor, a 02 party in a role (W4)"),
                ("08", "Supervised Representative / Associated Person Named", "Reference (Advisor, 03)")],
     "recommendation": "08 references 03 Advisor for the supervised person and 20 Employee for principals and staff.",
     "resolution": "As ruled (CW-013, CW-078).", "status": "Resolved", "decision": "CW-078"},
    {"term": "Hold",
     "usages": [("15", "Account Restriction (ARX-)", "Transaction or account-wide hold, incl. FINRA Rule 2165"),
                ("50", "Money Movement Hold (MMHLD-)", "Disbursement hold"),
                ("39", "Legal Hold (LHOLD-)", "Litigation preservation"),
                ("08", "Senior Investor Case Action", "References 15 and 50 holds; sets none (CW-071)")],
     "recommendation": "Qualify: account hold, disbursement hold, legal hold. 08 records the protective action only.",
     "resolution": "As recommended (CW-071).", "status": "Resolved", "decision": "CW-071"},
    {"term": "Complaint",
     "usages": [("08", "Complaint (CPL-)", "Grievance meeting the FINRA Rule 4530 and 4513 definition (and oral grievances by policy)"),
                ("13", "Service Request (SRQ-)", "Client request; references the complaint (Escalated Complaint)"),
                ("04", "Social Listening Mention / Survey Response", "Feedback that may be referred to 08")],
     "recommendation": "Complaint means the 08 record; 13 and 04 hold intake and reference CPL-.",
     "resolution": "As recommended (CW-070).", "status": "Resolved", "decision": "CW-070"},
    {"term": "Finding",
     "usages": [("08", "Supervisory Finding (SFND-)", "Branch inspection, control test or supervisory finding"),
                ("38", "Examination Finding", "Regulator examination finding"),
                ("37", "Audit Finding", "Internal audit finding")],
     "recommendation": "Always qualified; 08 Supervisory Finding references the 38 Examination Finding it responds to.",
     "resolution": "As recommended.", "status": "Resolved", "decision": "CW-066"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. REPOINTS: values and texts of other modules that the replacement changes (program lead applies at the W2 merge).
#    (object, attribute or item, before, after, decision)
# ---------------------------------------------------------------------------------------------------------------------
REPOINTS = [
    ("02 Vulnerability Concern", "Escalation Case Reference", "Identifier, 'Supervisory case 2026-00217', OWNERSHIP_OVERRIDES -> 08",
     "Reference (Senior Investor Case, 08), example SNRC-2026-00217; drop the enrich_02 override; relationship target 'Senior Investor Case [08]'", "CW-071"),
    ("36 Target Market Review Result", "Distributor Feedback Reviewed; Sales Outside Target Market Observed Indicator",
     "Read the wholesale 08 Distributor Feedback Report / Sales Against Target Market", "Removed early (MiFID II), recorded under CW-936 at 36's W4 adaptation", "CW-067"),
    ("36 (content_36 line 348)", "Reference (Outcome Metric, 08)", "Wholesale Outcome Metric (Consumer Duty)", "Removed with the 36 US pass (CW-936); no 08 target", "CW-067"),
    ("38 relationship text", "Compliance records [08] (REV-, DDQ-, GNE-, CPL-, LIC-)", "includes DDQ-", "Compliance records [08] (REV-, GNE-, CPL-, LIC-, PRNR-)", "CW-067"),
    ("30 (content_30 line 62)", "Reference (Private Offering Compliance, 08)", "Wholesale Private Offering Compliance", "30 retires at W4 (CW-016); no 08 target", "CW-067"),
    ("03 (W2 sibling)", "Supervisory Assignment heightened supervision flag; License & Registration Reference", "per the 03 brief",
     "Reference (Heightened Supervision Plan, 08) HSPL-; Reference (Individual Registration) LIC- (03 Derived copies of status and registered states)", "CW-072"),
    ("02 Vulnerability Concern", "Agency Referral Date", "Mastered in 02",
     "Derived copy (08) of the earliest External Protection Report.Report Date of the senior investor case the concern escalated to (program-lead ruling 4); add to enrich_02 DERIVED", "CW-071"),
    ("02 Vulnerability Concern", "Trusted Contact Contacted Date; Trusted Contact Designation Used", "Mastered in 02",
     "Unchanged: the first contact about the concern stays 02's; 08 Senior Investor Case.Trusted Contact Contacted Date is a Derived copy (02); later contacts are 08 case actions; the Rule 2165(b)(2) notice that follows a hold is evidence on the 15 or 50 hold", "CW-071"),
    ("45 (content_45 line 19 and the REL at line 547)", "PTE 2020-02 retrospective review", "'08 holds the PTE 2020-02 retrospective review' / 08 records its findings",
     "38 Compliance Program Review (CW-066); 08 holds only the per-recommendation Best Interest Review Detail", "CW-066"),
    ("03 Recognition Award", "Award Conduct Review Reference", "Reference (Incentive Conflict Review, 08), RECG-2026-00218 / 2026-02-20",
     "Unchanged: resolves to 08 Incentive Conflict Review keyed RECG- / review date (fix pass adds Reviewed Recognition Award)", "CW-064"),
    ("48 Routing Rule / Execution Quality Measure", "Approving Review; Reviewing Committee Review", "Reference (Supervisory Review, 08)",
     "Unchanged: resolves to an 08 Supervisory Review of type 'Best Execution Regular and Rigorous Review' (FINRA Rule 5310.09)", "CW-100"),
    ("03 Supervisory Assignment", "Heightened Supervision Plan Reference", "Reference (Heightened Supervision Plan, 08)",
     "Unchanged; 08 Heightened Supervision Plan.Heightened Supervisor is now a Derived copy (03) of the assignment's supervisor", "CW-072"),
    ("13 Service Request (W2 sibling)", "Escalated Complaint", "Reference (Complaint)", "Unchanged: resolves to 08 Complaint CPL-", "CW-070"),
    ("21 (W2 merge)", "Object Governance Profile / Record Governance Metadata retention references; Retention Rule object", "Reference (Retention Rule) -> 08",
     "Retention Rule added to 21 unchanged (name, RET-, Record Class, Governing Requirement, Retention Period (Years)); 08 Captured Communication Record.Retention Rule is Reference (Retention Rule, 21); PREFIXES RET- owner 08 -> 21", "CW-068"),
    ("39 Legal Hold Scope", "Reference (Retention Rule)", "-> 08", "-> 21 (no text change; the resolver follows the RET- owner)", "CW-068"),
    ("PREFIXES", "ICP- owner", "07", "03 (CW-080); 08 enrich_08 override on Incentive Conflict Review.Reviewed Incentive Plan Component can then be dropped", "CW-080"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. JURISDICTION: EU/UK content of the wholesale 08 (wholesale-v1.0) that the replacement does not carry (CW-079).
#    Format: jurisdiction.REMOVALS. Whole objects and whole lists have attribute "".
# ---------------------------------------------------------------------------------------------------------------------
_D = "CW-908"
def _j(obj, attr, regime, note):
    return {"domain": "08", "object": obj, "attribute": attr, "regime": regime, "decision": _D, "note": note}

JURISDICTION = [
    # Objects
    _j("EU / UK Communication Classification", "", "FCA", "FCA financial promotion (s21 FSMA, COBS 4, FPO exemption, s21 approver gateway), ESMA marketing communication (Regulation (EU) 2019/1156), MiFID client category targeted, FCA ESG 4.3 sustainability claims; 7 attributes. The US classification (FINRA Rule 2210, Rule 482, Marketing Rule) stays."),
    _j("Distributor Feedback Report", "", "FinDatEx", "FinDatEx EFT and UK distributor feedback template reports; FBK- retired. 6 attributes."),
    _j("Sales Against Target Market", "", "MiFID II", "MiFID II product governance sales outside the target market; 7 attributes. DP-109 and 36 readers re-pointed (CW-067)."),
    _j("Distribution Chain Information Exchange", "", "Consumer Duty", "FCA PRIN 2A information sharing along the distribution chain; 5 attributes."),
    _j("Distribution Review Finding", "", "MiFID II", "Input to the MiFID II / PROD 3 product review; 3 attributes."),
    _j("Inducement Assessment", "", "MiFID II", "MiFID II Article 24(9) and FCA COBS 2.3A inducements and minor non-monetary benefits; 3 attributes. FINRA Rules 3220 and 2341 stay (Gift / Entertainment Item, Benefit Valuation)."),
    _j("Certification & Competence", "", "SM&CR", "SM&CR population, certification function, FCA Individual Reference Number, annual certification, fitness and propriety, MiFID knowledge-and-competence role; 6 attributes. Forms U4 and U5, FINRA registration and CE stay."),
    _j("Cross-Border Marketing Notification", "", "UCITS", "UCITS Article 93 and AIFMD Article 32 and 42 marketing notifications; MKN- retired. 7 attributes. DP-246 and models_e8c_cross_area.py re-pointed (CW-067)."),
    _j("Pre-Marketing Episode", "", "AIFMD", "AIFMD Article 30a pre-marketing (Directive (EU) 2019/1160); PMK- retired. 8 attributes."),
    _j("Reverse Solicitation Record", "", "AIFMD", "EU reverse solicitation evidence; RSL- retired. 5 attributes."),
    _j("Outcome Metric", "", "Consumer Duty", "FCA Consumer Duty outcome metrics; 4 attributes. DP-109 and 36 reader re-pointed (CW-067)."),
    # Attributes
    _j("Private Offering Compliance", "NPPR Filing Reference", "AIFMD", "National private placement filing (e.g. UK AIFMD Article 42); the object is dropped for non-EU reasons (Form D is the feeder issuer's filing in 35; qualification is 02)."),
    _j("Complaint Classification", "FCA Complaint Product Group", "FCA", "FCA complaints return product group; FINRA Rule 4530 problem and product codes stay."),
    _j("Complaint Regulatory Report", "FCA Return Reporting Period", "FCA", "FCA DISP and PS25/19 consolidated complaints return; FINRA 4530(d) quarter stays."),
    _j("Complaint", "Vulnerable Customer Indicator", "Consumer Duty", "Replaced by Complaint.Related Vulnerability Concern, a restricted Reference (Vulnerability Concern) to 02 (FINRA Rule 2165; CW-030)."),
    _j("Other Regulator Filing", "Regulator", "EU market practice", "Example and purpose was an EU NCA ex-ante filing (CBDF Article 7); the object is merged into FINRA Advertising Filing as Filing Regulator (shared Regulator list, US values)."),
    _j("Required Disclosures", "Offering Document Reference Included", "EU market practice", "Primary source EU CBDF Regulation (prospectus / KID reference); dropped in the replacement (the Rule 482 legend check is part of the fair-and-balanced review)."),
    _j("Required Disclosures", "Risks and Rewards Equally Prominent Check", "EU market practice", "EU CBDF / FCA COBS 4 sourced; kept as US Communication Classification.Fair and Balanced Check re-sourced to FINRA Rule 2210(d)(1)."),
    _j("Other Regulator Filing", "Regulator Filing Type", "EU market practice", "EU NCA ex-ante or ex-post submission type (CBDF Article 7); the US filing body is FINRA Advertising Filing.Filing Regulator."),
    _j("Other Regulator Filing", "Regulator Submission Date", "EU market practice", "Date of an EU NCA submission; FINRA Advertising Filing.Filed Date covers US filings."),
    _j("Disclosure Event", "Disclosure Event Type (PII note: GDPR Article 10)", "GDPR / UK GDPR", "Criminal-offense data note re-stated as PII - special category (CD-344)."),
    # Whole code lists
    _j("Code list: Financial Promotion Type", "", "FCA", "Whole list: Non-Real-Time, Real-Time Solicited, Real-Time Unsolicited, Direct Offer."),
    _j("Code list: FPO Exemption", "", "FCA", "Whole list: FSMA Financial Promotion Order articles and COBS 4.12 bases (7 values)."),
    _j("Code list: MiFID Client Category", "", "MiFID II", "Membership of the retired shared list (CW-039); 4 local values."),
    _j("Code list: Feedback Template", "", "FinDatEx", "Whole list: FinDatEx EFT, UK Distributor Feedback Template, Bespoke."),
    _j("Code list: Distribution Strategy", "", "MiFID II", "Membership of the retired shared list (CW-039); FinDatEx EMT distribution services."),
    _j("Code list: Target Market Deviation Reason", "", "MiFID II", "Whole list (6 values), ESMA product governance guidelines."),
    _j("Code list: Exchange Direction", "", "Consumer Duty", "Whole list (3 values) of the Distribution Chain Information Exchange."),
    _j("Code list: Consumer Duty Information Type", "", "Consumer Duty", "Whole list (7 values)."),
    _j("Code list: Product Governance Action", "", "MiFID II", "Whole list (6 values), ESMA guidelines and FCA PROD 3."),
    _j("Code list: Consumer Duty Outcome", "", "Consumer Duty", "Whole list: Products and Services, Price and Value, Consumer Understanding, Consumer Support."),
    _j("Code list: MNMB Category", "", "FCA", "Whole list (7 values), FCA COBS 2.3A.19R and Delegated Directive (EU) 2017/593 Article 12(3)."),
    _j("Code list: Inducement Outcome", "", "MiFID II", "Whole list (4 values)."),
    _j("Code list: SM&CR Population", "", "SM&CR", "Whole list (4 values)."),
    _j("Code list: Certification Function", "", "SM&CR", "Whole list (7 values), FCA SYSC 27.8."),
    _j("Code list: F&P Outcome", "", "SM&CR", "Whole list (3 values)."),
    _j("Code list: MiFID Competence Role", "", "MiFID II", "Whole list (3 values), ESMA knowledge and competence guidelines."),
    _j("Code list: Notification Regime", "", "UCITS", "Whole list: UCITS Article 93, AIFMD Article 32, 42 and 36, UK Overseas Funds Regime, UK NPPR, Swiss representative (Other non-US), local private placement."),
    _j("Code list: Notification Status", "", "UCITS", "Whole list (6 values) of the Cross-Border Marketing Notification."),
    # Code-list values
    _j("Code list: G&E Limit Rule", "Firm EMEA Gift Threshold", "FCA", "Firm threshold for MiFID and COBS business."),
    _j("Code list: Complaint Source", "Ombudsman", "FCA", "UK Financial Ombudsman Service referral; Regulator Referral stays (US regulators)."),
    _j("Code list: Complaint Status", "Referred to Ombudsman", "FCA", "Replaced by In Arbitration or Litigation (FINRA arbitration, 39 Legal Matter)."),
    _j("Code list: Retention Requirement", "MiFID II Art 16(7)", "MiFID II", "List moves to 21 with Retention Rule (CW-068); recorded here per the brief."),
    _j("Code list: Retention Requirement", "FCA COBS 11.8", "FCA", "As above."),
    _j("Code list: Retention Requirement", "FCA DISP 1.9", "FCA", "As above."),
    _j("Code list: Record Class", "MiFID Telephone and Electronic Records", "MiFID II", "As above."),
    _j("Code list: Regulator Filing Type", "Ex-Ante Notification", "EU market practice", "Host NCA prior notification under CBDF Article 7; list replaced by the shared Regulator list on Filing Regulator."),
    _j("Code list: Performance Type", "Simulated Past Performance", "FCA", "ESMA / FCA COBS 4.6 term."),
    _j("Code list: Performance Type", "Future Performance Scenario", "EU market practice", "ESMA marketing communications guidelines."),
    _j("Code list: Disclosure Set (firm-defined)", "EU-MKTG-01", "EU market practice", "ESMA 'This is a marketing communication' disclaimer."),
    _j("Code list: Disclosure Set (firm-defined)", "UK-FP-PP-01", "FCA", "UK past performance warning."),
    _j("Code list: Reviewer Role", "Compliance - EMEA", "Other EU/UK", "EMEA compliance reviewer of EU/UK communications."),
    _j("Code list: Legal Entity (firm-defined)", "Example Asset Management (UK) Ltd", "FCA", "FCA-authorized firm; Registering Firm is now a Reference (Legal Entity) to 09."),
    _j("Code list: Legal Entity (firm-defined)", "Example Asset Management S.A.", "UCITS", "Luxembourg ManCo / AIFM."),
    _j("Code list: Sales Practice Alert Type", "Sale Outside Target Market", "MiFID II", "MiFID II product governance."),
    _j("Code list: Investor Qualification Standard", "Professional Investor (AIFMD)", "AIFMD", "Value of the dropped Private Offering Compliance; shared value removed under CW-039."),
    _j("Code list: Intermediary Info Type", "Target Market & Fair Value Data", "Consumer Duty", "Value of the dropped Intermediary Information Package."),
    # Sources
    _j("Sources", "FCA COBS 4 (Communicating with clients, including financial promotions) and s21 FSMA / PS23/13 gateway", "FCA", "Re-sourced to FINRA Rule 2210 and the Marketing Rule."),
    _j("Sources", "FCA PS23/16 SDR and FG24/3 anti-greenwashing rule (ESG 4.3.1R)", "FCA", ""),
    _j("Sources", "FCA COBS 2.3A (Inducements)", "FCA", "FINRA Rules 3220 and 2341 kept."),
    _j("Sources", "FCA PRIN 2A (Consumer Duty) and PROD 3", "Consumer Duty", ""),
    _j("Sources", "FCA DISP and PS25/19 (complaints reporting)", "FCA", "FINRA Rules 4530 and 4513 kept."),
    _j("Sources", "FCA SM&CR (SYSC 27) and SYSC 10 conflicts", "SM&CR", "Conflicts are 38 (Reg BI and Form ADV sources)."),
    _j("Sources", "Regulation (EU) 2019/1156 (Cross-Border Distribution of Funds)", "EU market practice", ""),
    _j("Sources", "ESMA Guidelines on marketing communications (ESMA34-45-1272)", "EU market practice", ""),
    _j("Sources", "Directive (EU) 2019/1160 / AIFMD Art 30a, 32, 42 and UCITS Art 93", "AIFMD", "Also UCITS; CSSF pre-marketing guidance included."),
    _j("Sources", "ESMA Guidelines on MiFID II product governance (ESMA35-43-3448)", "MiFID II", ""),
    _j("Sources", "MiFID II and Delegated Directive (EU) 2017/593", "MiFID II", ""),
    _j("Sources", "FinDatEx European Feedback Template (EFT) and EMT", "FinDatEx", ""),
    _j("Sources", "UK joint trade association Distributor Feedback Template / data delivery frameworks", "UK market practice", ""),
    _j("Sources", "Sanctions lists and AML frameworks (OFAC, OFSI, EU, FATF, UK MLR 2017) - OFSI, EU and UK MLR 2017 parts", "Other EU/UK", "The whole source leaves 08 with Distributor Due Diligence (05 at W4); OFAC and FATF stay there."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. DECISIONS: the US-only pass of 08 (pre-allocated id, CW-022, CW-079).
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-908", "theme": "Scope", "title": "US-only pass of Data Domain 08 Retail Conduct & Supervision (replacement of the wholesale 08 Distribution Compliance)",
     "domains": ["08", "21", "36", "05"],
     "issue": "The wholesale 08 Distribution Compliance served an asset manager distributing wholesale in the US and the EU/UK: FCA financial promotions and ESMA marketing communications, MiFID II product governance feedback and inducements, Consumer Duty information exchange and outcome metrics, UCITS and AIFMD cross-border marketing, pre-marketing and reverse solicitation, SM&CR certification, FCA complaints return fields, MiFID and FCA retention values, and 13 EU/UK sources. The replacement (CW-015, CW-066) is designed US only and must record what it leaves out so that a UK extension can be restored.",
     "resolution": "Not carried (71 JURISDICTION entries in proposals_w2_08.py (FCA 18, MiFID II 14, EU market practice 10, Consumer Duty 8, SM&CR 5, AIFMD 5, UCITS 4, FinDatEx 3, Other EU/UK 2, GDPR / UK GDPR 1, UK market practice 1): 11 objects, 10 attributes, 18 whole lists, 18 values, 14 sources): objects EU / UK Communication Classification, Distributor Feedback Report, Sales Against Target Market, Distribution Chain Information Exchange, Distribution Review Finding, Inducement Assessment, Certification & Competence, Cross-Border Marketing Notification, Pre-Marketing Episode, Reverse Solicitation Record, Outcome Metric (prefixes FBK-, MKN-, PMK-, RSL- retired); attributes Private Offering Compliance.NPPR Filing Reference, Complaint Classification.FCA Complaint Product Group, Complaint Regulatory Report.FCA Return Reporting Period, Complaint.Vulnerable Customer Indicator (replaced by a restricted Reference (Vulnerability Concern) to 02), the EU NCA purpose of Other Regulator Filing.Regulator (merged into FINRA Advertising Filing.Filing Regulator), Other Regulator Filing.Regulator Filing Type and Regulator Submission Date, Required Disclosures.Offering Document Reference Included, Required Disclosures.Risks and Rewards Equally Prominent Check (re-sourced to FINRA Rule 2210(d)(1) as Fair and Balanced Check) and the GDPR Article 10 note on Disclosure Event; lists Financial Promotion Type, FPO Exemption, MiFID Client Category and Distribution Strategy memberships, Feedback Template, Target Market Deviation Reason, Exchange Direction, Consumer Duty Information Type, Product Governance Action, Consumer Duty Outcome, MNMB Category, Inducement Outcome, SM&CR Population, Certification Function, F&P Outcome, MiFID Competence Role, Notification Regime, Notification Status; values G&E Limit Rule Firm EMEA Gift Threshold, Complaint Source Ombudsman, Complaint Status Referred to Ombudsman, Retention Requirement MiFID II Art 16(7), FCA COBS 11.8 and FCA DISP 1.9 and Record Class MiFID Telephone and Electronic Records (recorded here although the lists move to 21 with Retention Rule, CW-068), Regulator Filing Type Ex-Ante Notification, Performance Type Simulated Past Performance and Future Performance Scenario, Disclosure Set EU-MKTG-01 and UK-FP-PP-01, Reviewer Role Compliance - EMEA, the UK and Luxembourg firm-defined legal entities, Sales Practice Alert Type Sale Outside Target Market, Investor Qualification Standard Professional Investor (AIFMD), Intermediary Info Type Target Market & Fair Value Data; sources FCA COBS 4 and s21, FCA PS23/16 and ESG 4.3, FCA COBS 2.3A, FCA PRIN 2A and PROD 3, FCA DISP and PS25/19, FCA SM&CR and SYSC 10, Regulation (EU) 2019/1156, the ESMA marketing guidelines, Directive (EU) 2019/1160, the ESMA product governance guidelines, MiFID II and Delegated Directive 2017/593, FinDatEx EFT and EMT, the UK distributor feedback template, and the OFSI, EU and UK MLR parts of the sanctions source. Kept and re-sourced to the US rule: Compliance Review, US Communication Classification (with Required Disclosures merged; the fair-and-balanced check re-sourced to FINRA Rule 2210(d)), Performance Presentation (SEC Marketing Rule and Rule 482), Compliance Approval, FINRA Advertising Filing (with Other Regulator Filing merged as Filing Regulator on the US Regulator list), Jurisdictions of Use (US states, FINRA Rule 2210), Intended Audience (FINRA Rule 2210 audiences), Approved Communication Channel (SEC Rule 17a-4(b)(4), FINRA Rule 3110(b)(4)), complaints (FINRA Rules 4530 and 4513; final response due date re-sourced to firm policy), registrations (FINRA Rules 1210, 1220, 1240, Forms U4, U5 and BR, NASAA IAR CE), gifts and non-cash compensation (FINRA Rules 3220 and 2341). Not EU/UK and dropped or moved for other reasons (no entry): Distributor Due Diligence and its detail objects (05 at W4, DDQ- held; their EU/UK values, Regulatory Register 'FCA Financial Services Register', 'ESMA Registers' and 'EU NCA Register' and the ESMA- and Consumer Duty-aligned Distributor Role list, travel to 05 and are recorded by 05's pass under CW-905), Distribution Conflict of Interest (38 CONFL-; COI- retired), Intermediary Information Package, Private Offering Compliance, Record Metadata (CD-160), Retention Rule (21, CW-068).",
     "rationale": "US only narrows where the firm is regulated and distributes (CW-003, CW-022); the register keeps a UK extension restorable from tag wholesale-v1.0. Generic objects with a US instance were kept and re-sourced, not removed. Lever: UK extension restores the removed rows.",
     "action": "Merge JURISDICTION into jurisdiction.REMOVALS at the W2 merge", "status": "Proposed", "priority": "High",
     "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 8. NOTES for the consolidation step, with READERS.
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Validation (fix pass, 2026-10-15): taxonomy_builder.py content_08_retail_conduct_and_supervision OK (9 families, 39 objects (13 attribute groups, 0 without grain), 303 attributes, 102 CDEs (33.7%), 87 references, 6 derived, 0 unresolved, 54 code lists in the workbook). CL holds 55 entries: 42 local lists and 13 copies of shared lists; the workbook shows 54 because the two members of shared Approval Status (Approval Status, G&E Approval Status) render as one 'Shared: Approval Status' list. Before the fix pass: 290 attributes, 86 CDEs, 84 references, 3 derived, 64 workbook lists (52 local). check_enrichment.py 08 still picks content_08_distribution_compliance.py first from os.listdir; the scratchpad wrapper check08.py (forces the new module) prints 39 objects (26 business objects, 13 attribute groups), 6 derived copies, 20 overrides, 2 row ownership rules / OK.",
    "Deviations from the brief: (a) 26 BO and 13 AG (the brief header says 25 and 14; its table gives 26 and 13). (b) 303 attributes against 240 to 290: the fix pass added the review subjects and keys the review asked for (best-execution routing rule and venue, recognition award, exam attempt and date, registration links on exams, CE and disclosure events, the look-back window, Complaint Office, two disclosure evidence references, Final Response Due Date, Registration Body, a Trusted Contact Contacted Date copy, a source alert on corrective actions) and dropped Campaign, Prescribed Periods Shown Indicator, Population Scope, Case Action Action Taken By and Related AML Case. (c) 42 local code lists (36 to 46 met after the fix pass). (d) Wholesale Distributor Involved and Selling Distributor dropped (intermediary residue).",
    "Wholesale attributes not carried, with no EU/UK reason (the review's list, J and question 3): Gift / Entertainment Item.Business Purpose; Training / Education Meeting.Sponsorship Agreement (replaced by Sponsor Firm, the 02 party); US Communication Classification.Financial Professional Use Only Indicator (the audience is Intended Audience, and 04 Content Asset holds Audience Restriction); Required Disclosures.Offering Document Reference Included and Other Regulator Filing.Regulator Filing Type and Regulator Submission Date (also recorded in JURISDICTION: EU primary sources); Complaint.Related Communication; Compliance Approval.Compliance Approval Code and Re-certification Frequency; FINRA Advertising Filing.FINRA Comments Summary; Captured Communication Record.Preservation Method; Social Media Account.Content Supervision Model; Benefit Valuation.Excluded Gift Category. Complaint Handling.Final Response Due Date is restored, re-sourced to firm policy, as the CW-908 text says. Pending readers: DP-036, DP-038, DP-051, DP-061, DP-078 (WP0).",
    "45 names used: Recommendation (RECOM-), Best Interest Evidence (composite RECOM- / Best Interest Component), Rollover Analysis (ROLV-). 47: Fee Disclosure Delivery, forced to 47. 03: Advisor, Firm Branch Office, Incentive Plan Component, Recognition Award (RECG-), the Branch Type and Principal Designation Type scales; EMP-, SITE- and ICP- forced to 03. W3 (keys per the 48, 49 and 50 modules): Client Order (CLORD-), Routing Rule, Execution Venue Profile (48), Client Account Activity (CLACT-, 49), Money Movement Hold (MMHLD-, 50).",
    "Program-lead rulings applied (fix pass): Branch Type is 03's and 08's two branch type attributes and Heightened Supervisor are Derived copies (03); Supervisory Review Type gains 'Best Execution Regular and Rigorous Review' (FINRA Rule 5310.09) with 48 subjects; Incentive Conflict Review takes a 03 Recognition Award; Exam Result, CE Requirement and Disclosure Event are tied to Individual Registration (Disclosure Event keyed per person, registration optional); 08 masters the Senior Investor Case and the agency referral (External Protection Report), 02 keeps the trusted-contact facts that 08 copies (Derived, 02), and 02 Vulnerability Concern.Agency Referral Date becomes a Derived copy of 08 at the merge (REPOINTS); the PTE 2020-02 annual retrospective review stays 38 (CW-066), stated in Best Interest Review Detail.",
    "Row rules for the merge on two-way pointers (review Low A): the side that holds the fact is authoritative - the 50 Money Movement Hold and 15 Account Restriction for the hold (08 Case Action references them), 03 Supervisory Assignment for the heightened-supervision supervisor (08 holds a Derived copy), 08 Incentive Conflict Review for the review result (03 Incentive Conflict Review Reference and Award Conduct Review Reference point to it).",
    "Stewardship (review Low F): 08 uses neither Screening Result nor Audience Restriction; propose moving Audience Restriction stewardship to 04 (Content Asset) and Screening Result to 50 or 29 (transaction and account screening) at W5.",
    "Skipped Lows with reason: Senior Investor Case.Specified Adult Basis stays a Derived copy (02) rather than a reference, because 02 Specified Adult Status is an attribute group of Party with no row key to reference (brief section 5 asks for the Derived copy); Branch Registration keeps the office x Form BR filing grain (the repetition of registration-level facts is stated in the grain) rather than adding a separate filing object; Supervisory Finding.Finding Source keeps all seven source values while only three have references (alerts, complaints and examinations reach a finding through the corrective action or 38 Examination Finding).",
    "38 W4: the PTE 2020-02 annual retrospective review is a 38 Compliance Program Review type (CW-066); Rule 3240 and 3241 declarations join 38 Outside Business Activity (CW-074); 08 Supervisory Control is keyed by the 38 Policy holding the WSP. The 08 Related AML Case reference was dropped (31 CFR 1023.320(e)): 38 AML Case may point to SNRC-.",
    "Retention Rule (RET-) is not defined in 08 (CW-068); Captured Communication Record.Retention Rule is Reference (Retention Rule, 21), forced to 21 until PREFIXES moves RET- to 21; Retention Expiry Date is computed from the 21 period.",
    "State notice filings (CW-069): none in 08; Individual Registration holds state agent and IAR registrations only (Registration Body + state).",
    "Oral complaints: recorded by policy with Written Complaint Indicator = N and excluded from the FINRA Rule 4530(d) statistical counts by default (4530(d) Reporting Quarter blank).",
    "READERS - resolve unchanged (attribute names kept on the kept objects): DP-009 (specs_b_foundational.py) Individual Registration [License ID, Registered Person, Registration Category, Registration Jurisdiction, Registration Status, Registration Effective Date]; DP-200 (specs_e4_people_workplace_ai.py) Individual Registration [License ID, Registered Person], CE Requirement [CE Element, CE Due Date, CE Status]; DP-209 (same file) Gift / Entertainment Item [GNE ID, Benefit Type, Benefit Date, Giver, Recipient Individual]; DP-228 (specs_e4_compliance_legal.py) Surveillance Alert [Alert ID, Alert Disposition]; DP-236 (specs_e4_technology_communications.py) Compliance Review [Review ID, Review Type, Products Featured, Submission Timestamp], Compliance Approval [Approval Status, Approval Decision Date]. Object references from carried modules resolve by name: 04 (Compliance Review, Complaint), 11, 12, 13, 16 (Complaint), 20 (Individual Registration; Form U4 and U5 texts), 29 (Frequent Trading Case), 32, 38 (Surveillance Alert), 42 (Compliance Review, Gift / Entertainment Item), 44 (Gift / Entertainment Item); 21 and 39 Retention Rule references move with RET- to 21.",
    "READERS - re-point at the W2 merge: DP-246 (specs_e5_cross_area.py) reads Cross-Border Marketing Notification [Notification ID, Notified Product / Share Class, Host Country, Notification Regime, Competent Authority, Notification Status, Marketing Permitted From]: drop the input, and models_e8c_cross_area.py likewise. DP-109 (specs_e3_private_markets_product_range.py) reads Sales Against Target Market [Share Class, Sales Outside Target Market Indicator, Volume Outside Target Market] and Outcome Metric [Consumer Duty Outcome, Metric Name, Metric Value, Tolerance Status]: drop both, and models_e8c_private_markets_product_range.py likewise. 02 Vulnerability Concern.Escalation Case Reference: retype to Reference (Senior Investor Case, 08) with example SNRC-2026-00217 and drop its enrich_02 override (REPOINTS). 36 Target Market Review Result.Distributor Feedback Reviewed and Sales Outside Target Market Observed Indicator: remove early (MiFID II; CW-936 at W4); content_36 line 348 Reference (Outcome Metric, 08) likewise.",
    "READERS - attributes dropped from kept objects that wholesale products read (not in the brief's live list; check at WP0): Compliance Approval.Compliance Approval Code and Re-certification Frequency; Required Disclosures.Disclosure Set Applied now on US Communication Classification; Social Media Account [Social Platform, Account Owner, Account Use Type] now on Approved Communication Channel, Content Supervision Model dropped; Sales Practice Alert.Selling Distributor dropped; FINRA Advertising Filing.FINRA Comments Summary dropped; Captured Communication Record.Preservation Method dropped; Special Recipient Flags attributes now on Gift / Entertainment Item; Benefit Valuation.Excluded Gift Category dropped; Retention Rule [Record Class, Retention Period (Years)] moves to 21. Left for W4: 05 Distribution Agreement.Distributor Due Diligence Reference and the 05 and 10 Inducement Assessment references (typed Compliance Review). keys_g4_08_09.py and the keys_e7_* entries for dropped objects are superseded at WP2.",
]
