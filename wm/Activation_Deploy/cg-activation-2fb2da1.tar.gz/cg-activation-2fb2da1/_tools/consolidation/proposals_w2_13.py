"""Consolidation proposals from the W2 draft of Data Domain 13 Client Service & Communications (wealth manager), 2026-10-14.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py,
shared_code_lists.py and jurisdiction.REMOVALS at the W2 merge. Formats follow CONTRACT.md in this folder. The brief is
00_Program/Rework/Briefs/13_Client_Service_and_Communications.md (Disposition: Adapt, CW-001). It implements CW-003, CW-022,
CW-081, CW-082, CW-086 to CW-090 (proposals_w2_engagement.py) and CW-934 (proposals_w1b_34.py), and drafts CW-913, the US-only
pass of 13. Module: content_13_investor_servicing_and_shareholder_communications.py (rewritten in place; output path and
folder unchanged).
"""

_D, _C = "13", "CW-913"

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES (decisions.PREFIXES tuple format). None beyond VCEL-, which proposals_w2_engagement.py reserves (CW-082) and
#    decisions.PREFIXES does not hold yet. Interaction Authentication, Issuer Proxy Pass-Through, Beneficial Owner Disclosure
#    Election and Recipient Delivery Record use composite keys (KEY_FORMATS in proposals_w2_engagement.py; Recipient Delivery
#    Record: MAIL- / ACC-).
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED MEMBERSHIPS: 13 local lists that carry a shared list's exact name (or are registered members under a local
#    name). value_map maps each local label to the shared code; new_values are codes the shared list does not hold yet.
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Voting Choice Option Type", "local": "Voting Choice Option Type",
     "value_map": {"Fund Adviser Policy": "FUND_ADVISER_POLICY", "Board-Aligned": "BOARD_ALIGNED",
                   "Third-Party Benchmark": "THIRD_PARTY_BENCHMARK", "Values-Based": "VALUES_BASED", "Not Voting": "NOT_VOTING",
                   "Other": "OTHER"},
     "new_values": ["FUND_ADVISER_POLICY", "BOARD_ALIGNED", "THIRD_PARTY_BENCHMARK", "VALUES_BASED", "NOT_VOTING", "OTHER"],
     "note": "CW-082: a new shared list, steward 34 (content_34 line 400 holds the values, copied here label for label), members "
             "34 (Voting Policy.Voting Choice Option Type) and 13 (Voting Choice Election.Chosen Option Type). The list does not "
             "exist in shared_code_lists.py yet: create it at the W2 merge or at W5 with 34 (CW-082 action 'W5 (shared list)')."},
    {"shared": "Business Line", "local": "Business Line",
     "value_map": {c: c for c in ("DB", "DA", "HA", "PF", "WR", "IA", "IC", "TR")},
     "new_values": [],
     "note": "New member (CW-004). Service Request.Request Business Line, Servicing Error.Affected Business Line. Two-letter codes as "
             "values, as 02 and 15 (identity map, the program-lead ruling)."},
    {"shared": "Delivery Method", "local": "Delivery Method",
     "value_map": {"Paper - First Class Mail": "PAPER_MAIL_FIRST_CLASS", "Paper - Bulk Mail": "PAPER_MAIL_BULK",
                   "Electronic - Email Notification": "EMAIL_NOTIFICATION_LINK", "Electronic - Email Attachment": "EMAIL_ATTACHMENT",
                   "Electronic - Portal Posting": "PORTAL", "Notice of Internet Availability": "NOTICE_OF_INTERNET_AVAILABILITY",
                   "Website Availability Only": "WEBSITE", "Intermediary Distribution": "INTERMEDIARY_DISTRIBUTION"},
     "new_values": [],
     "note": "Kept membership, labels unchanged. New users in 13: Issuer Proxy Pass-Through.Pass-Through Delivery Method."},
    {"shared": "Delivery Status", "local": "Delivery Status",
     "value_map": {"Pending": "PENDING", "Sent": "SENT", "Delivered": "DELIVERED", "Email Bounced": "BOUNCED",
                   "Returned Undeliverable": "RETURNED_UNDELIVERABLE", "Suppressed": "SUPPRESSED", "Failed": "FAILED"},
     "new_values": [],
     "note": "Kept membership, labels unchanged. Returned mail is mastered on Recipient Delivery Record (Returned Mail Date, Return "
             "Reason; CW-089)."},
    {"shared": "Case Status", "local": "Service Request Status",
     "value_map": {"Received": "NEW", "Pending Good Order": "PENDING_GOOD_ORDER", "In Progress": "IN_PROGRESS",
                   "Pending Third Party": "PENDING_THIRD_PARTY", "Completed": "RESOLVED", "Rejected": "REJECTED", "Canceled": "CANCELED"},
     "new_values": [],
     "note": "Kept membership ('13', 'Service Request Status'), values unchanged."},
    {"shared": "Reconciliation Status", "local": "Reconciliation Status",
     "value_map": {"Reconciled": "RECONCILED", "Exceptions Open": "BREAK_OPEN", "Not Reconciled": "NOT_RECONCILED"},
     "new_values": [], "note": "Kept membership, unchanged (steward 06)."},
    {"shared": "Cost Bearer", "local": "Cost Bearer",
     "value_map": {"Fund": "FUND", "Adviser": "ADVISER", "Shared Fund / Adviser": "SHARED_FUND_ADVISER",
                   "Service Provider": "SERVICE_PROVIDER", "Intermediary": "INTERMEDIARY", "Firm": "FIRM"},
     "new_values": ["FIRM"], "note": "Kept membership (13 is steward). New value Firm (the broker-dealer or adviser entity bearing the cost of an error on a non-fund account; review F). Used by the transitional fee invoice and by remediation."},
    # Memberships to remove at merge
    {"shared": "COLL Change Classification", "local": "", "value_map": {}, "new_values": [],
     "note": "REMOVE ('13', 'COLL Change Classification') from the members (shared_code_lists.py line 2618) and its value map (line "
             "2621): Shareholder Notice.Change Classification is removed (JURISDICTION, FCA). The steward 36 still holds the list "
             "(content_36 line 172 and 396) until its own US-only pass."},
    {"shared": "Data Quality Status", "local": "", "value_map": {}, "new_values": [],
     "note": "REMOVE ('13', 'Data Quality Status') from the members (shared_code_lists.py line 109): the list left with the excluded "
             "Record Metadata object (CD-160), which this draft drops from the module."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED CANDIDATES: local lists that look like enterprise lists
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Service Channel", ["13", "02", "04", "12"],
     "Assisted and self-service channels (Phone, Chat, Secure Message, Video, Email, Branch, Postal Mail, Website, Mobile App). "
     "02 Communication Channel, 04 engagement channels and 12 request channels overlap. Candidate shared 'Service Channel', steward 09."),
    ("Authentication Method", ["13", "04", "41"],
     "13 assisted-service methods (CW-086), 04 Digital Profile MFA factors and 41 authentication policy share authenticator types "
     "(NIST SP 800-63B). Candidate shared list stewarded by 41."),
    ("Mail Return Reason", ["13", "02"],
     "If 02 keeps a reason beside the Derived Mail Returned Date, it should read the 13 list (CW-089)."),
    ("Beneficial Owner Disclosure Status", ["13", "49", "29"],
     "OBO / NOBO under Rule 14b-1; 49 (record-date entitlements) and 29 (intermediary NOBO lists, after CW-088) may need it."),
    ("Voting Instruction Status", ["13", "34"],
     "34 Vote Instruction status for the funds' own votes and 13 pass-through instruction status share received / transmitted / late "
     "values; keep separate unless 34 agrees."),
    ("Client Statement Type", ["13", "15", "16"],
     "Statement kinds by account type; 15 Account Type and 16 participant statements may map to it. Renamed from Statement Type, which collided by name with the 42 list."),
    ("Metric Unit", ["13", "21"], "Seconds, Hours, Business Days, Percent, Count; the 21 Metric Unit shares Percent and Count."),
    ("Oversight Rating", ["13", "37"], "Satisfactory / Needs Improvement / Unsatisfactory, identical to the 37 Audit Rating values; transitional with Servicing Provider Engagement (to 29)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (decisions.TERM_CONFLICTS format), from the plan section 5.3 watchlist and what the draft found
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Household",
     "usages": [("02", "Household / Household Membership (PTY-HH-)", "Client Household: the people a client lives and plans with."),
                ("13", "Householding Group (MHG-)", "Mailing Household: accounts sharing an address for SEC Rule 154 delivery."),
                ("47", "Fee Household", "Accounts aggregated for fee breakpoints.")],
     "recommendation": "Never bare 'Household': 'Client Household' (02), 'Mailing Household' (13), 'Fee Household' (47). 13 "
                       "definitions say 'Mailing Household'; the object keeps its name Householding Group for its readers.",
     "resolution": "Three concepts kept distinct (CW-027).", "status": "Resolved", "decision": "CW-027"},
    {"term": "Confirmation",
     "usages": [("48", "Client Trade Confirmation (CCONF-)", "The Rule 10b-10 record of a client trade."),
                ("13", "Confirmation Delivery (AG of Investor Document, STMT-)", "Rendering and delivery of that record to the client."),
                ("26", "Trade Confirmation", "Institutional trade confirmation and affirmation of fund trades.")],
     "recommendation": "13 never says 'Trade Confirmation': the object is Confirmation Delivery and the document category value is "
                       "'Client Confirmation'; 48 names its object 'Client Trade Confirmation' (CCONF-, 48 brief); 26 keeps 'Trade Confirmation' for fund-side affirmation.",
     "resolution": "Record in 48, delivery in 13 (CW-081).", "status": "Resolved", "decision": "CW-081"},
    {"term": "Account",
     "usages": [("15", "Account (ACC-)", "Every client account, including fund-only accounts at the transfer agent."),
                ("29", "Shareholder register / omnibus accounts", "Register-side accounts of the transfer agent.")],
     "recommendation": "13 references 15 ACC- for every client account; register and omnibus records are 29's.",
     "resolution": "13 holds no account master.", "status": "Resolved", "decision": "CW-006"},
    {"term": "Position",
     "usages": [("49", "Client Holding (CLHLD-) / Client Corporate Action Entitlement (CLCAE-)", "Brokerage book of record; the record-date entitlement per issuer meeting and account."),
                ("06", "Fund Shareholder Position", "Units of the firm's funds held by an account."),
                ("13", "Issuer Proxy Pass-Through.Record Date Entitled Quantity", "Derived copy of 49 Client Corporate Action Entitlement.")],
     "recommendation": "13 holds no position. The transitional Intermediary Distribution Request.Beneficial Owner Position Count is a "
                       "count of beneficial-owner accounts; the 29 receiver at W3 may rename it 'Beneficial Owner Account Count'.",
     "resolution": "13 holds none; one Derived copy, qualified.", "status": "Resolved", "decision": "CW-007"},
    {"term": "Authentication",
     "usages": [("04", "Digital Profile (DIGP-) / login events", "Self-service logins and MFA."),
                ("13", "Interaction Authentication", "Authentication of a person contacting a representative."),
                ("02", "Identity Verification (KYCV-)", "CIP identity verification."),
                ("41", "IAM and authentication policy", "Controls.")],
     "recommendation": "Say 'assisted-service authentication' (13), 'digital login' (04), 'identity verification' (02).",
     "resolution": "Split by who authenticates (CW-086).", "status": "Resolved", "decision": "CW-086"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION (jurisdiction.REMOVALS entry format; CW-022). A whole removed object or code list has attribute "".
# ---------------------------------------------------------------------------------------------------------------------


def _j(obj, attr, regime, note):
    return {"domain": _D, "object": obj, "attribute": attr, "regime": regime, "decision": _C, "note": note}


JURISDICTION = [
    # Objects
    _j("UK & EU Tax Document", "", "Other EU/UK",
       "UK HMRC tax vouchers and offshore reporting fund statements (3 attributes: UK Distribution Type, Equalization Amount, "
       "Excess Reportable Income per Unit; the last two were Derived copies of 01). US information returns stay in Tax Form Record; "
       "foreign-person reporting (Form 1042-S) stays."),
    _j("EU/UK Investor Information Provision", "", "UCITS",
       "UCITS Directive and PRIIPs durable-medium provision of the KID / KIID, reports and notices (1 attribute: Provision Medium). "
       "US delivery is Delivery Method and E-Delivery Election under the SEC e-delivery releases."),
    _j("Notice Cascade", "", "Other EU/UK",
       "UK and EU platform and nominee cascade of fund notices to underlying investors (UK market practice under FCA COBS; 3 "
       "attributes: Cascading Platform / Nominee, Cascade Method, Cascade Confirmation Received Indicator). The US beneficial-owner "
       "path is the transitional Intermediary Distribution Request (Rule 14b-1)."),
    _j("UK Dormant Asset Transfer", "", "Other EU/UK",
       "UK Dormant Assets Act 2022 transfers to the Reclaim Fund (3 attributes: UK Dormant Asset Category, Gone-Away Period (Years), "
       "Reclaim Fund Transfer Date). US state escheatment stays in Dormancy Assessment and Escheatment Report & Remittance."),
    # Attributes of kept objects
    _j("Shareholder Notice", "Change Classification", "FCA",
       "FCA COLL 4.3 fundamental / significant / notifiable classification (13 membership of the shared COLL Change Classification, "
       "steward 36). Minimum Notice Period (Days) kept, re-sourced to SEC Rule 35d-1 and the fund's disclosed policy; Change "
       "Effective Date added."),
    _j("Shareholder Notice", "Free Redemption Window End Date", "UCITS",
       "UCITS merger free redemption right (Directive 2009/65/EC Article 45). No US successor."),
    # Whole code lists
    _j("Code list: UK Distribution Type", "", "Other EU/UK", "HMRC: Dividend Distribution, Interest Distribution, Accumulation - Dividend, Accumulation - Interest."),
    _j("Code list: COLL Change Classification", "", "FCA", "13 copy of the shared list (Fundamental, Significant, Notifiable, Not Applicable); steward 36 keeps it until its pass."),
    _j("Code list: Durable Medium Type", "", "UCITS", "Paper, Email / Electronic Document, Website (Consented), Platform Delivery (UCITS Directive / FCA Glossary)."),
    _j("Code list: Cascade Method", "", "Other EU/UK", "Electronic Notice to Platform, Paper Forwarded by Nominee, Made Available on Platform Website, Not Cascaded."),
    _j("Code list: UK Dormant Asset Category", "", "Other EU/UK", "CIS Unit Conversion Proceeds, CIS Distributions, CIS Redemption Proceeds, Orphan Moneys (Dormant Assets Act 2022)."),
    # Code values of kept lists
    _j("Code list: Investor Document Category", "Tax Voucher / Certificate", "Other EU/UK", "UK / EU tax vouchers."),
    _j("Code list: Investor Tax Document Type", "UK Tax Voucher", "Other EU/UK", "HMRC. The list is re-cut to the IRS set (1099 family, Consolidated 1099, 5498 family, 1042-S)."),
    _j("Code list: Investor Tax Document Type", "UK Consolidated Tax Certificate", "Other EU/UK", "HMRC."),
    _j("Code list: Investor Tax Document Type", "UK Excess Reportable Income Report", "Other EU/UK", "HMRC offshore reporting funds."),
    _j("Code list: Investor Tax Document Type", "EU Annual Tax Statement", "Other EU/UK", "Country-specific EU investor tax statements."),
    _j("Code list: Document Regulatory Basis", "FCA COBS 16", "FCA", "UK periodic reporting and confirmations; US basis is FINRA Rule 2231 and SEC Rule 10b-10."),
    _j("Code list: Document Regulatory Basis", "HMRC", "Other EU/UK", "UK tax vouchers."),
    _j("Code list: Shareholder Communication Type", "Annual Report (UCITS / UK)", "UCITS", "US annual reports are Tailored Shareholder Report - Annual."),
    _j("Code list: Shareholder Communication Type", "Half-Yearly Report (UCITS / UK)", "UCITS", "US semi-annual reports are Tailored Shareholder Report - Semi-Annual."),
    _j("Code list: Shareholder Communication Type", "KID (PRIIPs) / KIID (UCITS)", "PRIIPs", "PRIIPs KID and UCITS KIID; the US equivalent is the summary prospectus (Rule 498)."),
    _j("Code list: Communication Regulatory Basis", "UCITS Directive", "UCITS", ""),
    _j("Code list: Communication Regulatory Basis", "PRIIPs Regulation", "PRIIPs", ""),
    _j("Code list: Communication Regulatory Basis", "UK FCA COLL", "FCA", ""),
    _j("Code list: Audience Basis", "Platform / Nominee Holders", "Other EU/UK", "UK / EU platform and nominee registers (UK market practice)."),
    _j("Code list: Holding Model", "Platform Nominee", "Other EU/UK", "UK / EU platform nominee holding (UK market practice)."),
    _j("Code list: Reclaim Source", "UK Reclaim Fund", "Other EU/UK", "Dormant Assets Act 2022."),
    _j("Code list: Meeting Type", "Extraordinary General Meeting", "FCA", "UK / EU meeting form (FCA COLL 4.4). US special and annual meetings stay."),
    _j("Code list: Vote Standard", "Extraordinary Resolution", "FCA", "UK 75% of votes cast (FCA COLL 4.4). The 1940 Act majority stays."),
    _j("Code list: Fund Proposal Type", "Fundamental Change (COLL)", "FCA", "UK extraordinary resolution matter."),
    _j("Code list: Fund Proposal Type", "Approve Scheme of Arrangement", "Other EU/UK", "UK scheme of arrangement (UK market practice); US reorganizations stay as Approve Reorganization."),
    _j("Code list: Estate Document Type", "Grant of Probate (UK)", "Other EU/UK", "English probate; US letters testamentary and letters of administration stay."),
    _j("Code list: Shareholder Notice Type", "Dealing Suspension", "Other EU/UK",
       "UK dealing terminology (UK market practice); replaced by Redemption Suspension (Investment Company Act Section 22(e))."),
    # Sources
    _j("Sources", "HMRC guidance on fund distributions, equalization and offshore reporting funds", "Other EU/UK", "Cited only by the removed UK & EU Tax Document."),
    _j("Sources", "UCITS Directive 2009/65/EC, Chapter IX (Articles 68-82) and Article 43 (merger information)", "UCITS",
       "Report deadlines on Report Period End Date and Required Delivery Deadline now cite SEC Form N-CSR and Rule 30e-1 only."),
    _j("Sources", "FCA Handbook COLL 4.3 (approvals and notifications), COLL 6.6, COBS 16 and Glossary (durable medium)", "FCA",
       "COLL references on Meeting Type, Proposal Type, Vote Standard, Minimum Notice Period and Shareholder Approval Required "
       "Indicator, and COLL 6.6 on NAV Error Magnitude and Materiality Threshold, re-sourced to the Investment Company Act, SEC Rule "
       "35d-1 and the board-approved NAV error policy."),
    _j("Sources", "Dormant Assets Act 2022 and Dormant Assets Scheme expansion to investment and wealth management", "Other EU/UK", "Cited only by the removed UK Dormant Asset Transfer."),
    _j("Sources", "EU GDPR / UK GDPR (part of the combined source 'EU GDPR / UK GDPR; FCA DISP; FINRA Rules 2165 and 4530')", "GDPR / UK GDPR",
       "Linked Consent Record re-sourced to the E-SIGN Act; the GDPR-only Personal Data Indicator left with Record Metadata (CD-160). "
       "The combined source is kept as 'FINRA Rules 2165 and 4530'."),
    _j("Sources", "FCA DISP (part of the combined source 'EU GDPR / UK GDPR; FCA DISP; FINRA Rules 2165 and 4530')", "FCA",
       "Escalated Complaint and Dissatisfaction Expressed Indicator re-sourced to FINRA Rule 4530."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. REPOINTS (object, attribute, before, after, decision): the re-cut, rename and re-pointed references of the adaptation
#    that are not EU/UK removals. Readers of each are listed in NOTES.
# ---------------------------------------------------------------------------------------------------------------------
REPOINTS = [
    ("Trade Confirmation", "", "Trade Confirmation (AG of Investor Document)", "Confirmation Delivery (AG of Investor Document)", "CW-081"),
    ("Confirmation Delivery", "Confirmed Transaction", "Reference (Transaction) to 06 TXN-",
     "removed; replaced by Client Trade Confirmation (Reference (Client Trade Confirmation, 48), CCONF-) and Confirmed Fund Order (Reference (Fund Order, 29))", "CW-081"),
    ("Service Request", "Resulting Transaction", "Reference (Transaction) (multi) to 06 TXN-",
     "removed; replaced by Resulting Client Account Activity (49, CLACT-) and Resulting Money Movement (50, MMVMT-); Resulting Order (29) kept", "CW-007"),
    ("Transfer of Ownership & Estate", "Decedent", "Reference (Party)", "removed; Related Death Notification (02 DTHN-) holds the deceased party", "CW-089"),
    ("Transfer of Ownership & Estate", "Date of Death", "Date", "removed; the reported date of death is on 02 Death Notification, the confirmed date on 02 Individual", "CW-089"),
    ("Transfer of Ownership & Estate", "Beneficiary Allocation Percentage", "Percentage", "removed; the share is held on 15 Beneficiary Designation, referenced by Claimed Beneficiary Designation", "CW-089"),
    ("Service Request", "Escalated Complaint", "Reference (Complaint) to 08 Distribution Compliance", "Reference (Complaint, 08) to the W2 08 Retail Conduct & Supervision Complaint (CPL- kept)", "CW-070"),
    ("Service Request", "Servicing Provider", "Transfer agent or servicer processing the request (CDE)", "Vendor that processed an outsourced request; blank for in-house processing (CDE flag removed)", "CW-088"),
    ("Investor Document Definition", "Document Definition Code", "example US-QTR-STMT", "example BD-QTR-STMT", "CW-003"),
    ("Code list: Service Channel", "Mail; Shareholder Website; Mobile App", "Mail; Shareholder Website; Mobile App", "Postal Mail; Website (Self-Service); Mobile App (Self-Service)", "CW-086"),
    ("Code list: Requester Role", "Power of Attorney; Financial Professional", "Power of Attorney; Financial Professional", "Agent Under Power of Attorney; Firm Advisor (03)", "CW-023"),
    ("Code list: Service Request Type", "Beneficiary Designation Change", "Beneficiary Designation Change", "Beneficiary Change", "CW-089"),
    ("Code list: Maintained Data Element", "Rep / Dealer of Record", "Rep / Dealer of Record (NSCC Networking)", "removed (intermediary dealer of record is 05 at W4); Trusted Contact added", "CW-013"),
    ("Code list: QA Outcome", "Fail - Shareholder Impact", "Fail - Shareholder Impact", "Fail - Client Impact", "CW-001"),
    ("Code list: Document Suppression Reason", "RPO - Undeliverable Address", "RPO - Undeliverable Address", "Returned Mail - Undeliverable Address", "CW-089"),
    ("Code list: Mail Hold Reason", "Undeliverable Address (RPO); Shareholder Request", "Undeliverable Address (RPO); Shareholder Request", "Undeliverable Address (Returned Mail); Client Request (FINRA Rule 3150)", "CW-089"),
    ("Code list: Dormancy Trigger Basis", "Returned Mail (RPO)", "Returned Mail (RPO)", "Returned Mail", "CW-089"),
    ("Code list: Audience Basis", "Registered Holders", "Registered Holders", "Registered Fund Shareholders (with Brokerage Clients, Advisory Clients, Plan Participants added)", "CW-087"),
    ("Code list: Remediation Type", "Unit / Share Adjustment", "Unit / Share Adjustment", "Share Adjustment", "CW-001"),
    ("Code list: Shareholder Communication Type", "Privacy Notice", "Privacy Notice (content owned by 02)", "Initial Privacy Notice; Annual Privacy Notice; Revised Privacy Notice", "CW-087"),
    ("Code list: Document Regulatory Basis", "IRC Section 6042 / 6045 / 408; ERISA / IRA Custodial Agreement", "combined values", "IRC Section 6042, 6045, 6049, 408 and ERISA Section 105 as separate values", "CW-087"),
    ("Servicing Provider Engagement", "", "Outsourced TA oversight (CD-202)", "Transitional; moves to 29 at W3", "CW-088"),
    ("Intermediary Distribution Request / NOBO List Request", "", "13 beneficial-owner communications", "Transitional; move to 29 at W3", "CW-088"),
    ("Intermediary Communication Fee Invoice", "", "13 intermediary fee invoice", "Transitional; moves to 05 at W4", "CW-088"),
    # Fix pass (review 13_review.md, program-lead rulings 2026-10-14)
    ("Code list: Investor Document Category", "Trade Confirmation", "Trade Confirmation", "Client Confirmation (Confirmation Delivery of the 48 Client Trade Confirmation)", "CW-081"),
    ("Issuer Proxy Pass-Through", "Record Date Client Holding Quantity", "Derived copy of 49 Client Holding (CHL-)", "Record Date Entitled Quantity, Derived copy of 49 Client Corporate Action Entitlement (CLCAE-)", "CW-090"),
    ("Confirmation Delivery / Service Request / Escheatment Report & Remittance / Shareholder Remediation", "W3 examples", "CCF-, CAA-, CHL-, MMT- (plan anchors)", "CCONF- (48), CLACT- (49), CLCAE- (49), MMVMT- (50) as the W3 briefs reserve", "CW-081"),
    ("Servicing Error", "Correction Transactions", "Reference (Transaction) (multi), 06 TXN-", "Reference (Register Transaction, 29) (multi), RGTX-", "CW-122"),
    ("Proxy Campaign", "Shares Outstanding at Record Date", "Derived copy of 06", "Derived copy of 29 Share Register Balance", "CW-122"),
    ("Voting Choice Election", "Chosen Option Type", "Code set on the election (CDE)", "Derived copy of 34 Voting Policy.Voting Choice Option Type (CDE flag removed)", "CW-082"),
    ("Investor Document", "Delivery Status", "Delivery outcome of the document", "Summary of the document's Recipient Delivery Record (master of returned mail)", "CW-089"),
    ("Recipient Delivery Record", "", "communication distribution job x recipient account", "every delivery: distribution job x recipient account, or Investor Document x recipient (Delivered Investor Document added)", "CW-089"),
    ("Code list: Statement Type", "", "Statement Type", "Client Statement Type (name collision with 42)", "CW-001"),
    ("Code list: Beneficial Owner Disclosure Status", "Default Applied", "Default Applied", "removed; Disclosure Default Applied Indicator carries it", "CW-090"),
    ("Code list: Investor Tax Document Type", "Form 8937 Reference", "Form 8937 Reference", "removed (issuer form, not furnished by the firm; 49 cost basis adjustment source)", "CW-081"),
    ("Code list: Authentication Method", "", "Internal (aligned to NIST SP 800-63B authenticator types)", "Internal (firm assisted-service policy); Authentication Assurance Level (AAL1 to AAL3, NIST SP 800-63B-4) added", "CW-086"),
    ("Tax Form Record", "Tax Year", "Text", "Integer (YYYY)", "CW-001"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. DECISIONS: the US-only pass of 13 (pre-allocated by CW-022)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-913", "theme": "Scope", "title": "US-only pass of 13 Client Service & Communications (adapted from Investor Servicing & Shareholder Communications)",
     "domains": ["13", "02", "15", "29", "34", "36", "48", "49", "05", "08", "51"],
     "issue": "The wholesale 13 served the shareholders of an intermediary-held fund complex at an outsourced transfer agent, in the "
              "US and the EU/UK: it carried UK and EU tax vouchers, UCITS and PRIIPs durable-medium provision, FCA COLL change "
              "classifications and meeting forms, UK platform notice cascades and the UK Dormant Assets Scheme, and sourced "
              "complaints and consent to FCA DISP and GDPR.",
     "resolution": "Removed (39 JURISDICTION entries: 4 objects, 2 attributes, 5 whole code lists, 22 code values, 6 sources): objects "
                   "UK & EU Tax Document (UK Distribution Type, Equalization Amount, Excess Reportable Income per Unit), EU/UK Investor "
                   "Information Provision (Provision Medium), Notice Cascade (Cascading Platform / Nominee, Cascade Method, Cascade "
                   "Confirmation Received Indicator) and UK Dormant Asset Transfer (UK Dormant Asset Category, Gone-Away Period (Years), "
                   "Reclaim Fund Transfer Date); attributes Shareholder Notice.Change Classification (13 membership of the shared COLL "
                   "Change Classification ends) and Shareholder Notice.Free Redemption Window End Date; lists UK Distribution Type, COLL "
                   "Change Classification, Durable Medium Type, Cascade Method, UK Dormant Asset Category; HMRC, UCITS, PRIIPs, COLL, "
                   "COBS 16, platform-nominee, UK reclaim fund, extraordinary general meeting and resolution, scheme of arrangement, "
                   "grant of probate and dealing suspension values; the HMRC, UCITS Directive, FCA Handbook and Dormant Assets Act "
                   "sources and the GDPR and FCA DISP parts of the combined source. Also dropped (not jurisdiction): the excluded Record "
                   "Metadata object (CD-160) with its Data Quality Status list and the DCAM source. "
                   "Kept and re-sourced: Minimum Notice Period (Days) to SEC Rule 35d-1 and the fund's disclosed policy; Shareholder "
                   "Approval Required Indicator, Meeting Type, Proposal Type and Vote Standard to the Investment Company Act; NAV Error "
                   "Magnitude and Materiality Threshold Exceeded Indicator to the board-approved NAV error policy; Escalated Complaint "
                   "and Dissatisfaction Expressed Indicator to FINRA Rule 4530; Linked Consent Record to the E-SIGN Act; Tax Document "
                   "Type, Tax Year and Form Box Code to the IRS only; Report Period End Date and Required Delivery Deadline to Form N-CSR "
                   "and Rule 30e-1 only. Foreign-address clients, nonresident aliens and Form 1042-S stay. "
                   "Perspective: META title 'Client Service & Communications', subtitle 'Wealth manager (direct) | Scope: US'; overview "
                   "rewritten for the direct wealth manager with in-house contact center, transfer agent and self-clearing broker-dealer. "
                   "Adaptation (CW-081, CW-082, CW-086 to CW-090): Trade Confirmation renamed Confirmation Delivery and re-pointed to 48 "
                   "and 29; Service Request widened to every account type (Resulting Client Account Activity 49, Resulting Money "
                   "Movement 50, Request Business Line, Assisting Advisor 03); Transfer of Ownership & Estate re-pointed to 02 Death "
                   "Notification, 15 Beneficiary Designation and Account Restriction and 51 Estate Settlement Case; new objects "
                   "Interaction Authentication, Beneficial Owner Disclosure Election, Voting Choice Election (VCEL-) and Issuer Proxy "
                   "Pass-Through; returned mail mastered on Recipient Delivery Record; Shareholder Communication Type adds the "
                   "broker-dealer and adviser communications; four objects flagged transitional (CW-088). Counts (built, Record Metadata "
                   "excluded; after the review fix pass): 40 to 40 objects, 230 to 289 attributes, 70 to 92 CDEs (32%), 60 to 68 code lists, "
                   "36 to 60 relationships, 20 to 26 sources. W3 references keyed to CCONF- (48), CLACT- and CLCAE- (49) and MMVMT- (50); "
                   "correction transactions and shares outstanding read from the 29 register (CW-122).",
     "rationale": "CW-003 and CW-022: the firm is regulated and services clients in the US only, so UK and EU tax, disclosure, "
                  "notice, meeting and dormant-asset regimes have nothing to serve, while every generic servicing object stays with US "
                  "sources. Names are kept so that the 02, 15, 16, 19, 29, 34 to 37, 40 and 42 references and DP-106, DP-169, DP-244, "
                  "DP-176 and DP-210 keep resolving; DP-069, DP-070, DP-085 and DP-091 lose the removed columns (NOTES, READERS). Lever: "
                  "a UK extension restores the removed rows from wholesale-v1.0 through the jurisdiction register.",
     "action": "W2", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 8. NOTES for the W2 merge
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    # Readers of removed or renamed content. Lines as of 2026-10-14.
    "READERS OF REMOVED OR RENAMED 13 CONTENT. Data products: "
    "DP-069 specs_l_shareholder_vendor.py 89-99 (Change Classification in the Notice Period Met Rate; Shareholder Notice.Change Classification and Free Redemption Window End Date in "
    "the Free Redemption Window Check), 102-110 (Cascade Confirmation Rate on Notice Cascade), 118-120 (Shareholder Notice columns "
    "Change Classification and Free Redemption Window End Date; EU/UK Investor Information Provision.Provision Medium), 140 (Notice "
    "Cascade columns), 181 (text naming Notice Cascade); "
    "DP-070 specs_l_shareholder_vendor.py 264 (UK Dormant Asset Transfer columns); "
    "DP-085 specs_o_operations.py 316 (Transfer of Ownership & Estate.Date of Death), 328 (Service Request.Resulting Transaction), "
    "331-332 (Decedent, Date of Death, Beneficiary Allocation Percentage), 360 (rule text on Decedent, Date of Death and the "
    "allocation sum); "
    "DP-091 specs_o_operations.py 439-446 (Confirmation Timeliness Rate on Trade Confirmation), 449-451 (metric on UK & EU Tax "
    "Document.Excess Reportable Income per Unit), 464-465 (UK & EU Tax Document and Trade Confirmation columns, Confirmed "
    "Transaction), 497 (rule on Confirmed Transaction), 524 (text naming UK & EU Tax Document); "
    "DP-106 specs_e3_private_markets_product_range.py 810 (Shareholder Notice.Change Classification; its other 13 columns at 755, "
    "768-769, 808 and 812-813 are kept). "
    "Data models: models_c10_shareholder_ops.py 40-43 (Notice Cascade folded into the intermediary distribution entity), 73 "
    "(EU/UK Investor Information Provision), 149-153 and 192 (UK Dormant Asset Transfer), 591 (fk Decedent on Fact Service "
    "Request), 627 (UK & EU Tax Document), 637 and 671-673 (Fact Trade Confirmation on 13 Trade Confirmation, fk Confirmed "
    "Transaction); keys_g5_11_12_13_14.py 128, 142, 169, 171, 172, 407, 417, 427, 428 (superseded at WP2). "
    "Semantic models: sm_07_finance_profitability.py 291 (change_classification dimension of the DP-069 Shareholder Communication), "
    "839-840 (DP-069 Free Redemption Window Check and Cascade Confirmation Rate listed as excluded metrics). "
    "Not readers of 13 (checked): sm_09 line 598 and specs_e2_invops_a.py 634-781 read 26 Trade Confirmation; sm_12 line 166 and "
    "keys_e7_27_29.py 458 read 29 Fund Order.Resulting Transaction; specs_q_accounts_plans.py 53-89 read 15 Beneficiary Designation.",
    "READERS (disposition, proposal). DP-069: drop the Free Redemption Window Check and the Cascade Confirmation Rate and the removed "
    "columns; the Notice Period Met Rate can use the new Shareholder Notice.Change Effective Date instead of the 01 lifecycle date. "
    "DP-070: drop the UK Dormant Asset Transfer columns. DP-085: replace Decedent and Date of Death by Related Death Notification (join "
    "02 Death Notification), Beneficiary Allocation Percentage by Claimed Beneficiary Designation (15), Resulting Transaction by "
    "Resulting Client Account Activity (49, W3) or keep the DP-006 lookup through Resulting Order. DP-091: re-point Trade "
    "Confirmation to Confirmation Delivery (Confirmation Timing and Confirmation Sent Date keep their names; Confirmed Transaction "
    "becomes Client Trade Confirmation or Confirmed Fund Order) and drop the UK & EU Tax Document metric (CW-041 pending list). DP-106: "
    "drop Change Classification. Live readers DP-106 (other columns), DP-169 (Servicing Error, Shareholder Remediation), DP-244 "
    "(Service Request ID) and DP-176 and DP-210 (Servicing Provider Engagement, kept transitional) need no change at W2; DP-176 and "
    "DP-210 re-point to 29 at W3.",
    "Renames for the baseline check: object Trade Confirmation -> Confirmation Delivery (CW-081); family names Shareholder Service "
    "Requests & Interactions -> Client Service Requests & Interactions, Regulatory Shareholder Communications -> Regulatory Client "
    "Communications, Proxy Solicitation & Shareholder Meetings -> Proxy, Voting Choice & Shareholder Meetings, Beneficial-Owner "
    "Communications via Intermediaries -> Intermediary Beneficial-Owner Communications, TA Oversight & Servicing Quality -> Service "
    "Quality, Errors & Remediation (family codes kept). Attribute IDs are positional within a family and renumber in SV-SRQ, SV-STM, "
    "SV-COM, SV-DEL, SV-PRX, SV-BOC, SV-ESC and SV-TAO; readers use names.",
    "domains.py: DD_NAMES takes 'Client Service & Communications' at the W2 merge (domains.DISPOSITION already records it); the "
    "folder 13_Investor_Servicing_and_Shareholder_Communications and the workbook name are kept (output path unchanged); renaming "
    "them is a program-lead choice (01, 25, 28 precedent).",
    "decisions.PREFIXES: add VCEL- from proposals_w2_engagement.py (owner 13, Reserved). Until then Reference (Voting Choice Election) "
    "from 34 would resolve only by concept name; add a CONCEPT_OWNERSHIP row 'Voting Choice Election' (owner 13, VCEL-) and rows for "
    "Interaction Authentication, Issuer Proxy Pass-Through and Beneficial Owner Disclosure Election (owner 13, no prefix).",
    "LOCAL_RENAMES ('13', 'Service Request Type', 'Shareholder Service Request Type'): propose relabeling to 'Client Service Request "
    "Type' (the list now covers brokerage, advisory, participant and trust work types). NOT_MERGED ('13', 'Reclaim Status', ...) "
    "reason says '13 tracks shareholder tax reclaims': it tracks unclaimed property reclaims; reword.",
    "02 at the W2 merge (CW-089): Postal Address.Mail Returned Date becomes a Derived copy of 13 Recipient Delivery Record.Returned "
    "Mail Date; its note 'confirm the master with 13' can be closed. 02 Privacy Profile.Initial Privacy Notice keeps resolving to "
    "Shareholder Communication (COMM-); 13 adds the communication type value 'Initial Privacy Notice' for it.",
    "34 at W5 (CW-082): Voting Choice Option Type becomes a shared list (SHARED_MEMBERSHIPS above). 34 reads the 13 elections to vote "
    "pass-through shares; consider a Reference (Voting Choice Election, 13) on 34 Vote Rationale or Vote Instruction where Vote "
    "Decision Source is 'Pass-Through Voting Choice'. The Chosen Voting Policy example uses the 34 format VPOL-HOUSE-2026.",
    "W3 (48, 49, 50): references are keyed to the W3 brief reservations: Client Trade Confirmation (48, CCONF-), Client Account Activity "
    "(49, CLACT-), Client Corporate Action Entitlement (49, CLCAE-; Record Date Entitled Quantity on Issuer Proxy Pass-Through is its "
    "Derived copy) and Money Movement (50, MMVMT-). 29 (CW-122): Correction Transactions reference Register Transaction (RGTX-); "
    "Shares Outstanding at Record Date is a Derived copy of Share Register Balance. The issuer meeting is referenced from 17 Corporate Action Event (CAE-), which exists, rather than "
    "a 49 corporate action object (CW-090 says 'per the 49 brief'; CAX- is the 49 account transfer, not a corporate action).",
    "W3 (29) and W4 (05), CW-088: Servicing Provider Engagement, Intermediary Distribution Request (BOD-) and NOBO List Request move to "
    "29; Intermediary Communication Fee Invoice (IFI-) moves to 05. Their attributes are unchanged here except definitions; the "
    "receiver must rename Intermediary Distribution Request.Holding Model to 'Beneficial Owner Holding Model' and Beneficial Owner "
    "Position Count to 'Beneficial Owner Account Count' (binding instruction, program-lead ruling 7; bare 'Holding' and 'Position' "
    "are flagged by the wealth checklist) and re-point DP-069 'Intermediary Fee Cost per Position' (specs_l_shareholder_vendor.py "
    "line 52) in the same step. 40 line 80 and 19 line 236 references re-point with the objects.",
    "READERS (fix pass additions): content_29_transfer_agency_operations.py line 418 REL 'Trade Confirmation [13] confirms Fund Order "
    "(via Transaction [06])' names the renamed object (re-point to Confirmation Delivery with the W3 29 draft); "
    "data_models/models_c10_shareholder_ops.py lines 567-570 'Request Transaction Bridge' resolves the removed Service Request."
    "Resulting Transaction (re-point to Resulting Client Account Activity or drop with DP-085).",
    "LOCAL_RENAMES: add ('13', 'Good Order Status', 'Service Request Good Order Status') (name collision with the 16 contribution "
    "list); the proposed 'Client Service Request Type' relabel also resolves the 12 Service Request Type collision.",
    "Deferred (review B, Low): Service Request.Servicing Provider shares its name with the transitional Servicing Provider "
    "Engagement attribute; rename it 'Outsourced Processing Vendor' when the engagement moves to 29 at W3.",
    "08 (W2 sibling): Escalated Complaint references 'Complaint' (CPL-) per the 08 brief; resolves to 08 today through the CPL- prefix.",
    "03 (W2 sibling): Service Request.Assisting Advisor is typed Reference (Advisor, 03) with an EMP- example (the 03 brief keys the "
    "Advisor by EMP-); forced to 03 in enrich_13 OWNERSHIP_OVERRIDES because the EMP- prefix resolves to 20.",
    "51 (W2 sibling): Transfer of Ownership & Estate.Estate Settlement Case references Estate Settlement Case (51, ESTATE-). The engagement "
    "file's NOTES say 'EST-'; the 51 brief reserves ESTATE-, which this draft uses.",
    "16: example drift not edited (content_16 line 365, STMT-2027-1099R-0071188 does not follow STMT-<year>-<code, 2 characters>-"
    "<sequence, 7 digits>).",
    "Brief deviation: the brief asks for 'Request Channel' on Service Request; the kept Intake Channel is that attribute (re-cut list "
    "Service Channel), so no second channel attribute was added.",
    "Remaining grep hits for EU/UK terms in the module: none. 'Holding' appears only qualified ('Client Holding', 'Holding of Customer "
    "Mail' in the FINRA Rule 3150 title) and in the transitional Holding Model; 'Position' only in the transitional Beneficial Owner "
    "Position Count.",
]
