"""Consolidation proposals from Data Domain 45 - Financial Planning & Advice (wealth model W2 draft v0.1, 2026-10-14).

Proposal fragment only: the builder does not read it. The program lead merges accepted entries into decisions.py and
shared_code_lists.py at the W2 merge. Format follows CONTRACT.md in this folder. 45 is a new domain (CW-008): it has no
wholesale module, so JURISDICTION is empty and there is no CW-9NN decision (CW-022). The decisions this draft implements are
CW-008, CW-011, CW-024 and CW-042 to CW-046, CW-057 to CW-060 (proposals_w2_advice.py); no new boundary decision is needed.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones: none. The draft uses only the eight reservations of CW-059 (ADENG-, AVREV-, FGOAL-,
#    FPLAN-, AGAC-, PSCEN-, RECOM-, ROLV-) and other domains' registered or reserved prefixes. Key formats follow
#    proposals_w2_advice.PREFIX_FORMATS. Composite keys not listed in proposals_w2_advice.GRAIN_KEY_FORMATS are below.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

GRAIN_KEY_FORMATS = [
    ("Engagement Participant", "45", "<ADENG- id> / <PTY- id> / <participant role> / <effective from>", "ADENG-2026-004187 / PTY-104611 / Co-Client / 2026-02-09"),
    ("Goal Progress Snapshot", "45", "<FGOAL- id> / <as-of date>", "FGOAL-00412877 / 2026-09-30"),
    ("Plan Goal Inclusion", "45", "<FPLAN- client financial plan version id> / <FGOAL- id>", "FPLAN-0041877-03 / FGOAL-00412877"),
    ("Planning Cash Flow Input", "45", "<FPLAN- version id> / CF<item number>", "FPLAN-0041877-03 / CF7"),
    ("Planning Balance Sheet Item", "45", "<FPLAN- version id> / BS<item number>", "FPLAN-0041877-03 / BS2"),
    ("Planning Assumption Set", "45", "<firm assumption set code, e.g. House + year + quarter>", "House 2026Q3"),
    ("Aggregated Account Balance", "45", "<AGAC- id> / <as-of date>", "AGAC-00218840 / 2026-10-12"),
    ("Projection Year Result", "45", "<PSCEN- id> / <projection year>", "PSCEN-0041877-03-02 / 2041"),
    ("Recommendation Alternative", "45", "<RECOM- id> / <alternative number>", "RECOM-2025-0018342 / 1"),
    ("Recommendation Implementation Link", "45", "<RECOM- id> / <implementing record key>", "RECOM-2025-0018342 / ENRL-2025-0004418"),
    ("Rollover Option Comparison", "45", "<ROLV- id> / <rollover option>", "ROLV-2026-000917 / Roll Over to IRA"),
]

# CONCEPT_OWNERSHIP rows to add at merge (decisions.CONCEPT_OWNERSHIP tuple format). Recommendation and Financial Goal are
# also listed in proposals_w2_advice.NOTES; its 'Financial Plan (45, FPLAN-)' row is replaced by 'Client Financial Plan'.
CONCEPT_OWNERSHIP = [
    ("Advice Engagement", "45", "ADENG-", ["03", "04", "08", "15", "47"], "Advice relationship of a client or Client Household; delivery channel as an attribute (CW-044)."),
    ("Advice Review", "45", "AVREV-", ["15", "08"], "Includes the Rule 3a-4 annual contact; 15 reads the latest date as a Derived copy (CW-044). Not 12 Client Review, not 08 supervisory review."),
    ("Recommendation", "45", "RECOM-", ["15", "08", "46", "03", "04", "47"], "Reg BI or advisory recommendation with its best-interest evidence (CW-042)."),
    ("Financial Goal", "45", "FGOAL-", ["15", "32"], "Client goal; not the retired 07 Goal (GOL-) (CW-043)."),
    ("Client Financial Plan", "45", "FPLAN-", ["08", "15"], "Client financial plan and its versions, Client Financial Plan Version (FPLAN-<n>-<vv>); 19 keeps Financial Plan Version (FPL-) for enterprise budgets (program-lead ruling)."),
    ("Aggregated Account", "45", "AGAC-", ["02", "06"], "External account observed through aggregation; never a 49 Client Holding (CW-043)."),
    ("Planning Scenario", "45", "PSCEN-", [], "Plan version x scenario; projections are not performance (CW-046)."),
    ("Rollover Analysis", "45", "ROLV-", ["08", "16"], "PTE 2020-02 rollover analysis; the transaction is 16 DIST- (CW-045)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local lists carrying the exact name and labels of an enterprise shared list (subsets copied).
#    45 cannot cite 'Shared: <name>' directly until it is registered in each list's direct_users (taxonomy_builder.validate()
#    reports the list as undefined otherwise), so it keeps local copies like 02 and 15. At merge: register ('45', <name>) as a
#    member, or add '45' to direct_users and re-point the attributes to 'Shared: <name>'.
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Business Line", "local": "Business Line",
     "value_map": {"DB": "DB", "DA": "DA", "HA": "HA", "PF": "PF", "WR": "WR", "IA": "IA", "IC": "IC", "TR": "TR"},
     "new_values": [], "note": "Advice Engagement.Engagement Business Line; the eight CW-004 codes with the shared labels copied exactly. Register 45 as a direct user and re-point to 'Shared: Business Line' (ruling)."},
    {"shared": "Frequency", "local": "Frequency",
     "value_map": {"Weekly": "WEEKLY", "Fortnightly": "FORTNIGHTLY", "Monthly": "MONTHLY", "Quarterly": "QUARTERLY",
                   "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL", "On Event": "ON_EVENT", "Ad Hoc": "AD_HOC"},
     "new_values": [], "note": "Agreed Review Frequency, Planned Contribution Frequency, Cash Flow Frequency; subset."},
    {"shared": "Record Status", "local": "Record Status",
     "value_map": {"Draft": "DRAFT", "Active": "ACTIVE", "Paused": "PAUSED", "Inactive": "INACTIVE", "Retired": "RETIRED"},
     "new_values": [], "note": "Financial Plan.Financial Plan Status; subset."},
    {"shared": "Delivery Method", "local": "Delivery Method",
     "value_map": {"Paper Mail": "PAPER_MAIL", "Email - Notification with Link": "EMAIL_NOTIFICATION_LINK",
                   "Email - Attachment": "EMAIL_ATTACHMENT", "Secure Email": "EMAIL_SECURE", "Portal Posting": "PORTAL"},
     "new_values": [], "note": "Financial Plan Version.Plan Delivery Method; subset (the brief's 'plan delivery')."},
]

# Shared lists the brief named that the draft does not use, and why: Meeting Format (review channel uses Advice Delivery
# Channel, so the same fact is not coded twice; its 'Not Applicable - Written Consent' value is a board concept); Approval
# Status and Case Status (no approval or case object here; supervisory approvals are 08); Data Provider (the aggregation
# provider is a 02 party under a 14 license; add aggregator values at W5 if 14 wants them); Return Methodology (45 holds no
# return, CW-011); Information Classification (PII tiers are stated per object in Notes).

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: (local list, domains, note)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Advice Delivery Channel", ["45", "03", "13"],
     "CW-044: candidate shared list at W5 (Digital, Phone, Video, In Person, Hybrid). 13 Service Channel (Phone, Chat, Secure "
     "Message, Video, Email, Branch, Postal Mail) is a different dimension (medium of a service contact); map, do not merge."),
    ("Advice Capacity", ["45", "01"],
     "01 'Advisory Capacity' (Investment Adviser, Broker-Dealer, Trust Company Fiduciary, Dual Capacity) states the offering's "
     "capacity; 45 'Advice Capacity' states the capacity of an engagement or a recommendation (Investment Adviser Fiduciary, "
     "Broker-Dealer Reg BI, Dual Registrant - Both). One shared list stewarded by 01 with a value map is possible; the trust "
     "company value would then apply to 51 recommendations as well. 08 Supervisory Review capacity should use the same list."),
    ("Investment Profile Factor", ["45", "02", "08"],
     "The Reg BI / FINRA Rule 2111 investment profile factors; 02 Investor Profile attributes follow the same factors and 08 "
     "Best Interest Review Detail checks them. Steward 02."),
    ("Conflict Type", ["45", "08", "47", "38"],
     "Conflicts identified per recommendation (45) versus firm conflict inventory (38 conflict of interest register) and 08 "
     "incentive conflict review; align values (proprietary product, differential compensation, revenue sharing, cash sweep)."),
    ("Rollover Option", ["45", "16"],
     "16 participant services and rollover capture (W3) may need the same four options of FINRA Regulatory Notice 13-45."),
    ("Recommendation Type", ["45", "08", "03"],
     "08 Supervisory Review type values (recommendation, rollover, account type) and 03 Advisor Activity purpose should map to "
     "45 Recommendation Type."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (plan section 5.3 watchlist names; extends the entries CW-058 lists)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Plan (wealth model)",
     "usages": [("45", "Client Financial Plan (FPLAN-); Client Financial Plan Version (FPLAN-<n>-<vv>)", "A client's financial plan and its versions."),
                ("19", "Financial Plan Version (FPL-); Financial Plan Line", "Enterprise budget, forecast or long-range plan; unchanged."),
                ("16", "Retirement Plan", "Workplace plan recordkept by the firm."),
                ("02", "Retirement Plan (thin party identity)", "Plan as a party.")],
     "recommendation": "Program-lead ruling applied: 45 renames its objects 'Client Financial Plan' and 'Client Financial Plan Version' "
                       "(list 'Client Financial Plan Version Status'); 19 keeps 'Financial Plan Version' and 'Financial Plan Line'. "
                       "Extend the existing 'Plan (wealth model)' entry with the 45 names; the 'Budget / Plan' entry stands.",
     "resolution": "No unqualified primary sense; 'Client Financial Plan' (45), 'Financial Plan Version' (19 enterprise budget), 'Retirement Plan' (16).",
     "status": "Resolved", "decision": "CW-058"},
    {"term": "Plan Type / Plan Version Status / Plan Scenario (code lists)",
     "usages": [("19", "Shared: Financial Plan Type; Shared: Plan Version Status; Shared: Plan Scenario", "Enterprise budget lists."),
                ("45", "Client Financial Plan Type; Client Financial Plan Version Status; Planning Scenario Type", "Client planning lists.")],
     "recommendation": "Keep the 45 lists local under the qualified names used; never register 45 as a member of the 19 lists.",
     "status": "Resolved", "decision": "CW-058"},
    {"term": "Goal / Objective",
     "usages": [("45", "Financial Goal (FGOAL-)", "What a client wants to achieve."),
                ("07", "Goal (GOL-), retired", "Sales quota."),
                ("02", "Investment Objective", "Investor profile objective."),
                ("15", "Account Investment Objective", "Objective recorded for one account.")],
     "recommendation": "Primary sense in the wealth model: 'Financial Goal' (45). 'Goal' is never used bare; the 07 entry is retired with 07 (CW-013).",
     "status": "Resolved", "decision": "CW-043"},
    {"term": "Review / Assessment",
     "usages": [("45", "Advice Review (AVREV-)", "Periodic or Rule 3a-4 review with the client."),
                ("08", "Supervisory Review (per the 08 brief)", "Principal review of a recommendation or account."),
                ("12", "Client Review", "Institutional client review meeting."),
                ("51", "fiduciary review (per the 51 brief)", "Trust account review.")],
     "recommendation": "Qualify always: 'Advice Review' (45), 'Supervisory Review' (08), 'Client Review' (12).",
     "status": "Resolved", "decision": "CW-058"},
    {"term": "Rollover (wealth model)",
     "usages": [("16", "Distribution Request (DIST-) with Rollover Direction", "The rollover transaction."),
                ("45", "Rollover Recommendation (Recommendation of type Rollover) and Rollover Analysis (ROLV-)", "The advice and its PTE 2020-02 analysis.")],
     "recommendation": "Extend the existing entry with 'Rollover Analysis' (45).", "status": "Resolved", "decision": "CW-045"},
    {"term": "Scenario",
     "usages": [("45", "Planning Scenario (PSCEN-)", "Client plan projection run."),
                ("19", "Plan Scenario (shared list)", "Budget scenario."),
                ("31", "Stress Scenario (STRESS-)", "Portfolio loss scenario.")],
     "recommendation": "Add 'Planning Scenario' (45) to the existing entry; never 'Scenario' bare.", "status": "Resolved", "decision": "CW-058"},
    {"term": "Recommendation",
     "usages": [("45", "Recommendation (RECOM-)", "Reg BI or advisory recommendation to a client."),
                ("23", "Research Recommendation (RCOV-)", "Analyst view on a subject.")],
     "recommendation": "Program-lead ruling: in the wealth model the bare name 'Recommendation' is the 45 object (CW-042; 15 and 46 "
                       "type 'Reference (Recommendation, 45)'); 23 is always 'Research Recommendation'. Amend the existing entry's resolution.",
     "resolution": "Primary sense (wealth model): 45 Recommendation (RECOM-). 23 is qualified as 'Research Recommendation'.",
     "status": "Resolved", "decision": "CW-042"},
    {"term": "Engagement",
     "usages": [("45", "Advice Engagement (ADENG-)", "Advice relationship."),
                ("34", "Engagement (ENGM-)", "Stewardship engagement, the primary sense; ownership.py aliases bare 'engagement' to 34.")],
     "recommendation": "Always 'Advice Engagement' (45); add to the existing entry's qualified uses.", "status": "Resolved", "decision": "CW-044"},
    {"term": "Advisor (wealth model) / advisor of record",
     "usages": [("45", "Engagement Advisor; Recommending Advisor; Plan Preparer (20 EMP-)", "Who delivered this engagement, made this recommendation or prepared this plan."),
                ("03", "Party Coverage Assignment (per the 03 brief, CW-063)", "The household's advisor of record.")],
     "recommendation": "03 masters the advisor of record; 45 holds the advisor who acted on each advice record, which may differ "
                       "(a planner, a phone representative). 45 never names its attribute 'advisor of record'.",
     "status": "Resolved", "decision": "CW-044"},
    {"term": "Program (wealth model)",
     "usages": [("01", "Advice Program (Service Offering, OFFR-)", "The offering a client enrolls in."),
                ("15", "Program Enrollment (ENRL-)", "The account's enrollment."),
                ("46", "Managed Account Program", "Operational record of a Rule 3a-4 program."),
                ("50", "Sweep Program", "Cash sweep."),
                ("45", "Engagement Service Offering; Recommended Service Offering; Reviewed Program Enrollments", "45 references the 01 offering and the 15 enrollment; it masters no program.")],
     "recommendation": "Extend the existing entry: 45 never says 'program' bare; it names the 01 Advice Program or the 15 Program Enrollment.",
     "resolution": "No unqualified primary sense (existing entry); 45 uses the qualified names.",
     "status": "Resolved", "decision": "CW-058"},
    {"term": "Capacity",
     "usages": [("01", "Advisory Capacity", "Capacity of a service offering."),
                ("45", "Advice Capacity (Engagement Advice Capacity, Recommendation Capacity)", "Capacity of an engagement or a recommendation.")],
     "recommendation": "Keep both: the offering's capacity and the capacity of each advice act; see SHARED_CANDIDATES.",
     "status": "Resolved", "decision": "CW-042"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION: new domain, nothing removed (brief section 4a). The EU/UK concepts deliberately left out are recorded in
#    Source_Notes.md section 3 only.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = []

# No DECISIONS: no new boundary decision; no CW-9NN pass for a new domain.

# ---------------------------------------------------------------------------------------------------------------------
# 6. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "15 at the W2 merge (CW-042, CW-044): re-key the two RCO- examples to RECOM- (proposals_w2_advice NOTES); flag Program "
    "Enrollment.Rule 3a-4 Annual Contact Date as DERIVED '45': the latest Review Held Date of an Advice Review of type 'Rule 3a-4 "
    "Annual Contact' whose Reviewed Program Enrollments names the enrollment (ruling 4).",
    "Program-lead rulings applied in the fix pass: 45 objects renamed Client Financial Plan / Client Financial Plan Version (19 "
    "unchanged; the six plan-version overrides removed); Recommendation Implementation Link is a Derived index of the links held on "
    "15, 46 and 48 (CW-032), with a row rule; rollover alternatives, reasons and the PTE attestation are held once on the rollover "
    "objects and the Recommendation references the Rollover Analysis; house assumptions are one Planning Assumption Set referenced "
    "per plan version, client tax and longevity assumptions an attribute group of the version; Recommendation Capacity has two values.",
    "Re-keys made to sibling formats: 48 Client Order examples use CLORD-<YYYYMMDD>-<9 digits> (proposals_w3_brokerage; the plan "
    "anchor COR- is rejected); 51 Trust examples use TRUST- (CW-075); the 13 objects are cited by their exact names 'Contact Center "
    "Interaction' and 'Recipient Delivery Record' (the PTE 2020-02 documentation goes to one investor, not a mass Shareholder "
    "Communication).",
    "No 45 attribute points at an 08 retrospective review: 08 holds PTE 2020-02 retrospective-review findings as exceptions on Best "
    "Interest Review Detail; 45 keeps a relationship row only. The 08 draft already references RECOM- and ROLV-; the 03 draft already "
    "cites 'Advice Review'.",
    "Briefs still naming the rejected anchors: 03, 08 and 51 ('Advice Engagement (ADE-)', 'Recommendation (RCO-)') and the 13 brief's "
    "prefix-check line (RCO-, ADE-); the drafts use ADENG- and RECOM-.",
    "03 CW-063: 45 holds the employee who acted (Engagement Advisor, Recommending Advisor, Plan Preparer, Review Conducted By, Evidence "
    "Attester, Attesting Employee) as 20 EMP- references, never an advisor of record. Decide after the 03 merge whether these should "
    "reference the 03 Advisor object instead of 20 Employee.",
    "OWNERSHIP_OVERRIDES in enrich_45: the two 'Fee Schedule' references stay forced to 47 until the merge moves the Fee Schedule "
    "CONCEPT_OWNERSHIP row from 01 to 47 (CW-051) and registers CLFEE-; then remove them.",
    "Form CRS before an account exists (ruling 5): Best Interest Evidence holds Client-Level Form CRS Delivered Date and Version (45 "
    "record, SEC Rule 17a-3(a)(24)) beside the 15 account-keyed Account Disclosure Delivery; row rule in enrich_45. If 15 or 13 later "
    "master a party-keyed Form CRS delivery, re-type it as a reference.",
    "Future-owner references (W3): Client Order (48, now a Derived copy of the 48 link), Capital Market Assumption Set (24, "
    "natural-language example), Client Account Performance (32, natural-language example). Derived copies naming 49 (Client Holding "
    "values) and 50 or 16 (contributions) on Goal Progress Snapshot.",
    "Plan Fee Schedule (16) is referenced with a PFEE- example (PFEE- is Proposed for 16 without a PREFIX_FORMATS row); 16 should "
    "publish the format and an ID attribute on Plan Fee Schedule at W3.",
    "Account Disclosure Delivery (15) has no ID attribute; 45 cites it by the composite '<ACC-> / <disclosure type> / <version>'. "
    "If 15 adds a key, re-key the Best Interest Evidence example.",
    "Business Line, Frequency, Record Status and Delivery Method are local copies with the shared labels (SHARED_MEMBERSHIPS); register 45.",
    "Regulatory status: Rule 17a-3(a)(35) and the IA-5248 path were verified by the reviewer (confirm marks closed). Still to confirm: "
    "the DOL removal of the 2024 Retirement Security Rule (secondary sources: March 20, 2026, effective April 20, 2026; FR doc "
    "2026-05492 and 91 FR 13503 not confirmed), the DOL FAQ point that a level-fee fiduciary paid a new fee on rolled-over assets "
    "relies on PTE 2020-02, the best-execution element of the Impartial Conduct Standards; CFPB 12 CFR Part 1033 status.",
    "Local code lists: 39 (brief target 28 to 36): beyond the brief's set, Education Cost Basis, Healthcare Cost Basis, Investment "
    "Profile Factor, Plan Fee Data Source, On-Track Status, Rollover Analysis Status, and from the fix pass Recommendation Capacity "
    "(ruling 9) and Account Tax Treatment (ruling 10).",
]
