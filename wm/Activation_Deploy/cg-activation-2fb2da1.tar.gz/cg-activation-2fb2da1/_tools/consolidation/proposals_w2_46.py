"""Consolidation proposals from the W2 draft of Data Domain 46 Managed Portfolios & Rebalancing (wealth manager, new domain,
CW-009), 2026-10-14.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py and
shared_code_lists.py at the W2 merge. Formats follow CONTRACT.md in this folder. Decisions implemented: CW-006, CW-007,
CW-009 (proposals_wealth_w0.py), CW-031, CW-032 (proposals_wealth_w1.py), CW-047 to CW-050 and CW-057 to CW-060
(proposals_w2_advice.py, treated as accepted). New domain: no US-only pass decision (CW-022) and no JURISDICTION entries.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES (prefix, entity, owner domain, status, note) - decisions.PREFIXES format
# None beyond the eight reserved in proposals_w2_advice.py (MASGN-, DRFT-, ARBE-, TLH-, TPBAT-, TRPR-, CSHI-, MACP-), with the
# key formats published there (PREFIX_FORMATS). The other 46 objects keep composite keys; see KEY_FORMATS below.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

KEY_FORMATS = [
    ("Sleeve Assignment", "Composite: MASGN- / sleeve sequence, e.g. 'MASGN-000418822 / 2'", "No prefix."),
    ("Household Managed Group", "Composite: PTY-HH- / ACC- / effective from, e.g. 'PTY-HH-55012 / ACC-0049813 / 2025-11-10'", ""),
    ("Managed Account Target", "Composite: MASGN- / account target version, e.g. 'MASGN-000418822 / 7'", "Used as the example of every reference to it."),
    ("Account Target Override Line", "Composite: MASGN- / version / asset class or INS-", ""),
    ("Account Investment Constraint", "Composite: ACC- / CRX- or 51 trust term key / constraint type / effective from", ""),
    ("Rebalance Trigger Rule", "Composite: OFFR- [/ MDL-] / trigger type / effective from, e.g. 'OFFR-0012 / Threshold / 2026-01-01'",
     "The example starts with OFFR- (01); enrich_46 forces Account Rebalance Event.Triggering Rule to 'mastered here'."),
    ("Drift Assessment Line", "Composite: DRFT- / instrument asset class or INS-", ""),
    ("Model Change Implementation", "Composite: MDL- / from TGT- / to TGT-", ""),
    ("Account Tax Budget", "Composite: ACC- / tax year (as GRAIN_KEY_FORMATS in proposals_w2_advice.py)", ""),
    ("Substantially Identical Security Group", "Firm-defined group code (e.g. 'SPX500') / INS- / effective from", "No prefix (brief section 6)."),
    ("Wash Sale Control Window", "Composite: PTY-HH- or ACC- / security group code / window start, e.g. 'PTY-HH-55012 / SPX500 / 2026-09-05'; loss sales of one group on the same day merge into one window",
     "The GRAIN_KEY_FORMATS example in proposals_w2_advice.py reads 'PTY-HH-55012 / SIG-SP500 / 2026-10-05'. Change it at merge: "
     "SIG- is not a reserved prefix and the group code is firm-defined; the window start is 30 days before the 2026-10-05 sale."),
    ("Asset Location Decision", "Composite: PTY-HH- / asset class / ACC- / effective from", ""),
    ("Proposed Client Lot Selection", "Composite: TRPR- / 49 Client Tax Lot key (CTLOT-, 49 brief)", ""),
    ("Trade Proposal Exception", "Composite: TRPR- / pre-trade check type / raised timestamp", ""),
    ("Managed Account Composite Membership", "Composite: MACP- / ACC- / start date (as GRAIN_KEY_FORMATS)", ""),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local 46 lists carrying an enterprise shared list's exact name and values (copied 2026-10-14).
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Record Status", "local": "Record Status",
     "value_map": {"Draft": "DRAFT", "Proposed": "PROPOSED", "Pending": "PENDING", "Active": "ACTIVE", "Paused": "PAUSED",
                   "Inactive": "INACTIVE", "Deprecated": "DEPRECATED", "Retired": "RETIRED"},
     "new_values": [], "note": "Model Assignment.Assignment Status, Household Managed Group.Group Membership Status, Account Investment "
                               "Constraint.Constraint Status, Rebalance Trigger Rule.Rule Status, Managed Account Composite.Composite Status."},
    {"shared": "Approval Status", "local": "Approval Status",
     "value_map": {"Not Required": "NOT_REQUIRED", "Pending": "PENDING", "Approved": "APPROVED",
                   "Approved with Conditions": "APPROVED_WITH_CONDITIONS", "Retrospectively Approved": "RETROSPECTIVELY_APPROVED",
                   "Rejected": "REJECTED", "Expired": "EXPIRED", "Withdrawn": "WITHDRAWN"},
     "new_values": [], "note": "Managed Account Target.Target Approval Status; Substantially Identical Security Group.Group Policy Approval Status."},
    {"shared": "Frequency", "local": "Frequency",
     "value_map": {"Intraday": "INTRADAY", "Daily": "DAILY", "Weekly": "WEEKLY", "Monthly": "MONTHLY", "Quarterly": "QUARTERLY",
                   "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL", "On Event": "ON_EVENT"},
     "new_values": [], "note": "Subset. Rebalance Trigger Rule.Evaluation Frequency."},
    {"shared": "Order Side", "local": "Order Side",
     "value_map": {"Buy": "BUY", "Sell": "SELL"},
     "new_values": [], "note": "Subset (managed accounts do not sell short). Trade Proposal.Proposal Side. Participant fund exchanges "
                               "are a sell and a buy, released as 29 fund orders."},
    {"shared": "Lot Relief Method", "local": "Lot Relief Method",
     "value_map": {"FIFO": "FIFO", "LIFO": "LIFO", "High Cost": "HIGH_COST", "Low Cost": "LOW_COST",
                   "Specific Lot Identification": "SPECIFIC_LOT_IDENTIFICATION", "Tax-Optimized": "TAX_OPTIMIZED",
                   "Average Cost": "AVERAGE_COST"},
     "new_values": [], "note": "Tax Management Setting.Managed Sale Lot Selection Method. The account default stays 15 Cost Basis Election "
                               "(15 SHARED_CANDIDATES: Cost Basis Method to join this list). Steward 18 to widen the definition, which "
                               "reads 'how a managed portfolio relieves its own tax lots', to cover client-account sales (46, 49 Client "
                               "Lot Relief)."},
    {"shared": "Instrument Asset Class", "local": "Instrument Asset Class",
     "value_map": {"Equity": "EQUITY", "Fixed Income": "FIXED_INCOME", "Cash & Money Market": "CASH_AND_MONEY_MARKET",
                   "Multi-Asset": "MULTI_ASSET", "Real Assets": "REAL_ASSETS", "Commodity": "COMMODITY"},
     "new_values": [], "note": "Subset, descriptions copied unchanged (program lead ruling 3 on the 46 review: the list 24 targets and 49 "
                               "holdings use). Override Asset Class, Line Asset Class, Location Asset Class. Register 46 as a member; "
                               "01 Asset Class is the lever (Source_Notes SME question 9)."},
    {"shared": "Measurement Basis", "local": "Measurement Basis",
     "value_map": {"% of Market Value": "PCT_OF_MARKET_VALUE", "Absolute Amount": "ABSOLUTE_AMOUNT", "Count": "COUNT"},
     "new_values": [], "note": "Subset. Account Investment Constraint.Constraint Measurement Basis."},
]
# Business Line (CW-004) is not used: the program and its business line are read from the 01 service offering.

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: (local list name, likely users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Composite Exclusion Reason", ["46", "32"],
     "Stays a shared candidate (ruling 6). The first four 46 values carry 32's labels; 46 adds Significant Cash Flow and Not "
     "Fully Invested. One list, steward 32."),
    ("Holding Period Term", ["46", "18", "49"],
     "Ruling 6: 46 now cites the 18 list ('External (18 list Holding Period Term)') instead of holding a copy; register 46 (and 49 "
     "Client Tax Lot) as members when the list is made shared (steward 18 or 49; IRC section 1222)."),
    ("Account Discretion Type", ["46", "01", "15"],
     "01 Discretion Type describes the offering (Discretionary, Non-Discretionary, Not Applicable); 46 describes how discretion is "
     "exercised per account (Full, Limited - Rebalance Only, Non-Discretionary); 15 holds a Boolean. Named apart to avoid a same-name "
     "conflict; a shared hierarchy (offering level, account level) is a W5 candidate."),
    ("Regulatory AUM Classification", ["46", "38", "18"],
     "Form ADV Item 5.F; 38 files Form ADV and 18 institutional separate accounts count in the same RAUM. Steward 38."),
    ("Account Tax Treatment", ["46", "15", "45", "47"],
     "Taxable / Tax-Deferred / Tax-Exempt classification set by rule from 15 Account Registration Type; 45 projections and 47 billing "
     "(IRA fee payment) may want it. Candidate for 15 to steward as a derived attribute of the registration type."),
    ("Account Constraint Type / Constraint Implementation Rule", ["46", "24", "33"],
     "Renamed from the brief's 'Constraint Type' because 24 has a list of that name with portfolio construction values. Keep separate "
     "(NOT_MERGED): 24 constrains a portfolio's construction, 46 implements a client's restriction."),
    ("Account Target Override Reason", ["46"],
     "Renamed from the brief's 'Override Reason' (06 and 33 hold different lists of that name; 47 plans one)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (plan section 5.3 watchlist names and CW-058), decisions.TERM_CONFLICTS format
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Model",
     "usages": [("01", "Model Portfolio (MDL-)", "The model offered."),
                ("24", "Target Allocation Set (TGT-)", "The model's weights over time."),
                ("46", "Model Assignment (MASGN-); Model Change Implementation", "Which account follows which model; how a change reaches accounts."),
                ("37", "Model Inventory Entry (MODEL-)", "Quantitative models, including the rebalancing engine.")],
     "recommendation": "Bare 'Model' is not used in 46. 'Model Portfolio' (01), 'Model Assignment' (46), 'Model Inventory Entry' (37).",
     "decision": "CW-047"},
    {"term": "Program",
     "usages": [("01", "Service Offering (OFFR-)", "The advisory program offered."),
                ("15", "Program Enrollment (ENRL-)", "An account's enrollment."),
                ("46", "Managed Account Program (glossary)", "The 46 operation of a 01 advisory program; no object of that name; rules, batches and composites reference OFFR-.")],
     "recommendation": "Extend the existing Program entry with the 46 usage (CW-058)."},
    {"term": "Composite",
     "usages": [("01", "GIPS Composite (CMP-)", "Presented composite definition."),
                ("32", "Composite Membership", "GIPS composite x 18 portfolio x period."),
                ("46", "Managed Account Composite (MACP-); Managed Account Composite Membership", "Program x model composite of 15 client accounts.")],
     "recommendation": "Always qualify: 'GIPS Composite' (01), 'Managed Account Composite' (46). 32 computes returns for both.",
     "decision": "CW-050"},
    {"term": "Rebalance",
     "usages": [("24", "Rebalance Run (RBAL-)", "Fund and institutional portfolios in 18."),
                ("46", "Account Rebalance Event (ARBE-)", "One managed account's rebalance decision.")],
     "recommendation": "Always qualify: 'Rebalance Run' (24), 'Account Rebalance Event' (46).", "decision": "CW-058"},
    {"term": "Trade proposal",
     "usages": [("24", "Proposed Trade; Proposed Lot Selection", "18 portfolios; 18 LOT- lots."),
                ("46", "Trade Proposal (TRPR-); Proposed Client Lot Selection", "15 managed accounts; 49 Client Tax Lots.")],
     "recommendation": "Keep both names; 24 applies to 18 portfolios only after the W3 re-cut (CW-048).", "decision": "CW-058"},
    {"term": "Tax Budget",
     "usages": [("24", "Tax Budget", "Budget Portfolio rows (18) only after W3; Budget Account rows move to 46."),
                ("46", "Account Tax Budget", "Account x tax year for retail managed accounts.")],
     "recommendation": "At the W3 24 re-cut drop 24 Tax Budget.Budget Account; 46 Account Tax Budget is the account-level record.",
     "decision": "CW-048"},
    {"term": "Household",
     "usages": [("02", "Household (PTY-HH-)", "Client Household."),
                ("13", "Mailing Household (MHG-)", "Document householding."),
                ("47", "Fee Household", "Breakpoint aggregation."),
                ("46", "Household Managed Group", "Accounts of one 02 household managed together for asset location and wash-sale scope.")],
     "recommendation": "Extend the Household entry: 46 groups accounts of a 02 household; it is not a fourth household."},
    {"term": "Holding",
     "usages": [("49", "Client Holding", "Brokerage book of record."),
                ("46", "Drift Assessment / Drift Assessment Line", "Derived copies of 49 values with Holdings As-Of Timestamp; no holding mastered.")],
     "recommendation": "No new usage: 46 reads 49 Client Holding only (CW-007)."},
    {"term": "Order",
     "usages": [("48", "Client Order (CLORD-)", "Order a released brokerage 46 Trade Proposal becomes."),
                ("16", "Participant Investment Transfer (PEXC-)", "Transfer a released participant 46 Trade Proposal becomes; 16 nets it into the plan-level 29 Fund Order."),
                ("25", "Trade Order (TORD-)", "Fund desk orders.")],
     "recommendation": "46 holds the released order reference only (CW-049); bare 'Order' not used."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION: new domain, nothing removed (CW-022). The UK and EU concepts left out are listed in Source_Notes section 3.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = []

# 6. DECISIONS: none (new domain; the 46 decisions are CW-047 to CW-050 and CW-058 to CW-060 in proposals_w2_advice.py).
DECISIONS = []

# ---------------------------------------------------------------------------------------------------------------------
# 7. NOTES for the W2 merge
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Fix pass 2026-10-14 applied 00_Program/Rework/Reviews/46_review.md (1 High, 13 Medium, 18 Low) and program-lead rulings 1-10. "
    "Size: 8 families, 24 objects (23 BO, 1 AG), 236 attributes, 84 CDEs (36%), 37 code lists (30 local, 7 copies of shared "
    "lists), 43 relationships, 23 sources. Ownership: 61 references, 10 derived copies, 2 overrides, 3 row ownership rules, 0 unresolved.",
    "CONCEPT_OWNERSHIP rows to add (owner 46): Model Assignment (MASGN-; already in proposals_w2_advice NOTES), Managed Account "
    "Target, Account Investment Constraint, Drift Assessment (DRFT-), Account Rebalance Event (ARBE-), Account Tax Budget, Tax-Loss "
    "Harvest Decision (TLH-), Substantially Identical Security Group, Wash Sale Control Window, Trade Proposal (TRPR-), Trade "
    "Proposal Batch (TPBAT-), Managed Account Cash Instruction (CSHI-), Managed Account Composite (MACP-). Do NOT add a bare "
    "'Composite Membership' alias: it is 32 (18 portfolios).",
    "Sibling references, re-keyed to the sibling briefs (ruling 2): 45 Recommendation (RECOM-); 48 Client Order (CLORD-); 49 Client "
    "Tax Lot (CTLOT-) typed 'Reference (Client Tax Lot, 49)' so ownership.py does not resolve 'tax lot' to 18, with Derived copies "
    "of 49 Client Holding (CLHLD-) values, Client Lot Relief realized gains, Account Cash Balance and pending Client Account "
    "Activity (CLACT-); 16 Participant Investment Transfer (PEXC-); 51 Trust Term Provision (composite key on TRUST-); 52 Sub-Adviser "
    "Engagement (SADV-). 08 Sales Practice Alert (SPA-) appears in REL only. 50 Money Movement (MMVMT-) and 47 Fee Debit (FDBT-) "
    "are not referenced by attribute: each references the 46 CSHI- from its side (ruling 7; 47 Fee Debit.Cash Raise Instruction "
    "exists; the 50 brief lists 46 CSHI- as a movement source). REL keeps both relationships.",
    "Workplace route (ruling 1, High): a participant managed account proposal is released as a 16 Participant Investment Transfer "
    "(PEXC-), which 16 nets into the plan-level 29 Fund Order; the direct 29 route ('Plan Fund Exchange', Released Fund Order) is "
    "removed. TA-registered fund-only accounts are not managed in 46 programs (no route).",
    "For the 15 editor: Program Enrollment.Discretionary Authority Indicator stays the grant; 46 Model Assignment.Discretion Exercised "
    "is the per-account use of it. Model Assignment.Assigned Account must equal the enrollment's Enrolled Account (note on the "
    "attribute). Program Enrollment.Reasonable Restrictions (CRX- multi) and 46 Account Investment Constraint.Source Client Restriction "
    "hold the same CRX- keys from two sides: 15 records which restrictions the program accepted, 46 how each is implemented. Proposed "
    "row rule: every CRX- on a 46 constraint must appear in the enrollment's Reasonable Restrictions.",
    "For the 24 W3 re-cut (CW-048): drop Tax Budget.Budget Account; Proposed Trade and Proposed Lot Selection apply to 18 portfolios "
    "only; content_18 SMA Portfolio Detail.Tax Loss Harvesting Indicator and Tax-Aware Management Indicator then serve institutional "
    "separate accounts only, and the '15 Platform Program Enrollment' notes in content_18 re-point to 15 Program Enrollment and 46 "
    "Model Assignment. Tolerance precedence (ruling 8): override line tolerance > account tolerance > 24 Target Allocation Line "
    "Lower/Upper Tolerance Band > program trigger rule threshold.",
    "Asset class (ruling 3): drift, override and location lines use 17 Instrument Asset Class, the list of 24 targets and 49 holdings; "
    "the Line Target Weight row rule sums 24 lines by that class through the 17 instrument lookup. 01 Asset Class is the lever.",
    "Wash-sale scope (ruling 4): the window holds Controlled Accounts in Scope (blocked) and Monitored Accounts in Scope (flagged, "
    "never blocked: self-directed accounts and IRAs). The legal scope is the seller and spouse (IRS Publication 550) and the seller's "
    "own IRAs (Rev. Rul. 2008-5); other household members' accounts are not in scope.",
    "Sleeves (ruling 5): sleeves share the account target; the assigned model is an 01 multi-sleeve model whose 24 target set carries "
    "the sleeve weights. Target Sleeve Weight was dropped (it would copy 24). Lever: sleeve-grain targets, drift and proposals.",
    "Wash Sale Control Window GRAIN_KEY_FORMATS example in proposals_w2_advice.py uses 'SIG-SP500'; change to 'SPX500' (SIG- is not "
    "reserved; the group code is firm-defined).",
    "Brief local list names changed: 'Discretion Type' -> 'Account Discretion Type' (01 has 'Discretion Type' with other values), "
    "'Constraint Type' -> 'Account Constraint Type' (24), 'Override Reason' -> 'Account Target Override Reason' (06, 33). Added local "
    "lists not in the brief: Account Tax Treatment, Implementation Status, Proposal Execution Route. Record Status is used on Model "
    "Assignment, Household Managed Group and Account Investment Constraint with a documented subset of values (review C).",
]
