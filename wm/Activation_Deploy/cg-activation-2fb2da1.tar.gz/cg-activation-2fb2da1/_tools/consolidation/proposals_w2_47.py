"""Consolidation proposals from the W2 draft of Data Domain 47 Pricing, Fees & Billing (wealth manager, new domain, CW-012), 2026-10-14.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py,
shared_code_lists.py and jurisdiction.py at the W2 merge. Formats follow CONTRACT.md in this folder. Decisions implemented:
CW-012 (proposals_wealth_w0.py), CW-027, CW-028 (as amended by CW-901), CW-032, CW-036, CW-037 (proposals_wealth_w1.py) and
CW-051 to CW-056, CW-058 to CW-060 (proposals_w2_advice.py). The domain has no US-only pass of its own (CW-022): no CW-9NN
decision, and JURISDICTION is empty; the EU/UK example content of the five objects moved from 12 is listed in CW912_ITEMS for
the 12 adaptation at W4 (brief SME question 9, reference default CW-912).
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES  (prefix, entity, owner domain, status, note) - decisions.PREFIXES format
# None beyond the six reserved in proposals_w2_advice.py (CLFEE-, FEASG-, FHHG-, FCRUN-, FDBT-, FWV-) and the three transferred
# from 12 (BLA-, BIL-, BDP-; TRANSFER_PREFIXES of proposals_w2_advice.py). The other 47 objects keep composite keys below.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = [
    ("FADJ-", "Fee adjustment (adjusted invoice or account fee calculation x adjustment type x adjustment)", "47", "Proposed",
     "47 fix pass (review D, ruling 10): Fee Adjustment had no identifying attribute. Collision check 2026-10-15 against "
     "decisions.PREFIXES, every proposals_w*.py and every content module token: FADJ- is not used and no token is within one edit "
     "(ADJ- is not registered). Rejected: FAJ- (one edit from FA-), FEADJ- (longer, same stem)."),
]

PREFIX_FORMATS = [
    ("FADJ-", "47", "FADJ-<year>-<sequence, 6 digits>", "FADJ-2026-000214"),
]

KEY_FORMATS = [
    ("Fee Schedule Tier", "Composite: CLFEE- / tier sequence, e.g. 'CLFEE-0031-04 / 2'", "No prefix (brief section 6)."),
    ("Commission & Transaction Charge Rate", "Composite: CLFEE- / instrument charge category / charge channel, e.g. 'CLFEE-0012-07 / Listed Option / Online / Mobile'", ""),
    ("Account Service Fee Item", "Composite: CLFEE- / account service type, e.g. 'CLFEE-0040-02 / ACATS Transfer Out - Full'", ""),
    ("Fee Discount Rule", "Composite: CLFEE- / discount rule code, e.g. 'CLFEE-0031-04 / TIER-PREMIER-05'", ""),
    ("Fee Rate Override", "Composite: FEASG- / override effective from, e.g. 'FEASG-000418822 / 2026-04-01'", ""),
    ("Fee Household Membership", "Composite: FHHG- / ACC- / effective from, e.g. 'FHHG-0055012 / ACC-0049812 / 2026-03-01'", "As in GRAIN_KEY_FORMATS of proposals_w2_advice.py."),
    ("Account Fee Calculation", "Composite: FCRUN- / FEASG-, or FCRUN- / BLA- for an institutional mandate, e.g. 'FCRUN-2026M09-004 / FEASG-000418822'",
     "Amends GRAIN_KEY_FORMATS of proposals_w2_advice.py: mandates are calculated under their Billing Arrangement (NOTES item 3)."),
    ("Billable Asset Exclusion", "Composite: account fee calculation key / exclusion category / CLHLD- (or HLD- for a mandate, or 'cash', 'margin')", ""),
    ("Fee Calculation Exception", "Composite: account fee calculation key / fee exception type / raised date", ""),
    ("Fee Adjustment", "FADJ- (proposed, PREFIXES above)", "Replaces the composite key; closes the wholesale gap at keys_g5_11_12_13_14.py line 89."),
    ("Performance Fee Calculation", "Composite: BLA- / calculation period end, e.g. 'BLA-00655 / 2026-09-30'",
     "Closes the gap noted in keys_g5_11_12_13_14.py line 95 and models_c9_events_inst_intel.py line 307: the billing arrangement is now an attribute."),
    ("Performance Fee Terms", "Attribute group of Fee Schedule: CLFEE-", "Institutional mandate schedules only (ruling 2)."),
    ("Fee Debit", "FDBT-; event-based service charges use the month of the charge as the billing period, e.g. FDBT-2026M10-000418900", "Ruling 6: no new object."),
    ("Fee Disclosure Delivery", "Composite: PTY- (or ACC-) / fee disclosure type / CLFEE- / delivered date", ""),
    ("Fee Deduction Authorization", "Composite: ACC- / AAG-, e.g. 'ACC-0049812 / AAG-0013455'", "As in GRAIN_KEY_FORMATS of proposals_w2_advice.py."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED MEMBERSHIPS: local 47 lists carrying an enterprise shared list's exact name and values (copied 2026-10-14).
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Record Status", "local": "Record Status",
     "value_map": {"Draft": "DRAFT", "Proposed": "PROPOSED", "Pending": "PENDING", "Active": "ACTIVE", "Inactive": "INACTIVE",
                   "Deprecated": "DEPRECATED", "Retired": "RETIRED"},
     "new_values": [], "note": "Fee Schedule.Schedule Status, Fee Household Status, Fee Household Membership Status, Fee Deduction Authorization.Authorization Status (subset; Paused not used)."},
    {"shared": "Frequency", "local": "Frequency",
     "value_map": {"Monthly": "MONTHLY", "Quarterly": "QUARTERLY", "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL", "On Event": "ON_EVENT"},
     "new_values": [], "note": "Default Billing Frequency, Tier Fee Period, Service Fee Frequency, Billing Frequency (assignment and arrangement), Crystallization Frequency."},
    {"shared": "Reconciliation Status", "local": "Reconciliation Status",
     "value_map": {"Reconciled": "RECONCILED", "Reconciled within Tolerance": "RECONCILED_WITHIN_TOLERANCE", "Break Open": "BREAK_OPEN",
                   "Break Explained": "BREAK_EXPLAINED", "Not Reconciled": "NOT_RECONCILED"},
     "new_values": [], "note": "Fee Calculation Run.Fee Reconciliation Status (brief section 8 offered a local Fee Reconciliation Status or the shared list; the shared list was taken)."},
    {"shared": "Case Status", "local": "Case Status",
     "value_map": {"New / Received": "NEW", "In Progress": "IN_PROGRESS", "Waiting on Client": "WAITING_ON_CLIENT", "Escalated": "ESCALATED",
                   "Resolved / Completed": "RESOLVED", "Closed": "CLOSED", "Canceled": "CANCELED"},
     "new_values": [], "note": "Billing Dispute.Dispute Status. In 12 it used the local 'Request Status', itself a member of Case Status; the 47 copy uses the shared labels."},
    {"shared": "Performance Fee Basis", "local": "Performance Fee Basis",
     "value_map": {"Gross of Fees": "GROSS_OF_FEES", "Net of Fees": "NET_OF_FEES", "Gross and Net": "GROSS_AND_NET"},
     "new_values": [], "note": "Performance Fee Terms.Performance Fee Basis. Steward is 32 (program lead ruling, fix pass): 47 is a member, not the steward; this overrides the CW-054 wording that moved the steward from 12 to 47."},
    {"shared": "Delivery Method", "local": "Delivery Method",
     "value_map": {"Paper Mail": "PAPER_MAIL", "Email - Notification with Link": "EMAIL_NOTIFICATION_LINK", "Email - Attachment": "EMAIL_ATTACHMENT", "Portal Posting": "PORTAL"},
     "new_values": [], "note": "Fee Disclosure Delivery.Fee Disclosure Delivery Method (same subset as 15)."},
]
# Brief section 8 also listed Approval Status, Delivery Status, Business Line and Information Classification: not used. Approvals
# are recorded as an approver reference and date; delivery evidence is the delivered date (13 holds delivery outcomes);
# business line follows from Fee Schedule Type; no record classification is held (governance metadata is 21, CD-160).

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Fee Collection Method", ["47", "16"], "16 Plan Fee Schedule.Fee Payer (participant accounts pro rata, sponsor paid) overlaps 'Paid by Sponsor' and 'Deducted from Account'; one list, steward 47."),
    ("Billing Basis", ["47", "10"], "10 Fee Basis Source (Fund Accounting NAV, Custodian Valuation, 'Client Invoice (12 BIL-)') is the source of the basis, not the basis; keep separate but re-point the 10 value to 47 BIL-."),
    ("Fee Schedule Type", ["47", "01", "16"], "01 Fee Schedule Link Type and 16 Plan Fee Component name kinds of fee; candidates for one 'Fee Type' hierarchy at W5."),
    ("Account Service Type", ["47", "15", "50"], "15 Account Feature Type and 50 money movement types name the same services (wires, ACATS); 47 prices them."),
    ("Fee Waiver Type", ["47"], "Deliberately NOT a member of the shared 'Waiver Type' (steward 27, fund expense waivers). Record as NOT_MERGED: different concept (CW-055)."),
    ("Dispute Reason / Fee Exception Type", ["47", "08"], "08 complaint problem codes overlap fee dispute reasons; keep separate (FINRA problem codes are 08)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (plan section 5.3 watchlist names; CW-058)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Fee",
     "usages": [("47", "Fee Schedule (CLFEE-), Account Fee Calculation, Fee Debit, Fee Invoice (BIL-)", "What a client pays the firm."),
                ("01", "Management Fee, Other Ongoing Fees (FSCH-)", "Prospectus expense terms of the firm's funds."),
                ("27", "Fund Expense Accrual, Expense Cap & Waiver Accrual", "Fund-level expense accounting."),
                ("10", "Fee Revenue Record (FRR-)", "Recognized revenue."),
                ("16", "Plan Fee Schedule (PFEE-)", "Plan-level recordkeeping fee terms."),
                ("13", "Intermediary Communication Fee Invoice", "Fees invoiced to the firm by intermediaries for beneficial owner communications.")],
     "recommendation": "Bare 'Fee' is the client fee (47). Qualify the others: 'Fund Expense' (01, 27), 'Fee Revenue' (10), 'Plan Fee' (16), 'Intermediary Communication Fee' (13).",
     "decision": "CW-058"},
    {"term": "Fee Schedule",
     "usages": [("47", "Fee Schedule (CLFEE-)", "Client fee schedule x version; 01 Offering Fee Schedule Link resolves here."),
                ("01", "'Fee Schedule / Fee Terms' concept row (FSCH-); Management Fee.Fee Breakpoint Schedule", "Fund fee terms and the fund's own breakpoints."),
                ("16", "Plan Fee Schedule (PFEE-)", "Plan fee lines of a service arrangement."),
                ("27", "Fund Expense Accrual.Applied Fee Schedule (content_27 line 272, FSCH-00981-03)", "Means the 01 fund fee terms; typed Reference (Fee Schedule)."),
                ("35", "Agreement Fund Schedule.Fund Fee Schedule (content_35 line 235, FSCH-00981-03)", "Means the 01 fund fee terms; typed Reference (Fee Schedule)."),
                ("48", "'Client Fee Schedule (CLFEE-)' in the 48 brief (lines 71, 159)", "Means the 47 Fee Schedule; resolves to it."),
                ("10", "Performance Fee Record 'terms held in 01 Product' (content_10 line 68); REL 'Fee rate terms from 01' (line 510)", "Mandate fee and performance fee terms are 47 Fee Schedule (Performance Fee Terms); fund fee terms stay 01.")],
     "recommendation": "'Fee Schedule' = 47 CLFEE-. Re-cut the 01 concept row to 'Fund Fee Schedule' (CW-051); 16 keeps 'Plan Fee Schedule'. "
                       "Program lead re-types at the W2-W4 merge: 27 line 272 and 35 line 235 to Reference (Management Fee, 01), the 01 fund "
                       "fee terms object (family Fees, Charges & Costs, keyed FSCH-; or Reference (Fund Fee Schedule, 01) once the re-cut row "
                       "exists); the re-type ships with the CW-051 re-cut. The 48 'Client Fee Schedule' resolves to 47 Fee Schedule; fund "
                       "sales-charge breakpoints (48 Fund Order Detail breakpoint basis) are 01 share-class terms (Investor Transaction Charge), "
                       "not 47. The 10 drafter re-types content_10 lines 68 and 510 (listed for the record).",
     "decision": "CW-051"},
    {"term": "Waiver",
     "usages": [("47", "Fee Waiver (FWV-)", "Waiver or credit of a client fee."),
                ("10", "Waiver Record (WVR-)", "Accounting for fund fee waivers and expense reimbursements."),
                ("27", "Expense Cap & Waiver Accrual", "Daily fund-level application of caps and waivers."),
                ("33", "Guideline Waiver", "Waiver of an investment guideline.")],
     "recommendation": "Always qualify: 'Fee Waiver' (47, client), 'Fund Expense Waiver' (10, 27), 'Guideline Waiver' (33). The shared list 'Waiver Type' stays fund-level; 47 uses 'Fee Waiver Type'.",
     "decision": "CW-055"},
    {"term": "Household",
     "usages": [("02", "Household (Client Household, PTY-HH-)", "Party of type Household with effective-dated membership."),
                ("13", "Householding Group (Mailing Household, MHG-)", "Document householding."),
                ("47", "Fee Household (FHHG-)", "Accounts aggregated for fee breakpoints; references 02, may differ from it.")],
     "recommendation": "Extend the existing entry with the 47 name: Client Household (02), Mailing Household (13), Fee Household (47) (CW-027).",
     "decision": "CW-027"},
    {"term": "Invoice",
     "usages": [("47", "Fee Invoice (BIL-)", "Invoice the firm issues to a client for fees."),
                ("19", "Payable Invoice (APV-); Receivable Item", "Supplier invoices the firm pays; receivables (the Fee Invoice is the source document)."),
                ("13", "Intermediary Communication Fee Invoice", "Invoice the firm receives from an intermediary."),
                ("40", "Invoice Match Result", "Procurement matching."),
                ("13", "Intermediary Communication Fee Invoice (Applies To label 'Fee Invoice', content_13 lines 383-390; models_c10 key 'Fee Invoice ID')", "Label collides with the 47 object name; for the 13 editor.")],
     "recommendation": "Bare 'Invoice' is ambiguous: 'Fee Invoice' (47, issued), 'Payable Invoice' (19, received).",
     "decision": "CW-054"},
    {"term": "Billing Basis / Billable Assets",
     "usages": [("47", "Billing Basis, Billable Assets", "Value a client fee is charged on, after exclusions."),
                ("06", "Client assets / AUM", "Asset measures for reporting and service tiers."),
                ("10", "Fee Basis Average Assets", "Fund average net assets for fee revenue accrual.")],
     "recommendation": "'Billable Assets' is a 47 term; it is not AUM, client assets or regulatory AUM (46).",
     "decision": "CW-053"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 4b. AMENDMENTS to proposals_w2_advice.py (ruling 3): neither text names mandates as fee-schedule holders.
# ---------------------------------------------------------------------------------------------------------------------
AMENDMENTS = [
    {"file": "proposals_w2_advice.py", "where": "DECISIONS CW-052 resolution",
     "text": "47 masters Fee Schedule Assignment (FEASG-; program enrollment, account, advice engagement or plan service arrangement "
             "x schedule x period: fee-paying account, timing, frequency, fee household), Fee Rate Override, Fee Household (FHHG-; "
             "anchored on a 02 Client Household, PTY-HH-) and effective-dated Fee Household Membership. Institutional mandates are "
             "billed under their Billing Arrangement (BLA-), the contract that applies the Fee Schedule; billing basis is held once, on "
             "the Fee Schedule, with an override on the arrangement only where the contract departs from it; a mandate may carry a "
             "Fee Waiver through its arrangement. 47 never copies 02 membership; the 13 Mailing Householding Group (MHG-) is unrelated. "
             "Service tier discounts are Fee Discount Rules referencing the 01 tier code."},
    {"file": "proposals_w2_advice.py", "where": "PREFIXES FEASG- entity",
     "text": "Fee schedule assignment (program enrollment, account, advice engagement or plan service arrangement x schedule x period)"},
    {"file": "proposals_w2_advice.py", "where": "GRAIN_KEY_FORMATS 'Account Fee Calculation'",
     "text": "('Account Fee Calculation', '47', '<FCRUN- id> / <FEASG- id or BLA- id>', 'FCRUN-2026M09-004 / FEASG-000418822')"},
    {"file": "proposals_w2_advice.py", "where": "NOTES, shared-list candidates: 'Performance Fee Basis steward 12 -> 47'",
     "text": "Performance Fee Basis steward 12 -> 32 (program lead ruling, 47 fix pass); 47 joins as a member."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION: none. 47 is a new domain with US sources only (CW-022). The EU/UK content of the moved 12 objects was not
#    carried; it is listed in CW912_ITEMS (REMOVALS format) for the 12 US-only pass at W4.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = []

_D912 = "CW-912"
CW912_ITEMS = [
    {"domain": "12", "object": "Billing Arrangement", "attribute": "Billing Currency (example GBP)", "regime": "Other EU/UK", "decision": _D912,
     "note": "Example only: re-sourced to USD in 47; GBP stays a valid ISO 4217 value for nonresident institutional clients."},
    {"domain": "12", "object": "Fee Invoice", "attribute": "Billable Assets, Management Fee Amount, Performance Fee Amount, Invoice Total (GBP examples)", "regime": "Other EU/UK", "decision": _D912,
     "note": "Examples only: same figures in USD in 47 (USD 612,400,000; 643,020; 0; 631,020)."},
    {"domain": "12", "object": "Performance Fee Calculation", "attribute": "High-Water Mark Value, Calculated Performance Fee (GBP examples)", "regime": "Other EU/UK", "decision": _D912,
     "note": "Examples only: USD in 47."},
    {"domain": "12", "object": "Performance Fee Calculation", "attribute": "ESMA Performance Fee Guidelines (references of Hurdle Benchmark, High-Water Mark Value, Crystallized Indicator)", "regime": "UCITS", "decision": _D912,
     "note": "ESMA guidelines on performance fees in UCITS and certain AIFs (also AIFMD). Re-sourced in 47 to Advisers Act Rule 205-3 (qualified clients) and Internal."},
    {"domain": "12", "object": "Fee Adjustment", "attribute": "Adjustment Amount Value (example GBP)", "regime": "Other EU/UK", "decision": _D912, "note": "Example only: USD in 47."},
    {"domain": "12", "object": "Billing Dispute", "attribute": "Disputed Amount (example GBP)", "regime": "Other EU/UK", "decision": _D912, "note": "Example only: USD in 47."},
    {"domain": "12", "object": "Sources", "attribute": "ESMA Guidelines on performance fees in UCITS and certain AIFs", "regime": "UCITS", "decision": _D912,
     "note": "12 source row used by the moved Performance Fee Calculation; not carried to 47. 12 removes it at W4 unless another 12 object cites it."},
    {"domain": "12", "object": "Code list: Report Type", "attribute": "Cost & Charges Statement", "regime": "MiFID II", "decision": _D912,
     "note": "Not in the moved family (12 IS-RPD); listed because the 47 brief section 4a names the MiFID II ex-post costs and charges statement: not carried to 47, UK extension lever."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. DECISIONS: none (no pre-allocated CW-9NN for a new domain; CW-051 to CW-056 and CW-058 to CW-060 are in proposals_w2_advice.py)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = []

# ---------------------------------------------------------------------------------------------------------------------
# 7. NOTES for the W2 merge
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    # 1
    "Size after the fix pass (00_Program/Rework/Reviews/47_review.md and the program-lead rulings 1-11): 7 families, 23 objects (22 BO, "
    "1 AG: Performance Fee Terms), 240 attributes, 82 CDEs (34%), 31 code lists (25 local, 6 copies of shared lists), 46 relationships, "
    "18 sources. Before: 22 objects, 223 attributes, 68 CDEs, 28 code lists, 43 relationships, 16 sources. Ownership: 46 references, 3 "
    "derived copies (49 x2, 19), 0 unresolved; 18 OWNERSHIP_OVERRIDES (item 6). Attributes and lists exceed the brief's 230 and 28 because "
    "of the ruled additions (Performance Fee Terms, contract-level qualified client, event-based charges, Waiver Extent / Waiver Reason).",
    # 2
    "OBJECTS MOVED FROM 12 (CW-054), names and prefixes unchanged: Billing Arrangement (BLA-), Fee Invoice (BIL-), Performance Fee "
    "Calculation, Fee Adjustment, Billing Dispute (BDP-); all 34 wholesale attribute names kept. Changes: Applied Fee Schedule "
    "re-typed Reference (Fee Schedule, 47) with CLFEE- example; examples GBP -> USD; Fee Invoice.Billable Assets no longer a Derived "
    "copy of 06 (now the billed figure, ROW_OWNERSHIP); internal references re-typed from 'Reference (Invoice)' to 'Reference (Fee "
    "Invoice, 47)'; Dispute Status list 'Request Status' -> local copy of shared 'Case Status' (Resolved -> Resolved / Completed); "
    "Billing Basis values renamed from AUM to Value (Average Month-End AUM -> Average Month-End Value, Fixed Fee -> Flat, Average "
    "Daily AUM -> Average Daily Value, Period-End AUM -> Period-End Value, Beginning-of-Period AUM -> Beginning-of-Period Value); "
    "Fee Adjustment Type 'Fee Waiver' -> 'Waiver Credit', 'Overbilling Refund' added; Dispute Reason gains two values. Attributes "
    "added: Billing Arrangement (Billing Timing, Arrangement Fee-Paying Account, Payment Terms Days, Billing Entity, Billing "
    "Effective To); Fee Invoice (Invoice Fee Schedule Assignment, Invoice Bill-To Party); Performance Fee Calculation (Performance "
    "Fee Billing Arrangement, Performance Measurement Basis, Qualified Client Basis Indicator, Qualified Client Determination); Fee "
    "Adjustment (Adjusted Fee Calculation, Applied Fee Waiver, Related Billing Dispute, Credit Posting, Adjustment Approved By); "
    "Billing Dispute (Disputed Fee Calculation, Related Complaint). Applies To labels now use the object names (Fee Invoice, "
    "Performance Fee Calculation). The lead keeps one copy (47) at the W2 merge; the 12 drafter (W4) drops IS-BIL and its lists "
    "Billing Basis, Fee Collection Method, Payment Status, Fee Adjustment Type, Dispute Reason, and enrich_12.py lines 44-49, 59, 63.",
    # 3
    "Deviation from the brief (confirmed by the program lead, ruling 3): institutional mandates are not a Fee Schedule Assignment subject. The Billing Arrangement (BLA-) is "
    "the mandate's assignment of a Fee Schedule, so the mandate's schedule is held once; Account Fee Calculation keys on FCRUN- / "
    "FEASG- or FCRUN- / BLA-. Fee Schedule Assignment subjects are 15 Program Enrollment, 15 Account, 45 Advice Engagement "
    "(planning-only fees) and 16 Service Arrangement (plan fees, rates read from 16 Plan Fee Schedule). Billing Basis is held once, on "
    "the Fee Schedule; Billing Arrangement.Billing Basis (wholesale name kept) is now only an override where the contract departs from "
    "the schedule. A mandate may carry a Fee Waiver (Waived Billing Arrangement). Amend CW-052, the FEASG- PREFIXES entity and "
    "GRAIN_KEY_FORMATS in proposals_w2_advice.py as in AMENDMENTS.",
    # 4
    "READERS of the moved 12 objects to re-point from ('12', ...) to ('47', ...) at WP0. Data products: DP-067 "
    "(data_products/specs_k_events_institutional.py lines 175-219: Billing Arrangement, Fee Invoice, Performance Fee Calculation, "
    "Fee Adjustment, Billing Dispute; line 242 rule 'Applied Fee Schedule with a Fee Breakpoint Schedule or Management Fee Rate' reads "
    "01 fund terms and must read 47 Fee Schedule Tier; line 257 gap 'no payment terms' closes with Billing Arrangement.Payment Terms "
    "Days); DP-086 (specs_p_inst_intel_finance.py lines 34, 42, 100: Billing Arrangement); DP-243 (specs_e5_cross_area.py lines "
    "458-461, 507-509: Billing Arrangement, Fee Invoice, Billing Dispute); DP-042 (specs_e_comp_finance_service.py lines 545-547, "
    "576: Billing Dispute, Fee Invoice, Billing Arrangement); DP-195 (specs_e4_finance_tax_treasury.py line 377: 19 Receivable "
    "Item.Source Fee Invoice, resolves through BIL- once the prefix transfers). Data models: data_models/models_c9_events_inst_intel.py "
    "(DP-067 lines 211-307, Fact Fee Invoice, Fact Fee Adjustment, Fact Billing Dispute, Fact Performance Fee Calculation, Billing "
    "Arrangement; DP-086 lines 658-707), models_c3_comp_finance_service.py (DP-042 lines 446-552), models_e8c_cross_area.py (DP-243 "
    "lines 499-592), models_e8c_finance_tax_treasury.py line 407 (DP-195 note 'Source Fee Invoice (12)'); keys_g5_11_12_13_14.py "
    "lines 74-96 (keys; Performance Fee Calculation now keys on BLA- / Calculation Period End), line 253 (FEE_INVOICE constant), lines "
    "313-351 (FKs), lines 481-485 (Applied Fee Schedule gap: owner 01 -> 47, gap closes); keys_e7_19_21.py line 296 ((19, Receivable "
    "Item, Source Fee Invoice) -> ('47', 'Fee Invoice')); keys_e7_27_29.py line 536 and keys_e7_34_35.py line 421 (comments citing the "
    "same gap). Semantic model: semantic_model/models/sm_04_institutional_retirement.py lines 417-425 (DP-243 billing_arrangement, "
    "fee_invoice, billing_dispute). Content: content_19 lines 293 ('12 fee invoice'), 459 (Receivable Source Type 'Fee Invoice' "
    "description '12 BIL-') and 508 (REL 'Fee Invoice [12]'); content_10 line 459 (Fee Basis Source 'Client Invoice (12 BIL-)'); "
    "content_32 line 463 (REL 'Performance Fee Calculation [12]'). data_products/_catalog.txt regenerates. No wholesale attribute of "
    "the moved objects was removed in the fix pass; Billing Arrangement.Billing Basis changed meaning to an override of the schedule's "
    "basis (DP-067 line 175 must read Fee Schedule.Billing Basis when the override is blank).",
    # 4b
    "READERS of 'Reference (Fee Schedule)' that mean the 01 FUND fee schedule (review High 1, ruling 1). Program lead re-types at the "
    "W2-W4 merge to Reference (Management Fee, 01), the 01 fund fee terms object (family 'Fees, Charges & Costs', FSCH-, with Fee "
    "Breakpoint Schedule; or Reference (Fund Fee Schedule, 01) once CW-051 adds that concept row); the re-type must ship with the "
    "CW-051 re-cut, otherwise both resolve to the 47 client Fee Schedule: content_27 line 272 (Fund Expense Accrual.Applied Fee "
    "Schedule) and content_35 line 235 (Agreement Fund Schedule.Fund Fee Schedule). Downstream: DP-165 "
    "(data_products/specs_e3_fund_accounting_custody.py lines 304, 340; specs_e3_ta_fund_governance.py lines 901, 955), DP-140 "
    "(specs_e1_book_of_record.py line 1092), DP-166 (data_models/models_e8_book_of_record.py line 963), DP-191 "
    "(models_e8c_fund_accounting_custody.py line 342), DP-170 (models_e8c_ta_fund_governance.py line 697), keys_e7_27_29.py line 534, "
    "keys_e7_34_35.py line 419, semantic_model/models/sm_11_fund_accounting_custody_governance.py line 166 (SM-11, DP-165). For the "
    "record (the 10 drafter re-types them at W4): content_10 line 68 (Performance Fee Record 'terms held in 01 Product': a mandate's "
    "performance fee terms are now 47 Fee Schedule Performance Fee Terms) and line 510 (REL 'Fee rate terms from 01': mandate rates are "
    "47). For the 48 drafter (W3): the 48 brief's 'Client Fee Schedule (CLFEE-)' (lines 71, 159) resolves to 47 'Fee Schedule'; the "
    "48 Fund Order Detail 'breakpoint basis (Derived copy, 47)' (line 100) is a 01 share-class sales-charge term (Investor Transaction "
    "Charge), not 47.",
    # 5
    "CONCEPT_OWNERSHIP at merge (CW-051, CW-054): add Fee Schedule (47, CLFEE-), Fee Household (47, FHHG-), Fee Schedule Assignment "
    "(47, FEASG-), Fee Calculation Run (47, FCRUN-), Account Fee Calculation (47), Fee Debit (47, FDBT-), Fee Waiver (47, FWV-), Fee "
    "Disclosure Delivery (47), Fee Deduction Authorization (47); re-cut 'Fee Schedule / Fee Terms' (01, FSCH-) to 'Fund Fee "
    "Schedule'; change 'Fee Invoice (segregated mandates)' (12, BIL-) to 'Fee Invoice' owner 47 and add Billing Arrangement (47, "
    "BLA-) and Billing Dispute (47, BDP-). Transfer prefix owners BLA-, BIL-, BDP- 12 -> 47 (TRANSFER_PREFIXES).",
    # 6
    "OWNERSHIP_OVERRIDES in enrich_47.py: 16 attributes typed Reference (Fee Schedule, 47), (Billing Arrangement, 47), (Fee Invoice, "
    "47) or (Billing Dispute, 47) are forced 'mastered here' because the concept register still gives 'Fee Schedule' to 01 and the "
    "prefixes BLA-, BIL-, BDP- to 12. They become redundant once item 5 is merged; keep or remove.",
    # 7
    "For the 01 editor: 01 Performance Fee (line 332) says a mandate's performance fee is 47; the terms now exist in 47 Fee "
    "Schedule.Performance Fee Terms (rate, hurdle type and rate, high-water mark, crystallization frequency, performance period, "
    "Performance Fee Basis), and the qualified-client route, determination date and the Rule 205-3 thresholds in force sit on the "
    "Billing Arrangement (USD 1.4 million / USD 2.7 million from 2026-06-29; release IA-6961 to confirm). Offering Fee Schedule "
    "Link.Linked Fee Schedule (content_01 line 573) has the example 'Digital Advisor standard schedule 2026'; give it a CLFEE- example "
    "(e.g. CLFEE-0012-03). 01 Service Tier and Platform Product Availability.Transaction Fee Category are referenced, not copied "
    "(CW-028, CW-037); Instrument Charge Category now has one 'Mutual Fund' value and the 01 category distinguishes the cases (ruling 7). "
    "For the 15 editor (merge note, ruling 5): 15 Account Disclosure Delivery masters every delivery made at account opening, including "
    "the fee schedule, the Form ADV brochures, the Reg BI disclosure and Form CRS; 47 Fee Disclosure Delivery masters only fee-change "
    "notices, Form ADV Part 2 fee-section deliveries, updated commission and fee schedules and fee billing notices after opening "
    "(CW-056). 47 dropped its 'Reg BI Fee and Cost Disclosure' value. 15 REL 'Program Enrollment is referenced by fee schedule "
    "assignment [47]' resolves to Fee Schedule Assignment.Billed Enrollment.",
    # 8
    "Sibling references made (resolve by domain number in the type until the modules exist): 45 Advice Engagement (ADENG-; Fee Schedule "
    "Assignment.Billed Advice Engagement); 46 Managed Account Cash Instruction (CSHI-; Fee Debit.Cash Raise Instruction, held on the 47 "
    "side only since the 46 fix pass dropped Source Fee Debit, ruling 9); 49 Client Holding (CLHLD-; Billable Asset Exclusion.Excluded "
    "Client Holding), Client Account Activity (CLACT-; Fee Debit.Debit Posting, Fee Adjustment.Credit Posting) and Account Transfer "
    "(ACXF-; Fee Debit.Triggering Account Transfer), with Derived copies Account Valuation and Excluded Amount (49 Client Holding "
    "Valuation; 18 Portfolio Holding valuations for mandate rows, ROW_OWNERSHIP, ruling 4); 50 Money Movement (MMVMT-; Fee "
    "Debit.Triggering Money Movement, ruling 6); 08 Supervisory Review (PRNR-) and Complaint (CPL-). Examples follow the formats "
    "in proposals_w3_brokerage.py. 45 Recommendation (RECOM-) is not referenced: 45 reads 47 costs, not the reverse.",
    # 9
    "Performance Fee Basis steward: 32 (program lead ruling); 47 is a member (SHARED_MEMBERSHIPS) through Performance Fee "
    "Terms.Performance Fee Basis. This overrides the CW-054 wording (AMENDMENTS). Event-based account service charges (ruling 6) are "
    "Fee Debit rows with Charged Fee Type 'Account Service', the charged service type and schedule, and a reference to the triggering "
    "50 money movement or 49 account transfer; no new object or prefix. The own-fund credit (ruling 8) is held once, as Fee "
    "Schedule.Own-Fund Treatment, and applied as Account Fee Calculation.Own-Fund Credit Amount; Billable Asset Exclusion.Own-Fund Net "
    "Expense Ratio and the Discount Basis value 'Own-Fund Expense Credit' were removed.",
    # 10
    "EU/UK content of the moved objects: JURISDICTION is empty (new domain); the eight items for the 12 adaptation are in "
    "CW912_ITEMS (REMOVALS format, decision CW-912; brief SME question 9). If the lead prefers CW-054, change the decision field.",
]
