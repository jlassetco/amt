"""Consolidation proposals from the W2 draft of Data Domain 51 Trust & Estate Services (wealth manager; new, optional,
Light tier; CW-017, CW-075 to CW-079), 2026-10-14.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py,
jurisdiction.py and shared_code_lists.py at the W2 merge. Formats follow CONTRACT.md in this folder. Decisions implemented:
CW-017 (proposals_wealth_w0.py / decisions.py), CW-026, CW-035, CW-075 to CW-079 (proposals_w2_conduct.py, treated as accepted).
The brief names this file proposals_51.py; the assignment named it proposals_w2_51.py.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES (prefix, entity, owner domain, status, note) - decisions.PREFIXES format
# None beyond the five reserved in proposals_w2_conduct.py (TRUST-, TDRQ-, FIRV-, ESTATE-, TXRT-), whose key formats are
# in its KEY_FORMATS. The draft follows them: TRUST-000412, TDRQ-2026-00318, FIRV-2026-01204, ESTATE-2026-0031,
# TXRT-2025-000412. Trust Instrument Document, Trust Term Provision, Trust Role, Beneficial Interest, Principal and Income
# Allocation, Fiduciary Accounting Statement, Distribution Decision, Fiduciary Review Exception, Estate Settlement Task and
# Beneficiary Tax Allocation keep composite keys (grains in enrich_51.py).
# Resolver note: ESTATE- has six letters, so ownership.py's prefix regex ([A-Z]{2,5}-) never reads it; references to the
# estate case resolve through the explicit "(Estate Settlement Case, 51)" type instead. Siblings referencing ESTATE- (13)
# must type the domain number too.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# Key formats for proposals_w2_conduct.py KEY_FORMATS (program lead ruling 5 on the review): a new row for Trust Term
# Provision, which 46 Account Investment Constraint references, and a replacement for the TXRT- row.
KEY_FORMATS = [
    ("Trust Term Provision", "Composite: TRUST- / provision type / provision sequence / instrument version, e.g. 'TRUST-000412 / Distribution Standard - Principal / 1 / 3'",
     "Unique when a trust has several shares, standards or termination events of one type (Provision Sequence)."),
    ("TXRT-", "TXRT-<tax year of the year-end date, YYYY>-<entity: T + TRUST- sequence (6 digits) or E + ESTATE- year and sequence (8 digits)>, e.g. TXRT-2025-T000412, TXRT-2026-E20260031",
     "Replaces 'TXRT-<tax year>-<TRUST- or ESTATE- sequence>': an estate sequence is unique only within its ESTATE- year, and trust and estate returns were told apart only by digit count."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED MEMBERSHIPS: local 51 lists carrying an enterprise shared list's exact name and values (copied 2026-10-14).
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Case Status", "local": "Case Status",
     "value_map": {"New / Received": "NEW", "Pending Good Order": "PENDING_GOOD_ORDER", "In Progress": "IN_PROGRESS",
                   "Waiting on Client": "WAITING_ON_CLIENT", "Pending Third Party": "PENDING_THIRD_PARTY", "Escalated": "ESCALATED",
                   "Resolved / Completed": "RESOLVED", "Closed": "CLOSED", "Rejected": "REJECTED", "Canceled": "CANCELED"},
     "new_values": [],
     "note": "Trust Distribution Request.Request Status, Estate Settlement Case.Case Status, Estate Settlement Task.Task Status, Fiduciary Tax Return.Return Status."},
    {"shared": "Approval Status", "local": "Approval Status",
     "value_map": {"Not Required": "NOT_REQUIRED", "Pending": "PENDING", "Approved": "APPROVED",
                   "Approved with Conditions": "APPROVED_WITH_CONDITIONS", "Retrospectively Approved": "RETROSPECTIVELY_APPROVED",
                   "Rejected": "REJECTED", "Expired": "EXPIRED", "Withdrawn": "WITHDRAWN"},
     "new_values": [], "note": "Fiduciary Accounting Statement.Statement Approval Status."},
    {"shared": "Severity", "local": "Severity",
     "value_map": {"Low": "LOW", "Medium": "MEDIUM", "High": "HIGH", "Critical": "CRITICAL"},
     "new_values": [], "note": "Fiduciary Review Exception.Exception Severity."},
]
# Brief section 8 also listed Business Line, Record Status and Frequency: not used. Every 51 record is line TR (a
# certification-only trust is DB through its 15 account's business line), status lists are lifecycle-specific (Trust
# Status) and no recurrence is held (the review cycle is fixed by 12 CFR 9.6).

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Trust Role Type", ["51", "02"],
     "Brief section 8: candidate with 02 Party Relationship Type. Not a merge (02's list is a relationship list); a value map "
     "instead: Grantor / Settlor -> 'Grantor Of'; Trustee, Co-Trustee, serving Successor Trustee -> 'Trustee Of'. The map drives "
     "the 02 Derived row rule (CW-075)."),
    ("Beneficial Interest Type / Beneficiary Relationship", ["51", "15"],
     "15 Beneficiary Relationship and Beneficiary Class describe account beneficiary designations; 51 Beneficial Interest Type "
     "describes trust interests. Keep separate (term conflict Beneficiary); listed because the W1 15 proposals named 51."),
    ("Estate Role / Authority Type", ["51", "02"],
     "02 Authority Type holds Executor / Personal Representative and Estate Administrator as authority grants; 51 Estate Role is "
     "the trust company's capacity in a case. Align labels (Executor, Administrator) at W5."),
    ("Allocation Character", ["51", "47"],
     "47 may need the principal or income charge of a trustee fee on the fee debit; if so, share this three-value list (steward 51)."),
    ("Revocability / Account Registration Type", ["51", "15"],
     "15 Account Registration Type values 'Revocable Trust' and 'Irrevocable Trust' must agree with 51 Trust.Revocability for "
     "trusts with a 51 record; propose a consistency rule (51 governs; 15 re-registers when a revocable trust becomes irrevocable)."),
    ("Investor Tax Document Type (13)", ["13", "51"],
     "13 Tax Form Record is keyed by account; a Schedule K-1 (Form 1041) is per beneficiary per return. Ask 13 for a "
     "'Schedule K-1 (Form 1041)' document type and a beneficiary (02 party) key referencing 51 Beneficiary Tax Allocation."),
    ("Distribution Purpose", ["51", "16"],
     "16 hardship distribution reasons overlap Hardship / Emergency and Health / Medical; different rules (IRC 401(k) safe harbor "
     "vs trust standards). Candidate only."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (plan section 5.3 watchlist names; CW-078)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Trust",
     "usages": [("51", "Trust (TRUST-)", "The trust instrument, its terms, roles and interests."),
                ("02", "Party of type Trust", "The trust as an entity party: legal name, EIN, party roles."),
                ("16", "Plan trust", "The trust holding an employer plan's assets; not a 51 Trust."),
                ("01 / 35", "Collective investment trust (12 CFR 9.18)", "A fund, not a personal trust.")],
     "recommendation": "Bare 'Trust' in the glossary is the 51 instrument; qualify 'Trust Party' (02), 'Plan Trust' (16) and 'Collective Investment Trust' (01).",
     "resolution": "Primary sense: 51 Trust. Others qualified as above.", "status": "Proposed", "decision": "CW-078"},
    {"term": "Review",
     "usages": [("51", "Fiduciary Account Review (FIRV-)", "12 CFR 9.6 pre-acceptance, initial and annual reviews."),
                ("08", "Supervisory Review", "FINRA Rule 3110 supervision."),
                ("45", "Advice review", "Periodic advice or plan review."),
                ("38", "Compliance Program Review", "Rule 206(4)-7 / 38a-1 annual review.")],
     "recommendation": "Always qualified; 51 uses 'Fiduciary Account Review'.",
     "resolution": "No primary sense; every use qualified (CW-078).", "status": "Proposed", "decision": "CW-078"},
    {"term": "Beneficiary",
     "usages": [("51", "Beneficial Interest", "A beneficiary's interest in a trust."),
                ("15", "Beneficiary Designation (ABD-)", "Beneficiary of an IRA, TOD or plan account."),
                ("51", "Beneficiary Tax Allocation", "Schedule K-1 recipient."),
                ("02", "Party Relationship 'Trust Beneficiary Of'", "Derived copy of 51 Beneficial Interest for trusts with a 51 record (row rule).")],
     "recommendation": "Qualify: 'Trust Beneficiary' (51 Beneficial Interest) and 'Designated Beneficiary' (15). The beneficiary person is always a 02 party.",
     "resolution": "Person: 02 Party. Trust interest: 51 (02 Trust Beneficiary Of rows are Derived for trusts with a 51 record). Account designation: 15.", "status": "Proposed", "decision": "CW-078"},
    {"term": "Distribution",
     "usages": [("51", "Trust Distribution Request (TDRQ-) / Distribution Decision", "Discretionary trust distribution."),
                ("50", "Money Movement (MMVMT-)", "The payment; it names TDRQ- as its source."),
                ("16", "Distribution Request (DIST-)", "Plan distribution."),
                ("27", "Distribution Declaration (FDIV-)", "Fund income distribution.")],
     "recommendation": "Always qualified: 'Trust Distribution' (51), 'Plan Distribution' (16), 'Fund Distribution' (27); the payment is a 50 Money Movement.",
     "resolution": "No primary sense (existing register rule); 51 names its objects 'Trust Distribution Request' and 'Distribution Decision'.", "status": "Proposed", "decision": "CW-078"},
    {"term": "Case",
     "usages": [("51", "Estate Settlement Case (ESTATE-)", "Estate the trust company settles."),
                ("08", "Senior Investor Case (SNRC-)", ""), ("38", "AML Case", ""),
                ("02", "Death Notification (DTHN-)", "Estate handling start; not a case object.")],
     "recommendation": "Always qualified (CW-078).", "resolution": "No primary sense.", "status": "Proposed", "decision": "CW-078"},
    {"term": "Tax Return",
     "usages": [("51", "Fiduciary Tax Return (TXRT-)", "Form 1041 of a trust or estate."),
                ("19", "Corporate Tax Return (TAXR-)", "The firm's own returns.")],
     "recommendation": "Qualify 'Fiduciary Tax Return' and 'Corporate Tax Return'.", "resolution": "Both qualified (CW-076).", "status": "Proposed", "decision": "CW-076"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION: none. 51 is new and replaces no wholesale module (CW-079); nothing was removed.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = []

# ---------------------------------------------------------------------------------------------------------------------
# 6. DECISIONS: the US-only decision of 51 (pre-allocated CW-951, CW-022 / CW-079)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-951", "theme": "Scope", "title": "US-only pass of 51 Trust & Estate Services (new domain): no removals",
     "domains": ["51"],
     "issue": "CW-003 requires a US-only decision for every domain drafted in the program. 51 is new; the wholesale model had no trust domain.",
     "resolution": "No EU/UK object, attribute, code value or source existed, so JURISDICTION is empty. The draft is sourced to OCC 12 CFR Part 9 and the Comptroller's Handbook, the Uniform Trust Code, Uniform Directed Trust Act, Uniform Prudent Investor Act, Uniform Principal and Income Act and Uniform Fiduciary Income and Principal Act (state adoption: confirm), IRC Subchapter J, Treas. Reg. 1.671-4, IRS Forms 1041, 7004, 8855 and Schedule K-1 (Form 1041), FINRA Rule 3241 and state trust and probate codes (lever). Foreign trusts stay (foreign trust status under IRC 7701(a)(31) is read from 02 Tax Profile.US Person Indicator of the trust party; a foreign situs is a Situs Jurisdiction value); nonresident beneficiaries stay through 02.",
     "rationale": "US only narrows where the firm is regulated and serves clients, not the trusts and beneficiaries it may serve. A UK extension (bare trusts, the HMRC Trust Registration Service) would add values and an object, not restore any.",
     "action": "W2 merge: merge this decision; no REMOVALS entries", "status": "Proposed", "priority": "Low", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. NOTES for the W2 merge
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Fix pass 2026-10-14 applied 00_Program/Rework/Reviews/51_review.md (1 High, 12 Medium, 18 Low) with the program-lead rulings. "
    "Draft size after the fix: 7 families, 15 objects (10 business objects, 5 attribute groups), 143 attributes, 41 CDEs (29%), 27 "
    "code lists (24 local, 3 shared copies), 40 relationships, 15 sources; 22 references, 5 derived copies, 0 unresolved.",
    "02 at merge (CW-075, CD-289; ruling 1: 51 masters every trust relationship): Party Relationship.Relationship Type rows "
    "'Trustee Of', 'Grantor Of' and 'Trust Beneficiary Of' become Derived rows of 51 for trusts with a 51 Trust record. Add a "
    "ROW_OWNERSHIP rule on ('Households & Relationships', 'Party Relationship', 'Relationship Type') in enrich_02.py: 'Trustee Of' "
    "from Trust Role Type Trustee, Co-Trustee, Directed Trustee and serving Successor Trustee (Role Effective From set); 'Grantor Of' "
    "from Grantor / Settlor; 'Trust Beneficiary Of' from current Beneficial Interest rows; only rows whose holder is a 02 party "
    "(Role Holder Party). Rows held by the trust company (09 internal legal entity) derive nothing in 02. Mastered in 02 for trusts "
    "without a 51 record. 51 holds the matching rules on Trust Role.Trust Role Type and Beneficial Interest.Beneficial Interest Type.",
    "15 at merge (CW-075; ruling 3): Account Registration Detail.Governing Trust example 'TRS-000412' re-keys to 'TRUST-000412'; "
    "the CW-035 wording '51 the trust terms (TRS-)' reads TRUST-. 51 masters the certification facts for every trust it records, "
    "including certification-only trusts (rule on Trust Instrument Document.Certification of Trust Received Date): 15 Account "
    "Registration Detail 'Trust or Agreement Date' and 'Registration Jurisdiction' become Derived copies of 51 (instrument version 1 "
    "Execution Date; Trust Situs Jurisdiction) for accounts with a Governing Trust; add them to enrich_15 DERIVED ('51') with a "
    "row rule (mastered in 15 for non-trust registrations). The Account Agreement type 'Trust Certification' stays a 15 agreement "
    "record that references the trust.",
    "Ruling 4: Trust.Firm Fiduciary Capacity, Trust Company Entity and Foreign Trust Indicator were dropped. The firm's capacity is "
    "the Trust Role rows held by the trust company (Role Holder Entity, 09 LEN-; new Trust Role Type value Directed Trustee); a "
    "trust with no such row is certification-only. Foreign trust status is 02 Tax Profile.US Person Indicator of the Trust Party.",
    "Ruling 2, 49 / 50 (W3): examples re-pointed to the reserved prefixes CLACT- (49 Client Account Activity, "
    "CLACT-20260105-0004551201) and MMVMT- (50 Money Movement, MMVMT-2026-00481120). The distribution-to-payment link is held "
    "once, on the 50 side: the 50 Money Movement names the 51 Trust Distribution Request (TDRQ-) as its source (50 brief), so "
    "Distribution Decision.Distribution Payment was dropped; the REL row stays. Principal and Income Allocation keeps Source "
    "Account Activity (49) and Source Money Movement (50) and gains an Allocation Date.",
    "Register TRUST-, TDRQ-, FIRV-, ESTATE-, TXRT- (proposals_w2_conduct.py PREFIXES) and a CONCEPT_OWNERSHIP row "
    "('Trust / Trust Instrument', '51', 'TRUST-', ['02', '15', '13', '46'], 'Trust instrument, terms, roles and interests'); the "
    "name avoids the bare token 'instrument' (17). In proposals_w2_conduct.py KEY_FORMATS replace the TXRT- row and add the "
    "Trust Term Provision row (KEY_FORMATS above).",
    "13 brief / drafter: Service Request / Transfer of Ownership & Estate references Estate Settlement Case as 'Reference (Estate "
    "Settlement Case, 51)' (ESTATE- is not read by the prefix resolver); its example ESTATE-2026-00042 has a 5-digit sequence "
    "where KEY_FORMATS has 4 (ESTATE-2026-0042). Tax Form Record needs a Schedule K-1 (Form 1041) document type and a beneficiary "
    "key (SHARED_CANDIDATES). Trustee Report Delivered Date on the Fiduciary Accounting Statement is a Derived copy of the 13 "
    "communication's delivery date.",
    "46 brief: Account Investment Constraint's 'source ... 51 trust term' is 'Reference (Trust Term Provision, 51)' with the "
    "composite key in KEY_FORMATS above; only rows with Investment Constraint Indicator = Y are read.",
    "47 brief: trustee and estate administration fees are 47 (Fee Schedule type 'trust administration'); 51 allocates the "
    "principal and income charge through the 49 activity (CLACT-) that posts the 47 Fee Debit (no direct 51 attribute; REL only).",
    "03: Trust.Administering Trust Officer is 'Reference (Advisor, 03)' with an EMP- example, forced to 03 by OWNERSHIP_OVERRIDES "
    "(EMP- alone resolves to 20). The workbook shows '03 Sales' until domains.py takes the 03 Advisor Organization name at the "
    "merge (lead). 03 Channel Referral has no attribute naming a trust outcome: 51 adds a REL row (Trust is referred from "
    "Channel Referral [03]); the 03 drafter may add a 'Resulting Trust' reference (Reference (Trust, 51)). 08 Senior Investor Case "
    "gets a REL row from Trust Distribution Request (the link held by 08).",
    "Decision makers and reviewers are 20 EMP-; the trust committee is a 39 Corporate Governing Body (CGOV-).",
    "Lows not applied: Fiduciary Tax Return.Return Status keeps the shared Case Status as a work status (definition says so; "
    "filing evidenced by Return Filed Date and Extended Due Date) - lead may add a Return Status list; Trust Distribution Request "
    "'requested by' not added (Purpose Description plus the 13 intake request; Light scope); the 03 domain name in domains.py is "
    "the lead's.",
    "Unverified (confirm): OCC 60-day initial post-acceptance review practice (the rule says 'prompt'); whether and how far OCC "
    "Bulletin 2008-10 is superseded by Bulletin 2014-3; the 2015 Personal Fiduciary Activities booklet path; UFIPA adoption by "
    "state and its section numbers (203, Article 3); UPIA 104; Uniform Law Commission act page URLs; Schedule K-1 (Form 1041) "
    "box numbers for the current year; Form 7004 extension length for Form 1041; FINRA Rule 3241 effective date (February 15, "
    "2021, Regulatory Notice 20-38); Delaware Title 12 chapter references.",
]
