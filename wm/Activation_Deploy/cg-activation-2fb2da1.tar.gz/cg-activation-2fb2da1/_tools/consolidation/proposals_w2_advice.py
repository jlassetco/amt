"""Wealth-manager reference model: W2 brief decisions for 45, 46 and 47 (CW-042 to CW-060), reserved prefixes and key formats.

Written by the W2 advice brief agent with the briefs in 00_Program/Rework/Briefs/ (45_Financial_Planning_and_Advice.md,
46_Managed_Portfolios_and_Rebalancing.md, 47_Pricing_Fees_and_Billing.md). Format: the DECISIONS dict format, the
PREFIXES tuple format and the PREFIX_FORMATS tuple format of decisions.py (CONTRACT.md). Declarative only. Every decision
is "Proposed" until the program lead merges it; each states the tailoring lever where a client could rule differently.
New domains have no US-only pass (CW-022): no CW-945 to CW-947 decision and no JURISDICTION entries here.
"""

PL = "Program lead"
P = "Proposed"

DECISIONS = [
    # ---- 45 Financial Planning & Advice -----------------------------------------------------------------------------
    {"id": "CW-042", "theme": "Ownership", "title": "The Recommendation and its best-interest evidence are mastered once, in 45; key RECOM- replaces the plan anchor RCO-",
     "domains": ["45", "15", "08", "46", "02"],
     "issue": "CW-008 gives 45 the recommendation and its Reg BI and fiduciary evidence; 15 already references 'Recommendation' (45) from Program Enrollment.Source Recommendation and Account Opening.Originating Recommendation with RCO- examples. The plan anchor RCO- is one insertion from RCOV- (23, Registered) and an anagram of COR- (the 48 anchor).",
     "resolution": "45 masters Recommendation (RECOM-; type, Reg BI or adviser capacity, source advisor or algorithm, subject client and accounts, recommended offering, model, share class or instrument, plan version, channel, presented date, client decision), Recommendation Rationale (attribute group), Recommendation Alternative, Best Interest Evidence (recommendation x obligation component: Reg BI disclosure, care, conflict of interest, compliance; Advisers Act duty of care and loyalty; profile version relied on by reference to 02 INPR-) and Recommendation Implementation Link (to 15 ENRL- or ACC-, 46 MASGN-, 48 client order, 16 DIST-). The object name 'Recommendation' is kept exactly. No other domain stores a rationale, a best-interest flag or a cost comparison; 08 references 45 for surveillance and supervisory review. RCO- is not registered: at the W2 merge the two 15 examples are re-keyed (RCO-2025-0018342 -> RECOM-2025-0018342, RCO-2024-0007719 -> RECOM-2024-0007719); the key registry entries in keys_g6_15_16.PENDING_REFS resolve by name and are unchanged.",
     "rationale": "One evidence chain per recommendation (review_checklist_wealth section 4); a prefix that cannot be misread as a 23 research coverage or 48 client order key. Lever: a self-directed-only firm drops 45 (CW-008).",
     "action": "W2 (45 draft); W2 merge (15 example re-key)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-043", "theme": "Ownership", "title": "Goals, financial plans, planning inputs and aggregated external accounts are 45 (amplifies CW-024)",
     "domains": ["45", "02", "15", "49", "14", "24"],
     "issue": "02 holds the Investor Profile with an Outside Investable Assets Band; 15 the Account Investment Profile; 49 will hold client holdings; account aggregation brings balances from other institutions; the wholesale register gives the concept 'Goal' to the retired 07 (GOL-).",
     "resolution": "45 masters Financial Goal (FGOAL-), Goal Funding Link (goal x 15 account or aggregated account), Retirement Income and Education Goal Detail, Goal Progress Snapshot, Financial Plan (FPLAN-) and Financial Plan Version, Plan Goal Inclusion, Planning Cash Flow Input, Planning Balance Sheet Item, Planning Assumption Set, Aggregated Account (AGAC-; under a 02 Consent Record, provider licensed in 14) and Aggregated Account Balance. 02 keeps the stated band; 45 holds observed external balances, which are never Client Holdings (49). Assets at the firm appear on 45 objects only as Derived copies of 49 with an as-of date. Capital-market assumptions are referenced from 24. The register concept is 'Financial Goal' (45), distinct from the retired 'Goal' (07, GOL-).",
     "rationale": "Goals and planning inputs change with the plan, not with the client profile or the account. Lever: a firm without aggregation drops Aggregated Account and its balance.",
     "action": "W2 (45)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-044", "theme": "Ownership", "title": "Advice engagements and reviews, including the Rule 3a-4 annual contact, are 45; delivery channel is an attribute",
     "domains": ["45", "02", "15", "13", "03"],
     "issue": "Rule 3a-4 requires the sponsor to contact each managed-account client at least annually about changes in financial situation or objectives; 15 Program Enrollment holds Rule 3a-4 Annual Contact Date and 02 Investor Profile has the trigger value Rule 3a-4 Annual Contact. Without a rule the contact is held three times. Plan section 15 item 4 makes delivery channel an attribute.",
     "resolution": "45 masters Advice Engagement (ADENG-; client or household x engagement: type, advice capacity, delivery channel, advisor of record, offering, advisory agreement reference to 15 AAG-), Engagement Participant and Advice Review (AVREV-; engagement x review: type including Rule 3a-4 annual contact, dates, channel, profile version confirmed or created, outcome, 13 interaction). 02 records the resulting profile version; at the 15 merge Program Enrollment.Rule 3a-4 Annual Contact Date becomes a Derived copy (45) of the latest Advice Review of that type. The quarterly Rule 3a-4 notice is a 13 communication. Advice Delivery Channel (Digital, Phone, Video, In Person, Hybrid) is a local 45 list proposed as a shared list for 03 and 13 at W5.",
     "rationale": "The contact is an advice event with its own evidence; its effects are a profile version (02) and a date the account reads. Lever: a firm that runs the annual contact as a 02 profile refresh drops the review type.",
     "action": "W2 (45); W2 merge (15 Derived copy flag)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-045", "theme": "Ownership", "title": "Rollover analyses and PTE 2020-02 documentation are 45; the rollover transaction stays 16",
     "domains": ["45", "16", "08", "15", "02"],
     "issue": "The term-conflict register names Rollover (16 transaction; 45 Rollover Recommendation). The rollover analysis needs plan fees and amounts that 16 masters for recordkept plans and that come from collected disclosures for external plans. The DOL Retirement Security Rule (2024) was stayed in July 2024 and is reported removed in 2026, restoring the 2020 PTE text (confirm).",
     "resolution": "45 masters Rollover Analysis (ROLV-; a Recommendation of type Rollover x analysis: source plan, 16 membership, amount and plan fee data as Derived copies of 16 or as collected 404(a)(5) disclosures, best-interest reasons, fiduciary status basis), Rollover Option Comparison and PTE 2020-02 Documentation (attribute group: fiduciary acknowledgment, services and conflicts disclosure, reasons documented, Impartial Conduct Standards attestation). 16 keeps the Distribution Request (DIST-) and rollover direction; 15 the receiving IRA; 08 the supervisory review and the firm's annual retrospective review under PTE 2020-02.",
     "rationale": "Advice evidence per rollover is a 45 fact; the distribution is a plan transaction. Lever: a firm that gives no rollover advice drops the family.",
     "action": "W2 (45), W3 (16 references)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-046", "theme": "Ownership", "title": "Planning scenarios and projection results are 45; capital-market assumptions are 24, engines 37, returns 32",
     "domains": ["45", "24", "32", "37"],
     "issue": "Monte Carlo projections look like performance and use the same capital-market assumptions as 24's allocations; certified Personal Rate of Return is 32 (CW-011).",
     "resolution": "45 masters Planning Scenario (PSCEN-; plan version x scenario), Goal Projection Result and Projection Year Result: forward-looking results of a plan. The capital-market assumption set is referenced from 24 (W3 family); the planning engine is a 37 Model Inventory Entry (MODEL-); historical returns, including the personal rate of return shown in goals-based reports, are 32 by reference and never mastered in 45.",
     "rationale": "Projections and returns answer different questions and have different owners and controls. Lever: a firm using a vendor engine records the vendor in 37 only.",
     "action": "W2 (45), W3 (24, 32 families)", "status": P, "priority": "Medium", "owner_role": PL},

    # ---- 46 Managed Portfolios & Rebalancing ------------------------------------------------------------------------
    {"id": "CW-047", "theme": "Ownership", "title": "Model assignment, account targets and constraints are 46; model weights stay 24, the model 01, enrollment 15",
     "domains": ["46", "01", "24", "15", "02", "51"],
     "issue": "Four records describe a managed account's investment: the model offered (01 MDL-), its weights (24 TGT-), the enrollment (15 ENRL-) and the account's own deviations and restrictions (02 CRX-).",
     "resolution": "46 masters Model Assignment (MASGN-; account x model x period, keyed from the 15 enrollment, with discretion and the Form ADV Item 5.F regulatory AUM classification), Sleeve Assignment, Household Managed Group, Tax Management Setting (including the tax-loss-harvesting election, the 15 brief's SME default), Managed Account Target (the 24 target set version applied plus overrides), Account Target Override Line and Account Investment Constraint (sourced from 02 Client Restriction or a 51 trust term). 46 never re-masters model weights.",
     "rationale": "Rule 3a-4 individualization is an account-level record; weights are an investment decision. Lever: a firm with household-level assignment keys Model Assignment on the household.",
     "action": "W2 (46)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-048", "theme": "Ownership", "title": "Account-level tax management of retail managed accounts is 46; 24 Tax Budget and proposed trades keep 18 portfolios only",
     "domains": ["46", "24", "18", "49"],
     "issue": "24 Tax Budget has a Budget Account (ACC-) reference and 24 Proposed Trade and Proposed Lot Selection reference 18 portfolios and 18 LOT- lots, written for individuals' SMAs. In the wealth model a retail managed account is a 15 account held in 49, and its lots are 49 client tax lots.",
     "resolution": "46 masters Account Tax Budget, Tax-Loss Harvest Decision (TLH-), Substantially Identical Security Group, Wash Sale Control Window (IRC section 1091; household scope including IRAs, Rev. Rul. 2008-5) and Asset Location Decision; lots are referenced as Client Tax Lot (49), never 18 LOT-. At the W3 24 re-cut, Tax Budget drops Budget Account and keeps Budget Portfolio for institutional separate accounts in 18; Proposed Trade and Proposed Lot Selection apply to 18 portfolios only.",
     "rationale": "One owner per account's tax management; the three books of record stay distinct (CW-007). Lever: a firm without tax management drops the family.",
     "action": "W2 (46), W3 (24 re-cut)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-049", "theme": "Ownership", "title": "Trade proposals end at release to 48; managed-account cash instructions go to 50",
     "domains": ["46", "48", "49", "50", "47", "25"],
     "issue": "Rebalancing and harvesting generate trades for many accounts at once, and withdrawals, deposits and fee debits require cash to be raised or invested.",
     "resolution": "46 masters Trade Proposal Batch (TPBAT-), Trade Proposal (TRPR-), Proposed Client Lot Selection, Trade Proposal Exception (including principal and cross-trade flags under Advisers Act section 206(3)), Account Rebalance Event (ARBE-), Drift Assessment (DRFT-), Rebalance Trigger Rule, Model Change Implementation and Managed Account Cash Instruction (CSHI-). Release hands each proposal to 48 as a client order; orders, executions and allocations are 48 and the proposal holds only the released order reference. Money movement is 50 and cash balances 49; a 47 Fee Debit may raise a cash instruction. 25 keeps fund desk orders.",
     "rationale": "Proposal and order have different lifecycles, controls and regulation (CW-010). Lever: an outsourced rebalancer keeps the batch and proposals as received copies.",
     "action": "W2 (46), W3 (48, 50)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-050", "theme": "Ownership", "title": "Managed account composites are 46 memberships of client accounts; returns are 32; GIPS composites stay 01",
     "domains": ["46", "32", "01", "11"],
     "issue": "Plan section 5.2 gives 46 'program-level composites of client accounts'. 01 masters GIPS Composite (CMP-) and 32 Composite Membership, which keys on 18 portfolios; CW-011 puts the advisory slice of Firm AUM on 46.",
     "resolution": "46 masters Managed Account Composite (MACP-; program x model: membership rules, link to 01 GIPS Composite where presented) and Managed Account Composite Membership (composite x 15 account x period: inclusion, exclusion, discretion). 32 computes composite and account returns (Client Account Performance, W3) from 46 membership; the Firm AUM advisory slice reads Model Assignment and membership, values from 49. Term conflict 'Composite' logged.",
     "rationale": "Membership is an operational fact of the program; measurement is performance. Lever: a firm that presents programs under GIPS adds 32 Composite Membership rows for accounts.",
     "action": "W2 (46), W3 (32), WP0 (certified Firm AUM)", "status": P, "priority": "Medium", "owner_role": PL},

    # ---- 47 Pricing, Fees & Billing ---------------------------------------------------------------------------------
    {"id": "CW-051", "theme": "Ownership", "title": "The client Fee Schedule (CLFEE-) is 47; fund fee terms (FSCH-) stay 01; plan fees stay 16",
     "domains": ["47", "01", "16", "12", "10", "11"],
     "issue": "CW-036 keeps prospectus expense terms in 01 under FSCH- and asks 47 for a prefix not confusable with it; CW-901 moves mandate fee schedules out of 01; CONCEPT_OWNERSHIP still names 'Fee Schedule / Fee Terms' (01, FSCH-); 16 masters Plan Fee Schedule (PFEE-); 01 Platform Product Availability holds a Transaction Fee Category (CW-037).",
     "resolution": "47 masters Fee Schedule (CLFEE-; client fee schedule x version: advisory, wrap, flat, subscription, brokerage commission, account service, participant managed account, institutional mandate, trust administration), Fee Schedule Tier, Commission & Transaction Charge Rate, Account Service Fee Item and Fee Discount Rule. The object name 'Fee Schedule' is kept (01 Offering Fee Schedule Link.Linked Fee Schedule resolves to it). 01 keeps every fund expense term, including Management Fee.Fee Breakpoint Schedule (fund-level). 16 keeps plan fee terms; 47 bills them by reference. Register: CONCEPT_OWNERSHIP 'Fee Schedule / Fee Terms' (01) is re-cut into 'Fund Fee Schedule' (01, FSCH-) and 'Fee Schedule' (47, CLFEE-). FSC- and FEES- are not registered.",
     "rationale": "What a client pays the firm and what a fund charges its shareholders are different contracts, owners and rules. Lever: a firm without a direct business bills only mandates.",
     "action": "W2 (47); W2 merge (CONCEPT_OWNERSHIP)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-052", "theme": "Ownership", "title": "Fee Household (FHHG-) and fee schedule assignment are 47 (applies CW-027 and CW-032)",
     "domains": ["47", "02", "15", "13"],
     "issue": "CW-027 names the Fee Household; CW-032 gives 47 the fee schedule assignment and fee-paying account; CW-901 amends CW-028 so that 47 references the service tier in its schedules or waivers.",
     "resolution": "47 masters Fee Schedule Assignment (FEASG-; enrollment, account or mandate x schedule x period: fee-paying account, timing, frequency, fee household), Fee Rate Override, Fee Household (FHHG-; anchored on a 02 Client Household, PTY-HH-) and effective-dated Fee Household Membership. 47 never copies 02 membership; the 13 Mailing Householding Group (MHG-) is unrelated. Service tier discounts are Fee Discount Rules referencing the 01 tier code.",
     "rationale": "Breakpoint aggregation follows the firm's billing policy, which may differ from the client household. Lever: bill strictly by 02 household and drop the Fee Household.",
     "action": "W2 (47)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-053", "theme": "Ownership", "title": "Fee calculation and debit are 47; postings are 49, revenue 10, receivables 19",
     "domains": ["47", "49", "10", "19", "46", "50"],
     "issue": "A fee is calculated on client assets (49), debited from an account (a 49 posting), recognized as revenue (10) or invoiced (19 receivable).",
     "resolution": "47 masters Fee Calculation Run (FCRUN-), Account Fee Calculation (billable assets as a Derived copy of 49, schedule version applied, rate, gross and net fee), Billable Asset Exclusion, Fee Calculation Exception and Fee Debit (FDBT-; status pending, posted, failed, reversed). 49 posts the debit as client account activity and holds the cash; 46 raises cash when short; 50 moves external payments; 10 Fee Revenue Record reads 47 calculations; 19 Receivable Item takes the Fee Invoice as source document (CD-158).",
     "rationale": "Billing evidence answers acceptance question 8 (failed reconciliations, accounts billed outside schedule) without copying revenue or balances.",
     "action": "W2 (47), W3 (49), W4 (10)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-054", "theme": "Ownership", "title": "The 12 Fee Billing & Invoicing family moves to 47 with names and prefixes unchanged (executes CW-012)",
     "domains": ["47", "12", "19", "10"],
     "issue": "CW-012 moves 12's Fee Billing & Invoicing family to 47; 12 is adapted only at W4.",
     "resolution": "Billing Arrangement (BLA-), Fee Invoice (BIL-), Performance Fee Calculation, Fee Adjustment and Billing Dispute (BDP-) move to 47 with exact names; owner of BLA-, BIL-, BDP- and of the CONCEPT_OWNERSHIP rows Fee Invoice and Billing Arrangement changes from 12 to 47; steward of the shared list Performance Fee Basis moves with them. Billing Arrangement.Applied Fee Schedule is re-typed to Reference (Fee Schedule) with CLFEE- examples; examples move to USD. At the W2 merge the lead keeps one copy (47) and removes the family from content_12 or marks it for the W4 adaptation; readers re-point the domain number. The moved objects' EU/UK example values are recorded under CW-912 at W4.",
     "rationale": "One billing master for retail and institutional clients. Lever: a firm whose OCIO billing stays with institutional servicing keeps the family in 12.",
     "action": "W2 (47), W2 merge (registers), W4 (12)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-055", "theme": "Ownership", "title": "Client fee waivers and credits (FWV-) are 47; fund expense waivers stay 10 and 27",
     "domains": ["47", "10", "27"],
     "issue": "'Waiver' names client fee waivers, service-recovery credits and refunds (47) and fund expense waivers and reimbursements (10 Waiver Record WVR-, 27 accruals).",
     "resolution": "47 masters Fee Waiver (FWV-; billed subject x waiver x period: type, basis, amount or rate, approver, reason); the moved Fee Adjustment records invoice-level corrections. 10 Waiver Record and 27 accruals remain fund-level. Term conflict 'Waiver' logged.",
     "rationale": "Different payer, contract and accounting.",
     "action": "W2 (47)", "status": P, "priority": "Low", "owner_role": PL},

    {"id": "CW-056", "theme": "Ownership", "title": "Fee disclosures delivered and custody-rule evidence of fee deduction are 47; account-opening disclosures stay 15, filings 38",
     "domains": ["47", "15", "13", "38", "08"],
     "issue": "15 Account Disclosure Delivery covers Form CRS, the Reg BI disclosure and Form ADV 2A and 2B at opening and says 'fee disclosures are 47'. Deducting fees from client accounts gives the adviser custody under Rule 206(4)-2, with conditions on the qualified custodian and statements.",
     "resolution": "47 masters Fee Disclosure Delivery (fee schedule, advance notice of fee change, commission and fee schedule, Reg BI fee and cost disclosure, fee billing notice) and Fee Deduction Authorization (account x authorizing 15 advisory agreement: fee types, qualified custodian 09 LEN-, statement evidence 13 STMT-, Rule 206(4)-2 basis, status). 15 keeps opening disclosures; 13 delivers statements and the annual brochure offer; 38 files Form ADV and Form CRS and holds the firm's custody status; 08 reviews billing exceptions.",
     "rationale": "Per-account evidence sits with the process that deducts the fee. Lever: a state-registered adviser adds the state invoice condition.",
     "action": "W2 (47)", "status": P, "priority": "Medium", "owner_role": PL},

    # ---- Cross-cutting -----------------------------------------------------------------------------------------------
    {"id": "CW-057", "theme": "Ownership", "title": "Algorithmic advice uses the same 45 and 46 objects as human advice",
     "domains": ["45", "46", "37", "08"],
     "issue": "Digital advice (DA) generates recommendations and rebalances without a person; IM Guidance 2017-02 expects disclosure of the algorithm and oversight of it.",
     "resolution": "Algorithmic recommendations are Recommendation rows with source Algorithm and the engine version as a reference to 37 Model Inventory Entry; batches name the engine. No separate digital-advice object family exists; products split by function and channel.",
     "rationale": "Plan section 15 item 4: one domain, channel as data.",
     "action": "W2 (45, 46)", "status": P, "priority": "Low", "owner_role": PL},

    {"id": "CW-058", "theme": "Code Lists", "title": "Term conflicts of 45, 46 and 47 to log at W5",
     "domains": ["45", "46", "47", "01", "07", "08", "10", "12", "13", "19", "24", "27", "32"],
     "issue": "The new domains reuse words already used elsewhere.",
     "resolution": "Log: Composite (01 GIPS Composite; 46 Managed Account Composite; 32 measurement); Waiver (47 Fee Waiver; 10 Waiver Record; 27 accrual); Goal (45 Financial Goal; 07 retired Goal GOL-); Rebalance (24 Rebalance Run; 46 Account Rebalance Event); Trade proposal (24 Proposed Trade; 46 Trade Proposal); Tax Budget (24 portfolio; 46 account); Review (45 Advice Review; 12 Client Review; 08 supervisory review); Scenario and Plan Version (45 Planning Scenario and Financial Plan Version; 19 Plan Scenario and Plan Version Status lists; 10 Plan Version); Fee Schedule (47; 01 FSCH-; 16 Plan Fee Schedule). Extend the existing Plan, Program, Fee, Household and Rollover entries with the 45, 46 and 47 names of the briefs.",
     "rationale": "Qualified names prevent silent reuse.",
     "action": "W5", "status": P, "priority": "Low", "owner_role": PL},

    {"id": "CW-059", "theme": "Identifiers", "title": "Reserved prefixes of 45, 46 and 47; plan anchors rejected",
     "domains": ["45", "46", "47", "12", "15"],
     "issue": "The plan section 5.2 anchors were proposals. Checked against decisions.PREFIXES, content tokens, series, L1 codes and the other anchors: PLN- (anagram PNL- 10), FGL- (FPL- 19), RCO- (RCOV- 23, anagram COR-), ADE- (ALE- 15), MAS- (DAS- 21), RBL- (RBAL- 24), TPB- (TPL- 12), FSC- (FSCH- 01), FBR- (FXR- 22, FRR- 10), FDB- (token and L1 code FB) fail; TLH- and FWV- are clear.",
     "resolution": "Reserve 45: ADENG-, AVREV-, FGOAL-, FPLAN-, AGAC-, PSCEN-, RECOM-, ROLV-; 46: MASGN-, DRFT-, ARBE-, TLH-, TPBAT-, TRPR-, CSHI-, MACP-; 47: CLFEE-, FEASG-, FHHG-, FCRUN-, FDBT-, FWV-; transfer BLA-, BIL-, BDP- from 12 to 47 (CW-054). Key formats in PREFIX_FORMATS below; composite keys in GRAIN_KEY_FORMATS.",
     "rationale": "No prefix equal, anagram or one edit from another.",
     "action": "W2 merge", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-060", "theme": "Governance", "title": "Personal data in 45, 46 and 47; health-based planning inputs are special category (CD-344)",
     "domains": ["45", "46", "47", "02"],
     "issue": "Planning captures health-related assumptions (longevity, healthcare and long-term care costs), dependents and hardship; plan section 11 requires a PII tier on every object.",
     "resolution": "Every object states its tier. Health-based longevity and healthcare-cost bases are coded values flagged 'PII - special category (CD-344)' with a restricted view; no medical detail is held. Hardship is not a goal type; vulnerability stays 02 (VCON-) and is never copied. Aggregated account numbers are masked. Products read special-category fields as aggregates only.",
     "rationale": "Applies CW-030 to advice data. Lever: drop health-based bases.",
     "action": "W2 (45, 46, 47), WP1 (products)", "status": P, "priority": "High", "owner_role": "Data Protection Officer"},
]

# ---------------------------------------------------------------------------------------------------------------------
# Reserved prefixes (decisions.py tuple format). Checked against decisions.PREFIXES (410 entries, both siblings, every
# status), the plan section 5.2 anchors of 48 to 52 (COR CEX CCF CRT CHL CLT RSV CAA CAX MMT SWP PBK MMH TRS TDD EST MGR MDD
# SAA PDD), prefix-like tokens in every content module, DP- FN- SM- CD- CW-, the L1 codes (with AO, DI, RC) and each other.
# Rejected near-misses:
#   45: ADE- (ALE- 15), ADEN-/ADEG- (ADE-), ADVE-/ADVG-/ADVC-/ADVR- (ADVA- 35), AENG-/AVENG- (VENG- 40), ENGA-/ENGT-
#       (ENGM- 34, ENT- 14); AREV- (REV- 08), ADRV- (DRV- 10), ARVW- (PRVW- 36), REVW-; FGL- (FPL- 19), GOAL-/FGOL-/GOLF-
#       (GOL- 07); PLN- (anagram PNL- 10; PLY-, PLC-, RLN-), FNPL-/FPLN-/FPLX-/CFPL- (FPL-), PLAN- (PAAN- 32); XACC- (ACC-),
#       AGGR- (AGR- 05), EXAC- (EXEC- 25); PROJ- (PROL- 16), PRJR-/PRJN- (PRJT- 41), MCSR- (MSR- 06, CSR- 12); RCO- (RCOV-
#       23, anagram COR- 48 anchor, RCN-, RCM-, RCL-, DCO-), RECO- (RESO- 35), RCMD- (RCM-, RMD-), RECM-, RCOM-, AREC- (RREC-
#       23), ADRC-/AVRC- (ARC- 08); RLOV- (RCOV-), ROVR- (OVR- 06), RLAN- (RLN- 07).
#   46: MAS- (DAS- 21), MASG-, MASN-, MDAS-, AMAS- (AMA- 29), MDLA- (MDL- 01); RBL- (RBAL- 24, SBL- 28, RSL-, OBL-, RCL-),
#       REBAL- (RBAL-), RBEV- (REV-), MRBL- (MRL- 06), ACRB- (ACR- 10); TPB- (TPL- 12), TPRB-, PRBT- (PRJT-), PBAT- (FBAT-
#       29); TPRP- (PRP- 13), PTRP- (PTRM- 16), MTRP- (anagram PTRM-); CRIN- (CRIS- 42), MCIN- (MIN- 11), CASI- (CPSI- 26);
#       MACM- (ACM- 10), PGCM- (PGM- 05); WSW- (WS- 44 code); ALOC- (ALLOC- 25).
#   47: FSC- (FSCH- 01), FEES- (FEED- 06), FESCH-/CFSCH-/FSCD-/FSCL- (FSCH-), CFEE- (PFEE- 16), CFSC-/CFSD-/CLFS- (CFS- 12),
#       FEEX-/FEEW-/FESD- (FEED-); FBR- (FXR- 22, FBK- 08, FRR- 10, FBS- 11), FRUN-/BRUN- (RUN- 07, PRUN- 13), FCAL- (CAL-
#       09), FCLR- (CLR- 09); FDB- (FB- token and L1 code), FEEDB- (FEED-), FDEB-/FEDB- (avoided beside FDB-); FDAU- (anagram
#       AUDF- 37); FEHH-/FEEHH- avoided (retired HH-).
#   Noted, not rejected: FHHG- is two edits from MHG- (13); MACP- two edits from CMP- (01); ARBE- two edits from RBAL- (24).
# The 03, 08 and 51 W2 briefs reserve their prefixes in parallel; the lead checks the three files against each other at
# merge (the 51 anchors TRS-, TDD-, EST- are clear of every prefix here).
# ---------------------------------------------------------------------------------------------------------------------
R = "Reserved"

PREFIXES = [
    ("ADENG-", "Advice engagement (client or household x engagement)", "45", R, "W2 brief 45 (CW-044). Plan anchor ADE- rejected (ALE- 15); rejected ADEN-, ADVE-, AENG-, ENGA-."),
    ("AVREV-", "Advice review (engagement x review; includes the Rule 3a-4 annual contact)", "45", R, "W2 brief 45 (CW-044). Rejected AREV-, ADRV-, ARVW-, REVW-."),
    ("FGOAL-", "Financial goal", "45", R, "W2 brief 45 (CW-043). Plan anchor FGL- rejected (FPL- 19); rejected GOAL-, FGOL-, GOLF- (GOL- 07)."),
    ("FPLAN-", "Financial plan (versions FPLAN-<n>-<vv>)", "45", R, "W2 brief 45 (CW-043). Plan anchor PLN- rejected (anagram PNL- 10); rejected FNPL-, FPLN-, PLAN-."),
    ("AGAC-", "Aggregated external account (party x account at another institution)", "45", R, "W2 brief 45 (CW-043). Rejected XACC-, AGGR-, EXAC-."),
    ("PSCEN-", "Planning scenario (financial plan version x scenario)", "45", R, "W2 brief 45 (CW-046). Rejected PROJ-, PRJR-, MCSR-."),
    ("RECOM-", "Recommendation (Reg BI or advisory)", "45", R, "W2 brief 45 (CW-042). Plan anchor RCO- rejected (RCOV- 23, anagram COR-); 15 examples re-keyed at merge. Rejected RECO-, RCMD-, RECM-, AREC-."),
    ("ROLV-", "Rollover analysis (rollover recommendation x analysis)", "45", R, "W2 brief 45 (CW-045). Rejected RLOV-, ROVR-, RLAN-."),
    ("MASGN-", "Model assignment (account x model portfolio x period)", "46", R, "W2 brief 46 (CW-047). Plan anchor MAS- rejected (DAS- 21); rejected MASG-, MDAS-, AMAS-, MDLA-."),
    ("DRFT-", "Drift assessment (managed account x assessment timestamp)", "46", R, "W2 brief 46 (CW-049)."),
    ("ARBE-", "Account rebalance event (managed account x rebalance event)", "46", R, "W2 brief 46 (CW-049). Plan anchor RBL- rejected (RBAL- 24); rejected REBAL-, RBEV-, MRBL-, ACRB-."),
    ("TLH-", "Tax-loss-harvest decision (managed account x harvest opportunity)", "46", R, "W2 brief 46 (CW-048). Plan anchor kept; clear."),
    ("TPBAT-", "Trade proposal batch", "46", R, "W2 brief 46 (CW-049). Plan anchor TPB- rejected (TPL- 12); rejected TPRB-, PRBT-, PBAT-."),
    ("TRPR-", "Trade proposal (proposal line for one managed account)", "46", R, "W2 brief 46 (CW-049). Rejected TPRP-, PTRP-, MTRP-."),
    ("CSHI-", "Managed account cash instruction (raise or invest)", "46", R, "W2 brief 46 (CW-049). Rejected CRIN-, MCIN-, CASI-."),
    ("MACP-", "Managed account composite (program x model)", "46", R, "W2 brief 46 (CW-050). Rejected MACM-, PGCM-; two edits from CMP- (01)."),
    ("CLFEE-", "Client fee schedule (versioned)", "47", R, "W2 brief 47 (CW-051). Plan anchor FSC- rejected (FSCH- 01); FEES- rejected (FEED- 06); rejected CFEE-, CFSC-, FESCH-."),
    ("FEASG-", "Fee schedule assignment (enrollment, account or mandate x schedule x period)", "47", R, "W2 brief 47 (CW-052)."),
    ("FHHG-", "Fee household (fee householding group for breakpoints)", "47", R, "W2 brief 47 (CW-027, CW-052). Two edits from MHG- (13); FEHH- avoided."),
    ("FCRUN-", "Fee calculation run", "47", R, "W2 brief 47 (CW-053). Plan anchor FBR- rejected (FXR- 22, FRR- 10); rejected FRUN-, BRUN-, FCAL-."),
    ("FDBT-", "Fee debit (account fee calculation x debited account)", "47", R, "W2 brief 47 (CW-053). Plan anchor FDB- rejected (FB- token and L1 code); rejected FEEDB-."),
    ("FWV-", "Client fee waiver or credit", "47", R, "W2 brief 47 (CW-055). Plan anchor kept; clear (three edits from WVR- 10)."),
]

# Prefixes transferred to 47 (already in decisions.PREFIXES with owner 12; the lead changes the owner at merge, CW-054).
TRANSFER_PREFIXES = {"BLA-": ("12", "47"), "BIL-": ("12", "47"), "BDP-": ("12", "47")}

# Proposed key formats (decisions.PREFIX_FORMATS tuple format: prefix, domain, format, example).
PREFIX_FORMATS = [
    ("ADENG-", "45", "ADENG-<year>-<sequence, 6 digits>", "ADENG-2026-004187"),
    ("AVREV-", "45", "AVREV-<year>-<sequence, 7 digits>", "AVREV-2026-0031877"),
    ("FGOAL-", "45", "FGOAL-<sequence, 8 digits>", "FGOAL-00412877"),
    ("FPLAN-", "45", "FPLAN-<sequence, 7 digits>[-<version, 2 digits>]", "FPLAN-0041877-03"),
    ("AGAC-", "45", "AGAC-<sequence, 8 digits>", "AGAC-00218840"),
    ("PSCEN-", "45", "PSCEN-<FPLAN sequence>-<version, 2 digits>-<scenario, 2 digits>", "PSCEN-0041877-03-02"),
    ("RECOM-", "45", "RECOM-<year>-<sequence, 7 digits>", "RECOM-2025-0018342"),
    ("ROLV-", "45", "ROLV-<year>-<sequence, 6 digits>", "ROLV-2026-000917"),
    ("MASGN-", "46", "MASGN-<sequence, 9 digits>", "MASGN-000418822"),
    ("DRFT-", "46", "DRFT-<YYYYMMDD>-<sequence, 8 digits>", "DRFT-20261005-00418822"),
    ("ARBE-", "46", "ARBE-<YYYYMMDD>-<sequence, 8 digits>", "ARBE-20261005-00031207"),
    ("TLH-", "46", "TLH-<YYYYMMDD>-<sequence, 8 digits>", "TLH-20261005-00004512"),
    ("TPBAT-", "46", "TPBAT-<YYYYMMDD>-<sequence, 4 digits>", "TPBAT-20261005-0007"),
    ("TRPR-", "46", "TRPR-<YYYYMMDD>-<sequence, 9 digits>", "TRPR-20261005-000418822"),
    ("CSHI-", "46", "CSHI-<year>-<sequence, 8 digits>", "CSHI-2026-00318273"),
    ("MACP-", "46", "MACP-<sequence, 4 digits>", "MACP-0012"),
    ("CLFEE-", "47", "CLFEE-<sequence, 4 digits>-<version, 2 digits>", "CLFEE-0031-04"),
    ("FEASG-", "47", "FEASG-<sequence, 9 digits>", "FEASG-000418822"),
    ("FHHG-", "47", "FHHG-<sequence, 7 digits>", "FHHG-0055012"),
    ("FCRUN-", "47", "FCRUN-<billing period, e.g. 2026Q3 or 2026M09>-<sequence, 3 digits>", "FCRUN-2026M09-004"),
    ("FDBT-", "47", "FDBT-<billing period>-<sequence, 9 digits>", "FDBT-2026M09-000418822"),
    ("FWV-", "47", "FWV-<year>-<sequence, 6 digits>", "FWV-2026-000917"),
]
KEY_FORMATS = PREFIX_FORMATS  # alias named in the W2 assignment

# Composite keys (decisions.GRAIN_KEY_FORMATS tuple format: object, domain, format, example).
GRAIN_KEY_FORMATS = [
    ("Financial Plan Version", "45", "<FPLAN- id>-<version, 2 digits>", "FPLAN-0041877-03"),
    ("Goal Funding Link", "45", "<FGOAL- id> / <ACC- or AGAC- id> / <effective from>", "FGOAL-00412877 / ACC-0049812 / 2026-01-15"),
    ("Best Interest Evidence", "45", "<RECOM- id> / <component code>", "RECOM-2025-0018342 / CARE"),
    ("Goal Projection Result", "45", "<PSCEN- id> / <FGOAL- id>", "PSCEN-0041877-03-02 / FGOAL-00412877"),
    ("Account Tax Budget", "46", "<ACC- id> / <tax year>", "ACC-0049812 / 2026"),
    ("Wash Sale Control Window", "46", "<group or ACC- id> / <security group> / <window start>", "PTY-HH-55012 / SIG-SP500 / 2026-10-05"),
    ("Managed Account Composite Membership", "46", "<MACP- id> / <ACC- id> / <start date>", "MACP-0012 / ACC-0049812 / 2026-01-01"),
    ("Account Fee Calculation", "47", "<FCRUN- id> / <FEASG- id>", "FCRUN-2026M09-004 / FEASG-000418822"),
    ("Fee Household Membership", "47", "<FHHG- id> / <ACC- id> / <effective from>", "FHHG-0055012 / ACC-0049812 / 2026-01-01"),
    ("Fee Deduction Authorization", "47", "<ACC- id> / <AAG- id>", "ACC-0049812 / AAG-0013455"),
]

NOTES = [
    "15 at the W2 merge: re-key the two Recommendation examples (content_15_account.py Program Enrollment.Source Recommendation and Account Opening.Originating Recommendation) from RCO- to RECOM- (CW-042); flag Program Enrollment.Rule 3a-4 Annual Contact Date as DERIVED '45' in enrich_15.py (CW-044); proposals_w1_15.NOTES line naming 'Recommendation (RCO-, 45)' is superseded.",
    "CONCEPT_OWNERSHIP at merge: add Recommendation (45, RECOM-), Financial Goal (45, FGOAL-), Financial Plan (45, FPLAN-), Model Assignment (46, MASGN-), Fee Schedule (47, CLFEE-), Fee Household (47, FHHG-); re-cut 'Fee Schedule / Fee Terms' (01, FSCH-) to 'Fund Fee Schedule' (CW-051); change Billing Arrangement and Fee Invoice owners to 47 (CW-054). Until then a Reference (Fee Schedule) without a CLFEE- example may resolve to 01 by the concept register; drafters always give CLFEE- examples.",
    "ownership.py ALIASES maps 'tax lot' to 18; 46 types every client lot reference 'Reference (Client Tax Lot, 49)' (CW-048). 49 (W3) confirms the object name and the CLT- prefix.",
    "24 re-cut at W3 (CW-048): Tax Budget drops Budget Account; Proposed Trade and Proposed Lot Selection apply to 18 portfolios only; Rebalance Run keeps RBAL-.",
    "W3 dependencies: 49 Client Holding, Client Tax Lot and client account activity names and prefixes (CHL-, CLT-, CAA- anchors); 48 Client Order (COR- anchor; RECOM- avoids the RCO-/COR- anagram); 50 Money Movement (MMT-); 32 Client Account Performance; 24 Capital Market Assumption Set; 52 sub-adviser key (Sleeve Assignment manager).",
    "W2 sibling dependencies: 08 names the surveillance and review objects that reference RECOM-, ROLV-, TRPR- and 47 exceptions; 03 names the advisor and client-assignment objects (advisor of record on ADENG- and RECOM- is 20 EMP- until then); 13 names the interaction and notice objects (CCI-, COMM-). Check the 03, 08 and 51 prefixes against this file at merge.",
    "Shared-list candidates for W5: Advice Delivery Channel (45, with 03 and 13); Composite Exclusion Reason (46 and 32); Performance Fee Basis steward 12 -> 47.",
    "Regulatory status to confirm in Source_Notes: removal of the DOL Retirement Security Rule and restoration of the 2020 PTE 2020-02 text (secondary sources: final rule of March 2026 effective April 20, 2026; Federal Register document 2026-05492 not read); withdrawal of the SEC safeguarding proposal (2025); CFPB section 1033 rule status; Exchange Act Rule 17a-3(a)(35) paragraph number.",
]
