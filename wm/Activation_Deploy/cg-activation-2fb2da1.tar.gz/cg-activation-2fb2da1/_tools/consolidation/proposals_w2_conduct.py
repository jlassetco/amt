"""Wealth-manager reference model: W2 brief decisions for 03, 08 and 51 (CW-061 to CW-080) and reserved prefixes.

Written by the W2 brief agent for 03 Advisor Organization, Coverage & Supervision (replaced, L1 code AO), 08 Retail
Conduct & Supervision (replaced, L1 code RC) and 51 Trust & Estate Services (new, optional, Light, L1 code TE), with the
briefs in 00_Program/Rework/Briefs/ (03_Advisor_Organization_Coverage_and_Supervision.md,
08_Retail_Conduct_and_Supervision.md, 51_Trust_and_Estate_Services.md). 2026-10-14.

Proposal fragment only: the builder does not read this file. Format: the DECISIONS dict format and the PREFIXES tuple
format of decisions.py (see CONTRACT.md). Declarative only. Every decision is "Proposed" until the program lead merges
it; each states the tailoring lever where a client could rule differently. The US-only decisions of these domains are
pre-allocated (CW-022): CW-903 (03), CW-908 (08), CW-951 (51); the drafters write them in proposals_03.py,
proposals_08.py and proposals_51.py.
"""

PL = "Program lead"
P = "Proposed"

DECISIONS = [
    # ---- 03 Advisor Organization, Coverage & Supervision --------------------------------------------------------
    {"id": "CW-061", "theme": "Ownership", "title": "03 Advisor Organization, Coverage & Supervision: the advisor profile, teams, branches and supervisory structure",
     "domains": ["03", "20", "09", "08", "02", "05", "13", "45"],
     "issue": "CW-013 makes 03 the firm's own advisor workforce domain but does not say what is mastered against 20 (employee), 09 (offices), 08 (licensing and supervisory evidence), 05 (external advisors), 13 (service interactions) and 45 (advice).",
     "resolution": "03 (L1 code AO) masters the advisor profile of a 20 employee keyed by EMP- (Advisor; roles over time, credentials, languages, specialties, accepting new clients; registration status as a Derived copy of 08), Coverage Team and membership, the firm's branch offices and OSJs as profiles of 09 Office Location (SITE-), the supervisory hierarchy, Principal Designation and Supervisory Assignment (FINRA Rule 3110(a)(2), (a)(4), (a)(5)), coverage and service models, assignment rules, client-to-advisor assignment and reassignment, capacity and book size snapshots, advisor activities with clients (ACT-), channel referrals and incentive and recognition plans in reduced form. 20 keeps identity, job, position and pay; 08 keeps registrations, inspections, reviews, findings and heightened supervision; 05 keeps external advisors and intermediary coverage; 13 keeps contact-center interactions and service requests; 45 keeps engagements, recommendations and their evidence. Advisor performance scorecards are data products, not objects. Bare 'Advisor' is the firm's own representative.",
     "rationale": "The book of business and the supervisory structure have one owner (the head of the advice organization) and are read by 06, 45, 47 and 08. Lever: an independent-contractor channel adds an advisor firm profile and moves toward 05.",
     "action": "W2 (03)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-062", "theme": "Structure", "title": "03 kept names, prefixes kept, transferred and retired, and the readers of the wholesale 03 and 07 to re-point",
     "domains": ["03", "07", "05", "04", "06", "10", "11", "12", "20"],
     "issue": "Replacing 03 and absorbing part of 07 breaks references in carried modules and live products (DP-009 and DP-010 are live foundational products) unless the kept names and the re-point map are stated.",
     "resolution": "Kept by exact name: from 03 Internal Participant, External Participant, Discussion Content, Outcome & Follow-Up, Activity Capture, License & Registration Reference; from 07 Coverage Model, Call Frequency Standard, Party Coverage Assignment, Incentive Compensation Plan, Compensation Statement. Renamed (map for the re-point): Sales Person -> Advisor; Sales Role -> Advisor Role Assignment; Sales Team and 07 Coverage Team -> Coverage Team; Team Membership & Channel Assignment and Sales Pairing & Alignment -> Coverage Team Membership; Sales Activity -> Advisor Activity; 07 Alignment Rule, Alignment Rule Criterion, Alignment Exception -> Coverage Assignment Rule (and its Criterion); Realignment Event -> Coverage Reassignment; Plan Component, Rate Table Tier, SPIF & MBO, Product Compensation Tier Mapping -> Incentive Plan Component; Plan Participant Assignment -> Incentive Plan Participation; Earnings Result -> Incentive Earnings Line; Coverage Tier Assignment -> 02 Service Tier Assignment. Prefixes: ACT- and SLT- kept (SLT- entity becomes 'Coverage team'); CVA-, ICP-, CPS- transferred 07 -> 03; OPP-, RFP-, ANS-, DBS-, KAP- held for 05 at W4 (restored with their objects if the 05 brief keeps them, else retired then); PLY- and FCS- retired; the 07 prefixes TER-, TMD-, ALR-, RLN-, GOL-, GPL-, CRR-, CRA-, CTM-, ERN-, DSP-, CTL-, RUN-, CPRD- retire with 07 at W4. Readers re-pointed at the W2 merge: DP-009 (03 and 07 inputs by the map; territory, crediting, cluster and potential inputs dropped with a 'W2' note; 08 Individual Registration resolves) and its model in models_f2.py; DP-010 (Sales Activity -> Advisor Activity; kept participants and content; Consultant Research Review and Content Usage Event dropped; 07 Call Frequency Standard -> 03); DP-243 (Sales Opportunity, Pipeline Status, Opportunity Value, Win / Loss dropped until 05 restores them at W4); DP-198 (Compensation Statement -> 03; Payroll Payment Instruction -> 20 Payroll Result); DP-006 and DP-007 (territory alignment from DP-009 -> Party Coverage Assignment); models_e8c_cross_area.py and models_e8c_people_workplace_ai.py by the same map; the 20 relationship text 'Employee is extended by Sales Person [03]' -> 'Advisor [03]'. Carried references that resolve unchanged by prefix: 04 Lead Assignment.First Sales Activity and 12 Client Review.Meeting Activity (ACT-), 20 Payroll Result.Incentive Payout Statements (CPS-), 10 Capitalization Assessment (ICP-). Left for W4 and listed in the W4 briefs: 04 Converted and Attributed Opportunity and Territory references (the 04 W2 brief decides), 05 Shelf Placement.Placement Opportunity and Partner Research Rating (RFP-), 06 Territory and Crediting Rule, 10 Territory and Sales Forecast Reference (FCS-), 11 Mandate Search Event.Linked Opportunity. Data model keys in keys.py, keys_g2_03_04_05.py and keys_g3_06_07_10.py are superseded at WP2 (keys_w_*.py).",
     "rationale": "Same mechanics as CW-021 for 02 and 15: names that readers use are kept where the concept is unchanged; renamed objects get an explicit map. Lever: none.",
     "action": "W2 (03 draft); W2 merge (products, models, PREFIXES, CONCEPT_OWNERSHIP); W4 (05, 06, 10, 11 readers)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-063", "theme": "Ownership", "title": "Client-to-advisor assignment is mastered once, in 03 Party Coverage Assignment",
     "domains": ["03", "02", "15", "45", "47", "06"],
     "issue": "Advisor-of-record attributes tend to appear on the client (02), the account (15), the plan (45) and the bill (47).",
     "resolution": "03 Party Coverage Assignment (CVA-; covered party or household x advisor or Coverage Team x coverage role x period, with account-scope exceptions) is the only advisor-of-record master. 02, 15, 45 and 47 hold no advisor-of-record attribute; 06 flow attribution by advisor, 47 billing and 45 engagements read the assignment as of a date. Reassignments are Coverage Reassignment events with client notice dates.",
     "rationale": "One assignment, effective dated, answers acceptance question 2 (net new assets by advisor) without reconciling copies. Lever: client grain instead of household grain.",
     "action": "W2 (03, 45, 47); W4 (06)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-064", "theme": "Ownership", "title": "Incentive compensation in reduced form in 03; pay in 20; the Reg BI review in 08; scorecards are products",
     "domains": ["03", "07", "20", "08", "19"],
     "issue": "07 modeled territories, goals, crediting, rate tables and payouts for a wholesale sales force; Reg BI restricts sales contests, quotas and non-cash compensation tied to specific securities.",
     "resolution": "03 keeps Incentive Compensation Plan (ICP-), Incentive Plan Component (ICP-n-Cnn; client-outcome and firm-level measures, a Reg BI Rule 15l-1(a)(2)(iii)(D) product-specific time-limited indicator), Incentive Plan Participation, Compensation Statement (CPS-) with Incentive Earnings Line, and Recognition Award (RECG-). Goals, crediting, draws, disputes and accruals are dropped (accruals are 19, payroll is 20 Payroll Result, HR objectives are 20 Performance Objective). 08 Incentive Conflict Review records the Reg BI review of each component. Advisor scorecards are data products.",
     "rationale": "A direct firm pays advisors salary and bonus on client outcomes; what survives of 07 is the plan, its measures and the statement payroll reads. Lever: a commission-paid force restores rate tables from the sibling.",
     "action": "W2 (03, 08)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-065", "theme": "Ownership", "title": "Channel referrals are 03; leads and client-to-friend referral programs are 04",
     "domains": ["03", "04", "13", "16", "45", "51"],
     "issue": "Referrals from digital to human advice, from service to advice, from participant services to advice and from advice to the trust company have no owner; 04 holds marketing leads.",
     "resolution": "03 masters Channel Referral (RFRL-; source channel and referring employee, target channel or advisor, referred party or household, reason, status, outcome as a reference to 45 engagement, 15 enrollment or 04 lead). 04 keeps Marketing Lead, acquisition campaigns and client referral programs. 16 rollover capture references the referral.",
     "rationale": "An internal referral is an advice-organization handoff with an incentive attached; a lead is a marketing record. Lever: a firm that routes all referrals through marketing makes them lead sources in 04.",
     "action": "W2 (03, 04 brief)", "status": P, "priority": "Low", "owner_role": PL},

    # ---- 08 Retail Conduct & Supervision ----------------------------------------------------------------------------
    {"id": "CW-066", "theme": "Ownership", "title": "08 Retail Conduct & Supervision supervises the evidence of 45, 02 and 15 and never re-masters it; 38 keeps the firm-level programs",
     "domains": ["08", "45", "02", "15", "38", "03"],
     "issue": "Reg BI, PTE 2020-02 and supervision invite copies of recommendation rationale, profile values and approval decisions into the compliance domain, and duplicates of 38's policies, attestations and conflicts register.",
     "resolution": "08 (L1 code RC) masters Supervisory Review (PRNR-; recommendation, rollover, account type, account, options and margin approval, transaction and correspondence reviews) with Best Interest Review Detail (evidence-present checks and references only), Disclosure Delivery Check (Form CRS and Reg BI disclosure per trigger), Incentive Conflict Review, Surveillance Scenario (SCEN-), Sales Practice Alert, Frequent Trading Case, Conduct Corrective Action (CORAC-), Supervisory Control, Branch Inspection (BRIN-), Supervisory Control Test (Rule 3120), Supervisory Finding (SFND-), Heightened Supervision Plan (HSPL-), communications review and capture, complaints, Senior Investor Case (SNRC-), registrations and CE, gifts and non-cash compensation. 45 masters the recommendation and its evidence, 02 the profile, 15 the approvals and disclosures delivered. 38 keeps written supervisory procedures as Policies, the Rule 3130 CEO certification as an Attestation, compliance program reviews (including the PTE 2020-02 retrospective review report, proposed as a 38 Program Review Type at its W4 adaptation), the conflicts register, OBAs, personal trading, political contributions, AML and firm registrations and filings, Form CRS filing included.",
     "rationale": "Acceptance question 3 resolves cleanly: the missing evidence is a 45 fact, the exception an 08 fact. Lever: a firm with separate surveillance and review platforms splits Supervisory Review by type.",
     "action": "W2 (08); W4 (38 Program Review Type value)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-067", "theme": "Structure", "title": "08 kept names, prefixes kept, transferred and retired, and the readers of the wholesale 08 to re-point",
     "domains": ["08", "04", "05", "10", "11", "12", "13", "16", "20", "21", "29", "32", "36", "38", "39", "42", "44"],
     "issue": "Seventeen carried modules and nine live products read wholesale 08 objects.",
     "resolution": "Kept by exact name: Compliance Review, US Communication Classification, Performance Presentation, Review Step, Compliance Approval, FINRA Advertising Filing, Approved Communication Channel, Captured Communication Record, Surveillance Alert, Sales Practice Alert, Frequent Trading Case, Complaint, Complaint Classification, Complaint Handling, Complaint Regulatory Report, Individual Registration, Exam Result, Registration Filing, Disclosure Event, CE Requirement, Gift / Entertainment Item, Benefit Valuation, G&E Approval, Training / Education Meeting. Merged: Required Disclosures into US Communication Classification; Other Regulator Filing into FINRA Advertising Filing; Social Media Account into Approved Communication Channel; Special Recipient Flags into Gift / Entertainment Item. Moved: Retention Rule to 21 (CW-068); Distributor Due Diligence with its six detail objects to 05 at W4 (DDQ- held). Dropped: Distribution Conflict of Interest (38 CONFL-), Intermediary Information Package, Private Offering Compliance, Record Metadata and the EU/UK objects of CW-908. Prefixes kept: REV-, CPL-, LIC-, GNE-, ARC-, SURV-, SPA-, FTC-; RET- transferred to 21; DDQ- held for 05; FBK-, MKN-, PMK-, RSL-, COI- retired. Readers that resolve unchanged: 04 (REV-, GNE-, CPL-), 11, 12, 13, 16, 20 (LIC-, Form U4 and U5 relationship texts), 29 (FTC-), 32, 38 (SURV-), 42, 44, DP-009, DP-200, DP-209, DP-228, DP-236. Re-pointed at the W2 merge: DP-246 drops Cross-Border Marketing Notification and models_e8c_cross_area.py likewise; DP-109 drops Outcome Metric and Sales Against Target Market and models_e8c_private_markets_product_range.py likewise; 36 Target Market Review Result.Distributor Feedback Reviewed and Sales Outside Target Market Observed Indicator are removed early (MiFID II, recorded under CW-936 when 36 is adapted at W4); 02 Vulnerability Concern.Escalation Case Reference is retyped Reference (Senior Investor Case, 08) and its relationship target named; the 38 relationship text 'Compliance records [08] (REV-, DDQ-, GNE-, CPL-, LIC-)' drops DDQ-. Left for W4: 05 Distribution Agreement.Distributor Due Diligence Reference and the 05 and 10 Inducement Assessment References (typed Compliance Review; removed with 05 and 10's US pass). keys_g4_08_09.py and the keys_e7_* entries for dropped objects are superseded at WP2.",
     "rationale": "As CW-021: readers keep resolving where the concept survives; dropped EU objects leave with their readers.",
     "action": "W2 (08 draft); W2 merge (products, models, 02 retype, 36 early removal); W4 (05, 10, 36)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-068", "theme": "Ownership", "title": "The records retention schedule (Retention Rule, RET-) moves from 08 to 21 (amends CD-062; settles C-12.16)",
     "domains": ["08", "21", "39", "02", "13", "41"],
     "issue": "CD-062 made 08 RET- the enterprise retention schedule; W0 left open whether it stays in the replaced 08 or moves to 21 or 39 (w0_framing_notes; W1 merge notes section 5).",
     "resolution": "Retention Rule moves to 21 Data Governance & Analytics at the W2 merge with its name, RET- prefix and attributes (Record Class, Governing Requirement, Retention Period) unchanged, re-sourced to the US rules (SEC Rules 17a-3 and 17a-4 with their periods, Advisers Act Rule 204-2, Investment Company Act Rule 31a-2, Rule 17Ad-7, FINRA Rule 4513, ERISA and IRS record rules); the MiFID II, COBS 11.8 and DISP 1.9 values are recorded under CW-908. Capability C-12.16 is re-mastered by 21. 21 Object Governance Profile and Record Governance Metadata (internal references after the move), 39 Legal Hold Scope and 08 Captured Communication Record reference it. 21 is a kept domain: the program lead adds the object at the merge (a logged change to a carried domain).",
     "rationale": "The schedule is governance metadata applied to every domain's records (CD-160 models governance metadata once, in 21); its periods come from many rules beyond the broker-dealer's; its owner is the Head of Records Management, not the retail CCO; its readers already sit in 21. 39 is rejected because the legal hold suspends the schedule and should reference it, not own it. Lever: a firm whose records function sits in Legal moves it to 39.",
     "action": "W2 merge (21 module, capability map C-12.16, CONCEPT_OWNERSHIP, PREFIXES RET- owner)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-069", "theme": "Ownership", "title": "State notice filings: fund shares stay in 35; adviser notice filings are 38; 08 holds individual state registrations only (settles CW-935)",
     "domains": ["35", "38", "08"],
     "issue": "CW-935 added the Filing Form Type value 'State Notice Filing (NSMIA)' and two state attributes to 35 and left the owner (35 or 08) to the 08 brief.",
     "resolution": "35 keeps the notice filings and fees for the funds' shares (one Filing Obligation and one Fund Regulatory Filing row per state; Securities Act Section 18, paragraphs to confirm). The SEC-registered adviser's state notice filings through IARD are 38 Entity Authorization. 08 Individual Registration holds the state registrations of individuals (agents under the Uniform Securities Act, IARs). Nothing moves.",
     "rationale": "A fund notice filing is a fund regulatory filing made by the fund's administrator; it has nothing to do with retail conduct. Lever: none.",
     "action": "None beyond recording; CW-935 note closed at the W2 merge", "status": P, "priority": "Low", "owner_role": PL},

    {"id": "CW-070", "theme": "Ownership", "title": "Complaints are 08; service requests are 13; the Rule 4530 definition decides",
     "domains": ["08", "13", "04", "12", "16"],
     "issue": "Grievances arrive as service requests, calls, chats, letters and social mentions; 13 and 08 both record them.",
     "resolution": "A written grievance by or for a customer that meets the FINRA Rule 4530 and 4513 definition is an 08 Complaint (CPL-) with FINRA problem and product codes and its 4530(d) quarter; 13 Service Request (SRQ-) keeps its own lifecycle and references the complaint (Escalated Complaint); 04 Social Listening Mention, 12 Client Service Request and 16 Plan Correction reference CPL-. Oral grievances are recorded as complaints by firm policy (lever) with the written indicator false.",
     "rationale": "One complaint record feeds 4530 reporting, Form U4 disclosure and root-cause analysis. Lever: written-only complaint scope.",
     "action": "W2 (08, 13 brief)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-071", "theme": "Ownership", "title": "Senior Investor Case (08) is the escalation target of the 02 Vulnerability Concern; holds stay in 15 and 50",
     "domains": ["08", "02", "15", "50", "38", "20"],
     "issue": "CW-030 left 02 Vulnerability Concern.Escalation Case Reference as an identifier until 08 exists.",
     "resolution": "08 masters Senior Investor Case (SNRC-), its actions (trusted contact used, hold placed or extended by reference to 15 ARX- and 50 MMH-) and External Protection Report (adult protective services, state securities regulator, law enforcement, court), all 'PII - special category (CD-344)' with a restricted view. 02 Escalation Case Reference is retyped Reference (Senior Investor Case, 08) at the W2 merge. SARs stay 38 AML Case; Senior Safe Act training evidence is 20 Learning Completion. FINRA Rule 2165 holds: up to 55 business days in total after the 2022 amendments (Regulatory Notice 22-05); SR-FINRA-2026-018 proposes changes (confirm).",
     "rationale": "The case is a supervisory record; the hold is an account or disbursement fact. Lever: a firm that runs elder cases in a financial crimes unit moves the case to 38.",
     "action": "W2 (08); W2 merge (02 retype)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-072", "theme": "Ownership", "title": "Licensing and registration of own representatives are 08; the role requirement is 20; 03 holds Derived copies",
     "domains": ["08", "20", "03", "09"],
     "issue": "Registration status appears in 20 (Regulated Role Category, Form U4 and U5 references), 03 (registered indicators) and 08 (Individual Registration).",
     "resolution": "08 masters Individual Registration (LIC-; person x category x jurisdiction: FINRA Rule 1220 categories, IAR, state agent), Exam Result, Registration Filing (Forms U4 and U5), Disclosure Event, CE Requirement (FINRA Rule 1240; NASAA IAR CE model rule, 12 credits a year in adopting states) and Branch Registration (Form BR). 20 Job Profile.Regulated Role Category is the requirement of the role (CW-920); 20's Form U4 and U5 references resolve to 08. 03 License & Registration Reference holds references and Derived copies; 03 Firm Branch Office holds the branch structure.",
     "rationale": "Registration is a compliance record filed with FINRA and the states; the role requirement is HR's; the coverage view needs a copy. Lever: none.",
     "action": "W2 (03, 08)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-073", "theme": "Scope", "title": "Communications review and capture kept from the wholesale 08 in retail form",
     "domains": ["08", "04", "42", "32", "11"],
     "issue": "Rule 2210 and Marketing Rule review was the core of the wholesale 08; much of it was EU/UK classification.",
     "resolution": "08 keeps Compliance Review (REV-) and its US classification, performance, step, approval and FINRA filing objects, approved channels (now including advisors' social accounts), captured communications (ARC-) and their surveillance alerts (SURV-), re-sourced to FINRA Rules 2210, 2212, 3110(b)(4), SEC Rule 17a-4(b)(4) and Advisers Act Rules 206(4)-1 and 204-2. 04 keeps the content asset and its versions; 08 decides and records the approval.",
     "rationale": "The review evidence is the same for a retail firm; the audience and the rules change. Lever: none.",
     "action": "W2 (08)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-074", "theme": "Ownership", "title": "FINRA Rule 3240 and 3241 declarations go with outside business activities to 38",
     "domains": ["38", "08", "51"],
     "issue": "Plan section 12 lists FINRA Rules 3240 (borrowing from or lending to customers) and 3241 (registered person named a customer's beneficiary or holding a position of trust; effective February 15, 2021) as 08 sources, while OBAs and private securities transactions stay in 38.",
     "resolution": "Rule 3240 and 3241 notices and approvals are 38 declarations beside Outside Business Activity (new OBA Type values proposed at 38's W4 adaptation; FINRA Rule 3290 replacing 3270 and 3280 when effective, confirm). 08 surveillance and senior investor cases reference them; 51 cross-checks trust roles held by representatives.",
     "rationale": "They are personal-conduct declarations approved by compliance under the same workflow as OBAs. Lever: a firm that runs them in its senior-protection unit keeps them in 08.",
     "action": "W4 (38 values)", "status": P, "priority": "Low", "owner_role": PL},

    # ---- 51 Trust & Estate Services -------------------------------------------------------------------------------
    {"id": "CW-075", "theme": "Ownership", "title": "51 Trust & Estate Services: the Trust instrument, fiduciary roles and interests; TRUST- replaces the anchor TRS-",
     "domains": ["51", "02", "15", "09", "35"],
     "issue": "15 already references 'Reference (Trust, 51)' with example TRS-000412; 02 holds Party Relationship values Trustee Of and Grantor Of; the plan anchor TRS- is one edit from TRSV- (38) and an anagram of STR- and RST- (01).",
     "resolution": "51 (Light, optional) masters Trust (TRUST-; the name 15 references), Trust Instrument Document, Trust Term Provision, Trust Role (grantor, trustee, co-trustee, successor trustee, trust protector, directed investment or distribution adviser; the trust company as a 09 LEN-, individuals as 02 PTY-) and Beneficial Interest (current, remainder, contingent). TRUST- is reserved instead of TRS-; the 15 example 'TRS-000412' becomes 'TRUST-000412' and the CW-035 wording '51 the trust terms (TRS-)' reads TRUST- at the merge. 02 Party Relationship rows Trustee Of and Grantor Of for trusts with a 51 record are a Derived copy of Trust Role (row rule, CD-289). CITs under 12 CFR 9.18 stay 01 and 35.",
     "rationale": "The fiduciary record has its own regulator (OCC 12 CFR Part 9), statutes and system. Lever: drop 51; 15 keeps the certification facts.",
     "action": "W2 (51); W2 merge (15 example, CW-035 wording, 02 row rule)", "status": P, "priority": "Low", "owner_role": PL},

    {"id": "CW-076", "theme": "Ownership", "title": "Trust accounting is a principal and income ledger, not a book of record; fiduciary tax is 51",
     "domains": ["51", "49", "50", "46", "47", "19", "13"],
     "issue": "Trust accounting statements show cash and assets that 49 masters; Form 1041 overlaps 19 (tax) and 13 (tax documents).",
     "resolution": "51 masters Principal and Income Allocation (the principal or income character of each receipt and disbursement, by UPIA or the 2018 Uniform Fiduciary Income and Principal Act per governing-law state, confirm adoption) and Fiduciary Accounting Statement (principal and income cash; market value as a Derived copy of 49). 49 masters holdings, lots and cash; 50 the distribution payment; 46 investment management; 47 trustee fees (51 allocates their principal and income charge). 51 masters Fiduciary Tax Return (TXRT-; Form 1041 or optional grantor-trust reporting, elections under IRC sections 645 and 663(b), DNI) and Beneficiary Tax Allocation (Schedule K-1); 19 keeps the firm's own tax; 13 delivers K-1s.",
     "rationale": "Principal and income is a fiduciary classification the custody record does not carry; copying balances would create a fourth book of record. Lever: outsourced trust accounting keeps only received statements.",
     "action": "W2 (51); W3 (49, 50 references)", "status": P, "priority": "Low", "owner_role": PL},

    {"id": "CW-077", "theme": "Ownership", "title": "Estate settlement cases are 51 where the firm is the fiduciary; account transfers after death stay 13; the death is 02",
     "domains": ["51", "02", "13", "15"],
     "issue": "02 Death Notification, 13 Service Request with Transfer of Ownership & Estate and an estate settlement case all describe a death.",
     "resolution": "02 records the death (DTHN-); 13 handles every request to transfer or re-register a decedent's account; 51 Estate Settlement Case (ESTATE-) exists only when the trust company is executor, administrator or agent for the personal representative, with court, letters, inventory, creditor period, tax and distribution milestones. Fiduciary Account Review (FIRV-) records the 12 CFR 9.6 pre-acceptance, initial post-acceptance and annual reviews (the initial review is 'prompt' in the rule; a 60-day policy is OCC guidance, confirm).",
     "rationale": "The fiduciary's administration is a case with legal duties; an account transfer is a service request. Lever: agent-only estate services.",
     "action": "W2 (51, 13 brief)", "status": P, "priority": "Low", "owner_role": PL},

    # ---- Cross-cutting ----------------------------------------------------------------------------------------------
    {"id": "CW-078", "theme": "Glossary", "title": "Term conflicts from the 03, 08 and 51 briefs",
     "domains": ["03", "05", "08", "13", "15", "16", "38", "45", "50", "51"],
     "issue": "New W2 objects reuse common words.",
     "resolution": "Log in TERM_CONFLICTS: Advisor (03 own representative; 05 External Advisor) as ruled; Team (03 Coverage Team; 05 Advisor Team, moved from the wholesale 02); Review (08 Supervisory Review; 45 advice review per the 45 brief; 51 Fiduciary Account Review; 38 Compliance Program Review) - always qualified; Case (08 Senior Investor Case; 38 AML Case; 51 Estate Settlement Case; 13 Service Request is not a case); Trust (51 Trust instrument; 02 trust party; 16 plan trust); Beneficiary (51 Beneficial Interest; 15 Beneficiary Designation); Distribution (51 trust distribution; 50 money movement; 16 plan distribution); Plan (03 Incentive Compensation Plan always named in full, beside 45 Financial Plan and 16 Retirement Plan).",
     "rationale": "Qualified names keep the glossary unambiguous. Lever: none.",
     "action": "W5 (TERM_CONFLICTS)", "status": P, "priority": "Low", "owner_role": PL},

    {"id": "CW-079", "theme": "Scope", "title": "US-only decisions of the W2 conduct domains: CW-903, CW-908 and CW-951",
     "domains": ["03", "08", "51"],
     "issue": "CW-022 pre-allocates CW-9NN for each domain; a new domain has no wholesale module to remove from.",
     "resolution": "The 03 drafter writes CW-903 (wholesale 03 EU/UK values and sources, and the EU/UK parts of the 07 objects 03 absorbs: NUTS and UK postcode geography, the MiFID and SYSC 19F remuneration conflict assessment, ESMA and FCA remuneration sources); the 08 drafter writes CW-908 (FCA financial promotions, Consumer Duty, MiFID product governance and inducements, cross-border marketing and AIFMD pre-marketing, SM&CR certification, FCA complaints fields, the EU/UK retention values, 13 sources); the 51 drafter writes CW-951 stating that no EU/UK content existed. Removal entries use the regimes of jurisdiction.REGIMES.",
     "rationale": "Keeps a UK extension restorable from the sibling. Lever: UK extension.",
     "action": "W2 (proposals_03.py, proposals_08.py, proposals_51.py)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-080", "theme": "Structure", "title": "07 stays in the tree until W4; the concept register moves the absorbed 07 objects to 03 at the W2 merge (amplifies CW-013)",
     "domains": ["07", "03", "04", "06", "10", "20"],
     "issue": "03 absorbs Coverage Model, Call Frequency Standard, Party Coverage Assignment, Incentive Compensation Plan and Compensation Statement at W2, but 07 retires at W4 and 04, 06 and 10 still reference its territories and crediting rules.",
     "resolution": "The wholesale 07 module stays in the tree until W4 so that territory and crediting references in 04, 06 and 10 keep resolving; at the W2 merge CONCEPT_OWNERSHIP and PREFIXES move CVA-, ICP- and CPS- (and the five object names) to 03, and readers resolve to 03. During W2 to W4 the five names exist in both modules; the explorer marks 07 'retiring at W4 (CW-013)'. At W4 07 is retired with its remaining prefixes (CW-062) and DP-009's owner domain becomes 03.",
     "rationale": "Avoids unresolved references in adapted domains before their own stage. Lever: none.",
     "action": "W2 merge; W4 (07 retired)", "status": P, "priority": "Medium", "owner_role": PL},
]

# ---------------------------------------------------------------------------------------------------------------------
# PREFIXES (prefix, entity, owner domain, status, note) - decisions.PREFIXES format. Near-misses rejected are in each note
# and in the briefs' section 6. Checked against decisions.PREFIXES (410 entries), plan section 5.2 anchors, the W1
# reservations, the 45/46/47 anchors (PLN-, FGL-, RCO-, ADE-, MAS-, RBL-, TLH-, TPB-, FBR-, FDB-, FWV-, FSC-) and
# prefix-like tokens in every content module: none equal, anagram or one edit away.
# ---------------------------------------------------------------------------------------------------------------------
R = "Reserved"

PREFIXES = [
    # 03
    ("RFRL-", "Channel referral (digital, service, workplace or advice channel to another channel or advisor)", "03", R, "W2 brief 03 (CW-065). Rejected CHRF- (one edit from CHRQ-, 41), REFL-, XREF-, REF-."),
    ("REAS-", "Coverage reassignment event", "03", R, "W2 brief 03 (CW-062). Rejected reuse of RLN- (07), CRSG- (anagram of SRCG-, 40), RASN-."),
    ("ASRL-", "Coverage assignment rule", "03", R, "W2 brief 03 (CW-062). Rejected reuse of ALR- (07), CARL- (one edit from CAL-, 09), CVRL-."),
    ("RECG-", "Recognition award", "03", R, "W2 brief 03 (CW-064). Rejected AWRD- (one edit from AWD-, 11), RCGN- (one edit from RCN-, 06), RCGA-."),
    # 08
    ("PRNR-", "Supervisory (principal) review: recommendation, rollover, account type, approval, transaction, correspondence", "08", R, "W2 brief 08 (CW-066). Rejected SUPV-, SPRV- (one edit from SURV-, SRV-), SREV-, PREV- (one edit from REV-; PREV- also PREQ-, 40), SPVR- (one edit from SVR-, 12), PRVW- (registered, 36)."),
    ("SCEN-", "Surveillance scenario version", "08", R, "W2 brief 08 (CW-066). Rejected SCNR-, SSCN-."),
    ("CORAC-", "Conduct corrective action", "08", R, "W2 brief 08 (CW-066). Rejected CORR- (one edit from CRR-, 07, and COR-, 48 anchor), CRCA-, CRAC-, CRAT- (one edit from CRA-, 07), CACT- (one edit from ACT-, 03), CCAP- (one edit from RCAP-, 43), CORX- (one edit from CRX-, 02)."),
    ("BRIN-", "Branch inspection (FINRA Rule 3110(c))", "08", R, "W2 brief 08 (CW-066). Rejected BINS- (one edit from INS-, 17)."),
    ("SFND-", "Supervisory finding", "08", R, "W2 brief 08 (CW-066). Rejected SUPF-."),
    ("HSPL-", "Heightened supervision plan", "08", R, "W2 brief 08 (CW-066). Rejected HSUP-, HSP-."),
    ("SNRC-", "Senior investor case (FINRA Rule 2165 supervisory case)", "08", R, "W2 brief 08 (CW-071). Rejected SENC- (one edit from the SEC token), SIVC-."),
    # 51
    ("TRUST-", "Trust (instrument)", "51", R, "W2 brief 51 (CW-075). Replaces the plan anchor TRS- (one edit from TRSV-, 38; anagram of STR- and RST-, 01). Rejected TRST- (one edit from TRSV-, RST-), TRIN- (one edit from TRIP-, 44, TRN-, 12), TINS- (one edit from INS-, 17). 15 example TRS-000412 re-pointed at merge."),
    ("TDRQ-", "Trust distribution request", "51", R, "W2 brief 51 (CW-075). Replaces the plan anchor TDD- (one edit from TMD-, 07, TRD-, 11, MDD- and PDD-, 52 anchors). Rejected DSRQ- (one edit from SRQ-, 13), TDST-."),
    ("FIRV-", "Fiduciary account review (12 CFR 9.6)", "51", R, "W2 brief 51 (CW-077). Rejected FIDR- (one edit from IDR-, 11), FDRV- (one edit from FDIV-, 27, DRV-, 10), FRVW- (one edit from PRVW-, 36), FARV-."),
    ("ESTATE-", "Estate settlement case", "51", R, "W2 brief 51 (CW-077). Replaces the plan anchor EST- (one edit from AST-, EVT-, 04, ESC-, 13, LST-, 17, RST-, 01, ENT-, 14). Rejected ESTC- (ESC-), ESTL- (anagram of SETL-, 26), ESTA- (ESGA-, 34), ESET- (DSET-, 14), PRBT- (PRJT-, 41)."),
    ("TXRT-", "Fiduciary tax return (Form 1041)", "51", R, "W2 brief 51 (CW-076). Rejected FTAX- (registered, 27), FTXR- (one edit from FXR-, 22), FTRN- (one edit from TRN-, 12)."),
]

# Status changes to apply to existing decisions.PREFIXES rows at the W2 merge (CW-062, CW-067, CW-068):
PREFIX_CHANGES = {
    "kept": {"03": ["ACT-", "SLT-"], "08": ["REV-", "CPL-", "LIC-", "GNE-", "ARC-", "SURV-", "SPA-", "FTC-"]},
    "entity_relabel": {"ACT-": "Advisor activity", "SLT-": "Coverage team"},
    "transferred": {"CVA-": ("07", "03"), "ICP-": ("07", "03"), "CPS-": ("07", "03"), "RET-": ("08", "21")},
    "held_for_05_at_W4": ["OPP-", "RFP-", "ANS-", "DBS-", "KAP-", "DDQ-"],
    "retired_now": ["PLY-", "FCS-", "FBK-", "MKN-", "PMK-", "RSL-", "COI-"],
    "retired_with_07_at_W4": ["TER-", "TMD-", "ALR-", "RLN-", "GOL-", "GPL-", "CRR-", "CRA-", "CTM-", "ERN-", "DSP-",
                              "CTL-", "RUN-", "CPRD-"],
    "anchors_replaced": {"TRS-": "TRUST-", "TDD-": "TDRQ-", "EST-": "ESTATE-"},
}

KEY_FORMATS = [
    # 03
    ("RFRL-", "RFRL-<year>-<sequence, 6 digits>, e.g. RFRL-2026-004417", "Channel referral."),
    ("REAS-", "REAS-<year>-<sequence, 4 digits>, e.g. REAS-2026-0031", "Coverage reassignment event."),
    ("ASRL-", "ASRL-<sequence, 4 digits>, e.g. ASRL-0142", "Coverage assignment rule."),
    ("RECG-", "RECG-<year>-<sequence, 5 digits>, e.g. RECG-2026-00218", "Recognition award."),
    ("CVA-", "CVA-<sequence, 7 digits>, e.g. CVA-1093345 (kept from 07)", "Party coverage assignment."),
    ("Advisor", "EMP- of 20, e.g. EMP-20417", "Profile pattern (CD-144); no prefix."),
    ("Firm Branch Office", "SITE- of 09, e.g. SITE-US-PHL-01", "Profile of 09 Office Location; no prefix."),
    ("Supervisory Assignment", "Composite: supervised EMP- / supervisor EMP- / effective from", ""),
    ("Principal Designation", "Composite: EMP- / designation type / SITE- or scope / effective from", ""),
    ("Advisor Capacity Snapshot", "Composite: EMP- or SLT- / as-of date", ""),
    ("Coverage Team Membership", "Composite: SLT- / EMP- / membership role / effective from", ""),
    # 08
    ("PRNR-", "PRNR-<year>-<sequence, 7 digits>, e.g. PRNR-2026-0041877", "Supervisory review."),
    ("SCEN-", "SCEN-<scenario code, 3-6 letters>-<version, 2 digits>, e.g. SCEN-XTRD-03", "Surveillance scenario version."),
    ("CORAC-", "CORAC-<year>-<sequence, 5 digits>, e.g. CORAC-2026-00412", "Conduct corrective action."),
    ("BRIN-", "BRIN-<year>-<sequence, 4 digits>, e.g. BRIN-2026-0087", "Branch inspection."),
    ("SFND-", "SFND-<year>-<sequence, 5 digits>, e.g. SFND-2026-00231", "Supervisory finding."),
    ("HSPL-", "HSPL-<year>-<sequence, 4 digits>, e.g. HSPL-2026-0012", "Heightened supervision plan."),
    ("SNRC-", "SNRC-<year>-<sequence, 5 digits>, e.g. SNRC-2026-00217", "Senior investor case; 02 Escalation Case Reference uses it."),
    ("Disclosure Delivery Check", "Composite: ACC- or PTY- / trigger / check date", ""),
    ("Incentive Conflict Review", "Composite: ICP- component / review date", ""),
    ("Supervisory Control", "Composite: POLCY- / control number", ""),
    ("Branch Registration", "Composite: SITE- / branch CRD number (fictitious in examples)", ""),
    # 51
    ("TRUST-", "TRUST-<sequence, 6 digits>, e.g. TRUST-000412", "Trust; 15 Governing Trust example re-pointed from TRS-000412."),
    ("TDRQ-", "TDRQ-<year>-<sequence, 5 digits>, e.g. TDRQ-2026-00318", "Trust distribution request."),
    ("FIRV-", "FIRV-<year>-<sequence, 5 digits>, e.g. FIRV-2026-01204", "Fiduciary account review."),
    ("ESTATE-", "ESTATE-<year>-<sequence, 4 digits>, e.g. ESTATE-2026-0031", "Estate settlement case."),
    ("TXRT-", "TXRT-<tax year>-<TRUST- or ESTATE- sequence>, e.g. TXRT-2026-000412", "Fiduciary tax return."),
    ("Trust Role", "Composite: TRUST- / PTY- or LEN- / role / effective from", ""),
    ("Beneficial Interest", "Composite: TRUST- / PTY- / interest type / effective from", ""),
    ("Principal and Income Allocation", "Composite: TRUST- / source event reference / allocation sequence", ""),
    ("Fiduciary Accounting Statement", "Composite: TRUST- / period end date", ""),
]

NOTES = [
    "Dependencies on the other W2 briefs: 45's object names and prefixes (Recommendation RCO-, Advice Engagement ADE-) are taken from the plan anchors; 46 and 47 names are 'per the brief'. The 47 fee-schedule prefix was not known when these prefixes were checked; the 47 brief must check it against RFRL-, REAS-, ASRL-, RECG-, PRNR-, SCEN-, CORAC-, BRIN-, SFND-, HSPL-, SNRC-, TRUST-, TDRQ-, FIRV-, ESTATE-, TXRT-.",
    "04 brief (W2): Lead Conversion.Converted Opportunity, Attributed Outcome.Attributed Opportunity (OPP-) and the Territory references (TER-, 07) need its ruling; this file recommends 02 Party / 15 Account for conversion and 03 Coverage Assignment Rule or 09 Geographic Group for geography.",
    "13 brief (W2): Service Request.Escalated Complaint stays a Reference (Complaint) to 08 CPL- (CW-070); Transfer of Ownership & Estate stays 13 (CW-077).",
    "Unverified, marked 'confirm' in the briefs: FINRA Rule 3110.19 effective date (Regulatory Notice 24-02); the SR-FINRA-2026-018 change to Rule 2165 hold periods; NASAA IAR CE adoption count (24 or 25 jurisdictions); the PTE 2020-02 republication citation and effective date (2026); UFIPA adoption by state; the OCC 60-day initial review practice; Securities Act Section 18 paragraphs for notice filings; FINRA Rule 3290 effective date; Qualification Exam values Series 4, 9/10 and 51.",
    "Tooling: none required. domains.py already registers 03 AO, 08 RC (REPLACEMENT_L1_CODE) and 51 TE; the new modules are written beside the wholesale 03 and 08 modules, so check_enrichment.py's directory-order pick (W1 merge notes) applies again.",
]
