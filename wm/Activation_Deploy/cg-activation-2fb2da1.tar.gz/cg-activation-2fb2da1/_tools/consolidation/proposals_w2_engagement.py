"""Wealth-manager reference model: W2 brief decisions for 04 Marketing, Digital & Client Engagement and 13 Client Service &
Communications (CW-081 to CW-094; CW-095 left unused) and the prefixes the two briefs reserve.

Written by the W2 brief agent with 00_Program/Rework/Briefs/04_Marketing_Digital_and_Client_Engagement.md and
13_Client_Service_and_Communications.md. Format: the DECISIONS dict format and the PREFIXES tuple format of decisions.py
(see CONTRACT.md). Declarative only; every decision is "Proposed" until the program lead merges it, and each states the
tailoring lever. The US-only passes of the two domains are decided under the pre-allocated CW-904 and CW-913 (CW-022),
which the drafters write in their own proposals files; they are not in this file.
"""

PL = "Program lead"
P = "Proposed"

DECISIONS = [
    {"id": "CW-081", "theme": "Ownership", "title": "Trade confirmations: 48 masters the confirmation record, 13 masters its delivery",
     "domains": ["13", "48", "29", "06"],
     "issue": "SEC Rule 10b-10 requires a written confirmation of each client trade. CW-010 gives confirmations to 48; the wholesale 13 holds a Trade Confirmation attribute group of Investor Document (Confirmed Transaction, Confirmation Timing, Confirmation Sent Date). Both domains would hold 'Trade Confirmation'.",
     "resolution": "48 masters the client trade confirmation (the Rule 10b-10 content: security, price, capacity, markup or commission, order-routing and payment-for-order-flow disclosures, settlement date; anchor CCF-), named in the 48 brief so that it is not 'Trade Confirmation' bare. 13 renames its attribute group Confirmation Delivery (AG of Investor Document, STMT-): the reference to the 48 confirmation (or, for fund-only accounts, to the 29 Fund Order), Confirmation Timing (immediate, periodic under Rule 10b-10(b), consolidated on the statement) and delivery dates; the delivery method, status, e-delivery and suppression are Investor Document attributes. 13 holds no trade economics. Readers: keys_g5_11_12_13_14.py and the pending DP-091 re-point to Confirmation Delivery at WP0. Term conflict 'Confirmation' logged (48 record; 13 delivery).",
     "rationale": "The record and its delivery have different owners, systems (OMS and books-and-records versus document composition) and evidence. Lever: a firm whose clearing vendor produces confirmations keeps only the delivery reference in 13.",
     "action": "W2 (13), W3 (48)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-082", "theme": "Ownership", "title": "The fund shareholder's voting-choice election is a 13 fact; the options and policies stay in 34",
     "domains": ["13", "34", "01", "49", "06"],
     "issue": "CW-934 added Voting Policy.Voting Choice Option Type and Voting Choice Offered Funds to 34 and left the shareholder's election to 13; the 34 notes ask whether Voting Choice Option Type should be shared and whether the offering needs its own effective-dated link.",
     "resolution": "13 masters Voting Choice Election (VCEL-; shareholder account (15 ACC-) x fund (01 PRD-) x period): the chosen 34 Voting Policy version, the option type, election channel, election and effective dates, default applied indicator and revocation. 34 keeps the policies, the options offered and the votes cast; it reads the elections to vote pass-through shares. The proportional shares are not mastered in 13 (Client Holding 49 or Fund Shareholder Position 06 at the record date). Voting Choice Option Type becomes a shared list stewarded by 34 with 13 as a member, not a 13 copy. The offering stays on the versioned 34 Voting Policy; the 13 draft validates an election against the policy version in force and does not add a policy x fund x period link (lever below).",
     "rationale": "The election is a client instruction captured and serviced by client service; the policy and the vote are stewardship. Lever: if the firm offers different options per fund over time, 34 adds an effective-dated Voting Choice Offering link at W5; a firm without investor choice drops VCEL-.",
     "action": "W2 (13), W5 (shared list)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-083", "theme": "Ownership", "title": "Prospects before they are parties: visitors and leads stay in 04 until the identity threshold",
     "domains": ["04", "02", "15"],
     "issue": "The 02 brief (SME question 9) holds that prospects are parties once identity is captured and anonymous leads stay in 04. 04 Marketing Lead holds Captured Name, Captured Email and Lead Party; 04 Web Visitor holds Matched Party. Without a threshold the same person is mastered in both.",
     "resolution": "An anonymous or partly identified person is a 04 Web Visitor (VIS-) or Marketing Lead (LEAD-); captured values are flagged PII, kept as captured lineage and never maintained as party data. At the identity threshold (name plus a verified email or phone, or any application start) 02 creates or matches a Party with Relationship Stage Prospect, and 04 references PTY- from then on (Lead Conversion.Converted Party, Web Visitor.Matched Party). Starting an application makes the party an Applicant with a 02 Onboarding Case; the 04 Application Journey records the journey to submission. Match rules and survivorship are 02's.",
     "rationale": "One master per person, and a clear point at which marketing stops holding personal data of its own. Lever: a stricter threshold (application start only) keeps more in 04; a looser one creates prospects at first identified visit.",
     "action": "W2 (04)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-084", "theme": "Ownership", "title": "Communication preferences: opt-in state in 02; topics, suppression and visitor tracking choices in 04; document delivery elections in 13",
     "domains": ["02", "04", "13"],
     "issue": "02 masters Contact Preference, Communication Preference (party x topic x channel opt-in, with Preference Topic referencing 04 Subscription Topic), Consent Record and Privacy Profile (CW-029, CW-902). The wholesale 04 carried opt-in lists and a Suppression Entry that 'overrides' preferences; 13 holds E-Delivery Election.",
     "resolution": "02 masters the party's marketing opt-in per topic and channel, TCPA consents (CNS-), do-not-contact and the Reg S-P, Reg S-AM and state-law opt-outs. 04 masters the Subscription Topic catalog (SUB-), the Suppression Entry list (operational suppressions: hard bounces, spam complaints, National Do Not Call Registry scrubs, TCPA revocations, competitor and employee exclusions), Email Interaction unsubscribe events (written to 02 Communication Preference within the CAN-SPAM 10 business days) and the Tracking Consent Choice of visitors who are not matched to a party (cookie banner and Global Privacy Control signals); once matched, the sale or sharing opt-out is 02 Privacy Profile. 13 masters elections for required documents (E-Delivery Election DEL- linked to an E-SIGN Consent Record; householding; mail hold). 04 keeps no Opt-In Status, Opt-In Method or Opt-Out Source lists of its own.",
     "rationale": "Preferences and consents are party facts; catalogs, suppression lists and sends are marketing operations; required-document delivery is service. Lever: a firm whose marketing platform is the system of record for opt-ins flags the 02 attributes as Derived copies of 04.",
     "action": "W2 (04, 13)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-085", "theme": "Ownership", "title": "The acquisition funnel ends at account opening; attribution weights in 04, net new assets by campaign in 06",
     "domains": ["04", "02", "15", "45", "06", "50"],
     "issue": "Acceptance questions 2 and 11 need net new assets by campaign and lifetime value by acquisition channel. 04 would hold applications started and abandoned, 15 Account Opening holds the application from receipt, 45 holds digital advice engagements, and 06 attributes flows to channel, advisor and campaign (plan section 5.1).",
     "resolution": "04 masters Application Journey (JRNY-; applicant x journey type x start: steps, abandonment, resumption, submission, resulting 02 Onboarding Case and 15 Account) and Acquisition Milestone (party x milestone type x date: prospect created, application submitted, account opened, account funded, advice enrolled, rollover completed), with opening and funding dates as Derived copies of 15 and 50. From submission 15 Account Opening is the master; the digital advice questionnaire is 02 Investor Profile and the advice engagement and recommendation are 45. 04 Attributed Outcome credits milestones to campaigns under an Attribution Model (weights); 06 computes net new assets by campaign by applying those weights to its flows; 04 Attributed Amount is a Derived copy of 06. 10 computes lifetime value by acquisition channel from the 04 first-touch campaign.",
     "rationale": "Each fact keeps one owner while the funnel stays answerable end to end. Lever: a firm without a digital journey drops Application Journey and keeps milestones.",
     "action": "W2 (04, 45), W4 (06, 10)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-086", "theme": "Ownership", "title": "Authentication: digital logins in 04, assisted-service authentication in 13, CIP verification in 02, controls in 41",
     "domains": ["04", "13", "02", "41"],
     "issue": "Logins to the website and app, the authentication of a caller or chat user, the customer identification program and identity and access management controls all record 'identity' events.",
     "resolution": "04 masters the client's Digital Profile (DIGP-; re-cut from the wholesale Portal Account and the successor of the wholesale 02 Digital Profile: status, MFA factors enrolled, biometric login flag, last login) and Session and Engagement Event rows for logins and app events. 13 masters Interaction Authentication (interaction x attempt: method, result, step-up, failure counts used for Regulation S-ID red flags), referencing 02 Identity Verification (KYCV-) when a CIP check is performed during service. Neither holds passwords, one-time codes or biometric templates. Voice biometric consent is a 02 Consent Record. 41 masters the IAM platform, authentication policy and security incidents.",
     "rationale": "The split follows who authenticates the person (the platform or a representative) and keeps CIP evidence single (CW-025). Lever: a firm with one identity platform for both channels keeps the events in 04 and references them from 13.",
     "action": "W2 (04, 13)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-087", "theme": "Ownership", "title": "Who delivers which disclosure: opening disclosures 15, periodic and event communications 13, fee disclosures 47, initial privacy notice evidence 02",
     "domains": ["13", "15", "47", "02", "38", "16"],
     "issue": "15 Account Disclosure Delivery records account-opening and feature disclosures; 47 masters fee disclosures delivered; 02 Privacy Profile.Initial Privacy Notice references a 13 communication (CW-902); 38 files Form CRS; 16 holds Plan Notice. Periodic broker-dealer and adviser communications have no stated owner.",
     "resolution": "13 Shareholder Communication (COMM-, name kept for its readers) masters periodic and event-driven regulatory communications to clients and fund shareholders: tailored shareholder reports, prospectus and notice delivery, annual privacy notices where the Reg S-P exception does not apply, Form CRS updates (Rule 17a-14, Advisers Act Rule 204-5), the annual Form ADV summary of material changes (Rule 204-3), annual margin disclosure (FINRA Rule 2264), SIPC notice (FINRA Rule 2266), BrokerCheck notice (FINRA Rule 2267), sweep program notices (SEC Rule 15c3-3(j)(2)), the Rule 3a-4 quarterly notice to managed-account clients (referenced by 45 Advice Review) and Reg S-P incident notices. 15 keeps account-opening and feature disclosures, 47 fee disclosures, 38 the Form CRS filing, 16 the Plan Notice record (13 delivers it). 02 keeps the initial privacy notice evidence by reference.",
     "rationale": "Delivery evidence sits with the process that produces it. Lever: a firm that sends opening disclosures through the same composition engine records them as 13 communications referenced by 15.",
     "action": "W2 (13, 47)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-088", "theme": "Ownership", "title": "Outsourced-TA oversight and intermediary beneficial-owner communications leave 13 (amends CD-202)",
     "domains": ["13", "29", "05", "19", "40"],
     "issue": "CD-202 kept outsourced-TA oversight in 13. The wealth firm runs its transfer agent in house, and the intermediary channel is thin (CW-013). 13 holds Servicing Provider Engagement, Intermediary Distribution Request, NOBO List Request and Intermediary Communication Fee Invoice; 40 (line 80) references Servicing Provider Engagement, 19 (line 236) the fee invoice, and the live DP-176 and DP-210 read Servicing Provider Engagement.",
     "resolution": "Servicing Provider Engagement moves to 29 at W3 (with the in-house TA it is the oversight of TA vendors such as print, escheat and proxy agents) and Intermediary Distribution Request and NOBO List Request move to 29 at W3 (broker searches under Rule 14a-13 run off the intermediary omnibus register); Intermediary Communication Fee Invoice moves to 05 at W4 with the intermediary payments. Names and prefixes (BOD-, IFI-) move unchanged. To keep every reference resolving, the W2 13 draft carries the four objects unchanged and flagged transitional; the receiving drafter takes them by name and the receiving merge re-points DP-176, DP-210, 19 and 40. Servicing Error (ERR-), Shareholder Remediation (RMD-) and Service Level Definition (SVL-) stay in 13 for client-impacting errors and client service levels.",
     "rationale": "Oversight of a TA belongs with the TA operation; intermediary fund-communication logistics with the intermediary domains. Lever: an outsourced TA keeps the oversight record in 29 at full depth.",
     "action": "W2 (flag), W3 (29), W4 (05)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-089", "theme": "Ownership", "title": "Deceased-client servicing and returned mail",
     "domains": ["13", "02", "15", "51", "50"],
     "issue": "02 masters Death Notification (DTHN-) with an Intake Service Request; 13 Transfer of Ownership & Estate repeats Decedent and Date of Death; 15 holds beneficiary designations and restrictions; 51 masters estate settlement cases. 02 Postal Address.Mail Returned Date and 13 Lost Shareholder Status.First Returned Mail Date both hold returned mail (02 notes ask who masters it).",
     "resolution": "02 masters the death notification and the reported date of death; 13 masters the service requests that follow (notification intake, re-registration, transfer on death and beneficiary claims, estate document collection) and references DTHN-, 15 Beneficiary Designation (ABD-) and, where the trust company acts, the 51 Estate Settlement Case (ESTATE-); 15 masters the resulting account restrictions and lifecycle events; 50 the disbursements. Decedent and Date of Death leave Transfer of Ownership & Estate. 13 Recipient Delivery Record masters returned mail (date and reason); 02 Mail Returned Date becomes a Derived copy of 13 and Lost Shareholder Status reads the 13 record.",
     "rationale": "Facts about the person stay in 02; the servicing workflow stays in 13; delivery outcomes are delivery facts. Lever: a firm whose CRM masters returned mail flips the Derived copy.",
     "action": "W2 (13, 51), 02 Derived flag at the W2 merge", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-090", "theme": "Ownership", "title": "Third-party issuer proxy pass-through to brokerage clients and the OBO / NOBO election are 13",
     "domains": ["13", "49", "34"],
     "issue": "The self-clearing broker-dealer must forward issuer proxy and other materials to the beneficial owners it carries and collect their voting instructions (SEC Rule 14b-1; FINRA Rule 2251), and record whether each client objects to disclosure of its name to issuers. No domain holds this; the wholesale 13 saw only the fund side.",
     "resolution": "13 masters Issuer Proxy Pass-Through (third-party issuer meeting x account: materials delivered, delivery method, voting instruction received and transmitted, broker discretionary vote permitted) and Beneficial Owner Disclosure Election (account x period: objecting or non-objecting). The record-date position is a Derived copy of 49 Client Holding; the issuer meeting is referenced from the 49 corporate action event (per the 49 brief). 34 votes only the funds' portfolio holdings.",
     "rationale": "Forwarding and instruction capture are client communications with delivery evidence. Lever: a firm that leaves pass-through entirely to its agent keeps aggregates only.",
     "action": "W2 (13), W3 (49)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-091", "theme": "Ownership", "title": "Personalization, nudges and experiments are 04; a nudge that may be a recommendation is routed to 45 and 08",
     "domains": ["04", "45", "08", "21"],
     "issue": "Digital engagement practices (prompts, nudges, A/B tests) can amount to a recommendation under Reg BI or the Advisers Act. The SEC's 2023 predictive data analytics proposal was withdrawn on June 12, 2025 (confirm), but the conduct rules apply.",
     "resolution": "04 masters Nudge Definition (NUDG-; trigger, channel, content asset, Recommendation Risk Class, 08 review reference), Nudge Delivery, Experiment (EXPMT-; variants, primary metric by reference to 21, decision) and Experiment Assignment. A nudge classed Potential Recommendation cannot be delivered without an 08 review, and any recommendation it carries is a 45 Recommendation (RECOM-) referenced from the delivery. Experiment results are computed in products, not stored in 04.",
     "rationale": "Engagement mechanics are marketing data; recommendations and their evidence stay single in 45 (CW-008). Lever: a firm that sends only educational nudges drops the risk class.",
     "action": "W2 (04, 45, 08)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-092", "theme": "Ownership", "title": "Promotions and referrals: definitions and enrollment in 04; awards in 50 and 47; tax reporting in 13; review in 08",
     "domains": ["04", "50", "47", "13", "08"],
     "issue": "Funding bonuses, transfer-fee reimbursements, commission-free offers and client referral rewards touch money movement, fees, tax reporting and the marketing rule (a paid client referral is an endorsement or testimonial under Advisers Act Rule 206(4)-1).",
     "resolution": "04 masters Promotion Offer (PROMO-), Promotion Enrollment (offer x party, optional account: qualification and award status) and Client Referral (CRFL-; referrer x referee x code: status, reward, endorsement disclosure delivered). The cash award is a 50 Money Movement; a fee waiver or credit is a 47 Fee Waiver (FWV-); a reportable award is a 13 Form 1099-MISC; terms and endorsements are reviewed by 08. An internal hand-off of a client between the firm's channels is the 03 Channel Referral (RFRL-), not a Client Referral.",
     "rationale": "One owner per fact; the promotion keys them together. Lever: drop the family.",
     "action": "W2 (04, 47, 08), W3 (50)", "status": P, "priority": "Low", "owner_role": PL},

    {"id": "CW-093", "theme": "Ownership", "title": "Voice of client: surveys and NPS in 04, interaction quality in 13, complaints in 08",
     "domains": ["04", "13", "08"],
     "issue": "Relationship and transactional NPS, CSAT and verbatims overlap with 13 QA Review and Contact Center Interaction.Dissatisfaction Expressed Indicator and with 08 complaints (FINRA Rule 4530).",
     "resolution": "04 masters Client Survey (CSVY-) and Survey Response (SRSP-; score, verbatim flagged PII and possibly special category, triggering 13 interaction or 15 milestone, complaint referral). 13 keeps QA Review and the dissatisfaction flag on the interaction. A response or interaction that may be a written complaint is referred to 08, which masters the complaint.",
     "rationale": "Feedback programs are run by client experience; complaint handling is a regulated process. Lever: vendor-held responses are loaded as aggregates only.",
     "action": "W2 (04, 08)", "status": P, "priority": "Low", "owner_role": PL},

    {"id": "CW-094", "theme": "Ownership", "title": "Client segments (02) versus marketing audiences (04)",
     "domains": ["02", "04"],
     "issue": "02 Segment Assignment carries schemes such as Client Value Segment, Life Stage and Digital Engagement Segment; 04 holds Marketing Segment and Segment Membership.",
     "resolution": "02 masters the enterprise segment assignment of a party (effective dated, used for service, reporting and pricing). 04 masters audiences built for activation (rule, refresh, destination channel) and their membership at activation time; an audience may use a 02 segment as a criterion but never re-assigns it. The 02 Digital Engagement Segment, where kept, is set from 04 Engagement Score and declared a Derived copy of 04.",
     "rationale": "A segment is a classification; an audience is a campaign artifact. Lever: a firm that segments only for marketing drops the 02 scheme.",
     "action": "W2 (04), 02 note at the W2 merge", "status": P, "priority": "Low", "owner_role": PL},
]

# ---------------------------------------------------------------------------------------------------------------------
# Reserved prefixes (decisions.py tuple format: prefix, entity, owner Data Domain, status, note).
# Checked against decisions.PREFIXES (410 rows, every status), the plan section 5.2 anchors (PLN FGL RCO ADE MAS RBL TLH
# TPB FSC FBR FDB FWV COR CEX CCF CRT CHL CLT RSV CAA CAX MMT SWP PBK MMH TRS TDD EST MGR MDD SAA PDD), the series and L1
# codes, prefix-like tokens in the content, consolidation and data product modules, and each other. A candidate was
# rejected if equal to, an anagram of, or one edit (substitution, insertion, deletion) from any of them. Also checked against
# the sibling W2 reservations: 03 (RFRL REAS ASRL RECG), 08 (PRNR SCEN CORAC BRIN SFND HSPL SNRC), 45-47 (proposals_w2_advice.py)
# and 51 (TRUST TDRQ FIRV ESTATE TXRT).
# Rejected near-misses:
#   JRNY-: APJ- (APV- 19), APPJ- (APPL- 41), AJR- (AGR- 05, ATR- 06, ALR- 07, ACR- 10)
#   NUDG-: NDG- (LDG- 19, NDT- 16), NUD- (BUD- 10)
#   EXPMT-: EXP-, EXPT-, EXPE-, EXPI-, EXPRM- (EXPR- 44, EMP- 20), ABT- (ABD-, ABI- 15, ACT- 03, AST- 04), XPR- (PRX- 13),
#           TEST- (EST- plan 51); EXPMT- is two edits from EXPR- (noted, not rejected)
#   PROMO-: PRMO- (PRMD- 16), PROF-, PROM- (PROL-, PFOR- 16), PMO- (PMT- 05, PMK- 08), OFFP- (OFFR- 01)
#   CRFL-: RFRL- (reserved by the W2 03 brief for Channel Referral), RFR- (RFP- 03, FRR-, PFR- 10)
#   CSVY-: SURV- (08), SVY- (SVL- 13, SVR-, SVT-, SVA- 12), CSUR- (CSR- 12), VOC- (SOC- 04, DOC- 05), NPS- (SNP- 06,
#          CPS- 07), FBK- (08), FDBK- (FBK- 08, FDB- plan 47)
#   SRSP-: SURR- (SURV- 08)
#   DIGP-: DGP- (DP- 21, DSP- 07)
#   VCEL-: VCE- (CEV- 11, anagram of the CVE- token in 41); VCEL- is two edits from VCON- (02, noted)
# ---------------------------------------------------------------------------------------------------------------------
R = "Reserved"

PREFIXES = [
    ("JRNY-", "Application journey (applicant x journey type x start)", "04", R, "W2 brief 04 (CW-085). Rejected APJ-, APPJ-, AJR-."),
    ("NUDG-", "Nudge definition (nudge x version)", "04", R, "W2 brief 04 (CW-091). Rejected NDG-, NUD-."),
    ("EXPMT-", "Experiment (A/B or multivariate test)", "04", R, "W2 brief 04 (CW-091). Rejected EXP-, EXPT-, EXPE-, EXPRM-, ABT-, XPR-, TEST-; two edits from EXPR- (44)."),
    ("PROMO-", "Promotion offer (offer x version)", "04", R, "W2 brief 04 (CW-092). Rejected PRMO-, PROF-, PROM-, PMO-, OFFP-."),
    ("CRFL-", "Client referral (referrer x referee x code; not the 03 Channel Referral)", "04", R, "W2 brief 04 (CW-092). Rejected RFRL- (03), RFR-; REFR- and REFL- read as 'reference'."),
    ("CSVY-", "Client survey (survey x version)", "04", R, "W2 brief 04 (CW-093). Rejected SURV-, SVY-, CSUR-, VOC-, NPS-, FBK-, FDBK-."),
    ("SRSP-", "Survey response", "04", R, "W2 brief 04 (CW-093). Rejected SURR-."),
    ("DIGP-", "Digital profile (client online login profile; successor of 04 Portal Account)", "04", R, "W2 brief 04 (CW-086). Rejected DGP-."),
    ("VCEL-", "Voting choice election (shareholder account x fund x period)", "13", R, "W2 brief 13 (CW-082). Rejected VCE-; two edits from VCON- (02)."),
]

# Proposed key formats (proposals_w1_15.py KEY_FORMATS format: prefix or object, format with example, note).
KEY_FORMATS = [
    ("JRNY-", "JRNY-<year>-<sequence, 7 digits>, e.g. JRNY-2026-0418822", "Application journey."),
    ("NUDG-", "NUDG-<sequence, 4 digits>; the version is an attribute, e.g. NUDG-0117", "Nudge definition."),
    ("EXPMT-", "EXPMT-<year>-<sequence, 4 digits>, e.g. EXPMT-2026-0031", "Experiment."),
    ("PROMO-", "PROMO-<year>-<sequence, 3 digits>, e.g. PROMO-2026-007", "Promotion offer."),
    ("CRFL-", "CRFL-<sequence, 8 digits>, e.g. CRFL-00041877", "Referral; the referral code shown to clients is a separate attribute."),
    ("CSVY-", "CSVY-<sequence, 4 digits>, e.g. CSVY-0012", "Client survey."),
    ("SRSP-", "SRSP-<year>-<sequence, 8 digits>, e.g. SRSP-2026-00918231", "Survey response."),
    ("DIGP-", "DIGP-<sequence, 8 digits>, e.g. DIGP-00104588", "Digital profile; never the client's login name."),
    ("VCEL-", "VCEL-<year>-<sequence, 7 digits>, e.g. VCEL-2026-0004512", "Voting choice election."),
    ("Acquisition Milestone", "Composite: PTY- / milestone type / milestone date, e.g. 'PTY-104588 / ACCOUNT_FUNDED / 2026-03-04'", "No prefix."),
    ("Nudge Delivery", "Composite: NUDG- / PTY- / delivered timestamp", "No prefix."),
    ("Experiment Assignment", "Composite: EXPMT- / VIS- or PTY-", "No prefix."),
    ("Promotion Enrollment", "Composite: PROMO- / PTY- (/ ACC-)", "No prefix."),
    ("Tracking Consent Choice", "Composite: VIS- / captured timestamp", "No prefix."),
    ("Interaction Authentication", "Composite: CCI- / attempt number, e.g. 'CCI-2026-1184520 / 1'", "No prefix."),
    ("Issuer Proxy Pass-Through", "Composite: issuer meeting reference (49) / ACC-", "No prefix."),
    ("Beneficial Owner Disclosure Election", "Composite: ACC- / effective from", "No prefix."),
]

NOTES = [
    "Ids: CW-081 to CW-094 used; CW-095 left unused. The US-only pass decisions are CW-904 (04) and CW-913 (13), drafted with the modules.",
    "Dependencies on the other W2 briefs: 08 (object names for Complaint and Compliance Review; the wholesale CPL- and REV- are assumed kept; CW-091 to CW-093 need 08 review routes), 03 (advisor and team object for lead routing and assisted service), 45 (Advice Engagement ADENG- and Recommendation RECOM-: CW-085, CW-091), 47 (Fee Waiver FWV- and fee disclosure delivery: CW-087, CW-092), 51 (Estate Settlement Case EST-: CW-089). W3: 48 names its confirmation object (CW-081), 49 its holding, activity and corporate action objects (CW-082, CW-090), 29 receives three 13 objects (CW-088). W4: 05 receives the fee invoice; 06 computes net new assets by campaign (CW-085).",
    "Name alignment for the 45 brief: it writes 'Contact-Center Interaction'; the 13 object is 'Contact Center Interaction' (CCI-, name kept).",
    "For the 02 owner at the W2 merge: Postal Address.Mail Returned Date becomes a Derived copy of 13 Recipient Delivery Record (CW-089); the Digital Engagement Segment scheme, if kept, is a Derived copy of 04 Engagement Score (CW-094).",
    "For the 34 owner at W5: Voting Choice Option Type becomes a shared list (steward 34, member 13) (CW-082).",
    "CD-202 is amended by CW-088 (13 no longer keeps outsourced-TA oversight after W3).",
    "Example drift seen in 16 (not edited): content_16_retirement_plan_administration.py line 365 uses STMT-2027-1099R-0071188, which does not follow the STMT- format STMT-<year>-<code, 2 characters>-<sequence, 7 digits>.",
    "READERS - live products at the W2 merge: DP-011 (04 CE Credit Issued, Campaign Member.Added By Salesperson, Event Registration.Invited By Salesperson; model data_models/models_f3.py lines 14-170), DP-075 (04 Marketing System, kept), DP-106, DP-169, DP-244 (13, kept), DP-176 and DP-210 (13 Servicing Provider Engagement, transitional to 29 at W3). Key registries keys_g2_03_04_05.py 335-397 and keys_g5_11_12_13_14.py 387-429 are superseded at WP2. Pending products (CW-041) are listed in the briefs' section 9.",
]
