"""Consolidation proposals from the W3 adaptation of Data Domain 16 Retirement Plan Administration (wealth manager), 2026-10-15.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py,
shared_code_lists.py and jurisdiction.REMOVALS at the W3 merge. Formats follow CONTRACT.md in this folder. The brief is
00_Program/Rework/Briefs/16_Retirement_Plan_Administration.md (Disposition: Adapt, CW-006; L1 code RP kept). It implements
CW-003, CW-022, CW-023, CW-045, CW-051, CW-087, CW-107, CW-915 and CW-125 to CW-127 (proposals_w3_oversight.py), and completes
CW-916, the US-only pass of 16. Module: content_16_retirement_plan_administration.py (adapted in place; output path and folder
unchanged). The brief names this file proposals_16.py; the assignment named it proposals_w3_16.py, which is used.
"""

_D, _C = "16", "CW-916"

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES (decisions.PREFIXES tuple format). None beyond PLPST-, PEXC- and PRTHO-, which proposals_w3_oversight.py
#    reserves (CW-128). One format is missing for a registered 16 prefix that is now used as a key (PFEE-).
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

PREFIX_FORMATS = [
    ("PFEE-", "16", "PFEE-<sequence, 6 digits>", "PFEE-004412"),   # Plan Fee Schedule.Plan Fee Line ID (new key; 45 already uses it)
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED MEMBERSHIPS: 16 local lists that carry a shared list's exact name. 16 had none before W3.
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Frequency", "local": "Frequency",
     "value_map": {"Weekly": "WEEKLY", "Biweekly": "FORTNIGHTLY", "Semi-Monthly": "SEMI_MONTHLY", "Monthly": "MONTHLY",
                   "Quarterly": "QUARTERLY", "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL", "On Event": "ON_EVENT",
                   "Per Payroll": "PER_PAYROLL"},
     "new_values": ["SEMI_MONTHLY", "PER_PAYROLL"],
     "note": "New member (steward 09). Used by Investment Election.Automatic Rebalancing Frequency and Participant Distribution "
             "Election.Installment Frequency. The wholesale local copy's 'Bi-Weekly' is relabeled 'Fortnightly' (shared label). "
             "Semi-Monthly and Per Payroll are payroll frequencies the shared list lacks; proposed to the steward (brief section 8). Fix pass: "
             "the local label is the US 'Biweekly' (mapped to FORTNIGHTLY); ask the 09 steward to relabel FORTNIGHTLY 'Biweekly', "
             "keeping 'fortnightly' as a synonym in the description."},
    {"shared": "Case Status", "local": "Case Status",
     "value_map": {"New / Received": "NEW", "In Progress": "IN_PROGRESS", "Waiting on Client": "WAITING_ON_CLIENT",
                   "Pending Third Party": "PENDING_THIRD_PARTY", "Resolved / Completed": "RESOLVED", "Closed": "CLOSED",
                   "Canceled": "CANCELED"},
     "new_values": [],
     "note": "New member (steward 09). Late Deposit Case.Late Deposit Case Status and Plan Correction.Plan Correction Status. The "
             "wholesale values Open, Pending Sponsor and Pending Regulator are re-cut to NEW, WAITING_ON_CLIENT (the sponsor) and "
             "PENDING_THIRD_PARTY (REPOINTS)."},
    {"shared": "Reconciliation Status", "local": "Reconciliation Status",
     "value_map": {"Not Reconciled": "NOT_RECONCILED", "Reconciled": "RECONCILED",
                   "Reconciled within Tolerance": "RECONCILED_WITHIN_TOLERANCE", "Break Open": "BREAK_OPEN",
                   "Break Explained": "BREAK_EXPLAINED"},
     "new_values": [],
     "note": "New member (steward 06). Plan Conversion.Record Reconciliation Status. Wholesale Pending -> Not Reconciled, Breaks Open "
             "-> Break Open, Reconciled with Adjustments -> Reconciled (REPOINTS)."},
    # Data Quality Status and Confidentiality Classification: 16 was never registered; the local copies left with Record
    # Metadata (CD-160). Business Line, Record Status and Approval Status: no 16 attribute needs them (every 16 record is WR;
    # Hand-Off outcome values carry the retail destination). Tax Form Type (steward 15) holds the W-9 / W-8 family, not 1099-R
    # or 5498, so it does not apply; the 1099-R box 7 code stays local (Form 1099-R Distribution Code).
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED CANDIDATES: local lists that look like enterprise lists
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Contribution Source", ["16", "15", "45", "46"],
     "Money source of plan contributions and balances. 15 Plan Participant Account.Money Sources Held already reads it as "
     "'External (16 Contribution Source)'; 45 Rollover Analysis and 46 asset location may need it. Steward 16."),
    ("QDIA Type", ["16", "01"],
     "Moved from 02 with the plan statistics (CW-023). 01 target date series and service offerings may classify the same way."),
    ("Plan Characteristic Code", ["16", "11"],
     "Form 5500 line 8a codes; 11 market intelligence reads public Form 5500 data for plans recordkept elsewhere. External list."),
    ("Rollover Source Type", ["16", "45", "50"],
     "Kind of plan or IRA a rollover comes from or goes to; 45 Rollover Analysis source plan type and 50 rollover receipts."),
    ("Hand-Off Outcome", ["16", "04", "06"],
     "04 Acquisition Milestone 'Rollover Completed' and the 06 rollover capture rate read the outcome values; agree them once."),
    ("Hardship Reason", ["16", "15"],
     "Treasury safe harbor reasons; special category (CD-344). 15 IRA hardship-type exceptions do not use it today."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (decisions.TERM_CONFLICTS format), from the brief section 13 and the plan section 5.3 watchlist
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Plan",
     "usages": [("02", "Retirement Plan (PTY-)", "The employer plan as a party."),
                ("45", "Financial Plan / Financial Plan Version", "A client's financial plan."),
                ("16", "Plan Document, Plan Investment Option and every 'Plan ...' object", "Administration of a recordkept retirement plan.")],
     "recommendation": "Never bare 'Plan' in a definition that can be read either way: 'Retirement Plan' (02, 16) or 'Financial Plan' "
                       "(45). 16 object names keep their 'Plan' prefix; their definitions say retirement plan.",
     "resolution": "Qualified everywhere.", "status": "Resolved", "decision": "CW-045"},
    {"term": "Rollover",
     "usages": [("16", "Distribution Request (Rollover Direction), Rollover Contribution Detail, Participant Retail Hand-Off",
                 "The distribution rolled to an IRA or another plan, and incoming rollovers."),
                ("45", "Rollover Analysis (ROLV-) / Recommendation of type Rollover", "The rollover recommendation and PTE 2020-02 evidence."),
                ("50", "Money Movement (rollover receipt)", "The cash received into a firm IRA.")],
     "recommendation": "Bare 'Rollover' is the 16 distribution; 'Rollover Recommendation' or 'Rollover Analysis' is 45; '50 rollover "
                       "receipt' for the cash on the IRA side.",
     "resolution": "Split by fact (CW-045, CW-126).", "status": "Resolved", "decision": "CW-126"},
    {"term": "Account",
     "usages": [("15", "Plan Participant Account (ACC-)", "The participant's account; holds no amount (CW-915)."),
                ("16", "Participant Plan Membership (PMEM-) and Participant Balance", "Plan-law facts and the balances."),
                ("29", "Plan omnibus register account (Share Register Balance)", "The plan's account at the transfer agent.")],
     "recommendation": "'Participant Account' is 15; 16 never holds an account master; the omnibus is 29.",
     "resolution": "15 account, 16 membership and balance, 29 omnibus.", "status": "Resolved", "decision": "CW-125"},
    {"term": "Balance",
     "usages": [("16", "Participant Balance", "Recordkept participant balance by money source and investment option."),
                ("49", "Client Holding (CLHLD-) / cash balances", "Brokerage book of record, including brokerage windows and IRAs."),
                ("50", "Sweep Balance", "Swept cash at program banks."),
                ("29", "Share Register Balance", "TA register balance, including the plan omnibus.")],
     "recommendation": "Always qualified: 'Participant Balance' (16), 'Client Holding' (49), 'Sweep Balance' (50), 'Share Register "
                       "Balance' (29). 16 definitions never say holding or position.",
     "resolution": "Four books, four names.", "status": "Resolved", "decision": "CW-125"},
    {"term": "Transfer",
     "usages": [("16", "Participant Investment Transfer (PEXC-)", "Exchange or rebalance between plan options within a membership."),
                ("29", "Fund Share Transfer", "Fund Order types Transfer Out and In on the register."),
                ("49", "Account Transfer", "ACATS and other account transfers."),
                ("50", "Cash Transfer", "Money moved between accounts.")],
     "recommendation": "Always qualified. 46 and its readers may say 'participant exchange' for the 16 object; the object name stays "
                       "Participant Investment Transfer (46 content line 321 references it by that name).",
     "resolution": "Qualified everywhere.", "status": "Resolved", "decision": "CW-125"},
    {"term": "Posting / Transaction",
     "usages": [("16", "Participant Ledger Posting (PLPST-)", "Recordkeeping posting."),
                ("29", "Register Transaction", "TA register posting."),
                ("06", "Transaction (TXN-)", "Firm-wide flow view."),
                ("18", "Portfolio Transaction", "IBOR transaction."),
                ("49", "Client Account Activity", "Brokerage activity.")],
     "recommendation": "16 attribute names Posting Transaction, Disbursement Transaction, Forfeiture Transaction, Settlement "
                       "Transactions and Mapping Transactions are kept for their readers but typed Participant Ledger Posting.",
     "resolution": "Names kept, types re-cut (CW-125).", "status": "Resolved", "decision": "CW-125"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION (jurisdiction.REMOVALS entry format; CW-022). The wholesale 16 was already US only.
# ---------------------------------------------------------------------------------------------------------------------


def _j(obj, attr, regime, note):
    return {"domain": _D, "object": obj, "attribute": attr, "regime": regime, "decision": _C, "note": note}


JURISDICTION = [
    _j("Retirement Plan Profile", "UK Pension Scheme Registry Number", "Other EU/UK",
       "Moved from 02 under CW-023; left out. The Pensions Regulator's Pension Scheme Registry number for UK schemes (wholesale 02 "
       "Retirement Plan statistics). US plans are identified by sponsor EIN and plan number on the 02 Retirement Plan."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. REPOINTS (object, attribute, before, after, decision)
# ---------------------------------------------------------------------------------------------------------------------
REPOINTS = [
    ("Contribution Record", "Posting Transaction", "Reference (Transaction) to 06 TXN-", "Reference (Participant Ledger Posting) PLPST- (name kept)", "CW-125"),
    ("Participant Loan", "Disbursement Transaction", "Reference (Transaction) to 06 TXN-", "Reference (Participant Ledger Posting) PLPST- (name kept)", "CW-125"),
    ("Forfeiture Record", "Forfeiture Transaction", "Reference (Transaction) to 06 TXN-", "Reference (Participant Ledger Posting) PLPST- (name kept)", "CW-125"),
    ("Distribution Request", "Settlement Transactions", "Reference (Transaction) (multi) to 06 TXN-", "Reference (Participant Ledger Posting) (multi) PLPST- (name kept)", "CW-125"),
    ("Fund Change Event", "Mapping Transactions", "Reference (Transaction) (multi) to 06 TXN-", "Reference (Participant Ledger Posting) (multi) PLPST- (name kept)", "CW-125"),
    ("Vested Balance by Source", "Source Position", "Reference (Position) to 06 POS-",
     "renamed Source Participant Balance, Reference (Participant Balance) (multi); the bare 'Position' fails the books-of-record test", "CW-125"),
    ("Service Arrangement", "Governing Agreement", "Reference (Agreement) to 05 AGR-", "Reference (Contract, 39) CTRCT- (name kept)", "CW-127"),
    ("Form 5500 Detail", "Total Plan Assets at Year End", "Derived copy (06)", "Calculated from Participant Balance (16); DERIVED entry removed", "CW-125"),
    ("Form 5500 Detail", "Participants with Balances at Year End", "mastered, unflagged", "Calculated from Participant Balance (16)", "CW-125"),
    ("Participant Plan Membership", "Participant Account", "15 account holding balances by money source", "15 account that holds no amount; balances are 16 Participant Balance", "CW-915"),
    ("Tax Withholding & 1099-R Detail", "Tax Form Document", "example STMT-2027-1099R-0071188", "example STMT-2027-TX-0071188 (STMT- key format)", "CW-087"),
    ("Plan Fee Schedule", "Plan Fee Line ID", "no identifier (composite key)", "added, PFEE- (registered 16 prefix; 45 and 47 reference it)", "CW-051"),
    ("Family RP-FID", "", "Plan Fiduciaries, Service Roles & Fee Arrangement", "Plan Sponsor, Fiduciaries, Service Roles & Fees (code kept)", "CW-127"),
    ("Family RP-DMG", "", "Retirement Plan Administration Data Management (Record Metadata)", "removed (CD-160, CW-020); DCAM source removed with it", "CW-020"),
    ("Code list: Frequency", "Bi-Weekly", "Bi-Weekly", "Biweekly (maps to shared FORTNIGHTLY; relabel requested)", "CW-916"),
    # Fix pass (16_review.md and the 12 review addendum), 2026-10-15
    ("Participant Investment Transfer", "Source Trade Proposal", "Reference (Trade Proposal, 46)", "removed; the link is held on 46 only (Released Participant Investment Transfer, n : 1)", "CW-127"),
    ("Employment Event", "Payroll Employee ID", "Derived copy (02)", "mastered here (the sponsor's payroll key as delivered by the feed); DERIVED entry removed", "CW-125"),
    ("Contribution Record", "", "grain contribution batch x membership x source", "grain contribution (CONT-): membership x source x receipt; batch blank for non-payroll receipts (row rule)", "CW-126"),
    ("Code list: Contribution Source", "", "18 values", "adds Employer Match Roth, Employer Nonelective Roth (SECURE 2.0 s.604), PLESA (s.127), In-Plan Roth Rollover, SIMPLE / SEP Roth (s.601)", "CW-916"),
    ("Code list: Managed Account Fiduciary Basis", "", "3(38), 3(21), two 408(g), AO 2001-09A", "adds Trustee Fiduciary and Plan Sponsor Fiduciary; QDIA rule (29 CFR 2550.404c-5(e)(3)) on Fiduciary Basis", "CW-127"),
    ("Code list: Hand-Off Outcome", "", "Rolled to Another Plan or IRA; Automatic Rollover IRA; Installments from Plan", "split by destination: Rolled to Firm-Recordkept Plan, Rolled to External Plan or IRA; automatic rollover and installments folded in", "CW-126"),
    ("Code list: Posting Type", "Earnings and Dividends", "Earnings and Dividends", "Dividends and Capital Gains (unit value changes are not posted)", "CW-125"),
    ("Code list: QDIA Type", "", "", "adds Grandfathered Stable Value (404c-5(e)(4)(v))", "CW-127"),
    ("Code list: Form 1099-R Distribution Code", "", "", "adds E (EPCRS distributions); source marked as a subset", "CW-916"),
    ("Code list: Late Deposit Correction Program", "source", "DOL VFCP / SECURE 2.0 section 305", "DOL VFCP including the 2025 update (confirm)", "CW-916"),
    ("Code list: Plan Fiduciary & Service Role", "", "", "adds Plan Fiduciary Committee (sponsor's fiduciary or investment committee; for 12)", "CW-127"),
    ("Participant Retail Hand-Off", "Contact Consent", "primary SEC Regulation S-P", "primary Internal (firm policy), secondary SEC Regulation S-AM", "CW-126"),
    ("REL", "Plan Fee Schedule is billed by Fee Schedule Assignment [47]", "Plan Fee Schedule", "Service Arrangement is billed by Fee Schedule Assignment [47]", "CW-051"),
    ("Code list: Case Status", "Open; Pending Sponsor; Pending Regulator", "Open; Pending Sponsor; Pending Regulator", "New / Received; Waiting on Client; Pending Third Party (shared labels; Resolved / Completed added)", "CW-916"),
    ("Code list: Reconciliation Status", "Pending; Breaks Open; Reconciled with Adjustments", "wholesale local labels", "Not Reconciled; Break Open; Reconciled (shared labels; within Tolerance and Break Explained added)", "CW-916"),
    ("Code list: Recordkeeping Program", "descriptions", "RecordkeeperDirect-type, PlanPremier-type product names", "generic descriptions; Large Plan Program added", "CW-006"),
    ("Code list: Plan Fiduciary & Service Role", "Advisor of Record; Recordkeeper", "plan-level financial professional; 'The firm'", "external advisor (02 party in a role); firm or prior or successor recordkeeper", "CW-023"),
    ("REL", "Plan Conversion is owned by", "Employee [09]", "Employee [20]", "CW-021"),
    ("REL", "Service Arrangement is governed by", "Agreement [05] (05 Distribution Agreement governs intermediary partners, not plan clients)", "Contract [39] (the sponsor's recordkeeping services contract; 16 holds no separate client contract); confirmed at the fix pass after the 05 draft", "CW-127"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. DECISIONS: the US-only pass of 16 (pre-allocated by CW-022; drafted at brief level in proposals_w3_oversight.py)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-916", "theme": "Scope", "title": "US-only pass of 16 Retirement Plan Administration", "domains": ["16", "02"],
     "issue": "The wholesale 16 is already US only (META 'Scope: US'); the grep for MiFID, UCITS, ESMA, PRIIP, UK, EU, FCA and GDPR "
              "finds nothing in the module. Its perspective was an asset manager recordkeeping small and mid-sized DC plans as a side "
              "business. The 02 Retirement Plan statistics restored under CW-023 include UK Pension Scheme Registry Number.",
     "resolution": "Removed (1 JURISDICTION entry, Other EU/UK): Retirement Plan Profile.UK Pension Scheme Registry Number, not "
                   "restored from the wholesale 02 (CW-023). Nothing else is EU/UK. Kept and re-sourced: none needed; the new objects "
                   "cite US sources only (IRC 402 and 402A, Treas. Reg. 1.401(a)(31)-1 and 1.402(c)-2, Rev. Rul. 2014-9, Notice "
                   "2020-62 as modified by Notice 2026-13, DOL 29 CFR 2550.404a-2, 2550.404c-5 and 2550.408g-1, Advisory Opinion "
                   "2001-09A, PTE 2020-02, SEC Rules 22c-1 and 22c-2, SECURE 2.0 sections 120, 127 and 604). Perspective: META subtitle "
                   "'Business domain 16 - Retirement Plan Administration | Wealth manager (direct) | Scope: US'; overview rewritten for "
                   "the in-house recordkeeper of a direct wealth manager, the participant book of record and rollover capture. Also "
                   "dropped (not jurisdiction): Record Metadata (CD-160, CW-020) with Data Quality Status, Confidentiality "
                   "Classification and the DCAM source. Adaptation: Participant Balance, Participant Ledger Posting (PLPST-) and "
                   "Participant Investment Transfer (PEXC-) added and five 06 references re-typed (CW-125); Participant Retail Hand-Off "
                   "(PRTHO-) and Rollover Contribution Detail added, Distribution Request gains Hardship Reason, Receiving Account and "
                   "Originating Hand-Off (CW-126); Plan Sponsor Profile, Recordkeeper Profile, Plan Service Provider and Retirement Plan "
                   "Profile moved in, Plan Managed Account Service and the Distribution and Service Elections added, Governing "
                   "Agreement re-typed to 39 (CW-127); Plan Fee Line ID (PFEE-) added (CW-051). Counts (built, Record Metadata "
                   "excluded, after the fix pass): 11 to 13 families, 43 to 55 objects, 275 to 354 attributes, 84 to 118 CDEs (33%), 59 to 74 code lists, "
                   "55 to 88 relationships, 25 to 33 sources.",
     "rationale": "Fix pass (16_review.md): 354 attributes, 118 CDEs (33%) under the 360 band ruling; Source Trade Proposal removed, "
                  "Unit Value Applied, Posting Unit Value, Referred Advisor, Linked Distribution Request and Hand-Off Rollover Amount "
                  "added. CW-003 and CW-022: the firm is regulated and services clients in the US only. Names are kept so that DP-094 and the "
                  "15, 29, 37, 39, 40, 45, 46 and 47 references keep resolving; the five re-typed references keep their names (CW-125). "
                  "Lever: a UK extension restores the registry number from wholesale-v1.0 through the jurisdiction register.",
     "action": "W3", "status": "Proposed", "priority": "Low", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 8. NOTES for the W3 merge
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "READERS OF RE-TYPED, RENAMED OR REMOVED 16 CONTENT (lines as of 2026-10-15). "
    "DP-094 Recordkept Plan & Participant Core (live, foundational) in data_products/specs_q_accounts_plans.py: 273 (Service "
    "Arrangement.Governing Agreement, now 39 Contract), 275 (Plan Fee Schedule columns; add Plan Fee Line ID), 279 (Fund Change "
    "Event.Mapping Transactions, now Participant Ledger Posting), 289 (Investment Election.Automatic Rebalancing Frequency, kept; "
    "values re-cut to the shared Frequency labels), 294 and 333 (Vested Balance by Source.Source Position, renamed Source Participant "
    "Balance; 'Source Position resolves to DP-007' no longer holds: it resolves inside DP-094 once Participant Balance is published). "
    "DP-094 should also publish Participant Balance (the book of record) and the moved profiles; propose at WP0. "
    "DP-095 Plan Contribution, Loan & Distribution Operations (pending, CW-041): 370-374 (Unposted Contribution Amount reads Posting "
    "Transaction against 06 Transaction ID; re-point to Participant Ledger Posting), 407 (Posting Transaction), 414 (Disbursement "
    "Transaction), 418 (Forfeiture Transaction), 421 (Settlement Transactions), 431-433 (06 Transaction columns, drop), 445 (rule "
    "'resolves to a Transaction ID in DP-006', re-point to Ledger Posting ID), 456 (Transaction Status note). "
    "DP-096 Plan Compliance Testing & Filing Status (pending): 531-532 (Form 5500 Detail Participants with Balances at Year End and "
    "Total Plan Assets at Year End, kept, now calculated from Participant Balance); no other change. "
    "Data models: models_f4_accounts_plans.py 228 and 298 (Plan Fee Schedule, add Plan Fee Line ID as key), 262 and 332 (Source "
    "Position note), 296 (Service Arrangement -> Distribution Agreement on Governing Agreement; re-point to Contract, DP-213), 331 "
    "(Mapping Transactions to DP-006), 361 (Posting Transaction note), 404-405 (Transaction dimension), 425, 431, 441, 448-449 and 467 "
    "(fks Posting Transaction, Disbursement Transaction, Forfeiture Transaction, Settlement Transactions to Transaction; re-point to "
    "a Participant Ledger Posting fact), 461-462 (text). "
    "Keys: keys_g6_15_16.py 128 (family comment, renamed), 131 (Plan Fee Schedule composite key; becomes PFEE- Plan Fee Line ID), 155 "
    "and 310 (Vested Balance by Source; Source Position renamed, POSITION target removed), 275 (Governing Agreement: AGREEMENT -> 39 "
    "Contract), 285, 298, 304, 313, 317 (TRANSACTION targets -> 16 Participant Ledger Posting); RP-BAL and RP-ROL keys added at WP2. "
    "keys_e7_19_21.py 362, keys_e7_27_29.py 457, keys_e7_37_38.py 262 and keys_e7_39_41.py 239 and 374 read kept 16 objects "
    "(Participant Plan Membership, Payroll Contribution Batch, Plan Correction, Service Arrangement): no change. "
    "Semantic models: sm_15_people_workplace.py 236 (hidden Own Plan Membership key to DP-094): no change. No 16 Record Metadata key "
    "was found in the key registries.",
    "Live readers in content modules (checked): 46 line 321 Reference (Participant Investment Transfer, 16) PEXC- resolves to the new "
    "object; 45 lines 364, 379, 381 and 383 (Distribution Request, Participant Plan Membership, vested balance, Plan Fee Schedule "
    "PFEE-004412) resolve, and 45's Rollover Amount can now read Participant Balance.Vested Amount; 47 line 110 (Service "
    "Arrangement) and 39 line 69, 40 line 306, 37 line 168 and 29 line 51 resolve unchanged. 15 Plan Participant Account (content_15 "
    "line 468ff) example PMEM-0045120 does not follow the PMEM- format (PMEM-301121-004471); for the 15 owner.",
    "decisions.PREFIXES and CONCEPT_OWNERSHIP at the W3 merge: PLPST-, PEXC-, PRTHO- (proposals_w3_oversight.py) and CLFEE- (47) are "
    "not yet registered, so enrich_16 forces six references to 'mastered here', Managed Account Fee Schedule to 47 and Referred Advisor (EMP- key) to 03. Remove those "
    "OWNERSHIP_OVERRIDES once registered. Add CONCEPT_OWNERSHIP rows Participant Balance / Participant Ledger Posting / Participant "
    "Investment Transfer (16, PLPST- / PEXC-), Participant Retail Hand-Off (16, PRTHO-), Plan Sponsor Profile / Recordkeeper Profile "
    "/ Retirement Plan Profile (16, PTY- keyed), Plan Managed Account Service (16). The decisions.py 2160 row ('Payment is a 06 "
    "TXN-') and the 2155 row ('15 participant account positions are held in PINV- options') need rewording to Participant Ledger "
    "Posting and Participant Balance (CW-125).",
    "GRAIN_KEY_FORMATS (proposals_w3_oversight.py): the Participant Balance example uses the code EE_PRETAX while Contribution Source "
    "is a label list in 16 ('Employee Pre-Tax'); the module examples use labels. Align when Contribution Source becomes shared. "
    "Participant Distribution Election and Participant Service Election key formats name 'WITHHOLDING' and 'AUTO_PORTABILITY_OPT_OUT', "
    "which correspond to the 16 labels 'Federal Withholding - Nonperiodic (Form W-4R)' and 'Automatic Portability Opt-Out'.",
    "15 owner (CW-125, brief section 13): Plan Participant Account carries no amount (confirmed: content_15 line 468ff has none); "
    "Participant Account Status, Participant Enrollment Date and Default Investment Indicator duplicate 16 membership and election "
    "facts and should be Derived copies of 16 PMEM- with an as-of date (Default Investment Indicator and Terminated Participant "
    "Indicator already are). 15 Retirement Distribution Election (IRAs) and 16 Participant Distribution Election (plan memberships) "
    "split by account type; 15 RMD Record (IRAs) and 16 RMD Calculation (plans) likewise.",
    "29 (W3 sibling): Participant Ledger Posting.Resulting Plan Fund Order references Fund Order (29, FNDO-); 29 may add the inverse "
    "'Source Participant Investment Transfer' or read the postings. The reconciliation of the sum of Participant Balances per plan "
    "and option to the plan's 29 Share Register Balance is 29's (TA controls) and reads both sides.",
    "50 (W3 sibling): plan distributions and loans are paid on the recordkeeper's rail (CW-107 default, 50 brief question 8); the "
    "receipt of a direct rollover into a firm IRA is a 50 Money Movement referencing DIST-. No 16 attribute references 50.",
    "03 (W2): Participant Retail Hand-Off.Referred Advisor is Reference (Advisor, 03) with an EMP- example, forced to 03 in enrich_16. "
    "The hand-off now carries all CW-126 items (03 advisor, linked Distribution Request, rollover amount Calculated); the receiving 15 "
    "account stays on the Distribution Request. Linked Distribution Request and Distribution Request.Originating Hand-Off are inverse "
    "links that must agree.",
    "46 (W3 sibling, fix pass ruling 1): 46 Trade Proposal.Released Participant Investment Transfer is many-to-one: several Trade "
    "Proposals (the sells and buys of one rebalance) net into one 16 Participant Investment Transfer. 46 should state that cardinality "
    "at content_46 line 321 and make its REL (line 485) 'n : 1' toward 16. 16 holds no pointer back; its REL reads 'Trade Proposal "
    "[46] is released as Participant Investment Transfer, n : 1, held by 46'.",
    "05 (W4): Recordkeeper Profile covers any recordkeeper, so 05 'Plan Recordkeeper' (content_05 line 520) can read it; Plan Service "
    "Provider and Retirement Plan Profile cover firm-recordkept plans only, so for a prospect plan 05 reads 11 Plan Market Record "
    "(Plan Service Provider is not available for prospects).",
    "12 (W4, 12 review addendum): Plan Fiduciary & Service Role gains 'Plan Fiduciary Committee' (the sponsor's fiduciary or "
    "investment committee as a 02 party in a Plan Role Assignment), so 12 Plan Sponsor Servicing Detail can reference that "
    "role assignment (PROL-).",
    "15 and 16 both store the membership-to-account link (16 Participant Plan Membership.Participant Account, 15 Plan Participant "
    "Account.Participant Plan Membership). Proposed authoritative side: 15 references PMEM-; 16's Participant Account is kept for "
    "its readers and must agree.",
    "12 (W4): plan sponsor servicing and reporting are 12; Plan Sponsor Profile is administrative only.",
    "05 (W4): external advisors of record are 02 parties in the Plan Role Assignment role 'Advisor of Record'; their profiles move to "
    "05 at W4. No 16 reference to 05 remains (Governing Agreement re-typed to 39).",
    "04: Acquisition Milestone 'Rollover Completed' copies its date from the 50 rollover receipt today (content_04 lines 690 and 757). "
    "W3 merge request: read Participant Retail Hand-Off (PRTHO-) Hand-Off Outcome and Outcome Date, or keep 50 and drop the 16 REL "
    "(marked 'proposed').",
    "Brief section 4 out-of-scope row 'Distribution payments | 50 | Money Movement' contradicts CW-107 (recordkeeper rail); the draft "
    "follows CW-107. Correct the brief row at the merge.",
    "Program-lead band ruling applied: 354 attributes against the 360 band (fix pass). Code lists 74 against the brief's 52 to 58: the brief's "
    "count did not add its own 13 new lists to the 59 kept; no list was merged to meet it.",
    "Remaining grep hits for EU/UK terms: none. 'Holding' appears only qualified (Client Holdings 49, Portfolio Holdings 18) and in "
    "'withholding' / 'holding the role'; 'Position' only in the note that Source Participant Balance replaces the wholesale Source "
    "Position, and in the qualified 'Fund Shareholder Position (06)'.",
]
