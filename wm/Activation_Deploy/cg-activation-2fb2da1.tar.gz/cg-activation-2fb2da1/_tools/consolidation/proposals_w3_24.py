"""Consolidation proposals from the W3 adaptation of Data Domain 24 Portfolio Management & Construction (wealth manager), 2026-10-15.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py,
shared_code_lists.py and jurisdiction.REMOVALS at the W3 merge. Formats follow CONTRACT.md in this folder. The brief is
00_Program/Rework/Briefs/W3_24_32_Family_Additions.md (Disposition: Adapt, CW-009). It implements CW-003, CW-009, CW-022,
CW-046, CW-048, CW-121 and CW-128 (proposals_w3_oversight.py) and completes CW-924, the US-only pass of 24, drafted at brief
level in proposals_w3_oversight.py. Module: content_24_portfolio_management_and_construction.py (edited in place; codes,
folder and workbook unchanged). The expansion file proposals_24.py is left as it is (the brief names it; the assignment
names this file).
"""

_D, _C = "24", "CW-924"

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES: none beyond CMASET- and MLNUP-, reserved in proposals_w3_oversight.py (CW-130) with their PREFIX_FORMATS
#    and the GRAIN_KEY_FORMATS of Asset Class Return Assumption, Asset Class Correlation Assumption, Model Lineup Position
#    and Model Building Block. Until decisions.PREFIXES holds them, the module's references to its own new objects resolve
#    through the explicit "(..., 24)" in the type; no override was needed except Lineup Allocation Policy (STR- key).
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# AMENDMENTS to proposals_w3_oversight.py GRAIN_KEY_FORMATS (24_32 review D Low): the drafted grains differ from the brief-level
# key formats. (object, domain, before, after, example).
AMENDMENTS = [
    ("Asset Class Return Assumption", "24", "<CMASET- id> / <version> / <asset class code>",
     "<CMASET- id> / <version> / <Instrument Asset Class label> / <17 level-2 sub-class label, blank at asset-class level>",
     "CMASET-2026-001 / 2 / Equity / US Large Cap Equity"),
    ("Asset Class Correlation Assumption", "24", "<CMASET- id> / <version> / <asset class code> / <asset class code>",
     "<first Asset Class Return Assumption key> // <second Asset Class Return Assumption key> (same set version; first sorts before second)",
     "CMASET-2026-001 / 2 / Equity / US Large Cap Equity // CMASET-2026-001 / 2 / Fixed Income / US Aggregate Bonds"),
    ("Model Building Block", "24", "<MDL- id> / <SHC- or INS- id> / <role> / <effective from>",
     "unchanged; slot (Building Block Slot) and Alternate For Building Block are attributes, not key parts",
     "MDL-0077 / SHC-004512 / PRIMARY / 2026-01-01"),
    ("Asset Allocation Policy", "24", "(none)", "<STR-, PRD-, MDL- or MND- id> v<version>", "MND-01234 v3"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED MEMBERSHIPS. 24 cites the shared lists directly ("Shared: <name>", direct user): Business Line, Record Status,
#    Approval Status, Frequency, Period Type, Data Basis, Flow Direction, Instrument Asset Class, Instrument Type, Order Side,
#    Lot Relief Method. No new local copy.
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Business Line", "local": "", "value_map": {}, "new_values": [],
     "note": "Direct user (no local list). Committee Business Lines example re-keyed to 'PF; IA' (CW-004)."},
    {"shared": "Instrument Asset Class", "local": "", "value_map": {}, "new_values": [],
     "note": "Direct user. New users: Asset Class Return Assumption.Assumption Asset Class (every value except Multi-Asset and "
             "Derivative, CD-286 rule). The asset-class list that 46 drift and 24 targets share is this one (46 review)."},
    {"shared": "Record Status", "local": "", "value_map": {}, "new_values": [],
     "note": "Direct user. New users: Capital Market Assumption Set.CMA Set Status, Model Lineup.Model Lineup Status."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED CANDIDATES
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Risk Tolerance", ["02", "24", "45", "46"],
     "24 Model Lineup Position.Position Risk Band reads the 02 Investor Profile list as 'External (02 list Risk Tolerance)'. "
     "If 45 suitability bands and 46 program risk levels use the same scale, register it as a shared list stewarded by 02."),
    ("Time Horizon", ["02", "24", "45"], "Same pattern: 24 Position Horizon Band reads the 02 list."),
    ("Product List Status", ["52", "24", "16", "45"],
     "52 masters it (52 brief); 24 Model Building Block reads it as a Derived copy typed 'External (52 list Product List Status)'. "
     "Register as shared, steward 52, when 52 is drafted."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (decisions.TERM_CONFLICTS format)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Model (wealth model)",
     "usages": [("01", "Model Portfolio (MDL-)", "The model as an offering."),
                ("24", "Model Lineup (MLNUP-), Model Lineup Position, Model Building Block, Target Allocation Set", "How models are built: ladder, place on it, vehicles, weights."),
                ("37", "Model Inventory Entry (MODEL-)", "A quantitative model or algorithm under model risk management (CMA engine, decision algorithm, optimizer)."),
                ("46", "Model Assignment (MASGN-)", "Which account follows which model.")],
     "recommendation": "Bare 'model' is 37 (existing alias). Say 'model portfolio' (01), 'model lineup' (24), 'model assignment' (46).",
     "resolution": "Primary sense 37; the others qualified.", "status": "Resolved", "decision": "CW-128"},
    {"term": "Assumption (wealth model)",
     "usages": [("24", "Capital Market Assumption Set (CMASET-)", "Expected returns, volatilities, correlations and inflation."),
                ("45", "Planning Assumption Set", "A plan's assumptions; references the 24 set and adds plan-level inputs.")],
     "recommendation": "'Capital market assumptions' are 24 only; 45 inflation and return inputs are read from the set or flagged as plan overrides.",
     "resolution": "One owner for market assumptions.", "status": "Proposed", "decision": "CW-046"},
    {"term": "Tax Budget",
     "usages": [("24", "Tax Budget", "Institutional separate account held as an 18 portfolio."),
                ("46", "Account Tax Budget", "Retail managed account (15 ACC-).")],
     "recommendation": "Keep both names; 24 has no account key after CW-048.",
     "resolution": "Budget Account removed from 24.", "status": "Resolved", "decision": "CW-048"},
    {"term": "Position (wealth model)",
     "usages": [("24", "Model Lineup Position", "Place of a model on a lineup ladder; not a holding."),
                ("06", "Fund Shareholder Position", "Units of the firm's funds held by an account.")],
     "recommendation": "The 24 name is the brief's exact name; it is always qualified ('Model Lineup Position') and never means a holding. "
                       "'Initiate Position' and similar Investment Decision Action values describe portfolio actions and are kept.",
     "resolution": "Qualified use only.", "status": "Proposed", "decision": "CW-128"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION (jurisdiction.REMOVALS entry format; CW-924)
# ---------------------------------------------------------------------------------------------------------------------


def _j(obj, attr, regime, note):
    return {"domain": _D, "object": obj, "attribute": attr, "regime": regime, "decision": _C, "note": note}


JURISDICTION = [
    _j("Investment Decision", "Decision Supervising Branch Country", "MiFIR",
       "RTS 22 (Delegated Regulation (EU) 2017/590) Annex I field 58, country of the branch supervising the decision maker; a "
       "Derived copy (20) of the decision maker's work assignment; CDE. No US instance. Its DERIVED entry left enrich_24."),
    _j("Investment Decision", "Decision Algorithm Code", "MiFIR",
       "RTS 22 field 57 algorithm code, a Derived copy of the 37 Trading Algorithm Code removed under CW-937. Replaced by Decision "
       "Algorithm, Reference (Model Inventory Entry, 37), example MODEL-0441 / 1 (CW-128); its DERIVED entry left enrich_24."),
    _j("Sources", "Commission Delegated Regulation (EU) 2017/590 (RTS 22, transaction reporting under MiFIR Article 26), Annex I fields 57 and 58", "MiFIR",
       "Primary or secondary reference of Investment Decision ID, Decision Maker, Decision Timestamp, Scoped Decision, Scope "
       "Portfolio, Target Allocation Set.Originating Investment Decision, Proposed Trade.Originating Investment Decision and "
       "Portfolio Management Assignment.Decision Authority Indicator; all re-sourced to Advisers Act Rule 204-2(a)(3), added as a source."),
    _j("META and overview", "Subtitle; Purpose; CDE; Investment Decisions family definition; REL Investment Decision - Employee", "MiFIR",
       "'Scope: US + EU/UK', 'MiFIR transaction reporting (RTS 22)' as a basis, the CDE reason 'from which branch (MiFIR RTS 22)', "
       "'transaction reporting (MiFIR decision-maker field)' and 'RTS 22 field 57' in REL. Rewritten to 'Wealth manager (direct) | "
       "Scope: US' and the Rule 204-2(a)(3) order memorandum."),
    _j("META and overview", "Notes", "GDPR / UK GDPR",
       "'PII = personal data under GDPR / UK GDPR and US privacy laws' and 'the MiFIR decision-maker field identifies a natural "
       "person'. Rewritten to the GLBA, Regulation S-P and US state privacy laws."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. REMOVALS AND RE-TYPES THAT ARE NOT JURISDICTION ITEMS (CW-048 boundary), and REPOINTS
#    (object, attribute, before, after, decision)
# ---------------------------------------------------------------------------------------------------------------------
REPOINTS = [
    ("Tax Budget", "Budget Account", "Reference (Account), SMA account, CDE, part of the key",
     "removed; retail account tax budgets are 46 Account Tax Budget; Budget Portfolio (Reference (Portfolio, 18)) is now the CDE key "
     "with Tax Year (grain: 18 portfolio of an institutional separate account or sleeve x tax year)", "CW-048"),
    ("Tax Budget", "Net Realized Gain Budget; Short-Term Gain Budget; Loss Harvesting Target; Realized Gain to Date", "PII (personal financial data)",
     "confidential institutional client information, not personal data; examples scaled to institutional size", "CW-048"),
    ("Proposed Trade / Proposed Lot Selection / Rebalance Portfolio Result", "", "18 portfolios including individuals' SMA books; PII notes",
     "18 portfolios only (funds, sleeves, institutional separate accounts); 18 LOT- lots only; PII notes replaced by confidentiality notes", "CW-048"),
    ("Investment Decision", "Decision Algorithm Code", "Identifier, Derived copy (37)", "Decision Algorithm, Reference (Model Inventory Entry, 37)", "CW-128"),
    ("Investment Committee", "Committee Business Lines", "example 'Mutual Fund; Collective Investment Trust; Separately Managed Account'", "'PF; IA'", "CW-004"),
    ("Code list: Committee Decision Type", "", "10 values", "adds CMA Approval, Model Lineup Approval, Manager Hire, Manager Termination, Third-Party Product Approval", "CW-121, CW-128"),
    ("Code list: Investment Committee Type", "", "6 values", "adds Manager Research Committee", "CW-121"),
    ("Asset Allocation Policy", "Policy Purpose; Policy CMA Set", "", "added (CW-128)", "CW-128"),
    # Fix pass (24_32 review) additions and re-types
    ("Model Lineup", "Model Lineup Name; Lineup Service Offering", "", "added; Lineup Service Offering is Reference (Service Offering) (multi), OFFR-", "CW-128"),
    ("Model Building Block", "Building Block Slot; Alternate For Building Block", "", "added (slot and primary-alternate pairing)", "CW-128"),
    ("Asset Allocation Policy", "Policy Mandate", "", "added, Reference (Investment Mandate), MND-; 12 Investment Policy Statement.Policy Allocation should use the key '<MND-> v<version>'", "CW-128"),
    ("Portfolio Management Assignment", "Decision Authority Indicator", "primary Rule 204-2(a)(3), secondary Internal", "primary Internal, secondary Rule 204-2(a)(3)", "CW-924"),
    ("Model Lineup", "Model Lineup Purpose", "primary Rule 3a-4", "primary Internal, secondary Rule 3a-4", "CW-128"),
    ("Investment Decision", "Decision Algorithm", "example MODEL-0412 / 1 (a 37 factor risk model)", "MODEL-0441 / 1", "CW-128"),
    ("CDE flags", "", "Meeting Date, Committee Member, Tactical Stance, Assignment Effective From, Cash in Lieu Indicator, Custom Basket Approver, Proposed Trade Side flagged",
     "un-flagged; flagged instead Building Block Share Class, Building Block Instrument, Policy Model Portfolio, Policy Mandate, CMA Horizon Years, Model Lineup Status, Lineup Effective From, Lineup Service Offering, Building Block Slot", "CW-128"),
    # Retirement of 30 (CW-930, CW-166; proposals_w4_retire.py CARRIED_INTO_MERGE, 22 items for 24)
    ("Investment Committee Decision", "Decision Scope Deal", "Reference (Deal, 30), PDL-", "removed. Readers: DP-126 specs_e2_portfolio_stewardship.py 84, 127; keys_e7_22_24.py 238, 447; models_e8c_portfolio_stewardship.py 193; specs_e3_private_markets_product_range.py 235, 267, 285 and models_e8c_private_markets_product_range.py 271 (30 readers, retire at WP0)", "CW-930, CW-166"),
    ("Commitment Pacing Plan", "", "object group Commitment Pacing and object (9 attributes)", "removed (lever: a feeder program making serial commitments keeps it). Readers: DP-127 specs_e2_portfolio_stewardship.py 209-211, 215-216, 219, 235 and framework.py 945 (product name 'Asset Allocation Policy, Glide Paths & Commitment Pacing'); keys_e7_22_24.py 480; models_e8c_portfolio_stewardship.py 220-221, 261-262; SM-08 sm_08_investment_book_performance.py 550", "CW-930, CW-166"),
    ("Code list: Investment Committee Type", "Private Markets Investment Committee", "value", "removed", "CW-930"),
    ("Code list: Committee Decision Type", "Commitment Pacing Approval; Private Investment Approval; Private Investment Exit Approval", "values", "removed; Committee Decision Type example re-keyed to Manager Hire", "CW-930"),
    ("REL", "Investment Committee Decision approves Deal (30); Commitment Pacing Plan paces Portfolio (18)", "2 rows", "removed", "CW-930"),
    ("Sources", "ILPA Principles 3.0; ILPA Reporting Template", "2 rows", "removed", "CW-930"),
    ("META overview, Investment Governance and Targets & Constraints definitions, enrich_24 GRAIN and SUMMARY", "", "private investment approvals, commitment pacing plans, deals (30), CD-205 clause, next step 9", "removed", "CW-930, CW-166"),
    ("META overview and enrich_24 SUMMARY", "", "'asset manager ... SMAs, private markets and insurance-dedicated funds'; 'SMA accounts from 15'; '02 Client & Customer'",
     "wealth manager perspective; no 15 reference (Budget Account removed); '02 Client & Household'; '01 Investment Product & Service Offering'", "CW-003, CW-023"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. DECISIONS: CW-924 completed
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-924", "theme": "Scope", "title": "US-only pass of 24 Portfolio Management & Construction", "domains": ["24", "37", "46"],
     "issue": "24 carried MiFIR RTS 22 fields 57 and 58 on Investment Decision (Decision Algorithm Code, Decision Supervising "
              "Branch Country), the RTS 22 delegated regulation as the reference of the decision trail, GDPR notes and 'US + EU/UK' "
              "perspective; it also kept individuals' SMA accounts on Tax Budget, which CW-048 moves to 46.",
     "resolution": "Removed (5 JURISDICTION entries: 2 attributes, 1 source, 2 perspective items; all MiFIR except the GDPR Notes): "
                   "Investment Decision.Decision Supervising Branch Country and Decision Algorithm Code (the latter replaced by "
                   "Decision Algorithm, Reference (Model Inventory Entry, 37), CW-128); the source Delegated Regulation (EU) 2017/590. "
                   "Re-sourced to Advisers Act Rule 204-2(a)(3): Investment Decision ID, Decision Maker, Decision Timestamp, "
                   "Investment Decision Scope (Scoped Decision, Scope Portfolio), Target Allocation Set and Proposed Trade "
                   "(Originating Investment Decision), Portfolio Management Assignment.Decision Authority Indicator. Perspective: "
                   "subtitle 'Wealth manager (direct) | Scope: US'; overview rewritten; Notes to the GLBA, Reg S-P and state law; "
                   "Business Line example 'PF; IA'. Boundary (CW-048, not jurisdiction): Tax Budget.Budget Account removed; Tax "
                   "Budget, Proposed Trade, Proposed Lot Selection and Rebalance Portfolio Result limited to 18 portfolios. "
                   "Additions (CW-128, CW-121): families Capital Market Assumptions (Capital Market Assumption Set CMASET-, Asset "
                   "Class Return Assumption, Asset Class Correlation Assumption) and Advice Model Construction (Model Lineup MLNUP-, "
                   "Model Lineup Position, Model Building Block); Asset Allocation Policy gains Policy Purpose and Policy CMA Set; "
                   "decision and committee types added; fix pass: Model Lineup Name, Lineup Service Offering, Building Block Slot, Alternate For "
                   "Building Block, Policy Mandate. 30 retirement applied (CW-930, CW-166): Decision Scope Deal, Commitment Pacing Plan, "
                   "private-investment committee and decision types, two RELs and two ILPA sources removed. Counts (wholesale v0.1 to "
                   "fix pass): 8 to 10 families, 28 to 33 objects, 240 to 280 attributes, 81 to 98 CDEs (35.0%), 54 to 60 references, "
                   "9 to 8 derived, 32 to 35 code lists, 57 to 77 relationships, 19 to 19 sources.",
     "rationale": "CW-003 and CW-022: no MiFIR transaction reporting; the US record of who recommended and placed an order is the "
                  "Advisers Act order memorandum. CW-009 and CW-048: client managed accounts are 46. Lever: a UK or EU extension "
                  "restores fields 57 and 58 from wholesale-v1.0 through the jurisdiction register.",
     "action": "W3", "status": "Proposed", "priority": "Low", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 8. NOTES for the W3 merge
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "READERS OF REMOVED OR RE-TYPED 24 CONTENT (lines as of 2026-10-15). "
    "Decision Supervising Branch Country and Decision Algorithm Code: DP-126 data_products/specs_e2_portfolio_stewardship.py 86-87 "
    "(input columns), 115 (DQ rule 'either a Decision Maker ... or a Decision Algorithm Code'), 125, 141, 148-149 (notes); "
    "semantic model SM-08 sm_08_investment_book_performance.py 467-468 (decision_supervising_branch_country, decision_algorithm_code "
    "dimension attributes); data_models/models_e8c_portfolio_stewardship.py 120-121, 152, 196-197; data_models/keys_e7_22_24.py "
    "529-530 (comment). "
    "Tax Budget.Budget Account: DP-130 specs_e2_portfolio_stewardship.py 571, 573 (Realized Gain Tie-Out), 604, 635-636 (DQ rules on "
    "Budget Account); data_models/keys_e7_22_24.py 253 (Tax Budget key Budget Account / Budget Portfolio / Tax Year) and 510 (fk to "
    "15 Account); data_models/models_e8c_portfolio_stewardship.py 479 (grain) and 514 (rel Fact Tax Budget - Account). "
    "DP-127 (Asset Allocation Policy, Glide Paths & Commitment Pacing) reads unchanged objects; Asset Allocation Policy gains Policy "
    "Purpose and Policy CMA Set (optional new columns). No reader of 24 reads Proposed Trade or Proposed Lot Selection by a retail key.",
    "READERS (disposition, proposal). DP-126: replace Decision Algorithm Code by Decision Algorithm (join 37 Model Inventory Entry, "
    "DP-212) and drop Decision Supervising Branch Country; the DQ rule becomes 'either a Decision Maker or a Decision Algorithm'. "
    "SM-08: drop decision_supervising_branch_country; re-point decision_algorithm_code to a Model dimension key from Decision "
    "Algorithm (this closes the 'model gap' noted at models_e8c line 196-197). DP-130 'SMA Customization & Tax Management': its "
    "retail SMA scope moves to 46 (Account Tax Budget, CW-048); the 24 part keeps Budget Portfolio and Tax Year as key and the "
    "Realized Gain Tie-Out runs on Budget Portfolio only. keys_e7_22_24 line 253: new key Budget Portfolio / Tax Year; line 510 "
    "removed. models_e8c line 479 and 514: grain and relationship re-keyed to the 18 portfolio. Lineage pass at WP1/WP2.",
    "New readers expected: 45 Planning Assumption Set.Capital Market Assumption Set (content_45 line 212, typed Reference (Capital "
    "Market Assumption Set, 24); example 'Long-term assumption set 2026 Q3' should become 'CMASET-2026-001 / 2' at the 45 fix "
    "pass). The 45 review finding on inflation: General Inflation Rate in 45 becomes a Derived copy of 24 Inflation Assumption or a "
    "flagged plan override. 46 Model Assignment and 45 Recommendation may reference Model Lineup Position (key MLNUP- / version / "
    "MDL-, GRAIN_KEY_FORMATS in proposals_w3_oversight.py).",
    "37 at merge: register the MODEL- entries used as examples (MODEL-0441 decision algorithm, MODEL-0427 capital-market model) or "
    "treat them as illustrative; the 37 Model Type list (content_37 line 496) needs values such as 'Capital Market Assumptions' and "
    "'Portfolio Construction Algorithm' for them (request to the 37 owner). 52 at W3: Product List Status values (Approved, Watch, Restricted for New Recommendations, Removed "
    "per the 52 brief) are read on Model Building Block; the example 'Approved' assumes that label.",
    "W4 (30 retirement, CW-930, CW-166): applied in the fix pass, all 22 CARRIED_INTO_MERGE items of proposals_w4_retire.py for 24 "
    "(REPOINTS above, with readers). Insurance-dedicated residue (out of CW-004 scope, not jurisdiction): Constraint "
    "Type 'Diversification Buffer (IRC 817(h))', the Buffered Investment Restriction note and the Treas. Reg. 1.817-5 source; "
    "05 Model Program Placement REL row (05 replaced at W4).",
    "PLANNED READERS (requests to the 45 and 46 owners at their fix passes): Reference (Model Lineup Position, 24), key MLNUP- / version "
    "/ MDL-, on 45 Recommendation (beside Recommended Model Portfolio, content_45 line 325) and on 46 Model Assignment (beside the 01 "
    "MDL-). The two REL rows say 'Proposed'. 12 (W4 owner): Investment Policy Statement.Policy Allocation example should follow the "
    "policy key '<MND-> v<version>' (Policy Mandate, CW-128). 45: General Inflation Rate (content_45 line 222) becomes a Derived copy "
    "of Inflation Assumption or a flagged plan override.",
    "Fix pass (24_32 review), Lows: applied Committee Business Lines 'PF; DA; HA; WR; IA'; Decision Authority Indicator reference "
    "order and the 25 note on the order memorandum; Rule 3a-4 source re-worded and made secondary on Model Lineup Purpose; FINRA "
    "2210 marked 'rule moving, SR-FINRA-2026-004 pending, confirm' (Notes, source, Source_Notes); DOL TDF tips URL added; Product "
    "List Status row rule to Product Use Scope 'Advice Models' on Building Block Effective From; Correlation CMA Set kept as a key "
    "part with the equality rule; sub-class examples aligned (US Large Cap Equity, Developed ex-US Equity); MODEL-0441; 37 Model "
    "Type request; vehicle keys: the 17-to-01 join stated on Building Block Share Class (Target Allocation Line keeps INS-, so "
    "both keys stay); Source_Notes stale wholesale text struck. Skipped: none. The Inflation Low needs no 24 change (45 fix pass).",
    "Brief deviations: (1) proposals file named proposals_w3_24.py as assigned (the brief says proposals_24.py). (2) Asset Allocation "
    "Policy Purpose adds 'Multi-Asset Fund' to the brief's four values, for balanced-fund SAAs (PF). (3) Model Lineup holds Lineup "
    "CMA Set only when it has no governing policy (row rule), so the set is held once. (4) Asset Class Correlation Assumption relates "
    "two Asset Class Return Assumption lines instead of repeating asset class and sub-class codes. (5) Model Building Block gained a slot and "
    "an alternate pairing in the fix pass (review D Medium). (6) Not added from the draft: CMA set name, default "
    "position flag, client projection use flag (lineup name added back in the fix pass, band widened to 295 by ruling). (7) Equity share is a design label (Nominal Equity Share); the weight is 24 Target "
    "Allocation Line only.",
    "Grep of the module after the pass: no MiFID, MiFIR, RTS 22, UCITS, ESMA, PRIIP, GIPS-for-retail, GDPR, FCA, 'UK ' or 'EU '. "
    "'SMA' remains only in the Money Management Institute source title. 'Position' appears in Model Lineup Position (brief's exact "
    "name) and portfolio action values; 'Holding' only in 'Portfolio Holding (18, HLD-)' and 'Holdings As-Of Timestamp'.",
]
