"""Consolidation proposals from the W3 draft of Data Domain 29 Transfer Agency Operations (wealth manager), 2026-10-15.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py,
shared_code_lists.py and jurisdiction.REMOVALS at the W3 merge. Formats follow CONTRACT.md in this folder. The brief is
00_Program/Rework/Briefs/29_Transfer_Agency_Operations.md (Disposition: Adapt, CW-006; L1 code TA kept). It implements CW-003,
CW-022, CW-025, CW-039, CW-088 (proposals_w2_engagement.py), CW-097 and CW-107 (proposals_w3_brokerage.py) and CW-121 to CW-124
and CW-130 (proposals_w3_oversight.py), and completes CW-929, the US-only pass of 29, drafted at brief level in
proposals_w3_oversight.py. The brief names this file proposals_29.py; that name holds the Stage 2 expansion proposals of 29
(kept unchanged), so the W3 entries are here. Module: content_29_transfer_agency_operations.py (adapted in place; output path
and folder unchanged).
"""

_D, _C = "29", "CW-929"

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES (decisions.PREFIXES tuple format). None beyond the reservations of proposals_w3_oversight.py: RGTX- (Reserved,
#    owner 29, CW-130), the transfer of BOD- from 13 (TRANSFER_PREFIXES) and the retirement of CIP- (RETIRE_PREFIXES).
#    Share Register Balance uses the composite key of GRAIN_KEY_FORMATS there: <ACC- id> / <SHC- id> / <business date>.
#    Register Transaction examples follow PREFIX_FORMATS there: RGTX-<year>-<sequence, 10 digits> (RGTX-2026-0004188273).
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED MEMBERSHIPS: 29 local lists that carry a shared list's exact name (or are registered members under a local
#    name). value_map maps each local label to the shared code; new_values are codes the shared list does not hold yet.
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Fund Dealing Settlement Method", "local": "Order Settlement Method",
     "value_map": {"NSCC Net Settlement": "NSCC_NET_SETTLEMENT",
                   "Affiliated Broker-Dealer Omnibus Settlement": "AFFILIATED_BD_OMNIBUS",
                   "Bank Transfer / Wire": "BANK_TRANSFER_WIRE", "Direct Investor Payment": "DIRECT_INVESTOR_PAYMENT"},
     "new_values": ["AFFILIATED_BD_OMNIBUS"],
     "note": "Kept membership (29 is steward), re-cut per CW-039 and CW-929. Remove CALASTONE_SETTLEMENT and "
             "ICSD_CLEARSTREAM_EUROCLEAR (JURISDICTION below); add ('AFFILIATED_BD_OMNIBUS', 'Affiliated Broker-Dealer Omnibus "
             "Settlement', 'Internal settlement with the firm's broker-dealer for its omnibus orders (CW-097)'). Re-describe "
             "DIRECT_INVESTOR_PAYMENT: 'Gross settlement with a fund-only shareholder through a 50 money movement (CW-107)'. Member "
             "05 'Settlement Method' maps Calastone Settlement and ICSD (Clearstream / Euroclear) to None until the W4 05 "
             "replacement, which drops the membership (proposals_w4_channels CW-164 resolution). Until the merge the builder shows "
             "the current shared values (with the two EU codes) in the 29 workbook, because the local list is a member."},
    {"shared": "Dealing Route", "local": "Dealing Route",
     "value_map": {"NSCC Fund/SERV": "NSCC_FUNDSERV", "NSCC DCC&S": "NSCC_DCCS", "NSCC CNS / ETF Portal": "NSCC_CNS_ETF",
                   "Affiliated Broker-Dealer Omnibus": "OWN_BD_OMNIBUS", "TA Direct": "TA_DIRECT",
                   "Recordkeeper File": "RECORDKEEPER_FILE", "Sponsor File": "SPONSOR_FILE"},
     "new_values": ["OWN_BD_OMNIBUS"],
     "note": "29 was a direct user (CD-210). The direct citation 'Shared: Dealing Route' is replaced by a local copy with the US "
             "values until the W4 06 re-cut (CW-039): register 29 as a member with this map, or, once the shared list holds only "
             "these values, return 29 to direct use. OWN_BD_OMNIBUS is the code proposals_w4_channels.py (CW-164) proposes; the 29 "
             "label 'Affiliated Broker-Dealer Omnibus' is ruled the shared label (06 adopts it at its fix pass). Removed from the local copy: CALASTONE, CLEARSTREAM_VESTIMA, "
             "EUROCLEAR_FUNDSETTLE, ALLFUNDS and SWIFT_DIRECT (JURISDICTION below). SWIFT_DIRECT: the 29 brief and CW-929 remove it "
             "from 29; ruled (29 review): SWIFT_DIRECT leaves the shared Dealing Route at the merge and 06 drops 'SWIFT ISO 20022 "
             "Direct' from Order Entry Channel too (ISO 20022 stays a market-neutral message standard in Message Standard). Local "
             "descriptions of TA Direct and Sponsor File are the shared ones, copied unchanged."},
    {"shared": "Networking Level", "local": "", "value_map": {}, "new_values": [],
     "note": "Direct use kept (steward 15; the 29 review calls it Networking Matrix Level). Note for the 15 steward at the merge "
             "(program-lead ruling): drop LEVEL_1 (DTCC's matrix lists levels 0, 3 and 4) and confirm the Level 0 wording against the "
             "current DTCC Networking matrix (non-networked for most firms; networked trust accounts excepted). 29 uses Level 3 in "
             "its example only."},
    {"shared": "Regulatory Report Status", "local": "", "value_map": {}, "new_values": [],
     "note": "Not a member and not a direct user: 29 files no regulatory report (Form TA-2 and the transfer agent filings are "
             "the 38 firm regulatory filings; SAR filing status is 38). Listed because the assignment named the list; no action."},
    # Kept direct uses (no local copies; values copied unchanged and checked US-only): Message Standard (steward 06),
    # Networking Level (15), Flow Direction, Data Basis, Case Status, Severity, Screening Result, Information Classification,
    # Reconciliation Status, Cost Bearer (13).
]

# Transfers with the CW-088 objects: the 13 local lists Holding Model (renamed Beneficial Owner Holding Model on receipt), NOBO Permitted Use, Servicing Provider Role and
# Oversight Rating move with their objects (13 keeps none of them after the W3 merge: Holding Model, NOBO Permitted Use and
# Oversight Rating have no other 13 user; Servicing Provider Role has none either once Servicing Provider Engagement leaves).

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED CANDIDATES: local lists that look like enterprise lists
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("NAV Dissemination Channel", ["29", "27"],
     "27 dropped its copy (27 NAV Dissemination now cites the 29 transmissions); 29 is the only holder. Keep local, or make shared "
     "with steward 29 if 01 Valuation Terms.NAV Publication Channel adopts it (DP-168 compares the two)."),
    ("Monitoring Alert Disposition", ["29", "50"],
     "50 Alert Disposition (money movement alerts, MMALT-) has the same meaning (proposals_w3_brokerage NOTES). Candidate shared "
     "list at W5, steward 38 (AML program)."),
    ("Monitoring Scenario", ["29", "50", "38"],
     "Dealing typologies (29) and payment typologies (50) together form the AML scenario catalog of 38. Candidate shared list at W5, "
     "steward 38, with a scope attribute (dealing, payment)."),
    ("Register Transaction Type", ["29", "06", "16", "49"],
     "06 Transaction Type (W4 flow fact) reads it for TA rows; 49 Client Account Activity Type and 16 Participant Ledger Posting Type "
     "overlap on purchase, redemption, exchange, reinvestment. Keep apart; publish a value map to 06 at W4."),
    ("Register Account Category", ["29", "06", "15"],
     "06 Fund Shareholder Position row rule (CD-289) selects its source book by this category; 15 Account Type is the account-level "
     "master. Map: Fund-Only Account -> Fund-Only; Omnibus Account at Transfer Agent -> Broker-Dealer Omnibus or Intermediary "
     "Omnibus; Networked Investor Account -> Networked; Plan Account -> Plan Omnibus; Institutional Separate Account -> Institutional "
     "Direct; Firm Proprietary Account -> Firm Proprietary. DTC Nominee and CIT Unitholder have no 15 Account Type value yet "
     "(note for the 15 owner)."),
    ("Order Payment Method", ["29", "19", "50"],
     "Kept from proposals_29.py with the EU/UK rails removed (Fedwire, ACH, Check, NSCC Settlement Payment, Internal Book Transfer); "
     "50 Payment Rail is the client-payment list. Candidate shared 'Payment Rail', steward 50."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (decisions.TERM_CONFLICTS format), from the plan section 5.3 watchlist and the brief section 13
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Order (wealth model)",
     "usages": [("29", "Fund Order (FNDO-)", "Dealing instruction in a share class as received and processed by the transfer agent."),
                ("48", "Client Order (CLORD-)", "A brokerage client's order, including fund orders in brokerage accounts."),
                ("25", "Portfolio Order", "A fund or institutional portfolio's order to the market."),
                ("29", "AP Creation / Redemption Order (ECR-)", "An authorized participant's ETF primary-market order.")],
     "recommendation": "Never bare: 'Fund Order' (29), 'Client Order' (48), 'Portfolio Order' / trade order (25), 'AP order' (29). "
                       "Own-fund client orders aggregate into one Fund Order per share class and dealing cycle (CW-097).",
     "resolution": "Distinct concepts linked by 48 Order Route.Resulting Fund Order.", "status": "Resolved", "decision": "CW-097"},
    {"term": "Transfer (wealth model)",
     "usages": [("29", "Fund Share Transfer (Fund Order Type Transfer Out / In; Register Transaction Type Fund Share Transfer In / Out)",
                 "Shares moved between registered accounts at the TA without a sale."),
                ("49", "Account Transfer (ACXF-)", "ACATS and non-ACATS transfers of a brokerage account's assets."),
                ("50", "Cash Transfer", "Money moved between accounts."),
                ("16", "Participant Investment Transfer (PEXC-)", "Exchange between plan options.")],
     "recommendation": "Qualify every use; 29 says 'Fund Share Transfer'.", "resolution": "No unqualified primary sense.",
     "status": "SME", "decision": "CW-122"},
    {"term": "Account (wealth model)",
     "usages": [("15", "Account (ACC-)", "Every client account, including fund-only, omnibus at the transfer agent and networked accounts."),
                ("29", "TA-Registered Account (Register Account / Posting Account, Register Account Category)",
                 "A 15 account registered at the transfer agent, seen from the register.")],
     "recommendation": "29 references 15 ACC- for every registered account; Register Account Category is the register view, not a "
                       "second account master.",
     "resolution": "15 masters the account (CW-035).", "status": "Resolved", "decision": "CW-006"},
    {"term": "Transaction (wealth model)",
     "usages": [("29", "Register Transaction (RGTX-)", "Posted share movement on the TA register."),
                ("06", "Transaction (TXN-)", "Firm-wide flow fact (W4)."),
                ("18", "Portfolio Transaction", "IBOR booking."),
                ("49", "Client Account Activity (CLACT-)", "Brokerage activity."),
                ("16", "Participant Ledger Posting (PLPST-)", "Recordkeeping posting.")],
     "recommendation": "Qualify every use. 29 Fund Order.Resulting Transaction and AP Resulting Transaction keep their names and "
                       "reference Register Transaction (CW-122).",
     "resolution": "As proposals_w3_oversight.TERM_CONFLICTS.", "status": "SME", "decision": "CW-122"},
    {"term": "Balance (wealth model)",
     "usages": [("29", "Share Register Balance", "Shares registered at the transfer agent per account, share class and date."),
                ("49", "Client Holding (CLHLD-)", "Brokerage book of record."),
                ("16", "Participant Balance", "Recordkept participant balance.")],
     "recommendation": "Share Register Balance is never called Holding or Position; it carries no value (06 values the view).",
     "resolution": "As proposals_w3_oversight.TERM_CONFLICTS.", "status": "SME", "decision": "CW-125"},
    {"term": "Alert (wealth model)",
     "usages": [("29", "Account Monitoring Alert (AMA-)", "Dealing-triggered AML, sanctions and fraud alert on a shareholder account."),
                ("50", "Money Movement Monitoring Alert (MMALT-)", "Alert on a client payment."),
                ("08", "Sales Practice Alert (SPA-); Surveillance Alert (SURV-)", "Conduct and communications surveillance alerts."),
                ("38", "Trade Surveillance Alert", "Market abuse surveillance.")],
     "recommendation": "Never bare 'alert': qualify by what is monitored (account dealing 29, money movement 50, sales practice 08, trade 38).",
     "resolution": "Split by trigger (CW-123).", "status": "SME", "decision": "CW-123"},
    {"term": "Settlement Obligation",
     "usages": [("29", "Settlement Obligation", "Fund-side cash due for a fund order or the cash leg of an AP order."),
                ("49", "Street Settlement Obligation", "Broker-dealer obligation with a clearing entity, including the 29 own-fund omnibus channel.")],
     "recommendation": "29 keeps 'Settlement Obligation'; 49 always says 'Street Settlement Obligation'; 49 holds the link "
                       "(Own-Fund Settlement Obligation).",
     "resolution": "Distinct records, linked from 49.", "status": "Resolved", "decision": "CW-122"},
    {"term": "Cash Movement / Money Movement",
     "usages": [("29", "Cash Movement", "Fund-side settlement entry against a 28 safekeeping cash account."),
                ("50", "Money Movement (MMVMT-)", "Every payment to, from or between client accounts.")],
     "recommendation": "A fund-only shareholder's payment is one 50 Money Movement and one 29 Cash Movement that references it.",
     "resolution": "CW-107.", "status": "Resolved", "decision": "CW-107"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION (jurisdiction.REMOVALS entry format; CW-022). A whole removed object or code list has attribute "".
#    Regimes follow the brief section 4a table. Insurance-dedicated values (Order Origin 'Insurance Company Instruction',
#    NAV Dissemination Channel 'Insurer Feed', Interface Cycle 'insurance company file') were removed as out of scope (CW-004),
#    not jurisdiction, and are listed in NOTES. CIP Verification and its five lists left under CW-124 (not jurisdiction); their
#    EU/UK values and references are recorded here so that the register says why they are not restored with a US extension.
# ---------------------------------------------------------------------------------------------------------------------


def _j(obj, attr, regime, note):
    return {"domain": _D, "object": obj, "attribute": attr, "regime": regime, "decision": _C, "note": note}


JURISDICTION = [
    # Attributes
    _j("Order Routing Detail", "Platform Order Reference", "EU market practice",
       "Order or message reference of Calastone, Clearstream Vestima, Euroclear FundSettle, Allfunds or SWIFT. The US routes are "
       "covered by Intermediary Order Reference and Fund/SERV Control Number."),
    # Code values: Dealing Route (local copy of the shared list, steward 06)
    _j("Code list: Dealing Route", "Calastone", "EU market practice", "EU/UK order routing network; CW-039 re-cut, W4 06 shared list."),
    _j("Code list: Dealing Route", "Clearstream Vestima", "EU market practice", "ICSD fund order routing."),
    _j("Code list: Dealing Route", "Euroclear FundSettle", "EU market practice", "ICSD fund order routing."),
    _j("Code list: Dealing Route", "Allfunds", "EU market practice", "EU fund platform."),
    _j("Code list: Dealing Route", "SWIFT Direct (ISO 20022)", "EU market practice",
       "Direct SWIFT setr messaging to the TA, the EU platform model (29 brief, CW-929). proposals_w4_channels keeps SWIFT_DIRECT in "
       "the shared list; ruled at the 29 review: removed from the shared list too, and from 06 Order Entry Channel. ISO 20022 stays in Message Standard."),
    # Code values: Order Settlement Method (local) and the shared Fund Dealing Settlement Method (steward 29)
    _j("Code list: Order Settlement Method", "Calastone Settlement", "EU market practice",
       "Replaced in the US set by Affiliated Broker-Dealer Omnibus Settlement (CW-097)."),
    _j("Code list: Order Settlement Method", "ICSD (Clearstream / Euroclear)", "EU market practice", "Vestima and FundSettle settlement."),
    _j("Code list: Fund Dealing Settlement Method", "CALASTONE_SETTLEMENT", "EU market practice",
       "Shared list, steward 29; member 05 maps the value to None until W4."),
    _j("Code list: Fund Dealing Settlement Method", "ICSD_CLEARSTREAM_EUROCLEAR", "EU market practice",
       "Shared list, steward 29; member 05 maps the value to None until W4."),
    # Code values: Order Payment Method
    _j("Code list: Order Payment Method", "CHAPS", "UK market practice", "UK high-value payment system (UK market practice). Fedwire stays."),
    _j("Code list: Order Payment Method", "SEPA Credit Transfer", "Other EU/UK", "EU payment scheme (EU market practice). ACH and Fedwire stay."),
    _j("Code list: Order Payment Method", "TARGET2", "Other EU/UK", "Eurosystem RTGS (EU market practice). Fedwire stays."),
    _j("Code list: Order Payment Method", "Bacs Direct Debit", "UK market practice", "UK direct debit (UK market practice). ACH stays; client direct debits are 50."),
    # Code values of the CIP lists that left with CIP Verification (CW-124); the US values are in 02
    _j("Code list: Identity Verification Regime", "UK CDD (MLR 2017 / JMLSG)", "Other EU/UK",
       "UK Money Laundering Regulations 2017. The list left 29 with CIP Verification (CW-124); 02 CIP Program holds the US programs."),
    _j("Code list: Identity Verification Regime", "EU CDD (AMLD)", "Other EU/UK", "EU anti-money laundering directives."),
    _j("Code list: CIP Verification Method", "Electronic Identity Verification", "Other EU/UK",
       "UK / EU electronic verification against multiple sources (JMLSG). 02 Identity Verification holds the US methods."),
    _j("Code list: CIP Identity Element", "National Insurance Number", "Other EU/UK", "UK identifier."),
    _j("Code list: CIP Exemption or Exclusion Reason", "Simplified Due Diligence Applied", "Other EU/UK", "UK MLR 2017 regulation 37."),
    # Secondary references and list sources
    _j("Fund Order", "Cut-Off Result", "FCA", "Secondary reference UK FCA COLL removed; primary SEC Rule 22c-1 stays."),
    _j("Code list: Cut-Off Result", "UK FCA COLL 6.3 valuation point (list source)", "FCA", "List source re-sourced to SEC Rule 22c-1 only."),
    _j("Order Routing Detail", "Dealing Route", "EU market practice", "Secondary reference Calastone removed; DTCC Fund/SERV stays."),
    _j("Settlement Obligation", "Order Settlement Method", "EU market practice", "Secondary reference Calastone removed; DTCC Fund/SERV stays."),
    _j("Intermediary Settlement Batch", "Net Settlement Amount", "EU market practice", "Secondary reference Calastone removed; DTCC Fund/SERV stays."),
    _j("Account Monitoring Alert", "Monitoring Scenario", "Other EU/UK", "Secondary reference JMLSG removed; FinCEN (31 CFR Part 1024) stays."),
    _j("Code list: Monitoring Alert Category", "JMLSG (list source)", "Other EU/UK", "List source re-sourced to FinCEN SAR categories and FINRA Rule 3310."),
    _j("Account Monitoring Alert", "Matched Sanctions List", "Other EU/UK", "Secondary reference UK OFSI removed; OFAC stays."),
    _j("CIP Verification", "Identity Verification Regime", "Other EU/UK", "Secondary reference UK MLR 2017; the object left under CW-124."),
    _j("CIP Verification", "CIP Verification Method", "Other EU/UK", "Secondary reference JMLSG; the object left under CW-124."),
    _j("CIP Verification", "CIP Exemption Reason", "Other EU/UK", "Secondary reference UK MLR 2017; the object left under CW-124."),
    _j("Code list: Processing Calendar Event Type", "Dealing Suspension (note 'e.g. UK COLL 7.2')", "FCA",
       "Value kept and re-sourced to Investment Company Act Section 22(e); the UK reference in its description removed."),
    _j("Code list: Interface Cycle", "Real-Time Messaging (note 'SWIFT, Calastone')", "EU market practice",
       "Value kept; description now 'ISO 20022 or API'."),
    _j("Exchange Link", "Switch Order Reference (example 'setr.013-ALLF-...')", "EU market practice",
       "Allfunds platform code removed from the example; attribute kept (ISO 20022 switch orders)."),
    # Sources
    _j("Sources", "Calastone order routing and settlement (public service description)", "EU market practice",
       "Cited by Dealing Route, Platform Order Reference and Order Settlement Method."),
    _j("Sources", "Clearstream Vestima, Euroclear FundSettle and Allfunds (public service descriptions)", "EU market practice",
       "Cited by Dealing Route and Order Settlement Method."),
    _j("Sources", "UK FCA Handbook COLL 6.2 and 6.3 (dealing, valuation and pricing) and COLL 7.2 (suspension)", "FCA",
       "Cut-Off Result re-sourced to SEC Rule 22c-1; Dealing Suspension to Investment Company Act Section 22(e) (source added)."),
    _j("Sources", "UK Money Laundering Regulations 2017 and JMLSG Guidance", "Other EU/UK",
       "Cited by the CIP lists (left with CIP Verification, CW-124) and Monitoring Scenario (re-sourced to FinCEN)."),
    _j("Sources", "UK OFSI consolidated list (part of the source 'OFAC sanctions programs ...; UK OFSI consolidated list')", "Other EU/UK",
       "The combined source is kept as OFAC only."),
    # Perspective (not removals of content; recorded for the register so that a UK extension knows to restore them)
    _j("META", "Overview (Purpose, Scope, Notes, Suggested next steps)", "GDPR / UK GDPR",
       "'UK customer due diligence' (Purpose, Scope), 'GDPR / UK GDPR' (Notes) and next step 7 (EU/UK routes, UK TA for OEICs) "
       "removed; personal data defined under GLBA, Regulation S-P and state law. Subtitle 'Asset manager (wholesale distributor) | "
       "Scope: US + EU/UK' rewritten to 'Wealth manager (direct) | Scope: US'."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. REPOINTS (object, attribute, before, after, decision): re-types, renames and re-pointed references of the adaptation
#    that are not EU/UK removals. Readers of each are listed in NOTES.
# ---------------------------------------------------------------------------------------------------------------------
REPOINTS = [
    ("CIP Verification", "", "29 business object (CIP-), 13 attributes, 5 lists", "removed; 02 Identity Verification (KYCV-, CIP Program 'Mutual Fund CIP') referenced from 15 Account Opening; CIP- Retired", "CW-124"),
    ("Fund Order", "Resulting Transaction", "Reference (Transaction) to 06 TXN-", "Reference (Register Transaction, 29), RGTX-", "CW-122"),
    ("AP Creation / Redemption Order", "AP Resulting Transaction", "Reference (Transaction) to 06 TXN-", "Reference (Register Transaction, 29), RGTX-", "CW-122"),
    ("Settlement Obligation", "Obligation Amount", "Derived copy of 06 Transaction Amounts / Net Amount (fund-order rows)", "Mastered here: the Register Transaction Net Amount (29); DERIVED and ROW_OWNERSHIP entries removed", "CW-122"),
    ("Cash Movement", "Investor Bank Instruction", "Reference (Bank Instruction) to 15 ABI-", "removed; replaced by Client Money Movement (Reference (Money Movement, 50), MMVMT-); the bank instruction is read by 50", "CW-107"),
    ("Cash Movement", "Payment Reference / Payment Method", "held for every payment, including direct investors", "fund-side payments only; blank for rows that settle a 50 money movement", "CW-107"),
    ("Account Monitoring Alert", "Triggering Money Movement", "", "added, Reference (Money Movement, 50)", "CW-123"),
    ("Fund Order", "Brokerage Omnibus Order Detail", "", "added attribute group (7 attributes; 4 Derived copies of 48)", "CW-097"),
    ("Fund Order", "Order Account (definition)", "investor, networked, omnibus, plan or insurance separate account", "15 account registered at the TA (fund-only, broker-dealer omnibus, intermediary omnibus or networked, plan omnibus, institutional)", "CW-035"),
    ("Code list: Order Origin", "Insurance Company Instruction", "Insurance Company Instruction", "removed (out of scope, CW-004); Affiliated Broker-Dealer Omnibus and Cash Sweep Run added", "CW-097"),
    ("Code list: NAV Dissemination Channel", "Insurer Feed", "Insurer Feed", "removed (out of scope, CW-004); Broker-Dealer Pricing Feed added", "CW-004"),
    ("Code list: Fund Order Status", "Confirmed", "06 transaction created", "Register Transaction posted", "CW-122"),
    ("Code list: As-Of Reason", "Broker-Dealer Aggregation Error", "", "added", "CW-097"),
    ("Code list: Monitoring Alert Category", "Fraud - Check or ACH Fraud", "Fraud - Check or ACH Fraud", "removed: payment fraud alerts are 50 money movement monitoring alerts (MMALT-)", "CW-123"),
    ("Code list: Monitoring Scenario", "Third-Party Payment; High-Risk Jurisdiction Payment; Cash-Equivalent Purchase", "payment typologies", "removed: payment scenarios are 50 (CW-110, CW-123)", "CW-123"),
    ("Code list: Servicing Provider Role", "Sub-Transfer Agent", "", "added (TA service providers, CW-124)", "CW-124"),
    ("Code list: Dealing Route", "", "Shared: Dealing Route (direct use)", "local copy 'Dealing Route' with the US values and Affiliated Broker-Dealer Omnibus (OWN_BD_OMNIBUS)", "CW-039"),
    ("Servicing Provider Engagement", "", "13 SV-TAO (transitional)", "29 TA-OVS (TA Controls & Oversight); names, attributes and lists unchanged; adds Engagement Start Date, Engagement End Date, Oversight Review Period End Date, Latest SOC 1 Report Date, Provider Service Levels (13 SVL-)", "CW-088"),
    ("Intermediary Distribution Request", "", "13 SV-BOC (transitional), BOD-", "29 TA-REG (Shareholder Register), BOD- transferred", "CW-088"),
    ("Intermediary Distribution Request", "Beneficial Owner Position Count", "Beneficial Owner Position Count", "Beneficial Owner Account Count (renamed on receipt: W0 term ruling keeps Position for 06 Fund Shareholder Position only; 13 fix pass)", "CW-007"),
    ("Intermediary Distribution Request", "Holding Model", "Holding Model (attribute and list)", "Beneficial Owner Holding Model (attribute and list, renamed on receipt; 13 fix pass)", "CW-007"),
    ("NOBO List Request", "", "13 SV-BOC (transitional)", "29 TA-REG, attribute group of Intermediary Distribution Request", "CW-088"),
    ("Family", "Investor Identity & Financial Crime", "Investor Identity & Financial Crime (TA-FCC)", "Shareholder Account Monitoring (TA-FCC kept)", "CW-124"),
    ("Family", "TA Controls", "TA Controls (TA-OVS)", "TA Controls & Oversight (TA-OVS kept)", "CW-088"),
    ("Family", "Shareholder Register", "", "added (TA-REG): Share Register Balance, Register Transaction, and the two CW-088 objects", "CW-122"),
    # Fix pass (29_review.md, program-lead rulings 2026-10-15)
    ("Order Routing Detail", "Resolved Dealer / Resolved Representative", "Derived copy of 06 Intermediary As Delivered", "Mastered in 29 from the Fund/SERV and Networking feed fields; 06 copies them", "CW-144"),
    ("Brokerage Omnibus Order Detail", "Aggregated Client Order Count / Purchase Amount / Redemption Amount / Redemption Units", "Derived copy of 48", "Row rule by Order Origin: 48 for Affiliated Broker-Dealer Omnibus rows, 50 Sweep Run allocations for Cash Sweep Run rows", "CW-108"),
    ("Share Register Balance", "Uncollected Shares", "primary reference Investment Company Act Section 22(e)", "Internal (prospectus and fund policy); 22(e) cited for the seven-day rule and its exceptions only; CDE", "CW-929"),
    ("Register Transaction", "As-Of Posting Indicator", "", "added (06 reads the posting's as-of)", "CW-122"),
    ("Code list: Register Transaction Type", "Escheatment Delivery; Reorganization Out; Reorganization In; Register Adjustment", "", "added; Fund/SERV code mapping to confirm; Originating row rule relaxed to 'at most one'", "CW-122"),
    ("Code list: Register Transaction Status", "Pending Settlement", "Pending Settlement; Posted ('posted and settled')", "Pending Posting; Posted (posting state only; settlement state on the Settlement Obligation)", "CW-122"),
    ("Code list: Register Account Category", "Institutional Direct", "mapped from 15 Institutional Separate Account", "mapped from 15 Direct Institutional Fund Account (new 15 type); DTC Nominee and CIT Unitholder map to new 15 types", "CW-035"),
    ("Account Monitoring Alert / Alert Disposition", "", "PII - financial (restricted)", "plus PII - special category (CD-344), restricted view, on elder exploitation and Rule 2165 hold rows", "CW-109"),
    ("NOBO List Request", "", "PII - identity", "No PII (the returned list is held by the requesting function)", "CW-088"),
    ("Servicing Provider Engagement", "", "grain servicing provider x servicing role", "grain servicing provider x servicing role x engagement start date", "CW-088"),
    ("Price & Rate Transmission", "Price Transmission Key / Transmitted Dissemination (examples)", "NAV-... / NSCC Mutual Fund Profile", "NAV-... / <release sequence> as the 27 NAV Dissemination key", "CW-001"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. DECISIONS: the US-only pass of 29 (pre-allocated CW-929; brief-level draft in proposals_w3_oversight.py, completed here)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-929", "theme": "Scope", "title": "US-only pass of 29 Transfer Agency Operations",
     "domains": ["29", "06", "05", "02", "13"],
     "issue": "The wholesale 29 served intermediaries and EU platforms: it carried EU order routing and settlement platforms "
              "(Calastone, Clearstream Vestima, Euroclear FundSettle, Allfunds, SWIFT direct), EU/UK payment rails, UK and EU "
              "customer due diligence values, FCA COLL, JMLSG and UK OFSI references and sources, GDPR notes and the 'Asset manager "
              "(wholesale distributor) | Scope: US + EU/UK' perspective.",
     "resolution": "Removed (39 JURISDICTION entries: 1 attribute, 18 code values, 14 references and list notes, 5 sources, 1 "
                   "perspective entry). Attribute: Order Routing Detail.Platform Order Reference. Values: Dealing Route Calastone, "
                   "Clearstream Vestima, Euroclear FundSettle, Allfunds and SWIFT Direct (local copy replaces the direct use of the "
                   "shared list until the W4 06 re-cut); Order Settlement Method and shared Fund Dealing Settlement Method Calastone "
                   "and ICSD (AFFILIATED_BD_OMNIBUS added); Order Payment Method CHAPS, SEPA Credit Transfer, TARGET2, Bacs Direct "
                   "Debit; the UK and EU values of the CIP lists (Identity Verification Regime UK CDD and EU CDD, CIP Verification "
                   "Method Electronic Identity Verification, CIP Identity Element National Insurance Number, CIP Exemption Simplified "
                   "Due Diligence Applied), which left with CIP Verification under CW-124. References: UK FCA COLL on Cut-Off Result; "
                   "Calastone on Dealing Route, Order Settlement Method and Net Settlement Amount; JMLSG on Monitoring Scenario and the "
                   "Monitoring Alert Category source; UK OFSI on Matched Sanctions List; UK MLR 2017 and JMLSG on three CIP "
                   "attributes; the UK COLL 7.2 note on Dealing Suspension; the SWIFT / Calastone note on Interface Cycle; the "
                   "Allfunds code in the Switch Order Reference example. Sources: Calastone; Clearstream Vestima, Euroclear "
                   "FundSettle and Allfunds; FCA COLL 6.2, 6.3, 7.2; UK MLR 2017 and JMLSG; the UK OFSI part of the OFAC source. "
                   "Kept and re-sourced: Cut-Off Result to SEC Rule 22c-1 only; Dealing Suspension to Investment Company "
                   "Act Section 22(e) (source added; seven-day rule and its exceptions only); Uncollected Shares to the prospectus and fund policy; Monitoring Scenario and Monitoring Alert Category to FinCEN "
                   "(31 CFR Part 1024) and FINRA Rule 3310; Matched Sanctions List to OFAC; Payment Method to the US rails (Fedwire, "
                   "ACH, check, NSCC settlement, book transfer). Foreign securities in fund baskets and portfolios, foreign currencies "
                   "and non-US intermediaries investing through US channels stay. Perspective: subtitle 'Wealth manager (direct) | "
                   "Scope: US'; overview rewritten for the in-house TA of a direct wealth manager; personal data under GLBA, "
                   "Regulation S-P and state law. Out of scope, not jurisdiction (CW-004): Order Origin Insurance Company Instruction, "
                   "NAV Dissemination Channel Insurer Feed and the insurance company file note on Interface Cycle. Adaptation applied "
                   "with the pass (CW-097, CW-107, CW-122 to CW-124, CW-088): CIP Verification removed and CIP- retired; Shareholder "
                   "Register family added (Share Register Balance, Register Transaction RGTX-); Brokerage Omnibus Order Detail added; "
                   "Cash Movement references 50 Money Movement instead of the investor bank instruction; Triggering Money Movement "
                   "added; Resulting Transaction and AP Resulting Transaction re-typed to Register Transaction; Servicing Provider "
                   "Engagement, Intermediary Distribution Request (BOD-) and NOBO List Request received from 13. Counts (built, after the "
                   "review fix pass): 6 to 7 families, 22 to 27 objects, 230 to 279 attributes, 78 to 95 CDEs (34%), 39 to 41 code lists in the workbook "
                   "(27 to 31 local), 42 to 60 relationships, 21 to 23 sources.",
     "rationale": "CW-003 and CW-022: the firm is regulated, distributes and services clients in the US only, so EU fund "
                  "platforms, EU/UK payment rails and UK customer due diligence have nothing to serve, while every generic object "
                  "(order routing, settlement, monitoring, controls) stays with US sources. Lever: a UK extension restores the "
                  "removed rows from wholesale-v1.0 through the jurisdiction register.",
     "action": "W3", "status": "Proposed", "priority": "Low", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 8. NOTES for the W3 merge
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    # Readers of removed, moved or re-typed content. Lines as of 2026-10-15.
    "READERS OF REMOVED, MOVED OR RE-TYPED 29 CONTENT. Data products: "
    "DP-177 specs_e3_ta_fund_governance.py 42, 45, 64, 78, 94, 105 (Dealing Route and Session Dealing Route: values re-cut, Affiliated "
    "Broker-Dealer Omnibus added), 84-85 and 92 (Fund Order.Resulting Transaction: re-typed to Register Transaction; the 'hand-off gap to "
    "DP-006' metric becomes the gap to the 29 posting), 88 (Order Account: definition re-cut); "
    "DP-178 specs_e3_ta_fund_governance.py 179-180, 200, 226, 263 (Obligation Amount: no longer a Derived copy of 06; the note at 263 is "
    "stale), 185 (Order Settlement Method values re-cut), 236 and 272 (Cash Movement.Investor Bank Instruction removed; Client Money "
    "Movement replaces it; Payment Method values re-cut and blank for client-payment rows); "
    "DP-179 specs_e3_ta_fund_governance.py 317 (AP Order Channel values), 343-344 and 357 (AP Resulting Transaction re-typed); "
    "DP-180 specs_e3_ta_fund_governance.py 426-442, 479-483, 510 (CIP Verification removed: re-point to 02 Identity Verification through "
    "15 Account Opening, or drop the CIP metrics), 461 (Matched Sanctions List secondary reference only), 444-486 (Account Monitoring "
    "Alert kept; Monitoring Scenario and Monitoring Alert Category lose payment values; Triggering Money Movement available); "
    "DP-168 specs_e3_fund_accounting_custody.py 57-82 (Transmission Channel: Insurer Feed removed, Broker-Dealer Pricing Feed added); "
    "DP-244 specs_e5_cross_area.py 609, 655 (Dealing Route values); "
    "DP-176 specs_e3_fund_accounting_custody.py 1027-1029, 1077, 1102, 1124 and DP-210 specs_e1_masters.py 758-773, 788 (Servicing "
    "Provider Engagement: domain '13' becomes '29'; attributes unchanged); "
    "DP-043 specs_e_comp_finance_service.py 624, 659 (Servicing Provider Engagement: '13' to '29'); "
    "DP-069 specs_l_shareholder_vendor.py 53-56, 94, 102-110, 137-138 and DP-071 359-402, 431-434 (Intermediary Distribution Request and "
    "NOBO List Request: '13' to '29'; Beneficial Owner Position Count renamed Beneficial Owner Account Count, Holding Model renamed Beneficial Owner Holding Model, including the 'Holding Model = NOBO' filter of NOBO List Coverage at 375-380; the DP-069 metric 'Intermediary Fee Cost per Position' at line 52-56 re-points its denominator to 29 Intermediary Distribution Request.Beneficial Owner Account Count and should be renamed 'Intermediary Fee Cost per Beneficial Owner Account'; its Fee Invoice numerator stays 13 until W4, then 05); "
    "DP-076 specs_i_product_data.py 590-593, 614-615 (same). "
    "Unchanged readers: DP-181, DP-107 (TA Control Check), DP-226 specs_e4_compliance_legal.py 614-659 (Account Monitoring Alert, Alert "
    "Disposition), DP-169 (as-of and order facts; type change of Resulting Transaction only). "
    "Data models: models_e8c_ta_fund_governance.py 185 (Obligation Amount note), 217 and 237 (Investor Bank Instruction dimension and "
    "relationship), 347-349 (Fact CIP Verification), 369 (Triggering Cash Movement, kept); models_c10_shareholder_ops.py 40, 245; "
    "models_c7_product_data.py 427-430 (Beneficial Owner Position Count note); models_c3_comp_finance_service.py 598; models_e8_masters.py 677; "
    "models_e8c_fund_accounting_custody.py 823 (the CW-088 objects: '13' to '29'). Key registries: keys_e7_27_29.py 234, 497-500 (CIP "
    "Verification keys removed), 453, 458, 491 (Order Account, Resulting Transaction, AP Resulting Transaction: target becomes 29 "
    "Register Transaction, RGTX-), 481 (Investor Bank Instruction removed; add Client Money Movement -> 50 Money Movement); "
    "keys_e7_39_41.py 332 and keys_g5_11_12_13_14.py 132, 141, 160, 399, 400, 421 (CW-088 objects move to 29); add keys for Share "
    "Register Balance (composite), Register Transaction (RGTX-) and the new references. "
    "Semantic models: sm_12_transfer_agency_shareholder_operations.py 238 and 668-670 (Obligation Amount: lineage now 29), 270 "
    "(Investor Bank Instruction), 331 (Triggering Cash Movement, kept), 349-355, 809-815, 1054 (CIP Verification fact and measures: "
    "remove or re-point to 02); sm_07_finance_profitability.py 334-339 and sm_06_product_market.py 314 (Beneficial Owner Position "
    "Count renamed, domain 13 to 29).",
    "Renames for the baseline check: families Investor Identity & Financial Crime -> Shareholder Account Monitoring (TA-FCC), TA "
    "Controls -> TA Controls & Oversight (TA-OVS); new family Shareholder Register (TA-REG). Attribute IDs are positional within a "
    "family and renumber in TA-ORC (Platform Order Reference removed, Brokerage Omnibus Order Detail added), TA-STL, TA-FCC (CIP "
    "Verification removed) and TA-OVS (Servicing Provider Engagement added at the end); TA-ETF and TA-IOI keep their IDs. Readers "
    "use names.",
    "Ownership register at the merge (decisions.CONCEPT_OWNERSHIP): Servicing Provider Engagement, Intermediary Distribution Request "
    "and NOBO List Request owner 13 -> 29 (CW-088), so that 40 Supplier Engagement.Specialized Servicing Provider Engagement (content_40) "
    "resolves to 29; add Share Register Balance and Register Transaction (owner 29, RGTX-); retire the CIP Verification row (CW-124). "
    "decisions.PREFIXES: RGTX- Reserved (29), BOD- owner 13 -> 29, CIP- Retired (proposals_w3_oversight TRANSFER_PREFIXES, "
    "RETIRE_PREFIXES). Until the merge the three CW-088 objects exist in both the 13 draft and this module; 13 removes them at the "
    "W3 merge (CW-088 action), with its SV-BOC family keeping only Intermediary Communication Fee Invoice until W4.",
    "For the 13 owner: Confirmation Delivery.Confirmed Fund Order could reference the 29 Register Transaction (the confirmed posting) "
    "rather than the Fund Order; Proxy Campaign.Shares Outstanding at Record Date (Derived copy of 29 Share Register Balance) is "
    "consistent with this draft. The 13 and 15 briefs cite the fund order as TAO-; the key is FNDO- (already noted in "
    "proposals_w3_oversight).",
    "For the 15 owner (program-lead ruling on the 29 review): 15 adds the Account Types Direct Institutional Fund Account, DTC "
    "Nominee Account and CIT Unitholder Account at the W3 merge; Register Account Category maps them to Institutional Direct, DTC "
    "Nominee and CIT Unitholder. 15 Institutional Separate Account does NOT map to Institutional Direct (a separate account is a "
    "mandate whose securities sit at a custodian, not a fund shareholder account). Account "
    "Opening references 02 Identity Verification for fund-only accounts (CW-124); 29 holds no identity data.",
    "For the 48 and 50 owners: Order Route.Resulting Fund Order (48) and Sweep Run.Resulting Sweep Fund Orders (50) reference the "
    "omnibus Fund Order; the counts and amounts on 29 Brokerage Omnibus Order Detail copy 48 for Affiliated Broker-Dealer Omnibus "
    "rows and the 50 sweep allocations for Cash Sweep Run rows (row rule by Order Origin; CW-097, CW-108, CW-123). Order Received "
    "Timestamp of an aggregated order is the broker-dealer's attested aggregation cut-off; per-client Rule 22c-1 receipt evidence "
    "stays on the 48 Client Order.",
    "For the 49 owner: the links are held on the 49 side, as 49's fix pass added them: Stock Record Reconciliation.Reconciled "
    "Register Balances (Reference (Share Register Balance, 29)) and Street Settlement Obligation.Own-Fund Settlement Obligation "
    "(Reference (Settlement Obligation, 29)); 29 REL lines say so. Stock Record Reconciliation (type 49 to 29 omnibus) compares 49 Client Holding totals to 29 Share Register "
    "Balance.Registered Shares of the Broker-Dealer Omnibus account per share class and business date; Street Settlement Obligation "
    "(29 own-fund omnibus channel) settles against the 29 Settlement Obligation of the omnibus Fund Order. Lots of fund-only "
    "accounts are 49 Client Tax Lots opened and relieved by 29 Register Transactions (CW-034).",
    "For the 50 owner: Cash Movement.Client Money Movement and Account Monitoring Alert.Triggering Money Movement reference MMVMT-; "
    "Settlement Exception.Return Reason Code copies the 50 return reason for returned client payments (ROW_OWNERSHIP). The 50 Sweep "
    "Run originates money market sweep Fund Orders (Order Origin 'Cash Sweep Run').",
    "For the W4 06 drafter (program-lead ruling on CW-122, 29 review High finding): the Broker-Dealer Omnibus Share Register "
    "Balance is not a 06 Fund Shareholder Position; the 49 look-through Client Holdings are. 06 excludes Register Account Category "
    "Broker-Dealer Omnibus from its view and Client Assets, and reconciles omnibus units = sum of 49 Client Holdings as a control. "
    "Every other category is read from Share Register Balance and valued at the 27 NAV. 06 Transaction copies Register Transaction "
    "type, dates, shares and Net Amount for TA rows and reads the as-of from the new As-Of Posting Indicator with Register Trade "
    "Date (06 Transaction.As-Of Date). Resolved Dealer and Resolved Representative are mastered in 29 from the Fund/SERV and "
    "Networking feed fields; 06 Intermediary As Delivered copies them for TA rows (the former 29 copy of 06 was circular and is "
    "removed). 06 adopts the label 'Affiliated Broker-Dealer Omnibus' for OWN_BD_OMNIBUS and drops SWIFT ISO 20022 Direct from "
    "Order Entry Channel. Response Data Load and Related Feed Load keep Reference (Load).",
    "For the 13 owner: the example RGTX-2026-000401118 on Servicing Error.Correction Transactions has 9 digits; the format is "
    "RGTX-<year>-<10 digits> (re-key in the 13 fix pass). 13 Escheatment Report & Remittance is the authority for the new 29 "
    "Register Transaction Type Escheatment Delivery.",
    "For the 38 owner: Account Monitoring Alert and Alert Disposition rows of category Fraud - Elder Financial Exploitation or with "
    "a Rule 2165 hold are special category (CD-344) with a restricted view; 38 AML Case readers of Source Account Monitoring Alert "
    "inherit the tier.",
    "For the W4 05 drafter: AP Agreement and Shareholder Information Agreement stay Reference (Agreement) (alias 05) and the "
    "routing REL names Trading Setup / Agreement [05]; re-point them to the replacing 05 objects by name.",
    "Binding 13 fix-pass instruction applied: the received 13 attributes are renamed Beneficial Owner Holding Model (attribute and "
    "list) and Beneficial Owner Account Count; 13 Servicing Error.Correction Transactions references Register Transaction (RGTX-, "
    "format RGTX-<year>-<10 digits> kept) and 13 Proxy Campaign.Shares Outstanding at Record Date copies Share Register Balance. The DTCC record name 'Omni/SERV Position Record' appears in a "
    "source description only. 'Cancellation' is the American spelling.",
    "Workbook during the transition: Order Settlement Method is a member of the shared Fund Dealing Settlement Method, so the 29 "
    "workbook shows the shared values (with CALASTONE_SETTLEMENT and ICSD_CLEARSTREAM_EUROCLEAR, without AFFILIATED_BD_OMNIBUS) "
    "until the program lead applies SHARED_MEMBERSHIPS; the module's local list is the re-cut set.",
    "Brief deviations: (1) proposals file named proposals_w3_29.py, not proposals_29.py (the Stage 2 file of that name is kept). "
    "(2) Cash Movement.Investor Bank Instruction removed rather than kept beside Client Money Movement: CW-107 says Cash Movement "
    "references the 50 money movement 'instead of holding the investor bank instruction'. (3) Register Account Category adds "
    "Institutional Direct and Firm Proprietary to the seven CW-122 values (the IA line's direct accounts and seed accounts are "
    "registered at the TA). (4) Beneficial Owner Position Count and Holding Model renamed on receipt to Beneficial Owner Account Count and Beneficial "
    "Owner Holding Model (binding 13 fix-pass instruction; CW-124 said attributes unchanged). (5) Servicing Provider Engagement gains five attributes "
    "(engagement dates, review period, SOC 1 date, provider service levels) that the brief allowed 'only if the drafter needs them'. "
    "(6) Monitoring Alert Category and Monitoring Scenario lose their payment values (CW-123). (7) Order Origin adds Cash Sweep Run "
    "(the 50 brief's money market sweep fund orders). Fix pass (29_review.md): every High and Medium finding applied under the "
    "program-lead rulings; Lows applied except the brief header count (not a 29 file) and the workbook's shared Fund Dealing "
    "Settlement Method values, which only the merge can change (do not circulate the 29 xlsx as US-only until then).",
]
