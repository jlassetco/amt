"""Consolidation proposals from the W3 adaptation of Data Domain 32 Performance & Attribution (wealth manager), 2026-10-15.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py,
shared_code_lists.py and jurisdiction.REMOVALS at the W3 merge. Formats follow CONTRACT.md in this folder. The brief is
00_Program/Rework/Briefs/W3_24_32_Family_Additions.md (Disposition: Adapt, CW-011). It implements CW-003, CW-011, CW-022,
CW-027, CW-050 and CW-129 (proposals_w3_oversight.py) and completes CW-932, the US-only pass of 32. Module:
content_32_performance_and_attribution.py (edited in place; codes, folder and workbook unchanged). The expansion file
proposals_32.py is left as it is.
"""

_D, _C = "32", "CW-932"

# 1. PREFIXES: none beyond PRROR- and HPGRP- (reserved in proposals_w3_oversight.py, CW-130).
PREFIXES = []

# 2. SHARED MEMBERSHIPS
SHARED_MEMBERSHIPS = [
    {"shared": "Record Status", "local": "Record Status",
     "value_map": {"Draft": "DRAFT", "Proposed": "PROPOSED", "Pending": "PENDING", "Active": "ACTIVE", "Paused": "PAUSED",
                   "Inactive": "INACTIVE", "Deprecated": "DEPRECATED", "Retired": "RETIRED"},
     "new_values": [],
     "note": "New: verbatim local copy for Household Performance Group.Performance Group Status. At the merge add 32 to the direct_users of "
             "Record Status (shared_code_lists.py; 24 already is one), cite 'Shared: Record Status' and drop the local list. Not done here: "
             "the builder refuses 'Shared: Record Status' while 32 is not a direct user, and shared_code_lists.py is outside this pass's files."},
    {"shared": "Business Line", "local": "", "value_map": {}, "new_values": [],
     "note": "Direct user. Covered Business Lines example re-keyed to 'PF; IA; IC' (CW-004)."},
    {"shared": "Return Methodology", "local": "", "value_map": {}, "new_values": [],
     "note": "32 is steward. New users: Client Performance Profile.Client Methods Produced ('Both' allowed), Personal Rate of "
             "Return.Personal Return Method ('Both' not allowed)."},
    {"shared": "Performance Fee Basis", "local": "", "value_map": {}, "new_values": [],
     "note": "New users: Client Fee Bases Produced, Personal Return Fee Basis."},
    {"shared": "Reporting Period Basis", "local": "", "value_map": {}, "new_values": [], "note": "Unchanged users."},
]

# 3. SHARED CANDIDATES
SHARED_CANDIDATES = [
    ("Return Status", ["32", "45", "13"], "13 statements and 45 reports filter Final and Restated personal returns; if they hold a status copy, share it."),
    ("GIPS Composite Exclusion Reason", ["32", "46"], "Renamed from Composite Exclusion Reason in the fix pass so that 32 (GIPS, 4 values) and 46 Composite Exclusion Reason (6 values) no longer share a name with two value sets; 46 may become the superset steward."),
]

# 4. TERM_CONFLICTS
TERM_CONFLICTS = [
    {"term": "Return (wealth model)",
     "usages": [("32", "Performance Return (RETURN-)", "Official return of a fund, portfolio, institutional separate account, composite or model."),
                ("32", "Personal Rate of Return (PRROR-)", "Certified client account or household return (CW-011).")],
     "recommendation": "'Personal Rate of Return' for clients; 'Performance Return' otherwise. 45's 'Client Account Performance' "
                       "reference names the 32 family; re-type it to Reference (Personal Rate of Return, 32).",
     "resolution": "Two named objects in 32.", "status": "Resolved", "decision": "CW-129"},
    {"term": "Household",
     "usages": [("02", "Household (PTY-HH-)", "Client Household."),
                ("32", "Household Performance Group (HPGRP-)", "Accounts measured together for performance."),
                ("13", "Householding Group (MHG-)", "Mailing Household."),
                ("46", "Household Managed Group", "Managed accounts run together."),
                ("47", "Fee Household", "Accounts aggregated for fee breakpoints.")],
     "recommendation": "Never bare 'household' for a grouping; 32 says 'household performance group'.",
     "resolution": "Kept distinct (CW-027).", "status": "Resolved", "decision": "CW-027"},
    {"term": "Composite",
     "usages": [("01", "GIPS Composite (CMP-)", "GIPS composite definition."),
                ("32", "Composite Membership; Composite Period Statistic", "GIPS membership of 18 portfolios and statistics."),
                ("46", "Managed Account Composite (MACP-)", "Program composite of client managed accounts; returns computed in 32.")],
     "recommendation": "'GIPS composite' (01, 32) vs 'managed account composite' (46). No retail account is a GIPS composite member.",
     "resolution": "CW-050, CW-129.", "status": "Resolved", "decision": "CW-050"},
]

# 5. JURISDICTION (CW-932)


def _j(obj, attr, regime, note):
    return {"domain": _D, "object": obj, "attribute": attr, "regime": regime, "decision": _C, "note": note}


JURISDICTION = [
    _j("Sources", "Commission Regulation (EU) No 583/2010, Articles 15-19 (UCITS KIID past performance) and its UK onshored version", "UCITS",
       "Cited for the calendar-year bar chart; Performance Return keeps the US basis (Form N-1A Item 4, Rule 482)."),
    _j("Sources", "PRIIPs Delegated Regulation (EU) 2017/653 as amended by (EU) 2021/2268", "PRIIPs",
       "Past performance beside the KID; no attribute depended on it only."),
    _j("Sources", "AIFMD Annex IV reporting (Delegated Regulation (EU) 231/2013), half of the source row 'SEC Form PF ... and AIFMD Annex IV'", "AIFMD",
       "The row is kept as 'SEC Form PF'; the reference tag 'AIFMD Annex IV' is removed."),
    _j("GIPS Firm", "GIPS Firm Definition (example)", "UK market practice",
       "Example 'group's US and UK investment advisers' re-worded to 'SEC-registered investment adviser and its "
       "non-US affiliates'; foreign affiliates stay as text, not as a regime."),
    _j("META and overview", "Subtitle; Purpose", "UCITS",
       "'Scope: US + EU/UK' and 'the UCITS KIID past performance rules (Regulation (EU) 583/2010) and PRIIPs' as sources (UCITS and "
       "PRIIPs). Rewritten to 'Wealth manager (direct) | Scope: US' and US sources."),
    _j("META and overview", "Suggested next steps; REL Performance Return - Fund Regulatory Filing", "AIFMD",
       "'which return rows feed N-PORT, Form PF and Annex IV' and 'Form PF, Annex IV'; Annex IV removed."),
    _j("META and overview", "Notes", "GDPR / UK GDPR",
       "'PII = personal data under GDPR / UK GDPR and US state privacy laws'; rewritten to the GLBA, Regulation S-P and state law."),
]

# 6. REPOINTS
REPOINTS = [
    ("Performance Return", "Return Account", "15 account: SMA, institutional, participant or direct shareholder account (CD-220 option A); PII",
     "15 institutional separate account only; client accounts are Personal Rate of Return (CW-129 supersedes CD-220 option A)", "CW-129"),
    ("Performance Measurement Profile", "Profiled Account", "15 account; PII when individual", "15 institutional separate account only", "CW-129"),
    ("Performance Return / Performance Measurement Profile", "Return Managed Account Composite; Profiled Managed Account Composite", "",
     "added, Reference (Managed Account Composite, 46), MACP-", "CW-050"),
    ("Code list: Measured Subject Type", "Account; Managed Account Composite", "Account = SMA, institutional, participant, direct shareholder",
     "Account = institutional separate account; Managed Account Composite added", "CW-129, CW-050"),
    ("Code list: Return Source", "Recordkeeping Platform", "participant or shareholder personal return (CD-220)", "participant account return on Personal Rate of Return only", "CW-129"),
    ("Code list: Performance Close Group", "SMA and Institutional Portfolios; Participant and Shareholder Accounts",
     "SMA and Institutional Portfolios; Participant and Shareholder Accounts",
     "Institutional Separate Accounts and Portfolios; Client Accounts and Household Groups; Managed Account Composites added", "CW-129"),
    ("PII_ROW notes (Return Value, Income Return, Capital Return, Statistic Value, Active Return, segment and effect values, contributions)", "",
     "PII on rows of an account or SMA portfolio held by an individual", "Not personal data: subjects are funds, institutional separate accounts, composites and models", "CW-129"),
    ("Composite Membership", "Member Portfolio", "PII when an individual's SMA book", "18 fund or institutional portfolio only; no retail account in a GIPS composite", "CW-129"),
    # Fix pass (24_32 review)
    ("Return Component Detail", "Fees Deducted Amount", "Derived copy (12), 12 fee invoices and accruals", "Derived copy (47), 47 Fee Invoice and Performance Fee Calculation (CW-054); REL to Performance Fee Calculation [47]; Scope and SUMMARY re-pointed", "CW-054"),
    ("Personal Rate of Return", "Beginning Market Value; Ending Market Value; Net External Flows; Fees Deducted", "49 Client Holding Valuation / Client Account Activity, 16 Participant Balance, 47 Fee Debit",
     "row rules by account kind: 49 Client Holding Valuation, Account Cash Balance (sweep included), Margin Balance Snapshot debit, Client Account Activity; 29 Share Register Balance, Register Transaction (fund-only); 16 Participant Balance, Participant Ledger Posting (plan); 47 Fee Debit, Fee Invoice; 16 Plan Fee Schedule (plan fees)", "CW-129"),
    ("Personal Rate of Return", "Personal Return Calculation Method; Personal Return Period Basis; Personal Return Client Notification Indicator", "", "added", "CW-129"),
    ("Client Performance Profile", "Client Comparison Target Set", "Reference (Target Allocation Set, 24)", "removed: the comparison is the model's 01 blended benchmark (Benchmark Return is keyed by an 01 benchmark)", "CW-129"),
    ("Household Performance Group Member", "Member Account", "mastered here", "row rule: derived from 02 Household Membership and 15 ownership on Default groups; mastered on Client-Defined Subset groups", "CW-027"),
    ("CDE flags", "", "Member Account, Client Return Exception Type, Member Inclusion Date, Performance Group Type, Statistic Period End Date flagged", "un-flagged; flagged instead Personal Return Account, Personal Return Group, Client Profile Account", "CW-129"),
    ("Code list: Composite Exclusion Reason", "", "Composite Exclusion Reason", "GIPS Composite Exclusion Reason", "CW-050"),
    ("Return Suppression Reason / Personal Return Suppression Reason", "", "FINRA Rule 2210", "Internal, FINRA Rule 2231 (confirm)", "CW-129"),
    ("REL", "Database Submission", "[03]", "[05]", "CW-023"),
    # Retirement of 30 (CW-930, CW-166) and the insurance-dedicated close group (CW-165); proposals_w4_retire.py CARRIED_INTO_MERGE, 19 items
    ("Private Markets Performance (PF-PVM)", "", "family: Private Markets Performance Measure (21 attributes), Investor Performance Measure (8), Public Market Equivalent (11)",
     "removed; feeder funds are ordinary Performance Returns. Readers: DP-145 specs_e1_book_of_record.py 629-698 and models_e8_book_of_record.py 583-586 (drop the 30 inputs and the Private Fund IRR and Multiples metric's 32 input); DP-160 specs_e2_invops_b.py 610-721 and models_e8c_invops_b.py 382-406 (retires at WP0); SM-08 register.py 47-48, 131 and sm_08_investment_book_performance.py 5, 7, 41, 112-113, 416-437 (private_measure, investor_performance, investor_commitment, investor_capital_account); SM-17 sm_17_technology_data_communications.py 1064, 1370 (ref to SM-08/Private Fund IRR and Multiples); SM-13 retires (register.py 70-73)", "CW-930, CW-166"),
    ("Code list: Measured Subject Type", "Private Fund; Private Investment", "values", "removed", "CW-930"),
    ("Code list: Facility Basis; ILPA Performance Methodology; PME Method", "", "3 lists", "removed with the family", "CW-930"),
    ("REL", "Private Markets Performance Measure, Investor Performance Measure and Public Market Equivalent rows; '/ Private Markets Performance Measure' on the 12 presentation row", "4 edits", "removed", "CW-930"),
    ("Sources", "ILPA Reporting Template and Performance Template (2025); Kaplan and Schoar (2005) et al.; GIPS guidance statements on private market investments and subscription lines", "", "removed (two rows, one title cut)", "CW-930"),
    ("Code list: Performance Close Group", "Insurance-Dedicated Fund Share Classes", "value", "removed", "CW-165"),
    ("META overview and enrich_32 GRAIN, OWNERSHIP_OVERRIDES, SUMMARY", "", "private markets measures, ILPA, PME, 30 references, CD-219 principle, next step 8", "removed; principle 7 states that feeder returns are ordinary returns", "CW-930, CW-166"),
    ("Performance Calculation Policy", "Covered Business Lines", "example 'Mutual Fund; ETF; Collective Investment Trust; Separately Managed Account; Insurance-Dedicated Fund'", "'PF; IA; IC'", "CW-004"),
]

# 7. DECISIONS
DECISIONS = [
    {"id": "CW-932", "theme": "Scope", "title": "US-only pass of 32 Performance & Attribution", "domains": ["32", "46", "16"],
     "issue": "32 cited UCITS KIID past performance (Regulation (EU) 583/2010), PRIIPs (2017/653) and AIFMD Annex IV, used a GIPS "
              "Firm Definition example naming UK advisers, GDPR notes and 'US + EU/UK' perspective, and measured retail, participant "
              "and direct shareholder accounts on Performance Return (CD-220 option A).",
     "resolution": "Removed (7 JURISDICTION entries: UCITS 2, PRIIPs 1, AIFMD 2, UK market practice 1, GDPR / UK GDPR 1): the UCITS KIID "
                   "and PRIIPs sources and the AIFMD half of the Form PF source; META and next-step mentions; GIPS Firm Definition "
                   "example re-worded; Notes to the GLBA, Reg S-P and state law; Covered Business Lines example 'PF; IA; IC'. No "
                   "object or attribute existed only for an EU/UK regime. Re-scoped (CW-129): Performance Return and Measurement "
                   "Profile account subjects are institutional separate accounts only; no retail account is a GIPS composite member. "
                   "Added: family Client Account Performance (Client Performance Profile, Household Performance Group HPGRP-, "
                   "Household Performance Group Member, Personal Rate of Return PRROR-, Client Return Exception) and Managed Account "
                   "Composite subjects (CW-050). Private Markets Performance kept (CD-219); references to 30 left for W4. Counts: 6 "
                   "to 6 families, 24 to 26 objects, 240 to 246 attributes, 80 to 85 CDEs (34.6%), 60 to 57 references, 8 to 12 "
                   "derived, 31 to 34 code lists, 48 to 56 relationships, 19 to 17 sources (3 EU removed or cut, FINRA Rule 2231 "
                   "and Reg S-P added; at the fix pass the Private Markets Performance family, its lists, RELs and ILPA and PME "
                   "sources left with the 30 retirement, CW-930, CW-166). Personal values, flows and fees name 49, 29, 16 and 47; "
                   "institutional fees are 47 (CW-054). GIPS firm scope excludes the advice programs by default (lever: wrap or "
                   "pooled composites).",
     "rationale": "CW-003 and CW-022; CW-011 and CW-129 certify the personal return separately from the official fund and "
                  "institutional return. Lever: a UK extension restores the KIID and PRIIPs sources from wholesale-v1.0.",
     "action": "W3", "status": "Proposed", "priority": "Low", "owner_role": "Program lead"},
]

# 8. NOTES
NOTES = [
    "FIX PASS (24_32 review, program-lead rulings 2026-10-15). GIPS firm scope: by default the advice programs (46 managed account "
    "programs) are run by a separate adviser entity outside the GIPS firm, so their accounts need not be in a GIPS composite (GIPS "
    "2020 composite requirement for discretionary fee-paying segregated accounts; provision number to confirm); lever: they enter the "
    "GIPS firm as wrap or pooled composites, and their accounts then become 32 Composite Membership rows. MERGE EDIT TO 46: Managed "
    "Account Composite's link to a 01 GIPS composite (content_46 Linked GIPS Composite) becomes conditional on that lever; its "
    "definition should say so, and 32 Composite Period Statistic counts the 46 members only under the lever.",
    "Requests to other owners: 13 (statements) and 45 (Goal Progress Snapshot) reference Final PRROR- records, Reference (Personal "
    "Rate of Return, 32); neither holds one yet (REL row marked 'Proposed'). 47 billing replaced 12 for institutional fee invoices "
    "(CW-054): 32 copies 47 Fee Invoice and Performance Fee Calculation.",
    "SME levers added: (1) personal-return calculation method (default true IRR for the money-weighted headline, Modified Dietz "
    "linked monthly or daily valuation for time-weighted); (2) GIPS firm scope (above); (3) fund-only account source (default 29 Share "
    "Register Balance and Register Transaction; lever: a firm that books every account in 49 reads 49 only).",
    "Fix pass Lows: applied Return Net Fee Basis note (12 Presentation Profile Fee Basis Shown), Missing Price '49 Client Holding', "
    "suppression source (Internal, FINRA Rule 2231 confirm), Database Submission [05], GIPS Composite Exclusion Reason rename, regime "
    "'UK market practice' for the GIPS Firm Definition example, PRROR client notification indicator, 'Householding Group (MHG-)' "
    "wording for 13, 13 reader request, the 49/52 status text. Skipped: the Record Status direct-user change (shared_code_lists.py is "
    "outside this pass; proposed in SHARED_MEMBERSHIPS). FINRA Rule 2210 projection rule moving (SR-FINRA-2026-004, pending): 32 cites "
    "2210 only for hypothetical performance in communications; marked confirm in Source_Notes.",
    "READERS (lines as of 2026-10-15). DP-145 Official Returns: data_products/specs_e1_book_of_record.py 657 (Profiled Account), 663 "
    "(Return Account), 734 (Return Source 'Recordkeeping Platform'), 736 (PII = Y under CD-220 option A). SM-08: "
    "semantic_model/models/sm_08_investment_book_performance.py 74 (return_account). Data models: data_models/keys_e7_31_33.py 152, "
    "394, 402; data_models/models_e8_book_of_record.py 555, 598, 610. DP-158: specs_e2_invops_b.py 323 (GIPS Firm Definition; "
    "example text only). DP-157, DP-159, DP-160, DP-109, DP-183, DP-185, DP-242, DP-245: read unchanged objects. Nothing was removed "
    "from 32 except sources, so no reader loses a column.",
    "READERS (disposition, proposal). DP-145 is extended at WP1 to publish Personal Rate of Return (CW-011): add a PRROR- output "
    "(subject, period, method, fee basis, value, status, version; values and flows as Derived copies of 49, 16, 47) with PII = Y; "
    "its Performance Return output drops the CD-220 PII statement (account rows are institutional) and the 'Recordkeeping "
    "Platform' source note. SM-08: return_account stays (institutional); add a personal_rate_of_return fact keyed by account or "
    "household performance group. keys_e7_31_33 and models_e8_book_of_record: add keys for the five new objects (GRAIN_KEY_FORMATS "
    "in proposals_w3_oversight.py).",
    "45 at its fix pass: Goal Progress Snapshot.Client Return Reference (content_45 line 136) is typed Reference (Client Account "
    "Performance, 32), the family name; re-type to Reference (Personal Rate of Return, 32) with a PRROR- example. 13 statements read "
    "Final PRROR- records; 13 holds no return value.",
    "46: Managed Account Composite (MACP-) returns are Performance Return rows with subject type Managed Account Composite; 46 "
    "membership feeds them (CW-050). 46 Household Managed Group and 32 Household Performance Group are distinct (CW-027).",
    "49, 29, 47, 50 and 52 are drafted in the tree; the names used resolve: 49 Client Holding Valuation, Account Cash Balance, "
    "Margin Balance Snapshot, Client Account Activity (CLACT-); 29 Share Register Balance, Register Transaction; 47 Fee Debit, Fee "
    "Invoice, Performance Fee Calculation; 50 Sweep Program; 16 Participant Balance, Participant Ledger Posting, Plan Fee Schedule.",
    "W4 (30 retirement, CW-930, CW-166; CW-165): applied in the fix pass, all 19 CARRIED_INTO_MERGE items of proposals_w4_retire.py "
    "for 32 plus the 'Insurance-Dedicated Fund Share Classes' close group (REPOINTS above, with readers).",
    "Brief deviations: (1) proposals file named proposals_w3_32.py as assigned. (2) Measurement Profile gains Profiled Managed "
    "Account Composite beside the brief's Return Managed Account Composite, so composite returns have a close group. (3) Personal "
    "Rate of Return gained Calculation Method and Period Basis in the fix pass (band widened to 295). (4) Household Performance Group holds no own dates or name (size band); measurement dates are on members and the "
    "profile. (5) Local Record Status copy (32 not a direct user of the shared list).",
    "Grep after the pass: no UCITS, PRIIP, AIFMD, KIID, GDPR, ESMA, MiFID, FCA, 'UK ' or 'EU '. 'CD-220' remains only in the Return "
    "Account note stating that CW-129 supersedes it. 'Holding' only in '49 Client Holding Valuation'.",
]
