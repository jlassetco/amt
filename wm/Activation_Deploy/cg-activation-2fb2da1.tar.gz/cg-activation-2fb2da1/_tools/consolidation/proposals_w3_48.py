"""Consolidation proposals from the W3 draft of Data Domain 48 Brokerage Orders & Execution (wealth manager, new domain,
CW-010), 2026-10-14.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py and
shared_code_lists.py at the W3 merge. Formats follow CONTRACT.md in this folder. Decisions implemented: CW-007, CW-010
(decisions.py), CW-037, CW-031 (proposals_wealth_w1.py), CW-049, CW-081 (W2 proposals) and CW-096 to CW-100, CW-112 to
CW-115 (proposals_w3_brokerage.py, treated as accepted). New domain: no US-only pass decision (CW-022) and no JURISDICTION
entries; the EU/UK concepts deliberately left out are listed in 48_Brokerage_Orders_and_Execution/Source_Notes.md section 2 (Jurisdiction).
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES (prefix, entity, owner domain, status, note) - decisions.PREFIXES format
# None beyond the six reserved in proposals_w3_brokerage.py (CLORD-, ROUTE-, CLEXE-, CLBLK-, CCONF-, TCORR-), whose key
# formats are published there (PREFIX_FORMATS). Every other 48 object keeps a composite key (KEY_FORMATS below).
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

KEY_FORMATS = [
    ("Option Order Leg", "Composite: CLORD- / leg sequence, e.g. 'CLORD-20261005-004188230 / 1'", ""),
    ("Client Order Event", "Composite: CLORD- / event sequence, e.g. 'CLORD-20261005-004188221 / 4'", ""),
    ("Order Eligibility Check", "As GRAIN_KEY_FORMATS in proposals_w3_brokerage.py: CLORD- / check type", ""),
    ("Pre-Trade Risk Limit", "Composite: scope / scope value (ACC-, segment or channel code, or blank for Firm) / instrument class (or "
     "blank) / limit type / effective from, e.g. 'Account Segment / SELF_DIRECTED_CASH / NMS Stock - Other / Single Order Notional "
     "Maximum / 2026-01-01'", "No prefix (lever: a prefix if per-account limits become numerous)."),
    ("Execution Venue Profile", "Composite: PTY- / effective from", "Role profile of a 02 party; references use Reference (Party)."),
    ("Routing Rule", "Firm-defined routing rule code without a hyphen, e.g. 'EQ_MKT_SMALL_V3' (code x effective period)", ""),
    ("Client Allocation", "As GRAIN_KEY_FORMATS: CLBLK- or CLORD- / ACC-", ""),
    ("Regulatory Trade Report", "Composite: CLEXE- / facility / submission timestamp", ""),
    ("Trade Error Case", "Firm case number without a prefix, e.g. 'TEC 2026-000412'; the case may cover one client order, a whole "
     "client block order or a missed instruction", "No reserved prefix; propose one at W5 if the case number is published."),
    ("Option Exercise Instruction", "As GRAIN_KEY_FORMATS: ACC- / INS- / exercise date", ""),
    ("Option Assignment Allocation", "Composite: OCC assignment notice reference / ACC-", ""),
    ("Execution Quality Measure", "Composite: period start / order class / client order type / PTY- (or 'Firm')", ""),
    ("Rule 605 Report Line", "LEN- / YYYY-MM / INS- / Rule 605 order type / lot class / notional dollar range, e.g. 'LEN-0004 / "
     "2026-09 / INS-00104477 / Marketable Limit / Odd Lot / USD 1,000 to < 5,000'",
     "Re-key the GRAIN_KEY_FORMATS example 'MARKETABLE / 100-499' at merge: the rule as adopted in 2024 (Release 34-99679) sets size "
     "categories by notional dollar value within fractional, odd-lot and round-lot classes, not by share count or round lots. The dollar "
     "boundaries are to be taken from 17 CFR 242.605(a)(1) (not verified; example illustrative)."),
    ("Rule 606 Report Line", "As GRAIN_KEY_FORMATS: LEN- / quarter / month / order class / PTY-", ""),
    ("Order Routing Disclosure Request", "Composite: PTY- / ACC- / request received date", ""),
    ("CAT Reportable Event", "Firm CAT record ID (firmROEID), unique per submitter and day, e.g. "
     "'20261005_ROUTE-20261005-004188221-01_E1'",
     "Replaces the GRAIN_KEY_FORMATS key 'source / event type / submission date', which collides for two modifications or routes of one "
     "order on one day. Allocation events reference the Client Allocation."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local 48 lists carrying an enterprise shared list's exact name and values (copied 2026-10-14).
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Order Side", "local": "Order Side",
     "value_map": {"Buy": "BUY", "Sell": "SELL", "Sell Short": "SELL_SHORT", "Sell Short Exempt": "SELL_SHORT_EXEMPT",
                   "Buy to Cover": "BUY_TO_COVER", "Subscribe": "SUBSCRIBE"},
     "new_values": [], "note": "Full list (brief section 8; 48 joins steward 25 as a member). Client Order.Order Side, Option Order "
                               "Leg.Leg Side, Client Block Order.Block Side, Client Trade Confirmation.Confirmed Side. Subscribe is copied but "
                               "not used in 48: every purchase, fund purchases included, is Buy; fund redemptions use Sell."},
    {"shared": "Message Standard", "local": "Message Standard",
     "value_map": {"FIX": "FIX", "DTCC Fund/SERV": "DTCC_FUNDSERV", "Proprietary": "PROPRIETARY"},
     "new_values": [], "note": "Subset. Order Route.Route Message Standard."},
    {"shared": "Regulatory Report Status", "local": "Regulatory Report Status",
     "value_map": {"Pending": "PENDING", "Submitted": "SUBMITTED", "Accepted": "ACCEPTED", "Rejected": "REJECTED",
                   "Corrected": "CORRECTED", "Canceled": "CANCELED", "Not Required": "NOT_REQUIRED"},
     "new_values": [], "note": "Regulatory Trade Report.Trade Report Status; CAT Reportable Event.CAT Report Status (CAT feedback error "
                               "codes are an External list)."},
    {"shared": "Record Status", "local": "Record Status",
     "value_map": {"Draft": "DRAFT", "Proposed": "PROPOSED", "Pending": "PENDING", "Active": "ACTIVE", "Paused": "PAUSED",
                   "Inactive": "INACTIVE", "Deprecated": "DEPRECATED", "Retired": "RETIRED"},
     "new_values": [], "note": "Execution Venue Profile.Venue Profile Status."},
    {"shared": "Severity", "local": "Severity",
     "value_map": {"Low": "LOW", "Medium": "MEDIUM", "High": "HIGH", "Critical": "CRITICAL"},
     "new_values": [], "note": "Trade Error Case.Error Severity."},
    {"shared": "Case Status", "local": "Case Status",
     "value_map": {"New / Received": "NEW", "Pending Good Order": "PENDING_GOOD_ORDER", "In Progress": "IN_PROGRESS",
                   "Waiting on Client": "WAITING_ON_CLIENT", "Pending Third Party": "PENDING_THIRD_PARTY", "Escalated": "ESCALATED",
                   "Resolved / Completed": "RESOLVED", "Closed": "CLOSED", "Rejected": "REJECTED", "Canceled": "CANCELED"},
     "new_values": [], "note": "Trade Error Case.Error Case Status."},
]
# Business Line (CW-004) and Approval Status are not used: the business line of an order is read from the 15 account and
# 01 offering; the correction approval is evidenced by Correction Approved By (20 employee).

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: (local list name, likely users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Client Order Type", ["48", "25"],
     "Named apart from 25 'Order Type' (brief section 8 lever): both follow FIX OrdType (40), but 48 adds the retail values Trailing Stop, "
     "Trailing Stop Limit, Net Debit, Net Credit and Next NAV and drops Pegged and Previously Quoted. Candidate for one FIX-based list "
     "with a W5 LOCAL_RENAMES entry or a shared 'Order Type' (steward 25) with both subsets."),
    ("Order Capacity", ["48", "25", "26", "49"],
     "FIX OrderCapacity (528) values used on executions, confirmations and trade reports; 25 cites FIX LastCapacity (29) as External and "
     "49 will book capacity on activity. Candidate shared list, steward 48."),
    ("Trade Reporting Facility", ["48", "26", "49"],
     "FINRA TRF, ADF, ORF, TRACE and MSRB RTRS. Not the 26 'Regulatory Trade Report Regime' (CFTC Part 45, Reg SBSR, Rule 10c-1a), which "
     "lists regimes, not facilities: keep separate (NOT_MERGED) unless the regime list is widened to facilities."),
    ("Routing Instrument Class", ["48", "49", "47"],
     "Instrument classes used for routing, market access limits and execution-quality measures; 47 Instrument Charge Category is close "
     "but prices transactions. Keep local; review at W5."),
    ("CAT Event Type", ["48", "38"],
     "38 trade surveillance may need the same vocabulary at W4."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (plan section 5.3 watchlist and CW-113), decisions.TERM_CONFLICTS format
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = []   # no new duplicate entries: the 48 usages are amendments of resolved entries (TERM_CONFLICT_AMENDMENTS)
                      # plus three new terms (TERM_CONFLICTS_NEW).

# Amendments to existing decisions.TERM_CONFLICTS entries (matched by "term"). "add_usages" are appended to the entry's usages;
# "resolution", "recommendation" and "status" replace the entry's fields; "decision" is set.
TERM_CONFLICT_AMENDMENTS = [
    {"term": "Order (wealth model)",
     "add_usages": [("46", "Trade Proposal (TRPR-)", "Proposed trade for a managed account up to release; released as a 48 Client Order or a 29 Fund Order."),
                    ("24", "Proposed Trade", "Intended trade for an 18 portfolio before release as a 25 order."),
                    ("29", "Fund Order on the brokerage omnibus account", "Result of own-fund Client Order routes, one per side per share class and dealing cycle unless netted (CW-097)."),
                    ("40", "Purchase Order (PURCH-)", "Firm purchase commitment; not a securities order.")],
     "recommendation": "Always qualify: 'Client Order' (48, CLORD-), 'Portfolio Order' / 'Trade Order' (25, TORD-), 'Fund Order' (29, FNDO-), "
                       "'Trade Proposal' (46), 'Proposed Trade' (24), 'Purchase Order' (40). A brokerage client's fund order is a 48 Client "
                       "Order whose route results in a 29 Fund Order (CW-097).",
     "resolution": "No unqualified primary sense; always qualified as 'Client Order' (48), 'Portfolio Order' (25) or 'Fund Order' (29); "
                   "46 'Trade Proposal' and 24 'Proposed Trade' precede them.",
     "status": "SME", "decision": "CW-010"},
    {"term": "Execution",
     "add_usages": [("48", "Client Execution (CLEXE-)", "Fill of a client order route, including a fund fill at NAV.")],
     "recommendation": "'Execution' alone stays the 25 fill (ownership.ALIASES); 48 always writes 'Client Execution'.",
     "resolution": "Primary sense: 25 Execution (EXEC-), a fund desk fill. The client-account fill is always 'Client Execution' (48, CLEXE-). "
                   "Agreements use 'signed' or 'executed agreement' (05).",
     "status": "Resolved", "decision": "CW-113"},
    {"term": "Allocation",
     "add_usages": [("48", "Client Allocation", "Account share of a client block or order's executions, at average price; 49 books it."),
                    ("48", "Option Assignment Allocation", "Account share of an OCC assignment notice."),
                    ("50", "Sweep Allocation", "Account x program bank sweep balance."),
                    ("49", "Dividend Reinvestment Allocation", "Reinvested shares of a client corporate action entitlement.")],
     "recommendation": "Qualify every use; add 'Client Allocation' and 'Option Assignment Allocation' (48), 'Sweep Allocation' (50) and "
                       "'Dividend Reinvestment Allocation' (49) to the existing list.",
     "resolution": "No unqualified primary sense; always qualified. Use 'Asset Allocation' and 'Target Allocation' (24), 'Trade Allocation' and "
                   "'New Issue Allocation' (25), 'Client Allocation' and 'Option Assignment Allocation' (48), 'Dividend Reinvestment "
                   "Allocation' (49), 'Sweep Allocation' (50), 'Credit Allocation' (07), 'Cost Allocation' (10) and 'Deal Allocation' (30).",
     "status": "Resolved", "decision": "CW-113"},
    {"term": "Confirmation",
     "add_usages": [("48", "Client Trade Confirmation (CCONF-)", "Rule 10b-10 content record of a client allocation, one row per version."),
                    ("13", "Confirmation Delivery", "Rendering and delivery of the 48 record (brokerage accounts) or of a 29 fund order confirmation (fund-only accounts).")],
     "recommendation": "Reopen: the existing resolution gives the Rule 10b-10 confirmation to 13 'Shareholder Confirmation', which CW-081 and "
                       "CW-098 overturn. Record in 48, delivery in 13, broker affirmation in 26.",
     "resolution": "No unqualified primary sense. 'Client Trade Confirmation' (48, CCONF-) is the Rule 10b-10 confirmation record; "
                   "'Confirmation Delivery' (13) is its rendering and delivery; 'Trade Confirmation' (26, CNFM-) is the broker or counterparty "
                   "confirmation and affirmation of a fund trade. The 13 'Shareholder Confirmation' usage is retired.",
     "status": "SME", "decision": "CW-098"},
    {"term": "Trade",
     "add_usages": [("48", "Client Trade Confirmation / Trade Correction / Trade Error Case", "Client-account confirmation, correction and error records."),
                    ("49", "Client Account Activity", "Booked effect of a client allocation on the brokerage book of record.")],
     "recommendation": "Extend the glossary chain for client accounts: Trade Proposal (46) -> Client Order -> Order Route -> Client Execution -> "
                       "Client Allocation -> Client Trade Confirmation (48) -> Client Account Activity (49).",
     "resolution": "No unqualified primary sense; no object is called 'Trade'. Portfolio chain: 'Proposed Trade' (24), 'Trade Order', "
                   "'Execution' and 'Trade Allocation' (25), 'Portfolio Transaction' (18), 'Trade Confirmation' and 'OTC Derivative Trade' "
                   "(26). Client chain: 'Trade Proposal' (46), 'Client Order' to 'Client Trade Confirmation', 'Trade Correction' and 'Trade "
                   "Error Case' (48), 'Client Account Activity' (49).",
     "status": "Resolved", "decision": "CW-113"},
]

TERM_CONFLICTS_NEW = [
    {"term": "Block",
     "usages": [("48", "Client Block Order (CLBLK-)", "Client orders aggregated from a 46 batch, an advisor block or fractional aggregation."),
                ("25", "Block Order (BLOCK-)", "Portfolio orders aggregated by the fund desk.")],
     "recommendation": "Bare 'block order' resolves to 25; 48 writes 'Client Block Order'.",
     "resolution": "Primary sense: 25 Block Order. The client-grain aggregate is always 'Client Block Order' (48).",
     "status": "Resolved", "decision": "CW-096"},
    {"term": "Correction",
     "usages": [("48", "Trade Correction (TCORR-)", "Cancel, correct, rebill or as-of change to a client execution or allocation."),
                ("48", "Trade Error Case", "Error in a client order, block or missed instruction and how the client was made whole."),
                ("25", "Trade Error", "Fund desk error."),
                ("06", "Correction Reason (list)", "Shareholder transaction correction reason.")],
     "recommendation": "Trade Correction is the change; Trade Error Case (48) and Trade Error (25) are the error records. 48 names its "
                       "reason list 'Trade Correction Reason' to keep it apart from the 06 list.",
     "resolution": "No unqualified primary sense; always qualified as 'Trade Correction' (48), 'Trade Error Case' (48) or 'Trade Error' (25).",
     "status": "Resolved", "decision": "CW-113"},
    {"term": "Route",
     "usages": [("48", "Order Route (ROUTE-)", "Child order of a client order or block to one venue, Fund/SERV or the transfer agent."),
                ("48", "Routing Rule", "Venue selection rule of the broker-dealer."),
                ("46", "Proposal Execution Route (list)", "Kind of order a trade proposal is released as."),
                ("29", "Order Routing Detail", "How a fund order reached the transfer agent.")],
     "recommendation": "Order Route (48) is the only routing record of client orders; 46's 'Execution Route' is a classification and 29's "
                       "'Order Routing Detail' describes a fund order's channel.",
     "resolution": "Primary sense: 48 Order Route. 46 and 29 usages are classifications or channel detail and keep their qualified names.",
     "status": "Resolved", "decision": "CW-113"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION (new domain, CW-022): none. DECISIONS: none pre-allocated for 48.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = []
DECISIONS = []

# ---------------------------------------------------------------------------------------------------------------------
# 6. NOTES for the consolidation step
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Reserved prefixes CLORD-, ROUTE-, CLEXE-, CLBLK-, CCONF-, TCORR- are not yet in decisions.PREFIXES; 48 references its own objects as "
    "'Reference (<Object>, 48)'. After registration, the example-prefix rule resolves them unchanged.",
    "Booking key (CW-098, fix pass 2026-10-15): 49 Client Account Activity.Source Client Allocation (Reference (Client Allocation, 48), "
    "example 'CLBLK-20261005-000412 / ACC-0049812') holds the link on the 49 side only. 48 dropped Client Allocation.Booked Client Account "
    "Activity; the 48 REL row 'Client Account Activity [49] books Client Allocation' documents the direction. An own-fund route returns a "
    "Client Execution at the 29 Fund Order's NAV, so 49 books own-fund orders through the same allocation.",
    "Re-key at the W3 merge (CW-114): only 08 still uses the plan anchor (Supervisory Review.Reviewed Client Order and Sales Practice "
    "Alert.Triggering Transaction, COR-2026-00884512 -> CLORD-<YYYYMMDD>-<9 digits>). 45 and 46 already use CLORD- and CTLOT-. 13 "
    "Confirmation Delivery.Client Trade Confirmation uses CCONF-2026-000418273, which does not follow PREFIX_FORMATS: conform it to "
    "'CCONF-20261005-004188221-01', and re-point the 13 REL text that still says CCF-.",
    "13 Confirmation Delivery.Confirmation Timing: make it a Derived copy (48) of Client Trade Confirmation.Periodic Confirmation Indicator "
    "(Rule 10b-10(b)); 48 dropped the 'Periodic' value from Confirmation Type so the election is held once.",
    "08 (W2 merge, CW-100): 08 is adding the Supervisory Review type 'Best Execution Regular and Rigorous Review' (FINRA Rule 5310.09), "
    "with a 48 routing arrangement (Routing Rule) or venue (Execution Venue Profile) as subject. 48 Routing Rule.Approving Review and "
    "Execution Quality Measure.Reviewing Committee Review reference reviews of that type.",
    "46 (W3 merge): CW-049 has the Client Order carry the proposal (Client Order.Source Trade Proposal); 46 Trade Proposal.Released Client "
    "Order should be dropped or flagged Derived (48) so the link is held once. Program lot selections are copied into Client Order."
    "Specified Client Tax Lots from 46 Proposed Client Lot Selection at release.",
    "W5 shared candidate: a 22 consolidated quote snapshot object (instrument x timestamp, SIP NBBO). Until then 48 masters NBBO Midpoint "
    "At Receipt and NBBO Bid / Offer At Route as captured from the SIP feed licensed through 14 (22 holds no consolidated quote record).",
    "Breakpoint Basis Amount is mastered in 48 (no longer a Derived copy of 47, which masters no fund breakpoint): computed at order entry "
    "from the related Client Holdings (49) and the share class sales-charge terms, rights of accumulation and letter of intent (01; 17 for "
    "third-party funds). Correct the 48 brief section 5 and CW-098 wording at merge.",
    "Buying power: Derived copy of 49 Margin Balance Snapshot.Buying Power on the snapshot of Margin Snapshot Type Intraday, with its "
    "Margin Snapshot As-Of Timestamp (49 fix pass); cash accounts read Account Cash Balance of type cash available to invest. Lever 9 "
    "default stays 'copied value'.",
    "47 (merge): the 47 per-bond commission example (Per-Unit Charge USD 1.00 per bond) conflicts with the 48 default of riskless principal "
    "fixed income with markup disclosed (SME question 6); align the 47 example to the markup default or mark the per-bond row as the "
    "agency lever.",
    "enrich_48 overrides Client Trade Confirmation.Commission Fee Schedule to 47: the concept register row 'Fee Schedule / Fee Terms' (01) "
    "would otherwise resolve 'Fee Schedule'. The 47 object is 'Fee Schedule' (CLFEE-), not 'Client Fee Schedule' as the 48 brief and "
    "CW-098 say; correct them, and consider retiring or renaming the 01 register row at merge.",
    "Time in Force: 48 cites the 25 'Time in Force' list as External (identical FIX values); add 48 as a direct user if the list is shared "
    "at W5.",
    "49 Client Margin Call cites an order source 'Margin Liquidation': 48 Order Source now holds that value and 'Regulation SHO Close-Out'.",
    "Execution Venue Profile is a role profile keyed by 02 PTY-; the firm's own principal desk is the 02 party of its broker-dealer.",
    "W4: 38 Trade Surveillance Alert to reference Client Order and Client Execution (CW-100); 38 may share CAT Event Type.",
    "29 (W3): Fund Order on the brokerage omnibus account is referenced from Order Route.Resulting Fund Order, one per side per share class "
    "and dealing cycle unless netted (29 Side Netting Indicator); 29 should not keep a reverse list of 48 orders.",
]
