"""Consolidation proposals from the W3 draft of Data Domain 49 Clearing, Settlement & Client Asset Custody (wealth manager,
new domain, CW-007), 2026-10-14.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py and
shared_code_lists.py at the W3 merge. Formats follow CONTRACT.md in this folder. Decisions implemented: CW-006, CW-007, CW-011
(decisions.py) and CW-101 to CW-106, CW-112 to CW-115 (proposals_w3_brokerage.py, treated as accepted). New domain: no US-only
pass decision (CW-022) and no JURISDICTION entries.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES: none beyond the eight reserved in proposals_w3_brokerage.py (CLHLD-, CTLOT-, CLACT-, RESRV-, ACXF-, MGCL-,
# CSLN-, CLCAE-), with the key formats published there. The other 49 objects keep composite keys.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

KEY_FORMATS = [
    ("Possession or Control Determination", "Composite: <INS- id> / <business date> / <Deficit Source>, e.g. 'INS-00104477 / 2026-10-05 / Fail to Receive over 30 Days - 15c3-3(d)(3)' (one row per deficit and source; 'No Deficit' when none)",
     "Renamed from the brief's 'Possession or Control Position' (term ruling Position: used only in 06 Fund Shareholder Position). "
     "Rename the GRAIN_KEY_FORMATS row of proposals_w3_brokerage.py at merge."),
    ("Client Lot Relief", "Composite: <CTLOT- id> / <CLACT- id or RGTX- id>", "Widened from GRAIN_KEY_FORMATS (<CTLOT-> / <CLACT->): fund-only lots are relieved by a 29 Register Transaction (CW-141). Amend the row at merge."),
    ("Cost Basis Adjustment", "Composite: <CTLOT- id> / <adjustment sequence>, e.g. 'CTLOT-00418822173 / 3'", ""),
    ("Cost Basis Transfer Statement", "Composite: <ACXF- id> / <Transfer Statement Direction> / <statement version>, e.g. 'ACXF-2026-0045120 / Received / 1'", ""),
    ("Account Cash Balance", "Composite: <ACC- id> / <currency> / <balance type> / <balance basis> / <business date>, e.g. 'ACC-0049812 / USD / SWEEP_BALANCE / SETTLEMENT_DATE / 2026-10-05'", "Adds Balance Basis to GRAIN_KEY_FORMATS; amend at merge."),
    ("Street Settlement Obligation", "Composite: <LEN- id> / <Clearing Channel> / <INS- id> / <contractual settlement date>", "No prefix (brief section 6)."),
    ("Client Settlement Fail", "Composite: <CLACT- id> / <Fail Type>", ""),
    ("Reserve Computation Line", "As GRAIN_KEY_FORMATS: <RESRV- id> / <Exhibit A item>, e.g. 'RESRV-20260930-C / CREDIT-01'", ""),
    ("Control Location", "Composite: <PTY- id> / <effective from>, e.g. 'PTY-100211 / 2019-01-01'", "Reference examples carry both parts; enrich_49 forces them to 'mastered here' because they start with PTY-."),
    ("Margin Balance Snapshot", "Composite: <ACC- id> / <business date> / <Margin Snapshot Type> / <as-of timestamp>", "Adds type and timestamp so 48's Buying Power As-Of Timestamp resolves to a snapshot; amend GRAIN_KEY_FORMATS at merge."),
    ("Account Transfer Asset Line", "Composite: <ACXF- id> / <line sequence>", ""),
    ("Client Voluntary Election", "Composite: <CLCAE- id> / <CAE- id> / <option number> / <election received timestamp>", ""),
    ("Security Count", "Composite: <LEN- id> / <quarter> / <control location PTY- id> / <count date>", "Adds the count date to GRAIN_KEY_FORMATS; amend at merge."),
    ("Stock Record Reconciliation", "Composite: <Stock Record Reconciliation Type> / <business date> / <control location PTY- id or SWEEP- id for Program-Bank Sweep runs>", ""),
    ("Stock Record Break", "Composite: <Stock Record Reconciliation key> / <break sequence>", ""),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local 49 lists carrying an enterprise shared list's exact name and values (copied 2026-10-14).
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Holding View", "local": "Holding View",
     "value_map": {"Start of Day": "START_OF_DAY", "Intraday": "INTRADAY", "End of Day": "END_OF_DAY"},
     "new_values": [], "note": "Client Holding.Client Holding View (CW-101; brief section 8)."},
    {"shared": "Lot Relief Method", "local": "Lot Relief Method",
     "value_map": {"FIFO": "FIFO", "LIFO": "LIFO", "High Cost": "HIGH_COST", "Low Cost": "LOW_COST",
                   "Specific Lot Identification": "SPECIFIC_LOT_IDENTIFICATION", "Tax-Optimized": "TAX_OPTIMIZED",
                   "Average Cost": "AVERAGE_COST"},
     "new_values": [], "note": "Client Lot Relief.Relief Method Applied. The account election stays 15 Cost Basis Method."},
    {"shared": "Regulatory Trade Report Regime", "local": "Regulatory Trade Report Regime",
     "value_map": {"SEC Rule 10c-1a": "SEC_RULE_10C_1A"},
     "new_values": [], "note": "Subset. Loan Reporting Detail.Loan Reporting Regime (CW-105)."},
    {"shared": "Regulatory Report Status", "local": "Regulatory Report Status",
     "value_map": {"Pending": "PENDING", "Submitted": "SUBMITTED", "Accepted": "ACCEPTED", "Rejected": "REJECTED",
                   "Corrected": "CORRECTED", "Canceled": "CANCELED", "Not Required": "NOT_REQUIRED"},
     "new_values": [], "note": "Loan Reporting Detail.Loan Report Status. The local description of Not Required adds 'or reporting deferred'."},
    {"shared": "Reconciliation Status", "local": "Reconciliation Status",
     "value_map": {"Reconciled": "RECONCILED", "Reconciled within Tolerance": "RECONCILED_WITHIN_TOLERANCE",
                   "Break Open": "BREAK_OPEN", "Break Explained": "BREAK_EXPLAINED", "Not Reconciled": "NOT_RECONCILED"},
     "new_values": [], "note": "Stock Record Reconciliation.Stock Record Reconciliation Status (the run result; the per-row sweep status on Account Cash Balance was dropped). Stock Record Break uses the local Break Status lifecycle instead."},
    {"shared": "Collateral Type", "local": "Collateral Type",
     "value_map": {"Cash": "CASH", "US Treasury Securities": "US_TREASURY_SECURITIES", "Letters of Credit": "LETTERS_OF_CREDIT"},
     "new_values": [], "note": "Subset (Rule 15c3-3(b)(3) eligible collateral). Fully Paid Securities Loan.Loan Collateral Type."},
    {"shared": "Approval Status", "local": "Approval Status",
     "value_map": {"Not Required": "NOT_REQUIRED", "Pending": "PENDING", "Approved": "APPROVED",
                   "Approved with Conditions": "APPROVED_WITH_CONDITIONS", "Retrospectively Approved": "RETROSPECTIVELY_APPROVED",
                   "Rejected": "REJECTED", "Expired": "EXPIRED", "Withdrawn": "WITHDRAWN"},
     "new_values": [], "note": "Cost Basis Adjustment, Reserve Computation, Control Location approvals."},
    {"shared": "Case Status", "local": "Case Status",
     "value_map": {"New / Received": "NEW", "Pending Good Order": "PENDING_GOOD_ORDER", "In Progress": "IN_PROGRESS",
                   "Waiting on Client": "WAITING_ON_CLIENT", "Pending Third Party": "PENDING_THIRD_PARTY", "Escalated": "ESCALATED",
                   "Resolved / Completed": "RESOLVED", "Closed": "CLOSED", "Rejected": "REJECTED", "Canceled": "CANCELED"},
     "new_values": [], "note": "Client Settlement Fail.Fail Case Status."},
]
# Transfer Statement Direction (Sent, Received) stays local: shared Flow Direction means assets entering or leaving the firm,
# not the direction a tax document travels.
# Brief section 8 also named Message Standard, Flow Direction, Business Line and Record Status. The draft does not use them:
# the transfer statement format and activity flow direction were cut for size (Flow Direction is derivable from Activity Type),
# no 49 object carries a business line (the account's is 15 Account Business Line), and no 49 record has a registration status.

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: (local list name, likely users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Holding Period Term", ["49", "18", "46"],
     "Same name and labels in 18 and 46 (18 adds 'Not Applicable' for tax-exempt books). One list, steward 49 (client lots carry "
     "the reported term) or 18; IRC section 1222."),
    ("Cash Balance Type", ["49", "18"],
     "18 Cash Balance.Cash Balance Type describes fund portfolio cash; 49 client cash (free credit, Sweep Balance, margin debit). "
     "Keep NOT_MERGED: different books (CW-007); log under the Cash Balance term conflict."),
    ("Activity Type", ["49", "13", "06"],
     "13 statements and 06 Client Assets flows classify 49 postings; one list stewarded by 49 avoids remapping. 18 Portfolio "
     "Transaction Type stays separate."),
    ("Transfer Channel / Transfer Direction", ["49", "29", "15"],
     "29 Fund Share Transfer and 15 Account Closure use similar values; candidate pair with steward 49."),
    ("Margin Call Type / Margin Call Status", ["49", "26"],
     "26 fund-side Margin Call has its own lists for collateral agreements; keep NOT_MERGED (term conflict Margin Call)."),
    ("Form 1099-B Reporting Category", ["49", "13"],
     "13 produces Form 1099-B from 49 Client Lot Relief; 13 should cite this list."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (plan section 5.3 watchlist names and CW-113), decisions.TERM_CONFLICTS format
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Holding",
     "usages": [("49", "Client Holding (CLHLD-)", "Brokerage book of record at account grain."),
                ("18", "Portfolio Holding (HLD-)", "Fund and institutional portfolios."),
                ("06", "Fund Shareholder Position", "View of 49 for own share classes in brokerage accounts and of 29 for the rest."),
                ("29", "Share Register Balance", "Shares registered at the transfer agent; not a holding (CW-122).")],
     "recommendation": "Confirms the W0 entry; every 49 definition names Client Holding. 29 Share Register Balance (TA register, fund-only and omnibus accounts) is neither a Holding nor a Position (CW-122).", "decision": "CW-007"},
    {"term": "Position",
     "usages": [("06", "Fund Shareholder Position", "Primary sense."),
                ("49", "Possession or Control Determination", "Renamed from the brief's 'Possession or Control Position' to keep 'Position' for 06."),
                ("50", "Program Bank Daily Position", "Aggregate deposits per program bank; 49 reconciles to it."),
                ("43", "Cash Position", "Firm bank cash.")],
     "recommendation": "Extend the W0 entry with the 50 and 43 qualified uses; 49 uses no 'Position'.", "decision": "CW-007"},
    {"term": "Custody",
     "usages": [("49", "Client Asset Custody", "Rule 15c3-3 possession or control, control locations, counts."),
                ("28", "Fund Custody", "Funds' custodian and sub-custodian network.")],
     "recommendation": "Confirms the W0 entry. The source title 'Customer protection - reserves and custody of securities' is the rule's name.", "decision": "CW-007"},
    {"term": "Tax Lot",
     "usages": [("49", "Client Tax Lot (CTLOT-)", "Client account lots with covered status."), ("18", "Tax Lot (LOT-)", "Fund portfolio lots.")],
     "recommendation": "Always 'Client Tax Lot' outside 18; references typed Reference (Client Tax Lot, 49).", "decision": "CW-101"},
    {"term": "Transfer",
     "usages": [("49", "Account Transfer (ACXF-)", "ACATS and non-ACATS account transfers."), ("50", "Cash Transfer (Money Movement)", ""),
                ("29", "Fund Share Transfer", "Fund-only account transfers on the register.")],
     "recommendation": "Always qualify.", "decision": "CW-104"},
    {"term": "Sweep",
     "usages": [("49", "Sweep Balance (Account Cash Balance type)", "Account-level balance."), ("50", "Sweep Allocation; Sweep Program", ""),
                ("15", "Cash Sweep Election", "")],
     "recommendation": "Allocations sum to the balance (CW-102); row rule in enrich_49.", "decision": "CW-102"},
    {"term": "Settlement",
     "usages": [("49", "Street Settlement Obligation; Client Settlement Fail", ""), ("26", "Settlement Instruction; Settlement Fail", "Fund-side."),
                ("29", "Settlement Obligation", "Fund order settlement at the TA.")],
     "recommendation": "Always qualify; 49 'Street Settlement Obligation' is distinct from 29 'Settlement Obligation'.", "decision": "CW-113"},
    {"term": "Entitlement",
     "usages": [("49", "Client Corporate Action Entitlement (CLCAE-)", ""), ("28", "Corporate Action Entitlement (CAEN-)", "Fund safekeeping accounts."),
                ("14", "Data Entitlement", "")],
     "recommendation": "Always qualify.", "decision": "CW-106"},
    {"term": "Securities Loan",
     "usages": [("49", "Fully Paid Securities Loan (CSLN-)", "Client lends to the firm."), ("28", "Securities Loan (SBL-)", "Fund lending program.")],
     "recommendation": "Always qualify.", "decision": "CW-105"},
    {"term": "Margin Call",
     "usages": [("49", "Client Margin Call (MGCL-)", "Reg T, FINRA 4210."), ("26", "Margin Call (MCALL-)", "Collateral agreements of funds.")],
     "recommendation": "Always qualify.", "decision": "CW-105"},
    {"term": "Reserve",
     "usages": [("49", "Reserve Computation (RESRV-)", "Rule 15c3-3(e), Customer or PAB."), ("19", "Accounting reserves", "")],
     "recommendation": "Always qualify.", "decision": "CW-103"},
    {"term": "Cash Balance",
     "usages": [("49", "Account Cash Balance", "Client cash."), ("18", "Cash Balance", "Portfolio cash."), ("43", "Cash Position", "Firm cash.")],
     "recommendation": "Always qualify.", "decision": "CW-113"},
    {"term": "Reconciliation",
     "usages": [("49", "Stock Record Reconciliation", "Stock record to DTC, TA omnibus, bank custodian, OCC, program-bank sweep."),
                ("28", "Custody Reconciliation Run", "Fund custodian statements to 18.")],
     "recommendation": "Always qualify (plan section 4: a reconciliation between books is owned by the domain the brief names). 49 owns the 49-to-29 omnibus reconciliation and references both sides.", "decision": "CW-122"},
    {"term": "Transaction",
     "usages": [("06", "Transaction (TXN-)", "Wholesale flow record, re-pointed at W4."),
                ("29", "Register Transaction (RGTX-)", "Share movement on the TA register; opens or relieves fund-only Client Tax Lots."),
                ("49", "Client Account Activity (CLACT-)", "Posting to a brokerage account.")],
     "recommendation": "Bare 'Transaction' is not used in 49; brokerage postings are Client Account Activity.", "decision": "CW-122"},
    {"term": "Balance",
     "usages": [("16", "Participant Balance", "Recordkept plan balances by money source."),
                ("29", "Share Register Balance", "TA register shares."),
                ("49", "Account Cash Balance (including Sweep Balance); Margin Balance Snapshot", "Brokerage cash and margin."),
                ("50", "Sweep Allocation", "Per-program-bank split of the 49 Sweep Balance.")],
     "recommendation": "Always qualify; 16 participant balances stay 16 (49 SME question 9).", "decision": "CW-102"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION: new domain, nothing removed (CW-022). The UK and EU concepts left out are listed in Source_Notes section 2.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = []

# 6. DECISIONS: none (new domain; the 49 decisions are CW-101 to CW-106 and CW-112 to CW-115 in proposals_w3_brokerage.py).
DECISIONS = []

# ---------------------------------------------------------------------------------------------------------------------
# 7. NOTES for the W3 merge
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Size (after the 2026-10-15 fix pass): 9 families, 26 objects (23 BO, 3 AG), 285 attributes, 96 CDEs (34%), 46 code lists "
    "(38 local, 8 copies of shared lists), 61 relationships, 24 sources. Ownership: 55 references, 2 derived copies, 5 overrides, 8 row ownership rules, 0 unresolved.",
    "CONCEPT_OWNERSHIP rows to add (owner 49): Client Holding (CLHLD-), Client Tax Lot (CTLOT-), Client Account Activity (CLACT-), "
    "Reserve Computation (RESRV-), Account Transfer (ACXF-), Client Margin Call (MGCL-), Fully Paid Securities Loan (CSLN-), Client "
    "Corporate Action Entitlement (CLCAE-), Cost Basis Transfer Statement, Control Location, Stock Record Reconciliation. Consider "
    "ALIASES 'client holding', 'client tax lot', 'client account activity', 'account transfer' -> 49 (proposals_w3_brokerage NOTES).",
    "Rename at merge: GRAIN_KEY_FORMATS 'Possession or Control Position' -> 'Possession or Control Determination' (term ruling Position).",
    "Re-keys for siblings (CW-114): 15 Account Closure.Closing Account Transfer example CAX-2026-0045120 -> ACXF-2026-0045120; 43 "
    "Capital Requirement Calculation.Reserve Computation type Reference (Customer Reserve Computation, 49) -> Reference (Reserve "
    "Computation, 49), example RSV-20260930-01 -> RESRV-20260930-C; 46 Harvest Client Tax Lots and Selected Client Tax Lot examples "
    "CLT- -> CTLOT-; 47 Excluded Client Holding example CHL- -> CLHLD-, Debit Posting and Credit Posting CAA- -> CLACT-; 51 Source "
    "Account Activity, 13 Resulting Client Account Activity and 08 Complaint.Related Transaction CAA- -> CLACT-; 13 Service "
    "Request.Resulting Client Account Activity example CLACT-2026-000418273 has the wrong format -> CLACT-20261005-0004188221. "
    "43: both the data type 'Customer Reserve Computation' and the RSV- example change (CW-103).",
    "Derived copies that siblings take from 49 and the 49 attribute each copies: 15 RMD Record.Prior Year-End Value <- Client Holding "
    "Valuation.Market Value (December 31); 46 Account Market Value and Actual Weight <- Market Value; 46 Realized Net Gain to Date and "
    "Realized Short-Term Gain to Date <- Client Lot Relief.Realized Gain or Loss by Holding Period Term; 46 Unrealized Loss at Scan <- "
    "Unrealized Gain or Loss (or Client Tax Lot.Adjusted Cost Basis and the price); 46 Available Cash Used <- Account Cash Balance.Cash "
    "Balance Amount (type Cash Available to Invest); 45 Firm Assets Assigned to Goal, 47 Account Valuation and Excluded Amount, 51 "
    "Closing Market Value <- Market Value; 51 Client Holding Valuation Date <- Valuation Date; 13 Issuer Proxy Pass-Through.Record Date Entitled Quantity <- "
    "Client Corporate Action Entitlement.Record Date Client Holding Quantity (CW-090; 13 keeps its name); 43 Aggregate Debit Items Amount <- Reserve "
    "Computation.Aggregate Debit Items Amount (Customer row); 48 Buying Power At Entry and Buying Power As-Of Timestamp <- Margin Balance Snapshot.Buying Power and Margin Snapshot As-Of Timestamp (margin accounts) or Account Cash Balance of type Cash Available to Invest (cash accounts).",
    "15 Margin Account Detail: 49 reads the Intraday Margin Requirement Basis from 15 Account (CW-915). The 15 review (finding on "
    "Pattern Day Trader Indicator) applies: 49 models only the intraday margin standard of FINRA Rule 4210 as amended (Regulatory "
    "Notice 26-10, effective June 4, 2026, phase-in to October 20, 2027).",
    "Brief size note: the brief says 27 objects but its table lists 26; the draft has the 26. Local lists: 38 against the brief's "
    "26 to 32 (lifecycle statuses are kept apart from types and reasons, as brief section 13 asks).",
    "Shared list members to register at W5: 49 joins Holding View and Lot Relief Method (steward 18), Regulatory Trade Report Regime "
    "(steward 26, value SEC_RULE_10C_1A), Regulatory Report Status (28), Reconciliation Status (06), Collateral Type (26), Approval "
    "Status and Case Status (09). Market Data Subscriber Status is not used (CW-112).",
    "Fix pass 2026-10-15 (49 review, program-lead rulings): before 274 attributes, 92 CDEs, 50 references, 3 overrides, 3 row "
    "rules, 43 lists; after 285 attributes, 96 CDEs (34%), 55 references, 5 overrides, 8 row rules, 46 lists (38 local, 8 shared copies).",
    "For 48's fix pass (ruling 3 as corrected, CW-098): 49 Client Account Activity.Source Client Allocation references the 48 Client "
    "Allocation; 48 drops Client Allocation.Booked Client Account Activity and its REL 'is booked as Client Account Activity [49]' "
    "(or turns it into an inverse note). The 49 key example for Client Allocation is the GRAIN_KEY_FORMATS form 'CLBLK- / ACC-'.",
    "Fund-only lots (CW-034, CW-122, CW-141): Client Tax Lot.Acquisition Register Transaction and Client Lot Relief.Closing Register "
    "Transaction reference 29 RGTX-; row rules in enrich_49. 29 REL 'Register Transaction opens or relieves Client Tax Lot [49]' now "
    "has its attributes on the 49 side.",
    "Own-fund omnibus (CW-097, CW-122): Street Settlement Obligation.Own-Fund Settlement Obligation references 29 Settlement "
    "Obligation and carries no amounts on own-fund rows; Stock Record Reconciliation.Reconciled Register Balances references 29 Share "
    "Register Balance (forced to 29 in enrich_49 because the key starts with ACC-).",
    "15 Cost Basis Method -> 49 Lot Relief Method mapping (NOT_MERGED pair): Average Cost -> Average Cost; FIFO, LIFO, High Cost, Low "
    "Cost, Specific Lot Identification -> same; Loss / Gain Utilization -> Tax-Optimized. Record with the shared-list registration at W5.",
]
