"""Consolidation proposals from the W3 draft of Data Domain 50 Money Movement, Cash & Sweep (wealth manager, new domain,
CW-016), 2026-10-14.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py and
shared_code_lists.py at the W3 merge. Formats follow CONTRACT.md in this folder. Decisions implemented: CW-016
(decisions.py), CW-021, CW-025, CW-026, CW-030, CW-031, CW-033 (proposals_wealth_w1.py), CW-071, CW-089, CW-092 (W2) and
CW-102, CW-107 to CW-111, CW-113 to CW-115 (proposals_w3_brokerage.py, treated as accepted). New domain: no US-only pass
decision (CW-022) and no JURISDICTION entries.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES (prefix, entity, owner domain, status, note) - decisions.PREFIXES format
# None beyond the six reserved in proposals_w3_brokerage.py (MMVMT-, MMHLD-, MMALT-, SWEEP-, PGBNK-, DCARD-), with the key
# formats published there. Every other 50 object keeps a composite key (KEY_FORMATS below).
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

KEY_FORMATS = [  # composite keys used as examples (GRAIN_KEY_FORMATS candidates beyond those in proposals_w3_brokerage.py)
    ("Bank Account Verification Event", "50", "<ABI- id> / <attempt number>", "ABI-00114410 / 1"),
    ("Money Movement Event", "50", "<MMVMT- id> / <event sequence>", "MMVMT-2026-00418273 / 3"),
    ("Money Movement Exception", "50", "<MMVMT- id> / <exception sequence>", "MMVMT-2026-00418273 / 1"),
    ("Fraud Risk Assessment", "50", "<MMVMT- id> / <assessment timestamp>", "MMVMT-2026-00418273 / 2026-10-05T14:01:57-04:00"),
    ("Payment Sanctions Screening", "50", "<MMVMT- id> / <screening timestamp>", "MMVMT-2026-00418273 / 2026-10-05T14:01:58-04:00"),
    ("Sweep Rate Tier", "50", "<SWEEP- id> / <rate tier basis> / <lower bound> / <effective from>", "SWEEP-0004 / HOUSEHOLD_ASSETS / 1000000 / 2026-09-18"),
    ("Sweep Run", "50", "<SWEEP- id> / <business date> / <cycle>", "SWEEP-0004 / 2026-10-05 / 1"),
    ("Program Bank Daily Total", "50", "<SWEEP- id> / <PGBNK- id> / <business date>", "SWEEP-0004 / PGBNK-0012 / 2026-10-05"),
    ("Card Dispute", "50", "<MMVMT- id> / <error notice date>", "MMVMT-2026-00418555 / 2026-10-09"),
    ("Client Cash Forecast", "50", "Client cash <as-of date> v<version> (as 43 Cash Forecast)", "Client cash 2026-10-05 v1"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local 50 lists carrying an enterprise shared list's exact name and values (copied 2026-10-14).
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Flow Direction", "local": "Flow Direction",
     "value_map": {"Inflow": "INFLOW", "Outflow": "OUTFLOW"},
     "new_values": [], "note": "Subset (no Neutral); shared descriptions kept. Money Movement.Movement Direction is read relative to the movement account (stated in the attribute definition)."},
    {"shared": "Message Standard", "local": "Message Standard",
     "value_map": {"ISO 20022 pacs": "ISO_20022_PACS", "ISO 20022 camt": "ISO_20022_CAMT", "Proprietary": "PROPRIETARY",
                   "NACHA ACH File Format": None, "ANSI X9 Image Exchange": None, "ISO 8583": None},
     "new_values": [("NACHA_ACH", "NACHA ACH File Format", "NACHA Operating Rules file format"),
                    ("ANSI_X9_IMAGE", "ANSI X9 Image Exchange", "X9.100-187 check image exchange (Check 21)"),
                    ("ISO_8583", "ISO 8583", "Card authorization and clearing messages")],
     "note": "Money Movement.Rail Message Standard. Three new values proposed to steward 06, and a request to widen the ISO_20022_PACS description (now 'Interbank payments (pacs.009) for cash-only settlements', copied as is) to cover pacs.008 customer credit transfers and pacs.004 returns."},
    {"shared": "Screening Result", "local": "Screening Result",
     "value_map": {"No Match": "NO_MATCH", "Potential Match - Under Review": "POTENTIAL_MATCH", "False Positive": "FALSE_POSITIVE",
                   "Confirmed Match": "CONFIRMED_MATCH"},
     "new_values": [], "note": "Payment Sanctions Screening.Screening Result (match question only; the action is Sanctions Screening Disposition)."},
    {"shared": "Severity", "local": "Severity",
     "value_map": {"Low": "LOW", "Medium": "MEDIUM", "High": "HIGH", "Critical": "CRITICAL"},
     "new_values": [], "note": "Money Movement Monitoring Alert.Alert Priority."},
    {"shared": "Case Status", "local": "Case Status",
     "value_map": {"New / Received": "NEW", "In Progress": "IN_PROGRESS", "Waiting on Client": "WAITING_ON_CLIENT",
                   "Pending Third Party": "PENDING_THIRD_PARTY", "Escalated": "ESCALATED", "Resolved / Completed": "RESOLVED",
                   "Closed": "CLOSED", "Canceled": "CANCELED"},
     "new_values": [], "note": "Subset. Money Movement Exception.Exception Status, Monitoring Alert.Alert Status, Card Dispute.Dispute Status."},
    {"shared": "Business Line", "local": "Business Line",
     "value_map": {"DB": "DB", "DA": "DA", "HA": "HA", "PF": "PF", "WR": "WR", "IA": "IA", "IC": "IC", "TR": "TR"},
     "new_values": [], "note": "CW-004 values. Sweep Program.Eligible Business Lines."},
    {"shared": "Record Status", "local": "Record Status",
     "value_map": {"Proposed": "PROPOSED", "Active": "ACTIVE", "Paused": "PAUSED", "Inactive": "INACTIVE", "Retired": "RETIRED"},
     "new_values": [], "note": "Subset. Sweep Program.Program Status."},
    {"shared": "Approval Status", "local": "Approval Status",
     "value_map": {"Not Required": "NOT_REQUIRED", "Pending": "PENDING", "Approved": "APPROVED",
                   "Approved with Conditions": "APPROVED_WITH_CONDITIONS", "Rejected": "REJECTED", "Withdrawn": "WITHDRAWN"},
     "new_values": [], "note": "Subset. Internal Transfer Detail.Journal Approval Status, Program Bank.Bank Approval Status, Client Cash Forecast.Forecast Approval Status."},
    {"shared": "Data Basis", "local": "Data Basis",
     "value_map": {"Reported / Actual": "REPORTED", "Estimated": "ESTIMATED", "Modeled": "MODELED"},
     "new_values": [], "note": "Subset. Client Cash Forecast Line.Line Data Basis."},
]
# Not joined (record under NOT_MERGED): Outgoing Payment Status (steward 19) vs 50 Money Movement Status - a money movement can
# be incoming, and 50 needs On Hold, Returned and Pending Review. Frequency (09) is not used: schedules are 15 standing
# instructions.

NOT_MERGED = [
    ("50", "Money Movement Status", "19", "Outgoing Payment Status",
     "Different scope: 50 covers incoming and outgoing client payments with hold, review and return states; 19 covers the firm's outgoing payments."),
    ("50", "Payment Rail", "29", "Order Payment Method",
     "29 lists how a fund-side payment is made (including NSCC settlement); 50 lists client payment rails. Kept apart, mapped in LIST_MAPS."),
]

# Value maps between kept-apart lists (29 Cash Movement keeps Payment Method, content_29 line 162; mapped now, not at W5).
LIST_MAPS = [
    {"from": ("50", "Payment Rail"), "to": ("29", "Order Payment Method"),
     "value_map": {"ACH": "ACH", "Fedwire Funds": "Fedwire", "International Wire": "Fedwire", "Check": "Check",
                   "Internal Journal": "Internal Book Transfer", "Debit Card Network": None, "Bill Pay Service": None},
     "note": "International wires leave through the correspondent by Fedwire; card and bill pay never settle fund-side payments. 29 NSCC Settlement Payment has no 50 equivalent."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: (local list name, likely users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Monitoring Alert Disposition", ["29", "50", "38"],
     "Copied from 29 with the same name, values and meaning (brief section 8). One list for every financial-crime alert; steward 38 "
     "(AML program) or 29. 38 Trade Surveillance Alert may join."),
    ("Money Movement Monitoring Scenario", ["50", "29"],
     "Overlaps 29 Monitoring Scenario (structuring, third-party payment, high-risk jurisdiction, dormant reactivation, manual referral). "
     "Named apart because the 29 list carries TA-only values (redemption patterns, cash-equivalent purchases). Candidate: one "
     "'Financial Crime Monitoring Scenario' list with a channel attribute, steward 38."),
    ("Client Cash Flow Category", ["50", "43"],
     "Brief section 8 asked to align with 43 Cash Flow Category; the 43 values are firm-cash categories (fee receipts, payroll, seed) "
     "with no client flow, so a same-name local list would conflict. Proposed as a child list (or a 'Client Cash' branch) of 43's list."),
    ("Bank Charter Type", ["50", "43", "02"],
     "Charter class of a bank party, now a Derived copy (02) on 50 Program Bank. Proposed attribute and list of the 02 Organization "
     "(bank party), steward 02; 43 Bank Relationship Profile could read it."),
    ("Payment Rail", ["50", "19", "29", "43"],
     "Rail vocabulary (ACH, Fedwire, check, card) recurs in 19 supplier payments, 29 order payment method and 43 bank statements; "
     "candidate enterprise 'Payment Method' list, steward 43."),
    ("FDIC Ownership Category", ["50", "51", "15"],
     "12 CFR Part 330 categories; 51 trusts and 15 registration types map to them. Steward 50."),
    ("NACHA Return Reason Code / NACHA Change Code", ["50", "29", "19"],
     "External NACHA lists; 29 direct-investor ACH and 19 supplier payments would cite the same codes. Register as External (NACHA)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (plan section 5.3 watchlist names and CW-113), decisions.TERM_CONFLICTS format
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Transfer",
     "usages": [("50", "Money Movement (Cash Transfer)", "ACH, wire, check, card and internal cash movements of client accounts."),
                ("49", "Account Transfer (ACXF-)", "ACATS and non-ACATS transfer of an account's assets between firms."),
                ("29", "Fund Share Transfer", "Transfer of fund shares between registrations.")],
     "recommendation": "Confirm the existing 'Transfer (wealth model)' entry: 50 uses 'Money Movement' and, in text, 'Cash Transfer'; Internal Transfer Detail is a cash journal, never an Account Transfer.",
     "resolution": "No unqualified primary sense; 'Money Movement' or 'Cash Transfer' (50).", "status": "SME", "decision": "CW-113"},
    {"term": "Sweep",
     "usages": [("50", "Sweep Program (SWEEP-); Sweep Run; Sweep Allocation", "The program, the daily run and per-bank allocations."),
                ("49", "Account Cash Balance (balance type Sweep Balance)", "Account-level swept cash, the book of record."),
                ("15", "Cash Sweep Election", "The client's election.")],
     "recommendation": "Confirm the existing Sweep entry with the 50 names; the sum of Sweep Allocations equals the 49 Sweep Balance (CW-102).",
     "resolution": "Primary sense: 50 sweep program and allocation.", "status": "SME", "decision": "CW-102"},
    {"term": "Allocation",
     "usages": [("50", "Sweep Allocation", "Account x program bank x business date."),
                ("48", "Client Allocation", "Block order allocation to accounts."),
                ("25", "Trade Allocation (ALLOC-)", "Fund trade allocation.")],
     "recommendation": "Always qualify: 'Sweep Allocation' (50), 'Client Allocation' (48), 'Trade Allocation' (25).", "decision": "CW-113"},
    {"term": "Program",
     "usages": [("50", "Sweep Program (SWEEP-)", "Cash sweep program of the broker-dealer."),
                ("01", "Service Offering (OFFR-)", "Advisory program offered."),
                ("15", "Program Enrollment (ENRL-)", "An account's enrollment in an advisory program."),
                ("38", "AML program", "The firm's AML compliance program (FINRA Rule 3310).")],
     "recommendation": "Extend the Program entry: 'Sweep Program' is always qualified; bare 'program' never names a 50 object."},
    {"term": "Hold",
     "usages": [("50", "Money Movement Hold (MMHLD-)", "Hold on one money movement (funds availability, fraud, Rule 2165, legal, AML, sanctions)."),
                ("15", "Account Restriction (ARX-)", "Hold on securities transactions or the whole account."),
                ("39", "Legal Hold (LHOLD-)", "Records preservation hold.")],
     "recommendation": "Never bare 'Hold': 'Money Movement Hold' (50), 'Account Restriction' (15), 'Legal Hold' (39). 08 re-points MMH- to MMHLD-.",
     "resolution": "Primary sense: 39 Legal Hold (existing entry); 50 and 15 qualified.", "status": "Resolved", "decision": "CW-109"},
    {"term": "Distribution",
     "usages": [("50", "Money Movement Type 'Retirement Distribution' / 'Trust Distribution'", "The payment of a distribution."),
                ("16", "Distribution Request (DIST-)", "Plan distribution paid on the recordkeeper's rail."),
                ("51", "Trust Distribution Request (TDRQ-)", "Approval of a discretionary trust distribution."),
                ("01", "Share Class (Distribution Policy list)", "Fund income distribution policy of a share class.")],
     "recommendation": "Extend the Distribution entry: 50 masters only the payment; the decision is 16 or 51."},
    {"term": "Cash",
     "usages": [("50", "Money Movement; Sweep Allocation", "Movement of client cash and its program-bank allocation."),
                ("49", "Account Cash Balance", "Client cash balances, the book of record."),
                ("43", "Cash Position; Corporate Bank Account", "Firm cash."),
                ("29", "Cash Movement", "Fund-side settlement cash."),
                ("18", "Cash Balance", "Portfolio cash.")],
     "recommendation": "Always qualify by owner: client cash moved (50), client cash booked (49), firm cash (43), fund settlement cash (29), portfolio cash (18).", "decision": "CW-102"},
    {"term": "Payment",
     "usages": [("50", "Money Movement", "Client payment."),
                ("19", "Supplier Payment", "Firm accounts payable payment."),
                ("29", "Cash Movement", "Fund settlement payment.")],
     "recommendation": "Bare 'payment' is not an object name in 50; 'Money Movement' (50), 'Supplier Payment' (19), 'Cash Movement' (29)."},
    {"term": "Position",
     "usages": [("50", "Program Bank Daily Total (formerly Program Bank Daily Position)", "Aggregate customer deposits of one program at one program bank for a business date."),
                ("43", "Cash Position", "Firm cash by entity and bank."),
                ("06", "Fund Shareholder Position", "Fund units held by an account.")],
     "recommendation": "Renamed in the fix pass: the 50 object is 'Program Bank Daily Total' (program x bank x date); 50 uses 'Position' nowhere. 49 (content_49 Stock Record Reconciliation text) and 10 should use the new name."},
    {"term": "Verification",
     "usages": [("50", "Bank Account Verification Event", "Proof that a 15 bank instruction's external account exists and belongs to the client."),
                ("02", "Identity Verification (KYCV-)", "CIP verification of a party's identity."),
                ("15", "Bank Instruction (Bank Verification Status)", "Current verification state of the bank instruction.")],
     "recommendation": "Always qualify: 'Bank Account Verification' (50; lists are 15's Bank Verification Method and Status), 'Identity Verification' (02). 50 no longer holds lists named Verification Method or Verification Result (02 holds the CIP lists of those names).",
     "decision": "CW-025"},
    {"term": "Return",
     "usages": [("50", "Money Movement Return (ACH Return Type, NACHA Return Reason Code)", "A returned ACH entry, wire or check."),
                ("01", "Return Type", "Price, net or gross total return of a fund."),
                ("32", "Performance Return", "Computed investment return.")],
     "recommendation": "Always qualify: 'Money Movement Return' (50), 'Performance Return' (32); the 50 list is 'ACH Return Type', not 'Return Type' (01)."},
    {"term": "Alert",
     "usages": [("50", "Money Movement Monitoring Alert (MMALT-)", "AML and fraud alert on money movements."),
                ("29", "Account Monitoring Alert (AMA-)", "Alert on fund-only transfer agent activity."),
                ("08", "Sales Practice Alert", "Retail conduct surveillance alert."),
                ("38", "Trade Surveillance Alert", "Market conduct surveillance alert.")],
     "recommendation": "Never bare 'Alert': qualify by what is monitored. Monitoring Alert Disposition is a shared candidate across 29, 50 and 38.",
     "decision": "CW-110"},
    {"term": "Card Transaction",
     "usages": [("50", "Card Transaction Detail", "Client debit card transaction (attribute group of Money Movement)."),
                ("44", "Card Transaction", "Firm corporate card transaction.")],
     "recommendation": "CONCEPT_OWNERSHIP 'Card Transaction' resolves to 44; 50 keeps 'Card Transaction Detail' and never references bare 'Card Transaction'."},
    {"term": "Cash Forecast",
     "usages": [("50", "Client Cash Forecast", "Projection of client cash flows by sweep program."),
                ("43", "Cash Forecast", "Firm liquidity forecast.")],
     "recommendation": "Bare 'Cash Forecast' is 43; 50 is always 'Client Cash Forecast' and feeds 43."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION: new domain, nothing removed (CW-022). Left-out UK and EU concepts are listed in Source_Notes section 3.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = []

# 6. DECISIONS: none (new domain; the 50 decisions are CW-016 and CW-102, CW-107 to CW-111, CW-113 to CW-115).
DECISIONS = []

# ---------------------------------------------------------------------------------------------------------------------
# 7. NOTES for the W3 merge
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Size after the review fix pass (2026-10-15): 8 families, 26 objects (21 BO, 5 AG), 250 attributes, 82 CDEs (33%), 42 code "
    "lists (33 local, 9 copies of shared lists), 47 relationships, 21 sources. Ownership: 50 references, 3 derived copies, 2 "
    "overrides, 5 row ownership rules, 0 unresolved. Before the pass: 250 attributes, 77 CDEs, 54 references, 1 derived, 43 lists.",
    "Brief count: section 5 says '26 objects (19 BO, 7 AG)' but its own table lists 21 BO and 5 AG (the five rail detail groups "
    "ACH, Wire, Check, Internal Transfer and Card Transaction). The draft follows the table.",
    "Link direction (program-lead ruling, fix pass): neighbors reference the Money Movement; 50 references only its own inputs "
    "and the 02, 15 and 43 masters. Dropped from 50: Money Movement.Posting Activity, Money Movement Return.Return Posting "
    "Activity, Sweep Allocation.Interest Posting Activity (49 Client Account Activity.Source Money Movement holds the link), "
    "Source Service Request and Source Escheatment Report (13 Service Request.Resulting Money Movement and Escheatment "
    "Report.Remittance Money Movement hold them; 13 Remediation.Remediation Money Movement likewise). The REL rows remain with "
    "a note naming the side that holds each link. Kept on the 50 side: 15 SIN-, 46 CSHI-, 47 FDBT-, 51 TDRQ-, 04 Promotion "
    "Enrollment, 16 DIST-, 02 DTHN-.",
    "List renames in the fix pass (W5 name clashes): Return Type -> ACH Return Type (01 Return Type); Hold Status -> Money "
    "Movement Hold Status (39); Card Status -> Debit Card Status (44). Verification Method and Verification Result dropped: "
    "Bank Account Verification Event cites 'External (15 Bank Verification Method)' and 'External (15 Bank Verification "
    "Status)' so the 15 row rule runs on one vocabulary. New local list: Primary Purpose Exception Basis (12 CFR 337.6).",
    "CONCEPT_OWNERSHIP rows to add (owner 50): Money Movement (MMVMT-; already in proposals_w3_brokerage NOTES), Money Movement Hold "
    "(MMHLD-), Money Movement Monitoring Alert (MMALT-), Sweep Program (SWEEP-), Program Bank (PGBNK-), Program Bank Participation, "
    "Sweep Allocation, Program Bank Daily Total, FDIC Coverage Assessment, Debit Card (DCARD-), Client Cash Forecast. Consider "
    "ownership.ALIASES 'money movement' -> 50 and 'sweep program' -> 50 at W5.",
    "Object names other domains reference, as written: 'Money Movement' (15, 13, 29, 46, 47, 49, 51, 04, 16), 'Money Movement Hold' "
    "(02, 08, 15 REL), 'Program Bank' and 'Sweep Program' (15 Cash Sweep Election, 49). 49 should rename its mention of 'Program "
    "Bank Daily Position' (Stock Record Reconciliation text) to 'Program Bank Daily Total', now keyed per program and bank.",
    "Example re-keys still owed in other modules (CW-114): 15 SWP-0004, PBK-0012, PBK-0019, MMT-2024-00318273, MMT-2026-00418273; "
    "08 Senior Investor Case Action.Disbursement Hold MMH-2026-0004412 -> MMHLD-2026-000412 (6-digit sequence). 15 Account "
    "Restriction.Source Vulnerability Concern example 'PTY-500771 / 2026-03-02' should read VCON-2026-000217. (04 no longer holds "
    "an Award Money Movement: the link is on the 50 side, Source Promotion Enrollment.)",
    "For 15: Sweep Vehicle Type and 50 Sweep Program Type now share labels (Bank Deposit Sweep Program, Money Market Fund Sweep; 15 "
    "keeps Free Credit Balance). Cash Sweep Election.Elected Sweep Fund must be one of 50 Sweep Program.Eligible Sweep Funds "
    "(row rule in enrich_50). 15 Bank Verification Status and Method are set from the latest 50 Bank Account Verification Event.",
    "Overrides in enrich_50: ACH Entry Detail.Account Validation Event (composite key starts with ABI-, forced mastered here); "
    "Sweep Allocation.Reconciled Sweep Balance (49 Account Cash Balance composite key starts with ACC-, forced 49). Derived copies: "
    "Fraud Risk Assessment.Account Age Days (15, as of Assessment Timestamp); Program Bank.FDIC Certificate Number and Bank Charter "
    "Type (02 bank party).",
    "W4 for 38: AML Case gains 'Source Money Movement Monitoring Alert' typed Reference (Money Movement Monitoring Alert, 50) "
    "(CW-110), and AML Case Source a value 'Money Movement Monitoring Alert (50)'; AML and Sanctions Report should accept blocked "
    "and rejected transaction reports without an AML case (50 Payment Sanctions Screening.Blocked or Rejected Report has no example "
    "because the 38 key is '<AML case number>|<sequence>'). Alerts with scenario Elder Exploitation Pattern are special category "
    "(CD-344); 38 reads them through the restricted view.",
    "29 (CW-107) is done on the 29 side: Cash Movement.Client Money Movement typed Reference (Money Movement, 50). Checkwriting on "
    "own money market funds: 50 Check Detail.Redeeming Fund Order references the 29 redemption that honors a presented draft; 29 "
    "should confirm the fund order source value for checkwriting redemptions.",
    "For 47 at the W3 merge: 47 REL 'Fee Invoice is paid by Money Movement [50]' covers an institutional invoice paid into a firm "
    "account, which is not a client-account movement; 50 has no source for it. Proposed: 19/43 receipt, or re-point the 47 row "
    "to Fee Debit only.",
    "W5 for 02: register an 'FDIC Certificate Number' Party Identifier scheme and a bank charter class on the bank Organization; 50 "
    "Program Bank keeps both as Derived copies (02). Party Role Type gains 'Program Bank' (the role whose profile is 50 Program Bank).",
    "For 10 at W4: Program Bank Participation.Bank Rate Formula, Program Bank Daily Total.Interest Paid by Bank and Sweep Rate "
    "Tier.Client Interest Rate are the inputs of sweep program economics (CW-108).",
    "For 13: card statements, Regulation E notices, the 15c3-3(j)(2)(ii)(D) change notice and the (j)(1) and (j)(2)(ii)(C) "
    "statement notices are 13 deliveries; 50 keeps the dispute and the program change dates only.",
    "Regulatory status to confirm (Source_Notes section 5): SEC action on SR-FINRA-2026-018 (Rule 2165 up to 145 business days; "
    "Rule 2166 delay up to 10 business days as filed); final status of the FDIC custodial deposit account recordkeeping proposal "
    "(RIN 3064-AG07; it exempts broker-dealer custodial accounts); primary purpose exception basis values under the 2020 rule "
    "(12 CFR 337.6); whether the broker-dealer is a Regulation E financial institution for brokerage-account transfers and how "
    "far Reg E reaches ACH on brokerage accounts (CFPB 2025 proposed interpretive rule, status unverified).",
]
