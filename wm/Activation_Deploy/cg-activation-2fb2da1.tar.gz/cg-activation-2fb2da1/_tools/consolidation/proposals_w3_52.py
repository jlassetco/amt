"""Consolidation proposals from the W3 draft of Data Domain 52 External Manager & Sub-Adviser Oversight (wealth manager, new
domain, CW-014), 2026-10-14.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py and
shared_code_lists.py at the W3 merge. Formats follow CONTRACT.md in this folder. Decisions implemented: CW-014, CW-023
(proposals_wealth_w0.py, proposals_wealth_w1.py), CW-037, CW-038, CW-116 to CW-121 and CW-130 (proposals_w3_oversight.py,
treated as accepted), and the program-lead rulings on the 52 review (00_Program/Rework/Reviews/52_review.md, fix pass
2026-10-15), including the proposed amendment CW-119-AM1 below. New domain: no US-only pass decision (CW-022) and no JURISDICTION entries.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES: none beyond the eight reserved in proposals_w3_oversight.py (EMSTR-, MSRCH-, MDILG-, SADV-, GDLN-, OVRVW-,
# OVFND-, TPDUE-), with the formats published there (PREFIX_FORMATS). Composite keys follow GRAIN_KEY_FORMATS there; the
# additions below cover the objects that list does not name.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

KEY_FORMATS = [
    ("Due Diligence Questionnaire Template", "Composite: firm template code / version, e.g. 'INV_DDQ / 3'",
     "Template codes avoid the DDQ- token (registered 08 prefix, moving to 05 at W4)."),
    ("Search Outcome", "Attribute group of Manager Search (MSRCH-).", ""),
    ("Onsite Visit", "Composite: MDILG- / visit date, e.g. 'MDILG-2026-00418 / 2026-07-22'", "Business object since the fix pass."),
    ("Background Check Result", "Composite: Manager Key Person key / check type / check date", "Business object since the fix pass; PII restricted."),
    ("Manager-of-Managers Hire Condition", "Attribute group of Sub-Adviser Engagement (SADV-).", ""),
    ("Sub-Adviser Compliance Certification", "Composite: manager PTY- / SADV- (quarterly guideline rows only) / certification type / period end",
     "Replaces the GRAIN_KEY_FORMATS row in proposals_w3_oversight.py (SADV- / type / period end): firm-level certifications are stored once per manager."),
    ("Oversight Metric Threshold", "Composite: SADV- / metric code / effective from, e.g. 'SADV-00412 / EXCESS_RETURN_3Y / 2026-11-02'", "New in the fix pass."),
    ("Fund of Funds Use Detail", "Composite: TPDUE- / acquiring fund PRD-, e.g. 'TPDUE-2026-000412 / PRD-01120'", "Business object; one row per acquiring fund (REL 1 : 0..n)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local 52 lists carrying an enterprise shared list's exact name and values (copied 2026-10-14).
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Record Status", "local": "Record Status",
     "value_map": {"Draft": "DRAFT", "Proposed": "PROPOSED", "Pending": "PENDING", "Active": "ACTIVE", "Paused": "PAUSED",
                   "Inactive": "INACTIVE", "Deprecated": "DEPRECATED", "Retired": "RETIRED"},
     "new_values": [], "note": "Due Diligence Questionnaire Template.Template Status."},
    {"shared": "Severity", "local": "Severity",
     "value_map": {"Low": "LOW", "Medium": "MEDIUM", "High": "HIGH", "Critical": "CRITICAL"},
     "new_values": [], "note": "Oversight Finding.Finding Severity."},
    {"shared": "Inclusion Type", "local": "Inclusion Type",
     "value_map": {"Include": "INCLUDE", "Exclude": "EXCLUDE"},
     "new_values": [], "note": "Guideline Rule Inclusion.Inclusion Type (CW-118)."},
    {"shared": "Case Status", "local": "Case Status",
     "value_map": {"New / Received": "NEW", "Pending Good Order": "PENDING_GOOD_ORDER", "In Progress": "IN_PROGRESS",
                   "Waiting on Client": "WAITING_ON_CLIENT", "Pending Third Party": "PENDING_THIRD_PARTY", "Escalated": "ESCALATED",
                   "Resolved / Completed": "RESOLVED", "Closed": "CLOSED", "Rejected": "REJECTED", "Canceled": "CANCELED"},
     "new_values": [], "note": "Manager Search.Search Status and Oversight Finding.Finding Status (the brief allowed Case Status for the "
                               "finding workflow; the search uses it too instead of a local Manager Search Status)."},
    {"shared": "Asset Class", "local": "Asset Class",
     "value_map": {"Equity": "EQUITY", "Fixed Income": "FIXED_INCOME", "Multi-Asset": "MULTI_ASSET", "Money Market": "MONEY_MARKET",
                   "Real Estate": "REAL_ESTATE", "Private Equity": "PRIVATE_EQUITY", "Private Credit": "PRIVATE_CREDIT",
                   "Infrastructure": "INFRASTRUCTURE", "Hedge / Absolute Return": "HEDGE_ABSOLUTE_RETURN",
                   "Commodities": "COMMODITIES", "Other": "OTHER"},
     "new_values": [], "note": "External Manager Strategy.Strategy Asset Class (steward 01)."},
    {"shared": "Vehicle Type", "local": "Vehicle Type",
     "value_map": {"Open-Ended Fund": "OPEN_ENDED_FUND", "Exchange-Traded Fund": "EXCHANGE_TRADED_FUND",
                   "Collective Investment Trust": "COLLECTIVE_INVESTMENT_TRUST", "Separately Managed Account": "SEPARATELY_MANAGED_ACCOUNT",
                   "Private Fund (Drawdown)": "PRIVATE_FUND_DRAWDOWN", "Evergreen Private Fund": "EVERGREEN_PRIVATE_FUND",
                   "Model Portfolio": "MODEL_PORTFOLIO", "Closed-End Fund": "CLOSED_END_FUND", "Interval Fund": "INTERVAL_FUND",
                   "Unit Investment Trust": "UNIT_INVESTMENT_TRUST"},
     "new_values": [], "note": "Subset. External Manager Strategy.Vehicles Available (steward 01). Left out: 'Pooled Pension / Unit-Linked Fund' "
                               "(no US external-manager vehicle of that name) and 'Segregated Mandate' (covered by Separately Managed Account)."},
    {"shared": "Business Domain", "local": "Business Domain",
     "value_map": {"01 Investment Product & Service Offering": "INVESTMENT_PRODUCT", "11 Market & Competitive Intelligence": "MARKET_INTELLIGENCE",
                   "31 Investment Risk": "INVESTMENT_RISK", "32 Performance & Attribution": "PERFORMANCE_ATTRIBUTION",
                   "33 Investment Compliance": "INVESTMENT_COMPLIANCE", "27 Fund Accounting & Valuation": "FUND_ACCOUNTING_VALUATION",
                   "52 External Manager & Sub-Adviser Oversight": "EXTERNAL_MANAGER_SUBADVISER_OVERSIGHT"},
     "new_values": [], "note": "Subset. Oversight Metric Reading.Metric Source Domain (the owner of each metric value or its inputs, CW-119-AM1)."},
    {"shared": "Measure Unit", "local": "Measure Unit",
     "value_map": {"Percent": "PERCENT", "Basis Points": "BASIS_POINTS", "Ratio": "RATIO", "Years": "YEARS"},
     "new_values": [("PERCENTILE", "Percentile", "Rank in a peer group, 1 = best or cheapest"), ("COUNT", "Count", "Number of records")],
     "note": "Subset plus two proposed values (steward 22). Oversight Metric Reading.Metric Unit (fix-pass ruling 4)."},
    {"shared": "Restriction Limit Type", "local": "Restriction Limit Type",
     "value_map": {"Minimum": "MINIMUM", "Maximum": "MAXIMUM", "Range": "RANGE"},
     "new_values": [], "note": "Subset (Prohibition does not apply). Oversight Metric Threshold.Threshold Limit Type (direction of the threshold)."},
]
# Not used although the brief lists them: Business Line and Data Basis (dropped in the fix pass: the business line is the 01
# product's; a reading's preliminary or final status is its source record's), Approval Status (approvals are 24 Investment Committee Decisions, whose outcome is the
# shared Committee Decision Outcome held in 24), Frequency and Period Type (review periods are dated; review cadence is the
# Oversight Review Type).

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: (local list name, likely users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Oversight Metric", ["52", "46", "12"],
     "Brief section 8: candidate shared list at W5 with 46 (sleeve and model oversight) and 12 (institutional reporting). Steward 52; "
     "each value names its computing domain (Business Domain on the reading)."),
    ("Threshold Result", ["52", "31", "33", "21"],
     "Within / Near / Outside threshold with Exception Approved; 31 limit utilization and 21 data quality results use similar bands. "
     "Merge only if the labels agree."),
    ("Questionnaire Type", ["52", "03", "08", "40"],
     "Due diligence questionnaire kinds (investment, operational, compliance, cybersecurity). 40 vendor due diligence and 08 "
     "distributor due diligence run questionnaires too; 03 answers incoming DDQs. A shared 'Due Diligence Questionnaire Type' with "
     "a subject dimension is a W5 candidate."),
    ("Strategy Style", ["52", "01", "23"],
     "01 Strategy Classification and 23 research universes classify style; align with the 01 style values if 01 has a list at W5."),
    ("Product Use Scope", ["52", "01", "16", "24", "45"],
     "Read by every channel through Product List Status (CW-120). Steward 52."),
    ("Watch Status", ["52", "16", "24"],
     "16 plan fiduciary monitoring (Plan Investment Option watch) may want the same values when the firm is a 3(21) or 3(38) fiduciary."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (plan section 5.3 watchlist names; proposals_w3_oversight.py already carries Manager and Due Diligence)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    # Amendment of the existing decisions.TERM_CONFLICTS entry "Due Diligence / DDQ" (CD-060), not a new entry (fix-pass ruling 6).
    {"term": "Due Diligence / DDQ", "amends": "CD-060",
     "add_usages": [("52", "Manager Due Diligence Review (MDILG-)", "Firm's research review of an external manager or strategy."),
                    ("52", "Product Due Diligence (TPDUE-)", "Firm's diligence on a third-party fund, ETF or private fund interest."),
                    ("05", "Partner Product Due Diligence (Research Rating, watch list indicator)", "A partner's diligence on the firm's products: the nearest collision with 52 Product Due Diligence."),
                    ("40", "Supplier due diligence (Due Diligence Depth)", "Firm's diligence on a supplier.")],
     "amend_usages": [("08", "Distributor Due Diligence (DDQ-)", "The DDQ- prefix and Distributor Due Diligence move to 05 at W4 (proposals_w2_conduct.py); mark the 08 rows 'to 05 at W4'.")],
     "add_glossary_names": ["Manager Due Diligence (52)", "Product Due Diligence (52)", "Supplier Due Diligence (40)"],
     "add_watch_list_pair": [("05", "Research Rating watch list indicator", "Partner's watch list of the firm's products."),
                             ("52", "Sub-Adviser Watch Status; Product List Status 'Watch'", "Firm's watch of external managers and third-party products.")],
     "recommendation": "Keep CD-060 as the single entry: no unqualified 'Due Diligence' or 'DDQ'; 52 uses 'Manager Due Diligence' and 'Product Due Diligence', and questionnaire template codes avoid the DDQ- token.",
     "decision": "CD-060"},

    {"term": "Manager (wealth model)",
     "usages": [("52", "External Manager Profile; Manager Key Person; Manager Search; Manager Termination", "An external investment firm the firm hires or whose products it vets."),
                ("20", "Employee (line manager)", "A line manager."),
                ("24", "Portfolio Management Assignment", "An employee managing a portfolio."),
                ("01", "Portfolio Manager Assignment", "Portfolio manager named for a product.")],
     "recommendation": "As proposals_w3_oversight.py: never bare. 52 object names all carry 'External Manager' or 'Manager <noun>'.",
     "decision": "CW-116"},
    {"term": "Mandate",
     "usages": [("01", "Investment Mandate (MND-)", "What is delegated or managed."),
                ("52", "Sub-Adviser Engagement (SADV-)", "Who is engaged on that mandate, for which fund and sleeve, for which period.")],
     "recommendation": "52 never names an object 'mandate'; Engagement Scope values 'OCIO Mandate' and 'Trust Mandate' describe the 01 mandate engaged on.",
     "decision": "CW-117"},
    {"term": "Engagement",
     "usages": [("34", "Engagement (stewardship engagement with an issuer)", "ownership.py alias 'engagement' -> 34."),
                ("52", "Sub-Adviser Engagement (SADV-)", "Hire of a sub-adviser."),
                ("45", "Advice Engagement", "Planning relationship with a client.")],
     "recommendation": "Always qualify; 52 always types 'Reference (Sub-Adviser Engagement, 52)' so the bare alias to 34 never fires."},
    {"term": "Review",
     "usages": [("52", "Manager Due Diligence Review (MDILG-); Oversight Review (OVRVW-)", "Research and oversight reviews of external managers and products."),
                ("08", "Supervisory review", "Retail conduct supervision."),
                ("45", "Advice Review", "Periodic advice review."),
                ("36", "Product Review", "Governance of own products.")],
     "recommendation": "Qualify every use; 52 never uses 'Review' bare.", "decision": "CW-119"},
    {"term": "Finding",
     "usages": [("52", "Oversight Finding (OVFND-)", "Issue found in manager due diligence or oversight."),
                ("35", "Board 15(c) Finding", "Board conclusion on a Section 15(c) factor."),
                ("37", "Audit Finding", "Internal audit finding.")],
     "recommendation": "Always qualify. A 52 finding that the firm escalates as an operational risk issue is linked from 37, not copied.",
     "decision": "CW-119"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION: new domain, nothing removed (CW-022). EU/UK delegation practice left out is listed in Source_Notes section 3.
# ---------------------------------------------------------------------------------------------------------------------
JURISDICTION = []

# 6. DECISIONS: no US-only pass (new domain). One proposed amendment of CW-119 (fix-pass ruling 2); the other 52 decisions are
# CW-116 to CW-121 and CW-130 in proposals_w3_oversight.py.
DECISIONS = [
    {"id": "CW-119-AM1", "theme": "Ownership", "amends": "CW-119",
     "title": "Oversight metrics: 52 reads base numbers from their owners and computes only stated comparisons; style drift and active share are 52 oversight computations",
     "domains": ["11", "18", "22", "27", "31", "32", "33", "52"],
     "issue": "52 review (High): CW-119's 'numbers are read, not computed' named owners that do not hold half of the twelve oversight metrics: 32 has no excess return, the peer percentile and fee percentile are 11, turnover exists only at fund level in 27, no domain computes style drift or active share, and a breach count is an aggregation of 33 rows.",
     "resolution": "Per Oversight Metric: excess return 1, 3 and 5 years computed in 52 as the annualized 32 Performance Return (pinned Return Version) minus the annualized 32 Benchmark Return (pinned version) over the same period, in percentage points; peer percentile read from 11 Peer Metric Snapshot.Category Percentile Rank and fee versus peers from 11 Fee Benchmark Result.Own Fee Percentile (both referenced); tracking error and information ratio from 32 Ex-Post Risk Statistic; ex-ante tracking error from 31 Portfolio Risk Measure; turnover from 27 Financial Highlights.Portfolio Turnover Rate at fund level (sleeve turnover is a lever); breach count computed in 52 as the count of 33 Investment Breach rows on the rules included in the engagement's Sub-Adviser Guideline Set (referenced) in the review period; style drift and active share mastered in 52 as oversight computations with declared inputs (18 Portfolio Holding of the sleeve, 22 Index Constituent of the benchmark at a stated date), proposed to 32 as a W5 shared candidate. Thresholds are stored once per engagement and metric (Oversight Metric Threshold: direction from shared Restriction Limit Type, value, warning value, effective period); readings carry the unit (shared Measure Unit) and the flag.",
     "rationale": "Every value is implementable from a named record; 52 computes only what no owner holds and says how. Lever: if 32 adopts excess return, style drift and active share at W5, 52 reads them and the computations retire.",
     "action": "Program lead at the W3 merge; 32 owner considers the W5 candidate", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. NOTES for the W3 merge
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Size after the review fix pass (2026-10-15): 8 families, 28 objects (26 BO, 2 AG), 250 attributes, 84 CDEs (34%), 39 code lists "
    "(30 local, 9 copies of shared lists), 48 relationships, 19 sources. Ownership: 49 references, 10 derived copies, 12 overrides, "
    "4 row ownership rules, 0 unresolved. Before: 28 objects (22 BO, 6 AG), 248 attributes, 76 CDEs, 47 references, 10 derived, "
    "8 overrides, 2 row rules, 46 relationships, 17 sources.",
    "For the 12 fix pass (ruling 1): Manager Transition was dropped from 52; the execution record is 12 Transition Event (TRN-, "
    "Transition Type 'Manager Replacement'), which 52 Manager Termination.Transition Event references. 12 Transition Event must hold "
    "the transition's aggregate cost (estimated and realized, in basis points of assets moved), or reference the 25 TCA Results of the "
    "transition orders in aggregate; today no record owns the aggregate. 12 Transition Event should also accept fund sleeves "
    "(18 PORT-) as well as client mandates. The 12 example 'SADV-000412; SADV-000418' has six digits; the published format is five "
    "(SADV-00412); the 12 fix pass corrects it.",
    "For the 16 owner: a third-party fund on a plan menu needs a menu option keyed by the 17 INS- (16 keys options by SHC- only) and a "
    "Derived copy of 52 Product List Status (scope Plan Menus) or a reference to the deciding TPDUE-. For the 45 owner: a "
    "recommendation of a third-party instrument should carry a Derived copy of Product List Status or reference the deciding TPDUE- "
    "(reasonable-basis link, brief section 3 HA). Until then the 52 REL marks both readers as planned.",
    "For the 35 owner: Fund Advisory Agreement.Termination Reason (free text) should read the 52 Manager Termination.Termination "
    "Reason code; 52 Search Outcome.Interim Contract Indicator is a Derived copy of the governing agreement's Advisory Agreement "
    "Type 'Interim Advisory Agreement'; Engagement End Date is set from Manager Termination.Termination Effective Date.",
    "For the 32 owner (W5 candidate, CW-119-AM1): style drift and active share are 52 oversight computations from 18 holdings and 22 "
    "index constituents; 32 may adopt them, and 'Excess Return' on the Ex-Post Statistic list, at W5. The ruling text said '17 index "
    "constituents'; the registered object is 22 Index Constituent (its member instruments are 17), which 52 uses.",
    "Lever (ruling 8): the self-directed platform default is a screen (Full Due Diligence Indicator = N; complex-product "
    "determination, closed or liquidating, sponsor concern); full due diligence is required for Advice Models, Plan Menus, Fund of "
    "Funds and any recommended use. Full curation of every platform product is the lever. The stale SAA-, PDD- and MGR- anchors in "
    "other briefs are ignored by ruling.",
    "Request to the 02 owner (CW-116): Party Role Type gains Sub-Adviser, External Fund Sponsor and Transition Manager. 52 holds the role "
    "profile only; External Manager Type on the profile is the research view and must agree with the 02 Party Role rows.",
    "Request to the 24 owner (CW-121): Committee Decision Type gains Manager Hire, Manager Termination and Third-Party Product Approval; "
    "Investment Committee Type gains Manager Research Committee. Examples use the committee code 'MRC' (for example 'MRC / 2026-09-15 / 3').",
    "Request to the 13 owner: Shareholder Communication Type gains 'Manager-of-Managers Information Statement' (Regulation 14C; today the "
    "information statement would be typed 'Shareholder Notice'). Manager-of-Managers Hire Condition.Information Statement Sent Date is "
    "a Derived copy of the 13 send date.",
    "Request to the 01 owner (CW-117, CW-120): Platform Product Availability.Due Diligence Approval example re-keys from 'Third-party fund "
    "review 2026-0412' to TPDUE-2026-000412; Product Party Role 'Delegated Function Indicator' definition should say 'under a 35 "
    "sub-advisory agreement' (not 52). Party Role Type note 'Sub-Investment Manager - Sub-adviser (52)' is fine: the oversight is 52.",
    "For the 35 owner: Fund Advisory Agreement.External Sub-Adviser and 52 Sub-Adviser Engagement.Engaged Sub-Adviser hold the same PTY-; "
    "proposed rule: every Active engagement's agreement names the engaged sub-adviser. Board Approval Date on the engagement is a Derived "
    "copy read through Resolution Subject Link (CD-237). The 52 Section 15(c) Renewal Submission could become a Renewal Material Item "
    "type ('Sub-Adviser Oversight Submission') in 35, referencing the submission.",
    "For the 46 owner: Sleeve Assignment.Sleeve Sub-Adviser Engagement already types Reference (Sub-Adviser Engagement, 52) with SADV-00412; "
    "it resolves once 52 is registered. proposals_w2_46.py NOTES still say '52 External Manager (MGR- plan anchor)'; read as SADV- at merge (CW-117).",
    "CONCEPT_OWNERSHIP rows to add (owner 52): External Manager Profile (keyed by PTY-), Manager Key Person, External Manager Strategy "
    "(EMSTR-), Manager Search (MSRCH-), Manager Due Diligence Review (MDILG-), Sub-Adviser Engagement (SADV-), Sub-Adviser Guideline Set "
    "(GDLN-), Oversight Review (OVRVW-), Oversight Finding (OVFND-), Product Due Diligence (TPDUE-), Product List Status. Do not add a bare "
    "'engagement' alias (34) or 'finding' alias.",
    "Overrides in enrich_52: six references to External Manager Profile (including Certifying Manager) and Checked Key Person carry PTY- "
    "keys and are forced 'mastered here'; Relied-On Exemptive Relief (starts PRD-) forced 35; Source Benchmark Return (BMK-) and Source "
    "Ex-Post Risk Statistic (PORT-) forced 32; Source Peer Metric Snapshot (SHC-) forced 11; Source Financial Highlights (PRD-) forced 27.",
    "Product List Status is keyed by INS- (third-party instruments only). A third-party fund share class bought by an own fund of funds is "
    "a 17 instrument; own share classes (SHC-) never appear here (36 governs own products).",
    "Brief file name: the brief names the drafter's proposals file 'proposals_52.py'; the W3 assignment names it 'proposals_w3_52.py' "
    "(this file).",
]
