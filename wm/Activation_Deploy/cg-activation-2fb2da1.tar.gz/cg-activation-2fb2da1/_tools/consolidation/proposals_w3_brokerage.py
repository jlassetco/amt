"""Wealth-manager reference model: W3 brief decisions for 48, 49 and 50 (CW-096 to CW-115), reserved prefixes and key formats.

Written by the W3 brokerage brief agent with the briefs in 00_Program/Rework/Briefs/ (48_Brokerage_Orders_and_Execution.md,
49_Clearing_Settlement_and_Client_Asset_Custody.md, 50_Money_Movement_Cash_and_Sweep.md). Format: the DECISIONS dict format,
the PREFIXES tuple format, PREFIX_FORMATS and GRAIN_KEY_FORMATS of decisions.py (CONTRACT.md). Declarative only. Every
decision is "Proposed" until the program lead merges it; each states the tailoring lever where a client could rule
differently. New domains have no US-only pass (CW-022): no CW-9NN decision and no JURISDICTION entries here.
"""

PL = "Program lead"
P = "Proposed"

DECISIONS = [
    # ---- 48 Brokerage Orders & Execution -----------------------------------------------------------------------------
    {"id": "CW-096", "theme": "Ownership", "title": "48 masters client orders, routes, executions, blocks and allocations at account grain, parallel to 25 and copying none of it",
     "domains": ["48", "25", "46", "45", "15", "49"],
     "issue": "CW-010 separates client orders (48) from portfolio orders (25). 25 holds Trade Order (TORD-), Block Order (BLOCK-), Execution (EXEC-), Trade Allocation (ALLOC-) and Trade Error; ownership.ALIASES resolve bare 'trade order', 'block order', 'execution' and 'trade allocation' to 25. Retail managed-account rebalance orders (46) and advisor blocks need a client-grain block and allocation.",
     "resolution": "48 masters Client Order (CLORD-) with Order Instruction Detail, Option Order Leg, Fixed Income Order Detail and Fund Order Detail, Client Order Event, Order Route (ROUTE-), Client Block Order (CLBLK-; source 46 Trade Proposal Batch TPBAT- or an advisor block), Client Execution (CLEXE-) and Client Allocation (block or order x account, average price, fractional remainder). Order source is an attribute: self-directed, advisor-entered (20 EMP-), 46 Trade Proposal (TRPR-), 45 Recommendation (RECOM-), 15 Account Standing Instruction (SIN-). Every 48 object name is qualified 'Client'; no 48 attribute references a 25 object. Institutional separate accounts (IA) trade through 25; self-directed brokerage windows in plans are 15 brokerage accounts and trade through 48.",
     "rationale": "Same lifecycle, different owner (broker-dealer, not adviser), grain (account), regulation (10b-10, 605, 606, CAT) and volume. Lever: an introducing-broker firm keeps 48 and adds the clearing firm's references (CW-114 SME lever).",
     "action": "W3 (48 draft)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-097", "theme": "Boundary", "title": "Fund order hand-off: a brokerage client's fund order is a 48 Client Order routed to 29 (own funds) or to NSCC Fund/SERV (third-party funds)",
     "domains": ["48", "29", "49", "06", "15"],
     "issue": "29 masters Fund Order (FNDO-) for the transfer agent; plan section 5.1 gives 29 the brokerage platform's omnibus position. A brokerage client may buy own funds, third-party funds and 529 portfolios; fund-only (TA-registered) accounts also exist (CW-035). Without a rule the same client instruction is mastered in both 48 and 29.",
     "resolution": "In a 15 brokerage account every fund purchase, redemption and exchange is a 48 Client Order with Fund Order Detail. Own funds: the Order Route goes to the in-house transfer agent; client orders are aggregated per share class and dealing cycle into one 29 Fund Order on the brokerage omnibus account (Order Route.Resulting Fund Order, Reference (Fund Order, 29)); 49 sub-accounts the result as Client Holdings and settles through the 29 Settlement Obligation. Third-party funds: the Order Route goes to NSCC Fund/SERV with its control number; the fill at NAV is a 48 Client Execution; settlement is 49. Fund-only accounts: orders are 29 Fund Orders only, never 48. 13 Confirmation Delivery references the 48 confirmation for brokerage accounts and the 29 Fund Order for fund-only accounts (CW-081).",
     "rationale": "The instruction is mastered where the client gave it; the TA processes what the broker-dealer sends. Lever: networked sub-accounts at the TA give one Fund Order per client order (48 SME question 8).",
     "action": "W3 (48, 29 drafts); confirm with the 29 brief agent", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-098", "theme": "Boundary", "title": "Client Trade Confirmation (CCONF-) is the 48 record; 13 delivers it; 49 books the trade (accepts CW-081)",
     "domains": ["48", "13", "49", "47"],
     "issue": "CW-081 (W2) gives 48 the Rule 10b-10 confirmation content under the plan anchor CCF-, which is one edit from CCI- (13), CCA- (10), CPF- (11), CDF- (12) and FCF-, CCN- (30). Markup disclosure (FINRA Rule 2232, MSRB Rule G-15) and commission amounts sit beside 47's schedules.",
     "resolution": "48 masters Client Trade Confirmation (CCONF-; allocation or execution x confirmation version) and its attribute group Confirmation Remuneration Disclosure (commission, markup or markdown amount and percentage, prevailing market price basis under FINRA Rule 2121 Supplementary Material .02, PFOF and routing statements). The commission amount is computed from 47 Client Fee Schedule (CLFEE-) and held here as charged; 47 masters the schedule. 13 Confirmation Delivery references CCONF- (re-point from the anchor CCF- at the W3 merge). 49 books the trade as Client Account Activity from the Client Allocation. Corrections create a new confirmation version from a 48 Trade Correction (TCORR-).",
     "rationale": "One record of what the customer was told; delivery and books are separate facts. Lever: under a fully disclosed arrangement the clearing firm issues the confirmation and 48 keeps it as received.",
     "action": "W3 (48); W3 merge (13 reference re-point)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-099", "theme": "Boundary", "title": "Order-time eligibility checks and Rule 15c3-5 limits are 48 results; the rules, flags, approvals and restrictions stay in 01, 17, 15 and 02",
     "domains": ["48", "01", "17", "15", "02", "38", "49"],
     "issue": "CW-037 says 48 applies the tradable universe rules and instrument flags; CW-031 says 48 checks features at order time; CW-917 adds fractional and extended-hours flags in 17. The market access rule (SEC Rule 15c3-5) requires pre-trade credit, capital and erroneous-order controls.",
     "resolution": "48 masters Order Eligibility Check (client order x check type: account status, feature and options level from 15 AFEA-, account restriction 15 ARX-, client restriction 02 CRX-, tradable universe rule 01 TUP-, instrument flag 17 INS-, restricted list 38 RLIST-, buying power as a Derived copy of 49 with as-of timestamp, 15c3-5 limit), its result and any override approver, and Pre-Trade Risk Limit (Rule 15c3-5(c) thresholds). 48 holds no copy of the rule, flag, approval or restriction values.",
     "rationale": "Evidence that the check ran is a trade fact; the rule is a policy fact. Lever: a firm that checks only in the OMS without retention keeps the check result on Client Order Event.",
     "action": "W3 (48)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-100", "theme": "Boundary", "title": "Execution-quality statistics, Rule 605 and 606 data and CAT events are 48; the best-execution committee review is 08; trade surveillance is 38",
     "domains": ["48", "08", "38", "25"],
     "issue": "25 Execution Reviews hold the adviser's best-execution committee for portfolios (with a Rule 606 Reports Reviewed Count); FINRA Rule 5310.09 requires the broker-dealer's regular and rigorous review of retail order routing; 38 holds Trade Surveillance Alert (TRSV-); 08 (W2) masters Supervisory Review (PRNR-).",
     "resolution": "48 masters Execution Quality Measure (period x order class x venue), Rule 605 Report Line, Rule 606 Report Line, Order Routing Disclosure Request (Rule 606(b)(1) and (b)(3)), Regulatory Trade Report (TRF, TRACE, MSRB RTRS) and CAT Reportable Event (SEC Rule 613, FINRA Rule 6800 series; FDID only, no customer names, addresses or years of birth). The broker-dealer's best-execution committee review of retail order flow is an 08 Supervisory Review referencing 48 measures and 48 Routing Rules; 25 keeps the adviser's portfolio best-execution reviews; 38 masters trade surveillance alerts that reference 48 Client Orders and Client Executions (38 adds the reference at W4).",
     "rationale": "Statistics are produced by the order system; judgment on them is supervision. Lever: a firm below the amended Rule 605 thresholds drops Rule 605 Report Line.",
     "action": "W3 (48); W2 merge (08 review subject type); W4 (38)", "status": P, "priority": "Medium", "owner_role": PL},

    # ---- 49 Clearing, Settlement & Client Asset Custody --------------------------------------------------------------
    {"id": "CW-101", "theme": "Ownership", "title": "The brokerage book of record: Client Holding (CLHLD-), Client Tax Lot (CTLOT-) and Client Account Activity (CLACT-) are 49",
     "domains": ["49", "18", "06", "15", "13", "46", "47", "51"],
     "issue": "CW-007 places the brokerage book of record in 49 with the glossary name Client Holding; the plan anchors CHL-, CLT- and CAA- each fail the confusable test; ownership.ALIASES maps 'tax lot' to 18; CW-915 moves Covered Security Indicator from 15 to the 49 client lot; 45, 46, 47, 51 and 13 reference these objects by the anchor names.",
     "resolution": "49 masters Client Holding (CLHLD-; account x instrument x holding date x Holding View), Client Holding Valuation (attribute group), Client Tax Lot (CTLOT-; with Covered Security Indicator and covered class under IRC section 6045(g)), Client Lot Relief, Cost Basis Adjustment, Cost Basis Transfer Statement (IRC section 6045A), Client Account Activity (CLACT-; the posting of every trade, money movement, income, fee debit, journal, corporate action and transfer, with status pending, posted or reversed) and Account Cash Balance. Every reference to a client lot is typed 'Reference (Client Tax Lot, 49)'. 06 Fund Shareholder Position is a view of Client Holdings in own share classes; 18 never holds a client account.",
     "rationale": "One book of record per owner (CW-007). Lever: under a fully disclosed clearing arrangement these become received copies from the clearing firm.",
     "action": "W3 (49); W3 merge (re-point 45, 46, 47, 51, 13 anchors to the reserved prefixes)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-102", "theme": "Boundary", "title": "Client cash: elected in 15, moved in 50, booked in 49; Sweep Balance (49) and Sweep Allocation (50) reconcile",
     "domains": ["15", "49", "50", "29", "43", "46"],
     "issue": "15 holds Cash Sweep Election, Bank Instruction and Account Standing Instruction (CW-031, CW-033); the term conflict Sweep names 49 Sweep Balance and 50 Sweep Allocation; 29 has its own Cash Movement for fund settlement; 43 holds the firm's bank accounts. Without a rule an account's swept cash is mastered twice.",
     "resolution": "15 masters elections and instructions. 50 masters every Money Movement (MMVMT-), the sweep programs, program banks and the Sweep Allocation (account x program bank x business date), and the program-bank omnibus deposit accounts held as agent for customers. 49 masters Account Cash Balance by balance type (free credit, Sweep Balance, margin debit, short proceeds) and posts every money movement, sweep interest and settlement as Client Account Activity. The sum of an account's Sweep Allocations equals its 49 Sweep Balance for the business date; the reconciliation is a 49 Stock Record Reconciliation of type Program-Bank Sweep. Money market sweep fund shares are Client Holdings. Settlement cash of client trades is 49; fund-side settlement cash is 29; firm cash is 43.",
     "rationale": "One owner per balance; the allocation explains the balance and never replaces it. Lever: a firm with a bank charter books deposits in a banking domain (plan section 13 variant).",
     "action": "W3 (49, 50)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-103", "theme": "Naming", "title": "The Rule 15c3-3 computation is named Reserve Computation (RESRV-; customer and PAB); 43 reads it and its aggregate debit items (amends CW-943)",
     "domains": ["49", "43"],
     "issue": "CW-943 added 43 Capital Requirement Calculation.Reserve Computation typed Reference (Customer Reserve Computation, 49), anchor RSV-, example RSV-20260930-01, and asked the 49 brief to confirm or correct the name. Rule 15c3-3(e) and Exhibit A (Rule 15c3-3a) define two computations, for customers and for PAB accounts, with the same formula; PAB accounts are not customers. RSV- is one edit from TRSV- (38), REV- (08), RSM- (06), RSL- (08), RST- (01) and an anagram of SVR- (12) and SRV- (08). The 2024 amendments require daily computation above USD 500 million average total credits (compliance date June 30, 2026; confirm).",
     "resolution": "Ruled: one object, Reserve Computation (RESRV-; broker-dealer x computation date x Computation Type Customer or PAB), with Reserve Computation Line (Exhibit A formula items), the requirement, the deposit and the reserve bank account (43 Corporate Bank Account, BKAC-). At the W3 merge 43 Capital Requirement Calculation.Reserve Computation is re-typed Reference (Reserve Computation, 49) and reads the Customer row; its example is re-keyed RESRV-20260930-C; Aggregate Debit Items Amount stays a Derived copy (49) of the customer computation. 43 computes net capital; 49 never holds it.",
     "rationale": "The name 'Customer Reserve Computation' would mislabel the PAB rows; one object avoids two identical structures. Lever: a firm with no PAB accounts keeps one value.",
     "action": "W3 (49); W3 merge (43 re-type and re-key)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-104", "theme": "Ownership", "title": "Account Transfer (ACXF-) is 49: ACATS full, partial and residual, non-ACATS and internal re-registrations, with IRC section 6045A statements",
     "domains": ["49", "15", "13", "29", "50"],
     "issue": "15 Account Closure.Closing Account Transfer references 'Account Transfer' (49) with an example under the anchor CAX-, which is one edit from CAE- (17 corporate action event), CRX- (02), CAL- (09) and CAM- (04). The Transfer term conflict separates Account Transfer (49), Cash Transfer (50) and Fund Share Transfer (29).",
     "resolution": "49 masters Account Transfer (ACXF-; direction, channel ACATS full, partial or residual credit, non-ACATS, internal re-registration; contra firm as a 02 party; validation and settlement dates; reject reason; FINRA Rule 11870) and Account Transfer Asset Line, with the Cost Basis Transfer Statement sent or received. Cash legs move as 50 money movements only when they leave the clearing system; fund-only account transfers are 29 Fund Share Transfers. 13 masters the client's transfer request (Service Request). The 15 example CAX-2026-0045120 is re-keyed ACXF-2026-0045120.",
     "rationale": "A transfer moves positions between books of record. Lever: none.",
     "action": "W3 (49); W3 merge (15 re-key)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-105", "theme": "Boundary", "title": "Margin and fully paid lending: approvals in 15, balances, calls and loans in 49, fund lending in 28, net capital in 43",
     "domains": ["49", "15", "28", "43", "48"],
     "issue": "CW-031 gives 15 the margin and fully paid lending features and agreements and 49 the balances, calls and loans; CW-915 puts the intraday margin standard on Account; 28 holds fund Securities Loan (SBL-) and Loan Regulatory Report under SEC Rule 10c-1a; 26 holds fund-side Margin Call (MCALL-).",
     "resolution": "49 masters Margin Balance Snapshot (account x business date: debit, equity, Reg T excess, SMA, maintenance, house and intraday requirements, buying power), Client Margin Call (MGCL-; Reg T, FINRA Rule 4210 maintenance, house, intraday deficit), Fully Paid Securities Loan (CSLN-; Rule 15c3-3(b)(3), FINRA Rule 4330) with Loan Reporting Detail (shared Regulatory Trade Report Regime value SEC_RULE_10C_1A; 49 joins as a member). 48 reads buying power as a Derived copy. Liquidations for unmet calls are 48 Client Orders with source 'Margin Liquidation'.",
     "rationale": "Client-side credit and lending are brokerage book facts; the fund program is 28. Lever: drop margin or fully paid lending (plan section 15 item 3).",
     "action": "W3 (49); W5 (shared list membership)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-106", "theme": "Boundary", "title": "Corporate actions and income on client accounts: event in 17, fund entitlements in 28, client entitlements, elections and DRIP in 49",
     "domains": ["49", "17", "28", "13", "51", "15"],
     "issue": "17 masters Corporate Action Event (CAE-) and options; 28 masters Corporate Action Entitlement (CAEN-) per safekeeping account for funds; 13 masters Issuer Proxy Pass-Through with the record-date position from 49 (CW-090); 15 holds the DRIP feature; 51 classifies trust receipts.",
     "resolution": "49 masters Client Corporate Action Entitlement (CLCAE-; 17 event x account: record-date quantity Derived from Client Holding, entitled cash and securities, withholding, cash in lieu), Client Voluntary Election (entitlement x option) and Dividend Reinvestment Allocation (attribute group; resulting Client Tax Lot). Payments post as Client Account Activity; basis effects are Cost Basis Adjustments citing the issuer's Form 8937. 13 reads record-date quantities from CLCAE-; 51 allocates principal and income from the activity.",
     "rationale": "Same events, different books (CW-007). Lever: none.",
     "action": "W3 (49)", "status": P, "priority": "Medium", "owner_role": PL},

    # ---- 50 Money Movement, Cash & Sweep -----------------------------------------------------------------------------
    {"id": "CW-107", "theme": "Boundary", "title": "Every client payment is a 50 Money Movement (MMVMT-), including for fund-only accounts; 29 keeps fund-side settlement cash",
     "domains": ["50", "29", "15", "13", "16", "49"],
     "issue": "15 references Money Movement (50) from Account Opening.Initial Funding Transaction, Account Lifecycle Event.Triggering Transaction and Account Closure.Final Transaction, with examples under the anchor MMT- (one edit from CMT- 01, PMT- 05 and MMH-). 29 Payments & Exceptions holds Cash Movement with an Investor Bank Instruction for direct-investor payments as well as intermediary and NSCC settlement.",
     "resolution": "50 masters Money Movement for every payment to, from or between client accounts of any 15 Account Type (ACH, wire, check, internal transfer, card, bill pay), with rail detail groups, events, returns and exceptions. 29 Cash Movement keeps fund-side settlement with intermediaries, NSCC, authorized participants and the fund cash account; for a direct investor of a fund-only account it references the 50 Money Movement (Reference (Money Movement, 50)) instead of holding the investor bank instruction. Plan distributions stay on the recordkeeper's rail (16 DIST-). The 15 examples MMT-2024-00318273 and MMT-2026-00418273 are re-keyed MMVMT-.",
     "rationale": "One payment hub per client, one fraud and AML view. Lever: a firm whose TA pays fund-only investors directly keeps those payments in 29 (confirm with the 29 brief agent).",
     "action": "W3 (50, 29 drafts); W3 merge (15 re-key)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-108", "theme": "Ownership", "title": "Sweep Program (SWEEP-) and Program Bank (PGBNK-) are 50; FDIC pass-through coverage is assessed in 50; 15 holds the election",
     "domains": ["50", "15", "01", "02", "39", "43", "10"],
     "issue": "15 Cash Sweep Election references Sweep Program (50) and Excluded Program Banks (Program Bank, 50) with examples SWP-0004, PBK-0012 and PBK-0019; SWP- is one edit from SWG- (27) and SNP- (06); PBK- from FBK- and PMK- (08). The firm has no bank charter; deposits sit in omnibus accounts opened by the broker-dealer as agent at program banks (12 CFR Part 330 pass-through; SEC Rule 15c3-3(j)(2)).",
     "resolution": "50 masters Sweep Program (SWEEP-), Program Bank (PGBNK-; role profile of a 02 party, the Issuer Profile pattern), Program Bank Participation (priority, capacity, omnibus deposit account, 39 contract), Sweep Rate Tier, Sweep Run, Sweep Allocation, Program Bank Daily Position and FDIC Coverage Assessment (party x ownership category x program bank x date). Money market sweep funds are 01 share classes; their orders are 29 Fund Orders from the Sweep Run. The omnibus deposit accounts are not 43 Corporate Bank Accounts. 10 reads program economics. The 15 examples are re-keyed SWEEP-0004, PGBNK-0012, PGBNK-0019.",
     "rationale": "Client cash programs are a client-asset service of the broker-dealer. Lever: one program bank, or money market sweep only.",
     "action": "W3 (50); W3 merge (15 re-key)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-109", "theme": "Boundary", "title": "Money Movement Hold (MMHLD-) is 50; securities and account holds stay 15 ARX-; the cause is 02 VCON-; the review is 08 SNRC-",
     "domains": ["50", "15", "02", "08", "39"],
     "issue": "15 Account Restriction Type 'Financial Exploitation' notes 'disbursement holds are 50 (confirm)'; 02 Vulnerability Concern lists resulting restrictions; 08 Senior Investor Case (CW-071) references 15 ARX- and 50 MMH-; the Hold term conflict gives the primary sense to 39 Legal Hold. MMH- is one edit from MSH- (11) and MMT-.",
     "resolution": "50 masters Money Movement Hold (MMHLD-; held movement, type funds availability, fraud, FINRA Rule 2165 disbursement hold, legal process, AML or sanctions; reason; dates; trusted contact notified; source concern 02 VCON-; paired 15 ARX-; 08 SNRC-; release). Hold reasons of suspected exploitation are 'PII - special category (CD-344)'. The link to the cause is held on the hold (02 Resulting Account Restrictions stays a Derived inverse). 08 re-points its anchor MMH- to MMHLD-. Term: 'Money Movement Hold', never bare 'Hold'.",
     "rationale": "A hold on a payment is a payment fact; supervision of it is a case. Lever: one account-level restriction for all holds (50 SME question 6).",
     "action": "W3 (50); W3 merge (08 re-point)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-110", "theme": "Boundary", "title": "Money-movement AML monitoring and payment sanctions screening are 50; the program, cases and SARs are 38; TA monitoring stays 29",
     "domains": ["50", "38", "29", "02"],
     "issue": "CW-016 and CW-025 give 50 cash-movement AML monitoring and 38 the AML program; 29 Account Monitoring Alert (AMA-) covers TA activity; 38 AML Case references the 29 alert; 02 holds KYC and the sanctions screening result of the party.",
     "resolution": "50 masters Money Movement Monitoring Alert (MMALT-; scenario, movements, subject, disposition, escalation to 38 AML Case) and Payment Sanctions Screening (movement x screening, shared Screening Result). 38 adds 'Source Money Movement Monitoring Alert' to AML Case at W4. 29 keeps AMA- for fund-only TA activity; party screening stays 02. SAR existence is restricted (31 CFR 1023.320(e)).",
     "rationale": "Alerts live with the activity they monitor (the 29 pattern). Lever: a single enterprise alert object in 38.",
     "action": "W3 (50); W4 (38)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-111", "theme": "Ownership", "title": "Debit cards (DCARD-), card transactions and Regulation E disputes are 50; the card feature is 15",
     "domains": ["50", "15", "02"],
     "issue": "CW-031 gives 50 debit-card instances and check stock; 15 Feature Type 'Debit Card' notes 'card instance is 50'. The program bank issues the card and is the Regulation E financial institution.",
     "resolution": "50 masters Debit Card (DCARD-; masked PAN only, PCI DSS), Card Transaction Detail (attribute group of Money Movement) and Card Dispute (Regulation E error resolution record as the firm handles it for the issuing program bank). Checks are Money Movements with Check Detail. 15 keeps the feature and approval.",
     "rationale": "Instruments of payment are payment facts. Lever: drop the card family.",
     "action": "W3 (50)", "status": P, "priority": "Low", "owner_role": PL},

    # ---- Cross-cutting ---------------------------------------------------------------------------------------------
    {"id": "CW-112", "theme": "Shared lists", "title": "Market Data Subscriber Status stays a 14 local list; 48 and 49 do not use it (withdraws the CW-914 candidate)",
     "domains": ["14", "48", "49", "04"],
     "issue": "CW-914 recorded 14 Market Data Subscriber Status as a shared-list candidate for 48 and 49.",
     "resolution": "Neither 48 nor 49 holds a subscriber status: the professional or non-professional status governs quote entitlements and exchange fees (14), not orders, executions or holdings. The candidate is withdrawn; if 04 Digital Profile records the client's subscriber attestation at W4, the list is shared with 04 instead.",
     "rationale": "A shared list needs two real members. Lever: a firm that gates order types by quote entitlement adds the status to Order Eligibility Check.",
     "action": "W5 (shared_code_lists.py note)", "status": P, "priority": "Low", "owner_role": PL},

    {"id": "CW-113", "theme": "Term conflicts", "title": "Term conflicts of 48, 49 and 50 to log at W5",
     "domains": ["48", "49", "50", "25", "26", "28", "29", "18", "06", "15", "13", "39", "43"],
     "issue": "Plan section 5.3 lists Order, Custody, Holding, Position, Transfer, Sweep, Program; the briefs add Execution, Allocation, Confirmation, Lot, Settlement, Entitlement, Securities Loan, Margin Call, Reserve, Hold, Cash Balance.",
     "resolution": "Log in TERM_CONFLICTS: Execution (48 Client Execution; 25 Execution); Allocation (48 Client Allocation; 25 Trade Allocation; 50 Sweep Allocation); Confirmation (48 Client Trade Confirmation; 13 Confirmation Delivery; 26 Trade Confirmation, fund-side affirmation); Tax Lot (49 Client Tax Lot; 18 Tax Lot); Settlement (49 Street Settlement Obligation; 26 Settlement Instruction; 29 Fund Order Settlement); Entitlement (49 Client Corporate Action Entitlement; 28 Corporate Action Entitlement; 14 Data Entitlement); Securities Loan (49 Fully Paid Securities Loan; 28 Securities Loan); Margin Call (49 Client Margin Call; 26 Margin Call); Reserve (49 Reserve Computation; 19 reserves); Hold (50 Money Movement Hold; 15 Account Restriction; 39 Legal Hold); Cash Balance (49 Account Cash Balance; 18 Cash Balance; 43 Cash Position). Confirm the plan section 5.3 resolutions for Order, Custody, Holding, Position, Transfer, Sweep and Program with the 48, 49 and 50 names.",
     "rationale": "Every term is qualified by its book or owner.",
     "action": "W5", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-114", "theme": "Prefixes", "title": "Reserved prefixes of 48, 49 and 50; every plan anchor rejected; module examples re-keyed",
     "domains": ["48", "49", "50", "15", "43", "13", "08", "45", "46", "47", "51", "02"],
     "issue": "All 13 plan anchors fail the confusable test (equal, anagram or one edit from a registered prefix, a plan anchor, a W2 reservation or a sibling anchor). Six examples already use anchors: 15 SWP-0004, PBK-0012, PBK-0019, MMT-2024-00318273, CAX-2026-0045120, MMT-2026-00418273; 43 RSV-20260930-01. W2 briefs cite the anchors 'per the 48/49/50 brief'.",
     "resolution": "Reserve 48: CLORD-, ROUTE-, CLEXE-, CLBLK-, CCONF-, TCORR-; 49: CLHLD-, CTLOT-, CLACT-, RESRV-, ACXF-, MGCL-, CSLN-, CLCAE-; 50: MMVMT-, MMHLD-, MMALT-, SWEEP-, PGBNK-, DCARD-. Formats in PREFIX_FORMATS; composite keys in GRAIN_KEY_FORMATS. At the W3 merge: re-key the 15 and 43 examples (NOTES); re-point the anchors named in the 45, 46, 47, 51, 13, 08, 02 and 01 briefs and drafts (COR- to CLORD-, CCF- to CCONF-, CHL- to CLHLD-, CLT- to CTLOT-, CAA- to CLACT-, CAX- to ACXF-, MMT- to MMVMT-, SWP- to SWEEP-, PBK- to PGBNK-, MMH- to MMHLD-). Self-clearing is the reference default; a fully disclosed clearing arrangement is the lever (briefs section 12).",
     "rationale": "No prefix equal, anagram or one edit from another; mnemonic five-letter keys for the high-volume objects.",
     "action": "W3 merge", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-115", "theme": "Governance", "title": "Personal data in 48, 49 and 50; exploitation hold reasons are special category (CD-344); CAT customer identifiers are not held",
     "domains": ["48", "49", "50", "02", "21"],
     "issue": "Plan section 11 requires a PII tier on every object of 48, 49 and 50 and the special-category rule for elder-exploitation data. CAT customer identifying information was reduced by the SEC exemption of February 2025 and a CAT NMS Plan amendment approved in January 2026 (confirm).",
     "resolution": "Every object states its tier: account-level orders, holdings, lots, activity, margin, transfers and movements are 'PII - financial'; bank account, card and check numbers and wire beneficiary data are 'PII - financial (restricted)' and masked in examples; screening and routing disclosure requests 'PII - identity'; firm-level objects (venue profiles, routing rules, report lines, reserve computations, possession or control, counts, sweep programs, program banks, daily positions, forecasts) 'No PII'. Money Movement Hold rows whose reason is suspected exploitation or diminished capacity are 'PII - special category (CD-344)' with a restricted view; products read them as aggregates. 48 CAT Reportable Event holds the FDID and no customer name, address, year of birth or TIN.",
     "rationale": "Applies CW-030 and CW-060 to brokerage data. Lever: none.",
     "action": "W3 (48, 49, 50); WP1 (products)", "status": P, "priority": "High", "owner_role": "Data Protection Officer"},
]

# ---------------------------------------------------------------------------------------------------------------------
# Reserved prefixes (decisions.py tuple format). Checked against decisions.PREFIXES (410 entries, both siblings, every
# status), the plan section 5.2 anchors of 45 to 52, the W2 reservations (proposals_w2_advice.py, proposals_w2_conduct.py,
# proposals_w2_engagement.py) and W2 briefs, prefix-like tokens in every content module, DP- FN- SM- CD- CW-, the L1 codes
# and each other (no two reserved here are within one edit). Rejected near-misses:
#   48: COR- (CLR- 09, CSR- 12, CRR- 07, COI- 08, PCOR- 16; anagram RCO- 45 anchor), CORD- (TORD- 25), CXORD-;
#       CRT- (CRX- 02, CMT- 01, CRR-, CRA- 07, CRV- 12), ROUT-/OROUT-, RTDC-; CEX- (CRX-, CEV- 11, CAX- anchor),
#       CEXE- (anagram EXEC- 25), CLEX- (RLEX- 31), FILL-; CBLKO- (anagram BLOCK- 25), CBLK-; CCF- (CCI- 13, CCA- 10,
#       CPF- 11, CDF- 12, FCF-, CCN- 30), CNFC- (CNFM- 26), CONFC- (CONFL- 38); TCRX- (CRX-), CORR- (CRR-), CLCOR-.
#   49: CHL- (PCHL- 22, CAL- 09, CPL- 08, CTL- 07), CHLD- (HLD- 18), CLHG- (anagram LCHG- 36); CLT- (anagram CTL- 07;
#       CLR-, CLV-, CLM- 09, CMT- 01, SLT- 03; reads as LOT- 18), CLOT- (LOT-), CLTL- (CTL-); CAA- (CAE- 17, CAL-, CAM- 04,
#       CUA- 12, CCA- 10, CRA-, CVA- 07, SAA- 52 anchor), CACT- (ACT- 03); RSV- (TRSV- 38, REV- 08, RSM- 06, RSL- 08, RST-
#       01, anagrams SVR- 12, SRV- 08), RSVC- (RVC- 10), RSRV- (SRV-), RCMP- (RCAP- 43); CAX- (CAE- 17, CRX- 02, CAL-,
#       CAM-), ACAT- (ACT-), ACATS-, XFER-; CMGC-/CLMC- (CMC- 28, CLM- 09); FPLN-/FPSL- (FPL- 19), FPLOAN- (FPLAN- 45);
#       CAENT- (CAEN- 28), CCAE- (CAE- 17).
#   50: MMT- (CMT- 01, PMT- 05, MMH-), MMVT-/MVMT-/MMTX- (MMT-), CMOV- (anagram MCOV- 42), CSHM- (CSHI- 46), MONMV-;
#       MMH- (MSH- 11, MMT-), MHLD-/DHLD- (HLD- 18), MMHD- (MSHD- 11), DSBH-; TMAL- (anagram LMAT- 39), MMAL-, CMMA-;
#       SWP- (SWG- 27, SNP- 06), SWPG-, SWPP-; PBK- (FBK-, PMK- 08), PBNK-/PRBK-/PGBK-; DBCD-, CARD-.
#   Noted, not rejected: CTLOT- is two edits from LOT- (18); CLCAE- two edits from CAE- (17); CSLN- two edits from SBL-
#   (28); MMHLD- two edits from CLHLD- and MMALT-; MMALT- two edits from AMA- (29); CLBLK- two edits from CLHLD-.
# The other W3 brief agents (52, 29, 16, 24, 32) and W4 reserve in parallel; the lead checks the files against each other.
# ---------------------------------------------------------------------------------------------------------------------
R = "Reserved"

PREFIXES = [
    ("CLORD-", "Client order (brokerage account order in any instrument)", "48", R, "W3 brief 48 (CW-096, CW-114). Plan anchor COR- rejected (CLR- 09, CSR- 12, CRR- 07, PCOR- 16; anagram RCO-); rejected CORD- (TORD- 25)."),
    ("ROUTE-", "Order route (client order x route sequence to one venue)", "48", R, "W3 brief 48 (CW-096). Plan anchor CRT- rejected (CRX- 02, CMT- 01, CRR-, CRA- 07, CRV- 12); rejected ROUT-, OROUT-, RTDC-."),
    ("CLEXE-", "Client execution (fill)", "48", R, "W3 brief 48 (CW-096). Plan anchor CEX- rejected (CRX- 02, CEV- 11); rejected CEXE- (anagram EXEC- 25), CLEX- (RLEX- 31)."),
    ("CLBLK-", "Client block order (46 batch or advisor block)", "48", R, "W3 brief 48 (CW-096). Rejected CBLKO- (anagram BLOCK- 25)."),
    ("CCONF-", "Client trade confirmation (Rule 10b-10 record x version)", "48", R, "W3 brief 48 (CW-098, CW-081). Plan anchor CCF- rejected (CCI- 13, CCA- 10, CPF- 11, CDF- 12); rejected CNFC- (CNFM- 26), CONFC- (CONFL- 38)."),
    ("TCORR-", "Trade correction (cancel, correct, rebill, as-of)", "48", R, "W3 brief 48 (CW-096). Rejected TCRX- (CRX- 02), CORR- (CRR- 07), CLCOR-."),
    ("CLHLD-", "Client holding (account x instrument x holding date x holding view)", "49", R, "W3 brief 49 (CW-101). Plan anchor CHL- rejected (PCHL- 22, CAL- 09, CPL- 08); rejected CHLD- (HLD- 18), CLHG- (anagram LCHG- 36)."),
    ("CTLOT-", "Client tax lot", "49", R, "W3 brief 49 (CW-101). Plan anchor CLT- rejected (anagram CTL- 07; CLR-, CLV-, CLM- 09; reads as LOT- 18); rejected CLOT- (LOT-), CLTL-. Two edits from LOT-."),
    ("CLACT-", "Client account activity (posting)", "49", R, "W3 brief 49 (CW-101). Plan anchor CAA- rejected (CAE- 17, CAL- 09, CAM- 04, CUA- 12, CCA- 10, SAA- 52 anchor); rejected CACT- (ACT- 03)."),
    ("RESRV-", "Reserve computation (Rule 15c3-3, customer or PAB)", "49", R, "W3 brief 49 (CW-103). Plan anchor RSV- rejected (TRSV- 38, REV- 08, RST- 01, anagrams SVR- 12, SRV- 08); rejected RSVC- (RVC- 10), RSRV-, RCMP- (RCAP- 43). 43 example re-keyed."),
    ("ACXF-", "Account transfer (ACATS and non-ACATS)", "49", R, "W3 brief 49 (CW-104). Plan anchor CAX- rejected (CAE- 17, CRX- 02, CAL-, CAM-); rejected ACAT- (ACT- 03), ACATS-, XFER-. 15 example re-keyed."),
    ("MGCL-", "Client margin call (Reg T, maintenance, house, intraday)", "49", R, "W3 brief 49 (CW-105). MCALL- stays 26; rejected CMGC-, CLMC- (CMC- 28, CLM- 09)."),
    ("CSLN-", "Fully paid securities loan (client account x borrower x instrument)", "49", R, "W3 brief 49 (CW-105). Rejected FPLN-, FPSL- (FPL- 19), FPLOAN- (FPLAN- 45); two edits from SBL- (28)."),
    ("CLCAE-", "Client corporate action entitlement (17 event x account)", "49", R, "W3 brief 49 (CW-106). Rejected CAENT- (CAEN- 28), CCAE- (CAE- 17)."),
    ("MMVMT-", "Money movement (ACH, wire, check, internal, card, bill pay)", "50", R, "W3 brief 50 (CW-107). Plan anchor MMT- rejected (CMT- 01, PMT- 05, MMH-); rejected MMVT-, MVMT-, CMOV- (anagram MCOV- 42), CSHM- (CSHI- 46). 15 examples re-keyed."),
    ("MMHLD-", "Money movement hold (funds availability, fraud, Rule 2165, legal, AML)", "50", R, "W3 brief 50 (CW-109). Plan anchor MMH- rejected (MSH- 11, MMT-); rejected MHLD-, DHLD- (HLD- 18), MMHD- (MSHD- 11), DSBH-."),
    ("MMALT-", "Money movement monitoring alert (AML, fraud scenario)", "50", R, "W3 brief 50 (CW-110). Rejected TMAL- (anagram LMAT- 39); two edits from AMA- (29)."),
    ("SWEEP-", "Sweep program (bank deposit or money market)", "50", R, "W3 brief 50 (CW-108). Plan anchor SWP- rejected (SWG- 27, SNP- 06); rejected SWPG-, SWPP-. 15 example re-keyed."),
    ("PGBNK-", "Program bank (role profile of a 02 party x period)", "50", R, "W3 brief 50 (CW-108). Plan anchor PBK- rejected (FBK-, PMK- 08); rejected PBNK-, PRBK-, PGBK-. 15 examples re-keyed."),
    ("DCARD-", "Debit card (program-bank card instance; masked PAN)", "50", R, "W3 brief 50 (CW-111). Rejected CARD- (bare word), DBCD-."),
]

# Proposed key formats (decisions.PREFIX_FORMATS tuple format: prefix, domain, format, example).
PREFIX_FORMATS = [
    ("CLORD-", "48", "CLORD-<YYYYMMDD>-<sequence, 9 digits>", "CLORD-20261005-004188221"),
    ("ROUTE-", "48", "ROUTE-<CLORD- date and sequence>-<route sequence, 2 digits>", "ROUTE-20261005-004188221-01"),
    ("CLEXE-", "48", "CLEXE-<YYYYMMDD>-<sequence, 10 digits>", "CLEXE-20261005-0031877412"),
    ("CLBLK-", "48", "CLBLK-<YYYYMMDD>-<sequence, 6 digits>", "CLBLK-20261005-000412"),
    ("CCONF-", "48", "CCONF-<trade date YYYYMMDD>-<sequence, 9 digits>-<version, 2 digits>", "CCONF-20261005-004188221-01"),
    ("TCORR-", "48", "TCORR-<year>-<sequence, 6 digits>", "TCORR-2026-000318"),
    ("CLHLD-", "49", "CLHLD-<holding date YYYYMMDD>-<sequence, 10 digits>", "CLHLD-20261005-0041882217"),
    ("CTLOT-", "49", "CTLOT-<sequence, 11 digits>", "CTLOT-00418822173"),
    ("CLACT-", "49", "CLACT-<entry date YYYYMMDD>-<sequence, 10 digits>", "CLACT-20261005-0004188221"),
    ("RESRV-", "49", "RESRV-<computation date YYYYMMDD>-<C for customer or P for PAB>", "RESRV-20260930-C"),
    ("ACXF-", "49", "ACXF-<year>-<sequence, 7 digits>", "ACXF-2026-0045120"),
    ("MGCL-", "49", "MGCL-<call date YYYYMMDD>-<sequence, 6 digits>", "MGCL-20261005-000187"),
    ("CSLN-", "49", "CSLN-<year>-<sequence, 7 digits>", "CSLN-2026-0003128"),
    ("CLCAE-", "49", "CLCAE-<CAE- event number>-<ACC- account number>", "CLCAE-2026-0041877-0049812"),
    ("MMVMT-", "50", "MMVMT-<year>-<sequence, 8 digits>", "MMVMT-2026-00418273"),
    ("MMHLD-", "50", "MMHLD-<year>-<sequence, 6 digits>", "MMHLD-2026-000412"),
    ("MMALT-", "50", "MMALT-<year>-<sequence, 7 digits>", "MMALT-2026-0003187"),
    ("SWEEP-", "50", "SWEEP-<sequence, 4 digits>", "SWEEP-0004"),
    ("PGBNK-", "50", "PGBNK-<sequence, 4 digits>", "PGBNK-0012"),
    ("DCARD-", "50", "DCARD-<sequence, 9 digits> (never the card number)", "DCARD-000418822"),
]
KEY_FORMATS = PREFIX_FORMATS  # alias named in the W3 assignment

# Composite keys (decisions.GRAIN_KEY_FORMATS tuple format: object, domain, format, example).
GRAIN_KEY_FORMATS = [
    ("Order Eligibility Check", "48", "<CLORD- id> / <check type>", "CLORD-20261005-004188221 / OPTIONS_LEVEL"),
    ("Client Allocation", "48", "<CLBLK- or CLORD- id> / <ACC- id>", "CLBLK-20261005-000412 / ACC-0049812"),
    ("Option Exercise Instruction", "48", "<ACC- id> / <INS- id> / <exercise date>", "ACC-0049812 / INS-00512240 / 2026-10-16"),
    ("Rule 605 Report Line", "48", "<LEN- id> / <month YYYY-MM> / <INS- id> / <order type> / <size bucket>", "LEN-0004 / 2026-09 / INS-00104477 / MARKETABLE / 100-499"),
    ("Rule 606 Report Line", "48", "<LEN- id> / <quarter> / <month> / <order class> / <venue PTY- id>", "LEN-0004 / 2026Q3 / 2026-09 / SP500_STOCKS / PTY-0102877"),
    ("CAT Reportable Event", "48", "<source id> / <CAT event type> / <submission date>", "ROUTE-20261005-004188221-01 / MEOR / 2026-10-05"),
    ("Client Lot Relief", "49", "<CTLOT- id> / <CLACT- id>", "CTLOT-00418822173 / CLACT-20261005-0004188221"),
    ("Account Cash Balance", "49", "<ACC- id> / <currency> / <balance type> / <business date>", "ACC-0049812 / USD / SWEEP_BALANCE / 2026-10-05"),
    ("Reserve Computation Line", "49", "<RESRV- id> / <Exhibit A item>", "RESRV-20260930-C / CREDIT-01"),
    ("Possession or Control Position", "49", "<INS- id> / <business date>", "INS-00104477 / 2026-10-05"),
    ("Margin Balance Snapshot", "49", "<ACC- id> / <business date>", "ACC-0049812 / 2026-10-05"),
    ("Security Count", "49", "<LEN- id> / <quarter> / <control location PTY- id>", "LEN-0004 / 2026Q3 / PTY-0100211"),
    ("Sweep Allocation", "50", "<ACC- id> / <PGBNK- id> / <business date>", "ACC-0049812 / PGBNK-0012 / 2026-10-05"),
    ("Program Bank Participation", "50", "<SWEEP- id> / <PGBNK- id> / <effective from>", "SWEEP-0004 / PGBNK-0012 / 2026-01-01"),
    ("FDIC Coverage Assessment", "50", "<PTY- id> / <ownership category> / <PGBNK- id> / <as-of date>", "PTY-0041877 / JOINT / PGBNK-0012 / 2026-10-05"),
    ("Money Movement Return", "50", "<MMVMT- id> / <return sequence>", "MMVMT-2026-00418273 / 1"),
]

NOTES = [
    "15 at the W3 merge (content_15_account.py examples): Elected Sweep Program SWP-0004 -> SWEEP-0004; Excluded Program Banks PBK-0012; PBK-0019 -> PGBNK-0012; PGBNK-0019; Initial Funding Transaction MMT-2024-00318273 -> MMVMT-2024-00318273; Closing Account Transfer CAX-2026-0045120 -> ACXF-2026-0045120; Final Transaction MMT-2026-00418273 -> MMVMT-2026-00418273 (CW-114). Object names Account Transfer, Money Movement, Sweep Program and Program Bank resolve as written. The Account Restriction Type 'Financial Exploitation' note '(confirm)' is settled by CW-109.",
    "43 at the W3 merge: Capital Requirement Calculation.Reserve Computation re-typed Reference (Reserve Computation, 49); example RSV-20260930-01 -> RESRV-20260930-C; the relationship 'Capital Requirement Calculation reads Customer Reserve Computation [49]' renamed (CW-103).",
    "Anchors named in the W2 briefs and their drafts to re-point at merge: 45 (CHL-, MMT-, COR-), 46 (CHL-, CLT-, CAA-, COR-, MMT-), 47 (CHL-, CAA-, MMT-), 51 (CHL-, CAA-, MMT-), 13 (CCF-, CHL-, CLT-, CAA-, MMT-), 08 (COR-, CAA-, MMH-), 02 (MMH-, CHL-), 01 (SWP-, COR-), 04 (MMT-). 46 and 13 name the object 'client account activity' / 'Client Account Activity': the object name is Client Account Activity (CLACT-).",
    "ownership.ALIASES: 'tax lot', 'execution', 'trade order', 'block order', 'trade allocation', 'activity' (03) and 'transaction' (06) resolve elsewhere; 48, 49 and 50 qualify every object name ('Client ...') and every reference carries the domain number. Consider adding aliases 'client holding' -> 49, 'client tax lot' -> 49, 'money movement' -> 50 at W5.",
    "CONCEPT_OWNERSHIP at merge: Client Order (48, CLORD-), Client Trade Confirmation (48, CCONF-), Client Holding (49, CLHLD-), Client Tax Lot (49, CTLOT-), Client Account Activity (49, CLACT-), Reserve Computation (49, RESRV-), Account Transfer (49, ACXF-), Money Movement (50, MMVMT-), Sweep Program (50, SWEEP-), Program Bank (50, PGBNK-), Money Movement Hold (50, MMHLD-).",
    "W3 sibling dependencies: 29 brief (CW-097 own-fund omnibus Fund Order and Order Route.Resulting Fund Order; CW-107 29 Cash Movement references 50 for direct-investor payments; Fund Share Transfer name); 16 brief (participant balances stay 16, 49 SME question 9; plan distributions on the recordkeeper rail, 50 SME question 8); 52 brief (third-party product due diligence read through 01 Platform Product Availability); 24 and 32 none.",
    "W4 dependencies: 38 AML Case gains Source Money Movement Monitoring Alert (CW-110) and trade surveillance references to 48 (CW-100); 06 Fund Shareholder Position and Client Assets read 49 Client Holding Valuation (CW-101); 10 reads 50 Sweep Rate Tier and Program Bank Participation economics; 04 may take Market Data Subscriber Status (CW-112).",
    "Shared lists: 48 joins Order Side (steward 25); 49 joins Lot Relief Method and Holding View (steward 18) and Regulatory Trade Report Regime (steward 26) with SEC_RULE_10C_1A; 50 uses Screening Result (08) and records NOT_MERGED Outgoing Payment Status (19) vs Money Movement Status (incoming movements). Candidates for W5: Alert Disposition (29, 50), Cash Flow Category (43, 50), Order Type and Time in Force (25, 48; or LOCAL_RENAMES).",
    "Regulatory status to confirm in Source_Notes: amended Rule 605 compliance date August 1, 2026 (Federal Register 2025-19316) and whether it held; Rule 15c3-3 daily computation compliance date June 30, 2026 (SEC press release 2025-95; threshold USD 500 million average total credits); CAT CAIS amendment approved January 13, 2026 and the February 2025 PII exemption (Release 34-102386); SEC Rule 10c-1a compliance deferral (2028 and 2029); FINRA Rule 4210 intraday margin standard (Regulatory Notice 26-10); FINRA Rule 2165 hold length and SR-FINRA-2026-018; FINRA Rule 11870 current timing and residual credit provisions; NACHA fraud monitoring phase 2 (June 19, 2026, effective June 22); FDIC custodial deposit account recordkeeping proposal status; Rule 17a-13 count timing.",
]

JURISDICTION = []  # New domains (CW-022): nothing carried from a wholesale module.
