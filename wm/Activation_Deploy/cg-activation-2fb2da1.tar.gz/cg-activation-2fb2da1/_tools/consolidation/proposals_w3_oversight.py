"""Wealth-manager reference model: W3 brief decisions for 52 External Manager & Sub-Adviser Oversight (new), the adapted
29 Transfer Agency Operations and 16 Retirement Plan Administration, and the family additions to 24 Portfolio Management
& Construction and 32 Performance & Attribution (CW-116 to CW-130; CW-916, CW-924, CW-929, CW-932), with the prefixes
the briefs reserve and their key formats.

Written by the W3 oversight brief agent with 00_Program/Rework/Briefs/52_External_Manager_and_Sub_Adviser_Oversight.md,
29_Transfer_Agency_Operations.md, 16_Retirement_Plan_Administration.md and W3_24_32_Family_Additions.md. Format: the
DECISIONS dict format and the PREFIXES tuple format of decisions.py (see CONTRACT.md). Declarative only; every decision is
"Proposed" until the program lead merges it, and each states the tailoring lever. The four CW-9NN decisions are drafted
here at brief level (the removals the briefs found); the editors complete them, with their JURISDICTION entries, in
proposals_16.py, proposals_24.py, proposals_29.py and proposals_32.py. 52 is new and has no US-only pass (CW-022).
"""

PL = "Program lead"
P = "Proposed"

DECISIONS = [
    # ---- 52 External Manager & Sub-Adviser Oversight --------------------------------------------------------------
    {"id": "CW-116", "theme": "Ownership", "title": "External managers are 02 parties; their role profile, key persons and strategies are 52",
     "domains": ["02", "05", "14", "52"],
     "issue": "52 needs a record of each sub-adviser, third-party fund or ETF sponsor, private fund manager behind a feeder, model provider and transition manager. 02 Party Role Type has no such values; the wholesale Form ADV Profile moves to 05 at W4 as the intermediary (distributor RIA) profile (CW-023).",
     "resolution": "Every external manager is a 02 Party (PTY-) with a Party Role; 02 Party Role Type gains Sub-Adviser, External Fund Sponsor and Transition Manager. 52 masters External Manager Profile (role profile keyed by PTY-, the Issuer Profile pattern of CD-143), Manager Key Person (manager x individual x role x period) with Background Check Result (outcome only, PII restricted) and External Manager Strategy (EMSTR-). Reported firm and strategy AUM are Derived copies of 14 vendor datasets. The 05 Form ADV Profile (W4) is the intermediary profile; a party that is both keeps one profile per role.",
     "rationale": "One party, many roles (CD-143). Lever: a firm with no external managers drops 52 (plan section 15 item 5).",
     "action": "W3 drafter of 52; 02 owner adds the role values at the W3 merge", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-117", "theme": "Ownership", "title": "The sub-advisory contract and its Section 15(c) renewal stay 35; 52 masters the Sub-Adviser Engagement and its renewal submission",
     "domains": ["01", "35", "39", "52"],
     "issue": "Plan section 5.2 lists 'sub-advisory agreements and Section 15(c) renewal data' under 52 with the anchor SAA-, and the 01 brief names a 52 'Sub-Advisory Agreement (SAA-)'. CD-232 already masters the Fund Advisory Agreement (ADVA-, type Sub-Advisory) and the Advisory Contract Renewal (RENEW-) in 35, with fee terms in 01; CD-237 links board approvals once, from 35.",
     "resolution": "No 52 object is named Sub-Advisory Agreement and SAA- is not used. 52 masters Sub-Adviser Engagement (SADV-; sub-adviser x fund or mandate x sleeve x period: governing 35 ADVA-, 39 CTRCT-, 01 MND- and PRD-, 18 sleeve PORT-, scope, discretion, delegated trading and proxy voting, status, dates) and Section 15(c) Renewal Submission (engagement x 35 RENEW-: questionnaire to and response from the sub-adviser, oversight reviews included, recommendation). Board approval dates are Derived copies read through 35 Resolution Subject Link. Fee rates stay 01 FSCH- through 35 Agreement Fund Schedule. The 01 brief's reference re-points to 35 Fund Advisory Agreement.",
     "rationale": "The contract and the board's judgment already have one owner; 52 adds the oversight team's evidence without a second contract record.",
     "action": "W3 drafter of 52; 01 owner corrects its brief reference", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-118", "theme": "Ownership", "title": "Sub-adviser guidelines: defined in 01 and coded in 33; delivered, acknowledged and certified in 52",
     "domains": ["01", "24", "33", "52"],
     "issue": "Mandate guidelines given to sub-advisers could be held as a third copy of 01 Investment Restriction and 33 Compliance Rule.",
     "resolution": "52 masters Sub-Adviser Guideline Set (GDLN-; engagement x version: effective, delivered and acknowledged dates, custom text, delegated pre-trade checks) with Guideline Rule Inclusion rows that reference 33 Compliance Rule versions (CRULE-) and 01 Investment Restriction (RST-) only, and Sub-Adviser Compliance Certification (engagement x period: quarterly guideline compliance, Rule 38a-1 policies, Rule 17j-1 code of ethics, Rule 206(4)-7 annual review summary; exceptions linked to 33 BREACH-). 33 keeps rule assignment to the sleeve portfolio, checks and breaches; 24 Target Allocation Line keeps sleeve weights.",
     "rationale": "Define once, test once; 52 holds only what passes between the adviser and the sub-adviser.",
     "action": "W3 drafter of 52", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-119", "theme": "Ownership", "title": "Manager due diligence and oversight reviews are 52; their numbers are Derived readings of 32, 31, 33, 01 and 11; manager research is not 23",
     "domains": ["11", "14", "23", "31", "32", "33", "52"],
     "issue": "Oversight reviews compare sub-advisers on returns, risk, breaches, fees and peers that other domains compute; 23 Investment Research covers issuers and securities.",
     "resolution": "52 masters Due Diligence Questionnaire Template, Manager Due Diligence Review (MDILG-) with Due Diligence Score and Onsite Visit, Oversight Review (OVRVW-) with Oversight Metric Reading (value a Derived copy naming its 32 Performance Return or Benchmark Return, 32 Ex-Post Risk Statistic, 31 Portfolio Risk Measures, 33 Investment Breach count, 01 fee or 11 peer source; threshold and flag mastered here), Sub-Adviser Watch Status, Oversight Finding (OVFND-) and Remediation Action. 23 is not used for manager research.",
     "rationale": "The judgment is 52's; the numbers have owners already (CD-217, CD-211).",
     "action": "W3 drafter of 52", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-120", "theme": "Ownership", "title": "Product Due Diligence (TPDUE-) and the approved, watch and restricted lists are 52; availability stays 01",
     "domains": ["01", "16", "17", "24", "36", "45", "46", "52"],
     "issue": "01 Platform Product Availability.Due Diligence Approval is typed Reference (Product Due Diligence, 52) (CW-037; keys_g1_01_02.py). The plan anchor PDD- is one edit from PDL- (30), PRD- (01) and PFD- (11).",
     "resolution": "52 masters Product Due Diligence (exact name; TPDUE-; third-party product (17 INS-) x review: use scope platform, advice models, plan menus, own fund of funds holdings or feeder underlying; sponsor review MDILG-; complex product determination; outcome; approver), Product Due Diligence Criterion Result, Fund of Funds Use Detail (Rule 12d1-4 investment agreement in 39) and Product List Status (product x scope x period: approved, watch, restricted for new recommendations, removed). 01 decides availability and transaction-fee category; 45 (reasonable-basis diligence), 24 Model Building Block and 16 Plan Investment Option read the list status. Own products are 36's product governance, not 52. The 01 example 'Third-party fund review 2026-0412' re-keys to TPDUE-2026-000412.",
     "rationale": "One verdict per product, read by every channel. Lever: an open-architecture platform without curation keeps due diligence for advice models only.",
     "action": "W3 drafter of 52; 01 example re-keyed at the merge", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-121", "theme": "Ownership", "title": "Manager search, selection, manager-of-managers hires, termination and transition are 52; committee decisions 24, board approvals 35",
     "domains": ["13", "18", "24", "35", "52"],
     "issue": "Hiring and firing sub-advisers involves an investment committee, the fund board, exemptive relief and shareholder notice.",
     "resolution": "52 masters Manager Search (MSRCH-), Search Candidate, Search Outcome (with the Rule 15a-4 interim contract indicator), Manager-of-Managers Hire Condition (relied-on 35 Exemptive Relief Reliance, information statement due within the order's period, 13 COMM- sent), Manager Termination and Manager Transition (transition manager, method, 18 Portfolio Lifecycle Event references, cost as a Derived copy of 25). Approvals reference 24 Investment Committee Decision; 24 Committee Decision Type gains Manager Hire, Manager Termination and Third-Party Product Approval, and Investment Committee Type gains Manager Research Committee. Board approvals stay on 35 (CD-237).",
     "rationale": "The selection trail is the evidence the board and the SEC ask for. Lever: no manager-of-managers order drops the hire-condition group and every hire goes to a 35 proxy.",
     "action": "W3 drafters of 52 and 24", "status": P, "priority": "Medium", "owner_role": PL},

    # ---- 29 Transfer Agency Operations ---------------------------------------------------------------------------
    {"id": "CW-122", "theme": "Ownership", "title": "The fund share register is 29 (Share Register Balance, Register Transaction); 06 reads it as a view (amends CD-199 and CD-200)",
     "domains": ["06", "15", "29", "49"],
     "issue": "Plan section 5.1 gives 29 the shareholder register; CW-007 makes 06 Fund Shareholder Position a view of 49 for direct accounts and of TA data for the rest; the wholesale 06 masters the confirmed transaction (TXN-, CD-199) and the position (POS-).",
     "resolution": "29 masters Share Register Balance (registered account x share class x business date: registered, collected and uncollected, escrowed or pledged and restricted shares; register account category Fund-Only, Broker-Dealer Omnibus, Intermediary Omnibus, Networked, Plan Omnibus, DTC Nominee, CIT Unitholder; no value) and Register Transaction (RGTX-; the Rule 17Ad-10 posting: type, dates, shares, NAV applied, amounts, originating Fund Order, AP order or 27 distribution, status). Fund Order.Resulting Transaction and AP Resulting Transaction keep their names, re-typed to Register Transaction. 06 Fund Shareholder Position is a view of 49 Client Holding for brokerage accounts and of 29 Share Register Balance for every other registered account; 06 Transaction becomes a firm-wide flow fact referencing 29, 49 and intermediary feeds (W4 06 brief). 49 Stock Record Reconciliation owns the 49-to-29 omnibus reconciliation. Lots of fund-only accounts are 49 Client Tax Lots (CW-034).",
     "rationale": "The TA is the registrar of record; 06 summarizes across channels. Lever: lots of fund-only accounts kept on the TA platform as a 29 object.",
     "action": "W3 editor of 29; W4 06 brief applies the 06 side", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-123", "theme": "Ownership", "title": "29 order hand-off and monitoring: Brokerage Omnibus Order Detail; account monitoring split 29, 50, 38 and 08",
     "domains": ["08", "29", "38", "48", "50"],
     "issue": "CW-097 aggregates brokerage own-fund orders into one 29 Fund Order per share class and dealing cycle and CW-107 puts every client payment in 50; 29 Account Monitoring Alert overlaps 50 cash-movement monitoring.",
     "resolution": "Fund Order gains Brokerage Omnibus Order Detail (aggregation date and cycle, client order count and gross amounts as Derived copies of 48, netting indicator); the 48 Client Order holds the Resulting Fund Order link. Fund-only accounts' orders are 29 only. Cash Movement keeps fund-side settlement and adds Client Money Movement (Reference (Money Movement, 50), MMVMT-). Account Monitoring Alert covers dealing-triggered alerts on shareholder accounts and adds Triggering Money Movement (50); cash-movement monitoring is 50, the AML program and cases 38, frequent trading cases 08 (FTC-).",
     "rationale": "Applies CW-097 and CW-107 without copying client orders or payments.",
     "action": "W3 editor of 29", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-124", "theme": "Ownership", "title": "29 drops CIP Verification and retires CIP- (applies CW-025); receives the three 13 objects of CW-088",
     "domains": ["02", "13", "15", "29"],
     "issue": "CW-025 asks the 29 brief whether an outsourced-TA case needs a received CIP copy; CW-088 moves Servicing Provider Engagement, Intermediary Distribution Request (BOD-) and NOBO List Request from 13 to 29.",
     "resolution": "Default in-house TA: CIP Verification and its five lists leave 29; fund-only account opening references 02 Identity Verification (KYCV-, CIP Program Mutual Fund CIP) through 15 Account Opening; CIP- is Retired. DP-180 re-points. The three 13 objects move with names, attributes, lists and BOD- unchanged; Servicing Provider Engagement covers TA service providers (sub-TA, print, escheat, proxy). Lever: an outsourced TA restores a received-copy object.",
     "rationale": "Identity is mastered once (CW-025); the register work runs where the register is.",
     "action": "W3 editor of 29; program lead updates PREFIXES (CIP- Retired, BOD- owner 29)", "status": P, "priority": "Medium", "owner_role": PL},

    # ---- 16 Retirement Plan Administration -----------------------------------------------------------------------
    {"id": "CW-125", "theme": "Ownership", "title": "16 is the participant book of record: Participant Balance and Participant Ledger Posting; 06 references re-typed (applies CW-915)",
     "domains": ["06", "15", "16", "29", "46", "49"],
     "issue": "The W1 merge ruled that participant balances are mastered in 16, but the module holds no balance object and types its postings Reference (Transaction) and Reference (Position) to 06.",
     "resolution": "16 masters Participant Balance (membership x money source x investment option x valuation date: units, unit value, market value, vested amount Derived) and Participant Ledger Posting (PLPST-), plus Participant Investment Transfer (PEXC-; participant exchange or rebalance, including those sourced from 46 Trade Proposals, TRPR-). Contribution Record.Posting Transaction, Participant Loan.Disbursement Transaction, Forfeiture Record.Forfeiture Transaction, Distribution Request.Settlement Transactions and Fund Change Event.Mapping Transactions keep their names, re-typed to Participant Ledger Posting; Vested Balance by Source.Source Position references Participant Balance; Form 5500 plan assets and participant counts are Derived. The plan's omnibus account at the TA is a 29 Share Register Balance. Brokerage windows and IRAs are 49. 15 holds no amount.",
     "rationale": "Names the recordkeeping book of record distinctly from the three books of CW-007. Lever: a platform merge moves participant balances to 49.",
     "action": "W3 editor of 16", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-126", "theme": "Ownership", "title": "Rollover capture: Participant Retail Hand-Off and Rollover Contribution Detail are 16; the advice is 45",
     "domains": ["04", "06", "13", "15", "16", "45"],
     "issue": "Acceptance question 10 (participants separated and the share rolled into the direct business) has no record joining the separation, the advice and the receiving account.",
     "resolution": "16 masters Participant Retail Hand-Off (PRTHO-; membership x trigger: separation, retirement, in-service eligibility, RMD age, small-balance notice; consent to contact; referral to a 45 Advice Engagement or 03 advisor; outcome and date; linked Distribution Request and receiving 15 account; amount Derived) and Rollover Contribution Detail (AG of Contribution Record for incoming rollovers). Distribution Request gains Receiving Account and Originating Hand-Off. 45 keeps Recommendation, Rollover Analysis and PTE 2020-02 documentation (CW-045); 08 the review; 04 the acquisition milestone; 06 the capture rate; 13 the interactions.",
     "rationale": "One record per opportunity makes the capture rate computable without copying advice evidence.",
     "action": "W3 editor of 16", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-127", "theme": "Ownership", "title": "Plan sponsor, recordkeeper and plan profiles move into 16 (applies CW-023); managed accounts in plan split 16, 15 and 46",
     "domains": ["02", "12", "15", "16", "39", "46", "47"],
     "issue": "CW-023 moves Recordkeeper Profile, Plan Service Provider and the Retirement Plan statistics from 02 to 16 at W3. Managed accounts in plan touch the plan, the participant account, the model and the fee.",
     "resolution": "16 gains Plan Sponsor Profile (role profile keyed by the sponsor PTY-), Recordkeeper Profile (name kept), Plan Service Provider (name kept, attribute group of Plan Role Assignment) and Retirement Plan Profile (plan x plan year; assets, participants, QDIA type and fiduciary type as Derived copies of 16 facts); the UK Pension Scheme Registry Number is not restored (CW-916). Service Arrangement.Governing Agreement re-types to 39 Contract. Plan fee terms stay 16 (CW-051). Sponsor servicing and reporting are 12 (W4). Managed accounts: 16 Plan Managed Account Service (plan x 01 offering x period; QDIA designation, fiduciary basis, fee reference); 15 Program Enrollment on the participant account; 46 Model Assignment at participant-account grain, reading balances, deferral rates and salary as Derived copies of 16; 46 trade proposals executed as 16 Participant Investment Transfers.",
     "rationale": "The plan facts stay with the recordkeeper; advice and models stay with their owners.",
     "action": "W3 editor of 16", "status": P, "priority": "Medium", "owner_role": PL},

    # ---- 24 and 32 ------------------------------------------------------------------------------------------------
    {"id": "CW-128", "theme": "Ownership", "title": "24 gains Capital Market Assumptions and Advice Model Construction; Decision Algorithm re-typed to 37; Tax Budget per CW-048",
     "domains": ["01", "24", "37", "45", "46", "52"],
     "issue": "45 references a 24 Capital Market Assumption Set (CW-046); 46 consumes model weights and lineups (CW-047); the W1b pass removed 37 Trading Algorithm Code, leaving 24 Investment Decision.Decision Algorithm Code without a source.",
     "resolution": "24 masters Capital Market Assumption Set (CMASET-; exact name), Asset Class Return Assumption and Asset Class Correlation Assumption; Model Lineup (MLNUP-), Model Lineup Position (lineup version x model: risk band on the 02 profile scale, horizon band, retirement-date position) and Model Building Block (model x share class or instrument x role x period, with the 52 Product List Status read as a Derived copy). Asset Allocation Policy gains Policy CMA Set and Policy Purpose. Decision Algorithm Code is replaced by Decision Algorithm (Reference (Model Inventory Entry, 37)); Tax Budget drops Budget Account (46). 45 recommends from and 46 assigns from Model Lineup Position by reference; 46 owns substantial identity.",
     "rationale": "Every advice number starts from the CMAs and the lineup; one owner for each. Lever: licensed CMAs become a 14 dataset approved in 24.",
     "action": "W3 editor of 24", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-129", "theme": "Certified numbers", "title": "Personal Rate of Return is mastered in the 32 Client Account Performance family, separate from Performance Return",
     "domains": ["13", "16", "32", "45", "46", "47", "49"],
     "issue": "CW-011 certifies Personal Rate of Return (client-level time-weighted and money-weighted returns, owned by Performance, DP-145 extended). 32 Performance Return already accepts an account subject.",
     "resolution": "32 masters Client Performance Profile, Household Performance Group (HPGRP-) and Member, Personal Rate of Return (PRROR-; account or group x period x method x fee basis x version; values and flows as Derived copies of 49, 16 and 47) and Client Return Exception. Performance Return's account subject is limited to institutional separate accounts; Measured Subject Type gains Managed Account Composite (CW-050). GIPS does not apply to personal returns; no retail account enters 32 Composite Membership. 13, 45 and the semantic layer read the metric; it is defined once.",
     "rationale": "Retail scale, household grain and a separate certification justify a separate object. Lever: a firm without personal performance reporting drops the family.",
     "action": "W3 editor of 32; WP1 extends DP-145", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-130", "theme": "Identifiers", "title": "Prefixes, key formats, term conflicts and personal data of the W3 oversight briefs; plan anchors of 52 rejected",
     "domains": ["16", "24", "29", "32", "52"],
     "issue": "The plan anchors MGR-, MDD-, SAA-, PDD- are each one edit from a registered prefix or another anchor.",
     "resolution": "Reserve 52: EMSTR-, MSRCH-, MDILG-, SADV-, GDLN-, OVRVW-, OVFND-, TPDUE-; 29: RGTX- (BOD- transferred from 13; CIP- retired); 16: PLPST-, PEXC-, PRTHO-; 24: CMASET-, MLNUP-; 32: PRROR-, HPGRP-. Formats in PREFIX_FORMATS; composite keys in GRAIN_KEY_FORMATS. Term conflicts to log at W5 in TERM_CONFLICTS below. Personal data: 52 key persons and background checks are identity (restricted); 29, 16 and 32 participant and shareholder amounts are financial; 16 hardship reasons are special category (CD-344).",
     "rationale": "Same discipline as CW-059 and CW-114.",
     "action": "Program lead at the W3 merge", "status": P, "priority": "Low", "owner_role": PL},

    # ---- US-only passes (pre-allocated by CW-022; completed by the editors) ---------------------------------------
    {"id": "CW-916", "theme": "Scope", "title": "US-only pass of 16 Retirement Plan Administration", "domains": ["16"],
     "issue": "The wholesale 16 is already US only (META 'Scope: US'); the grep for MiFID, UCITS, ESMA, PRIIP, UK, EU, FCA and GDPR finds nothing. The 02 Retirement Plan statistics restored under CW-023 include UK Pension Scheme Registry Number.",
     "resolution": "One JURISDICTION entry (Other EU/UK): 02 Retirement Plan.UK Pension Scheme Registry Number not restored. Perspective rewritten to 'Wealth manager (direct) | Scope: US'. Record Metadata dropped under CW-020 (not a jurisdiction item).",
     "rationale": "CW-003, CW-022.", "action": "W3 editor of 16 (proposals_16.py)", "status": P, "priority": "Low", "owner_role": PL},

    {"id": "CW-924", "theme": "Scope", "title": "US-only pass of 24 Portfolio Management & Construction", "domains": ["24", "37"],
     "issue": "24 carries MiFIR RTS 22 fields and sources on Investment Decision (fields 57 and 58), GDPR notes and 'US + EU/UK' perspective.",
     "resolution": "Remove Investment Decision.Decision Supervising Branch Country and Decision Algorithm Code (MiFIR; the latter replaced by Decision Algorithm, Reference (Model Inventory Entry, 37), CW-128); re-source the RTS 22 references on Investment Decision ID, Decision Maker, Decision Timestamp, Investment Decision Scope, Target Allocation Set, Proposed Trade and PM Assignment.Decision Authority Indicator to Advisers Act Rule 204-2(a)(3); remove the Delegated Regulation (EU) 2017/590 source and GDPR wording; Business Line examples to CW-004 codes. References to 30 left for W4.",
     "rationale": "CW-003, CW-022.", "action": "W3 editor of 24 (proposals_24.py)", "status": P, "priority": "Low", "owner_role": PL},

    {"id": "CW-929", "theme": "Scope", "title": "US-only pass of 29 Transfer Agency Operations", "domains": ["29", "06", "05"],
     "issue": "29 carries EU order routing and settlement platforms (Calastone, Clearstream Vestima, Euroclear FundSettle, Allfunds, SWIFT), EU/UK payment rails, UK and EU customer due diligence values, FCA COLL and JMLSG sources and 'US + EU/UK' perspective.",
     "resolution": "Remove Order Routing Detail.Platform Order Reference; Dealing Route values CALASTONE, CLEARSTREAM_VESTIMA, EUROCLEAR_FUNDSETTLE, ALLFUNDS, SWIFT_DIRECT (local copy; shared list steward 06 at W4); Order Settlement Method and shared Fund Dealing Settlement Method values Calastone and ICSD (add AFFILIATED_BD_OMNIBUS); Order Payment Method values CHAPS, SEPA Credit Transfer, TARGET2, Bacs Direct Debit; the UK and EU CIP list values (with the object under CW-124); secondary references UK FCA COLL, JMLSG, Calastone, UK OFSI; sources Calastone, Clearstream/Euroclear/Allfunds, FCA COLL 6.2, 6.3, 7.2, UK MLR 2017 and JMLSG; re-source dealing suspension to Investment Company Act section 22(e); perspective and GDPR notes rewritten. Insurance-dedicated values (Insurance Company Instruction, Insurer Feed) removed as out of scope (CW-004), not jurisdiction.",
     "rationale": "CW-003, CW-022.", "action": "W3 editor of 29 (proposals_29.py)", "status": P, "priority": "Low", "owner_role": PL},

    {"id": "CW-932", "theme": "Scope", "title": "US-only pass of 32 Performance & Attribution", "domains": ["32"],
     "issue": "32 cites UCITS KIID past performance (Regulation (EU) 583/2010), PRIIPs (2017/653) and AIFMD Annex IV, uses a GIPS Firm Definition example naming UK advisers, GDPR notes and 'US + EU/UK' perspective.",
     "resolution": "Remove the UCITS KIID and PRIIPs sources and the AIFMD half of the Form PF source; re-word the GIPS Firm Definition example; personal data notes to Reg S-P and state law; Business Line examples to CW-004 codes. Private Markets Performance stays (CD-219); references to 30 left for W4.",
     "rationale": "CW-003, CW-022.", "action": "W3 editor of 32 (proposals_32.py)", "status": P, "priority": "Low", "owner_role": PL},
]

# ---------------------------------------------------------------------------------------------------------------------
# Reserved prefixes (decisions.PREFIXES tuple format). Near-misses rejected (checked against decisions.PREFIXES, every
# proposals_*.py, the plan section 5.2 anchors, the W2 and W3 briefs, content-module tokens, DP-/FN-/SM-/CD-/CW-, L1 codes):
#   EMSTR-: MSTR- (STR- 01, MSR- 06); plan anchor MGR- (AGR- 05, MSR- 06, MRR- 11, anagram MRG token 15); XMGR-, MGSR-
#   MSRCH-: SRCH- (SRCG- 40)
#   MDILG-: plan anchor MDD- (MND-, MDL- 01, TDD- 51 anchor, PDD-); MGDD-, DDRV- (DRV- 10), MDDQ- (DDQ- 08, MEDQ- 42); PDILG- (one edit)
#   SADV-:  plan anchor SAA- (SKA- 28, SPA- 08, SVA-, SLA- 12, CAA- 49 anchor); SAENG- (AENG-, 45 brief); two edits from ADVA- (35), noted
#   GDLN-:  SAGL- (reads as SADV-), SGDL-
#   OVRVW-: OVRV-, OVSR-, MOVR-, OVRW- (OVR- 06); OVREV- (AVREV- 45); OSREV- (SREV-, 08 brief)
#   OVFND-: OFND- (anagram FNDO- 29), MFND- (MND- 01)
#   TPDUE-: plan anchor PDD- (PDL- 30, PRD- 01, PFD- 11); PRDD- (PRD-, PRMD- 16), TPDD-, XPDD-, PDRV- (DRV- 10), TPRV- (SPRV-, 08 brief)
#   RGTX-:  RTXN- (PTXN- 18, TXN- 06); REGT-, SRTX- read as other words
#   PLPST-: PLGP- (PLDP- 16)
#   PEXC-:  PXFR- (PFR- 10), PITR- (anagram TRIP- 44), PXCH- (PFCH- 16)
#   PRTHO-: PRHO-, PRHOF- (PRMO-, PROF-, 04 brief), PHOF- (PROF-)
#   CMASET-: CMAS- (MAS- 46 anchor), CMA- (CMC- 28, AMA- 29, CMP- 01)
#   MLNUP-: MLIN- (MIN- 11), MDLU- (MDL- 01)
#   PRROR-: PRR- (PRD- 01, CRR- 07, FRR- 10), PRRT- (PORT- 18), CPRR- (CRR- 07, CORR- 08), PROR- (PROL-, PFOR-, PCOR- 16)
#   HPGRP-: HHPG-, HPG- (HH- retired 02 prefix)
# ---------------------------------------------------------------------------------------------------------------------
R = "Reserved"

PREFIXES = [
    ("EMSTR-", "External manager strategy (manager x strategy researched)", "52", R, "W3 brief 52 (CW-116). Plan anchor MGR- rejected; rejected MSTR-, XMGR-, MGSR-."),
    ("MSRCH-", "Manager search", "52", R, "W3 brief 52 (CW-121). Rejected SRCH-."),
    ("MDILG-", "Manager due diligence review", "52", R, "W3 brief 52 (CW-119). Plan anchor MDD- rejected; rejected MGDD-, DDRV-, MDDQ-."),
    ("SADV-", "Sub-adviser engagement (sub-adviser x fund or mandate x sleeve x period)", "52", R, "W3 brief 52 (CW-117). Plan anchor SAA- rejected; rejected SAENG-; two edits from ADVA- (35)."),
    ("GDLN-", "Sub-adviser guideline set (engagement x version)", "52", R, "W3 brief 52 (CW-118). Rejected SAGL-, SGDL-."),
    ("OVRVW-", "Oversight review (sub-adviser engagement or approved product x review)", "52", R, "W3 brief 52 (CW-119). Rejected OVRV-, OVSR-, MOVR-, OVRW-, OVREV-, OSREV-."),
    ("OVFND-", "Oversight finding", "52", R, "W3 brief 52 (CW-119). Rejected OFND-, MFND-."),
    ("TPDUE-", "Product due diligence (third-party product x review)", "52", R, "W3 brief 52 (CW-120). Plan anchor PDD- rejected; rejected PRDD-, TPDD-, XPDD-, PDRV-, TPRV-. 01 example re-keyed."),
    ("RGTX-", "Register transaction (posted share movement on the TA register)", "29", R, "W3 brief 29 (CW-122). Rejected RTXN-, REGT-, SRTX-."),
    ("PLPST-", "Participant ledger posting", "16", R, "W3 brief 16 (CW-125). Rejected PLGP-."),
    ("PEXC-", "Participant investment transfer (exchange or rebalance between plan options)", "16", R, "W3 brief 16 (CW-125). Rejected PXFR-, PITR-, PXCH-."),
    ("PRTHO-", "Participant retail hand-off (membership x trigger event)", "16", R, "W3 brief 16 (CW-126). Rejected PRHO-, PRHOF-, PHOF-."),
    ("CMASET-", "Capital market assumption set (versioned)", "24", R, "W3 brief 24/32 (CW-128). Rejected CMAS-, CMA-."),
    ("MLNUP-", "Model lineup (versioned ladder of model portfolios)", "24", R, "W3 brief 24/32 (CW-128). Rejected MLIN-, MDLU-."),
    ("PRROR-", "Personal rate of return (subject x period x method x fee basis x version)", "32", R, "W3 brief 24/32 (CW-129). Rejected PRR-, PRRT-, CPRR-, PROR-."),
    ("HPGRP-", "Household performance group", "32", R, "W3 brief 24/32 (CW-129). Rejected HHPG-, HPG-."),
]

# Register changes for the program lead at the merge (CW-124).
TRANSFER_PREFIXES = {"BOD-": ("13", "29")}
RETIRE_PREFIXES = {"CIP-": ("29", "CW-124: identity verification is 02 Identity Verification (KYCV-), CW-025")}

# Proposed key formats (decisions.PREFIX_FORMATS tuple format: prefix, domain, format, example).
PREFIX_FORMATS = [
    ("EMSTR-", "52", "EMSTR-<sequence, 6 digits>", "EMSTR-004187"),
    ("MSRCH-", "52", "MSRCH-<year>-<sequence, 4 digits>", "MSRCH-2026-0031"),
    ("MDILG-", "52", "MDILG-<year>-<sequence, 5 digits>", "MDILG-2026-00418"),
    ("SADV-", "52", "SADV-<sequence, 5 digits>", "SADV-00412"),
    ("GDLN-", "52", "GDLN-<SADV- sequence, 5 digits>-<version, 2 digits>", "GDLN-00412-03"),
    ("OVRVW-", "52", "OVRVW-<year>-<sequence, 6 digits>", "OVRVW-2026-001877"),
    ("OVFND-", "52", "OVFND-<year>-<sequence, 5 digits>", "OVFND-2026-00213"),
    ("TPDUE-", "52", "TPDUE-<year>-<sequence, 6 digits>", "TPDUE-2026-000412"),
    ("RGTX-", "29", "RGTX-<year>-<sequence, 10 digits>", "RGTX-2026-0004188273"),
    ("PLPST-", "16", "PLPST-<year>-<sequence, 10 digits>", "PLPST-2026-0091220417"),
    ("PEXC-", "16", "PEXC-<year>-<sequence, 7 digits>", "PEXC-2026-0041877"),
    ("PRTHO-", "16", "PRTHO-<year>-<sequence, 7 digits>", "PRTHO-2026-0003318"),
    ("CMASET-", "24", "CMASET-<year>-<sequence, 3 digits>; the version is a separate attribute", "CMASET-2026-001"),
    ("MLNUP-", "24", "MLNUP-<sequence, 4 digits>; the version is a separate attribute", "MLNUP-0007"),
    ("PRROR-", "32", "PRROR-<year>-<sequence, 12 digits>; the version is a separate attribute", "PRROR-2026-000041882203"),
    ("HPGRP-", "32", "HPGRP-<sequence, 8 digits>", "HPGRP-00418822"),
]
KEY_FORMATS = PREFIX_FORMATS  # alias named in the W3 assignment

# Composite keys (decisions.GRAIN_KEY_FORMATS tuple format: object, domain, format, example).
GRAIN_KEY_FORMATS = [
    ("External Manager Profile", "52", "<PTY- id of the manager>", "PTY-100912"),
    ("Manager Key Person", "52", "<manager PTY-> / <person PTY-> / <role> / <effective from>", "PTY-100912 / PTY-204471 / Lead Portfolio Manager / 2021-03-01"),
    ("Search Candidate", "52", "<MSRCH- id> / <EMSTR- id>", "MSRCH-2026-0031 / EMSTR-004187"),
    ("Due Diligence Score", "52", "<MDILG- id> / <scoring factor code>", "MDILG-2026-00418 / PROCESS"),
    ("Guideline Rule Inclusion", "52", "<GDLN- id> / <CRULE- id or RST- id>", "GDLN-00412-03 / CRULE-004512"),
    ("Sub-Adviser Compliance Certification", "52", "<SADV- id> / <certification type> / <period end>", "SADV-00412 / QUARTERLY_GUIDELINE / 2026-09-30"),
    ("Oversight Metric Reading", "52", "<OVRVW- id> / <metric code>", "OVRVW-2026-001877 / EXCESS_RETURN_3Y"),
    ("Sub-Adviser Watch Status", "52", "<SADV- id> / <effective from>", "SADV-00412 / 2026-07-15"),
    ("Section 15(c) Renewal Submission", "52", "<SADV- id> / <RENEW- id>", "SADV-00412 / RENEW-00041-2026"),
    ("Remediation Action", "52", "<OVFND- id> / <sequence>", "OVFND-2026-00213 / 2"),
    ("Product Due Diligence Criterion Result", "52", "<TPDUE- id> / <criterion code>", "TPDUE-2026-000412 / EXPENSE_RATIO_PEER"),
    ("Product List Status", "52", "<INS- id> / <list scope> / <effective from>", "INS-00418822 / PLATFORM / 2026-06-01"),
    ("Manager Termination", "52", "<SADV- id> / <termination effective date>", "SADV-00412 / 2026-12-31"),
    ("Share Register Balance", "29", "<ACC- id> / <SHC- id> / <business date>", "ACC-0049812 / SHC-004512 / 2026-10-05"),
    ("Participant Balance", "16", "<PMEM- id> / <money source code> / <PINV- id> / <valuation date>", "PMEM-301121-004471 / EE_PRETAX / PINV-301121-014 / 2026-09-30"),
    ("Participant Distribution Election", "16", "<PMEM- id> / <election type> / <effective from>", "PMEM-301121-004471 / WITHHOLDING / 2026-01-01"),
    ("Participant Service Election", "16", "<PMEM- id> / <election type> / <effective from>", "PMEM-301121-004471 / AUTO_PORTABILITY_OPT_OUT / 2026-02-01"),
    ("Plan Managed Account Service", "16", "<plan PTY-> / <OFFR- id> / <effective from>", "PTY-301121 / OFFR-0012 / 2026-01-01"),
    ("Retirement Plan Profile", "16", "<plan PTY-> / <plan year>", "PTY-301121 / 2025"),
    ("Asset Class Return Assumption", "24", "<CMASET- id> / <version> / <asset class code>", "CMASET-2026-001 / 2 / EQUITY_US"),
    ("Asset Class Correlation Assumption", "24", "<CMASET- id> / <version> / <asset class code> / <asset class code>", "CMASET-2026-001 / 2 / EQUITY_US / FIXED_INCOME_US"),
    ("Model Lineup Position", "24", "<MLNUP- id> / <version> / <MDL- id>", "MLNUP-0007 / 3 / MDL-0077"),
    ("Model Building Block", "24", "<MDL- id> / <SHC- or INS- id> / <role> / <effective from>", "MDL-0077 / SHC-004512 / PRIMARY / 2026-01-01"),
    ("Client Performance Profile", "32", "<ACC- or HPGRP- id> / <effective from>", "ACC-0049812 / 2024-03-04"),
    ("Household Performance Group Member", "32", "<HPGRP- id> / <ACC- id> / <effective from>", "HPGRP-00418822 / ACC-0049812 / 2024-03-04"),
    ("Client Return Exception", "32", "<ACC- id> / <date> / <exception type>", "ACC-0049812 / 2026-09-30 / MISSING_PRICE"),
]

# Term conflicts to log at W5 (decisions.TERM_CONFLICTS dict format, abbreviated).
TERM_CONFLICTS = [
    {"term": "Manager (wealth model)",
     "usages": [("52", "External Manager Profile", "An external investment firm the firm hires or whose products it vets."),
                ("20", "Employee (people manager)", "A line manager."),
                ("24", "Portfolio Management Assignment", "An employee managing a portfolio.")],
     "recommendation": "Never bare: 'External Manager' (52), 'Portfolio Manager' (24, 01), 'line manager' (20).",
     "resolution": "No unqualified primary sense.", "status": "SME", "decision": "CW-116"},
    {"term": "Due Diligence (wealth model)",
     "usages": [("52", "Manager Due Diligence Review; Product Due Diligence", "Research review of a manager or third-party product."),
                ("02", "Customer Due Diligence", "KYC state of a client (31 CFR 1010.230).")],
     "recommendation": "Qualify as 'Manager Due Diligence', 'Product Due Diligence' (52) or 'Customer Due Diligence' (02).",
     "resolution": "No unqualified primary sense.", "status": "SME", "decision": "CW-119"},
    {"term": "Balance (wealth model)",
     "usages": [("16", "Participant Balance", "Recordkept participant balance by money source and option."),
                ("29", "Share Register Balance", "Shares registered at the transfer agent."),
                ("49", "Client Holding; Sweep Balance", "Brokerage book of record."),
                ("50", "Sweep Allocation", "Program bank allocation.")],
     "recommendation": "Always qualified; none is a Holding or Position (CW-007).",
     "resolution": "No unqualified primary sense.", "status": "SME", "decision": "CW-125"},
    {"term": "Transaction (wealth model)",
     "usages": [("29", "Register Transaction", "Posted share movement on the TA register."),
                ("06", "Transaction", "Firm-wide flow fact (W4)."),
                ("18", "Portfolio Transaction", "IBOR booking."),
                ("49", "Client Account Activity", "Brokerage activity."),
                ("16", "Participant Ledger Posting", "Recordkeeping posting.")],
     "recommendation": "Qualify every use; bare 'Transaction' is the 06 flow fact only.",
     "resolution": "Primary sense: 06 Transaction (flow fact).", "status": "SME", "decision": "CW-122"},
    {"term": "Return (wealth model)",
     "usages": [("32", "Performance Return", "Official return of a fund, portfolio, composite or model."),
                ("32", "Personal Rate of Return", "Certified client account or household return (CW-011).")],
     "recommendation": "'Personal Rate of Return' for clients; 'Performance Return' otherwise.",
     "resolution": "Two named objects in 32.", "status": "SME", "decision": "CW-129"},
]

NOTES = [
    "Ids: CW-116 to CW-130 used; CW-916, CW-924, CW-929 and CW-932 drafted at brief level for the editors to complete with JURISDICTION entries in proposals_16.py, proposals_24.py, proposals_29.py and proposals_32.py.",
    "Requests to other owners at the W3 merge: 02 Party Role Type gains Sub-Adviser, External Fund Sponsor, Transition Manager (CW-116); 24 Committee Decision Type gains CMA Approval, Model Lineup Approval, Manager Hire, Manager Termination, Third-Party Product Approval and Investment Committee Type gains Manager Research Committee (CW-121, CW-128); 01 brief reference 'Sub-Advisory Agreement (SAA-)' re-points to 35 Fund Advisory Agreement (CW-117) and the 01 Due Diligence Approval example re-keys to TPDUE- (CW-120); shared Fund Dealing Settlement Method gains AFFILIATED_BD_OMNIBUS and loses CALASTONE_SETTLEMENT and ICSD_CLEARSTREAM_EUROCLEAR (CW-929); shared Dealing Route EU values listed for the W4 06 re-cut.",
    "Brief corrections for the 13 and 15 owners: their briefs cite the 29 fund order as TAO-; the registered key is FNDO-.",
    "For the 15 owner: Plan Participant Account repeats membership facts of 16 (status, enrollment date, default investment indicator); propose Derived copies of 16 PMEM- (CW-125).",
    "For the 46 owner: Sleeve Assignment references Sub-Adviser Engagement (SADV-), not MGR- (CW-117).",
    "For the 49 owner: lots of fund-only accounts are Client Tax Lots under CW-034 and CW-122 (49 brief silent); the 49-to-29 omnibus reconciliation is 49 Stock Record Reconciliation (49 brief agrees).",
    "For the W4 06 brief: CW-122 moves the confirmed TA transaction from 06 Transaction to 29 Register Transaction and makes 06 Fund Shareholder Position a view of 49 and 29 (amends CD-199, CD-200).",
    "Program-lead ruling requested: 16's attribute band widened to 320-345 (precedent: 01 at W1); fallback lever in the 16 brief section 11.",
    "W4 (30 retirement) candidates seen: 24 Decision Scope Deal, Commitment Pacing Plan, Committee Decision Type 'Private Investment Approval'; 32 references to Private Investment, Investor Commitment, Investor Capital Account, Fund Credit Facility.",
    "Example drift seen in 16 (not edited): STMT-2027-1099R-0071188 (content_16 line 365) does not follow the STMT- format; Plan Conversion REL names 'Employee [09]' for a 20 object.",
    "Unverified, marked 'confirm' in the briefs: SEC exemptive-order page path; Rule 17a-10 not cited; FINRA Regulatory Notice 22-08 path; Reg BI section path; ILPA and AIMA DDQ paths; IRS Notice 2020-62; SECURE 2.0 sections 120 and 127; DOL Advisory Opinion 2001-09A and 29 CFR 2550.408g-1 path; DOL target-date tips page; SEC marketing-rule FAQ position on one-on-one personal performance; GIPS calculation guidance path; FINRA Rule 2231 treatment of statement returns; DTCC Omni/SERV path.",
]
