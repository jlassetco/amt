"""Consolidation proposals from Data Domain 05 - Intermediary & Institutional Distribution (wealth model W4 draft v0.1,
2026-10-15; replaces the wholesale 05 Distribution Agreements & Partners, CW-013, CW-131).

Proposal fragment only: the builder does not read it. The program lead merges accepted entries into decisions.py,
shared_code_lists.py and jurisdiction.py at the W4 merge. Format follows CONTRACT.md in this folder (DECISIONS dict format,
PREFIXES tuple format, the jurisdiction.py REMOVALS entry format, decisions.TERM_CONFLICTS format). The brief names this file
proposals_05.py; the assignment named it proposals_w4_05.py, which is used. The content module is
content_05_intermediary_and_institutional_distribution.py, written beside the wholesale content_05_distribution_agreements_and_partners.py.
"""

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES beyond the reserved ones: none. The module uses the kept AGR- (amendments AGR-n-Ann, obligations AGR-n-OBnn),
#    PYA-, PCL-, PMT-, PGM-, SHF-; the restored OPP-, RFP-, DBS- (03), DDQ- (08, findings DDQ-n-Fnn), IFI- (13); the reserved
#    PCVG- and MDEV- (proposals_w4_channels.py PREFIXES, PREFIX_FORMATS). Profiles are keyed by 02 PTY-; the other objects keep
#    the composite keys of proposals_w4_channels.py GRAIN_KEY_FORMATS. Until the merge moves OPP-, RFP-, DDQ- and IFI- to owner
#    05, enrich_05.py OWNERSHIP_OVERRIDES forces the internal references that carry those prefixes to "mastered here".
#    DOC-, ANS- and KAP- appear nowhere in the module (RETIRE_PREFIXES of proposals_w4_channels.py).
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS: local lists in 05 carrying the exact name and (US) values of an enterprise shared list.
#    (local list name in 05, shared list name, instruction for the consolidation step)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    ("Distribution Channel", "Distribution Channel",
     "Replace member ('05', 'Partner Channel') by ('05', 'Distribution Channel') (CW-140). Local copy of the CW-164 re-cut with the "
     "CW-139 refinement (RETIREMENT_DCIO -> INTERMEDIARY_RECORDKEEPER): the WORKPLACE, INSTITUTIONAL and INTERMEDIARY values only "
     "(05 never assigns a DIRECT_ value). Labels proposed for the new codes are in VALUE_MAPS; the steward 09 applies the list at W5. "
     "Used by Distributor Firm.Distribution Channel, Agreement Distribution Scope.Permitted Channels, Sales Opportunity.Opportunity Sales Channel."),
    ("Distribution Market", "Distribution Market",
     "Remove member ('05', 'Agreement Market'): the attribute is not carried and the list retires (CW-164). No 05 local list."),
    ("Qualification Exam", "Qualification Exam",
     "New member ('05', 'Qualification Exam'), re-registered from 02 (CW-132, CW-140); all ten shared labels copied, including Series 99. "
     "Used by Financial Professional.Qualification Exams."),
    ("Data Vendor", "Data Provider",
     "New member ('05', 'Data Vendor'), re-registered from 02 (CW-132, CW-140); the seven wholesale 02 labels, map in VALUE_MAPS. "
     "Labels are the shared Data Provider labels (Cerulli Associates, Nasdaq eVestment); the wholesale 02 labels are the old-to-new map in "
     "VALUE_MAPS_OLD. Used by External Classification.Classification Vendor."),
    ("Agreement Status", "Agreement Status", "Keep ('05', 'Agreement Status'); steward 05; all ten shared labels copied."),
    ("Networking Level", "Networking Level", "Keep ('05', 'Networking Level'); all five shared labels copied."),
    ("Dealing Route", "Dealing Route",
     "Keep ('05', 'Dealing Route'); local values are the CW-140 re-cut (Calastone, Clearstream Vestima, Euroclear FundSettle and Allfunds "
     "removed under CW-905; Own Broker-Dealer Omnibus added as OWN_BD_OMNIBUS). Until the steward re-cuts the shared list, the "
     "consolidated 05 workbook shows the four EU values (as 02 showed the EU Regulator values at W1)."),
    ("Governing Law", "Governing Law",
     "Keep ('05', 'Governing Law'); local values are the US subset (New York, Delaware, Massachusetts, California, Maryland, Other). The "
     "six non-US values are recorded under CW-905; steward 39 decides whether the shared list keeps them for 39's own contracts."),
    ("Inclusion Type", "Inclusion Type", "Keep ('05', 'Inclusion Type')."),
    ("Delivery Method", "Delivery Method",
     "Rename member ('05', 'Data Delivery Channel') -> ('05', 'Delivery Method') (review ruling: kept for the CW-137 Model Delivery Event channel); "
     "four shared labels copied (API, SFTP File, Platform Upload, Via Data Vendor). Model Delivery Event.Delivery Channel."),
    ("Cost Bearer", "Cost Bearer",
     "New member ('05', 'Cost Bearer') (steward 13); exact copy of the five shared labels. Intermediary Communication Fee Invoice.Fee Paid By."),
    ("Payable Invoice Status", "Payable Invoice Status",
     "Rename member ('05', 'Invoice Status') -> ('05', 'Payable Invoice Status'); all eight shared labels copied. Partner Invoice.Invoice Status."),
    ("Outgoing Payment Status", "Outgoing Payment Status",
     "Rename member ('05', 'Payment Status') -> ('05', 'Outgoing Payment Status'); all six shared labels copied. Partner Payment.Payment Status."),
    ("Record Status", "Record Status",
     "New member ('05', 'Record Status'); all eight shared labels. Distributor Firm.Partner Status, Payment Arrangement Status, Program Status, "
     "Dealer Setup Status (the wholesale local Arrangement Status, Setup Status and Database Profile Status are superseded)."),
    ("Risk Rating", "Risk Rating",
     "New member ('05', 'Risk Rating'), moved with Distributor Due Diligence from 08 (CW-135); all five shared labels. Residual Risk Rating."),
    ("Screening Result", "Screening Result",
     "New member ('05', 'Screening Result'), moved with Distributor Due Diligence from 08 (CW-135); all four shared labels."),
    ("Severity", "Severity", "New member ('05', 'Severity'), moved with Due Diligence Finding from 08 (CW-135); all four shared labels."),
    ("Case Status", "Case Status",
     "New member ('05', 'Case Status'); seven of the shared labels. Due Diligence Finding.Remediation Status (the wholesale 08 local "
     "Remediation Status list is superseded)."),
    ("Business Line", "Business Line",
     "New member ('05', 'Business Line') (CW-140); local copy of the eight CW-004 codes. Sales Opportunity.Opportunity Business Line (IA, IC, WR)."),
]

VALUE_MAPS = {   # 05 local label -> shared code
    ("05", "Distribution Channel"): {
        "Workplace": "WORKPLACE", "Workplace - Recordkept Plan": "WORKPLACE_RECORDKEPT",
        "Institutional": "INSTITUTIONAL", "Institutional - Direct": "INSTITUTIONAL_DIRECT",
        "Institutional - Consultant-Led": "INSTITUTIONAL_CONSULTANT", "Institutional - OCIO": "INSTITUTIONAL_OCIO",
        "Intermediary": "INTERMEDIARY", "Intermediary - Wirehouse": "INTERMEDIARY_WIREHOUSE",
        "Intermediary - National / Regional Broker-Dealer": "INTERMEDIARY_REGIONAL_BD",
        "Intermediary - Independent Broker-Dealer": "INTERMEDIARY_IBD", "Intermediary - RIA": "INTERMEDIARY_RIA",
        "Intermediary - Bank / Trust": "INTERMEDIARY_BANK_TRUST", "Intermediary - TAMP / Model Marketplace": "INTERMEDIARY_TAMP_MODEL",
        "Intermediary - Brokerage Platform": "INTERMEDIARY_BROKERAGE_PLATFORM",
        "Intermediary - Third-Party Recordkeeper": "INTERMEDIARY_RECORDKEEPER"},
    ("05", "Data Vendor"): {"Discovery Data": "DISCOVERY_DATA", "Broadridge": "BROADRIDGE", "FINTRX": "FINTRX", "Cerulli Associates": "CERULLI",
                            "Morningstar": "MORNINGSTAR", "Nasdaq eVestment": "NASDAQ_EVESTMENT", "Other": "OTHER"},
    ("05", "Delivery Method"): {"API": "API", "SFTP File": "SFTP_FILE", "Platform Upload": "PLATFORM_UPLOAD", "Via Data Vendor": "DATA_VENDOR"},
    ("05", "Cost Bearer"): {"Fund": "FUND", "Adviser": "ADVISER", "Shared Fund / Adviser": "SHARED_FUND_ADVISER", "Service Provider": "SERVICE_PROVIDER",
                            "Intermediary": "INTERMEDIARY"},
    ("05", "Qualification Exam"): {"SIE": "SIE", "Series 6": "SERIES_6", "Series 7": "SERIES_7", "Series 9 / 10": "SERIES_9_10",
                                   "Series 24": "SERIES_24", "Series 26": "SERIES_26", "Series 63": "SERIES_63", "Series 65": "SERIES_65",
                                   "Series 66": "SERIES_66", "Series 99": "SERIES_99"},
    ("05", "Dealing Route"): {"NSCC Fund/SERV": "NSCC_FUNDSERV", "NSCC DCC&S": "NSCC_DCCS", "NSCC CNS / ETF Portal": "NSCC_CNS_ETF",
                              "SWIFT Direct (ISO 20022)": "SWIFT_DIRECT", "TA Direct": "TA_DIRECT", "Recordkeeper File": "RECORDKEEPER_FILE",
                              "Sponsor File": "SPONSOR_FILE", "Own Broker-Dealer Omnibus": "OWN_BD_OMNIBUS"},
    ("05", "Governing Law"): {"New York": "NEW_YORK", "Delaware": "DELAWARE", "Massachusetts": "MASSACHUSETTS", "California": "CALIFORNIA",
                              "Maryland": "MARYLAND", "Other": "OTHER"},
    ("05", "Record Status"): {"Draft": "DRAFT", "Proposed": "PROPOSED", "Pending": "PENDING", "Active": "ACTIVE", "Paused": "PAUSED",
                              "Inactive": "INACTIVE", "Deprecated": "DEPRECATED", "Retired": "RETIRED"},
    ("05", "Risk Rating"): {"Low": "LOW", "Medium": "MEDIUM", "High": "HIGH", "Critical": "CRITICAL", "Prohibited": "PROHIBITED"},
    ("05", "Screening Result"): {"No Match": "NO_MATCH", "Potential Match - Under Review": "POTENTIAL_MATCH", "False Positive": "FALSE_POSITIVE",
                                 "Confirmed Match": "CONFIRMED_MATCH"},
    ("05", "Severity"): {"Low": "LOW", "Medium": "MEDIUM", "High": "HIGH", "Critical": "CRITICAL"},
    ("05", "Case Status"): {"New / Received": "NEW", "In Progress": "IN_PROGRESS", "Pending Third Party": "PENDING_THIRD_PARTY",
                            "Escalated": "ESCALATED", "Resolved / Completed": "RESOLVED", "Closed": "CLOSED", "Canceled": "CANCELED"},
    ("05", "Business Line"): {c: c for c in ["DB", "DA", "HA", "PF", "WR", "IA", "IC", "TR"]},
    ("05", "Payable Invoice Status"): {"Received": "RECEIVED", "Matched": "MATCHED", "Under Review": "UNDER_REVIEW", "Disputed": "DISPUTED",
                                       "Approved for Payment": "APPROVED", "Paid": "PAID", "Rejected": "REJECTED", "Credited": "CREDITED"},
    ("05", "Outgoing Payment Status"): {"Scheduled": "SCHEDULED", "Released": "RELEASED", "Paid / Settled": "PAID", "Failed": "FAILED",
                                        "Reversed": "REVERSED", "Canceled": "CANCELED"},
}

# Proposed labels for the CW-164 codes that have no label in shared_code_lists.py yet (for the steward 09 at W5).
DISTRIBUTION_CHANNEL_LABELS = {
    "WORKPLACE": "Workplace", "WORKPLACE_RECORDKEPT": "Workplace - Recordkept Plan", "INSTITUTIONAL_OCIO": "Institutional - OCIO",
    "INTERMEDIARY_BROKERAGE_PLATFORM": "Intermediary - Brokerage Platform", "INTERMEDIARY_RECORDKEEPER": "Intermediary - Third-Party Recordkeeper",
}

# Old-to-new maps of the values that existing data carries (review): wholesale label -> 05 label, or a reason it has none.
VALUE_MAPS_OLD = {
    ("05", "Partner Channel") : {   # -> 05 Distribution Channel
        "Wirehouse": "Intermediary - Wirehouse", "Regional Broker-Dealer": "Intermediary - National / Regional Broker-Dealer",
        "Independent Broker-Dealer": "Intermediary - Independent Broker-Dealer", "RIA Custodian": "Intermediary - Brokerage Platform",
        "Bank / Trust": "Intermediary - Bank / Trust", "Private Bank": "Intermediary - Bank / Trust",
        "Fund Platform / Supermarket": "Intermediary - Brokerage Platform", "Insurer / Unit-Linked": None,   # CW-165
        "DCIO / Recordkeeper": "Intermediary - Third-Party Recordkeeper", "TAMP": "Intermediary - TAMP / Model Marketplace",
        "Model Marketplace": "Intermediary - TAMP / Model Marketplace", "IFA Network": None, "Discretionary Fund Manager": None,  # CW-905
        "Institutional Consultant": "Institutional - Consultant-Led"},
    ("02", "Distribution Channel"): {   # wholesale 02 list -> 05 Distribution Channel
        "Wirehouse": "Intermediary - Wirehouse", "National / Regional Broker-Dealer": "Intermediary - National / Regional Broker-Dealer",
        "Independent Broker-Dealer": "Intermediary - Independent Broker-Dealer", "Insurance Broker-Dealer": None,    # CW-165
        "Bank Broker-Dealer": "Intermediary - Bank / Trust", "Dually Registered / Hybrid RIA": "Intermediary - RIA",
        "Independent RIA": "Intermediary - RIA", "Private Bank / Trust Company": "Intermediary - Bank / Trust",
        "Family Office": "Intermediary - RIA", "TAMP / Model Platform": "Intermediary - TAMP / Model Marketplace",
        "Retirement Recordkeeper / DCIO": "Intermediary - Third-Party Recordkeeper",
        "UK IFA / Network": None, "UK / EU Discretionary Fund Manager": None, "Fund Platform / Supermarket": None, "EU Bank Distributor": None,  # CW-905 / CW-911
        "Institutional Direct": "Institutional - Direct", "Investment Consultant": "Institutional - Consultant-Led"},
    ("05", "Agreement Type"): {
        "Selling / Dealer Agreement": "Selling Agreement", "Distribution Agreement": None,   # principal underwriting agreement is 35 / 39
        "Platform Agreement": "Platform Agreement", "Sub-TA / Shareholder Servicing Agreement": "Sub-Accounting / Shareholder Services Agreement",
        "Networking Agreement": "Networking Agreement", "Revenue Sharing / Marketing Support Agreement": "Revenue Sharing Agreement",  # lever
        "DCIO / Recordkeeper Services Agreement": "Recordkeeper Services Agreement",
        "Model Delivery / SMA Sponsor Agreement": "Model Provider Agreement (or SMA Sponsor Agreement where the firm manages the accounts)",
        "Data Licensing / Data Sharing Agreement": "Data Sharing Agreement", "Placement Agent Agreement": None,   # 30 retired (CW-016)
        "Nominee Agreement": None, "Retrocession / Rebate Agreement": None,   # CW-905
        "Shareholder Information Agreement (Rule 22c-2)": "Shareholder Information Agreement (Rule 22c-2)",
        "Unit-Linked / Insurance Distribution Agreement": None,   # CW-165
        "Confidentiality Agreement": None},   # 39 Contract
    ("05", "Payment Type"): {
        "Revenue Sharing - Asset-Based": "Revenue Sharing", "Revenue Sharing - Sales-Based": "Revenue Sharing",
        "Revenue Sharing - Flat Fee": "Revenue Sharing",   # lever
        "Sub-TA / Sub-Accounting Fee": "Sub-Accounting Fee - Per Account (or - Asset-Based by the rate schedule basis)",
        "Networking Fee": "Networking Fee", "12b-1 Distribution Fee": None,   # lever: no 12b-1 plans (CW-136); restore from the sibling
        "12b-1 Service Fee": "Rule 12b-1 Service Fee",   # lever
        "Shareholder Servicing Fee (Non-12b-1)": "Sub-Accounting Fee - Asset-Based", "Dealer Concession / Commission": None,   # no-load default
        "Platform / Shelf Fee": "Platform Fee", "Data Fee": "Data Fee", "Conference / Education Sponsorship": "Program / Sponsorship Fee",
        "Model Delivery Fee": "Model Marketplace Fee", "DCIO Recordkeeping Fee": "Sub-Accounting Fee - Per Account",
        "Trail Commission (EU/UK)": None, "Retrocession (EU/UK)": None,   # CW-905
        "Placement Fee": None},   # 30 retired
}
# 06 Salesperson Credit.Credit Role reads '05 Partner Coverage Role' (content_06 line 347): 06 should copy the five 05 values (CW-138).
CREDIT_ROLE_MAP_06 = {"National Accounts": "Platform Relationship Manager", "Relationship Manager (IA)": None,   # 03 / 12 roles, not partner coverage
                      "Consultant Relations": "Consultant Relations Manager", "Retirement Specialist": "Recordkeeper Relationship Manager",
                      "External Wholesaler": "External Wholesaler", "Internal Wholesaler": "Internal Wholesaler"}

# Memberships of the wholesale 05 that the replacement does not carry (brief section 8).
MEMBERSHIPS_REMOVE = [("05", "Agreement Market"), ("05", "Data Quality Status"), ("05", "Access Classification"),
                      ("05", "Settlement Method"), ("05", "Frequency"), ("05", "Message Standard"), ("05", "SLA Unit"),
                      ("05", "Data Granularity")]
# Frequency, Message Standard, SLA Unit and Data Granularity are named in brief section 8 but no carried attribute uses them after the
# thin cut (Payment Frequency, Message Standard, SLA Target Unit, Partner Data Feed Arrangement.Data Granularity); re-register if a
# lever restores them. Delivery Method is kept (renamed from Data Delivery Channel) for Model Delivery Event.Delivery Channel.
MEMBERSHIPS_RENAME = [(("05", "Partner Channel"), ("05", "Distribution Channel")),
                      (("05", "Invoice Status"), ("05", "Payable Invoice Status")),
                      (("05", "Payment Status"), ("05", "Outgoing Payment Status")),
                      (("05", "Data Delivery Channel"), ("05", "Delivery Method"))]
MEMBERSHIPS_ADD = [("05", "Qualification Exam"), ("05", "Data Vendor"), ("05", "Record Status"), ("05", "Risk Rating"),
                   ("05", "Screening Result"), ("05", "Severity"), ("05", "Case Status"), ("05", "Business Line"), ("05", "Cost Bearer")]
# Stale LOCAL_RENAMES of the wholesale 05: the replacement authors the disambiguated names directly (Agreement Termination Reason,
# Partner Review Type was dropped with its attribute) or no longer has the list (Benefit Type, Attestation Type, Dispute Reason,
# Coverage Basis). The 02 renames ('02', 'Hierarchy Type' -> 'Distributor Hierarchy Type') and ('02', 'Registration Status' ->
# 'Advisor Registration Category') are authored under the new names in 05 and can be removed with the wholesale 02 entries.
LOCAL_RENAMES_REMOVE = [("05", "Benefit Type"), ("05", "Attestation Type"), ("05", "Termination Reason"), ("05", "Dispute Reason"),
                        ("05", "Coverage Basis"), ("05", "Review Type"), ("02", "Hierarchy Type"), ("02", "Registration Status")]
# NOT_MERGED rows naming wholesale 05 lists that no longer exist: ('13', 'Reclaim Status', '05', 'Invoice Status') -> 05 is now
# 'Payable Invoice Status'; ('05', 'Renewal Decision', '14', ...), ('05', '12b-1 Component', '10', 'Revenue Stream'),
# ('20', 'Employee Benefit Type', '05', 'Benefit Type') and ('20', 'Performance Review Type', '05', 'Review Type') lose their 05 side.

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES: (list name in 05, proposed shared list name, likely other users, recommendation)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Account Structure", "Fund Account Structure", ["05", "06", "29", "13"],
     "Omnibus, networked, direct and plan-level registration of fund accounts; 13 Holding Model and 29 account registration use close values. Steward 29."),
    ("External (03 Credential Type)", "Professional Credential", ["05", "03", "20", "45"],
     "Folded: Financial Professional.Professional Designations now cites 03 Credential Type (the 05 Professional Designation list is gone). "
     "If 03's 'Professional Credential' candidate becomes shared, 05 joins as a direct user; the wholesale 05 values CIMA, CPWA, CRPS and AIF "
     "should be in it."),
    ("Manager Database", None, ["05", "52"],
     "52 External Manager & Sub-Adviser Oversight screens managers in the same databases (eVestment, Morningstar); keep local unless 52 adopts it."),
    ("Placement Status", None, ["05", "01"],
     "01 Brokerage Platform Availability Status is the firm's own platform; 05 Placement Status is a partner's shelf. Not a merge: record in NOT_MERGED."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS noticed (plan section 5.3 watchlist names and CW-149), decisions.TERM_CONFLICTS format.
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Advisor (wealth model)",
     "usages": [("03", "Advisor (profile of a 20 employee)", "The firm's own representative"),
                ("05", "Financial Professional (External Advisor)", "Intermediary advisor: a 02 party with the Party Role 'Financial Advisor' and a 05 profile"),
                ("05", "Advisor Team, Advisor Practice", "External team and practice")],
     "recommendation": "Bare 'advisor' is the own representative (03); 05 definitions say 'external advisor'.",
     "resolution": "As recommended (CW-078, CW-149).", "status": "Resolved", "decision": "CW-149"},
    {"term": "Coverage",
     "usages": [("03", "Party Coverage Assignment (CVA-)", "Advisor coverage of clients and households, including institutional relationship managers"),
                ("05", "Partner Coverage Assignment (PCVG-)", "Coverage of partner firms, external advisors, consultants and third-party recordkeepers"),
                ("12", "Service Coverage Assignment", "Servicing roles on a Service Relationship"),
                ("05", "Agreement Product Coverage", "Products an agreement covers (not a person covering a party)")],
     "recommendation": "Always qualified: Party, Partner, Service or Agreement Product Coverage.",
     "resolution": "As recommended (CW-138).", "status": "Resolved", "decision": "CW-138"},
    {"term": "Team",
     "usages": [("03", "Coverage Team (SLT-)", "Own advisors serving households"), ("05", "Advisor Team", "External advisor team at a partner"),
                ("12", "Service Team", "Institutional servicing team")],
     "recommendation": "Always qualified.", "resolution": "As recommended (CW-149).", "status": "Resolved", "decision": "CW-149"},
    {"term": "Program",
     "usages": [("05", "Partner Program (PGM-)", "A partner-run program the firm joins"), ("05", "Sponsor Program (Model Program Placement)", "Third-party SMA, UMA or model program"),
                ("01", "Advice program / Service Offering", "The firm's own advice program"), ("46", "Managed account program", ""),
                ("50", "Sweep program", "")],
     "recommendation": "Always qualified: Partner Program, Sponsor Program, advice program, managed account program, sweep program.",
     "resolution": "As recommended (CW-149).", "status": "Resolved", "decision": "CW-149"},
    {"term": "Agreement",
     "usages": [("05", "Distribution Agreement (AGR-)", "Agreement with a distribution partner"), ("15", "Account Agreement", "Client account agreement"),
                ("39", "Contract (CTRCT-)", "The executed document and enterprise contract record"),
                ("14", "Data License Agreement (DLA-)", "Data bought from vendors")],
     "recommendation": "05 Distribution Agreement holds the commercial terms; its executed copy is a 39 Contract (Executed Contract); data bought is 14.",
     "resolution": "As recommended (CD-257, CW-149).", "status": "Resolved", "decision": "CW-149"},
    {"term": "Tier",
     "usages": [("05", "Partner Tier", "The firm's tier in a partner program"), ("05", "Rate Tier", "Band of a partner payment rate schedule"),
                ("01", "Service Tier", "Retail client service tier"), ("12", "Institutional Service Tier", "")],
     "recommendation": "Always qualified.", "resolution": "As recommended (CW-149).", "status": "Resolved", "decision": "CW-149"},
    {"term": "Hierarchy Node",
     "usages": [("05", "Hierarchy Node", "Node of a partner firm's distribution hierarchy"),
                ("10", "Management Hierarchy Node", "Node of a management P&L hierarchy (renamed, CW-159)")],
     "recommendation": "05 keeps the name for its readers; 10 is renamed.", "resolution": "As recommended (CW-159).", "status": "Resolved", "decision": "CW-159"},
    {"term": "Assets (wealth model)",
     "usages": [("06", "Client Assets, Net New Assets, Advised Assets", "Certified firm measures (CW-142)"),
                ("05", "Form ADV Profile.Regulatory Assets Under Management", "A partner's Form ADV regulatory assets"),
                ("05", "Advisor Practice.Practice AUM", "Vendor estimate of an external advisor's book"),
                ("05", "Consultant Profile.Assets Under Advisement", "A consultant's advised assets")],
     "recommendation": "05 asset figures describe partners, never the firm's own assets; definitions say so.",
     "resolution": "As recommended (CW-142, CW-149).", "status": "Resolved", "decision": "CW-149"},
    {"term": "Feed",
     "usages": [("06", "Data Feed (FEED-)", "Technical feed definition and loads"), ("05", "Partner Data Feed Arrangement", "Commercial arrangement under which a partner supplies a feed"),
                ("12", "Client Data Feed (CDF-)", "Outbound feed to an institutional client"), ("14", "Dataset Delivery", "Licensed vendor data")],
     "recommendation": "Always qualified.", "resolution": "As recommended (CW-149).", "status": "Resolved", "decision": "CW-149"},
    {"term": "Due diligence",
     "usages": [("05", "Distributor Due Diligence (DDQ-)", "Oversight of a distribution partner"),
                ("05", "RFP Request of type DDQ / Home-Office Due Diligence (RFP-)", "A partner's or consultant's questionnaire about the firm"),
                ("05", "Partner Research Rating.Last Due Diligence Review Date", "A partner's review of the firm's product"),
                ("52", "Manager and product due diligence", "The firm's review of external managers and third-party funds")],
     "recommendation": "Always qualified by who reviews whom.", "resolution": "Open: confirm the 52 object names at the W4 merge.", "status": "Open", "decision": "CW-135"},
    {"term": "Branch",
     "usages": [("03", "Firm Branch Office", "The firm's own branch"), ("05", "Branch / Office", "A partner's branch (Form BR)")],
     "recommendation": "'Branch' alone is the firm's own (03); 05 definitions say 'partner branch'.",
     "resolution": "As recommended (CW-072).", "status": "Resolved", "decision": "CW-072"},
    {"term": "Sponsor",
     "usages": [("05", "Partner Program.Program Sponsor; SMA / UMA Sponsor (Agreement Party Role); Sponsor Program", "Partner that runs a program"),
                ("16", "Plan Sponsor", "Employer that sponsors a retirement plan"), ("01", "Fund sponsor", "The firm as sponsor of its funds")],
     "recommendation": "Always qualified: program sponsor, SMA sponsor, plan sponsor, fund sponsor.", "resolution": "As recommended (CW-149).",
     "status": "Resolved", "decision": "CW-149"},
    {"term": "Platform",
     "usages": [("05", "Partner Platform / Program Name; Intermediary - Brokerage Platform; Platform Agreement", "A partner's platform"),
                ("01", "Brokerage Platform Availability", "The firm's own brokerage platform")],
     "recommendation": "'Platform' in 05 is always a partner's platform; the firm's own is the brokerage platform (01).",
     "resolution": "As recommended (CW-149).", "status": "Resolved", "decision": "CW-149"},
    {"term": "Rating",
     "usages": [("05", "Partner Research Rating", "A partner gatekeeper's rating of the firm's product"), ("05", "Consultant Rating", "A consultant's manager rating"),
                ("17", "Credit Rating Assignment", "Agency credit rating of an instrument or issuer")],
     "recommendation": "Always qualified.", "resolution": "As recommended (CW-149).", "status": "Resolved", "decision": "CW-149"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. REPOINTS: readers of the wholesale 05 and of the restored 02, 03, 08 and 13 objects. Object map first; then the attributes
#    not carried (value None) or renamed. Keys and values are (domain, object, attribute) with attribute "" for a whole object.
# ---------------------------------------------------------------------------------------------------------------------
OBJECT_MAP = {
    **{("02", o): ("05", o) for o in ["Distributor Firm", "Form ADV Profile", "Hierarchy Node", "Branch / Office", "Advisor Team",
                                      "Team Membership", "Gatekeeper Profile", "Financial Professional", "Advisor Practice",
                                      "Employment Affiliation", "External Classification", "Consultant Profile",
                                      "Consultant Advisory Relationship"]},
    **{("03", o): ("05", o) for o in ["Sales Opportunity", "Pipeline Status", "Opportunity Value", "Win / Loss", "RFP Request",
                                      "RFP Submission", "Database Profile", "Database Submission", "Consultant Rating"]},
    ("03", "Placement, Model & DCIO Detail"): ("05", "Placement & Plan Detail"),
    ("03", "Institutional Search Detail"): ("05", "Sales Opportunity"),
    ("03", "Opportunity Product"): ("05", "Sales Opportunity"),
    ("03", "Opportunity Competitor"): ("05", "Win / Loss"),
    ("08", "Distributor Due Diligence"): ("05", "Distributor Due Diligence"),
    ("08", "Distributor Risk Rating"): ("05", "Distributor Due Diligence"),
    ("08", "Screening Result"): ("05", "Distributor Due Diligence"),
    ("08", "Regulatory Status Check"): ("05", "Distributor Due Diligence"),
    ("08", "Questionnaire Response"): ("05", "Distributor Due Diligence"),
    ("08", "Due Diligence Outcome"): ("05", "Distributor Due Diligence"),
    ("08", "Due Diligence Finding"): ("05", "Due Diligence Finding"),
    ("13", "Intermediary Communication Fee Invoice"): ("05", "Intermediary Communication Fee Invoice"),
    ("05", "Payment Terms"): ("05", "Payment Arrangement"),
    ("05", "Payment Limit"): ("05", "Payment Arrangement"),
    ("05", "Trading Setup"): ("05", "Partner Dealer Setup"),
    ("05", "Program Benefit"): ("05", "Program Membership"),
    ("05", "Service Level Agreement"): ("05", "Agreement Obligation"),
    ("05", "SLA Measurement"): ("05", "Agreement Obligation"),
    ("05", "408(b)(2) Compensation Disclosure"): ("05", "Payment Disclosure"),
    ("05", "Partner Attestation"): ("05", "Distributor Due Diligence"),
    ("05", "Agreement Document"): ("39", "Contract"),
    ("05", "Distribution Fee Pass-Through"): None,     # CW-136: no 12b-1 or trail default (lever)
    ("05", "Distributor Data Exchange"): None,         # CW-905 (FinDatEx, MiFID II)
    ("05", "Record Metadata"): None,                   # CD-160
    ("03", "Opportunity Team"): None, ("03", "Stage History"): None, ("03", "Request Question"): None,
    ("03", "Answer Library Entry"): None, ("03", "Consultant Research Review"): ("03", "Advisor Activity"),
    ("03", "Consultant Notification"): None, ("03", "Account Plan"): None, ("03", "Plan Objective"): None,
    ("03", "Stakeholder Map"): None, ("03", "Plan Action"): None,
}

REPOINTS = {
    # ---- renamed or moved within 05 --------------------------------------------------------------------------------------
    ("05", "Payment Calculation", "Basis Position Snapshot"): ("05", "Payment Calculation", "Basis Snapshot"),     # bare 'Position' (CW-007); type Reference (Snapshot, 06)
    ("05", "Distribution Agreement", "Agreement Document"): ("05", "Distribution Agreement", "Executed Contract"),
    ("05", "Partner Dealer Setup", "Clearing Firm"): ("05", "Distributor Firm", "Clearing Firm"),                    # held once, on the firm
    ("05", "Trading Setup", "Dealing Route"): ("05", "Partner Dealer Setup", "Dealing Route"),
    ("05", "Trading Setup", "Account Structure"): ("05", "Partner Dealer Setup", "Account Structure"),
    ("05", "Trading Setup", "Order Cut-Off Time"): None,
    ("05", "Payment Terms", "Payment Frequency"): None,
    ("05", "Payment Terms", "Basis Data Source"): ("05", "Payment Calculation", "Basis Snapshot"),
    ("05", "Payment Limit", "Annual Payment Cap"): ("05", "Payment Arrangement", "Annual Payment Cap"),
    ("05", "Program Benefit", "Benefit Type"): ("05", "Partner Program", "Program Type"),
    ("05", "Service Level Agreement", "SLA Target Value"): ("05", "Agreement Obligation", "SLA Target Value"),
    ("05", "SLA Measurement", "Actual Value"): ("05", "Agreement Obligation", "Latest Measured Value"),
    ("05", "408(b)(2) Compensation Disclosure", "Covered Service Provider"): ("05", "Payment Disclosure", "Covered Service Provider"),
    ("05", "408(b)(2) Compensation Disclosure", "Indirect Compensation Description"): ("05", "Payment Disclosure", "Indirect Compensation Description"),
    ("05", "Partner Attestation", "Attestation Received Date"): ("05", "Distributor Due Diligence", "SOC 1 Report Received Date"),
    ("05", "Shelf Placement", "Placed Product"): ("05", "Shelf Placement", "Placed Product"),                         # kept
    ("03", "Placement, Model & DCIO Detail", "Plan Recordkeeper"): ("05", "Placement & Plan Detail", "Plan Recordkeeper"),  # now Reference (Recordkeeper Profile, 16)
    ("03", "Opportunity Product", "Proposed Product"): ("05", "Sales Opportunity", "Proposed Offering or Strategy"),
    ("03", "Institutional Search Detail", "Search Consultant"): ("05", "Sales Opportunity", "Search Consultant"),
    ("03", "Opportunity Competitor", "Competitor Firm"): ("05", "Win / Loss", "Winning Competitor"),
    ("03", "Win / Loss", "Resulting Shelf Status Record"): ("05", "Win / Loss", "Resulting Shelf Status Record"),       # now Reference (Shelf Placement)
    ("08", "Distributor Due Diligence", "Due Diligence ID"): ("05", "Distributor Due Diligence", "Due Diligence ID"),
    ("08", "Distributor Risk Rating", "Residual Risk Rating"): ("05", "Distributor Due Diligence", "Residual Risk Rating"),
    ("08", "Screening Result", "Screening Result"): ("05", "Distributor Due Diligence", "Sanctions Screening Result"),
    ("08", "Regulatory Status Check", "Authorization Verified Indicator"): ("05", "Distributor Due Diligence", "Regulatory Status Verified Indicator"),
    ("08", "Questionnaire Response", "Questionnaire Received Date"): ("05", "Distributor Due Diligence", "Questionnaire Received Date"),
    ("08", "Due Diligence Outcome", "Due Diligence Outcome"): ("05", "Distributor Due Diligence", "Due Diligence Outcome"),
    ("08", "Due Diligence Finding", "Due Diligence Finding Key"): ("05", "Due Diligence Finding", "Due Diligence Finding Key"),   # aligned name
    ("03", "Win / Loss", "Winning Competitor"): ("05", "Win / Loss", "Winning Competitor"),   # now Reference (Competitor Profile, 11)
    ("08", "Due Diligence Finding", "Remediation Action"): ("05", "Due Diligence Finding", "Finding Description"),
}
# Attributes not carried (thin cut; readers drop them at WP0 or a lever restores them from tag wholesale-v1.0). EU/UK-only
# attributes are in JURISDICTION instead. Grouped by object: (domain, object): [attributes].
NOT_CARRIED = {
    ("05", "Distribution Agreement"): ["Agreement Paper"],
    ("05", "Agreement Party Role"): ["Signatory Name", "Notice Contact"],          # contacts and signatories are 39 Contract
    ("05", "Agreement Term"): ["Execution Date", "Termination Initiated By", "Post-Termination Payment Period"],
    ("05", "Agreement Amendment"): ["Amendment Type", "Amendment Summary", "Confidential Side Letter Indicator"],
    ("05", "Agreement Product Coverage"): ["Coverage Basis"],
    ("05", "Agreement Distribution Scope"): ["Sub-Distribution Permitted Indicator"],
    ("05", "Payment Arrangement"): ["Payment Direction", "Payment Currency", "Rule 12b-1 Plan Reference"],
    ("05", "Payment Limit"): ["Cap Rate", "Minimum Annual Payment", "Offset Method", "Payment Waterfall Sequence"],
    ("05", "Payment Terms"): ["Billing Method", "Payment Due Days"],
    ("05", "Rate Schedule"): ["Rate Type", "Tier Aggregation Level", "Qualifying Asset Definition", "Excluded Asset Categories", "Greater-of / Lesser-of Rule"],
    ("05", "Rate Tier"): ["Tier Bound Unit"],
    ("05", "Sub-Accounting Fee Terms"): ["Account Count Source", "Sub-Accounting Fee Unit (the Rate Schedule Calculation Basis)", "Applicable Networking Level (Networking Setup and 15)"],
    ("05", "Payment Calculation"): ["Applied Effective Rate", "Adjustment Amount", "Adjustment Reason", "Accrual Amount", "Calculation Status"],
    ("05", "Partner Invoice"): ["Invoice Date", "Invoice Variance Amount", "Dispute Reason"],
    ("05", "Partner Program"): [],
    ("05", "Program Membership"): ["Tier Qualification Basis", "Annual Commitment Amount", "Relationship Manager", "Renewal Decision"],
    ("05", "Program Benefit"): ["Entitled Quantity", "Used Quantity", "Linked Event", "Non-Cash Compensation Relevance Indicator"],
    ("05", "Shelf Placement"): ["Placement Change Reason", "Partner Product Code", "Platform Minimum Initial Investment"],
    ("05", "Partner Research Rating"): ["Partner Rating Value", "Due Diligence Review Type", "Watch List Reason", "Research Analyst"],
    ("05", "Share Class Mapping"): ["Sales Charge Waiver Indicator"],              # no-load default (CW-136)
    ("05", "Partner Dealer Setup"): ["Dealer Setup Status (now Record Status)"],
    ("05", "Trading Setup"): ["Message Standard", "Settlement Method", "Settlement Cycle", "Dealing Restrictions"],   # settlement is 29
    ("05", "Networking Setup"): ["Statement & Confirmation Responsibility", "Sub-Accounting Platform"],
    ("05", "Partner Data Feed Arrangement"): ["Data Content Types", "Data Granularity", "Data Fee Arrangement", "Permitted Use Restrictions", "Personal Data Included Indicator"],
    ("05", "Agreement Obligation"): ["Obligated Party", "Obligation Frequency", "Next Due Date", "Obligation Owner"],
    ("05", "Service Level Agreement"): ["SLA Metric Name", "SLA Metric Type", "SLA Target Unit", "Measurement Frequency", "Service Credit Terms"],
    ("05", "SLA Measurement"): ["Measurement Period", "SLA Met Indicator", "Remediation Action"],
    ("05", "Payment Disclosure"): ["Firm Listed Indicator", "Disclosure Location", "Last Verified Date"],
    ("05", "408(b)(2) Compensation Disclosure"): ["Indirect Compensation Payer", "Compensation Formula", "Disclosure Provided Date", "Change Notification Date"],
    ("05", "Partner Attestation"): ["Attestation Type", "Next Attestation Due Date", "Attestation Outcome"],
    ("02", "Distributor Firm"): ["Number of Investment Adviser Representatives"],
    ("02", "Form ADV Profile"): ["Discretionary RAUM"],
    ("02", "Hierarchy Node"): ["Top-Level Firm"],                                   # derivable from Parent Node
    ("02", "Advisor Team"): ["Team Name", "Team Lead"],                             # 02 Party Display Name; Team Membership role Team Lead
    ("02", "Gatekeeper Profile"): ["Decision Authority"],
    ("02", "Financial Professional"): ["Job Title", "Industry Start Date"],
    ("02", "Advisor Practice"): ["Revenue Model", "Investment Management Style", "Client Niche"],
    ("02", "Employment Affiliation"): ["Primary Affiliation Indicator"],
    ("02", "Consultant Profile"): ["Manager Research Coverage"],
    ("03", "Sales Opportunity"): ["Client Account", "Opportunity Source", "Originating Lead"],
    ("03", "Institutional Search Detail"): ["Consultant Role", "Finals Presentation Date", "Decision Body Meeting Date"],
    ("03", "Opportunity Product"): ["Product Line Amount"],
    ("03", "Pipeline Status"): ["Forecast Category", "Opportunity Next Step"],
    ("03", "Opportunity Value"): ["Expected Fee Rate", "Amount Currency (US only; amounts are USD)"],
    ("03", "Placement, Model & DCIO Detail"): ["Home-Office Research Contact", "Related Agreement", "Line-Up Asset Category", "QDIA Indicator",
                                               "prospect plan participant count (CW-139 names participants; read from Form 5500 in 16 or the RFP)"],
    ("03", "Win / Loss"): ["Secondary Win / Loss Reasons", "Win / Loss Commentary"],
    ("03", "RFP Request"): ["Standard Questionnaire Template", "End Client", "Received Date", "Go / No-Go Decision", "RFP Manager"],
    ("03", "RFP Submission"): ["Submitted By", "Outcome Date", "Issuer Feedback"],
    ("03", "Database Profile"): ["Database Product Code", "Database Universe", "Profile Status"],
    ("03", "Database Submission"): ["Submission Frequency", "Data Sets Submitted", "Submission Due Date", "Performance Basis Submitted"],
    ("03", "Consultant Rating"): ["Rating Action", "Watch / Under Review Indicator", "Marketing Use Permitted Indicator"],
    ("08", "Distributor Due Diligence"): ["Governing Agreement", "Case Status", "Distributor Role (JURISDICTION)"],
    ("08", "Distributor Risk Rating"): ["Inherent Risk Rating"],
    ("08", "Screening Result"): ["Screening Type", "Screening Date"],
    ("08", "Regulatory Status Check"): ["Register Checked", "Disciplinary History Indicator"],
    ("08", "Questionnaire Response"): ["Questionnaire Template"],
    ("08", "Due Diligence Finding"): ["Remediation Action (merged into Finding Description)"],
    ("13", "Intermediary Communication Fee Invoice"): ["Invoice Validation Status"],
    ("03", "Opportunity Competitor"): ["Competitor Firm (merged into Win / Loss.Winning Competitor)", "Competitor Product", "Competitor Role"],
    ("08", "Due Diligence Outcome"): ["Outcome Conditions"],
}

# ---------------------------------------------------------------------------------------------------------------------
# 6. READERS to re-point at the W4 merge (CW-151; complements proposals_w4_channels.py READERS with what this draft changes).
#    (file or product, location, from, to)
# ---------------------------------------------------------------------------------------------------------------------
READERS = [
    ("data_models/keys.py, keys_g2_03_04_05.py, keys_g3_06_07_10.py, keys_g4_08_09.py, keys_g5_11_12_13_14.py", "DISTRIBUTOR, FIN_PRO",
     "('02', 'Party')", "('05', 'Distributor Firm'), ('05', 'Financial Professional'); key attribute 'Distributor Firm Party' / 'Financial Professional Party' (PTY-)"),
    ("data_models/keys_g5_11_12_13_14.py", "INST_CLIENT", "('02', 'Party')", "('12', 'Institutional Client') - 12's restoration (CW-133), not 05"),
    ("data_models/keys.py", "05 Payment Calculation.Basis Position Snapshot; Sub-Accounting Fee Terms.Account Count Source; Payment Arrangement.Inducement Assessment Reference; Payment Terms",
     "05 wholesale", "Basis Snapshot (Reference (Snapshot), 06); not carried; JURISDICTION (CW-905); merged into Payment Arrangement"),
    ("data_models/keys.py", "08 Distributor Due Diligence.Governing Agreement", "08", "not carried: Distribution Agreement.Distributor Due Diligence Reference points the other way"),
    ("data_models/keys_g2_03_04_05.py", "03 Sales Opportunity, RFP Request, RFP Submission, Placement, Model & DCIO Detail; 05 Program Benefit, Distributor Data Exchange, 408(b)(2) Compensation Disclosure, Master Agreement, Notice Contact, Clearing Firm (dealer setup), Obligation Owner, Funding Agreement, Relationship Manager",
     "03 / 05 wholesale", "05 objects per OBJECT_MAP; NOT_CARRIED attributes dropped; Placement & Plan Detail; Clearing Firm on Distributor Firm"),
    ("data_models/keys_g6_15_16.py", "15 Intermediary Account Servicing: Dealer of Record, Branch of Record, Rep of Record", "PARTY",
     "05 Distributor Firm, Branch / Office, Financial Professional (keyed by PTY-, so the value does not change)"),
    ("data_models/keys_g1_01_02.py", "01 Model Portfolio.Model Sponsor / Platform; Distribution Availability.Platform Availability", "PARTY",
     "05 Distributor Firm; Derived copy of 05 Shelf Placement (ROW_OWNERSHIP note in enrich_05.py)"),
    ("data_models/keys_g3_06_07_10.py", "06 Distributor Hierarchy, Intermediary As Delivered, Plan Position.Plan Advisor, Sponsor-Reported Assets.Sponsor; 10 Profitability Record.Partner Firm",
     "DISTRIBUTOR / FIN_PRO", "05 Distributor Firm, Hierarchy Node, Branch / Office, Advisor Team, Financial Professional"),
    ("data_models/keys_g5_11_12_13_14.py", "11 Competitor Distribution Footprint, Industry Flow Observation, Market Share Record (Distributor Firm); 12 Service Relationship.Advising Consultant and Won Opportunity; 11 Mandate Search Event.Asset Owner",
     "DISTRIBUTOR / PARTY", "05 Distributor Firm; 05 Consultant Advisory Relationship; 05 Sales Opportunity (OPP-); Asset Owner not re-pointed, prospects (stays 02 Party)"),
    ("data_models/keys_g4_08_09.py", "08 Distributor Due Diligence entries", "08", "05 Distributor Due Diligence and Due Diligence Finding (CW-135)"),
    ("semantic_model/models/sm_00_shared_dimensions.py", "distributor_firm, distributor_office, advisor_team (entity Party, filtered by Party Role)", "Party",
     "05 Distributor Firm (add distribution_channel, firm_registration_type, partner_status), Branch / Office (branch_type), Advisor Team (team_rep_code); names stay the 02 Party Display Name"),
    ("semantic_model/models/sm_00_shared_dimensions.py", "advisor, advisor_segment", "Financial Professional / Segment Assignment (02)",
     "05 Financial Professional (professional_type, registration_status, disclosure count hidden) and 05 External Classification.Vendor Advisor Segment (restored) for vendor segments"),
    ("semantic_model/models/sm_00_shared_dimensions.py", "consultant, consultant_relationship, recordkeeper", "Institutional Client / Party Relationship 'Consults For'",
     "05 Consultant Profile and Consultant Advisory Relationship; recordkeeper reads 16 Recordkeeper Profile"),
    ("semantic_model/models/sm_00_shared_dimensions.py", "distribution_agreement.agreement_market and agreement_paper; shelf_placement dims", "05 wholesale",
     "drop agreement_market (CW-905) and agreement_paper (not carried); shelf_placement keeps trade_enabled_date, eligible_account_types, model_eligible"),
    ("DP-001 Distributor Hierarchy", "inputs cut at W1 to the 02 party, roles and identifiers", "02 Party",
     "WP0 re-scope: add 05 Distributor Firm, Form ADV Profile, Hierarchy Node, Branch / Office, Advisor Team, Team Membership, Gatekeeper Profile"),
    ("DP-002 Financial Professional Profile", "inputs cut at W1", "02 Party",
     "WP0 re-scope: add 05 Financial Professional, Advisor Practice, Employment Affiliation, External Classification, Partner Coverage Assignment"),
    ("DP-003 Institutional, Consultant & Plan Relationships", "inputs cut at W1", "02 Party / Party Relationship",
     "WP0 re-scope: 05 Consultant Profile, Consultant Advisory Relationship; 12 Institutional Client; 16 Recordkeeper Profile"),
    ("DP-005 Distribution Agreements & Shelf Status (live)", "Distribution Agreement.Agreement Paper, Agreement Market; Agreement Term.Execution Date; Agreement Product Coverage.Coverage Basis, Covered Vehicle Types; Agreement Distribution Scope.Permitted Jurisdictions, Permitted Investor Types, Sub-Distribution Permitted Indicator; Shelf Placement.Placement Change Reason, Partner Product Code, Platform Minimum Initial Investment; Partner Research Rating.Partner Rating Value, Watch List Reason; Share Class Mapping.Sales Charge Waiver Indicator; Partner Dealer Setup.Platform Participant ID",
     "05 wholesale", "drop from the inputs (EU/UK items under CW-905; the rest thin cut, levers); every other DP-005 input resolves unchanged, including the dealer, networking, shelf and research-rating attributes"),
    ("DP-129", "05 Model Program Placement, Partner Program (incl. Program Status)", "05", "resolve unchanged"),
    ("DP-108", "05 Shelf Placement", "05", "resolve unchanged"),
    ("DP-243 Total Client Relationship", "03 Sales Opportunity (Opportunity ID, Business Type, Prospect / Client), Pipeline Status (Sales Stage, Probability), Opportunity Value (Expected Amount, Actual Close Date), Win / Loss (Opportunity Outcome)",
     "03", "('05', same object, same attribute): all eight attributes are carried (CW-134)"),
    ("DP-225 Code of Ethics", "02 Party.Party Type (political contributions)", "02", "no 05 object is read; nothing to re-point (listed because the assignment named it)"),
    ("data_products specs_c_sales, specs_d_marketing_product, specs_g_advisor_analytics, specs_h_planning_partners, specs_p_inst_intel_finance, specs_b_foundational",
     "('03', pipeline, RFP, database and consultant rating objects); ('02', restored profiles)", "03 / 02",
     "('05', ...) per OBJECT_MAP; the NOT_CARRIED attributes leave the inputs (Forecast Category, Opportunity Next Step, Client Account, Originating Lead, Expected Fee Rate, Line-Up Asset Category, QDIA Indicator and the RFP workflow fields)"),
    ("data_products specs_e_comp_finance_service, specs_j_compliance_2, specs_o_operations, specs_f_compliance, specs_i_product_data, specs_n_compliance_controls",
     "('05', wholesale objects and attributes) incl. Distribution Fee Pass-Through, Payment Terms, Payment Limit, Partner Attestation, Service Level Agreement, SLA Measurement, Agreement Document, Distributor Data Exchange",
     "05 wholesale", "per OBJECT_MAP and NOT_CARRIED; Distributor Data Exchange and the inducement attributes per JURISDICTION"),
    ("content_11_market_and_competitive_intelligence.py", "Mandate Search Event.Linked Opportunity (Reference (Opportunity), OPP-)", "03", "05 Sales Opportunity (resolves when OPP- moves to 05, CW-134, CW-170)"),
    ("content_36_product_development_and_lifecycle.py", "Readiness Check.Evidence Shelf Placement, Evidence Model Program Placement", "Reference (Object, 05)",
     "resolve unchanged; the Model Program Placement key is Sponsor Program Agreement x Placed Model Portfolio (AGR- / MDL-), as 36's example"),
    ("content_04_marketing_and_digital.py", "Campaign.Co-Marketing Agreement (Reference (Agreement), AGR-)", "05", "resolves; Agreement Type 'Co-Marketing Agreement' added"),
    ("content_29_transfer_agency_operations.py", "AP Agreement; Shareholder Information Request.Shareholder Information Agreement", "Reference (Agreement)",
     "resolve; Agreement Types 'Authorized Participant Agreement' and 'Shareholder Information Agreement (Rule 22c-2)'"),
    ("content_25_trading_and_execution.py", "Trade Order.Trade Rotation Program (AGR-)", "05", "resolves to an SMA Sponsor or Model Provider Agreement"),
    ("content_16_retirement_plan_administration.py", "Service Arrangement 'is governed by Agreement [05]'", "05",
     "for the 16 W3 drafter: the firm's recordkeeping contract with a plan sponsor is a client contract (39 Contract / 16 Service Arrangement), not a 05 Distribution Agreement; 05 Recordkeeper Services Agreement is with third-party recordkeepers (CW-139)"),
    ("content_19_finance_and_accounting.py", "Payable Invoice.Source Partner Invoice; Supplier Payment.Settled Partner Payment", "05", "resolve unchanged; IFI- invoices added (CW-088)"),
    ("content_10_distribution_finance_and_profitability.py", "Distribution Cost Item sources PYA-, PCL-; Inducement Assessment Reference", "05", "resolve; the inducement attribute is removed by 10 (CW-905 / 10 brief section 4a)"),
    ("content_13_investor_servicing_and_shareholder_communications.py", "Intermediary Communication Fee Invoice (transitional)", "13", "removed at the merge; 05 holds it unchanged except Invoice Validation Status (not carried)"),
    ("content_01_product.py", "Distribution Availability.Platform Availability (Reference (Party) (multi))", "PARTY", "recommend a Derived copy (05) of Shelf Placement.Shelf Partner (05 masters the partner channel and shelf for every partner firm)"),
    ("content_01_product.py", "Model Portfolio.Model Sponsor / Platform (Reference (Party))", "PARTY", "recommend a Derived copy (05) of Model Program Placement (sponsor program agreement x model); 05 masters which sponsor receives a model"),
    ("content_39_legal_and_corporate_governance.py line 99", "Document Version.Typed Record Document (Reference (Agreement Document, 05), DOC-)", "05 Agreement Document",
     "merge re-point to the 39 Contract document: the 05 object is dropped and DOC- retired (CD-257); 05 Distribution Agreement.Executed Contract holds the CTRCT- link"),
    ("data_models/keys.py", "('05', 'Rate Tier') pk [Tier Sequence], scoped within Rate Schedule", "05", "unchanged (Tier Sequence restored); register Rate Schedule as scoped within Payment Arrangement"),
    ("data_models/keys_g2_03_04_05.py", "('05', 'Agreement Product Coverage') pk incl. Covered Vehicle Types; ('05', 'Partner Dealer Setup') pk [TA Dealer Number, Platform Participant ID]", "05", "unchanged (both attributes restored)"),
    ("data_models/keys_g2_03_04_05.py", "('05', 'Model Program Placement') pk [Placed Model Portfolio, Model Placement Effective From]", "05", "pk re-cut: add Sponsor Program Agreement (the 05 key, as 36's example AGR- / MDL-)"),
    ("data_models/keys_g2_03_04_05.py", "('05', 'Share Class Mapping') pk [Mapped Share Class, Mapped Account Type]", "05", "pk re-cut: add Mapping Partner (grain mapping partner x account type x share class)"),
    ("data_models/keys_g4_08_09.py", "('08', 'Due Diligence Finding') pk [Due Diligence Finding Key]", "08", "('05', 'Due Diligence Finding'), same key name"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. JURISDICTION (CW-905; CW-022): the EU/UK content of the wholesale 05 and of the restored 02, 03 and 08 objects that the
#    replacement does not carry, in the jurisdiction.REMOVALS entry format. Domain is "05" throughout; the note names the wholesale
#    origin where the object came from 02, 03 or 08.
# ---------------------------------------------------------------------------------------------------------------------
D = "CW-905"
def _j(obj, attr, regime, note=""):
    return {"domain": "05", "object": obj, "attribute": attr, "regime": regime, "decision": D, "note": note}

JURISDICTION = [
    # ---- objects ----
    _j("Distributor Data Exchange", "", "FinDatEx",
       "FinDatEx EMT delivery and MiFID II ex-post costs and inducement data sent to EU/UK distributors (6 attributes: Recipient Distributor, EMT "
       "Version Delivered, EMT Delivery Channel, Last EMT Delivery Date, Ex-Post Inducement Amount, Ex-Post Data Delivery Date). No US equivalent; "
       "US partners receive prospectus and fee data from 01."),
    # ---- attributes of kept or dropped wholesale 05 objects ----
    _j("Payment Arrangement", "Inducement Relevance Indicator", "MiFID II", "Reg BI and FINRA Rule 2341 disclosure stays (Prospectus Disclosure Indicator, Payment Disclosure)."),
    _j("Payment Arrangement", "Inducement Assessment Reference", "MiFID II", "Quality-enhancement assessment (08, Delegated Directive 2017/593 Art. 11); the 08 Inducement Assessment was removed under CW-908."),
    _j("Distribution Fee Pass-Through", "Retrocession Basis", "MiFID II", "The object is not carried (CW-136, no 12b-1 or trail default); its US 12b-1 attributes are a lever, not a jurisdiction removal."),
    _j("Distribution Fee Pass-Through", "Retrocession Rate", "MiFID II", ""),
    _j("Distribution Fee Pass-Through", "Pass-On to Client Required Indicator", "MiFID II", "MiFID II pass-on rule for independent advice and portfolio management."),
    _j("Distribution Fee Pass-Through", "UK Legacy Trail Indicator", "FCA", "FCA COBS 6.1A / RDR pre-2013 trail commission."),
    _j("Payment Terms", "VAT Applicable Indicator", "Other EU/UK", "EU/UK VAT on platform and service fees; Payment Terms merged into Payment Arrangement."),
    _j("Partner Dealer Setup", "Dealing BIC", "EU market practice", "BIC for EU platform order messaging; BIC stays a 02 Identifier Scheme (ISO 9362 is market-neutral)."),
    _j("Distribution Agreement", "Agreement Market", "Other EU/UK", "Removed with the retired Distribution Market list (CW-164); values UK, EU, Switzerland, Cross-Border / Global below."),
    _j("Agreement Distribution Scope", "Permitted Investor Types", "MiFID II", "MiFID II retail / professional client categories (primary MiFID II). US account programs are Permitted Service Models."),
    # ---- attribute wordings and references of the restored objects ----
    _j("Employment Affiliation", "Employing Firm, Affiliation Type (secondary reference UK FCA Register)", "FCA", "Wholesale 02 object; re-sourced to FINRA CRD."),
    _j("Distributor Due Diligence", "Distributor Firm (secondary reference ESMA Product Governance Guidelines)", "MiFID II", "Wholesale 08 object (CW-135)."),
    _j("Distributor Due Diligence", "Distributor Role", "Consumer Duty", "Wholesale 08 attribute (secondary reference FCA PRIN 2A): distribution-chain role for UK Consumer Duty and ESMA product governance. Not carried; the 05 Distribution Channel of the firm stands in. Its EU/UK values are listed below."),
    _j("Regulatory Status Check", "Authorization Verified Indicator (secondary reference MiFID II)", "MiFID II", "Wholesale 08 object merged into Distributor Due Diligence; re-sourced to BrokerCheck and IAPD as Regulatory Status Verified Indicator."),
    _j("Screening Result", "Screening Type (secondary reference UK MLR 2017)", "Other EU/UK", "Wholesale 08 object merged into Distributor Due Diligence; the US screen is OFAC (Sanctions Screening Result). The OFSI and UK MLR part of the sanctions source was recorded by 08 under CW-908."),
    _j("Due Diligence Finding", "Finding Description and Remediation Action examples (target market reporting and FinDatEx EFT feedback)", "FinDatEx", "Wholesale 08 examples; the 05 example is a Rule 22c-2 data finding."),
    # ---- code-list values: wholesale 05 ----
    _j("Code list: Agreement Market", "UK", "Other EU/UK", "List retired with the attribute (the US value retires under CW-164)."),
    _j("Code list: Agreement Market", "EU", "Other EU/UK", ""),
    _j("Code list: Agreement Market", "Switzerland", "Other non-US", ""),
    _j("Code list: Agreement Market", "Cross-Border / Global", "Other non-US", ""),
    _j("Code list: Agreement Type", "Nominee Agreement", "Other EU/UK", "EU/UK nominee holding of units."),
    _j("Code list: Agreement Type", "Retrocession / Rebate Agreement", "MiFID II", "EU/UK trail commission or management-fee rebate; US revenue sharing is a lever value (Revenue Sharing Agreement)."),
    _j("Code list: Agreement Party Role", "Management Company", "UCITS", "UCITS ManCo / AIFM."),
    _j("Code list: Agreement Party Role", "Nominee", "Other EU/UK", ""),
    _j("Code list: Governing Law", "England and Wales", "Other EU/UK", "05 copy re-cut to US states; steward 39 decides the shared list."),
    _j("Code list: Governing Law", "Scotland", "Other EU/UK", ""),
    _j("Code list: Governing Law", "Luxembourg", "Other EU/UK", ""),
    _j("Code list: Governing Law", "Ireland", "Other EU/UK", ""),
    _j("Code list: Governing Law", "Germany", "Other EU/UK", ""),
    _j("Code list: Governing Law", "Switzerland", "Other non-US", ""),
    _j("Code list: Partner Channel", "IFA Network", "Other EU/UK", "List replaced by the local Distribution Channel copy (CW-140)."),
    _j("Code list: Partner Channel", "Discretionary Fund Manager", "Other EU/UK", "UK DFM."),
    _j("Code list: Service Model", "Non-Independent Advice", "MiFID II", "List merged into Account Eligibility (US account programs)."),
    _j("Code list: Service Model", "Independent Advice", "MiFID II", "Inducements must be passed on."),
    _j("Code list: Account Structure", "Nominee", "Other EU/UK", "EU/UK nominee holding."),
    _j("Code list: Payment Type", "Trail Commission (EU/UK)", "FCA", ""),
    _j("Code list: Payment Type", "Retrocession (EU/UK)", "MiFID II", ""),
    _j("Code list: Funding Source", "Management Company - Fee Share", "UCITS", "Retrocession out of the UCITS management fee."),
    _j("Code list: Funding Source", "Share Class Distribution Fee (EU)", "UCITS", "Separate distribution fee charged to an EU share class."),
    _j("Code list: Calculation Basis", "Management Fee Revenue", "MiFID II", "EU/UK retrocession basis."),
    _j("Code list: Retrocession Basis", "", "MiFID II", "Whole list: % of Management Fee, bps of Assets, % of Entry Charge."),
    _j("Code list: Account Eligibility", "ISA / SIPP", "Other EU/UK", "UK tax wrappers."),
    _j("Code list: Account Eligibility", "Unit-Linked Policy", "Other EU/UK", "EU/UK insurance wrapper."),
    _j("Code list: Dealing Route", "Calastone", "EU market practice", "Shared Dealing Route re-cut (CW-140); also recorded by 06 under CW-906."),
    _j("Code list: Dealing Route", "Clearstream Vestima", "EU market practice", ""),
    _j("Code list: Dealing Route", "Euroclear FundSettle", "EU market practice", ""),
    _j("Code list: Dealing Route", "Allfunds", "EU market practice", ""),
    _j("Code list: Settlement Method", "Calastone Settlement", "EU market practice", "List not carried (settlement is 29); 29 records the shared Fund Dealing Settlement Method values under its own decision."),
    _j("Code list: Settlement Method", "ICSD (Clearstream / Euroclear)", "EU market practice", ""),
    _j("Code list: Data Content Type", "EMT / EPT / EET", "FinDatEx", "FinDatEx templates."),
    _j("Code list: Partner Disclosure Type", "MiFID Ex-Ante Costs & Charges", "MiFID II", ""),
    _j("Code list: Partner Disclosure Type", "MiFID Ex-Post Costs & Charges", "MiFID II", ""),
    _j("Code list: Partner Disclosure Type", "MiFID Inducement Disclosure", "MiFID II", ""),
    _j("Code list: Partner Disclosure Type", "UK Platform Charges Disclosure", "FCA", "FCA COBS 6.1E."),
    _j("Code list: Attestation Type", "Inducement Quality-Enhancement Confirmation", "MiFID II", "Partner Attestation merged into Distributor Due Diligence."),
    # ---- code-list values: restored 02, 03 and 08 objects ----
    _j("Code list: Distribution Channel", "UK IFA / Network", "Other EU/UK", "Wholesale 02 list; not restored in the 05 Distribution Channel copy (brief section 4a). The shared-list values are recorded under CW-911 (proposals_w4_economics.py); record these once."),
    _j("Code list: Distribution Channel", "UK / EU Discretionary Fund Manager", "Other EU/UK", ""),
    _j("Code list: Distribution Channel", "Fund Platform / Supermarket", "Other EU/UK", "Wholesale 02 value described 'UK / EU'; the US platform sense is Intermediary - Brokerage Platform. Cross-reference CW-911."),
    _j("Code list: Distribution Channel", "EU Bank Distributor", "Other EU/UK", ""),
    _j("Code list: Firm Registration Type", "FCA Authorized Firm", "FCA", "Wholesale 02 list."),
    _j("Code list: Firm Registration Type", "FCA Appointed Representative", "FCA", ""),
    _j("Code list: Firm Registration Type", "EU MiFID Investment Firm", "MiFID II", ""),
    _j("Code list: Firm Registration Type", "EU Credit Institution", "Other EU/UK", ""),
    _j("Code list: Platform Offering", "UCITS / OEICs", "UCITS", "Wholesale 02 list."),
    _j("Code list: Branch Type", "Non-Registered Office (UK / EU sense)", "Other EU/UK", "Wholesale 02 value re-cut to RIA-Only Office (US sense kept)."),
    _j("Code list: Professional Type", "UK IFA", "FCA", "Wholesale 02 list."),
    _j("Code list: Professional Designation", "Chartered Financial Planner", "Other EU/UK", "UK CII designation."),
    _j("Code list: Professional Designation", "Certified Financial Planner (UK)", "Other EU/UK", ""),
    _j("Code list: Professional Designation", "CISI Chartered Wealth Manager", "Other EU/UK", ""),
    _j("Code list: Advisor Business Model", "UK IFA", "FCA", "Wholesale 02 list."),
    _j("Code list: Affiliation Type", "Appointed Representative", "FCA", "Wholesale 02 list (UK appointed representative regime)."),
    _j("Code list: Manager Database", "bfinance", "Other EU/UK", "Wholesale 03 list; UK/EU search consultant."),
    _j("Code list: Distributor Role", "Platform / Nominee", "Other EU/UK", "Wholesale 08 list, not carried with its attribute."),
    _j("Code list: Distributor Role", "IFA / Advisory Firm", "Other EU/UK", ""),
    _j("Code list: Distributor Role", "Discretionary Fund Manager", "Other EU/UK", ""),
    _j("Code list: Regulatory Register", "FCA Financial Services Register", "FCA", "Wholesale 08 list; the US checks are BrokerCheck and IAPD."),
    _j("Code list: DD Finding Category", "Target Market Controls", "MiFID II", "Wholesale 08 value (MiFID II product governance)."),
    _j("Code list: DD Finding Category", "Inducements / Remuneration", "MiFID II", "Replaced by Compensation Disclosure (Reg BI, Form CRS)."),
    # ---- sources: wholesale 05 ----
    _j("Sources", "MiFID II Directive 2014/65/EU Art. 24(9) and Delegated Directive (EU) 2017/593 Art. 11", "MiFID II", "Re-sourced to SEC IM Guidance Update 2016-01, FINRA Rule 2341 and Reg BI."),
    _j("Sources", "FCA Handbook COBS 2.3A, 6.1A, 6.1B and 6.1E (RDR adviser charging and platform rules)", "FCA", ""),
    _j("Sources", "FinDatEx European MiFID Template (EMT)", "FinDatEx", ""),
    _j("Sources", "Calastone, Clearstream Vestima, Euroclear FundSettle and Allfunds", "EU market practice", "DTCC NSCC Fund/SERV and Networking kept."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 8. DECISIONS: only the pre-allocated US-only decision of this domain (CW-022).
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-905", "theme": "Scope", "title": "US-only pass of Data Domain 05 Intermediary & Institutional Distribution (replacement of the wholesale 05)",
     "domains": ["05", "02", "03", "08"],
     "issue": "The wholesale 05 carried MiFID II inducement and costs data (FinDatEx EMT, ex-post inducement amounts, quality-enhancement assessments), "
              "UK RDR legacy trail, retrocessions, VAT on platform fees, EU dealing networks (Calastone, Clearstream Vestima, Euroclear FundSettle, "
              "Allfunds), EU/UK markets, passporting jurisdictions, MiFID investor types and service models, governing law and wrapper values, and "
              "EU/UK sources; the restored 02, 03 and 08 objects carry EU/UK channel, registration, designation, register and finding values.",
     "resolution": "Not carried (83 JURISDICTION entries in proposals_w4_05.py: 1 object, 16 attributes or attribute references, 62 code-list values "
                   "and lists, 4 sources; by regime Other EU/UK 30, MiFID II 22, FCA 11, EU market practice 8, FinDatEx 4, UCITS 4, Other non-US 3, "
                   "Consumer Duty 1). Object Distributor Data Exchange. Attributes Payment Arrangement.Inducement Relevance Indicator and Inducement "
                   "Assessment Reference; Distribution Fee Pass-Through.Retrocession Basis, Retrocession Rate, Pass-On to Client Required Indicator and "
                   "UK Legacy Trail Indicator; Payment Terms.VAT Applicable Indicator; Partner Dealer Setup.Dealing BIC; "
                   "Distribution Agreement.Agreement Market; Agreement Distribution Scope.Permitted Investor Types; the "
                   "FCA Register, ESMA, MiFID II and UK MLR references of the restored Employment Affiliation, Distributor Due Diligence, Regulatory "
                   "Status Check and Screening Result, the 08 Distributor Role and the EFT examples of Due Diligence Finding. Values: Agreement Market "
                   "(UK, EU, Switzerland, Cross-Border / Global); Agreement Type Nominee and Retrocession / Rebate Agreement; Agreement Party Role "
                   "Management Company and Nominee; six non-US Governing Law values; Partner Channel IFA Network and Discretionary Fund Manager; Service "
                   "Model Independent and Non-Independent Advice; Account Structure Nominee; Payment Type Trail Commission and Retrocession (EU/UK); "
                   "Funding Source Management Company - Fee Share and Share Class Distribution Fee (EU); Calculation Basis Management Fee Revenue; the "
                   "Retrocession Basis list; Account Eligibility ISA / SIPP and Unit-Linked Policy; Dealing Route Calastone, Clearstream Vestima, "
                   "Euroclear FundSettle, Allfunds; Settlement Method Calastone Settlement and ICSD; Data Content Type EMT / EPT / EET; Partner "
                   "Disclosure Type MiFID Ex-Ante, Ex-Post and Inducement Disclosure and UK Platform Charges Disclosure; Attestation Type Inducement "
                   "Quality-Enhancement Confirmation; restored Distribution Channel UK IFA / Network, UK / EU Discretionary Fund Manager, Fund Platform "
                   "(UK / EU), EU Bank Distributor; Firm Registration Type FCA Authorized Firm, FCA Appointed Representative, EU MiFID Investment Firm, "
                   "EU Credit Institution; Platform Offering UCITS / OEICs; Branch Type Non-Registered Office (UK / EU sense); Professional Type and "
                   "Advisor Business Model UK IFA; three UK designations; Affiliation Type Appointed Representative; Manager Database bfinance; "
                   "Distributor Role Platform / Nominee, IFA / Advisory Firm, Discretionary Fund Manager; Regulatory Register FCA Financial Services "
                   "Register; DD Finding Category Target Market Controls and Inducements / Remuneration. Sources MiFID II Art. 24(9) and Delegated "
                   "Directive 2017/593 Art. 11, FCA COBS 2.3A, 6.1A, 6.1B and 6.1E, FinDatEx EMT, and Calastone and the EU fund networks. Kept and "
                   "re-sourced: agreements, payments, caps and disclosures to SEC IM Guidance Update 2016-01, FINRA Rule 2341, SEC Rule 22c-2, SEC "
                   "Form N-1A Item 8, DOL 29 CFR 2550.408b-2 and Reg BI; dealer and networking set-up to DTCC NSCC Fund/SERV and Networking (Platform Participant ID kept as a generic platform-assigned identifier, re-described without Calastone and Allfunds); Agreement Distribution Scope.Permitted Jurisdictions kept and re-sourced to US states (ISO 3166-2:US, blue-sky notice filing); distributor "
                   "due diligence to OFAC, BrokerCheck, IAPD and SOC 1; ISO standards as market-neutral. Financial Professional.UK Certification Status "
                   "was recorded by 02 under CW-902 and is not repeated. META subtitle 'Wealth manager (direct) | Scope: US'.",
     "rationale": "CW-003, CW-022: a replaced domain records what it leaves out; a UK extension restores the content from tag wholesale-v1.0.",
     "action": "Merge JURISDICTION into jurisdiction.REMOVALS at the W4 merge", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 9. NOTES for the consolidation step.
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Size (review fix pass): 8 families, 53 objects (41 BO, 12 AG), 311 attributes, 97 CDEs (31.2%), 72 code lists (54 local, 18 copies of "
    "shared lists), 49 relationships, 23 sources. The 11 attributes above the brief's 300 come from restored-object completeness: the 22 "
    "restored objects keep the attributes their readers and the key registry use (DP-005 still loses 15 inputs, listed in READERS). "
    "Brief section 5 attributes cut and not restored: Discretionary RAUM, Top-Level Firm, Decision Authority, Job Title, Revenue Model, "
    "Client Niche, Order Cut-Off Time, Payment Direction, Minimum Annual Payment, Offset Method, Annual Commitment Amount, Team Lead "
    "(a Team Membership role), Number of Investment Adviser Representatives.",
    "Merge edit for 01 (review ruling 1, High): add 'Fund-Paid Sub-TA Fee Cap' (basis points, with a per-account amount variant) with "
    "'Approving Board Resolution (35)' to the fund fee terms (Management Fee group) of content_01_product.py. 05 Sub-Accounting Fee "
    "Terms.Fund-Paid Sub-TA Cap stays a Derived copy of that 01 term (IM Guidance Update 2016-01 board oversight).",
    "CW-131 decision note: Agreement Type 'Authorized Participant Agreement' is kept so 29 AP Agreement resolves; it is not a "
    "distribution-partner agreement, and the lead may move it to 39 Contract later. 'Co-Marketing Agreement' keeps 04 resolving.",
    "For steward 15 (Networking Level): DTCC's current Networking matrix lists levels 0, 3 and 4; 'Level 1' has no current definition and "
    "'Level 0' overlaps 'Not Networked' for most firms (trust and plan accounts are the exception). The 05 copy stays equal to the shared "
    "list until 15 drops Level 1 and resolves Level 0 versus Not Networked.",
    "Key mismatches with the key registry (data_models/keys_g2_03_04_05.py), for the lead at the merge: Model Program Placement's 05 key is "
    "Sponsor Program Agreement x Placed Model Portfolio (x effective date), while the registry pk is [Placed Model Portfolio, Model "
    "Placement Effective From]; Share Class Mapping's 05 grain is Mapping Partner x Mapped Account Type x Mapped Share Class, while the "
    "registry pk is [Mapped Share Class, Mapped Account Type]. READERS gives the pk re-cuts.",
    "Program Membership now carries Member Party (PTY-), matching GRAIN_KEY_FORMATS '<PGM- id> / <PTY- id of the member> / <effective from>'.",
    "Internal 05 profile references are typed to the 05 object (Reference (Distributor Firm, 05), (Hierarchy Node, 05), (Branch / Office, "
    "05), (Advisor Team, 05), (Financial Professional, 05), (Consultant Profile, 05)); 15 interim OWNERSHIP_OVERRIDES in enrich_05.py "
    "force them to 'mastered here' because the PTY- example resolves to 02. The '<role> Party' keys stay Reference (Party).",
    "Restored by exact name: 02 Distributor Firm, Form ADV Profile, Hierarchy Node, Branch / Office, Advisor Team, Team Membership, Gatekeeper "
    "Profile, Financial Professional, Advisor Practice, Employment Affiliation, External Classification, Consultant Profile, Consultant Advisory "
    "Relationship (CW-132); 03 Sales Opportunity, Pipeline Status, Opportunity Value, Win / Loss, RFP Request, RFP Submission, Database Profile, "
    "Database Submission, Consultant Rating, and Placement & Plan Detail (renamed, CW-134); 08 Distributor Due Diligence, Due Diligence Finding "
    "(CW-135); 13 Intermediary Communication Fee Invoice (CW-088). Kept by name: the 25 wholesale 05 objects of proposals_w4_channels.py KEPT_OBJECTS.",
    "Restored 02 attribute sets were confirmed against the compiled wholesale module content/__pycache__/content_02_client_and_customer.cpython-314.pyc "
    "(loaded with python3.14 from a scratchpad script; source-equivalent to tag wholesale-v1.0 per proposals_w4_channels.py NOTES). Each profile "
    "BO gains a '<role> Party' key (Distributor Firm Party, Hierarchy Node Party, Branch Party, Advisor Team Party, Gatekeeper Party, Financial "
    "Professional Party, Classified Party, Consultant Party; Employment Affiliation gains Affiliated Professional) typed Reference (Party).",
    "Party core not re-mastered (CD-143): Branch CRD Number, TA Dealer Number and NSCC Participant Number are declared Derived copies of the 02 "
    "party identifiers; Advisor Team.Team Name is not carried (the 02 Party Display Name); Clearing Firm is held once, on Distributor Firm.",
    "Profiles keyed by PTY- resolve to 02 in the ownership resolver; Placement & Plan Detail.Plan Recordkeeper is forced to 16 (Recordkeeper "
    "Profile, CW-133). The interim overrides for OPP-, RFP- and DDQ- can be removed once decisions.PREFIXES moves OPP-, RFP-, DBS-, DDQ- and "
    "IFI- (all five restored prefixes) to owner 05.",
    "check_enrichment.py picks a content_05_* module by os.listdir order. With both 05 modules in content/ it picked the new module (53 objects) "
    "on 2026-10-15; the order is not guaranteed, so the draft was also checked with a scratchpad wrapper bound to the new module (same result).",
    "Shared Dealing Route and Governing Law still carry EU/UK values in shared_code_lists.py; because 05 is a registered member, the consolidated "
    "05 workbook shows them until the stewards (06, 39) apply the re-cuts. The 05 local copies hold the US values only.",
    "CW-165: insurance values of the wholesale lists (Agreement Type Unit-Linked / Insurance Distribution Agreement, Partner Channel Insurer / "
    "Unit-Linked, Agreement Party Role Insurer, Placement Agent and Placement Agent Agreement with 30) are not carried; they are not EU/UK-only and "
    "have no JURISDICTION entry. Platform Offering 'Annuities' and Professional Type 'Insurance Producer' stay as descriptions of partners.",
    "12 review rulings (coordinator, 2026-10-15): (1) the won-opportunity link is held on the 12 side, 12 Mandate Onboarding.Won "
    "Opportunity -> 05 Sales Opportunity (OPP-); 05 holds no 'Resulting Service Relationship' attribute on Win / Loss (the wholesale 03 had none "
    "either), only a relationship row noting that 12 holds it. (2) 11 Mandate Search Event.Asset Owner stays Reference (Party, 02): not re-pointed, "
    "prospects (an asset owner in a search is a prospect, not a 12 Institutional Client). proposals_w4_channels.py CW-133 and READERS list it among "
    "the INST_CLIENT re-points; the lead drops it from that list.",
    "Dependencies: 03 adds intermediary and institutional activity types to Advisor Activity (CW-138); 06 reads Partner Coverage Assignment for "
    "Salesperson Credit and Distributor Firm.Distribution Channel for channel attribution; 12 restores Institutional Client and references 05 "
    "Consultant Advisory Relationship; 16 restores Recordkeeper Profile (Placement & Plan Detail.Plan Recordkeeper); 10 reads PYA- and PCL-; 19 "
    "reads Partner Invoice, Partner Payment and IFI-; 08 owns Compliance Review (REV-) used by Database Submission and RFP Submission.",
]
