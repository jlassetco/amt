"""Consolidation proposals from the W4 draft of Data Domain 06 Client Assets, Flows & Channel Attribution (wealth manager),
2026-10-15.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py,
shared_code_lists.py and jurisdiction.REMOVALS at the W4 merge. Formats follow CONTRACT.md in this folder. The brief is
00_Program/Rework/Briefs/06_Client_Assets_Flows_and_Channel_Attribution.md (Disposition: Adapt, CW-141). It implements CW-003,
CW-007, CW-011, CW-013, CW-022, CW-122 and CW-140 to CW-145 (proposals_w4_channels.py) and drafts CW-906, the US-only pass of 06.
Module: content_06_sales_transactions_and_aum_attribution.py (edited in place; output path and folder unchanged; the file and
folder are renamed at integration with domains.py). The brief names this file proposals_06.py; the assignment named it
proposals_w4_06.py, which is used.
"""

_D, _C = "06", "CW-906"

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES: none beyond CHASG- (reserved by CW-148 in proposals_w4_channels.py). Account Asset Summary uses the composite key
#    <ACC- id> / <as-of date> / <holding type> (GRAIN_KEY_FORMATS in proposals_w4_channels.py).
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED MEMBERSHIPS (local list -> shared list, label -> code)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Dealing Route", "local": "Order Entry Channel",
     "value_map": {"NSCC Fund/SERV": "NSCC_FUNDSERV", "NSCC DCC&S": "NSCC_DCCS", "NSCC CNS / ETF Portal": "NSCC_CNS_ETF",
                   "Affiliated Broker-Dealer Omnibus": "OWN_BD_OMNIBUS", "TA Direct": "TA_DIRECT",
                   "Recordkeeper File": "RECORDKEEPER_FILE", "Sponsor File": "SPONSOR_FILE"},
     "new_values": ["OWN_BD_OMNIBUS"],
     "note": "Re-cut by CW-140 (steward 06). Remove CALASTONE, CLEARSTREAM_VESTIMA, EUROCLEAR_FUNDSETTLE, ALLFUNDS from the shared "
             "values and from the 06 value map (JURISDICTION below; 05 records its own under CW-905). Add OWN_BD_OMNIBUS with the 29 label 'Affiliated "
             "Broker-Dealer Omnibus' (fix pass: labels follow 29, the direct user; TA_DIRECT label 'TA Direct'). SWIFT_DIRECT is "
             "removed from the 06 map (29 has no SWIFT route; not a jurisdiction removal); retire it from the shared list at W5 "
             "unless 05 still uses it. Update the list source "
             "text to 'Internal (DTCC NSCC services; SWIFT ISO 20022 setr)'."},
    {"shared": "Distribution Channel", "local": "Distribution Channel",
     "value_map": {"Direct": "DIRECT", "Direct - Self-Directed": "DIRECT_SELF_DIRECTED", "Direct - Digital Advice": "DIRECT_DIGITAL_ADVICE",
                   "Direct - Human Advice": "DIRECT_HUMAN_ADVICE", "Direct - Trust": "DIRECT_TRUST",
                   "Workplace": "WORKPLACE", "Workplace - Recordkept Plan": "WORKPLACE_RECORDKEPT",
                   "Institutional": "INSTITUTIONAL", "Institutional - Direct": "INSTITUTIONAL_DIRECT",
                   "Institutional - Consultant-Led": "INSTITUTIONAL_CONSULTANT", "Institutional - OCIO": "INSTITUTIONAL_OCIO",
                   "Intermediary": "INTERMEDIARY", "Intermediary - Wirehouse": "INTERMEDIARY_WIREHOUSE",
                   "Intermediary - National / Regional Broker-Dealer": "INTERMEDIARY_REGIONAL_BD",
                   "Intermediary - Independent Broker-Dealer": "INTERMEDIARY_IBD", "Intermediary - RIA": "INTERMEDIARY_RIA",
                   "Intermediary - Bank / Trust": "INTERMEDIARY_BANK_TRUST",
                   "Intermediary - TAMP / Model Marketplace": "INTERMEDIARY_TAMP_MODEL",
                   "Intermediary - Brokerage Platform": "INTERMEDIARY_BROKERAGE_PLATFORM",
                   "Intermediary - Third-Party Recordkeeper": "INTERMEDIARY_RECORDKEEPER"},
     "new_values": ["DIRECT", "DIRECT_SELF_DIRECTED", "DIRECT_DIGITAL_ADVICE", "DIRECT_HUMAN_ADVICE", "DIRECT_TRUST", "WORKPLACE",
                    "WORKPLACE_RECORDKEPT", "INSTITUTIONAL_OCIO", "INTERMEDIARY_BROKERAGE_PLATFORM", "INTERMEDIARY_RECORDKEEPER"],
     "note": "The CW-164 values with the CW-140 refinement (RETIREMENT_DCIO -> INTERMEDIARY_RECORDKEEPER); labels follow the drafted "
             "05 module (content_05_intermediary_and_institutional_distribution.py line 556), which carries the same codes without the "
             "DIRECT_ values. The 'advised and managed' roll-up is defined on "
             "Measure Definition.Included Distribution Channels, not as a list level. Old 06 labels: Wirehouse, Regional "
             "Broker-Dealer, Independent Broker-Dealer, RIA and Bank / Trust keep their codes; Private Bank merges into "
             "INTERMEDIARY_BANK_TRUST, Insurance retires (CW-165), DCIO / Retirement becomes INTERMEDIARY_RECORDKEEPER, Institutional "
             "Direct and Institutional Consultant-Led keep their codes, Direct to Investor becomes DIRECT, Sub-Advisory retires "
             "(CW-164); the three EU/UK labels are in JURISDICTION. Distribution Market: 06 is not a member (retired)."},
    {"shared": "Business Line", "local": "Business Line",
     "value_map": {c: c for c in ("DB", "DA", "HA", "PF", "WR", "IA", "IC", "TR")}, "new_values": [],
     "note": "New member (CW-004, CW-140). Account Channel Assignment.Assigned Business Line, Market & Client Dimensions.Business "
             "Line. Two-letter codes as values (identity map, as 02, 13 and 15)."},
    {"shared": "Reconciliation Status", "local": "Break Status",
     "value_map": {"Open": "BREAK_OPEN", "Investigating": "BREAK_OPEN", "Resolved": "RECONCILED",
                   "Accepted (Within Materiality)": "RECONCILED_WITHIN_TOLERANCE"},
     "new_values": [],
     "note": "New member (CW-140): 06 is the steward and now a member through its Break Status list (Break.Break Status). "
             "Investigating has no own code; it maps to BREAK_OPEN."},
    {"shared": "Message Standard", "local": "Message Standard",
     "value_map": {"DTCC Fund/SERV": "DTCC_FUNDSERV", "DTCC Networking": "DTCC_NETWORKING",
                   "DTCC Omni/SERV Activity Record": "DTCC_OMNISERV_ACTIVITY", "DTCC Omni/SERV Position Record": "DTCC_OMNISERV_POSITION",
                   "ISO 20022 setr": "ISO_20022_SETR", "ISO 20022 semt": "ISO_20022_SEMT", "Vendor Proprietary": "PROPRIETARY"},
     "new_values": [],
     "note": "Kept membership; FundsXML removed from the 06 map (JURISDICTION). As steward, 06 proposes retiring FUNDSXML from the "
             "shared values at W5 unless a direct user still needs it (none found in the 05 brief); the list source text drops "
             "'FundsXML'."},
    {"shared": "Flow Direction", "local": "Flow Direction",
     "value_map": {"Inflow": "INFLOW", "Outflow": "OUTFLOW", "Neutral": "NEUTRAL"}, "new_values": [],
     "note": "Kept membership, unchanged (steward 06)."},
    {"shared": "Frequency", "local": "Frequency",
     "value_map": {"Intraday": "INTRADAY", "Daily": "DAILY", "Weekly": "WEEKLY", "Monthly": "MONTHLY", "Quarterly": "QUARTERLY",
                   "Ad Hoc": "AD_HOC"}, "new_values": [], "note": "Kept membership, unchanged."},
    {"shared": "Data Basis", "local": "Data Basis",
     "value_map": {"Actual": "REPORTED", "Estimated": "ESTIMATED", "Allocated": "ALLOCATED", "Mixed": "MIXED"}, "new_values": [],
     "note": "Kept membership, unchanged."},
    {"shared": "Period Type", "local": "Period Type",
     "value_map": {"Day": "DAY", "Week": "WEEK", "Month": "MONTH", "Quarter": "QUARTER", "Year": "YEAR",
                   "Year-to-Date": "YEAR_TO_DATE", "Rolling 12 Months": "ROLLING_12_MONTHS"}, "new_values": [],
     "note": "Kept membership, unchanged."},
    # Memberships to remove at merge
    {"shared": "Data Quality Status", "local": "", "value_map": {}, "new_values": [],
     "note": "REMOVE ('06', 'Data Quality Status') from the members (shared_code_lists.py line 106) and its value map (line 118): "
             "the list left with the excluded Record Metadata object (CD-160)."},
    {"shared": "Information Classification", "local": "", "value_map": {}, "new_values": [],
     "note": "REMOVE ('06', 'Data Classification') from the members (shared_code_lists.py line 691) and its value map (line 703): "
             "Record Metadata dropped (CD-160)."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED CANDIDATES
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Holding Type", ["06", "49", "10", "46", "32"],
     "The eleven CW-142 values split Client Assets and Net New Assets; 49 Client Holding, 10 Client Revenue Record and 46 and 32 "
     "client reporting group assets the same way. Candidate shared list, steward 06 (or 49)."),
    ("Source Book", ["06", "21"],
     "Book-of-record identifiers (49, 50, 29, 16, 18, intermediary feed) used for lineage; 21 lineage metadata may want the same "
     "values."),
    ("Transaction Type", ["06", "49", "50", "29", "16"],
     "06's conformed flow types map one-to-one onto 49 activity types, 50 movement types, 29 register posting types and 16 "
     "contribution and distribution types. Not a shared list (each book keeps its own); propose a crosswalk table at W5."),
    ("Channel Assignment Basis", ["06", "10"],
     "10 assigns revenue to channels on the same basis; 10 should read Account Channel Assignment rather than keep its own."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (decisions.TERM_CONFLICTS format)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Transaction",
     "usages": [("06", "Transaction (TXN-), glossary Flow Transaction", "Conformed flow record copied from the books, mastered only for intermediary rows."),
                ("49", "Client Account Activity (CLACT-)", "Posting to a client account in the brokerage book."),
                ("50", "Money Movement (MMVMT-)", "ACH, wire, check or internal cash movement."),
                ("29", "Register Transaction (RGTX-) / Fund Order (FNDO-)", "TA posting and the order behind it."),
                ("18", "Portfolio Transaction", "Fund or institutional portfolio trade."),
                ("16", "Participant Ledger Posting (PLPST-)", "Posting to a participant balance."),
                ("48", "Client Order", "A client's brokerage order before execution.")],
     "recommendation": "Definitions say 'flow transaction' for 06; the object keeps the name Transaction for its readers (CW-141).",
     "resolution": "Five concepts kept distinct.", "status": "Resolved", "decision": "CW-149"},
    {"term": "Position",
     "usages": [("06", "Fund Shareholder Position (POS-)", "Own-fund units held by an account; a view of 49 and 29."),
                ("49", "Client Holding (CLHLD-)", "Brokerage book of record."),
                ("18", "Portfolio Holding (HLD-)", "Fund and institutional portfolio book."),
                ("16", "Participant Balance", "Workplace participant balance.")],
     "recommendation": "No bare 'Position' in 06; ETF Holding, Plan Position and Sponsor-Reported Assets keep their names for "
                       "readers and say in their definitions that they are intermediary-delivered own-fund assets, not Client Holdings.",
     "resolution": "Renamed Position -> Fund Shareholder Position.", "status": "Resolved", "decision": "CW-007"},
    {"term": "Assets",
     "usages": [("06", "Client Assets (MSR-CLIENTASSETS)", "Market value of every client account at the firm."),
                ("06", "Advised Assets (MSR-ADVISEDASSETS)", "Client Assets in fee-based advice and managed enrollments."),
                ("06", "Asset Measures (Beginning / Ending / Average AUM)", "Own-fund assets by channel (fund AUM by channel)."),
                ("27 / 46 / 18", "Firm AUM (DP-165)", "Own funds at NAV plus managed and institutional assets."),
                ("38", "Form ADV regulatory assets under management", "Item 5.F RAUM.")],
     "recommendation": "Never bare 'AUM' in new 06 text; the kept Asset Measures names (Beginning AUM etc.) are defined as own-fund "
                       "assets by channel. W5 may rename them 'Beginning Fund Assets' with their readers (DP-008, SM-01, DP-024, "
                       "DP-055).",
     "resolution": "Two certified families, overlap reported here (CW-011).", "status": "Open", "decision": "CW-149"},
    {"term": "Channel",
     "usages": [("06", "Distribution Channel (Account Channel Assignment)", "The client channel of an account."),
                ("01", "Distribution Channel", "Channel a product or offering is available through."),
                ("13", "Service Channel", "Communication channel of a service interaction."),
                ("04", "engagement channels", "Marketing channel of a touch.")],
     "recommendation": "06 and 01 share the shared list; 13 and 04 say 'service channel' and 'marketing channel'.",
     "resolution": "Logged.", "status": "Resolved", "decision": "CW-149"},
    {"term": "Advisor",
     "usages": [("06", "Market & Client Dimensions.Covering Advisor", "Firm advisor (03)."),
                ("06", "Distributor Hierarchy.Advisor / Rep", "External financial professional (05).")],
     "recommendation": "The kept name 'Advisor / Rep' is defined as the external financial professional; the Attribution Dimension "
                       "value 'Advisor' is relabeled 'Financial Professional' and 'Firm Advisor' is added.",
     "resolution": "Defined in each attribute.", "status": "Resolved", "decision": "CW-149"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION (jurisdiction.REMOVALS entry format; CW-022, CW-906)
# ---------------------------------------------------------------------------------------------------------------------


def _j(obj, attr, regime, note):
    return {"domain": _D, "object": obj, "attribute": attr, "regime": regime, "decision": _C, "note": note}


JURISDICTION = [
    # Attributes
    _j("Market & Client Dimensions", "Platform / Fund Distributor (EU/UK)", "EU market practice",
       "Platform, fund supermarket or nominee through which EU/UK flows were placed. US intermediary attribution uses the 05 "
       "Distributor Hierarchy (channel value Intermediary - Brokerage Platform)."),
    _j("Market & Client Dimensions", "Investor Country", "MiFID II",
       "End-investor country for MiFID II distribution-chain reporting. Nonresident clients are visible from 02 party data."),
    _j("Omnibus Look-Through", "Nominee / Platform Account Indicator", "Other EU/UK",
       "Whether the parent was an EU/UK nominee or platform account (UK and EU market practice). US omnibus accounts are a 15 "
       "account type and a 29 register account category."),
    # Code values of kept lists
    _j("Code list: Order Entry Channel", "Calastone", "UK market practice", "UK fund order network; shared Dealing Route re-cut (CW-140)."),
    _j("Code list: Order Entry Channel", "Clearstream Vestima", "EU market practice", "Luxembourg fund order routing (CW-140)."),
    _j("Code list: Order Entry Channel", "Euroclear FundSettle", "EU market practice", "EU fund order routing (CW-140)."),
    _j("Code list: Order Entry Channel", "Allfunds", "EU market practice", "EU fund platform (CW-140). US route added: Own Broker-Dealer Omnibus."),
    _j("Code list: Distribution Channel", "Fund Platform (EU/UK)", "Other EU/UK", "UK and EU fund platforms (CW-164)."),
    _j("Code list: Distribution Channel", "IFA / Wealth Manager (EU/UK)", "Other EU/UK", "UK and EU independent financial advisers (CW-164)."),
    _j("Code list: Distribution Channel", "Discretionary Fund Manager (UK)", "UK market practice", "UK discretionary fund managers (CW-164)."),
    _j("Code list: Sales Charge Type", "Initial Charge (EU/UK)", "Other EU/UK",
       "EU/UK initial charge; the whole list left with Transaction Sales Charge (no-load default, CW-141; not a jurisdiction removal)."),
    _j("Code list: Intermediary Identifier Type", "FCA FRN", "FCA", "FCA Firm Reference Number (CW-144); US identifiers CRD and IARD stay."),
    _j("Code list: Transfer Type", "Platform Re-Registration (UK)", "UK market practice",
       "UK platform re-registration; US transfers are ACATS (FINRA Rule 11870), non-ACATS, re-registration and rollovers."),
    _j("Code list: Look-Through Source", "Nominee Disclosure (EU/UK)", "Other EU/UK", "EU/UK nominee disclosure; US look-through is Omni/SERV and SEC Rule 22c-2."),
    _j("Code list: Attribution Dimension", "Platform", "EU market practice", "Dimension of the removed Platform / Fund Distributor (EU/UK)."),
    _j("Code list: Attribution Dimension", "Investor Country", "MiFID II", "Dimension of the removed Investor Country."),
    _j("Code list: Intermediary Identifier Type", "Platform Distributor Code", "EU market practice",
       "Distributor code assigned by an EU fund platform (remnant of the removed platform content; no US instance; fix pass)."),
    _j("Code list: Look-Through Source", "Platform Data Service", "EU market practice",
       "Platform look-through data service (Calastone or Allfunds style); US look-through is Omni/SERV and SEC Rule 22c-2 (fix pass)."),
    _j("Code list: File Format", "XML (FundsXML)", "EU market practice",
       "FundsXML is a European fund-data exchange standard; US feeds use DTCC layouts, ISO 20022 and APIs."),
    _j("Code list: Message Standard", "FundsXML", "EU market practice", "06 map of the shared Message Standard (SHARED_MEMBERSHIPS)."),
    # Sources
    _j("Sources", "EFAMA statistical releases (monthly fact sheet, quarterly statistical release)", "Other EU/UK",
       "European UCITS / AIF net sales. ICI and Morningstar definitions stay; Business Definition, Industry Definition Alignment, "
       "Gross Sales, Redemptions, Net Flows and Money Market Inclusion re-sourced to ICI and Morningstar."),
    _j("Sources", "Calastone (order routing and Data Services)", "UK market practice", "Cited only by the removed EU/UK channel and platform content."),
    _j("Sources", "Clearstream Vestima", "EU market practice", "Cited only by the removed channel value and nominee indicator."),
    _j("Sources", "Allfunds", "EU market practice", "Cited only by the removed channel value and platform attribution."),
    _j("Sources", "MiFID II (distribution chain / target market feedback)", "MiFID II", "Cited only by Investor Country."),
    _j("Sources", "FundsXML", "EU market practice", "Cited only by the removed file format and message standard values."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. REPOINTS (object, attribute, before, after, decision): re-cuts, renames, re-typings and removals that are not EU/UK
# ---------------------------------------------------------------------------------------------------------------------
REPOINTS = [
    ("Position", "", "Position (POS-)", "Fund Shareholder Position (POS- kept)", "CW-007, CW-141"),
    ("Transaction Sales Charge", "", "7 attributes (Sales Charge Type, Rate, Amount, CDSC Amount, Breakpoint Applied Indicator, Sales Charge Waiver Reason, Dealer Concession Amount)",
     "removed; no-load reference default; brokerage commissions are 48 and 47 (lever restores from wholesale-v1.0)", "CW-141"),
    ("Record Metadata", "", "9 attributes (TX-DMM)", "removed (CD-160)", "CD-160"),
    ("Market & Client Dimensions", "Territory", "Reference (Territory) TER- (07)", "removed; 07 retires (CW-907); suspense by channel", "CW-143"),
    ("Salesperson Credit", "Crediting Rule Applied", "Reference (Crediting Rule) CRR- (07)", "removed; replaced by Source Partner Coverage Assignment (05, PCVG-)", "CW-143"),
    ("Unattributed Item", "Suspense Territory / Bucket", "Reference (Territory)", "removed; replaced by Suspense Channel (Code, Distribution Channel)", "CW-143"),
    ("Reporting Period", "Compensation Cut-Off Date", "Date (07)", "removed; 07 retires; Restatement.Compensation Impact Indicator reads 03 incentive statements", "CW-143"),
    ("Asset Measures", "FX Effect", "Amount", "removed; own funds are USD share classes (lever restores for non-USD classes)", "CW-141"),
    ("Transaction", "Networking Matrix Level (As Delivered)", "Code (lineage)", "removed; the authoritative value is 15 Intermediary Account Servicing.Networking Level", "CW-141"),
    ("Data Feed", "Coverage - Markets", "Code (multi) ISO 3166", "removed; US only, a single value (as Distribution Market, CW-164)", "CW-906"),
    ("Distributor Hierarchy", "Distributor Firm; Distributor Office / Branch; Advisor Team; Advisor / Rep", "Reference (Party) 02",
     "Reference (Distributor Firm / Branch / Office / Advisor Team / Financial Professional, 05)", "CW-132"),
    ("Intermediary As Delivered", "Resolved Distributor Firm; Resolved Office / Branch; Resolved Advisor / Rep", "Reference (Party) 02",
     "Reference (Distributor Firm / Branch / Office / Financial Professional, 05)", "CW-132"),
    ("Linked Transaction", "Contra Firm", "Reference (Party) 02", "Reference (Distributor Firm, 05)", "CW-132"),
    ("Plan Position", "Recordkeeper; Plan Advisor", "Reference (Party) 02", "Reference (Recordkeeper Profile, 16); Reference (Financial Professional, 05)", "CW-132, CW-133"),
    ("Sponsor-Reported Assets", "Sponsor", "Reference (Party) 02", "Reference (Distributor Firm, 05)", "CW-132"),
    ("Market & Client Dimensions", "Institutional Client; Consultant", "Reference (Party) 02", "Reference (Institutional Client, 12); Reference (Consultant Profile, 05)", "CW-133, CW-132"),
    ("Attribution Record", "Source Position", "Reference (Position)", "Reference (Fund Shareholder Position)", "CW-007"),
    ("Transaction / Fund Shareholder Position / Account Asset Summary", "row rules", "CD-199: Trade Date and As-Of Date Derived from 29 Fund Order",
     "CW-141 row rule: type, dates, units, amounts and account Derived from the source book (49, 50, 29 Register Transaction, 16, 18); mastered for intermediary rows", "CW-141, CW-122"),
    ("Intermediary As Delivered / ETF Holding / Identifier Crosswalk / Salesperson Credit", "DERIVED", "02 (Dealer, Branch, Rep numbers, Rep Name, Clearing Firm, DTC Participant, CRD); 07 (Credit Role)",
     "05 for all", "CW-132, CW-143"),
    ("Omnibus Look-Through", "Sub-Account Identifier As Delivered", "Derived copy (02)", "mastered here as delivered (look-through rows)", "CW-141"),
    ("Code list: Transaction Type", "", "19 wholesale fund-flow values", "30 values: adds Cash Deposit and Withdrawal, ACATS Transfer In and Out, Securities Received and Delivered, Journal In and Out, Rollover In and Out, Fee Debit", "CW-141"),
    ("Code list: Distribution Channel", "Private Bank; Insurance; Sub-Advisory; DCIO / Retirement; Direct to Investor", "wholesale labels",
     "merged into Bank / Trust; retired (CW-165); retired (CW-164); Intermediary - Recordkeeper (CW-139); Direct", "CW-164, CW-140"),
    ("Code list: Attribution Dimension", "Territory; Advisor", "Territory; Advisor", "removed; relabeled Financial Professional (Firm Advisor, Business Line, Service Offering, Holding Type, Client Household, Campaign added)", "CW-143"),
    ("Code list: Allocation Basis", "Territory Default", "Territory Default", "removed", "CW-143"),
    ("Code list: Unattributed Reason", "Territory Not Aligned", "Territory Not Aligned", "removed; No Channel Assignment added", "CW-143"),
    ("Code list: Feed Type", "Transfer Agent; Recordkeeper (DCIO)", "Transfer Agent; Recordkeeper (DCIO)",
     "Transfer Agent Register (29); Third-Party Recordkeeper; adds Brokerage Book of Record (49), Money Movement (50), Workplace Recordkeeping (16), Institutional Portfolio Book (18)", "CW-141"),
    ("Code list: Reconciliation Type", "TA vs Fund Accounting", "TA vs Fund Accounting", "removed (29 TA Control Check capital stock proof); Client Asset Summary vs Source Book added", "CW-141"),
    ("Code list: Look-Through Level", "Direct Account", "Direct Account", "Firm Client Account", "CW-141"),
    ("Code list: Source Record Type", "Position", "Position", "Fund Shareholder Position; Account Asset Summary added", "CW-007"),
    ("Code lists", "Sales Charge Type; Sales Charge Waiver Reason; Data Quality Status; Data Classification; Networking Matrix Level",
     "local lists", "removed with their attributes", "CW-141, CD-160"),
    # ---- 06 fix pass (program-lead rulings on 00_Program/Rework/Reviews/06_review.md) ----
    ("Fund Shareholder Position", "Market Value (Reporting Currency)", "Amount", "removed (equal to Market Value for USD classes); readers use Market Value", "06 review"),
    ("Fund Shareholder Position", "Register Account Category; Aggregation Role; Source As-Of Timestamp", "", "added (counting rule; Register Account Category Derived from 29)", "06 review"),
    ("Fund Shareholder Position", "Valuation NAV", "27 NAV on every row", "27 NAV on 29 register rows only; 49 rows carry the 49 Client Holding Valuation", "06 review"),
    ("Account Asset Summary", "Summary Source Book; Summary Market Value", "any source incl. intermediary feed; market value", "firm client accounts only; net equity (lever: gross long value); Source As-Of Timestamp added", "06 review"),
    ("Order Source", "Source Money Movement; Source Contribution Record; Source Distribution Request", "References (50, 16)", "removed; 50 reaches 06 through its 49 posting; replaced by Source Participant Ledger Posting (16, PLPST-)", "06 review"),
    ("Order Source", "Source Channel Assignment", "", "added (generated Inter-Channel Transfer rows)", "06 review"),
    ("Linked Transaction", "Contra Firm", "Reference (Distributor Firm, 05)", "Reference (Party), Derived copy of 49 Account Transfer.Contra Firm", "06 review"),
    ("Linked Transaction", "Conversion Reason", "Code", "removed with its list (load-share content under the no-load default)", "06 review"),
    ("Linked Transaction", "From Distribution Channel; To Distribution Channel", "", "added (inter-channel transfer amount)", "06 review"),
    ("Measure Value", "Dimension Grain; Distribution Channel; Share Class", "Code (multi) and two fixed slots", "Dimension Type (Code) and Dimension Key (Identifier): key measure x period end x dimension type x dimension key", "06 review"),
    ("Measure Definition", "Sign Convention; Industry Definition Alignment", "Code", "removed with their lists (outflows always negative; alignment stated in the references)", "06 review"),
    ("Load", "Completeness Status", "Code", "merged into Load Status (Expected, Received Late, Partial, Missing added)", "06 review"),
    ("Snapshot", "Snapshot Status", "Code", "merged into Snapshot Type (stage gives the lock status)", "06 review"),
    ("Client Asset Measures", "Average Client Assets; Client Assets Excluding Intermediary-Held", "", "added (10 reads MSR-AVGCLIENTASSETS; subtotal lever)", "06 review"),
    ("Unattributed Item", "", "Attribute Group of Attribution Record", "Business Object with Unattributed Item ID (UNA-)", "06 review"),
    ("Attribution Override; Identifier Crosswalk", "Override ID; Crosswalk ID", "", "added (OVR-, XWK-)", "06 review"),
    ("Market & Client Dimensions", "Source Attributed Outcome", "", "added (Reference (Attributed Outcome, 04))", "06 review"),
    ("Identifier Crosswalk", "Source Address / Postcode", "Source Address / Postcode", "Source Address / ZIP Code", "06 review"),
    ("Data Feed", "Latency; Historical Depth; Transport Method", "", "removed (size band; Transport Method list removed)", "06 review"),
    ("ETF Holding; Attribution Method", "Office-Level Detail Indicator; Match Confidence Score", "", "removed (size band; Match Confidence Band kept)", "06 review"),
    ("Code lists", "Credit Role; Contribution Source Type; License Use Restriction; ETF Basket Type", "local copies", "External (05 Partner Coverage Role / 03 Coverage Role; 16 Contribution Source; 14 Permitted Use Category; 29 Basket Settlement Form)", "06 review"),
    ("Code list: Order Entry Channel", "Own Broker-Dealer Omnibus; TA Direct (Web / Phone / Mail); SWIFT ISO 20022 Direct", "06 labels", "Affiliated Broker-Dealer Omnibus; TA Direct; removed", "06 review"),
    ("Code list: Distribution Channel", "Workplace - Recordkept; Intermediary - Recordkeeper", "06 labels", "Workplace - Recordkept Plan; Intermediary - Third-Party Recordkeeper (as 05)", "06 review"),
    ("Code list: Transaction Type", "", "30 values", "33 values: Income Received, Tax Withholding, Inter-Channel Transfer added; precedence note", "06 review"),
    ("Code list: Measure Category", "Revenue; Market Share", "Revenue; Market Share", "Revenue Estimate; removed (11)", "06 review"),
    ("Code list: Source Book; Feed Type", "Money Movement (50)", "value", "removed; Account Channel Assignment (06) added to Source Book", "06 review"),
    ("Code list: Override Scope", "Account Channel Assignment", "value", "removed (channel changes are assignment versions)", "06 review"),
    ("Sources", "FINRA Rule 2341; SEC Form N-1A; DCAM", "sources", "removed (cited only by Transaction Sales Charge and Record Metadata)", "CW-141, CD-160"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. DECISIONS: the US-only pass of 06 (pre-allocated)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-906", "theme": "Scope", "title": "US-only pass of Data Domain 06 Client Assets, Flows & Channel Attribution",
     "domains": ["06", "05", "09"],
     "issue": "The wholesale 06 carried EU/UK platform and nominee attribution, investor country for MiFID II, EU dealing networks "
              "(Calastone, Clearstream Vestima, Euroclear FundSettle, Allfunds), UK and EU channel values, the FCA FRN, UK platform "
              "re-registration, the EU/UK initial charge, nominee disclosure, FundsXML and EFAMA, Calastone, Clearstream, Allfunds, "
              "FundsXML and MiFID II sources, and 'asset manager that distributes wholesale', 'EU/UK fund platforms' and EFAMA "
              "alignment in its perspective text.",
     "resolution": "Removed (26 JURISDICTION entries: 3 attributes, 17 code values, 6 sources): Market & Client Dimensions.Platform / "
                   "Fund Distributor (EU/UK) and Investor Country; Omnibus Look-Through.Nominee / Platform Account Indicator; Order "
                   "Entry Channel values Calastone, Clearstream Vestima, Euroclear FundSettle, Allfunds; Distribution Channel values "
                   "Fund Platform (EU/UK), IFA / Wealth Manager (EU/UK), Discretionary Fund Manager (UK); Sales Charge Type value "
                   "Initial Charge (EU/UK); Intermediary Identifier Type values FCA FRN and Platform Distributor Code; Look-Through Source value Platform Data Service; Transfer Type value Platform Re-Registration "
                   "(UK); Look-Through Source value Nominee Disclosure (EU/UK); Attribution Dimension values Platform and Investor "
                   "Country; File Format value XML (FundsXML) and the FundsXML value of the 06 Message Standard map; sources EFAMA, "
                   "Calastone, Clearstream Vestima, Allfunds, MiFID II and FundsXML. Kept and re-sourced: measure definitions, "
                   "Industry Definition Alignment, Gross Sales, Redemptions, Net Flows and Money Market Inclusion to ICI and "
                   "Morningstar only; order routing to the US Dealing Route set with Own Broker-Dealer Omnibus added (CW-140); "
                   "transfers to FINRA Rule 11870 and IRC sections 402(c) and 408(d)(3); look-through to Omni/SERV and SEC Rule 22c-2; "
                   "Product Identifier As Delivered example re-cut from an LU ISIN to a CUSIP. Kept unchanged: ISO 20022, DTCC "
                   "services, ISO 4217 and FX attributes for foreign-currency cash and foreign securities received in client "
                   "accounts. Perspective: META title 'Client Assets, Flows & Channel Attribution Data Taxonomy', subtitle 'Wealth "
                   "manager (direct) | Scope: US'; overview rewritten for the direct wealth manager. Also removed, not jurisdiction "
                   "(REPOINTS): Transaction Sales Charge, Record Metadata, Territory, Crediting Rule Applied, Suspense Territory / "
                   "Bucket, Compensation Cut-Off Date, FX Effect, Networking Matrix Level (As Delivered), Coverage - Markets.",
     "rationale": "CW-003 and CW-022: the firm distributes and is regulated in the US only; foreign instruments and currencies held "
                  "by clients stay. A UK extension restores the removed rows from wholesale-v1.0 through the jurisdiction register.",
     "action": "Merge JURISDICTION into jurisdiction.REMOVALS at the W4 merge; this entry supersedes the CW-906 stub in proposals_w4_channels.py", "status": "Proposed", "priority": "High",
     "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 8. NOTES for the W4 merge
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "COUNTS (builder). Wholesale -> W4 draft -> fix pass: 8 -> 8 -> 8 families; 38 -> 40 -> 40 objects (23 -> 23 -> 22 attribute "
    "groups; Unattributed Item became a Business Object); 253 -> 291 -> 290 attributes; 82 -> 100 -> 101 CDEs (34.8%); 41 -> 56 -> 54 "
    "references; 18 -> 14 -> 12 derived; 60 -> 62 -> 54 code lists; 27 -> 37 -> 38 relationships; 22 -> 18 -> 18 sources; 0 "
    "unresolved throughout.",
    "FIX PASS (00_Program/Rework/Reviews/06_review.md, program-lead rulings 1-8). Counting rule: Fund Shareholder Position carries "
    "Register Account Category (Derived from 29) and Aggregation Role; Client Assets = Account Asset Summary over firm client "
    "accounts plus Counted - Intermediary rows and omnibus residuals (summing rule on Ending Client Assets and in ROW_OWNERSHIP). One "
    "flow book per account book (Flow Source Book rule). Measure Value keyed by measure x period end x Dimension Type x Dimension "
    "Key. Inter-channel transfers are Transaction rows (Flow Scope 'Inter-Channel Transfer', From and To Distribution Channel), "
    "generated from Account Channel Assignment with the account's Account Asset Summary total on the last day of the old "
    "assignment; journals between channels are inter-channel transfers. Copies declared (Price, currency, FX rate, Transfer Type, "
    "Contribution Source Type, Transaction Status, Systematic Plan Indicator, channel and business line copies, Resolved Distributor "
    "Firm and Resolved Advisor / Rep from 29 Order Routing Detail.Resolved Dealer and Resolved Representative); as-delivered codes "
    "mastered here; DTC Participant Number and Resolved CRD Number are 02 copies. Advisor of record by 03 precedence (account, "
    "client, household; Primary Coverage Indicator). IA direct credit from 03 Party Coverage Assignment (Relationship Manager). "
    "Link to 04 Attributed Outcome. Average Client Assets (MSR-AVGCLIENTASSETS) and the subtotal without intermediary-held assets "
    "added; gross NNA inflows and outflows are Measure Definition rows MSR-NNA-IN and MSR-NNA-OUT (no new attribute; Measure Value "
    "is generic). Net equity, business-day convention, seed exclusion, trust (TR via 49), participant managed accounts (WR) and the "
    "11-to-4 holding type mapping stated.",
    "FIX PASS SKIPPED (one line each): Attribution View code (Medium) not added; Attributed Amount states one split basis per record "
    "instead (size band). Basis Plan Membership and Basis Partner Agreement (Medium) not added; the basis precedence is in Channel "
    "Assignment Basis and the plan and partner are read through the 15 account (size band). Program Enrollment dimension (Low) not "
    "added; Service Offering and the channel assignment basis carry it (size band). Own-Fund Overlap by Firm AUM slice (Medium) left "
    "as an SME question for the CW-011 owner, per ruling 5 (overlap covers own funds in every channel). Unattributed Item source "
    "references and Reporting Period (Medium) not added beyond the UNA- key (size band). Multi-dimension Measure Value combinations "
    "(channel x holding type) are a lever (composite Dimension Key) rather than more slots.",
    "READERS OF FIX-PASS REMOVALS: Measure Value.Dimension Grain is read by about 23 product, semantic and data-model files "
    "(specs_00_reference, specs_b, specs_c, specs_d, specs_e, specs_e5, specs_f, specs_h, specs_i, specs_j, specs_k; sm_06, sm_07, "
    "sm_14; models_016_pilot, c1, c2, c6, c7, e8c, f3, pilot_er; keys.py): re-point to Dimension Type and Dimension Key at WP0. "
    "Fund Shareholder Position.Market Value (Reporting Currency): specs_a, specs_c (515, 945), specs_e5 (115, 193), specs_h (31-32, "
    "73, 556-595), specs_i, specs_n, sm_01, sm_04: read Market Value. Snapshot Status: specs_00, specs_b, specs_e5 (read Snapshot "
    "Type). Completeness Status: specs_a, specs_e, specs_i (read Load Status). Sign Convention and Industry Definition Alignment: "
    "specs_00 (DP-008). Conversion Reason: specs_a, specs_j. Office-Level Detail Indicator: specs_a. Latency: specs_e. Match "
    "Confidence Score: specs_a, specs_e (read Match Confidence Band).",
    "10 at the W4 merge: content_10 line 89 Distribution Revenue Record.Sales Charge Source Transactions re-points from 06 TXN- to 29 "
    "Register Transaction (RGTX-), which carries Sales Charge Amount; 10 lines 254 and 310 read MSR-AVGCLIENTASSETS, now defined. 18 "
    "line 364 ('Not NAV (27) or AUM (06)') contradicts CW-011 (06 defines no AUM; Firm AUM is 27, 46, 18): flagged for the lead.",
    "READERS (live, the assignment's list). DP-006 Transaction: specs_a_foundational.py 554-556 (Transaction Sales Charge columns), "
    "571-573 (Market & Client Dimensions Territory, Platform / Fund Distributor (EU/UK), Investor Country; Salesperson Credit "
    "Crediting Rule Applied), 577 (Suspense Territory / Bucket), 595 and 604 (rules on Crediting Rule Applied); data models "
    "models_f2.py 22, 118-123, models_c8_compliance2.py 32, models_c3_comp_finance_service.py 802-878; keys_g3_06_07_10.py 25, 215, "
    "217; keys.py 150, 154. Disposition: drop with a 'W4' note (CW-151); re-point the Distributor Hierarchy columns to 05 and "
    "Institutional Client to 12.",
    "READERS. DP-007 Positions & Holdings: specs_a_foundational.py 630-647 ('06', 'Position' -> 'Fund Shareholder Position'), 650 "
    "(Nominee / Platform Account Indicator: drop), 659-660 (Territory, Platform / Fund Distributor, Investor Country: drop), 664 "
    "(Suspense Territory / Bucket -> Suspense Channel); models_f2.py 138, 231-235; models_c10_shareholder_ops.py 175, 256, 564; "
    "models_c6_planning_finance.py 42, 669; models_c8_compliance2.py 38, 182, 702; sm_01_distribution_performance.py 249 "
    "(nominee_platform_account dimension: drop). New columns to offer DP-007 at WP0: Position Source Book, Source Client Holding, "
    "Source Share Register Balance, Valuation NAV.",
    "READERS. DP-008 Certified Flows & AUM (successor product for Client Assets at WP0, CW-142): specs_00_reference.py 26-28 "
    "(Market Movement formula subtracts FX Effect: drop the term), 43 (Asset Measures list: drop FX Effect), 46-47 (Territory and "
    "Platform / Fund Distributor: drop), 48 (Compensation Cut-Off Date: drop); models_pilot_er.py 78, 126; SM-01 "
    "sm_01_distribution_performance.py 65, 323-326 (fx_effect measure and the Market Movement description), 509-511 (DP-055 "
    "answer text). WP0 re-scope: DP-008 becomes Client Assets & Net New Assets and reads Client Asset Measures, Account Asset "
    "Summary and Account Channel Assignment; SM-01's certified flow and AUM metrics move to SM-20 Client Assets & Flows (CW-142).",
    "READERS. DP-241 (Firm AUM reconciliation; successor nets the own-fund overlap): specs_e5_cross_area.py 102, 105, 114-115 "
    "(_u('06', 'Position', 'Market Value', 'Market Value (Reporting Currency)'): re-type to Fund Shareholder Position; names kept), "
    "192-193; models_e8c_cross_area.py 91. It should also read Client Asset Measures.Own-Fund Overlap Amount (CW-011).",
    "READERS of ('06', 'Position') beyond the four above, all re-typed by name only at the W4 merge (CW-151): DP-019, DP-024 "
    "(specs_c_sales.py 487, 515, 945-974), DP-050, DP-066 (specs_h_planning_partners.py 31-32, 73, 556-595), DP-060, DP-061 "
    "(specs_j_compliance_2.py 31-87, 153-207), DP-070, DP-071 (specs_l_shareholder_vendor.py 207-406), DP-076 "
    "(specs_i_product_data.py 569-611), DP-084 (specs_n_compliance_controls.py 342-387), DP-085 (specs_o_operations.py 288-347), "
    "DP-108, DP-204; keys.py 139, 145; keys_e7_17_18.py 239; keys_e7_42_44.py 382; keys_g3_06_07_10.py 33, 204-206, 242; "
    "keys_g6_15_16.py 177; content_18 lines 156 and 428 (Portfolio Holding.Corresponding Shareholder Position, typed "
    "Reference (Position): re-type to Reference (Fund Shareholder Position)); content_43 Seed Valuation.Source Shareholder Position; "
    "content_05 (current wholesale module) Payment Calculation.Basis Position Snapshot (keys.py 139).",
    "READERS of other removed content: DP-060 specs_j_compliance_2.py 34-48, 83-84, 107 (breakpoint metrics on Transaction Sales "
    "Charge: the product retires with the no-load default or moves to 47/48 brokerage commission data; CW-141 lever); DP-076 "
    "specs_i_product_data.py 606 and 611 (Nominee indicator, Investor Country, Platform), sm_06_product_market.py 303-304; DP-029 "
    "and DP-031 specs_d_marketing_product.py 470-471 and 682 (06 Territory, Platform, Investor Country), models_c2_marketing_product.py "
    "399-443; DP-015, DP-016, DP-024, DP-025, DP-045, DP-047, DP-055, DP-057, DP-071 read Market & Client Dimensions.Territory "
    "(specs_b 692, specs_c 43-80 and 975, specs_d 79, specs_e 863-865, specs_g 148, specs_h 313, 483, 502, specs_l 412): most are "
    "07-dependent products retired by CW-907; the survivors re-point to Covering Advisor / Distribution Channel. FX Effect also in "
    "semantic_model/out (generated). Asset Measures.Estimated Management Fee Revenue is kept because DP-024 and DP-066 read it "
    "(specs_c_sales.py 574-575, 626; specs_h_planning_partners.py 210); 10 owns booked revenue.",
    "Family renames for the baseline check: Positions & Holdings -> Positions & Client Asset Balances; Flow & AUM Measures -> Flow & "
    "Client Asset Measures; Attribution -> Channel Attribution (family codes kept). Data Management Metadata (TX-DMM) removed. "
    "Attribute IDs are positional within a family and renumber in TX-TRN, TX-POS, TX-MEA, TX-ATT, TX-FED and TX-SNP; readers use "
    "names. Kept attribute names are unchanged.",
    "LOCAL_RENAMES (shared_code_lists.py 2708-2732): ('06', 'Snapshot Type', 'Snapshot Version Stage'), ('06', 'Reconciliation "
    "Type', 'Flow and AUM Reconciliation Type'), ('06', 'Restatement Reason', 'Flow and AUM Restatement Reason'): relabel 'Flow and "
    "AUM' to 'Flow and Client Asset'. NOT_MERGED ('06', 'Position Basis', ...) stays.",
    "decisions.PREFIXES: CHASG- (reserved by CW-148); UNA-, OVR- and XWK- are now used as keys (already registered to 06). CVA- is "
    "still registered to 07: the Advisor Coverage Assignment override becomes redundant once the merge moves CVA- to 03. Every other "
    "override stays, because ownership.resolve reads the ID prefix before the concept register: the PTY-keyed 05 and 12 objects "
    "(Distributor Firm, Branch / Office, Advisor Team, Financial Professional, Consultant Profile, Institutional Client), 16 "
    "Recordkeeper Profile, 03 Advisor (EMP-), 04 Attributed Outcome (PTY- composite), 29 Share Register Balance and 06 Account Asset "
    "Summary (ACC- composites), and Measure Value.Reporting Period. W5 option: let an explicit ', NN' in the type win over the prefix.",
    "Sibling names used, checked against the drafted modules: 49 Client Holding (CLHLD-), Client Holding Valuation, Account Cash "
    "Balance, Client Account Activity (CLACT-), Account Transfer (ACXF-, Transfer Channel, Contra Firm); 50 Sweep Allocation; 29 "
    "Register Transaction (RGTX-), Share Register Balance and Register Account Category, Order Routing Detail.Resolved Dealer and "
    "Resolved Representative, Basket Settlement Form, Dealing Route labels; 16 Participant Ledger Posting (PLPST-), Participant "
    "Balance, Contribution Source, Recordkeeper Profile; 18 Portfolio Capital Activity and "
    "Portfolio Valuation Summary (composite keys); 03 Advisor and Party Coverage Assignment (CVA-); 04 Campaign (CAM-) and "
    "Attributed Outcome.Attribution Weight (04 Attributed Outcome.Attributed Amount is already declared a Derived copy of 06, "
    "CW-085); 05 Distributor Firm, Branch / Office, Advisor Team, Financial Professional, Consultant Profile, Partner Coverage "
    "Assignment (PCVG-), Distribution Agreement (AGR-); 12 Institutional Client; 27 Share Class NAV (NAV-).",
    "16 at W3 merge: content_16 Contribution Record and its overview say contributions flow to 06 TXN-; under CW-141 06 copies 16, "
    "not the reverse. 18 overview line 438 note 'shareholder transactions themselves are 06 TXN-' should read '29 Register "
    "Transaction' (CW-122).",
    "Brief deviations: (1) Unattributed Item.Suspense Territory / Bucket replaced by Suspense Channel (a new attribute) rather than "
    "re-typed, so the removal is explicit. (2) Order Source does not carry a 46 Model Assignment reference (managed-account flows "
    "are 49 activity of a 15 account; 46 is read through the enrollment). (3) Linked Transaction carries no separate rollover link "
    "attribute: a rollover is the pair of a 16 Participant Ledger Posting (Distribution) and the IRA receipt posted in 49 (the 16 "
    "Distribution Request.Receiving Account money movement reaches 06 only through that 49 posting), joined by Linked Transaction ID. "
    "(4) Code lists 54 against the brief's 35-45 (ruling: toward 55). (5) Attributes 290 (band 290). (6) Networking Matrix Level (As Delivered) and Coverage - Markets removed (lineage-only and single-valued). "
    "(7) FundsXML removed as EU market practice (not named in the brief section 4a).",
    "Remaining grep hits in the module for EU/UK terms: none; 'wholesale' only in the module docstring (the wholesale origin) and "
    "in 'wholesaler' (a credit role). 'Holding' and 'Position' appear bare only in kept object names ETF Holding and Plan Position "
    "(definitions qualify them) and in the code list Position Basis and Holding Type.",
]
