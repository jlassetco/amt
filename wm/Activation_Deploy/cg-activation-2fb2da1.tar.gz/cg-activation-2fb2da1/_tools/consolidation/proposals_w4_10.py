"""Consolidation proposals from the W4 draft of Data Domain 10 Client Revenue, Pricing Economics & Profitability (wealth
manager), 2026-10-15.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py,
shared_code_lists.py and jurisdiction.REMOVALS at the W4 merge. Formats follow CONTRACT.md in this folder. The brief is
00_Program/Rework/Briefs/10_Client_Revenue_Pricing_Economics_and_Profitability.md (Disposition: Adapt, CW-012). It implements
CW-003, CW-011, CW-012, CW-013, CW-022 (proposals_wealth_w0.py / proposals_wealth_w1.py), CW-156 to CW-159, CW-164, CW-169,
CW-170 (proposals_w4_economics.py, treated as accepted) and the 10 rows of W4_Retirement_of_07_and_30.md section 5, and drafts
CW-910, the US-only pass of 10. Module: content_10_distribution_finance_and_profitability.py (adapted in place; file name, output
path and folder unchanged until the W5 rename pass). The brief names the file proposals_10.py; the assignment names this file
proposals_w4_10.py (no proposals_10.py exists from the expansion).
"""

_D, _C = "10", "CW-910"

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES (decisions.PREFIXES tuple format). None beyond CLREV-, LTVM- and PRSC-, which proposals_w4_economics.PREFIXES
#    reserves (CW-156 to CW-158). Client Acquisition Cost Record, Client Lifetime Value Estimate, Cash Program Economics and
#    Pricing Scenario Result use the composite keys of proposals_w4_economics.KEY_FORMATS. The 19 wholesale prefixes are kept.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED MEMBERSHIPS: 10 local lists that carry a shared list's exact name (or are registered members under a local
#    name). value_map maps each local label to the shared code; new_values are codes the shared list does not hold yet.
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Accounting Basis", "local": "Accounting Basis",
     "value_map": {"US GAAP": "US_GAAP", "Tax Basis": "TAX_BASIS", "Regulatory": "REGULATORY"},
     "new_values": [],
     "note": "Members change explicitly (review F, ruling 8): in shared_code_lists.py the Accounting Basis 'members' tuple ('10', 'Accounting Framework') becomes ('10', 'Accounting Basis'), and the value_map entries keyed ('10', 'Accounting Framework', ...) are replaced by VALUE_MAPS below (proposals_w4_economics.MEMBERSHIPS_REMOVE lists the old tuple). The local list is "
             "renamed to the shared name and carries the shared values exactly; the attribute Revenue Contract.Accounting "
             "Framework keeps its name for its readers (DP-012, DP-089, SM-07). The four W1b value-map entries mapped to None "
             "(IFRS (EU-adopted), UK-adopted IFRS, FRS 102 (UK GAAP), Lux GAAP) are resolved by removal under CW-910 "
             "(JURISDICTION below); Tax Basis and Regulatory are added from the shared list."},
    {"shared": "Business Line", "local": "Business Line",
     "value_map": {c: c for c in ("DB", "DA", "HA", "PF", "WR", "IA", "IC", "TR")},
     "new_values": [],
     "note": "New member (CW-004). Profitability Record.Business Line. Two-letter codes as values, as 02, 13 and 15."},
    {"shared": "Business Domain", "local": "Source Domain",
     "value_map": {"03 Advisor Organization, Coverage & Supervision": "SALES",
                   "04 Marketing, Digital & Client Engagement": "MARKETING_DIGITAL",
                   "05 Intermediary & Institutional Distribution": "DISTRIBUTION_AGREEMENTS_PARTNERS",
                   "14 Third-Party Data & Licensing": "THIRD_PARTY_DATA",
                   "16 Retirement Plan Administration": "RETIREMENT_PLAN_ADMINISTRATION",
                   "19 Finance & Accounting": "FINANCE_ACCOUNTING",
                   "20 Human Capital": "HUMAN_CAPITAL",
                   "40 Procurement & Vendor Management": "PROCUREMENT_VENDOR_MANAGEMENT",
                   "47 Pricing, Fees & Billing": "PRICING_FEES_BILLING",
                   "48 Brokerage Orders & Execution": "BROKERAGE_ORDERS_EXECUTION",
                   "49 Clearing, Settlement & Client Asset Custody": "CLEARING_SETTLEMENT_CLIENT_CUSTODY",
                   "50 Money Movement, Cash & Sweep": "MONEY_MOVEMENT_CASH_SWEEP",
                   "52 External Manager & Sub-Adviser Oversight": "EXTERNAL_MANAGER_SUBADVISER_OVERSIGHT",
                   "ERP / Accounts Payable": "EXT_ERP_ACCOUNTS_PAYABLE"},
     "new_values": [],
     "note": "Kept membership, re-cut (CW-159, CW-164): value '07 Compensation & Territory' removed (07 retires, CW-907); '12 Institutional "
             "Client Servicing' removed (mandate invoices are 47, CW-012); 03, 16, 19, 20, 40, 47, 48, 49, 50 and 52 added; labels of 04 and 05 take "
             "the wealth names of domains.DISPOSITION. 03 maps to the existing "
             "code SALES and 05 to DISTRIBUTION_AGREEMENTS_PARTNERS until the steward 09 relabels the codes at W5 (the codes are "
             "kept, the labels change). Replace the existing ('10', 'Source Domain') value_map entry in shared_code_lists.py."},
    {"shared": "Waiver Type", "local": "Waiver Type", "value_map": None, "new_values": [],
     "note": "Kept membership, values unchanged (steward 27). Waiver Record is fund level; client fee waivers are 47 Fee Waiver (CW-055)."},
    {"shared": "Reconciliation Status", "local": "Reconciliation Status", "value_map": None, "new_values": [],
     "note": "Kept membership, values unchanged (steward 06)."},
    {"shared": "Record Status", "local": "Hierarchy Status", "value_map": None, "new_values": [],
     "note": "Kept membership, values unchanged."},
    {"shared": "Plan Version Status", "local": "Plan Version Status", "value_map": None, "new_values": [],
     "note": "Kept membership, values unchanged (steward 19)."},
    {"shared": "Financial Plan Type", "local": "Plan Type", "value_map": None, "new_values": [],
     "note": "Kept membership, values unchanged (steward 19)."},
    {"shared": "Plan Scenario", "local": "Scenario", "value_map": None, "new_values": [],
     "note": "Kept membership, values unchanged (steward 19). Distinct from 10 Pricing Scenario (term conflict Scenario, CW-169)."},
]

# VALUE_MAPS: the shared_code_lists.py value_map entries to replace at the merge (member -> {local label: shared code}).
VALUE_MAPS = {
    ("10", "Accounting Basis"): {"US GAAP": "US_GAAP", "Tax Basis": "TAX_BASIS", "Regulatory": "REGULATORY"},
    ("10", "Source Domain"): SHARED_MEMBERSHIPS[2]["value_map"],
}
# Removed from the shared registry: the value_map entry ('10', 'Accounting Framework') with its four None values; the
# memberships ('10', 'Data Classification') and ('10', 'Data Quality Status') end with Record Metadata (CD-160; already in
# proposals_w4_economics.MEMBERSHIPS_REMOVE).

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED CANDIDATES: local lists that look like enterprise lists
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Revenue Stream", ["10", "47", "19", "06", "05"],
     "Revenue disaggregation (advisory, wrap, planning, commission, account service, margin interest, fully paid lending, bank sweep, "
     "fund management, fulcrum, 12b-1, recordkeeping, trust, OCIO). 47 Fee Schedule Type, 19 revenue Financial Statement Lines, 06 "
     "estimated fee revenue and 05 12b-1 Component (NOT_MERGED) map to it. Candidate shared list, steward 10."),
    ("Acquisition Channel", ["10", "04", "06"],
     "How a Client Household was acquired (organic digital, paid media, workplace rollover, advice conversion, referral). 04 "
     "acquisition attribution and 06 inter-channel transfers may need the same values. Candidate shared list, steward 04."),
    ("Cost-to-Serve Component", ["10", "13", "41"],
     "CW-157 components (advice, service, platform, clearing and client asset custody, money movement, communications, regulatory). "
     "13 service cost and 41 technology cost reporting could tag to it; keep local unless they adopt it."),
    ("Pricing Scenario Type", ["10", "36", "11"],
     "36 Proposed Term Change types and 11 competitor price components overlap the change kinds; align at W5."),
    ("Settlement Status", ["10", "19", "05"],
     "Intercompany charge settlement (Pending, Invoiced, Settled, Netted) overlaps 19 receivable and payable status and 05 partner "
     "payment status; candidate shared 'Settlement Status', steward 19."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (decisions.TERM_CONFLICTS format), from CW-169 and what the draft found
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Revenue",
     "usages": [("10", "Fee Revenue Record (FRR-) / Client Revenue Record (CLREV-)", "Revenue recognized under ASC 606 (own funds; client accounts)."),
                ("19", "GL Posting / Financial Statement Line Value (DP-191)", "Certified revenue on the ledger (CW-011)."),
                ("47", "Account Fee Calculation / Fee Invoice", "Calculated client fee, before recognition."),
                ("06", "Estimated fee revenue measure (MSR-)", "Estimate from client assets x rate.")],
     "recommendation": "Say 'Fee Revenue' or 'Client Revenue' (10, recognized), 'certified revenue' (19), 'calculated fee' (47), "
                       "'estimated fee revenue' (06). Bare 'Fee' is the 47 client fee.",
     "resolution": "Calculated 47, recognized 10, certified 19 (CW-012, CW-156, CW-011).", "status": "Resolved", "decision": "CW-156"},
    {"term": "Cost to Serve",
     "usages": [("10", "Cost-to-Serve Profile", "Allocated cost of serving a Client Household, segment, tier, offering or channel."),
                ("13", "Service level / SLA Measurement", "Service quality and timeliness, not cost.")],
     "recommendation": "'Cost to serve' is a 10 cost measure only; 13 says 'service level'.",
     "resolution": "Kept distinct (CW-157).", "status": "Resolved", "decision": "CW-169"},
    {"term": "Lifetime Value",
     "usages": [("10", "Lifetime Value Model (LTVM-) / Client Lifetime Value Estimate", "Discounted projected margin of a Client Household.")],
     "recommendation": "Used only in 10; 04 and 45 reference the estimate, never compute their own.",
     "resolution": "Single owner (CW-157).", "status": "Resolved", "decision": "CW-169"},
    {"term": "Scenario",
     "usages": [("10", "Pricing Scenario (PRSC-)", "Economics of a proposed price change."),
                ("10", "Plan Version.Scenario (shared Plan Scenario)", "Budget scenario (base, upside, downside)."),
                ("19", "Plan Scenario", "Shared budget scenario list."),
                ("45", "Planning Scenario (PSCEN-)", "A client's financial planning scenario."),
                ("31", "Stress scenario", "Risk stress test.")],
     "recommendation": "Always qualified: 'Pricing Scenario', 'Plan Scenario', 'Planning Scenario', 'Stress Scenario'.",
     "resolution": "Qualified names (CW-169).", "status": "Resolved", "decision": "CW-169"},
    {"term": "Plan",
     "usages": [("10", "Plan Version (BUD-) / Plan Line", "Budget or forecast version."),
                ("45", "Financial Plan (FPLAN-)", "A client's financial plan."),
                ("16", "Retirement plan (02 Retirement Plan party; 16 Plan Document)", "Employer retirement plan."),
                ("03", "Incentive Compensation Plan (ICP-)", "Advisor incentive plan.")],
     "recommendation": "10 definitions say 'budget Plan Version'; never bare 'plan' for a client or retirement plan.",
     "resolution": "Qualified names (CW-058, CW-169).", "status": "Resolved", "decision": "CW-058"},
    {"term": "Hierarchy Node",
     "usages": [("10", "Management Hierarchy Node", "Node of a management P&L rollup."),
                ("05", "Hierarchy Node", "Distributor firm hierarchy node (restored from the wholesale 02, CW-132).")],
     "recommendation": "10 renames its object Management Hierarchy Node (CW-159) so that 'Hierarchy Node' resolves to 05 only.",
     "resolution": "Renamed in 10.", "status": "Resolved", "decision": "CW-159"},
    {"term": "Waiver",
     "usages": [("10", "Waiver Record (WVR-)", "Fund-level fee waiver and expense reimbursement impact."),
                ("47", "Fee Waiver (FWV-)", "Client fee waiver or credit."),
                ("27", "Expense Cap & Waiver Accrual", "Fund-side accrual.")],
     "recommendation": "10 definitions say 'fund-level'; 47 says 'client fee waiver'.",
     "resolution": "Kept distinct (CW-055).", "status": "Resolved", "decision": "CW-055"},
    {"term": "Fee Schedule",
     "usages": [("47", "Fee Schedule (CLFEE-)", "Client fee schedule."),
                ("01", "Fund fee terms (FSCH-; concept 'Fund Fee Schedule')", "Prospectus expense terms of a share class, once effective."),
                ("36", "Proposed Term Change", "A proposed fund expense term until it is effective."),
                ("10", "Pricing Scenario.Proposed Schedule Version; Performance Fee Record.Performance Fee Terms Reference; Waiver Record.Expense Cap Terms Reference", "References to either.")],
     "recommendation": "10 types adopted fund-term references 'Reference (Fund Fee Schedule, 01)', proposed fund terms 'Reference "
                       "(Proposed Term Change, 36)' and client-fee references 'Reference (Fee Schedule, 47)' (also the mandate "
                       "Performance Fee Terms), forced to 47 in enrich_10 until CONCEPT_OWNERSHIP re-cuts the 01 row (CW-051).",
     "resolution": "Typed per owner.", "status": "Resolved", "decision": "CW-051"},
    {"term": "Channel",
     "usages": [("09", "Distribution Channel (shared list)", "Route through which an account is served (direct, workplace, institutional, intermediary)."),
                ("10", "Acquisition Channel (local list)", "How a Client Household was first acquired (organic digital, paid media, workplace rollover, referral)."),
                ("13", "Service Channel", "Medium of a service interaction (phone, chat, secure message).")],
     "recommendation": "Never bare 'channel': 'Distribution Channel' (06 assigns it), 'Acquisition Channel' (10), 'Service Channel' (13).",
     "resolution": "Qualified names.", "status": "Resolved", "decision": "CW-169"},
    {"term": "Household",
     "usages": [("02", "Household (PTY-HH-)", "Client Household."),
                ("47", "Fee Household (FHHG-)", "Accounts aggregated for fee breakpoints and household billing; may span or split Client Households."),
                ("10", "Client Revenue Record.Revenue Account / Household", "Household-grain rows key on the 47 Fee Household, never on the 02 household.")],
     "recommendation": "10 books fee revenue at account grain and rolls up to the 02 Client Household in products; household-grain rows "
                       "(lever) use the 47 Fee Household and reach the 02 household through its Anchor Client Household.",
     "resolution": "Kept distinct (CW-027, checklist section 7).", "status": "Resolved", "decision": "CW-027"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION (jurisdiction.REMOVALS entry format; CW-022). A whole removed object or code list has attribute "".
# ---------------------------------------------------------------------------------------------------------------------


def _j(obj, attr, regime, note):
    return {"domain": _D, "object": obj, "attribute": attr, "regime": regime, "decision": _C, "note": note}


_IFRS15 = [
    ("Revenue Contract", "Contract Inception Date"), ("Revenue Contract", "Termination Notice Period"),
    ("Performance Obligation", "Performance Obligation Type"), ("Performance Obligation", "Satisfaction Pattern"),
    ("Performance Obligation", "Series Guidance Applied Indicator"), ("Fee Revenue Record", "Net Fee Revenue"),
    ("Performance Fee Record", "Constraint Assessment Outcome"), ("Performance Fee Record", "Recognized Performance Fee Revenue"),
    ("Distribution Revenue Record", "Principal vs Agent Conclusion"), ("Waiver Record", "Waiver Accounting Treatment"),
    ("Distribution Cost Item", "Capitalization Outcome"), ("Contract Cost Asset", "Cost Asset Type"),
    ("Contract Cost Asset", "Capitalized Amount"), ("Contract Cost Asset", "Amortization Method"),
    ("Contract Cost Asset", "Net Carrying Amount"), ("Contract Cost Asset", "Impairment Loss Amount"),
    ("Capitalization Assessment", "Incremental Indicator"), ("Capitalization Assessment", "Practical Expedient Applied Indicator"),
    ("Capitalization Assessment", "Assessment Conclusion"),
]

JURISDICTION = [
    # Attributes
    _j("Distribution Cost Item", "Inducement Assessment Reference", "MiFID II",
       "08 inducement compliance review carried for EU/UK cost reporting (MiFID II Article 24(9); left for this pass by CW-067). No US "
       "successor on the cost item: Reg BI conflict review of incentives is 08 Incentive Conflict Review, read from 03."),
    _j("Intercompany Charge", "VAT Treatment", "Other EU/UK",
       "EU/UK VAT treatment of intercompany charges (fund management exemption; EU VAT Directive and UK VAT Act). The firm's entities "
       "are US; no VAT."),
    # Whole code lists
    _j("Code list: VAT Treatment", "", "Other EU/UK", "Standard Rated, Exempt - Fund Management, Out of Scope, Reverse Charge."),
    # Code values of kept lists
    _j("Code list: Accounting Framework", "IFRS (EU-adopted)", "Other EU/UK",
       "Mapped to None in the Accounting Basis crosswalk since W1b. The list is renamed Accounting Basis and carries the shared values "
       "US GAAP, Tax Basis and Regulatory."),
    _j("Code list: Accounting Framework", "UK-adopted IFRS", "Other EU/UK", "UK Companies Act; mapped to None since W1b."),
    _j("Code list: Accounting Framework", "FRS 102 (UK GAAP)", "Other EU/UK", "UK GAAP (FRC); mapped to None since W1b."),
    _j("Code list: Accounting Framework", "Lux GAAP", "Other EU/UK", "Luxembourg GAAP; mapped to None since W1b."),
    _j("Code list: Distribution Expense Category", "Trail Commission / Retrocession", "MiFID II",
       "EU/UK trail commissions and retrocessions to distributors (MiFID II inducements). The list is renamed Cost Item Category; US "
       "intermediary payments stay as Revenue Sharing, Sub-TA / Networking Fees, 12b-1 Paid to Intermediaries and Platform Fees."),
    _j("Code list: Revenue Contract Type", "ManCo Services Agreement", "UCITS",
       "Third-party UCITS management company / AIFM services agreement (UCITS Directive Article 6; also AIFMD). No US equivalent at "
       "the firm."),
    _j("Code list: Revenue Contract Type", "Investment Advisory Agreement (Fund)", "UCITS",
       "Description wording 'UCITS / AIF management agreement' removed (also AIFMD); the value stays for '40 Act funds and CITs."),
    _j("Code list: Customer Determination Basis", "Fund is Customer", "UCITS",
       "Description wording 'UCITS' removed; the value stays for '40 Act funds and CITs."),
    _j("Revenue Contract", "Contracting Legal Entity", "UCITS",
       "Definition wording 'ManCo' removed (UCITS management company; also AIFMD); the attribute stays with the US entities (RIA, "
       "broker-dealer, fund adviser, transfer agent, recordkeeper, trust company)."),
    _j("Performance Fee Record", "Crystallization Date", "UCITS",
       "Primary reference 'ESMA Performance Fee Guidelines' (ESMA guidelines on performance fees in UCITS and certain AIFs) removed; "
       "the attribute stays, re-sourced to Advisers Act Rule 205-3, for fulcrum adjustments and mandate performance fees."),
    _j("Profitability Measure", "Distribution Payments", "MiFID II",
       "Definition wording 'retrocessions' removed; the attribute stays for intermediary channel partner payments."),
    # Examples (EUR, UK and Luxembourg entities)
    _j("Performance Fee Record", "NAV-Accrued Performance Fee", "Other EU/UK", "Example 'EUR 3,400,000' re-sourced to a USD fulcrum accrual."),
    _j("Performance Fee Record", "Recognized Performance Fee Revenue", "Other EU/UK", "Example 'EUR 0' re-sourced to USD; IFRS 15 secondary reference also removed."),
    _j("Intercompany Charge", "Charge Amount", "Other EU/UK", "Example 'EUR 980,000' re-sourced to USD; primary reference OECD TPG re-sourced to IRC section 482."),
    _j("Intercompany Agreement", "Service Provider Entity", "Other EU/UK", "Example 'LEN-0021 (UK distributor)' re-sourced to the US broker-dealer."),
    _j("Intercompany Agreement", "Service Recipient Entity", "UCITS", "Example 'LEN-0004 (Lux ManCo)' (Luxembourg UCITS management company) re-sourced to the US fund adviser."),
    _j("TP Policy", "TP Documentation Reference", "Other EU/UK",
       "Example 'UK Local File FY2025' (OECD local file as filed in the UK) re-sourced to the US entity's documentation key "
       "'US Local File FY2025' (19 TP Documentation ID format; IRC section 6662(e)); the attribute is re-typed Reference (Transfer "
       "Pricing Documentation, 19)."),
    # IFRS secondary references (one entry per attribute)
    *[_j(o, a, "Other EU/UK", "Secondary reference IFRS 15 removed (IFRS as adopted in the EU and UK); the US GAAP primary (ASC 606 or "
         "ASC 340-40) stays.") for o, a in _IFRS15],
    _j("Management Hierarchy Node", "Operating Segment Mapping", "Other EU/UK",
       "Secondary reference IFRS 8 removed; ASC 280 stays. (Object renamed from Hierarchy Node, CW-159.)"),
    # Sources
    _j("Sources", "IFRS 15 Revenue from Contracts with Customers", "Other EU/UK",
       "IFRS Foundation standard used for IFRS reporters (EU-adopted and UK-adopted IFRS); ASC 606 and ASC 340-40 stay."),
    _j("Sources", "IFRS 8 Operating Segments (half of the source 'FASB ASC 280 Segment Reporting / IFRS 8 Operating Segments')", "Other EU/UK",
       "The source is kept as 'FASB ASC 280 Segment Reporting' with the FASB codification link."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. REPOINTS (object, attribute, before, after, decision): renames, re-types, re-cuts and the 07 and 30 references of the
#    adaptation that are not EU/UK removals. Readers of each are listed in NOTES.
# ---------------------------------------------------------------------------------------------------------------------
REPOINTS = [
    # Object rename and removals (07 retirement, CW-907; 03 forecast retired, CW-062)
    ("Hierarchy Node", "", "Hierarchy Node (BO, family Management Reporting Hierarchies)", "Management Hierarchy Node (AG of Management Hierarchy); attributes unchanged; Parent Node re-typed Reference (Management Hierarchy Node, 10)", "CW-159"),
    ("Profitability Record", "Territory", "Reference (Territory) to 07 TER-", "removed (07 retires, CW-907); geography is 09 Geographic Group if needed", "CW-159"),
    ("Profitability Record", "Salesperson", "Reference (Employee) to 20 EMP- (07 salesperson)", "renamed Advisor, Reference (Advisor, 03), EMP- key, forced to 03", "CW-159"),
    ("Flow & Revenue Forecast", "Sales Forecast Reference", "Reference (Sales Forecast) to 03 FCS-", "removed (FCS- retired, CW-062); forecast re-cut to net new assets and revenue by offering and channel reading 06 definitions", "CW-159"),
    ("Flow & Revenue Forecast", "Forecast Gross Sales", "Derived copy of the 03 sales forecast submission (FCS-)", "mastered here (forecast), defined on the 06 Net New Assets inflow definition", "CW-159"),
    ("Capitalization Assessment", "Assessed Cost Source", "Reference (Plan Component / Payment Arrangement), 07 ICP- component", "Reference (Incentive Plan Component, 03 / Payment Arrangement, 05), ICP-n-Cnn, forced to 03", "CW-062"),
    ("Code list: Source Domain", "07 Compensation & Territory", "07 Compensation & Territory", "removed; 03, 16, 40, 47, 48, 50 added; 04, 05, 12 relabeled", "CW-159"),
    ("Code list: Restatement Trigger", "Territory Realignment", "Territory Realignment (07 RLN-)", "Coverage Model Change (03 coverage model or reassignment)", "CW-159"),
    ("Code list: Reconciliation Type", "Comp Accrual vs ICM (07)", "Comp Accrual vs ICM (07)", "Compensation Accrual vs Statements (03)", "CW-159"),
    ("Code list: Profitability Dimension", "Territory; Salesperson", "Territory; Salesperson", "removed; Advisor, Household, Account, Service Offering, Service Tier, Business Line added", "CW-159"),
    ("Code list: Accrual Basis", "Engine Calculation", "From 05 / 07 calculation engine", "From the 03, 04 or 05 calculation", "CW-159"),
    ("Code list: Cost Item Category", "Sales Compensation", "Sales Compensation (base, incentive and benefits from 07)", "Advisor Base Compensation; Advisor Incentive Compensation (03, booked per cost center)", "CW-159"),
    ("REL", "", "Distribution Cost Item is sourced from Compensation Statement / Accrual (07 CT: CPS-)", "is sourced from Compensation Statement (03: CPS-)", "CW-159"),
    ("REL", "", "Capitalization Assessment assesses Incentive Comp Plan component (07 CT: ICP-)", "assesses Incentive Plan Component (03: ICP-n-Cnn)", "CW-062"),
    ("REL", "", "Profitability Record is dimensioned by Party, Share Class, Territory, Employee (07 TER-, 03 EMP-)", "Party / Account / Service Offering / Service Tier / Share Class / Advisor; Distributor Firm (05) on IC rows", "CW-159"),
    ("REL", "", "Flow & Revenue Forecast uses Sales Forecast (03 Sales: FCS-)", "uses definitions of Measure Definition (06: MSR-)", "CW-062"),
    ("Management Hierarchy Node", "Leaf Member", "example TER-US-NE-03 (07)", "example OFFR-0012 (01)", "CW-159"),
    # Re-points to replaced, adapted and new neighbors
    ("Profitability Record", "Partner Firm", "Reference (Party), 02 PTY-", "Reference (Distributor Firm, 05), PTY- key, forced to 05; intermediary channel rows only", "CW-132"),
    ("Profitability Record", "Client / Account", "institutional client or account (02 PTY- / ACC-)", "Client Household, client or institutional client (02 PTY-HH-, PTY-) or account (15 ACC-); PII - financial, restricted", "CW-157"),
    ("Profitability Record", "Client Segment", "External (02 CC - Client Segment), 'Large RIA'", "External (02 - Segment Assignment), Derived copy as of period end, 'Pre-Retiree'", "CW-157"),
    ("Profitability Record", "Average AUM Reference", "06 average AUM measure value", "06 Client Asset Measures (average client assets) or fund net assets; name kept for readers", "CW-011"),
    ("Cost-to-Serve Profile", "", "BO, served party = partner firm or client", "AG of Profitability Record; Served Party = Client Household or client; components re-cut (CW-157)", "CW-157"),
    ("Cost-to-Serve Profile", "Coverage and Servicing Cost", "wholesaling, national-accounts and client-service cost", "advice and client service cost (Advice and Service components)", "CW-157"),
    ("Revenue Contract", "Underlying Agreement", "Reference (Fund Advisory Agreement / Mandate / Agreement): 35, 01, 05", "adds 15 Account Agreement (AAG-), 16 Service Arrangement (PSVA-), 51 Trust (TRUST-)", "CW-156"),
    ("Revenue Contract", "Accounting Framework", "code list Accounting Framework", "code list Accounting Basis (shared values)", "CW-164"),
    ("Fee Revenue Record", "Revenue Share Class / Mandate", "share class or mandate", "own-fund share class; mandate fees booked on Client Revenue Record from 47 (name kept)", "CW-156"),
    ("Fee Revenue Record", "Fee Basis Average Assets", "Derived copy of 06 average AUM", "Derived copy of 27 fund average net assets", "CW-011"),
    ("Fee Revenue Record", "Applied Gross Fee Rate", "01 Product fee terms", "01 fund fee terms (Management Fee, FSCH-)", "CW-051"),
    ("Performance Fee Record", "Performance Fee Share Class / Mandate", "content_10 line 68: 'terms held in 01 Product'", "subject only; terms in the new Performance Fee Terms Reference: Reference (Fund Fee Schedule, 01 / Performance Fee Calculation, 47) by row rule (47 review, Medium item)", "CW-051"),
    ("REL", "", "content_10 line 510: Fee Revenue Record is earned on Share Class / Mandate (01 Product: SHC-/MND-), 'Fee rate terms from 01'", "is earned on Share Class (01: SHC-) under the fund fee terms (01: FSCH-); mandates leave FRR for Client Revenue Record (47) (47 review, Medium item)", "CW-051"),
    ("Waiver Record", "Expense Cap Terms Reference", "Reference (Share Class Fee Terms)", "Reference (Fund Fee Schedule, 01)", "CW-051"),
    ("Distribution Cost Item", "Source Record", "Reference (Source Record), 05 PCL- example", "typed list of 03 CPS-, 05 PCL- / PMT-, 04 campaign spend, 14 data license, 19 or 40 invoice; forced to 03; advisor pay booked per cost center", "CW-159"),
    ("Distribution Cost Item", "Distribution Expense Category", "code list Distribution Expense Category", "code list Cost Item Category (renamed, re-cut); attribute name kept for readers", "CW-159"),
    ("Cost Pool", "Included Expense Categories", "code list Distribution Expense Category", "code list Cost Item Category", "CW-159"),
    ("Flow & Revenue Forecast", "Forecast Share Class / Product", "Reference (Product / Share Class)", "Reference (Service Offering / Product / Share Class)", "CW-159"),
    ("TP Policy", "TP Documentation Reference", "Text", "Reference (Transfer Pricing Documentation, 19)", "CW-910"),
    ("TP Policy / Intercompany Agreement", "", "OECD TPG as primary reference (nine attributes)", "IRC section 482 and Treas. Reg. sections 1.482-1 and 1.482-9 primary; OECD TPG secondary on TP Method only (confirm)", "CW-910"),
    ("Code list: TP Method", "", "OECD TPG Chapter II methods (CUP, Resale Price, Cost Plus, TNMM, Profit Split)", "Treas. Reg. section 1.482-9 services methods", "CW-910"),
    ("Code list: Fee Basis Source", "Custodian Valuation; Client Invoice (12 BIL-)", "mandate asset bases", "removed: mandate fees are booked on Client Revenue Record from the 47 Fee Invoice", "CW-156"),
    ("Code list: Distribution Revenue Type", "Placement Fee Received", "Placement Fee Received", "removed (private fund placement; 30 retires, CW-930)", "CW-930"),
    ("Code list: Cost Asset Type", "Placement Fee", "Placement Fee (private fund / mandate placement)", "removed (private fund placement; 30 retires, CW-930); Deferred Sales Commission kept as a legacy lever value", "CW-930"),
    ("Code list: Revenue Stream", "", "wholesale fund streams (Management, Performance, Distribution, Service, Sales Charge, Administration, Sub-Advisory)", "wealth streams per the brief section 8 (CW-156)", "CW-156"),
    # Fix pass (00_Program/Rework/Reviews/10_review.md; program-lead rulings, 2026-10-15)
    ("Client Revenue Record", "Source Calculation Record", "single-valued: 47 Account Fee Calculation / Fee Invoice, 48 Client Execution, 49, 16 Plan Fee Schedule, 51 Trust", "multi-valued: 47 Account Fee Calculation / Fee Invoice / Fee Debit / Fee Adjustment, 48 Client Trade Confirmation, 49 Client Account Activity / Fully Paid Securities Loan, 50 Sweep Allocation; grain account x month x stream", "CW-156"),
    ("Client Revenue Record", "Revenue Account / Household", "Reference (Account / Party): 02 Client Household on household rows", "Reference (Account / Fee Household, 47 / Service Arrangement, 16)", "CW-027"),
    ("Client Revenue Record", "Revenue Business Line", "(none; 'reached through the 01 offering')", "added: Derived copy of 06 Account Channel Assignment.Assigned Business Line", "CW-156"),
    ("Pricing Scenario", "Proposed Schedule Version", "Reference (Fee Schedule, 47 / Fund Fee Schedule, 01)", "Reference (Fee Schedule, 47 / Proposed Term Change, 36)", "CW-158"),
    ("Pricing Scenario", "Scenario Base Date", "(none)", "added: as-of of Affected Client Assets", "CW-158"),
    ("Performance Fee Record", "Performance Fee Terms Reference", "Reference (Fund Fee Schedule, 01 / Performance Fee Calculation, 47)", "Reference (Fund Fee Schedule, 01 / Fee Schedule, 47); the 47 calculation is the amount source", "CW-051"),
    ("Performance Fee Record", "Crystallization Date", "primary Advisers Act Rule 205-3", "primary Rule 205-2, secondary Rule 205-3", "CW-910"),
    ("Performance Obligation", "Stream Principal vs Agent Conclusion", "(none; only on Distribution Revenue Record)", "added; sub-advised fund fees gross by default", "CW-156"),
    ("Fee Revenue Record", "Gross Fee Revenue", "mastered (fund average net assets x rate)", "Derived copy of 27 Fund Expense Accrual (management fee) summed", "CW-156"),
    ("Fee Revenue Record", "Applied Gross Fee Rate", "Derived copy of 01 fund fee terms", "Derived copy of 27 Fund Expense Accrual.Fee Rate Applied", "CW-156"),
    ("Fee Revenue Record", "Revenue Share Class / Mandate", "Reference (Share Class / Mandate)", "Reference (Share Class); name kept", "CW-156"),
    ("Cash Program Economics", "Program Bank Fee Earned", "mastered, no inputs; note named '50 Program Bank Daily Position'", "computed from 50 Program Bank Daily Total, Sweep Allocation and the 39 program bank agreement (inputs declared)", "CW-156"),
    ("Cash Program Economics", "Net Spread", "bank yield less client rate (yield not held)", "Program Bank Fee Earned annualized over Average Swept Balance", "CW-156"),
    ("Cost-to-Serve Profile", "Partner Payments Cost", "Amount (IC rows)", "removed: duplicate of the parent Profitability Record.Distribution Payments (readers DP-034, DP-035, pending)", "CW-157"),
    ("Cost-to-Serve Profile", "Coverage and Servicing Cost", "advice and service (merged)", "Advice component only; Client Service Cost added (Service)", "CW-157"),
    ("Cost-to-Serve Profile", "Clearing, Custody & Money Movement Cost", "merged amount", "split: Clearing & Client Asset Custody Cost; Money Movement Cost (six components stored)", "CW-157"),
    ("Profitability Record", "Direct Sales & Marketing Cost", "directly attributable advisor compensation", "on advisor rows an allocated Cost Pool amount (Allocation Result), never a 03 statement amount; advisor rows restricted (CD-344)", "CW-159"),
    ("Distribution Cost Item", "Source Record", "single, example CPS-2027-Q4-20417 (one advisor), forced to 03", "multi-valued, example PCL-2026Q3-00871, resolves 05; advisor rows hold all statements of the cost center", "CW-159"),
    ("Distribution Cost Item", "Funding Source", "External (05 DA - Funding Source), Derived from 05 on every row", "External (05 DI - Funding Source); row rule (05 copy on IC rows only)", "CW-013"),
    ("Revenue Contract", "Underlying Agreement", "underwriting rows to 05 Distribution Agreement", "underwriting rows to the 35 board-approved underwriting contract; 05 keeps selling and servicing agreements", "CW-156"),
    ("Revenue Contract", "Contract Inception Date; Termination Notice Period", "Derived from 35 on every row", "Derived, default 15, with a row rule by agreement owner", "CW-156"),
    ("Client Lifetime Value Estimate", "Household Acquisition Channel", "Derived copy of 04", "mastered here with a stated derivation rule", "CW-157"),
    ("Code list: Reconciliation Type", "Executions vs Commission Revenue (48)", "Executions vs Commission Revenue (48)", "Confirmations vs Commission Revenue (48)", "CW-156"),
    ("Code list: Source Domain", "12 Institutional Client Servicing & Reporting", "12 Institutional Client Servicing & Reporting", "removed; 19, 20, 49, 52 added", "CW-159"),
    ("Code list: Profitability Dimension", "Retirement Plan", "(none)", "added (cost to serve by plan, WR)", "CW-157"),
    ("Code list: Revenue Stream", "Sub-Advisory Fee Received", "(none)", "added (Revenue Contract Type 'Sub-Advisory Agreement')", "CW-156"),
    ("Code list: Management P&L Line", "Clearing, Custody & Operations", "Clearing, Custody & Operations", "Clearing, Client Asset Custody & Operations", "CW-007"),
    ("Family names", "", "Revenue & Revenue Recognition; Fee Waivers & Fund Expense Support; Distribution Expense Accounting; Contract Costs & Deferred Commissions; Chart of Accounts & GL Posting; Profitability & Cost-to-Serve; Management Reporting Hierarchies; Budgets, Forecasts & Plans; Period Close, Controls & Data Management", "Revenue & Recognition; Fund Expense Support; Cost Accounting & Contract Costs (DF-EXP absorbs DF-CCA); Ledger Mapping & Controls (DF-COA absorbs Control from DF-DMM); Profitability & Cost to Serve; Client Economics & Pricing (DF-CLE, new); Management Hierarchies; Budgets & Forecasts", "CW-159"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. DECISIONS: the US-only pass of 10 (pre-allocated by CW-022)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-910", "theme": "Scope", "title": "US-only pass of 10 Client Revenue, Pricing Economics & Profitability",
     "domains": ["10", "19", "08", "35"],
     "issue": "The wholesale 10 Distribution Finance & Profitability describes a wholesale distributor reporting under ASC 606 and "
              "IFRS 15 with UK and Luxembourg entities: dual-GAAP accounting frameworks (IFRS as EU- and UK-adopted, FRS 102, Lux GAAP), "
              "IFRS 15 and IFRS 8 references, VAT on intercompany charges, MiFID inducement assessments, trail commissions and "
              "retrocessions, ManCo contracts, ESMA performance fee guidance, OECD transfer pricing as primary and EUR examples.",
     "resolution": "Removed (42 JURISDICTION entries: 2 attributes, 1 whole code list, 8 code values or value descriptions, 2 "
                   "definition wordings, 1 primary reference, 6 examples, 20 IFRS secondary references, 2 sources): attributes "
                   "Distribution Cost Item.Inducement Assessment Reference (MiFID II) and Intercompany Charge.VAT Treatment with the VAT "
                   "Treatment list; Accounting Framework values IFRS (EU-adopted), UK-adopted IFRS, FRS 102 (UK GAAP) and Lux GAAP (the "
                   "list is renamed Accounting Basis with the shared values US GAAP, Tax Basis, Regulatory, resolving the four None "
                   "value-map entries of W1b); Distribution Expense Category value Trail Commission / Retrocession; Revenue Contract Type "
                   "value ManCo Services Agreement and the UCITS / AIF wording of Investment Advisory Agreement (Fund) and Customer "
                   "Determination Basis 'Fund is Customer'; 'ManCo' in Contracting Legal Entity and 'retrocessions' in Distribution "
                   "Payments; the ESMA primary reference of Crystallization Date; examples UK distributor, Lux ManCo, UK Local File and "
                   "EUR amounts; IFRS 15 secondary references on 19 attributes and IFRS 8 on Operating Segment Mapping; the IFRS 15 "
                   "source and the IFRS 8 half of the ASC 280 source. "
                   "Kept and re-sourced: Crystallization Date and the fulcrum accrual to Advisers Act Rules 205-1 to 205-3; the "
                   "constraint wording to ASC 606 ('probable'); Termination Notice Period to Investment Company Act section 15(a); "
                   "Intercompany & Transfer Pricing to IRC section 482 and Treas. Reg. sections 1.482-1 and 1.482-9 (TP Method re-cut to "
                   "the section 1.482-9 services methods; OECD TPG kept as a secondary reference only, confirm), TP Documentation "
                   "Reference re-typed to the 19 Transfer Pricing Documentation (IRC section 6662(e)), Intercompany Service Type adds "
                   "FINRA Notice to Members 03-63 (broker-dealer expense sharing); revenue and P&L lines aligned to the FOCUS report "
                   "(Form X-17A-5 Part II) and Form ADV Part 2A Item 5; examples in USD with US entities. Foreign-currency revenue of "
                   "international funds stays (CW-022; Variance Driver FX kept). "
                   "Perspective: META title 'Client Revenue, Pricing Economics & Profitability', subtitle 'Wealth manager (direct) | "
                   "Scope: US'; overview rewritten for the direct wealth manager and its US entities (RIA, broker-dealer, fund adviser, "
                   "transfer agent, recordkeeper, trust company). "
                   "Adaptation (CW-156 to CW-159, CW-164; not jurisdiction): Client Revenue Record (CLREV-), Cash Program Economics, "
                   "Client Acquisition Cost Record, Lifetime Value Model (LTVM-), Client Lifetime Value Estimate, Pricing Scenario "
                   "(PRSC-) and Pricing Scenario Result added; Hierarchy Node renamed Management Hierarchy Node; Profitability Record "
                   "loses Territory, Salesperson becomes Advisor (03), gains Business Line, Service Offering and Service Tier, Partner "
                   "Firm re-typed to 05 Distributor Firm; Cost-to-Serve Profile re-cut to CW-157 components; Sales Forecast Reference "
                   "removed; Record Metadata dropped (CD-160). Counts (built, Record Metadata excluded, after the review fix pass): 11 to "
                   "10 families, 33 to 40 objects, 223 to 284 attributes, 68 to 94 CDEs (33%), 45 to 49 code lists, 28 to 55 relationships, 16 to 23 "
                   "sources. Intercompany Charge.Elimination Indicator adds Treas. Reg. section 1.1502-13 (consolidated return intercompany "
                   "transactions) as secondary reference.",
     "rationale": "CW-003 and CW-022: the firm's entities are US and report under US GAAP, so the EU/UK accounting frameworks, VAT, "
                  "MiFID inducements and UCITS management company contracts have nothing to serve, while every generic finance object "
                  "stays with US sources. Names are kept so that DP-012, DP-105, DP-109, DP-170, DP-183, DP-194 to DP-196 and DP-242 to "
                  "DP-245 keep resolving; DP-195 and the pending DP-074 lose Intercompany Charge.VAT Treatment and the pending DP-038 and DP-065 lose "
                  "Inducement Assessment Reference (NOTES, READERS). Lever: a firm with UK or EU affiliates restores the removed rows "
                  "from wholesale-v1.0 through the jurisdiction register, and OECD TPG becomes primary (brief SME question 8).",
     "action": "W4", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 8. NOTES for the W4 merge
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    # Readers of removed, renamed or re-typed content. Lines as of 2026-10-15 (completed in the review fix pass).
    "READERS OF REMOVED OR RENAMED 10 CONTENT (grep of data_products/specs_*.py, data_models/models_*.py and keys*.py, "
    "semantic_model/models/sm_*.py). "
    "Distribution Cost Item.Inducement Assessment Reference: DP-034 specs_e_comp_finance_service.py 298 (column list); DP-038 "
    "specs_f_compliance.py 250-251 (Unreconciled G&E Spend metric) and 269 (input list); DP-065 specs_j_compliance_2.py 508, 526-528 "
    "(Ledger Tie-Out) and 544 (input list); models_034_pilot.py 140 (DP-034 text); models_c8_compliance2.py 577 (DP-065 text); keys.py 201. "
    "Intercompany Charge.VAT Treatment: DP-195 specs_e4_finance_tax_treasury.py 520 (column list; live); DP-074 (pending) "
    "specs_k_events_institutional.py 515 (column list) and sm_07_finance_profitability.py 349 (DP-074 dimension vat_treatment). "
    "Profitability Record.Territory: DP-035 specs_e_comp_finance_service.py 351 (grain text) and 403 (column list); DP-057 "
    "specs_h_planning_partners.py 483 and 504 (column list, with Salesperson); sm_07_finance_profitability.py 150 (DP-035 grain), 166 "
    "(territory dimension), 461 (join to DP-009/Territory) and 532 (DP-012 note); models_c3_comp_finance_service.py 355 (DP-035 fk); "
    "models_c6_planning_finance.py 626-627 (DP-057); keys_g3_06_07_10.py 293. "
    "Profitability Record.Salesperson: DP-057 specs_h_planning_partners.py 504; models_c6_planning_finance.py 586 and 626; "
    "keys_g3_06_07_10.py 294. "
    "Hierarchy Node (renamed Management Hierarchy Node): DP-034 specs_e_comp_finance_service.py 396-399, 429 and 448; "
    "models_c3_comp_finance_service.py 335 and 396 (DP-035); sm_07_finance_profitability.py 224 (DP-035 entity); keys_g3_06_07_10.py "
    "147, 301, 322. "
    "Cost-to-Serve Profile.Partner Payments Cost (removed in the fix pass): DP-034 specs_e_comp_finance_service.py 410 (column list); "
    "sm_07_finance_profitability.py 188 (DP-035 fact partner_payments_cost). "
    "Flow & Revenue Forecast.Sales Forecast Reference: keys_g3_06_07_10.py 305 only. "
    "IFRS wording in readers: sm_07_finance_profitability.py 79 (accounting_framework note 'US GAAP or IFRS'), 791-792 (DP-089 contract "
    "cost metric 'ASC 340-40 / IFRS 15') and 926 ('IFRS impairment reversals' question). "
    "Kept names whose definitions or types changed (no reader change needed): Accounting Framework (DP-012 specs_b_foundational.py "
    "351; DP-089 specs_p_inst_intel_finance.py 334, 367), Expense Cap Terms Reference (DP-170 specs_e3_fund_accounting_custody.py 352; "
    "specs_i_product_data.py 177), TP Documentation Reference (DP-196 specs_e4_finance_tax_treasury.py 519, 537), Distribution Expense "
    "Category and Source Record (DP-244 specs_e5_cross_area.py 626 and 646; specs_e_comp_finance_service.py 295 and 417; "
    "specs_h_planning_partners.py 402-403; specs_j_compliance_2.py 411, 435 and 544; specs_f_compliance.py 269; Source Record is now "
    "multi-valued), Gross Fee Revenue and Applied Gross Fee Rate (now Derived copies of 27; DP-012, specs_i_product_data.py 155), Forecast "
    "Share Class / Product, Forecast Gross Sales, Forecast Redemptions and Forecast Average AUM (DP-194 specs_b_foundational.py 702; "
    "specs_h_planning_partners.py 325), Average AUM Reference, Served Party and Coverage and Servicing Cost (DP-034 / DP-035; "
    "Coverage and Servicing Cost now holds the Advice component only), Crystallization Date (DP-012; models_f3.py), and the legacy "
    "intermediary attributes Trailing Fee Constraint Indicator, Sales Charge Source Transactions, CDSC Recovery Offset and Related Share "
    "Class (DP-012; DP-089; sm_07; keys.py; keys_g3; models_c6).",
    "READERS (disposition, proposal). DP-195 (live) and DP-074 (pending, with sm_07 line 349): drop VAT Treatment. DP-244 (live): keeps "
    "Profitability Record, Distribution Cost Item, Plan Version and Plan Line; Direct Channel values are the CW-164 channels. DP-012 "
    "(live, SM-07 certified fee revenue): keeps its objects; gains Client Revenue Record at WP0; sm_07 line 532 drops 'territory'. "
    "DP-034 and DP-035 (pending, CW-041): re-point 'Hierarchy Node' to 'Management Hierarchy Node' at WP0; drop Territory (specs_e 351, "
    "403; sm_07 150, 166, 461; models_c3 355), Inducement Assessment Reference (specs_e 298) and Partner Payments Cost (specs_e 410; sm_07 "
    "188: read Profitability Measure.Distribution Payments instead); add Client Service Cost and Money Movement Cost. DP-038 and DP-065 "
    "(pending): drop the inducement metrics and input columns (no US successor on the cost item). DP-057 (pending): retires at WP0. "
    "DP-089 (pending) and sm_07 79, 791-792, 926: reword to US GAAP. keys_g3_06_07_10.py is superseded at WP2.",
    "07 AND 30 REFERENCES (W4 retirement brief section 5, CW-907, CW-930), all removed or re-pointed: Profitability Record.Territory "
    "removed; Capitalization Assessment ICP- re-typed to 03 Incentive Plan Component (forced to 03 because decisions.PREFIXES still assigns "
    "ICP- and CPS- to 07: move them to 03 at the merge, CW-062); Source Domain value 07 removed; REL rows to CPS- (07), ICP- (07) and TER- "
    "(07) re-pointed or removed; Restatement Trigger 'Territory Realignment' replaced by 'Coverage Model Change'; Reconciliation Type 'Comp "
    "Accrual vs ICM (07)' replaced; Accrual Basis and Cost Item Category wording re-pointed to 03 and 20; Leaf Member example TER- "
    "replaced. 30: Distribution Revenue Type 'Placement Fee Received' and Cost Asset Type 'Placement Fee' removed. A grep of the module "
    "for 07, TER-, RLN-, Territory, Salesperson and FCS- returns nothing.",
    "Renames for the baseline check: object Hierarchy Node -> Management Hierarchy Node (CW-159); attribute Profitability Record."
    "Salesperson -> Advisor; Cost-to-Serve Profile attribute 'Clearing, Custody & Money Movement Cost' (new in the draft) split; family "
    "names as in REPOINTS 'Family names' (codes DF-REV, DF-FWS, DF-EXP, DF-COA, DF-ALC, DF-PNL, DF-HIR, DF-BUD, DF-ICT kept; DF-CLE new; "
    "DF-CCA and DF-DMM retire with their objects moved into DF-EXP and DF-COA). Attribute IDs renumber in every touched family; readers "
    "use names. Kinds changed to Attribute Group per the brief: Capitalization Assessment, Allocation Result, Cost-to-Serve Profile, "
    "Management Hierarchy Node, Plan Line, Flow & Revenue Forecast, Variance.",
    "domains.py: DD_NAMES['10'] takes 'Client Revenue, Pricing Economics & Profitability' at the W4 merge (L1 code DF kept); the folder "
    "10_Distribution_Finance_and_Profitability and the workbook name are kept until the program lead renames them (brief section 1).",
    "decisions.CONCEPT_OWNERSHIP at the merge (corrected in the fix pass; decisions.py has no 10 Hierarchy Node row). New rows: Client "
    "Revenue Record (10, CLREV-, users 19, 21), Cash Program Economics (10, users 50), Client Acquisition Cost Record (10, users 04), "
    "Lifetime Value Model (10, LTVM-, users 37), Client Lifetime Value Estimate (10, users 04), Pricing Scenario (10, PRSC-, users 11, 36), "
    "Management Hierarchy Node (10, MHY- node keys). Row re-cuts: 'Fee Revenue Record (booked revenue)' (10, FRR-): users add 47 and 19, "
    "note becomes 'Enterprise Fee Revenue (own funds); client revenue is Client Revenue Record (CW-156)'; 'Fee Invoice (segregated "
    "mandates)' owner 12 -> 47 with users 10 and 12 (CW-012); 'Incentive Compensation Plan' and 'Compensation Statement' owner 07 -> 03 "
    "(CW-062); 'Territory' (07) drop 10 from users and mark 'Retired (CW-907)'; 'Sales Activity' (03, ACT-): 10 now reads 03 Advisor "
    "Activity counts as a driver (keep 10 as user, rename the concept per the 03 merge); 'Sales Forecast' (03, FCS-) drop 10 from users; "
    "'Fee Schedule / Fee Terms' (01) re-cut to 'Fund Fee Schedule' (CW-051) with 10 as user; 'Recordkeeping Service Arrangement and Plan "
    "Fee Schedule' (16): note becomes '47 bills plan fees; 10 recognizes them from the 47 calculation or invoice'; 'Client Segment / Party "
    "Classification' (02): note becomes '10 uses External (02 - Segment Assignment)'.",
    "Ownership overrides in enrich_10 that the merge can retire: Assessed Cost Source and Advisor forced to 03 (ICP- is still 07 in "
    "decisions.PREFIXES; EMP- is 20 and keys the 03 Advisor); Partner Firm forced to 05 (PTY- key of the 05 Distributor Firm); Proposed "
    "Schedule Version forced to 47 ('Fee Schedule' still resolves to the 01 row until CW-051); Source Calculation Record forced to 47 ('Fee "
    "Invoice' still resolves to 12 BIL-). The Distribution Cost Item.Source Record override was dropped in the fix pass (multi-valued, "
    "05 example).",
    "KEY_FORMATS additions (composite keys of 10 business objects without an identifier, review D): Distribution Revenue Record = "
    "<SHC- id> / <LEN- id> / <distribution revenue type> / <fiscal period>; Adviser-Borne Cost = <adviser-borne cost type> / <PYA- id or "
    "SHC- id> / <fiscal period>; Control = <reconciliation type> / <fiscal period>; Client Revenue Record keeps CLREV- (account x stream "
    "x month).",
    "MERGE EDITS FOR SIBLINGS (not edited here): 49 Fully Paid Securities Loan holds only Client Loan Fee Rate; it needs the gross borrower "
    "fee or the firm share (or a monthly loan revenue record) so that the CLREV fully paid lending row has a calculating record; meanwhile "
    "10 derives the firm share by the documented rule in the Source Calculation Record row rule. 19 Transfer Pricing Documentation."
    "Covered Intercompany Agreements (content_19 line 431, REL 516) holds the back-link of TP Policy.TP Documentation Reference: 10 holds "
    "the link (ruling 5); 19 drops the attribute or declares it a Derived copy. content_19 REL line 488 lists the 10 posting sources: add "
    "Client Revenue Record and Cash Program Economics. content_47 REL line 451 'Account Fee Calculation is recognized as Fee Revenue "
    "Record [10]': read 'Client Revenue Record [10]'. content_19 still names '10 Distribution Finance & Profitability' (overview; Journal "
    "Source 'Distribution Finance'); 14 (ALM- hand-off text), 21 and 43 (Loan Intercompany Agreement) carry the old name.",
    "Shared lists: 10 is a direct user of Distribution Channel (External (Enterprise - Distribution Channel)) on Client Revenue Record."
    "Revenue Channel, Distribution Cost Item.Direct Channel, Profitability Record.Channel and Flow & Revenue Forecast.Forecast Channel, "
    "with the CW-164 values; add '10' to its direct_users. Client Segment is External (02 - Segment Assignment), the firm's designated "
    "segmentation scheme. LOCAL_RENAMES ('10', 'Hierarchy Type', ...) and ('10', 'Reconciliation Type', ...) stay valid.",
    "Sibling names used (modules on disk 2026-10-15, including the drafted 05, 06, 16, 36, 47, 48, 49, 50, 51 and 52): 47 Account Fee "
    "Calculation (FCRUN- / FEASG- key), Fee Invoice (BIL-), Fee Debit (FDBT-), Fee Adjustment (FADJ-), Fee Household (FHHG-), Fee "
    "Schedule (CLFEE-) with Performance Fee Terms, Performance Fee Calculation, Billing Arrangement (BLA-); 48 Client Trade Confirmation "
    "(CCONF-: Commission Charged, Markup Markdown Amount); 49 Client Account Activity (CLACT-; Commission Amount), Fully Paid Securities "
    "Loan (CSLN-); 50 Sweep Program (SWEEP-), Program Bank (PGBNK-), Program Bank Participation (Program Bank Agreement, Bank Rate "
    "Formula), Program Bank Daily Total, Sweep Allocation, Sweep Rate Tier; 39 Contract (CTRCT-); 36 Product Change Initiative (LCHG-), "
    "Proposed Term Change; 27 Fund Expense Accrual; 16 Service Arrangement (PSVA-); 51 Trust (TRUST-; terms only); 52 Sub-Adviser "
    "Engagement (SADV-; fee terms in the 35 ADVA- it references); 03 Advisor (EMP-), Compensation Statement (CPS-), Incentive Plan "
    "Component (ICP-n-Cnn); 04 Campaign (CAM-), Acquisition Milestone; 05 Distributor Firm (PTY-), Payment Arrangement (PYA-), Payment "
    "Calculation (PCL-), Partner Payment (PMT-); 06 Client Asset Measures (Average Client Assets, Ending Client Assets), Account Channel "
    "Assignment (CHASG-, Assigned Business Line), Transaction (TXN-); 11 Competitor Pricing Observation (COFF- composite); 01 Service "
    "Offering (OFFR-), Service Tier, fund fee terms (FSCH-); 19 Transfer Pricing Documentation. The measure code MSR-AVGCLIENTASSETS is "
    "illustrative (06 gives no measure codes).",
    "Deviations from the brief (after the fix pass): (1) Client Revenue Record grain is account x revenue stream x month (offering is an "
    "attribute, not a key part); household-grain rows key on the 47 Fee Household (lever); (2) Profitability Record has no Household or "
    "Acquisition Channel attribute (Client / Account holds household rows; acquisition-channel economics are the Client Acquisition Cost "
    "Record and Client Lifetime Value Estimate); (3) Cost-to-Serve Profile stores six of the seven CW-157 components (Communications and "
    "Regulatory stay merged); (4) Cost per Funded Household, funded account counts, the cohort on Client Lifetime Value Estimate and the "
    "pricing breakeven are computed in products, not stored; (5) attributes 284, four above the brief's 240-280 band, from the "
    "program-lead fix-pass rulings (business line, client service cost, money movement cost, scenario base date, principal versus agent) "
    "net of the removed Partner Payments Cost.",
    "Remaining grep hits for EU/UK terms in the module: none (MiFID, UCITS, AIFM, FCA, ESMA, PRIIP, KID, SFDR, CASS, CSDR, EMIR, DORA, "
    "ICARA, GDPR, FinDatEx, Calastone, Clearstream, CSSF, IFRS, VAT, ManCo, Lux, EUR, GBP, 'UK', 'EU'). 'OECD TPG' remains once as the "
    "secondary reference of TP Method (lever). 'Custody' appears only qualified (client asset custody); 'Holding' only as 'Client "
    "Holding'; 'Position' nowhere.",
    "SME question 10 (owner of mandate performance-fee terms) is retired: the program lead ruled that 47 owns them (47 Fee Schedule "
    "Performance Fee Terms); 10 references them by row rule.",
]
