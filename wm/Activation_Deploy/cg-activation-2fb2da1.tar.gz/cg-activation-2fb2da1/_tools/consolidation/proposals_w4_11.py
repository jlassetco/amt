"""Consolidation proposals from the W4 draft of Data Domain 11 Market & Competitive Intelligence (wealth manager), 2026-10-15.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py,
shared_code_lists.py and jurisdiction.REMOVALS at the W4 merge. Formats follow CONTRACT.md in this folder. The brief is
00_Program/Rework/Briefs/11_Market_and_Competitive_Intelligence.md (Disposition: Adapt, CW-013, CW-160). It implements
CW-003, CW-013, CW-022, CW-158, CW-160, CW-164, CW-169, CW-170 (proposals_w4_economics.py) and CW-132, CW-134, CW-139,
CW-140 (proposals_w4_channels.py), applies section 5 of the W4 retirement brief (07 and 30; CW-907, CW-930) and drafts
CW-911, the US-only pass of 11. Module: content_11_market_and_competitive_intelligence.py (adapted in place; output path
and folder unchanged). The brief names the file proposals_11.py; this W4 file is proposals_w4_11.py, as assigned (there is
no earlier proposals_11.py).
"""

_D, _C = "11", "CW-911"

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES (decisions.PREFIXES tuple format). None: COFF- is reserved by proposals_w4_economics.PREFIXES (CW-160) and
#    its format by KEY_FORMATS there; Competitor Pricing Observation takes the composite key COFF- / Price Component /
#    Observation As-of Date (x Balance Tier when tiered). The 15 kept prefixes are unchanged.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# Key formats (proposals_w4_economics.KEY_FORMATS format), fix-pass ruling 3.
KEY_FORMATS = [
    ("COFF-", "COFF-<sequence, 5 digits>, e.g. COFF-00213", "Competitor offering (unchanged from proposals_w4_economics)."),
    ("Competitor Pricing Observation",
     "Composite: COFF- / Price Component / Observation As-of Date [/ Balance Tier Lower Bound, only when the price is tiered], "
     "e.g. 'COFF-00213 / Advisory Fee Rate / 2026-09-30' (untiered) and 'COFF-00213 / Advisory Fee Rate / 2026-09-30 / USD "
     "1,000,000' (tiered)",
     "Price Component values are exact list labels ('Advisory Fee Rate', not 'Advisory Fee')."),
    ("Regulatory Horizon Item", "Composite: Regulator / Body / Regulatory Initiative", "Kept as a business object (fix-pass ruling 4)."),
    ("Redistribution Restriction", "Child of Industry Dataset Profile: DSET- of the profile's Licensed Dataset", ""),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED MEMBERSHIPS: 11 local lists registered under a shared list (local names kept, as the brief says "as ...").
#    value_map maps each local label exactly as authored to the shared code; new_values are codes the shared list does
#    not hold yet. Each map REPLACES the 11 map in shared_code_lists.py (see VALUE_MAPS for the removed keys).
# ---------------------------------------------------------------------------------------------------------------------
_CHANNEL_MAP = {
    "Direct": "DIRECT", "Direct - Self-Directed": "DIRECT_SELF_DIRECTED", "Direct - Digital Advice": "DIRECT_DIGITAL_ADVICE",
    "Direct - Human Advice": "DIRECT_HUMAN_ADVICE", "Direct - Trust": "DIRECT_TRUST", "Workplace": "WORKPLACE",
    "Workplace - Recordkept": "WORKPLACE_RECORDKEPT", "Institutional": "INSTITUTIONAL",
    "Institutional - Direct": "INSTITUTIONAL_DIRECT", "Institutional - Consultant-Led": "INSTITUTIONAL_CONSULTANT",
    "Institutional - OCIO": "INSTITUTIONAL_OCIO", "Intermediary": "INTERMEDIARY",
    "Intermediary - Wirehouse": "INTERMEDIARY_WIREHOUSE",
    "Intermediary - National / Regional Broker-Dealer": "INTERMEDIARY_REGIONAL_BD",
    "Intermediary - Independent Broker-Dealer": "INTERMEDIARY_IBD", "Intermediary - RIA": "INTERMEDIARY_RIA",
    "Intermediary - Bank / Trust": "INTERMEDIARY_BANK_TRUST", "Intermediary - TAMP / Model Marketplace": "INTERMEDIARY_TAMP_MODEL",
    "Intermediary - Brokerage Platform": "INTERMEDIARY_BROKERAGE_PLATFORM",
    "Intermediary - Recordkeeper": "INTERMEDIARY_RECORDKEEPER",
}

_REGULATOR_MAP = {
    "SEC": "US_SEC", "FINRA": "US_FINRA", "US State Securities Regulator": "US_STATE_SECURITIES_REGULATOR",
    "CFTC / NFA": "US_CFTC_NFA", "OCC": "US_OCC", "Federal Reserve": "US_FEDERAL_RESERVE", "DOL / EBSA": "US_DOL_EBSA",
    "IRS / US Treasury": "US_IRS_TREASURY", "FinCEN": "US_FINCEN", "MSRB": "US_MSRB", "IOSCO": "INTL_IOSCO",
}

_PROVIDER_MAP = {
    "ICI": "ICI", "Morningstar": "MORNINGSTAR", "LSEG Lipper": "LSEG_LIPPER", "ISS Market Intelligence": "ISS_MARKET_INTELLIGENCE",
    "Broadridge": "BROADRIDGE", "Cerulli Associates": "CERULLI", "Nasdaq eVestment": "NASDAQ_EVESTMENT",
    "Discovery Data": "DISCOVERY_DATA", "US Department of Labor": "US_DOL", "US SEC": "US_SEC", "FINRA": "FINRA",
    "Federal Reserve": "FEDERAL_RESERVE", "Other": "OTHER",
}

_CATEGORY_MAP = {
    "ICI Investment Classification": "ICI_INVESTMENT_CLASSIFICATION", "Morningstar Category": "MORNINGSTAR_CATEGORY",
    "Morningstar Global Category": "MORNINGSTAR_GLOBAL_CATEGORY", "Lipper Global Classification": "LIPPER_GLOBAL_CLASSIFICATION",
    "eVestment Universe": "EVESTMENT_UNIVERSE", "Firm Market Segment": "FIRM_MARKET_SEGMENT",
}

SHARED_MEMBERSHIPS = [
    {"shared": "Distribution Channel", "local": "Industry Channel", "value_map": _CHANNEL_MAP, "new_values": [],
     "note": "new_values is empty because the DIRECT_, WORKPLACE_, INSTITUTIONAL_OCIO, INTERMEDIARY_BROKERAGE_PLATFORM and "
             "INTERMEDIARY_RECORDKEEPER codes arrive with the CW-164 SHARED_RECUTS (proposals_w4_economics), not from 11. CW-164 values as refined by CW-140 (INTERMEDIARY_RECORDKEEPER for RETIREMENT_DCIO, CW-139). Labels follow the shared "
             "list's 'Level 1 - Level 2' style; the shared labels may differ in wording (the steward 09 applies the list at W5). "
             "The five EU/UK values go to JURISDICTION (CW-911); Insurance Broker-Dealer under CW-165; Hybrid RIA and Independent "
             "RIA merged into Intermediary - RIA (thin IC, CW-013)."},
    {"shared": "Data Provider", "local": "Industry Data Provider", "value_map": _PROVIDER_MAP, "new_values": ["FEDERAL_RESERVE"],
     "note": "EFAMA, Investment Association, FE fundinfo and Citywire removed (CW-164, CW-911). FINRA (already a shared value, "
             "added for 22 TRACE) now also covers BrokerCheck and the Industry Snapshot. New value FEDERAL_RESERVE ('Federal "
             "Reserve', 'Survey of Consumer Finances; Financial Accounts of the United States (Z.1)') for household wealth sizing; "
             "steward 14 to confirm. 11 stays a member; 05 re-registers Data Vendor (CW-132)."},
    {"shared": "Fund Category Scheme", "local": "Category Scheme", "value_map": _CATEGORY_MAP, "new_values": [],
     "note": "Steward 11. EFAMA_EFC and IA_SECTOR removed from the shared values and the map (CW-164, CW-911); the source text "
             "of the shared list should drop 'EFAMA EFC' and 'IA sectors'."},
    {"shared": "Regulator", "local": "Regulatory Body", "value_map": _REGULATOR_MAP, "new_values": [],
     "note": "Local labels now copy the shared Regulator labels (US values after the W1 re-cut, CW-909); 'US SEC' relabeled 'SEC' "
             "and 'US DOL' relabeled 'DOL / EBSA'; State Securities Regulator, CFTC / NFA, OCC, Federal Reserve, IRS / US "
             "Treasury, FinCEN and MSRB added; the six EU/UK values (mapped to None since W1) removed (CW-911)."},
    {"shared": "Frequency", "local": "Frequency",
     "value_map": {"Daily": "DAILY", "Weekly": "WEEKLY", "Monthly": "MONTHLY", "Quarterly": "QUARTERLY",
                   "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL", "Ad Hoc": "AD_HOC"},
     "new_values": [], "note": "Unchanged."},
    {"shared": "Period Type", "local": "Period Type",
     "value_map": {"Month": "MONTH", "Quarter": "QUARTER", "Year to Date": "YEAR_TO_DATE", "Trailing 12 Months": "ROLLING_12_MONTHS",
                   "Calendar Year": "YEAR", "Point in Time": "POINT_IN_TIME"},
     "new_values": [], "note": "Unchanged."},
    {"shared": "Reporting Period Basis", "local": "Return Period",
     "value_map": {"1 Month": "TRAILING_1M", "Year to Date": "YTD", "1 Year": "TRAILING_1Y", "3 Years Annualized": "TRAILING_3Y",
                   "5 Years Annualized": "TRAILING_5Y", "10 Years Annualized": "TRAILING_10Y", "Since Inception": "SINCE_INCEPTION"},
     "new_values": [], "note": "Unchanged."},
    {"shared": "Data Basis", "local": "Value Basis",
     "value_map": {"Reported": "REPORTED", "Estimated": "ESTIMATED", "Modeled": "MODELED", "Interpolated": "INTERPOLATED"},
     "new_values": [], "note": "Unchanged."},
    {"shared": "Award Outcome", "local": "Award Outcome",
     "value_map": {"Winner": "WINNER", "Highly Commended": "HIGHLY_COMMENDED", "Shortlisted / Finalist": "SHORTLISTED_FINALIST",
                   "Not Placed": "NOT_PLACED"},
     "new_values": [], "note": "Steward 11; unchanged."},
    {"shared": "Measure Unit", "local": "Measure Unit",
     "value_map": {"Percent": "PERCENT", "Basis Points": "BASIS_POINTS", "Currency Amount": "CURRENCY_AMOUNT"}, "new_values": [],
     "note": "Fix-pass ruling 2. The list is proposed as shared by 22 (proposals_22 SHARED_CANDIDATES; 52 registers a subset in "
             "proposals_w3_52); labels copied from content_22 'Measure Unit'. Fee Benchmark Study.Measure Unit (unit of every Fee "
             "Benchmark Result and Pricing Input statistic). Register 11 when the list is created."},
    {"shared": "Net Worth Band (02, to be shared)", "local": "Net Worth Band",
     "value_map": {v: v for v in ("USD 0 - 49,999", "USD 50,000 - 99,999", "USD 100,000 - 249,999", "USD 250,000 - 499,999",
                                   "USD 500,000 - 999,999", "USD 1,000,000 - 2,499,999", "USD 2,500,000 - 4,999,999",
                                   "USD 5,000,000 - 9,999,999", "USD 10,000,000 or more")}, "new_values": [],
     "note": "Fix-pass ruling 4: Market Sizing Record.Wealth Band adopts the 02 Net Worth Band boundaries label for label "
             "(content_02 line 560), so market segments nest with client profiles. Not yet a shared list: see SHARED_CANDIDATES."},
    {"shared": "Business Line", "local": "Business Line",
     "value_map": {c: c for c in ("DB", "DA", "HA", "PF", "WR", "IA", "IC", "TR")}, "new_values": [],
     "note": "New member (CW-004): Competitor Offering.Contested Business Line. Two-letter codes as values (identity map)."},
]

# Memberships that end (already listed in proposals_w4_economics.MEMBERSHIPS_REMOVE): ('11', 'Data Classification') and
# ('11', 'Data Quality Status'), with the dropped Record Metadata (CD-160).

# ---------------------------------------------------------------------------------------------------------------------
# 3. VALUE_MAPS: the replacement of each 11 value_map in shared_code_lists.py. 'remove' lists the local keys of the current
#    map that no longer exist in the module (EU/UK values recorded in JURISDICTION, other re-cuts in REPOINTS). The
#    Regulator map has carried keys for values removed from the shared list since the W1 re-cut (mapped to None): fixed here.
# ---------------------------------------------------------------------------------------------------------------------
VALUE_MAPS = [
    {"shared": "Regulator", "member": ("11", "Regulatory Body"), "value_map": _REGULATOR_MAP,
     "remove": ["US SEC", "US DOL", "UK FCA", "ESMA", "European Commission", "CSSF", "Central Bank of Ireland", "BaFin"]},
    {"shared": "Distribution Channel", "member": ("11", "Industry Channel"), "value_map": _CHANNEL_MAP,
     "remove": ["Wirehouse", "National / Regional Broker-Dealer", "Independent Broker-Dealer", "Hybrid RIA", "Independent RIA",
                "Bank Trust / Private Bank", "Insurance Broker-Dealer", "DC / Retirement", "Institutional", "Direct / Self-Directed",
                "UK Platform", "UK IFA / Wealth Manager / DFM", "EU Private Bank", "EU Retail Bank Network", "EU Fund Platform"]},
    {"shared": "Data Provider", "member": ("11", "Industry Data Provider"), "value_map": _PROVIDER_MAP,
     "remove": ["EFAMA", "Investment Association", "FE fundinfo", "Citywire"]},
    {"shared": "Fund Category Scheme", "member": ("11", "Category Scheme"), "value_map": _CATEGORY_MAP,
     "remove": ["EFAMA EFC", "IA Sector"]},
]

# LOCAL_RENAMES entry to replace: ('11', 'Coverage Basis', 'Industry Flow Geographic Basis', ...) becomes
# ('11', 'Coverage Basis', 'Industry Data Attribution Basis', "Basis on which an industry dataset attributes flows and assets
#  (fund domicile, reporting distributor, investor residence, filer)."): Distributor Reported and Filer Reported are not
# geographic, and Country of Sale is removed (CW-911).

# ---------------------------------------------------------------------------------------------------------------------
# 4. SHARED_CANDIDATES: local lists that look like enterprise lists
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Price Component", ["11", "47", "10", "36"],
     "Components of what a client pays or earns (advisory fee rate, subscription fee, commission, options contract fee, account "
     "service fee, margin rate, cash sweep yield, expense ratio). 47 fee schedule components and 10 Pricing Scenario subjects "
     "use the same set; a shared 'Price Component' (steward 47) lets 10 compare a scenario with the 11 observations directly."),
    ("Net Worth Band", ["02", "11", "04", "06"],
     "Fix-pass ruling 4: 11 Market Sizing Record.Wealth Band now uses the 02 Net Worth Band boundaries (local copy). Proposal for "
     "steward 02 at W5: make the list shared (02 steward; 11, 04 and 06 members) and split the 02 top band 'USD 10,000,000 or "
     "more' into 'USD 10,000,000 - 24,999,999' and 'USD 25,000,000 or more', which ultra-high-net-worth market sizing (Cerulli, "
     "SCF top percentiles) reports separately. Measure note: 02 bands net worth excluding the residence; 11 bands investable "
     "assets on the same boundaries."),
    ("Competitor Offering Type", ["11", "01"],
     "Mirrors the 01 Offering Type of Service Offering (brokerage, digital, hybrid and human advice, recordkeeping, cash, trust) "
     "plus the fund and ETF ranges. Keep local unless 01 agrees a shared 'Offering Type' covering both own and competitor offerings."),
    ("Pricing Source Type", ["11", "47"],
     "Disclosure documents a price is evidenced in (Form ADV Part 2A, Form CRS, fee schedule, prospectus fee table)."),
    ("Market Topic", ["11", "04", "42"],
     "Topics of research, news and trends; 04 content topics and 42 corporate communications topics overlap."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. TERM_CONFLICTS (decisions.TERM_CONFLICTS format)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Offering",
     "usages": [("01", "Service Offering (OFFR-)", "What the firm does for a client: an advice, brokerage, trust or OCIO offering."),
                ("11", "Competitor Offering (COFF-)", "What a competitor sells, observed from public documents.")],
     "recommendation": "Never bare 'Offering' in 11: 'Competitor Offering' or 'own Service Offering'. Competitor Offering.Comparable "
                       "Own Offering links the two.",
     "resolution": "Logged (CW-169).", "status": "Open", "decision": "CW-169"},
    {"term": "Assets",
     "usages": [("06", "Client Assets / Net New Assets (MSR-)", "The firm's certified client asset measures."),
                ("11", "Competitor Metric Snapshot.Reported Client Assets / Reported Net New Assets", "A competitor's own reported figures, on its own definition."),
                ("11", "Competitor Metric Snapshot.Total AUM", "Form ADV Item 5.F regulatory AUM or fund sponsor assets.")],
     "recommendation": "11 prefixes competitor figures with 'Reported' and says they are not the 06 measure; the firm's own values in "
                       "11 are Derived copies of 06 (Market Share Record.Firm Value, Opportunity Potential.Firm Assets with Party).",
     "resolution": "Defined in each attribute.", "status": "Resolved", "decision": "CW-160"},
    {"term": "Advisor",
     "usages": [("03", "Firm advisor", "The firm's own representative."),
                ("05", "Financial Professional", "External advisor at an intermediary."),
                ("11", "Competitor Metric Snapshot.Advisor Count; Competitor Distribution Footprint.Estimated Advisor Headcount", "Advisors employed by a competitor.")],
     "recommendation": "11 definitions say 'the competitor's advisors'. Advisor Count is the firm-wide reported total; Estimated "
                       "Advisor Headcount is the per-channel estimate.",
     "resolution": "Defined in each attribute.", "status": "Resolved", "decision": "CW-160"},
    {"term": "Rating",
     "usages": [("11", "Rating Observation (RTG-)", "Third-party fund rating (Morningstar, Lipper)."),
                ("05", "Partner Research Rating; Consultant Rating", "Intermediary home-office and consultant ratings of the firm's products."),
                ("17", "Credit rating", "Issuer and instrument credit ratings.")],
     "recommendation": "11 says 'fund rating' or names the scheme; the 05 ratings keep their qualified names.",
     "resolution": "Logged.", "status": "Resolved", "decision": "CW-160"},
    {"term": "Opportunity",
     "usages": [("05", "Sales Opportunity (OPP-)", "An own pipeline opportunity."),
                ("11", "Opportunity Potential", "Estimated wallet share at an intermediary firm (market estimate, IC)."),
                ("11", "Plan Market Record.Recordkeeping Opportunity Value", "Estimated value of a plan as a recordkeeping prospect.")],
     "recommendation": "11 never creates opportunities; Mandate Search Event.Linked Opportunity and Win/Loss Analysis read the 05 object.",
     "resolution": "Logged.", "status": "Resolved", "decision": "CW-170"},
    {"term": "Price Quote Basis",
     "usages": [("22", "Price Quote Basis (content_22 line 459)", "ISO 20022 security quote basis: Per Unit, Percent of Par, Yield."),
                ("11", "Price Quote Basis", "Unit in which a competitor price is quoted: annual percentage of assets, per trade, per contract, APY.")],
     "recommendation": "Same list name, different vocabulary. Rename the 11 list 'Competitor Price Unit' at W5, or add a LOCAL_RENAMES "
                       "entry ('11', 'Price Quote Basis', 'Competitor Price Quote Basis', ...). The 11 name is kept in this fix pass.",
     "resolution": "Logged.", "status": "Open", "decision": "CW-169"},
    {"term": "Segment",
     "usages": [("02", "Segment Assignment", "Firm segment of a client or household."),
                ("04", "Marketing Segment (SEG-)", "Audience definition for campaigns."),
                ("11", "Market Sizing Record.Mapped Firm Segment; Category Mapping.Internal Market Segment", "Market segments sized externally and their mapping to 02 segment values; fund market segments for share.")],
     "recommendation": "11 says 'market segment'; Mapped Firm Segment holds a 02 scheme value, never a client assignment.",
     "resolution": "Logged.", "status": "Resolved", "decision": "CW-160"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. JURISDICTION (jurisdiction.REMOVALS entry format; CW-022, CW-911). A whole removed object or code list has attribute "".
# ---------------------------------------------------------------------------------------------------------------------


def _j(obj, attr, regime, note):
    return {"domain": _D, "object": obj, "attribute": attr, "regime": regime, "decision": _C, "note": note}


_CROWN = "FE fundinfo Crown Fund Rating scale (UK market practice); the US schemes are Morningstar and Lipper Leaders."
_CW = "Citywire Fund Manager Rating scale (UK market practice); Manager Rating removed."

JURISDICTION = [
    # Objects
    _j("Manager Rating", "", "UK market practice",
       "Citywire fund manager ratings (4 attributes: Rated Manager, Manager Rating Value, Rated Sector, Manager Rating Date). No US "
       "equivalent is modeled; fund-level ratings stay in Rating Observation. Lever: the UK extension restores it."),
    # Attributes of kept objects
    _j("Competitor Distribution Footprint", "Market", "EU market practice",
       "Country of distribution (example DE) for cross-border EU/UK fund distribution. The US footprint is by channel (grain "
       "competitor x channel)."),
    # Code list values
    _j("Code list: Industry Data Provider", "EFAMA", "Other EU/UK", "European Fund and Asset Management Association (EU). Shared Data Provider re-cut, CW-164."),
    _j("Code list: Industry Data Provider", "Investment Association", "UK market practice", "UK trade association. CW-164."),
    _j("Code list: Industry Data Provider", "FE fundinfo", "UK market practice", "UK fund data and Crown ratings. CW-164."),
    _j("Code list: Industry Data Provider", "Citywire", "UK market practice", "UK manager ratings and trade press. CW-164."),
    _j("Code list: Category Scheme", "EFAMA EFC", "EU market practice", "EFAMA Fund Classification. Shared Fund Category Scheme re-cut, CW-164."),
    _j("Code list: Category Scheme", "IA Sector", "UK market practice", "Investment Association sectors. CW-164."),
    _j("Code list: Industry Vehicle Type", "UCITS", "UCITS", "Foreign peer funds keep their vehicle as Mutual Fund or Other."),
    _j("Code list: Industry Vehicle Type", "AIF", "AIFMD", "Foreign peer funds keep their vehicle as Mutual Fund or Other."),
    _j("Code list: Industry Channel", "UK Platform", "UK market practice", "Shared Distribution Channel re-cut to the CW-164 values; was mapped to INTERMEDIARY_FUND_PLATFORM."),
    _j("Code list: Industry Channel", "UK IFA / Wealth Manager / DFM", "UK market practice", "CW-164."),
    _j("Code list: Industry Channel", "EU Private Bank", "EU market practice", "CW-164."),
    _j("Code list: Industry Channel", "EU Retail Bank Network", "EU market practice", "CW-164."),
    _j("Code list: Industry Channel", "EU Fund Platform", "EU market practice", "CW-164."),
    _j("Code list: Regulatory Body", "UK FCA", "FCA", "Mapped to None in the Regulator crosswalk since W1 (CW-909)."),
    _j("Code list: Regulatory Body", "ESMA", "Other EU/UK", "European Securities and Markets Authority (EU). Mapped to None since W1."),
    _j("Code list: Regulatory Body", "European Commission", "Other EU/UK", "EU. Mapped to None since W1."),
    _j("Code list: Regulatory Body", "CSSF", "Other EU/UK", "Luxembourg regulator. Mapped to None since W1."),
    _j("Code list: Regulatory Body", "Central Bank of Ireland", "Other EU/UK", "Irish regulator. Mapped to None since W1."),
    _j("Code list: Regulatory Body", "BaFin", "Other EU/UK", "German regulator. Mapped to None since W1."),
    _j("Code list: Rating Scheme", "FE fundinfo Crown Rating", "UK market practice", _CROWN),
    _j("Code list: Rating Scheme", "Citywire Manager Rating", "UK market practice", _CW),
    _j("Code list: Rating Value", "1 Crown", "UK market practice", _CROWN),
    _j("Code list: Rating Value", "2 Crowns", "UK market practice", _CROWN),
    _j("Code list: Rating Value", "3 Crowns", "UK market practice", _CROWN),
    _j("Code list: Rating Value", "4 Crowns", "UK market practice", _CROWN),
    _j("Code list: Rating Value", "5 Crowns", "UK market practice", _CROWN),
    _j("Code list: Rating Value", "AAA", "UK market practice", _CW),
    _j("Code list: Rating Value", "AA", "UK market practice", _CW),
    _j("Code list: Rating Value", "A", "UK market practice", _CW),
    _j("Code list: Rating Value", "+", "UK market practice", _CW),
    _j("Code list: Fee Measure", "Ongoing Charges Figure", "FCA", "UK/EU OCF; the US measures are Net and Gross Expense Ratio (Form N-1A Item 3)."),
    _j("Code list: Fee Measure", "PRIIPs Total Costs", "PRIIPs", "PRIIPs KID cost figure; no US equivalent beyond the fee table."),
    _j("Code list: Fee Study Purpose", "Assessment of Value", "FCA", "FCA COLL 6.6.20R; the US board review is Board 15(c) Review (kept)."),
    _j("Code list: Coverage Basis", "Country of Sale", "EU market practice", "Cross-border fund registration basis (EFAMA); the US values are Fund Domicile, Distributor Reported, Investor Residence and Filer Reported."),
    _j("Code list: Sizing Unit", "EUR", "Other EU/UK", "EU market sizing; the US market is sized in USD (foreign-currency amounts in observations keep ISO 4217)."),
    _j("Code list: Sizing Unit", "GBP", "Other EU/UK", "UK market sizing; as above."),
    # References and examples re-sourced (brief section 4a)
    _j("Industry Dataset Profile", "Category Scheme", "EU market practice", "Secondary reference EFAMA removed; re-sourced to LSEG Lipper."),
    _j("Industry Dataset Profile", "Coverage Basis", "EU market practice", "Primary reference EFAMA and the 'country of sale' reading removed; re-sourced to ICI and ISS Market Intelligence."),
    _j("Industry Data Release", "As-of Date", "EU market practice", "Secondary reference EFAMA removed; re-sourced to Morningstar."),
    _j("Industry Flow Observation", "Region / Market", "EU market practice", "Primary reference EFAMA and example LU removed; re-sourced to ICI, example US (foreign domicile only for peers of international funds)."),
    _j("Industry Flow Observation", "Net Flow", "EU market practice", "Secondary reference EFAMA removed; re-sourced to ISS Market Intelligence."),
    _j("Industry Flow Observation", "Ending Assets", "EU market practice", "Primary reference EFAMA removed; re-sourced to ICI and Morningstar."),
    _j("Market Share Record", "Region / Market", "UK market practice", "Example GB removed; example US."),
    _j("Peer Universe", "Peer Universe Name", "EU market practice", "Example 'EAA Fund' (Morningstar Europe-Asia-Africa category) removed; US Fund category example."),
    _j("Peer Universe", "Inclusion Rules", "EU market practice", "Example 'AUM > EUR 50m; LU/IE domiciled' removed; USD and US-domiciled example."),
    _j("Peer Fund", "ISIN", "EU market practice", "Example LU ISIN removed; US example (international peers keep foreign ISINs)."),
    _j("Peer Fund", "Domicile", "EU market practice", "Example LU removed; US example."),
    _j("Peer Fund", "Peer Fund Name", "EU market practice", "Example 'Acc USD' (accumulating UCITS share class naming) removed."),
    _j("Rating Scheme", "Rebalance Frequency", "UK market practice", "Secondary reference FE fundinfo removed; re-sourced to LSEG Lipper."),
    _j("Rating Scheme", "Minimum History Required", "UK market practice", "Secondary reference FE fundinfo removed; re-sourced to LSEG Lipper."),
    _j("Rating Observation", "Rating Value", "UK market practice", "Secondary reference FE fundinfo and 'crowns' in the definition removed; re-sourced to LSEG Lipper."),
    _j("Competitor Personnel Move", "Affected Strategies / Funds", "UK market practice", "Primary reference Citywire removed; re-sourced to Morningstar."),
    _j("Award", "Award Program", "UK market practice", "Examples Citywire awards and Investment Week Fund Manager of the Year removed."),
    _j("Award", "Paid to Participate Indicator", "FCA", "Secondary reference 'UK FCA' removed; SEC Marketing Rule 206(4)-1 kept."),
    _j("Fee Benchmark Study", "Fee Measure Compared", "FCA", "Secondary reference 'UK FCA' and example 'Ongoing Charges Figure' removed; re-sourced to SEC Form N-1A."),
    _j("Fee Benchmark Study", "Study Purpose", "FCA", "Secondary reference 'UK FCA' and example 'Assessment of Value' removed; re-sourced to Investment Company Act Section 15(c)."),
    _j("Peer Metric Snapshot", "Expense Ratio", "UCITS", "'Ongoing charge' removed from the definition; net expense ratio per Form N-1A Item 3."),
    _j("Regulatory Horizon Item", "Regulator / Body", "FCA", "Example 'UK FCA' removed; example SEC."),
    _j("Regulatory Horizon Item", "Regulatory Initiative", "FCA", "Example 'Consumer Composite Investments (CCI) regime' (FCA) removed; example SEC Regulation S-P amendments."),
    _j("Regulatory Horizon Item", "Market Impact Assessment", "FCA", "Example on UK platform fee comparisons removed."),
    # Code list descriptions re-sourced (review J; no value removed)
    _j("Code list: Flow Estimation Method", "Reported by Funds (description)", "EU market practice", "Description 'EFAMA, IA' removed; ICI monthly only."),
    _j("Code list: Peer Universe Type", "Vendor Category (description)", "UK market practice", "Description 'IA Sector' removed."),
    _j("Code list: Rating Scheme", "Other Third-Party Rating (description)", "UK market practice", "Description 'UK fund research agency ratings' removed; now any third-party rating cited under the SEC Marketing Rule."),
    _j("Code list: Industry Dataset Family", "(descriptions)", "Other EU/UK", "EFAMA, IA, FE fundinfo and Citywire removed from the Industry Flow Statistics and Ratings Data descriptions."),
    # Sources
    _j("Sources", "EFAMA Monthly Investment Fund Industry Fact Sheet / Quarterly Statistical Release", "EU market practice", "Replaced by ICI statistics and the ICI Fact Book."),
    _j("Sources", "Investment Association monthly fund statistics", "UK market practice", "UK authorized funds statistics; no US counterpart needed beyond ICI."),
    _j("Sources", "FE fundinfo Crown Fund Ratings methodology", "UK market practice", "Rating scheme removed."),
    _j("Sources", "Citywire Fund Manager Ratings", "UK market practice", "Manager Rating removed."),
    _j("Sources", "UK FCA COLL 6.6.20R Assessment of Value and Consumer Duty", "FCA",
       "Assessment of Value (FCA COLL) and the Consumer Duty value assessment; the US fee review basis is Investment Company Act "
       "Section 15(c) (source added)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. REPOINTS: (object, attribute, before, after, decision)
# ---------------------------------------------------------------------------------------------------------------------
REPOINTS = [
    # Structure
    ("Record Metadata", "", "Governance metadata object (10 attributes)", "dropped (CD-160); Source Vendor Dataset and Redistribution Permitted Indicator re-cut into Redistribution Restriction (AG of Industry Dataset Profile, family Data Sourcing Controls, MI-SRC replaces MI-DMM)", "CW-160"),
    ("Industry Ranking", "", "Business Object", "Attribute Group of Market Share Record (brief section 5)", "CW-160"),
    ("Peer Metric Snapshot", "", "Attribute Group of Peer Fund", "Business Object with Snapshot Subject (peer fund or own share class) added as its key part", "CW-160"),
    ("Regulatory Horizon Item", "", "Business Object", "Attribute Group of Intelligence Item; Initiative Source Type added", "CW-160"),
    ("Competitor Offering / Competitor Pricing Observation", "", "(none)", "added to MI-CMP (COFF-; composite key COFF- / Price Component / Observation As-of Date)", "CW-160"),
    ("Family names", "", "Industry Flow & AUM Data; Ratings, Rankings & Awards; Fee Benchmarking; Market Sizing & Opportunity Potential; Market Structure Research; Win/Loss & Mandate Search Intelligence; Data Management Metadata",
     "Industry Flow & Asset Data; Ratings & Awards; Fee & Price Benchmarking; Market Sizing; Market Research & Trends; Institutional Search & Win/Loss; Data Sourcing Controls (codes kept except MI-DMM -> MI-SRC)", "CW-160"),
    # 05 restored objects (CW-132, CW-134, CW-170)
    ("Industry Flow Observation", "Distributor Firm", "Reference (Party), 02", "Reference (Distributor Firm, 05) (override 05; PTY- example kept)", "CW-132"),
    ("Market Share Record", "Distributor Firm", "Reference (Party), 02", "Reference (Distributor Firm, 05)", "CW-132"),
    ("Competitor Distribution Footprint", "Key Distribution Partners", "Reference (Party) (multi), 02", "Reference (Distributor Firm, 05) (multi)", "CW-132"),
    ("Mandate Search Event", "Consultant", "Reference (Party), 02", "Reference (Consultant Profile, 05)", "CW-132"),
    ("Mandate Search Event", "Linked Opportunity", "Reference (Opportunity), 03 Sales OPP-", "Reference (Sales Opportunity, 05) (override 05; OPP- still registered to 03 in decisions.PREFIXES)", "CW-170"),
    ("Win/Loss Analysis", "Opportunities Decided; Top Loss Reasons", "03 opportunity outcomes and Win Loss Reason list", "05 Win / Loss and Win Loss Reason list", "CW-134"),
    ("REL", "", "Mandate Search Event / Win/Loss Analysis -> Sales Opportunity (03 Sales: OPP-)", "-> Sales Opportunity (05 Intermediary & Institutional Distribution: OPP-); Mandate Search Event -> Consultant Profile (05) added", "CW-170"),
    # 07 retirement (CW-907; W4 retirement brief section 5)
    ("REL", "", "Market Sizing Record feeds Territory Potential Metric (07 Comp & Territory: TER-)", "removed", "CW-907"),
    ("META / MI-MSZ definition", "", "'07 holds the territory-level values ... references these records'; scope and next steps naming 07 TER-/GOL- and the MSZ- to 07 interface", "removed; sizing is read by 36 and 10", "CW-907"),
    # Fees (CW-158, CW-160)
    ("Fee Benchmark Study", "Subject Share Class", "Reference (Share Class), CDE", "kept by name for DP-109 and DP-183; Subject Service Offering (01 OFFR-) and Subject Fee Schedule (47 CLFEE-) added; Comparison Offerings (COFF-) added", "CW-160"),
    ("Fee Benchmark Result", "Own Fee Rate", "Derived copy of 01", "Derived copy of 01 (share class) or 47 (fee schedule), ROW_OWNERSHIP rule", "CW-158"),
    ("Code list: Fee Measure", "All-In Cost Including Platform", "All-In Cost Including Platform", "All-In Program Cost; Advisory Fee Rate, Commission per Trade and Account Service Fee added", "CW-160"),
    ("Code list: Fee Study Purpose", "", "(none)", "Advice Program Pricing Review added", "CW-160"),
    # Competitors (CW-160)
    ("Competitor Profile", "Headquarters Country", "Code ISO 3166, Derived 02", "removed (read from the 02 party; US only)", "CW-160"),
    ("Competitor Metric Snapshot", "", "As-of Date, Total AUM, Trailing 12-Month Net Flows, Asset-Weighted Expense Ratio", "adds Reported Client Assets, Reported Net New Assets, Client Account Count, Advisor Count", "CW-160"),
    ("Competitor Distribution Footprint", "Estimated Wholesaler Headcount", "Estimated Wholesaler Headcount", "Estimated Advisor Headcount", "CW-160"),
    ("Code list: Competitor Type", "", "Active Multi-Asset Manager; Passive / ETF Specialist; Boutique / Specialist; Insurer-Owned Manager; Bank-Owned Manager; Private Markets Manager; Multi-Boutique / Affiliate Model; Model Portfolio / TAMP Provider",
     "Direct Brokerage; Robo-Adviser; Hybrid Advice Firm; Wirehouse; Independent RIA Aggregator; Workplace Recordkeeper; Fund and ETF Sponsor; Bank Wealth Manager; Trust Company; OCIO Provider; Other", "CW-160"),
    ("Code list: Competitor Event Type", "", "(wholesale 11 values)", "adds Pricing Change, Program Launch, Feature Launch, Cash Yield Change", "CW-160"),
    ("Code list: Personnel Role", "Senior Wholesaler / Key Account", "Senior Wholesaler / Key Account", "removed; Head of Wealth / Advice and Head of Digital added", "CW-013"),
    ("Code list: Industry Channel", "", "15 Cerulli-style wholesale channel values", "20 CW-164 / CW-140 values (see SHARED_MEMBERSHIPS)", "CW-164"),
    # Peers and ratings
    ("Code list: Rated Object Type", "Fund Manager", "Fund Manager", "Service Offering (Manager Rating removed)", "CW-911"),
    ("Rating Scheme", "Peer Group Basis", "Text", "removed (held per observation in Rating Peer Group)", "CW-160"),
    ("Award", "Recipient", "Reference (Share Class / Peer Fund / Competitor Profile / Party)", "Reference (Share Class / Service Offering / Peer Fund / Competitor Profile); manager party removed with Manager Rating", "CW-160"),
    ("Fee Benchmark Result", "Asset-Weighted Peer Average Fee", "Percentage", "removed (median and quartile boundaries kept)", "CW-160"),
    # Sizing (CW-139, CW-160)
    ("Market Sizing Record", "", "(none)", "Wealth Band, Age Band, Mapped Firm Segment added; Projection Indicator removed", "CW-160"),
    ("Code list: Sizing Subject Type", "Branch / Office; Advisor / Team; DCIO Market", "wholesale values", "removed; Investor Segment, Wealth Band, Age Band, Workplace Participant Market added", "CW-139"),
    ("Code list: Sizing Metric", "Producing Advisor Count; Addressable Gross Sales; DCIO Addressable Assets", "wholesale values", "removed; household, advice, participant and IRA rollover metrics added", "CW-139"),
    ("Opportunity Potential", "Practice AUM Input; Potential Score", "Amount (Derived 02); Integer", "removed (thin IC, CW-013; practice assets are 05 profile facts)", "CW-013"),
    ("Opportunity Potential", "Firm Assets with Party", "own assets attributed to the party (06 attribution)", "own-fund assets held through the party, Derived copy of the 06 intermediary-held measure", "CW-011"),
    ("Plan Market Record", "DCIO Opportunity Value", "DCIO Opportunity Value", "Recordkeeping Opportunity Value (plan sponsor prospect, WR); Participant Count added", "CW-139"),
    # Other
    ("Market Share Definition", "Numerator Source", "value '06 Attributed Flows / AUM'", "value '06 Certified Measure' (CW-011 Client Assets, Net New Assets, fund flows)", "CW-160"),
    ("Code list: Share Measure Basis", "", "(none)", "Net New Assets and Client Count added", "CW-160"),
    ("Code list: Regulatory Stage", "Discussion / Call for Input; Consultation; Final Rules Published", "UK/EU stage names", "Concept Release / Request for Comment; Proposed Rule; Final Rule Adopted; Stayed / In Litigation added", "CW-911"),
    ("Code list: Regulatory Body", "US SEC; US DOL", "US SEC; US DOL", "SEC; DOL / EBSA (shared Regulator labels) and seven US values added", "CW-911"),
    ("Intelligence Item", "Source Name", "Text (example Citywire)", "removed (Source Type kept)", "CW-160"),
    ("Code list: Market Topic", "Retirement / DCIO", "Retirement / DCIO", "Retirement / Rollovers; Digital Advice, Hybrid Advice, Cash and Sweep Yields, Direct Indexing, Wealth Transfer added", "CW-139"),
    # Fix pass (00_Program/Rework/Reviews/11_review.md; program-lead rulings 2026-10-15)
    ("Regulatory Horizon Item", "", "Attribute Group of Intelligence Item (draft)", "Business Object, regulator x initiative; Source Intelligence Items (multi) added", "CW-160"),
    ("Peer Metric Snapshot", "Expense Ratio; Total Return; Estimated Net Flow", "mastered here on every row", "row rules: own share class rows copy 01 Net Expense Ratio and 32 Performance Return; Estimated Net Flow is the vendor estimate", "CW-160"),
    ("Fee Benchmark Result / Pricing Input", "fee statistics", "Percentage", "Decimal in Fee Benchmark Study.Measure Unit (Percent, Basis Points, Currency Amount); Reference Balance added", "CW-160"),
    ("Competitor Pricing Observation", "Balance Tier", "Text range, optional", "Balance Tier Lower Bound (Amount), key part when tiered (CDE)", "CW-160"),
    ("Competitor Profile", "Vendor Manager Identifiers", "vendor codes and CRD / SEC numbers, Derived 02", "vendor codes only, mastered here under the 14 license; Regulatory Identifiers (Derived 02) added", "CW-160"),
    ("Market Sizing Record", "Wealth Band; Mapped Firm Segment", "11 bands to USD 25m+; segment value without scheme", "02 Net Worth Band boundaries; value written '<02 Segmentation Scheme>: <segment>'", "CW-160"),
    ("Market Sizing Record", "Sizing Unit", "Code", "removed (unit implied by Sizing Metric)", "CW-160"),
    ("Rating Scheme", "Rating Basis", "Code", "removed (implied by the scheme)", "CW-160"),
    ("Industry Ranking", "Ranking Basis", "Code", "removed (the parent share record's basis)", "CW-160"),
    ("Redistribution Restriction", "Source Vendor Dataset", "Reference (Dataset)", "removed (equals the parent key)", "CD-160"),
    ("Industry Dataset Profile", "Reinvested Distribution Treatment", "Code (Reinvestment Treatment)", "Boolean (name kept for DP-014)", "CW-160"),
    ("Opportunity Potential", "Target Party", "intermediary firm or advisor (conditional PII)", "intermediary firm only (05 Distributor Firm role), No PII", "CW-013"),
    ("Plan Market Record", "Plan Party", "Reference (Party)", "Reference (Retirement Plan)", "CW-021"),
    ("Code lists", "Age Band; Rating Value; Medalist Pillar Score; Lipper Leaders Measure; Rating Time Period; Search Event Type", "local lists", "External (owner scale: SCF, Morningstar, LSEG Lipper, Nasdaq eVestment)", "CW-160"),
    ("Code list: Competitor Offering Type", "", "(none)", "Institutional / OCIO added", "CW-160"),
    ("Code list: Industry Dataset Family", "", "(wholesale values)", "Household Wealth Statistics and Competitor Pricing Data added; EFAMA, IA, FE fundinfo, Citywire removed from descriptions", "CW-160"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 8. DECISIONS: the US-only pass of 11 (pre-allocated in proposals_w4_economics.py; this entry supersedes that draft text)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-911", "theme": "Scope", "title": "US-only pass of 11 Market & Competitive Intelligence",
     "domains": ["11", "14", "09", "05", "01", "06", "47"],
     "issue": "The wholesale 11 tracked fund-manager competitors in intermediary channels across the US and Europe: EU and UK "
              "trade-association data (EFAMA, Investment Association), UK ratings (FE fundinfo Crowns, Citywire manager ratings), "
              "UCITS and AIF vehicles, UK and EU channels, EU/UK regulators in horizon scanning, the UK Ongoing Charges Figure, the "
              "PRIIPs cost figure and the FCA Assessment of Value.",
     "resolution": "Removed (71 JURISDICTION entries: 1 object, 1 attribute, 36 code values, 24 re-sourced references and "
                   "examples, 4 code-list description re-sourcings, 5 sources): object Manager Rating (Rated Manager, Manager Rating Value, Rated Sector, Manager Rating "
                   "Date); attribute Competitor Distribution Footprint.Market; Industry Data Provider EFAMA, Investment Association, "
                   "FE fundinfo, Citywire; Category Scheme EFAMA EFC, IA Sector; Industry Vehicle Type UCITS, AIF; Industry Channel "
                   "UK Platform, UK IFA / Wealth Manager / DFM, EU Private Bank, EU Retail Bank Network, EU Fund Platform; Regulatory "
                   "Body UK FCA, ESMA, European Commission, CSSF, Central Bank of Ireland, BaFin; Rating Scheme FE fundinfo Crown "
                   "Rating, Citywire Manager Rating; Rating Value 1-5 Crowns and AAA, AA, A, +; Fee Measure Ongoing Charges Figure and "
                   "PRIIPs Total Costs; Fee Study Purpose Assessment of Value; Coverage Basis Country of Sale; Sizing Unit EUR, GBP; "
                   "sources EFAMA, Investment Association, FE fundinfo, Citywire, FCA COLL 6.6.20R and Consumer Duty. "
                   "Kept and re-sourced: Industry Dataset Profile, Data Release and Flow Observation references to ICI, Morningstar, "
                   "LSEG Lipper and ISS Market Intelligence; Coverage Basis to Fund Domicile, Distributor Reported, Investor "
                   "Residence, Filer Reported; Rating Scheme and Rating Value secondary references to LSEG Lipper; Fee Measure "
                   "Compared to SEC Form N-1A; Study Purpose to Investment Company Act Section 15(c) (source added); Paid to "
                   "Participate Indicator to SEC Marketing Rule 206(4)-1 only; Regulatory Body to the shared Regulator US labels; "
                   "Regulatory Stage to US rulemaking stages; examples LU, GB, DE, EUR, EAA, Investment Week, Citywire and the FCA "
                   "CCI regime replaced by US examples. Morningstar Global Category, Lipper Global Classification, Peer Fund ISIN "
                   "and Domicile stay (peers of the firm's international funds). Also dropped (not jurisdiction): Record Metadata "
                   "(CD-160; its GDPR secondary reference on Data Classification goes with it) and the DCAM source. "
                   "Perspective: META subtitle 'Wealth manager (direct) | Scope: US'; overview rewritten for the direct wealth "
                   "manager (CW-013, CW-160). Counts (built, after the fix pass): 10 to 11 families, 34 to 36 objects (8 to 9 attribute "
                   "groups), 239 to 260 attributes, 80 to 91 CDEs (35%), 50 to 52 code lists, 33 to 47 relationships, 23 to 24 "
                   "sources.",
     "rationale": "CW-003 and CW-022: the firm is regulated and distributes in the US only, so EU and UK market statistics, "
                  "ratings, vehicles, channels, regulators and value assessments have nothing to serve; the investment universe is "
                  "not narrowed, so international peers keep their foreign domicile, ISIN and global categories. Lever: the UK "
                  "extension restores the removed rows from wholesale-v1.0 through the jurisdiction register.",
     "action": "W4", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 9. NOTES for the W4 merge
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "READERS OF REMOVED, RENAMED OR RE-TYPED 11 CONTENT (lines as of 2026-10-15). Live products resolve unchanged: DP-014 "
    "(specs_b_foundational.py 571-633; every column kept, including Competitor Display Name, Morningstar SecId and Peer Universe "
    "Member.Manual Override Indicator, which were kept for it; EFAMA and IA inputs drop with the values), DP-105, DP-109 "
    "(specs_e3_private_markets_product_range.py 1198, Fee Benchmark Study.Subject Share Class kept), DP-159, DP-183 "
    "(specs_e3_ta_fund_governance.py 874 and 922, Subject Share Class kept), DP-223, DP-236, DP-248. Checked by script against "
    "every ('11', object, attribute) read in data_products/specs_*.py.",
    "READERS (pending products, CW-041; they lose columns at WP0). DP-018 specs_c_sales.py 407-408 and DP-049 "
    "specs_g_advisor_analytics.py 329-330: Opportunity Potential.Practice AUM Input and Potential Score (removed). DP-024 "
    "specs_c_sales.py 965-966, 989 and DP-066 specs_h_planning_partners.py 576-577, 593: Plan Market Record.DCIO Opportunity Value "
    "(renamed Recordkeeping Opportunity Value, CW-139). DP-030 specs_d_marketing_product.py 550-553, 568, 575, 610: Manager Rating "
    "(removed, CW-911) and Rating Scheme.Peer Group Basis (removed); its Rated Manager Count metric and the PII note on Manager "
    "Rating go (brief: drop). DP-031 specs_d_marketing_product.py 676: Market Sizing Record.Projection Indicator (removed). DP-059 "
    "specs_i_product_data.py 183: Fee Benchmark Result.Asset-Weighted Peer Average Fee (removed). DP-088 "
    "specs_p_inst_intel_finance.py 195, 203-208: Competitor Distribution Footprint.Market (removed, CW-911) and Estimated "
    "Wholesaler Headcount (renamed Estimated Advisor Headcount), Competitor Profile.Headquarters Country (removed), Intelligence "
    "Item.Source Name (removed).",
    "READERS (logical models and keys). models_c2_marketing_product.py 489, 534 (Fact Manager Rating: drop) and 576 (Fact Industry "
    "Ranking keyed Ranking Basis / Ranking Universe / Ranked Firm: now an attribute group of Market Share Record, key MSH- / Ranked "
    "Firm); models_c1_sales.py 1038 (Fact Mandate Search Event -> Fact Search Opportunity on Linked Opportunity: target becomes "
    "05 Sales Opportunity) and 1137 (DCIO Opportunity Value note); models_c6_planning_finance.py 672-733 (Fact DCIO Opportunity: "
    "rename with CW-139); models_c9_events_inst_intel.py 764, 821 (Key Distribution Partners: resolves to 05 Distributor Firm); "
    "models_f3.py 658-724 and models_e8c_invops_b.py 288 (Peer Metric Snapshot: now a business object with Snapshot Subject; "
    "the fk 'Peer Fund Key' maps to Snapshot Subject); models_c8_compliance2.py 603, models_e8c_cross_area.py 1150, "
    "models_e8c_compliance_legal.py 169 and 196 (Regulatory Horizon Item: unchanged, regulator x initiative). keys_g5_11_12_13_14.py (superseded at WP2): 45 and 285 Industry Ranking key, 48 and 288 "
    "Manager Rating (drop), 60 Peer Metric Snapshot (_child -> composite Snapshot Subject / Snapshot Date / Return Period / Peer "
    "Universe), 69 Regulatory Horizon Item (composite key kept: it stays a business object), 266 Key Distribution Partners (DISTRIBUTOR "
    "becomes ('05', 'Distributor Firm') per CW-132), 293 Mandate Search Event.Linked Opportunity ('03' -> '05', 'Sales "
    "Opportunity'). keys_e7_37_38.py 352 (38 Source Horizon Item -> 11 Regulatory Horizon Item) resolves unchanged.",
    "READERS (semantic models). sm_06_product_market.py 220-223 (manager_rating entity of DP-030: drop) and 268 "
    "(asset_class_category: kept); sm_04_institutional_retirement.py 243 (dcio_opportunity_value: rename to "
    "recordkeeping_opportunity_value with DP-024); sm_04 176 and sm_06 153 (Competitor Display Name: kept).",
    "07 AND 30 REFERENCES (W4 retirement brief section 5). Removed: REL 'Market Sizing Record feeds Territory Potential Metric (07 "
    "Comp & Territory: TER-)'; the 07 text in the MI-MSZ family definition, the META Scope (07 TER-/GOL-), Core model ('feed 07 "
    "territory potential') and Suggested next steps (MSZ- to 07 interface). No 30 reference existed; Competitor Type 'Private "
    "Markets Manager' left with the re-cut; Market Topic 'Private Markets in Wealth' is a market topic (retail access to private "
    "markets) and stays.",
    "DEVIATIONS FROM THE BRIEF. (1) Fee Benchmark Study keeps 'Subject Share Class' (read by live DP-109 and DP-183) and adds "
    "'Subject Service Offering' and 'Subject Fee Schedule' instead of renaming it to 'Subject'. (2) Competitor Offering carries no "
    "separate delivery mode or launch date: the delivery mode is in Competitor Offering Type (Self-Directed Brokerage, Digital, "
    "Hybrid, Human Advice) and launches are Competitor Events of type Program Launch, to stay inside the 260-attribute band. (3) "
    "Asset Owner on Mandate Search Event stays Reference (Party): the asset owner of a search need not be a client, so it is not "
    "re-pointed to 12 Institutional Client (proposals_w4_channels READERS lists it under INST_CLIENT; program lead to rule). (4) "
    "Opportunity Potential.Target Party stays Reference (Party) (brief: '02 party with a 05 role'). (5) The brief's proposals file "
    "name proposals_11.py is proposals_w4_11.py. (6) Fix-pass ruling 4: Regulatory Horizon Item stays a business object at "
    "regulator x initiative grain (brief section 5 made it an attribute group of Intelligence Item), because keys_g5 line 69, "
    "models_e8c_cross_area line 1151 and models_c8_compliance2 line 603 key it that way and 38 Source Horizon Item must point "
    "at one record per initiative; Source Intelligence Items (multi) links the news items. The object is then 27 business "
    "objects and 9 attribute groups. (7) Competitor Offering has no channel attribute (CW-160 names one): it does not fit "
    "within 260 attributes. Lever: add 'Offering Channel' (Industry Channel) for TR and IA offerings sold through "
    "intermediaries; until then the channel is read from Competitor Distribution Footprint (competitor x channel).",
    "READERS ADDED IN THE FIX PASS. Peer Metric Snapshot (keyed 'Peer Fund Key' by readers; now Snapshot Subject): "
    "models_c2_marketing_product.py 471-472 and 513 (Fact Peer Position); sm_06_product_market.py 182, 200 and 875 "
    "(peer_position.peer_fund); sm_08_investment_book_performance.py 390-412 and 902 (DP-159 peer_snapshot.peer_fund_key). "
    "Industry Ranking (now an attribute group; Ranking Basis removed): sm_06 255 (DP-031 industry_ranking); models_c2 644 and "
    "sm_06 1797 (GAP-11-014 'no period': closed by the parent Market Share Record.Period End Date). keys_g5_11_12_13_14.py: "
    "28 Competitor Distribution Footprint _child(['Channel', 'Market']) becomes _child(['Channel']) (Market removed, CW-911); "
    "289 Mandate Search Event.Asset Owner INST_CLIENT becomes PARTY (12 ruling); 290 Mandate Search Event.Consultant PARTY "
    "becomes ('05', 'Consultant Profile'); new rows ('11', 'Competitor Offering'): _k(['Competitor Offering ID'], 'Natural', "
    "COFF-); ('11', 'Competitor Pricing Observation'): _k(['Priced Offering', 'Price Component', 'Observation As-of Date', "
    "'Balance Tier Lower Bound'], 'Composite'); ('11', 'Redistribution Restriction'): _child of Industry Dataset Profile. "
    "Removed in the fix pass (pending readers only): Industry Ranking.Ranking Basis (DP-031), Rating Scheme.Rating Basis "
    "(DP-030), Market Sizing Record.Sizing Unit (DP-031), Redistribution Restriction.Source Vendor Dataset (none). Kept for "
    "DP-014 with a new type: Industry Dataset Profile.Reinvested Distribution Treatment (Code -> Boolean; list Reinvestment "
    "Treatment dropped).",
    "LEVER (fix-pass ruling 7). Price capture is monthly from public schedules, plus event-triggered capture: a Competitor Event "
    "of type 'Cash Yield Change' (or 'Pricing Change') triggers a new Competitor Pricing Observation of the affected offering "
    "the same day, because cash sweep yields move with rate changes between monthly runs.",
    "OWNERSHIP OVERRIDES (corrected in the fix pass). ownership.resolve reads the ID prefix of the example first, so the four "
    "PTY-keyed 05 overrides (Industry Flow Observation.Distributor Firm, Market Share Record.Distributor Firm, Competitor "
    "Distribution Footprint.Key Distribution Partners, Mandate Search Event.Consultant) are permanent, as in the 05 module's own "
    "readers. Only four become redundant: Linked Opportunity when OPP- moves to 05 (CW-134), Subject Fee Schedule when CLFEE- is "
    "registered to 47, and Priced Offering and Comparison Offerings when COFF- is registered to 11.",
    "FOR OTHER DOMAINS (not edited). 05: Win / Loss and Win Loss Reason are read by Win/Loss Analysis; Consultant Profile and "
    "Sales Opportunity names are assumed from the 05 brief. 06: the intermediary-held own-fund measure read by Opportunity "
    "Potential.Firm Assets with Party and the MSR- measures read by Market Share Record.Firm Value are assumed from the 06 brief. "
    "The 05 module now exists: Distributor Firm and Consultant Profile are PTY-keyed, Sales Opportunity is OPP-; 05 Win / "
    "Loss.Winning Competitor (content_05 line 526) is Reference (Party) while 11 aggregates by Competitor Profile, so the 11 "
    "Most Frequent Winning Competitor needs a party-to-profile lookup: propose that 05 type it Reference (Competitor Profile, 11). "
    "10 and 36: the example keys 'COFF-00213 / Advisory Fee / 2026-09-30' in content_10 line 386 (Pricing Scenario.Competitor "
    "Pricing Evidence) and content_36 line 90 (Evidence Competitor Pricing Observation) should read 'COFF-00213 / Advisory Fee "
    "Rate / 2026-09-30' and, for a tiered price, add '/ USD 1,000,000' (KEY_FORMATS above); for their owners at merge. 38: "
    "Regulatory Change Item.Source Horizon Item resolves to the Regulatory Horizon Item, which stays a business object at "
    "regulator x initiative grain. 06: content_06 line 561 Measure Category value 'Market Share' invites a second share measure; "
    "market share is mastered only in 11 (drop the value or define it as 'a 06 input to 11'). 14: Data Provider gains "
    "FEDERAL_RESERVE (proposed).",
]
