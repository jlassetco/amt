"""Consolidation proposals from the W4 draft of Data Domain 12 Institutional Client Servicing & Reporting (wealth manager), 2026-10-14.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py,
shared_code_lists.py and jurisdiction.REMOVALS at the W4 merge. Formats follow CONTRACT.md in this folder. The brief is
00_Program/Rework/Briefs/12_Institutional_Client_Servicing_and_Reporting.md (Disposition: Adapt, CW-145; the brief names the
file proposals_12.py, the W4 assignment names it proposals_w4_12.py). It implements CW-003, CW-005, CW-012, CW-022, CW-023,
CW-054, CW-093, CW-133, CW-138, CW-145 to CW-151 (proposals_w4_channels.py) and drafts CW-912, the US-only pass of 12 including
the EU/UK example values of the billing objects moved to 47 (proposals_w2_47.py CW912_ITEMS). Module:
content_12_institutional_client_servicing_and_reporting.py (edited in place; output path and folder unchanged).
"""

_D, _C = "12", "CW-912"

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES: none beyond IPSV-, which proposals_w4_channels.py reserves (CW-148). Institutional Client is keyed by its PTY-
#    and Mandate Onboarding by '<MND- id> / <onboarding start date>' (GRAIN_KEY_FORMATS of proposals_w4_channels.py).
#    CFS- retires (CW-145); BLA-, BIL-, BDP- transfer to 47 (CW-054). SVT- format example SVT-INST-02 is used.
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED MEMBERSHIPS (local name -> shared list; value_map local label -> shared code)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Business Line", "local": "Business Line",
     "value_map": {c: c for c in ("DB", "DA", "HA", "PF", "WR", "IA", "IC", "TR")}, "new_values": [],
     "note": "New member (CW-004, CW-140). Institutional Client.Primary Business Line, Service Relationship.Relationship Business "
             "Line, Service Team.Service Team Business Line. Two-letter codes as values, as 02, 13 and 15."},
    {"shared": "Performance Fee Basis", "local": "Fee Basis",
     "value_map": {"Gross of Fees": "GROSS_OF_FEES", "Net of Fees": "NET_OF_FEES", "Gross and Net": "GROSS_AND_NET"},
     "new_values": [],
     "note": "Kept membership, values unchanged (Presentation Profile.Fee Basis Shown, which did not move). STEWARD RULED 32 "
             "Performance & Attribution (program lead, 12 fix pass), replacing CW-054 / CW-140's 47. At merge: set steward '32' and "
             "move 32 from direct_users to steward; rewrite the definition (shared_code_lists.py line 1599, 'steward 12 as owner of "
             "performance reporting presentation reference') to 'Basis on which a return is computed or shown (GIPS 2020 gross-of-fees "
             "and net-of-fees); steward 32 as master of returns'; members ('12', 'Fee Basis') and ('47', 'Performance Fee Basis') "
             "(Performance Fee Calculation.Performance Measurement Basis); the wholesale ('03', 'Performance Basis') member goes with "
             "the replaced 03."},
    {"shared": "Frequency", "local": "Frequency",
     "value_map": {"Daily": "DAILY", "Weekly": "WEEKLY", "Monthly": "MONTHLY", "Quarterly": "QUARTERLY", "Semi-Annual": "SEMI_ANNUAL",
                   "Annual": "ANNUAL", "Ad Hoc": "AD_HOC", "On Event": "ON_EVENT"},
     "new_values": [], "note": "Kept membership, unchanged. New users: IPS Review Frequency, Plan Review Cadence."},
    {"shared": "Delivery Method", "local": "Delivery Channel",
     "value_map": {"Client Portal": "PORTAL", "Email": "EMAIL", "Secure Email": "EMAIL_SECURE", "SFTP": "SFTP_FILE", "API": "API",
                   "Consultant Database Feed": "CONSULTANT_DATABASE_FEED", "Post": "PAPER_MAIL", "Data Vendor Platform": "DATA_VENDOR"},
     "new_values": [], "note": "Kept membership, unchanged."},
    {"shared": "Delivery Status", "local": "Delivery Status",
     "value_map": {"Pending": "PENDING", "Delivered": "DELIVERED", "Opened": "OPENED", "Failed": "FAILED", "Recalled": "RECALLED"},
     "new_values": [], "note": "Kept membership, unchanged."},
    {"shared": "RAG Status", "local": "RAG Status", "value_map": {"Green": "GREEN", "Amber": "AMBER", "Red": "RED"},
     "new_values": [], "note": "Kept membership, unchanged."},
    {"shared": "Case Status", "local": "Request Status",
     "value_map": {"New": "NEW", "In Progress": "IN_PROGRESS", "Waiting on Client": "WAITING_ON_CLIENT", "Escalated": "ESCALATED",
                   "Resolved": "RESOLVED", "Closed": "CLOSED", "Canceled": "CANCELED"},
     "new_values": [], "note": "Kept membership, unchanged. Billing Dispute.Dispute Status, the other 12 user, moved to 47 (47 uses a "
                               "local 'Case Status')."},
    {"shared": "Flow Direction", "local": "Flow Direction", "value_map": {"Contribution": "INFLOW", "Withdrawal": "OUTFLOW"},
     "new_values": [], "note": "Kept membership, unchanged."},
    {"shared": "Reporting Period Basis", "local": "Return Period",
     "value_map": {"MTD": "MTD", "QTD": "QTD", "YTD": "YTD", "1Y": "TRAILING_1Y", "3Y": "TRAILING_3Y", "5Y": "TRAILING_5Y",
                   "10Y": "TRAILING_10Y", "Since Inception": "SINCE_INCEPTION", "Calendar Years": "CALENDAR_YEARS"},
     "new_values": [], "note": "Kept membership, unchanged."},
    {"shared": "SLA Unit", "local": "SLA Unit",
     "value_map": {"Business Days After Period End": "BUSINESS_DAYS_AFTER_PERIOD_END", "Business Hours": "BUSINESS_HOURS",
                   "Business Days": "BUSINESS_DAYS", "Calendar Days": "CALENDAR_DAYS", "Percent": "PERCENT"},
     "new_values": [], "note": "Kept membership, unchanged."},
    {"shared": "Return Methodology", "local": "Return Methodology",
     "value_map": {"Time-Weighted": "TIME_WEIGHTED", "Money-Weighted (IRR)": "MONEY_WEIGHTED_IRR", "Both": "BOTH"},
     "new_values": [], "note": "Kept membership (12 steward), unchanged."},
    {"shared": "Net Fee Treatment", "local": "Net Fee Treatment",
     "value_map": {"Actual Fees": "ACTUAL_FEES", "Model Fees": "MODEL_FEES", "Highest Fee": "HIGHEST_FEE"},
     "new_values": [], "note": "Kept membership (12 steward), unchanged."},
    {"shared": "Breach Type", "local": "Breach Type",
     "value_map": {"Active": "ACTIVE", "Passive": "PASSIVE", "Technical": "TECHNICAL"},
     "new_values": [], "note": "Kept membership, unchanged (Derived copy of 33, CD-222)."},
    {"shared": "Cure Action", "local": "Cure Action",
     "value_map": {"Sell Down": "SELL_DOWN", "Purchase": "PURCHASE", "Client Waiver": "CLIENT_WAIVER",
                   "Guideline Amended": "GUIDELINE_AMENDED", "Self-Cured by Market": "SELF_CURED_BY_MARKET"},
     "new_values": [], "note": "Kept membership, unchanged."},
    # Memberships to remove at merge
    {"shared": "Data Quality Status", "local": "", "value_map": {}, "new_values": [],
     "note": "REMOVE ('12', 'Data Quality Status') from the members (shared_code_lists.py line 108) and its value map (line 122): "
             "Record Metadata dropped (CD-160)."},
    {"shared": "Information Classification", "local": "", "value_map": {}, "new_values": [],
     "note": "REMOVE ('12', 'Confidentiality Classification') from the members (shared_code_lists.py line 693) and its value map "
             "(line 714): Record Metadata dropped (CD-160)."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED CANDIDATES
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Institutional Client Type", ["12", "05", "06", "11"],
     "12 masters it on the restored profile; 05 consultant client segments, 06 Market & Client Dimensions and 11 Mandate Search "
     "Event asset owner types read the same categories (aligned to Form ADV Item 5.D). Candidate shared list, steward 12."),
    ("ERISA Fiduciary Status", ["12", "16", "46"],
     "12 OCIO Service Detail, 16 plan fiduciary roles (3(38) / 3(21) adviser type on Retirement Plan Profile and Plan Managed Account "
     "Service) and 46 managed account fiduciary role use the same three values. Candidate shared list, steward 16."),
    ("Service Role", ["12", "03", "05"],
     "Three coverage records (CW-138) with three role lists; keep separate values but one 'Coverage Role' pattern at W5."),
    ("Client Review Type", ["12", "45", "08"],
     "Review kinds differ by domain (term conflict Review); keep local."),
    ("Spending Policy Method", ["12", "51"],
     "51 trust distribution standards (unitrust percentage) overlap the endowment spending methods; check at W5."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (decisions.TERM_CONFLICTS format), from the brief section 13 and CW-149
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Client",
     "usages": [("02", "Party Role 'Client' (CW-005)", "Holds or applies for an account."),
                ("12", "Institutional Client", "Role profile of an institutional asset owner or plan sponsor, keyed by PTY-.")],
     "recommendation": "Always 'Institutional Client' for the 12 profile; bare 'client' is the 02 role. 12 Service Relationship.Client "
                       "keeps its attribute name and is typed Reference (Institutional Client, 12).",
     "resolution": "Profile here, party core in 02.", "status": "Resolved", "decision": "CW-133"},
    {"term": "Tier",
     "usages": [("01", "Service Tier", "Retail service tier (CW-028)."), ("12", "Institutional Service Tier", "Institutional servicing tier."),
                ("05", "Partner Tier", "Partner program tier.")],
     "recommendation": "12 object renamed Institutional Service Tier; its attribute Service Tier Code and Service Relationship.Service "
                       "Tier keep their names (readers) and their definitions say 'institutional service tier'.",
     "resolution": "Renamed (CW-145).", "status": "Resolved", "decision": "CW-149"},
    {"term": "Review",
     "usages": [("12", "Client Review", "Governance review with an institutional client or plan committee."),
                ("45", "Advice Review", "Retail advice review."), ("08", "Supervisory Review / Compliance Review", "Supervision."),
                ("52", "Oversight Review", "Manager oversight.")],
     "recommendation": "Never bare 'Review'.", "resolution": "Distinct objects.", "status": "Resolved", "decision": "CW-149"},
    {"term": "Coverage",
     "usages": [("03", "Party Coverage Assignment", "Relationship manager of record."), ("05", "Partner Coverage Assignment", "Partner coverage."),
                ("12", "Service Coverage Assignment", "Servicing roles.")],
     "recommendation": "12 holds servicing roles only; Service Role no longer has 'Relationship Manager' or 'Billing Analyst'.",
     "resolution": "CW-138.", "status": "Resolved", "decision": "CW-138"},
    {"term": "Feed",
     "usages": [("12", "Client Data Feed", "Outbound."), ("06", "Data Feed", "Inbound."), ("05", "Partner Data Feed Arrangement", ""),
                ("14", "Dataset Delivery", "")],
     "recommendation": "Qualified everywhere.", "resolution": "Distinct objects.", "status": "Resolved", "decision": "CW-149"},
    {"term": "Plan",
     "usages": [("02 / 16", "Retirement Plan", "The plan (thin identity in 02, administered in 16)."),
                ("12", "Plan Sponsor Servicing Detail", "The sponsor service relationship for a plan."),
                ("16", "Plan Sponsor Profile", "Sponsor facts (controlled group, employee count).")],
     "recommendation": "Never bare 'Plan'. A sponsor party may carry both a 16 Plan Sponsor Profile and a 12 Institutional Client "
                       "profile (type Corporate DC Plan Sponsor); the facts do not overlap (16: plan sponsor facts; 12: asset owner and "
                       "servicing facts).",
     "resolution": "CW-146.", "status": "Proposed", "decision": "CW-146"},
    {"term": "Custody",
     "usages": [("12", "Client Custodian Account (CUA-)", "Set-up of an institutional separate account at the client's custodian bank."),
                ("28", "Safekeeping Account", "Fund custody network."), ("49", "Client asset custody", "Rule 15c3-3 possession and control.")],
     "recommendation": "Never bare 'Custody'. 12 renamed Custody Account to Client Custodian Account (attributes Client Custodian "
                       "Mandate and Mandate Onboarding.Client Custodian Set-Up) at the 12 fix pass (program-lead ruling); readers in "
                       "REPOINTS.",
     "resolution": "Renamed (12 fix pass).", "status": "Resolved", "decision": "CW-145"},
    {"term": "Holdings",
     "usages": [("12", "Holdings Presentation; Holdings Detail Level; Holdings Disclosure Lag Days; family Performance & Holdings Presentation",
                 "Presentation settings for 18 portfolio holdings."),
                ("18", "Portfolio Holding", "Fund or institutional portfolio holdings."), ("49", "Client Holding", "Brokerage book of record.")],
     "recommendation": "Definitions say 'portfolio holding (18)'. Rename to Portfolio Holdings Presentation, Portfolio Holdings Detail "
                       "Level and Pooled Fund Holdings Disclosure Lag Days at W5 (logged 2026-10-15; the 12 fix pass ruling renamed only "
                       "the client-asset names Serviced Pooled Vehicles and Covered Mandates / Vehicles).",
     "resolution": "", "status": "Proposed, W5", "decision": "CW-149"},
    {"term": "Team",
     "usages": [("03", "Coverage Team", "Advisor coverage team."), ("05", "Advisor Team", "External advisor team (partner)."),
                ("12", "Service Team (SVT-)", "Institutional client service team.")],
     "recommendation": "Never bare 'Team'; 12 definitions say 'service team'.", "resolution": "Distinct objects (CW-149).",
     "status": "Resolved", "decision": "CW-149"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION (jurisdiction.REMOVALS entry format; decision CW-912). A whole removed object or code list has attribute "".
# ---------------------------------------------------------------------------------------------------------------------


def _j(obj, attr, regime, note):
    return {"domain": _D, "object": obj, "attribute": attr, "regime": regime, "decision": _C, "note": note}


JURISDICTION = [
    # Objects
    _j("Depreciation Notification", "", "MiFID II",
       "MiFID II Delegated Regulation 2017/565 Art. 62 and FCA COBS 16A 10% depreciation notice (3 attributes: Depreciation "
       "Threshold Reached, Threshold Breach Date, Depreciation Notice Sent Timestamp). No US successor; client-facing guideline "
       "breaches stay in Breach Notification."),
    # Attributes (of the dropped Template Adoption; its ILPA attributes left under CW-016, not jurisdiction)
    _j("Template Adoption", "CTI Template Type", "Other EU/UK", "UK Cost Transparency Initiative templates for UK pension schemes."),
    _j("Template Adoption", "MiFID Ex-Post Cost Report Indicator", "MiFID II",
       "Annual ex-post costs and charges statement (Delegated Regulation 2017/565 Art. 50, COBS 16A). US fee reporting is 47 (Fee Report Backup report type here)."),
    # Whole code lists
    _j("Code list: CTI Template Type", "", "Other EU/UK",
       "UK CTI: Account Template, Private Markets Sub-Template, Fiduciary Management Template, LDI Template, User Summary."),
    # Code values of kept lists
    _j("Code list: Reporting Driver", "MiFID II Periodic Statement", "MiFID II", "US drivers: Client IMA / Contract, Plan Sponsor Agreement, GIPS, ERISA 3(38) Reporting, Advisers Act Rule 206(4)-2 (confirm current status), Other."),
    _j("Code list: Reporting Driver", "MiFID II Ex-Post Costs", "MiFID II", ""),
    _j("Code list: Reporting Driver", "UK CTI", "Other EU/UK", "UK Cost Transparency Initiative."),
    _j("Code list: Reporting Driver", "UK Stewardship Code", "UK Stewardship Code", "Stewardship reporting is re-sourced to Form N-PX and the 34 voting record."),
    _j("Code list: Reporting Driver", "Solvency II Look-Through", "Other EU/UK", "Solvency II look-through for EU/UK insurer clients."),
    _j("Code list: Reporting Driver", "SFDR / TCFD", "SFDR", "Client-requested ESG reports stay as Report Type 'ESG / Climate Report'."),
    _j("Code list: Report Type", "Cost & Charges Statement", "MiFID II",
       "MiFID ex-post costs / UK CTI statement; also listed in proposals_w2_47.py CW912_ITEMS (recorded once, here)."),
    _j("Code list: Look-Through Template", "Solvency II TPT", "FinDatEx", "Tripartite Template (Solvency II) maintained by FinDatEx; replaced by Consultant Template."),
    _j("Code list: Stewardship Content", "Policy and Context", "UK Stewardship Code",
       "Policy and Context Disclosure of the UK Stewardship Code 2026; replaced by Proxy Voting Policy Summary."),
    _j("Code list: Institutional Client Type", "UK DB Scheme", "Other EU/UK", "Value of the wholesale 02 list, not carried by the restored profile (CW-133)."),
    _j("Code list: Institutional Client Type", "UK DC / Master Trust", "Other EU/UK", "As above."),
    _j("Code list: Institutional Client Type", "UK Local Government Pension Scheme Pool", "Other EU/UK", "As above. US public pensions stay (Public Pension Plan)."),
    _j("Code list: Servicing Segment", "Institutional - Pooled Vehicle (QIAIF in the description)", "AIFMD",
       "Irish qualifying investor AIF named as a pooled vehicle; the re-cut segment 'Institutional Pooled (Fund or CIT)' names the firm's funds and CITs."),
    # Attribute definitions, references and examples re-cut to the US (brief section 4a)
    _j("Service Relationship", "Servicing Legal Entity", "MiFID II",
       "Definition named a UK MiFID firm and a Luxembourg ManCo, secondary reference MiFID II; rewritten to the RIA, trust company and recordkeeping entity (09 LEN-0004)."),
    _j("Service Relationship", "Serviced Pooled Holdings", "AIFMD", "Definition example QIAIF removed; now the firm's mutual funds, ETFs and CITs (attribute renamed Serviced Pooled Vehicles at the 12 fix pass, REPOINTS)."),
    _j("Service Team", "Service Team ID, Service Team Name (EMEA examples)", "Other EU/UK",
       "SVT-EMEA-02 and 'EMEA Pensions Client Service' re-cut to SVT-INST-02 and 'Endowments & Foundations Client Service' (also Service Coverage Assignment.Service Team)."),
    _j("Report Definition", "Regulatory Driver (references and example)", "MiFID II",
       "Primary reference MiFID II Delegated Reg 2017/565 and secondary UK FCA COBS 16A, example 'MiFID II Periodic Statement'; re-sourced to Internal and GIPS."),
    _j("Report Definition", "Available Languages (example en; de; fr)", "Other EU/UK", "European distribution languages; example en; es (US Spanish-language reporting)."),
    _j("Report Definition", "Stewardship Report Scope (primary reference UK Stewardship Code)", "UK Stewardship Code",
       "Moved here from Template Adoption; re-sourced to Advisers Act Rule 206(4)-6 and Rule 14Ad-1 (the firm's own Form N-PX), with fund Form N-PX for pooled vehicles only."),
    _j("Presentation Profile", "Reporting Currency (example GBP)", "Other EU/UK", "Example USD; non-USD reporting currencies stay valid ISO 4217 values for global mandates."),
    _j("Holdings Presentation", "Look-Through Indicator (secondary reference Solvency II TPT)", "FinDatEx", "Reference removed; Internal."),
    _j("Holdings Presentation", "Look-Through Template (references Solvency II TPT)", "FinDatEx", "Re-sourced to Internal."),
    _j("Report Schedule", "Business Calendar (example CAL-UK-LON)", "Other EU/UK", "Example CAL-US-NYSE."),
    _j("Cash Flow Notification", "Notified Amount (example GBP)", "Other EU/UK", "Example USD 25,000,000."),
    _j("Cash Flow Arrangement", "Notification Cut-Off Time (example Europe/London)", "Other EU/UK", "Example 12:00 America/New_York."),
    _j("Mandate Termination", "Records Retention End Date (secondary reference UK FCA SYSC 9)", "FCA", "SEC Rule 204-2 only."),
    # Moved billing objects (CW-054): EU/UK example content recorded here (proposals_w2_47.py CW912_ITEMS; the Report Type item is above)
    _j("Billing Arrangement", "Billing Currency (example GBP)", "Other EU/UK",
       "Moved to 47 (CW-054). Example only: re-sourced to USD in 47; GBP stays a valid ISO 4217 value for nonresident institutional clients."),
    _j("Fee Invoice", "Billable Assets, Management Fee Amount, Performance Fee Amount, Invoice Total (GBP examples)", "Other EU/UK",
       "Moved to 47. Examples only: same figures in USD in 47 (USD 612,400,000; 643,020; 0; 631,020)."),
    _j("Performance Fee Calculation", "High-Water Mark Value, Calculated Performance Fee (GBP examples)", "Other EU/UK", "Moved to 47. Examples only: USD in 47."),
    _j("Performance Fee Calculation", "ESMA Performance Fee Guidelines (references of Hurdle Benchmark, High-Water Mark Value, Crystallized Indicator)", "UCITS",
       "Moved to 47. ESMA guidelines on performance fees in UCITS and certain AIFs; re-sourced in 47 to Advisers Act Rule 205-3 (qualified clients) and Internal."),
    _j("Fee Adjustment", "Adjustment Amount Value (example GBP)", "Other EU/UK", "Moved to 47. Example only: USD in 47."),
    _j("Billing Dispute", "Disputed Amount (example GBP)", "Other EU/UK", "Moved to 47. Example only: USD in 47."),
    # Sources
    _j("Sources", "Cost Transparency Initiative (CTI) templates", "Other EU/UK", "Cited only by the removed CTI content."),
    _j("Sources", "MiFID II Delegated Regulation (EU) 2017/565, Articles 60-62", "MiFID II", "Cited by the removed Depreciation Notification and Regulatory Driver references."),
    _j("Sources", "UK FCA Handbook COBS 16A and SYSC 9", "FCA", "Records retention re-sourced to SEC Rule 204-2."),
    _j("Sources", "UK Stewardship Code 2026", "UK Stewardship Code", "Re-sourced to Advisers Act Rule 206(4)-6, Rule 14Ad-1 and SEC Form N-PX (new source rows)."),
    _j("Sources", "Solvency II Tripartite Template (TPT)", "FinDatEx", "Look-through re-sourced to Internal."),
    _j("Sources", "ESMA Guidelines on performance fees in UCITS and certain AIFs", "UCITS",
       "Cited only by the moved Performance Fee Calculation; no 12 object cites it now (proposals_w2_47.py CW912_ITEMS)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. REPOINTS (object, attribute, before, after, decision): re-types, re-cuts and moves of the adaptation that are not EU/UK
#    removals. Readers in NOTES.
# ---------------------------------------------------------------------------------------------------------------------
REPOINTS = [
    ("Institutional Client", "", "02 Institutional Client (wholesale; dropped at W1, interim INST_CLIENT = ('02', 'Party'))",
     "12 Institutional Client, BO keyed by Institutional Client Party (Reference (Party), PTY-); wholesale attributes kept by name, Fiscal Year End, "
     "Funded Status As-Of Date, UPMIFA Applicability Indicator and Primary Business Line added", "CW-133"),
    ("Service Tier", "", "Service Tier (BO)", "Institutional Service Tier (BO; attribute Service Tier Code kept)", "CW-145"),
    # 12 fix pass renames (program-lead ruling 2026-10-15). Readers listed with each.
    ("Custody Account", "", "Custody Account (BO, CUA-); family group 'Custody Account Set-Up'; ID 'Custody Account Set-Up ID'",
     "Client Custodian Account; 'Client Custodian Account Set-Up'; 'Client Custodian Account Set-Up ID'. Readers: DP-086 "
     "specs_p_inst_intel_finance.py 39, 47-48, 87; models_c9_events_inst_intel.py 649-650, 695-699; keys_g5_11_12_13_14.py 86, "
     "335-337; keys_g8_22_30.py 22 (26 SSI.Safekeeping Account -> ('12', 'Client Custodian Account'))", "CW-145"),
    ("Client Custodian Account", "Custody Mandate", "Custody Mandate", "Client Custodian Mandate. Readers: DP-086 specs_p_inst_intel_finance.py 87; "
     "models_c9_events_inst_intel.py 695; keys_g5_11_12_13_14.py 336", "CW-145"),
    ("Mandate Onboarding", "Custody Set-Up", "Custody Set-Up (new at W4 v0.1; no readers)", "Client Custodian Set-Up", "CW-145"),
    ("Service Relationship", "Serviced Pooled Holdings", "Serviced Pooled Holdings", "Serviced Pooled Vehicles. Readers: DP-042 "
     "specs_e_comp_finance_service.py 519; DP-092 specs_c_sales.py 309; models_c3_comp_finance_service.py 464, 504; models_c1_sales.py "
     "403, 472; keys_g5_11_12_13_14.py 376", "CW-007"),
    ("Report Package", "Covered Mandates / Holdings", "Covered Mandates / Holdings", "Covered Mandates / Vehicles. Readers: DP-042 "
     "specs_e_comp_finance_service.py 530, 575; DP-068 specs_k_events_institutional.py 372; models_c3_comp_finance_service.py 519; "
     "models_c9_events_inst_intel.py 11, 346; keys_g5_11_12_13_14.py 361", "CW-007"),
    ("Plan Sponsor Servicing Detail", "", "Attribute Group of Service Relationship", "Business Object keyed <SVR- id> / <plan PTY-> "
     "(attribute Sponsor Service Relationship added); one row per plan of a sponsor relationship. Add the key to keys_g5 at WP2", "CW-146"),
    ("Holdings Presentation", "Holdings Disclosure Lag Days", "primary SEC Form N-PORT; definition 'e.g. sub-advisory' (v0.1 filed under CW-912)",
     "primary SEC Form N-1A Item 16(f), secondary SEC Form N-PORT (confirm); the sub-advisory wording left with the segment (scope re-cut, not EU/UK)", "CW-145"),
    ("Transition Event", "Transition Total Cost", "", "added: aggregate transition cost as reported to the client (52 review; 25 TCA read, not copied); 'Manager Replacement' Transition Type confirmed present", "CW-147"),
    ("Code list: Institutional Client Type", "relabeled values", "wholesale 02 labels",
     "value map old -> new: Corporate DB Plan -> Corporate DB Plan; Corporate DC Plan -> Corporate DC Plan Sponsor; Public Pension Plan "
     "-> Public Pension Plan; Taft-Hartley / Multiemployer Plan -> Taft-Hartley / Multiemployer Plan (label kept); Endowment -> Endowment; "
     "Foundation -> Foundation; Healthcare System -> Health System; Insurance Company - General Account -> Insurance General Account; "
     "Other -> Other; new: Government Entity; not carried: Sovereign Wealth Fund, Central Bank / Official Institution, Family Office, "
     "Corporate Treasury (lever), UK DB Scheme, UK DC / Master Trust, UK Local Government Pension Scheme Pool (CW-912). Readers that map "
     "values: DP-023, DP-092, SM-00 institutional_client, SM-04 client_type, and the 05, 06 and 11 shared candidate", "CW-133"),
    ("Code list: Servicing Segment", "OCIO / Fiduciary Manager -> OCIO", "the client is an OCIO investing for underlying clients (third-party OCIO; 'Fiduciary Manager' is UK usage)",
     "the firm is the client's OCIO. MEANING FLIPS: a reader filtering on the wholesale value must not map it to OCIO; the third-party "
     "OCIO client has no segment in the wealth model (05 consultant relations)", "CW-145"),
    ("Investment Policy Statement", "Policy Allocation", "example by name", "example in the 24 key form 'MND-01234 v3' (forced to 24); waits for 24 to add a client or mandate subject", "CW-147"),
    ("Institutional Client / IPS / Service Relationship examples", "", "PTY-301120 (also the 02 and 16 plan sponsor example)",
     "endowment examples PTY-301180 and IPSV-301180-04; PTY-301120 / PTY-301121 stay the plan sponsor and plan (SVR-00431). The "
     "proposals_w4_channels.py key-format examples (IPSV-301120-04, PTY-301120) may keep their values or follow", "CW-148"),
    ("Service Relationship", "Client", "Reference (Party)", "Reference (Institutional Client, 12) (PTY- key; OWNERSHIP_OVERRIDES mastered here)", "CW-133"),
    ("Service Relationship", "Advising Consultant", "Reference (Party), copy of the 02 consultant relationship",
     "Reference (Consultant Advisory Relationship, 05) with its composite key", "CW-132"),
    ("Service Relationship", "Service Tier", "Code list 'Service Tier'", "Code list 'Institutional Service Tier' (name kept)", "CW-145"),
    ("Service Standard", "Applies To Tier / Relationship", "Reference (Service Tier / Service Relationship)", "Reference (Institutional Service Tier / Service Relationship)", "CW-145"),
    ("Mandate Termination", "Final Invoice", "Reference (Invoice) to 12 BIL-", "Reference (Fee Invoice, 47) (BIL-; forced to 47 until the prefix transfers)", "CW-054"),
    ("Client Review", "Meeting Activity", "Reference (Activity) to 03 Sales", "Reference (Advisor Activity, 03)", "CW-138"),
    ("Client Service Request", "Related Complaint", "Reference (Complaint) to 08 Distribution Compliance", "Reference (Complaint, 08) (CPL- kept)", "CW-070"),
    ("Custody Account", "Client Account", "Account 'owned by 02'", "Institutional separate account (15)", "CW-021"),
    ("Custody Account", "Custodian BIC", "Derived copy of the 02 Business Identifier Code", "Derived copy of the 02 Party Identifier (scheme BIC)", "CW-902"),
    ("Template Adoption", "Stewardship Report Scope", "Template Adoption (AG of Report Definition)", "Report Definition (same attribute, same list)", "CW-145"),
    ("Client Feedback Response", "", "12 BO (CFS-)", "removed; 04 Client Survey and Survey Response; Relationship Health Score.Survey Inputs added", "CW-093"),
    ("Billing Arrangement / Fee Invoice / Performance Fee Calculation / Fee Adjustment / Billing Dispute", "", "12 IS-BIL family",
     "47 (names and prefixes unchanged); lists Billing Basis, Fee Collection Method, Payment Status, Fee Adjustment Type, Dispute Reason removed from 12", "CW-054"),
    ("Template Adoption", "ILPA Reporting Template Version; ILPA Performance Methodology", "ILPA private fund reporting",
     "removed with their lists (ILPA Template Version, ILPA Performance Methodology), the ILPA Reporting Driver value, Report Type "
     "'Capital Account Statement', Servicing Segment 'Private Fund Investor' and the ILPA source: private funds out of scope", "CW-016"),
    ("Servicing Segment", "", "Segregated Mandate, Pooled Vehicle, Sub-Advisory, SMA / UMA Sponsor, Model Delivery Client, DCIO Plan, OCIO / Fiduciary Manager, Private Fund Investor",
     "OCIO, Institutional Separate Account, Institutional Pooled (Fund or CIT), Plan Sponsor - Recordkept, Plan Sponsor - CIT Only", "CW-145"),
    ("Code list: Service Role", "Relationship Manager; Billing Analyst", "values", "removed (03 Party Coverage Assignment; 47); OCIO Client Strategist and Plan Sponsor Service Manager added", "CW-138"),
    ("Code list: Report Scope Level", "Share Class / Investor Holding; Model / SMA Program", "values", "Pooled Fund or CIT; Retirement Plan (model sponsors are 05)", "CW-145"),
    ("Code list: Branding Type", "White-Label", "Sponsor or sub-advisory client brand", "removed (sub-advisory and sponsors left)", "CW-145"),
    ("Code list: Report Type / Report Component Type / Feed Content Type / Holdings Detail Level", "Holdings values",
     "Holdings / Valuation Statement; Holdings; Full Holdings", "Portfolio Holdings & Valuation Statement; Portfolio Holdings; Full Portfolio Holdings (CW-007 qualifier)", "CW-007"),
    ("Code list: Report Type", "Fee Invoice Backup", "value", "Fee Report Backup (supporting detail for the 47 invoice); OCIO Total Portfolio Report, Plan Sponsor Review Report, Participation & Deferral Report added", "CW-145"),
    ("Code list: Service Standard Metric", "Invoice Timeliness", "value", "removed (47); Cash Flow Instruction Processing Time added", "CW-054"),
    ("Code list: Service Request Type", "Fee Query", "value", "Fee / Invoice Query (resolved against 47); IPS Change Request, SOC 1 Report Request, Plan Sponsor Data Request added", "CW-145"),
    ("Code list: Client Review Type", "", "", "Plan Fiduciary Committee Review and IPS Review added; 'Trustee / Board Meeting' relabeled 'Board / Trustee Meeting'", "CW-145"),
    ("Code list: Review Outcome", "Expansion Discussed", "Hand off to 03 as opportunity", "Hand off to 05 as a sales opportunity", "CW-134"),
    ("Code list: Governance Model", "Fully Delegated (OCIO / Fiduciary Manager)", "value", "Fully Delegated (OCIO); Investment Committee with OCIO added", "CW-145"),
    ("Code list: Institutional Client Type", "", "wholesale 02 list (16 values)",
     "brief section 8 list plus Other; Sovereign Wealth Fund, Central Bank / Official Institution, Family Office, Corporate Treasury not carried (outside the IA client base; lever)", "CW-133"),
    ("Record Metadata", "", "12 AG (7 attributes)", "removed (CD-160); lists Data Quality Status and Confidentiality Classification and the DCAM source go", "CD-160"),
    ("Reference type labels", "Mandate, Template, Transition, Invoice", "Reference (Mandate) / (Template) / (Transition)",
     "Reference (Investment Mandate) / (Report Template) / (Transition Event): label only, same owner and object", "CW-145"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. DECISIONS: the US-only pass of 12 (pre-allocated by CW-022; drafted in proposals_w4_channels.py, completed here)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-912", "theme": "Scope", "title": "US-only pass of Data Domain 12 Institutional Client Servicing & Reporting (including the billing objects moved to 47)",
     "domains": ["12", "47", "34"],
     "issue": "The wholesale 12 carried the MiFID II depreciation notification, UK CTI and MiFID ex-post cost reporting, Solvency II "
              "look-through, UK Stewardship Code and SFDR reporting drivers, UK and Luxembourg servicing entities, EMEA, GBP and "
              "Europe/London examples, and ESMA performance fee guidance on the billing objects that CW-054 moves to 47; the restored "
              "Institutional Client brought three UK client types from the wholesale 02.",
     "resolution": "Removed (42 JURISDICTION entries: 1 object, 2 attributes of the dropped Template Adoption, 1 whole code list, "
                   "13 code values, 13 definition, reference or example re-cuts of kept attributes, 6 example and reference items "
                   "of the billing objects moved to 47, 6 sources): object Depreciation Notification (Depreciation Threshold Reached, Threshold Breach "
                   "Date, Depreciation Notice Sent Timestamp); Template Adoption.CTI Template Type and MiFID Ex-Post Cost Report "
                   "Indicator with the CTI Template Type list; Reporting Driver values MiFID II Periodic Statement, MiFID II Ex-Post "
                   "Costs, UK CTI, UK Stewardship Code, Solvency II Look-Through, SFDR / TCFD; Report Type value Cost & Charges "
                   "Statement; Look-Through Template value Solvency II TPT; Stewardship Content value Policy and Context; Institutional "
                   "Client Type values UK DB Scheme, UK DC / Master Trust, UK Local Government Pension Scheme Pool; the QIAIF pooled "
                   "vehicle; sources CTI templates, MiFID II Delegated Regulation 2017/565 Arts 60-62, FCA COBS 16A and SYSC 9, UK "
                   "Stewardship Code 2026, Solvency II TPT and the ESMA performance fee guidelines. Moved billing objects (47): the GBP "
                   "examples of Billing Arrangement, Fee Invoice, Performance Fee Calculation, Fee Adjustment and Billing Dispute, the "
                   "ESMA references. Kept and re-sourced: Servicing Legal Entity to the US RIA, trust "
                   "company and recordkeeping entity; Regulatory Driver to Internal and GIPS with US values (Client IMA / Contract, Plan "
                   "Sponsor Agreement, GIPS, ERISA 3(38) Reporting, Advisers Act Rule 206(4)-2, Other); Stewardship Report Scope (moved "
                   "to Report Definition) to Advisers Act Rule 206(4)-6, Rule 14Ad-1 and fund Form N-PX for pooled vehicles; look-through "
                   "to Internal; Records Retention End Date to SEC Rule 204-2; examples to "
                   "USD, CAL-US-NYSE, America/New_York, SVT-INST-02 and en; es. Kept: GIPS, ISO standards, SEC marketing and books-and-"
                   "records rules, non-USD currencies and benchmarks of global mandates. Perspective: META subtitle 'Wealth manager "
                   "(direct) | Scope: US'; overview rewritten for OCIO, institutional mandates and plan sponsors (CW-145). Counts "
                   "(built, after the 12 fix pass): 36 to 33 objects, 236 to 250 attributes, 75 to 87 CDEs (35%), 52 to 51 code lists, "
                   "37 to 55 relationships, 15 to 19 sources.",
     "rationale": "CW-003 and CW-022: the firm is regulated and services clients in the US only. Object names are kept (two renames, "
                  "Institutional Service Tier and Client Custodian Account) so DP-140, DP-163 and DP-243 keep resolving; removed content has its readers listed "
                  "(NOTES). Lever: a UK extension restores the removed rows from wholesale-v1.0 through the jurisdiction register.",
     "action": "W4", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 8. NOTES for the W4 merge
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "Size (12 fix pass, 2026-10-15): 10 families, 33 objects (29 BO, 4 AG), 250 attributes, 87 CDEs (35%), 51 code lists (37 "
    "local, 14 copies of shared lists), 55 relationships, 19 sources. v0.1 was 28 BO / 5 AG, 83 CDEs, 54 relationships, 17 "
    "sources. Ownership: 61 references, 6 derived copies (02, 28, 33 x4), 0 unresolved; 6 OWNERSHIP_OVERRIDES (Service "
    "Relationship.Client and IPS Client mastered here; Advising Consultant 05; Policy Allocation 24; Won Opportunity 05 and Final "
    "Invoice 47). REMOVE AT THE W4 MERGE the Won Opportunity and Final Invoice overrides once decisions.PREFIXES restores OPP- to 05 "
    "(CW-148) and transfers BIL- to 47 (CW-054); the other four stay. Before (wholesale): 10 families, 36 objects, 236 "
    "attributes, 75 CDEs, 51 references, 8 derived, 52 code lists, 37 relationships, 15 sources.",
    # Readers. Lines as of 2026-10-14.
    "READERS OF REMOVED, MOVED OR RENAMED 12 CONTENT (live and backlog). "
    "DP-243 (data_products/specs_e5_cross_area.py 459-461 and 507-509: Billing Arrangement, Fee Invoice, Billing Dispute -> 47; "
    "467 and 513: Client Feedback Response.Feedback Relationship and Likelihood to Recommend Score -> 04 Survey Response (Response "
    "Survey, score per the 04 module) joined to 12 Relationship Health Score.Survey Inputs; 553 note on the W1 drop of Institutional "
    "Client -> restore inputs Institutional Client Type, Total Investable Assets from 12). Live 12 inputs that keep resolving: Service "
    "Relationship, Client Service Request, Relationship Health Score, Report Package, Report Run, Mandate Termination. "
    "DP-042 (specs_e_comp_finance_service.py 497, 521: Service Tier -> Institutional Service Tier (attributes unchanged); 499, 542: "
    "Client Feedback Response -> 04 Survey Response; 510-513, 538: Depreciation Notification and its 'Late Depreciation Notices' "
    "metric -> drop (CW-912); 545-547, 576: Billing Dispute, Fee Invoice, Billing Arrangement -> 47; 485, 495: Service Relationship."
    "Client keeps its name, now typed Institutional Client). "
    "DP-092 (specs_c_sales.py 236-237, 275-276, 331: ('02', 'Institutional Client') -> ('12', 'Institutional Client'), every attribute "
    "kept by name; 254, 311: Service Tier -> Institutional Service Tier; 227-269: Service Relationship.Client re-typed only). "
    "DP-023 (specs_c_sales.py 904: ('02', 'Institutional Client', [Institutional Client Type, Government Entity Indicator]) -> 12). "
    "DP-019: no 12 or Institutional Client input found (pipeline is 05). DP-024 and DP-066 (specs_c_sales.py 927-1011; "
    "specs_h_planning_partners.py 535-600): read 02 Recordkeeper Profile and Plan Service Provider, which go to 16 (CW-146), not to "
    "12; no 12 input. DP-068 (specs_k_events_institutional.py 345-352, 393, 409: Template Adoption Mix metric and columns -> drop the "
    "ILPA, CTI and MiFID columns; Stewardship Report Scope now on Report Definition). DP-067 (specs_k_events_institutional.py 175-219; "
    "196: Mandate Termination.Final Invoice now Reference (Fee Invoice, 47)) and DP-086 (specs_p_inst_intel_finance.py 42, 100: "
    "Billing Arrangement -> 47) per proposals_w2_47.py NOTES item 4. DP-225 (specs_e4_compliance_legal.py 582-584: the W1 notes that "
    "Government Entity Indicator and Institutional Client Type had no successor) -> read 12 Institutional Client again. DP-140 and "
    "DP-163: unchanged. DP-053 (specs_g_advisor_analytics.py 477, 485) and DP-061 (specs_j_compliance_2.py 175): re-typed attributes "
    "only (Meeting Activity, Related Complaint), names unchanged.",
    "KEY REGISTRY (data_models/keys_g5_11_12_13_14.py): line 235 INST_CLIENT = ('02', 'Party') -> ('12', 'Institutional Client') "
    "(CW-133); readers 289 (11 Mandate Search Event.Asset Owner) and 374 (12 Service Relationship.Client); line 377 Advising "
    "Consultant -> ('05', 'Consultant Advisory Relationship'); lines 114 and 381 ('12', 'Service Tier') -> ('12', 'Institutional "
    "Service Tier'); lines 80, 324-325 Client Feedback Response, 87 Depreciation Notification, 115 Template Adoption: supersede at "
    "WP2; lines 74-96, 253, 313-315, 341-342, 350-351, 481-485 billing keys -> 47 (proposals_w2_47.py NOTES item 4); line 349 Final "
    "Invoice -> FEE_INVOICE owner 47. Add keys: Institutional Client (PTY-), Investment Policy Statement (IPSV-), Mandate "
    "Onboarding (MND- / date), OCIO Service Detail and Plan Sponsor Servicing Detail (SVR- parent). keys_g1_01_02.py (01 Investment "
    "Mandate.Client) and keys.py (06 Market & Client Dimensions.Institutional Client) re-point to INST_CLIENT per CW-151.",
    "DATA MODELS: models_c3_comp_finance_service.py (DP-042) 436-438 (Depreciation Notification folded into Fact Breach Notification: "
    "remove), 444 (Fact Client Feedback: re-point to 04 Survey Response or drop), 446, 471-473 (billing -> 47), 466 and 499 (Service "
    "Tier dimension -> Institutional Service Tier); models_c1_sales.py (DP-092) 404 and 469 (Service Tier), 412 and 1075 (('02', "
    "'Institutional Client') -> 12); models_c9_events_inst_intel.py 217-307 (DP-067 billing -> 47), 362 (Template Adoption folded "
    "into Report Definition: drop the object); models_e8c_cross_area.py (DP-243) 499-501 (billing -> 47), 511-512 and 575 (Fact Client "
    "Feedback Response -> 04 Survey Response).",
    "SEMANTIC MODELS: SM-00 sm_00_shared_dimensions.py 108-118 (institutional_client: entity is now 12 Institutional Client; "
    "client_party_type reads Institutional Client Type again and its note 'Read in place of Institutional Client Type until W4' goes; "
    "add government_entity_indicator, erisa_plan_indicator), 1096 (institutional_client.party_id = party.party_id stays: the profile "
    "key is the PTY-), 1416-1418 and 1870, 1900 (texts naming the Party Type stand-in). SM-04 sm_04_institutional_retirement.py 61-63 "
    "(client_type attr Institutional Client Type: re-point entity to 12), 258-259 and 543 (service_tier -> Institutional Service Tier; "
    "attribute Service Tier Code kept), 284-286 (depreciation_threshold, depreciation_notice_sent: drop, CW-912), 299-300, 357-360 "
    "and 557-558 (client_feedback -> 04 Survey Response via Relationship Health Score.Survey Inputs; NPS slices read 04), 355-356, "
    "417-426 and 611-616 (billing_arrangement, fee_invoice, billing_dispute -> 47), 31 (question text 'billing issues' reads 47).",
    "REMAINING INTERIM PARTY REFERENCES TO RE-POINT TO THE RESTORED PROFILE (CW-133, CW-151): 01 Investment Mandate.Client "
    "(content_01 line 109, Reference (Party)) -> Reference (Institutional Client, 12) for institutional mandates (01 editor; keep "
    "Party for retail); 06 Market & Client Dimensions.Institutional Client (the 06 W4 draft already re-typed Attribution "
    "Record.Institutional Client; keys.py line 152 ('06', 'Market & Client Dimensions', 'Institutional Client'): PARTY is the one left). "
    "AMENDMENT TO CW-133 (program-lead ruling): 11 Mandate Search Event.Asset Owner STAYS Reference (Party, 02), because the asset "
    "owner running a search need not be a client (content_11 line 428) and the 12 profile exists only for parties with the "
    "Institutional Client role; keys_g5_11_12_13_14.py line 289 therefore stays PARTY, not INST_CLIENT. Readers read the profile "
    "only where one exists. Likewise 05 Consultant Advisory Relationship.Advised Client (content_05 line 441) stays Reference (Party) "
    "by design. In 12 itself, Institutional Client.Institutional Client Party stays Reference (Party) (the key).",
    "MORE READERS OF THE RESTORED PROFILE: DP-003 (data_products/specs_a_foundational.py 189-196: the definition says the "
    "institutional client, consultant and recordkeeper profiles 'move to 12, 05 and 16 at W3 and W4'; at WP0 its institutional slice "
    "reads 12 Institutional Client (Institutional Client Type, Total Investable Assets, Assets As-Of Date, Governance Model, Government "
    "Entity Indicator, ERISA Plan Indicator) and the definition text is rewritten, as brief section 9 says). SM-04 "
    "sm_04_institutional_retirement.py 70-78: the consultant, recordkeeper and rfp_issuer dimensions are declared on entity "
    "'Institutional Client' with Consultant Type and Recordkeeper Model attributes; re-point consultant to 05 Consultant Profile, "
    "recordkeeper to 16 Recordkeeper Profile and rfp_issuer to 02 Party (prospects included), leaving only client_type on the 12 "
    "profile.",
    "SIBLING REQUESTS (sent by the coordinator): (1) 16 adds a 'Plan Fiduciary Committee' value to its plan role list (content_16 "
    "line 646, Plan Fiduciary & Service Role) so Plan Sponsor Servicing Detail.Plan Fiduciary Committee can be filled (16 fix pass). "
    "(2) 24 Asset Allocation Policy adds a client or mandate subject (Policy Mandate or Policy Institutional Client) beside strategy, "
    "product and model portfolio (24/32 fix pass); IPS Policy Allocation then keys on the 24 form '<subject> v<n>' (example MND-01234 "
    "v3 already in that form; drop the Policy Allocation override if 24 gives the subject its own prefix). (3) The won-mandate "
    "hand-off is held on the 12 side only (Mandate Onboarding.Won Opportunity); 05 drops Win / Loss.Resulting Service Relationship "
    "(content_05 line 517; the 05 drafter is told). (4) 52: Transition Event gains Transition Total Cost (aggregate; 25 TCA results "
    "are read, not copied) and Transition Type 'Manager Replacement' is present.",
    "Renames for the baseline check: object Service Tier -> Institutional Service Tier (attributes unchanged). New family "
    "Institutional Client Profile (IS-CLT) first; objects added: Institutional Client (restored), Investment Policy Statement, "
    "OCIO Service Detail, Plan Sponsor Servicing Detail, Mandate Onboarding. Families IS-BIL (Fee Billing & Invoicing) and IS-DMG "
    "(Servicing Data Management) removed. Subdomain 'Certification & Threshold Notifications' -> 'Compliance Certification'. "
    "Attribute IDs are positional within a family and renumber in IS-SVC, IS-RDF, IS-PPR, IS-GBR, IS-CRV, IS-MOS; readers use names. "
    "Attributes added to kept objects: Service Relationship (Relationship Business Line, Relationship Start Date), Service Team "
    "(Service Team Business Line), Report Definition (Stewardship Report Scope, moved), Report Package (Covered Retirement Plans), "
    "Compliance Certificate (Certified Mandate, which the grain needed), Client Review (Reviewed IPS Version), Relationship Health "
    "Score (Survey Inputs).",
    "decisions.py at merge: CONCEPT_OWNERSHIP add Institutional Client (12, PTY- key), Investment Policy Statement (12, IPSV-), "
    "Mandate Onboarding (12), Institutional Service Tier (12), Plan Sponsor Servicing Detail (12); rename the 'Custody Account' row "
    "(if any) to Client Custodian Account (12, CUA-); rename NOT_MERGED ('07', 'Product Compensation Tier', '12', 'Service Tier') "
    "(shared_code_lists.py line 2770) to ('07', 'Product Compensation Tier', '12', 'Institutional Service Tier') or retire it with 07 "
    "(CW-907); retire 'Client Feedback' (12, CFS-) and re-cut Service Tier rows so "
    "'Service Tier' alone resolves to 01 (CW-028). LOCAL_RENAMES and NOT_MERGED: remove ('12', 'Payment Status', ...) and ('12', "
    "'Dispute Reason', ...) (moved to 47; shared_code_lists.py 2715 and 2719), and ('12', 'Settlement Message Standard', ...) (line "
    "2754; the list is not in the module); reword ('12', 'Servicing Segment', ...) (line 2768: 'segregated, pooled, SMA sponsor, "
    "OCIO' -> 'OCIO, separate account, pooled fund or CIT, plan sponsor').",
    "Sibling references made (resolve by the domain number in the type until the modules exist): 05 Consultant Advisory Relationship "
    "(composite key '<consultant PTY-> / <client PTY-> / <effective from>') and Sales Opportunity (OPP-); 16 Service Arrangement "
    "(PSVA-00921) and Plan Role Assignment (PROL-2026-018812), in the 16 example formats; 24 Asset Allocation Policy (no prefix; "
    "24 key form 'MND-01234 v3', forced to 24); 52 Sub-Adviser Engagement (SADV-00412, five digits as 52; the 52 brief rejected the plan anchor MGR- and its Engagement Scope list has 'OCIO Mandate'); 04 Survey Response "
    "(SRSP-); 03 Advisor Activity (ACT-); 08 Complaint (CPL-) and Compliance Review (REV-); 47 Fee Invoice (BIL-).",
    "Not carried and not jurisdiction: Template Adoption's ILPA attributes, lists and source (private funds out of scope, CW-016), "
    "the Net Promoter System source and NPS Category list (CW-093), the DCAM source and Record Metadata (CD-160), ISO 13616 IBAN and "
    "ISO 3166 from the combined ISO source (no attribute used them), Report Type 'Capital Account Statement'.",
    "Brief deviations: (1) Compliance Certificate gains Certified Mandate (its grain 'mandate x period end' had no mandate attribute). "
    "(2) Holdings Presentation, Holdings Detail Level and Holdings Disclosure Lag Days keep their names (TERM_CONFLICTS Holdings, "
    "W5); Custody Account, Serviced Pooled Holdings and Covered Mandates / Holdings were renamed at the 12 fix pass (REPOINTS). "
    "(3) In-Specie Indicator is kept (ordinary US usage; readers). (4) Plan Sponsor Servicing Detail is a Business Object keyed "
    "relationship x plan (ruling), not the brief's attribute group. (5) Two v0.1 attributes were dropped to stay at 250 after the "
    "fix-pass additions (Sponsor Service Relationship, Transition Total Cost): Plan Sponsor Servicing Detail.Servicing Detail Effective "
    "From and OCIO Service Detail.Delegation Effective Date (Relationship Start Date covers both). (6) Spending Policy Method is a "
    "local list not in the brief section 8 list. (7) IPS approval is one date (Governing Body Approval Date) plus IPS Effective Date; "
    "the brief's 'adoption and governing body approval dates' are the same event in most institutions (SME lever).",
    "Remaining grep hits for EU/UK terms in the module: none ('UK' and 'EU' do not occur; 'in specie' kept as an attribute name and "
    "list value, which is ordinary US institutional usage). 'Holding' only qualified or in the three names logged under "
    "TERM_CONFLICTS Holdings; 'Custody' only in the Rule 206(4)-2 title and 'not 49 client asset custody'; 'Position' does not occur.",
    "12 FIX PASS LOWS SKIPPED (one line each): Report Schedule keeps 'Scheduled Package / Report' (DP-068 line 373 and keys_g5 lines "
    "107 and 367 read it; redefined as repeating the parent key); Holdings names (logged for W5, not in the rename ruling); Custodian "
    "BIC and Safekeeping Account Number keep their CDE flag with an 'inherited from the master' note (custody set-up controls depend "
    "on them); Breach Type unflagged instead.",
]
