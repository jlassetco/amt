"""Consolidation proposals from the W4 draft of Data Domain 36 Product Development & Lifecycle (wealth manager), 2026-10-15.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py,
shared_code_lists.py and jurisdiction.REMOVALS at the W4 merge. Formats follow CONTRACT.md in this folder. The brief is
00_Program/Rework/Briefs/36_Product_Development_and_Lifecycle.md (Disposition: Adapt, CW-001; L1 code PD kept). It implements
CW-003, CW-013, CW-022, CW-161, CW-164, CW-169 and CW-170 (proposals_w4_economics.py), the 36 lines of
W4_Retirement_of_07_and_30.md section 5 (no 07 references existed; the 30 references are removed under CW-930), the 08 drafter's
requests in proposals_w2_08.py (CW-067), and drafts CW-936, the US-only pass of 36. Module:
content_36_product_development_and_lifecycle.py (adapted in place; output path and folder unchanged). The expansion file
proposals_36.py is kept as it is; this file supersedes its SHARED_MEMBERSHIPS, SHARED_CANDIDATES and KEY_FORMATS rows where
they differ (stated per row below).
"""

_D, _C = "36", "CW-936"

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES (decisions.PREFIXES tuple format). None. 36 keeps PPSL-, PAPR-, LCHG- and PRVW- (KEPT_PREFIXES in
#    proposals_w4_economics.py). The three new objects take composite keys (KEY_FORMATS in proposals_w4_economics.py):
#    Service Offering Specification LCHG- / specification sequence; Platform Feature Specification LCHG- / feature type;
#    Product Review Criterion Result PRVW- / criterion / share class (or the reviewed subject as a whole).
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

KEY_FORMATS = [
    # Replaces the proposals_36.py row whose example was PRVW-2026-00981-AOV-01 (CW-161).
    # Fix pass (ruling 3): the subject key carries its own prefix so that PRD-00081 and MDL-0081 cannot collide.
    ("PRVW-", "36", "PRVW-<year of review period end>-<subject key with its prefix: PRD-nnnnn, SHC-nnnnnn, MDL-nnnn, OFFR-nnnn, or the "
     "launching LCHG-yyyy-nnnnn of a platform feature>-<review type code, 3 letters: PPR, PLR, APR, RRR, CIT>-<sequence, 2 digits>",
     "PRVW-2026-PRD-00981-PPR-01"),
]

# Key rows for the 36 key registry (keys_e7_30_36.py successor at WP2), in its _k / _child / _fold notation. The nine kept
# objects keep their wholesale kind (Business Object) and their rows; only the rows below change.
KEY_ROWS = [
    ("36", "Service Offering Specification", "_child(['Offering Specification Sequence'])",
     "AG of Product Change Initiative; several offerings per initiative (fold=False)."),
    ("36", "Platform Feature Specification", "_child(['Specified Feature Type'])",
     "AG of Product Change Initiative; one row per feature type per initiative (fold=False)."),
    ("36", "Product Review Criterion Result", "_k(['Criterion Review', 'Product Review Criterion', 'Criterion Share Class'], 'Composite')",
     "Replaces the Value Assessment Criterion Result row; Criterion Share Class is empty when the subject is assessed as a whole."),
    ("36", "Changed Product Scope", "_k(['Scope Change Initiative', 'Scope Product', 'Scope Share Class', 'Scope Model Portfolio', "
     "'Scope Service Offering', 'Scope Service Tier', 'Change Scope Role'], 'Composite')", "Adds the two new scope levels."),
    ("36", "Proposed Term Change", "_k(['Term Change Initiative', 'Product Term Name', 'Term Product', 'Term Share Class', "
     "'Term Model Portfolio', 'Term Service Offering', 'Term Service Tier'], 'Composite')", "Adds the two new term levels."),
    ("36", "Target Market Review Result", "(remove)", "Object removed (CW-936)."),
    ("36", "Value Assessment Criterion Result", "(remove)", "Object removed (CW-936)."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED MEMBERSHIPS. 36 holds no local copy of a shared list: it cites them as 'Shared: <name>' (registered direct user,
#    CD-241). The rows record the direct-user status after W4 and the values its examples use.
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    {"shared": "Business Line", "local": "Shared: Business Line (direct user)",
     "value_map": {c: c for c in ("DB", "DA", "HA", "PF", "WR", "IA", "IC", "TR")}, "new_values": [],
     "note": "Direct user kept (Product Proposal.Proposed Business Line, Product Governance Committee.Committee Business Lines). "
             "Examples now carry CW-004 codes (VALUE_MAPS below)."},
    {"shared": "Distribution Market", "local": "Shared: Distribution Market (direct user)", "value_map": {}, "new_values": [],
     "note": "Direct user ENDS: Product Proposal.Intended Distribution Markets removed (CW-164 retires the list, CW-170). Remove 36 "
             "from direct_users at the W4 merge."},
    {"shared": "COLL Change Classification", "local": "COLL Change Classification", "value_map": {}, "new_values": [],
     "note": "Membership ('36', 'COLL Change Classification') ENDS and the steward (36) retires the list (CW-164; MEMBERSHIPS_REMOVE "
             "in proposals_w4_economics.py). The 13 membership already ended under CW-913."},
    {"shared": "Frequency", "local": "Shared: Frequency (direct user)", "value_map": {}, "new_values": [],
     "note": "Direct user ENDS: Product Committee Meeting Frequency removed (size trim, no reader). Remove 36 from direct_users."},
    {"shared": "Hedging Type", "local": "Shared: Hedging Type (direct user)", "value_map": {}, "new_values": [],
     "note": "Direct user ENDS: Share Class Specification.Proposed Hedging Type removed (size trim, no reader; hedged classes are "
             "rare for the firm's US funds). Remove 36 from direct_users; 01 stays the member."},
    {"shared": "Investor Category", "local": "Shared: Investor Category (direct user)", "value_map": {}, "new_values": [],
     "note": "Direct user kept (Share Class Specification.Proposed Eligible Investor Types, example 'Retail; Institutional'). "
             "The MiFID values PROFESSIONAL, ELIGIBLE_COUNTERPARTY and QUALIFIED_INVESTOR leave the shared list under CW-164 (steward 02)."},
    {"shared": "Vehicle Type", "local": "Shared: Vehicle Type (direct user)", "value_map": {}, "new_values": [],
     "note": "Direct user kept; the CW-164 re-cut (FEEDER_FUND and TENDER_OFFER_FUND added, private-fund and UK pension values "
             "removed) is the steward's (01)."},
    {"shared": "Regulatory Regime", "local": "Shared: Regulatory Regime (direct user)", "value_map": {}, "new_values": [],
     "note": "Direct user kept. Steward 01 to confirm whether NON_US_REGULATED_FUND stays (36 does not use it)."},
    {"shared": "Record Status, RAG Status, Severity, Regulator, Data Basis, Committee Decision Outcome, Asset Class, "
               "Share Class Type, Distribution Policy", "local": "Shared: <name> (direct user)", "value_map": {}, "new_values": [],
     "note": "Direct uses unchanged. RAG Status is no longer used for criterion ratings (local Criterion Rating, brief section 8); "
             "it stays for readiness statuses."},
]

# Example value maps (CW-004): the wholesale Business Line labels the 36 examples carried since W1b, and their codes.
VALUE_MAPS = {
    "Business Line": {"ETF": "PF", "Mutual Fund": "PF", "Collective Investment Trust": "PF"},
    # Fix pass (ruling 4): 36 Product Change Type -> the 01 Lifecycle Event Type value the effected change creates, or None
    # where no 01 Lifecycle Event is created (the 01 record named is updated instead). Hand-off for CD-236.
    "Product Change Type -> 01 Lifecycle Event Type": {
        "Launch": "Launch", "Share Class Launch": "Launch", "Soft Close": "Soft Close", "Hard Close": "Hard Close",
        "Reopen": "Reopen", "Merger": "Merger", "Liquidation": "Liquidation", "Conversion": "Conversion",
        "ETF Conversion": "Conversion", "Share Class Conversion": "Conversion", "Share Class Closure": "Hard Close",
        "Rename": "Rename", "Change of Objective / Policy": "Change of Objective / Policy",
        "Fee Change": None, "Expense Cap Change": None, "Benchmark Change": None, "Dealing Terms Change": None,
        "Change of Service Provider": "Change of Service Provider", "Redomiciliation": "Conversion",
        "Advice Program Launch": "Launch", "Program Change": "Change of Offering Terms",
        "Program Pricing Change": "Change of Offering Terms", "Program Closure": "Soft Close or Hard Close",
        "Platform Feature Launch": None, "Platform Feature Change": None, "Platform Feature Retirement": None,
        "Service Tier Change": None,
    },
    # None rows: Fee Change, Expense Cap Change -> 01 Management Fee / Other Ongoing Fees / Cost Disclosure; Benchmark Change ->
    # 01 Product Benchmark Assignment; Dealing Terms Change -> 01 Dealing Terms; Platform Feature values -> the 01 Platform
    # Feature row (merge edit for 01, NOTES); Service Tier Change -> 01 Service Tier (Tier Asset Threshold, Tier Benefits).
    "Reorganization Cost Bearer -> shared Cost Bearer (if joined)": {"Adviser": "ADVISER", "Shared": "SHARED_FUND_ADVISER",
                                                                    "Merging Fund": "FUND", "Acquiring Fund": "FUND"},
}
# Product Proposal.Proposed Business Line example 'ETF' -> 'PF'; Product Governance Committee.Committee Business Lines
# example 'Mutual Fund; ETF; Collective Investment Trust' -> 'PF; DA; HA; DB' (the committee's wealth remit).

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES (list name in 36, proposed shared list, likely users, recommendation).
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Product Change Type", "Product Lifecycle Event Type", ["01", "13", "47"],
     "CD-236, updated: 36 Product Change Type stays a superset of 01 Lifecycle Event Type. The wealth 01 list adds 'Change of "
     "Offering Terms'; 36 maps Program Change and Service Tier Change to it and adds Advice Program Launch, Program Pricing "
     "Change, Program Closure, Platform Feature Launch, Platform Feature Change and Platform Feature Retirement (CW-161). SFDR "
     "Reclassification (CW-936) and Fund Substitution (CW-165) left the list. Steward 36. Supersedes the proposals_36.py row."),
    ("Product Review Outcome", None, ["36"],
     "Withdrawn as a shared candidate: the three value outcomes copied from 01 Value Assessment Outcome left with the US pass, "
     "and the wealth 01 has no Value Assessment Outcome. Supersedes the proposals_36.py row."),
    ("Reorganization Cost Bearer", "Cost Bearer (steward 13)", ["13", "29", "36"],
     "Fix pass: the local list is renamed now from 'Cost Bearer' (it collided with the shared Cost Bearer of steward 13) and "
     "stays local. Map to the shared list if it is ever joined (lossy): Adviser -> ADVISER, Shared -> SHARED_FUND_ADVISER, "
     "Merging Fund -> FUND, Acquiring Fund -> FUND. 'Management Company / AFM' left under CW-936."),
    ("Product Committee Member Role", "Committee Member Role", ["21", "22", "24", "35", "39"],
     "Unchanged from proposals_36.py."),
    ("Offering Type, Delivery Mode, Discretion Type, Advisory Capacity", "(owner 01 lists)", ["01", "36"],
     "Copies of 01 lists with the owner's names and values (Service Offering Specification, Product Proposal). Replace by "
     "references to the owner's lists at W5, or register 36 as a member if the lists become shared."),
    ("Feature Type, Disclosure Type", "(owner 15 lists)", ["15", "36"],
     "Copies of 15 lists (Platform Feature Specification). Same treatment. Eligible Account Registration Types cites "
     "'External (15 Account Registration Type)' instead of copying the 28-value list."),
    ("Product Review Criterion", None, ["36", "52"],
     "Local (CW-161). 52 Oversight Review of external managers may want the same performance and fee criteria; compare at W5."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (decisions.py format). CW-169 logs Review, Offering and Program; the rows add the 36 usages.
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = [
    {"term": "Review",
     "usages": [("36", "Product Review (PRVW-)", "Periodic, post-launch, advice program, range rationalization and CIT reviews"),
                ("45", "Advice Review", "Review of a client's advice relationship"),
                ("08", "Supervisory Review", "Principal review of recommendations and accounts"),
                ("38", "Compliance Program Review", "Rule 206(4)-7 and 38a-1 annual review"),
                ("52", "Oversight Review", "Review of an external manager or sub-adviser")],
     "recommendation": "Never 'Review' bare (CW-169): 'Product Review' (36). Adds the 52 usage."},
    {"term": "Offering",
     "usages": [("01", "Service Offering (OFFR-)", "The live advice or service offering"),
                ("36", "Service Offering Specification", "Proposed values of an offering under a change initiative"),
                ("11", "Competitor Offering (COFF-)", "A competitor's offering")],
     "recommendation": "'Service Offering' is 01's record; 36 uses 'Specification' for proposed values (CD-236)."},
    {"term": "Feature",
     "usages": [("01", "Offering Feature", "Feature included in a service offering"),
                ("15", "Account Feature", "Feature enabled on one account"),
                ("36", "Platform Feature Specification", "Proposed brokerage platform feature under a change initiative")],
     "recommendation": "Qualify: 'Offering Feature' (01), 'Account Feature' (15), 'Platform Feature' (36 change and specification)."},
    {"term": "Proposal",
     "usages": [("36", "Product Proposal (PPSL-)", "Proposal for a new fund, offering or feature"),
                ("13", "Proxy Proposal", "Matter put to a shareholder vote"),
                ("46", "Trade Proposal", "Proposed rebalancing trade")],
     "recommendation": "Never 'Proposal' bare: 'Product Proposal' (36), 'Proxy Proposal' (13), 'Trade Proposal' (46)."},
    {"term": "Program",
     "usages": [("01", "Service Offering (advice program)", "Advice program"),
                ("36", "Product Change Type 'Advice Program Launch', 'Program Change', 'Program Pricing Change'", "Change to an advice program"),
                ("38", "Compliance program", ""), ("50", "Sweep Program", ""), ("05", "Partner Program", "IC partner program")],
     "recommendation": "CW-169: 'advice program' when 01 Service Offering is meant."},
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION (jurisdiction.REMOVALS entry format; CW-022). A whole removed object or code list has attribute "".
# ---------------------------------------------------------------------------------------------------------------------


def _j(obj, attr, regime, note):
    return {"domain": _D, "object": obj, "attribute": attr, "regime": regime, "decision": _C, "note": note}


JURISDICTION = [
    # Objects
    _j("Target Market Review Result", "", "MiFID II",
       "MiFID II / FCA PROD 3 manufacturer target market review (4 attributes: Target Market Review Conclusion, Distributor Feedback "
       "Reviewed (Reference (Distributor Feedback Report), 08), Sales Outside Target Market Observed Indicator (Derived copy, 08) and "
       "Target Market Review Rationale). The two 08 feedback attributes are the ones the 08 drafter asked 36 to remove (CW-067; "
       "proposals_w2_08.py NOTES); client feedback now lives in 04 surveys (CW-093) and product-governance outcomes are reviewed by "
       "08 Compliance Review. No US successor object: US reviews use Product Review and Product Review Criterion Result."),
    _j("Value Assessment Criterion Result", "", "FCA",
       "FCA COLL 6.6.20R-6.6.21R assessment of value and the Consumer Duty (PRIN 2A) price and value outcome (12 attributes, among "
       "them Value Assessment Criterion, Outcome Evidence Metric (Reference (Outcome Metric, 08), Consumer Duty; the 'Outcome "
       "Metric, 08' reference the 08 drafter asked 36 to remove) and Comparable Share Class (COLL 6.6.21R(7) classes of units)). "
       "Replaced by Product Review Criterion Result with US criteria (CW-161), which keeps the evidence attributes by name."),
    # Attributes of kept objects
    _j("Changed Product Scope", "COLL Change Classification", "FCA",
       "FCA COLL 4.3 fundamental / significant / notifiable classification per product; the shared list (steward 36) retires (CW-164). "
       "US notice and vote needs are Change Regulatory Requirement rows (Rule 35d-1, Investment Company Act Section 15)."),
    _j("Product Review", "AFM Board Approval Date", "FCA",
       "UK authorized fund manager board approval of the assessment of value (Derived copy, 35). US board approvals stay 35 Board "
       "Resolution linked through Resolution Subject Link (CD-237)."),
    _j("Change Impact Assessment", "Foreseeable Harm Identified Indicator", "Consumer Duty",
       "FCA PRIN 2A foreseeable harm. Impact Area adds Advisory Clients, Supervisory Procedures, Client Disclosures and Technology."),
    _j("Product Proposal", "Intended Distribution Markets", "Other EU/UK",
       "Distribution market of a manufacturer distributing in the EU/UK (shared Distribution Market, one value left, retired under "
       "CW-164; CW-170)."),
    _j("Readiness Check", "Evidence Country Registration", "UCITS",
       "Reference (Country Registration) to the 01 object removed under CW-901 (UCITS cross-border marketing registrations). "
       "Readiness Workstream 'State Notice Filing' (35, NSMIA) is added (CW-069, CW-170)."),
    # Whole code lists
    _j("Code list: Target Market Review Conclusion", "", "MiFID II",
       "Target Market Confirmed, Target Market Amended, Distribution Strategy Restricted, Product Withdrawal Recommended (ESMA "
       "product governance guidelines, FCA PROD 3)."),
    _j("Code list: Value Assessment Criterion", "", "FCA",
       "COLL 6.6.21R(1) to (7) (Quality of Service, Performance, AFM Costs, Economies of Scale, Comparable Market Rates, Comparable "
       "Services, Classes of Units) and Consumer Duty Price and Value (PRIN 2A.4). Replaced by the local Product Review Criterion list."),
    _j("Code list: COLL Change Classification", "", "FCA",
       "Fundamental, Significant, Notifiable, Not Applicable (FCA COLL 4.3); shared list retired (CW-164)."),
    # Code-list values
    _j("Code list: Product Review Type", "Assessment of Value", "FCA", "UK authorized funds, COLL 6.6.20R."),
    _j("Code list: Product Review Type", "Fair Value Assessment", "Consumer Duty", "FCA PRIN 2A price and value outcome."),
    _j("Code list: Product Review Type", "Target Market Review", "MiFID II", "Ad hoc review of the MiFID target market."),
    _j("Code list: Product Review Type", "Periodic Product Review", "MiFID II",
       "Reading removed, value kept: the MiFID II / FCA PROD 3 manufacturer-review reading leaves; the value is re-sourced to "
       "NASD Notice to Members 05-26 practice (reiterated by FINRA Regulatory Notice 12-03) and firm policy."),
    _j("Code list: Product Review Outcome", "Value Delivered", "FCA", "01 Value Assessment Outcome value for COLL value reviews."),
    _j("Code list: Product Review Outcome", "Value Delivered - Action Required", "FCA", "As above."),
    _j("Code list: Product Review Outcome", "Value Not Delivered", "FCA", "As above."),
    _j("Code list: Product Decision Type", "Value Assessment Sign-off", "FCA",
       "Sign-off of the assessment of value or Consumer Duty fair value assessment; US sign-offs are Review Sign-off."),
    _j("Code list: Review Action Type", "Target Market Amendment", "MiFID II", "MiFID II target market."),
    _j("Code list: Review Action Type", "Distribution Strategy Restriction", "MiFID II", "MiFID II distribution strategy."),
    _j("Code list: Product Change Type", "SFDR Reclassification", "SFDR", "Change of SFDR article or sustainability label."),
    _j("Code list: Product Term Name", "SFDR Classification", "SFDR", "Text term mapped to 01 ESG Classification (SFDR article)."),
    _j("Code list: Regulatory Requirement Type", "FCA Change Notification", "FCA",
       "Fund Filing group row for 35 form type FCA Authorized Fund Report or Notification."),
    _j("Code list: Regulatory Requirement Type", "Competent Authority Prior Approval", "UCITS",
       "Regulator Prior Approval for EU funds (for example CSSF or Central Bank of Ireland). The group keeps the US value FINRA "
       "Continuing Membership Application (FINRA Rule 1017)."),
    _j("Code list: Regulatory Requirement Type", "UCITS Merger Authorization", "UCITS", "UCITS Directive Chapter VI."),
    _j("Code list: Regulatory Requirement Type", "Shareholder Vote", "FCA",
       "Reading removed, value kept for US votes (Investment Company Act Section 15, fundamental policy changes); the 'COLL Fundamental changes' "
       "reading is removed."),
    _j("Code list: Regulatory Requirement Type", "Shareholder Notice - Prior Written Notice", "FCA",
       "Reading removed, value kept; 'including COLL Significant changes' removed."),
    _j("Code list: Regulatory Requirement Type", "Shareholder Notice - Other", "FCA",
       "Reading removed, value kept; 'including COLL Notifiable changes and UCITS merger information' removed (also UCITS)."),
    _j("Code list: Impact Area", "Consumer Duty Foreseeable Harm", "Consumer Duty", "FCA PRIN 2A."),
    _j("Code list: Reorganization Structure", "UCITS Merger by Absorption", "UCITS", "UCITS Directive Chapter VI."),
    _j("Code list: Reorganization Structure", "UCITS Merger by New Fund", "UCITS", "UCITS Directive Chapter VI."),
    _j("Code list: Reorganization Structure", "UK Scheme of Arrangement", "FCA", "UK authorized fund merger by scheme of arrangement."),
    _j("Code list: Reorganization Cost Bearer", "Management Company / AFM", "Other EU/UK",
       "UCITS management company and UK authorized fund manager (UCITS and FCA). The US adviser is 'Adviser'. The list was named Cost Bearer in the wholesale module."),
    _j("Code list: Readiness Workstream", "Registration", "UCITS",
       "01 Country Registration (cross-border marketing). Replaced by 'State Notice Filing' (35, NSMIA)."),
    _j("Code list: Final Distribution Approach", "Payment to Unitholders by Trustee", "FCA",
       "Reading removed, value kept for CIT plan terminations (OCC 12 CFR 9.18); the UK authorized unit trust reading is removed."),
    # Sources
    _j("Sources", "FCA Handbook COLL 4.3 (approvals and notifications) and COLL 6.6.20R-6.6.21R (assessment of value)", "FCA",
       "Also removed as secondary reference ('UK FCA COLL') from kept attributes, re-sourced to SEC rules or Internal."),
    _j("Sources", "FCA Handbook PROD 3 (product governance for MiFID manufacturers) and PRIN 2A (Consumer Duty)", "FCA",
       "Also Consumer Duty. Product governance re-sourced to NASD Notice to Members 05-26 practice (reiterated by FINRA Regulatory Notice 12-03) and firm policy."),
    _j("Sources", "ESMA Guidelines on MiFID II product governance requirements (ESMA35-43-3448)", "MiFID II",
       "Also removed as secondary reference ('ESMA Product Governance Guidelines', 'MiFID II') from kept attributes."),
    _j("Sources", "UCITS Directive 2009/65/EC, Chapter VI (mergers of UCITS)", "UCITS",
       "Removed also from the Change Scope Role and Reorganization Structure list sources and the Reorganization attribute references."),
    _j("Sources", "PRIIPs Regulation (EU) 1286/2014; FCA PS25/20 Consumer Composite Investments", "PRIIPs",
       "Also secondary reference of the wholesale Projected Ongoing Charge (renamed Projected Total Annual Operating Expense, Form N-1A)."),
    _j("Sources", "FinDatEx European MiFID Template (EMT) and European Feedback Template (EFT)", "FinDatEx",
       "Target market data and distributor feedback; left with Target Market Review Result."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. REPOINTS (object, attribute, before, after, decision).
# ---------------------------------------------------------------------------------------------------------------------
REPOINTS = [
    ("Value Assessment Criterion Result", "", "object (BO), criteria per share class under COLL 6.6.21R",
     "removed; Product Review Criterion Result (BO, review x criterion x share class or whole subject) keeps Criterion Review, "
     "Criterion Share Class, Criterion Rating, Criterion Conclusion, Performance Evidence Return, Benchmark Evidence Return, Fee "
     "Evidence Study, Cost Evidence Profitability Record and Evidence Metric Definition by name; Value Assessment Criterion -> "
     "Product Review Criterion; adds Peer Evidence Universe (11), Flow Evidence Measure Value (06), Complaint Evidence Count "
     "(Derived, 08), Drift Exception Evidence Count (Derived, 46)", "CW-161"),
    ("Product Review Criterion Result", "Criterion Rating", "Code, Shared: RAG Status (on Value Assessment Criterion Result)",
     "Code, local Criterion Rating (Meets Expectations, Monitor, Below Expectations, Not Assessed)", "CW-161"),
    ("Value Assessment Criterion Result", "Outcome Evidence Metric", "Reference (Outcome Metric, 08)", "removed (no 08 target)", "CW-170"),
    ("Target Market Review Result", "Distributor Feedback Reviewed", "Reference (Distributor Feedback Report) (multi), 08",
     "removed (no 08 target; feedback in 04 surveys, CW-093)", "CW-170"),
    ("Product Business Case", "Projected Ongoing Charge", "Percentage, SEC Form N-1A / PRIIPs Regulation",
     "renamed Projected Total Annual Operating Expense (Form N-1A Item 3 fee table)", "CW-161"),
    ("Readiness Check", "Evidence Shelf Placement", "Reference (Shelf Placement), wholesale 05",
     "unchanged type; resolves to the kept 05 Shelf Placement (SHF-), IC line only", "CW-170"),
    ("Readiness Check", "Evidence Platform Product Availability", "(none)",
     "added: Reference (Platform Product Availability, 01) for brokerage platform set-up checks", "CW-170"),
    ("Readiness Check", "Evidence Supervisory Policy; Evidence Release", "(none)",
     "added: Reference (Policy) 38 POLCY-; Reference (Release, 41) RLSE-", "CW-161"),
    ("Change Regulatory Requirement", "Satisfying Firm Filing", "(none)",
     "added: Reference (Firm Regulatory Filing, 38) for Form ADV and Form CRS amendments", "CW-161"),
    ("Changed Product Scope / Proposed Term Change / Product Review", "Scope / Term / Review Service Offering", "(none)",
     "added: Reference (Service Offering, 01)", "CW-161"),
    ("Proposed Term Change", "Proposed Fee Schedule", "(none)", "added: Reference (Fee Schedule, 47), forced to 47 in enrich_36", "CW-158"),
    ("Product Proposal", "Proposed Business Line", "example 'ETF'", "example 'PF'", "CW-004"),
    ("Product Governance Committee", "Committee Business Lines", "example 'Mutual Fund; ETF; Collective Investment Trust'",
     "example 'PF; DA; HA; DB'", "CW-004"),
    ("Product Review", "Product Review ID", "example PRVW-2026-00981-AOV-01",
     "example PRVW-2026-PRD-00981-PPR-01, key with the subject prefix (also Criterion Review, Action Review)", "CW-161"),
    ("Product Review", "Review Platform Feature", "(none)",
     "added: Reference (Platform Feature Specification, 36), so a platform feature can be the subject of a Post-Launch Review", "CW-161"),
    ("Changed Product Scope / Proposed Term Change", "Scope Service Tier / Term Service Tier", "(none)",
     "added: Reference (Service Tier, 01); Product Term Name adds Tier Asset Threshold and Tier Benefits", "CW-161"),
    ("Platform Feature Specification", "Eligible Offerings, Eligible Account Registration Types, Required Disclosure Type, Client "
     "Activation Required Indicator", "proposed values with no live home after launch",
     "proposed values of 01 Platform Feature (merge edit for 01, NOTES); names unchanged", "CW-161"),
    ("Product Review Criterion Result", "Complaint Evidence Count", "rule: complaints 'whose product or offering is the review subject'",
     "rule: 08 Complaint.Product / Share Class, or Complaint.Account -> 15 Program Enrollment.Enrolled Service Offering at Received Date", "CW-161"),
    ("Change Regulatory Requirement", "Requirement Status (Exemptive Relief group)", "Satisfied when the 35 reliance has an Order Date",
     "Satisfied when 35 Exemptive Relief Reliance.Reliance Effective From is set; date = Reliance Effective From", "CD-233"),
    ("Code list: Cost Bearer", "", "local list 'Cost Bearer'", "renamed 'Reorganization Cost Bearer' (map in VALUE_MAPS)", "CW-164"),
    ("Code list: Impact Area", "", "Shareholders; Distributors and Platforms", "Fund Shareholders; Intermediary Platforms", "CW-013"),
    ("Code list: Proposal Origin", "", "Distribution Demand; Client Request",
     "Client Demand (both); Institutional Client Request added for institutional and seed requests", "CW-013"),
    ("Code list: Product Review Type", "", "US Product Rationalization Review", "Fund Range Rationalization Review (RRR)", "CW-161"),
    ("Code list: Review Action Type", "", "Investor Communication", "Client Communication", "CW-161"),
    ("Code list: Product Committee Member Role", "", "Observer / Adviser", "Observer / Advisor (a person; American usage)", "CW-161"),
    ("Changed Product Scope", "Scope Product", "note: 'the New row's product is the key 30 Private Fund Profile is held against'",
     "note: the New row's PRD- is created by 01 with status In Development", "CW-930"),
    ("Readiness Check", "Readiness Workstream", "values Custody, Platform Onboarding",
     "values Fund Custody (CW-007 custody naming), Intermediary Platform Onboarding (05, IC line)", "CW-007"),
    ("(object kinds, withdrawn in the fix pass)", "", "Business Object: Proposal Stage History, Product Business Case, Product Committee Membership, Changed "
     "Product Scope, Proposed Term Change, Share Class Specification, Change Impact Assessment, Product Readiness Plan, Review Action",
     "UNCHANGED: the draft's move to Attribute Group is reverted (program-lead ruling 2); all nine stay Business Objects", "CW-161"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. DECISIONS: the one CW- id the brief pre-allocates (CW-936). Completes the CW-936 row of proposals_w4_economics.py.
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-936", "theme": "Scope", "title": "US-only pass of 36 Product Development & Lifecycle",
     "domains": ["36", "01", "08", "13", "35"],
     "issue": "The wholesale 36 governed the product range of a manufacturer selling in the US and under UK and EU product "
              "governance: FCA PROD 3 and MiFID II target market reviews, the COLL 4.3 change classification, the COLL 6.6.20R "
              "assessment of value and the Consumer Duty fair value assessment, UCITS mergers and competent authority approvals, "
              "PRIIPs documents and FinDatEx target market and feedback templates; its review key example carried 'AOV'.",
     "resolution": "Removed (41 JURISDICTION entries: 2 objects, 5 attributes, 3 whole code lists, 25 code values or value "
                   "readings, 6 sources): objects Target Market Review Result (Target Market Review Conclusion, Distributor "
                   "Feedback Reviewed, Sales Outside Target Market Observed Indicator, Target Market Review Rationale) and Value "
                   "Assessment Criterion Result (12 attributes, among them Value Assessment Criterion, Outcome Evidence Metric and "
                   "Comparable Share Class); attributes Changed Product Scope.COLL Change Classification (shared list retired, "
                   "CW-164), Product Review.AFM Board Approval Date, Change Impact Assessment.Foreseeable Harm Identified Indicator, "
                   "Product Proposal.Intended Distribution Markets (Distribution Market retired) and Readiness Check.Evidence "
                   "Country Registration (01 object removed, CW-901); lists Target Market Review Conclusion, Value Assessment "
                   "Criterion and COLL Change Classification; values Assessment of Value, Fair Value Assessment and Target Market "
                   "Review (Product Review Type), the three value outcomes (Product Review Outcome), Value Assessment Sign-off, "
                   "Target Market Amendment and Distribution Strategy Restriction, SFDR Reclassification and the SFDR Classification "
                   "term, FCA Change Notification, Competent Authority Prior Approval and UCITS Merger Authorization, the COLL "
                   "readings of Shareholder Vote and the two notice types, Consumer Duty Foreseeable Harm, the UCITS and UK merger "
                   "structures, Management Company / AFM as cost bearer, Registration as readiness workstream and the UK unit trust "
                   "reading of trustee payment; sources FCA COLL, FCA PROD 3 and PRIN 2A, ESMA product governance guidelines, UCITS "
                   "Directive Chapter VI, PRIIPs and PS25/20, FinDatEx EMT and EFT. "
                   "Kept and re-sourced: Product Governance Committee, Product Decision Type and Product Review Type (Periodic "
                   "Product Review) to NASD Notice to Members 05-26 practice (reiterated by FINRA Regulatory Notice 12-03) and firm policy; Proposed Manufacturer "
                   "Entity, Committee Manufacturer Entity, Proposal Sponsor, Review Approver and the review dates to Internal; "
                   "Shareholder Adverse Indicator to the Investment Company Act and Form ADV; Minimum Notice Days to Rule 35d-1; "
                   "Regulatory Requirement Type to Form N-14 and Rule 485; Change Scope Role, Reorganization Structure and Exchange "
                   "Valuation Date to Form N-14 and Rule 17a-8; Projected Ongoing Charge renamed Projected Total Annual Operating "
                   "Expense (Form N-1A Item 3); Regulator Prior Approval group re-sourced to FINRA Rule 1017; Final Distribution "
                   "Approach trustee payment to OCC 12 CFR 9.18; Pricing readiness to Rule 2a-5. Perspective text (META, overview, "
                   "Source_Notes) rewritten to the US wealth manager; GDPR replaced by Regulation S-P, GLBA and state law. "
                   "The PRVW- key carries the subject prefix, example PRVW-2026-PRD-00981-PPR-01 (CW-161; 35's copy follows). Fund Substitution and the "
                   "Section 26(c) Substitution Order requirement left under CW-165 (insurance-dedicated, not EU/UK); the 30 "
                   "Private Fund Profile note left under CW-930. Proposed Domicile and Proposed Class Currency keep non-US values "
                   "as values only (foreign-listed ETF classes); no foreign product governance regime is modeled. Lever: a UK "
                   "extension restores the removed rows from wholesale-v1.0 through the jurisdiction register.",
     "rationale": "CW-003, CW-022. Readers DP-105 to DP-109, DP-242, models_e8c_private_markets_product_range.py, "
                  "models_e8c_cross_area.py, keys_e7_30_36.py and sm_06_product_market.py lose the removed columns (NOTES, READERS).",
     "action": "W4", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 8. NOTES for the W4 merge
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    "READERS OF REMOVED, RENAMED OR RE-TYPED 36 CONTENT (lines as of 2026-10-15). Data products, specs_e3_private_markets_product_range.py: "
    "DP-105 659 (Product Proposal.Intended Distribution Markets), 664 (Projected Ongoing Charge, renamed Projected Total Annual "
    "Operating Expense); DP-106 791, 829, 1053 (Changed Product Scope.COLL Change Classification) and the FCA / UCITS Regulatory "
    "Requirement Type values (748-799 read the attribute, no literal value filter found); DP-107 882, 888, 927 (Readiness "
    "Check.Evidence Country Registration); DP-108 1042, 1043, 1062 (Change Impact Assessment.Foreseeable Harm Identified Indicator); "
    "DP-109 1133-1134, 1183, 1231 (Product Review.AFM Board Approval Date, metric 'Assessments Approved on Time %'), 1136-1150, "
    "1155, 1160, 1164, 1186, 1217, 1235 (Value Assessment Criterion Result: Value Assessment Criterion, Criterion Rating, Criterion "
    "Share Class, Criterion Review, Outcome Evidence Metric at 1142, 1149, 1189, Comparable Share Class at 1142, 1148, 1189, 1236), "
    "1168-1171, 1184-1185 (Target Market Review Result: Target Market Review Conclusion, Distributor Feedback Reviewed, Sales Outside "
    "Target Market Observed Indicator, Target Market Review Rationale). specs_e5_cross_area.py: DP-242 283, 285, 348 (Value "
    "Assessment Criterion Result, Value Assessment Criterion, Criterion Rating; metric 'Latest Review Outcome (from DP-109)'). "
    "Logical models: models_e8c_private_markets_product_range.py 810 (Evidence Country Registration), 894-895 (Value Assessment "
    "Criterion Result), 926, 929 (Target Market Review Result, Distributor Feedback Reviewed), 933, 950-951 (Comparable Share Class, "
    "Outcome Evidence Metric), 980 (AFM Board Approval Date, Distributor Feedback Reviewed); models_e8c_cross_area.py 282-283, "
    "384-385, 435 (Value Assessment Criterion Result). Keys: keys_e7_30_36.py 173-174, 337, 348-357, 367, 370 (superseded at WP2). "
    "Semantic model: sm_06_product_market.py 444 (Projected Ongoing Charge), 509 (COLL Change Classification), 596 (Evidence Country "
    "Registration), 661, 668, 1647, 1649 (Foreseeable Harm), 679 (AFM Board Approval Date), 681-686 (Target Market Review Result "
    "columns), 689-690, 703-704, 1672-1674 (Value Assessment Criterion Result columns). DP-109 and "
    "models_e8c_private_markets_product_range.py also carry the 30 Private Markets products (DP-136 to DP-139) that retire at WP0; "
    "noted, not edited.",
    "READERS (disposition, proposal). DP-109 Product Reviews & Value Assessments: re-scope at WP0 to 'Product Reviews & Criterion "
    "Results' (brief section 9): re-point Value Assessment Criterion Result to Product Review Criterion Result (Criterion Review, "
    "Criterion Share Class, Criterion Rating, Criterion Conclusion and the evidence columns keep their names; Value Assessment "
    "Criterion -> Product Review Criterion; Criterion Rating values change from RAG to the local Criterion Rating list), drop "
    "'Assessments Approved on Time %', the Target Market Review Result columns, Outcome Evidence Metric and Comparable Share Class; "
    "'Share Classes Not Providing Value' becomes 'Subjects Rated Below Expectations'. DP-242 Fund 360 & Product P&L: re-point to "
    "Product Review Criterion Result and drop the 'not providing value' flag. DP-105: drop Intended Distribution Markets, rename "
    "Projected Ongoing Charge. DP-106: drop COLL Change Classification; the requirement type values FCA Change Notification, "
    "Competent Authority Prior Approval and UCITS Merger Authorization disappear, and Form ADV, Form CRS, Advance Fee Change Notice, "
    "Advisory Agreement Amendment, State Notice Filing and FINRA Continuing Membership Application appear (Satisfying Firm Filing "
    "is a new column). DP-107: drop Evidence Country Registration; workstream values Custody -> Fund Custody, Platform Onboarding "
    "-> Intermediary Platform Onboarding, Registration -> State Notice Filing. DP-108: drop Foreseeable Harm. DP-234 and the kept "
    "objects read by DP-105 to DP-108 keep their names. Object kinds are the wholesale kinds (fix pass), so keys_e7_30_36 needs only the "
    "KEY_ROWS above. Further readers (review finding): sm_06_product_market.py 727, 1676, 1679 ('Share Classes Not Providing Value') "
    "and 1665, 1669 ('Assessments Approved on Time %'); specs_e5_cross_area.py 330 (the not-providing-value flag); "
    "specs_e3_private_markets_product_range.py 1234 (the AFM gap note); generated outputs data_products/_catalog.txt and "
    "semantic_model/out/products/DP-107, DP-108, DP-109 and DP-242 yaml regenerate at WP0. specs_e3 line 1202 reads 08 Sales Against "
    "Target Market, not a 36 object.",
    "Removals that are not jurisdiction entries. CW-165 (insurance-dedicated): Product Change Type 'Fund Substitution', Regulatory "
    "Requirement Type 'Section 26(c) Substitution Order', the Section 26(c) half of the Investment Company Act source (re-cut to "
    "Section 15, URL 80a-15), the insurance-dedicated wording of the Purpose. CW-930 (30 Private Markets retires; W4 retirement "
    "brief section 5 lists no other 36 reference): the Changed Product Scope.Scope Product note on 30 Private Fund Profile, 'private "
    "fund profiles and closes (30)' in the Scope overview, 'private funds' in the Purpose, and the proposals_36.py NOTES line on "
    "private fund launches. No 07 reference existed in content_36 or enrich_36. Size trims (no reader): Share Class "
    "Specification.Proposed Class Servicing Fee Rate and Proposed Hedging Type, Product Governance Committee.Product Committee "
    "Meeting Frequency and Product Committee Effective To.",
    "Brief deviations. (a) Platform Feature Specification holds no Release and no supervisory procedure reference: the 41 Release "
    "and the 38 Policy are Readiness Check evidence (Evidence Release, Evidence Supervisory Policy), held once (CD-239); and it holds "
    "no launched date (Actual Effective Date of the initiative, held once). (b) Product Review Criterion Result's subject is the "
    "share class or the reviewed subject as a whole; the offering or model is the review's subject, not repeated per criterion. "
    "(c) A Program Pricing Change references the 47 schedule on Proposed Term Change; the 10 Pricing Scenario is not referenced from "
    "the change because 10 Pricing Scenario references LCHG- (one direction per link); a proposal's business case may cite PRSC- as "
    "market evidence. (d) Requirement Country is kept (live readers DP-106, keys, sm_06); state notice filings are one row per "
    "product, the states being on the 35 filings. (e) Affected Shareholder Accounts Count keeps its name (live readers) and counts "
    "client accounts for program and feature changes. (f) Proposal Category is added (not in the brief) to tell fund, share class, "
    "service offering and platform feature proposals apart; CDE.",
    "Sibling names used, checked 2026-10-15: 01 Service Offering (OFFR-), Tradable Universe Policy Rule (TUP-), Platform Product "
    "Availability, Offering Type, Delivery Mode, Discretion Type, Advisory Capacity lists (content_01_product.py); 15 Feature Type, "
    "Disclosure Type, Account Registration Type lists; 47 Fee Schedule (CLFEE-), Fee Disclosure Delivery (type Advance Notice of Fee "
    "Change); 38 Firm Regulatory Filing (FILNG-), Policy (POLCY-); 41 Release (RLSE-); 05 Distribution Agreement (AGR-), Shelf "
    "Placement (SHF-), Model Program Placement (kept per the 05 W4 brief); 06 Measure Value (MSR-), Client Asset Measures (per the 06 "
    "W4 brief); 08 Complaint (CPL-); 46 Drift Assessment (DRFT-); 10 Pricing Scenario (PRSC-, reserved in proposals_w4_economics.py); "
    "11 Competitor Pricing Observation (COFF- composite, reserved there). Typed with the domain number where the prefix is not yet "
    "in decisions.PREFIXES; the two 47 Fee Schedule references are forced in enrich_36 OWNERSHIP_OVERRIDES because the concept "
    "'Fee Schedule' still resolves to the 01 'Fee Schedule / Fee Terms' register row (CW-051 re-cut pending in decisions.py).",
    "To other domains (not edited): 35 PRVW- example 'PRVW-2026-00981-AOV' (CW-935 NOTES) follows the new key with the subject prefix, PRVW-2026-PRD-00981-PPR-01; 35 Filing "
    "Form Type 'State Notice Filing (NSMIA)' is the Fund Filing row of the new State Notice Filing requirement type; 01 Lifecycle "
    "Event Type could add the program and feature values or accept the 'Change of Offering Terms' mapping (SHARED_CANDIDATES); 01 "
    "Product Governance cites 'FINRA Notice to Members 05-26'; the notice is 'NASD Notice to Members 05-26' (36 label; align 01 at W5); "
    "10 already holds Related Change Initiative (content_10), the one direction of the pricing link; "
    "47 Fee Disclosure Delivery has no change-initiative link, which is why the 36 requirement derives its status from the proposed "
    "schedule version; 48, 49, 50 and 52 modules now exist, but the typed Readiness Check references to their set-up objects and "
    "to 52 Sub-Adviser Engagement are deferred to W5 by choice (held as Readiness Check Name text, so the attribute band holds).",
    "MERGE EDIT FOR 01 (program-lead ruling 1, High finding): the live home of platform feature eligibility is the 01 Brokerage "
    "Platform Offering family (feature catalog). 01 adds a platform feature object (proposed name 'Platform Feature', keyed by the "
    "15 Feature Type) with four attributes: Eligible Offerings (Reference (Service Offering) (multi)), Eligible Account "
    "Registration Types (15 Account Registration Type, multi), Required Disclosure Type (15 Disclosure Type) and Client Activation "
    "Required Indicator (Boolean). 36 Platform Feature Specification keeps the same four names as proposed values and names the 01 "
    "target attribute in each note. When the 01 object exists, 36 may add 'Created Platform Feature' (Reference (Platform Feature, "
    "01)) beside Governing Policy Rule, as Share Class and Service Offering Specifications do.",
    "08 complaint path: no merge edit is needed. 08 Complaint carries Account (15) and Product / Share Class; the offering is reached "
    "through 15 Program Enrollment.Enrolled Service Offering effective at the complaint's Received Date. Drift: 46 Drift Assessment "
    "Tolerance Breached Indicator of the Assessed Account, enrolled in the offering through the same 15 path.",
    "Fix-pass deviation from the brief: object kinds follow the brief's text ('keeps the wholesale kind'), not its 9 / 15 table "
    "(ruling 2): 18 Business Objects and 6 Attribute Groups (Business Case Market Evidence, the three structure details, Service "
    "Offering Specification and Platform Feature Specification). The proposals_w4_economics.py CW-936 row says 'Drafted in "
    "proposals_36.py'; the lead should point it at proposals_w4_36.py.",
    "Fix-pass Lows skipped, with reason: Service Offering Specification.Proposed Sponsoring Entity and Proposed Offering Name not "
    "added (the proposal's Proposed Manufacturer Entity and the initiative's Change Title carry them, and the band is at 250); "
    "Requirement Status / Satisfied Date stay Derived (35) with the row rule (the reviewer marked this acceptable). Applied in the "
    "fix pass (with the rulings): Form N-1A Initial Registration and Form CRS Change Communication requirement types; Section 13(a) "
    "and 15(a) on Shareholder Vote; complaints only under Client Outcomes; examples COFF- Advisory Fee Rate and MSR-NNA / Year; "
    "the household wording of Proposed Program Minimum; 47 approval follows the 36 Change Approval; CDE flags (Requirement Country, "
    "Satisfying Filing and Satisfying Firm Filing unflagged so no evidence reference is a CDE; Market Evidence keys flagged); "
    "ETF share class order IC-35786; Form N-14, N-8F and IM 2017-02 confirms dropped; Form CRS General Instruction 8; Form ADV "
    "'promptly' and annual; Names Rule compliance dates (Source_Notes); 9.18(b)(1) and (b)(6); the JURISDICTION 'reading' rows "
    "now carry the bare value. Three more size trims to absorb the additions (no reader): Product Committee Minutes Location, "
    "Product Committee Effective From, Share Class Specification.Proposed Minimum Initial Investment.",
    "Remaining grep hits for EU/UK terms in the module: none ('coll' only inside 'collective'). 'Holding' appears only qualified "
    "('portfolio holdings (18)'); 'position' only as 'fund shareholder positions'; 'custody' only as 'fund custody'.",
]
