"""Consolidation proposals from the W4 adaptation of Data Domain 38 Corporate Compliance & Regulatory Affairs (wealth manager),
2026-10-15.

Proposal fragment only: the builder does not read this file. The program lead merges accepted entries into decisions.py,
shared_code_lists.py and jurisdiction.REMOVALS at the W4 merge. Formats follow CONTRACT.md in this folder. The brief is
00_Program/Rework/Briefs/38_Corporate_Compliance_and_Regulatory_Affairs.md (Disposition: Adapt from keep, CW-167). It
implements CW-162, CW-163, CW-164, CW-165, CW-168, CW-169 and CW-930 (proposals_w4_economics.py), CW-003, CW-013, CW-022,
CW-056 and CW-066 to CW-069 and CW-074, and drafts CW-938, the US-only pass of 38. Module:
content_38_corporate_compliance_and_regulatory_affairs.py (adapted in place; output path and folder unchanged). The expansion
record proposals_38.py is unchanged; this file supersedes nothing in it except where NOTES say so.

Note: CW-938 in proposals_w4_economics.py says "Drafted in proposals_38.py"; per the drafter assignment it is drafted here.
"""

_D, _C = "38", "CW-938"

# ---------------------------------------------------------------------------------------------------------------------
# 1. PREFIXES: none. Kept: FILNG- (form codes add CRS, TA1, TA2, ADVE), EXAM-, POLCY-, REGCH-, RLIST-, TRSV-, CONFL-,
#    MNPI-, OBL-, AUTH-. Form CRS Filing Detail is an attribute group of FILNG-; Adviser Custody Profile (LEN- x effective
#    from) and Custody Surprise Examination (LEN- x examination date) take composite keys; AML and Sanctions Report takes a
#    restricted firm key without a hyphenated stem ("AMLR 2026-00031"), as AML Case ("AML case 2026-0441") and Political
#    Contribution ("PCON 2026-00007").
# ---------------------------------------------------------------------------------------------------------------------
PREFIXES = []

KEY_FORMATS = [   # (object, key format, example)
    ("Form CRS Filing Detail", "FILNG- of the Form CRS filing (attribute group)", "FILNG-CRS-2026-00002"),
    ("Adviser Custody Profile", "LEN- / Custody Profile Effective From", "LEN-0002 / 2026-01-01"),
    ("Custody Surprise Examination", "LEN- / Surprise Examination Date", "LEN-0002 / 2026-08-11"),
    ("AML and Sanctions Report", "AMLR <year>-<sequence, 5 digits> (restricted firm key, no prefix); Reported Case / Report Sequence where filed from a case", "AMLR 2026-00031"),
]
FILING_FORM_CODES = ["ADV", "BD", "CRS", "TA1", "TA2", "ADVE", "13F", "13D", "13G", "13H", "SHO"]   # FILNG-<code>-<year>-<seq>

# ---------------------------------------------------------------------------------------------------------------------
# 2. SHARED_MEMBERSHIPS (38 is a direct user of each list, cited as 'Shared: <name>'; no local copy).
# ---------------------------------------------------------------------------------------------------------------------
SHARED_MEMBERSHIPS = [
    ("Regulator", "Shared: Regulator", "Direct user (unchanged). Entity Authorization.Regulator, Regulatory Change Item.Change "
     "Regulator, Regulatory Examination.Examining Regulator. Examples re-cut to US labels (VALUE_MAPS): the Entity Authorization "
     "example 'CSSF' (removed from the shared list at W1, CW-909) is now 'FINRA'; the STOR Competent Authority example 'FCA' left "
     "with the object. 38 uses SEC, FINRA, US State Securities Regulator, MSRB, OCC, US State Banking Regulator, CFTC / NFA, "
     "DOL / EBSA, FinCEN and OFAC; it no longer uses US State Insurance Regulator (CW-164, CW-165)."),
    ("Business Line", "Shared: Business Line", "Direct user (unchanged). Regulatory Change Impact.Impacted Business Line, example "
     "'DB' (CW-004 code, as 02, 13 and 15)."),
    ("Approval Status", "Shared: Approval Status", "Direct user. Pre-Clearance Request.Pre-Clearance Decision now cites it and the local "
     "Pre-Clearance Decision list is folded (review F; ruling 5): Approved, Approved with Conditions, Not Required and Withdrawn keep "
     "their labels; Denied becomes Rejected (VALUE_MAPS)."),
    ("Business Domain", "External (09 Shared - Business Domain)", "PROPOSED direct user: register '38' in direct_users of Business "
     "Domain (Regulatory Change Impact.Impacted Data Domain, example '48 Brokerage Orders & Execution'). Until then the attribute cites "
     "the list as External, because the builder refuses 'Shared: Business Domain' for an unregistered domain."),
    ("Case Status", "Shared: Case Status", "Direct user (unchanged)."),
    ("Severity", "Shared: Severity", "Direct user (unchanged)."),
    ("Record Status", "Shared: Record Status", "Direct user (unchanged)."),
    ("Frequency", "Shared: Frequency", "Direct user (unchanged)."),
    ("Information Classification", "Shared: Information Classification", "Direct user (unchanged)."),
    ("Risk Rating", "Shared: Risk Rating", "Direct user (unchanged)."),
]

VALUE_MAPS = {   # 38 example label -> shared code (direct-user examples)
    "Regulator": {"SEC": "US_SEC", "FINRA": "US_FINRA", "OCC": "US_OCC", "MSRB": "US_MSRB", "FinCEN": "US_FINCEN",
                  "OFAC": "US_TREASURY_OFAC", "DOL / EBSA": "US_DOL_EBSA", "US State Securities Regulator": "US_STATE_SECURITIES_REGULATOR",
                  "US State Banking Regulator": "US_STATE_BANKING_REGULATOR", "CFTC / NFA": "US_CFTC_NFA",
                  # removed examples (were unmapped since the W1 re-cut, CW-909)
                  "CSSF": None, "FCA": None},
    "Business Line": {c: c for c in ("DB", "DA", "HA", "PF", "WR", "IA", "IC", "TR")},
    "Approval Status (from the folded Pre-Clearance Decision)": {"Approved": "APPROVED", "Approved with Conditions": "APPROVED_WITH_CONDITIONS",
                                                                 "Denied": "REJECTED", "Not Required": "NOT_REQUIRED", "Withdrawn": "WITHDRAWN"},
}

# ---------------------------------------------------------------------------------------------------------------------
# 3. SHARED_CANDIDATES (list in 38, proposed shared name, other users, note)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_CANDIDATES = [
    ("Surveillance Scenario", None, ["08"],
     "08 Surveillance Scenario (SCEN-) is an object holding sales-practice scenarios; 38 holds market-abuse scenarios as a local "
     "list on Trade Surveillance Alert. Keep apart (CW-163); if the firm runs one surveillance team, the lever is a scenario "
     "ownership attribute on the 08 object, not a merged list (brief SME question 5)."),
    ("Personal Trade Side", None, ["25", "48"],
     "Folded (ruling 5): Personal Transaction.Personal Trade Side and Pre-Clearance Request.Pre-Clearance Side cite External (25 Order "
     "Side). 25 Order Side lacks 'Exercise' and 'Gift / Transfer', which personal trading needs: propose them to 25 (or read the 48 "
     "side list if 48 holds them)."),
    ("Custody Basis", None, ["47"],
     "47 Fee Deduction Authorization holds a 'Rule 206(4)-2 basis'; if 47 uses a list, it should read these values (Fee "
     "Deduction is the one 47 records). Recommend 47 reads the 38 list, no shared list."),
    ("Form CRS Filer Capacity", None, ["15", "13", "08"],
     "15 Account Disclosure Delivery, 13 updated-delivery communications and 08 Disclosure Delivery Check may need the capacity of "
     "the version delivered; they read it from the 38 Form CRS Filing Detail by reference. Keep local."),
    ("AML Case Source", None, ["29", "50"],
     "Values name the source records (29, 50, 02, 40, 38, 314(a)); keep local."),
    ("Conflict Category", None, ["08", "10"],
     "08 Incentive Conflict Review and 10 Cash Program Economics may tag the 38 category; they reference the CONFL- entry. Keep local."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 4. TERM_CONFLICTS (decisions.TERM_CONFLICTS format; CW-169 terms that touch 38)
# ---------------------------------------------------------------------------------------------------------------------
TERM_CONFLICTS = []   # no new terms (review, ruling 7): the 38 usages amend existing decisions.TERM_CONFLICTS entries below

TERM_CONFLICT_AMENDMENTS = [   # (existing term in decisions.TERM_CONFLICTS, change, decision)
    ("Custody (wealth model)",
     "Add usage ('38', 'Adviser Custody Profile; Custody Surprise Examination', 'Adviser Custody Status: the adviser's Rule 206(4)-2 "
     "status and its surprise examinations'). Recommendation and resolution add 'Adviser Custody Status' (38) beside 'Client Asset "
     "Custody' (49) and 'Fund Custody' (28); 47 Fee Deduction Authorization is per-account evidence of one custody basis.", "CW-169"),
    ("Program (wealth model)",
     "Add usages ('38', 'Compliance program; AML program (Program Review Type)', 'Compliance programs of a regulated entity') and "
     "('41', 'Information Security Program', 'Regulation S-P and S-ID safeguards programs that 38 reviews'). Qualify as 'Compliance "
     "Program' and 'AML Program' (38), 'Information Security Program' (41).", "CW-169"),
    ("Review / Assessment",
     "Replace the wholesale 08 usage ('Compliance Review (REV-); Distribution Review Finding') with ('08', 'Supervisory Review (PRNR-); "
     "Compliance Review (REV-)'); add ('38', 'Compliance Program Review', 'Periodic review of a compliance program') and ('45', 'Advice "
     "Review'); the 36 usage drops 'assessment of value, fair value assessment' (CW-161). Qualify as 'Compliance Program Review' (38).", "CW-169"),
    ("Conflict",
     "Drop the retired usages ('08', 'Distribution Conflict of Interest (COI-)', dropped by CW-067) and ('07', 'Remuneration Conflict "
     "Assessment', 07 retired by CW-907); add ('08', 'Incentive Conflict Review', 'Supervisory review of incentive conflicts named in "
     "the 38 register'). Resolution: primary sense 38 'Conflict of Interest' (CONFL-); 08 reviews, 10 measures (CW-168).", "CW-168"),
    ("Attestation",
     "Drop the usage ('08', 'Attestation ...'): the object moved to 38 at Stage 4 (CD-252) and the W2 08 holds none. Recommendation: "
     "'Attestation' is 38's; 08 references 38 Attestations (Rule 3130 certification).", "CW-066"),
    ("Surveillance (new usage note, if the lead logs it under CW-169)",
     "38 Trade Surveillance Alert (market abuse); 08 Surveillance Scenario, Sales Practice Alert and Surveillance Alert; 50 and 29 "
     "transaction monitoring alerts. Only log as a new term if decisions.TERM_CONFLICTS holds no surveillance entry at the merge.", "CW-169"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 5. JURISDICTION (jurisdiction.REMOVALS entry format; CW-022). jurisdiction.REMOVALS held no 38 entry before this draft
#    (checked 2026-10-15), so nothing here duplicates an earlier pass.
# ---------------------------------------------------------------------------------------------------------------------


def _j(obj, attr, regime, note):
    return {"domain": _D, "object": obj, "attribute": attr, "regime": regime, "decision": _C, "note": note}


_EAT, _RA = "Code list: Entity Authorization Type", "Code list: Regulated Activity"

JURISDICTION = [
    # Objects
    _j("Cross-Border Passport", "", "UCITS",
       "UCITS management company, AIFMD and MiFID II passports (regimes UCITS, AIFMD, MiFID II; 6 attributes: Passport Home Entity, "
       "Host Country, Passport Type, Notification Date, Passport Status, Passport Effective From / To). US firms register state by "
       "state: Entity Authorization rows with Authorization Jurisdiction (CW-069)."),
    _j("Suspicious Transaction and Order Report", "", "Other EU/UK",
       "EU and UK Market Abuse Regulation Article 16 STOR (regime: MAR; 5 attributes: STOR Source Alert, STOR Competent Authority, "
       "STOR Submitted Timestamp, STOR Authority Reference, Suspicion Description). The US route is Trade Surveillance Alert -> AML "
       "Case -> FinCEN SAR (31 CFR 1023.320), CW-163."),
    # Whole code lists
    _j("Code list: Passport Type", "", "UCITS",
       "UCITS ManCo Freedom to Provide Services and Branch, AIFM Management and Marketing Passports, MiFID Services and Branch Passports "
       "(regimes UCITS, AIFMD, MiFID II). Left with Cross-Border Passport."),
    # Entity Authorization Type values
    _j(_EAT, "FCA Part 4A Permission", "FCA", "UK authorization."),
    _j(_EAT, "UK UCITS Management Company / ACD", "FCA", "UK fund manager authorization."),
    _j(_EAT, "UK AIFM (Full-Scope)", "AIFMD", "UK AIFMD regime."),
    _j(_EAT, "UCITS Management Company (Chapter 15)", "UCITS", "Luxembourg 2010 Law."),
    _j(_EAT, "Authorized AIFM", "AIFMD", "AIFMD Article 6."),
    _j(_EAT, "Registered (Sub-Threshold) AIFM", "AIFMD", ""),
    _j(_EAT, "Super ManCo", "UCITS", "UCITS ManCo and AIFM (regimes UCITS, AIFMD)."),
    _j(_EAT, "MiFID Investment Firm License", "MiFID II", ""),
    _j(_EAT, "Irish UCITS Management Company", "UCITS", "Central Bank of Ireland."),
    _j(_EAT, "Irish AIFM", "AIFMD", "Central Bank of Ireland."),
    # Regulated Activity values (list re-cut to Form BD and Form ADV business types)
    _j(_RA, "Managing a UCITS", "UCITS", "UCITS Annex II. The list is re-cut to US business types (Carrying and Clearing, Retail Brokerage, Options, Margin, Municipal Securities, Fund Principal Underwriting, Investment Advisory Programs, Wrap Fee Sponsor, Transfer Agency, Fiduciary Services, Other)."),
    _j(_RA, "Managing an AIF", "AIFMD", "AIFMD Annex I."),
    _j(_RA, "Collective Portfolio Management - Investment Management", "UCITS", "UCITS Annex II / AIFMD Annex I."),
    _j(_RA, "Collective Portfolio Management - Administration", "UCITS", "UCITS Annex II / AIFMD Annex I."),
    _j(_RA, "Collective Portfolio Management - Marketing / Distribution", "UCITS", "UCITS Annex II / AIFMD Annex I."),
    _j(_RA, "Discretionary Portfolio Management (MiFID top-up)", "MiFID II", "UCITS Article 6(3) / AIFMD Article 6(4) top-up services."),
    _j(_RA, "Investment Advice (MiFID top-up)", "MiFID II", ""),
    _j(_RA, "Reception and Transmission of Orders (MiFID top-up)", "MiFID II", ""),
    _j(_RA, "Arranging Deals in Investments", "FCA", "FCA Regulated Activities Order."),
    _j(_RA, "Dealing as Agent", "FCA", "FCA Regulated Activities Order."),
    _j(_RA, "Acting as Authorised Fund Manager / ACD", "FCA", ""),
    # Source Regulation values
    _j("Code list: Source Regulation", "FCA Handbook", "FCA", "MSRB Rules, FinCEN / BSA Regulations, OCC Regulations, DOL / ERISA and Other added."),
    _j("Code list: Source Regulation", "EU Regulation / Directive", "Other EU/UK", "EU legislation."),
    _j("Code list: Source Regulation", "ESMA Guidelines", "Other EU/UK", "ESMA."),
    # Firm Filing Form Type values
    _j("Code list: Firm Filing Form Type", "TR-1 / Major Holdings Notification", "Other EU/UK", "EU Transparency Directive Article 9 and UK DTR 5."),
    _j("Code list: Firm Filing Form Type", "EU Net Short Position Notification", "Other EU/UK", "Short Selling Regulation (EU) 236/2012. US short reporting is Form SHO (Rule 13f-2), kept."),
    _j("Code list: Firm Filing Form Type", "UK Net Short Position Notification", "Other EU/UK", "UK short selling regime."),
    _j("Code list: Firm Filing Form Type", "CASS CMAR", "CASS", "FCA Client Money and Asset Return. The broker-dealer's Rule 15c3-3 reserve is 49; FOCUS reports are 19 / 43."),
    # Disclosure Regime values
    _j("Code list: Disclosure Regime", "EU Transparency Directive Major Holdings", "Other EU/UK", "Foreign issuers stay in scope under the US regimes (investment-universe principle)."),
    _j("Code list: Disclosure Regime", "UK DTR 5 Major Holdings", "FCA", ""),
    _j("Code list: Disclosure Regime", "EU Short Selling Regulation Net Short Position", "Other EU/UK", ""),
    _j("Code list: Disclosure Regime", "UK Net Short Position", "Other EU/UK", "UK short selling regime."),
    # Other values
    _j("Code list: Examination Type", "Thematic Review", "FCA", "FCA or NCA multi-firm review; the US equivalent is Sweep, kept."),
    _j("Code list: Program Review Type", "MLRO Annual Report", "FCA", "FCA SYSC 6.3. US AML program testing is AML Program Assessment.Independent Test Date (FINRA Rule 3310)."),
    _j("Code list: Program Review Type", "Compliance Function Annual Report", "Other EU/UK", "FCA SYSC 6, ESMA compliance guidelines and CSSF / CBI reporting (regimes FCA, MiFID II)."),
    _j("Code list: Conduct Designation Type", "Relevant Person", "MiFID II", "MiFID II / COBS 11.7 personal account dealing; FINRA Rule 3210 Associated Person added."),
    _j("Code list: Conduct Designation Type", "Insider-List-Eligible", "Other EU/UK", "MAR Article 18 permanent insider candidate."),
    _j("Code list: Personal Account Type", "ISA / SIPP", "UK market practice", "UK tax wrappers (UK market practice); 529 Plan Account added."),
    _j("Code list: AML Institution Type", "UK Relevant Person (MLR 2017)", "Other EU/UK", "UK Money Laundering Regulations 2017."),
    _j("Code list: AML Institution Type", "EU Obliged Entity (AMLD)", "Other EU/UK", "EU AML Directive."),
    _j("Code list: AML Report Type", "UK SAR to National Crime Agency", "Other EU/UK", "POCA 2002 / Terrorism Act 2000."),
    _j("Code list: AML Report Type", "EU FIU Suspicious Transaction Report", "Other EU/UK", "EU AML Directive."),
    _j("Code list: AML Report Type", "UK OFSI Frozen Asset Report", "Other EU/UK", "UK sanctions; OFAC reports kept; FinCEN 314(a) Match Report added."),
    _j("Code list: Surveillance Disposition", "Escalated - STOR", "Other EU/UK", "MAR Article 16; escalation is Escalated - AML Case."),
    # Sources
    _j("Sources", "FCA Handbook: SYSC 6 (compliance and MLRO), SYSC 10 (conflicts), SUP 15, COBS 11.7 (personal account dealing), DTR 5, SM&CR", "FCA",
       "Conflict references re-sourced to Form ADV Part 2A and Rule 15l-1; personal dealing to Rule 204A-1 and FINRA Rule 3210; "
       "Obligation Owner's SM&CR reference removed (regimes FCA, SM&CR)."),
    _j("Sources", "MiFID II Delegated Regulation (EU) 2017/565, Articles 22, 29 and 33-35", "MiFID II", ""),
    _j("Sources", "ESMA Guidelines on certain aspects of the MiFID II compliance function requirements (ESMA35-36-1952) and CSSF Circular 18/698", "Other EU/UK", "ESMA and CSSF (regime MiFID II)."),
    _j("Sources", "Market Abuse Regulation (EU) 596/2014 Articles 7, 11, 16, 17, 18 and 19, UK MAR, Commission Delegated Regulation (EU) 2016/957 and Implementing Regulation (EU) 2022/1210", "Other EU/UK",
       "Regime MAR. Restricted list, MNPI and insider list references re-sourced to Advisers Act Section 204A and Exchange Act "
       "Section 15(g); surveillance scenarios to FINRA Rules 5270, 5320 and 3110."),
    _j("Sources", "UK Money Laundering, Terrorist Financing and Transfer of Funds Regulations 2017 (part of the combined source with FATF Recommendations)", "Other EU/UK",
       "FATF Recommendations kept as a separate secondary source (confirm)."),
    _j("Sources", "EU Transparency Directive 2004/109/EC Article 9 and Short Selling Regulation (EU) 236/2012", "Other EU/UK", ""),
    _j("Sources", "UCITS Directive 2009/65/EC, AIFMD 2011/61/EU (as amended by 2024/927), MiFID II 2014/65/EU", "UCITS", "Regimes UCITS, AIFMD, MiFID II."),
    _j("Sources", "FCA, CSSF and Central Bank of Ireland public registers (part of the combined register source)", "FCA",
       "The source is kept as SEC, FINRA and OCC public registers and NASAA guidance; FCA Connect and the CSSF eDesk left the tool lists."),
]

# ---------------------------------------------------------------------------------------------------------------------
# 6. REPOINTS (object, attribute, before, after, decision): re-cuts, renames and re-pointed references that are not EU/UK removals.
# ---------------------------------------------------------------------------------------------------------------------
REPOINTS = [
    ("MNPI Escalation", "Source Deal", "Reference (Deal) to 30 PDL-", "removed (30 retires; W4_Retirement_of_07_and_30.md section 5)", "CW-930"),
    ("Code list: MNPI Source Type", "Private Markets Deal", "Private Markets Deal (30)", "removed", "CW-930"),
    ("Relationships", "MNPI Escalation may originate from", "Deal [30] / Engagement [34]", "Engagement [34]", "CW-930"),
    ("Conflict Mitigation", "Client Consent Obtained Indicator", "LPAC and fund board consents recorded in 30 and 35", "fund board consents recorded in 35", "CW-930"),
    ("Code list: Entity Authorization Type", "State Insurance License", "State Insurance License", "removed (insurance-dedicated residue)", "CW-165"),
    ("Code list: Conflict Category", "Insurer Client Relationship", "Insurer Client Relationship", "removed (insurance-dedicated residue)", "CW-165"),
    ("Code list: Conflict Category", "Distribution and Remuneration", "Distribution and Remuneration (profiled in 08 Distribution Conflict of Interest, dropped by CW-067)",
     "replaced by Revenue Sharing and Platform Payments and Advisor Compensation; Proprietary Products in Advice, Cash Sweep Economics, Account Type Recommendation, Principal Trading with Clients and Trust Company Self-Dealing added", "CW-168"),
    ("Relationships", "Conflict of Interest is profiled for distribution by", "Distribution Conflict of Interest [08] (COI-)", "removed (08 object dropped, CW-067); Incentive Conflict Review [08] and Cash Program Economics [10] rows added", "CW-168"),
    ("Code list: Entity Authorization Type", "Municipal Advisor / MSRB Registration", "Municipal Advisor / MSRB Registration", "Municipal Securities Dealer / MSRB Registration (the broker-dealer sells 529 plans; not a municipal advisor)", "CW-162"),
    ("Code list: Entity Authorization Type", "(new values)", "", "SIPC Membership; State Broker-Dealer Registration; Transfer Agent Registration (Form TA-1); Other", "CW-162"),
    ("Code list: Regulated Activity", "Investment Company Principal Underwriting", "Investment Company Principal Underwriting", "Fund Principal Underwriting", "CW-162"),
    ("Code list: Firm Filing Form Type", "Form ADV Part 3 (Form CRS)", "Form ADV Part 3 (Form CRS)", "Form CRS (adviser via IARD as Part 3; broker-dealer via CRD); Form TA-1, Form TA-2 and Form ADV-E added", "CW-162"),
    ("Code list: Disclosure Regime", "Other National Regime", "Other National Regime", "Other Ownership Limit (US sector-specific limits)", "CW-938"),
    ("Code list: Regulatory Change Instrument Type", "Consultation Paper; Supervisory Statement / Priorities", "Consultation Paper; Supervisory Statement / Priorities",
     "Request for Comment / Concept Release; Examination Priorities / Risk Alert; SRO Rule Filing added", "CW-938"),
    ("Code list: Policy Domain", "Distribution", "Distribution (policies referenced by 08)", "Retail Conduct (written supervisory procedures applied by 08); Privacy and Financial Crime added", "CW-066"),
    ("Code list: Program Review Type", "(new values)", "", "PTE 2020-02 Retrospective Review; Regulation S-P Program Review; Regulation S-ID Annual Report", "CW-162"),
    ("Code list: Conduct Designation Type", "(new value)", "", "Associated Person (FINRA Rule 3210)", "CW-162"),
    ("Code list: OBA Type", "(new values)", "", "Borrowing or Lending with Customer (Rule 3240); Customer Beneficiary or Fiduciary Appointment (Rule 3241)", "CW-074"),
    ("Code list: AML Institution Type", "Bank / Trust Company", "Bank / Trust Company (CIT trustee)", "Bank / Trust Company (31 CFR 1020) for the optional trust line", "CW-162"),
    ("Code list: AML Case Source", "(new values)", "", "Money Movement Monitoring Alert (50); FinCEN 314(a) Request", "CW-163"),
    ("Code list: AML Report Type", "(new value)", "", "FinCEN 314(a) Match Report", "CW-162"),
    ("Code list: Surveillance Scenario", "(new values)", "", "Front Running of Customer Orders (FINRA Rule 5270); Trading Ahead of Customer Orders (FINRA Rule 5320)", "CW-163"),
    ("Code list: Restricted List Type", "Insider List", "MAR Article 18 insider list", "Wall-crossing log (Advisers Act Section 204A, Exchange Act Section 15(g)); sections 'matter-specific' and 'standing access'", "CW-938"),
    ("Trade Surveillance Alert", "Subject Client Orders; Subject Client Executions", "", "added: Reference (Client Order, 48) (multi), Reference (Client Execution, 48) (multi)", "CW-163"),
    ("AML Case", "Source Money Movement Monitoring Alert", "", "added: Reference (Money Movement Monitoring Alert, 50), MMALT-", "CW-163"),
    ("AML and Sanctions Report", "AML Report Key", "", "added: restricted firm key AMLR <year>-<sequence>; Reported Case no longer CDE and blank for an OFAC report filed without a case; Report Sequence kept (blank without a case)", "CW-163"),
    ("Firm Regulatory Filing", "Form CRS Filing Detail", "", "added attribute group (5 attributes)", "CW-162"),
    ("Adviser Custody Profile; Custody Surprise Examination", "", "", "added business objects (9 and 5 attributes) in the new subfamily Adviser Custody Status", "CW-162"),
    ("Entity Authorization", "Regulator", "example CSSF", "example FINRA", "CW-938"),
    ("Entity Authorization", "Regulator Reference Number", "SEC 801- file number, CRD, FRN, CSSF / CBI reference; example S00001234", "SEC 801-, 8- and 84- file numbers, CRD, MSRB, NFA, OCC, large trader ID; example CRD 999901 (fictitious)", "CW-938"),
    ("Entity Authorization", "Authorization Type; Permitted Activities", "UCITS and FCA examples and sources", "Broker-Dealer Registration and FINRA Membership; Carrying and Clearing; Retail Brokerage; Options; Margin (Form BD, Form ADV)", "CW-938"),
    ("Regulatory Change Impact", "Impacted Business Line", "example blank", "example DB (CW-004)", "CW-004"),
    ("Family", "Policies & Attestations (CO-POL)", "Policies & Attestations", "Policies, Attestations & Program Reviews (code kept)", "CW-162"),
    ("Family", "Conflicts of Interest (CO-CNF)", "Conflicts of Interest", "Conflicts & Outside Activities (code kept)", "CW-168"),
    ("Personal Trading Account", "Firm Brokerage Account", "", "added: Reference (Account, 15); Personal Account Broker blank for in-house accounts; row rules make in-house Reported Personal Holding and Personal Transaction values Derived copies of 49 Client Holding and 48 Client Execution (review W1 High; ruling 1)", "CW-007"),
    ("Code list: Personal Trading Data Source", "Firm Books and Records", "", "added (in-house rows); Broker Feed now means an outside broker", "CW-007"),
    ("AML Case", "Source Account Monitoring Alert; Source Money Movement Monitoring Alert", "Reference (Account Monitoring Alert); Reference (Money Movement Monitoring Alert, 50)", "removed: held once on 29 Alert Disposition.Escalation Case Reference and 50 Money Movement Monitoring Alert.Escalated AML Case (ruling 2)", "CW-163"),
    ("Code list: AML Case Source", "Shareholder Account Monitoring Alert (29)", "Shareholder Account Monitoring Alert (29)", "Account Monitoring Alert (29); Senior Investor Case (08) added", "CW-163"),
    ("Regulatory Obligation", "Applicable Legal Entity", "Code, Legal Entity (firm-defined), Derived (09)", "Reference (Legal Entity), LEN- (review D Low)", "CW-938"),
    ("Pre-Clearance Request", "Pre-Clearance Decision", "local list Pre-Clearance Decision", "Shared: Approval Status (Denied -> Rejected)", "CW-938"),
    ("Personal Transaction; Pre-Clearance Request", "Personal Trade Side; Pre-Clearance Side", "local list Personal Trade Side", "External (25 Order Side)", "CW-938"),
    ("Regulatory Change Impact", "Impacted Data Domain", "Firm-defined (Data Domain register)", "External (09 Shared - Business Domain)", "CW-164"),
    ("Conflict Mitigation", "Mitigation Sequence", "", "added (key CONFL-<n> / M<nn>, read by 08 Incentive Conflict Review)", "CW-168"),
    ("Code list: Conduct Designation Type", "Municipal Finance Professional", "", "added (MSRB Rule G-37)", "CW-162"),
    ("Code list: Surveillance Scenario", "Front Running of Customer Orders; Front Running; Insider Dealing", "Front Running of Customer Orders; Front Running; Insider Dealing", "Front Running of Block Transactions (Rule 5270); Front Running of Portfolio Orders; Insider Trading", "CW-163"),
    ("Code list: Examination Type", "Desk-Based Review", "Desk-Based Review", "Remote Examination; Routine Examination defined as risk-based", "CW-938"),
    ("Subfamily", "Personal Dealing", "Personal Dealing", "Personal Trading", "CW-938"),
    ("Code list: Pay-to-Play Outcome; MNPI Source Type; Restriction Reason", "(new values)", "", "Not Applicable; Other; Other", "CW-938"),
    ("Adviser Custody Profile", "Operationally Independent Related Person Indicator; Surprise Examination Required Indicator; Custody Bases", "examples N; Y; Fee Deduction; Standing Letter of Authorization; Related Person Qualified Custodian", "examples Y; N; Fee Deduction; Related Person Qualified Custodian (brief lever 2 default)", "CW-162"),
    ("Obligation examples", "Obligation ID", "OBL-DC-0142", "OBL-BD-0142", "CW-938"),
    ("Kind", "Regulatory Change Impact; Regulator Request Item; Examination Finding; Policy Version; Conflict Mitigation", "Business Object", "Attribute Group (brief section 5; grain unchanged)", "CW-938"),
]

# ---------------------------------------------------------------------------------------------------------------------
# 7. DECISIONS: the US-only pass of 38 (pre-allocated by CW-022; proposed in proposals_w4_economics.py)
# ---------------------------------------------------------------------------------------------------------------------
DECISIONS = [
    {"id": "CW-938", "theme": "Scope", "title": "US-only pass of 38 Corporate Compliance & Regulatory Affairs",
     "domains": ["38", "08", "48", "49", "50", "47", "41", "15", "13"],
     "issue": "The wholesale 38 holds FCA, CSSF and Central Bank of Ireland authorizations, EU passports, MAR insider lists and "
              "STORs, SM&CR-adjacent compliance reporting, EU and UK major-holdings and short-selling notifications, CASS CMAR and UK "
              "and EU AML regimes, and sources its conflicts register to FCA SYSC 10 and its PII note to GDPR.",
     "resolution": "Removed (55 JURISDICTION entries: 2 objects, 1 whole code list, 44 code values, 8 sources): objects Cross-Border "
                   "Passport (6 attributes) and Suspicious Transaction and Order Report (5 attributes) with the list Passport Type; "
                   "Entity Authorization Type values FCA Part 4A Permission, UK UCITS Management Company / ACD, UK AIFM, UCITS "
                   "Management Company (Chapter 15), Authorized AIFM, Registered AIFM, Super ManCo, MiFID Investment Firm License, "
                   "Irish UCITS Management Company, Irish AIFM; the 11 FCA, UCITS, AIFMD and MiFID Regulated Activity values; Source "
                   "Regulation FCA Handbook, EU Regulation / Directive, ESMA Guidelines; Firm Filing Form Type TR-1, EU and UK Net Short "
                   "Position, CASS CMAR; Disclosure Regime EU Transparency Directive, UK DTR 5, EU and UK short selling; Examination "
                   "Type Thematic Review; Program Review Type MLRO Annual Report and Compliance Function Annual Report; Conduct "
                   "Designation Type Relevant Person and Insider-List-Eligible; Personal Account Type ISA / SIPP; AML Institution Type "
                   "UK Relevant Person and EU Obliged Entity; AML Report Type UK SAR, EU FIU STR, UK OFSI; Surveillance Disposition "
                   "Escalated - STOR; sources FCA Handbook, MiFID II Delegated Regulation 2017/565, ESMA and CSSF compliance guidance, "
                   "MAR, UK MLR 2017, EU Transparency Directive and SSR, UCITS / AIFMD / MiFID II and the FCA, CSSF and CBI registers. "
                   "Kept and re-sourced: Entity Authorization (Regulator Reference Number to SEC file numbers, CRD, MSRB, NFA and OCC "
                   "numbers; Permitted Activities to Form BD and Form ADV business types; status to IARD and CRD); Firm Filing Regulator "
                   "Reference to EDGAR and IARD; Ownership Disclosure Determination to Sections 13(d), 13(g), 16 and Rule 13f-2 (foreign "
                   "issuers stay); Firm Restricted List, Restricted List Entry, MNPI Escalation and Insider List Entry (now the "
                   "wall-crossing log) to Advisers Act Section 204A and Exchange Act Section 15(g); Trade Surveillance Alert scenarios "
                   "to FINRA Rules 5270, 5320 and 3110, with escalation to an AML Case and SAR; Conflict of Interest to Form ADV Part 2A "
                   "and Rule 15l-1; code of ethics to Rule 204A-1, Rule 17j-1 and FINRA Rule 3210; AML Program Assessment to FINRA Rule "
                   "3310 and 31 CFR Chapter X; Obligation Owner's SM&CR reference removed; Notes PII re-sourced from GDPR to Regulation "
                   "S-P and state privacy law. Perspective: META subtitle 'Wealth manager (direct) | Scope: US', overview rewritten for "
                   "the adviser, self-clearing broker-dealer, funds, transfer agent and trust company. Adaptation applied in the same "
                   "pass (CW-162, CW-163, CW-168, CW-074, CW-165, CW-930): Form CRS Filing Detail, Adviser Custody Profile and Custody "
                   "Surprise Examination added; client orders and executions (48) added to trade surveillance; 50 alerts and 314(a) "
                   "requests added as AML case sources (29, 50 and 08 Senior Investor Case hold their links); in-house personal trading rows are Derived copies of 48 and 49; AML and Sanctions Report keyed without a case; wealth conflict categories and "
                   "Rule 3240 / 3241 OBA types; insurance values and the 30 Source Deal removed. Counts (built, after the review fix pass): 35 to 36 objects (2 "
                   "to 8 attribute groups), 280 to 291 attributes, 87 to 101 CDEs (35%), 53 to 53 code lists (44 local, 9 shared), 59 to 65 references.",
     "rationale": "CW-003 and CW-022: the firm is registered, examined and files in the US only, so EU and UK authorizations, passports, "
                  "MAR reporting and UK and EU AML regimes have nothing to serve; every generic compliance object stays with its US "
                  "rule. Names are kept so that DP-222 to DP-230 and their models keep resolving except for the removed objects "
                  "(NOTES, READERS). Lever: a UK extension restores the removed rows from wholesale-v1.0 through the jurisdiction register.",
     "action": "W4", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]

# ---------------------------------------------------------------------------------------------------------------------
# 8. NOTES for the W4 merge
# ---------------------------------------------------------------------------------------------------------------------
NOTES = [
    # Readers. Line numbers as of 2026-10-15.
    "READERS OF REMOVED 38 CONTENT (live). Data products: DP-222 specs_e4_compliance_legal.py 13-14 (description names EU and UK "
    "major holdings, short position notifications and CASS CMAR), 79-80 (Passport Without Home Authorization Flag on Cross-Border "
    "Passport), 88-89 (Cross-Border Passport columns), 133-134 (UK DTR 5, EU Transparency Directive and short selling thresholds in "
    "notes); DP-224 line 270 (MLRO report in the description); DP-226 lines 594-599 (UK SAR to the NCA, MLRO, OFSI in description and "
    "question), 689 (POCA tipping-off note); DP-227 lines 760 (MNPI Escalation.Source Deal column), 800-801 (UK and EU insider lists "
    "in notes); DP-228 lines 807-911 (STOR throughout: description, questions 816-817, grain 820, Disposition Mix 835 'escalated - "
    "STOR', STOR Count and Rate 838-841, Alert-to-STOR Days 843-846, Escalated Without STOR Flag 847-850, columns 868-869, timeliness "
    "887, history 888, rule 895, notes 901-911). Data models: models_e8c_compliance_legal.py 63-64, 88, 105-106 (Fact Cross-Border "
    "Passport, Host Country dimension), 596 (Source Deal descriptive column), 611-614 and 658 (Fact STOR). Semantic model: "
    "sm_16_risk_compliance_legal_audit.py 455-459 and 844-847 (cross_border_passport entity and joins, DP-222). Keys: "
    "keys_e7_37_38.py 221-223, 422, 434 and keys_g9_37_44.py 22, 32 (superseded at WP2). Pending (CW-041): DP-041 specs_f_compliance.py "
    "537-574 (Cross-Border Passport; retire at WP0 per the brief), DP-083; models_c4_compliance.py 502-503, 562-564 (Fact "
    "Cross-Border Passport). Consolidation registers (WP0 clean-up): gaps_register.py line 4062 (STOR object list); "
    "proposals_dp_corporate_b.py lines 269 (Cross-Border Passport) and 366 (STOR).",
    "READERS OF FIX-PASS CHANGES. AML Case.Source Account Monitoring Alert removed (ruling 2): DP-226 specs_e4_compliance_legal.py 614 "
    "(measure input), 650 (column), 679 (rule 'exactly the source reference that matches it'); models_e8c_compliance_legal.py 498 (rel "
    "Fact AML Case -> Account Monitoring Alert); keys_e7_37_38.py 408. Proposal: DP-226 reads the link from 29 Alert Disposition."
    "Escalation Case Reference and 50 Money Movement Monitoring Alert.Escalated AML Case (join from the alert side); the rule becomes "
    "'every AML Case with a 29 or 50 source is referenced by at least one alert'. Pre-Clearance Decision now Shared: Approval Status: "
    "DP-225 lines 430 and 473 ('denied') read 'Rejected'; 559 ('approved') unchanged. Regulatory Obligation.Applicable Legal Entity "
    "re-typed to Reference (Legal Entity): DP-224 lines 291, 299, 349, 387, DP-248 specs_e5_cross_area.py 1166-1167 and 1209, DP-082 "
    "specs_n_compliance_controls.py 250-302 keep the name; the model notes at models_e8c_compliance_legal.py 277-278 and "
    "models_c8_compliance2.py 643-680 ('not typed as a reference', 'taxonomy gap') can be closed. Personal Trade Side and "
    "Impacted Data Domain (DP-225 460 and 514; models_e8c_compliance_legal.py 152-156; keys_e7_37_38.py 149) keep names and values.",
    "READERS (disposition, proposal). DP-222 and SM-16: drop Cross-Border Passport (fact, dimension Host Country, the flag and the "
    "joins) and the EU and UK regime text; optionally add Form CRS Filing Detail and Adviser Custody Profile at WP0. DP-224: reword the "
    "MLRO mention; new Program Review Type values need no column change. DP-226: reword the UK and MLRO text; AML and Sanctions "
    "Report keeps Reported Case and Report Sequence (unchanged columns) and gains AML Report Key, which should become the fact key "
    "(keys_e7_37_38.py 209 and models_e8c_compliance_legal.py 463 'pk Reported Case, Report Sequence' fail for case-less OFAC reports). "
    "DP-227: drop Source Deal. DP-228: re-scope at WP0 to surveillance and AML escalation (brief section 9): drop the STOR fact, the "
    "three STOR measures and the STOR rules; Disposition Mix reads 'Escalated - AML Case'; add Subject Client Orders and Subject Client "
    "Executions (48) as subjects. Live readers that resolve unchanged: DP-013, DP-205, DP-216, DP-223, DP-225, DP-229, DP-230, DP-234, "
    "DP-238, DP-246, DP-248 and DP-121 (kept names; family renames do not affect (domain, object, attribute) keys).",
    "Renames for the baseline check: families Policies & Attestations -> Policies, Attestations & Program Reviews (CO-POL) and "
    "Conflicts of Interest -> Conflicts & Outside Activities (CO-CNF), codes kept; new subfamily Adviser Custody Status. No object or "
    "attribute is renamed. Attribute IDs are positional within a family and renumber in CO-REG (Cross-Border Passport removed, Form "
    "CRS Filing Detail added), CO-POL (custody objects added), CO-AML (two attributes added) and CO-MKT (Source Deal, STOR removed; two "
    "subjects added); readers use names. Kind changes BO -> AG for Regulatory Change Impact, Regulator Request Item, Examination "
    "Finding, Policy Version and Conflict Mitigation (brief section 5: 28 BO, 8 AG).",
    "domains.py: DISPOSITION['38'] becomes ('adapt', '') at the W4 merge (CW-167). DD_NAMES unchanged.",
    "CW-163 AML case links (program-lead ruling 2, which supersedes the coordinator's first request): the alert side holds the "
    "link. 29 Alert Disposition.Escalation Case Reference, 50 Money Movement Monitoring Alert.Escalated AML Case and (proposed for 08 at "
    "the merge) a Senior Investor Case reference to the AML Case are the masters; the single-valued AML Case.Source Account Monitoring "
    "Alert and Source Money Movement Monitoring Alert were dropped, and the relationship rows say which side holds each link. AML Case "
    "Source adds 'Senior Investor Case (08)'. Row rule (CD-344): AML Case rows of type Elder Financial Exploitation or sourced from a "
    "Senior Investor Case are PII - special category. 50 line 217 note ('38 adds Source Money Movement Monitoring Alert at W4') should "
    "be reworded at the merge.",
    "CW-163 AML report key (coordinator): AML and Sanctions Report has its own restricted firm key AML Report Key ('AMLR <year>-"
    "<sequence>', no prefix). Rule: every report has an AML Report Key; Reported Case and Report Sequence are filled only when the report "
    "is filed from an AML Case; an OFAC blocked or rejected payment report raised directly by 50 Payment Sanctions Screening is filed "
    "without a case and carries only the key.",
    "08 at the W4 merge (ruling 3): 38 Compliance Program Review masters the FINRA Rule 3120 report (Program Review Type 'FINRA Rule "
    "3120 Supervisory Control Report', Review Report Date). 08 Supervisory Control Test.'Rule 3120 Report Date' (content_08 line 168) "
    "becomes a Derived copy of 38. 08 Senior Investor Case gains a Reference (AML Case, 38) for escalated exploitation cases (ruling 2).",
    "CW-007 personal trading at the firm's own broker-dealer (ruling 1, review W1 High): Personal Trading Account.Firm Brokerage "
    "Account (Reference (Account, 15)); on in-house rows (Personal Trading Data Source 'Firm Books and Records') Reported Personal "
    "Holding.Held Security and Held Quantity are Derived copies of 49 Client Holding, and Personal Transaction trade date, security, "
    "side, quantity and price are Derived copies of the 48 Client Execution named by Broker Transaction Reference. Only outside-broker "
    "rows (Rule 3210 duplicate statements, broker feeds) and self-reported rows are mastered here. Recorded as ROW_OWNERSHIP rules in "
    "enrich_38 (7 rules); the Ownership flag stays 'mastered here' because outside-broker rows are the majority by count (CD-289: "
    "the flag stays as declared).",
    "25 (proposal): Order Side lacks 'Exercise' and 'Gift / Transfer', which 38 personal trading uses since Personal Trade Side was "
    "folded into External (25 Order Side). Add them to 25 or name the 48 side list.",
    "Re-sourcings (Regulator Reference Number wording, GDPR -> Regulation S-P in the Notes PII text, MAR -> Section 204A / 15(g)) are "
    "recorded in REPOINTS and in the CW-938 resolution only; JURISDICTION holds removals only (jurisdiction.py format).",
    "CW-165 (not jurisdiction, no JURISDICTION entry): Entity Authorization Type 'State Insurance License' and Conflict Category "
    "'Insurer Client Relationship' removed; 38 no longer uses the shared Regulator value US_STATE_INSURANCE_REGULATOR.",
    "CW-930 and the W4 retirement brief section 5 (all 07 and 30 references in content_38 and enrich_38): MNPI Escalation.Source "
    "Deal (Reference (Deal), PDL-) removed; MNPI Source Type 'Private Markets Deal' removed; REL 'MNPI Escalation may originate from "
    "Deal [30]' re-pointed to Engagement [34] only; Client Consent Obtained Indicator text 'LPAC ... 30' removed; enrich_38 SUMMARY "
    "'deals from 30' removed. No 07 reference existed. Remaining: the Held Security Description example 'Private placement - XYZ "
    "Ventures LP interest' is an employee's private investment, not a 30 record (kept).",
    "CW-068: records retention stays in 21 (Retention Rule, RET-); 38 holds no retention object. Policy Domain 'Data Governance' "
    "covers the retention policy; REL 'Policy cites Retention Rule [21]' is held on the 21 side.",
    "Boundary with 08 (as drafted): 38 holds no recommendation, best-interest test, supervisory review, sales-practice alert, "
    "complaint, individual or branch registration or delivery check. 08 references 38 Policies (WSPs, Policy Domain 'Retail Conduct'), "
    "Attestations (Rule 3130) and the Form CRS filing: 08 Disclosure Delivery Check.Form CRS Version Required references the FILNG- "
    "key (content_08 line 71); Relationship Summary Version is a descriptive label (review B). Trade Surveillance "
    "Alert keeps Related Communications Alert (Reference (Surveillance Alert), SURV-, 08). Conflict register entries of category "
    "Advisor Compensation and Account Type Recommendation are reviewed in 08 Incentive Conflict Review (held there).",
    "Boundary with 49 (as drafted): Adviser Custody Profile holds the adviser's Rule 206(4)-2 status only; the affiliated "
    "broker-dealer appears as a related-person qualified custodian (LEN-). 38 references no 49 object as an attribute: the "
    "possession-or-control and reserve records are not referenced (brief section 7); Client Holding (49) appears only in the "
    "relationship row of Ownership Disclosure Determination (discretionary accounts aggregated for 13D / 13G / 13F).",
    "Boundary with 35 (as drafted): fund filings (N-PORT, N-CEN, N-CSR and others) and fund-share state notice filings stay 35 "
    "(CW-069); 38 Firm Regulatory Filing holds the firm's own filings only (Form ADV, BD, CRS, TA-1, TA-2, ADV-E, 13F, 13D, 13G, 13H, "
    "SHO). Form 13F is a firm-level filing of the adviser as institutional investment manager and stays here.",
    "Boundary with 47: Fee Deduction Authorization (47) is the per-account evidence of the fee deduction custody basis; 38 holds no "
    "reference to it (relationship row only). If 47 holds a 'Rule 206(4)-2 basis' list, it should read the 38 Custody Basis values.",
    "Boundary with 41 (resolves the CW-941 note in proposals_w1b_41.py): 38 holds the Regulation S-P and S-ID program reviews as "
    "Compliance Program Review types; 41 Information Security Program.Program Last Review Date and Last Board Report Date may be "
    "Derived copies of the 38 review (proposal for 41 at W5); no 38 attribute references 41 (relationship rows only).",
    "Deviation from the brief: attributes 291, one above the 265-290 band (accepted by ruling). Code lists 53 = 44 local + 9 shared, "
    "inside the 45-52 local band's intent (review F; the earlier '55 against 45-52' miscounted shared lists; Pre-Clearance Decision and "
    "Personal Trade Side were folded in the fix pass). CDEs 101 (34.7%). Sources 22.",
    "Brief section 8 'Distribution becomes Retail Conduct' applied; Privacy and Financial Crime Policy Domain values added for CW-163 "
    "(privacy program oversight) and the AML policies.",
    "Remaining grep hits for EU/UK terms in the module: 'wholesale' in the module docstring (tag name) and 'Short Position' in the "
    "Form SHO title and the US Rule 13f-2 regime value. 'Custody' appears only qualified (Adviser Custody Profile, Custody Surprise "
    "Examination, Custody Basis, Adviser Custody Status, Client Asset Custody, Fund Custody); 'Holding' only qualified (Reported "
    "Personal Holding, Portfolio Holding, Client Holding, Minimum Holding Period, Bank Holding Company Act).",
]
