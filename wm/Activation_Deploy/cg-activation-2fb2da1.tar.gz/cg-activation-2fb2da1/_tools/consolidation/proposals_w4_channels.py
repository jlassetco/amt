"""Wealth-manager reference model: W4 channel brief decisions for 05, 06 and 12 (CW-131 to CW-151; CW-905, CW-906, CW-912),
reserved and restored prefixes, key formats and the reader re-points.

Written by the W4 channels brief agent with the briefs in 00_Program/Rework/Briefs/ (05_Intermediary_and_Institutional_
Distribution.md, 06_Client_Assets_Flows_and_Channel_Attribution.md, 12_Institutional_Client_Servicing_and_Reporting.md).
Format: the DECISIONS dict format, the PREFIXES tuple format, the PREFIX_FORMATS and GRAIN_KEY_FORMATS tuple formats of
decisions.py (CONTRACT.md). Declarative only; the builder does not read this file. Every decision is "Proposed" until the
program lead merges it; each states the tailoring lever where a client could rule differently. The JURISDICTION entries of
CW-905, CW-906 and CW-912 are written by the drafters in proposals_05.py, proposals_06.py and proposals_12.py (CW-022).
CW-152 to CW-155 are left unused.
"""

PL = "Program lead"
P = "Proposed"

DECISIONS = [
    # ---- 05 Intermediary & Institutional Distribution -----------------------------------------------------------------
    {"id": "CW-131", "theme": "Scope", "title": "05 Intermediary & Institutional Distribution (L1 DI): the thin commercial record of the IC and IA lines",
     "domains": ["05", "02", "03", "08", "12", "13", "16"],
     "issue": "CW-013 makes 05 the intermediary and institutional distribution domain but leaves its contents to the W4 brief. The wholesale model spread this record over 02 (distributor hierarchy and advisor profiles), 03 (pipeline, RFPs, consultant relations), 05 (agreements, payments, shelf), 07 (coverage, crediting) and 08 (distributor due diligence).",
     "resolution": "05 (L1 code DI; the wholesale module and its code DA retire at integration) masters, in eight families and about 53 objects: intermediary firm and hierarchy profiles and external advisor profiles keyed by 02 PTY- (CW-132); Partner Coverage Assignment (PCVG-, CW-138); selling, platform, sub-accounting, networking, model-provider, SMA sponsor, recordkeeper services and data agreements (AGR-) with parties, terms, scope, product coverage and linked accounts; partner payments (PYA-, PCL-, PMT-, Partner Invoice, Intermediary Communication Fee Invoice IFI-); shelf placement (SHF-), share-class mapping, partner research ratings, partner programs (PGM-), model program placement and Model Delivery Event (MDEV-, CW-137); dealer and networking set-up and partner feed arrangements; Distributor Due Diligence (DDQ-, CW-135), agreement obligations and payment disclosures (including ERISA 408(b)(2) information); consultant profiles, consultant advisory relationships, consultant database profiles and submissions (DBS-) and consultant ratings; the institutional, intermediary-placement and plan-sponsor pipeline (OPP-) and RFPs (RFP-) (CW-134). Dropped: EU/UK distribution (CW-905), DCIO as a channel (CW-139), compensation and territory (07, CW-907), Agreement Document (39 Contract, CD-257), Distribution Fee Pass-Through (CW-136), Record Metadata (CD-160).",
     "rationale": "The intermediary business is a secondary channel (plan section 4 item 9); one domain with one owner per concept is thinner than the wholesale 02 + 03 + 05 set and keeps the readers resolving. Lever: a firm with a large advisor-channel business restores the wholesale depth from the sibling.",
     "action": "W4 (05 drafted beside the wholesale module; the lead deletes the wholesale 05 at integration)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-132", "theme": "Ownership", "title": "05 restores thirteen wholesale 02 role profiles with their names unchanged and the interim Party references re-point to them",
     "domains": ["05", "02", "01", "06", "08", "10", "11", "15"],
     "issue": "CW-021 and CW-023 moved the intermediary and consultant profiles out of 02 with their names unchanged; since W1 their readers point at ('02', 'Party') (key registry constants DISTRIBUTOR and FIN_PRO, 01, 06, 08, 10, 11 and 15 references, SM-00 dimensions, DP-001 to DP-003).",
     "resolution": "05 restores, by exact name and keyed by the 02 PTY- of a party holding the matching 02 Party Role (the Issuer Profile pattern, CD-143): Distributor Firm, Form ADV Profile (an attribute group of Distributor Firm), Hierarchy Node, Branch / Office, Advisor Team, Team Membership, Gatekeeper Profile, Financial Professional, Advisor Practice (an attribute group of Financial Professional), Employment Affiliation, External Classification, Consultant Profile and Consultant Advisory Relationship. Each profile Business Object carries a '<role> Party' key typed Reference (Party). Financial Professional.UK Certification Status is not restored (CW-902). Attribute sets are the wholesale ones (wholesale-v1.0), re-sourced to US rules; Distributor Firm.Distribution Channel uses the re-cut list (CW-140, CW-164). At the W4 merge: DISTRIBUTOR = ('05', 'Distributor Firm') and FIN_PRO = ('05', 'Financial Professional') in keys.py, keys_g2_03_04_05.py, keys_g3_06_07_10.py, keys_g4_08_09.py and keys_g5_11_12_13_14.py; the other references re-point per READERS below; the memberships ('05', 'Distribution Channel'), ('05', 'Qualification Exam') and ('05', 'Data Vendor') are registered (W1 merge notes section 5). The 02 Party Role Type values for these roles stay in 02 (CW-902).",
     "rationale": "Same mechanics as CW-021: readers keep resolving because the names are unchanged; the party core stays once in 02. Lever: a firm without an intermediary channel drops the profiles and keeps the roles.",
     "action": "W4 merge (key registry, references and memberships re-pointed by the lead)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-133", "theme": "Ownership", "title": "Institutional Client is restored in 12; Recordkeeper Profile and Plan Service Provider are 16's",
     "domains": ["12", "16", "02", "01", "06", "11"],
     "issue": "CW-023 sends Institutional Client to 12 and Recordkeeper Profile and Plan Service Provider to 16; the W4 brief must confirm which of the three 12 restores. The interim INST_CLIENT = ('02', 'Party') constant and the 01, 06, 11 and 12 references wait for it.",
     "resolution": "12 restores Institutional Client by exact name: a Business Object keyed by the 02 PTY- of a party with the Institutional Client role (Institutional Client Party, type, total investable assets and as-of date, governance model, funded status, government entity indicator for Advisers Act Rule 206(4)-5, ERISA plan indicator; fiscal year end and UPMIFA applicability added). Recordkeeper Profile and Plan Service Provider are restored by 16 at W3 (CW-023); the 16 brief may merge Plan Service Provider into its Plan Role Assignment (PROL-) provided the name stays resolvable. At the W4 merge INST_CLIENT = ('12', 'Institutional Client') in keys_g5_11_12_13_14.py; 12 Service Relationship.Client, 01 Investment Mandate.Client (keys_g1_01_02.py), 06 Market & Client Dimensions.Institutional Client (keys.py) and 11 Mandate Search Event.Asset Owner re-point; SM-00's institutional_client dimension reads Institutional Client Type again.",
     "rationale": "The institutional profile is maintained by the team that services the client; plan service providers are a fact of the plan. Lever: a firm without institutional advisory drops the profile.",
     "action": "W4 (12); W3 (16)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-134", "theme": "Ownership", "title": "05 restores the wholesale 03 institutional pipeline, RFP and consultant database objects; OPP-, RFP- and DBS- restored, ANS- and KAP- retired",
     "domains": ["05", "03", "04", "11", "36"],
     "issue": "CW-062 held OPP-, RFP-, ANS-, DBS- and KAP- for 05 at W4 'if the 05 brief keeps them, else retired'. DP-243, 05 Shelf Placement, 05 Partner Research Rating, 11 Mandate Search Event and 36 references wait for the ruling.",
     "resolution": "Restored by exact name: Sales Opportunity (OPP-), Pipeline Status, Opportunity Value, Win / Loss, RFP Request (RFP-), RFP Submission, Database Profile (DBS-), Database Submission, Consultant Rating. Renamed: Placement, Model & DCIO Detail -> Placement & Plan Detail (DCIO is not a channel, CW-139). Merged: Institutional Search Detail and Opportunity Product into Sales Opportunity; Opportunity Competitor into Win / Loss. Dropped: Opportunity Team, Stage History, Request Question, Answer Library Entry, Consultant Research Review (a 03 Advisor Activity row, CW-138), Consultant Notification, Account Plan, Plan Objective, Stakeholder Map, Plan Action. ANS- and KAP- retire (status 'Retired (sibling)' if CW-907's new status is accepted). Opportunity types: institutional mandate or OCIO search, intermediary placement (shelf, model), plan sponsor recordkeeping prospect (WR). DP-243 regains Sales Opportunity, Pipeline Status, Opportunity Value and Win / Loss; 05 Shelf Placement.Placement Opportunity, Partner Research Rating.DDQ Response, 11 Mandate Search Event.Linked Opportunity and 36 Evidence Shelf Placement and Evidence Model Program Placement resolve to 05 (CW-170).",
     "rationale": "Pipeline and RFP data for the IA and IC lines has no other home now that 03 is the own-advisor domain; the direct-business funnel is 04. Lever: restore Answer Library Entry and key account planning from the sibling.",
     "action": "W4 (05); readers at the W4 merge", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-135", "theme": "Ownership", "title": "Distributor due diligence returns to 05 in reduced form (DDQ-); Intermediary Communication Fee Invoice (IFI-) moves in from 13",
     "domains": ["05", "08", "13", "19"],
     "issue": "CW-067 held Distributor Due Diligence and its six detail objects (DDQ-) for 05 at W4; CW-088 moves Intermediary Communication Fee Invoice from 13 to 05 with the intermediary payments.",
     "resolution": "05 restores Distributor Due Diligence (DDQ-; partner firm x review: review type, risk rating, sanctions screening result (shared Screening Result), regulatory status check against BrokerCheck and IAPD, questionnaire received, SOC 1 attestation and outcome, next review date), absorbing Distributor Risk Rating, Screening Result, Regulatory Status Check, Questionnaire Response, Due Diligence Outcome and the wholesale 05 Partner Attestation; Due Diligence Finding is restored (DDQ-n-Fnn). Distribution Agreement.Distributor Due Diligence Reference resolves inside 05. Intermediary Communication Fee Invoice moves with IFI- unchanged; the 19 references re-point to 05. Supervision of the firm's own representatives is 08 and is not touched.",
     "rationale": "Oversight of distribution partners is commercial due diligence of the IC line, kept thin. Lever: reduce to an attestation on the agreement.",
     "action": "W4 (05); 08 and 13 remove their transitional copies at the W4 merge", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-136", "theme": "Ownership", "title": "Payments to intermediaries: platform, sub-accounting and networking fees are the reference default; 12b-1 and revenue sharing are levers",
     "domains": ["05", "01", "10", "19", "47"],
     "issue": "The wholesale 05 modeled 12b-1 pass-through, trails and retrocessions as core. The archetype's funds are no-load with no 12b-1 plans; what it pays intermediaries is platform, sub-accounting (sub-TA) and networking fees, some borne by the funds within board-approved caps (SEC IM Guidance Update 2016-01).",
     "resolution": "05 masters the payment terms (Payment Arrangement, absorbing Payment Terms and Payment Limit; Rate Schedule; Rate Tier; Sub-Accounting Fee Terms) and the partner payment cycle (Payment Calculation, Partner Invoice, Partner Payment, Intermediary Communication Fee Invoice). Payment Type default values: Platform Fee, Sub-Accounting Fee per account or asset-based, Networking Fee, Omnibus Processing Fee, Data Fee, Model Marketplace Fee, Intermediary Communication Fee; Revenue Sharing and Rule 12b-1 Service Fee are lever values. Distribution Fee Pass-Through is dropped. Payment Calculation.Basis Value is a Derived copy of 06. 10 books the accounting (Distribution Cost Item, Adviser-Borne Cost; CW-159), 19 the payable and payment, 01 the fund expense terms (FSCH-), 47 client fees only.",
     "rationale": "The reference model shows what the archetype pays; the sibling keeps the 12b-1 depth. Lever: restore 12b-1 share classes, trails and revenue sharing.",
     "action": "W4 (05)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-137", "theme": "Ownership", "title": "Model and SMA delivery to third-party sponsors: placement and delivery in 05, discretionary sponsor accounts in 15, 18 and 25",
     "domains": ["05", "01", "15", "18", "25", "46", "06"],
     "issue": "Plan section 5.1 gives 05 model and SMA delivery to advisors; CW-918 and CW-925 rule that sponsor program accounts the firm manages inside third-party wrap or model programs are the intermediary channel in 18 and 25.",
     "resolution": "05 masters Model Program Placement (kept; firm role model provider or discretionary manager) and Model Delivery Event (MDEV-; model portfolio 01 MDL- x sponsor program x delivery: initial, rebalance, change notice or discontinuation, model version as-of, channel, delivered and acknowledged timestamps) for non-discretionary model delivery. Where the firm manages the sponsor program account, the account is a 15 account linked by Agreement Account Link, its book is 18 SMA Portfolio Detail and its trades are 25 (trade rotation, directed brokerage). 46 never manages a sponsor account. Sponsor-reported assets and flows are 06 (Sponsor-Reported Assets, SMA Flow).",
     "rationale": "Delivering a model is a commercial and operational event, not portfolio management. Lever: a firm that only delivers models drops the 18 sponsor-account content, and the reverse.",
     "action": "W4 (05, 06)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-138", "theme": "Ownership", "title": "Coverage and activity: one activity master (03 ACT-) and three coverage records (03 clients, 05 partners, 12 servicing roles)",
     "domains": ["03", "05", "06", "12"],
     "issue": "CW-061 leaves 'external advisors and intermediary coverage' to 05 and CW-063 makes 03 Party Coverage Assignment the only advisor-of-record master; the 03 brief has institutional relationship managers on 03 coverage; 12 holds Service Coverage Assignment. Wholesale sales activities with intermediaries and consultants moved to 03 Advisor Activity.",
     "resolution": "05 Partner Coverage Assignment (PCVG-; covered party x covering employee (20 EMP-) x coverage role x period) covers partner firms, external advisors, consultants and third-party recordkeepers only (roles: internal wholesaler, external wholesaler, platform relationship manager, consultant relations manager, recordkeeper relationship manager). 03 Party Coverage Assignment covers clients and households, including the relationship manager of record for institutional clients and plan sponsors. 12 Service Coverage Assignment covers servicing roles on a Service Relationship (client service manager, reporting analyst, client portfolio manager). Meetings with intermediaries and consultants, including consultant research reviews, are 03 Advisor Activity rows (ACT-) with External Participant parties: the 03 drafter adds the intermediary and institutional activity types. 06 Salesperson Credit reads 05 coverage for IC and IA flows.",
     "rationale": "One activity master keeps the CRM record whole; the three coverage records answer different questions (who advises the client, who covers the partner, who services the relationship). Lever: a firm with a large channel moves activity types into 05.",
     "action": "W4 (05, 12); 03 activity types at the W4 merge (dependency on the W2 03 draft)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-139", "theme": "Scope", "title": "DCIO is not a separate channel: plan sponsor prospecting is a WR opportunity; own funds in third-party recordkept plans are intermediary-held",
     "domains": ["05", "06", "16", "09"],
     "issue": "The wholesale model ran DCIO (investment-only sales into plans recordkept by others) as its own channel; CW-164 keeps RETIREMENT_DCIO under WORKPLACE in the Distribution Channel re-cut.",
     "resolution": "Prospecting plan sponsors for the firm's own recordkeeping is a 05 Sales Opportunity of type Plan Sponsor Prospect (Placement & Plan Detail: target plan by 02 Retirement Plan, incumbent recordkeeper, plan advisor, participants). Own funds and CITs held in plans recordkept by others are intermediary-held own-fund assets (CW-011): the Distribution Channel value RETIREMENT_DCIO becomes INTERMEDIARY_RECORDKEEPER (refining CW-164), 06 Plan Position records them, and third-party recordkeepers are 05 partners covered by Partner Coverage Assignment with Recordkeeper Services Agreements. WORKPLACE then equals the CW-011 workplace channel (participants in the firm's recordkept plans).",
     "rationale": "Keeps Client Assets by channel free of non-client assets. Lever: restore DCIO as its own channel and coverage team.",
     "action": "W4 (05, 06); W5 shared list", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-140", "theme": "Code Lists", "title": "Shared-list refinements of the W4 channel briefs: Distribution Channel intermediary values, Dealing Route, 05 Partner Channel and memberships (refines CW-164)",
     "domains": ["05", "06", "09", "12", "29"],
     "issue": "CW-039 left the Distribution Channel and Dealing Route re-cuts to W4; CW-164 (W4 economics brief) re-cuts Distribution Channel, retires Distribution Market and invites the 05 and 06 briefs to refine the intermediary values.",
     "resolution": "Distribution Channel: accept the CW-164 values; refine RETIREMENT_DCIO to INTERMEDIARY_RECORDKEEPER (CW-139); the CW-011 'advised and managed' channel is the roll-up DIRECT_DIGITAL_ADVICE + DIRECT_HUMAN_ADVICE + DIRECT_TRUST, defined in 06 Measure Definition. 05 replaces its local Partner Channel by a local copy named Distribution Channel; members after W4: 01, 04, 05, 06, 11. Distribution Market retired (CW-164): 05 drops Agreement Market; 06 and 12 are not members. Dealing Route (steward 06): keep NSCC_FUNDSERV, NSCC_DCCS, NSCC_CNS_ETF, SWIFT_DIRECT, TA_DIRECT, RECORDKEEPER_FILE, SPONSOR_FILE; add OWN_BD_OMNIBUS (orders from the firm's broker-dealer omnibus to its transfer agent); remove CALASTONE, CLEARSTREAM_VESTIMA, EUROCLEAR_FUNDSETTLE, ALLFUNDS (recorded under CW-905 and CW-906); members 05, 06; direct user 29 (W3). Memberships removed for 05, 06 and 12: Data Quality Status and Information Classification (Record Metadata dropped, CD-160); for 05 also Distribution Market and Fund Dealing Settlement Method. Registered for 05: Qualification Exam, Data Vendor, Distribution Channel (CW-132). 06 joins Reconciliation Status (Break Status). Performance Fee Basis: steward to 47 (CW-054); 12 stays a member. Business Line: 05, 06 and 12 register as members with local copies of the eight codes.",
     "rationale": "Drafters copy the target values now; the steward applies the lists at W5. Lever: a client with regional intermediary wholesaling uses 09 Geographic Group, not a shared market list.",
     "action": "W4 drafts copy the values; W5 consolidation applies them", "status": P, "priority": "Medium", "owner_role": PL},

    # ---- 06 Client Assets, Flows & Channel Attribution ----------------------------------------------------------------
    {"id": "CW-141", "theme": "Ownership", "title": "06 Client Assets, Flows & Channel Attribution: firm-wide flows and summaries, never a book of record",
     "domains": ["06", "15", "16", "18", "29", "49", "50"],
     "issue": "CW-013 makes 06 firm-wide; CW-007 makes the Fund Shareholder Position a view of 49 and of intermediary and TA data. The wholesale 06 Transaction and Position were mastered from TA and intermediary feeds.",
     "resolution": "06 (renamed Client Assets, Flows & Channel Attribution; code TX kept; module edited in place) holds eight families and about 40 objects. Transaction (TXN-, name kept for its readers; glossary 'Flow Transaction') is the conformed flow record of every external flow into or out of a client account and every own-fund purchase or redemption; row rule (CD-289): amount, date and type are a Derived copy of the source record (49 Client Account Activity and Account Transfer, 50 Money Movement, 29 Register Transaction (RGTX-; the confirmed TA posting is 29's by CW-122, amending CD-199 and CD-200), 16 Contribution Record and Distribution Request, 18 Portfolio Capital Activity) referenced from Order Source; intermediary-feed rows are mastered here as delivered. Position is renamed Fund Shareholder Position (POS- kept); row rule (adopts CW-122): brokerage and managed accounts Derived from 49 Client Holding, every other registered account Derived from 29 Share Register Balance, intermediary sub-account look-through rows mastered here as delivered; fund-only lots are 49 Client Tax Lots; the 49-to-29 omnibus reconciliation is 49's. New Account Asset Summary (account x as-of date x holding type; Derived throughout from 49 Client Holding Valuation, 16 participant balances, 18 Portfolio Valuation Summary, 29 and the Fund Shareholder Position). Dropped: Transaction Sales Charge (no-load default; lever), Record Metadata, territory and the EU/UK content of CW-906. 06 holds no tax lot, cost basis, cash balance or quantity mastered for a client account.",
     "rationale": "06 summarizes, attributes and certifies across five books; mastering any of them would duplicate 49, 29, 16 or 18. Lever: a firm without a brokerage reads 29 only.",
     "action": "W4 (06)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-142", "theme": "Certified numbers", "title": "Client Assets, Net New Assets and Advised Assets are defined once, in 06; channel is an effective-dated property of the account",
     "domains": ["06", "15", "21", "27", "46"],
     "issue": "CW-011 certifies Client Assets (successor of DP-008), Net New Assets and Advised Assets but does not say which objects carry them, how channel is assigned or which flows count.",
     "resolution": "06 Measure Definition (MSR-) defines MSR-CLIENTASSETS, MSR-NNA, MSR-ADVISEDASSETS, client market movement, inter-channel transfers, client organic growth and the own-fund overlap; 06 Measure Value and the new Client Asset Measures attribute group carry the values; the owner role is the Head of Client & Channel Analytics; 21 registers them. Account Channel Assignment (CHASG-; account x channel x period; basis account type, 15 Program Enrollment, 16 plan or 05 partner) gives every account one channel at a time; a change is an inter-channel transfer, never a flow. Reference defaults (Flow Treatment Rule, levers): NNA counts external cash and asset movements (deposits, withdrawals, ACATS, rollovers from outside the firm, contributions, distributions, mandate funding and withdrawals, intermediary net sales of own funds); dividends, interest and capital gains are excluded; fees are excluded and shown in market movement and other; rollovers from the firm's plans into firm IRAs are inter-channel transfers. Holding Type: own mutual fund, own ETF, own CIT, third-party mutual fund, third-party ETF, equity, fixed income and CDs, options, cash and sweep, alternative feeder, other. Firm AUM is not defined in 06 (DP-165, 46, 18); the own-fund overlap is reported here and netted only in the reconciliation product (successor of DP-241). DP-008 is re-scoped at WP0 as Client Assets & Net New Assets; SM-01's certified flow and AUM metrics move to SM-20 Client Assets & Flows.",
     "rationale": "One definition per certified number (CD-292 as amended by CW-011). Lever: the treatment options of Flow Treatment Rule.",
     "action": "W4 (06); WP0 (DP-008, DP-241); WP2 (SM-20)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-143", "theme": "Ownership", "title": "Attribution of flows and assets: advisor from 03, campaign from 04, intermediary from 05, institution from 12; territory and crediting retire with 07",
     "domains": ["06", "03", "04", "05", "07", "12", "16"],
     "issue": "The wholesale attribution credited distributor hierarchies, territories (07) and salespeople through crediting rules (07); acceptance question 2 asks for net new assets by channel, advisor and campaign.",
     "resolution": "06 Attribution Record keeps its attribute groups: Distributor Hierarchy (IC path to the 05 restored profiles), Market & Client Dimensions (re-cut: channel, business line, offering 01 OFFR-, enrollment 15 ENRL-, advisor from 03 Party Coverage Assignment as of the flow date (CW-063), household PTY-HH-, plan, institutional client (12), consultant (05), campaign and weight as Derived copies of 04 (CW-085); Territory, Platform / Fund Distributor (EU/UK) and Investor Country dropped), Salesperson Credit (IC and IA flows only; the credited employee and role from 05 Partner Coverage Assignment; the 07 Crediting Rule reference dropped), Attribution Method (adds Account-Keyed), Unattributed Item (suspense by channel, not territory), Attribution Override.",
     "rationale": "Attribution reads each dimension from its master as of a date and copies nothing as mastered. Lever: restore territories and crediting from the sibling.",
     "action": "W4 (06)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-144", "theme": "Ownership", "title": "Identity resolution and rep matching are kept for intermediary data only",
     "domains": ["06", "05", "02"],
     "issue": "The wholesale 06 resolved every feed's firm, office, rep and account codes; direct, workplace and institutional data now arrive keyed by ACC- and PTY-.",
     "resolution": "Identifier Crosswalk (XWK-), Match Rule (MRL-) and Match Result are kept by name and apply to intermediary feeds (sub-accounting, Omni/SERV, aggregator, sponsor and third-party recordkeeper files), resolving to 05 profiles and 02 parties; internal sources are joined by key (Attribution Method 'Account-Keyed'). The FCA FRN identifier type is removed (CW-906).",
     "rationale": "Matching is needed only where the firm does not own the key. Lever: none.",
     "action": "W4 (06)", "status": P, "priority": "Low", "owner_role": PL},

    # ---- 12 Institutional Client Servicing & Reporting ---------------------------------------------------------------
    {"id": "CW-145", "theme": "Ownership", "title": "12 adapted to institutional advisory and plan sponsor servicing; billing leaves for 47, surveys for 04",
     "domains": ["12", "04", "16", "47", "01"],
     "issue": "The wholesale 12 serviced institutional, sub-advisory, DCIO and platform clients, billed mandates and ran client surveys; CW-012 and CW-054 move billing to 47 and CW-093 puts surveys and NPS in 04; 01 now has a retail Service Tier object (CW-028).",
     "resolution": "12 (name and code IS kept; module edited in place) has ten families and about 33 objects: Institutional Client (restored, CW-133); Investment Policy Statement (new, IPSV-; client x IPS version); Service Relationship with the new attribute groups OCIO Service Detail and Plan Sponsor Servicing Detail; Service Tier renamed Institutional Service Tier; Service Standard, Service Team, Service Coverage Assignment; the reporting families kept; guideline monitoring and breach notification kept; Client Service Request and Cash Flow Notification kept; Client Review and Relationship Health Score kept; new Mandate Onboarding (MND- x onboarding start); Custody Account, Cash Flow Arrangement, Client Data Feed, Transition Event, Mandate Termination kept. Removed: the Fee Billing & Invoicing family (moved to 47 with BLA-, BIL-, BDP-, CW-054), Client Feedback Response (04 Client Survey and Survey Response; CFS- retired), Template Adoption (ILPA out of scope with 30; CTI and MiFID content under CW-912), Depreciation Notification (MiFID II, CW-912), Record Metadata. Servicing Segment values: OCIO, Institutional Separate Account, Institutional Pooled (fund or CIT), Plan Sponsor - Recordkept, Plan Sponsor - CIT Only; sub-advisory, DCIO, SMA sponsor, model delivery and private fund investor segments leave (05 or out of scope). DP-243 re-points billing inputs to 47 and feedback to 04 Survey Response; Mandate Termination.Final Invoice is Reference (Fee Invoice, 47).",
     "rationale": "12 keeps the servicing record of the IA and WR relationships and nothing that another domain masters. Lever: add sub-advisory servicing from the sibling.",
     "action": "W4 (12)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-146", "theme": "Ownership", "title": "Plan sponsor boundary: 16 owns the plan and its arrangements, 12 owns the sponsor service relationship and reporting",
     "domains": ["12", "16", "13", "02"],
     "issue": "Plan section 5.1 adds 'plan sponsor relationship' to 16 and 'plan sponsor servicing and reporting' to 12.",
     "resolution": "16 masters the plan and its provisions, plan roles including the sponsor (Plan Role Assignment, PROL-), the recordkeeping Service Arrangement (PSVA-), plan fee schedules, plan notices, filings and every plan operation (payroll, loans, distributions). 12 masters the sponsor Service Relationship (Plan Sponsor Servicing Detail: plan, recordkeeping arrangement and fiduciary committee by reference), the sponsor's service team, report packages (plan review, participation and deferral, investment line-up review), fiduciary committee reviews and relationship-level requests. Participant requests are 13; complaints 08.",
     "rationale": "The plan record and the client relationship have different owners and systems. Lever: a recordkeeper-only firm moves sponsor reporting into 16.",
     "action": "W4 (12); W3 (16 brief to confirm)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-147", "theme": "Ownership", "title": "OCIO boundary: mandate in 01, allocation in 24, managers in 52, book in 18, returns in 32, billing in 47; the IPS and the service in 12",
     "domains": ["12", "01", "24", "52", "18", "32", "33", "47"],
     "issue": "OCIO clients delegate the whole portfolio, including the hiring of external managers; several domains hold parts of the record.",
     "resolution": "01 masters the Investment Mandate (MND-), its restrictions (RST-) and the OCIO Service Offering (OFFR-); 24 the strategic asset allocation; 52 the external managers and their due diligence; 18 the portfolios; 32 performance; 33 breaches; 47 billing. 12 masters the client's Investment Policy Statement versions (IPSV-: adoption and approval, return objective, spending policy, risk and liquidity constraints, strategic allocation reference to 24, linked mandates, review cycle), OCIO Service Detail (delegation scope, ERISA section 3(38) or 3(21) status, managers in scope by reference to 52), reporting and servicing.",
     "rationale": "The client's policy and the servicing commitments are 12's; the investment facts are where they are produced. Lever: hold the IPS as a 39 document reference.",
     "action": "W4 (12)", "status": P, "priority": "Medium", "owner_role": PL},

    # ---- Shared mechanics -------------------------------------------------------------------------------------------
    {"id": "CW-148", "theme": "Identifiers", "title": "Prefixes of 05, 06 and 12: four reserved, five restored, four retired, POS- re-described",
     "domains": ["03", "05", "06", "08", "12", "13"],
     "issue": "The W4 channel briefs need new keys (partner coverage, model delivery, channel assignment, IPS) and rulings on the prefixes CW-062, CW-067 and CW-088 held for 05.",
     "resolution": "Reserve PCVG- and MDEV- (05), CHASG- (06), IPSV- (12). Restore to owner 05: OPP-, RFP-, DBS- (from 03), DDQ- (from 08), IFI- (from 13). Retire: DOC- (05), ANS- and KAP- (03), CFS- (12). Kept unchanged: 05 AGR-, PYA-, PCL-, PMT-, PGM-, SHF-; 06 TXN-, POS- (entity 'Fund shareholder position'), FEED-, ATR-, OVR-, XWK-, MRL-, LOAD-, RCN-, BRK-, SNP-, UNA-, MSR-, RSM-; 12 RPT-, RPK-, CSR-, SVR-, SVT-, SVA-, SLA-, RCM-, TPL-, PPP-, RRN-, DLS-, GBN-, CFN-, CRV-, CUA-, CDF-, TRN-, TRM-; BLA-, BIL-, BDP- move to 47 (CW-054). SVT- format example becomes SVT-INST-02. Composite keys in GRAIN_KEY_FORMATS. Each new prefix is at least two edits from, and no anagram of, every prefix in decisions.PREFIXES, the W2, W3 and W4 proposals files present on 2026-10-14, the anchors of 45 to 52, content tokens and L1 codes.",
     "rationale": "Prefix discipline across siblings (CW-002).",
     "action": "W4 merge", "status": P, "priority": "Low", "owner_role": PL},

    {"id": "CW-149", "theme": "Code Lists", "title": "Term conflicts of the 05, 06 and 12 briefs (log at W5)",
     "domains": ["03", "05", "06", "12", "13", "15", "39", "49", "50"],
     "issue": "The channel briefs add or re-use terms on the plan section 5.3 watchlist and beyond.",
     "resolution": "Log: Advisor (03 Advisor; 05 External Advisor = Financial Professional); Coverage (03 Party Coverage Assignment; 05 Partner Coverage Assignment; 12 Service Coverage Assignment); Team (03 Coverage Team; 05 Advisor Team; 12 Service Team); Transaction (06 Flow Transaction; 49 Client Account Activity; 50 Money Movement; 29 Fund Order; 18 Portfolio Transaction); Position (06 Fund Shareholder Position; 18 Portfolio Holding; 49 Client Holding); Assets (06 Client Assets; Firm AUM; Form ADV regulatory assets under management); Channel (06 Distribution Channel; 13 communication channel); Program (05 Partner Program; 01 advice program; 46 managed account program; 50 sweep program); Agreement (05 Distribution Agreement; 15 Account Agreement; 39 Contract); Tier (05 Partner Tier; 01 Service Tier; 12 Institutional Service Tier); Client (12 Institutional Client; 02 client role); Review (12 Client Review; 45 Advice Review; 08 Supervisory Review); Feed (06 Data Feed; 12 Client Data Feed; 05 Partner Data Feed Arrangement; 14 Dataset Delivery); Hierarchy Node (05 intermediary hierarchy; 10 Management Hierarchy Node, CW-159).",
     "rationale": "Every definition says which sense it uses.", "action": "W5", "status": P, "priority": "Low", "owner_role": PL},

    {"id": "CW-150", "theme": "Governance", "title": "Personal data in 05, 06 and 12",
     "domains": ["05", "06", "12"],
     "issue": "05 holds external advisors' professional data (individuals), 06 holds client flows and balances by account, 12 holds institutional contacts.",
     "resolution": "Every object states its PII tier. 05: Financial Professional, Advisor Practice, Employment Affiliation, Team Membership, Gatekeeper Profile, External Classification and analyst or signatory attributes are 'PII - identity' (professional data); Disclosure Events Count is restricted. 06: Transaction, Fund Shareholder Position and Account Asset Summary are 'PII - financial' (account-level client data); products read them in aggregate except authorized client views. 12: recipients, signatories and officers are 'PII - identity'; institutional profiles carry none. No special-category data in the three domains.",
     "rationale": "Plan section 11 and CD-344.", "action": "W4", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-151", "theme": "Structure", "title": "Readers of 05, 06 and 12 to re-point at the W4 merge",
     "domains": ["01", "05", "06", "08", "10", "11", "12", "13", "15", "16", "18", "19", "43"],
     "issue": "The adaptations rename, restore, move and drop objects that carried modules, the key registry, live products and semantic models read.",
     "resolution": "The lead applies READERS below at the W4 merge: the interim ('02', 'Party') references to the restored 05 and 12 profiles (CW-132, CW-133); Position -> Fund Shareholder Position in 16, 18, 43, the key registry, DP-007, DP-108, DP-204 and DP-241; DP-006 loses Transaction Sales Charge, the crediting rule and the territory; DP-243 regains the 05 pipeline objects, re-points billing to 47 and feedback to 04; 19 Partner Invoice and Partner Payment, 10 Payment Arrangement, 36 Shelf Placement and Model Program Placement, 21 Measure Definition, 14, 21 and 41 Data Feed resolve unchanged; 13's transitional Intermediary Communication Fee Invoice is removed; the keys_g* entries of dropped objects are superseded at WP2.",
     "rationale": "As CW-021: readers keep resolving or are re-pointed by an explicit list.", "action": "W4 merge", "status": P, "priority": "High", "owner_role": PL},

    # ---- US-only decisions (pre-allocated, CW-022) --------------------------------------------------------------------
    {"id": "CW-905", "theme": "Scope", "title": "US-only pass of Data Domain 05 Intermediary & Institutional Distribution (replacement of the wholesale 05)",
     "domains": ["05"],
     "issue": "The wholesale 05 carried MiFID II inducements and costs data (FinDatEx EMT, ex-post inducement amounts, quality-enhancement assessments), UK RDR legacy trail, retrocessions, VAT on platform fees, EU dealing networks (Calastone, Clearstream Vestima, Euroclear FundSettle, Allfunds), EU/UK markets, governing law, account and channel values, and EU/UK sources; the restored 02 and 03 objects carry EU/UK channel values.",
     "resolution": "Not carried (entries in proposals_05.py JURISDICTION, per the 05 brief section 4a): object Distributor Data Exchange; attributes Payment Arrangement.Inducement Relevance Indicator and Inducement Assessment Reference, Distribution Fee Pass-Through.Retrocession Basis, Retrocession Rate, Pass-On to Client Required Indicator and UK Legacy Trail Indicator, Payment Terms.VAT Applicable Indicator, Partner Dealer Setup.Platform Participant ID and Dealing BIC, Distribution Agreement.Agreement Market; the EU/UK values of Agreement Type, Agreement Party Role, Service Model, Account Structure, Payment Type, Funding Source, Account Eligibility, Dealing Route, Settlement Method, Data Content Type, Partner Disclosure Type, Attestation Type, Governing Law, Partner Channel and the restored Distribution Channel; sources MiFID II Art. 24(9) and Delegated Directive 2017/593 Art. 11, FCA COBS 2.3A, 6.1A, 6.1B and 6.1E, FinDatEx EMT, Calastone and the EU fund networks. Kept and re-sourced: agreements, payments and disclosures to SEC IM Guidance Update 2016-01, FINRA Rule 2341, SEC Rule 22c-2, DOL 29 CFR 2550.408b-2 and Reg BI; ISO 20022 as a market-neutral standard. META subtitle 'Wealth manager (direct) | Scope: US'.",
     "rationale": "CW-003, CW-022; a UK extension restores the content from tag wholesale-v1.0.",
     "action": "Merge JURISDICTION into jurisdiction.REMOVALS at the W4 merge", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-906", "theme": "Scope", "title": "US-only pass of Data Domain 06 Client Assets, Flows & Channel Attribution",
     "domains": ["06"],
     "issue": "The wholesale 06 carried EU/UK platform and nominee attribution, investor country for MiFID, EU dealing networks, UK and EU channel values, FCA identifiers, UK re-registration and initial-charge values, and EFAMA, Calastone, Clearstream, Allfunds and MiFID sources.",
     "resolution": "Removed (entries in proposals_06.py JURISDICTION, per the 06 brief section 4a): Market & Client Dimensions.Platform / Fund Distributor (EU/UK) and Investor Country; Omnibus Look-Through.Nominee / Platform Account Indicator; Order Entry Channel values Calastone, Clearstream Vestima, Euroclear FundSettle, Allfunds; Distribution Channel values Fund Platform (EU/UK), IFA / Wealth Manager (EU/UK), Discretionary Fund Manager (UK); Sales Charge Type value Initial Charge (EU/UK); Intermediary Identifier Type value FCA FRN; Transfer Type value Platform Re-Registration (UK); Look-Through Source value Nominee Disclosure (EU/UK); sources EFAMA statistical releases, Calastone, Clearstream Vestima, Allfunds and MiFID II distribution chain. Perspective text rewritten (EFAMA alignment, the LU product identifier example). Kept: ISO 20022, DTCC services, ICI and Morningstar definitions, foreign instruments held in client accounts.",
     "rationale": "CW-003, CW-022.", "action": "Merge JURISDICTION at the W4 merge", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-912", "theme": "Scope", "title": "US-only pass of Data Domain 12 Institutional Client Servicing & Reporting (including the billing objects moved to 47)",
     "domains": ["12", "47"],
     "issue": "The wholesale 12 carried the MiFID II depreciation notification, UK CTI and MiFID ex-post cost reporting, Solvency II look-through, UK Stewardship Code and SFDR reporting drivers, UK and Luxembourg servicing entities, EMEA and GBP examples, and ESMA performance fee guidance on the billing objects that CW-054 moves to 47.",
     "resolution": "Removed (entries in proposals_12.py JURISDICTION, per the 12 brief section 4a; the moved billing objects' items are recorded here as CW-054 and the 47 brief propose, using proposals_w2_47.py CW912_ITEMS): object Depreciation Notification; Template Adoption.CTI Template Type and MiFID Ex-Post Cost Report Indicator with the CTI Template Type list; Reporting Driver values MiFID II Periodic Statement, MiFID II Ex-Post Costs, UK CTI, UK Stewardship Code, Solvency II Look-Through, SFDR / TCFD; Report Type value Cost & Charges Statement; Look-Through Template value Solvency II TPT; sources CTI templates, MiFID II Delegated Regulation 2017/565 Arts 60-62, FCA COBS 16A and SYSC 9, UK Stewardship Code 2026, Solvency II TPT and the ESMA performance fee guidelines. Rewritten: Servicing Legal Entity definition, EMEA, GBP and Europe/London examples, CAL-UK-LON. Kept: GIPS, ISO standards, SEC marketing and books-and-records rules, non-USD benchmarks of global mandates.",
     "rationale": "CW-003, CW-022, CW-054.", "action": "Merge JURISDICTION at the W4 merge", "status": P, "priority": "High", "owner_role": PL},
]

# ---------------------------------------------------------------------------------------------------------------------
# PREFIXES (decisions.py tuple format: prefix, entity, owner domain, status, note). Checked by script on 2026-10-14 against
# decisions.PREFIXES (410 entries, every status), every proposals_w*.py file then present (W2 advice, conduct, engagement,
# 13, 45, 46, 47, 51; W3 brokerage; W4 economics), the 45-52 anchors (PLN FGL RCO ADE MAS RBL TLH TPB FBR FDB FWV FSC COR
# CEX CCF CRT CHL CLT RSV CAA CAX MMT SWP PBK MMH TRS TDD EST MGR MDD SAA PDD), prefix-like tokens in every content
# module, DP- FN- SM- CD- CW- and the L1 codes (with AO, DI, RC).
# Rejected near-misses:
#   05 partner coverage: PCOV- (RCOV- 23, MCOV- 42, PCOR- and PCNV- 16), ICOV- (RCOV-, MCOV-), XCOV- (same), PTCA- (TCA- 25),
#       PCVA- (CVA- 03), PRCV- and PCOVA- (clear but opaque).
#   05 model delivery: MDLV-, MDLX-, MDLY- (MDL- 01), MDLD-, MDDL- (MDL-, anchor MDD-), MDX- (IDX- 22, MDL-, MDD-), DLVR-,
#       MODV- (clear, opaque).
#   06 channel assignment: CHNL- (anchor CHL-), CHAN- (CAN- token), CHAS- and ACHA- (read as ACH and a bank brand),
#       ACHN-, CHNA- (clear, illegible); Account Asset Summary: CAS- (CAA- anchor, CAM-, CAL-, CNS-, CPS-, CFS-), ASUM-
#       (AUM- token), AAS- (AAG- 15, ANS-, MAS-, SAA-), ASNP- (SNP-, SNAP-), so a composite key is used.
#   12 IPS: IPS- (INS- 17, CPS- 07, ICS- 09), IPOL- (VPOL- 34, INPOL- 43), INPS- (INS-, INPR- 02); Mandate Onboarding:
#       MONB- (CONB- 16, ONB- 02), ONBM- (ONB-), MNDO- (FNDO- 29, MND- 01), MSET- (MSE- 11, DSET- 14), so a composite key.
# ---------------------------------------------------------------------------------------------------------------------
R = "Reserved"
RS = "Restored"

PREFIXES = [
    ("PCVG-", "Partner coverage assignment (partner firm, external advisor, consultant or recordkeeper x employee x role x period)", "05", R,
     "W4 brief 05 (CW-138). Rejected PCOV-, ICOV-, PTCA-, PCVA-."),
    ("MDEV-", "Model delivery event (model portfolio x sponsor program x delivery)", "05", R,
     "W4 brief 05 (CW-137). Rejected MDLV-, MDLX-, MDLD-, MDX-."),
    ("CHASG-", "Account channel assignment (account x distribution channel x period)", "06", R,
     "W4 brief 06 (CW-142). Rejected CHNL- (anchor CHL-), CHAN-, CHAS-, ACHA-."),
    ("IPSV-", "Investment policy statement version (institutional client x IPS version)", "12", R,
     "W4 brief 12 (CW-147). Rejected IPS-, IPOL-, INPS-."),
    # Restored to 05 (owner change; the rows already exist in decisions.PREFIXES with the old owner).
    ("OPP-", "Sales opportunity (institutional or OCIO search, intermediary placement, plan sponsor prospect)", "05", RS,
     "Held for 05 by CW-062; restored with Sales Opportunity (CW-134). Previous owner 03."),
    ("RFP-", "RFP / RFI / DDQ request and response", "05", RS,
     "Held for 05 by CW-062; restored with RFP Request (CW-134). Previous owner 03."),
    ("DBS-", "Consultant database profile", "05", RS,
     "Held for 05 by CW-062; restored with Database Profile (CW-134). Previous owner 03."),
    ("DDQ-", "Distributor due diligence (findings DDQ-n-Fnn)", "05", RS,
     "Held for 05 by CW-067; restored with Distributor Due Diligence (CW-135). Previous owner 08."),
    ("IFI-", "Intermediary communication fee invoice", "05", RS,
     "Moved with its object from 13 (CW-088, CW-135). Previous owner 13."),
]

# Prefixes to retire at the W4 merge (status 'Retired (sibling)' if CW-907's new status is accepted, else 'Retired').
RETIRE_PREFIXES = {"DOC-": ("05", "CW-131: Agreement Document dropped; documents are 39 Contract (CD-257)"),
                   "ANS-": ("03", "CW-134: Answer Library Entry dropped"),
                   "KAP-": ("03", "CW-134: Account Plan dropped"),
                   "CFS-": ("12", "CW-145: Client Feedback Response retired to 04 (CW-093)")}

# Entity texts of kept prefixes to update at the merge.
PREFIX_ENTITY_UPDATES = {"POS-": "Fund shareholder position (06; renamed from Position, CW-007, CW-141)",
                         "TXN-": "Flow transaction (06; conformed flow record, CW-141)"}

# Proposed key formats (decisions.PREFIX_FORMATS tuple format: prefix, domain, format, example).
PREFIX_FORMATS = [
    ("PCVG-", "05", "PCVG-<sequence, 6 digits>", "PCVG-004512"),
    ("MDEV-", "05", "MDEV-<YYYYMMDD>-<sequence, 6 digits>", "MDEV-20261005-000318"),
    ("CHASG-", "06", "CHASG-<sequence, 9 digits>", "CHASG-000418822"),
    ("IPSV-", "12", "IPSV-<client party number, digits of PTY->-<version, 2 digits>", "IPSV-301120-04"),
    # Format examples re-cut to US values (formats themselves unchanged).
    ("SVT-", "12", "SVT-<code, 4 letters>-<sequence, 2 digits>", "SVT-INST-02"),
]
KEY_FORMATS = PREFIX_FORMATS  # alias named in the W4 assignment

# Composite keys (decisions.GRAIN_KEY_FORMATS tuple format: object, domain, key format, example).
GRAIN_KEY_FORMATS = [
    ("Distributor Firm", "05", "<PTY- id of the partner firm>", "PTY-100001"),
    ("Hierarchy Node", "05", "<PTY- id of the node> / <hierarchy type> / <effective from>", "PTY-100455 / FIRM_OPERATIONAL / 2024-01-01"),
    ("Team Membership", "05", "<PTY- id of the team> / <PTY- id of the member> / <effective from>", "PTY-204500 / PTY-204511 / 2020-01-01"),
    ("Employment Affiliation", "05", "<PTY- id of the professional> / <PTY- id of the firm> / <start date>", "PTY-301177 / PTY-100001 / 2018-04-09"),
    ("External Classification", "05", "<PTY- id> / <data vendor> / <as-of date>", "PTY-301177 / BROADRIDGE / 2026-08-31"),
    ("Consultant Advisory Relationship", "05", "<PTY- id of the consultant> / <PTY- id of the advised client or plan> / <effective from>", "PTY-100670 / PTY-301120 / 2019-07-01"),
    ("Program Membership", "05", "<PGM- id> / <PTY- id of the member> / <effective from>", "PGM-0042 / PTY-100001 / 2026-01-01"),
    ("Due Diligence Finding", "05", "<DDQ- id>-F<sequence, 2 digits>", "DDQ-2026-00312-F03"),
    ("Account Asset Summary", "06", "<ACC- id> / <as-of date> / <holding type>", "ACC-0049812 / 2026-09-30 / OWN_ETF"),
    ("Fund Shareholder Position", "06", "POS-<valuation date YYYYMMDD>-<account sequence, 7 digits>-<share class sequence, 6 digits> (unchanged)", "POS-20260930-0049812-004512"),
    ("Institutional Client", "12", "<PTY- id of the institutional client>", "PTY-301120"),
    ("Mandate Onboarding", "12", "<MND- id> / <onboarding start date>", "MND-01234 / 2026-07-01"),
]

# Objects restored by exact name (CW-021, CW-023), by receiving domain, with their wholesale source domain.
RESTORED_OBJECTS = {
    "05": {"02": ["Distributor Firm", "Form ADV Profile", "Hierarchy Node", "Branch / Office", "Advisor Team", "Team Membership",
                  "Gatekeeper Profile", "Financial Professional", "Advisor Practice", "Employment Affiliation",
                  "External Classification", "Consultant Profile", "Consultant Advisory Relationship"],
           "03": ["Sales Opportunity", "Pipeline Status", "Opportunity Value", "Win / Loss", "RFP Request", "RFP Submission",
                  "Database Profile", "Database Submission", "Consultant Rating",
                  "Placement & Plan Detail (renamed from Placement, Model & DCIO Detail)"],
           "08": ["Distributor Due Diligence", "Due Diligence Finding"],
           "13": ["Intermediary Communication Fee Invoice"]},
    "12": {"02": ["Institutional Client"]},
    "16 (W3, not these briefs)": {"02": ["Recordkeeper Profile", "Plan Service Provider"]},
}

# Objects kept by exact name in the adapted or replaced modules.
KEPT_OBJECTS = {
    "05": ["Distribution Agreement", "Agreement Party Role", "Agreement Term", "Agreement Amendment", "Agreement Product Coverage",
           "Agreement Distribution Scope", "Agreement Account Link", "Payment Arrangement", "Rate Schedule", "Rate Tier",
           "Sub-Accounting Fee Terms", "Payment Calculation", "Partner Invoice", "Partner Payment", "Shelf Placement",
           "Share Class Mapping", "Partner Research Rating", "Model Program Placement", "Partner Program", "Program Membership",
           "Partner Dealer Setup", "Networking Setup", "Partner Data Feed Arrangement", "Agreement Obligation", "Payment Disclosure"],
    "06": ["Transaction", "Transaction Dates", "Transaction Amounts", "Order Source", "Intermediary As Delivered",
           "Linked Transaction", "ETF Creation / Redemption", "SMA Flow", "Transaction Status", "Omnibus Look-Through",
           "ETF Holding", "Plan Position", "Sponsor-Reported Assets", "Measure Definition", "Flow Treatment Rule", "Measure Value",
           "Flow Measures", "Asset Measures", "Attribution Record", "Distributor Hierarchy", "Market & Client Dimensions",
           "Salesperson Credit", "Attribution Method", "Unattributed Item", "Attribution Override", "Identifier Crosswalk",
           "Match Rule", "Match Result", "Data Feed", "Load", "Reconciliation", "Reconciliation Run", "Break", "Reporting Period",
           "Snapshot", "Restatement"],
    "12": ["Service Relationship", "Service Standard", "Service Team", "Service Coverage Assignment", "Report Definition",
           "Report Component", "Report Template", "Report Package", "Presentation Profile", "Holdings Presentation",
           "GIPS Report Provision", "Report Schedule", "Report Run", "Distribution List", "Report Delivery",
           "Guideline Monitoring Arrangement", "Breach Notification", "Compliance Certificate", "Client Service Request",
           "Cash Flow Notification", "Client Review", "Relationship Health Score", "Custody Account", "Cash Flow Arrangement",
           "Client Data Feed", "Transition Event", "Mandate Termination"],
}
RENAMED_OBJECTS = {("06", "Position"): ("06", "Fund Shareholder Position"),
                   ("12", "Service Tier"): ("12", "Institutional Service Tier"),
                   ("03", "Placement, Model & DCIO Detail"): ("05", "Placement & Plan Detail")}

# Readers to re-point at the W4 merge (CW-151). (file or product, location, from, to)
READERS = [
    ("keys.py, keys_g2_03_04_05.py, keys_g3_06_07_10.py, keys_g4_08_09.py, keys_g5_11_12_13_14.py", "DISTRIBUTOR, FIN_PRO", "('02', 'Party')", "('05', 'Distributor Firm'), ('05', 'Financial Professional')"),
    ("keys_g5_11_12_13_14.py", "INST_CLIENT", "('02', 'Party')", "('12', 'Institutional Client')"),
    ("keys_g6_15_16.py", "15 Intermediary Account Servicing: Dealer of Record, Branch of Record, Rep of Record", "PARTY", "05 Distributor Firm, Branch / Office, Financial Professional"),
    ("keys_g1_01_02.py", "01 Investment Mandate.Client; Model Portfolio.Model Sponsor / Platform; Distribution Availability.Platform Availability", "PARTY", "12 Institutional Client; 05 Distributor Firm; 05 Shelf Placement (recommend a Derived copy (05) in content_01)"),
    ("keys.py", "06 Market & Client Dimensions.Institutional Client", "PARTY", "12 Institutional Client"),
    ("keys_g3_06_07_10.py", "06 Distributor Hierarchy, Intermediary As Delivered, Linked Transaction.Contra Firm, Plan Position.Plan Advisor, Sponsor-Reported Assets.Sponsor; 10 Profitability Record.Partner Firm", "DISTRIBUTOR / FIN_PRO", "05 restored objects"),
    ("keys_g5_11_12_13_14.py", "11 Competitor Distribution Footprint, Industry Flow Observation, Market Share Record (Distributor Firm); 11 Mandate Search Event.Asset Owner; 12 Service Relationship.Client and Advising Consultant", "DISTRIBUTOR / INST_CLIENT / PARTY", "05 Distributor Firm; 12 Institutional Client; 05 Consultant Advisory Relationship"),
    ("keys_g4_08_09.py", "08 Distributor Due Diligence entries", "08", "05 Distributor Due Diligence"),
    ("semantic_model/models/sm_00_shared_dimensions.py", "distributor_firm, distributor_office, team and advisor dimensions; institutional_client (client_party_type note); consultant_relationship", "Party", "05 and 12 restored objects; Institutional Client Type"),
    ("content_18_portfolio_and_investment_book_of_record.py", "Portfolio Holding.Corresponding Shareholder Position", "Reference (Position)", "Reference (Fund Shareholder Position)"),
    ("content_43_corporate_treasury_and_capital.py", "Seed Valuation.Source Shareholder Position", "Reference (Position)", "Reference (Fund Shareholder Position)"),
    ("content_16_retirement_plan_administration.py", "Vested Balance.Source Position", "Reference (Position)", "16's own participant balance (W1 ruling; for the 16 W3 drafter)"),
    ("content_19_finance_and_accounting.py", "Payable Invoice.Source Partner Invoice; Supplier Payment.Settled Partner Payment", "05", "05 (names unchanged; IFI- invoices added)"),
    ("content_13_investor_servicing_and_shareholder_communications.py", "Intermediary Communication Fee Invoice (transitional)", "13", "removed; 05 holds it (CW-088)"),
    ("content_13", "Confirmation.Confirmed Transaction", "Reference (Transaction)", "48 Client Trade Confirmation per CW-081 and CW-098 (13 brief decides)"),
    ("content_10_distribution_finance_and_profitability.py", "Distribution Revenue Record.Sales Charge Source Transactions", "06 Transaction", "kept (IC 12b-1 lever only, CW-156); Transaction Sales Charge is gone"),
    ("DP-005", "Trading Setup, Payment Terms, Payment Limit, Program Benefit, Distribution Fee Pass-Through (if read at attribute level)", "05", "merged objects (Partner Dealer Setup, Payment Arrangement, Program Membership) or dropped"),
    ("DP-006", "Transaction Sales Charge; Salesperson Credit.Crediting Rule Applied; Market & Client Dimensions.Territory", "06", "dropped with a 'W4' note"),
    ("DP-007, DP-108, DP-204, DP-241", "Position", "06 Position", "06 Fund Shareholder Position"),
    ("DP-008", "Certified Flows & AUM", "06", "WP0 re-scope to Client Assets & Net New Assets (CW-142)"),
    ("DP-243", "12 Billing Arrangement, Fee Invoice, Billing Dispute; 12 Client Feedback Response; 05 pipeline", "12", "47 objects; 04 Survey Response; 05 Sales Opportunity, Pipeline Status, Opportunity Value, Win / Loss (Consultant Coverage measure returns)"),
    ("DP-001, DP-002, DP-003", "inputs cut at W1", "02 Party", "WP0 re-scope on the 05, 12 and 16 restored objects"),
    ("DP-140, DP-163", "Mandate Termination; Breach Notification", "12", "unchanged (Final Invoice -> 47)"),
]

NOTES = [
    "Ids: CW-131 to CW-151 and CW-905, CW-906, CW-912 used; CW-152 to CW-155 left unused.",
    "Attribute sets of the restored 02 profiles: the wholesale 02 module is not on the branch (CW-021, W1 merge step 1). The briefs list the attribute names recovered from the compiled module content/__pycache__/content_02_client_and_customer.cpython-314.pyc (dated 2026-10-06; 52 objects and 296 attributes including Record Metadata, which matches wholesale-v1.0's 51 objects and 286 attributes once Record Metadata is excluded) and the object list in baseline/wholesale-v1.0.json. The program lead confirms them against tag wholesale-v1.0 before drafting (git is the lead's).",
    "The restored profiles become Business Objects keyed by a '<role> Party' Reference (Party) attribute (the Issuer Profile pattern, enrich_17), because an attribute group cannot have a parent in another domain (enrichment CONTRACT). Form ADV Profile and Advisor Practice are attribute groups of the 05 Distributor Firm and Financial Professional.",
    "Distribution Channel: CW-164 (proposals_w4_economics.py) re-cuts the list; CW-140 only refines RETIREMENT_DCIO -> INTERMEDIARY_RECORDKEEPER and states the roll-up of the CW-011 'advised and managed' channel. The lead reconciles the two at merge; 01's local values (Direct Brokerage (Self-Directed), Advice Program, Workplace Plan Menu, Intermediary, Institutional) map to DIRECT_SELF_DIRECTED, the DIRECT_*_ADVICE values (by offering), WORKPLACE, INTERMEDIARY and INSTITUTIONAL.",
    "Dependencies on W2: 03 adds intermediary and institutional activity types to Advisor Activity and keeps the institutional relationship manager on Party Coverage Assignment (CW-138); 04 Survey Response and Attributed Outcome names (CW-085, CW-093); 08 Compliance Review and Gift / Entertainment Item names; 47 holds the moved 12 billing objects and CW912_ITEMS (proposals_w2_47.py).",
    "Dependencies on W3: 49 Client Holding (CLHLD-), Client Holding Valuation, Client Account Activity (CLACT-) and Account Transfer (ACXF-), 50 Money Movement (MMVMT-) per proposals_w3_brokerage.py (the plan anchors CHL-, CAA-, MMT- were rejected there); 29 masters Share Register Balance and Register Transaction (CW-122, proposals_w3_oversight.py), adopted by the 06 row rules; 29 Fund Order.Resulting Transaction and AP Resulting Transaction re-type to Register Transaction, so 06 Transaction loses those readers; 29 adds OWN_BD_OMNIBUS to its Dealing Route use; 16 restores Recordkeeper Profile and Plan Service Provider and confirms the plan sponsor boundary (CW-146); 24 names the strategic asset allocation object the IPS references; 52 names the manager objects OCIO Service Detail references; 32 Client Account Performance is never computed in 06.",
    "Dependencies on W4 economics: 10 renames its Hierarchy Node to Management Hierarchy Node (CW-159), which removes the name clash with the restored 05 Hierarchy Node; 10 reads 05 PYA-, PCL- and 06 Client Assets and NNA (CW-156, CW-157); 11 Mandate Search Event.Linked Opportunity and 36 Evidence Shelf Placement and Evidence Model Program Placement resolve to 05 (CW-170); 07 retirement (CW-907) retires the territory and crediting prefixes 06 no longer references.",
    "Tooling: none required; domains.py already has REPLACEMENT_L1_CODE['05'] = 'DI' and the 06 rename in DISPOSITION. check_enrichment.py picks a module by directory order (W1 merge notes): the 05 drafter writes beside the wholesale module, so the lead must check that the new module is picked. The PREFIXES status 'Restored' used here is new; the lead maps it to 'Registered' or 'Proposed' with the new owner at merge.",
    "Unverified, marked 'confirm' in the briefs: Form ADV Part 1A PDF path; FINRA Form BR page; ICI distributor DDQ page; FINRA Rule 2251 and NYSE Rule 451 as the source of intermediary communication processing fees (and the current fee schedule rule number); Advisers Act Rules 206(4)-5 and 206(4)-2 eCFR paths; UPMIFA and the CFA Institute IPS guidance pages; Form N-PX PDF path; IRC section 402(c) rollover page; Salesforce object reference paths.",
]
