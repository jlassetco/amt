"""Wealth-manager reference model: W4 brief decisions for 10, 11, 36 and 38 (adapted) and the retirement of 07 and 30.

Written by the W4 brief agent for 10 Client Revenue, Pricing Economics & Profitability, 11 Market & Competitive
Intelligence, 36 Product Development & Lifecycle, 38 Corporate Compliance & Regulatory Affairs and the retirement of
07 Compensation & Territory and 30 Private Markets, with the briefs in 00_Program/Rework/Briefs/
(10_Client_Revenue_Pricing_Economics_and_Profitability.md, 11_Market_and_Competitive_Intelligence.md,
36_Product_Development_and_Lifecycle.md, 38_Corporate_Compliance_and_Regulatory_Affairs.md, W4_Retirement_of_07_and_30.md).
2026-10-14.

Proposal fragment only: the builder does not read this file. Format: the DECISIONS dict format and the PREFIXES tuple
format of decisions.py (see CONTRACT.md). Declarative only. Every decision is "Proposed" until the program lead merges
it; each states the tailoring lever where a client could rule differently.

Ids used: CW-156 to CW-170 (sequential, reserved for this batch), CW-910 (10), CW-911 (11), CW-936 (36) and CW-938 (38)
for the US-only decisions (pre-allocated by CW-022; the drafters complete them with their JURISDICTION lists in
proposals_10.py, proposals_11.py, proposals_36.py and proposals_38.py), and CW-907 (07) and CW-930 (30) for the
retirements (CW-019 names the decision that retired each domain in domains.RETIRED_DOMAINS).
"""

PL = "Program lead"
P = "Proposed"

DECISIONS = [
    # ---- 10 Client Revenue, Pricing Economics & Profitability -------------------------------------------------------
    {"id": "CW-156", "theme": "Ownership", "title": "10 masters booked client and fund revenue by offering, channel and client segment; 47 calculates fees, 19 certifies the ledger",
     "domains": ["10", "19", "47", "48", "49", "50", "16", "01", "02", "06"],
     "issue": "CW-012 keeps revenue recognition, allocation and profitability in 10 and gives fee calculation to 47; CW-011 keeps certified revenue on the ledger (DP-191). The wholesale 10 books only fund-level revenue (Fee Revenue Record per share class) and distribution revenue; a wealth manager earns advisory fees, commissions, account service fees, sweep and cash economics, fully paid lending revenue, plan recordkeeping fees and trust fees at account grain.",
     "resolution": "10 keeps Revenue Contract, Performance Obligation, Fee Revenue Record (own funds' management fees, including the money market sweep fund), Performance Fee Record (fulcrum fees under Advisers Act Rule 205-1 and 205-2 and Rule 205-3 mandate fees), Distribution Revenue Record (12b-1 and servicing revenue, IC channel only) and adds Client Revenue Record (CLREV-; revenue recognized per account or household x offering x revenue stream x period: advisory and wrap fees from 47 Account Fee Calculation, commissions and markups from 48 executions, account service fees from 47, margin interest from 49, fully paid lending revenue share from 49, plan recordkeeping and participant fees from 16 and 47, trust fees from 51 and 47, OCIO and mandate fees from 47; recognized amount, period, recognizing legal entity, offering 01 OFFR-, channel, business line, 02 client segment as a Derived copy as of the period end) and Cash Program Economics (sweep program x program bank x period: average swept balances as a Derived copy of 50, fee earned from program banks, client rate paid as a Derived copy of 50, net spread, money market sweep fund revenue as a reference to the Fee Revenue Record). Amounts are referenced from the calculating domain, never recalculated (wholesale design principle 1). 19 holds journals, postings and the certified revenue (DP-191); 10 holds Account Mapping to 19 GL accounts. 47 holds calculated fees, waivers and debits, 49 the posted debit, 50 the cash; 10 holds no fee rate schedule and no balance.",
     "rationale": "Revenue is recognized where finance recognizes it; the grain must reach the account so that cost to serve and lifetime value can be computed by segment (acceptance question 11). Lever: a fund-only firm drops Client Revenue Record and Cash Program Economics.",
     "action": "W4 (10)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-157", "theme": "Ownership", "title": "Cost to serve, client lifetime value and acquisition cost are 10; spend is 04, milestones 04, assets 06, pay 03 and 20",
     "domains": ["10", "04", "06", "03", "13", "20", "02", "45"],
     "issue": "Acceptance question 11 asks what it costs to serve each client segment and what lifetime value is by acquisition channel. The inputs live in 04 (campaign spend, acquisition milestones, attribution), 06 (client assets and net new assets), 03 (advisor compensation statements), 13 (service interactions) and 20 (payroll); the wholesale 10 has a Cost-to-Serve Profile for partner firms only.",
     "resolution": "10 masters Cost-to-Serve Profile (kept by name, re-cut to client segment, household, service tier, offering and channel: advice, service, platform, clearing and custody, money movement, communications and regulatory cost components, each from an Allocation Result), Client Acquisition Cost Record (acquisition channel x campaign x cohort month: allocated acquisition cost, new households and funded accounts as Derived copies of 04 Acquisition Milestone counts, cost per funded household), Lifetime Value Model (LTVM-; versioned method: horizon, discount rate, attrition and asset-growth assumptions, margin basis) and Client Lifetime Value Estimate (household x model version x as-of: expected revenue, expected cost to serve, lifetime value, acquisition channel and cohort). 04 keeps campaign budgets, spend lines and attribution weights; 06 keeps client assets and net new assets; 10 copies none of them as mastered values. Lifetime value and cost-to-serve values are financial inferences about a household: PII - financial, aggregates in products.",
     "rationale": "Client economics is a finance model run on other domains' facts. Lever: a firm without household-level economics keeps the segment grain only.",
     "action": "W4 (10)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-158", "theme": "Ownership", "title": "Pricing economics: Pricing Scenario is 10; the schedule is 47, the change initiative 36, the competitor prices 11",
     "domains": ["10", "47", "36", "11", "01"],
     "issue": "The new name of 10 adds pricing economics. A fee or rate change touches the 47 fee schedule (what clients pay), the 36 change initiative (approval and regulatory clock), the 11 competitor price observations and 10's revenue impact.",
     "resolution": "10 masters Pricing Scenario (PRSC-; subject offering, share class or fee schedule x scenario: proposed rate or schedule version, affected accounts and assets as Derived copies, assumed retention and flow response, projected revenue impact by year, breakeven) and Pricing Scenario Result (scenario x year). 47 masters the current and proposed client Fee Schedule versions (CLFEE-) and their effective dates; 01 the fund expense terms (FSCH-); 36 the Proposed Term Change and approval; 11 Competitor Pricing Observation and Fee Benchmark Result. A Pricing Scenario references them; it holds no adopted rate.",
     "rationale": "One owner for the economics of a price, distinct from the price itself. Lever: a firm that prices only through the fund board drops Pricing Scenario for share classes.",
     "action": "W4 (10)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-159", "theme": "Structure", "title": "10 kept names, renames and re-points (partner payment accounting shrinks to IC; Hierarchy Node renamed)",
     "domains": ["10", "02", "05", "03", "07", "19", "21"],
     "issue": "Live products read 10 by object name (DP-012, DP-105, DP-109, DP-170, DP-183, DP-194 to DP-196, DP-242 to DP-245) and SM-07 owns the certified fee revenue metrics on DP-012. 10's own Hierarchy Node is resolved by name to the wholesale 02 Hierarchy Node (proposals_w1_02 NOTES), which moves to 05 at W4. 10 references 07 Territory, Compensation Statement and Incentive Compensation Plan, 03 Sales Forecast (FCS-, retired) and 05 payment calculations.",
     "resolution": "Kept by exact name: Revenue Contract, Performance Obligation, Fee Revenue Record, Performance Fee Record, Distribution Revenue Record, Waiver Record, Adviser-Borne Cost, Distribution Cost Item, Accrual, Contract Cost Asset, Capitalization Assessment, Account Mapping, Control, Cost Pool, Allocation Method, Allocation Driver, Allocation Rule, Allocation Run, Allocation Result, Profitability Record, Profitability Measure, Profitability Measure Definition, Cost-to-Serve Profile, Management Hierarchy, Hierarchy Restatement, Plan Version, Plan Line, Flow & Revenue Forecast, Variance, Intercompany Agreement, TP Policy, Intercompany Charge. Renamed: Hierarchy Node -> Management Hierarchy Node (MHY- node keys unchanged). Dropped: Record Metadata (CD-160). Re-points: Profitability Record.Territory removed (07 retired, CW-907); Salesperson renamed Advisor (03, EMP-); Partner Firm kept for IC; Distribution Cost Item sources 05 partner payments (IC only), 03 Compensation Statement (CPS-), 04 spend, 14 data costs, 40 supplier invoices; Capitalization Assessment.Assessed Cost Source resolves to 03 Incentive Compensation Plan components (ICP-n-Cnn); Flow & Revenue Forecast.Sales Forecast Reference removed (FCS- retired, CW-062) and the forecast re-cut to net new assets and revenue by channel and offering reading 06; Source Domain value 07 removed. Prefixes kept: DCO-, ALM-, PNL-, BUD-, RVC-, FRR-, PFR-, WVR-, ACR-, CCA-, ACM-, CPO-, DRV-, ARU-, ARN-, MHY-, HRS-, ICA-, ICC-. L1 code DF kept.",
     "rationale": "Name continuity keeps the live readers resolving (CW-021 by analogy). Lever: rename Distribution Cost Item to Client & Channel Cost Item at W5 with its readers.",
     "action": "W4 (10); W4 merge (readers)", "status": P, "priority": "Medium", "owner_role": PL},

    # ---- 11 Market & Competitive Intelligence ----------------------------------------------------------------------
    {"id": "CW-160", "theme": "Ownership", "title": "11 covers the retail and wealth market: competitor offerings and pricing, industry flows by channel, investor-segment sizing; competitors are 02 parties",
     "domains": ["11", "02", "01", "14", "04", "05", "52", "36", "10"],
     "issue": "CW-013 adapts 11 to the retail and wealth market. The wholesale 11 tracks fund-manager competitors in intermediary channels (wholesaler headcount, distributor-firm flows, consultant searches, UK and EU fund ratings).",
     "resolution": "11 keeps Competitor Profile (CPF-, keyed to a 02 Party; hypothetical names only in examples), Industry Dataset Profile, Industry Data Release, Industry Flow Observation, Category Mapping, Market Share Definition and Record, Industry Ranking, Peer Universe and Member, Peer Fund, Peer Metric Snapshot, Rating Scheme and Observation, Medalist and Sustainability Rating Detail, Award, Fee Benchmark Study and Result, Pricing Input, Market Sizing Record, Opportunity Potential (IC, thin), Plan Market Record (WR), Market Research Report, Market Trend, Mandate Search Event (IA), Win/Loss Analysis (IA and IC), Intelligence Item, Regulatory Horizon Item, Competitor Metric Snapshot (re-cut to client assets, net new assets, accounts, advisors), Competitor Distribution Footprint (re-cut to channel presence), Competitor Event and Competitor Personnel Move. Adds Competitor Offering (COFF-; competitor x offering: brokerage, digital advice, hybrid and human advice programs, workplace recordkeeping, cash and sweep, ETF and fund ranges; features, minimums, channel) and Competitor Pricing Observation (offering x price component x as-of: advisory fee rate or schedule, commission per trade, account service fee, sweep or cash yield, expense ratio). Drops Manager Rating (Citywire) and Record Metadata. Fee Benchmark Study subjects extend to 01 Service Offerings and 47 fee schedules. Consultant-database intelligence is kept only for IA mandate searches.",
     "rationale": "A direct wealth manager competes on advice price, platform features and cash yield as much as on fund performance. Lever: a firm with a large advisor channel restores the intermediary depth from the sibling.",
     "action": "W4 (11)", "status": P, "priority": "Medium", "owner_role": PL},

    # ---- 36 Product Development & Lifecycle -------------------------------------------------------------------------
    {"id": "CW-161", "theme": "Ownership", "title": "36 governs fund, advice-service and platform-feature development; reviews re-cut to US product governance",
     "domains": ["36", "01", "15", "35", "38", "41", "46", "47", "08", "13"],
     "issue": "Plan section 5.1 adds advice-service and platform-feature development to 36 and removes the Consumer Duty value assessment. CW-036 makes service offerings 01 objects that 36 governs. The wholesale 36 carries FCA PROD 3, COLL 4.3 and 6.6.20R, PRIN 2A and MiFID product governance content; its review key example carries 'AOV'.",
     "resolution": "36 keeps every object except Target Market Review Result and Value Assessment Criterion Result, and adds Service Offering Specification (attribute group of Product Change Initiative: proposed offering type, delivery mode, discretion, advisory capacity, minimum, models, proposed 47 fee schedule, Rule 3a-4 and wrap fee indicators, created 01 OFFR-), Platform Feature Specification (attribute group: feature type as 15 Feature Type, 01 Tradable Universe Policy Rule TUP-, eligible offerings and account types, disclosure type, 41 Release) and Product Review Criterion Result (review x criterion x subject: performance against benchmark and peers, fees against peers (11), profitability (10), scale and flows (06), client outcomes for programs (46 drift and 08 complaint counts as references), operational issues). Product, change, scope and review objects gain a 01 Service Offering reference beside Investment Product, Share Class and Model Portfolio. Product Change Type adds Advice Program Launch, Program Change, Program Pricing Change, Program Closure, Platform Feature Launch, Platform Feature Change, Platform Feature Retirement, Service Tier Change; Change Regulatory Requirement adds Form ADV Part 2A or Appendix 1 Amendment, Form CRS Amendment (38), Advance Fee Change Notice (47), Advisory Agreement Amendment (15). Review types re-cut to Periodic Product Review (FINRA Regulatory Notice 05-26 practice, confirm), Post-Launch Review, Advice Program Review, Fund Range Rationalization Review, CIT Annual Review; the PRVW- example is re-keyed PRVW-2026-00981-PPR-01. Section 15(c) evidence stays 35; board approvals stay 35 Board Resolution.",
     "rationale": "Clients choose funds and programs together; one product governance process approves both. Lever: a fund-only firm drops the two new specifications.",
     "action": "W4 (36)", "status": P, "priority": "Medium", "owner_role": PL},

    # ---- 38 Corporate Compliance & Regulatory Affairs ---------------------------------------------------------------
    {"id": "CW-162", "theme": "Ownership", "title": "38 adds the broker-dealer, transfer agent and trust company registrations, Form CRS filing, adviser custody status and the BD AML program (amplifies CW-015, CW-066)",
     "domains": ["38", "08", "15", "13", "47", "49", "43", "02", "50", "29"],
     "issue": "CW-015 and CW-066 keep the firm-level programs in 38 and add broker-dealer registration, FINRA membership, Form CRS filing and the BD AML program. CW-056 leaves the firm's custody status to 38. The wholesale 38 is built for an adviser and fund complex with EU and UK entities.",
     "resolution": "38 Entity Authorization covers SEC investment adviser registration (Form ADV), broker-dealer registration with FINRA membership and SIPC membership (Form BD), state broker-dealer registrations and adviser notice filings (Authorization Jurisdiction), MSRB registration (529 plans), transfer agent registration (Form TA-1), the national trust bank charter (OCC) or state trust company charter, CPO / CTA status. Firm Regulatory Filing adds Form CRS (adviser through IARD, broker-dealer through CRD), Form TA-1 and TA-2, Form ADV-E and keeps Form ADV, Form BD, 13F, 13G and 13D, 13H and SHO; Form CRS Filing Detail (attribute group: filer capacity, relationship summary version, material-change trigger, posted-to-website date) is the version that 15 delivers at opening, 13 delivers on update and 08 checks. Adds Adviser Custody Profile (adviser entity x period: custody bases such as fee deduction and standing letters of authorization, qualified custodians including the affiliated broker-dealer, surprise examination requirement, internal control report for a related qualified custodian) and Custody Surprise Examination (entity x examination: accountant, Form ADV-E filing reference), under Advisers Act Rule 206(4)-2. AML Program Assessment covers the broker-dealer (FINRA Rule 3310; 31 CFR 1023.210), the funds (31 CFR 1024.210), the trust company where present and the adviser (31 CFR 1032, effective date postponed to no earlier than 2028-01-01, confirm); AML Case adds sources from 50 cash-movement monitoring and FinCEN 314(a) requests; CIP and beneficial ownership stay 02 (CW-025). OBA Type adds FINRA Rule 3240 and 3241 declarations (CW-074; Rule 3290 approved, effective date pending, confirm). Program Review Type adds the PTE 2020-02 retrospective review (CW-066), Regulation S-P program review and the Regulation S-ID annual report.",
     "rationale": "The registrations, filings and programs of each regulated entity are one firm-level record. Lever: a firm without a trust company drops the charter and its AML row.",
     "action": "W4 (38)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-163", "theme": "Ownership", "title": "Surveillance and privacy boundaries of 38: market-abuse surveillance in 38, sales-practice surveillance in 08; privacy program oversight in 38, safeguards in 41, consents and notices in 02 and 13; retention schedule in 21",
     "domains": ["38", "08", "25", "48", "50", "29", "41", "02", "13", "21"],
     "issue": "38 Trade Surveillance Alert covers portfolio orders and personal trading; the wealth firm adds client orders (48). 08 runs sales-practice surveillance (SCEN-). Regulation S-P and S-ID involve 41 (safeguards, incident response), 02 (privacy profile, consents, opt-outs), 13 (notices) and 40 (service-provider oversight). The W2 08 brief moved the records retention schedule to 21 (CW-068).",
     "resolution": "38 masters market-abuse and firm-conduct surveillance (Trade Surveillance Alert, TRSV-) over 25 portfolio orders, 48 client orders and executions (Reference (Client Order, 48), CLORD-, and Client Execution, CLEXE-) and 38 personal transactions, with scenarios such as front running of customer orders (FINRA Rule 5270), trading ahead (Rule 5320), spoofing and marking the close; escalation to an AML Case and a SAR replaces the EU STOR. 08 masters sales-practice surveillance (suitability, Reg BI, excessive trading, senior investor). 50 and 29 own transaction monitoring alerts; 38 owns the cases. 38 oversees the privacy program by Policy, Regulatory Obligation and Compliance Program Review rows referencing 41 Information Security Program and Security Incident Detail; it holds no consent, notice or incident record. The records retention schedule is 21 Retention Rule (CW-068); 38 Policies reference it.",
     "rationale": "One owner per surveillance purpose and per privacy record. Lever: a firm that runs one surveillance team keeps the split as scenario ownership only.",
     "action": "W4 (38)", "status": P, "priority": "Medium", "owner_role": PL},

    # ---- Shared lists due at W4 (CW-039) ----------------------------------------------------------------------------
    {"id": "CW-164", "theme": "Code Lists", "title": "Shared-list re-cuts due at W4 (completes CW-039)",
     "domains": ["09", "01", "02", "08", "11", "14", "36", "05", "06", "03", "04", "07", "30", "33", "13"],
     "issue": "CW-039 and the W1 and W1b merge notes leave Distribution Channel, Distribution Market, Investor Category, Investor Qualification Standard, Vehicle Type, Audience Restriction, COLL Change Classification, Measurement Basis PCT_OF_CAPITAL and Regulator US_STATE_INSURANCE_REGULATOR for W4.",
     "resolution": "See SHARED_RECUTS below. Distribution Channel re-cut to the wealth channels (direct, workplace, institutional, thin intermediary); Distribution Market retired (one value, below the two-value floor; geography is 09 Geographic Group); Investor Category and Investor Qualification Standard drop their MiFID and AIFMD values; Vehicle Type adds FEEDER_FUND and TENDER_OFFER_FUND and drops the private-fund and UK pension values; Audience Restriction drops PROFESSIONAL_INVESTOR_ONLY and PARTNER_SPECIFIC; COLL Change Classification retires with 36's attribute; Measurement Basis drops PCT_OF_CAPITAL and keeps PCT_OF_COMMITMENTS for drawdown feeder funds; Regulator drops US_STATE_INSURANCE_REGULATOR (no insurance products); Fund Category Scheme drops EFAMA_EFC and IA_SECTOR; Data Provider drops EFAMA, INVESTMENT_ASSOCIATION, FE_FUNDINFO and CITYWIRE; Business Domain marks 07 and 30 retired. The 05 and 06 W4 briefs may refine the intermediary sub-values of Distribution Channel; the steward 09 applies the list at W5.",
     "rationale": "Drafters of every W4 domain need the target values now. Lever: the UK extension restores the removed values from the sibling.",
     "action": "W4 (local copies), W5 (shared_code_lists.py)", "status": P, "priority": "Medium", "owner_role": PL},

    # ---- Retirement of 07 and 30 ------------------------------------------------------------------------------------
    {"id": "CW-165", "theme": "Scope", "title": "Insurance-dedicated residues leave the carried domains (17, 27, 31, 33, 35, 38, 39, 43)",
     "domains": ["17", "27", "31", "33", "35", "38", "39", "43", "09"],
     "issue": "Plan section 2 puts insurance-dedicated funds and annuities out of scope; the W1b editors listed their residues for W4 without removing them.",
     "resolution": "Remove: 17 NAIC Designation Category and NAIC SVO Filing Status with their lists and source; 27 the insurer NAV and holdings package wording; 31 the NAIC Model 280 source and Stress Scenario Source 'Insurer Requested'; 33 Regulatory Regime 'IRC 817(h) Insurance-Dedicated', the IRC 817(h), Treasury Regulation 1.817-5 and NAIC sources and the 817(h) example; 35 RIC Qualification Determination.Section 817(h) Result and Relied 817(h) Rule Results, the Section 817(h) Result list, Exemptive Relief Type 'Mixed and Shared Funding' and the 817(h) family text; 38 Entity Authorization Type 'State Insurance License' and Conflict Category 'Insurer Client Relationship'; 39 Contract Subtype 'Fund Participation Agreement'; 43 the insurance-dedicated rows on Seed Units Held; shared Regulator value US_STATE_INSURANCE_REGULATOR (CW-164). None is EU/UK: no JURISDICTION entry; the removals are listed in each editor's NOTES under this decision.",
     "rationale": "Out-of-scope lines leave no orphan values. Lever: a full-service (Fidelity type) variant restores them with annuities (plan section 13).",
     "action": "W4 (editors of the named kept domains, logged changes to carried domains)", "status": P, "priority": "Low", "owner_role": PL},

    {"id": "CW-166", "theme": "Scope", "title": "What the carried domains keep when 30 retires: feeder-fund books, Form PF, seed capital in own funds, partnership tax of feeders",
     "domains": ["35", "43", "31", "18", "22", "27", "17", "39", "20", "32", "24", "33", "34", "19", "21", "37", "40", "41", "42", "44"],
     "issue": "Thirty references to 30 sit in carried and adapted modules (W1b NOTES). The firm keeps alternative-investment access through its own feeder funds (CW-038), which are 01 products with an 18 book holding a 17 fund-interest instrument; 30 manufactured private funds.",
     "resolution": "Reference default: the feeders are private funds advised by the fund adviser, so the adviser has private funds. 35 keeps Form PF (Section 1 only; confirm the sections that apply) with Filing Data Source values re-pointed from 30 Private Fund Profile and 30 Fund Credit Facility to 01 Feeder Access Terms and 18 Portfolio; LPAC content leaves 35 (Governing Body Type 'Private Fund LPAC', the LPAC consent values, Board Consent Record.Related Private Fund Deal). 43 keeps seed capital in own registered funds, ETFs, CITs and feeder funds; Seed Commitment Type values GP Commitment and Co-Investment and the attributes GP Investor Commitment, Resulting Capital Call, Resulting Private Fund Distribution and the 30 row of Seed Capital Balance are removed; Incubation Account is re-worded to a firm proprietary account incubating a model or strategy; Cash Flow Category 'Performance Fee and Carry Receipts' becomes 'Performance Fee Receipts' and 'GP Commitment Funding' is removed. 18 keeps Fund Interest Holding Detail and the feeder capital-activity values, removes Private Fund Portfolio Detail.Vintage Year and Subscription Credit Facility Indicator. 22 keeps GP-statement NAV pricing for fund interests and removes Private Asset Valuation Detail, the financing-round and exit back-test types and the IPEV source. 27 keeps Fund Tax Regime 'Partnership' for feeder funds; the 30 source references on Fund Journal Line and the Capital Call, Private Fund Distribution, Credit Facility and Carried Interest source values are removed; investor K-1s are 13 tax documents from the feeder administrator. 31 keeps Liquidity Horizon Bucket only while Form PF is filed, re-pointed to the 01 feeder product; Fund Borrowing Facility's 30 reference is removed. 20 removes Carried Interest Allocation, Co-Investment Entitlement, Carry Vehicle Interest, Realization-Based vesting and Carried Interest Points. 39 removes the four 30 typed links and their record types; feeder side letters with underlying managers are plain 39 Contracts. 32 Private Markets Performance family leaves 32, feeder returns are ordinary 32 returns. 24 Decision Scope Deal, Commitment Pacing Plan and the value Private Investment Approval (left for W4 by W3_24_32_Family_Additions.md), and 33 Tested Deal and 'Deal Pre-Approval' are removed. 17 keeps Private Market Instruments (underlying funds) with the 30 wording re-pointed to the 01 feeder. Text-only mentions in 19, 21, 23, 34, 37, 40, 41, 42, 44 are re-worded or removed.",
     "rationale": "Keep what the feeder business needs, nothing that only manufacturing needed. Lever: registered (tender-offer or interval) feeders or third-party feeder platforms remove Form PF and Liquidity Horizon Bucket too; private-markets manufacturing restores 30 from the sibling.",
     "action": "W4 (editors of the named domains; 24 and 32 at the W4 merge, as the W3 brief left them)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-167", "theme": "Structure", "title": "Mechanics of a retired Data Domain (applies CW-019 to 07 and 30)",
     "domains": ["07", "30", "09", "21"],
     "issue": "CW-019 creates RETIRED_DOMAINS but does not say what happens to the module, folder, enrichment, keys, products, models, semantic models, registers and prefixes of a retired domain.",
     "resolution": "At the W4 merge: 1) domains.RETIRED_DOMAINS = {'07': 'CW-907', '30': 'CW-930'}; DD_NAMES, L1_CODE (CT, PV) and DISPOSITION ('retire') keep the entries so historical decisions and prefixes validate; WEALTH_DOMAINS drops them; DISPOSITION['38'] becomes ('adapt', '') with its W4 adaptation. 2) content_07_compensation_and_territory.py, content_30_private_markets.py, enrich_07.py, enrich_30.py, 07_Compensation_and_Territory/ and 30_Private_Markets/ are deleted from the branch (they remain at tag wholesale-v1.0). 3) check_baseline.py reports 'Data Domain 07 Compensation & Territory retired by CW-907' and '30 Private Markets retired by CW-930', not removals. 4) decisions.PREFIXES: every remaining 07 and 30 prefix takes status 'Retired (sibling)' (retired in the wealth model, live in the wholesale sibling, never reused; RETIRED_PREFIXES below); CVA-, ICP- and CPS- were transferred to 03 at W2. 5) CONCEPT_OWNERSHIP rows owned by 07 and 30 keep their text with a note starting 'Retired (CW-907)' or 'Retired (CW-930)' so the resolver skips them; shared_code_lists memberships of 07 are removed; TERM_CONFLICTS usages naming 07 or 30 are marked retired at W5; gaps_register entries GAP-07- and GAP-30- lapse. 6) Products, logical models, keys and semantic models are re-pointed or retired as listed in W4_Retirement_of_07_and_30.md (SM-13 retires; DP-116, DP-117, DP-136 to DP-139 and DP-160 retire at WP0 with their models; FN-25 and FN-26 keep their codes with no products and are never reused). 7) The capability map COVERAGE_NOTES rows for 07 and 30 read 'Retired by CW-907 / CW-930'.",
     "rationale": "A retired domain disappears from the rendered model but every identifier it used stays resolvable as history. Lever: a firm with sales territories or private-markets manufacturing restores the module from the sibling with its prefixes.",
     "action": "W4 merge (domains.py, decisions.py, files), WP0 (products and models)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-168", "theme": "Ownership", "title": "38 keeps the firm conflicts register with wealth conflict categories; Reg BI incentive review is 08; the sweep and proprietary-product conflicts are disclosed, not re-mastered",
     "domains": ["38", "08", "03", "10", "01", "50"],
     "issue": "The SEC and FINRA focus on cash sweep economics, proprietary products in advice and advisor compensation. 38 Conflict of Interest lists asset-manager categories; 08 Incentive Conflict Review covers compensation (CW-066).",
     "resolution": "38 Conflict Category adds Proprietary Products in Advice, Cash Sweep Economics, Account Type Recommendation (fee-based or commission), Advisor Compensation (identified, reviewed in 08), Revenue Sharing and Platform Payments (IC), Principal Trading with Clients, Trust Company Self-Dealing (12 CFR 9.12); the register references Form ADV Part 2A and Form CRS disclosure locations and 10 Cash Program Economics as evidence. 08 reviews incentives; 10 measures the economics; 38 holds the conflict.",
     "rationale": "One firm conflicts register, many evidence sources. Lever: none.",
     "action": "W4 (38)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-169", "theme": "Governance", "title": "Term conflicts from the W4 economics briefs (log at W5)",
     "domains": ["10", "11", "36", "38", "47", "45", "08", "13", "06", "50"],
     "issue": "New and re-cut names overlap neighbors.",
     "resolution": "Log: Revenue (10 Client Revenue Record and Fee Revenue Record; 19 certified revenue; 47 calculated fee; 06 estimated fee revenue); Cost to Serve (10 Cost-to-Serve Profile; 13 service level); Lifetime Value (10 Client Lifetime Value Estimate only); Scenario (10 Pricing Scenario; 45 Planning Scenario; 19 Plan Scenario); Offering (01 Service Offering; 11 Competitor Offering); Review (36 Product Review; 45 Advice Review; 08 Supervisory Review; 38 Compliance Program Review); Surveillance (38 Trade Surveillance Alert; 08 Surveillance Scenario and Sales Practice Alert); Custody (38 Adviser Custody Profile, the Rule 206(4)-2 status; 49 client asset custody; 28 fund custody); Program (38 compliance program; 01 advice program; 50 sweep program); Form CRS (38 filing; 15 opening delivery; 13 update delivery; 08 delivery check).",
     "rationale": "Glossary terms prevent silent reuse.",
     "action": "W5", "status": P, "priority": "Low", "owner_role": PL},

    {"id": "CW-170", "theme": "Structure", "title": "36 and 11 references to removed and re-cut neighbors (01 Country Registration and Target Market, 08 feedback and outcome metrics, 05 placements, 03 opportunities)",
     "domains": ["36", "11", "01", "08", "05", "03", "35"],
     "issue": "CW-901 removed 01 Country Registration and Target Market; CW-067 removed 08 Distributor Feedback Report and Outcome Metric; 03 Sales Opportunity is held for 05 (CW-062); 36 and 11 still reference them.",
     "resolution": "36: Readiness Check.Evidence Country Registration removed and Readiness Workstream 'Registration' re-pointed to 35 state notice filings (NSMIA); Target Market Review Result removed with the two attributes already removed early (CW-067); Value Assessment Criterion Result.Outcome Evidence Metric removed with the object; Proposal.Intended Distribution Markets removed (Distribution Market retired, CW-164); Evidence Shelf Placement and Evidence Model Program Placement stay typed Reference (Object, 05) for IC launches, resolved by the 05 W4 brief or dropped with a note if 05 does not keep them; Proposed Business Line examples use CW-004 codes. 11: Mandate Search Event.Linked Opportunity re-typed Reference (Opportunity, 05) if the 05 brief keeps OPP-, else removed; the relationship to 07 Territory Potential Metric removed; Distributor Firm references keep Reference (Party).",
     "rationale": "Every reference resolves to an object that exists in the wealth model. Lever: none.",
     "action": "W4 (36, 11); W4 merge", "status": P, "priority": "Medium", "owner_role": PL},

    # ---- US-only decisions (pre-allocated, CW-022) and retirements (CW-019) -----------------------------------------
    {"id": "CW-910", "theme": "Scope", "title": "US-only pass of 10 Client Revenue, Pricing Economics & Profitability",
     "domains": ["10"],
     "issue": "The wholesale 10 describes a wholesale distributor reporting under ASC 606 and IFRS 15 with UK and Luxembourg entities, VAT on intercompany charges, MiFID inducement assessments and trail commissions.",
     "resolution": "Drafted by the 10 drafter in proposals_10.py with its JURISDICTION list (brief section 4a): Accounting Framework values IFRS (EU-adopted), UK-adopted IFRS, FRS 102 and Lux GAAP (mapped to None in the Accounting Basis crosswalk); IFRS 15 and IFRS 8 secondary references and sources; Distribution Cost Item.Inducement Assessment Reference (MiFID II); Distribution Expense Category 'Trail Commission / Retrocession'; Intercompany Charge.VAT Treatment and its list; Revenue Contract Type and Customer Determination Basis UCITS / AIF wording; ManCo entities in examples; EUR and GBP examples; OECD TPG re-sourced to IRC section 482 as primary (OECD kept as secondary, confirm).",
     "rationale": "CW-003, CW-022.", "action": "W4", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-911", "theme": "Scope", "title": "US-only pass of 11 Market & Competitive Intelligence",
     "domains": ["11"],
     "issue": "The wholesale 11 tracks EU and UK fund markets, EU and UK data providers, UK ratings and EU/UK regulators.",
     "resolution": "Drafted in proposals_11.py (brief section 4a): Industry Data Provider values EFAMA, Investment Association, FE fundinfo, Citywire; Category Scheme values EFAMA EFC, IA Sector; Industry Vehicle Type values UCITS, AIF; Industry Channel values UK Platform, UK IFA / Wealth Manager / DFM, EU Private Bank, EU Retail Bank Network, EU Fund Platform; Regulatory Body values UK FCA, ESMA, European Commission, CSSF, Central Bank of Ireland, BaFin (mapped to None in the Regulator crosswalk); Rating Scheme values FE fundinfo Crown Rating and Citywire Manager Rating; object Manager Rating; Fee Measure 'Ongoing Charges Figure'; Fee Study Purpose 'Assessment of Value'; sources EFAMA, Investment Association, FE fundinfo, Citywire, FCA COLL 6.6.20R and Consumer Duty; EU examples (LU, EUR).",
     "rationale": "CW-003, CW-022.", "action": "W4", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-936", "theme": "Scope", "title": "US-only pass of 36 Product Development & Lifecycle",
     "domains": ["36"],
     "issue": "The wholesale 36 governs UK authorized funds and MiFID manufacturers (FCA PROD 3, PRIN 2A Consumer Duty, COLL 4.3 change classification, COLL 6.6.20R assessment of value, ESMA product governance guidelines, UCITS mergers, PRIIPs, FinDatEx EMT and EFT).",
     "resolution": "Drafted in proposals_36.py (brief section 4a): objects Target Market Review Result and Value Assessment Criterion Result (with Distributor Feedback Reviewed and Sales Outside Target Market Observed Indicator removed early under CW-067); attributes Changed Product Scope.COLL Change Classification (shared list retired), Product Review.AFM Board Approval Date, Change Impact Assessment.Foreseeable Harm Identified Indicator, Proposal.Intended Distribution Markets, Readiness Check.Evidence Country Registration; values Product Review Type Assessment of Value, Fair Value Assessment and the MiFID Periodic Product Review reading, Value Assessment Sign-off, Impact Area 'Consumer Duty Foreseeable Harm', Product Change Type 'SFDR Reclassification', Regulatory Requirement Type 'FCA Change Notification' and the COLL vote readings, Review Action Type 'Target Market Amendment' and 'Distribution Strategy Restriction', the Target Market Review Conclusion and Value Assessment Criterion lists; sources FCA COLL, FCA PROD 3 and PRIN 2A, ESMA product governance guidelines, UCITS Directive Chapter VI, PRIIPs and PS25/20, FinDatEx. 'Fund Substitution' (Section 26(c), insurance-dedicated) goes under CW-165. The AOV review example is re-keyed (CW-161).",
     "rationale": "CW-003, CW-022.", "action": "W4", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-938", "theme": "Scope", "title": "US-only pass of 38 Corporate Compliance & Regulatory Affairs",
     "domains": ["38"],
     "issue": "The wholesale 38 holds FCA, CSSF and Central Bank of Ireland authorizations, EU passports, MAR insider lists and STORs, SM&CR-adjacent compliance reporting, EU and UK major-holdings and short-selling notifications, CASS CMAR and UK and EU AML regimes.",
     "resolution": "Drafted in proposals_38.py (brief section 4a): object Cross-Border Passport with its Passport Type list; object Suspicious Transaction and Order Report (MAR Art 16; the US route is an AML Case and SAR); Entity Authorization Type values FCA Part 4A Permission, UK UCITS Management Company / ACD, UK AIFM, UCITS Management Company (Chapter 15), Authorized AIFM, Registered AIFM, Super ManCo, MiFID Investment Firm License, Irish UCITS Management Company, Irish AIFM; Regulated Activity values for FCA, UCITS, AIFMD and MiFID (list re-sourced to Form BD and Form ADV business descriptions, confirm); Source Regulation values FCA Handbook, EU Regulation / Directive, ESMA Guidelines; Firm Filing Form Type values TR-1, EU and UK Net Short Position, CASS CMAR; Disclosure Regime values EU Transparency Directive, UK DTR 5, EU and UK short selling; Examination Type 'Thematic Review'; Program Review Type MLRO Annual Report and Compliance Function Annual Report; Conduct Designation Type Relevant Person and Insider-List-Eligible; AML Institution Type UK Relevant Person and EU Obliged Entity; AML Report Type UK SAR, EU FIU STR, UK OFSI; FRN, CSSF and CBI wording on Regulator Reference Number; EU MAR, UK MAR and Commission Regulation references on the restricted, MNPI and insider-list objects (kept, re-sourced to Advisers Act Section 204A and Exchange Act Section 15(g)); sources FCA SYSC / SUP / COBS 11.7, MiFID II Delegated Regulation 2017/565, ESMA compliance guidelines and CSSF, MAR, UK MLR 2017, EU Transparency Directive and SSR, UCITS / AIFMD / MiFID II, FCA / CSSF / CBI registers; GDPR in Notes re-sourced to Regulation S-P and state law.",
     "rationale": "CW-003, CW-022.", "action": "W4", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-907", "theme": "Scope", "title": "07 Compensation & Territory is retired (executes CW-013 with CW-062, CW-064, CW-080)",
     "domains": ["07", "03", "02", "06", "10", "04", "09", "19", "20", "37", "14", "21"],
     "issue": "CW-013 retires 07; the W2 03 brief moved coverage and incentive compensation to 03 (five objects kept by name; CVA-, ICP-, CPS- transferred) and dropped territories, goals, crediting and payout mechanics.",
     "resolution": "All 49 objects of the wholesale 07 leave the wealth model: 5 survive by name in 03 (Coverage Model, Call Frequency Standard, Party Coverage Assignment, Incentive Compensation Plan, Compensation Statement), 10 are re-cut into 03 objects (Alignment Rule, Alignment Rule Criterion, Alignment Exception, Realignment Event, Plan Component, Rate Table Tier, SPIF & MBO, Product Compensation Tier Mapping, Plan Participant Assignment, Earnings Result, per CW-062), Coverage Tier Assignment is 02 Service Tier Assignment, Coverage Team is re-cut into 03 Coverage Team, and the other 32 are dropped (territory, geography, goals, crediting, payout mechanics, governance, Remuneration Conflict Assessment, Record Metadata). Prefixes TER-, TMD-, ALR-, RLN-, GOL-, GPL-, CRR-, CRA-, CTM-, ERN-, DSP-, CTL-, RUN-, CPRD- take status 'Retired (sibling)'. Readers re-pointed or dropped per W4_Retirement_of_07_and_30.md section 5. No JURISDICTION entries (a retired domain records its retirement, not each object); the EU/UK content of the absorbed objects was recorded under CW-903.",
     "rationale": "Territories are not a wealth-manager concept beyond advisor assignment. Lever: a firm with a large advisor-channel sales force restores 07 from the sibling.",
     "action": "W4 merge (domains.RETIRED_DOMAINS['07'] = 'CW-907')", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-930", "theme": "Scope", "title": "30 Private Markets is retired (executes CW-016 with CW-038 and CW-166)",
     "domains": ["30", "01", "15", "17", "18", "20", "22", "27", "31", "32", "33", "35", "39", "43", "49", "50", "52"],
     "issue": "CW-016 retires 30; CW-038 places feeder-fund access in 01, 15, 49, 50 and 52.",
     "resolution": "All 36 objects of the wholesale 30 leave the wealth model (fund formation and closes, investor commitments, side letters and MFN, capital calls and distributions, equalization, capital accounts and partner tax allocations, deal pipeline and due diligence, portfolio companies and investments, fund financing, waterfalls and carried interest). Their wealth successors are: 01 Investment Product (vehicle Feeder Fund) with Feeder Access Terms and Offering Window (OFWN-); 15 Alternative Investment Subscription (AISB-); 49 client holdings and activity; 50 capital-call and distribution cash; 17 fund-interest instruments; 18 the feeder book; 52 underlying-manager due diligence. Prefixes ICMT-, CAPA-, CCN-, PDIS-, PDL-, FCF-, DWF-, CLOSE- take status 'Retired (sibling)'. SM-13 Private Markets retires; DP-116, DP-117, DP-136 to DP-139 and DP-160 retire at WP0; DP-145, DP-165, DP-186, DP-204, DP-241 and DP-243 drop their 30 inputs. Readers per W4_Retirement_of_07_and_30.md section 5; carried-domain survivors per CW-166. No JURISDICTION entries (the 30 module's EU/UK content leaves with the domain; the sibling keeps it).",
     "rationale": "Private-markets manufacturing is out of scope (plan section 2). Lever: a firm with private-markets manufacturing restores 30 from the sibling.",
     "action": "W4 merge (domains.RETIRED_DOMAINS['30'] = 'CW-930'); WP0 (products)", "status": P, "priority": "High", "owner_role": PL},
]

# ---------------------------------------------------------------------------------------------------------------------
# Shared-list re-cuts due at W4 (CW-164): (list, steward, action, values after, removed values, note)
# ---------------------------------------------------------------------------------------------------------------------
SHARED_RECUTS = [
    ("Distribution Channel", "09", "re-cut",
     ["DIRECT", "DIRECT_SELF_DIRECTED", "DIRECT_DIGITAL_ADVICE", "DIRECT_HUMAN_ADVICE", "DIRECT_TRUST",
      "WORKPLACE", "WORKPLACE_RECORDKEPT",
      "INSTITUTIONAL", "INSTITUTIONAL_DIRECT", "INSTITUTIONAL_CONSULTANT", "INSTITUTIONAL_OCIO",
      "INTERMEDIARY", "INTERMEDIARY_WIREHOUSE", "INTERMEDIARY_REGIONAL_BD", "INTERMEDIARY_IBD", "INTERMEDIARY_RIA",
      "INTERMEDIARY_BANK_TRUST", "INTERMEDIARY_TAMP_MODEL", "INTERMEDIARY_BROKERAGE_PLATFORM", "INTERMEDIARY_RECORDKEEPER"],
     ["INTERMEDIARY_IFA_WEALTH", "INTERMEDIARY_DFM", "INTERMEDIARY_EU_BANK", "INTERMEDIARY_FUND_PLATFORM (renamed BROKERAGE_PLATFORM)",
      "INTERMEDIARY_INSURANCE_BD", "INTERMEDIARY_INSURANCE", "INTERMEDIARY_FUND_OF_FUNDS", "INTERMEDIARY_PRIVATE_BANK",
      "INTERMEDIARY_FAMILY_OFFICE", "INTERMEDIARY_RIA_INDEPENDENT", "INTERMEDIARY_RIA_HYBRID", "INTERMEDIARY_RIA_CUSTODIAN",
      "SUB_ADVISORY", "DIRECT_TO_INVESTOR (renamed DIRECT)", "RETIREMENT_DCIO (becomes INTERMEDIARY_RECORDKEEPER, CW-139)"],
     "EU/UK values go under CW-911 (11 Industry Channel); insurance values under CW-165; RIA and private-bank sub-values merged (thin IC, CW-013). Members after W4: 01, 04, 05, 06, 11 (03 and 07 memberships end with their modules). The 05 and 06 W4 briefs may refine the INTERMEDIARY_ sub-values; the DIRECT_ and WORKPLACE_ values follow the Client Assets channels of CW-011."),
    ("Distribution Market", "09", "retire", [], ["US"],
     "One value, below the two-value floor. Members 03 (replaced), 05 (05 brief decides its local Agreement Market) and 07 (retired); direct user 36 drops Intended Distribution Markets. Geography for coverage is 09 Geographic Group; the UK extension restores the list."),
    ("Investor Category", "02", "re-cut", ["RETAIL", "INSTITUTIONAL", "FINANCIAL_PROFESSIONAL", "ACCREDITED_INVESTOR", "QUALIFIED_PURCHASER"],
     ["PROFESSIONAL", "ELIGIBLE_COUNTERPARTY", "QUALIFIED_INVESTOR"], "MiFID II values (CW-039); 36 is a direct user."),
    ("Investor Qualification Standard", "02", "re-cut",
     ["NONE_EVIDENCED", "ACCREDITED_INVESTOR", "QUALIFIED_CLIENT", "QUALIFIED_PURCHASER", "QUALIFIED_INSTITUTIONAL_BUYER"],
     ["AIFMD_PROFESSIONAL_INVESTOR"], "AIFMD value (CW-039). Feeder qualification (01 Feeder Access Terms, 02 Investor Qualification) uses the remaining values."),
    ("Vehicle Type", "01", "re-cut",
     ["OPEN_ENDED_FUND", "EXCHANGE_TRADED_FUND", "CLOSED_END_FUND", "INTERVAL_FUND", "TENDER_OFFER_FUND", "FEEDER_FUND",
      "COLLECTIVE_INVESTMENT_TRUST", "UNIT_INVESTMENT_TRUST", "SEPARATELY_MANAGED_ACCOUNT", "SEGREGATED_MANDATE", "MODEL_PORTFOLIO"],
     ["PRIVATE_FUND_DRAWDOWN", "EVERGREEN_PRIVATE_FUND", "POOLED_PENSION_UNIT_LINKED_FUND"],
     "Private-fund vehicles retire with 30 (CW-930); the UK pooled pension value is Other EU/UK (record under CW-901 as a late entry). Steward 01 to confirm whether SEPARATELY_MANAGED_ACCOUNT and SEGREGATED_MANDATE merge into one institutional separate account value (review_checklist_wealth section 8)."),
    ("Audience Restriction", "08", "re-cut",
     ["PUBLIC_RETAIL", "FINANCIAL_PROFESSIONAL_ONLY", "INSTITUTIONAL_ONLY", "ACCREDITED_INVESTOR_ONLY", "CLIENT_SPECIFIC", "INTERNAL_ONLY"],
     ["PROFESSIONAL_INVESTOR_ONLY", "PARTNER_SPECIFIC"],
     "As the 04 and 08 W2 briefs state. ACCREDITED_INVESTOR_ONLY is proposed for feeder-fund materials under Regulation D (confirm with the 08 steward)."),
    ("COLL Change Classification", "36", "retire", [], ["FUNDAMENTAL", "SIGNIFICANT", "NOTIFIABLE", "NOT_APPLICABLE"],
     "FCA COLL 4.3; members 36 and 13 (13's Shareholder Notice Change Classification goes with it, recorded under the 13 decision or CW-936)."),
    ("Measurement Basis", "01", "re-cut",
     ["PCT_OF_NAV", "PCT_OF_MARKET_VALUE", "PCT_OF_ISSUER_CAPITAL", "ABSOLUTE_AMOUNT", "COUNT", "PCT_OF_TOTAL_ASSETS", "DAYS", "RATIO", "RATING_NOTCH", "PCT_OF_COMMITMENTS"],
     ["PCT_OF_CAPITAL"], "PCT_OF_CAPITAL was the AIFMD II single-borrower limit; no own-fund restriction uses it (CW-930). PCT_OF_COMMITMENTS stays for drawdown feeder funds (lever: remove with registered feeders)."),
    ("Regulator", "09", "re-cut", None, ["US_STATE_INSURANCE_REGULATOR"], "Insurance residue (CW-165)."),
    ("Fund Category Scheme", "11", "re-cut",
     ["ICI_INVESTMENT_CLASSIFICATION", "MORNINGSTAR_CATEGORY", "MORNINGSTAR_GLOBAL_CATEGORY", "LIPPER_GLOBAL_CLASSIFICATION", "EVESTMENT_UNIVERSE", "FIRM_MARKET_SEGMENT"],
     ["EFAMA_EFC", "IA_SECTOR"], "CW-911."),
    ("Data Provider", "14", "re-cut", None, ["EFAMA", "INVESTMENT_ASSOCIATION", "FE_FUNDINFO", "CITYWIRE"],
     "CW-911; steward 14 confirms no 17, 22 or 34 reader uses them."),
    ("Business Domain", "09", "mark retired", None, [],
     "Values for 07 and 30 are kept with the label suffix '(retired, CW-907)' and '(retired, CW-930)' so historical rows resolve; no new row may use them."),
]

# Memberships to remove at the W4 merge (07 retires; CW-167):
MEMBERSHIPS_REMOVE = [("07", "Data Quality Status"), ("07", "Frequency"), ("07", "Sales Channel"), ("07", "Payment Status"),
                      ("07", "Data Classification"), ("07", "Approval Status"), ("07", "Market Scope"),
                      ("07", "Geographic Unit Type"), ("07", "Rule Status"), ("07", "Inclusion Type"),
                      ("10", "Data Classification"), ("10", "Data Quality Status"),   # Record Metadata dropped (CD-160)
                      ("11", "Data Classification"), ("11", "Data Quality Status"),   # Record Metadata dropped (CD-160)
                      ("36", "COLL Change Classification"), ("10", "Accounting Framework")]  # 10 keeps a US-only local list
# Note: 10 Accounting Framework rejoins Accounting Basis (steward 19) if its values reduce to US_GAAP, TAX_BASIS,
# REGULATORY; the 10 drafter decides and records it in SHARED_MEMBERSHIPS.

# ---------------------------------------------------------------------------------------------------------------------
# PREFIXES (prefix, entity, owner domain, status, note) - decisions.PREFIXES format. Each was checked with a script
# against decisions.PREFIXES (410 entries, every status), the W1 and W2 reservations (proposals_wealth_w1,
# proposals_w2_advice, proposals_w2_conduct, proposals_w2_engagement), the plan section 5.2 anchors (PLN FGL RCO ADE MAS
# RBL TLH TPB FSC FBR FDB FWV COR CEX CCF CRT CHL CLT RSV CAA CAX MMT SWP PBK MMH TRS TDD EST MGR MDD SAA PDD), the L1
# codes, the series codes (DP FN SM CD CW GAP) and every prefix-like token in the content modules. A candidate was
# rejected if equal to, an anagram of, or one edit away from any of them.
# Rejected near-misses:
#   10 Client Revenue Record: CRVR- (CRR- 07, CRV- 12), CREV- (REV- 08, CEV- 11, CRV- 12), CLRV- (CLR- 09, CLV- 09,
#      CRV- 12), REVR- (REV- 08), RVNU- (clear but opaque).
#   10 Lifetime Value Model: CLVM- (CLV- and CLM-, 09), CLTV- (CLV- 09, CLT- 49 anchor), VALM- (ALM- 10), LTV- (clear,
#      but reads as loan-to-value next to 49 margin), CLVE- (anagram of VCEL- 13).
#   10 Pricing Scenario: PSCN- (PSCEN- 45), PRICS- (PRICE- 22), PRCS- (anagram of PRSC-, reads as 'process').
#   11 Competitor Offering: CPOF- (CPO- 10, CPF- 11), CMPO- (CMP- 01, CPO- 10), COFR- (COR- 48 anchor). Noted, not
#      rejected: COFF- is two edits from OFFR- (01).
#   36 and 38: no new prefixes (new objects are attribute groups or take composite keys).
# ---------------------------------------------------------------------------------------------------------------------
R = "Reserved"

PREFIXES = [
    ("CLREV-", "Client revenue record (account or household x offering x revenue stream x period)", "10", R,
     "W4 brief 10 (CW-156). Rejected CRVR-, CREV-, CLRV-, REVR-, RVNU-."),
    ("LTVM-", "Lifetime value model (version is a separate attribute)", "10", R,
     "W4 brief 10 (CW-157). Rejected CLVM-, CLTV-, VALM-, LTV-, CLVE-."),
    ("PRSC-", "Pricing scenario (subject x scenario)", "10", R,
     "W4 brief 10 (CW-158). Rejected PSCN- (PSCEN-, 45), PRICS- (PRICE-, 22), PRCS-."),
    ("COFF-", "Competitor offering (competitor x offering)", "11", R,
     "W4 brief 11 (CW-160). Rejected CPOF-, CMPO-, COFR-; two edits from OFFR- (01)."),
]

# Prefixes of the retired domains: status 'Retired (sibling)' at the W4 merge (CW-167). Never reused by either sibling.
RETIRED_STATUS = "Retired (sibling)"
RETIRED_PREFIXES = {
    "07": ["TER-", "TMD-", "ALR-", "RLN-", "GOL-", "GPL-", "CRR-", "CRA-", "CTM-", "ERN-", "DSP-", "CTL-", "RUN-", "CPRD-"],
    "30": ["ICMT-", "CAPA-", "CCN-", "PDIS-", "PDL-", "FCF-", "DWF-", "CLOSE-"],
}
# Already moved or settled, listed for the merge check: CVA-, ICP-, CPS- transferred 07 -> 03 at W2 (CW-062); CP-
# (07) keeps status 'Renamed' (to CPRD-, CD-135), and CPRD- retires.

# Prefixes the adapted domains keep (already in decisions.PREFIXES):
KEPT_PREFIXES = {
    "10": ["DCO-", "ALM-", "PNL-", "BUD-", "RVC-", "FRR-", "PFR-", "WVR-", "ACR-", "CCA-", "ACM-", "CPO-", "DRV-", "ARU-",
           "ARN-", "MHY-", "HRS-", "ICA-", "ICC-"],
    "11": ["CPF-", "PEER-", "MSH-", "MSZ-", "IDR-", "MSHD-", "PFD-", "RTG-", "AWD-", "FBS-", "CEV-", "MSE-", "MRR-", "TRD-",
           "MIN-"],
    "36": ["PPSL-", "PAPR-", "LCHG-", "PRVW-"],
    "38": ["FILNG-", "EXAM-", "POLCY-", "REGCH-", "RLIST-", "TRSV-", "CONFL-", "MNPI-", "OBL-", "AUTH-"],
}

# Key formats (prefix or object, format with example, note); decisions.PREFIX_FORMATS style.
KEY_FORMATS = [
    ("CLREV-", "CLREV-<year>-<period, 2 digits>-<sequence, 7 digits>, e.g. CLREV-2026-09-0041877", "Client revenue record."),
    ("LTVM-", "LTVM-<sequence, 3 digits>, e.g. LTVM-004; version in Lifetime Value Model Version", "Lifetime value model."),
    ("PRSC-", "PRSC-<year>-<sequence, 4 digits>, e.g. PRSC-2026-0017", "Pricing scenario."),
    ("COFF-", "COFF-<sequence, 5 digits>, e.g. COFF-00213", "Competitor offering; competitor is a 02 PTY- party with a hypothetical name in examples."),
    ("PRVW-", "PRVW-<year>-<product, offering or model number, 5 digits>-<review type code, 3 letters>-<sequence, 2 digits>, e.g. PRVW-2026-00981-PPR-01", "Re-keyed from the AOV example (CW-161). Type codes: PPR periodic, PLR post-launch, APR advice program, RRR range rationalization, CIT CIT annual."),
    ("FILNG-", "FILNG-CRS-<year>-<sequence, 5 digits>, e.g. FILNG-CRS-2026-00002", "Form CRS filing (form code CRS); TA1 and TA2 for Forms TA-1 and TA-2, ADVE for Form ADV-E."),
    ("Cash Program Economics", "Composite: SWEEP- / PGBNK- / period (50 prefixes of proposals_w3_brokerage)", ""),
    ("Client Acquisition Cost Record", "Composite: acquisition channel / CAM- campaign or 'ALL' / cohort month", ""),
    ("Client Lifetime Value Estimate", "Composite: PTY-HH- / LTVM- and version / as-of date", "PII - financial."),
    ("Pricing Scenario Result", "Composite: PRSC- / projection year", ""),
    ("Competitor Pricing Observation", "Composite: COFF- / price component / as-of date", ""),
    ("Product Review Criterion Result", "Composite: PRVW- / criterion / subject (SHC-, OFFR- or MDL-)", ""),
    ("Service Offering Specification", "Composite: LCHG- / specification sequence", ""),
    ("Platform Feature Specification", "Composite: LCHG- / feature type", ""),
    ("Adviser Custody Profile", "Composite: LEN- / effective from", ""),
    ("Custody Surprise Examination", "Composite: LEN- / examination date", ""),
]

NOTES = [
    "Disposition: domains.DISPOSITION['38'] is 'keep'; plan section 5.1 adds named objects and CW-022 item 3 calls it '38 with its W4 adaptation'. Proposed: ('adapt', '') at the W4 merge (CW-167). 10 takes its new name 'Client Revenue, Pricing Economics & Profitability' in DD_NAMES at the merge; L1 code DF kept.",
    "The status 'Retired (sibling)' is new in decisions.PREFIXES; check_baseline.py and any prefix validator that enumerates statuses must accept it (tooling change at the W4 merge). The existing status 'Retired' remains for prefixes retired in both siblings.",
    "Dependencies: the 05 W4 brief (Opportunity OPP-, Shelf Placement, Model Program Placement, Partner Payment and Payment Calculation, Hierarchy Node) decides whether 10, 11 and 36 references to them resolve; the 06 W4 brief (Fund Shareholder Position, Client Assets, Net New Assets) supplies the 10 and 11 Derived copies; the W3 briefs of 48 (Client Order, Execution), 49 (margin and fully paid lending balances), 50 (Sweep Program, Program Bank, cash-movement monitoring alert) and 16 (plan fee arrangements) supply 10 and 38 references; the W3 24 and 32 brief (W3_24_32_Family_Additions.md) left the private-markets content of 24 and 32 for CW-166.",
    "Unverified (marked confirm in the briefs): FINRA Rule 3290 effective date (SEC approval 2026-09-15; FINRA to announce); the FinCEN investment adviser AML rule (exemptive relief to 2028-01-01, new date by rulemaking); Regulation S-P amendment compliance dates; the Form PF sections that apply to feeder funds and the current Form PF compliance date; FINRA Regulatory Notices 05-26 and 22-08 as product-governance sources; Form BD and Form ADV item numbers used as list sources; OECD TPG versus IRC section 482 as 10's transfer-pricing source.",
]
