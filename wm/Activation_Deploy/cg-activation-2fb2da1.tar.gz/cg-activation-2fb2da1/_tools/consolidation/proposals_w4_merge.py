"""Wealth-manager reference model: decisions taken by the program lead at the combined W2-W4 merge (2026-10-16)."""

PL = "Program lead"

DECISIONS = [
    {"id": "CW-172", "theme": "Tooling", "title": "Ownership resolution: an explicit domain in a reference type takes precedence over the example prefix; prefixes may be two to six letters; every status starting with 'Retired' is skipped",
     "domains": ["05", "06", "10", "11", "12", "16", "36", "38", "47", "49", "52"],
     "issue": "The W2-W4 drafters typed cross-domain references with an explicit domain ('Reference (Distributor Firm, 05)') but the resolver read the example prefix first (PTY-, ACC-, EMP-), so about 170 OWNERSHIP_OVERRIDES were needed to force the intended owner. ESTATE- and CMASET- exceeded the five-letter prefix pattern. The new status 'Retired (sibling)' (retired in the wealth model, live in the wholesale sibling) was not skipped by the owner map.",
     "resolution": "ownership.py: EXPLICIT_DOMAIN in the reference type is checked before the example prefix; PREFIX_PATTERN allows two to six letters; PREFIX_OWNER, build_enterprise.py and export_review_data.py skip every status starting with 'Retired'. The overrides that the change makes redundant are left in place and swept at W5 (CW-039 tooling pass). Three non-overridden references change owner: 01 Investment Mandate.Client to 12 (CW-133), one in 10 and one in 49, both intended.",
     "rationale": "The drafters' explicit domains are the designed intent; the example prefix is a convenience.",
     "action": "W4 merge", "status": "Accepted", "priority": "Medium", "owner_role": PL},
]
