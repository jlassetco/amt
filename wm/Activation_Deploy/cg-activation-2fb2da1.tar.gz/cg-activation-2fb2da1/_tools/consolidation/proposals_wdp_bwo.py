"""WP0 product brief proposals: Brokerage, Cash & Workplace (group BWO).

Brief: 00_Program/Rework/Product_Briefs/BWO_Brokerage_Cash_and_Workplace.md
Data Domains: 48 Brokerage Orders & Execution, 49 Clearing, Settlement & Client Asset Custody, 50 Money Movement,
Cash & Sweep, 16 Retirement Plan Administration (Wealth_Manager_Rework_Plan.md section 8; area BWO).
Reserved product IDs DP-430 to DP-479 (DP-430 to DP-432, DP-435 to DP-442, DP-445 to DP-453, DP-455 to DP-462 and
DP-465 to DP-470 used; the gaps are left free by sub-domain); reserved decision IDs CW-230 to CW-239 (CW-230 to
CW-235 used), status "Proposed".
Waves: "WP1F" (foundational wave of WP1) and "WP1C" (consumer waves of WP1). candidate_coverage.py still accepts only
E1 to E5 (WAVES); the check was run on a patched scratchpad copy that adds WP1F and WP1C (see the brief, section 7).
Check: /usr/bin/python3 data_products/candidate_coverage.py proposals_wdp_bwo  (from _tools)

Upstream names that are not DP- ids are the WP0 framing agent's new foundational products (DP-300 to DP-319, ids not
yet assigned when this file was written), by the plan's names (section 8.2): "Client Holdings, Lots & Cost Basis" (49),
"Client Orders & Executions" (48), "Money Movement Transactions" (50), "Advice Plans & Recommendations" (45),
"Managed Account Model Assignments" (46), "Fee Schedules & Billing Runs" (47), and the DP-008 successor
"Client Assets & Net New Assets" (06, CW-142). Replaced by their ids (DP-300 to DP-305, DP-008) at the WP0 integration.

Function codes are framework.FUNCTIONS as of 2026-10-15: FN-64 Brokerage Trading & Execution, FN-65 Clearing,
Settlement & Client Asset Custody, FN-66 Money Movement & Cash Programs, FN-71 Workplace Participant Services &
Rollovers, FN-19 Retirement Plan Services (Recordkeeping). (The assignment's FN-63/64/65 numbering is one off; FN-63 is
Managed Account Operations.)
"""

SEC = "DP-097"   # Security Master & Identifiers (17)
CAE = "DP-099"   # Corporate Action Event Golden Copy (17)
REF = "DP-013"   # Enterprise Reference & Calendars (09)
ACC = "DP-093"   # Account Master (15; re-scoped to the brokerage and advisory account, plan 8.2)
PTY = "DP-240"   # Enterprise Party & Role Master (02; client household primary role family)
PLN = "DP-094"   # Recordkept Plan & Participant Core (16; the framing agent's)
EMP = "DP-192"   # Employee & Position Master (20)
PRC = "DP-143"   # Prices, FX & Curves (22)
NAV = "DP-165"   # NAV & Fund Financials (27)
RET = "DP-145"   # Official Returns, extended with Personal Rate of Return (32, CW-129)
CTR = "DP-213"   # Enterprise Contract Register (39)
SHC = "DP-004"   # Product & Share Class Reference (01)
AML = "DP-226"   # AML & Sanctions Program Cases (38)
CPF = "DP-322"   # Client Protection Flags & Senior Investor Register (02; CLA-A brief, proposals_wdp_cla_a, CW-213)

HLD = "DP-300"        # framing agent, DP-300 to DP-319 (49)
ORD = "DP-301"                # framing agent (48)
MMV = "DP-302"               # framing agent (50)
ADV = "DP-303"            # framing agent (45)
MAM = "DP-304"         # framing agent (46)
FEE = "DP-305"              # framing agent (47)
CAN = "DP-008"            # DP-008 successor (06, CW-142; certified)

F, C = "WP1F", "WP1C"

CANDIDATES = [
    # ============================================== Foundational (Wave WP1F) ==============================================
    dict(id="DP-430", name="Participant Balances & Ledger", tier="Foundational", type="Conformed Facts", domain="16",
         owner_role="Head of Retirement Plan Services", primary="FN-19", supporting=["FN-71", "FN-63", "FN-77", "FN-31"],
         wave=F,
         definition="The participant book of record of the recordkept plans: daily Participant Balance by membership, "
                    "money source and investment option with units, unit value and vested amount, every Participant "
                    "Ledger Posting and every Participant Investment Transfer. It is the third book of record "
                    "(CW-007, CW-125), keyed to the DP-094 membership and the DP-093 participant account, and the only "
                    "source of plan balances for 06, 32, 46 and the workplace products.",
         objects=[("16", "Participant Balance"), ("16", "Participant Ledger Posting"),
                  ("16", "Participant Investment Transfer"), ("16", "Participant Plan Membership"),
                  ("16", "Plan Investment Option")],
         upstream=[PLN, ACC, NAV, SHC, REF],
         notes="Concept ownership row: Participant Balance / Participant Ledger Posting (16, CW-125). PII: 'PII - "
               "financial' (membership-level amounts); classification Restricted - Personal Data; plan-level "
               "aggregates shared. Book: Participant Balance (16), never Client Holding (49) or Fund Shareholder "
               "Position (06). Unit values from DP-165 (27). Ruling needed: a separate product (recommended, as DP-141 "
               "and DP-142 sit apart from DP-140) or an extension of DP-094 as the W3 note proposed (proposals_w3_16 "
               "NOTES). Lever: a recordkeeping platform merge moves balances to 49 (16 lever 7.7.2); the product then "
               "reads the ledger only."),
    dict(id="DP-431", name="Sweep Programs & Program Banks", tier="Foundational", type="Master & Reference",
         domain="50", owner_role="Head of Cash Programs", primary="FN-66", supporting=["FN-65", "FN-72", "FN-38", "FN-62"],
         wave=F,
         definition="The conformed master of the cash sweep programs and the program banks behind them: Sweep Program "
                    "with eligibility and eligible sweep funds, Program Bank as a role profile of the 02 bank party, "
                    "Program Bank Participation with priority, capacity and the omnibus deposit account, and Sweep Rate "
                    "Tier. It conforms the Program Bank dimension the plan names (section 8.4) once, for 49, 50, 10 "
                    "and 15 readers.",
         objects=[("50", "Sweep Program"), ("50", "Program Bank"), ("50", "Program Bank Participation"),
                  ("50", "Sweep Rate Tier")],
         upstream=[PTY, CTR, SHC, REF],
         notes="Concept ownership rows: Sweep Program (SWEEP-) and Program Bank (PGBNK-), 50 (CW-108). PII: 'No PII' "
               "(firm-level, CW-115); Bank Approved By is an employee reference. Ruling needed: confirm the framing "
               "agent's 'Money Movement Transactions' does not also carry the program master (one master, one "
               "product). Lever: bank sweep only or money market sweep only (50 lever 3); one program bank (lever 2)."),
    dict(id="DP-432", name="Execution Venues & Routing Rules", tier="Foundational", type="Master & Reference",
         domain="48", owner_role="Head of Brokerage Trading", primary="FN-64", supporting=["FN-68", "FN-44"], wave=F,
         definition="The conformed master of the execution venues the broker-dealer routes to (Execution Venue Profile "
                    "with MIC, Rule 606 name, affiliation and order-flow payment terms) and the versioned Routing Rules "
                    "that send each order class to a primary and fallback venue. It is the Venue dimension for routes, "
                    "executions, Rule 605 and 606 lines and the best-execution review.",
         objects=[("48", "Execution Venue Profile"), ("48", "Routing Rule")],
         upstream=[PTY, REF],
         notes="Concept ownership rows: Execution Venue Profile and Routing Rule (48, CW-100). PII: 'No PII' "
               "(firm-level). Lever: if the framing agent folds venues into 'Client Orders & Executions', this "
               "candidate is withdrawn and DP-436 reads the venue from there. Lever: PFOF accepted (48 lever 2) makes "
               "Order Flow Payment Terms a CDE."),

    # ===================================== Consumer-aligned: 48 Brokerage (Wave WP1C) =====================================
    dict(id="DP-435", name="Order Lifecycle & CAT Completeness", tier="Consumer-aligned", type="Regulatory & Control",
         domain="48", owner_role="Head of Brokerage Trading", primary="FN-64", supporting=["FN-68", "FN-44", "FN-65"],
         wave=C,
         definition="Every client order from receipt to final state, with its events, routes, executions, allocations "
                    "and option legs, matched to the CAT Reportable Events that must exist for each step and their "
                    "submission, error and repair status. Trading operations works late, rejected and unrepaired CAT "
                    "records and order-state breaks from it before the T+3 repair deadline.",
         objects=[("48", "Client Order"), ("48", "Order Instruction Detail"), ("48", "Option Order Leg"),
                  ("48", "Client Order Event"), ("48", "Order Route"), ("48", "Client Execution"),
                  ("48", "Client Allocation"), ("48", "Client Block Order"), ("48", "CAT Reportable Event")],
         upstream=[ORD, "DP-432", ACC, SEC, EMP, REF],
         notes="PII: 'PII - financial' (account-level orders); CAT records hold the FDID only (CW-115); classification "
               "Confidential - Client. Measures: CAT records expected versus submitted per lifecycle event; error and "
               "repair aging; orders without terminal status; route-to-execution latency. Lever: introducing broker "
               "(48 lever 1) keeps the grain with the clearing firm's references."),
    dict(id="DP-436", name="Execution Quality & Routing (605/606)", tier="Consumer-aligned", type="Regulatory & Control",
         domain="48", owner_role="Head of Brokerage Trading", primary="FN-64", supporting=["FN-68", "FN-44", "FN-67"],
         wave=C,
         definition="Execution quality by venue, order class and order type (price improvement rate and amount, "
                    "effective over quoted spread, time to execution) with the Rule 605 monthly report lines, the Rule "
                    "606 quarterly routing disclosure and the Rule 606(b) customer requests, and the best-execution "
                    "committee review that approved each routing rule. It answers acceptance question 5 (execution "
                    "quality by venue and order type) and is the evidence pack for FINRA Rule 5310 regular and rigorous "
                    "review.",
         objects=[("48", "Execution Quality Measure"), ("48", "Rule 605 Report Line"), ("48", "Rule 606 Report Line"),
                  ("48", "Order Routing Disclosure Request"), ("48", "Execution Venue Profile"),
                  ("48", "Routing Rule"), ("48", "Order Route"), ("48", "Client Execution"),
                  ("08", "Supervisory Review")],
         upstream=["DP-432", ORD, SEC, PTY, REF],
         notes="PII: report lines and measures 'No PII'; routing disclosure requests 'PII - identity' (restricted "
               "view); the public 605/606 extracts carry no personal data. The 48 measures are computed in 48 "
               "(CW-100); this product publishes them, never recomputes them; the committee review is 08's. Lever: "
               "a smaller broker-dealer (fewer than 100,000 customers) drops the Rule 605 lines (48 lever 7)."),
    dict(id="DP-437", name="Trade Corrections & Errors", tier="Consumer-aligned", type="Regulatory & Control",
         domain="48", owner_role="Head of Brokerage Trading", primary="FN-64", supporting=["FN-65", "FN-68", "FN-42"],
         wave=C,
         definition="Every trade correction (cancel and rebill, as-of trade, price or account correction) with the "
                    "superseded and resulting confirmations, and every trade error case with its cause, severity, gain "
                    "or loss and whether the client was made whole. It answers the second half of acceptance question "
                    "5 (which orders were corrected) and feeds operational loss events to 37.",
         objects=[("48", "Trade Correction"), ("48", "Trade Error Case"), ("48", "Client Trade Confirmation"),
                  ("48", "Client Allocation"), ("48", "Client Execution"), ("48", "Client Order")],
         upstream=[ORD, ACC, EMP, REF],
         notes="PII: 'PII - financial'; classification Confidential - Client. Measures: corrections per 10,000 "
               "allocations by type and cause; as-of share; error loss amount; client-made-whole rate; aging of open "
               "cases. Loss events stay in 37 (Related Loss Event); this product never books the loss."),
    dict(id="DP-438", name="Trade Confirmations & Regulatory Trade Reporting", tier="Consumer-aligned",
         type="Regulatory & Control", domain="48", owner_role="Head of Brokerage Trading", primary="FN-64",
         supporting=["FN-67", "FN-68", "FN-72"], wave=C,
         definition="The Rule 10b-10 confirmation record by version, with commission, regulatory fees, markup or "
                    "markdown disclosure under FINRA Rule 2232 and MSRB Rule G-15, joined to the confirmation delivery "
                    "in 13 and to the TRF, TRACE and RTRS reports of each execution. It shows which confirmations are "
                    "late, missing a required markup disclosure or superseded, and which trade reports were late.",
         objects=[("48", "Client Trade Confirmation"), ("48", "Confirmation Remuneration Disclosure"),
                  ("48", "Regulatory Trade Report"), ("48", "Fixed Income Order Detail"), ("48", "Fund Order Detail"),
                  ("13", "Confirmation Delivery")],
         upstream=[ORD, ACC, SEC, PRC, FEE],
         notes="PII: 'PII - financial'. The confirmation is 48's, delivery 13's (CW-081, CW-098); commission rates are "
               "47's. Lever: agency fixed income (48 lever 6) blanks the markup fields."),
    dict(id="DP-439", name="Order-Time Eligibility & Market Access Controls", tier="Consumer-aligned",
         type="Regulatory & Control", domain="48", owner_role="Head of Brokerage Trading", primary="FN-64",
         supporting=["FN-68", "FN-65", "FN-62"], wave=C,
         definition="The result of every order-time check (options level, margin and buying power, account and client "
                    "restrictions, restricted list, product policy) and the Rule 15c3-5 pre-trade limits that applied, "
                    "with overrides and their approvers. It shows options and margin eligibility in practice: orders "
                    "blocked or overridden by check type, and limits not reviewed within their cycle.",
         objects=[("48", "Order Eligibility Check"), ("48", "Pre-Trade Risk Limit"), ("48", "Order Instruction Detail"),
                  ("48", "Client Order"), ("15", "Options Approval Detail"), ("15", "Margin Account Detail"),
                  ("15", "Account Restriction")],
         upstream=[ORD, ACC, PTY, EMP, SEC],
         notes="PII: 'PII - financial'. Approvals, flags and restrictions stay in 15, 17, 01 and 02 (CW-099); the "
               "check result is 48. Buying power at entry is a copy of 49 (48 lever 9)."),
    dict(id="DP-440", name="Brokerage Activity by Product & Session", tier="Consumer-aligned", type="Analytical",
         domain="48", owner_role="Head of Brokerage Trading", primary="FN-64", supporting=["FN-78", "FN-61", "FN-77"],
         wave=C,
         definition="Client trading activity by product (equity, ETF, own and third-party funds, options, fixed income "
                    "and CDs), entry channel, order source and trading session, with fractional and extended-hours "
                    "activity and the fund orders handed to 29 or Fund/SERV. It tells the platform and offering owners "
                    "how clients trade, where fractional remainders and facilitation positions build, and how "
                    "extended-hours fills compare with the regular session.",
         objects=[("48", "Client Order"), ("48", "Client Execution"), ("48", "Client Allocation"),
                  ("48", "Fund Order Detail"), ("48", "Order Route"), ("29", "Fund Order")],
         upstream=[ORD, ACC, SEC, SHC, REF],
         notes="PII: aggregates only (account counts by segment); no row-level output. Commission and revenue come "
               "from 10, never computed here. Levers: overnight session (48 lever 4); agency-only fractional (lever 3)."),
    dict(id="DP-441", name="Option Exercise & Assignment Operations", tier="Consumer-aligned", type="Operational",
         domain="48", owner_role="Head of Brokerage Operations", primary="FN-65", supporting=["FN-64", "FN-67"], wave=C,
         definition="Expiration-day and early-exercise instructions against the exercise cut-off, OCC assignment "
                    "notices allocated to short accounts with the allocation method and client notification time, and "
                    "the resulting 49 activity. Options operations works unbooked exercises, late notifications and "
                    "contrary instructions from it.",
         objects=[("48", "Option Exercise Instruction"), ("48", "Option Assignment Allocation"),
                  ("48", "Option Order Leg"), ("49", "Client Account Activity")],
         upstream=[ORD, HLD, ACC, SEC, REF],
         notes="PII: 'PII - financial'. Lever: no options offered drops the product."),

    # ============================== Consumer-aligned: 49 Clearing & custody (Wave WP1C) ==============================
    dict(id="DP-445", name="Customer Reserve & Possession-and-Control Control Pack", tier="Consumer-aligned",
         type="Regulatory & Control", domain="49", owner_role="Financial and Operations Principal",
         primary="FN-65", supporting=["FN-40", "FN-44", "FN-38"], wave=C,
         definition="The daily Rule 15c3-3 customer and PAB reserve computations with every Exhibit A line, the deposit "
                    "requirement against the deposit on hand and its deadline, and the possession-or-control "
                    "determination of every security with deficits by source, age and action deadline. It answers "
                    "acceptance question 6 (today's reserve requirement; client securities out of possession or "
                    "control) and gives 43 the aggregate debit items for net capital.",
         objects=[("49", "Reserve Computation"), ("49", "Reserve Computation Line"),
                  ("49", "Possession or Control Determination"), ("49", "Control Location"),
                  ("49", "Account Cash Balance"), ("49", "Client Holding"), ("49", "Client Holding Valuation"),
                  ("43", "Capital Requirement Calculation")],
         upstream=[HLD, SEC, PTY, EMP, REF],
         notes="PII: 'No PII' for the computations and determinations (CW-115); the cash and holding inputs are "
               "aggregated to formula items. The computation is 49's, net capital 43's (CW-103). Levers: weekly "
               "computation (49 lever 2); PAB value dropped (lever 3); fully disclosed clearing removes the product "
               "(the clearing firm computes the reserve)."),
    dict(id="DP-446", name="Stock Record Reconciliation & Security Counts", tier="Consumer-aligned",
         type="Regulatory & Control", domain="49", owner_role="Head of Brokerage Operations", primary="FN-65",
         supporting=["FN-35", "FN-66", "FN-38"], wave=C,
         definition="Daily stock record reconciliations by type (depository, own-fund omnibus at the TA, program-bank "
                    "sweep, transfer agent) with every break, its owner, age and short-difference status, and the "
                    "quarterly Rule 17a-13 security counts with differences found and recorded. It is where the 49 "
                    "Sweep Balance and the 50 Sweep Allocations, and the 49 own-fund holdings and the 29 omnibus "
                    "register balance, are shown to agree.",
         objects=[("49", "Stock Record Reconciliation"), ("49", "Stock Record Break"), ("49", "Security Count"),
                  ("49", "Control Location"), ("29", "Share Register Balance"), ("50", "Sweep Allocation")],
         upstream=[HLD, "DP-431", SEC, EMP, REF],
         notes="PII: breaks carry an account reference ('PII - financial', restricted to operations); counts 'No "
               "PII'. Lever: networked own-fund accounts (49 lever 4) replace the omnibus reconciliation type."),
    dict(id="DP-447", name="Client Settlement & Fails", tier="Consumer-aligned", type="Operational", domain="49",
         owner_role="Head of Brokerage Operations", primary="FN-65", supporting=["FN-64", "FN-35", "FN-40"], wave=C,
         definition="Street settlement obligations by clearing channel (NSCC CNS, DTC, Fund/SERV, own-fund TA) against "
                    "actual settlement, and client settlement fails with close-out deadlines, freeriding restrictions "
                    "and resolution. Cage and settlement staff work Regulation SHO and Regulation T close-outs from it.",
         objects=[("49", "Street Settlement Obligation"), ("49", "Client Settlement Fail"),
                  ("49", "Client Account Activity"), ("29", "Settlement Obligation")],
         upstream=[HLD, ORD, SEC, PTY, REF],
         notes="PII: 'PII - financial' for client fails; street obligations 'No PII'. Fund-side settlement cash stays "
               "29 (CW-102)."),
    dict(id="DP-448", name="ACATS In and Out", tier="Consumer-aligned", type="Operational", domain="49",
         owner_role="Head of Brokerage Operations", primary="FN-65", supporting=["FN-77", "FN-62", "FN-67", "FN-60"],
         wave=C,
         definition="Every account transfer in and out (ACATS full, partial and residual, non-ACATS, internal "
                    "re-registration) with validation and settlement dates, rejects, non-transferable assets, debit "
                    "balances and the IRC section 6045A cost basis statement due and received. It shows cycle time and "
                    "reject rates by contra firm and the transferred value by direction, taking the certified "
                    "transfer component of Net New Assets from the 06 product.",
         objects=[("49", "Account Transfer"), ("49", "Account Transfer Asset Line"),
                  ("49", "Cost Basis Transfer Statement"), ("13", "Service Request")],
         upstream=[HLD, CAN, ACC, PTY, SEC, REF],
         notes="PII: 'PII - financial' (contra account numbers restricted). Certified: Net New Assets (transfer "
               "component) consumed from Client Assets & Net New Assets (CW-142); the product's own values are "
               "operational transfer values, never labeled NNA. Lever: fractional delivery to contra firms (49 lever 8)."),
    dict(id="DP-449", name="Cost Basis & Form 1099-B Readiness", tier="Consumer-aligned", type="Regulatory & Control",
         domain="49", owner_role="Head of Brokerage Operations", primary="FN-65", supporting=["FN-67", "FN-63", "FN-39"],
         wave=C,
         definition="Covered and noncovered lots, lot reliefs with realized gain or loss and holding period, wash sale "
                    "deferrals, cost basis adjustments from corporate actions and Form 8937, and inbound and outbound "
                    "section 6045A statements, measured against the Form 1099-B reporting categories and the account's "
                    "cost basis election. It shows which accounts will report missing or unadjusted basis before the "
                    "tax form run.",
         objects=[("49", "Client Tax Lot"), ("49", "Client Lot Relief"), ("49", "Cost Basis Adjustment"),
                  ("49", "Cost Basis Transfer Statement"), ("15", "Cost Basis Election"), ("13", "Tax Form Record")],
         upstream=[HLD, CAE, ACC, SEC],
         notes="PII: 'PII - financial'; classification Confidential - Personal Data. Lots are 49 (CW-101); the "
               "election is 15, the form 13 (CW-034); tax-loss harvesting decisions are 46's. Lever: lots of "
               "fund-only accounts kept on the TA platform (49 lever 12)."),
    dict(id="DP-450", name="Margin Calls & Margin Exposure", tier="Consumer-aligned", type="Operational", domain="49",
         owner_role="Head of Margin & Credit", primary="FN-65", supporting=["FN-40", "FN-42", "FN-68"], wave=C,
         definition="Daily and intraday margin balance snapshots (debit balance, equity, Reg T and house excess, "
                    "maintenance deficit, buying power) with every Reg T, maintenance, house and day-trade call, its "
                    "due and met dates and any liquidation order. Credit staff decide extensions and liquidations from "
                    "it, and risk watches concentration of margin debt.",
         objects=[("49", "Margin Balance Snapshot"), ("49", "Client Margin Call"), ("49", "Client Holding"),
                  ("49", "Client Holding Valuation"),
                  ("15", "Margin Account Detail")],
         upstream=[HLD, ACC, SEC, PRC],
         notes="PII: 'PII - financial'. Approvals are 15, net capital 43 (CW-105). Lever: margin not offered (49 "
               "lever 6) drops the product."),
    dict(id="DP-451", name="Fully Paid Securities Lending Program", tier="Consumer-aligned",
         type="Regulatory & Control", domain="49", owner_role="Head of Brokerage Operations", primary="FN-65",
         supporting=["FN-40", "FN-44", "FN-72"], wave=C,
         definition="Fully paid loans by account, borrower and instrument with collateral marks, the client and gross "
                    "fee rates and the firm's share, and the SEC Rule 10c-1a reporting status of each loan. It shows "
                    "the program's collateral coverage, client economics and reporting completeness.",
         objects=[("49", "Fully Paid Securities Loan"), ("49", "Loan Reporting Detail"), ("15", "Account Agreement")],
         upstream=[HLD, ACC, SEC, PRC, PTY],
         notes="PII: 'PII - financial'. Fund securities lending is 28 (DP-174). Lever: a Vanguard-type firm may not "
               "offer fully paid lending (49 lever 7); the product is then withdrawn."),
    dict(id="DP-452", name="Client Corporate Action Entitlements & Elections", tier="Consumer-aligned",
         type="Operational", domain="49", owner_role="Head of Brokerage Operations", primary="FN-65",
         supporting=["FN-67", "FN-63"], wave=C,
         definition="Client entitlements for each 17 corporate action event (record-date quantity, cash, securities, "
                    "withholding, cash in lieu), dividend reinvestment allocations and voluntary elections against "
                    "the internal deadline with defaults applied. Reorganization staff work unelected positions and "
                    "unpaid entitlements from it.",
         objects=[("49", "Client Corporate Action Entitlement"), ("49", "Dividend Reinvestment Allocation"),
                  ("49", "Client Voluntary Election")],
         upstream=[HLD, CAE, ACC, SEC],
         notes="PII: 'PII - financial'. Event 17, fund entitlements 28, client entitlements 49 (CW-106)."),
    dict(id="DP-453", name="Brokerage Operations Daily Control Dashboard", tier="Consumer-aligned", type="Analytical",
         domain="49", owner_role="Head of Brokerage Operations", primary="FN-65",
         supporting=["FN-64", "FN-66", "FN-42"], wave=C,
         definition="One daily view of the brokerage exceptions across 48, 49 and 50: open settlement fails, stock "
                    "record breaks, unrepaired CAT records, money movement exceptions and returns, and their aging "
                    "against deadline. It gives the head of operations and risk one set of operating KPIs without "
                    "reopening each product.",
         objects=[("49", "Client Settlement Fail"), ("49", "Stock Record Break"), ("48", "CAT Reportable Event"),
                  ("50", "Money Movement Exception"), ("50", "Money Movement Return")],
         upstream=["DP-447", "DP-446", "DP-435", "DP-455", REF],
         notes="PII: counts and amounts only. Reads the other products' exception flags; defines no new exception."),

    # =============================== Consumer-aligned: 50 Money movement (Wave WP1C) ===============================
    dict(id="DP-455", name="ACH, Wire & Check Operations and Returns", tier="Consumer-aligned", type="Operational",
         domain="50", owner_role="Head of Money Movement", primary="FN-66", supporting=["FN-67", "FN-65", "FN-62"],
         wave=C,
         definition="Every money movement by rail with its events, ACH, wire, check and journal detail, bank account "
                    "verification, returns (with unauthorized returns and reinitiations) and exceptions such as "
                    "notifications of change. Money movement operations works the day's returns, NOCs, unverified "
                    "instructions and stuck movements from it and tracks NACHA return-rate thresholds.",
         objects=[("50", "Money Movement"), ("50", "Money Movement Event"), ("50", "ACH Entry Detail"),
                  ("50", "Wire Transfer Detail"), ("50", "Check Detail"), ("50", "Internal Transfer Detail"),
                  ("50", "Money Movement Return"), ("50", "Money Movement Exception"),
                  ("50", "Bank Account Verification Event"), ("15", "Bank Instruction")],
         upstream=[MMV, ACC, PTY, EMP, REF],
         notes="PII: 'PII - financial'; bank account, check and wire beneficiary data 'PII - financial (restricted)', "
               "masked outside operations (CW-115). Levers: instant payments (50 lever 4); NACHA phase (lever 11)."),
    dict(id="DP-456", name="Fraud & Elder-Exploitation Holds", tier="Consumer-aligned", type="Regulatory & Control",
         domain="50", owner_role="Head of Money Movement", primary="FN-66", supporting=["FN-68", "FN-44", "FN-67"],
         wave=C,
         definition="Every money movement hold (funds availability, fraud, FINRA Rule 2165 disbursement hold, legal "
                    "process, AML, sanctions) with its reason, dates, expiry, trusted contact notice and the fraud risk "
                    "assessment behind it, linked to the 02 vulnerability concern, the 15 paired restriction and the 08 "
                    "Senior Investor Case. It answers acceptance question 7 (which cash movements are on hold for "
                    "fraud or elder-exploitation review) and tracks Rule 2165 hold-day limits.",
         objects=[("50", "Money Movement Hold"), ("50", "Fraud Risk Assessment"), ("50", "Money Movement"),
                  ("15", "Account Restriction")],
         upstream=[MMV, CPF, PTY, ACC, EMP, REF],
         notes="PII: special category (CD-344, CW-030, CW-115): hold rows whose reason is suspected exploitation or "
               "diminished capacity. The 02 Specified Adult Status, Vulnerability Concern and trusted contact facts and "
               "the 08 Senior Investor Case are read only through the CLA-A restricted view DP-322 (CW-213), never "
               "from 02 or 08 directly; the hold carries the case reference. Two outputs: a "
               "restricted view for money movement, senior investor and compliance roles (classification Restricted - "
               "Personal Data) and an aggregate view (counts, amounts, age, outcome by hold type) for everyone else. "
               "The case and its review are 08's; this product never re-scores them. Lever: Rule 2166 delays if "
               "adopted (50 lever 9); securities holds in 15 (lever 6)."),
    dict(id="DP-457", name="Cash Sweep & Program Bank Allocation", tier="Consumer-aligned", type="Analytical",
         domain="50", owner_role="Head of Cash Programs", primary="FN-66", supporting=["FN-40", "FN-72", "FN-78", "FN-38"],
         wave=C,
         definition="Daily sweep runs, sweep allocations by account and program bank, program bank daily totals "
                    "against capacity, and the client rate tiers in force, with each bank's concentration and the "
                    "net flow wired. It shows where swept cash sits, which banks are near capacity, and the spread "
                    "between bank rate and client rate the program earns.",
         objects=[("50", "Sweep Run"), ("50", "Sweep Allocation"), ("50", "Program Bank Daily Total"),
                  ("50", "Program Bank Participation"), ("50", "Sweep Rate Tier"), ("49", "Account Cash Balance"),
                  ("15", "Cash Sweep Election")],
         upstream=["DP-431", MMV, HLD, ACC, REF],
         notes="PII: allocations are 'PII - financial'; published outputs aggregate to program bank and segment. "
               "Certified: Client Assets (cash and sweep holding type) consumed from Client Assets & Net New Assets; "
               "program revenue is 10's (CW-156), never computed here. Sweep Balance (49) equals the sum of "
               "allocations (CW-102); the reconciliation is DP-446."),
    dict(id="DP-458", name="FDIC Pass-Through Coverage", tier="Consumer-aligned", type="Regulatory & Control",
         domain="50", owner_role="Head of Cash Programs", primary="FN-66", supporting=["FN-67", "FN-44", "FN-62"],
         wave=C,
         definition="FDIC coverage by party, ownership category and program bank with insured and uninsured amounts, "
                    "client-declared direct deposits, exclusions and the pass-through recordkeeping basis under 12 CFR "
                    "Part 330. Cash programs and client service see which clients are above coverage and whether the "
                    "recordkeeping requirements for pass-through are met.",
         objects=[("50", "FDIC Coverage Assessment"), ("50", "Sweep Allocation"), ("50", "Program Bank"),
                  ("02", "Party")],
         upstream=["DP-431", PTY, ACC, REF],
         notes="PII: 'PII - financial'. Lever: one program bank (50 lever 2) collapses the bank dimension."),
    dict(id="DP-459", name="Debit Card, Checkwriting & Regulation E Disputes", tier="Consumer-aligned",
         type="Operational", domain="50", owner_role="Head of Money Movement", primary="FN-66",
         supporting=["FN-67", "FN-68"], wave=C,
         definition="Debit cards issued with status and limits, card transactions, checkwriting drafts honored by own "
                    "money market fund redemptions, and Regulation E error notices with provisional credit and "
                    "investigation deadlines. Card operations meet the 10 and 45 business day Regulation E clocks from it.",
         objects=[("50", "Debit Card"), ("50", "Card Transaction Detail"), ("50", "Card Dispute"),
                  ("50", "Check Detail"), ("15", "Account Feature")],
         upstream=[MMV, ACC, PTY, REF],
         notes="PII: card numbers 'PII - financial (restricted)', masked; classification Restricted - Personal Data "
               "for row level. Lever: drop the card family or checkwriting through a program bank (50 lever 7)."),
    dict(id="DP-460", name="Money Movement AML Monitoring & Payment Sanctions Screening", tier="Consumer-aligned",
         type="Regulatory & Control", domain="50", owner_role="Head of Money Movement", primary="FN-66",
         supporting=["FN-44"], wave=C,
         definition="Money-movement monitoring alerts by scenario with disposition and escalation, and payment "
                    "sanctions screening results with blocked or rejected payments. It measures alert volumes, "
                    "aging, false positive and escalation rates, and the movements screened before release.",
         objects=[("50", "Money Movement Monitoring Alert"), ("50", "Payment Sanctions Screening"),
                  ("50", "Money Movement"), ("38", "AML Case")],
         upstream=[MMV, AML, PTY, ACC, EMP],
         notes="PII: 'PII - identity' and 'PII - financial'; SAR existence restricted (31 CFR 1023.320(e)): the "
               "product exposes only whether an alert was escalated, never SAR status (CW-110). Boundary: DP-226 owns "
               "the AML case and SAR; this product owns the 50 alert and screening record."),
    dict(id="DP-461", name="Client Cash Forecast", tier="Consumer-aligned", type="Analytical", domain="50",
         owner_role="Head of Cash Programs", primary="FN-66", supporting=["FN-40"], wave=C,
         definition="The client cash forecast by value date, cash flow category and sweep program against actual "
                    "movements, so cash programs size program bank capacity and treasury plans the reserve deposit and "
                    "funding. It measures forecast error by category.",
         objects=[("50", "Client Cash Forecast"), ("50", "Client Cash Forecast Line"), ("50", "Sweep Run"),
                  ("43", "Cash Forecast")],
         upstream=[MMV, "DP-431", REF],
         notes="PII: 'No PII' (CW-115)."),
    dict(id="DP-462", name="Account Funding & Money-In Journey", tier="Consumer-aligned", type="Analytical",
         domain="50", owner_role="Head of Money Movement", primary="FN-66", supporting=["FN-62", "FN-76", "FN-61"],
         wave=C,
         definition="Time from account opening to first funding by funding method (ACH, wire, check, ACATS, rollover), "
                    "bank verification success, first-deposit returns and funding drop-off, joined to the 04 "
                    "acquisition milestone. It tells onboarding and marketing where funding fails, while net new "
                    "assets by campaign stay with the 06 product.",
         objects=[("50", "Money Movement"), ("50", "Bank Account Verification Event"), ("49", "Account Transfer"),
                  ("15", "Account Opening"), ("04", "Acquisition Milestone")],
         upstream=[MMV, HLD, ACC, CAN, REF],
         notes="PII: aggregates only. Certified: Net New Assets consumed from Client Assets & Net New Assets (CW-085, "
               "CW-142); funding amounts here are operational and never labeled NNA."),

    # ================================ Consumer-aligned: 16 Workplace (Wave WP1C) ================================
    dict(id="DP-465", name="Plan Sponsor Reporting Data", tier="Consumer-aligned", type="Analytical", domain="16",
         owner_role="Head of Workplace Plan Sponsor Services", primary="FN-71", supporting=["FN-19", "FN-75", "FN-72"],
         wave=C,
         definition="The plan-level data behind the sponsor report packages 12 delivers: plan profile, participation "
                    "and deferral rates, balances by option and money source, menu and QDIA use, and plan fees, by plan "
                    "year and quarter. It is the one source of plan statistics for sponsor reviews and for the "
                    "Retirement Plan Profile Derived copies.",
         objects=[("16", "Retirement Plan Profile"), ("16", "Plan Sponsor Profile"), ("16", "Participant Balance"),
                  ("16", "Participant Plan Membership"), ("16", "Deferral Election"), ("16", "Plan Investment Option"),
                  ("16", "Plan Fee Schedule"), ("12", "Plan Sponsor Servicing Detail"), ("12", "Report Package")],
         upstream=["DP-430", PLN, PTY, SHC, REF],
         notes="PII: plan-level aggregates only; no participant rows leave the product (CW-146: 12 owns the "
               "relationship and the report package, 16 the plan facts)."),
    dict(id="DP-466", name="Participant Outcomes", tier="Consumer-aligned", type="Analytical", domain="16",
         owner_role="Head of Workplace Participant Services", primary="FN-71", supporting=["FN-19", "FN-60", "FN-61"],
         wave=C,
         definition="Retirement readiness by plan, cohort and segment: participation, deferral and savings rates, "
                    "automatic-feature effects, diversification and default-option use, loan and hardship leakage, "
                    "vested balances and personal rates of return, with projected income replacement where a 45 plan "
                    "exists. Workplace leadership and sponsors use it to judge plan design and nudges.",
         objects=[("16", "Participant Balance"), ("16", "Participant Plan Membership"), ("16", "Deferral Election"),
                  ("16", "Investment Election"), ("16", "Vested Balance by Source"), ("16", "Participant Loan"),
                  ("16", "Distribution Request"), ("16", "Annual Limit Tracking"), ("32", "Personal Rate of Return"),
                  ("45", "Goal Projection Result")],
         upstream=["DP-430", PLN, RET, ADV, ACC],
         notes="PII: aggregates by cohort (minimum cell size rule); financial hardship reasons are special category "
               "and appear only as counts. Certified: Personal Rate of Return consumed from DP-145 extended (CW-129), "
               "never recomputed."),
    dict(id="DP-467", name="Rollover Capture", tier="Consumer-aligned", type="Analytical", domain="16",
         owner_role="Head of Workplace Participant Services", primary="FN-71", supporting=["FN-60", "FN-77", "FN-68"],
         wave=C,
         definition="The separation-to-rollover funnel: participant retail hand-offs by trigger, consent to contact, "
                    "referral to an advice engagement or advisor, outcome by destination (firm IRA, firm-recordkept "
                    "plan, external, stayed, cashed out), linked distribution requests and incoming rollover "
                    "contributions, with PTE 2020-02 documentation status where a rollover was recommended. It answers "
                    "acceptance question 10 (which participants separated and what share rolled into the direct "
                    "business), taking the certified capture rate from the 06 product.",
         objects=[("16", "Participant Retail Hand-Off"), ("16", "Distribution Request"),
                  ("16", "Rollover Contribution Detail"), ("16", "Employment Event"),
                  ("16", "Participant Plan Membership"), ("45", "Rollover Analysis"),
                  ("45", "PTE 2020-02 Documentation"), ("06", "Account Channel Assignment")],
         upstream=["DP-430", PLN, ADV, CAN, ACC, PTY],
         notes="PII: 'PII - financial' in the operational view for workplace and advice roles; aggregate view for "
               "management. Certified: rollover capture rate and the inter-channel transfer amount are 06 measures "
               "(CW-126, CW-142; rollovers from the firm's plans into firm IRAs are inter-channel transfers, not NNA) "
               "consumed from Client Assets & Net New Assets; the funnel counts are this product's. Best-interest "
               "evidence is 45's and supervised in 08; read, never re-scored. Lever: outreach on notice and opt-out "
               "instead of consent (16 lever 7.7.4); third-party auto-rollover IRA provider (lever 7.7.7)."),
    dict(id="DP-468", name="Participant Managed Account Program", tier="Consumer-aligned", type="Analytical",
         domain="16", owner_role="Head of Workplace Participant Services", primary="FN-71", supporting=["FN-63", "FN-19", "FN-72"],
         wave=C,
         definition="In-plan managed account uptake and operation by plan: the plan's managed account service and "
                    "fiduciary basis, participant service elections, the 46 model assignment of each participant "
                    "account and the participant investment transfers that executed 46 trade proposals. It shows "
                    "enrollment, QDIA use, balances managed and trade execution timeliness.",
         objects=[("16", "Plan Managed Account Service"), ("16", "Participant Service Election"),
                  ("16", "Participant Investment Transfer"), ("16", "Participant Balance"),
                  ("46", "Model Assignment"), ("15", "Program Enrollment")],
         upstream=["DP-430", PLN, MAM, ACC, FEE],
         notes="PII: aggregates by plan; participant rows restricted to managed account operations. Advised Assets is "
               "a certified 06 measure, consumed, not computed (CW-011). Lever: no participant managed accounts (16 "
               "lever 7.7.3) withdraws the product."),
    dict(id="DP-469", name="Plan Conversion & Fund Change Tracker", tier="Consumer-aligned", type="Operational",
         domain="16", owner_role="Head of Retirement Plan Services", primary="FN-19", supporting=["FN-71", "FN-35"],
         wave=C,
         definition="Plan conversions in and out with the counterparty recordkeeper, blackout notice and period, asset "
                    "transfer and record reconciliation status, and fund change events with their mapping. Plan "
                    "services and sponsor teams track onboarding risk and blackout compliance from it.",
         objects=[("16", "Plan Conversion"), ("16", "Fund Change Event"), ("16", "Recordkeeper Profile"),
                  ("16", "Service Arrangement"), ("16", "Plan Investment Option"), ("16", "Participant Ledger Posting")],
         upstream=[PLN, "DP-430", PTY, CTR, EMP],
         notes="PII: 'No PII' at plan level; project owner is an employee reference."),
    dict(id="DP-470", name="Required Minimum Distribution Readiness", tier="Consumer-aligned", type="Operational",
         domain="16", owner_role="Head of Workplace Participant Services", primary="FN-71", supporting=["FN-62", "FN-67", "FN-19"],
         wave=C,
         definition="One list of clients who owe a required minimum distribution this year across their firm IRAs "
                    "(15 RMD Record) and recordkept plans (16 RMD Calculation), with amount required, amount "
                    "distributed and distribution elections on file. Client service and plan services contact those "
                    "short of the deadline from it.",
         objects=[("16", "RMD Calculation"), ("16", "Participant Distribution Election"), ("16", "Distribution Request"),
                  ("15", "RMD Record"), ("15", "Retirement Distribution Election")],
         upstream=[PLN, "DP-430", ACC, PTY, MMV],
         notes="PII: 'PII - financial'. The plan RMD is 16, the IRA RMD 15 (CW-034); the product joins them by party "
               "and never recomputes either."),
]

# ---------------------------------------------------------------------------------------------------------------------
# Dispositions of the pending products owned by 16, 48, 49 and 50 (RESCOPE_PENDING, CW-041). Only DP-095 and DP-096
# are pending in this group; DP-094 is live and the framing agent's (recommendations in the brief, section 3).
# (id, disposition, successor, decision, reason)
# ---------------------------------------------------------------------------------------------------------------------
DISPOSITIONS = [
    ("DP-095", "Re-scope in place", "DP-095", "CW-233",
     "Plan Contribution, Loan & Distribution Operations keeps its id, name, grain and owner (Head of Retirement Plan "
     "Services; FN-19). Re-point per proposals_w3_16 NOTES: Posting, Disbursement, Forfeiture and Settlement "
     "Transactions resolve to 16 Participant Ledger Posting (CW-125), the 06 Transaction inputs and DP-006 upstream are "
     "dropped for DP-430; add Rollover Contribution Detail and Participant Distribution Election; upstream DP-094, "
     "DP-430, DP-093, DP-240 (for DP-003 and DP-001, pending re-scope) and DP-013; supporting FN-15 (no capabilities) "
     "becomes FN-71 and FN-66. Its operational exception list is still needed and no candidate duplicates it."),
    ("DP-096", "Re-scope in place", "DP-096", "CW-233",
     "Plan Compliance Testing & Filing Status keeps its id, name, grain and owner (Head of Retirement Plan Compliance; "
     "FN-19). Re-point: Form 5500 Detail plan assets and participant counts are Derived from Participant Balance "
     "(DP-430 upstream); Related Complaint resolves to 08 Complaint, not DP-061; upstream DP-003 and DP-001 replaced "
     "by DP-240 and DP-094; supporting FN-13 (no capabilities) becomes FN-44 and FN-71. Lever: TPA-partnered programs "
     "make the test and filing rows received records (16 lever 7.7.1)."),
]

DECISIONS = [
    {"id": "CW-230", "theme": "Data Products", "title": "Brokerage, cash and workplace products take every certified number from its owner",
     "domains": ["48", "49", "50", "16", "06", "32", "10"],
     "issue": "The BWO consumer products count transfers, deposits, rollovers, sweep cash and participant returns, all "
              "of which look like certified Client Assets, Net New Assets, Advised Assets or Personal Rate of Return.",
     "resolution": "Proposed: DP-448, DP-457, DP-462, DP-466, DP-467 and DP-468 consume Client Assets, Net New Assets, "
                   "Advised Assets and the rollover capture rate from Client Assets & Net New Assets (DP-008 successor, "
                   "CW-142) and Personal Rate of Return from DP-145 extended (CW-129). Their own amounts are named as "
                   "operational values (transfer value, funding amount, allocated sweep balance, hand-off rollover "
                   "amount) and never labeled as a certified family. Sweep program revenue is 10's (CW-156).",
     "rationale": "CW-011 and the WP0 instructions: a certified number is defined in one product only.",
     "action": "WP1", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
    {"id": "CW-231", "theme": "Data Products", "title": "Special-category money movement and senior investor data publish a restricted view and aggregates",
     "domains": ["50", "02", "08", "15", "16"],
     "issue": "DP-456 needs hold reasons of suspected exploitation and the client protection facts behind them (02 "
              "Specified Adult Status and Vulnerability Concern, 08 Senior Investor Case; special category, CD-344, "
              "CW-030, CW-115); DP-466 reads hardship reasons.",
     "resolution": "Proposed: DP-456 publishes two outputs, a restricted row-level view for money movement, senior "
                   "investor and compliance roles (Restricted - Personal Data) and an aggregate view by hold type, age "
                   "and outcome, and reads the 02 and 08 client protection facts only through the CLA-A restricted view "
                   "DP-322 (CW-213). DP-466 shows hardship only as counts with a minimum cell size. No other BWO product "
                   "reads these objects.",
     "rationale": "Applies CW-030, CW-115 and CW-213 at product level.",
     "action": "WP1", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
    {"id": "CW-232", "theme": "Data Products", "title": "Participant Balances & Ledger is a foundational product separate from DP-094",
     "domains": ["16", "06", "32", "46"],
     "issue": "The W3 note proposed that DP-094 publish Participant Balance; DP-094 is a Master & Reference product at "
              "membership grain, while balances and ledger postings are daily facts read by 06, 32, 46 and five BWO products.",
     "resolution": "Proposed: DP-430 Participant Balances & Ledger (Foundational, Conformed Facts) publishes Participant "
                   "Balance, Participant Ledger Posting and Participant Investment Transfer; DP-094 adds the moved "
                   "profiles (Plan Sponsor Profile, Recordkeeper Profile, Retirement Plan Profile, Plan Service "
                   "Provider, Plan Managed Account Service) and the distribution and service elections.",
     "rationale": "Mirrors the 18 split (DP-140 master, DP-141 and DP-142 facts) and keeps the third book of record (CW-007) in one product.",
     "action": "WP0", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
    {"id": "CW-233", "theme": "Data Products", "title": "DP-095 and DP-096 are re-scoped in place, not retired",
     "domains": ["16"],
     "issue": "DP-095 and DP-096 are pending (CW-041) and read 06 Transaction and the wholesale DP-001 and DP-003.",
     "resolution": "Proposed: both keep their ids and grains and are re-pointed per the DISPOSITIONS of "
                   "proposals_wdp_bwo (Participant Ledger Posting for 06 Transaction, DP-430 and DP-240 upstream, FN-15 "
                   "and FN-13 supporting replaced by FN-71, FN-66 and FN-44) and leave RESCOPE_PENDING at WP1.",
     "rationale": "Recordkeeping operations and plan compliance are unchanged by the wealth model; only references moved.",
     "action": "WP1", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
    {"id": "CW-234", "theme": "Data Products", "title": "Program Bank and Execution Venue are conformed by BWO foundational masters",
     "domains": ["50", "48", "49", "10", "15"],
     "issue": "Plan section 8.4 adds a Program Bank dimension, and routes, executions, Rule 605 and 606 lines and the "
              "best-execution review all key on the venue; neither is named among the section 8.2 foundational products.",
     "resolution": "Proposed: DP-431 Sweep Programs & Program Banks conforms Sweep Program and Program Bank; DP-432 "
                   "Execution Venues & Routing Rules conforms the venue and routing rule. If the framing agent's Money "
                   "Movement Transactions or Client Orders & Executions already carries either master, the BWO "
                   "candidate is withdrawn and its readers re-point.",
     "rationale": "One master, one product; both are firm-level reference data with their own owners and cadence.",
     "action": "WP0", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
    {"id": "CW-235", "theme": "Data Products", "title": "Self-clearing is the reference operating model of the BWO products; the clearing lever shrinks them",
     "domains": ["48", "49", "50"],
     "issue": "CD-297 and CD-331 ask each product to state its grain if the function is outsourced.",
     "resolution": "Proposed: under fully disclosed clearing DP-445 and DP-447 are withdrawn (the clearing firm computes "
                   "the reserve and settles), DP-446, DP-449 to DP-452 and DP-457 become oversight products over "
                   "received copies, and DP-435 to DP-441 keep their grain with the clearing firm's references "
                   "(48 lever 1, 49 lever 1, 50 lever 1).",
     "rationale": "The levers already written in the 48, 49 and 50 Source_Notes.",
     "action": "WP1", "status": "Proposed", "priority": "Low", "owner_role": "Program lead"},
]


# ---- WP1 scope (WP0 rationalization, 2026-10-15; Product_Briefs/WP1_Scope.md) ------------------------------
# Program-lead ruling: every candidate is flagged wp1=True (specified at WP1) or backlog=True (registered in
# framework.WAVE_BACKLOG, status 'backlog', not specified at WP1; ids unchanged). WP1_MERGES names the product a
# backlog candidate overlaps (its scope folds in there if it is picked up). WP1_MOVED_READS: objects with CDEs that
# only a backlog candidate read, now read by the named WP1 product (coverage rule; WP1 specs read them).
WP1_BACKLOG_IDS = ["DP-439", "DP-440", "DP-441", "DP-449", "DP-450", "DP-451", "DP-453", "DP-455", "DP-458", "DP-461", "DP-462", "DP-465", "DP-468", "DP-469", "DP-470"]
WP1_MERGES = {

    "DP-439": "DP-435",   # Order-Time Eligibility & Market Access Controls -> Order Lifecycle & CAT Completeness
    "DP-440": None,   # Brokerage Activity by Product & Session (stands alone)
    "DP-441": "DP-452",   # Option Exercise & Assignment Operations -> Client Corporate Action Entitlements & Elections
    "DP-449": "DP-417",   # Cost Basis & Form 1099-B Readiness -> Client Tax Forms & Cost Basis Reporting
    "DP-450": None,   # Margin Calls & Margin Exposure (stands alone)
    "DP-451": None,   # Fully Paid Securities Lending Program (stands alone)
    "DP-453": "DP-445",   # Brokerage Operations Daily Control Dashboard -> Customer Reserve & Possession-and-Control Control Pack
    "DP-455": None,   # ACH, Wire & Check Operations and Returns (stands alone)
    "DP-458": "DP-457",   # FDIC Pass-Through Coverage -> Cash Sweep & Program Bank Allocation
    "DP-461": "DP-457",   # Client Cash Forecast -> Cash Sweep & Program Bank Allocation
    "DP-462": "DP-392",   # Account Funding & Money-In Journey -> Acquisition Funnel & Account Opening Conversion
    "DP-465": "DP-514",   # Plan Sponsor Reporting Data -> Plan Sponsor Servicing & Plan Reviews
    "DP-468": "DP-466",   # Participant Managed Account Program -> Participant Outcomes
    "DP-469": "DP-514",   # Plan Conversion & Fund Change Tracker -> Plan Sponsor Servicing & Plan Reviews
    "DP-470": "DP-329",   # Required Minimum Distribution Readiness -> Retirement Account RMD & Distribution Tracker
}
WP1_MOVED_READS = {

    "DP-456": [('50', 'Bank Account Verification Event', "DP-331, DP-455, DP-462")],
    "DP-435": [('48', 'Order Eligibility Check', "DP-439"), ('48', 'Pre-Trade Risk Limit', "DP-439")],
    "DP-452": [('48', 'Option Exercise Instruction', "DP-441"), ('48', 'Option Assignment Allocation', "DP-441")],
    "DP-457": [('50', 'FDIC Coverage Assessment', "DP-458"), ('50', 'Client Cash Forecast', "DP-461"), ('50', 'Client Cash Forecast Line', "DP-461")],
    "DP-466": [('16', 'Plan Managed Account Service', "DP-468"), ('16', 'Participant Service Election', "DP-468")],
}
for _c in list(CANDIDATES) + list(globals().get("RESCOPED", [])):
    _bl = _c["id"] in WP1_BACKLOG_IDS
    _c["wp1"], _c["backlog"] = not _bl, _bl
    if _bl:
        _t = WP1_MERGES.get(_c["id"])
        _c["merge_into"] = _t
        _c["notes"] = (_c.get("notes", "") + " Backlog (WP1_Scope.md): not specified at WP1"
                       + (f"; overlaps {_t}, into which its scope folds if it is picked up." if _t else "; stands alone."))
    for _o in WP1_MOVED_READS.get(_c["id"], []):
        if (_o[0], _o[1]) not in _c["objects"]:
            _c["objects"].append((_o[0], _o[1]))
            _c["notes"] = _c.get("notes", "") + f" WP1 scope: also reads {_o[0]} {_o[1]} (from backlog {_o[2]})."
