"""WP0 product brief proposals: CLA-A Client & Advice (wealth-manager rework, Stage WP0 Product framing).

Data Domains 02 Client & Household, 15 Account, 45 Financial Planning & Advice, 46 Managed Portfolios & Rebalancing,
47 Pricing, Fees & Billing and 51 Trust & Estate Services. Brief: 00_Program/Rework/Product_Briefs/CLA_A_Client_and_Advice.md.
Reserved product IDs DP-320 to DP-379 (DP-320 to DP-356 used); reserved decision IDs CW-210 to CW-219 (CW-210 to CW-216 used).
Waves: "WP1C" (consumer); no foundational candidate is proposed here (the framing agent's DP-300 to DP-319 cover the group).

Check from _tools:  /usr/bin/python3 data_products/candidate_coverage.py proposals_wdp_cla_a

Upstream names that are not DP- ids are the WP0 framing agent's foundational products (plan section 8.2), written as
"<planned name> [DP-30x framing]" for the lead to resolve, and the re-scoped successors CW-011 names:
  Client Holdings, Lots & Cost Basis (49); Client Orders & Executions (48); Money Movement Transactions (50);
  Advice Plans & Recommendations (45); Managed Account Model Assignments (46); Fee Schedules & Billing Runs (47);
  Trust Fiduciary Record (51); Manager & Sub-Adviser Master (52);
  Client Assets & Net New Assets (the DP-008 successor, 06: Client Assets, Net New Assets, Advised Assets);
  Client Fee Revenue (the DP-012 re-scope, 10).
Existing ids used as they are: DP-240 Enterprise Party & Role Master (re-scoped to the client household; certified
Households and Clients), DP-093 Account Master (re-scoped; certified Accounts), DP-145 Official Returns (extended with
Personal Rate of Return, 32), DP-009 (re-cut to the advisor organization, 03), DP-004, DP-013, DP-192, DP-213, DP-097, DP-143.

Status: Proposed (WP0). Nothing here is merged; DISPOSITIONS and DECISIONS are for the program lead.
"""

W = "WP1C"

# ---- Upstream foundational products (framing placeholders and existing ids) -------------------------------------------
PTY = "DP-240"      # Enterprise Party & Role Master (client household re-scope)
ACC = "DP-093"      # Account Master (brokerage and advisory account re-scope)
REF = "DP-013"      # Enterprise Reference & Calendars
OFR = "DP-004"      # Product & Share Class Distribution Reference (offerings, service tiers, model portfolios at WP1)
EMP = "DP-192"      # Employee & Position Master
ADV = "DP-009"      # Sales Organization & Coverage, re-cut to the advisor organization (03)
RET = "DP-145"      # Official Returns, extended with Personal Rate of Return (32)
SEC = "DP-097"      # Security Master & Identifiers
CTR = "DP-213"      # Enterprise Contract Register
CHL = "DP-300"
ORD = "DP-301"
MMV = "DP-302"
APR = "DP-303"
MAM = "DP-304"
FSB = "DP-305"
TFR = "DP-307"
CAN = "DP-008"
CFR = "DP-012"

# ---- Owner roles (capability-map owners of the capability each product mainly serves) ----------------------------------
R_CD = "Head of Client Data"
R_ONB = "Head of Client Onboarding"
R_AS = "Head of Account Services"
R_PRV = "Privacy Officer"
R_ADV = "Head of Advice"
R_FP = "Head of Financial Planning"
R_DIG = "Head of Digital Advice"
R_WPS = "Head of Workplace Solutions"
R_MAO = "Head of Managed Account Operations"
R_PB = "Head of Pricing & Billing"
R_TR = "Head of Trust Services"
R_RC = "Head of Retail Conduct"
R_CCA = "Head of Client & Channel Analytics"
R_CS = "Head of Client Service"
R_PRD = "Head of Advice Products"

CANDIDATES = [
    # ================================================ 02 Client & Household ================================================
    dict(id="DP-320", name="Household 360", tier="Consumer-aligned", type="Analytical", domain="02", owner_role=R_CD,
         primary="FN-60", supporting=["FN-61", "FN-62", "FN-63", "FN-67", "FN-72", "FN-73", "FN-69"], wave=W,
         definition="One view of each Client Household and its members: who they are and how they are related, the accounts "
                    "they own and the programs those accounts are enrolled in, their goals and plan status, managed models, "
                    "fee household, service tier, advisor coverage and recent service contact, with Client Assets and "
                    "Personal Rate of Return taken from their certified owners. It exists so an advisor, planner or service "
                    "associate sees the whole household before a review or a call; it owns no certified number.",
         objects=[("02", "Party"), ("02", "Individual"), ("02", "Household"), ("02", "Household Membership"),
                  ("02", "Party Relationship"), ("02", "Service Tier Assignment"), ("02", "Segment Assignment"),
                  ("15", "Account"), ("15", "Account Party Role"), ("15", "Program Enrollment"),
                  ("45", "Advice Engagement"), ("45", "Financial Goal"), ("45", "Goal Progress Snapshot"),
                  ("45", "Client Financial Plan"), ("46", "Model Assignment"), ("46", "Household Managed Group"),
                  ("47", "Fee Household"), ("47", "Fee Household Membership"), ("51", "Trust"),
                  ("06", "Client Asset Measures"), ("32", "Personal Rate of Return"), ("32", "Household Performance Group"),
                  ("03", "Party Coverage Assignment"), ("13", "Contact Center Interaction")],
         upstream=[PTY, ACC, CAN, RET, APR, MAM, FSB, TFR, ADV, REF],
         notes="Plan 8.3 example. Certified numbers consumed, never recomputed (CW-011, CW-211): Client Assets and Advised "
               "Assets from the DP-008 successor; Personal Rate of Return from DP-145 (acceptance question 9 resolves there); "
               "Households, Clients and Accounts counts from DP-240 and DP-093. Holdings book: none read directly; household "
               "assets by holding type come from the DP-008 successor (built on Client Holding, 49). PII: Confidential - "
               "Personal Data; special-category facts appear only as the DP-322 'protection flag present' indicator "
               "(CW-213). Boundary: DP-243 Total Client Relationship stays the institutional (IA) relationship view. "
               "Levers: household definition (02 SME 2), household-only firms collapse member rows; TR line drops the trust panel."),
    dict(id="DP-321", name="Authorized Persons, Trusted Contacts & Beneficiaries", tier="Consumer-aligned", type="Operational",
         domain="02", owner_role=R_AS, primary="FN-62", supporting=["FN-67", "FN-68", "FN-69", "FN-60"], wave=W,
         definition="The current register of who may act for or be contacted about each client and account: powers of "
                    "attorney and other authority grants with their scope and verification, trusted contact designations "
                    "(FINRA Rule 4512), beneficiary and TOD designations, and death notifications with the account actions "
                    "they trigger. Service and operations work its exceptions: accounts with no trusted contact requested, "
                    "authority grants unverified or expired, accounts with no or invalid beneficiary allocation, and deaths "
                    "notified but accounts not yet restricted.",
         objects=[("02", "Authority Grant"), ("02", "Trusted Contact Designation"), ("02", "Death Notification"),
                  ("02", "Party Relationship"), ("02", "Individual"), ("15", "Account"), ("15", "Account Party Role"),
                  ("15", "Beneficiary Designation"), ("15", "Account Restriction"),
                  ("13", "Transfer of Ownership & Estate"), ("39", "Power of Attorney")],
         upstream=[PTY, ACC, REF],
         notes="Trusted Contact Coverage Rate (accounts opened or updated since Rule 4512(a)(1)(F) where a reasonable "
               "effort to obtain a trusted contact is recorded) is the key measure. 39 Power of Attorney is the firm's own "
               "POA (signing authority) and is read only to exclude internal grants; confirm at spec. PII: Confidential - "
               "Personal Data (names, dates of birth and death of third parties). Lever: trusted contact per client or per "
               "account (02 SME 6)."),
    dict(id="DP-322", name="Client Protection Flags & Senior Investor Register", tier="Consumer-aligned",
         type="Regulatory & Control", domain="02", owner_role=R_RC, primary="FN-68",
         supporting=["FN-66", "FN-67", "FN-60", "FN-69", "FN-62"], wave=W,
         definition="The restricted register of clients with specified adult status, open vulnerability concerns, temporary "
                    "holds under FINRA Rule 2165 and the senior investor cases and external reports opened on them, with "
                    "the trusted contact and authority grants that bear on each case. It also publishes the one unrestricted "
                    "field other products may carry: a protection flag with no detail, so service, advice and money "
                    "movement know to route the client to trained staff.",
         objects=[("02", "Specified Adult Status"), ("02", "Vulnerability Concern"), ("02", "Trusted Contact Designation"),
                  ("02", "Authority Grant"), ("15", "Account Restriction"), ("08", "Senior Investor Case"),
                  ("08", "Senior Investor Case Action"), ("08", "External Protection Report"), ("50", "Money Movement Hold")],
         upstream=[PTY, ACC, MMV, EMP],
         notes="Special category (CD-344, CW-213): the register itself is Restricted - Personal Data, visible to retail "
               "conduct, the senior investor team and named service roles; every other CLA-A product reads only the "
               "Protection Flag Present indicator. Boundary: the cash movements on hold for fraud or elder-exploitation "
               "review (acceptance question 7, plan 8.3 'Fraud & Elder-Exploitation Holds') are the 50 brief's product, "
               "which reads 02 Specified Adult Status and Vulnerability Concern through this product's restricted view, "
               "never the detail. Lever: which special-category facts advisors may record (02 SME 5)."),
    dict(id="DP-323", name="Investor Profile Currency & Suitability Inputs", tier="Consumer-aligned", type="Regulatory & Control",
         domain="02", owner_role=R_ADV, primary="FN-60", supporting=["FN-61", "FN-68", "FN-62", "FN-63"], wave=W,
         definition="For every client and account, whether the investor profile that Reg BI, the Advisers Act and SEC Rule "
                    "17a-3(a)(17) rely on is current: the latest attested profile version, its review date, the account "
                    "investment profiles and recommendations still pointing at superseded versions, options approval levels "
                    "against stated experience, and investor qualification for feeder fund subscriptions. It feeds the "
                    "advisor worklist and the supervision of recommendations with one answer per client.",
         objects=[("02", "Investor Profile"), ("02", "Investment Experience"), ("02", "Investor Qualification"),
                  ("02", "Regulatory Classification"), ("15", "Account Investment Profile"), ("15", "Account Feature"),
                  ("15", "Options Approval Detail"), ("15", "Alternative Investment Subscription"),
                  ("45", "Advice Review"), ("45", "Recommendation")],
         upstream=[PTY, ACC, APR, OFR],
         notes="Answers the profile part of acceptance question 3 (recommendations made on a stale or superseded profile). "
               "Takes Alternative Investment Subscription over from DP-116 and DP-136 if they retire at WP0 (CW-930). "
               "PII: Confidential - Personal Data (income, net worth and tax-rate bands). Levers: profile per client or per "
               "household (02 SME 1); whether the Rule 3a-4 annual contact creates a version (02 SME 3)."),
    dict(id="DP-324", name="Client Contactability, Preferences & Consent", tier="Consumer-aligned", type="Operational",
         domain="02", owner_role=R_CS, primary="FN-67", supporting=["FN-76", "FN-62", "FN-61"], wave=W,
         definition="The one answer to whether, how and about what the firm may contact each client: valid contact points and "
                    "postal addresses, do-not-contact channels, topic subscriptions, consents, e-delivery elections and mail "
                    "holds, joined to marketing suppression. Campaigns, service outreach and statement production read it "
                    "instead of re-deriving contact rules.",
         objects=[("02", "Contact Point"), ("02", "Postal Address"), ("02", "Contact Preference"),
                  ("02", "Communication Preference"), ("02", "Consent Record"), ("02", "Privacy Profile"),
                  ("13", "E-Delivery Election"), ("13", "Mail Hold"), ("04", "Suppression Entry")],
         upstream=[PTY, REF],
         notes="Boundary with DP-080: DP-080 is the evidence register of privacy requests and opt-outs; this product is the "
               "operational contact rule set. PII: Confidential - Personal Data. Lever: state privacy regimes in scope (02 SME 8)."),
    dict(id="DP-325", name="Service Tier Qualification & Client Segments", tier="Consumer-aligned", type="Analytical",
         domain="02", owner_role=R_PRD, primary="FN-78", supporting=["FN-73", "FN-67", "FN-76", "FN-60"], wave=W,
         definition="Each household's service tier and segment, the qualifying Client Assets as of the qualification date, "
                    "overrides and their approvers, and the households that now qualify above or below their tier. Offering "
                    "management and advisor workforce planning use it to size tiers and to re-assign coverage.",
         objects=[("02", "Service Tier Assignment"), ("02", "Segment Assignment"), ("02", "Household Membership"),
                  ("01", "Service Tier"), ("01", "Service Offering"), ("06", "Client Asset Measures"),
                  ("03", "Party Coverage Assignment")],
         upstream=[PTY, OFR, CAN, ADV],
         notes="Consumes Client Assets (CW-011); Qualifying Client Assets on the assignment is the 02 copy at qualification. "
               "PII: Confidential - Personal Data at household grain; aggregates Internal. Lever: whether workplace plan "
               "assets count toward tier (02 SME 10)."),
    dict(id="DP-326", name="Client Base Movement & Attrition", tier="Consumer-aligned", type="Analytical", domain="02",
         owner_role=R_CCA, primary="FN-77", supporting=["FN-76", "FN-67", "FN-60", "FN-78"], wave=W,
         definition="How the client base moves: new, reactivated, attrited and deceased clients and households, accounts opened "
                    "and closed with their reasons, by channel, business line, tier and acquisition source, with the Net New "
                    "Assets that each movement carried. It explains the change in the certified Households, Clients and "
                    "Accounts counts without restating them.",
         objects=[("02", "Party"), ("02", "Household Membership"), ("02", "Death Notification"), ("15", "Account"),
                  ("15", "Account Status History"), ("15", "Account Lifecycle Event"), ("15", "Account Closure"),
                  ("06", "Account Channel Assignment"), ("06", "Client Asset Measures"), ("04", "Lead Conversion")],
         upstream=[PTY, ACC, CAN, REF],
         notes="Counts are certified in DP-240 and DP-093 and Net New Assets in the DP-008 successor (CW-011); this product "
               "decomposes them and must tie to both. Outbound ACATS detail is the 49 brief's ACATS In and Out product. "
               "PII: aggregates Internal; client-level drill Confidential - Personal Data."),
    # ===================================================== 15 Account =====================================================
    dict(id="DP-327", name="Account Opening & Good Order Pipeline", tier="Consumer-aligned", type="Operational", domain="15",
         owner_role=R_ONB, primary="FN-62", supporting=["FN-61", "FN-76", "FN-67", "FN-66"], wave=W,
         definition="Every account application from start to funded: the digital application journey, onboarding case, "
                    "identity verification, agreements signed and disclosures delivered, feature approvals, tax "
                    "certification, bank instruction and first funding, with the date each reached good order. New accounts "
                    "teams work its not-in-good-order queue and leadership tracks time to open and time to fund.",
         objects=[("15", "Account Opening"), ("15", "Account"), ("15", "Account Agreement"), ("15", "Account Disclosure Delivery"),
                  ("15", "Account Feature"), ("15", "Account Tax Certification"), ("15", "Bank Instruction"),
                  ("15", "Account Lifecycle Event"), ("02", "Onboarding Case"), ("02", "Identity Verification"),
                  ("04", "Application Journey"), ("04", "Acquisition Milestone"), ("50", "Money Movement")],
         upstream=[ACC, PTY, MMV, REF],
         notes="PII: Confidential - Personal Data; identity evidence is not carried, only results. Lever: an outsourced TA "
               "keeps fund-only CIP (02 SME 4)."),
    dict(id="DP-328", name="Account Features, Agreements & Disclosure Evidence", tier="Consumer-aligned",
         type="Regulatory & Control", domain="15", owner_role=R_AS, primary="FN-62",
         supporting=["FN-68", "FN-65", "FN-66", "FN-64"], wave=W,
         definition="The standing evidence that each account feature in force (margin, options, sweep, checkwriting, debit card, "
                    "fully paid lending, new issue eligibility) has its approval, signed agreement version and required "
                    "disclosure, and that Form CRS and the account opening disclosures were delivered when Reg BI and the "
                    "Advisers Act require. Supervision and brokerage operations use its exceptions; examiners get one file.",
         objects=[("15", "Account Feature"), ("15", "Options Approval Detail"), ("15", "Margin Account Detail"),
                  ("15", "Cash Sweep Election"), ("15", "Account Agreement"), ("15", "Account Disclosure Delivery"),
                  ("15", "New Issue Eligibility"), ("08", "Disclosure Delivery Check"), ("50", "Sweep Program")],
         upstream=[ACC, CTR, REF],
         notes="Rule citations at spec: FINRA 2360(b)(16) options approval, 4210 margin, 2264 margin disclosure, 5130/5131 "
               "new issues, Reg BI disclosure obligation. Boundary: 08 Disclosure Delivery Check is the supervisory test; this "
               "product assembles the facts it tests (CW-215). Lever: feature families dropped (15 SME 2)."),
    dict(id="DP-329", name="Retirement Account RMD & Distribution Tracker", tier="Consumer-aligned", type="Operational",
         domain="15", owner_role=R_AS, primary="FN-62", supporting=["FN-60", "FN-67", "FN-65", "FN-66"], wave=W,
         definition="For every IRA-family and inherited account, the required minimum distribution for the year, what has been "
                    "distributed so far, the withholding election and the beneficiary rules (10-year rule, required beginning "
                    "date) that apply. Service and advisors work the shortfall list before year-end and operations evidence "
                    "that RMD notices and distributions were made.",
         objects=[("15", "RMD Record"), ("15", "Retirement Account Detail"), ("15", "Education & Health Savings Account Detail"),
                  ("15", "Retirement Distribution Election"), ("15", "Beneficiary Designation"), ("15", "Account"),
                  ("02", "Individual"), ("49", "Client Account Activity"), ("49", "Client Holding Valuation")],
         upstream=[ACC, PTY, CHL, MMV],
         notes="Holdings book: Client Holding Valuation (49) for prior year-end fair market value (CW-007). Plan-side RMDs are "
               "16 RMD Calculation (Workplace brief). PII: Confidential - Personal Data. Lever: RMD for every IRA with "
               "aggregation flagged (15 SME 6)."),
    dict(id="DP-330", name="Account Tax Certification & Cost Basis Election Status", tier="Consumer-aligned",
         type="Regulatory & Control", domain="15", owner_role=R_AS, primary="FN-62", supporting=["FN-65", "FN-67", "FN-39"], wave=W,
         definition="Each account's tax certification (W-9, W-8 forms) and its expiry, backup withholding and B-notice status, "
                    "tax reporting regimes, and cost basis method elections by scope, with the tax forms produced. Operations "
                    "clears missing and expiring certifications before backup withholding applies and evidences the election "
                    "applied to each lot relief.",
         objects=[("15", "Account Tax Certification"), ("15", "Account Tax Reporting Status"), ("15", "Cost Basis Election"),
                  ("02", "Tax Profile"), ("49", "Cost Basis Transfer Statement"), ("13", "Tax Form Record")],
         upstream=[ACC, PTY, CHL],
         notes="Taxpayer identification numbers are never published; only certification status. PII: Restricted - Personal "
               "Data at account grain. Cost basis itself is 49 (Client Tax Lot) through the framing product."),
    dict(id="DP-331", name="Systematic Investment & Withdrawal Plans", tier="Consumer-aligned", type="Analytical",
         domain="15", owner_role=R_AS, primary="FN-66", supporting=["FN-62", "FN-60", "FN-77"], wave=W,
         definition="The standing instructions that move money on a schedule (automatic investment, systematic withdrawal, "
                    "dividend handling, recurring transfers) with their bank instructions, verification status and the "
                    "executions and returns they produced. It shows recurring contribution and withdrawal run-rates by "
                    "segment and the instructions failing or unverified.",
         objects=[("15", "Account Standing Instruction"), ("15", "Bank Instruction"), ("15", "Account Preference"),
                  ("50", "Money Movement"), ("50", "Money Movement Return"), ("50", "Bank Account Verification Event")],
         upstream=[ACC, MMV, REF],
         notes="Net New Assets stays certified in the DP-008 successor; run-rates here are operational. Fraud review of bank "
               "instruction changes is the 50 brief's. PII: Confidential - Personal Data (masked bank account only)."),
    dict(id="DP-332", name="Advisory Program Enrollment & Rule 3a-4 Compliance", tier="Consumer-aligned",
         type="Regulatory & Control", domain="15", owner_role=R_MAO, primary="FN-63",
         supporting=["FN-61", "FN-68", "FN-60", "FN-78"], wave=W,
         definition="Every advisory program enrollment with the conditions of the Rule 3a-4 safe harbor and the advisory "
                    "agreement: the annual contact and profile confirmation, the quarterly statement, the reasonable "
                    "restrictions the client asked for and how 46 implements each, and the enrollment's source "
                    "recommendation. Program management and supervision use it to show each account is individually managed.",
         objects=[("15", "Program Enrollment"), ("15", "Account Agreement"), ("15", "Account Hierarchy Link"),
                  ("45", "Advice Review"), ("46", "Model Assignment"), ("46", "Account Investment Constraint"),
                  ("02", "Client Restriction"), ("13", "Investor Document"), ("01", "Service Offering")],
         upstream=[ACC, MAM, APR, OFR, PTY],
         notes="Boundary: 15 says which restrictions were accepted, 46 how each is implemented (46 Source_Notes overlap). "
               "Lever: enrollment per household (15 SME 1)."),
    # ============================================ 45 Financial Planning & Advice ============================================
    dict(id="DP-333", name="Advice Funnel & Conversion", tier="Consumer-aligned", type="Analytical", domain="45",
         owner_role=R_ADV, primary="FN-60", supporting=["FN-61", "FN-76", "FN-73", "FN-78"], wave=W,
         definition="The path from lead or referral to an advised relationship: referrals and leads, advice engagements opened, "
                    "plans presented and accepted, recommendations accepted or declined, and enrollments and assets that "
                    "followed, by channel, advisor, campaign and offering. Advice leadership uses it to see where clients "
                    "drop out and which channels convert.",
         objects=[("45", "Advice Engagement"), ("45", "Engagement Participant"), ("45", "Recommendation"),
                  ("45", "Recommendation Implementation Link"), ("45", "Client Financial Plan Version"),
                  ("15", "Program Enrollment"), ("04", "Marketing Lead"), ("04", "Lead Conversion"),
                  ("03", "Channel Referral"), ("03", "Referral Status History"), ("03", "Advisor")],
         upstream=[APR, PTY, ACC, CAN, ADV, OFR],
         notes="Plan 8.3 example. Consumes Net New Assets and Advised Assets (DP-008 successor); publishes conversion rates "
               "only. Acceptance question 2 (NNA by advisor and campaign) resolves in the DP-008 successor; this product "
               "adds the funnel behind it. PII: aggregates Internal; drill Confidential - Personal Data."),
    dict(id="DP-334", name="Plan Quality & Recommendation Evidence (Reg BI File)", tier="Consumer-aligned",
         type="Regulatory & Control", domain="45", owner_role=R_ADV, primary="FN-60", supporting=["FN-68", "FN-61", "FN-71"], wave=W,
         definition="For every recommendation, the evidence chain Reg BI's care obligation and SEC Rule 17a-3(a)(35) require: "
                    "the profile version and plan version relied on, the rationale, the alternatives and costs considered, "
                    "each best-interest component with its attestation, the disclosure delivered and the supervisory review "
                    "outcome. It lists recommendations missing any element and scores plan inputs for completeness, so advice "
                    "quality and supervision work from one file.",
         objects=[("45", "Recommendation"), ("45", "Recommendation Rationale"), ("45", "Recommendation Alternative"),
                  ("45", "Best Interest Evidence"), ("45", "Client Financial Plan"), ("45", "Client Financial Plan Version"),
                  ("45", "Client Planning Assumptions"), ("45", "Planning Cash Flow Input"), ("45", "Planning Balance Sheet Item"),
                  ("02", "Investor Profile"), ("15", "Account Disclosure Delivery"), ("08", "Supervisory Review"),
                  ("08", "Best Interest Review Detail")],
         upstream=[APR, PTY, ACC, OFR, EMP],
         notes="Plan 8.3 example; acceptance question 3 (first half): Evidence Gap Flag = a recommendation with any Best "
               "Interest Evidence component not satisfied or unattested, or no Recommendation Rationale, mastered in 45. "
               "Assembles, never re-scores (CW-215): the 08 review outcome is read as recorded. PII: Confidential - "
               "Personal Data. Lever: brokerage security recommendations recorded or not (45 SME 2)."),
    dict(id="DP-335", name="Rollover Recommendations & PTE 2020-02 Evidence", tier="Consumer-aligned",
         type="Regulatory & Control", domain="45", owner_role=R_WPS, primary="FN-71", supporting=["FN-60", "FN-68", "FN-19"], wave=W,
         definition="Every rollover recommendation with its analysis, the options compared and their costs, the fiduciary status "
                    "basis, and the PTE 2020-02 documentation (fiduciary acknowledgment, services and conflicts disclosure, "
                    "reasons, impartial conduct attestation), joined to the plan distribution and the receiving IRA. It lists "
                    "rollovers missing documentation and feeds the 08 annual retrospective review.",
         objects=[("45", "Rollover Analysis"), ("45", "PTE 2020-02 Documentation"), ("45", "Rollover Option Comparison"),
                  ("45", "Recommendation"), ("45", "Best Interest Evidence"), ("16", "Distribution Request"),
                  ("16", "Participant Retail Hand-Off"), ("16", "Rollover Contribution Detail"), ("15", "Account"),
                  ("08", "Supervisory Review")],
         upstream=[APR, ACC, "DP-094", PTY],
         notes="Acceptance question 3 (second half): PTE Documentation Gap Flag from the four PTE 2020-02 Documentation CDEs. "
               "Boundary: rollover capture rate (acceptance question 10, plan 8.3 'Rollover Capture') is the Workplace "
               "brief's product; this one is the evidence. Lever: every rollover treated as fiduciary advice (45 SME 9)."),
    dict(id="DP-336", name="Advice Review Cadence & Plan Currency", tier="Consumer-aligned", type="Operational", domain="45",
         owner_role=R_FP, primary="FN-60", supporting=["FN-61", "FN-73", "FN-68"], wave=W,
         definition="The schedule of reviews every advice engagement owes (periodic reviews, digital check-ins, Rule 3a-4 annual "
                    "contacts) with what is due, held and overdue, and the age of each plan, its assumption set and the "
                    "profile it rests on. Advisors and planning managers clear overdue reviews and refresh stale plans.",
         objects=[("45", "Advice Review"), ("45", "Advice Engagement"), ("45", "Client Financial Plan"),
                  ("45", "Client Financial Plan Version"), ("45", "Planning Assumption Set"), ("45", "Plan Goal Inclusion"),
                  ("02", "Investor Profile"), ("15", "Program Enrollment")],
         upstream=[APR, PTY, ACC, EMP],
         notes="Review due dates are mastered in 45; the Rule 3a-4 date on 15 Program Enrollment is a Derived copy (CW-044). "
               "PII: Confidential - Personal Data."),
    dict(id="DP-337", name="Goal Progress & Funded Status", tier="Consumer-aligned", type="Analytical", domain="45",
         owner_role=R_DIG, primary="FN-61", supporting=["FN-60", "FN-67", "FN-71"], wave=W,
         definition="Each financial goal's progress: target, funding accounts and aggregated outside accounts, funded ratio and "
                    "probability of success from the latest scenario, with retirement-income and education detail, and the "
                    "goals that moved off track. The digital experience shows it to clients and advice leadership sees goal "
                    "outcomes across the book.",
         objects=[("45", "Financial Goal"), ("45", "Goal Funding Link"), ("45", "Retirement Income Goal Detail"),
                  ("45", "Education Goal Detail"), ("45", "Goal Progress Snapshot"), ("45", "Planning Scenario"),
                  ("45", "Goal Projection Result"), ("45", "Projection Year Result"), ("32", "Personal Rate of Return")],
         upstream=[APR, RET, CAN, PTY],
         notes="Personal Rate of Return shown by reference to DP-145 (CW-011); 45 never computes returns. PII: Confidential - "
               "Personal Data; health-based longevity bases excluded (45 SME 6)."),
    dict(id="DP-338", name="Held-Away Assets & Consolidation Opportunity", tier="Consumer-aligned", type="Analytical",
         domain="45", owner_role=R_FP, primary="FN-60", supporting=["FN-76", "FN-61", "FN-71", "FN-73"], wave=W,
         definition="Assets clients hold at other institutions, from account aggregation (balances and asset-class mix) and the "
                    "stated outside-assets band, with connection health and consent, by household, account type and source "
                    "institution type. Advisors and marketing use it to size consolidation and rollover opportunity.",
         objects=[("45", "Aggregated Account"), ("45", "Aggregated Account Balance"), ("02", "Investor Profile"),
                  ("16", "Separated Participant Entry")],
         upstream=[APR, PTY, "DP-094"],
         notes="Observed balance versus stated band: neither replaces the other (CW-024). Held-away assets are never Client "
               "Assets. PII: Confidential - Personal Data; Aggregation Consent governs use (Reg S-P, CFPB 1033 status "
               "'confirm'). Lever: holding-level aggregation (45 SME 5)."),
    dict(id="DP-339", name="Digital Advice Engine Outcomes & Oversight", tier="Consumer-aligned", type="Regulatory & Control",
         domain="45", owner_role=R_DIG, primary="FN-61", supporting=["FN-60", "FN-68", "FN-42", "FN-63"], wave=W,
         definition="What the advice algorithms recommended, by engine and version: the distribution of recommended models "
                    "against risk tolerance and time horizon, human overrides, client acceptance, and the assumption sets and "
                    "model validations each engine version ran under. Digital advice and model risk use it to evidence the "
                    "SEC robo-adviser guidance and to detect drift in engine behavior after a release.",
         objects=[("45", "Recommendation"), ("45", "Recommendation Rationale"), ("45", "Planning Scenario"),
                  ("45", "Planning Assumption Set"), ("46", "Model Assignment"), ("37", "Model Inventory Entry"),
                  ("37", "Model Validation"), ("02", "Investor Profile")],
         upstream=[APR, MAM, PTY],
         notes="Engines are inventoried in 37 (45 SME 8). PII: aggregates Internal; drill Confidential - Personal Data."),
    dict(id="DP-340", name="Advisor Client Action Worklist", tier="Consumer-aligned", type="Operational", domain="45",
         owner_role=R_ADV, primary="FN-60", supporting=["FN-73", "FN-67", "FN-63", "FN-62"], wave=W,
         definition="One prioritized list per advisor of the client actions due: reviews overdue, stale profiles, missing "
                    "trusted contacts or beneficiaries, RMD shortfalls, accounts out of drift tolerance, goals off track and "
                    "evidence gaps, each with its source product and due date. It is delivered into the advisor desktop so "
                    "advisors work exceptions without opening six reports.",
         objects=[("45", "Advice Engagement"), ("45", "Advice Review"), ("03", "Party Coverage Assignment"), ("03", "Advisor")],
         upstream=["DP-336", "DP-323", "DP-321", "DP-329", "DP-341", "DP-337", "DP-334", ADV],
         notes="A consumer of consumers: it re-derives nothing and carries each item's rule from its source product. "
               "Special-category items appear only as the DP-322 flag. Lever: advisor of record from 03 coverage (45 SME 10)."),
    # =========================================== 46 Managed Portfolios & Rebalancing ===========================================
    dict(id="DP-341", name="Drift & Rebalance Monitor", tier="Consumer-aligned", type="Operational", domain="46",
         owner_role=R_MAO, primary="FN-63", supporting=["FN-61", "FN-60", "FN-64"], wave=W,
         definition="Every managed account's drift against its target: the latest assessment and asset-class lines, the "
                    "tolerance and override lines in force, the trigger rule that applies, and the rebalance decision taken "
                    "or deferred. Managed account operations works the accounts outside tolerance and evidences that each was "
                    "rebalanced or deferred for a recorded reason.",
         objects=[("46", "Drift Assessment"), ("46", "Drift Assessment Line"), ("46", "Managed Account Target"),
                  ("46", "Account Target Override Line"), ("46", "Rebalance Trigger Rule"), ("46", "Account Rebalance Event"),
                  ("46", "Model Assignment"), ("46", "Sleeve Assignment"), ("49", "Client Holding Valuation")],
         upstream=[MAM, CHL, ACC, OFR],
         notes="Acceptance question 4 (first half): accounts with Tolerance Breached Indicator = Y on the latest Drift "
               "Assessment. Holdings book: Client Holding (49), never Portfolio Holding (CW-007). Lever: drift daily versus "
               "on event (46 SME 6)."),
    dict(id="DP-342", name="Rebalance & Tax-Loss Harvest Effectiveness", tier="Consumer-aligned", type="Analytical",
         domain="46", owner_role=R_MAO, primary="FN-63", supporting=["FN-61", "FN-60", "FN-31", "FN-72"], wave=W,
         definition="What rebalancing and tax management achieved: losses harvested and estimated tax saved, gains realized "
                    "against each account's tax budget, harvests skipped and why, asset location placements, and drift "
                    "reduction after rebalances, by program, model and household. It answers what tax-loss harvesting saved "
                    "clients and whether tax management is worth its trading.",
         objects=[("46", "Tax-Loss Harvest Decision"), ("46", "Account Tax Budget"), ("46", "Tax Management Setting"),
                  ("46", "Asset Location Decision"), ("46", "Account Rebalance Event"), ("46", "Household Managed Group"),
                  ("46", "Model Change Implementation"), ("49", "Client Lot Relief"), ("49", "Client Tax Lot"),
                  ("02", "Investor Profile")],
         upstream=[MAM, CHL, PTY, RET],
         notes="Plan 8.3 example; acceptance question 4 (second half): Estimated Tax Saving = harvested loss x the 02 Federal "
               "Marginal Tax Rate (Derived copy) or a flat rate (46 SME 7). Holdings book: Client Tax Lot and Client Lot "
               "Relief (49). Returns are read from DP-145, never computed. PII: Confidential - Personal Data."),
    dict(id="DP-343", name="Wash-Sale Control & Household Tax Coordination", tier="Consumer-aligned",
         type="Regulatory & Control", domain="46", owner_role=R_MAO, primary="FN-63", supporting=["FN-65", "FN-64", "FN-68"], wave=W,
         definition="Open and closed wash-sale control windows by household and substantially identical security group, the "
                    "controlled and monitored accounts in scope, purchases that fell inside a window and the basis "
                    "adjustments they caused. Operations evidences that managed accounts were blocked and self-directed "
                    "accounts flagged as the program promises.",
         objects=[("46", "Wash Sale Control Window"), ("46", "Substantially Identical Security Group"),
                  ("46", "Household Managed Group"), ("49", "Cost Basis Adjustment"), ("49", "Client Lot Relief"),
                  ("48", "Client Execution")],
         upstream=[MAM, CHL, ORD, SEC],
         notes="Levers: window scope (46 SME 3) and substantially identical policy (46 SME 4). PII: Confidential - Personal Data."),
    dict(id="DP-344", name="Trade Proposals, Cash Raises & Pre-Trade Exceptions", tier="Consumer-aligned", type="Operational",
         domain="46", owner_role=R_MAO, primary="FN-63", supporting=["FN-64", "FN-71", "FN-66"], wave=W,
         definition="Each trade proposal batch from generation to release: proposal lines, lot selections, pre-trade check "
                    "exceptions and their outcomes, the client orders or participant investment transfers released, and the "
                    "managed account cash instructions (withdrawals, contributions, fee raises) the proposals fund. "
                    "Implementation analysts clear exceptions before the release window.",
         objects=[("46", "Trade Proposal Batch"), ("46", "Trade Proposal"), ("46", "Proposed Client Lot Selection"),
                  ("46", "Trade Proposal Exception"), ("46", "Managed Account Cash Instruction"), ("48", "Client Order"),
                  ("16", "Participant Investment Transfer"), ("50", "Money Movement")],
         upstream=[MAM, ORD, CHL, MMV],
         notes="Proposals are 46, orders 48 (CW-010 boundary). Lever: WR proposals as 16 transfers (46 SME 10)."),
    dict(id="DP-345", name="Managed Account Assets, Models & Composites", tier="Consumer-aligned", type="Analytical",
         domain="46", owner_role=R_MAO, primary="FN-63", supporting=["FN-31", "FN-78", "FN-33", "FN-77"], wave=W,
         definition="Managed accounts and their market value by program, model, discretion and regulatory AUM classification, "
                    "model adoption and changes, and composite membership with exclusions. It publishes the managed-account "
                    "slice of Firm AUM that the Firm AUM product and the Client Assets reconciliation read.",
         objects=[("46", "Model Assignment"), ("46", "Sleeve Assignment"), ("46", "Managed Account Composite"),
                  ("46", "Managed Account Composite Membership"), ("01", "Model Portfolio"), ("01", "Service Offering"),
                  ("49", "Client Holding Valuation")],
         upstream=[MAM, CHL, OFR],
         notes="Certified: the managed-account (advisory) slice of Firm AUM, owner Head of Managed Account Operations "
               "(CW-011). Ruling needed (CW-212): publish it here, or in the framing foundational Managed Account Model "
               "Assignments so the Firm AUM product can stay foundational. Holdings book: Client Holding Valuation (49). "
               "Lever: GIPS presentation of composites (46 SME 8)."),
    # ============================================== 47 Pricing, Fees & Billing ==============================================
    dict(id="DP-346", name="Fee Billing Accuracy & Custody-Rule Evidence", tier="Consumer-aligned", type="Regulatory & Control",
         domain="47", owner_role=R_PB, primary="FN-72", supporting=["FN-68", "FN-44", "FN-38", "FN-63"], wave=W,
         definition="Every fee calculation run re-performed: run reconciliation status, calculation exceptions, accounts billed "
                    "at a rate other than their assigned schedule, tier and household breakpoint, exclusions and waivers "
                    "applied, debits posted against calculations, and for each debited account the deduction authorization, "
                    "custody-rule basis and fee disclosures in force. Billing operations and compliance use it to answer the "
                    "SEC fee-billing risk alert findings and to evidence Rule 206(4)-2 conditions.",
         objects=[("47", "Fee Calculation Run"), ("47", "Account Fee Calculation"), ("47", "Billable Asset Exclusion"),
                  ("47", "Fee Calculation Exception"), ("47", "Fee Schedule Assignment"), ("47", "Fee Schedule"),
                  ("47", "Fee Schedule Tier"), ("47", "Fee Household"), ("47", "Fee Household Membership"),
                  ("47", "Fee Debit"), ("47", "Fee Deduction Authorization"), ("47", "Fee Disclosure Delivery"),
                  ("15", "Program Enrollment"), ("15", "Account Agreement"), ("38", "Adviser Custody Profile"),
                  ("38", "Custody Surprise Examination"), ("49", "Client Holding Valuation")],
         upstream=[FSB, ACC, CHL, CFR, REF],
         notes="Plan 8.3 example; acceptance question 8: Failed Run = Fee Reconciliation Status not reconciled on the run; "
               "Off-Schedule Flag = Effective Annual Rate differs from the rate re-performed from the assigned Fee Schedule "
               "version, tiers, Fee Household Assets and active overrides and waivers. Billed fees are operational; client "
               "fee revenue is certified in the DP-012 re-scope and tied here by run (CW-214). Holdings book: Client Holding "
               "Valuation (49) for broker-dealer accounts. PII: Confidential - Personal Data at account grain."),
    dict(id="DP-347", name="Fee Waivers, Adjustments & Billing Disputes", tier="Consumer-aligned", type="Operational",
         domain="47", owner_role=R_PB, primary="FN-72", supporting=["FN-67", "FN-68", "FN-38"], wave=W,
         definition="Fee waivers granted (reason, extent, approver, period), fee adjustments and refunds after billing, and "
                    "billing disputes with the complaints they became, with the cost of each to the firm. Billing operations "
                    "works open disputes and refunds; pricing and finance see what concessions and errors cost.",
         objects=[("47", "Fee Waiver"), ("47", "Fee Adjustment"), ("47", "Billing Dispute"), ("47", "Fee Rate Override"),
                  ("08", "Complaint"), ("49", "Client Account Activity")],
         upstream=[FSB, ACC, CFR, EMP],
         notes="Waivers here are client fee waivers, not fund expense waivers (CW-055). PII: Confidential - Personal Data."),
    dict(id="DP-348", name="Client Pricing Realization & Breakpoints", tier="Consumer-aligned", type="Analytical",
         domain="47", owner_role=R_PB, primary="FN-72", supporting=["FN-78", "FN-38", "FN-73"], wave=W,
         definition="List price against realized price: effective annual rates by offering, tier and household size, the value "
                    "of breakpoints, discount rules, negotiated overrides and own-fund offsets, and pricing scenarios tested. "
                    "Pricing and offering management use it to set schedules and to find leakage.",
         objects=[("47", "Fee Schedule"), ("47", "Fee Schedule Tier"), ("47", "Fee Discount Rule"), ("47", "Fee Rate Override"),
                  ("47", "Fee Schedule Assignment"), ("47", "Account Fee Calculation"), ("47", "Performance Fee Terms"),
                  ("01", "Offering Fee Schedule Link"), ("01", "Service Offering"), ("10", "Pricing Scenario")],
         upstream=[FSB, OFR, CFR],
         notes="Revenue figures come from the DP-012 re-scope (CW-011, CW-214). Lever: own-fund treatment (47 SME 4); "
               "breakpoints on billable or total household assets (47 SME 12). PII: aggregates Internal."),
    dict(id="DP-349", name="Brokerage Commissions & Account Service Charges", tier="Consumer-aligned", type="Regulatory & Control",
         domain="47", owner_role=R_PB, primary="FN-72", supporting=["FN-64", "FN-66", "FN-65", "FN-68"], wave=W,
         definition="Commissions and transaction charges applied to client executions and event-based service charges (wires, "
                    "transfers out, paper statements) checked against the schedule in force, with the remuneration disclosed "
                    "on the confirmation. Billing and brokerage operations clear mischarges and evidence Rule 10b-10 "
                    "disclosure of what was charged.",
         objects=[("47", "Commission & Transaction Charge Rate"), ("47", "Account Service Fee Item"), ("47", "Fee Debit"),
                  ("48", "Client Execution"), ("48", "Client Trade Confirmation"), ("48", "Confirmation Remuneration Disclosure"),
                  ("50", "Money Movement"), ("49", "Account Transfer")],
         upstream=[FSB, ORD, MMV, CHL],
         notes="Lever: commission-free trading by channel (47 SME 5). PII: Confidential - Personal Data at account grain."),
    dict(id="DP-350", name="Fee Invoicing, Mandate Billing & Performance Fees", tier="Consumer-aligned", type="Operational",
         domain="47", owner_role=R_PB, primary="FN-72", supporting=["FN-75", "FN-38", "FN-60"], wave=W,
         definition="Invoiced fees: institutional mandate billing arrangements with their schedules, qualified-client "
                    "determinations and performance fee calculations, and invoices for planning-only engagements, with "
                    "payment status from receivables. Billing operations and institutional service track what was invoiced, "
                    "paid and disputed.",
         objects=[("47", "Billing Arrangement"), ("47", "Performance Fee Calculation"), ("47", "Performance Fee Terms"),
                  ("47", "Fee Invoice"), ("47", "Billing Dispute"), ("12", "Institutional Client"), ("01", "Investment Mandate"),
                  ("18", "Holding Valuation"), ("32", "Performance Return"), ("19", "Receivable Item")],
         upstream=[FSB, "DP-140", RET, CFR, "DP-190"],
         notes="Proposed successor of DP-067 Institutional Fee Billing & Revenue Leakage (owner 12, pending) because the "
               "billing family moved to 47 (CW-054, CW-216); the 12 brief dispositions DP-067. Holdings book: Portfolio "
               "Holding valuations (18) for mandates. Payment Status is a Derived copy of 19 (CD-158)."),
    # ============================================== 51 Trust & Estate Services ==============================================
    dict(id="DP-351", name="Fiduciary Account Review Compliance", tier="Consumer-aligned", type="Regulatory & Control",
         domain="51", owner_role=R_TR, primary="FN-69", supporting=["FN-68", "FN-63", "FN-44"], wave=W,
         definition="Every fiduciary account review 12 CFR 9.6 requires (pre-acceptance, initial post-acceptance, annual) with "
                    "due and completed dates, exceptions raised and cleared, and the trust's terms, roles and investment "
                    "constraints reviewed. Trust management and the trust committee track overdue reviews and open exceptions.",
         objects=[("51", "Fiduciary Account Review"), ("51", "Fiduciary Review Exception"), ("51", "Trust"),
                  ("51", "Trust Role"), ("51", "Trust Term Provision"), ("51", "Trust Instrument Document"),
                  ("46", "Account Investment Constraint"), ("46", "Model Assignment")],
         upstream=[TFR, MAM, EMP],
         notes="Optional TR line (plan 15 item 2): the 51 products drop with the domain. Lever: post-acceptance deadline "
               "(51 SME 5). PII: Confidential - Personal Data."),
    dict(id="DP-352", name="Discretionary Distribution Decisions", tier="Consumer-aligned", type="Regulatory & Control",
         domain="51", owner_role=R_TR, primary="FN-69", supporting=["FN-66", "FN-68"], wave=W,
         definition="Each discretionary distribution request with the beneficiary's interest, the distribution standard of the "
                    "governing provision, the decision, approver and delegated limit, and the payment that followed. Trust "
                    "officers work open requests; the trust committee sees decisions above limits and the standard cited.",
         objects=[("51", "Trust Distribution Request"), ("51", "Distribution Decision"), ("51", "Beneficial Interest"),
                  ("51", "Trust Term Provision"), ("51", "Trust Role"), ("50", "Money Movement")],
         upstream=[TFR, MMV, EMP],
         notes="Special category (CD-344): special-needs and medical purposes are in a restricted view; the default view "
               "carries the coded purpose only (51 SME 8). Lever: decision authority (51 SME 4)."),
    dict(id="DP-353", name="Trust Principal & Income Accounting", tier="Consumer-aligned", type="Operational", domain="51",
         owner_role=R_TR, primary="FN-69", supporting=["FN-65", "FN-72"], wave=W,
         definition="Principal and income allocation of every receipt and disbursement in trust accounts, the fiduciary "
                    "accounting statement for each period, and unallocated activity and principal and income cash that do not "
                    "agree to the 49 cash balance. Trust accounting closes periods and produces beneficiary accountings from it.",
         objects=[("51", "Principal and Income Allocation"), ("51", "Fiduciary Accounting Statement"), ("51", "Trust"),
                  ("49", "Client Account Activity"), ("49", "Account Cash Balance"), ("47", "Fee Debit")],
         upstream=[TFR, CHL, FSB],
         notes="Trustee fees are 47; 51 allocates their character (51 Source_Notes). Lever: principal and income act per "
               "trust or firm-wide (51 SME 3); outsourced trust accounting keeps the statement only."),
    dict(id="DP-354", name="Estate Settlement Case Tracker", tier="Consumer-aligned", type="Operational", domain="51",
         owner_role=R_TR, primary="FN-69", supporting=["FN-67", "FN-62"], wave=W,
         definition="Each estate the firm acts for, from death notification through settlement: the firm's estate role, "
                    "milestones and tasks, the accounts restricted and re-registered, and the beneficiaries paid. Estate "
                    "specialists track aging cases and service sees the status when heirs call.",
         objects=[("51", "Estate Settlement Case"), ("51", "Estate Settlement Task"), ("02", "Death Notification"),
                  ("13", "Transfer of Ownership & Estate"), ("15", "Account Restriction"), ("15", "Beneficiary Designation")],
         upstream=[TFR, PTY, ACC],
         notes="One fact each: 02 notification, 13 ownership transfer request, 51 estate case (CW-077). Lever: executor or "
               "agent only (51 SME 6)."),
    dict(id="DP-355", name="Fiduciary Tax Filing & K-1 Status", tier="Consumer-aligned", type="Regulatory & Control",
         domain="51", owner_role=R_TR, primary="FN-69", supporting=["FN-39", "FN-67"], wave=W,
         definition="Each trust and estate's Form 1041 for the tax year: filing status and dates, distributable net income, and "
                    "the K-1 allocations to beneficiaries with the tax forms delivered. Fiduciary tax tracks filings due and "
                    "K-1s not delivered.",
         objects=[("51", "Fiduciary Tax Return"), ("51", "Beneficiary Tax Allocation"), ("51", "Trust"),
                  ("51", "Estate Settlement Case"), ("13", "Tax Form Record")],
         upstream=[TFR, PTY],
         notes="Preparation outsourced by default; 51 holds the filing facts (51 SME 7). Filer EIN is published; beneficiary "
               "TINs are not. PII: Restricted - Personal Data."),
]

# Re-scoped pending products (their ids are kept; candidate_coverage.py rejects ids that collide with existing products, so the
# re-scoped definitions are given here, not in CANDIDATES).
RESCOPED = [
    dict(id="DP-077", name="Client Eligibility, KYC & Restrictions Status", tier="Consumer-aligned", type="Regulatory & Control",
         domain="02", owner_role=R_ONB, primary="FN-62", supporting=["FN-68", "FN-44", "FN-76", "FN-61", "FN-63", "FN-66"],
         wave=W,
         definition="One current eligibility status per client and account, reduced from the KYC profile, CIP identity "
                    "verification, beneficial ownership certification, tax status and Reg BI classification, every active "
                    "client restriction and restricted-client status, account restrictions and new issue eligibility. "
                    "Marketing, advice, managed accounts and money movement read the status and reason instead of "
                    "re-deriving restrictions; compliance uses it to evidence that due diligence is current.",
         objects=[("02", "Party"), ("02", "Organization"), ("02", "KYC Profile"), ("02", "Identity Verification"),
                  ("02", "Beneficial Ownership Certification"), ("02", "Beneficial Ownership"), ("02", "Tax Profile"),
                  ("02", "Regulatory Classification"), ("02", "Client Restriction"), ("02", "Restricted Client Status"),
                  ("15", "Account"), ("15", "Account Party Role"), ("15", "Account Restriction"), ("15", "New Issue Eligibility")],
         upstream=[PTY, ACC, REF],
         notes="Re-scope (CW-210): the 08 distributor due diligence inputs leave (the distributor firm is a 05 role; the 05 "
               "brief owns any distributor eligibility); EU/UK regimes (CRS, EU AMLD, UK MLRs, OFSI) removed (US only); "
               "FinCEN CDD prongs on Beneficial Ownership. Keeping the id keeps the four live dependents (DP-130, DP-161, DP-180, "
               "DP-226) pointing at it. PII: Restricted - Personal Data; "
               "consumers receive status, reason and restricted product scope only."),
    dict(id="DP-080", name="Consumer Privacy Rights & Opt-Out Evidence", tier="Consumer-aligned", type="Regulatory & Control",
         domain="02", owner_role=R_PRV, primary="FN-62", supporting=["FN-76", "FN-50", "FN-44"], wave=W,
         definition="The register of consumer privacy requests under state privacy laws (access, deletion, correction, opt-out "
                    "of sale or sharing) with their statutory deadlines and status, and the Regulation S-P and FCRA "
                    "affiliate-marketing opt-outs in force, joined to the consents, preferences, digital identities, leads and "
                    "suppression entries holding the same person's data. It evidences that requests were answered on time and "
                    "that opt-outs and deletions reached every record.",
         objects=[("02", "Consumer Privacy Request"), ("02", "Privacy Profile"), ("02", "Consent Record"),
                  ("02", "Communication Preference"), ("02", "Party"), ("04", "Web Visitor / Known User"),
                  ("04", "Marketing Lead"), ("04", "Suppression Entry"), ("21", "Retention Rule")],
         upstream=[PTY, REF],
         notes="Re-scope (CW-210): GDPR and UK GDPR removed (US only, CW-003); 02 Data Subject Request, Retention and "
               "Processing Legal Basis no longer exist; Consumer Privacy Request replaces the request register and the "
               "retention schedule is read from 21 Retention Rule. GLBA-covered data is exempt from most state laws: the "
               "product carries the exemption basis per request. Lever: state regimes in scope (02 SME 8)."),
]

DISPOSITIONS = [
    dict(id="DP-048", disposition="Retire", successor="", decision="CW-210",
         reason="Wholesale intermediary-advisor movement alerts (wirehouse breakaway). Its 02 objects moved to 05 (Financial "
                "Professional, Employment Affiliation, Distributor Firm, Team Membership, External Classification), UK & EU "
                "Regulatory Identifier was removed and 07 Party Territory Alignment retired. The intermediary channel is thin "
                "(CW-013); restoring the alert is the 05 depth lever, owned by the channel brief. Own-advisor departure risk "
                "belongs to the 03 brief's Advisor Capacity & Book Health."),
    dict(id="DP-066", disposition="Retire", successor="", decision="CW-210",
         reason="DCIO plan prospecting for the wholesale channel. Its plan objects moved to 16 (Plan Service Provider, "
                "Recordkeeper Profile) and 05 (Advisor Practice, Sales Opportunity); 03 Placement, Model & DCIO Detail and 07 "
                "Party Territory Alignment are gone. Prospecting plans for the recordkeeping business (WR) is a 05/16 "
                "question for the channel or workplace brief, not a 02 product."),
    dict(id="DP-077", disposition="Re-scope", successor="DP-077", decision="CW-210",
         reason="The purpose survives (one eligibility status from KYC and restrictions) and four live products (DP-130, DP-161, "
                "DP-180, DP-226) list it upstream, so the id is kept. New definition and objects in RESCOPED: wealth 02 KYC, CIP, beneficial "
                "ownership certification and Reg BI classification; 15 account restrictions and new issue eligibility; 08 "
                "distributor due diligence and the EU/UK regimes removed. Primary function FN-13 -> FN-62."),
    dict(id="DP-080", disposition="Re-scope", successor="DP-080", decision="CW-210",
         reason="Privacy-rights evidence is still needed for a direct firm, under US law: state consumer privacy requests "
                "(02 Consumer Privacy Request), Reg S-P and FCRA opt-outs (Privacy Profile). GDPR, UK GDPR and the removed 02 "
                "objects (Data Subject Request, Retention, Processing Legal Basis) leave; retention from 21 Retention Rule. "
                "Primary function FN-17 -> FN-62."),
]

DECISIONS = [
    {"id": "CW-210", "theme": "Data Products",
     "title": "WP0 disposition of the four 02-owned pending products: DP-048 and DP-066 retired, DP-077 and DP-080 re-scoped in place",
     "domains": ["02", "15", "05", "16", "04", "21"],
     "issue": "RESCOPE_PENDING holds four products owned by 02 (CW-041). Their inputs were removed or moved at W1 and W4.",
     "resolution": "Proposed: DP-048 Advisor Movement & Breakaway Alerts and DP-066 Retirement Plan Prospecting retire with "
                   "no CLA-A successor (intermediary depth and plan prospecting are 05/16 levers). DP-077 is re-scoped to "
                   "Client Eligibility, KYC & Restrictions Status and DP-080 to Consumer Privacy Rights & Opt-Out Evidence, "
                   "keeping their ids so live dependents stay pointed; functions FN-13 and FN-17 are replaced by FN-62.",
     "rationale": "Keep ids where the purpose survives and dependents exist; retire what only served the wholesale channel.",
     "action": "WP0 register; WP1 specs", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
    {"id": "CW-211", "theme": "Certified numbers",
     "title": "Household 360 and the client views own no certified number",
     "domains": ["02", "06", "32", "15"],
     "issue": "Household 360, Client Base Movement and Service Tier Qualification all show client assets, returns and counts.",
     "resolution": "Proposed: DP-320, DP-325 and DP-326 read Client Assets, Advised Assets and Net New Assets from the DP-008 "
                   "successor, Personal Rate of Return from DP-145, and Households, Clients and Accounts from DP-240 and "
                   "DP-093; they publish only decompositions that tie to those numbers. DP-243 Total Client Relationship "
                   "stays the institutional relationship view; Household 360 is the retail and household view.",
     "rationale": "CW-011: each certified number in one product.",
     "action": "WP1 specs", "status": "Proposed", "priority": "High", "owner_role": "Head of Client & Channel Analytics"},
    {"id": "CW-212", "theme": "Certified numbers",
     "title": "Where the managed-account slice of Firm AUM is published",
     "domains": ["46", "27", "49", "06"],
     "issue": "CW-011 makes the advisory slice of Firm AUM certified (owner Head of Managed Account Operations) but names no product.",
     "resolution": "Proposed: DP-345 Managed Account Assets, Models & Composites publishes it (Model Assignment Regulatory AUM "
                   "Classification x 49 Client Holding Valuation). Alternative for the lead: publish it in the framing "
                   "foundational Managed Account Model Assignments so a foundational Firm AUM product can read it; DP-345 "
                   "then consumes it.",
     "rationale": "One product per certified number; the choice depends on whether Firm AUM is assembled in a foundational product.",
     "action": "Program lead ruling at WP0", "status": "Proposed", "priority": "High", "owner_role": "Head of Managed Account Operations"},
    {"id": "CW-213", "theme": "Personal data",
     "title": "Special-category client facts reach CLA-A products only through the DP-322 restricted view",
     "domains": ["02", "08", "50", "51"],
     "issue": "Specified adult status, vulnerability concerns, holds and special-needs distribution purposes are special category (CD-344).",
     "resolution": "Proposed: DP-322 is the only CLA-A product that reads 02 Specified Adult Status and Vulnerability Concern "
                   "in detail (Restricted - Personal Data); DP-320, DP-340 and other consumers carry only its Protection Flag "
                   "Present indicator. DP-352 holds special-needs and medical purposes in a restricted view. The 50 brief's "
                   "holds product reads the same restricted view.",
     "rationale": "Aggregates or restricted views only for special-category data (plan section 11).",
     "action": "WP1 specs", "status": "Proposed", "priority": "High", "owner_role": "Privacy Officer"},
    {"id": "CW-214", "theme": "Certified numbers",
     "title": "Billed fees in 47 products are operational; client fee revenue is certified in the DP-012 re-scope",
     "domains": ["47", "10", "19"],
     "issue": "47 calculates Net Fee and debits; 10 recognizes client fee revenue. Pricing and billing products could publish a revenue figure.",
     "resolution": "Proposed: DP-346 to DP-350 publish billed, waived, adjusted and collected amounts as operational measures; "
                   "client fee revenue comes only from the DP-012 re-scope; DP-346 ties run totals (Run Net Fee Total) to it.",
     "rationale": "CW-012, CW-053: calculation in 47, revenue in 10.",
     "action": "WP1 specs", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Pricing & Billing"},
    {"id": "CW-215", "theme": "Conduct",
     "title": "Reg BI and fiduciary evidence products assemble 45 and 15 facts and read 08 outcomes; they never score best interest",
     "domains": ["45", "08", "15"],
     "issue": "DP-334, DP-335 and DP-328 sit next to 08 supervision products that test the same recommendations and disclosures.",
     "resolution": "Proposed: CLA-A products publish evidence completeness flags computed from 45 and 15 CDEs and carry the 08 "
                   "Supervisory Review outcome as recorded; the 08 brief's products own surveillance scores, alerts and the "
                   "PTE 2020-02 retrospective review.",
     "rationale": "Plan rule: evidence mastered in 45, supervised in 08; assembled, never re-scored.",
     "action": "WP1 specs", "status": "Proposed", "priority": "Medium", "owner_role": "Head of Retail Conduct"},
    {"id": "CW-216", "theme": "Data Products",
     "title": "DP-350 as successor of DP-067 Institutional Fee Billing & Revenue Leakage",
     "domains": ["47", "12", "10"],
     "issue": "DP-067 is owned by 12 and pending; its billing objects moved to 47 (CW-054).",
     "resolution": "Proposed: DP-067 is retired with DP-350 Fee Invoicing, Mandate Billing & Performance Fees as successor; "
                   "revenue leakage measures move to DP-348 and the DP-012 re-scope. If the 12 brief re-scopes DP-067 instead, "
                   "DP-350 is withdrawn and DP-067 is re-owned by 47.",
     "rationale": "The product follows the objects it reads.",
     "action": "Program lead to reconcile with the 12 brief", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]


# ---- WP1 scope (WP0 rationalization, 2026-10-15; Product_Briefs/WP1_Scope.md) ------------------------------
# Program-lead ruling: every candidate is flagged wp1=True (specified at WP1) or backlog=True (registered in
# framework.WAVE_BACKLOG, status 'backlog', not specified at WP1; ids unchanged). WP1_MERGES names the product a
# backlog candidate overlaps (its scope folds in there if it is picked up). WP1_MOVED_READS: objects with CDEs that
# only a backlog candidate read, now read by the named WP1 product (coverage rule; WP1 specs read them).
# Lead ruling 2026-10-15: DP-321 (Rule 4512) and DP-332 (Rule 3a-4) pulled back into WP1.
WP1_BACKLOG_IDS = ["DP-323", "DP-325", "DP-326", "DP-327", "DP-328", "DP-330", "DP-331", "DP-336", "DP-338", "DP-339", "DP-340", "DP-343", "DP-344", "DP-347", "DP-348"]
WP1_MERGES = {

    "DP-323": "DP-334",   # Investor Profile Currency & Suitability Inputs -> Plan Quality & Recommendation Evidence (Reg BI File)
    "DP-325": "DP-320",   # Service Tier Qualification & Client Segments -> Household 360
    "DP-326": "DP-490",   # Client Base Movement & Attrition -> Client Assets & Flows Executive Scorecard
    "DP-327": "DP-392",   # Account Opening & Good Order Pipeline -> Acquisition Funnel & Account Opening Conversion
    "DP-328": "DP-399",   # Account Features, Agreements & Disclosure Evidence -> Form CRS & Reg BI Disclosure Delivery Control
    "DP-330": "DP-417",   # Account Tax Certification & Cost Basis Election Status -> Client Tax Forms & Cost Basis Reporting
    "DP-331": None,   # Systematic Investment & Withdrawal Plans (stands alone)
    "DP-336": "DP-337",   # Advice Review Cadence & Plan Currency -> Goal Progress & Funded Status
    "DP-338": "DP-320",   # Held-Away Assets & Consolidation Opportunity -> Household 360
    "DP-339": "DP-385",   # Digital Advice Engine Outcomes & Oversight -> Advice Program Outcomes Evidence
    "DP-340": "DP-387",   # Advisor Client Action Worklist -> Advisor Capacity & Book Health
    "DP-343": "DP-342",   # Wash-Sale Control & Household Tax Coordination -> Rebalance & Tax-Loss Harvest Effectiveness
    "DP-344": "DP-341",   # Trade Proposals, Cash Raises & Pre-Trade Exceptions -> Drift & Rebalance Monitor
    "DP-347": "DP-346",   # Fee Waivers, Adjustments & Billing Disputes -> Fee Billing Accuracy & Custody-Rule Evidence
    "DP-348": "DP-349",   # Client Pricing Realization & Breakpoints -> Brokerage Commissions & Account Service Charges
}
WP1_MOVED_READS = {

    "DP-334": [('02', 'Investor Qualification', "DP-323")],
    "DP-337": [('45', 'Planning Assumption Set', "DP-336, DP-339")],
    "DP-320": [('45', 'Aggregated Account', "DP-338"), ('45', 'Aggregated Account Balance', "DP-338")],
    "DP-342": [('46', 'Substantially Identical Security Group', "DP-343"), ('46', 'Wash Sale Control Window', "DP-343")],
    "DP-341": [('46', 'Trade Proposal', "DP-344"), ('46', 'Proposed Client Lot Selection', "DP-344"), ('46', 'Trade Proposal Exception', "DP-344"), ('46', 'Managed Account Cash Instruction', "DP-344")],
    "DP-346": [('47', 'Fee Adjustment', "DP-347")],
    "DP-349": [('47', 'Fee Discount Rule', "DP-348")],
    "DP-329": [('16', 'Participant Distribution Election', "DP-470")],
}
for _c in list(CANDIDATES) + list(globals().get("RESCOPED", [])):
    _bl = _c["id"] in WP1_BACKLOG_IDS
    _c["wp1"], _c["backlog"] = not _bl, _bl
    if _bl:
        _t = WP1_MERGES.get(_c["id"])
        _c["merge_into"] = _t
        _c["notes"] = (_c.get("notes", "") + " Backlog (WP1_Scope.md): not specified at WP1"
                       + (f"; overlaps {_t}, into which its scope folds if it is picked up." if _t else "; stands alone."))
    for _o in WP1_MOVED_READS.get(_c["id"], []):
        if (_o[0], _o[1]) not in _c["objects"]:
            _c["objects"].append((_o[0], _o[1]))
            _c["notes"] = _c.get("notes", "") + f" WP1 scope: also reads {_o[0]} {_o[1]} (from backlog {_o[2]})."
