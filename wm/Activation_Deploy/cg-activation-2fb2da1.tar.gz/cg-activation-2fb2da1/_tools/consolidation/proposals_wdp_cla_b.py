"""WP0 product brief CLA-B: Offering, Conduct & Engagement (Client & Advice area; Data Domains 01, 36, 03, 04, 13, 08).

Brief: 00_Program/Rework/Product_Briefs/CLA_B_Offering_Conduct_and_Engagement.md (Wealth_Manager_Rework_Plan.md sections 8, 10).
Id block (framework.ID_BLOCKS "CLA-B"): DP-380 to DP-429, DP-381 to DP-418 used (38 candidates; DP-380 drafted and folded into DP-004 by
the WP0 framing ruling, CW-221; the id stays free). Decisions CW-220 to CW-229, all used, "Proposed".
Waves: "WP1F" and "WP1C" (framework.CANDIDATE_WAVES). candidate_coverage.py still checks the wholesale E1 to E5 codes at the
time of writing; brief section 7 records the run against a scratchpad copy that reads framework.CANDIDATE_WAVES.

CANDIDATES carry the candidate_coverage.py fields plus three brief fields the checker ignores: pii (posture), metrics
(certified metrics consumed and their owner product) and levers (tailoring levers that change the product).
DISPOSITIONS: one dict per pending product (framework.RESCOPE_PENDING) owned by 01, 36, 03, 04, 13 or 08 (38; 36 owns none):
id, disposition, successor, decision, reason. Disposition rule (WP0 lead, 2026-10-15): re-scope in place only when a live
product depends on the id after the WP1 re-points; otherwise the product is Superseded by a new id (here or in another
brief) and retired, or Retired with no successor.
RESCOPED: the seven pending products re-scoped in place, candidate-shaped with disposition "re-scope".
RESPEC: notes for the WP1 re-spec of the live products this group owns (36 and 01) and the recommendation for DP-004.
Framing foundational ids (proposals_wp0_framing): DP-300 Client Holdings, Lots & Cost Basis; DP-301 Client Orders &
Executions; DP-302 Money Movement Transactions; DP-303 Advice Plans & Recommendations; DP-304 Managed Account Model
Assignments; DP-305 Fee Schedules & Billing Runs; DP-306 Manager & Sub-Adviser Master; DP-004 Product, Offering & Share
Class Reference (offerings folded in); DP-008 Client Assets & Net New Assets; DP-012 Client Fee Revenue.
Semantic layer (framing ruling): the retail conduct products (DP-398 to DP-404, DP-414 to DP-416, DP-036, DP-038, DP-039,
DP-078) get their own semantic model SM-29 at WP2.
DP-008, DP-009, DP-010, DP-011 and DP-012 are named by id; the framing agent re-scopes them.
"""

_A = "DP-303"
_H = "DP-300"
_O = "DP-301"
_M = "DP-302"
_MA = "DP-304"
_F = "DP-305"
_MG = "DP-306"

_CA = "Client Assets, Net New Assets and Advised Assets by advisor of record, offering and channel (DP-008 successor; CW-011, CW-142)"
_HH = "Households, Clients and Accounts (DP-240, DP-093; CW-011)"
_PRR = "Personal Rate of Return (DP-145 extended; CW-129)"
_REV = "Client fee revenue (DP-012 re-scoped)"

F, C = "Foundational", "Consumer-aligned"
MR, CF, AN, OP, RC = "Master & Reference", "Conformed Facts", "Analytical", "Operational", "Regulatory & Control"


def _c(id, name, tier, type, domain, owner_role, primary, supporting, definition, objects, upstream, notes, pii,
       metrics=(), levers="None specific."):
    return dict(id=id, name=name, tier=tier, type=type, domain=domain, owner_role=owner_role, primary=primary,
                supporting=list(supporting), wave="WP1F" if tier == F else "WP1C", definition=definition,
                objects=list(objects), upstream=list(upstream), notes=notes, pii=pii, metrics=list(metrics), levers=levers)


CANDIDATES = [
    _c("DP-381", "Client Service Interactions & Requests", F, CF, "13", "Head of Client Service", "FN-67",
       ["FN-62", "FN-68", "FN-61", "FN-65", "FN-66", "FN-77", "FN-38", "FN-71"],
       "Every service request and every phone, chat and secure-message interaction for every account type, with request "
       "controls, maintenance and ownership-transfer detail, the authentication of each interaction and the QA review "
       "sample. It is the one service fact that contact center, complaint, fraud, cost-to-serve and voice-of-client "
       "products read, keyed SRQ- and to the 02 party and 15 account.",
       [("13", "Service Request"), ("13", "Request Controls"), ("13", "Account Maintenance Change"),
        ("13", "Transfer of Ownership & Estate"), ("13", "Contact Center Interaction"),
        ("13", "Interaction Authentication"), ("13", "QA Review")],
       ["DP-240", "DP-093", "DP-009", "DP-192", "DP-013"],
       "Master concepts: Service Request (13, SRQ-; row proposed with CW-222) and Interaction Authentication (13). "
       "Complaints are referenced, never copied (CW-070); authentication publishes method, result and step-up only, never "
       "secrets (CW-086). Outsourced contact center: same grain, received from the provider. DP-498 (DIS+FDN cost to serve) "
       "and DP-320 (CLA-A Household 360) read service facts from here.",
       "Y: Confidential - Personal Data; free-text notes in a restricted view; deceased and vulnerability flags are "
       "references only (CD-344).",
       [_HH], "13 SME 1 (participant requests in 16 for a recordkeeper with its own case tool), SME 8."),
    _c("DP-382", "Client Document & Delivery Record", F, CF, "13", "Head of Client Communications", "FN-67",
       ["FN-68", "FN-62", "FN-64", "FN-72", "FN-35", "FN-37", "FN-76"],
       "Every statement, confirmation delivery, tax document, regulatory communication and notice produced for a client or "
       "shareholder, with its distribution, the recipient-level delivery record (method, date, returned mail), the "
       "e-delivery election and the mailing household in force. It is the delivery evidence that disclosure, statement, "
       "proxy and tax products cite instead of each rebuilding it.",
       [("13", "Investor Document Definition"), ("13", "Investor Document"), ("13", "Confirmation Delivery"),
        ("13", "Production Run"), ("13", "Shareholder Communication"), ("13", "Communication Distribution"),
        ("13", "Recipient Delivery Record"), ("13", "E-Delivery Election"), ("13", "Householding Group"),
        ("13", "Mail Hold")],
       ["DP-240", "DP-093", "DP-004", "DP-013"],
       "Master concepts: Shareholder Communication (13, COMM-), Confirmation Delivery (13), Investor Document (row proposed "
       "with CW-223). 13 masters delivery; 48 the confirmation (CW-081, CW-098); 47 fee disclosures delivered (CW-056); 15 "
       "opening disclosures (CW-087). The mailing household is not the 02 or 47 household (CW-027). Replaces DP-069 as "
       "DP-106's upstream (RESPEC).",
       "Y: Confidential - Personal Data (names, postal and email addresses).",
       [_HH], "13 SME 5 (household statements), SME 6 (annual privacy notice), SME 7 (returned mail in a CRM)."),
    _c("DP-383", "Platform Shelf, Availability & Due Diligence Status", C, RC, "01", "Head of Brokerage Products", "FN-78",
       ["FN-70", "FN-64", "FN-68", "FN-60", "FN-63"],
       "Which own and third-party products are available on the brokerage platform and in advice models, for which "
       "offerings and account types, against the tradable universe policy and the 52 due diligence approval behind each "
       "third-party product. Brokerage product managers and manager research see products offered without a current "
       "approval, approvals on watch and availability changes coming into effect.",
       [("01", "Platform Product Availability"), ("01", "Tradable Universe Policy Rule"), ("01", "Platform Feature"),
        ("52", "Product Due Diligence"), ("52", "Product Due Diligence Criterion Result")],
       ["DP-004", "DP-097", _MG],
       "Supersedes the go-to-market part of DP-058. Availability 01, approval 52, instrument eligibility flags 17 "
       "(DP-516, DIS+FDN), order-time checks 48 (CW-037, CW-099, CW-120); the product reports gaps and never re-decides "
       "eligibility. Third-party platforms' shelves are DP-484 (05).",
       "N", levers="01 SME 4 (open platform drops the due diligence join); 52 dropped for a firm without third-party "
       "products (CW-014)."),
    _c("DP-384", "Advice Service & Platform Feature Development Pipeline", C, OP, "36", "Head of Product Development",
       "FN-37", ["FN-78", "FN-61", "FN-51", "FN-72", "FN-68", "FN-63"],
       "Every advice program, service tier and platform feature in development or change, with its specification, scope, "
       "impact assessment and each regulatory requirement (Form ADV and Form CRS amendments, advance fee notices, agreement "
       "amendments) against its due date. Product, technology, billing and compliance plan each launch or change from one "
       "calendar.",
       [("36", "Service Offering Specification"), ("36", "Platform Feature Specification"),
        ("36", "Product Change Initiative"), ("36", "Changed Product Scope"), ("36", "Change Impact Assessment"),
        ("36", "Change Regulatory Requirement")],
       ["DP-004", "DP-106", "DP-211", "DP-192", "DP-013"],
       "The fund side of the calendar stays DP-106; this is its advice and platform counterpart (CW-161). Proposed values "
       "are 36 until the effective date, then DP-004 (CD-236).",
       "N", levers="36 SME 1 (separate advice program committee), SME 2 (features under 41 change management only), "
       "SME 4 (negative-consent amendments)."),
    _c("DP-385", "Advice Program Outcomes Evidence", C, RC, "36", "Head of Product Governance", "FN-37",
       ["FN-78", "FN-63", "FN-68", "FN-60", "FN-31"],
       "The client-outcome evidence for each Advice Program Review: drift and rebalancing outcomes, personal returns "
       "against the program's models, fees, complaints and net new assets by program, with the review's criterion results "
       "and actions. Product governance concludes whether each program still serves the clients enrolled in it and "
       "records what it will change.",
       [("36", "Product Review"), ("36", "Product Review Criterion Result"), ("36", "Review Action"),
        ("01", "Product Governance"), ("46", "Drift Assessment"), ("32", "Personal Rate of Return"), ("08", "Complaint")],
       ["DP-109", "DP-004", "DP-145", "DP-008", "DP-012", _MA],
       "DP-109 stays the review register for funds and programs; this product assembles program evidence for it (36 SME "
       "3). Returns from DP-145 extended (CW-129) and complaint counts are read, never recomputed or reclassified.",
       "Y in the account drill (restricted); published at program and cohort grain.",
       [_CA, _PRR, _REV], "36 SME 3 (risk-based cycles), SME 7 (criterion rating scale)."),
    _c("DP-386", "Product Documents & Commentary Currency", C, RC, "01", "Head of Product", "FN-78",
       ["FN-68", "FN-31", "FN-37", "FN-76"],
       "Every product document and investment commentary by fund, program and model, with its version, approval and the "
       "compliance review behind it, measured for currency against its due date. Product teams see stale documents and "
       "commentary still published, and compliance sees any that went out unapproved.",
       [("01", "Product Document"), ("01", "Investment Commentary"), ("01", "Commentary Approval"),
        ("08", "Compliance Review"), ("08", "Compliance Approval")],
       ["DP-004", "DP-013"],
       "Commentary is 01; the approval decision is 08 (CW-073). No live or pending product read Investment Commentary.",
       "Y: author and approver names only.", levers="Drops for a firm that publishes no commentary."),
    _c("DP-387", "Advisor Capacity & Book Health", C, AN, "03", "Head of Advisor Workforce", "FN-73",
       ["FN-60", "FN-77", "FN-68", "FN-67", "FN-41"],
       "Each advisor's and team's book against capacity: households and assets by offering and tier, capacity used, review "
       "completion, service demand, growth, attrition, and credentials, and the profile of the book (tier mix, "
       "complex and protected households as counts). Practice managers decide hiring, book rebalancing and which advisors "
       "take new clients.",
       [("03", "Advisor Capacity Snapshot"), ("03", "Party Coverage Assignment"), ("03", "Coverage Model"),
        ("03", "Advisor"), ("03", "Advisor Credential"), ("45", "Advice Review")],
       ["DP-009", "DP-008", "DP-093", "DP-240", "DP-381", _A],
       "Plan section 8.3 example. Assets and net new assets by advisor of record from the DP-008 successor (CW-063, CW-143, "
       "CW-226); DP-491 (DIS+FDN) publishes NNA by advisor and this product reads it. Own-advisor departure risk (from "
       "DP-048's retirement, CLA-A) is a measure here.",
       "Y: advisor identity and household keys (Confidential - Personal Data); aggregates for leadership; protected "
       "households only as a count (CD-344).",
       [_CA, _HH], "03 SME 2 (pooled teams), SME 3 (household or client grain)."),
    _c("DP-388", "Client Reassignment & Retention", C, OP, "03", "Head of Advisor Workforce", "FN-73",
       ["FN-77", "FN-67", "FN-60"],
       "Every reassignment of households from one advisor or team to another (departure, rebalancing, tier change), with "
       "the households moved, the notice given and the assets and households retained 90 and 365 days later. Practice "
       "managers run reassignments and learn which approaches keep clients.",
       [("03", "Coverage Reassignment"), ("03", "Coverage Reassignment Item"), ("03", "Party Coverage Assignment")],
       ["DP-009", "DP-008", "DP-381", "DP-240"],
       "Retention on the DP-008 successor's Client Assets and Net New Assets by household (CW-226).",
       "Y: household keys and advisor names.", [_CA, _HH], "03 SME 1 (independent contractors)."),
    _c("DP-389", "Advisor Contact Cadence & Coverage Standards", C, OP, "03", "Head of Advisor Workforce", "FN-73",
       ["FN-60", "FN-61", "FN-67"],
       "For each advisor and team, the households due a contact under the coverage model's call frequency standard, "
       "contacts made by type and channel, households overdue and the outcomes and follow-ups recorded. Practice managers "
       "see contact standards kept or missed and where pooled coverage is overloaded.",
       [("03", "Advisor Activity"), ("03", "Outcome & Follow-Up"), ("03", "Call Frequency Standard"),
        ("03", "Coverage Model"), ("04", "Nudge Delivery")],
       ["DP-010", "DP-009", "DP-011", "DP-381"],
       "The advisor's action list itself is DP-340 Advisor Client Action Worklist (CLA-A), which may read this product's "
       "overdue-contact items. Supersedes nothing directly: DP-046 goes to DP-340, DP-053 retires (DISPOSITIONS).",
       "Y: household keys and contact context; vulnerability shown only as the DP-322 flag (CLA-A, CD-344).",
       [_HH], "03 SME 2 (pooled coverage at team grain)."),
    _c("DP-390", "Incentive Plan Governance & Advisor Payouts", C, RC, "03", "Head of Sales Compensation", "FN-73",
       ["FN-68", "FN-41", "FN-38", "FN-44"],
       "Each advisor incentive plan and component with the Reg BI incentive conflict review behind it, every participant, the "
       "compensation statement and earnings lines per period and recognition awards. Compensation and conduct see which "
       "components lack a current review, which measures could favor a product, and what was paid on each component.",
       [("03", "Incentive Compensation Plan"), ("03", "Incentive Plan Component"), ("03", "Incentive Plan Participation"),
        ("03", "Compensation Statement"), ("03", "Incentive Earnings Line"), ("03", "Recognition Award"),
        ("08", "Incentive Conflict Review"), ("20", "Variable Compensation Award")],
       ["DP-009", "DP-192", "DP-198", "DP-008", "DP-012"],
       "Incentives in reduced form in 03, pay in 20, the Reg BI review in 08 (CW-064, CW-168); FOP+CORP withdrew its DP-597 "
       "in favor of this product and re-points DP-198's 07 upstream here. Successor of the 07 compensation products DP-032, "
       "DP-033 and DP-082 (07-owned; recommended to the framing agent). Asset-based measures take DP-008 values (CW-226); "
       "certified pay stays DP-198.",
       "Y: individual compensation (Confidential - Compensation); restricted to compensation, HR and compliance.",
       [_CA, _REV, "Pay (DP-198)"], "03 SME 5 (allowed incentive measures), SME 6 (referral incentives)."),
    _c("DP-391", "Supervisory Structure & Principal Coverage", C, RC, "03", "Head of Retail Supervision", "FN-68",
       ["FN-73", "FN-44", "FN-41"],
       "The branch, OSJ and supervisory hierarchy with each principal's designations and the representatives assigned to "
       "each supervisor, matched to Form BR branch registrations and the supervisors' own registrations. Supervision sees "
       "representatives without a qualified supervisor, branches without a registration and principals over their span.",
       [("03", "Firm Branch Office"), ("03", "Supervisory Hierarchy Link"), ("03", "Principal Designation"),
        ("03", "Supervisory Assignment"), ("08", "Branch Registration"), ("08", "Individual Registration")],
       ["DP-009", "DP-192", "DP-013"],
       "FINRA Rule 3110(a) and (b); structure 03, registrations 08 (CW-061, CW-072).",
       "Y: representative and principal names.", levers="03 SME 8 (remote-only firm keeps the home-office OSJ only)."),
    _c("DP-393", "Channel Referrals & Advice Hand-Offs", C, AN, "03", "Head of Advisor Workforce", "FN-73",
       ["FN-71", "FN-60", "FN-61", "FN-76", "FN-77"],
       "Every internal hand-off of a client between channels (digital to human advice, service to advisor, workplace "
       "participant to the retail business, trust referrals) from referral through acceptance to the resulting advice "
       "engagement and assets. Channel leaders see conversion and leakage at each hand-off.",
       [("03", "Channel Referral"), ("03", "Referral Status History"), ("16", "Participant Retail Hand-Off"),
        ("45", "Advice Engagement")],
       ["DP-009", "DP-240", "DP-094", "DP-008", _A],
       "Channel referrals are 03, client-to-friend referrals 04 (CW-065, CW-092). DP-333 (CLA-A) counts referrals entering "
       "the advice funnel; this product covers every hand-off and its leakage. The rollover capture rate (acceptance "
       "question 10) is the workplace brief's.",
       "Y: client and participant keys.", [_CA, _HH], "03 SME 6, SME 7."),
    _c("DP-392", "Acquisition Funnel & Account Opening Conversion", C, AN, "04", "Head of Marketing", "FN-76",
       ["FN-61", "FN-62", "FN-77", "FN-38"],
       "The acquisition funnel from visitor and lead through application start, submission, account opening and funding, "
       "with abandonment by journey step, time between milestones and conversion by campaign, channel and offering. "
       "Marketing and digital decide spend, journey fixes and lead routing to digital or human advice.",
       [("04", "Marketing Lead"), ("04", "Lead Qualification"), ("04", "Lead Assignment"), ("04", "Lead Conversion"),
        ("04", "Application Journey"), ("04", "Acquisition Milestone"), ("02", "Onboarding Case"),
        ("15", "Account Opening")],
       ["DP-011", "DP-240", "DP-093", "DP-008", "DP-004"],
       "The acquisition half of plan 8.3 'Advice Funnel & Conversion': it ends at account opening and funding (CW-083, "
       "CW-085); DP-333 (CLA-A) takes it from advice engagement to enrollment. Funded assets by campaign come from DP-492 "
       "(DIS+FDN) on the DP-008 successor (CW-227). Supersedes DP-027.",
       "Y: lead and applicant contact data as captured lineage (CW-083); aggregates for reporting.",
       [_CA, _HH], "04 SME 1 (identity threshold), SME 7 (attribution model)."),
    _c("DP-394", "Digital Engagement & Experiments", C, AN, "04", "Head of Digital", "FN-61",
       ["FN-76", "FN-50", "FN-67", "FN-51"],
       "Logged-in and anonymous engagement by digital property, page, feature and journey, digital profile health (MFA "
       "enrollment, login frequency), and every experiment with its variants, assignments and result on its primary "
       "metric. Digital product owners decide which journeys and features to change and which variants to ship.",
       [("04", "Experiment"), ("04", "Experiment Assignment"), ("04", "Digital Profile"), ("04", "Session"),
        ("04", "Engagement Event"), ("04", "Web Page"), ("04", "Digital Property"), ("21", "Metric Definition")],
       ["DP-011", "DP-101", "DP-240", "DP-004"],
       "Plan section 8.3 example. Experiment results are computed here, not stored in 04 (CW-091); the primary metric's "
       "definition is 21's. Supersedes DP-052 for clients.",
       "Y: pseudonymous visitor and client keys under the tracking consent; aggregates by variant.",
       [_HH], "04 SME 2 (anonymous event retention)."),
    _c("DP-395", "Nudges & Recommendation Determinations", C, RC, "04", "Head of Digital Advice", "FN-61",
       ["FN-68", "FN-60", "FN-76"],
       "Every nudge and personalized message with its trigger, channel, content, recommendation risk class and the 08 "
       "determination behind it, and every delivery with its response and any 45 recommendation it carried. Digital advice "
       "sees what nudges achieve, and supervision sees that no nudge classed as a potential recommendation went out "
       "unreviewed.",
       [("04", "Nudge Definition"), ("04", "Nudge Delivery"), ("08", "Supervisory Review"), ("45", "Recommendation")],
       ["DP-011", "DP-004", _A],
       "CW-091, CW-228: the determination is 08's and the recommendation 45's; reported, never decided here.",
       "Y: client keys on deliveries; restricted view for supervision.",
       levers="04 SME 3 (educational nudges only drops the determination join)."),
    _c("DP-396", "Promotions & Client Referral Rewards", C, OP, "04", "Head of Marketing", "FN-76",
       ["FN-66", "FN-72", "FN-67", "FN-68"],
       "Every promotion offer and client referral program with enrollments, qualification against the terms, awards due "
       "and paid (as a 50 money movement or a 47 fee waiver), 1099-MISC reportability and the 08 review of terms and "
       "endorsement disclosures. Marketing runs offers and sees cost per funded household; operations sees awards owed "
       "but unpaid.",
       [("04", "Promotion Offer"), ("04", "Promotion Enrollment"), ("04", "Client Referral"), ("50", "Money Movement"),
        ("47", "Fee Waiver"), ("08", "Compliance Review")],
       ["DP-011", "DP-240", "DP-093", "DP-008", _M, _F],
       "CW-092: definitions and enrollment 04, awards 50 and 47, tax reporting 13, review 08. DP-347 (CLA-A) owns fee "
       "waivers generally; this product reads the promotional ones.",
       "Y: referrer and referee identity.", [_CA], "04 SME 4 (a firm running neither drops it)."),
    _c("DP-397", "Voice of Client: Surveys & NPS", C, AN, "04", "Head of Digital", "FN-61",
       ["FN-67", "FN-68", "FN-73", "FN-76", "FN-37"],
       "Relationship and transactional survey results (NPS, satisfaction, effort) by journey, interaction, advisor, "
       "offering and segment, joined to the interaction or milestone that triggered each survey and its QA review, with "
       "responses referred as possible complaints. Client experience, service and advisor leaders see where satisfaction "
       "is won or lost.",
       [("04", "Client Survey"), ("04", "Survey Response"), ("13", "QA Review"), ("08", "Complaint")],
       ["DP-381", "DP-009", "DP-011", "DP-240"],
       "CW-093: surveys 04, interaction quality 13, complaints 08. DP-243 keeps the institutional survey reads.",
       "Y: verbatims PII and possibly special category: restricted view; scores as aggregates (CD-344, CW-225).",
       [_HH], "04 SME 5 (vendor-held responses: aggregates only)."),
    _c("DP-410", "Campaign Performance & Spend", C, AN, "04", "Head of Marketing Operations", "FN-76",
       ["FN-38", "FN-77"],
       "Cost, reach, response, leads and funnel milestones for every campaign node (program, campaign, wave, tactic, "
       "including client events and webinars) under the primary and alternative attribution models, with budgets, spend "
       "lines, media delivery and tracked URLs. Marketing reallocates spend between campaigns and channels.",
       [("04", "Campaign"), ("04", "Campaign Targeting"), ("04", "Campaign Product"), ("04", "Campaign Budget"),
        ("04", "Spend Line"), ("04", "Campaign Tracking Code"), ("04", "Campaign Member"), ("04", "Media Placement"),
        ("04", "Paid Media Delivery"), ("04", "Attribution Model"), ("04", "Attributed Outcome"),
        ("04", "Marketing Touchpoint"), ("04", "Marketing Event"), ("04", "Event Registration")],
       ["DP-011", "DP-013", "DP-004"],
       "Supersedes DP-025 (spend, response and funnel) and DP-051 (events as tactics). Net new assets and funded "
       "households by campaign are DP-492 (DIS+FDN), which reads the 04 weights (CW-085, CW-227); this product shows "
       "them beside spend and computes no NNA. Acquisition cost and lifetime value are DP-498 (CW-157).",
       "N in published views (aggregates); member drill Confidential - Personal Data.",
       [_CA], "04 SME 7 (attribution model), SME 8 (campaign hierarchy depth)."),
    _c("DP-411", "Content Performance", C, AN, "04", "Head of Content Strategy", "FN-76",
       ["FN-61", "FN-68", "FN-78"],
       "Use, engagement and compliance currency of every content asset and version across web, app, email and events, "
       "with its classification, audience restriction, rights, accessibility and the approval that governs it. Content "
       "strategists decide what to refresh, retire or produce.",
       [("04", "Content Asset"), ("04", "Asset Classification"), ("04", "Audience Restriction"), ("04", "Asset Version"),
        ("04", "Asset Rights"), ("04", "Asset Accessibility & Rendition"), ("04", "Marketing Theme"),
        ("04", "Engagement Event"), ("04", "Email Interaction"), ("08", "Compliance Review"),
        ("08", "Compliance Approval")],
       ["DP-011", "DP-013"],
       "Supersedes DP-026; the 03 Content Usage Event input left with the wholesale 03 (CW-062).",
       "N (aggregates).", levers="None specific."),
    _c("DP-412", "Marketing Audiences, Subscriptions & Tracking Consent", C, OP, "04", "Head of Marketing Operations",
       "FN-76", ["FN-62", "FN-61"],
       "The marketing audience for every send and personalization: segment membership, subscription topics, suppression "
       "entries and visitor tracking choices, joined to the contact rules for each party, so each send is built from one "
       "eligibility answer. Marketing operations builds audiences and proves suppressions were honored.",
       [("04", "Marketing Segment"), ("04", "Segment Membership"), ("04", "Subscription Topic"),
        ("04", "Suppression Entry"), ("04", "Tracking Consent Choice"), ("04", "Email Send")],
       ["DP-324", "DP-011", "DP-240"],
       "Supersedes DP-028. Opt-in state, consent and privacy are 02 and conformed by DP-324 Client Contactability, "
       "Preferences & Consent (CLA-A); topics, suppression and tracking choices are 04 (CW-084, CW-094).",
       "Y: Confidential - Personal Data.", levers="04 SME 9 (marketing platform masters opt-ins)."),
    _c("DP-413", "Social Media & Brand Performance", C, AN, "04", "Head of Digital Marketing", "FN-76",
       ["FN-47", "FN-68"],
       "Reach, engagement and sentiment of the firm's social accounts and posts and of third-party mentions, by brand, "
       "theme and message, with each post's compliance approval and complaints raised through social channels. Marketing "
       "sees which themes resonate and compliance sees that published posts were approved.",
       [("04", "Social Media Account"), ("04", "Social Post"), ("04", "Social Engagement Metrics"),
        ("04", "Social Listening Mention"), ("04", "Marketing Theme"), ("04", "Messaging Pillar"),
        ("08", "Compliance Review"), ("08", "Compliance Approval"), ("08", "Complaint")],
       ["DP-011", "DP-013"],
       "Supersedes DP-090. Advisors' own social accounts are 08 Approved Communication Channel (CW-067) and read by DP-078.",
       "Y in the listening drill (public handles); aggregates otherwise."),
    _c("DP-398", "Principal Review Queue & Supervisory Approvals", C, OP, "08", "Head of Retail Supervision", "FN-68",
       ["FN-60", "FN-61", "FN-62", "FN-71"],
       "Every supervisory review a registered principal performs (recommendation, rollover, account type, new account, "
       "transaction and correspondence reviews) with its queue, ageing, outcome, escalation and the best-interest review "
       "detail checked, by principal, branch and review type. Supervision staffs the queue and evidences timely approvals.",
       [("08", "Supervisory Review"), ("08", "Best Interest Review Detail")],
       ["DP-391", "DP-009", "DP-093", "DP-240", _A],
       "The Reg BI evidence file of plan 8.3 and acceptance question 3 is DP-334 and DP-335 (CLA-A), which read the review "
       "outcome as recorded; this product owns the workflow and its timeliness (CW-224). It never re-scores evidence "
       "(CW-066).",
       "Y: client and representative identity; restricted to supervision.",
       levers="08 SME 1 (one or several review objects), SME 2 (digital advice reviewed by population)."),
    _c("DP-399", "Form CRS & Reg BI Disclosure Delivery Control", C, RC, "08", "Head of Retail Conduct", "FN-68",
       ["FN-62", "FN-67", "FN-44", "FN-72"],
       "Each Form CRS and Reg BI disclosure trigger (account opening, recommendation, material change, new account type) "
       "checked against the delivery evidence, with late, missing and failed deliveries and the Form CRS version in force. "
       "Compliance evidences the disclosure obligation and finds the populations to re-deliver to.",
       [("08", "Disclosure Delivery Check"), ("15", "Account Disclosure Delivery"), ("13", "Recipient Delivery Record"),
        ("38", "Form CRS Filing Detail"), ("47", "Fee Disclosure Delivery")],
       ["DP-382", "DP-093", "DP-240", _F],
       "Who delivers which disclosure: 15 opening, 13 periodic and event, 47 fee, 38 the filing (CW-087, CW-162, CW-223). "
       "DP-328 (CLA-A) evidences account-opening disclosures; this product is the 08 check across all triggers.",
       "Y: client keys and addresses on delivery rows.", [_HH], "08 SME 3 (sample-based checks)."),
    _c("DP-400", "Sales Practice Surveillance & Corrective Action", C, RC, "08", "Head of Retail Supervision", "FN-68",
       ["FN-60", "FN-64", "FN-63", "FN-73", "FN-44"],
       "Every sales-practice surveillance scenario (excessive trading, concentration, share class and account type "
       "selection, switching, rollover patterns, complex products) with its alerts, dispositions, corrective actions "
       "against representatives and heightened supervision plans. Supervision manages the alert queue and evidences that "
       "exceptions were reviewed and acted on.",
       [("08", "Surveillance Scenario"), ("08", "Sales Practice Alert"), ("08", "Conduct Corrective Action"),
        ("08", "Heightened Supervision Plan"), ("45", "Recommendation"),
        ("01", "Product Risk Indicator")],
       ["DP-009", "DP-093", "DP-240", _O, _H, _A],
       "Sales-practice surveillance is 08, market-abuse surveillance 38 (DP-228; CW-163). Supersedes DP-060: share class "
       "selection becomes a scenario; brokerage breakpoints are 47 householding (CW-052, DP-348 CLA-A). The 01 firm risk rating (Product Risk Indicator) sets the complex-product scenarios. Holdings read are "
       "Client Holdings (49), never 06 or 18 (CW-007).",
       "Y: client and representative identity; restricted to supervision.",
       levers="Scenarios drop with product lines (options, margin, complex products)."),
    _c("DP-401", "Options & Margin Approval Oversight", C, RC, "08", "Head of Retail Supervision", "FN-68",
       ["FN-62", "FN-65", "FN-64"],
       "Options level and margin approvals with the principal's review of each, the profile facts relied on, accounts "
       "trading above their approved level, margin calls and accounts with repeated calls. Supervision evidences FINRA "
       "Rule 2360 and 4210 approvals and finds approvals to re-review.",
       [("08", "Supervisory Review"), ("15", "Options Approval Detail"), ("15", "Margin Account Detail"),
        ("15", "Account Feature"), ("49", "Margin Balance Snapshot"), ("49", "Client Margin Call")],
       ["DP-093", "DP-240", _H, _O],
       "Approvals 15, balances and calls 49, review 08 (CW-031; C-19.06).",
       "Y: client financial profile on approval rows.", levers="Plan section 15 ruling 3 (no margin or options: drop)."),
    _c("DP-402", "Supervisory Controls, Branch Inspections & Findings", C, RC, "08", "Head of Retail Supervision", "FN-68",
       ["FN-44", "FN-43", "FN-42", "FN-73"],
       "The supervisory control system: each control and its Rule 3120 test, branch and OSJ inspections against their "
       "cycle, findings with owners and due dates, and heightened supervision plans. Supervision and the CCO evidence the "
       "annual Rule 3120 report and the Rule 3130 certification.",
       [("08", "Supervisory Control"), ("08", "Supervisory Control Test"), ("08", "Branch Inspection"),
        ("08", "Supervisory Finding"), ("08", "Heightened Supervision Plan"), ("03", "Firm Branch Office"),
        ("38", "Attestation")],
       ["DP-009", "DP-192", "DP-391"],
       "Written supervisory procedures are 38 Policies; the Rule 3130 certification is a 38 Attestation (CW-066).",
       "Y: names of inspected staff and finding owners.", levers="03 SME 8 (branch network size)."),
    _c("DP-403", "Senior Investor Case Management & Rule 2165 Holds", C, RC, "08", "Head of Retail Conduct", "FN-68",
       ["FN-66", "FN-67", "FN-62", "FN-60"],
       "Every senior investor case from the concern that raised it through trusted contact outreach, temporary holds on "
       "disbursements and securities (FINRA Rule 2165) against their day limits, external reports to adult protective "
       "services and regulators, and resolution. The senior investor team runs its cases and compliance evidences each "
       "hold and report.",
       [("08", "Senior Investor Case"), ("08", "Senior Investor Case Action"), ("08", "External Protection Report"),
        ("50", "Money Movement Hold"), ("15", "Account Restriction")],
       ["DP-322", "DP-240", "DP-093", _M, "DP-381"],
       "CW-071, CW-109: case 08, concern 02, holds 15 and 50. DP-322 (CLA-A) is the protection register (who is protected); "
       "this product is the case workflow and the hold clock, reading 02 flags through DP-322's restricted view. Cash on "
       "hold (acceptance question 7) is BWO DP-456; DP-583 (FOP+CORP) covers TA-registered account holds.",
       "Y, special category: Restricted - Personal Data view for the senior investor team; aggregates elsewhere (CW-225).",
       levers="08 SME 5 (all specified adults or concerns only), SME 9 (cases run in 38)."),
    _c("DP-404", "Retail Conduct Risk Indicators", C, AN, "08", "Head of Retail Conduct", "FN-68",
       ["FN-42", "FN-44", "FN-73", "FN-37"],
       "Conduct indicators by business line, offering, branch and advisor: alert rates and ageing, complaint rates, "
       "recommendation evidence gaps, open findings, corrective actions, senior cases, registration lapses and late "
       "communications approvals. The CCO and the risk committee steer conduct risk and set heightened supervision.",
       [("08", "Sales Practice Alert"), ("08", "Complaint"), ("08", "Supervisory Finding"),
        ("08", "Conduct Corrective Action"), ("08", "Senior Investor Case")],
       ["DP-398", "DP-400", "DP-402", "DP-403", "DP-414", "DP-039", "DP-334", "DP-335", "DP-009", "DP-008"],
       "Counts read from the owning products (evidence gaps from DP-334 and DP-335, CLA-A; CW-224) and normalized by "
       "households and assets from the DP-008 successor; nothing re-derived. Feeds DP-248.",
       "N in published views; senior case counts only (CD-344).", [_CA, _HH]),
    _c("DP-414", "Complaints & Rule 4530 Reporting", C, RC, "08", "Head of Complaints & Conduct", "FN-68",
       ["FN-67", "FN-37", "FN-73", "FN-44"],
       "Every complaint with its classification (FINRA problem and product codes), handling, outcome, redress and root "
       "cause, by offering, channel, advisor and branch, with the Rule 4530(d) quarterly statistics and dissatisfaction "
       "seen in service contacts and surveys that was not logged. Complaints teams meet deadlines; product and service "
       "owners act on systemic causes.",
       [("08", "Complaint"), ("08", "Complaint Classification"), ("08", "Complaint Handling"),
        ("08", "Complaint Regulatory Report"), ("13", "Contact Center Interaction"), ("04", "Survey Response"),
        ("03", "Party Coverage Assignment")],
       ["DP-381", "DP-009", "DP-240", "DP-093", "DP-004"],
       "Supersedes DP-061. Complaints are 08, service requests 13; the Rule 4530 definition decides (CW-070). Consumer Duty "
       "outcome metrics left with CW-908.",
       "Y: complainant identity and narrative; restricted drill.", [_HH], "08 SME 4 (oral grievances recorded)."),
    _c("DP-415", "Marketing Rule Performance Substantiation", C, RC, "08", "Head of Advertising Review", "FN-68",
       ["FN-31", "FN-76", "FN-78"],
       "The evidence pack behind every performance presentation: products, programs or composites featured, gross and net "
       "presentation, required periods, hypothetical and extracted performance controls, ratings disclosures, the track "
       "record and benchmark of record and the retention of the supporting records. It evidences Rule 206(4)-1(d) and "
       "Rule 204-2(a)(16) and, for fund communications, Rule 482 and FINRA Rule 2210(d).",
       [("08", "Compliance Review"), ("08", "Performance Presentation"), ("08", "Compliance Approval"),
        ("21", "Retention Rule"), ("04", "Asset Compliance Reference"), ("04", "Asset Version"),
        ("01", "Performance Track Record"), ("01", "GIPS Composite"), ("01", "Product Benchmark Assignment")],
       ["DP-036", "DP-145", "DP-004", "DP-013"],
       "Supersedes DP-062; retention from 21 (CW-068); returns from DP-145 (never recomputed).",
       "N.", [_PRR], "Advice programs outside the GIPS firm by default (W2-W4 ruling)."),
    _c("DP-416", "Frequent Trading & Market Timing Surveillance", C, RC, "08", "Head of Retail Supervision", "FN-68",
       ["FN-35", "FN-36", "FN-74"],
       "Round-trip and excessive trading in own funds against each fund's frequent trading policy, for brokerage, "
       "fund-only and intermediary omnibus accounts, with frequent trading cases, the restrictions applied and the Rule "
       "22c-2 information relied on. Supervision evidences the market-timing policy to the fund board.",
       [("08", "Frequent Trading Case"), ("29", "Register Transaction"), ("29", "Share Register Balance"),
        ("15", "Account Restriction"), ("01", "Dealing Terms")],
       ["DP-580", "DP-093", "DP-004", "DP-240"],
       "Supersedes DP-084 (no live dependent, so a new id; FOP+CORP's DP-580 and DP-585 notes re-point here; 08 SME 7: the case stays 08). DP-585 (FOP+CORP) counts the 22c-2 requests and restriction "
       "instructions; this product scores trading. Books: Share Register Balance (29) and, through DP-580, the brokerage "
       "omnibus.",
       "Y: account keys.", levers="08 SME 7 (case moves to 29)."),
    _c("DP-405", "Contact Center Operations", C, OP, "13", "Head of Client Service", "FN-67",
       ["FN-61", "FN-41", "FN-38", "FN-68"],
       "Contact volumes, handle and wait times, abandonment, first-contact resolution, authentication outcomes and QA "
       "scores by channel, queue, reason and team against the service level definitions, with digital deflection by "
       "contact reason. Contact center managers staff queues and act on missed service levels.",
       [("13", "Contact Center Interaction"), ("13", "Interaction Authentication"), ("13", "QA Review"),
        ("13", "Service Level Definition"), ("13", "Service Level Measurement")],
       ["DP-381", "DP-192", "DP-011", "DP-013"],
       "Plan section 8.3 example. Supersedes the service-level part of DP-043; outsourced-TA oversight is 29's (CW-088). "
       "Cost per contact is DP-498's (CW-157).",
       "Y: client keys and agent names; aggregates for leadership.", [_HH], "13 SME 1."),
    _c("DP-406", "Service Request Fulfillment & Good-Order Quality", C, OP, "13", "Head of Client Service", "FN-67",
       ["FN-62", "FN-65", "FN-66", "FN-71"],
       "Every service request by type (maintenance, transfers in and out, beneficiary and estate, distributions, document "
       "requests) from intake to completion, with not-in-good-order rates and reasons, rework, ageing and the ACATS "
       "transfer or money movement it triggered. Service operations clears backlogs and fixes the forms and journeys that "
       "fail most.",
       [("13", "Service Request"), ("13", "Request Controls"), ("13", "Transfer of Ownership & Estate"),
        ("49", "Account Transfer"), ("50", "Money Movement"), ("02", "Death Notification")],
       ["DP-381", "DP-093", _H, _M],
       "Transfers 49 (CW-104); payments 50 (CW-107); death 02, estate transfer 13 (CW-077, CW-089). Account opening good "
       "order is DP-327 (CLA-A).",
       "Y: client identity and estate detail.", levers="13 SME 1."),
    _c("DP-407", "Statements & Trade Confirmation Delivery", C, RC, "13", "Head of Client Communications", "FN-67",
       ["FN-64", "FN-65", "FN-68", "FN-63"],
       "Account statements (FINRA Rule 2231) and trade confirmations (SEC Rule 10b-10) produced and delivered by account, "
       "cycle and method against their deadlines, with returned mail, suppressions, corrections and confirmations not "
       "delivered. Client communications evidences delivery and fixes failed production runs.",
       [("13", "Investor Document"), ("13", "Confirmation Delivery"), ("13", "Production Run"),
        ("13", "Recipient Delivery Record"), ("48", "Client Trade Confirmation")],
       ["DP-382", "DP-093", _O],
       "48 masters the confirmation, 13 its delivery (CW-081, CW-098).",
       "Y: client addresses on delivery rows.", levers="13 SME 5."),
    _c("DP-408", "Proxy Solicitation, Pass-Through & Voting Choice", C, OP, "13", "Head of Client Communications", "FN-67",
       ["FN-24", "FN-35", "FN-36", "FN-65"],
       "Own-fund shareholder meetings (votes against quorum by channel and intermediary, NOBO requests) and, for brokerage "
       "clients, third-party issuer pass-through (materials delivered, instructions received and transmitted, OBO / NOBO "
       "elections), with own-fund voting-choice elections. Communications and fund legal steer solicitation to quorum and "
       "evidence pass-through.",
       [("13", "Proxy Campaign"), ("13", "Proxy Proposal"), ("13", "Vote Tally"), ("13", "Intermediary Vote Instruction"),
        ("13", "Issuer Proxy Pass-Through"), ("13", "Beneficial Owner Disclosure Election"),
        ("13", "Voting Choice Election"), ("49", "Client Holding"), ("29", "Share Register Balance")],
       ["DP-382", "DP-580", "DP-099", "DP-093", _H],
       "Supersedes DP-071 (plan section 15 ruling 7). Pass-through and elections 13 (CW-082, CW-090); record-date position "
       "a derived copy of 49 Client Holding or the 29 register balance, never 06 (CW-007). Own funds' portfolio votes are 34.",
       "Y: account keys and elections.", levers="13 SME 3, SME 4, SME 9."),
    _c("DP-409", "Servicing Errors & Client Remediation", C, RC, "13", "Head of Client Service", "FN-67",
       ["FN-42", "FN-68", "FN-33", "FN-72"],
       "Every servicing and processing error affecting clients, with root cause, accounts affected, remediation owed and "
       "paid and its timeliness, linked to the operational incident where one was raised. Service and risk see recurring "
       "errors and remediation still owed.",
       [("13", "Servicing Error"), ("13", "Shareholder Remediation"), ("50", "Money Movement")],
       ["DP-381", "DP-093", "DP-215", _M],
       "Supersedes the error and remediation part of DP-043. NAV-error remediation stays DP-169; the incident is 37.",
       "Y: client keys and amounts.", levers="None specific."),
    _c("DP-417", "Client Tax Forms & Cost Basis Reporting", C, RC, "13", "Head of Client Communications", "FN-67",
       ["FN-65", "FN-39", "FN-62", "FN-76"],
       "Forms 1099-B, -DIV, -INT, -R, -MISC and 5498, original and corrected, by account and tax year, checked against the "
       "49 lots and activity and the 15 elections behind them, furnished and filed on time. Tax reporting sees missing, "
       "late and inconsistent forms and the corrections they cause.",
       [("13", "Tax Form Record"), ("13", "Investor Document"), ("49", "Client Tax Lot"),
        ("49", "Cost Basis Adjustment"), ("15", "Cost Basis Election"), ("04", "Promotion Enrollment")],
       ["DP-382", "DP-093", _H],
       "Supersedes DP-091 (CW-034). Certification and election status are DP-330 (CLA-A); this product is the forms. "
       "1099-MISC for promotion awards (CW-092).",
       "Y: Restricted - Personal Data at account grain; TINs never published.", levers="None specific."),
    _c("DP-418", "Escheatment, Dormancy & Lost Client Monitoring", C, RC, "13", "Head of Client Service", "FN-67",
       ["FN-35", "FN-65", "FN-66", "FN-38", "FN-44"],
       "Lost securityholder status and Rule 17Ad-17 searches, state dormancy assessments and due diligence letters, "
       "presumed-abandoned dates, escheatment deliveries and the state reports, remittances and reclaims, for TA-registered "
       "and brokerage accounts. Client service and the transfer agent stop accounts escheating that should not and file "
       "every state on time.",
       [("13", "Lost Shareholder Status"), ("13", "Dormancy Assessment"), ("13", "Escheatment Report & Remittance"),
        ("13", "Unclaimed Property Reclaim"), ("13", "Service Request"), ("29", "Share Register Balance"),
        ("49", "Client Holding"), ("50", "Money Movement")],
       ["DP-381", "DP-580", "DP-093", "DP-240", _H, _M],
       "Supersedes DP-070 (no live product depends on it, so a new id; FOP+CORP withdrew DP-584 as a duplicate of 'DP-070 "
       "re-scoped', and its notes re-point here). Books: Share Register Balance (29) for TA-registered accounts, Client "
       "Holding (49) for brokerage accounts (CW-007); owner-generated contact from DP-381.",
       "Y: owner state and contact dates; state-level aggregates for filing views."),
]


# Re-scoped in place (kept ids; a live product depends on each): candidate-shaped, read by candidate_coverage.py
RESCOPED = [
    {**_c("DP-036", "Communications Review & FINRA Filing", C, RC, "08", "Head of Advertising Review", "FN-68",
       ["FN-76", "FN-78", "FN-47"],
       "Every communication submitted for review from submission through review steps, principal approval, FINRA filing, "
       "expiry and withdrawal, with the US classification that decides which rules apply. Advertising review manages its "
       "workload and evidences approval before use and timely filing (FINRA Rules 2210 and 2212; Rule 206(4)-1).",
       [("08", "Compliance Review"), ("08", "US Communication Classification"), ("08", "Performance Presentation"),
        ("08", "Review Step"), ("08", "Compliance Approval"), ("08", "FINRA Advertising Filing"),
        ("08", "Individual Registration"), ("04", "Content Asset"), ("04", "Asset Version")],
       ["DP-011", "DP-009", "DP-013"],
       "Re-scoped in place: DP-236 (42, live) depends on the id. EU/UK classifications and other-regulator filings left with CW-908.",
       "Y: submitter and principal names.", levers="None specific."), "disposition": "re-scope"},
    {**_c("DP-038", "Gifts & Non-Cash Compensation", C, RC, "08", "Head of Retail Conduct", "FN-68",
       ["FN-44", "FN-74", "FN-38"],
       "Every gift, entertainment item and training or education meeting given or received, valued per recipient, summed "
       "per recipient per year against the FINRA Rule 3220 limit and Rule 2341 non-cash compensation conditions, with "
       "approvals and the special-recipient controls (ERISA fiduciaries, government officials). Compliance evidences the "
       "limits and sees concentrations.",
       [("08", "Gift / Entertainment Item"), ("08", "Benefit Valuation"), ("08", "G&E Approval"),
        ("08", "Training / Education Meeting"), ("03", "Advisor Role Assignment"), ("04", "Marketing Event")],
       ["DP-009", "DP-240", "DP-192", "DP-011"],
       "Re-scoped in place: DP-209 (44, live) depends on the id. The inducement assessment left with CW-067.",
       "Y: giver and recipient names.", levers="08 SME 6 (aggregation basis), SME 10."), "disposition": "re-scope"},
    {**_c("DP-039", "Representative Registrations, Licensing & CE", C, RC, "08", "Head of Registration & Licensing",
       "FN-68", ["FN-41", "FN-73", "FN-44"],
       "Every registration, exam, Form U4 and U5 filing, disclosure event and CE requirement of the firm's own "
       "representatives and IARs, with credentials, matched to the states their clients live in. Licensing stops a "
       "representative serving a client or state they are not registered for and files on time.",
       [("08", "Individual Registration"), ("08", "Exam Result"), ("08", "Registration Filing"),
        ("08", "Disclosure Event"), ("08", "CE Requirement"), ("03", "License & Registration Reference"),
        ("03", "Advisor"), ("03", "Party Coverage Assignment")],
       ["DP-009", "DP-192", "DP-240"],
       "Re-scoped in place (CW-072): DP-200 (live) depends on the id, and its registered-role eligibility "
       "reads it (FOP+CORP RESPEC). Client state of residence from DP-240 (03 SME 4).",
       "Y: Confidential - Personal Data; disclosure events Restricted.", levers="03 SME 4 (registered-state check)."), "disposition": "re-scope"},
    {**_c("DP-078", "Communications Capture & Surveillance", C, RC, "08", "Head of Compliance Surveillance", "FN-68",
       ["FN-44", "FN-73", "FN-51"],
       "Evidence that business communications are captured, retained and supervised: the approved-channel register "
       "(advisors' social accounts included), archived messages and calls with retention and legal hold status, and lexicon "
       "surveillance alerts with their review and disposition, joined to the registered population and CRM activity. "
       "Compliance sees capture gaps, unreviewed alerts and records at risk of early deletion.",
       [("08", "Approved Communication Channel"), ("08", "Captured Communication Record"), ("08", "Surveillance Alert"),
        ("08", "Individual Registration"), ("21", "Retention Rule"), ("03", "Advisor"), ("03", "Advisor Activity"),
        ("03", "Activity Capture"), ("20", "Employee")],
       ["DP-009", "DP-010", "DP-039", "DP-192", "DP-013"],
       "Re-scoped in place: DP-228 (38, live) depends on the id. SEC Rule 17a-4(b)(4), FINRA Rule 3110(b)(4); retention "
       "from 21 (CW-068); primary FN-13 to FN-68.",
       "Y: Confidential - Personal Data; message content restricted to surveillance."), "disposition": "re-scope"},
    {**_c("DP-069", "Client Communications Delivery, Householding & Cost", C, AN, "13", "Head of Client Communications",
       "FN-67", ["FN-35", "FN-38", "FN-76"],
       "Regulatory communications (shareholder reports, prospectuses, notices) and periodic documents by type, delivery "
       "method (print, e-delivery, householded, suppressed) and route, with e-delivery adoption, householding savings, "
       "returned mail and the print, postage and processing cost borne by the funds and the firm. Communications and "
       "finance decide e-delivery campaigns and see that each mailing met its deadline.",
       [("13", "Shareholder Communication"), ("13", "Tailored Shareholder Report"), ("13", "Prospectus Delivery"),
        ("13", "Shareholder Notice"), ("13", "Communication Distribution"), ("13", "E-Delivery Election"),
        ("13", "Householding Group"), ("10", "Distribution Cost Item")],
       ["DP-382", "DP-004", "DP-013"],
       "Re-scoped in place: DP-106 (36, live) depends on the id; DP-106 also gains DP-382 (RESPEC). Intermediary distribution requests are 29 (CW-088).",
       "N (aggregates).", [_HH], "13 SME 5, SME 6."), "disposition": "re-scope"},
    {**_c("DP-085", "Account Maintenance, Authentication & Takeover Monitoring", C, RC, "13", "Head of Client Service",
       "FN-67", ["FN-66", "FN-68", "FN-51", "FN-44"],
       "Every change to contact data, bank instructions, registration and beneficiaries, with the authentication behind "
       "it and the digital login signals around it, linked to the disbursements and holds that follow, flagging patterns "
       "of account takeover (a bank or email change followed by a withdrawal). Service and fraud teams stop losses and "
       "evidence Reg S-ID red-flag controls.",
       [("13", "Service Request"), ("13", "Account Maintenance Change"), ("13", "Interaction Authentication"),
        ("04", "Digital Profile"), ("15", "Bank Instruction"), ("15", "Account Standing Instruction"),
        ("50", "Money Movement Hold"), ("50", "Fraud Risk Assessment")],
       ["DP-381", "DP-093", "DP-240", _M],
       "Re-scoped in place: DP-180 (29, live) depends on the id. Authentication split 04, 13, 02, 41 (CW-086); holds 50 (CW-109).",
       "Y: Confidential - Personal Data; never credentials.", levers="13 SME 8."), "disposition": "re-scope"},
    {**_c("DP-079", "Fund Dealing & Operational Reference", C, OP, "01", "Head of Product Data", "FN-78",
       ["FN-35", "FN-74", "FN-64"],
       "The operational terms needed to trade, settle and service each own share class on the brokerage platform, through "
       "the transfer agent and at intermediaries: dealing frequency and cut-off, settlement period, valuation point, "
       "listings, ETF characteristics, income distribution, currency hedging, minimums and sales charges, and US tax status. "
       "Platforms, the TA and intermediaries trade on one published set of terms.",
       [("01", "Share Class"), ("01", "Dealing Terms"), ("01", "Valuation Terms"), ("01", "Listing"),
        ("01", "ETF Characteristics"), ("01", "Income Distribution"), ("01", "Currency Hedging"),
        ("01", "Investor Transaction Charge"), ("01", "Product Tax Status")],
       ["DP-004", "DP-005", "DP-013"],
       "Re-scoped in place: DP-177 (29, live) depends on the id and FOP+CORP keeps it. EU tax status, UK reporting fund and "
       "the 05 Trading Setup inputs left (CW-901); primary FN-15 to FN-78.",
       "N."), "disposition": "re-scope"},
]


# ======================================================== Dispositions of the pending products ======================
def _d(pid, disposition, successor, reason, decision="CW-220"):
    return dict(id=pid, disposition=disposition, successor=successor, decision=decision, reason=reason)


DISPOSITIONS = [
    # --- 03 (wholesale sales) ---
    _d("DP-017", "Superseded", "DP-483 (DIS+FDN)", "Advisor 360 for wholesalers: the external advisor profiles moved to 05 "
       "(CW-132) and wholesaler coverage retired with 07 (CW-907); DP-483 Intermediary Advisor Coverage & Engagement takes "
       "it. The own-advisor book is DP-387."),
    _d("DP-018", "Superseded", "DP-483 (DIS+FDN)", "External-advisor segmentation for wholesalers on 07 territory and "
       "coverage tiers (CW-907); thin IC channel."),
    _d("DP-019", "Superseded", "DP-488 (DIS+FDN)", "Agreed with DIS+FDN: institutional and plan pipeline objects are 05 "
       "(CW-134); goals and pipeline snapshots retired (CW-907, CW-062)."),
    _d("DP-022", "Superseded", "DP-489 (DIS+FDN)", "Agreed with DIS+FDN: consultant objects are 05 (CW-131, CW-134); "
       "consultant meetings are 03 activities through DP-010 (CW-138)."),
    _d("DP-023", "Superseded", "DP-489 (DIS+FDN)", "Agreed with DIS+FDN: RFP Request and Submission are 05; the answer "
       "library retired (ANS-)."),
    _d("DP-092", "Retire", "DP-243 (live); DP-510 (DIS+FDN, institutional slice)", "Institutional Client restored in 12 "
       "(CW-133); DP-243 Total Client Relationship already answers it and DIS+FDN DP-510 takes the institutional service "
       "slice. No live dependent. Owner 03, so this is the one disposition (the FOP+CORP duplicate was removed at the WP0 "
       "integration)."),
    _d("DP-046", "Superseded", "DP-340 (CLA-A)", "Wholesaler next-best-action on 07 coverage; the own advisor's action list "
       "is DP-340 Advisor Client Action Worklist, with contact cadence from DP-389."),
    _d("DP-053", "Retire", "", "The unified timeline is a view of DP-010, DP-011 and DP-381; DP-320 Household 360 (CLA-A) "
       "shows recent interactions. No live dependent."),
    # --- 04 (marketing) ---
    _d("DP-025", "Superseded", "DP-410; DP-492 (DIS+FDN)", "Agreed with DIS+FDN: net new assets by campaign go to DP-492 "
       "(04 keeps the weights, CW-085); spend, response and funnel go to DP-410. No live dependent."),
    _d("DP-026", "Superseded", "DP-411", "Content performance survives without the 03 Content Usage Event (CW-062); no live "
       "dependent."),
    _d("DP-027", "Superseded", "DP-392", "Lead hand-off to inside sales and 07 territory becomes the direct acquisition "
       "funnel to account opening (CW-083, CW-085)."),
    _d("DP-028", "Superseded", "DP-412; DP-324 (CLA-A)", "Contactability splits: 02 consent and contact rules are DP-324; "
       "marketing audiences, topics, suppression and tracking choices are DP-412 (CW-084). GDPR inputs left (CW-904)."),
    _d("DP-051", "Superseded", "DP-410", "CE accreditation and sponsorship objects removed (CW-904); client events are "
       "campaign tactics. IC lever restores advisor events."),
    _d("DP-052", "Superseded", "DP-394", "Advisor intent signals served wholesaler outreach; client engagement is DP-394; "
       "third-party intent and portal objects removed (CW-904)."),
    _d("DP-087", "Retire", "", "Professional-only and EU/UK access gating removed (CW-003, CW-904); a direct US site has no "
       "gated audience. IC lever restores it."),
    _d("DP-090", "Superseded", "DP-413", "Social and brand performance survives; advisors' social accounts are 08 (CW-067)."),
    # --- 08 (distribution compliance) ---
    _d("DP-036", "Re-scope", "DP-036", "Kept in place: DP-236 (42, live) depends on it. Communications review and FINRA "
       "filing in retail form (CW-073); EU/UK classifications and other-regulator filings left (CW-908). Spec in RESCOPED."),
    _d("DP-037", "Superseded", "DP-486 (DIS+FDN)", "Distributor due diligence moved to 05 in reduced form (CW-135); MiFID "
       "and FCA oversight out of scope (CW-003)."),
    _d("DP-038", "Re-scope", "DP-038", "Kept in place: DP-209 (44, live) depends on it. Gifts and non-cash compensation "
       "(FINRA Rules 3220, 2341); inducement assessment left (CW-067). Spec in RESCOPED."),
    _d("DP-039", "Re-scope", "DP-039", "Kept in place: DP-200 (20, live) depends on it, and FOP+CORP withdrew DP-596 in its "
       "favor. Registrations, exams, U4/U5, CE of own representatives and IARs (CW-072); SM&CR and territory left."),
    # DP-040 (retire into DP-109 and DP-385): ruled once in the framing table (proposals_wp0_framing, CW-207), agreed here.
    _d("DP-041", "Retire", "", "Cross-border marketing eligibility is EU/UK (CW-003). UK extension lever."),
    _d("DP-060", "Superseded", "DP-400", "Share class selection and level-load patterns become surveillance scenarios; "
       "brokerage breakpoints are 47 householding (CW-052, DP-348 CLA-A)."),
    _d("DP-061", "Superseded", "DP-414", "Complaints under Rules 4530 and 4513 (CW-070); no live dependent."),
    _d("DP-062", "Superseded", "DP-415", "Marketing Rule substantiation; retention from 21 (CW-068); no live dependent."),
    # DP-065 (retire, EU/UK inducements): ruled once in the framing table (CW-207), agreed here.
    _d("DP-078", "Re-scope", "DP-078", "Kept in place: DP-228 (38, live; framing re-scope) depends on it. Spec in RESCOPED. "
       "Lead ruling 2026-10-15: DP-078 stays in place as DP-228's upstream."),
    _d("DP-084", "Superseded", "DP-416", "Own-fund market-timing surveillance stays 08 (08 SME 7), on the 29 register "
       "(CW-123). No live dependent, so a new id; FOP+CORP's notes on DP-580 and DP-585 cite DP-084 and re-point to DP-416."),
    # --- 13 (servicing) ---
    _d("DP-043", "Superseded", "DP-405; DP-409", "TA oversight left 13 with Servicing Provider Engagement (CW-088; outsourced "
       "TA is the 29 lever); in-house service levels and errors are DP-405 and DP-409 (FOP+CORP re-points DP-169, DP-176)."),
    _d("DP-069", "Re-scope", "DP-069", "Kept in place: DP-106 (36, live) depends on it. Delivery, householding, e-delivery "
       "adoption and cost for every account type; EU/UK and intermediary cascade inputs left (CW-913, CW-088)."),
    _d("DP-070", "Superseded", "DP-418", "No live dependent, so a new id under the lead's rule. FOP+CORP withdrew DP-584 as a "
       "duplicate of 'DP-070 re-scoped'; DP-418 covers that scope (29 register and 49 brokerage book)."),
    _d("DP-071", "Superseded", "DP-408", "Own-fund solicitation joins issuer pass-through and voting choice in DP-408; DP-183 "
       "drops DP-071 (FOP+CORP RESPEC)."),
    _d("DP-085", "Re-scope", "DP-085", "Kept in place: DP-180 (29, live) depends on it. Widened to digital authentication "
       "(CW-086, Reg S-ID) and 50 holds (CW-109). Spec in RESCOPED."),
    _d("DP-091", "Superseded", "DP-417", "Tax forms for every account type against 49 lots (CW-034); UK and EU documents "
       "left; no live dependent."),
    # --- 01 (product data) ---
    _d("DP-058", "Superseded", "DP-383; DP-107 (live)", "Country registrations and EU notifications removed (CW-901); the "
       "remaining go-to-market check is platform availability; launch readiness stays DP-107."),
    _d("DP-059", "Superseded", "DP-500, DP-506 (DIS+FDN); DP-183 (live)", "Pricing scenarios are 10 (CW-158, DP-500), fee "
       "benchmarks 11 (DP-506), the Section 15(c) fee materials DP-183, which drops DP-059 (FOP+CORP RESPEC). 01 "
       "Performance Fee loses its only reader (RESPEC DP-004)."),
    # DP-064 (retire, FinDatEx EU/UK feeds): ruled once in the framing table (CW-207), agreed here.
    _d("DP-079", "Re-scope", "DP-079", "Kept in place: DP-177 (29, live) depends on it and FOP+CORP keeps the upstream. "
       "US dealing and operational reference for the own platform, the TA and the IC line. Spec in RESCOPED."),
]


# ======================================================== WP1 re-spec notes for live products owned by 01 and 36 ======
RESPEC = {
    "DP-004": "Framing re-scope (Product, Offering & Share Class Reference) takes the offering scope drafted here as DP-380 "
              "(CW-221). Please confirm it also reads 01 Offering Fee Schedule Link, Model Portfolio and Currency Hedging; "
              "Currency Hedging is otherwise read only by DP-079 (re-scoped here).",
    "DP-105": "Proposals and business cases gain the 01 Service Offering reference (CW-161); supporting FN-10, FN-01, FN-16, "
              "FN-12 become FN-78, FN-77, FN-38.",
    "DP-106": "Keeps DP-069 (re-scoped in place) and adds DP-382; the advice and platform side of the calendar is DP-384; "
              "supporting FN-15, FN-13, FN-04, FN-12 become FN-67, FN-68, FN-74, FN-38.",
    "DP-107": "Readiness adds advice program and platform feature launches (36 Readiness Check on Service Offering "
              "Specification); DP-058 is superseded by DP-383; FN-10, FN-04 become FN-78, FN-74.",
    "DP-108": "Upstream DP-008 becomes its successor; account moves read DP-093 and 49 holdings through the framing product; "
              "FN-04, FN-07, FN-19 become FN-74, FN-71.",
    "DP-109": "Reads DP-385 for advice program evidence; upstreams DP-040 (retired), DP-035 and DP-030 (pending) are replaced "
              "by DP-385, DP-499 and DP-506; FN-13, FN-18 become FN-68.",
    "DP-242": "Fund 360 carried (plan section 8.3); upstream DP-008 becomes its successor; FN-10 becomes FN-78.",
}


DECISIONS = [
    {"id": "CW-220", "theme": "Data products", "title": "WP0 dispositions of the CLA-B pending products (01, 03, 04, 08, 13)",
     "domains": ["01", "03", "04", "08", "13", "36"],
     "issue": "Thirty-eight wholesale consumer products owned by 01, 03, 04, 08 and 13 are pending (CW-041).",
     "resolution": "Per proposals_wdp_cla_b.DISPOSITIONS, under the lead's rule (re-scope in place only where a live product "
                   "depends on the id): 7 re-scoped in place, specs in RESCOPED: DP-036 (for DP-236), DP-038 (DP-209), "
                   "DP-039 (DP-200), DP-069 (DP-106), DP-078 (DP-228), DP-079 (DP-177), DP-085 (DP-180); 24 superseded: "
                   "DP-017 and DP-018 (DP-483), DP-019 (DP-488), DP-022 and DP-023 (DP-489), DP-025 (DP-410, DP-492), DP-026 "
                   "(DP-411), DP-027 (DP-392), DP-028 (DP-412, DP-324), DP-037 (DP-486), DP-043 (DP-405, DP-409), DP-046 "
                   "(DP-340), DP-051 (DP-410), DP-052 (DP-394), DP-058 (DP-383), DP-059 (DP-500, DP-506), DP-060 (DP-400), "
                   "DP-061 (DP-414), DP-062 (DP-415), DP-070 (DP-418), DP-071 (DP-408), DP-084 (DP-416), DP-090 (DP-413), "
                   "DP-091 (DP-417); 7 retired: DP-040, DP-041, DP-053, DP-064, DP-065, DP-087, DP-092 (DP-040, DP-064 and "
                   "DP-065 confirm CW-207). Superseded and retired ids go to RETIRED_PRODUCTS with this decision and are "
                   "never reused.",
     "rationale": "Territory, wholesaler and sales-crediting products retire with 07 (CW-907); supervision and conduct "
                  "products are rebuilt on the new 08 and 03 (CW-015, CW-066).",
     "action": "WP0 integration", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
    {"id": "CW-221", "theme": "Data products", "title": "The Offering and Program dimension is conformed once, in DP-004 (DP-380 folded in)",
     "domains": ["01", "15", "46", "47", "06"],
     "issue": "Plan section 8.4 adds an Offering and Program dimension; this brief drafted DP-380 Advice, Service & Platform "
              "Offering Catalog for it, and the framing agent re-scopes DP-004 to the same scope.",
     "resolution": "Ruled at WP0 framing: DP-380 folds into DP-004 Product, Offering & Share Class Reference; the id DP-380 is "
                   "not registered. Every CLA-B product that named DP-380 reads DP-004. No other product conforms an "
                   "offering; CONCEPT_OWNERSHIP gains ('Service Offering', '01', 'OFFR-') if the framing has not added it.",
     "rationale": "Enrollment, billing, managed accounts, attribution and supervision all slice by one offering key.",
     "action": "WP1F (DP-004)", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
    {"id": "CW-222", "theme": "Data products", "title": "Client service facts are conformed once in DP-381",
     "domains": ["13", "08", "10", "04", "02"],
     "issue": "Service requests and interactions are read by contact center, complaints, fraud, voice of client, Household "
              "360 and cost to serve.",
     "resolution": "DP-381 Client Service Interactions & Requests (foundational, 13) is the one service fact; consumers read "
                   "it (DP-498 and DP-320 included). Complaints stay 08 and are referenced (CW-070). CONCEPT_OWNERSHIP gains "
                   "('Service Request', '13', 'SRQ-').",
     "rationale": "One count of contacts and requests across service, conduct and economics.",
     "action": "WP0 ruling, WP1F", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
    {"id": "CW-223", "theme": "Data products", "title": "Delivery evidence is conformed once in DP-382",
     "domains": ["13", "08", "15", "47", "48"],
     "issue": "Disclosure checks, statements, confirmations, proxy, tax and fee disclosures all need proof of delivery.",
     "resolution": "DP-382 Client Document & Delivery Record (foundational, 13) publishes documents, distributions, recipient "
                   "delivery records, e-delivery elections and mailing households; 15 Account Disclosure Delivery and 47 Fee "
                   "Disclosure Delivery are read beside it from their masters (CW-087). CONCEPT_OWNERSHIP gains "
                   "('Investor Document', '13', '').",
     "rationale": "Delivery proof computed once; the mailing household is not the client or fee household (CW-027).",
     "action": "WP0 ruling, WP1F", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
    {"id": "CW-224", "theme": "Data products", "title": "Acceptance question 3: evidence in DP-334 and DP-335 (CLA-A), review workflow in DP-398",
     "domains": ["08", "45", "16"],
     "issue": "Both Client & Advice briefs drafted the Reg BI file; the question could resolve in two products.",
     "resolution": "DP-334 Plan Quality & Recommendation Evidence and DP-335 Rollover Recommendations & PTE 2020-02 Evidence "
                   "(CLA-A, 45) publish the evidence-gap flags; DP-398 Principal Review Queue & Supervisory Approvals (08) "
                   "publishes the review workflow and its timeliness and supplies the outcome they read. DP-404 takes the gap "
                   "counts from DP-334 and DP-335. No CLA-B product re-scores evidence (CW-066).",
     "rationale": "One answer to acceptance question 3; supervision owns the review, advice owns the evidence.",
     "action": "WP1C", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
    {"id": "CW-225", "theme": "Data products", "title": "Special-category posture of the CLA-B products",
     "domains": ["08", "02", "04", "13", "50"],
     "issue": "Senior investor cases, vulnerability concerns and survey verbatims are special category (CD-344, CW-030).",
     "resolution": "DP-403 publishes case detail only in a restricted view for the senior investor team and reads 02 flags "
                   "through DP-322's restricted view (CLA-A, CW-213); DP-404 and the other products publish counts or the "
                   "DP-322 flag only; DP-397 publishes verbatims in a restricted view and scores as aggregates.",
     "rationale": "Applies CD-344 to the conduct and engagement products, consistent with CW-213.",
     "action": "WP1C", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
    {"id": "CW-226", "theme": "Certified numbers", "title": "Advisor books take assets from the DP-008 successor by advisor of record",
     "domains": ["03", "06", "20", "10"],
     "issue": "Capacity, reassignment, referral, incentive and conduct products need assets by advisor or household.",
     "resolution": "DP-387, DP-388, DP-390, DP-393 and DP-404 read Client Assets, Net New Assets and Advised Assets by advisor "
                   "of record and household from the DP-008 successor or DP-491 (CW-011, CW-063, CW-143); none recomputes or "
                   "re-attributes them. Certified pay stays DP-198.",
     "rationale": "A certified number is defined in one product only.",
     "action": "WP1C", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
    {"id": "CW-227", "theme": "Certified numbers", "title": "Assets by campaign come from DP-008's Campaign rows; 04 products compute counts and rates only",
     "domains": ["04", "06", "10"],
     "issue": "DP-392, DP-396 and DP-410 show assets won by campaign.",
     "resolution": "04 holds attribution weights and milestones; DP-008 applies them to its flows at Dimension Type Campaign (CW-085); "
                   "DP-392 and DP-410 read Net New Assets by campaign from DP-008 directly and compute counts, costs and conversion "
                   "rates only; DP-492 (DIS+FDN) reads the same rows for cohort and household views and lists DP-410 upstream "
                   "for the funnel outcomes (amended at the WP1C fix pass: no DIS-to-CLA-B edge is needed for the asset figure).",
     "rationale": "Applies CW-085 and agrees the DIS+FDN split of DP-025; one NNA rule, read from DP-008 wherever it is cut.",
     "action": "WP1C", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
    {"id": "CW-228", "theme": "Data products", "title": "Nudges point to 45 recommendations and 08 determinations",
     "domains": ["04", "03", "45", "08"],
     "issue": "DP-395 and DP-389 surface actions that may be recommendations.",
     "resolution": "Neither creates or classifies a recommendation: DP-395 reports each nudge's 08 determination and the 45 "
                   "Recommendation a delivery carried; recommendations are evidenced in DP-334 and reviewed in DP-398.",
     "rationale": "Applies CW-091 and CW-057.",
     "action": "WP1C", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
    {"id": "CW-229", "theme": "Data products", "title": "Two CLA-B foundational products outside the plan's section 8.2 list (DP-381, DP-382)",
     "domains": ["13"],
     "issue": "Plan section 8.2 names no foundational product for service facts or delivery evidence.",
     "resolution": "DP-381 and DP-382 join WP1F beside the framing agent's DP-300 series, depending only on foundational "
                   "products (DP-004, DP-013, DP-093, DP-192, DP-240, DP-009). If declined, both become consumer products "
                   "and their readers each conform their own copy.",
     "rationale": "Each conforms one 13 master read by five or more consumers across three areas.",
     "action": "WP0 ruling", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]


# ---- WP1 scope (WP0 rationalization, 2026-10-15; Product_Briefs/WP1_Scope.md) ------------------------------
# Program-lead ruling: every candidate is flagged wp1=True (specified at WP1) or backlog=True (registered in
# framework.WAVE_BACKLOG, status 'backlog', not specified at WP1; ids unchanged). WP1_MERGES names the product a
# backlog candidate overlaps (its scope folds in there if it is picked up). WP1_MOVED_READS: objects with CDEs that
# only a backlog candidate read, now read by the named WP1 product (coverage rule; WP1 specs read them).
WP1_BACKLOG_IDS = ["DP-386", "DP-388", "DP-389", "DP-395", "DP-396", "DP-397", "DP-411", "DP-413", "DP-401", "DP-415", "DP-416", "DP-406", "DP-407", "DP-417"]
WP1_MERGES = {

    "DP-386": "DP-383",   # Product Documents & Commentary Currency -> Platform Shelf, Availability & Due Diligence Status
    "DP-388": "DP-387",   # Client Reassignment & Retention -> Advisor Capacity & Book Health
    "DP-389": "DP-387",   # Advisor Contact Cadence & Coverage Standards -> Advisor Capacity & Book Health
    "DP-395": "DP-394",   # Nudges & Recommendation Determinations -> Digital Engagement & Experiments
    "DP-396": "DP-392",   # Promotions & Client Referral Rewards -> Acquisition Funnel & Account Opening Conversion
    "DP-397": "DP-405",   # Voice of Client: Surveys & NPS -> Contact Center Operations
    "DP-411": "DP-410",   # Content Performance -> Campaign Performance & Spend
    "DP-413": "DP-410",   # Social Media & Brand Performance -> Campaign Performance & Spend
    "DP-401": "DP-398",   # Options & Margin Approval Oversight -> Principal Review Queue & Supervisory Approvals
    "DP-415": "DP-036",   # Marketing Rule Performance Substantiation -> Communications Review & FINRA Filing
    "DP-416": "DP-585",   # Frequent Trading & Market Timing Surveillance -> Intermediary Shareholder Requests: Rule 22c-2 and Beneficial Owner Distribution
    "DP-406": "DP-405",   # Service Request Fulfillment & Good-Order Quality -> Contact Center Operations
    "DP-407": "DP-382",   # Statements & Trade Confirmation Delivery -> Client Document & Delivery Record
    "DP-417": None,   # Client Tax Forms & Cost Basis Reporting (stands alone)
}
WP1_MOVED_READS = {

    "DP-383": [('01', 'Product Document', "DP-386"), ('01', 'Investment Commentary', "DP-386"), ('01', 'Commentary Approval', "DP-386")],
    "DP-387": [('03', 'Coverage Reassignment Item', "DP-388")],
    "DP-394": [('04', 'Nudge Delivery', "DP-389, DP-395"), ('04', 'Nudge Definition', "DP-395")],
    "DP-392": [('04', 'Promotion Offer', "DP-396"), ('04', 'Client Referral', "DP-396"), ('04', 'Promotion Enrollment', "DP-396, DP-417")],
    "DP-405": [('04', 'Client Survey', "DP-397")],
    "DP-410": [('04', 'Audience Restriction', "DP-411"), ('04', 'Asset Classification', "DP-411"), ('04', 'Social Media Account', "DP-413"), ('04', 'Social Post', "DP-413")],
    "DP-036": [('01', 'Performance Track Record', "DP-415"), ('04', 'Asset Compliance Reference', "DP-415")],
}
for _c in list(CANDIDATES) + list(globals().get("RESCOPED", [])):
    _bl = _c["id"] in WP1_BACKLOG_IDS
    _c["wp1"], _c["backlog"] = not _bl, _bl
    if _bl:
        _t = WP1_MERGES.get(_c["id"])
        _c["merge_into"] = _t
        _c["notes"] = (_c.get("notes", "") + " Backlog (WP1_Scope.md): not specified at WP1"
                       + (f"; overlaps {_t}, into which its scope folds if it is picked up." if _t else "; stands alone."))
    for _o in WP1_MOVED_READS.get(_c["id"], []):
        if (_o[0], _o[1]) not in _c["objects"]:
            _c["objects"].append((_o[0], _o[1]))
            _c["notes"] = _c.get("notes", "") + f" WP1 scope: also reads {_o[0]} {_o[1]} (from backlog {_o[2]})."
