"""WP0 product brief proposals: Fund Operations and Corporate Functions (FOP + CORP).

Brief: 00_Program/Rework/Product_Briefs/FOP_CORP_Fund_Operations_and_Corporate.md
Data Domains 27, 28, 29, 35 (FOP) and 19, 20, 37, 38, 39, 40, 41, 42, 43, 44 (CORP).
Reserved product IDs DP-580 to DP-639 (15 used: DP-580, DP-582, DP-583, DP-585 to DP-588, DP-592, DP-593, DP-595, DP-598,
DP-600, DP-602 to DP-604; DP-581, DP-584, DP-590, DP-591, DP-594, DP-596, DP-597 and DP-601 were drafted and withdrawn
as duplicates of BWO DP-446, CLA-B DP-418 (successor of DP-070), CLA-B DP-399, CLA-A DP-346, DP-224, CLA-B DP-039, CLA-B DP-390 and DIS
DP-503; the withdrawn ids are not registered and stay free). Reserved decision IDs CW-260 to CW-269 (CW-260 to CW-266 used), all "Proposed".
Wave codes as framework.py defines them (CW-201): "WP1F", "WP1C_FOP", "WP1C_CORP". candidate_coverage.py still accepts
only E1 to E5, so the check was run on a scratchpad copy of the checker with WAVES = framework.CANDIDATE_WAVES (brief
section 7).
Upstream names that are not DP- ids are WP1 foundational candidates of the framing agent (plan section 8.2 names):
"Client Holdings, Lots & Cost Basis" (49), "Client Orders & Executions" (48), "Money Movement Transactions" (50),
"Fee Schedules & Billing Runs" (47), replaced by DP-300, DP-301, DP-302 and DP-305 at the WP0 integration. Other briefs' candidates are cited by id (BWO DP-431, DP-445, DP-446, DP-450,
DP-451, DP-456, DP-457, DP-460; CLA-A DP-322, DP-346, DP-350; CLA-B DP-390, DP-399, DP-402, DP-409; DIS DP-497, DP-501, DP-503,
DP-509, DP-510; INV DP-538).
DISPOSITIONS uses the list-of-dicts format of the other WP0 briefs.
DP-008 (Client Assets & Net New Assets successor), DP-012 (client fee revenue) and DP-009 (advisor organization) are
cited by their kept ids.
Most of this area is already specified (75 live enterprise products); the RESPEC list and the dispositions are in the
brief section 3, and RESPEC below holds the same list in machine-readable form.
"""

HOLD = "DP-300"          # 49, framing agent WP1F
CORD = "DP-301"                  # 48, framing agent WP1F
MMV = "DP-302"                  # 50, framing agent WP1F
FEES = "DP-305"                # 47, framing agent WP1F

CANDIDATES = [
    dict(id='DP-580', name='Fund Share Register & Postings', tier='Foundational', type='Conformed Facts', domain='29',
         owner_role='Head of Transfer Agency', primary='FN-35', supporting=['FN-33', 'FN-65', 'FN-77', 'FN-67', 'FN-39', 'FN-36'], wave='WP1F',
         definition=("The transfer agent's book of record for every account registered at the TA (Rule "
                     '17Ad-10): the daily share register balance by registered account, share class and '
                     'business date (registered, collected, uncollected, escrowed or pledged and restricted '
                     'shares, by register account category) and every posted register transaction with its NAV'
                     ' record, gross and net amounts, sales charge, redemption fee, tax withheld and '
                     'originating order, AP order or distribution declaration. It is the single conformed '
                     'source the 06 Fund Shareholder Position view, the 49 stock record reconciliation, the '
                     'capital stock proof and the fund regulatory filings read; it carries shares only and '
                     'publishes no market value.'),
         objects=[('29', 'Share Register Balance'), ('29', 'Register Transaction'), ('27', 'Share Class NAV')],
         upstream=['DP-093', 'DP-004', 'DP-013', 'DP-165', 'DP-240'],
         notes=('Concept ownership row: share register and register postings, 29 (CW-122). Foundational '
                'because four live products (DP-177, DP-178, DP-179, DP-181) the candidates DP-582, DP-583, '
                'DP-585, DP-587 and DP-588 here, and BWO DP-446, DIS DP-494 and CLA-B DP-416 and DP-418 (successors of DP-084 and DP-070) read '
                'the register and none may re-conform it. Holdings book: none of the three (CW-007); the '
                "register is the TA's record and the 06 view reads it. The Broker-Dealer Omnibus rows are "
                'published with Register Account Category so that 06 and DP-008 exclude them from Client '
                'Assets (CW-122 ruling); the look-through is the 49 Client Holding. PII: register account and '
                'share counts are personal data (Confidential - Personal Data); a share-class aggregate view '
                'carries none. Operating model: in house (reference default) the TA platform is the source; '
                "outsourced, the provider's register file is a received record and Register Keeper names it; "
                'grain unchanged. Lever: networked sub-accounts (29 SME 2) add one row per sub-account. '
                'Proposed to the framing agent for the WP1 foundational wave (CW-261).')),
    dict(id='DP-582', name='Omnibus Aggregation, Forward-Pricing & Settlement Evidence', tier='Consumer-aligned', type='Regulatory & Control', domain='29',
         owner_role='Head of Transfer Agency', primary='FN-35', supporting=['FN-64', 'FN-68', 'FN-33', 'FN-44'], wave='WP1C_FOP',
         definition=('For each aggregated omnibus fund order, the client orders behind it with their 48 '
                     'receipt times against the dealing cut-off, the attested aggregation cut-off, purchase '
                     'and redemption totals, side netting, the resulting register posting and trade date, and '
                     'the omnibus settlement obligation and batch it settled in. Compliance uses it as the '
                     'Rule 22c-1 forward-pricing evidence for own-fund orders taken through the broker-dealer,'
                     ' and operations uses it to catch late aggregation, as-of postings, aggregation errors '
                     'and omnibus settlement differences.'),
         objects=[('29', 'Fund Order'), ('29', 'Brokerage Omnibus Order Detail'), ('29', 'Order Routing Detail'), ('29', 'TA Processing Calendar Event'), ('29', 'As-Of Order Detail'), ('29', 'Register Transaction'), ('48', 'Client Order'), ('48', 'Order Route'), ('29', 'Settlement Obligation'), ('29', 'Intermediary Settlement Batch')],
         upstream=['DP-177', 'DP-178', 'DP-580', CORD, 'DP-013'],
         notes=('Per-client Rule 22c-1 receipt evidence stays on the 48 Client Order; the 29 aggregates are '
                'Derived copies of 48 and are compared, not recomputed (29 Source_Notes section 2). DP-177 '
                'keeps all fund-order processing; this product only adds the omnibus aggregation layer that '
                'DP-177 cannot see. The 48 order lines carry client account keys: publish a share-class and '
                'cycle aggregate for wide use. The unit proof of the omnibus register against the 49 client '
                'holdings is BWO DP-446 (Stock Record Reconciliation & Security Counts) and the intermediary '
                'look-through is DIS DP-494; this product does not repeat either (the earlier DP-581 draft was'
                ' withdrawn for that reason).')),
    dict(id='DP-583', name='Shareholder Account Holds & Rule 2165 Restrictions', tier='Consumer-aligned', type='Regulatory & Control', domain='29',
         owner_role='Head of Transfer Agency', primary='FN-35', supporting=['FN-68', 'FN-66', 'FN-44', 'FN-62'], wave='WP1C_FOP',
         definition=('Every hold and restriction on a TA-registered account and its shares: restricted shares '
                     'on the register, the account restriction behind them, the monitoring alert and '
                     'disposition that placed it, FINRA Rule 2165 temporary holds on redemptions and transfers'
                     ' with trusted contact outreach and the senior investor case, and the age of each hold '
                     'against its release or extension date. Transfer agency, retail supervision and the '
                     'senior investor team use it to release or extend holds on time and to evidence the Rule '
                     '2165 conditions.'),
         objects=[('29', 'Account Monitoring Alert'), ('29', 'Alert Disposition'), ('29', 'Share Register Balance'), ('29', 'Register Transaction'), ('15', 'Account Restriction'), ('02', 'Trusted Contact Designation'), ('08', 'Senior Investor Case'), ('50', 'Money Movement Hold')],
         upstream=['DP-580', 'DP-180', 'DP-322', 'DP-456', 'DP-093', 'DP-240'],
         notes=('Special category (CD-344): Rule 2165 and elder-exploitation rows are published as a '
                'restricted view to the senior investor team and as counts only elsewhere; no '
                'diminished-capacity observation is read (02 Vulnerability Concern is not an input). Boundary:'
                ' holds on a cash movement are BWO DP-456 Fraud & Elder-Exploitation Holds (acceptance '
                'question 7), and the client protection register is CLA-A DP-322; this product reads 50 Money '
                'Movement Hold (through DP-456) only to link a redemption hold to the payment hold, never to '
                "count cash holds (CW-264). FINRA Rule 2165 hold length is 'confirm' (SR-FINRA-2026-018).")),
    dict(id='DP-585', name='Intermediary Shareholder Requests: Rule 22c-2 and Beneficial Owner Distribution', tier='Consumer-aligned', type='Operational', domain='29',
         owner_role='Head of Transfer Agency', primary='FN-35', supporting=['FN-74', 'FN-68', 'FN-67', 'FN-36'], wave='WP1C_FOP',
         definition=('The requests the TA makes of intermediaries that hold own-fund shares in omnibus '
                     'accounts: Rule 22c-2 shareholder information requests with response timeliness and the '
                     'trading restrictions they lead to, and the beneficial owner distribution and NOBO list '
                     'requests behind each shareholder communication and proxy. Transfer agency and the '
                     'intermediary channel use it to chase late intermediaries and to show the fund board that'
                     ' market-timing and distribution obligations were met.'),
         objects=[('29', 'Shareholder Information Request'), ('29', 'Intermediary Distribution Request'), ('29', 'NOBO List Request'), ('08', 'Frequent Trading Case'), ('13', 'Shareholder Communication'), ('13', 'Communication Distribution')],
         upstream=['DP-580', 'DP-177', 'DP-005', 'DP-240', 'DP-004'],
         notes=('Covers the two 29 objects with CDEs no live product reads. Frequent trading cases are 08 '
                '(CLA-B DP-416, the successor of DP-084, which this product feeds with the 22c-2 responses); '
                'this product counts restriction instructions sent, it does not score trading. Proxy tallies '
                "stay with CLA-B DP-408 (13; successor of DP-071). Thin channel: the intermediary profiles are 05 (CW-021 "
                'lever restores depth).')),
    dict(id='DP-586', name='Fund Fee Accrual Assurance', tier='Consumer-aligned', type='Regulatory & Control', domain='27',
         owner_role='Fund Treasurer', primary='FN-33', supporting=['FN-36', 'FN-78', 'FN-38', 'FN-35'], wave='WP1C_FOP',
         definition=("Daily proof that each fund's management, administration, 12b-1 and shareholder servicing"
                     ' accruals equal the board-approved rates and breakpoints of the 01 fund fee terms '
                     'applied to the NAV of record, that waivers and caps follow the expense limitation '
                     'agreement, and that sub-TA and omnibus servicing fees paid by the fund stay within the '
                     'Fund-Paid Sub-TA Fee Cap. The fund treasurer and the board use it to catch fee errors '
                     'before they become NAV errors.'),
         objects=[('27', 'Fund Expense Accrual'), ('27', 'Expense Cap & Waiver Accrual'), ('27', 'Fund Expense Payment'), ('27', 'Share Class NAV'), ('01', 'Management Fee'), ('01', 'Other Ongoing Fees'), ('35', 'Agreement Fund Schedule'), ('35', 'Board Resolution'), ('10', 'Waiver Record')],
         upstream=['DP-165', 'DP-170', 'DP-183', 'DP-004'],
         notes=('The fund fee terms are 01 (Fund Fee Schedule, FSCH-, typed Reference (Management Fee, 01)); '
                'the 47 client Fee Schedule is never read (CW-051). Expense ratios stay certified in DP-165 '
                '(CD-330); DP-170 keeps budgets, payments and cap management, this product only tests accrual '
                'against terms. A fee accrual breach over the NAV error threshold is raised as a 27 NAV Error '
                'Case in DP-169, not here. No personal data.')),
    dict(id='DP-587', name='Fund Share State Notice Filings & Sales by State', tier='Consumer-aligned', type='Regulatory & Control', domain='35',
         owner_role='Head of Fund Regulatory Reporting', primary='FN-36', supporting=['FN-78', 'FN-35', 'FN-38'], wave='WP1C_FOP',
         definition=('For every fund sold direct, the state notice filing obligations and filings (Securities '
                     "Act section 18 notices, renewals and sales reports) by state, with the fund's sales and "
                     'redemptions by shareholder state from the register and the brokerage book, the Rule '
                     '24f-2 net sales behind the registration fee, and the states where shares were sold '
                     'without a current notice. Fund regulatory reporting uses it to file and pay each state '
                     'on time and to block sales in a lapsed state.'),
         objects=[('35', 'Filing Obligation'), ('35', 'Fund Regulatory Filing'), ('29', 'Register Transaction'), ('15', 'Account'), ('02', 'Postal Address'), ('01', 'Distribution Availability')],
         upstream=['DP-580', 'DP-184', 'DP-093', 'DP-240', 'DP-004', HOLD],
         notes=('Fund-share state notice filings are 35 (CW-069); adviser and broker-dealer state '
                'registrations are 38 Entity Authorization rows and stay in DP-222. Brokerage-held own-fund '
                'sales are read through the 49 activity by account state, never from the omnibus register rows'
                ' (CW-122). Shareholder state is derived from the 02 address; publish state totals only (no '
                'personal data in the product). Lever: a firm that sells only through intermediaries takes '
                "state sales from the intermediaries' reports.")),
    dict(id='DP-588', name='Fund Distribution Payment & Reinvestment Posting Control', tier='Consumer-aligned', type='Regulatory & Control', domain='29',
         owner_role='Head of Transfer Agency', primary='FN-35', supporting=['FN-33', 'FN-65', 'FN-67'], wave='WP1C_FOP',
         definition=('For each declared fund distribution, proof that every registered account on the record '
                     'date received its reinvestment or cash posting at the reinvest NAV, that the omnibus '
                     'distribution was allocated to every brokerage client holding, and that the total posted '
                     'ties to the declared amount. Transfer agency and fund accounting use it to close each '
                     'distribution cycle without unallocated residue.'),
         objects=[('27', 'Distribution Declaration'), ('29', 'Register Transaction'), ('29', 'Share Register Balance'), ('49', 'Dividend Reinvestment Allocation'), ('49', 'Client Corporate Action Entitlement'), ('15', 'Account Standing Instruction')],
         upstream=['DP-580', 'DP-171', HOLD, 'DP-093'],
         notes=("Distribution amounts and character are DP-171's (27); this product tests posting "
                'completeness. Books: register (29) for TA accounts and the omnibus, Client Holding (49) for '
                'the look-through. Personal data only in the account-level exception list.')),
    dict(id='DP-592', name='Employee Brokerage Accounts & Personal Trading Coverage', tier='Consumer-aligned', type='Regulatory & Control', domain='38',
         owner_role='Chief Compliance Officer', primary='FN-44', supporting=['FN-41', 'FN-65', 'FN-64'], wave='WP1C_CORP',
         definition=("Matches every access person's reportable accounts to the accounts the firm's own "
                     'broker-dealer carries for employees and their households, and shows the in-house '
                     'holdings and executions feeding the code of ethics, outside-broker duplicate statements,'
                     ' unreported in-house accounts and pre-clearance breaches. Compliance uses it to prove '
                     'complete personal trading coverage (Rule 204A-1, Rule 17j-1, FINRA Rule 3210).'),
         objects=[('38', 'Personal Trading Account'), ('38', 'Reported Personal Holding'), ('38', 'Personal Transaction'), ('38', 'Conduct Population Designation'), ('38', 'Pre-Clearance Request'), ('15', 'Account Party Role'), ('20', 'Employee'), ('49', 'Client Holding'), ('48', 'Client Execution')],
         upstream=['DP-225', 'DP-192', 'DP-093', 'DP-240', HOLD, CORD],
         notes=('Ruling 1 of 38: an employee account at the own broker-dealer is a 15 Account and its holdings'
                ' and trades are Derived copies of 49 and 48 (CW-266). Books: Client Holding (49). DP-225 '
                'keeps violations and conflicts; this product is the coverage proof. Restricted - Personal '
                'Data: compliance population only.')),
    dict(id='DP-593', name='Government Client Pay-to-Play Exposure', tier='Consumer-aligned', type='Regulatory & Control', domain='38',
         owner_role='Chief Compliance Officer', primary='FN-44', supporting=['FN-75', 'FN-71', 'FN-73'], wave='WP1C_CORP',
         definition=("Covered associates' political contributions against the government entities the firm "
                     'advises or recordkeeps for (public plans, OCIO mandates, 529 programs), with the de '
                     'minimis, return and look-back tests, any two-year time-out and the fees it puts at risk.'
                     ' Compliance and the institutional and workplace businesses use it before soliciting or '
                     'renewing a government client (Rule 206(4)-5, FINRA Rule 2030, MSRB Rule G-37).'),
         objects=[('38', 'Political Contribution'), ('38', 'Pay-to-Play Review'), ('38', 'Conduct Population Designation'), ('12', 'Institutional Client'), ('16', 'Plan Sponsor Profile'), ('03', 'Advisor'), ('47', 'Billing Arrangement')],
         upstream=['DP-225', 'DP-009', 'DP-094', FEES, 'DP-192'],
         notes=('Government-entity status is read from 12 Institutional Client and 16 Plan Sponsor Profile (W4'
                ' re-point); fees at risk are the 47 billing arrangement terms, never revenue (revenue is '
                'DP-012). Lever: drop G-37 if no municipal fund securities (38 SME 4). Restricted - Personal '
                'Data.')),
    dict(id='DP-595', name='Client Data Safeguards: Reg S-P, Reg S-ID & Customer Notification', tier='Consumer-aligned', type='Regulatory & Control', domain='41',
         owner_role='Chief Information Security Officer', primary='FN-51', supporting=['FN-44', 'FN-62', 'FN-46', 'FN-42'], wave='WP1C_CORP',
         definition=('The information security and identity theft programs that cover each entity holding '
                     'client data, the security incidents involving client information with the 30-day '
                     'customer notification test of amended Regulation S-P, the regulatory notifications made,'
                     " and the service providers whose incidents reach the firm's clients. The CISO and "
                     'compliance use it for the Reg S-P and Reg S-ID program reviews and the board report.'),
         objects=[('41', 'Information Security Program'), ('41', 'Security Incident Detail'), ('41', 'IT Incident'), ('38', 'Compliance Program Review'), ('38', 'Policy'), ('37', 'Incident Regulatory Notification'), ('40', 'Outsourcing Arrangement')],
         upstream=['DP-232', 'DP-219', 'DP-224', 'DP-210', 'DP-211', 'DP-215'],
         notes=('Covers 41 Information Security Program (no live reader). Privacy oversight is 38, safeguards '
                'and incidents 41, consents 02, notices 13 (CW-029, CW-163). Incident counts only; no client '
                'record is read. Confirm the Reg S-P compliance dates for a larger entity.')),
    dict(id='DP-598', name='Client Revenue Recognition & Ledger Tie-Out', tier='Consumer-aligned', type='Regulatory & Control', domain='19',
         owner_role='Finance Controller', primary='FN-38', supporting=['FN-72', 'FN-39', 'FN-66'], wave='WP1C_CORP',
         definition=("Ties the month's client revenue records (advisory and account fees, commissions, sweep "
                     'and program bank fees, fully paid lending) to their ASC 606 performance obligations, the'
                     ' fee debits and invoices behind them, and the ledger postings and receivables in 19, '
                     'with the unposted, mis-mapped and late-closed items. The controller uses it to close '
                     'revenue and to explain the revenue line to the certified client revenue of DP-012.'),
         objects=[('19', 'GL Posting'), ('19', 'Journal Entry'), ('19', 'Receivable Item'), ('19', 'Accounting Period Status'), ('10', 'Client Revenue Record'), ('10', 'Cash Program Economics'), ('10', 'Revenue Contract'), ('10', 'Performance Obligation'), ('47', 'Fee Debit'), ('47', 'Fee Invoice')],
         upstream=['DP-191', 'DP-190', 'DP-012', FEES, 'DP-350'],
         notes=("Client fee revenue is certified once, in re-scoped DP-012 (CW-011 family 'revenue as today');"
                ' this product tie-outs and never publishes a revenue total of its own (CW-265). Program bank '
                'economics are 10 Cash Program Economics, read here only for their ledger posting; analytics '
                'stay with DIS DP-501 and DP-497. Client Revenue Record is account-grain personal data: the '
                'ledger view is by entity, stream and GL account.')),
    dict(id='DP-600', name='Customer Reserve Funding & Program Bank Exposure', tier='Consumer-aligned', type='Operational', domain='43',
         owner_role='Group Treasurer', primary='FN-40', supporting=['FN-65', 'FN-66', 'FN-42', 'FN-38'], wave='WP1C_CORP',
         definition=("Treasury's view of the cash the broker-dealer must place in its special reserve bank "
                     'accounts after each approved reserve computation (deposit or withdrawal due, deadline, '
                     'balance on hand by bank), the corporate cash that funds it, and the concentration of '
                     "client sweep deposits by program bank against the firm's bank exposure limits. The "
                     'treasurer uses it to fund reserve deposits on time and to manage program bank '
                     'counterparty risk.'),
         objects=[('43', 'Corporate Bank Account'), ('43', 'Bank Statement Entry'), ('43', 'Cash Position'), ('43', 'Cash Forecast Line'), ('49', 'Reserve Computation'), ('50', 'Program Bank'), ('50', 'Program Bank Daily Total'), ('50', 'Sweep Program')],
         upstream=['DP-202', 'DP-205', 'DP-445', 'DP-431'],
         notes=("The reserve computation is 49's and is published by BWO DP-445 Customer Reserve & "
                'Possession-and-Control Control Pack (acceptance question 6); this product reads the approved '
                "computation's requirement and deposit amounts and never recomputes them (CW-262). Program "
                'bank deposits are client money, not corporate cash: they are exposure here, never a 43 Cash '
                'Position. Customer reserve bank accounts are 43 Corporate Bank Accounts referenced by 49. No '
                'personal data (program-level totals). Sweep allocation and program bank allocation operations'
                ' are BWO DP-457; economics DIS DP-501.')),
    dict(id='DP-602', name='Client-Impacting Incidents & Remediation', tier='Consumer-aligned', type='Regulatory & Control', domain='37',
         owner_role='Head of Operational Risk', primary='FN-42', supporting=['FN-67', 'FN-65', 'FN-64', 'FN-35', 'FN-33'], wave='WP1C_CORP',
         definition=('Operational incidents that harmed clients or shareholders (trade errors, servicing '
                     'errors, NAV errors, missed corporate actions, sweep misallocations) with their loss '
                     'events, the client remediation paid or owed, and the risk issues raised. Operational '
                     'risk and the business heads use it to see client harm by cause and to close remediation.'),
         objects=[('37', 'Operational Incident'), ('37', 'Operational Loss Event'), ('37', 'Loss Event Amount'), ('37', 'Risk Issue'), ('13', 'Servicing Error'), ('13', 'Shareholder Remediation'), ('48', 'Trade Error Case'), ('27', 'NAV Error Case')],
         upstream=['DP-215', 'DP-216', 'DP-169', 'DP-409', 'DP-437', 'DP-240'],
         notes=('Loss amounts are certified in DP-215; servicing errors and remediation are CLA-B DP-409 and '
                'trade errors BWO DP-437, read through them. This product is the risk view across them: client'
                ' harm linked to the 37 incident, loss and issue, by cause and business line; it counts no '
                'error twice and holds no remediation record. Remediation rows are client personal data; risk '
                'committee views are aggregates. Reviewer challenge: fold into DP-215 if the incident links '
                'suffice.')),
    dict(id='DP-603', name='Customer Financing Funding: Margin Debits, Stock Loan & Bank Lines', tier='Consumer-aligned', type='Analytical', domain='43',
         owner_role='Group Treasurer', primary='FN-40', supporting=['FN-65', 'FN-42', 'FN-38'], wave='WP1C_CORP',
         definition=('How the self-clearing broker-dealer funds customer margin debits and short sales: the '
                     'debit balances and margin calls of the brokerage book, the fully paid lending and '
                     'collateral that offset them, and the corporate debt facilities, drawdowns and covenant '
                     'tests that fund the rest. The treasurer uses it to size bank lines and to see funding '
                     'headroom before margin balances grow.'),
         objects=[('43', 'Debt Facility'), ('43', 'Debt Facility Drawdown'), ('43', 'Corporate Covenant Test'), ('43', 'Cash Position'), ('49', 'Margin Balance Snapshot'), ('49', 'Client Margin Call'), ('49', 'Fully Paid Securities Loan')],
         upstream=['DP-202', 'DP-203', 'DP-205', 'DP-450', 'DP-451'],
         notes=('Margin balances and calls are BWO DP-450, fully paid lending DP-451; read as program-level '
                'totals, never by account. Customer debits enter the reserve formula in DP-445 and are not '
                're-derived here (CW-262). Lever: a firm without margin or fully paid lending drops the '
                'product (plan section 15.3). No personal data.')),
    dict(id='DP-604', name='Fidelity Bond & Excess SIPC Coverage Adequacy', tier='Consumer-aligned', type='Regulatory & Control', domain='43',
         owner_role='Group Treasurer', primary='FN-40', supporting=['FN-36', 'FN-65', 'FN-42'], wave='WP1C_CORP',
         definition=("Tests the firm's protection coverage against what it must cover: each fund's fidelity "
                     "bond against the Rule 17g-1 minimum for its gross assets, the broker-dealer's fidelity "
                     "bond against FINRA Rule 4360, and the excess SIPC policy's aggregate and per-account "
                     'limits against client assets and the largest client accounts. Treasury and fund legal '
                     'use it before each renewal and when assets grow past a threshold.'),
         objects=[('43', 'Corporate Insurance Policy'), ('43', 'Insurance Coverage Layer'), ('35', 'Fund Fidelity Bond'), ('27', 'Fund NAV Calculation'), ('06', 'Account Asset Summary')],
         upstream=['DP-206', 'DP-182', 'DP-165', 'DP-008'],
         notes=('Fund gross assets come from DP-165 (NAV of record) and client assets from the DP-008 '
                'successor (certified Client Assets by account band), never summed from holdings. Fund '
                'Fidelity Bond is 35 and approved by the board (DP-182); this product tests adequacy only. '
                'Account-level rows are personal data: publish by band.')),
]

# Pending products owned by this group (RESCOPE_PENDING) and the dispositions other briefs asked this brief to record.
DISPOSITIONS = [
    {"id": 'DP-083', "disposition": 'Re-scope', "successor": 'DP-083', "decision": 'CW-260',
     "reason": ('Live DP-246 and DP-248 list DP-083 upstream, so the id is kept and re-scoped in place (the '
                "WP0 disposition rule). New name 'Regulatory Obligations & Attestations': the obligation "
                'register by legal entity (FINRA Rules 3110, 3120, 3130; Advisers Act Rules 204A-1, 206(4)-7; '
                'Rule 38a-1; Reg S-P, Reg S-ID; 31 CFR 1023 and 1032) with its owner and the attestations '
                'against it. The horizon tile retires into DIS+FDN DP-509 Regulatory Horizon & Change Watch '
                '(agreed); the FCA SYSC, SM&CR and DP-041 passport inputs drop (CW-938). Primary FN-44; '
                'supporting FN-68, FN-36, FN-43. Upstreams DP-013, DP-009, DP-004, DP-224, DP-192.'),
     "objects": [('38', 'Regulatory Obligation'), ('38', 'Attestation'), ('38', 'Entity Authorization'), ('09', 'Internal Legal Entity'), ('20', 'Employee'), ('20', 'Employee Reporting Line')]},
    # DP-092 Institutional Client 360 is owned by 03: its one disposition is CLA-B's (retire into DP-243 and DIS+FDN DP-510,
    # CW-220); this group's duplicate entry was removed at the WP0 integration.
]

# Live enterprise products whose scope changed at W1b to W4: the WP1 re-specification each needs (brief section 3).
RESPEC = {
    'DP-165': ('Re-point supporting functions (FN-15, FN-10, FN-12, FN-14, FN-01 retired) to FN-77, FN-78, '
                'FN-72, FN-36; record the Firm AUM fund slice under CW-011; managed-account slice is 46/18 '
                '(not here).'),
    'DP-166': 'No scope change; confirm ABOR inputs after the 27 W1b drops.',
    'DP-167': ('Supporting FN-14, FN-26 dropped; 28 safekeeping accounts include the 29 fund cash accounts '
                'read by DP-178; custody of client assets is 49 (CW-007), never read here.'),
    'DP-168': ('Add Price & Rate Transmission Broker-Dealer Pricing Feed to the release checks and the '
                'capital stock proof from DP-580 through DP-181; FN-15 to FN-77.'),
    'DP-169': ('DP-043 succeeded by CLA-B DP-405 and DP-409: re-point the servicing-error read to DP-409; '
                'as-of dilution adds Broker-Dealer Aggregation Error (29 As-Of Reason).'),
    'DP-170': ('Fee terms are 01 Management Fee (FSCH-, CW-051) and 10 Waiver Record (CW-159); '
                'accrual-to-terms testing moves to DP-586; FN-12, FN-10 to FN-78, FN-72.'),
    'DP-171': 'Read reinvestment postings from DP-580 (completeness moves to DP-588).',
    'DP-172': 'No scope change; 49 Stock Record Reconciliation is not a 28 break (DP-581).',
    'DP-173': 'No scope change for fund assets; client corporate actions are 49 (BWO).',
    'DP-174': 'No scope change for fund lending; client fully paid lending is 49 (BWO).',
    'DP-175': 'Retired by the framing agent (CW-207); DP-172 keeps the reconciliation runs.',
    'DP-176': ('Servicing Provider Engagement now 29 (CW-088); DP-043 succeeded (CLA-B): outsourced-TA '
                'oversight stays here (sub-TA role, SOC 1 date, provider service levels).'),
    'DP-177': ('Add 29 Brokerage Omnibus Order Detail and Order Origin values (Affiliated Broker-Dealer '
                'Omnibus, Cash Sweep Run); Resulting Transaction is Register Transaction (DP-580 upstream); '
                'DP-079 is re-scoped in place by CLA-B (keep) and DP-001, DP-006 upstreams after their '
                're-scope; FN-13, FN-08, FN-18 dropped.'),
    'DP-178': ('Cash Movement names the 50 Money Movement (CW-107); add Money Movement Transactions upstream;'
                ' Obligation Amount mastered in 29.'),
    'DP-179': ('AP Resulting Transaction is Register Transaction; AP Agreement re-points to 05; FN-04 '
                'dropped.'),
    'DP-180': ('CIP from 02 Identity Verification (CW-124); DP-077 and DP-085 re-scoped in place by CLA-A and'
                ' CLA-B (keep the ids); payment-only alerts are 50 (BWO DP-460); register holds move to '
                'DP-583.'),
    'DP-181': ('Capital Stock Proof sums Share Register Balance: add DP-580 upstream and the 29 Share '
                'Register Balance input.'),
    'DP-182': 'W4 drop of Board Consent Record; no further change.',
    'DP-183': ('Add 52 Section 15(c) Renewal Submission and read INV DP-538 for sub-advised funds (acceptance'
                ' question 12); replace pending upstreams DP-059, DP-035, DP-030, DP-071 with DP-165, DP-012, '
                'DIS DP-506 and DP-538; FN-10, FN-12 to FN-70, FN-72.'),
    'DP-184': 'State notice filings detail moves to DP-587; keep the calendar.',
    'DP-185': ('N-CEN items for the affiliated transfer agent, principal underwriter and broker-dealer; '
                'N-PORT unchanged; Form N-MFP for the sweep money market funds.'),
    'DP-186': "Framing agent's re-scope to Form PF for the alternative-access feeder funds.",
    'DP-190': 'Journal Source values for 10 client revenue; FN-12 dropped.',
    'DP-191': ('Client revenue postings from 10 (GL Posting sourced from Client Revenue Record and Cash '
                'Program Economics); tie-out in DP-598.'),
    'DP-192': 'FN-08, FN-11, FN-13 to FN-73, FN-68; advisor organization is DP-009 (03).',
    'DP-193': ('Consolidation scope gains the broker-dealer, TA, recordkeeper and trust company entities; '
                'seed holdings unchanged.'),
    'DP-194': 'Function re-point only (see _functions).',
    'DP-195': ('Receivable Item.Source Fee Invoice is the 47 Fee Invoice (CW-051, CW-912); FN-14, FN-17 '
                'dropped. Client fee receivables (47 Fee Invoice) read through CLA-A DP-350.'),
    'DP-196': ('Upstream DP-074 superseded by DIS DP-503 Intercompany Charges & Transfer Pricing: re-point; '
                'VAT treatment dropped (CW-910).'),
    'DP-197': 'Function re-point only (see _functions).',
    'DP-198': ('Reads 03 Compensation Statement (CW-062); upstream DP-033 (07 retired): re-point to CLA-B '
                'DP-390 Incentive Plan Governance & Advisor Payouts; DP-198 keeps the certified pay; FN-11 to '
                'FN-73.'),
    'DP-199': "Framing agent's re-scope (deferred awards without the remuneration code).",
    'DP-200': ('DP-039 is re-scoped in place by CLA-B (keep the id); registered-role eligibility reads '
                'DP-039.'),
    'DP-202': ('Customer reserve bank accounts are corporate bank accounts referenced by 49; reserve funding '
                'view in DP-600.'),
    'DP-203': 'Customer financing funding view in DP-603; no input change.',
    'DP-204': 'Private-markets seed dropped (CW-930, CW-166); FN-26, FN-10 to FN-78.',
    'DP-205': ('Rename to Regulatory Capital: Broker-Dealer Net Capital & Trust Company Capital; add the 49 '
                'Reserve Computation reference for the alternative standard; add FOCUS, Rule 17a-5 annual '
                'reports, Form Custody and SIPC assessments as Regulatory Financial Return types.'),
    'DP-206': 'Excess SIPC and fidelity bond policies named in the definition; adequacy tests in DP-604.',
    'DP-209': ("Upstream DP-038 pending: replace with the conduct brief's gifts successor; FN-13, FN-12, "
                'FN-26, FN-01 dropped.'),
    'DP-210': ('Servicing Provider Engagement now 29; program banks are 50 parties, read as vendors only '
                'where a service agreement exists.'),
    'DP-213': ('Client account agreements are 15; contract register keeps firm contracts; FN-04, FN-17, FN-26'
                ' dropped.'),
    'DP-215': 'Client-impacting incident view in DP-602; no input change.',
    'DP-217': "Framing agent's re-scope (US critical functions).",
    'DP-219': 'Add program banks, sub-transfer agents and clearing utilities to the critical provider tiers.',
    'DP-220': "Framing agent's re-scope (outsourcing register without DORA).",
    'DP-222': ('Add the TA-1, TA-2, Form CRS (Form CRS Filing Detail: version, filer capacity, website '
                'posting) and ADV-E filing types and the state BD and RIA notice rows; Form CRS delivery is '
                'CLA-B DP-399, custody-rule evidence CLA-A DP-346.'),
    'DP-224': ('Add the Rule 3120 report, Rule 3130 certification, Rule 38a-1 annual report and PTE 2020-02 '
                'retrospective review as Compliance Program Review types with their sign-off; read CLA-B '
                'DP-402 for the supervisory tests and findings behind them; obligations and attestations stay '
                'in DP-083 (re-scoped).'),
    'DP-225': ('Firm Brokerage Account rows are Derived copies of 49 and 48 (CW-266); coverage in DP-592, '
                'pay-to-play exposure in DP-593; FN-05, FN-25 dropped.'),
    'DP-226': ('Add the BD, TA, trust and adviser (2028) program rows and 314(a) match reports; read BWO '
                'DP-460 for 50 alerts and case-less OFAC reports; DP-077 kept (re-scoped by CLA-A).'),
    'DP-227': 'MNPI Escalation.Source Deal dropped (CW-930); FN-25 dropped.',
    'DP-228': "Framing agent's re-scope (trade surveillance and AML escalation, CW-163).",
    'DP-229': 'Add FINRA customer arbitration matters linked to 08 Complaint.',
    'DP-232': 'Client data incidents feed DP-595.',
    'DP-233': 'Upstream DP-044 pending: re-point to the 14 successor.',
    'DP-234': 'Function re-point only (see _functions).',
    'DP-236': 'Upstreams DP-036, DP-030 pending: re-point to their successors.',
    'DP-241': ('Successor reconciliation of Client Assets (DP-008 successor) to Firm AUM (CW-011), netting '
                'the own-fund overlap (06 Client Asset Measures) and checking omnibus units through BWO '
                'DP-446; coordinate with the framing agent.'),
    'DP-246': 'Upstream DP-083 kept (re-scoped in place, CW-260).',
    'DP-247': 'Function re-point only (see _functions).',
    'DP-248': 'Upstream DP-083 kept (re-scoped in place, CW-260).',
    '_functions': ('Every product: replace retired supporting functions per framework.py: FN-01 to FN-79 Business'
                ' Line Leadership & Strategy; FN-08 and FN-11 to FN-73; FN-10 to FN-78; FN-12 to FN-72; FN-13 '
                'to FN-68; FN-15 to FN-77; drop FN-04, FN-05, FN-09, FN-14, FN-16, FN-17, FN-18, FN-25, FN-26.'),
}

DECISIONS = [
    {
     'id': 'CW-260',
     'theme': 'Products',
     'title': ('DP-083 is re-scoped in place to Regulatory Obligations & Attestations; its horizon tile '
                'retires into DP-509'),
     'domains': ['38', '11', '20'],
     'issue': ('DP-083 is the only pending product owned by a FOP or CORP domain. Live DP-246 and DP-248 list'
                " it upstream; its horizon tile read the 11 Regulatory Horizon Item, now DIS+FDN DP-509's."),
     'resolution': ('Proposed: keep DP-083 (live products depend on its id) as Regulatory Obligations & '
                     'Attestations: the 38 obligation register by legal entity with owners and attestations. '
                     'Horizon measures go to DP-509; compliance program reviews and policies stay DP-224. The '
                     'UK SYSC and SM&CR obligations and the DP-041 passport input drop.'),
     'rationale': 'The WP0 disposition rule: re-scope in place only when live products depend on the id.',
     'action': 'WP1 re-specification (WP1C_CORP)',
     'status': 'Proposed',
     'priority': 'Medium',
     'owner_role': 'Program lead',
    },
    {
     'id': 'CW-261',
     'theme': 'Products',
     'title': 'The fund share register is published once, by DP-580 Fund Share Register & Postings',
     'domains': ['29', '06', '49', '27'],
     'issue': ('CW-122 made 29 the master of the share register, but no product conforms it; DP-177, DP-178, '
                'DP-181 and the 06 view each need it.'),
     'resolution': ('Proposed: DP-580 (Foundational, WP1F) is the only product that publishes Share Register '
                     'Balance and Register Transaction. It carries shares and amounts posted, never market '
                     'value or Client Assets; the Broker-Dealer Omnibus rows are flagged by Register Account '
                     'Category so DP-008 and the 06 view exclude them.'),
     'rationale': ('One conformed register avoids four readers re-deriving balances; it keeps the register '
                    'distinct from the three books of record.'),
     'action': 'WP1 foundational wave',
     'status': 'Proposed',
     'priority': 'High',
     'owner_role': 'Program lead',
    },
    {
     'id': 'CW-262',
     'theme': 'Certified numbers',
     'title': 'Corporate products read the approved customer reserve computation; they never recompute it',
     'domains': ['49', '43', '19'],
     'issue': ('43 Capital Requirement Calculation (alternative standard), 19 regulatory returns and treasury'
                ' funding all need reserve figures that 49 masters.'),
     'resolution': ('Proposed: the reserve requirement, deposit on hand and deposit or withdrawal amount are '
                     'published by the BWO control pack from the approved 49 Reserve Computation; DP-205, '
                     'DP-600 and any FOCUS view read them by reference and compare, never recompute.'),
     'rationale': 'One owner per number (plan section 11).',
     'action': 'WP1',
     'status': 'Proposed',
     'priority': 'High',
     'owner_role': 'Program lead',
    },
    {
     'id': 'CW-263',
     'theme': 'Boundaries',
     'title': ('Custody-rule evidence is published once, in CLA-A DP-346; 38 keeps the status records and the'
                ' ADV-E filing'),
     'domains': ['38', '47', '49'],
     'issue': ('Acceptance question 8 spans 47 billing and 38 custody status; both briefs drafted a product '
                'reading 38 Adviser Custody Profile.'),
     'resolution': ('Proposed: CLA-A DP-346 Fee Billing Accuracy & Custody-Rule Evidence publishes the '
                     'custody status, surprise examinations and the fee-deduction population with the billing '
                     'evidence; DP-222 keeps the Form ADV-E filing timeliness. The FOP+CORP draft DP-591 is '
                     'withdrawn.'),
     'rationale': 'One product per evidence pack; the 38 owner reviews the status measures of DP-346.',
     'action': 'WP1',
     'status': 'Proposed',
     'priority': 'Medium',
     'owner_role': 'Chief Compliance Officer',
    },
    {
     'id': 'CW-264',
     'theme': 'Boundaries',
     'title': 'Holds on registered shares are DP-583; holds on cash movements are the BWO holds product',
     'domains': ['29', '50', '15', '08'],
     'issue': 'A Rule 2165 hold can sit on a redemption (29) and on the payment (50).',
     'resolution': ('Proposed: DP-583 counts holds on TA-registered accounts and redemptions and links the 50'
                     ' hold; BWO DP-456 counts cash-movement holds and CLA-A DP-322 keeps the protection '
                     'register (acceptance question 7). Both publish special-category rows only as a '
                     'restricted view (CD-344).'),
     'rationale': 'Avoids double-counting holds.',
     'action': 'WP1',
     'status': 'Proposed',
     'priority': 'Medium',
     'owner_role': 'Program lead',
    },
    {
     'id': 'CW-265',
     'theme': 'Certified numbers',
     'title': 'Client revenue is certified in re-scoped DP-012; DP-598 is a ledger tie-out only',
     'domains': ['10', '19', '47'],
     'issue': ('19 now posts client revenue from 10 records, so a finance product could publish a second '
                'revenue total.'),
     'resolution': ('Proposed: DP-598 publishes the differences between 10 revenue records, 47 billing '
                     '(through DP-350) and 19 postings, and the posted amount by GL account; the certified '
                     'revenue measures stay in DP-012 and the yield analytics in DIS DP-497 and DP-501.'),
     'rationale': 'CW-011: revenue as today, one product.',
     'action': 'WP1',
     'status': 'Proposed',
     'priority': 'Medium',
     'owner_role': 'Program lead',
    },
    {
     'id': 'CW-266',
     'theme': 'Boundaries',
     'title': ('Employee accounts at the own broker-dealer are read from 49 and 48 through their foundational'
                ' products'),
     'domains': ['38', '15', '48', '49'],
     'issue': '38 ruling 1 makes in-house employee holdings and trades Derived copies of 49 and 48.',
     'resolution': ('Proposed: DP-225 and DP-592 take in-house rows from the Client Holdings and Client '
                     'Orders foundational products and outside-broker rows from 38; neither republishes client'
                     ' holdings outside the compliance population.'),
     'rationale': 'One source for in-house rows, restricted publication.',
     'action': 'WP1',
     'status': 'Proposed',
     'priority': 'Low',
     'owner_role': 'Chief Compliance Officer',
    },
]


# ---- WP1 scope (WP0 rationalization, 2026-10-15; Product_Briefs/WP1_Scope.md) ------------------------------
# Program-lead ruling: every candidate is flagged wp1=True (specified at WP1) or backlog=True (registered in
# framework.WAVE_BACKLOG, status 'backlog', not specified at WP1; ids unchanged). WP1_MERGES names the product a
# backlog candidate overlaps (its scope folds in there if it is picked up). WP1_MOVED_READS: objects with CDEs that
# only a backlog candidate read, now read by the named WP1 product (coverage rule; WP1 specs read them).
WP1_BACKLOG_IDS = ["DP-582", "DP-587", "DP-592", "DP-593", "DP-602", "DP-603", "DP-604"]
WP1_MERGES = {

    "DP-582": None,   # Omnibus Aggregation, Forward-Pricing & Settlement Evidence (stands alone)
    "DP-587": None,   # Fund Share State Notice Filings & Sales by State (stands alone)
    "DP-592": "DP-225",   # Employee Brokerage Accounts & Personal Trading Coverage -> live DP-225
    "DP-593": None,   # Government Client Pay-to-Play Exposure (stands alone)
    "DP-602": "DP-215",   # Client-Impacting Incidents & Remediation -> live DP-215
    "DP-603": "DP-600",   # Customer Financing Funding: Margin Debits, Stock Loan & Bank Lines -> Customer Reserve Funding & Program Bank Exposure
    "DP-604": None,   # Fidelity Bond & Excess SIPC Coverage Adequacy (stands alone)
}
WP1_MOVED_READS = {

    "DP-600": [('49', 'Client Margin Call', "DP-401, DP-450, DP-603")],
    "DP-598": [('10', 'Contract Cost Asset', "DP-504"), ('10', 'Capitalization Assessment', "DP-504")],
}
for _c in list(CANDIDATES) + list(globals().get("RESCOPED", [])):
    _bl = _c["id"] in WP1_BACKLOG_IDS
    _c["wp1"], _c["backlog"] = not _bl, _bl
    if _bl:
        _t = WP1_MERGES.get(_c["id"])
        _c["merge_into"] = _t
        _c["notes"] = (_c.get("notes", "") + " Backlog (WP1_Scope.md): not specified at WP1"
                       + (f"; overlaps {_t}, into which its scope folds if it is picked up." if _t else "; stands alone."))
    for _o in WP1_MOVED_READS.get(_c["id"], []):
        if (_o[0], _o[1]) not in _c["objects"]:
            _c["objects"].append((_o[0], _o[1]))
            _c["notes"] = _c.get("notes", "") + f" WP1 scope: also reads {_o[0]} {_o[1]} (from backlog {_o[2]})."
