"""WP0 product brief proposals: Investment and Investment Operations (group INV+IOP) of the wealth-manager model.

Brief: 00_Program/Rework/Product_Briefs/INV_IOP_Investment_and_Investment_Operations.md
Data Domains: 23 Investment Research, 24 Portfolio Management & Construction, 25 Trading & Execution, 34 Stewardship &
Sustainable Investing, 52 External Manager & Sub-Adviser Oversight, 18 Portfolio & Investment Book of Record,
22 Market Data & Pricing, 26 Trade Operations, Settlement & Collateral, 31 Investment Risk, 32 Performance &
Attribution, 33 Investment Compliance.
Reserved product IDs DP-530 to DP-579 (DP-530 to DP-544 used); reserved decision IDs CW-250 to CW-259 (CW-250 to
CW-257 used, status Proposed). Waves: "WP1F" (foundational) and "WP1C" (consumer); framework.py defines no WP1 wave
codes yet and candidate_coverage.py accepts only E1 to E5, so the check was run on a patched scratchpad copy that adds
the two codes (brief section 7).
Check: /usr/bin/python3 data_products/candidate_coverage.py proposals_wdp_inv_iop  (from _tools; patched WAVES)

Upstream names that are not DP- ids are WP1 foundational candidates of the parallel briefs, by the plan section 8.2
names: "Manager & Sub-Adviser Master" (52, WP0 framing agent, DP-30x); "Client Holdings, Lots & Cost Basis" (49);
"Client Orders & Executions" (48); "Managed Account Model Assignments" (46); "Advice Plans & Recommendations" (45).
Replaced by their ids (DP-306, DP-300, DP-301, DP-304, DP-303) at the WP0 integration.

Besides CANDIDATES and DECISIONS this module carries DISPOSITIONS (pending and WP0 re-scope products whose owner domain
is in the group) and RESPEC (live enterprise products of the group whose scope changed at W1b to W4, with the WP1
re-specification each needs). Neither is read by candidate_coverage.py.
"""

MGR = "DP-306"          # 52, WP0 framing agent (DP-30x)
CHB = "DP-300"    # 49 brokerage book of record (CW-007)
COE = "DP-301"            # 48
MAA = "DP-304"     # 46
APR = "DP-303"        # 45

CANDIDATES = [
    # ================================================ Foundational (WP1F) ================================================
    dict(id="DP-530", name="Capital Market Assumptions, Model Lineups & Model Weights", tier="Foundational",
         type="Master & Reference", domain="24", owner_role="Chief Investment Officer", primary="FN-21",
         supporting=["FN-60", "FN-61", "FN-63", "FN-71", "FN-74", "FN-30", "FN-70"], wave="WP1F",
         definition="The approved capital market assumption sets (expected returns, volatilities and correlations by "
                    "asset class and horizon), the advice model lineups with the position of each 01 model portfolio "
                    "on the risk and horizon scale, the building blocks each model is built from, and the target "
                    "weights of every model portfolio version. It is the one source 45 planning, 46 model assignment, "
                    "16 workplace managed accounts and IC model delivery read for what a model holds and on which "
                    "assumptions it was built; concept rows Capital Market Assumption Set, Model Lineup and Target "
                    "Allocation Set (model subject), 24.",
         objects=[("24", "Capital Market Assumption Set"), ("24", "Asset Class Return Assumption"),
                  ("24", "Asset Class Correlation Assumption"), ("24", "Model Lineup"),
                  ("24", "Model Lineup Position"), ("24", "Model Building Block"),
                  ("24", "Target Allocation Set"), ("24", "Target Allocation Line"), ("01", "Model Portfolio"),
                  ("01", "Service Offering"), ("01", "Benchmark")],
         upstream=["DP-004", "DP-097", "DP-144", "DP-212", "DP-013"],
         notes="Model subject rows only of Target Allocation Set and Line (portfolio subject rows stay in DP-128). "
               "Building Block Product List Status is a Derived copy of 52 held as recorded; its tie-out against the "
               "52 list is in DP-531, so no consumer is upstream (CW-250). Licensed CMA lever: the set becomes a 14 "
               "dataset with 24 approval only (24 SME 1). Certified numbers: none. PII = N."),

    # ================================================ Consumer (WP1C) ================================================
    dict(id="DP-531", name="CMA & Model Lineup Governance and Lineup Drift", tier="Consumer-aligned",
         type="Regulatory & Control", domain="24", owner_role="Chief Investment Officer", primary="FN-21",
         supporting=["FN-70", "FN-63", "FN-60", "FN-68", "FN-42"], wave="WP1C",
         definition="Approval and currency of every capital market assumption set and model lineup, the committee "
                    "decision behind each, building blocks whose 52 list status is no longer Approved for Advice "
                    "Models, and the drift of each lineup's design (risk band, equity share, glide path position) from "
                    "the target weights its models actually carry. It lets the investment committee show that every "
                    "advice model in use rests on a current approved set and an approved product.",
         objects=[("24", "Capital Market Assumption Set"), ("24", "Model Lineup"), ("24", "Model Lineup Position"),
                  ("24", "Model Building Block"), ("24", "Target Allocation Set"), ("24", "Target Allocation Line"),
                  ("24", "Asset Allocation Policy"), ("24", "Asset Allocation Policy Line"),
                  ("24", "Glide Path Point"), ("24", "Investment Committee Decision"),
                  ("52", "Product List Status"), ("37", "Model Inventory Entry")],
         upstream=["DP-530", "DP-126", "DP-127", "DP-212", MGR, "DP-004", "DP-013"],
         notes="Lineup drift = Nominal Equity Share of the position minus the equity weight of the model's current "
               "target set; glide-path drift against Glide Path Point. Not account drift (46, CLA-A). Projections "
               "shown to clients are 45 and reviewed by 08 (24 boundary rule 4)."),

    dict(id="DP-532", name="Household & Account Performance View", tier="Consumer-aligned", type="Analytical",
         domain="32", owner_role="Head of Performance Measurement", primary="FN-31",
         supporting=["FN-61", "FN-60", "FN-67", "FN-73", "FN-69", "FN-71"], wave="WP1C",
         definition="Personal Rate of Return by account and household performance group over standard and "
                    "client-chosen periods, with the method (time-weighted or money-weighted), calculation method, fee "
                    "basis, suppression state and comparison benchmark printed beside each number. It is the "
                    "presentation view advisors, the digital experience and statements read, taking the certified "
                    "value from DP-145 and never recalculating it.",
         objects=[("32", "Personal Rate of Return"), ("32", "Client Performance Profile"),
                  ("32", "Household Performance Group"), ("32", "Household Performance Group Member"),
                  ("15", "Account"), ("02", "Household"), ("02", "Household Membership"), ("01", "Benchmark")],
         upstream=["DP-145", "DP-093", "DP-240", "DP-004", "DP-013"],
         notes="PII = Y (client PII, financial tier); Confidential - Personal Data; row-level entitlement by advisor "
               "of record (03) and the client. Suppressed and Preliminary rows are shown as suppressed, never as a "
               "number. Answers acceptance question 9 with DP-145."),

    dict(id="DP-533", name="Personal Return Exceptions, Suppression & Restatements", tier="Consumer-aligned",
         type="Regulatory & Control", domain="32", owner_role="Head of Performance Measurement", primary="FN-31",
         supporting=["FN-65", "FN-28", "FN-67", "FN-72"], wave="WP1C",
         definition="Open and aged client return exceptions (missing price, unposted corporate action, large flow, "
                    "conversion gap), the accounts and households they suppress, personal returns restated and "
                    "whether the client was notified, and profiles missing a start date or policy. It is the control "
                    "behind the certified Personal Rate of Return: no number is published while an exception "
                    "suppresses it.",
         objects=[("32", "Client Return Exception"), ("32", "Personal Rate of Return"),
                  ("32", "Client Performance Profile"), ("32", "Performance Calculation Policy"),
                  ("32", "Performance Restatement"), ("15", "Account")],
         upstream=["DP-145", "DP-093", "DP-143", "DP-013"],
         notes="PII = Y; operations view restricted to performance and service operations. Exceptions caused by "
               "pricing route to DP-148 / DP-543; by 49 posting breaks to the 49 products (BWO brief)."),

    dict(id="DP-534", name="Managed Account Program Performance & Dispersion", tier="Consumer-aligned",
         type="Analytical", domain="32", owner_role="Head of Performance Measurement", primary="FN-31",
         supporting=["FN-63", "FN-61", "FN-21", "FN-68"], wave="WP1C",
         definition="Managed account composite returns (32 Performance Return with a Managed Account Composite "
                    "subject) set against the model's own return and the dispersion of member accounts' personal "
                    "returns around them, by program, model and lineup position. It shows whether accounts assigned "
                    "to the same model get the same outcome, which 46 operations, product and Rule 3a-4 program "
                    "reviews need.",
         objects=[("32", "Performance Return"), ("32", "Personal Rate of Return"), ("32", "Benchmark Return"),
                  ("46", "Managed Account Composite"), ("46", "Managed Account Composite Membership"),
                  ("46", "Model Assignment"), ("24", "Model Lineup Position"), ("01", "Model Portfolio")],
         upstream=["DP-145", MAA, "DP-530", "DP-004", "DP-013"],
         notes="Aggregates only (PII = N at publication; account-level dispersion inputs restricted). Advice programs "
               "sit outside the GIPS firm by default (32 lever 7). Composite membership is 46's (CW-050)."),

    dict(id="DP-535", name="Manager Search, Selection & Due Diligence", tier="Consumer-aligned",
         type="Operational", domain="52", owner_role="Head of Manager Research", primary="FN-70",
         supporting=["FN-21", "FN-75", "FN-69", "FN-44"], wave="WP1C",
         definition="Each manager search from need to recommendation with its candidate strategies, stages and "
                    "eliminations, and every operational and investment due diligence review with its questionnaire, "
                    "factor scores, onsite visits and key-person background checks. It evidences the care behind each "
                    "hire for fund boards, OCIO clients and trust fiduciaries.",
         objects=[("52", "Manager Search"), ("52", "Search Outcome"), ("52", "Search Candidate"),
                  ("52", "Due Diligence Questionnaire Template"), ("52", "Manager Due Diligence Review"),
                  ("52", "Due Diligence Score"), ("52", "Onsite Visit"), ("52", "Background Check Result"),
                  ("52", "External Manager Profile"), ("52", "Manager Key Person"),
                  ("52", "External Manager Strategy"), ("24", "Investment Committee Decision")],
         upstream=[MGR, "DP-126", "DP-192", "DP-240", "DP-004", "DP-013"],
         notes="PII = Y: key persons are individuals; Background Check Result is published as outcome and FCRA "
               "authorization only, in a restricted view. Manager research is not 23 (CW-119)."),

    dict(id="DP-536", name="Sub-Adviser Oversight Scorecard", tier="Consumer-aligned", type="Regulatory & Control",
         domain="52", owner_role="Head of Manager Research", primary="FN-70",
         supporting=["FN-31", "FN-30", "FN-32", "FN-36", "FN-21", "FN-75"], wave="WP1C",
         definition="Per sub-adviser engagement and review period: excess return, ex-post and ex-ante risk, peer "
                    "percentile, fee versus peers, turnover, breach count, style drift and active share against the "
                    "thresholds approved for that engagement, key-person changes, the review conclusion and the watch "
                    "status in force. It answers which sub-advisers are under review and why, from readings that "
                    "each name the owner record they copy.",
         objects=[("52", "Oversight Review"), ("52", "Oversight Metric Reading"), ("52", "Oversight Metric Threshold"),
                  ("52", "Sub-Adviser Watch Status"), ("52", "Sub-Adviser Engagement"), ("52", "Manager Key Person"),
                  ("32", "Performance Return"), ("32", "Benchmark Return"), ("32", "Ex-Post Risk Statistic"),
                  ("31", "Portfolio Risk Measure"), ("11", "Peer Metric Snapshot"), ("11", "Fee Benchmark Result"),
                  ("27", "Financial Highlights"), ("33", "Investment Breach")],
         upstream=[MGR, "DP-145", "DP-157", "DP-146", "DP-163", "DP-165", "DP-014", "DP-140", "DP-004", "DP-013"],
         notes="Plan section 8.3 example. Readings are Derived copies (CW-119); the scorecard ties each to its source "
               "version and never publishes a return as official (CW-252). Acceptance question 12 (first half)."),

    dict(id="DP-537", name="Sub-Adviser Guidelines, Certifications & Findings", tier="Consumer-aligned",
         type="Regulatory & Control", domain="52", owner_role="Head of Manager Research", primary="FN-70",
         supporting=["FN-32", "FN-36", "FN-44", "FN-24"], wave="WP1C",
         definition="Guideline set versions delivered to and acknowledged by each sub-adviser with the 33 rule "
                    "versions they include, the firm-level and quarterly compliance certifications received against "
                    "due dates and the breaches they disclose, and oversight findings with their remediation actions. "
                    "It is the Rule 38a-1 and 206(4)-7 oversight evidence for the sub-advised range.",
         objects=[("52", "Sub-Adviser Guideline Set"), ("52", "Guideline Rule Inclusion"),
                  ("52", "Sub-Adviser Compliance Certification"), ("52", "Oversight Finding"),
                  ("52", "Remediation Action"), ("52", "Sub-Adviser Engagement"), ("33", "Compliance Rule"),
                  ("33", "Investment Breach"), ("01", "Investment Restriction")],
         upstream=[MGR, "DP-161", "DP-163", "DP-192", "DP-004", "DP-013"],
         notes="Guidelines defined in 01, coded in 33, delivered and certified in 52 (CW-118). Delegated proxy voting "
               "(Proxy Voting Delegated Indicator) is checked against DP-132 authority rows."),

    dict(id="DP-538", name="Sub-Adviser Hires, Terminations & Section 15(c) Renewal Evidence", tier="Consumer-aligned",
         type="Regulatory & Control", domain="52", owner_role="Head of Manager Research", primary="FN-70",
         supporting=["FN-36", "FN-35", "FN-45", "FN-21"], wave="WP1C",
         definition="Each sub-adviser engagement's lifecycle: hire under a manager-of-managers order with the "
                    "information statement due and sent, the Section 15(c) renewal submission with its recommendation "
                    "and the oversight reviews it includes, and terminations with the deciding committee decision, "
                    "replacement and 12 transition event. It gives the fund board, through 35, the renewal data on "
                    "every sub-adviser.",
         objects=[("52", "Sub-Adviser Engagement"), ("52", "Manager-of-Managers Hire Condition"),
                  ("52", "Section 15(c) Renewal Submission"), ("52", "Manager Termination"),
                  ("35", "Advisory Contract Renewal"), ("35", "Fund Advisory Agreement"),
                  ("35", "Exemptive Relief Reliance"), ("13", "Shareholder Communication"),
                  ("12", "Transition Event"), ("24", "Investment Committee Decision")],
         upstream=[MGR, "DP-536", "DP-183", "DP-126", "DP-004", "DP-013"],
         notes="Contract and board approval stay 35 (CW-117); DP-183 keeps the renewal and reads this product at WP1 "
               "(CW-253). Information statement timing is the order's 90 days (Release 33-8312 marked confirm). "
               "Acceptance question 12 (second half)."),

    dict(id="DP-539", name="Third-Party Product Due Diligence & Approved Lists", tier="Consumer-aligned",
         type="Regulatory & Control", domain="52", owner_role="Head of Manager Research", primary="FN-70",
         supporting=["FN-78", "FN-60", "FN-61", "FN-68", "FN-71", "FN-74", "FN-21"], wave="WP1C",
         definition="Every third-party fund and ETF the firm offers, recommends or uses: the screen or full due "
                    "diligence behind it, criterion results, complex-product determination, Rule 12d1-4 fund of funds "
                    "detail, and its list status per use scope (brokerage platform, advice models, plan menus, fund "
                    "of funds, feeder underlying), set against 01 platform availability, 24 building blocks and 45 "
                    "recommendations. It is platform curation and the Reg BI reasonable-basis evidence in one place.",
         objects=[("52", "Product Due Diligence"), ("52", "Product Due Diligence Criterion Result"),
                  ("52", "Fund of Funds Use Detail"), ("52", "Product List Status"),
                  ("01", "Platform Product Availability"), ("24", "Model Building Block"),
                  ("16", "Plan Investment Option"), ("17", "Instrument"), ("24", "Investment Committee Decision")],
         upstream=[MGR, "DP-097", "DP-530", "DP-126", "DP-094", "DP-004", "DP-013"],
         notes="Availability is 01, the verdict 52 (CW-120). Takes the residual of DP-137 (52 Product Due Diligence of "
               "feeder products) when the framing agent retires it. Products recommended without an Approved status "
               "are read from the 45 foundational product by key, not re-scored here. CW-254."),

    dict(id="DP-540", name="OCIO & Trust Delegated Manager Oversight", tier="Consumer-aligned",
         type="Analytical", domain="52", owner_role="Head of Manager Research", primary="FN-70",
         supporting=["FN-75", "FN-69", "FN-31"], wave="WP1C",
         definition="The external managers hired inside OCIO mandates and personal trust accounts (Engagement Scope "
                    "OCIO Mandate and Trust Mandate): the governing 39 contract, the client's investment policy, the "
                    "engagements by client and the oversight conclusions and watch status of each. It lets the "
                    "institutional advisory and trust teams evidence prudent delegation (Advisers Act duty of care, "
                    "ERISA 3(38), UPMIFA, UPIA section 9) client by client.",
         objects=[("52", "Sub-Adviser Engagement"), ("52", "Oversight Review"), ("52", "Sub-Adviser Watch Status"),
                  ("12", "OCIO Service Detail"), ("12", "Investment Policy Statement"), ("39", "Contract"),
                  ("01", "Investment Mandate")],
         upstream=[MGR, "DP-536", "DP-213", "DP-240", "DP-004", "DP-013"],
         notes="Trust scope is optional (TR line, 51); without TR the product is OCIO only. Client names are "
               "institutional; trust accounts make it PII = Y in the trust view."),

    dict(id="DP-541", name="Investor Choice Proxy Voting Program", tier="Consumer-aligned",
         type="Regulatory & Control", domain="34", owner_role="Head of Stewardship", primary="FN-24",
         supporting=["FN-35", "FN-36", "FN-67", "FN-61"], wave="WP1C",
         definition="The voting policies offered to fund shareholders as investor choice options, the share of each "
                    "fund's shares elected to each option (13 elections against Fund Shareholder Position, 06), and "
                    "how the votes cast split by option, policy and fund. It shows the board and shareholders that "
                    "each election was honored in the votes the firm cast.",
         objects=[("34", "Voting Policy"), ("34", "Voting Authority Arrangement"), ("34", "Ballot"),
                  ("34", "Vote Instruction"), ("34", "Vote Rationale"), ("13", "Voting Choice Election"),
                  ("06", "Fund Shareholder Position"), ("01", "Investment Product")],
         upstream=["DP-132", "DP-142", "DP-004", "DP-240", "DP-013"],
         notes="Election and position are client PII: published as fund x option aggregates; the shareholder-level "
               "view is restricted to TA and service operations (CW-256). Fund Shareholder Position is the 06 book "
               "(CW-007), read for elected shares; never Client Holding or Portfolio Holding."),

    dict(id="DP-542", name="Institutional Mandate Guidelines & IPS Compliance", tier="Consumer-aligned",
         type="Regulatory & Control", domain="33", owner_role="Head of Investment Compliance", primary="FN-32",
         supporting=["FN-75", "FN-21", "FN-31"], wave="WP1C",
         definition="For each institutional separate account and OCIO mandate of the IA line: the 12 investment "
                    "policy statement and 01 mandate restrictions, the 33 rules coded and assigned to its 18 "
                    "portfolio, the 24 allocation policy of the mandate, and open breaches. It shows that every IPS "
                    "constraint is coded and monitored before a mandate funds and while it runs.",
         objects=[("33", "Compliance Rule"), ("33", "Rule Assignment"), ("33", "Rule Source Link"),
                  ("33", "Investment Breach"), ("12", "Investment Policy Statement"), ("01", "Investment Mandate"),
                  ("01", "Investment Restriction"), ("18", "Portfolio"), ("18", "Portfolio Implementation Link"),
                  ("24", "Asset Allocation Policy")],
         upstream=["DP-161", "DP-163", "DP-140", "DP-127", "DP-004", "DP-013"],
         notes="Returns versus IPS objectives are read from DP-145 for institutional accounts (Performance Return "
               "account subject is IA only, CW-129); client reporting of them is 12 (DIS brief)."),

    dict(id="DP-543", name="Client-Held Instrument Pricing Coverage", tier="Consumer-aligned",
         type="Regulatory & Control", domain="22", owner_role="Head of Pricing and Valuation", primary="FN-28",
         supporting=["FN-65", "FN-67", "FN-31"], wave="WP1C",
         definition="Instruments held in client brokerage accounts (49 Client Holding) that no fund or institutional "
                    "portfolio holds, with their approved price coverage, staleness, evaluated-price share and open "
                    "validation exceptions at the statement pricing point. It closes the gap between a pricing "
                    "function built for fund books and the brokerage book whose statement values and personal returns "
                    "depend on the same prices.",
         objects=[("22", "Approved Price"), ("22", "Price Validation Exception"), ("22", "Pricing Point"),
                  ("22", "Pricing Policy"), ("22", "Price Observation"), ("49", "Client Holding"),
                  ("17", "Instrument")],
         upstream=["DP-143", CHB, "DP-097", "DP-013"],
         notes="Holdings book named: Client Holding (49), counted by instrument only; PII = N (no account published). "
               "Statement valuation rules (FINRA Rule 2231, confirm) stay 49 and 13."),

    dict(id="DP-544", name="Trade Rotation & Cross-Book Allocation Fairness", tier="Consumer-aligned",
         type="Regulatory & Control", domain="25", owner_role="Head of Trading", primary="FN-23",
         supporting=["FN-63", "FN-64", "FN-32", "FN-44", "FN-74"], wave="WP1C",
         definition="When the same investment decision reaches fund and institutional portfolios (25 orders), managed "
                    "accounts (46 proposals released as 48 client block orders) and intermediary model delivery, the "
                    "sequence and timing of each book against the rotation policy, and execution price differences "
                    "between books. It evidences that no book is systematically traded ahead of another.",
         objects=[("25", "Trade Order"), ("25", "Block Order"), ("25", "Execution"), ("24", "Investment Decision"),
                  ("46", "Trade Proposal Batch"), ("48", "Client Block Order"), ("48", "Client Execution")],
         upstream=["DP-123", "DP-126", COE, MAA, "DP-129", "DP-097", "DP-013"],
         notes="Joins the three trade records by key only and re-publishes no execution (CW-255); Rule 605/606 "
               "execution quality is 48's. Lever: a firm that routes managed-account trades through the fund desk "
               "reads 25 only."),
]

DISPOSITIONS = [
    # (id, disposition, successor, decision, reason): the standard WP0 shape (WP0_Framing.md section 1), normalized at the WP0
    # integration. No pending wholesale consumer product (framework.RESCOPE_PENDING) is owned by 18, 22, 23, 24, 25, 26, 31,
    # 32, 33, 34 or 52 (checked 2026-10-15). The rows below agree with the framing table, which rules these products.
    ("DP-135", "re-scope", "DP-135", "CW-208; CW-257",
     "Keep and re-scope: rename 'Climate Metrics, Financed Emissions & ESG Fund Metrics'; voluntary TCFD / IFRS S2, PCAF and "
     "NZAM reporting and the metrics behind ESG-named funds (Rule 35d-1); stays separate from DP-134 (issuer data versus "
     "portfolio metrics). Lever: a firm with no voluntary climate reporting retires it and moves ESG-name metrics into DP-134."),
    ("DP-156", "retire", "DP-004; DP-146", "CW-207; CW-257",
     "Retired by the framing ruling: firm risk rating published by DP-004, realized volatility a DP-146 measure (this brief had "
     "recommended DP-145 or a 45 suitability product; the framing ruling governs)."),
    ("DP-137", "retire", "DP-539", "CW-930; CW-120", "Private markets; its 52 Product Due Diligence residual is taken by DP-539."),
    ("DP-160", "retire", "DP-145", "CW-930; CW-129", "Private markets; nothing carried; Personal Rate of Return is DP-145's."),
    ("DP-127", "keep", "DP-127", "CW-208; CW-048", "Asset allocation policy; DP-542 lists DP-127 upstream for the IA policy."),
    ("DP-130", "re-scope", "DP-130", "CW-208; CW-048", "Portfolio-book separate accounts; the client managed-account view moves to 46 (CLA-A)."),
]

RESPEC = [
    # (product, what changed at W1b to W4, WP1 re-specification)
    ("DP-145 Official Returns", "W3 CW-129: Client Account Performance family; Performance Return account subject limited to IA separate accounts; Managed Account Composite subject (CW-050); W4 private markets removed",
     "Publish Personal Rate of Return (certified, defined here only): inputs Personal Rate of Return, Client Performance Profile, Household Performance Group and Member, Client Return Exception (suppression); grain subject x period x method x fee basis x version; PII = Y, Confidential - Personal Data, plus an account-free public view; tie-outs of Beginning / Ending Market Value, Net External Flows and Fees Deducted to 49, 29, 16 and 47 (upstream Client Holdings, Lots & Cost Basis, the 47 billing foundational, DP-094); Managed Account Composite returns from 46 membership; supersede the 'Recordkeeping Platform' note and the CD-220 statement."),
    ("DP-126 Investment Governance, Decisions & Manager Assignment", "W3 CW-121, CW-128: Committee Decision Types CMA Approval, Model Lineup Approval, Manager Hire, Manager Termination, Third-Party Product Approval; Manager Research Committee; Decision Algorithm to 37",
     "Add decision-type dimensions and measures (approvals by type, decisions without a 52 or 24 subject record); restore DP-212 upstream for Decision Algorithm; state that 52 records the engagement and DP-535 / DP-538 / DP-539 read the decision."),
    ("DP-128 Portfolio Targets, Investable Cash & Rebalancing", "W3 CW-047, CW-048: model weights are read by 46; retail accounts are not 18 portfolios",
     "Restrict to portfolio subject target sets (funds, CITs, IA accounts); model subject target sets publish through DP-530, which foundational 45 and 46 products can depend on."),
    ("DP-129 Model Portfolio Delivery to Sponsors", "CW-013: intermediary channel is thin; FN-74 runs C-02.04; W4 model-fk warning",
     "Re-scope to IC model delivery to third-party platforms (05 placements), primary FN-74 or FN-22 by ruling; read the model weights from DP-530; fix the conformed-entity model warning."),
    ("DP-140 Portfolio Master & Mandate Link", "W1b, W4: private fund detail removed; SMA Portfolio Detail now IA separate accounts and sponsor program books; W4 model-fk warning",
     "State that retail managed accounts are 15 / 46 client accounts, never 18 portfolios; restate the CW-007 book name; fix the model-fk warning."),
    ("DP-142 Holdings, Tax Lots & Cash", "CW-007 three books of record",
     "Name the book (Portfolio Holding, 18) in definition and grain; no input change."),
    ("DP-132 Proxy Voting Record & Disclosure", "W1b CW-934: SRD II removed; investor choice options on Voting Policy; Rule 14Ad-1 manager say-on-pay report type",
     "Add Voting Choice Option Type and Voting Authority Holder 'pass-through' to the dimensions; N-PX fund and manager report completeness measures; DP-541 reads it."),
    ("DP-135 Sustainability Metrics, PAI & Product Outcomes", "W1b CW-934: PAI, outcomes and EET removed",
     "Rename and re-scope per DISPOSITIONS (CW-257)."),
    ("DP-149 Fair Value & Valuation Committee Oversight", "W4 CW-930: Private Asset Valuation Detail removed; W1b: AIFMD valuer removed",
     "Re-word to the Rule 2a-5 valuation designee and the CIT trustee; feeder fund interests valued from 18 Fund Interest Holding Detail; drop the private markets question."),
    ("DP-155 Fund Liquidity & Derivatives Risk Programs", "W4: Bucket Feeder Access Terms (interval and tender-offer funds); Fund Borrowing Facility removed; W1b UCITS / AIFMD removed",
     "Add interval-fund (Rule 23c-3) and tender-offer liquidity measures over Bucket Feeder Access Terms; restate program types 22e-4, 18f-4, 2a-7."),
    ("DP-158 GIPS Composites & Verification", "W3 CW-129, 32 lever 7: advice programs outside the GIPS firm; no retail account in Composite Membership",
     "Add the rule 'no retail, participant or trust account is a member' as a DQ rule; Managed Account Composite lever noted."),
    ("DP-159 Investment Performance Scorecard", "W3: 52 reads the same returns for sub-advisers",
     "Add a sub-advised indicator dimension from the Manager & Sub-Adviser Master; boundary with DP-536 (fund results versus engagement oversight)."),
    ("DP-162 Compliance Monitoring, Alerts & Overrides", "W4: Tested Deal removed; W3: sub-adviser pre-trade checks (52 Sub-Adviser Pre-Trade Checks Indicator)",
     "Add a sleeve and sub-adviser dimension; alerts on sleeves whose guideline set says the sub-adviser runs pre-trade checks are flagged post-trade only."),
    ("DP-163 Investment Breaches & Remediation", "W1b: Depositary Notification removed; W3: 52 certifications link breaches",
     "Add the 'breach disclosed in a sub-adviser certification' flag (52 Linked Investment Breaches) read by DP-537."),
    ("DP-183 Advisory Agreements & 15(c) Renewal (owner 35, not this group)", "W3 CW-117",
     "For its owner: add DP-538 upstream for sub-adviser renewal content (CW-253)."),
]

DECISIONS = [
    {"id": "CW-250", "theme": "Products", "domains": ["24", "45", "46", "16", "52"],
     "title": "Capital market assumptions, model lineups and model target weights are one foundational product (DP-530)",
     "issue": "45 planning, 46 model assignment, 16 workplace managed accounts and IC delivery read 24 Model Lineup "
              "Position, the CMA set and the model target weights. Their WP1 foundational products may depend only on "
              "foundational products, but the model target weights sit today in the consumer DP-128 and the CMA and "
              "lineup objects in no product.",
     "resolution": "Proposed: DP-530 conforms Capital Market Assumption Set, its return and correlation lines, Model "
                   "Lineup, Model Lineup Position, Model Building Block and the model-subject rows of Target "
                   "Allocation Set and Line. DP-128 keeps portfolio-subject target sets. The building block's 52 "
                   "list status is held as a Derived copy and tied out in DP-531, so DP-530 depends on no consumer.",
     "rationale": "Foundational rule (Data_Products_Approach); 24 boundary rule 1 (W3 brief); w4 merge notes WP1 item.",
     "action": "WP1 foundational wave", "status": "Proposed", "priority": "High", "owner_role": "Chief Investment Officer"},
    {"id": "CW-251", "theme": "Certified numbers", "domains": ["32", "13", "45", "46"],
     "title": "Personal Rate of Return is published by DP-145 only; DP-532 to DP-534 present and control it",
     "issue": "CW-011 and CW-129 certify Personal Rate of Return and name DP-145 extended; three new consumers read it.",
     "resolution": "Proposed: DP-145 is the only product that publishes a Personal Rate of Return value. DP-532 "
                   "presents it with method, fee basis and suppression; DP-533 holds exceptions and restatements; "
                   "DP-534 publishes dispersion aggregates. None recalculates a return; a suppressed or Preliminary "
                   "row is never shown as a number. A Household Performance Group is not the 02 household.",
     "rationale": "CW-011, CW-129, CW-027.", "action": "WP1", "status": "Proposed", "priority": "High",
     "owner_role": "Head of Performance Measurement"},
    {"id": "CW-252", "theme": "Products", "domains": ["52", "32", "31", "33", "11", "27"],
     "title": "Sub-adviser oversight readings are Derived copies tied to their source version and are never official returns",
     "issue": "DP-536 shows returns, risk and peer numbers that DP-145, DP-146 and DP-014 also publish.",
     "resolution": "Proposed: DP-536 publishes Oversight Metric Readings as oversight values with the pinned source "
                   "record and version, and a tie-out measure per metric to DP-145, DP-157, DP-146, DP-163 and DP-165. "
                   "Only excess return, breach count, style drift and active share are computed in 52.",
     "rationale": "CW-119 as amended.", "action": "WP1", "status": "Proposed", "priority": "Medium",
     "owner_role": "Head of Manager Research"},
    {"id": "CW-253", "theme": "Products", "domains": ["52", "35"],
     "title": "Sub-adviser Section 15(c) content is DP-538; the renewal and board approval stay DP-183",
     "issue": "Acceptance question 12 crosses 52 and 35.",
     "resolution": "Proposed: DP-538 publishes the 52 renewal submission, recommendation and included reviews; DP-183 "
                   "keeps the 35 renewal and board resolution and lists DP-538 upstream at WP1.",
     "rationale": "CW-117, CD-237.", "action": "WP1 (DP-183 owner)", "status": "Proposed", "priority": "Medium",
     "owner_role": "Head of Manager Research"},
    {"id": "CW-254", "theme": "Products", "domains": ["52", "01", "24", "45", "16"],
     "title": "The approved third-party product lists are published by DP-539; a foundational reader moves Product List Status into the Manager & Sub-Adviser Master",
     "issue": "01 availability, 24 building blocks, 45 recommendations and 16 menus read 52 Product List Status.",
     "resolution": "Proposed: DP-539 is the product of record for list status and due diligence. If a WP1 "
                   "foundational product (45 or 46) must list it upstream, Product List Status moves into the "
                   "framing agent's Manager & Sub-Adviser Master and DP-539 reads it from there.",
     "rationale": "CW-120; foundational dependency rule.", "action": "WP0 framing ruling", "status": "Proposed",
     "priority": "Medium", "owner_role": "Program lead"},
    {"id": "CW-255", "theme": "Products", "domains": ["25", "46", "48"],
     "title": "Fund and institutional trading (25) and client orders (48) stay separate trade records; DP-544 joins them by key for rotation only",
     "issue": "One investment decision reaches funds, managed accounts and model platforms through two order records.",
     "resolution": "Proposed: DP-123 stays the 25 chain and the 48 foundational product the client chain; DP-544 "
                   "reads both by key and re-publishes no execution; Rule 605 / 606 execution quality is 48's.",
     "rationale": "CD-314, CW-007.", "action": "WP1", "status": "Proposed", "priority": "Medium",
     "owner_role": "Head of Trading"},
    {"id": "CW-256", "theme": "Personal data", "domains": ["34", "13", "06"],
     "title": "Investor choice voting: options 34, elections 13; DP-541 publishes fund x option aggregates",
     "issue": "Elections and elected shares are shareholder-level personal data.",
     "resolution": "Proposed: DP-541 publishes elected shares and votes by fund and option; the shareholder-level view "
                   "is restricted. Form N-PX content stays DP-132.",
     "rationale": "CW-934, plan section 11 data tiers.", "action": "WP1", "status": "Proposed", "priority": "Low",
     "owner_role": "Head of Stewardship"},
    {"id": "CW-257", "theme": "Products", "domains": ["34", "31"],
     "title": "WP0 dispositions of DP-135 (keep, re-scope to voluntary climate and ESG-name fund metrics) and DP-156 (retire, residual to DP-145)",
     "issue": "Both were flagged WP0 re-scope candidates under CW-041 when their EU regimes left the model.",
     "resolution": "Proposed: DP-135 kept, renamed 'Climate Metrics, Financed Emissions & ESG Fund Metrics' (lever: "
                   "retire without voluntary climate reporting). DP-156 retired; its realized-volatility check moves to "
                   "DP-145 or a 45 suitability product.",
     "rationale": "CW-934, CW-931, CW-901.", "action": "WP0 framing table", "status": "Proposed", "priority": "Low",
     "owner_role": "Program lead"},
]


# ---- WP1 scope (WP0 rationalization, 2026-10-15; Product_Briefs/WP1_Scope.md) ------------------------------
# Program-lead ruling: every candidate is flagged wp1=True (specified at WP1) or backlog=True (registered in
# framework.WAVE_BACKLOG, status 'backlog', not specified at WP1; ids unchanged). WP1_MERGES names the product a
# backlog candidate overlaps (its scope folds in there if it is picked up). WP1_MOVED_READS: objects with CDEs that
# only a backlog candidate read, now read by the named WP1 product (coverage rule; WP1 specs read them).
WP1_BACKLOG_IDS = ["DP-534", "DP-537", "DP-539", "DP-540", "DP-541", "DP-542", "DP-543"]
WP1_MERGES = {

    "DP-534": "DP-345",   # Managed Account Program Performance & Dispersion -> Managed Account Assets, Models & Composites
    "DP-537": "DP-536",   # Sub-Adviser Guidelines, Certifications & Findings -> Sub-Adviser Oversight Scorecard
    "DP-539": "DP-535",   # Third-Party Product Due Diligence & Approved Lists -> Manager Search, Selection & Due Diligence
    "DP-540": "DP-536",   # OCIO & Trust Delegated Manager Oversight -> Sub-Adviser Oversight Scorecard
    "DP-541": "DP-408",   # Investor Choice Proxy Voting Program -> Proxy Solicitation, Pass-Through & Voting Choice
    "DP-542": None,   # Institutional Mandate Guidelines & IPS Compliance (stands alone)
    "DP-543": "DP-516",   # Client-Held Instrument Pricing Coverage -> Retail Tradable Instrument Coverage & Eligibility
}
WP1_MOVED_READS = {

    "DP-536": [('52', 'Guideline Rule Inclusion', "DP-537"), ('52', 'Sub-Adviser Compliance Certification', "DP-537"), ('52', 'Oversight Finding', "DP-537"), ('52', 'Remediation Action', "DP-537")],
    "DP-535": [('52', 'Fund of Funds Use Detail', "DP-539")],
}
for _c in list(CANDIDATES) + list(globals().get("RESCOPED", [])):
    _bl = _c["id"] in WP1_BACKLOG_IDS
    _c["wp1"], _c["backlog"] = not _bl, _bl
    if _bl:
        _t = WP1_MERGES.get(_c["id"])
        _c["merge_into"] = _t
        _c["notes"] = (_c.get("notes", "") + " Backlog (WP1_Scope.md): not specified at WP1"
                       + (f"; overlaps {_t}, into which its scope folds if it is picked up." if _t else "; stands alone."))
    for _o in WP1_MOVED_READS.get(_c["id"], []):
        if (_o[0], _o[1]) not in _c["objects"]:
            _c["objects"].append((_o[0], _o[1]))
            _c["notes"] = _c.get("notes", "") + f" WP1 scope: also reads {_o[0]} {_o[1]} (from backlog {_o[2]})."
