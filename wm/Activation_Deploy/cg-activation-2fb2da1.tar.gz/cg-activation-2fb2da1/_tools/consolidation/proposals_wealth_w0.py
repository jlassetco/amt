"""Wealth-manager reference model: the W0 framing decisions (CW-001 onward).

Merged into decisions.py at W0 (2026-10-14); kept here as the record of the proposal. The builder does not read this file.

Format: the DECISIONS dict format of decisions.py (see CONTRACT.md). Declarative only. The CW- series is the wealth
model's own; the inherited CD- entries record the shared foundation and are never renumbered. Each ruling names the
tailoring lever a client would pull to rule differently (Wealth_Manager_Rework_Plan.md section 4 and 15).

Status conventions for the CW- series:
  "Ruled (W0)"             - program lead ruling for the reference model; applied in the stage named in the action
  "Applied (W<n>)"         - implemented in the content, registers or tooling at that stage
  "SME decision required"  - a genuine business choice the reference model cannot default
"""

PL = "Program lead"
W0 = "Ruled (W0)"

DECISIONS = [
    {"id": "CW-001", "theme": "Scope", "title": "A sibling reference model for a direct wealth manager (Vanguard type), US only",
     "domains": [],
     "issue": "The enterprise taxonomy, products, models and semantic layer describe a wholesale asset manager (US + EU/UK, six business lines). A second client type, a direct-to-investor wealth manager that also manufactures funds, needs the same four layers with a different center of gravity.",
     "resolution": "Build a second reference model on branch feature/wealth-manager, cut from tag wholesale-v1.0, for a US wealth manager with the business lines of CW-004. The wholesale model stays intact at the tag and on main and is not edited by this program. Shared-foundation fixes move between the siblings by cherry-pick, each with a decision; the branches are never merged.",
     "rationale": "A branch keeps one tooling base, one prefix register and one baseline lineage, and can be split into its own repository later; the reverse is expensive. Nothing in the wholesale build is lost: every commit stays reachable at the tag.",
     "action": "Branch cut at W0; check_baseline.py --check wholesale-v1.0 reports the drift on demand", "status": W0, "priority": "High", "owner_role": PL},

    {"id": "CW-002", "theme": "Identifiers", "title": "Separate identifier series for the wealth model",
     "domains": [],
     "issue": "Both siblings continue to add decisions, products, semantic models and functions. Shared numbering would make an ID ambiguous across the two models.",
     "resolution": "Decisions: CW-001 onward (CD- entries are inherited history). Products: retired DP- numbers stay retired; new products start at DP-300. Semantic models: new models start at SM-20; SM-01 to SM-07 retire at WP0. Functions: new functions start at FN-60. ID prefixes: one register for both siblings; a prefix registered on either side is never reused by the other (wholesale-only prefixes carry status 'Reserved by sibling'). Data Domain numbers 07 and 30 are retired and never reused; new domains start at 45.",
     "rationale": "An identifier must resolve to one thing whichever sibling a reader opens.",
     "action": "Applied in decisions.py, framework.py, register.py and domains.py at W0 and WP0", "status": W0, "priority": "High", "owner_role": PL},

    {"id": "CW-003", "theme": "Scope", "title": "Markets: US only; EU/UK content removed through a per-domain jurisdiction pass",
     "domains": ["01", "08", "09", "13", "14", "17", "19", "20", "21", "22", "23", "25", "26", "27", "28", "29", "31", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44"],
     "issue": "Every carried-over domain holds EU/UK regime objects, code values and sources (UCITS, AIFMD, MiFID II, PRIIPs, SFDR, CASS, CSDR, EMIR, DORA, SM&CR, Consumer Duty, FinDatEx).",
     "resolution": "Remove EU/UK-only objects, attributes, code values and sources from every carried-over and adapted domain, one CW- decision per domain listing the removals, recorded object by object in consolidation/jurisdiction.py (the Jurisdiction register). Generic objects with a US instance are kept and re-sourced to the US rule. Perspective text (META subtitle, overviews, Source_Notes) is rewritten to 'Wealth manager (direct) | Scope: US'.",
     "rationale": "The archetype firms are US retail businesses. The register keeps a UK extension restorable from the sibling without a rebuild.",
     "action": "W1 (09, 17), W1b (kept domains), W2 to W4 (adapted and replaced domains)", "status": W0, "priority": "High", "owner_role": PL},

    {"id": "CW-004", "theme": "Scope", "title": "Business lines of the wealth model (replaces the six-value list of CD-209)",
     "domains": ["09", "21"],
     "issue": "The shared Business Line list (CD-209) names the wholesale lines: mutual funds, ETFs, CITs, SMAs, private markets, insurance-dedicated funds. The capability map tags every capability with them.",
     "resolution": "Replace the shared list with: DB Direct brokerage and self-directed investing; DA Digital advice; HA Human and hybrid advice; PF Proprietary funds and ETFs (including CITs); WR Workplace retirement recordkeeping; IA Institutional advisory; IC Intermediary channel; TR Personal trust services (optional). Private markets and insurance-dedicated funds are out of scope; alternative-investment access through feeder funds is a family of 01 and 15. The capability map's lines and the briefs' business-line tables use this list.",
     "rationale": "The lines are how a wealth manager is organized and reported; they are the first tailoring lever.",
     "action": "Applied in capability_map/content_capabilities.py and shared_code_lists.py at W0", "status": W0, "priority": "High", "owner_role": PL},

    {"id": "CW-005", "theme": "Ownership", "title": "The party master is the client household (02 replaced)",
     "domains": ["02", "05", "15", "16", "45"],
     "issue": "02 Client & Customer masters the distributor hierarchy, advisors, gatekeepers, institutions and look-through end investors. A wealth manager's parties are its clients.",
     "resolution": "02 is replaced by Client & Household (L1 code HH): individuals, joint owners, households, entities (trusts, estates, corporations, plans), minors and custodians, authorized agents and powers of attorney, trusted contacts (FINRA Rule 4512), beneficiaries as parties, the investor profile (objectives, risk tolerance, time horizon, financial situation, tax status), KYC and CIP, privacy and consent, client preferences and restrictions. PTY- stays the party key; a household is a party of type Household. Intermediary firms and advisors, consultants and plan sponsors remain party roles with their profiles in 05 and 16 (the Issuer Profile pattern, CD-143).",
     "rationale": "One party, many roles, as before; the role families change with the business. Lever: a firm without a direct business re-thickens the intermediary profiles from the sibling.",
     "action": "W1", "status": W0, "priority": "High", "owner_role": PL},

    {"id": "CW-006", "theme": "Ownership", "title": "The account is the brokerage and advisory account (15 replaced)",
     "domains": ["15", "29", "16", "47", "49"],
     "issue": "15 Account masters investor, omnibus, plan and institutional accounts as a transfer agent and recordkeeper see them.",
     "resolution": "15 is replaced in place: registration types (individual, joint, IRA and Roth IRA, SEP and SIMPLE, 529, UTMA/UGMA, trust, estate, entity, participant, HSA), account features (margin, options level, cash sweep election, DRIP, checkwriting, debit card), account agreements and disclosures delivered, beneficiary and TOD designations, advisory program enrollment, RMD status, cost-basis method election, account-level tax certification, lifecycle and restrictions. Fund-only (TA-registered) accounts stay a registration type. ACC- stays the key.",
     "rationale": "The account is the unit of custody, taxation, advice enrollment and billing for a wealth manager. Lever: feature families drop for a firm without margin, options or 529.",
     "action": "W1", "status": W0, "priority": "High", "owner_role": PL},

    {"id": "CW-007", "theme": "Ownership", "title": "Three books of record: portfolio holdings (18), client holdings (49), fund shareholder positions (06)",
     "domains": ["06", "18", "28", "49"],
     "issue": "The wholesale model has the fund IBOR (18) and shareholder positions in our funds (06 POS-). A self-clearing wealth manager keeps a brokerage book of record for every security a client holds.",
     "resolution": "The brokerage book of record (client holdings, tax lots and cost basis, cash and sweep balances, pending activity, at account grain) is mastered in 49 Clearing, Settlement & Client Asset Custody. 18 keeps fund and institutional portfolio holdings. 06 Fund Shareholder Position becomes a view of 49 for direct accounts and of intermediary and TA data for the rest. Glossary names: Portfolio Holding (18), Client Holding (49), Fund Shareholder Position (06). Custody of client assets (49) and custody of fund assets (28) are distinct concepts and domains.",
     "rationale": "Different grain, different system of record, different regulation (Rule 15c3-3 versus fund custody rules).",
     "action": "W3 (49); W4 (06 re-pointed); term conflicts Holding, Position and Custody logged at W0", "status": W0, "priority": "High", "owner_role": PL},

    {"id": "CW-008", "theme": "Ownership", "title": "Advice is data: 45 Financial Planning & Advice",
     "domains": ["01", "02", "15", "45", "46"],
     "issue": "No wholesale domain holds goals, plans, recommendations or the best-interest evidence behind them.",
     "resolution": "45 masters goals, financial plans and versions, planning assumptions and aggregated external data, projections, recommendations and their rationale, the Reg BI care-obligation and fiduciary evidence, rollover analyses (DOL PTE 2020-02), advice engagements and reviews, and the delivery channel (digital, phone, video, in person) as an attribute. Advice programs and service tiers are offerings in 01; enrollment is on the account (15); the investor profile is on the client (02).",
     "rationale": "One advice domain, with delivery channel as data, serves digital and human advice alike; products split by function. Lever: a self-directed-only firm drops 45 and 46.",
     "action": "W2", "status": W0, "priority": "High", "owner_role": PL},

    {"id": "CW-009", "theme": "Ownership", "title": "Discretionary management of client accounts is 46, not 24",
     "domains": ["01", "24", "46", "48", "49"],
     "issue": "Managing millions of client accounts to models is operationally and regulatorily distinct from constructing fund and institutional portfolios.",
     "resolution": "46 Managed Portfolios & Rebalancing masters model assignment per account and household, account-level targets and constraints, drift and rebalance triggers, tax-loss-harvesting and asset-location decisions, wash-sale control, and the trade proposals handed to 48. 24 keeps fund and institutional construction and gains capital-market assumptions, strategic allocation and glide paths that 46 consumes through the 01 model portfolio (MDL-).",
     "rationale": "Investment Company Act Rule 3a-4 programs run on account-level data at retail scale; the fund desk does not.",
     "action": "W2 (46), W3 (24 families)", "status": W0, "priority": "High", "owner_role": PL},

    {"id": "CW-010", "theme": "Ownership", "title": "Client orders (48) are not portfolio orders (25)",
     "domains": ["25", "48", "49"],
     "issue": "25 Trading & Execution is the fund trading desk. Client orders in a brokerage have their own lifecycle, venues, disclosures and reporting.",
     "resolution": "48 Brokerage Orders & Execution masters client orders, routing, executions, allocations to accounts, confirmations (Rule 10b-10), corrections, execution-quality and routing disclosure (Rules 605 and 606) and CAT reporting. 25 is renamed Portfolio Trading & Execution. Term conflict Order is logged; the prefixes differ.",
     "rationale": "Different regulation, systems and grain.",
     "action": "W3", "status": W0, "priority": "High", "owner_role": PL},

    {"id": "CW-011", "theme": "Certified numbers", "title": "Client Assets and Firm AUM are two certified families, reconciled and never summed (amends CD-292)",
     "domains": ["06", "18", "27", "46", "49", "21"],
     "issue": "CD-292 defines Firm AUM for a manufacturer in three slices. A wealth manager reports client assets under administration as its headline and manages only part of them.",
     "resolution": "Client Assets: the market value of every client account at the firm, by channel (direct self-directed, advised and managed, workplace, intermediary-held own-fund assets) and holding type (own funds, third-party funds, securities, cash); owner Head of Client & Channel Analytics; successor of DP-008. Firm AUM: own funds' net assets at NAV (DP-165) plus managed-account and institutional assets at portfolio market value (46, 18); fund slice owned by the Head of Fund Accounting, advisory slice by the Head of Managed Account Operations. Also certified: Net New Assets by channel; Advised Assets; Households, Clients and Accounts; Personal Rate of Return (DP-145 extended); revenue, expense, headcount and pay as today. The reconciliation product (successor of DP-241) nets the overlap: own-fund holdings in client accounts appear in both families.",
     "rationale": "The two numbers answer different questions and overlap by design; summing them double counts own funds held by clients.",
     "action": "WP0", "status": W0, "priority": "High", "owner_role": PL},

    {"id": "CW-012", "theme": "Ownership", "title": "Fees and billing are an operational domain (47); 10 keeps revenue and profitability",
     "domains": ["10", "12", "15", "16", "47"],
     "issue": "Fee schedules, calculation and billing of advisory, brokerage and account fees have no operational owner; 12 holds mandate billing and 10 the revenue view.",
     "resolution": "47 Pricing, Fees & Billing masters fee schedules and pricing tiers, householding and breakpoints, fee calculation runs, fee debits and invoices, commission and account-fee schedules, waivers and credits, fee disclosures delivered and the custody-rule conditions on fee deduction (Advisers Act Rule 206(4)-2). 12's Fee Billing & Invoicing family moves to 47. 10 becomes Client Revenue, Pricing Economics & Profitability by offering, channel and segment.",
     "rationale": "Billing is a controlled process with its own system and evidence; revenue recognition is finance.",
     "action": "W2 (47), W4 (10, 12)", "status": W0, "priority": "Medium", "owner_role": PL},

    {"id": "CW-013", "theme": "Scope", "title": "The intermediary business is a channel: 03, 05, 06, 07, 11 compress; 07 retired",
     "domains": ["03", "05", "06", "07", "11"],
     "issue": "Seven wholesale domains model intermediary distribution in depth. The archetype sells through advisors as a secondary channel.",
     "resolution": "05 becomes Intermediary & Institutional Distribution (L1 code DI): channel partners and hierarchy, selling and platform agreements, model and SMA delivery to advisors, institutional sales and consultant relations, RFPs. 06 becomes Client Assets, Flows & Channel Attribution across every channel. 03 becomes Advisor Organization, Coverage & Supervision (L1 code AO) for the firm's own advisors, taking coverage and incentive compensation from 07. 07 is retired; territories survive only as advisor assignment. 11 is adapted to the retail and wealth market.",
     "rationale": "Reference default is thin. Lever: restore wholesale depth from the sibling for a firm with a large advisor-channel business.",
     "action": "W2 (03), W4 (05, 06, 11; 07 retired)", "status": W0, "priority": "Medium", "owner_role": PL},

    {"id": "CW-014", "theme": "Scope", "title": "External managers return: 52 External Manager & Sub-Adviser Oversight",
     "domains": ["23", "33", "35", "39", "52"],
     "issue": "The wholesale model dropped the domain because all management was in house. A Vanguard-type firm sub-advises much of its active range and vets third-party funds for its platform and advice models.",
     "resolution": "52 masters manager search, due diligence and scoring, sub-advisory agreements under Section 15(c), mandate guidelines given to sub-advisers, oversight reviews and findings, third-party fund and ETF due diligence for the platform and models, approved and watch lists. Contracts are indexed by 39; board approvals by 35; guideline monitoring by 33.",
     "rationale": "Manager selection and oversight is a function with its own owner, data and regulation. Lever: drop 52 for a firm that manages everything in house.",
     "action": "W3", "status": W0, "priority": "Medium", "owner_role": PL},

    {"id": "CW-015", "theme": "Scope", "title": "Retail conduct and supervision replace distribution compliance (08 replaced)",
     "domains": ["03", "08", "38", "45"],
     "issue": "08 Distribution Compliance is built around marketing review, know-your-distributor, inducements and cross-border marketing.",
     "resolution": "08 is replaced by Retail Conduct & Supervision (L1 code RC): Reg BI and Form CRS, suitability and best-interest surveillance, supervision under FINRA Rules 3110, 3120 and 3130, complaints (Rule 4530), senior and vulnerable investor protection (Rule 2165), communications review (Rule 2210 and the Advisers Act marketing rule), licensing and registration of own representatives (Forms U4 and U5, Series 7 and 66, IAR registration), options and margin suitability oversight, rollover recommendation review. 38 keeps the firm-level programs (AML, code of ethics, firm registrations) and adds broker-dealer registration and Form CRS filing.",
     "rationale": "The conduct risk of a wealth manager sits in recommendations to retail clients and the supervision of its own representatives.",
     "action": "W2", "status": W0, "priority": "High", "owner_role": PL},

    {"id": "CW-016", "theme": "Scope", "title": "Money movement is its own domain (50); private markets (30) retired",
     "domains": ["30", "43", "49", "50", "01", "15"],
     "issue": "Cash in and out of client accounts (ACH, wire, check, debit card, sweep) has no owner; 30 Private Markets manufactures a line the archetype does not run.",
     "resolution": "50 Money Movement, Cash & Sweep masters ACH, wire, check and debit-card transactions, standing instructions by reference to 15, bank sweep programs and program banks, money market sweep, FDIC pass-through allocation, holds and returns, fraud and elder-exploitation holds (FINRA Rule 2165) and cash-movement AML monitoring. It references 43 for the firm's own bank accounts and 49 for settlement cash. 30 is retired; feeder-fund access to alternatives is a family of 01 and 15.",
     "rationale": "Money movement is the largest operational risk surface of a direct business. Lever: a firm with private-markets manufacturing restores 30 from the sibling.",
     "action": "W3 (50), W4 (30 retired)", "status": W0, "priority": "Medium", "owner_role": PL},

    {"id": "CW-017", "theme": "Scope", "title": "Trust services as an optional Light domain (51)",
     "domains": ["02", "15", "46", "49", "51"],
     "issue": "A national trust company is common at this archetype but not universal.",
     "resolution": "51 Trust & Estate Services (Light, optional, listed in OPTIONAL_DOMAINS) masters trust instruments and terms, trustee roles, grantors and beneficiaries, discretionary distribution decisions, trust accounting (principal and income), estate settlement cases and fiduciary tax (Form 1041). Parties, accounts, holdings and investment management are referenced from 02, 15, 49 and 46.",
     "rationale": "Kept in the reference set so the fiduciary record has a home. Lever: drop.",
     "action": "W2", "status": W0, "priority": "Low", "owner_role": PL},

    {"id": "CW-018", "theme": "Structure", "title": "Areas of the wealth model (replaces the six areas of the wholesale model)",
     "domains": [],
     "issue": "The wholesale areas put product management under Distribution & Client and have no home for advice, brokerage operations or workplace services.",
     "resolution": "Eight areas plus the Foundations band: Investment (23, 24, 25, 34, 52); Investment Operations (18, 22, 26, 31, 32, 33); Fund Operations (27, 28, 29, 35); Client & Advice (01, 36, 02, 15, 45, 46, 03, 04, 13, 47, 08, 51); Brokerage & Workplace Operations (48, 49, 50, 16); Distribution, Channels & Client Economics (05, 06, 10, 11, 12); Corporate Functions (19, 20, 37 to 44); Foundations (09, 17, 14, 21). Areas remain presentation; boundary calls are recorded in areas.py as today.",
     "rationale": "Client & Advice is the new center; brokerage and workplace operations are a back office distinct from fund operations.",
     "action": "Applied in capability_map/areas.py and the explorer views at W0 and W5", "status": W0, "priority": "Medium", "owner_role": PL},

    {"id": "CW-019", "theme": "Structure", "title": "Retired Data Domains and replaced domains in the baseline check",
     "domains": ["07", "30"],
     "issue": "check_baseline.py compares every protected domain in full. A replaced domain under the same number would report every object as changed; a retired domain would report every object as removed.",
     "resolution": "domains.py gains RETIRED_DOMAINS (07, 30, each with the decision that retired it) and DISPOSITION (keep, adapt, replace, retire, new per domain). check_baseline.py compares replaced domains by counts only once their replacement module lands, reports retired domains as 'retired by CW-nnn', and treats 45 to 52 as expansion additions. The wholesale-v1.0 snapshot is the comparison baseline until wealth-taxonomy-v0.1 is taken at W5.",
     "rationale": "The check must stay useful: full comparison for carried domains, counts for replaced ones.",
     "action": "Applied at W0", "status": W0, "priority": "Medium", "owner_role": PL},

    {"id": "CW-020", "theme": "Governance", "title": "Per-row ownership, governance metadata and the data products rules carry over unchanged",
     "domains": [],
     "issue": "Which of the wholesale model's conventions apply to the sibling.",
     "resolution": "All of them: the ownership rule, per-row ownership (CD-289), governance metadata modeled once in 21 (CD-160), the product rule (a product assembles what the domains master and never remasters it), certified numbers defined once, the three contracts, the quality bar and the agent pipeline. The jurisdiction register (CW-003) and the identifier series (CW-002) are the only additions.",
     "rationale": "The method is what makes the model trustworthy; the content is what changes.",
     "action": "Stated in the conventions document at W0", "status": W0, "priority": "Low", "owner_role": PL},
]
