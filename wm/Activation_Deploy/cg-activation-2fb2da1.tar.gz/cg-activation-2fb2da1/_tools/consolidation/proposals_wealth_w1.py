"""Wealth-manager reference model: W1 brief decisions (CW-021 to CW-040) and reserved prefixes.

Briefs accepted 2026-10-14: DECISIONS and PREFIXES below are merged into decisions.py (kept here as the record of the proposal).

Written by the W0 brief agent with the W1 briefs in 00_Program/Rework/Briefs/ (02_Client_and_Household.md,
15_Account.md, 01_Investment_Product_and_Service_Offering.md, W1b_Carry_Over_Pass.md). Format: the DECISIONS dict format
and the PREFIXES tuple format of decisions.py (see CONTRACT.md). Declarative only. Every decision is "Proposed" until the
program lead merges it; each states the tailoring lever where a client could rule differently.

Pre-allocated ids (CW-022): the US-only pass of Data Domain NN is decided under CW-9NN (CW-901 for 01, CW-902 for 02,
CW-909, CW-914 ... CW-944). The drafters write those decisions in proposals_NN.py; they are not in this file.
"""

PL = "Program lead"
P = "Proposed"

DECISIONS = [
    # ---- Mechanics of the rework --------------------------------------------------------------------------------
    {"id": "CW-021", "theme": "Structure", "title": "Replaced domains keep the object names that carried modules reference",
     "domains": ["02", "15", "13", "16", "18", "24", "25", "26", "28", "29", "32", "33", "34", "38", "39", "43"],
     "issue": "02 and 15 are replaced in W1 while 30 carried and adapted modules reference their objects: Reference (Party) 460 times, (Account) 61, (Contact Point), (Consent Record), (Client Restriction), (KYC Profile), (Onboarding Case), (Account Restriction), (Bank Instruction), (Account Standing Instruction), (Beneficiary Designation), (Retirement Plan). A new design that renamed them would break resolution in domains the program does not otherwise touch.",
     "resolution": "The wealth 02 keeps by exact name: Party, Organization, Individual, Legal Entity Hierarchy, Party Role, Party Identifier, LEI Record, US Regulatory Identifier, Market Infrastructure & Vendor Identifier, Household, Household Membership, Party Relationship, Onboarding Case, KYC Profile, Beneficial Ownership, Tax Profile, Regulatory Classification, Segment Assignment, Contact Point (now one object, CTP-), Contact Preference, Communication Preference, Consent Record, Privacy Profile, Client Restriction, Restricted Client Status and a thin Retirement Plan. The wealth 15 keeps: Account, Account Identifier, Account Hierarchy Link, Account Party Role, Account Registration Detail, Custodial Account Detail, Beneficiary Designation, Intermediary Account Servicing, Institutional Account, Plan Participant Account, Account Tax Certification, Account Tax Reporting Status, Cost Basis Election, Account Standing Instruction, Bank Instruction, Account Preference, Account Opening, Account Lifecycle Event, Account Status History, Account Closure, Account Restriction. Prefixes kept: PTY- (PTY-HH-), CTP-, CNS-, ONB-, CRX-, ACC-, ACI-, ABD-, ATC-, SIN-, ABI-, ALE-, ARX-. Mechanics: 02 is written as content_02_client_and_household.py beside the wholesale module; 15 is rewritten in place; enrich_02.py and enrich_15.py are rewritten in place; the program lead deletes the wholesale 02 module and folder at integration (both stay at tag wholesale-v1.0). Dropped objects are listed in the briefs and in review_checklist_wealth.md section 8.",
     "rationale": "The W1 gate (plan section 10) requires every Reference (Party) and Reference (Account) in the carried modules to resolve; keeping names makes the replacement invisible to them.",
     "action": "W1", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-022", "theme": "Scope", "title": "Mechanics of the US-only pass: decision ids, records, scope and the investment-universe principle (amends CW-003)",
     "domains": ["01", "02", "03", "04", "05", "06", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44"],
     "issue": "CW-003 requires one CW- decision per domain and a register entry per removal, but several agents run at once and cannot edit jurisdiction.py or allocate ids without colliding. Its domain list omits adapted and replaced domains that hold EU/UK content (02, 03, 04, 05, 06, 10, 11, 12, 15, 16, 18, 24, 32). Nothing says whether 'US only' removes foreign instruments and markets.",
     "resolution": "1) Ids: the US-only pass of Data Domain NN is decided under CW-9NN (CW-901 ... CW-944), pre-allocated so that agents never collide with the sequential series. 2) Records: the drafter or editor writes JURISDICTION = [...] in proposals_NN.py in the exact REMOVALS entry format of jurisdiction.py and drafts the CW-9NN decision there; the program lead appends the entries to jurisdiction.REMOVALS and merges the decision at integration. A replaced domain records the EU/UK concepts of the wholesale module it leaves out. 3) Scope: every carried, adapted and replaced domain, in its own stage: W1 for 01, 02, 09, 15, 17; W1b for the 22 kept domains 14, 18, 19, 20, 21, 22, 23, 25, 26, 27, 28, 31, 33, 34, 35, 37, 39, 40, 41, 42, 43, 44; W2 to W4 for the rest (38 with its W4 adaptation). 4) Principle: US only narrows where the firm is regulated, distributes and services clients; foreign instruments, issuers, markets, currencies, calendars, reference rates, sub-custodians, foreign tax reclaim and contract governing law stay. 5) References to 30, 07 and to domains replaced in later stages are not removed in W1b; they are listed for the W2 and W4 decisions.",
     "rationale": "Pre-allocated ids and per-domain files let five editors and five drafters work in parallel; the principle stops the pass from deleting what an international fund range needs.",
     "action": "W1, W1b, W2 to W4; jurisdiction.REMOVALS filled at each merge", "status": P, "priority": "High", "owner_role": PL},

    # ---- 02 Client & Household --------------------------------------------------------------------------------------
    {"id": "CW-023", "theme": "Ownership", "title": "Role profiles leave 02; the party core stays for every external party",
     "domains": ["02", "03", "05", "12", "16", "17", "25", "40"],
     "issue": "CW-005 makes the client household the primary role of 02 and says intermediary, consultant and plan profiles live in 05 and 16. The wholesale 02 holds those profiles as objects (Distributor Firm, Form ADV Profile, Hierarchy Node, Branch / Office, Advisor Team, Gatekeeper Profile, Financial Professional, Advisor Practice, Employment Affiliation, Institutional Client, Consultant Profile, Recordkeeper Profile, Plan Service Provider, End Investor) and CD-143 makes 02 the party core for issuers, brokers, vendors and every other external party.",
     "resolution": "02 keeps the party core for every external party (Party, Organization, Individual, Legal Entity Hierarchy, Party Role, identifiers including CRD, LEI and NSCC numbers) under CD-143. Role profiles move with their names unchanged: Distributor Firm, Form ADV Profile, Hierarchy Node, Branch / Office, Advisor Team, Gatekeeper Profile, Financial Professional, Advisor Practice, Employment Affiliation, Team Membership, External Classification, Consultant Profile and Consultant Advisory Relationship to 05 at W4; Institutional Client to 12 at W4; Recordkeeper Profile and Plan Service Provider to 16 at W3, with the statistical attributes of Retirement Plan (plan assets, participants, QDIA type, Form 5500 year, fiduciary adviser type). 02 keeps a thin Retirement Plan (name, number, type, sponsor, sponsor EIN) so that 15 and 16 references resolve. End Investor is dropped: intermediary look-through data is summarized in 06. Between W1 and the receiving stage the moved objects exist only in the wholesale sibling; the receiving drafter restores them from tag wholesale-v1.0.",
     "rationale": "One party, many roles; each role's profile is stewarded by the team that maintains it (the Issuer Profile pattern). Lever: a firm with a large intermediary business restores the profiles in 05 at full depth.",
     "action": "W1 (02 drops), W3 (16 receives), W4 (05 and 12 receive)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-024", "theme": "Ownership", "title": "Investor profile (02), account investment profile (15) and goals (45) are three records",
     "domains": ["02", "15", "45", "46", "08"],
     "issue": "Reg BI (Rule 15l-1) defines a retail customer investment profile per customer; SEC Rule 17a-3(a)(17) and FINRA Rule 4512 require an investment objective per account; financial planning records goals. The wholesale 15 holds Account Investment Objective; 45 will hold goals. Without a rule the same objective is held three times.",
     "resolution": "02 masters the Investor Profile (INPR-), versioned per client: objectives, risk tolerance, time horizon, liquidity needs, financial situation bands, tax bracket, investment experience by product type, questionnaire version and score, trigger and attestation. 15 masters the Account Investment Profile (attribute group of Account): the objective, risk tolerance, time horizon and purpose recorded for that account, with a reference to the 02 profile version it was set against and an indicator that it differs from the client profile. 45 masters goals and plans and references the profile version a recommendation relied on; it never copies profile values. Options and margin approvals (15) reference the profile version used. 08 supervises; it holds none of the values.",
     "rationale": "Each record has its own rule and owner; references, not copies, keep the evidence chain intact. Lever: a household-only firm keeps one profile per household (02 profile scope).",
     "action": "W1 (02, 15), W2 (45, 08)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-025", "theme": "Ownership", "title": "Identity verification and beneficial ownership are mastered once in 02 for every CIP program",
     "domains": ["02", "15", "29", "38", "50"],
     "issue": "The broker-dealer (31 CFR 1023.220), the funds through the transfer agent (31 CFR 1024.220) and the optional trust company (31 CFR 1020.220) each run a customer identification program. The wholesale 29 masters CIP Verification (CIP-) for TA accounts; the wholesale 02 holds KYC Profile and Beneficial Ownership. A direct client would be verified in two masters.",
     "resolution": "02 masters Identity Verification (KYCV-; party x CIP program x verification: method, document type, masked number, result, discrepancy resolution, retention end) and Beneficial Ownership Certification (BOWN-; legal-entity customer x certification under 31 CFR 1010.230) with Beneficial Ownership rows. KYC Profile (current due-diligence state) stays in 02. 15 Account Opening references the verification. At W3 the 29 CIP Verification is re-cut to a reference to 02 KYCV- and the CIP- prefix is retired, unless the 29 brief shows an outsourced-TA case that needs a received copy. 38 keeps the AML program, SAR cases and the sanctions program; 50 keeps cash-movement monitoring.",
     "rationale": "Identity is a party fact; one verification record per program, shared evidence, one master. Lever: an outsourced TA that runs the fund CIP keeps a 29 oversight copy.",
     "action": "W1 (02), W3 (29 re-cut)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-026", "theme": "Ownership", "title": "Authorized persons, trusted contacts and beneficiaries are parties; their grants and designations are split between 02 and 15",
     "domains": ["02", "15", "13", "50", "51"],
     "issue": "The wholesale 15 Account Role Type carries Power of Attorney and Trusted Contact Person as account roles. FINRA Rule 4512 trusted contact information is collected per customer account but used per person (FINRA Rule 2165); a power of attorney is granted by a person and often covers several accounts.",
     "resolution": "02 masters Authority Grant (AGNT-; grantor x holder x authority type: durable or limited POA, limited or full trading authorization, guardian, conservator, executor, entity authorized signer; scope; accounts covered by reference to 15) and Trusted Contact Designation (TCNT-; client x trusted contact x period, with account scope, declined indicator and the Rule 2165 disclosure date), and Death Notification. Beneficiaries, trusted contacts and agents are 02 parties. 15 masters Beneficiary Designation (ABD-) and Account Party Role; the values Power of Attorney and Trusted Contact Person leave the Account Role Type list. 13 handles the requests that create them; 51 keeps trustee roles under trust instruments.",
     "rationale": "A grant or designation made by a person is a party fact with an account scope; a beneficiary designation is an account fact. Lever: a firm that captures trusted contacts per account sets the scope to one account.",
     "action": "W1", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-027", "theme": "Ownership", "title": "Three household concepts: client household (02), mailing household (13), fee household (47)",
     "domains": ["02", "13", "47", "32", "06"],
     "issue": "'Household' names three groupings: the client's family or economic unit (02 PTY-HH-), the 13 mailing householding group (MHG-) for SEC householding of documents, and the grouping of accounts for fee breakpoints. The plan's term-conflict watchlist names Household (02 party; 13 mailing household).",
     "resolution": "02 masters the Client Household (a party of type Household, PTY-HH-) and effective-dated Household Membership. 13 keeps the Mailing Household (MHG-). 47 masters the Fee Household (the accounts aggregated for breakpoints), which references 02 households and 15 accounts but may differ from them. 32 household returns and 06 household client assets aggregate by 02 membership as of the measurement date. Glossary terms: Client Household, Mailing Household, Fee Household.",
     "rationale": "Each grouping has its own rule and owner; naming them avoids silent reuse. Lever: a firm that bills strictly by client household lets 47 reference 02 membership without its own grouping.",
     "action": "W1 (02), W2 (47, 13), term conflict logged at W5", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-028", "theme": "Ownership", "title": "Service tiers are defined in 01 and assigned in 02; segmentation and regulatory classification stay in 02",
     "domains": ["01", "02", "06", "47"],
     "issue": "Relationship tiers with asset thresholds and benefits (advisor access, fee discounts) are product decisions, but each client's or household's tier is a client fact that changes with assets.",
     "resolution": "01 masters Service Tier (tier code, threshold, measurement basis, benefits, fee discount reference to 47). 02 masters Service Tier Assignment (household or party x tier x period, qualifying assets as a Derived copy of 06 Client Assets, assignment basis, override approver), Segment Assignment and Regulatory Classification (Reg BI retail customer, FINRA Rule 4512(c) institutional account). 47 applies tier discounts by reference.",
     "rationale": "Definition and assignment have different owners and change at different rates. Lever: a firm without tiers drops the family.",
     "action": "W1", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-029", "theme": "Ownership", "title": "Privacy and consent under Reg S-P, Reg S-AM, GLBA and state law are mastered in 02",
     "domains": ["02", "04", "13", "41"],
     "issue": "The wholesale 02 privacy family is built on GDPR (lawful basis, legitimate interests assessments, data subject requests). The wealth model is US only and personal data is pervasive (plan section 11).",
     "resolution": "02 masters Privacy Profile (applicable US regimes, GLBA nonaffiliated-sharing opt-out, Reg S-AM affiliate-marketing opt-out, state-law sale or sharing opt-out, do-not-contact), Consent Record (CNS-; purposes re-cut: electronic delivery under E-SIGN, account aggregation access, call recording, voice biometrics, marketing) and Consumer Privacy Request (renamed from Data Subject Request). Processing Legal Basis and Retention are dropped (GDPR; retention metadata is 21). 13 delivers privacy notices (COMM-) and keeps E-Delivery Election (DEL-) linked to a Consent Record; 04 applies opt-outs to marketing; 41 keeps the Reg S-P safeguards and incident-response program.",
     "rationale": "Consent and opt-outs are party facts; delivery and safeguards are operational. Lever: a firm subject to further state laws extends the regime list.",
     "action": "W1 (02), W1b (41)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-030", "theme": "Governance", "title": "Special-category client data: specified adult status and vulnerability concerns (CD-344 applied to clients)",
     "domains": ["02", "15", "50", "08", "13"],
     "issue": "FINRA Rule 2165 holds, diminished capacity, suspected financial exploitation and financial hardship are sensitive facts about a person. The plan's quality bar applies the special-category rule of CD-344 to them.",
     "resolution": "02 masters Specified Adult Status (attribute group of Party: basis age 65 or older or belief of impairment, determination date and determiner) and Vulnerability Concern (party x concern: type, source, trusted contact contacted, escalation reference to 08, resulting 15 account restrictions), both flagged 'PII - special category (CD-344)'. 15 masters account restrictions (ARX-, Rule 2165 temporary hold), 50 disbursement holds (MMH-), 08 the supervisory case. Products and semantic models read these objects as aggregates or restricted views only.",
     "rationale": "Hold the facts once, flag them, and restrict their use by product. Lever: a firm that does not record diminished capacity keeps only Specified Adult Status.",
     "action": "W1 (02, 15), W2 (08), W3 (50), WP1 (products)", "status": P, "priority": "High", "owner_role": "Data Protection Officer"},

    # ---- 15 Account ------------------------------------------------------------------------------------------------
    {"id": "CW-031", "theme": "Ownership", "title": "Account features, approvals and agreements are mastered in 15; balances, programs and cards are not",
     "domains": ["15", "49", "50", "08", "48", "20"],
     "issue": "Margin, options, sweep, cash management, debit card, fully paid lending, extended-hours and fractional trading are each an election or approval on the account, a program or product defined elsewhere, a balance or a transaction.",
     "resolution": "15 masters Account Feature (AFEA-; account x feature type x period, status and approval), its Options Approval Detail (level, strategies, approving principal from 20, investor profile version, options disclosure document date, FINRA Rule 2360(b)(16) verification) and Margin Account Detail (margin agreement, Reg T account type, pattern day trader designation, FINRA Rule 2264 disclosure), Sweep Election (account x sweep vehicle x period, Rule 15c3-3(j)(2) notice, excluded program banks), Account Agreement (AAG-; customer, margin, options, advisory, custodial, fully paid lending agreements, trust certifications, corporate resolutions; version and signature) and Account Disclosure Delivery (account-opening and feature disclosures; fee disclosures are 47). 49 masters margin balances and calls, fully paid loans and possession and control; 50 masters the sweep program, program banks, debit-card instances and check stock; 08 supervises approvals; 48 checks features at order time.",
     "rationale": "Elections and approvals are account facts with their own evidence; the money and securities they govern are elsewhere. Lever: drop a feature by dropping its type (plan section 15 item 3).",
     "action": "W1 (15), W2 (08), W3 (48, 49, 50)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-032", "theme": "Ownership", "title": "Program enrollment (15) is not the offering (01), the model (46), the fee (47) or the recommendation (45)",
     "domains": ["01", "15", "45", "46", "47"],
     "issue": "Advisory programs touch five records: what the program is, which account is in it, which model it follows, what it costs and why it was recommended. The wholesale 15 holds Platform Program Enrollment with Assigned Model Portfolio, and an Advisory Program Indicator.",
     "resolution": "01 masters the Service Offering (OFFR-). 15 masters Program Enrollment (ENRL-; account x offering x period: status, discretion, source recommendation, Form ADV brochure and advisory agreement references, Rule 3a-4 restrictions by reference to 02 CRX-, termination reason). 46 masters the model assignment, account targets and tax-loss-harvesting preference. 47 masters the fee schedule assignment and the fee-paying account. 45 masters the recommendation. Platform Program Enrollment and Advisory Program Indicator are dropped; intermediary platform programs are 05.",
     "rationale": "Each fact changes for a different reason and is supervised differently; one enrollment record keys them together. Lever: enrollment per household adds a household reference.",
     "action": "W1 (01, 15), W2 (45, 46, 47)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-033", "theme": "Ownership", "title": "Standing and bank instructions are mastered in 15; 50 and 29 execute them (amplifies CW-016)",
     "domains": ["15", "29", "50", "13"],
     "issue": "CW-016 gives 50 the money movement and says standing instructions are referenced from 15. The boundary for bank verification, recurring transfers and automatic RMD payments needs stating.",
     "resolution": "15 masters Account Standing Instruction (SIN-; automatic investment, systematic withdrawal, automatic RMD, recurring transfer between accounts, distribution option) and Bank Instruction (ABI-; masked account, ABA routing number, verification status and method). 50 masters every money movement a standing instruction generates, the verification events (micro-deposits, instant verification) as transactions, holds and returns; 29 masters fund orders a systematic instruction generates. 13 masters the request that set up or changed an instruction.",
     "rationale": "The definition of an instruction and the transactions it generates have different owners and grains (wholesale design principle 4 of 15).",
     "action": "W1 (15), W3 (50)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-034", "theme": "Ownership", "title": "Account tax status, cost-basis election and the IRA RMD record are 15; lots are 49, plan RMD is 16, forms are 13",
     "domains": ["02", "13", "15", "16", "49", "50"],
     "issue": "Tax facts sit at four grains: the party (US person, classification, TIN), the account (certification on file, backup withholding, cost-basis method, RMD), the lot (basis, covered status) and the form (1099, 5498). The wholesale 15 also holds CRS self-certification, which the US does not apply.",
     "resolution": "02 Tax Profile: party tax status and masked TIN. 15: Account Tax Certification (ATC-; W-9 and W-8 family), Account Tax Reporting Status (backup withholding, B-notices, exempt payee and FATCA exemption codes, chapter 3 rate), Cost Basis Election (method and scope), RMD Record (account x distribution year, with prior year-end value as a Derived copy of 49 and satisfied amount as a Derived copy of 50) and Retirement Distribution Election (Form W-4R and state withholding). 49 masters client lots, basis and covered-security status (IRC section 6045). 16 keeps the plan RMD Calculation (PRMD-). 13 produces Forms 1099 and 5498. CRS fields and values are removed (CW-915).",
     "rationale": "Each tax fact is mastered at the grain the rule applies to.",
     "action": "W1 (15), W3 (49)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-035", "theme": "Ownership", "title": "Every account kind is a 15 account; alternative-investment subscriptions are 15",
     "domains": ["15", "16", "29", "51", "12", "06", "01", "49"],
     "issue": "The plan's term-conflict watchlist names Account in 15, 29, 16 and 43. Mutual-fund-only accounts at the TA, participant accounts at the recordkeeper, trust-company fiduciary accounts and institutional separate accounts could each grow their own master; feeder-fund subscriptions need a home now that 30 is retired.",
     "resolution": "Brokerage, mutual-fund-only (TA-registered), managed advisory, workplace participant, trust-company fiduciary, institutional separate, omnibus-at-TA and firm proprietary accounts are Account Types of the one 15 master (ACC-). 29 keeps orders and processing; 06 the Fund Shareholder Position view; 16 participant membership (PMEM-); 51 the trust terms (TRS-), referenced from the account; 12 servicing of institutional accounts; 43 the firm's own bank accounts, which are not 15 accounts. 15 masters Alternative Investment Subscription (AISB-; account x feeder product x offering window: amount, qualification reference, documents, acceptance, funded amount as a Derived copy of 50); 49 holds the resulting Client Holding. Glossary: Brokerage Account, Fund-Only Account, Participant Account, Fiduciary Account, Corporate Bank Account (43).",
     "rationale": "One account master keeps one key for custody, tax, enrollment and billing. Lever: a firm without legacy fund-only accounts drops the type.",
     "action": "W1 (15), W3 (16, 29, 49), W2 (51)", "status": P, "priority": "High", "owner_role": PL},

    # ---- 01 Investment Product & Service Offering ------------------------------------------------------------------
    {"id": "CW-036", "theme": "Ownership", "title": "Advice and service offerings are 01 objects; fund expense terms stay 01 and client fees are 47",
     "domains": ["01", "02", "15", "45", "46", "47"],
     "issue": "Plan section 5.1 adds Advice & Service Offerings to 01 with fee schedule references to 47. 01 already reserves FSCH- for versioned fund fee schedules (CD-023), and the plan's anchor for 47 is FSC-, one deletion from FSCH-.",
     "resolution": "01 masters Service Offering (OFFR-; type, delivery mode, discretion, advisory or Reg BI capacity, sponsoring entity, wrap fee and Rule 3a-4 indicators, model portfolios used, minimum, status), Offering Feature, Offering Eligibility Rule (ELIG-), Offering Fee Schedule Link (offering x 47 fee schedule x period) and Service Tier (CW-028). 01 keeps the prospectus expense terms of share classes (management, 12b-1 and servicing fees, expense ratios, loads, purchase and redemption fees) under FSCH-. 47 masters client fee schedules (advisory, commission, account service, plan), their versions, assignments, waivers and billing. FSC- is not registered: the 47 brief chooses a prefix that is not confusable with FSCH-. Family codes for the new 01 families use the PR- stem (CW-040).",
     "rationale": "Clients choose between funds and programs together, and 36 governs both; pricing and billing are 47's operational process. Lever: a self-directed-only firm drops the family.",
     "action": "W1 (01), W2 (47 prefix)", "status": P, "priority": "High", "owner_role": PL},

    {"id": "CW-037", "theme": "Ownership", "title": "Brokerage platform offering: policy in 01, instrument flags in 17, due diligence in 52, fee amounts in 47, checks in 48",
     "domains": ["01", "17", "47", "48", "52"],
     "issue": "The tradable universe, fractional and extended-hours eligibility and third-party fund availability (no-transaction-fee or transaction-fee) involve policy, instrument facts, vetting, pricing and order handling.",
     "resolution": "01 masters Tradable Universe Policy Rule (TUP-; rule type, criteria, session times for extended hours, approving committee, period) and Platform Product Availability (own share class or third-party instrument x period: availability status, transaction-fee category, platform minimums, due diligence approval reference, restriction reason). 17 masters the instrument and its resulting flags (Fractional Trading Eligible, Extended-Hours Eligible) with a reference to the TUP- rule that set them. 52 masters third-party product due diligence (PDD-). 47 masters the transaction-fee amounts. 48 applies the rules and flags to client orders.",
     "rationale": "Policy, instrument fact, vetting, price and check each have one owner. Lever: an open-architecture platform without curation drops the due diligence reference.",
     "action": "W1 (01, 17), W2 (47), W3 (48, 52)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-038", "theme": "Ownership", "title": "Alternative-investment access through feeder funds: product and window in 01, subscription in 15, holding in 49, manager in 52",
     "domains": ["01", "02", "15", "17", "49", "50", "52"],
     "issue": "CW-016 retires 30 and makes feeder access a family of 01 and 15 (plan section 2).",
     "resolution": "The feeder fund is a 01 Investment Product (vehicle Feeder Fund) with Feeder Access Terms (attribute group: access structure, underlying fund instrument from 17, placement agent, qualification required, minimum commitment, liquidity terms) and Offering Window (OFWN-; open, close, capacity, allocation). Investor qualification is 02 Investor Qualification; the subscription is 15 Alternative Investment Subscription (CW-035); capital calls and distributions are 50 money movements and 49 client account activity; the underlying private fund is a 17 fund-interest instrument held in the feeder's 18 portfolio; the underlying manager's due diligence is 52.",
     "rationale": "Feeder access is distribution of a product the firm wraps, not private-markets manufacturing. Lever: a firm with private-markets manufacturing restores 30 from the sibling.",
     "action": "W1 (01, 15), W3 (49, 50, 52)", "status": P, "priority": "Medium", "owner_role": PL},

    # ---- Registers and codes ----------------------------------------------------------------------------------------
    {"id": "CW-039", "theme": "Code Lists", "title": "Shared code lists re-cut for the wealth model (02, 15, 01, 09 and expansion stewards)",
     "domains": ["01", "02", "09", "15", "18", "19", "26", "31", "40", "41"],
     "issue": "Several shared lists carry EU/UK values or exist only for an EU/UK regime; drafters must know which values to copy.",
     "resolution": "Retired: MiFID Client Category (02), CRS Entity Classification (02), Distribution Strategy (01; MiFID service types), DORA ICT Service Type (41), DORA Substitutability (40), COLL Change Classification (36, at W4). Re-cut to US values: Investor Category (02; drop PROFESSIONAL, ELIGIBLE_COUNTERPARTY, QUALIFIED_INVESTOR), Investor Qualification Standard (02; drop AIFMD_PROFESSIONAL_INVESTOR), Regulatory Regime (01), MMF Type (01; Rule 2a-7 values), Regulator (09), Distribution Market (09), Geographic Unit Type (09), Accounting Basis (19), Lot Relief Method (18), Exposure Method (31), Regulatory Trade Report Regime (26), Fund Dealing Settlement Method (29, at W3), Dealing Route (06, at W4), Distribution Channel (09, at W4). Kept: Networking Level (15) for the IC line; Business Line per CW-004. Vehicle Type gains Feeder Fund and Tender-Offer Fund; Instrument Type (17) gains Certificate of Deposit and Municipal Fund Security. Drafters copy the re-cut values now and record removed values in JURISDICTION; the program lead applies the lists at W5.",
     "rationale": "Shared lists are joined at consolidation; drafters need the target values before then.",
     "action": "W1 to W4 (local copies), W5 (shared_code_lists.py)", "status": P, "priority": "Medium", "owner_role": PL},

    {"id": "CW-040", "theme": "Identifiers", "title": "Family codes of the W1 domains: 02 takes HH, 15 keeps AC, 01 adds PR- families",
     "domains": ["01", "02", "15"],
     "issue": "Replaced domains take new L1 codes at their stage (plan section 5.1: 02 HH). The register retired the prefix HH- (CD-137) because households are keyed PTY-HH-. 01 uses legacy three-letter family codes (STR, PRD, SHC) that equal its ID prefixes.",
     "resolution": "02 family codes are HH-xxx (attribute IDs HH-FAM-nnn); HH- stays a retired example prefix and households stay PTY-HH-; drafters never use HH- in examples. 15 keeps AC-xxx. 01 keeps its legacy family codes (renaming them would change every 01 attribute ID and break the baseline) and gives new families the PR- stem (PR-ASO, PR-PLT, PR-ALT). domains.py takes the new name and code of 02 and the new name of 01 when the W1 modules merge.",
     "rationale": "Stable attribute IDs for kept content; the new code for the replaced domain.",
     "action": "W1 (modules), W1 merge (domains.py)", "status": P, "priority": "Low", "owner_role": PL},
]

# ---------------------------------------------------------------------------------------------------------------------
# Reserved prefixes (decisions.py tuple format: prefix, entity, owner Data Domain, status, note).
# Each was checked against decisions.PREFIXES (both siblings, every status), the anchor prefixes of plan section 5.2
# (PLN FGL RCO ADE MAS RBL TLH TPB FSC FBR FDB FWV COR CEX CCF CRT CHL CLT RSV CAA CAX MMT SWP PBK MMH TRS TDD EST MGR MDD
# SAA PDD), prefix-like tokens in every content module, and each other. A candidate was rejected if it is equal to, an
# anagram of, or one edit (substitution, insertion, deletion) away from any of them.
# Rejected near-misses:
#   02: IVP- (ICP- 07), IPF- (CPF- 11), INVP- (anagram PINV- 16), IPRO- (IPRU- token 19/43); IDV- (IDX- 22, IDR- 11,
#       anagram VDI- 14), IDVR- (IDR-), CIPV- (CIP- 29), IDVF- (anagram FDIV- 27); BOC- (SOC- 04, DOC- 05, BOD- 13),
#       UBO- (free but an EU term of art); POA- (PYA- 05, POS- 06), AUTG- (AUTH- 38), AUG- (AUM- token);
#       TCD- (CD- 21, TCA- 25, TMD- 07, TRD- 11, TDD- plan 51), TCON- (anagram CONT- 16), TRCN- (RCN- 06, TRN- 12),
#       TCDN- (anagram NDTC- 16).
#   15: FEAT- (FBAT- 29), AFT- (ACT- 03, AST- 04), AFTR- (ATR- 06), FAPV- (APV- 19), OPA- (VPA- 20, OPP- 03, SPA- 08);
#       AAGR- (TAGR- 26, AGR- 05), ACAG- (ACSG- 41), AGM- (AGR-, PGM-, ALM-, ACM-); ENR- (anagram ERN- 07; ECR-, ERR-,
#       ENT-), PENR- (PEER- 11), APE- (APV-, ALE-, ADE- plan 45), PRG- (PRD-, PRX-, PRP-); AIS- (AIU-, ANS-, VIS-),
#       SUBS- and PSUB- (SUB- 04); ARMD-, IRMD-, RMDS- (RMD- 13, PRMD- 16) - the RMD Record takes no prefix.
#   01: SOF- (SOC- 04, SHF- 05), OFR- (OVR- 06, PFR- 10), ADVP- (ADVA- 35), APGM- (PGM- 05), ADP- (DP- 21);
#       TPOL- (VPOL- 34, TPL- 12), PLTP- and PLOP- (PLDP- 16), TRDU- (TRD- 11), BPOL- (VPOL-); SUBW- (SUB- 04),
#       AIW- (AIU- 21), ALTF- (ALLF- token 29); TIER- (TER- 07), STIR- (STR- 01), SVTR- (anagram TRSV- 38),
#       SVTI- (SVT- 12) - Service Tier takes no prefix (tier code is its key).
#   Noted, not rejected: AAG- is two edits from AGR- (05); ELIG- is two edits from ELE- (20); TUP- is two edits from
#   TPB- (plan 46).
# Also flagged for the 47 brief (CW-036): the plan anchor FSC- is one deletion from FSCH- (01) and is not registered here.
# ---------------------------------------------------------------------------------------------------------------------
R = "Reserved"

PREFIXES = [
    ("INPR-", "Investor profile version (client x version)", "02", R, "W1 brief 02 (CW-024). Rejected IVP-, IPF-, INVP-, IPRO-."),
    ("KYCV-", "Identity verification (party x CIP program x verification)", "02", R, "W1 brief 02 (CW-025). Rejected IDV-, IDVR-, CIPV-, IDVF-. 29 CIP- to be retired at W3."),
    ("BOWN-", "Beneficial ownership certification (legal-entity customer x certification)", "02", R, "W1 brief 02 (CW-025). Rejected BOC-, UBO-."),
    ("AGNT-", "Authority grant (power of attorney, trading authorization, guardian, executor, entity signer)", "02", R, "W1 brief 02 (CW-026). Rejected POA-, AUTG-, AUG-."),
    ("TCNT-", "Trusted contact designation (FINRA Rule 4512)", "02", R, "W1 brief 02 (CW-026). Rejected TCD-, TCON-, TRCN-, TCDN-."),
    ("AFEA-", "Account feature (account x feature type x period)", "15", R, "W1 brief 15 (CW-031). Rejected FEAT-, AFT-, AFTR-, FAPV-, OPA-."),
    ("AAG-", "Account agreement (account x agreement type x version)", "15", R, "W1 brief 15 (CW-031). Rejected AAGR-, ACAG-, AGM-; two edits from AGR- (05)."),
    ("ENRL-", "Program enrollment (account x service offering x period)", "15", R, "W1 brief 15 (CW-032). Rejected ENR-, PENR-, APE-, PRG-."),
    ("AISB-", "Alternative investment subscription (account x feeder product x offering window)", "15", R, "W1 brief 15 (CW-035, CW-038). Rejected AIS-, SUBS-, PSUB-."),
    ("OFFR-", "Service offering (advice program, brokerage, trust, planning, workplace managed account, OCIO)", "01", R, "W1 brief 01 (CW-036). Rejected SOF-, OFR-, ADVP-, APGM-, ADP-."),
    ("ELIG-", "Offering eligibility rule", "01", R, "W1 brief 01 (CW-036). Two edits from ELE- (20)."),
    ("TUP-", "Tradable-universe and trading-feature policy rule", "01", R, "W1 brief 01 (CW-037). Rejected TPOL-, PLTP-, PLOP-, TRDU-, BPOL-; two edits from TPB- (plan 46)."),
    ("OFWN-", "Offering window of a feeder fund", "01", R, "W1 brief 01 (CW-038). Rejected SUBW-, AIW-, ALTF-."),
]

# Prefixes kept by the replaced and adapted W1 domains (already in decisions.PREFIXES; listed for the merge check):
KEPT_PREFIXES = {
    "02": ["PTY-", "CTP-", "CNS-", "ONB-", "CRX-"],
    "15": ["ACC-", "ACI-", "ABD-", "ATC-", "SIN-", "ABI-", "ALE-", "ARX-"],
    "01": ["STR-", "PRD-", "SHC-", "MND-", "MDL-", "BMK-", "CMP-", "RST-", "CMT-", "FSCH-"],
}

# Pre-allocated decision ids for the US-only pass (CW-022), by Data Domain; drafted in proposals_NN.py.
JURISDICTION_DECISION_IDS = {nn: f"CW-9{nn}" for nn in
                             ["01", "02", "09", "15", "17", "14", "18", "19", "20", "21", "22", "23", "25", "26", "27",
                              "28", "31", "33", "34", "35", "37", "39", "40", "41", "42", "43", "44"]}

NOTES = [
    "jurisdiction.py says the drafters append to REMOVALS directly; the W1 and W1b instructions have them write JURISDICTION in proposals_NN.py instead (parallel agents), and the program lead appends at merge. The tooling owner may align the docstring.",
    "jurisdiction.REGIMES has no GDPR, BMR, CRS or UK Stewardship Code entry; drafters use 'Other EU/UK' and name the regime in the note unless the list is extended.",
    "domains.py must carry the new names of 01 (Investment Product & Service Offering) and 02 (Client & Household, L1 code HH) when the W1 modules merge, and the renames of 25 and 28 for W1b (plan section 5.1).",
    "The keys of the replaced domains in keys_g1_01_02.py (02) and keys_g6_15_16.py (15) are superseded at WP2 by keys_w_*.py (keys_common.md).",
    "The plan anchor prefixes of 45 to 52 were used only for collision checks; their meanings (for example CAX- as the ACATS account transfer of 49) are inferred from plan section 5.2 and must be confirmed by the W2 and W3 briefs.",
]
