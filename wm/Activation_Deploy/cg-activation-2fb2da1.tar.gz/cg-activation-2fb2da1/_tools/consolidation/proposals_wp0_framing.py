"""WP0 framing proposals of the wealth-manager rework (Wealth_Manager_Rework_Plan.md sections 4 item 7, 8.1 to 8.5 and 10;
00_Program/Rework/Product_Briefs/WP0_Framing.md). Program lead's framing agent, 2026-10-15. MODEL = "wealth".

CANDIDATES: the new foundational products of plan section 8.2 (DP-300 to DP-307, wave WP1F) and the cross-area and
foundational products re-scoped in place (disposition "re-scope"; the id is kept because live products depend on it).
Checked with `python data_products/candidate_coverage.py proposals_wp0_framing` from _tools.
DISPOSITIONS: (id, disposition, successor, decision, reason) for every product this agent rules (keep / re-scope / retire /
succeed); the area briefs rule the pending products of their own domains (CW-210 to CW-269).
DECISIONS: CW-200 to CW-209, status "Proposed".
"""

MODEL = "wealth"

# Upstream candidates of other briefs. Written as names in the draft; replaced by their ids at the WP0 integration
# (2026-10-15; WP0_Integration_Notes.md).
SWEEP_MASTER = "DP-431"
VENUE_MASTER = "DP-432"
CMA_MODELS = "DP-530"
MANAGED_SLICE = "DP-345"

CANDIDATES = [
    # ---- New foundational products (plan section 8.2; CW-205) ---------------------------------------------------------
    dict(id="DP-300", name="Client Holdings, Lots & Cost Basis", tier="Foundational", type="Conformed Facts", domain="49",
         owner_role="Head of Brokerage Operations", primary="FN-65",
         supporting=["FN-63", "FN-60", "FN-72", "FN-77", "FN-67", "FN-69", "FN-31", "FN-39"], wave="WP1F",
         definition="The brokerage book of record at account grain: every client holding of any security with its valuation, "
                    "tax lots, lot reliefs and cost-basis adjustments and transfer statements, cash and sweep balances, margin "
                    "balances and every pending and settled account activity, as 49 masters them (CW-007: Client Holding, never "
                    "a Portfolio Holding of 18 or a Fund Shareholder Position of 06). It conforms the book once so that client "
                    "assets, advice, managed accounts, billing, statements, trust accounting and personal returns read the same "
                    "positions.",
         objects=[("49", "Client Holding"), ("49", "Client Holding Valuation"), ("49", "Client Tax Lot"),
                  ("49", "Client Lot Relief"), ("49", "Cost Basis Adjustment"), ("49", "Cost Basis Transfer Statement"),
                  ("49", "Client Account Activity"), ("49", "Account Cash Balance"), ("49", "Margin Balance Snapshot"),
                  ("15", "Account"), ("15", "Cost Basis Election"), ("17", "Instrument")],
         upstream=["DP-093", "DP-301", "DP-097", "DP-143", "DP-013"],
         notes="Concept row: 'Client Holding', 49, CHL- (CW-007). Book: Client Holding (49). 49 postings reference 48 allocations "
               "(links held once by the later record), so DP-301 is upstream. Margin calls, reserve, possession or control, "
               "transfers, lending and corporate action entitlements stay with the BWO consumer products (DP-445 to DP-452). "
               "Outsourcing lever: with an outside clearing firm the product becomes the received book and its reconciliation."),
    dict(id="DP-301", name="Client Orders & Executions", tier="Foundational", type="Conformed Facts", domain="48",
         owner_role="Head of Brokerage Trading", primary="FN-64",
         supporting=["FN-65", "FN-63", "FN-68", "FN-72", "FN-67", "FN-44"], wave="WP1F",
         definition="Every client order in every product the platform offers, with its instruction detail, option legs, "
                    "lifecycle events and routes, the block orders that aggregate them, and the executions, allocations to "
                    "accounts, Rule 10b-10 confirmations and trade corrections that follow. It conforms the order book once so "
                    "that execution quality, CAT completeness, managed-account trading, commissions and surveillance read the "
                    "same orders.",
         objects=[("48", "Client Order"), ("48", "Order Instruction Detail"), ("48", "Option Order Leg"),
                  ("48", "Client Order Event"), ("48", "Order Route"), ("48", "Client Block Order"),
                  ("48", "Client Execution"), ("48", "Client Allocation"), ("48", "Client Trade Confirmation"),
                  ("48", "Trade Correction")],
         upstream=["DP-093", "DP-097", "DP-013", VENUE_MASTER],
         notes="Concept row: 'Client Order', 48, COR- (term conflict 'Order' with 25 Trade Order). Venue and routing-rule "
               "masters are the BWO foundational DP-432 (ruled: this product does not carry them). Fund desk orders stay in 25."),
    dict(id="DP-302", name="Money Movement Transactions", tier="Foundational", type="Conformed Facts", domain="50",
         owner_role="Head of Money Movement", primary="FN-66",
         supporting=["FN-65", "FN-62", "FN-68", "FN-44", "FN-77", "FN-71", "FN-69"], wave="WP1F",
         definition="Every movement of cash into, out of and between client accounts (ACH, wire, check and internal transfer) "
                    "with its events, returns and exceptions, as 50 masters them. It conforms money movement once so that net "
                    "new assets, funding journeys, fraud holds, AML monitoring and distributions read the same transactions.",
         objects=[("50", "Money Movement"), ("50", "Money Movement Event"), ("50", "ACH Entry Detail"),
                  ("50", "Wire Transfer Detail"), ("50", "Check Detail"), ("50", "Internal Transfer Detail"),
                  ("50", "Money Movement Return"), ("50", "Money Movement Exception"), ("15", "Bank Instruction"),
                  ("15", "Account Standing Instruction")],
         upstream=["DP-093", "DP-013", SWEEP_MASTER],
         notes="Concept row: 'Money Movement', 50, MMT-. Holds, fraud and elder-exploitation flags are special-category and are "
               "published only by the restricted BWO consumer DP-456. Sweep programs and program banks are the BWO foundational "
               "DP-431 (ruled: not carried here). Debit card transactions stay with DP-459."),
    dict(id="DP-303", name="Advice Plans & Recommendations", tier="Foundational", type="Master & Reference", domain="45",
         owner_role="Head of Advice", primary="FN-60",
         supporting=["FN-61", "FN-68", "FN-71", "FN-63", "FN-73", "FN-62"], wave="WP1F",
         definition="The advice record of each client and household: advice engagements and participants, goals, financial "
                    "plans and their versions, and every recommendation with its rationale, the alternatives considered, the "
                    "best-interest evidence, the link to its implementation and, for rollovers, the analysis and PTE 2020-02 "
                    "documentation. It conforms the advice record once so that the Reg BI file, supervision, the advice funnel "
                    "and goal progress assemble the same evidence and never re-score it.",
         objects=[("45", "Advice Engagement"), ("45", "Engagement Participant"), ("45", "Advice Review"),
                  ("45", "Financial Goal"), ("45", "Client Financial Plan"), ("45", "Client Financial Plan Version"),
                  ("45", "Recommendation"), ("45", "Recommendation Rationale"), ("45", "Recommendation Alternative"),
                  ("45", "Best Interest Evidence"), ("45", "Recommendation Implementation Link"),
                  ("45", "Rollover Analysis"), ("45", "PTE 2020-02 Documentation")],
         upstream=["DP-240", "DP-093", "DP-004", "DP-009", "DP-013"],
         notes="Concept rows: 'Recommendation', 45, RCO-; 'Financial Plan', 45, PLN-. Delivery channel (digital or human) is an "
               "attribute (plan section 15 ruling 4). Supervision of the evidence is 08's (CLA-B)."),
    dict(id="DP-304", name="Managed Account Model Assignments", tier="Foundational", type="Master & Reference", domain="46",
         owner_role="Head of Managed Account Operations", primary="FN-63",
         supporting=["FN-60", "FN-61", "FN-72", "FN-31", "FN-33", "FN-71", "FN-69"], wave="WP1F",
         definition="The model assigned to every managed account and household group, with sleeves, account-level targets and "
                    "overrides, investment constraints, tax management settings and the membership of each managed account "
                    "program composite, effective-dated. It conforms the assignment once so that drift, rebalancing, harvesting, "
                    "billing, program performance and the managed-account slice of Firm AUM read the same accounts and models.",
         objects=[("46", "Model Assignment"), ("46", "Sleeve Assignment"), ("46", "Household Managed Group"),
                  ("46", "Managed Account Target"), ("46", "Account Target Override Line"),
                  ("46", "Account Investment Constraint"), ("46", "Tax Management Setting"),
                  ("46", "Managed Account Composite"), ("46", "Managed Account Composite Membership"),
                  ("15", "Program Enrollment")],
         upstream=["DP-093", "DP-004", "DP-240", "DP-013", CMA_MODELS],
         notes="Concept row: 'Model Assignment', 46, MAS-. The model (01 MDL-) and its weights come from DP-004 and the INV+IOP "
               "foundational DP-530; drift, harvesting and trade proposals are CLA-A consumers (DP-341 to DP-345)."),
    dict(id="DP-305", name="Fee Schedules & Billing Runs", tier="Foundational", type="Conformed Facts", domain="47",
         owner_role="Head of Pricing & Billing", primary="FN-72",
         supporting=["FN-12", "FN-63", "FN-75", "FN-69", "FN-68", "FN-38"], wave="WP1F",
         definition="The fee schedules, tiers and their assignment to accounts and fee households, and every fee calculation "
                    "run with its account calculations, debits and invoices, as 47 masters them. It conforms billing once so "
                    "that billing accuracy, custody-rule evidence, client fee revenue and pricing realization read the same "
                    "schedules and runs.",
         objects=[("47", "Fee Schedule"), ("47", "Fee Schedule Tier"), ("47", "Fee Schedule Assignment"),
                  ("47", "Fee Rate Override"), ("47", "Fee Household"), ("47", "Fee Household Membership"),
                  ("47", "Fee Calculation Run"), ("47", "Account Fee Calculation"), ("47", "Fee Debit"),
                  ("47", "Fee Invoice"), ("47", "Billing Arrangement"), ("01", "Offering Fee Schedule Link")],
         upstream=["DP-093", "DP-240", "DP-004", "DP-300", "DP-013"],
         notes="Concept row: 'Fee Schedule', 47, FSC-. Billable assets come from DP-300 (Client Holding). Waivers, adjustments, "
               "disputes and performance fees are CLA-A consumers (DP-347, DP-350); revenue recognition is DP-012's."),
    dict(id="DP-306", name="Manager & Sub-Adviser Master", tier="Foundational", type="Master & Reference", domain="52",
         owner_role="Head of Manager Research", primary="FN-70",
         supporting=["FN-21", "FN-36", "FN-32", "FN-31", "FN-60", "FN-75", "FN-78"], wave="WP1F",
         definition="Every external manager the firm hires or researches, with its key persons and strategies, the sub-advisory "
                    "engagements and mandate guideline sets given to sub-advisers, manager-of-managers hire conditions, watch "
                    "status and terminations, and the approved-list status of third-party products. It conforms the manager "
                    "once so that oversight, Section 15(c) evidence, OCIO line-ups and advice models name the same manager.",
         objects=[("52", "External Manager Profile"), ("52", "Manager Key Person"), ("52", "External Manager Strategy"),
                  ("52", "Sub-Adviser Engagement"), ("52", "Manager-of-Managers Hire Condition"),
                  ("52", "Sub-Adviser Guideline Set"), ("52", "Sub-Adviser Watch Status"), ("52", "Product List Status"),
                  ("52", "Manager Termination"), ("02", "Party")],
         upstream=["DP-240", "DP-004", "DP-213", "DP-097", "DP-013"],
         notes="Concept row: 'External Manager', 52, MGR-. Product List Status included (lead ruling 2026-10-15). Due diligence, "
               "oversight reviews and 15(c) renewal evidence are INV+IOP consumers (DP-535 to DP-540)."),
    dict(id="DP-307", name="Trust Fiduciary Record", tier="Foundational", type="Master & Reference", domain="51",
         owner_role="Head of Trust Services", primary="FN-69",
         supporting=["FN-62", "FN-63", "FN-39", "FN-72"], wave="WP1F",
         definition="Each trust the trust company administers: the trust and its instrument terms, trustee, co-trustee, grantor "
                    "and beneficiary roles and the beneficial interests, linked to the accounts that hold its assets. It "
                    "conforms the fiduciary record once so that distributions, principal and income accounting, account reviews "
                    "and fiduciary tax read the same trust.",
         objects=[("51", "Trust"), ("51", "Trust Term Provision"), ("51", "Trust Role"), ("51", "Beneficial Interest"),
                  ("51", "Trust Instrument Document")],
         upstream=["DP-240", "DP-093", "DP-013"],
         notes="Optional (51 is an optional domain, CW-018 OPTIONAL_DOMAINS): dropped with the trust line. Concept row: 'Trust', "
               "51, TRS-."),

    # ---- Foundational products re-scoped in place (CW-202 to CW-204) ----------------------------------------------------
    dict(id="DP-001", disposition="re-scope", name="Intermediary Partner Master", tier="Foundational",
         type="Master & Reference", domain="05", owner_role="Head of Intermediary Distribution", primary="FN-74",
         supporting=["FN-75", "FN-73", "FN-12", "FN-77", "FN-68"], wave="WP1F",
         definition="The intermediary channel's partners and the people in them: distributor firms with their hierarchy nodes, "
                    "branches and offices, advisor teams and memberships, Form ADV and gatekeeper profiles, and the external "
                    "financial professionals with their practices, affiliations, classifications and partner coverage, on the "
                    "party identity of DP-240. It conforms the thin intermediary set once (CW-132 restored it in 05) so that "
                    "flows, placement, payments and coverage name the same partner and advisor.",
         objects=[("05", "Distributor Firm"), ("05", "Form ADV Profile"), ("05", "Hierarchy Node"), ("05", "Branch / Office"),
                  ("05", "Advisor Team"), ("05", "Team Membership"), ("05", "Gatekeeper Profile"),
                  ("05", "Financial Professional"), ("05", "Advisor Practice"), ("05", "Employment Affiliation"),
                  ("05", "External Classification"), ("05", "Partner Coverage Assignment"),
                  ("02", "Party"), ("02", "Party Identifier"), ("02", "US Regulatory Identifier")],
         upstream=["DP-240", "DP-013"],
         notes="Re-scoped in place: DP-006, DP-007, DP-008, DP-012, DP-014, DP-093, DP-094 and others list DP-001. Absorbs DP-002 "
               "Financial Professional Profile, which retires (CW-202); its dependents (DP-003, DP-011, DP-093) re-point to "
               "DP-001 at WP1. Owning domain moves 02 -> 05. This is the 'Intermediary Partner Master' the DIS+FDN brief names."),
    dict(id="DP-003", disposition="re-scope", name="Institutional, Consultant & Plan Relationships", tier="Foundational",
         type="Master & Reference", domain="12", owner_role="Head of Institutional Client Service", primary="FN-75",
         supporting=["FN-71", "FN-19", "FN-74", "FN-72"], wave="WP1F",
         definition="The golden record of institutional advisory and OCIO clients with their investment policy statements, the "
                    "investment consultants and their advisory relationships, and the plan sponsors, recordkeepers and service "
                    "providers of the plans, on the restored 12, 05 and 16 objects (CW-132, CW-133). It conforms these "
                    "relationships once so that institutional servicing, pipeline, plan sponsor servicing and the total client "
                    "relationship name the same institution.",
         objects=[("12", "Institutional Client"), ("12", "Investment Policy Statement"), ("05", "Consultant Profile"),
                  ("05", "Consultant Advisory Relationship"), ("16", "Plan Sponsor Profile"), ("16", "Recordkeeper Profile"),
                  ("16", "Retirement Plan Profile"), ("16", "Plan Service Provider"), ("02", "Party"),
                  ("02", "Organization"), ("02", "Retirement Plan"), ("02", "Party Relationship"),
                  ("15", "Institutional Account"), ("01", "Investment Mandate")],
         upstream=["DP-240", "DP-001", "DP-093", "DP-004", "DP-013"],
         notes="Re-scoped in place (DP-094 and DP-243 list it). Owning domain moves 02 -> 12. SM-00's distributor dimensions stop "
               "role-playing Party at WP2."),
    dict(id="DP-004", disposition="re-scope", name="Product, Offering & Share Class Reference", tier="Foundational",
         type="Master & Reference", domain="01", owner_role="Head of Product Data", primary="FN-78",
         supporting=["FN-37", "FN-60", "FN-61", "FN-63", "FN-64", "FN-72", "FN-74", "FN-68"], wave="WP1F",
         definition="Every strategy, fund, ETF, CIT, share class and model portfolio with its identifiers, structure, "
                    "classifications, fees, eligibility, lifecycle and relationships, extended with the advice and service "
                    "offerings, service tiers and eligibility rules, the brokerage platform's tradable universe and product "
                    "availability, and the firm's own risk rating of each share class. It conforms what the firm offers once, so "
                    "that advice, managed accounts, billing, the platform and the fund products name the same offering.",
         objects=[("01", "Investment Strategy"), ("01", "Strategy Classification"), ("01", "Investment Product"),
                  ("01", "Fund Legal Structure"), ("01", "Model Portfolio"), ("01", "Share Class"),
                  ("01", "Investor Eligibility"), ("01", "Security Identifier"), ("01", "System Cross-Reference"),
                  ("01", "Firm Product Classification"), ("01", "Performance Fee"),
                  ("01", "Product Relationship"), ("01", "Lifecycle Event"), ("01", "Portfolio Manager Assignment"),
                  ("01", "Product Risk Indicator"), ("01", "Service Offering"), ("01", "Offering Feature"),
                  ("01", "Offering Eligibility Rule"), ("01", "Service Tier"), ("01", "Tradable Universe Policy Rule"),
                  ("01", "Platform Product Availability"), ("01", "Platform Feature"), ("01", "Feeder Access Terms"),
                  ("01", "Offering Window"), ("01", "Offering Fee Schedule Link")],
         upstream=["DP-013", "DP-097"],
         notes="Kept and extended (plan 8.2 'DP-004 stays'); closes the W1 gap 'no foundational model publishes 01 Service "
               "Offering'. Takes 01 Product Risk Indicator from the retired DP-156 and the feeder terms of the retired DP-116. "
               "Absorbs the offering scope drafted by CLA-B as DP-380 (lead ruling 2026-10-15, CW-221; DP-380 is not "
               "registered): Service Offering, features, eligibility, service tiers, platform availability, Model Portfolio and "
               "the Offering Fee Schedule Link to the 47 schedule (verified at the WP0 integration). 01 Currency Hedging stays "
               "with DP-079 (re-scoped in place)."),
    dict(id="DP-005", disposition="re-scope", name="Intermediary Agreements & Platform Placement", tier="Foundational",
         type="Master & Reference", domain="05", owner_role="Head of Intermediary Distribution", primary="FN-74",
         supporting=["FN-12", "FN-68", "FN-78", "FN-22"], wave="WP1F",
         definition="The selling and platform agreements with each intermediary partner, their terms, amendments, product and "
                    "distribution scope and payment arrangements, joined to shelf placement, share class mapping, partner "
                    "programs and model program placement, partner research ratings and dealer and networking set-up. It shrinks "
                    "the wholesale register to the thin intermediary channel (CW-013).",
         objects=[("05", "Distribution Agreement"), ("05", "Agreement Party Role"), ("05", "Agreement Term"),
                  ("05", "Agreement Amendment"), ("05", "Agreement Product Coverage"),
                  ("05", "Agreement Distribution Scope"), ("05", "Agreement Account Link"), ("05", "Payment Arrangement"),
                  ("05", "Shelf Placement"), ("05", "Share Class Mapping"), ("05", "Partner Research Rating"),
                  ("05", "Model Program Placement"), ("05", "Partner Program"), ("05", "Program Membership"),
                  ("05", "Partner Dealer Setup"), ("05", "Networking Setup")],
         upstream=["DP-001", "DP-004", "DP-013"],
         notes="Re-scoped in place (DP-006, DP-012, DP-108 list it)."),
    dict(id="DP-006", disposition="re-scope", name="Client Flow Transactions", tier="Foundational", type="Conformed Facts",
         domain="06", owner_role="Head of Client & Channel Analytics", primary="FN-77",
         supporting=["FN-12", "FN-74", "FN-73", "FN-76", "FN-71"], wave="WP1F",
         definition="Every client asset movement across every channel, copied into the 06 flow book with declared sources: "
                    "brokerage activity from 49, money movement from 50, fund register transactions from 29, plan activity from "
                    "16 and intermediary feeds, de-duplicated, corrected for cancels and assigned to the account's channel at the "
                    "transaction date (Account Channel Assignment). It is the transaction input of the certified net new assets "
                    "and keeps unattributed amounts in suspense.",
         objects=[("06", "Transaction"), ("06", "Transaction Dates"), ("06", "Transaction Amounts"), ("06", "Order Source"),
                  ("06", "Intermediary As Delivered"), ("06", "Linked Transaction"), ("06", "Transaction Status"),
                  ("06", "Account Channel Assignment"), ("06", "Attribution Record"), ("06", "Market & Client Dimensions"),
                  ("06", "Unattributed Item"), ("06", "Identifier Crosswalk"), ("06", "Data Feed"), ("06", "Reporting Period")],
         upstream=["DP-300", "DP-302", "DP-093", "DP-094", "DP-001", "DP-004", "DP-009", "DP-013"],
         notes="Re-scoped in place (DP-008 and others list it). 06 masters nothing (CW-141): every row names its source book."),
    dict(id="DP-007", disposition="re-scope", name="Client Asset Positions", tier="Foundational", type="Conformed Facts",
         domain="06", owner_role="Head of Client & Channel Analytics", primary="FN-77",
         supporting=["FN-12", "FN-74", "FN-75", "FN-33", "FN-71"], wave="WP1F",
         definition="Daily client asset summaries at account grain across every channel, copied with their source book: "
                    "Client Holding summaries from 49, participant balances from 16, the fund share register view from 29 and "
                    "intermediary look-through and sponsor-reported assets, by holding type and own-product indicator, assigned "
                    "to the account's channel and reconciled source to source. It is the position input of the certified client "
                    "assets; it is never a book of record (CW-007, CW-141).",
         objects=[("06", "Account Asset Summary"), ("06", "Fund Shareholder Position"), ("06", "Omnibus Look-Through"),
                  ("06", "Plan Position"), ("06", "Sponsor-Reported Assets"), ("06", "Account Channel Assignment"),
                  ("06", "Reconciliation"), ("06", "Reconciliation Run"), ("06", "Break"), ("06", "Load"),
                  ("15", "Account"), ("15", "Program Enrollment")],
         upstream=["DP-300", "DP-093", "DP-094", "DP-001", "DP-004", "DP-013"],
         notes="Re-scoped in place (DP-008, DP-241 list it). Book: Fund Shareholder Position (06) is a view of 49 for direct "
               "accounts and of intermediary data for the rest (CW-007)."),
    dict(id="DP-008", disposition="re-scope", name="Client Assets & Net New Assets", tier="Foundational",
         type="Conformed Facts", domain="06", owner_role="Head of Client & Channel Analytics", primary="FN-77",
         supporting=["FN-79", "FN-12", "FN-73", "FN-74", "FN-75", "FN-76", "FN-78", "FN-16"], wave="WP1F",
         definition="The firm's certified client assets, net new assets and advised assets by period, channel, business line, "
                    "offering, holding type and advisor, with client market movement, inter-channel transfers, client organic "
                    "growth, the own-fund overlap (reported, never netted here) and the counts of funded accounts, clients and "
                    "households. It applies the 06 measure definitions and flow treatment rules once, locks period-end "
                    "snapshots and records every restatement (CW-011, CW-142).",
         objects=[("06", "Measure Definition"), ("06", "Flow Treatment Rule"), ("06", "Measure Value"),
                  ("06", "Client Asset Measures"), ("06", "Flow Measures"), ("06", "Asset Measures"),
                  ("06", "Account Channel Assignment"), ("06", "Market & Client Dimensions"), ("06", "Reporting Period"),
                  ("06", "Snapshot"), ("06", "Restatement"), ("09", "Reporting Period Definition")],
         upstream=["DP-006", "DP-007", "DP-093", "DP-240", "DP-009", "DP-004", "DP-013"],
         notes="Re-scoped in place under CW-142 (every certified-number reader keys on DP-008): no DP-30x successor. The only "
               "source of Client Assets, Net New Assets and Advised Assets (lead ruling 2026-10-15). Gross sales, redemptions "
               "and net flows remain as the own-fund flow family by channel; the wholesale 'AUM' measures retire (CW-203)."),
    dict(id="DP-012", disposition="re-scope", name="Client Fee Revenue", tier="Foundational", type="Conformed Facts",
         domain="10", owner_role="Head of Client Revenue Finance", primary="FN-12",
         supporting=["FN-79", "FN-72", "FN-78", "FN-38", "FN-74", "FN-33"], wave="WP1F",
         definition="The firm's conformed client revenue by offering, channel, client segment and accounting period: advisory and "
                    "account fees billed (47), brokerage commissions, cash program revenue, fund management fee revenue after "
                    "waivers and the intermediary channel's distribution revenue, with revenue recognition applied once and "
                    "reconciled to the general ledger. It is the only source of the certified client fee revenue (CW-011).",
         objects=[("10", "Client Revenue Record"), ("10", "Fee Revenue Record"), ("10", "Revenue Contract"),
                  ("10", "Performance Obligation"), ("10", "Performance Fee Record"), ("10", "Distribution Revenue Record"),
                  ("10", "Cash Program Economics"), ("10", "Waiver Record"), ("10", "Account Mapping"), ("10", "Control"),
                  ("47", "Fee Debit"), ("47", "Fee Invoice"), ("19", "Journal Entry"), ("19", "GL Posting"),
                  ("19", "Accounting Period Status"), ("19", "Financial Statement Line Mapping"), ("09", "Fiscal Period")],
         upstream=["DP-305", "DP-004", "DP-093", "DP-005", "DP-190", "DP-191", "DP-013"],
         notes="Re-scoped in place (DP-242, DP-245, DP-243 list it). Revenue yield, profitability and cost to serve are DIS+FDN "
               "consumers (DP-497 to DP-499); the ledger tie-out view is FOP+CORP DP-598."),
    dict(id="DP-093", disposition="re-scope", name="Account Master", tier="Foundational", type="Master & Reference",
         domain="15", owner_role="Head of Account Data", primary="FN-62",
         supporting=["FN-60", "FN-63", "FN-64", "FN-65", "FN-66", "FN-67", "FN-72", "FN-71", "FN-19", "FN-15"], wave="WP1F",
         definition="The conformed brokerage and advisory account record: every account by registration type (individual, joint, "
                    "IRA and Roth IRA, SEP and SIMPLE, 529, UTMA/UGMA, trust, estate, entity, participant, HSA, fund-only) with "
                    "identifiers, hierarchy, party roles, beneficiaries and TOD designations, features (margin, options, cash "
                    "sweep, DRIP, checkwriting), agreements and disclosures, advisory program enrollment, RMD status, cost-basis "
                    "and tax certification, standing and bank instructions, restrictions and lifecycle. It conforms the account "
                    "once for every line (plan section 4 item 2).",
         objects=[("15", "Account"), ("15", "Account Identifier"), ("15", "Account Hierarchy Link"),
                  ("15", "Account Party Role"), ("15", "Account Registration Detail"), ("15", "Account Investment Profile"),
                  ("15", "Custodial Account Detail"), ("15", "Retirement Account Detail"),
                  ("15", "Education & Health Savings Account Detail"), ("15", "Beneficiary Designation"),
                  ("15", "Account Feature"), ("15", "Options Approval Detail"), ("15", "Margin Account Detail"),
                  ("15", "Cash Sweep Election"), ("15", "Account Agreement"), ("15", "Program Enrollment"),
                  ("15", "Alternative Investment Subscription"), ("15", "Account Tax Certification"),
                  ("15", "Account Tax Reporting Status"), ("15", "Cost Basis Election"), ("15", "RMD Record"),
                  ("15", "Account Standing Instruction"), ("15", "Bank Instruction"), ("15", "Account Opening"),
                  ("15", "Account Lifecycle Event"), ("15", "Account Status History"), ("15", "Account Closure"),
                  ("15", "Account Restriction"), ("15", "Plan Participant Account"), ("15", "Institutional Account"),
                  ("15", "Intermediary Account Servicing"), ("02", "Party"), ("01", "Service Offering")],
         upstream=["DP-240", "DP-001", "DP-004", "DP-013"],
         notes="Re-scoped in place. Primary FN-15 -> FN-62. Takes 15 Alternative Investment Subscription from the retired DP-116 "
               "and DP-136. Agreement disclosures, RMD trackers and opening pipelines are CLA-A consumers (DP-327 to DP-332)."),
    dict(id="DP-240", disposition="re-scope", name="Client, Household & Party Master", tier="Foundational",
         type="Master & Reference", domain="02", owner_role="Head of Client Data", primary="FN-62",
         supporting=["FN-49", "FN-60", "FN-61", "FN-67", "FN-68", "FN-73", "FN-77", "FN-23", "FN-44", "FN-46"], wave="WP1F",
         definition="The one conformed record of every client and household and of every other party the firm deals with: the "
                    "02 Party identity, individual or organization profile, households and memberships, authority grants, "
                    "trusted contacts and death notifications, the investor profile and investment experience, identifiers, "
                    "beneficial ownership, tax profile, contact points, segment and service tier, roles and relationships. The "
                    "client household is the primary role family; counterparties, vendors and intermediaries are thinner roles "
                    "on the same party (plan section 4 item 1).",
         objects=[("02", "Party"), ("02", "Individual"), ("02", "Organization"), ("02", "Legal Entity Hierarchy"),
                  ("02", "Party Role"), ("02", "Party Identifier"), ("02", "LEI Record"), ("02", "US Regulatory Identifier"),
                  ("02", "Household"), ("02", "Household Membership"), ("02", "Party Relationship"),
                  ("02", "Authority Grant"), ("02", "Trusted Contact Designation"), ("02", "Death Notification"),
                  ("02", "Investor Profile"), ("02", "Investment Experience"), ("02", "Beneficial Ownership Certification"),
                  ("02", "Beneficial Ownership"), ("02", "Tax Profile"), ("02", "Contact Point"), ("02", "Postal Address"),
                  ("02", "Segment Assignment"), ("02", "Service Tier Assignment"), ("09", "Internal Legal Entity")],
         upstream=["DP-013"],
         notes="Re-scoped in place (DP-001, DP-115, DP-210, DP-213 and others list it). Primary FN-49 -> FN-62; owner Head of "
               "Enterprise Data Management -> Head of Client Data. Specified adult status, vulnerability concerns and "
               "restricted-client status are published only by the restricted CLA-A consumer DP-322 (CD-344)."),

    # ---- Cross-area consumer products re-scoped in place (CW-206) --------------------------------------------------------
    dict(id="DP-241", disposition="re-scope", name="Firm AUM & Client Assets Reconciliation", tier="Consumer-aligned",
         type="Analytical", domain="27", owner_role="Head of Fund Accounting", primary="FN-33",
         supporting=["FN-63", "FN-77", "FN-79", "FN-12", "FN-27", "FN-50"], wave="WP1C",
         definition="The certified Firm AUM with its slices (own funds at NAV from DP-165; managed-account assets at market value "
                    "from 46 and 49; institutional and OCIO mandates from 18) and its monthly reconciliation to certified Client "
                    "Assets (DP-008), with the own-fund overlap netted here and only here and every other difference explained "
                    "by cause. The two families are reconciled, never summed (CW-011).",
         objects=[("27", "Fund NAV Calculation"), ("27", "Share Class NAV"), ("27", "Fund Accounting Book"),
                  ("27", "ABOR to IBOR Reconciliation"), ("01", "Investment Product"), ("01", "Share Class"),
                  ("18", "Portfolio"), ("18", "Portfolio Implementation Link"), ("18", "Portfolio Valuation Summary"),
                  ("46", "Managed Account Composite"), ("46", "Managed Account Composite Membership"),
                  ("49", "Client Holding Valuation"), ("06", "Measure Value"), ("06", "Client Asset Measures"),
                  ("06", "Account Asset Summary"), ("06", "Snapshot"), ("32", "GIPS Firm Assets"),
                  ("43", "Seed Position Valuation"), ("22", "FX Rate Observation")],
         upstream=["DP-165", "DP-008", "DP-007", "DP-304", "DP-300", "DP-142", "DP-140", "DP-143", "DP-204", "DP-158",
                   "DP-004", "DP-013", MANAGED_SLICE],
         notes="Lead ruling 2026-10-15: Firm AUM and its slices are certified in DP-241 (the CERTIFIED entry moves from DP-165 at "
               "WP2); the managed-account slice is sourced from CLA-A DP-345. DP-165 keeps fund and class net assets and NAV."),
    dict(id="DP-243", disposition="re-scope", name="Total Client Relationship", tier="Consumer-aligned", type="Analytical",
         domain="12", owner_role="Head of Institutional Client Service", primary="FN-75",
         supporting=["FN-71", "FN-74", "FN-79", "FN-72"], wave="WP1C",
         definition="An institution's whole relationship with the firm, keyed on the party and rolled up to the ultimate parent: "
                    "OCIO and advisory mandates, recordkept plans it sponsors, intermediary agreements, client assets and fee "
                    "revenue, billing, service and pipeline. It answers what one institution is worth to the firm across lines; "
                    "the household equivalent is CLA-A DP-320 Household 360.",
         objects=[("12", "Institutional Client"), ("12", "Service Relationship"), ("12", "Relationship Health Score"),
                  ("12", "Mandate Termination"), ("05", "Sales Opportunity"), ("05", "Pipeline Status"),
                  ("16", "Plan Sponsor Profile"), ("47", "Billing Arrangement"), ("47", "Fee Invoice"),
                  ("06", "Client Asset Measures"), ("10", "Client Revenue Record"), ("02", "Party"),
                  ("02", "Legal Entity Hierarchy")],
         upstream=["DP-240", "DP-003", "DP-008", "DP-012", "DP-305", "DP-094", "DP-140", "DP-013"],
         notes="Kept as a cross-area view; owning domain 02 -> 12. Service health detail is DIS+FDN DP-510, billing CLA-A DP-350."),
]

# (id, disposition, successor, decision, reason). Disposition vocabulary: keep / re-scope / retire / succeed.
DISPOSITIONS = [
    ("DP-001", "re-scope", "DP-001", "CW-202", "Intermediary Partner Master on the restored 05 firm, hierarchy and advisor objects; absorbs DP-002."),
    ("DP-002", "retire", "DP-001", "CW-202", "Merged into DP-001; dependents DP-003, DP-011, DP-093 re-point at WP1."),
    ("DP-003", "re-scope", "DP-003", "CW-202", "Institutions, consultants and plan relationships on 12, 05 and 16 (CW-132, CW-133)."),
    ("DP-004", "re-scope", "DP-004", "CW-202", "Kept and extended to advice and service offerings, platform availability and the firm risk rating."),
    ("DP-005", "re-scope", "DP-005", "CW-202", "Shrunk to the intermediary channel's agreements and placement."),
    ("DP-006", "re-scope", "DP-006", "CW-203", "Client flow transactions across every channel, copied from 49, 50, 29, 16 and feeds."),
    ("DP-007", "re-scope", "DP-007", "CW-203", "Client asset positions (account summaries with source book), never a book of record."),
    ("DP-008", "re-scope", "DP-008", "CW-203", "Client Assets & Net New Assets, certified, re-scoped in place (CW-142); no DP-30x successor."),
    ("DP-009", "keep", "DP-009", "CW-204", "Advisor organization and coverage (03), re-pointed at W2 to W4; primary FN-73."),
    ("DP-010", "keep", "DP-010", "CW-204", "Function re-pointed to FN-73; content left to the CLA-B brief (03 activity master)."),
    ("DP-011", "keep", "DP-011", "CW-204", "Function re-pointed to FN-76; content left to the CLA-B brief (04)."),
    ("DP-012", "re-scope", "DP-012", "CW-204", "Client Fee Revenue; the only source of certified client fee revenue."),
    ("DP-013", "keep", "DP-013", "CW-204", "Unchanged (CW-909)."),
    ("DP-014", "keep", "DP-014", "CW-204", "Content left to the DIS+FDN brief (11)."),
    ("DP-093", "re-scope", "DP-093", "CW-204", "Brokerage and advisory Account Master; primary FN-62."),
    ("DP-094", "keep", "DP-094", "CW-204", "Recordkept plan and participant core; participant balances in BWO DP-430."),
    ("DP-240", "re-scope", "DP-240", "CW-204", "Client household as the primary role family; primary FN-62."),
    ("DP-241", "re-scope", "DP-241", "CW-206", "Firm AUM certified here with its slices, reconciled to Client Assets."),
    ("DP-242", "keep", "DP-242", "CW-206", "Fund 360 carried (plan 8.3); primary FN-78."),
    ("DP-243", "re-scope", "DP-243", "CW-206", "Institutional total relationship; household view is CLA-A DP-320."),
    ("DP-244", "retire", "DP-498", "CW-206", "Into DIS+FDN DP-498 Cost to Serve & Client Lifetime Value (lead ruling)."),
    ("DP-245", "keep", "DP-245", "CW-206", "Lists the CW-011 families with their owning products (DP-008, DP-241, DP-145, DP-012, DP-240/DP-093 counts in DP-008)."),
    ("DP-246", "keep", "DP-246", "CW-206", "Filing hub; DP-083 input re-points to DP-224 (FOP+CORP CW-260)."),
    ("DP-247", "keep", "DP-247", "CW-206", "Reads certified metrics through DP-245 only."),
    ("DP-248", "keep", "DP-248", "CW-206", "Unchanged."),
    ("DP-116", "retire", "DP-093", "CW-930", "Private markets; feeder subscriptions are 15 Alternative Investment Subscription in DP-093."),
    ("DP-117", "retire", "DP-142", "CW-930", "Private markets; fund-interest holdings of feeder books stay in DP-142."),
    ("DP-136", "retire", "DP-093", "CW-930", "Private markets; feeder onboarding control in DP-093 and CLA-A DP-077."),
    ("DP-137", "retire", "DP-539", "CW-930", "Private markets; 52 Product Due Diligence taken by INV+IOP DP-539."),
    ("DP-138", "retire", "DP-149", "CW-930", "Private markets; fair value of private instruments stays with DP-149."),
    ("DP-139", "retire", "DP-146", "CW-930", "Private markets; Section 18 leverage measurement stays with DP-146."),
    ("DP-160", "retire", "DP-145", "CW-930", "Private markets; nothing carried (INV+IOP)."),
    ("DP-109", "re-scope", "DP-109", "CW-208", "US product reviews of funds, models and advice offerings (CW-161); drops DP-040 upstream."),
    ("DP-127", "keep", "DP-127", "CW-208", "Asset allocation and glide paths; advice CMAs and model weights in INV+IOP DP-530."),
    ("DP-130", "re-scope", "DP-130", "CW-208", "Tax management of the separate accounts on the portfolio book (24 Tax Budget, 18); client managed accounts are 46 (CLA-A DP-342, DP-343)."),
    ("DP-135", "re-scope", "DP-135", "CW-208", "Climate Metrics, Financed Emissions & ESG Fund Metrics; PAI and SFDR removed (lead ruling)."),
    ("DP-156", "retire", "DP-004", "CW-207", "Firm Risk Rating published by DP-004; realized volatility is a DP-146 measure (lead ruling)."),
    ("DP-175", "retire", "DP-172", "CW-207", "CASS residual; reconciliation coverage becomes a DP-172 measure; customer protection is BWO DP-445."),
    ("DP-186", "keep", "DP-186", "CW-208", "Form PF for the feeder funds (CW-166); supporting FN-26 and FN-18 dropped."),
    ("DP-199", "re-scope", "DP-199", "CW-208", "Deferred Compensation & Clawback: US deferral (IRC 409A) and firm clawback policy; MRT and EU codes gone."),
    ("DP-217", "re-scope", "DP-217", "CW-208", "Business continuity and critical business functions under FINRA Rule 4370 and Reg S-P; DORA removed."),
    ("DP-220", "keep", "DP-220", "CW-208", "Already re-cut to US regimes (FINRA Rule 3110, Notice 21-29, Reg S-P)."),
    ("DP-228", "re-scope", "DP-228", "CW-208", "Trade surveillance with FinCEN SAR (31 CFR 1023.320) for STOR; adds 48 client orders as subjects."),
    ("DP-040", "retire", "DP-109; DP-385", "CW-207", "MiFID target market and Consumer Duty; US product reviews are DP-109, advice program evidence CLA-B DP-385 (CLA-B agreed, CW-220)."),
    # 07 Sales Performance, Compensation & Territory retired at W4 (CW-907): its pending products are ruled here (the CLA-B
    # brief left them to the framing table; lead ruling 2026-10-15 for DP-032, DP-033 and DP-082).
    ("DP-016", "retire", None, "CW-207", "Wholesaler territory scorecard; territories and wholesalers retired with 07 (CW-907; FN-11 has no territory successor). No live dependent."),
    ("DP-054", "retire", None, "CW-207", "Territory alignment scenarios; territories retired with 07 (CW-907). No live dependent."),
    ("DP-057", "retire", None, "CW-207", "Wholesaler productivity and expense; wholesalers retired with 07 (CW-907); own-advisor productivity is CLA-B DP-387 and advisor profitability DIS+FDN DP-499. No live dependent."),
    ("DP-032", "succeed", "DP-390", "CW-207", "Sales crediting and goal attainment; incentive governance is CLA-B DP-390 in 03 (lead ruling). No live dependent."),
    ("DP-033", "succeed", "DP-390", "CW-207", "Incentive compensation payouts; succeeded by CLA-B DP-390 (lead ruling); live DP-198 re-points its upstream to DP-390 at WP1 (FOP+CORP RESPEC)."),
    ("DP-082", "succeed", "DP-390", "CW-207", "Sales compensation governance and controls; succeeded by CLA-B DP-390 with the 08 Incentive Conflict Review (lead ruling). No live dependent."),
    ("DP-064", "retire", None, "CW-207", "FinDatEx EMT / EPT / EET are EU / UK templates (CW-003)."),
    ("DP-065", "retire", None, "CW-207", "EU / UK inducements and retrocessions (CW-003)."),
]

_P = "Proposed"
DECISIONS = [
    {"id": "CW-200", "theme": "Data products", "title": "Functions re-cut for the wealth manager: 16 retired, 5 re-cut, FN-79 added",
     "domains": [], "issue": "framework.FUNCTIONS still carried the wholesale distribution functions FN-01 to FN-19 and the "
     "private markets FN-25 and FN-26, and live products named them as consumers (plan section 8.1).",
     "resolution": "framework.FUNCTION_DISPOSITIONS rules every code. Retired (code kept, never reused, no capabilities, flagged "
     "in RETIRED_FUNCTIONS and skipped by validators and builders): FN-01 to FN-11, FN-13, FN-14, FN-18, FN-25, FN-26. Re-cut "
     "(code kept): FN-12 Client Revenue & Profitability Finance, FN-15 Fund Shareholder Servicing & TA Oversight, FN-16 Market & "
     "Competitive Intelligence (retail and wealth market), FN-17 Third-Party Data Licensing & Entitlements (the enterprise "
     "function of 14, C-14.09), FN-19 Retirement Plan Services (adapted). Kept: FN-20 to FN-24, FN-27 to FN-51 and the W0 "
     "functions FN-60 to FN-78, confirmed against the capability map (every L2 has a live function). Added: FN-79 Business Line "
     "Leadership & Strategy, successor of FN-01. Every live product's primary and supporting functions were re-pointed to the "
     "successor; pending products keep theirs until their brief re-scopes them.",
     "rationale": "Every L2 capability keeps a function and every live product a live consumer; codes stay stable for history.",
     "action": "WP0 (framework.py); W5 tooling: build_capability_map.WP0_FUNCTIONS and the builders read RETIRED_FUNCTIONS",
     "status": _P, "priority": "High", "owner_role": "Program lead"},
    {"id": "CW-201", "theme": "Data products", "title": "Wealth product waves, wave codes and id blocks",
     "domains": [], "issue": "The briefs need one wave vocabulary and non-overlapping id ranges.",
     "resolution": "Waves: WP1F (foundational, re-scoped and new), WP1C (consumer-aligned; one wave per area at WP1, written "
     "WP1C or WP1C_<area>), WP2 (key registry, logical and semantic models). candidate_coverage.py reads the codes from "
     "framework (CANDIDATE_WAVES); W1 to W4 from the W0 instructions are accepted with a warning. Id blocks (framework.ID_BLOCKS): "
     "framing DP-300 to DP-319; CLA-A (02, 15, 45, 46, 47, 51) DP-320 to DP-379; CLA-B (01, 36, 03, 04, 13, 08) DP-380 to "
     "DP-429; BWO (48, 49, 50, 16) DP-430 to DP-479; DIS+FDN (05, 06, 10, 11, 12, 09, 17, 21, 14) DP-480 to DP-529; INV+IOP "
     "(23, 24, 25, 34, 52, 18, 22, 26, 31, 32, 33) DP-530 to DP-579; FOP+CORP (27, 28, 29, 35, 19, 20, 37 to 44) DP-580 to "
     "DP-639. Decisions: framing CW-200 to CW-209, briefs CW-210 to CW-269 in blocks of ten. Disposition rule for every brief: a "
     "pending product is re-scoped in place only when live products depend on its id; otherwise it is superseded by a new id "
     "and retired.",
     "rationale": "Parallel briefs without collisions; ids never reused (CW-002).", "action": "WP0 (framework.py, candidate_coverage.py)",
     "status": _P, "priority": "High", "owner_role": "Program lead"},
    {"id": "CW-202", "theme": "Data products", "title": "Intermediary channel foundations re-scoped onto the restored 05, 12 and 16 objects",
     "domains": ["05", "12", "16", "02", "01"], "issue": "DP-001 to DP-003 read interim 02 party roles; DP-005 carried the "
     "wholesale register; the DIS+FDN brief needs an Intermediary Partner Master.",
     "resolution": "DP-001 is re-scoped in place as Intermediary Partner Master (05 Intermediary Firms & Hierarchy and External "
     "Advisors & Coverage, on DP-240 identity) and absorbs DP-002, which retires (dependents re-point at WP1). DP-003 is "
     "re-scoped onto 12 Institutional Client and Investment Policy Statement, 05 consultants and 16 plan sponsor, recordkeeper "
     "and plan profiles. DP-004 stays and is extended to the 01 advice and service offerings, platform availability and the "
     "firm risk rating. DP-005 shrinks to the intermediary agreements and placement. No new partner master id.",
     "rationale": "Live products depend on DP-001, DP-003 and DP-005 (keep the ids); one master per concept.",
     "action": "WP1F specs", "status": _P, "priority": "High", "owner_role": "Program lead"},
    {"id": "CW-203", "theme": "Certified numbers", "title": "DP-008 re-scoped in place as Client Assets & Net New Assets; DP-006 and DP-007 become the client flow and position inputs",
     "domains": ["06"], "issue": "CW-142 left open whether DP-008 is re-scoped or succeeded.",
     "resolution": "DP-008 keeps its id (every certified-number reader keys on it) and is renamed Client Assets & Net New Assets; "
     "it is the only source of Client Assets, Net New Assets and Advised Assets, and publishes client market movement, net "
     "inter-channel transfers, client organic growth, the own-fund overlap (reported only), the own-fund gross sales, "
     "redemptions and net flows by channel, and the counts of funded accounts, clients and households. The wholesale Ending, "
     "Beginning and Average AUM metrics retire with SM-01 at WP2 ('AUM' is reserved for Firm AUM). DP-006 becomes Client Flow "
     "Transactions and DP-007 Client Asset Positions, copies with declared sources (CW-141).",
     "rationale": "One definition per certified number (CW-011); no id churn on the most-read product.",
     "action": "WP1F specs; WP2 SM-20", "status": _P, "priority": "High", "owner_role": "Head of Client & Channel Analytics"},
    {"id": "CW-204", "theme": "Data products", "title": "Client and account masters and client fee revenue re-scoped",
     "domains": ["02", "15", "10", "03"], "issue": "Plan 8.2 re-scopes DP-240, DP-093 and DP-012.",
     "resolution": "DP-240 becomes Client, Household & Party Master (household the primary role family; primary FN-62, owner "
     "Head of Client Data). DP-093 becomes the brokerage and advisory Account Master (registration types, features, agreements, "
     "program enrollment, RMD, alternative investment subscriptions; primary FN-62). DP-012 becomes Client Fee Revenue, the only "
     "source of certified client fee revenue, reading 47 billed fees and 10 client revenue. DP-009 is confirmed as the advisor "
     "organization (FN-73); DP-010, DP-011, DP-013, DP-014 and DP-094 keep their ids with re-pointed functions.",
     "rationale": "Plan sections 4 items 1, 2 and 7.", "action": "WP1F specs", "status": _P, "priority": "High",
     "owner_role": "Program lead"},
    {"id": "CW-205", "theme": "Data products", "title": "New foundational products DP-300 to DP-307",
     "domains": ["45", "46", "47", "48", "49", "50", "51", "52"], "issue": "The eight new domains have no foundational product.",
     "resolution": "DP-300 Client Holdings, Lots & Cost Basis (49); DP-301 Client Orders & Executions (48); DP-302 Money Movement "
     "Transactions (50); DP-303 Advice Plans & Recommendations (45); DP-304 Managed Account Model Assignments (46); DP-305 Fee "
     "Schedules & Billing Runs (47); DP-306 Manager & Sub-Adviser Master (52, with Product List Status); DP-307 Trust Fiduciary "
     "Record (51, optional). Venue and routing masters stay with the BWO foundational DP-432 and sweep programs and program "
     "banks with DP-431; participant balances with DP-430; CMAs, model lineups and weights with INV+IOP DP-530. DP-308 to DP-319 "
     "stay reserved.",
     "rationale": "Each master conformed once; the BWO and INV+IOP foundational candidates are accepted rather than absorbed.",
     "action": "WP1F", "status": _P, "priority": "High", "owner_role": "Program lead"},
    {"id": "CW-206", "theme": "Data products", "title": "Cross-area products DP-241 to DP-248",
     "domains": ["27", "06", "10", "12", "21"], "issue": "The E5 cross-area products were cut for the wholesale firm.",
     "resolution": "DP-241 becomes Firm AUM & Client Assets Reconciliation and certifies Firm AUM and its slices (fund at NAV from "
     "DP-165, managed accounts from CLA-A DP-345 over DP-304 and DP-300, institutional from 18), netting the own-fund overlap "
     "only there. DP-242 Fund 360 is carried. DP-243 is re-scoped to institutions (household view CLA-A DP-320). DP-244 retires "
     "into DIS+FDN DP-498. DP-245 lists the CW-011 families with their owning products. DP-246 to DP-248 are kept.",
     "rationale": "Lead rulings of 2026-10-15; one owner per certified number.", "action": "WP1C specs; WP2",
     "status": _P, "priority": "High", "owner_role": "Program lead"},
    {"id": "CW-207", "theme": "Data products", "title": "Products retired at WP0 and the RETIRED_PRODUCTS register",
     "domains": ["30", "08", "01", "28", "31"], "issue": "Retired products need a register the tooling reads.",
     "resolution": "framework.RETIRED_PRODUCTS {id: decision}: DP-116, DP-117, DP-136 to DP-139, DP-160 (CW-930); DP-040 "
     "(MiFID target market; US product reviews in DP-109), DP-064 and DP-065 (EU / UK), DP-156 (firm risk rating to DP-004, "
     "realized volatility to DP-146), DP-175 (CASS residual; coverage to DP-172) under this decision; DP-002 (CW-202) and DP-244 "
     "(CW-206). The 07-owned pending products (07 retired, CW-907) are ruled here too: DP-016, DP-054 and DP-057 retire with "
     "no successor; DP-032, DP-033 and DP-082 are succeeded by CLA-B DP-390 Incentive Plan Governance & Advisor Payouts (lead "
     "ruling 2026-10-15). The WP0 integration adds every other retired or superseded pending product with its brief's "
     "decision (WP0_Integration_Notes.md). Ids are never reused; rows and specs leave at the WP1 integration once dependents are re-pointed.",
     "rationale": "No EU / UK or private markets product survives without a US purpose.", "action": "WP1 integration; W5 tooling",
     "status": _P, "priority": "Medium", "owner_role": "Program lead"},
    {"id": "CW-208", "theme": "Data products", "title": "Carried enterprise products re-scoped for the wealth manager",
     "domains": ["36", "24", "34", "35", "20", "37", "40", "38"], "issue": "W1b and W4 left re-scopes for WP0.",
     "resolution": "Re-scoped: DP-109 (US product reviews, CW-161), DP-130 (portfolio-book separate account tax management; client "
     "managed accounts are 46), DP-135 (climate metrics, financed emissions and ESG fund metrics), DP-199 (deferred compensation "
     "and clawback), DP-217 (FINRA Rule 4370 business continuity), DP-228 (FinCEN SAR replaces STOR; 48 client orders as "
     "subjects). Kept: DP-127, DP-186, DP-220. Dropped supporting functions follow CW-200.",
     "rationale": "US-only (CW-003); each keeps a live purpose and its readers.", "action": "WP1 specs",
     "status": _P, "priority": "Medium", "owner_role": "Program lead"},
    {"id": "CW-209", "theme": "Certified numbers", "title": "Certified families registered once; SM-20 to SM-28 reserved; SM-01 to SM-07 retire at WP2",
     "domains": ["06", "27", "32", "10", "02", "15"], "issue": "CW-011 families need one owning model and product each.",
     "resolution": "semantic_model/register.CERTIFIED_WEALTH: Client Assets, Net New Assets, Advised Assets, client market "
     "movement, inter-channel transfers, client organic growth, own-fund overlap, funded accounts, clients and households in "
     "SM-20 Client Assets & Flows on DP-008; Firm AUM and its slices in SM-11 on DP-241; Personal Rate of Return in SM-08 on "
     "DP-145 (extended with 32 Client Account Performance); client fee revenue in SM-28 Client Economics on DP-012. RESERVED "
     "holds SM-20 to SM-28 with their area products. SM-02 to SM-06 and SM-13 retire at the WP0 integration; SM-01 and SM-07 stay "
     "live until SM-20 and SM-28 exist at WP2, then retire. The acceptance-question map is in WP0_Framing.md section 7.",
     "rationale": "Each certified metric is defined in one model (plan 8.4).", "action": "WP2", "status": _P,
     "priority": "High", "owner_role": "Program lead"},
]


# ---- WP1 scope (WP0 rationalization, 2026-10-15; Product_Briefs/WP1_Scope.md) ------------------------------
# Program-lead ruling: every candidate is flagged wp1=True (specified at WP1) or backlog=True (registered in
# framework.WAVE_BACKLOG, status 'backlog', not specified at WP1; ids unchanged). WP1_MERGES names the product a
# backlog candidate overlaps (its scope folds in there if it is picked up). WP1_MOVED_READS: objects with CDEs that
# only a backlog candidate read, now read by the named WP1 product (coverage rule; WP1 specs read them).
WP1_BACKLOG_IDS = []
WP1_MERGES = {
}
WP1_MOVED_READS = {
}
for _c in list(CANDIDATES) + list(globals().get("RESCOPED", [])):
    _bl = _c["id"] in WP1_BACKLOG_IDS
    _c["wp1"], _c["backlog"] = not _bl, _bl
    if _bl:
        _t = WP1_MERGES.get(_c["id"])
        _c["merge_into"] = _t
        _c["notes"] = (_c.get("notes", "") + " Backlog (WP1_Scope.md): not specified at WP1"
                       + (f"; overlaps {_t}, into which its scope folds if it is picked up." if _t else "; stands alone."))
    for _o in WP1_MOVED_READS.get(_c["id"], []):
        if (_o[0], _o[1]) not in _c["objects"]:
            _c["objects"].append((_o[0], _o[1]))
            _c["notes"] = _c.get("notes", "") + f" WP1 scope: also reads {_o[0]} {_o[1]} (from backlog {_o[2]})."
