"""WP2 Models and semantic layer: the program lead's decisions at the close (2026-10-17; Wealth_Manager_Rework_Plan.md
sections 8.4 and 10, stage WP2). Block CW-270 to CW-279 (framework.DECISION_BLOCKS). Merged into decisions.py as the record;
notes in consolidation/wp2_notes.md."""

DECISIONS = [
    {"id": "CW-270", "theme": "Semantic layer", "title": "Semantic homes settled for every live product; SM-30 and SM-31 added; DP-093 joins the shared dimensions",
     "domains": ["06", "02", "15", "45", "46", "47", "48", "49", "50", "16", "05", "12", "10", "08", "01", "36", "52"],
     "issue": "RESERVED (CW-209) named candidate ids; after the WP1 merges and re-scopes 39 live products had no model and six were "
              "listed twice.",
     "resolution": "register.MODELS carries SM-20 to SM-29 on the live WP1 ids (backlog merges applied) plus two models added by the "
                   "lead as SM-29 was: SM-30 Offering, Product Range & Market (the product-range products of the retired SM-06, "
                   "the CLA-B offering products, competitor and fee benchmarks, instrument coverage) and SM-31 Manager Oversight & "
                   "Due Diligence (DP-306, DP-535, DP-536, DP-538). Carried models extend: SM-08 takes DP-532 and DP-533, SM-09 "
                   "DP-544, SM-12 DP-580 and DP-408, SM-17 DP-044, DP-515 and DP-518; DP-498 moves from SM-14 to SM-28; DP-093 "
                   "Account Master joins SM-00 as the Client Account dimension. Products whose spec lists no BI delivery (DP-094 to "
                   "DP-096, DP-321, DP-324, DP-329, DP-403, DP-435, DP-447, DP-456, DP-085, DP-585) are bound to no model and reach "
                   "the layer through the products that read them.",
     "rationale": "One home per product (CONTRACT.md); the retired SM-06 left the product-range products without a model, and the "
                  "manager-oversight family did not fit SM-08 or SM-10.",
     "action": "WP2", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
    {"id": "CW-271", "theme": "Semantic layer", "title": "SM-01 to SM-07 and SM-13 retired; the 66 retired consumer products lose their specs and models; RESCOPE_PENDING emptied",
     "domains": ["06", "10", "03", "05", "12", "04", "01", "30"],
     "issue": "CW-041 held the wholesale consumer products and their models back until the semantic layer could re-home the certified "
              "families; CW-209 retired SM-01 and SM-07 only once SM-20 and SM-28 existed.",
     "resolution": "With SM-20 owning the client-asset and flow family and SM-28 the client fee revenue family, SM-01 and SM-07 retire "
                   "with SM-02 to SM-06 and SM-13 (register rows and files removed, listed in the register as history); the specs "
                   "and logical models of the 66 products retired at WP0 (RETIRED_PRODUCTS, CW-207, CW-220, CW-240, CW-245) are "
                   "deleted and RESCOPE_PENDING is empty. Personal Rate of Return (SM-08, DP-145) and the three Firm AUM slices "
                   "(SM-11, DP-241) enter CERTIFIED with the SM-20 and SM-28 families; CERTIFIED_WEALTH stays as the applied plan.",
     "rationale": "Applies CW-041, CW-207 and CW-209; the wholesale sibling keeps every retired product at wholesale-v1.0.",
     "action": "WP2", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
    {"id": "CW-272", "theme": "Logical models", "title": "Logical models for the WP1 products: ER foundations, consumer stars over the wealth dimensions, cross-consumer conformance where the spec lists the product upstream",
     "domains": ["02", "15", "03", "01", "06", "45", "46", "47", "48", "49", "50", "16", "29", "13", "52", "24", "11", "10"],
     "issue": "Plan section 8.4 names the conformed wealth dimensions but no foundational model published Channel, Program Bank or Manager.",
     "resolution": "Seventeen foundational ER models (models_w_books, models_w_advice, models_w_client_channels) and 94 consumer stars "
                   "(models_wc_*) at 0 errors. Conformed names: Household = DP-240 Party (Party Type Household) with the Household "
                   "Membership bridge; Client Account = DP-093 Account; Advisor = DP-009 Employee (the 03 Advisor; DP-001's Financial "
                   "Professional is the intermediary rep); Offering and Program = DP-004 Service Offering (Program read through "
                   "DP-304 or DP-093 Program Enrollment); Channel = the 06 Account Channel Assignment of DP-008 (no foundational "
                   "Channel entity exists; SM-00 names it through DP-013 Code Value); Program Bank stays DP-431's and Manager "
                   "DP-306's (model-local dimensions). A consumer model may conform an entity from another consumer product when "
                   "the spec lists that product upstream (DP-600 from DP-445, DP-334 and DP-335 from DP-398, DP-403 from DP-322, "
                   "DP-456 from DP-403). Special-category rows sit in restricted entities or are filtered at extraction; no model "
                   "joins the 18, 49 and 06 books as one fact.",
     "rationale": "Plan section 8.4 and data_models/CONTRACT.md; the household-to-account path is a bridge, never a column.",
     "action": "WP2", "status": "Proposed", "priority": "High", "owner_role": "Program lead"},
    {"id": "CW-273", "theme": "Semantic layer", "title": "One name, one definition: the owners of the metrics two WP2 models both wanted",
     "domains": ["03", "45", "02", "04", "10", "49", "06"],
     "issue": "Sibling models defined the same metric name from different products.",
     "resolution": "Hand-Off to Advice Engagement Rate % and Participant Hand-Offs Triggered are DP-393's (SM-22); Households Without "
                   "Primary Advisor is DP-320's (SM-21; DP-387's number is Book Households Without Primary Advisor); Total Cost to "
                   "Serve, Cost to Serve Rate (bps) and Cost Coverage of Certified Expense are DP-498's (SM-28; SM-14 references); "
                   "Funded Households Acquired and Campaign Spend are SM-25's (DP-392, DP-410); Own-Fund Client Holdings Market "
                   "Value is SM-20's (DP-496; SM-24 references); the Reg BI and PTE 2020-02 evidence flags are SM-22's (DP-334, "
                   "DP-335; SM-26 and SM-29 reference); the Rule 2165 clock stays DP-403's and reaches the layer only as aggregates.",
     "rationale": "CONTRACT.md: every metric defined once and referenced with ref= elsewhere.",
     "action": "WP2", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
    {"id": "CW-274", "theme": "Products", "title": "Spec follow-ups the WP2 models exposed, to apply by decision at the next product pass",
     "domains": ["46", "16", "08", "49", "04", "03", "09", "12", "11", "10"],
     "issue": "The model agents may not change specs; they recorded gaps where a spec input or upstream is missing.",
     "resolution": "To apply: DP-304 lists DP-303 upstream (Model Assignment.Source Recommendation) and reads 46 Substantially Identical "
                   "Security Group; DP-306 reads 52 Oversight Review; DP-467 filters the Hardship and Disability distribution types "
                   "at extraction (CD-344); DP-456 reads 08 External Protection Report Recipient Type and Recipient Agency; DP-446 "
                   "lists DP-004 upstream; DP-412 lists DP-324 upstream; DP-488 reads Onboarded Mandate; DP-490 reads Plan Cost "
                   "Center; DP-503 reads Role Market Scope; DP-506 reads Return Period; DP-514 reads Service Assignment ID; DP-498 "
                   "reads Attributed Milestone, Applied Attribution Model and Budget Currency; DP-405 reads Event Visitor; DP-418 "
                   "reads Interaction ID; register renames DP-009 to Advisor Organization & Coverage and DP-075's owner to Chief Data "
                   "Officer; FN-15 is primary for no product (fold into FN-62 or give it DP-093).",
     "rationale": "Keeps the WP2 models honest about borrowed keys; each item is one spec line and a model edit.",
     "action": "WP3", "status": "Proposed", "priority": "Medium", "owner_role": "Program lead"},
]
