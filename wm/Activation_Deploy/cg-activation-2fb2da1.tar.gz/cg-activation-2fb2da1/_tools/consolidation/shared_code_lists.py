"""Shared enterprise code lists - consolidation layer v0.2 (see CONTRACT.md).

SHARED        - enterprise lists that replace local lists in two or more business domains.
LOCAL_RENAMES - same list name, different meaning: renamed locally to disambiguate (not merged).
NOT_MERGED    - similar lists deliberately kept separate, with the reason, for the record.

Conventions
- Codes are UPPER_SNAKE. Where a list is hierarchical (Distribution Channel, Distribution Market,
  Information Classification) the parent is the code prefix, e.g. INTERMEDIARY_WIREHOUSE sits under
  INTERMEDIARY, and the parent code itself is valid for records known only at the higher level.
- value_map keys are (domain, local list name, local value exactly as authored in the content module).
- A value maps to None only when it has no enterprise equivalent; each such case is commented.
- Steward = business domain accountable for the list's values (09 unless the concept is clearly
  regulatory (08), party classification (02), product (01) or owned by another domain).

Wealth model W1 merge (2026-10-14; 01 adapted, 02 and 15 replaced, 09 and 17 passed). Inline comments mark each change.
- Business Line (CW-004, CW-909): six wholesale values replaced by the eight lines DB, DA, HA, PF, WR, IA, IC, TR; 01, 02
  and 15 registered as members; 18 and 21 re-mapped (Mutual Fund, ETF, CIT -> PF; SMA -> IA; Private Markets and
  Insurance-Dedicated Fund -> None, out of scope and retired with 30 at W4). LOCAL_RENAMES 01 Business Line -> Client
  Segment removed (CD-209 superseded for the wealth model).
- 09 re-cuts (CW-909, CW-039): Regulator to US authorities plus US_MSRB (15 UK, EU and Swiss values removed); Distribution
  Market to US only (W4 to retire or convert the list); Geographic Unit Type without the five UK / EU values and
  COUNTRY_SUBDIVISION relabeled; Delivery Method definition and source without FinDatEx. Member values of 03, 05, 07 and
  11 that pointed at removed codes map to None until those domains are replaced or retired.
- 02 (CW-902): MiFID Client Category, CRS Entity Classification and Data Quality Status memberships removed; US Investor
  Qualification, AML Risk Rating and Role Status memberships renamed Investor Qualification Standard, Risk Rating and
  Record Status; Regulator, Screening Result, Risk Rating, Personal Data Category, Record Status and LEI Registration
  Status maps rewritten to the wealth 02 labels; Case Status and Investor Category memberships added; Distribution
  Channel, Qualification Exam and Data Vendor memberships commented out, to be re-registered for 05 at W4.
- 01 (CW-901, CW-917): Investor Qualification Standard membership added; Share Class Type gains FRONT_END_LOAD and
  LEVEL_LOAD and loses PLATFORM_SUPER_CLEAN; Distribution Policy loses DISTRIBUTING_GROSS_INCOME; Regulatory Regime
  to the four US values plus NON_US_REGULATED_FUND; MMF Type to the Rule 2a-7 values; Data Quality Status,
  Distribution Strategy and CRS Entity Classification memberships removed; LOCAL_RENAMES 01 Registration Status
  removed; maps of Investor Category, Audience Restriction, Vehicle Type and Distribution Channel aligned to the
  01 values (new 01 values without a shared code map to None until the W4 / W5 re-cuts, CW-039).
- 15 (CW-915): Agreement Status, Case Status and Delivery Method memberships added; Networking Level map completed
  (Not Networked); Data Quality Status membership removed (no local list).
- 17 (CW-917, CW-039): Instrument Type gains CERTIFICATE_OF_DEPOSIT and MUNICIPAL_FUND_SECURITY.

Wealth model W1b merge (2026-10-14; US-only pass of the 22 kept domains 14, 18-23, 25-28, 31, 33-35, 37, 39-44; the
SHARED_RECUTS of proposals_w1b_NN.py applied under CW-039). Inline comments mark each change.
- Retired (CW-039): DORA ICT Service Type (steward 41; 40's member left with the ICT register, CW-940; 41 ICT Service Type
  is firm-defined and stays a local list, CW-941; direct user 14 dropped, CW-914) and DORA Substitutability (steward 40;
  40's member left, CW-940; 14 Substitutability is firm-defined, CW-914). Neither kept a member or a direct user: both
  deleted with their value maps.
- Accounting Basis (19, CW-919): IFRS_EU_ADOPTED, UK_ADOPTED_IFRS, FRS_102_UK_GAAP, LUX_GAAP, IRISH_GAAP_FRS_102 removed;
  19 map trimmed; member 10 Accounting Framework still holds four of them (W4 pass of 10): mapped to None.
- Lot Relief Method (18, CW-918): UK_SHARE_IDENTIFICATION_RULES_TCGA_1992_S105_106A and its map entry removed; source
  'IRS Publication 550 / Treas. Reg. 1.1012-1'; NOT_MERGED 18 / 15 reason reworded.
- Regulatory Trade Report Regime (26, CW-926, CW-928): EU_EMIR, UK_EMIR, EU_SFTR, UK_SFTR removed with the 26 and 28 map
  entries; source and definition US only.
- Regulatory Report Status (CW-925, CW-926, CW-928): steward 25 -> 28; member 25 Transaction Report Status removed (left
  with MiFIR Transaction Report); source 'Internal / SEC Rule 10c-1a / CFTC Part 45'; ARM wording removed.
- Exposure Method (31, CW-931): the two UCITS and two AIFMD values removed; SECTION_18_ASSET_COVERAGE added; source
  'SEC Rule 18f-4 / Investment Company Act Section 18'. Two values, at the floor. Risk Measure source without CESR/10-788.
- Business Domain (09; CW-914, CW-921, CW-021, CW-925, CW-928, CW-002): 01, 02, 25 and 28 relabeled to the domains.py
  names (codes kept); values for 45-52 added; 14 map re-keyed to its new labels and '45 Financial Planning & Advice'.
- Business Line (CW-004, CW-918, CW-921): 18 and 21 maps replaced by the identity map on DB, DA, HA, PF, WR, IA, IC, TR.
- Plan Scenario (19, CW-919): CAPITAL_AND_LIQUIDITY_STRESS no longer cites ICARA. Approved Price Basis (22, CW-922):
  CONTRACT_VALUE no longer names insurance-dedicated funds. Personal Data Category (02 steward; CW-921): source US only.
  Measurement Basis (01; CW-933): PCT_OF_CAPITAL no longer described as the AIFMD II limit (keep or remove at W4 with 30).
- Regulator: direct users 25 and 40 removed (no longer cite it; CW-925, CW-940).
- Tax Form Type created (CW-940, CW-915): steward 15, members 15 and 40, which carry the same seven IRS values.
- NOT_MERGED: ('20', 'MRT Remuneration Regime', '07', 'Remuneration Regime') removed (the 20 list left, CW-920).
- Candidates recorded, not created (one domain carries the list today): 14 Market Data Subscriber Status for 48 and 49
  (W3; CW-914); 37 Incident Notification Regime and Incident Notification Stage for 41 and 38 (steward 37; CW-937);
  34 Voting Choice Option Type for 13 (W2; CW-934); 41 Security Program Type for 38 (W4; CW-941); 20 Regulated Role
  Category for the replaced 08 (W2; CW-920). Withdrawn: 18 Transaction Cost Category (CW-918).
- Still due (w1_merge_notes.md section 5, unchanged): Investor Category, Investor Qualification Standard, Vehicle Type,
  Audience Restriction, Distribution Channel, Distribution Market, CRS Entity Classification, the stale Information
  Classification member ("15", "Confidentiality Classification"), three stale 02 LOCAL_RENAMES; COLL Change
  Classification (36, retire at W4); Third-Party Risk Domain value ESG_MODERN_SLAVERY for 37 to judge (CW-937).
  (All but ESG_MODERN_SLAVERY done at the W2-W4 merge below.)

Wealth model W2-W4 merge (2026-10-15; 03, 05 and 08 replaced, 04, 06, 10-13, 16, 24, 29, 32, 36 and 38 adapted, 45-52 new, 07
and 30 retired; the SHARED_MEMBERSHIPS, SHARED_RECUTS, VALUE_MAPS, MEMBERSHIPS_REMOVE, LIST_MAPS and LOCAL_RENAMES of the
proposals_w2_* / w3_* / w4_* files, as gathered in the merge-prep shared_lists and ruled by the program lead). Inline comments
mark each change.
- Re-cuts (CW-164, CW-039): Distribution Channel to the wealth channels (DIRECT_*, WORKPLACE_*, INSTITUTIONAL_*, INTERMEDIARY_*;
  RETIREMENT_DCIO becomes INTERMEDIARY_RECORDKEEPER, CW-139; 05's labels win, merge-prep ruling 8); Investor Category without
  the MiFID / Swiss values; Investor Qualification Standard without AIFMD; Audience Restriction without PROFESSIONAL_INVESTOR_ONLY,
  with ACCREDITED_INVESTOR_ONLY (PARTNER_SPECIFIC kept: 01 uses it); Vehicle Type with TENDER_OFFER_FUND and FEEDER_FUND and
  without the two private-fund values and the UK pooled pension value; Dealing Route to the US routes plus OWN_BD_OMNIBUS
  ('Affiliated Broker-Dealer Omnibus'; SWIFT_DIRECT removed by the 29 ruling); Fund Dealing Settlement Method with
  AFFILIATED_BD_OMNIBUS and without the Calastone and ICSD values; Data Provider without EFAMA, Investment Association, FE
  fundinfo and Citywire, with FEDERAL_RESERVE; Fund Category Scheme without EFAMA EFC and IA sectors; Regulator without
  US_STATE_INSURANCE_REGULATOR (CW-165); Measurement Basis without PCT_OF_CAPITAL (CW-930); Networking Level without LEVEL_1
  (steward 15); Message Standard without FUNDSXML, with NACHA_ACH, ANSI_X9_IMAGE and ISO_8583; Qualification Exam with
  SERIES_4 and SERIES_51; Frequency FORTNIGHTLY relabeled 'Biweekly', SEMI_MONTHLY and PER_PAYROLL added (16); Measure Unit with
  PERCENTILE and COUNT (52); Cost Bearer with FIRM (13); Order Side with EXERCISE and GIFT_TRANSFER (38 personal trading);
  Business Domain 03-13 relabeled to the domains.py names and 07 / 30 kept with the '(retired, CW-907 / CW-930)' suffix.
- Steward change: Performance Fee Basis 12 -> 32 (program-lead ruling; overrides the CW-054 and CW-140 wording).
- Retired and deleted (no member or direct user left): Distribution Market (CW-164), MiFID Client Category, Distribution
  Strategy, CRS Entity Classification (CW-039), COLL Change Classification (CW-936). Geographic Unit Type folded back into the
  09 local list (07 retired).
- Members: the replaced 03, 05 and 08 and the new 45-52 registered for the lists they copy (05 re-registers the 02 Distribution
  Channel, Qualification Exam and Data Vendor memberships, CW-902, CW-132); renamed members (03 Information Classification,
  Record Status, Sentiment; 05 Distribution Channel, Payable Invoice Status, Outgoing Payment Status, Delivery Method; 10
  Accounting Basis); Record Metadata memberships of Data Quality Status and Information Classification ended (CD-160); every 07
  member and 30 direct user removed. 32 (Record Status), 38 (Business Domain) and 45 (Business Line, Frequency, Record Status,
  Delivery Method) are registered direct users (their transitional memberships were dropped with their copies; W5).
- LOCAL_RENAMES: stale rows of the wholesale 02, 03, 05, 08 and 12 removed; 06 'Flow and AUM' -> 'Flow and Client Asset';
  11 Coverage Basis reworded; 13 Service Request Type -> 'Client Service Request Type' (12 -> 'Institutional Service Request
  Type') and 13 Good Order Status added. NOT_MERGED: six W2-W4 pairs added, stale 05 / 12 rows removed; LIST_MAPS added
  (50 Payment Rail -> 29 Order Payment Method).
- Not done here (recorded): Voting Choice Option Type (CW-082, W5), Net Worth Band, Holding Type and the other W5 candidates;
  SPECIAL_CATEGORY for Personal Data Category (special category is 21's sensitivity tier, not a category); Party Role Type,
  Committee Decision Type, Investment Committee Type and Shareholder Communication Type gains (local lists of 02, 24, 13).

Wealth model W5 consolidation (2026-10-16; registers pass, CW-175). Inline comments mark each change.
- Checker errors fixed against the live modules: Regulator (02 'US State Insurance Regulator' key dropped with 02's copy),
  Vehicle Type (52 private-fund keys dropped with 52's copy), Business Domain (09 relabeled to the domains.py names by agent B:
  identity map on the 52 numbered labels), Period Type (direct user 24 removed: 24 no longer cites it).
- Confirmed against content_05: the 05 memberships of Record Status, Risk Rating, Screening Result, Severity, Case Status,
  Business Line and Cost Bearer each have the local list and at least one attribute citing it, every value mapped. No domain
  is both a member and a direct user of a list (the 32 and 45 double registrations were already gone).
- Stewards: Audience Restriction 08 -> 04; Screening Result 08 -> 38. Regulatory Regime keeps NON_US_REGULATED_FUND
  (investment-universe principle). Third-Party Risk Domain: ESG_MODERN_SLAVERY -> FORCED_LABOR_HUMAN_RIGHTS ('Forced Labor /
  Human Rights'); the UK Modern Slavery Act label is recorded in jurisdiction.py (14, 37).
- Folded: Data Granularity (one member, 14; no citation). Kept although single-member (recorded, not folded: the content
  modules name them as shared): Fund Category Scheme (11), Hedging Type (01), Fund Dealing Settlement Method (29); Data
  Quality Status has one direct user (21) and no member. No list has fewer than two values; no unused list was found.
- LOCAL_RENAMES: 07 Plan Type and 12 Service Request Type deleted (07 retired; 12 authors the renamed list); 11 Price Quote Basis
  -> Competitor Price Quote Basis added (term conflict, CW-174). NOT_MERGED: 21 rows naming a wholesale list absent from the live
  module deleted as history; 4 rows re-keyed to a live member of the same shared list.
- Follow-ups of agent B's content sweep: Net Worth Band created (steward 02, members 02 and 11, identical ten bands); Measurement
  Basis PCT_OF_TOTAL_ASSETS no longer cites IRC 817(h) (CW-165).
"""


def _m(domain, list_name, mapping):
    """Expand {local value: shared code} for one member list into contract value_map keys."""
    return {(domain, list_name, local): code for local, code in mapping.items()}


def _vm(*parts):
    out = {}
    for p in parts:
        out.update(p)
    return out


SHARED = [
    # ------------------------------------------------------------------ 1
    {
        "name": "Data Quality Status",
        "steward": "09",
        "definition": "Validation state of a record or data value against its data quality rules; steward 09 as the enterprise data governance list used on every domain's record metadata.",
        "source": "Internal (aligned to DAMA-DMBOK data quality management and ISO 8000 concepts)",
        "values": [
            ("VALIDATED", "Validated", "Passed all applicable data quality rules."),
            ("PENDING_VALIDATION", "Pending Validation", "Not yet validated, including newly created or draft records."),
            ("EXCEPTION", "Exception", "Failed one or more validation rules; an open data quality exception exists."),
            ("ESTIMATED", "Estimated", "Value is an estimate pending actual or reported data."),
            ("STALE", "Stale", "Not refreshed within the expected refresh window."),
            ("DEPRECATED", "Deprecated", "No longer maintained; retained for history only."),
        ],
        # W1 merge: 01 (CW-901), 02 (CW-902) and 15 (CW-915) removed; the list left with Record Metadata (CD-160) and the
        # replaced 02 and 15 hold no copy.
        # W2-W4 merge: 03, 04, 05, 06, 08, 10, 11, 12 and 13 removed with their maps (Record Metadata dropped, CD-160; CW-903,
        # CW-904, CW-905, CW-906, CW-908, CW-910, CW-911, CW-912, CW-913); 07 removed (retired, CW-907).
        # 09 and 14 removed with their Record Metadata at the W2-W4 merge (CD-160, merge agent D); 21 cites the list directly.
        "members": [],
        "direct_users": ["21"],
        "value_map": _vm(),
    },
    # ------------------------------------------------------------------ 2
    {
        "name": "Frequency",
        "steward": "09",
        "definition": "Standard recurrence period of a process, delivery, payment, review or data refresh; steward 09.",
        "source": "Internal (aligned to ISO 20022 Frequency code set: INDA, DAIL, WEEK, TOWK, MNTH, QURT, MIAN, YEAR, ADHO)",
        "values": [
            ("REAL_TIME", "Real-Time", "Continuous or event-streamed, no batching."),
            ("INTRADAY", "Intraday", "More than once per day (ISO 20022 INDA)."),
            ("DAILY", "Daily", "Once per business or calendar day (ISO 20022 DAIL)."),
            ("WEEKLY", "Weekly", "Once per week (ISO 20022 WEEK)."),
            # W2-W4 merge: relabeled 'Biweekly' (US usage; steward 09 ruling, 16 fix pass); code kept, 'fortnightly' is a synonym.
            ("FORTNIGHTLY", "Biweekly", "Once every two weeks; also called fortnightly (ISO 20022 TOWK)."),
            # W2-W4 merge: SEMI_MONTHLY and PER_PAYROLL added for payroll-driven plan contributions (16; proposals_w3_16).
            ("SEMI_MONTHLY", "Semi-Monthly", "Twice per month, typically on fixed pay dates (e.g. the 15th and the last day)."),
            ("MONTHLY", "Monthly", "Once per month (ISO 20022 MNTH)."),
            ("QUARTERLY", "Quarterly", "Once per quarter (ISO 20022 QURT)."),
            ("SEMI_ANNUAL", "Semi-Annual", "Twice per year (ISO 20022 MIAN)."),
            ("ANNUAL", "Annual", "Once per year (ISO 20022 YEAR)."),
            ("BIENNIAL", "Biennial", "Once every two years."),
            ("ON_EVENT", "On Event", "Triggered by a defined business event rather than a calendar."),
            ("AD_HOC", "Ad Hoc", "Irregular, on request (ISO 20022 ADHO)."),
            ("PER_PAYROLL", "Per Payroll", "On each pay date of the plan sponsor's payroll, whatever its cycle."),
        ],
        # W2-W4 merge: 16, 45, 46 and 47 added (proposals_w3_16, proposals_w2_45, _46, _47); 05 removed (proposals_w4_05 MEMBERSHIPS_REMOVE, CW-140);
        # 07 removed (retired, CW-907); direct users 30 (retired, CW-930) and 36 (Product Committee Meeting Frequency removed) dropped.
        # 45 is also registered as a direct user (program-lead ruling): it re-points to 'Shared: Frequency' and drops its copy.
        "members": [("01", "Frequency"), ("03", "Frequency"), ("06", "Frequency"),
                    ("08", "Frequency"), ("11", "Frequency"), ("12", "Frequency"),
                    ("14", "Frequency"), ("15", "Frequency"), ("16", "Frequency"),
                    ("46", "Frequency"), ("47", "Frequency")],
        "direct_users": ["17", "19", "20", "21", "22", "24", "25", "26", "31", "32", "33", "35", "37", "38", "39", "41", "44", "45"],
        "value_map": _vm(
            _m("01", "Frequency", {"Daily": "DAILY", "Weekly": "WEEKLY", "Biweekly": "FORTNIGHTLY", "Monthly": "MONTHLY",
                                   "Quarterly": "QUARTERLY", "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL", "Ad Hoc": "AD_HOC"}),
            # 03 copies every shared value (proposals_w2_03, CW-903)
            _m("03", "Frequency", {"Real-Time": "REAL_TIME", "Intraday": "INTRADAY", "Daily": "DAILY", "Weekly": "WEEKLY",
                                   "Biweekly": "FORTNIGHTLY", "Monthly": "MONTHLY", "Quarterly": "QUARTERLY",
                                   "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL", "Biennial": "BIENNIAL",
                                   "On Event": "ON_EVENT", "Ad Hoc": "AD_HOC"}),
            _m("06", "Frequency", {"Intraday": "INTRADAY", "Daily": "DAILY", "Weekly": "WEEKLY", "Monthly": "MONTHLY",
                                   "Quarterly": "QUARTERLY", "Ad Hoc": "AD_HOC"}),
            # 08 re-mapped to the replaced 08 (proposals_w2_08, CW-908): Daily, Weekly and On Event used, Biennial dropped
            _m("08", "Frequency", {"Daily": "DAILY", "Weekly": "WEEKLY", "Monthly": "MONTHLY", "Quarterly": "QUARTERLY",
                                   "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL", "On Event": "ON_EVENT", "Ad Hoc": "AD_HOC"}),
            _m("11", "Frequency", {"Daily": "DAILY", "Weekly": "WEEKLY", "Monthly": "MONTHLY", "Quarterly": "QUARTERLY",
                                   "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL", "Ad Hoc": "AD_HOC"}),
            _m("12", "Frequency", {"Daily": "DAILY", "Weekly": "WEEKLY", "Monthly": "MONTHLY", "Quarterly": "QUARTERLY",
                                   "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL", "Ad Hoc": "AD_HOC", "On Event": "ON_EVENT"}),
            _m("14", "Frequency", {"Real-Time": "REAL_TIME", "Intraday": "INTRADAY", "Daily": "DAILY", "Weekly": "WEEKLY",
                                   "Monthly": "MONTHLY", "Quarterly": "QUARTERLY", "Semi-Annual": "SEMI_ANNUAL",
                                   "Annual": "ANNUAL", "Ad Hoc": "AD_HOC"}),
            _m("15", "Frequency", {"Weekly": "WEEKLY", "Biweekly": "FORTNIGHTLY", "Monthly": "MONTHLY", "Quarterly": "QUARTERLY",
                                   "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL", "On Event": "ON_EVENT", "Ad Hoc": "AD_HOC"}),
            # 16 already carries the US label 'Biweekly' and the two payroll values (proposals_w3_16, CW-916)
            _m("16", "Frequency", {"Weekly": "WEEKLY", "Biweekly": "FORTNIGHTLY", "Semi-Monthly": "SEMI_MONTHLY", "Monthly": "MONTHLY",
                                   "Quarterly": "QUARTERLY", "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL", "On Event": "ON_EVENT",
                                   "Per Payroll": "PER_PAYROLL"}),
            _m("46", "Frequency", {"Intraday": "INTRADAY", "Daily": "DAILY", "Weekly": "WEEKLY", "Monthly": "MONTHLY",
                                   "Quarterly": "QUARTERLY", "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL", "On Event": "ON_EVENT"}),
            _m("47", "Frequency", {"Monthly": "MONTHLY", "Quarterly": "QUARTERLY", "Semi-Annual": "SEMI_ANNUAL", "Annual": "ANNUAL",
                                   "On Event": "ON_EVENT"}),
        ),
    },
    # ------------------------------------------------------------------ 3
    {
        "name": "Distribution Channel",
        "steward": "09",
        # W2-W4 merge: re-cut to the wealth channels (CW-164, refined by CW-139 and CW-140; CW-011 Client Assets channels).
        "definition": "Two-level enterprise classification of the route through which the firm's clients and assets reach it (level 1 = DIRECT, WORKPLACE, INSTITUTIONAL, INTERMEDIARY; level 2 = code suffix); steward 09, with 05 assigning the channel to distributor firms and opportunities and 06 attributing client assets and flows. The 'advised and managed' roll-up (CW-011) is DIRECT_DIGITAL_ADVICE + DIRECT_HUMAN_ADVICE + DIRECT_TRUST, defined on 06 Measure Definition, not a list level.",
        "source": "Internal (wealth-manager channel scheme, CW-164; intermediary sub-channels aligned to Cerulli-style US channel groupings)",
        # Removed (CW-164, CW-911, CW-165, CW-013): INTERMEDIARY_INSURANCE_BD, INTERMEDIARY_RIA_INDEPENDENT, INTERMEDIARY_RIA_HYBRID,
        # INTERMEDIARY_RIA_CUSTODIAN (into INTERMEDIARY_BROKERAGE_PLATFORM), INTERMEDIARY_PRIVATE_BANK and INTERMEDIARY_FAMILY_OFFICE
        # (into INTERMEDIARY_BANK_TRUST and INTERMEDIARY_RIA), INTERMEDIARY_IFA_WEALTH, INTERMEDIARY_DFM, INTERMEDIARY_EU_BANK,
        # INTERMEDIARY_FUND_PLATFORM (now INTERMEDIARY_BROKERAGE_PLATFORM), INTERMEDIARY_INSURANCE, INTERMEDIARY_FUND_OF_FUNDS,
        # SUB_ADVISORY, DIRECT_TO_INVESTOR (now DIRECT) and RETIREMENT_DCIO (now INTERMEDIARY_RECORDKEEPER, CW-139).
        # Labels: 05's labels win (merge-prep ruling 8); 06 already carries them, 11 aligns at the merge.
        "values": [
            ("DIRECT", "Direct", "Level 1: clients served directly by the firm; use for records with no level-2 detail."),
            ("DIRECT_SELF_DIRECTED", "Direct - Self-Directed", "Self-directed brokerage (DB), including fund-only accounts."),
            ("DIRECT_DIGITAL_ADVICE", "Direct - Digital Advice", "Digital advice program accounts (DA)."),
            ("DIRECT_HUMAN_ADVICE", "Direct - Human Advice", "Human and hybrid advice relationships (HA)."),
            ("DIRECT_TRUST", "Direct - Trust", "Personal trust services (TR)."),
            ("WORKPLACE", "Workplace", "Level 1: participants in plans the firm recordkeeps (WR); use for records with no level-2 detail."),
            ("WORKPLACE_RECORDKEPT", "Workplace - Recordkept Plan", "Plan recordkept by the firm."),
            ("INSTITUTIONAL", "Institutional", "Level 1: institutional advisory (IA); use for records with no level-2 detail."),
            ("INSTITUTIONAL_DIRECT", "Institutional - Direct", "Institution deals with the firm without a consultant."),
            ("INSTITUTIONAL_CONSULTANT", "Institutional - Consultant-Led", "Search or relationship run through an investment consultant."),
            ("INSTITUTIONAL_OCIO", "Institutional - OCIO", "Outsourced CIO relationship."),
            ("INTERMEDIARY", "Intermediary", "Level 1: own funds and models held through third parties (IC); use for records with no level-2 detail."),
            ("INTERMEDIARY_WIREHOUSE", "Intermediary - Wirehouse", "US national full-service broker-dealers."),
            ("INTERMEDIARY_REGIONAL_BD", "Intermediary - National / Regional Broker-Dealer", "US national and regional full-service broker-dealers outside the wirehouses."),
            ("INTERMEDIARY_IBD", "Intermediary - Independent Broker-Dealer", "US independent broker-dealers and their affiliated representatives."),
            ("INTERMEDIARY_RIA", "Intermediary - RIA", "Independent, hybrid and dually registered RIAs and family offices."),
            ("INTERMEDIARY_BANK_TRUST", "Intermediary - Bank / Trust", "Bank brokerage, trust departments and private banks."),
            ("INTERMEDIARY_TAMP_MODEL", "Intermediary - TAMP / Model Marketplace", "Turnkey asset management programs and model portfolio marketplaces."),
            ("INTERMEDIARY_BROKERAGE_PLATFORM", "Intermediary - Brokerage Platform", "Third-party brokerage and fund platforms, including RIA custodian platforms."),
            ("INTERMEDIARY_RECORDKEEPER", "Intermediary - Third-Party Recordkeeper", "Own funds and CITs in plans recordkept by others (CW-139; was Retirement - DCIO)."),
        ],
        # W2-W4 merge: ('05', 'Partner Channel') renamed ('05', 'Distribution Channel') (CW-140); ('03', 'Sales Channel') removed
        # with the wholesale 03 (CW-903); ('07', 'Sales Channel') removed (retired, CW-907); ('04', 'Business Channel') removed
        # (the adapted 04 holds no channel list, CW-904).
        "members": [("01", "Distribution Channel"), ("05", "Distribution Channel"), ("06", "Distribution Channel"),
                    ("11", "Industry Channel")],
        "value_map": _vm(
            # 01 offering channels (CW-901), mapped at the W4 re-cut; 01 takes the shared labels (merge agent D), advice programs split into DA and HA.
            _m("01", "Distribution Channel", {
                "Direct - Self-Directed": "DIRECT_SELF_DIRECTED", "Direct - Digital Advice": "DIRECT_DIGITAL_ADVICE",
                "Direct - Human Advice": "DIRECT_HUMAN_ADVICE", "Workplace": "WORKPLACE", "Intermediary": "INTERMEDIARY",
                "Institutional": "INSTITUTIONAL"}),
            # 05 never assigns a DIRECT_ value (proposals_w4_05)
            _m("05", "Distribution Channel", {
                "Workplace": "WORKPLACE", "Workplace - Recordkept Plan": "WORKPLACE_RECORDKEPT",
                "Institutional": "INSTITUTIONAL", "Institutional - Direct": "INSTITUTIONAL_DIRECT",
                "Institutional - Consultant-Led": "INSTITUTIONAL_CONSULTANT", "Institutional - OCIO": "INSTITUTIONAL_OCIO",
                "Intermediary": "INTERMEDIARY", "Intermediary - Wirehouse": "INTERMEDIARY_WIREHOUSE",
                "Intermediary - National / Regional Broker-Dealer": "INTERMEDIARY_REGIONAL_BD",
                "Intermediary - Independent Broker-Dealer": "INTERMEDIARY_IBD", "Intermediary - RIA": "INTERMEDIARY_RIA",
                "Intermediary - Bank / Trust": "INTERMEDIARY_BANK_TRUST",
                "Intermediary - TAMP / Model Marketplace": "INTERMEDIARY_TAMP_MODEL",
                "Intermediary - Brokerage Platform": "INTERMEDIARY_BROKERAGE_PLATFORM",
                "Intermediary - Third-Party Recordkeeper": "INTERMEDIARY_RECORDKEEPER"}),
            # 06 and 11 carry every value (proposals_w4_06, proposals_w4_11); 11 aligned its two labels at the merge (ruling 8, merge agent D)
            *[_m(d, n, {
                "Direct": "DIRECT", "Direct - Self-Directed": "DIRECT_SELF_DIRECTED", "Direct - Digital Advice": "DIRECT_DIGITAL_ADVICE",
                "Direct - Human Advice": "DIRECT_HUMAN_ADVICE", "Direct - Trust": "DIRECT_TRUST", "Workplace": "WORKPLACE",
                rk_plan: "WORKPLACE_RECORDKEPT", "Institutional": "INSTITUTIONAL", "Institutional - Direct": "INSTITUTIONAL_DIRECT",
                "Institutional - Consultant-Led": "INSTITUTIONAL_CONSULTANT", "Institutional - OCIO": "INSTITUTIONAL_OCIO",
                "Intermediary": "INTERMEDIARY", "Intermediary - Wirehouse": "INTERMEDIARY_WIREHOUSE",
                "Intermediary - National / Regional Broker-Dealer": "INTERMEDIARY_REGIONAL_BD",
                "Intermediary - Independent Broker-Dealer": "INTERMEDIARY_IBD", "Intermediary - RIA": "INTERMEDIARY_RIA",
                "Intermediary - Bank / Trust": "INTERMEDIARY_BANK_TRUST",
                "Intermediary - TAMP / Model Marketplace": "INTERMEDIARY_TAMP_MODEL",
                "Intermediary - Brokerage Platform": "INTERMEDIARY_BROKERAGE_PLATFORM", rk_third: "INTERMEDIARY_RECORDKEEPER"})
              for d, n, rk_plan, rk_third in (
                  ("06", "Distribution Channel", "Workplace - Recordkept Plan", "Intermediary - Third-Party Recordkeeper"),
                  ("11", "Industry Channel", "Workplace - Recordkept Plan", "Intermediary - Third-Party Recordkeeper"))],
        ),
    },
    # ------------------------------------------------------------------ 4
    {
        "name": "Investor Category",
        "steward": "02",
        "definition": "Regulatory category of investor used to state product eligibility, target market and permitted communications audience; steward 02 as owner of party regulatory classification.",
        # W2-W4 merge (CW-164, CW-039): MiFID II / COBS 3 and Swiss CISA citations dropped with their values.
        "source": "FINRA Rule 2210 and 4512(c); SEC Reg D Rule 501(a); ICA 1940 s.2(a)(51)",
        "values": [
            ("RETAIL", "Retail", "US retail investor (FINRA 2210)."),
            # W2-W4 merge (CW-164, CW-039): PROFESSIONAL, ELIGIBLE_COUNTERPARTY and QUALIFIED_INVESTOR removed (MiFID II / Swiss).
            ("INSTITUTIONAL", "Institutional", "Institutional investor (FINRA 4512(c) institutional account)."),
            ("FINANCIAL_PROFESSIONAL", "Financial Professional", "US registered representatives and investment adviser representatives (advisor-use-only audience)."),
            ("ACCREDITED_INVESTOR", "Accredited Investor", "US Reg D Rule 501(a)."),
            ("QUALIFIED_PURCHASER", "Qualified Purchaser", "US ICA 1940 s.2(a)(51)."),
        ],
        # W2-W4 merge: 08 added (Compliance Review.Intended Audience, CW-908).
        "members": [("01", "Investor Type"), ("04", "Investor Category"), ("02", "Investor Category"), ("08", "Investor Category")],
        "direct_users": ["36"],   # 36 Proposed Eligible Investor Types (local copy of the 01 list removed, CD-286)
        "value_map": _vm(
            _m("01", "Investor Type", {"Retail": "RETAIL", "Institutional": "INSTITUTIONAL",
                                       "Accredited Investor": "ACCREDITED_INVESTOR", "Qualified Purchaser": "QUALIFIED_PURCHASER"}),
            # 02, 04 and 08 hold the communications-audience subset (W1 merge, CW-902; W2-W4 merge, CW-904, CW-908): the seven
            # wholesale 04 rows (US / EU / UK labels, 'Accredited Investor / Qualified Purchaser') replaced
            *[_m(d, "Investor Category", {"Retail": "RETAIL", "Institutional": "INSTITUTIONAL",
                                           "Financial Professional": "FINANCIAL_PROFESSIONAL"}) for d in ("02", "04", "08")],
        ),
    },
    # ------------------------------------------------------------------ 5
    # MiFID Client Category (steward 02) deleted at the W2-W4 merge (CW-039, CW-908): its last member, 08, left with the replaced
    # 08 (no MiFID categorization in the wealth model). Kept at tag wholesale-v1.0.
    # ------------------------------------------------------------------ 6
    {
        "name": "Investor Qualification Standard",
        "steward": "02",
        "definition": "Investor eligibility standard for private offerings and restricted vehicles, evidenced for a party (02) or required by an offering's access terms (01); steward 02.",
        "source": "SEC Reg D Rule 501(a); Advisers Act Rule 205-3; ICA 1940 s.2(a)(51); Securities Act Rule 144A",  # AIFMD dropped (CW-164)
        "values": [
            ("NONE_EVIDENCED", "None Evidenced", "No qualification standard evidenced for the party."),
            ("ACCREDITED_INVESTOR", "Accredited Investor", "Reg D Rule 501(a)."),
            ("QUALIFIED_CLIENT", "Qualified Client", "Advisers Act Rule 205-3 (performance fee eligibility)."),
            ("QUALIFIED_PURCHASER", "Qualified Purchaser", "ICA 1940 s.2(a)(51) (3(c)(7) funds)."),
            ("QUALIFIED_INSTITUTIONAL_BUYER", "Qualified Institutional Buyer", "Securities Act Rule 144A."),
            # W2-W4 merge (CW-164, CW-039): AIFMD_PROFESSIONAL_INVESTOR removed.
        ],
        # W1 merge: 02 member renamed from 'US Investor Qualification' (CW-902); 01 added (Feeder Access Terms, CW-901, CW-038).
        # W2-W4 merge: 08 removed with the wholesale 08 (CW-908; the replaced 08 holds no copy).
        "members": [("02", "Investor Qualification Standard"), ("01", "Investor Qualification Standard")],
        "value_map": _vm(
            *[_m(d, "Investor Qualification Standard", {
                "None Evidenced": "NONE_EVIDENCED", "Accredited Investor": "ACCREDITED_INVESTOR",
                "Qualified Client": "QUALIFIED_CLIENT", "Qualified Purchaser": "QUALIFIED_PURCHASER",
                "Qualified Institutional Buyer": "QUALIFIED_INSTITUTIONAL_BUYER"}) for d in ("02", "01")],
        ),
    },
    # ------------------------------------------------------------------ 7
    {
        "name": "Audience Restriction",
        "steward": "04",   # W5 (CW-175): 08 -> 04 (08 review ruling); the replaced 08 holds no copy, 04 applies it at the point of use
        "definition": "Highest-level statement of who may receive a marketing communication, asset, page or event, checked at the point of use; steward 04, which gates every marketing asset and page, with the categories set by the communications rules that 08 supervises.",
        "source": "FINRA Rule 2210 (retail / institutional communications); SEC Regulation D Rule 502(c) and 506(c)",  # FCA COBS 4 and ESMA guidelines dropped (CW-164)
        "values": [
            ("PUBLIC_RETAIL", "Public / Retail", "May be shown to anyone, including retail investors."),
            ("FINANCIAL_PROFESSIONAL_ONLY", "Financial Professional Use Only", "Advisor use only; not for use with the public."),
            ("INSTITUTIONAL_ONLY", "Institutional Use Only", "Institutional investors as defined by the applicable rule (e.g. FINRA 4512(c))."),
            # W2-W4 merge (CW-164): PROFESSIONAL_INVESTOR_ONLY removed (EU/UK); ACCREDITED_INVESTOR_ONLY added for feeder-fund
            # materials (01 Feeder Fund, CW-038). PARTNER_SPECIFIC is kept: 01 Audience Restriction still uses it.
            ("ACCREDITED_INVESTOR_ONLY", "Accredited Investors Only", "Private offering materials for verified accredited investors (Regulation D; feeder funds)."),
            ("PARTNER_SPECIFIC", "Partner-Specific", "Approved only for named distributor(s)."),
            ("CLIENT_SPECIFIC", "Client-Specific", "Single client or prospect."),
            ("INTERNAL_ONLY", "Internal Use Only", "Not for external distribution."),
        ],
        # W2-W4 merge: ('03', 'Audience Type') removed with the wholesale 03 (CW-903).
        "members": [("01", "Audience Restriction"), ("04", "Audience Restriction")],
        "value_map": _vm(
            _m("01", "Audience Restriction", {
                "Public / Retail": "PUBLIC_RETAIL", "Financial Professional Use Only": "FINANCIAL_PROFESSIONAL_ONLY",
                "Institutional Use Only": "INSTITUTIONAL_ONLY",  # 'Professional Investors Only' left 01 at W1 (CW-901)
                "Partner-Specific": "PARTNER_SPECIFIC", "Client-Specific": "CLIENT_SPECIFIC",
                "Internal Use Only": "INTERNAL_ONLY"}),
            # 04 re-cut (proposals_w2_04, CW-904): 'Professional Investors Only' and 'Partner-Specific' removed
            _m("04", "Audience Restriction", {
                "Public / Retail": "PUBLIC_RETAIL", "Financial Professional Use Only": "FINANCIAL_PROFESSIONAL_ONLY",
                "Institutional Use Only": "INSTITUTIONAL_ONLY", "Client-Specific": "CLIENT_SPECIFIC",
                "Internal Use Only": "INTERNAL_ONLY"}),
        ),
    },
    # ------------------------------------------------------------------ 8
    {
        "name": "Networking Level",
        "steward": "15",
        "definition": "DTCC NSCC Networking matrix level that allocates account control and servicing between the fund/TA and the intermediary; steward 15 (owner on the account, CW-915), with 05 holding the level agreed in contract and 29 the level of the register account.",
        "source": "DTCC NSCC Networking service (matrix levels 0, 3, 4) - Level 0 wording to be confirmed against the current DTCC matrix with the TA",
        "values": [
            ("LEVEL_0", "Level 0", "Intermediary keeps the account records; the fund/TA has no direct shareholder relationship (typically trust and plan accounts)."),
            # W2-W4 merge (29 review ruling, steward 15): LEVEL_1 removed; the DTCC Networking matrix lists levels 0, 3 and 4.
            ("LEVEL_3", "Level 3", "Firm-controlled: the intermediary handles customer contact, orders, statements and tax reporting."),
            ("LEVEL_4", "Level 4", "Fund-controlled: the intermediary processes orders; the fund/TA provides statements, accounting and tax reporting."),
            ("NOT_NETWORKED", "Not Networked", "Account not on Networking (omnibus or direct)."),
        ],
        "members": [("15", "Networking Level"), ("05", "Networking Level")],
        "direct_users": ["29"],  # Stage 2 (CD-210)
        "value_map": _vm(
            # 15 (formerly 02) and 05 drafts describe levels 0, 3 and 4 differently; enterprise descriptions follow 05 pending TA confirmation
            # 15 steward for the IC line (CW-039, CW-915); 15 dropped 'Level 1' at the merge
            _m("15", "Networking Level", {"Level 0": "LEVEL_0", "Level 3": "LEVEL_3", "Level 4": "LEVEL_4", "Not Networked": "NOT_NETWORKED"}),
            # 'Level 1' left the shared list at the W2-W4 merge; 05 dropped it from its copy (merge agent D)
            _m("05", "Networking Level", {"Level 0": "LEVEL_0", "Level 3": "LEVEL_3", "Level 4": "LEVEL_4",
                                          "Not Networked": "NOT_NETWORKED"}),
        ),
    },
    # ------------------------------------------------------------------ 9
    {
        "name": "Qualification Exam",
        "steward": "08",
        "definition": "FINRA / NASAA / MSRB qualification examination held by an individual, for external financial professionals (05) and own registered staff (08); steward 08 as owner of registrations and licenses.",
        "source": "FINRA qualification examinations (Rule 1210 series); NASAA Series 63 / 65 / 66; MSRB Series 51",
        "values": [
            ("SIE", "SIE", "Securities Industry Essentials."),
            ("SERIES_4", "Series 4", "Registered Options Principal (added at the W2-W4 merge, CW-908)."),
            ("SERIES_6", "Series 6", "Investment Company and Variable Contracts Products Representative."),
            ("SERIES_7", "Series 7", "General Securities Representative."),
            ("SERIES_9_10", "Series 9 / 10", "General Securities Sales Supervisor (options and general modules)."),
            ("SERIES_24", "Series 24", "General Securities Principal."),
            ("SERIES_26", "Series 26", "Investment Company and Variable Contracts Products Principal."),
            ("SERIES_51", "Series 51", "MSRB Municipal Fund Securities Limited Principal (529 plans; added at the W2-W4 merge, CW-908)."),
            ("SERIES_63", "Series 63", "NASAA Uniform Securities Agent State Law."),
            ("SERIES_65", "Series 65", "NASAA Uniform Investment Adviser Law."),
            ("SERIES_66", "Series 66", "NASAA Uniform Combined State Law."),
            ("SERIES_99", "Series 99", "Operations Professional."),
        ],
        # ("02", "Qualification Exam") re-registered for 05 at the W2-W4 merge (CW-902, CW-132, CW-140).
        "members": [("08", "Qualification Exam"), ("05", "Qualification Exam")],
        "value_map": _vm(
            # Re-registered for 05 at W4 (CW-902); the wholesale 02 map is kept here for the record:
            # _m("02", "Qualification Exam", {"SIE": "SIE", "Series 6": "SERIES_6", "Series 7": "SERIES_7", "Series 63": "SERIES_63",
            #                                 "Series 65": "SERIES_65", "Series 66": "SERIES_66", "Series 24": "SERIES_24",
            #                                 "Series 9 / 10": "SERIES_9_10", "Series 26": "SERIES_26"}),
            # 08 (proposals_w2_08, CW-908) adds Series 4 and Series 51; Series 9 / 10 now used
            _m("08", "Qualification Exam", {"SIE": "SIE", "Series 4": "SERIES_4", "Series 6": "SERIES_6", "Series 7": "SERIES_7",
                                            "Series 9 / 10": "SERIES_9_10", "Series 24": "SERIES_24", "Series 26": "SERIES_26",
                                            "Series 51": "SERIES_51", "Series 63": "SERIES_63", "Series 65": "SERIES_65",
                                            "Series 66": "SERIES_66", "Series 99": "SERIES_99"}),
            # 05 Financial Professional.Qualification Exams (proposals_w4_05, CW-140): the ten wholesale shared values
            _m("05", "Qualification Exam", {"SIE": "SIE", "Series 6": "SERIES_6", "Series 7": "SERIES_7", "Series 9 / 10": "SERIES_9_10",
                                            "Series 24": "SERIES_24", "Series 26": "SERIES_26", "Series 63": "SERIES_63",
                                            "Series 65": "SERIES_65", "Series 66": "SERIES_66", "Series 99": "SERIES_99"}),
        ),
    },
    # ------------------------------------------------------------------ 10
    {
        "name": "Screening Result",
        "steward": "38",   # W5 (CW-175): 08 -> 38 (program-lead ruling; 38 owns the firm AML and sanctions program)
        "definition": "Outcome of sanctions, PEP, adverse-media or enforcement screening of a party or payment; steward 38 (the firm AML and sanctions compliance program), shared with 02 client onboarding/KYC, 05 distributor due diligence, 50 payment screening, 29 shareholder screening and 40 supplier screening.",
        "source": "Internal (aligned to FATF risk-based approach and common screening-tool dispositions)",
        "values": [
            ("NO_MATCH", "No Match", "Screening returned no potential match."),
            ("POTENTIAL_MATCH", "Potential Match - Under Review", "Alert raised; disposition pending."),
            ("FALSE_POSITIVE", "False Positive", "Alert reviewed and discounted."),
            ("CONFIRMED_MATCH", "Confirmed Match", "Alert reviewed and confirmed as a true match."),
        ],
        # W2-W4 merge: 08 removed (the replaced 08 holds no copy, CW-908); 05 (Distributor Due Diligence moved from 08, CW-135) and
        # 50 (Payment Sanctions Screening, CW-107) added; both copy every shared label.
        "members": [("02", "Screening Result"), ("05", "Screening Result"), ("50", "Screening Result")],
        "direct_users": ["29", "40"],  # Stage 2 (CD-210)
        "value_map": _vm(
            # 'True Match' relabeled in 02 (CW-902)
            *[_m(d, "Screening Result", {"No Match": "NO_MATCH", "Potential Match - Under Review": "POTENTIAL_MATCH",
                                          "False Positive": "FALSE_POSITIVE", "Confirmed Match": "CONFIRMED_MATCH"}) for d in ("02", "05", "50")],
        ),
    },
    # ------------------------------------------------------------------ 11
    {
        "name": "Personal Data Category",
        "steward": "02",
        "definition": "Category of personal data held about an individual or contained in a record, driving access, retention and data-subject-rights handling; steward 02 as owner of privacy and consent.",
        "source": "SEC Regulation S-P; CCPA / CPRA Cal. Civ. Code 1798.140 personal information categories",  # GDPR / UK GDPR dropped at the W1b merge (CW-921, CW-039)
        "values": [
            ("NONE", "No Personal Data", "Record holds no personal data."),
            ("IDENTITY", "Identity", "Name, date of birth and other identity attributes."),
            ("CONTACT", "Contact", "Business or personal contact details."),
            ("PROFESSIONAL_EMPLOYMENT", "Professional / Employment", "Employer, role and professional history of an external individual."),
            ("REGISTRATION_LICENSING", "Registration / Licensing", "Regulatory registrations, CRD/IRN and licenses."),
            ("HR_EMPLOYEE", "HR / Employee", "Own-employee HR data (performance, compensation, employment)."),
            ("FINANCIAL", "Financial", "Holdings, transactions, account and payment data."),
            ("GOVERNMENT_IDENTIFIER", "Government Identifier", "SSN, passport, national ID; sensitive under CPRA."),
            ("ONLINE_IDENTIFIERS_ENGAGEMENT", "Online Identifiers / Engagement", "Cookies, device IDs and digital engagement data."),
            ("INFERENCES_SEGMENTATION", "Inferences / Segmentation", "Profiles, scores and segments derived about the individual."),
            ("OPINION_ABOUT_INDIVIDUAL", "Opinion About Individual", "Recorded opinions or assessments about a person."),
            ("UNSTRUCTURED_MAY_CONTAIN", "Free Text - May Contain Personal Data", "Unstructured notes that may contain personal data."),
        ],
        # W2-W4 merge: 04 added (Marketing System.Personal Data Categories Processed, CW-904); 03 re-mapped to the replaced 03.
        # Not added: SPECIAL_CATEGORY (proposals_w2_03). Special category data (CD-344) is a sensitivity tier, held by 21 Personal
        # Data Sensitivity ('Special Category Data'), a separate axis from this category list (NOT_MERGED 04 / 02).
        "members": [("02", "Personal Data Category"), ("03", "Personal Data Category"), ("04", "Personal Data Category")],
        "direct_users": ["21"],
        "value_map": _vm(
            # 02 re-mapped at W1 (CW-902), 03 (CW-903) and 04 (CW-904) at the W2-W4 merge: each copies every shared value
            *[_m(d, "Personal Data Category", {
                "No Personal Data": "NONE", "Identity": "IDENTITY", "Contact": "CONTACT",
                "Professional / Employment": "PROFESSIONAL_EMPLOYMENT", "Registration / Licensing": "REGISTRATION_LICENSING",
                "HR / Employee": "HR_EMPLOYEE", "Financial": "FINANCIAL", "Government Identifier": "GOVERNMENT_IDENTIFIER",
                "Online Identifiers / Engagement": "ONLINE_IDENTIFIERS_ENGAGEMENT", "Inferences / Segmentation": "INFERENCES_SEGMENTATION",
                "Opinion About Individual": "OPINION_ABOUT_INDIVIDUAL",
                "Free Text - May Contain Personal Data": "UNSTRUCTURED_MAY_CONTAIN"}) for d in ("02", "03", "04")],
        ),
    },
    # ------------------------------------------------------------------ 12
    {
        "name": "FINRA Communication Category",
        "steward": "08",
        "definition": "FINRA Rule 2210(a) category of a broker-dealer communication, which drives approval, filing and content standards; steward 08.",
        "source": "FINRA Rule 2210(a)(2), (a)(3), (a)(5)",
        "values": [
            ("RETAIL_COMMUNICATION", "Retail Communication", "Distributed or made available to more than 25 retail investors within any 30-calendar-day period."),
            ("INSTITUTIONAL_COMMUNICATION", "Institutional Communication", "Distributed or made available only to institutional investors."),
            ("CORRESPONDENCE", "Correspondence", "Distributed to 25 or fewer retail investors within any 30-calendar-day period."),
        ],
        "members": [("04", "FINRA Communication Category"), ("08", "FINRA Communication Category")],
        "value_map": _vm(*[_m(d, "FINRA Communication Category", {
            "Retail Communication": "RETAIL_COMMUNICATION", "Institutional Communication": "INSTITUTIONAL_COMMUNICATION",
            "Correspondence": "CORRESPONDENCE"}) for d in ("04", "08")]),
    },
    # ------------------------------------------------------------------ 13
    {
        "name": "Social Platform",
        "steward": "04",
        "definition": "Social media platform on which the firm or its personnel hold accounts and publish content; steward 04 as owner of social media, with 08 supervising.",
        "source": "Internal",
        "values": [
            ("LINKEDIN", "LinkedIn", ""),
            ("X", "X", "Formerly Twitter."),
            ("YOUTUBE", "YouTube", ""),
            ("INSTAGRAM", "Instagram", ""),
            ("FACEBOOK", "Facebook", ""),
            ("THREADS", "Threads", ""),
            ("OTHER", "Other", "Any other platform; name it in the account record."),
        ],
        "members": [("04", "Social Platform"), ("08", "Social Platform")],
        "value_map": _vm(
            _m("04", "Social Platform", {"LinkedIn": "LINKEDIN", "X": "X", "YouTube": "YOUTUBE", "Instagram": "INSTAGRAM",
                                         "Facebook": "FACEBOOK", "Threads": "THREADS", "Other": "OTHER"}),
            _m("08", "Social Platform", {"LinkedIn": "LINKEDIN", "X": "X", "YouTube": "YOUTUBE", "Facebook": "FACEBOOK",
                                         "Instagram": "INSTAGRAM", "Threads": "THREADS", "Other": "OTHER"}),  # Threads used (CW-908)
        ),
    },
    # ------------------------------------------------------------------ 14
    {
        "name": "Outgoing Payment Status",
        "steward": "19",
        "definition": "Processing status of a payment the firm makes (intermediary partner payments in 05; supplier and other payments in 19); steward 19 Finance & Accounting as owner of the generic payable and payment records (CD-158).",
        "source": "Internal (aligned to ISO 20022 pain.002 payment status concepts)",
        "values": [
            ("SCHEDULED", "Scheduled", "Calculated and scheduled for payment."),
            ("RELEASED", "Released", "Released for payment (to AP, the bank or payroll)."),
            ("PAID", "Paid / Settled", "Funds settled with the payee."),
            ("FAILED", "Failed", "Payment rejected or failed to settle."),
            ("REVERSED", "Reversed", "Settled payment subsequently reversed or clawed back."),
            ("CANCELED", "Canceled", "Canceled before release."),
        ],
        # W2-W4 merge: ('05', 'Payment Status') renamed ('05', 'Outgoing Payment Status') with the six shared labels (CW-140);
        # ('07', 'Payment Status') removed (retired, CW-907); direct user 30 removed (retired, CW-930).
        "members": [("05", "Outgoing Payment Status")],
        "direct_users": ["19", "25", "27", "44"],
        "value_map": _vm(
            _m("05", "Outgoing Payment Status", {"Scheduled": "SCHEDULED", "Released": "RELEASED", "Paid / Settled": "PAID",
                                                 "Failed": "FAILED", "Reversed": "REVERSED", "Canceled": "CANCELED"}),
        ),
    },
    # ------------------------------------------------------------------ 15
    {
        "name": "Message Standard",
        "steward": "06",
        "definition": "Messaging or record-format standard of an inbound or outbound message or file: partner data feeds, transaction and position feeds, corporate action notifications (MT564, seev.031), security reference and price messages (reda), order, execution and allocation messages (FIX), settlement, collateral and payment messages (sese, colr, pacs), custodian cash statements (camt) and OTC derivative confirmations (FpML); steward 06 as owner of data sources and feeds.",
        "source": "ISO 20022 (setr, semt, sese, pacs, camt); ISO 15022; DTCC NSCC record layouts; NACHA Operating Rules; ANSI X9.100-187; ISO 8583",  # FundsXML dropped (W2-W4 merge)
        "values": [
            ("ISO_20022", "ISO 20022", "ISO 20022 message, business area not specified."),
            ("ISO_20022_SETR", "ISO 20022 setr", "Securities trade (fund orders and confirmations)."),
            ("ISO_20022_SEMT", "ISO 20022 semt", "Securities management (statements of holdings and transactions)."),
            ("ISO_15022", "ISO 15022", "SWIFT MT messages."),
            ("DTCC_NSCC", "DTCC NSCC Record Formats", "NSCC record layouts, service not specified."),
            ("DTCC_FUNDSERV", "DTCC Fund/SERV", ""),
            ("DTCC_NETWORKING", "DTCC Networking", ""),
            ("DTCC_OMNISERV_ACTIVITY", "DTCC Omni/SERV Activity Record", ""),
            ("DTCC_OMNISERV_POSITION", "DTCC Omni/SERV Position Record", ""),
            # W2-W4 merge: FUNDSXML retired (steward 06; no member or direct user cites it, CW-906).
            ("PROPRIETARY", "Proprietary", "Vendor or partner proprietary format."),
            # Added in Stage 2 (CD-210): proposals_22, _25, _26 and _28, deduplicated (one FIX value)
            ("FIX", "FIX", "FIX Protocol messages: orders, executions, allocations (NewOrderSingle, ExecutionReport, AllocationInstruction) and market data (MsgType W)."),
            ("ISO_20022_SESE", "ISO 20022 sese", "Securities settlement: instruction, status advice and confirmation."),
            ("ISO_20022_COLR", "ISO 20022 colr", "Collateral management: margin calls, collateral proposals and disputes."),
            # description widened at the W2-W4 merge (50 request, CW-107): customer credit transfers and returns as well
            ("ISO_20022_PACS", "ISO 20022 pacs", "Interbank payments: customer credit transfers (pacs.008), financial institution transfers (pacs.009, incl. cash-only settlements) and payment returns (pacs.004)."),
            ("ISO_20022_SEEV", "ISO 20022 seev", "Securities events: corporate action notification, instruction, status, movement confirmation and reversal (seev.031-seev.037)."),
            ("ISO_20022_CAMT", "ISO 20022 camt", "Cash management: bank-to-customer statements and reports (camt.052, camt.053, camt.054)."),
            ("ISO_20022_REDA", "ISO 20022 reda", "Reference data, including reda.001 PriceReport."),
            ("FPML", "FpML", "OTC derivative confirmations and trade reporting."),
            # Added at the W2-W4 merge for 50 money movement rails (CW-107; proposals_w3_50)
            ("NACHA_ACH", "NACHA ACH File Format", "NACHA Operating Rules file format for ACH entries."),
            ("ANSI_X9_IMAGE", "ANSI X9 Image Exchange", "X9.100-187 check image exchange (Check 21)."),
            ("ISO_8583", "ISO 8583", "Card authorization and clearing messages."),
        ],
        # W2-W4 merge: 05 removed (proposals_w4_05 MEMBERSHIPS_REMOVE, CW-140); 48 (Order Route) and 50 (Money Movement) added.
        "members": [("06", "Message Standard"), ("48", "Message Standard"), ("50", "Message Standard")],
        "direct_users": ["17", "25", "26", "28", "29", "41", "43"],
        "value_map": _vm(
            # 'FundsXML' left the 06 copy (CW-906)
            _m("06", "Message Standard", {"DTCC Fund/SERV": "DTCC_FUNDSERV", "DTCC Networking": "DTCC_NETWORKING",
                                          "DTCC Omni/SERV Activity Record": "DTCC_OMNISERV_ACTIVITY",
                                          "DTCC Omni/SERV Position Record": "DTCC_OMNISERV_POSITION",
                                          "ISO 20022 setr": "ISO_20022_SETR", "ISO 20022 semt": "ISO_20022_SEMT",
                                          "Vendor Proprietary": "PROPRIETARY"}),
            _m("48", "Message Standard", {"FIX": "FIX", "DTCC Fund/SERV": "DTCC_FUNDSERV", "Proprietary": "PROPRIETARY"}),
            _m("50", "Message Standard", {"ISO 20022 pacs": "ISO_20022_PACS", "ISO 20022 camt": "ISO_20022_CAMT",
                                          "Proprietary": "PROPRIETARY", "NACHA ACH File Format": "NACHA_ACH",
                                          "ANSI X9 Image Exchange": "ANSI_X9_IMAGE", "ISO 8583": "ISO_8583"}),
        ),
    },
    # ------------------------------------------------------------------ 16
    {
        "name": "Information Classification",
        "steward": "09",
        "definition": "Confidentiality level of a record or dataset that controls who may see it, as a four-level scale (PUBLIC, INTERNAL, CONFIDENTIAL, RESTRICTED) with handling qualifiers as code suffixes; steward 09 with the CISO / CDO.",
        "source": "Internal (aligned to EDM Council CDMC classification and ISO/IEC 27001 Annex A 5.12)",
        "values": [
            ("PUBLIC", "Public", "Approved for public release."),
            ("INTERNAL", "Internal", "Any employee; not for external release."),
            ("CONFIDENTIAL", "Confidential", "Need-to-know within the firm; named users or teams."),
            ("CONFIDENTIAL_PERSONAL_DATA", "Confidential - Personal Data", "Confidential because it contains (non-special-category) personal data."),
            ("CONFIDENTIAL_CLIENT", "Confidential - Client", "Client confidential information."),
            ("CONFIDENTIAL_FINANCIAL", "Confidential - Financial", "Non-public financial information (not MNPI)."),
            ("CONFIDENTIAL_COMPENSATION", "Confidential - Compensation", "Restricted to the participant, management and the compensation team."),
            ("CONFIDENTIAL_LICENSED", "Confidential - Licensed", "Third-party data under license restrictions."),
            ("RESTRICTED", "Restricted", "Highest level; named individuals only."),
            ("RESTRICTED_PERSONAL_DATA", "Restricted - Personal Data", "Sensitive or special-category personal data."),
            ("RESTRICTED_MNPI", "Restricted - MNPI", "Material non-public information, e.g. pre-earnings results."),
            ("RESTRICTED_COMMERCIAL_TERMS", "Restricted - Commercial Terms", "Commercially sensitive contract terms, including side letters."),
            ("RESTRICTED_LEGAL", "Restricted - Legal", "Legally privileged or legally sensitive material."),
        ],
        # W2-W4 merge: ('03', 'Confidentiality Type') renamed ('03', 'Information Classification'), all shared labels copied (CW-903);
        # 05, 06, 10, 11 and 12 removed (Record Metadata dropped, CD-160; CW-905, CW-906, CW-910, CW-911, CW-912); 07 removed
        # (retired, CW-907); the stale ('15', 'Confidentiality Classification') removed (no 15 list since W1, CW-915).
        "members": [("03", "Information Classification"), ("14", "Information Classification")],
        "direct_users": ["20", "21", "23", "29", "33", "34", "35", "37", "38", "39", "41"],
        "value_map": _vm(
            _m("03", "Information Classification", {
                "Public": "PUBLIC", "Internal": "INTERNAL", "Confidential": "CONFIDENTIAL",
                "Confidential - Personal Data": "CONFIDENTIAL_PERSONAL_DATA", "Confidential - Client": "CONFIDENTIAL_CLIENT",
                "Confidential - Financial": "CONFIDENTIAL_FINANCIAL", "Confidential - Compensation": "CONFIDENTIAL_COMPENSATION",
                "Confidential - Licensed": "CONFIDENTIAL_LICENSED", "Restricted": "RESTRICTED",
                "Restricted - Personal Data": "RESTRICTED_PERSONAL_DATA", "Restricted - MNPI": "RESTRICTED_MNPI",
                "Restricted - Commercial Terms": "RESTRICTED_COMMERCIAL_TERMS", "Restricted - Legal": "RESTRICTED_LEGAL"}),
            _m("14", "Information Classification", {"Public": "PUBLIC", "Internal": "INTERNAL", "Confidential": "CONFIDENTIAL",
                                                    "Restricted": "RESTRICTED"}),
        ),
    },
    # ------------------------------------------------------------------ 17
    {
        "name": "Approval Status",
        "steward": "09",
        "definition": "Status of a request that needs approval (compensation plans, communications, gifts and entertainment, pre-clearance, targets, journals); steward 09 as a generic workflow list.",
        "source": "Internal",
        "values": [
            ("NOT_REQUIRED", "Not Required", "No approval needed under the applicable policy."),
            ("PENDING", "Pending", "Submitted and awaiting decision."),
            ("APPROVED", "Approved", ""),
            ("APPROVED_WITH_CONDITIONS", "Approved with Conditions", "Approved subject to stated changes or conditions."),
            ("RETROSPECTIVELY_APPROVED", "Retrospectively Approved", "Approved after the event (policy breach to be recorded)."),
            ("REJECTED", "Rejected", ""),
            ("EXPIRED", "Expired", "Approval lapsed (e.g. past its review or expiry date)."),
            ("WITHDRAWN", "Withdrawn", "Withdrawn by the requester."),
        ],
        # W2-W4 merge: 03 (Incentive Compensation Plan approval, CW-903), 46, 49, 50 and 51 added; 07 removed (retired, CW-907);
        # direct user 30 removed (retired, CW-930). 38 folds its local Pre-Clearance Decision into its direct use (38 review ruling 5):
        # Approved, Approved with Conditions, Not Required and Withdrawn keep their labels; Denied becomes Rejected.
        "members": [("03", "Approval Status"), ("08", "Approval Status"), ("08", "G&E Approval Status"), ("46", "Approval Status"),
                    ("49", "Approval Status"), ("50", "Approval Status"), ("51", "Approval Status")],
        "direct_users": ["17", "18", "19", "21", "22", "23", "24", "25", "26", "27", "28", "31", "32", "33", "34", "35", "37", "38", "39", "40", "41", "43", "44"],
        "value_map": _vm(
            # 03, 08 (replaced, CW-908), 46, 49 and 51 copy every shared value; 50 a subset
            *[_m(d, "Approval Status", {"Not Required": "NOT_REQUIRED", "Pending": "PENDING", "Approved": "APPROVED",
                                        "Approved with Conditions": "APPROVED_WITH_CONDITIONS",
                                        "Retrospectively Approved": "RETROSPECTIVELY_APPROVED", "Rejected": "REJECTED",
                                        "Expired": "EXPIRED", "Withdrawn": "WITHDRAWN"}) for d in ("03", "08", "46", "49", "51")],
            _m("50", "Approval Status", {"Not Required": "NOT_REQUIRED", "Pending": "PENDING", "Approved": "APPROVED",
                                         "Approved with Conditions": "APPROVED_WITH_CONDITIONS", "Rejected": "REJECTED",
                                         "Withdrawn": "WITHDRAWN"}),
            _m("08", "G&E Approval Status", {"Not Required": "NOT_REQUIRED", "Pending": "PENDING", "Approved": "APPROVED",
                                             "Rejected": "REJECTED", "Retrospectively Approved": "RETROSPECTIVELY_APPROVED"}),
        ),
    },
    # ------------------------------------------------------------------ 18
    {
        "name": "Delivery Method",
        "steward": "09",
        "definition": "Method or route by which a document, report or data set is delivered to its recipient (client and shareholder documents, client reports, licensed vendor data); steward 09.",
        "source": "Internal (aligned to SEC e-delivery guidance and SEC Rule 30e-3 notice-and-access)",  # FinDatEx wording dropped at W1 (CW-909); values unchanged
        "values": [
            ("PAPER_MAIL", "Paper Mail", "Postal delivery, class not specified."),
            ("PAPER_MAIL_FIRST_CLASS", "Paper - First Class Mail", ""),
            ("PAPER_MAIL_BULK", "Paper - Bulk Mail", ""),
            ("EMAIL", "Email", "Email, form not specified."),
            ("EMAIL_NOTIFICATION_LINK", "Email - Notification with Link", "Electronic notice with a link to the document."),
            ("EMAIL_ATTACHMENT", "Email - Attachment", ""),
            ("EMAIL_SECURE", "Secure Email", "Encrypted or secure-message email."),
            ("PORTAL", "Portal Posting", "Posted to a firm-operated client, investor or distributor portal."),
            ("WEBSITE", "Website", "Published on a firm website (incl. 'website availability only' where rules permit)."),
            ("NOTICE_OF_INTERNET_AVAILABILITY", "Notice of Internet Availability", "Paper or electronic notice that the document is online (e.g. Rule 30e-3)."),
            ("INTERMEDIARY_DISTRIBUTION", "Intermediary Distribution", "Delivered via an intermediary or its agent (e.g. Broadridge, platform)."),
            ("API", "API", ""),
            ("SFTP_FILE", "SFTP File", "File transfer over SFTP."),
            ("DIRECT_TRANSMISSION", "Direct Transmission", "Direct file or API transmission to the recipient where the technical method is not recorded."),
            ("PLATFORM_UPLOAD", "Platform Upload", "Uploaded to the recipient's platform."),
            ("DATA_VENDOR", "Via Data Vendor", "Delivered through a third-party data vendor or data distribution platform."),
            ("CONSULTANT_DATABASE_FEED", "Consultant Database Feed", "Feed to an investment consultant database (e.g. eVestment)."),
            ("CLOUD_DATA_SHARE", "Cloud Data Share", "e.g. Snowflake Secure Data Sharing / marketplace listing."),
            ("STREAMING_FEED", "Streaming Feed", ""),
            ("WEB_PLATFORM", "Vendor Web Platform", "Vendor-hosted web application."),
            ("TERMINAL_DESKTOP", "Terminal / Desktop", "Vendor terminal or desktop application."),
            ("EXCEL_ADD_IN", "Excel Add-In", ""),
        ],
        # 15 added at W1 (CW-915). W2-W4 merge: ('05', 'Data Delivery Channel') replaced by ('05', 'Delivery Method') (the 05 data
        # feeds use the shared labels; 05 keeps Delivery Method, CW-140); ('08', 'Delivery Method') removed (EMT feeds left with the
        # wholesale 08, CW-908); 45 (Financial Plan Version delivery) and 47 (Fee Disclosure Delivery) added. 45 is also a direct
        # user (program-lead ruling): it re-points to 'Shared: Delivery Method' and drops its copy.
        "members": [("05", "Delivery Method"), ("12", "Delivery Channel"),
                    ("13", "Delivery Method"), ("14", "Delivery Method"), ("15", "Delivery Method"),
                    ("47", "Delivery Method")],
        "direct_users": ["42", "45"],  # 42: Stage 4 (CD-283); 45: W2-W4 merge ruling
        "value_map": _vm(
            # 05 partner data feeds (proposals_w4_05): shared labels
            _m("05", "Delivery Method", {"API": "API", "SFTP File": "SFTP_FILE", "Platform Upload": "PLATFORM_UPLOAD",
                                         "Via Data Vendor": "DATA_VENDOR"}),
            _m("12", "Delivery Channel", {"Client Portal": "PORTAL", "Email": "EMAIL", "Secure Email": "EMAIL_SECURE",
                                          "SFTP": "SFTP_FILE", "API": "API", "Consultant Database Feed": "CONSULTANT_DATABASE_FEED",
                                          "Post": "PAPER_MAIL", "Data Vendor Platform": "DATA_VENDOR"}),
            _m("13", "Delivery Method", {"Paper - First Class Mail": "PAPER_MAIL_FIRST_CLASS", "Paper - Bulk Mail": "PAPER_MAIL_BULK",
                                         "Electronic - Email Notification": "EMAIL_NOTIFICATION_LINK",
                                         "Electronic - Email Attachment": "EMAIL_ATTACHMENT",
                                         "Electronic - Portal Posting": "PORTAL",
                                         "Notice of Internet Availability": "NOTICE_OF_INTERNET_AVAILABILITY",
                                         "Website Availability Only": "WEBSITE",
                                         "Intermediary Distribution": "INTERMEDIARY_DISTRIBUTION"}),
            _m("14", "Delivery Method", {"API": "API", "SFTP File": "SFTP_FILE", "Cloud Data Share": "CLOUD_DATA_SHARE",
                                         "Terminal / Desktop": "TERMINAL_DESKTOP", "Web Platform": "WEB_PLATFORM",
                                         "Streaming Feed": "STREAMING_FEED", "Excel Add-In": "EXCEL_ADD_IN", "Email": "EMAIL"}),
            # 15 Disclosure Delivery Method (subset), W1 merge (CW-915)
            # 15 Disclosure Delivery Method and 47 Fee Disclosure Delivery Method (same subset); 45 adds Secure Email
            *[_m(d, "Delivery Method", {"Paper Mail": "PAPER_MAIL", "Email - Notification with Link": "EMAIL_NOTIFICATION_LINK",
                                        "Email - Attachment": "EMAIL_ATTACHMENT", "Portal Posting": "PORTAL"}) for d in ("15", "47")],
        ),
    },
    # ------------------------------------------------------------------ 19
    {
        "name": "Delivery Status",
        "steward": "09",
        "definition": "Outcome of an attempt to deliver a communication, document or report to a recipient; steward 09.",
        "source": "Internal (email statuses aligned to Adobe XDM directMarketing)",
        "values": [
            ("PENDING", "Pending", "Queued, not yet sent."),
            ("SENT", "Sent", "Dispatched; delivery not yet confirmed."),
            ("DELIVERED", "Delivered", "Delivery confirmed."),
            ("OPENED", "Opened", "Opened in a portal or tracked email."),
            ("DEFERRED", "Deferred", "Temporarily delayed by the receiving server; retrying."),
            ("SOFT_BOUNCE", "Soft Bounce", "Temporary email delivery failure."),
            ("HARD_BOUNCE", "Hard Bounce", "Permanent email delivery failure."),
            ("BOUNCED", "Bounced", "Email bounced, type not recorded."),
            ("BLOCKED", "Blocked", "Rejected by the receiving server or a block list."),
            ("RETURNED_UNDELIVERABLE", "Returned Undeliverable", "Paper mail returned by the postal service."),
            ("SUPPRESSED", "Suppressed", "Not sent because of a suppression rule (e.g. householding, opt-out, lost shareholder)."),
            ("FAILED", "Failed", "Delivery failed for another reason."),
            ("RECALLED", "Recalled", "Withdrawn after sending."),
        ],
        "members": [("04", "Email Delivery Status"), ("12", "Delivery Status"), ("13", "Delivery Status")],
        "value_map": _vm(
            _m("04", "Email Delivery Status", {"Sent": "SENT", "Delivered": "DELIVERED", "Soft Bounce": "SOFT_BOUNCE",
                                               "Hard Bounce": "HARD_BOUNCE", "Blocked": "BLOCKED", "Deferred": "DEFERRED"}),
            _m("12", "Delivery Status", {"Pending": "PENDING", "Delivered": "DELIVERED", "Opened": "OPENED",
                                         "Failed": "FAILED", "Recalled": "RECALLED"}),
            _m("13", "Delivery Status", {"Pending": "PENDING", "Sent": "SENT", "Delivered": "DELIVERED",
                                         "Email Bounced": "BOUNCED", "Returned Undeliverable": "RETURNED_UNDELIVERABLE",
                                         "Suppressed": "SUPPRESSED", "Failed": "FAILED"}),
        ),
    },
    # ------------------------------------------------------------------ 20
    {
        "name": "Risk Rating",
        "steward": "09",
        "definition": "Ordinal rating of assessed risk (inherent or residual) of a party, distributor or vendor; steward 09 as the common scale, with 02 (AML), 05 (distributor due diligence) and 14 (vendor risk) applying it.",
        "source": "Internal (aligned to FATF risk-based approach and US Interagency TPRM Guidance, June 2023)",
        "values": [
            ("LOW", "Low", ""),
            ("MEDIUM", "Medium", ""),
            ("HIGH", "High", ""),
            ("CRITICAL", "Critical", "Highest acceptable rating; requires senior approval and enhanced monitoring."),
            ("PROHIBITED", "Prohibited", "Outside risk appetite; relationship not permitted."),
        ],
        # 02 renamed from 'AML Risk Rating' at W1 (CW-902). W2-W4 merge: 08 removed and 05 added (Distributor Due Diligence moved
        # from 08 to 05, CW-135; all five shared labels).
        "members": [("02", "Risk Rating"), ("05", "Risk Rating"), ("14", "Risk Rating")],
        "direct_users": ["28", "37", "38", "41", "44"],  # Stage 2 (CD-210)
        "value_map": _vm(
            _m("02", "Risk Rating", {"Low": "LOW", "Medium": "MEDIUM", "High": "HIGH", "Critical": "CRITICAL", "Prohibited": "PROHIBITED"}),
            _m("05", "Risk Rating", {"Low": "LOW", "Medium": "MEDIUM", "High": "HIGH", "Critical": "CRITICAL", "Prohibited": "PROHIBITED"}),
            _m("14", "Risk Rating", {"Critical": "CRITICAL", "High": "HIGH", "Medium": "MEDIUM", "Low": "LOW"}),
        ),
    },
    # ------------------------------------------------------------------ 21
    {
        "name": "Severity",
        "steward": "09",
        "definition": "Seriousness of a finding or issue (due diligence findings, license compliance findings, vendor data issues); steward 09.",
        "source": "Internal",
        "values": [
            ("LOW", "Low", ""),
            ("MEDIUM", "Medium", ""),
            ("HIGH", "High", ""),
            ("CRITICAL", "Critical", "Immediate escalation required."),
        ],
        # W2-W4 merge: 05 (Due Diligence Finding, CW-135), 48, 50, 51 and 52 added; each copies the four shared labels.
        "members": [("05", "Severity"), ("08", "Severity"), ("14", "Severity"), ("48", "Severity"), ("50", "Severity"),
                    ("51", "Severity"), ("52", "Severity")],
        "direct_users": ["20", "21", "22", "25", "27", "28", "29", "31", "33", "34", "35", "36", "37", "38", "39", "41", "44"],
        "value_map": _vm(*[_m(d, "Severity", {"Low": "LOW", "Medium": "MEDIUM", "High": "HIGH", "Critical": "CRITICAL"})
                           for d in ("05", "08", "14", "48", "50", "51", "52")]),
    },
    # ------------------------------------------------------------------ 22
    {
        "name": "RAG Status",
        "steward": "09",
        "definition": "Red / amber / green indicator of health or progress against target; steward 09.",
        "source": "Internal (common management-reporting convention)",
        "values": [
            ("GREEN", "Green", "On track."),
            ("AMBER", "Amber", "At risk; action needed."),
            ("RED", "Red", "Off track; escalation needed."),
        ],
        "members": [("12", "RAG Status")],   # 08 removed at the W2-W4 merge (the replaced 08 holds no copy, CW-908)
        "direct_users": ["19", "31", "34", "36", "37", "41"],
        "value_map": _vm(*[_m(d, "RAG Status", {"Green": "GREEN", "Amber": "AMBER", "Red": "RED"}) for d in ("12",)]),
    },
    # ------------------------------------------------------------------ 23
    # Distribution Market (steward 09) retired at the W2-W4 merge (CW-164): one value (US) was left after the W1 re-cut, below the
    # two-value floor; members 03 Sales Market (wholesale 03, CW-903), 05 Agreement Market (not carried, CW-140) and 07 Market Scope
    # (retired, CW-907) and direct user 36 (Intended Distribution Markets removed, CW-170) all ended. Coverage geography is 09
    # Geographic Group; the UK extension restores the list. Kept at tag wholesale-v1.0.
    # ------------------------------------------------------------------ 24
    # Geographic Unit Type (steward 09) folded back into the 09 local list at the W2-W4 merge (retirement pass proposal): 07, the
    # other member, retired (CW-907), and no domain cites the shared list. Kept at tag wholesale-v1.0.
    # ------------------------------------------------------------------ 25
    {
        "name": "Data Provider",
        "steward": "14",
        "definition": "Organization that compiles or supplies external data, research or classifications (vendors, trade associations, regulators as data publishers); steward 14 as owner of data vendor relationships (each provider should also resolve to a PTY- party).",
        "source": "Internal",
        "values": [
            ("ICI", "ICI", "Investment Company Institute (US)."),
            # W2-W4 merge (CW-164, CW-911): EFAMA, INVESTMENT_ASSOCIATION, FE_FUNDINFO and CITYWIRE removed (EU/UK providers; no 17,
            # 22 or 34 user cites them).
            ("MORNINGSTAR", "Morningstar", ""),
            ("LSEG_LIPPER", "LSEG Lipper", ""),
            ("ISS_MARKET_INTELLIGENCE", "ISS Market Intelligence", "Incl. Simfund."),
            ("BROADRIDGE", "Broadridge", ""),
            ("CERULLI", "Cerulli Associates", ""),
            ("NASDAQ_EVESTMENT", "Nasdaq eVestment", ""),
            ("DISCOVERY_DATA", "Discovery Data", ""),
            ("FINTRX", "FINTRX", ""),
            ("US_DOL", "US Department of Labor", "Form 5500 datasets."),
            ("US_SEC", "US SEC", "Form ADV, EDGAR."),
            # Added at the W2-W4 merge for 11 household wealth sizing (proposals_w4_11)
            ("FEDERAL_RESERVE", "Federal Reserve", "Survey of Consumer Finances; Financial Accounts of the United States (Z.1)."),
            ("OTHER", "Other", "Name the provider on the record."),
            # Added for 17 Instrument & Issuer Reference in Stage 1 (proposals_17.py, CD-166)
            ("BLOOMBERG", "Bloomberg", "Market, reference, corporate action and classification (BICS) data; FIGI registration authority."),
            ("ICE_DATA_SERVICES", "ICE Data Services", "Fixed income reference data and evaluated pricing."),
            ("LSEG_DATA_ANALYTICS", "LSEG Data & Analytics", "Reference and market data (RIC, SEDOL); distinct from LSEG Lipper fund data."),
            ("SP_GLOBAL_MI", "S&P Global Market Intelligence", "Company, issuer and reference data (Capital IQ)."),
            ("MOODYS", "Moody's", "Credit ratings and research data (Moody's Ratings, Moody's Analytics)."),
            ("FITCH", "Fitch Ratings", "Credit ratings data."),
            ("MSCI", "MSCI", "Index, GICS classification and ESG data."),
            ("FTSE_RUSSELL", "FTSE Russell", "Index and ICB classification data."),
            ("DTCC", "DTCC", "Corporate action announcements (Global Corporate Actions) and settlement reference."),
            ("ANNA_DSB", "ANNA DSB", "OTC ISIN, UPI and CFI for OTC derivatives."),
            ("CUSIP_GLOBAL_SERVICES", "CUSIP Global Services", "CUSIP and CINS identifiers and issuer numbers."),
            # Added for 22 Market Data & Pricing in Stage 2 (proposals_22.py, CD-210)
            ("SP_DOW_JONES_INDICES", "S&P Dow Jones Indices", "Index levels, constituents and changes."),
            ("JPM_PRICINGDIRECT", "J.P. Morgan PricingDirect", "Evaluated pricing service."),
            ("TRADEWEB", "Tradeweb", "Composite and evaluated prices, trade data."),
            ("MARKETAXESS", "MarketAxess", "Composite prices and trade data."),
            ("STOXX", "STOXX", "Index data."),
            ("SOLACTIVE", "Solactive", "Index data."),
            ("FINRA", "FINRA", "TRACE trade prints; BrokerCheck and the FINRA Industry Snapshot (11)."),
            ("ISS_STOXX", "ISS STOXX", "Proxy research, voting recommendations and ESG data (ISS Governance, ISS ESG); distinct from ISS Market Intelligence (proposals_34, CD-241)."),
            ("GLASS_LEWIS", "Glass Lewis", "Proxy research and voting recommendations (proposals_34, CD-241)."),
            ("SUSTAINALYTICS", "Sustainalytics", "ESG risk ratings and controversy research (a Morningstar company) (proposals_34, CD-241)."),
            ("CDP", "CDP", "Company-reported climate, water and forest disclosures (proposals_34, CD-241)."),
        ],
        # ("02", "Data Vendor") re-registered for 05 at the W2-W4 merge (CW-902, CW-132, CW-140).
        "members": [("11", "Industry Data Provider"), ("05", "Data Vendor")],
        "direct_users": ["17", "22", "34"],
        "value_map": _vm(
            # 05 External Classification.Classification Vendor (proposals_w4_05): the seven wholesale 02 Data Vendor values, now
            # with the shared labels
            _m("05", "Data Vendor", {"Discovery Data": "DISCOVERY_DATA", "Broadridge": "BROADRIDGE", "FINTRX": "FINTRX",
                                     "Cerulli Associates": "CERULLI", "Morningstar": "MORNINGSTAR", "Nasdaq eVestment": "NASDAQ_EVESTMENT",
                                     "Other": "OTHER"}),
            # 11 replaced (proposals_w4_11, CW-911): EU/UK providers removed, FINRA and Federal Reserve added
            _m("11", "Industry Data Provider", {"ICI": "ICI", "Morningstar": "MORNINGSTAR", "LSEG Lipper": "LSEG_LIPPER",
                                                "ISS Market Intelligence": "ISS_MARKET_INTELLIGENCE", "Broadridge": "BROADRIDGE",
                                                "Cerulli Associates": "CERULLI", "Nasdaq eVestment": "NASDAQ_EVESTMENT",
                                                "Discovery Data": "DISCOVERY_DATA", "US Department of Labor": "US_DOL",
                                                "US SEC": "US_SEC", "FINRA": "FINRA", "Federal Reserve": "FEDERAL_RESERVE",
                                                "Other": "OTHER"}),
        ),
    },
    # ------------------------------------------------------------------ 26
    {
        "name": "Regulator",
        "steward": "09",
        "definition": "Regulatory authority, self-regulatory organization or standard setter relevant to the firm, its entities, its counterparties or its horizon scanning; steward 09 as owner of the code list registry (entity authorizations, its first user, moved to 38 under CD-250).",
        "source": "Internal (official names per each authority)",  # ESMA NCA register dropped at W1 (CW-909)
        "values": [
            ("US_SEC", "SEC", "US Securities and Exchange Commission."),
            ("US_FINRA", "FINRA", "US self-regulatory organization for broker-dealers."),
            ("US_STATE_SECURITIES_REGULATOR", "US State Securities Regulator", "Via NASAA / IARD notice filings."),
            ("US_CFTC_NFA", "CFTC / NFA", "Commodity pool operator / commodity trading adviser regulation."),
            ("US_OCC", "OCC", "Office of the Comptroller of the Currency."),
            ("US_STATE_BANKING_REGULATOR", "US State Banking Regulator", "e.g. for state-chartered CIT trustee banks."),
            ("US_FEDERAL_RESERVE", "Federal Reserve", ""),
            ("US_DOL_EBSA", "DOL / EBSA", "US Department of Labor, Employee Benefits Security Administration."),
            # W2-W4 merge (CW-165): US_STATE_INSURANCE_REGULATOR removed (insurance-dedicated residue).
            ("US_IRS_TREASURY", "IRS / US Treasury", "US Internal Revenue Service and US Department of the Treasury: RIC qualification (IRC Subchapter M, Form 1120-RIC, Form 8613) and retirement account and plan tax rules (CD-224 context; added in Stage 3, CD-241)."),
            ("US_FINCEN", "FinCEN", "US Financial Crimes Enforcement Network: BSA / AML rules and SAR filing (added in Stage 4, CD-255)."),
            ("US_TREASURY_OFAC", "OFAC", "US Treasury Office of Foreign Assets Control: sanctions and blocked or rejected property reports (Stage 4, CD-255)."),
            ("US_DOJ", "US Department of Justice", "Criminal and civil enforcement (Stage 4, CD-255; proposals_39)."),
            ("US_STATE_ATTORNEY_GENERAL", "US State Attorney General", "State enforcement and investigations (Stage 4, CD-255; proposals_39)."),
            ("US_MSRB", "MSRB", "Municipal Securities Rulemaking Board: rules for dealers in municipal securities and 529 municipal fund securities (the broker-dealer sells both; CW-037). Added at the W1 merge (CW-909)."),
            # W1 merge (CW-909, CW-039): the 15 UK, EU and Swiss values removed (UK_FCA, UK_PRA, UK_HMT_OFSI, UK_NCA, LU_CSSF, IE_CBI,
            # DE_BAFIN, FR_AMF, IT_CONSOB_BANCA_D_ITALIA, ES_CNMV, NL_AFM, CH_FINMA, OTHER_EU_NCA, EU_ESMA, EU_COMMISSION).
            ("INTL_IOSCO", "IOSCO", "International Organization of Securities Commissions (standard setter)."),
        ],
        # 09 left at Stage 4: Entity Authorization moved to 38 (CD-250). W2-W4 merge: 08 added (FINRA Advertising Filing, CW-908).
        "members": [("02", "Regulator"), ("08", "Regulator"), ("11", "Regulatory Body")],
        # W1b merge: 25 (CW-925) and 40 (CW-940) removed; neither cites the list any more.
        "direct_users": ["19", "20", "26", "27", "31", "33", "35", "36", "37", "38", "39", "42", "43"],
        "value_map": _vm(
            # 02 re-mapped to the wealth 02 labels at the W1 merge (CW-902)
            _m("02", "Regulator", {"SEC": "US_SEC", "FINRA": "US_FINRA", "US State Securities Regulator": "US_STATE_SECURITIES_REGULATOR",
                                   "CFTC / NFA": "US_CFTC_NFA", "OCC": "US_OCC", "US State Banking Regulator": "US_STATE_BANKING_REGULATOR",
                                   "Federal Reserve": "US_FEDERAL_RESERVE", "DOL / EBSA": "US_DOL_EBSA",
                                   "IRS / US Treasury": "US_IRS_TREASURY",
                                   "FinCEN": "US_FINCEN", "OFAC": "US_TREASURY_OFAC", "US Department of Justice": "US_DOJ",
                                   "US State Attorney General": "US_STATE_ATTORNEY_GENERAL", "MSRB": "US_MSRB", "IOSCO": "INTL_IOSCO"}),
            _m("08", "Regulator", {"FINRA": "US_FINRA", "SEC": "US_SEC", "US State Securities Regulator": "US_STATE_SECURITIES_REGULATOR",
                                   "MSRB": "US_MSRB"}),
            # 11 replaced (proposals_w4_11, CW-911): shared labels copied, the six EU/UK values removed
            _m("11", "Regulatory Body", {"SEC": "US_SEC", "FINRA": "US_FINRA", "US State Securities Regulator": "US_STATE_SECURITIES_REGULATOR",
                                         "CFTC / NFA": "US_CFTC_NFA", "OCC": "US_OCC", "Federal Reserve": "US_FEDERAL_RESERVE",
                                         "DOL / EBSA": "US_DOL_EBSA", "IRS / US Treasury": "US_IRS_TREASURY", "FinCEN": "US_FINCEN",
                                         "MSRB": "US_MSRB", "IOSCO": "INTL_IOSCO"}),
        ),
    },
    # ------------------------------------------------------------------ 27
    {
        "name": "Record Status",
        "steward": "09",
        "definition": "Generic lifecycle status of a reference or configuration record (rules, hierarchies, roles, plays, registry entries) that has no domain-specific lifecycle; steward 09.",
        "source": "Internal (aligned to ISO/IEC 11179-6 registration status concepts)",
        "values": [
            ("DRAFT", "Draft", "Being authored; not yet submitted."),
            ("PROPOSED", "Proposed", "Submitted for approval."),
            ("PENDING", "Pending", "Approved or created but not yet effective."),
            ("ACTIVE", "Active", "Current and usable for new records."),
            ("PAUSED", "Paused", "Temporarily not in use; expected to resume."),
            ("INACTIVE", "Inactive", "Not currently in use but may be reactivated."),
            ("DEPRECATED", "Deprecated", "Valid for history, not for new records."),
            ("RETIRED", "Retired", "Permanently withdrawn."),
        ],
        # 02 renamed from 'Role Status' at W1 (CW-902). W2-W4 merge: ('03', 'Sales Play Status') renamed ('03', 'Record Status')
        # (CW-903); 05, 08, 45, 46, 47, 48, 50 and 52 added; 07 removed (retired, CW-907); direct user 30 removed (retired, CW-930).
        # 32 (24/32 fix pass) and 45 (program-lead ruling) are direct users: they re-point to 'Shared: Record Status' and drop their
        # verbatim copies; until then their copies are members.
        "members": [("02", "Record Status"), ("03", "Record Status"), ("05", "Record Status"), ("08", "Record Status"),
                    ("09", "Reference Record Status"), ("10", "Hierarchy Status"), 
                    ("46", "Record Status"), ("47", "Record Status"), ("48", "Record Status"), ("50", "Record Status"),
                    ("52", "Record Status")],
        "direct_users": ["17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45"],
        "value_map": _vm(
            # verbatim copies of the eight shared values
            *[_m(d, "Record Status", {"Draft": "DRAFT", "Proposed": "PROPOSED", "Pending": "PENDING", "Active": "ACTIVE",
                                      "Paused": "PAUSED", "Inactive": "INACTIVE", "Deprecated": "DEPRECATED", "Retired": "RETIRED"})
              for d in ("02", "03", "05", "08", "46", "48", "52")],
            # subsets
            _m("47", "Record Status", {"Draft": "DRAFT", "Proposed": "PROPOSED", "Pending": "PENDING", "Active": "ACTIVE",
                                       "Inactive": "INACTIVE", "Deprecated": "DEPRECATED", "Retired": "RETIRED"}),
            _m("50", "Record Status", {"Proposed": "PROPOSED", "Active": "ACTIVE", "Paused": "PAUSED", "Inactive": "INACTIVE", "Retired": "RETIRED"}),
            _m("09", "Reference Record Status", {"Proposed": "PROPOSED", "Active": "ACTIVE", "Inactive": "INACTIVE",
                                                 "Deprecated": "DEPRECATED", "Retired": "RETIRED"}),
            _m("10", "Hierarchy Status", {"Draft": "DRAFT", "Active": "ACTIVE", "Retired": "RETIRED"}),
        ),
    },
    # ------------------------------------------------------------------ 28
    {
        "name": "LEI Registration Status",
        "steward": "09",
        "definition": "GLEIF registration status of a Legal Entity Identifier record; steward 09 (internal entities, LEN-) and used by 02 for external parties.",
        "source": "GLEIF LEI-CDF 3.1 RegistrationStatus",
        "values": [
            ("PENDING_VALIDATION", "Pending Validation", ""),
            ("ISSUED", "Issued", ""),
            ("LAPSED", "Lapsed", "Not renewed by the due date."),
            ("MERGED", "Merged", ""),
            ("RETIRED", "Retired", ""),
            ("ANNULLED", "Annulled", ""),
            ("DUPLICATE", "Duplicate", ""),
            ("TRANSFERRED", "Transferred", ""),
            ("PENDING_TRANSFER", "Pending Transfer", ""),
            ("PENDING_ARCHIVAL", "Pending Archival", ""),
        ],
        "members": [("02", "LEI Registration Status"), ("09", "LEI Registration Status")],
        "value_map": _vm(
            _m("09", "LEI Registration Status", {v: v for v in (
                "PENDING_VALIDATION", "ISSUED", "LAPSED", "MERGED", "RETIRED", "ANNULLED", "DUPLICATE", "TRANSFERRED",
                "PENDING_TRANSFER", "PENDING_ARCHIVAL")}),
            # the wealth 02 holds the GLEIF labels, not the codes (W1 merge, CW-902)
            _m("02", "LEI Registration Status", {label: code for code, label in (
                ("PENDING_VALIDATION", "Pending Validation"), ("ISSUED", "Issued"), ("LAPSED", "Lapsed"), ("MERGED", "Merged"),
                ("RETIRED", "Retired"), ("ANNULLED", "Annulled"), ("DUPLICATE", "Duplicate"), ("TRANSFERRED", "Transferred"),
                ("PENDING_TRANSFER", "Pending Transfer"), ("PENDING_ARCHIVAL", "Pending Archival"))}),
        ),
    },
    # ------------------------------------------------------------------ 29
    {
        "name": "Agreement Status",
        "steward": "05",
        "definition": "Lifecycle status of a contract, whether a distribution agreement (05), a data license agreement (14) or an account agreement (15); steward 05 as the main agreements domain.",
        "source": "Internal",
        "values": [
            ("DRAFT", "Draft", ""),
            ("IN_NEGOTIATION", "In Negotiation", ""),
            ("PENDING_SIGNATURE", "Pending Signature", ""),
            ("EXECUTED_NOT_EFFECTIVE", "Executed - Not Yet Effective", "Signed; effective date in the future."),
            ("ACTIVE", "Active", ""),
            ("SUSPENDED", "Suspended", "Payments or trading suspended pending remediation."),
            ("UNDER_NOTICE", "Under Notice of Termination", "Notice given by either party."),
            ("TERMINATED", "Terminated", ""),
            ("EXPIRED", "Expired", "Ended at term without renewal."),
            ("SUPERSEDED", "Superseded", "Replaced by a new agreement."),
        ],
        "members": [("05", "Agreement Status"), ("14", "Agreement Status"), ("15", "Agreement Status")],  # 15 added at W1 (CW-915)
        "direct_users": ["26", "35", "39", "40", "44"],  # Stage 2 (CD-210)
        "value_map": _vm(
            # 05 copies all ten shared labels (proposals_w4_05, CW-140)
            _m("05", "Agreement Status", {"Draft": "DRAFT", "In Negotiation": "IN_NEGOTIATION", "Pending Signature": "PENDING_SIGNATURE",
                                          "Executed - Not Yet Effective": "EXECUTED_NOT_EFFECTIVE", "Active": "ACTIVE", "Suspended": "SUSPENDED", "Under Notice of Termination": "UNDER_NOTICE",
                                          "Terminated": "TERMINATED", "Expired": "EXPIRED", "Superseded": "SUPERSEDED"}),
            _m("14", "Agreement Status", {"Draft": "DRAFT", "In Negotiation": "IN_NEGOTIATION",
                                          "Executed - Not Yet Effective": "EXECUTED_NOT_EFFECTIVE", "Active": "ACTIVE",
                                          "Notice Given": "UNDER_NOTICE", "Expired": "EXPIRED", "Terminated": "TERMINATED"}),
            # 15 Account Agreement.Agreement Status (subset)
            _m("15", "Agreement Status", {"Pending Signature": "PENDING_SIGNATURE", "Executed - Not Yet Effective": "EXECUTED_NOT_EFFECTIVE",
                                          "Active": "ACTIVE", "Terminated": "TERMINATED", "Superseded": "SUPERSEDED"}),
        ),
    },
    # ------------------------------------------------------------------ 30
    {
        "name": "Payable Invoice Status",
        "steward": "19",
        "definition": "Processing status of an invoice the firm receives (from distribution partners in 05 or data vendors in 14); steward 19 Finance & Accounting as owner of the generic payable and payment records (CD-158).",
        "source": "Internal (accounts payable practice)",
        "values": [
            ("RECEIVED", "Received", ""),
            ("MATCHED", "Matched", "Matched to the calculated or contracted amount."),
            ("UNDER_REVIEW", "Under Review", "Being validated."),
            ("DISPUTED", "Disputed", ""),
            ("APPROVED", "Approved for Payment", ""),
            ("PAID", "Paid", ""),
            ("REJECTED", "Rejected", ""),
            ("CREDITED", "Credited", "Settled by a credit note."),
        ],
        # W2-W4 merge: ('05', 'Invoice Status') renamed ('05', 'Payable Invoice Status'), all eight shared labels copied (CW-140).
        "members": [("05", "Payable Invoice Status"), ("14", "Invoice Status")],
        "direct_users": ["19", "40"],
        "value_map": _vm(
            _m("05", "Payable Invoice Status", {"Received": "RECEIVED", "Matched": "MATCHED", "Under Review": "UNDER_REVIEW",
                                                "Disputed": "DISPUTED", "Approved for Payment": "APPROVED", "Paid": "PAID",
                                                "Rejected": "REJECTED", "Credited": "CREDITED"}),
            _m("14", "Invoice Status", {"Received": "RECEIVED", "Under Validation": "UNDER_REVIEW", "Disputed": "DISPUTED",
                                        "Approved for Payment": "APPROVED", "Paid": "PAID", "Credited": "CREDITED"}),
        ),
    },
    # ------------------------------------------------------------------ 31
    {
        "name": "Case Status",
        "steward": "09",
        "definition": "Workflow status of a service request, case, exception or finding (client service requests, disputes, alerts, error cases, supervisory findings, vendor data issues); steward 09.",
        "source": "Internal (aligned to Salesforce Service Cloud / FSC case status)",
        "values": [
            ("NEW", "New / Received", "Logged, not yet worked."),
            ("PENDING_GOOD_ORDER", "Pending Good Order", "Awaiting documents or information needed to process."),
            ("IN_PROGRESS", "In Progress", ""),
            ("WAITING_ON_CLIENT", "Waiting on Client", ""),
            ("PENDING_THIRD_PARTY", "Pending Third Party", "Raised with a vendor, intermediary or other third party."),
            ("ESCALATED", "Escalated", ""),
            ("RESOLVED", "Resolved / Completed", "Request fulfilled or issue fixed."),
            ("CLOSED", "Closed", "Closed after resolution and any confirmation."),
            ("REJECTED", "Rejected", "Not accepted or not in good order."),
            ("CANCELED", "Canceled", ""),
        ],
        # 02 and 15 added at W1 (CW-902, CW-915). W2-W4 merge: 05 (Due Diligence Finding, CW-135), 08 (CW-908), 16, 47 (Billing
        # Dispute moved from 12), 48, 49, 50, 51 and 52 added; each copies the shared labels (all ten, or a subset).
        "members": [("12", "Request Status"), ("13", "Service Request Status"), ("14", "Issue Status"),
                    ("02", "Case Status"), ("15", "Case Status"), ("05", "Case Status"), ("08", "Case Status"), ("16", "Case Status"),
                    ("47", "Case Status"), ("48", "Case Status"), ("49", "Case Status"), ("50", "Case Status"), ("51", "Case Status"),
                    ("52", "Case Status")],
        "direct_users": ["17", "21", "22", "25", "26", "27", "28", "29", "31", "33", "34", "37", "38", "39", "40", "41", "42", "44"],
        "value_map": _vm(
            _m("12", "Request Status", {"New": "NEW", "In Progress": "IN_PROGRESS", "Waiting on Client": "WAITING_ON_CLIENT",
                                        "Escalated": "ESCALATED", "Resolved": "RESOLVED", "Closed": "CLOSED", "Canceled": "CANCELED"}),
            _m("13", "Service Request Status", {"Received": "NEW", "Pending Good Order": "PENDING_GOOD_ORDER",
                                                "In Progress": "IN_PROGRESS", "Pending Third Party": "PENDING_THIRD_PARTY",
                                                "Completed": "RESOLVED", "Rejected": "REJECTED", "Canceled": "CANCELED"}),
            _m("14", "Issue Status", {"New": "NEW", "Raised with Vendor": "PENDING_THIRD_PARTY", "In Progress": "IN_PROGRESS",
                                      "Resolved": "RESOLVED", "Closed": "CLOSED", "Canceled": "CANCELED"}),
            # all ten values: 02 Onboarding Case, Death Notification, Consumer Privacy Request, Vulnerability Concern; 48 Trade Error
            # Case; 49 Client Settlement Fail; 51 trust requests, estate cases and tasks, fiduciary tax returns; 52 Manager Search and
            # Oversight Finding
            *[_m(d, "Case Status", {"New / Received": "NEW", "Pending Good Order": "PENDING_GOOD_ORDER", "In Progress": "IN_PROGRESS",
                                    "Waiting on Client": "WAITING_ON_CLIENT", "Pending Third Party": "PENDING_THIRD_PARTY",
                                    "Escalated": "ESCALATED", "Resolved / Completed": "RESOLVED", "Closed": "CLOSED",
                                    "Rejected": "REJECTED", "Canceled": "CANCELED"}) for d in ("02", "48", "49", "51", "52")],
            # subsets: 05 Due Diligence Finding remediation; 08 corrective actions, findings, alerts, complaints and senior investor
            # cases; 16 Late Deposit Case and Plan Correction; 47 Billing Dispute; 50 exceptions, alerts and card disputes
            _m("05", "Case Status", {"New / Received": "NEW", "In Progress": "IN_PROGRESS", "Pending Third Party": "PENDING_THIRD_PARTY", "Escalated": "ESCALATED", "Resolved / Completed": "RESOLVED", "Closed": "CLOSED", "Canceled": "CANCELED"}),
            _m("08", "Case Status", {"New / Received": "NEW", "In Progress": "IN_PROGRESS", "Waiting on Client": "WAITING_ON_CLIENT", "Pending Third Party": "PENDING_THIRD_PARTY", "Escalated": "ESCALATED", "Resolved / Completed": "RESOLVED", "Closed": "CLOSED", "Canceled": "CANCELED"}),
            _m("16", "Case Status", {"New / Received": "NEW", "In Progress": "IN_PROGRESS", "Waiting on Client": "WAITING_ON_CLIENT", "Pending Third Party": "PENDING_THIRD_PARTY", "Resolved / Completed": "RESOLVED", "Closed": "CLOSED", "Canceled": "CANCELED"}),
            _m("47", "Case Status", {"New / Received": "NEW", "In Progress": "IN_PROGRESS", "Waiting on Client": "WAITING_ON_CLIENT", "Escalated": "ESCALATED", "Resolved / Completed": "RESOLVED", "Closed": "CLOSED", "Canceled": "CANCELED"}),
            _m("50", "Case Status", {"New / Received": "NEW", "In Progress": "IN_PROGRESS", "Waiting on Client": "WAITING_ON_CLIENT", "Pending Third Party": "PENDING_THIRD_PARTY", "Escalated": "ESCALATED", "Resolved / Completed": "RESOLVED", "Closed": "CLOSED", "Canceled": "CANCELED"}),
            # 15 Alternative Investment Subscription.Subscription Documents Status (subset)
            _m("15", "Case Status", {"New / Received": "NEW", "Pending Good Order": "PENDING_GOOD_ORDER", "In Progress": "IN_PROGRESS",
                                     "Waiting on Client": "WAITING_ON_CLIENT", "Resolved / Completed": "RESOLVED",
                                     "Rejected": "REJECTED", "Canceled": "CANCELED"}),
        ),
    },
    # ------------------------------------------------------------------ 32
    {
        "name": "Fund Category Scheme",
        "steward": "11",
        "definition": "Fund classification scheme used to categorize own and peer funds for flows, market share and peer analysis; steward 11, which already consolidates the 06 list.",
        "source": "ICI investment classification; Morningstar Category; LSEG Lipper Global Classification; eVestment universes",  # EFAMA EFC and IA sectors dropped (CW-911)
        "values": [
            ("ICI_INVESTMENT_CLASSIFICATION", "ICI Investment Classification", ""),
            # W2-W4 merge (CW-164, CW-911): EFAMA_EFC and IA_SECTOR removed.
            ("MORNINGSTAR_CATEGORY", "Morningstar Category", "Local / regional Morningstar Category."),
            ("MORNINGSTAR_GLOBAL_CATEGORY", "Morningstar Global Category", ""),
            ("LIPPER_GLOBAL_CLASSIFICATION", "Lipper Global Classification", ""),
            ("EVESTMENT_UNIVERSE", "eVestment Universe", ""),
            ("FIRM_MARKET_SEGMENT", "Firm Market Segment", "Firm-defined segmentation."),
        ],
        "members": [("11", "Category Scheme")],
        "value_map": _vm(
            # replaced (proposals_w4_11, CW-911)
            _m("11", "Category Scheme", {"ICI Investment Classification": "ICI_INVESTMENT_CLASSIFICATION",
                                         "Morningstar Category": "MORNINGSTAR_CATEGORY",
                                         "Morningstar Global Category": "MORNINGSTAR_GLOBAL_CATEGORY",
                                         "Lipper Global Classification": "LIPPER_GLOBAL_CLASSIFICATION",
                                         "eVestment Universe": "EVESTMENT_UNIVERSE", "Firm Market Segment": "FIRM_MARKET_SEGMENT"}),
        ),
    },
    # ------------------------------------------------------------------ 33
    {
        "name": "Data Basis",
        "steward": "09",
        "definition": "Basis on which a data value was derived (reported, estimated, modeled, allocated); steward 09.",
        "source": "Internal",
        "values": [
            ("REPORTED", "Reported / Actual", "Actual values from source records, filings, registers or providers."),
            ("ESTIMATED", "Estimated", ""),
            ("MODELED", "Modeled", "Produced by a statistical or analytical model."),
            ("ALLOCATED", "Allocated", "Distributed from a higher-level total by an allocation rule."),
            ("INTERPOLATED", "Interpolated", "Filled between reported points."),
            ("SURVEY_BASED", "Survey-Based", ""),
            ("MIXED", "Mixed", "Combination of the above."),
        ],
        # W2-W4 merge: 50 added (Client Cash Forecast Line); direct user 30 removed (retired, CW-930).
        "members": [("06", "Data Basis"), ("11", "Value Basis"), ("14", "Data Basis"), ("50", "Data Basis")],
        "direct_users": ["18", "24", "27", "28", "29", "31", "34", "35", "36", "42", "43", "44"],
        "value_map": _vm(
            _m("06", "Data Basis", {"Actual": "REPORTED", "Estimated": "ESTIMATED", "Allocated": "ALLOCATED", "Mixed": "MIXED"}),
            _m("11", "Value Basis", {"Reported": "REPORTED", "Estimated": "ESTIMATED", "Modeled": "MODELED",
                                     "Interpolated": "INTERPOLATED"}),
            _m("14", "Data Basis", {"Reported": "REPORTED", "Estimated": "ESTIMATED", "Modeled": "MODELED",
                                    "Survey-Based": "SURVEY_BASED", "Mixed": "MIXED"}),
            _m("50", "Data Basis", {"Reported / Actual": "REPORTED", "Estimated": "ESTIMATED", "Modeled": "MODELED"}),
        ),
    },
    # ------------------------------------------------------------------ 34
    # Data Granularity (steward 14) folded at W5 (CW-175): 14 Dataset.Data Granularity was its only member and no domain cites it
    # (05 left at the W2-W4 merge, CW-140); 14 keeps its local list unchanged. Restore as shared if 05's lever brings the
    # Partner Data Feed Arrangement attribute back. Kept at tag wealth-w4-v0.1.
    # ------------------------------------------------------------------ 35
    # Distribution Strategy (steward 01; MiFID II target market) deleted at the W2-W4 merge (CW-039, CW-908): its last member, 08,
    # left with the wholesale 08 and no direct user cites it. Kept at tag wholesale-v1.0.
    # ------------------------------------------------------------------ 36
    {
        "name": "Flow Direction",
        "steward": "06",
        "definition": "Direction of an asset flow relative to the firm or mandate (an inflow is a purchase or contribution); steward 06 as owner of flows.",
        "source": "Internal (aligned to ICI flow components)",
        "values": [
            ("INFLOW", "Inflow", "Purchase, subscription or client contribution."),
            ("OUTFLOW", "Outflow", "Redemption or client withdrawal."),
            ("NEUTRAL", "Neutral", "No change to firm assets, e.g. share class conversion."),
        ],
        # W2-W4 merge: 08 (Gift / Entertainment Item.Direction, CW-908) and 50 (Money Movement.Movement Direction) added.
        "members": [("06", "Flow Direction"), ("08", "Flow Direction"), ("12", "Flow Direction"), ("50", "Flow Direction")],
        "direct_users": ["18", "24", "26", "27", "29"],
        "value_map": _vm(
            _m("06", "Flow Direction", {"Inflow": "INFLOW", "Outflow": "OUTFLOW", "Neutral": "NEUTRAL"}),
            *[_m(d, "Flow Direction", {"Inflow": "INFLOW", "Outflow": "OUTFLOW"}) for d in ("08", "50")],
            _m("12", "Flow Direction", {"Contribution": "INFLOW", "Withdrawal": "OUTFLOW"}),
        ),
    },
    # ------------------------------------------------------------------ 37
    {
        "name": "Inclusion Type",
        "steward": "09",
        "definition": "Whether a member is included in or carved out of a set (agreement scope, geographic group, guideline rule scope); steward 09.",
        "source": "Internal",
        "values": [
            ("INCLUDE", "Include", ""),
            ("EXCLUDE", "Exclude", "Carve-out from a larger included unit."),
        ],
        # W2-W4 merge: 07 removed (retired, CW-907); 52 added (Guideline Rule Inclusion, CW-118).
        "members": [("05", "Inclusion Type"), ("09", "Membership Type"), ("52", "Inclusion Type")],
        "direct_users": ["33", "34", "39"],
        "value_map": _vm(
            *[_m(d, "Inclusion Type", {"Include": "INCLUDE", "Exclude": "EXCLUDE"}) for d in ("05", "52")],
            _m("09", "Membership Type", {"Include": "INCLUDE", "Exclude": "EXCLUDE"}),
        ),
    },
    # ------------------------------------------------------------------ 38
    {
        "name": "Period Type",
        "steward": "09",
        "definition": "Length or basis of the period over which a measure is aggregated; steward 09 as owner of reporting period definitions.",
        "source": "Internal",
        "values": [
            ("DAY", "Day", ""),
            ("WEEK", "Week", ""),
            ("MONTH", "Month", ""),
            ("QUARTER", "Quarter", ""),
            ("HALF_YEAR", "Half-Year", ""),
            ("YEAR", "Year", "Calendar or fiscal year, per the calendar on the record."),
            ("YEAR_TO_DATE", "Year-to-Date", ""),
            ("ROLLING_12_MONTHS", "Rolling / Trailing 12 Months", ""),
            ("POINT_IN_TIME", "Point in Time", "Snapshot at a date, e.g. asset share."),
        ],
        "members": [("06", "Period Type"), ("09", "Period Type"), ("11", "Period Type")],
        "direct_users": ["18", "19", "20", "23", "25", "32"],   # 30 removed at the W2-W4 merge (retired, CW-930); 24 removed at W5 (no longer cites it, CW-175)
        "value_map": _vm(
            _m("06", "Period Type", {"Day": "DAY", "Week": "WEEK", "Month": "MONTH", "Quarter": "QUARTER", "Year": "YEAR",
                                     "Year-to-Date": "YEAR_TO_DATE", "Rolling 12 Months": "ROLLING_12_MONTHS"}),
            _m("09", "Period Type", {"Day": "DAY", "Week": "WEEK", "Month": "MONTH", "Quarter": "QUARTER",
                                     "Half-Year": "HALF_YEAR", "Year": "YEAR"}),
            _m("11", "Period Type", {"Month": "MONTH", "Quarter": "QUARTER", "Year to Date": "YEAR_TO_DATE",
                                     "Trailing 12 Months": "ROLLING_12_MONTHS", "Calendar Year": "YEAR",
                                     "Point in Time": "POINT_IN_TIME"}),
        ),
    },
    # ------------------------------------------------------------------ 39
    {
        "name": "Reporting Period Basis",
        "steward": "09",
        "definition": "Relative period window for which a measure or return is reported (to-date, rolling, trailing, since inception); steward 09 as owner of reporting period definitions.",
        "source": "Internal (aligned to GIPS 2020 period conventions and Morningstar / LSEG Lipper trailing return periods)",
        "values": [
            ("MTD", "Month to Date", ""),
            ("QTD", "Quarter to Date", ""),
            ("YTD", "Year to Date", "Calendar year to date."),
            ("FYTD", "Fiscal Year to Date", ""),
            ("TRAILING_1M", "Trailing 1 Month", ""),
            ("ROLLING_3M", "Rolling 3 Months", ""),
            ("ROLLING_12M", "Rolling 12 Months", "For flows and activity measures."),
            ("TRAILING_1Y", "1 Year", "Trailing 1-year return."),
            ("TRAILING_3Y", "3 Years", "Trailing 3 years, annualized for returns."),
            ("TRAILING_5Y", "5 Years", "Trailing 5 years, annualized for returns."),
            ("TRAILING_10Y", "10 Years", "Trailing 10 years, annualized for returns."),
            ("SINCE_INCEPTION", "Since Inception", "Annualized where longer than one year."),
            ("CALENDAR_YEARS", "Calendar Years", "Discrete calendar-year periods."),
            ("CUSTOM", "Custom", "Explicit start and end dates."),
        ],
        "members": [("09", "Reporting Period Basis"), ("11", "Return Period"), ("12", "Return Period")],
        "direct_users": ["19", "32"],   # 30 removed at the W2-W4 merge (retired, CW-930)
        "value_map": _vm(
            _m("09", "Reporting Period Basis", {"MTD": "MTD", "QTD": "QTD", "YTD": "YTD", "FYTD": "FYTD", "R3M": "ROLLING_3M",
                                                "R12M": "ROLLING_12M", "1Y": "TRAILING_1Y", "3Y": "TRAILING_3Y", "5Y": "TRAILING_5Y",
                                                "10Y": "TRAILING_10Y", "SI": "SINCE_INCEPTION", "Custom": "CUSTOM"}),
            _m("11", "Return Period", {"1 Month": "TRAILING_1M", "Year to Date": "YTD", "1 Year": "TRAILING_1Y",
                                       "3 Years Annualized": "TRAILING_3Y", "5 Years Annualized": "TRAILING_5Y",
                                       "10 Years Annualized": "TRAILING_10Y", "Since Inception": "SINCE_INCEPTION"}),
            _m("12", "Return Period", {"MTD": "MTD", "QTD": "QTD", "YTD": "YTD", "1Y": "TRAILING_1Y", "3Y": "TRAILING_3Y",
                                       "5Y": "TRAILING_5Y", "10Y": "TRAILING_10Y", "Since Inception": "SINCE_INCEPTION",
                                       "Calendar Years": "CALENDAR_YEARS"}),
        ),
    },
    # ------------------------------------------------------------------ 40
    {
        "name": "SLA Unit",
        "steward": "09",
        "definition": "Unit in which a service level target is expressed; steward 09.",
        "source": "Internal",
        "values": [
            ("PERCENT", "Percent", "Percentage, base not specified."),
            ("PERCENT_OF_DELIVERIES", "% of Deliveries", ""),
            ("PERCENT_OF_RECORDS", "% of Records", ""),
            ("HOURS", "Hours", "Elapsed clock hours."),
            ("BUSINESS_HOURS", "Business Hours", ""),
            ("BUSINESS_DAYS", "Business Days", ""),
            ("CALENDAR_DAYS", "Calendar Days", ""),
            ("BUSINESS_DAYS_AFTER_PERIOD_END", "Business Days After Period End", ""),
        ],
        # W2-W4 merge: 05 removed (SLA Target Unit not carried by the thin IC cut; proposals_w4_05 MEMBERSHIPS_REMOVE, CW-140).
        "members": [("12", "SLA Unit")],
        "direct_users": ["40"],  # Stage 4 (CD-283)
        "value_map": _vm(
            _m("12", "SLA Unit", {"Business Days After Period End": "BUSINESS_DAYS_AFTER_PERIOD_END", "Business Hours": "BUSINESS_HOURS",
                                  "Business Days": "BUSINESS_DAYS", "Calendar Days": "CALENDAR_DAYS", "Percent": "PERCENT"}),
        ),
    },
    # ------------------------------------------------------------------ 41
    {
        "name": "Business Domain",
        "steward": "09",
        "definition": "Data Domain of the CG taxonomy program, plus named sources outside it, used for ownership, consumers and lineage; steward 09 as owner of the code list registry.",
        "source": "CG Taxonomy program (00_Program/Domain_Ownership_and_Conventions.md)",
        "values": [
            # W1b merge (CW-021, CW-914, CW-921): 01 and 02 relabeled to the wealth names; codes kept.
            ("INVESTMENT_PRODUCT", "01 Investment Product & Service Offering", ""),
            ("CLIENT_CUSTOMER", "02 Client & Household", ""),
            # W2-W4 merge: 03, 04, 05, 06, 08, 10 and 13 relabeled to the domains.py names (codes kept, as at W1b; CW-903, CW-904,
            # CW-905, CW-906, CW-908, CW-910, CW-913); 07 and 30 kept with the retired suffix so historical rows resolve; no new
            # row may use them (CW-164, CW-907, CW-930).
            ("SALES", "03 Advisor Organization, Coverage & Supervision", ""),
            ("MARKETING_DIGITAL", "04 Marketing, Digital & Client Engagement", ""),
            ("DISTRIBUTION_AGREEMENTS_PARTNERS", "05 Intermediary & Institutional Distribution", ""),
            ("SALES_TRANSACTIONS_AUM", "06 Client Assets, Flows & Channel Attribution", ""),
            ("COMPENSATION_TERRITORY", "07 Compensation & Territory (retired, CW-907)", "Retired Data Domain; historical rows only."),
            ("DISTRIBUTION_COMPLIANCE", "08 Retail Conduct & Supervision", ""),
            ("SHARED_REFERENCE_DATA", "09 Shared & Enterprise Reference Data", ""),
            ("DISTRIBUTION_FINANCE", "10 Client Revenue, Pricing Economics & Profitability", ""),
            ("MARKET_INTELLIGENCE", "11 Market & Competitive Intelligence", ""),
            ("INSTITUTIONAL_SERVICING", "12 Institutional Client Servicing & Reporting", ""),
            ("INVESTOR_SERVICING", "13 Client Service & Communications", ""),
            ("THIRD_PARTY_DATA", "14 Third-Party Data & Licensing", ""),
            ("EXT_INVESTMENT_MANAGEMENT", "Investment Management (outside program)", "Front office / investment management functions outside the distribution program."),
            ("EXT_ERP_ACCOUNTS_PAYABLE", "ERP / Accounts Payable (outside program)", "Enterprise ERP and accounts payable, e.g. direct supplier invoices."),
            # Added in Stage 1 (proposals_21.py, CD-166): Data Domains 15-21; 22-44 to be added as each stage is drafted
            ("ACCOUNT", "15 Account", ""),
            ("RETIREMENT_PLAN_ADMINISTRATION", "16 Retirement Plan Administration", ""),
            ("INSTRUMENT_ISSUER_REFERENCE", "17 Instrument & Issuer Reference", ""),
            ("PORTFOLIO_IBOR", "18 Portfolio & Investment Book of Record", ""),
            ("FINANCE_ACCOUNTING", "19 Finance & Accounting", ""),
            ("HUMAN_CAPITAL", "20 Human Capital", ""),
            ("DATA_GOVERNANCE_ANALYTICS", "21 Data Governance & Analytics", ""),
            # Added in Stage 4 (CD-283; 41 found the list stopped at 21): Data Domains 22-44
            ("MARKET_DATA_PRICING", "22 Market Data & Pricing", ""),
            ("INVESTMENT_RESEARCH", "23 Investment Research", ""),
            ("PORTFOLIO_MANAGEMENT_CONSTRUCTION", "24 Portfolio Management & Construction", ""),
            ("TRADING_EXECUTION", "25 Portfolio Trading & Execution", ""),  # relabeled at the W1b merge (CW-925); code kept
            ("TRADE_OPERATIONS_SETTLEMENT_COLLATERAL", "26 Trade Operations, Settlement & Collateral", ""),
            ("FUND_ACCOUNTING_VALUATION", "27 Fund Accounting & Valuation", ""),
            ("CUSTODY_ASSET_SERVICING", "28 Fund Custody & Asset Servicing", ""),  # relabeled at the W1b merge (CW-928); code kept
            ("TRANSFER_AGENCY_OPERATIONS", "29 Transfer Agency Operations", ""),
            ("PRIVATE_MARKETS", "30 Private Markets (retired, CW-930)", "Retired Data Domain; historical rows only."),
            ("INVESTMENT_RISK", "31 Investment Risk", ""),
            ("PERFORMANCE_ATTRIBUTION", "32 Performance & Attribution", ""),
            ("INVESTMENT_COMPLIANCE", "33 Investment Compliance", ""),
            ("STEWARDSHIP_SUSTAINABLE_INVESTING", "34 Stewardship & Sustainable Investing", ""),
            ("FUND_GOVERNANCE_REGULATORY_REPORTING", "35 Fund Governance & Regulatory Reporting", ""),
            ("PRODUCT_DEVELOPMENT_LIFECYCLE", "36 Product Development & Lifecycle", ""),
            ("ENTERPRISE_OPERATIONAL_RISK", "37 Enterprise & Operational Risk", ""),
            ("CORPORATE_COMPLIANCE_REGULATORY_AFFAIRS", "38 Corporate Compliance & Regulatory Affairs", ""),
            ("LEGAL_CORPORATE_GOVERNANCE", "39 Legal & Corporate Governance", ""),
            ("PROCUREMENT_VENDOR_MANAGEMENT", "40 Procurement & Vendor Management", ""),
            ("TECHNOLOGY_INFORMATION_SECURITY", "41 Technology & Information Security", ""),
            ("CORPORATE_COMMUNICATIONS_PUBLIC_AFFAIRS", "42 Corporate Communications & Public Affairs", ""),
            ("CORPORATE_TREASURY_CAPITAL", "43 Corporate Treasury & Capital", ""),
            ("WORKPLACE_CORPORATE_SERVICES", "44 Workplace & Corporate Services", ""),
            # Added at the W1b merge (CW-002, CW-914): the wealth Data Domains 45-52 registered in domains.py at W0
            ("FINANCIAL_PLANNING_ADVICE", "45 Financial Planning & Advice", ""),
            ("MANAGED_PORTFOLIOS_REBALANCING", "46 Managed Portfolios & Rebalancing", ""),
            ("PRICING_FEES_BILLING", "47 Pricing, Fees & Billing", ""),
            ("BROKERAGE_ORDERS_EXECUTION", "48 Brokerage Orders & Execution", ""),
            ("CLEARING_SETTLEMENT_CLIENT_CUSTODY", "49 Clearing, Settlement & Client Asset Custody", ""),
            ("MONEY_MOVEMENT_CASH_SWEEP", "50 Money Movement, Cash & Sweep", ""),
            ("TRUST_ESTATE_SERVICES", "51 Trust & Estate Services", ""),
            ("EXTERNAL_MANAGER_SUBADVISER_OVERSIGHT", "52 External Manager & Sub-Adviser Oversight", ""),
        ],
        # W2-W4 merge: 52 added (Oversight Metric Reading.Metric Source Domain, CW-119 as amended by CW-171); 38 added as a direct
        # user (Regulatory Change Impact.Impacted Data Domain; 38 re-points from 'External (09 Shared - Business Domain)').
        "members": [("09", "Business Domain"), ("10", "Source Domain"), ("14", "Consuming Business Domain"), ("52", "Business Domain")],
        "direct_users": ["21", "38", "41"],
        "value_map": _vm(
            # W1b merge (CW-914): 14 now carries the wealth names of 01 and 02 and adds 45; 09 keeps the wholesale labels
            # of 01 and 02 in its local list until its next pass. W2-W4 merge: 09 and 14 take the domains.py labels of 03-13 (merge agent D); their '07 Compensation & Territory' rows were removed with the 07 value of both local lists (CW-907).
            # W5 (CW-175): the 09 local list now carries the 52 numbered labels of the shared list (07 and 30 with the retired
            # suffix); its map is the identity on those labels, built from the values below the list.
            _m("14", "Consuming Business Domain", {"01 Investment Product & Service Offering": "INVESTMENT_PRODUCT",
                                                   "02 Client & Household": "CLIENT_CUSTOMER",
                                                   "45 Financial Planning & Advice": "FINANCIAL_PLANNING_ADVICE"}),
            *[_m(d, n, {
                "03 Advisor Organization, Coverage & Supervision": "SALES",
                "04 Marketing, Digital & Client Engagement": "MARKETING_DIGITAL",
                "05 Intermediary & Institutional Distribution": "DISTRIBUTION_AGREEMENTS_PARTNERS",
                "06 Client Assets, Flows & Channel Attribution": "SALES_TRANSACTIONS_AUM", "08 Retail Conduct & Supervision": "DISTRIBUTION_COMPLIANCE",
                "09 Shared & Enterprise Reference Data": "SHARED_REFERENCE_DATA",
                "10 Client Revenue, Pricing Economics & Profitability": "DISTRIBUTION_FINANCE",
                "11 Market & Competitive Intelligence": "MARKET_INTELLIGENCE",
                "12 Institutional Client Servicing & Reporting": "INSTITUTIONAL_SERVICING",
                "13 Client Service & Communications": "INVESTOR_SERVICING"})
              for d, n in (("14", "Consuming Business Domain"),)],
            _m("14", "Consuming Business Domain", {"Investment Management (outside program)": "EXT_INVESTMENT_MANAGEMENT"}),
            # 10 replaced (proposals_w4_10, CW-159, CW-164): 07 removed, 03, 16, 19, 20, 40, 47-50 and 52 added, wealth labels;
            # 'ERP / Accounts Payable' keeps its short label
            _m("10", "Source Domain", {"03 Advisor Organization, Coverage & Supervision": "SALES",
                                       "04 Marketing, Digital & Client Engagement": "MARKETING_DIGITAL",
                                       "05 Intermediary & Institutional Distribution": "DISTRIBUTION_AGREEMENTS_PARTNERS",
                                       "14 Third-Party Data & Licensing": "THIRD_PARTY_DATA",
                                       "16 Retirement Plan Administration": "RETIREMENT_PLAN_ADMINISTRATION",
                                       "19 Finance & Accounting": "FINANCE_ACCOUNTING", "20 Human Capital": "HUMAN_CAPITAL",
                                       "40 Procurement & Vendor Management": "PROCUREMENT_VENDOR_MANAGEMENT",
                                       "47 Pricing, Fees & Billing": "PRICING_FEES_BILLING",
                                       "48 Brokerage Orders & Execution": "BROKERAGE_ORDERS_EXECUTION",
                                       "49 Clearing, Settlement & Client Asset Custody": "CLEARING_SETTLEMENT_CLIENT_CUSTODY",
                                       "50 Money Movement, Cash & Sweep": "MONEY_MOVEMENT_CASH_SWEEP",
                                       "52 External Manager & Sub-Adviser Oversight": "EXTERNAL_MANAGER_SUBADVISER_OVERSIGHT",
                                       "ERP / Accounts Payable": "EXT_ERP_ACCOUNTS_PAYABLE"}),
            # 52: the domains that compute oversight metrics (subset)
            _m("52", "Business Domain", {"01 Investment Product & Service Offering": "INVESTMENT_PRODUCT",
                                         "11 Market & Competitive Intelligence": "MARKET_INTELLIGENCE", "31 Investment Risk": "INVESTMENT_RISK",
                                         "32 Performance & Attribution": "PERFORMANCE_ATTRIBUTION",
                                         "33 Investment Compliance": "INVESTMENT_COMPLIANCE",
                                         "27 Fund Accounting & Valuation": "FUND_ACCOUNTING_VALUATION",
                                         "52 External Manager & Sub-Adviser Oversight": "EXTERNAL_MANAGER_SUBADVISER_OVERSIGHT"}),
        ),
    },
    # ------------------------------------------------------------------ 42
    {
        "name": "Sentiment",
        "steward": "09",
        "definition": "Sentiment expressed or inferred in an interaction, mention or piece of feedback; steward 09.",
        "source": "Internal",
        "values": [
            ("POSITIVE", "Positive", ""),
            ("NEUTRAL", "Neutral", ""),
            ("NEGATIVE", "Negative", ""),
            ("MIXED", "Mixed", "Both positive and negative elements."),
            ("UNKNOWN", "Unknown", "Not assessed or not determinable."),
        ],
        # W2-W4 merge: ('03', 'Client Sentiment') renamed ('03', 'Sentiment'); 03 adds Mixed (CW-903).
        "members": [("03", "Sentiment"), ("04", "Sentiment")],
        "direct_users": ["23", "42"],  # Stage 2 (CD-210)
        "value_map": _vm(
            _m("03", "Sentiment", {"Positive": "POSITIVE", "Neutral": "NEUTRAL", "Negative": "NEGATIVE", "Mixed": "MIXED", "Unknown": "UNKNOWN"}),
            _m("04", "Sentiment", {"Positive": "POSITIVE", "Neutral": "NEUTRAL", "Negative": "NEGATIVE", "Mixed": "MIXED"}),
        ),
    },
    # ------------------------------------------------------------------ 43
    {
        "name": "Dealing Route",
        "steward": "06",
        "definition": "Order-routing and settlement infrastructure through which fund dealing instructions reach the transfer agent; steward 06 as owner of transactions, with 05 holding the route agreed with each partner and 29 the route of each register order.",
        "source": "Internal (DTCC NSCC services)",  # Calastone, Clearstream Vestima, Euroclear FundSettle, Allfunds and SWIFT dropped (W2-W4 merge)
        "values": [
            ("NSCC_FUNDSERV", "NSCC Fund/SERV", ""),
            ("NSCC_DCCS", "NSCC DCC&S", "Defined Contribution Clearance & Settlement."),
            ("NSCC_CNS_ETF", "NSCC CNS / ETF Portal", "ETF creations and redemptions."),
            # W2-W4 merge: CALASTONE, CLEARSTREAM_VESTIMA, EUROCLEAR_FUNDSETTLE and ALLFUNDS removed (CW-905, CW-906, CW-929);
            # SWIFT_DIRECT removed (29 review ruling: the firm uses no SWIFT route; ISO 20022 stays in Message Standard).
            # OWN_BD_OMNIBUS added with the 29 label (CW-097, CW-140, CW-164).
            ("OWN_BD_OMNIBUS", "Affiliated Broker-Dealer Omnibus", "Aggregated orders from the firm's broker-dealer omnibus account to its transfer agent (CW-097)."),
            ("TA_DIRECT", "TA Direct", "Web, phone, fax, email or mail direct to the TA."),
            ("RECORDKEEPER_FILE", "Recordkeeper File", "Plan-level orders from the firm's or a third-party recordkeeper outside DCC&S."),
            ("SPONSOR_FILE", "Sponsor File", "SMA / UMA sponsor file."),
        ],
        # W2-W4 merge: 29 moved from direct_users to members: it holds a local copy of exactly these values (proposals_w3_29) and may
        # return to direct use at W5.
        "members": [("05", "Dealing Route"), ("06", "Order Entry Channel"), ("29", "Dealing Route")],
        "value_map": _vm(
            # 05 (proposals_w4_05, CW-140): SWIFT Direct dropped and 'Affiliated Broker-Dealer Omnibus' takes the shared label
            # (both 05 merge edits applied by merge agent D)
            _m("05", "Dealing Route", {"NSCC Fund/SERV": "NSCC_FUNDSERV", "NSCC DCC&S": "NSCC_DCCS", "NSCC CNS / ETF Portal": "NSCC_CNS_ETF",
                                       "TA Direct": "TA_DIRECT", "Recordkeeper File": "RECORDKEEPER_FILE",
                                       "Sponsor File": "SPONSOR_FILE", "Affiliated Broker-Dealer Omnibus": "OWN_BD_OMNIBUS"}),
            # 06 (proposals_w4_06) and 29 (proposals_w3_29) carry the shared labels
            *[_m(d, n, {"NSCC Fund/SERV": "NSCC_FUNDSERV", "NSCC DCC&S": "NSCC_DCCS", "NSCC CNS / ETF Portal": "NSCC_CNS_ETF",
                        "Affiliated Broker-Dealer Omnibus": "OWN_BD_OMNIBUS", "TA Direct": "TA_DIRECT",
                        "Recordkeeper File": "RECORDKEEPER_FILE", "Sponsor File": "SPONSOR_FILE"})
              for d, n in (("06", "Order Entry Channel"), ("29", "Dealing Route"))],
        ),
    },
    # ------------------------------------------------------------------ 44
    {
        "name": "Performance Fee Basis",
        # W2-W4 merge (program-lead ruling, 12 and 47 fix passes): steward 12 -> 32, overriding the CW-054 and CW-140 wording (47).
        "steward": "32",
        "definition": "Basis on which a return is computed or shown (GIPS 2020 gross-of-fees and net-of-fees); steward 32 as master of returns.",
        "source": "GIPS 2020 (gross-of-fees / net-of-fees returns)",
        "values": [
            ("GROSS_OF_FEES", "Gross of Fees", ""),
            ("NET_OF_FEES", "Net of Fees", ""),
            ("GROSS_AND_NET", "Gross and Net", ""),
        ],
        # W2-W4 merge: ('03', 'Performance Basis') removed with the wholesale 03 (CW-903); 08 (Performance Presentation.Gross / Net
        # Presentation, CW-908) and 47 (Performance Fee Terms and Calculation, CW-054) added. 32, now the steward, stays a direct user
        # (Client Fee Bases Produced, Personal Return Fee Basis cite 'Shared: Performance Fee Basis').
        "members": [("08", "Performance Fee Basis"), ("12", "Fee Basis"), ("47", "Performance Fee Basis")],
        "direct_users": ["32"],
        "value_map": _vm(*[_m(d, n, {"Gross of Fees": "GROSS_OF_FEES", "Net of Fees": "NET_OF_FEES",
                                      "Gross and Net": "GROSS_AND_NET"})
                           for d, n in (("08", "Performance Fee Basis"), ("12", "Fee Basis"), ("47", "Performance Fee Basis"))]),
    },
    # ------------------------------------------------------------------ 45
    # CRS Entity Classification (steward 02) deleted at the W2-W4 merge (CW-039): retired at W1 (CW-901, CW-902) with no member or
    # direct user left. Kept at tag wholesale-v1.0.
    # ------------------------------------------------------------------ 46
    {
        "name": "Reconciliation Status",
        "steward": "06",
        "definition": "Outcome status of a reconciliation run or item; steward 06 as owner of data quality and reconciliation (its Break Status lifecycle is a member).",
        "source": "Internal",
        "values": [
            ("RECONCILED", "Reconciled", ""),
            ("RECONCILED_WITHIN_TOLERANCE", "Reconciled within Tolerance", ""),
            ("BREAK_OPEN", "Break Open", "Unexplained differences / exceptions open."),
            ("BREAK_EXPLAINED", "Break Explained", "Differences explained and accepted, pending correction."),
            ("NOT_RECONCILED", "Not Reconciled", "Reconciliation not yet performed."),
        ],
        # W2-W4 merge: 06 Break Status (Break.Break Status, CW-140), 16 (Plan Conversion), 47 (Fee Calculation Run) and 49 (Stock
        # Record Reconciliation) added.
        "members": [("06", "Break Status"), ("10", "Reconciliation Status"), ("13", "Reconciliation Status"),
                    ("16", "Reconciliation Status"), ("47", "Reconciliation Status"), ("49", "Reconciliation Status")],
        "direct_users": ["18", "19", "26", "27", "28", "29", "43"],
        "value_map": _vm(
            # 06 Break lifecycle: Investigating has no own code (still open)
            _m("06", "Break Status", {"Open": "BREAK_OPEN", "Investigating": "BREAK_OPEN", "Resolved": "RECONCILED",
                                      "Accepted (Within Materiality)": "RECONCILED_WITHIN_TOLERANCE"}),
            _m("10", "Reconciliation Status", {"Reconciled": "RECONCILED", "Reconciled within Tolerance": "RECONCILED_WITHIN_TOLERANCE",
                                               "Break Open": "BREAK_OPEN", "Break Explained": "BREAK_EXPLAINED"}),
            # 16, 47 and 49 copy all five shared values
            *[_m(d, "Reconciliation Status", {"Reconciled": "RECONCILED", "Reconciled within Tolerance": "RECONCILED_WITHIN_TOLERANCE",
                                              "Break Open": "BREAK_OPEN", "Break Explained": "BREAK_EXPLAINED",
                                              "Not Reconciled": "NOT_RECONCILED"}) for d in ("16", "47", "49")],
            _m("13", "Reconciliation Status", {"Reconciled": "RECONCILED", "Exceptions Open": "BREAK_OPEN",
                                               "Not Reconciled": "NOT_RECONCILED"}),
        ),
    },
    # ------------------------------------------------------------------ Stage 2 (CD-209); re-cut for the wealth model (CW-004, W1 merge)
    {
        "name": "Business Line",
        "steward": "09",
        "definition": "Enterprise business line of the wealth manager (CW-004): the eight lines of the business capability map whose clients, books, products or records a row belongs to; steward 09. Codes are the CW-004 two-letter codes. Institutional mandates take the line of the service they are sold under (IA); seed books are flagged by 18 Proprietary Capital Indicator.",
        "source": "Internal (Business_Capability_Map business lines, CW-004)",
        # W1 merge (CW-004, CW-909): the six wholesale values of CD-209 (MUTUAL_FUND, ETF, COLLECTIVE_INVESTMENT_TRUST,
        # SEPARATELY_MANAGED_ACCOUNT, PRIVATE_MARKETS, INSURANCE_DEDICATED_FUND) are replaced by the eight wealth lines.
        "values": [
            ("DB", "Direct brokerage and self-directed investing", ""),
            ("DA", "Digital advice", ""),
            ("HA", "Human and hybrid advice", ""),
            ("PF", "Proprietary funds and ETFs", "Own mutual funds, ETFs and CITs."),
            ("WR", "Workplace retirement recordkeeping", ""),
            ("IA", "Institutional advisory", "OCIO, institutional mandates in own funds and separate accounts."),
            ("IC", "Intermediary channel", ""),
            ("TR", "Personal trust services", "Optional line."),
        ],
        # 01, 02 and 15 registered at the W1 merge (CW-901, CW-902, CW-915); 01 is no longer renamed 'Client Segment' (LOCAL_RENAMES).
        # W2-W4 merge (CW-004, CW-140): 03, 04, 05, 06, 10, 11, 12, 13, 45 and 50 registered; each copies the eight codes as values.
        # 45 is also a direct user (program-lead ruling): it re-points to 'Shared: Business Line' and drops its copy.
        "members": [("18", "Business Line"), ("21", "Business Line"), ("01", "Business Line"), ("02", "Business Line"),
                    ("15", "Business Line"), ("03", "Business Line"), ("04", "Business Line"), ("05", "Business Line"),
                    ("06", "Business Line"), ("10", "Business Line"), ("11", "Business Line"), ("12", "Business Line"),
                    ("13", "Business Line"), ("50", "Business Line")],
        "direct_users": ["24", "27", "31", "32", "33", "35", "36", "37", "38", "39", "40", "41", "45"],
        "value_map": _vm(
            # W1b merge (CW-918, CW-921): 18 and 21 now hold the eight CW-004 codes, as 02 and 15 (identity map below). The
            # wholesale values (Mutual Fund, ETF, Collective Investment Trust, Separately Managed Account, Private Markets,
            # Insurance-Dedicated Fund; 21 also Institutional Mandate and Proprietary / Seed) left both local lists.
            # 01 labels are title case; 02 and 15 hold the two-letter codes as values (program-lead ruling, CW-004).
            _m("01", "Business Line", {"Direct Brokerage and Self-Directed Investing": "DB", "Digital Advice": "DA",
                                       "Human and Hybrid Advice": "HA", "Proprietary Funds and ETFs": "PF",
                                       "Workplace Retirement Recordkeeping": "WR", "Institutional Advisory": "IA",
                                       "Intermediary Channel": "IC", "Personal Trust Services": "TR"}),
            *[_m(d, "Business Line", {c: c for c in ("DB", "DA", "HA", "PF", "WR", "IA", "IC", "TR")})
              for d in ("02", "15", "18", "21", "03", "04", "05", "06", "10", "11", "12", "13", "50")],
        ),
    },
    # ---- Stage 3 (2026-10-06, CD-242): lists two domains already shared value for value. The older domain is a member
    #      (its local list is replaced at build); the Stage 3 domain is a direct user (its local copy was removed).
    {
        "name": "Committee Decision Outcome",
        "steward": "24",
        "definition": "Outcome of a decision item of a management committee (investment committee, product governance committee).",
        "source": "Internal (24 Committee Decision Outcome; Approved, Approved with Conditions and Rejected map one to one to Approval Status)",
        "values": [
            ("APPROVED", "Approved", ""),
            ("APPROVED_WITH_CONDITIONS", "Approved with Conditions", ""),
            ("REJECTED", "Rejected", ""),
            ("DEFERRED", "Deferred", "Carried to a later meeting."),
            ("NOTED", "Noted", "Recorded for information; no decision required."),
        ],
        "members": [("24", "Committee Decision Outcome")],
        "direct_users": ["36", "39"],
        "value_map": _m("24", "Committee Decision Outcome", {"Approved": "APPROVED", "Approved with Conditions": "APPROVED_WITH_CONDITIONS",
                                                            "Rejected": "REJECTED", "Deferred": "DEFERRED", "Noted": "NOTED"}),
    },
    {
        "name": "Compliance Check Outcome",
        "steward": "33",
        "definition": "Outcome of a pre-trade compliance check of an order, block order, proposed trade or deal. Mastered on 33 Check Subject Member; 25 Trade Order Event holds a Derived copy (CD-180, CD-221).",
        "source": "Internal (33 Investment Compliance; values as first drafted by 25)",
        "values": [
            ("PASSED", "Passed", ""),
            ("PASSED_WITH_WARNING", "Passed with Warning", "Soft limit or warning raised."),
            ("FAILED_BLOCKED", "Failed - Blocked", "Hard breach; order cannot be released."),
            ("FAILED_OVERRIDE_APPROVED", "Failed - Override Approved", "Breach overridden with approval."),
            ("NOT_CHECKED", "Not Checked", "Instrument or order type not covered."),
        ],
        "members": [("25", "Compliance Check Outcome")],
        "direct_users": ["33"],
        "value_map": _m("25", "Compliance Check Outcome", {"Passed": "PASSED", "Passed with Warning": "PASSED_WITH_WARNING",
                                                          "Failed - Blocked": "FAILED_BLOCKED",
                                                          "Failed - Override Approved": "FAILED_OVERRIDE_APPROVED",
                                                          "Not Checked": "NOT_CHECKED"}),
    },
    {
        "name": "Return Methodology",
        "steward": "32",
        "definition": "How a performance return is calculated (GIPS). 'Both' is valid only on a presentation or profile choice, never on a return row.",
        "source": "GIPS 2020",
        "values": [
            ("TIME_WEIGHTED", "Time-Weighted", ""),
            ("MONEY_WEIGHTED_IRR", "Money-Weighted (IRR)", ""),
            ("BOTH", "Both", "Presentation or profile choice only (12, 32 profile); never on a 32 return row."),
        ],
        "members": [("12", "Return Methodology")],
        "direct_users": ["32"],
        "value_map": _m("12", "Return Methodology", {"Time-Weighted": "TIME_WEIGHTED", "Money-Weighted (IRR)": "MONEY_WEIGHTED_IRR", "Both": "BOTH"}),
    },
    {
        "name": "Net Fee Treatment",
        "steward": "32",
        "definition": "Fee basis deducted in a net-of-fees return (GIPS: actual, model or highest fee).",
        "source": "GIPS 2020",
        "values": [
            ("ACTUAL_FEES", "Actual Fees", ""),
            ("MODEL_FEES", "Model Fees", ""),
            ("HIGHEST_FEE", "Highest Fee", ""),
        ],
        "members": [("12", "Net Fee Treatment")],
        "direct_users": ["32"],
        "value_map": _m("12", "Net Fee Treatment", {"Actual Fees": "ACTUAL_FEES", "Model Fees": "MODEL_FEES", "Highest Fee": "HIGHEST_FEE"}),
    },
    {
        "name": "Breach Type",
        "steward": "33",
        "definition": "Cause of an investment breach. Mastered on 33 Investment Breach; 12 Breach Notification holds a Derived copy (CD-222).",
        "source": "Internal (33 Investment Compliance; values as first drafted by 12)",
        "values": [
            ("ACTIVE", "Active", "Caused by a firm action, e.g. a trade."),
            ("PASSIVE", "Passive", "Caused by market movement or a corporate action."),
            ("TECHNICAL", "Technical", "Data or coding error, no actual exposure."),
        ],
        "members": [("12", "Breach Type")],
        "direct_users": ["33"],
        "value_map": _m("12", "Breach Type", {"Active": "ACTIVE", "Passive": "PASSIVE", "Technical": "TECHNICAL"}),
    },
    {
        "name": "Cure Action",
        "steward": "33",
        "definition": "How an investment breach was cured. Mastered on 33 Investment Breach; 12 Breach Notification holds a Derived copy (CD-222).",
        "source": "Internal (33 Investment Compliance; values as first drafted by 12)",
        "values": [
            ("SELL_DOWN", "Sell Down", ""),
            ("PURCHASE", "Purchase", ""),
            ("CLIENT_WAIVER", "Client Waiver", ""),
            ("GUIDELINE_AMENDED", "Guideline Amended", ""),
            ("SELF_CURED_BY_MARKET", "Self-Cured by Market", ""),
        ],
        "members": [("12", "Cure Action")],
        "direct_users": ["33"],
        "value_map": _m("12", "Cure Action", {"Sell Down": "SELL_DOWN", "Purchase": "PURCHASE", "Client Waiver": "CLIENT_WAIVER",
                                             "Guideline Amended": "GUIDELINE_AMENDED", "Self-Cured by Market": "SELF_CURED_BY_MARKET"}),
    },
    # ------------------------------------------------------------------ Stage 4 (CD-284): DORA ICT Service Type (Annex III, CD-268) retired at
    #      the W1b merge (CW-039): 40's member left with the ICT register (CW-940), 41 ICT Service Type is a firm-defined local
    #      list (CW-941) and 14 no longer cites it (CW-914). Kept at tag wholesale-v1.0.
    # ------------------------------------------------------------------ Stage 4 (CD-284): financed (34) and operational (44) emissions (CD-281)
    {
        "name": "GHG Scope Category",
        "steward": "34",
        "definition": "GHG Protocol scope, and Scope 3 category where known, of an emissions indicator or record. Scope 3 category 15 (financed emissions) is 34's and never appears on a 44 operational record.",
        "source": "GHG Protocol Corporate Standard, Scope 2 Guidance and Scope 3 Standard",
        "values": [
            ("SCOPE_1", "Scope 1", ""),
            ("SCOPE_2_LOCATION_BASED", "Scope 2 (Location-Based)", ""),
            ("SCOPE_2_MARKET_BASED", "Scope 2 (Market-Based)", ""),
            ("SCOPE_3", "Scope 3", ""),
            ("SCOPE_3_CATEGORY_1_PURCHASED_GOODS_AND_SERVICES", "Scope 3 Category 1 - Purchased Goods and Services", ""),
            ("SCOPE_3_CATEGORY_3_FUEL_AND_ENERGY_RELATED_ACTIVITIES", "Scope 3 Category 3 - Fuel- and Energy-Related Activities", ""),
            ("SCOPE_3_CATEGORY_5_WASTE_GENERATED_IN_OPERATIONS", "Scope 3 Category 5 - Waste Generated in Operations", ""),
            ("SCOPE_3_CATEGORY_6_BUSINESS_TRAVEL", "Scope 3 Category 6 - Business Travel", ""),
            ("SCOPE_3_CATEGORY_7_EMPLOYEE_COMMUTING", "Scope 3 Category 7 - Employee Commuting", ""),
            ("NOT_APPLICABLE", "Not Applicable", ""),
        ],
        "members": [("34", "Sustainability Indicator Scope"), ("44", "GHG Scope Category")],
        "value_map": _vm(
            _m("34", "Sustainability Indicator Scope", {"Scope 1": "SCOPE_1", "Scope 2 (Location-Based)": "SCOPE_2_LOCATION_BASED", "Scope 2 (Market-Based)": "SCOPE_2_MARKET_BASED", "Scope 3": "SCOPE_3", "Not Applicable": "NOT_APPLICABLE"}),
            _m("44", "GHG Scope Category", {"Scope 1": "SCOPE_1", "Scope 2 (Location-Based)": "SCOPE_2_LOCATION_BASED", "Scope 2 (Market-Based)": "SCOPE_2_MARKET_BASED", "Scope 3 Category 1 - Purchased Goods and Services": "SCOPE_3_CATEGORY_1_PURCHASED_GOODS_AND_SERVICES", "Scope 3 Category 3 - Fuel- and Energy-Related Activities": "SCOPE_3_CATEGORY_3_FUEL_AND_ENERGY_RELATED_ACTIVITIES", "Scope 3 Category 5 - Waste Generated in Operations": "SCOPE_3_CATEGORY_5_WASTE_GENERATED_IN_OPERATIONS", "Scope 3 Category 6 - Business Travel": "SCOPE_3_CATEGORY_6_BUSINESS_TRAVEL", "Scope 3 Category 7 - Employee Commuting": "SCOPE_3_CATEGORY_7_EMPLOYEE_COMMUTING"}),
        ),
    },
    # ------------------------------------------------------------------ Stage 4 (CD-284): fund and manager awards (11) and corporate award entries (42), CD-272
    {
        "name": "Award Outcome",
        "steward": "11",
        "definition": "Result of an award entry.",
        "source": "Internal",
        "values": [
            ("WINNER", "Winner", ""),
            ("HIGHLY_COMMENDED", "Highly Commended", ""),
            ("SHORTLISTED_FINALIST", "Shortlisted / Finalist", ""),
            ("NOT_PLACED", "Not Placed", ""),
        ],
        "members": [("11", "Award Outcome"), ("42", "Award Result")],
        "value_map": _vm(
            _m("11", "Award Outcome", {"Winner": "WINNER", "Highly Commended": "HIGHLY_COMMENDED", "Shortlisted / Finalist": "SHORTLISTED_FINALIST", "Not Placed": "NOT_PLACED"}),
            _m("42", "Award Result", {"Winner": "WINNER", "Highly Commended": "HIGHLY_COMMENDED", "Shortlisted / Finalist": "SHORTLISTED_FINALIST", "Not Placed": "NOT_PLACED"}),
        ),
    },
    # ------------------------------------------------------------------ Stage 4 (CD-284): supplier performance (40) and data-vendor performance (14), CD-260
    {
        "name": "Performance Rating",
        "steward": "40",
        "definition": "Rating of a supplier's performance over a review period.",
        "source": "Internal",
        "values": [
            ("EXCEEDS_EXPECTATIONS", "Exceeds Expectations", ""),
            ("MEETS_EXPECTATIONS", "Meets Expectations", ""),
            ("PARTIALLY_MEETS", "Partially Meets", ""),
            ("DOES_NOT_MEET", "Does Not Meet", ""),
        ],
        "members": [("14", "Performance Rating"), ("40", "Supplier Performance Rating")],
        "value_map": _vm(
            _m("14", "Performance Rating", {"Exceeds Expectations": "EXCEEDS_EXPECTATIONS", "Meets Expectations": "MEETS_EXPECTATIONS", "Partially Meets": "PARTIALLY_MEETS", "Does Not Meet": "DOES_NOT_MEET"}),
            _m("40", "Supplier Performance Rating", {"Exceeds Expectations": "EXCEEDS_EXPECTATIONS", "Meets Expectations": "MEETS_EXPECTATIONS", "Partially Meets": "PARTIALLY_MEETS", "Does Not Meet": "DOES_NOT_MEET"}),
        ),
    },
    # ================================================================== Step 5 (CD-286, 2026-10-07): shared lists from the deferred
    # candidates of stage1-4_consolidation_notes §2 and the proposals_17..44 SHARED_CANDIDATES. Steward = the domain that defines
    # the concept (09 for generic vocabularies). Members keep their local list in the content module (replaced at build);
    # direct users' local copies and 'External (NN list)' citations were re-pointed to 'Shared: <name>'. See step5_consolidation_notes §1.
    {
        "name": 'Vehicle Type',
        "steward": '01',
        "definition": 'Legal and operational form of a collective investment vehicle or managed mandate.',
        "source": 'FIBO CIV / openfunds',
        "values": [
            # W2-W4 merge (CW-164, CW-930, CW-039): PRIVATE_FUND_DRAWDOWN and EVERGREEN_PRIVATE_FUND removed with 30;
            # POOLED_PENSION_UNIT_LINKED_FUND removed (UK; left 01 at W1); TENDER_OFFER_FUND and FEEDER_FUND added (01, CW-038).
            ('OPEN_ENDED_FUND', 'Open-Ended Fund', 'Mutual fund (open-end management company)'),
            ('EXCHANGE_TRADED_FUND', 'Exchange-Traded Fund', ''),
            ('CLOSED_END_FUND', 'Closed-End Fund', ''),
            ('INTERVAL_FUND', 'Interval Fund', 'US periodic repurchase fund (Rule 23c-3)'),
            ('TENDER_OFFER_FUND', 'Tender-Offer Fund', 'Closed-end fund offering periodic repurchases by tender offer'),
            ('FEEDER_FUND', 'Feeder Fund', 'Fund that gives qualified clients access to an underlying private fund (CW-038)'),
            ('COLLECTIVE_INVESTMENT_TRUST', 'Collective Investment Trust', 'US bank-maintained CIT'),
            ('UNIT_INVESTMENT_TRUST', 'Unit Investment Trust', ''),
            ('SEPARATELY_MANAGED_ACCOUNT', 'Separately Managed Account', 'SMA / wrap program account'),
            ('SEGREGATED_MANDATE', 'Segregated Mandate', 'Institutional segregated account'),
            ('MODEL_PORTFOLIO', 'Model Portfolio', ''),
        ],
        # W2-W4 merge: 52 added (External Manager Strategy.Vehicles Available, CW-117).
        "members": [('01', 'Vehicle Type'), ('52', 'Vehicle Type')],
        "direct_users": ['17', '36'],
        "value_map": _vm(
            # 01 (CW-901): Tender-Offer Fund and Feeder Fund mapped at the W2-W4 re-cut (CW-164)
            _m('01', 'Vehicle Type', {'Open-Ended Fund': 'OPEN_ENDED_FUND', 'Exchange-Traded Fund': 'EXCHANGE_TRADED_FUND', 'Closed-End Fund': 'CLOSED_END_FUND', 'Interval Fund': 'INTERVAL_FUND', 'Tender-Offer Fund': 'TENDER_OFFER_FUND', 'Feeder Fund': 'FEEDER_FUND', 'Collective Investment Trust': 'COLLECTIVE_INVESTMENT_TRUST', 'Unit Investment Trust': 'UNIT_INVESTMENT_TRUST', 'Separately Managed Account': 'SEPARATELY_MANAGED_ACCOUNT', 'Segregated Mandate': 'SEGREGATED_MANDATE', 'Model Portfolio': 'MODEL_PORTFOLIO'}),
            # 52 subset; its two private-fund values have no equivalent since the re-cut and leave the 52 copy (merge-prep ruling 2)
            _m('52', 'Vehicle Type', {'Open-Ended Fund': 'OPEN_ENDED_FUND', 'Exchange-Traded Fund': 'EXCHANGE_TRADED_FUND', 'Collective Investment Trust': 'COLLECTIVE_INVESTMENT_TRUST', 'Separately Managed Account': 'SEPARATELY_MANAGED_ACCOUNT', 'Model Portfolio': 'MODEL_PORTFOLIO', 'Closed-End Fund': 'CLOSED_END_FUND', 'Interval Fund': 'INTERVAL_FUND', 'Unit Investment Trust': 'UNIT_INVESTMENT_TRUST'}),
        ),
    },
    {
        "name": 'Regulatory Regime',
        "steward": '01',
        "definition": 'Regulatory regime under which a fund or vehicle is authorized or exempt.',
        "source": 'Investment Company Act of 1940 / Internal',
        # W1 merge (CW-901, CW-917, CW-039): UCITS, UK_UCITS, EU_AIF, ELTIF, EU_MMF, UK_NURS, UK_QIS, LUX_SIF, LUX_RAIF and
        # IRISH_QIAIF removed; CAYMAN_REGULATED_MUTUAL_FUND replaced by one value for non-US regulated funds held by the
        # international funds (17's note): the firm sponsors US vehicles only, but its funds may hold foreign regulated funds.
        "values": [
            ('US_1940_ACT_REGISTERED', 'US 1940 Act Registered', ''),
            ('US_PRIVATE_FUND_3_C_1', 'US Private Fund 3(c)(1)', ''),
            ('US_PRIVATE_FUND_3_C_7', 'US Private Fund 3(c)(7)', ''),
            ('US_BANK_CIT', 'US Bank CIT', 'OCC / state banking regulation'),
            ('NON_US_REGULATED_FUND', 'Non-US Regulated Fund', 'Fund authorized under a non-US regime (e.g. UCITS, Cayman CIMA), held as an instrument by the international funds; not a regime of a firm-sponsored product'),
        ],
        # W2-W4 merge: unchanged. W5 (CW-175): NON_US_REGULATED_FUND stays under the investment-universe principle (the firm
        # sponsors US vehicles only, but its funds and client accounts may hold foreign regulated funds as instruments; 17 uses it).
        "members": [('01', 'Regulatory Regime')],
        "direct_users": ['17', '36'],
        "value_map": _vm(
            _m('01', 'Regulatory Regime', {'US 1940 Act Registered': 'US_1940_ACT_REGISTERED', 'US Private Fund 3(c)(1)': 'US_PRIVATE_FUND_3_C_1', 'US Private Fund 3(c)(7)': 'US_PRIVATE_FUND_3_C_7', 'US Bank CIT': 'US_BANK_CIT'}),
        ),
    },
    {
        "name": 'Distribution Policy',
        "steward": '01',
        "definition": 'Whether a share class accumulates or distributes income.',
        "source": 'openfunds',
        "values": [
            ('ACCUMULATING', 'Accumulating', ''),
            ('DISTRIBUTING', 'Distributing', ''),
            # W1 merge (CW-901, CW-039): DISTRIBUTING_GROSS_INCOME removed (fees charged to capital, UK and Irish income-share practice).
        ],
        "members": [('01', 'Distribution Policy')],
        "direct_users": ['17', '36'],
        "value_map": _vm(
            _m('01', 'Distribution Policy', {'Accumulating': 'ACCUMULATING', 'Distributing': 'DISTRIBUTING'}),
        ),
    },
    {
        "name": 'MMF Type',
        "steward": '01',
        "definition": 'Money market fund type under SEC Rule 2a-7.',
        "source": 'SEC Rule 2a-7',
        # W1 merge (CW-901, CW-917, CW-039): EU MMFR values PUBLIC_DEBT_CNAV, LVNAV, SHORT_TERM_VNAV, STANDARD_VNAV removed.
        "values": [
            ('GOVERNMENT_MMF', 'Government MMF', 'Rule 2a-7 government money market fund'),
            ('PRIME_MMF_INSTITUTIONAL', 'Prime MMF - Institutional', 'Rule 2a-7 institutional prime fund'),
            ('PRIME_MMF_RETAIL', 'Prime MMF - Retail', 'Rule 2a-7 retail prime fund'),
            ('TAX_EXEMPT_MMF', 'Tax-Exempt MMF', 'Rule 2a-7 tax-exempt (municipal) fund'),
        ],
        "members": [('01', 'MMF Type')],
        "direct_users": ['17'],
        "value_map": _vm(
            _m('01', 'MMF Type', {'Government MMF': 'GOVERNMENT_MMF', 'Prime MMF - Institutional': 'PRIME_MMF_INSTITUTIONAL', 'Prime MMF - Retail': 'PRIME_MMF_RETAIL', 'Tax-Exempt MMF': 'TAX_EXEMPT_MMF'}),
        ),
    },
    {
        "name": 'Asset Class',
        "steward": '01',
        "definition": "Product and strategy asset class (EFAMA EFC aligned); the instrument-level classification is 'Instrument Asset Class' (17).",
        "source": 'Internal',
        "values": [
            ('EQUITY', 'Equity', ''),
            ('FIXED_INCOME', 'Fixed Income', ''),
            ('MULTI_ASSET', 'Multi-Asset', ''),
            ('MONEY_MARKET', 'Money Market', ''),
            ('REAL_ESTATE', 'Real Estate', ''),
            ('PRIVATE_EQUITY', 'Private Equity', ''),
            ('PRIVATE_CREDIT', 'Private Credit', ''),
            ('INFRASTRUCTURE', 'Infrastructure', ''),
            ('HEDGE_ABSOLUTE_RETURN', 'Hedge / Absolute Return', ''),
            ('COMMODITIES', 'Commodities', ''),
            ('OTHER', 'Other', ''),
        ],
        "members": [('01', 'Asset Class'), ('52', 'Asset Class')],   # 52 added at the W2-W4 merge (External Manager Strategy)
        "direct_users": ['36'],
        "value_map": _vm(
            _m('52', 'Asset Class', {'Equity': 'EQUITY', 'Fixed Income': 'FIXED_INCOME', 'Multi-Asset': 'MULTI_ASSET', 'Money Market': 'MONEY_MARKET', 'Real Estate': 'REAL_ESTATE', 'Private Equity': 'PRIVATE_EQUITY', 'Private Credit': 'PRIVATE_CREDIT', 'Infrastructure': 'INFRASTRUCTURE', 'Hedge / Absolute Return': 'HEDGE_ABSOLUTE_RETURN', 'Commodities': 'COMMODITIES', 'Other': 'OTHER'}),
            _m('01', 'Asset Class', {'Equity': 'EQUITY', 'Fixed Income': 'FIXED_INCOME', 'Multi-Asset': 'MULTI_ASSET', 'Money Market': 'MONEY_MARKET', 'Real Estate': 'REAL_ESTATE', 'Private Equity': 'PRIVATE_EQUITY', 'Private Credit': 'PRIVATE_CREDIT', 'Infrastructure': 'INFRASTRUCTURE', 'Hedge / Absolute Return': 'HEDGE_ABSOLUTE_RETURN', 'Commodities': 'COMMODITIES', 'Other': 'OTHER'}),
        ),
    },
    {
        "name": 'Hedging Type',
        "steward": '01',
        "definition": 'Currency or exposure hedging applied to a share class.',
        "source": 'openfunds / ESMA',
        "values": [
            ('UNHEDGED', 'Unhedged', ''),
            ('NAV_HEDGED', 'NAV Hedged', 'Base currency hedged to class currency'),
            ('PORTFOLIO_HEDGED', 'Portfolio Hedged', 'Look-through hedge of underlying exposures'),
            ('DURATION_HEDGED', 'Duration Hedged', 'Permitted for some regimes only'),
        ],
        "members": [('01', 'Hedging Type')],
        # W2-W4 merge: direct user 36 removed (Share Class Specification.Proposed Hedging Type removed, CW-170).
        "value_map": _vm(
            _m('01', 'Hedging Type', {'Unhedged': 'UNHEDGED', 'NAV Hedged': 'NAV_HEDGED', 'Portfolio Hedged': 'PORTFOLIO_HEDGED', 'Duration Hedged': 'DURATION_HEDGED'}),
        ),
    },
    {
        "name": 'Share Class Type',
        "steward": '01',
        "definition": 'Commercial type of a share class.',
        "source": 'Internal / openfunds',
        "values": [
            ('RETAIL', 'Retail', ''),
            ('INSTITUTIONAL', 'Institutional', ''),
            ('FRONT_END_LOAD', 'Front-End Load', 'Intermediary class with a front-end sales charge (IC line); added at W1 (CW-901)'),
            ('LEVEL_LOAD', 'Level Load', 'Intermediary class with an asset-based sales charge and no front-end load (IC line); added at W1 (CW-901)'),
            ('CLEAN', 'Clean', 'No commission / rebate'),
            ('FOUNDER_SEED', 'Founder / Seed', ''),
            # PLATFORM_SUPER_CLEAN removed at W1 (CW-901: UK RDR platform class)
            ('EMPLOYEE', 'Employee', ''),
            ('ETF_SHARE_CLASS', 'ETF Share Class', ''),
            ('INTERNAL', 'Internal', 'Reserved for in-house fund-of-funds / mandates'),
        ],
        "members": [('01', 'Share Class Type')],
        "direct_users": ['36'],
        "value_map": _vm(
            _m('01', 'Share Class Type', {'Retail': 'RETAIL', 'Institutional': 'INSTITUTIONAL', 'Front-End Load': 'FRONT_END_LOAD', 'Level Load': 'LEVEL_LOAD', 'Clean': 'CLEAN', 'Founder / Seed': 'FOUNDER_SEED', 'Employee': 'EMPLOYEE', 'ETF Share Class': 'ETF_SHARE_CLASS', 'Internal': 'INTERNAL'}),
        ),
    },
    {
        "name": 'Return Type',
        "steward": '01',
        "definition": 'Treatment of income in a return or index level: price, net total or gross total return.',
        "source": 'Internal',
        "values": [
            ('PRICE_RETURN', 'Price Return', ''),
            ('NET_TOTAL_RETURN', 'Net Total Return', ''),
            ('GROSS_TOTAL_RETURN', 'Gross Total Return', ''),
        ],
        "members": [('01', 'Return Type'), ('22', 'Index Level Variant')],
        "direct_users": ['32'],
        "value_map": _vm(
            _m('01', 'Return Type', {'Price Return': 'PRICE_RETURN', 'Net Total Return': 'NET_TOTAL_RETURN', 'Gross Total Return': 'GROSS_TOTAL_RETURN'}),
            _m('22', 'Index Level Variant', {'Price Return': 'PRICE_RETURN', 'Net Total Return': 'NET_TOTAL_RETURN', 'Gross Total Return': 'GROSS_TOTAL_RETURN'}),
        ),
    },
    {
        "name": 'Measurement Basis',
        "steward": '01',
        "definition": 'Basis in which an investment restriction or coded compliance limit is measured.',
        "source": 'Internal',
        "values": [
            ('PCT_OF_NAV', '% of NAV', ''),
            ('PCT_OF_MARKET_VALUE', '% of Market Value', ''),
            ('PCT_OF_ISSUER_CAPITAL', '% of Issuer Capital', ''),
            ('ABSOLUTE_AMOUNT', 'Absolute Amount', ''),
            ('COUNT', 'Count', ''),
            ('PCT_OF_TOTAL_ASSETS', '% of Total Assets', 'ICA Section 5(b)(1), Rule 2a-7 - Stage 3, CD-241'),  # W5: IRC 817(h) dropped (insurance-dedicated scope removed, CW-165)
            ('DAYS', 'Days', 'Weighted average maturity or life (Rule 2a-7) - Stage 3, CD-241'),
            ('RATIO', 'Ratio', 'Asset coverage (ICA Section 18) or leverage multiple - Stage 3, CD-241'),
            ('RATING_NOTCH', 'Rating Notch', 'Minimum credit quality tests - Stage 3, CD-241'),
            ('PCT_OF_COMMITMENTS', '% of Commitments', 'Private fund document limits on aggregate commitments - Stage 3, CD-241'),
            # W2-W4 merge (CW-930, CW-164): PCT_OF_CAPITAL removed with 30 (no own-fund restriction uses it); PCT_OF_COMMITMENTS
            # stays for drawdown feeder funds (lever: remove with registered feeders).
        ],
        "members": [('01', 'Measurement Basis'), ('46', 'Measurement Basis')],   # 46 added at the W2-W4 merge
        "direct_users": ['33'],
        "value_map": _vm(
            _m('01', 'Measurement Basis', {'% of NAV': 'PCT_OF_NAV', '% of Market Value': 'PCT_OF_MARKET_VALUE', '% of Issuer Capital': 'PCT_OF_ISSUER_CAPITAL', 'Absolute Amount': 'ABSOLUTE_AMOUNT', 'Count': 'COUNT', '% of Total Assets': 'PCT_OF_TOTAL_ASSETS', 'Days': 'DAYS', 'Ratio': 'RATIO', 'Rating Notch': 'RATING_NOTCH', '% of Commitments': 'PCT_OF_COMMITMENTS'}),
            _m('46', 'Measurement Basis', {'% of Market Value': 'PCT_OF_MARKET_VALUE', 'Absolute Amount': 'ABSOLUTE_AMOUNT', 'Count': 'COUNT'}),
        ),
    },
    {
        "name": 'Restriction Limit Type',
        "steward": '01',
        "definition": "Whether an investment restriction or coded compliance limit is a minimum, maximum, range or prohibition. Distinct from 25 'Limit Type' (counterparty trading limit measures).",
        "source": 'Internal',
        "values": [
            ('MINIMUM', 'Minimum', ''),
            ('MAXIMUM', 'Maximum', ''),
            ('RANGE', 'Range', ''),
            ('PROHIBITION', 'Prohibition', ''),
        ],
        "members": [('01', 'Limit Type'), ('52', 'Restriction Limit Type')],   # 52 added at the W2-W4 merge (Oversight Metric Threshold)
        "direct_users": ['33'],
        "value_map": _vm(
            _m('01', 'Limit Type', {'Minimum': 'MINIMUM', 'Maximum': 'MAXIMUM', 'Range': 'RANGE', 'Prohibition': 'PROHIBITION'}),
            _m('52', 'Restriction Limit Type', {'Minimum': 'MINIMUM', 'Maximum': 'MAXIMUM', 'Range': 'RANGE'}),
        ),
    },
    {
        "name": 'Identifier Status',
        "steward": '09',
        "definition": 'Status of an identifier held for a party, account or instrument.',
        "source": 'Internal',
        "values": [
            ('ACTIVE', 'Active', ''),
            ('INACTIVE', 'Inactive', ''),
            ('RETIRED', 'Retired', 'Superseded or no longer issued'),
            ('UNVERIFIED', 'Unverified', ''),
        ],
        "members": [('02', 'Identifier Status'), ('15', 'Identifier Status')],
        "direct_users": ['17'],
        "value_map": _vm(
            _m('02', 'Identifier Status', {'Active': 'ACTIVE', 'Inactive': 'INACTIVE', 'Retired': 'RETIRED', 'Unverified': 'UNVERIFIED'}),
            _m('15', 'Identifier Status', {'Active': 'ACTIVE', 'Inactive': 'INACTIVE', 'Retired': 'RETIRED', 'Unverified': 'UNVERIFIED'}),
        ),
    },
    {
        "name": 'Instrument Asset Class',
        "steward": '17',
        "definition": 'Level 1 of the firm asset-class taxonomy for instruments, used for policy, allocation and pricing scopes.',
        "source": 'Internal (firm asset-class taxonomy, level 1)',
        "values": [
            ('EQUITY', 'Equity', ''),
            ('FIXED_INCOME', 'Fixed Income', ''),
            ('CASH_AND_MONEY_MARKET', 'Cash & Money Market', ''),
            ('MULTI_ASSET', 'Multi-Asset', 'Funds whose look-through spans asset classes'),
            ('DERIVATIVE', 'Derivative', 'Pending review with Investment Risk: may be replaced by the underlying asset class'),
            ('CURRENCY_FX', 'Currency / FX', 'FX forwards and currency overlays'),
            ('PRIVATE_EQUITY', 'Private Equity', ''),
            ('PRIVATE_CREDIT', 'Private Credit', ''),
            ('REAL_ASSETS', 'Real Assets', ''),
            ('COMMODITY', 'Commodity', ''),
        ],
        "members": [('17', 'Instrument Asset Class'), ('46', 'Instrument Asset Class')],   # 46 added at the W2-W4 merge (CW-046)
        "direct_users": ['22', '24'],
        "value_map": _vm(
            _m('46', 'Instrument Asset Class', {'Equity': 'EQUITY', 'Fixed Income': 'FIXED_INCOME', 'Cash & Money Market': 'CASH_AND_MONEY_MARKET', 'Multi-Asset': 'MULTI_ASSET', 'Real Assets': 'REAL_ASSETS', 'Commodity': 'COMMODITY'}),
            _m('17', 'Instrument Asset Class', {'Equity': 'EQUITY', 'Fixed Income': 'FIXED_INCOME', 'Cash & Money Market': 'CASH_AND_MONEY_MARKET', 'Multi-Asset': 'MULTI_ASSET', 'Derivative': 'DERIVATIVE', 'Currency / FX': 'CURRENCY_FX', 'Private Equity': 'PRIVATE_EQUITY', 'Private Credit': 'PRIVATE_CREDIT', 'Real Assets': 'REAL_ASSETS', 'Commodity': 'COMMODITY'}),
        ),
    },
    {
        "name": 'Instrument Type',
        "steward": '17',
        "definition": 'Type of instrument in the security master, aligned to ISO 10962 CFI categories and groups.',
        "source": 'Internal',
        "values": [
            ('EQUITY_SHARE', 'Equity Share', 'CFI E: ES common, EP preferred, EL limited partnership units; subtype in Equity Share Type'),
            ('DEPOSITARY_RECEIPT', 'Depositary Receipt', 'CFI ED (on equities) or DD (on debt)'),
            ('RIGHT', 'Right', 'CFI RS / RP'),
            ('WARRANT', 'Warrant', 'CFI RW'),
            ('GOVERNMENT_BOND', 'Government Bond', 'CFI DB'),
            ('MUNICIPAL_BOND', 'Municipal Bond', 'CFI DN'),
            ('CORPORATE_BOND', 'Corporate Bond', 'CFI DB / DT'),
            ('CONVERTIBLE_BOND', 'Convertible Bond', 'CFI DC'),
            ('MONEY_MARKET_INSTRUMENT', 'Money Market Instrument', "CFI DY: commercial paper, bills, bankers' acceptances; brokered CDs take Certificate of Deposit"),
            ('CERTIFICATE_OF_DEPOSIT', 'Certificate of Deposit', 'Brokered certificate of deposit of an FDIC-insured bank; CFI as allocated with the CUSIP (added at W1, CW-917, CW-039)'),
            ('MORTGAGE_BACKED_SECURITY', 'Mortgage-Backed Security', 'CFI DG'),
            ('ASSET_BACKED_SECURITY', 'Asset-Backed Security', 'CFI DA'),
            ('COLLATERALIZED_LOAN_OBLIGATION', 'Collateralized Loan Obligation', 'CFI DA'),
            ('THIRD_PARTY_FUND', 'Third-Party Fund', 'CFI C (CI, CE, CB and others); vehicle in Fund Vehicle Type'),
            ('OWN_FUND_SHARE_CLASS', 'Own Fund Share Class', 'Own share class held in client accounts (49) or by own portfolios (18); references 01 SHC-; vehicle in Fund Vehicle Type (Derived copy 01)'),
            ('MUNICIPAL_FUND_SECURITY', 'Municipal Fund Security', '529 college savings or ABLE program portfolio (MSRB Rule D-12); subtype in Municipal Fund Security Type (added at W1, CW-917, CW-039)'),
            ('LISTED_FUTURE', 'Listed Future', 'CFI F'),
            ('LISTED_OPTION', 'Listed Option', 'CFI O; one instrument per OCC series'),
            ('OTC_DERIVATIVE_PRODUCT', 'OTC Derivative Product', 'CFI S, H or J (and M where applicable); UPI level'),
            ('LOAN', 'Loan', 'Syndicated or direct loan; subtype in Private Asset Type'),
            ('PRIVATE_EQUITY_HOLDING', 'Private Equity Holding', 'Subtype in Private Asset Type'),
            ('REAL_ASSET', 'Real Asset', 'Subtype in Private Asset Type'),
            ('LP_FUND_INTEREST', 'LP Fund Interest', 'Limited partner interest in an underlying fund'),
            ('CASH_DEPOSIT', 'Cash / Deposit', ''),
            ('OTHER', 'Other', ''),
        ],
        "members": [('17', 'Instrument Type')],
        "direct_users": ['22', '24', '26'],
        "value_map": _vm(
            _m('17', 'Instrument Type', {'Equity Share': 'EQUITY_SHARE', 'Depositary Receipt': 'DEPOSITARY_RECEIPT', 'Right': 'RIGHT', 'Warrant': 'WARRANT', 'Government Bond': 'GOVERNMENT_BOND', 'Municipal Bond': 'MUNICIPAL_BOND', 'Corporate Bond': 'CORPORATE_BOND', 'Convertible Bond': 'CONVERTIBLE_BOND', 'Money Market Instrument': 'MONEY_MARKET_INSTRUMENT', 'Certificate of Deposit': 'CERTIFICATE_OF_DEPOSIT', 'Mortgage-Backed Security': 'MORTGAGE_BACKED_SECURITY', 'Asset-Backed Security': 'ASSET_BACKED_SECURITY', 'Collateralized Loan Obligation': 'COLLATERALIZED_LOAN_OBLIGATION', 'Third-Party Fund': 'THIRD_PARTY_FUND', 'Own Fund Share Class': 'OWN_FUND_SHARE_CLASS', 'Municipal Fund Security': 'MUNICIPAL_FUND_SECURITY', 'Listed Future': 'LISTED_FUTURE', 'Listed Option': 'LISTED_OPTION', 'OTC Derivative Product': 'OTC_DERIVATIVE_PRODUCT', 'Loan': 'LOAN', 'Private Equity Holding': 'PRIVATE_EQUITY_HOLDING', 'Real Asset': 'REAL_ASSET', 'LP Fund Interest': 'LP_FUND_INTEREST', 'Cash / Deposit': 'CASH_DEPOSIT', 'Other': 'OTHER'}),
        ),
    },
    {
        "name": 'Business Day Convention',
        "steward": '09',
        "definition": 'ISDA business day convention for adjusting a date that falls on a non-business day.',
        "source": 'ISDA 2006 Definitions',
        "values": [
            ('FOLLOWING', 'Following', ''),
            ('MODIFIED_FOLLOWING', 'Modified Following', ''),
            ('PRECEDING', 'Preceding', ''),
            ('MODIFIED_PRECEDING', 'Modified Preceding', ''),
            ('UNADJUSTED', 'Unadjusted', ''),
        ],
        "members": [('09', 'Business Day Convention'), ('17', 'Business Day Convention')],
        "value_map": _vm(
            _m('09', 'Business Day Convention', {'Following': 'FOLLOWING', 'Modified Following': 'MODIFIED_FOLLOWING', 'Preceding': 'PRECEDING', 'Modified Preceding': 'MODIFIED_PRECEDING', 'Unadjusted': 'UNADJUSTED'}),
            _m('17', 'Business Day Convention', {'Following': 'FOLLOWING', 'Modified Following': 'MODIFIED_FOLLOWING', 'Preceding': 'PRECEDING', 'Modified Preceding': 'MODIFIED_PRECEDING', 'No Adjustment': 'UNADJUSTED'}),
        ),
    },
    {
        "name": 'Day Count Convention',
        "steward": '17',
        "definition": 'ISDA / ICMA day count fraction for accruing interest.',
        "source": 'ISDA definitions / FINOS CDM',
        "values": [
            ('30_360', '30/360', 'Bond basis'),
            ('30E_360', '30E/360', 'Eurobond basis'),
            ('ACT_360', 'ACT/360', ''),
            ('ACT_365_FIXED', 'ACT/365 (Fixed)', ''),
            ('ACT_ACT_ICMA', 'ACT/ACT (ICMA)', ''),
            ('ACT_ACT_ISDA', 'ACT/ACT (ISDA)', ''),
            ('ACT_365L', 'ACT/365L', ''),
            ('OTHER', 'Other', ''),
        ],
        "members": [('17', 'Day Count Convention')],
        "direct_users": ['26'],
        "value_map": _vm(
            _m('17', 'Day Count Convention', {'30/360': '30_360', '30E/360': '30E_360', 'ACT/360': 'ACT_360', 'ACT/365 (Fixed)': 'ACT_365_FIXED', 'ACT/ACT (ICMA)': 'ACT_ACT_ICMA', 'ACT/ACT (ISDA)': 'ACT_ACT_ISDA', 'ACT/365L': 'ACT_365L', 'Other': 'OTHER'}),
        ),
    },
    {
        "name": 'Credit Outlook',
        "steward": '17',
        "definition": "Outlook attached to an agency credit rating or an internal credit assessment. 'Not Assigned' applies to agency ratings only.",
        "source": 'Agency definitions',
        "values": [
            ('POSITIVE', 'Positive', ''),
            ('STABLE', 'Stable', ''),
            ('NEGATIVE', 'Negative', ''),
            ('DEVELOPING', 'Developing', ''),
            ('NOT_ASSIGNED', 'Not Assigned', ''),
        ],
        "members": [('17', 'Credit Rating Outlook')],
        "direct_users": ['23'],
        "value_map": _vm(
            _m('17', 'Credit Rating Outlook', {'Positive': 'POSITIVE', 'Stable': 'STABLE', 'Negative': 'NEGATIVE', 'Developing': 'DEVELOPING', 'Not Assigned': 'NOT_ASSIGNED'}),
        ),
    },
    {
        "name": 'Lot Relief Method',
        "steward": '18',
        # definition widened at the W2-W4 merge to client accounts (46 managed sales, 49 Client Lot Relief; steward 18)
        "definition": "Method by which tax lots are relieved on disposal, in a managed portfolio's own book (18) or in a client account (46 managed account sales, 49 Client Lot Relief); not the account holder's cost basis election (15 Cost Basis Method).",
        "source": 'IRS Publication 550 / Treas. Reg. 1.1012-1',  # HMRC CG51500 dropped at the W1b merge (CW-918, CW-039)
        "values": [
            ('FIFO', 'FIFO', 'First in, first out'),
            ('LIFO', 'LIFO', 'Last in, first out'),
            ('HIGH_COST', 'High Cost', 'Highest-cost lots first'),
            ('LOW_COST', 'Low Cost', 'Lowest-cost lots first'),
            ('SPECIFIC_LOT_IDENTIFICATION', 'Specific Lot Identification', 'Lots named on the trade'),
            ('TAX_OPTIMIZED', 'Tax-Optimized', 'Minimizes tax given gain budget and holding periods'),
            ('AVERAGE_COST', 'Average Cost', 'Average cost of all units'),
            # W1b merge (CW-918, CW-039): UK_SHARE_IDENTIFICATION_RULES_TCGA_1992_S105_106A removed with its 18 value.
        ],
        "members": [('18', 'Lot Relief Method'), ('46', 'Lot Relief Method'), ('49', 'Lot Relief Method')],   # 46, 49 added at the W2-W4 merge
        "direct_users": ['24'],
        "value_map": _vm(
            *[_m(d, 'Lot Relief Method', {'FIFO': 'FIFO', 'LIFO': 'LIFO', 'High Cost': 'HIGH_COST', 'Low Cost': 'LOW_COST', 'Specific Lot Identification': 'SPECIFIC_LOT_IDENTIFICATION', 'Tax-Optimized': 'TAX_OPTIMIZED', 'Average Cost': 'AVERAGE_COST'}) for d in ('18', '46', '49')],
        ),
    },
    {
        "name": 'Holding View',
        "steward": '18',
        "definition": 'View of the book of record (18 investment book of record, 49 client holdings) a holding or measure is taken from.',
        "source": 'Internal',
        "values": [
            ('START_OF_DAY', 'Start of Day', 'Official opening view'),
            ('INTRADAY', 'Intraday', "Real-time view including today's activity"),
            ('END_OF_DAY', 'End of Day', "Closing view after the day's bookings"),
        ],
        "members": [('18', 'Holding View'), ('49', 'Holding View')],   # 49 added at the W2-W4 merge (Client Holding View, CW-101)
        "direct_users": ['31'],
        "value_map": _vm(
            *[_m(d, 'Holding View', {'Start of Day': 'START_OF_DAY', 'Intraday': 'INTRADAY', 'End of Day': 'END_OF_DAY'}) for d in ('18', '49')],
        ),
    },
    {
        "name": 'Accounting Basis',
        "steward": '19',
        "definition": 'Accounting framework or basis under which a ledger, book or set of statements is kept.',
        "source": 'Internal',
        "values": [
            ('US_GAAP', 'US GAAP', ''),
            # W1b merge (CW-919, CW-039): IFRS_EU_ADOPTED, UK_ADOPTED_IFRS, FRS_102_UK_GAAP, LUX_GAAP, IRISH_GAAP_FRS_102 removed.
            ('TAX_BASIS', 'Tax Basis', 'Book kept on a tax basis'),
            ('REGULATORY', 'Regulatory', 'Basis prescribed for a regulatory return'),
        ],
        # W2-W4 merge (CW-910): ('10', 'Accounting Framework') replaced by ('10', 'Accounting Basis'), which carries the shared values
        # exactly; the four EU/UK values that mapped to None since W1b left 10.
        "members": [('19', 'Accounting Basis'), ('10', 'Accounting Basis')],
        "direct_users": ['27'],
        "value_map": _vm(
            *[_m(d, 'Accounting Basis', {'US GAAP': 'US_GAAP', 'Tax Basis': 'TAX_BASIS', 'Regulatory': 'REGULATORY'}) for d in ('19', '10')],
        ),
    },
    {
        "name": 'Plan Version Status',
        "steward": '19',
        "definition": 'Workflow status of a budget or forecast version.',
        "source": 'Internal',
        "values": [
            ('DRAFT', 'Draft', ''),
            ('SUBMITTED', 'Submitted', ''),
            ('APPROVED', 'Approved', ''),
            ('LOCKED', 'Locked', ''),
            ('SUPERSEDED', 'Superseded', 'Added in 19'),
        ],
        "members": [('19', 'Plan Version Status'), ('10', 'Plan Version Status')],
        "value_map": _vm(
            _m('19', 'Plan Version Status', {'Draft': 'DRAFT', 'Submitted': 'SUBMITTED', 'Approved': 'APPROVED', 'Locked': 'LOCKED', 'Superseded': 'SUPERSEDED'}),
            _m('10', 'Plan Version Status', {'Draft': 'DRAFT', 'Submitted': 'SUBMITTED', 'Approved': 'APPROVED', 'Locked': 'LOCKED'}),
        ),
    },
    {
        "name": 'Financial Plan Type',
        "steward": '19',
        "definition": "Type of budget or forecast (annual budget, rolling forecast, long-range plan, scenario). Distinct from 07 'Incentive Plan Type'.",
        "source": 'Internal',
        "values": [
            ('ANNUAL_BUDGET', 'Annual Budget', ''),
            ('ROLLING_FORECAST', 'Rolling Forecast', ''),
            ('LONG_RANGE_PLAN', 'Long-Range Plan', ''),
            ('SCENARIO', 'Scenario', 'Off-cycle scenario plan; the scenario itself is Plan Scenario'),
        ],
        "members": [('19', 'Plan Type'), ('10', 'Plan Type')],
        "value_map": _vm(
            _m('19', 'Plan Type', {'Annual Budget': 'ANNUAL_BUDGET', 'Rolling Forecast': 'ROLLING_FORECAST', 'Long-Range Plan': 'LONG_RANGE_PLAN', 'Scenario': 'SCENARIO'}),
            _m('10', 'Plan Type', {'Annual Budget': 'ANNUAL_BUDGET', 'Rolling Forecast': 'ROLLING_FORECAST', 'Long-Range Plan': 'LONG_RANGE_PLAN', 'Scenario': 'SCENARIO'}),
        ),
    },
    {
        "name": 'Plan Scenario',
        "steward": '19',
        "definition": 'Scenario of a budget or forecast version. Distinct from 31 risk stress scenarios.',
        "source": 'Internal',
        "values": [
            ('BASE', 'Base', ''),
            ('UPSIDE', 'Upside', ''),
            ('DOWNSIDE', 'Downside', ''),
            ('MARKET_STRESS', 'Market Stress', ''),
            ('CAPITAL_AND_LIQUIDITY_STRESS', 'Capital and Liquidity Stress', 'Added in 19: e.g. broker-dealer net capital and liquidity stress testing'),  # ICARA dropped at the W1b merge (CW-919)
        ],
        "members": [('19', 'Plan Scenario'), ('10', 'Scenario')],
        "value_map": _vm(
            _m('19', 'Plan Scenario', {'Base': 'BASE', 'Upside': 'UPSIDE', 'Downside': 'DOWNSIDE', 'Market Stress': 'MARKET_STRESS', 'Capital and Liquidity Stress': 'CAPITAL_AND_LIQUIDITY_STRESS'}),
            _m('10', 'Scenario', {'Base': 'BASE', 'Upside': 'UPSIDE', 'Downside': 'DOWNSIDE', 'Market Stress': 'MARKET_STRESS'}),
        ),
    },
    {
        "name": 'Job Level',
        "steward": '20',
        "definition": 'Grade band of a job in the firm job architecture.',
        "source": 'Internal (firm leveling framework)',
        "values": [
            ('ANALYST', 'Analyst', ''),
            ('ASSOCIATE', 'Associate', ''),
            ('VICE_PRESIDENT', 'Vice President', ''),
            ('DIRECTOR', 'Director', ''),
            ('MANAGING_DIRECTOR', 'Managing Director', ''),
            ('EXECUTIVE', 'Executive', 'Executive committee'),
        ],
        "members": [('20', 'Job Level')],
        "direct_users": ['44'],
        "value_map": _vm(
            _m('20', 'Job Level', {'Analyst': 'ANALYST', 'Associate': 'ASSOCIATE', 'Vice President': 'VICE_PRESIDENT', 'Director': 'DIRECTOR', 'Managing Director': 'MANAGING_DIRECTOR', 'Executive': 'EXECUTIVE'}),
        ),
    },
    {
        "name": 'Metric Direction',
        "steward": '21',
        "definition": 'Which way a change in a metric or indicator value is favorable.',
        "source": 'Internal',
        "values": [
            ('HIGHER_IS_BETTER', 'Higher Is Better', ''),
            ('LOWER_IS_BETTER', 'Lower Is Better', ''),
            ('TARGET_RANGE', 'Target Range', 'Favorable within a target band'),
            ('NEUTRAL', 'Neutral', 'Informational'),
        ],
        "members": [('21', 'Metric Direction')],
        "direct_users": ['37'],
        "value_map": _vm(
            _m('21', 'Metric Direction', {'Higher Is Better': 'HIGHER_IS_BETTER', 'Lower Is Better': 'LOWER_IS_BETTER', 'Target Range': 'TARGET_RANGE', 'Neutral': 'NEUTRAL'}),
        ),
    },
    {
        "name": 'Approved Price Basis',
        "steward": '22',
        "definition": 'How an approved price or value was reached.',
        "source": 'Internal',
        "values": [
            ('SELECTED_OBSERVATION', 'Selected Observation', 'Observation chosen under the source hierarchy'),
            ('PRICE_OVERRIDE', 'Price Override', 'Approved manual price'),
            ('FAIR_VALUE_DETERMINATION', 'Fair Value Determination', 'Value of an approved determination'),
            ('FAIR_VALUE_FACTOR', 'Fair Value Factor', 'Local close multiplied by an applied fair value factor'),
            ('OWN_FUND_NAV', 'Own Fund NAV', '27 final unswung NAV per share of an own fund (row rule, CD-167)'),
            ('PRIOR_PRICE_CARRIED_FORWARD', 'Prior Price Carried Forward', 'Market closed or no new price'),
            ('AMORTIZED_COST', 'Amortized Cost', 'Money market instruments valued at amortized cost under Rule 2a-7'),
            ('CONTRACT_VALUE', 'Contract Value', 'Stable value contracts held by CITs and stable value funds'),  # reworded at the W1b merge (CW-922)
        ],
        "members": [('22', 'Approved Price Basis')],
        "direct_users": ['18'],
        "value_map": _vm(
            _m('22', 'Approved Price Basis', {'Selected Observation': 'SELECTED_OBSERVATION', 'Price Override': 'PRICE_OVERRIDE', 'Fair Value Determination': 'FAIR_VALUE_DETERMINATION', 'Fair Value Factor': 'FAIR_VALUE_FACTOR', 'Own Fund NAV': 'OWN_FUND_NAV', 'Prior Price Carried Forward': 'PRIOR_PRICE_CARRIED_FORWARD', 'Amortized Cost': 'AMORTIZED_COST', 'Contract Value': 'CONTRACT_VALUE'}),
        ),
    },
    {
        "name": 'Measure Unit',
        "steward": '22',
        "definition": 'Unit in which a threshold, input, shock, exposure or measure value is expressed.',
        "source": 'Internal',
        "values": [
            ('PERCENT', 'Percent', ''),
            ('BASIS_POINTS', 'Basis Points', ''),
            ('DAYS', 'Days', ''),
            ('PRICE_UNITS', 'Price Units', 'Same unit as the price'),
            ('MULTIPLE', 'Multiple', 'Times, e.g. EV/EBITDA'),
            ('YEARS', 'Years', ''),
            ('RATIO', 'Ratio', ''),
            ('DELTA', 'Delta', 'Option delta, -1 to 1'),
            ('CURRENCY_AMOUNT', 'Currency Amount', ''),
            # Added at the W2-W4 merge (52 fix-pass ruling 4, steward 22)
            ('PERCENTILE', 'Percentile', 'Rank in a peer group, 1 = best or cheapest'),
            ('COUNT', 'Count', 'Number of records'),
        ],
        # W2-W4 merge: 11 (Fee Benchmark Study.Measure Unit) and 52 (Oversight Metric Reading.Metric Unit) added; direct user 30
        # removed (retired, CW-930).
        "members": [('22', 'Measure Unit'), ('11', 'Measure Unit'), ('52', 'Measure Unit')],
        "direct_users": ['31'],
        "value_map": _vm(
            _m('11', 'Measure Unit', {'Percent': 'PERCENT', 'Basis Points': 'BASIS_POINTS', 'Currency Amount': 'CURRENCY_AMOUNT'}),
            _m('52', 'Measure Unit', {'Percent': 'PERCENT', 'Basis Points': 'BASIS_POINTS', 'Ratio': 'RATIO', 'Years': 'YEARS', 'Percentile': 'PERCENTILE', 'Count': 'COUNT'}),
            _m('22', 'Measure Unit', {'Percent': 'PERCENT', 'Basis Points': 'BASIS_POINTS', 'Days': 'DAYS', 'Price Units': 'PRICE_UNITS', 'Multiple': 'MULTIPLE', 'Years': 'YEARS', 'Ratio': 'RATIO', 'Delta': 'DELTA', 'Currency Amount': 'CURRENCY_AMOUNT'}),
        ),
    },
    {
        "name": 'Rate Tenor',
        "steward": '22',
        "definition": 'Market tenor of an FX rate, reference rate fixing, curve point, surface expiry, shock or loan rate.',
        "source": 'Internal (market tenor conventions)',
        "values": [
            ('ON', 'ON', 'Overnight'),
            ('TN', 'TN', 'Tomorrow-next'),
            ('SN', 'SN', 'Spot-next'),
            ('SPOT', 'Spot', ''),
            ('1W', '1W', ''),
            ('2W', '2W', ''),
            ('1M', '1M', ''),
            ('2M', '2M', ''),
            ('3M', '3M', ''),
            ('6M', '6M', ''),
            ('9M', '9M', ''),
            ('1Y', '1Y', 'One year (also written 12M)'),
            ('2Y', '2Y', ''),
            ('3Y', '3Y', ''),
            ('4Y', '4Y', ''),
            ('5Y', '5Y', ''),
            ('7Y', '7Y', ''),
            ('10Y', '10Y', ''),
            ('15Y', '15Y', ''),
            ('20Y', '20Y', ''),
            ('25Y', '25Y', ''),
            ('30Y', '30Y', ''),
            ('40Y', '40Y', ''),
            ('50Y', '50Y', ''),
        ],
        "members": [('22', 'Rate Tenor')],
        "direct_users": ['31', '43'],
        "value_map": _vm(
            _m('22', 'Rate Tenor', {'ON': 'ON', 'TN': 'TN', 'SN': 'SN', 'Spot': 'SPOT', '1W': '1W', '2W': '2W', '1M': '1M', '2M': '2M', '3M': '3M', '6M': '6M', '9M': '9M', '1Y': '1Y', '2Y': '2Y', '3Y': '3Y', '4Y': '4Y', '5Y': '5Y', '7Y': '7Y', '10Y': '10Y', '15Y': '15Y', '20Y': '20Y', '25Y': '25Y', '30Y': '30Y', '40Y': '40Y', '50Y': '50Y'}),
        ),
    },
    {
        "name": 'Meeting Format',
        "steward": '09',
        "definition": 'How a meeting was held (in person, virtual, hybrid, telephonic).',
        "source": 'Internal',
        "values": [
            ('IN_PERSON', 'In Person', ''),
            ('VIRTUAL', 'Virtual', 'Video conference'),
            ('HYBRID', 'Hybrid', 'Some members in person'),
            ('TELEPHONIC', 'Telephonic', ''),
            ('NOT_APPLICABLE_WRITTEN_CONSENT', 'Not Applicable - Written Consent', ''),
        ],
        "members": [('35', 'Meeting Format'), ('23', 'Meeting Channel')],
        "value_map": _vm(
            _m('35', 'Meeting Format', {'In Person': 'IN_PERSON', 'Virtual': 'VIRTUAL', 'Hybrid': 'HYBRID', 'Telephonic': 'TELEPHONIC', 'Not Applicable - Written Consent': 'NOT_APPLICABLE_WRITTEN_CONSENT'}),
            _m('23', 'Meeting Channel', {'In Person': 'IN_PERSON', 'Video': 'VIRTUAL', 'Telephone': 'TELEPHONIC'}),
        ),
    },
    {
        "name": 'Order Side',
        "steward": '25',
        "definition": 'Side of an order, proposed trade or personal transaction (FIX Side, tag 54, plus internal values).',
        "source": 'FIX Protocol Side (54) / Internal',
        "values": [
            ('BUY', 'Buy', 'FIX 1'),
            ('SELL', 'Sell', 'FIX 2'),
            ('SELL_SHORT', 'Sell Short', 'FIX 5'),
            ('SELL_SHORT_EXEMPT', 'Sell Short Exempt', 'FIX 6; Regulation SHO exemption'),
            ('BUY_TO_COVER', 'Buy to Cover', 'Internal; purchase that closes a short position'),
            ('SUBSCRIBE', 'Subscribe', 'FIX D; subscription to a third-party fund held by the portfolio, not a 29 fund order'),
            # Added at the W2-W4 merge for 38 personal trading (38 fix pass; Personal Trade Side folded into this list)
            ('EXERCISE', 'Exercise', 'Internal; exercise of an option or other right, reported as a personal transaction (SEC Rule 204A-1)'),
            ('GIFT_TRANSFER', 'Gift / Transfer', 'Internal; securities given, received or transferred without a trade (SEC Rule 204A-1)'),
        ],
        # W2-W4 merge: 46 (Trade Proposal side, subset) and 48 (client orders, executions, confirmations) added.
        "members": [('25', 'Order Side'), ('46', 'Order Side'), ('48', 'Order Side')],
        "direct_users": ['24', '38'],  # 38: personal trading sides (W2-W4 merge, merge agent D)
        "value_map": _vm(
            _m('46', 'Order Side', {'Buy': 'BUY', 'Sell': 'SELL'}),
            _m('48', 'Order Side', {'Buy': 'BUY', 'Sell': 'SELL', 'Sell Short': 'SELL_SHORT', 'Sell Short Exempt': 'SELL_SHORT_EXEMPT', 'Buy to Cover': 'BUY_TO_COVER', 'Subscribe': 'SUBSCRIBE'}),
            _m('25', 'Order Side', {'Buy': 'BUY', 'Sell': 'SELL', 'Sell Short': 'SELL_SHORT', 'Sell Short Exempt': 'SELL_SHORT_EXEMPT', 'Buy to Cover': 'BUY_TO_COVER', 'Subscribe': 'SUBSCRIBE', 'Exercise': 'EXERCISE', 'Gift / Transfer': 'GIFT_TRANSFER'}),
        ),
    },
    {
        "name": 'Regulatory Report Status',
        # W1b merge (CW-925, CW-926, CW-928): steward 25 -> 28, the remaining member; 25 Transaction Report Status left with the
        # MiFIR Transaction Report. CORRECTED and CANCELED are kept for a later trade report status (26).
        "steward": '28',
        "definition": 'Status of a regulatory transaction or securities loan report submitted to a swap data repository, a registered securities association or a regulator.',
        "source": 'Internal / SEC Rule 10c-1a / CFTC Part 45',
        "values": [
            ('PENDING', 'Pending', ''),
            ('SUBMITTED', 'Submitted', ''),
            ('ACCEPTED', 'Accepted', ''),
            ('REJECTED', 'Rejected', 'Rejected by the receiving repository, association or regulator'),
            ('CORRECTED', 'Corrected', 'Canceled and resubmitted'),
            ('CANCELED', 'Canceled', ''),
            ('NOT_REQUIRED', 'Not Required', 'No report is due for the record (e.g. an exempt securities loan).'),
        ],
        # W2-W4 merge: 48 (Regulatory Trade Report, CAT Reportable Event) and 49 (Loan Reporting Detail) added.
        "members": [('28', 'Loan Report Status'), ('48', 'Regulatory Report Status'), ('49', 'Regulatory Report Status')],
        "value_map": _vm(
            *[_m(d, 'Regulatory Report Status', {'Pending': 'PENDING', 'Submitted': 'SUBMITTED', 'Accepted': 'ACCEPTED', 'Rejected': 'REJECTED', 'Corrected': 'CORRECTED', 'Canceled': 'CANCELED', 'Not Required': 'NOT_REQUIRED'}) for d in ('48', '49')],
            _m('28', 'Loan Report Status', {'Pending': 'PENDING', 'Submitted': 'SUBMITTED', 'Accepted': 'ACCEPTED', 'Rejected': 'REJECTED', 'Not Required': 'NOT_REQUIRED'}),
        ),
    },
    {
        "name": 'Collateral Type',
        "steward": '26',
        "definition": 'Asset category of eligible, posted or received collateral (OTC margin, repo, securities lending and fully paid client securities lending).',
        "source": 'ISDA / BCBS-IOSCO eligible collateral categories / ISLA',
        "values": [
            ('CASH', 'Cash', ''),
            ('US_TREASURY_SECURITIES', 'US Treasury Securities', ''),
            ('AGENCY_SECURITIES', 'Agency Securities', 'US agency debt and agency MBS'),
            ('OTHER_GOVERNMENT_BONDS', 'Other Government Bonds', 'Non-US sovereign debt'),
            ('SUPRANATIONAL_DEBT', 'Supranational Debt', ''),
            ('CORPORATE_BONDS', 'Corporate Bonds', ''),
            ('COVERED_BONDS', 'Covered Bonds', ''),
            ('EQUITIES', 'Equities', 'Main index equities'),
            ('MONEY_MARKET_FUND_SHARES', 'Money Market Fund Shares', ''),
            ('GOLD', 'Gold', ''),
            ('LETTERS_OF_CREDIT', 'Letters of Credit', 'Bank letters of credit (securities lending collateral).'),
            ('OTHER', 'Other', ''),
        ],
        "members": [('26', 'Collateral Type'), ('28', 'Lending Collateral Type'), ('49', 'Collateral Type')],   # 49 added at the W2-W4 merge
        "value_map": _vm(
            # 49 Fully Paid Securities Loan collateral: Rule 15c3-3(b)(3) eligible subset
            _m('49', 'Collateral Type', {'Cash': 'CASH', 'US Treasury Securities': 'US_TREASURY_SECURITIES', 'Letters of Credit': 'LETTERS_OF_CREDIT'}),
            _m('26', 'Collateral Type', {'Cash': 'CASH', 'US Treasury Securities': 'US_TREASURY_SECURITIES', 'Agency Securities': 'AGENCY_SECURITIES', 'Other Government Bonds': 'OTHER_GOVERNMENT_BONDS', 'Supranational Debt': 'SUPRANATIONAL_DEBT', 'Corporate Bonds': 'CORPORATE_BONDS', 'Covered Bonds': 'COVERED_BONDS', 'Equities': 'EQUITIES', 'Money Market Fund Shares': 'MONEY_MARKET_FUND_SHARES', 'Gold': 'GOLD'}),
            _m('28', 'Lending Collateral Type', {'Cash': 'CASH', 'US Treasury Securities': 'US_TREASURY_SECURITIES', 'Other Government Bonds': 'OTHER_GOVERNMENT_BONDS', 'Agency Securities': 'AGENCY_SECURITIES', 'Equities': 'EQUITIES', 'Letters of Credit': 'LETTERS_OF_CREDIT', 'Other': 'OTHER'}),
        ),
    },
    {
        "name": 'Regulatory Trade Report Regime',
        "steward": '26',
        "definition": 'Regulatory regime under which a derivative transaction or a securities loan is reported.',
        "source": 'CFTC Part 45 / SEC Regulation SBSR / SEC Rule 10c-1a',
        "values": [
            # W1b merge (CW-926, CW-928, CW-039): EU_EMIR, UK_EMIR, EU_SFTR and UK_SFTR removed with their 26 and 28 values.
            ('CFTC_PART_45', 'CFTC Part 45', '17 CFR Part 45 swap data reporting'),
            ('SEC_REGULATION_SBSR', 'SEC Regulation SBSR', '17 CFR 242.900-242.909, security-based swap reporting'),
            ('SEC_RULE_10C_1A', 'SEC Rule 10c-1a', 'US securities loan reporting to FINRA SLATE.'),
        ],
        "members": [('26', 'Trade Report Regime'), ('28', 'Loan Reporting Regime'), ('49', 'Regulatory Trade Report Regime')],   # 49 added at the W2-W4 merge (CW-105)
        "value_map": _vm(
            _m('49', 'Regulatory Trade Report Regime', {'SEC Rule 10c-1a': 'SEC_RULE_10C_1A'}),
            _m('26', 'Trade Report Regime', {'CFTC Part 45': 'CFTC_PART_45', 'SEC Regulation SBSR': 'SEC_REGULATION_SBSR'}),
            _m('28', 'Loan Reporting Regime', {'SEC Rule 10c-1a': 'SEC_RULE_10C_1A'}),
        ),
    },
    {
        "name": 'Waiver Type',
        "steward": '27',
        "definition": 'Type of fee waiver or expense reimbursement (CD-188).',
        "source": 'SEC Form N-1A / Internal',
        "values": [
            ('CONTRACTUAL_FEE_WAIVER', 'Contractual Fee Waiver', ''),
            ('VOLUNTARY_FEE_WAIVER', 'Voluntary Fee Waiver', ''),
            ('EXPENSE_REIMBURSEMENT', 'Expense Reimbursement', ''),
            ('MONEY_MARKET_YIELD_WAIVER', 'Money Market Yield Waiver', 'Waiver to maintain non-negative yield'),
            ('ACQUIRED_FUND_FEE_WAIVER', 'Acquired Fund Fee Waiver', 'Waiver for fees of affiliated underlying funds'),
            ('12B_1_FEE_WAIVER', '12b-1 Fee Waiver', ''),
        ],
        "members": [('27', 'Waiver Type'), ('10', 'Waiver Type')],
        "value_map": _vm(
            _m('27', 'Waiver Type', {'Contractual Fee Waiver': 'CONTRACTUAL_FEE_WAIVER', 'Voluntary Fee Waiver': 'VOLUNTARY_FEE_WAIVER', 'Expense Reimbursement': 'EXPENSE_REIMBURSEMENT', 'Money Market Yield Waiver': 'MONEY_MARKET_YIELD_WAIVER', 'Acquired Fund Fee Waiver': 'ACQUIRED_FUND_FEE_WAIVER', '12b-1 Fee Waiver': '12B_1_FEE_WAIVER'}),
            _m('10', 'Waiver Type', {'Contractual Fee Waiver': 'CONTRACTUAL_FEE_WAIVER', 'Voluntary Fee Waiver': 'VOLUNTARY_FEE_WAIVER', 'Expense Reimbursement': 'EXPENSE_REIMBURSEMENT', 'Money Market Yield Waiver': 'MONEY_MARKET_YIELD_WAIVER', 'Acquired Fund Fee Waiver': 'ACQUIRED_FUND_FEE_WAIVER', '12b-1 Fee Waiver': '12B_1_FEE_WAIVER'}),
        ),
    },
    {
        "name": 'Cost Bearer',
        "steward": '13',
        "definition": 'Party that bears the cost of a servicing error, NAV error, as-of dilution or intermediary communication fee.',
        "source": 'Internal',
        "values": [
            ('FUND', 'Fund', ''),
            ('ADVISER', 'Adviser', ''),
            ('SHARED_FUND_ADVISER', 'Shared Fund / Adviser', ''),
            ('SERVICE_PROVIDER', 'Service Provider', ''),
            ('INTERMEDIARY', 'Intermediary', ''),
            # Added at the W2-W4 merge (13 review F, CW-913)
            ('FIRM', 'Firm', 'Broker-dealer or adviser entity of the firm, for errors on non-fund accounts'),
        ],
        # W2-W4 merge: 05 added (Intermediary Communication Fee Invoice moved from 13, CW-088; proposals_w4_05). 36 renamed its local
        # 'Cost Bearer' to 'Reorganization Cost Bearer' and stays local.
        "members": [('13', 'Cost Bearer'), ('05', 'Cost Bearer')],
        "direct_users": ['29'],
        "value_map": _vm(
            _m('13', 'Cost Bearer', {'Fund': 'FUND', 'Firm': 'FIRM', 'Adviser': 'ADVISER', 'Shared Fund / Adviser': 'SHARED_FUND_ADVISER', 'Service Provider': 'SERVICE_PROVIDER', 'Intermediary': 'INTERMEDIARY'}),
            _m('05', 'Cost Bearer', {'Fund': 'FUND', 'Adviser': 'ADVISER', 'Shared Fund / Adviser': 'SHARED_FUND_ADVISER', 'Service Provider': 'SERVICE_PROVIDER', 'Intermediary': 'INTERMEDIARY'}),
        ),
    },
    {
        "name": 'Fund Dealing Settlement Method',
        "steward": '29',
        "definition": 'Settlement venue or arrangement for fund dealing (not securities DvP / FoP, 26; not derivative cash or physical settlement, 17).',
        "source": 'Internal',
        "values": [
            ('NSCC_NET_SETTLEMENT', 'NSCC Net Settlement', 'Fund/SERV or DCC&S money settlement'),
            # W2-W4 merge (CW-929, CW-039): CALASTONE_SETTLEMENT and ICSD_CLEARSTREAM_EUROCLEAR removed; AFFILIATED_BD_OMNIBUS added.
            ('AFFILIATED_BD_OMNIBUS', 'Affiliated Broker-Dealer Omnibus Settlement', "Internal settlement with the firm's broker-dealer for its omnibus orders (CW-097)"),
            ('BANK_TRANSFER_WIRE', 'Bank Transfer / Wire', 'Gross settlement by wire with an intermediary, AP or institution'),
            ('DIRECT_INVESTOR_PAYMENT', 'Direct Investor Payment', 'Gross settlement with a fund-only shareholder through a 50 money movement (ACH, wire or check; CW-107)'),
        ],
        # W2-W4 merge: ('05', 'Settlement Method') removed (not carried by the replaced 05; proposals_w4_05 MEMBERSHIPS_REMOVE).
        "members": [('29', 'Order Settlement Method')],
        "value_map": _vm(
            _m('29', 'Order Settlement Method', {'NSCC Net Settlement': 'NSCC_NET_SETTLEMENT', 'Affiliated Broker-Dealer Omnibus Settlement': 'AFFILIATED_BD_OMNIBUS', 'Bank Transfer / Wire': 'BANK_TRANSFER_WIRE', 'Direct Investor Payment': 'DIRECT_INVESTOR_PAYMENT'}),
        ),
    },
    {
        "name": 'Exposure Method',
        "steward": '31',
        "definition": "Regulatory method used to measure a fund's derivatives exposure or senior securities leverage.",
        "source": 'SEC Rule 18f-4 / Investment Company Act Section 18',
        "values": [
            # W1b merge (CW-931, CW-039): COMMITMENT_APPROACH_UCITS, SUM_OF_NOTIONALS_UCITS, GROSS_METHOD_AIFMD and
            # COMMITMENT_METHOD_AIFMD removed; SECTION_18_ASSET_COVERAGE added (program-lead ruling in the 31 review fix pass).
            ('RULE_18F_4_DERIVATIVES_EXPOSURE', 'Rule 18f-4 Derivatives Exposure', 'Sum of gross notional amounts of derivatives (options delta-adjusted, interest rate derivatives as 10-year bond equivalents) plus short sale and elected financing exposure'),
            ('SECTION_18_ASSET_COVERAGE', 'Section 18 Asset Coverage', 'Asset coverage of senior securities under Investment Company Act Section 18(f)(1), including reverse repurchase agreements and similar financing a fund does not elect to treat as derivatives transactions under Rule 18f-4(d)'),
        ],
        "members": [('31', 'Exposure Method')],
        "direct_users": ['33'],
        "value_map": _vm(
            _m('31', 'Exposure Method', {'Rule 18f-4 Derivatives Exposure': 'RULE_18F_4_DERIVATIVES_EXPOSURE', 'Section 18 Asset Coverage': 'SECTION_18_ASSET_COVERAGE'}),
        ),
    },
    {
        "name": 'Risk Measure',
        "steward": '31',
        "definition": 'Ex-ante portfolio risk measure (the ex-post statistics of 32 are a separate list).',
        "source": 'Internal / Basel MAR (concepts)',  # CESR/10-788 dropped at the W1b merge (CW-931)
        "values": [
            ('EX_ANTE_TRACKING_ERROR', 'Ex-Ante Tracking Error', 'Forecast standard deviation of active return against a benchmark'),
            ('EX_ANTE_VOLATILITY', 'Ex-Ante Volatility', 'Forecast standard deviation of total return'),
            ('VALUE_AT_RISK', 'Value at Risk', 'Loss not exceeded at the confidence level over the horizon'),
            ('EXPECTED_SHORTFALL', 'Expected Shortfall', 'Average loss beyond the VaR at the confidence level'),
            ('EX_ANTE_BETA', 'Ex-Ante Beta', 'Forecast sensitivity of portfolio return to benchmark return'),
        ],
        "members": [('31', 'Risk Measure')],
        "direct_users": ['33'],
        "value_map": _vm(
            _m('31', 'Risk Measure', {'Ex-Ante Tracking Error': 'EX_ANTE_TRACKING_ERROR', 'Ex-Ante Volatility': 'EX_ANTE_VOLATILITY', 'Value at Risk': 'VALUE_AT_RISK', 'Expected Shortfall': 'EXPECTED_SHORTFALL', 'Ex-Ante Beta': 'EX_ANTE_BETA'}),
        ),
    },
    # COLL Change Classification (steward 36; FCA COLL 4.3) retired at the W2-W4 merge (CW-164, CW-936): the 13 member ended under
    # CW-913 and the 36 member under CW-936; no direct user. Kept at tag wholesale-v1.0.
    {
        "name": 'Third-Party Risk Domain',
        "steward": '37',
        "definition": 'Risk domain assessed in a third-party (vendor, supplier or data vendor) risk assessment (CD-248).',
        "source": 'Internal (third-party risk management practice)',
        "values": [
            ('INFORMATION_SECURITY', 'Information Security', ''),
            ('BUSINESS_CONTINUITY_AND_RESILIENCE', 'Business Continuity & Resilience', ''),
            ('DATA_PRIVACY', 'Data Privacy', ''),
            ('FINANCIAL_VIABILITY', 'Financial Viability', ''),
            ('LEGAL_AND_REGULATORY', 'Legal & Regulatory', ''),
            ('CONCENTRATION', 'Concentration', ''),
            ('SUBCONTRACTING_FOURTH_PARTY', 'Subcontracting / Fourth Party', ''),
            ('REPUTATIONAL', 'Reputational', ''),
            # W5 (CW-175): ESG_MODERN_SLAVERY ('ESG / Modern Slavery', named for the UK Modern Slavery Act 2015) becomes the generic
            # value below; the UK label is recorded in the jurisdiction register (14 and 37 relabel their copies).
            ('FORCED_LABOR_HUMAN_RIGHTS', 'Forced Labor / Human Rights', 'Forced labor, child labor and other human-rights risk in the third party or its supply chain (US anchors: Uyghur Forced Labor Prevention Act; 19 U.S.C. 1307).'),
            ('CONDUCT_AND_MNPI', 'Conduct and MNPI', 'Expert networks and research providers'),
        ],
        "members": [('37', 'Third-Party Risk Domain'), ('14', 'Vendor Risk Domain')],
        "value_map": _vm(
            _m('37', 'Third-Party Risk Domain', {'Information Security': 'INFORMATION_SECURITY', 'Business Continuity & Resilience': 'BUSINESS_CONTINUITY_AND_RESILIENCE', 'Data Privacy': 'DATA_PRIVACY', 'Financial Viability': 'FINANCIAL_VIABILITY', 'Legal & Regulatory': 'LEGAL_AND_REGULATORY', 'Concentration': 'CONCENTRATION', 'Subcontracting / Fourth Party': 'SUBCONTRACTING_FOURTH_PARTY', 'Reputational': 'REPUTATIONAL', 'Forced Labor / Human Rights': 'FORCED_LABOR_HUMAN_RIGHTS', 'Conduct and MNPI': 'CONDUCT_AND_MNPI'}),
            _m('14', 'Vendor Risk Domain', {'Information Security': 'INFORMATION_SECURITY', 'Business Continuity & Resilience': 'BUSINESS_CONTINUITY_AND_RESILIENCE', 'Data Privacy': 'DATA_PRIVACY', 'Financial Viability': 'FINANCIAL_VIABILITY', 'Legal & Regulatory': 'LEGAL_AND_REGULATORY', 'Concentration': 'CONCENTRATION', 'Subcontracting / Fourth Party': 'SUBCONTRACTING_FOURTH_PARTY', 'Reputational': 'REPUTATIONAL', 'Forced Labor / Human Rights': 'FORCED_LABOR_HUMAN_RIGHTS'}),
        ),
    },
    # W5 (CW-175): created from the 02 and 11 copies (W4 11 review ruling: wealth bands nest with the 02 Net Worth Band; the 02
    # steward split the top band at W5). 11 bands investable assets on the same boundaries.
    {
        "name": 'Net Worth Band',
        "steward": '02',
        "definition": 'USD band boundaries for household wealth: net worth excluding the primary residence in 02 (client profile), investable assets on the same boundaries in 11 (market sizing).',
        "source": 'Internal (wealth-segment boundaries; net worth excludes the primary residence)',
        "values": [
            ('USD_0_50K', 'USD 0 - 49,999', ''),
            ('USD_50K_100K', 'USD 50,000 - 99,999', ''),
            ('USD_100K_250K', 'USD 100,000 - 249,999', ''),
            ('USD_250K_500K', 'USD 250,000 - 499,999', ''),
            ('USD_500K_1M', 'USD 500,000 - 999,999', ''),
            ('USD_1M_2_5M', 'USD 1,000,000 - 2,499,999', ''),
            ('USD_2_5M_5M', 'USD 2,500,000 - 4,999,999', ''),
            ('USD_5M_10M', 'USD 5,000,000 - 9,999,999', ''),
            ('USD_10M_25M', 'USD 10,000,000 - 24,999,999', ''),
            ('USD_25M_PLUS', 'USD 25,000,000 or more', 'Ultra-high-net-worth threshold (top band split at W5, CW-160).'),
        ],
        "members": [('02', 'Net Worth Band'), ('11', 'Net Worth Band')],
        "value_map": _vm(*[_m(d, 'Net Worth Band', {'USD 0 - 49,999': 'USD_0_50K', 'USD 50,000 - 99,999': 'USD_50K_100K', 'USD 100,000 - 249,999': 'USD_100K_250K', 'USD 250,000 - 499,999': 'USD_250K_500K', 'USD 500,000 - 999,999': 'USD_500K_1M', 'USD 1,000,000 - 2,499,999': 'USD_1M_2_5M', 'USD 2,500,000 - 4,999,999': 'USD_2_5M_5M', 'USD 5,000,000 - 9,999,999': 'USD_5M_10M', 'USD 10,000,000 - 24,999,999': 'USD_10M_25M', 'USD 25,000,000 or more': 'USD_25M_PLUS'}) for d in ('02', '11')]),
    },
    # W1b merge (CW-940, CW-915): 15 and 40 carry the same seven IRS forms; one list, steward 15.
    {
        "name": 'Tax Form Type',
        "steward": '15',
        "definition": 'IRS certification form received for a party: the client account holder (15 Account Tax Certification) or a supplier (40 Supplier tax form on file).',
        "source": 'IRS (Forms W-9 and W-8 series)',
        "values": [
            ('W_9', 'W-9', 'Request for Taxpayer Identification Number and Certification (US persons)'),
            ('SUBSTITUTE_FORM_W_9', 'Substitute Form W-9', 'A form carrying the Form W-9 certification, e.g. embedded in an account application or a supplier\'s own form'),
            ('W_8BEN', 'W-8BEN', 'Foreign individual beneficial owner'),
            ('W_8BEN_E', 'W-8BEN-E', 'Foreign entity beneficial owner'),
            ('W_8IMY', 'W-8IMY', 'Foreign intermediary, flow-through entity or certain branches'),
            ('W_8EXP', 'W-8EXP', 'Foreign government, international organization or tax-exempt organization'),
            ('W_8ECI', 'W-8ECI', 'Foreign person with income effectively connected with a US trade or business'),
        ],
        "members": [('15', 'Tax Form Type'), ('40', 'Tax Form Type')],
        "value_map": _vm(
            *[_m(d, 'Tax Form Type', {'W-9': 'W_9', 'Substitute Form W-9': 'SUBSTITUTE_FORM_W_9', 'W-8BEN': 'W_8BEN', 'W-8BEN-E': 'W_8BEN_E', 'W-8IMY': 'W_8IMY', 'W-8EXP': 'W_8EXP', 'W-8ECI': 'W_8ECI'}) for d in ('15', '40')],
        ),
    },
    # DORA Substitutability (steward 40, ITS (EU) 2024/2956 B_07.01) retired at the W1b merge (CW-039): its members 40 DORA
    # Substitutability (CW-940) and 14 Substitutability (firm-defined, CW-914) left. Kept at tag wholesale-v1.0.
    {
        "name": 'Governing Law',
        "steward": '39',
        "definition": 'Law that governs a contract or agreement.',
        "source": 'Internal',
        "values": [
            ('NEW_YORK', 'New York', ''),
            ('DELAWARE', 'Delaware', ''),
            ('MASSACHUSETTS', 'Massachusetts', ''),
            ('CALIFORNIA', 'California', ''),
            ('MARYLAND', 'Maryland', 'Added by 39: Maryland corporations and statutory trusts'),
            ('ENGLAND_AND_WALES', 'England and Wales', ''),
            ('SCOTLAND', 'Scotland', ''),
            ('LUXEMBOURG', 'Luxembourg', ''),
            ('IRELAND', 'Ireland', ''),
            ('GERMANY', 'Germany', ''),
            ('SWITZERLAND', 'Switzerland', ''),
            ('OTHER', 'Other', ''),
        ],
        "members": [('39', 'Governing Law'), ('05', 'Governing Law')],
        "value_map": _vm(
            _m('39', 'Governing Law', {'New York': 'NEW_YORK', 'Delaware': 'DELAWARE', 'Massachusetts': 'MASSACHUSETTS', 'California': 'CALIFORNIA', 'Maryland': 'MARYLAND', 'England and Wales': 'ENGLAND_AND_WALES', 'Scotland': 'SCOTLAND', 'Luxembourg': 'LUXEMBOURG', 'Ireland': 'IRELAND', 'Germany': 'GERMANY', 'Switzerland': 'SWITZERLAND', 'Other': 'OTHER'}),
            # 05 US subset (CW-905, proposals_w4_05); steward 39 keeps the non-US values for its own contracts (CW-939 unchanged)
            _m('05', 'Governing Law', {'New York': 'NEW_YORK', 'Delaware': 'DELAWARE', 'Massachusetts': 'MASSACHUSETTS', 'California': 'CALIFORNIA', 'Maryland': 'MARYLAND', 'Other': 'OTHER'}),
        ),
    },
]


# W5 (CW-175): the 09 local Business Domain list carries every numbered label of the shared list (agent B relabeled it to
# the domains.py names, 07 and 30 with the retired suffix), so its value map is the identity on those labels.
for _x in SHARED:
    if _x["name"] == "Business Domain":
        _x["value_map"].update({("09", "Business Domain", _l): _c for _c, _l, _d in _x["values"] if _l[:2].isdigit()})


LOCAL_RENAMES = [
    # W1 merge (CW-004, CW-901): ("01", "Business Line", "Client Segment") removed. CD-209 is superseded for the wealth model: 01's
    # "Business Line" now holds the eight CW-004 lines and is a member of the shared Business Line, not a client segment list.
    # (domain, current name, new name, reason)
    ("01", "Party Role Type", "Product Party Role Type", "01 lists roles of service providers to a fund (adviser, custodian, transfer agent, trustee); 02 lists roles a party plays with the firm."),  # reason reworded at W1 (CW-901)
    # W2-W4 merge: ("02", "Investor Type", "Investor Legal Type") removed: the wealth 02 authors no Investor Type list (stale since W1, CW-902).
    # W1 merge (CW-901): ("01", "Registration Status", "Product Registration Status") removed; the list left 01 with Country Registration.
    # W2-W4 merge: ("02", "Registration Status", ...) removed: the list moved to 05 under its new name (proposals_w4_05; to re-check).
    ("04", "Registration Status", "Event Registration Status", "Status of a registrant for a marketing event (invited, registered, attended)."),
    ("08", "Registration Status", "License Registration Status", "FINRA CRD status of an own-staff registration on the LIC- record."),
    # W2-W4 merge: ("03", "Snapshot Type", ...) removed with Pipeline Snapshot (wholesale 03, CW-903).
    ("06", "Snapshot Type", "Snapshot Version Stage", "06 is the version stage of an AUM / flow snapshot (flash, preliminary, final, restated)."),
    # W2-W4 merge: ("03", "Capture Method", ...) removed: the replaced 03 authors "Activity Capture Method" itself (CW-903).
    # W2-W4 merge: ("08", "Capture Method", ...) removed: the replaced 08 holds no Capture Method list (CW-908).
    # W2-W4 merge: ("05", "Benefit Type", ...) removed: not carried by the replaced 05 (proposals_w4_05; to re-check).
    ("08", "Benefit Type", "Gift and Entertainment Benefit Type", "Gifts, entertainment and non-cash compensation given or received (FINRA Rules 3220 and 2341)."),  # COBS 2.3A dropped (CW-908)
    # W2-W4 merge: ("05", "Attestation Type", ...) removed: not carried by the replaced 05 (proposals_w4_05; to re-check).
    ("38", "Attestation Type", "Compliance Attestation Type", "Attestations made by own staff and officers (annual compliance, code of ethics, Rule 3130)."),  # moved with Attestation from 08 to 38 (CD-252)
    # W2-W4 merge: ("12", "Payment Status", ...) removed: the fee invoice family moved to 47 (CW-051, proposals_w4_12).
    # W2-W4 merge: ("05", "Termination Reason", ...) removed: the replaced 05 authors "Agreement Termination Reason" itself (to re-check).
    ("12", "Termination Reason", "Mandate Termination Reason", "Why an institutional client terminated a mandate."),
    # W2-W4 merge: ("05", "Dispute Reason", ...) removed: not carried by the replaced 05 (proposals_w4_05; to re-check).
    # W2-W4 merge: ("12", "Dispute Reason", ...) removed: moved to 47 with the fee invoice (proposals_w4_12).
    # W2-W4 merge: 13 relabeled 'Client Service Request Type' (proposals_w2_13: the list covers brokerage, advisory, participant and
    # trust work types); 12 therefore renamed 'Institutional Service Request Type' so the two stay distinct.
    # W5 (CW-175): ("12", "Service Request Type", "Institutional Service Request Type") deleted: 12 now authors the list under that name.
    ("13", "Service Request Type", "Client Service Request Type", "Client service work types across brokerage, advisory, participant, trust and fund accounts (address change, transfer, estate)."),
    ("13", "Good Order Status", "Service Request Good Order Status", "Good order state of a client service request; 16 holds a contribution 'Good Order Status' (proposals_w2_13)."),
    # W2-W4 merge: ("05", "Coverage Basis", ...) removed: not carried by the replaced 05 (proposals_w4_05; to re-check).
    ("11", "Coverage Basis", "Industry Data Attribution Basis", "Basis on which an industry dataset attributes flows and assets (fund domicile, reporting distributor, investor residence, filer)."),  # reworded at the W2-W4 merge (proposals_w4_11, CW-911)
    # W2-W4 merge: ("02", "Hierarchy Type", ...) removed: the distributor hierarchy moved to 05 under its new name (CW-132; to re-check).
    ("10", "Hierarchy Type", "Management Reporting Hierarchy Type", "Dimension of a management P&L hierarchy (channel, product, region, cost center)."),
    # W5 (CW-175): ("07", "Plan Type", "Incentive Plan Type") deleted as history: 07 retired (CW-907).
    # ("10", "Plan Type") is no longer renamed: it is a member of the shared list "Financial Plan Type" (CD-286).
    ("01", "Pricing Basis", "Dealing Price Basis", "Forward or historic pricing for fund dealing (openfunds)."),
    ("14", "Pricing Basis", "License Pricing Basis", "How a data license is priced (flat, per user, bps on AUM)."),
    ("06", "Reconciliation Type", "Flow and Client Asset Reconciliation Type", "Operational reconciliations of book-of-record, intermediary and attributed flow and client asset data."),  # relabeled at the W2-W4 merge (proposals_w4_06)
    ("10", "Reconciliation Type", "Finance Reconciliation Type", "Finance reconciliations of accruals and profitability to source domains and the GL."),
    ("06", "Restatement Reason", "Flow and Client Asset Restatement Reason", "Why attributed flows or client assets were restated."),  # relabeled at the W2-W4 merge (proposals_w4_06)
    ("12", "Restatement Reason", "Client Report Restatement Reason", "Why a client report or performance figure was restated."),
    # W2-W4 merge: ("05", "Review Type", ...) removed: the replaced 05 authors "Partner Review Type" itself (to re-check).
    # W5 (CW-174, CW-175): the 11 competitor price unit list is renamed so the 22 ISO 20022 quote basis keeps the name (term conflict 'Price Quote Basis').
    ("11", "Price Quote Basis", "Competitor Price Quote Basis", "Unit in which a competitor price is quoted (annual percentage of assets, per trade, per contract); 22 'Price Quote Basis' is the ISO 20022 security quote basis."),
    ("08", "Review Type", "Communication Review Type", "Type of compliance review of a marketing communication (new, revision, recertification)."),
]


NOT_MERGED = [
    # (domain A, list A, domain B, list B, reason)
    # W5 (CW-175): 21 rows deleted as history because one side names a list that no longer exists in the live module (the
    # wholesale 02, 03, 04, 06, 07 and 08 lists; tag wholesale-v1.0 keeps them): 02 Registration Status / 08 Registration Status; 01 Investor Type / 02 Investor Type; 04 Declared Investor Type / 04 Investor Category; 03 Audience Type / 04 Audience Type; 08 Audience Category / 04 Audience Restriction; 03 Answer Audience / 04 Audience Type; 04 Personal Data Classification / 06 Data Classification;
    #   04 Personal Data Classification / 02 Personal Data Category; 08 Gross Net Presentation / 12 Fee Basis; 07 Territory Status / 09 Reference Record Status; 08 Complaint Status / 12 Request Status; 02 Data Subject Request Status / 13 Service Request Status;
    #   04 Communication Channel / 13 Service Channel; 08 Electronic Channel Type / 04 Communication Channel; 04 Marketing Channel / 03 Sales Channel; 07 Product Compensation Tier / 12 Service Tier; 07 Credit Trigger Event / 06 Position Basis;
    #   02 Consent Capture Method / 03 Capture Method; 20 Background Screening Type / 08 Screening Type; 20 Job Assignment Type / 07 Assignment Type; 04 Personal Data Classification / 21 Personal Data Sensitivity.
    ("03", "Attendance Status", "04", "Registration Status", "67% value overlap, but 03 is attendance at a sales meeting and 04 is the registration lifecycle of an event registrant (04 renamed 'Event Registration Status')."),
    ("13", "Report Period Type", "01", "Frequency", "100% value overlap (Annual, Semi-Annual), but 13 identifies the SEC Rule 30e-1 shareholder report type, not a recurrence."),
    ("14", "Risk Rating", "14", "Severity", "Both are shared lists but kept apart: a risk rating assesses an entity (inherent / residual), severity grades a finding or issue."),  # W5 (CW-175): re-keyed to a live member of the shared list
    ("06", "Match Confidence Band", "02", "Risk Rating", "Same High/Medium/Low words, but 06 bands an entity-matching score, not a risk."),  # W5 (CW-175): re-keyed to a live member of the shared list
    ("11", "Impact Level", "08", "Severity", "11 grades the expected business impact of a regulatory or market development (includes 'None'); not the severity of a finding."),
    ("02", "Identifier Scheme", "14", "Identifier Scheme", "Same concept at different grain: 02 is the party identifier scheme list (CRD firm / individual / branch separately); 14 lists identifier types carried in vendor datasets, incl. instrument IDs and combined values ('FINRA CRD', 'FCA FRN / IRN'). Align 14 party codes to 02 later."),
    # W2-W4 merge: ("05", "Renewal Decision", "14", "Renewal Decision") removed: 05 Renewal Decision not carried (proposals_w4_05; to re-check).
    # W2-W4 merge: ("12", "Settlement Message Standard", "06", "Message Standard") removed: the 12 list left the module (proposals_w4_12).
    ("13", "Reclaim Status", "05", "Payable Invoice Status", "Overlapping values, but 13 tracks unclaimed property reclaims, not payable invoices."),  # reworded at the W2-W4 merge (proposals_w2_13, proposals_w4_05)
    ("01", "Performance Calculation Basis", "12", "Return Methodology", "01 mixes fee basis and calculation method (NAV-to-NAV net, gross, TWR, MWR); 12 is calculation method only. Split 01 before aligning."),
    ("01", "Lifecycle Status", "09", "Reference Record Status", "Product lifecycle (soft / hard closed, in liquidation, merged) is a domain lifecycle, not a generic record status."),
    ("02", "Identifier Status", "09", "Reference Record Status", "Includes 'Unverified', a verification state rather than a lifecycle state."),
    ("12", "Servicing Segment", "06", "Distribution Channel", "Institutional servicing segment (OCIO, separate account, pooled fund or CIT, plan sponsor) is a service-model segmentation, not a distribution channel."),  # reworded at the W2-W4 merge (proposals_w4_12)
    # W2-W4 merge: ("05", "12b-1 Component", "10", "Revenue Stream") removed: 05 12b-1 Component not carried (no 12b-1 plans, CW-136) (proposals_w4_05; to re-check).
    ("06", "Position Basis", "09", "As-Of Date Convention", "Trade vs settlement date basis is one dimension of the 09 as-of convention; 06 should reference the 09 values later rather than merge now."),
    ("09", "Period Type", "09", "Reporting Period Basis", "Period length (month, quarter) vs relative reporting window (MTD, trailing 3Y); both shared lists are needed."),
    # Stage 1 (2026-10-06): pairs recorded by Data Domains 17-21 (proposals_18, proposals_20, proposals_21)
    ("18", "Lot Relief Method", "15", "Cost Basis Method", "NOT_MERGED candidate: 15 'Cost Basis Method' is the shareholder's election on fund shares (IRC 6045); 18 'Lot Relief Method' is how a managed portfolio relieves its own lots (UK share identification rules removed at the W1b merge, CW-918). Overlapping values, different subject; record the pair in NOT_MERGED. Shared labels are aligned (FIFO, LIFO, High Cost, Low Cost, Specific Lot Identification, Average Cost); 15 'Loss / Gain Utilization' and 18 'Tax-Optimized' are close and could use one label."),
    ("18", "Portfolio Identifier Scheme", "15", "Account Identifier Scheme", "NOT_MERGED candidate against 15 'Account Identifier Scheme': both have custodian numbers but identify different records."),
    ("20", "Background Screening Result", "02", "Screening Result", "Different concepts: pre-employment background check outcome vs sanctions / PEP / adverse-media match disposition. The brief named the local list 'Screening Result', which collides with the shared list name."),  # W5 (CW-175): re-keyed to a live member of the shared list
    ("20", "Employee Benefit Type", "08", "Benefit Type", "Employee benefits vs gifts, entertainment and non-cash compensation."),
    # W2-W4 merge: ("20", "Employee Benefit Type", "05", "Benefit Type") removed: 05 Benefit Type not carried (proposals_w4_05; to re-check).
    ("20", "Award Vesting Basis", "16", "Vesting Basis", "Deferred award vesting vs IRC 411(a) retirement plan vesting."),
    ("20", "Employee Lifecycle Event Type", "01", "Lifecycle Event Type", "Employment events vs product lifecycle events."),
    # W2-W4 merge: ("20", "Performance Review Type", "05", "Review Type") removed: 05 Review Type renamed Partner Review Type (proposals_w4_05; to re-check).
    # W1b merge (CW-920): ("20", "MRT Remuneration Regime", "07", "Remuneration Regime") removed; the 20 list left with the MRT content.
    ("20", "Learning Item Type", "38", "Attestation Type", "Training items vs policy attestations; 'Attestation' was removed from the 20 list."),  # W5 (CW-175): re-keyed to a live member of the shared list
    ("09", "Mapping Type", "21", "Element Mapping Type", "09 maps code values between schemes (Exact / Close / Broad Match); 21 maps physical elements to taxonomy attributes (Direct / Transformed / Derived)."),
    ("11", "Release Status", "21", "Taxonomy Release Status", "11 is the status of an industry data release; 21 is the publication status of a taxonomy release."),
    ("15", "Certification Status", "21", "Governance Certification Status", "15 is tax form certification; 21 is data asset certification."),
    ("09", "Business Function", "21", "Data Product Business Function", "Different granularity and purpose."),
    ("14", "Permitted Use Category", "21", "Permitted AI Data Use", "Different grain: 14 codes what a license permits per dataset; 21 codes how an AI use case uses data. Each 21 value names its 14 counterpart in the description, and the approval references the 14 Permitted Use Grant."),
    # W2-W4 merge: pairs recorded by the W2-W4 proposals (NOT_MERGED kind in proposals_w2_08 and proposals_w3_50)
    ("08", "Heightened Supervision Basis", "08", "Disclosure Event Type", "De-overlapped: the plan basis says 'Disclosure Event' and the kind of disclosure is the related Disclosure Event's type."),
    ("08", "Conduct Rule Basis", "45", "Best Interest Component", "Conduct Rule Basis holds rule numbers only; the obligation components are 45's."),
    ("08", "Registration Category", "20", "Regulated Role Category", "Registration codes an individual holds (CRD) vs the registrations a role requires (CW-072, CW-920)."),
    ("08", "Review Outcome", "45", "Review Outcome", "Same name, different subject: supervisory review result (08) vs the outcome of a client advice review (45)."),
    ("50", "Money Movement Status", "19", "Outgoing Payment Status", "Different scope: 50 covers incoming and outgoing client payments with hold, review and return states; 19 covers the firm's outgoing payments."),
    ("50", "Payment Rail", "29", "Order Payment Method", "29 lists how a fund-side payment is made (including NSCC settlement); 50 lists client payment rails. Kept apart and mapped in LIST_MAPS."),
]


# W2-W4 merge: value maps between two LOCAL lists that are deliberately not merged (NOT_MERGED above); not read by the builder.
# {(source domain, source list, target domain, target list): {source value: target value, or None}}
LIST_MAPS = {
    # proposals_w3_50 LIST_MAPS (50 fix pass): international wires leave through the correspondent by Fedwire; card and bill pay never
    # settle fund-side payments; 29 NSCC Settlement Payment has no 50 equivalent.
    ("50", "Payment Rail", "29", "Order Payment Method"): {
        "ACH": "ACH", "Fedwire Funds": "Fedwire", "International Wire": "Fedwire", "Check": "Check",
        "Internal Journal": "Internal Book Transfer", "Debit Card Network": None, "Bill Pay Service": None},
}
