# Stage 1 consolidation notes (2026-10-06)

The Stage 1 consolidation merged Data Domains 17 to 21 into the enterprise registers and applied the agreed moves to Data Domains 01 to 16 (Enterprise_Expansion_Plan.md §9.3 step 5). This file records:
- what was applied
- what was deferred, and the decision each deferred item needs
- the reconciliation of every difference that `check_baseline.py` reports against `distribution-v0.4`

The new baseline is `baseline/stage1-v0.1.json`.

## 1. Decisions applied

| Decision | Status | What changed |
|---|---|---|
| CD-151 | Applied | Employee, Employee Reporting Line and Org Unit Assignment, and the lists Employment Type, Employment Status and Reporting Line Type, were removed from 09. They were identical in 20 apart from Notes. `EMP-` is registered to 20. Ownership aliases `employee` and `salesperson` now resolve to 20. The 01, 08, 15 and 16 overrides were re-pointed to 20. Data product inputs, logical model keys and models, and the gap register now read 20. 07 Identified Staff Indicator is a derived copy of 20 Material Risk Taker Identification. Definition text in 03, 04, 07 and 08 and the 01-16 "References" summaries were re-pointed to 20. CD-120 is marked as superseded. |
| CD-152 | Applied | GL Posting and Accounting Period Status were removed from 10. External Reporting Line, XBRL Element and Revenue Disaggregation Category were removed from 10 Account Mapping. GL Natural Account and Applicable Ledger now reference 19 GL Account and Ledger. The 10 lists Ledger, Journal Type and Period Close Status were removed. The 10 cost center references (Distribution Cost Item, Cost Pool, Plan Line), 09 Cost Center Code and Profit Center Code, and 07 Compensation Accrual GL Account now reference 19. 10 Plan Version gained Enterprise Financial Plan Version. 09 Accounting Company Code and Fiscal Period Status are derived copies of 19 (value map in Notes). `JNL-` is registered to 19. DP-012, DP-056, DP-074, DP-089, their models and SM-07 were re-pointed. CD-083 and CD-084 carry an amendment note. |
| CD-156 | Applied | 06 DQ Rule and its DQ Dimension list were removed; 21 Data Quality Rule and Data Quality Result keep the names. `DQR-` is registered to 21. DP-045, DP-075, their models and the gap register were re-pointed. |
| CD-158 | Applied (as amended in proposals_19.py) | 14 AP Document Reference is a derived copy of the 19 Payable Invoice ID. 12 Fee Invoice Payment Status is a derived copy of the 19 Receivable Status (value map in Notes). The shared lists Payable Invoice Status and Outgoing Payment Status are now stewarded by 19. |
| CD-163 (proposals_21 CD-21-C) | Applied | 06 Measure Definition Certified Indicator is a derived copy owned by 21. Its definition was reworded. |
| CD-166 (new) | Applied | Register consolidation for 17-21: prefixes, concept owners, aliases, term conflicts, shared-list direct users and value additions, and not-merged pairs. See section 2. |

CD-143 to CD-150, CD-153 to CD-155, CD-157, CD-159 to CD-162, CD-164 and CD-165 were merged with status Proposed.

## 2. Registers (CD-166)

- **Prefixes:** the 26 prefixes reserved by the Stage 1 briefs are registered under their owners. The transferred prefixes changed owner: `EMP-` 09 to 20 (CD-151), `JNL-` 10 to 19 (CD-152) and `DQR-` 06 to 21 (CD-156).
- **Concept ownership:** 37 rows were added for the 17-21 masters. Employee was changed to 20. Org Unit was re-noted for CD-152. The 10 row "Cost / Profit Center Code and GL Account" was replaced by "Account Mapping (management P&L line -> GL account)" and the 19 rows GL Account and Chart Segment Value. The referencing domains come from a scan of the content as it stands now.
- **Term conflicts:** 34 terms were added. Account, Rating and Revenue were extended.
- **Shared lists:** each list now has a `direct_users` key, which records the domains that cite it directly as "Shared: <name>" rather than through a local member list. The builder reads this key. It replaces the import-time helpers in 18-21 and 17's six local copies (Frequency, Record Status, Case Status, Approval Status, Message Standard and Data Provider).
  - 17 and 21 were first registered as members with the proposals' value maps, then converted to direct users when their local copies were removed in step 6. The proposals_17 maps were label-identical, so no value changed.
  - Values were added to two lists: 11 data providers in Data Provider (proposals_17), and Data Domains 15 to 21 in Business Domain (proposals_21).
  - Message Standard's definition was widened to corporate action and security reference messages.
- **Not merged:** 18 pairs from proposals_18, 20 and 21 were recorded.

### Candidate shared lists deferred

| Candidate | Raised by | Why deferred |
|---|---|---|
| Business Line | 18, 21 | The value sets disagree: 18 has the six enterprise business lines, while 21 also has Institutional Mandate and Proprietary / Seed, which 18 explicitly excludes. 01 has a local list of the same name that means client segment. The value map is not complete, and the 01 rename needs a decision. |
| Identifier Status | 17 (with 02, 15) | Only one expansion domain uses it. The other members are 01-16 lists that would change. |
| Governance Role | 21 | Only 21 has the list. 09 and 14 hold owner and steward attributes but no list. |
| Instrument Asset Class, Instrument Type, Instrument Identifier Scheme, Day Count / Business Day Convention, Credit Rating Agency, corporate action lists, Settlement Method / Option Style | 17 | Their other users are Stage 2-3 domains (22, 25, 26, 28, 31, 33) or 01-16 lists. Revisit at Stage 2. |
| Vehicle Type, Regulatory Regime, Distribution Policy, MMF Type (mirrors of 01) | 17 | Would make 01 lists shared lists stewarded by 01, which changes 01. |
| Operating Model, Investment Transaction Type, Quantity Unit, Long / Short Indicator, Transaction Cost Category | 18 | Only 18 uses them today. Transaction Cost Category would also touch 01. |
| Accounting Basis, Plan Version Status, Plan Type, Plan Scenario, Payment Method, Tax Type, Financial Statement Type, Regulatory Return Type | 19 | Each would change a 10 or other 01-16 list (rename or merge), or waits for Stage 2-4 users. |
| Job Family, Regulated Role Category / SM&CR Population, Separation Reason, Gender Identity, Training Completion Status, Readiness | 20 | Each would change an 02, 08, 09 or 16 list, or has no second user. |
| System, Governance Certification Status, Governance Priority, Semantic Model, Data Product Business Function, Data Product Delivery Mode, Metric Aggregation Rule, Metric Unit | 21 | Only 21 uses them, or they should be generated from framework.py or register.py. |

## 3. Decision list for the program lead (proposed for 01-16, not applied)

| # | Proposal | Source | Decision needed |
|---|---|---|---|
| 1 | Add 12 Party Role Type values to 02 (Issuer, Guarantor, Portfolio Company, Depositary Bank, Loan Administrative Agent, Collateral Manager / Servicer, Third-Party Fund Manager / GP, Clearing House / CCP, Offeror, Numbering Agency, Rating Agency, Exchange Operator) | proposals_17 | Accept CD-143 |
| 2 | Widen 09 Industry Classification Scheme (ICS-) to investment classification schemes; add ICB, BICS, Firm Asset Class, Firm Industry Sector, Firm Credit Sector | proposals_17 | New CD under CD-154 |
| 3 | CUSIP Issuer Number and Bloomberg Company ID as 02 Party Identifier schemes (instead of columns on 17 Issuer Profile) | proposals_17 | CD-143 / CD-154 (SME) |
| 4 | Widen 01 Benchmark to every index used as a derivative underlying | proposals_17 | CD-154 |
| 5 | Make 01 Vehicle Type, Regulatory Regime, Distribution Policy and MMF Type shared lists stewarded by 01, with 17 as a user | proposals_17 | New code-list CD |
| 6 | Rename the 03 "Issuer Feedback" usage to "RFP Issuer" (term conflict Issuer) | proposals_17 | New CD |
| 7 | Create the shared Business Line list (18, 21) and rename 01 Business Line to "Client Segment" (LOCAL_RENAMES); agree whether Institutional Mandate and Proprietary / Seed are business lines | proposals_18, proposals_21 | New CD (changes 01) |
| 8 | Add "ETF Transparency Type" to 01 ETF Characteristics, so 18 Daily Holdings Publication Indicator becomes its copy | proposals_18 | CD-145 / new CD |
| 9 | Optional "Holding Portfolio" (PORT-) on 06 Position for own fund-of-funds holdings | proposals_18 | CD-146 |
| 10 | 12 reverse note: Cash Flow Notification (CFN-) feeds 18 Portfolio Capital Activity | proposals_18 | CD-145 |
| 11 | SMA sponsor program key: 05 AGR- (18) or PGM- (15) | proposals_18 | New CD (05) |
| 12 | Seed capital: one owner for 18 Proprietary Capital Indicator and the 15 Account Seed Capital Indicator gap (with 43) | proposals_18 | New CD |
| 13 | 10 TP Policy "TP Documentation Reference" re-typed to Reference (Transfer Pricing Documentation, 19) | proposals_19 | CD-149 or a CD-152 amendment |
| 14 | 10 Distribution Cost Item "Profit Center" (OU-PC-) re-typed to 19 Chart Segment Value, like the cost center references | consolidation finding | CD-152 amendment |
| 15 | Add VAT Registration Number to 02; 19 to master own-entity tax registrations and the 02 mirror PTY- to copy them | proposals_19 | CD-143 |
| 16 | Rename 10 "Scenario" to "Plan Scenario"; share Accounting Basis, Plan Version Status, Plan Type and Plan Scenario (10 / 19) | proposals_19 | New code-list CD |
| 17 | Shared Payment Method list (05, 12, 13, 15, 19) | proposals_19 | New code-list CD |
| 18 | Align the 10 US GAAP Taxonomy source URL to the FASB page | proposals_19 | New CD (10 Sources) |
| 19 | Add "Credited" to the 12 Fee Invoice Payment Status list, or map 19 Credited to Paid | proposals_19 | CD-158 |
| 20 | Rename the 10 family "Chart of Accounts & GL Posting" (it now holds only Account Mapping) and the 06 family "Data Quality & Reconciliation" (it now holds only reconciliations and breaks) | consolidation finding | CD-152 / CD-156 amendment |
| 21 | Add a Payroll Payment Instruction ID to 07 | proposals_20 | New CD |
| 22 | Add "Evidencing Learning Completion" (Reference to 20 Learning Completion) to 08 CE Requirement | proposals_20 | New CD |
| 23 | Retire the unused 03 local lists Employment Type and Employment Status (left from CD-120; they already drop out of the 03 workbook) | proposals_20 | CD-151 amendment |
| 24 | One 08-stewarded SM&CR list shared with 20 Regulated Role Category; align 16 Separation Reason, 02 Gender Identity and 08 CE Status labels with 20 | proposals_20 | New code-list CD (SME question 3 in 20) |
| 25 | Split 20 Org Unit Assignment "Assignment Effective From / To" into two dates; flag the 20 copies of placement data as derived within 20 | proposals_20, GAP-09-011 | CD-151 follow-up |
| 26 | Apply CD-148: Data Quality Status steward 09 to 21; mark CD-006 as superseded; Information Classification steward (21 or 41) | proposals_expansion, proposals_21 | Accept CD-148 |
| 27 | Rename the 14 family "Dataset & Data Product Catalog" to "Licensed Dataset Catalog" | proposals_21 | CD-160 |
| 28 | 04 Personal Data Classification mapped to 21 Personal Data Sensitivity | proposals_21 | New code-list CD |
| 29 | 09 Code List Data Owner / Data Steward derived from 21 Data Ownership Assignment | proposals_21 | CD-157 |
| 30 | 10 Profitability Measure Definition and 11 Market Share Definition certification as derived copies of 21 | proposals_21 | CD-163 extension |
| 31 | Consolidation check reconciling 14 Authoritative Source Indicator with 21 System of Record Designation | proposals_21 | CD-161 |
| 32 | Builder and baseline emit the stable name-path key next to the positional attribute ID | proposals_21 | CD-162 |
| 33 | Rename the enterprise workbook and documents to the enterprise scope (CD-150, end of Stage 1) | proposals_expansion | Accept CD-150 |

## 4. Data product layer follow-ups (not decisions)

- **Cost center joins.** The 10 cost center references are now typed to 19 Chart Segment Value. The logical models still join them to the DP-013 Org Unit dimension, through 19 Represented Org Unit, and keys REFS stay on 09 Org Unit (see keys_g7_17_21.py). A finance reference data product (chart of accounts, segment values, ledgers) is needed before the joins can point to 19.
- **Product register.** framework.py source-domain lists and owning domains are unchanged (CD-160 keeps the product register stable). DP-009, DP-012, DP-045, DP-056, DP-074, DP-075 and DP-089 now read 19, 20 or 21 objects.
- **New warning.** DP-056 has pii=N but consumes attributes that 20 marks as PII (Employee ID, Home Org Unit, Employment Type, Employment Status). The PII notes on the moved attributes come from the program lead's PII decision in 20. DP-056 notes already justify PII = N, because the product publishes at cost center level.
- **Generated output.** `semantic_model/build_semantic_model.py` writes `_cols` sets in a different order on each run, so `semantic_model/out/models/SM-00 ... SM-06.yaml` change with no change in content. This predates Stage 1; sorting the set in the generator would fix it.

## 5. Baseline reconciliation (check_baseline.py against distribution-v0.4)

`check_baseline.py --allow CD-151,CD-152,CD-156,CD-158,CD-163,CD-166` fails, as expected. It reports 19 sections: 15 Data Domains (13 is unchanged in the compared fields), the registers, data products, logical models and semantic models. Every reported difference traces to an allowed decision. None is unexplained.

### Data Domains 01-16

| Domain | Reported difference | Cause | CD |
|---|---|---|---|
| 01 | Ownership changed (Commentary Approval, Investment Commentary, Investment Strategy, Product Governance, Portfolio Manager Assignment) | Employee references and the three employee overrides resolve to 20 | CD-151 |
| 02 | Ownership changed (Restricted Client Status) | Employee reference resolves to 20 | CD-151 |
| 02 | Code list values changed | Data Provider gained 11 values (02 Data Vendor is a member) | CD-166 |
| 03 | Ownership / grain changed | Employee references resolve to 20; Sales Person grain text says "20 EMP-" | CD-151 |
| 03 | Attributes and family definitions changed | "mastered by HR in 09 Workforce" re-pointed to 20 | CD-151 |
| 04 | Ownership and attributes changed | Employee references resolve to 20; the Assigned Salesperson note is re-pointed | CD-151 |
| 05 | Ownership changed | Employee references resolve to 20 | CD-151 |
| 05 | Code list values changed | Payable Invoice Status and Outgoing Payment Status steward changed 10 to 19 | CD-158 |
| 06 | Objects 39 to 38, attributes 256 to 251, one local code list fewer, DQ Rule removed, family definition changed | DQ Rule and DQ Dimension moved to 21 | CD-156 |
| 06 | Derived +1, attribute changed (Measure Definition) | Certified Indicator is a derived copy of 21 | CD-163 |
| 06 | Ownership changed (Attribution Override, Salesperson Credit, Restatement, Snapshot) | Employee references resolve to 20 | CD-151 |
| 07 | References +1, derived -1 (Compensation Accrual GL Account) | Re-typed to Reference (GL Account, 19) | CD-152 |
| 07 | Attributes changed (Remuneration Conflict Assessment, Territory Salesperson Assignment, Plan Participant) | Identified Staff Indicator is a derived copy of 20 (owner 08 to 20); text re-pointed | CD-151 |
| 07 | Ownership changed | Employee references resolve to 20 | CD-151 |
| 07 | Code list values changed | Outgoing Payment Status steward changed 10 to 19 | CD-158 |
| 08 | Ownership and family definition changed | Employee references and Participants derived copy resolve to 20; the registration family text is re-pointed | CD-151 |
| 09 | Families 10 to 9, objects 52 to 49, attributes 263 to 239, CDEs 82 to 76, 3 local code lists fewer | Workforce family and Org Unit Assignment moved to 20 | CD-151 |
| 09 | Reference changes; Org Unit, Reorganization Event and relationships changed | Unit Head resolves to 20; the employs REL is re-pointed; SR-ORG positional IDs shift after the removal | CD-151 |
| 09 | Derived 4 to 3; Internal Legal Entity, Cost & Profit Center and Fiscal Period changed; code list values and relationships changed | Accounting Company Code and Fiscal Period Status are derived copies of 19; Cost and Profit Center Code reference 19; list source and description and REL re-pointed | CD-152 |
| 09 | Code list values changed | Business Domain gained Data Domains 15-21 | CD-166 |
| 10 | Objects 35 to 33, attributes 236 to 223, CDEs 71 to 68, 3 local lists fewer, relationships 28 to 29; GL Posting and Accounting Period Status removed; Account Mapping, Distribution Cost Item, Cost Pool, Plan Version, Plan Line changed; DF-BUD positional IDs shift | Moves, re-typing and the new Enterprise Financial Plan Version | CD-152 |
| 10 | Ownership changed (Profitability Record) | Employee reference resolves to 20 | CD-151 |
| 10 | Code list values changed | Business Domain values (10 Source Domain is a member) | CD-166 |
| 11 | Code list values changed | Data Provider values (11 Industry Data Provider is a member) | CD-166 |
| 12 | Derived +1, Fee Invoice changed | Payment Status is a derived copy of 19 | CD-158 |
| 12 | Ownership changed (service teams, requests and others) | Employee references resolve to 20 | CD-151 |
| 14 | Derived +1, Data Invoice changed | AP Document Reference is a derived copy of 19 | CD-158 |
| 14 | Ownership changed | Employee references resolve to 20 | CD-151 |
| 14 | Code list values changed | Business Domain values; Payable Invoice Status steward | CD-166, CD-158 |
| 15, 16 | Ownership changed | Employee references resolve to 20 | CD-151 |

### Registers

| Register | Reported difference | CD |
|---|---|---|
| Decisions | 23 added that name 01-16 (CD-143 to CD-166 except CD-147, which names only 17+) | Merge of proposals_expansion and proposals_21 (decision log); CD-166 itself |
| Decisions | CD-083 and CD-084 changed (amendment note) | CD-152 |
| Decisions | CD-120 changed (superseded note) | CD-151 |
| Prefixes | EMP-, JNL-, DQR- changed (26 added for 17+ are expansion additions) | CD-151, CD-152, CD-156 |
| Concept ownership | Employee changed | CD-151 |
| Concept ownership | Org Unit changed; "Cost / Profit Center Code and GL Account" replaced by "Account Mapping (management P&L line -> GL account)" | CD-152 |
| Term conflicts | 33 added that name 01-16; Account, Rating and Revenue changed | CD-166 |
| Shared code lists | 20 changed | Payable Invoice Status, Outgoing Payment Status: CD-158. Data Provider, Business Domain, Message Standard (values, definition), plus direct users on Approval Status, Case Status, Data Basis, Data Quality Status, Flow Direction, Frequency, Information Classification, Period Type, Personal Data Category, RAG Status, Reconciliation Status, Record Status, Regulator, Reporting Period Basis, Severity: CD-166 |

### Data products, logical models and semantic models

| Layer | Reported difference | CD |
|---|---|---|
| Data products | DP-009, DP-039, DP-044, DP-078, DP-082, DP-083 changed (09 Employee, Employee Reporting Line and Org Unit Assignment inputs read from 20) | CD-151 |
| Data products | DP-012, DP-056, DP-074, DP-089 changed (10 GL Posting, Accounting Period Status and Account Mapping attributes read from 19 Journal Entry, GL Posting, Accounting Period Status and Financial Statement Line Mapping, with their identifying attributes added); DP-056 also CD-151 | CD-152 |
| Data products | DP-045, DP-075 changed (06 DQ Rule read from 21 Data Quality Rule and Data Quality Result) | CD-156 |
| Data products | Input objects +7, attribute links +23; links by domain 06 -10, 09 -67, 10 -31, 19 +48, 20 +67, 21 +16 | CD-151, CD-152, CD-156 |
| Data products | New warning: DP-056 PII | CD-151 (PII notes on the moved 20 attributes) |
| Logical models | Entities +6, relationships +6: Journal Entry entities in DP-012, DP-056, DP-074 and DP-089; Statement Line Mapping in DP-012; DQ Result in DP-075 | CD-152, CD-156 |
| Logical models | DP-009, DP-011, DP-016 to DP-024, DP-026, DP-027, DP-032, DP-033, DP-036, DP-038 to DP-040, DP-042, DP-044, DP-046 to DP-048, DP-050, DP-051, DP-053, DP-054, DP-057, DP-061, DP-066 to DP-068, DP-073, DP-077, DP-078, DP-081 to DP-083, DP-092 changed (Employee attributes now come from 20 objects, directly or through the conformed DP-009 Employee) | CD-151 |
| Logical models | DP-013, DP-015, DP-029, DP-034, DP-035, DP-041, DP-059, DP-062, DP-072 changed: inherited definitions of 09 Fiscal Period Status, Accounting Company Code and 10 Distribution Cost Item Cost Center; DF-BUD positional IDs (DP-015, DP-055); DP-013 notes re-pointed | CD-152, CD-151 |
| Logical models | DP-008, DP-015, DP-029, DP-031, DP-055, DP-075 changed (inherited definition of Certified Indicator) | CD-163 |
| Logical models | DP-045, DP-056, DP-074, DP-075, DP-089, DP-012 (see above) | CD-152, CD-156 |
| Semantic models | Tables 285 to 286; SM-07 changed (intercompany_gl_posting reads the 19 GL Posting line; new intercompany_journal_entry table for the posting period and legal entity) | CD-152 |

Expansion additions (not failures): the five 17-21 modules, CD-147, 26 prefixes, 37 concept owners and one term conflict (Payroll) that name only Data Domains 17+.
