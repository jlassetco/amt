# Stage 2 consolidation notes (2026-10-06)

The Stage 2 consolidation merged Data Domains 22 to 30 into the enterprise registers and applied the agreed moves and re-pointings to Data Domains 01 to 21 (Enterprise_Expansion_Plan.md §9.3 step 5). This file records:
- what was applied
- what was deferred, and the decision each deferred item needs
- the reconciliation of every difference that `check_baseline.py` reports against `stage1-v0.1`

The new baseline is `baseline/stage2-v0.1.json`. Unlike the two earlier baselines, it records Data Domains 01-30 in full (see §4), so Stage 3 is checked against all thirty.

## 1. Decisions applied

| Decision | Status | What changed |
|---|---|---|
| CD-143 | Applied in part | 33 Party Role Type values proposed by 22, 25, 26, 28, 29 and 30 were deduplicated and added to the 02 list. "Tri-Party Agent" (26) and "Tri-Party Collateral Agent" (28) became one value; "Clearing Broker / FCM" (25, 26), "Central Securities Depository" (26, 28) and "Research Provider" (23, 25) appear once. The 17 values from Stage 1 and 23's two values stay open (§3 item 1). |
| CD-153 | Applied (with CD-168) | 19 Applied Exchange Rate on GL Posting and GL Account Balance re-noted as Derived copies of 22 FX Rate Observation. The 19 overview names 22 and 27 instead of "future". |
| CD-155 | Applied (option A) | Standing Settlement Instruction and the lists SSI Asset Class, Settlement Message Standard and SSI Verification Status were removed from 12. Before deletion I verified that 26's copies are identical apart from the row-rule note on Safekeeping Account. SSI- is registered to 26 and CPSI- is retired. 12 Custody Account gained "Created Standing Settlement Instructions" (Reference SSI-, 26, multi). Also changed: the 12 family definition, overview, relationships, sources (DTCC ALERT and sese.023 rows removed, since 26 holds them), enrich_12 grain and derived entries, and the 18 relationship note. DP-086 was re-pointed: spec inputs, the model entity and the keys, which moved to the new `data_models/keys_g8_22_30.py`. 26 SSI ID is now a CDE. The two enrich_26 overrides were dropped. |
| CD-167 | Applied | 18 Price Used, Price Date and Price Source are Derived copies of 22 Approved Price (Approved Price Value, Price Date, Approved Price Basis). Price Date and Price Source were redefined. The Price Source list is "External (22 Approved Price Basis)", correcting the CD text, which said "Price Source Type". 18 Delta Used names 22 Pricing Analytics Observation. 17 Securitized Product Terms and Rate Fixing Date name the 22 objects. |
| CD-168 | Applied, amended | 18 Holding FX Rate and Cash FX Rate name 22 FX Rate Observation. 18 Trade FX Rate carries the row rule: a copy of 22 for market-rate rows, derived from 25 Execution.Executed FX Rate for executed FX trades. The conversion rule from proposals_25 was added to the CD text. 06 FX Rate Applied is unchanged (§3). |
| CD-170 | Applied | 18 Adjusted NAV is a Derived copy (22) of the approved Fair Value Determination.Fair Value Amount and was redefined. GP Reported NAV stays mastered in 18. |
| CD-174 | Applied | 18 Commission Amount and Research Payment Component are Derived copies (25) of Allocation Cost Detail on allocation rows (row rule). |
| CD-180 | Applied | 18 Source Allocation ID re-typed to Reference (Trade Allocation, 25) with an ALLOC- example. The relationship is no longer marked "future". |
| CD-181 | Applied, rewritten | The resolution now carries 26's row rules (a) to (d). 18 Settlement Confirmed Indicator, Initial Margin Posted and Encumbered Quantity name the 26 objects; Encumbered Quantity adds 28 on-loan quantity. Settled and Unsettled Quantity are noted "computed from 26 Settlement Status Event". |
| CD-188 | Applied | 10 Waiver Record Waived Fee Amount and Reimbursed Expense Amount are Derived copies (27) of Expense Cap & Waiver Accrual. |
| CD-189 | Applied | 13 Servicing Error gained Related NAV Error Case (NEC-, 27). NAV Error Magnitude and Materiality Threshold Exceeded Indicator are Derived copies (27); the definition now says "reaches or exceeds". |
| CD-194 | Applied (option A) | 12 Custody Account gained Created Safekeeping Account (SKA-, 28). Its Safekeeping Account Number is a Derived copy (28); Custodian BIC stays a Derived copy (02) of the account provider's BIC, now noted. 18 Safekeeping Custody Account re-typed to SKA- and widened to every book. 18 Cash Account Number is replaced by Cash Safekeeping Account (SKA-). 18 Cash Custodian is noted as the account provider of that account (it stays a 02 party reference: a Reference type cannot also be flagged Derived copy). 15 Account Identifier Value is a Derived copy (28) under a row rule for Custodian Account Number rows of SMA and mandate accounts. |
| CD-199 | Applied | 13 Service Request gained Resulting Order (FNDO-, multi). 06 Transaction gained Originating Fund Order (FNDO-). 06 Order Entry Channel, Order Message Type, Trade Date and As-Of Date are Derived copies (29) for TA-processed rows, with the row rule in Notes. |
| CD-200 | Applied in part | 06 Transaction gained Originating AP Order (ECR-, 29). The rest is in §3. |
| CD-209 (new) | Applied | A shared Business Line list (six values, steward 09) was created. 18 and 21 are members, and 21's Institutional Mandate and Proprietary / Seed map to none, pending SME review. 24 and 27 are direct users. The 01 list was renamed "Client Segment" in LOCAL_RENAMES; the 01 attribute keeps its name for now (§3). |
| CD-210 (new) | Applied | Stage 2 register consolidation (§2). |

**Merged with status Proposed:**
- CD-169, CD-171 to CD-173, CD-175 to CD-179, CD-182 to CD-187, CD-190 to CD-193, CD-195 to CD-198 and CD-201 to CD-205, from proposals_stage2_a and proposals_stage2_b.
- CD-206 to CD-208 (new). These come from proposals_22 (ETF market statistics), proposals_27 and 29 (NAV release vs price transmission) and proposals_24 and 30 (private deal approvals).

**Text corrections made while merging:**
- CD-174 names "Research Evaluation Round".
- CD-187 names "Approved Price" and "Fair Value Determination".
- CD-200 names "ETF Basket" and "Settlement Instruction".

**Working assumptions:** CD-175 (option B) and the other working assumptions stay Proposed, because they change nothing in 01-21.

## 2. Registers (CD-210)

**Prefix renames.** Eight reserved prefixes were one letter apart from, or an anagram of, another new prefix. Each was renamed in its owner's content, enrichment, proposals and Source_Notes, and in every sibling that used it. The briefs and reviews were left as historical records.

| Reserved | Registered | Owner | Why |
|---|---|---|---|
| CREC- | CUREC- | 28 | One letter from RREC- (23). CRCN- was rejected: one letter from CCN- (30). |
| CAEL- | ELECT- | 28 | One letter from CAEN- and one insertion from CAL- (09) |
| DVD- | FDIV- | 27 | One letter from FVD- (22). The F matches FJNL- and FTAX-. |
| FCL- | CLOSE- | 30 | One letter from FCF- (30). FCLS- was rejected: one insertion from FCS- (03). |
| SCA- | SCAC- | 28 | One letter from SKA- (28) and TCA- (25) |
| TAO- | FNDO- | 29 | One letter from TAS- and TAC-. FORD- (the suggested name) was rejected: one letter from TORD- (25). |
| TAS- | FBAT- | 29 | One letter from TAO- and TAC- |
| TAC- | TACK- | 29 | One letter from TAO- and TAS-, and an anagram of TCA- (25) |

**Kept:**
- CAEN- is kept as a deliberate member of the CAE- family.
- The pairs flagged against the existing register are accepted: CCN-~CCA-/RCN-/CFN-/CCI-, CIP-~ICP-/CTP-/CMP-, CMC-~CMT-/CMP-, ECR-~ACR-/ERR-, FXR-~FRR-, IDX-~IDR- and OTC-~FTC-/ATC-. Each differs in its first or last letter from a prefix in another domain, and no two of them are in the same domain.

**Registered:**
- 53 Stage 2 prefixes are registered.
- IDX- stays Proposed, because it is the CD-169 option B contingency.
- CPSI- is Retired.
- SSI- moved from 12 (Proposed) to 26 (Registered).

**Key formats.** A new `PREFIX_FORMATS` section in decisions.py records the owner's format and an example for all 53 Stage 2 prefixes. Sibling examples were aligned to them:
- 23 PRICE-
- 24 RREC-
- 26 PRICE-
- 27 PRICE-, FVD- and TACK-
- 28 PRICE-
- 29 SKA- and NAV- (three)
- 30 SKA-

29's BSKT- example and 22's DSET- examples were already aligned. The 09 and 11 DSET- examples use four digits instead of 14's five; they are 01-16 examples, so they are listed in §3.

**Concept ownership.** 84 rows were added for the Stage 2 masters. Referencing domains come from a scan of references and derived copies after the merge. Two rows were re-noted: 12 Custody Account Set-Up (now the workflow record that references SKA- and SSI-) and 09 Currency and FX Rate Type (observations are 22 FXR-).

**Ownership aliases** (ownership.py): price, approved price, FX rate observation, fair value determination, research recommendation, investment decision, ETF basket, trade order, block order, execution, trade allocation, settlement instruction, standing settlement instruction, fund journal entry, NAV, share class NAV, safekeeping account, fund order, commitment, investor commitment, capital account, investor capital account, capital call and deal. "Distribution" and bare "order" were not aliased. 22 asked for no bare "price" alias; it was added as the program lead instructed. No 01-21 reference target matches any of the new aliases (checked by scan).

**Term conflicts.** 55 terms were added. Synonymous entries were merged: Coverage / Coverage Role; Custody Account / Safekeeping Account; Reconciliation and Reconciliation / Control Check; NAV Release / Price Transmission. Six existing terms were extended: Position, Rating, Transaction, Due Diligence / DDQ, Agreement / Contract / License, and Business Line (CD-209).

**Shared lists:**
- 22-30 were registered as direct users of the 21 shared lists they copied, and their local copies were removed in the same step. Every copy was label-identical apart from the values added below, so no value changed. Every attribute now shows "Shared: <name>".
- Values added:
  - Message Standard: FIX (once), ISO 20022 sese, colr, pacs, seev, camt and reda, and FpML. Its definition was widened.
  - Data Provider: S&P Dow Jones Indices, J.P. Morgan PricingDirect, Tradeweb, MarketAxess, STOXX, Solactive and FINRA.
- New list Business Line (CD-209).

**Ownership overrides dropped** (they existed only because a prefix was unregistered): enrich_26 (Applied Own SSI, Applied Counterparty SSI), enrich_27 (Related Income Collection) and enrich_30 (Platform Company). The others remain, because their composite example keys start with another domain's prefix (PRD-, PTY-, STR-, PORT-, BMK-, LEN-); concept rows cannot fix that, since the example prefix takes precedence in ownership.py. enrich_22 and enrich_29 had none.

### Candidate shared lists deferred

| Candidate | Raised by | Why deferred |
|---|---|---|
| Operating Model (IBOR, pricing, trading, fund accounting, administration, NAV calculation source) | 18, 22, 25, 27, 30 | Would change 18 IBOR Operating Model (CD-147). The value sets differ (27 adds Outsourced with Shadow NAV and Trustee Bank; 22 adds Sponsor or Client Priced). |
| Price Type, Price Origin, Approved Price Basis, Fair Value Hierarchy Level, Rate Tenor, Measure Unit, Observation Status | 22 (users 18, 25-28, 30, 35) | Only 22 has them today. Measure Unit is copied locally by 30. |
| Asset Class / Instrument Asset Class, Trading Asset Class | 24, 25 (01, 17) | Would change 01 Asset Class |
| ETF Basket Type / Basket Settlement Form | 24, 29 (06) | Would split the 06 list |
| Trade Side / Order Side, Trade Allocation Method, Counterparty Approved Activity, Review Outcome | 24, 25, 26 | Only Stage 2 users so far; some wait for 31 and 33 |
| Settlement Type, Trade Settlement Status / Order Settlement Status, Collateral Type, Regulatory Trade Report Regime, Regulatory Report Status, Contract Type | 26, 28, 29 | Value sets not yet reconciled (Failing / Failed, Returned / Reversed); 10 Settlement Status stays not merged |
| Accounting Basis, Waiver Type, Investment Income Type, NAV Dissemination Channel | 27 (19, 10, 18, 28, 29) | Each would change a 10 or 19 list, or needs 27 and 29 to agree the channel list (CD-207) |
| Custody Holding Model, Custodian Balance Type, Exception Type, Tax Relief Method | 28 (13, 18, 26, 27, 29) | 13 Holding Model is a different concept; an exception list would touch 06 |
| Cost Bearer, Fund Dealing Settlement Method, Payment Method | 29 (13, 05, 19) | Each would change a 05, 13 or 19 list |
| Internal Credit Rating Scale, Credit Outlook, Research Subject Type, Meeting Channel, Committee Member Role | 23, 24 (17, 03, 21, 22) | Second users are Stage 3 or 01-21 lists |
| Private Fund Strategy, Capital Call Purpose, Portfolio Company Ownership Type | 30 (01, 17) | Private Fund Strategy is to become 01 sub-asset-class values (changes 01) |

## 3. Decision list for the program lead (proposed for 01-21, not applied)

| # | Proposal | Source | Decision needed |
|---|---|---|---|
| 1 | 02 Party Role Type: the Stage 1 values from 17 not raised again (Issuer, Guarantor, Portfolio Company, Depositary Bank, Collateral Manager / Servicer, Third-Party Fund Manager / GP, Clearing House / CCP, Offeror, Numbering Agency, Rating Agency, Exchange Operator), and 23's Expert Network and Corporate Access Provider | proposals_17, proposals_23 | CD-143 (complete it) |
| 2 | 02 Identity Document record (party x document type x issuing country, masked number, dates) for 31 CFR 1024.220 | proposals_29 | New CD under CD-201 |
| 3 | Optional 02 classification for benefit plan investors | proposals_30 | New CD (low) |
| 4 | 01: widen Benchmark to every index used as an underlying, research index or curve input (22 index data depends on it) | proposals_22 | CD-169 option A |
| 5 | 01 Portfolio Manager: re-type from Reference (Party) to Reference (Employee), so the 24 consistency check can join | proposals_24 | CD-175 (option B follow-up) |
| 6 | 01 attribute "Business Line" renamed "Client Segment" (the list is already renamed) | CD-209 | CD-209 amendment |
| 7 | 01 ETF Transparency Type (Stage 1 item 8) | proposals_18 | CD-145 / new CD |
| 8 | 01 Return Type shared with 22 Index Level Variant | proposals_22 | New code-list CD (CD-169) |
| 9 | 01 Gross / Net Expense Ratio as a Derived copy (27) for annual-report figures (row rule) | proposals_27 | New CD (SME question 10 in 27) |
| 10 | 01 maximum on-loan percentage as a policy limit (28 holds it provisionally) | proposals_28 | CD-198 |
| 11 | 01 Private Fund Strategy values as 01 sub-asset-class values | proposals_30 | New CD (CD-205) |
| 12 | 05 Agreement Type "Authorized Participant Agreement", if missing | proposals_29 | CD-200 |
| 13 | Rename 05 "Trading Setup" to "Fund Dealing Setup"; merge 05 Settlement Method into the 29 Order Settlement Method (or rename it via LOCAL_RENAMES) | proposals_25, _26, _29 | New CD (CD-185) |
| 14 | 06 FX Rate Applied as a Derived copy (22) | proposals_22 | CD-168 (accept the 06 part) |
| 15 | 06 Intermediary As Delivered codes and Source Transaction Reference as Derived copies (29) for TA-processed rows; Representative Number PII flag | proposals_29 | CD-199 extension |
| 16 | 06 ETF Creation / Redemption: Authorized Participant, Creation Units and Basket Type as Derived copies (29); split the 06 Basket Type list | proposals_24, _29 | CD-200 and a code-list CD |
| 17 | 06 Transaction Price note: "as delivered; official NAV is 27" | proposals_27 | CD-187 |
| 18 | 06 Flow Treatment Rule "Private Fund Treatment" | proposals_30 | CD-204 |
| 19 | 06 reconciliation value "TA vs Fund Accounting": rename or retire in favor of 29 TACK- | proposals_29 | CD-196 |
| 20 | 08 "Alert ID" renamed "Surveillance Alert ID" | proposals_29 | New CD |
| 21 | 09 Calendar Type "Settlement (CSD / Payment System)", or document "Banking / Settlement" | proposals_26 | CD-185 |
| 22 | 09 and 11 DSET- examples to 14's five-digit format (DSET-0042 to DSET-00042, and so on) | consolidation finding | CD-138 amendment |
| 23 | 10 Waiver Type shared with 27 | proposals_27 | New code-list CD (CD-188) |
| 24 | 13 Tax Form Record "Schedule K-1" type, referencing 30 Partner Tax Allocation and holding no box amounts | proposals_30 | CD-149 / CD-205 |
| 25 | 13 Cost Bearer shared with 27 and 29 | proposals_29 | New code-list CD |
| 26 | 15 Account Type "Private Fund Investor Account" | proposals_30 | CD-203 |
| 27 | 15 relationship: Account is the owner of a 28 Safekeeping Account (via Safekeeping Account Assignment) | proposals_28 | CD-194 |
| 28 | 16: no change requested | | |
| 29 | 17 FX contract instrument type (spot, forward, swap, NDF), so FX orders and holdings can reference INS- | proposals_25 | New CD (CD-168 / CD-180) |
| 30 | 17 Class Action event case facts (case name, court, class period, filing deadline) | proposals_28 | CD-195 |
| 31 | 17 Fund Interest Terms (vintage year, strategy, commitment currency, final close, periods) as Derived copies (30) for own private funds | proposals_30 | CD-203 / CD-205 |
| 32 | 17 Credit Rating Outlook shared with 23 as "Credit Outlook" | proposals_23 | New code-list CD |
| 33 | 18 own-private-fund row rules from 30: Fund Interest Holding Detail (commitment, called, recallable, unfunded, distributions, GP NAV and date, Adjusted NAV), Private Fund Portfolio Detail (Vintage Year, Subscription Credit Facility Indicator) and Portfolio Capital Activity (capital calls and distributions, with references to CCN- and PDIS-) | proposals_30 | CD-203 / CD-204 / CD-205 |
| 34 | 18 trade fields as Derived copies (25) on allocation rows: Principal Amount, Net Settlement Amount, Transaction Price, Trade Date, Exchange and Clearing Fee Amount (with the 25 regulatory fee), Transaction Tax Amount, Accrued Interest Amount, Contractual Settlement Date | proposals_25 TRADE_FIELD_MAPPING | CD-180 / CD-174 amendment |
| 35 | 18 FXR- references beside Holding FX Rate and Cash FX Rate | proposals_22 | CD-168 |
| 36 | 18 Portfolio Capital Activity "Source Settlement Batch" (FBAT-, 29) | proposals_29 | CD-199 extension |
| 37 | 18 Portfolio Identifier "Accounting System Fund Code" as a Derived copy of 27 Book Code | proposals_27 | CD-186 |
| 38 | 18 Cash Account Purpose replaced by the 28 Account Assignment Purpose | proposals_28 | CD-194 |
| 39 | 19 Accounting Basis shared with 27; 19 Payment Method shared with 29 (Stage 1 item 17) | proposals_27, _29 | New code-list CD |
| 40 | 20 to confirm it holds the work location or entity for 24 Decision Supervising Branch Country (RTS 22 field 58) | proposals_24 | New CD (low) |
| 41 | 21 metric definitions: Private Fund Commitments Raised, Capital Called, Distributions and Net Invested Capital | proposals_30 | CD-204 |
| 42 | 21 Business Line values Institutional Mandate and Proprietary / Seed (mapped to none) | CD-209 | SME review under CD-209 |
| 43 | 26 SSI "Safekeeping Account": re-type CUA- to SKA- and retire Own Safekeeping Account into it. Needs DP-086 re-modeled to join SSIs to 12 Custody Account through Created Safekeeping Account | proposals_26, _28 | CD-194 consequence |

Within the new domains (no 01-21 change; for the CD owners):
- 24 / 30 private deal approvals (CD-208).
- 27 NAV Dissemination renamed "NAV Release" (CD-207).
- 27 and 28 to agree the composite keys of Income Accrual and ABOR Valuation Record. 28 should key Related Income Collection by the CAEN- of the income entitlement.
- 27 Shares Outstanding master (27 or the 29 register).
- 25 Large Trader ID to 38 when it exists.

## 4. Data product layer and tooling follow-ups (not decisions)

- **DP-086 Mandate Readiness** reads the SSI from 26. It still joins SSIs to the 12 Custody Account through "Safekeeping Account" (CUA-), which is why §3 item 43 is deferred. The new keys file `data_models/keys_g8_22_30.py` registers only the 26 SSI.
- **check_baseline.py** now protects every Data Domain merged so far. A new snapshot (other than distribution-v0.4) records all content modules in full, and the snapshot's `meta.domains` drives the comparison. Older baselines keep comparing 01-16 in full, and they now also report count changes in any domain they recorded by counts only. Against stage1-v0.1 that showed 18 (references +2).
- **Example shapes of older prefixes** used in 22-30 differ from their owners' examples (for example ACC- 8 digits in 28 vs 7 in 15, PTY- 7 digits in 23 and 30, INS- 7 digits in 29, OU- shapes in 23 and 24). Only Stage 2 formats were published, so these were not changed. Stage 3 should publish formats for the Stage 1 and distribution prefixes.
- **Semantic model output** still writes `_cols` sets in a different order on each run (Stage 1 §4), so `semantic_model/out/` files may change with no change in content.

## 5. Baseline reconciliation (check_baseline.py against stage1-v0.1)

`check_baseline.py --check stage1-v0.1 --allow CD-143,CD-153,CD-155,CD-167,CD-168,CD-170,CD-174,CD-180,CD-181,CD-188,CD-189,CD-194,CD-199,CD-200,CD-209,CD-210` fails, as expected. It reports 13 sections:
- 01-16: 01, 02, 05, 06, 10, 11, 12, 13 and 15
- 18, by counts
- the registers, data products and logical models

stage1-v0.1 records 17-21 by counts only. A full pre-merge snapshot of 01-30, taken before any change, was used to reconcile 17-21 in detail as well. Every reported difference traces to an allowed decision. None is unexplained. Semantic models are unchanged.

### Data Domains 01-21

| Domain | Reported difference | Cause | CD |
|---|---|---|---|
| 01 | Attributes and code list values changed (Firm Product Classification) | List "Business Line" renamed "Client Segment" (LOCAL_RENAMES) | CD-209 |
| 02 | Code list values changed | 33 Party Role Type values; Data Provider values (02 Data Vendor is a member) | CD-143, CD-210 |
| 05 | Code list values changed | Message Standard values (05 is a member) | CD-210 |
| 06 | Attributes 251 to 253, references +2 | Originating Fund Order (FNDO-), Originating AP Order (ECR-) | CD-199, CD-200 |
| 06 | Derived +4, ownership changed | Order Entry Channel, Order Message Type, Trade Date, As-Of Date are Derived copies (29) with a row rule | CD-199 |
| 06 | Objects in the Transactions family changed | Positional attribute IDs shift after the two new attributes | CD-199 |
| 06 | Code list values changed | Message Standard values (06 is a member) | CD-210 |
| 10 | Derived +2, Waiver Record changed | Waived Fee Amount, Reimbursed Expense Amount are Derived copies (27) | CD-188 |
| 11 | Code list values changed | Data Provider values (11 is a member) | CD-210 |
| 12 | Objects 37 to 36, attributes 243 to 235, CDEs 80 to 74, local lists 46 to 43, Standing Settlement Instruction removed, family definition, relationships 35 to 36, sources changed | SSI and its three lists moved to 26 (10 attributes and 6 CDEs out); the relationship to Custody Account replaced by two "caused the creation of" rows; SSI-only sources removed | CD-155 |
| 12 | References +1, derived -1, Custody Account changed | Created Safekeeping Account (SKA-) and Created Standing Settlement Instructions (SSI-) added, and the SSI's one cross-domain reference (SSI Mandate) removed; its Safekeeping Account pointed within 12. Safekeeping Account Number Derived copy (28) added, the SSI's two derived copies removed. Custodian BIC re-noted. | CD-194, CD-155 |
| 12 | Cash Flow Arrangement, Client Data Feed, Transition Event changed | Positional attribute IDs in the family shift after the SSI removal | CD-155 |
| 13 | Attributes 228 to 230, references +2 | Resulting Order (FNDO-) | CD-199 |
| 13 | Attributes 228 to 230, references +2 | Related NAV Error Case (NEC-) | CD-189 |
| 13 | Derived +2, Servicing Error changed | NAV Error Magnitude, Materiality Threshold Exceeded Indicator are Derived copies (27); definition reworded | CD-189 |
| 13 | Other Shareholder Service Requests & Interactions objects changed | Positional attribute IDs shift | CD-199 |
| 15 | Derived +1, Account Identifier changed | Account Identifier Value is a Derived copy (28) with a row rule | CD-194 |
| 17 | Code list values changed (detail from the pre-merge snapshot) | Message Standard and Data Provider values (17 is a direct user) | CD-210 |
| 17 | Coupon Schedule and Securitized Product Terms text | Name the 22 objects | CD-167 |
| 18 | References 33 to 35 (reported by counts) | Source Allocation ID re-typed to Reference (25); Cash Account Number replaced by Cash Safekeeping Account (28) | CD-180, CD-194 |
| 18 | Derived 12 to 14 (detail) | +Adjusted NAV (22), +Commission Amount and +Research Payment Component (25), -Source Allocation ID | CD-170, CD-174, CD-180 |
| 18 | Re-noted attributes (detail) | Prices, FX rates, delta, settlement and collateral notes; Safekeeping Custody Account re-typed to SKA-; two relationships | CD-167, CD-168, CD-181, CD-194, CD-155 |
| 18 | Business Line becomes "Shared: Business Line" (local -1, shared +1) | Shared list | CD-209 |
| 19 | GL Posting and GL Account Balance changed (detail) | Applied Exchange Rate notes name 22 FX Rate Observation | CD-153, CD-168 |
| 20 | No difference | | |
| 21 | Business Line becomes "Shared: Business Line" (local -1, shared +1); System of Record Designation changed (detail) | Shared list; two values map to none | CD-209 |

### Registers

| Register | Reported difference | CD |
|---|---|---|
| Decisions | 39 added that name 01-16 (CD-167 to CD-210, except CD-181, CD-183, CD-184, CD-206 and CD-208, which name only 17+) | Merge of proposals_stage2_a and _b and of the decisions the proposals asked for (decision log); CD-209 and CD-210 themselves |
| Decisions | CD-143, CD-153, CD-155 changed (status Applied, applied note) | CD-143, CD-153, CD-155 |
| Prefixes | SSI- changed (12 Proposed to 26 Registered). The 53 other additions name only 22-30. | CD-155 |
| Concept ownership | Currency and FX Rate Type, Custody Account Set-Up re-noted. The 84 additions name only 22-30. | CD-168, CD-194 (recorded under CD-210) |
| Term conflicts | 41 added that name 01-16; Agreement / Contract / License, Due Diligence / DDQ, Position, Rating and Transaction extended | CD-210 |
| Term conflicts | Business Line changed | CD-209 |
| Shared code lists | Business Line added | CD-209 |
| Shared code lists | Message Standard and Data Provider changed (values, definition) | CD-210 |
| Shared code lists | Agreement Status, Approval Status, Case Status, Data Basis, Dealing Route, Flow Direction, Frequency, Information Classification, Networking Level, Outgoing Payment Status, Period Type, Reconciliation Status, Record Status, Regulator, Reporting Period Basis, Risk Rating, Screening Result, Sentiment, Severity changed (direct users 22-30 added) | CD-210 |
| Local renames | 01 Business Line to Client Segment | CD-209 |

### Data products, logical models and semantic models

| Layer | Reported difference | CD |
|---|---|---|
| Data products | DP-086 changed; links by domain 12 -10, 26 +10 (SSI inputs read from 26) | CD-155 |
| Data products | DP-086 note on the 12 Custody Account | CD-194 |
| Logical models | DP-086 changed (SSI entity reads 26; Custody Account inherits the new derived note) | CD-155, CD-194 |
| Logical models | DP-006, DP-024, DP-025, DP-032, DP-047, DP-050, DP-051, DP-058, DP-060, DP-076, DP-084, DP-091, DP-095 changed: inherited 06 Transaction, Order Source and Transaction Dates definitions, flags and positional IDs | CD-199 |
| Logical models | DP-024, DP-032, DP-047, DP-058, DP-060, DP-084, DP-091 also changed: 01 Investment Product Business Line code list now "Client Segment" | CD-209 |
| Logical models | DP-043, DP-061, DP-070, DP-085 changed: 13 Service Request (and, for DP-043, 13 Servicing Error); DP-061, DP-070 and DP-085 also 06 | CD-199, CD-189 |
| Logical models | DP-068 changed: positional IDs of 12 Transition Event and the other Mandate Operational Set-Up objects after the SSI removal | CD-155 |
| Semantic models | No difference | |

Expansion additions (not failures):
- the nine 22-30 modules
- the 53 Stage 2 prefixes other than SSI-
- 84 concept owners
- term conflicts and decisions that name only 17+

Against `distribution-v0.4` (`--allow` with the Stage 1 and Stage 2 decisions), the check reports 20 sections. Domains 03, 04, 07, 08, 09, 14 and 16 match stage1-v0.1, so their differences are the Stage 1 ones in stage1_consolidation_notes.md §5. The other differences are the union of that table and the one above. `--check stage2-v0.1` passes.
