# Stage 3 consolidation notes (2026-10-06)

The Stage 3 consolidation merged Data Domains 31 to 36 into the enterprise registers and applied the agreed moves and re-pointings to Data Domains 01 to 30 (Enterprise_Expansion_Plan.md §9.3 step 5), following the program lead's rulings for this merge. This file records:
- what was applied
- what was deferred, and the decision each deferred item needs
- the reconciliation of every difference that `check_baseline.py` reports against `stage2-v0.1`

The new baseline is `baseline/stage3-v0.1.json`. It records Data Domains 01-36 in full, so Stage 4 is checked against all thirty-six.

## 1. Decisions applied

| Decision | Status | What changed |
|---|---|---|
| CD-022 | Superseded | Closed by CD-232. The status is now "Superseded" and the resolution names CD-232. |
| CD-143 | Applied further | Seven Party Role Type values added to the 02 list: Risk Model Vendor (31); Proxy Advisor, Proxy Voting Agent, Collaborative Engagement Initiative, Stewardship Framework Body (34); Independent Fund Director / Trustee, Independent Counsel to Fund Directors (35). 35's other four values are in §3 item 3. |
| CD-180 | Confirmed | 25 Trade Order Event Compliance Check Outcome (already flagged Derived copy (33)) now carries the row rule: per order (each member order of a block), the outcome of the latest 33 run before release that covered the order; a second Compliance Checked event after an override. The stale 25 relationship "Compliance Check [33]" names Compliance Check Run and Check Subject Member. |
| CD-212 | Applied | 01 Product Risk Indicator Summary Risk Indicator (SRI) and SRRI are Derived copies (31) of Product Risk Indicator Calculation.Calculated Indicator Value: the latest approved calculation of type PRIIPs SRI or UCITS SRRI for the share class. |
| CD-218 | Applied (option A, reworded) | 01 GIPS Composite Composite Member is a Derived copy (32): the products and mandates implemented by the composite's current member portfolios, rolled up from 32 Composite Membership through 18 Portfolio Implementation Link. It was re-typed from Reference (Product / Mandate) to Text, because a Reference cannot also be flagged Derived copy. Its link in `data_models/keys_g1_01_02.py` was removed (no model used it as a foreign key). The 01 relationship note was updated. |
| CD-221 | Applied in part | The 25 part, with CD-180: Compliance Check Outcome row rule and the shared list (CD-242). The 01 and 12 proposals are in §3. |
| CD-222 | Applied | 12 Breach Notification gained Related Investment Breach (Reference (Investment Breach, 33), BREACH-2026-00143, CDE). Breach Type, Breach Detected Date, Cure Action and Cure Date are Derived copies (33). Breached Restriction stays a reference to 01 RST- with a note that its value is the 33 breach's. A relationship row "Breach Notification reports Investment Breach [33]" was added. The 12 Breach Type and Cure Action lists are now shared lists stewarded by 33 (CD-242). |
| CD-225 | Applied, amended | CD-237 prevails for board and trustee approvals: the approval link is held only on 35 Resolution Subject Link. The withdrawn sentence and the amendment are in the resolution text. Sibling names were aligned. |
| CD-226 | Applied | 17 Corporate Action Event Type gained Annual General Meeting (MEET), Extraordinary General Meeting (XMET), Ordinary General Meeting (OMET), Bondholder Meeting (BMET) and Court Meeting (CMET). 17 Corporate Action Event gained Meeting Date. The 17 family definition says investee meetings are 17 events, with their agenda items, ballots and votes in 34. This is the one 17 change agreed in Stage 3. |
| CD-230 | Applied (verified) | 34 holds no filing reference. 35 Filing Document.Filed Proxy Voting Report carries each series' Proxy Voting Report; its example now uses the 34 key format. |
| CD-232 | Applied | 10 Revenue Contract Underlying Agreement is typed Reference (Fund Advisory Agreement / Mandate / Agreement), with a row rule: ADVA- on rows of type "Investment Advisory Agreement (Fund)", MND- on mandate rows, AGR- on distribution rows. The example stays MND-, so the flag still resolves to 01. The 10 relationship names 35 ADVA-. |
| CD-233 | Applied in part (verified) | There is one 35 REGF- record per filing, and 36 Change Regulatory Requirement.Satisfying Filing holds the change-to-filing link. 35 holds no Originating Change Initiative. The CD wording was corrected as proposals_36 asked. The 01 and 13 derived copies are in §3. |
| CD-237 | Applied | 33 Guideline Waiver "Approving Board Resolution" (Reference (Board Resolution, 35)) was replaced by "Board Approval Date", a Derived copy (35) read through Resolution Subject Link. The 33 scope, relationship and summary text were aligned. 31, 34 and 36 already held no approval reference. 13 and 27 hold none (checked: neither has a board approval attribute). |
| CD-240 | Applied | The reserved prefixes were registered under CD-241. |
| CD-241 (new) | Applied | Stage 3 register consolidation (§2). |
| CD-242 (new) | Applied | Six shared lists created (§2). |

**Merged with status Proposed:** CD-211, CD-213 to CD-217, CD-219, CD-220, CD-223, CD-224, CD-227 to CD-229, CD-231, CD-234 to CD-236, CD-238 and CD-239. They change nothing in 01-30 at this stage, or their 01-30 parts are deferred to §3.

**No decision proposals inside proposals_31 ... proposals_36.** None of the six files carried a DECISIONS section, so nothing was renumbered. The new decisions start at CD-241.

**Text corrections made while merging.** The sibling names below were replaced by the names in the drafted modules:
- CD-211: Instrument Factor Loading
- CD-213: 35 Fund Regulatory Filing, Filing Data Source, Reportable Fund Event
- CD-216 and CD-229: 34 Issuer Sustainability Observation and Portfolio Sustainability Metric, which absorbed Portfolio Climate Metric and PAI Indicator Result
- CD-222: 35 Board Report Received and Board Report Source Item
- CD-228: 33 Rule Instrument List
- CD-234: 31 VaR Test Result (not "Derivatives VaR Test Result"; there is no "Liquidity Risk Program Report" object); 32 Performance Return (not "Share Class Return"); 33 Investment Breach and Compliance Rule (not "Compliance Breach" or "Guideline Rule")
- CD-238: 32 Performance Return and Benchmark Return

The resolutions of CD-226 (CMET and Meeting Date) and CD-233 (36 holds the filing link) were also updated.

## 2. Registers (CD-241)

**Prefix renames: none.** The 25 reserved prefixes were checked against every registered, proposed, renamed and retired prefix and against each other: one letter apart (Levenshtein distance 1) or an anagram. Nothing matched. The PA- stem was checked as asked: PAAN- (32), PAIC- (34) and PAPR- (36) are each at least two edits from each other and from PAMD- and PAUD- (16). The prefix notes record this.

**Registered** (Reserved to Registered):

| Domain | Prefixes |
|---|---|
| 31 | RLMT-, RLEX-, STRESS- |
| 32 | RETURN-, PAAN-, GVER- |
| 33 | CRULE-, CCHK-, CALERT-, BREACH- |
| 34 | VOTE-, ENGM-, ESGA-, PAIC-, VPOL- |
| 35 | BOARD-, BMEET-, RESO-, ADVA-, RENEW-, REGF- |
| 36 | PPSL-, PAPR-, LCHG-, PRVW- |

STRESS-, RETURN-, CALERT- and BREACH- have six letters. `ownership.py` reads prefixes of two to five letters, so it never matches them. References to them resolve through the concept name or the ", NN" qualifier in the data type, and the notes say so. The regex was not widened, because that would change how existing 01-30 examples resolve.

**Key formats.** PREFIX_FORMATS now has 25 Stage 3 rows. They come from proposals_31 and proposals_33 PREFIX_FORMATS and from the proposals_32, _34, _35 and _36 KEY_FORMATS, and PRVW- uses 36's new 2-digit sequence. A scan of every example in 01-36 found one Stage 2 or Stage 3 prefix that did not match its owner's format: 35's PRVW-2026-00981-AOV, now PRVW-2026-00981-AOV-01.

Sibling examples of grain-keyed objects were also aligned to the owners' published grain keys (proposals_31 GRAIN_KEY_FORMATS, proposals_34 KEY_FORMATS and 32's own composite keys):
- 35:
  - Reported Risk Program, Subject Risk Program Designation: PRD- / program type / effective from
  - Subject Highly Liquid Investment Minimum: PRD- / effective from
  - Source Fund Liquidity Profile: PRD- / measurement date
  - Source VaR Test Result: PRD- / test date / regime
  - Source Benchmark Return: BMK- / start / end / return type / currency / hedged / version
  - Relied 817(h) Rule Results: CCHK- / PORT- / CRULE- version / evaluated party
  - Subject and Filed Proxy Voting Report: '2026 NPX-FUND PRD-00431'
- 36: Liquidity Evidence Profile and Benchmark Evidence Return
- 33: Source Sustainability Exclusion List and Triggering Product Change had blank examples; they now hold 'TCOAL / 3' and LCHG-2026-00118.
- 31: Climate Metric Input was re-pointed from the retired "Portfolio Climate Metric" to Reference (Portfolio Sustainability Metric, 34), with the 34 key 'PORT-000412 / 2026-09-30 / WACI / Scope 1+2 / Point in Time'. Its relationship row was renamed to match.

Composite keys that start with an 01 prefix need an override. Seven were added: six in enrich_35 and one in enrich_36. 36 Satisfying Exemptive Relief keeps its descriptive example, because 35 publishes no grain key for Exemptive Relief Reliance (§4).

**Stale sibling names fixed in content:**
- 35 Board Report Type "Investment Compliance Breach Summary" is now "Investment Breach Summary".
- The 35 Source VaR Test Result note no longer cites the brief name.
- The 35 and 36 notes that called the CD-237 and CD-233 changes "proposed" now say the changes were made or verified.
- 31's "Risk Model Vendor is proposed" note, 34's "CDP is proposed" note (the example is now CDP) and 33's "IRS is proposed" note were updated.
- The next-step and code-list comments in 31-36 that asked for shared-list registration were updated.

**Concept ownership.** 90 rows were added for the Stage 3 masters (31: 23, 32: 13, 33: 14, 34: 17, 35: 14, 36: 7). Referencing domains come from a scan of references and relationship rows after the merge, plus the 01-30 derived copies (01, 10, 12, 25). No existing row changed, and no attribute in 01-36 changed owner when the rows were added (checked by baseline).

**Ownership aliases** (ownership.py):
- 31: risk limit, risk limit exceedance, exceedance
- 32: performance return, composite membership
- 33: compliance rule, investment breach, breach
- 34: vote, vote instruction, engagement, exclusion list, sustainability exclusion list
- 35: board, fund governing body, board resolution, fund regulatory filing, regulatory filing, advisory agreement, fund advisory agreement
- 36: product proposal, change initiative, product change initiative

Bare "resolution" and "filing" were not aliased. The term conflicts Resolution and Filing say both are always qualified, and 08, 12, 13, 14, 16 and 19 use them for other things. A scan of every 01-30 Reference target found no match with any new alias.

**Term conflicts.**
- 31 terms were added: Proxy / Vote, Board, Engagement, Filing, Review / Assessment, Change, Risk, Exposure, Limit, Exceedance / Breach, Factor, Liquidity, Scenario, Tracking Error, Return, Performance, Attribution, Composite, Restatement, Rule, Restriction, Exception, Check, Policy, Exclusion, Resolution, Disclosure, Approval, Launch, Reorganization, Readiness / Set-up.
- Synonymous entries were merged. "Review / Assessment" absorbs the Review entries of proposals_33 and _36 and Assessment from proposals_34. "Limit" combines 31 and 33. "Exceedance / Breach" absorbs 33's Breach. "Resolution" absorbs the Resolution Outcome list-name entry.
- 12 existing terms were extended: Rating, Agreement / Contract / License, Model, Counterparty, Meeting, Decision, Committee, Alert, Waiver, Index / Benchmark, Measure / Metric / KPI, Report. The placeholder usages "Board meeting (planned, MTG-)" and "Counterparty exposure (planned)" were replaced by the drafted objects.

**Shared lists:**
- 31-36 were registered as direct users of the 17 shared lists they copied (proposals_31 ... _36 SHARED_MEMBERSHIPS), and the local copies were removed in the same step: 31 nine, 32 six, 33 nine, 34 nine, 35 nine, 36 eight. The copies of the new CD-242 lists were removed too (32 two, 33 three, 36 one). Every copy was label-identical except 35's Regulator value "IRS", whose two examples now read "IRS / US Treasury". Every attribute now shows "Shared: <name>".
- Values added:
  - Regulator: "IRS / US Treasury" (US_IRS_TREASURY; CD-224 context, accepted by the program lead).
  - Data Provider: ISS STOXX, Glass Lewis, Sustainalytics, CDP (proposals_34). "MSCI ESG Research" was not added: proposals_34 marks it optional and recommends keeping MSCI and naming the product through the 14 dataset.
  - Message Standard: no Stage 3 domain proposed a value.
- Values added to local lists:
  - 02 Party Role Type: the seven values above (CD-143)
  - 01 Measurement Basis: % of Total Assets, Days, Ratio, Rating Notch, % of Commitments, % of Capital (proposals_33, CD-221 and CD-223). The 33 copy now matches 01 value for value.
- New shared lists (CD-242), each with identity value maps:

| List | Steward | Members (local list replaced at build) | Direct users (local copy removed) |
|---|---|---|---|
| Committee Decision Outcome | 24 | 24 | 36 |
| Compliance Check Outcome | 33 | 25 | 33 |
| Return Methodology | 32 | 12 | 32 |
| Net Fee Treatment | 32 | 12 | 32 |
| Breach Type | 33 | 12 | 33 |
| Cure Action | 33 | 12 | 33 |

**Ownership overrides dropped:** enrich_33 Source Risk Measurement (31) and Resulting Reportable Fund Event (35). Both have blank examples, and with the 31 and 35 concepts registered they resolve without help.

Every other override in enrich_31 ... enrich_36 was tested by resolving the attribute without it. All but five are still needed: composite keys that start with another domain's prefix (PORT-, PRD-, BMK-, INS-, PTY-, CAE-), or 13 references with blank examples. The five redundant ones were kept on purpose:
- 31 Utilized and Exceeded Counterparty Trading Limit, and 33 Originating Manual Check: composite-key guards with blank examples
- 34 Earning Stewardship Report and 36 Evidence Listing: documented as explicit in their files

None of these five existed because a prefix was unregistered.

### Candidate shared lists deferred

| Candidate | Raised by | Why deferred |
|---|---|---|
| Committee Member Role | 24, 35, 36 (21, 22, 39) | Values differ (24 Vice Chair / Voting Member / Non-Voting Member / Standing Attendee; 35 Lead Independent Director, Advisory Board Member, Observer; 36 Deputy Chair, Observer / Adviser). No complete value map. |
| Internal Credit Rating | 23 (31, 33) | 31 and 33 hold no copy or citation of the 23 list today. |
| Return Type | 01, 32 (22 Index Level Variant) | Identical values, but it would change the 01 citation. Waits for CD-169 (Stage 2 §3 item 8). |
| Measurement Basis; Restriction Limit Type (01 Limit Type = 33 Rule Limit Type) and a LOCAL_RENAMES of 25 Limit Type to Counterparty Limit Type | 01, 33, 25 | 33 now matches 01, but making the lists shared changes 01 citations and renames a 25 list. Needs a code-list CD. |
| Regulatory Regime (+ IRC 817(h) Insurance-Dedicated, ERISA Plan Assets) | 01, 33, 35, 36 | The additions to 01 are not covered by a Stage 3 CD (§3 item 7). 33 keeps its local copy with the two values. |
| COLL Change Classification | 13, 36 | Identical values. proposals_36 also asks for 13 Change Classification to become a derived copy, so it is handled with §3 item 15. |
| 36 copies of 01 lists (Vehicle Type, Asset Class, Regulatory Regime, Share Class Type, Hedging Type, Distribution Policy, Investor Type) | 36 | They would make 01 a member of seven new shared lists. Needs a code-list CD with 01. |
| Product Lifecycle Event Type (36 Product Change Type as a superset of 01 Lifecycle Event Type) | 36, 01, 13, 16 | Not a value-for-value match. Part of CD-236 (§3 item 13). |
| Product Review Outcome (01 Value Assessment Outcome) | 36, 01 | Part of CD-236 and CD-238. |
| Exposure Method (01 Risk Measurement Method and Leverage Method) | 31, 01 | It would split an 01 list (CD-214). |
| Counterparty Exposure Measure / 25 Limit Type | 31, 25 | Not identical: 31 adds net MTM, collateral held, net exposure, PFE. |
| Measure Unit, Rate Tenor | 22 (31 cites them as External) | Only 22 holds them (Stage 2 §2). |
| Liquidity Category, Liquidity Horizon Bucket, Confidence Level, Risk Measure, Risk Dimension | 31 (35, 30, 32) | Only 31 holds them. |
| Price Basis, Return Status, Measured Subject Type, Return Source | 32 (31, 33, 35) | Only 32 holds them. |
| ESG Topic (34 Engagement Theme / 23 Meeting Topic Category), Meeting Format, Metric Framework, Exclusion Policy Basis | 34, 35 (03, 04, 13, 23, 31, 33, 01) | Values only overlap in part. |
| Filing Form Type, Regulatory Filing Status, Board Meeting Type, Fund Officer Role, Consent Type | 35 | Recommended NOT_MERGED by 35, or single-user. |
| Cost Bearer | 36 (10, 19, 29, 35) | Stage 2 deferred the same list (13, 27, 29). |

## 3. Decision list for the program lead (proposed for 01-30, not applied)

| # | Proposal | Source | Decision needed |
|---|---|---|---|
| 1 | 01 Portfolio Manager: re-type Reference (Party) to Reference (Employee); 01 Product Governance Product Owner the same (both are resolved to 20 by override today) | proposals_24 (Stage 2 item 5), proposals_36 | CD-175 (option B follow-up), CD-236 |
| 2 | 01 Benchmark widened to every index the firm references; 32 Benchmark Return and 22 index data depend on it | proposals_22 (Stage 2 item 4) | CD-169 option A |
| 3 | 02 Party Role Type: Fidelity Bond Insurer, Fund Filing Agent, LPAC Member Representative, CIT Trustee Bank | proposals_35 | CD-143 (complete it) |
| 4 | 01 Product Governance Governing Body re-typed to Reference (Fund Governing Body, 35) with a BOARD- example (the enrich_01 override to 09 goes); retire the 01 Product Party Role Type value "Board of Directors" | proposals_35 | CD-231 |
| 5 | 01 Regulatory Authorization Regulatory Reporting Obligations as a Derived copy (35) of Filing Obligation | proposals_35 | CD-233 |
| 6 | 01 Investment Restriction: add "Restated Regulatory Provision" (Reference (Regulatory Limit Provision, 33)) for Restriction Source "Regulatory"; add "Cited Exclusion List" (Reference (Sustainability Exclusion List, 34)) for "ESG Exclusion Policy" | proposals_33, proposals_34 | CD-221, CD-228 |
| 7 | 01 Regulatory Regime: add "IRC 817(h) Insurance-Dedicated" and "ERISA Plan Assets" (or a separate scope list) | proposals_33 | New code-list CD (CD-221) |
| 8 | 01 ESG Classification: Derived copies (34) of the latest Achieved Sustainable Investment % and Achieved Taxonomy-Aligned % for EET delivery | proposals_34 | CD-229 |
| 9 | 01 Share Class Performance Calculation Basis as a Derived copy (32) of the Performance Measurement Profile, or retire it | proposals_32 | CD-217 |
| 10 | 01 Exposure Method: split 01 Risk Measurement Method into an exposure method and a VaR test regime, shared with 31 | proposals_31 | CD-214 |
| 11 | 01 Product Governance: Product Approval Date, Last and Next Product Review Date and Value Assessment Outcome as Derived copies (36) | proposals_36 | CD-236 |
| 12 | 01 Lifecycle Event: add Originating Change Initiative (LCHG-); Event Effective Date and Event Reason as Derived copies (36) | proposals_36 | CD-236 |
| 13 | 01 Lifecycle Event Type joins a shared "Product Lifecycle Event Type" list, with the 36 Product Change Type as a superset | proposals_36 | CD-236 and a code-list CD |
| 14 | 08 Distribution Review Finding Product Review Cycle re-typed to Reference (Product Review, 36) with a PRVW- example | proposals_36 | CD-238 |
| 15 | 13 Shareholder Notice: Change Classification as a Derived copy (36) of Changed Product Scope COLL Change Classification; Shareholder Approval Required Indicator derived from the 36 Shareholder Vote requirement; COLL Change Classification shared 13 / 36 | proposals_36 | CD-236 |
| 16 | 13 Shareholder Communication Regulatory Filing Reference and Tailored Shareholder Report Form N-CSR Filing Date as Derived copies (35) of the N-CSR filing's Accession Number and Official Filing Date | proposals_35 | CD-233 |
| 17 | 27 Fund Tax Year Record: Reference (Fund Regulatory Filing, 35) for Form 1120-RIC and Form 8613 | proposals_35 | CD-191 / CD-235 (SME question 11 in 35) |
| 18 | 27 Financial Highlights Total Return as a Derived copy (32) (option A) or kept with a 32 reconciliation (option B) | proposals_32 | CD-217 (SME) |
| 19 | 10 Revenue Contract Contract Inception Date and Termination Notice Period: today Derived copies (01) "from the fund advisory / management agreement"; on fund advisory rows they should read the 35 Fund Advisory Agreement | consolidation finding | CD-232 extension |
| 20 | 12 Breach Notification: add "Breached Client Restriction" (Reference (Client Restriction)); derive Breached Mandate from the breach's portfolio (18 Portfolio Implementation Link) | proposals_33 | CD-222 extension |
| 21 | 12 Compliance Certificate: add Supporting Manual Checks (Reference (Manual Compliance Check, 33), multi) (optional) | proposals_33 | CD-222 |
| 22 | 12 Presentation Profile Fee Basis list re-pointed to the shared Performance Fee Basis; 12 Return Period replaced by the shared Reporting Period Basis | proposals_32 | CD-217 and a code-list CD |
| 23 | 12 Stewardship Report Scope / Stewardship Content values matched to the 34 report types | proposals_34 | CD-227 |
| 24 | 22 Pricing Analytic Measure: Average Daily Trading Volume and Quoted Bid-Ask Spread (only if 22 is to own liquidity market inputs) | proposals_31 | CD-211 / CD-213 (SME question 3 in 31) |
| 25 | 22 Measure Unit and Rate Tenor as enterprise shared lists (31 cites them as External) | proposals_31 | New code-list CD |
| 26 | 24 Rebalance Run "Risk Model Used" re-typed Text to Reference (Risk Model, 31); Pre-Trade and Post-Trade Tracking Error notes say "optimizer estimate; held-book measure is 31" | proposals_31 | CD-211 |
| 27 | 24 Portfolio Construction Constraint: note that constraints are not compliance rules | proposals_33 | CD-221 |
| 28 | 25 Counterparty Trading Limit: note that each Limit Type is measured by the 31 Counterparty Exposure of the same measure, with utilization and exceedances in 31 | proposals_31 | CD-215 |
| 29 | 28 Securities Loan: a dated on-loan quantity, so 34 Ballot Shares on Loan Not Recalled can be derived; optional recall reason "Proxy Vote" | proposals_34 | CD-226 extension / CD-198 |
| 30 | 09 Inclusion Type: widen the definition of "Exclude" to cover a listed exclusion. 09 Unit of Measure: tCO2e, tCO2e per million invested, tCO2e per million revenue, degrees Celsius | proposals_34 | CD-228 / CD-229 (09 list changes) |
| 31 | 02 ERISA party-in-interest lists for plan clients, which the 33 list would read | proposals_33 | SME question 10 in 33 |
| 32 | 02 Data Provider "MSCI ESG Research" (optional) | proposals_34 | CD-241 follow-up |
| 33 | "Future 31-36" notes left in 01-30, to be re-worded now that the Stage 3 objects exist: 24 Rebalance Run and Rebalance Portfolio Result ("future owner 31"); 27 overview, RIC Test Result, Fund Tax Return Type, N-CSR filing and Financial Highlights Total Return ("future 35", "future 36", "future 32"); 30 overview and sources (IRR and multiples "future 32", Form PF and Annex IV "future 35") | consolidation finding | Cleanup CD (with CD-211, CD-217, CD-219, CD-233, CD-235) |

Within the new domains (no 01-30 change; for the CD owners):
- 27 vs 35 ownership of the RIC qualification determination. CD-224 says 27 RIC Test Result is the determination, while CD-235 and 35 RIC Qualification Determination say 35 holds it and reads 27 and 33.
- Rule 2a-7 liquid asset minimums as 33 rules vs the Rule 22e-4 program in 31 (33 SME question 7).
- 34 Proxy Voting Report "report line" object, if N-PX content must be frozen at filing.
- 35 Fund Officer Appointment as the 31 program administrator (in place; 35 suggests 31 drops Program Risk Lead).
- 37 model inventory: 31 Risk Model, 32 Attribution Model and 34 methodology names stay text until Stage 4. 38 restricted list: 33 Rule Instrument List stays text.

## 4. Data product layer and tooling follow-ups (not decisions)

- **Lineage.** No data product spec traces to a moved object. DP-042 inherits the 12 Breach Notification changes (definitions, flags, the shared Breach Type and Cure Action lists and positional IDs). The only data model edit was removing the 01 Composite Member key link (CD-218). Semantic models are unchanged.
- **Explorer.** build_explorer.py has a new group, "Investment oversight and product governance (Stage 3)", with one-line taglines and short names for 31-36. No area views were added. The landscape map in `explorer/template.html` now draws every expansion stage (enterprise, invest, oversight) as a band under the foundations, at most five domains per row. Each stage has its own color in the light and dark themes. Stage 2 had added "invest" as a sixth column, which overlapped the five value-chain columns and had no color.
- **Grain-key formats.** Only 31 (GRAIN_KEY_FORMATS) and 34 (KEY_FORMATS) publish composite key formats. 32's are readable from its own examples. 33 and 35 publish none: Compliance Rule Result was aligned to 33's own example, and 35 Exemptive Relief Reliance and Reportable Fund Event have no published format. Stage 4 should publish one key format per grain-keyed object.
- **Six-letter prefixes.** References to STRESS-, RETURN-, CALERT- and BREACH- resolve through names (above). If the resolver regex is widened later, re-run the baseline: 01-30 examples with 6-letter stems would then be matched.
- **Older prefix shapes** (Stage 2 §4) are still not published for Stage 1 and distribution prefixes.
- **Semantic model output** still writes `_cols` sets in a different order on each run, so `semantic_model/out/` files may change with no change in content.

## 5. Baseline reconciliation (check_baseline.py against stage2-v0.1)

`check_baseline.py --check stage2-v0.1 --allow CD-022,CD-143,CD-180,CD-212,CD-218,CD-221,CD-222,CD-225,CD-226,CD-230,CD-232,CD-233,CD-237,CD-240,CD-241,CD-242` fails, as expected. It reports 16 sections:
- 14 Data Domains: 01, 02, 09, 10, 11, 12, 17, 19, 20, 22, 24, 25, 26 and 27
- the registers
- the logical models

The validators all pass (36 modules, 0 unresolved references). stage2-v0.1 records only hashes, so each difference was checked in detail against a flattened attribute, code list, relationship and family model of 01-30, built from `git archive stage2-v0.1` and from the working tree. Every difference traces to an allowed decision. None is unexplained.

### Data Domains 01-30

| Domain | Reported difference | Cause | CD |
|---|---|---|---|
| 01 | Derived 4 to 7; Product Risk Indicator changed | Summary Risk Indicator (SRI) and SRRI are Derived copies (31) with notes | CD-212 |
| 01 | GIPS Composite changed; ownership changed; relationships changed | Composite Member re-typed Reference to Text, redefined, example and note changed, Derived copy (32); relationship note updated | CD-218 |
| 01 | Code list values changed | Measurement Basis +6 values | CD-241 (CD-221, CD-223) |
| 02 | Code list values changed | Party Role Type +7 values; shared Regulator and Data Provider values (02 is a member) | CD-143, CD-241 |
| 09, 11 | Code list values changed | Shared Regulator (09, 11) and Data Provider (11) values | CD-241 |
| 10 | Revenue Contract changed; relationships changed | Underlying Agreement type, definition and row rule note; "is based on" row names 35 ADVA- | CD-232 |
| 12 | Attributes 235 to 236, CDEs 74 to 75, references 50 to 51, derived 4 to 8, relationships 36 to 37 | Related Investment Breach (BREACH-, CDE); Breach Type, Breach Detected Date, Cure Action, Cure Date Derived copies (33); Breached Restriction note; row "reports Investment Breach [33]" | CD-222 |
| 12 | Code lists local 43 to 39, shared 9 to 13; Presentation Profile changed | Breach Type, Cure Action (steward 33), Return Methodology, Net Fee Treatment (steward 32) are shared; Return Methodology Shown and Net Return Fee Treatment show "Shared:" | CD-242 |
| 12 | Compliance Certificate, Depreciation Notification changed | Positional attribute IDs in the family shift after the new attribute | CD-222 |
| 17 | Attributes 267 to 268; Corporate Action Event changed; ownership changed | Meeting Date added (mastered here) | CD-226 |
| 17 | Code list values changed; family definition changed; Corporate Action Option changed | Five meeting event types; family text; positional IDs shift. Data Provider values (17 is a direct user) | CD-226, CD-241 |
| 19, 20, 22, 26, 27 | Code list values changed | Shared Regulator (19, 20, 26, 27) and Data Provider (22) values (direct users) | CD-241 |
| 24 | Code lists local 24 to 23, shared 7 to 8; Investment Committee Decision changed | Committee Decision Outcome is shared (steward 24) | CD-242 |
| 25 | Code lists local 28 to 27, shared 9 to 10; Trade Order Event changed; relationships changed | Compliance Check Outcome shared (steward 33) with the per-order row rule note; local list source text; "Compliance Check Run, Check Subject Member [33]" | CD-180, CD-221, CD-242 |
| 25 | Code list values changed | Shared Regulator values (direct user) | CD-241 |
| 03-08, 13-16, 18, 21, 23, 28-30 | No difference | | |

### Registers

| Register | Reported difference | CD |
|---|---|---|
| Decisions | 32 added (CD-211 to CD-242) | Merge of proposals_stage3_a and _b; CD-241, CD-242 |
| Decisions | CD-022 changed (status Superseded, resolution names CD-232) | CD-232 |
| Decisions | CD-143, CD-180 changed (Stage 3 notes) | CD-143, CD-180 |
| Term conflicts | 31 added; Agreement / Contract / License, Alert, Committee, Counterparty, Decision, Index / Benchmark, Measure / Metric / KPI, Meeting, Model, Rating, Report, Waiver extended | CD-241 |
| Shared code lists | Breach Type, Committee Decision Outcome, Compliance Check Outcome, Cure Action, Net Fee Treatment, Return Methodology added | CD-242 |
| Shared code lists | Regulator (value, direct users), Data Provider (values, direct user) changed | CD-241 |
| Shared code lists | Agreement Status, Approval Status, Business Line, Case Status, Data Basis, Distribution Market, Frequency, Inclusion Type, Information Classification, Performance Fee Basis, Period Type, RAG Status, Record Status, Reporting Period Basis, Severity changed (direct users 31-36 added) | CD-241 |

Prefixes (25), concept owners (90) and the decisions and terms that name only 31-36 are expansion additions. Ownership aliases are code (`ownership.py`); the check shows no ownership change from them.

### Data products, logical models and semantic models

| Layer | Reported difference | CD |
|---|---|---|
| Data products | No difference | |
| Logical models | DP-042 changed: inherited 12 Breach Notification definitions, flags, notes, shared code list names and positional IDs | CD-222, CD-242 |
| Semantic models | No difference | |

Expansion additions (not failures): the six 31-36 modules, the 25 Stage 3 prefixes, 90 concept owners, and the decisions and term conflicts that name only 31-36.

Against `distribution-v0.4`, `--allow` was given the Stage 1, Stage 2 and Stage 3 decisions. The check reports 20 sections, the same set as at Stage 2:
- 16 Data Domains
- the registers, data products, logical models and semantic models

Stage 3 adds differences only in 01, 02, 09, 10, 11 and 12, all listed above, and these domains already differed for Stage 1 or Stage 2 reasons. Domains 03-08 and 13-16 are unchanged since stage2-v0.1, so their differences are the Stage 1 and Stage 2 ones in the earlier notes. The register, data product and logical model differences are the union of the three reconciliations; Stage 3 adds only the CD-022 change, the new decisions, terms and shared lists, and DP-042.

`--check stage3-v0.1` passes.
