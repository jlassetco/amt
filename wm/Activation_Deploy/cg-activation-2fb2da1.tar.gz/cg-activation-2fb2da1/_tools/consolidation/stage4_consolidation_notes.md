# Stage 4 consolidation notes (2026-10-07)

The Stage 4 consolidation merged Data Domains 37 to 44 into the enterprise registers and applied the agreed moves and re-pointings to Data Domains 01 to 36 (Enterprise_Expansion_Plan.md §9.3 step 5), following the program lead's rulings for this merge. It is the last drafting-stage merge: the taxonomy now has all 44 Data Domains. This file records:
- what was applied
- what was deferred, and the decision each deferred item needs
- the reconciliation of every difference that `check_baseline.py` reports against `stage3-v0.1`

The new baseline is `baseline/stage4-v0.1.json`. It records Data Domains 01-44 in full.

## 1. Decisions applied

| Decision | Status | What changed |
|---|---|---|
| CD-143 | Applied further | 32 Party Role Type values proposed by 37-44, deduplicated, added to the 02 list: Insurer, External Model Validator, Co-Sourced Internal Audit Provider (37, 43); Personal Account Broker, Political Candidate / Committee (38); Outside Counsel, Opposing Party, Non-Executive Director, Attorney-in-Fact (39); Supplier, ICT Third-Party Service Provider, Subcontractor, Staffing Agency (40); Security Testing Provider (41; its "ICT Service Provider" is the 40 value); Journalist, Media Outlet, Government Official, Trade Association, Award Organizer, Newswire Service, Media Monitoring Provider, Reputation Research Provider, Lobbying Firm, Legislative Body / Government Agency (42); Relationship Bank, Corporate Lender, Insurance Broker (43); Landlord, Facility Service Provider, Card Issuer, Travel Management Company, Subtenant (44). |
| CD-245 | Applied (verified) | DORA major-incident classification and authority reports are on 37 Operational Incident / Incident Regulatory Notification; 41 IT Incident (ITINC-) is the technical record with no notification and no 37 reference. No 01-36 change. |
| CD-246 | Applied | 31 Risk Model and 32 Attribution Model "Model Inventory Reference", 21 AI Use Case "Model Name", 22 Fair Value Determination "Valuation Model Name", 34 Firm ESG Assessment "Assessment Methodology Name" and 34 Portfolio Sustainability Metric "Metric Model Name" re-typed Text to Reference (Model Inventory Entry, 37) with MODEL- examples (names unchanged). 24 Decision Algorithm Code is a Derived copy (37). The 21 and 31 relationship rows name Model Inventory Entry. |
| CD-248 | Amended (Proposed) | Program lead ruling written into the resolution: 14 Inherent Risk Rating stays mastered in 14. Nothing changed in 01-36; the 14 Residual Risk Rating and 23 Expert Network copies are in §3. |
| CD-250 | Applied (move) | 09 Entity Authorization, Cross-Border Passport, their four lists and two relationships removed (38 copies verified identical tuple for tuple before deletion). AUTH- transferred to 38. 09 left the Regulator shared-list members (its only use was the moved attribute). 25 Large Trader ID is a Derived copy (38). 26, 28 texts and the 28 / 43 references now point to 38. |
| CD-252 | Applied (move) | 08 Regulatory Obligation, Attestation, their four lists and two relationships removed (38 copies verified identical). OBL- transferred to 38. The LOCAL_RENAMES entry "Compliance Attestation Type" and the Applicable Legal Entity Derived copy (09) flag moved to 38, so consolidated names and flags are unchanged. 08, 20 and 21 texts name 38. |
| CD-255 | Applied | 29 Escalation Case Reference re-typed to Reference (AML Case, 38); the 29 disposition value and relationship name the AML Case. Regulator gained FinCEN, OFAC, UK HM Treasury OFSI, UK National Crime Agency, US Department of Justice and US State Attorney General. |
| CD-256 | Applied | 33 Restricted List Source re-typed to Reference (Firm Restricted List, 38), example "GRL"; 23 MNPI Escalation Reference re-typed to Reference (MNPI Escalation, 38); 23, 25, 33 relationship rows name Restricted List Entry, Trade Surveillance Alert, Firm Restricted List. |
| CD-257 | Applied, amended | Text amended per the ruling (typed owners 01, 05, 10, 14, 16, 26, 28, 30, 35, 40, 43, 44; leases typed 44 rows; 39 Contract generic with derived copies on typed rows, declared owner "05" as a stand-in, per-row owner in the note, plan §4 item 9). 20 Supplier Contract Reference and 28 Service Agreement Reference re-typed to Reference (Contract, 39). |
| CD-258 | Applied | 02 Retention and 08 Captured Communication Record Legal Hold Indicator are Derived copies (39). |
| CD-259 | Applied (verified) | Approval links: fund-board approvals only on 35 Resolution Subject Link, corporate approvals only on 39 Corporate Resolution Subject Link. No 37-44 attribute outside 39 and no 01-36 attribute references a corporate resolution (scan). |
| CD-260 | Applied in part | 19 Purchase Order Reference re-typed to Reference (Purchase Order, 40); 14 Procurement Supplier ID is a Derived copy (40), example "SUP 0045521". |
| CD-261 | Applied in part | 14 ICT Third-Party Register Entry: DORA In-Scope Indicator, ICT Service Type, Supports Critical or Important Function, Supported Functions and Data Storage Locations are Derived copies (40); Reporting Financial Entity and Material Subcontractors (References) carry the row rule in their notes. |
| CD-262 | Applied | Every "future owner 37-40" note resolved (with CD-285). |
| CD-263 | Applied | Re-typed to Reference (Application, 41): 21 Hosting System, Designated System, Record Governance Metadata System of Record and Source System; 18 Book of Record System, Event Source System; 09 Code Mapping Source System, Subscribing System; 01 System Cross-Reference Source System. The 21 "System" list is retired. (The program lead's ruling cites CD-264 for these; CD-263 is the decision that names them.) |
| CD-264 | Applied (option A) | 14 Consuming Application keyed by APPL- (DAPP- retired), Application Name Derived copy (41), Dataset Consumption / Entitlement examples re-keyed (kept mastered in 14 by override, they reference the profile); 04 Marketing System gained Inventoried Application, System Name Derived copy (41). |
| CD-267 | Applied | 36 Launch Project Code is a Derived copy (41), example PRJT-2026-0114. |
| CD-268 | Applied | Register of information in 40; shared DORA ICT Service Type (steward 41) created (CD-284). |
| CD-271 | Applied (move) | 04 Brand, Brand Level and Brand Status lists, relationship and grain entry removed (42 copy identical except the ruled CDE on Brand Level). BRD- transferred to 42. 12 Report Template Brand "owned by 42". 04 keeps websites, social accounts, themes and messaging. |
| CD-274 | Applied | 19 Paying Bank Account → Reference (Corporate Bank Account, 43); 19 Bank Statement Entry Reference → Reference (Bank Statement Entry, 43). |
| CD-276 | Applied | 18 Proprietary Capital Indicator is a Derived copy (43); 43 is the master of seed status. |
| CD-277 | Applied | 19 Capital Requirement Amount and Capital Resources Amount are Derived copies (43); Regulatory Return Type gained "FCA MIF007 ICARA Questionnaire". |
| CD-279, CD-280 | Applied in part | 19 Journal Source gained "Lease Accounting" and "Travel & Expense". |
| CD-281 | Applied in part | Shared GHG Scope Category (CD-284). |
| CD-282 | Applied | Registers (CD-283); COVG- withdrawn for MCOV-. |
| CD-283 (new) | Applied | Stage 4 register consolidation (§2). |
| CD-284 (new) | Applied | Four shared lists (§2). |
| CD-285 (new) | Applied | Future-owner texts in 17-36 resolved or pointed to §3. |

**Merged with status Proposed:** CD-243, CD-244, CD-247, CD-248 (amended), CD-249, CD-251, CD-253, CD-254, CD-265, CD-266, CD-269, CD-270, CD-272, CD-273, CD-275 and CD-278. They change nothing in 01-36 now, or their 01-36 parts are in §3.

**No decision proposals inside proposals_37 ... proposals_44.** None carried a DECISIONS section, so nothing was renumbered; the new decisions are CD-283 to CD-285.

## 2. Registers (CD-283)

**Prefixes.** 56 prefixes registered (27 for 37-40, 28 for 41-44 less COVG-, plus MCOV-). The confusable check (Levenshtein distance 1 or anagram) against all 339 registered, proposed, renamed and retired prefixes and among the 56 found one pair: MCOV- (42) ~ RCOV- (23). It is kept: the program lead accepted it when withdrawing COVG- (an anagram of CGOV-, 39), and the two are in different domains, as with the pairs accepted at Stage 2. No rename was needed. Transfers in place: AUTH- 09→38, OBL- 08→38, BRD- 04→42 (formats kept). DAPP- (14) retired (CD-264).

**Key formats.** PREFIX_FORMATS gained 59 rows (the 56 plus AUTH-, OBL-, BRD-), from the proposals_37 ... _44 KEY_FORMATS (43's amended RCAP- and INPOL- formats, 42's full LOBR- format). Two new informational registers in decisions.py: FIRM_KEY_FORMATS (9 firm keys without a hyphenated stem: PCON, GRL, PTA, AML case, SVC, SRT, IFC, PRB, UAR) and GRAIN_KEY_FORMATS (101 composite keys of 37-44 objects), answering stage3 §4's request for one published format per grain-keyed object.

**Sibling alignment.** 37 Resilience Resource Mapping and Resilience Test use "SVC 0118" and "SRT 2026-0031"; 39 Subject Link examples use "IGCT 2026/007", "LEN-0021 / ICARA / 2026-06-30", "MSA/0021/2025/1", "2026 / 2"; 42 uses "RCAP-0021-MP-20260930-01", the 44 emission key, "PSI 2026-0042" and "PCON 2026-00007"; 44 relationships no longer say "proposed" for the 37 incident link, Journal Source values and the CD-257 amendment. 40 already used "SVC 0118" and "CIF 03". The next-step texts of 37, 38, 40, 41, 42, 43 and 44 record what the merge did.

**Concept ownership.** 235 rows for the 37-44 business objects (referencing domains from a scan after the merge; 69 have referrers). The 04 Brand row now names 42. No 01-36 attribute changed owner when the rows and aliases were added (checked by a flattened before/after comparison).

**Aliases** (ownership.py): risk, enterprise risk, control, incident, operational incident, loss event, risk issue, model, model inventory entry, audit, audit engagement, audit finding → 37; policy, restricted list, firm restricted list, restricted list entry, examination, regulatory examination, filing, firm regulatory filing, entity authorization, regulatory obligation, aml case, mnpi escalation, conflict of interest, trade surveillance alert → 38; contract, legal matter, legal hold, resolution, corporate resolution, corporate governing body → 39; supplier, supplier engagement, purchase order, outsourcing arrangement → 40; application, it incident, project, it service → 41; brand, publication, corporate publication, press release → 42; bank account, corporate bank account, seed, seed capital commitment → 43; lease, site, site profile, expense, expense report → 44. Bare "filing" and "resolution" are now aliased per the ruling (Stage 3 had left them unaliased); the scan found no 01-36 reference that resolves differently.

**Term conflicts.** 36 new terms (Incident, Application / System, Project / Program / Initiative, Asset, Release, Brand / Trademark, Event, Facility / Covenant, Claim, Site / Office, Emissions, Expense, Control, Examination / Audit, Conflict, Registration / Authorization, Case, Hold, Matter, Signatory, Vendor / Supplier, RFP, Service Level / SLA, Outsourcing, Category, Register, Service, Interface, Test, Identity, Publication, Lease, Space, Visitor, Reservation / Booking, Measurement) and 26 extended (Entitlement, Statement, Account, Commitment, Policy, Position, Exposure, Challenge / Issue, Risk, Model, Exception, Limit, Filing, Restriction, Alert, Attestation, Agreement / Contract / License, Board, Resolution, Committee, Invoice, Payment, Order, Engagement, Change, Coverage). Synonyms were merged (Access / Entitlement into Entitlement; Capital and Capital / Commitment into Commitment; Hedge into Exposure; Issue into Challenge / Issue; Appetite / Limit into Limit; Facility Drawdown and Covenant Test into Facility / Covenant; four authorization / registration entries into one).

**Shared lists.**
- 37-44 registered as direct users of the 23 shared lists they copied (proposals_37 ... _44 SHARED_MEMBERSHIPS) and the local copies removed: 37 ten, 38 nine, 39 eleven, 40 nine, 41 eleven, 42 six, 43 six, 44 nine. Every copy was label-identical; 41's Business Domain copy matched once the list was extended.
- Values added: Regulator six (CD-255); Business Domain 22-44 (23 values; 41 found it stopped at 21); 02 Party Role Type 32 (CD-143); 19 Journal Source 2, Regulatory Return Type 1.
- 09 left the Regulator members (CD-250); LOCAL_RENAMES "Compliance Attestation Type" moved from 08 to 38 (CD-252).
- New shared lists (CD-284):

| List | Steward | Members (local list replaced at build) | Direct users |
|---|---|---|---|
| DORA ICT Service Type (S01-S19, Annex III labels) | 41 | 40 DORA ICT Service Type, 41 ICT Service Type | 14 |
| GHG Scope Category | 34 | 34 Sustainability Indicator Scope, 44 GHG Scope Category | |
| Award Outcome | 11 | 11 Award Outcome, 42 Award Result | |
| Performance Rating | 40 | 14 Performance Rating, 40 Supplier Performance Rating | |

The ruling asked for 14 as a member of DORA ICT Service Type; 14 had no local list (it cited an external format), so it is a direct user and its example is now the Annex label "Data analysis". GHG Scope Category is the union of both lists, so 34 sees five Scope 3 category values it did not have.

**Overrides.** Dropped: enrich_38 two (OBL- now 38's), enrich_42 five (BRD- now 42's), enrich_43 two (AUTH- now 38's, BKAC- registered). Added: enrich_39 Subject ICARA Assessment (43) and enrich_42 Source Operational Emission Record (44), composite keys starting with LEN-; enrich_14 two (CD-264 profile references). Kept: genuine resolver corrections and composite-key guards in 37, 39, 40 and 43 (each tested: 39 Linked Securities Lending Agreement and 40 Fund Service Provider Role resolve correctly without theirs but are documented guards). The ", NN" qualifiers in 37-44 data types are kept.

### Candidate shared lists deferred

| Candidate | Raised by | Why deferred |
|---|---|---|
| Third-Party Risk Domain | 37 (14, 40) | Adds "Conduct and MNPI" to the 14 list; needs a code-list CD with 14. |
| DORA Substitutability | 40 (14) | 14 labels differ ("Highly Complex"); would change 14 values. |
| Governing Law | 39 (05, 26, 28, 40, 43, 44) | 39 adds "Maryland" to the 05 values; needs 05's agreement. |
| Committee Member Role / Corporate Member Role | 39 (24, 35, 36) | Values differ; Stage 3 deferral stands. |
| Basel Event Type L1 / L2, Model Type, Control Type, Assessment Level | 37 | Only 37 holds them. |
| Root Cause Category, Environment, Test Outcome | 41 (21, 37) | 21 holds no Environment list; root causes overlap only in part. |
| Stakeholder Group, Policy Topic, EU TR Cost Band | 42 (34, 37, 38) | Single user today. |
| Covenant Metric, Reference Rate, Cash Flow Category, Capital Regime, Insurance Coverage Line | 43 (17, 19, 22, 26, 30) | Values differ (fund vs corporate covenants) or external formats. |
| Assurance Level, Emission Factor Source, Calculation Method | 44 (34, 35, 42) | Single user today. |
| Job Level | 44 (20) | 44 cites "Firm-defined (20 Job Level)"; making it shared changes the 20 citation. |
| Payment Terms, Procurement Category, Third-Party Criticality Tier | 40 (05, 10, 12, 14, 19) | No complete value map. |
| Firm Filing Status, Surveillance Disposition, Corporate Officer Role, Corporate Meeting Type, Audit Rating, Expense Type, Badge / Card Status, Emergency Role | 37-44 | Recommended NOT_MERGED by their drafts. |

## 3. Decision list for the program lead (proposed for 01-36, not applied)

| # | Proposal | Source | Decision needed |
|---|---|---|---|
| 1 | 25 Trade Error Related Incident Reference → Reference (Operational Incident, 37), example OPINC-2026-01187 | proposals_37 | CD-244 |
| 2 | 10 Control "Control Reference" and 19 Close Task "Key Control Reference" → Reference (Control, 37); 07 Compensation Control gains "Library Control", Last Test Result Derived copy (37) | proposals_37 | CD-243 |
| 3 | 31 Risk Model Model Vendor, Risk Model Owner, Risk Model Status as Derived copies (37) | proposals_37 | CD-246 extension |
| 4 | 14 Vendor Risk Assessment Residual Risk Rating Derived copy (37) and a new "Enterprise Third-Party Risk Assessment" reference; 23 Expert Network Due Diligence Date Derived copy (37); 14 Data Vendor Strategic Tier (40 copy or rename) | proposals_37, _40 | CD-248 |
| 5 | 20 Key-Person Risk Indicator note; 14 UK Important Business Service Mapping and Impact Tolerance Dependency Indicator replaced by 37 Resilience Resource Mapping | proposals_37, _40 | CD-249 |
| 6 | 08 Distribution Conflict of Interest gains "Firm Conflict" (Reference (Conflict of Interest, 38)) | proposals_38 | CD-254 |
| 7 | 35 Board Report Source Item gains "Source Compliance Program Review" (38) | proposals_38 | CD-251 / CD-262 |
| 8 | 35 Fund Governing Body Charter Reference and Fund Advisory Agreement Agreement Document Location → Contract Document Version (39); 28 Securities Lending Agreement Agreement Document Reference dropped or Derived copy (39); 05 Agreement Document Location Derived copy (39) | proposals_39 | CD-257 (SME question 2) |
| 9 | 13 Servicing Provider Engagement gains Reference (Contract, 39) | proposals_39 | CD-257 |
| 10 | 30 side letter identity (commitment x date, or a 30 Side Letter header) | proposals_39 | CD-257 (SME question 9) |
| 11 | 15 Account Restriction Type "Legal Hold" note or rename to "Legal Restriction" | proposals_39 | CD-258 |
| 12 | 14 ICT Third-Party Register Entry Contractual Arrangement Reference → Reference (Contract, 39); 14 Vendor Risk Assessment Substitutability and Exit Strategy Documented Indicator Derived copies (40); "Supported IT Service" (41) on the 14 entry | proposals_40, _41 | CD-261, CD-268 |
| 13 | 19 Payable Invoice Line Invoiced Quantity and Unit Price; 19 Supplier Payment Remit-To Account (40) and employee payee rows | proposals_40, _44 | CD-158, CD-260, CD-280 (SME question 4) |
| 14 | 02 Tax Form Type and Tax Identification Number apply to the Supplier role; 40 Tax Form on File becomes a Derived copy (02) | proposals_40 | CD-143, CD-260 |
| 15 | 03 Activity Source System, 05 Sub-Accounting Platform, 30 Private Fund Platform → Reference (Application, 41) (optional); the excluded Record Metadata "System of Record" / "Source System" in 01-16 | proposals_41 | CD-263 |
| 16 | 21 relationship "AI Use Case is served by Application [41] via AI System Use Case Link" | proposals_41 | CD-269 |
| 17 | 13 / 12 Regulation S-P notices gain "Related IT Incident" (41) | proposals_41 | CD-266 |
| 18 | 04 Property Type "Corporate Website / Newsroom"; retire 04 Content Type "Press Release"; identifier on 04 Social Listening Mention | proposals_42 | CD-272 |
| 19 | 36 Readiness Check "Evidence Seed Capital Commitment" (43) and the Seed Capital workstream description; 19 Consolidation Scope Entity Group Ownership Percentage Derived copy (43) on fund rows | proposals_43 | CD-276 |
| 20 | 34 Portfolio Sustainability Metric own-operations rows as Derived copies (44) with indicator codes | proposals_44 | CD-281 |
| 21 | 27 Fund Expense Accrual "Recharged Expense Line" (44) | proposals_44 | CD-280 |
| 22 | 09 Office Location widened to "office or site"; 09 Unit of Measure tCO2e codes | proposals_44, _34 | CD-279, CD-229 |
| 23 | 44 Lease Accounting Measurement moves to 19 if lease accounting runs in the ERP | proposals_44 | CD-279 (SME question 2) |
| 24 | 30 Facility Drawdown renamed "Fund Credit Facility Drawdown" | proposals_43 | Term conflict Facility / Covenant |
| 25 | 20 Job Level shared with 44 | proposals_44 | New code-list CD |
| 26 | 28 Maximum On-Loan Percentage "future owner 01 as a fund policy limit" (an 01 proposal, not a Stage 4 owner) | proposals_28 | Stage 2 item (CD-198) |
| 27 | Deferred shared lists that change 01-36 values (§2: Third-Party Risk Domain, DORA Substitutability, Governing Law) | proposals_37, _39, _40 | New code-list CD |

Already listed in Stage 3 §3 and re-worded only (CD-285): 24 Risk Model Used (item 26), 27 Fund Tax Return Type (item 17), 27 Financial Highlights Total Return (item 18).

Within the new domains (no 01-36 change):
- 38 Regulatory Obligation Applicable Legal Entity: re-type Code to Reference (Legal Entity) (it moved with its 09 Derived copy flag; DP-083 reads it).
- 37 Critical or Important Function widened to a DORA B_06.01 business function register (40 row rule depends on it).
- 39 Contract Key Date "Notifying Side"; Governing Law values carry their ISO country; Typed Contract Link second link of type Supplier Contract Profile (40); "Linked Intercompany Loan" (43).
- 43 folding rule into 19 (CD-278) if there is no treasury function.
- Business process codes in 37 and 41 cite the capability map code, which no domain masters.

**Running total of deferred 01-NN decisions:** Stage 1 33, Stage 2 43, Stage 3 33, Stage 4 27 = 136 items for the program lead (some later stages resolved earlier items; the CDs above say which).

## 4. Data product layer and tooling follow-ups (not decisions)

- **Lineage re-pointed** (names unchanged, so only the domain changed): specs DP-013 (`specs_b_foundational.py`), DP-041 (`specs_f_compliance.py`), DP-083 (`specs_n_compliance_controls.py`) to 38 Entity Authorization, Cross-Border Passport, Regulatory Obligation and Attestation; DP-090 (`specs_m_clients_privacy_digital.py`) to 42 Brand. Models `models_f3.py`, `models_c4_compliance.py`, `models_c8_compliance2.py`, `models_c2_marketing_product.py`; keys moved from `keys_g2_03_04_05.py` and `keys_g4_08_09.py` to the new `keys_g9_37_44.py`; the 12 Report Template Brand link in `keys_g5_11_12_13_14.py` names 42. The gap register (`gaps_register.py`, GAP-01-018, GAP-04-016, GAP-08-024 to 026, GAP-11-018) names the new owners. Semantic models needed no change.
- **Product owners unchanged.** DP-083 still names 08 as owning domain, so dp_model warns that 08 is not among its inputs. Data products gain no scope in the expansion (plan §2); re-assigning the owner is for Step 5.
- **Re-typed references in models.** dm_model raised no error for the Code / Text → Reference re-typings in DP-001, DP-004, DP-044 and DP-075; their keys registry has no link for the new references (they are attributes, not joins).
- **Resolver rule 0.** 21 Record Governance Metadata "System of Record" is a Reference (Application, 41) but resolves "Mastered here", because `ownership.GOVERNANCE_METADATA` names it.
- **Explorer.** New group "Corporate and support functions (Stage 4)" with taglines and short names for 37-44, and a fourth band color (`--g-corporate`) in light and dark themes. No area views.
- **Semantic model output** still rewrites `_cols` order on each run (SM-00 ... SM-07 YAML diffs are ordering only).
- **Row Ownership Rule** (plan §4 item 9) is needed for 39 Contract (declared owner "05" stand-in) and 37 Loss Event Amount; ratify at Step 5.

## 5. Baseline reconciliation (check_baseline.py against stage3-v0.1)

`check_baseline.py --check stage3-v0.1 --allow CD-143,CD-245,CD-246,CD-250,CD-252,CD-255,CD-256,CD-257,CD-258,CD-259,CD-260,CD-261,CD-262,CD-263,CD-264,CD-267,CD-268,CD-271,CD-274,CD-276,CD-277,CD-279,CD-280,CD-281,CD-282,CD-283,CD-284,CD-285` fails, as expected, with 31 sections: 28 Data Domains (01, 02, 04, 08-12, 14, 18-36), the registers, data products and logical models (semantic models: no difference). All validators pass (44 modules, 0 unresolved). Each difference was checked against a flattened attribute, code list, relationship and object model of 01-36 built from HEAD (identical to stage3-v0.1) and from the working tree.

### Data Domains 01-36

| Domain | Reported difference | Cause | CD |
|---|---|---|---|
| 01 | Source System re-typed; references +1 | System Cross-Reference Source System → Application (41) | CD-263 |
| 02 | Legal Hold Indicator derived; Party Role Type +32; Regulator values | Derived copy (39); party roles; shared Regulator | CD-258, CD-143, CD-255 |
| 04 | Brand removed (6 attributes, 2 CDEs, 2 lists, 1 relationship); Marketing System; family text; positional IDs of Marketing Theme and Messaging Pillar | Move to 42; Inventoried Application added, System Name derived | CD-271, CD-264 |
| 08 | Regulatory Obligation and Attestation removed (11 attributes, 4 lists, 2 relationships); family DC-GOV left with only excluded Record Metadata (families 10 → 9); Legal Hold Indicator derived | Move to 38 | CD-252, CD-258 |
| 09 | Entity Authorization and Cross-Border Passport removed (16 attributes, 4 lists, Shared: Regulator, 2 relationships); Code Mapping, Reference Data Subscription re-typed; overview and family text; positional IDs of Entity Distribution Role | Move to 38; Application (41) | CD-250, CD-263 |
| 10 | Business Domain values | 22-44 added | CD-283 |
| 11 | Award Outcome is shared; Regulator values | New shared list | CD-284, CD-255 |
| 12 | Report Template Brand owner 04 → 42; relationship | BRD- transfer | CD-271 |
| 14 | Consuming Application keyed by APPL-, Application Name derived; Procurement Supplier ID derived; 5 ICT register fields derived, 2 notes; Performance Rating and DORA ICT Service Type shared; Business Domain values | | CD-264, CD-260, CD-261, CD-268, CD-284, CD-283 |
| 18 | Book of Record System, Event Source System re-typed; Proprietary Capital Indicator derived | | CD-263, CD-276 |
| 19 | Purchase Order Reference, Paying Bank Account, Bank Statement Entry Reference re-typed; capital amounts derived; Journal Source +2, Regulatory Return Type +1; overview; Regulator values | | CD-260, CD-274, CD-277, CD-279, CD-280, CD-285, CD-255 |
| 20 | Supplier Contract Reference re-typed; Learning Item Type source; overview; Regulator values | | CD-257, CD-252, CD-285, CD-255 |
| 21 | Four system attributes re-typed, System list retired; AI Use Case Model Name re-typed and relationship; CDE Regulatory Driver source; Business Domain values; overview | | CD-263, CD-246, CD-252, CD-283, CD-285 |
| 22 | Valuation Model Name re-typed; overview | | CD-246, CD-285 |
| 23 | MNPI Escalation Reference re-typed; relationship; Expert Network note | | CD-256, CD-285 |
| 24 | Decision Algorithm Code derived; Rebalance notes; overview | | CD-246, CD-285 |
| 25 | Large Trader ID derived; relationship; Trade Error note; overview; Regulator values | | CD-250, CD-256, CD-285, CD-255 |
| 26 | Trade Reporting family text; Regulator values | | CD-250, CD-255 |
| 27 | Overview, family, note and relationship texts; Regulator values | | CD-285, CD-255 |
| 28 | CASS Entity Authorization owner 09 → 38; Service Agreement Reference re-typed; relationship note; overview; summary | | CD-250, CD-257, CD-285 |
| 29 | Escalation Case Reference re-typed; disposition value; relationship; overview, family text | | CD-255, CD-285 |
| 30 | Overview, family and source texts | | CD-285 |
| 31 | Model Inventory Reference re-typed; relationship; overview, family, source texts; Regulator values | | CD-246, CD-285, CD-255 |
| 32 | Model Inventory Reference re-typed | | CD-246 |
| 33 | Restricted List Source re-typed; relationship; overview and group text; Regulator values | | CD-256, CD-285, CD-255 |
| 34 | Two model attributes re-typed; GHG Scope Category shared (+5 values); Passive Status Review note | | CD-246, CD-284, CD-251 |
| 35 | Overview, family and note texts; Regulator values | | CD-285, CD-255 |
| 36 | Launch Project Code derived; seed and project notes; Readiness Check note; list description; Regulator values | | CD-267, CD-276, CD-285, CD-255 |
| 03, 05, 06, 07, 13, 15, 16, 17 | No difference reported (17's overview text changed under CD-285, but overview text is not part of the baseline record) | | |

### Registers

| Register | Reported difference | CD |
|---|---|---|
| Decisions | 43 added (CD-243 to CD-285); CD-143 changed | merge; CD-283 to CD-285; CD-143 |
| Prefixes | 56 added; AUTH-, OBL-, BRD- owner changed; DAPP- retired | CD-283, CD-250, CD-252, CD-271, CD-264 |
| Concept ownership | 235 added; Brand owner 04 → 42 | CD-283, CD-271 |
| Term conflicts | 36 added (35 reported; one names only 37-44 and is an expansion addition), 26 extended | CD-283 |
| Shared code lists | 4 added; 23 changed (direct users 37-44; Regulator values and members; Business Domain values) | CD-284, CD-283, CD-255, CD-250 |
| Local renames | Compliance Attestation Type 08 → 38 | CD-252 |

### Data products, logical models and semantic models

| Layer | Reported difference | CD |
|---|---|---|
| Data products | Links by domain 04 −6, 08 −11, 09 −33, 38 +44, 42 +6; DP-013, DP-041, DP-083, DP-090 changed; DP-083 owner warning | CD-250, CD-252, CD-271 |
| Logical models | DP-013, DP-041, DP-083, DP-090 (re-pointed); DP-001, DP-004, DP-044, DP-075 (inherited re-typings of 01, 09, 14, 04); DP-026, DP-074 (positional IDs of 04 Marketing Theme and 09 Entity Distribution Role); DP-068 (12 Report Template Brand owner) | CD-250, CD-252, CD-271, CD-263, CD-264 |
| Semantic models | No difference | |

`--check stage4-v0.1` passes after `--snapshot stage4-v0.1`.

Against `distribution-v0.4`, `--allow` was given the Stage 1-4 decisions. The check reports the same 20 sections as at Stage 3 (16 Data Domains, registers, data products, logical models, semantic models). Stage 4 adds differences only in 01, 02, 04, 08, 09, 10, 11, 12 and 14, all listed above; 03, 05, 06, 07, 13, 15 and 16 are unchanged since stage3-v0.1, so their differences are the Stage 1-3 ones in the earlier notes.
