# Step 5 consolidation notes (2026-10-07)

Step 5 of the enterprise expansion (Enterprise_Expansion_Plan.md §6) is the consolidation pass across all 44 Data Domains. This file records what the consolidation stream applied (CD-286 to CD-290, and CD-150), what it rejected and why, and the reconciliation of every difference that `check_baseline.py` reports against `stage4-v0.1`. The explorer areas and the capability coverage test ran as separate streams and are not covered here. The deferred decision lists of Stages 1-4 (each notes file's §3) were not applied, except where an item was purely a shared code list (§1 below names those items).

No new snapshot was taken; the program lead takes it after integrating the three streams.

| Decision | Status | What changed |
|---|---|---|
| CD-286 | Applied | 41 shared code lists (§1) |
| CD-287 | Applied | `resolution` and `status` on all 170 term conflicts (§2) |
| CD-288 | Applied | 234 key formats; 212 example tokens aligned (§3) |
| CD-289 | Applied | Row Ownership Rule convention; 52 rules (§4) |
| CD-150 | Applied (was Proposed) | Enterprise workbook renamed, distribution view kept as a filter (§5) |
| CD-290 | Applied | DP-083 owner, DP-056 warning, deterministic semantic model output (§6) |

## 1. Shared code lists (CD-286)

**Rule applied.** A shared list was created where two or more Data Domains hold the same vocabulary, either as a local list or as an "External (NN list)" citation of another domain's list, and where a complete value map can be written. The steward is the domain that defines the concept. Generic vocabularies go to 09.

How each domain joined a list:
- **Members.** Lists in 01-16, steward lists, and lists whose name or labels differ are members with a value map. The content module keeps the list, and the builder replaces it at build time.
- **Direct users.** Label-identical copies in 17-44 and "External (NN list)" citations were re-pointed to `Shared: <name>`, and the local copy was removed from the content module.

No value was dropped: every value map is complete (no value maps to None).

**Created (41):**

| List | Steward | Members (local list replaced at build) | Direct users (local copy or citation re-pointed) | Note |
|---|---|---|---|---|
| Vehicle Type | 01 | 01 | 17, 36 | 17 held a subset |
| Regulatory Regime | 01 | 01 | 17, 36 | 33 keeps its local list (see rejected) |
| Distribution Policy | 01 | 01 | 17, 36 | |
| MMF Type | 01 | 01 | 17 | |
| Asset Class | 01 | 01 | 36 | product asset class; instrument level is Instrument Asset Class |
| Hedging Type | 01 | 01 | 36 | |
| Share Class Type | 01 | 01 | 36 | |
| Return Type | 01 | 01, 22 Index Level Variant | 32 | identical values (CD-169 names the reuse) |
| Measurement Basis | 01 | 01 | 33 | identical since CD-241 |
| Restriction Limit Type | 01 | 01 Limit Type | 33 (was Rule Limit Type) | distinct from 25 Limit Type |
| Identifier Status | 09 | 02, 15 | 17 | |
| Business Day Convention | 09 | 09, 17 | | 17 "No Adjustment" maps to Unadjusted |
| Meeting Format | 09 | 35, 23 Meeting Channel | | 23 Video maps to Virtual, Telephone to Telephonic |
| Cost Bearer | 13 | 13 | 29 | 36 Cost Bearer (reorganization costs) stays local |
| Instrument Asset Class | 17 | 17 | 24, 22 (citation) | 24's usage rule moved to the attribute notes |
| Instrument Type | 17 | 17 | 22, 24, 26 (citations) | |
| Day Count Convention | 17 | 17 | 26 (was External ISDA) | |
| Credit Outlook | 17 | 17 Credit Rating Outlook | 23 | Not Assigned applies to agency ratings only |
| Lot Relief Method | 18 | 18 | 24 | NOT_MERGED with 15 Cost Basis Method stands |
| Holding View | 18 | 18 | 31 (citation) | |
| Accounting Basis | 19 | 19, 10 Accounting Framework | 27 | 10 sees Irish GAAP, Tax Basis, Regulatory |
| Plan Version Status | 19 | 19, 10 | | 10 sees Superseded |
| Financial Plan Type | 19 | 19 Plan Type, 10 Plan Type | | replaces the 10 LOCAL_RENAMES entry of the same name |
| Plan Scenario | 19 | 19, 10 Scenario | | 10 sees Capital and Liquidity Stress |
| Job Level | 20 | 20 | 44 (was Firm-defined citation) | |
| Metric Direction | 21 | 21 | 37 (citation) | |
| Approved Price Basis | 22 | 22 | 18 (citation) | |
| Measure Unit | 22 | 22 | 30, 31 (citation) | |
| Rate Tenor | 22 | 22 | 31, 43 (citations) | |
| Order Side | 25 | 25 | 24 (was Proposed Trade Side) | 24 sees Subscribe |
| Regulatory Report Status | 25 | 25 Transaction Report Status, 28 Loan Report Status | | union, adds Not Required |
| Collateral Type | 26 | 26, 28 Lending Collateral Type | | union, adds Letters of Credit and Other |
| Regulatory Trade Report Regime | 26 | 26 Trade Report Regime, 28 Loan Reporting Regime | | union, adds SEC Rule 10c-1a |
| Waiver Type | 27 | 27, 10 | | identical |
| Fund Dealing Settlement Method | 29 | 29 Order Settlement Method, 05 Settlement Method | | 05 sees Direct Investor Payment |
| Exposure Method | 31 | 31 | 33 (citation) | 01 not included (split deferred) |
| Risk Measure | 31 | 31 | 33 (citation) | |
| COLL Change Classification | 36 | 36, 13 | | identical; the 13 derived copy stays deferred |
| Third-Party Risk Domain | 37 | 37, 14 Vendor Risk Domain | | 14 sees Conduct and MNPI |
| DORA Substitutability | 40 | 40, 14 Substitutability | | 14 labels follow DORA |
| Governing Law | 39 | 39, 05 | | 05 sees Maryland |

Also: 36 became a direct user of the existing **Investor Category** list, and its local copy of the 01 Investor Type list was removed. Shared lists grew from 57 to 98. Code list uses went from 1,762 local and 370 shared to 1,682 local and 464 shared.

**Stage 1-4 §3 items closed by CD-286, shared-list part only.** Stage 1 items 5 and 16 (the list part: the 10 "Scenario" list now shows as "Plan Scenario"); Stage 2 items 8, 13 (list part only; the 05 family rename is not applied), 23, 25 (13 and 29; 27 holds no Cost Bearer list), 32 and 39 (Accounting Basis only); Stage 3 items 15 (list part only; the 13 derived copy is not applied) and 25; Stage 4 items 25 and 27. Every other part of those items is untouched.

**Message Standard and Data Provider.** Every value proposed in Stages 1-4 is in the lists (proposals_17, _22, _25, _26, _28 and _34). The only value not added is "MSCI ESG Research", which proposals_34 itself marked optional, recommending MSCI with the product named through the 14 dataset. It stays as Stage 3 §3 item 32 for the program lead. 26 Settlement Message Standard stays NOT_MERGED (MT-level values).

**Rejected: 41 candidate groups (about 120 list names), with reasons:**

| Candidate | Raised by | Why not created |
|---|---|---|
| Instrument Identifier Scheme | 17 | 14 Identifier Scheme mixes party and instrument schemes (NOT_MERGED with 02); 01 and 11 hold identifiers as columns, not a list |
| Credit Rating Agency; Corporate Action Event Type, Option Type, Mandatory Voluntary, Announcement Status; Settlement Method / Option Style (17) | 17 | Only 17 holds them; 28 holds different CA lists (entitlement status, payment type); 17 Settlement Method is cash or physical settlement, a different concept from 05 and 29 |
| Private Fund Strategy (17 = 30) | 17, 30 | Identical values, but the steward is pending: the program lead's ruling makes it an 01 sub-asset class (Stage 2 §3 item 11, CD-205) |
| Operating Model (IBOR, Pricing, Trading, Fund Accounting, Administration, NAV Calculation Source) | 18, 22, 25, 27, 30 | Values differ by function (Shadow of Client Custodian Record, Sponsor or Client Priced, Delegated to Sub-Adviser, Trustee Bank); no complete map without CD-147 |
| Investment Transaction Type, Quantity Unit, Long / Short Indicator, Transaction Cost Category | 18 | Only 18 holds them |
| Portfolio Identifier Scheme | 18 | NOT_MERGED with 15 Account Identifier Scheme (recorded at Stage 1) |
| Payment Method (19 vs 29 Order Payment Method) | 19, 29 | 19 "Wire Transfer" must be split into Fedwire, CHAPS and TARGET2 to map; needs SME |
| Tax Type, Financial Statement Type, Regulatory Return Type | 19 | Only 19 holds a list; Tax waits on CD-149 |
| Employment Type, Employment Status (03 copies) | 20 | The 03 copies are unused and already drop out of the 03 workbook; retiring them is Stage 1 §3 item 23 |
| Job Family, Regulated Role Category / SM&CR, Separation Reason, Gender Identity, Completion Status / CE Status, Readiness | 20 | Values differ (SM&CR roles vs statuses; Complete vs Completed; CE-specific values) or single user |
| Governance Role, Governance Certification Status, Governance Priority, Semantic Model, Data Product Business Function and Delivery Mode, Metric Aggregation Rule, Metric Unit | 21 | Only 21 holds them, or they should be generated from framework.py and register.py. Governance Priority equals 23 Conviction Level and 37 Assessment Level in values (High, Medium, Low) but not in meaning |
| Price Type, Price Origin, Fair Value Hierarchy Level, Observation Status, FX Rate Basis | 22 | Only 22 holds them |
| Internal Credit Rating Scale, Internal Credit Rating, Research Subject Type | 23 | Only 23 holds them |
| Basket Type / Basket Settlement Form / 06 ETF Basket Type | 24, 29, 06 | Needs the 06 list split (Stage 2 §3 item 16) |
| Committee Member Role (24, 35, 36, 39 variants) | 24, 35, 36, 39 | Values differ; no complete map |
| Portfolio Management Role; Investment Decision Cause | 24 | Depends on CD-175; 24 and 25 asked to map, not merge |
| Trade Allocation Method, Counterparty Approved Activity, Execution Factor, Trading Asset Class, Review Outcome | 25 | Single user, or a different cut (Trading Asset Class vs Instrument Asset Class), or different values (12, 25, 28, 33 review outcomes) |
| Settlement Type, Trade Settlement Status / Order Settlement Status | 26, 29 | Failing vs Failed and Returned vs Reversed not reconciled; 10 Settlement Status is different |
| Message Processing Status (26) | 26 | Instruction processing states (Sent, Cancellation Requested) differ from regulatory report status; kept out of Regulatory Report Status |
| Trading Agreement Type / enterprise Contract Type | 26, 39 | Crosswalk to 39 Contract Subtype, not a merge (proposals_39) |
| Responsible Party Type | 26 | Single user |
| Fund Expense Type, Distribution Character, NAV Control Check Type, Income Type, NAV Dissemination Channel | 27, 29 | Single user today (27 no longer holds the NAV Dissemination Channel list) |
| Custody Provider Role, Custody Holding Model, Custodian Balance Type, Custody Break Type / Break Root Cause, Safekeeping Account Type / Assignment Purpose, Tax Relief Method / Reclaim Status | 28 | 02 role granularity; 13 Holding Model is a different concept; 06 Break Type labels need SME mapping; 18 replacement is Stage 2 §3 item 38; 13 Reclaim Status differs |
| Order Exception Type, Fund Order Status, Monitoring Alert Disposition, TA Control Type | 29 | Recommended NOT_MERGED by 29 |
| Capital Call Purpose, Portfolio Company Ownership Type | 30 | Single user |
| Liquidity Category, Liquidity Horizon Bucket, Confidence Level, Risk Dimension, Counterparty Exposure Measure vs 25 Limit Type | 31 | Single user, or not identical (31 adds four measures) |
| Exposure Method with 01 Risk Measurement Method and Leverage Method | 31, 01 | Needs the 01 list split (Stage 3 §3 item 10); 31 and 33 share it now |
| Price Basis, Return Status, Measured Subject Type, Return Source | 32 | Single user |
| Regulatory Regime for 33 | 33 | 33 adds IRC 817(h) Insurance-Dedicated and ERISA Plan Assets; adding them to 01 is Stage 3 §3 item 7 |
| Rule Instrument List Type | 33 | Kept local by 33 |
| Proposal Category, ESG Rating Type, Engagement Contact Medium, ESG Topic, Metric Framework, Exclusion Policy Basis | 34 | NOT_MERGED recommended, partial overlap only, or single user |
| Filing Form Type, Filing Status, Board Meeting Type, Fund Officer Role, Consent Type | 35 | Recommended NOT_MERGED, or single user |
| Product Lifecycle Event Type, Product Review Outcome / Value Assessment Outcome, 36 Cost Bearer | 36 | Tied to CD-236 and CD-238 (01 derived copies, Stage 3 §3 items 11 and 13); 36 Cost Bearer holds reorganization payers, which have different values |
| Audit Rating, Basel Event Type L1 and L2, Model Type, Control Type, Assessment Level (with 40 DORA Assessment Level) | 37 | Single user; 40's list is the DORA ITS value set for two register fields; 37 Audit Rating equals 13 Oversight Rating in values but not in meaning |
| Firm Filing Status, Surveillance Disposition, Personal Trade Side, Entity Authorization Type, Policy Domain | 38 | Recommended NOT_MERGED or local by 38 |
| Corporate Member Role, Corporate Officer Role, Corporate Meeting Type, Contract Family / Subtype | 39 | Recommended NOT_MERGED, or crosswalk |
| Supplier Status, Third-Party Criticality Tier, Payment Terms, Procurement Category; 13 Oversight Rating to Performance Rating | 40 | Labels differ (14 Vendor Strategic Tier, SME), single user, or a lossy map (Satisfactory / Needs Improvement / Unsatisfactory against a four-point scale) |
| Environment, Root Cause Category, Test Outcome, Ownership Role | 41 | Single user, or partial overlap with 06, 08, 13, 14, 21, 28 root causes |
| Stakeholder Group, Policy Topic, EU TR Cost Band | 42 | Single user |
| Reference Rate, Covenant Metric (with 30 Covenant Type), Cash Flow Category, Capital Regime, Insurance Coverage Line | 43 | External format, disjoint value sets, or single user |
| Assurance Level, Emission Factor Source, Calculation Method, Lease Classification, Expense Type, Badge / Card Status, Emergency Role | 44 | Single user, waiting on the CD-279 move, or recommended NOT_MERGED |

The scan also found equal lists that no stage proposed: 04 Personal Data Classification and 21 Personal Data Sensitivity (Stage 1 §3 item 28); 02, 15 and 40 Tax Form Type (Stage 4 §3 item 14); 24 Basket Purpose and 29 AP Order Type; 02 and 04 Communication Channel and the opt-in lists (04 copies unused). They are left for the program lead. The 01-16 "External (NN list)" citations (for example 05 citing 01 Vehicle Type) were not re-pointed, because that would edit 01-16 content beyond registering members.

## 2. Term conflicts (CD-287)

Each of the 170 TERM_CONFLICTS entries now has:
- `resolution`: the glossary's primary sense, naming the domain and the meaning, and how the other uses are qualified.
- `status`: "Resolved" when the resolution follows from Applied decisions or is purely a naming rule. "SME" when it rests on a Proposed or SME decision, or on an open client choice.

**Result: 124 Resolved, 46 SME.** The SME entries rest on, by theme:
- **Distribution measures:** Revenue (CD-040), AUM (CD-047, AUM vs AUA), Net Flow (CD-041), Territory / Market (CD-052, CD-053), Fee (CD-023), DDQ (CD-060).
- **Ratings and agreements:** Rating (CD-020, CD-173, CD-228), Agreement (CD-182).
- **Tax:** Tax (CD-149).
- **Investment book:** Position (CD-146), Portfolio (CD-145).
- **Governance:** Catalog and lineage terms (CD-160, CD-161); Coverage and Order terms (CD-172, CD-185); NAV Release (CD-187, CD-193); Index (CD-169); Board (CD-231); Model and PM roles (CD-175).
- **Investment oversight:** Accrual (CD-186); Carried Interest (CD-205); Engagement (CD-227); Exposure and Tracking Error (CD-211); Limit and Exceedance (CD-223); Exclusion (CD-228); Reconciliation (CD-196); Collateral (CD-198).
- **Corporate functions:** Readiness (CD-239), Incident (CD-266), Control (CD-243), Test (CD-249, CD-270).
- **Open questions with no CD:** Expense Ratio (27 SME question 10), Vintage Year, the SMA sponsor program key, Hold (15 "Legal Restriction"), Service, Measurement (lease accounting in 19 or 44).

Judgment calls to review:
- **Facility / Covenant** is Resolved as a naming rule, though it recommends renaming the 30 object to "Fund Credit Facility Drawdown" (Stage 4 §3 item 24).
- **Accrual** is SME only because of its management-fee note.
- **Agreement** is SME only because CD-182 is Proposed. The bare "agreement" alias already resolves to 05.

The resolutions were drafted per entry from the recommendation and checked against the decision status. CONTRACT.md documents the two keys, and the Term Conflicts sheet shows them, filterable by status. The enterprise Overview counts Resolved and SME.

## 3. Key formats (CD-288)

**Published.** PREFIX_FORMATS went from 137 to 371 rows. 234 rows were added: every Registered or Proposed prefix that lacked a format and has an example somewhere. Each format is taken from the owning module's most common example shape:
- Numeric segments are written as sequences of n digits, years or dates.
- Mnemonic and sub-typed keys were written by hand: PTY- (households PTY-HH-), AGR- (amendments and obligations), GEO-, CAL-, OU-, TER-, MSR-, RET-, VIS-, DP-, CD-, SITE- and ICS-.
- Where the owner's own examples were tied between two shapes (RFP-, ICP-, LAU-), the plain shape was published and the suffixed shape is a documented variant.

**Not published.** 12 proposed prefixes have no example anywhere: IDX-, PFEE-, PEMP-, PIEL-, PLIM-, LREP-, PVST-, PVBL-, PRMD-, OVR-, XWK- and UNA-.

**Aligned: 212 example tokens in 27 domains.** These had the published structure and differed only in digit count, and the change is lossless (zero-padding, or dropping leading zeros). By domain:

| Domain | 01 | 02 | 03 | 04 | 05 | 06 | 07 | 08 | 09 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 18 | 19 | 23 | 24 | 25 | 28 | 29 | 33 | 35 | 36 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Tokens aligned | 13 | 4 | 38 | 28 | 15 | 18 | 9 | 20 | 2 | 7 | 11 | 7 | 3 | 3 | 4 | 3 | 3 | 7 | 1 | 1 | 4 | 3 | 4 | 2 | 1 | 1 |

Examples of the changes:
- PTY-3301 to PTY-003301
- EMP-0107 to EMP-00107 and EMP-003390 to EMP-03390
- DSET-0042 to DSET-00042 (closes the example part of Stage 2 §3 item 22)
- MDL-00045 to MDL-0077-style 4 digits
- SHC-04412 to SHC-004412
- STR-0012 to STR-00012
- LIC-, CMP-, REV- and others

Only examples were changed; definitions and notes that quote an ID were not. Two false matches were left untouched: TX-ACC-014 and AC-ACC-002 are attribute IDs, not account keys.

**Logged, not changed: 143 tokens.**

| Prefix | Tokens | Domains | Examples | Why |
|---|---|---|---|---|
| `PTY-` | 77 | 11, 16, 17, 23, 30, 32-35, 38 | PTY-1002214, PTY-7001234 | 7 digits with a significant first digit; the owner format has 6 |
| `PTY-` | 4 | 02, 05 | PTY-HH-55012, PTY-3301-C04 | household sub-type and contact suffixes (documented variants) |
| `TXN-` | 12 | 04, 08, 10, 12, 16 | TXN-88120455, TXN-2026-11-0099812 | different structure from TXN-<year>-<9 digits> |
| `ACC-` | 5 | 16 | ACC-301121-004471 | plan x participant composite |
| `ICP-`, `RFP-`, `LAU-`, `JNL-`, `SNP-`, `DP-`, `SHC-`, `AGR-` | 14 | 03, 05, 06, 07, 10, 14, 16, 19, 21, 39 | ICP-US-EW-2027-C02, RFP-2026-0312-Q045, AGR-004512-A03 | sub-record suffixes of the owner's key (versions, questions, amendments) |
| `CAM-`, `EVT-`, `OPP-`, `REV-`, `LEAD-`, `DDQ-`, `CMT-`, `DQR-` | 19 | 03, 04, 05, 08, 10, 22, 23 | CAM-2026-017, EVT-2026-0133, OPP-118230, DQR-00412 | a year-sequence or plain-sequence shape that differs from the owner's |
| `JNL-`, `RRN-`, `STMT-`, `ACT-` | 6 | 04, 12, 16, 20 | JNL-2027-04-118230, RRN-2026M08-003311 | longer than the format with significant digits, or monthly instead of quarterly periods |
| `POS-`, `PORT-`, `ABD-`, `ARC-`, `FCS-`, `IDR-`, `DIST-` | 9 | 03, 05, 07, 09, 10, 11, 16, 19 | POS-881023, PORT-SEED-0041, DIST-US | different structure (DIST-US is a distribution code, not the 16 DIST- prefix) |

These need an owner's call: either re-key the sibling example, or widen the published format to admit the variant.

## 4. Per-row ownership (CD-289)

The plan §4 item 9 convention is ratified as an optional enrichment key, `ROW_OWNERSHIP = {(family, object, attribute): "rule text"}`. Tooling:
- **enrichment/CONTRACT.md** documents the key.
- **check_enrichment.py** validates that each key is an attribute in the content module.
- **ownership.py** never reads it, so every flag stays as declared.
- **taxonomy_builder.py** writes a "Row Ownership Rule" column (Q) on every Taxonomy tab.
- **build_enterprise.py** adds column S on Enterprise Attributes and an Overview count.
- **build_index.py** lists each object's rules on the Hierarchy Index.

**52 rules in 21 domains** were taken from the row rules already written in attribute notes. The scan looked for "row rule", "mastered here only", "owner = domain of the typed link" and "copied from", and kept the rules that say which rows are mastered where:

| Domain | Rules | Domain | Rules | Domain | Rules |
|---|---|---|---|---|---|
| 06 | 4 | 26 | 2 | 35 | 1 |
| 14 | 2 | 27 | 2 | 36 | 2 |
| 15 | 1 | 29 | 2 | 37 | 5 |
| 18 | 5 | 30 | 1 | 38 | 2 |
| 22 | 3 | 31 | 2 | 39 | 9 |
| 24 | 1 | 32 | 3 | 40 | 1 |
| | | 34 | 2 | 43 | 1 |
| | | | | 44 | 1 |

Key cases:
- **39 Contract.** Seven attributes flagged Derived copy (05) or Reference now state that the "05" is a stand-in: the owner is the domain of the typed link, and 39 masters untyped rows.
- **37 Loss Event Amount and Operational Loss Event.** The rules name their typed sources.
- **06 Transaction Dates and Order Source.** The rules cover TA-processed rows.

Rules left out:
- Structural rules that do not move ownership, such as "exactly one of A and B is filled".
- Proposed row rules (18 Fund Interest Holding Detail, 30 Investor Capital Account).
- The 33 note that states 25's copy rule. It belongs on 25 Trade Order Event, which carries it in its own note.

No ownership flag changed: the baseline reports no ownership difference.

## 5. Rename to enterprise scope (CD-150)

What changed:
- `00_Program/Enterprise_Distribution_Data_Taxonomy.xlsx` is now `00_Program/Enterprise_Data_Taxonomy.xlsx`. The file was moved and rebuilt, and build_enterprise.py writes the new path.
- The workbook Overview is titled "Enterprise Data Taxonomy (Consolidated)" and gains "Distribution view" and "Row ownership" rows.
- **Distribution view.** The Data Domains sheet has two new filterable columns: "Area", read only from `capability_map/areas.py`, and "Distribution View" (Y for 01-16). The Taxonomy Index Data Domains sheet has the same columns and a filter. No separate workbook is produced.
- The domain workbooks' consolidation overview text names the new file.
- Program_Plan.md is retitled "Enterprise Data Taxonomy Program" with a note on the old name, and its status list and folder tree are updated.
- The new name also appears in the conventions document's register pointer (§9), the expansion plan (§4 items 8 and 9 marked done) and _tools/README.md. README.md also carries the redirect note for one release.
- Historical sections that mention the old name are unchanged: CD-150's issue text and proposals_expansion.

Not touched:
- `Taxonomy_Explorer.html`, build_explorer.py and the explorer templates belong to the explorer stream.
- The capability map files.
- No script outside build_enterprise.py read the old path (checked by grep).

## 6. Data products (CD-290)

- **DP-083 Regulatory Obligations, Attestations & Horizon.** The owning domain changed from 08 to 38 in `data_products/framework.py`. 38 masters Regulatory Obligation and Attestation, the product's core objects (CD-252), and its spec inputs come from 38, 01, 09, 11 and 20. The dp_model warning "owning domain 08 is not among its input domains" is cleared. The owner role (Head of Compliance Risk & Controls) is unchanged.
- **DP-056 PII warning.** Documented, not suppressed. The product publishes at cost center, team and category level. Its notes already justify `pii="N"` against the 20 Employee attributes it reads, which data_products/CONTRACT.md rule 6 allows ("fix a WARNING, or justify it in notes"). The other eight pii=N warnings are pre-Stage 1 and the same kind.
- **Semantic model YAML ordering.** `semantic_model/build_semantic_model.py` `_scalar()` now writes sets sorted. The validator's `_cols` sets were the only random-order output. Two consecutive builds produce byte-identical `semantic_model/out/`.
- **Validation:**
  - dp_model: 96 specs, 0 errors, 9 warnings (10 before)
  - dm_model: 96 models, 0 errors, 2 warnings
  - sm_model: 8 models, 0 errors, 1 warning

## 7. Reconciliation (check_baseline.py against stage4-v0.1)

`check_baseline.py --check stage4-v0.1 --allow CD-150,CD-286,CD-287,CD-288,CD-289,CD-290` fails, as expected, with 42 sections:
- 40 Data Domains (all but 34, 38, 41 and 42)
- the registers
- data products

All validators pass: 44 modules, 0 unresolved references, check_enrichment 44/44. Logical models and semantic models show no difference.

Each content difference was checked against a field-level comparison of every content module at the tag `stage4-v0.1` and in the working tree. In that comparison:
- no attribute was added, removed or renamed
- no definition, data type, reference, CDE flag, relationship, source or META changed
- the only changes are examples, code-list citations and three 24 notes

| Domain | Reported difference | Cause | CD |
|---|---|---|---|
| 01 | Local lists 58 to 48, shared 6 to 16; attributes (examples) changed; code list values | 10 lists became members (Vehicle Type, Regulatory Regime, Distribution Policy, MMF Type, Asset Class, Hedging Type, Share Class Type, Return Type, Measurement Basis, Limit Type as Restriction Limit Type); 12 example tokens aligned | CD-286, CD-288 |
| 02 | Local 79 to 78, shared +1; examples; values | Identifier Status member; 4 examples | CD-286, CD-288 |
| 03, 04, 06, 07, 08, 11, 12, 16 | Attributes and objects changed | Examples aligned only (34, 27, 18, 9, 19, 11, 7, 3 attributes) | CD-288 |
| 05 | Local 56 to 54, shared +2; examples; values | Governing Law (+Maryland) and Settlement Method (as Fund Dealing Settlement Method, +Direct Investor Payment) members; 15 examples | CD-286, CD-288 |
| 09 | Local 50 to 49, shared +1; examples; values | Business Day Convention member; 2 examples | CD-286, CD-288 |
| 10 | Local 42 to 37, shared 3 to 8; examples; values | Accounting Framework, Plan Version Status, Plan Type (LOCAL_RENAMES entry replaced by the shared Financial Plan Type), Scenario, Waiver Type members; 7 examples | CD-286, CD-288 |
| 13 | Local 56 to 54, shared +2; examples; values | Cost Bearer, COLL Change Classification members; 3 examples | CD-286, CD-288 |
| 14 | Local 50 to 48, shared +2; examples; values | Vendor Risk Domain, Substitutability members; 3 examples | CD-286, CD-288 |
| 15 | Local 41 to 40, shared +1; examples; values | Identifier Status member; 4 examples | CD-286, CD-288 |
| 17 | Local 42 to 32, shared 6 to 16; values | 5 local copies removed (direct user); Instrument Asset Class, Instrument Type, Business Day Convention, Day Count Convention, Credit Rating Outlook as members | CD-286 |
| 18 | Local 23 to 21, shared 7 to 10; examples; values | Lot Relief Method, Holding View members; Approved Price Basis citation; 3 examples | CD-286, CD-288 |
| 19 | Local 28 to 24, shared 10 to 14; examples; values | Accounting Basis, Plan Version Status, Plan Type, Plan Scenario members; 7 examples | CD-286, CD-288 |
| 20, 21 | Local -1, shared +1; values | Job Level, Metric Direction members | CD-286 |
| 22 | Local 32 to 28, shared 6 to 12; values | Approved Price Basis, Measure Unit, Rate Tenor, Index Level Variant members; 4 citations re-pointed to Instrument Asset Class and Instrument Type | CD-286 |
| 23 | Local 26 to 24, shared +2; values; 1 example | Credit Outlook copy removed; Meeting Channel member (Meeting Format); 1 example | CD-286, CD-288 |
| 24 | Local 23 to 20, shared 8 to 12; values; 3 notes; 1 example | Instrument Asset Class, Lot Relief Method, Proposed Trade Side copies removed; Instrument Type citation; the asset-class usage rule moved into three attribute notes | CD-286, CD-288 |
| 25 | Local 27 to 25, shared +2; examples | Order Side, Transaction Report Status members; 4 examples | CD-286, CD-288 |
| 26 | Local 31 to 29, shared 9 to 13; values | Collateral Type, Trade Report Regime members; Instrument Type and Day Count citations | CD-286 |
| 27 | Local 32 to 30, shared +2; values | Accounting Basis copy removed; Waiver Type member | CD-286 |
| 28 | Local 31 to 28, shared +3; examples; values | Lending Collateral Type, Loan Reporting Regime, Loan Report Status members; 3 examples | CD-286, CD-288 |
| 29 | Local 29 to 27, shared +2; examples; values | Cost Bearer copy removed; Order Settlement Method member; 4 examples | CD-286, CD-288 |
| 30, 32 | Local -1, shared +1; values | Measure Unit / Return Type copies removed | CD-286 |
| 31 | Local 24 to 22, shared 9 to 14; values | Exposure Method, Risk Measure members; 6 citations re-pointed (Measure Unit, Rate Tenor, Holding View) | CD-286 |
| 33 | Local 19 to 17, shared 12 to 16; examples; values | Measurement Basis and Rule Limit Type copies removed; Exposure Method and Risk Measure citations; 2 examples | CD-286, CD-288 |
| 35 | Local -1, shared +1; example | Meeting Format member; 1 example | CD-286, CD-288 |
| 36 | Local 31 to 23, shared 9 to 17; values; 1 example | 7 copies of 01 lists removed (Investor Type to Investor Category); COLL Change Classification member; 1 example | CD-286, CD-288 |
| 37 | Local -1, shared +2; values | Third-Party Risk Domain member; Metric Direction citation | CD-286 |
| 39, 40 | Local -1, shared +1; values | Governing Law, DORA Substitutability members | CD-286 |
| 43, 44 | Shared +1; values | Rate Tenor and Job Level citations | CD-286 |
| 34, 38, 41, 42 | No difference | | |

**Registers**

| Register | Reported difference | CD |
|---|---|---|
| Decisions | CD-286 to CD-290 added | CD-286 to CD-290 |
| Decisions | CD-150 changed (status Applied, applied text) | CD-150 |
| Concept ownership | "Fund Advisory / Management Agreement" (01) changed | See below |
| Term conflicts | 170 changed (resolution, status) | CD-287 |
| Shared code lists | 41 added (57 to 98) | CD-286 |
| Shared code lists | Investor Category changed (direct user 36) | CD-286 |
| Local renames | 10 Plan Type to Financial Plan Type removed (replaced by the shared list) | CD-286 |
| PREFIX_FORMATS | Not compared by the check (informational); 234 rows added | CD-288 |

**Concept ownership row retired.** The 01 row "Fund Advisory / Management Agreement" still said "pending SME decision CD-022", which CD-232 superseded: 35 masters the agreement as Fund Advisory Agreement (ADVA-).
- The row is marked Retired in its note: "superseded by CD-232; 35 masters the advisory agreement". CONCEPT_OWNERSHIP has no status field, so the note carries the status.
- The row is kept for traceability. The capability map's UNCOVERED_CONCEPTS still names it, and its validator requires the row to exist.
- `ownership.py` now skips CONCEPT_OWNERSHIP rows whose note starts with "Retired". The baseline shows no ownership change from this.
- This was requested by the capability coverage stream.

**Data products, logical models and semantic models**

| Layer | Reported difference | CD |
|---|---|---|
| Data products | Register hash changed (DP-083 owning domain 08 to 38); warning cleared for DP-083 | CD-290 |
| Logical models | No difference | |
| Semantic models | No difference. The generated YAML is now deterministic; the check reads models, not out/ | CD-290 |

**Expansion additions:** none. All 44 domains are protected by stage4-v0.1.

Every reported difference traces to an allowed decision. None is unexplained.
