# W0 framing notes: the wealth-manager sibling

**Date:** 2026-10-14. **Branch:** `feature/wealth-manager`, cut from tag `wholesale-v1.0`. **Plan:** `00_Program/Wealth_Manager_Rework_Plan.md` §9 and §10 (Stage W0).

## 1. What W0 did

| Piece | Where | Decision |
|---|---|---|
| Data Domains 45-52 registered (names, L1 codes); DISPOSITION, RETIRED_DOMAINS (empty), WEALTH_DOMAINS | `domains.py` | CW-002, CW-019 |
| Decisions CW-001 to CW-020 merged; MODEL = "wealth"; 15 term-conflict stubs for the §5.3 watchlist | `consolidation/decisions.py` (record: `proposals_wealth_w0.py`) | CW-001 to CW-020 |
| Jurisdiction register (REMOVALS, CHECKLIST) | `consolidation/jurisdiction.py`, CONTRACT.md | CW-003 |
| Baseline checker: replaced and retired domains, wealth-model additions, snapshot meta | `check_baseline.py` | CW-019 |
| Eight areas (Client & Advice first) plus the Foundations band; 07 in DIS and 30 in INV until retired; optional 43, 44, 51 | `capability_map/areas.py` | CW-017, CW-018 |
| Capability map re-cut: 25 L1 areas, 179 L2 capabilities (16 removed, 12 moved, 50 added); eight business lines | `capability_map/content_capabilities.py` (REMOVED_W0, MOVED_W0, L1_CHANGES_W0, CHANGELOG "W0") | CW-004 |
| Function register re-pointed to the new map; FN-60 to FN-78 added; 16 wholesale functions kept with empty capability lists until WP0 | `data_products/framework.py` | CW-002, CW-013, CW-016, CW-018 |
| Explorer: views for CLA, BWO, DIS; INV, IOP, FOP, CORP rewritten; landing, bands and guide copy; 45-52 shown as registered; 07 and 30 in a Retiring band | `build_explorer.py`, `explorer/template.html`, `explorer/views/` | CW-018 |
| Provisional topics for 45-52 | `data_products/framework.py` TOPIC_OF_DOMAIN | until WP0 |
| Docs: README "Wealth-manager sibling", conventions §20, Program_Plan status line | | CW-020 |

## 2. Reconciliation against `wholesale-v1.0`

`python check_baseline.py --check wholesale-v1.0 --allow CW-013,CW-018` after W0:

- Validators: taxonomy, enrichment, dp_model (0 errors), dm_model (0), sm_model (0) all ok.
- Expansion additions: 19 functions FN-60 to FN-78 (each warns "no specified product serves this function" until WP1).
- Wealth-model additions: Data Domains 45-52 registered without modules; decisions CW-001 to CW-020; 15 term conflicts.
- **The one difference:** `functions changed: FN-01 to FN-19, FN-22, FN-25, FN-26, FN-30, FN-31, FN-37`. Every one is the re-pointing of a wholesale function's area (DCL retired) and capability ids (moved or removed in the W0 re-cut), or an empty capability list kept for the wholesale products until WP0. Traced to CW-013 (intermediary channel compressed; FN-02 to FN-08, FN-11, FN-14, FN-18), CW-016 (private markets retired; FN-25, FN-26), CW-018 (areas; FN-01, FN-09, FN-10, FN-12, FN-13, FN-15 to FN-17, FN-19, FN-37) and the capability re-cut under CW-004 (FN-22, FN-30, FN-31).
- Taxonomy content, registers (prefixes, concept owners, shared lists), products, logical models and semantic models: unchanged (0 differences).

Snapshot `wealth-w0-v0.1` taken after this reconciliation; Stage W1 is checked against it.

## 3. Carried into later stages

- WP0: re-cut FUNCTIONS (retire or rename the 16 empty wholesale functions; FN-12, FN-15, FN-16, FN-17 still carry wholesale names; C-14.09 moves to an enterprise function), TOPICS and TOPIC_OF_DOMAIN, RETIRED_PRODUCTS handling in check_baseline, SM-01 to SM-07 retirement.
- W2 (08 brief): whether the records retention schedule (C-12.16, Rule 17a-4 periods) stays in 08 or moves to 21 or 39.
- W4: add 07 and 30 to RETIRED_DOMAINS; the PREFIXES register's wholesale-only prefixes get status "Reserved by sibling" by decision.
- W5: fold the 15 "(wealth model)" term-conflict stubs into the existing entries where the term already exists (Account, Fee, Position, Holding, Order, Model, Plan).
- Brand: `brand/kpmg.css` has seven area colors; the DIS area uses the template's fallback color.
- The shared Business Line list (CD-209, used by 18 Business-Line Detail) is replaced in content at W1b, not at W0.
