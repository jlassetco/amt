# W1 merge notes: anchors of the wealth-manager sibling

**Date:** 2026-10-14. **Branch:** `feature/wealth-manager`. **Plan:** `00_Program/Wealth_Manager_Rework_Plan.md` §10 (Stage W1 Anchors). **Baseline checked against:** `wealth-w0-v0.1`; snapshot `wealth-w1-v0.1` taken at the end of this stage.

## 1. What W1 did

| Domain | Disposition | Result | Decision |
|---|---|---|---|
| 01 Investment Product & Service Offering | adapt | 17 families, 54 objects, 320 attributes (307 wholesale, 42 removed, 55 added); three new families: Advice & Service Offerings, Brokerage Platform Offering, Alternative Investment Access; fee family limited to fund-level terms; 101 jurisdiction removals | CW-901 (amends CW-028, CW-036, CW-037, CW-038) |
| 02 Client & Household | replace | new module, L1 code HH; 10 families, 39 objects, 290 attributes; the client household as party master, investor profile, one identity verification master, beneficial ownership, authority grants, trusted contacts, vulnerability concerns; the wholesale 02 module and folder retired; 58 jurisdiction removals; prefixes VCON- and DTHN- reserved | CW-902, CW-005, CW-021, CW-040 |
| 09 Shared & Enterprise Reference Data | keep (US-only pass) | 44 objects, 212 attributes; UK/EU geography, regulators, markets and authorizations removed; US entity categories and distribution roles; settlement calendar per CD-185; 74 jurisdiction removals; five shared-list re-cuts proposed and applied at merge | CW-909 |
| 15 Account | replace in place | 9 families, 35 objects, 290 attributes; brokerage and advisory account: registration types, features, agreements, program enrollment, RMD, cost-basis election, intraday margin standard (the pattern day trader regime is retired); 24 jurisdiction removals | CW-915 (amends CW-031) |
| 17 Instrument & Issuer Reference | keep (US-only pass, retail additions) | 25 objects, 279 attributes; UCITS, MiFID, PRIIPs and EU listing content removed; listed options, CDs, municipal and municipal fund securities (529 and ABLE), fractional and extended-hours eligibility flags added; 23 jurisdiction removals | CW-917 |

Every domain was drafted by one Opus agent, reviewed by another with fresh context, and fixed by the drafter under program-lead rulings (reviews in `00_Program/Rework/Reviews/`).

## 2. Merge steps

1. The wholesale 02 module and `02_Client_and_Customer/` were removed from the branch (they stay at tag `wholesale-v1.0`); `domains.py` renamed 01 and 02 and gave 02 the code HH (CW-021, CW-040).
2. CW-901, CW-902, CW-909, CW-915 and CW-917, the 02 prefixes and key formats were merged into `decisions.py`; the 280 jurisdiction removals into `jurisdiction.py` (CW-022).
3. Participant balances were ruled to stay mastered in 16, the recordkeeping book of record (`enrich_16.py`, `content_16` wording); 18 now references 15 Program Enrollment (CW-915).
4. `RESCOPE_PENDING` (CW-041): the 79 wholesale consumer products of Waves 1 to 4 and SM-02 to SM-06 are set aside until WP0 and skipped by the validators; SM-01 and SM-07 stay live as the owners of the certified flow, AUM and fee-revenue metrics; a live product's dependency on a pending one is a WP0 warning.
5. The key and link registry was re-cut for 02 and 15 and adapted for 01 and 17; the removed wholesale 02 objects are referenced as ("02", "Party") or ("02", "Contact Point") until W4 restores them in 05 and 12; references into 45-52 sit in `PENDING_REFS`.
6. The live products were re-pointed: distribution foundational (DP-001 to DP-004, DP-007, DP-013, DP-093, DP-094) and enterprise (DP-240, DP-097, DP-098, DP-115, DP-125, DP-130, DP-135 to DP-137, DP-144, DP-156, DP-161, DP-222, DP-225, DP-235, DP-243), with their logical models. Inputs with no successor were dropped with their measures and a "W1" note. DP-001 to DP-003 are cut to party, roles and identifiers until WP0 (CW-013).
7. Shared code lists re-cut (CW-004, CW-039, CW-909): Business Line to the eight wealth lines (codes DB, DA, HA, PF, WR, IA, IC, TR), Regulator, Distribution Market, Geographic Unit Type, Delivery Method, Regulatory Regime, MMF Type, Instrument Type; memberships and the CD-209 local rename adjusted.
8. The semantic layer re-pointed: SM-00 and the live subject-area models; metric references into pending models removed with a WP0 note.

## 3. Reconciliation against `wealth-w0-v0.1`

`python check_baseline.py --check wealth-w0-v0.1 --allow CW-004,CW-021,CW-039,CW-041,CW-901,CW-902,CW-909,CW-915,CW-917` after the merge:

- Validators: taxonomy (44 modules, 0 unresolved), enrichment (44, 0 failed), dp_model (159 live specs + 79 pending, 0 errors, 73 warnings), dm_model (159 + 79 pending, 0 errors, 7 warnings), sm_model (13 live + 5 pending, 0 errors, 82 warnings): all ok.
- Replaced and retired Data Domains (CW-019): 02 and 15 compared by counts only.
- Pending WP0 re-scope (CW-041): 79 products, 79 logical models, SM-02 to SM-06, 39 dependency warnings.
- Wealth-model additions: CW-901, CW-902, CW-909, CW-915, CW-917; the VCON- and DTHN- prefixes and the 02 key formats.
- 37 sections differ, every one a W1 change:
  - 33 Data Domains: 01, 09, 17 (content), 16 and 18 (the participant-balance and enrollment re-points), and 28 domains whose only change is "code list values changed" from the shared-list re-cuts (Business Line, Regulator and the others; CW-004, CW-039, CW-909).
  - Registers: 29 shared code lists changed, 0 added, 0 removed; the local renames (CD-209 superseded).
  - Data products: 23 live products changed by re-pointing (links 20,101 to 19,999; measures 2,679 to 2,667; DQ rules 1,330 to 1,327); three new PII warnings (DP-098, DP-206, DP-222 read Party attributes now noted as PII; the parties are organizations).
  - Logical models: the same products' models; one warning cleared (DP-140).
  - Semantic models: SM-00, SM-01, SM-08, SM-10 to SM-13, SM-15 changed; metrics defined 1,767 to 1,766.
- `Now:      44 domains, 360 families, 1455 objects (313 attribute groups), 11273 attributes, 3600 CDEs, 2148 references, 264 derived, 0 unresolved, 1682 local + 466 shared code list uses, 1886 relationships | 98 shared code lists, 318 decisions, 410 prefixes, 562 concept owners, 185 term conflicts | 2`
- `Baseline: 44 domains, 358 families, 1450 objects (321 attribute groups), 11164 attributes, 3552 CDEs, 2105 references, 268 derived, 0 unresolved, 1682 local + 464 shared code list uses, 1817 relationships | 98 shared code lists, 292 decisions, 395 prefixes, 562 concept owners, 185 term conflicts | 2`

Snapshot `wealth-w1-v0.1` taken after this reconciliation; Stage W1b and W2 are checked against it.

## 4. Rulings taken at W1

- 01's attribute band is widened to 300 to 325: the brief's own arithmetic could not fit 280 to 300 after the three new families.
- Recommended Holding Period, SEDOL, Valoren and WKN leave 01; the N-1A exchange fee and the Rule 205-3 incentive-fee terms stay.
- Participant balances are 16's; 15 holds no balances (CW-007 holds for client holdings in 49).
- Consultant-to-client and provider-to-plan links are carried as 02 Party Relationship types until W4 restores the profile objects.
- Foreign calendars, currencies, FX sources and instruments stay (the investment-universe principle, CW-022); "Other non-US" is a jurisdiction regime for Canadian and Swiss content.

## 5. Carried into later stages

- W2 (08): the records retention schedule (C-12.16); Vulnerability Concern.Escalation Case Reference re-typed to a Reference when 08 exists.
- W3 (29): CIP- identity verification becomes a reference to 02 Identity Verification (CW-025); 49 takes Covered Security Indicator; 50 takes the money-movement references now in PENDING_REFS.
- W4 (05, 12): restore the distributor hierarchy, advisor practice, institutional client and consultant relationship objects and re-point the interim ("02", "Party") references; Distribution Channel re-cut; 07 and 30 retired; DP-243 Consultant Coverage returns.
- WP0: empty RESCOPE_PENDING; re-scope or retire DP-001 to DP-003, DP-015 onward, DP-040, DP-064, DP-065 (lost their purpose), DP-135 and DP-156 (largely EU in scope); re-home the certified families; SM-02 to SM-06 retire; the 39 dependency warnings; pending models that take entities from re-cut foundational models (DP-015, DP-095, DP-096).
- Taxonomy gaps for the gap register: 01 Fee Breakpoint Schedule typed Reference (Fee Tier) with no such object; 02 Specified Adult Status lacks Effective From; 02 Investor Qualification carries the parent key; 01 Platform Product Availability has no ID; no foundational model publishes 01 Service Offering; 02 has no successor for Trading Name, Formation Date, Ownership Percentage, Last Verified Date, LEI Entity Category and Registration Authority Entity ID (DP-240 lost its stale-identifier check); 01 has no successor for the ESG minimum commitments (DP-135).
- Tooling: `dm_model.py --keys <keys_g*>` double-loads the named file and reports its entries as duplicates; `check_enrichment.py` picks a module by directory order.
- Shared Frequency value "Fortnightly" to be relabeled "Biweekly" (steward 09).
- W1b: content examples still using removed shared values: Business Line in 18, 21, 24, 27, 31, 32, 33, 35, 36, 37, 39, 40, 41; Regulator in 11, 25, 26, 27, 37, 38, 40 (file and line in the shared-list agent's report; the W1b editors fix them with their domains). Member values mapped to None in the crosswalk ("Review") are the same items.
- W4/W5 shared-list re-cuts still due under CW-039: Investor Category, Investor Qualification Standard, Vehicle Type (add FEEDER_FUND and TENDER_OFFER_FUND), Audience Restriction, Distribution Channel, Distribution Market (below the two-value floor: retire or convert to US sales regions); delete CRS Entity Classification (no members); the stale Information Classification member ("15", "Confidentiality Classification") and the three stale 02 LOCAL_RENAMES (Hierarchy Type, Investor Type, Registration Status).
- Tooling: `taxonomy_builder.py` does not validate shared-list value maps although consolidation/CONTRACT.md says it does; only the enterprise crosswalk reads them. Add the check at the W5 tooling pass (the shared-list agent's checker in the scratchpad is the model).
