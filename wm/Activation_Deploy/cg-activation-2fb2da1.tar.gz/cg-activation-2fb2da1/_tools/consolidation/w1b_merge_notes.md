# W1b merge notes: the US-only pass on the kept domains

**Date:** 2026-10-14. **Branch:** `feature/wealth-manager`. **Plan:** `00_Program/Wealth_Manager_Rework_Plan.md` §6 and §10 (Stage W1b). **Baseline checked against:** `wealth-w1-v0.1`; snapshot `wealth-w1b-v0.1` taken at the end of this stage.

## 1. What W1b did

Twenty-two kept domains passed through the US-only and perspective pass (CW-003, CW-022), five Opus editors with one reviewer per group and a fix pass under program-lead rulings (reviews in `00_Program/Rework/Reviews/W1b_*.md`). Decisions CW-914 to CW-944; 682 jurisdiction removals (962 in the register with W1). Every module builds with 0 unresolved references.

| Group | Domains | Highlights |
|---|---|---|
| 1 | 14, 19, 21, 22, 23 | DORA and BMR content out of 14, market data subscriber object in; 19 on US GAAP, FOCUS and Form ADV; 21's special-category tier defined for every data subject (CD-344), EU AI Act out, NIST AI RMF in; 22 valuation on Rules 2a-5 and 31a-4; 23 research payments on Section 28(e), FINRA 2241 |
| 2 | 18, 25, 26, 27 | 18 names the three books of record; 25 renamed Portfolio Trading & Execution (CW-010), MiFIR report out, best execution on Release IA-5248 and FINRA 5310; 26 EMIR and SFTR out, settlement penalty kept for the international funds, Reg SHO buy-ins; 27 swing pricing on Rule 22c-1(a)(3), UK distribution and tax regimes out |
| 3 | 28, 31, 33, 35 | 28 renamed Fund Custody & Asset Servicing, the CASS family removed in full (49 masters client-asset custody, CW-007); 31 UCITS VaR and PRIIPs out, Exposure Method on Rule 18f-4 and Section 18 asset coverage; 33 on the 1940 Act, ERISA and IMA tests; 35 UCITS and AIFMD filings out, state notice filings keyed by state |
| 4 | 20, 34, 37, 39 | 20 SM&CR, EU remuneration and UK equality items out, FINRA 1220 role categories; 34 SFDR, PAIs and the UK Stewardship Code out, investor-choice proxy voting options in; 37 DORA and UK operational resilience out, notification regime split from stage, FINRA 4530 cited for what it covers; 39 ICARA, UK filings and SM&CR roles out, FinCEN BOI per the 2026 final rule |
| 5 | 40, 41, 42, 43, 44 | 40 DORA register out, supplier tax form mastered here; 41 Information Security Program (Reg S-P, Reg S-ID, NIST CSF, Reg SCI where applicable); 42 Lobbying Disclosure Act; 43 ICARA and MIFIDPRU out, broker-dealer net capital items in (Rules 15c3-1 and 17a-11, FINRA 4110), reserve computation referenced from 49; 44 OSHA, ADA, ASC 842 |

## 2. Merge steps

1. `domains.py`: 25 and 28 renamed with folder overrides so paths stay (CW-925, CW-928).
2. CW-914 to CW-944 merged into `decisions.py`; the 682 removals into `jurisdiction.py`.
3. Shared code lists re-cut from the 22 files' proposals (DORA lists retired, Accounting Basis, Lot Relief Method, Regulatory Trade Report Regime, Exposure Method, Business Domain labels and the rest; CW-039).
4. Key registry: removed objects and attributes dropped or re-pointed; keys for the added objects.
5. Live products and models re-pointed by two lineage agents; products that lost their purpose stay valid and are marked WP0 re-scope candidates: DP-175 (28 CASS), DP-199 (20 MRT), DP-217 (37 important business services), DP-220 (40 DORA register), with DP-156 from W1.
6. Semantic layer re-pointed.
7. Gap register entries that named removed objects were trimmed with a note.

## 3. Reconciliation against `wealth-w1-v0.1`

`python check_baseline.py --check wealth-w1-v0.1 --allow CW-914,CW-918,CW-919,CW-920,CW-921,CW-922,CW-923,CW-925,CW-926,CW-927,CW-928,CW-931,CW-933,CW-934,CW-935,CW-937,CW-939,CW-940,CW-941,CW-942,CW-943,CW-944,CW-039,CW-041` after the merge:

- Validators: taxonomy (44 modules, 0 unresolved), enrichment (44, 0 failed), dp_model (159 live + 79 pending, 0 errors, 75 warnings), dm_model (159 + 79 pending, 0 errors, 6 warnings), sm_model (13 live + 5 pending, 0 errors, 82 warnings): all ok.
- 32 sections differ, every one a W1b change: 28 Data Domains (the 22 passed domains, plus 01, 02, 09, 10, 15 and 24 whose only change is a shared-list value map or example touched by the re-cuts); registers (shared code lists: Tax Form Type added, the two DORA lists removed, 13 changed); data products (measures 2,667 to 2,627; DQ rules 1,327 to 1,317; links 19,999 to 19,708; the re-pointed live products and the renamed DP-156, DP-175, DP-199, DP-217, DP-220); logical models and the semantic layer (tables 1,151 to 1,136; metrics defined 1,766 to 1,733).
- Two new warnings on DP-156 are explained in its notes (its owning domain 31 no longer holds a share-class indicator; only share class return rows are read).
- `Now:      44 domains, 358 families, 1437 objects (313 attribute groups), 11058 attributes, 3546 CDEs, 2112 references, 249 derived, 0 unresolved, 1651 local + 460 shared code list uses, 1866 relationships | 97 shared code lists, 340 decisions, 410 prefixes, 562 concept owners, 185 term conflicts | 238 data products, 2627 measure`
- `Baseline: 44 domains, 360 families, 1455 objects (313 attribute groups), 11273 attributes, 3600 CDEs, 2148 references, 264 derived, 0 unresolved, 1682 local + 466 shared code list uses, 1886 relationships | 98 shared code lists, 318 decisions, 410 prefixes, 562 concept owners, 185 term conflicts | 238 data products, 2667 measure`

Snapshot `wealth-w1b-v0.1` taken after this reconciliation; Stage W2 is checked against it.

## 4. Rulings taken at W1b

- Investment-universe principle applied consistently: foreign venues, CSDs, sub-custodians, instruments, calendars, currencies, FX sources and index methodologies stay; EU/UK regulation, reporting regimes, distribution content and the firm's own EU/UK entities go.
- 26 Settlement Penalty stays (the object carries the US TMPG fails charge and EU CSD penalties reach the international funds); sources relabeled as foreign-market rules.
- 37 Critical or Important Function stays, re-sourced to the interagency third-party guidance and SR 20-24; 34 Signatory Status goes.
- Accounts managed inside a third-party sponsor's wrap or model program are the intermediary channel; institutional separate accounts are the firm's own mandates.
- 40 masters the supplier's tax form on file; 02 holds no form type and 15 covers accounts.
- 43 holds the net capital early-warning level once, as the higher of the two tests; aggregate debit items are the 49 copy.
- Business Line examples use the two-letter codes everywhere; local copies carry the eight codes only.
- "Other non-US" is the regime for Canadian, Swiss and other non-US removals.

## 5. Carried into later stages

- W2 (08): ownership of state notice filings (35 or 08); Form U4/U5 references from 20; 37's notification lists as shared candidates for 41 and 38.
- W3 (24): Decision Algorithm Code lost its 37 source; 29's CIP- to 02 Identity Verification (CW-025).
- W4: references to 30, 05, 12, 07 and 13 left in place and listed in each proposals NOTES; Distribution Market below the two-value floor; W4 retirement candidates (carried interest values in 20, insurance-dedicated residues in 27, 39, 43 seed).
- W5: Output VAT Amount rename; 34 family and 37 group rename candidates; Exposure Method and other single-value lists; the W4/W5 shared-list re-cuts from the W1 notes.
- WP0: re-scope or retire DP-156, DP-175, DP-199, DP-217, DP-220 and the products whose READERS lists name text-only mentions; the 39 dependency warnings.
- Unverified items are marked "confirm" in each Source_Notes (FINRA notices and rule paragraphs, eCFR paths, Rule 10c-1a status after the Fifth Circuit remand, the FinCEN BOI final rule citation, SR 26-2 as the current model risk guidance).
- Shared-list follow-ups from the W1b merge: 09's local Business Domain list still carries the wholesale 01 and 02 labels and stops at 14 (W5, with the shared Business Domain list now extended to 52); 10 Accounting Framework's EU/UK values map to None until W4; Business Line examples in 24, 32 and 36 and Regulator examples in 38 (adapted at W3 and W4); the DQ rule in specs_e4_risk_audit_third_party.py line 982 that cites the retired DORA ICT Service Type codes; ESG_MODERN_SLAVERY in Third-Party Risk Domain for 37 to judge; COLL Change Classification retires with 36 at W4; Measurement Basis PCT_OF_CAPITAL decided with 30 at W4; the Tax Form Type shared list (steward 15, members 15 and 40) was created at this merge.
