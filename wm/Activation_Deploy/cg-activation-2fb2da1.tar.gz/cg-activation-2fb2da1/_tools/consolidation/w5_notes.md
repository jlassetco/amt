# W5 and WP0 notes: consolidation, publication and product framing

**Date:** 2026-10-16. **Branch:** `feature/wealth-manager`. **Plan:** `00_Program/Wealth_Manager_Rework_Plan.md` §8, §9, §10 (Stages W5 Consolidate and publish, WP0 Product framing) and §11 (quality bar). **Baseline checked against:** `wealth-w4-v0.1`; snapshot `wealth-taxonomy-v0.1` taken at the end of this stage.

## 1. What W5 did

| Agent | Scope | Result |
|---|---|---|
| Registers | `decisions.py`, `shared_code_lists.py`, `jurisdiction.py` | 241 prefixes moved to Registered with formats (446 Registered, 9 Proposed, 37 Retired (sibling)); 27 composite-key rows; 24 term conflicts resolved (193 Resolved, 44 SME); shared lists 91 (Data Granularity folded, Net Worth Band created, steward moves Audience Restriction to 04 and Screening Result to 38, Forced Labor / Human Rights replaces the UK Modern Slavery label); 135 concept rows added and the referencing domains of 224 rows rebuilt from a content scan (850 rows); 103 empty jurisdiction notes filled; CW-173 to CW-177 |
| Content sweep | all content and enrichment modules | 228 of 312 ownership overrides removed as redundant under CW-172; 58 wholesale names out of prose; 12 Portfolio Holdings renames; 02 Net Worth Band split at USD 25m; 01 Model Sponsor typed to 05; CW-165 insurance residues out of 17, 31, 33, 35; 02 Specified Adult Effective From and 01 Platform Availability ID (PLAVL-); quality-bar fixes (books named, rules cited, PII tiers, CD-344); 370 edits logged in `proposals_w5_content.py` |
| Tooling and explorer | builders, validators, views, capability map | shared-list value maps validated in the builder (CONTRACT.md updated); `dm_model --keys` loads each file once incl. `keys_w_*`; deterministic enrichment module pick; `dimension_type` in the semantic check; capability coverage test (179 L2s, each with a mastering domain and a live function); eight area views, core entities and the guide chain on the wealth model; retired functions and products honored by every builder and reported by `check_baseline`; wealth subtitles; TOPICS re-cut (T10 brokerage, T19 advice) |
| Walkthrough decks | `build_walkthroughs.py` | 50 decks regenerated from the modules (15 to 18 slides each); ten wholesale-era decks removed |
| Lineage | specs, models, keys, semantic | readers of the sweep's removals and renames re-pointed; validators at 0 errors |

## 2. What WP0 did

- Functions (CW-200): FN-01 to FN-11, FN-13, FN-14, FN-18, FN-25, FN-26 retired with successors; FN-12, FN-15, FN-16, FN-17, FN-19 re-cut; FN-79 Business Line Leadership & Strategy added; 90 live products re-pointed to live functions.
- Waves and ids (CW-201): WP1F foundational, WP1C per area, WP2 models; id blocks DP-300 to DP-639 by brief; `RETIRED_PRODUCTS` with successors.
- Dispositions: the 79 pending products of CW-041 ruled once each: 12 re-scoped in place (live dependents), 50 superseded by new ids, 17 retired; the cross-area and foundational products re-scoped (DP-001 Intermediary Partner Master, DP-003 and DP-243 to 12, DP-004 Product, Offering & Share Class Reference, DP-006 Client Flow Transactions, DP-007 Client Asset Positions, DP-008 Client Assets & Net New Assets as the sole source of the certified client-asset numbers, DP-012 Client Fee Revenue, DP-093 the brokerage and advisory Account Master, DP-240 Client, Household & Party Master, DP-241 Firm AUM & Client Assets Reconciliation); DP-002 retired into DP-001, DP-244 into DP-498, DP-156 and DP-175 retired, the seven private-markets products retired with named residual homes.
- Candidates: seven briefs (framing plus CLA-A, CLA-B, BWO, DIS+FDN, INV+IOP, FOP+CORP) in `00_Program/Rework/Product_Briefs/`; 188 new products registered in progress (17 foundational: DP-300 to DP-307, DP-381, DP-382, DP-430 to DP-432, DP-480, DP-481, DP-530, DP-580; 171 consumer by area); `candidate_coverage.py --wealth` at 0 errors with every object carrying CDEs read by a live product or a candidate.
- Certified families (CW-011): reserved in `register.py` (SM-20 Client Assets & Flows from DP-008; Firm AUM in SM-11 from DP-241; Personal Rate of Return in SM-08 from DP-145; client fee revenue in SM-28 from DP-012; SM-29 Retail Conduct & Supervision); SM-01 and SM-07 stay live until SM-20 and SM-28 exist at WP2.
- Decisions CW-200 to CW-266 merged (Proposed); the acceptance questions of §8.5 all map to a metric, an owning product and the mastering domains (`WP0_Framing.md` §8, `WP0_Integration_Notes.md`).

## 3. Reconciliation against `wealth-w4-v0.1`

`python check_baseline.py --check wealth-w4-v0.1 --allow CW-173,...,CW-266,CW-172,CW-165,CW-039,CW-041,CW-011,CW-142`:

- Validators: taxonomy (50 modules, 0 unresolved; shared lists 91 checked, 0 errors), enrichment (50, 0 failed), dp_model (148 live + 12 pending + 78 retired, 0 errors, 73 warnings), dm_model (159 + 79 pending, 0 errors, 16 warnings), sm_model (12 + 6 pending, 0 errors, 103 warnings): all ok.
- 35 sections differ, every one a W5 or WP0 change: the content sweep (prose, overrides, renames, CW-165), the registers (decisions 483 to 546; prefixes 502 to 503; concept owners 712 to 850), the products (functions re-pointed; retired products; the in-progress candidates), models and semantic rows.
- `Now:      50 domains, 406 families, 1583 objects (303 attribute groups), 13009 attributes, 4268 CDEs, 2574 references, 292 derived, 0 unresolved, 1816 local + 505 shared code list uses, 2459 relationships | 91 shared code lists, 546 decisions, 503 prefixes, 850 concept owners, 237 term conflicts | 238 data products, 2546 measures`
- `Baseline: 50 domains, 406 families, 1583 objects (303 attribute groups), 13009 attributes, 4266 CDEs, 2575 references, 292 derived, 0 unresolved, 1818 local + 504 shared code list uses, 2459 relationships | 91 shared code lists, 483 decisions, 502 prefixes, 712 concept owners, 237 term conflicts | 238 data products, 2546 measures`

Snapshot `wealth-taxonomy-v0.1` taken after this reconciliation; WP1 is checked against it.

## 4. Rulings taken at W5 and WP0

- One disposition rule for every pending product: re-scoped in place only when a live product depends on its id, otherwise superseded by a new id and retired.
- Certified numbers are defined once and consumed everywhere: Client Assets, Net New Assets, Advised Assets and the household, client and account counts in DP-008; Firm AUM and its slices in DP-241 (the managed-account slice sourced from DP-345); Personal Rate of Return in DP-145; client fee revenue in DP-012.
- Special-category client facts reach other products only through the DP-322 restricted view (CW-213).
- Product count: the briefs registered 348 products against the plan's 230 to 250. A rationalization pass before WP1 specifies the 17 foundational, the 30 re-scoped and about 90 consumer products chosen by the acceptance questions, the §8.3 examples, the certified-metric chains and the regulatory controls; the rest move to a registered Backlog wave.
- DP-075 stays live until DP-101 absorbs its lineage at WP1; DP-044 is re-scoped in place (five live dependents) with DP-519's scope; DP-078 stays as DP-228's upstream; the household dimension stays inside DP-240.
- Retired products keep their `RESCOPE_PENDING` key as a hold-back until WP1 deletes their specs and models; builders show `RESCOPE_OPEN` (12).

## 5. Carried into later stages

- WP1 first re-points: the live products that depend on retired ones (DP-003, DP-006, DP-007, DP-011, DP-093 on DP-002; DP-109 on DP-040; 19 products in all); the Measure Value Dimension Grain readers; SM-00's distributor dimensions role-playing Party until DP-001 to DP-003 are re-specified; SM-01 and SM-08 register rows naming FN-01 and FN-08 (successors FN-79, FN-77); SM-00, SM-10, SM-11 and SM-14 publishing DP-002, DP-156, DP-175, DP-244; the logical models of the 11 retired non-pending products (built until their entities are no longer conformed); the gap register's product links; the pending semantic rows SM-02 to SM-06 and SM-13 (retire at WP2 integration).
- WP1 scope notes: DP-145 publishes Personal Rate of Return; DP-004 reads Offering Fee Schedule Link and Model Portfolio; the DP-333/DP-392 funnel hand-off; the eight products that briefs mark as tailoring levers (trust DP-307 and DP-351 to DP-355, DP-450, DP-451, DP-468, DP-512, DP-541, DP-135, DP-520) specified last.
- W5 leftovers: 44 SME term conflicts resting on Proposed CD- decisions (some text still names 07 and 30); C-08.06 CIT Plan Participation has no object in 05 or 16; the 39-to-05 contract flow direction; quality-bar outliers (CDE share just over 35 percent in 01, 46, 39, 27; 51 at 143 attributes; 01 at 331 and 21 at 301); single-value lists kept with reasons (01 Pricing Basis, 28 Loan Reporting Regime, 49 Regulatory Trade Report Regime); the Source_Notes of the kept domains lack a 'why this domain exists' section and lever defaults (the decks fall back to module text).
- Process notes: the session limit interrupted all eleven W5 and WP0 agents once; each resumed from its transcript. python-pptx 1.0.2 was installed in the user site of `/usr/bin/python3` for the deck generator. The CLA-B brief agent ran one read-only `git log` against the rule.
