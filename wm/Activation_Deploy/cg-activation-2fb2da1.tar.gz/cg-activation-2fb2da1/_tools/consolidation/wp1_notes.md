# WP1 notes: the product layer of the wealth-manager sibling

**Date:** 2026-10-17. **Branch:** `feature/wealth-manager`. **Plan:** `00_Program/Wealth_Manager_Rework_Plan.md` §8 and §10 (Stage WP1 Products). **Method:** `00_Program/Rework/Product_Briefs/WP1_Method.md` and `WP1_Scope.md`; agent instructions in `00_Program/Rework/Agent_Instructions/spec_common_wealth.md`, `spec_reviewer_wealth.md` and `spec_lineage_wealth.md`. **Baseline checked against:** `wealth-taxonomy-v0.1`; snapshot `wealth-wp1-v0.1` taken at the end of this stage.

## 1. What WP1 did

WP1 specified the 140 products of the WP1 scope (17 foundational, 29 re-scoped in place, 94 consumer-aligned) in eleven new spec modules, deleted the old entries of every re-specified or retired product, re-pointed the live wholesale-era products, logical models and semantic models to the new foundations, and left every validator at 0 errors. Every module was drafted by one Opus agent, reviewed by a second with fresh context, and fixed by the drafter under program-lead rulings (reviews in `00_Program/Rework/Reviews/specs_w1f_*_review.md` and `specs_w1c_*_review.md`).

| Wave | Module | Products | Highlights |
|---|---|---|---|
| WP1F client | `specs_w1f_client.py` | DP-240, DP-093, DP-004, DP-381, DP-382 | the client household and account masters, the offering and share-class record, contact and delivery facts |
| WP1F advice | `specs_w1f_advice.py` | DP-303 to DP-307, DP-530 | advice engagements, plans, recommendations, managed-account runs and the capital market assumption sets |
| WP1F books | `specs_w1f_books.py` | DP-300, DP-301, DP-302, DP-430, DP-431, DP-432, DP-580 | the three books of record (18 Portfolio Holding, 49 Client Holding, 06 Fund Shareholder Position as a view), orders, cash and sweep, the 16 participant book, the share register |
| WP1F channels | `specs_w1f_channels.py` | DP-001, DP-003, DP-005, DP-480, DP-481 | advisor and intermediary masters, institutional profiles, industry and competitor reference |
| WP1F certified | `specs_w1f_certified.py` | DP-006, DP-007, DP-008, DP-012, DP-145, DP-165, DP-241 | flows, asset summaries, the certified Client Assets family (CW-011), client fee revenue, Personal Return Value, portfolio performance, Firm AUM and its slices |
| WP1C CLA-A | `specs_w1c_cla_a.py` | DP-320 to DP-355 (21), DP-077, DP-080 | advice delivery, suitability and Reg BI evidence, managed accounts, trust, privacy |
| WP1C CLA-B | `specs_w1c_cla_b.py` | DP-383 to DP-418 (22), DP-036, DP-038, DP-039, DP-069, DP-078, DP-079, DP-085, DP-109 | offering governance, conduct and supervision, marketing and engagement, registration, complaints |
| WP1C BWO | `specs_w1c_bwo.py` | DP-435 to DP-467 (15), DP-095, DP-096 | brokerage execution, transfers, corporate actions, cash and sweep, the customer reserve, money movement, workplace plans |
| WP1C DIS+FDN | `specs_w1c_dis.py`, `specs_w1c_inv_iop_fdn.py` | DP-486 to DP-518 (21+3), DP-243, DP-044, DP-130 | channel economics, attribution and cohorts, institutional relationships, pricing, the data-governance register, third-party data |
| WP1C INV+IOP | `specs_w1c_inv_iop_fdn.py` | DP-531 to DP-544 (7) | capital market assumptions, model lineups, statements and personal returns, oversight |
| WP1C FOP+CORP | `specs_w1c_fop_corp.py` | DP-583 to DP-600 (7), DP-083, DP-199, DP-217, DP-228 | shareholder register holds, intermediary oversight, fund fees, distributions, board reporting, revenue, reserve funding, compensation, resilience, AML |

Decisions CW-200 to CW-266 (WP0) are applied; CW-227 was amended at the fix passes (Net New Assets by campaign is read from DP-008's Campaign rows). The 78 backlog candidates keep their merge targets in `framework.py` (`WAVE_BACKLOG_MERGES`; DP-519 merged into DP-044 at this stage).

## 2. Lineage and tooling

- Old spec entries deleted for the 30 re-specified products and the 11 retired products whose specs could be removed once `dp_model.py` skipped `RETIRED_PRODUCTS` in the no-spec check (DP-002, DP-116, DP-117, DP-136 to DP-139, DP-156, DP-160, DP-175, DP-244). The 66 wholesale consumer products retired at WP0 stay held back in `RESCOPE_PENDING` with their specs and models until WP2 retires SM-01 and SM-07, which still publish seven of them.
- 40 live products re-pointed: the certified names (Ending, Beginning and Average Client Assets, Client Market Movement and Other, Client Organic Growth Rate), Firm AUM from DP-241, DP-183, DP-242 and DP-196 on their successors; measures moved to their new owners (DP-224 to DP-083, DP-170 to DP-586, DP-246 and DP-248 to DP-509 in the backlog).
- Logical models and keys re-cut for the 13 foundations and the 17 re-scoped products; Party conformed from DP-240 and DP-001, DP-003 as the institutional profile, DP-241 Fact Client Assets; retired models deleted.
- Semantic layer: CERTIFIED re-pointed to DP-008 and DP-241; SM-00, SM-01, SM-07, SM-08, SM-10 to SM-12, SM-14 to SM-16 re-cut; the pending SM-03, SM-04 and SM-06 trimmed; new WP1 measures held in each model's `excluded` list until WP2 (`sm_model.py` lets Wave WP1 and `WP1_RESCOPED` products await their WP2 model, SM-20 to SM-29).
- `framework.py`: `WP1_RESCOPE_SPECIFIED` lifts the re-specified ids from the hold-backs (`RESCOPE_OPEN` is empty); register rows re-cut for DP-044 (renamed Third-Party Data Entitlements, Usage & Cost), DP-080, DP-083, DP-093, DP-095, DP-096, DP-130 (renamed Institutional Separate Account Tax Management), DP-165, DP-345, DP-490.
- Foundation additions for the consumer waves: DP-012 publishes Client Fee Revenue, DP-004 the 01 fee and cost disclosure groups, DP-240 the trusted-contact account scope.
- Gap register: 144 product links re-pointed to live successors; GAP-16-002 (16 Distribution Type "Disability" reveals a health condition and is not marked special category).

## 3. Reconciliation against `wealth-taxonomy-v0.1`

`python check_baseline.py --check wealth-taxonomy-v0.1 --allow CW-200,...,CW-266,CW-011,CW-041` after the close (the full list is the 58 WP0 and WP1 decisions of `proposals_wp0_framing.py` and the six `proposals_wdp_*.py` files):

- Validators: taxonomy (50 modules, 0 unresolved), enrichment (50, 0 failed), dp_model (271 live + 66 retired held back, 0 errors, 47 warnings), dm_model (161 models + 66 pending, 0 errors, 10 warnings), sm_model (12 live + 6 pending, 0 errors, 174 warnings), candidate_coverage --wealth --wp1 (0 errors, 0 CDE objects unread): all ok.
- Expansion additions: 111 data products added (the WP1F and WP1C waves and DP-044 back from retired); 24 justified pii='N' warnings on additions; 89 "awaits its WP2 semantic model" warnings.
- Four sections differ, every one a WP1 change: registers (CW-227 amended); data products (specified 238 to 337; measures 2,546 to 4,354; DQ rules 1,298 to 1,931; input objects 3,495 to 5,008; attribute links 19,016 to 27,520; upstream edges 1,557 to 2,359; the re-pointed foundations and live products); logical data models (the re-cut foundations, re-scopes and re-pointed models; 66 pending held back); semantic models (tables 1,121 to 1,107; metrics defined 1,705 to 1,668; SM-00, SM-01, SM-07, SM-08, SM-10 to SM-12, SM-14 to SM-16 changed; the retired-function warnings on SM-01 and SM-08 cleared).
- The taxonomy itself is unchanged: `Now:      50 domains, 406 families, 1583 objects (303 attribute groups), 13009 attributes, 4268 CDEs, 2574 references, 292 derived, 0 unresolved, 1816 local + 505 shared code list uses, 2459 relationships | 91 shared code lists, 546 decisions, 503 prefixes, 850 concept owners, 237 term conflicts` equals the baseline line.
- Generated outputs rebuilt: the 50 domain workbooks, Taxonomy Index, Enterprise Data Taxonomy, Data Product Catalog (271 specified, 77 retired, 78 WP1 backlog), Data Product Logical Models (161 models), Gap Register (480 issues), Business Capability Map, Taxonomy Explorer, and the wealth foundational review pack (`00_Program/Rework/Product_Briefs/Wealth_Foundational_Review_Pack.md`).

Snapshot `wealth-wp1-v0.1` taken after this reconciliation; WP2 is checked against it.

## 4. Rulings taken at WP1

- Certified numbers defined once and read everywhere: no consumer product re-selects DP-006 rows for Net New Assets (DP-491 and DP-492 roll up DP-008's attribution rows), restates the Client Assets summing rule (DP-320 and DP-496 are decompositions tying to DP-008's rows), or recomputes Personal Return Value, Firm AUM or the reserve; DP-241's managed-account slice is certified from DP-345's operational measure "Managed Account Assets (Discretionary and Non-Discretionary)", built on the DP-007 client cash rule.
- One owner per control fact: DP-403 owns the Rule 2165 hold clock (Active and Extended holds; extensions from the 08 case actions); DP-322 publishes the Protection Flag and the hold, restriction and case rows only; DP-456 and DP-583 read DP-403; DP-393 owns the hand-off-to-engagement rate; DP-324 owns suppression coverage; DP-334 and DP-335 own the Reg BI and PTE 2020-02 evidence flags (DP-404 and DP-467 read them); DP-530 owns the capital market assumption staleness control; DP-145 owns the statement value tie-out and suppression controls.
- Special category (CW-213): Financial Exploitation and Disability values are extraction filters that are never published outside a restricted view; complementary suppression applies wherever a non-special count could be subtracted from a total (DP-456, DP-466, DP-095); the SAR-decision value never leaves DP-460; DP-039 is a restricted view for registration and licensing compliance and may read 08 Disclosure Event Type; DP-503, DP-498 and DP-499 release member-level, household and advisor economics only through views named in DP-518.
- Minimum cell 10 everywhere; 3 to 6 DQ rules per product, each testable on the product's inputs and cited by rule number.
- Edges: foundations never list consumers; one direction per pair (DP-390 to DP-198, DP-492 to DP-320 and DP-410, DP-498 to DP-392, DP-410 and DP-518, DP-538 to DP-183); DP-583 and DP-600 are readers of the Q7 and Q6 answering products, not feeders; DP-497 is not a Q8 feeder (DP-346 reads DP-305 directly).
- Direct reads accepted where no foundation publishes the object (19 Receivable Item, 08 Supervisory Review): WP2 foundation candidates, noted in each product.
- Register rows: the producing function owns the product (DP-490 keeps FN-77 with FN-79 supporting; DP-080 moves to FN-44 Corporate Compliance as the privacy office).
- Reference defaults recorded as tailoring levers: RMD applicable age on the SECURE 2.0 schedule (73 for births 1951 to 1959, 75 after); delegated trust distribution limits; drift cadence; trusted-contact reconfirmation; all rollovers treated as fiduciary advice under PTE 2020-02; in-house fee billing re-performed for every account.

## 5. Carried into WP2 and later

- WP2 models and semantic layer: logical models for the 94 consumer and 17 foundational products (the foundations and re-scopes have models; the new consumer products do not); SM-20 to SM-29 take the measures now in the `excluded` lists (SM-00 61, SM-01 30, SM-07 12, SM-14 17, SM-08 8, SM-11 7, SM-15 3, SM-16 1, plus the DP-498 and DP-012 additions); SM-01 and SM-07 retire with their seven retired products; then `RESCOPE_PENDING` empties and the 66 held-back specs and models are deleted.
- WP2 foundation candidates: 19 Receivable Item, 08 Supervisory Review, 47 Fee Invoice readers (DP-243 reads DP-350), the 06 Attribution Record's missing Measure and Snapshot references, a Household and a Service Tier Dimension Type on DP-008.
- Taxonomy gaps recorded in the product notes ("Taxonomy gap:" lines; to the gap register at WP2): 02 Investor Profile effective dates; 02 attribute groups without a party key; 13 K-1 and trustee report types and a mail-hold re-verification date; 51 Estate Settlement Case opened date; 50 RMD reason code; 04 Lead Conversion link to an engagement; a Rule 3a-4 notice record; 46 harvest execution link; a sanctions or PEP match object; 02 Consumer Privacy Request outcomes; 43 Special Reserve bank account purpose; 49 Reserve Computation version; 21 Data Contract view name; a fund authorization type in 38; the omnibus-account-to-intermediary link; 16 Disability as special category (GAP-16-002).
- Unverified citations marked "confirm" in the specs: PTE 2020-02 Section IV after the amendments; SEC Rule 17a-13 independence condition; Rule 17a-4 in DP-044; the USD 300 limit in DP-038; the CASH_AND_SWEEP dimension key.
- The 10 `dm_model` registry fk-target warnings (DP-005, DP-075, DP-129, DP-012, DP-198, DP-140, DP-234) and the 47 `dp_model` warnings (justified pii='N' notes) stand.
- Leftovers from W5 (`w5_notes.md` §5) still open: the SME term conflicts on Proposed CD- decisions; C-08.06 CIT Plan Participation without an object.
