# WP2 notes: logical models and the semantic layer of the wealth-manager sibling

**Date:** 2026-10-17. **Branch:** `feature/wealth-manager`. **Plan:** `00_Program/Wealth_Manager_Rework_Plan.md` §8.4 and §10 (Stage WP2 Models and semantic layer). **Instructions:** `00_Program/Rework/Agent_Instructions/models_common.md`, `keys_common.md`, `semantic_common.md`. **Decisions:** CW-270 to CW-274 (`consolidation/proposals_wp2_close.py`). **Baseline checked against:** `wealth-wp1-v0.1`; snapshot `wealth-v1.0` taken at the end of this stage.

## 1. What WP2 did

| Step | Agents | Result |
|---|---|---|
| Key registry | 1 | The ten fk-target warnings of the carried models cleared (DP-005, DP-012, DP-075 conform their mastering entities; DP-129, DP-140, DP-198, DP-234 derived links); Cost Pool contributing cost centers re-pointed to 19 Chart Segment Value; Recipient Delivery Record re-keyed. The wealth domains were keyed at W5 (`keys_w_*.py`); nothing further was needed. |
| Foundational models | 3 | 17 ER models in `models_w_books.py` (DP-300, DP-301, DP-302, DP-430, DP-431, DP-432, DP-580), `models_w_advice.py` (DP-303 to DP-307, DP-530) and `models_w_client_channels.py` (DP-381, DP-382, DP-480, DP-481); orders and hand-offs link to the advice entities; DP-382 conforms the trade confirmation from DP-301. |
| Consumer models | 6 | 94 star models in `models_wc_cla_a.py` (21), `models_wc_cla_b.py` (22), `models_wc_bwo.py` (15), `models_wc_dis.py` (18), `models_wc_inv_iop_fdn.py` (10), `models_wc_fop_corp.py` (7); cross-consumer conformance where the spec lists the product upstream (DP-600 from DP-445; DP-334 and DP-335 from DP-398; DP-403 from DP-322; DP-456 from DP-403). Every live product has a model: 271 models, 0 errors. |
| Semantic register | lead | SM-20 to SM-29 registered on the live ids, SM-30 Offering, Product Range & Market and SM-31 Manager Oversight & Due Diligence added, carried models extended, DP-093 into SM-00, the certified families moved to SM-20 and SM-28, Personal Rate of Return and the Firm AUM slices certified (CW-270). |
| Semantic models | 12 | Twelve new definitions (`sm_20_*` to `sm_31_*`), SM-00 extended with the wealth dimensions (Household, Client Account, Advisor, Offering and Program, Channel) and 80 held measures resolved, the nine carried models re-pointed from SM-01 and SM-07 to SM-20 and SM-28 with their WP1 products published. 22 live models, 0 errors, 0 warnings. |
| Retirement | 1 | SM-01 to SM-07 and SM-13 retired; the 66 retired consumer products' specs and models deleted; `RESCOPE_PENDING` empty (CW-271). |
| Documents | 1 | `00_Program/Data_Products_Approach.md` rewritten for the wealth manager; the wealth review pack rebuilt. |

## 2. The conformed wealth dimensions (CW-272)

| Dimension | Source entity | Note |
|---|---|---|
| Household | DP-240 Party (Party Type Household) with the Household Membership bridge | many-to-many, effective dated; never a column on the account |
| Client Account | DP-093 Account, with Account Party Role and Program Enrollment | DP-093 joined SM-00 at WP2 |
| Advisor | DP-009 Employee (holds the 03 Advisor) with Coverage Assignment | DP-001 Financial Professional is the intermediary rep |
| Offering and Program | DP-004 Service Offering, Service Tier, Model Portfolio | the program is read through DP-304 or DP-093 Program Enrollment |
| Channel | DP-008 Account Channel Assignment, named through DP-013 Code Value | no foundational model publishes a Channel entity; Channel stays the Dimension Type of the certified rows |
| Program Bank | DP-431 (SM-24) | model-local until DP-431 joins SM-00 |
| Manager | DP-306 (SM-31) | model-local until DP-306 joins SM-00 |

## 3. Reconciliation against `wealth-wp1-v0.1`

`python check_baseline.py --check wealth-wp1-v0.1 --allow CW-270,CW-271,CW-272,CW-273,CW-274,CW-041,CW-207,CW-209,CW-011` after the close:

- Validators: taxonomy (50 modules, 0 unresolved), enrichment (50, 0 failed), dp_model (271 live specs, 0 errors, 47 warnings), dm_model (271 models, 0 errors, 1 warning), sm_model (22 models, 0 errors, 0 warnings), candidate_coverage --wealth --wp1 (0 errors, 0 CDE objects unread): all ok.
- Expansion additions: 110 logical models (the WP1 products) and 12 semantic models (SM-20 to SM-31); wealth-model additions: decisions CW-270 to CW-274.
- Three sections differ, every one a WP2 change: data products (specified 337 to 271 as the 66 retired specs left; measures 4,354 to 3,664; DQ rules 1,931 to 1,559; the specs whose notes record the retirement of their SM-0x readers); logical data models (the retired models removed; the carried models whose keys were cleared); semantic models (SM-01 and SM-07 removed, SM-02 to SM-06 and SM-13 cleared from the pending register, SM-00 and the nine carried models re-pointed; 83 "awaits its WP2 semantic model" warnings cleared).
- The taxonomy itself is unchanged (50 domains, 406 families, 1,583 objects, 13,009 attributes, 4,268 CDEs, 0 unresolved); decisions 546 to 551.
- The semantic layer after WP2: 22 live models, 1,504 tables, 2,630 metrics defined and 174 references, 44 certified metrics, 221 of 271 products bound (the 50 others deliver to systems and processes, or list no BI delivery); the twelve wealth models hold 655 tables and 1,293 metrics.
- Generated outputs rebuilt: the 50 domain workbooks, Taxonomy Index, Enterprise Data Taxonomy, Data Product Catalog, Data Product Logical Models (271 models), Gap Register, Business Capability Map, Taxonomy Explorer, the wealth foundational review pack and the semantic outputs (`semantic_model/out/`).

Snapshot `wealth-v1.0` taken after this reconciliation: the wealth-manager reference model at the end of its first full build, with the wholesale sibling intact at `wholesale-v1.0`.

## 4. Rulings taken at WP2

- One semantic home per product; products whose spec lists no BI delivery are bound to no model and reach the layer through the products that read them (CW-270).
- Certified metrics defined once and referenced everywhere: SM-20 owns the client-asset and flow family (15 metrics), SM-28 the client fee revenue family (4), SM-08 Personal Rate of Return (pinned to one return method per query), SM-11 Firm AUM and its three slices; no metric adds Client Assets and Firm AUM.
- One name, one definition across models (CW-273): the hand-off rate and triggered hand-offs are DP-393's, households without a primary advisor DP-320's, cost to serve DP-498's, funded households acquired and campaign spend SM-25's, own-fund client holdings SM-20's, the evidence flags SM-22's.
- Special-category data in the semantic layer: restricted tables and roles (DP-322, DP-352, DP-355, DP-403, DP-039, DP-535 background checks), complementary suppression stated wherever a non-special count sits beside a total, minimum cell 10, the Rule 2165 clock as aggregates only.
- Books of record in the layer: a 49 table is never joined to an 18 or 06 table; the 06 positions of firm client accounts are filtered out wherever 49 is also published (CW-007).
- Consumer models may conform entities from another consumer product when the spec lists it upstream; a dimension published by a foundational model is never rebuilt.
- The producing function owns a product's register row; the semantic register's owner role is the subject-area head.

## 5. Carried into the next stage

- Spec follow-ups by decision (CW-274): the missing upstreams and inputs the models exposed (DP-304, DP-306, DP-467, DP-456, DP-446, DP-412, DP-488, DP-490, DP-503, DP-506, DP-514, DP-498, DP-405, DP-418), the register renames (DP-009, DP-075), FN-15 primary for no product.
- Semantic open decisions recorded in each model's `open_decisions` (the Dimension Type and snapshot codes of DP-008 to confirm against the code lists; a Household and Service Tier Dimension Type on DP-008; the return-method parameter values; the DP-518 roles as stand-ins for data contracts; Program Bank and Manager joining SM-00; the Campaign business line; the DP-106/DP-384 and DP-105/DP-107 overlaps; the three uncovered-household definitions).
- Model gaps recorded on entities ("Model gap:" notes: borrowed and surrogate keys where a spec reads no key attribute; polymorphic references; the 06 Attribution Record's missing Measure and Snapshot references) and the WP1 "Taxonomy gap:" lines: both go to the gap register at the next consolidation pass.
- Filter values, join expressions and SQL in the semantic models are descriptive and come from the specs' drafting assumptions; the validator checks names, not logic.
- Walkthrough decks and the explorer's area views were not re-cut for the models at WP2.
