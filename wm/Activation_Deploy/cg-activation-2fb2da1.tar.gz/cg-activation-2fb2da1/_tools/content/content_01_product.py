"""Data Domain 01 - Investment Product & Service Offering (wealth manager, adapted from the wholesale 01 Investment Product). Content module for taxonomy_builder.py."""

META = {
 "title": "Investment Product & Service Offering Reference Data Taxonomy",
 "subtitle": "Business domain 01 - Investment Product & Service Offering | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "01_Product/Investment_Product_Reference_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the catalog of what a US wealth manager offers its clients: its own investment strategies, mutual funds, ETFs, bank-maintained CITs, institutional mandates and model portfolios, and the services it sells next to them (digital, hybrid and personal advice programs, planning, brokerage, trust services, workplace managed accounts and OCIO), the brokerage platform's trading policy and product availability, and access to alternatives through feeder funds. Product management maintains it; enrollment (15), recommendations (45), model management (46) and billing (47) use it. Built from open standards (FIBO CIV, openfunds, ISO, GIPS) and US regulation (Investment Company Act and its rules, Form N-1A, Advisers Act, Regulation Best Interest, FINRA rules, OCC 12 CFR 9.18)."),
  ("Scope", "In scope: investment strategies and GIPS composites, products and vehicles (funds, ETFs, CITs, feeder funds, institutional mandates, model portfolios), share classes and their features, product identifiers and classifications, investment policy, restrictions and risk ratings, benchmarks, prospectus fee and expense terms, dealing, valuation and listing terms, product parties, US channel availability, product documents and tax status, investment commentary, lifecycle and product governance; service offerings with features, eligibility rules and fee schedule links; service tiers; tradable-universe policy rules and platform product availability; feeder access terms and offering windows. Out of scope: client fee schedules and billing (47), enrollment and subscriptions (15), recommendations (45), model assignment and rebalancing (46), instrument terms and flags of third-party securities (17), manager and product due diligence (52), client orders (48), client holdings (49), fund filings and board approvals (35), partner shelf status (05)."),
  ("Structure", "Four levels: Data Domain > Data Family > Data Business Object > Data Business Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Strategy (what we manage) -> Product / Vehicle (how it is packaged: fund, ETF, CIT, feeder fund, mandate, model) -> Share Class (how investors own it). Service Offering (OFFR-: what we do for a client) -> Offering Features, Eligibility Rules (ELIG-), Fee Schedule Links (to 47) and the Model Portfolios (MDL-) it implements. Tradable Universe Policy Rules (TUP-), Platform Product Availability and the Platform Feature catalog state what the brokerage platform offers. A feeder fund is an Investment Product with Feeder Access Terms and Offering Windows (OFWN-)."),
  ("Design principles", "1) Reuse standards: openfunds field definitions and FIBO CIV concepts are the default; internal attributes only where no standard exists. 2) Effective-date everything that changes (classifications, benchmarks, parties, fees, fee schedule links, availability). 3) Use controlled code lists, not free text. 4) Reference parties, instruments, fee schedules, legal entities and calendars by ID rather than copying them. 5) An offering is not an enrollment, a model or a fee (CW-036); policy is not an instrument flag or an order check (CW-037); a feeder is a product (CW-038). 6) Flag Critical Data Elements (CDE) for governance and data-quality focus."),
  ("Applies To", "Shows the record each attribute belongs to: Strategy, Composite, Product, Mandate, Model, Share Class, Benchmark, Commentary, Service Offering, Eligibility Rule, Fee Schedule Link, Service Tier, Policy Rule, Platform Availability, Platform Feature, Offering Window or All."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify, make available, price or report on a product, or to decide whether a client may enroll in an offering or buy a product on the platform. Confirm with data owners."),
  ("Primary / Secondary Reference", "Standard or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Next step: map each openfunds-aligned attribute to its exact field ID and each Form N-1A attribute to its item and instruction."),
  ("Tabs", "Hierarchy: families, object groups and objects with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: object-level cardinalities, including references to other Data Domains | Sources: standards used, owners, licenses and links."),
  ("Suggested next steps", "1) Validate families and CDEs with Product Management, the advice program owners, Brokerage Product, Legal and Compliance and Fund Operations. 2) Confirm the reference firm's offering set, tiers, platform curation and alternatives (Source_Notes SME questions). 3) Map attributes to source systems (fund administrator, transfer agent, brokerage platform, advice engine, document management). 4) Agree data owners and stewards per family. 5) Align fee schedule links and due diligence references with the 47 and 52 drafts. 6) Turn the Relationships tab into a logical data model."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

D("Investment Strategy", "STR",
  "The investment capability or approach the firm manages, independent of the vehicle(s) through which it is offered to clients.",
  [
   ("Strategy Definition", "Core identity and ownership of an investment strategy.", [
     ("Investment Strategy", [
       ("Strategy ID", "Unique internal identifier for the investment strategy.", "Strategy", "Identifier", "", "STR-00123", "Internal", "", "Y"),
       ("Strategy Name", "Official name of the strategy as used in governance, RFPs and reporting.", "Strategy", "Text", "", "Global Sustainable Equity", "Internal", "GIPS", "Y"),
       ("Strategy Description", "Narrative description of the investment philosophy and process.", "Strategy", "Text", "", "High-conviction portfolio of 30-50 global companies with durable sustainable growth", "Internal", "", ""),
       ("Strategy Investment Objective", "Return and/or risk objective of the strategy, independent of any vehicle.", "Strategy", "Text", "", "Outperform MSCI ACWI NR by 2% p.a. over rolling 5 years", "GIPS", "", ""),
       ("Strategy Inception Date", "Date the strategy began managing assets; start of the strategy track record.", "Strategy", "Date", "ISO 8601", "2012-04-01", "GIPS", "", "Y"),
       ("Strategy Status", "Current lifecycle status of the strategy.", "Strategy", "Code", "Lifecycle Status", "Active", "Internal", "", "Y"),
       ("Investment Team", "Investment team or desk accountable for managing the strategy.", "Strategy", "Reference", "Firm-defined", "Global Equities", "Internal", "", ""),
       ("Lead Portfolio Manager", "Party reference for the named lead portfolio manager(s) of the strategy.", "Strategy", "Reference (Party)", "", "PTY-000457", "Internal", "openfunds", ""),
       ("Investment Affiliate / Boutique", "Affiliate or boutique that owns the strategy in a multi-boutique firm.", "Strategy", "Reference (Party)", "", "PTY-000012", "Internal", "", ""),
     ]),
   ]),
   ("Strategy Classification", "Firm-standard classification facets assigned at strategy level and inherited by products by default.", [
     ("Strategy Classification", [
       ("Asset Class", "Primary asset class of the strategy.", "Strategy", "Code", "Asset Class", "Equity", "Internal", "ICI", "Y"),
       ("Sub-Asset Class", "Secondary asset class grouping within the primary asset class.", "Strategy", "Code", "Sub-Asset Class (firm-defined)", "Global Equity", "Internal", "Morningstar", ""),
       ("Investment Approach", "Management approach of the strategy (active, passive, factor, etc.).", "Strategy", "Code", "Investment Approach", "Active Fundamental", "Internal", "openfunds", "Y"),
       ("Investment Style", "Style orientation of the strategy.", "Strategy", "Code", "Investment Style", "Growth", "Internal", "Morningstar", ""),
       ("Market Capitalization Focus", "Market capitalization segment targeted (equity strategies).", "Strategy", "Code", "Market Cap Focus", "Large Cap", "Internal", "Morningstar", ""),
       ("Geographic Focus", "Primary geographic investment universe.", "Strategy", "Code", "Geographic Focus", "Global", "Internal", "Morningstar", "Y"),
       ("Sector / Thematic Focus", "Sector or theme the strategy concentrates on, where applicable.", "Strategy", "Text", "", "Clean Energy", "Internal", "", ""),
       ("Public / Private Markets Indicator", "Whether the strategy invests in public, private or both markets.", "Strategy", "Code", "Market Type", "Public", "Internal", "", ""),
       ("Liquidity Profile", "Liquidity offered to investors by vehicles implementing the strategy.", "Strategy", "Code", "Liquidity Profile", "Daily", "Internal", "", ""),
     ]),
   ]),
   ("Composite (GIPS)", "GIPS composites used to present strategy performance to prospective clients.", [
     ("GIPS Composite", [
       ("Composite ID", "Unique identifier for the GIPS composite.", "Composite", "Identifier", "", "CMP-0045", "GIPS", "", "Y"),
       ("Composite Name", "Name of the composite as presented in GIPS reports.", "Composite", "Text", "", "Global Sustainable Equity Composite", "GIPS", "", "Y"),
       ("Composite Definition", "Documented criteria determining which portfolios belong to the composite.", "Composite", "Text", "", "All discretionary fee-paying portfolios managed to the Global Sustainable Equity strategy...", "GIPS", "", ""),
       ("Composite Creation Date", "Date the composite was created.", "Composite", "Date", "ISO 8601", "2013-01-01", "GIPS", "", ""),
       ("Composite Inception Date", "Date from which composite performance is presented.", "Composite", "Date", "ISO 8601", "2012-04-01", "GIPS", "", ""),
       ("Composite Benchmark", "Benchmark against which composite performance is presented.", "Composite", "Reference (Benchmark)", "", "BMK-0001", "GIPS", "", ""),
       ("Minimum Portfolio Size", "Asset threshold below which portfolios are excluded from the composite.", "Composite", "Amount", "", "USD 5,000,000", "GIPS", "", ""),
       ("Significant Cash Flow Policy", "Policy for temporarily removing portfolios with significant cash flows.", "Composite", "Text", "", "Remove if external flow > 10% of portfolio value", "GIPS", "", ""),
       ("Composite Member", "Products and mandates in the composite: those implemented by the composite's current member portfolios.", "Composite", "Text", "", "PRD-00981; MND-01234", "GIPS", "", "", "Derived copy (32, via 18): a roll-up of 32 Composite Membership (composite x 18 portfolio x period) through the active 18 Portfolio Implementation Links of the member portfolios. Membership is mastered in 32 by portfolio (CD-218 option A); re-typed from Reference (Product / Mandate) because a Reference cannot also be a Derived copy."),
     ]),
   ]),
  ])

D("Product & Vehicle", "PRD",
  "The legal or contractual vehicle through which a strategy is offered to clients: pooled funds, separate accounts, mandates and model portfolios.",
  [
   ("Product Definition", "Core identity of an investment product or vehicle.", [
     ("Investment Product", [
       ("Product ID", "Unique internal identifier for the product or vehicle.", "Product", "Identifier", "", "PRD-00981", "Internal", "FIBO CIV", "Y"),
       ("Product Legal Name", "Legal name of the product per constitutional documents.", "Product", "Text", "", "Example Funds Trust - Global Sustainable Equity Fund", "SEC Form N-1A", "FIBO CIV", "Y"),
       ("Product Marketing Name", "Short or marketing name used in client communications.", "Product", "Text", "", "Global Sustainable Equity Fund", "Internal", "", ""),
       ("Product Description", "Short description of the product for catalogs and websites.", "Product", "Text", "", "", "Internal", "", ""),
       ("Vehicle Type", "Type of investment vehicle.", "Product", "Code", "Vehicle Type", "Open-Ended Fund", "FIBO CIV", "openfunds", "Y"),
       ("Implemented Strategy", "Strategy that the product implements.", "Product", "Reference (Strategy)", "", "STR-00123", "Internal", "", "Y"),
       ("Base Currency", "Currency in which the product's NAV and accounts are kept.", "Product", "Code", "ISO 4217", "USD", "openfunds", "", "Y"),
       ("Product Inception Date", "Date the product was launched / first priced.", "Product", "Date", "ISO 8601", "2015-06-01", "openfunds", "FIBO CIV", "Y"),
       ("Fiscal Year End", "Month and day of the product's financial year end.", "Product", "Text", "MM-DD", "12-31", "openfunds", "", ""),
       ("Product Range", "Commercial product range or line the product belongs to.", "Product", "Code", "Firm-defined", "Sustainable Range", "Internal", "", ""),
     ]),
   ]),
   ("Legal Structure", "Legal form, regulatory regime and structural features of pooled vehicles: registered funds and ETFs, bank-maintained CITs and the feeder funds that give access to alternatives.", [
     ("Fund Legal Structure", [
       ("Legal Form", "Legal form of the vehicle.", "Product", "Code", "Legal Form", "Delaware Statutory Trust", "FIBO CIV", "openfunds", "Y"),
       ("Regulatory Regime", "Regulatory framework the vehicle is registered or operated under (Investment Company Act registration, a private fund exclusion, or bank collective investment fund rules).", "Product", "Code", "Regulatory Regime", "US 1940 Act Registered", "Investment Company Act of 1940", "openfunds", "Y"),
       ("Fund Domicile", "Country in which the vehicle is legally domiciled.", "Product", "Code", "ISO 3166-1 alpha-2", "US", "openfunds", "FIBO CIV", "Y"),
       ("Fund LEI", "Legal Entity Identifier of the fund or sub-fund.", "Product", "Identifier", "ISO 17442", "5493001KJTIIGC8Y1R12", "ISO 17442 (GLEIF)", "openfunds", "Y"),
       ("Umbrella Indicator", "Whether the vehicle is an umbrella structure (a series trust) containing separate series or sub-funds.", "Product", "Boolean", "", "N", "FIBO CIV", "openfunds", ""),
       ("Umbrella Fund", "Reference to the umbrella fund of which this product is a sub-fund.", "Product", "Reference (Product)", "", "PRD-00900", "FIBO CIV", "openfunds", "Y"),
       ("Segregated Liability Indicator", "Whether assets and liabilities are segregated between sub-funds.", "Product", "Boolean", "", "Y", "openfunds", "", ""),
       ("Fund Openness", "Whether the vehicle is open-ended, closed-ended or periodically open.", "Product", "Code", "Fund Openness", "Open-Ended", "FIBO CIV", "openfunds", "Y"),
       ("Fund of Funds Indicator", "Whether the vehicle primarily invests in other investment companies (fund of funds).", "Product", "Boolean", "", "N", "openfunds", "SEC Rule 12d1-4", ""),
       ("Master-Feeder Role", "Role of the vehicle in a master-feeder structure.", "Product", "Code", "Master-Feeder Role", "Standalone", "openfunds", "Investment Company Act §12(d)(1)(E)", ""),
       ("Master Fund", "Reference to the master fund, where the product is a feeder.", "Product", "Reference (Product)", "", "", "openfunds", "", ""),
       ("Legal Registration Number", "State business entity or trust registration number of the vehicle.", "Product", "Text", "", "DE 7654321", "Internal", "", ""),
       ("Constitutional Document Date", "Date of the current declaration of trust, articles or CIT declaration of trust.", "Product", "Date", "ISO 8601", "2026-03-15", "Internal", "", ""),
     ]),
   ]),
   ("Separate Account & Mandate", "Contractual arrangements where the firm manages assets for a single institutional client (IA line); a retail managed account is a 15 account managed in 46.", [
     ("Investment Mandate", [
       ("Mandate ID", "Unique identifier for the separate account or mandate.", "Mandate", "Identifier", "", "MND-01234", "Internal", "", "Y"),
       ("Mandate Name", "Name of the mandate.", "Mandate", "Text", "", "XYZ Pension Plan - Global Equity", "Internal", "", ""),
       ("Mandate Type", "Type of separately managed arrangement.", "Mandate", "Code", "Mandate Type", "Segregated Account", "Internal", "", "Y"),
       ("Client", "Institutional client (12 profile, keyed by its PTY- party) for whom the separate account or mandate is managed.", "Mandate", "Reference (Institutional Client, 12)", "", "PTY-002201", "Internal", "", "Y", "Re-pointed from Party to the restored 12 profile (CW-133, CW-151); the client is also the owner of the linked 15 account (15 Institutional Account references MND-). Name kept (CW-021)."),
       ("Implemented Strategy", "Strategy the mandate is managed to.", "Mandate", "Reference (Strategy)", "", "STR-00123", "Internal", "", "Y"),
       ("Investment Management Agreement Date", "Date the governing IMA was signed.", "Mandate", "Date", "ISO 8601", "2019-09-30", "Internal", "", ""),
       ("Custom Guidelines Indicator", "Whether the mandate has client-specific guidelines that deviate from the strategy model.", "Mandate", "Boolean", "", "Y", "Internal", "", ""),
       ("Minimum Account Size", "Minimum asset size accepted for this mandate type.", "Mandate", "Amount", "", "USD 50,000,000", "Internal", "", ""),
       ("Mandate Base Currency", "Reference currency of the mandate.", "Mandate", "Code", "ISO 4217", "USD", "Internal", "", ""),
     ]),
   ]),
   ("Model Portfolio", "Model portfolios used by the firm's advice programs (assigned to accounts in 46) and delivered to third-party platforms or sponsors for implementation (IC line).", [
     ("Model Portfolio", [
       ("Model Portfolio ID", "Unique identifier for the model portfolio.", "Model", "Identifier", "", "MDL-0077", "Internal", "", "Y"),
       ("Model Portfolio Name", "Name of the model portfolio.", "Model", "Text", "", "Global Equity Model - Moderate", "Internal", "", ""),
       ("Implemented Strategy", "Strategy the model portfolio represents.", "Model", "Reference (Strategy)", "", "STR-00123", "Internal", "", "Y"),
       ("Model Sponsor / Platform", "Intermediary platform or sponsor firm (the 05 Distributor Firm profile, keyed by its 02 PTY-) that receives the model for implementation on the IC line; blank for models used only by the firm's own advice programs, which reach accounts through 46 Model Assignment. Which sponsor program carries the model is 05 Model Program Placement.", "Model", "Reference (Distributor Firm, 05)", "", "PTY-003301", "Internal", "", "", "Row rule in enrich_01 ROW_OWNERSHIP (W5)."),
       ("Rebalance Frequency", "Frequency at which model changes are delivered.", "Model", "Code", "Frequency", "Quarterly", "Internal", "", ""),
       ("Model Delivery Method", "How the model is delivered (file, API, platform upload).", "Model", "Text", "", "Platform upload", "Internal", "", ""),
     ]),
   ]),
   ("Product Relationships", "Structural relationships between products (umbrella, master-feeder, feeder access, clones, mergers).", [
     ("Product Relationship", [
       ("Source Product", "Product at the 'from' end of the relationship.", "Product", "Reference (Product)", "", "PRD-00981", "FIBO CIV", "", "Y"),
       ("Target Product", "Product at the 'to' end of the relationship.", "Product", "Reference (Product)", "", "PRD-00900", "FIBO CIV", "", "Y"),
       ("Relationship Type", "Nature of the relationship between the two products.", "Product", "Code", "Product Relationship Type", "Umbrella - Sub-fund", "FIBO CIV", "", "Y"),
       ("Relationship Effective From", "Date the relationship became effective.", "Product", "Date", "ISO 8601", "2015-06-01", "Internal", "", ""),
       ("Relationship Effective To", "Date the relationship ended, if applicable.", "Product", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

D("Share Class", "SHC",
  "The unit of investor ownership in a pooled product, differentiated by currency, fees, distribution policy, hedging and investor eligibility.",
  [
   ("Share Class Definition", "Core identity of a share or unit class.", [
     ("Share Class", [
       ("Share Class ID", "Unique internal identifier for the share class.", "Share Class", "Identifier", "", "SHC-004512", "Internal", "FIBO CIV", "Y"),
       ("Parent Product", "Product to which the share class belongs.", "Share Class", "Reference (Product)", "", "PRD-00981", "FIBO CIV", "openfunds", "Y"),
       ("Share Class Legal Name", "Full legal name of the share class.", "Share Class", "Text", "", "Global Sustainable Equity Fund Investor Shares", "openfunds", "SEC EDGAR", "Y"),
       ("Share Class Designation", "Short class code or letter used in the prospectus.", "Share Class", "Text", "", "Investor", "openfunds", "", ""),
       ("Share Class Type", "Commercial type of the share class.", "Share Class", "Code", "Share Class Type", "Retail", "Internal", "openfunds", "Y"),
       ("Share Class Currency", "Currency in which the share class is denominated and priced.", "Share Class", "Code", "ISO 4217", "USD", "openfunds", "", "Y"),
       ("Share Class Launch Date", "Date the share class was first priced.", "Share Class", "Date", "ISO 8601", "2015-06-01", "openfunds", "", "Y"),
       ("Share Class Status", "Current lifecycle status of the share class.", "Share Class", "Code", "Lifecycle Status", "Active", "Internal", "openfunds", "Y"),
       ("Initial Offer Price", "Price per share at launch.", "Share Class", "Decimal", "", "100.00", "openfunds", "", ""),
       ("Initial Offer Period End Date", "Last day of the initial offer period.", "Share Class", "Date", "ISO 8601", "2015-05-29", "openfunds", "", ""),
     ]),
   ]),
   ("Share Class Features", "Features that differentiate share classes of the same product.", [
     ("Currency Hedging", [
       ("Currency Hedged Indicator", "Whether the share class applies currency hedging.", "Share Class", "Boolean", "", "N", "openfunds", "", "Y"),
       ("Hedging Type", "Method of hedging applied to the share class.", "Share Class", "Code", "Hedging Type", "NAV Hedged", "openfunds", "", ""),
       ("Hedge Target Ratio", "Target percentage of currency exposure hedged.", "Share Class", "Percentage", "", "100%", "Internal", "", ""),
     ]),
     ("Income Distribution", [
       ("Distribution Policy", "Whether income is accumulated or distributed.", "Share Class", "Code", "Distribution Policy", "Distributing", "openfunds", "", "Y"),
       ("Distribution Frequency", "Frequency of income distributions.", "Share Class", "Code", "Frequency", "Quarterly", "openfunds", "", ""),
       ("Distribution Payment Method", "Default treatment of distributions for investors.", "Share Class", "Code", "Distribution Payment Method", "Cash", "openfunds", "", ""),
     ]),
     ("Investor Eligibility", [
       ("Eligible Investor Type", "Type(s) of investor eligible to invest in the share class.", "Share Class", "Code (multi)", "Investor Type", "Retail; Institutional", "openfunds", "", "Y"),
       ("Minimum Initial Investment", "Minimum amount for a first subscription.", "Share Class", "Amount", "", "USD 1,000", "openfunds", "", ""),
       ("Minimum Subsequent Investment", "Minimum amount for additional subscriptions.", "Share Class", "Amount", "", "USD 100", "openfunds", "", ""),
       ("Minimum Holding", "Minimum Fund Shareholder Position (06) an investor must maintain in the share class.", "Share Class", "Amount", "", "USD 1,000", "openfunds", "", ""),
       ("Eligibility Restriction", "Narrative restriction on who may invest.", "Share Class", "Text", "", "Available only through the firm's advice programs and to employer plans meeting the plan asset minimum", "Internal", "", ""),
     ]),
   ]),
  ])

D("Identifiers & Cross-References", "IDN",
  "Industry, vendor and internal identifiers used to recognize products and share classes across systems and counterparties.",
  [
   ("Global Identifiers", "Standard identifiers issued by recognized numbering agencies or standards bodies.", [
     ("Security Identifier", [
       ("ISIN", "International Securities Identification Number of the share class.", "Share Class", "Identifier", "ISO 6166", "US1234567890", "ISO 6166 (ANNA)", "openfunds", "Y"),
       ("CUSIP", "CUSIP identifier (US/Canada share classes).", "Share Class", "Identifier", "", "123456789", "CUSIP Global Services", "", ""),
       ("FIGI", "Financial Instrument Global Identifier.", "Share Class", "Identifier", "", "BBG000BLNNH6", "OMG FIGI / OpenFIGI", "", ""),
       ("FISN", "Financial Instrument Short Name.", "Share Class", "Text", "ISO 18774", "EXAMPLE FDS/GLB SUS EQ INV", "ISO 18774", "", ""),
     ]),
     ("Regulatory Filing Identifier", [
       ("SEC Investment Company File Number", "SEC file number of the registered investment company (US).", "Product", "Identifier", "", "811-01234", "SEC EDGAR", "", ""),
       ("SEC Series ID", "SEC EDGAR series identifier of the fund (US).", "Product", "Identifier", "", "S000012345", "SEC EDGAR", "", ""),
       ("SEC Class / Contract ID", "SEC EDGAR class identifier of the share class (US).", "Share Class", "Identifier", "", "C000034567", "SEC EDGAR", "", ""),
     ]),
   ]),
   ("Vendor & Industry Cross-References", "Identifiers assigned by data vendors, ratings agencies and market infrastructure.", [
     ("External Cross-Reference", [
       ("Morningstar SecId", "Morningstar security identifier of the share class.", "Share Class", "Identifier", "", "F00000XXXX", "Morningstar", "", ""),
       ("Morningstar FundId", "Morningstar identifier of the fund.", "Product", "Identifier", "", "FS0000XXXX", "Morningstar", "", ""),
       ("Lipper ID", "LSEG Lipper identifier of the share class.", "Share Class", "Identifier", "", "68123456", "LSEG Lipper", "", ""),
       ("Bloomberg Ticker", "Bloomberg ticker of the share class.", "Share Class", "Text", "", "EXGSX US Equity", "Bloomberg", "", ""),
       ("DTCC Fund/SERV Code", "NSCC Fund/SERV fund code (US mutual funds).", "Share Class", "Identifier", "", "12345", "DTCC / NSCC", "", ""),
     ]),
   ]),
   ("Internal Cross-References", "Identifiers used by internal systems and outsourced service providers.", [
     ("System Cross-Reference", [
       ("Source System", "Application (41 application inventory) assigning the identifier.", "Product, Share Class", "Reference (Application, 41)", "", "APPL-00702", "Internal", "", "Y", "Re-typed to the 41 Application at the Stage 4 consolidation (CD-263); provider systems (fund administrator, transfer agent) are Applications of hosting model 'Provider-Hosted' (CD-147)."),
       ("Source System Code", "Identifier of the product/share class in the source system.", "Product, Share Class", "Identifier", "", "FA-10045", "Internal", "", "Y"),
       ("Cross-Reference Effective From", "Date the cross-reference became valid.", "Product, Share Class", "Date", "ISO 8601", "2015-06-01", "Internal", "", ""),
       ("Cross-Reference Effective To", "Date the cross-reference ceased to be valid.", "Product, Share Class", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

D("Product Classification", "CLS",
  "Internal, industry, regulatory and sustainability classifications assigned to products and share classes.",
  [
   ("Internal Product Classification", "Firm-standard classifications used for management reporting, AUM and catalogs.", [
     ("Firm Product Classification", [
       ("Business Line", "Business line (CW-004) that owns the product commercially.", "Product", "Code", "Business Line", "Proprietary Funds and ETFs", "Internal", "", "Y"),
       ("Product Asset Class", "Asset class of the product; defaults from the strategy but can be overridden.", "Product", "Code", "Asset Class", "Equity", "Internal", "ICI", "Y", "Inherit from Strategy unless overridden."),
       ("Product Investment Approach", "Investment approach of the product; defaults from the strategy.", "Product", "Code", "Investment Approach", "Active Fundamental", "Internal", "", "", "Inherit from Strategy unless overridden."),
       ("AUM Reporting Category", "Category used to aggregate AUM in management and public reporting.", "Product", "Code", "Firm-defined", "Equity - Global", "Internal", "", ""),
     ]),
   ]),
   ("Industry & Peer Group Classification", "Third-party category schemes used for peer comparison and distribution.", [
     ("External Classification", [
       ("Morningstar Category", "Morningstar peer category.", "Share Class", "Code", "External (Morningstar)", "Global Large-Cap Growth Equity", "Morningstar", "", ""),
       ("Morningstar Global Category", "Morningstar global broad category.", "Share Class", "Code", "External (Morningstar)", "Global Equity Large Cap", "Morningstar", "", ""),
       ("Lipper Global Classification", "LSEG Lipper Global Classification.", "Share Class", "Code", "External (LSEG Lipper)", "Equity Global", "LSEG Lipper", "", ""),
       ("ICI Investment Category", "ICI investment classification (US).", "Product", "Code", "External (ICI)", "World Equity", "ICI", "", ""),
       ("Classification Effective Date", "Date the external classification was assigned.", "Product, Share Class", "Date", "ISO 8601", "2026-01-31", "Internal", "", ""),
     ]),
   ]),
   ("Regulatory Product Classification", "Classifications required by regulation or used in regulatory reporting.", [
     ("Regulatory Classification", [
       ("CFI Code", "Classification of Financial Instruments code of the share class.", "Share Class", "Code", "ISO 10962", "CIOGEU", "ISO 10962", "openfunds", "Y"),
       ("Money Market Fund Type", "Money market fund type under SEC Rule 2a-7; drives the liquidity fee and the eligibility of the fund as a cash sweep vehicle.", "Product", "Code", "MMF Type", "Government MMF", "SEC Rule 2a-7", "", ""),
       ("US Fund Type", "SEC classification of the registered investment company.", "Product", "Code", "US Fund Type", "Open-End Management Company", "SEC Form N-1A", "", ""),
     ]),
   ]),
   ("Sustainability Classification", "ESG investment approach and the use of ESG terms in the fund name (SEC Rule 35d-1).", [
     ("ESG Classification", [
       ("ESG Investment Approach", "ESG approach(es) applied in the investment process.", "Product", "Code (multi)", "ESG Investment Approach", "ESG Integration; Exclusion / Negative Screening", "Internal", "SEC Form N-1A", ""),
       ("ESG Term in Name Indicator", "Whether the product name uses ESG- or sustainability-related terms, which brings it under the 80% investment policy of the names rule.", "Product", "Boolean", "", "Y", "SEC Rule 35d-1", "", ""),
     ]),
   ]),
  ])

D("Investment Policy & Risk", "POL",
  "The documented investment objective, policy, restrictions and risk profile of a product.",
  [
   ("Objective & Policy", "Prospectus-level objective and policy, including use of benchmarks, derivatives and leverage.", [
     ("Investment Objective & Policy", [
       ("Investment Objective", "Investment objective as stated in the offering document.", "Product", "Text", "", "To achieve long-term capital growth...", "openfunds", "Prospectus", "Y"),
       ("Investment Policy", "Investment policy as stated in the offering document.", "Product", "Text", "", "The Fund invests at least 80% in equities of companies worldwide...", "Prospectus", "", ""),
       ("Benchmark Usage Type", "How a benchmark is used in managing the product (target, constraint, comparator, index tracked).", "Product", "Code", "Benchmark Usage Type", "Comparator", "SEC Form N-1A", "", "Y"),
       ("Derivatives Usage", "Purpose(s) for which derivatives may be used.", "Product", "Code", "Derivatives Usage", "Hedging Only", "Prospectus", "SEC Rule 18f-4", ""),
       ("Leverage Calculation Method", "Value-at-risk test the fund applies to limit leverage risk from derivatives: the relative VaR test against a designated reference portfolio, the absolute VaR test, or none for a limited derivatives user.", "Product", "Code", "Leverage Method", "Relative VaR Test", "SEC Rule 18f-4", "", ""),
       ("Maximum Leverage", "Maximum permitted leverage as a percentage of NAV.", "Product", "Percentage", "", "150%", "Prospectus", "SEC Rule 18f-4", ""),
       ("Maximum Borrowing", "Maximum permitted borrowing as a percentage of NAV.", "Product", "Percentage", "", "33%", "Investment Company Act §18(f)", "Prospectus", ""),
       ("Securities Lending Permitted Indicator", "Whether the product may engage in securities lending.", "Product", "Boolean", "", "Y", "Prospectus", "", ""),
     ]),
   ]),
   ("Investment Restrictions", "Machine-readable investment restrictions and guidelines applied to products and mandates.", [
     ("Investment Restriction", [
       ("Restriction ID", "Unique identifier of the restriction.", "Product, Mandate", "Identifier", "", "RST-55012", "Internal", "", "Y"),
       ("Restriction Source", "Origin of the restriction.", "Product, Mandate", "Code", "Restriction Source", "Prospectus", "Internal", "", "Y"),
       ("Restriction Category", "Category of the restriction.", "Product, Mandate", "Code", "Restriction Category", "Concentration", "Internal", "", ""),
       ("Restriction Description", "Narrative description of the restriction.", "Product, Mandate", "Text", "", "Max 10% NAV in any single issuer", "Internal", "", ""),
       ("Limit Type", "Whether the limit is a minimum, maximum, range or prohibition.", "Product, Mandate", "Code", "Limit Type", "Maximum", "Internal", "", ""),
       ("Limit Value", "Numeric limit value.", "Product, Mandate", "Decimal", "", "10", "Internal", "", ""),
       ("Measurement Basis", "Basis on which the limit is measured.", "Product, Mandate", "Code", "Measurement Basis", "% of NAV", "Internal", "", ""),
       ("Restriction Effective From", "Date the restriction became effective.", "Product, Mandate", "Date", "ISO 8601", "2015-06-01", "Internal", "", ""),
     ]),
   ]),
   ("Risk Profile", "The firm risk rating used by suitability and advice (45) and the derivatives category of the fund under SEC Rule 18f-4.", [
     ("Product Risk Indicator", [
       ("Firm Risk Rating", "Risk rating the firm assigns to the share class on its own scale, used to match products to the investor profile in recommendations (45) and to the risk level of model portfolios.", "Share Class", "Code", "Firm Risk Rating", "4 - Moderately Aggressive", "Internal", "Exchange Act Rule 15l-1", "Y", "Renamed from Local Regulatory Risk Rating (CW-901). Product attribute; where a 37 risk model computes it, the model is referenced in the methodology (SME question 8)."),
       ("Derivatives Risk Category", "Category of the fund under the derivatives rule: no derivatives use, limited derivatives user (exposure at or below 10% of net assets), or full derivatives user with a derivatives risk management program and VaR-based leverage limit.", "Product", "Code", "Derivatives Category", "Limited Derivatives User", "SEC Rule 18f-4", "SEC Form N-PORT", ""),
     ]),
   ]),
  ])

D("Benchmark & Performance Reference", "BMK",
  "Benchmarks and indices assigned to products and the reference data that governs how performance is presented.",
  [
   ("Benchmark Definition", "Master data describing benchmarks and blended benchmarks.", [
     ("Benchmark", [
       ("Benchmark ID", "Unique internal identifier for the benchmark.", "Benchmark", "Identifier", "", "BMK-0001", "Internal", "", "Y"),
       ("Benchmark Name", "Official name of the benchmark or index.", "Benchmark", "Text", "", "MSCI ACWI Net Total Return USD", "openfunds", "", "Y"),
       ("Benchmark Administrator", "Party that administers the benchmark.", "Benchmark", "Reference (Party)", "", "MSCI", "Internal", "IOSCO Principles for Financial Benchmarks", ""),
       ("Benchmark Currency", "Currency of the benchmark.", "Benchmark", "Code", "ISO 4217", "USD", "Internal", "", ""),
       ("Return Type", "Treatment of income in the benchmark return.", "Benchmark", "Code", "Return Type", "Net Total Return", "Internal", "", ""),
       ("Benchmark Hedged Indicator", "Whether the benchmark is currency hedged.", "Benchmark", "Boolean", "", "N", "Internal", "", ""),
       ("Blended Benchmark Indicator", "Whether the benchmark is a blend of components.", "Benchmark", "Boolean", "", "N", "Internal", "", ""),
       ("Blend Components", "Component benchmarks and weights for a blended benchmark.", "Benchmark", "Reference (Benchmark) + Percentage", "", "60% BMK-0001; 40% BMK-0007", "Internal", "", ""),
       ("Benchmark Vendor Code", "Vendor ticker or code for the benchmark.", "Benchmark", "Text", "", "NDUEACWF Index", "Bloomberg", "", ""),
     ]),
   ]),
   ("Benchmark Assignment", "Effective-dated assignment of benchmarks to products and share classes by role.", [
     ("Product Benchmark Assignment", [
       ("Assigned Product / Share Class", "Product or share class receiving the benchmark.", "Product, Share Class", "Reference (Product / Share Class)", "", "SHC-004512", "Internal", "", "Y"),
       ("Assigned Benchmark", "Benchmark being assigned.", "Product, Share Class", "Reference (Benchmark)", "", "BMK-0001", "Internal", "", "Y"),
       ("Benchmark Role", "Role the benchmark plays for the product.", "Product, Share Class", "Code", "Benchmark Role", "Primary", "Internal", "openfunds", "Y"),
       ("Assignment Effective From", "Date the assignment became effective.", "Product, Share Class", "Date", "ISO 8601", "2015-06-01", "Internal", "", "Y"),
       ("Assignment Effective To", "Date the assignment ended.", "Product, Share Class", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Prospectus Disclosed Indicator", "Whether the benchmark is disclosed in the offering document (for a registered fund, the broad-based index of the prospectus performance table).", "Product, Share Class", "Boolean", "", "Y", "SEC Form N-1A", "", ""),
     ]),
   ]),
   ("Performance Reference", "Reference data that governs performance track records and presentation.", [
     ("Performance Track Record", [
       ("Performance Inception Date", "Date from which performance is calculated and shown.", "Share Class", "Date", "ISO 8601", "2015-06-01", "openfunds", "", "Y"),
       ("Track Record Source", "Predecessor product or share class whose track record is used, if any.", "Share Class", "Reference (Product / Share Class)", "", "", "Internal", "GIPS", ""),
       ("Performance Calculation Basis", "Basis on which performance is calculated.", "Share Class", "Code", "Performance Calculation Basis", "NAV-to-NAV Net of Fees", "Internal", "GIPS", ""),
     ]),
   ]),
  ])

D("Fees, Charges & Costs", "FEE",
  "Prospectus expense terms of share classes (the Fund Fee Schedule, FSCH-, CD-023; concept register row 'Fund Fee Schedule', CW-051) and the expense figures of the Form N-1A fee table. 10, 27 and 35 reference the fund fee terms as Reference (Fund Fee Schedule, 01). Client fees for advice, brokerage and account services are the 47 Fee Schedule (CLFEE-, CW-036, CW-051).",
  [
   ("Management & Ongoing Fees", "Recurring fees charged to the product or share class: with the performance fee and transaction charge groups, the Fund Fee Schedule (FSCH-) of the share class (CW-051).", [
     ("Management Fee", [
       ("Management Fee Rate", "Annual management fee as a percentage.", "Share Class", "Percentage", "", "0.75%", "openfunds", "SEC Form N-1A", "Y"),
       ("Maximum Management Fee Rate", "Maximum management fee permitted by the offering document.", "Share Class", "Percentage", "", "1.50%", "openfunds", "", ""),
       ("Fee Accrual Basis", "Basis on which the fee is calculated.", "Share Class", "Code", "Fee Accrual Basis", "Average Net Assets", "Internal", "", ""),
       ("Fee Breakpoint Schedule", "Tiered fund management fee rates by fund asset level (advisory agreement breakpoints of an own fund); a mandate's or client's fee breakpoints are 47.", "Share Class", "Reference (Fee Tier)", "", "0.75% first USD 100m; 0.60% thereafter", "Internal", "", ""),
       ("Fund-Paid Sub-TA Fee Cap", "Maximum the fund (share class) may bear for sub-transfer agency and sub-accounting services paid to intermediaries, in basis points a year of the assets serviced, as approved by the fund board; 05 Sub-Accounting Fee Terms.Fund-Paid Sub-TA Cap copies it.", "Share Class", "Decimal", "Basis points", "10", "SEC IM Guidance Update 2016-01", "", "Y", "Fund fee term (05 review ruling 1); the excess over the cap is adviser-borne (10)."),
       ("Fund-Paid Sub-TA Fee Cap Per Account", "Per-account variant of the cap: maximum annual amount per serviced shareholder account the fund may bear, where the board approved a per-account cap.", "Share Class", "Amount", "", "USD 16.00", "SEC IM Guidance Update 2016-01", "", ""),
       ("Approving Board Resolution", "35 board resolution that approved the fund-paid sub-TA fee cap.", "Share Class", "Reference (Board Resolution, 35)", "", "RESO-2026-00412", "SEC IM Guidance Update 2016-01", "Investment Company Act Rule 12b-1", ""),
     ]),
     ("Other Ongoing Fees", [
       ("Administration / Operating Fee Rate", "Fixed or variable operating / administration fee.", "Share Class", "Percentage", "", "0.15%", "openfunds", "", ""),
       ("Distribution (12b-1) Fee Rate", "Annual distribution and/or service fee (US).", "Share Class", "Percentage", "", "0.25%", "SEC Form N-1A", "", ""),
       ("Shareholder Servicing Fee Rate", "Annual shareholder servicing fee.", "Share Class", "Percentage", "", "0.10%", "SEC Form N-1A", "", ""),
     ]),
   ]),
   ("Performance Fee", "Fund-level performance-based fee terms of own funds: the fulcrum fee of a registered fund (Advisers Act §205(b)(2)) and the incentive fee of an own feeder or other qualified-client fund charged at fund level (Advisers Act Rule 205-3). A mandate's performance fee is a client fee (47).", [
     ("Performance Fee", [
       ("Performance Fee Indicator", "Whether a fund-level performance-based fee applies: a fulcrum fee that rises and falls symmetrically around an index for a registered fund, or an incentive fee of an own feeder or other qualified-client fund.", "Share Class", "Boolean", "", "N", "Advisers Act §205(b)", "Advisers Act Rule 205-3", "Y"),
       ("Performance Fee Rate", "Performance fee participation rate, or for a fulcrum fee the maximum adjustment to the base fee.", "Share Class", "Percentage", "", "0.10%", "openfunds", "Advisers Act Rule 205-1", ""),
       ("Hurdle Type", "Type of hurdle above which the fee is earned.", "Share Class", "Code", "Hurdle Type", "Benchmark", "Advisers Act Rule 205-1", "", ""),
       ("Hurdle Benchmark", "Benchmark used as the hurdle (the index of a fulcrum fee).", "Share Class", "Reference (Benchmark)", "", "BMK-0001", "Advisers Act Rule 205-1", "", ""),
       ("High-Water Mark Indicator", "Whether a high-water mark applies to the incentive fee of an own feeder or other qualified-client fund (never to a registered fund's fulcrum fee, which must be symmetric).", "Share Class", "Boolean", "", "Y", "Advisers Act Rule 205-3", "Fund offering documents", ""),
       ("Crystallization Frequency", "Frequency at which the incentive fee of an own feeder or other qualified-client fund crystallizes and becomes payable.", "Share Class", "Code", "Frequency", "Annual", "Fund offering documents", "Advisers Act Rule 205-3", ""),
       ("Performance Reference Period", "Period over which performance is measured for the fee (for a fulcrum fee, a rolling period of at least 12 months).", "Share Class", "Text", "", "Rolling 36 months", "Advisers Act Rule 205-1", "Advisers Act Rule 205-2", ""),
     ]),
   ]),
   ("Transaction Charges", "Shareholder fees of the Form N-1A fee table (sales loads, purchase and redemption fees) and the swing pricing mechanism applied when investors deal.", [
     ("Investor Transaction Charge", [
       ("Maximum Entry Charge", "Maximum front-end sales charge (load) or purchase fee on purchases, as a percentage of the offering price.", "Share Class", "Percentage", "", "5.75%", "SEC Form N-1A", "FINRA Rule 2341", "Y"),
       ("Maximum Exit Charge", "Maximum redemption fee on shares redeemed within the fund's holding period, payable to the fund (at most 2%).", "Share Class", "Percentage", "", "1.00%", "SEC Rule 22c-2", "SEC Form N-1A", "Y"),
       ("CDSC Schedule", "Contingent deferred sales charge schedule by holding period.", "Share Class", "Text", "", "1% if redeemed within 12 months", "SEC Form N-1A", "FINRA Rule 2341", ""),
       ("Switching Charge", "Exchange fee charged when shares are exchanged for shares of another fund in the same fund group (the exchange fee row of the shareholder fee table).", "Share Class", "Percentage", "", "0.00%", "SEC Form N-1A", "", ""),
       ("Anti-Dilution Mechanism", "Mechanism used to protect remaining investors from dilution by purchases and redemptions.", "Product", "Code", "Anti-Dilution Mechanism", "Redemption Fee (Rule 22c-2)", "openfunds", "SEC Rule 22c-1(a)(3)", ""),
       ("Maximum Swing Factor", "Maximum swing factor permitted under the fund's swing pricing policy.", "Product", "Percentage", "", "2.00%", "SEC Rule 22c-1(a)(3)", "Prospectus", ""),
     ]),
   ]),
   ("Reported Costs & Expense Ratios", "Annual fund operating expense figures of the Form N-1A fee table (Item 3), as of a cost reference date.", [
     ("Cost Disclosure", [
       ("Gross Expense Ratio", "Total annual fund operating expenses before waivers (US).", "Share Class", "Percentage", "", "1.10%", "SEC Form N-1A", "", ""),
       ("Net Expense Ratio", "Total annual fund operating expenses after waivers (US).", "Share Class", "Percentage", "", "0.95%", "SEC Form N-1A", "", ""),
       ("Acquired Fund Fees and Expenses", "Fees and expenses the fund incurs indirectly through its investments in other investment companies, shown as a separate line of the fee table.", "Share Class", "Percentage", "", "0.04%", "SEC Form N-1A", "SEC Rule 12d1-4", ""),
       ("Expense Cap Rate", "Contractual cap on expenses through waiver or reimbursement.", "Share Class", "Percentage", "", "0.95%", "SEC Form N-1A", "", ""),
       ("Waiver Expiry Date", "Date the contractual fee waiver or expense cap expires.", "Share Class", "Date", "ISO 8601", "2027-04-30", "SEC Form N-1A", "", ""),
       ("Cost Reference Date", "Date as of which the cost figures are calculated (the fiscal year end of the fee table).", "Share Class", "Date", "ISO 8601", "2025-12-31", "SEC Form N-1A", "", ""),
     ]),
   ]),
  ])

D("Dealing, Valuation & Listing", "OPS",
  "Operational terms governing how investors deal, how the product is valued and where it trades.",
  [
   ("Dealing Terms", "Terms on which investors subscribe and redeem.", [
     ("Dealing Terms", [
       ("Dealing Frequency", "Frequency of dealing days.", "Share Class", "Code", "Frequency", "Daily", "openfunds", "", "Y"),
       ("Dealing Cut-off Time", "Latest time orders are accepted for a dealing day.", "Share Class", "Time", "HH:MM", "16:00", "openfunds", "SEC Rule 22c-1", "Y"),
       ("Cut-off Time Zone", "Time zone of the dealing cut-off.", "Share Class", "Code", "IANA Time Zone", "America/New_York", "openfunds", "", ""),
       ("Subscription Settlement Period", "Settlement lag for subscriptions in business days.", "Share Class", "Integer", "T+n", "1", "openfunds", "", ""),
       ("Redemption Settlement Period", "Settlement lag for redemptions in business days.", "Share Class", "Integer", "T+n", "1", "openfunds", "", ""),
       ("Redemption Notice Period", "Notice required before redemption, in days.", "Share Class", "Integer", "Days", "0", "openfunds", "", ""),
       ("Lock-up Period", "Initial period during which redemptions are not permitted, in months.", "Share Class", "Integer", "Months", "0", "Internal", "", ""),
       ("Redemption Gate", "Maximum percentage of NAV redeemable on a dealing day before gating.", "Product", "Percentage", "", "10%", "Prospectus", "", ""),
       ("Pricing Basis", "Whether dealing is at forward or historic prices.", "Share Class", "Code", "Pricing Basis", "Forward", "openfunds", "", ""),
       ("Dealing Calendar", "Calendar of dealing and non-dealing days.", "Product", "Reference (Calendar)", "", "CAL-US-NYSE", "Internal", "", ""),
     ]),
   ]),
   ("Valuation & Pricing", "Terms governing valuation and NAV publication.", [
     ("Valuation Terms", [
       ("Valuation Frequency", "Frequency of NAV calculation.", "Product", "Code", "Frequency", "Daily", "openfunds", "", "Y"),
       ("Valuation Point", "Time at which assets are valued.", "Product", "Time", "HH:MM + time zone", "16:00 America/New_York", "openfunds", "", ""),
       ("Pricing Model", "Single price or single swinging price.", "Product", "Code", "Pricing Model", "Single Price", "openfunds", "", ""),
       ("NAV Decimal Precision", "Number of decimal places in the published NAV.", "Share Class", "Integer", "", "2", "Internal", "", ""),
       ("NAV Publication Channel", "Where the NAV is published.", "Share Class", "Text", "", "Firm website; Bloomberg; Morningstar", "Internal", "", ""),
     ]),
   ]),
   ("Exchange Listing", "Exchange listings for ETFs and listed closed-ended vehicles.", [
     ("Listing", [
       ("Listing Exchange", "Exchange on which the share class is listed.", "Share Class", "Code", "ISO 10383 (MIC)", "ARCX", "ISO 10383", "", "Y"),
       ("Exchange Ticker", "Local exchange ticker.", "Share Class", "Text", "", "GSEQ", "Exchange", "", "Y"),
       ("Trading Currency", "Currency in which the listing trades.", "Share Class", "Code", "ISO 4217", "USD", "Exchange", "", ""),
       ("Primary Listing Indicator", "Whether this is the primary listing.", "Share Class", "Boolean", "", "Y", "Internal", "", ""),
       ("Listing Date", "Date the listing commenced.", "Share Class", "Date", "ISO 8601", "2020-02-10", "Exchange", "", ""),
       ("Delisting Date", "Date the listing ended.", "Share Class", "Date", "ISO 8601", "", "Exchange", "", ""),
       ("iNAV Ticker", "Ticker of the indicative NAV.", "Share Class", "Text", "", "IGSEQ", "Exchange", "", ""),
     ]),
     ("ETF Characteristics", [
       ("Replication Method", "How an index-tracking product replicates its index.", "Product", "Code", "Replication Method", "Physical - Full", "openfunds", "SEC Rule 6c-11", "Y"),
       ("Creation Unit Size", "Number of shares per creation / redemption unit.", "Share Class", "Integer", "", "50000", "Internal", "", ""),
       ("Index Tracked", "Index the ETF or index fund tracks.", "Product", "Reference (Benchmark)", "", "BMK-0001", "openfunds", "", ""),
       ("ETF Share Class Indicator", "Whether the product is a mutual fund that also offers an exchange-traded share class under SEC exemptive relief.", "Product", "Boolean", "", "N", "SEC exemptive relief (multi-class ETF)", "SEC Rule 6c-11", "", "Confirm the status of the relief for the firm's range (SME question 5)."),
     ]),
   ]),
  ])

D("Product Parties & Roles", "PTY",
  "Legal entities and individuals that play a defined role for a product (service providers, delegates, portfolio managers).",
  [
   ("Service Providers", "Effective-dated assignment of service providers and delegates to products.", [
     ("Product Party Role", [
       ("Party", "Reference to the party in the party / legal entity master.", "Product", "Reference (Party)", "", "PTY-000101", "FIBO CIV", "", "Y"),
       ("Party Legal Name", "Legal name of the party (from party master).", "Product", "Text", "", "Example Trust Bank N.A.", "openfunds", "", ""),
       ("Party LEI", "LEI of the party (from party master).", "Product", "Identifier", "ISO 17442", "549300XXXXXXXXXXXX12", "ISO 17442 (GLEIF)", "openfunds", ""),
       ("Party Role Type", "Role the party plays for the product.", "Product", "Code", "Party Role Type", "Custodian", "FIBO CIV", "openfunds", "Y"),
       ("Delegated Function Indicator", "Whether the role is performed under delegation from the fund's investment adviser (for example a sub-adviser under a sub-advisory agreement, 52).", "Product", "Boolean", "", "Y", "Investment Company Act §15(a)", "", ""),
       ("Role Effective From", "Date the party assumed the role.", "Product", "Date", "ISO 8601", "2015-06-01", "Internal", "", "Y"),
       ("Role Effective To", "Date the party ceased the role.", "Product", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Key Persons", "Portfolio managers and other key persons named for a product.", [
     ("Portfolio Manager Assignment", [
       ("Portfolio Manager", "Reference to the individual portfolio manager.", "Product, Mandate", "Reference (Party)", "", "PTY-000457", "openfunds", "", "Y"),
       ("Portfolio Manager Role", "Role of the individual on the product.", "Product, Mandate", "Code", "PM Role", "Lead", "Internal", "", ""),
       ("PM Start Date", "Date the individual started managing the product.", "Product, Mandate", "Date", "ISO 8601", "2015-06-01", "openfunds", "SEC Form N-1A", ""),
       ("PM End Date", "Date the individual stopped managing the product.", "Product, Mandate", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

D("Distribution & Registration", "DST",
  "Through which US channels a product is made available. Registration of registered funds and state notice filings are 35 Fund Regulatory Filing; partner platform shelf detail is 05.",
  [
   ("Channel & Availability", "Availability of the share class by channel (direct brokerage, advice programs, workplace plan menus, intermediary, institutional) and its sales restrictions.", [
     ("Distribution Availability", [
       ("Distribution Channel", "Channel(s) through which the share class is made available: the commercial channel decision; operational availability on the firm's own brokerage platform is Platform Product Availability.", "Share Class", "Code (multi)", "Distribution Channel", "Direct - Self-Directed; Direct - Digital Advice; Direct - Human Advice", "Internal", "", ""),
       ("Platform Availability", "Third-party intermediary platforms on which the share class is available (IC line); shelf status is mastered in 05.", "Share Class", "Reference (Party) (multi)", "", "PTY-003301; PTY-003302", "Internal", "", ""),
       ("Sales Restriction", "Restrictions on selling the product (e.g., to US persons).", "Product, Share Class", "Text", "", "Not available to investors residing outside the United States", "Prospectus", "", ""),
     ]),
   ]),
  ])

D("Regulatory, Tax & Disclosure", "REG",
  "US regulatory registration, required documents and tax status of products and share classes.",
  [
   ("Regulatory Authorization", "Registration of the product with, or supervision by, its US regulator.", [
     ("Regulatory Authorization", [
       ("Competent Authority", "Regulator with which the product is registered or that supervises it (the SEC for a registered fund; the OCC or a state banking regulator for a bank-maintained CIT).", "Product", "Reference (Party)", "", "PTY-000020", "openfunds", "", "Y"),
       ("Authorization Date", "Date the registration statement became effective or the product was authorized.", "Product", "Date", "ISO 8601", "2015-05-15", "openfunds", "", ""),
       ("Authorization Number", "Regulator-assigned registration number (for a registered fund, the Securities Act file number).", "Product", "Identifier", "", "333-123456", "Internal", "", ""),
       ("Regulatory Reporting Obligations", "Regulatory reports the product is in scope for.", "Product", "Text (multi)", "", "Form N-PORT; Form N-CEN; Form N-CSR", "Internal", "", ""),
     ]),
   ]),
   ("Product Disclosures", "Regulatory and marketing documents published for products and share classes: statutory and summary prospectus (Rule 498), SAI, tailored shareholder reports (Rule 30e-1), CIT disclosure documents, fact sheets.", [
     ("Product Document", [
       ("Document Type", "Type of document.", "Product, Share Class", "Code", "Document Type", "Summary Prospectus", "openfunds", "SEC Rule 498", "Y"),
       ("Document Language", "Language of the document.", "Product, Share Class", "Code", "ISO 639-1", "en", "openfunds", "", "Y"),
       ("Document Jurisdiction", "Country for which the document is produced.", "Product, Share Class", "Code", "ISO 3166-1 alpha-2", "US", "openfunds", "", ""),
       ("Document Version Date", "Date of the document version.", "Product, Share Class", "Date", "ISO 8601", "2026-02-14", "openfunds", "", "Y"),
       ("Document Location", "URL or repository reference for the document.", "Product, Share Class", "Text", "URI", "https://docs.example.com/summary-prospectus/US1234567890_en.pdf", "openfunds", "", ""),
     ]),
   ]),
   ("Tax Status", "US tax classification and FATCA status of the product.", [
     ("Product Tax Status", [
       ("Tax Residence Country", "Country of tax residence of the vehicle.", "Product", "Code", "ISO 3166-1 alpha-2", "US", "Internal", "", ""),
       ("US Tax Classification", "US federal tax classification of the vehicle.", "Product", "Code", "US Tax Classification", "RIC", "Internal", "", ""),
       ("FATCA GIIN", "Global Intermediary Identification Number.", "Product", "Identifier", "", "98Q96B.00000.LE.442", "IRS FATCA", "", ""),
       ("Tax Transparency Indicator", "Whether the vehicle is tax transparent.", "Product", "Boolean", "", "N", "Internal", "", ""),
     ]),
   ]),
  ])

D("Investment Commentary", "CMT",
  "Market and investment commentary written by the investment teams: the source record that marketing content (04) and client reports (12) reuse. One commentary covers one subject (the markets, an asset class, a strategy, a product or a mandate) for one period.",
  [
   ("Commentary Definition", "Identity, subject, period and authorship of a commentary.", [
     ("Investment Commentary", [
       ("Commentary ID", "Unique identifier of the commentary.", "Commentary", "Identifier", "", "CMT-2026Q3-00412", "Internal", "", "Y"),
       ("Commentary Type", "Kind of commentary.", "Commentary", "Code", "Commentary Type", "Portfolio Commentary", "Internal", "", "Y"),
       ("Commentary Title", "Title or headline of the commentary.", "Commentary", "Text", "", "Global Sustainable Equity: Q3 2026 review", "Internal", "", ""),
       ("Commentary Scope", "Level of subject the commentary is written about.", "Commentary", "Code", "Commentary Scope", "Strategy", "Internal", "", "Y"),
       ("Subject Asset Class", "Asset class discussed, for market commentary written at asset-class level.", "Commentary", "Code", "Asset Class", "Fixed Income", "Internal", "", ""),
       ("Subject Strategy", "Strategy the commentary is written about.", "Commentary", "Reference (Strategy)", "", "STR-00123", "Internal", "", "Y"),
       ("Subject Product / Mandate", "Product or mandate the commentary is written about, where it is specific to one vehicle or client portfolio.", "Commentary", "Reference (Product / Mandate)", "", "PRD-00981", "Internal", "", ""),
       ("Commentary Frequency", "How often the commentary is produced.", "Commentary", "Code", "Frequency", "Quarterly", "Internal", "", ""),
       ("Commentary Period End Date", "Last day of the period the commentary covers.", "Commentary", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
       ("Commentary Data As-Of Date", "Date as of which the 18 Portfolio Holdings, performance and market data quoted are stated.", "Commentary", "Date", "ISO 8601", "2026-09-30", "Internal", "SEC Marketing Rule", ""),
       ("Commentary Author", "Portfolio manager, strategist or product specialist who wrote the commentary.", "Commentary", "Reference (Employee)", "", "EMP-00107", "Internal", "", "", "PII (named individual)."),
       ("Commentary Language", "Language the commentary is written in; a translation is a separate commentary linked to its source.", "Commentary", "Code", "ISO 639-1", "en", "Internal", "", ""),
       ("Translated From", "Source-language commentary this one translates.", "Commentary", "Reference (Investment Commentary)", "", "CMT-2026Q3-00398", "Internal", "", ""),
       ("Commentary Location", "URL or repository reference for the commentary text.", "Commentary", "Text", "URI", "https://content.example.com/commentary/CMT-2026Q3-00412", "Internal", "", ""),
     ]),
   ]),
   ("Commentary Approval & Use", "Sign-off of a commentary and the limits on who may receive it.", [
     ("Commentary Approval", [
       ("Commentary Status", "Lifecycle status of the commentary.", "Commentary", "Code", "Commentary Status", "Approved for Use", "Internal", "", "Y"),
       ("Investment Sign-Off By", "Portfolio manager or investment lead who signed off the commentary as reflecting the team's views.", "Commentary", "Reference (Employee)", "", "EMP-00107", "Internal", "", "", "PII (named individual)."),
       ("Investment Sign-Off Date", "Date the investment team signed off the commentary.", "Commentary", "Date", "ISO 8601", "2026-10-08", "Internal", "", "Y"),
       ("Permitted Audience", "Widest audience the commentary may be used with; content and reports built from it may not go wider.", "Commentary", "Code", "Audience Restriction", "Institutional Use Only", "Internal", "FINRA Rule 2210", "Y"),
       ("Use-By Date", "Date after which the commentary must not be used in new content or reports.", "Commentary", "Date", "ISO 8601", "2027-01-15", "Internal", "", ""),
       ("Supersedes Commentary", "Earlier commentary this one corrects or replaces.", "Commentary", "Reference (Investment Commentary)", "", "CMT-2026Q3-00405", "Internal", "", ""),
     ]),
   ]),
  ])

D("Lifecycle & Governance", "LCG",
  "Lifecycle events of products, share classes and service offerings, and product governance. Governance metadata of records is modeled once in 21 (CD-160).",
  [
   ("Product Lifecycle", "Effective-dated events that change the status or structure of a product, share class or service offering (launch, close, merger, conversion, rename).", [
     ("Lifecycle Event", [
       ("Lifecycle Status", "Current status of the product or share class.", "All", "Code", "Lifecycle Status", "Active", "Internal", "openfunds", "Y"),
       ("Status Effective Date", "Date the current status took effect.", "All", "Date", "ISO 8601", "2015-06-01", "Internal", "", ""),
       ("Lifecycle Event Type", "Type of lifecycle event.", "Product, Share Class, Service Offering", "Code", "Lifecycle Event Type", "Merger", "Internal", "", "Y"),
       ("Event Effective Date", "Date the event took effect.", "Product, Share Class, Service Offering", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
       ("Successor Product / Share Class", "Product or share class that receives investors after a merger or conversion.", "Product, Share Class", "Reference (Product / Share Class)", "", "SHC-004700", "Internal", "", ""),
       ("Event Reason", "Business rationale for the event.", "Product, Share Class, Service Offering", "Text", "", "Sub-scale; merged into larger fund with same strategy", "Internal", "", ""),
       ("Investor Notice Date", "Date investors or enrolled clients were notified of the event.", "Product, Share Class, Service Offering", "Date", "ISO 8601", "2026-08-15", "Internal", "", "", "Derived from the 13 shareholder communication for fund events; for a service offering change the notice to enrolled clients is to be confirmed against the 13 scope."),
     ]),
   ]),
   ("Product Governance", "Product approval and periodic review reference data (new product vetting).", [
     ("Product Governance", [
       ("Product Owner", "Business owner accountable for the product.", "Product", "Reference (Party)", "", "PTY-000999", "Internal", "", "Y"),
       ("Product Approval Date", "Date the product was approved by the product governance committee.", "Product", "Date", "ISO 8601", "2015-03-10", "Internal", "NASD Notice to Members 05-26", ""),
       ("Last Product Review Date", "Date of the last periodic product review.", "Product", "Date", "ISO 8601", "2026-03-31", "Internal", "NASD Notice to Members 05-26", ""),
       ("Next Product Review Date", "Scheduled date of the next product review.", "Product", "Date", "ISO 8601", "2027-03-31", "Internal", "", ""),
       ("Governing Body", "Board or governing body overseeing the product.", "Product", "Reference (Party)", "", "PTY-000050", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Wealth-manager additions (CW-036 to CW-038; family codes PR-, CW-040)
# ---------------------------------------------------------------------------
D("Advice & Service Offerings", "PR-ASO",
  "The service offerings the firm defines and sells next to its funds: digital, hybrid and personal advice programs, planning-only and wealth management services, the brokerage service, trust services, workplace managed accounts and OCIO. Each offering has features, eligibility rules and a standard fee schedule held by reference; enrollment is 15, the recommendation 45, model assignment 46 and the fee schedule itself 47 (CW-036). Service tiers are defined here and assigned in 02 (CW-028).",
  [
   ("Offering Definition", "Identity, type, regulatory capacity and status of a service offering, and the features it includes.", [
     ("Service Offering", [
       ("Offering ID", "Unique identifier of the service offering.", "Service Offering", "Identifier", "", "OFFR-0012", "Internal", "", "Y"),
       ("Offering Name", "Name of the offering as shown to clients and in Form ADV.", "Service Offering", "Text", "", "Digital Advisor Program", "Internal", "Form ADV Part 2A Appendix 1", "Y"),
       ("Offering Type", "Kind of service the offering provides.", "Service Offering", "Code", "Offering Type", "Digital Advice", "Internal", "SEC IM Guidance Update 2017-02", "Y"),
       ("Delivery Mode", "How the client receives the service: online only, online with access to an advisor, or a dedicated advisor.", "Service Offering", "Code", "Delivery Mode", "Digital with Advisor Access", "Internal", "", ""),
       ("Discretion Type", "Whether the firm manages enrolled accounts with discretionary authority or recommends and the client decides.", "Service Offering", "Code", "Discretion Type", "Discretionary", "Form ADV Part 2A", "Investment Company Act Rule 3a-4", ""),
       ("Advisory Capacity", "Capacity in which the firm provides the service: as an investment adviser under the Advisers Act or as a broker-dealer under Regulation Best Interest.", "Service Offering", "Code", "Advisory Capacity", "Investment Adviser", "Exchange Act Rule 15l-1", "Investment Advisers Act of 1940", "Y"),
       ("Sponsoring Entity", "Internal legal entity that sponsors the offering and contracts with the client (the registered investment adviser, the broker-dealer or the trust company).", "Service Offering", "Reference (Internal Legal Entity)", "", "LEN-0004", "Internal", "Form ADV Part 1A", ""),
       ("Wrap Fee Program Indicator", "Whether the offering is a wrap fee program, with advisory and brokerage services for a single fee, that requires a wrap fee program brochure.", "Service Offering", "Boolean", "", "Y", "Form ADV Part 2A Appendix 1", "", ""),
       ("Rule 3a-4 Program Indicator", "Whether the offering is operated within the safe harbor for discretionary advisory programs, so that the program is not itself an investment company.", "Service Offering", "Boolean", "", "Y", "Investment Company Act Rule 3a-4", "", ""),
       ("Model Portfolios Used", "Model portfolios the offering implements in enrolled accounts; 46 assigns one of them to each account.", "Service Offering", "Reference (Model Portfolio) (multi)", "", "MDL-0077; MDL-0078", "Internal", "", ""),
       ("Offering Status", "Current lifecycle status of the offering; launches, closes and changes are recorded as lifecycle events.", "Service Offering", "Code", "Lifecycle Status", "Active", "Internal", "", ""),
     ]),
     ("Offering Feature", [
       ("Offering Feature Type", "Feature the offering includes for enrolled accounts.", "Service Offering", "Code", "Offering Feature Type", "Tax-Loss Harvesting", "Internal", "SEC IM Guidance Update 2017-02", ""),
       ("Feature Setting", "Parameter of the feature as offered, such as a rebalancing frequency or drift threshold, an advisor access channel or an account balance from which the feature applies.", "Service Offering", "Text", "", "Daily scan; harvest when the unrealized loss on a lot exceeds USD 1,000", "Internal", "", ""),
     ]),
   ]),
   ("Offering Eligibility", "Rules that decide who may enroll in an offering; 15 applies them at enrollment.", [
     ("Offering Eligibility Rule", [
       ("Eligibility Rule ID", "Unique identifier of the eligibility rule.", "Eligibility Rule", "Identifier", "", "ELIG-0031", "Internal", "", "Y"),
       ("Eligibility Offering", "Service offering the rule applies to.", "Eligibility Rule", "Reference (Service Offering)", "", "OFFR-0012", "Internal", "", "Y"),
       ("Eligibility Criterion", "Fact the rule tests.", "Eligibility Rule", "Code", "Eligibility Criterion", "Minimum Assets", "Internal", "", "Y"),
       ("Criterion Operator", "Comparison applied between the tested fact and the threshold.", "Eligibility Rule", "Code", "Comparison Operator", "At Least", "Internal", "", ""),
       ("Criterion Threshold", "Value or values the fact is compared with: an amount, a list of account registration types (15), an investor qualification standard or a list of states.", "Eligibility Rule", "Text", "", "USD 3,000", "Internal", "", "Y"),
       ("Eligibility Effective From", "Date from which the rule applies to new enrollments.", "Eligibility Rule", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Eligibility Effective To", "Date after which the rule no longer applies; a changed threshold is a new rule version.", "Eligibility Rule", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Offering Pricing Link", "The standard and promotional fee schedules that apply to an offering. The schedule, its rates and breakpoints are 47.", [
     ("Offering Fee Schedule Link", [
       ("Linked Offering", "Service offering the fee schedule applies to.", "Fee Schedule Link", "Reference (Service Offering)", "", "OFFR-0012", "Internal", "", "Y"),
       ("Linked Fee Schedule", "Client fee schedule that prices the offering.", "Fee Schedule Link", "Reference (Fee Schedule, 47)", "", "CLFEE-0012-03", "Internal", "Form ADV Part 2A", "Y"),
       ("Fee Schedule Link Type", "Whether the schedule is the offering's standard schedule or a promotional schedule for new enrollments.", "Fee Schedule Link", "Code", "Fee Schedule Link Type", "Standard", "Internal", "", ""),
       ("Link Effective From", "Date from which the schedule applies to the offering.", "Fee Schedule Link", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Link Effective To", "Date after which the schedule no longer applies to the offering.", "Fee Schedule Link", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Service Tiers", "Firm-wide relationship tiers with their asset thresholds and benefits; 02 assigns a tier to a household or client.", [
     ("Service Tier", [
       ("Service Tier Code", "Firm code of the service tier; the tier's natural key.", "Service Tier", "Code", "Firm-defined", "PREMIER", "Internal", "", "Y", "The tier code is the key; no ID prefix is registered (CW-028)."),
       ("Service Tier Name", "Name of the tier shown to clients.", "Service Tier", "Text", "", "Premier", "Internal", "", ""),
       ("Tier Asset Threshold", "Minimum qualifying assets for the tier.", "Service Tier", "Amount", "", "USD 1,000,000", "Internal", "", "Y"),
       ("Tier Measurement Basis", "Assets that count toward the threshold; the measured amount per household is held on the 02 Service Tier Assignment from 06 client assets.", "Service Tier", "Code", "Tier Measurement Basis", "Household Client Assets", "Internal", "", ""),
       ("Tier Benefits", "Services and privileges the tier includes.", "Service Tier", "Text", "", "Dedicated service team; annual planning review; priority phone line", "Internal", "", ""),
     ]),
   ]),
  ])

D("Brokerage Platform Offering", "PR-PLT",
  "The policy of the brokerage platform: which instruments are tradable and on what terms (universe inclusion, fractional and extended-hours eligibility, purchase restrictions), and which own and third-party funds and ETFs are available with their transaction-fee category. 17 holds each instrument's resulting flags, 52 the due diligence, 47 the fee amounts and 48 the order-time checks (CW-037).",
  [
   ("Trading Policy", "Policy rules that set the tradable universe and trading features.", [
     ("Tradable Universe Policy Rule", [
       ("Policy Rule ID", "Unique identifier of the policy rule.", "Policy Rule", "Identifier", "", "TUP-0011", "Internal", "", "Y"),
       ("Rule Name", "Name of the policy rule.", "Policy Rule", "Text", "", "Extended-hours eligibility - listed equities and ETFs", "Internal", "", ""),
       ("Universe Rule Type", "What the rule decides.", "Policy Rule", "Code", "Universe Rule Type", "Extended-Hours Eligibility", "Internal", "FINRA Rule 2265", "Y"),
       ("Rule Criteria", "Instrument types (17) the rule applies to and the criteria an instrument must meet, including for extended-hours rules the session times; 17 records the result per instrument with this rule's ID.", "Policy Rule", "Text", "", "Common stock and ETFs listed on a US national exchange; price at least USD 1; sessions 07:00-09:30 and 16:00-20:00 America/New_York", "Internal", "FINRA Rule 2265", "Y"),
       ("Rule Effective From", "Date the rule takes effect.", "Policy Rule", "Date", "ISO 8601", "2026-03-02", "Internal", "", ""),
       ("Rule Effective To", "Date after which the rule no longer applies.", "Policy Rule", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Rule Status", "Current lifecycle status of the rule.", "Policy Rule", "Code", "Lifecycle Status", "Active", "Internal", "", ""),
     ]),
   ]),
   ("Brokerage Platform Availability", "Operational availability of own share classes and third-party funds and ETFs on the firm's own brokerage platform. Distribution Availability.Distribution Channel is the commercial channel decision; this is the status on the platform.", [
     ("Platform Product Availability", [
       ("Platform Availability ID", "Unique identifier of one availability row (an own share class or a third-party instrument on the firm's brokerage platform).", "Platform Availability", "Identifier", "", "PLAVL-000731", "Internal", "", "Y", "Object PII tier: No PII. PLAVL- proposed at W5 (proposals_w5_content NOTES)."),
       ("Available Share Class", "Own share class made available on the platform; empty when the row is for a third-party instrument.", "Platform Availability", "Reference (Share Class)", "", "SHC-004512", "Internal", "", "Y"),
       ("Available Third-Party Instrument", "Third-party fund or ETF made available on the platform; empty when the row is for an own share class.", "Platform Availability", "Reference (Instrument)", "", "INS-00104477", "Internal", "", "Y"),
       ("Platform Availability Status", "Whether clients may buy, only hold or sell, or not access the product on the platform; a purchase restriction on a class of instruments is a Purchase Restriction policy rule.", "Platform Availability", "Code", "Availability Status", "Available", "Internal", "", "Y"),
       ("Transaction Fee Category", "Commission treatment of purchases of the product on the platform; whether the product is the firm's own is given by which reference the row fills. The amounts are 47.", "Platform Availability", "Code", "Transaction Fee Category", "No Transaction Fee", "Internal", "", "Y"),
       ("Due Diligence Approval", "Due diligence review that approved the third-party product for the platform.", "Platform Availability", "Reference (Product Due Diligence, 52)", "", "TPDUE-2026-000412", "Internal", "", ""),
       ("Availability Effective From", "Date the availability status took effect.", "Platform Availability", "Date", "ISO 8601", "2026-04-01", "Internal", "", ""),
     ]),
   ]),
   ("Platform Feature Catalog", "The brokerage account features the platform offers (one row per 15 Feature Type) and who may use them: the live eligibility that 36 Platform Feature Specification proposes and 15 Account Feature applies per account (CW-161).", [
     ("Platform Feature", [
       ("Platform Feature Type", "Brokerage account feature offered on the platform, in the 15 Feature Type values; the key of the catalog row.", "Platform Feature", "Code", "External (15 Feature Type)", "Extended-Hours Trading", "Internal", "FINRA Rule 2265", "Y"),
       ("Eligible Offerings", "Service offerings whose enrolled accounts may use the feature.", "Platform Feature", "Reference (Service Offering) (multi)", "", "OFFR-0003", "Internal", "", "Y"),
       ("Eligible Account Registration Types", "Account registration types that may use the feature.", "Platform Feature", "Code (multi)", "External (15 Account Registration Type)", "Individual; Joint Tenants (JTWROS); Roth IRA", "Internal", "", "Y"),
       ("Required Disclosure Type", "Disclosure a client must receive before using the feature; delivery is 15 Account Disclosure Delivery.", "Platform Feature", "Code", "External (15 Disclosure Type)", "Extended Hours Trading Risk Disclosure", "FINRA Rule 2265", "", "Y"),
       ("Client Activation Required Indicator", "Whether a client must request the feature, creating a 15 Account Feature row, rather than receive it on every eligible account.", "Platform Feature", "Boolean", "", "Y", "Internal", "", ""),
       ("Feature Governing Policy Rule", "Tradable universe policy rule that sets which instruments and sessions the feature applies to, where one does.", "Platform Feature", "Reference (Tradable Universe Policy Rule)", "", "TUP-0011", "Internal", "FINRA Rule 2265", ""),
       ("Feature Effective From", "Date the feature (or this version of its eligibility) took effect on the platform.", "Platform Feature", "Date", "ISO 8601", "2026-03-02", "Internal", "", ""),
     ]),
   ]),
  ])

D("Alternative Investment Access", "PR-ALT",
  "Feeder funds, tender-offer funds and interval funds through which qualified clients reach private funds and other alternatives: the access terms of the feeder product and its offering windows. The subscription is 15, the resulting holding 49 and the underlying private fund a 17 fund-interest instrument whose manager is reviewed in 52 (CW-038).",
  [
   ("Feeder Access", "Access terms of a feeder or access product. The minimum subscription is the share class Minimum Initial Investment; the placement agent is a Product Party Role (Placement Agent); redemption, notice and lock-up terms are Dealing Terms.", [
     ("Feeder Access Terms", [
       ("Feeder Access Structure", "Vehicle structure through which the product gives access to the underlying investment: Feeder Fund, Tender-Offer Fund or Interval Fund of the shared Vehicle Type list.", "Product", "Code", "Vehicle Type", "Feeder Fund", "Internal", "", ""),
       ("Underlying Fund Instrument", "Underlying private fund interest a feeder fund invests in; empty for an interval or tender-offer fund that is itself the vehicle and holds its own portfolio (18).", "Product", "Reference (Instrument)", "", "INS-00218840", "Internal", "", ""),
       ("Required Investor Qualification", "Investor qualification an investor must evidence to subscribe.", "Product", "Code", "Investor Qualification Standard", "Qualified Purchaser", "Regulation D Rule 506", "Investment Company Act §3(c)(7)", "Y"),
     ]),
   ]),
   ("Offering Windows", "Periods during which a feeder accepts subscriptions.", [
     ("Offering Window", [
       ("Offering Window ID", "Unique identifier of the offering window.", "Offering Window", "Identifier", "", "OFWN-2026-Q4-0005", "Internal", "", "Y"),
       ("Window Feeder Product", "Feeder product the window belongs to.", "Offering Window", "Reference (Product)", "", "PRD-01120", "Internal", "", "Y"),
       ("Window Open Date", "First date subscriptions are accepted.", "Offering Window", "Date", "ISO 8601", "2026-11-03", "Internal", "", "Y"),
       ("Window Close Date", "Last date subscriptions are accepted.", "Offering Window", "Date", "ISO 8601", "2026-12-12", "Internal", "", "Y"),
       ("Window Capacity", "Maximum aggregate subscriptions the window accepts.", "Offering Window", "Amount", "", "USD 75,000,000", "Internal", "", ""),
       ("Window Status", "Current status of the window.", "Offering Window", "Code", "Window Status", "Open", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Lifecycle Status": ("Internal (aligned to openfunds)", [("Proposed","Idea under evaluation"),("In Development","Approved for build, not yet launched"),("Active","Launched and open to investors"),("Soft Closed","Closed to new investors; existing investors may add"),("Hard Closed","Closed to all subscriptions"),("In Liquidation","Liquidation in progress"),("Merged","Merged into a successor"),("Liquidated","Fully liquidated"),("Inactive","Launched but unfunded / dormant")]),
 "Asset Class": ("Internal (aligned to ICI and Morningstar categories)", [("Equity",""),("Fixed Income",""),("Multi-Asset",""),("Money Market",""),("Real Estate",""),("Private Equity",""),("Private Credit",""),("Infrastructure",""),("Hedge / Absolute Return",""),("Commodities",""),("Other","")]),
 "Investment Approach": ("Internal", [("Active Fundamental",""),("Active Quantitative",""),("Passive Index",""),("Smart Beta / Factor",""),("Enhanced Index","")]),
 "Investment Style": ("Internal (aligned to Morningstar Style Box)", [("Growth",""),("Value",""),("Core / Blend",""),("Income",""),("Quality",""),("Not Applicable","")]),
 "Market Cap Focus": ("Internal", [("Large Cap",""),("Mid Cap",""),("Small Cap",""),("Micro Cap",""),("All Cap",""),("Not Applicable","")]),
 "Geographic Focus": ("Internal", [("Global",""),("Global ex-US",""),("Developed Markets",""),("Emerging Markets",""),("Frontier Markets",""),("North America",""),("Europe",""),("Asia Pacific",""),("Single Country","Specify country in Sector / Thematic or separate attribute")]),
 "Market Type": ("Internal", [("Public",""),("Private",""),("Hybrid","")]),
 "Liquidity Profile": ("Internal", [("Daily",""),("Weekly / Monthly",""),("Semi-Liquid (Evergreen)","Periodic liquidity, typically quarterly with gates"),("Illiquid (Drawdown / Closed-Ended)","")]),
 "Vehicle Type": ("FIBO CIV / openfunds", [("Open-Ended Fund","Mutual fund (open-end management company)"),("Exchange-Traded Fund",""),("Closed-End Fund",""),("Interval Fund","US periodic repurchase fund (Rule 23c-3)"),("Tender-Offer Fund","Closed-end fund offering periodic repurchases by tender offer"),("Feeder Fund","Fund that gives qualified clients access to an underlying private fund (CW-038)"),("Collective Investment Trust","US bank-maintained CIT"),("Unit Investment Trust",""),("Separately Managed Account","Institutional separately managed account, or the firm as manager in a third-party sponsor's program (IC line); a retail managed account is a 15 account managed in 46"),("Segregated Mandate","Institutional separate account"),("Model Portfolio","")]),
 "Legal Form": ("FIBO CIV / openfunds", [("US Open-End Investment Company","'40 Act registered"),("Delaware Statutory Trust",""),("Massachusetts Business Trust",""),("Maryland Corporation",""),("Limited Partnership",""),("Limited Liability Company",""),("Bank Collective Trust","")]),
 "Regulatory Regime": ("openfunds / Internal", [("US 1940 Act Registered",""),("US Private Fund 3(c)(1)",""),("US Private Fund 3(c)(7)",""),("US Bank CIT","OCC 12 CFR 9.18 / state banking regulation")]),
 "Fund Openness": ("FIBO CIV", [("Open-Ended",""),("Closed-Ended",""),("Semi-Open","Interval / tender-offer liquidity")]),
 "Master-Feeder Role": ("Investment Company Act §12(d)(1)(E)", [("Master",""),("Feeder",""),("Standalone","")]),
 "Mandate Type": ("Internal", [("Segregated Account","Institutional separate account (IA line)"),("Sub-Advisory",""),("Fund of One","")]),
 "Commentary Type": ("Internal", [("Market Commentary","Review of markets and the economy; not specific to a portfolio"),("Investment Outlook","Forward-looking house or team view"),("Portfolio Commentary","Positioning, activity and performance of a strategy, product or mandate over the period"),("Performance Attribution Commentary","Explanation of the sources of return against the benchmark"),("Event Commentary","Ad hoc note on a market or portfolio event")]),
 "Commentary Scope": ("Internal", [("House View","Firm-wide view of markets"),("Asset Class",""),("Strategy",""),("Product",""),("Mandate","")]),
 "Commentary Status": ("Internal", [("Draft",""),("In Investment Review",""),("Approved for Use","Signed off by the investment team; marketing use still needs 08 review of the published asset"),("Superseded",""),("Withdrawn","")]),
 "Audience Restriction": ("Internal (aligned to 04 / 08)", [("Public / Retail",""),("Financial Professional Use Only",""),("Institutional Use Only",""),("Partner-Specific",""),("Client-Specific",""),("Internal Use Only","")]),
 "Frequency": ("Internal", [("Daily",""),("Weekly",""),("Biweekly",""),("Monthly",""),("Quarterly",""),("Semi-Annual",""),("Annual",""),("Ad Hoc","")]),
 "Product Relationship Type": ("FIBO CIV / Internal", [("Umbrella - Sub-fund",""),("Master - Feeder",""),("Feeder Of","Feeder fund investing in another own product; an external underlying private fund is referenced in Feeder Access Terms (17)"),("Clone / Mirror","Same strategy, different vehicle"),("Parallel Vehicle",""),("Fund of Funds Holding",""),("Predecessor - Successor","Merger or conversion")]),
 "Share Class Type": ("Internal / openfunds", [("Retail",""),("Institutional",""),("Front-End Load","Intermediary class with a front-end sales charge (IC line)"),("Level Load","Intermediary class with a 12b-1 fee and CDSC (IC line)"),("Clean","No sales load or 12b-1 fee"),("Founder / Seed",""),("Employee",""),("ETF Share Class","Exchange-traded class of a mutual fund under exemptive relief"),("Internal","Reserved for in-house fund-of-funds / mandates")]),
 "Hedging Type": ("openfunds", [("Unhedged",""),("NAV Hedged","Base currency hedged to class currency"),("Portfolio Hedged","Look-through hedge of underlying exposures"),("Duration Hedged","")]),
 "Distribution Policy": ("openfunds", [("Accumulating","Used by CITs and other non-RIC vehicles"),("Distributing","")]),
 "Distribution Payment Method": ("openfunds", [("Cash",""),("Reinvestment",""),("Investor Election","")]),
 "Investor Type": ("openfunds / US", [("Retail",""),("Institutional",""),("Accredited Investor","US Reg D"),("Qualified Purchaser","US '40 Act s.2(a)(51)")]),
 "Benchmark Usage Type": ("Internal (SEC Form N-1A)", [("No Benchmark",""),("Comparator","Broad-based index of the performance table"),("Constraint",""),("Target",""),("Index Tracking","")]),
 "Derivatives Usage": ("Prospectus", [("None",""),("Hedging Only",""),("Investment Purposes","")]),
 "Leverage Method": ("SEC Rule 18f-4", [("Relative VaR Test","VaR of the fund at most 200% of the VaR of its designated reference portfolio (250% for a closed-end fund with preferred stock outstanding)"),("Absolute VaR Test","VaR of the fund at most 20% of net assets (25% for a closed-end fund with preferred stock outstanding)"),("Not Applicable","Limited derivatives user or no derivatives")]),
 "Restriction Source": ("Internal", [("Regulatory",""),("Prospectus",""),("Client IMA",""),("Internal / House",""),("ESG Exclusion Policy","")]),
 "Restriction Category": ("Internal", [("Concentration",""),("Issuer",""),("Sector / Industry",""),("Country",""),("Credit Quality",""),("Liquidity",""),("Exclusion",""),("Instrument Type","")]),
 "Limit Type": ("Internal", [("Minimum",""),("Maximum",""),("Range",""),("Prohibition","")]),
 "Measurement Basis": ("Internal", [("% of NAV",""),("% of Market Value",""),("% of Issuer Capital",""),("Absolute Amount",""),("Count",""),("% of Total Assets","ICA Section 5(b)(1), Rule 2a-7, IRC 817(h) - Stage 3, CD-241"),("Days","Weighted average maturity or life (Rule 2a-7) - Stage 3, CD-241"),("Ratio","Asset coverage (ICA Section 18) or leverage multiple - Stage 3, CD-241"),("Rating Notch","Minimum credit quality tests - Stage 3, CD-241"),("% of Commitments","Private fund document limits on aggregate commitments - Stage 3, CD-241")]),
 "Return Type": ("Internal", [("Price Return",""),("Net Total Return",""),("Gross Total Return","")]),
 "Benchmark Role": ("Internal / openfunds", [("Primary",""),("Secondary",""),("Performance Fee Hurdle",""),("Risk / Tracking",""),("Peer Comparison",""),("Index Tracked","")]),
 "Performance Calculation Basis": ("GIPS / Internal", [("NAV-to-NAV Net of Fees",""),("Gross of Fees",""),("Time-Weighted",""),("Money-Weighted (IRR)","")]),
 "Fee Accrual Basis": ("Internal", [("Average Net Assets",""),("Committed Capital",""),("Invested Capital",""),("Fixed Fee","")]),
 "Hurdle Type": ("Advisers Act Rule 205-1 / Internal", [("Benchmark","Index of a fulcrum fee"),("Fixed Rate",""),("Cash Rate + Spread",""),("None","")]),
 "Anti-Dilution Mechanism": ("openfunds / SEC", [("Partial Swing Pricing","SEC Rule 22c-1(a)(3): swing when net flows pass the swing threshold"),("Redemption Fee (Rule 22c-2)","Fee of up to 2% payable to the fund on short-term redemptions"),("Liquidity Fee","Money market fund liquidity fee (SEC Rule 2a-7)"),("None","")]),
 "Pricing Basis": ("openfunds", [("Forward","SEC Rule 22c-1")]),
 "Pricing Model": ("openfunds", [("Single Price",""),("Single Swinging Price","")]),
 "Replication Method": ("openfunds", [("Physical - Full",""),("Physical - Optimized / Sampled",""),("Synthetic - Swap-Based",""),("Active (Non-Index)","")]),
 "Party Role Type": ("FIBO CIV / openfunds", [("Investment Manager",""),("Sub-Investment Manager","Sub-adviser (52)"),("Investment Adviser",""),("Trustee","Bank trustee of a CIT or trustee of a trust-form fund"),("Custodian",""),("Fund Administrator",""),("Transfer Agent / Registrar",""),("Auditor",""),("Legal Adviser",""),("Principal Distributor / Underwriter",""),("Placement Agent","Places feeder fund interests (CW-038)"),("Authorized Participant",""),("Market Maker",""),("Index Provider",""),("Board of Directors","")]),
 "PM Role": ("Internal", [("Lead",""),("Co-Manager",""),("Associate / Deputy","")]),
 "Distribution Channel": ("Shared list copy (steward 09; CW-164 values used by 01)", [("Direct - Self-Directed","DB line"),("Direct - Digital Advice","DA line; enrollment is 15"),("Direct - Human Advice","HA line; enrollment is 15"),("Workplace","WR line; plan menus are 16"),("Intermediary","IC line; shelf detail is 05"),("Institutional","IA line")]),
 "ESG Investment Approach": ("Internal", [("Exclusion / Negative Screening",""),("ESG Integration",""),("Best-in-Class",""),("Thematic",""),("Impact",""),("Engagement / Stewardship",""),("None","")]),
 "MMF Type": ("SEC Rule 2a-7", [("Government MMF",""),("Prime MMF - Institutional","Mandatory liquidity fee applies"),("Prime MMF - Retail",""),("Tax-Exempt MMF","")]),
 "US Fund Type": ("SEC", [("Open-End Management Company",""),("Closed-End Management Company",""),("Unit Investment Trust",""),("ETF (Rule 6c-11)",""),("Interval Fund",""),("Business Development Company","")]),
 "Document Type": ("openfunds / SEC", [("Prospectus","Statutory prospectus (Form N-1A Part A)"),("Prospectus Supplement",""),("Summary Prospectus","SEC Rule 498"),("Statement of Additional Information","Form N-1A Part B"),("Annual Report",""),("Semi-Annual Report",""),("Tailored Shareholder Report","SEC Rule 30e-1"),("Factsheet",""),("CIT Disclosure Document","Declaration of trust and fund disclosure of a bank-maintained CIT"),("Articles / Trust Deed",""),("Investment Management Agreement","")]),
 "US Tax Classification": ("IRS", [("RIC","Regulated investment company (Subchapter M)"),("Partnership",""),("Grantor Trust",""),("Corporation",""),("Group Trust","Tax-exempt group trust (Rev. Rul. 81-100), typical for CITs")]),
 "Lifecycle Event Type": ("Internal", [("Launch",""),("Soft Close",""),("Hard Close",""),("Reopen",""),("Merger",""),("Liquidation",""),("Conversion",""),("Rename",""),("Change of Objective / Policy",""),("Change of Service Provider",""),("Change of Offering Terms","Change to the features, eligibility or fee schedule of a service offering")]),
 "Business Line": ("Internal (CW-004)", [("Direct Brokerage and Self-Directed Investing","[DB]"),("Digital Advice","[DA]"),("Human and Hybrid Advice","[HA]"),("Proprietary Funds and ETFs","[PF] Including CITs"),("Workplace Retirement Recordkeeping","[WR]"),("Institutional Advisory","[IA]"),("Intermediary Channel","[IC]"),("Personal Trust Services","[TR] Optional line")]),
 "Firm Risk Rating": ("Internal", [("1 - Conservative",""),("2 - Moderately Conservative",""),("3 - Moderate",""),("4 - Moderately Aggressive",""),("5 - Aggressive",""),("Not Rated","")]),
 "Derivatives Category": ("SEC Rule 18f-4", [("No Derivatives Use",""),("Limited Derivatives User","Derivatives exposure at or below 10% of net assets; written policies instead of a program"),("Full Derivatives User","Derivatives risk management program, derivatives risk manager and VaR-based leverage limit"),("Full Derivatives User - Leveraged / Inverse","Full derivatives user that seeks a leveraged or inverse multiple of an index")]),
 "Offering Type": ("Internal", [("Digital Advice","Algorithm-driven portfolio management (robo-adviser)"),("Hybrid Advice","Digital management with access to advisors"),("Personal Advisor","Dedicated advisor managing the relationship"),("Wealth Management","Personal advisor plus planning, tax and estate services for high-net-worth clients"),("Planning Only","Financial plan without ongoing management"),("Brokerage","Self-directed brokerage service"),("Trust Services","Trustee or agent for trust accounts (TR line)"),("Workplace Managed Account","Managed account offered in a recordkept plan"),("OCIO","Outsourced chief investment officer for institutions")]),
 "Delivery Mode": ("Internal", [("Digital Only",""),("Digital with Advisor Access",""),("Dedicated Advisor",""),("Advisor Team","")]),
 "Discretion Type": ("Form ADV Part 2A", [("Discretionary",""),("Non-Discretionary",""),("Not Applicable","Self-directed or planning only")]),
 "Advisory Capacity": ("Internal", [("Investment Adviser","Advisers Act fiduciary"),("Broker-Dealer","Regulation Best Interest"),("Trust Company Fiduciary","Bank or state trust company fiduciary"),("Dual Capacity","Both capacities, stated per service")]),
 "Offering Feature Type": ("Internal", [("Automatic Rebalancing",""),("Tax-Loss Harvesting",""),("Financial Plan Included",""),("Advisor Access",""),("Custom Restrictions Allowed","Client restrictions under Rule 3a-4 (02)"),("ESG Portfolio Option",""),("Direct Indexing",""),("Tax-Aware Asset Location","")]),
 "Eligibility Criterion": ("Internal", [("Minimum Assets",""),("Account Registration Type","15 account types"),("Investor Qualification","Shared Investor Qualification Standard (02)"),("Residence State",""),("Plan Participation","Workplace plan participant (16)"),("Service Tier","Tier assigned in 02")]),
 "Comparison Operator": ("Internal", [("At Least",""),("Less Than",""),("Equal To",""),("In List",""),("Not In List","")]),
 "Fee Schedule Link Type": ("Internal", [("Standard",""),("Promotional","Applies to new enrollments within the link period")]),
 "Tier Measurement Basis": ("Internal", [("Household Client Assets","All accounts of the household (06 client assets)"),("Client Assets","Accounts of the individual client"),("Household Client Assets incl. Workplace Plan","Includes workplace plan balances")]),
 "Universe Rule Type": ("Internal", [("Universe Inclusion",""),("Fractional Eligibility",""),("Extended-Hours Eligibility","FINRA Rule 2265 disclosure applies"),("Purchase Restriction","")]),
 "Availability Status": ("Internal", [("Available",""),("Hold and Sell Only",""),("Closed to New Investors",""),("Not Available","")]),
 "Transaction Fee Category": ("Internal", [("No Transaction Fee",""),("Transaction Fee",""),("Short-Term Trading Fee Only","No transaction fee, but a fee on early redemption")]),
 "Investor Qualification Standard": ("Enterprise shared list (steward 02); US values (CW-039)", [("None Evidenced",""),("Accredited Investor","Regulation D Rule 501(a)"),("Qualified Client","Advisers Act Rule 205-3"),("Qualified Purchaser","Investment Company Act §2(a)(51)"),("Qualified Institutional Buyer","Securities Act Rule 144A")]),
 "Window Status": ("Internal", [("Scheduled",""),("Open",""),("Closed",""),("Allocated",""),("Canceled","")]),
}

# ---------------------------------------------------------------------------
# Relationships, sources
# ---------------------------------------------------------------------------
REL = [
 ("Investment Restriction","may originate from","Client Restriction (02 Client & Household, CRX-)","n : 0..1","Client-instructed exclusions are mastered in 02 and implemented as mandate guidelines here."),
 ("Investment Strategy","is implemented by","Investment Product","1 : 0..n","A strategy may be offered through many vehicles (funds, ETFs, CITs)."),
 ("Investment Strategy","is implemented by","Investment Mandate","1 : 0..n",""),
 ("Investment Strategy","is implemented by","Model Portfolio","1 : 0..n",""),
 ("Investment Strategy","is represented by","GIPS Composite","1 : 0..n","Usually one primary composite per strategy."),
 ("GIPS Composite","contains","Investment Product / Investment Mandate","1 : 0..n","Derived roll-up of 32 Composite Membership (by 18 portfolio) through 18 Portfolio Implementation Link (CD-218)."),
 ("Investment Product (Umbrella)","contains","Investment Product (Sub-fund)","1 : 1..n","Via Product Relationship."),
 ("Investment Product (Feeder)","invests in","Investment Product (Master)","n : 1","Via Product Relationship."),
 ("Investment Product","issues","Share Class","1 : 1..n","Mandates and models have no share classes."),
 ("Share Class","is identified by","Security Identifier","1 : 0..n","ISIN, CUSIP, FIGI, etc."),
 ("Share Class","is listed as","Listing","1 : 0..n","ETFs / listed closed-end funds."),
 ("Investment Product / Share Class","is assigned","Product Benchmark Assignment","1 : 0..n","Each assignment references one Benchmark and a role."),
 ("Product Benchmark Assignment","references","Benchmark","n : 1",""),
 ("Investment Product","is served by","Product Party Role","1 : 1..n","Each role references a Party (legal entity master)."),
 ("Investment Product / Mandate","is managed by","Portfolio Manager Assignment","1 : 1..n",""),
 ("Investment Product / Mandate","is constrained by","Investment Restriction","1 : 0..n",""),
 ("Share Class","is charged","Fee terms (Management, Performance, Transaction)","1 : 0..n","Fees typically vary by share class."),
 ("Investment Product / Share Class","is classified by","External Classification","1 : 0..n","Effective-dated."),
 ("Investment Product / Share Class","is described by","Product Document","1 : 0..n","By type, language and jurisdiction."),
 ("Investment Product / Share Class / Service Offering","undergoes","Lifecycle Event","1 : 0..n",""),
 ("Investment Strategy / Investment Product / Investment Mandate","is discussed in","Investment Commentary","1 : 0..n","Per period; market commentary at house-view or asset-class scope has no strategy or product."),
 ("Investment Commentary","is published as","Content Asset (04 Marketing & Digital, AST-)","1 : 0..n","Cross-domain: 04 owns the published piece; 08 reviews the asset."),
 ("Investment Commentary","is used in","Report Run (12 Institutional Client Servicing & Reporting, RRN-)","n : n","Cross-domain: commentary included in a client report."),
 ("Investment Product / Share Class","is cross-referenced by","System Cross-Reference","1 : 0..n",""),
 # Wealth-manager additions (CW-036 to CW-038)
 ("Service Offering","includes","Offering Feature","1 : 0..n",""),
 ("Service Offering","is restricted by","Offering Eligibility Rule","1 : 0..n","15 applies the rules at enrollment."),
 ("Service Offering","is priced by","Offering Fee Schedule Link","1 : 1..n","Each link references one 47 fee schedule for a period."),
 ("Offering Fee Schedule Link","references","Fee Schedule (47 Pricing, Fees & Billing)","n : 1","Cross-domain: 47 masters rates, breakpoints and billing (CW-036)."),
 ("Service Offering","implements","Model Portfolio","n : n","46 assigns one of the offering's models to each enrolled account."),
 ("Service Offering","is sponsored by","Internal Legal Entity (09 Shared & Enterprise Reference Data, LEN-)","n : 1","The RIA, the broker-dealer or the trust company."),
 ("Service Offering","is enrolled in by","Program Enrollment (15 Account, ENRL-)","1 : 0..n","Cross-domain: 15 masters the account x offering x period (CW-032)."),
 ("Service Offering","is recommended in","Recommendation (45 Financial Planning & Advice)","1 : 0..n","Cross-domain: 45 masters the recommendation and its best-interest evidence."),
 ("Service Tier","is assigned by","Service Tier Assignment (02 Client & Household)","1 : 0..n","Cross-domain: 02 assigns tiers to households or clients (CW-028)."),
 ("Tradable Universe Policy Rule","sets flags on","Instrument (17 Instrument & Issuer Reference, INS-)","1 : 0..n","Cross-domain: 17 holds each instrument's resulting flag with the TUP- rule reference (CW-037)."),
 ("Tradable Universe Policy Rule","is applied by","Client Order (48 Brokerage Orders & Execution)","1 : 0..n","Cross-domain: 48 checks orders against the rules and flags."),
 ("Platform Product Availability","makes available","Share Class / Instrument (17)","n : 1","Own share class (SHC-) or third-party fund or ETF (17 INS-)."),
 ("Platform Product Availability","is approved by","Product Due Diligence (52 External Manager & Sub-Adviser Oversight)","n : 0..1","Cross-domain: third-party products only (SME question 4)."),
 ("Platform Feature","is available to","Service Offering","n : 0..n","Eligible Offerings (CW-161)."),
 ("Platform Feature","is specified by","Platform Feature Specification (36 Product Development & Lifecycle)","1 : 0..n","Cross-domain: 36 holds proposed values only (CW-161)."),
 ("Platform Feature","is activated as","Account Feature (15 Account)","1 : 0..n","Cross-domain: 15 masters the account x feature row."),
 ("Investment Product (Feeder)","has","Feeder Access Terms","1 : 0..1","Vehicle Type Feeder Fund, Tender-Offer Fund or Interval Fund."),
 ("Feeder Access Terms","invests in","Instrument (17 Instrument & Issuer Reference, INS-)","n : 0..1","The underlying private fund interest of a Feeder Fund (one); none for an interval or tender-offer fund that is itself the vehicle. Its manager is reviewed in 52."),
 ("Investment Product (Feeder)","is offered in","Offering Window","1 : 0..n",""),
 ("Offering Window","receives","Alternative Investment Subscription (15 Account, AISB-)","1 : 0..n","Cross-domain: 15 masters the subscription; 49 holds the resulting client holding (CW-035, CW-038)."),
 ("Share Class (Money Market Fund)","is used as","Sweep Election (15 Account)","1 : 0..n","Cross-domain: money market sweep funds are 01 share classes; the bank sweep program is 50 (CW-016)."),
]

SRC = [
 ("FIBO - Collective Investment Vehicles (CIV)","EDM Council","https://spec.edmcouncil.org/fibo/","Open (MIT license)","Ontology of funds, umbrellas, share classes, legal forms and fund roles","Conceptual backbone: Product, Legal Structure, Share Class, Party Roles, Product Relationships"),
 ("openfunds","openfunds Association","https://www.openfunds.org","Free open standard","Governed dictionary of fund and share-class data fields (static, dealing, fees, documents); market-neutral fields only","Primary attribute dictionary for Product, Share Class, Fees, Dealing, Documents"),
 ("ISO 6166 (ISIN) / ISO 10962 (CFI) / ISO 18774 (FISN)","ISO; ANNA","https://www.anna-web.org","Standard (ISO purchase); codes via NNAs","Instrument identification and classification","Global Identifiers, Regulatory Classification"),
 ("ISO 17442 (LEI)","ISO; GLEIF","https://www.gleif.org","Open data (GLEIF)","Legal entity identification","Fund LEI, Party LEI"),
 ("ISO 4217 / ISO 3166 / ISO 10383 / ISO 639 / ISO 8601","ISO","https://www.iso.org","Standard; code lists widely available","Currency, country, market (MIC), language and date/time codes","Reference code lists used throughout"),
 ("OpenFIGI","Object Management Group / Bloomberg","https://www.openfigi.com","Open","Financial Instrument Global Identifier","Global Identifiers"),
 ("GIPS Standards","CFA Institute","https://www.gipsstandards.org","Free","Composite definition and performance presentation","Strategy, GIPS Composite, Performance Reference"),
 ("Morningstar Category / Global Category","Morningstar","https://www.morningstar.com","Licensed","Peer-group categories","External Classification"),
 ("Lipper Global Classification","LSEG","https://www.lseg.com","Licensed","Peer-group categories","External Classification"),
 ("ICI Investment Classifications","Investment Company Institute (US)","https://www.ici.org","Free","US fund categories and industry definitions","External Classification, Asset Class alignment, US vehicle definitions"),
 ("SEC Form N-1A and EDGAR series/class IDs","US SEC","https://www.sec.gov/files/formn-1a.pdf","Regulation","Registration form of open-end funds: fee table (Item 3, including acquired fund fees and expenses), risk and performance (Item 4), management (Item 5), share classes and sales loads (Items 12, 18); series and class identifiers","Fees, Cost Disclosure, Benchmark Usage, Regulatory Filing Identifier, US Fund Type"),
 ("SEC Rule 498 (summary prospectus) and Rule 30e-1 (tailored shareholder reports)","US SEC","https://www.ecfr.gov/current/title-17/section-230.498","Regulation","Summary prospectus and annual and semi-annual shareholder reports of registered funds","Product Document"),
 ("Investment Company Act rules: 2a-7, 6c-11, 12d1-4, 18f-4, 22c-1, 22c-2, 35d-1, 3a-4","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270","Regulation","Money market funds, ETFs, funds of funds, derivatives and leverage, forward pricing and swing pricing, redemption fees, fund names, advisory program safe harbor","MMF Type, ETF Characteristics, Derivatives Risk Category, Leverage Method, Dealing, Anti-Dilution, ESG Term in Name, Service Offering"),
 ("Investment Company Act of 1940 (§2(a)(51), §3(c)(1), §3(c)(7), §12(d)(1), §15(a), §18(f))","US Congress / SEC","https://www.law.cornell.edu/uscode/text/15/chapter-2D/subchapter-I","Statute","Registration, private fund exclusions, master-feeder, advisory contracts, senior securities and borrowing","Regulatory Regime, Master-Feeder Role, Maximum Borrowing, Feeder Access Terms"),
 ("Investment Advisers Act §205(b) and Rules 205-1, 205-2 and 205-3; Form ADV Part 2A and Appendix 1","US SEC","https://www.ecfr.gov/current/title-17/section-275.205-1","Regulation","Fulcrum fees of registered funds and their measurement period, incentive fees of qualified-client funds, wrap fee program brochure","Performance Fee, Service Offering"),
 ("Regulation Best Interest (Exchange Act Rule 15l-1)","US SEC","https://www.ecfr.gov/current/title-17/section-240.15l-1","Regulation","Broker-dealer standard of conduct for recommendations to retail customers","Advisory Capacity, Firm Risk Rating"),
 ("SEC IM Guidance Update No. 2017-02 (Robo-Advisers)","US SEC Division of Investment Management","https://www.sec.gov/investment/im-guidance-2017-02.pdf","Guidance","Disclosure, suitability and compliance expectations for automated advisory programs","Offering Type, Offering Feature"),
 ("OCC 12 CFR 9.18 (collective investment funds)","US Office of the Comptroller of the Currency","https://www.ecfr.gov/current/title-12/chapter-I/part-9/section-9.18","Regulation","Bank-maintained collective investment funds (CITs)","Regulatory Regime, Legal Form, Document Type"),
 ("FINRA Rules 2341 and 2265; NASD Notice to Members 05-26","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules","SRO rules","Investment company securities and sales charges, extended-hours trading risk disclosure; new product vetting","Investor Transaction Charge, Tradable Universe Policy Rule, Product Governance"),
 ("Regulation D Rule 506 and Rule 501(a)","US SEC","https://www.ecfr.gov/current/title-17/section-230.506","Regulation","Private placement of feeder fund interests to accredited investors","Feeder Access Terms, Investor Qualification Standard"),
 ("SEC Rule 35d-1 (fund names)","US SEC","https://www.ecfr.gov/current/title-17/section-270.35d-1","Regulation","80% investment policy for fund names, including ESG terms","ESG Classification"),
 ("IOSCO Principles for Financial Benchmarks","IOSCO","https://www.iosco.org","Principles","Benchmark governance and administrator accountability","Benchmark"),
 ("Vendor wealth platform models (Morningstar Direct, Envestnet, Orion)","Commercial vendors","Vendor-provided","Proprietary / licensed","Advisory program, model and platform availability structures","Cross-check for Advice & Service Offerings and Brokerage Platform Offering; not a primary source"),
 ("Vendor EDM models (GoldenSource, S&P EDM, SimCorp, Aladdin)","Commercial vendors","Vendor-provided","Proprietary / licensed","Security- and fund-master data models","Optional cross-check during implementation; not used as primary source"),
]


_SRC_KEYS = {
 "FIBO": ["FIBO*"], "openfunds": ["openfunds"],
 "ISO 6166": ["ISO 6166*", "ISO 10962", "ISO 18774"], "ISO 17442": ["ISO 17442*"], "ISO 4217": ["ISO 10383"],
 "OpenFIGI": ["OMG FIGI*"], "GIPS": ["GIPS"], "Morningstar": ["Morningstar"], "Lipper": ["LSEG Lipper"],
 "ICI": ["ICI"], "SEC Form N-1A": ["SEC Form N-1A", "SEC EDGAR"], "SEC Rule 498": ["SEC Rule 498", "SEC Rule 30e-1"],
 "Investment Company Act rules": ["SEC Rule 2a-7", "SEC Rule 6c-11", "SEC Rule 12d1-4", "SEC Rule 18f-4", "SEC Rule 22c-1*",
                                  "SEC Rule 22c-2", "Investment Company Act Rule 3a-4", "SEC exemptive relief*"],
 "Investment Company Act of 1940": ["Investment Company Act*"], "Investment Advisers Act": ["Advisers Act*", "Form ADV*", "Investment Advisers Act*"],
 "Regulation Best Interest": ["Exchange Act Rule 15l-1"], "SEC IM Guidance": ["SEC IM Guidance*"], "OCC": ["OCC*"],
 "FINRA": ["FINRA*"], "Regulation D": ["Regulation D*"], "SEC Rule 35d-1": ["SEC Rule 35d-1"], "IOSCO": ["IOSCO*"],
}
SRC = [tuple(s) + (next((v for k, v in _SRC_KEYS.items() if s[0].startswith(k)), []),) for s in SRC]
