"""Data Domain 02 - Client & Household (wealth-manager reference model; replaces the wholesale 02 Client & Customer, CW-005).
Content module for taxonomy_builder.py."""

META = {
 "title": "Client & Household Data Taxonomy",
 "subtitle": "Business domain 02 - Client & Household | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "02_Client_and_Household/Client_and_Household_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the client master of a US wealth manager that serves investors directly: self-directed brokerage, digital and human advice, its own mutual funds and ETFs, workplace retirement recordkeeping, institutional advisory, a thin intermediary channel and optional personal trust services. The domain masters who each client is, who acts for them, who they live and plan with, what they have told the firm about their finances, objectives and risk tolerance, how their identity was verified, what they have agreed to about their data, and the protections that apply to them. It also keeps the party core for every other external party (sub-advisers, brokers, vendors, plan sponsors, intermediary firms) under CD-143. It is stitched together from FINRA Rules 4512, 2090, 2111, 2165 and 3210, SEC Rule 17a-3(a)(17), Regulation Best Interest, Investment Company Act Rule 3a-4, the Bank Secrecy Act CIP and beneficial ownership rules (31 CFR 1023.220, 1024.220, 1020.220 and 1010.230), Regulations S-P and S-AM, the CCPA/CPRA, IRS Forms W-9 and W-8, GLEIF and ISO party standards, and the Salesforce Financial Services Cloud household model as a cross-check. Use it as a starting point for a client master, CRM and onboarding data model, CIP and CDD record design, a consent platform or a business glossary."),
  ("Scope", "In scope: the party core for every external party (party, individual, organization, legal entity hierarchy, party roles, identifiers including CRD, LEI and NSCC numbers) and a thin Retirement Plan identity; Client Households as parties of type Household with effective-dated membership and party relationships; authority grants (powers of attorney, trading authorizations, guardians, conservators, executors, entity signers), trusted contact designations and death notifications; the versioned investor profile, investment experience and investor qualification; onboarding cases, KYC profiles, identity verification for every CIP program, beneficial ownership certifications and owners, and the party tax profile; regulatory classification, segmentation and service tier assignment; contact points, postal addresses and contact and communication preferences; privacy profile, consent records and consumer privacy requests under Reg S-P, Reg S-AM, the GLBA and state law; client restrictions, restricted client status, specified adult status and vulnerability concerns. Out of scope (referenced by ID): accounts, account roles, beneficiary designations, account investment profiles, account restrictions and tax certifications (15 Account); service tiers and offerings (01 Investment Product & Service Offering); goals, plans and recommendations (45 Financial Planning & Advice, W2); client holdings and client assets (49 and 06); fee households (47); mailing households, e-delivery elections, privacy notice delivery and service requests (13); subscriptions and digital identity (04); the AML program and cases (38); money movement holds (50); trust terms (51); employees (20); internal legal entities and countries (09); models (37). Role profiles of intermediary firms, advisors, consultants, institutional clients and recordkeepers are not here (05, 12 and 16, CW-023)."),
  ("Structure", "Four levels: Data Domain > Data Family > Data Business Object > Data Business Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Party (PTY-; households PTY-HH-) is described by Individual, Organization or the thin Retirement Plan, plays effective-dated Party Roles and carries Party Identifiers (LEI Record, US Regulatory Identifier, Market Infrastructure & Vendor Identifier). Entities link through Legal Entity Hierarchy. A Client Household (Household attribute group of a Household party) groups members through Household Membership; Party Relationship records spouse, guardian, trustee, executor and control-person links. Authority Grant (AGNT-) gives a holder authority over a grantor's affairs and names the accounts covered (15 ACC-); Trusted Contact Designation (TCNT-) names the person the firm may call under FINRA Rule 2165; Death Notification starts estate handling. Investor Profile (INPR-) is versioned per client with Investment Experience by product type; Investor Qualification records accredited investor, qualified client and qualified purchaser determinations. Onboarding Case (ONB-) produces the KYC Profile, one Identity Verification (KYCV-) per CIP program and, for legal entity customers, a Beneficial Ownership Certification (BOWN-) listing Beneficial Ownership rows; the Tax Profile holds US person status, classification and the masked TIN. Regulatory Classification, Segment Assignment and Service Tier Assignment (tier defined in 01) classify the client. Contact Point (CTP-) with Postal Address, Contact Preference and Communication Preference say how to reach the client; Privacy Profile, Consent Record (CNS-) and Consumer Privacy Request hold privacy choices. Client Restriction (CRX-), Restricted Client Status, Specified Adult Status and Vulnerability Concern hold restrictions and protections."),
  ("Design principles", "1) One party, many roles: a client, a trusted contact, a beneficiary and a sub-adviser are all parties; never duplicate a party because it plays a second role (CD-143). 2) Client facts on the party, account facts on the account (CW-024): no account number, registration type, Client Holding (49) or balance is mastered here; 15 references the profile version it was set against. 3) One identity verification per party per CIP program, sharing evidence (CW-025). 4) Three household concepts stay distinct (CW-027): Client Household (02), Mailing Household (13 MHG-), Fee Household (47). 5) Roles here, profiles with the role's owner (CW-023). 6) Effective-date roles, memberships, relationships, grants, designations, classifications and assignments; version the investor profile. 7) Personal data is pervasive: every object states its PII tier (identity, financial, special category, or no PII); government identifiers and dates of birth are masked; specified adult status and vulnerability concerns are special category (CD-344) and restricted to service, advice and compliance. 8) Flag Critical Data Elements (CDE)."),
  ("Applies To", "Shows the record each attribute belongs to: Party, Individual, Organization, Legal Entity Hierarchy, Party Role, Retirement Plan, Party Identifier, LEI Record, US Regulatory Identifier, Market Participant, Household, Household Membership, Party Relationship, Authority Grant, Trusted Contact Designation, Death Notification, Investor Profile, Investment Experience, Investor Qualification, Onboarding Case, KYC Profile, Identity Verification, Beneficial Ownership Certification, Beneficial Ownership, Tax Profile, Regulatory Classification, Segment Assignment, Service Tier Assignment, Contact Point, Postal Address, Contact Preference, Communication Preference, Privacy Profile, Consent Record, Consumer Privacy Request, Client Restriction, Restricted Client Status, Specified Adult Status or Vulnerability Concern."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify and match a party, verify identity under a CIP program, meet the customer-record and suitability obligations (FINRA Rule 4512, SEC Rule 17a-3(a)(17), Reg BI), honor an authority, trusted contact or privacy choice, or apply a restriction or protection. Confirm with data owners."),
  ("Primary / Secondary Reference", "Standard or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Vendor and CRM models (Salesforce FSC, FDX) are cross-checks, not a license to reproduce their schemas. Next step: map each attribute to the exact rule paragraph, form line or onboarding screen field."),
  ("Notes", "PII = personal data under the GLBA, Regulation S-P and US state privacy laws. Each object's PII tier is stated in the Notes of its first attribute: 'PII - identity', 'PII - financial', 'PII - special category (CD-344)' or 'No PII'. 'Restricted' marks government identifiers, document numbers and dates of birth: hold masked, with access controls."),
  ("Tabs", "Hierarchy: families, object groups and objects with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: object-level cardinalities, including references to other Data Domains | Sources: standards used, owners, licenses and links."),
  ("Suggested next steps", "1) Validate families, objects and CDEs with Client Onboarding, Client Service, the advice teams, AML and KYC Operations, Privacy, Senior Investor Protection and Data Management. 2) Agree the household rule of record (client-defined with system suggestions held as unconfirmed memberships) with 13 and 47. 3) Agree with 15 the reference from Account Investment Profile, Account Opening and options and margin approvals to the investor profile version and identity verification. 4) Agree with 29 the W3 re-cut of CIP Verification to a reference to Identity Verification. 5) Map attributes to the CRM and client master, the onboarding and CIP tool, the risk questionnaire, the consent platform and the privacy request tool. 6) Confirm which state privacy laws apply and how GLBA-covered data is flagged. 7) Turn the Relationships tab into a logical client data model."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Party Master", "HH-PTY",
  "The golden record for every external party the firm deals with, whether a client, a person related to a client, a household, an entity or a counterparty, together with the effective-dated roles each party plays (CD-143, CW-005).",
  [
   ("Party Core", "Identity and lifecycle attributes common to every external party: clients and prospects, related persons, Client Households, entities and the organizations the firm deals with.", [
     ("Party", [
       ("Party ID", "Unique, permanent internal identifier of the party; never reused and kept after a merge as a pointer to the surviving record. Client Households take the sub-type PTY-HH- (CW-005).", "Party", "Identifier", "", "PTY-104588", "Internal", "FIBO BE", "Y", "Object PII tier: PII - identity (individual and household parties; an organization party holds no personal data). PII when the party is an individual."),
       ("Party Type", "Legal form class of the party: an individual, a household (individuals and entities planned and served together) or a kind of entity.", "Party", "Code", "Party Type", "Individual", "FIBO BE", "Salesforce FSC", "Y", "PII."),
       ("Party Display Name", "Name used to address and display the party in client websites, statements and service tools; built from the legal or preferred name of an individual, the legal name of an entity or the household name.", "Party", "Text", "", "Jordan Example", "Internal", "Salesforce FSC", "", "PII when the party is an individual or household."),
       ("Party Status", "Lifecycle status of the party record.", "Party", "Code", "Party Status", "Active", "Internal", "BIAN", "", "PII."),
       ("Relationship Stage", "Stage of the party's relationship with the firm as a whole: prospect, applicant, client, former client, or a related party or counterparty that is not a client.", "Party", "Code", "Relationship Stage", "Client", "Internal", "Salesforce FSC", "Y", "PII."),
       ("Party Origin", "Channel or source through which the party record was created.", "Party", "Code", "Party Origin", "Workplace Plan Enrollment", "Internal", "", "", "PII."),
       ("Merged Into Party", "Surviving party record where this record was found to be a duplicate and merged.", "Party", "Reference (Party)", "", "PTY-100212", "Internal", "", "", "Supports the de-duplication audit trail. PII when the party is an individual."),
       ("Primary Country", "Country of residence (individual) or domicile (entity) used for regulatory, tax and privacy scoping; a foreign country is allowed where US law permits the relationship.", "Party", "Code", "ISO 3166-1 alpha-2", "US", "ISO 3166", "", "", "PII when the party is an individual."),
       ("Employee Cross-Reference", "Employee record of a party who is also an employee of the firm or an affiliate, used for employee-account surveillance and employee pricing. The employee is mastered in 20.", "Party", "Reference (Employee)", "", "EMP-01234", "FINRA Rule 3210", "Internal", "", "PII (employee identifier)."),
     ]),
   ]),
   ("Individual", "Personal attributes of natural persons: clients, joint owners, minors and custodians, trusted contacts, agents, beneficiaries and the individuals behind entities.", [
     ("Individual", [
       ("Given Name", "Legal first name of the individual as shown on the identity document used for verification.", "Individual", "Text", "", "Jordan", "FINRA Rule 4512", "31 CFR 1023.220", "Y", "Object PII tier: PII - identity. PII."),
       ("Family Name", "Legal surname of the individual.", "Individual", "Text", "", "Example", "FINRA Rule 4512", "31 CFR 1023.220", "Y", "PII."),
       ("Preferred Name", "Name the individual prefers to be addressed by in service and advice conversations, where it differs from the legal given name.", "Individual", "Text", "", "Jo", "Internal", "Salesforce FSC", "", "PII."),
       ("Date of Birth", "Date of birth, required for CIP, for the legal-age check and for age-based rules such as custodial account termination, specified adult status and required minimum distributions.", "Individual", "Date", "ISO 8601", "****-**-14 (masked)", "31 CFR 1023.220", "SEC Rule 17a-3", "Y", "PII - identity (restricted). Mask in examples and displays."),
       ("Citizenship Countries", "Countries of which the individual is a citizen; drives US person status and the identity documents accepted for CIP.", "Individual", "Code (multi)", "ISO 3166-1 alpha-2", "US", "31 CFR 1023.220", "IRS Form W-8BEN", "", "PII."),
       ("Marital Status", "Marital status as stated by the individual; drives spousal consent, community property and joint investor profile questions.", "Individual", "Code", "Marital Status", "Married", "Internal", "Salesforce FSC", "", "PII."),
       ("Employment Status", "Employment status as stated by the individual on the account application.", "Individual", "Code", "Employment Status", "Employed", "SEC Rule 17a-3", "FINRA Rule 4512", "", "PII."),
       ("Occupation", "Occupation of the individual as stated on the account application.", "Individual", "Text", "", "Mechanical engineer", "FINRA Rule 4512", "SEC Rule 17a-3", "", "PII."),
       ("Employer Name", "Name of the individual's employer, collected for non-institutional customers.", "Individual", "Text", "", "Harbor Manufacturing Co.", "FINRA Rule 4512", "", "", "PII."),
       ("Associated Person Disclosure Indicator", "Whether the individual is associated with or employed by another FINRA member, broker-dealer or investment adviser, which triggers the notice, consent and duplicate-statement duties for accounts at other firms. Moved from 15 Account Registration Detail as a party fact.", "Individual", "Boolean", "", "N", "FINRA Rule 3210", "SEC Rule 17a-3", "Y", "PII."),
       ("Date of Death", "Confirmed date of death, set once the death certificate has been received under a Death Notification.", "Individual", "Date", "ISO 8601", "2026-08-30", "Internal", "", "Y", "PII."),
     ]),
   ]),
   ("Organization", "Legal and descriptive attributes of entity parties (trusts, estates, corporations, partnerships and LLCs, retirement plans, nonprofits, government bodies and financial institutions), aligned to FIBO and the GLEIF Level 1 record.", [
     ("Organization", [
       ("Legal Name", "Registered legal name of the entity as shown on its formation documents, trust agreement or court appointment.", "Organization", "Text", "", "Example Family Revocable Trust dated 2019-06-01", "GLEIF LEI-CDF", "FIBO BE", "Y", "Object PII tier: No PII (a trust or estate name that contains an individual's name is PII)."),
       ("Legal Form", "Legal form of the entity coded to the ISO 20275 Entity Legal Form list.", "Organization", "Code", "ISO 20275", "Limited Liability Company (Delaware ELF code)", "ISO 20275", "GLEIF LEI-CDF", "", ""),
       ("Legal Jurisdiction", "State or country under whose law the entity is formed or the trust is governed.", "Organization", "Code", "ISO 3166-2", "US-DE", "GLEIF LEI-CDF", "FIBO BE", "", ""),
       ("Industry Classification", "NAICS code of the entity's business, used in customer due diligence risk rating.", "Organization", "Code", "External (NAICS)", "523920 - Portfolio Management", "US Census NAICS", "", "", ""),
       ("Primary Regulator", "Financial regulators that supervise the entity, where it is a regulated financial institution.", "Organization", "Code (multi)", "Regulator", "SEC; FINRA", "FIBO FBC", "", "", ""),
       ("Legal Entity Customer Exclusion Basis", "Why the entity is excluded from the legal entity customer definition, or is subject to the control prong only, under the beneficial ownership rule; 'Not Excluded' when a certification is required.", "Organization", "Code", "Legal Entity Customer Exclusion Basis", "Not Excluded", "31 CFR 1010.230", "", "Y", ""),
     ]),
     ("Legal Entity Hierarchy", [
       ("Subsidiary Party", "Entity whose parent is recorded.", "Legal Entity Hierarchy", "Reference (Party)", "", "PTY-100780", "GLEIF LEI-CDF", "FIBO BE", "", "Object PII tier: No PII."),
       ("Direct Parent", "Entity that directly consolidates or controls the subsidiary.", "Legal Entity Hierarchy", "Reference (Party)", "", "PTY-100050", "GLEIF LEI-CDF", "FIBO BE", "", "GLEIF Level 2 'who owns whom' where available."),
       ("Ultimate Parent", "Highest-level entity that consolidates the subsidiary, as published in GLEIF Level 2 or determined by the firm; used for entity client grouping and counterparty exposure.", "Legal Entity Hierarchy", "Reference (Party)", "", "PTY-100001", "GLEIF LEI-CDF", "FIBO BE", "", "GLEIF Level 2 ultimate parent where available."),
       ("Parent Relationship Basis", "Basis on which the parent relationship is asserted.", "Legal Entity Hierarchy", "Code", "Parent Relationship Basis", "Accounting Consolidation", "GLEIF LEI-CDF", "", "", ""),
       ("Hierarchy Effective From", "Date the parent relationship began.", "Legal Entity Hierarchy", "Date", "ISO 8601", "2021-01-01", "GLEIF LEI-CDF", "", "", ""),
       ("Hierarchy Effective To", "Date the parent relationship ended (sale, merger, dissolution).", "Legal Entity Hierarchy", "Date", "ISO 8601", "", "GLEIF LEI-CDF", "", "", ""),
     ]),
   ]),
   ("Party Role", "The effective-dated roles a party plays with the firm. A party holds many roles at once (CD-143); the profiles that go with intermediary, consultant, institutional and recordkeeper roles live with the role's owner (CW-023).", [
     ("Party Role", [
       ("Role Party", "Party playing the role.", "Party Role", "Reference (Party)", "", "PTY-104588", "FIBO BE", "", "Y", "Object PII tier: PII - identity (when the party is an individual). PII when the party is an individual."),
       ("Role Type", "Role the party plays, for example client, prospect, trusted contact, authorized agent, beneficiary, plan sponsor, external financial advisor, executing broker or supplier.", "Party Role", "Code", "Party Role Type", "Client", "FIBO BE", "BIAN", "Y", "PII."),
       ("Role Status", "Status of the party in this role.", "Party Role", "Code", "Record Status", "Active", "Internal", "", "", "PII."),
       ("Role Business Line", "Business lines in which the party holds the role (CW-004).", "Party Role", "Code (multi)", "Business Line", "DB; HA", "Internal", "", "", "PII."),
       ("Role Effective From", "Date the party began playing the role.", "Party Role", "Date", "ISO 8601", "2014-03-17", "Internal", "", "", "PII."),
       ("Role Effective To", "Date the party stopped playing the role.", "Party Role", "Date", "ISO 8601", "", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Retirement Plan", "Thin identity of an employer retirement plan as an entity party, kept so that 15 and 16 references resolve. Plan provisions, membership, assets, participant counts and filings are 16 (CW-023).", [
     ("Retirement Plan", [
       ("Plan Name", "Name of the plan as reported on Form 5500.", "Retirement Plan", "Text", "", "Harbor Manufacturing 401(k) Savings Plan", "DOL Form 5500", "", "", "Object PII tier: No PII."),
       ("Plan Number", "Three-digit plan number assigned by the sponsor; with the sponsor EIN it identifies the plan.", "Retirement Plan", "Identifier", "", "001", "DOL Form 5500", "", "Y", ""),
       ("Plan Type", "Type of retirement plan.", "Retirement Plan", "Code", "Retirement Plan Type", "401(k)", "DOL Form 5500", "ERISA", "Y", ""),
       ("Plan Sponsor", "Employer or organization that sponsors the plan.", "Retirement Plan", "Reference (Party)", "", "PTY-301120", "DOL Form 5500", "ERISA", "", ""),
       ("Sponsor EIN", "EIN of the plan sponsor as reported on Form 5500 line 2b; the plan key carries the value held as the sponsor's Employer Identification Number.", "Retirement Plan", "Identifier", "", "**-***2378 (masked)", "DOL Form 5500", "IRS", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Party Identifiers", "HH-PID",
  "Regulatory, market-infrastructure and vendor identifiers used to recognize parties across registers, systems and counterparties. Party Identifier is the master register; the attributes of LEI Record, US Regulatory Identifier and Market Infrastructure & Vendor Identifier are typed views of the party's current active Party Identifier row of each scheme, not second copies. Social Security numbers and other taxpayer identification numbers are not identifiers here: the masked TIN is held once, on the Tax Profile.",
  [
   ("Identifier Register", "Generic, effective-dated store of every identifier held for a party.", [
     ("Party Identifier", [
       ("Identified Party", "Party the identifier belongs to.", "Party Identifier", "Reference (Party)", "", "PTY-100780", "ISO 20022", "", "", "Object PII tier: PII - identity (identifiers of individuals, such as an individual CRD number, are personal data). PII when the party is an individual."),
       ("Identifier Value", "The identifier as issued by its scheme.", "Party Identifier", "Identifier", "", "5493004SXGJ8KJ3TQR56", "ISO 20022", "", "Y", "PII when the party is an individual."),
       ("Identifier Scheme", "Scheme or register that issued the identifier.", "Party Identifier", "Code", "Identifier Scheme", "LEI", "ISO 20022", "FIBO FBC", "Y", "PII."),
       ("Identifier Status", "Whether the identifier is currently valid.", "Party Identifier", "Code", "Identifier Status", "Active", "Internal", "", "", "PII."),
       ("Identifier Effective From", "Date the identifier was issued or first applied to the party.", "Party Identifier", "Date", "ISO 8601", "2018-05-02", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Legal Entity Identifier", "LEI and selected GLEIF Level 1 reference data for entity parties.", [
     ("LEI Record", [
       ("LEI", "20-character Legal Entity Identifier of the entity.", "LEI Record", "Identifier", "ISO 17442", "5493004SXGJ8KJ3TQR56", "ISO 17442 (GLEIF)", "ISO 20022", "Y", "Object PII tier: No PII."),
       ("LEI Registration Status", "Status of the LEI registration in the Global LEI System.", "LEI Record", "Code", "LEI Registration Status", "Issued", "GLEIF LEI-CDF", "", "", ""),
       ("Registration Authority ID", "GLEIF Registration Authority code of the business register that holds the entity.", "LEI Record", "Code", "External (GLEIF RA list)", "RA000602", "GLEIF LEI-CDF", "FIBO FBC", "", ""),
     ]),
   ]),
   ("US Regulatory Identifiers", "Identifiers issued by US regulators, self-regulatory organizations and the IRS to organizations and registered individuals.", [
     ("US Regulatory Identifier", [
       ("Firm CRD Number", "FINRA Central Registration Depository number of a broker-dealer or investment adviser firm.", "US Regulatory Identifier", "Identifier", "", "0000001 (fictitious)", "FINRA CRD", "SEC Form ADV", "Y", "Object PII tier: PII - identity (individual CRD and NPN numbers of external advisors)."),
       ("Individual CRD Number", "FINRA CRD number of an external registered representative or investment adviser representative.", "US Regulatory Identifier", "Identifier", "", "0000002 (fictitious)", "FINRA CRD", "FINRA BrokerCheck", "", "PII."),
       ("SEC File Number", "SEC file number of a registered investment adviser (801-) or broker-dealer (8-).", "US Regulatory Identifier", "Identifier", "", "801-112345", "SEC Form ADV", "SEC Form BD", "", "PII."),
       ("National Producer Number", "NIPR National Producer Number of a licensed insurance producer.", "US Regulatory Identifier", "Identifier", "", "17654321", "NIPR", "", "", "PII."),
       ("Employer Identification Number", "IRS EIN of a US organization; it is the organization's TIN, so the Tax Profile does not repeat it, and with the plan number it keys a retirement plan.", "US Regulatory Identifier", "Identifier", "", "**-***4512 (masked)", "IRS", "DOL Form 5500", "Y", "PII."),
     ]),
   ]),
   ("Market Infrastructure & Vendor Identifiers", "Identifiers used in clearing, settlement and fund processing networks and by data vendors; 29 and 49 read them.", [
     ("Market Infrastructure & Vendor Identifier", [
       ("NSCC Participant Number", "NSCC participant number of a broker-dealer or bank used in Fund/SERV, Networking and CNS.", "Market Participant", "Identifier", "", "0457", "DTCC / NSCC", "", "", "Object PII tier: No PII."),
       ("DTC Participant Number", "DTC participant number used for book-entry settlement and account transfers.", "Market Participant", "Identifier", "", "0226", "DTCC / NSCC", "", "", ""),
       ("Transfer Agent Dealer Number", "Dealer number assigned by the funds' transfer agent to an intermediary firm; key for matching intermediary fund orders to the firm.", "Market Participant", "Identifier", "", "D-004512", "DTCC / NSCC", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Households & Relationships", "HH-REL",
  "Client Households (CW-027), their effective-dated membership and the relationships between parties (spouse, parent, trustee, grantor, control person, subsidiary). A Party Relationship is the family or legal tie; it is never a substitute for an Authority Grant, which masters the authority to act, nor for a 15 Account Party Role, which records the capacity in which a party is on an account.",
  [
   ("Client Household", "The Client Household: a party of type Household (PTY-HH-) grouping individuals and entities whose finances are planned and served together. It is not the 13 Mailing Household (MHG-) used for document householding, nor the 47 Fee Household used for breakpoints.", [
     ("Household", [
       ("Household Name", "Display name of the Client Household.", "Household", "Text", "", "Example Household", "Salesforce FSC", "", "", "Object PII tier: PII - identity. PII."),
       ("Household Formation Basis", "Who formed the Client Household; the client-defined grouping governs, and system suggestions stay unconfirmed until the client agrees.", "Household", "Code", "Household Formation Basis", "Client Defined", "Internal", "Salesforce FSC", "", "PII."),
       ("Primary Member", "Member designated as the household's primary contact.", "Household", "Reference (Party)", "", "PTY-104588", "Salesforce FSC", "", "", "PII."),
       ("Membership Last Confirmed Date", "Date the client last confirmed who belongs to the household.", "Household", "Date", "ISO 8601", "2026-04-02", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Household Membership", "Effective-dated membership of parties in Client Households.", [
     ("Household Membership", [
       ("Household", "Client Household the member belongs to.", "Household Membership", "Reference (Party)", "", "PTY-HH-55012", "Salesforce FSC", "", "Y", "Object PII tier: PII - identity. PII."),
       ("Household Member", "Individual or entity party that belongs to the household.", "Household Membership", "Reference (Party)", "", "PTY-104588", "Salesforce FSC", "", "Y", "PII."),
       ("Household Member Role", "Role of the member in the household.", "Household Membership", "Code", "Household Member Role", "Spouse / Domestic Partner", "Salesforce FSC", "", "", "PII."),
       ("Membership Status", "Whether the membership is confirmed by the client (Active), suggested by the system and not yet confirmed (Proposed) or ended (Inactive).", "Household Membership", "Code", "Record Status", "Active", "Internal", "", "", "PII."),
       ("Membership Effective From", "Date the party joined the household.", "Household Membership", "Date", "ISO 8601", "2019-06-01", "Internal", "", "Y", "PII."),
       ("Membership Effective To", "Date the party left the household.", "Household Membership", "Date", "ISO 8601", "", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Party Relationships", "Typed, effective-dated relationships between two parties.", [
     ("Party Relationship", [
       ("From Party", "Party at the 'from' end of the relationship.", "Party Relationship", "Reference (Party)", "", "PTY-104611", "Salesforce FSC", "FIBO BE", "", "Object PII tier: PII - identity (relationships between individuals reveal family structure). PII."),
       ("To Party", "Party at the 'to' end of the relationship.", "Party Relationship", "Reference (Party)", "", "PTY-104588", "Salesforce FSC", "FIBO BE", "", "PII."),
       ("Relationship Type", "Nature of the relationship, read from the 'from' party to the 'to' party.", "Party Relationship", "Code", "Party Relationship Type", "Spouse Of", "Salesforce FSC", "BIAN", "Y", "PII."),
       ("Relationship Effective From", "Date the relationship began.", "Party Relationship", "Date", "ISO 8601", "2012-09-15", "Internal", "", "", "PII."),
       ("Relationship Effective To", "Date the relationship ended.", "Party Relationship", "Date", "ISO 8601", "", "Internal", "", "", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Authorized Persons & Life Events", "HH-AUT",
  "Who may act for a client and whom the firm may contact about them (CW-026): authority grants, trusted contact designations, and the death notifications that start estate handling. The persons are 02 parties; beneficiary designations are 15 account facts. Authority Grant is the only master of authority to act (guardian, conservator, executor, attorney-in-fact, signer); Party Relationship holds the family or legal tie and 15 Account Party Role the registration capacity.",
  [
   ("Authority Grants", "Authority one party grants another, or a court confers, to act on a party's affairs and accounts: powers of attorney, trading authorizations, guardianships, conservatorships, executorships and entity signing authority.", [
     ("Authority Grant", [
       ("Authority Grant ID", "Unique identifier of the authority grant.", "Authority Grant", "Identifier", "", "AGNT-0004512", "Internal", "", "Y", "Object PII tier: PII - identity."),
       ("Grantor Party", "Party granting the authority, or whose affairs a guardian, conservator or executor manages.", "Authority Grant", "Reference (Party)", "", "PTY-104588", "Internal", "", "Y", "PII."),
       ("Authority Holder", "Party who holds the authority: attorney-in-fact, agent, guardian, conservator, executor or authorized signer.", "Authority Grant", "Reference (Party)", "", "PTY-104611", "Internal", "", "Y", "PII."),
       ("Authority Type", "Kind of authority granted.", "Authority Grant", "Code", "Authority Type", "Durable Power of Attorney", "Uniform Power of Attorney Act", "Internal", "Y", "PII."),
       ("Authority Scope", "Powers the holder has under the grant; the accounts covered are held separately in Accounts Covered.", "Authority Grant", "Code", "Authority Scope", "Trading and Disbursements to Owner", "Internal", "", "Y", "PII."),
       ("Accounts Covered", "Accounts the grant applies to; blank when it covers every current and future account of the grantor. Accounts are mastered in 15.", "Authority Grant", "Reference (Account) (multi)", "", "ACC-0049812; ACC-0049813", "Internal", "", "", "PII."),
       ("Authority Evidence", "Document that establishes the authority, such as the power of attorney instrument, court order, letters testamentary or corporate resolution.", "Authority Grant", "Text", "", "Durable POA dated 2025-11-03, notarized", "Internal", "", "", "PII."),
       ("Grant Effective From", "Date the authority took effect for the firm.", "Authority Grant", "Date", "ISO 8601", "2025-11-10", "Internal", "", "", "PII."),
       ("Revoked Date", "Date the grant ended through revocation, the grantor's death, the end of a guardianship or a court order.", "Authority Grant", "Date", "ISO 8601", "", "Uniform Power of Attorney Act", "", "", "PII."),
       ("Intake Service Request", "13 service request through which the instrument was received and reviewed.", "Authority Grant", "Reference (Service Request)", "", "SRQ-2026-0081245", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Trusted Contacts", "Trusted contact persons designated by clients under FINRA Rule 4512, whom the firm may contact under FINRA Rule 2165.", [
     ("Trusted Contact Designation", [
       ("Trusted Contact Designation ID", "Unique identifier of the designation.", "Trusted Contact Designation", "Identifier", "", "TCNT-0002215", "FINRA Rule 4512", "", "Y", "Object PII tier: PII - identity."),
       ("Designating Client", "Client who designated, or declined to designate, a trusted contact.", "Trusted Contact Designation", "Reference (Party)", "", "PTY-104588", "FINRA Rule 4512", "", "Y", "PII."),
       ("Trusted Contact Person", "Individual aged 18 or older whom the firm may contact about the client's accounts; a party in 02. Blank when the client declined.", "Trusted Contact Designation", "Reference (Party)", "", "PTY-104630", "FINRA Rule 4512", "FINRA Rule 2165", "Y", "PII."),
       ("Designation Status", "Whether the client provided a trusted contact, declined, or has not responded to the request; not required for institutional accounts, to which FINRA Rule 4512(a)(1)(F) does not apply.", "Trusted Contact Designation", "Code", "Trusted Contact Status", "Provided", "FINRA Rule 4512", "", "Y", "PII."),
       ("Account Scope", "Accounts the designation applies to; blank means every account of the client (reference default: per client with an account scope).", "Trusted Contact Designation", "Reference (Account) (multi)", "", "ACC-0049812", "FINRA Rule 4512", "", "", "PII."),
       ("Reasonable Efforts Date", "Date the firm made reasonable efforts to obtain the trusted contact's name and contact information, at account opening or when it updated account information.", "Trusted Contact Designation", "Date", "ISO 8601", "2026-02-11", "FINRA Rule 4512", "", "", "PII."),
       ("Trusted Contact Disclosure Date", "Date the firm gave the client written disclosure that it may contact the trusted contact and disclose account information.", "Trusted Contact Designation", "Date", "ISO 8601", "2026-02-11", "FINRA Rule 4512", "FINRA Rule 2165", "", "PII."),
       ("Last Confirmed Date", "Date the client last confirmed the trusted contact.", "Trusted Contact Designation", "Date", "ISO 8601", "2026-02-11", "Internal", "", "", "PII."),
       ("Designation Effective From", "Date the designation took effect.", "Trusted Contact Designation", "Date", "ISO 8601", "2026-02-11", "Internal", "", "", "PII."),
       ("Designation Effective To", "Date the designation was replaced or removed.", "Trusted Contact Designation", "Date", "ISO 8601", "", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Death Notification", "Notification that a party has died, and the estate handling it starts across the client's accounts.", [
     ("Death Notification", [
       ("Death Notification ID", "Unique identifier of the death notification and the estate handling it starts.", "Death Notification", "Identifier", "", "DTHN-2026-000318", "Internal", "", "Y", "Object PII tier: PII - identity."),
       ("Deceased Party", "Party reported as deceased.", "Death Notification", "Reference (Party)", "", "PTY-104588", "Internal", "", "Y", "PII."),
       ("Notification Received Date", "Date the firm was first told of the death.", "Death Notification", "Date", "ISO 8601", "2026-09-02", "Internal", "", "", "PII."),
       ("Reported Date of Death", "Date of death as reported by the notifier; the confirmed date is set on Individual Date of Death once the certificate is received.", "Death Notification", "Date", "ISO 8601", "2026-08-30", "Internal", "", "", "PII."),
       ("Death Certificate Received Date", "Date a certified copy of the death certificate was received.", "Death Notification", "Date", "ISO 8601", "2026-09-12", "Internal", "", "", "PII."),
       ("Estate Representative", "Executor, administrator or other personal representative of the estate, once appointed.", "Death Notification", "Reference (Party)", "", "PTY-104655", "Internal", "", "", "PII."),
       ("Representative Authority Grant", "Authority grant that records the representative's letters testamentary, letters of administration or small-estate affidavit.", "Death Notification", "Reference (Authority Grant)", "", "AGNT-0004533", "Internal", "", "", "PII."),
       ("Notification Status", "Work status of the estate handling.", "Death Notification", "Code", "Case Status", "In Progress", "Internal", "", "", "PII."),
       ("Intake Service Request", "13 service request through which the notification was received.", "Death Notification", "Reference (Service Request)", "", "SRQ-2026-0090412", "Internal", "", "", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Investor Profile", "HH-PRF",
  "What the client has told the firm about their objectives, risk, time horizon, liquidity and financial situation, versioned so that every account setting, approval and recommendation can name the version it relied on (CW-024); investment experience by product type; and investor qualification determinations.",
  [
   ("Investor Profile Versions", "The client's investor profile, one row per captured or re-attested version. 15 Account Investment Profile references the version it was set against; 45 recommendations reference the version they relied on; neither copies the values.", [
     ("Investor Profile", [
       ("Investor Profile ID", "Unique identifier of the investor profile version.", "Investor Profile", "Identifier", "", "INPR-104588-03", "Internal", "SEC Reg BI", "Y", "Object PII tier: PII - financial."),
       ("Profile Client", "Client the profile describes: an individual, an entity, or a Client Household party when the profile has household scope.", "Investor Profile", "Reference (Party)", "", "PTY-104588", "SEC Reg BI", "FINRA Rule 2111", "Y", "PII."),
       ("Profile Scope", "Whether the profile describes one individual, joint owners, a whole household or an entity (reference default: per client, with a joint or household scope).", "Investor Profile", "Code", "Profile Scope", "Joint", "Internal", "", "", "PII."),
       ("Profile Version Number", "Sequential version of the client's profile; a new version is created whenever the profile is captured or re-attested.", "Investor Profile", "Integer", "", "3", "Internal", "", "Y", "PII."),
       ("Investment Objective", "Primary investment objective stated by the client.", "Investor Profile", "Code", "Investment Objective", "Growth", "SEC Rule 17a-3", "FINRA Rule 2111", "Y", "PII - financial."),
       ("Risk Tolerance", "Client's stated willingness and ability to accept loss in pursuit of return.", "Investor Profile", "Code", "Risk Tolerance", "Moderately Aggressive", "FINRA Rule 2111", "SEC Reg BI", "Y", "PII - financial."),
       ("Time Horizon", "Expected period before the client needs a substantial part of the invested money.", "Investor Profile", "Code", "Time Horizon", "11 to 20 Years", "FINRA Rule 2111", "SEC Reg BI", "Y", "PII - financial."),
       ("Liquidity Need", "How important it is to the client to convert investments to cash quickly without significant loss.", "Investor Profile", "Code", "Liquidity Need", "Somewhat Important", "FINRA Rule 2111", "", "", "PII - financial."),
       ("Annual Income Band", "Client's annual income from all sources, as a band.", "Investor Profile", "Code", "Income Band", "USD 100,000 - 199,999", "SEC Rule 17a-3", "FINRA Rule 2111", "Y", "PII - financial."),
       ("Net Worth Band", "Client's net worth excluding the value of the primary residence, as a band.", "Investor Profile", "Code", "Net Worth Band", "USD 1,000,000 - 2,499,999", "SEC Rule 17a-3", "FINRA Rule 2111", "Y", "PII - financial."),
       ("Outside Investable Assets Band", "Investable assets the client holds at other institutions, as stated by the client (the other investments of the investment profile).", "Investor Profile", "Code", "Net Worth Band", "USD 250,000 - 499,999", "FINRA Rule 2111", "SEC Reg BI", "", "PII - financial."),
       ("Federal Marginal Tax Rate", "Client's stated federal marginal income tax rate, recorded as the tax status element of the investment profile.", "Investor Profile", "Percentage", "", "24%", "FINRA Rule 2111", "SEC Reg BI", "", "PII - financial."),
       ("Questionnaire Version", "Version of the risk questionnaire or fact-finder used to capture the profile.", "Investor Profile", "Text", "", "Risk questionnaire v2026.1", "Internal", "SEC IM Guidance 2017-02", "", "PII."),
       ("Risk Score", "Score the risk questionnaire produced, before any advisor adjustment.", "Investor Profile", "Decimal", "", "62", "Internal", "", "", "PII - financial."),
       ("Profile Trigger", "Event that caused this version to be captured.", "Investor Profile", "Code", "Profile Trigger", "Rule 3a-4 Annual Contact", "ICA Rule 3a-4", "SEC Rule 17a-3", "", "PII."),
       ("Attested Date", "Date the client confirmed the profile as accurate.", "Investor Profile", "Date", "ISO 8601", "2026-06-15", "SEC Rule 17a-3", "ICA Rule 3a-4", "", "PII."),
       ("Next Review Date", "Date the profile is next due for update or re-attestation (the Rule 17a-3(a)(17) furnishing cycle, the Rule 3a-4 annual contact or the advice review cycle).", "Investor Profile", "Date", "ISO 8601", "2027-06-15", "SEC Rule 17a-3", "ICA Rule 3a-4", "", "PII."),
       ("Profile Status", "Status of the version: Pending (awaiting attestation), Active (current), Deprecated (superseded by a later version).", "Investor Profile", "Code", "Record Status", "Active", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Investment Experience", "The client's experience with each product type, captured with a profile version; read for options and margin approvals and complex product eligibility.", [
     ("Investment Experience", [
       ("Experience Profile", "Investor profile version the experience was captured with.", "Investment Experience", "Reference (Investor Profile)", "", "INPR-104588-03", "Internal", "", "", "Object PII tier: PII - financial."),
       ("Product Experience Type", "Product type the experience relates to.", "Investment Experience", "Code", "Product Experience Type", "Options", "FINRA Rule 2360", "FINRA Rule 2111", "Y", "PII."),
       ("Years of Experience", "Years the client has invested in the product type.", "Investment Experience", "Integer", "", "6", "FINRA Rule 2360", "", "", "PII - financial."),
       ("Trades per Year", "Approximate number of trades a year the client makes in the product type.", "Investment Experience", "Integer", "", "12", "FINRA Rule 2360", "", "", "PII - financial."),
     ]),
   ]),
   ("Investor Qualification", "Determinations that a party meets a US investor qualification standard, for private offerings, feeder fund access and performance fee eligibility.", [
     ("Investor Qualification", [
       ("Qualified Party", "Party the determination is about; with the qualification standard it keys the row.", "Investor Qualification", "Reference (Party)", "", "PTY-104588", "SEC Regulation D", "", "Y", "Object PII tier: PII - financial. PII."),
       ("Qualification Standard", "Standard the party was determined to meet.", "Investor Qualification", "Code", "Investor Qualification Standard", "Accredited Investor", "SEC Regulation D", "SEC Rule 205-3", "Y", "PII."),
       ("Qualification Basis", "Test within the standard that the party meets.", "Investor Qualification", "Code", "Qualification Basis", "Net Worth", "SEC Regulation D", "ICA Section 2(a)(51)", "", "PII - financial."),
       ("Qualification Verification Method", "How the determination was evidenced.", "Investor Qualification", "Code", "Qualification Verification Method", "Third-Party Verification Letter", "SEC Regulation D", "", "", "PII."),
       ("Determination Date", "Date the firm determined that the party meets the standard.", "Investor Qualification", "Date", "ISO 8601", "2026-03-04", "SEC Regulation D", "", "", "PII."),
       ("Qualification Expiry Date", "Date the determination lapses under firm policy and must be refreshed before a further subscription.", "Investor Qualification", "Date", "ISO 8601", "2026-06-02", "SEC Regulation D", "", "", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("KYC, Identity & Tax", "HH-KYC",
  "Onboarding and periodic review of clients, customer due diligence, identity verification under each CIP program the firm runs (broker-dealer, funds through the transfer agent, trust company), beneficial ownership certification of legal entity customers, and the party tax profile (CW-025). The AML program, SAR cases and the sanctions program are 38.",
  [
   ("Onboarding Case", "Workflow record for onboarding a party or reviewing an existing one.", [
     ("Onboarding Case", [
       ("Onboarding Case ID", "Unique identifier of the onboarding or review case.", "Onboarding Case", "Identifier", "", "ONB-2026-0412", "Internal", "", "Y", "Object PII tier: PII - identity."),
       ("Case Party", "Party being onboarded or reviewed.", "Onboarding Case", "Reference (Party)", "", "PTY-104588", "Internal", "", "", "PII."),
       ("Case Type", "Reason the case was opened.", "Onboarding Case", "Code", "KYC Case Type", "New Client Onboarding", "Internal", "31 CFR 1010.230", "", "PII."),
       ("Case Status", "Current work status of the case.", "Onboarding Case", "Code", "Case Status", "Resolved / Completed", "Internal", "", "", "PII."),
       ("Case Business Line", "Business line through which the party is onboarded (CW-004).", "Onboarding Case", "Code", "Business Line", "DA", "Internal", "", "", "PII."),
       ("Case Opened Date", "Date the case was opened.", "Onboarding Case", "Date", "ISO 8601", "2026-02-10", "Internal", "", "", "PII."),
       ("Related Accounts", "Accounts opened or reviewed under the case; mastered in 15.", "Onboarding Case", "Reference (Account) (multi)", "", "ACC-0049812", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Customer Due Diligence", "Risk-based KYC profile of a party: its current due diligence state.", [
     ("KYC Profile", [
       ("KYC Status", "Overall KYC status of the party.", "KYC Profile", "Code", "KYC Status", "Complete", "31 CFR 1010.230", "FINRA Rule 2090", "Y", "Object PII tier: PII - identity."),
       ("AML Risk Rating", "Money laundering and terrorist financing risk rating of the customer.", "KYC Profile", "Code", "Risk Rating", "Low", "31 CFR 1010.230", "FINRA Rule 3310", "Y", "PII - restricted."),
       ("Due Diligence Level", "Level of due diligence applied.", "KYC Profile", "Code", "Due Diligence Level", "Standard CDD", "31 CFR 1010.230", "31 CFR 1010.610", "", "PII."),
       ("Nature and Purpose of Relationship", "Documented nature and purpose of the customer relationship, used to build the customer risk profile.", "KYC Profile", "Text", "", "Long-term retirement savings and self-directed trading", "31 CFR 1010.230", "", "", "PII."),
       ("Source of Funds", "Origin of the money the client will invest.", "KYC Profile", "Text", "", "Rollover from a former employer's 401(k) plan", "31 CFR 1010.230", "FINRA Rule 3310", "", "PII - financial."),
       ("PEP Status", "Whether the party, or an individual related to it, is a senior foreign political figure or another politically exposed person under firm policy.", "KYC Profile", "Code", "PEP Status", "Not a PEP", "31 CFR 1010.620", "FATF", "Y", "PII - identity (restricted)."),
       ("Sanctions Screening Result", "Latest outcome of screening the party against the OFAC lists.", "KYC Profile", "Code", "Screening Result", "No Match", "OFAC", "", "Y", "PII - restricted."),
       ("Last Screening Date", "Date of the latest sanctions, PEP and adverse media screening.", "KYC Profile", "Date", "ISO 8601", "2026-09-30", "OFAC", "", "", "PII."),
       ("Next KYC Review Date", "Date the next periodic KYC review is due, driven by the risk rating.", "KYC Profile", "Date", "ISO 8601", "2029-02-10", "FINRA Rule 3310", "", "", "PII."),
     ]),
   ]),
   ("Identity Verification", "One verification of a party's identity under one customer identification program, mastered once in 02 for every program (CW-025).", [
     ("Identity Verification", [
       ("Identity Verification ID", "Unique identifier of the verification.", "Identity Verification", "Identifier", "", "KYCV-2026-0041877", "31 CFR 1023.220", "", "Y", "Object PII tier: PII - identity (restricted)."),
       ("Verified Party", "Party whose identity was verified.", "Identity Verification", "Reference (Party)", "", "PTY-104588", "31 CFR 1023.220", "", "Y", "PII."),
       ("CIP Program", "Customer identification program the verification satisfies.", "Identity Verification", "Code", "CIP Program", "Broker-Dealer CIP", "31 CFR 1023.220", "31 CFR 1024.220", "Y", "PII."),
       ("CIP Program Entity", "Internal legal entity whose program the verification satisfies (the broker-dealer, the fund trust through the transfer agent, or the trust company); mastered in 09.", "Identity Verification", "Reference (Internal Legal Entity)", "", "LEN-0003", "31 CFR 1023.220", "", "", "PII."),
       ("Verification Method", "How the identity was verified.", "Identity Verification", "Code", "Verification Method", "Non-Documentary - Database", "31 CFR 1023.220", "", "Y", "PII."),
       ("Identity Document Type", "Type of document examined, where documentary verification was used.", "Identity Verification", "Code", "Identity Document Type", "US Driver's License", "31 CFR 1023.220", "", "", "PII."),
       ("Masked Document Number", "Last four characters of the identity document number; the full number is held only in the restricted evidence store.", "Identity Verification", "Identifier", "", "*****4821", "31 CFR 1023.220", "", "", "PII - identity (restricted)."),
       ("Document Expiry Date", "Expiry date of the document examined.", "Identity Verification", "Date", "ISO 8601", "2029-05-14", "31 CFR 1023.220", "", "", "PII."),
       ("Verification Result", "Outcome of the verification.", "Identity Verification", "Code", "Verification Result", "Verified", "31 CFR 1023.220", "", "Y", "PII."),
       ("Verification Date", "Date the verification was completed.", "Identity Verification", "Date", "ISO 8601", "2026-02-10", "31 CFR 1023.220", "", "", "PII."),
       ("Discrepancy Resolution", "How any substantive discrepancy between the identifying information and the verification sources was resolved.", "Identity Verification", "Text", "", "Address mismatch resolved with a utility bill dated 2026-01-05", "31 CFR 1023.220", "", "", "PII."),
       ("Government List Check Date", "Date the customer was compared with the government lists of known or suspected terrorists or terrorist organizations, as the CIP rule requires.", "Identity Verification", "Date", "ISO 8601", "2026-02-10", "31 CFR 1023.220", "", "", "PII."),
       ("Shared Evidence Verification", "Verification under another CIP program whose evidence this record reuses (reference default: one record per program, sharing evidence).", "Identity Verification", "Reference (Identity Verification)", "", "KYCV-2026-0041876", "Internal", "", "", "PII."),
       ("Record Retention End Date", "Date the identifying information may be destroyed: five years after the account is closed; verification records five years after they are made.", "Identity Verification", "Date", "ISO 8601", "", "31 CFR 1023.220", "", "", "The CIP-rule retention fact (31 CFR 1023.220(a)(3)(iii)), not record-retention metadata (21, CD-160). PII."),
     ]),
   ]),
   ("Beneficial Ownership", "Certification of the beneficial owners of a legal entity customer and the owners it lists.", [
     ("Beneficial Ownership Certification", [
       ("Beneficial Ownership Certification ID", "Unique identifier of the certification.", "Beneficial Ownership Certification", "Identifier", "", "BOWN-2026-001877", "31 CFR 1010.230", "", "Y", "Object PII tier: PII - identity."),
       ("Certified Entity", "Legal entity customer whose beneficial owners are certified.", "Beneficial Ownership Certification", "Reference (Party)", "", "PTY-100780", "31 CFR 1010.230", "", "Y", "PII."),
       ("Certifying Individual", "Individual who certified on behalf of the entity.", "Beneficial Ownership Certification", "Reference (Party)", "", "PTY-104611", "31 CFR 1010.230", "", "", "PII."),
       ("Certification Date", "Date the certification was signed.", "Beneficial Ownership Certification", "Date", "ISO 8601", "2026-03-18", "31 CFR 1010.230", "", "", "PII."),
       ("Certifying Onboarding Case", "Onboarding or review case under which the certification was obtained; its case type gives the trigger.", "Beneficial Ownership Certification", "Reference (Onboarding Case)", "", "ONB-2026-0418", "Internal", "", "", "PII."),
       ("Certification Status", "Status of the certification: Active (current), Deprecated (superseded by a recertification).", "Beneficial Ownership Certification", "Code", "Record Status", "Active", "Internal", "", "", "PII."),
       ("Recertification Due Date", "Date by which the firm will refresh the certification under its risk-based procedures, or earlier on knowledge of a change.", "Beneficial Ownership Certification", "Date", "ISO 8601", "2029-03-18", "31 CFR 1010.230", "", "", "PII."),
     ]),
     ("Beneficial Ownership", [
       ("Ownership Certification", "Certification that lists the owner.", "Beneficial Ownership", "Reference (Beneficial Ownership Certification)", "", "BOWN-2026-001877", "31 CFR 1010.230", "", "", "Object PII tier: PII - identity."),
       ("Beneficial Owner", "Individual who owns or controls the legal entity customer.", "Beneficial Ownership", "Reference (Party)", "", "PTY-500901", "31 CFR 1010.230", "", "Y", "PII."),
       ("Ownership Prong", "Prong under which the individual is a beneficial owner.", "Beneficial Ownership", "Code", "Beneficial Ownership Prong", "Ownership", "31 CFR 1010.230", "", "Y", "PII."),
       ("Beneficial Ownership Percentage", "Percentage of equity interests held directly or indirectly, for the ownership prong.", "Beneficial Ownership", "Percentage", "", "40%", "31 CFR 1010.230", "", "", "PII."),
       ("Owner Identity Verification", "Identity verification of the beneficial owner.", "Beneficial Ownership", "Reference (Identity Verification)", "", "KYCV-2026-0041902", "31 CFR 1010.230", "", "", "PII."),
     ]),
   ]),
   ("Tax Classification", "US tax status of the party: US person status, federal tax classification, the masked TIN and chapter 4 status. The Form W-9 or W-8 on file is a 15 Account Tax Certification.", [
     ("Tax Profile", [
       ("US Person Indicator", "Whether the party is a US person for federal tax purposes.", "Tax Profile", "Boolean", "", "Y", "IRS Form W-9", "IRC 7701", "Y", "Object PII tier: PII - identity (restricted). PII."),
       ("Tax Classification", "Federal tax classification of the party as certified.", "Tax Profile", "Code", "Tax Classification", "Individual / Sole Proprietor", "IRS Form W-9", "", "Y", "PII."),
       ("Tax Identification Number", "Taxpayer identification number of an individual party, held masked with restricted access. For an organization the TIN is its EIN, held on US Regulatory Identifier and not repeated here.", "Tax Profile", "Identifier", "", "***-**-4821", "IRS Form W-9", "IRS Form W-8BEN", "Y", "PII - identity (restricted). Mask in every example and display."),
       ("TIN Type", "Kind of taxpayer identification number held.", "Tax Profile", "Code", "TIN Type", "SSN", "IRS Form W-9", "", "", "PII."),
       ("Nonresident Alien Indicator", "Whether the individual is a nonresident alien who certified foreign status on Form W-8BEN.", "Tax Profile", "Boolean", "", "N", "IRS Form W-8BEN", "IRC 7701", "", "PII."),
       ("Tax Residence Countries", "Countries in which the party is resident for tax purposes.", "Tax Profile", "Code (multi)", "ISO 3166-1 alpha-2", "US", "IRS Form W-8BEN", "", "", "PII."),
       ("FATCA Status", "Chapter 4 status of the party as certified.", "Tax Profile", "Code", "FATCA Status", "US Person", "FATCA", "IRS Form W-8BEN-E", "", "PII."),
       ("Tax Status Evidence", "Account tax certification (Form W-9 or W-8) on file that evidences the tax status; mastered in 15.", "Tax Profile", "Reference (Account Tax Certification)", "", "ATC-00771203", "IRS Form W-9", "", "", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Classification & Segmentation", "HH-SEG",
  "Regulatory classifications that drive the conduct rules applied to a client, firm-defined segments, and the assignment of each client or Client Household to a service tier defined in 01 (CW-028).",
  [
   ("Regulatory Client Classification", "Classifications that drive the regulatory treatment of a party.", [
     ("Regulatory Classification", [
       ("Classified Party", "Party the classification applies to.", "Regulatory Classification", "Reference (Party)", "", "PTY-104588", "Internal", "", "", "Object PII tier: PII - identity (when the party is an individual). PII when the party is an individual."),
       ("Categorization Date", "Date the party was classified or last re-classified.", "Regulatory Classification", "Date", "ISO 8601", "2026-02-10", "Internal", "", "", "PII."),
       ("Reg BI Retail Customer Indicator", "Whether the party is a retail customer under Regulation Best Interest: a natural person, or the legal representative of one, who uses a recommendation primarily for personal, family or household purposes.", "Regulatory Classification", "Boolean", "", "Y", "SEC Reg BI", "SEC Form CRS", "Y", "PII."),
       ("FINRA Institutional Account Indicator", "Whether the party meets the institutional account definition of FINRA Rule 4512(c).", "Regulatory Classification", "Boolean", "", "N", "FINRA Rule 4512", "", "Y", "PII."),
       ("FINRA Institutional Investor Indicator", "Whether the party is an institutional investor for FINRA Rule 2210 communications.", "Regulatory Classification", "Boolean", "", "N", "FINRA Rule 2210", "", "", "PII."),
       ("Investor Category", "Communications audience of the party (retail, institutional or financial professional), derived from the FINRA indicators on this record; investor qualification determinations (accredited investor, qualified purchaser) are held only on Investor Qualification.", "Regulatory Classification", "Code", "Investor Category", "Retail", "FINRA Rule 2210", "SEC Regulation D", "", "PII."),
     ]),
   ]),
   ("Firm-Defined Segmentation", "Segments assigned by the firm to clients and Client Households for service design, analytics and engagement.", [
     ("Segment Assignment", [
       ("Segmented Party", "Client party or Client Household the segment is assigned to.", "Segment Assignment", "Reference (Party)", "", "PTY-HH-55012", "Internal", "", "", "Object PII tier: PII - financial (a segment is an inference about a client). PII."),
       ("Segmentation Scheme", "Segmentation model the assignment belongs to.", "Segment Assignment", "Code", "Segmentation Scheme", "Life Stage", "Internal", "", "", "PII."),
       ("Segment", "Segment assigned.", "Segment Assignment", "Code", "Firm-defined", "Pre-Retiree", "Internal", "", "", "PII - financial (inference)."),
       ("Assignment Method", "How the segment was assigned.", "Segment Assignment", "Code", "Assignment Method", "Model Score", "Internal", "", "", "PII."),
       ("Segment Effective From", "Date the assignment took effect.", "Segment Assignment", "Date", "ISO 8601", "2026-07-01", "Internal", "", "", "PII."),
       ("Segment Effective To", "Date the assignment ended.", "Segment Assignment", "Date", "ISO 8601", "", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Service Tier Assignment", "Assignment of a Client Household or client to a relationship service tier; the tier, its thresholds and benefits are defined in 01, and fee discounts are applied by 47.", [
     ("Service Tier Assignment", [
       ("Tier Party", "Client Household or client party the tier is assigned to.", "Service Tier Assignment", "Reference (Party)", "", "PTY-HH-55012", "Internal", "", "Y", "Object PII tier: PII - financial. PII."),
       ("Assigned Service Tier", "Service tier defined in 01 (the tier code is its natural key).", "Service Tier Assignment", "Reference (Service Tier, 01)", "", "TIER2", "Internal", "", "Y", "PII."),
       ("Qualifying Client Assets", "Client assets the tier qualification was measured on (reference default: all household client assets as published by 06, including workplace plan assets).", "Service Tier Assignment", "Amount", "", "USD 1,240,000", "Internal", "", "", "Derived copy (06): household or client total from 06 Client Assets, summarized from 49 Client Holding; future owner 06, W4. PII - financial."),
       ("Qualifying Assets As-Of Date", "Measurement date of the qualifying client assets.", "Service Tier Assignment", "Date", "ISO 8601", "2026-09-30", "Internal", "", "", "Derived copy (06); future owner 06, W4. PII."),
       ("Tier Assignment Method", "How the tier was assigned.", "Service Tier Assignment", "Code", "Assignment Method", "Rule-Based Threshold", "Internal", "", "", "PII."),
       ("Override Approver", "Employee who approved a tier assignment that departs from the threshold rule.", "Service Tier Assignment", "Reference (Employee)", "", "EMP-02201", "Internal", "", "", "PII (employee identifier)."),
       ("Tier Effective From", "Date the tier assignment took effect.", "Service Tier Assignment", "Date", "ISO 8601", "2026-10-01", "Internal", "", "", "PII."),
       ("Tier Effective To", "Date the tier assignment ended.", "Service Tier Assignment", "Date", "ISO 8601", "", "Internal", "", "", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Contact Points & Preferences", "HH-CPT",
  "Postal addresses, email addresses and telephone numbers through which parties are reached, and how each client wants to be contacted (CD-142). Delivery of statements and notices is 13; marketing subscriptions and suppression lists are 04.",
  [
   ("Contact Points", "One contact point per party, channel, value and usage, effective dated (re-cut from the wholesale address, email, phone and usage objects into one object, CTP- kept).", [
     ("Contact Point", [
       ("Contact Point ID", "Unique identifier of the contact point; referenced by 13 for delivery and by 04 for outreach.", "Contact Point", "Identifier", "", "CTP-0091245", "Internal", "Salesforce FSC", "Y", "Object PII tier: PII - identity."),
       ("Contact Point Party", "Party reached through the contact point.", "Contact Point", "Reference (Party)", "", "PTY-104588", "Internal", "", "", "PII."),
       ("Contact Channel", "Kind of contact point.", "Contact Point", "Code", "Contact Channel", "Mobile Phone", "Salesforce FSC", "", "Y", "PII."),
       ("Contact Point Usage", "Purpose the contact point serves for the party.", "Contact Point", "Code", "Contact Point Usage", "Legal Residence", "FINRA Rule 4512", "Salesforce FSC", "", "PII."),
       ("Email Address", "Email address, for email contact points.", "Contact Point", "Text", "Email", "j.example@example.com", "Salesforce FSC", "", "", "PII."),
       ("Phone Number", "Telephone number in international format, for phone contact points.", "Contact Point", "Text", "E.164", "+12155550142", "ITU-T E.164", "", "", "PII. Mobile numbers are subject to TCPA rules."),
       ("Primary Contact Point Indicator", "Whether this is the party's primary contact point of its channel.", "Contact Point", "Boolean", "", "Y", "Salesforce FSC", "", "", "PII."),
       ("Contact Point Verified Indicator", "Whether the contact point has been verified (address standardized and delivery-point validated, email confirmed, phone confirmed by one-time code).", "Contact Point", "Boolean", "", "Y", "USPS Publication 28", "Internal", "", "PII."),
       ("Contact Point Effective From", "Date the contact point became valid.", "Contact Point", "Date", "ISO 8601", "2024-03-01", "Internal", "", "", "PII."),
       ("Contact Point Effective To", "Date the contact point ceased to be valid.", "Contact Point", "Date", "ISO 8601", "", "Internal", "", "", "PII."),
     ]),
     ("Postal Address", [
       ("Address Line 1", "First line of the street address, standardized to USPS Publication 28 for US addresses.", "Postal Address", "Text", "", "100 Example Street, Apt 4B", "USPS Publication 28", "ISO 20022", "Y", "Object PII tier: PII - identity. PII."),
       ("City", "City or town.", "Postal Address", "Text", "", "Anytown", "USPS Publication 28", "ISO 20022", "", "PII."),
       ("Country Subdivision", "State, territory or foreign province (the 09 Country Subdivision).", "Postal Address", "Code", "ISO 3166-2", "US-PA", "ISO 3166", "", "", "PII."),
       ("Postal Code", "ZIP+4 code, or the foreign postal code.", "Postal Address", "Text", "", "00000-0000", "USPS Publication 28", "", "Y", "PII."),
       ("Country", "Country of the address.", "Postal Address", "Code", "ISO 3166-1 alpha-2", "US", "ISO 3166", "", "Y", "PII."),
       ("Mail Returned Date", "Date mail to the address was last returned as undeliverable: the latest 13 Recipient Delivery Record.Returned Mail Date for the address. Starts the lost securityholder search and the unclaimed property clocks that 13 runs.", "Postal Address", "Date", "ISO 8601", "", "SEC Rule 17Ad-17", "", "", "Derived copy (13 Recipient Delivery Record, CW-089); 13 masters returned mail and runs the search. PII."),
     ]),
   ]),
   ("Contact & Communication Preferences", "How, when and about what a client wants to be contacted.", [
     ("Contact Preference", [
       ("Preference Holder", "Party whose contact preferences these are.", "Contact Preference", "Reference (Party)", "", "PTY-104588", "Internal", "", "", "Object PII tier: PII - identity. PII."),
       ("Preferred Contact Channel", "Channel the party prefers for routine contact.", "Contact Preference", "Code", "Communication Channel", "Secure Message", "Internal", "Salesforce FSC", "", "PII."),
       ("Preferred Contact Point", "Contact point to use by default.", "Contact Preference", "Reference (Contact Point)", "", "CTP-0091245", "Internal", "", "", "PII."),
       ("Preferred Language", "Language for communications.", "Contact Preference", "Code", "ISO 639-1", "es", "ISO 639", "", "", "PII."),
       ("Do Not Contact Channels", "Channels through which the party must not be contacted, in addition to the global Do Not Contact Indicator on the Privacy Profile.", "Contact Preference", "Code (multi)", "Communication Channel", "Telephone; SMS", "Internal", "TCPA", "Y", "PII."),
       ("Preference Effective From", "Date the preferences took effect.", "Contact Preference", "Date", "ISO 8601", "2026-03-02", "Internal", "", "", "PII."),
       ("Preference Effective To", "Date the preferences were replaced or withdrawn.", "Contact Preference", "Date", "ISO 8601", "", "Internal", "", "", "PII."),
     ]),
     ("Communication Preference", [
       ("Preference Party", "Party whose preference this is.", "Communication Preference", "Reference (Party)", "", "PTY-104588", "Internal", "", "", "Object PII tier: PII - identity. PII."),
       ("Preference Topic", "Subscription topic offered by 04 the preference applies to; blank means all marketing.", "Communication Preference", "Reference (Subscription Topic)", "", "SUB-004", "Internal", "", "", "PII."),
       ("Preference Channel", "Channel the preference applies to.", "Communication Preference", "Code", "Communication Channel", "Email", "Internal", "", "Y", "PII."),
       ("Opt-In Status", "Current preference for the topic and channel; its history is kept through Opt-Out Timestamp and the capture timestamp of the linked Consent Record.", "Communication Preference", "Code", "Opt-In Status", "Opted In", "CAN-SPAM Act", "TCPA", "Y", "PII."),
       ("Opt-Out Timestamp", "When the opt-out was received.", "Communication Preference", "Timestamp", "ISO 8601", "", "CAN-SPAM Act", "TCPA", "", "PII. CAN-SPAM: honor within 10 business days."),
       ("Consent Record Reference", "Consent record the preference relies on, where consent is required (for example marketing text messages).", "Communication Preference", "Reference (Consent Record)", "", "CNS-00918231", "TCPA", "", "", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Privacy & Consent", "HH-PRV",
  "Privacy choices and consents of each party under US law (CW-029): the privacy regimes that apply, GLBA and Regulation S-P sharing opt-outs, Regulation S-AM affiliate marketing opt-outs, state-law sale and sharing opt-outs, consent records and consumer privacy requests. 13 delivers privacy notices; 41 runs the Reg S-P safeguards and incident response program.",
  [
   ("Privacy Profile", "Privacy regimes and opt-outs applying to a party.", [
     ("Privacy Profile", [
       ("Applicable Privacy Regimes", "Privacy laws that apply to the party's personal information (reference default: a multi-valued regime list with GLBA-covered data flagged).", "Privacy Profile", "Code (multi)", "Privacy Regime", "GLBA / Regulation S-P; CCPA / CPRA", "SEC Regulation S-P", "CCPA / CPRA", "Y", "Object PII tier: PII - identity. PII."),
       ("Personal Data Categories Held", "Categories of personal information held about the party.", "Privacy Profile", "Code (multi)", "Personal Data Category", "Identity; Contact; Financial; Government Identifier", "CCPA / CPRA", "", "", "PII."),
       ("GLBA-Covered Data Indicator", "Whether the party's personal information is collected under the GLBA, which takes it outside most CCPA rights.", "Privacy Profile", "Boolean", "", "Y", "CCPA / CPRA", "GLBA", "", "PII."),
       ("Nonaffiliated Sharing Opt-Out Indicator", "Whether the consumer has opted out of the firm sharing nonpublic personal information with nonaffiliated third parties.", "Privacy Profile", "Boolean", "", "N", "SEC Regulation S-P", "GLBA", "Y", "PII."),
       ("Affiliate Marketing Opt-Out Indicator", "Whether the consumer has opted out of affiliates using eligibility information about them to market to them.", "Privacy Profile", "Boolean", "", "N", "SEC Regulation S-AM", "FCRA", "Y", "PII."),
       ("Affiliate Marketing Opt-Out Expiry Date", "Date the affiliate marketing opt-out expires (at least five years after it was received) unless renewed.", "Privacy Profile", "Date", "ISO 8601", "2031-04-30", "SEC Regulation S-AM", "", "", "PII."),
       ("Sale / Sharing Opt-Out Indicator", "Whether the consumer has opted out of the sale or sharing of personal information under state law, including opt-out preference signals.", "Privacy Profile", "Boolean", "", "N", "CCPA / CPRA", "US State Privacy Laws", "", "PII."),
       ("Do Not Contact Indicator", "Whether the party must not be contacted for any non-mandatory purpose (global suppression).", "Privacy Profile", "Boolean", "", "N", "Internal", "FINRA Rule 3230", "Y", "PII. Overrides 04 channel preferences."),
       ("Initial Privacy Notice", "13 communication that delivered the initial privacy notice to the party.", "Privacy Profile", "Reference (Shareholder Communication)", "", "COMM-2026-0145", "SEC Regulation S-P", "", "", "PII."),
     ]),
   ]),
   ("Consent", "Consents a party has given, with their evidence. 13 E-Delivery Election (DEL-) and 04 subscriptions link to them.", [
     ("Consent Record", [
       ("Consent Record ID", "Unique identifier of the consent record.", "Consent Record", "Identifier", "", "CNS-00418822", "Regulation S-P (17 CFR 248)", "E-SIGN Act", "Y", "Object PII tier: PII - identity."),
       ("Consenting Party", "Party who gave the consent.", "Consent Record", "Reference (Party)", "", "PTY-104588", "Internal", "", "", "PII."),
       ("Consent Purpose", "Purpose the consent covers.", "Consent Record", "Code", "Consent Purpose", "Electronic Delivery (E-SIGN)", "E-SIGN Act", "FDX API", "Y", "PII."),
       ("Consent Status", "Current status of the consent.", "Consent Record", "Code", "Consent Status", "Granted", "Internal", "", "Y", "PII."),
       ("Consent Captured Timestamp", "When the consent was given.", "Consent Record", "Timestamp", "ISO 8601", "2026-02-10T14:22:05Z", "E-SIGN Act", "", "", "PII."),
       ("Consent Capture Method", "How the consent was captured.", "Consent Record", "Code", "Consent Capture Method", "Electronic Signature Ceremony", "E-SIGN Act", "", "", "PII."),
       ("Data Recipient", "Third party authorized to receive data under the consent, such as an account aggregator connected through FDX.", "Consent Record", "Reference (Party)", "", "PTY-100995", "FDX API", "", "", "PII."),
       ("Consent Expiry Date", "Date the consent lapses unless renewed.", "Consent Record", "Date", "ISO 8601", "2027-02-10", "FDX API", "", "", "PII."),
       ("Consent Withdrawn Timestamp", "When the consent was withdrawn.", "Consent Record", "Timestamp", "ISO 8601", "", "E-SIGN Act", "", "", "PII."),
     ]),
   ]),
   ("Consumer Privacy Requests", "Requests from consumers exercising state-law privacy rights (renamed from the wholesale Data Subject Request).", [
     ("Consumer Privacy Request", [
       ("Privacy Request ID", "Unique identifier of the request (firm-defined key; no registered prefix).", "Consumer Privacy Request", "Identifier", "", "2026-000412", "Internal", "Regulation S-P (17 CFR 248)", "Y", "Object PII tier: PII - identity."),
       ("Requesting Party", "Party who made the request, or on whose behalf an authorized agent made it.", "Consumer Privacy Request", "Reference (Party)", "", "PTY-104588", "CCPA / CPRA", "", "", "PII."),
       ("Request Type", "Right being exercised.", "Consumer Privacy Request", "Code", "Privacy Request Type", "Delete", "CCPA / CPRA", "", "Y", "PII."),
       ("Request Regime", "Privacy law under which the request is handled.", "Consumer Privacy Request", "Code", "Privacy Regime", "CCPA / CPRA", "CCPA / CPRA", "", "", "PII."),
       ("Request Received Date", "Date the request was received.", "Consumer Privacy Request", "Date", "ISO 8601", "2026-08-18", "CCPA / CPRA", "", "", "PII."),
       ("Statutory Due Date", "Date the response is due under the regime (45 calendar days under the CCPA, extendable once by 45 days with notice).", "Consumer Privacy Request", "Date", "ISO 8601", "2026-10-02", "CCPA / CPRA", "", "", "PII."),
       ("GLBA Exemption Applied Indicator", "Whether part of the request was declined because the data is covered by the GLBA.", "Consumer Privacy Request", "Boolean", "", "Y", "CCPA / CPRA", "GLBA", "", "PII."),
       ("Request Status", "Work status of the request.", "Consumer Privacy Request", "Code", "Case Status", "In Progress", "Internal", "", "", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Restrictions & Protections", "HH-PRT",
  "Restrictions that apply to a client whoever imposed them, the client's enterprise-wide restricted status, and the senior and vulnerable investor protections of FINRA Rule 2165 (CW-030). Account-level blocks and holds are 15 Account Restrictions (ARX-); disbursement holds are 50.",
  [
   ("Client Restrictions", "Restrictions on what may be done for or offered to a client, and the client's enterprise-wide engagement status.", [
     ("Client Restriction", [
       ("Client Restriction ID", "Unique identifier of the restriction.", "Client Restriction", "Identifier", "", "CRX-002318", "Internal", "", "Y", "Object PII tier: PII - financial."),
       ("Restricted Party", "Client the restriction applies to.", "Client Restriction", "Reference (Party)", "", "PTY-104588", "Internal", "", "Y", "PII."),
       ("Restricted Accounts", "Accounts the restriction is limited to; blank when it applies to every account of the client. Accounts are mastered in 15.", "Client Restriction", "Reference (Account) (multi)", "", "ACC-0049812", "Internal", "", "", "PII."),
       ("Restriction Category", "Kind of restriction.", "Client Restriction", "Code", "Client Restriction Category", "Investment Exclusion", "Internal", "", "Y", "PII."),
       ("Restriction Source", "Who imposed the restriction.", "Client Restriction", "Code", "Client Restriction Source", "Client Instruction", "Internal", "", "", "PII."),
       ("Restriction Description", "What is restricted, in business terms.", "Client Restriction", "Text", "", "No tobacco or firearms manufacturers in managed accounts", "Internal", "", "", "PII - financial (client preference)."),
       ("Excluded Instruments", "Instruments the restriction excludes; mastered in 17.", "Client Restriction", "Reference (Instrument) (multi)", "", "INS-00412873", "ICA Rule 3a-4", "", "", "PII."),
       ("Rule 3a-4 Reasonable Restriction Indicator", "Whether the restriction is a reasonable restriction the client imposed on the management of an advisory program account; 46 applies it to the account's targets.", "Client Restriction", "Boolean", "", "Y", "ICA Rule 3a-4", "", "", "PII."),
       ("Restriction Status", "Status of the restriction: Active, Paused (suspended) or Retired (lifted).", "Client Restriction", "Code", "Record Status", "Active", "Internal", "", "Y", "PII."),
       ("Restriction Effective From", "Date the restriction took effect.", "Client Restriction", "Date", "ISO 8601", "2026-01-15", "Internal", "", "", "PII."),
       ("Restriction Effective To", "Date the restriction ended.", "Client Restriction", "Date", "ISO 8601", "", "Internal", "", "", "PII."),
     ]),
     ("Restricted Client Status", [
       ("Status Party", "Client the status applies to.", "Restricted Client Status", "Reference (Party)", "", "PTY-104588", "Internal", "", "", "Object PII tier: PII - identity. PII."),
       ("Restricted Client Status", "Enterprise-wide engagement status of the client.", "Restricted Client Status", "Code", "Restricted Client Status", "Watch", "Internal", "", "Y", "PII - restricted."),
       ("Restricted Status Reason", "Why the status was set.", "Restricted Client Status", "Code", "Restricted Status Reason", "Fraud", "Internal", "", "", "PII. Restricted."),
       ("Related AML Case", "38 AML case behind the status; visible only to AML staff because it may reveal a suspicious activity report.", "Restricted Client Status", "Reference (AML Case)", "", "Restricted firm case number", "31 CFR 1023.320", "", "", "Restricted (31 CFR 1023.320(e)). PII."),
       ("Status Effective From", "Date the status took effect.", "Restricted Client Status", "Date", "ISO 8601", "2026-05-20", "Internal", "", "", "PII."),
       ("Status Effective To", "Date the status ended.", "Restricted Client Status", "Date", "ISO 8601", "", "Internal", "", "", "PII."),
       ("Status Next Review Date", "Date the status must be reviewed.", "Restricted Client Status", "Date", "ISO 8601", "2026-11-20", "Internal", "", "", "PII."),
       ("Status Approved By", "Employee who approved the status.", "Restricted Client Status", "Reference (Employee)", "", "EMP-30051", "Internal", "", "", "PII (employee identifier)."),
     ]),
   ]),
   ("Senior & Vulnerable Investor Protection", "Specified adult status and vulnerability concerns: special-category facts held once, flagged, and restricted to service, advice and compliance (CD-344).", [
     ("Specified Adult Status", [
       ("Specified Adult Indicator", "Whether the client is a specified adult under FINRA Rule 2165.", "Specified Adult Status", "Boolean", "", "Y", "FINRA Rule 2165", "", "Y", "Object PII tier: PII - special category (CD-344). Restricted view."),
       ("Specified Adult Basis", "Ground on which the client is a specified adult.", "Specified Adult Status", "Code", "Specified Adult Basis", "Age 65 or Older", "FINRA Rule 2165", "", "Y", "PII - special category (CD-344). Restricted view."),
       ("Specified Adult Determination Date", "Date the basis was determined or last reviewed.", "Specified Adult Status", "Date", "ISO 8601", "2026-05-14", "FINRA Rule 2165", "", "", "PII - special category (CD-344). Restricted view."),
       ("Specified Adult Status Effective From", "Date from which the specified adult basis applies (the age-65 birthday, or the date a reasonable belief of impairment was formed); with Effective To it bounds each period kept for Rule 2165 reviews.", "Specified Adult Status", "Date", "ISO 8601", "2026-05-14", "FINRA Rule 2165", "", "Y", "PII - special category (CD-344). Restricted view."),
       ("Specified Adult Status Effective To", "Date the specified adult basis ceased to apply, for example when a reasonable belief of impairment is withdrawn; blank while it applies. Earlier periods are kept for Rule 2165 reviews.", "Specified Adult Status", "Date", "ISO 8601", "", "FINRA Rule 2165", "", "", "PII - special category (CD-344). Restricted view."),
       ("Determined By", "Employee who recorded the determination.", "Specified Adult Status", "Reference (Employee)", "", "EMP-01877", "Internal", "", "", "PII - special category (CD-344). Restricted view."),
     ]),
     ("Vulnerability Concern", [
       ("Vulnerability Concern ID", "Unique identifier of the concern; 15 Account Restriction and 50 Money Movement Hold reference it.", "Vulnerability Concern", "Identifier", "", "VCON-2026-000217", "FINRA Rule 2165", "", "Y", "Object PII tier: PII - special category (CD-344). Restricted view."),
       ("Concern Party", "Client the concern is about.", "Vulnerability Concern", "Reference (Party)", "", "PTY-104588", "FINRA Rule 2165", "", "Y", "PII - special category (CD-344). Restricted view."),
       ("Concern Type", "Kind of concern raised.", "Vulnerability Concern", "Code", "Vulnerability Concern Type", "Suspected Financial Exploitation", "FINRA Rule 2165", "", "Y", "PII - special category (CD-344). Restricted view."),
       ("Concern Raised Date", "Date the concern was first recorded.", "Vulnerability Concern", "Date", "ISO 8601", "2026-09-08", "FINRA Rule 2165", "", "", "PII - special category (CD-344). Restricted view."),
       ("Concern Description", "Factual description of what was observed or reported; restricted to service, advice and compliance staff.", "Vulnerability Concern", "Text", "", "Client asked to wire funds to a new payee met online and could not explain the purpose", "FINRA Rule 2165", "", "", "PII - special category (CD-344). Restricted view."),
       ("Trusted Contact Contacted Date", "Date the trusted contact was contacted about the concern itself; the Rule 2165(b)(2) notice that follows a hold is evidence on the 15 or 50 hold.", "Vulnerability Concern", "Date", "ISO 8601", "2026-09-09", "FINRA Rule 2165", "FINRA Rule 4512", "", "PII - special category (CD-344). Restricted view."),
       ("Trusted Contact Designation Used", "Trusted contact designation used for the contact.", "Vulnerability Concern", "Reference (Trusted Contact Designation)", "", "TCNT-0002215", "FINRA Rule 2165", "", "", "PII - special category (CD-344). Restricted view."),
       ("Escalation Case Reference", "08 Senior Investor Case the concern was escalated to.", "Vulnerability Concern", "Reference (Senior Investor Case, 08)", "", "SNRC-2026-00217", "FINRA Rule 2165", "", "", "PII - special category (CD-344). Restricted view."),
       ("Agency Referral Date", "Date the concern was reported to adult protective services, a state securities regulator or law enforcement: the earliest External Protection Report.Report Date of the 08 Senior Investor Case the concern was escalated to.", "Vulnerability Concern", "Date", "ISO 8601", "2026-09-10", "Senior Safe Act", "", "", "PII - special category (CD-344). Restricted view. Derived copy (08 External Protection Report)."),
       ("Concern Status", "Work status of the concern.", "Vulnerability Concern", "Code", "Case Status", "Escalated", "Internal", "", "", "PII - special category (CD-344). Restricted view."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 # Party Master
 "Party Type": ("FIBO BE / IRS Form W-9 / Internal", [("Individual","Natural person"),("Household","Client Household (PTY-HH-), CW-027"),("Trust","Revocable or irrevocable trust; the trust terms are 51"),("Estate","Decedent's estate"),("Corporation",""),("Partnership / LLC",""),("Retirement Plan","Employer plan; thin identity here, administration in 16"),("Nonprofit","Charity, foundation, endowment or other tax-exempt organization"),("Government","Federal, state or local government body"),("Financial Institution","Broker-dealer, bank, adviser, insurer, fund or market infrastructure")]),
 "Party Status": ("Internal (record lifecycle only; deceased is Individual Date of Death, blocked is Restricted Client Status)", [("Pending Verification","Created but identity not yet verified"),("Active",""),("Inactive","No current role or relationship, including a dissolved entity or a deceased individual whose estate is settled"),("Merged","Duplicate merged into the surviving record")]),
 "Relationship Stage": ("Internal / Salesforce FSC", [("Prospect","Identity captured; no application (anonymous leads stay in 04)"),("Applicant","Application in progress"),("Client","Holds at least one open account"),("Former Client","Held accounts; all are closed"),("Related Party","Trusted contact, agent, beneficiary or other non-client person"),("Counterparty / Vendor","Organization the firm deals with that is not a client")]),
 "Party Origin": ("Internal", [("Direct Online Application",""),("Mobile App Application",""),("Phone Representative",""),("Advisor-Assisted Onboarding","Human or hybrid advice onboarding"),("Workplace Plan Enrollment","Participant created by the recordkeeper (16)"),("Transfer Agent Registration","Legacy fund-direct shareholder"),("Account Transfer In","Created from an incoming ACATS transfer (49)"),("Related Party Capture","Added as trusted contact, agent, beneficiary or owner"),("Institutional Onboarding",""),("Counterparty / Vendor Setup",""),("Regulatory Register - FINRA CRD",""),("Regulatory Register - SEC IAPD",""),("GLEIF",""),("Lead Conversion","From a 04 lead"),("Data Migration","")]),
 "Party Role Type": ("Internal (aligned to FIBO BE / BIAN)", [("Client","Holds or applies for an account (CW-005)"),("Prospect","Identified potential client"),("Trusted Contact","Trusted contact person under FINRA Rule 4512"),("Authorized Agent","Holder of an authority grant (attorney-in-fact, trading agent, guardian, conservator, executor, signer)"),("Beneficiary","Named beneficiary on a 15 Beneficiary Designation or a trust"),("Distributor Firm","Broker-dealer, RIA, bank, platform or TAMP in the intermediary channel; profile in 05"),("Branch / Office",""),("Advisor Team","External advisor team as a party; team structure is 05"),("Financial Advisor","External RR, IAR, private banker or plan advisor; profile in 05"),("Gatekeeper / Research",""),("Sub-Adviser","Sub-adviser to an own fund or manager of a managed account sleeve; role profile in 52 (CW-116)"),("External Fund Sponsor","Sponsor of a third-party fund, ETF or SMA strategy on the platform; role profile in 52 (CW-116)"),("Transition Manager","Manager that executes a portfolio transition; role profile in 52, the transition event in 12 (CW-116)"),("Home Office Contact","Product, marketing, operations"),("Institutional Client","Profile in 12"),("Investment Consultant / OCIO",""),("Plan Sponsor",""),("Retirement Plan",""),("Plan Participant","Participant in a plan the firm recordkeeps; referenced by 16"),("Recordkeeper",""),("Third-Party Administrator",""),("Custodian",""),("Clearing Firm",""),("Sub-Accounting Provider",""),("Beneficial Owner / Controller",""),("Fund Service Provider","Party referenced by 01 product party roles"),("Pricing Vendor","Evaluated pricing, market data or fair value factor vendor (22)"),("Index Administrator","Administrator of an index or interest rate benchmark (22, 01)"),("Valuation Agent","Third-party valuer of hard-to-value assets (22)"),("Quoting Broker","Broker-dealer giving price quotes used as valuation evidence (22)"),("Executing Broker","Broker that executes trades for the funds (25)"),("Clearing Broker / FCM","Clearing member through which a fund clears futures and swaps (25, 26)"),("Prime Broker","(25)"),("Step-Out Broker","(25)"),("OTC Derivative Counterparty","(25, 26)"),("FX Counterparty","(25)"),("Repo Counterparty","(25, 26)"),("Underwriter / Bookrunner","Underwriter or bookrunner of a new issue (25)"),("Research Provider","(23, 25)"),("TCA Provider","Transaction cost analysis provider (25)"),("Outsourced Trading Provider","(25)"),("Central Securities Depository","Depository that holds securities and settles instructions (26, 28)"),("Tri-Party Agent","(26, 28)"),("Collateral Segregation Custodian","Third-party custodian holding regulatory initial margin (26)"),("Trade Repository","CFTC swap data repository or SEC security-based swap data repository (26)"),("Loan Administrative Agent","(17, 26)"),("Sub-Custodian","Local bank appointed by the funds' global custodian (28)"),("Agent Lender","(28)"),("Securities Borrower","(28)"),("Tax Reclaim Agent","(28)"),("Class Action Claims Filer","(28)"),("Nominee Company","Company in whose name securities are registered (28)"),("Authorized Participant","ETF authorized participant (29)"),("Risk Model Vendor","(31)"),("Proxy Advisor","(34)"),("Proxy Voting Agent","(34)"),("Collaborative Engagement Initiative","(34)"),("Stewardship Framework Body","Body that grants signatory status on a stewardship code (34)"),("Independent Fund Director / Trustee","(35)"),("Independent Counsel to Fund Directors","(35)"),("Insurer","(37, 43)"),("External Model Validator","(37)"),("Co-Sourced Internal Audit Provider","(37)"),("Personal Account Broker","Broker holding an employee's reportable personal account (38)"),("Political Candidate / Committee","(38)"),("Outside Counsel","(39)"),("Opposing Party","(39)"),("Non-Executive Director","(39)"),("Attorney-in-Fact","Holder of a power of attorney granted by a group entity (39)"),("Supplier","(40)"),("ICT Third-Party Service Provider","Provider of technology services (40, 41)"),("Subcontractor","(40)"),("Staffing Agency","(40)"),("Security Testing Provider","Penetration or red team testing provider (41)"),("Journalist","(42)"),("Media Outlet","(42)"),("Government Official","(42)"),("Trade Association","(42)"),("Award Organizer","(42)"),("Newswire Service","(42)"),("Media Monitoring Provider","(42)"),("Reputation Research Provider","(42)"),("Lobbying Firm","(42)"),("Legislative Body / Government Agency","(42)"),("Relationship Bank","(43)"),("Corporate Lender","(43)"),("Insurance Broker","(43)"),("Landlord","(44)"),("Facility Service Provider","(44)"),("Card Issuer","(44)"),("Travel Management Company","(44)"),("Subtenant","(44)")]),
 "Record Status": ("Enterprise shared list 'Record Status' (steward 09; ISO/IEC 11179-6 registration status concepts) - values copied", [("Draft","Being authored; not yet submitted"),("Proposed","Submitted for approval"),("Pending","Approved or created but not yet effective"),("Active","Current and usable for new records"),("Paused","Temporarily not in use; expected to resume"),("Inactive","Not currently in use but may be reactivated"),("Deprecated","Valid for history, not for new records"),("Retired","Permanently withdrawn")]),
 "Business Line": ("Business lines of the wealth model (CW-004) - local copy until the shared list is re-cut", [("DB","Direct brokerage and self-directed investing"),("DA","Digital advice"),("HA","Human and hybrid advice"),("PF","Proprietary funds and ETFs (including CITs)"),("WR","Workplace retirement recordkeeping"),("IA","Institutional advisory"),("IC","Intermediary channel"),("TR","Personal trust services (optional)")]),
 "Marital Status": ("Internal", [("Single",""),("Married",""),("Domestic Partnership / Civil Union",""),("Separated",""),("Divorced",""),("Widowed",""),("Not Disclosed","")]),
 "Employment Status": ("SEC Rule 17a-3 / Internal", [("Employed",""),("Self-Employed",""),("Retired",""),("Unemployed",""),("Student",""),("Homemaker",""),("Not Applicable (Minor)","")]),
 "Regulator": ("Enterprise shared list 'Regulator' (steward 09) - US values copied (CW-039)", [("SEC","US Securities and Exchange Commission"),("FINRA","US self-regulatory organization for broker-dealers"),("US State Securities Regulator","Via NASAA / IARD notice filings"),("CFTC / NFA","Commodity pool operator and commodity trading adviser regulation"),("OCC","Office of the Comptroller of the Currency"),("US State Banking Regulator","For example for state-chartered trust companies"),("Federal Reserve",""),("DOL / EBSA","US Department of Labor, Employee Benefits Security Administration"),("IRS / US Treasury",""),("FinCEN","Financial Crimes Enforcement Network"),("OFAC","Office of Foreign Assets Control"),("US Department of Justice",""),("US State Attorney General",""),("MSRB","Municipal Securities Rulemaking Board"),("IOSCO","International standard setter")]),
 "Legal Entity Customer Exclusion Basis": ("31 CFR 1010.230(e) (confirm current text)", [("Not Excluded","Beneficial ownership certification required"),("Publicly Traded Company","Listed on a US exchange, or majority-owned domestic subsidiary"),("SEC-Registered Entity","Registered investment company, investment adviser, broker-dealer, exchange or clearing agency"),("Bank or Federally Regulated Financial Institution",""),("Government Entity","Federal, state or local government department or agency"),("State-Regulated Insurance Company",""),("Pooled Investment Vehicle Operated by an Excluded Entity",""),("Nonprofit - Control Prong Only","Charity or nonprofit: control prong only"),("Other Excluded Entity","Another exclusion in the rule; state it in the evidence")]),
 "Parent Relationship Basis": ("GLEIF LEI-CDF (Level 2)", [("Accounting Consolidation","Parent consolidates the entity in its financial statements"),("Majority Ownership",""),("Control (Non-Ownership)",""),("Fund Management","Fund managed by another entity"),("Unknown","")]),
 "Retirement Plan Type": ("DOL Form 5500 / IRC", [("401(k)",""),("403(b)",""),("457(b)",""),("Profit Sharing",""),("Money Purchase",""),("Defined Benefit",""),("Cash Balance",""),("Pooled Employer Plan (PEP)",""),("SIMPLE IRA","Recordkept on the IRA platform"),("SEP","")]),
 # Party Identifiers
 "Identifier Scheme": ("ISO 20022 / Internal", [("LEI",""),("BIC","ISO 9362 business identifier code (re-homed here as a scheme; CW-902)"),("FINRA CRD - Firm",""),("FINRA CRD - Individual",""),("FINRA CRD - Branch",""),("SEC File Number",""),("SEC CIK",""),("EIN",""),("EIN + Plan Number","Retirement plan key"),("NPN",""),("NSCC Participant Number",""),("DTC Participant Number",""),("TA Dealer Number",""),("Company Registration Number","State business entity filing number"),("GIIN","FATCA global intermediary identification number"),("Recordkeeper Participant ID","Participant identifier on the recordkeeping platform (16)"),("Vendor ID",""),("CRM ID","")]),
 "Identifier Status": ("Enterprise shared list 'Identifier Status' (steward 09) - values copied", [("Active",""),("Inactive",""),("Retired","Superseded or no longer issued"),("Unverified","")]),
 "LEI Registration Status": ("Enterprise shared list 'LEI Registration Status' (GLEIF LEI-CDF 3.1) - values copied", [("Pending Validation",""),("Issued",""),("Lapsed","Not renewed by the due date"),("Merged",""),("Retired",""),("Annulled",""),("Duplicate",""),("Transferred",""),("Pending Transfer",""),("Pending Archival","")]),
 # Households & Relationships
 "Household Formation Basis": ("Internal / Salesforce FSC (who formed the household; composition is read from the members)", [("Client Defined","Members named by the client (governs)"),("Advisor Proposed - Client Confirmed",""),("System Suggested - Unconfirmed","Shared address, surname or account roles; memberships held as Proposed")]),
 "Household Member Role": ("Salesforce FSC", [("Head of Household",""),("Spouse / Domestic Partner",""),("Dependent",""),("Other Family Member",""),("Trust or Entity","Entity party grouped with the household"),("Other","")]),
 "Party Relationship Type": ("Internal (aligned to Salesforce FSC / BIAN)", [("Spouse Of",""),("Domestic Partner Of",""),("Parent Of",""),("Child Of",""),("Sibling Of",""),("Other Relative Of",""),("Friend Of",""),("Trustee Of","Trustee or successor trustee of a trust party; Derived row of 51 Trust Role for trusts with a 51 record (CW-075)"),("Grantor Of","Grantor or settlor of a trust party; Derived row of 51 Trust Role for trusts with a 51 record (CW-075)"),("Trust Beneficiary Of","Current beneficiary of a trust party; Derived row of 51 Beneficial Interest for trusts with a 51 record (CW-075)"),("Control Person Of","Individual with significant responsibility to control an entity"),("Officer Of",""),("Employs",""),("Subsidiary Of",""),("Sponsors","Employer sponsors a retirement plan"),("Advises","External advisor advises a client (IC line)"),("Consults For",""),("Services Plan",""),("Custodies For",""),("Clears For",""),("Refers / Introduces","")]),
 # Authorized Persons & Life Events
 "Authority Type": ("Uniform Power of Attorney Act / Internal", [("Durable Power of Attorney",""),("Limited Power of Attorney",""),("Springing Power of Attorney","Effective on a stated event, typically incapacity"),("Trading Authorization","Agent authority over accounts; its powers are the Authority Scope"),("Guardian","Court-appointed guardian of a minor or incapacitated adult"),("Conservator",""),("Executor / Personal Representative",""),("Estate Administrator",""),("Small Estate Affiant",""),("Entity Authorized Signer","Officer, partner or manager authorized by resolution")]),
 "Authority Scope": ("Internal (powers only; account coverage is Accounts Covered)", [("Full Authority","All powers the instrument allows"),("Trading Only",""),("Trading and Disbursements to Owner",""),("Third-Party Disbursements Allowed",""),("Information Access Only","")]),
 "Trusted Contact Status": ("FINRA Rule 4512 / Internal", [("Provided",""),("Declined by Client",""),("Requested - Not Provided","Reasonable efforts made, no response"),("Not Required - Institutional Account","FINRA Rule 4512(a)(1)(F) does not apply")]),
 "Case Status": ("Enterprise shared list 'Case Status' (steward 09; aligned to Salesforce Service Cloud / FSC case status) - values copied", [("New / Received","Logged, not yet worked"),("Pending Good Order","Awaiting documents or information needed to process"),("In Progress",""),("Waiting on Client",""),("Pending Third Party","Raised with a vendor, intermediary or other third party"),("Escalated",""),("Resolved / Completed","Request fulfilled or issue fixed"),("Closed","Closed after resolution and any confirmation"),("Rejected","Not accepted or not in good order"),("Canceled","")]),
 # Investor Profile
 "Profile Scope": ("Internal", [("Individual",""),("Joint","Joint owners profiled together"),("Household","One profile for the Client Household"),("Entity","Trust, estate or other entity")]),
 "Investment Objective": ("FINRA Rule 2111 / SEC Rule 17a-3 / Internal", [("Capital Preservation",""),("Income",""),("Growth and Income",""),("Growth",""),("Aggressive Growth",""),("Speculation","")]),
 "Risk Tolerance": ("FINRA Rule 2111 / Internal", [("Conservative",""),("Moderately Conservative",""),("Moderate",""),("Moderately Aggressive",""),("Aggressive","")]),
 "Time Horizon": ("FINRA Rule 2111 / Internal", [("Under 3 Years",""),("3 to 5 Years",""),("6 to 10 Years",""),("11 to 20 Years",""),("Over 20 Years","")]),
 "Liquidity Need": ("FINRA Rule 2111 / Internal", [("Very Important",""),("Somewhat Important",""),("Not Important","")]),
 "Income Band": ("Internal", [("USD 0 - 24,999",""),("USD 25,000 - 49,999",""),("USD 50,000 - 99,999",""),("USD 100,000 - 199,999",""),("USD 200,000 - 299,999",""),("USD 300,000 - 499,999",""),("USD 500,000 - 999,999",""),("USD 1,000,000 or more","")]),
 "Net Worth Band": ("Internal (net worth excludes the primary residence)", [("USD 0 - 49,999",""),("USD 50,000 - 99,999",""),("USD 100,000 - 249,999",""),("USD 250,000 - 499,999",""),("USD 500,000 - 999,999",""),("USD 1,000,000 - 2,499,999",""),("USD 2,500,000 - 4,999,999",""),("USD 5,000,000 - 9,999,999",""),("USD 10,000,000 - 24,999,999",""),("USD 25,000,000 or more","Top band split at W5 (CW-160 proposal; 02 steward, 11 follows): ultra-high-net-worth threshold")]),
 "Profile Trigger": ("Internal", [("Account Opening",""),("Client-Initiated Update",""),("Rule 3a-4 Annual Contact","Annual contact of an advisory program client; a new attested version even when nothing changed"),("Rule 17a-3 Account Record Update","Periodic furnishing of the account record"),("Life Event",""),("Advice Engagement","Planning or advice review (45)"),("Options or Margin Application",""),("Data Correction","")]),
 "Product Experience Type": ("FINRA Rule 2360 / Internal", [("Stocks",""),("Bonds",""),("Mutual Funds",""),("ETFs",""),("Options",""),("Margin",""),("Annuities",""),("Alternative Investments",""),("Futures","")]),
 "Investor Qualification Standard": ("Enterprise shared list 'Investor Qualification Standard' (steward 02) - US values copied (CW-039)", [("None Evidenced","No qualification standard evidenced for the party"),("Accredited Investor","Reg D Rule 501(a)"),("Qualified Client","Advisers Act Rule 205-3 (performance fee eligibility)"),("Qualified Purchaser","ICA 1940 s.2(a)(51) (3(c)(7) funds)"),("Qualified Institutional Buyer","Securities Act Rule 144A")]),
 "Qualification Basis": ("SEC Regulation D Rule 501(a) / Advisers Act Rule 205-3 / ICA Section 2(a)(51) (confirm current thresholds)", [("Income - Individual",""),("Income - Joint or Spousal Equivalent",""),("Net Worth","Excluding the primary residence"),("Professional Certification","Series 7, 65 or 82 in good standing"),("Knowledgeable Employee",""),("Entity Assets",""),("Entity Owned by Qualified Investors",""),("Investments Threshold","Qualified purchaser investments test"),("Assets Under Management with the Adviser","Qualified client assets test"),("Net Worth Threshold - Qualified Client","")]),
 "Qualification Verification Method": ("SEC Regulation D Rule 506(c) / Internal", [("Self-Certification",""),("Third-Party Verification Letter","From a broker-dealer, adviser, attorney or CPA"),("Document Review","Tax returns, statements or credit report reviewed"),("Professional License Check",""),("Existing Relationship Evidence","")]),
 # KYC, Identity & Tax
 "KYC Case Type": ("Internal", [("New Client Onboarding",""),("New Account for Existing Client",""),("Related Party Onboarding","Trusted contact, agent, beneficial owner"),("Periodic Review",""),("Trigger Event Review",""),("Remediation","")]),
 "KYC Status": ("Internal", [("Not Started",""),("In Progress",""),("Complete",""),("Expired","Periodic review overdue"),("Failed","")]),
 "Risk Rating": ("Enterprise shared list 'Risk Rating' (steward 09) - values copied", [("Low",""),("Medium",""),("High",""),("Critical","Highest acceptable rating; requires senior approval and enhanced monitoring"),("Prohibited","Outside risk appetite; relationship not permitted")]),
 "Due Diligence Level": ("31 CFR 1010.230 / 1010.610 / 1010.620", [("Standard CDD",""),("Enhanced Due Diligence","Risk-based enhanced measures"),("Special Due Diligence","Private banking or correspondent accounts for non-US persons (USA PATRIOT Act section 312)")]),
 "PEP Status": ("31 CFR 1010.605 and 1010.620 / FATF / Internal", [("Not a PEP",""),("Senior Foreign Political Figure",""),("Domestic PEP","Firm policy"),("International Organization PEP","Firm policy"),("Immediate Family / Close Associate",""),("Former PEP","")]),
 "Screening Result": ("Enterprise shared list 'Screening Result' (steward 08) - values copied", [("No Match","Screening returned no potential match"),("Potential Match - Under Review","Alert raised; disposition pending"),("False Positive","Alert reviewed and discounted"),("Confirmed Match","Alert reviewed and confirmed as a true match")]),
 "CIP Program": ("31 CFR 1023.220, 1024.220, 1020.220", [("Broker-Dealer CIP","31 CFR 1023.220"),("Mutual Fund CIP","31 CFR 1024.220; run through the in-house transfer agent"),("Trust Company CIP","31 CFR 1020.220; optional trust services (TR)")]),
 "Verification Method": ("31 CFR 1023.220(a)(2)", [("Documentary",""),("Non-Documentary - Database","Consumer reporting agency or public database comparison"),("Non-Documentary - Knowledge-Based",""),("Non-Documentary - Financial Statement or Reference",""),("Combined",""),("Reliance on Another Financial Institution","Permitted reliance under the CIP rule")]),
 "Identity Document Type": ("31 CFR 1023.220 / Internal", [("US Driver's License",""),("State Identification Card",""),("US Passport",""),("Foreign Passport",""),("Permanent Resident Card",""),("Military Identification",""),("Certificate of Formation / Articles","Entity"),("Trust Agreement / Certification of Trust","Entity"),("Letters Testamentary / of Administration","Estate"),("Government-Issued Business License","Entity")]),
 "Verification Result": ("Internal", [("Verified",""),("Verified - Discrepancy Resolved",""),("Pending",""),("Unable to Verify","Account not opened or closed under CIP procedures"),("Failed","")]),
 "Beneficial Ownership Prong": ("31 CFR 1010.230(d)", [("Ownership","Each individual owning 25% or more of the equity interests"),("Control","Single individual with significant responsibility to control, manage or direct the entity")]),
 "Tax Classification": ("IRS Form W-9 / Form W-8", [("Individual / Sole Proprietor",""),("C Corporation",""),("S Corporation",""),("Partnership",""),("Trust / Estate",""),("LLC - C Corporation",""),("LLC - S Corporation",""),("LLC - Partnership",""),("Tax-Exempt Organization",""),("Government Entity",""),("Other","")]),
 "TIN Type": ("IRS", [("SSN",""),("ITIN",""),("EIN",""),("ATIN","Adoption taxpayer identification number"),("Foreign TIN",""),("Applied For","")]),
 "FATCA Status": ("IRC Chapter 4 / IRS Form W-8BEN-E", [("US Person",""),("Exempt Beneficial Owner",""),("Participating FFI",""),("Registered Deemed-Compliant FFI",""),("Active NFFE",""),("Passive NFFE",""),("Nonparticipating FFI",""),("Foreign Individual","Nonresident alien beneficial owner")]),
 # Classification & Segmentation
 "Investor Category": ("Enterprise shared list 'Investor Category' (steward 02) - US values copied (CW-039)", [("Retail","US retail investor (FINRA Rule 2210)"),("Institutional","FINRA Rule 4512(c) institutional account or equivalent"),("Financial Professional","US registered representatives and investment adviser representatives")]),
 "Segmentation Scheme": ("Internal", [("Client Value Segment",""),("Life Stage",""),("Wealth Tier",""),("Digital Engagement Segment",""),("Advice Propensity",""),("Workplace-to-Retail Conversion Propensity","")]),
 "Assignment Method": ("Internal", [("Rule-Based Threshold",""),("Model Score",""),("Manual Override",""),("Grandfathered","Kept after falling below the threshold"),("Program Eligibility","Employee or affiliate program")]),
 # Contact Points & Preferences
 "Contact Channel": ("Internal / Salesforce FSC", [("Postal Address",""),("Email",""),("Mobile Phone","TCPA applies to automated calls and texts"),("Landline Phone",""),("Fax","")]),
 "Contact Point Usage": ("FINRA Rule 4512 / Internal", [("Legal Residence","Residential address of record"),("Mailing",""),("Business",""),("Seasonal / Alternate",""),("Registered Office","Entity"),("Principal Place of Business","Entity")]),
 "Communication Channel": ("Internal", [("Email",""),("SMS",""),("Postal Mail",""),("Telephone",""),("Push Notification",""),("Secure Message","Message center in the client website or app")]),
 "Opt-In Status": ("Internal", [("Opted In",""),("Pending Confirmation","Awaiting double opt-in"),("Opted Out",""),("Not Set","No preference recorded")]),
 # Privacy & Consent
 "Privacy Regime": ("Internal", [("GLBA / Regulation S-P",""),("FCRA Affiliate Marketing / Regulation S-AM",""),("CCPA / CPRA",""),("Other US State Privacy Law",""),("State Financial Privacy Law","For example the California Financial Information Privacy Act")]),
 "Personal Data Category": ("Enterprise shared list 'Personal Data Category' (steward 02) - values copied", [("No Personal Data",""),("Identity","Name, date of birth and other identity attributes"),("Contact","Business or personal contact details"),("Professional / Employment","Employer, role and professional history of an external individual"),("Registration / Licensing","Regulatory registrations and licenses"),("HR / Employee","Own-employee HR data (not used in 02)"),("Financial","Holdings, transactions, account and payment data"),("Government Identifier","SSN, passport, national ID; sensitive under the CPRA"),("Online Identifiers / Engagement","Cookies, device IDs and digital engagement data"),("Inferences / Segmentation","Profiles, scores and segments derived about the individual"),("Opinion About Individual","Recorded opinions or assessments about a person"),("Free Text - May Contain Personal Data","Unstructured notes that may contain personal data")]),
 "Consent Purpose": ("E-SIGN Act / TCPA / FDX / Internal", [("Electronic Delivery (E-SIGN)","Consent to receive required documents electronically; 13 E-Delivery Election links it"),("Account Aggregation Data Access","Firm reads the client's accounts held elsewhere"),("Third-Party Data Sharing (FDX)","Client authorizes an aggregator or app to read data held at the firm"),("Call Recording",""),("Voice Biometrics Enrollment",""),("Marketing Email",""),("Marketing Text Messages","Prior express written consent under the TCPA"),("Marketing Telephone","")]),
 "Consent Status": ("Internal", [("Granted",""),("Withdrawn",""),("Expired",""),("Declined","")]),
 "Consent Capture Method": ("Internal", [("Web Form - Single Opt-In",""),("Web Form - Double Opt-In",""),("Mobile App",""),("Electronic Signature Ceremony",""),("Recorded Verbal",""),("Paper Form",""),("OAuth Authorization","FDX or open-banking style token grant")]),
 "Privacy Request Type": ("CCPA / CPRA (Cal. Civ. Code 1798.100 to 1798.125)", [("Know - Categories",""),("Access - Specific Pieces","Includes a portable copy"),("Delete",""),("Correct",""),("Opt Out of Sale / Sharing",""),("Limit Use of Sensitive Personal Information","")]),
 # Restrictions & Protections
 "Client Restriction Category": ("Internal", [("Investment Exclusion","Values-based or issuer exclusions; Rule 3a-4 reasonable restrictions"),("Security-Specific Restriction","For example employer stock or a security the client is an insider of"),("Product Eligibility","Products the client may not hold or be offered"),("Contact & Engagement","Rules on who may contact the client and how"),("Data Use","Limits on use of the client's data"),("Regulatory","Restrictions required by law or regulator")]),
 "Client Restriction Source": ("Internal", [("Client Instruction",""),("Firm Policy",""),("Regulatory",""),("Internal Compliance","")]),
 "Restricted Client Status": ("Internal", [("None",""),("Watch","Engage with heightened review"),("Restricted","Engagement only with Compliance approval"),("Prohibited","No new business; exit the relationship")]),
 "Restricted Status Reason": ("Internal", [("Sanctions Match",""),("AML Risk",""),("Fraud",""),("Abusive Conduct",""),("Regulatory Action",""),("Litigation",""),("Compliance Hold",""),("Reputational","")]),
 "Specified Adult Basis": ("FINRA Rule 2165(a)(1)", [("Age 65 or Older",""),("Age 18 or Older - Reasonable Belief of Impairment","Mental or physical impairment that renders the individual unable to protect their own interests")]),
 "Vulnerability Concern Type": ("FINRA Rule 2165 / Internal (special category, CD-344)", [("Suspected Financial Exploitation","By a person known to the client: family member, caregiver, agent or advisor"),("Diminished Capacity",""),("Undue Influence",""),("Scam or Fraud Victim","By an unknown third party: impostor, romance or investment scam"),("Financial Hardship",""),("Recent Bereavement",""),("Other","")]),
}

# ---------------------------------------------------------------------------
REL = [
 ("Party","plays","Party Role","1 : 0..n","Effective-dated; one party, many roles (CD-143)."),
 ("Party","is described by","Individual / Organization / Retirement Plan / Household","1 : 0..1","Attribute groups by Party Type."),
 ("Investor Qualification","describes","Party","n : 1","Attribute group of the party, keyed by PTY- and the qualification standard."),
 ("Party","is identified by","Party Identifier","1 : 0..n","LEI, BIC, CRD, SEC, NSCC, DTC, EIN + plan number, vendor IDs; never a Social Security number."),
 ("Party Identifier","is detailed by","LEI Record","1 : 0..1","LEI scheme only."),
 ("Party (Organization)","is a subsidiary of","Party (Organization) via Legal Entity Hierarchy","n : 0..n","GLEIF Level 2 where available."),
 ("Retirement Plan (Party)","is sponsored by","Party (Plan Sponsor)","n : 1","Plan identity only; administration is 16."),
 ("Household (Party, PTY-HH-)","groups","Party via Household Membership","1 : 1..n","Client Household (CW-027); effective dated."),
 ("Household (Party)","is distinct from","Householding Group [13] / Fee Household [47]","n : n","13 MHG- groups mailings; 47 groups accounts for breakpoints; both may reference 02 membership but are not it."),
 ("Party","relates to","Party via Party Relationship","n : n","Spouse, parent, guardian, trustee, executor, control person, subsidiary."),
 ("Authority Grant","is granted by","Party (Grantor)","n : 1",""),
 ("Authority Grant","is held by","Party (Authority Holder)","n : 1",""),
 ("Authority Grant","covers","Account [15]","n : 0..n","Blank means all current and future accounts."),
 ("Authority Grant","is received through","Service Request [13]","n : 0..1",""),
 ("Trusted Contact Designation","is made by","Party (Client)","n : 1","FINRA Rule 4512."),
 ("Trusted Contact Designation","names","Party (Trusted Contact Person)","n : 0..1","Blank when declined."),
 ("Trusted Contact Designation","applies to","Account [15]","n : 0..n","Account scope; blank means all accounts."),
 ("Death Notification","concerns","Party (Individual)","n : 1","Sets Individual Date of Death once confirmed."),
 ("Death Notification","recognizes the representative under","Authority Grant","n : 0..1","Letters testamentary or small-estate affidavit."),
 ("Investor Profile","describes","Party (Client or Client Household)","n : 1","Versioned (CW-024)."),
 ("Investor Profile","records","Investment Experience","1 : 0..n","One row per product type."),
 ("Investor Profile","is referenced by","Account Investment Profile [15]","1 : 0..n","15 references the version it was set against; never copies (CW-024)."),
 ("Investor Profile","is referenced by","Options Approval Detail [15]","1 : 0..n","Options and margin approvals name the version used."),
 ("Investor Profile","is relied on by","Recommendation [45]","1 : 0..n","45 references the version (W2)."),
  ("Investor Qualification","is read by","Alternative Investment Subscription [15]","1 : 0..n","Feeder fund eligibility."),
 ("Onboarding Case","onboards or reviews","Party","n : 1",""),
 ("Onboarding Case","opens","Account [15]","1 : 0..n","15 Account Opening references the case."),
 ("Identity Verification","verifies","Party","n : 1","One per party per CIP program (CW-025)."),
 ("Identity Verification","satisfies the program of","Internal Legal Entity [09]","n : 1",""),
 ("Identity Verification","is referenced by","Account Opening [15]","1 : 0..n",""),
 ("Identity Verification","replaces at W3","CIP Verification [29]","1 : 0..1","29 CIP- becomes a reference to KYCV- at W3 (CW-025)."),
 ("Beneficial Ownership Certification","certifies","Party (Legal Entity Customer)","n : 1","31 CFR 1010.230."),
 ("Beneficial Ownership Certification","is obtained under","Onboarding Case","n : 0..1",""),
 ("Beneficial Ownership Certification","lists","Beneficial Ownership","1 : 1..n",""),
 ("Beneficial Ownership","names","Party (Individual)","n : 1",""),
 ("Beneficial Ownership","is verified by","Identity Verification","n : 0..1",""),
 ("KYC Profile","is escalated to","AML Case [38]","1 : 0..n","38 references the KYC Profile and Identity Verification."),
 ("Tax Profile","is evidenced by","Account Tax Certification [15]","1 : 0..1","Form W-9 or W-8 on file."),
 ("Service Tier Assignment","assigns","Service Tier [01]","n : 1","CW-028."),
 ("Service Tier Assignment","qualifies on","Client Assets [06]","n : 1","Derived copy; future owner 06, W4."),
 ("Segment Assignment","segments","Party (Client or Client Household)","n : 1",""),
 ("Contact Point","belongs to","Party","n : 1",""),
 ("Contact Point","is located at","Postal Address","1 : 0..1","Postal contact points only."),
 ("Contact Preference","prefers","Contact Point","n : 0..1",""),
 ("Communication Preference","applies to","Subscription Topic [04]","n : 0..1",""),
 ("Communication Preference","relies on","Consent Record","n : 0..1",""),
 ("Consent Record","is linked from","E-Delivery Election [13]","1 : 0..n","13 DEL- holds the link."),
 ("Privacy Profile","records notice delivery via","Shareholder Communication [13]","1 : 0..1","Initial privacy notice."),
 ("Consumer Privacy Request","is raised by","Party","n : 1",""),
 ("Client Restriction","applies to","Account [15]","n : 0..n","Blank means all accounts."),
 ("Client Restriction","excludes","Instrument [17]","n : 0..n",""),
 ("Client Restriction","is applied by","Managed account targets and constraints [46]","1 : 0..n","46 (W2) reads Rule 3a-4 restrictions."),
 ("Restricted Client Status","may arise from","AML Case [38]","n : 0..1","Restricted reference."),
 ("Vulnerability Concern","concerns","Party (client; often a specified adult)","n : 1","Special category (CD-344)."),
 ("Vulnerability Concern","uses","Trusted Contact Designation","n : 0..1",""),
 ("Vulnerability Concern","is referenced by","Account Restriction [15]","1 : 0..n","FINRA Rule 2165 temporary hold; 15 holds the link (VCON-), not 02."),
 ("Vulnerability Concern","is referenced by","Money Movement Hold [50]","1 : 0..n","50 holds the link (W3)."),
 ("Vulnerability Concern","is escalated to","Senior Investor Case [08]","n : 0..1","SNRC-; Agency Referral Date is copied from the case's earliest External Protection Report."),
 ("Party","is cross-referenced to","Employee [20]","0..1 : 0..1","Employee clients."),
]

# ---------------------------------------------------------------------------
SRC = [
 ("FINRA Rule 4512 Customer Account Information","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/4512","Rule (public)","Customer account record content, employer and occupation, associated person status, trusted contact person (age 18 or older, reasonable efforts, written disclosure), institutional account definition 4512(c)","Individual, Trusted Contact Designation, Contact Point, Regulatory Classification",["FINRA Rule 4512"]),
 ("FINRA Rule 2165 Financial Exploitation of Specified Adults","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2165","Rule (public)","Specified adult definition, temporary holds on disbursements and transactions, contact with the trusted contact (confirm current hold periods after the 2022 amendments)","Specified Adult Status, Vulnerability Concern, Trusted Contact Designation",["FINRA Rule 2165"]),
 ("FINRA Rules 2090 Know Your Customer and 2111 Suitability","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2111","Rule (public)","Essential facts, customer investment profile (age, other investments, financial situation and needs, tax status, objectives, experience, time horizon, liquidity needs, risk tolerance)","Investor Profile, Investment Experience, KYC Profile",["FINRA Rule 2090","FINRA Rule 2111"]),
 ("FINRA Rule 3210 Accounts At Other Broker-Dealers and Financial Institutions","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/3210","Rule (public)","Consent and duplicate statements for accounts of associated persons; drives the associated person disclosure","Individual, Party",["FINRA Rule 3210"]),
 ("FINRA Rule 2360 Options","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2360","Rule (public)","Options account approval information: investment experience and knowledge by product","Investment Experience",["FINRA Rule 2360"]),
 ("FINRA Rules 2210 Communications with the Public, 3230 Telemarketing and 3310 AML Compliance Program","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules","Rules (public)","Institutional investor definition, firm-specific do-not-call duties, AML program and risk-based CDD","Regulatory Classification, Privacy Profile, KYC Profile",["FINRA Rule 2210","FINRA Rule 3230","FINRA Rule 3310"]),
 ("SEC Rule 17a-3 Records to be made by certain exchange members, brokers and dealers (paragraph (a)(17))","US SEC","https://www.ecfr.gov/current/title-17/section-240.17a-3","Regulation (public)","Account record content (name, TIN, address, date of birth, employment status, annual income, net worth excluding primary residence, investment objectives) and the periodic furnishing cycle","Individual, Investor Profile",["SEC Rule 17a-3"]),
 ("Regulation Best Interest (Exchange Act Rule 15l-1) and Form CRS","US SEC","https://www.ecfr.gov/current/title-17/section-240.15l-1","Regulation (public)","Retail customer definition and retail customer investment profile","Regulatory Classification, Investor Profile",["SEC Reg BI","SEC Form CRS"]),
 ("Investment Company Act Rule 3a-4 (advisory programs)","US SEC","https://www.ecfr.gov/current/title-17/section-270.3a-4","Regulation (public)","Annual contact to update the client's financial situation and objectives; reasonable restrictions on management of the account","Investor Profile (trigger), Client Restriction",["ICA Rule 3a-4"]),
 ("Customer identification program rules: 31 CFR 1023.220 (broker-dealers), 1024.220 (mutual funds), 1020.220 (banks and trust companies)","FinCEN / US Treasury","https://www.ecfr.gov/current/title-31/section-1023.220","Regulation (public)","Minimum identifying information, documentary and non-documentary verification, discrepancy resolution, government list comparison, customer notice, reliance, five-year retention (confirm eCFR paths for 1024.220 and 1020.220)","Identity Verification, CIP Program, Verification Method",["31 CFR 1023.220","31 CFR 1024.220","31 CFR 1020.220"]),
 ("Customer due diligence and beneficial ownership rule 31 CFR 1010.230; due diligence for private banking 1010.620","FinCEN / US Treasury","https://www.ecfr.gov/current/title-31/section-1010.230","Regulation (public)","Ownership and control prongs, legal entity customer exclusions, certification, risk-based updating; FinCEN Order No. 2026-01 (13 February 2026) relieves covered brokers, dealers and mutual funds from re-identifying beneficial owners at each new account","Beneficial Ownership Certification, Beneficial Ownership, Organization, KYC Profile",["31 CFR 1010.230","31 CFR 1010.610","31 CFR 1010.620","31 CFR 1023.320"]),
 ("OFAC Sanctions List Service","US Treasury, OFAC","https://ofac.treasury.gov","Public list","SDN and consolidated lists used in sanctions screening","KYC Profile",["OFAC"]),
 ("FATF Recommendations (politically exposed persons)","FATF","https://www.fatf-gafi.org","International standard (public)","PEP categories used alongside the US senior foreign political figure definition","KYC Profile (PEP Status)",["FATF"]),
 ("Regulation S-P (17 CFR Part 248, Subpart A) and Regulation S-AM (Subpart B); GLBA","US SEC","https://www.ecfr.gov/current/title-17/part-248","Regulation (public)","Privacy notices, nonaffiliated sharing opt-out, affiliate marketing opt-out and its five-year duration (confirm the 2024 Reg S-P amendment compliance dates)","Privacy Profile, Privacy Regime",["SEC Regulation S-P","SEC Regulation S-AM","GLBA","FCRA"]),
 ("California Consumer Privacy Act as amended by the CPRA; other US state privacy laws","California Attorney General / California Privacy Protection Agency","https://oag.ca.gov/privacy/ccpa","Statute and regulations (public)","Consumer rights and request types, response periods, opt-out preference signals, GLBA data exemption (confirm section 1798.145(e))","Privacy Profile, Consumer Privacy Request",["CCPA / CPRA","US State Privacy Laws"]),
 ("Electronic Signatures in Global and National Commerce Act (E-SIGN), 15 U.S.C. 7001","US Congress / Legal Information Institute","https://www.law.cornell.edu/uscode/text/15/7001","Statute (public)","Consumer consent to electronic records, required disclosures, demonstrated ability to access","Consent Record",["E-SIGN Act"]),
 ("Telephone Consumer Protection Act (47 U.S.C. 227) and CAN-SPAM Act","US Congress / FTC / FCC","https://www.law.cornell.edu/uscode/text/47/227","Statute (public)","Prior express written consent for marketing texts and calls; email opt-out within 10 business days","Communication Preference, Consent Purpose, Contact Preference",["TCPA","CAN-SPAM Act"]),
 ("Senior Safe Act (section 303 of the Economic Growth, Regulatory Relief, and Consumer Protection Act, 2018)","US Congress","https://www.congress.gov/bill/115th-congress/senate-bill/2155","Statute (public)","Immunity for reporting suspected exploitation of seniors to agencies after training (confirm section)","Vulnerability Concern (agency referral)",["Senior Safe Act"]),
 ("Regulation D Rule 501(a), Advisers Act Rule 205-3, Investment Company Act section 2(a)(51), Securities Act Rule 144A","US SEC","https://www.ecfr.gov/current/title-17/section-230.501","Regulation (public)","Accredited investor, qualified client, qualified purchaser and qualified institutional buyer tests; Rule 506(c) verification","Investor Qualification, Qualification Basis",["SEC Regulation D","SEC Rule 205-3","ICA Section 2(a)(51)","SEC Rule 144A"]),
 ("IRS Forms W-9, W-8BEN and W-8BEN-E; FATCA (IRC chapter 4); IRC 7701","US IRS","https://www.irs.gov/forms-pubs/about-form-w-9","Public forms and instructions","US person status, federal tax classification, TIN types, foreign status and chapter 4 status","Tax Profile",["IRS Form W-9","IRS Form W-8BEN","IRS Form W-8BEN-E","FATCA","IRC 7701","IRS"]),
 ("SEC Rule 17Ad-17 Lost securityholders and unresponsive payees","US SEC","https://www.ecfr.gov/current/title-17/section-240.17Ad-17","Regulation (public)","Returned mail starts the lost securityholder database search","Postal Address (Mail Returned Date)",["SEC Rule 17Ad-17"]),
 ("USPS Publication 28 Postal Addressing Standards","US Postal Service","https://pe.usps.com/text/pub28/welcome.htm","Public standard","Address standardization, ZIP+4, delivery point validation","Postal Address, Contact Point",["USPS Publication 28"]),
 ("GLEIF LEI-CDF 3.1 and Level 2 relationship data; ISO 17442","GLEIF / ISO","https://www.gleif.org/en/lei-data","Open data / ISO standard","LEI record, registration status, registration authority, parent relationships","LEI Record, Legal Entity Hierarchy, Organization",["GLEIF*","ISO 17442*"]),
 ("ISO 20275 Entity Legal Forms (ELF)","ISO / GLEIF","https://www.gleif.org/en/about-lei/code-lists/iso-20275-entity-legal-forms-code-list","ISO standard (code list public)","Entity legal form codes","Organization",["ISO 20275"]),
 ("ISO 20022 party components (PartyIdentification, PostalAddress)","ISO","https://www.iso20022.org","ISO standard","Party identification schemes and postal address structure","Party Identifier, Postal Address",["ISO 20022"]),
 ("FIBO - Business Entities (BE) and Financial Business & Commerce (FBC)","EDM Council / OMG","https://spec.edmcouncil.org/fibo/","Open ontology","Party, legal person, natural person, party role","Party, Party Role, Organization",["FIBO*"]),
 ("BIAN Party Reference Data Directory","BIAN","https://bian.org/semantic-apis/party-reference-data-directory/","Open standard","Party reference data service domain","Party, Party Role",["BIAN"]),
 ("Salesforce Financial Services Cloud data model (Person Account, Household, Party Relationship Group, Contact Point and consent objects)","Salesforce","https://developer.salesforce.com/docs/platform/data-models/guide/fsc-customer.html","Vendor documentation (public; confirm path)","Household structure, member roles, contact points; cross-check only","Household, Household Membership, Contact Point",["Salesforce FSC"]),
 ("Financial Data Exchange (FDX) API","Financial Data Exchange","https://financialdataexchange.org","Industry standard (members)","Consumer-permissioned data sharing, consent duration and revocation","Consent Record, Consent Purpose",["FDX API"]),
 ("FINRA CRD and BrokerCheck; SEC IAPD, Form ADV, Form BD and EDGAR; NIPR","FINRA / US SEC / NIPR","https://www.finra.org/registration-exams-ce","Public registers","Firm and individual CRD numbers, SEC file numbers, CIK, national producer numbers","US Regulatory Identifier",["FINRA CRD","FINRA BrokerCheck","SEC Form ADV","SEC Form BD","SEC EDGAR","NIPR"]),
 ("DTCC / NSCC and DTC participant directories","DTCC","https://www.dtcc.com","Commercial service","NSCC and DTC participant numbers, Fund/SERV and Networking dealer numbers","Market Infrastructure & Vendor Identifier",["DTCC / NSCC"]),
 ("DOL Form 5500 and ERISA","US DOL, EBSA","https://www.dol.gov/agencies/ebsa/employers-and-advisers/plan-administration-and-compliance/reporting-and-filing/form-5500","Public forms","Plan name, plan number, plan type, sponsor EIN","Retirement Plan",["DOL Form 5500","ERISA"]),
 ("Uniform Power of Attorney Act","Uniform Law Commission","https://www.uniformlaws.org","Model act (public; confirm the act page)","Durable, limited and springing powers, agent authority, termination","Authority Grant, Authority Type",["Uniform Power of Attorney Act"]),
 ("SEC Division of Investment Management Guidance Update 2017-02 (robo-advisers)","US SEC","https://www.sec.gov/investment/im-guidance-2017-02.pdf","Public guidance (confirm path)","Questionnaire design and client information for digital advice","Investor Profile (questionnaire)",["SEC IM Guidance 2017-02"]),
 ("ISO 3166, ISO 639, ISO 8601, ITU-T E.164; NAICS","ISO / ITU / US Census Bureau","https://www.census.gov/naics/","Standards","Country and subdivision codes, languages, dates, phone numbers, industry codes","Party, Postal Address, Contact Point, Organization",["ISO 3166","ISO 639","ITU-T E.164","US Census NAICS"]),
]
