"""Data Domain 03 - Advisor Organization, Coverage & Supervision (wealth-manager reference model; replaces the wholesale 03 Sales
and absorbs the coverage and incentive objects of 07 Compensation & Territory, CW-013, CW-061 to CW-065, CW-080).
Content module for taxonomy_builder.py."""

META = {
 "title": "Advisor Organization, Coverage & Supervision Data Taxonomy",
 "subtitle": "Business domain 03 - Advisor Organization, Coverage & Supervision | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "03_Advisor_Organization_Coverage_and_Supervision/Advisor_Organization_Coverage_and_Supervision_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the advice organization of a US wealth manager that serves investors directly: self-directed brokerage, digital and human advice, its own mutual funds and ETFs, workplace retirement recordkeeping, institutional advisory, a thin intermediary channel and optional personal trust services. The domain masters who serves which client: the advisor profile of each employee who advises or services clients, the coverage teams they work in, the branch offices and offices of supervisory jurisdiction (OSJs) of the broker-dealer and the supervisory structure FINRA Rule 3110 requires, the coverage and service models each client tier receives, the advisor or team each household is assigned to and how much capacity each advisor has, what advisors did with clients, the referrals that move clients between channels, and the incentive and recognition plans that pay for the work. It is stitched together from FINRA Rules 3110, 1210, 1220, 3220 and 2341, SEC Rule 203A-3, Regulation Best Interest (Exchange Act Rule 15l-1), SEC Rule 17a-4 and Advisers Act Rule 204-2, Investment Company Act Rule 3a-4, the CFP Board Code of Ethics and Standards of Conduct, and the Salesforce Financial Services Cloud advisor and interaction model as a cross-check. Use it as a starting point for a CRM and book-of-business data model, a supervisory structure register, an incentive plan design record or a business glossary."),
  ("Scope", "In scope: the Advisor profile of a 20 employee (EMP-) with role assignments, credentials, languages, specialties, the entities represented and a Derived copy of 08 registration status; Coverage Teams (SLT-) and their memberships; Firm Branch Offices and OSJs as profiles of 09 Office Locations (SITE-), the supervisory hierarchy, Principal Designations and Supervisory Assignments; Coverage Models, Call Frequency Standards (contact standards) and Coverage Assignment Rules (ASRL-); Party Coverage Assignment (CVA-), the one advisor-of-record master (CW-063), Coverage Reassignments (REAS-) and Advisor Capacity Snapshots; Advisor Activities (ACT-) with participants, discussion content, outcomes and capture; Channel Referrals (RFRL-); Incentive Compensation Plans (ICP-) with components and participation, Compensation Statements (CPS-) with earnings lines, and Recognition Awards (RECG-). Out of scope (referenced by ID): employee identity, jobs, positions, pay and payroll (20 Human Capital); offices, org units, legal entities and geography (09); clients, households and service tier assignments (02); accounts and program enrollments (15); service tiers, offerings and products (01); registrations, branch registrations and inspections, supervisory reviews, heightened supervision plans, captured communications, gifts, complaints and the Reg BI incentive review (08 Retail Conduct & Supervision); advice engagements, recommendations and their best-interest evidence (45); contact-center interactions and service requests (13); leads, campaigns and client-to-friend referrals (04); client assets (06, from 49). External advisors and intermediary coverage are 05 (W4) and are not referenced here."),
  ("Structure", "Four levels: Data Domain > Data Family > Data Business Object > Data Business Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Advisor (a profile of 20 Employee, keyed by EMP-) holds Advisor Role Assignments, Advisor Credentials and a License & Registration Reference (08 LIC- references and Derived copies of status). Coverage Team (SLT-) groups advisors through Coverage Team Membership. Firm Branch Office (a profile of 09 Office Location, keyed by SITE-) classifies the office by the FINRA Rule 3110 location class (office of supervisory jurisdiction, branch office, non-branch location; the Branch Type list is mastered here) and flags residential supervisory locations; Supervisory Hierarchy Link rolls branches up to OSJs, regions and the home office; Principal Designation names the principals of each office or function; Supervisory Assignment assigns every registered person to a supervisor. Coverage Model and Call Frequency Standard say how each service tier (01) is served and how often clients are contacted; Coverage Assignment Rule (ASRL-) with its criteria places households on a team or advisor. Party Coverage Assignment (CVA-) records which advisor or team serves each household, client or account in which coverage role, as of each date, with one primary per scope per date (account, then client, then household); Coverage Reassignment (REAS-) moves households between advisors with client notice dates; Advisor Capacity Snapshot measures each book. Advisor Activity (ACT-) records meetings, calls and reviews with households, with Internal and External Participants, Discussion Content, Outcome & Follow-Up and Activity Capture (08 ARC-). Channel Referral (RFRL-) hands a client from one channel to another and records the resulting 45 engagement, 15 enrollment, 04 lead or 51 trust. Incentive Compensation Plan (ICP-) has Incentive Plan Components (ICP-n-Cnn) with the Reg BI product-specific time-limited indicator; Incentive Plan Participation assigns plans to advisors; Compensation Statement (CPS-) with Incentive Earnings Lines feeds 20 Payroll Result; Recognition Award (RECG-) records non-cash recognition."),
  ("Design principles", "1) Advisor is a profile, not a person master (CD-144, CW-061): name, contact, job and pay are 20's; registration status is 08's and appears here only as a Derived copy. 'Advisor' means the firm's own representative; an external advisor is a 02 party whose profile is 05 (W4). 2) One advisor-of-record master (CW-063): Party Coverage Assignment is the only place that says which advisor or team serves a client or household; 02, 15, 45 and 47 hold no advisor-of-record attribute and read the assignment as of a date. 3) Activities are not service interactions or advice: an Advisor Activity is the advisor's own interaction; 13 holds contact-center interactions and service requests, 45 holds recommendations, rationale and best-interest evidence; 03 references them and never stores a rationale or a best-interest flag. 4) Supervisory structure here, supervisory evidence in 08 (CW-072): 03 says who supervises whom and which office is an OSJ; 08 holds registrations, inspections, reviews, findings and heightened supervision plans. 5) Incentives in reduced form (CW-064): client-outcome and firm-level measures, no territories, quotas or crediting; the Reg BI review of each component is 08. 6) Effective-date roles, memberships, designations, assignments and rules. 7) Personal data: every object states its PII tier; activity notes may contain special-category data (CD-344) and are a restricted view; target incentives and statements are restricted compensation data. 8) Flag Critical Data Elements (CDE)."),
  ("Applies To", "Shows the record each attribute belongs to: Advisor, Advisor Role Assignment, Advisor Credential, License & Registration Reference, Coverage Team, Coverage Team Membership, Firm Branch Office, Supervisory Hierarchy Link, Principal Designation, Supervisory Assignment, Coverage Model, Call Frequency Standard, Coverage Assignment Rule, Coverage Assignment Rule Criterion, Party Coverage Assignment, Coverage Reassignment, Coverage Reassignment Item, Advisor Capacity Snapshot, Advisor Activity, Internal Participant, External Participant, Discussion Content, Outcome & Follow-Up, Activity Capture, Channel Referral, Referral Status History, Incentive Compensation Plan, Incentive Plan Component, Incentive Plan Participation, Compensation Statement, Incentive Earnings Line or Recognition Award."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify an advisor, team, branch or supervisor, to evidence the supervisory structure FINRA Rule 3110 requires, to say who serves a client on a date (net new assets by advisor, billing, engagement ownership), to record an advisor's contact with a client, to measure a referral, or to design and review an incentive plan under Regulation Best Interest. Confirm with data owners."),
  ("Primary / Secondary Reference", "Standard or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Vendor and CRM models (Salesforce Financial Services Cloud) are cross-checks, not a license to reproduce their schemas. Next step: map each attribute to the CRM, the registration system and the incentive compensation tool."),
  ("Notes", "PII = personal data under the GLBA, Regulation S-P and US state privacy laws, or employee personal data. Each object's PII tier is stated in the Notes of its first attribute: 'PII - identity', 'PII - financial', 'PII - special category (CD-344)' or 'No PII'; 'identity (employee)' marks objects whose personal data is about the firm's own staff. 'Restricted' marks compensation amounts and free-text notes: hold with access controls."),
  ("Tabs", "Hierarchy: families, object groups and objects with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: object-level cardinalities, including references to other Data Domains | Sources: standards used, owners, licenses and links."),
  ("Suggested next steps", "1) Validate families, objects and CDEs with the head of the advice organization, branch and field supervision, Compliance (registrations and supervision), Sales Compensation, HR and the CRM product owner. 2) Agree with 08 the Derived copy of registration status and the references to Branch Registration, Heightened Supervision Plan and Incentive Conflict Review. 3) Agree with 45 and 47 that engagements, recommendations and bills read Party Coverage Assignment as of a date instead of holding an advisor of record. 4) Agree with 06 (W4) the client-assets figure used for book size. 5) Map attributes to the CRM, the registration system (FINRA Gateway), the HR system and the incentive compensation tool. 6) Turn the Relationships tab into a logical data model."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Advisors & Teams", "AO-ADV",
  "The firm's own advisors, planners, relationship managers, service associates and trust officers as profiles of 20 employees, their roles over time, professional credentials, a copy of their registration status from 08, and the coverage teams they work in (CW-061). Identity, job and pay stay in 20; registration is 08's.",
  [
   ("Advisor Profile", "Coverage-facing profile of each employee who advises or services clients; keyed by the 20 employee (EMP-).", [
     ("Advisor", [
       ("Employee", "The 20 employee this advisor profile extends; the advisor's key. Name, contact details, job title, employing entity and employment status are mastered in 20.", "Advisor", "Reference (Employee)", "", "EMP-20417", "Internal", "HR system of record", "Y", "Object PII tier: PII - identity (employee). PII (employee identifier)."),
       ("Advisor Status", "Status of the person as a client-facing advisor, separate from the HR employment status: onboarding, active, transitioning their book, or no longer advising. A leave of absence is read from 20 Employment Status and Leave of Absence, not held here; status history is the record history (21 governance metadata).", "Advisor", "Code", "Advisor Status", "Active", "Internal", "Salesforce FSC", "Y", "PII (employee)."),
       ("Client-Facing Title", "Title shown to clients in the app, on the website and in documents; may differ from the HR job title held in 20.", "Advisor", "Text", "", "Senior Financial Advisor", "Internal", "", "", "PII (employee)."),
       ("Advice Channels Offered", "Media through which the advisor serves clients (phone, video, in person, chat); drives routing and scheduling.", "Advisor", "Code (multi)", "Interaction Medium", "Phone; Video Conference", "Internal", "Salesforce FSC", "", "PII (employee)."),
       ("Advisor Business Lines", "Business lines in which the advisor serves clients (CW-004).", "Advisor", "Code (multi)", "Business Line", "HA; WR", "Internal", "", "", "PII (employee)."),
       ("Accepting New Clients Indicator", "Whether the advisor may currently receive new household assignments from rules, referrals or client requests; history is the record history (21 governance metadata).", "Advisor", "Boolean", "", "Y", "Internal", "", "Y", "PII (employee)."),
       ("Languages Spoken", "Languages in which the advisor can serve clients; used by assignment rules and client requests.", "Advisor", "Code (multi)", "ISO 639-1", "en; es", "ISO 639", "", "", "PII (employee)."),
       ("Advisor Specialties", "Areas of practice in which the advisor has recognized expertise, such as retirement income, equity compensation or estate planning.", "Advisor", "Code (multi)", "Advisor Specialty", "Retirement Income Planning; Equity Compensation", "Internal", "Salesforce FSC", "", "PII (employee)."),
       ("Entities Represented", "Internal legal entities on whose behalf the advisor acts: the broker-dealer, the registered investment adviser or both for a dual registrant; the trust company for a trust officer.", "Advisor", "Reference (Internal Legal Entity) (multi)", "", "LEN-0003; LEN-0007", "SEC Rule 203A-3", "FINRA Rule 1220", "Y", "PII (employee)."),
       ("Advisor Since Date", "Date the person first took a client-facing advisor role at the firm; tenure basis for capacity and recognition rules.", "Advisor", "Date", "ISO 8601", "2019-03-04", "Internal", "", "", "PII (employee)."),
     ]),
     ("Advisor Role Assignment", [
       ("Role Advisor", "Advisor who holds the role.", "Advisor Role Assignment", "Reference (Advisor)", "", "EMP-20417", "Internal", "", "Y", "Object PII tier: PII - identity (employee). PII (employee identifier)."),
       ("Advisor Role", "Client-facing or supervisory role the advisor performs in the advice organization; the registration the role requires is 20 Job Profile Regulated Role Category.", "Advisor Role Assignment", "Code", "Advisor Role", "Financial Advisor", "Internal", "FINRA Rule 1220", "Y", "PII (employee)."),
       ("Primary Role Indicator", "Whether this is the advisor's principal role for reporting and capacity.", "Advisor Role Assignment", "Boolean", "", "Y", "Internal", "", "", "PII (employee)."),
       ("Producing Indicator", "Whether the role carries an individual book of households and is measured on client outcomes in an incentive plan.", "Advisor Role Assignment", "Boolean", "", "Y", "Internal", "", "Y", "PII (employee)."),
       ("Role Job Profile", "20 job profile whose Regulated Role Category states the registrations the role requires; not redefined here.", "Advisor Role Assignment", "Reference (Job Profile)", "", "JOB-00412", "Internal", "", "", "PII (employee)."),
       ("Role Effective From", "Date the role assignment took effect.", "Advisor Role Assignment", "Date", "ISO 8601", "2024-01-01", "Internal", "", "", "PII (employee)."),
       ("Role Effective To", "Date the role assignment ended.", "Advisor Role Assignment", "Date", "ISO 8601", "", "Internal", "", "", "PII (employee)."),
     ]),
     ("Advisor Credential", [
       ("Credential Holder", "Advisor who holds the professional credential.", "Advisor Credential", "Reference (Advisor)", "", "EMP-20417", "Internal", "", "", "Object PII tier: PII - identity (employee). PII (employee identifier)."),
       ("Credential Type", "Professional designation held, such as CFP, CFA, ChFC, CPA or CTFA. A credential is not a regulatory registration or license, which 08 masters.", "Advisor Credential", "Code", "Credential Type", "CFP", "CFP Board Standards", "Internal", "Y", "PII (employee)."),
       ("Credential Status", "Whether the credential is currently held in good standing (Active) or has lapsed, been surrendered or been revoked (Inactive or Retired).", "Advisor Credential", "Code", "Record Status", "Active", "CFP Board Standards", "", "", "PII (employee)."),
       ("Credential Earned Date", "Date the credential was first granted.", "Advisor Credential", "Date", "ISO 8601", "2021-06-15", "Internal", "", "", "PII (employee)."),
       ("Credential Last Verified Date", "Date the firm last verified the credential with the issuer's public register, before using it in client-facing materials.", "Advisor Credential", "Date", "ISO 8601", "2026-07-01", "Internal", "CFP Board Standards", "", "PII (employee)."),
       ("Credential Effective To", "Date the credential stopped being held or displayed.", "Advisor Credential", "Date", "ISO 8601", "", "Internal", "", "", "PII (employee)."),
     ]),
     ("License & Registration Reference", [
       ("License Reference", "Individual registrations held by the advisor (FINRA registration categories, investment adviser representative and state agent registrations), mastered in 08 and referenced here.", "License & Registration Reference", "Reference (Individual Registration) (multi)", "", "LIC-000731; LIC-000732", "FINRA Rule 1210", "SEC Rule 203A-3", "Y", "Object PII tier: PII - identity (employee). PII (employee)."),
       ("Registered Representative Indicator", "Whether the advisor is currently registered with FINRA as a representative of the broker-dealer, as reported by 08; blocks assignment and activity ownership where registration is required.", "License & Registration Reference", "Boolean", "", "Y", "FINRA Rule 1210", "FINRA Rule 1220", "Y", "Derived copy (08); do not maintain locally. PII (employee)."),
       ("Investment Adviser Representative Indicator", "Whether the advisor is currently registered as an investment adviser representative of the firm's RIA in at least one state, as reported by 08.", "License & Registration Reference", "Boolean", "", "Y", "SEC Rule 203A-3", "", "Y", "Derived copy (08). PII (employee)."),
       ("Registered States", "States in which the advisor is currently registered as an agent or investment adviser representative, as reported by 08; read by the registered-state check of Coverage Assignment Rule.", "License & Registration Reference", "Code (multi)", "ISO 3166-2", "US-PA; US-NJ; US-DE", "FINRA Rule 1210", "SEC Rule 203A-3", "Y", "Derived copy (08). PII (employee)."),
       ("Individual CRD Number", "FINRA CRD number of the advisor, copied from 08 for display and BrokerCheck links.", "License & Registration Reference", "Identifier", "", "0000002 (fictitious)", "FINRA CRD", "", "", "Derived copy (08). PII (employee)."),
       ("Registration Copy As-Of", "When the registration values above were last copied from 08.", "License & Registration Reference", "Timestamp", "ISO 8601", "2026-10-13T02:00:00-04:00", "Internal", "", "", "PII (employee)."),
     ]),
   ]),
   ("Coverage Teams", "Teams that serve households together: pooled phone and chat teams, digital advice 'advisor on call' pools, named-advisor ensembles, institutional relationship teams and trust teams.", [
     ("Coverage Team", [
       ("Coverage Team ID", "Unique identifier of the coverage team.", "Coverage Team", "Identifier", "", "SLT-0042", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Coverage Team Name", "Name of the team as shown in routing and reporting.", "Coverage Team", "Text", "", "Mid-Atlantic Ensemble Team 3", "Internal", "", "", ""),
       ("Coverage Team Type", "Kind of team: pooled service team, digital advice pool, ensemble, institutional relationship team, trust team or specialist team.", "Coverage Team", "Code", "Coverage Team Type", "Ensemble Team", "Internal", "Salesforce FSC", "Y", ""),
       ("Lead Advisor", "Advisor who leads the team and is accountable for its households.", "Coverage Team", "Reference (Advisor)", "", "EMP-20417", "Internal", "", "", "Employee identifier."),
       ("Team Office", "09 office the team works from; branch profile in Firm Branch Office.", "Coverage Team", "Reference (Office Location)", "", "SITE-US-PHL-01", "Internal", "", "", ""),
       ("Service Tiers Served", "Service tiers (01) whose households the team serves.", "Coverage Team", "Reference (Service Tier, 01) (multi)", "", "TIER2; TIER3", "Internal", "", "", ""),
       ("Parent Coverage Team", "Team above this one in the advice organization, for roll-up.", "Coverage Team", "Reference (Coverage Team)", "", "SLT-0010", "Internal", "", "", ""),
       ("Team Status", "Lifecycle status of the team.", "Coverage Team", "Code", "Record Status", "Active", "Internal", "", "", ""),
       ("Team Effective From", "Date the team was formed.", "Coverage Team", "Date", "ISO 8601", "2023-01-01", "Internal", "", "", ""),
       ("Team Effective To", "Date the team was dissolved or merged into another.", "Coverage Team", "Date", "ISO 8601", "", "Internal", "", "", ""),
     ]),
     ("Coverage Team Membership", [
       ("Member Coverage Team", "Team the advisor belongs to.", "Coverage Team Membership", "Reference (Coverage Team)", "", "SLT-0042", "Internal", "", "Y", "Object PII tier: PII - identity (employee)."),
       ("Member Advisor", "Advisor who is a member of the team.", "Coverage Team Membership", "Reference (Advisor)", "", "EMP-20502", "Internal", "", "Y", "PII (employee identifier)."),
       ("Membership Role", "Role the advisor plays in the team, such as lead advisor, associate advisor, planner or service partner; replaces the wholesale sales pairing.", "Coverage Team Membership", "Code", "Team Membership Role", "Associate Advisor", "Internal", "Salesforce FSC", "", "PII (employee)."),
       ("Capacity Allocation Percentage", "Share of the advisor's capacity given to this team where the advisor serves on more than one.", "Coverage Team Membership", "Percentage", "", "100%", "Internal", "", "", "PII (employee)."),
       ("Membership Effective From", "Date the membership took effect.", "Coverage Team Membership", "Date", "ISO 8601", "2025-02-01", "Internal", "", "", "PII (employee)."),
       ("Membership Effective To", "Date the membership ended.", "Coverage Team Membership", "Date", "ISO 8601", "", "Internal", "", "", "PII (employee)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Branches & Supervisory Structure", "AO-SUP",
  "The broker-dealer's branch offices, offices of supervisory jurisdiction and other supervised locations as profiles of 09 offices, how they roll up, which principals are designated where, and which supervisor each registered person is assigned to (FINRA Rule 3110(a)(2) to (a)(5)). The Form BR filing, branch inspections, supervisory reviews and heightened supervision plans are 08's (CW-072).",
  [
   ("Branch Offices", "Supervisory classification of each office of the firm, keyed by the 09 Office Location.", [
     ("Firm Branch Office", [
       ("Office", "09 office this branch profile describes; address, time zone and occupying legal entity are 09's.", "Firm Branch Office", "Reference (Office Location)", "", "SITE-US-PHL-01", "Internal", "FINRA Rule 3110", "Y", "Object PII tier: No PII (a residential supervisory location is a person's home: its address, held in 09, is PII)."),
       ("Branch Type", "FINRA Rule 3110 location class of the office: office of supervisory jurisdiction (an office where a Rule 3110(f)(1) function takes place, including the main office), branch office (Rule 3110(f)(2)) or non-branch location. This list is mastered here; 08 Branch Registration and Branch Inspection copy it.", "Firm Branch Office", "Code", "Branch Type", "Office of Supervisory Jurisdiction", "FINRA Rule 3110", "FINRA Form BR", "Y", ""),
       ("Supervises Non-Branch Locations Indicator", "Whether the office supervises one or more non-branch locations, which makes it subject to annual inspection under FINRA Rule 3110(c)(1)(A).", "Firm Branch Office", "Boolean", "", "N", "FINRA Rule 3110", "", "", ""),
       ("Residential Supervisory Location Indicator", "Whether a non-branch location is a private residence designated a residential supervisory location under FINRA Rule 3110.19, effective 1 June 2024 (Regulatory Notice 24-02).", "Firm Branch Office", "Boolean", "", "N", "FINRA Rule 3110", "FINRA Regulatory Notice 24-02", "", ""),
       ("Branch Registration Reference", "08 Form BR registration of the office (branch CRD number and filing history).", "Firm Branch Office", "Reference (Branch Registration, 08)", "", "SITE-US-PHL-01 / 0000003 (fictitious)", "FINRA Form BR", "", "", ""),
       ("Branch Status", "Lifecycle status of the branch designation.", "Firm Branch Office", "Code", "Record Status", "Active", "Internal", "", "", ""),
       ("Branch Designation Effective From", "Date the office took its current branch type and OSJ designation.", "Firm Branch Office", "Date", "ISO 8601", "2024-06-01", "FINRA Rule 3110", "", "", ""),
       ("Branch Designation Effective To", "Date the designation ended (office closed or reclassified).", "Firm Branch Office", "Date", "ISO 8601", "", "FINRA Rule 3110", "", "", ""),
     ]),
     ("Supervisory Hierarchy Link", [
       ("Child Supervisory Unit", "Office or org unit supervised by the parent: a branch under an OSJ, an OSJ under a region, a region under the home office.", "Supervisory Hierarchy Link", "Reference (Office Location / Org Unit)", "", "SITE-US-PHL-01", "FINRA Rule 3110", "", "Y", "Object PII tier: No PII."),
       ("Parent Supervisory Unit", "Office or org unit that supervises the child.", "Supervisory Hierarchy Link", "Reference (Office Location / Org Unit)", "", "SITE-US-HQO-01", "FINRA Rule 3110", "", "Y", ""),
       ("Supervisory Link Type", "Nature of the link: branch to its supervising OSJ, OSJ to region, region to home office, or non-branch location to its supervising branch.", "Supervisory Hierarchy Link", "Code", "Supervisory Link Type", "Branch to OSJ", "FINRA Rule 3110", "", "", ""),
       ("Link Effective From", "Date the link took effect.", "Supervisory Hierarchy Link", "Date", "ISO 8601", "2024-06-01", "Internal", "", "", ""),
       ("Link Effective To", "Date the link ended.", "Supervisory Hierarchy Link", "Date", "ISO 8601", "", "Internal", "", "", ""),
     ]),
   ]),
   ("Principals & Supervisors", "Designation of principals with supervisory authority and the assignment of every registered person to a supervisor.", [
     ("Principal Designation", [
       ("Designated Principal", "Employee designated with supervisory authority.", "Principal Designation", "Reference (Employee)", "", "EMP-11208", "FINRA Rule 3110", "", "Y", "Object PII tier: PII - identity (employee). PII (employee identifier)."),
       ("Principal Designation Type", "Supervisory designation held, such as OSJ principal, branch manager, Registered Options Principal or supervising principal for advisory accounts.", "Principal Designation", "Code", "Principal Designation Type", "OSJ Principal", "FINRA Rule 3110", "Advisers Act Rule 206(4)-7", "Y", "PII (employee)."),
       ("Designation Office", "Office the designation covers; blank for a firm-wide function designation.", "Principal Designation", "Reference (Office Location)", "", "SITE-US-PHL-01", "FINRA Rule 3110", "", "", "PII (employee)."),
       ("Supervised Functions", "Business types or functions the principal is designated to supervise (FINRA Rule 3110(a)(2)).", "Principal Designation", "Code (multi)", "Supervised Function", "Retail Brokerage Accounts; Options Accounts", "FINRA Rule 3110", "", "", "PII (employee)."),
       ("Qualifying Registration", "08 registration that qualifies the principal for the designation (for example a General Securities Principal or Registered Options Principal registration).", "Principal Designation", "Reference (Individual Registration)", "", "LIC-000812", "FINRA Rule 1220", "", "", "PII (employee)."),
       ("Designation Effective From", "Date the designation took effect.", "Principal Designation", "Date", "ISO 8601", "2025-01-01", "FINRA Rule 3110", "", "", "PII (employee)."),
       ("Designation Effective To", "Date the designation ended.", "Principal Designation", "Date", "ISO 8601", "", "FINRA Rule 3110", "", "", "PII (employee)."),
     ]),
     ("Supervisory Assignment", [
       ("Supervised Person", "Registered person (or other associated person) whose activities are supervised.", "Supervisory Assignment", "Reference (Employee)", "", "EMP-20417", "FINRA Rule 3110", "", "Y", "Object PII tier: PII - identity (employee). PII (employee identifier)."),
       ("Assigned Supervisor", "Appropriately registered representative or principal responsible for supervising the person (FINRA Rule 3110(a)(5)).", "Supervisory Assignment", "Reference (Employee)", "", "EMP-11208", "FINRA Rule 3110", "", "Y", "PII (employee identifier)."),
       ("Supervisory Assignment Type", "Kind of assignment: primary supervisor, delegate, interim cover or heightened supervision supervisor. The heightened-supervision supervisor is mastered here; 08 Heightened Supervision Plan holds it as a Derived copy.", "Supervisory Assignment", "Code", "Supervisory Assignment Type", "Primary Supervisor", "FINRA Rule 3110", "", "Y", "PII (employee)."),
       ("Supervising Office", "OSJ or branch from which the supervision is exercised.", "Supervisory Assignment", "Reference (Office Location)", "", "SITE-US-PHL-01", "FINRA Rule 3110", "", "", "PII (employee)."),
       ("Heightened Supervision Plan Reference", "08 heightened supervision plan that this assignment carries out; the plan's basis and conditions stay in 08, and the supervisor named for the plan is this assignment's Assigned Supervisor.", "Supervisory Assignment", "Reference (Heightened Supervision Plan, 08)", "", "HSPL-2026-0012", "FINRA Rule 3110", "", "", "PII (employee); restricted (may reveal a disclosure event)."),
       ("Assignment Effective From", "Date the supervisory assignment took effect.", "Supervisory Assignment", "Date", "ISO 8601", "2025-01-01", "FINRA Rule 3110", "", "", "PII (employee)."),
       ("Assignment Effective To", "Date the supervisory assignment ended.", "Supervisory Assignment", "Date", "ISO 8601", "", "FINRA Rule 3110", "", "", "PII (employee)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Coverage & Service Models", "AO-CVM",
  "How each service tier (01) is served: the coverage models (digital only, pooled team, dedicated advisor, ensemble), the contact standards each tier must receive, and the rules that place households on a team or advisor. Service tiers are defined in 01 and assigned to households in 02 (CW-028).",
  [
   ("Coverage Models & Contact Standards", "Standard designs for serving a tier and the minimum client contact they require.", [
     ("Coverage Model", [
       ("Coverage Model Code", "Firm-defined code of the coverage model; a firm may define several models for one tier or delivery mode.", "Coverage Model", "Code", "Firm-defined", "HA-DEDICATED-T3", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Delivery Mode", "How advice and service are delivered under the model, on the 01 Delivery Mode list (the same dimension as 01 Service Offering Delivery Mode; 01 is the steward).", "Coverage Model", "Code", "External (01 Delivery Mode)", "Dedicated Advisor", "Internal", "", "", ""),
       ("Coverage Roles Included", "Coverage roles that make up the model.", "Coverage Model", "Code (multi)", "Coverage Role", "Primary Advisor; Service Associate", "Internal", "", "", ""),
       ("Service Tiers Covered", "Service tiers (01) served under the model.", "Coverage Model", "Reference (Service Tier, 01) (multi)", "", "TIER3", "Internal", "", "", ""),
       ("Target Households per Advisor", "Planned number of households per primary advisor under the model.", "Coverage Model", "Integer", "", "150", "Internal", "", "", ""),
       ("Maximum Households per Advisor", "Number of households above which an advisor is over capacity under the model.", "Coverage Model", "Integer", "", "180", "Internal", "", "", ""),
       ("Coverage Model Status", "Lifecycle status of the model.", "Coverage Model", "Code", "Record Status", "Active", "Internal", "", "", ""),
       ("Coverage Model Effective From", "Date the model took effect.", "Coverage Model", "Date", "ISO 8601", "2026-01-01", "Internal", "", "", ""),
     ]),
     ("Call Frequency Standard", [
       ("Standard Coverage Model", "Coverage model the contact standard belongs to.", "Call Frequency Standard", "Reference (Coverage Model, 03)", "", "HA-DEDICATED-T3", "Internal", "", "", "Object PII tier: No PII."),
       ("Standard Service Tier", "Service tier (01) the contact standard applies to.", "Call Frequency Standard", "Reference (Service Tier, 01)", "", "TIER3", "Internal", "", "Y", ""),
       ("Contact Type", "Kind of client contact the standard requires, such as an annual review, a check-in or a planning update.", "Call Frequency Standard", "Code", "Contact Type", "Annual Review", "Internal", "ICA Rule 3a-4", "", ""),
       ("Qualifying Activity Type", "Advisor activity types that count toward the standard.", "Call Frequency Standard", "Code (multi)", "Activity Type", "Meeting; Call", "Internal", "", "", ""),
       ("Required Interactions per Period", "Minimum number of qualifying contacts per period.", "Call Frequency Standard", "Integer", "", "1", "Internal", "", "", ""),
       ("Standard Period", "Period over which the standard is measured.", "Call Frequency Standard", "Code", "Frequency", "Annual", "Internal", "", "", ""),
       ("Annual Contact Required Indicator", "Whether the standard satisfies the annual client contact of an advisory program under Investment Company Act Rule 3a-4(a)(2)(ii); the contact itself is a 45 Advice Review.", "Call Frequency Standard", "Boolean", "", "Y", "ICA Rule 3a-4", "", "Y", ""),
       ("Standard Effective From", "Date the standard took effect.", "Call Frequency Standard", "Date", "ISO 8601", "2026-01-01", "Internal", "", "", ""),
     ]),
   ]),
   ("Assignment Rules", "Rules that place a household on a coverage team or advisor by tier, geography, language and registered state.", [
     ("Coverage Assignment Rule", [
       ("Assignment Rule ID", "Unique identifier of the assignment rule.", "Coverage Assignment Rule", "Identifier", "", "ASRL-0142", "Internal", "", "Y", "Object PII tier: No PII (a named-exception row names a household: PII - identity)."),
       ("Assignment Rule Type", "Basis of the rule: tier and geography, language, workplace plan, referral source, round robin or named exception (one household placed by approval).", "Coverage Assignment Rule", "Code", "Assignment Rule Type", "Tier and Geography", "Internal", "", "", ""),
       ("Target Coverage Team", "Team to which matching households are assigned.", "Coverage Assignment Rule", "Reference (Coverage Team)", "", "SLT-0042", "Internal", "", "", ""),
       ("Target Advisor", "Advisor to whom matching households are assigned, for named exceptions and dedicated-advisor rules.", "Coverage Assignment Rule", "Reference (Advisor)", "", "EMP-20417", "Internal", "", "", ""),
       ("Excepted Party", "Household or client a named-exception rule places; blank for criteria-based rules.", "Coverage Assignment Rule", "Reference (Party)", "", "PTY-HH-55012", "Internal", "", "", "PII (named-exception rows only)."),
       ("Rule Precedence", "Order of evaluation; when a household matches several rules, the lowest number wins.", "Coverage Assignment Rule", "Integer", "", "20", "Internal", "", "", ""),
       ("Boolean Filter", "Logic combining the rule criteria by sequence number.", "Coverage Assignment Rule", "Text", "", "(1 AND 2) OR 3", "Internal", "", "", ""),
       ("Registered-State Check Indicator", "Whether the rule may assign a household only to an advisor registered in the household's state of residence (08 registration copy).", "Coverage Assignment Rule", "Boolean", "", "Y", "FINRA Rule 1210", "Internal", "Y", ""),
       ("Rule Status", "Lifecycle status of the rule.", "Coverage Assignment Rule", "Code", "Record Status", "Active", "Internal", "", "", ""),
       ("Rule Effective From", "Date the rule took effect.", "Coverage Assignment Rule", "Date", "ISO 8601", "2026-01-01", "Internal", "", "", ""),
       ("Rule Effective To", "Date the rule was retired.", "Coverage Assignment Rule", "Date", "ISO 8601", "", "Internal", "", "", ""),
     ]),
     ("Coverage Assignment Rule Criterion", [
       ("Criterion Sequence", "Number of the criterion within the rule, used by the Boolean filter.", "Coverage Assignment Rule Criterion", "Integer", "", "1", "Internal", "", "", "Object PII tier: No PII."),
       ("Criterion Field", "Attribute evaluated, named by domain, object and attribute (for example the 02 service tier or the household's state).", "Coverage Assignment Rule Criterion", "Text", "", "02.Service Tier Assignment.Assigned Service Tier", "Internal", "", "", ""),
       ("Criterion Operator", "Comparison operator.", "Coverage Assignment Rule Criterion", "Code", "Rule Operator", "Equals", "Internal", "", "", ""),
       ("Criterion Value", "Value or list compared against.", "Coverage Assignment Rule Criterion", "Text", "", "TIER3", "Internal", "", "", ""),
       ("Criterion Geographic Group", "09 geographic group compared against when the criterion is geographic.", "Coverage Assignment Rule Criterion", "Reference (Geographic Group)", "", "GEO-GRP-US-MIDATL", "Internal", "", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Client Assignment & Capacity", "AO-ASG",
  "Which advisor or team serves each household or client, in which coverage role, as of each date: the one advisor-of-record master (CW-063), its reassignments with client notice, and the capacity of each book.",
  [
   ("Coverage Assignment", "The effective-dated assignment of a household or client to an advisor or coverage team.", [
     ("Party Coverage Assignment", [
       ("Coverage Assignment ID", "Unique identifier of the coverage assignment.", "Party Coverage Assignment", "Identifier", "", "CVA-1093345", "Internal", "", "Y", "Object PII tier: PII - identity. PII."),
       ("Covered Party", "Client Household (PTY-HH-, the reference default) or individual or entity client being covered; an institutional advisory client for the IA line.", "Party Coverage Assignment", "Reference (Party)", "", "PTY-HH-55012", "Internal", "Salesforce FSC", "Y", "PII."),
       ("Covering Advisor", "Advisor who covers the party in this role; blank when the party is covered by a team without a named advisor.", "Party Coverage Assignment", "Reference (Advisor)", "", "EMP-20417", "Internal", "", "Y", "PII (employee identifier)."),
       ("Covering Coverage Team", "Coverage team that covers the party, for pooled and ensemble models.", "Party Coverage Assignment", "Reference (Coverage Team)", "", "SLT-0042", "Internal", "", "Y", "PII."),
       ("Party Coverage Role", "Role the advisor or team plays for the party.", "Party Coverage Assignment", "Code", "Coverage Role", "Primary Advisor", "Internal", "", "Y", "PII."),
       ("Primary Coverage Indicator", "Whether this assignment is the advisor of record for its scope (CW-063). At most one primary row per scope per date: per household, per client, and per account where Covered Account is filled. The advisor of record that 06 attribution and 47 billing read for an account on a date resolves at account scope first, then client, then household; 45 engagements read it the same way.", "Party Coverage Assignment", "Boolean", "", "Y", "Internal", "", "Y", "PII."),
       ("Assignment Basis", "How the assignment arose: assignment rule, client request, channel referral, reassignment or legacy conversion.", "Party Coverage Assignment", "Code", "Coverage Assignment Basis", "Channel Referral", "Internal", "", "", "PII."),
       ("Source Assignment Rule", "Assignment rule that produced the assignment.", "Party Coverage Assignment", "Reference (Coverage Assignment Rule, 03)", "", "ASRL-0142", "Internal", "", "", "PII."),
       ("Source Channel Referral", "Channel referral that produced the assignment.", "Party Coverage Assignment", "Reference (Channel Referral, 03)", "", "RFRL-2026-004417", "Internal", "", "", "PII."),
       ("Covered Account", "Accounts (15) to which the assignment is limited, as an exception to household-level coverage; blank means every account of the household.", "Party Coverage Assignment", "Reference (Account) (multi)", "", "ACC-0049812", "Internal", "", "", "PII."),
       ("Coverage Effective From", "Date the coverage took effect.", "Party Coverage Assignment", "Date", "ISO 8601", "2026-04-01", "Internal", "", "Y", "PII."),
       ("Coverage Effective To", "Date the coverage ended.", "Party Coverage Assignment", "Date", "ISO 8601", "", "Internal", "", "Y", "PII."),
       ("Relationship Start Date", "Date the advisor first covered the party, across reassignments within the same team; tenure basis for retention measures.", "Party Coverage Assignment", "Date", "ISO 8601", "2023-05-01", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Reassignment", "Events that move households from one advisor or team to another, with client notice.", [
     ("Coverage Reassignment", [
       ("Reassignment ID", "Unique identifier of the reassignment event.", "Coverage Reassignment", "Identifier", "", "REAS-2026-0031", "Internal", "", "Y", "Object PII tier: PII - identity (names the advisors and, through its items, the households)."),
       ("Reassignment Reason", "Why households are moved: advisor departure, leave, role change, capacity rebalancing, tier change, client request or team restructuring.", "Coverage Reassignment", "Code", "Reassignment Reason", "Advisor Departure", "Internal", "", "", "PII (employee)."),
       ("From Advisor", "Advisor whose households are moved.", "Coverage Reassignment", "Reference (Advisor)", "", "EMP-20211", "Internal", "", "", "PII (employee identifier)."),
       ("From Coverage Team", "Coverage team whose households are moved; blank when they move from a named advisor.", "Coverage Reassignment", "Reference (Coverage Team)", "", "SLT-0040", "Internal", "", "", ""),
       ("To Advisor", "Advisor who receives the households; blank when they move to a team.", "Coverage Reassignment", "Reference (Advisor)", "", "EMP-20417", "Internal", "", "", "PII (employee identifier)."),
       ("To Coverage Team", "Coverage team that receives the households.", "Coverage Reassignment", "Reference (Coverage Team)", "", "SLT-0042", "Internal", "", "", ""),
       ("Reassignment Effective Date", "Date from which the new assignments apply to coverage, attribution and billing.", "Coverage Reassignment", "Date", "ISO 8601", "2026-11-01", "Internal", "", "Y", ""),
       ("Planned Client Notice Date", "Date by which affected clients are to be told of their new advisor or team.", "Coverage Reassignment", "Date", "ISO 8601", "2026-10-15", "Internal", "", "Y", ""),
       ("Reassignment Status", "Workflow status of the event.", "Coverage Reassignment", "Code", "Reassignment Status", "Clients Notified", "Internal", "", "", ""),
       ("Reassignment Approver", "Manager or principal who approved the reassignment.", "Coverage Reassignment", "Reference (Employee)", "", "EMP-11208", "Internal", "", "", "PII (employee identifier)."),
     ]),
     ("Coverage Reassignment Item", [
       ("Reassigned Household", "Household (or client) moved by the event.", "Coverage Reassignment Item", "Reference (Party)", "", "PTY-HH-55012", "Internal", "", "Y", "Object PII tier: PII - identity. PII."),
       ("Prior Coverage Assignment", "Coverage assignment ended by the event.", "Coverage Reassignment Item", "Reference (Party Coverage Assignment)", "", "CVA-1041207", "Internal", "", "", "PII."),
       ("New Coverage Assignment", "Coverage assignment created by the event.", "Coverage Reassignment Item", "Reference (Party Coverage Assignment)", "", "CVA-1093345", "Internal", "", "", "PII."),
       ("Client Notice Sent Date", "Date this household was told of the change.", "Coverage Reassignment Item", "Date", "ISO 8601", "2026-10-14", "Internal", "", "", "PII."),
       ("Client Notice Delivery", "13 recipient delivery record of the notice sent to this household.", "Coverage Reassignment Item", "Reference (Recipient Delivery Record)", "", "MAIL-2026-00318 / ACC-0049812", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Capacity", "Periodic measurement of the size of each advisor's or team's book against its capacity.", [
     ("Advisor Capacity Snapshot", [
       ("Capacity Subject Advisor", "Advisor whose book is measured; blank for a team snapshot.", "Advisor Capacity Snapshot", "Reference (Advisor)", "", "EMP-20417", "Internal", "", "Y", "Object PII tier: PII - financial (aggregate book figures of a named advisor; no client-level data)."),
       ("Capacity Subject Team", "Coverage team whose book is measured; blank for an advisor snapshot.", "Advisor Capacity Snapshot", "Reference (Coverage Team)", "", "SLT-0042", "Internal", "", "", "PII."),
       ("Capacity As-Of Date", "Date the snapshot measures.", "Advisor Capacity Snapshot", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y", "PII."),
       ("Assigned Household Count", "Number of households with an active primary coverage assignment to the subject on the as-of date, counted from Party Coverage Assignment.", "Advisor Capacity Snapshot", "Integer", "", "162", "Internal", "", "Y", "PII (employee)."),
       ("Assigned Client Count", "Number of individual clients in the assigned households on the as-of date, counted from 02 household membership.", "Advisor Capacity Snapshot", "Integer", "", "291", "Internal", "", "", "Derived copy (02). PII (employee)."),
       ("Assigned Account Count", "Number of open accounts of the assigned households on the as-of date, counted from 15.", "Advisor Capacity Snapshot", "Integer", "", "604", "Internal", "", "", "Derived copy (15). PII (employee)."),
       ("Book Client Assets", "Client assets of the assigned households on the as-of date, as published by 06 Client Assets (summarized from 49 Client Holding).", "Advisor Capacity Snapshot", "Amount", "", "USD 214,500,000", "Internal", "", "", "Derived copy (06); future owner 06, W4. PII - financial (aggregate)."),
       ("Household Capacity Limit", "Maximum number of households the subject should serve, from the coverage model or an approved exception.", "Advisor Capacity Snapshot", "Integer", "", "180", "Internal", "", "", "PII (employee)."),
       ("Available Household Capacity", "Households the subject can still take: capacity limit less assigned households, floored at zero.", "Advisor Capacity Snapshot", "Integer", "", "18", "Internal", "", "", "PII (employee)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Advisor Activities & Interactions", "AO-ACT",
  "The advisor's own interactions with clients and households (meetings, calls, video sessions, reviews, emails), who took part, what was discussed, the outcome and how the record was captured for books and records. Contact-center interactions and service requests are 13; recommendations and their evidence are 45 (CW-061).",
  [
   ("Activity Record", "Header of an advisor activity.", [
     ("Advisor Activity", [
       ("Activity ID", "Unique identifier of the activity.", "Advisor Activity", "Identifier", "", "ACT-2026-0451230", "Internal", "Salesforce FSC", "Y", "Object PII tier: PII - identity. PII."),
       ("Activity Type", "Form of the activity (meeting, call, message, seminar, task), or for intermediary and institutional coverage the meeting kind; the medium is Interaction Medium.", "Advisor Activity", "Code", "Activity Type", "Meeting", "Salesforce FSC", "", "Y", "PII."),
       ("Interaction Medium", "How the interaction took place.", "Advisor Activity", "Code", "Interaction Medium", "Video Conference", "Salesforce FSC", "", "", "PII."),
       ("Activity Purpose", "Business purpose of the interaction, such as an annual review, a planning meeting or a rollover discussion.", "Advisor Activity", "Code", "Activity Purpose", "Annual Review", "Salesforce FSC", "ICA Rule 3a-4", "Y", "PII."),
       ("Activity Start Timestamp", "Date and time the activity started, or the email or message was sent.", "Advisor Activity", "Timestamp", "ISO 8601", "2026-09-22T14:00:00-04:00", "Salesforce FSC", "", "Y", "PII."),
       ("Activity End Timestamp", "Date and time the activity ended.", "Advisor Activity", "Timestamp", "ISO 8601", "2026-09-22T14:50:00-04:00", "Salesforce FSC", "", "", "PII."),
       ("Activity Status", "Lifecycle status of the activity.", "Advisor Activity", "Code", "Activity Status", "Completed", "Salesforce FSC", "", "", "PII."),
       ("Activity Owner", "Employee accountable for the activity record: an own advisor, or a member of the intermediary or institutional teams of 05, whose meetings are also Advisor Activity rows (CW-138); any employee qualifies.", "Advisor Activity", "Reference (Employee)", "", "EMP-20417", "Salesforce FSC", "", "Y", "PII (employee identifier)."),
       ("Activity Party", "Client Household or client the activity concerns, or for an intermediary or institutional meeting the partner firm, consultant or plan sponsor party (02).", "Advisor Activity", "Reference (Party)", "", "PTY-HH-55012", "Salesforce FSC", "", "Y", "PII."),
       ("Related Accounts", "Accounts (15) discussed or acted on.", "Advisor Activity", "Reference (Account) (multi)", "", "ACC-0049812; ACC-0049813", "Internal", "", "", "PII."),
       ("Related Advice Engagement", "45 advice engagement the activity is part of.", "Advisor Activity", "Reference (Advice Engagement, 45)", "", "ADENG-2026-004187", "Internal", "", "", "PII."),
       ("Related Advice Review", "45 advice review held in this activity (for example the Rule 3a-4 annual contact); the review outcome is 45's.", "Advisor Activity", "Reference (Advice Review, 45)", "", "AVREV-2026-0031877", "ICA Rule 3a-4", "", "", "PII."),
       ("Originating Service Request", "13 service request that led to the activity, where a service case was escalated to the advisor.", "Advisor Activity", "Reference (Service Request)", "", "SRQ-2026-0081245", "Internal", "", "", "PII."),
       ("Related Campaign", "04 campaign the activity supports, such as a rollover or Roth conversion campaign.", "Advisor Activity", "Reference (Campaign)", "", "CAM-004512", "Internal", "", "", "PII."),
       ("Activity Classification", "Confidentiality level of the activity and its notes, which controls who may see them.", "Advisor Activity", "Code", "Information Classification", "Confidential - Client", "Internal", "ISO/IEC 27001", "", "PII."),
     ]),
   ]),
   ("Activity Participants", "Internal and external people who took part in the activity.", [
     ("Internal Participant", [
       ("Internal Participant", "Employee who took part in the activity.", "Internal Participant", "Reference (Employee)", "", "EMP-20502", "Salesforce FSC", "", "", "Object PII tier: PII - identity (employee). PII (employee identifier)."),
       ("Internal Participant Role", "Role the employee played in the activity.", "Internal Participant", "Code", "Activity Participant Role", "Financial Planner", "Internal", "", "", "PII (employee)."),
       ("Attendance Status", "Response or attendance status of the participant.", "Internal Participant", "Code", "Attendance Status", "Attended", "Salesforce FSC", "", "", "PII (employee)."),
     ]),
     ("External Participant", [
       ("External Participant", "02 party who took part: a household member, the client's attorney or CPA, a trusted contact or an agent.", "External Participant", "Reference (Party)", "", "PTY-104588", "Salesforce FSC", "", "", "Object PII tier: PII - identity. PII."),
       ("External Participant Role", "Role the external participant played in the interaction.", "External Participant", "Code", "Activity Participant Role", "Client", "Internal", "", "", "PII."),
       ("External Attendance Status", "Whether the external participant attended.", "External Participant", "Code", "Attendance Status", "Attended", "Salesforce FSC", "", "", "PII."),
       ("Unmatched Participant Email", "Email address captured from the calendar or email that could not be matched to a 02 party; routed to 02 for matching and never used to create a party here.", "External Participant", "Text", "Email", "j.example@example.net", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Activity Content & Outcome", "What was discussed and what happens next.", [
     ("Discussion Content", [
       ("Discussion Topics", "Topics covered in the interaction.", "Discussion Content", "Code (multi)", "Discussion Topic", "Retirement Income; Tax Planning", "Internal", "", "", "Object PII tier: PII - identity; free text may contain special category data (CD-344). PII."),
       ("Products Discussed", "01 investment products discussed.", "Discussion Content", "Reference (Investment Product) (multi)", "", "PRD-00981", "Internal", "", "", "PII."),
       ("Services Discussed", "01 service offerings discussed, such as a managed account program or trust services.", "Discussion Content", "Reference (Service Offering) (multi)", "", "OFFR-0012", "Internal", "", "", "PII."),
       ("Meeting Notes", "Narrative record of what was discussed. Not a recommendation rationale or best-interest record, which 45 masters.", "Discussion Content", "Text", "Free text", "Reviewed income plan; client asked about Roth conversion; follow-up with planner.", "Salesforce FSC", "SEC Rule 17a-4", "", "PII; may contain special category data (CD-344; for example diminished capacity under FINRA Rule 2165). Restricted view driven by Special Category Content Indicator."),
       ("Special Category Content Indicator", "Whether the notes contain special-category personal data (health, diminished capacity, specified adult or suspected exploitation); when set, the notes are a restricted view for service, advice and compliance only (CD-344).", "Discussion Content", "Boolean", "", "N", "Internal", "FINRA Rule 2165", "", "PII - special category (CD-344) when set."),
       ("Notes Personal Data Categories", "Categories of personal data the notes contain, set by the author or a classifier; drives the restricted view.", "Discussion Content", "Code (multi)", "Personal Data Category", "Financial; Free Text - May Contain Personal Data", "SEC Regulation S-P", "", "", "PII."),
       ("Summary Generation Method", "How the activity summary was produced, so that AI-generated content can be identified and reviewed.", "Discussion Content", "Code", "Summary Generation Method", "AI-Assisted - Reviewed", "Internal", "", "", "PII."),
       ("Client Sentiment", "Advisor's assessment of the client's sentiment in the interaction.", "Discussion Content", "Code", "Sentiment", "Positive", "Internal", "", "", "PII (opinion about an individual)."),
       ("Content Assets Shared", "04 content assets shown or sent in the interaction.", "Discussion Content", "Reference (Content Asset) (multi)", "", "AST-018233", "Internal", "FINRA Rule 2210", "", "PII."),
     ]),
     ("Outcome & Follow-Up", [
       ("Activity Outcome", "Result of the interaction.", "Outcome & Follow-Up", "Code", "Activity Outcome", "Follow-Up Required", "Internal", "", "Y", "Object PII tier: PII - identity. PII."),
       ("Next Step", "Agreed next action in plain language.", "Outcome & Follow-Up", "Text", "", "Planner to model Roth conversion; meet again in November", "Salesforce FSC", "", "", "PII possible."),
       ("Follow-Up Task", "Activity created to track the follow-up.", "Outcome & Follow-Up", "Reference (Advisor Activity)", "", "ACT-2026-0451288", "Salesforce FSC", "", "", "PII."),
       ("Resulting Recommendation", "45 recommendation made in or after the interaction; its rationale and evidence stay in 45.", "Outcome & Follow-Up", "Reference (Recommendation, 45)", "", "RECOM-2026-0018342", "Internal", "", "", "PII."),
       ("Complaint Raised", "08 complaint recorded when the client raised a grievance in the interaction.", "Outcome & Follow-Up", "Reference (Complaint)", "", "CPL-2026-000418", "FINRA Rule 4530", "", "", "PII."),
     ]),
   ]),
   ("Activity Capture & Record-Keeping", "Where the activity came from and how it links to the books and records the broker-dealer and adviser keep.", [
     ("Activity Capture", [
       ("Activity Source System", "System from which the activity record originated.", "Activity Capture", "Code", "Firm-defined", "CRM", "Internal", "", "", "Object PII tier: PII - identity. PII."),
       ("Capture Method", "How the activity was recorded.", "Activity Capture", "Code", "Activity Capture Method", "Meeting Platform Integration", "Internal", "", "", "PII."),
       ("Source Record ID", "Identifier of the activity in the source system.", "Activity Capture", "Identifier", "", "mtg:84512233901", "Internal", "", "", "PII."),
       ("Communication Archive Reference", "08 captured communication record holding the original email, message or recording.", "Activity Capture", "Reference (Captured Communication Record)", "", "ARC-2026-09-11-88412093", "SEC Rule 17a-4", "Advisers Act Rule 204-2", "Y", "PII."),
       ("Recorded Communication Indicator", "Whether the audio, video or chat of the interaction was recorded and retained as a business communication.", "Activity Capture", "Boolean", "", "Y", "SEC Rule 17a-4", "Advisers Act Rule 204-2", "", "PII. Recording policy owned by 08."),
       ("Gifts & Entertainment Reference", "08 gift or entertainment item provided at the activity.", "Activity Capture", "Reference (Gift / Entertainment Item)", "", "GNE-2026-018834", "FINRA Rule 3220", "", "", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Channel Referrals", "AO-REF",
  "Handoffs of a client from one channel to another inside the firm: self-directed or digital clients to human advice, service to advice, workplace participants to rollover support and advice, advice to the trust company (CW-065). Marketing leads and client-to-friend referral programs are 04.",
  [
   ("Referral", "The referral and its history.", [
     ("Channel Referral", [
       ("Referral ID", "Unique identifier of the referral.", "Channel Referral", "Identifier", "", "RFRL-2026-004417", "Internal", "", "Y", "Object PII tier: PII - identity. PII."),
       ("Referral Date", "Date and time the referral was made.", "Channel Referral", "Timestamp", "ISO 8601", "2026-08-12T10:14:00-04:00", "Internal", "", "Y", "PII."),
       ("Referred Party", "Client Household or client referred.", "Channel Referral", "Reference (Party)", "", "PTY-HH-55012", "Internal", "", "Y", "PII."),
       ("Referral Source Channel", "Channel the client is referred from.", "Channel Referral", "Code", "Referral Channel", "Workplace Participant Services", "Internal", "", "Y", "PII."),
       ("Referring Employee", "Employee who made the referral.", "Channel Referral", "Reference (Employee)", "", "EMP-30988", "Internal", "", "", "PII (employee identifier)."),
       ("Referral Target Channel", "Channel the client is referred to.", "Channel Referral", "Code", "Referral Channel", "Human Advice", "Internal", "", "Y", "PII."),
       ("Target Advisor", "Advisor the client is referred to, where named.", "Channel Referral", "Reference (Advisor)", "", "EMP-20417", "Internal", "", "", "PII (employee identifier)."),
       ("Target Coverage Team", "Coverage team the client is referred to.", "Channel Referral", "Reference (Coverage Team)", "", "SLT-0042", "Internal", "", "", "PII."),
       ("Referral Reason", "Why the client was referred, such as a rollover from a workplace plan, a planning need or an assets threshold reached.", "Channel Referral", "Code", "Referral Reason", "Rollover Support", "Internal", "", "", "PII."),
       ("Referral Status", "Current status of the referral; history in Referral Status History.", "Channel Referral", "Code", "Channel Referral Status", "Converted", "Internal", "", "Y", "PII."),
       ("Source Service Request", "13 service request from which the referral arose.", "Channel Referral", "Reference (Service Request)", "", "SRQ-2026-0081245", "Internal", "", "", "PII."),
       ("Resulting Advice Engagement", "45 advice engagement opened as the outcome of the referral.", "Channel Referral", "Reference (Advice Engagement, 45)", "", "ADENG-2026-004187", "Internal", "", "Y", "PII."),
       ("Resulting Program Enrollment", "15 program enrollment that followed the referral, such as a digital or managed advice enrollment.", "Channel Referral", "Reference (Program Enrollment)", "", "ENRL-2025-0004418", "Internal", "", "", "PII."),
       ("Resulting Marketing Lead", "04 marketing lead created when the referred person is not yet a client.", "Channel Referral", "Reference (Marketing Lead)", "", "LEAD-0091234", "Internal", "", "", "PII."),
       ("Resulting Trust", "51 trust the trust company accepted following an advice-to-trust referral.", "Channel Referral", "Reference (Trust, 51)", "", "TRUST-000412", "Internal", "", "", "PII."),
       ("Referral Incentive Eligible Indicator", "Whether the referral can earn the referring employee an award under an incentive plan component (subject to the 08 incentive review).", "Channel Referral", "Boolean", "", "Y", "SEC Reg BI", "Internal", "", "PII."),
     ]),
     ("Referral Status History", [
       ("History Referral Status", "Status the referral moved to.", "Referral Status History", "Code", "Channel Referral Status", "Accepted", "Internal", "", "", "Object PII tier: PII - identity. PII."),
       ("Status Change Timestamp", "When the status changed.", "Referral Status History", "Timestamp", "ISO 8601", "2026-08-13T09:02:00-04:00", "Internal", "", "", "PII."),
       ("Status Changed By", "Employee who changed the status.", "Referral Status History", "Reference (Employee)", "", "EMP-20417", "Internal", "", "", "PII (employee identifier)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Incentive & Recognition", "AO-INC",
  "Incentive and recognition plans for advisors in reduced form (CW-064): the plan, its client-outcome and firm-level components with the Reg BI indicator, who participates, the statements payroll reads and non-cash recognition awards. Pay and payroll are 20; accruals are 19; the Reg BI review of each component is 08 Incentive Conflict Review.",
  [
   ("Incentive Plans", "Identity, terms and components of each incentive compensation plan.", [
     ("Incentive Compensation Plan", [
       ("Incentive Plan ID", "Unique identifier of the incentive compensation plan.", "Incentive Compensation Plan", "Identifier", "", "ICP-US-HA-2027", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Incentive Plan Name", "Name of the incentive compensation plan.", "Incentive Compensation Plan", "Text", "", "Human Advice Advisor Incentive Plan 2027", "Internal", "", "", ""),
       ("Incentive Plan Type", "Overall structure of the plan.", "Incentive Compensation Plan", "Code", "Incentive Plan Type", "Formula Bonus", "Internal", "", "", ""),
       ("Incentive Plan Year", "Performance year the plan applies to.", "Incentive Compensation Plan", "Integer", "", "2027", "Internal", "", "", ""),
       ("Payout Frequency", "Frequency of incentive payments under the plan.", "Incentive Compensation Plan", "Code", "Frequency", "Annual", "Internal", "", "", ""),
       ("Eligible Advisor Roles", "Advisor roles that may participate in the plan.", "Incentive Compensation Plan", "Code (multi)", "Advisor Role", "Financial Advisor; Relationship Manager", "Internal", "", "", ""),
       ("Plan Approval Status", "Approval status of the plan design.", "Incentive Compensation Plan", "Code", "Approval Status", "Approved", "Internal", "", "", ""),
       ("Plan Effective From", "Date the plan took effect.", "Incentive Compensation Plan", "Date", "ISO 8601", "2027-01-01", "Internal", "", "", ""),
       ("Plan Effective To", "Date the plan ended.", "Incentive Compensation Plan", "Date", "ISO 8601", "2027-12-31", "Internal", "", "", ""),
     ]),
     ("Incentive Plan Component", [
       ("Component ID", "Unique identifier of the plan component.", "Incentive Plan Component", "Identifier", "", "ICP-US-HA-2027-C02", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Parent Incentive Plan", "Incentive compensation plan the component belongs to.", "Incentive Plan Component", "Reference (Incentive Compensation Plan)", "", "ICP-US-HA-2027", "Internal", "", "", ""),
       ("Component Measure", "What the component pays on: client retention, client satisfaction, review completion, net new assets of the book, qualified referrals or firm results; never sales of specific securities by default.", "Incentive Plan Component", "Code", "Incentive Measure", "Client Retention", "SEC Reg BI", "Internal", "Y", ""),
       ("Component Weight", "Share of the target incentive allocated to the component.", "Incentive Plan Component", "Percentage", "", "30%", "Internal", "", "", ""),
       ("Threshold Attainment", "Attainment below which the component pays nothing.", "Incentive Plan Component", "Percentage", "", "80%", "Internal", "", "", ""),
       ("Cap Amount", "Maximum payout of the component as an amount, where the cap is an amount.", "Incentive Plan Component", "Amount", "", "USD 15,000", "Internal", "", "", ""),
       ("Cap Percentage", "Maximum payout of the component as a percentage of its target, where the cap is a percentage.", "Incentive Plan Component", "Percentage", "", "150%", "Internal", "", "", ""),
       ("Product-Specific Time-Limited Indicator", "Whether the component is based on sales of specific securities or specific types of securities within a limited period, which Regulation Best Interest requires the broker-dealer to identify and eliminate.", "Incentive Plan Component", "Boolean", "", "N", "SEC Reg BI", "FINRA Rule 2341", "Y", ""),
       ("Proprietary Product Linked Indicator", "Whether the measure counts the firm's own funds or ETFs differently from other products; a conflict the 08 review must test.", "Incentive Plan Component", "Boolean", "", "N", "SEC Reg BI", "Internal", "", ""),
       ("Rollover Neutral Indicator", "Whether the component pays the same whether or not a client rolls workplace plan assets to the firm or moves to an advisory account; a component that is not neutral is a conflict the 08 review must mitigate (Reg BI Rule 15l-1(a)(2)(iii)(B) and (C), DOL PTE 2020-02).", "Incentive Plan Component", "Boolean", "", "Y", "DOL PTE 2020-02", "SEC Reg BI", "Y", ""),
       ("Incentive Conflict Review Reference", "08 incentive conflict review of the component under Rule 15l-1(a)(2)(iii).", "Incentive Plan Component", "Reference (Incentive Conflict Review, 08)", "", "ICP-US-HA-2027-C02 / 2026-11-20", "SEC Reg BI", "", "", ""),
     ]),
     ("Incentive Plan Participation", [
       ("Plan Participant", "Advisor assigned to the plan.", "Incentive Plan Participation", "Reference (Advisor)", "", "EMP-20417", "Internal", "", "Y", "Object PII tier: PII - financial (employee compensation; Confidential - Compensation, restricted under CD-344). PII (employee identifier)."),
       ("Assigned Plan", "Incentive compensation plan assigned to the participant.", "Incentive Plan Participation", "Reference (Incentive Compensation Plan)", "", "ICP-US-HA-2027", "Internal", "", "Y", "PII (employee)."),
       ("Target Incentive Amount", "Annual incentive payable at 100% attainment.", "Incentive Plan Participation", "Amount", "", "USD 40,000", "Internal", "", "Y", "PII (employee); Confidential - Compensation (CD-344)."),
       ("Participant Eligibility Status", "Whether the participant may earn and be paid under the plan.", "Incentive Plan Participation", "Code", "Participant Eligibility Status", "Eligible", "Internal", "", "", "PII (employee)."),
       ("Plan Acknowledgment Date", "Date the participant acknowledged the plan document.", "Incentive Plan Participation", "Date", "ISO 8601", "2027-01-20", "Internal", "", "", "PII (employee)."),
       ("Participation Effective From", "Date the participation took effect.", "Incentive Plan Participation", "Date", "ISO 8601", "2027-01-01", "Internal", "", "", "PII (employee)."),
       ("Participation Effective To", "Date the participation ended.", "Incentive Plan Participation", "Date", "ISO 8601", "", "Internal", "", "", "PII (employee)."),
     ]),
   ]),
   ("Statements & Recognition", "Incentive statements issued to participants and non-cash recognition awards.", [
     ("Compensation Statement", [
       ("Statement ID", "Unique identifier of the compensation statement.", "Compensation Statement", "Identifier", "", "CPS-2027-Q4-20417", "Internal", "", "Y", "Object PII tier: PII - financial (employee compensation; Confidential - Compensation, restricted under CD-344)."),
       ("Statement Participant", "Advisor the statement is for.", "Compensation Statement", "Reference (Advisor)", "", "EMP-20417", "Internal", "", "Y", "PII (employee identifier)."),
       ("Statement Period End", "Last day of the period the statement covers.", "Compensation Statement", "Date", "ISO 8601", "2027-12-31", "Internal", "", "", "PII (employee)."),
       ("Total Earned", "Total incentive earned in the period across components.", "Compensation Statement", "Amount", "", "USD 38,600", "Internal", "", "", "PII (employee); Confidential - Compensation (CD-344)."),
       ("Net Payable Amount", "Amount sent to payroll after holdbacks and adjustments.", "Compensation Statement", "Amount", "", "USD 38,600", "Internal", "", "Y", "PII (employee); Confidential - Compensation (CD-344)."),
       ("Statement Status", "Lifecycle status of the statement.", "Compensation Statement", "Code", "Compensation Statement Status", "Issued", "Internal", "", "", "PII (employee)."),
       ("Statement Issued Date", "Date the statement was issued to the participant.", "Compensation Statement", "Date", "ISO 8601", "2028-02-10", "Internal", "", "", "PII (employee)."),
       ("Payroll Result Reference", "20 payroll result that paid the statement.", "Compensation Statement", "Reference (Payroll Result)", "", "US-M-2028-02-R1 / EMP-20417", "Internal", "", "", "PII (employee)."),
     ]),
     ("Incentive Earnings Line", [
       ("Earning Component", "Plan component that produced the earnings.", "Incentive Earnings Line", "Reference (Incentive Plan Component)", "", "ICP-US-HA-2027-C02", "Internal", "", "", "Object PII tier: PII - financial (employee compensation; Confidential - Compensation, restricted under CD-344)."),
       ("Measured Result", "Value of the component measure for the participant in the period (for example a retention rate of 0.97).", "Incentive Earnings Line", "Decimal", "", "0.97", "Internal", "", "", "PII (employee)."),
       ("Attainment Percentage", "Measured result as a percentage of the component target.", "Incentive Earnings Line", "Percentage", "", "104%", "Internal", "", "", "PII (employee)."),
       ("Earned Amount", "Incentive earned for the component and period.", "Incentive Earnings Line", "Amount", "", "USD 12,480", "Internal", "", "Y", "PII (employee); Confidential - Compensation (CD-344)."),
     ]),
     ("Recognition Award", [
       ("Recognition Award ID", "Unique identifier of the recognition award.", "Recognition Award", "Identifier", "", "RECG-2026-00218", "Internal", "", "Y", "Object PII tier: PII - financial (employee compensation; Confidential - Compensation, restricted under CD-344)."),
       ("Award Recipient", "Employee who received the award.", "Recognition Award", "Reference (Advisor)", "", "EMP-20417", "Internal", "", "", "PII (employee identifier)."),
       ("Recognition Program", "Program under which the award was made.", "Recognition Award", "Text", "", "Client Experience Excellence 2026", "Internal", "", "", "PII (employee)."),
       ("Recognition Award Type", "Kind of award, such as a peer recognition, a firm-paid recognition event or a merchandise award.", "Recognition Award", "Code", "Recognition Award Type", "Recognition Event", "FINRA Rule 3220", "", "", "PII (employee)."),
       ("Award Date", "Date the award was made.", "Recognition Award", "Date", "ISO 8601", "2026-03-02", "Internal", "", "", "PII (employee)."),
       ("Non-Cash Award Value", "Estimated value of a non-cash award.", "Recognition Award", "Amount", "", "USD 1,200", "FINRA Rule 2341", "", "", "PII (employee); Confidential - Compensation (CD-344)."),
       ("Product-Specific Criteria Indicator", "Whether the award was earned on sales of specific securities or specific types of securities within a limited period (prohibited by default under Regulation Best Interest).", "Recognition Award", "Boolean", "", "N", "SEC Reg BI", "FINRA Rule 2341", "Y", "PII (employee)."),
       ("Award Conduct Review Reference", "08 incentive conflict review of the recognition program.", "Recognition Award", "Reference (Incentive Conflict Review, 08)", "", "RECG-2026-00218 / 2026-02-20", "SEC Reg BI", "", "", "PII (employee)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 # Advisors & Teams
 "Advisor Status": ("Internal (status as a client-facing advisor; employment status is 20)", [("Onboarding","Hired or transferred into an advisor role; no book yet"),("Active",""),("Transitioning Book","Households being reassigned (departure, retirement, role change)"),("Inactive","No longer advising")]),
 "Advisor Role": ("Internal (registration requirement of each role is 20 Regulated Role Category)", [("Financial Advisor","Named advisor with a book of households (HA)"),("Associate Advisor","Supports a lead advisor in an ensemble"),("Financial Planner","Prepares plans (45); may not hold a book"),("Relationship Manager","Institutional advisory or high-tier relationship lead (IA, HA)"),("Service Associate","Licensed associate in a pooled phone or chat team (DB, WR)"),("Digital Advice Advisor","Advisor on call for digital advice clients (DA)"),("Rollover Support Specialist","Workplace participant education and rollover support (WR)"),("Trust Officer","Officer of the trust company (TR, 51)"),("Advice Team Leader","Leads a coverage team")]),
 "Credential Type": ("CFP Board / CFA Institute / The American College / AICPA / ABA (designations; confirm the firm's accepted list)", [("CFP","CERTIFIED FINANCIAL PLANNER"),("CFA","Chartered Financial Analyst"),("ChFC","Chartered Financial Consultant"),("CPA","Certified Public Accountant"),("CPA/PFS","Personal Financial Specialist"),("CTFA","Certified Trust and Financial Advisor"),("CIMA","Certified Investment Management Analyst"),("RICP","Retirement Income Certified Professional"),("CLU","Chartered Life Underwriter"),("EA","Enrolled Agent"),("Other","")]),
 "Advisor Specialty": ("Internal", [("Retirement Income Planning",""),("Rollover and Workplace Transitions",""),("Equity Compensation",""),("Tax-Aware Investing",""),("Estate and Legacy Planning",""),("Business Owners",""),("Charitable Giving",""),("Education Planning",""),("Special Needs Planning",""),("Institutional Mandates",""),("Other","")]),
 "Coverage Team Type": ("Internal", [("Pooled Service Team","Licensed associates answering phone and chat (DB, WR)"),("Digital Advice Pool","Advisors on call for digital advice clients (DA)"),("Ensemble Team","Named lead advisor with associates and planners (HA)"),("Institutional Relationship Team","OCIO and institutional mandates (IA)"),("Trust Team","Trust officers and relationship managers (TR)"),("Specialist Team","Planners or specialists supporting several teams")]),
 "Team Membership Role": ("Internal", [("Lead Advisor",""),("Associate Advisor",""),("Financial Planner",""),("Service Associate","Service associate paired with the team"),("Specialist",""),("Temporary Cover","")]),
 # Branches & Supervisory Structure
 "Branch Type": ("FINRA Rule 3110(f); FINRA Form BR (mastered in 03; 08 Branch Registration and Branch Inspection copy it)", [("Office of Supervisory Jurisdiction","Office where a Rule 3110(f)(1) function takes place, including the main office; inspected annually"),("Branch Office","Location meeting the Rule 3110(f)(2) definition; inspected annually if it supervises non-branch locations, else at least every three years"),("Non-Branch Location","Excluded from the branch office definition (for example a primary residence or an office of convenience); a residential supervisory location (Rule 3110.19) is a non-branch location flagged by Residential Supervisory Location Indicator")]),
 "Supervisory Link Type": ("FINRA Rule 3110 / Internal", [("Branch to OSJ",""),("Non-Branch Location to Supervising Office",""),("OSJ to Region",""),("Region to Home Office","")]),
 "Principal Designation Type": ("FINRA Rule 3110(a)(2) and (a)(4); FINRA Rule 2360(b)(16) and (b)(20); Advisers Act Section 203(e)(6) and Rule 206(4)-7 for advisory supervision", [("OSJ Principal","Appropriately registered principal designated in an OSJ"),("Branch Manager","Representative or principal with supervisory authority in a non-OSJ branch"),("Registered Options Principal","Approves options accounts"),("Supervising Principal - Advisory Accounts","Supervises advisory program accounts of the RIA"),("Correspondence Review Principal",""),("Home Office Supervisory Principal",""),("Delegated Supervisor","Delegate of a principal, within the firm's procedures")]),
 "Supervised Function": ("FINRA Rule 3110(a)(2); Advisers Act Rule 206(4)-7 for advisory program accounts (trust services are supervised under 12 CFR Part 9 in 51, not here)", [("Retail Brokerage Accounts",""),("Options Accounts",""),("Margin Accounts",""),("Advisory Program Accounts",""),("Retirement Rollovers",""),("Correspondence and Communications",""),("Account Opening Approval","")]),
 "Supervisory Assignment Type": ("FINRA Rule 3110(a)(5) / Internal", [("Primary Supervisor",""),("Delegate Supervisor",""),("Interim Cover","During the primary supervisor's absence"),("Heightened Supervision Supervisor","Carries out an 08 heightened supervision plan")]),
 # Coverage & Service Models
 "Coverage Role": ("Internal", [("Primary Advisor","Advisor of record when the assignment is primary"),("Associate Advisor",""),("Financial Planner",""),("Service Associate",""),("Relationship Manager",""),("Trust Officer",""),("Specialist","Overlay specialist, such as equity compensation or estate planning")]),
 "Contact Type": ("Internal / Investment Company Act Rule 3a-4", [("Annual Review","Review of the client's situation and objectives; meets the Rule 3a-4 annual contact"),("Quarterly Check-In",""),("Planning Update",""),("Proactive Outreach","Market event or life event contact"),("Onboarding Meeting","")]),
 "Assignment Rule Type": ("Internal", [("Tier and Geography",""),("Language",""),("Workplace Plan","Participants of a recordkept plan"),("Referral Source",""),("Named Exception","Specific household placed by approval"),("Round Robin","Even distribution across a team")]),
 "Rule Operator": ("Internal", [("Equals",""),("Not Equals",""),("In List",""),("Not In List",""),("Greater Than",""),("Less Than",""),("Between",""),("Within Geographic Group","")]),
 # Client Assignment & Capacity
 "Coverage Assignment Basis": ("Internal", [("Assignment Rule",""),("Client Request",""),("Channel Referral",""),("Reassignment",""),("Legacy Conversion","Loaded at system conversion")]),
 "Reassignment Reason": ("Internal", [("Advisor Departure",""),("Advisor Retirement",""),("Advisor Leave",""),("Role Change",""),("Capacity Rebalancing",""),("Service Tier Change",""),("Client Request",""),("Team Restructuring",""),("Registration Lapse","Advisor not registered in the client's state (08 copy)"),("Other","")]),
 "Reassignment Status": ("Internal", [("Planned",""),("Approved",""),("Clients Notified",""),("Effective",""),("Canceled","")]),
 # Advisor Activities
 "Activity Type": ("Salesforce FSC / Internal (form of the activity; the medium is Interaction Medium)", [("Meeting",""),("Call",""),("Message","Email, secure message or approved chat"),("Seminar / Workshop",""),("Task","To-do or follow-up"),("Partner Meeting","Meeting with an intermediary partner firm or external advisor (05, CW-138)"),("Consultant Meeting","Meeting with an investment consultant (05)"),("Plan Sponsor Review","Review meeting with a workplace plan sponsor or institutional client (16, 12)"),("Finals Presentation","Finals presentation in an institutional search (05)")]),
 "Interaction Medium": ("Salesforce FSC", [("In Person",""),("Video Conference",""),("Phone",""),("Email",""),("Chat / Messaging","Approved channels only"),("Webinar","")]),
 "Activity Purpose": ("Internal", [("Annual Review",""),("Planning Meeting",""),("Onboarding",""),("Rollover Discussion",""),("Portfolio Review",""),("Life Event",""),("Service Follow-Up",""),("Tax Planning",""),("Estate Planning",""),("Referral Introduction",""),("Relationship Check-In",""),("Other","")]),
 "Activity Status": ("Salesforce FSC", [("Planned",""),("Completed",""),("Canceled",""),("No-Show",""),("Rescheduled","")]),
 "Activity Participant Role": ("Internal (internal and external participants)", [("Advisor / Organizer",""),("Financial Planner",""),("Specialist",""),("Service Associate",""),("Note-Taker",""),("Client",""),("Household Member",""),("Client's Attorney",""),("Client's CPA",""),("Trusted Contact","02 Trusted Contact Designation (FINRA Rule 4512)"),("Authorized Agent","02 Authority Grant holder"),("External Advisor","Intermediary advisor (05)"),("Investment Consultant","(05)"),("Plan Sponsor Contact","(16, 12)"),("Partner Firm Contact","Home-office contact of an intermediary partner (05)")]),
 "Attendance Status": ("Salesforce FSC", [("Invited",""),("Accepted",""),("Declined",""),("Attended",""),("No-Show","")]),
 "Discussion Topic": ("Internal", [("Retirement Income",""),("Tax Planning",""),("Portfolio Performance",""),("Asset Allocation",""),("Rollover",""),("Estate Planning",""),("Education Funding",""),("Insurance Needs",""),("Fees and Pricing",""),("Life Event",""),("Market Outlook",""),("Service Issue",""),("Other","")]),
 "Summary Generation Method": ("Internal", [("Manual",""),("AI-Assisted - Reviewed","AI draft reviewed and edited by the owner"),("AI-Generated - Unreviewed","Must be reviewed before use")]),
 "Activity Outcome": ("Internal", [("Next Step Agreed",""),("Follow-Up Required",""),("Information Only",""),("Recommendation Made","Recommendation recorded in 45"),("Referral Made","Channel Referral created"),("Complaint Raised","Recorded as an 08 complaint"),("No Action","")]),
 "Activity Capture Method": ("Internal", [("Manual Entry",""),("Calendar Sync",""),("Email Capture",""),("Meeting Platform Integration",""),("AI Note-Taker",""),("Telephony Integration","")]),
 # Channel Referrals
 "Referral Channel": ("Internal (CW-065; source and target of an internal referral)", [("Self-Directed Brokerage",""),("Digital Advice",""),("Human Advice",""),("Client Service","Phone, chat and branch service teams (13)"),("Workplace Participant Services","Recordkeeping participant service (16)"),("Institutional Advisory",""),("Trust Company","Personal trust services (51)")]),
 "Referral Reason": ("Internal", [("Rollover Support",""),("Planning Need",""),("Assets Threshold Reached","Qualifies for a higher service tier (01)"),("Life Event",""),("Complex Situation",""),("Client Request",""),("Trust or Estate Need",""),("Other","")]),
 "Channel Referral Status": ("Internal", [("Submitted",""),("Accepted",""),("Contacted",""),("Converted","Engagement, enrollment, trust or lead recorded"),("Declined by Client",""),("Closed - No Action","")]),
 # Incentive & Recognition
 "Incentive Plan Type": ("Internal", [("Formula Bonus","Payout by component attainment against a target incentive"),("Discretionary Bonus","Manager-determined within a pool"),("Team Pool","Shared pool for a coverage team"),("Referral Award Plan","Awards for qualified channel referrals")]),
 "Incentive Measure": ("Internal (client-outcome and firm-level measures, CW-064; reviewed by 08 under Reg BI)", [("Client Retention",""),("Client Satisfaction",""),("Review Completion","Contact standard met (Call Frequency Standard)"),("Net New Assets - Book","All products; not product-specific"),("Qualified Referrals",""),("Plan Delivery","Financial plans delivered (45)"),("Firm Results","")]),
 "Participant Eligibility Status": ("Internal", [("Eligible",""),("Ineligible - Leave",""),("Ineligible - Conduct Hold","Pending an 08 matter"),("Ineligible - Terminated","")]),
 "Compensation Statement Status": ("Internal", [("Calculated",""),("Approved",""),("Issued",""),("Paid","Included in a 20 payroll result"),("Reissued","Corrected and reissued")]),
 "Recognition Award Type": ("Internal / FINRA Rules 3220 and 2341(l)(5)", [("Peer Recognition","No monetary value"),("Recognition Event","Firm-paid event or trip"),("Merchandise Award",""),("Charitable Donation in Recipient's Name",""),("Plaque or Certificate","")]),
 # Copies of enterprise shared lists (09 steward unless noted)
 "Business Line": ("Enterprise shared list Business Line (CW-004; steward 09)", [("DB","Direct brokerage and self-directed investing"),("DA","Digital advice"),("HA","Human and hybrid advice"),("PF","Proprietary funds and ETFs"),("WR","Workplace retirement recordkeeping"),("IA","Institutional advisory"),("IC","Intermediary channel"),("TR","Personal trust services")]),
 "Frequency": ("Enterprise shared list Frequency (steward 09; ISO 20022 frequency codes)", [("Real-Time",""),("Intraday",""),("Daily",""),("Weekly",""),("Biweekly",""),("Monthly",""),("Quarterly",""),("Semi-Annual",""),("Annual",""),("Biennial",""),("On Event",""),("Ad Hoc","")]),
 "Record Status": ("Enterprise shared list Record Status (steward 09)", [("Draft",""),("Proposed",""),("Pending",""),("Active",""),("Paused",""),("Inactive",""),("Deprecated",""),("Retired","")]),
 "Approval Status": ("Enterprise shared list Approval Status (steward 09)", [("Not Required",""),("Pending",""),("Approved",""),("Approved with Conditions",""),("Retrospectively Approved",""),("Rejected",""),("Expired",""),("Withdrawn","")]),
 "Information Classification": ("Enterprise shared list Information Classification (steward 09)", [("Public",""),("Internal",""),("Confidential",""),("Confidential - Personal Data",""),("Confidential - Client",""),("Confidential - Financial",""),("Confidential - Compensation",""),("Confidential - Licensed",""),("Restricted",""),("Restricted - Personal Data",""),("Restricted - MNPI",""),("Restricted - Commercial Terms",""),("Restricted - Legal","")]),
 "Sentiment": ("Enterprise shared list Sentiment (steward 09)", [("Positive",""),("Neutral",""),("Negative",""),("Mixed",""),("Unknown","")]),
 "Personal Data Category": ("Enterprise shared list Personal Data Category (steward 02; SEC Regulation S-P, CCPA / CPRA)", [("No Personal Data",""),("Identity",""),("Contact",""),("Professional / Employment",""),("Registration / Licensing",""),("HR / Employee",""),("Financial",""),("Government Identifier",""),("Online Identifiers / Engagement",""),("Inferences / Segmentation",""),("Opinion About Individual",""),("Free Text - May Contain Personal Data","")]),
}

# ---------------------------------------------------------------------------
REL = [
 ("Advisor","extends","Employee [20]","1 : 1","Profile pattern (CD-144); keyed by EMP-; identity, job and pay stay in 20."),
 ("Advisor","holds","Advisor Role Assignment","1 : 1..n","Effective dated."),
 ("Advisor Role Assignment","requires registrations of","Job Profile [20]","n : 0..1","Regulated Role Category is the role requirement (CW-920)."),
 ("Advisor","holds","Advisor Credential","1 : 0..n",""),
 ("License & Registration Reference","references","Individual Registration [08]","1 : 0..n","Status indicators and registered states are Derived copies (CW-072)."),
 ("Advisor","represents","Internal Legal Entity [09]","n : 1..n","Broker-dealer, RIA or both; trust company for trust officers."),
 ("Coverage Team","groups","Advisor via Coverage Team Membership","1 : 1..n","Effective dated; replaces wholesale sales pairing."),
 ("Coverage Team","works from","Office Location [09]","n : 0..1",""),
 ("Coverage Team","serves","Service Tier [01]","n : n",""),
 ("Firm Branch Office","profiles","Office Location [09]","1 : 1","Keyed by SITE-."),
 ("Firm Branch Office","is registered by","Branch Registration [08]","1 : 0..1","Form BR filing is 08's."),
 ("Firm Branch Office","is inspected through","Branch Inspection [08]","1 : 0..n","Inspection cycle follows OSJ and branch type (FINRA Rule 3110(c))."),
 ("Supervisory Hierarchy Link","has child","Office Location [09] / Org Unit [09]","n : 1","Child Supervisory Unit."),
 ("Supervisory Hierarchy Link","has parent","Office Location [09] / Org Unit [09]","n : 1","Parent Supervisory Unit."),
 ("Principal Designation","designates","Employee [20]","n : 1","FINRA Rule 3110(a)(2) and (a)(4)."),
 ("Principal Designation","is qualified by","Individual Registration [08]","n : 0..1",""),
 ("Supervisory Assignment","assigns","Employee [20] (supervised person) to Employee [20] (supervisor)","n : 1","FINRA Rule 3110(a)(5)."),
 ("Supervisory Assignment","carries out","Heightened Supervision Plan [08]","n : 0..1","Plan basis and conditions stay in 08; the heightened-supervision supervisor is mastered here and copied by 08."),
 ("Supervisory Assignment","is read by","Supervisory Review [08]","1 : 0..n","08 routes reviews to the assigned supervisor."),
 ("Coverage Model","serves","Service Tier [01]","n : n","Delivery Mode on the 01 list."),
 ("Coverage Model","sets","Call Frequency Standard","1 : 0..n","By service tier and contact type."),
 ("Coverage Assignment Rule","has","Coverage Assignment Rule Criterion","1 : 1..n",""),
 ("Coverage Assignment Rule Criterion","compares with","Geographic Group [09]","n : 0..1",""),
 ("Coverage Assignment Rule","places households on","Coverage Team / Advisor","n : 1",""),
 ("Coverage Assignment Rule","names (named exception)","Party [02]","n : 0..1","Excepted Party."),
 ("Party Coverage Assignment","covers","Party [02] (Client Household PTY-HH- or client)","n : 1","The one advisor-of-record master (CW-063); one primary per scope per date, resolved account, then client, then household."),
 ("Party Coverage Assignment","is limited to","Account [15]","n : 0..n","Account-scope exception; blank means all accounts."),
 ("Party Coverage Assignment","is held by","Advisor / Coverage Team","n : 1",""),
 ("Party Coverage Assignment","is read by","Advice Engagement [45] / Fee billing [47] / flow attribution [06]","1 : 0..n","Read as of a date; no copy of the advisor of record is held there."),
 ("Coverage Assignment Rule Criterion","evaluates","Service Tier Assignment [02]","n : 0..1","Tier criteria read the 02 assignment (CW-028); no attribute is copied."),
 ("Coverage Reassignment","moves","Party Coverage Assignment via Coverage Reassignment Item","1 : 1..n","Ends the prior and creates the new assignment."),
 ("Coverage Reassignment Item","is notified by","Recipient Delivery Record [13]","n : 0..1",""),
 ("Advisor Capacity Snapshot","measures","Advisor / Coverage Team","n : 1","Counts from 02 and 15 and client assets from 06 are Derived copies."),
 ("Advisor Capacity Snapshot","reads","Client Assets [06]","n : 1","Derived copy; future owner 06, W4."),
 ("Advisor Activity","concerns","Party [02] (household, client or partner party)","n : 1","Partner and consultant meetings of 05 are activities too (CW-138)."),
 ("Advisor Activity","has","Internal Participant / External Participant","1 : 0..n",""),
 ("Advisor Activity","is part of","Advice Engagement [45]","n : 0..1",""),
 ("Advisor Activity","holds","Advice Review [45]","1 : 0..1","Review outcome is 45's."),
 ("Advisor Activity","arises from","Service Request [13]","n : 0..1","Contact-center interactions are not activities (CW-061)."),
 ("Outcome & Follow-Up","results in","Recommendation [45]","1 : 0..n","Rationale and best-interest evidence stay in 45."),
 ("Outcome & Follow-Up","raises","Complaint [08]","1 : 0..1",""),
 ("Activity Capture","is archived as","Captured Communication Record [08]","1 : 0..n","SEC Rule 17a-4(b)(4); Advisers Act Rule 204-2(a)(7)."),
 ("Activity Capture","may involve","Gift / Entertainment Item [08]","1 : 0..n",""),
 ("Discussion Content","discusses","Investment Product [01] / Service Offering [01]","n : n",""),
 ("Channel Referral","refers","Party [02]","n : 1",""),
 ("Channel Referral","results in","Advice Engagement [45] / Program Enrollment [15] / Marketing Lead [04] / Trust [51]","1 : 0..1","Outcome references (CW-065)."),
 ("Channel Referral","produces","Party Coverage Assignment","1 : 0..1",""),
 ("Channel Referral","has","Referral Status History","1 : 1..n",""),
 ("Incentive Compensation Plan","has","Incentive Plan Component","1 : 1..n","Components keyed ICP-n-Cnn."),
 ("Incentive Plan Component","is reviewed by","Incentive Conflict Review [08]","1 : 0..n","Rule 15l-1(a)(2)(iii) (CW-064)."),
 ("Incentive Plan Participation","assigns","Incentive Compensation Plan to Advisor","n : 1",""),
 ("Compensation Statement","has","Incentive Earnings Line","1 : 1..n",""),
 ("Compensation Statement","is paid by","Payroll Result [20]","n : 0..1","Payroll and pay are 20's."),
 ("Recognition Award","is reviewed by","Incentive Conflict Review [08]","n : 0..1","Non-cash compensation (FINRA Rules 3220 and 2341)."),
]

# ---------------------------------------------------------------------------
SRC = [
 ("FINRA Rule 3110 Supervision (including Supplementary Material .18 remote inspections pilot and .19 residential supervisory location)","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110","Rule (public)","Supervisory system: principal designation by business type (a)(2), registration and designation of branch offices and OSJs (a)(3), principals in each OSJ (a)(4), assignment of each registered person to a supervisor (a)(5); inspection cycles (c)(1); OSJ and branch office definitions (f); Regulatory Notice 24-02 makes .19 (residential supervisory location) effective 1 June 2024 and the .18 remote inspections pilot effective 1 July 2024 (pilot end date confirm)","Firm Branch Office, Supervisory Hierarchy Link, Principal Designation, Supervisory Assignment",["FINRA Rule 3110"]),
 ("FINRA Form BR (Uniform Branch Office Registration Form)","FINRA","https://www.finra.org/registration-exams-ce/broker-dealers/registration-forms/form-br","Regulatory form (public)","Branch office and OSJ registration fields; the filing itself is 08's","Branch Type, OSJ Indicator, Branch Registration Reference",["FINRA Form BR"]),
 ("FINRA Rules 1210 Registration Requirements and 1220 Registration Categories","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/1220","Rule (public)","Representative and principal registration categories behind advisor roles and principal designations","License & Registration Reference, Advisor Role, Principal Designation",["FINRA Rule 1210","FINRA Rule 1220"]),
 ("SEC Rule 203A-3 Definitions (investment adviser representative)","US SEC","https://www.ecfr.gov/current/title-17/section-275.203A-3","Regulation (public)","Investment adviser representative definition; state registration of IARs","Investment Adviser Representative Indicator, Entities Represented",["SEC Rule 203A-3"]),
 ("Regulation Best Interest, Exchange Act Rule 15l-1(a)(2)(iii)","US SEC","https://www.ecfr.gov/current/title-17/section-240.15l-1","Regulation (public)","Conflict of interest obligation: mitigate incentives of associated persons; identify and eliminate sales contests, quotas, bonuses and non-cash compensation based on specific securities within a limited period","Incentive Plan Component, Recognition Award, Incentive Measure",["SEC Reg BI"]),
 ("FINRA Rule 3220 Influencing or Rewarding Employees of Others and Rule 2341 Investment Company Securities (paragraph (l)(5) non-cash compensation)","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/3220","Rule (public)","Gifts and non-cash compensation; conditions on recognition events and sales incentives (confirm the current Rule 3220 gift limit)","Recognition Award, Gifts & Entertainment Reference",["FINRA Rule 3220","FINRA Rule 2341"]),
 ("FINRA Rule 2360 Options (paragraphs (b)(16) account approval and (b)(20) supervision of accounts)","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2360","Rule (public)","Options account approval and supervision by a Registered Options Principal","Principal Designation Type",["FINRA Rule 2360"]),
 ("SEC Rule 17a-4 Records to be preserved by certain exchange members, brokers and dealers (paragraph (b)(4))","US SEC","https://www.ecfr.gov/current/title-17/section-240.17a-4","Regulation (public)","Retention of business communications sent and received","Activity Capture, Meeting Notes",["SEC Rule 17a-4"]),
 ("Advisers Act Rule 204-2 Books and records to be maintained by investment advisers (paragraph (a)(7))","US SEC","https://www.ecfr.gov/current/title-17/section-275.204-2","Regulation (public)","Written communications relating to recommendations and advice","Activity Capture",["Advisers Act Rule 204-2"]),
 ("Investment Company Act Rule 3a-4 (advisory programs)","US SEC","https://www.ecfr.gov/current/title-17/section-270.3a-4","Regulation (public)","Annual contact with advisory program clients","Call Frequency Standard, Contact Type, Activity Purpose",["ICA Rule 3a-4"]),
 ("FINRA Rule 4530 Reporting Requirements","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/4530","Rule (public)","Customer complaint definition and reporting; complaints raised in activities are 08 records","Complaint Raised",["FINRA Rule 4530"]),
 ("FINRA Rule 2210 Communications with the Public","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2210","Rule (public)","Content shared with clients; approval is 08's","Content Assets Shared",["FINRA Rule 2210"]),
 ("Advisers Act Section 203(e)(6) and Rule 206(4)-7 (compliance procedures and failure to supervise)","US SEC","https://www.ecfr.gov/current/title-17/section-275.206(4)-7","Regulation (public)","Supervision of investment adviser representatives and advisory program accounts","Principal Designation Type, Supervised Function",["Advisers Act Rule 206(4)-7"]),
 ("DOL PTE 2020-02 (improving investment advice for workers and retirees)","US Department of Labor, EBSA","https://www.dol.gov/sites/dolgov/files/ebsa/about-ebsa/our-activities/resource-center/faqs/new-fiduciary-advice-exemption.pdf","Exemption and DOL FAQ (public; adopted 18 December 2020, effective 16 February 2021; confirm the status of the 2024 amendments)","Rollover recommendations; policies to mitigate incentives tied to rollovers","Rollover Neutral Indicator",["DOL PTE 2020-02"]),
 ("CFP Board Code of Ethics and Standards of Conduct","CFP Board","https://www.cfp.net/ethics/code-of-ethics-and-standards-of-conduct","Professional standard (public)","Credential holder obligations and public verification of CFP certification","Advisor Credential, Credential Type",["CFP Board Standards"]),
 ("FINRA CRD and BrokerCheck","FINRA","https://www.finra.org/registration-exams-ce","Public register","Individual CRD numbers and public registration status","Individual CRD Number",["FINRA CRD"]),
 ("SEC Regulation S-P (17 CFR Part 248, Subpart A)","US SEC","https://www.ecfr.gov/current/title-17/part-248","Regulation (public)","Safeguarding of customer information in activity notes and referrals (confirm the 2024 amendment compliance dates)","Notes Personal Data Categories, PII flags",["SEC Regulation S-P"]),
 ("CCPA as amended by the CPRA (personal information categories)","California Attorney General","https://oag.ca.gov/privacy/ccpa","Statute (public)","Employee and consumer personal information categories","Personal Data Category",["CCPA / CPRA"]),
 ("ISO/IEC 27001 Annex A 5.12 Classification of information","ISO","https://www.iso.org/standard/27001","ISO standard","Information classification of activities","Activity Classification",["ISO/IEC 27001"]),
 ("ISO 639 Language codes; ISO 3166-2 country subdivision codes; ISO 8601","ISO","https://www.iso.org/iso-639-language-code","ISO standards","Languages spoken, registered states, dates","Languages Spoken, Registered States",["ISO 639","ISO 3166","ISO 8601"]),
 ("Salesforce Financial Services Cloud data model (advisor, household, interaction and interaction summary objects)","Salesforce","https://developer.salesforce.com/docs/platform/data-models/guide/fsc-customer.html","Vendor documentation (public; confirm path)","Structure cross-check for advisor, household coverage and interaction records","Advisor, Coverage Team, Advisor Activity, participants",["Salesforce FSC"]),
]
