"""Data Domain 04 - Marketing, Digital & Client Engagement (wealth-manager reference model; adapts the wholesale 04 Marketing &
Digital, CW-001, CW-904). Content module for taxonomy_builder.py. The wholesale version stays at tag wholesale-v1.0."""

META = {
 "title": "Marketing, Digital & Client Engagement Data Taxonomy",
 "subtitle": "Business domain 04 - Marketing, Digital & Client Engagement | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "04_Marketing_and_Digital/Marketing_and_Digital_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the marketing, digital and client engagement data of a US wealth manager that acquires and serves investors directly: self-directed brokerage, digital and human advice, its own mutual funds and ETFs, workplace retirement recordkeeping, institutional advisory, a thin intermediary channel and optional personal trust services. The domain masters how the firm reaches people (campaigns, content, events, email, social and paid media), what visitors and clients do on its website and app, how it tests and personalizes their journeys, and how a visitor becomes a prospect, an applicant and a funded client. It is built from open vendor data models (Salesforce Campaign / CampaignMember / Lead, Account Engagement, Adobe XDM, GA4 and UTM conventions), open metadata standards (Dublin Core, IPTC, schema.org, WCAG) and the US rules that shape the data: FINRA Rule 2210 and the Advisers Act marketing rule (Rule 206(4)-1) for communications, the CAN-SPAM Act and the TCPA for email, text and telephone outreach, FINRA Rule 3230 and the National Do Not Call Registry, Regulation Best Interest for nudges that may be recommendations, and the CCPA / CPRA for tracking choices of website visitors. Use it as a starting point for a marketing data model, a CDP or marketing automation design, a digital analytics and experimentation design, a data catalog or a business glossary."),
  ("Scope", "In scope: marketing themes and messaging (the brand register is 42 Corporate Communications & Public Affairs, BRD-; CD-271); campaigns (program > campaign > wave > tactic) with business line, targeting, products and offerings, budgets, spend, tracking codes and members; content assets and their audience restriction, classification, versions, rights, accessibility and the 08 review reference; client events, seminars, webinars and workplace education with registrations and attendance; digital properties (website, client website, mobile app), pages, forms and the martech inventory; web visitors, the client's Digital Profile (online login profile), visitor tracking choices, sessions, logins, app and web engagement events, email sends and interactions, media engagement and engagement scores; marketing audiences, subscription topics and suppression lists; leads, the application journey up to submission and acquisition milestones to first funding; nudges and experiments; promotion offers and enrollments, client referrals and client surveys (NPS, CSAT); social media and paid media; touchpoints, attribution models and attributed outcomes. "
             "Out of scope (referenced by ID only): parties, prospects, households, consents, contact points, communication preferences and privacy opt-outs, segment assignment, investor profile and onboarding (02 Client & Household; PTY-, CNS-, CTP-, ONB-); accounts, account opening and lifecycle events (15 Account; ACC-, ALE-); products, share classes, commentary and service offerings (01; PRD-, SHC-, CMT-, OFFR-); advisors, coverage teams and advisor activities (03 Advisor Organization, Coverage & Supervision; ACT-, SLT-); review and approval of communications, social media supervision and complaints (08 Retail Conduct & Supervision; REV-, CPL-); service interactions, service requests, tax forms and required-document delivery (13 Client Service & Communications; CCI-, SRQ-); advice engagements and recommendations (45 Financial Planning & Advice; RECOM-); fee waivers (47 Pricing, Fees & Billing; FWV-); award payments (50 Money Movement, W3); net new assets by campaign (06, W4); metric definitions (21; KPI-); applications (41; APPL-); employees (20; EMP-)."),
  ("Structure", "Four levels: Data Domain > Data Family > Data Business Object > Data Business Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Marketing Theme (under a 42 Brand) -> Campaign (program > campaign > wave > tactic, with a Business Line) -> Content Asset, Marketing Event, Email Send, Social Post, Media Placement, Nudge Definition and Promotion Offer (what a campaign deploys) -> Engagement Event and Email Interaction (what an anonymous Web Visitor or a known client did, in a Session on a Digital Property; logins carry the client's Digital Profile, DIGP-) -> Marketing Lead (LEAD-) until the identity threshold, then a 02 Party (Relationship Stage Prospect) -> Application Journey (JRNY-) to submission -> Acquisition Milestones (account opened, funded, advice enrolled, rollover completed) -> Attributed Outcome (credit to campaigns under an Attribution Model; 06 applies the weights to net new assets). Audiences (Marketing Segment), Subscription Topics (SUB-, read by 02 Communication Preference) and Suppression Entries control who may be contacted; Audience Restriction on assets, pages, events and topics controls what each audience may see. Experiments (EXPMT-) assign visitors and clients to variants; Client Surveys (CSVY-) collect Survey Responses (SRSP-) after interactions and milestones; Client Referrals (CRFL-) and Promotion Enrollments tie rewards to 50 payments and 47 fee waivers."),
  ("Design principles", "1) Reuse open vendor models (Salesforce, Adobe XDM, GA4) and metadata standards (Dublin Core, IPTC, schema.org) for names and structures; internal attributes only where none exists. 2) Reference, don't copy: people are 02 Parties; 04 holds captured, pre-match values of visitors and leads (flagged PII, kept as lineage) only until the identity threshold (CW-083). 3) Consent and opt-in state are 02 (CW-029, CW-084): 04 masters the subscription topic catalog, the suppression list, unsubscribe events (written to 02) and the tracking choices of unmatched visitors. 4) The funnel ends at account opening (CW-085): from submission the application is 15's; questionnaire answers are 02's; advice is 45's; net new assets are 06's. 5) Compliance owns approval: assets, messages, nudges, promotions, experiments that change client communications and social posts carry the 08 REV- reference and a read-only approval mirror; a nudge that may be a recommendation is classed and routed to 08 and 45 (CW-091). 6) Effective-date memberships, suppressions and statuses; date scores and milestones. 7) Flag Critical Data Elements (CDE) and personal data (PII); every object states its PII tier."),
  ("Applies To", "Shows the record at which each attribute is held: Theme, Campaign, Campaign Member, Tracking Code, Content Asset, Event, Registration, Digital Property, Web Page, Visitor, Digital Profile, Tracking Consent, Session, Engagement Event, Score, Email, Segment, Subscription, Suppression, Lead, Journey, Milestone, Nudge, Experiment, Promotion, Referral, Survey, Social Account, Social Post, Placement, Touchpoint, Attribution or All."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify, target, restrict, measure or attribute marketing and digital activity, to evidence that outreach honored audience restrictions, opt-outs, do-not-call and suppression rules, or to evidence the funnel from first touch to funded account. Confirm with data owners."),
  ("Primary / Secondary Reference", "Standard or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Regulatory references (FINRA, SEC, FTC, FCC, CCPA / CPRA) indicate the rule that drives the data requirement; interpretation and approval sit with 08 Retail Conduct & Supervision and Legal. Next step: map vendor-aligned attributes to exact field API names in the firm's CRM, marketing automation, DAM, analytics and experimentation configuration."),
  ("Notes", "PII = personal data under the GLBA, Regulation S-P and US state privacy laws (CCPA / CPRA and others). Each object's PII tier is stated in the Notes of its first attribute: 'PII - identity' (including pseudonymous visitor and device identifiers), 'PII - financial', 'PII - may contain special category (CD-344)' or 'No PII'. Opt-in state, consents and privacy opt-outs of a known party are mastered in 02; 04 records the state applied when it collected or sent."),
  ("Tabs", "Hierarchy: families, object groups and objects with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: object-level cardinalities and cross-domain references | Sources: standards and data models used, owners, licenses and links."),
  ("Suggested next steps", "1) Validate families, CDEs and boundary calls with Marketing, Digital Product, Client Experience, Marketing Operations, Retail Conduct & Supervision (08), Privacy and Client Onboarding. 2) Map attributes to source systems (CRM, marketing automation, CDP, DAM, CMS, web and app analytics, experimentation, push and in-app messaging, survey, social publishing and archiving, ad platforms). 3) Agree the identity threshold and party-match rules with 02 (CW-083). 4) Agree the unsubscribe and tracking-choice write-back to 02 Communication Preference and Privacy Profile (CW-084). 5) Agree the hand-off from Application Journey to 15 Account Opening and the digital advice engagement in 45 (CW-085). 6) Agree the Recommendation Risk Class routing of nudges with 08 and 45 (CW-091). 7) Agree the attribution model and the net new assets feed with 06 (W4). 8) Extend code lists to firm values and assign owners and stewards per family."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Brand & Messaging", "MK-BRD",
  "The marketing themes and messaging pillars that campaigns, content and nudges are built on. The brand register is 42 Corporate Communications & Public Affairs (BRD-, CD-271); 04 keeps product and campaign marketing.",
  [
   ("Themes & Messaging", "Reusable marketing themes and approved key messages that align campaigns, content, nudges and advisor conversations.", [
     ("Marketing Theme", [
       ("Theme ID", "Unique identifier for the marketing theme.", "Theme", "Identifier", "", "THM-0021", "Internal", "", "", "Object PII tier: No PII."),
       ("Theme Name", "Name of the theme as used in campaign planning.", "Theme", "Text", "", "Retire on your terms", "Internal", "", ""),
       ("Theme Type", "Category of theme.", "Theme", "Code", "Theme Type", "Retirement Readiness", "Internal", "", ""),
       ("Theme Strategies / Products", "Strategies, products and service offerings the theme is designed to support.", "Theme", "Reference (Strategy / Product / Service Offering) (multi)", "", "PRD-00981; OFFR-0012", "Internal", "", "", "Owned by 01 Investment Product & Service Offering."),
     ]),
     ("Messaging Pillar", [
       ("Key Message Statement", "The approved headline message for the pillar.", "Theme", "Text", "", "Low costs mean more of your return stays with you", "Internal", "", "", "Object PII tier: No PII."),
       ("Proof Points", "Supporting facts that substantiate the message, each with its as-of date.", "Theme", "Text", "", "Asset-weighted average fund expense ratio of 0.09% (as of 2026-06-30); no commission on online US-listed stock and ETF trades", "Internal", "SEC Marketing Rule", "", "Performance, ratings and cost claims require substantiation and approval (08)."),
       ("Messaging Compliance Review", "Compliance review of the content asset that carries the pre-approved message text for reuse.", "Theme", "Reference (Compliance Review)", "", "REV-2026-001877", "Internal", "FINRA Rule 2210", "", "Owned by 08 Retail Conduct & Supervision."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Campaign Management", "MK-CAM",
  "Planned, budgeted marketing initiatives organized as program > campaign > wave / tactic, with a business line, objectives, targeting, products and offerings, spend, tracking codes and members.",
  [
   ("Campaign Definition", "Identity, hierarchy, ownership, business line and dates of a campaign record at any level.", [
     ("Campaign", [
       ("Campaign ID", "Unique identifier for the campaign record (any level).", "Campaign", "Identifier", "", "CAM-004512", "Salesforce", "Adobe XDM", "Y", "Object PII tier: No PII."),
       ("Campaign Name", "Name of the campaign following the firm naming convention.", "Campaign", "Text", "", "FY27Q1_DB_IRA_ContributionSeason_Wave2", "Salesforce", "", ""),
       ("Campaign Level", "Level of the record in the campaign hierarchy.", "Campaign", "Code", "Campaign Level", "Wave", "Internal", "Salesforce", ""),
       ("Parent Campaign", "Campaign record directly above this one in the hierarchy.", "Campaign", "Reference (Campaign)", "", "CAM-004500", "Salesforce", "", ""),
       ("Campaign Type", "Nature of the campaign.", "Campaign", "Code", "Campaign Type", "Funding", "Salesforce", "", ""),
       ("Campaign Status", "Lifecycle status of the campaign.", "Campaign", "Code", "Campaign Status", "In Progress", "Salesforce", "", "Y"),
       ("Campaign Owner", "Marketing employee accountable for the campaign.", "Campaign", "Reference (Employee)", "", "EMP-00412", "Salesforce", "", ""),
       ("Planned Start Date", "Date the campaign is planned to start.", "Campaign", "Date", "ISO 8601", "2027-01-04", "Salesforce", "", ""),
       ("Planned End Date", "Date the campaign is planned to end.", "Campaign", "Date", "ISO 8601", "2027-04-15", "Salesforce", "", ""),
       ("Marketing Theme", "Theme the campaign executes.", "Campaign", "Reference (Theme)", "", "THM-0021", "Internal", "", ""),
       ("Co-Marketing Agreement", "Agreement with an intermediary firm that governs co-marketing funding and terms of the firm's own ETFs and funds; intermediary channel (IC) campaigns only.", "Campaign", "Reference (Agreement)", "", "AGR-000218", "Internal", "", "", "Owned by 05 (wholesale until W4, when 05 is replaced). Co-marketed pieces carry Audience Restriction Financial Professional Use Only and this agreement; there is no Partner-Specific value (CW-904)."),
       ("Campaign Business Line", "Business line (CW-004) whose clients, prospects or products the campaign serves, used to report funnel and cost by line.", "Campaign", "Code", "Business Line", "DB", "Internal", "", "Y"),
     ]),
   ]),
   ("Objectives & Targeting", "What the campaign aims to achieve, for whom and with which products and offerings.", [
     ("Campaign Targeting", [
       ("Primary Objective", "Main business objective of the campaign.", "Campaign", "Code", "Campaign Objective", "Account Funding", "Internal", "", "", "Object PII tier: No PII."),
       ("Primary KPI", "Measure used to judge success against the objective.", "Campaign", "Code", "Marketing KPI", "Accounts Funded", "Internal", "", ""),
       ("Target Audience Types", "Audience types the campaign is aimed at.", "Campaign", "Code (multi)", "Audience Type", "Existing Client; Workplace Plan Participant", "Internal", "", "Y"),
       ("Target Business Lines", "Business lines whose clients or prospects the campaign targets when it spans more than its own line (for example a workplace-to-IRA rollover campaign).", "Campaign", "Code (multi)", "Business Line", "WR; DB", "Internal", "", ""),
       ("Target Segments", "Marketing audiences the campaign is deployed to.", "Campaign", "Reference (Marketing Segment) (multi)", "", "SEG-0042; SEG-0057", "Internal", "Adobe XDM", ""),
       ("Target Jurisdictions", "Countries in which the campaign may be deployed; content for clients with a foreign address is approved separately.", "Campaign", "Code (multi)", "ISO 3166-1 alpha-2", "US", "Internal", "FINRA Rule 2210", "Y"),
       ("Marketing Channel Mix", "Marketing channels used by the campaign.", "Campaign", "Code (multi)", "Marketing Channel", "Email; Mobile App; Paid Search", "Internal", "Adobe XDM", ""),
     ]),
     ("Campaign Product", [
       ("Campaign Product / Share Class", "Product, share class, strategy or service offering promoted by the campaign.", "Campaign", "Reference (Product / Share Class / Service Offering)", "", "OFFR-0012", "Internal", "", "Y", "Object PII tier: No PII. Owned by 01 Investment Product & Service Offering."),
       ("Product Role in Campaign", "Prominence of the product or offering in the campaign.", "Campaign", "Code", "Product Role", "Featured", "Internal", "", ""),
     ]),
   ]),
   ("Budget & Spend", "Planned and actual cost of campaigns, and the line items that make it up.", [
     ("Campaign Budget", [
       ("Budgeted Cost", "Amount budgeted for the campaign.", "Campaign", "Amount", "", "USD 85,000", "Salesforce", "", "", "Object PII tier: No PII."),
       ("Actual Cost", "Amount actually spent to run the campaign, including rolled-up child campaigns.", "Campaign", "Amount", "", "USD 61,250", "Salesforce", "", "Y"),
       ("Budget Currency", "Currency of budget and cost amounts.", "Campaign", "Code", "ISO 4217", "USD", "ISO 4217", "", ""),
     ]),
     ("Spend Line", [
       ("Spend Category", "Category of the spend line.", "Campaign", "Code", "Spend Category", "Media", "Internal", "", "", "Object PII tier: No PII."),
       ("Spend Amount", "Amount of the spend line.", "Campaign", "Amount", "", "USD 12,500", "Internal", "", ""),
     ]),
   ]),
   ("Tracking Codes", "Campaign tracking parameters appended to links so that traffic and responses can be attributed.", [
     ("Campaign Tracking Code", [
       ("Tracked URL", "Full destination URL including tracking parameters.", "Tracking Code", "Text", "URI", "https://www.example.com/ira?utm_source=google&utm_medium=cpc&utm_campaign=fy27q1_ira_season&utm_id=CAM-004512", "UTM", "GA4", "", "Object PII tier: No PII."),
       ("utm_id", "Campaign identifier carried in the URL; should equal the Campaign ID to enable cost and data import.", "Tracking Code", "Text", "", "CAM-004512", "GA4", "UTM", "Y"),
       ("utm_source", "Referrer that sent the traffic.", "Tracking Code", "Code", "UTM Source (firm-defined)", "google", "UTM", "GA4", ""),
       ("utm_medium", "Marketing medium of the traffic.", "Tracking Code", "Code", "UTM Medium", "cpc", "UTM", "GA4", ""),
       ("utm_campaign", "Campaign name or code as it appears in analytics.", "Tracking Code", "Text", "", "fy27q1_ira_season", "UTM", "GA4", ""),
       ("utm_content", "Differentiates ads, links or creative variants within a campaign.", "Tracking Code", "Text", "", "rsa_headline_v2", "UTM", "GA4", ""),
     ]),
   ]),
   ("Campaign Membership", "Clients, prospects and leads targeted by, or responding to, a campaign.", [
     ("Campaign Member", [
       ("Member Party", "Client or prospect party that is a member of the campaign.", "Campaign Member", "Reference (Party)", "", "PTY-104588", "Salesforce", "", "Y", "Object PII tier: PII - identity. PII (link to individual). Party mastered in 02."),
       ("Member Lead", "Lead record that is a member, where the person has not yet reached the identity threshold (CW-083).", "Campaign Member", "Reference (Lead)", "", "LEAD-0091234", "Salesforce", "", "", "PII (link to individual)."),
       ("Member Status", "Status of the member in the campaign.", "Campaign Member", "Code", "Campaign Member Status", "Responded", "Salesforce", "", "Y"),
       ("Responded Indicator", "Whether the member's status counts as a response.", "Campaign Member", "Boolean", "", "Y", "Salesforce", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Content & Digital Assets", "MK-AST",
  "Marketing and educational content and digital assets (articles, guides, videos, calculators, email and in-app templates, advertisements) and the metadata that governs who may see them, in which language, for how long and under which rights.",
  [
   ("Asset Identity", "Core descriptive metadata of a content asset, aligned to Dublin Core.", [
     ("Content Asset", [
       ("Asset ID", "Unique identifier of the content asset (all versions).", "Content Asset", "Identifier", "", "AST-018233", "Dublin Core", "Internal", "Y", "Object PII tier: No PII. dc:identifier"),
       ("Asset Title", "Title of the asset.", "Content Asset", "Text", "", "Roth or traditional IRA: how to choose", "Dublin Core", "IPTC", "", "dc:title"),
       ("Asset Description", "Short summary or abstract of the asset.", "Content Asset", "Text", "", "Compares tax treatment today and in retirement, with a worked example for a 35-year-old saver.", "Dublin Core", "", "", "dc:description"),
       ("Content Type", "Business type of the content.", "Content Asset", "Code", "Content Type", "Educational Article / Guide", "Internal", "Dublin Core", "", "dc:type maps to the coarser DCMI Type vocabulary."),
       ("Asset Owner", "Marketing employee accountable for the asset's accuracy and lifecycle.", "Content Asset", "Reference (Employee)", "", "EMP-00412", "Internal", "", ""),
       ("Asset Authors", "Named authors or presenters (employees or external contributors).", "Content Asset", "Reference (Employee / Party) (multi)", "", "EMP-00107; PTY-000457", "Dublin Core", "", "", "dc:creator. PII (named individuals)."),
       ("Publishing Entity", "Internal legal entity that issues the communication (the broker-dealer or the registered investment adviser named in the legal footer).", "Content Asset", "Reference (Internal Legal Entity)", "", "LEN-0001", "Dublin Core", "FINRA Rule 2210", "", "dc:publisher. FINRA Rule 2210(d)(3) requires the member firm's name in retail communications; an adviser advertisement names the adviser."),
       ("Parent / Source Asset", "Asset this asset was derived from (for example a social cut-down of a webinar recording).", "Content Asset", "Reference (Content Asset)", "", "AST-018100", "Dublin Core", "", "", "dc:source"),
       ("Source Commentary", "Investment commentary (owned by 01) that the asset publishes or is built from.", "Content Asset", "Reference (Investment Commentary) (multi)", "", "CMT-2026Q3-00412", "Internal", "", "", "The asset's audience restriction may not be wider than the commentary's Permitted Audience."),
     ]),
   ]),
   ("Audience & Distribution Restrictions", "Who may receive the asset and where; drives access rules, distribution lists and compliance routing.", [
     ("Audience Restriction", [
       ("Audience Restriction", "Highest-level statement of who may receive the asset.", "Content Asset", "Code", "Audience Restriction", "Public / Retail", "Internal", "FINRA Rule 2210", "Y", "Object PII tier: No PII."),
       ("FINRA Communication Category", "FINRA Rule 2210 category of the communication, as determined by compliance.", "Content Asset", "Code", "FINRA Communication Category", "Retail Communication", "FINRA Rule 2210", "", "", "Mirrored from 08 Retail Conduct & Supervision; marketing does not set it."),
       ("Permitted Investor Categories", "Communications audiences the asset may be shown to (retail, institutional, financial professional).", "Content Asset", "Code (multi)", "Investor Category", "Retail; Institutional", "Internal", "FINRA Rule 2210", ""),
       ("Permitted Jurisdictions", "Countries in which the asset may be distributed; clients with a foreign address see only assets approved for their country.", "Content Asset", "Code (multi)", "ISO 3166-1 alpha-2", "US", "Internal", "FINRA Rule 2210", "Y", "Must be consistent with the product's registration and availability (01, 35)."),
     ]),
   ]),
   ("Descriptive Classification", "Language, products, topics and tags used for search, personalization and reporting.", [
     ("Asset Classification", [
       ("Asset Language", "Language of the asset content.", "Content Asset", "Code", "ISO 639-1", "en", "Dublin Core", "", "", "Object PII tier: No PII. dc:language"),
       ("Featured Products / Share Classes", "Products, share classes, strategies or service offerings the asset discusses.", "Content Asset", "Reference (Product / Share Class) (multi)", "", "PRD-00981; SHC-004512", "Internal", "", "Y"),
       ("Content Topics", "Controlled topics the asset covers.", "Content Asset", "Code (multi)", "Content Topic", "Retirement; Tax", "Internal", "IAB", ""),
       ("Keywords / Tags", "Free keywords used for search.", "Content Asset", "Text (multi)", "", "Roth IRA; tax bracket; contribution limit", "IPTC", "Dublin Core", "", "dc:subject / IPTC Keywords"),
       ("Gated Indicator", "Whether access requires a client login or a form fill.", "Content Asset", "Boolean", "", "N", "Internal", "", ""),
     ]),
   ]),
   ("Version & Lifecycle", "Versioning, data as-of dates, expiry and withdrawal of assets.", [
     ("Asset Version", [
       ("Version Number", "Version of the asset.", "Content Asset", "Text", "", "2.1", "Internal", "XMP", "", "Object PII tier: No PII."),
       ("Asset Lifecycle Status", "Lifecycle status of the asset version.", "Content Asset", "Code", "Asset Lifecycle Status", "Published", "Internal", "", "Y"),
       ("Data As-Of Date", "Date of the performance, cost, 18 Portfolio Holdings or market data shown in the asset.", "Content Asset", "Date", "ISO 8601", "2026-06-30", "Internal", "SEC Marketing Rule", "Y"),
       ("Publication Date", "Date the version was first made available to its audience.", "Content Asset", "Date", "ISO 8601", "2026-07-21", "Dublin Core", "", "", "dct:issued"),
       ("Expiry Date", "Date after which the version must be withdrawn from all channels.", "Content Asset", "Date", "ISO 8601", "2026-10-20", "Internal", "", "Y"),
       ("Withdrawal Reason", "Reason the asset was withdrawn early.", "Content Asset", "Code", "Withdrawal Reason", "Data Superseded", "Internal", "", ""),
     ]),
   ]),
   ("Compliance Linkage", "Content characteristics that drive compliance review, and the link to the review owned by 08 Retail Conduct & Supervision.", [
     ("Asset Compliance Reference", [
       ("Compliance Review Reference", "Compliance review that approved this asset version.", "Content Asset", "Reference (Compliance Review)", "", "REV-2026-002311", "Internal", "FINRA Rule 2210", "Y", "Object PII tier: No PII. Owned by 08 Retail Conduct & Supervision."),
       ("Approval Status (Mirrored)", "Read-only copy of the review outcome, used to block distribution of unapproved assets.", "Content Asset", "Code", "External (08 Retail Conduct & Supervision: Review Status)", "Approved", "Internal", "", "Y", "Owned by 08; mirrored, never edited in marketing."),
       ("Performance Content Declared Indicator", "Whether the submitter declares, when routing the asset to 08, that it presents investment performance; 08's determination on the Compliance Review governs.", "Content Asset", "Boolean", "", "Y", "SEC Marketing Rule", "FINRA Rule 2210", "", "Submitter's declaration only; renamed from Performance Content Indicator (CW-904). The Marketing Rule classification is mastered by 08 (Compliance Review)."),
       ("Hypothetical Performance Declared Indicator", "Whether the submitter declares that the asset contains model, back-tested, targeted or projected performance; 08's determination governs.", "Content Asset", "Boolean", "", "N", "SEC Marketing Rule", "", "", "Submitter's declaration only; renamed from Hypothetical Performance Indicator (CW-904). Mastered by 08."),
       ("Testimonial / Endorsement / Rating Declared Indicator", "Whether the submitter declares that the asset contains testimonials, endorsements or third-party ratings; 08's determination governs.", "Content Asset", "Boolean", "", "Y", "SEC Marketing Rule", "FINRA Rule 2210", "", "Submitter's declaration only; renamed from Testimonial / Endorsement / Rating Indicator (CW-904). Mastered by 08."),
     ]),
   ]),
   ("Rights & Accessibility", "Ownership, licensing and accessibility metadata, aligned to IPTC, XMP and WCAG.", [
     ("Asset Rights", [
       ("Copyright Notice", "Copyright statement identifying the current rights owner.", "Content Asset", "Text", "", "(c) 2026 Example Investments LLC", "IPTC", "Dublin Core", "", "Object PII tier: No PII. dc:rights"),
       ("License Type", "Type of license under which the firm uses the asset.", "Content Asset", "Code", "License Type", "Rights-Managed", "IPTC", "", ""),
       ("Rights Usage Terms", "What may and may not be done with the asset.", "Content Asset", "Text", "", "Digital and print use in the US only; no paid social", "IPTC", "XMP", ""),
       ("License Expiry Date", "Date the usage license (image, music, third-party data) ends.", "Content Asset", "Date", "ISO 8601", "2027-06-30", "Internal", "IPTC", ""),
     ]),
     ("Asset Accessibility & Rendition", [
       ("Alt Text", "Short text alternative describing the purpose of an image for assistive technology.", "Content Asset", "Text", "", "Bar chart comparing Roth and traditional IRA balances after tax at age 65", "IPTC", "WCAG 2.2", "", "Object PII tier: No PII."),
       ("Captions / Transcript Available Indicator", "Whether captions (video) or a transcript (audio or video) are available.", "Content Asset", "Boolean", "", "Y", "WCAG 2.2", "", ""),
       ("Accessibility Conformance Level", "WCAG conformance level the asset has been checked against.", "Content Asset", "Code", "WCAG Conformance Level", "AA", "WCAG 2.2", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Client Events & Webinars", "MK-EVT",
  "Events the firm runs or attends for clients and prospects (seminars, webinars, workplace education sessions, client appreciation events), their sessions and speakers, and registrations and attendance.",
  [
   ("Event Definition", "Core identity, format, schedule and audience of an event.", [
     ("Marketing Event", [
       ("Event ID", "Unique identifier of the event.", "Event", "Identifier", "", "EVT-00871", "Internal", "schema.org", "Y", "Object PII tier: No PII."),
       ("Event Name", "Name of the event.", "Event", "Text", "", "Retirement Income Planning Webinar - October 2026", "schema.org", "", ""),
       ("Event Type", "Type of event.", "Event", "Code", "Event Type", "Webinar", "Internal", "schema.org", "Y"),
       ("Attendance Mode", "Whether the event is in person, online or hybrid.", "Event", "Code", "Attendance Mode", "Online", "schema.org", "", "", "schema.org eventAttendanceMode"),
       ("Event Status", "Scheduling status of the event.", "Event", "Code", "Event Status", "Scheduled", "schema.org", "", "", "schema.org eventStatus"),
       ("Event Start", "Start date and time of the event.", "Event", "Timestamp", "ISO 8601", "2026-10-28T19:00:00-04:00", "schema.org", "", ""),
       ("Event Country", "Country in which the event takes place (or primary audience country for online events).", "Event", "Code", "ISO 3166-1 alpha-2", "US", "Internal", "", ""),
       ("Organizer", "Organization running the event (the firm, a workplace plan sponsor or a third-party organizer).", "Event", "Reference (Party)", "", "PTY-000015", "schema.org", "", ""),
       ("Owning Campaign", "Campaign the event belongs to.", "Event", "Reference (Campaign)", "", "CAM-004530", "Internal", "", ""),
       ("Event Audience Restriction", "Who may attend.", "Event", "Code", "Audience Restriction", "Public / Retail", "Internal", "FINRA Rule 2210", "Y"),
     ]),
   ]),
   ("Agenda & Speakers", "Sessions within an event and the people presenting them.", [
     ("Event Session", [
       ("Session Title", "Title of the session.", "Event", "Text", "", "Turning savings into a paycheck", "schema.org", "", "", "Object PII tier: No PII."),
       ("Session Presentation Asset", "Approved presentation used in the session.", "Event", "Reference (Content Asset)", "", "AST-018402", "Internal", "", "", "Asset must carry its own REV- approval."),
     ]),
     ("Event Speaker", [
       ("Speaker", "Employee (an advisor, planner or investment professional) or external person presenting.", "Event", "Reference (Employee / Party)", "", "EMP-00107", "schema.org", "", "", "Object PII tier: PII - identity. PII (named individual)."),
     ]),
   ]),
   ("Registration & Attendance", "Invitations, registrations, check-ins and attendance of individuals at events.", [
     ("Event Registration", [
       ("Registrant Party", "Client or prospect party who registered or was invited.", "Registration", "Reference (Party)", "", "PTY-104588", "Internal", "", "Y", "Object PII tier: PII - identity. PII (link to individual)."),
       ("Registrant Email (Captured)", "Email address entered on the registration form, before matching to a party.", "Registration", "Text", "Email", "j.example@example.com", "Internal", "", "", "PII. Captured lineage only; 02 creates or updates the contact point at the identity threshold (CW-083)."),
       ("Registration Status", "Status of the registration.", "Registration", "Code", "Registration Status", "Attended", "Internal", "Salesforce", "Y"),
       ("Invited By Advisor", "Own advisor (03) who invited the registrant, for example to a seminar for the advisor's clients.", "Registration", "Reference (Advisor, 03)", "", "EMP-00233", "Internal", "", "", "Renamed from Invited By Salesperson (CW-904). The advisor is the 03 profile of a 20 employee."),
       ("Attended Indicator", "Whether the registrant attended (live or on demand).", "Registration", "Boolean", "", "Y", "Internal", "", ""),
       ("Accessibility / Dietary Requirements", "Accommodations the registrant asked for.", "Registration", "Text", "", "Wheelchair access", "Internal", "", "", "PII - may contain special category (CD-344): health information. Restricted view; minimize and delete after the event."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Digital Properties & Martech", "MK-WEB",
  "The firm's websites, client website, mobile apps, literature centers and landing pages, their pages and forms, and the inventory of marketing and digital technology that runs them.",
  [
   ("Digital Property", "Registry of owned digital properties.", [
     ("Digital Property", [
       ("Property ID", "Unique identifier of the digital property.", "Digital Property", "Identifier", "", "WEB-012", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Property Name", "Name of the property.", "Digital Property", "Text", "", "Example Investments Mobile App (iOS)", "Internal", "", ""),
       ("Property Type", "Type of digital property.", "Digital Property", "Code", "Property Type", "Mobile App", "Internal", "", ""),
       ("Primary Domain", "Primary domain or app store identifier.", "Digital Property", "Text", "URI", "https://www.example.com", "Internal", "", ""),
       ("Property Audience Types", "Audiences the property serves.", "Digital Property", "Code (multi)", "Audience Type", "Prospect; Existing Client", "Internal", "", ""),
       ("Jurisdictions Served", "Countries the property is designed for.", "Digital Property", "Code (multi)", "ISO 3166-1 alpha-2", "US", "Internal", "", ""),
       ("Property Status", "Lifecycle status of the property.", "Digital Property", "Code", "Property Status", "Live", "Internal", "", ""),
     ]),
   ]),
   ("Pages & Forms", "Pages and forms within a property, including product pages, application steps and lead capture forms.", [
     ("Web Page", [
       ("Page URL", "Canonical URL of the page.", "Web Page", "Text", "URI", "https://www.example.com/funds/total-bond-market-index", "GA4", "Adobe XDM", "Y", "Object PII tier: No PII. GA4 page_location; XDM web.webPageDetails.URL"),
       ("Page Type", "Template type of the page.", "Web Page", "Code", "Page Type", "Product Page", "Internal", "", ""),
       ("Page Product / Share Class", "Product, share class or service offering the page describes.", "Web Page", "Reference (Product / Share Class)", "", "PRD-00981", "Internal", "", ""),
       ("Page Audience Restriction", "Audience the page is restricted to.", "Web Page", "Code", "Audience Restriction", "Public / Retail", "Internal", "FINRA Rule 2210", "Y"),
       ("Audience Gate", "Control that admits a visitor to the page only after the evidence its audience restriction needs: a client login, or a financial professional or institutional investor self-certification or verified login, so that institutional communications and financial-professional-only content reach only those audiences.", "Web Page", "Code", "Audience Gate Type", "Financial Professional Self-Certification", "FINRA Rule 2210", "", "Y", "US replacement for the wholesale Access Gate (CW-904). The self-certification itself is an Engagement Event of type form_submit on the gate form."),
     ]),
     ("Web Form", [
       ("Form ID", "Identifier of the form.", "Web Page", "Identifier", "", "FRM-0057", "GA4", "", "", "Object PII tier: No PII (the form definition; submissions are leads and engagement events). GA4 form_id"),
       ("Form Purpose", "What the form captures.", "Web Page", "Code", "Form Purpose", "Appointment Request", "Internal", "", ""),
       ("Linked Campaign", "Campaign credited with form submissions.", "Web Page", "Reference (Campaign)", "", "CAM-004512", "Salesforce MCAE", "", ""),
       ("Privacy Notice Version", "Version of the notice at collection displayed on the form.", "Web Page", "Text", "", "PN-US-2026-02", "CCPA / CPRA", "", "", "Notice content is owned by Privacy (02); the Regulation S-P initial privacy notice of a client is delivered by 13 and evidenced in 02."),
     ]),
   ]),
   ("Marketing Systems", "Registry of marketing and digital technology systems and what they are system of record for.", [
     ("Marketing System", [
       ("System Name", "Name of the system.", "All", "Text", "", "Marketing Automation Platform", "Internal", "", "", "Object PII tier: No PII. Derived copy (41) of Application.Application Name since the Stage 4 consolidation (CD-264); System Category stays 04's martech classification."),
       ("Inventoried Application", "41 application that this martech profile describes.", "All", "Reference (Application, 41)", "", "APPL-00733", "Internal", "", "", "Added at the Stage 4 consolidation (CD-264 option A): the marketing system is a profile keyed by the 41 Application."),
       ("System Category", "Category of martech system.", "All", "Code", "Martech System Category", "Experimentation Platform", "Internal", "", ""),
       ("Personal Data Categories Processed", "Categories of personal information the system stores or processes, used for privacy inventories, CCPA / CPRA disclosures and access reviews.", "All", "Code (multi)", "Personal Data Category", "Contact; Online Identifiers / Engagement; Inferences / Segmentation", "CCPA / CPRA", "SEC Regulation S-P", "", "Replaces the wholesale record-level Personal Data Classification, removed with Record Metadata (CD-160, CW-904)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Digital Identity & Engagement", "MK-DIG",
  "Identification of web and app visitors, the client's Digital Profile (online login profile), visitor tracking choices, sessions and logins, and the behavioral events visitors and clients generate across web, app, email, video and webinars, plus engagement scores. Authentication of a person contacting a representative is 13; identity verification under CIP is 02; IAM controls are 41 (CW-086).",
  [
   ("Visitor Identity", "Identifiers and identity-resolution status of anonymous and known digital users.", [
     ("Web Visitor / Known User", [
       ("Visitor ID", "Firm-assigned persistent identifier for a browser, app instance or known user.", "Visitor", "Identifier", "", "VIS-7f3a9c21", "Adobe XDM", "GA4", "Y", "Object PII tier: PII - identity (pseudonymous). Anonymous visitor events kept 24 months (SME question 2)."),
       ("Identity Namespace", "Type of identifier held in the identity value.", "Visitor", "Code", "Identity Namespace", "GA Client ID", "Adobe XDM", "", ""),
       ("Identification Status", "Whether the visitor is anonymous, known or matched to a party.", "Visitor", "Code", "Identification Status", "Known - Matched", "Internal", "", ""),
       ("Matched Party", "Party the visitor has been resolved to, once the identity threshold is reached (CW-083).", "Visitor", "Reference (Party)", "", "PTY-104588", "Internal", "", "Y", "PII (link to individual)."),
       ("Match Method", "How the visitor was matched to the party.", "Visitor", "Code", "Identity Match Method", "Authenticated Login", "Internal", "", ""),
       ("Applied Tracking Consent", "Tracking categories permitted for the visitor when events were collected (the state applied at collection).", "Visitor", "Code (multi)", "Tracking Consent Category", "Strictly Necessary; Analytics", "CCPA / CPRA", "Internal", "Y", "From the latest Tracking Consent Choice; for a matched party the sale and sharing opt-out is read from 02 Privacy Profile (CW-084)."),
     ]),
     ("Digital Profile", [
       ("Digital Profile ID", "Unique identifier of the client's online login profile on the client website and app.", "Digital Profile", "Identifier", "", "DIGP-00104588", "Internal", "", "Y", "Object PII tier: PII - identity. Re-cut from the wholesale Portal Account (CW-086, CW-904); successor of the wholesale 02 Digital Profile. Never the login name; no password, one-time code or biometric template is held."),
       ("Digital Profile Party", "Party the digital profile belongs to.", "Digital Profile", "Reference (Party)", "", "PTY-104588", "Internal", "", "Y", "PII (link to individual). Renamed from Portal Account Party."),
       ("Digital Profile Status", "Status of the profile.", "Digital Profile", "Code", "Digital Profile Status", "Active", "Internal", "", "Y", "PII."),
       ("MFA Factors Enrolled", "Multi-factor authentication methods the client has enrolled.", "Digital Profile", "Code (multi)", "MFA Factor Type", "Authenticator App (TOTP); Security Key / Passkey (FIDO2)", "NIST SP 800-63B", "", "", "PII. Factor types only; the authenticator secrets are held in the 41 IAM platform."),
       ("Biometric Login Enabled Indicator", "Whether the client has enabled device biometric unlock for the mobile app.", "Digital Profile", "Boolean", "", "Y", "Internal", "NIST SP 800-63B", "", "PII. The biometric match happens on the device; the firm holds no biometric template (CW-086)."),
       ("Last Login Timestamp", "When the client last logged in successfully.", "Digital Profile", "Timestamp", "ISO 8601", "2026-10-13T07:42:10-04:00", "Internal", "", "", "PII (behavioral)."),
     ]),
     ("Tracking Consent Choice", [
       ("Choice Visitor", "Visitor who made or sent the tracking choice.", "Tracking Consent", "Reference (Visitor)", "", "VIS-7f3a9c21", "Internal", "", "Y", "Object PII tier: PII - identity (pseudonymous). Choices of unmatched visitors are mastered here; once matched, the sale and sharing opt-out is 02 Privacy Profile (CW-084)."),
       ("Choice Timestamp", "When the choice was made or the signal was received.", "Tracking Consent", "Timestamp", "ISO 8601", "2026-09-29T09:14:55Z", "Internal", "", "Y", "PII."),
       ("Choice Source", "How the choice was expressed.", "Tracking Consent", "Code", "Tracking Choice Source", "Global Privacy Control Signal", "CCPA / CPRA", "Global Privacy Control", "", "PII."),
       ("Permitted Tracking Categories", "Tracking categories the visitor allowed with this choice.", "Tracking Consent", "Code (multi)", "Tracking Consent Category", "Strictly Necessary; Functional", "CCPA / CPRA", "Internal", "", "PII."),
       ("Sale / Sharing Opt-Out Signal Indicator", "Whether the choice opts the visitor out of the sale or sharing of personal information for cross-context behavioral advertising, including an opt-out preference signal.", "Tracking Consent", "Boolean", "", "Y", "CCPA / CPRA", "Global Privacy Control", "Y", "PII. Honored as a valid opt-out request under the CCPA regulations on opt-out preference signals, 11 CCR § 7025 (confirm); once the visitor is matched it is written to 02 Privacy Profile."),
     ]),
   ]),
   ("Sessions & Logins", "The sessions in which web and app activity occurs, including authenticated sessions.", [
     ("Session", [
       ("Session ID", "Identifier of a visit.", "Session", "Identifier", "", "1727600001", "GA4", "", "", "Object PII tier: PII - identity (behavioral). GA4 ga_session_id."),
       ("Session Visitor", "Visitor (browser, app instance or known user) whose session it is; resolves to the party through the visitor's Matched Party.", "Session", "Reference (Visitor)", "", "VIS-7f3a9c21", "GA4", "Adobe XDM", "", "PII (pseudonymous)."),
       ("Session Source / Medium", "Traffic source and medium of the session (from UTM or referrer).", "Session", "Text", "", "google / cpc", "GA4", "UTM", "", "PII (behavioral)."),
       ("Session Campaign", "Campaign attributed to the session.", "Session", "Reference (Campaign)", "", "CAM-004512", "GA4", "UTM", "", "PII (behavioral)."),
       ("Session Login Method", "How the person authenticated in the session, or that the session was not authenticated.", "Session", "Code", "Login Method", "Passkey", "Internal", "NIST SP 800-63B", "", "PII (behavioral). The authentication event and its controls are 41's; assisted-service authentication is 13 (CW-086)."),
     ]),
   ]),
   ("Web & App Interaction", "Individual behavioral events on owned websites and apps.", [
     ("Engagement Event", [
       ("Event Timestamp", "When the event occurred.", "Engagement Event", "Timestamp", "ISO 8601", "2026-09-29T09:16:41Z", "Adobe XDM", "GA4", "Y", "Object PII tier: PII - identity (behavioral)."),
       ("Engagement Event Type", "Type of interaction.", "Engagement Event", "Code", "Engagement Event Type", "feature_use", "GA4", "Adobe XDM", "Y"),
       ("Event Visitor / Party", "Visitor or party who performed the event.", "Engagement Event", "Reference (Visitor / Party)", "", "VIS-7f3a9c21", "Adobe XDM", "", "Y", "PII (behavioral)."),
       ("Event Content Asset", "Content asset interacted with.", "Engagement Event", "Reference (Content Asset)", "", "AST-018233", "Internal", "", ""),
       ("Event Session", "Session in which the event occurred.", "Engagement Event", "Reference (Session, 04)", "", "1727600001", "GA4", "", "", "PII (behavioral)."),
       ("Digital Feature Used", "App or website feature the event was performed in, for feature_use, login and journey events.", "Engagement Event", "Code", "Digital Feature", "Recurring Investment Setup", "Internal", "Adobe XDM", ""),
       ("Event Application Journey", "Application journey the event is a step of, for journey_step events.", "Engagement Event", "Reference (Application Journey, 04)", "", "JRNY-2026-0418822", "Internal", "", ""),
       ("Exposed Experiment", "Experiment whose variant the visitor or client saw when the event occurred.", "Engagement Event", "Reference (Experiment, 04)", "", "EXPMT-2026-0031", "Internal", "", "", "The variant is on the Experiment Assignment."),
     ]),
   ]),
   ("Email Engagement", "Marketing email sends and recipient-level delivery and engagement.", [
     ("Email Send", [
       ("Email Template Asset", "Approved email template or creative used.", "Email", "Reference (Content Asset)", "", "AST-018560", "Internal", "", "", "Object PII tier: No PII."),
       ("Email Campaign", "Campaign the send belongs to.", "Email", "Reference (Campaign)", "", "CAM-004512", "Adobe XDM", "Salesforce MCAE", ""),
       ("Subject Line", "Subject line as sent.", "Email", "Text", "", "Your IRA contribution window is open", "Internal", "CAN-SPAM", "", "Must not be misleading (CAN-SPAM)."),
       ("Email Send Type", "Commercial or transactional nature of the email.", "Email", "Code", "Email Send Type", "Commercial", "CAN-SPAM", "", "Y", "Transactional or relationship messages have different opt-out rules; required documents are 13."),
       ("Email Subscription Topic", "Subscription topic the send is governed by.", "Email", "Reference (Subscription Topic)", "", "SUB-004", "Internal", "", ""),
     ]),
     ("Email Interaction", [
       ("Recipient Party", "Party who received the email.", "Email", "Reference (Party)", "", "PTY-104588", "Adobe XDM", "", "Y", "Object PII tier: PII - identity. PII (link to individual)."),
       ("Recipient Email Address", "Email address the message was sent to.", "Email", "Text", "Email", "j.example@example.com", "Adobe XDM", "", "", "PII. Derived copy of the 02 Contact Point at send time."),
       ("Delivery Status", "Delivery outcome for the recipient.", "Email", "Code", "Email Delivery Status", "Delivered", "Adobe XDM", "", "Y"),
       ("First Open Timestamp", "First recorded open.", "Email", "Timestamp", "ISO 8601", "2026-10-14T13:42:10Z", "Adobe XDM", "", "", "Opens are inflated by mail privacy proxies; prefer clicks for scoring."),
       ("First Click Timestamp", "First recorded click.", "Email", "Timestamp", "ISO 8601", "2026-10-14T13:43:02Z", "Adobe XDM", "", ""),
       ("Unsubscribe Timestamp", "When the recipient unsubscribed through this email.", "Email", "Timestamp", "ISO 8601", "", "Adobe XDM", "CAN-SPAM", "Y", "Written to 02 Communication Preference and to Suppression Entry (CW-084)."),
       ("Unsubscribe Written Back Timestamp", "When the unsubscribe was recorded in the 02 Communication Preference, evidencing that the opt-out was honored within 10 business days.", "Email", "Timestamp", "ISO 8601", "", "CAN-SPAM", "Internal", "Y", "PII."),
     ]),
   ]),
   ("Video & Webinar Engagement", "Consumption of video, audio and webinar content.", [
     ("Media Engagement", [
       ("Viewing Mode", "Whether content was consumed live or on demand.", "Engagement Event", "Code", "Viewing Mode", "On-Demand", "Internal", "", "", "Object PII tier: PII - identity (behavioral)."),
       ("Percent Viewed", "Furthest progress through the media.", "Engagement Event", "Percentage", "", "75%", "GA4", "", "", "GA4 video_percent (10 / 25 / 50 / 75 milestones)."),
       ("Completion Indicator", "Whether the media was watched to the end.", "Engagement Event", "Boolean", "", "N", "GA4", "", ""),
     ]),
   ]),
   ("Engagement Scoring", "Scores that summarize how engaged a client or prospect is, used to prioritize outreach and personalization.", [
     ("Engagement Score", [
       ("Engagement Score Model", "Scoring model and version that produced the score.", "Score", "Code", "Firm-defined", "Client Engagement Propensity v1", "Internal", "", "", "Object PII tier: PII - identity (inference)."),
       ("Engagement Score Party", "Client or prospect party being scored.", "Score", "Reference (Party)", "", "PTY-104588", "Internal", "", "", "PII (inference). State privacy laws treat profiles as personal information; opt-out of profiling where a state law grants it (confirm)."),
       ("Engagement Score Value", "Calculated score.", "Score", "Integer", "", "84", "Internal", "Salesforce MCAE", "", "PII (inference). 02 Digital Engagement Segment, where kept, is a Derived copy of this score (CW-094)."),
       ("Score As-Of Date", "Date the score was calculated.", "Score", "Date", "ISO 8601", "2026-10-12", "Internal", "", "", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Audiences, Subscriptions & Suppression", "MK-AUD",
  "Marketing audiences built for activation and their membership, the subscription topic catalog and suppression lists. The party's opt-in per topic and channel, consents, do-not-contact and privacy opt-outs are mastered in 02 Client & Household (CW-084); enterprise segment assignment is 02 (CW-094).",
  [
   ("Segments", "Audiences built for activation and the parties in them at activation time.", [
     ("Marketing Segment", [
       ("Segment ID", "Unique identifier of the audience.", "Segment", "Identifier", "", "SEG-0042", "Internal", "Adobe XDM", "Y", "Object PII tier: No PII (the definition; membership is PII)."),
       ("Segment Name", "Name of the audience.", "Segment", "Text", "", "Pre-retirees with no IRA contribution this tax year", "Internal", "", ""),
       ("Segment Type", "How membership is determined.", "Segment", "Code", "Segment Type", "Rule-Based (Dynamic)", "Internal", "Adobe XDM", ""),
       ("Segment Rule Definition", "Business-readable rule that selects members; it may use a 02 segment assignment as a criterion but never re-assigns it.", "Segment", "Text", "", "Relationship Stage = Client AND 02 Life Stage = Pre-Retiree AND no IRA contribution for tax year 2026", "Internal", "", ""),
       ("Segment Audience Restriction", "Highest audience restriction compatible with the segment's members.", "Segment", "Code", "Audience Restriction", "Public / Retail", "Internal", "", ""),
     ]),
     ("Segment Membership", [
       ("Member Party", "Party included in the segment.", "Segment", "Reference (Party)", "", "PTY-104588", "Internal", "", "Y", "Object PII tier: PII - identity. PII (link to individual)."),
       ("Membership Effective From", "Date the party entered the segment.", "Segment", "Date", "ISO 8601", "2026-09-12", "Internal", "", "Y"),
       ("Membership Effective To", "Date the party left the segment.", "Segment", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Subscriptions", "Subscription topics offered in the preference center. Each party's per-topic, per-channel opt-in is mastered in 02 Communication Preference, which references the topic.", [
     ("Subscription Topic", [
       ("Subscription Topic ID", "Unique identifier of the topic.", "Subscription", "Identifier", "", "SUB-004", "Internal", "Salesforce MCAE", "Y", "Object PII tier: No PII."),
       ("Subscription Topic Name", "Name shown in the preference center.", "Subscription", "Text", "", "Retirement Insights", "Internal", "", ""),
       ("Subscription Category", "Category of the topic.", "Subscription", "Code", "Subscription Category", "Retirement Planning", "Internal", "", ""),
       ("Topic Audience Restriction", "Audience the topic is offered to.", "Subscription", "Code", "Audience Restriction", "Public / Retail", "Internal", "", ""),
     ]),
   ]),
   ("Suppression", "Operational lists of identifiers that must be excluded from outreach regardless of audience or preference.", [
     ("Suppression Entry", [
       ("Suppressed Identifier", "Email address, hashed email or phone number suppressed.", "Suppression", "Text", "", "sha256:4f1c...e9", "Internal", "", "Y", "Object PII tier: PII - identity (hashed where possible)."),
       ("Suppression Reason", "Why the identifier is suppressed.", "Suppression", "Code", "Suppression Reason", "National Do Not Call Registry", "Internal", "CAN-SPAM", "Y", "TCPA and FINRA Rule 3230 reasons apply to calls and texts; a party's do-not-contact flag is 02 Privacy Profile."),
       ("Suppression Scope", "Breadth of the suppression.", "Suppression", "Code", "Suppression Scope", "Channel", "Internal", "", ""),
       ("Suppression Effective From", "Date the suppression started.", "Suppression", "Date", "ISO 8601", "2026-08-11", "Internal", "", ""),
       ("Registry Scrub Date", "Date the telephone number was last checked against the National Do Not Call Registry.", "Suppression", "Date", "ISO 8601", "2026-09-30", "FTC Telemarketing Sales Rule", "FINRA Rule 3230", "", "PII. Registry data must be refreshed at least every 31 days for telemarketing (confirm)."),
       ("Revoked Consent Record", "02 consent record updated when the suppression records a TCPA consent revocation captured by 04 (for example a STOP reply).", "Suppression", "Reference (Consent Record)", "", "CNS-00918231", "TCPA", "", "Y", "PII. 04 captures the revocation; 02 masters the consent and its withdrawal (CW-084); write-back within the FCC's 10-business-day window (confirm)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Leads & Acquisition Funnel", "MK-LED",
  "Marketing leads from capture through qualification, routing to an advisor or advice team and conversion to a 02 prospect party; the digital application journey up to submission; and the acquisition milestones from prospect to funded account (CW-083, CW-085).",
  [
   ("Lead Capture", "Identity, source and captured details of a lead before and after party matching.", [
     ("Marketing Lead", [
       ("Lead ID", "Unique identifier of the lead.", "Lead", "Identifier", "", "LEAD-0091234", "Salesforce", "", "Y", "Object PII tier: PII - identity. Captured values are kept as lineage until the identity threshold and deleted per the retention rule (SME question 1)."),
       ("Lead Type", "Type of prospect the lead represents.", "Lead", "Code", "Lead Type", "Advice Prospect", "Internal", "", ""),
       ("Lead Party", "Party the lead is matched to (blank until the identity threshold is reached).", "Lead", "Reference (Party)", "", "PTY-104588", "Internal", "", "Y", "PII (link to individual)."),
       ("Captured Name", "First and last name as captured.", "Lead", "Text", "", "Jordan Example", "Salesforce", "", "", "PII. Never maintained as party data (CW-083)."),
       ("Captured Email", "Email address as captured.", "Lead", "Text", "Email", "j.example@example.com", "Salesforce", "", "", "PII."),
       ("Lead Source", "Origin of the lead.", "Lead", "Code", "Lead Source", "Calculator / Tool", "Salesforce", "", ""),
       ("Original Campaign", "First campaign that generated the lead.", "Lead", "Reference (Campaign)", "", "CAM-004530", "Salesforce MCAE", "", ""),
     ]),
   ]),
   ("Qualification & Scoring", "Lead status, lifecycle stage, behavioral score and fit grade.", [
     ("Lead Qualification", [
       ("Lead Status", "Current qualification status of the lead.", "Lead", "Code", "Lead Status", "MQL", "Salesforce", "", "Y", "Object PII tier: PII - identity."),
       ("Lead Status Effective Timestamp", "When the current status took effect.", "Lead", "Timestamp", "ISO 8601", "2026-10-01T08:00:00Z", "Internal", "", ""),
       ("Lifecycle Stage", "Funnel lifecycle stage of the lead; the party's relationship stage is mastered in 02.", "Lead", "Code", "Lifecycle Stage", "Marketing Qualified Lead", "Salesforce MCAE", "", "", "Values after Marketing Qualified Lead are copies of 02 Relationship Stage once the lead is matched."),
       ("Behavior Score", "Points reflecting engagement behavior.", "Lead", "Integer", "", "135", "Salesforce MCAE", "", "", "PII (inference)."),
       ("Fit Grade", "Grade reflecting fit to the target client profile.", "Lead", "Code", "Fit Grade", "A-", "Salesforce MCAE", "", "", "PII (inference)."),
       ("Disqualification Reason", "Why the lead was disqualified.", "Lead", "Code", "Disqualification Reason", "Existing Client", "Internal", "", ""),
     ]),
   ]),
   ("Routing & Conversion", "Assignment of leads to an advisor or advice team and the outcome of follow-up.", [
     ("Lead Assignment", [
       ("Assigned Advisor", "Own advisor or coverage team (03) the lead is routed to, for human and hybrid advice and trust prospects.", "Lead", "Reference (Advisor / Coverage Team, 03)", "", "EMP-00233", "Salesforce", "", "Y", "Object PII tier: PII - identity. Renamed from Assigned Salesperson (CW-904). Coverage rules are 03's and are applied, not redefined."),
       ("Follow-Up SLA Due", "When the advisor or team must first act on the lead.", "Lead", "Timestamp", "ISO 8601", "2026-10-03T17:00:00-04:00", "Internal", "", ""),
       ("First Sales Activity", "First advisor activity logged against the lead.", "Lead", "Reference (Activity)", "", "ACT-20261002-7781", "Internal", "", "", "Owned by 03 (Advisor Activity, ACT-). Name kept for readers."),
     ]),
     ("Lead Conversion", [
       ("Conversion Outcome", "Outcome of follow-up.", "Lead", "Code", "Conversion Outcome", "Converted to Prospect Party", "Salesforce", "", "", "Object PII tier: PII - identity."),
       ("Converted Party", "02 party created or matched when the lead reached the identity threshold.", "Lead", "Reference (Party)", "", "PTY-104588", "Internal", "", "Y", "PII (link to individual). Replaces Converted Opportunity (CW-083)."),
       ("Resulting Application Journey", "Application journey the lead started, where conversion was an application start.", "Lead", "Reference (Application Journey, 04)", "", "JRNY-2026-0418822", "Internal", "", ""),
       ("Conversion Timestamp", "When the lead was converted.", "Lead", "Timestamp", "ISO 8601", "2026-10-02T20:05:00-04:00", "Salesforce", "", ""),
     ]),
   ]),
   ("Application Journey", "The digital journey of an applicant from start to submission; from submission the application is 15 Account Opening (CW-085).", [
     ("Application Journey", [
       ("Journey ID", "Unique identifier of the application journey.", "Journey", "Identifier", "", "JRNY-2026-0418822", "Internal", "", "Y", "Object PII tier: PII - identity. No application data after submission and no questionnaire answers (02 Investor Profile) are held here."),
       ("Journey Applicant Party", "Party making the application; an application start makes the party an Applicant (CW-083).", "Journey", "Reference (Party)", "", "PTY-104588", "Internal", "", "Y", "PII (link to individual)."),
       ("Journey Type", "Kind of application the journey leads to.", "Journey", "Code", "Journey Type", "IRA Rollover", "Internal", "", "Y", "PII."),
       ("Journey Start Timestamp", "When the applicant started the journey.", "Journey", "Timestamp", "ISO 8601", "2026-10-02T20:11:45-04:00", "Internal", "", ""),
       ("Last Completed Step", "Last step the applicant completed.", "Journey", "Code", "Journey Step", "Funding Method", "Internal", "", "", "PII."),
       ("Journey Status", "Current status of the journey.", "Journey", "Code", "Journey Status", "Submitted", "Internal", "", "Y", "PII."),
       ("Abandonment Reason", "Why the journey was abandoned, where known.", "Journey", "Code", "Abandonment Reason", "Funding Not Linked", "Internal", "", "", "PII."),
       ("Submission Timestamp", "When the applicant submitted the application; 15 Account Opening is the master from this point.", "Journey", "Timestamp", "ISO 8601", "2026-10-02T20:31:02-04:00", "Internal", "", "Y"),
       ("Resulting Onboarding Case", "02 onboarding case opened from the submitted application.", "Journey", "Reference (Onboarding Case)", "", "ONB-2026-0412", "Internal", "", ""),
       ("Resulting Account", "15 account opened from the application.", "Journey", "Reference (Account)", "", "ACC-0049812", "Internal", "", "Y"),
     ]),
   ]),
   ("Acquisition Milestones", "Dated steps from prospect to funded client that campaigns are credited with.", [
     ("Acquisition Milestone", [
       ("Milestone Party", "Party that reached the milestone.", "Milestone", "Reference (Party)", "", "PTY-104588", "Internal", "", "Y", "Object PII tier: PII - financial."),
       ("Milestone Type", "Funnel step from prospect to funded client that the party reached (CW-085 milestone types).", "Milestone", "Code", "Acquisition Milestone Type", "Account Funded", "Internal", "", "Y", "PII."),
       ("Milestone Date", "Date the milestone was reached.", "Milestone", "Date", "ISO 8601", "2026-10-09", "Internal", "", "Y", "PII. Row rule in ROW_OWNERSHIP: 04 reads the date from the domain that records the fact (02, 15, 50); only the application milestones are 04 journey events (CW-085)."),
       ("Milestone Account", "Account the milestone concerns, for account milestones.", "Milestone", "Reference (Account)", "", "ACC-0049812", "Internal", "", "", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Personalization & Experiments", "MK-PEX",
  "Nudges (prompts, reminders and suggestions shown in the app, by push, text or email) and their deliveries, and experiments (A/B and multivariate tests) and the assignment of visitors and clients to variants. A nudge that may be a recommendation is routed to 08 and 45 (CW-091); experiment results are computed in data products, not stored.",
  [
   ("Nudges", "Definitions of nudges and each delivery to a client.", [
     ("Nudge Definition", [
       ("Nudge ID", "Unique identifier of the nudge.", "Nudge", "Identifier", "", "NUDG-0117", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Nudge Version", "Version of the nudge's trigger and content.", "Nudge", "Text", "", "3", "Internal", "", ""),
       ("Nudge Type", "Purpose of the nudge (reminder, education, feature discovery, savings prompt, product suggestion or milestone message), which drives its review route.", "Nudge", "Code", "Nudge Type", "Task Reminder", "Internal", "SEC Release 34-92766", ""),
       ("Trigger Rule", "Business-readable rule that decides when the nudge is shown.", "Nudge", "Text", "", "IRA opened more than 7 days ago AND no funding received AND not suppressed", "Internal", "", ""),
       ("Nudge Content Asset", "Approved content (in-app card, push, text or email template) the nudge shows.", "Nudge", "Reference (Content Asset)", "", "AST-018777", "Internal", "", ""),
       ("Recommendation Risk Class", "08's determination, under the Nudge Compliance Review, of whether delivering the nudge is a recommendation of a security, account type or strategy, or a communication within an advice program.", "Nudge", "Code", "Recommendation Risk Class", "Determined Not a Recommendation", "SEC Reg BI", "SEC Release 34-92766", "Y", "Copy of the 08 determination (Derived). A nudge Pending Determination is not delivered; every delivery of a nudge Determined Recommendation carries a Linked Recommendation (CW-091)."),
       ("Nudge Compliance Review", "Compliance review of the nudge's content asset and trigger under which 08 made the recommendation determination.", "Nudge", "Reference (Compliance Review)", "", "REV-2026-002412", "Internal", "FINRA Rule 2210", "Y", "Owned by 08."),
     ]),
     ("Nudge Delivery", [
       ("Delivered Nudge", "Nudge that was delivered.", "Nudge", "Reference (Nudge Definition, 04)", "", "NUDG-0117", "Internal", "", "Y", "Object PII tier: PII - identity."),
       ("Delivery Party", "Client the nudge was delivered to.", "Nudge", "Reference (Party)", "", "PTY-104588", "Internal", "", "Y", "PII (link to individual)."),
       ("Delivered Timestamp", "When the nudge was delivered.", "Nudge", "Timestamp", "ISO 8601", "2026-10-09T12:00:03Z", "Internal", "", "Y", "PII."),
       ("Delivery Channel", "Marketing channel the nudge was delivered through (mobile app card, push notification, SMS, email or website).", "Nudge", "Code", "Marketing Channel", "Push Notification", "Internal", "TCPA", "", "PII. Text messages need the 02 TCPA consent; push and in-app need no consent record but honor 02 preferences."),
       ("Suppression Check Result", "Outcome of the opt-out, frequency and do-not-contact checks applied before delivery.", "Nudge", "Code", "Suppression Check Result", "Passed", "Internal", "", "Y", "PII."),
       ("Nudge Response", "What the client did with the nudge.", "Nudge", "Code", "Nudge Response", "Completed Action", "Internal", "", "", "PII (behavioral)."),
       ("Linked Recommendation", "45 recommendation the delivery carried; mandatory when the nudge's Recommendation Risk Class is Determined Recommendation.", "Nudge", "Reference (Recommendation, 45)", "", "RECOM-2025-0018342", "Internal", "SEC Reg BI", "", "PII. DQ rule: every Nudge Delivery of a Determined Recommendation nudge has a Linked Recommendation. Owned by 45 Financial Planning & Advice."),
     ]),
   ]),
   ("Experiments", "Tests of alternative versions of a page, journey step, message or nudge, and who saw which version.", [
     ("Experiment", [
       ("Experiment ID", "Unique identifier of the experiment.", "Experiment", "Identifier", "", "EXPMT-2026-0031", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Experiment Name", "Name of the experiment and what it tests.", "Experiment", "Text", "", "IRA funding step: one page vs two steps", "Internal", "", ""),
       ("Experiment Status", "Where the experiment is in its lifecycle, from draft through running to completed or stopped early.", "Experiment", "Code", "Experiment Status", "Running", "Internal", "", ""),
       ("Experiment Variants", "Variants under test, with the control first.", "Experiment", "Text", "", "A: two-step funding (control); B: one-page funding", "Internal", "", "", "Variants that change a client communication carry their own 08 review on the content asset."),
       ("Primary Metric", "21 metric whose difference between variants decides the experiment.", "Experiment", "Reference (Metric Definition)", "", "KPI-0412", "Internal", "", "Y", "Owned by 21 Data Governance & Analytics."),
       ("Experiment Decision", "Decision taken at the end of the experiment.", "Experiment", "Code", "Experiment Decision", "Ship Variant", "Internal", "", ""),
     ]),
     ("Experiment Assignment", [
       ("Assigned Experiment", "Experiment the visitor or client was assigned in.", "Experiment", "Reference (Experiment, 04)", "", "EXPMT-2026-0031", "Internal", "", "Y", "Object PII tier: PII - identity (pseudonymous)."),
       ("Assigned Visitor / Party", "Visitor or party assigned.", "Experiment", "Reference (Visitor / Party)", "", "VIS-7f3a9c21", "Internal", "", "Y", "PII (pseudonymous)."),
       ("Assigned Variant", "Variant the visitor or client was assigned to.", "Experiment", "Text", "", "B", "Internal", "", "Y", "PII."),
       ("First Exposure Timestamp", "When the visitor or client first saw the assigned variant.", "Experiment", "Timestamp", "ISO 8601", "2026-09-16T18:22:41Z", "Internal", "", "", "PII (behavioral)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Referrals, Promotions & Voice of Client", "MK-PRO",
  "Promotion offers (funding bonuses, transfer-fee reimbursements, fee credits) and client enrollments in them; client-to-friend referrals; and client surveys and their responses (NPS, CSAT). Awards are paid by 50 and waived by 47; reportable awards are 13 tax forms; terms and endorsements are reviewed by 08; complaints are 08 (CW-092, CW-093).",
  [
   ("Promotions", "Offers that reward a client for an action, and the clients enrolled in them.", [
     ("Promotion Offer", [
       ("Promotion ID", "Unique identifier of the promotion offer.", "Promotion", "Identifier", "", "PROMO-2026-007", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Promotion Name", "Name of the offer as shown to clients.", "Promotion", "Text", "", "IRA transfer bonus 2026", "Internal", "", ""),
       ("Promotion Award Type", "Form of the reward (cash bonus, fee waiver or credit, trade commission waiver, gift or referral reward), which decides whether 50 or 47 delivers it.", "Promotion", "Code", "Promotion Award Type", "Cash Bonus", "Internal", "", "Y"),
       ("Eligibility Criteria", "Who qualifies and what they must do, as stated in the terms.", "Promotion", "Text", "", "New IRA funded with at least USD 10,000 transferred in during the offer period and held 180 days", "Internal", "", ""),
       ("Offer Start Date", "First date an enrollment or qualifying action counts.", "Promotion", "Date", "ISO 8601", "2026-10-01", "Internal", "", ""),
       ("Offer End Date", "Last date an enrollment or qualifying action counts.", "Promotion", "Date", "ISO 8601", "2026-12-31", "Internal", "", ""),
       ("Award Value", "Award per qualifying enrollment, or the top of the tier schedule stated in the terms; used for the 1099-MISC threshold test.", "Promotion", "Amount", "", "USD 1,000", "Internal", "IRS Form 1099-MISC", ""),
       ("Promotion Campaign", "Campaign that markets the offer.", "Promotion", "Reference (Campaign)", "", "CAM-004512", "Internal", "", ""),
       ("Promotion Compliance Review", "Compliance review of the content asset carrying the offer terms and advertising.", "Promotion", "Reference (Compliance Review)", "", "REV-2026-002498", "Internal", "FINRA Rule 2210", "Y", "Owned by 08."),
       ("Promotion Status", "Where the offer is in its lifecycle, from draft and review to active, closed or withdrawn.", "Promotion", "Code", "Promotion Status", "Active", "Internal", "", ""),
     ]),
     ("Promotion Enrollment", [
       ("Enrolled Promotion", "Promotion offer the client enrolled in.", "Promotion", "Reference (Promotion Offer, 04)", "", "PROMO-2026-007", "Internal", "", "Y", "Object PII tier: PII - financial."),
       ("Enrolled Party", "Client enrolled in the offer.", "Promotion", "Reference (Party)", "", "PTY-104588", "Internal", "", "Y", "PII (link to individual)."),
       ("Enrolled Account", "Account the qualifying action and award apply to, where the offer is account-level.", "Promotion", "Reference (Account)", "", "ACC-0049812", "Internal", "", "", "PII."),
       ("Enrollment Status", "Qualification and award status of the enrollment.", "Promotion", "Code", "Promotion Enrollment Status", "Award Paid", "Internal", "", "Y", "PII."),
       ("Award Fee Waiver", "47 fee waiver or credit that delivered a fee award.", "Promotion", "Reference (Fee Waiver, 47)", "", "FWV-2026-000917", "Internal", "", "", "PII. Owned by 47 Pricing, Fees & Billing."),
       ("Form 1099-MISC Reportable Indicator", "Whether the award is reportable to the client as other income on Form 1099-MISC.", "Promotion", "Boolean", "", "Y", "IRS Form 1099-MISC", "", "", "PII. The form is a 13 Tax Form Record; the reporting threshold changed for payments after 2025 (confirm)."),
     ]),
   ]),
   ("Client Referrals", "Clients referring friends and family to the firm.", [
     ("Client Referral", [
       ("Referral ID", "Unique identifier of the referral.", "Referral", "Identifier", "", "CRFL-00041877", "Internal", "", "Y", "Object PII tier: PII - identity. Not the 03 Channel Referral (RFRL-), which hands a client between the firm's channels (CW-092)."),
       ("Referrer Party", "Client who made the referral.", "Referral", "Reference (Party)", "", "PTY-104588", "Internal", "", "Y", "PII (link to individual)."),
       ("Referee Party", "Person referred, once a 02 party exists; before that the referee is a 04 lead.", "Referral", "Reference (Party / Lead)", "", "PTY-104902", "Internal", "", "", "PII (link to individual)."),
       ("Referral Code", "Code the referrer shares and the referee enters.", "Referral", "Text", "", "JEX-4K7Q", "Internal", "", "", "PII (linkable to the referrer)."),
       ("Referral Status", "Progress of the referral.", "Referral", "Code", "Referral Program Status", "Referee Funded", "Internal", "", "Y", "PII."),
       ("Endorsement Disclosure Delivered Indicator", "Whether the disclosures required for a compensated testimonial (the referrer is a client) or endorsement were provided with the referral.", "Referral", "Boolean", "", "Y", "SEC Marketing Rule", "FINRA Rule 2210", "Y", "PII. Advisers Act Rule 206(4)-1(b)(1) disclosures, with (b)(2) oversight and (b)(3) disqualification (confirm paragraphs); FINRA Rule 2210(d)(6) for the broker-dealer."),
       ("Referral Reward Enrollment", "Promotion enrollment of the referrer (offer of award type Referral Reward) through which the reward is earned and paid by 50 or 47.", "Referral", "Reference (Promotion Enrollment, 04)", "", "PROMO-2026-011 / PTY-104588", "Internal", "SEC Marketing Rule", "", "PII. Held once, on the 04 side (CW-092); a cash reward makes the testimonial compensated."),
     ]),
   ]),
   ("Voice of Client", "Client surveys and the responses to them.", [
     ("Client Survey", [
       ("Survey ID", "Unique identifier of the survey.", "Survey", "Identifier", "", "CSVY-0012", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Survey Name", "Name of the survey as shown to respondents and in reports.", "Survey", "Text", "", "Relationship NPS - Annual 2026", "Internal", "", ""),
       ("Survey Type", "Measure the survey collects (relationship or transactional NPS, CSAT, customer effort or experience feedback).", "Survey", "Code", "Survey Type", "Transactional NPS", "Net Promoter System", "", ""),
       ("Survey Trigger", "Event that sends the survey.", "Survey", "Code", "Survey Trigger", "Contact Center Interaction Closed", "Internal", "", ""),
     ]),
     ("Survey Response", [
       ("Response ID", "Unique identifier of the response.", "Survey", "Identifier", "", "SRSP-2026-00918231", "Internal", "", "Y", "Object PII tier: PII - identity; verbatims may contain special category (CD-344). Held in house, keyed to 02 (SME question 5)."),
       ("Response Survey", "Survey version the response answers.", "Survey", "Reference (Client Survey, 04)", "", "CSVY-0012", "Internal", "", "Y"),
       ("Respondent Party", "Client who responded, or the contact person speaking for an institutional client.", "Survey", "Reference (Party)", "", "PTY-104588", "Internal", "", "Y", "PII (link to individual)."),
       ("Response Timestamp", "When the response was submitted.", "Survey", "Timestamp", "ISO 8601", "2026-10-09T16:05:12Z", "Internal", "", "", "PII."),
       ("Response Score", "Score given to the main question (0 to 10 for NPS).", "Survey", "Integer", "", "9", "Net Promoter System", "", "Y", "PII."),
       ("NPS Category", "Promoter, passive or detractor, from the score.", "Survey", "Code", "NPS Category", "Promoter", "Net Promoter System", "", "", "PII."),
       ("Verbatim Comment", "Free-text comment of the respondent.", "Survey", "Text", "", "Rollover was easy; the call back took two days.", "Internal", "", "", "PII - may contain special category (CD-344). Restricted view; products read sentiment and themes only."),
       ("Triggering Interaction", "13 contact center interaction that triggered a transactional survey.", "Survey", "Reference (Contact Center Interaction)", "", "CCI-2026-1184520", "Internal", "", "", "PII. Owned by 13; referenced, never copied."),
       ("Complaint Referral", "08 complaint raised when the response may be a written complaint.", "Survey", "Reference (Complaint)", "", "CPL-2026-000318", "Internal", "FINRA Rule 4530", "", "PII. Owned by 08 Retail Conduct & Supervision."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Social & Paid Media", "MK-SOC",
  "Owned social media accounts, posts and engagement, social listening, and paid media placements, creatives and delivery metrics. Social media supervision and archiving are owned by 08 Retail Conduct & Supervision.",
  [
   ("Social Accounts & Posts", "Owned and employee social accounts and the posts published on them.", [
     ("Social Media Account", [
       ("Social Account ID", "Unique identifier of the social account.", "Social Account", "Identifier", "", "SOC-0008", "Internal", "", "Y", "Object PII tier: No PII for corporate accounts; PII - identity for an employee's account."),
       ("Social Platform", "Platform of the account.", "Social Account", "Code", "Social Platform", "YouTube", "Internal", "", ""),
       ("Account Handle", "Public handle or page URL.", "Social Account", "Text", "", "youtube.com/@exampleinvestments", "Internal", "", "", "PII where the account belongs to an individual employee."),
       ("Social Account Type", "Type of account.", "Social Account", "Code", "Social Account Type", "Corporate Brand", "Internal", "FINRA Rule 2210", ""),
       ("Archiving Enrolled Indicator", "Whether the account is connected to the firm's archiving and supervision tool.", "Social Account", "Boolean", "", "Y", "Internal", "FINRA Rule 2210", "Y", "Archiving and supervision owned by 08."),
     ]),
     ("Social Post", [
       ("Platform Post ID", "Platform identifier of the post.", "Social Post", "Identifier", "", "yt:video:Q3x8bR2kL0a", "Internal", "schema.org", "", "Object PII tier: No PII."),
       ("Post Timestamp", "When the post was published.", "Social Post", "Timestamp", "ISO 8601", "2026-10-14T12:00:00Z", "schema.org", "", ""),
       ("Post Content Classification", "Whether the post is static (pre-approved) or interactive content.", "Social Post", "Code", "Social Content Classification", "Static", "FINRA Rule 2210", "", "", "Static content typically requires pre-approval; classification confirmed by 08."),
       ("Post Campaign", "Campaign the post belongs to.", "Social Post", "Reference (Campaign)", "", "CAM-004512", "Internal", "", ""),
       ("Post Compliance Review", "Compliance review that approved the post.", "Social Post", "Reference (Compliance Review)", "", "REV-2026-002350", "Internal", "FINRA Rule 2210", "Y", "Owned by 08."),
     ]),
   ]),
   ("Social Engagement & Listening", "Engagement metrics for owned posts and mentions captured through social listening.", [
     ("Social Engagement Metrics", [
       ("Post Impressions", "Times the post was shown.", "Social Post", "Integer", "", "18450", "Internal", "", "", "Object PII tier: No PII."),
       ("Engagement Rate", "Engagements divided by impressions.", "Social Post", "Percentage", "", "3.3%", "Internal", "", ""),
     ]),
     ("Social Listening Mention", [
       ("Mention Sentiment", "Sentiment of the mention.", "Social Post", "Code", "Sentiment", "Negative", "Internal", "", "", "Object PII tier: PII - identity (public handle)."),
       ("Mention Author Handle", "Handle of the person who posted.", "Social Post", "Text", "", "@investor123", "Internal", "", "", "PII."),
       ("Escalated Complaint", "Complaint record raised if the mention is a potential complaint.", "Social Post", "Reference (Complaint)", "", "CPL-2026-000318", "Internal", "FINRA Rule 4530", "", "Owned by 08."),
     ]),
   ]),
   ("Paid Media", "Paid placements, ad creatives and their delivery and spend.", [
     ("Media Placement", [
       ("Placement ID", "Unique identifier of the placement or line item.", "Placement", "Identifier", "", "PLC-2026-0771", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Placement Campaign", "Campaign the placement belongs to.", "Placement", "Reference (Campaign)", "", "CAM-004512", "Internal", "", "Y"),
       ("Paid Media Channel", "Channel of the paid placement.", "Placement", "Code", "Paid Media Channel", "Paid Search", "Internal", "IAB", ""),
       ("Placement Geo Targeting", "Countries targeted.", "Placement", "Code (multi)", "ISO 3166-1 alpha-2", "US", "Internal", "", ""),
       ("Planned Placement Spend", "Planned spend for the placement.", "Placement", "Amount", "", "USD 20,000", "Internal", "", ""),
       ("Ad Creative Asset", "Approved creative used in the placement.", "Placement", "Reference (Content Asset)", "", "AST-018601", "Internal", "", ""),
       ("Ad Format", "Format or size of the creative.", "Placement", "Code", "Ad Format", "Responsive Search Ad", "IAB", "", ""),
     ]),
     ("Paid Media Delivery", [
       ("Impressions", "Impressions served.", "Placement", "Integer", "", "45210", "IAB", "", "", "Object PII tier: No PII."),
       ("Actual Spend", "Amount spent.", "Placement", "Amount", "", "USD 1,356.30", "Internal", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Performance & Attribution", "MK-ATR",
  "Marketing touchpoints, attribution models and the acquisition milestones campaigns are credited with. Campaign metrics are computed in data products (DP-025) from the facts here; 06 applies the attribution weights to its flows to report net new assets by campaign (CW-085).",
  [
   ("Touchpoints", "Engagements attributed to a party and campaign, forming the input to attribution.", [
     ("Marketing Touchpoint", [
       ("Touchpoint Party", "Client or prospect party that engaged.", "Touchpoint", "Reference (Party)", "", "PTY-104588", "Internal", "", "Y", "Object PII tier: PII - identity. PII (link to individual)."),
       ("Touchpoint Timestamp", "When the engagement occurred.", "Touchpoint", "Timestamp", "ISO 8601", "2026-10-14T13:43:02Z", "Internal", "", ""),
       ("Touchpoint Type", "Type of engagement.", "Touchpoint", "Code", "Touchpoint Type", "Email Click", "Internal", "", ""),
       ("Touchpoint Campaign", "Campaign credited with the touchpoint.", "Touchpoint", "Reference (Campaign)", "", "CAM-004512", "Salesforce", "", "Y"),
       ("Source Event", "Engagement event, registration, nudge delivery or advisor activity the touchpoint derives from.", "Touchpoint", "Reference (Engagement Event / Activity)", "", "evt_9b1d2e7c", "Internal", "", "", "Advisor activities (ACT-) owned by 03."),
     ]),
   ]),
   ("Attribution Models", "Rules that distribute credit for acquisition milestones across touchpoints.", [
     ("Attribution Model", [
       ("Attribution Model ID", "Unique identifier of the attribution model version.", "Attribution", "Identifier", "", "position_based_ms_v1", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Attribution Model Type", "Method of distributing credit.", "Attribution", "Code", "Attribution Model Type", "Position-Based (U-Shaped)", "Salesforce", "GA4", "Y"),
       ("Lookback Window", "Days before the milestone in which touchpoints are eligible.", "Attribution", "Integer", "Days", "90", "Internal", "GA4", ""),
       ("Primary Model Indicator", "Whether this is the firm's primary reporting model.", "Attribution", "Boolean", "", "Y", "Internal", "", ""),
     ]),
   ]),
   ("Attributed Outcomes", "Credit given to campaigns for acquisition milestones.", [
     ("Attributed Outcome", [
       ("Outcome Type", "Type of milestone attributed, from the acquisition milestone types.", "Attribution", "Code", "Acquisition Milestone Type", "Account Funded", "Internal", "", "", "Object PII tier: PII - financial (milestone of an identified party)."),
       ("Attributed Milestone", "Acquisition milestone credited.", "Attribution", "Reference (Acquisition Milestone, 04)", "", "PTY-104588 / ACCOUNT_FUNDED / 2026-10-09", "Internal", "", "Y", "Replaces Attributed Opportunity and Attributed Flow Record (CW-085)."),
       ("Attributed Campaign", "Campaign receiving credit.", "Attribution", "Reference (Campaign)", "", "CAM-004512", "Salesforce", "", "Y"),
       ("Applied Attribution Model", "Attribution model under which the credit was given.", "Attribution", "Reference (Attribution Model, 04)", "", "position_based_ms_v1", "Internal", "", ""),
       ("Attribution Weight", "Share of the milestone credited to the campaign under the model.", "Attribution", "Percentage", "", "40%", "Salesforce", "", "Y"),
       ("Attributed Amount", "Net new assets credited to the campaign: the 06 flow of the milestone multiplied by the weight.", "Attribution", "Amount", "", "USD 18,400", "Internal", "", "", "Derived copy of 06 (W4), which applies the 04 weights to its flows; 04 does not compute flows (CW-085)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Theme Type": ("Internal", [("Market Outlook",""),("Product / Capability",""),("Investor Education",""),("Retirement Readiness",""),("Life Events","Marriage, children, inheritance, job change"),("Sustainability / ESG",""),("Brand / Corporate","")]),
 "Business Line": ("Enterprise shared list 'Business Line' (steward 09, CW-004) - values copied", [("DB","Direct brokerage and self-directed investing"),("DA","Digital advice"),("HA","Human and hybrid advice"),("PF","Proprietary funds and ETFs (including CITs)"),("WR","Workplace retirement recordkeeping"),("IA","Institutional advisory"),("IC","Intermediary channel"),("TR","Personal trust services (optional)")]),
 "Audience Type": ("Internal (aligned to 02 relationship stage and investor category)", [("Prospect","Person not yet a client"),("Existing Client",""),("Workplace Plan Participant","Participant in a plan the firm recordkeeps (16)"),("Plan Sponsor",""),("Institutional Client","Institutional advisory (IA)"),("Financial Professional","Third-party advisor using the firm's ETFs and funds (IC, thin)"),("Media / Press",""),("Internal Employee","")]),
 "Campaign Level": ("Internal (Salesforce campaign hierarchy)", [("Program","Annual or multi-quarter umbrella"),("Campaign","Planned initiative with objective, audience and budget"),("Wave","Time-boxed release within a campaign"),("Tactic","Single executable item: an email, ad set, nudge or webinar")]),
 "Campaign Type": ("Salesforce / Internal", [("Acquisition","New clients"),("Funding","Fund new or under-funded accounts"),("Rollover Capture","Workplace plan and other employer plan assets to an IRA"),("Advice Enrollment","Digital or human advice"),("Referral","Client referral program"),("Product Launch",""),("Investor Education",""),("Nurture",""),("Retention / Cross-Sell",""),("Reactivation",""),("Event Promotion",""),("Brand / Advertising",""),("Partner Co-Marketing","Intermediary channel (IC) only")]),
 "Campaign Status": ("Salesforce", [("Planned",""),("Awaiting Compliance","Assets in review with 08"),("In Progress",""),("Completed",""),("Aborted","")]),
 "Campaign Objective": ("Internal", [("Awareness",""),("Lead Generation",""),("Account Opening",""),("Account Funding",""),("Asset Consolidation / Rollover",""),("Advice Enrollment",""),("Retention",""),("Event Attendance",""),("Digital Adoption","App download, e-delivery, recurring investments")]),
 "Marketing KPI": ("Internal", [("Reach / Impressions",""),("Engaged Visits",""),("Registrations",""),("Attendees",""),("MQLs",""),("Applications Started",""),("Applications Submitted",""),("Accounts Opened",""),("Accounts Funded",""),("Advice Enrollments",""),("Net New Assets","Computed by 06 from the 04 weights")]),
 "Marketing Channel": ("Internal (aligned to Adobe XDM channel types)", [("Email",""),("Website",""),("Mobile App","In-app cards and messages"),("Push Notification",""),("SMS",""),("Webinar",""),("In-Person Event",""),("Organic Social",""),("Paid Social",""),("Paid Search",""),("Programmatic Display",""),("Connected TV / Online Video",""),("Direct Mail",""),("Podcast / Audio",""),("Workplace Plan Communications","Through the participant website and plan sponsor"),("Advisor-Delivered","An own advisor presents or forwards approved content")]),
 "Product Role": ("Internal", [("Featured","Main subject of the campaign"),("Secondary",""),("Mentioned","")]),
 "Spend Category": ("Internal", [("Media",""),("Agency / Creative",""),("Event Venue & Logistics",""),("Technology & Data",""),("Print & Fulfillment",""),("Speaker Fees",""),("Content / Data Licensing",""),("Promotion & Referral Awards","Budgeted cost of awards; payments are 50 and 47")]),
 "UTM Medium": ("UTM / GA4 default channel grouping", [("email",""),("paid_social",""),("organic_social",""),("cpc","Paid search"),("display",""),("video",""),("referral",""),("affiliate","Affiliate and partner sites"),("sms",""),("push","App push notification"),("qr","Print and event QR codes")]),
 "Campaign Member Status": ("Salesforce (CampaignMember.Status)", [("Targeted","Not yet sent"),("Sent",""),("Opened",""),("Clicked","Counts as responded"),("Registered","Counts as responded"),("Attended","Counts as responded"),("No-Show",""),("Responded","Generic responded status"),("Unsubscribed","")]),
 "Content Type": ("Internal (aligned to 08 review categories)", [("Fact Sheet",""),("Market Commentary","Markets and outlook; not specific to a portfolio"),("Investment Commentary","Strategy, fund or portfolio commentary for a period"),("Educational Article / Guide",""),("White Paper / Research",""),("Fund / Strategy Presentation","Institutional advisory (IA)"),("Product Brochure",""),("Video",""),("Podcast Episode",""),("Webinar Recording",""),("Social Post",""),("Advertisement",""),("Email Template",""),("Push / In-App Message",""),("Landing Page",""),("Interactive Tool / Calculator",""),("Promotion Terms",""),("Press Release","Corporate press is 42")]),
 "Audience Restriction": ("Enterprise shared list 'Audience Restriction' (steward 08) - US values copied", [("Public / Retail","May be shown to anyone, including retail investors"),("Financial Professional Use Only","Third-party advisor use only (IC); not for use with the public"),("Institutional Use Only","Institutional investors as defined by FINRA Rule 2210 / 4512(c)"),("Client-Specific","Single client or prospect"),("Internal Use Only","")]),
 "FINRA Communication Category": ("FINRA Rule 2210", [("Retail Communication","More than 25 retail investors within 30 calendar days"),("Institutional Communication","Only institutional investors"),("Correspondence","25 or fewer retail investors within 30 calendar days")]),
 "Investor Category": ("Enterprise shared list 'Investor Category' (steward 02) - US values copied (CW-039)", [("Retail","US retail investor (FINRA Rule 2210)"),("Institutional","FINRA Rule 4512(c) institutional account or equivalent"),("Financial Professional","US registered representatives and investment adviser representatives")]),
 "Content Topic": ("Internal (cross-check IAB Content Taxonomy for paid media)", [("Investing Basics",""),("Retirement",""),("Tax",""),("College Savings",""),("Estate & Trust",""),("Markets & Economy",""),("Interest Rates",""),("Stocks",""),("Bonds",""),("ETFs",""),("Index Investing",""),("Cash & Money Market",""),("Financial Planning",""),("Sustainability / ESG","")]),
 "Asset Lifecycle Status": ("Internal", [("Draft",""),("In Compliance Review","Submitted to 08"),("Approved","Approved, not yet published"),("Published",""),("Expired","Past expiry date; auto-withdrawn"),("Withdrawn","Removed early"),("Archived","Retained for records only")]),
 "Withdrawal Reason": ("Internal", [("Data Superseded","Newer as-of data available"),("Product Change","Product merged, closed or changed"),("Compliance Request",""),("License Expired",""),("Error Found",""),("Campaign Ended","")]),
 "License Type": ("IPTC / Internal", [("Owned","Firm-created or work-for-hire"),("Royalty-Free",""),("Rights-Managed",""),("Creative Commons",""),("Data / Index License","Index or data vendor license")]),
 "WCAG Conformance Level": ("W3C WCAG 2.2", [("A",""),("AA","Target for public digital properties"),("AAA",""),("Not Assessed","")]),
 "Event Type": ("Internal", [("Client Seminar",""),("Webinar",""),("Workplace Education Session","For participants of a recordkept plan (WR)"),("Client Appreciation Event",""),("Investor Center Event","At a firm office"),("Virtual Office Hours","Open question-and-answer session with planners"),("Third-Party Conference (Attending)","")]),
 "Attendance Mode": ("schema.org eventAttendanceMode", [("Offline","OfflineEventAttendanceMode"),("Online","OnlineEventAttendanceMode"),("Mixed","MixedEventAttendanceMode")]),
 "Event Status": ("schema.org eventStatus", [("Scheduled","EventScheduled"),("Rescheduled","EventRescheduled"),("Postponed","EventPostponed"),("Moved Online","EventMovedOnline"),("Canceled","EventCancelled"),("Completed","Internal extension")]),
 "Registration Status": ("Internal", [("Invited",""),("Registered",""),("Waitlisted",""),("Canceled",""),("Attended",""),("Attended On-Demand",""),("No-Show",""),("Declined","")]),
 "Property Type": ("Internal", [("Public Website",""),("Client Website","Authenticated"),("Mobile App",""),("Workplace Participant Website","Authenticated (WR)"),("Fund & ETF Literature Center",""),("Institutional Client Portal","Authenticated (IA)"),("Microsite / Landing Page","")]),
 "Property Status": ("Internal", [("Planned",""),("Live",""),("Being Decommissioned",""),("Decommissioned","")]),
 "Audience Gate Type": ("Internal (FINRA Rule 2210 communication categories)", [("None","Public page"),("Client Login","Authenticated client website or app"),("Financial Professional Self-Certification","Visitor declares they are a registered representative or investment adviser representative"),("Institutional Investor Self-Certification","Visitor declares they are an institutional investor as defined in FINRA Rule 4512(c)"),("Verified Financial Professional Login","Login of a third-party advisor verified against FINRA BrokerCheck or SEC IAPD")]),
 "Page Type": ("Internal", [("Home",""),("Product Page",""),("Insight / Article",""),("Literature Library",""),("Landing Page",""),("Event Page",""),("Calculator / Tool",""),("Application Step","Step of an account application journey"),("Form",""),("Legal / Disclosure","")]),
 "Form Purpose": ("Internal", [("Content Download Gate",""),("Subscription Sign-Up",""),("Event Registration",""),("Contact Request","Request contact from an advisor or advice team"),("Appointment Request",""),("Preference Center",""),("Digital Profile Registration",""),("Referral Sign-Up","")]),
 "Identity Namespace": ("Adobe XDM identity namespaces / Internal", [("First-Party Cookie ID",""),("GA Client ID",""),("GA User ID",""),("CRM Contact ID",""),("Marketing Automation ID",""),("Hashed Email","SHA-256"),("Digital Profile ID","DIGP-"),("Mobile App Instance ID",""),("Mobile Advertising ID","")]),
 "Identification Status": ("Internal", [("Anonymous",""),("Known - Unmatched","Identifier captured, below the identity threshold (CW-083)"),("Known - Matched","Resolved to a party")]),
 "Identity Match Method": ("Internal", [("Form Submission",""),("Email Click-Through",""),("Authenticated Login",""),("Deterministic CRM Match",""),("Probabilistic","Lower confidence; not used for 1:1 targeting")]),
 "Tracking Consent Category": ("Internal (website cookie categories; CCPA / CPRA sale and sharing)", [("Strictly Necessary","No choice required"),("Functional",""),("Analytics",""),("Marketing / Advertising","Cross-context behavioral advertising; a 'sharing' under the CPRA")]),
 "Tracking Choice Source": ("Internal / CCPA regulations", [("Cookie Banner",""),("Preference Center",""),("Global Privacy Control Signal","Opt-out preference signal sent by the browser"),("Mobile OS Tracking Prompt","App tracking permission on the device")]),
 "Digital Profile Status": ("Internal", [("Pending Activation",""),("Active",""),("Locked","Too many failed attempts or suspected compromise"),("Suspended","Compliance or fraud hold"),("Closed","")]),
 "MFA Factor Type": ("NIST SP 800-63B authenticator types / Internal", [("SMS One-Time Passcode","Restricted authenticator under NIST SP 800-63B (confirm in Revision 4)"),("Voice One-Time Passcode",""),("Email One-Time Passcode",""),("Authenticator App (TOTP)",""),("Push Approval",""),("Security Key / Passkey (FIDO2)","Phishing-resistant")]),
 "Login Method": ("Internal", [("Password Only",""),("Password + MFA",""),("Passkey",""),("Device Biometric Unlock","Biometric match on the device"),("Workplace Single Sign-On","From the plan sponsor or recordkeeping site"),("Not Authenticated","")]),
 "Engagement Event Type": ("GA4 / Adobe XDM", [("page_view",""),("file_download",""),("form_start",""),("form_submit",""),("view_search_results",""),("video_start",""),("video_progress",""),("video_complete",""),("login",""),("app_open",""),("feature_use",""),("journey_step","Step of an application journey"),("nudge_view",""),("webinar_join",""),("tool_use","Interactive tool or calculator")]),
 "Digital Feature": ("Internal", [("Trade Ticket",""),("Watchlist",""),("Research & Screeners",""),("Portfolio Overview",""),("Transfer & Deposit",""),("Recurring Investment Setup",""),("Goal Planner",""),("Investor Questionnaire","Answers are 02 Investor Profile"),("Document Center",""),("Secure Message",""),("Profile & Security Settings","")]),
 "Email Send Type": ("CAN-SPAM", [("Commercial","Primary purpose is promotional, whoever sends it (an advisor-sent marketing email is Commercial)"),("Transactional / Relationship","")]),
 "Email Delivery Status": ("Adobe XDM directMarketing", [("Sent",""),("Delivered",""),("Soft Bounce",""),("Hard Bounce",""),("Blocked",""),("Deferred","")]),
 "Viewing Mode": ("Internal", [("Live",""),("Simulive","Pre-recorded, broadcast at a set time"),("On-Demand","")]),
 "Segment Type": ("Internal / Adobe XDM", [("Rule-Based (Dynamic)",""),("Static List",""),("Lookalike",""),("Exclusion","")]),
 "Subscription Category": ("Internal", [("Market Insights",""),("Product Updates",""),("Investor Education",""),("Retirement Planning",""),("Event Invitations",""),("Promotions & Offers",""),("Operational Notices","Not marketing; not opt-out-able per topic")]),
 "Suppression Reason": ("Internal / CAN-SPAM / TCPA / FTC Telemarketing Sales Rule", [("Global Unsubscribe",""),("Hard Bounce",""),("Spam Complaint",""),("National Do Not Call Registry","Telephone and text marketing"),("Firm-Specific Do-Not-Call","FINRA Rule 3230 and 47 CFR 64.1200(d)"),("TCPA Consent Revoked","Revocation received by any reasonable means"),("Reassigned Number","FCC Reassigned Numbers Database"),("Do Not Contact","From 02 Privacy Profile"),("Competitor",""),("Internal Employee",""),("Deceased","")]),
 "Suppression Scope": ("Internal", [("Global","All marketing"),("Channel",""),("Topic",""),("Business Line","")]),
 "Lead Type": ("Internal", [("Individual Prospect","Self-directed investing (DB)"),("Advice Prospect","Digital, human or hybrid advice (DA, HA)"),("Workplace Participant","Rollover or IRA prospect from a recordkept plan (WR)"),("Trust & Estate Prospect","Personal trust services (TR)"),("Institutional Prospect","Institutional advisory (IA)"),("Financial Professional","Intermediary channel (IC); handed to 05 at W4")]),
 "Lead Source": ("Salesforce / Internal", [("Website Form",""),("Content Download",""),("Calculator / Tool",""),("Webinar",""),("Event",""),("Paid Media",""),("Social",""),("Mobile App",""),("Client Referral",""),("Workplace Plan",""),("Advisor-Created","")]),
 "Lead Status": ("Internal (aligned to the MQL funnel)", [("New",""),("Nurture",""),("MQL","Marketing qualified"),("Accepted","Accepted by an advisor or advice team"),("Converted",""),("Recycled","Returned to nurture"),("Disqualified","")]),
 "Lifecycle Stage": ("Salesforce MCAE lifecycle stages / Internal", [("Visitor",""),("Prospect",""),("Marketing Qualified Lead",""),("Applicant",""),("Client","")]),
 "Fit Grade": ("Salesforce MCAE grading", [("A+",""),("A",""),("A-",""),("B+",""),("B",""),("B-",""),("C+",""),("C",""),("C-",""),("D+",""),("D",""),("D-",""),("F","")]),
 "Disqualification Reason": ("Internal", [("Existing Client",""),("Non-Permitted Jurisdiction","Resides where the firm does not offer the service"),("Under Age of Majority",""),("Competitor",""),("Duplicate",""),("Invalid Contact Data","")]),
 "Conversion Outcome": ("Salesforce / Internal", [("Converted to Prospect Party","02 party created or matched (CW-083)"),("Application Started",""),("Merged",""),("Rejected","")]),
 "Journey Type": ("Internal", [("Brokerage Account Opening",""),("IRA Opening",""),("IRA Rollover",""),("529 Plan Account Opening",""),("Custodial (UTMA / UGMA) Opening",""),("Digital Advice Enrollment",""),("Advice Consultation Request","Human or hybrid advice"),("Trust Account Opening",""),("Account Transfer In (ACATS)","")]),
 "Journey Step": ("Internal", [("Product Selection",""),("Identity & Contact",""),("Employment & Financial Profile",""),("Investor Questionnaire","Answers are 02 Investor Profile"),("Beneficiaries",""),("Disclosures & Agreements",""),("Funding Method",""),("Review & Submit","")]),
 "Journey Status": ("Internal", [("In Progress",""),("Abandoned",""),("Resumed",""),("Submitted","15 Account Opening is the master from here"),("Expired","")]),
 "Abandonment Reason": ("Internal", [("Timed Out",""),("User Exited",""),("Identity Step Failed",""),("Funding Not Linked",""),("Ineligible",""),("Technical Error",""),("Unknown","")]),
 "Acquisition Milestone Type": ("Internal (CW-085)", [("Prospect Created","02 party with Relationship Stage Prospect"),("Application Started",""),("Application Submitted",""),("Account Opened","Date copied from 15"),("Account Funded","Date copied from 50"),("Advice Enrolled","Digital or human advice (45, 15)"),("Rollover Completed","Date copied from the 50 rollover receipt money movement (the ruled default source, 16 fix pass); the 16 Participant Retail Hand-Off outcome is not read"),("Recurring Investment Set Up","")]),
 "Nudge Type": ("Internal / SEC Release 34-92766 (digital engagement practices)", [("Task Reminder",""),("Educational Prompt",""),("Feature Discovery",""),("Savings Prompt",""),("Product Suggestion","Usually Determined Recommendation after the 08 review"),("Milestone Message","")]),
 "Recommendation Risk Class": ("08 determination (Reg BI; SEC Release 34-92766)", [("Pending Determination","Not deliverable until 08 decides"),("Determined Not a Recommendation","Educational or task prompt"),("Determined Recommendation","Every delivery carries a 45 Recommendation"),("Advice Program Communication","Sent within a 45 advice engagement")]),
 "Suppression Check Result": ("Internal", [("Passed",""),("Suppressed - Opted Out",""),("Suppressed - Frequency Cap",""),("Suppressed - Do Not Contact",""),("Suppressed - Compliance Hold","")]),
 "Nudge Response": ("Internal", [("Viewed",""),("Clicked",""),("Dismissed",""),("Completed Action",""),("No Response","")]),
 "Experiment Status": ("Internal", [("Draft",""),("In Review",""),("Running",""),("Paused",""),("Completed",""),("Stopped Early","")]),
 "Experiment Decision": ("Internal", [("Ship Variant",""),("Keep Control",""),("Iterate",""),("Inconclusive","")]),
 "Promotion Award Type": ("Internal", [("Cash Bonus","Paid by 50"),("Transfer Fee Reimbursement","Paid by 50"),("Fee Waiver / Credit","Applied by 47"),("Commission-Free Trades","Applied by 47"),("Advisory Fee Discount Period","Applied by 47"),("Referral Reward","Earned through a Client Referral; paid by 50 or applied by 47"),("Non-Cash Gift","")]),
 "Promotion Status": ("Internal", [("Draft",""),("In Review",""),("Active",""),("Closed",""),("Withdrawn","")]),
 "Promotion Enrollment Status": ("Internal", [("Enrolled",""),("Qualified",""),("Disqualified",""),("Award Pending",""),("Award Paid",""),("Award Reversed","Clawed back, for example for an early transfer out")]),
 "Referral Program Status": ("Internal", [("Invited",""),("Referee Registered",""),("Referee Applied",""),("Referee Funded",""),("Reward Earned",""),("Reward Paid",""),("Expired",""),("Rejected","")]),
 "Survey Type": ("Net Promoter System / Internal", [("Relationship NPS",""),("Transactional NPS",""),("CSAT",""),("Customer Effort Score (CES)",""),("Onboarding Experience",""),("Product Feedback","")]),
 "Survey Trigger": ("Internal", [("Periodic (Relationship)",""),("Contact Center Interaction Closed","13"),("Service Request Completed","13"),("Account Opened","15"),("Digital Journey Completed",""),("Event Attended","")]),
 "NPS Category": ("Net Promoter System", [("Promoter","Score 9 or 10"),("Passive","Score 7 or 8"),("Detractor","Score 0 to 6")]),
 "Social Platform": ("Internal", [("LinkedIn",""),("X",""),("YouTube",""),("Instagram",""),("Facebook",""),("Threads",""),("Other","")]),
 "Social Account Type": ("Internal (aligned to FINRA social media guidance)", [("Corporate Brand",""),("Product / Fund Brand",""),("Executive / Portfolio Manager",""),("Employee Advocacy / Advisor","Own advisors and employees")]),
 "Social Content Classification": ("FINRA Rule 2210 / FINRA Regulatory Notices on social media", [("Static","Pre-approved content"),("Interactive","Real-time interaction; supervised post-use"),("Third-Party Shared","Shared or linked third-party content")]),
 "Sentiment": ("Internal", [("Positive",""),("Neutral",""),("Negative",""),("Mixed","")]),
 "Paid Media Channel": ("Internal (cross-check IAB)", [("Paid Social",""),("Paid Search",""),("App Store Search",""),("Programmatic Display",""),("Native",""),("Connected TV / Online Video",""),("Audio / Podcast",""),("Publisher Direct (Digital)",""),("Print",""),("Sponsored Newsletter",""),("Out-of-Home","")]),
 "Ad Format": ("IAB New Ad Portfolio / platform formats", [("300x250 Medium Rectangle",""),("728x90 Leaderboard",""),("320x50 Mobile Banner",""),("Responsive Search Ad",""),("Single Image Sponsored Content",""),("Carousel",""),("Video 15s",""),("Video 30s",""),("Native In-Feed","")]),
 "Touchpoint Type": ("Internal", [("Email Click",""),("Web Visit",""),("App Engagement",""),("Content Download",""),("Form Submission",""),("Event Attendance",""),("Webinar Attendance",""),("Paid Media Click",""),("Social Engagement",""),("Nudge Response",""),("Client Referral",""),("Advisor Activity","Meeting or call logged in 03")]),
 "Attribution Model Type": ("Salesforce Campaign Influence / GA4 / Internal", [("First Touch",""),("Last Touch",""),("Linear / Even",""),("Time Decay",""),("Position-Based (U-Shaped)","40/20/40"),("W-Shaped",""),("Data-Driven","Algorithmic")]),
 "Martech System Category": ("Internal", [("CRM",""),("Marketing Automation (MAP)",""),("Customer Data Platform (CDP)",""),("Digital Asset Management (DAM)",""),("Content Management (CMS)",""),("Web & App Analytics",""),("Tag / Consent Management",""),("Experimentation Platform",""),("Push & In-App Messaging",""),("Survey / Voice of Client Platform",""),("Event Management",""),("Webinar Platform",""),("Social Publishing",""),("Social Archiving","Operated for 08"),("Ad Platform / DSP","")]),
 "Personal Data Category": ("Enterprise shared list 'Personal Data Category' (steward 02) - values copied", [("No Personal Data",""),("Identity","Name, date of birth and other identity attributes"),("Contact","Business or personal contact details"),("Professional / Employment","Employer, role and professional history of an external individual"),("Registration / Licensing","Regulatory registrations and licenses"),("HR / Employee","Own-employee HR data"),("Financial","Holdings, transactions, account and payment data"),("Government Identifier","SSN, passport, national ID; sensitive under the CPRA"),("Online Identifiers / Engagement","Cookies, device IDs and digital engagement data"),("Inferences / Segmentation","Profiles, scores and segments derived about the individual"),("Opinion About Individual","Recorded opinions or assessments about a person"),("Free Text - May Contain Personal Data","Unstructured notes that may contain personal data")]),
}

# ---------------------------------------------------------------------------
# Relationships, sources
# ---------------------------------------------------------------------------
REL = [
 ("Marketing Theme","is expressed by","Messaging Pillar","1 : 1..n",""),
 ("Campaign (Program)","contains","Campaign (Campaign / Wave / Tactic)","1 : 0..n","Self-referencing hierarchy via Parent Campaign."),
 ("Campaign","executes","Marketing Theme","n : 0..1",""),
 ("Campaign","promotes","Investment Product / Share Class / Service Offering [01]","n : n","Via Campaign Product with Product Role."),
 ("Campaign","is co-funded under","Agreement [05]","n : 0..1","Intermediary channel (IC) co-marketing only; 05 is replaced at W4."),
 ("Campaign","targets","Marketing Segment","n : n","Via Campaign Targeting."),
 ("Campaign","has","Campaign Member","1 : 0..n",""),
 ("Campaign Member","is","Party [02] or Marketing Lead","n : 1",""),
 ("Campaign","is tracked by","Campaign Tracking Code","1 : 0..n","utm_id = Campaign ID."),
 ("Campaign","deploys","Content Asset / Marketing Event / Email Send / Social Post / Media Placement / Promotion Offer","1 : 0..n","Nudges are deployed through their content asset and trigger, not a campaign reference."),
 ("Content Asset","is approved under","Compliance Review [08]","n : 1","Per version; approval status mirrored read-only."),
 ("Content Asset","features","Investment Product / Share Class [01]","n : n",""),
 ("Content Asset","publishes","Investment Commentary [01]","n : 0..n",""),
 ("Content Asset","is derived from","Content Asset","n : 0..1","For example a social cut-down of a webinar recording."),
 ("Marketing Event","has","Event Session / Event Speaker","1 : 0..n","Speakers are EMP- (20, advisors in 03) or PTY- (02)."),
 ("Marketing Event","has","Event Registration","1 : 0..n",""),
 ("Event Registration","is invited by","Advisor [03]","n : 0..1",""),
 ("Digital Property","contains","Web Page / Web Form","1 : 0..n",""),
 ("Marketing System","profiles","Application [41]","1 : 1","CD-264."),
 ("Web Visitor","is resolved to","Party [02]","n : 0..1","At the identity threshold (CW-083)."),
 ("Web Visitor","makes","Tracking Consent Choice","1 : 0..n","Unmatched visitors; once matched, the opt-out is 02 Privacy Profile (CW-084)."),
 ("Digital Profile","belongs to","Party [02]","n : 1","The client's online login profile (CW-086)."),
 ("Web Visitor","generates","Engagement Event","1 : 0..n",""),
 ("Engagement Event","is a step of","Application Journey","n : 0..1","journey_step events."),
 ("Email Send","produces","Email Interaction","1 : 0..n","One per recipient."),
 ("Email Interaction","writes the unsubscribe to","Communication Preference [02]","n : 0..1","Within 10 business days (CAN-SPAM; CW-084)."),
 ("Marketing Segment","includes","Party [02]","n : n","Via effective-dated Segment Membership; may use 02 Segment Assignment as a criterion (CW-094)."),
 ("Subscription Topic","is the subject of","Communication Preference [02]","1 : 0..n","Opt-in per party, topic and channel is mastered in 02."),
 ("Suppression Entry","overrides","Communication Preference [02]","n : n","A suppressed identifier is never contacted, whatever the opt-in."),
 ("Suppression Entry","writes the revocation to","Consent Record [02]","n : 0..1","TCPA revocations: 04 captures, 02 masters (CW-084)."),
 ("Session","belongs to","Web Visitor","n : 1",""),
 ("Engagement Event","occurs in","Session","n : 0..1",""),
 ("Web Page","is gated by","Audience Gate (FINRA Rule 2210)","n : 0..1","Financial-professional-only and institutional content."),
 ("Marketing Lead","is routed to","Advisor / Coverage Team [03]","n : 0..1",""),
 ("Marketing Lead","converts to","Party [02] (Relationship Stage Prospect)","1 : 0..1","CW-083."),
 ("Marketing Lead","starts","Application Journey","1 : 0..1",""),
 ("Application Journey","is submitted as","Onboarding Case [02] / Account [15]","1 : 0..1","15 Account Opening is the master from submission (CW-085)."),
 ("Acquisition Milestone","concerns","Party [02] / Account [15]","n : 1","Opening dates copied from 15, funding and rollover dates from 50 (rollover: the 50 receipt is the default source; 16 hand-off outcomes are not read)."),
 ("Nudge Definition","is approved under","Compliance Review [08]","n : 1","08 determines the Recommendation Risk Class under this review (CW-091)."),
 ("Nudge Definition","has","Nudge Delivery","1 : 0..n",""),
 ("Nudge Delivery","carries","Recommendation [45]","n : 0..1","Mandatory when the nudge is Determined Recommendation (CW-091)."),
 ("Experiment","assigns","Experiment Assignment","1 : 0..n","Visitor or party x variant."),
 ("Experiment","is decided by","Metric Definition [21]","n : 1",""),
 ("Promotion Offer","has","Promotion Enrollment","1 : 0..n",""),
 ("Promotion Enrollment","is paid by","Money Movement [50]","1 : 0..n","Cash awards; 50 holds the link (Money Movement references the enrollment; MMVMT-, W3)."),
 ("Promotion Enrollment","is applied as","Fee Waiver [47]","1 : 0..1","Fee awards; 04 holds the link (Award Fee Waiver, CW-092)."),
 ("Promotion Enrollment","is reported on","Tax Form Record [13]","n : 0..1","Form 1099-MISC where Form 1099-MISC Reportable Indicator = Y; 13 holds the link."),
 ("Client Referral","links","Party (referrer) [02] to Party or Marketing Lead (referee)","n : 1",""),
 ("Client Referral","is rewarded through","Promotion Enrollment","n : 0..1","Referral Reward Enrollment (CW-092)."),
 ("Client Survey","collects","Survey Response","1 : 0..n",""),
 ("Survey Response","is triggered by","Contact Center Interaction [13]","n : 0..1","Transactional surveys (CW-093)."),
 ("Survey Response","may raise","Complaint [08]","1 : 0..1","FINRA Rule 4530."),
 ("Social Post","is approved under","Compliance Review [08]","n : 0..1","Archiving and supervision owned by 08."),
 ("Social Listening Mention","may raise","Complaint [08]","1 : 0..1",""),
 ("Media Placement","uses","Content Asset (Ad Creative)","n : 1",""),
 ("Engagement Event / Event Registration / Nudge Delivery / Advisor Activity [03]","becomes","Marketing Touchpoint","1 : 0..1","When attributable to a party and campaign."),
 ("Attributed Outcome","credits","Campaign","n : 1","Under one Attribution Model."),
 ("Attributed Outcome","credits","Acquisition Milestone","n : 1","Replaces opportunity and flow outcomes (CW-085)."),
 ("Attributed Outcome","is valued by","Net new assets by campaign [06]","n : 0..1","Attributed Amount is a Derived copy; future owner 06 (W4)."),
]

SRC = [
 ("Salesforce Sales Cloud object reference (Campaign, CampaignMember, Lead, Campaign Influence)","Salesforce","https://developer.salesforce.com/docs/atlas.en-us.object_reference.meta/object_reference/sforce_api_objects_campaign.htm","Public documentation","Campaign hierarchy (ParentId), Type, Status, BudgetedCost, ActualCost; CampaignMember Status / HasResponded; Lead source, status and conversion; campaign influence","Campaign Management, Campaign Membership, Leads, Attribution",["Salesforce"]),
 ("Salesforce Marketing Cloud Account Engagement (Pardot) API - Prospect, Lifecycle Stage","Salesforce","https://developer.salesforce.com/docs/marketing/pardot/guide/lifecycle-stage-v5.html","Public documentation","Prospect score and grade, lifecycle stages, forms, subscription lists","Lead Qualification & Scoring, Subscription Topic, Web Form",["Salesforce MCAE"]),
 ("Adobe Experience Data Model (XDM)","Adobe","https://github.com/adobe/xdm","Open source (Apache 2.0 / CC-BY)","ExperienceEvent class, identity namespaces, Web Details, Direct Marketing (email sent / delivered / opened / clicked / bounced / unsubscribed) and Campaign Marketing field groups","Digital Identity & Engagement, Email Engagement, Segments",["Adobe XDM"]),
 ("Adobe Experience League - XDM ExperienceEvent and Web Details field group","Adobe","https://experienceleague.adobe.com/en/docs/experience-platform/xdm/classes/experienceevent","Public documentation","Event _id, timestamp, eventType values; web.webPageDetails","Engagement Event, Web Page",[]),
 ("Google Analytics 4 - enhanced measurement events and UTM / campaign parameters","Google","https://support.google.com/analytics/answer/9216061","Public documentation","Event model (page_view, file_download, form_submit, video_progress, view_search_results) and parameters; utm_id, utm_source_platform, utm_creative_format","Tracking Codes, Session, Engagement Event, Media Engagement",["GA4"]),
 ("UTM parameter convention (Urchin Tracking Module)","Google (de facto standard)","https://support.google.com/analytics/answer/10917952","Public documentation","utm_source, utm_medium, utm_campaign, utm_term, utm_content","Campaign Tracking Code",["UTM"]),
 ("DCMI Metadata Terms (Dublin Core)","Dublin Core Metadata Initiative","https://www.dublincore.org/specifications/dublin-core/dcmi-terms/","Open (CC BY 4.0)","title, description, creator, publisher, type, format, language, subject, rights, source, issued, replaces","Content Asset identity, classification and versioning",["Dublin Core"]),
 ("IPTC Photo Metadata Standard","IPTC","https://iptc.org/standards/photo-metadata/iptc-standard/","Open (CC BY 4.0)","Copyright Notice, Credit Line, Rights Usage Terms (XMP), Keywords, Alt Text (Accessibility), Extended Description","Asset Rights, Accessibility",["IPTC"]),
 ("Adobe XMP specification (ISO 16684-1)","Adobe / ISO","https://developer.adobe.com/xmp/docs/","Open specification; ISO purchase","Embedded metadata container for DAM assets (xmpRights, xmpMM version / document IDs)","Asset Version, Rights (secondary reference)",["XMP"]),
 ("schema.org Event and CreativeWork","schema.org","https://schema.org/Event","Open (CC BY-SA 3.0)","Event name, startDate, location, organizer, eventAttendanceMode, eventStatus; CreativeWork / SocialMediaPosting","Marketing Event, Social Post",["schema.org"]),
 ("W3C Web Content Accessibility Guidelines (WCAG) 2.2","W3C","https://www.w3.org/TR/WCAG22/","Open (W3C license)","Text alternatives, captions, conformance levels A / AA / AAA","Asset Accessibility, Digital Properties",["WCAG 2.2"]),
 ("FINRA Rule 2210 - Communications with the Public (and social media Regulatory Notices)","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2210","Rule (public)","Retail communication / institutional communication / correspondence definitions; institutional-only and financial-professional-only gating (Audience Gate); principal approval, filing and record-keeping; firm name disclosure (2210(d)(3)); testimonials (2210(d)(6)); static vs interactive social content","Audience Restriction, FINRA Communication Category, Publishing Entity, Social Accounts & Posts, review references (approval owned by 08)",["FINRA Rule 2210"]),
 ("SEC Marketing Rule - Investment Advisers Act Rule 206(4)-1","US SEC","https://www.sec.gov/rules-regulations/2020/12/investment-adviser-marketing","Regulation (public)","Advertisement definition; testimonials and endorsements (compensated client referrals) and their disclosures (206(4)-1(b)(1), oversight (b)(2), disqualification (b)(3); confirm); third-party ratings; performance and hypothetical performance","Compliance Linkage indicators, Proof Points, Client Referral (review owned by 08)",["SEC Marketing Rule"]),
 ("CAN-SPAM Act: A Compliance Guide for Business (16 CFR Part 316)","US FTC","https://www.ftc.gov/business-guidance/resources/can-spam-act-compliance-guide-business","Regulation (public)","Commercial vs transactional email, non-misleading headers and subject lines, opt-out honored within 10 business days","Email Send Type, Subject Line, Unsubscribe, Suppression",["CAN-SPAM"]),
 ("Telephone Consumer Protection Act (47 U.S.C. 227) and FCC rules (47 CFR 64.1200)","US Congress / FCC","https://www.law.cornell.edu/uscode/text/47/227","Statute and regulation (public)","Prior express written consent for marketing calls and texts; company-specific do-not-call lists; revocation of consent by any reasonable means (FCC revocation rules effective April 11, 2025; the revoke-all provision of 64.1200(a)(10) delayed to January 31, 2027, confirm); one-to-one consent rule vacated by the Eleventh Circuit on January 24, 2025","Suppression Reason, Nudge Delivery channel, Lead outreach (consents mastered in 02)",["TCPA"]),
 ("FTC Telemarketing Sales Rule (16 CFR Part 310) and the National Do Not Call Registry","US FTC","https://www.ftc.gov/legal-library/browse/rules/telemarketing-sales-rule","Regulation (public)","Registry access and the requirement to scrub calling lists against it (at least every 31 days; confirm)","Suppression Entry (Registry Scrub Date, Suppression Reason)",["FTC Telemarketing Sales Rule"]),
 ("FINRA Rule 3230 Telemarketing","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/3230","Rule (public)","Firm-specific do-not-call list, time-of-day limits, National Do Not Call Registry for broker-dealers","Suppression Entry",["FINRA Rule 3230"]),
 ("Regulation S-P (17 CFR Part 248)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-248","Regulation (public)","Privacy of consumer financial information; opt-outs and notices (mastered in 02, delivered by 13); 2024 amendments with compliance dates December 3, 2025 (larger entities) and June 3, 2026 (smaller entities) (confirm)","Marketing System (Personal Data Categories Processed), boundary notes",["SEC Regulation S-P"]),
 ("California Consumer Privacy Act as amended by the CPRA, and the CCPA regulations (opt-out preference signals)","California Privacy Protection Agency / California Attorney General","https://cppa.ca.gov/regulations/","Statute and regulations (public; confirm path)","Sale and sharing of personal information, cross-context behavioral advertising, notice at collection, opt-out preference signals (11 CCR § 7025, confirm); GLBA data exemption","Tracking Consent Choice, Applied Tracking Consent, Privacy Notice Version, Personal Data Categories Processed",["CCPA / CPRA"]),
 ("Global Privacy Control specification","Global Privacy Control / W3C Privacy Community Group","https://globalprivacycontrol.org","Open specification","Sec-GPC browser signal used as an opt-out preference signal","Tracking Choice Source, Sale / Sharing Opt-Out Signal Indicator",["Global Privacy Control"]),
 ("SEC request for information and comments on broker-dealer and investment adviser digital engagement practices (Release Nos. 34-92766 and IA-5833, August 27, 2021)","US SEC","https://www.sec.gov/news/press-release/2021-167","Release (public)","Behavioral prompts, gamification, personalization and when they may be recommendations; the 2023 predictive data analytics proposal was withdrawn on June 12, 2025 (confirm)","Nudge Type, Recommendation Risk Class",["SEC Release 34-92766"]),
 ("Regulation Best Interest (Exchange Act Rule 15l-1)","US SEC","https://www.ecfr.gov/current/title-17/section-240.15l-1","Regulation (public)","Recommendation to a retail customer; care obligation (recommendation evidence mastered in 45)","Recommendation Risk Class, Linked Recommendation",["SEC Reg BI"]),
 ("NIST SP 800-63B-4 Digital Identity Guidelines: Authentication and Authenticator Management (Revision 4, 2025; confirm)","US NIST","https://pages.nist.gov/800-63-4/sp800-63b.html","Public guideline","Authenticator types (out-of-band, OTP, cryptographic), restricted authenticators (SMS), multi-factor authentication","MFA Factor Type, Login Method, Biometric Login Enabled Indicator",["NIST SP 800-63B"]),
 ("Net Promoter System (Bain & Company)","Bain & Company","https://www.netpromotersystem.com","Public methodology (trademark)","0-10 likelihood-to-recommend question; promoters 9-10, passives 7-8, detractors 0-6; relationship and transactional NPS","Client Survey, Survey Response, NPS Category",["Net Promoter System"]),
 ("IRS Instructions for Forms 1099-MISC and 1099-NEC","US IRS","https://www.irs.gov/instructions/i1099mec","Public instructions","Other income (prizes and awards) reporting and thresholds (confirm the threshold for payments after 2025)","Form 1099-MISC Reportable Indicator",["IRS Form 1099-MISC"]),
 ("FINRA Rule 4530 Reporting Requirements (written customer complaints)","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/4530","Rule (public)","Written customer complaint definition and quarterly statistical reporting (complaints mastered in 08)","Complaint Referral, Escalated Complaint",["FINRA Rule 4530"]),
 ("IAB Tech Lab Taxonomies (Content, Audience, Ad Product) and ad format guidelines","IAB Tech Lab","https://github.com/InteractiveAdvertisingBureau/Taxonomies","Open (CC BY 3.0)","Standard content and audience categories and ad formats for paid media","Paid Media Channel, Ad Format, Content Topic cross-check",["IAB"]),
 ("ISO 4217 / ISO 3166-1 / ISO 639-1 / ISO 8601 / IANA Time Zones / IANA Media Types","ISO; IANA","https://www.iso.org","Standard; code lists widely available","Currency, country, language, date / time, time zone and MIME type codes","Reference code lists used throughout",["ISO 4217"]),
]
