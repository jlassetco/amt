"""Data Domain 05 - Intermediary & Institutional Distribution (wealth-manager reference model; replaces the wholesale 05
Distribution Agreements & Partners, CW-013, CW-131). Content module for taxonomy_builder.py.

Written beside the wholesale content_05_distribution_agreements_and_partners.py, which the program lead removes at
integration. Restores by exact name thirteen wholesale 02 role profiles (CW-132), nine wholesale 03 pipeline, RFP and
database objects plus Placement & Plan Detail (CW-134), the wholesale 08 Distributor Due Diligence and Due Diligence
Finding (CW-135) and the 13 Intermediary Communication Fee Invoice (CW-088).
"""

META = {
 "title": "Intermediary & Institutional Distribution Data Taxonomy",
 "subtitle": "Business domain 05 - Intermediary & Institutional Distribution | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-15",
 "output": "05_Intermediary_and_Institutional_Distribution/Intermediary_and_Institutional_Distribution_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the commercial record of the two secondary channels of a US wealth manager that serves investors directly: the thin intermediary channel (IC), through which third-party advisors, broker-dealers, RIAs, platforms, model marketplaces and third-party recordkeepers use the firm's own mutual funds, ETFs, CITs and model portfolios, and the institutional advisory line (IA), which wins institutional mandates and OCIO relationships through consultants and searches. It also holds the plan sponsor pipeline of the workplace recordkeeping line (WR). The domain masters the partner and consultant role profiles (keyed by 02 parties), partner coverage, selling, platform, sub-accounting, networking, model and data agreements, the platform, sub-accounting and networking fees paid to partners, shelf and model placement, model delivery, dealer and networking set-up, distributor due diligence, partner payment disclosures, consultant databases and ratings, and the institutional, placement and plan sponsor pipeline with its RFPs. It is built from FINRA Rules 2341, 3110 and 2251, SEC IM Guidance Update 2016-01, SEC Rule 22c-2, Regulation Best Interest, Form ADV Part 1A, Form BR and BrokerCheck, DOL 29 CFR 2550.408b-2, DTCC NSCC Fund/SERV and Networking, the ICI / IDC intermediary oversight guidance, Nasdaq eVestment data collection, GIPS and the Salesforce opportunity model as a cross-check. Use it as a starting point for a partner master, an agreements repository, a partner payments engine, a shelf register, a consultant database calendar, a CRM pipeline model or a business glossary."),
  ("Scope", "In scope: role profiles keyed by the 02 party of an intermediary or consultant (Distributor Firm with its Form ADV Profile, Hierarchy Node, Branch / Office, Advisor Team, Team Membership, Gatekeeper Profile; Financial Professional (the External Advisor) with Advisor Practice, Employment Affiliation and External Classification; Consultant Profile and Consultant Advisory Relationship); Partner Coverage Assignment (PCVG-) of partner firms, external advisors, consultants and third-party recordkeepers by firm employees; distribution agreements (AGR-: selling, platform, sub-accounting and shareholder services, networking, Rule 22c-2 shareholder information, model provider, SMA sponsor, recordkeeper services, data sharing, co-marketing, authorized participant) with parties, terms, amendments, product coverage, distribution scope and linked accounts; partner payment arrangements (PYA-) with rate schedules, tiers and sub-accounting fee terms, payment calculations (PCL-), partner invoices, partner payments (PMT-) and intermediary communication fee invoices (IFI-); shelf placement (SHF-), share class mapping, partner research ratings, partner programs (PGM-) and memberships, model program placement and model delivery events (MDEV-); partner dealer and networking set-up, partner data feed arrangements, distributor due diligence (DDQ-) and findings, agreement obligations with their service levels, and partner payment disclosures including ERISA 408(b)(2) information; consultant databases (DBS-) and submissions and consultant ratings; the institutional, OCIO, intermediary placement and plan sponsor pipeline (OPP-) and RFP, RFI and DDQ requests (RFP-). Out of scope (referenced by ID only): the party core, CRD, LEI, NSCC and TA dealer identifiers and party roles (02); own advisors, client coverage and every meeting or call (03 Advisor Activity, ACT-); products, share classes, model portfolios, strategies and composites (01); accounts (15); flows, fund shareholder positions, snapshots and technical data feeds (06); institutional client profiles and service relationships after a win (12); retirement plans, recordkeeper profiles and plan roles (16); partner payment accounting (10), payables (19) and client fees (47); compliance reviews (08); executed contracts (39); employees (20); licensed datasets (14); campaigns and leads (04); proxy campaigns (13); competitor profiles (11)."),
  ("Structure", "Four levels: Data Domain > Data Family > Data Business Object > Data Business Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "A 02 Party holding an intermediary Party Role carries a Distributor Firm profile (with its Form ADV Profile), sits in Hierarchy Nodes, and has Branch / Office and Advisor Team profiles; an individual party carries a Financial Professional profile (the External Advisor, with Advisor Practice), Employment Affiliations to firms and offices and Team Memberships; vendors classify parties through External Classification; firm employees (20 EMP-) cover partners through Partner Coverage Assignment (PCVG-). Distribution Agreement (AGR-) is signed by Agreement Party Roles, runs under an Agreement Term, changes by Agreement Amendment, covers products, share classes and models (Agreement Product Coverage), is limited by Agreement Distribution Scope and governs accounts (Agreement Account Link to 15 ACC-); its executed copy is a 39 Contract. Payment Arrangement (PYA-) under an agreement is priced by Rate Schedules and Rate Tiers (and Sub-Accounting Fee Terms), calculated per period as Payment Calculation (PCL-; basis value read from 06), billed by Partner Invoice and settled by Partner Payment (PMT-); Intermediary Communication Fee Invoice (IFI-) bills proxy and shareholder communication processing (13 PRX-). Shelf Placement (SHF-) puts a share class on a partner list; Share Class Mapping sets the class per partner account type; Partner Research Rating records the gatekeeper's view; Model Program Placement puts a 01 model on a sponsor program and Model Delivery Event (MDEV-) records each delivery; Partner Program (PGM-) and Program Membership hold partner programs the firm joins. Partner Dealer Setup (with Networking Setup) and Partner Data Feed Arrangement hold the operating set-up; Distributor Due Diligence (DDQ-) with Due Diligence Findings, Agreement Obligations and Payment Disclosures hold the oversight record. Consultant Profile and Consultant Advisory Relationship describe consultants; Database Profile (DBS-) with Database Submissions and Consultant Rating record the firm's strategies in consultant databases. Sales Opportunity (OPP-) with Pipeline Status, Opportunity Value, Placement & Plan Detail and Win / Loss carries the pipeline; RFP Request (RFP-) with RFP Submission the questionnaires; a win hands over to a 05 Shelf Placement, or to 12 Mandate Onboarding, which references the won opportunity."),
  ("Design principles", "1) Profiles here, party core in 02 (CW-132, CD-143): every profile is a Business Object keyed by a '<role> Party' reference to the 02 party with the matching Party Role; no name, address, CRD, LEI or TIN is re-mastered, and identifiers the operating set-up needs are declared Derived copies of 02. 2) One activity master, three coverage records (CW-138): meetings and calls with partners and consultants are 03 Advisor Activity rows; Partner Coverage Assignment covers partners only; client coverage is 03 and servicing roles are 12. 3) Partner money is not client fees (CW-136): 05 holds what is owed to partners and under what terms; client fees are 47, fund expense terms 01, accounting 10 and payables 19. Platform, sub-accounting and networking fees are the reference default; Rule 12b-1 fees and revenue sharing are levers. 4) Model delivery is not discretionary management (CW-137): 05 records placement and delivery of 01 models; sponsor program accounts the firm manages are 15 accounts with 18 SMA Portfolio Detail traded in 25. 5) Separate the contract (agreement, term, scope), the money (arrangement, calculation, invoice, payment) and the shelf (placement, mapping, rating), each with its own effective dates. 6) Reference products, accounts, feeds, employees, contracts and compliance reviews by ID; the payment basis is a Derived copy of 06. 7) Every object states its PII tier; external advisors' professional data is personal data. 8) Flag Critical Data Elements (CDE)."),
  ("Applies To", "Shows the record each attribute belongs to: Distributor Firm, Form ADV, Hierarchy Node, Branch, Team, Team Membership, Gatekeeper, Advisor, Practice, Affiliation, Classification, Partner Coverage, Agreement, Agreement Party, Amendment, Product Coverage, Distribution Scope, Account Link, Payment Arrangement, Rate Schedule, Rate Tier, Payment Calculation, Partner Invoice, Partner Payment, Fee Invoice, Shelf Placement, Share Class Mapping, Research Rating, Model Placement, Model Delivery, Program, Program Membership, Dealer Setup, Networking Setup, Data Feed Arrangement, DD Case, Finding, Obligation, Disclosure, Consultant, Consultant Relationship, Database Profile, Database Submission, Rating, Opportunity, RFP."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify a partner, consultant, agreement, arrangement, placement or opportunity, to key a profile to its 02 party, to calculate or pay a partner fee correctly, to evidence a regulatory disclosure or the oversight of a distribution partner, to know whether a share class or model can be used through a partner, or to measure the pipeline. Confirm with data owners (Intermediary Distribution, Institutional Sales & Consultant Relations, Fund Treasurer, Transfer Agency Operations, Compliance)."),
  ("Primary / Secondary Reference", "Standard or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition (most commercial terms). Vendor and CRM references (Discovery Data, Broadridge, Cerulli, Nasdaq eVestment, Salesforce Sales Cloud) are cross-checks of common industry structure, not a license to reproduce their schemas. Next step: map each attribute to the rule paragraph, form item or source system field."),
  ("Notes", "PII = personal data under the GLBA, Regulation S-P and US state privacy laws. Each object's PII tier is stated in the Notes of its first attribute: 'PII - identity', 'PII - financial' or 'No PII'. External advisors, gatekeepers, team members, research analysts and plan advisors are individuals whose professional data is personal data (CW-150); the BrokerCheck disclosure event count is 'PII - restricted'. Partner commercial terms are confidential (Restricted - Commercial Terms) but not personal data. Scope is US only (CW-905): EU/UK distribution, inducement, retrocession, platform and dealing-network content of the wholesale 05 and of the restored 02, 03 and 08 objects is listed in the jurisdiction register; foreign instruments held in the firm's funds and models are kept."),
  ("Tabs", "Hierarchy: families, object groups and objects with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: object-level cardinalities, including references to other Data Domains | Sources: rules, standards and vendor sources used, with links."),
  ("Suggested next steps", "1) Validate families, objects and CDEs with Intermediary Distribution, Institutional Sales & Consultant Relations, the Fund Treasurer, Transfer Agency Operations, Legal and Compliance. 2) Confirm the depth of the intermediary channel (thin by default) and whether external advisors are held individually (SME questions). 3) Inventory current platform, sub-accounting and networking agreements and payment arrangements and load the top partners as a pilot. 4) Agree with 06 the basis data each Payment Calculation reads and the Distribution Channel re-cut (CW-139, CW-140, CW-164); with 03 the intermediary and institutional activity types (CW-138); with 12 the hand-over of won opportunities; with 16 the recordkeeper profiles and plan prospects; with 10 and 19 the accounting and payable of partner payments. 5) Map attributes to the CRM, the contract repository (39), the intermediary fee engine, the transfer agent dealer file, the consultant database calendar and the RFP tool. 6) Turn the Relationships tab into a logical data model."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

NOPII = "Object PII tier: No PII."
IDPII = "Object PII tier: PII - identity (professional data of an individual, CW-150)."

# ---------------------------------------------------------------------------
D("Intermediary Firms & Hierarchy", "DI-INT",
  "Role profiles of the intermediary firms that use the firm's funds, ETFs and models (broker-dealers, RIAs, bank and trust departments, platforms, TAMPs and third-party recordkeepers), their Form ADV sizing, hierarchy, branches, advisor teams and home-office gatekeepers. Each profile is keyed by the 02 party that holds the matching Party Role (CW-132).",
  [
   ("Distributor Firm Profile", "Commercial and regulatory profile of an intermediary firm that distributes or uses the firm's products, and its Form ADV sizing.", [
     ("Distributor Firm", [
       ("Distributor Firm Party", "02 party of the intermediary firm the profile belongs to; key of the profile. The party holds the 02 Party Role 'Distributor Firm'.", "Distributor Firm", "Reference (Party)", "", "PTY-100001", "Internal", "FIBO BE", "Y", NOPII + " Name, address, CRD, LEI and NSCC numbers stay in 02 (CD-143)."),
       ("Distribution Channel", "Channel the partner firm belongs to in the re-cut Distribution Channel list (CW-140, CW-164); 06 reads it as of the flow date to attribute IC flows and assets.", "Distributor Firm", "Code", "Distribution Channel", "Intermediary - RIA", "Internal", "Cerulli", "Y"),
       ("Firm Registration Type", "How the firm is registered to provide brokerage or advisory services, as shown in CRD and IAPD.", "Distributor Firm", "Code", "Firm Registration Type", "SEC-Registered Investment Adviser", "SEC Form ADV", "FINRA CRD", ""),
       ("Number of Registered Representatives", "Number of FINRA-registered representatives associated with the firm, from CRD or vendor data; sizes the partner for coverage.", "Distributor Firm", "Integer", "", "2450", "FINRA CRD", "Discovery Data", ""),
       ("Clearing Firm", "Clearing broker-dealer of an introducing firm, which settles the firm's fund and ETF trades.", "Distributor Firm", "Reference (Party)", "", "PTY-100780", "SEC Form BD", "", ""),
       ("Primary Custodian", "Third-party broker-dealer or bank that holds the client assets of an RIA partner (Form ADV Schedule D, Section 5.K(3)); the firm itself does not serve RIAs as their custodian (plan section 13).", "Distributor Firm", "Reference (Party)", "", "PTY-100912", "SEC Form ADV", "Discovery Data", ""),
       ("Product Platforms Offered", "Investment vehicles and programs the firm makes available to its advisors, which tells which of the firm's products it can use.", "Distributor Firm", "Code (multi)", "Platform Offering", "Mutual Funds; ETFs; Model Portfolios; UMA", "Internal", "Broadridge", ""),
       ("Firm Operating Model", "Degree of central home-office control over advisors' product and model selection, which decides whether gatekeepers or advisors are the target of coverage.", "Distributor Firm", "Code", "Firm Operating Model", "Centralized Research / Approved List", "Internal", "Cerulli", ""),
       ("Partner Status", "Lifecycle status of the firm's 'Distributor Firm' role, copied from 02 Party Role.Role Status so that partner reports filter on it without a join.", "Distributor Firm", "Code", "Record Status", "Active", "Internal", "", "", "Derived copy of 02 Party Role.Role Status (role 'Distributor Firm')."),
       ("Partner Since Date", "Date the party's 'Distributor Firm' role started, copied from 02 Party Role.Role Effective From.", "Distributor Firm", "Date", "ISO 8601", "2019-04-01", "Internal", "", "", "Derived copy of 02 Party Role.Role Effective From."),
     ]),
     ("Form ADV Profile", [
       ("Regulatory Assets Under Management", "Regulatory assets under management the partner reported in Form ADV Part 1A Item 5.F (Form ADV regulatory assets, not the firm's own Client Assets or AUM).", "Form ADV", "Amount", "", "USD 4,850,000,000", "SEC Form ADV", "FINTRX", "Y", NOPII + " Attribute group of Distributor Firm (RIA partners)."),
       ("Advisory Client Types", "Types of clients the adviser serves (Item 5.D).", "Form ADV", "Code (multi)", "External (SEC Form ADV Part 1A Item 5.D)", "High Net Worth Individuals; Pension and Profit Sharing Plans", "SEC Form ADV", "", ""),
       ("Compensation Arrangements", "How the adviser is compensated (Item 5.E).", "Form ADV", "Code (multi)", "External (SEC Form ADV Part 1A Item 5.E)", "A percentage of assets under your management; Fixed fees", "SEC Form ADV", "", ""),
       ("Form ADV Filing Date", "Date of the Form ADV filing (annual updating amendment or other-than-annual amendment) from which the profile was taken.", "Form ADV", "Date", "ISO 8601", "2026-03-28", "SEC Form ADV", "", ""),
     ]),
   ]),
   ("Firm Hierarchy", "The parent-child structure of a partner firm in each hierarchy the firm keeps (regulatory, operational, vendor). Each node is a 02 party in an intermediary role.", [
     ("Hierarchy Node", [
       ("Hierarchy Node Party", "02 party that is the node (firm, division, region, complex, branch or team); with the hierarchy type and effective date it keys the row. Legal ownership (parent group) is the 02 Legal Entity Hierarchy; 05 holds the distribution and operating structure.", "Hierarchy Node", "Reference (Party)", "", "PTY-100455", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Hierarchy Type", "Which hierarchy the node belongs to; a firm is often held in several hierarchies at once. Not the 10 Management Hierarchy Node (CW-159).", "Hierarchy Node", "Code", "Distributor Hierarchy Type", "Firm Operational", "Internal", "Broadridge", ""),
       ("Hierarchy Level", "Level of the node in the hierarchy.", "Hierarchy Node", "Code", "Hierarchy Level", "Branch / Office", "Internal", "Salesforce FSC", ""),
       ("Parent Node", "Hierarchy node (a partner party in the same hierarchy) that is the immediate parent of this node.", "Hierarchy Node", "Reference (Hierarchy Node, 05)", "", "PTY-100450", "Internal", "", ""),
       ("Node Effective From", "Date the node took its current place in the hierarchy.", "Hierarchy Node", "Date", "ISO 8601", "2024-01-01", "Internal", "", ""),
       ("Node Effective To", "Date the node left this place (closure, re-parenting, merger).", "Hierarchy Node", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Branch / Office", [
       ("Branch Party", "02 party of the partner's branch or office; key of the profile. The party holds the 02 Party Role 'Branch / Office'.", "Branch", "Reference (Party)", "", "PTY-100460", "Internal", "", "Y", NOPII + " A partner branch, never the firm's own branch office (03 Firm Branch Office)."),
       ("Branch CRD Number", "FINRA branch number registered for the location through Form BR, carried here to match vendor and order data to the branch.", "Branch", "Identifier", "", "712345 (fictitious)", "FINRA Form BR", "FINRA CRD", "Y", "Derived copy of the 02 party identifier (scheme FINRA CRD - Branch)."),
       ("Branch Type", "Regulatory and operational type of the location under FINRA Rule 3110 and Form BR.", "Branch", "Code", "Branch Type", "OSJ Branch", "FINRA Rule 3110", "FINRA Form BR", ""),
       ("Supervising OSJ", "Office of Supervisory Jurisdiction of the partner that supervises a non-OSJ branch.", "Branch", "Reference (Branch / Office, 05)", "", "PTY-100455", "FINRA Rule 3110", "", ""),
     ]),
     ("Advisor Team", [
       ("Advisor Team Party", "02 party of an external advisor team at a partner firm; key of the profile. The party holds the 02 Party Role 'Advisor Team'.", "Team", "Reference (Party)", "", "PTY-204500", "Internal", "Discovery Data", "Y", "Object PII tier: PII - identity (teams are often named after their advisors). The team name is the 02 Party Display Name; the lead is the Team Membership row with role Team Lead."),
       ("Team Rep Code", "Joint or split representative code under which the team's business is booked at the partner and delivered on orders and feeds; used by 06 to attribute flows to the team.", "Team", "Identifier", "", "J4K7", "Internal", "DTCC NSCC Fund/SERV", "Y", "PII."),
     ]),
     ("Team Membership", [
       ("Team", "Advisor team the member belongs to.", "Team Membership", "Reference (Advisor Team, 05)", "", "PTY-204500", "Internal", "Discovery Data", "", "Object PII tier: PII - identity (professional data of an individual, CW-150)."),
       ("Team Member", "External advisor who is a member of the team.", "Team Membership", "Reference (Financial Professional, 05)", "", "PTY-204511", "Internal", "", "Y", "PII."),
       ("Team Member Role", "Role of the member on the team.", "Team Membership", "Code", "Team Member Role", "Senior Partner", "Internal", "Discovery Data", "", "PII."),
       ("Team Membership Effective From", "Date the member joined the team.", "Team Membership", "Date", "ISO 8601", "2020-01-01", "Internal", "", "", "PII."),
       ("Team Membership Effective To", "Date the member left the team.", "Team Membership", "Date", "ISO 8601", "", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Home Office & Gatekeepers", "Central functions at partner firms that control product access, model and research decisions (gatekeepers).", [
     ("Gatekeeper Profile", [
       ("Gatekeeper Party", "02 party of the home-office individual or unit; key of the profile. The party holds the 02 Party Role 'Gatekeeper / Research'.", "Gatekeeper", "Reference (Party)", "", "PTY-784600", "Internal", "", "Y", IDPII + " No PII when the gatekeeper is a unit (organization party)."),
       ("Gatekeeper Function", "Home-office function the individual or unit performs.", "Gatekeeper", "Code", "Gatekeeper Function", "Manager Research / Due Diligence", "Internal", "Cerulli", "", "PII."),
       ("Asset Class Coverage", "Asset classes or vehicle types the gatekeeper covers, so the firm knows whom to approach for each product.", "Gatekeeper", "Code (multi)", "External (01 Asset Class)", "Fixed Income; Multi-Asset", "Internal", "", "", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("External Advisors & Coverage", "DI-FPR",
  "Profiles of external advisors (Financial Professional, the 'External Advisor'; bare 'advisor' is the firm's own, 03), their practices, firm affiliations and vendor classifications, and the coverage of partners, external advisors, consultants and third-party recordkeepers by the firm's employees (CW-138).",
  [
   ("External Advisor Profile", "Professional and registration profile of an external advisor, largely sourced from BrokerCheck, IAPD and vendors, and the business profile of the advisor's practice.", [
     ("Financial Professional", [
       ("Financial Professional Party", "02 individual party of the external advisor; key of the profile. The party holds the 02 Party Role 'Financial Advisor'.", "Advisor", "Reference (Party)", "", "PTY-301177", "Internal", "FIBO BE", "Y", IDPII + " Name, CRD number and contact points stay in 02."),
       ("Professional Type", "Type of external financial professional (registered representative, investment adviser representative, dually registered, plan advisor and so on).", "Advisor", "Code", "Professional Type", "Dually Registered (RR + IAR)", "FINRA CRD", "Discovery Data", "", "PII."),
       ("Professional Designations", "Professional credentials the advisor holds.", "Advisor", "Code (multi)", "External (03 Credential Type)", "CFP; CIMA", "Internal", "Discovery Data", "", "PII."),
       ("Qualification Exams", "FINRA and NASAA qualification examinations the advisor has passed, as shown on BrokerCheck.", "Advisor", "Code (multi)", "Qualification Exam", "SIE; Series 7; Series 66", "FINRA BrokerCheck", "", "", "PII."),
       ("Registration Status", "Current registration of the advisor in CRD and IAPD (broker-dealer, investment adviser, both, previously registered, barred).", "Advisor", "Code", "Advisor Registration Category", "Active - BD and IA", "FINRA CRD", "SEC IAPD", "Y", "PII."),
       ("Disclosure Events Count", "Number of disclosure events (customer disputes, regulatory actions, terminations) shown on BrokerCheck or IAPD; used only for distributor risk.", "Advisor", "Integer", "", "0", "FINRA BrokerCheck", "", "", "PII - restricted. Public data; restricted to Distributor Due Diligence and Compliance."),
     ]),
     ("Advisor Practice", [
       ("Business Model", "Business model of the external advisor's practice; a team practice is profiled on the team lead's Financial Professional.", "Practice", "Code", "Advisor Business Model", "Independent RIA Advisor", "Cerulli", "Discovery Data", "Y", "Object PII tier: PII - identity (professional data of an individual, CW-150). Attribute group of Financial Professional; practice assets are business data of the individual."),
       ("Practice AUM", "Total client assets the practice services (book size), a vendor estimate unless sourced from 06; not the firm's own Client Assets.", "Practice", "Amount", "", "USD 412,000,000", "Discovery Data", "Broadridge", "", "PII."),
       ("Number of Client Households", "Client households of the external practice (vendor count; not 02 Client Households).", "Practice", "Integer", "", "210", "Discovery Data", "", "", "PII."),
       ("Vehicle Usage", "Vehicles the practice uses materially, which tells whether it is a prospect for the firm's ETFs, models or CITs.", "Practice", "Code (multi)", "Platform Offering", "ETFs; Model Portfolios", "Broadridge", "Discovery Data", "", "PII."),
       ("Retirement Plan Practice Indicator", "Whether the advisor actively advises employer retirement plans (plan advisor), derived from Form 5500 Schedule C or vendor data.", "Practice", "Boolean", "", "Y", "DOL Form 5500", "Discovery Data", "", "PII."),
       ("Practice Data As-Of Date", "Date of the vendor or survey data used for the practice profile.", "Practice", "Date", "ISO 8601", "2026-06-30", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Employment & Affiliation", "Effective-dated firm-employs-advisor relationships, including advisor moves between firms.", [
     ("Employment Affiliation", [
       ("Affiliated Professional", "External advisor whose affiliation this is; with the firm and start date it keys the row.", "Affiliation", "Reference (Financial Professional, 05)", "", "PTY-301177", "FINRA CRD", "", "Y", "Object PII tier: PII - identity (professional data of an individual, CW-150)."),
       ("Employing Firm", "Partner firm the advisor is registered with or employed by.", "Affiliation", "Reference (Distributor Firm, 05)", "", "PTY-100001", "FINRA CRD", "", "Y", "PII."),
       ("Office of Record", "Partner branch or office the advisor works from.", "Affiliation", "Reference (Branch / Office, 05)", "", "PTY-100460", "FINRA Form BR", "", "", "PII."),
       ("Affiliation Type", "Nature of the advisor's association with the firm.", "Affiliation", "Code", "Affiliation Type", "Independent Contractor", "FINRA CRD", "", "", "PII."),
       ("Affiliation Start Date", "Date the advisor joined the firm.", "Affiliation", "Date", "ISO 8601", "2018-04-09", "FINRA CRD", "", "", "PII."),
       ("Affiliation End Date", "Date the advisor left the firm.", "Affiliation", "Date", "ISO 8601", "", "FINRA CRD", "", "", "PII."),
       ("Affiliation Change Reason", "Reason the advisor left or changed affiliation.", "Affiliation", "Code", "Affiliation Change Reason", "Breakaway to Independent RIA", "Discovery Data", "Internal", "", "PII."),
       ("Move Detected Date", "Date the firm first learned of the move (vendor alert, CRD change, transfer agent rep transfer).", "Affiliation", "Date", "ISO 8601", "2026-09-12", "Discovery Data", "", "", "PII."),
     ]),
   ]),
   ("Vendor Classification", "Classifications supplied by advisor-data and industry-research vendors, kept alongside the internal values.", [
     ("External Classification", [
       ("Classified Party", "02 party (partner firm, branch, team or external advisor) the vendor classified; with the vendor and as-of date it keys the row.", "Classification", "Reference (Party)", "", "PTY-301177", "Internal", "", "Y", IDPII + " No PII when the classified party is an organization."),
       ("Classification Vendor", "Vendor or research firm that supplied the classification.", "Classification", "Code", "Data Vendor", "Broadridge", "Internal", "", "", "PII."),
       ("Vendor Channel", "Channel the vendor assigns, mapped to the internal Distribution Channel.", "Classification", "Code", "External (Vendor)", "Hybrid RIA", "Discovery Data", "Broadridge", "", "PII."),
       ("Vendor Advisor Segment", "Vendor's advisor or practice segment (persona, propensity or opportunity segment); SM-00 reads it.", "Classification", "Code", "External (Vendor)", "Model Adopter - Growth", "Broadridge", "", "", "PII."),
       ("Vendor Classification As-Of Date", "Date of the vendor file the classification came from.", "Classification", "Date", "ISO 8601", "2026-08-31", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Partner Coverage", "Who at the firm covers each partner firm, external advisor, consultant and third-party recordkeeper (CW-138). Client and household coverage is 03 Party Coverage Assignment; servicing roles are 12 Service Coverage Assignment.", [
     ("Partner Coverage Assignment", [
       ("Partner Coverage Assignment ID", "Unique identifier of the coverage assignment.", "Partner Coverage", "Identifier", "", "PCVG-004512", "Internal", "", "Y", "Object PII tier: PII - identity (employee and, for external advisors, the covered individual)."),
       ("Covered Party", "02 party covered: a partner firm, branch, advisor team, external advisor, consultant or third-party recordkeeper; never a client or household (03).", "Partner Coverage", "Reference (Party)", "", "PTY-100001", "Internal", "Salesforce FSC", "Y", "PII when the covered party is an individual."),
       ("Covering Employee", "Firm employee who covers the party.", "Partner Coverage", "Reference (Employee)", "", "EMP-01177", "Internal", "", "Y", "PII (employee)."),
       ("Partner Coverage Role", "Role in which the employee covers the party (internal or external wholesaler, platform, consultant or recordkeeper relationship manager).", "Partner Coverage", "Code", "Partner Coverage Role", "Platform Relationship Manager", "Internal", "", "", "PII."),
       ("Primary Coverage Indicator", "Whether the employee is the primary coverage for the party in this role; 06 Salesperson Credit reads the primary row for IC and IA flows.", "Partner Coverage", "Boolean", "", "Y", "Internal", "", "", "PII."),
       ("Coverage Effective From", "Date the coverage started.", "Partner Coverage", "Date", "ISO 8601", "2026-01-01", "Internal", "", "", "PII."),
       ("Coverage Effective To", "Date the coverage ended.", "Partner Coverage", "Date", "ISO 8601", "", "Internal", "", "", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Selling & Platform Agreements", "DI-AGR",
  "The agreements between the firm and its distribution partners (selling, platform, sub-accounting and shareholder services, networking, Rule 22c-2 shareholder information, model provider, SMA sponsor, recordkeeper services, data sharing, co-marketing, authorized participant): parties, term, amendments, what they cover and the accounts they govern. The executed document is a 39 Contract (CD-257).",
  [
   ("Agreement Definition", "Core identity, type and status of a distribution agreement.", [
     ("Distribution Agreement", [
       ("Agreement ID", "Unique internal identifier of the agreement.", "Agreement", "Identifier", "", "AGR-004512", "Internal", "", "Y", "Object PII tier: No PII, except the employee reference (Business Owner)."),
       ("Agreement Name", "Business name of the agreement as used in the contract repository and partner reporting.", "Agreement", "Text", "", "Platform A - Fund Platform and Sub-Accounting Agreement 2024", "Internal", "", ""),
       ("Agreement Type", "Primary type of the agreement, which determines the terms and payment arrangements it can carry.", "Agreement", "Code", "Agreement Type", "Sub-Accounting / Shareholder Services Agreement", "Internal", "SEC IM Guidance 2016-01", "Y"),
       ("Master Agreement", "Master or framework agreement this agreement is a schedule of, such as a platform master agreement with product schedules.", "Agreement", "Reference (Agreement)", "", "AGR-000210", "Internal", "", ""),
       ("Agreement Status", "Current lifecycle status of the agreement.", "Agreement", "Code", "Agreement Status", "Active", "Internal", "", "Y"),
       ("Governing Law", "US state law that governs the agreement.", "Agreement", "Code", "Governing Law", "New York", "Internal", "", ""),
       ("Business Owner", "Employee accountable for the partner relationship and the agreement's commercial terms.", "Agreement", "Reference (Employee)", "", "EMP-01177", "Internal", "", "", "PII (employee)."),
       ("Most-Favored-Nation Clause Indicator", "Whether the partner has a most-favored-nation right on pricing or terms compared with peer partners.", "Agreement", "Boolean", "", "N", "Internal", "", ""),
       ("Exclusivity Indicator", "Whether the agreement grants or requires exclusivity (for example, sole model provider in a sleeve of a program).", "Agreement", "Boolean", "", "N", "Internal", "", ""),
       ("Distributor Due Diligence Reference", "Latest distributor due diligence review of the partner that supports the agreement.", "Agreement", "Reference (Distributor Due Diligence)", "", "DDQ-2026-00312", "Internal", "", ""),
       ("Executed Contract", "Contract record in the contract repository that holds the executed agreement, its exhibits and its retention (39).", "Agreement", "Reference (Contract)", "", "CTRCT-0041877", "Internal", "", ""),
     ]),
     ("Agreement Party Role", [
       ("Agreement Party", "Party that signs or is named in the agreement, from the 02 party master, including the firm's own contracting entities as parties.", "Agreement Party", "Reference (Party)", "", "PTY-100001", "Internal", "", "Y", "Object PII tier: No PII (organization parties). Signatories and notice contacts are held on the 39 Contract."),
       ("Agreement Party Role", "Role the party plays in the agreement.", "Agreement Party", "Code", "Agreement Party Role", "Platform Sponsor", "Internal", "FINRA Rule 2341", "Y"),
       ("Firm Contracting Entity Indicator", "Whether the party is one of the firm's own legal entities (principal underwriter, investment adviser, transfer agent, fund trust) rather than the partner.", "Agreement Party", "Boolean", "", "N", "Internal", "", ""),
       ("Party Role Effective From", "Date the party's role in the agreement started (for example, after an assignment).", "Agreement Party", "Date", "ISO 8601", "2024-04-01", "Internal", "", ""),
       ("Party Role Effective To", "Date the party's role in the agreement ended.", "Agreement Party", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Term, Renewal & Amendments", "When the agreement starts and ends, how it renews, and the effective-dated amendments that change it.", [
     ("Agreement Term", [
       ("Agreement Effective Date", "Date from which the agreement's terms apply.", "Agreement", "Date", "ISO 8601", "2024-04-01", "Internal", "", "Y", NOPII + " Attribute group of Distribution Agreement."),
       ("Term Type", "How the agreement's term is structured.", "Agreement", "Code", "Term Type", "Auto-Renewing", "Internal", "", ""),
       ("Initial Term End Date", "End date of the initial fixed term, if any.", "Agreement", "Date", "ISO 8601", "2027-03-31", "Internal", "", ""),
       ("Next Renewal Date", "Next date on which the agreement renews or expires unless action is taken.", "Agreement", "Date", "ISO 8601", "2027-04-01", "Internal", "", ""),
       ("Renewal Notice Period", "Days' notice required to prevent automatic renewal or to renegotiate.", "Agreement", "Integer", "Days", "90", "Internal", "", ""),
       ("Termination Notice Period", "Days' notice either party must give to terminate without cause.", "Agreement", "Integer", "Days", "60", "Internal", "", ""),
       ("Termination Date", "Date the agreement terminated or will terminate.", "Agreement", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Termination Reason", "Reason the agreement was terminated.", "Agreement", "Code", "Agreement Termination Reason", "Replaced by New Agreement", "Internal", "", ""),
     ]),
     ("Agreement Amendment", [
       ("Amendment ID", "Identifier of the amendment, side letter or replacement schedule (AGR-n-Ann), which dates each change to the agreement's terms.", "Amendment", "Identifier", "", "AGR-004512-A03", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Amendment Effective Date", "Date the amendment's changes take effect.", "Amendment", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
     ]),
   ]),
   ("Agreement Scope", "Which products, share classes and models the agreement covers, where and through which channels the partner may use them, and which accounts it governs.", [
     ("Agreement Product Coverage", [
       ("Covered Product", "Product included in or excluded from the agreement.", "Product Coverage", "Reference (Product)", "", "PRD-00981", "Internal", "", "", NOPII),
       ("Covered Share Class", "Share class included in or excluded from the agreement, where coverage is at share-class level.", "Product Coverage", "Reference (Share Class)", "", "SHC-004512", "Internal", "", "Y"),
       ("Covered Model Portfolio", "Model portfolio covered by a model provider or SMA sponsor agreement.", "Product Coverage", "Reference (Model Portfolio)", "", "MDL-0077", "Internal", "", ""),
       ("Covered Vehicle Types", "Vehicle types covered when coverage is expressed by vehicle type rather than by product (for example all ETFs).", "Product Coverage", "Code (multi)", "External (01 Vehicle Type)", "Exchange-Traded Fund", "Internal", "", ""),
       ("Inclusion Type", "Whether the line includes or excludes the product, share class or model.", "Product Coverage", "Code", "Inclusion Type", "Include", "Internal", "", ""),
       ("Coverage Effective From", "Date the product, share class or model came into scope.", "Product Coverage", "Date", "ISO 8601", "2024-04-01", "Internal", "", ""),
       ("Coverage Effective To", "Date the product, share class or model left scope.", "Product Coverage", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Agreement Distribution Scope", [
       ("Permitted Channels", "Distribution channels the agreement covers.", "Distribution Scope", "Code (multi)", "Distribution Channel", "Intermediary - Brokerage Platform; Intermediary - RIA", "Internal", "", "Y", NOPII + " Attribute group of Distribution Agreement. US only: no market, jurisdiction or EU/UK service model (CW-905)."),
       ("Permitted Jurisdictions", "US states and territories in which the partner may offer the products, where the agreement limits them (for example to states where the funds' notice filings are made); most agreements are nationwide and leave it blank.", "Distribution Scope", "Code (multi)", "ISO 3166-2:US", "US-NY; US-NJ; US-CT", "Internal", "", "", ""),
       ("Permitted Service Models", "Account programs (brokerage, fee-based advisory, discretionary, self-directed, retirement plan) in which the partner may use the products.", "Distribution Scope", "Code (multi)", "Account Eligibility", "Fee-Based Advisory; Self-Directed", "Internal", "SEC Reg BI", ""),
       ("Covered Account Types", "Account structures at the transfer agent the agreement applies to.", "Distribution Scope", "Code (multi)", "Account Structure", "Omnibus; Networked", "Internal", "SEC IM Guidance 2016-01", ""),
     ]),
     ("Agreement Account Link", [
       ("Linked Account", "Account (omnibus, networked group, plan or sponsor program account) governed by the agreement.", "Account Link", "Reference (Account)", "", "ACC-0091233", "Internal", "", "Y", NOPII + " Omnibus and program accounts; no end-client account is linked here."),
       ("Account Link Role", "Role the account plays under the agreement.", "Account Link", "Code", "Account Link Role", "Omnibus Trading Account", "Internal", "", ""),
       ("Account Link Effective From", "Date the account became governed by the agreement.", "Account Link", "Date", "ISO 8601", "2024-04-01", "Internal", "", ""),
       ("Account Link Effective To", "Date the account ceased to be governed by the agreement.", "Account Link", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Partner Payments", "DI-PAY",
  "The money owed to partners under the agreements: platform, sub-accounting, networking, omnibus processing, data and model marketplace fees, their rates, tiers and caps, the period calculations, partner invoices and payments, and the fees for distributing proxy and shareholder materials through intermediaries (CW-136, CW-088). Client fees are 47, fund expense terms 01, accounting 10 and payables 19.",
  [
   ("Payment Arrangement", "One payment stream agreed under an agreement, with its funding source, services compensated, caps and frequency (absorbs the wholesale Payment Terms and Payment Limit).", [
     ("Payment Arrangement", [
       ("Payment Arrangement ID", "Unique identifier of the payment arrangement.", "Payment Arrangement", "Identifier", "", "PYA-00871", "Internal", "", "Y", NOPII),
       ("Governing Agreement", "Agreement under which the payment is made.", "Payment Arrangement", "Reference (Agreement)", "", "AGR-004512", "Internal", "", "Y"),
       ("Payment Type", "Type of payment; platform, sub-accounting and networking fees are the reference default, revenue sharing and Rule 12b-1 service fees are levers (CW-136).", "Payment Arrangement", "Code", "Payment Type", "Sub-Accounting Fee - Per Account", "Internal", "ICI", "Y"),
       ("Payer Entity", "Legal entity that pays: the fund (within the board-approved cap), the investment adviser or the principal underwriter.", "Payment Arrangement", "Reference (Party)", "", "PTY-000012", "Internal", "", ""),
       ("Payee Entity", "Partner legal entity that receives the payment.", "Payment Arrangement", "Reference (Party)", "", "PTY-100001", "Internal", "", ""),
       ("Funding Source", "Source of the money: fund assets for non-distribution services such as sub-accounting, or the adviser's or distributor's own resources.", "Payment Arrangement", "Code", "Funding Source", "Fund - Non-Distribution Services", "SEC IM Guidance 2016-01", "SEC Rule 12b-1", "Y"),
       ("Services Compensated", "Services the payment is made for; decides whether a fund-paid amount is a non-distribution service fee or would need a distribution plan.", "Payment Arrangement", "Code (multi)", "Compensated Service", "Sub-Accounting / Recordkeeping; Shareholder Servicing", "SEC IM Guidance 2016-01", "", ""),
       ("Payment Arrangement Status", "Lifecycle status of the payment arrangement.", "Payment Arrangement", "Code", "Record Status", "Active", "Internal", "", ""),
       ("Arrangement Effective From", "Date from which the arrangement applies.", "Payment Arrangement", "Date", "ISO 8601", "2024-04-01", "Internal", "", ""),
       ("Arrangement Effective To", "Date the arrangement ends.", "Payment Arrangement", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Prospectus Disclosure Indicator", "Whether payments of this kind to intermediaries are described in the fund's current prospectus and statement of additional information (Form N-1A Item 8 and the SAI), which FINRA Rule 2341 requires for cash compensation to members.", "Payment Arrangement", "Boolean", "", "Y", "FINRA Rule 2341", "SEC Form N-1A", ""),
       ("Annual Payment Cap", "Maximum total payable under the arrangement in a cap year.", "Payment Arrangement", "Amount", "", "USD 1,500,000", "Internal", "", ""),
     ]),
   ]),
   ("Rates & Sub-Accounting Terms", "How the amount is calculated: basis, rate, tiers and the per-account sub-accounting terms with the fund-paid cap.", [
     ("Rate Schedule", [
       ("Calculation Basis", "Measure the rate is applied to.", "Rate Schedule", "Code", "Calculation Basis", "Per Account", "Internal", "ICI", "Y", NOPII),
       ("Base Rate", "Asset-based rate in basis points per annum, when there are no tiers or for the first tier; per-account amounts are Sub-Accounting Fee Terms.Per-Account Fee Amount.", "Rate Schedule", "Decimal", "Basis points", "12", "Internal", "", "Y"),
       ("Flat Fee Amount", "Fixed amount payable per period for flat-fee arrangements (platform access, data, model marketplace listing).", "Rate Schedule", "Amount", "", "USD 250,000", "Internal", "", ""),
       ("Tiering Method", "How tiers are applied.", "Rate Schedule", "Code", "Tiering Method", "Incremental", "Internal", "", ""),
       ("Rate Schedule Effective From", "Date the rate schedule applies from.", "Rate Schedule", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Rate Schedule Effective To", "Date the rate schedule ends.", "Rate Schedule", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Rate Tier", [
       ("Tier Lower Bound", "Inclusive lower bound of the tier in basis units (assets, accounts or participants).", "Rate Tier", "Decimal", "", "1000000000", "Internal", "", "", "Object PII tier: No PII."),
       ("Tier Sequence", "Order of the tier within the schedule; with the schedule it keys the tier (key registry primary key).", "Rate Tier", "Integer", "", "2", "Internal", "", "Y"),
       ("Tier Upper Bound", "Exclusive upper bound of the tier; blank for the top tier.", "Rate Tier", "Decimal", "", "5000000000", "Internal", "", ""),
       ("Tier Rate", "Rate applied within the tier.", "Rate Tier", "Decimal", "Basis points", "10", "Internal", "", "Y"),
     ]),
     ("Sub-Accounting Fee Terms", [
       ("Per-Account Fee Amount", "Annual fee per unit (account, fund shareholder account or participant).", "Payment Arrangement", "Amount", "", "USD 16.00", "Internal", "", "Y", "Object PII tier: No PII. Attribute group of Payment Arrangement; the unit is the Rate Schedule Calculation Basis (per account, per fund shareholder account or per participant)."),
       ("Fund-Paid Sub-TA Cap", "Maximum the fund may bear for sub-accounting services, in basis points of the assets serviced, as approved by the fund board; a per-account cap is held in the same 01 term as an amount.", "Payment Arrangement", "Decimal", "Basis points", "10", "SEC IM Guidance 2016-01", "", "Y", "Derived copy of the 01 fund fee term Fund-Paid Sub-TA Fee Cap (Management Fee group, with its Approving Board Resolution, 35); merge edit for 01 in proposals_w4_05.py NOTES."),
       ("Excess Borne by Adviser Indicator", "Whether any amount above the fund-paid cap is paid by the adviser or distributor from its own resources.", "Payment Arrangement", "Boolean", "", "Y", "SEC IM Guidance 2016-01", "", ""),
     ]),
   ]),
   ("Partner Payment Processing", "Period calculation of the amount due, the partner's invoice and the settled payment.", [
     ("Payment Calculation", [
       ("Calculation ID", "Unique identifier of the period calculation.", "Payment Calculation", "Identifier", "", "PCL-2026Q2-00871", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Calculated Arrangement", "Payment arrangement being calculated.", "Payment Calculation", "Reference (Payment Arrangement)", "", "PYA-00871", "Internal", "", ""),
       ("Calculation Period Start", "First day of the period.", "Payment Calculation", "Date", "ISO 8601", "2026-04-01", "Internal", "", ""),
       ("Calculation Period End", "Last day of the period.", "Payment Calculation", "Date", "ISO 8601", "2026-06-30", "Internal", "", ""),
       ("Basis Value", "Value of the calculation basis for the period (average assets, account count or participant count) as read from 06.", "Payment Calculation", "Decimal", "", "48250", "Internal", "", "Y", "Derived copy (06): Fund Shareholder Position look-through and data feed counts (CW-136)."),
       ("Basis Snapshot", "06 snapshot of flows and fund shareholder positions the basis value was read from.", "Payment Calculation", "Reference (Snapshot)", "", "SNP-2026-06-M-FINAL", "Internal", "", ""),
       ("Calculated Amount", "Amount due for the period after tiers, caps and true-ups.", "Payment Calculation", "Amount", "", "USD 193,000", "Internal", "", "Y"),
     ]),
     ("Partner Invoice", [
       ("Partner Invoice Number", "Invoice number assigned by the partner.", "Partner Invoice", "Identifier", "External (Partner-assigned)", "INV-WHA-2026-0712", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Invoicing Partner", "Partner that issued the invoice.", "Partner Invoice", "Reference (Party)", "", "PTY-100001", "Internal", "", ""),
       ("Invoiced Amount", "Total amount invoiced.", "Partner Invoice", "Amount", "", "USD 195,300", "Internal", "", "Y"),
       ("Invoice Status", "Status of the invoice in the review and approval workflow; the payable itself is 19.", "Partner Invoice", "Code", "Payable Invoice Status", "Disputed", "Internal", "", ""),
     ]),
     ("Partner Payment", [
       ("Partner Payment ID", "Unique identifier of the payment.", "Partner Payment", "Identifier", "", "PMT-2026-004411", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Payment Date", "Date the payment was made.", "Partner Payment", "Date", "ISO 8601", "2026-08-14", "Internal", "", "Y"),
       ("Payment Amount", "Amount disbursed to the partner by 19 for the invoices settled.", "Partner Payment", "Amount", "", "USD 193,000", "Internal", "", "Y"),
       ("Charged Entity", "Entity whose books bear the payment for the period; equals the arrangement's Payer Entity unless the excess above the fund-paid cap is borne by the adviser.", "Partner Payment", "Reference (Party)", "", "PTY-000012", "SEC IM Guidance 2016-01", "", ""),
       ("Payment Status", "Status of the payment as released and settled by 19.", "Partner Payment", "Code", "Outgoing Payment Status", "Paid / Settled", "Internal", "", ""),
       ("Invoices Settled", "Partner invoices settled by the payment, each keyed as invoicing partner / partner invoice number.", "Partner Payment", "Reference (Partner Invoice) (multi)", "", "PTY-100001 / INV-WHA-2026-0712", "Internal", "", ""),
     ]),
     ("Intermediary Communication Fee Invoice", [
       ("Fee Invoice ID", "Unique identifier of the invoice for forwarding proxy and shareholder materials to beneficial owners through intermediaries.", "Fee Invoice", "Identifier", "", "IFI-2026-00412", "Internal", "", "Y", "Object PII tier: No PII. Moved from 13 (CW-088)."),
       ("Invoicing Party", "Intermediary or its processing agent that issued the invoice.", "Fee Invoice", "Reference (Party)", "", "PTY-100800", "Internal", "", ""),
       ("Invoiced Campaign / Communication", "Proxy campaign or shareholder communication (annual report, prospectus or other issuer material) billed (13).", "Fee Invoice", "Reference (Proxy Campaign / Shareholder Communication)", "", "PRX-2026-004", "Internal", "", ""),
       ("Fee Type", "Fee component billed, in the FINRA Rule 2251 Supplementary Material .01 terms; drives the rate checked.", "Fee Invoice", "Code", "Intermediary Communication Fee Type", "Processing Unit Fee", "FINRA Rule 2251", "NYSE Rule 451", ""),
       ("Invoice Amount", "Total invoiced for the campaign or communication, checked against beneficial owner counts and the 2251.01 rates.", "Fee Invoice", "Amount", "", "USD 21,330.00", "Internal", "", "Y"),
       ("Fee Paid By", "Who bears the fee.", "Fee Invoice", "Code", "Cost Bearer", "Fund", "Internal", "", ""),
       ("Governing Agreement", "Agreement under which a negotiated rate applies, if any; otherwise the SRO rate schedule applies.", "Fee Invoice", "Reference (Agreement)", "", "AGR-000981", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Shelf, Programs & Model Delivery", "DI-SHF",
  "Whether and how the firm's share classes and models are available through each partner: shelf and list placement, share class mapping, partner research ratings, model program placement and each model delivery to a sponsor (CW-137), and the partner programs the firm joins.",
  [
   ("Shelf Placement", "Effective-dated status of a share class on a partner's platform shelf, approved list, recommended list or recordkeeper fund menu.", [
     ("Shelf Placement", [
       ("Shelf Placement ID", "Unique identifier of the placement record.", "Shelf Placement", "Identifier", "", "SHF-0193344", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Shelf Partner", "Partner on whose shelf or list the share class is placed.", "Shelf Placement", "Reference (Distributor Firm, 05)", "", "PTY-100001", "Internal", "", "Y"),
       ("Partner Platform / Program Name", "Platform, advisory program or list within the partner (a partner may run several).", "Shelf Placement", "Text", "", "Platform A Advisory Program", "Internal", "", ""),
       ("Placed Product", "Product placed, carried with the share class for product-level shelf reporting.", "Shelf Placement", "Reference (Product)", "", "PRD-00981", "Internal", "", ""),
       ("Placed Share Class", "Share class available under the placement; the product is read from the share class.", "Shelf Placement", "Reference (Share Class)", "", "SHC-004512", "Internal", "", "Y"),
       ("Shelf List Type", "Type of list or shelf.", "Shelf Placement", "Code", "Shelf List Type", "Recommended List", "Internal", "", ""),
       ("Placement Status", "Status of the share class on the list.", "Shelf Placement", "Code", "Placement Status", "Approved - Available", "Internal", "", "Y"),
       ("Placement Status Effective From", "Date the current status took effect.", "Shelf Placement", "Date", "ISO 8601", "2025-11-01", "Internal", "", ""),
       ("Placement Status Effective To", "Date the status ended.", "Shelf Placement", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Trade-Enabled Date", "Date the share class could first be traded on the partner platform.", "Shelf Placement", "Date", "ISO 8601", "2025-11-10", "Internal", "", ""),
       ("Eligible Account Types", "Partner account programs in which the share class may be held.", "Shelf Placement", "Code (multi)", "Account Eligibility", "Fee-Based Advisory; IRA", "Internal", "SEC Reg BI", ""),
       ("Model Eligibility Indicator", "Whether the share class may be used in partner-built or third-party models on the platform.", "Shelf Placement", "Boolean", "", "Y", "Internal", "", ""),
       ("Placement Opportunity", "Sales opportunity that tracked the pursuit of the placement.", "Shelf Placement", "Reference (Opportunity)", "", "OPP-2026-00871", "Internal", "", ""),
     ]),
     ("Share Class Mapping", [
       ("Mapping Partner", "Partner whose platform the mapping applies to.", "Share Class Mapping", "Reference (Distributor Firm, 05)", "", "PTY-100001", "Internal", "", "", "Object PII tier: No PII."),
       ("Mapped Account Type", "Partner account program the mapping applies to.", "Share Class Mapping", "Code", "Account Eligibility", "Fee-Based Advisory", "Internal", "SEC Reg BI", ""),
       ("Mapped Share Class", "Share class the partner uses for the account program.", "Share Class Mapping", "Reference (Share Class)", "", "SHC-004519", "Internal", "", "Y"),
       ("Default Share Class Indicator", "Whether this is the default class for the product and account program on the platform.", "Share Class Mapping", "Boolean", "", "Y", "Internal", "", ""),
       ("Share Class Conversion Eligible Indicator", "Whether fund shareholder accounts can be converted into this class on the platform (for example from a retail to an advisory class).", "Share Class Mapping", "Boolean", "", "Y", "Internal", "", ""),
     ]),
     ("Partner Research Rating", [
       ("Research Provider", "Partner research team or third-party gatekeeper that issued the rating.", "Research Rating", "Reference (Party)", "", "PTY-100390", "Internal", "", "", "Object PII tier: No PII."),
       ("Rated Product", "Product or strategy rated.", "Research Rating", "Reference (Product)", "", "PRD-00981", "Internal", "", ""),
       ("Normalized Research Rating", "Rating mapped to the firm's common scale for cross-partner reporting; the partner's own value is kept in the provider's report.", "Research Rating", "Code", "Normalized Research Rating", "Recommended", "Internal", "", "Y"),
       ("Rating Date", "Date the current rating was issued.", "Research Rating", "Date", "ISO 8601", "2026-05-20", "Internal", "", ""),
       ("Last Due Diligence Review Date", "Date of the partner's last due diligence meeting or review of the product.", "Research Rating", "Date", "ISO 8601", "2026-05-12", "Internal", "", ""),
       ("Next Scheduled Review Date", "Date of the partner's next scheduled review.", "Research Rating", "Date", "ISO 8601", "2027-05-01", "Internal", "", ""),
       ("Watch List Indicator", "Whether the product is on the partner's watch list.", "Research Rating", "Boolean", "", "N", "Internal", "", ""),
       ("DDQ Response Reference", "Due diligence questionnaire the firm answered for the partner's review (RFP Request of type DDQ or Home-Office Due Diligence).", "Research Rating", "Reference (RFP Request)", "", "RFP-2026-0422", "Internal", "", ""),
     ]),
   ]),
   ("Model & SMA Program Placement", "Placement of the firm's model portfolios on third-party sponsor programs and model marketplaces, and each delivery of a model to a sponsor (CW-137). Sponsor program accounts the firm manages are 15 accounts with 18 SMA Portfolio Detail traded in 25.", [
     ("Model Program Placement", [
       ("Sponsor Program Agreement", "Model provider or SMA sponsor agreement that governs the program; with the model it keys the placement.", "Model Placement", "Reference (Agreement)", "", "AGR-000412", "Internal", "", "", NOPII),
       ("Placed Model Portfolio", "Model portfolio placed on the program.", "Model Placement", "Reference (Model Portfolio)", "", "MDL-0077", "Internal", "", "Y"),
       ("Sponsor Program Type", "Type of sponsor program.", "Model Placement", "Code", "Sponsor Program Type", "UMA", "Internal", "", ""),
       ("Firm Role in Program", "Whether the firm delivers the model to the sponsor (model provider) or manages the sponsor program accounts (discretionary manager); must agree with the Agreement Type of the sponsor program agreement (Model Provider or SMA Sponsor Agreement).", "Model Placement", "Code", "External (Agreement Type of the Sponsor Program Agreement)", "Model Provider", "SEC Form ADV", "", ""),
       ("Program Minimum Account Size", "Minimum account size for the model in the program.", "Model Placement", "Amount", "", "USD 25,000", "Internal", "", ""),
       ("Model Placement Status", "Status of the model in the program.", "Model Placement", "Code", "Placement Status", "Approved - Available", "Internal", "", ""),
       ("Model Placement Effective From", "Date the status took effect.", "Model Placement", "Date", "ISO 8601", "2026-02-01", "Internal", "", ""),
     ]),
     ("Model Delivery Event", [
       ("Model Delivery Event ID", "Unique identifier of one delivery of a model to a sponsor.", "Model Delivery", "Identifier", "", "MDEV-20261005-000318", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Delivered Model Portfolio", "Model portfolio delivered.", "Model Delivery", "Reference (Model Portfolio)", "", "MDL-0077", "Internal", "", "Y"),
       ("Delivery Program Agreement", "Sponsor program agreement under which the model was delivered.", "Model Delivery", "Reference (Agreement)", "", "AGR-000412", "Internal", "", ""),
       ("Model Delivery Type", "Kind of delivery: initial model, rebalance or trade list, model change notice, or discontinuation notice.", "Model Delivery", "Code", "Model Delivery Type", "Rebalance / Trade List", "Internal", "", "Y"),
       ("Model Version As-Of Date", "As-of date of the model version (01) delivered.", "Model Delivery", "Date", "ISO 8601", "2026-10-02", "Internal", "", ""),
       ("Delivery Channel", "Channel through which the model or notice reached the sponsor (CW-137).", "Model Delivery", "Code", "Delivery Method", "SFTP File", "Internal", "", ""),
       ("Delivered Timestamp", "When the model file or notice reached the sponsor.", "Model Delivery", "Timestamp", "ISO 8601", "2026-10-05T13:05:00Z", "Internal", "", "Y"),
       ("Acknowledged Timestamp", "When the sponsor acknowledged receipt, if the program requires it.", "Model Delivery", "Timestamp", "ISO 8601", "2026-10-05T14:20:00Z", "Internal", "", ""),
     ]),
   ]),
   ("Partner Programs", "Partner-run programs the firm joins (strategic partner, platform preferred partner, education, conference, data and model marketplace programs) and its tier.", [
     ("Partner Program", [
       ("Program ID", "Unique identifier of the partner program.", "Program", "Identifier", "", "PGM-0042", "Internal", "", "Y", NOPII),
       ("Program Name", "Name of the program as the partner calls it.", "Program", "Text", "", "Platform A Preferred Partner Program 2026", "Internal", "", ""),
       ("Program Type", "Type of program.", "Program", "Code", "Program Type", "Platform Preferred Partner", "Internal", "", ""),
       ("Program Sponsor", "Partner that runs the program.", "Program", "Reference (Party)", "", "PTY-100001", "Internal", "", ""),
       ("Program Status", "Status of the program as the partner runs it; an ended program closes its memberships.", "Program", "Code", "Record Status", "Active", "Internal", "", ""),
     ]),
     ("Program Membership", [
       ("Member Program", "Program the firm participates in.", "Program Membership", "Reference (Partner Program)", "", "PGM-0042", "Internal", "", "", "Object PII tier: No PII."),
       ("Member Party", "Firm legal entity, as its 02 party, that holds the membership; with the program and start date it keys the membership.", "Program Membership", "Reference (Party)", "", "PTY-000012", "Internal", "", "Y"),
       ("Partner Tier", "Tier or level the firm holds in the program.", "Program Membership", "Code", "Partner Tier", "Tier 2 / Gold", "Internal", "", "Y"),
       ("Funding Agreement", "Agreement under which the program fees are paid.", "Program Membership", "Reference (Agreement)", "", "AGR-004512", "Internal", "", ""),
       ("Membership Effective From", "Start of the membership.", "Program Membership", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Membership Effective To", "End of the membership.", "Program Membership", "Date", "ISO 8601", "2026-12-31", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Partner Operations & Oversight", "DI-OPS",
  "The set-up needed to trade and service business with a partner (dealer, dealing route, account structure, networking level, data feeds) and the oversight record: distributor due diligence and findings, agreement obligations with their service levels, and disclosures of the payments partners receive.",
  [
   ("Dealer & Networking Setup", "Dealer and NSCC identification, dealing route, account structure and DTCC Networking level agreed with the partner (absorbs the wholesale Trading Setup). Order processing itself is 29.", [
     ("Partner Dealer Setup", [
       ("Dealer Setup Partner", "Partner firm the dealer set-up is for; key with the dealer number.", "Dealer Setup", "Reference (Distributor Firm, 05)", "", "PTY-100001", "Internal", "", "", "Object PII tier: No PII."),
       ("TA Dealer Number", "Dealer number assigned to the partner by the funds' transfer agent under the selling agreement.", "Dealer Setup", "Identifier", "", "D-004512", "DTCC NSCC Fund/SERV", "", "Y", "Derived copy of the 02 party identifier Transfer Agent Dealer Number."),
       ("NSCC Participant Number", "NSCC participant number the partner uses for Fund/SERV and Networking.", "Dealer Setup", "Identifier", "", "0457", "DTCC NSCC Fund/SERV", "", "Y", "Derived copy of the 02 party identifier."),
       ("Platform Participant ID", "Identifier the partner's platform or the transfer agent portal assigns to the firm or the partner for order and data exchange outside NSCC (key registry primary key with the TA dealer number).", "Dealer Setup", "Identifier", "External (Platform-assigned)", "PLT-A-00418", "Internal", "", ""),
       ("Dealer Setup Status", "Status of the dealer set-up.", "Dealer Setup", "Code", "Record Status", "Active", "Internal", "", ""),
       ("Dealer Setup Effective Date", "Date the set-up went live.", "Dealer Setup", "Date", "ISO 8601", "2024-04-15", "Internal", "", ""),
       ("Dealing Route", "Channel through which the partner sends orders to the transfer agent.", "Dealer Setup", "Code", "Dealing Route", "NSCC Fund/SERV", "DTCC NSCC Fund/SERV", "", "Y"),
       ("Account Structure", "How the partner's clients are held at the transfer agent (omnibus, networked, direct, plan-level).", "Dealer Setup", "Code", "Account Structure", "Omnibus", "SEC IM Guidance 2016-01", "", "Y"),
     ]),
     ("Networking Setup", [
       ("Networking Level", "DTCC Networking level agreed in the networking agreement as the default for the partner's new accounts; each account's actual level is mastered in 15.", "Networking Setup", "Code", "Networking Level", "Level 3", "DTCC NSCC Networking", "", "Y", "Object PII tier: No PII. Attribute group of Partner Dealer Setup."),
       ("Recordkeeping Responsibility", "Party that keeps the shareholder-level books and records for the accounts.", "Networking Setup", "Code", "Servicing Responsibility", "Intermediary", "DTCC NSCC Networking", "SEC IM Guidance 2016-01", ""),
       ("Rule 22c-2 Agreement in Place Indicator", "Whether an active Shareholder Information Agreement (Rule 22c-2) exists with the partner, derived from Distribution Agreement; held here for the networking set-up review, though the agreement is needed for omnibus accounts too (requests are 29).", "Networking Setup", "Boolean", "", "Y", "SEC Rule 22c-2", "", "Y"),
     ]),
     ("Partner Data Feed Arrangement", [
       ("Data Feed", "Feed delivered under the arrangement; technical feed definitions and loads are 06.", "Data Feed Arrangement", "Reference (Data Feed)", "", "FEED-012", "Internal", "", "Y", "Object PII tier: No PII. Feeds of advisor-level or account-level data are classified in 06 and 14; any data fee is a Payment Arrangement of type Data Fee under the governing agreement."),
       ("Governing Data Agreement", "Data sharing agreement under which the partner supplies the feed.", "Data Feed Arrangement", "Reference (Agreement)", "", "AGR-005130", "Internal", "", ""),
     ]),
   ]),
   ("Distributor Due Diligence", "Initial, periodic and event-driven review of a distribution partner (reduced, CW-135): risk rating, sanctions screening, regulatory status, questionnaire, controls report and outcome, with findings. Supervision of the firm's own representatives is 08.", [
     ("Distributor Due Diligence", [
       ("Due Diligence ID", "Unique identifier of the due diligence review.", "DD Case", "Identifier", "", "DDQ-2026-00312", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Distributor Firm", "Partner firm under review (its 05 Distributor Firm profile); firm details and identifiers stay in 02.", "DD Case", "Reference (Distributor Firm, 05)", "", "PTY-100001", "Internal", "", "Y"),
       ("Due Diligence Review Type", "Trigger of the review: initial onboarding, periodic or event-driven (CW-135).", "DD Case", "Code", "Partner Review Type", "Periodic", "Internal", "", ""),
       ("Residual Risk Rating", "Risk rating of the partner after its controls and the findings, which sets the depth and frequency of oversight.", "DD Case", "Code", "Risk Rating", "Low", "Internal", "", "Y"),
       ("Sanctions Screening Result", "Result of OFAC sanctions screening of the partner firm and its principals.", "DD Case", "Code", "Screening Result", "No Match", "OFAC", "", "Y"),
       ("Regulatory Status Verified Indicator", "Whether the partner's broker-dealer or adviser registration and disciplinary history were checked on BrokerCheck and IAPD.", "DD Case", "Boolean", "", "Y", "FINRA BrokerCheck", "SEC IAPD", ""),
       ("Questionnaire Received Date", "Date the completed due diligence questionnaire was received from the partner.", "DD Case", "Date", "ISO 8601", "2026-07-24", "Internal", "ICI", ""),
       ("SOC 1 Report Received Date", "Date the partner's SOC 1 Type 2 report (or FICCA report) on its sub-accounting controls was received.", "DD Case", "Date", "ISO 8601", "2026-02-10", "AICPA SOC 1", "SEC IM Guidance 2016-01", ""),
       ("Due Diligence Outcome", "Overall decision on the relationship.", "DD Case", "Code", "Due Diligence Outcome", "Approved with Conditions", "Internal", "", "Y"),
       ("Due Diligence Completed Date", "Date the review was completed and signed off.", "DD Case", "Date", "ISO 8601", "2026-08-15", "Internal", "", ""),
       ("Next Review Due Date", "Date the next periodic review is due, based on the risk rating.", "DD Case", "Date", "ISO 8601", "2027-08-15", "Internal", "", ""),
     ]),
     ("Due Diligence Finding", [
       ("Due Diligence Finding Key", "Key of the finding within the review (DDQ-n-Fnn), the name 08 and the key registry use.", "Finding", "Identifier", "", "DDQ-2026-00312-F03", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Finding Category", "Area the finding relates to.", "Finding", "Code", "DD Finding Category", "Rule 22c-2 / Market Timing Controls", "Internal", "", ""),
       ("Finding Severity", "Severity of the finding.", "Finding", "Code", "Severity", "Medium", "Internal", "", ""),
       ("Finding Description", "Description of the finding and the remediation agreed with the partner.", "Finding", "Text", "", "Omnibus trading data for Rule 22c-2 requests delivered after 20 business days; partner to automate the extract.", "Internal", "", ""),
       ("Remediation Status", "Status of the remediation.", "Finding", "Code", "Case Status", "In Progress", "Internal", "", ""),
     ]),
   ]),
   ("Obligations & Disclosures", "Obligations and service levels each party takes on under an agreement, and disclosures of the payments partners receive (Reg BI, prospectus and 408(b)(2) information).", [
     ("Agreement Obligation", [
       ("Obligation ID", "Unique identifier of the obligation.", "Obligation", "Identifier", "", "AGR-004512-OB07", "Internal", "", "Y", "Object PII tier: No PII. Absorbs the wholesale Service Level Agreement and SLA Measurement."),
       ("Obligation Category", "Category of the obligation.", "Obligation", "Code", "Obligation Category", "Data Delivery", "Internal", "", ""),
       ("Obligation Description", "What must be done, by whom and when.", "Obligation", "Text", "", "Partner delivers the monthly rep-level Omni/SERV sub-account file by business day 5", "Internal", "", ""),
       ("Obligation Compliance Status", "Current compliance status of the obligation.", "Obligation", "Code", "Obligation Status", "Met", "Internal", "", "Y"),
       ("SLA Target Value", "Service-level target the obligation must meet, where it is measured.", "Obligation", "Decimal", "", "98", "Internal", "", ""),
       ("Latest Measured Value", "Most recent measured performance against the target.", "Obligation", "Decimal", "", "96.2", "Internal", "", ""),
     ]),
     ("Payment Disclosure", [
       ("Disclosure Type", "Type of disclosure (absorbs the wholesale 408(b)(2) Compensation Disclosure).", "Disclosure", "Code", "Partner Disclosure Type", "DOL 408(b)(2) Indirect Compensation", "SEC Reg BI", "DOL 408(b)(2)", "Y", NOPII),
       ("Disclosing Party", "Party publishing or providing the disclosure (the partner, the fund or the firm).", "Disclosure", "Reference (Party)", "", "PTY-000012", "Internal", "", ""),
       ("Disclosed Arrangements", "Payment arrangements the disclosure covers.", "Disclosure", "Reference (Payment Arrangement) (multi)", "", "PYA-00871; PYA-00872", "Internal", "", ""),
       ("Disclosure Publication Date", "Date the current version was published or provided.", "Disclosure", "Date", "ISO 8601", "2026-01-31", "Internal", "", ""),
       ("Covered Service Provider", "Recordkeeper or other covered service provider to an ERISA plan that receives the indirect compensation and must disclose it under 408(b)(2).", "Disclosure", "Reference (Party)", "", "PTY-500003", "DOL 408(b)(2)", "", ""),
       ("Indirect Compensation Description", "Description of the indirect compensation, its payer, the services it relates to and its formula, as supplied to the covered service provider.", "Disclosure", "Text", "", "Sub-accounting fee of USD 12 per participant fund account paid by the fund within the board-approved cap", "DOL 408(b)(2)", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Consultant Relations & Databases", "DI-CON",
  "Profiles of the investment consultants and OCIO providers that advise institutions and plan sponsors, their advisory relationships, the firm's strategy profiles and submissions in consultant and industry manager databases, and the ratings consultants give the firm's strategies (IA line). Research meetings with consultants are 03 Advisor Activity rows (CW-138).",
  [
   ("Investment Consultants", "Consultants and OCIO providers that influence manager selection, and whom they advise.", [
     ("Consultant Profile", [
       ("Consultant Party", "02 party of the consulting firm; key of the profile. The party holds the 02 Party Role 'Investment Consultant / OCIO'.", "Consultant", "Reference (Party)", "", "PTY-100670", "Internal", "", "Y", NOPII),
       ("Consultant Type", "Business type of the consulting firm.", "Consultant", "Code", "Consultant Type", "Full-Service Investment Consultant", "Internal", "", ""),
       ("Assets Under Advisement", "Total client assets on which the consultant advises.", "Consultant", "Amount", "", "USD 1,200,000,000,000", "Internal", "SEC Form ADV", ""),
       ("Discretionary OCIO Assets", "Client assets the consultant manages on a discretionary (OCIO) basis.", "Consultant", "Amount", "", "USD 95,000,000,000", "SEC Form ADV", "", ""),
       ("Competing OCIO Indicator", "Whether the consultant also offers OCIO services that compete with the firm's institutional advisory offering.", "Consultant", "Boolean", "", "Y", "Internal", "", ""),
     ]),
     ("Consultant Advisory Relationship", [
       ("Consultant Firm", "Consulting firm advising the institution or plan; with the advised party and start date it keys the row.", "Consultant Relationship", "Reference (Consultant Profile, 05)", "", "PTY-100670", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Advised Client", "Institution, plan sponsor or retirement plan the consultant advises (12 Institutional Client or 02 Retirement Plan party).", "Consultant Relationship", "Reference (Party)", "", "PTY-301120", "Internal", "", ""),
       ("Consulting Engagement Type", "Nature of the consultant's engagement.", "Consultant Relationship", "Code", "Consulting Engagement Type", "Non-Discretionary General Consultant", "Internal", "", ""),
       ("Engagement Effective From", "Date the engagement started.", "Consultant Relationship", "Date", "ISO 8601", "2019-07-01", "Internal", "", ""),
       ("Engagement Effective To", "Date the engagement ended.", "Consultant Relationship", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Database Submissions", "Strategy profiles kept in consultant and industry manager databases and the periodic data submitted to them.", [
     ("Database Profile", [
       ("Database Profile ID", "Unique identifier of a strategy or product profile in an external manager database.", "Database Profile", "Identifier", "", "DBS-0456", "Internal", "", "Y", NOPII),
       ("Manager Database", "Database the profile is kept in.", "Database Profile", "Code", "Manager Database", "Nasdaq eVestment", "Nasdaq eVestment", "", ""),
       ("Linked Strategy / Product", "Strategy, product or vehicle the profile represents.", "Database Profile", "Reference (Strategy / Product)", "", "STR-00456", "Internal", "", "Y"),
       ("Linked GIPS Composite", "GIPS composite whose returns feed the profile (01).", "Database Profile", "Reference (Composite)", "", "CMP-0045", "GIPS", "", ""),
     ]),
     ("Database Submission", [
       ("Submission Period End", "Period-end date the submitted data relates to.", "Database Submission", "Date", "ISO 8601", "2026-06-30", "Nasdaq eVestment", "", "", NOPII + " Attribute group of Database Profile (one row per period end)."),
       ("Submitted Date", "Date the data was submitted.", "Database Submission", "Date", "ISO 8601", "2026-07-10", "Internal", "", ""),
       ("Submission Status", "Status of the submission.", "Database Submission", "Code", "Submission Status", "Submitted", "Internal", "", "Y"),
       ("Submission Compliance Review", "08 compliance review of the submitted performance and characteristics data.", "Database Submission", "Reference (Compliance Review)", "", "REV-2026-007690", "SEC Marketing Rule", "", ""),
     ]),
   ]),
   ("Consultant Ratings", "Manager research ratings consultants assign to the firm's strategies (partner research ratings are Partner Research Rating).", [
     ("Consultant Rating", [
       ("Rating Provider", "Consultant or research firm that assigned the rating.", "Rating", "Reference (Consultant Profile, 05)", "", "PTY-100670", "Internal", "", "", "Object PII tier: No PII."),
       ("Rated Strategy / Product", "Strategy or product rated.", "Rating", "Reference (Strategy / Product)", "", "STR-00456", "Internal", "", "Y"),
       ("Rating Type", "Kind of rating.", "Rating", "Code", "Consultant Rating Type", "Investment Rating", "Internal", "", ""),
       ("Rating Value", "Rating on the provider's own scale.", "Rating", "Code", "External (Vendor)", "A", "Internal", "", "Y"),
       ("Rating Date", "Date the rating or rating action took effect.", "Rating", "Date", "ISO 8601", "2026-05-20", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Pipeline & RFPs", "DI-PIP",
  "Business being pursued in the IA, IC and WR lines: institutional mandate and OCIO searches, intermediary shelf and model placements and plan sponsor recordkeeping prospects, with stage, value, placement or plan detail and outcome, and the RFP, RFI and DDQ requests and responses (CW-134). The direct-business funnel is 04; meetings are 03 Advisor Activity rows.",
  [
   ("Opportunity", "Identity, ownership, stage, value, placement or plan detail and outcome of an opportunity (absorbs Institutional Search Detail, Opportunity Product and Opportunity Competitor).", [
     ("Sales Opportunity", [
       ("Opportunity ID", "Unique identifier of the opportunity.", "Opportunity", "Identifier", "", "OPP-2026-00871", "Internal", "", "Y", "Object PII tier: No PII, except the employee reference (Opportunity Owner). Institutional, partner and plan sponsor prospects are organizations."),
       ("Opportunity Name", "Descriptive name of the opportunity.", "Opportunity", "Text", "", "State Teachers' RS - OCIO search", "Salesforce Sales Cloud", "", ""),
       ("Opportunity Type", "Kind of business pursued: institutional mandate or OCIO search, intermediary shelf or model placement, plan sponsor recordkeeping prospect, add-on or retention.", "Opportunity", "Code", "Opportunity Type", "OCIO Search", "Salesforce Sales Cloud", "", "Y"),
       ("Business Type", "Whether the opportunity is a new client, an expansion of an existing client or retention of existing assets.", "Opportunity", "Code", "Opportunity Business Type", "New Client", "Internal", "", ""),
       ("Opportunity Sales Channel", "Channel through which the business would be won.", "Opportunity", "Code", "Distribution Channel", "Institutional - OCIO", "Internal", "", "Y"),
       ("Opportunity Business Line", "Business line the opportunity belongs to (IA, IC or WR).", "Opportunity", "Code", "Business Line", "IA", "Internal", "", ""),
       ("Prospect / Client", "Party the business would be won from: an institution, a partner firm or platform, or a plan sponsor.", "Opportunity", "Reference (Party)", "", "PTY-204410", "Salesforce Sales Cloud", "", "Y"),
       ("Opportunity Owner", "Employee accountable for the opportunity.", "Opportunity", "Reference (Employee)", "", "EMP-00562", "Salesforce Sales Cloud", "", "", "PII (employee)."),
       ("Proposed Offering or Strategy", "Strategy or product proposed (01); share classes and models are named on Placement & Plan Detail.", "Opportunity", "Reference (Strategy / Product)", "", "STR-00456", "Salesforce Sales Cloud", "", ""),
       ("Search Consultant", "Investment consultant running or advising on the search, where there is one.", "Opportunity", "Reference (Consultant Profile, 05)", "", "PTY-100670", "Internal", "", ""),
       ("Originating Campaign", "Marketing campaign credited with sourcing the opportunity (04).", "Opportunity", "Reference (Campaign)", "", "CAM-004512", "Salesforce Sales Cloud", "", ""),
     ]),
     ("Pipeline Status", [
       ("Sales Stage", "Current stage of the opportunity in the sales process.", "Opportunity", "Code", "Sales Stage", "Finalist", "Salesforce Sales Cloud", "", "Y", NOPII + " Attribute group of Sales Opportunity."),
       ("Probability", "Likelihood of winning, defaulted from the stage and overridable by the owner.", "Opportunity", "Percentage", "", "50%", "Salesforce Sales Cloud", "", ""),
       ("Expected Close Date", "Date a decision is expected.", "Opportunity", "Date", "ISO 8601", "2026-11-30", "Salesforce Sales Cloud", "", ""),
       ("Expected Funding Date", "Date assets are expected to fund, or the first flow is expected, after a win.", "Opportunity", "Date", "ISO 8601", "2027-02-01", "Internal", "", ""),
     ]),
     ("Opportunity Value", [
       ("Expected Amount", "Expected assets or commitment to be won, in US dollars.", "Opportunity", "Amount", "", "USD 250,000,000", "Salesforce Sales Cloud", "", "Y", "Object PII tier: No PII. Attribute group of Sales Opportunity."),
       ("Expected Annual Revenue", "Expected annualized advisory, fund or recordkeeping fee revenue if won; an estimate, not 10's recognized revenue.", "Opportunity", "Amount", "", "USD 1,125,000", "Internal", "", ""),
       ("Actual Close Date", "Date the opportunity was closed as won or lost.", "Opportunity", "Date", "ISO 8601", "", "Salesforce Sales Cloud", "", ""),
     ]),
     ("Placement & Plan Detail", [
       ("Target Platform / Sponsor", "Partner home office, platform, TAMP or model sponsor where a placement is sought.", "Opportunity", "Reference (Distributor Firm, 05)", "", "PTY-100022", "Internal", "", "Y", "Object PII tier: No PII, except the Plan Advisor attribute (PII - identity when an individual). Attribute group of Sales Opportunity."),
       ("Placement Type", "Kind of placement sought, in the shelf list terms of the target.", "Opportunity", "Code", "Shelf List Type", "Recommended List", "Internal", "", ""),
       ("Target Model Portfolio", "Firm model the opportunity would place on a sponsor program (01).", "Opportunity", "Reference (Model Portfolio)", "", "MDL-0077", "Internal", "", ""),
       ("Retirement Plan", "Plan whose recordkeeping or fund menu is targeted (02 Retirement Plan party; 16 once recordkept).", "Opportunity", "Reference (Retirement Plan)", "", "PTY-560021", "Internal", "", ""),
       ("Plan Recordkeeper", "Incumbent recordkeeper of the target plan, or the third-party recordkeeper whose menu is targeted.", "Opportunity", "Reference (Recordkeeper Profile, 16)", "", "PTY-500003", "DOL Form 5500", "", ""),
       ("Plan Advisor", "Retirement plan advisor or consultant advising the plan sponsor.", "Opportunity", "Reference (Party)", "", "PTY-790144", "DOL Form 5500", "", "", "PII where the plan advisor is an individual."),
     ]),
     ("Win / Loss", [
       ("Opportunity Outcome", "Final outcome of the opportunity.", "Opportunity", "Code", "Opportunity Outcome", "Won", "Salesforce Sales Cloud", "", "Y", NOPII + " Attribute group of Sales Opportunity."),
       ("Primary Win / Loss Reason", "Main reason for the outcome.", "Opportunity", "Code", "Win Loss Reason", "Investment Performance", "Internal", "", ""),
       ("Winning Competitor", "Competitor that won where the outcome was a loss, as profiled in 11 (absorbs the wholesale Opportunity Competitor).", "Opportunity", "Reference (Competitor Profile)", "", "CPF-0112", "Internal", "", ""),
       ("Resulting Shelf Status Record", "Shelf placement created or updated as a result of a won intermediary placement.", "Opportunity", "Reference (Shelf Placement)", "", "SHF-0193344", "Internal", "", ""),
     ]),
   ]),
   ("RFP, RFI & DDQ", "Requests for proposal, information and due diligence received from institutions, consultants, partner home offices and plan sponsors, and the responses. Answer content stays in the RFP tool (SME question 7).", [
     ("RFP Request", [
       ("RFP ID", "Unique identifier of the request.", "RFP", "Identifier", "", "RFP-2026-0312", "Internal", "", "Y", NOPII),
       ("Request Type", "Kind of questionnaire (RFP, RFI, DDQ, consultant or home-office questionnaire, plan sponsor RFP), which sets the response workflow and compliance review.", "RFP", "Code", "Request Type", "RFP", "Internal", "", ""),
       ("Issuing Party", "Party that issued the request (institution, consultant, partner home office, plan sponsor).", "RFP", "Reference (Party)", "", "PTY-100670", "Internal", "", ""),
       ("Related Opportunity", "Opportunity the request belongs to.", "RFP", "Reference (Opportunity)", "", "OPP-2026-00871", "Internal", "", ""),
       ("Strategies in Scope", "Strategies or products the response covers.", "RFP", "Reference (Strategy / Product) (multi)", "", "STR-00456", "Internal", "", ""),
       ("Response Due Date", "Deadline for the response.", "RFP", "Timestamp", "ISO 8601", "2026-07-31T17:00:00-04:00", "Internal", "", ""),
       ("Request Status", "Current status of the response effort.", "RFP", "Code", "RFP Status", "In Progress", "Internal", "", "Y"),
     ]),
     ("RFP Submission", [
       ("Submission Timestamp", "Date and time the response was submitted.", "RFP", "Timestamp", "ISO 8601", "2026-07-30T16:20:00-04:00", "Internal", "", "", "Object PII tier: No PII. Attribute group of RFP Request."),
       ("Final Compliance Approval", "08 compliance review that approved the final response.", "RFP", "Reference (Compliance Review)", "", "REV-2026-007802", "SEC Marketing Rule", "FINRA Rule 2210", ""),
       ("Fee Proposal", "Fee proposed in the response, in basis points; the client fee schedule is 47 once won.", "RFP", "Decimal", "Basis points", "28", "Internal", "", ""),
       ("RFP Outcome", "Result of the response.", "RFP", "Code", "RFP Outcome", "Finalist", "Internal", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(value, description)])
# Copies of enterprise shared lists carry the shared list's exact name and labels (proposals_w4_05.py SHARED_MEMBERSHIPS).
# ---------------------------------------------------------------------------
CL = {
 # ---- copies of shared lists --------------------------------------------------------------------------------------
 "Distribution Channel": ("Shared list copy (steward 09; re-cut by CW-164, refined by CW-139 and CW-140; the DIRECT_ values are not used in 05)", [
   ("Workplace", "Participants in plans the firm recordkeeps (WR)"), ("Workplace - Recordkept Plan", ""),
   ("Institutional", ""), ("Institutional - Direct", "Institution deals with the firm without a consultant"),
   ("Institutional - Consultant-Led", "Search or relationship run through an investment consultant"), ("Institutional - OCIO", "Outsourced CIO relationship"),
   ("Intermediary", "Record known only at the intermediary level"), ("Intermediary - Wirehouse", ""),
   ("Intermediary - National / Regional Broker-Dealer", ""), ("Intermediary - Independent Broker-Dealer", ""),
   ("Intermediary - RIA", "Independent, hybrid and dually registered RIAs and family offices"),
   ("Intermediary - Bank / Trust", "Bank brokerage, trust departments and private banks"),
   ("Intermediary - TAMP / Model Marketplace", ""), ("Intermediary - Brokerage Platform", "Third-party brokerage and fund platforms, including RIA custodian platforms"),
   ("Intermediary - Third-Party Recordkeeper", "Own funds and CITs in plans recordkept by others (CW-139; was Retirement - DCIO)")]),
 "Qualification Exam": ("Shared list copy (steward 08): FINRA qualification examinations and NASAA Series 63 / 65 / 66", [
   ("SIE",""),("Series 6",""),("Series 7",""),("Series 9 / 10",""),("Series 24",""),("Series 26",""),("Series 63",""),("Series 65",""),("Series 66",""),("Series 99","")]),
 "Data Vendor": ("Local member list of shared Data Provider (steward 14)", [
   ("Discovery Data",""),("Broadridge",""),("FINTRX",""),("Cerulli Associates",""),("Morningstar",""),("Nasdaq eVestment",""),("Other","")]),
 "Record Status": ("Shared list copy (steward 09)", [
   ("Draft",""),("Proposed","Prospect or proposed record"),("Pending","Onboarding or set-up in progress"),("Active",""),("Paused","Restricted or suspended"),("Inactive",""),("Deprecated",""),("Retired","Terminated or closed")]),
 "Agreement Status": ("Shared list copy (steward 05)", [
   ("Draft",""),("In Negotiation",""),("Pending Signature",""),("Executed - Not Yet Effective",""),("Active",""),("Suspended","Payments or trading suspended pending remediation"),("Under Notice of Termination",""),("Terminated",""),("Expired",""),("Superseded","Replaced by a new agreement")]),
 "Governing Law": ("Shared list copy (steward 39), US values (CW-905)", [
   ("New York",""),("Delaware",""),("Massachusetts",""),("California",""),("Maryland",""),("Other","Another US state")]),
 "Delivery Method": ("Shared list copy (steward 09)", [("API",""),("SFTP File",""),("Platform Upload",""),("Via Data Vendor","")]),
 "Inclusion Type": ("Shared list copy (steward 09)", [("Include",""),("Exclude","")]),
 "Networking Level": ("Shared list copy (steward 15): DTCC NSCC Networking", [
   ("Level 0","Intermediary keeps all account records; the fund does not deal with the shareholder (commonly trust and plan accounts)"),
   ("Level 3","Firm-controlled: the intermediary handles customer contact, orders, statements and tax reporting"),
   ("Level 4","Fund-controlled: the intermediary processes orders; the fund provides statements and tax reporting"),
   ("Not Networked","Omnibus or direct")]),
 "Dealing Route": ("Shared list copy (steward 06), re-cut by CW-140", [
   ("NSCC Fund/SERV",""),("NSCC DCC&S","Defined contribution clearance and settlement"),("NSCC CNS / ETF Portal",""),
   ("TA Direct","Portal, file or manual instruction to the transfer agent"),("Recordkeeper File",""),("Sponsor File",""),
   ("Affiliated Broker-Dealer Omnibus","Orders from the firm's broker-dealer omnibus to its transfer agent (CW-140)")]),
 "Payable Invoice Status": ("Shared list copy (steward 19)", [("Received",""),("Matched",""),("Under Review",""),("Disputed",""),("Approved for Payment",""),("Paid",""),("Rejected",""),("Credited","")]),
 "Outgoing Payment Status": ("Shared list copy (steward 19)", [("Scheduled",""),("Released",""),("Paid / Settled",""),("Failed",""),("Reversed",""),("Canceled","")]),
 "Risk Rating": ("Shared list copy (steward 09)", [("Low",""),("Medium",""),("High",""),("Critical",""),("Prohibited","")]),
 "Screening Result": ("Shared list copy (steward 08)", [("No Match",""),("Potential Match - Under Review",""),("False Positive",""),("Confirmed Match","")]),
 "Severity": ("Shared list copy (steward 09)", [("Low",""),("Medium",""),("High",""),("Critical","")]),
 "Case Status": ("Shared list copy (steward 09)", [("New / Received",""),("In Progress",""),("Pending Third Party","Awaiting the partner"),("Escalated",""),("Resolved / Completed",""),("Closed",""),("Canceled","")]),
 "Business Line": ("Shared list copy (steward 09), CW-004", [
   ("DB","Direct brokerage and self-directed investing"),("DA","Digital advice"),("HA","Human and hybrid advice"),("PF","Proprietary funds and ETFs (including CITs)"),
   ("WR","Workplace retirement recordkeeping"),("IA","Institutional advisory"),("IC","Intermediary channel"),("TR","Personal trust services (optional)")]),
 # ---- local lists: intermediary firms and advisors -----------------------------------------------------------------
 "Firm Registration Type": ("SEC Form ADV / FINRA CRD", [
   ("Broker-Dealer (FINRA Member)",""),("SEC-Registered Investment Adviser",""),("State-Registered Investment Adviser",""),("Dual Registrant (BD + RIA)",""),
   ("Exempt Reporting Adviser",""),("Bank (Exempt)","Bank or trust company exempt from broker-dealer or adviser registration"),("Other / Unregistered","")]),
 "Platform Offering": ("Internal", [
   ("Mutual Funds",""),("ETFs",""),("SMA",""),("UMA",""),("Model Portfolios",""),("CITs",""),("Interval / Tender-Offer Funds",""),("Private / Alternative Funds",""),("Annuities","Partner shelf content; the firm offers none (CW-165)")]),
 "Firm Operating Model": ("Internal (Cerulli-style)", [
   ("Centralized Research / Approved List","Home office controls product access"),("Centralized Models","Home-office models hold most assets"),
   ("Advisor Discretion","Advisors select from a broad shelf"),("Outsourced (TAMP / OCIO)","")]),
 "Distributor Hierarchy Type": ("Internal", [
   ("Regulatory (CRD)","Firm and branch structure as registered"),("Firm Operational","Divisions, regions and complexes as the partner runs them"),
   ("Vendor - Broadridge",""),("Vendor - Discovery Data","")]),
 "Hierarchy Level": ("Internal", [("Firm",""),("Division / Home Office",""),("Region",""),("Complex / Market",""),("Branch / Office",""),("Team","")]),
 "Branch Type": ("FINRA Form BR / FINRA Rule 3110", [
   ("Main Office",""),("OSJ Branch","Office of Supervisory Jurisdiction"),("Non-OSJ Branch",""),("Non-Branch Location","For example a primary residence under Rule 3110(f)(2)(A)(ii)"),("Residential Supervisory Location","Non-branch location under Rule 3110.19 (Regulatory Notice 24-02)"),("RIA-Only Office","Investment adviser office not registered as a FINRA branch")]),
 "Team Member Role": ("Internal", [("Team Lead",""),("Senior Partner",""),("Partner",""),("Junior Advisor",""),("Client Service Associate",""),("Analyst / Portfolio Specialist","")]),
 "Gatekeeper Function": ("Internal", [
   ("Manager Research / Due Diligence",""),("CIO / Model Portfolio Management",""),("Product Management / Shelf",""),("Platform / Advisory Program Management",""),
   ("Retirement Plan Program",""),("Home Office Marketing / Sales Desk",""),("Operations / Product Onboarding","")]),
 "Professional Type": ("FINRA CRD / Internal", [
   ("Registered Representative",""),("Investment Adviser Representative",""),("Dually Registered (RR + IAR)",""),("Insurance Producer",""),
   ("Private Banker / Relationship Manager",""),("Trust Officer",""),("Plan Advisor",""),("Paraplanner / Associate","")]),
 "Advisor Registration Category": ("FINRA CRD / SEC IAPD (wholesale 02 'Registration Status', renamed at consolidation)", [
   ("Active - BD",""),("Active - IA",""),("Active - BD and IA",""),("Previously Registered",""),("Barred / Suspended","")]),
 "Advisor Business Model": ("Internal (Cerulli-style)", [
   ("Wirehouse FA",""),("Regional BD Advisor",""),("Independent BD Advisor",""),("Hybrid RIA Advisor",""),("Independent RIA Advisor",""),("Bank Advisor",""),
   ("Insurance Agent / Advisor",""),("Private Banker",""),("Retirement Plan Specialist","")]),
 "Affiliation Type": ("FINRA CRD", [("Employee",""),("Independent Contractor",""),("Investment Adviser Representative Only",""),("Outside Business Activity","")]),
 "Affiliation Change Reason": ("Internal", [
   ("Moved to Another Firm",""),("Breakaway to Independent RIA",""),("Joined Hybrid / Independent BD",""),("Team Lift-Out",""),("Firm Merger / Acquisition",""),
   ("Retirement",""),("Terminated",""),("Left Industry",""),("Deceased","")]),
 "Partner Coverage Role": ("Internal (CW-138)", [
   ("Internal Wholesaler","Inside sales coverage of external advisors"),("External Wholesaler","Field coverage of partner branches and external advisors"),
   ("Platform Relationship Manager","Home-office and platform coverage"),("Consultant Relations Manager",""),("Recordkeeper Relationship Manager","Third-party recordkeepers (CW-139)")]),
 # ---- local lists: agreements and payments --------------------------------------------------------------------------
 "Agreement Type": ("Internal (aligned to FINRA Rule 2341, SEC Rule 22c-2, SEC IM Guidance 2016-01, DOL 408(b)(2))", [
   ("Selling Agreement","Principal underwriter appoints a broker-dealer to sell the funds' shares (no-load; no dealer concession by default)"),
   ("Platform Agreement","Access to a brokerage, fund or advisory platform"),
   ("Sub-Accounting / Shareholder Services Agreement","Omnibus sub-accounting, recordkeeping and shareholder services"),
   ("Networking Agreement","DTCC Networking participation"),
   ("Shareholder Information Agreement (Rule 22c-2)","Lets the funds request shareholder trading data from the intermediary"),
   ("Model Provider Agreement","Delivery of the firm's models to a sponsor, TAMP or model marketplace"),
   ("SMA Sponsor Agreement","The firm as discretionary manager in a sponsor's SMA or UMA program"),
   ("Recordkeeper Services Agreement","Own funds and CITs on a third-party recordkeeper's platform (CW-139)"),
   ("Data Sharing Agreement","Supply of distribution data (fund shareholder positions, transactions, rep-level data) and its permitted use"),
   ("Co-Marketing Agreement","Joint marketing of the firm's ETFs or funds with a partner (04 campaigns)"),
   ("Authorized Participant Agreement","ETF creation and redemption with an authorized participant (29)"),
   ("Revenue Sharing Agreement","Lever (CW-136): payments from the adviser's own resources for distribution support; not the reference default")]),
 "Agreement Party Role": ("Internal (aligned to FINRA Rule 2341 and FIBO party roles)", [
   ("Principal Underwriter / Distributor","Firm's registered distributor"),("Fund / Trust",""),("Investment Adviser",""),("Transfer Agent",""),("Selling Dealer",""),("Clearing Firm",""),
   ("Platform Sponsor",""),("Sub-Transfer Agent / Servicer",""),("Recordkeeper",""),("SMA / UMA Sponsor",""),("Model Marketplace",""),("Authorized Participant",""),("Data Provider",""),("Data Recipient","")]),
 "Term Type": ("Internal", [("Fixed Term",""),("Auto-Renewing",""),("Evergreen","Continues until terminated on notice")]),
 "Agreement Termination Reason": ("Internal (wholesale 'Termination Reason', renamed at consolidation)", [
   ("Replaced by New Agreement",""),("Commercial Non-Renewal",""),("Partner Exit / Acquisition",""),("Product Closure",""),("Regulatory Change",""),("Breach",""),("Due Diligence Failure",""),("Mutual Agreement","")]),
 "Account Eligibility": ("Internal (aligned to SEC Reg BI account types; used as Code (multi): a fee-based IRA carries both Fee-Based Advisory and IRA)", [
   ("Brokerage",""),("Fee-Based Advisory",""),("Discretionary Advisory",""),("Self-Directed",""),("IRA",""),("Employer Retirement Plan",""),("SMA / Wrap",""),("UMA","")]),
 "Account Structure": ("Internal (SEC IM Guidance 2016-01)", [
   ("Omnibus","Single account at the transfer agent; the intermediary keeps the sub-accounts"),("Networked","Individual accounts at the transfer agent through DTCC Networking"),
   ("Fully Disclosed / Direct","Investor registered directly at the transfer agent"),("Plan-Level","Retirement plan omnibus")]),
 "Account Link Role": ("Internal", [("Omnibus Trading Account",""),("Networked Account Group",""),("Fee Billing Account",""),("Plan Account",""),("Sponsor Program Account","Account the firm manages in a sponsor program (15, CW-137)")]),
 "Payment Type": ("Internal (aligned to ICI / IDC and SEC staff terminology; CW-136)", [
   ("Platform Fee","Flat or asset-based fee for platform access"),("Sub-Accounting Fee - Per Account",""),("Sub-Accounting Fee - Asset-Based",""),
   ("Networking Fee","Per-account fee for networked accounts"),("Omnibus Processing Fee",""),("Data Fee",""),("Model Marketplace Fee",""),("Program / Sponsorship Fee","Partner program, conference and education sponsorship fees (FINRA Rule 2341(l)(5) non-cash compensation limits)"),
   ("Intermediary Communication Fee","Proxy and shareholder material forwarding (IFI-)"),
   ("Revenue Sharing","Lever: not the reference default"),("Rule 12b-1 Service Fee","Lever: the reference funds have no 12b-1 plans")]),
 "Funding Source": ("SEC IM Guidance 2016-01 / SEC Rule 12b-1 / Internal", [
   ("Fund - Non-Distribution Services","Fund-paid sub-accounting or shareholder servicing within the board-approved cap"),
   ("Adviser - Own Resources","Paid from the adviser's legitimate profits"),("Distributor - Own Resources","Paid by the principal underwriter"),
   ("Fund - Rule 12b-1 Plan","Lever: fund assets used to finance distribution under a written plan")]),
 "Compensated Service": ("SEC IM Guidance 2016-01 / Internal", [
   ("Shelf / Platform Access",""),("Sub-Accounting / Recordkeeping",""),("Shareholder Servicing",""),("Networking",""),("Data Provision",""),
   ("Model Marketplace Access",""),("Education / Training",""),("Communication Processing",""),("Distribution","Lever: distribution-related services")]),
 "Calculation Basis": ("Internal (aligned to ICI intermediary payment terminology)", [
   ("Average Daily Net Assets",""),("Month-End Assets",""),("Per Account",""),("Per Fund Shareholder Account","Each account and fund (CUSIP) combination"),("Per Participant",""),("Flat Fee",""),("Per Unit Processed","Communication sets, files or events")]),
 "Tiering Method": ("Internal", [("None",""),("Incremental","Each tier rate applies to the band of basis inside it"),("Cliff / Whole Balance","The rate of the tier reached applies to the whole basis")]),
 "Intermediary Communication Fee Type": ("FINRA Rule 2251 Supplementary Material .01 (NYSE Rule 451 secondary)", [
   ("Processing Unit Fee","Per set of materials sent"),("Intermediary Unit Fee","Paid to the intermediary that coordinates nominees"),("Intermediary Supplemental Fee","Per nominee, for nominees with fewer beneficial owners"),("Notice and Access Fee",""),("Preference Management Fee","Suppressed paper (e-delivery or householding)"),("NOBO List Fee",""),("Postage and Handling","Pass-through at actual cost")]),
 "Cost Bearer": ("Shared list copy (steward 13)", [("Fund",""),("Adviser",""),("Shared Fund / Adviser",""),("Service Provider",""),("Intermediary","")]),
 # ---- local lists: shelf, programs, models --------------------------------------------------------------------------
 "Shelf List Type": ("Internal", [
   ("Platform Shelf","Available to trade"),("Approved List",""),("Recommended List",""),("Focus List",""),("Model Eligible List",""),("Advisory Program Line-Up",""),
   ("Recordkeeper Fund Menu","Third-party recordkeeper's menu of available funds and CITs"),("Sell-Only / Hold List","")]),
 "Placement Status": ("Internal", [
   ("Proposed",""),("Under Review",""),("Approved - Pending Setup",""),("Approved - Available",""),("On Watch",""),("Closed to New Investors",""),("Restricted / Sell-Only",""),("Removed",""),("Declined","")]),
 "Normalized Research Rating": ("Internal", [("Recommended",""),("Approved",""),("Neutral / Hold",""),("Sell / Remove",""),("Not Rated","")]),
 "Sponsor Program Type": ("Internal", [("SMA - Single Contract / Wrap",""),("SMA - Dual Contract",""),("UMA",""),("Model Marketplace",""),("TAMP",""),("Fund / ETF Advisory Program","")]),
 "Model Delivery Type": ("Internal (CW-137)", [("Initial Delivery",""),("Rebalance / Trade List",""),("Model Change Notice","Allocation or constituent change"),("Discontinuation Notice","")]),
 "Program Type": ("Internal", [("Strategic Partnership",""),("Platform Preferred Partner",""),("Education / Practice Management",""),("Conference Sponsorship",""),("Data Partnership",""),("Model Marketplace Membership","")]),
 "Partner Tier": ("Internal", [("Tier 1 / Platinum",""),("Tier 2 / Gold",""),("Tier 3 / Silver",""),("Standard","")]),
 # ---- local lists: operations and oversight -------------------------------------------------------------------------
 "Partner Review Type": ("Internal (wholesale 05 'Review Type', renamed at consolidation; CW-135)", [("Initial","Onboarding review before the first agreement"),("Periodic","Annual or risk-based cycle"),("Event-Driven","Merger, regulatory action, complaint or SOC 1 exception")]),
 "Servicing Responsibility": ("DTCC NSCC Networking / Internal", [("Fund Transfer Agent",""),("Intermediary",""),("Shared","")]),
 "Due Diligence Outcome": ("Internal", [("Approved",""),("Approved with Conditions",""),("Restricted","Limited products or account programs"),("Suspended",""),("Terminated","")]),
 "DD Finding Category": ("Internal", [
   ("AML / Sanctions Controls",""),("Rule 22c-2 / Market Timing Controls",""),("Sub-Accounting Controls","Including the SOC 1 or FICCA exceptions"),("Complaints Handling",""),
   ("Compensation Disclosure","Reg BI and Form CRS disclosure of payments received"),("Marketing Material Use",""),("Data Protection and Cybersecurity",""),("Business Continuity",""),("Governance","")]),
 "Obligation Category": ("Internal", [
   ("Data Delivery",""),("Regulatory Reporting",""),("AML / CIP",""),("Rule 22c-2 Information",""),("Marketing Material Use",""),("Training",""),
   ("Confidentiality / Data Protection",""),("Insurance",""),("Audit Rights",""),("Notice",""),("Service Level","")]),
 "Obligation Status": ("Internal (wholesale 05 'Compliance Status')", [("Met",""),("Not Yet Due",""),("Overdue",""),("Breached",""),("Waived","")]),
 "Partner Disclosure Type": ("Internal (aligned to SEC Reg BI, FINRA Rule 2341, SEC Form N-1A, DOL 408(b)(2))", [
   ("Partner Compensation Disclosure","Partner's published list of payments received from fund sponsors (Reg BI)"),("Form CRS Conflicts Disclosure",""),
   ("Prospectus / SAI Intermediary Payments","Form N-1A Item 8 and SAI"),("DOL 408(b)(2) Indirect Compensation","")]),
 # ---- local lists: consultants and databases ------------------------------------------------------------------------
 "Consultant Type": ("Internal", [("Full-Service Investment Consultant",""),("OCIO / Fiduciary Manager",""),("Specialist Consultant","For example alternatives or DC"),("Retirement Plan Consultant",""),("Actuarial / Benefits Consultant","")]),
 "Consulting Engagement Type": ("Internal", [("Non-Discretionary General Consultant",""),("Discretionary OCIO",""),("Specialist / Asset-Class Consultant",""),("Manager Search Only",""),("DC Plan Consultant","")]),
 "Manager Database": ("Internal", [("Nasdaq eVestment","Also the input channel for Mercer manager research"),("Morningstar",""),("Callan",""),("Aon",""),("WTW",""),("Wilshire",""),("NEPC",""),("Meketa",""),("Cambridge Associates","")]),
 "Submission Status": ("Internal", [("Not Started",""),("In Preparation",""),("In Review",""),("Submitted",""),("Confirmed by Provider",""),("Late",""),("Rejected","")]),
 "Consultant Rating Type": ("Internal", [("Investment Rating",""),("ESG Rating",""),("Operational Due Diligence Rating",""),("Preferred Provider / Buy List","")]),
 # ---- local lists: pipeline and RFPs --------------------------------------------------------------------------------
 "Opportunity Type": ("Internal (CW-134, CW-139)", [
   ("Institutional Mandate Search","Consultant-led or direct search for a separate account or pooled vehicle (IA)"),("OCIO Search","Outsourced CIO search (IA)"),
   ("Intermediary Placement - Shelf","Shelf, approved or recommended list placement (IC)"),("Intermediary Placement - Model","Model placement on a sponsor program or marketplace (IC)"),
   ("Plan Sponsor Recordkeeping Prospect","Plan sponsor prospect for the firm's recordkeeping (WR)")]),
 "Opportunity Business Type": ("Internal", [("New Client",""),("Existing Client - Expansion",""),("Existing Client - Retention","")]),
 "Sales Stage": ("Internal (aligned to Salesforce StageName)", [
   ("Identified","10%"),("Qualified","20%"),("RFP / Due Diligence","30%"),("Shortlisted","40%"),("Finalist","50%"),("Selected / Verbal","80%"),("Contracting / Onboarding","90%"),
   ("Closed Won - Funded","100%"),("Closed Lost","0%"),("Closed Withdrawn","0%")]),
 "Opportunity Outcome": ("Internal", [("Won",""),("Lost",""),("Withdrawn by Client",""),("Withdrawn by Firm",""),("No Decision / Deferred","")]),
 "Win Loss Reason": ("Internal", [
   ("Investment Performance",""),("Investment Process / Philosophy",""),("Fees",""),("Team Stability",""),("Consultant Rating",""),("Brand / Firm Profile",""),
   ("Capacity / Vehicle Availability",""),("Recordkeeping Capability","Plan sponsor prospects (WR)"),("Relationship",""),("Client Strategy Change",""),("Operational / Servicing","")]),
 "Request Type": ("Internal", [
   ("RFP",""),("RFI",""),("DDQ","Investment due diligence questionnaire"),("Operational DDQ",""),("Consultant Questionnaire","Consultant research or database questionnaire"),
   ("Home-Office Due Diligence","Partner research team questionnaire"),("Plan Sponsor RFP","Recordkeeping or investment-only RFP from a plan sponsor (WR)")]),
 "RFP Status": ("Internal", [("Received",""),("Go / No-Go Review",""),("In Progress",""),("In Review",""),("Submitted",""),("Declined to Respond",""),("Closed","")]),
 "RFP Outcome": ("Internal", [("Pending",""),("Shortlisted",""),("Finalist",""),("Awarded",""),("Not Awarded",""),("Canceled by Issuer",""),("Withdrawn","")]),
}

# ---------------------------------------------------------------------------
# Relationships
# ---------------------------------------------------------------------------
REL = [
 ("Distributor Firm","is the profile of","Party (PTY-, 02) holding Party Role 'Distributor Firm'","1 : 1","CW-132; the party core stays in 02."),
 ("Form ADV Profile","describes","Distributor Firm","0..1 : 1","Attribute group; RIA partners."),
 ("Hierarchy Node","is child of","Hierarchy Node (Parent Node)","n : 0..1","Per hierarchy type: firm > division > region > complex > branch > team."),
 ("Branch / Office","is supervised by","Branch / Office (Supervising OSJ)","n : 0..1","FINRA Rule 3110."),
 ("Team Membership","links","Advisor Team to Financial Professional","n : 1 each","Effective-dated."),
 ("Financial Professional","is the profile of","Party (PTY-, 02) holding Party Role 'Financial Advisor'","1 : 1","The External Advisor; bare 'advisor' is 03."),
 ("Employment Affiliation","links","Financial Professional to Distributor Firm and Branch / Office","n : 1 each","History kept for advisor moves."),
 ("External Classification","classifies","Party (PTY-, 02)","n : 1","Per vendor and as-of date."),
 ("Partner Coverage Assignment","assigns","Employee (EMP-, 20) to a partner, external advisor, consultant or recordkeeper party (PTY-, 02)","n : 1 each","CW-138; clients are covered in 03 (CVA-), servicing roles in 12."),
 ("Distribution Agreement","is signed by","Agreement Party Role -> Party (PTY-, 02)","1 : 2..n","Firm contracting entity and at least one partner."),
 ("Distribution Agreement","is executed as","Contract (CTRCT-, 39)","1 : 0..1","CD-257; the document and its retention are 39."),
 ("Distribution Agreement","is a schedule of","Distribution Agreement (Master Agreement)","n : 0..1","Platform master agreements and schedules."),
 ("Distribution Agreement","is changed by","Agreement Amendment","1 : 0..n",""),
 ("Distribution Agreement","covers","Agreement Product Coverage -> Investment Product / Share Class / Model Portfolio (PRD- / SHC- / MDL-, 01)","1 : 1..n","Include and exclude lines, effective-dated."),
 ("Distribution Agreement","governs","Agreement Account Link -> Account (ACC-, 15)","1 : 0..n","Omnibus, networked, plan and sponsor program accounts."),
 ("Distribution Agreement","relies on","Distributor Due Diligence (DDQ-)","n : 0..1",""),
 ("Payment Arrangement","is made under","Distribution Agreement","n : 1",""),
 ("Payment Arrangement","is priced by","Rate Schedule -> Rate Tier","1 : 1..n",""),
 ("Payment Calculation","calculates","Payment Arrangement for a period","n : 1","One per period."),
 ("Payment Calculation","reads its basis from","Snapshot / Fund Shareholder Position / Data Feed (SNP- / POS- / FEED-, 06)","n : 1","Basis Value is a Derived copy (CW-136)."),
 ("Partner Invoice","bills","Payment Calculation","n : 1..n","No attribute: the invoice is matched to its calculations in 19."),
 ("Partner Payment","settles","Partner Invoice","n : 1..n","19 holds the payable and the disbursement; 10 books the cost."),
 ("Intermediary Communication Fee Invoice","bills","Proxy Campaign / Shareholder Communication (PRX- / COMM-, 13)","n : 1","CW-088."),
 ("Shelf Placement","places","Share Class (SHC-, 01) on a partner (PTY-, 02)","n : 1 each","One record per partner x platform x class x list type x status period."),
 ("Shelf Placement","was won through","Sales Opportunity (OPP-)","n : 0..1",""),
 ("Partner Research Rating","rates","Investment Product (PRD-, 01)","n : 1","Supported by an RFP Request of type DDQ."),
 ("Model Program Placement","places","Model Portfolio (MDL-, 01) on a sponsor program agreement (AGR-)","n : 1 each","CW-137."),
 ("Model Delivery Event","delivers","Model Portfolio (MDL-, 01) under a sponsor program agreement","n : 1 each","Discretionary sponsor accounts are 15 / 18 / 25."),
 ("Program Membership","is the firm's membership in","Partner Program (PGM-)","n : 1",""),
 ("Program Membership","is funded under","Distribution Agreement (Funding Agreement) and its Payment Arrangement","n : 1","Education meetings and sponsorship it involves are reviewed in 08 under the FINRA Rule 2341 non-cash compensation limits."),
 ("Partner Dealer Setup","is established for","Distributor Firm (PTY-)","n : 1","TA dealer and NSCC numbers are Derived copies of 02."),
 ("Networking Setup","describes","Partner Dealer Setup","0..1 : 1",""),
 ("Partner Data Feed Arrangement","delivers","Data Feed (FEED-, 06)","1 : 1","Governed by a data sharing agreement."),
 ("Due Diligence Finding","is raised by","Distributor Due Diligence","n : 1",""),
 ("Agreement Obligation","is imposed by","Distribution Agreement","n : 1",""),
 ("Payment Disclosure","discloses","Payment Arrangement","n : n","Includes 408(b)(2) information supplied to recordkeepers (16 profile)."),
 ("Consultant Advisory Relationship","links","Consultant Profile to an institution or plan (12 Institutional Client, 02 Retirement Plan)","n : 1 each","12 Service Relationship.Advising Consultant reads it."),
 ("Database Profile","represents","Investment Strategy / GIPS Composite (STR- / CMP-, 01)","n : 1",""),
 ("Database Submission","is reviewed by","Compliance Review (REV-, 08)","n : 0..1","SEC Marketing Rule."),
 ("Consultant Rating","rates","Investment Strategy / Product (STR- / PRD-, 01)","n : 1",""),
 ("Sales Opportunity","is pursued with","Party (PTY-, 02) and owned by Employee (EMP-, 20)","n : 1 each","Meetings are 03 Advisor Activity rows (ACT-)."),
 ("Sales Opportunity","was sourced by","Campaign (CAM-, 04)","n : 0..1",""),
 ("Placement & Plan Detail","targets","Retirement Plan (02) and its recordkeeper (16 Recordkeeper Profile)","n : 0..1 each","Plan sponsor prospects (WR, CW-139)."),
 ("Win / Loss","results in","Shelf Placement (SHF-)","1 : 0..1","Won intermediary placement."),
 ("Partner Invoice / Partner Payment","is recorded as","Payable Invoice / Supplier Payment (19)","1 : 1","19 holds the payable and the disbursement; 19 matches each invoice to its payment calculations."),
 ("Sales Opportunity","is referenced by","Mandate Onboarding (12) via Mandate Onboarding.Won Opportunity","1 : 0..1","Won institutional, OCIO and plan sponsor clients; the link is held on the 12 side (12 review ruling)."),
 ("Win / Loss","names","Competitor Profile (CPF-, 11)","n : n","11 Mandate Search Event.Linked Opportunity reads OPP-."),
 ("RFP Request","belongs to","Sales Opportunity","n : 0..1",""),
 ("RFP Submission","is approved by","Compliance Review (REV-, 08)","1 : 1",""),
]

# ---------------------------------------------------------------------------
# Sources: (source, owner, url, license, coverage, used_in, [primary_ref labels])
# ---------------------------------------------------------------------------
SRC = [
 ("FINRA Rule 2341 Investment Company Securities, paragraphs (l)(4), (l)(5) and (d)(4)","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2341","Rule (public)","(l)(4) cash compensation must be described in the prospectus; (l)(5) non-cash compensation limits (training and education meetings, sponsorship); (d)(4) a fund is no-load with no sales charge and asset-based sales and service charges of 0.25% or less, so a service fee lever would keep the funds no-load","Prospectus Disclosure Indicator, Agreement Party Role, Program Type (non-cash compensation)",["FINRA Rule 2341"]),
 ("SEC Division of Investment Management Guidance Update 2016-01: Mutual Fund Distribution and Sub-Accounting Fees","US SEC","https://www.sec.gov/investment/im-guidance-2016-01.pdf","Staff guidance (public)","Board oversight of sub-accounting fees, distribution in guise, fund-paid caps, payments by the adviser from its own resources","Funding Source, Services Compensated, Sub-Accounting Fee Terms, Account Structure, Charged Entity",["SEC IM Guidance 2016-01"]),
 ("SEC Rule 22c-2 (17 CFR 270.22c-2)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/subchapter-A/part-270/section-270.22c-2","Regulation (public)","Shareholder information agreements with financial intermediaries","Rule 22c-2 Agreement in Place Indicator, Agreement Type, DD Finding Category",["SEC Rule 22c-2"]),
 ("SEC Regulation Best Interest (17 CFR 240.15l-1) and Form CRS","US SEC","https://www.sec.gov/rules/final/2019/34-86031.pdf","Regulation (public)","Broker-dealer disclosure and mitigation of conflicts, including payments received from fund sponsors; retail account types","Partner Disclosure Type, Account Eligibility",["SEC Reg BI"]),
 ("SEC Form N-1A (Item 8, Financial Intermediary Compensation; SAI)","US SEC","https://www.sec.gov/files/form-n-1a.pdf","Form (public)","Prospectus and SAI disclosure of payments to intermediaries","Prospectus Disclosure Indicator (secondary), Partner Disclosure Type",[]),
 ("DOL ERISA section 408(b)(2) service provider fee disclosure (29 CFR 2550.408b-2)","US Department of Labor (EBSA)","https://www.law.cornell.edu/cfr/text/29/2550.408b-2","Regulation (public)","Covered service provider disclosure of direct and indirect compensation, payer, services and formula","Payment Disclosure (Covered Service Provider, Indirect Compensation Description)",["DOL 408(b)(2)"]),
 ("SEC Form ADV Part 1A (Items 5.D, 5.E, 5.F; Schedule D 5.K) and IAPD","US SEC","https://www.sec.gov/about/forms/formadv-part1a.pdf","Form (public; confirm the PDF path)","Regulatory assets under management, client types, compensation, custodians of RIA client assets","Form ADV Profile, Firm Registration Type, Primary Custodian, Program Role",["SEC Form ADV","SEC IAPD"]),
 ("FINRA CRD, BrokerCheck and Form BR","FINRA","https://brokercheck.finra.org","Public register","Firm and individual registration status, qualification examinations, disclosure events, branch registration","Financial Professional, Employment Affiliation, Branch / Office, Regulatory Status Verified Indicator",["FINRA CRD","FINRA BrokerCheck","FINRA Form BR"]),
 ("FINRA Rule 3110 Supervision, paragraphs (f)(1), (f)(2) and Supplementary Material .19","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110","Rule (public)","OSJ (f)(1) and branch office (f)(2) definitions, the primary-residence exclusion (f)(2)(A)(ii) and residential supervisory locations (.19)","Branch Type, Supervising OSJ",["FINRA Rule 3110"]),
 ("SEC Form BD","US SEC","https://www.sec.gov/files/formbd.pdf","Form (public)","Introducing and clearing arrangements of broker-dealers","Clearing Firm",["SEC Form BD"]),
 ("DTCC NSCC Fund/SERV, Networking and Omni/SERV","DTCC","https://www.dtcc.com/wealth-management-services/mutual-fund-services","Participant documentation (some public)","Fund order routing and settlement; Networking levels and servicing responsibilities; omnibus sub-account data","Dealing Route, Networking Level, Servicing Responsibility, TA Dealer Number, NSCC Participant Number, Team Rep Code",["DTCC NSCC Fund/SERV","DTCC NSCC Networking"]),
 ("FINRA Rule 2251 (Supplementary Material .01 fee schedule), with NYSE Rule 451 secondary","FINRA; NYSE","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2251","SRO rules (public)","Reasonable reimbursement for forwarding proxy and other issuer materials to beneficial owners and the named fees","Intermediary Communication Fee Invoice",["FINRA Rule 2251"]),
 ("ICI / IDC: Navigating Intermediary Relationships (2022)","Investment Company Institute / Independent Directors Council","https://www.idc.org/files/2022/22-ppr-navigating-intermediary-relationships.pdf","Free","Taxonomy of intermediary payments (sub-accounting, platform, networking, revenue sharing) and board oversight practice","Payment Type, Calculation Basis, Account Fee Unit, Questionnaire Received Date",["ICI"]),
 ("ICI Financial Intermediary Controls and Compliance Assessment (FICCA) framework (2014 and 2015 updates; confirm current version) and AICPA SOC 1 (SSAE 18) reports","ICI; AICPA","https://ici.org/pubfile_pdf/ppr_16_ficca.pdf (confirm)","Free framework; AICPA attestation standards","Controls reports on intermediary sub-accounting relied on in distributor oversight","SOC 1 Report Received Date, DD Finding Category",["AICPA SOC 1"]),
 ("OFAC sanctions lists","US Treasury","https://ofac.treasury.gov","Public","Sanctions screening of partner firms and principals","Sanctions Screening Result",["OFAC"]),
 ("DOL Form 5500 and Schedule C (EFAST2)","US Department of Labor (EBSA)","https://www.dol.gov/agencies/ebsa/employers-and-advisers/plan-administration-and-compliance/reporting-and-filing/form-5500","Public filings","Plan service providers, recordkeepers and plan advisors of prospect plans","Retirement Plan Practice Indicator, Plan Recordkeeper, Plan Advisor",["DOL Form 5500"]),
 ("Nasdaq eVestment data collection","Nasdaq","https://www.nasdaq.com/solutions/evestment/global-database/data-collection-process","Licensed (free for manager submission)","Institutional manager database; periodic data collection; Mercer manager research data collected through eVestment","Database Profile, Database Submission, Manager Database",["Nasdaq eVestment"]),
 ("GIPS Standards","CFA Institute","https://www.gipsstandards.org","Free","Composites behind database profiles and RFP performance","Linked GIPS Composite",["GIPS"]),
 ("SEC Marketing Rule (Advisers Act Rule 206(4)-1)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.206(4)-1","Regulation (public)","Third-party ratings and performance in adviser marketing, including RFP and database content","Submission Compliance Review, Final Compliance Approval",["SEC Marketing Rule"]),
 ("FINRA Rule 2210 Communications with the Public","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2210","Rule (public)","Institutional communications and broker-dealer use of ratings","Secondary reference on ratings and RFP approval",[]),
 ("Salesforce Sales Cloud object reference (Opportunity, OpportunityCompetitor)","Salesforce","https://developer.salesforce.com/docs/atlas.en-us.object_reference.meta/object_reference/sforce_api_objects_opportunity.htm","Proprietary documentation (free to read; confirm path)","Standard CRM opportunity fields, stages and probability","Sales Opportunity, Pipeline Status, Opportunity Value, Win / Loss",["Salesforce Sales Cloud"]),
 ("Discovery Data, Broadridge Distribution Insight, FINTRX and Cerulli Associates","Vendors","https://www.discoverydata.com","Licensed","Advisor, team and firm channel, practice and move data; channel and practice research","Distributor Firm, Advisor Practice, External Classification, Data Vendor",["Discovery Data","Broadridge","Cerulli","FINTRX"]),
 ("FIBO Business Entities","EDM Council","https://spec.edmcouncil.org/fibo/","Open standard","Party and party-in-role concepts behind the role profiles","Profile keys",[]),
]
