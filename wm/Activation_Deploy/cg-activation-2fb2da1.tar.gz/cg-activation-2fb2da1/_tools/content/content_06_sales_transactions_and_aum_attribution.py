"""Data Domain 06 - Client Assets, Flows & Channel Attribution (wealth-manager reference model; adapts the wholesale 06 Sales
Transactions & AUM Attribution in place, CW-141; L1 code TX kept). Content module for taxonomy_builder.py."""

META = {
 "title": "Client Assets, Flows & Channel Attribution Data Taxonomy",
 "subtitle": "Business domain 06 - Client Assets, Flows & Channel Attribution | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-15",
 "output": "06_Sales_Transactions_and_AUM_Attribution/Sales_Transactions_and_AUM_Attribution_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the client asset, flow and channel attribution data of a US wealth manager that serves investors directly: self-directed brokerage, digital and human advice, its own mutual funds, ETFs and CITs, workplace retirement recordkeeping, institutional advisory, a thin intermediary channel and optional personal trust services. It produces the firm's headline numbers: how much clients hold at the firm (Client Assets), how much new money came in (Net New Assets), how much of it is advised (Advised Assets), through which channel, business line, offering, advisor, campaign, plan, institution or intermediary, and how much market movement changed it; and, for the own funds, gross sales, redemptions and net flows by share class across every channel. The source facts live in five books of record (49 Client Holdings and account activity, 50 Money Movements, 29 the fund share register, 16 participant balances and plan activity, 18 institutional portfolios) and in intermediary feeds; 06 conforms, summarizes, attributes and certifies them and never masters a Client Holding or Portfolio Holding (CW-007, CW-011, CW-141). Flow definitions follow ICI and Morningstar; intermediary processing follows DTCC/NSCC Fund/SERV, Networking, Omni/SERV and DCC&S and ISO 20022; account transfers follow FINRA Rule 11870 (ACATS); rollovers follow IRC sections 402(c) and 408(d)(3); Client Assets are distinguished from Form ADV regulatory assets under management."),
  ("Scope", "In scope (mastered here): the conformed flow record (Transaction, TXN-, glossary name Flow Transaction) for every external flow into or out of a client account and every own-fund purchase or redemption, with its typed source link; Fund Shareholder Positions (POS-) and Account Asset Summaries as views of the books of record; the intermediary look-through, ETF holdings by DTC participant, third-party recordkept plan positions and sponsor-reported assets as delivered; Account Channel Assignment (CHASG-), the effective-dated channel of every account; attribution of flows and assets (ATR-) to channel, business line, offering, firm advisor, client household, campaign, plan, institutional client, consultant and intermediary hierarchy, with salesperson credit for the IC and IA lines, overrides (OVR-) and unattributed items; the certified Client Assets, Net New Assets and Advised Assets families and the fund flow measures (MSR-), their treatment rules, values, snapshots (SNP-) and restatements (RSM-); identity resolution and rep matching for intermediary data (XWK-, MRL-); data feeds (FEED-) and loads (LOAD-); reconciliations (RCN-) and breaks (BRK-) of 06 data to its sources. Out of scope (referenced by ID only): client holdings, tax lots, cost basis, cash and sweep balances, account activity and account transfers (49: CLHLD-, CLACT-, ACXF-); money movements (50: MMVMT-); the share register, register postings and fund orders (29: RGTX-, FNDO-, ECR-); participant memberships, contributions and distributions (16: PMEM-, CONT-, DIST-); institutional portfolio valuation and capital activity (18: PORT-); accounts and program enrollments (15: ACC-, ENRL-); parties and households (02: PTY-, PTY-HH-); products, share classes, models and service offerings (01: PRD-, SHC-, MDL-, OFFR-); the share class NAV (27: NAV-); firm advisors and their coverage of clients (03: CVA-); campaigns and attribution weights (04: CAM-); intermediary firms, financial professionals, partner coverage and agreements (05: PCVG-, AGR-); institutional clients (12); employees (20: EMP-); metric registration (21); Firm AUM (27, 46, 18; never computed here); client returns (32); revenue (10)."),
  ("Nature of the data", "Transactions, positions, asset summaries and measure values are high-volume transactional and time-series data. This taxonomy does not hold values; it defines their structure (grain, keys, dates, measures) and the reference attributes and code lists that describe them, so that every book of record and feed maps to one model."),
  ("Structure", "Four levels: Data Domain > Data Family > Data Business Object > Data Business Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Books of record, one flow book per account book (49 Client Account Activity for brokerage, managed and trust accounts, with 50 money movements only through their 49 posting; 29 Register Transaction for direct registered accounts; 16 Participant Ledger Posting for participant accounts; 18 Portfolio Capital Activity for IA mandates) and intermediary Data Feeds (FEED-) -> Load (LOAD-) -> Transaction (TXN-), a Derived copy of the source record's type, date and amount plus flow classification, or mastered as delivered for intermediary rows. 49 Client Holding and 29 Share Register Balance -> Fund Shareholder Position (POS-, own funds only; 49 rows at the 49 valuation, register rows at the 27 NAV; each row's Aggregation Role says whether it is counted); 49 Client Holding Valuation and Account Cash Balance, 16 Participant Balance, 18 Portfolio Holding and the Fund Shareholder Position -> Account Asset Summary (firm client account x as-of date x holding type). 15 Account, Program Enrollment, 16 plan membership and 05 agreements -> Account Channel Assignment (CHASG-), one channel per account at a time; a change generates an Inter-Channel Transfer transaction (the account's assets on the last day of the old channel), never Net New Assets. Attribution Record (ATR-) splits each transaction, fund shareholder position or account asset summary across channel, business line, offering, firm advisor (03 coverage as of the flow date), client household, campaign and weight (04), plan, institutional client (12), consultant and the intermediary hierarchy (05), and credits IC salespeople from 05 Partner Coverage Assignment and IA direct relationship managers from 03 Party Coverage Assignment. Measure Definitions (MSR-CLIENTASSETS, MSR-NNA, MSR-ADVISEDASSETS, MSR-AVGCLIENTASSETS and the fund flow measures) aggregate attributed facts into Measure Values keyed by measure x period end x dimension type x dimension key, held in locked Snapshots, reconciled to the books and restated under governance."),
  ("Design principles", "1) 06 summarizes, never masters a Client Holding or Portfolio Holding: no tax lot, cost basis, cash balance or client holding quantity is mastered here; every Derived row names the book it copies (CW-007, CW-122, CW-141). 2) Three books are named distinctly: Portfolio Holding (18), Client Holding (49), Fund Shareholder Position (06). 3) Client Assets, Net New Assets and Advised Assets are defined once, here, with explicit treatment rules; Firm AUM is not defined here and the own-fund overlap is reported, never netted (CW-011, CW-142). 4) Channel is an effective-dated property of the account. 5) Keep as-delivered intermediary codes alongside resolved IDs; identity resolution applies only where the firm does not own the key (CW-144). 6) Every attribution carries a method and confidence; estimated and allocated amounts are never mixed silently with actuals; unattributed amounts are held in suspense. 7) Month-end results are snapshotted and locked; changes after lock are restatements. 8) Reference parties, accounts, products, advisors, campaigns and partners by ID; do not copy their attributes. 9) Every object states its PII tier. 10) Flag Critical Data Elements (CDE)."),
  ("Applies To", "Shows the record type at which each attribute is held: Transaction, Fund Shareholder Position, Account Asset Summary, Channel Assignment, Measure Definition, Measure Value, Attribution Record, Unattributed Item, Override, Identifier Crosswalk, Match Rule, Feed, Load, Reconciliation, Break, Snapshot or Restatement."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify a flow, fund shareholder position or account asset summary, compute a certified Client Assets, Net New Assets, Advised Assets or fund flow measure, assign a channel, attribute assets to an advisor, campaign or intermediary (and therefore drive incentive compensation in 03), or reconcile to the books of record. Confirm with data owners (Client & Channel Analytics, Finance, Brokerage Operations, Transfer Agency, Retirement Services)."),
  ("Primary / Secondary Reference", "Standard or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Several sources (DTCC record layouts, aggregator data dictionaries) are member- or license-restricted, so attribute names are aligned to their public descriptions; map to exact field IDs during implementation."),
  ("Notes", "PII = personal information under the GLBA, Regulation S-P and US state privacy laws. Each object's PII tier is stated in the Notes of its first attribute: 'PII - identity', 'PII - financial' or 'No PII'. Transaction, Fund Shareholder Position and Account Asset Summary are account-level client data (PII - financial); products read them in aggregate except for authorized client views (CW-150). Row Ownership Rules (CD-289) say which rows of an attribute are Derived copies of a book of record and which are mastered here."),
  ("Tabs", "Hierarchy: families, object groups and objects with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: object-level cardinalities, including references to other Data Domains | Sources: standards, rules and data sources used, with links."),
  ("Suggested next steps", "1) Ratify the Client Assets, Net New Assets and Advised Assets definitions and the Flow Treatment Rule defaults with Finance and Client & Channel Analytics, and register them in 21. 2) Map each book of record (49, 50, 29, 16, 18) and each intermediary feed to Transaction, Fund Shareholder Position and Account Asset Summary, with the source references set. 3) Load Account Channel Assignment from 15 account types and enrollments, 16 plan memberships and 05 agreements, and test that every account has exactly one channel per day. 4) Agree with 03 the as-of-date advisor attribution, with 04 the campaign weights and with 05 the partner coverage used for salesperson credit. 5) Build the reconciliations of Account Asset Summary totals to 49, 16 and 18, and of intermediary feeds to the 29 register. 6) Publish the own-fund overlap to the Client Assets and Firm AUM reconciliation product (successor of DP-241)."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

_RR_FLOW = ("Row rule (CW-141, CD-289): on rows whose Flow Source Book is 49, 50, 29, 16 or 18 this is a Derived copy of the source "
            "record named in Order Source, one flow book per account book (49 Client Account Activity for brokerage, managed and trust "
            "accounts; 29 Register Transaction for direct registered accounts; 16 Participant Ledger Posting for participant accounts; 18 "
            "Portfolio Capital Activity for IA mandates; 06 Account Channel Assignment for inter-channel transfers); mastered here, as "
            "delivered, on intermediary-feed rows.")
_RR_AGG = ("Row rule (program-lead ruling on the 06 review, CD-289): Counted - Firm Client Account = 49 rows (brokerage, managed, trust) and 29 rows of "
           "direct registered accounts (Fund-Only, Institutional Direct); Counted - Intermediary = Networked register rows and "
           "intermediary look-through rows (Omnibus Look-Through, ETF Holding at external DTC participants, Plan Position); Excluded - "
           "Omnibus or Nominee = Broker-Dealer Omnibus, DTC Nominee, Intermediary Omnibus aggregate and Plan Omnibus register rows (control "
           "only: Broker-Dealer Omnibus units = sum of 49 Client Holdings); Excluded - Firm Proprietary = seed and error accounts; "
           "Attribution Only = Sponsor-Reported Assets. CIT Unitholder rows count only for unitholders that are firm client accounts.")
_RR_AAS = ("Row rule (CW-141, CD-289): computed here on every row by summing the book named in Summary Source Book; never edited here, "
           "restated only by re-deriving from the source. Firm client accounts only; intermediary assets are never summarized here.")
_RR_POS = ("Row rule (CW-122, CW-141, CD-289): brokerage and managed accounts are a Derived copy of 49 Client Holding (Source Client "
           "Holding set); every other registered account (fund-only, broker-dealer omnibus, intermediary omnibus, networked, plan "
           "omnibus, DTC nominee, CIT unitholder) is a Derived copy of 29 Share Register Balance (Source Share Register Balance set), "
           "valued at the 27 Share Class NAV; mastered here, as delivered, only on intermediary look-through rows.")

# ---------------------------------------------------------------------------
D("Transactions", "TX-TRN",
  "Flow transactions (glossary name Flow Transaction, CW-141): every external flow into or out of a client account (cash deposits and withdrawals, ACATS and other account transfers, journals, rollovers, plan contributions and distributions, mandate funding and withdrawals, fee debits) and every purchase, redemption, exchange or reinvestment in the firm's own funds, conformed from the books of record (49, 50, 29, 16, 18) and from intermediary feeds. The activity itself stays in its book: 49 Client Account Activity, 50 Money Movement, 29 Register Transaction and Fund Order, 18 Portfolio Transaction.",
  [
   ("Transaction Core", "Identity, type, flow scope, holding and account of a flow transaction.", [
     ("Transaction", [
       ("Transaction ID", "Unique identifier of the conformed flow record after load and de-duplication.", "Transaction", "Identifier", "", "TXN-2026-000418273", "Internal", "", "Y", "Object PII tier: PII - financial (account-level client flow). Glossary name Flow Transaction (CW-141); object name and key kept for their readers."),
       ("Source Transaction Reference", "Identifier of the flow in the delivering book or feed (49 activity number, 50 movement number, 29 register posting number, recordkeeper or Fund/SERV control number).", "Transaction", "Identifier", "", "FS2026091800017734", "DTCC Fund/SERV", "ISO 20022", "", "De-duplication key: Flow Source Book + Source Transaction Reference is unique; a second load of the same source record is a new version of the row, never a new flow."),
       ("Source Feed", "Data feed from which the flow was received.", "Transaction", "Reference (Feed)", "", "FEED-003", "Internal", "", ""),
       ("Transaction Type", "Normalized business type of the flow, from cash deposit or ACATS transfer to own-fund purchase or rollover.", "Transaction", "Code", "Transaction Type", "ACATS Transfer In", "ICI", "FINRA Rule 11870", "Y", _RR_FLOW),
       ("Source Transaction Code", "Transaction code exactly as delivered by the source book or feed, retained for lineage and re-mapping.", "Transaction", "Code", "External (Source system)", "TA2000 'Purchase - New Money'", "SS&C DST", "", ""),
       ("Flow Direction", "Whether the flow adds to, removes from or is neutral to the account's assets.", "Transaction", "Code", "Flow Direction", "Inflow", "Internal", "", "", _RR_FLOW),
       ("Flow Scope", "Which measure family the flow feeds: client asset measures (an external flow of a firm client account, counted in Net New Assets), fund flow measures (an own-fund purchase or redemption), both, or an inter-channel transfer between two firm accounts or two channels of one account (never Net New Assets).", "Transaction", "Code", "Flow Scope", "Client Asset and Fund Flow", "Internal", "", "Y", "Journals and re-registrations between firm accounts in different channels are Inter-Channel Transfer whatever the owner; Same-Owner Indicator governs only the firm-wide figure."),
       ("Holding Type", "Kind of asset moved by the flow (cash, an own or third-party fund, or a security type), which drives the holding-type split of Net New Assets.", "Transaction", "Code", "Holding Type", "Own ETF", "Internal", "", "Y"),
       ("Share Class", "Own-fund share class transacted or moved; blank for cash and for holdings that are not own funds.", "Transaction", "Reference (Share Class)", "", "SHC-004512", "Internal", "", "Y"),
       ("Product", "Product of the share class, or the model or strategy for sponsor-program flows; derived from 01.", "Transaction", "Reference (Product)", "", "PRD-00981", "Internal", "", ""),
       ("Product Identifier As Delivered", "Product identifier exactly as received (CUSIP, ticker, TA fund number).", "Transaction", "Identifier", "External (Source system)", "45678Q109", "ISO 20022", "", "", "Mastered here as delivered (lineage)."),
       ("Account", "Client account (15) the flow is into or out of: brokerage, fund-only, managed, IRA, participant, trust or institutional separate account, or an intermediary's omnibus or networked account.", "Transaction", "Reference (Account)", "", "ACC-0049812", "Internal", "", "Y", "PII. " + _RR_FLOW),
       ("Originating Fund Order", "Fund order, as received and processed by the transfer agent, that resulted in this flow (mastered in 29).", "Transaction", "Reference (Fund Order, 29)", "", "FNDO-2026-00418273", "Internal", "", "", "CD-199 as amended by CW-122: set for own-fund orders processed by the firm's transfer agent; the confirmed posting is Source Register Transaction (29)."),
       ("Originating AP Order", "ETF authorized participant creation or redemption order that resulted in this flow (mastered in 29).", "Transaction", "Reference (AP Creation / Redemption Order, 29)", "", "ECR-2026-000512", "Internal", "", "", "CD-199, CD-200: set only for ETF primary-market transactions processed by the firm's transfer agent."),
       ("Look-Through Level", "Level of visibility the record gives into the underlying client.", "Transaction, Fund Shareholder Position", "Code", "Look-Through Level", "Firm Client Account", "Internal", "DTCC Omni/SERV", ""),
     ]),
   ]),
   ("Dates & Amounts", "Trade dates, quantities, prices and amounts of a flow.", [
     ("Transaction Dates", [
       ("Trade Date", "Date the flow was priced, executed or posted (NAV date for fund dealing, value date for cash, transfer settlement date for ACATS).", "Transaction", "Date", "ISO 8601", "2026-09-18", "ISO 20022", "DTCC Fund/SERV", "Y", "Object PII tier: PII - financial. " + _RR_FLOW),
       ("Settlement Date", "Date cash and shares or securities settled.", "Transaction", "Date", "ISO 8601", "2026-09-19", "ISO 20022", "", "", _RR_FLOW),
       ("As-Of Date", "Effective date for a back-dated (as-of) posting processed after the trade date, e.g. to correct a processing error.", "Transaction", "Date", "ISO 8601", "2026-09-15", "SS&C DST", "", "Y", "Row rule (CD-199 as amended by CW-122): on rows with a Source Register Transaction this is a Derived copy of the 29 posting's as-of date; mastered here for intermediary-feed rows."),
     ]),
     ("Transaction Amounts", [
       ("Units", "Number of shares, units or securities moved (stored unsigned; signed by Flow Direction in measures).", "Transaction", "Decimal", "", "1,250.4472", "ISO 20022", "", "Y", "Object PII tier: PII - financial. " + _RR_FLOW),
       ("Price", "Price applied (NAV, exchange price, or the transfer valuation price for securities received in kind).", "Transaction", "Decimal", "", "24.1873", "ISO 20022", "", "", _RR_FLOW),
       ("Gross Amount", "Amount of the flow before fees and tax withholding.", "Transaction", "Amount", "", "USD 30,250.00", "ISO 20022", "ICI", "Y", "PII. " + _RR_FLOW + " On an Inter-Channel Transfer row it is the Account Asset Summary total of the account on the last day of the old channel assignment."),
       ("Net Amount", "Amount invested or paid out after fees and tax withholding.", "Transaction", "Amount", "", "USD 29,190.25", "ISO 20022", "", "", _RR_FLOW),
       ("Transaction Currency", "Currency of the flow amounts.", "Transaction", "Code", "ISO 4217", "USD", "ISO 4217", "", "", _RR_FLOW),
       ("Reporting Currency Amount", "Gross amount in USD, the reporting currency; differs from Gross Amount only for foreign-currency cash or foreign securities received.", "Transaction", "Amount", "", "USD 30,250.00", "Internal", "", "Y"),
       ("FX Rate Applied", "Exchange rate used to convert a foreign-currency flow to USD.", "Transaction", "Decimal", "", "1.0000", "Internal", "", "", _RR_FLOW),
     ]),
   ]),
   ("Order Source, Source Records & Intermediary As Delivered", "Which book of record the flow is copied from, how an order reached the transfer agent, and which intermediary codes an intermediary feed reported.", [
     ("Order Source", [
       ("Flow Source Book", "Book the flow is loaded from, fixed by the account's book: 49 Client Account Activity for brokerage and managed accounts (50 money movements reach 06 only through their 49 posting), 29 Register Transaction for direct registered accounts (Fund-Only, Institutional Direct, Networked), 16 Participant Ledger Posting for participant accounts of plans the firm recordkeeps, 18 Portfolio Capital Activity for institutional advisory mandates, the intermediary feed for intermediary sub-accounts, and 06 Account Channel Assignment for generated inter-channel transfers.", "Transaction", "Code", "Source Book", "Brokerage Book of Record (49)", "Internal", "", "Y", "Object PII tier: PII - financial. One flow book per account (program-lead ruling on the 06 review): 29 postings to the Broker-Dealer Omnibus, Plan Omnibus, Intermediary Omnibus and DTC Nominee accounts and 50 money movement instructions are never loaded as flows."),
       ("Source Client Account Activity", "49 client account activity posting the flow is copied from, for brokerage and managed accounts (deposits and withdrawals, transfers, journals, fund purchases and redemptions, income, fee debits).", "Transaction", "Reference (Client Account Activity, 49)", "", "CLACT-20261005-0004188221", "Internal", "", ""),
       ("Source Account Transfer", "49 account transfer behind an Account Transfer In or Out posting (ACATS full, partial or residual, non-ACATS, internal re-registration), copied from the 49 posting for its transfer detail.", "Transaction", "Reference (Account Transfer, 49)", "", "ACXF-2026-0045120", "FINRA Rule 11870", "", ""),
       ("Source Register Transaction", "29 register posting (the confirmed transfer agent transaction under SEC Rule 17Ad-10) the own-fund flow of a direct registered account is copied from.", "Transaction", "Reference (Register Transaction, 29)", "", "RGTX-2026-0004188273", "SEC Rule 17Ad-10", "", "", "CW-122 amends CD-199 and CD-200: the confirmed TA transaction is 29's."),
       ("Source Participant Ledger Posting", "16 participant ledger posting (contribution, rollover in, distribution, fee, exchange) the workplace flow is copied from.", "Transaction", "Reference (Participant Ledger Posting, 16)", "", "PLPST-2026-0091220417", "SPARK Institute", "", ""),
       ("Source Portfolio Capital Activity", "18 capital activity (institutional mandate contribution or withdrawal) the institutional flow is copied from.", "Transaction", "Reference (Portfolio Capital Activity, 18)", "", "PORT-000412 / 2026-10-05 / Client Contribution", "Internal", "", ""),
       ("Source Channel Assignment", "Account channel assignment whose start generated an inter-channel transfer row (the new assignment; its predecessor gives the From Channel).", "Transaction", "Reference (Account Channel Assignment, 06)", "", "CHASG-000418822", "Internal", "", ""),
       ("Order Entry Channel", "Route by which an own-fund order reached the transfer agent (Dealing Route).", "Transaction", "Code", "Order Entry Channel", "Affiliated Broker-Dealer Omnibus", "DTCC Fund/SERV", "", "", "Row rule (CD-199, plan section 4 item 9): on rows processed by the firm's transfer agent (Originating Fund Order set) this is a Derived copy of 29 Order Routing Detail.Dealing Route; mastered here for every other source."),
       ("Systematic Plan Indicator", "Whether the flow arose from a recurring investment, automatic deposit, systematic withdrawal or payroll contribution.", "Transaction", "Boolean", "", "N", "Internal", "", "", _RR_FLOW),
       ("Contribution Source Type", "Money source of a workplace contribution or rollover, copied from the 16 posting.", "Transaction", "Code", "External (16 Contribution Source)", "Employee Pre-Tax", "SPARK Institute", "", ""),
       ("Order Message Type", "Standard message used to submit an own-fund order, where messaging is ISO 20022 or proprietary.", "Transaction", "Code", "External (ISO 20022 message catalog)", "setr.010 Subscription Order", "ISO 20022", "", "", "Row rule (CD-199, plan section 4 item 9): on rows processed by the firm's transfer agent (Originating Fund Order set) this is a Derived copy of 29 Order Routing Detail.Order Message Type; mastered here for every other source."),
     ]),
     ("Intermediary As Delivered", [
       ("Dealer / Firm Number", "Dealer or firm code exactly as delivered by an intermediary feed (NSCC dealer number, TA dealer ID).", "Transaction, Fund Shareholder Position", "Identifier", "External (Source system)", "0158", "DTCC Fund/SERV", "SS&C DST", "Y", "Object PII tier: PII - identity (rep name as delivered). IC rows only; as-delivered codes are mastered here (lineage)."),
       ("Branch Number", "Branch or office code as delivered by the intermediary feed.", "Transaction, Fund Shareholder Position", "Identifier", "External (Source system)", "A27", "DTCC Fund/SERV", "", ""),
       ("Representative Number", "External financial professional's rep code as delivered (firm-specific rep ID, not necessarily CRD).", "Transaction, Fund Shareholder Position", "Identifier", "External (Source system)", "RJ4471", "DTCC Fund/SERV", "", ""),
       ("Representative Name As Delivered", "Rep name text delivered with the record, used for matching.", "Transaction, Fund Shareholder Position", "Text", "", "SMITH JANE A", "Internal", "", "", "PII"),
       ("Clearing Firm Number", "NSCC participant number of the clearing or settling firm, where different from the introducing dealer.", "Transaction", "Identifier", "External (Source system)", "0226", "DTCC Fund/SERV", "", ""),
       ("Intermediary Identifier Scheme", "Scheme of the delivered firm, office and rep codes.", "Transaction, Fund Shareholder Position", "Code", "Intermediary Identifier Type", "NSCC Dealer Number", "Internal", "", ""),
       ("Resolved Distributor Firm", "Intermediary firm profile (05) the delivered dealer code resolves to.", "Transaction, Fund Shareholder Position", "Reference (Distributor Firm, 05)", "", "PTY-100001", "Internal", "", "Y", "Row rule: on TA-processed rows (Originating Fund Order set) the party is copied from 29 Order Routing Detail.Resolved Dealer; on intermediary-feed rows it is resolved here through Identifier Crosswalk."),
       ("Resolved Office / Branch", "Intermediary branch or office profile (05) the delivered branch code resolves to.", "Transaction, Fund Shareholder Position", "Reference (Branch / Office, 05)", "", "PTY-100455", "Internal", "", ""),
       ("Resolved Advisor / Rep", "External financial professional (05) the delivered rep code resolves to; not a firm advisor.", "Transaction, Fund Shareholder Position", "Reference (Financial Professional, 05)", "", "PTY-301177", "Internal", "", "Y", "PII (individual). Row rule: on TA-processed rows copied from 29 Order Routing Detail.Resolved Representative; on intermediary-feed rows resolved here through Identifier Crosswalk."),
     ]),
   ]),
   ("Exchanges, Transfers, Rollovers & Conversions", "Links between the legs of exchanges, transfers, rollovers and share-class conversions.", [
     ("Linked Transaction", [
       ("Linked Transaction ID", "Other leg of an exchange, transfer, rollover or conversion.", "Transaction", "Reference (Transaction)", "", "TXN-2026-000418274", "Internal", "ISO 20022", "Y", "Object PII tier: PII - financial."),
       ("Contra Share Class", "Share class on the other side of an exchange or conversion.", "Transaction", "Reference (Share Class)", "", "SHC-004519", "Internal", "", ""),
       ("Transfer Type", "Mechanism of an account or asset transfer, copied from 49 Account Transfer.Transfer Channel or the 16 distribution.", "Transaction", "Code", "Transfer Type", "ACATS", "FINRA Rule 11870", "", "", _RR_FLOW),
       ("Contra Firm", "Other broker-dealer or custodian of a transfer in or out, copied from 49 Account Transfer.Contra Firm; for IC rows its 05 profile is Resolved Distributor Firm.", "Transaction", "Reference (Party)", "", "PTY-100877", "FINRA Rule 11870", "", "", "Row rule: Derived copy of 49 Account Transfer.Contra Firm on rows with a Source Account Transfer; mastered as delivered on intermediary-feed rows."),
       ("Same-Owner Indicator", "Whether a transfer or journal moved assets without change of beneficial owner (used to exclude it from Net New Assets firm-wide).", "Transaction", "Boolean", "", "Y", "Internal", "ICI", "Y"),
       ("From Distribution Channel", "Channel the assets left, on an inter-channel transfer row (the predecessor assignment of the account, or the channel of the delivering firm account of a journal).", "Transaction", "Code", "Distribution Channel", "Direct - Self-Directed", "Internal", "", "", "Copy of Account Channel Assignment.Assigned Distribution Channel."),
       ("To Distribution Channel", "Channel the assets entered, on an inter-channel transfer row.", "Transaction", "Code", "Distribution Channel", "Direct - Digital Advice", "Internal", "", "", "Copy of Account Channel Assignment.Assigned Distribution Channel."),
     ]),
   ]),
   ("ETF Primary Market & Sponsor Programs", "Authorized-participant creations and redemptions, and flows of third-party sponsor programs that use the firm's models (IC line).", [
     ("ETF Creation / Redemption", [
       ("Authorized Participant", "Authorized participant that placed the creation or redemption order.", "Transaction", "Reference (Party)", "", "PTY-000871", "Internal", "", "", "Object PII tier: No PII."),
       ("Creation Units", "Number of creation units created or redeemed.", "Transaction", "Integer", "", "4", "Internal", "", ""),
       ("Basket Type", "Settlement form of the creation or redemption basket, copied from the 29 AP order.", "Transaction", "Code", "External (29 Basket Settlement Form)", "In-Kind", "SEC Rule 6c-11", "", ""),
     ]),
     ("SMA Flow", [
       ("Sponsor Program", "Third-party sponsor separately managed account or model program agreement (05) under which the flow occurred.", "Transaction, Fund Shareholder Position", "Reference (Agreement)", "", "AGR-000312", "Internal", "", "", "Object PII tier: No PII. IC line (CW-918); the firm's own managed accounts are 15 accounts managed in 46, not sponsor flows."),
       ("Model Portfolio", "Model portfolio or strategy sleeve the sponsor flow relates to.", "Transaction, Fund Shareholder Position", "Reference (Model)", "", "MDL-0077", "Internal", "", ""),
     ]),
   ]),
   ("Status, Cancellations & Corrections", "Lifecycle of the flow record and corrections after the fact.", [
     ("Transaction Status", [
       ("Transaction Status", "Processing status of the flow record.", "Transaction", "Code", "Transaction Status", "Settled", "ISO 20022", "", "Y", "Object PII tier: No PII. " + _RR_FLOW),
       ("Cancel / Correct Indicator", "Whether the record cancels, corrects or reverses an earlier flow.", "Transaction", "Code", "Cancel Correct Indicator", "Cancel", "ISO 20022", "", "Y"),
       ("Original Transaction ID", "Flow being canceled, corrected or reversed.", "Transaction", "Reference (Transaction)", "", "TXN-2026-000401118", "Internal", "", ""),
       ("Correction Reason", "Reason for the cancellation or correction.", "Transaction", "Code", "Correction Reason", "NAV Error", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Positions & Client Asset Balances", "TX-POS",
  "Fund Shareholder Positions (units of the firm's own funds held by an account, a view of 49 Client Holdings and of the 29 share register, each row with an Aggregation Role), the intermediary look-through, ETF, third-party recordkept plan and sponsor-reported assets delivered by intermediaries, and the Account Asset Summary that feeds Client Assets. 06 masters no Client Holding, tax lot, cost basis or cash balance (CW-007, CW-122).",
  [
   ("Fund Shareholder Position", "Units and market value of an own fund held by an account on a valuation date.", [
     ("Fund Shareholder Position", [
       ("Position ID", "Unique identifier of the fund shareholder position (account x share class x valuation date x source).", "Fund Shareholder Position", "Identifier", "", "POS-20260930-0049812-004512", "Internal", "", "Y", "Object PII tier: PII - financial. Renamed from Position (CW-007, CW-141); POS- kept."),
       ("Account", "Account holding the own-fund shares.", "Fund Shareholder Position", "Reference (Account)", "", "ACC-0049812", "Internal", "", "Y", "PII"),
       ("Share Class", "Own-fund share class held.", "Fund Shareholder Position", "Reference (Share Class)", "", "SHC-004512", "Internal", "", "Y"),
       ("Valuation Date", "Date at which the fund shareholder position is stated.", "Fund Shareholder Position", "Date", "ISO 8601", "2026-09-30", "ISO 20022", "", "Y"),
       ("Position Source Book", "Book the row is a view of: 49 for brokerage and managed accounts, 29 for every other registered account, or an intermediary feed for look-through rows.", "Fund Shareholder Position", "Code", "Source Book", "Transfer Agent Register (29)", "Internal", "", "Y"),
       ("Register Account Category", "Register view of the account (fund-only, broker-dealer omnibus, intermediary omnibus, networked, plan omnibus, institutional direct, firm proprietary, DTC nominee, CIT unitholder), copied from 29; blank on 49 and look-through rows.", "Fund Shareholder Position", "Code", "External (29 Register Account Category)", "Fund-Only", "Internal", "", ""),
       ("Aggregation Role", "Whether the row is summed into Client Assets and own-fund assets by channel, and in which channel family, or kept only for control and attribution.", "Fund Shareholder Position", "Code", "Aggregation Role", "Counted - Firm Client Account", "Internal", "", "Y", _RR_AGG),
       ("Source Client Holding", "49 Client Holding the fund shareholder position copies, for brokerage and managed accounts.", "Fund Shareholder Position", "Reference (Client Holding, 49)", "", "CLHLD-20261005-0041882217", "Internal", "", ""),
       ("Source Share Register Balance", "29 share register balance the fund shareholder position copies, for fund-only, omnibus, networked, plan omnibus, DTC nominee and CIT unitholder accounts.", "Fund Shareholder Position", "Reference (Share Register Balance, 29)", "", "ACC-0049812 / SHC-004512 / 2026-09-30", "SEC Rule 17Ad-10", "", ""),
       ("Units Held", "Number of own-fund shares or units held.", "Fund Shareholder Position", "Decimal", "", "18,402.1190", "ISO 20022", "DTCC Omni/SERV", "Y", _RR_POS),
       ("Valuation NAV", "27 share class NAV applied to Units Held on 29 register rows; blank on 49 rows, which carry the 49 valuation (own ETFs at the approved market price).", "Fund Shareholder Position", "Reference (Share Class NAV)", "", "NAV-2026093000451201", "Internal", "", ""),
       ("Market Value", "Value of the units held in USD: the 49 Client Holding Valuation.Market Value on 49 rows, Units Held x the 27 NAV on register rows, as delivered on look-through rows.", "Fund Shareholder Position", "Amount", "", "USD 447,192.04", "ISO 20022", "", "Y", "PII. " + _RR_POS),
       ("Position Basis", "Whether units reflect trade-date or settlement-date accounting.", "Fund Shareholder Position", "Code", "Position Basis", "Trade Date", "Internal", "", ""),
       ("Position Source", "Feed that reported the fund shareholder position, for intermediary rows.", "Fund Shareholder Position", "Reference (Feed)", "", "FEED-007", "Internal", "", ""),
       ("Source As-Of Timestamp", "Timestamp of the source view (49 End of Day holding, 29 register close, feed file) the row was copied from, so a locked snapshot can be re-derived after a source correction.", "Fund Shareholder Position", "Timestamp", "ISO 8601", "2026-09-30T23:15:00-04:00", "Internal", "", ""),
     ]),
   ]),
   ("Omnibus & Look-Through", "Relationship between an intermediary omnibus account on the register and the underlying sub-account positions reported by the intermediary.", [
     ("Omnibus Look-Through", [
       ("Omnibus Parent Account", "Intermediary omnibus account on the 29 register that aggregates the sub-account.", "Fund Shareholder Position, Transaction", "Reference (Account)", "", "ACC-0000415", "Internal", "DTCC Omni/SERV", "", "Object PII tier: PII - financial (sub-account level)."),
       ("Sub-Account Identifier As Delivered", "Identifier of the underlying sub-account at the intermediary, as delivered.", "Fund Shareholder Position, Transaction", "Identifier", "External (Source system)", "8842-11937", "SEC Rule 22c-2", "DTCC Omni/SERV", "", "May be pseudonymized; treat as PII if linkable."),
       ("Look-Through Source", "Source of the underlying detail.", "Fund Shareholder Position", "Code", "Look-Through Source", "Omni/SERV Position File", "DTCC Omni/SERV", "", ""),
       ("Look-Through Coverage %", "Share of the omnibus fund shareholder position explained by underlying records on the valuation date.", "Fund Shareholder Position", "Percentage", "", "97.4%", "Internal", "", ""),
       ("Omnibus Residual Amount", "Omnibus market value not explained by underlying records.", "Fund Shareholder Position", "Amount", "", "USD 1,204,500.00", "Internal", "", "", "Counted in the intermediary channel as an Unattributed Item, so look-through rows plus the residual equal the omnibus register balance."),
     ]),
   ]),
   ("ETF Holdings by Custodian / Broker", "Own-ETF shares reported by DTC participant or broker outside the firm, the basis for intermediary ETF attribution.", [
     ("ETF Holding", [
       ("Holding Custodian / Broker", "Broker-dealer or custodian outside the firm holding the own-ETF shares for its clients; the firm's own broker-dealer is excluded (its clients' ETF shares are 49 Client Holdings).", "Fund Shareholder Position", "Reference (Party)", "", "PTY-100001", "Internal", "", "", "Object PII tier: No PII. Name kept for its readers; the rows are own-ETF shares by DTC participant, not a Client Holding."),
       ("DTC Participant Number", "Depository participant number of the holder, as delivered.", "Fund Shareholder Position", "Identifier", "External (Source system)", "0164", "Internal", "", ""),
       ("ETF Shares Held", "Number of own-ETF shares held at the broker or custodian.", "Fund Shareholder Position", "Decimal", "", "1,284,000", "Internal", "Broadridge", ""),
       ("ETF Holdings Source", "Source of the ETF holdings data.", "Fund Shareholder Position", "Code", "ETF Holdings Source", "Aggregator Broker Data", "Internal", "", ""),
     ]),
   ]),
   ("Plan & Sponsor Assets", "Own funds held in plans recordkept by others (CW-139) and sponsor-reported program assets, where account-level detail is not held.", [
     ("Plan Position", [
       ("Retirement Plan", "Retirement plan recordkept by a third party whose participants hold the own fund; plans the firm recordkeeps flow through Account Asset Summary from 16.", "Fund Shareholder Position", "Reference (Party)", "", "PTY-077120", "Internal", "DTCC DCC&S", "", "Object PII tier: No PII."),
       ("Recordkeeper", "Third-party recordkeeper reporting the assets (16 Recordkeeper Profile).", "Fund Shareholder Position", "Reference (Recordkeeper Profile, 16)", "", "PTY-020018", "Internal", "", ""),
       ("Plan Participant Count", "Number of participants holding the own fund.", "Fund Shareholder Position", "Integer", "", "1,412", "Internal", "", ""),
       ("Plan Advisor", "External plan advisor of record reported by the recordkeeper (05 Financial Professional).", "Fund Shareholder Position", "Reference (Financial Professional, 05)", "", "PTY-301990", "Internal", "", "", "PII (individual)"),
     ]),
     ("Sponsor-Reported Assets", [
       ("Sponsor", "Third-party SMA, UMA or model-delivery sponsor reporting the assets (05 Distributor Firm).", "Fund Shareholder Position", "Reference (Distributor Firm, 05)", "", "PTY-100001", "Internal", "", "", "Object PII tier: No PII. Aggregation Role Attribution Only: sponsor totals attribute omnibus look-through rows and are never added to them."),
       ("Sponsor Reporting Basis", "Whether the sponsor reports account-level, advisor-level or program-level totals.", "Fund Shareholder Position", "Code", "Feed Grain", "Advisor", "Internal", "", ""),
       ("Model-Delivery Assets Indicator", "Whether the assets are model-delivery (sponsor-implemented, non-discretionary for the firm) rather than firm-managed.", "Fund Shareholder Position", "Boolean", "", "Y", "Internal", "SEC Form ADV", "", "Reported as assets under advisement, outside Client Assets and Firm AUM."),
     ]),
   ]),
   ("Client Asset Balances", "Market value of every client account by holding type on an as-of date: the base of Client Assets.", [
     ("Account Asset Summary", [
       ("Summary Account", "Firm client account (15) summarized: brokerage, managed, fund-only, institutional direct, participant, trust or institutional separate account; never an intermediary omnibus or networked account.", "Account Asset Summary", "Reference (Account)", "", "ACC-0049812", "Internal", "", "Y", "Object PII tier: PII - financial. PII. Key <ACC- id> / <as-of date> / <holding type> (GRAIN_KEY_FORMATS, CW-148)."),
       ("Summary As-Of Date", "Business date the summary represents.", "Account Asset Summary", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
       ("Summary Holding Type", "Holding type summarized.", "Account Asset Summary", "Code", "Holding Type", "Own ETF", "Internal", "", "Y"),
       ("Summary Source Book", "Book the summary is computed from: 49 Client Holding Valuation, 49 Account Cash Balance and 50 Sweep Allocation for brokerage, managed and trust accounts; 06 Fund Shareholder Position (29 register rows) for fund-only and institutional direct accounts; 16 Participant Balance for participant accounts of plans the firm recordkeeps; 18 Portfolio Holding (through the portfolio's account) for institutional separate accounts.", "Account Asset Summary", "Code", "Source Book", "Brokerage Book of Record (49)", "Internal", "", "Y"),
       ("Summary Market Value", "Net equity of the account in the holding type on the as-of date, in USD: long market value (shorts negative), and for Cash and Sweep the free credit, bank sweep and money market sweep balances less any margin debit; accrued interest excluded.", "Account Asset Summary", "Amount", "", "USD 182,410.55", "GIPS", "", "Y", "PII. Lever: gross long value (margin debit not deducted). " + _RR_AAS),
       ("Own-Product Indicator", "Whether the holding type is an own fund, ETF or CIT, so the amount also sits in Firm AUM and enters the reported own-fund overlap.", "Account Asset Summary", "Boolean", "", "Y", "Internal", "", "Y"),
       ("Summary Distribution Channel", "Channel of the account on the as-of date.", "Account Asset Summary", "Code", "Distribution Channel", "Direct - Self-Directed", "Internal", "", "Y", "Copy of Account Channel Assignment.Assigned Distribution Channel in force on the as-of date; never set here."),
       ("Advised Assets Indicator", "Whether the account was enrolled in a fee-based advice, managed or trust program (15 Program Enrollment) on the as-of date, so the row counts toward Advised Assets.", "Account Asset Summary", "Boolean", "", "N", "Internal", "SEC Form ADV", "Y"),
       ("Source As-Of Timestamp", "Timestamp of the source view the summary was computed from (49 End of Day, 16 valuation, 18 holding date).", "Account Asset Summary", "Timestamp", "ISO 8601", "2026-09-30T23:15:00-04:00", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Flow & Client Asset Measures", "TX-MEA",
  "Definitions, treatment rules and value structures of the certified Client Assets, Net New Assets and Advised Assets families (CW-011, CW-142) and of the own-fund flow and asset measures, aligned to ICI and Morningstar definitions. Firm AUM is not defined here (27, 46, 18; DP-165).",
  [
   ("Measure Definition", "Catalog entry for each certified measure; 21 registers each one as a Metric Definition.", [
     ("Measure Definition", [
       ("Measure ID", "Unique identifier of the measure.", "Measure Definition", "Identifier", "", "MSR-NNA", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Measure Name", "Business name of the measure.", "Measure Definition", "Text", "", "Net New Assets", "Internal", "", ""),
       ("Measure Category", "Family the measure belongs to.", "Measure Definition", "Code", "Measure Category", "Client Assets", "Internal", "", ""),
       ("Business Definition", "Plain-language definition of the measure, as certified; the single place the certified text is held (CW-142).", "Measure Definition", "Text", "", "External cash and asset movements into firm client accounts less those out of them, by channel, in the period.", "Internal", "ICI", ""),
       ("Calculation Formula", "Formula in terms of transaction types, treatment rules and other measures.", "Measure Definition", "Text", "", "Inflows - Outflows of Transaction Types included, Same-Owner = N, Flow Scope includes Client Asset Flow", "Internal", "ICI", ""),
       ("Included Transaction Types", "Transaction types counted in the measure.", "Measure Definition", "Code (multi)", "Transaction Type", "Cash Deposit; ACATS Transfer In; Rollover In; Plan Contribution", "Internal", "", "Y"),
       ("Excluded Transaction Types", "Transaction types explicitly excluded.", "Measure Definition", "Code (multi)", "Transaction Type", "Reinvestment; Fee Debit; Share Class Conversion", "Internal", "", ""),
       ("Included Distribution Channels", "Channels the measure covers; defines roll-ups such as the 'advised and managed' channel (Direct - Digital Advice + Direct - Human Advice + Direct - Trust, CW-140).", "Measure Definition", "Code (multi)", "Distribution Channel", "Direct - Digital Advice; Direct - Human Advice; Direct - Trust", "Internal", "", ""),
       ("Aggregation Behavior", "How the measure may be summed across time and dimensions; every measure signs outflows negative.", "Measure Definition", "Code", "Aggregation Behavior", "Additive", "Internal", "", ""),
       ("Time Basis", "Date driving period assignment.", "Measure Definition", "Code", "Time Basis", "Trade Date", "Internal", "", "Y"),
       ("Measure Owner Role", "Business role accountable for the certified definition.", "Measure Definition", "Text", "", "Head of Client & Channel Analytics", "Internal", "", "", "CW-011, CW-142."),
       ("Certified Indicator", "Whether the measure is certified for external or management reporting; copied from the certification of the 21 Metric Definition that registers the measure.", "Measure Definition", "Boolean", "", "Y", "Internal", "", ""),
     ]),
   ]),
   ("Flow Treatment Rules", "Firm-level policy choices that drive flow and Net New Assets measures where industry practice varies; each is a tailoring lever.", [
     ("Flow Treatment Rule", [
       ("Reinvestment Treatment", "Whether reinvested dividends and capital gains count as sales or as market movement.", "Measure Definition", "Code", "Treatment Option", "Exclude from Sales (Market Movement)", "ICI", "Morningstar", "Y", "Object PII tier: No PII."),
       ("Exchange Treatment", "Whether exchanges within the own fund family are counted in gross sales and redemptions or only as net exchanges.", "Measure Definition", "Code", "Treatment Option", "Include in Gross", "ICI", "", ""),
       ("Transfer Treatment", "Whether transfers and journals without change of owner are counted as flows firm-wide; journals between firm accounts in different channels are inter-channel transfers whatever the owner and never Net New Assets.", "Measure Definition", "Code", "Treatment Option", "Exclude (Same Owner)", "Internal", "", ""),
       ("Share Class Conversion Treatment", "Whether conversions between share classes of the same fund are counted as flows.", "Measure Definition", "Code", "Treatment Option", "Exclude at Product Level", "Internal", "", ""),
       ("ETF Flow Basis", "Basis for own-ETF flows: primary-market creations and redemptions or change in shares outstanding.", "Measure Definition", "Code", "ETF Flow Basis", "Shares Outstanding Change x NAV", "Morningstar", "ICI", ""),
       ("Model-Delivery Inclusion", "Whether model-delivery assets are included in asset measures or reported separately as assets under advisement.", "Measure Definition", "Code", "Treatment Option", "Exclude (Report Separately)", "Internal", "SEC Form ADV", ""),
       ("Money Market Inclusion", "Whether money market funds (including sweep money market funds) are included in long-term flow measures.", "Measure Definition", "Code", "Treatment Option", "Exclude (Report Separately)", "ICI", "", ""),
       ("Income Treatment", "Whether dividends, interest and capital gain distributions received in client accounts (Transaction Type Income Received) count as Net New Assets or as market movement and other.", "Measure Definition", "Code", "Treatment Option", "Exclude (Market Movement and Other)", "Internal", "", "Y"),
       ("Fee Treatment", "Whether advisory fees and other fees debited from client accounts reduce Net New Assets or are shown in market movement and other.", "Measure Definition", "Code", "Treatment Option", "Exclude (Market Movement and Other)", "Internal", "", "Y"),
       ("Inter-Channel Transfer Treatment", "How a change of an account's channel (for example enrollment of a self-directed account in digital advice) is counted: zero firm-wide, an outflow of the old and an inflow of the new channel.", "Measure Definition", "Code", "Treatment Option", "Inter-Channel Transfer (Zero Firm-Wide)", "Internal", "", ""),
       ("Rollover Treatment", "Whether a rollover from a plan the firm recordkeeps into a firm IRA is new money or an inter-channel transfer.", "Measure Definition", "Code", "Treatment Option", "Inter-Channel Transfer (Zero Firm-Wide)", "IRC Section 402(c)", "", "", "Rollovers from outside the firm count as Net New Assets. The pair is the 16 Distribution posting and the IRA receipt posted in 49 (16 Participant Retail Hand-Off, PRTHO-, starts it); the amount is the distribution's Gross Amount."),
     ]),
   ]),
   ("Measure Value Structure", "Grain and qualifiers of every stored measure value (fact).", [
     ("Measure Value", [
       ("Measure", "Measure the value belongs to.", "Measure Value", "Reference (Measure)", "", "MSR-CLIENTASSETS", "Internal", "", "Y", "Object PII tier: No PII at total, channel, holding type and business line grain; values at advisor, household or campaign grain are restricted views. Key: measure x period end x Dimension Type x Dimension Key x data basis x snapshot."),
       ("Period Type", "Length of the period the value covers.", "Measure Value", "Code", "Period Type", "Month", "Internal", "", ""),
       ("Period Start Date", "First day of the period.", "Measure Value", "Date", "ISO 8601", "2026-09-01", "Internal", "", ""),
       ("Period End Date", "Last day of the period.", "Measure Value", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
       ("Dimension Type", "Dimension the value is broken down by: total, channel, holding type, business line, advisor, campaign, share class or segment.", "Measure Value", "Code", "Dimension Type", "Holding Type", "Internal", "", "Y"),
       ("Dimension Key", "Member of the dimension: the code or ID of the channel, holding type, business line, advisor (EMP-), campaign (CAM-), share class (SHC-) or segment; ALL for Total.", "Measure Value", "Identifier", "", "OWN_ETF", "Internal", "", "Y", "Tailoring lever (W5): one dimension per row in the reference model, so cross-tabs (for example channel x holding type) are computed from the flow records rather than stored. A client that wants stored cross-tabs may adopt a composite Dimension Key (Dimension Type 'Channel x Holding Type', key 'INTERMEDIARY_RIA|OWN_ETF') with the Dimension Type list extended; the record key is unchanged."),
       ("Reporting Period", "Reporting period the value belongs to.", "Measure Value", "Reference (Reporting Period)", "", "2026-09", "Internal", "", "Y"),
       ("Measure Amount", "Value of the measure in USD.", "Measure Value", "Amount", "", "USD 4,812,330.00", "Internal", "", "Y"),
       ("Data Basis", "Whether the value is actual, estimated or allocated.", "Measure Value", "Code", "Data Basis", "Actual", "Internal", "Morningstar", "Y"),
       ("Snapshot", "Snapshot or version the value belongs to.", "Measure Value", "Reference (Snapshot)", "", "SNP-2026-09-M-FINAL", "Internal", "", ""),
       ("Attributed Share %", "Share of the value attributed to a named dimension member (versus unattributed).", "Measure Value", "Percentage", "", "93.8%", "Internal", "", ""),
     ]),
   ]),
   ("Core Measure Catalog", "Starter catalog of the measures the domain certifies; each row is a Measure Definition instance with its rule summarized here.", [
     ("Flow Measures", [
       ("Gross Sales", "Own-fund purchases, exchanges in, new-owner transfers in, sponsor-program contributions and ETF creations (or estimated ETF inflows) in the period, by account across every channel (brokerage-account purchases from 49, never the Broker-Dealer Omnibus posting); excludes reinvestments.", "Measure Value", "Amount", "", "USD 412m", "ICI", "", "Y", "Object PII tier: No PII. Values only; the certified text is the Measure Definition row."),
       ("Redemptions", "Own-fund redemptions, exchanges out, new-owner transfers out, sponsor-program withdrawals and ETF redemptions in the period, shown as a positive amount.", "Measure Value", "Amount", "", "USD 388m", "ICI", "", "Y"),
       ("Net Exchanges", "Exchanges in less exchanges out within the own fund family.", "Measure Value", "Amount", "", "USD -3m", "ICI", "", ""),
       ("Net Flows (Net Sales)", "Gross sales less redemptions of the own funds; equals ICI net new cash flow where exchanges are included and reinvestments excluded.", "Measure Value", "Amount", "", "USD 24m", "ICI", "Morningstar", "Y"),
       ("Reinvested Distributions", "Own-fund dividends and capital gains reinvested in additional shares.", "Measure Value", "Amount", "", "USD 9m", "ICI", "Morningstar", ""),
     ]),
     ("Asset Measures", [
       ("Beginning AUM", "Own-fund assets attributed to a channel or dimension at the end of the prior period (sum of Fund Shareholder Position market values); fund assets by channel, not Firm AUM.", "Measure Value", "Amount", "", "USD 18.20bn", "GIPS", "Internal", "", "Object PII tier: No PII. Firm AUM is DP-165, 46 and 18 (CW-011); names kept for their readers."),
       ("Ending AUM", "Own-fund assets attributed to a channel or dimension at period end: the sum of Fund Shareholder Position market values whose Aggregation Role is Counted (firm client account and intermediary look-through rows), plus omnibus residuals.", "Measure Value", "Amount", "", "USD 18.61bn", "GIPS", "Internal", "Y"),
       ("Market Movement", "Change in own-fund assets not explained by net flows: Ending AUM - Beginning AUM - Net Flows; includes appreciation, income and reinvestments where excluded from flows.", "Measure Value", "Amount", "", "USD 386m", "Morningstar", "", "Y"),
       ("Average AUM", "Average of daily (or month-end) own-fund assets over the period; method stated in Calculation Formula.", "Measure Value", "Amount", "", "USD 18.43bn", "Internal", "", "Y"),
       ("Organic Growth Rate", "Own-fund net flows for the period divided by Beginning AUM, annualized where stated.", "Measure Value", "Percentage", "", "1.6% annualized", "Internal", "", "Y"),
       ("Estimated Management Fee Revenue", "Average AUM multiplied by the share class net management fee rate (from 01) for the period, pro-rated by days; an analytic estimate, not booked revenue (10).", "Measure Value", "Amount", "", "USD 11.7m", "Internal", "", "", "Fee rates referenced from SHC-; not a GL figure."),
     ]),
     ("Client Asset Measures", [
       ("Beginning Client Assets", "Client Assets at the end of the prior period.", "Measure Value", "Amount", "", "USD 412.6bn", "Internal", "", "", "Object PII tier: No PII (aggregate). Values only; the certified definitions are the Measure Definition rows MSR-CLIENTASSETS, MSR-NNA, MSR-ADVISEDASSETS and MSR-AVGCLIENTASSETS."),
       ("Ending Client Assets", "Value of Client Assets (MSR-CLIENTASSETS) on the last business day of the period (09 business calendar, End of Day view).", "Measure Value", "Amount", "", "USD 418.9bn", "Internal", "SEC Form ADV", "Y", "Summing rule (program-lead ruling on the 06 review): sum of Account Asset Summary over firm client accounts (49 book for brokerage, managed and trust; 29 book for direct registered; 16 Participant Balance for participant accounts; 18 for IA mandates) plus Fund Shareholder Position rows with Aggregation Role Counted - Intermediary Look-Through and omnibus residuals. Account Asset Summary never holds intermediary assets, so nothing is added twice. Seed (Firm Proprietary) excluded."),
       ("Net New Assets", "Value of Net New Assets (MSR-NNA): Transaction rows with Flow Scope Client Asset Flow or Client Asset and Fund Flow, signed, under the Flow Treatment Rule; inter-channel transfers, income and fees excluded by default. Gross inflows and outflows are the measures MSR-NNA-IN and MSR-NNA-OUT.", "Measure Value", "Amount", "", "USD 3.4bn", "Internal", "ICI", "Y", "CW-011, CW-142."),
       ("Client Market Movement and Other", "Change in Client Assets not explained by Net New Assets and inter-channel transfers: Ending - Beginning Client Assets - Net New Assets - Net Inter-Channel Transfers; includes market appreciation, income and fees.", "Measure Value", "Amount", "", "USD 2.9bn", "Morningstar", "", "Y"),
       ("Net Inter-Channel Transfers", "Sum of Transaction rows with Flow Scope Inter-Channel Transfer into the channel less those out of it (advice enrollments and terminations, journals between channels, rollovers from firm plans into firm IRAs); zero firm-wide.", "Measure Value", "Amount", "", "USD 0.6bn", "Internal", "", ""),
       ("Client Organic Growth Rate", "Net New Assets for the period divided by Beginning Client Assets, annualized where stated.", "Measure Value", "Percentage", "", "3.3% annualized", "Internal", "", "Y"),
       ("Advised Assets", "Value of Advised Assets (MSR-ADVISEDASSETS): Account Asset Summary rows with Advised Assets Indicator = Y (fee-based advice, managed and trust enrollments, equal to the advised and managed channel roll-up) on the period end; participant managed accounts and institutional mandates excluded by default.", "Measure Value", "Amount", "", "USD 141.2bn", "Internal", "SEC Form ADV", "Y", "CW-011, CW-142. Levers: include planning-only clients, participant managed accounts (WR) or IA mandates."),
       ("Average Client Assets", "Value of Average Client Assets (MSR-AVGCLIENTASSETS): the mean of the Ending Client Assets of each business day of the period (month-end average for quarter and year); the asset basis 10 reads for basis-point measures.", "Measure Value", "Amount", "", "USD 415.7bn", "Internal", "", "Y"),
       ("Client Assets Excluding Intermediary-Held", "Ending Client Assets less the intermediary look-through rows and omnibus residuals: assets of firm client accounts only.", "Measure Value", "Amount", "", "USD 391.3bn", "Internal", "", ""),
       ("Own-Fund Overlap Amount", "Own-fund, own-ETF and own-CIT assets included in Client Assets in every channel (firm client accounts and intermediary look-through), which are also in the fund slice of Firm AUM; reported here, netted only in the reconciliation product (successor of DP-241).", "Measure Value", "Amount", "", "USD 236.5bn", "Internal", "", "Y", "CW-011: reported, never netted, in 06. The advisory-slice overlap (46 managed and 18 mandate assets) is an open question for the CW-011 owner."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Channel Attribution", "TX-ATT",
  "Effective-dated channel of every account, and the assignment of flows and assets to channel, business line, offering, firm advisor, client household, campaign, plan, institutional client, consultant and intermediary hierarchy, with IC and IA salesperson credit, method, confidence, overrides and unattributed items (CW-142, CW-143).",
  [
   ("Account Channel Assignment", "The channel and business line of an account over time.", [
     ("Account Channel Assignment", [
       ("Channel Assignment ID", "Unique identifier of the account channel assignment.", "Channel Assignment", "Identifier", "", "CHASG-000418822", "Internal", "", "Y", "Object PII tier: PII - financial (an account's enrollment history)."),
       ("Assigned Account", "Account the channel is assigned to.", "Channel Assignment", "Reference (Account)", "", "ACC-0049812", "Internal", "", "Y"),
       ("Assigned Distribution Channel", "Channel the account belongs to in the period.", "Channel Assignment", "Code", "Distribution Channel", "Direct - Digital Advice", "Internal", "", "Y"),
       ("Assigned Business Line", "CW-004 business line the account belongs to in the period.", "Channel Assignment", "Code", "Business Line", "DA", "Internal", "", "Y"),
       ("Channel Assignment Basis", "Fact the channel is derived from, by precedence: trust program, advice or managed enrollment (15 Program Enrollment), workplace plan (15 participant account of a 16 plan; participant managed accounts stay WR), partner agreement (15 intermediary account), institutional mandate, then account type; a manual assignment is a new version, never an override.", "Channel Assignment", "Code", "Channel Assignment Basis", "Program Enrollment", "Internal", "", "Y", "Trust accounts (51) take Direct - Trust and line TR through their 49 holdings."),
       ("Basis Program Enrollment", "15 program enrollment that puts the account in an advice or trust channel.", "Channel Assignment", "Reference (Program Enrollment)", "", "ENRL-2025-0004418", "Internal", "", ""),
       ("Channel Effective From", "First business date the account is in the channel.", "Channel Assignment", "Date", "ISO 8601", "2025-03-14", "Internal", "", "Y"),
       ("Channel Effective To", "Last business date the account is in the channel; blank while current.", "Channel Assignment", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Attribution Record", "Split of one transaction, fund shareholder position or account asset summary across attribution dimensions.", [
     ("Attribution Record", [
       ("Attribution Record ID", "Unique identifier of the attribution record.", "Attribution Record", "Identifier", "", "ATR-2026-09-00918822", "Internal", "", "Y", "Object PII tier: PII - financial (account-level amounts)."),
       ("Source Record Type", "Whether a transaction, fund shareholder position, account asset summary or measure value was attributed.", "Attribution Record", "Code", "Source Record Type", "Transaction", "Internal", "", ""),
       ("Source Transaction", "Flow transaction attributed.", "Attribution Record", "Reference (Transaction)", "", "TXN-2026-000418273", "Internal", "", ""),
       ("Source Position", "Fund shareholder position attributed.", "Attribution Record", "Reference (Fund Shareholder Position)", "", "POS-20260930-0049812-004512", "Internal", "", ""),
       ("Source Account Asset Summary", "Account asset summary attributed.", "Attribution Record", "Reference (Account Asset Summary, 06)", "", "ACC-0049812 / 2026-09-30 / Own ETF", "Internal", "", ""),
       ("Attributed Amount", "Amount assigned to this combination of dimensions; a record applies one split basis only (campaign weight or salesperson credit split), and the records of one basis sum to 100% of the source amount, so amounts are never summed across bases.", "Attribution Record", "Amount", "", "USD 30,250.00", "Internal", "", "Y"),
       ("Attribution Share %", "Proportion of the source amount assigned by this record (100% unless split).", "Attribution Record", "Percentage", "", "100%", "Internal", "", ""),
       ("Attribution Effective Date", "Business date the attribution applies to (trade or valuation date).", "Attribution Record", "Date", "ISO 8601", "2026-09-18", "Internal", "", ""),
     ]),
   ]),
   ("Attribution Dimensions", "Who and where the amount is attributed to.", [
     ("Distributor Hierarchy", [
       ("Distributor Firm", "Intermediary firm (05) credited, for IC flows and assets.", "Attribution Record", "Reference (Distributor Firm, 05)", "", "PTY-100001", "Internal", "Broadridge", "Y", "Object PII tier: PII - identity (external advisor). CW-132."),
       ("Distributor Office / Branch", "Intermediary branch or office (05) credited.", "Attribution Record", "Reference (Branch / Office, 05)", "", "PTY-100455", "Broadridge", "Internal", ""),
       ("Advisor Team", "Intermediary advisor team (05) credited, where teams are modeled.", "Attribution Record", "Reference (Advisor Team, 05)", "", "PTY-204500", "Internal", "", ""),
       ("Advisor / Rep", "External financial professional (05) credited; the firm's own advisor is Covering Advisor.", "Attribution Record", "Reference (Financial Professional, 05)", "", "PTY-301177", "Broadridge", "Internal", "Y", "PII (individual)"),
       ("Hierarchy Version Date", "Date of the 05 intermediary hierarchy (Hierarchy Node) used, so restated hierarchies are traceable.", "Attribution Record", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
     ]),
     ("Market & Client Dimensions", [
       ("Distribution Channel", "Channel of the flow or asset on the effective date.", "Attribution Record", "Code", "Distribution Channel", "Direct - Human Advice", "Internal", "", "Y", "Object PII tier: PII - identity (household and advisor keys). Copy of Account Channel Assignment.Assigned Distribution Channel; channel changes are new assignment versions, never overrides."),
       ("Business Line", "CW-004 business line of the account on the effective date; PF reporting uses Flow Scope Fund Flow by share class, not this line.", "Attribution Record", "Code", "Business Line", "HA", "Internal", "", "Y", "Copy of Account Channel Assignment.Assigned Business Line."),
       ("Service Offering", "Advice or managed program offering (01) credited, from the account's enrollment.", "Attribution Record", "Reference (Service Offering, 01)", "", "OFFR-0012", "Internal", "", ""),
       ("Covering Advisor", "Firm advisor of record (03) on the effective date: the primary coverage (Primary Coverage Indicator = Y) resolved at account, then client, then household scope.", "Attribution Record", "Reference (Advisor, 03)", "", "EMP-20417", "Internal", "", "Y", "PII (employee). Derived from Advisor Coverage Assignment (CW-063)."),
       ("Advisor Coverage Assignment", "03 party coverage assignment that names the advisor of record by the same precedence; for IA direct mandates the assignment with role Relationship Manager, which also sources IA salesperson credit.", "Attribution Record", "Reference (Party Coverage Assignment, 03)", "", "CVA-1093345", "Internal", "", ""),
       ("Client Household", "02 Client Household the account belongs to on the effective date.", "Attribution Record", "Reference (Party)", "", "PTY-HH-55012", "Internal", "", "", "PII"),
       ("Retirement Plan", "Retirement plan credited for workplace flows and assets.", "Attribution Record", "Reference (Party)", "", "PTY-077120", "Internal", "", ""),
       ("Institutional Client", "Institutional client (12) credited for IA flows and assets.", "Attribution Record", "Reference (Institutional Client, 12)", "", "PTY-301120", "Internal", "", "", "CW-133."),
       ("Consultant", "Investment consultant (05 Consultant Profile) influencing the institutional mandate or plan.", "Attribution Record", "Reference (Consultant Profile, 05)", "", "PTY-100670", "Internal", "", ""),
       ("Attributed Campaign", "04 campaign credited with the acquisition milestone behind the flow.", "Attribution Record", "Reference (Campaign)", "", "CAM-004512", "Internal", "", ""),
       ("Campaign Attribution Weight", "Share of the flow credited to the campaign under the 04 attribution model.", "Attribution Record", "Percentage", "", "40%", "Internal", "", "", "Lever: the window of flows after the milestone that the weight covers (default: the funding flow of the milestone only). Derived copy of 04 Attributed Outcome.Attribution Weight; 06 applies it to the flow to give Net New Assets by campaign (CW-085)."),
       ("Source Attributed Outcome", "04 attributed outcome (milestone x campaign x model) whose weight the record applies.", "Attribution Record", "Reference (Attributed Outcome, 04)", "", "PTY-104588 / ACCOUNT_FUNDED / 2026-10-09 / CAM-004512", "Internal", "", ""),
     ]),
     ("Salesperson Credit", [
       ("Credited Salesperson", "Employee credited for an IC or IA amount: wholesalers and platform, consultant and recordkeeper relationship managers from 05, institutional relationship managers of direct mandates from 03.", "Attribution Record", "Reference (Employee)", "", "EMP-00412", "Internal", "", "Y", "Object PII tier: PII - identity (employee). PII (employee)"),
       ("Source Partner Coverage Assignment", "05 partner coverage assignment that names the credited employee and role for IC and consultant-led amounts; blank for IA direct mandates, whose credit reads Advisor Coverage Assignment (03).", "Attribution Record", "Reference (Partner Coverage Assignment, 05)", "", "PCVG-004512", "Internal", "", "Y", "Replaces the 07 crediting rule (CW-143)."),
       ("Credit Split %", "Share of the attributed amount credited to the salesperson.", "Attribution Record", "Percentage", "", "50%", "Internal", "", ""),
       ("Credit Role", "Role in which the salesperson is credited, copied from the coverage assignment.", "Attribution Record", "Code", "External (05 Partner Coverage Role; 03 Coverage Role)", "External Wholesaler", "Internal", "", ""),
     ]),
   ]),
   ("Method & Confidence", "How the attribution was derived and how reliable it is.", [
     ("Attribution Method", [
       ("Attribution Method", "Method used to derive the attribution.", "Attribution Record", "Code", "Attribution Method", "Account-Keyed", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Attribution Source", "Feed whose data drove the attribution (may differ from the source of the transaction).", "Attribution Record", "Reference (Feed)", "", "FEED-011", "Internal", "", ""),
       ("Match Confidence Band", "Banded confidence for reporting.", "Attribution Record", "Code", "Match Confidence Band", "Not Applicable", "Internal", "", ""),
       ("Allocation Basis", "Basis used when amounts are allocated or estimated rather than directly observed.", "Attribution Record", "Code", "Allocation Basis", "Pro-Rata Prior Period Known Assets", "Internal", "", ""),
     ]),
   ]),
   ("Unattributed Assets", "Amounts that cannot be attributed below a given level, held in suspense.", [
     ("Unattributed Item", [
       ("Unattributed Item ID", "Unique identifier of the suspense item.", "Unattributed Item", "Identifier", "", "UNA-2026-09-000412", "Internal", "", "", "Object PII tier: No PII."),
       ("Lowest Resolved Level", "Lowest dimension level to which the amount could be attributed.", "Unattributed Item", "Code", "Attribution Dimension", "Distributor Firm", "Internal", "", ""),
       ("Unattributed Reason", "Why the amount could not be fully attributed.", "Unattributed Item", "Code", "Unattributed Reason", "Unmatched Rep Code", "Internal", "", "Y"),
       ("Unattributed Amount", "Amount held in suspense.", "Unattributed Item", "Amount", "", "USD 2,450,000.00", "Internal", "", "Y"),
       ("Suspense Channel", "Channel bucket that holds the amount until resolved (not a territory, CW-143).", "Unattributed Item", "Code", "Distribution Channel", "Intermediary", "Internal", "", ""),
       ("First Seen Date", "Date the item first became unattributed (for aging).", "Unattributed Item", "Date", "ISO 8601", "2026-07-31", "Internal", "", ""),
       ("Resolution Status", "Work status of the item.", "Unattributed Item", "Code", "Resolution Status", "Under Investigation", "Internal", "", ""),
     ]),
   ]),
   ("Overrides", "Manual changes to engine-derived attribution or channel assignment.", [
     ("Attribution Override", [
       ("Override ID", "Unique identifier of the override.", "Override", "Identifier", "", "OVR-000318", "Internal", "", "", "Object PII tier: No PII."),
       ("Override Scope", "What the override applies to (single record, account, rep code, office, plan); channel changes are Account Channel Assignment versions.", "Override", "Code", "Override Scope", "Rep Code", "Internal", "", ""),
       ("Override Reason", "Business reason for the override.", "Override", "Code", "Override Reason", "Rep Moved Firms - Book Transferred", "Internal", "", "Y"),
       ("Override Value", "Dimension and new value applied (e.g. Advisor / Rep -> PTY-301990).", "Override", "Text", "", "Advisor / Rep: PTY-301177 -> PTY-301990", "Internal", "", ""),
       ("Approved By", "Person approving the override (segregated from the requester where it affects incentive compensation in 03).", "Override", "Reference (Employee)", "", "EMP-00031", "Internal", "", ""),
       ("Override Effective From", "First business date the override applies.", "Override", "Date", "ISO 8601", "2026-09-01", "Internal", "", ""),
       ("Override Effective To", "Last business date the override applies.", "Override", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Identity Resolution & Rep Matching", "TX-IDR",
  "Rules and results that map the firm, office, rep, plan and account identifiers delivered by intermediary feeds (sub-accounting, Omni/SERV, aggregator, sponsor and third-party recordkeeper files) to 05 profiles, 02 parties and 15 accounts. Internal books arrive keyed by ACC- and PTY- and are joined by key (CW-144).",
  [
   ("Source Identifier Crosswalk", "Feed-specific identifiers and the party or account they resolve to.", [
     ("Identifier Crosswalk", [
       ("Crosswalk ID", "Unique identifier of the crosswalk entry.", "Identifier Crosswalk", "Identifier", "", "XWK-0041882", "Internal", "", "", "Object PII tier: PII - identity (external advisor names and addresses)."),
       ("Source Feed", "Intermediary feed in which the identifier occurs.", "Identifier Crosswalk", "Reference (Feed)", "", "FEED-003", "Internal", "", ""),
       ("Source Identifier Type", "Type of identifier delivered.", "Identifier Crosswalk", "Code", "Intermediary Identifier Type", "Firm Rep ID", "Internal", "", ""),
       ("Source Identifier Value", "Identifier exactly as delivered (composite keys concatenated in agreed order).", "Identifier Crosswalk", "Identifier", "", "0158|A27|RJ4471", "Internal", "", "Y"),
       ("Source Name Text", "Name delivered with the identifier.", "Identifier Crosswalk", "Text", "", "SMITH JANE A", "Internal", "", "", "PII"),
       ("Source Address / ZIP Code", "Address or ZIP Code delivered with the identifier, used as a match key.", "Identifier Crosswalk", "Text", "", "02110", "Internal", "", "", "PII where for an individual"),
       ("Resolved Party", "Party (02) the identifier resolves to; its 05 profile gives the role.", "Identifier Crosswalk", "Reference (Party)", "", "PTY-301177", "Internal", "", "Y"),
       ("Resolved Account", "Account the identifier resolves to, for account-level keys.", "Identifier Crosswalk", "Reference (Account)", "", "ACC-0000415", "Internal", "", ""),
       ("Resolved CRD Number", "FINRA CRD of the matched financial professional or firm, copied for audit (master in 02 US Regulatory Identifier).", "Identifier Crosswalk", "Identifier", "External (FINRA CRD)", "4417720", "FINRA BrokerCheck / CRD", "", "", "Authoritative identifier held in 02 (Firm CRD Number, Individual CRD Number)."),
       ("Crosswalk Effective From", "First date the mapping applies.", "Identifier Crosswalk", "Date", "ISO 8601", "2024-03-01", "Internal", "", ""),
       ("Crosswalk Effective To", "Last date the mapping applies (e.g. the rep left the firm).", "Identifier Crosswalk", "Date", "ISO 8601", "2026-08-31", "Internal", "", ""),
     ]),
   ]),
   ("Match Rules", "Configured rules used to resolve identifiers.", [
     ("Match Rule", [
       ("Match Rule ID", "Identifier of the rule.", "Match Rule", "Identifier", "", "MRL-012", "Internal", "", "", "Object PII tier: No PII."),
       ("Match Rule Type", "Deterministic, probabilistic or manual.", "Match Rule", "Code", "Match Rule Type", "Deterministic", "Internal", "", ""),
       ("Match Keys", "Fields compared by the rule.", "Match Rule", "Text", "", "CRD; Last Name; First Initial; ZIP5", "Internal", "", ""),
       ("Auto-Accept Threshold", "Score at or above which a match is accepted without review.", "Match Rule", "Integer", "", "90", "Internal", "", ""),
       ("Review Threshold", "Score at or above which a match is queued for steward review.", "Match Rule", "Integer", "", "70", "Internal", "", ""),
       ("Applicable Feeds", "Intermediary feeds the rule applies to.", "Match Rule", "Reference (Feed)", "", "FEED-003; FEED-011", "Internal", "", ""),
     ]),
   ]),
   ("Match Results", "Outcome and audit trail of each match.", [
     ("Match Result", [
       ("Match Status", "Current state of the match.", "Identifier Crosswalk", "Code", "Match Status", "Matched - Auto", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Match Source", "Evidence used to make the match.", "Identifier Crosswalk", "Code", "Match Source", "CRD Exact", "Internal", "", ""),
       ("Match Rule Applied", "Rule that produced the match.", "Identifier Crosswalk", "Reference (Match Rule)", "", "MRL-012", "Internal", "", ""),
       ("Match Score", "Score (0-100) produced by the rule.", "Identifier Crosswalk", "Integer", "", "96", "Internal", "", ""),
       ("Match Date", "Date the match was made or last confirmed.", "Identifier Crosswalk", "Date", "ISO 8601", "2026-09-19", "Internal", "", ""),
       ("Rejection Reason", "Reason a suggested match was rejected.", "Identifier Crosswalk", "Text", "", "Same name, different CRD and state", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Data Sources & Feeds", "TX-FED",
  "Master of every data source that delivers flows, fund shareholder positions, client balances or attribution detail to 06 (FEED-): the internal books of record (49, 50, 29, 16, 18) and the intermediary feeds; and metadata of each file or load received.",
  [
   ("Feed Master", "Descriptive and contractual reference data for each feed.", [
     ("Data Feed", [
       ("Feed ID", "Unique identifier of the feed.", "Feed", "Identifier", "", "FEED-003", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Feed Name", "Business name of the feed.", "Feed", "Text", "", "NSCC Omni/SERV Activity - Firm X", "Internal", "", ""),
       ("Data Provider", "Organization or internal book delivering the data (intermediary, aggregator, recordkeeper, sponsor, or the firm's own entity).", "Feed", "Reference (Party)", "", "PTY-100001", "Internal", "", "Y"),
       ("Feed Type", "Category of source.", "Feed", "Code", "Feed Type", "Intermediary Sub-Accounting", "Internal", "", "Y"),
       ("Data Content", "Kinds of data the feed carries.", "Feed", "Code (multi)", "Data Content", "Transactions; Positions", "Internal", "", ""),
       ("Delivery Frequency", "How often the feed is delivered.", "Feed", "Code", "Frequency", "Daily", "Internal", "", ""),
       ("File Format", "Format of the delivered data.", "Feed", "Code", "File Format", "Fixed-Width (DTCC layout)", "ISO 20022", "", ""),
       ("Message Standard", "Message or record standard used.", "Feed", "Code", "Message Standard", "DTCC Omni/SERV Activity Record", "DTCC Omni/SERV", "ISO 20022", ""),
       ("Feed Grain", "Lowest level of detail the feed provides.", "Feed", "Code", "Feed Grain", "Sub-Account", "Internal", "", ""),
       ("Coverage - Channels", "Channels covered.", "Feed", "Code (multi)", "Distribution Channel", "Intermediary - Wirehouse; Intermediary - Independent Broker-Dealer", "Internal", "", ""),
       ("Governing Agreement", "Data-licensing, networking or sub-accounting agreement governing an intermediary feed (owned by 05).", "Feed", "Reference (Agreement)", "", "AGR-000177", "Internal", "", ""),
       ("License Use Restriction", "Permitted use of the data under the license, copied from 14.", "Feed", "Code (multi)", "External (14 Permitted Use Category)", "Internal Use - Display", "Internal", "", ""),
       ("Feed Status", "Lifecycle status of the feed.", "Feed", "Code", "Feed Status", "Production", "Internal", "", ""),
       ("Source Precedence Rank", "Default rank of the feed in the source hierarchy for attribution.", "Feed", "Integer", "1-7", "3", "Internal", "", ""),
     ]),
   ]),
   ("File & Load Metadata", "Each file or batch received and its processing outcome.", [
     ("Load", [
       ("Load ID", "Identifier of the load.", "Load", "Identifier", "", "LOAD-20260919-FEED003-01", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Feed", "Feed the load belongs to.", "Load", "Reference (Feed)", "", "FEED-003", "Internal", "", ""),
       ("File Name", "Name of the file received.", "Load", "Text", "", "OMNIACT_0158_20260918.dat", "Internal", "", ""),
       ("Business Date", "Business or as-of date the data relates to.", "Load", "Date", "ISO 8601", "2026-09-18", "Internal", "", "Y"),
       ("Record Count", "Records in the file.", "Load", "Integer", "", "48,221", "Internal", "", ""),
       ("Control Total", "Header or trailer control total (amount or units) delivered with the file.", "Load", "Decimal", "", "112,483,901.22", "Internal", "", ""),
       ("Rejected Record Count", "Records rejected on validation.", "Load", "Integer", "", "14", "Internal", "", ""),
       ("Load Status", "Processing and completeness status of the load, including expected files that are late, partial or missing.", "Load", "Code", "Load Status", "Loaded with Warnings", "Internal", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Data Quality & Reconciliation", "TX-DQR",
  "Reconciliations of 06 data to its sources (intermediary feeds to the 29 register; Account Asset Summary and Fund Shareholder Position totals to 49, 16, 18 and 29; flows to the asset roll-forward) and their breaks. Data quality rules and results are mastered in 21 (CD-156); the 49-to-29 omnibus reconciliation is 49 Stock Record Reconciliation.",
  [
   ("Reconciliation Definition", "What is reconciled to what, at which grain and tolerance.", [
     ("Reconciliation", [
       ("Reconciliation ID", "Identifier of the reconciliation.", "Reconciliation", "Identifier", "", "RCN-007", "Internal", "", "", "Object PII tier: No PII."),
       ("Reconciliation Name", "Business name.", "Reconciliation", "Text", "", "Omnibus shares: TA register vs Omni/SERV position", "Internal", "", ""),
       ("Reconciliation Type", "Category of reconciliation.", "Reconciliation", "Code", "Reconciliation Type", "Client Asset Summary vs Source Book", "Internal", "", "Y"),
       ("Left Source", "First source compared.", "Reconciliation", "Reference (Feed)", "", "FEED-001", "Internal", "", ""),
       ("Right Source", "Second source compared.", "Reconciliation", "Reference (Feed)", "", "FEED-003", "Internal", "", ""),
       ("Comparison Grain", "Level at which values are compared.", "Reconciliation", "Code", "Feed Grain", "Account x Share Class", "Internal", "", ""),
       ("Compared Measure", "Value compared (units, market value, flows).", "Reconciliation", "Code", "Compared Measure", "Market Value", "Internal", "", ""),
       ("Absolute Tolerance", "Maximum absolute difference accepted.", "Reconciliation", "Decimal", "", "0.001 units", "Internal", "", "Y"),
       ("Relative Tolerance %", "Maximum relative difference accepted.", "Reconciliation", "Percentage", "", "0.05%", "Internal", "", ""),
       ("Reconciliation Frequency", "How often the reconciliation runs.", "Reconciliation", "Code", "Frequency", "Daily", "Internal", "", ""),
     ]),
     ("Reconciliation Run", [
       ("Run Business Date", "Business date reconciled.", "Reconciliation", "Date", "ISO 8601", "2026-09-30", "Internal", "", "", "Object PII tier: No PII."),
       ("Matched %", "Proportion of items within tolerance.", "Reconciliation", "Percentage", "", "99.82%", "Internal", "", "Y"),
     ]),
   ]),
   ("Breaks", "Differences outside tolerance and their resolution.", [
     ("Break", [
       ("Break ID", "Identifier of the break.", "Break", "Identifier", "", "BRK-2026-09-30-00045", "Internal", "", "", "Object PII tier: No PII (account keys only)."),
       ("Break Type", "Nature of the difference.", "Break", "Code", "Break Type", "Units Difference", "Internal", "", ""),
       ("Difference Amount", "Value of the difference in USD.", "Break", "Amount", "", "USD 184,220.10", "Internal", "", "Y"),
       ("Root Cause Category", "Root cause once investigated.", "Break", "Code", "Root Cause Category", "Timing (Late Trade)", "Internal", "", ""),
       ("Break Status", "Work status.", "Break", "Code", "Break Status", "Open", "Internal", "", "Y"),
       ("Break Age (Days)", "Days since the break first appeared.", "Break", "Integer", "Days", "3", "Internal", "", ""),
       ("Resolution Action", "Action taken to resolve.", "Break", "Text", "", "Intermediary resent position file; shares agreed", "Internal", "", ""),
       ("Resolution Date", "Date the break was closed.", "Break", "Date", "ISO 8601", "2026-10-02", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Reporting Periods, Snapshots & Restatements", "TX-SNP",
  "Reporting calendar, locked as-of snapshots of attributed flows and client assets, and governed restatements after lock.",
  [
   ("Reporting Calendar", "Periods and close dates for flow and client asset reporting.", [
     ("Reporting Period", [
       ("Reporting Period ID", "Identifier of the period.", "Snapshot", "Identifier", "", "2026-09", "Internal", "", "", "Object PII tier: No PII."),
       ("Period Type", "Type of period.", "Snapshot", "Code", "Period Type", "Month", "Internal", "", ""),
       ("Final Close Date", "Date results are locked as final.", "Snapshot", "Date", "ISO 8601", "2026-10-15", "Internal", "", "Y"),
     ]),
   ]),
   ("Snapshots", "Immutable versions of results at a point in time.", [
     ("Snapshot", [
       ("Snapshot ID", "Identifier of the snapshot.", "Snapshot", "Identifier", "", "SNP-2026-09-M-FINAL", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Snapshot Type", "Stage of the snapshot, which also gives its lock status: Flash and Preliminary are open, Final and Restated are locked; a replaced snapshot is superseded through Supersedes Snapshot.", "Snapshot", "Code", "Snapshot Type", "Final", "Internal", "", "Y"),
       ("As-Of Date", "Business date the snapshot represents.", "Snapshot", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
       ("Supersedes Snapshot", "Earlier snapshot this one replaces.", "Snapshot", "Reference (Snapshot)", "", "SNP-2026-09-M-PRELIM", "Internal", "", ""),
       ("Approved By", "Person who signed off the snapshot.", "Snapshot", "Reference (Employee)", "", "EMP-00031", "Internal", "", ""),
     ]),
   ]),
   ("Restatements", "Governed changes to locked results.", [
     ("Restatement", [
       ("Restatement ID", "Identifier of the restatement.", "Restatement", "Identifier", "", "RSM-2026-004", "Internal", "", "", "Object PII tier: No PII."),
       ("Restatement Reason", "Why the locked period is restated.", "Restatement", "Code", "Restatement Reason", "Late Source Data", "Internal", "", ""),
       ("Affected Periods", "Periods restated.", "Restatement", "Text", "", "2026-07; 2026-08", "Internal", "", ""),
       ("Net Impact Amount", "Net change to the measure or measures restated.", "Restatement", "Amount", "", "USD 12.4m", "Internal", "", "Y"),
       ("Compensation Impact Indicator", "Whether the restatement changes attributed amounts already used in 03 incentive compensation statements.", "Restatement", "Boolean", "", "Y", "Internal", "", "Y"),
       ("Restatement Approved By", "Approver.", "Restatement", "Reference (Employee)", "", "EMP-00031", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Transaction Type": ("Internal (aligned to ICI flow components, ISO 20022 setr order types, FINRA Rule 11870 and IRC rollover rules); mutually exclusive business types: the mechanism is Transfer Type, the money source Contribution Source Type", [
   ("Purchase","Own-fund subscription (setr.010 Subscription Order)"),("Redemption","Own-fund redemption (setr.004 Redemption Order)"),
   ("Exchange In","Switch into an own fund (setr.013 Switch Order, buy leg)"),("Exchange Out","Switch out of an own fund (sell leg)"),
   ("Transfer In","TA re-registration of own-fund shares into a direct registered account (29)"),("Transfer Out","TA re-registration of own-fund shares out of a direct registered account (29)"),
   ("Reinvestment","Dividend or capital gain reinvested"),("Share Class Conversion","Exchange between classes of the same fund"),
   ("ETF Creation","Authorized-participant creation of own-ETF shares"),("ETF Redemption","Authorized-participant redemption of own-ETF shares"),
   ("Cash Deposit","ACH, wire or check deposit, as posted in 49 (the 50 movement is lineage only)"),("Cash Withdrawal","ACH, wire or check withdrawal, as posted in 49"),
   ("ACATS Transfer In","Account transfer received through ACATS (49)"),("ACATS Transfer Out","Account transfer delivered through ACATS (49)"),
   ("Securities Received","Securities received in kind outside ACATS (49)"),("Securities Delivered","Securities delivered in kind outside ACATS (49)"),
   ("Journal In","Cash or securities journaled in from another firm account"),("Journal Out","Cash or securities journaled out to another firm account"),
   ("Rollover In","Rollover receipt into an IRA or plan (IRC 402(c), 408(d)(3)); takes precedence over Cash Deposit and Securities Received"),("Rollover Out","Rollover distribution from an IRA or plan"),
   ("Plan Contribution","Workplace plan contribution invested (16)"),("Plan Distribution","Workplace plan withdrawal or distribution (16)"),
   ("Fee Debit","Advisory or account fee debited from a client account"),("Income Received","Dividend, interest or capital gain distribution paid in cash to a client account; excluded from Net New Assets by default (Income Treatment)"),("Tax Withholding","Federal or state tax withheld from a distribution or payment"),("Inter-Channel Transfer","Generated row moving an account's assets between channels on a new Account Channel Assignment"),
   ("SMA Contribution","Cash or securities added to a third-party sponsor program account"),("SMA Withdrawal","Cash or securities withdrawn from a third-party sponsor program account"),
   ("Mandate Funding","Institutional mandate initial funding or top-up (18)"),("Mandate Withdrawal","Institutional mandate partial or full termination (18)"),
   ("Fund Merger In","Shares received from a merged fund"),("Fund Merger Out","Shares removed by fund merger"),("Adjustment","Non-trade adjustment")]),
 "Flow Direction": ("Internal", [("Inflow",""),("Outflow",""),("Neutral","No change to client or fund assets, e.g. conversion")]),
 "Flow Scope": ("Internal (CW-141)", [("Inter-Channel Transfer","Between firm accounts or channels of one account; never Net New Assets"),("Client Asset Flow","External flow of a client account; counts toward Net New Assets"),("Fund Flow","Purchase or redemption of an own fund; counts toward fund flow measures"),("Client Asset and Fund Flow","Both, e.g. a new-money purchase of an own fund in a fund-only account")]),
 "Holding Type": ("Internal (CW-142); each value names its CW-011 holding type (own funds, third-party funds, securities, cash)", [("Own Mutual Fund","CW-011: Own Funds"),("Own ETF","CW-011: Own Funds"),("Own CIT","CW-011: Own Funds; collective investment trust of the firm's trust company or bank partner"),("Third-Party Mutual Fund","CW-011: Third-Party Funds"),("Third-Party ETF","CW-011: Third-Party Funds"),("Equity","CW-011: Securities"),("Fixed Income and CDs","CW-011: Securities"),("Options","CW-011: Securities"),("Cash and Sweep","CW-011: Cash; free credit, bank sweep and money market sweep balances, net of margin debit"),("Alternative Feeder","CW-011: Third-Party Funds; feeder fund interests (01 vehicle Feeder Fund)"),("Other","CW-011: Securities")]),
 "Source Book": ("Internal (CW-141)", [("Brokerage Book of Record (49)","Client Holdings, Account Cash Balance and client account activity; 50 sweep allocations read through it"),("Transfer Agent Register (29)","Share Register Balance and Register Transaction"),("Workplace Recordkeeping (16)","Participant balances, contributions, distributions"),("Institutional Portfolio Book (18)","Portfolio valuation and capital activity"),("Fund Shareholder Position (06)","06 view of the 29 register, for Account Asset Summary rows"),("Account Channel Assignment (06)","Generated inter-channel transfer rows"),("Intermediary Feed","Intermediary sub-account rows, mastered here as delivered")]),
 "Look-Through Level": ("Internal (aligned to DTCC Networking / Omni/SERV)", [
   ("Firm Client Account","Account carried by the firm's broker-dealer or transfer agent with full client detail"),("Networked Account","Account on the TA register serviced via NSCC Networking"),
   ("Omnibus Aggregate","Omnibus or nominee account on the register, no underlying detail"),("Omnibus Sub-Account","Underlying sub-account reported by the intermediary"),
   ("Plan Level","Third-party recordkept plan totals from the recordkeeper"),("Sponsor Program Level","SMA, UMA or model totals from the sponsor"),
   ("Aggregator Estimate","Firm, office or rep level data from a third-party aggregator")]),
 "Order Entry Channel": ("Shared Dealing Route (steward 06; re-cut by CW-140; labels as 29)", [("NSCC Fund/SERV",""),("NSCC DCC&S","Defined Contribution Clearance & Settlement"),("NSCC CNS / ETF Portal","ETF creations and redemptions"),("Affiliated Broker-Dealer Omnibus","Aggregated orders from the firm's broker-dealer omnibus account to its transfer agent"),("TA Direct","Web, phone, fax, email or mail direct to the TA"),("Recordkeeper File",""),("Sponsor File","SMA / UMA sponsor")]),
 "Intermediary Identifier Type": ("Internal", [("NSCC Dealer Number",""),("NSCC Branch ID",""),("Firm Rep ID","Firm-specific rep code"),("FINRA CRD",""),("SEC / IARD Number",""),("LEI","ISO 17442"),("Aggregator Firm / Office / Rep ID","Broadridge, ISS MI or similar"),("Recordkeeper Plan ID",""),("Sponsor Advisor ID","")]),
 "Transfer Type": ("Internal (FINRA Rule 11870; IRC 402(c), 408(d)(3))", [("ACATS","Automated Customer Account Transfer Service"),("Non-ACATS Transfer","Transfer agent, bank or other non-ACATS transfer"),("Re-Registration",""),("Intra-Firm",""),("Estate / Transmission",""),("Direct Rollover","Plan-to-IRA direct rollover"),("Trustee-to-Trustee Transfer","IRA-to-IRA transfer")]),
 "Transaction Status": ("ISO 20022 (order status) / Internal", [("Received",""),("Pending",""),("Confirmed",""),("Settled",""),("Canceled",""),("Reversed",""),("Rejected","")]),
 "Cancel Correct Indicator": ("ISO 20022", [("New",""),("Cancel",""),("Correct",""),("Reversal","")]),
 "Correction Reason": ("Internal", [("NAV Error",""),("Processing Error",""),("Client Request",""),("Duplicate",""),("Late Trading Reversal",""),("Wrong Share Class","")]),
 "Position Basis": ("Internal", [("Trade Date",""),("Settlement Date","")]),
 "Look-Through Source": ("Internal", [("Omni/SERV Position File",""),("Intermediary Proprietary File",""),("Aggregator","")]),
 "ETF Holdings Source": ("Internal", [("Aggregator Broker Data",""),("Depository Participant Report",""),("Broker Direct Feed",""),("13F Filings","Quarterly institutional holdings"),("Estimate","")]),
 "Feed Grain": ("Internal", [("Fund Total",""),("Distributor Firm",""),("Office",""),("Advisor",""),("Account",""),("Sub-Account",""),("Plan",""),("Program",""),("Account x Share Class",""),("Account x Holding Type","")]),
 "Measure Category": ("Internal", [("Flow",""),("Asset",""),("Client Assets","Certified Client Assets, Net New Assets and Advised Assets (CW-011)"),("Revenue Estimate","Analytic estimate; booked revenue is 10"),("Ratio","")]),
 "Aggregation Behavior": ("Internal", [("Additive","Sum across time and dimensions"),("Semi-Additive","Sum across dimensions, not time (e.g. Client Assets)"),("Non-Additive","Recalculate, do not sum (rates, %)")]),
 "Time Basis": ("Internal", [("Trade Date",""),("Settlement Date",""),("As-Of Date",""),("Processing Date",""),("Valuation Date","")]),
 "Treatment Option": ("Internal", [("Include in Gross",""),("Net Only",""),("Exclude from Sales (Market Movement)",""),("Exclude (Same Owner)",""),("Exclude at Product Level","Count at share-class level only"),("Exclude (Report Separately)",""),("Include",""),("Count as Net New Assets",""),("Exclude (Market Movement and Other)","Shown in market movement and other, not Net New Assets"),("Inter-Channel Transfer (Zero Firm-Wide)","Outflow of the old channel and inflow of the new; zero firm-wide")]),
 "ETF Flow Basis": ("Morningstar / ICI", [("Primary Market Creations / Redemptions",""),("Shares Outstanding Change x NAV",""),("Aggregator Broker Holdings Change","")]),
 "Period Type": ("Internal", [("Day",""),("Week",""),("Month",""),("Quarter",""),("Year",""),("Year-to-Date",""),("Rolling 12 Months","")]),
 "Data Basis": ("Internal", [("Actual",""),("Estimated",""),("Allocated",""),("Mixed","")]),
 "Attribution Dimension": ("Internal", [("Share Class",""),("Product",""),("Service Offering",""),("Business Line",""),("Distribution Channel",""),("Holding Type",""),("Firm Advisor","03 advisor covering the client"),("Client Household",""),("Distributor Firm",""),("Distributor Office",""),("Advisor Team",""),("Financial Professional","External advisor (05)"),("Retirement Plan",""),("Institutional Client",""),("Consultant",""),("Campaign",""),("Salesperson","")]),
 "Aggregation Role": ("Internal (program-lead ruling on the 06 review)", [("Counted - Firm Client Account","49 rows and 29 rows of direct registered accounts"),("Counted - Intermediary","Networked register rows and intermediary look-through rows"),("Excluded - Omnibus or Nominee","Broker-dealer omnibus, DTC nominee, intermediary omnibus aggregate and plan omnibus rows; control only"),("Excluded - Firm Proprietary","Seed and error accounts"),("Attribution Only","Sponsor-reported totals that attribute counted rows")]),
 "Dimension Type": ("Internal (CW-011, CW-143)", [("Total",""),("Channel",""),("Holding Type",""),("Business Line",""),("Advisor","Firm advisor of record (03)"),("Campaign","04 campaign"),("Share Class",""),("Segment","02 client segment")]),
 "Distribution Channel": ("Shared Distribution Channel (steward 09; re-cut by CW-164, refined by CW-140)", [
   ("Direct","Level 1: clients served directly by the firm"),("Direct - Self-Directed","DB, including fund-only accounts"),("Direct - Digital Advice","DA"),("Direct - Human Advice","HA, including hybrid"),("Direct - Trust","TR"),
   ("Workplace","Level 1: plans the firm recordkeeps"),("Workplace - Recordkept Plan","WR"),
   ("Institutional","Level 1: institutional advisory (IA)"),("Institutional - Direct",""),("Institutional - Consultant-Led",""),("Institutional - OCIO",""),
   ("Intermediary","Level 1: own funds and models held through third parties (IC)"),("Intermediary - Wirehouse",""),("Intermediary - National / Regional Broker-Dealer",""),("Intermediary - Independent Broker-Dealer",""),("Intermediary - RIA",""),("Intermediary - Bank / Trust",""),("Intermediary - TAMP / Model Marketplace",""),("Intermediary - Brokerage Platform","Third-party brokerage and fund platforms"),("Intermediary - Third-Party Recordkeeper","Own funds in plans recordkept by others (CW-139)")]),
 "Business Line": ("Shared Business Line (steward 09; CW-004)", [("DB","Direct brokerage and self-directed investing"),("DA","Digital advice"),("HA","Human and hybrid advice"),("PF","Proprietary funds and ETFs, including CITs"),("WR","Workplace retirement recordkeeping"),("IA","Institutional advisory"),("IC","Intermediary channel"),("TR","Personal trust services")]),
 "Channel Assignment Basis": ("Internal (CW-142)", [("Account Type","15 account type (brokerage, fund-only, participant, institutional separate)"),("Program Enrollment","15 enrollment in an advice, managed or trust program"),("Workplace Plan","16 plan membership of a participant account"),("Partner Agreement","05 agreement of an intermediary omnibus, networked or sponsor account"),("Institutional Mandate","Institutional advisory mandate (01, 12)"),("Manual Assignment","Override with approval")]),
 "Source Record Type": ("Internal", [("Transaction",""),("Fund Shareholder Position",""),("Account Asset Summary",""),("Measure Value","")]),
 "Attribution Method": ("Internal", [("Account-Keyed","Internal book keyed by ACC- and PTY-; joined, not matched (CW-144)"),("Direct","Rep codes on TA or networked account"),("Rep-Matched","Source rep code matched to a 05 profile"),("Look-Through","Omnibus sub-account detail"),("Aggregator","Third-party distribution data"),("Allocated","Known total split by an allocation basis"),("Estimated","Modeled where no detail exists"),("Manual Override","")]),
 "Match Confidence Band": ("Internal", [("High","Score >= 90 or deterministic key"),("Medium","70-89"),("Low","< 70"),("Not Applicable","Account-keyed rows")]),
 "Allocation Basis": ("Internal", [("Pro-Rata Prior Period Known Assets",""),("Pro-Rata Aggregator Share",""),("Equal Split",""),("Coverage Assignment","Per 03 Party Coverage Assignment or 05 Partner Coverage Assignment")]),
 "Unattributed Reason": ("Internal", [("Unmatched Rep Code",""),("Missing Rep Code",""),("Omnibus No Look-Through",""),("ETF Unknown Holder",""),("Late / Missing Feed",""),("Party Not in Master",""),("No Channel Assignment","Account without an Account Channel Assignment on the date")]),
 "Resolution Status": ("Internal", [("New",""),("Under Investigation",""),("Awaiting Source",""),("Resolved",""),("Written Off to House","")]),
 "Override Scope": ("Internal", [("Single Record",""),("Account",""),("Rep Code",""),("Office",""),("Plan","")]),
 "Override Reason": ("Internal", [("Rep Moved Firms - Book Transferred",""),("Team Split Agreement",""),("Data Error at Source",""),("Coverage Exception",""),("Sponsor Correction","")]),
 "Match Rule Type": ("Internal", [("Deterministic",""),("Probabilistic",""),("Manual","")]),
 "Match Status": ("Internal", [("Matched - Auto",""),("Matched - Manual",""),("Suggested",""),("Unmatched",""),("Rejected",""),("Retired","")]),
 "Match Source": ("Internal", [("CRD Exact",""),("Source Key Exact","Previously confirmed crosswalk"),("Name + ZIP Code Fuzzy",""),("Aggregator Mapping",""),("Steward Research",""),("Distributor Confirmation","")]),
 "Feed Type": ("Internal", [("Brokerage Book of Record (49)",""),("Transfer Agent Register (29)",""),("Workplace Recordkeeping (16)",""),("Institutional Portfolio Book (18)",""),("Intermediary Sub-Accounting",""),("Distribution Data Aggregator",""),("ETF Holdings",""),("SMA / UMA Sponsor",""),("Third-Party Recordkeeper","Own funds in plans recordkept by others"),("Fund Platform / Order Network","US brokerage and fund platforms"),("Fund Accounting",""),("Industry Statistics","")]),
 "Data Content": ("Internal", [("Transactions",""),("Positions",""),("Balances",""),("Hierarchy / Reference",""),("Flows (Aggregated)",""),("Assets (Aggregated)","")]),
 "Frequency": ("Internal", [("Intraday",""),("Daily",""),("Weekly",""),("Monthly",""),("Quarterly",""),("Ad Hoc","")]),
 "File Format": ("Internal", [("Fixed-Width (DTCC layout)",""),("Delimited (CSV / Pipe)",""),("XML (ISO 20022)",""),("JSON / API",""),("Database Extract","Internal book of record"),("Excel","")]),
 "Message Standard": ("Shared Message Standard (steward 06)", [("DTCC Fund/SERV",""),("DTCC Networking",""),("DTCC Omni/SERV Activity Record",""),("DTCC Omni/SERV Position Record",""),("ISO 20022 setr",""),("ISO 20022 semt",""),("Vendor Proprietary","")]),
 "Feed Status": ("Internal", [("Planned",""),("Testing",""),("Production",""),("Suspended",""),("Decommissioned","")]),
 "Load Status": ("Internal (merges the former Completeness Status)", [("Expected",""),("Received",""),("Received Late",""),("Partial","Part of the expected records received"),("Missing","Expected file not received"),("Loaded",""),("Loaded with Warnings",""),("Rejected",""),("Superseded","")]),
 "Reconciliation Type": ("Internal", [("TA vs Intermediary Feed","29 omnibus register vs intermediary sub-accounts"),("Client Asset Summary vs Source Book","Account Asset Summary totals vs 49, 16 or 18 totals"),("Broker-Dealer Omnibus vs Client Holdings","Control: 29 Broker-Dealer Omnibus units equal the sum of 49 Client Holdings of the share class (the book reconciliation is 49 Stock Record Reconciliation)"),("Feed vs Feed",""),("Attributed vs Total Assets",""),("Flows vs Asset Roll-Forward","")]),
 "Compared Measure": ("Internal", [("Units",""),("Market Value",""),("Flows",""),("Record Count","")]),
 "Break Type": ("Internal", [("Units Difference",""),("Value Difference",""),("Missing in Left",""),("Missing in Right",""),("Attribute Mismatch","")]),
 "Root Cause Category": ("Internal", [("Timing (Late Trade)",""),("Pricing",""),("Source Error",""),("Mapping Error",""),("Corporate Action / Merger",""),("Unknown","")]),
 "Break Status": ("Internal (member of shared Reconciliation Status, CW-140)", [("Open",""),("Investigating",""),("Resolved",""),("Accepted (Within Materiality)","")]),
 "Snapshot Type": ("Internal (merges the former Snapshot Status)", [("Flash","Open"),("Preliminary","Open"),("Final","Locked"),("Restated","Locked; replaces a Final snapshot")]),
 "Restatement Reason": ("Internal", [("Late Source Data",""),("Source Correction",""),("Attribution Rule Change",""),("Hierarchy Change",""),("Channel Assignment Change",""),("Measure Definition Change",""),("Error","")]),
}

REL = [
 ("Data Feed","delivers","Load","1 : 0..n","One load per file or business date."),
 ("Load","creates","Transaction / Fund Shareholder Position","1 : 0..n","Lineage via Source Feed and Position Source."),
 ("Data Feed","is governed by","Distribution Agreement (05, AGR-)","n : 0..1","Data-licensing, networking or sub-accounting agreement of an intermediary feed."),
 ("Data Feed","is provided by","Party (02, PTY-)","n : 1","Intermediary, aggregator, recordkeeper, sponsor or the firm's own entity."),
 ("Transaction","is copied from","Client Account Activity / Account Transfer (49, CLACT- / ACXF-)","n : 0..1","Brokerage flows (CW-141 row rule)."),
 ("Transaction","is copied from","Register Transaction (29, RGTX-)","n : 0..1","Own-fund flows of direct registered accounts (CW-122); omnibus postings are never loaded."),
 ("Transaction","originates from","Fund Order (29, FNDO-) / AP Creation / Redemption Order (29, ECR-)","n : 0..1",""),
 ("Transaction","is copied from","Participant Ledger Posting (16, PLPST-)","n : 0..1","Workplace flows and rollovers."),
 ("Transaction","is copied from","Portfolio Capital Activity (18)","n : 0..1","Institutional mandate flows."),
 ("Transaction","is for","Share Class (01, SHC-)","n : 0..1","Own-fund flows; blank for cash and other holdings."),
 ("Transaction","is booked to","Account (15, ACC-)","n : 0..1","Aggregator and sponsor data may have no account."),
 ("Transaction","is linked to","Transaction","0..1 : 0..1","Exchange legs, transfers, rollovers, conversions, cancel and correct."),
 ("Fund Shareholder Position","is a view of","Client Holding (49, CLHLD-)","n : 0..1","Brokerage and managed accounts (CW-007)."),
 ("Fund Shareholder Position","is a view of","Share Register Balance (29)","n : 0..1","Every other registered account (CW-122)."),
 ("Fund Shareholder Position","is valued at","Share Class NAV (27, NAV-)","n : 0..1","29 register rows; 49 rows carry the 49 Client Holding Valuation."),
 ("Transaction (Inter-Channel Transfer)","is generated by","Account Channel Assignment","n : 0..1","Amount = Account Asset Summary total on the last day of the old assignment."),
 ("Attribution Record","applies","Attributed Outcome (04)","n : 0..1","Campaign weight (CW-085)."),
 ("Fund Shareholder Position (Omnibus Sub-Account)","rolls up to","Account - Intermediary Omnibus (15, ACC-)","n : 1","Look-through coverage tracked."),
 ("Account Asset Summary","summarizes","Client Holding Valuation and Account Cash Balance (49) / Sweep Allocation (50) / Participant Balance (16) / Portfolio Holding (18) / Fund Shareholder Position","n : n","Firm client accounts only."),
 ("Account Channel Assignment","assigns a channel to","Account (15, ACC-)","n : 1","One channel per account at a time."),
 ("Account Channel Assignment","is based on","Program Enrollment (15, ENRL-)","n : 0..1",""),
  ("Identifier Crosswalk","resolves to","Distributor Firm / Financial Professional (05)","n : 0..1","Intermediary feeds only (CW-144)."),
 ("Identifier Crosswalk","is produced by","Match Rule","n : 0..1",""),
 ("Transaction / Fund Shareholder Position / Account Asset Summary","is attributed by","Attribution Record","1 : 1..n","Split where more than one advisor, team or salesperson."),
 ("Attribution Record","credits","Distributor Firm / Branch / Office / Advisor Team / Financial Professional (05)","n : 0..1 each","IC path (CW-132)."),
 ("Attribution Record","credits","Advisor via Party Coverage Assignment (03, CVA-)","n : 0..1","As of the effective date (CW-063)."),
 ("Attribution Record","credits","Campaign (04, CAM-)","n : 0..1","Weight from 04 Attributed Outcome (CW-085)."),
 ("Attribution Record","credits","Institutional Client (12)","n : 0..1",""),
 ("Attribution Record","credits salesperson via","Partner Coverage Assignment (05, PCVG-) / Employee (20, EMP-)","n : 0..n","IC and IA only."),
 ("Attribution Record","may be changed by","Attribution Override","n : 0..n",""),
 ("Transaction / Fund Shareholder Position","may create","Unattributed Item","1 : 0..1",""),
 ("Measure Definition","is valued as","Measure Value","1 : 0..n",""),
 ("Measure Definition","is registered as","Metric Definition (21)","1 : 1","Certification held in 21."),
 ("Measure Value","belongs to","Snapshot","n : 1",""),
 ("Measure Value (Client Assets, Net New Assets)","is read by","Client Revenue Record and forecasts (10)","n : n","Average asset basis (Derived copies in 10)."),
 ("Snapshot","may be superseded via","Restatement","1 : 0..n","Restatements with compensation impact feed 03 incentive statements."),
 ("Reconciliation","compares","Data Feed (left / right)","n : 2",""),
 ("Reconciliation","raises","Break","1 : 0..n",""),
]

SRC = [
 ("DTCC / NSCC Fund/SERV","DTCC","https://www.dtcc.com/wealth-management-services/mutual-fund-services/fund-serv","Member service; record layouts behind login","Automated order processing and settlement for mutual funds; dealer, branch and rep fields on orders","Transaction core, intermediary as delivered, order entry channel",["DTCC Fund/SERV"]),
 ("DTCC / NSCC Networking (matrix levels)","DTCC","https://www.dtcc.com/wealth-management-services/mutual-fund-services/networking","Member service; layouts behind login","Account-level data exchange between funds and firms; matrix levels 0, 3, 4","Look-Through Level, Networking Matrix Level",["DTCC Networking"]),
 ("DTCC Omni/SERV","DTCC","https://dtcclearning.com/products-and-services/mutual-fund-services/omni-serv.html","Member service; layouts behind login","Omnibus Activity file and Omnibus Position file from sub-accounting firms","Omnibus look-through, sub-account positions and activity",["DTCC Omni/SERV"]),
 ("DTCC Defined Contribution Clearance & Settlement (DCC&S)","DTCC","https://www.dtcc.com/wealth-management-services/mutual-fund-services/defined-contribution-clearance-and-settlement","Member service","Retirement-plan trade processing for funds, CITs and stable value","Plan positions, contribution source",["DTCC DCC&S"]),
 ("FINRA Rule 11870 (Customer Account Transfer Contracts) and DTCC ACATS","FINRA; DTCC","https://www.finra.org/rules-guidance/rulebooks/finra-rules/11870","Regulation; member service","Account transfer obligations and timelines through ACATS","Transaction Type ACATS values, Transfer Type, Source Account Transfer",["FINRA Rule 11870"]),
 ("ISO 20022 investment funds messages (setr order / confirmation, semt.002 statement of holdings, semt.006 statement of fund transactions)","ISO / SWIFT (RA)","https://www.iso20022.org/iso-20022-message-definitions","Free","Order, confirmation, cancellation, status and holdings message definitions","Transaction types, dates, amounts, status, cancel / correct, holdings",["ISO 20022"]),
 ("ICI Monthly Trends in Mutual Fund Investing and Fact Book definitions","Investment Company Institute","https://www.ici.org/monthly-trends-in-mutual-fund-investing","Free (summary); member data","New sales, exchange sales, redemptions, exchange redemptions, net new cash flow; reinvested dividends excluded from new sales","Flow measure definitions and alignment",["ICI"]),
 ("Morningstar Estimated Net Cash Flow methodology","Morningstar","https://www.morningstar.com/content/dam/marketing/shared/research/methodology/765555_Estimated_Net_Cash_Flow_Methodology.pdf","Free methodology; data licensed","Estimated flows from TNA change and returns; reinvestment treatment; ETF shares-outstanding basis","Market Movement, ETF Flow Basis, Data Basis",["Morningstar"]),
 ("SEC Form ADV Part 1A, Item 5.F and instructions (regulatory assets under management)","US SEC","https://www.sec.gov/about/forms/formadv-part1a.pdf","Regulation (confirm path)","How an adviser computes regulatory assets under management","Why Client Assets and Advised Assets differ from RAUM; model-delivery assets",["SEC Form ADV"]),
 ("Internal Revenue Code sections 402(c) and 408(d)(3) (rollovers)","US Code (Cornell LII)","https://www.law.cornell.edu/uscode/text/26/402","Statute (confirm page for 408)","Eligible rollover distributions and IRA rollover contributions","Rollover classification, Rollover Treatment",["IRC Section 402(c)","IRC Section 408(d)(3)"]),
 ("SEC Rule 17Ad-10 (transfer agent recordkeeping)","US SEC (eCFR)","https://www.ecfr.gov/current/title-17/section-240.17Ad-10","Regulation (confirm path)","Transfer agent obligation to post debits and credits to the master securityholder file","Source Register Transaction, Source Share Register Balance",["SEC Rule 17Ad-10"]),
 ("SEC Rule 6c-11 (exchange-traded funds)","US SEC (eCFR)","https://www.ecfr.gov/current/title-17/section-270.6c-11","Regulation (confirm path)","ETF conditions including custom baskets","ETF basket type",["SEC Rule 6c-11"]),
 ("Broadridge Distribution Insight / Sales & Asset Reporting","Broadridge","https://www.broadridge.com/financial-services/asset-management/mutual-funds-etf/access-unique-distribution-insights/sales-and-asset-reporting","Licensed","Intermediary sales and assets by firm, office and advisor; ETF positions by distributor","Intermediary attribution dimensions, aggregator feeds, ETF holdings",["Broadridge"]),
 ("ISS Market Intelligence Simfund","ISS Market Intelligence","https://www.issmarketintelligence.com","Licensed","Industry fund, ETF and CIT flows and assets","Industry flow benchmarks (held in 11 Market & Competitive Intelligence)",[]),
 ("SS&C DST TA2000 / FAN Mail / sub-accounting","SS&C Technologies","https://www.ssctech.com/solutions/subaccounting","Licensed","TA recordkeeping, as-of trades, intermediary data distribution","Source transaction codes, as-of dates, dealer IDs",["SS&C DST"]),
 ("SEC Rule 22c-2 (shareholder information agreements)","US SEC (eCFR)","https://www.ecfr.gov/current/title-17/section-270.22c-2","Regulation (confirm path; adopting release not confirmed)","Omnibus intermediaries to provide underlying shareholder ID, transaction type, amount and date on request","Omnibus sub-account identifiers",["SEC Rule 22c-2"]),
 ("FINRA BrokerCheck / CRD","FINRA","https://brokercheck.finra.org","Public lookup","Registered representative and firm identifiers","Rep matching (CRD)",["FINRA BrokerCheck / CRD"]),
 ("GIPS Standards (firm / composite assets)","CFA Institute","https://www.gipsstandards.org","Free","Definitions of assets and valuation","Asset measure framing",["GIPS"]),
]
