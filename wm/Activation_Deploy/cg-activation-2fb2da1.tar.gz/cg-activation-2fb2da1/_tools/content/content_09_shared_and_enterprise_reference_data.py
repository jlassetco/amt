"""Business domain 09 - Shared & Enterprise Reference Data. Content module for taxonomy_builder.py."""

META = {
 "title": "Shared & Enterprise Reference Data Taxonomy",
 "subtitle": "Business domain 09 - Shared & Enterprise Reference Data | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "09_Shared_and_Enterprise_Reference_Data/Shared_and_Enterprise_Reference_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the shared, enterprise-wide reference data that every other business domain of a US wealth manager points to: a firm that serves investors directly through brokerage, digital and human advice, manufactures its own mutual funds, ETFs and CITs, recordkeeps workplace plans and advises institutions. It covers geography, time zones and calendars (including the US settlement and payment calendars of client money movement), currencies and FX rate conventions, languages, locales and units, the firm's own legal entities, the internal organization, industry classification schemes, and the enterprise code list registry. It is stitched together from ISO standards (3166, 4217, 639, 8601, 17442, 20275, ISO/IEC 11179), IETF BCP 47 and the IANA time zone database, US statistical geographies (US Census FIPS and ZCTA, OMB CBSA delineations, HUD-USPS crosswalks), SIFMA and Federal Reserve holiday schedules, FX benchmark methodologies (LSEG WM/Reuters, ECB euro reference rates, used because the firm's funds hold foreign assets), GLEIF Level 1 and Level 2 data, FIBO Business Entities, US registers (SEC, FINRA, OCC) and the DAMA-DMBOK and DCAM approaches to reference data management. Use it as the starting point for a reference data hub, a data catalog or a business glossary."),
  ("Scope", "In scope: countries, subdivisions, US counties, CBSAs, ZIP codes and ZCTAs, firm-defined geographic groupings (sales and service regions, country clusters used for investment exposure reporting) and geographic hierarchies; IANA time zones; business, holiday, exchange, bond market, payment system and fund dealing calendar structures, including foreign market calendars for the firm's international funds; the fiscal calendar and fiscal periods; reporting period definitions; ISO 4217 currencies and minor units; FX rate types, sources and conventions (no FX time series); ISO 639 languages, BCP 47 locales, units of measure and number/date conventions; internal legal entities (LEN-: parent company, investment adviser, self-clearing broker-dealer, fund adviser and fund trusts, transfer agent, recordkeeper, optional national trust company) with group hierarchy, LEI and distribution roles; internal organization units, cost and profit centers and reorganizations (OU-); industry classification schemes (NAICS, US SIC, GICS, ISIC) and their concordances; and the enterprise code list registry (CLR-) with versions, values, source-system mappings and change control. Out of scope (referenced by ID only): products, share classes and which entity plays which role for which fund (01 Investment Product, PRD-/SHC-); external parties and clients, their addresses, industry codes and identifiers (02 Client & Household, PTY-); employees, their jobs, reporting lines and org unit assignments (20 Human Capital, EMP-; moved from 09 under CD-151) and coverage teams (03 Advisor Organization, Coverage & Supervision, SLT-); digital properties and content language use (04 Marketing, Digital & Client Engagement); agreements naming a group entity as contracting party (05 Intermediary & Institutional Distribution, AGR-); flow records, data feeds and party-matching crosswalks (06 Client Assets, Flows & Channel Attribution, FEED-/XWK-); coverage assignment rules that use geographic groups as assignment geography (03 Advisor Organization, Coverage & Supervision, ASRL-); individual licenses (08 Retail Conduct & Supervision, LIC-); entity-level regulatory registrations (Form ADV, Form BD, Form TA-1, OCC charter) and their file and charter numbers (38 Corporate Compliance & Regulatory Affairs, AUTH-; moved from 09 under CD-250) and the regulatory obligations register (38, OBL-; CD-252); chart of accounts, cost and profit center codes, ledgers, GL postings and accounting period status (19 Finance & Accounting, CD-152) and cost allocation (10 Client Revenue, Pricing Economics & Profitability); FX rate and market data licenses (14 Third-Party Data & Licensing, DSET-/DLA-). Also out of scope: FX rate time series, prices and the security master."),
  ("Structure", "Four levels: Domain > Subdomain > Concept > Attribute. The Hierarchy tab shows the first three levels with definitions. The Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard. Attribute IDs take the form SR-xxx-nnn."),
  ("Core model", "Thin, shared masters keyed by stable IDs. Geographic Unit (GEO-) is one generic record for any country, subdivision, county, CBSA or ZIP/ZCTA, typed by scheme and vintage and linked by effective-dated hierarchies; Geographic Groups (sales and service regions, country clusters) are GEO- records whose members are other GEO- units. Calendar (CAL-) holds holiday, exchange, bond market, payment system, dealing, fiscal and reporting calendars, with Calendar Dates and Periods underneath. Currency, FX Rate Type, Language, Locale and Time Zone use their natural ISO / IANA / BCP 47 codes as keys. Internal Legal Entity (LEN-) is linked to its parent entities and the distribution roles it performs; its regulatory registrations (AUTH-) are mastered in 38 Corporate Compliance & Regulatory Affairs (CD-250). Org Unit (OU-) forms management, legal and cost-center hierarchies that change through governed reorganizations (REORG-). Classification Scheme (ICS-) holds NAICS, US SIC, GICS and ISIC nodes and concordances. The Code List Registry (CLR-) describes every governed list, its versions (CLV-), values and source-system mappings (CLM-)."),
  ("Design principles", "1) Reference external standards, don't copy them: ISO, IANA, Census, OMB and HUD-USPS lists are loaded from their maintainers and tagged with version / vintage; this workbook defines only the structure and the firm-defined layers. 2) Effective-date everything: geographies, groupings, hierarchies, entity ownership, org units and code values all carry Effective From / To so history can be restated. 3) One generic structure per pattern (one Geographic Unit, one Calendar, one Code List Registry) rather than one table per list. 4) Own the internal, reference the external: the firm's own legal entities live here (LEN-); every external organization and client stays in the 02 party master (PTY-). Each LEN- carries a cross-reference to its PTY- record so that domains which model counterparties generically (01 product party roles, 05 agreements) can keep using PTY-. 5) Registry before harmonization: the code list registry records owner, steward, version, consumers and source-system mappings for every shared list now; the harmonized enterprise value sets are the shared lists of the consolidation layer (shared_code_lists.py), stewarded through this registry. 6) Flag Critical Data Elements (CDE) where an error would mis-state regulatory reporting, settlement and payment dates, valuation dates or roll-ups across domains."),
  ("Applies To", "Shows the record type each attribute belongs to, e.g. Country, Subdivision, Geographic Unit, Geographic Group, Time Zone, Calendar, Calendar Date, Fiscal Period, Reporting Period Definition, Currency, FX Rate Type, Language, Locale, Unit, Legal Entity, Entity Role, Org Unit, Reorganization, Classification Scheme, Classification Code, Code List, Code List Version, Code Value, Code Mapping or All."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify a reference record, to derive dates, currencies or entity facts used in valuation, dealing, settlement, regulatory reporting or compensation, or to roll up data consistently across business domains. Confirm with the reference data owner, Finance, Compliance, Brokerage Operations and the Data Governance Office."),
  ("Primary / Secondary Reference", "The standard, register or methodology the attribute is aligned to (e.g. 'ISO 3166', 'ISO 4217', 'IANA tz', 'OMB CBSA', 'SIFMA', 'Federal Reserve Financial Services', 'LSEG WM/Reuters', 'ECB', 'GLEIF RR-CDF', 'FIBO BE', 'SEC Form ADV', 'ISO/IEC 11179', 'DAMA-DMBOK'). 'Internal' means the attribute is firm-defined and has no authoritative external definition."),
  ("Tabs", "Hierarchy: domains, subdomains and concepts with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies (ISO and other external lists are referenced as formats, not reproduced) | Relationships: concept-level cardinalities, including links to every consuming business domain | Sources: standards, registers and methodologies used, with owners and links."),
  ("Suggested next steps", "1) Validate the domains, CDEs and code lists with the Data Governance Office, Finance (entity, fiscal calendar, cost centers), Legal Entity Management / Corporate Secretary, Fund Operations (dealing calendars), Brokerage and Money Movement Operations (settlement and payment calendars) and Client Service (geographies and service regions). 2) Pick the reference data hub or MDM tool and the load sources for each external list (ISO 4217 from SIX, IANA tzdata, Census / OMB / HUD-USPS, SIFMA and Federal Reserve holiday schedules, GLEIF). 3) Populate the code list registry with the enterprise shared lists (shared_code_lists.py) and every domain's local lists, tagging owner, class and consumers. 4) Agree the LEN- / PTY- cross-reference rule with 02 and the entity-role boundary with 01. 5) The enterprise employee master (EMP-) is mastered in 20 Human Capital (CD-151); confirm with HR that org units, offices and legal entities referenced by the employee record stay here. 6) Cost and profit center codes are mastered in 19 Finance & Accounting as chart segment values (CD-152); keep the org unit hierarchy here and agree the Represented Org Unit link with 19. 7) Turn the Relationships tab into a logical data model."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Geography", "SR-GEO",
  "Countries, subdivisions and the US statistical and postal geographies, plus firm-defined geographic groupings and hierarchies that other domains use for addresses, coverage regions, registrations and reporting.",
  [
   ("Countries & Subdivisions", "ISO 3166 countries and their principal subdivisions (US states, districts and outlying areas, and the subdivisions of other countries).", [
     ("Country", [
       ("Country Code (Alpha-2)", "Two-letter ISO 3166-1 code; the enterprise key for country in every domain.", "Country", "Code", "ISO 3166-1 alpha-2", "US", "ISO 3166", "", "Y"),
       ("Country Short Name", "English short name as published by the ISO 3166 Maintenance Agency.", "Country", "Text", "", "United States of America", "ISO 3166", "", ""),
       ("Default Currency", "Principal legal-tender currency of the country.", "Country", "Code", "ISO 4217", "USD", "ISO 4217", "", ""),
       ("Primary Time Zone", "Default IANA time zone of the country's capital / financial center.", "Country", "Code", "IANA Time Zone", "America/New_York", "IANA tz", "", ""),
     ]),
     ("Country Subdivision", [
       ("Subdivision Code", "ISO 3166-2 code (country code + hyphen + up to three characters).", "Subdivision", "Code", "ISO 3166-2", "US-NY", "ISO 3166", "", "Y"),
       ("Subdivision Name", "Name of the subdivision in English or the official romanization.", "Subdivision", "Text", "", "New York", "ISO 3166", "", ""),
       ("Subdivision Category", "Type of subdivision as defined in ISO 3166-2 (state, nation, Land, canton, province, region).", "Subdivision", "Code", "Subdivision Category", "State", "ISO 3166", "", ""),
       ("Parent Country", "Country to which the subdivision belongs.", "Subdivision", "Code", "ISO 3166-1 alpha-2", "US", "ISO 3166", "", ""),
       ("US State FIPS Code", "Two-digit FIPS / ANSI code of a US state or territory.", "Subdivision", "Code", "External (US Census FIPS)", "36", "US Census (FIPS)", "", ""),
     ]),
   ]),
   ("US Statistical & Postal Geography", "US counties, Core Based Statistical Areas and ZIP codes used for service-region design, market sizing and assignment of clients to the firm's advisors and branches.", [
     ("US County", [
       ("County FIPS Code", "Five-digit state + county FIPS / ANSI code.", "Geographic Unit", "Code", "External (US Census FIPS)", "36119", "US Census (FIPS)", "", "Y"),
       ("County CBSA Code", "CBSA to which the county belongs under the current OMB delineation.", "Geographic Unit", "Code", "External (OMB CBSA)", "35620", "OMB CBSA", "", ""),
     ]),
     ("Core Based Statistical Area", [
       ("CBSA Code", "Five-digit OMB code of the metropolitan or micropolitan statistical area.", "Geographic Unit", "Code", "External (OMB CBSA)", "35620", "OMB CBSA", "US Census (FIPS)", "Y"),
       ("CBSA Title", "Official title of the CBSA.", "Geographic Unit", "Text", "", "New York-Newark-Jersey City, NY-NJ", "OMB CBSA", "", ""),
       ("CBSA Type", "Whether the CBSA is a metropolitan or micropolitan statistical area.", "Geographic Unit", "Code", "CBSA Type", "Metropolitan", "OMB CBSA", "", ""),
       ("Delineation Bulletin", "OMB bulletin that defines the delineation in force (vintage).", "Geographic Unit", "Text", "", "OMB Bulletin 23-01", "OMB CBSA", "", ""),
     ]),
     ("ZIP Code & ZCTA", [
       ("ZIP Code", "Five-digit USPS ZIP code.", "Geographic Unit", "Code", "External (USPS)", "10601", "USPS", "", "Y"),
       ("ZCTA Code", "Census ZIP Code Tabulation Area that approximates the ZIP code for statistical mapping.", "Geographic Unit", "Code", "External (US Census ZCTA)", "10601", "US Census (ZCTA)", "", ""),
       ("Preferred County", "County holding the largest share of the ZIP code's addresses, used for single-county assignment.", "Geographic Unit", "Code", "External (US Census FIPS)", "36119", "HUD-USPS Crosswalk", "", ""),
     ]),
   ]),
   ("Geographic Unit & Hierarchy", "The generic, effective-dated geographic record and the parent-child hierarchies that roll units up (ZIP > county > CBSA > state > country; county > state > country).", [
     ("Geographic Unit", [
       ("Geographic Unit ID", "Enterprise identifier of any geographic unit, independent of scheme.", "Geographic Unit", "Identifier", "", "GEO-US-CBSA-35620", "Internal", "", "Y"),
       ("Geographic Unit Type", "Type of unit (country, subdivision, county, CBSA, ZIP, ZCTA, city, group).", "Geographic Unit", "Code", "Geographic Unit Type", "CBSA", "Internal", "", "Y"),
       ("Geographic Scheme", "External scheme or authority that defines the unit's code.", "Geographic Unit", "Code", "Geographic Scheme", "OMB CBSA", "Internal", "", ""),
       ("Scheme Code", "The unit's code within its scheme.", "Geographic Unit", "Code", "Firm-defined (per scheme)", "35620", "Internal", "", ""),
       ("Geographic Unit Name", "Display name of the unit.", "Geographic Unit", "Text", "", "New York-Newark-Jersey City, NY-NJ", "Internal", "", ""),
       ("Scheme Vintage", "Version or release of the external scheme the unit comes from.", "Geographic Unit", "Text", "", "OMB Bulletin 23-01", "Internal", "", "Y"),
       ("Country", "Country containing the unit.", "Geographic Unit", "Code", "ISO 3166-1 alpha-2", "US", "ISO 3166", "", ""),
       ("Successor Geographic Unit", "Unit that replaces this one after a boundary or code change.", "Geographic Unit", "Reference (Geographic Unit)", "", "GEO-US-CNTY-09110", "Internal", "", ""),
       ("Geographic Unit Status", "Lifecycle status of the unit in the enterprise list.", "Geographic Unit", "Code", "Reference Record Status", "Active", "Internal", "", ""),
       ("Effective From", "Date the unit became valid.", "Geographic Unit", "Date", "ISO 8601", "2023-07-21", "Internal", "", ""),
       ("Effective To", "Date the unit ceased to be valid.", "Geographic Unit", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Geographic Hierarchy", [
       ("Geographic Hierarchy Type", "Named hierarchy the parent-child link belongs to.", "Geographic Unit", "Code", "Geographic Hierarchy Type", "US Statistical (ZIP > County > CBSA)", "Internal", "", ""),
       ("Parent Geographic Unit", "Parent of the unit in this hierarchy.", "Geographic Unit", "Reference (Geographic Unit)", "", "GEO-US-ST-36", "Internal", "", "Y"),
       ("Child Geographic Unit", "Child of the unit in this hierarchy.", "Geographic Unit", "Reference (Geographic Unit)", "", "GEO-US-CNTY-36119", "Internal", "", ""),
       ("Hierarchy Effective From", "Date the link became valid.", "Geographic Unit", "Date", "ISO 8601", "2023-07-21", "Internal", "", ""),
     ]),
   ]),
   ("Geographic Groupings", "Firm-defined groups of geographic units: sales and service regions, country clusters for investment exposure reporting, regulatory regions and reporting regions. Coverage assignment rules (03) and market scopes in other domains are built from them.", [
     ("Geographic Group", [
       ("Geographic Group ID", "Identifier of the group (a Geographic Unit of type Group).", "Geographic Group", "Identifier", "", "GEO-GRP-US-NE", "Internal", "", "Y"),
       ("Geographic Group Name", "Name of the group.", "Geographic Group", "Text", "", "US Northeast", "Internal", "", ""),
       ("Geographic Group Type", "Purpose of the group.", "Geographic Group", "Code", "Geographic Group Type", "Sales Region", "Internal", "", "Y"),
       ("Consuming Domains", "Business domains that use the group.", "Geographic Group", "Code (multi)", "Business Domain", "03 Advisor Organization, Coverage & Supervision; 12 Institutional Client Servicing & Reporting", "Internal", "", ""),
     ]),
     ("Geographic Group Membership", [
       ("Member Geographic Unit", "Geographic unit (or nested group) included in the group.", "Geographic Group", "Reference (Geographic Unit)", "", "GEO-US-ST-36", "Internal", "", "Y"),
       ("Membership Type", "Whether the unit is included or explicitly excluded (e.g. a state minus a county).", "Geographic Group", "Code", "Membership Type", "Include", "Internal", "", ""),
       ("Membership Effective From", "Date the unit joined the group.", "Geographic Group", "Date", "ISO 8601", "2027-01-01", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Time Zones & Calendars", "SR-CAL",
  "Time zones and the calendars that determine business days, holidays, market, settlement, payment and fund dealing days, fiscal periods and reporting periods in the US and in the foreign markets where the firm's funds invest.",
  [
   ("Time Zones", "IANA time zones used for cut-off times, valuation points and timestamps.", [
     ("Time Zone", [
       ("IANA Time Zone ID", "Area/Location identifier from the IANA time zone database; the enterprise key for time zone.", "Time Zone", "Code", "IANA Time Zone", "America/New_York", "IANA tz", "", "Y"),
       ("Daylight Saving Indicator", "Whether the zone observes daylight saving time.", "Time Zone", "Boolean", "", "Y", "IANA tz", "", ""),
       ("tzdata Release", "IANA tzdata release loaded (rules change several times a year).", "Time Zone", "Text", "", "2026b", "IANA tz", "", ""),
     ]),
   ]),
   ("Business & Holiday Calendars", "Calendars of business days and holidays by country, subdivision, market, settlement system or firm.", [
     ("Calendar", [
       ("Calendar ID", "Identifier of the calendar.", "Calendar", "Identifier", "", "CAL-US-NYSE", "Internal", "", "Y"),
       ("Calendar Name", "Name of the calendar.", "Calendar", "Text", "", "NYSE Trading Calendar", "Internal", "", ""),
       ("Calendar Type", "Kind of calendar.", "Calendar", "Code", "Calendar Type", "Exchange", "Internal", "", "Y"),
       ("Calendar Country", "Country the calendar applies to, where it is national.", "Calendar", "Code", "ISO 3166-1 alpha-2", "US", "ISO 3166", "", ""),
       ("Exchange MIC", "Market Identifier Code for exchange calendars.", "Calendar", "Code", "ISO 10383 (MIC)", "XNYS", "ISO 10383", "", ""),
       ("Calendar Time Zone", "Time zone in which calendar days start and end.", "Calendar", "Code", "IANA Time Zone", "America/New_York", "IANA tz", "", ""),
       ("Weekend Days", "Days of the week that are non-business days by default.", "Calendar", "Code (multi)", "Day of Week", "Saturday; Sunday", "Internal", "ISO 8601", ""),
       ("Calendar Source", "Authority or vendor publishing the holiday dates.", "Calendar", "Code", "Calendar Source", "Exchange Publication", "Internal", "", ""),
     ]),
     ("Composite Calendar", [
       ("Component Calendar", "Calendar combined into a composite (e.g. NYSE + Fedwire for client cash settlement, or TARGET + London for a EUR/GBP settlement).", "Calendar", "Reference (Calendar)", "", "CAL-US-FEDWIRE", "Internal", "", ""),
       ("Combination Rule", "How the component calendars are combined.", "Calendar", "Code", "Calendar Combination Rule", "Holiday if Any Component Closed", "Internal", "", ""),
     ]),
     ("Calendar Date", [
       ("Calendar Date", "Date the entry applies to.", "Calendar Date", "Date", "ISO 8601", "2026-11-26", "ISO 8601", "", "Y"),
       ("Day Type", "Status of the date in the calendar.", "Calendar Date", "Code", "Day Type", "Holiday", "Internal", "", "Y"),
       ("Holiday Name", "Name of the holiday or closure.", "Calendar Date", "Text", "", "Thanksgiving Day", "Internal", "", ""),
     ]),
   ]),
   ("Fund Dealing Calendars", "Structure of fund dealing calendars: which underlying calendars and rules decide whether a fund deals on a day. 01 Investment Product & Service Offering references the calendar by CAL- ID; dealing cut-off and valuation point stay in 01.", [
     ("Dealing Calendar Rule", [
       ("Dealing Calendar ID", "Calendar ID of the dealing calendar (Calendar Type = Fund Dealing).", "Calendar", "Identifier", "", "CAL-FUND-US-01", "Internal", "", "Y"),
       ("Base Business Calendar", "Calendar of the fund's domicile / administrator whose business days are candidate dealing days.", "Calendar", "Reference (Calendar)", "", "CAL-US-NYSE", "Internal", "", "Y"),
       ("Market Closure Calendars", "Exchange calendars whose closure can make a day non-dealing.", "Calendar", "Reference (Calendar)", "", "CAL-US-XNAS; CAL-GB-XLON", "Internal", "", ""),
       ("Dealing Day Pattern", "Pattern of dealing days within the business days (daily, weekly on a weekday, month-end).", "Calendar", "Code", "Dealing Day Pattern", "Every Business Day", "Internal", "SEC Rule 22c-1", ""),
     ]),
   ]),
   ("Fiscal Calendar & Periods", "The firm's fiscal calendar(s) and fiscal periods, used by Finance and every domain that reports on fiscal months, quarters and years.", [
     ("Fiscal Calendar", [
       ("Fiscal Calendar ID", "Calendar ID of the fiscal calendar (Calendar Type = Fiscal).", "Calendar", "Identifier", "", "CAL-FISCAL-GRP", "Internal", "", ""),
       ("Fiscal Year Start", "Month and day the fiscal year begins.", "Calendar", "Text", "MM-DD", "01-01", "Internal", "", ""),
       ("Period Structure", "Division of the fiscal year into periods.", "Calendar", "Code", "Fiscal Period Structure", "12 Calendar Months", "Internal", "", ""),
     ]),
     ("Fiscal Period", [
       ("Fiscal Period ID", "Identifier of the fiscal period.", "Fiscal Period", "Identifier", "", "FY2026-P09", "Internal", "", "Y"),
       ("Fiscal Year", "Fiscal year the period belongs to.", "Fiscal Period", "Integer", "", "2026", "Internal", "", ""),
       ("Fiscal Period Type", "Granularity of the period.", "Fiscal Period", "Code", "Period Type", "Month", "Internal", "", ""),
       ("Period Start Date", "First day of the period.", "Fiscal Period", "Date", "ISO 8601", "2026-09-01", "Internal", "", ""),
       ("Period End Date", "Last day of the period.", "Fiscal Period", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
       ("Fiscal Period Status", "Close status of the period for the group primary ledger, copied from 19 Accounting Period Status.", "Fiscal Period", "Code", "Fiscal Period Status", "Open", "Internal", "", "", "Value map from 19 Period Close Status: Not Yet Opened -> Future; Open and Reopened -> Open; Soft Close -> Soft Close; Hard Close and Permanently Closed -> Closed (CD-152)."),
     ]),
   ]),
   ("Reporting Period Definitions", "Standard period definitions (month-to-date, quarter, rolling 12 months, since inception) and as-of conventions shared by sales, AUM, compensation, finance and client reporting. Close and lock dates for a domain's own results stay in that domain (e.g. 06 TX-SNP).", [
     ("Reporting Period Definition", [
       ("Reporting Period Definition Code", "Code of the standard period definition.", "Reporting Period Definition", "Code", "Reporting Period Basis", "QTD", "Internal", "", ""),
       ("Period Basis Calendar", "Calendar the period is computed on (Gregorian or fiscal).", "Reporting Period Definition", "Reference (Calendar)", "", "CAL-FISCAL-GRP", "Internal", "", ""),
       ("As-Of Date Convention", "Rule for the as-of date of a period end.", "Reporting Period Definition", "Code", "As-Of Date Convention", "Last Business Day", "Internal", "GIPS", "Y"),
       ("Business Day Convention", "Rule used to adjust a date that falls on a non-business day.", "Reporting Period Definition", "Code", "Business Day Convention", "Preceding", "ISDA", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Currency & FX Reference", "SR-CCY",
  "ISO 4217 currencies and the reference data describing FX rate types, sources and conventions used for valuation, reporting translation, fee and compensation calculations. FX rate time series are out of scope.",
  [
   ("Currency", "Currencies, funds codes and precious metals, with minor units and firm usage flags.", [
     ("Currency", [
       ("Currency Code", "Three-letter ISO 4217 alphabetic code; the enterprise key for currency.", "Currency", "Code", "ISO 4217", "USD", "ISO 4217", "", "Y"),
       ("Currency Numeric Code", "Three-digit ISO 4217 numeric code.", "Currency", "Code", "ISO 4217", "840", "ISO 4217", "", ""),
       ("Currency Name", "Official English name of the currency.", "Currency", "Text", "", "US Dollar", "ISO 4217", "", ""),
       ("Minor Unit", "Number of decimal places of the minor unit (0-4), used for rounding and display of amounts.", "Currency", "Integer", "", "2", "ISO 4217", "", "Y"),
       ("Currency Type", "Kind of ISO 4217 entry.", "Currency", "Code", "Currency Type", "National Currency", "ISO 4217", "", ""),
       ("Currency Status", "Whether the code is current or historic in ISO 4217.", "Currency", "Code", "Currency Status", "Current", "ISO 4217", "", ""),
       ("Withdrawal Date", "Date the currency was withdrawn (ISO 4217 List Three).", "Currency", "Date", "ISO 8601", "2026-01-01", "ISO 4217", "", ""),
       ("Replacement Currency", "Currency that replaced a withdrawn currency, with the fixed conversion rate in notes.", "Currency", "Code", "ISO 4217", "EUR", "ISO 4217", "", "", "e.g. BGN replaced by EUR at 1.95583 from 2026-01-01 (ISO 4217 Amendment 180)."),
       ("Group Reporting Currency Indicator", "Whether the currency is a firm reporting currency for AUM, flows or financials.", "Currency", "Boolean", "", "N", "Internal", "", ""),
     ]),
     ("Currency Pair Convention", [
       ("Currency Pair", "Base and quote currency in market order.", "Currency", "Code", "Firm-defined (ISO 4217 pair)", "EURUSD", "Internal", "LSEG WM/Reuters", ""),
     ]),
   ]),
   ("FX Rate Types & Sources", "Named FX rate types (e.g. WM/Reuters 4pm London close, ECB reference rate) and the rules for which type each process uses.", [
     ("FX Rate Source", [
       ("FX Rate Source Code", "Code of the benchmark administrator or provider of rates.", "FX Rate Type", "Code", "FX Rate Source", "LSEG WM/Reuters", "Internal", "", ""),
       ("Licensed Dataset", "Dataset under which the rates are licensed (owned by 14).", "FX Rate Type", "Reference (Dataset)", "", "DSET-00042", "Internal", "", ""),
     ]),
     ("FX Rate Type", [
       ("FX Rate Type Code", "Code of the rate type.", "FX Rate Type", "Code", "FX Rate Type", "WMR London 4pm Close Mid", "Internal", "", "Y"),
       ("FX Rate Type Name", "Descriptive name.", "FX Rate Type", "Text", "", "WM/Reuters London 4pm Closing Spot Mid", "LSEG WM/Reuters", "", ""),
       ("Fixing Time", "Time the rate is fixed or snapped.", "FX Rate Type", "Time", "HH:MM + time zone", "16:00 Europe/London", "LSEG WM/Reuters", "ECB", "Y"),
       ("Rate Side", "Side of the market the rate represents.", "FX Rate Type", "Code", "Rate Side", "Mid", "LSEG WM/Reuters", "", ""),
       ("Publication Calendar", "Calendar of days on which the rate is published.", "FX Rate Type", "Reference (Calendar)", "", "CAL-EU-TARGET", "ECB", "", ""),
       ("Quote Convention", "Whether rates are stored as base-per-quote per market convention or always against a pivot currency.", "FX Rate Type", "Code", "FX Quote Convention", "Units of Quote per 1 EUR", "ECB", "", "Y"),
       ("Fallback Rule", "Rule applied when the rate is not published for a date.", "FX Rate Type", "Code", "FX Fallback Rule", "Previous Published Rate", "Internal", "", ""),
       ("Approved Usage", "Processes for which the rate type is approved.", "FX Rate Type", "Code (multi)", "FX Rate Usage", "AUM Reporting Translation; Fee Calculation", "Internal", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Languages, Locales & Units", "SR-LOC",
  "Languages, BCP 47 locales, units of measure and the number, date and rounding conventions used in documents, digital channels, data exchange and reporting.",
  [
   ("Languages & Locales", "Languages and locale tags supported by the firm's documents, websites and client communications.", [
     ("Language", [
       ("Language Code (ISO 639-1)", "Two-letter language code; the enterprise key where one exists.", "Language", "Code", "ISO 639-1", "es", "ISO 639", "", "Y"),
       ("Language Code (ISO 639-3)", "Three-letter code, for languages without a two-letter code.", "Language", "Code", "ISO 639-3", "spa", "ISO 639", "", ""),
       ("Language Name (English)", "English name of the language.", "Language", "Text", "", "Spanish", "ISO 639", "", ""),
       ("Firm-Supported Language Indicator", "Whether the firm produces client documents or web content in the language.", "Language", "Boolean", "", "Y", "Internal", "", ""),
     ]),
     ("Locale", [
       ("Locale Tag", "BCP 47 language tag combining language, optional script and region.", "Locale", "Code", "External (BCP 47)", "es-US", "IETF BCP 47", "Unicode CLDR", "Y"),
       ("Fallback Locale", "Locale used when content is unavailable in this locale.", "Locale", "Code", "External (BCP 47)", "en-US", "Internal", "", ""),
       ("Locale Usage", "Channels where the locale is enabled.", "Locale", "Code (multi)", "Locale Usage", "Website; Client Documents", "Internal", "", ""),
     ]),
   ]),
   ("Units & Formats", "Units of measure and enterprise conventions for numbers, dates and rounding.", [
     ("Unit of Measure", [
       ("Unit Code", "Code of the unit (UCUM or UN/ECE Recommendation 20 where available).", "Unit", "Code", "External (UN/ECE Rec 20)", "P1", "UN/ECE Rec 20", "UCUM", "", "P1 = percent."),
       ("Unit Name", "Name of the unit.", "Unit", "Text", "", "Percent", "UN/ECE Rec 20", "", ""),
       ("Unit Category", "Quantity the unit measures.", "Unit", "Code", "Unit Category", "Ratio", "Internal", "", ""),
       ("Conversion Factor to Base", "Multiplier converting the unit to the category's base unit.", "Unit", "Decimal", "", "0.01", "Internal", "", "", "e.g. 1 bp = 0.0001; 1 % = 0.01."),
     ]),
     ("Number & Date Convention", [
       ("Decimal Separator", "Character separating integer and fraction for the locale.", "Locale", "Text", "", ".", "Unicode CLDR", "", ""),
       ("Display Date Pattern", "Date pattern shown to users for the locale (storage always ISO 8601).", "Locale", "Text", "", "MM/dd/yyyy", "Unicode CLDR", "ISO 8601", ""),
       ("Rounding Rule", "Enterprise rounding method for amounts, rates and percentages.", "All", "Code", "Rounding Rule", "Half Even", "Internal", "", ""),
       ("Percentage Storage Convention", "How percentages are stored in data exchange (decimal fraction or percent).", "All", "Code", "Percentage Storage Convention", "Decimal Fraction", "Internal", "", "Y", "Avoids the frequent 0.75 vs 0.0075 error in fee and rate feeds."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Internal Legal Entities", "SR-LEN",
  "The firm's own legal entities (parent holding company, registered investment adviser, self-clearing broker-dealer, fund adviser, fund trusts, transfer agent, recordkeeper, optional national trust company, service companies and branches), their group hierarchy and identifiers, and the roles they perform in distribution. Their regulatory registrations are mastered in 38 (CD-250).",
  [
   ("Legal Entity Master", "Identity, legal form and status of each group legal entity.", [
     ("Internal Legal Entity", [
       ("Legal Entity ID", "Enterprise identifier of the internal legal entity.", "Legal Entity", "Identifier", "", "LEN-0004", "Internal", "FIBO BE", "Y"),
       ("Legal Name", "Registered legal name.", "Legal Entity", "Text", "", "Example Advisory Services, LLC", "GLEIF LEI-CDF", "FIBO BE", "Y"),
       ("Entity Legal Form", "ISO 20275 Entity Legal Form code.", "Legal Entity", "Code", "ISO 20275", "ELF code of a Delaware limited liability company", "ISO 20275", "GLEIF LEI-CDF", "", "Look up the four-character code in the GLEIF ELF list (confirm)."),
       ("Entity Category", "Business category of the entity within the group.", "Legal Entity", "Code", "Internal Entity Category", "Registered Investment Adviser", "Internal", "FIBO FBC", "Y", "Reference model entities (plan section 2), illustrative: LEN-0001 parent holding company; LEN-0002 fund adviser; LEN-0003 broker-dealer (self-clearing; principal underwriter of the funds); LEN-0004 registered investment adviser (advice and discretionary management); LEN-0005 fund trust (registrant); LEN-0006 transfer agent; LEN-0007 recordkeeper; LEN-0008 national trust company (optional); LEN-0009 service company."),
       ("Jurisdiction of Formation", "Country or subdivision under whose law the entity is formed.", "Legal Entity", "Code", "ISO 3166-2", "US-DE", "GLEIF LEI-CDF", "", "", "Use ISO 3166-2 where formation is at state level."),
       ("Company Registration Number", "Number in the company / trade register (for a US entity, the state file number).", "Legal Entity", "Text", "", "1234567", "GLEIF LEI-CDF", "", ""),
       ("Entity Status", "Lifecycle status of the entity.", "Legal Entity", "Code", "Legal Entity Status", "Active", "GLEIF LEI-CDF", "", ""),
       ("Branch Indicator", "Whether the record is a branch (not a separate legal person) of another entity.", "Legal Entity", "Boolean", "", "N", "GLEIF LEI-CDF", "FIBO BE", ""),
       ("Head Office Entity", "Legal entity of which this record is a branch.", "Legal Entity", "Reference (Legal Entity)", "", "", "GLEIF LEI-CDF", "", ""),
       ("Accounting Company Code", "Company code of the entity in the general ledger, copied from the 19 Chart Segment Value of segment 'Company' that represents the entity.", "Legal Entity", "Code", "Firm-defined", "4100", "Internal", "", ""),
       ("Party Master Cross-Reference", "PTY- record representing the same entity in the party master, used where domains model counterparties generically.", "Legal Entity", "Reference (Party)", "", "PTY-000015", "Internal", "", "Y"),
     ]),
     ("Legal Entity Identifier", [
       ("LEI", "20-character Legal Entity Identifier.", "Legal Entity", "Identifier", "ISO 17442", "5493001ABCDEXAMPLE12", "ISO 17442 (GLEIF)", "GLEIF LEI-CDF", "Y", "Example LEI illustrative."),
       ("LEI Registration Status", "GLEIF registration status of the LEI.", "Legal Entity", "Code", "LEI Registration Status", "ISSUED", "GLEIF LEI-CDF", "", "Y"),
       ("LEI Next Renewal Date", "Date by which the LEI must be renewed to avoid lapsing.", "Legal Entity", "Date", "ISO 8601", "2027-03-14", "GLEIF LEI-CDF", "", ""),
       ("SEC CIK", "SEC Central Index Key of the entity for EDGAR filings.", "Legal Entity", "Identifier", "", "0001234567", "SEC EDGAR", "", ""),
       ("Firm CRD Number", "FINRA Central Registration Depository number of the firm (own entities only; external firms are in 02).", "Legal Entity", "Identifier", "", "123456", "FINRA", "SEC Form ADV", "", "SEC file numbers (801- adviser, 8- broker-dealer, 84- transfer agent, 811- fund trust) and the OCC charter number are held per registration in 38 Entity Authorization."),
     ]),
   ]),
   ("Group Structure & Ownership", "Effective-dated ownership and consolidation links between internal entities, aligned to GLEIF Level 2 and FIBO ownership and control.", [
     ("Entity Ownership Relationship", [
       ("Child Entity", "Entity that is owned or consolidated.", "Legal Entity", "Reference (Legal Entity)", "", "LEN-0004", "GLEIF RR-CDF", "FIBO BE", ""),
       ("Parent Entity", "Entity that owns or consolidates the child.", "Legal Entity", "Reference (Legal Entity)", "", "LEN-0001", "GLEIF RR-CDF", "FIBO BE", "Y"),
       ("Relationship Type", "Nature of the parent link.", "Legal Entity", "Code", "Ownership Relationship Type", "Direct Accounting Consolidation Parent", "GLEIF RR-CDF", "FIBO BE", "Y"),
       ("Ownership Percentage", "Share of equity held by the parent.", "Legal Entity", "Percentage", "", "100%", "FIBO BE", "", ""),
       ("Level 2 Reporting Exception", "Reason reported to GLEIF when no parent LEI is reported.", "Legal Entity", "Code", "GLEIF Reporting Exception", "NATURAL_PERSONS", "GLEIF RR-CDF", "", ""),
       ("Ownership Effective From", "Date the relationship started.", "Legal Entity", "Date", "ISO 8601", "2004-05-12", "GLEIF RR-CDF", "", ""),
     ]),
   ]),
   ("Entity Roles in Distribution", "Which group entity performs which distribution role in which market, channel or product range. Fund-specific service-provider roles stay in 01 (Product Party Role).", [
     ("Entity Distribution Role", [
       ("Role Entity", "Entity performing the role.", "Entity Role", "Reference (Legal Entity)", "", "LEN-0003", "Internal", "FIBO FBC", "Y"),
       ("Distribution Role", "Role performed.", "Entity Role", "Code", "Entity Distribution Role", "Principal Underwriter", "Internal", "FIBO FBC", "Y"),
       ("Role Market Scope", "Markets in which the entity performs the role.", "Entity Role", "Reference (Geographic Group)", "", "GEO-GRP-US", "Internal", "", ""),
       ("Role Channel Scope", "Channels in which the entity performs the role.", "Entity Role", "Code (multi)", "Firm-defined (enterprise Distribution Channel)", "Direct; Intermediary", "Internal", "", ""),
       ("Role Product Scope", "Product range or vehicle types covered.", "Entity Role", "Text", "", "All '40 Act mutual funds and ETFs", "Internal", "", ""),
       ("Default Contracting Entity Indicator", "Whether the entity signs distribution agreements (05) for this role and scope by default.", "Entity Role", "Boolean", "", "Y", "Internal", "", ""),
       ("Role Effective From", "Date the role started.", "Entity Role", "Date", "ISO 8601", "2010-01-01", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Internal Organization", "SR-ORG",
  "Business units, departments, teams, cost and profit centers, offices and the effective-dated hierarchies and reorganizations that structure the firm internally.",
  [
   ("Org Units", "Units of the internal organization and their attributes.", [
     ("Org Unit", [
       ("Org Unit ID", "Enterprise identifier of the org unit.", "Org Unit", "Identifier", "", "OU-DIST-US-WEST", "Internal", "", "Y"),
       ("Org Unit Name", "Name of the unit.", "Org Unit", "Text", "", "Client Advice Services - West", "Internal", "", ""),
       ("Org Unit Type", "Kind of unit.", "Org Unit", "Code", "Org Unit Type", "Department", "Internal", "", "Y"),
       ("Business Function", "Enterprise function the unit belongs to.", "Org Unit", "Code", "Business Function", "Distribution", "Internal", "", ""),
       ("Employing / Booking Entity", "Legal entity in which the unit's staff and costs are booked.", "Org Unit", "Reference (Legal Entity)", "", "LEN-0004", "Internal", "", "Y"),
       ("Unit Head", "Employee leading the unit.", "Org Unit", "Reference (Employee)", "", "EMP-10233", "Internal", "", "", "PII (name resolved via the employee record)."),
       ("Org Unit Effective From", "Date the unit was created.", "Org Unit", "Date", "ISO 8601", "2024-01-01", "Internal", "", ""),
     ]),
     ("Cost & Profit Center", [
       ("Cost Center Code", "General-ledger cost center to which the unit's costs are booked (19 chart segment value).", "Org Unit", "Reference (Chart Segment Value)", "", "41020", "Internal", "", "Y"),
       ("Profit Center Code", "Profit center the unit reports into for management P&L (19 chart segment value).", "Org Unit", "Reference (Chart Segment Value)", "", "PC-DIST-US", "Internal", "", ""),
     ]),
     ("Office Location", [
       ("Office ID", "Identifier of an office or site.", "Office", "Identifier", "", "SITE-US-SFO", "Internal", "", ""),
       ("Office Country / Subdivision", "Location of the office.", "Office", "Code", "ISO 3166-2", "US-CA", "ISO 3166", "", ""),
       ("Office Time Zone", "Time zone of the office.", "Office", "Code", "IANA Time Zone", "America/Los_Angeles", "IANA tz", "", ""),
       ("Office Legal Entity", "Legal entity occupying or registering the office (e.g. FINRA branch office of the BD).", "Office", "Reference (Legal Entity)", "", "LEN-0003", "Internal", "FINRA", ""),
     ]),
   ]),
   ("Org Hierarchies", "Parallel, effective-dated hierarchies over org units (management, legal, cost center).", [
     ("Org Hierarchy Link", [
       ("Org Hierarchy Type", "Hierarchy the link belongs to.", "Org Unit", "Code", "Org Hierarchy Type", "Management", "Internal", "", "Y"),
       ("Parent Org Unit", "Parent of the unit in this hierarchy.", "Org Unit", "Reference (Org Unit)", "", "OU-DIST-US", "Internal", "", "Y"),
       ("Child Org Unit", "Child of the unit in this hierarchy.", "Org Unit", "Reference (Org Unit)", "", "OU-DIST-US-WEST", "Internal", "", ""),
       ("Link Effective From", "Date the link became valid.", "Org Unit", "Date", "ISO 8601", "2024-01-01", "Internal", "", ""),
     ]),
   ]),
   ("Reorganizations", "Governed changes to the organization that merge, split, move or close units, with the mapping used to restate history.", [
     ("Reorganization Event", [
       ("Reorganization ID", "Identifier of the reorganization.", "Reorganization", "Identifier", "", "REORG-2027-01", "Internal", "", ""),
       ("Reorganization Type", "Kind of change.", "Reorganization", "Code", "Reorganization Type", "Split", "Internal", "", ""),
       ("Reorganization Effective Date", "Date the new structure takes effect.", "Reorganization", "Date", "ISO 8601", "2027-01-01", "Internal", "", "Y"),
       ("Source Org Units", "Units affected before the change.", "Reorganization", "Reference (Org Unit)", "", "OU-DIST-US-WEST", "Internal", "", ""),
       ("Target Org Units", "Units resulting from the change.", "Reorganization", "Reference (Org Unit)", "", "OU-DIST-US-PNW; OU-DIST-US-SW", "Internal", "", ""),
       ("History Restatement Rule", "Whether history is restated to the new structure or kept as booked.", "Reorganization", "Code", "Restatement Rule", "Restate Prior Periods", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Industry Classification", "SR-IND",
  "Scheme metadata, hierarchical codes and concordances of the industry classification systems used to classify organizations (NAICS, US SIC, GICS, ISIC). Assignment of codes to parties stays in 02.",
  [
   ("Classification Schemes", "Industry classification schemes and versions held by the enterprise.", [
     ("Classification Scheme", [
       ("Classification Scheme ID", "Identifier of the scheme version.", "Classification Scheme", "Identifier", "", "ICS-NAICS-2022", "Internal", "", "Y"),
       ("Scheme Name", "Name of the classification system.", "Classification Scheme", "Code", "Industry Classification Scheme", "NAICS", "Internal", "", ""),
       ("Scheme Version", "Edition of the scheme.", "Classification Scheme", "Text", "", "2022", "NAICS", "", "Y"),
       ("Scheme Jurisdiction", "Country or region where the scheme is the official standard.", "Classification Scheme", "Code", "Firm-defined (ISO 3166 or region)", "US", "Internal", "", ""),
       ("Number of Levels", "Depth of the hierarchy.", "Classification Scheme", "Integer", "", "5", "NAICS", "", ""),
       ("Scheme Effective From", "Date the version came into force.", "Classification Scheme", "Date", "ISO 8601", "2022-01-01", "NAICS", "", ""),
       ("License Required Indicator", "Whether use of the scheme needs a commercial license (e.g. GICS); the license is held in 14.", "Classification Scheme", "Boolean", "", "N", "Internal", "", ""),
     ]),
   ]),
   ("Classification Codes & Concordances", "Hierarchical nodes of each scheme and the correspondence tables between schemes and versions.", [
     ("Classification Code", [
       ("Classification Code", "Code of the node within the scheme.", "Classification Code", "Code", "Firm-defined (per scheme)", "523940", "NAICS", "US SIC", "Y"),
       ("Classification Label", "Official title of the node.", "Classification Code", "Text", "", "Portfolio Management and Investment Advice", "NAICS", "", ""),
       ("Classification Level", "Level of the node in the hierarchy.", "Classification Code", "Integer", "", "5", "NAICS", "", ""),
       ("Parent Classification Code", "Code of the node one level up.", "Classification Code", "Code", "Firm-defined (per scheme)", "52394", "NAICS", "", ""),
     ]),
     ("Classification Concordance", [
       ("Source Classification Code", "Code in the source scheme version.", "Classification Code", "Reference (Classification Code)", "", "NAICS 2017: 523920", "NAICS", "", ""),
       ("Target Classification Code", "Corresponding code in the target scheme version.", "Classification Code", "Reference (Classification Code)", "", "NAICS 2022: 523940", "NAICS", "", "Y"),
       ("Correspondence Type", "Cardinality / quality of the correspondence.", "Classification Code", "Code", "Correspondence Type", "Partial (Many-to-One)", "Internal", "", ""),
       ("Concordance Source", "Published correspondence table used.", "Classification Code", "Text", "", "US Census Bureau NAICS 2017 to 2022 concordance", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Enterprise Code List Registry", "SR-CLR",
  "Governance metadata for every governed code list in the enterprise (shared, domain-specific and external), its versions, values, consumers and mappings to source-system values, following the ISO/IEC 11179 registry pattern.",
  [
   ("Code List Registry Entry", "Registration and ownership metadata of a code list.", [
     ("Code List", [
       ("Code List ID", "Registry identifier of the code list.", "Code List", "Identifier", "", "CLR-0031", "ISO/IEC 11179", "", "Y"),
       ("Code List Name", "Preferred name of the list.", "Code List", "Text", "", "Distribution Channel", "ISO/IEC 11179", "", "Y"),
       ("Code List Definition", "Business definition of what the list classifies.", "Code List", "Text", "", "Route through which products reach end investors, used for flow, sales and profitability reporting.", "ISO/IEC 11179", "", ""),
       ("Code List Class", "Whether the list is an enterprise shared list, a domain list, an external standard or a vendor list.", "Code List", "Code", "Code List Class", "Enterprise Shared", "Internal", "DAMA-DMBOK", ""),
       ("Source Standard", "External standard the list is taken from or aligned to.", "Code List", "Text", "", "Internal (Cerulli-style channel scheme)", "Internal", "", ""),
       ("Owning Business Domain", "Business domain accountable for the list.", "Code List", "Code", "Business Domain", "09 Shared & Enterprise Reference Data", "Internal", "", "Y"),
       ("Data Owner", "Role accountable for the list's content.", "Code List", "Reference (Employee)", "", "EMP-10044", "DCAM (EDM Council)", "DAMA-DMBOK", "Y"),
       ("Data Steward", "Role maintaining the list day to day.", "Code List", "Reference (Employee)", "", "EMP-10871", "DCAM (EDM Council)", "DAMA-DMBOK", ""),
       ("Registration Status", "Registration status of the list in the registry.", "Code List", "Code", "Registry Status", "Standard", "ISO/IEC 11179", "", "Y"),
       ("Current Version", "Version currently in force.", "Code List", "Reference (Code List Version)", "", "CLV-0031-004", "ISO/IEC 11179", "", ""),
       ("Harmonization Candidate", "Shared concept the list is a candidate to be merged into during the consolidation exercise.", "Code List", "Code", "Shared Code List Candidate", "Distribution Channel", "Internal", "", "", "Harmonized value sets are out of scope for v0.1."),
       ("Extensibility", "Whether consuming domains may add local values.", "Code List", "Code", "Extensibility", "Closed", "Internal", "", ""),
     ]),
     ("Code List Consumer", [
       ("Consuming Domain", "Business domain that uses the list.", "Code List", "Code", "Business Domain", "06 Client Assets, Flows & Channel Attribution", "Internal", "", "Y"),
       ("Consuming Attribute", "Attribute ID(s) in the consuming taxonomy that take values from the list.", "Code List", "Text", "", "TX-ACC-014", "Internal", "", ""),
       ("Usage Type", "How the consumer uses the list.", "Code List", "Code", "Code List Usage Type", "Validate and Store", "Internal", "", ""),
     ]),
   ]),
   ("Versions & Values", "Versioned value sets of each list.", [
     ("Code List Version", [
       ("Code List Version ID", "Identifier of the version.", "Code List Version", "Identifier", "", "CLV-0031-004", "ISO/IEC 11179", "", "Y"),
       ("Version Effective From", "Date the version came into force.", "Code List Version", "Date", "ISO 8601", "2027-01-01", "ISO/IEC 11179", "", ""),
       ("Change Summary", "Summary of changes from the previous version.", "Code List Version", "Text", "", "Split 'Bank / Trust' into 'Bank Brokerage' and 'Trust Company'", "Internal", "", ""),
     ]),
     ("Code Value", [
       ("Code", "Stable code of the value.", "Code Value", "Code", "Firm-defined (per list)", "RIA", "ISO/IEC 11179", "", "Y"),
       ("Code Label", "Display label of the value.", "Code Value", "Text", "", "Registered Investment Adviser", "ISO/IEC 11179", "", ""),
       ("Parent Code", "Parent value in a hierarchical list.", "Code Value", "Code", "Firm-defined (per list)", "INTERMEDIARY", "Internal", "", ""),
       ("Code Value Status", "Status of the value.", "Code Value", "Code", "Reference Record Status", "Active", "Internal", "", "Y"),
       ("Replaced By Code", "Value that replaces a deprecated value.", "Code Value", "Code", "Firm-defined (per list)", "", "Internal", "", ""),
     ]),
   ]),
   ("Source-System Mappings", "Crosswalks from values used in source systems and vendor feeds to registered codes. Party-matching crosswalks stay in 06 (XWK-).", [
     ("Code Mapping", [
       ("Code Mapping ID", "Identifier of the mapping row.", "Code Mapping", "Identifier", "", "CLM-0031-00217", "Internal", "", ""),
       ("Source System", "Application (41 application inventory) or vendor feed holding the source value.", "Code Mapping", "Reference (Application, 41)", "", "APPL-00611", "Internal", "", "", "Re-typed to the 41 Application at the Stage 4 consolidation (CD-263); vendor feeds are Applications of hosting model Provider-Hosted or SaaS."),
       ("Source Value", "Code or text as delivered by the source.", "Code Mapping", "Text", "", "RIA-IND", "Internal", "", "Y"),
       ("Target Code List", "Registered list the value maps into.", "Code Mapping", "Reference (Code List)", "", "CLR-0031", "Internal", "", ""),
       ("Target Code", "Registered code the source value maps to.", "Code Mapping", "Code", "Firm-defined (per list)", "RIA", "Internal", "", "Y"),
       ("Mapping Type", "Semantic match between source and target (SKOS mapping relations).", "Code Mapping", "Code", "Mapping Type", "Exact Match", "W3C SKOS", "ISO/IEC 11179", ""),
       ("Mapping Status", "Approval status of the mapping.", "Code Mapping", "Code", "Mapping Status", "Approved", "Internal", "", ""),
     ]),
   ]),
   ("Change Control", "Requests to add, change or retire code lists and values, and their decisions.", [
     ("Code List Change Request", [
       ("Change Request Reference", "Reference of the request in the governance workflow tool.", "Code List", "Identifier", "", "CR-2026-0145", "Internal", "", ""),
       ("Change Type", "Kind of change requested.", "Code List", "Code", "Code List Change Type", "Add Value", "Internal", "DAMA-DMBOK", ""),
       ("Impact Assessment", "Consumers, mappings and reports affected.", "Code List", "Text", "", "4 consuming systems; 12 mappings to re-point; channel AUM history restated", "Internal", "", ""),
       ("Change Decision", "Outcome of the request.", "Code List", "Code", "Change Decision", "Approved", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Reference Data Management", "SR-RDM",
  "The distribution of reference data to consuming systems. Record governance metadata is 21 Record Governance Metadata (CD-160).",
  [
   ("Reference Data Distribution", "Publication of reference data sets to consuming systems.", [
     ("Reference Data Subscription", [
       ("Reference Data Set", "Registered list or master published.", "All", "Reference (Code List)", "", "CLR-0002 (Currency)", "Internal", "", ""),
       ("Subscribing System", "Application (41 application inventory) that receives the data.", "All", "Reference (Application, 41)", "", "APPL-00455", "Internal", "", "", "Re-typed to the 41 Application at the Stage 4 consolidation (CD-263)."),
       ("Distribution Method", "How the data is delivered.", "All", "Code", "Distribution Method", "API", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Subdivision Category": ("ISO 3166-2", [("State","US"),("District","e.g. US-DC"),("Outlying Area","e.g. US-PR"),("Nation","UK: England, Scotland, Wales, Northern Ireland"),("Land","Germany, Austria"),("Canton","Switzerland"),("Province",""),("Region",""),("Canton / Commune","Luxembourg")]),
 "CBSA Type": ("OMB", [("Metropolitan","Urban core of 50,000+ population"),("Micropolitan","Urban core of 10,000-49,999 population")]),
 "Geographic Unit Type": ("Internal (aligned to ISO 3166, US Census, OMB)", [("Country","ISO 3166-1"),("Country Subdivision","ISO 3166-2"),("County","US county by FIPS"),("CBSA","OMB metropolitan / micropolitan area"),("Metropolitan Division",""),("CSA","Combined statistical area"),("ZIP Code","USPS 5-digit"),("ZIP3","First three digits of ZIP"),("ZCTA","Census ZIP Code Tabulation Area"),("City / Locality",""),("Geographic Group","Firm-defined group of units")]),
 "Geographic Scheme": ("Internal", [("ISO 3166-1",""),("ISO 3166-2",""),("US Census FIPS",""),("OMB CBSA",""),("USPS ZIP",""),("US Census ZCTA",""),("Firm-Defined","")]),
 "Geographic Hierarchy Type": ("Internal", [("Political (Country > Subdivision > County)",""),("US Statistical (ZIP > County > CBSA)",""),("Firm Sales Geography","Units > sales sub-region > sales region > market")]),
 "Geographic Group Type": ("Internal", [("Sales Region","e.g. US Northeast, US West; also client service regions"),("Country Cluster","e.g. Developed Europe, Pacific ex-Japan; investment exposure and research reporting"),("Market","e.g. US - harmonizes 03 'Sales Market', 05 'Agreement Market' (Distribution Market)"),("Regulatory Region","e.g. SEC regional office area, state groupings for notice filings"),("Reporting Region","e.g. Americas, EMEA, APAC"),("Statistical Grouping","e.g. UN M49 region")]),
 "Membership Type": ("Internal", [("Include",""),("Exclude","Carve-out from an included parent")]),
 "Reference Record Status": ("Internal", [("Proposed",""),("Active",""),("Inactive",""),("Deprecated","Still valid for history, not for new records"),("Retired","")]),
 "Business Domain": ("CG Taxonomy program (domains.py; labels of the shared Business Domain list)", [("01 Investment Product & Service Offering",""),("02 Client & Household",""),("03 Advisor Organization, Coverage & Supervision",""),("04 Marketing, Digital & Client Engagement",""),("05 Intermediary & Institutional Distribution",""),("06 Client Assets, Flows & Channel Attribution",""),("07 Compensation & Territory (retired, CW-907)","Retired Data Domain; historical rows only"),("08 Retail Conduct & Supervision",""),("09 Shared & Enterprise Reference Data",""),("10 Client Revenue, Pricing Economics & Profitability",""),("11 Market & Competitive Intelligence",""),("12 Institutional Client Servicing & Reporting",""),("13 Client Service & Communications",""),("14 Third-Party Data & Licensing",""),("15 Account",""),("16 Retirement Plan Administration",""),("17 Instrument & Issuer Reference",""),("18 Portfolio & Investment Book of Record",""),("19 Finance & Accounting",""),("20 Human Capital",""),("21 Data Governance & Analytics",""),("22 Market Data & Pricing",""),("23 Investment Research",""),("24 Portfolio Management & Construction",""),("25 Portfolio Trading & Execution",""),("26 Trade Operations, Settlement & Collateral",""),("27 Fund Accounting & Valuation",""),("28 Fund Custody & Asset Servicing",""),("29 Transfer Agency Operations",""),("30 Private Markets (retired, CW-930)","Retired Data Domain; historical rows only"),("31 Investment Risk",""),("32 Performance & Attribution",""),("33 Investment Compliance",""),("34 Stewardship & Sustainable Investing",""),("35 Fund Governance & Regulatory Reporting",""),("36 Product Development & Lifecycle",""),("37 Enterprise & Operational Risk",""),("38 Corporate Compliance & Regulatory Affairs",""),("39 Legal & Corporate Governance",""),("40 Procurement & Vendor Management",""),("41 Technology & Information Security",""),("42 Corporate Communications & Public Affairs",""),("43 Corporate Treasury & Capital",""),("44 Workplace & Corporate Services",""),("45 Financial Planning & Advice",""),("46 Managed Portfolios & Rebalancing",""),("47 Pricing, Fees & Billing",""),("48 Brokerage Orders & Execution",""),("49 Clearing, Settlement & Client Asset Custody",""),("50 Money Movement, Cash & Sweep",""),("51 Trust & Estate Services",""),("52 External Manager & Sub-Adviser Oversight","")]),
 "Calendar Type": ("Internal", [("Public Holiday","National or subdivision public and bank holidays (e.g. US federal holidays, UK bank holidays)"),("Settlement (CSD / Payment System)","Business days of a settlement or payment system: US Federal Reserve Fedwire Funds Service and FedACH, DTC; foreign systems such as TARGET for the funds' foreign trades (CD-185)"),("Exchange","Trading days of a MIC"),("Bond Market","e.g. SIFMA recommended US bond market full and early closes (client and fund fixed income settlement)"),("Fund Dealing","Dealing days of a fund or fund range"),("Fiscal","Firm fiscal calendar"),("Reporting","Firm reporting calendar"),("Firm Office","Office closure days"),("Composite","Combination of other calendars")]),
 "Day of Week": ("ISO 8601", [("Monday",""),("Tuesday",""),("Wednesday",""),("Thursday",""),("Friday",""),("Saturday",""),("Sunday","")]),
 "Calendar Source": ("Internal", [("Government Publication","e.g. gov.uk bank holidays, US OPM federal holidays"),("Central Bank","e.g. Federal Reserve Financial Services holiday schedule (Fedwire, FedACH), ECB TARGET closing days"),("Exchange Publication","e.g. NYSE, LSE"),("Industry Body","e.g. SIFMA"),("Market Data Vendor",""),("Fund Administrator / TA",""),("Internal","")]),
 "Calendar Combination Rule": ("Internal", [("Holiday if Any Component Closed","Joint / union of holidays"),("Holiday if All Components Closed","Intersection of holidays")]),
 "Day Type": ("Internal", [("Business Day",""),("Holiday",""),("Weekend",""),("Half Day / Early Close",""),("Non-Dealing Day","Fund-specific"),("Dealing Day","Fund-specific, for non-daily patterns")]),
 "Dealing Day Pattern": ("Internal (every business day for '40 Act funds under SEC Rule 22c-1; less frequent patterns only for CITs or other non-daily vehicles, to confirm with Fund Operations)", [("Every Business Day",""),("Weekly - Named Weekday",""),("Fortnightly",""),("Month-End",""),("Mid-Month and Month-End",""),("Quarter-End","")]),
 "Fiscal Period Structure": ("Internal", [("12 Calendar Months",""),("4-4-5 Weeks",""),("4-5-4 Weeks",""),("13 Four-Week Periods","")]),
 "Period Type": ("Internal", [("Day",""),("Week",""),("Month",""),("Quarter",""),("Half-Year",""),("Year","")]),
 "Fiscal Period Status": ("Derived from 19 Period Close Status (group primary ledger)", [("Future",""),("Open",""),("Soft Close",""),("Closed","")]),
 "Reporting Period Basis": ("Internal (aligned to GIPS period conventions)", [("MTD","Month to date"),("QTD","Quarter to date"),("YTD","Calendar year to date"),("FYTD","Fiscal year to date"),("R3M","Rolling 3 months"),("R12M","Rolling 12 months"),("1Y",""),("3Y",""),("5Y",""),("10Y",""),("SI","Since inception"),("Custom","Explicit start and end dates")]),
 "As-Of Date Convention": ("Internal", [("Calendar Month-End",""),("Last Business Day",""),("Last Valuation Day","Fund valuation day"),("Trade Date",""),("Settlement Date","")]),
 "Business Day Convention": ("ISDA 2006 Definitions", [("Following",""),("Modified Following",""),("Preceding",""),("Modified Preceding",""),("Unadjusted","")]),
 "Currency Type": ("ISO 4217", [("National Currency",""),("Supranational Currency","e.g. EUR, XAF"),("Fund Code","e.g. USN, CLF"),("Precious Metal","e.g. XAU"),("Testing / No Currency","XTS, XXX"),("Non-ISO Market Convention","e.g. GBX, CNH - not ISO 4217; firm-defined extension")]),
 "Currency Status": ("ISO 4217", [("Current","List One"),("Historic","List Three")]),
 "FX Rate Source": ("Internal", [("LSEG WM/Reuters","WMR benchmark spot, forward and NDF rates"),("ECB","Euro foreign exchange reference rates"),("Bloomberg BFIX",""),("Federal Reserve H.10","US noon buying rates (statistical release)"),("Bank of England","Spot rates (statistical)"),("Fund Administrator","Rates applied in NAV calculation"),("Internal Treasury","Budget / planning rates")]),
 "FX Rate Type": ("Internal", [("WMR London 4pm Close Mid","WM/Reuters 16:00 London closing spot, mid"),("WMR London 4pm Close Bid / Offer",""),("WMR Intraday Fix",""),("ECB Euro Reference Rate","Published around 16:00 CET on TARGET days"),("Fund Valuation Point Rate","Rate at the fund's valuation point, per prospectus"),("Monthly Average Rate",""),("Budget Rate","Fixed planning rate for the fiscal year"),("Month-End Spot","Close rate on the reporting period end date")]),
 "Rate Side": ("Market convention", [("Mid",""),("Bid",""),("Offer","")]),
 "FX Quote Convention": ("Internal", [("Market Convention Pair","Base / quote as quoted in the market, e.g. EURUSD, GBPUSD, USDJPY"),("Units of Quote per 1 EUR","ECB convention"),("Units of Currency per 1 USD","Pivot USD")]),
 "FX Fallback Rule": ("Internal", [("Previous Published Rate",""),("Alternative Rate Type","Switch to a named alternate source"),("Triangulate via Cross Currency",""),("Manual Override with Approval","")]),
 "FX Rate Usage": ("Internal", [("NAV Valuation",""),("AUM Reporting Translation",""),("Flow Reporting Translation",""),("Fee Calculation",""),("Distribution Payment Calculation","05 revenue sharing and intermediary payments"),("Incentive Compensation","03 incentive compensation plans"),("Financial Reporting","10"),("Budget / Forecast","10")]),
 "Locale Usage": ("Internal", [("Website",""),("Advisor / Client Portal",""),("Client Documents",""),("Email",""),("Statements","")]),
 "Unit Category": ("Internal", [("Monetary Amount",""),("Ratio","Percent, basis points, per mille"),("Count",""),("Duration","Days, months, years"),("Rate per Period",""),("Data Volume","")]),
 "Rounding Rule": ("IEEE 754 / Internal", [("Half Even","Banker's rounding"),("Half Up",""),("Truncate",""),("Up","")]),
 "Percentage Storage Convention": ("Internal", [("Decimal Fraction","0.0075 = 0.75%"),("Percent","0.75 = 0.75%"),("Basis Points","75 = 0.75%")]),
 "Internal Entity Category": ("Internal (aligned to FIBO FBC functional entities; US registrations per SEC Form ADV, Form BD, Form TA-1 and OCC charter)", [("Parent Holding Company","Ultimate parent of the group"),("Intermediate Holding Company",""),("Registered Investment Adviser","SEC-registered adviser (Form ADV) giving advice and managing client accounts"),("Broker-Dealer (self-clearing)","SEC-registered broker-dealer and FINRA member (Form BD) that carries and clears client accounts; principal underwriter of the funds"),("Fund Adviser","SEC-registered adviser (Form ADV) to the proprietary funds; oversees sub-advisers"),("Fund Trust (registrant)","Statutory or business trust registered under the Investment Company Act that issues the funds"),("Transfer Agent","SEC-registered transfer agent (Form TA-1) of the funds"),("Recordkeeper","Workplace plan recordkeeper"),("National Trust Company","OCC-chartered national trust company; CIT trustee and personal trust services (optional)"),("General Partner / Fund Vehicle Sponsor",""),("Service Company","Employment, shared services"),("Branch","Non-legal-person branch")]),
 "Legal Entity Status": ("GLEIF LEI-CDF / Internal", [("Active",""),("Dormant",""),("In Liquidation",""),("Merged",""),("Dissolved","")]),
 "LEI Registration Status": ("GLEIF LEI-CDF", [("PENDING_VALIDATION",""),("ISSUED",""),("LAPSED","Not renewed"),("MERGED",""),("RETIRED",""),("ANNULLED",""),("DUPLICATE",""),("TRANSFERRED",""),("PENDING_TRANSFER",""),("PENDING_ARCHIVAL","")]),
 "Ownership Relationship Type": ("GLEIF RR-CDF / FIBO BE", [("Direct Accounting Consolidation Parent","GLEIF IS_DIRECTLY_CONSOLIDATED_BY"),("Ultimate Accounting Consolidation Parent","GLEIF IS_ULTIMATELY_CONSOLIDATED_BY"),("Branch Of","GLEIF IS_INTERNATIONAL_BRANCH_OF"),("Minority Ownership","Not consolidated"),("Joint Venture","")]),
 "GLEIF Reporting Exception": ("GLEIF Level 2 reporting exceptions (verify against current GLEIF documentation)", [("NATURAL_PERSONS","Controlled by natural persons"),("NON_CONSOLIDATING","Parent does not consolidate"),("NO_KNOWN_PERSON","No known controlling person"),("NON_PUBLIC","Disclosure restricted"),("NO_LEI","Parent has no LEI")]),
 "Entity Distribution Role": ("Internal (aligned to FIBO FBC, 01 'Party Role Type'; US roles)", [("Principal Underwriter","Principal underwriter of the '40 Act funds (the firm's broker-dealer)"),("Distributor","Distributor of CITs, model portfolios or other products without a principal underwriter"),("Selling Dealer or Agent","Broker-dealer that sells funds and other products to its own clients under a selling or dealer agreement"),("Placement Agent","Places private offerings, e.g. feeder funds (CW-038)"),("Transfer Agent","Registered transfer agent of the funds (Form TA-1)"),("Recordkeeper","Recordkeeper of workplace retirement plans"),("529 Program Manager","Program manager of a state 529 plan (CW-037)"),("Investment Manager",""),("Sub-Adviser",""),("Model Provider","Model portfolio delivery"),("Employing Entity for Registered Personnel","Employs the advisors and registered representatives (03, 20)"),("Contracting Entity for Intermediary Agreements","Signs the 05 intermediary and institutional agreements")]),
 "Org Unit Type": ("Internal", [("Division",""),("Business Unit",""),("Department",""),("Team",""),("Desk",""),("Cost Center Node","Finance-only grouping"),("Committee","")]),
 "Business Function": ("Internal", [("Distribution",""),("Marketing",""),("Investment Management",""),("Product",""),("Operations",""),("Finance",""),("Legal & Compliance",""),("Technology & Data",""),("HR",""),("Executive","")]),
 "Org Hierarchy Type": ("Internal", [("Management","Reporting lines for people management"),("Legal Entity","Units by booking entity"),("Cost Center","Finance roll-up (aligned to 19 Chart Segment Value hierarchy)"),("Distribution Organization","Channel / region structure used by 03")]),
 "Reorganization Type": ("Internal", [("Create",""),("Merge",""),("Split",""),("Move","Change of parent"),("Rename",""),("Close","")]),
 "Restatement Rule": ("Internal", [("Restate Prior Periods",""),("Keep As Booked",""),("Restate Current Year Only","")]),
 "Industry Classification Scheme": ("Various", [("NAICS","US / Canada / Mexico; OMB / Census"),("US SIC","Legacy US SIC 1987; still used by SEC EDGAR"),("GICS","MSCI / S&P - licensed"),("ISIC","UN")]),
 "Correspondence Type": ("Internal", [("One-to-One",""),("Partial (One-to-Many)",""),("Partial (Many-to-One)",""),("Many-to-Many","")]),
 "Code List Class": ("Internal (DAMA-DMBOK reference data categories)", [("Enterprise Shared","Governed by 09; used by more than one domain"),("Domain-Specific","Owned and used by one business domain"),("External Standard","ISO / regulator list, loaded not edited"),("External Vendor","Vendor-maintained, licensed via 14")]),
 "Registry Status": ("ISO/IEC 11179 registration status", [("Candidate",""),("Recorded",""),("Qualified",""),("Standard",""),("Preferred Standard",""),("Superseded",""),("Retired","")]),
 "Extensibility": ("Internal", [("Closed","No local values"),("Extensible with Approval",""),("Locally Extensible","Domain may add values mapped to a parent")]),
 "Code List Usage Type": ("Internal", [("Validate and Store",""),("Display Only",""),("Map Inbound",""),("Report / Aggregate","")]),
 "Mapping Type": ("W3C SKOS", [("Exact Match",""),("Close Match",""),("Broad Match","Source narrower than target"),("Narrow Match","Source broader than target"),("Related Match",""),("Unmapped","Held for steward review")]),
 "Mapping Status": ("Internal", [("Proposed",""),("Approved",""),("Rejected",""),("Retired","")]),
 "Code List Change Type": ("Internal", [("New List",""),("Add Value",""),("Change Label / Definition",""),("Deprecate Value",""),("Merge Values",""),("Split Value",""),("Retire List","")]),
 "Change Decision": ("Internal", [("Approved",""),("Approved with Changes",""),("Rejected",""),("Deferred","")]),
 "Distribution Method": ("Internal", [("API",""),("File (SFTP)",""),("Message / Event Stream",""),("Database Replication",""),("Catalog Download","")]),
 "Shared Code List Candidate": ("CG Taxonomy cross-domain scan (draft v0.1); harmonized values to be agreed in the consolidation exercise", [("Distribution Channel","01 'Distribution Channel', 02 'Distribution Channel', 03 'Sales Channel', 04 'Business Channel', 05 'Partner Channel', 06 'Distribution Channel'"),("Frequency","01, 03, 05, 06, 08 'Frequency'"),("Investor Type / Client Category","01 'Investor Type', 02 'Investor Type'"),("Lifecycle / Record Status","01 'Lifecycle Status', 'Data Quality Status' in all of 01-08, plus many domain status lists"),("Party Role","01 'Party Role Type', 02 'Party Role Type'"),("Registration Status","01, 02, 04, 08 'Registration Status'"),("Market / Sales Market","03 'Sales Market', 05 'Agreement Market' - model as Geographic Group Type = Market"),("Approval Status","08"),("Payment Status","05"),("Networking Level","02, 05"),("Qualification Exam","02, 08"),("Screening Result","02, 08"),("Personal Data Category","02, 03"),("Social Platform","04, 08"),("Snapshot Type","03, 06"),("Message Standard","05, 06"),("Data Classification","06"),("Legal Entity (firm-defined)","08 - replace with LEN- reference")]),
}

# ---------------------------------------------------------------------------
# Relationships, sources
# ---------------------------------------------------------------------------
REL = [
 ("Country","contains","Country Subdivision","1 : 0..n","ISO 3166-2 subdivisions; multi-level for e.g. GB."),
 ("Geographic Unit (parent)","is parent of","Geographic Unit (child)","1 : 0..n","Per Geographic Hierarchy Type; effective-dated; allocation share where a child spans parents."),
 ("Geographic Group","contains","Geographic Unit","n : m","Include / exclude membership, effective-dated; groups may nest."),
 ("Coverage Assignment Rule (03, ASRL-)","uses as assignment geography","Geographic Unit / Geographic Group","n : m","03 owns coverage assignment rules (CW-062); 09 owns the units and groups they use."),
 ("Postal Address (02 CC)","references","Country / Country Subdivision / Postal Code","n : 1","02 stores the address; codes validated against 09."),
 ("Country","uses","Currency; Time Zone; Language","n : m","Defaults only; products and parties hold their own values."),
 ("Composite Calendar","combines","Calendar","1 : 2..n","Union or intersection of holidays."),
 ("Calendar","has","Calendar Date","1 : 0..n",""),
 ("Fund Dealing Calendar","is based on","Business Calendar / Exchange Calendar","n : m","Base calendar plus market closure calendars."),
 ("Investment Product (01 PRD-)","deals according to","Fund Dealing Calendar (CAL-)","n : 1","01 'Dealing Calendar' attribute; cut-off and valuation point stay in 01."),
 ("Fiscal Calendar","has","Fiscal Period","1 : 1..n",""),
 ("Reporting Period Definition","is used by","Reporting Period / Snapshot (06), Profitability record (10), Client Report (12)","1 : 0..n","Consumers own their own close and lock dates."),
 ("FX Rate Type","is sourced from","FX Rate Source","n : 1",""),
 ("FX Rate Source","is licensed under","Dataset (14 TD, DSET-)","n : 0..1","License terms and entitlements owned by 14."),
 ("Currency","is used as","Base / Share Class / Reporting Currency (01, 06, 10)","1 : 0..n","ISO 4217 code is the enterprise key."),
 ("Locale","is used by","Digital Property / Content Asset (04 MK)","1 : 0..n","Language and locale of websites, portals and assets."),
 ("Internal Legal Entity (child)","is owned / consolidated by","Internal Legal Entity (parent)","n : 0..n","GLEIF Level 2 direct and ultimate parent; effective-dated."),
 ("Internal Legal Entity","is cross-referenced to","Party (02 CC, PTY-)","1 : 0..1","Lets 01 product party roles and 05 agreements keep using PTY- for group entities."),
 ("Internal Legal Entity","performs","Entity Distribution Role","1 : 0..n","Scoped by market (Geographic Group), channel and product range."),
 ("Internal Legal Entity","is contracting party to","Agreement (05 DA, AGR-)","1 : 0..n","Via the PTY- cross-reference until 05 adds a LEN- reference."),
 ("Internal Legal Entity","employs / registers","Employee (20 HC, EMP-) / License (08 DC, LIC-)","1 : 0..n","20 'Employing Legal Entity' (employee master moved from 09 under CD-151); 08 'Registering Firm' and 'Applicable Legal Entity' should reference LEN-."),
 ("Org Unit (parent)","is parent of","Org Unit (child)","1 : 0..n","Per Org Hierarchy Type; effective-dated."),
 ("Org Unit","is booked in","Internal Legal Entity","n : 1",""),
 ("Org Unit","is represented by","Chart Segment Value (cost / profit center) [19]","1 : 0..n","Chart of accounts owned by 19 (CD-152); allocations owned by 10."),
 ("Sales Team (03 SL, SLT-)","belongs to","Org Unit","n : 1",""),
 ("Reorganization","changes","Org Unit","1 : 1..n","Source and target units with restatement rule."),
 ("Classification Scheme","contains","Classification Code","1 : 1..n","Hierarchical via Parent Classification Code."),
 ("Organization (02 CC, PTY-)","is classified by","Classification Code","n : m","02 holds the assignment; 09 holds the scheme."),
 ("Code List Registry Entry (CLR-)","has","Code List Version (CLV-)","1 : 1..n",""),
 ("Code List Version","contains","Code Value","1 : 1..n",""),
 ("Code Value","is mapped from","Code Mapping (CLM-)","1 : 0..n","Source-system and vendor values; party-matching crosswalks stay in 06 XWK-."),
 ("Code List Registry Entry","is consumed by","Business Domain attribute (01-14)","1 : 0..n","Consumer registration drives change impact assessment."),
]

SRC = [
 ("ISO 3166 Country Codes (3166-1, 3166-2) and Online Browsing Platform","ISO 3166 Maintenance Agency","https://www.iso.org/iso-3166-country-codes.html ; https://www.iso.org/obp/ui","Standard; codes browsable free, data files licensed","Country and subdivision codes and statuses","Countries & Subdivisions, Geographic Unit",["ISO 3166"]),
 ("ISO 4217 Currency Codes and amendments","ISO; SIX Financial Information (Maintenance Agency secretariat)","https://www.six-group.com/en/products-services/financial-information/data-standards.html","Free lists (List One / Three) from SIX","Alphabetic / numeric codes, minor units, historic currencies; Amendment 180: BGN replaced by EUR from 1 Jan 2026","Currency",["ISO 4217"]),
 ("ISO 639 Language Codes","ISO 639 Registration Authority (Library of Congress / SIL)","https://www.loc.gov/standards/iso639-2/ ; https://iso639-3.sil.org","Free","Two- and three-letter language codes","Language",["ISO 639"]),
 ("IETF BCP 47 (RFC 5646 / 4647) and IANA Language Subtag Registry","IETF; IANA","https://www.rfc-editor.org/info/bcp47 ; https://www.iana.org/assignments/language-subtag-registry","Free","Locale / language tags","Locale",["IETF BCP 47"]),
 ("Unicode CLDR","Unicode Consortium","https://cldr.unicode.org","Free (Unicode license)","Locale data: number and date formats, currency symbols, Windows-to-IANA zone mapping","Locale, Number & Date Convention, Time Zone",["Unicode CLDR"]),
 ("IANA Time Zone Database (tzdata)","IANA","https://www.iana.org/time-zones","Public domain","Time zone identifiers and rules, several releases per year","Time Zone, Calendar time zones",["IANA tz"]),
 ("ISO 8601 / ISO 10383 (MIC) / ISO 15924 / ITU-T E.164","ISO; SWIFT (MIC RA); Unicode (15924 RA); ITU","https://www.iso.org/iso-8601-date-and-time-format.html ; https://www.iso20022.org/market-identifier-codes","Standard; MIC list free","Date / time format, market identifiers, scripts, telephone codes","Calendars, Locale, Country",["ISO 8601","ISO 10383","ITU-T E.164"]),
 ("US Census Bureau FIPS / ANSI codes and ZIP Code Tabulation Areas","US Census Bureau","https://www.census.gov/library/reference/code-lists/ansi.html ; https://www.census.gov/programs-surveys/geography/guidance/geo-areas/zctas.html","Public domain","State and county codes; ZCTA approximations of ZIP codes","US County, ZIP Code & ZCTA, Subdivision",["US Census (FIPS)","US Census (ZCTA)"]),
 ("OMB Bulletin 23-01: Revised Delineations of Metropolitan / Micropolitan Statistical Areas","US Office of Management and Budget","https://www.whitehouse.gov/wp-content/uploads/2023/07/OMB-Bulletin-23-01.pdf ; https://www.census.gov/programs-surveys/metro-micro/about.html","Public domain","CBSA, metropolitan division and CSA delineations (21 Jul 2023, supersedes 20-01)","Core Based Statistical Area",["OMB CBSA"]),
 ("HUD-USPS ZIP Code Crosswalk Files and USPS ZIP data","US Department of Housing and Urban Development; USPS","https://www.huduser.gov/portal/datasets/usps_crosswalk.html","Free (registration)","ZIP-to-county / CBSA address ratios; ZIP types","Preferred County, ZIP-to-County Ratio",["HUD-USPS Crosswalk","USPS"]),
 ("LSEG WM/Reuters FX Benchmarks (WMR London 4pm Close)","LSEG Benchmark Services Ltd","https://www.lseg.com/en/data-analytics/financial-data/benchmarks/foreign-exchange-benchmarks","Licensed (via 14)","Spot, forward and NDF benchmark rates; 4pm fix from trades and quotes in a window around 16:00 London; used for the firm's funds that hold foreign assets","FX Rate Source, FX Rate Type",["LSEG WM/Reuters"]),
 ("ECB euro foreign exchange reference rates","European Central Bank","https://www.ecb.europa.eu/stats/policy_and_exchange_rates/euro_reference_exchange_rates/html/index.en.html","Free; for information only, not for transactions","Daily EUR reference rates, concertation around 14:10 CET, published around 16:00 CET on TARGET days","FX Rate Type, Quote Convention, Publication Calendar",["ECB"]),
 ("SIFMA holiday recommendations for US dollar fixed income (full and early closes)","Securities Industry and Financial Markets Association (SIFMA)","https://www.sifma.org","Free (published annually; confirm the holiday schedule page URL)","Recommended full and early (2:00 p.m. ET) closes for US bond markets; recommendations only, each firm decides","Calendar Type (Bond Market), Calendar Source",["SIFMA"]),
 ("Federal Reserve Financial Services holiday schedules (Fedwire Funds Service, FedACH)","Federal Reserve Banks","https://www.frbservices.org/about/holiday-schedules","Free","Reserve Bank holidays, weekend observance rules and FedACH processing windows; Fedwire Funds Service operation on Sundays and weekday holidays announced for no earlier than 2028 (confirm)","Calendar Type (Settlement (CSD / Payment System)), Calendar Source",["Federal Reserve Financial Services"]),
 ("SEC Rule 22c-1 (17 CFR 270.22c-1), forward pricing","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.22c-1","Regulation","Daily computation of net asset value for redeemable fund shares; basis of the every-business-day dealing pattern","Dealing Calendar Rule, Dealing Day Pattern",["SEC Rule 22c-1"]),
 ("ISDA 2006 Definitions (business day conventions)","ISDA","https://www.isda.org","Member / purchase","Following, modified following and preceding conventions","Business Day Convention",["ISDA"]),
 ("GLEIF LEI-CDF 3.1, RR-CDF 2.1 (Level 2) and Entity Legal Form list; ISO 17442 / ISO 20275","GLEIF; ISO","https://www.gleif.org/en/about-lei/common-data-file-format/relationship-record-cdf-format ; https://www.gleif.org/en/about-lei/code-lists/iso-20275-entity-legal-forms-code-list","Open data (CC0)","Level 1 entity data, registration status, direct / ultimate accounting consolidation parents, reporting exceptions, legal forms","Legal Entity Master, Group Structure & Ownership",["GLEIF LEI-CDF","GLEIF RR-CDF","ISO 17442 (GLEIF)","ISO 20275"]),
 ("FIBO Business Entities (BE: Legal Entities, Ownership and Control) and FBC Functional Entities","EDM Council","https://spec.edmcouncil.org/fibo/ontology/BE/OwnershipAndControl/ ; https://spec.edmcouncil.org/fibo/ontology/FBC/FunctionalEntities/","Open (MIT license)","Legal persons, ownership and control parties, regulated financial service providers","Legal Entity Master, Ownership, Entity Roles",["FIBO BE","FIBO FBC"]),
 ("SEC Form ADV / Form BD / Form TA-1 / EDGAR CIK and FINRA BrokerCheck / CRD","US SEC; FINRA","https://adviserinfo.sec.gov ; https://brokercheck.finra.org ; https://www.sec.gov/edgar","Public registers","Adviser, broker-dealer and transfer agent registration, CRD, CIK and SEC file numbers (801-, 8-, 84-, and 811- for fund trusts under the Investment Company Act), annual updating amendments","Internal Entity Category, Legal Entity Identifier (registrations mastered in 38)",["SEC Form ADV","SEC EDGAR","FINRA"]),
 ("OCC national trust bank charters and licensing","US Office of the Comptroller of the Currency","https://www.occ.gov","Public register; regulation","Charter of a national trust company (charter number; confirm the register page)","Internal Entity Category (National Trust Company)",["OCC"]),
 ("NAICS (2022; 2027 revision in progress)","US Census Bureau / OMB ECPC","https://www.census.gov/naics/","Public domain","North American industry classification; 2017-2022 concordances (523920 and 523930 combined into 523940)","Industry Classification",["NAICS"]),
 ("US SIC (1987) as used by SEC EDGAR","US OMB (legacy); SEC","https://www.sec.gov/search-filings/standard-industrial-classification-sic-code-list","Public domain","Legacy industry codes still assigned to SEC registrants","Industry Classification",["US SIC"]),
 ("GICS","MSCI and S&P Dow Jones Indices","https://www.msci.com/indexes/index-resources/gics","Licensed (via 14)","Sector / industry group / industry / sub-industry for companies","Industry Classification",["GICS"]),
 ("ISO/IEC 11179-3:2023 Metadata registries - Registry metamodel","ISO/IEC JTC 1/SC 32","https://www.iso.org/standard/78915.html","Standard (purchase)","Registry items, designation, definition, registration status, classification and mapping","Enterprise Code List Registry",["ISO/IEC 11179"]),
 ("W3C SKOS Reference (mapping properties)","W3C","https://www.w3.org/TR/skos-reference/","Free","exactMatch, closeMatch, broadMatch, narrowMatch, relatedMatch","Code Mapping",["W3C SKOS"]),
 ("DAMA-DMBOK 2nd ed. (rev.), Ch. 10 Reference and Master Data","DAMA International","https://www.dama.org/cpages/body-of-knowledge","Book (purchase)","Reference data management: code lists, taxonomies, crosswalks, governance and change control","Code List Registry, Reference Data Management",["DAMA-DMBOK"]),
 ("DCAM","EDM Council","https://edmcouncil.org","Member framework","Data ownership, stewardship and governance","Data Owner / Steward",["DCAM*"]),
 ("UN/ECE Recommendation 20 and UCUM","UNECE; Regenstrief Institute","https://unece.org/trade/uncefact/cl-recommendations ; https://ucum.org","Free","Units of measure codes","Unit of Measure",["UN/ECE Rec 20","UCUM"]),
]
