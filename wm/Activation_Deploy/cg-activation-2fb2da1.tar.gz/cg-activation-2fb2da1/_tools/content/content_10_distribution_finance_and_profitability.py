"""Data Domain 10 - Client Revenue, Pricing Economics & Profitability (wealth-manager reference model; adapts the wholesale 10
Distribution Finance & Profitability in place, CW-012, CW-156 to CW-159). Content module for taxonomy_builder.py."""

META = {
 "title": "Client Revenue, Pricing Economics & Profitability Data Taxonomy",
 "subtitle": "Business domain 10 - Client Revenue, Pricing Economics & Profitability | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-15",
 "output": "10_Distribution_Finance_and_Profitability/Distribution_Finance_and_Profitability_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the management-accounting view of a US wealth manager that serves investors directly: self-directed brokerage, digital and human advice, its own mutual funds, ETFs and CITs, workplace retirement recordkeeping, institutional advisory, a thin intermediary channel and optional personal trust services. The domain answers what each client account, Client Household, service offering, channel, business line and client segment earns and costs: revenue recognized under ASC 606 (advisory, wrap and planning fees, commissions, account service fees, margin interest, fully paid lending revenue, cash sweep economics, own-fund management and fulcrum fees, plan recordkeeping and trust fees), fund expense support, contract costs under ASC 340-40, cost allocation, profitability, cost to serve, client acquisition cost and lifetime value, and the economics of a price change. Built from US GAAP (ASC 606, ASC 340-40, ASC 280), the AICPA Revenue Recognition Guide (asset management chapter), the Advisers Act performance fee rules, SEC Rule 12b-1, IRC section 482, the US GAAP Financial Reporting Taxonomy, the FOCUS report and management-accounting practice (time-driven activity-based costing). Use it as a starting point for a client profitability engine, a finance data mart, a chart-of-accounts mapping or a business glossary."),
  ("Scope", "In scope: revenue contracts and performance obligations; booked fund revenue (management, fulcrum and 12b-1 fees) per share class; Client Revenue Record (CLREV-) per account (or 47 Fee Household), revenue stream and month; Cash Program Economics per sweep program and program bank; fund-level waivers and reimbursements and adviser-borne fund costs; cost items, accruals and true-ups; contract cost assets and capitalization assessments; mapping of management P&L lines to 19 GL accounts and reconciliation controls; cost pools, allocation methods, drivers (including time-driven activity-based costing), rules, runs and results; profitability records and measures by offering, channel, business line, client segment, service tier, Client Household and advisor; cost-to-serve profiles; client acquisition cost, lifetime value models (LTVM-) and estimates; pricing scenarios (PRSC-) and their projected results; management hierarchies and restatements; budgets, forecasts and variances; intercompany agreements, transfer pricing policies and charges between the firm's US entities. Out of scope (referenced by ID only): client fee schedules, calculations, debits, invoices and waivers (47, CLFEE-, FCRUN-, FDBT-, BIL-, FWV-); fund fee terms, products, share classes, service offerings and tiers (01, FSCH-, SHC-, OFFR-); parties, Client Households and segments (02, PTY-, PTY-HH-); accounts and agreements (15, ACC-, AAG-); client assets and net new assets (06, MSR-, CHASG-); executions and commissions (48, CLEXE-); client account activity, margin and fully paid lending (49, CLACT-, CSLN-); sweep programs and program banks (50, SWEEP-, PGBNK-); campaigns and acquisition milestones (04, CAM-); advisor compensation and incentive plans (03, CPS-, ICP-); partner payments of the intermediary channel (05, PYA-, PCL-, PMT-); fund advisory agreements (35, ADVA-); sub-adviser engagements (52, SADV-); competitor prices and fee benchmarks (11); product change initiatives (36, LCHG-); journals, postings, certified revenue and the chart of accounts (19, JNL-, GLA-); legal entities and fiscal periods (09, LEN-)."),
  ("Structure", "Four levels: Data Domain > Data Family > Data Business Object > Data Business Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Revenue side: Revenue Contract (RVC-: the 35 fund advisory agreement, the 15 client account agreement, the 16 plan service arrangement, the 51 trust or the 01 institutional mandate) -> Performance Obligation -> Fee Revenue Record (FRR-) per own-fund share class and period, net of fund-level Waiver Records (WVR-), with Performance Fee Record (PFR-) and Distribution Revenue Record beside it; Client Revenue Record (CLREV-) per account x revenue stream x month, each row pointing at its calculating records (47 Account Fee Calculation, Fee Invoice, Fee Debit or Fee Adjustment, 48 Client Trade Confirmation, 49 Client Account Activity or Fully Paid Securities Loan, 50 Sweep Allocation); Cash Program Economics per 50 Sweep Program x Program Bank x period. Cost side: source records (03 Compensation Statement, 05 Payment Calculation, 04 Spend Line, 14 data license costs, 40 and 19 supplier invoices) -> Distribution Cost Item (DCO-) -> Accrual (ACR-) / true-up, mapped by Account Mapping (ACM-) to 19 GL accounts; qualifying costs -> Contract Cost Asset (CCA-). Allocation: Cost Pool (CPO-) -> Allocation Rule (ARU-) with an Allocation Method (ALM-) and Driver (DRV-) -> Allocation Run (ARN-) -> Allocation Results. Output: Profitability Record (PNL-) at a declared grain and version with its measures and Cost-to-Serve Profile, rolled up through Management Hierarchies (MHY-, Management Hierarchy Node) with Hierarchy Restatements (HRS-). Client economics: Client Acquisition Cost Record, Lifetime Value Model (LTVM-) -> Client Lifetime Value Estimate; Pricing Scenario (PRSC-) -> Pricing Scenario Result. Plans: Plan Version (BUD-) -> Plan Line, Flow & Revenue Forecast, Variance, rolled into 19 FPL-. Entities: Intercompany Agreement (ICA-) under a TP Policy -> Intercompany Charge (ICC-)."),
  ("Design principles", "1) Account for, never recalculate (CW-156): every amount on a Client Revenue Record or Distribution Cost Item references the record that calculated it in 47, 48, 49, 50, 16, 51, 03, 04 or 05; 10 adds the recognition period, entity, offering, channel, business line and ledger mapping. 2) Calculated fee is 47, recognized revenue is 10, certified revenue is 19 (CW-012, CW-011, DP-191): bare 'Fee' means the 47 client fee; 10 names its records Fee Revenue (own funds) and Client Revenue. 3) No balances (CW-007): average client assets, swept balances and lending balances are Derived copies with their source and as-of date; 10 masters no Client Holding, cash or sweep balance. 4) Economics, not the price (CW-158): a Pricing Scenario references the 47 Fee Schedule version, the 01 fund fee terms and the 36 initiative and holds no adopted rate. 5) Every profitability, cost-to-serve and lifetime value figure declares its version, grain, hierarchy version, allocation run or model version so that it can be reproduced. 6) Effective-dated mappings, hierarchies, rules, models and TP policies; history is restated only through a recorded Hierarchy Restatement. 7) Household-level economics are restricted personal financial inferences: products show segment aggregates (CW-157)."),
  ("Applies To", "Shows the record type each attribute is held on: Revenue Contract, Performance Obligation, Fee Revenue Record, Performance Fee Record, Distribution Revenue Record, Client Revenue Record, Cash Program Economics, Waiver Record, Adviser-Borne Cost, Distribution Cost Item, Accrual, Contract Cost Asset, Capitalization Assessment, Account Mapping, Control, Cost Pool, Allocation Method, Allocation Driver, Allocation Rule, Allocation Run, Allocation Result, Profitability Record, Profitability Measure, Cost-to-Serve Profile, Acquisition Cost, Lifetime Value Model, Lifetime Value Estimate, Pricing Scenario, Pricing Scenario Result, Management Hierarchy, Management Hierarchy Node, Hierarchy Restatement, Plan Version, Plan Line, Forecast, Variance, Intercompany Agreement, TP Policy or Intercompany Charge."),
  ("CDE", "Y = proposed Critical Data Element: needed to recognize or report revenue and expense correctly, to post to the ledger, to reproduce a profitability, cost-to-serve, allocation or lifetime value result, to evidence a pricing decision, or to evidence arm's-length intercompany pricing. Confirm with data owners (Financial Reporting, FP&A, Client Economics, Tax)."),
  ("Primary / Secondary Reference", "Standard or source the attribute definition is aligned to (ASC 606, ASC 340-40, ASC 280, AICPA Revenue Recognition Guide, Advisers Act Rules 205-1 to 205-3, SEC Rule 12b-1, IRC section 482 and Treas. Reg. section 1.482, FOCUS report, Form ADV Part 2A, US GAAP Taxonomy, TDABC). 'Internal' = firm-defined; there is no authoritative external definition (most management-accounting attributes fall here). Next step: confirm the exact ASC paragraph and US GAAP Taxonomy element for each CDE with Financial Reporting."),
  ("Notes", "PII = personal information under the GLBA, Regulation S-P and US state privacy laws. Client Revenue Record and Client Lifetime Value Estimate are 'PII - financial'; the household and advisor rows of Profitability Record and Cost-to-Serve Profile are 'PII - financial' (household) or confidential (advisor); every other object is 'No PII'. The tier is stated in the Notes of the first attribute of each object that holds personal data. No cost item carries one person's pay amount: advisor compensation is booked per cost center and period with the 03 Compensation Statements as source records."),
  ("Tabs", "Hierarchy: families, object groups and objects with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: object-level cardinalities, including references to other Data Domains | Sources: standards and rules used, with links."),
  ("Suggested next steps", "1) Validate with Financial Reporting and Technical Accounting, FP&A, Client Economics, Brokerage Finance, Fund Treasury and Tax. 2) Confirm the revenue-recognition positions (customer determination, principal versus agent on 12b-1, the fulcrum fee constraint, capitalization of advisor and referral incentives, the recognizing entity of bank sweep fees) against the accounting policy papers. 3) Agree the hand-off contracts with 47 (Account Fee Calculation, Fee Invoice), 48, 49, 50, 16 and 51 (source record IDs and amounts) and with 06 (client asset measures, channel assignment). 4) Agree cost pools, drivers and the cost-to-serve components with FP&A and the service, operations and technology owners; pilot one quarter for the digital advice offering. 5) Register the lifetime value model in the 37 model inventory. 6) Turn the Relationships tab into a logical data model."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Revenue & Recognition", "DF-REV",
  "Revenue the firm's US entities earn and recognize under ASC 606: own-fund management, fulcrum and 12b-1 fees, and client revenue per account (advisory, brokerage, cash, lending, plan recordkeeping and trust), with the contracts and performance obligations that govern recognition. Fees are calculated in 47 and certified on the ledger in 19.",
  [
   ("Revenue Contracts & Performance Obligations", "The contract with a customer under ASC 606 and the promises within it: the fund advisory agreement with an own fund, the advisory or brokerage agreement with a client, the plan recordkeeping arrangement with a sponsor, the trust agreement or the institutional mandate.", [
     ("Revenue Contract", [
       ("Revenue Contract ID", "Unique identifier of the revenue contract as defined for revenue recognition.", "Revenue Contract", "Identifier", "", "RVC-000231", "Internal", "ASC 606", "Y"),
       ("Revenue Contract Type", "Type of contract that gives rise to revenue.", "Revenue Contract", "Code", "Revenue Contract Type", "Advisory Agreement (Client)", "ASC 606", "AICPA Revenue Recognition Guide", ""),
       ("Identified Customer", "Party identified as the customer for revenue recognition: the fund for fund advisory and 12b-1 fees, the client (or the Client Household billed as one) for advisory, brokerage, planning and trust contracts, the plan sponsor for recordkeeping, the institution for a mandate.", "Revenue Contract", "Reference (Party)", "", "PTY-000012 (Example Funds Trust - Growth Fund)", "ASC 606", "AICPA Revenue Recognition Guide", "Y"),
       ("Customer Determination Basis", "Conclusion on who the customer is, which drives the treatment of sales loads, consideration payable and costs to obtain.", "Revenue Contract", "Code", "Customer Determination Basis", "Client is Customer", "AICPA Revenue Recognition Guide", "ASC 606", ""),
       ("Underlying Agreement", "Legal agreement the revenue contract is based on: the 35 fund advisory agreement, the 15 account agreement, the 16 plan service arrangement, the 51 trust, the 01 mandate, the board-approved underwriting contract (35) or, for intermediary selling and servicing, the 05 distribution agreement.", "Revenue Contract", "Reference (Fund Advisory Agreement / Account Agreement / Service Arrangement / Trust / Mandate / Agreement)", "", "ADVA-00041", "Internal", "", "", "Row rule (CD-232, CW-156): Revenue Contract Type 'Investment Advisory Agreement (Fund)' references 35 Fund Advisory Agreement (ADVA-); 'Advisory Agreement (Client)' and 'Brokerage Customer Agreement' reference 15 Account Agreement (AAG-); 'Plan Recordkeeping Agreement' references 16 Service Arrangement (PSVA-); 'Trust Agreement' references 51 Trust (TRUST-); 'Investment Management Agreement (Mandate)' references 01 Investment Mandate (MND-); 'Principal Underwriting / Distribution Agreement' references the 35 underwriting contract approved by the board under Investment Company Act section 15(b); 'Shareholder Servicing Agreement' with intermediaries references 05 Distribution Agreement (AGR-)."),
       ("Contracting Legal Entity", "Internal legal entity that is party to the contract and records the revenue: the RIA, the broker-dealer (also principal underwriter), the fund adviser, the transfer agent, the recordkeeper or the trust company.", "Revenue Contract", "Reference (Legal Entity)", "", "LEN-0003", "Internal", "ASC 606", "Y"),
       ("Accounting Framework", "Accounting basis under which the contracting entity reports the revenue.", "Revenue Contract", "Code", "Accounting Basis", "US GAAP", "Internal", "", "Y"),
       ("Contract Inception Date", "Date the contract became enforceable.", "Revenue Contract", "Date", "ISO 8601", "2019-04-01", "ASC 606", "", ""),
       ("Termination Notice Period", "Days' notice either party needs to terminate without penalty. Short notice periods limit the contract term for revenue and cost amortization purposes (a fund advisory contract is terminable on 60 days' notice).", "Revenue Contract", "Integer", "Days", "60", "ASC 606", "Investment Company Act §15(a)", ""),
     ]),
     ("Performance Obligation", [
       ("Performance Obligation Type", "Distinct promise to transfer services to the customer.", "Performance Obligation", "Code", "Performance Obligation Type", "Investment Advisory Services (Series)", "ASC 606", "AICPA Revenue Recognition Guide", ""),
       ("Satisfaction Pattern", "Whether the obligation is satisfied over time or at a point in time (trade execution is satisfied on the trade date).", "Performance Obligation", "Code", "Satisfaction Pattern", "Over Time", "ASC 606", "", "Y"),
       ("Series Guidance Applied Indicator", "Whether the obligation is a series of distinct service periods, so that variable fees are allocated to the period in which they are earned.", "Performance Obligation", "Boolean", "", "Y", "ASC 606", "AICPA Revenue Recognition Guide", ""),
       ("Revenue Stream", "Revenue stream the obligation generates.", "Performance Obligation", "Code", "Revenue Stream", "Advisory Fee", "Internal", "US GAAP Taxonomy", ""),
       ("Stream Principal vs Agent Conclusion", "Whether the firm is principal (revenue presented gross, third-party costs as expense) or agent (revenue presented net) for the obligation's revenue stream. Own-fund management fees of sub-advised funds are presented gross with sub-advisory fees as expense (lever: net).", "Performance Obligation", "Code", "Principal vs Agent Conclusion", "Principal", "ASC 606", "AICPA Revenue Recognition Guide", "Y"),
     ]),
   ]),
   ("Fund Management Fee Revenue", "Booked management fee revenue of the firm's own mutual funds, ETFs, CITs and the money market sweep fund per share class and period, accrued from fund average net assets x fee rate.", [
     ("Fee Revenue Record", [
       ("Fee Revenue Record ID", "Unique identifier of the fee revenue record.", "Fee Revenue Record", "Identifier", "", "FRR-2026-09-004512", "Internal", "", "Y"),
       ("Revenue Share Class / Mandate", "Own-fund share class the management fee is earned on. Institutional mandate fees are booked on Client Revenue Record from the 47 Fee Invoice (CW-156); the name keeps 'Mandate' for its readers.", "Fee Revenue Record", "Reference (Share Class)", "", "SHC-004512", "Internal", "", "Y"),
       ("Revenue Accounting Period", "Fiscal period the revenue is recognized in.", "Fee Revenue Record", "Code", "External (09 Shared - Fiscal Period)", "FY2026-P09", "Internal", "", "Y"),
       ("Fee Basis Average Assets", "Average net assets of the share class used to accrue the fee for the period.", "Fee Revenue Record", "Amount", "", "USD 1,842,500,000", "Internal", "SEC Form N-1A", ""),
       ("Fee Basis Source", "Where the asset basis came from.", "Fee Revenue Record", "Code", "Fee Basis Source", "Fund Accounting NAV", "Internal", "", ""),
       ("Applied Gross Fee Rate", "Annual management fee rate applied for the period after breakpoints, as accrued by fund accounting under the 01 fund fee terms (FSCH-).", "Fee Revenue Record", "Decimal", "Basis points", "65.0", "Internal", "SEC Form N-1A", "", "Derived copy of 27 Fund Expense Accrual.Fee Rate Applied (Accrual Expense Type 'Management Fee') for the period."),
       ("Gross Fee Revenue", "Management fee earned for the period before fund-level waivers and reimbursements, as accrued by fund accounting.", "Fee Revenue Record", "Amount", "", "USD 99,800", "ASC 606", "US GAAP Taxonomy", "Y", "Derived copy of 27 Fund Expense Accrual.Accrued Expense Amount (Accrual Expense Type 'Management Fee') summed over the period for the share class; 10 does not recalculate it (CW-156)."),
       ("Waiver and Reimbursement Offset", "Fund-level waivers and reimbursements netted against revenue as consideration payable to the customer (detail on Waiver Record).", "Fee Revenue Record", "Amount", "", "USD -6,100", "ASC 606", "", ""),
       ("Net Fee Revenue", "Fee revenue after waivers and reimbursements; the amount recognized.", "Fee Revenue Record", "Amount", "", "USD 93,700", "ASC 606", "US GAAP Taxonomy", "Y"),
       ("Effective Net Fee Rate", "Net fee revenue annualized over average net assets.", "Fee Revenue Record", "Decimal", "Basis points", "6.1", "Internal", "", ""),
       ("Revenue Data Basis", "Whether the amount is actual (settled), an accrued estimate or allocated.", "Fee Revenue Record", "Code", "Revenue Data Basis", "Accrued Estimate", "Internal", "", ""),
       ("Sub-Advisory Fee Payable", "Sub-advisory fee expense for the period owed to external sub-advisers of the fund, presented as expense (the management fee stays gross, Stream Principal vs Agent Conclusion). The booked cost is the Distribution Cost Item of category 'Sub-Advisory Fees'; this amount equals it for the share class and period.", "Fee Revenue Record", "Amount", "", "USD 21,000", "Internal", "ASC 606", ""),
       ("Sub-Adviser Engagement", "52 sub-adviser engagement under which the sub-advisory fee is payable, for share classes of funds with external sub-advisers; the fee terms are in the 35 fund advisory agreement the engagement references (ADVA-).", "Fee Revenue Record", "Reference (Sub-Adviser Engagement, 52)", "", "SADV-00412", "Internal", "Investment Company Act §15(a)", ""),
     ]),
   ]),
   ("Performance Fee Revenue", "Fulcrum fee adjustments of own registered funds (Advisers Act section 205(b)(2), Rules 205-1 and 205-2) and performance fees of institutional mandates for qualified clients (Rule 205-3), recognized under the variable-consideration constraint.", [
     ("Performance Fee Record", [
       ("Performance Fee Record ID", "Unique identifier of the performance fee record.", "Performance Fee Record", "Identifier", "", "PFR-2026-12-00877", "Internal", "", ""),
       ("Performance Fee Share Class / Mandate", "Own-fund share class with a fulcrum fee, or the institutional mandate with a performance fee, that the record is for.", "Performance Fee Record", "Reference (Share Class / Mandate)", "", "SHC-008811", "Internal", "", ""),
       ("Performance Fee Terms Reference", "Record that holds the fee terms: the 01 fund fee terms (Performance Fee, FSCH-) for a fund's fulcrum fee, or the 47 Fee Schedule version (Performance Fee Terms) of the mandate. On mandate rows the amount comes from the 47 Performance Fee Calculation.", "Performance Fee Record", "Reference (Fund Fee Schedule, 01 / Fee Schedule, 47)", "", "FSCH-08811-02", "Internal", "Advisers Act Rule 205-1", "", "Row rule (CW-051, CW-156; program-lead ruling: 47 owns mandate performance fee terms): share-class rows reference the 01 fund fee terms (FSCH-); mandate rows reference the 47 Fee Schedule (CLFEE-) and take the amount from the 47 Performance Fee Calculation (BLA- / period end). 10 holds neither the terms nor the calculation."),
       ("Crystallization Date", "Date the fulcrum adjustment or the mandate performance fee is determined for the performance period and becomes payable.", "Performance Fee Record", "Date", "ISO 8601", "2026-12-31", "Advisers Act Rule 205-2", "Advisers Act Rule 205-3", "", "Fund (fulcrum) rows follow Advisers Act section 205(b)(2) and Rules 205-1 and 205-2; mandate rows follow Rule 205-3."),
       ("NAV-Accrued Performance Fee", "Fulcrum fee adjustment accrued in the fund's NAV for the period and not yet determined (fund rows only).", "Performance Fee Record", "Amount", "", "USD 340,000", "Advisers Act Rule 205-2", "", ""),
       ("Constraint Assessment Outcome", "Result of assessing whether it is probable that a significant reversal of cumulative revenue will not occur when the uncertainty is resolved.", "Performance Fee Record", "Code", "Constraint Assessment Outcome", "Fully Constrained", "ASC 606", "AICPA Revenue Recognition Guide", "Y"),
       ("Recognized Performance Fee Revenue", "Performance fee revenue recognized in the period (negative for a downward fulcrum adjustment).", "Performance Fee Record", "Amount", "", "USD 0", "ASC 606", "US GAAP Taxonomy", "Y"),
       ("Clawback Exposure Indicator", "Whether recognized fees may be clawed back.", "Performance Fee Record", "Boolean", "", "N", "AICPA Revenue Recognition Guide", "", ""),
     ]),
   ]),
   ("Distribution & Servicing Revenue", "12b-1 distribution and service fees, shareholder servicing fees and sales charges received by the firm's broker-dealer as principal underwriter of share classes sold through the intermediary channel (IC only).", [
     ("Distribution Revenue Record", [
       ("Distribution Revenue Type", "Type of distribution-related revenue.", "Distribution Revenue Record", "Code", "Distribution Revenue Type", "12b-1 Service Fee", "SEC Rule 12b-1", "US GAAP Taxonomy", "Y"),
       ("Receiving Entity", "Internal entity (the broker-dealer acting as principal underwriter) that receives the fee.", "Distribution Revenue Record", "Reference (Legal Entity)", "", "LEN-0004", "SEC Rule 12b-1", "", ""),
       ("Paying Share Class", "Share class whose assets pay the fee or whose sales generate the charge.", "Distribution Revenue Record", "Reference (Share Class)", "", "SHC-004513", "Internal", "", ""),
       ("Gross Distribution Revenue", "Amount received or receivable before pass-through to intermediaries.", "Distribution Revenue Record", "Amount", "", "USD 41,200", "ASC 606", "US GAAP Taxonomy", "Y"),
       ("Amount Passed Through", "Portion paid on to intermediary dealers of record, as calculated in the 05 Payment Calculation.", "Distribution Revenue Record", "Amount", "", "USD 38,950", "Internal", "SEC Rule 12b-1", ""),
       ("Principal vs Agent Conclusion", "Whether the distributor controls the distribution service before transfer (principal, gross) or arranges it (agent, net).", "Distribution Revenue Record", "Code", "Principal vs Agent Conclusion", "Principal", "ASC 606", "AICPA Revenue Recognition Guide", "Y"),
       ("Trailing Fee Constraint Indicator", "Whether trailing fees for past sales are constrained and recognized only as asset values become known.", "Distribution Revenue Record", "Boolean", "", "Y", "AICPA Revenue Recognition Guide", "ASC 606", ""),
       ("Sales Charge Source Transactions", "29 register transactions (purchases or redemptions) generating front-end or contingent deferred sales charges (legacy sales-charge rows only; the reference firm sells no-load funds).", "Distribution Revenue Record", "Reference (Register Transaction, 29) (multi)", "", "RGTX-2026-0004182730", "Internal", "FINRA Rule 2341", ""),
     ]),
   ]),
   ("Client Revenue", "Revenue recognized from each client account per revenue stream and month, referencing the records that calculated it (CW-156): advisory, wrap, planning, subscription, plan recordkeeping, trust and OCIO fees (47 Account Fee Calculation or Fee Invoice), account service charges (47 Fee Debit) and corrections (47 Fee Adjustment), commissions and markups (48 Client Trade Confirmation, posted in 49 Client Account Activity), margin interest (49 Client Account Activity), the firm share of fully paid lending revenue (49 Fully Paid Securities Loan) and bank sweep fees allocated from Cash Program Economics (50 Sweep Allocation). Fund management, fulcrum and 12b-1 fees are not client revenue streams.", [
     ("Client Revenue Record", [
       ("Client Revenue Record ID", "Unique identifier of the client revenue record.", "Client Revenue Record", "Identifier", "", "CLREV-2026-09-0041877", "Internal", "ASC 606", "Y", "Object PII tier: PII - financial (revenue earned from an identified client account or Client Household)."),
       ("Revenue Account / Household", "Client account the revenue is earned on; on household-grain rows (a fee calculated for a 47 Fee Household), the Fee Household; on plan-paid rows, the 16 plan service arrangement.", "Client Revenue Record", "Reference (Account / Fee Household, 47 / Service Arrangement, 16)", "", "ACC-0049812", "Internal", "", "Y", "PII - financial (linked to an identified client). The 02 Client Household is reached through the account or the Fee Household's Anchor Client Household, never stored here (checklist section 7)."),
       ("Client Revenue Stream", "Revenue stream of the row.", "Client Revenue Record", "Code", "Revenue Stream", "Advisory Fee", "Internal", "FOCUS Report (Form X-17A-5) Part II", "Y"),
       ("Revenue Service Offering", "01 service offering the revenue is earned under (advice program, brokerage, planning, trust, workplace managed account, OCIO).", "Client Revenue Record", "Reference (Service Offering)", "", "OFFR-0012", "Internal", "Form ADV Part 2A Item 5", "Y"),
       ("Client Revenue Period", "Fiscal period the revenue is recognized in.", "Client Revenue Record", "Code", "External (09 Shared - Fiscal Period)", "FY2026-P09", "ASC 606", "", "Y"),
       ("Source Calculation Record", "Records that calculated the month's amount for the account and stream: 47 Account Fee Calculation, Fee Invoice (including plan recordkeeping and trust fees), Fee Debit (account service charges) or Fee Adjustment (corrections); 48 Client Trade Confirmation (commissions and markups); 49 Client Account Activity (margin interest, commission postings) or Fully Paid Securities Loan; 50 Sweep Allocation (bank sweep fee allocation).", "Client Revenue Record", "Reference (Account Fee Calculation, 47 / Fee Invoice, 47 / Fee Debit, 47 / Fee Adjustment, 47 / Client Trade Confirmation, 48 / Client Account Activity, 49 / Fully Paid Securities Loan, 49 / Sweep Allocation, 50) (multi)", "", "FCRUN-2026M09-004 / FEASG-000418822", "Internal", "ASC 606", "Y", "Every row carries its source records (CW-156); the row amount is their sum for the month, and 10 never recalculates it."),
       ("Recognized Revenue Amount", "Revenue recognized for the account, stream and month: the sum of the source records' amounts for the month; a later correction arrives as a 47 Fee Adjustment and is booked in the month it is recorded.", "Client Revenue Record", "Amount", "", "USD 2,657.28", "ASC 606", "US GAAP Taxonomy", "Y", "PII - financial."),
       ("Recognizing Legal Entity", "Internal legal entity that recognizes the revenue (the RIA for advisory fees, the broker-dealer for commissions, margin interest and sweep fees, the recordkeeper, the trust company).", "Client Revenue Record", "Reference (Legal Entity)", "", "LEN-0003", "ASC 606", "", "Y"),
       ("Revenue Channel", "Distribution channel of the account as of the period end.", "Client Revenue Record", "Code", "External (Enterprise - Distribution Channel)", "DIRECT_DIGITAL_ADVICE", "Internal", "", "", "Derived copy of the 06 Account Channel Assignment (CHASG-) effective at the period end."),
       ("Revenue Business Line", "Business line of the account as of the period end (CW-004).", "Client Revenue Record", "Code", "Business Line", "DA", "Internal", "", "", "Derived copy of 06 Account Channel Assignment.Assigned Business Line effective at the period end."),
       ("Client Segment at Period End", "Segment of the account's Client Household in the firm's primary segmentation scheme (the 02 Segmentation Scheme the firm designates for economics, for example Life Stage) as of the period end.", "Client Revenue Record", "Code", "External (02 - Segment Assignment)", "Pre-Retiree", "Internal", "", "", "Derived copy of 02 Segment Assignment.Segment effective at the period end."),
     ]),
   ]),
   ("Cash Program Economics", "Economics of the cash sweep programs per program bank and period: fees earned from program banks on swept deposits, the rate paid to clients and the net spread; the money market sweep fund's revenue is its Fee Revenue Record.", [
     ("Cash Program Economics", [
       ("Economics Sweep Program", "50 sweep program the row is for.", "Cash Program Economics", "Reference (Sweep Program, 50)", "", "SWEEP-0004", "Internal", "SEC Rule 15c3-3", "Y", "Object PII tier: No PII (program aggregates)."),
       ("Economics Program Bank", "50 program bank the row is for; blank on money market sweep fund rows.", "Cash Program Economics", "Reference (Program Bank, 50)", "", "PGBNK-0012", "Internal", "", "Y"),
       ("Economics Period", "Fiscal period of the row.", "Cash Program Economics", "Code", "External (09 Shared - Fiscal Period)", "FY2026-P09", "Internal", "", "Y"),
       ("Average Swept Balance", "Average client deposits swept to the program bank over the period.", "Cash Program Economics", "Amount", "", "USD 3,600,000,000", "Internal", "", "", "Derived copy of 50 Program Bank Daily Total.Aggregate Customer Deposits averaged over the period's business dates."),
       ("Program Bank Fee Earned", "Fee earned by the broker-dealer from the program bank for the period, computed here: interest the bank pays on the swept deposits less the interest credited to clients, under the rate terms of the program bank agreement.", "Cash Program Economics", "Amount", "", "USD 11,250,000", "ASC 606", "Sweep program disclosure", "Y", "Computed in 10 (CW-156 exception: no 50 record holds the fee). Inputs: 50 Program Bank Daily Total.Interest Paid by Bank and Aggregate Customer Deposits for the period; 50 Sweep Allocation.Interest Accrued Amount summed for the bank; the rate terms of the 39 Contract named in 50 Program Bank Participation.Program Bank Agreement (with its Bank Rate Formula)."),
       ("Average Client Rate Paid", "Balance-weighted average interest rate credited to clients on swept cash over the period.", "Cash Program Economics", "Percentage", "", "0.45%", "Internal", "", "", "Derived copy of 50 Sweep Rate Tier.Client Interest Rate weighted by the period's swept balances."),
       ("Net Spread", "Program Bank Fee Earned annualized over Average Swept Balance.", "Cash Program Economics", "Decimal", "Basis points", "375", "Internal", "", "Y"),
       ("Money Market Sweep Fund Revenue", "Fee revenue record of the money market sweep fund for the period, on money market sweep program rows (the reference firm's default sweep vehicle; bank deposit sweep rows are the lever).", "Cash Program Economics", "Reference (Fee Revenue Record)", "", "FRR-2026-09-000118", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Fund Expense Support", "DF-FWS",
  "Financial impact of fund-level fee waivers, expense caps, reimbursements and recoupment, and fund costs borne by the adviser. The waiver and cap TERMS are 01 fund fee terms; client fee waivers and credits are 47 Fee Waiver (FWV-, CW-055).",
  [
   ("Waiver & Reimbursement Impact", "Period amounts waived or reimbursed at fund level under the 01 expense cap terms.", [
     ("Waiver Record", [
       ("Waiver Record ID", "Unique identifier of the fund waiver or reimbursement record.", "Waiver Record", "Identifier", "", "WVR-2026-09-004512", "Internal", "", ""),
       ("Waiver Type", "Type of fund fee support.", "Waiver Record", "Code", "Waiver Type", "Contractual Fee Waiver", "SEC Form N-1A", "", "Y"),
       ("Supported Share Class", "Own-fund share class receiving the support.", "Waiver Record", "Reference (Share Class)", "", "SHC-004512", "Internal", "", ""),
       ("Expense Cap Terms Reference", "Share-class expense cap and waiver terms in the 01 fund fee terms (Expense Cap Rate, Waiver Expiry Date).", "Waiver Record", "Reference (Fund Fee Schedule, 01)", "", "FSCH-04512-02", "Internal", "SEC Form N-1A", ""),
       ("Waived Fee Amount", "Management or 12b-1 fee waived in the period.", "Waiver Record", "Amount", "", "USD 4,820", "Internal", "ASC 606", "Y", "Derived copy of 27 Expense Cap & Waiver Accrual.Waived Fee Amount summed over the period for the share class and waiver type (CD-188)."),
       ("Reimbursed Expense Amount", "Fund expenses reimbursed by the adviser in the period.", "Waiver Record", "Amount", "", "USD 1,320", "Internal", "ASC 606", "", "Derived copy of 27 Expense Cap & Waiver Accrual.Reimbursed Expense Amount summed over the period for the share class and waiver type (CD-188)."),
       ("Waiver Accounting Treatment", "How the support is presented: reduction of revenue (consideration payable to a customer) or expense.", "Waiver Record", "Code", "Waiver Accounting Treatment", "Reduction of Revenue", "ASC 606", "AICPA Revenue Recognition Guide", "Y"),
       ("Recoupment Eligible Indicator", "Whether the adviser may recoup the amount from the fund in later periods while staying under the cap.", "Waiver Record", "Boolean", "", "Y", "SEC Form N-1A", "", ""),
       ("Recoupment Expiry Date", "Last date the amount can be recouped (typically three years).", "Waiver Record", "Date", "ISO 8601", "2029-09-30", "SEC Form N-1A", "", ""),
     ]),
   ]),
   ("Adviser-Borne Fund Costs", "Fund-level costs the adviser or the principal underwriter pays from its own resources.", [
     ("Adviser-Borne Cost", [
       ("Adviser-Borne Cost Type", "Type of fund cost borne by the firm.", "Adviser-Borne Cost", "Code", "Adviser-Borne Cost Type", "Fund Expense Above Cap", "SEC IM Guidance 2016-01", "", ""),
       ("Related Payment Arrangement", "05 payment arrangement whose excess the firm bears (intermediary sub-accounting and revenue sharing only).", "Adviser-Borne Cost", "Reference (Payment Arrangement)", "", "PYA-00871", "Internal", "", ""),
       ("Adviser-Borne Amount", "Amount borne for the period.", "Adviser-Borne Cost", "Amount", "", "USD 74,000", "Internal", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Cost Accounting & Contract Costs", "DF-EXP",
  "Accounting records for costs calculated elsewhere (advisor compensation statements in 03, partner payments in 05, marketing spend in 04, data costs in 14, supplier invoices in 40 and 19), with accruals, true-ups and cost-center assignment, and the assets recognized for costs to obtain or fulfill contracts with customers under ASC 340-40.",
  [
   ("Distribution Cost Item", "One accounting cost line, linked to the source record that calculated it. The name is kept for its readers (CW-159); it covers every client and channel cost, not only distribution.", [
     ("Distribution Cost Item", [
       ("Distribution Cost Item ID", "Unique identifier of the cost item.", "Distribution Cost Item", "Identifier", "", "DCO-2026-09-018822", "Internal", "", "Y"),
       ("Distribution Expense Category", "Category of the cost item.", "Distribution Cost Item", "Code", "Cost Item Category", "Advisor Incentive Compensation", "Internal", "US GAAP Taxonomy", "Y"),
       ("Source Domain", "Data Domain that calculated the amount.", "Distribution Cost Item", "Code", "Source Domain", "03 Advisor Organization, Coverage & Supervision", "Internal", "", ""),
       ("Source Record", "IDs of the calculating records: the 03 Compensation Statements of the cost center for the period (never a single advisor's), the 05 Payment Calculation or Partner Payment, the 04 campaign spend, the 14 data license cost, or the 40 or 19 supplier invoice.", "Distribution Cost Item", "Reference (Payment Calculation, 05 / Partner Payment, 05 / Compensation Statement, 03 / Campaign, 04 / Data License Agreement, 14 / Payable Invoice, 19) (multi)", "", "PCL-2026Q3-00871", "Internal", "", "Y", "Advisor compensation is booked per cost center and statement period with all the statements of that cost center as source records; no cost item carries one person's pay amount."),
       ("Cost Counterparty", "External party paid or payable, where the cost is owed outside the firm.", "Distribution Cost Item", "Reference (Party)", "", "PTY-003301", "Internal", "", ""),
       ("Bearing Legal Entity", "Internal entity whose books bear the cost.", "Distribution Cost Item", "Reference (Legal Entity)", "", "LEN-0003", "Internal", "", "Y"),
       ("Funding Source", "Fund-paid under 12b-1, fund-paid for servicing, or the firm's own resources (05 list); on non-intermediary rows always the firm's own resources.", "Distribution Cost Item", "Code", "External (05 DI - Funding Source)", "Adviser - Own Resources", "SEC Rule 12b-1", "SEC IM Guidance 2016-01", "Y"),
       ("Cost Center", "Cost center charged, as a 19 chart segment value (the org unit is reached through its Represented Org Unit).", "Distribution Cost Item", "Reference (Chart Segment Value)", "", "41020", "Internal", "", "Y"),
       ("Profit Center", "Profit center the cost belongs to, where different from the cost center's default.", "Distribution Cost Item", "Reference (Org Unit)", "", "OU-PC-US-HA", "Internal", "", ""),
       ("Direct Product / Share Class", "Product or share class directly attributable, if any.", "Distribution Cost Item", "Reference (Product / Share Class)", "", "SHC-004512", "Internal", "", ""),
       ("Direct Channel", "Distribution channel directly attributable, if any.", "Distribution Cost Item", "Code", "External (Enterprise - Distribution Channel)", "DIRECT_HUMAN_ADVICE", "Internal", "", ""),
       ("Service Period Start", "First day of the period the cost relates to.", "Distribution Cost Item", "Date", "ISO 8601", "2026-07-01", "Internal", "", ""),
       ("Service Period End", "Last day of the period the cost relates to.", "Distribution Cost Item", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
       ("Expense Amount", "Expense amount in transaction currency.", "Distribution Cost Item", "Amount", "", "USD 1,745,000", "Internal", "", "Y"),
       ("Directly Attributable Indicator", "Whether the cost is assigned directly to profitability dimensions or goes to a cost pool for allocation.", "Distribution Cost Item", "Boolean", "", "N", "Internal", "TDABC", ""),
       ("Capitalization Outcome", "Whether the cost is expensed or capitalized as a contract cost asset.", "Distribution Cost Item", "Code", "Capitalization Outcome", "Expense as Incurred", "ASC 340-40", "AICPA Revenue Recognition Guide", ""),
     ]),
   ]),
   ("Accruals & True-Ups", "Period-end accruals of cost and their later true-up to invoiced, settled or final calculated amounts.", [
     ("Accrual", [
       ("Accrual ID", "Unique identifier of the accrual.", "Accrual", "Identifier", "", "ACR-2026-09-00441", "Internal", "", ""),
       ("Accrued Cost Item", "Cost item being accrued.", "Accrual", "Reference (Distribution Cost Item)", "", "DCO-2026-09-018822", "Internal", "", ""),
       ("Accrual Basis", "How the accrued amount was derived.", "Accrual", "Code", "Accrual Basis", "Engine Calculation", "Internal", "", ""),
       ("Accrual Period", "Fiscal period of the accrual.", "Accrual", "Code", "External (09 Shared - Fiscal Period)", "FY2026-P09", "Internal", "", ""),
       ("Accrued Amount", "Amount accrued.", "Accrual", "Amount", "", "USD 1,740,000", "Internal", "", "Y"),
       ("True-Up Amount", "Difference between the accrued and the final (invoiced, settled or recalculated) amount, booked in the true-up period.", "Accrual", "Amount", "", "USD 12,600", "Internal", "", "Y"),
       ("True-Up Reason", "Reason for the true-up.", "Accrual", "Code", "True-Up Reason", "Invoice Variance", "Internal", "", ""),
     ]),
   ]),
   ("Contract Cost Asset", "A capitalized cost to obtain or fulfill a contract with a customer (ASC 340-40), with its amortization and impairment.", [
     ("Contract Cost Asset", [
       ("Contract Cost Asset ID", "Unique identifier of the contract cost asset.", "Contract Cost Asset", "Identifier", "", "CCA-000118", "Internal", "", ""),
       ("Cost Asset Type", "Type of capitalized cost.", "Contract Cost Asset", "Code", "Cost Asset Type", "Incremental Cost to Obtain", "ASC 340-40", "", "Y"),
       ("Related Revenue Contract", "Revenue contract the cost relates to.", "Contract Cost Asset", "Reference (Revenue Contract)", "", "RVC-000231", "ASC 340-40", "", ""),
       ("Related Share Class", "Share class whose sales generated a legacy deferred sales commission (intermediary level-load or back-end-load classes only); blank for advisory contract costs.", "Contract Cost Asset", "Reference (Share Class)", "", "", "Internal", "", ""),
       ("Originating Cost Items", "Cost items capitalized into the asset.", "Contract Cost Asset", "Reference (Distribution Cost Item) (multi)", "", "DCO-2026-09-019001", "Internal", "", ""),
       ("Capitalized Amount", "Amount initially capitalized.", "Contract Cost Asset", "Amount", "", "USD 230,000", "ASC 340-40", "", "Y"),
       ("Amortization Method", "Systematic basis of amortization consistent with the transfer of the related services.", "Contract Cost Asset", "Code", "Amortization Method", "Straight-Line", "ASC 340-40", "", ""),
       ("Amortization Period", "Months over which the asset is amortized (for advisory contract costs, the expected client relationship life including anticipated renewals).", "Contract Cost Asset", "Integer", "Months", "84", "ASC 340-40", "", ""),
       ("CDSC Recovery Offset", "Contingent deferred sales charges received on early redemption that reduce the unamortized legacy deferred sales commission asset.", "Contract Cost Asset", "Amount", "", "USD 0", "AICPA Revenue Recognition Guide", "", ""),
       ("Net Carrying Amount", "Capitalized amount less amortization, recoveries and impairment.", "Contract Cost Asset", "Amount", "", "USD 197,140", "ASC 340-40", "", "Y"),
       ("Impairment Loss Amount", "Impairment recognized when the carrying amount exceeds the remaining consideration less the costs still to be incurred.", "Contract Cost Asset", "Amount", "", "USD 0", "ASC 340-40", "", ""),
     ]),
   ]),
   ("Capitalization Assessment", "Policy assessment of whether an incentive or fee is an incremental cost of obtaining a contract with the customer.", [
     ("Capitalization Assessment", [
       ("Assessed Cost Source", "03 incentive plan component (advisor new-client and referral incentives, ICP-n-Cnn) or 05 payment arrangement being assessed.", "Capitalization Assessment", "Reference (Incentive Plan Component, 03 / Payment Arrangement, 05)", "", "ICP-US-HA-2027-C02", "Internal", "", ""),
       ("Incremental Indicator", "Whether the cost would not have been incurred had the contract not been obtained.", "Capitalization Assessment", "Boolean", "", "Y", "ASC 340-40", "", ""),
       ("Customer Contract Linkage", "How the cost links to a contract with the identified customer. An incentive paid for a new advisory client agreement obtains a contract; a commission on fund share sales does not obtain a new contract with the fund.", "Capitalization Assessment", "Code", "Customer Contract Linkage", "Directly Obtains New Customer Contract", "AICPA Revenue Recognition Guide", "ASC 340-40", ""),
       ("Practical Expedient Applied Indicator", "Whether the one-year practical expedient (expense if the amortization period is one year or less) is applied.", "Capitalization Assessment", "Boolean", "", "N", "ASC 340-40", "", ""),
       ("Assessment Conclusion", "Conclusion of the assessment.", "Capitalization Assessment", "Code", "Capitalization Outcome", "Capitalize - Cost to Obtain", "ASC 340-40", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Ledger Mapping & Controls", "DF-COA",
  "Mapping of revenue and expense from management P&L lines to 19 GL accounts and ledgers, and the reconciliations that evidence that 10 agrees with its source domains and the ledger. The chart of accounts, GL postings, accounting period status and certified revenue are mastered in 19 (CD-152, CW-011).",
  [
   ("Account Mapping", "Effective-dated mapping from management P&L line to 19 GL account (narrowed under CD-152).", [
     ("Account Mapping", [
       ("Account Mapping ID", "Unique identifier of the mapping.", "Account Mapping", "Identifier", "", "ACM-0142", "Internal", "", ""),
       ("Management P&L Line", "Line on the management P&L.", "Account Mapping", "Code", "Management P&L Line", "Advisory Fee Revenue", "Internal", "FOCUS Report (Form X-17A-5) Part II", "Y"),
       ("GL Natural Account", "19 GL account (natural account) the management P&L line maps to.", "Account Mapping", "Reference (GL Account)", "", "GLA-GRPCOA-410200", "Internal", "", "Y"),
       ("Applicable Ledger", "19 ledger the mapping applies to.", "Account Mapping", "Reference (Ledger)", "", "LDG-4100-USGAAP-USD", "Internal", "", ""),
       ("Mapping Effective From", "Date the mapping applies from.", "Account Mapping", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Mapping Effective To", "Date the mapping ends.", "Account Mapping", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Controls & Reconciliation", "Reconciliations evidencing that 10 records agree with the calculating domains and the ledger.", [
     ("Control", [
       ("Reconciliation Type", "Reconciliation performed.", "Control", "Code", "Reconciliation Type", "Fee Calculations vs Client Revenue (47)", "Internal", "SOX", ""),
       ("Control Period", "Fiscal period the reconciliation covers.", "Control", "Code", "External (09 Shared - Fiscal Period)", "FY2026-P09", "Internal", "SOX", ""),
       ("Reconciliation Status", "Result of the reconciliation.", "Control", "Code", "Reconciliation Status", "Reconciled within Tolerance", "Internal", "SOX", ""),
       ("Control Reference", "Key control the reconciliation evidences.", "Control", "Text", "", "DF-KC-07", "SOX", "COSO 2013", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Cost Allocation", "DF-ALC",
  "Cost pools, allocation methods, drivers and rules, and the runs that spread indirect cost to accounts, Client Households, segments, offerings, channels and business lines.",
  [
   ("Cost Pools", "Groupings of indirect cost to be allocated.", [
     ("Cost Pool", [
       ("Cost Pool ID", "Unique identifier of the cost pool.", "Cost Pool", "Identifier", "", "CPO-CLIENTSVC", "Internal", "", ""),
       ("Cost Pool Type", "Functional type of cost in the pool.", "Cost Pool", "Code", "Cost Pool Type", "Client Service", "Internal", "TDABC", ""),
       ("Cost-to-Serve Component", "Cost-to-serve component the pool's allocated cost is reported under (CW-157).", "Cost Pool", "Code", "Cost-to-Serve Component", "Service", "Internal", "TDABC", ""),
       ("Contributing Cost Centers", "Cost centers (19 chart segment values) whose cost flows into the pool.", "Cost Pool", "Reference (Chart Segment Value) (multi)", "", "44100; 44200", "Internal", "", ""),
       ("Included Expense Categories", "Cost item categories included in the pool.", "Cost Pool", "Code (multi)", "Cost Item Category", "Service Staff Compensation; Contact Center Technology", "Internal", "", ""),
     ]),
   ]),
   ("Allocation Methods & Drivers", "How cost is spread and the measured quantities that drive it.", [
     ("Allocation Method", [
       ("Allocation Method ID", "Unique identifier of the allocation method.", "Allocation Method", "Identifier", "", "ALM-007", "Internal", "", ""),
       ("Allocation Method Name", "Business name of the method.", "Allocation Method", "Text", "", "Contact center time by Client Household (TDABC)", "Internal", "", ""),
       ("Allocation Method Type", "Type of method.", "Allocation Method", "Code", "Allocation Method Type", "Time-Driven Activity-Based", "TDABC", "Internal", "Y"),
       ("Method Description", "How the method works, including the treatment of unused capacity.", "Allocation Method", "Text", "", "Capacity cost rate x minutes per service contact type; unused capacity held at pool level", "TDABC", "", ""),
     ]),
     ("Allocation Driver", [
       ("Allocation Driver ID", "Unique identifier of the driver.", "Allocation Driver", "Identifier", "", "DRV-SVCCONTACT", "Internal", "", ""),
       ("Driver Type", "Quantity used to allocate.", "Allocation Driver", "Code", "Allocation Driver Type", "Service Contact Count", "Internal", "TDABC", "Y"),
       ("Driver Source Measure", "06 certified measure (average client assets, net new assets) or other source of the driver quantity (13 contacts, 48 trades, 50 money movements, 15 accounts).", "Allocation Driver", "Code", "External (06 TX - Flow & AUM Measure)", "MSR-AVGCLIENTASSETS", "Internal", "", ""),
       ("Capacity Cost Rate", "Cost per unit of practical capacity (for example per minute of contact center time).", "Allocation Driver", "Decimal", "", "USD 1.90 per minute", "TDABC", "", ""),
       ("Unit Time Estimate", "Minutes consumed per activity unit (TDABC time equation term).", "Allocation Driver", "Decimal", "", "9", "TDABC", "", ""),
     ]),
   ]),
   ("Allocation Rules", "Rules that apply a method and driver to a pool and target.", [
     ("Allocation Rule", [
       ("Allocation Rule ID", "Unique identifier of the rule.", "Allocation Rule", "Identifier", "", "ARU-0031", "Internal", "", ""),
       ("Source Cost Pool", "Pool the rule allocates from.", "Allocation Rule", "Reference (Cost Pool)", "", "CPO-CLIENTSVC", "Internal", "", "Y"),
       ("Applied Allocation Method", "Method applied by the rule.", "Allocation Rule", "Reference (Allocation Method)", "", "ALM-007", "Internal", "", ""),
       ("Applied Driver", "Driver applied by the rule.", "Allocation Rule", "Reference (Allocation Driver)", "", "DRV-SVCCONTACT", "Internal", "", ""),
       ("Target Dimension", "Profitability dimension the cost is allocated to.", "Allocation Rule", "Code", "Profitability Dimension", "Household", "Internal", "", "Y"),
       ("Allocation Sequence", "Order of the rule in a step-down allocation.", "Allocation Rule", "Integer", "", "3", "Internal", "", ""),
       ("Rule Effective From", "Date the rule applies from.", "Allocation Rule", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Rule Effective To", "Date the rule ends.", "Allocation Rule", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Allocation Runs & Results", "Executions of the allocation rule set and the amounts produced.", [
     ("Allocation Run", [
       ("Allocation Run ID", "Unique identifier of the run.", "Allocation Run", "Identifier", "", "ARN-2026-09-A01", "Internal", "SOX", "Y"),
       ("Run Period", "Fiscal period allocated.", "Allocation Run", "Code", "External (09 Shared - Fiscal Period)", "FY2026-P09", "Internal", "", ""),
       ("Run Data Version", "Version of data allocated (actual, budget, forecast).", "Allocation Run", "Code", "Data Version", "Actual", "Internal", "", ""),
       ("Run Status", "Status of the run.", "Allocation Run", "Code", "Run Status", "Final", "Internal", "", ""),
       ("Unallocated Residual", "Pool cost left unallocated (for example unused capacity).", "Allocation Run", "Amount", "", "USD 312,000", "TDABC", "", ""),
     ]),
     ("Allocation Result", [
       ("Allocated Rule", "Rule that produced the result.", "Allocation Result", "Reference (Allocation Rule)", "", "ARU-0031", "Internal", "", ""),
       ("Target Dimension Member", "Member receiving the allocation (Client Household, account, segment, offering, channel, share class).", "Allocation Result", "Reference (Dimension Member)", "", "OFFR-0012", "Internal", "", "", "PII - financial on Client Household and account rows (restricted)."),
       ("Driver Share", "Member's share of the driver quantity.", "Allocation Result", "Percentage", "", "6.4%", "Internal", "", ""),
       ("Allocated Amount", "Cost allocated to the member.", "Allocation Result", "Amount", "", "USD 228,500", "Internal", "", "Y", "PII - financial on Client Household and account rows (restricted)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Profitability & Cost to Serve", "DF-PNL",
  "Profitability records at a declared dimension grain and version, the certified profitability measures, and cost-to-serve profiles for Client Households, segments, service tiers, offerings and channels (CW-157).",
  [
   ("Profitability Record", "One row of the management P&L at a declared grain, period and version.", [
     ("Profitability Record", [
       ("Profitability Record ID", "Unique identifier of the profitability record.", "Profitability Record", "Identifier", "", "PNL-2026-09-ACT-000918", "Internal", "", "Y", "Object PII tier: No PII on aggregate rows; PII - financial on Client Household and account rows (restricted; products show segment aggregates, CW-157)."),
       ("Profitability Period", "Fiscal period of the record.", "Profitability Record", "Code", "External (09 Shared - Fiscal Period)", "FY2026-P09", "Internal", "", "Y"),
       ("Data Version", "Actual, budget, forecast or scenario.", "Profitability Record", "Code", "Data Version", "Actual", "Internal", "", "Y"),
       ("Dimension Grain", "Set of dimensions the record is held at.", "Profitability Record", "Code (multi)", "Profitability Dimension", "Channel; Service Offering; Client Segment", "Internal", "", "Y", "The dimension attributes named in the grain are part of the record key and inherit this CDE flag."),
       ("Channel", "Distribution channel.", "Profitability Record", "Code", "External (Enterprise - Distribution Channel)", "DIRECT_DIGITAL_ADVICE", "Internal", "", ""),
       ("Business Line", "Business line (CW-004).", "Profitability Record", "Code", "Business Line", "DA", "Internal", "ASC 280", ""),
       ("Service Offering", "01 service offering.", "Profitability Record", "Reference (Service Offering)", "", "OFFR-0012", "Internal", "", ""),
       ("Service Tier", "01 relationship service tier of the Client Households in the grain.", "Profitability Record", "Reference (Service Tier, 01)", "", "PREMIER", "Internal", "", ""),
       ("Partner Firm", "Intermediary distributor firm (05 Distributor Firm), on intermediary channel rows only.", "Profitability Record", "Reference (Distributor Firm, 05)", "", "PTY-100001", "Internal", "", ""),
       ("Product / Share Class", "Product or share class (01).", "Profitability Record", "Reference (Product / Share Class)", "", "SHC-004512", "Internal", "", ""),
       ("Advisor", "Firm advisor (03 Advisor, keyed by the 20 employee) the grain is attributed to.", "Profitability Record", "Reference (Advisor, 03)", "", "EMP-20417", "Internal", "", "", "Advisor rows are PII - financial (employee compensation, restricted, CD-344) regardless of grain: products show advisor results only without cost lines, or above a minimum team size."),
       ("Client / Account", "Client Household, client or institutional client (02 PTY-HH-, PTY-) or account (15 ACC-) of household-, client- or account-grain rows.", "Profitability Record", "Reference (Party / Account)", "", "PTY-HH-55012", "Internal", "", "", "PII - financial; restricted (CW-157)."),
       ("Client Segment", "Segment in the firm's primary segmentation scheme (02 Segmentation Scheme designated for economics) as of the period end.", "Profitability Record", "Code", "External (02 - Segment Assignment)", "Pre-Retiree", "Internal", "", ""),
       ("Reporting Legal Entity", "Internal legal entity the record belongs to.", "Profitability Record", "Reference (Legal Entity)", "", "LEN-0003", "Internal", "", ""),
       ("Hierarchy Version", "Management hierarchy version used to roll the record up.", "Profitability Record", "Reference (Management Hierarchy)", "", "MHY-OFFERING-2026v2", "Internal", "", "Y"),
       ("Source Allocation Run", "Allocation run whose results are included.", "Profitability Record", "Reference (Allocation Run)", "", "ARN-2026-09-A01", "Internal", "", "Y"),
       ("Average AUM Reference", "Average client assets of the grain (06 Average Client Assets, mean of daily values over the period), or average fund net assets on product and share class rows (27), used for basis-point measures.", "Profitability Record", "Amount", "", "USD 640,000,000", "Internal", "", ""),
       ("Reporting Currency", "Currency of the amounts.", "Profitability Record", "Code", "ISO 4217", "USD", "ISO 4217", "", ""),
     ]),
   ]),
   ("Profitability Measures", "Certified measures held on each profitability record.", [
     ("Profitability Measure", [
       ("Gross Revenue", "Client revenue, own-fund fee revenue after fund waivers and distribution revenue attributed to the grain.", "Profitability Record", "Amount", "", "USD 1,050,000", "Internal", "ASC 606", "Y"),
       ("Distribution Payments", "Partner payments charged to the grain (intermediary channel rows): revenue sharing, sub-accounting, 12b-1 pass-through and platform fees. Authoritative partner payment amount of the record.", "Profitability Record", "Amount", "", "USD 0", "Internal", "", ""),
       ("Net Revenue After Distribution Costs", "Gross revenue less distribution payments.", "Profitability Record", "Amount", "", "USD 1,050,000", "Internal", "", "Y"),
       ("Net Revenue Yield", "Net revenue after distribution costs, annualized over average client assets.", "Profitability Record", "Decimal", "Basis points", "19.7", "Internal", "McKinsey Performance Lens", "Y"),
       ("Direct Sales & Marketing Cost", "Directly attributable acquisition marketing and service cost and, for advisor coverage, the advisor compensation of the cost center allocated to the grain. On advisor-grain rows it is always an allocated Cost Pool amount (10 Allocation Result), never a 03 Compensation Statement amount.", "Profitability Record", "Amount", "", "USD 180,000", "Internal", "", "", "Restricted on advisor rows (CD-344)."),
       ("Contribution Margin", "Net revenue after distribution costs less direct sales and marketing cost.", "Profitability Record", "Amount", "", "USD 870,000", "Internal", "", "Y"),
       ("Allocated Indirect Cost", "Indirect cost allocated from cost pools.", "Profitability Record", "Amount", "", "USD 428,500", "Internal", "TDABC", ""),
       ("Operating Profit", "Contribution margin less allocated indirect cost (fully loaded).", "Profitability Record", "Amount", "", "USD 441,500", "Internal", "", "Y"),
       ("Operating Margin", "Operating profit divided by gross revenue.", "Profitability Record", "Percentage", "", "42.0%", "Internal", "McKinsey Performance Lens", ""),
     ]),
     ("Profitability Measure Definition", [
       ("Profitability Measure Code", "Identifier of the measure in the catalog.", "Profitability Measure", "Code", "Profitability Measure", "Net Revenue Yield", "Internal", "", ""),
       ("Measure Formula", "Formula in terms of P&L lines and client assets.", "Profitability Measure", "Text", "", "(Gross Revenue - Distribution Payments) / Average AUM Reference x 10,000 x (365 / days)", "Internal", "", ""),
     ]),
   ]),
   ("Cost-to-Serve", "Total cost of serving a Client Household, client segment, service tier, offering or channel, relative to the assets and revenue it produces, by cost-to-serve component (CW-157).", [
     ("Cost-to-Serve Profile", [
       ("Served Party", "Client Household or client (02 party) the profile describes, on household and client rows; blank on segment, tier, offering and channel rows, whose subject is the parent Profitability Record's grain.", "Cost-to-Serve Profile", "Reference (Party)", "", "PTY-HH-55012", "Internal", "", "", "Object PII tier: No PII on segment, tier, offering and channel rows; PII - financial on Client Household and client rows (restricted; products show segment aggregates, CW-157)."),
       ("Coverage and Servicing Cost", "Allocated advisor coverage and planning cost (Advice component): the human advice cost that separates HA economics from DA and DB.", "Cost-to-Serve Profile", "Amount", "", "USD 420,000", "Internal", "TDABC", "", "PII - financial on Client Household rows."),
       ("Client Service Cost", "Allocated contact center and service operations cost (Service component).", "Cost-to-Serve Profile", "Amount", "", "USD 220,000", "Internal", "TDABC", "", "PII - financial on Client Household rows."),
       ("Platform & Technology Cost", "Allocated cost of the digital platform, advice engine and account technology (Platform component).", "Cost-to-Serve Profile", "Amount", "", "USD 410,000", "Internal", "TDABC", "", "PII - financial on Client Household rows."),
       ("Clearing & Client Asset Custody Cost", "Allocated self-clearing, client asset custody and transfer agency cost (Clearing and Client Asset Custody component).", "Cost-to-Serve Profile", "Amount", "", "USD 205,000", "Internal", "TDABC", "", "PII - financial on Client Household rows."),
       ("Money Movement Cost", "Allocated cost of ACH, wire, check and sweep processing (Money Movement component).", "Cost-to-Serve Profile", "Amount", "", "USD 61,000", "Internal", "TDABC", "", "PII - financial on Client Household rows."),
       ("Communications & Regulatory Cost", "Allocated cost of statements, confirmations, tax forms, regulatory mailings, supervision and regulatory fees (Communications and Regulatory components).", "Cost-to-Serve Profile", "Amount", "", "USD 118,000", "Internal", "TDABC", "", "PII - financial on Client Household rows."),
       ("Total Cost-to-Serve", "Sum of all costs to serve the subject for the period.", "Cost-to-Serve Profile", "Amount", "", "USD 1,434,000", "Internal", "", "Y", "PII - financial on Client Household rows."),
       ("Cost-to-Serve Rate", "Total cost-to-serve annualized over average client assets.", "Cost-to-Serve Profile", "Decimal", "Basis points", "9.2", "Internal", "", "Y", "PII - financial on Client Household rows."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Client Economics & Pricing", "DF-CLE",
  "Client acquisition cost by channel and cohort, lifetime value models and household estimates, and the economics of a proposed price change (CW-157, CW-158). Spend and milestones are 04, client assets 06, the fee schedule 47, fund fee terms 01, the change initiative 36 and competitor prices 11.",
  [
   ("Client Acquisition Cost", "Allocated cost of acquiring new Client Households by acquisition channel, campaign and cohort month.", [
     ("Client Acquisition Cost Record", [
       ("Acquisition Channel", "Acquisition channel of the cohort.", "Acquisition Cost", "Code", "Acquisition Channel", "Paid Digital Media", "Internal", "", "Y", "Object PII tier: No PII (cohort aggregates)."),
       ("Acquisition Campaign", "04 campaign the cost is attributed to; 'ALL' on channel-level rows.", "Acquisition Cost", "Reference (Campaign)", "", "CAM-004512", "Internal", "", ""),
       ("Cohort Month", "Month in which the cohort's households were acquired (first account funded).", "Acquisition Cost", "Date", "ISO 8601 (YYYY-MM)", "2026-09", "Internal", "", ""),
       ("Allocated Acquisition Cost", "Marketing, referral and onboarding cost allocated to the cohort (Allocation Results of the acquisition cost pools).", "Acquisition Cost", "Amount", "", "USD 412,000", "Internal", "TDABC", "Y"),
       ("New Households Acquired", "Client Households whose first account was funded in the cohort month.", "Acquisition Cost", "Integer", "", "318", "Internal", "", "", "Derived copy of the count of 04 Acquisition Milestone rows of type 'Account Funded' for first-time households in the cohort month."),
     ]),
   ]),
   ("Lifetime Value", "Versioned lifetime value models and the household estimates they produce.", [
     ("Lifetime Value Model", [
       ("Lifetime Value Model ID", "Unique identifier of the lifetime value model.", "Lifetime Value Model", "Identifier", "", "LTVM-004", "Internal", "", "Y"),
       ("Lifetime Value Model Version", "Version of the model's assumptions.", "Lifetime Value Model", "Integer", "", "3", "Internal", "", "Y"),
       ("Lifetime Value Method", "Method used to compute lifetime value.", "Lifetime Value Model", "Code", "Lifetime Value Method", "Discounted Margin", "Internal", "", ""),
       ("Projection Horizon Years", "Number of years projected.", "Lifetime Value Model", "Integer", "Years", "20", "Internal", "", ""),
       ("Discount Rate", "Annual rate used to discount projected margin.", "Lifetime Value Model", "Percentage", "", "8.0%", "Internal", "", ""),
       ("Attrition Assumption Basis", "Source of the attrition curve applied (by segment and tenure).", "Lifetime Value Model", "Text", "", "Household attrition by segment and tenure, FY2021-FY2025 actuals", "Internal", "", ""),
       ("Asset Growth Assumption", "Annual growth of client assets assumed (market return plus net new assets).", "Lifetime Value Model", "Percentage", "", "4.0%", "Internal", "", ""),
       ("Margin Basis", "Profitability measure projected (contribution margin or operating profit).", "Lifetime Value Model", "Code", "Profitability Measure", "Contribution Margin", "Internal", "", ""),
     ]),
     ("Client Lifetime Value Estimate", [
       ("Valued Household", "02 Client Household the estimate is for.", "Lifetime Value Estimate", "Reference (Party)", "", "PTY-HH-55012", "Internal", "", "Y", "Object PII tier: PII - financial (an inference about an identified household; restricted, products show segment aggregates, CW-157)."),
       ("Valuation Model Version", "Lifetime value model and version used.", "Lifetime Value Estimate", "Reference (Lifetime Value Model, 10)", "", "LTVM-004 v3", "Internal", "", "Y"),
       ("Estimate As-Of Date", "Date as of which the estimate was computed.", "Lifetime Value Estimate", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
       ("Expected Lifetime Revenue", "Present value of the household's projected revenue over the horizon.", "Lifetime Value Estimate", "Amount", "", "USD 186,000", "Internal", "", "", "PII - financial."),
       ("Expected Lifetime Cost to Serve", "Present value of the household's projected cost to serve over the horizon.", "Lifetime Value Estimate", "Amount", "", "USD 71,500", "Internal", "", "", "PII - financial."),
       ("Client Lifetime Value", "Present value of projected margin less acquisition cost.", "Lifetime Value Estimate", "Amount", "", "USD 112,900", "Internal", "", "Y", "PII - financial."),
       ("Household Acquisition Channel", "Channel through which the household was acquired, classified here from the first funded account: 04 Acquisition Milestones and campaign credit, 03 Channel Referral, 16 rollover source and 15 enrollment history.", "Lifetime Value Estimate", "Code", "Acquisition Channel", "Workplace Rollover", "Internal", "", "", "Mastered here by the stated derivation rule (04 credits campaigns, not acquisition channels)."),
     ]),
   ]),
   ("Pricing Scenarios", "Economics of a proposed change to a client fee schedule, a fund expense term or a service offering's pricing: affected base, behavioral assumptions and projected revenue impact (CW-158). The proposed client fee is a 47 Fee Schedule version; a proposed fund term is a 36 Proposed Term Change until effective (then 01); the approval is 36.", [
     ("Pricing Scenario", [
       ("Pricing Scenario ID", "Unique identifier of the pricing scenario.", "Pricing Scenario", "Identifier", "", "PRSC-2026-0017", "Internal", "", "Y"),
       ("Pricing Scenario Type", "Kind of price change modeled.", "Pricing Scenario", "Code", "Pricing Scenario Type", "Advisory Fee Rate Change", "Internal", "", ""),
       ("Priced Subject", "Service offering or share class whose price the scenario changes.", "Pricing Scenario", "Reference (Service Offering / Share Class)", "", "OFFR-0012", "Internal", "", "Y"),
       ("Proposed Schedule Version", "Proposed 47 client Fee Schedule version, or the 36 Proposed Term Change that holds the proposed fund expense term until it is effective, that the scenario prices.", "Pricing Scenario", "Reference (Fee Schedule, 47 / Proposed Term Change, 36)", "", "CLFEE-0031-05", "Internal", "Form ADV Part 2A Item 5", "", "Row rule (CW-158): client-fee scenarios reference the proposed 47 Fee Schedule version (CLFEE-, status Proposed); fund expense scenarios reference the 36 Proposed Term Change (LCHG- / term key; 01 holds the value only once effective). The scenario holds no adopted rate."),
       ("Related Change Initiative", "36 product change initiative under which the change is approved, if any.", "Pricing Scenario", "Reference (Product Change Initiative)", "", "LCHG-2026-00118", "Internal", "", ""),
       ("Competitor Pricing Evidence", "11 competitor pricing observations used as inputs.", "Pricing Scenario", "Reference (Competitor Pricing Observation, 11) (multi)", "", "COFF-00213 / Advisory Fee Rate / 2026-09-30", "Internal", "", ""),
       ("Affected Client Assets", "Client assets of the accounts the change applies to, as of the Scenario Base Date.", "Pricing Scenario", "Amount", "", "USD 48,000,000,000", "Internal", "", "", "Derived copy of 06 Client Asset Measures.Ending Client Assets for the affected offering or share class as of the Scenario Base Date."),
       ("Scenario Base Date", "As-of date of the affected base (client assets and accounts) the scenario starts from.", "Pricing Scenario", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
       ("Assumed Retention Rate", "Share of affected assets assumed to stay after the change.", "Pricing Scenario", "Percentage", "", "98.5%", "Internal", "", ""),
       ("Assumed Flow Response", "Annual net new assets response to the change, as a percentage of affected assets.", "Pricing Scenario", "Percentage", "", "1.2%", "Internal", "", ""),
     ]),
     ("Pricing Scenario Result", [
       ("Projection Year", "Year of the projection.", "Pricing Scenario Result", "Integer", "", "2027", "Internal", "", ""),
       ("Projected Revenue Under Scenario", "Revenue projected for the year if the change is adopted.", "Pricing Scenario Result", "Amount", "", "USD 101,400,000", "Internal", "", "Y"),
       ("Projected Revenue Impact", "Projected revenue under the scenario less the baseline projection for the year.", "Pricing Scenario Result", "Amount", "", "USD -4,600,000", "Internal", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Management Hierarchies", "DF-HIR",
  "Versioned hierarchies for business line, offering, channel, product, segment and entity P&L, their node structure, segment mapping and restatements when hierarchies change.",
  [
   ("Management Hierarchy", "A versioned rollup structure used for the management P&L.", [
     ("Management Hierarchy", [
       ("Management Hierarchy ID", "Unique identifier of the hierarchy version.", "Management Hierarchy", "Identifier", "", "MHY-OFFERING-2026v2", "Internal", "", "Y"),
       ("Hierarchy Type", "Dimension the hierarchy organizes.", "Management Hierarchy", "Code", "Hierarchy Type", "Service Offering", "Internal", "", "Y"),
       ("Hierarchy Status", "Lifecycle status of the version.", "Management Hierarchy", "Code", "Hierarchy Status", "Active", "Internal", "", ""),
       ("Hierarchy Effective From", "Date the version applies from.", "Management Hierarchy", "Date", "ISO 8601", "2026-07-01", "Internal", "", ""),
       ("Hierarchy Effective To", "Date the version ends.", "Management Hierarchy", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Management Hierarchy Node", [
       ("Node ID", "Identifier of the node within the hierarchy version.", "Management Hierarchy Node", "Identifier", "", "MHY-OFFERING-2026v2.N0142", "Internal", "", ""),
       ("Parent Node", "Node directly above.", "Management Hierarchy Node", "Reference (Management Hierarchy Node, 10)", "", "MHY-OFFERING-2026v2.N0100", "Internal", "", "Y"),
       ("Leaf Member", "Dimension member mapped to a leaf node (offering OFFR-, share class SHC-, channel code, business line code, org unit OU-).", "Management Hierarchy Node", "Reference (Dimension Member)", "", "OFFR-0012", "Internal", "", ""),
       ("Operating Segment Mapping", "Reportable operating segment the node rolls into, where management and segment reporting align.", "Management Hierarchy Node", "Text", "", "Wealth Management (single segment)", "ASC 280", "", ""),
     ]),
   ]),
   ("Hierarchy Restatement", "Recorded decisions to restate prior-period P&L when a hierarchy, allocation rule or mapping changes.", [
     ("Hierarchy Restatement", [
       ("Restatement ID", "Unique identifier of the restatement.", "Hierarchy Restatement", "Identifier", "", "HRS-2026-007", "Internal", "", ""),
       ("Restatement Trigger", "Change that triggered the restatement.", "Hierarchy Restatement", "Code", "Restatement Trigger", "Coverage Model Change", "Internal", "", ""),
       ("Restatement Method", "How history is treated.", "Hierarchy Restatement", "Code", "Restatement Method", "Full Restatement", "Internal", "ASC 280", "Y"),
       ("Restated From Period", "First period restated.", "Hierarchy Restatement", "Code", "External (09 Shared - Fiscal Period)", "FY2025-P01", "Internal", "", ""),
       ("Restated To Period", "Last period restated.", "Hierarchy Restatement", "Code", "External (09 Shared - Fiscal Period)", "FY2026-P06", "Internal", "", ""),
       ("Prior Hierarchy Version", "Hierarchy version replaced.", "Hierarchy Restatement", "Reference (Management Hierarchy)", "", "MHY-OFFERING-2026v1", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Budgets & Forecasts", "DF-BUD",
  "Budgets, rolling forecasts, long-range plans and scenarios, net new asset and revenue forecasts by channel and offering, and plan-versus-actual variance. 'Plan' here is a budget Plan Version (term conflict with 45 Financial Plan and 16 Retirement Plan, CW-058).",
  [
   ("Plan Version", "A budget, forecast or scenario version.", [
     ("Plan Version", [
       ("Plan Version ID", "Unique identifier of the plan version.", "Plan Version", "Identifier", "", "BUD-FY2027-B1", "Internal", "", "Y"),
       ("Plan Type", "Type of plan.", "Plan Version", "Code", "Plan Type", "Annual Budget", "Internal", "", "Y"),
       ("Scenario", "Scenario the version represents.", "Plan Version", "Code", "Scenario", "Base", "Internal", "", ""),
       ("Plan Fiscal Year", "Fiscal year covered.", "Plan Version", "Code", "External (09 Shared - Fiscal Period)", "FY2027", "Internal", "", ""),
       ("Plan Version Status", "Workflow status.", "Plan Version", "Code", "Plan Version Status", "Approved", "Internal", "", ""),
       ("Market Return Assumption", "Assumed market appreciation applied to client assets and fund net assets.", "Plan Version", "Percentage", "", "5.0% p.a. equities; 3.0% p.a. fixed income", "Internal", "", ""),
       ("Enterprise Financial Plan Version", "19 enterprise financial plan version this plan rolls into (the link is held here only).", "Plan Version", "Reference (Financial Plan Version)", "", "FPL-2027-BUD", "Internal", "", ""),
     ]),
   ]),
   ("Plan Lines", "Planned amounts by P&L line and dimension.", [
     ("Plan Line", [
       ("Plan P&L Line", "Management P&L line planned.", "Plan Line", "Code", "Management P&L Line", "Marketing & Acquisition Spend", "Internal", "", ""),
       ("Plan Cost Center", "Cost center the amount is planned in (19 chart segment value).", "Plan Line", "Reference (Chart Segment Value)", "", "45100", "Internal", "", ""),
       ("Plan Dimension Members", "Offering, channel, business line or product the line is planned at, where below cost-center level.", "Plan Line", "Reference (Dimension Member) (multi)", "", "OFFR-0012; DIRECT_DIGITAL_ADVICE", "Internal", "", ""),
       ("Plan Period", "Fiscal period of the amount.", "Plan Line", "Code", "External (09 Shared - Fiscal Period)", "FY2027-P03", "Internal", "", ""),
       ("Planned Amount", "Amount planned for the line, member and period, in the reporting currency.", "Plan Line", "Amount", "", "USD 420,000", "Internal", "", "Y"),
       ("Driver-Based Indicator", "Whether the amount is computed from drivers (client assets x basis points) rather than entered.", "Plan Line", "Boolean", "", "Y", "Internal", "", ""),
     ]),
   ]),
   ("Flow & Revenue Forecast", "Forecast flows, client assets and revenue by offering or share class and channel, using the 06 measure definitions (Client Assets, Net New Assets).", [
     ("Flow & Revenue Forecast", [
       ("Forecast Share Class / Product", "Service offering, product or share class forecast.", "Forecast", "Reference (Service Offering / Product / Share Class)", "", "OFFR-0012", "Internal", "", ""),
       ("Forecast Channel", "Distribution channel forecast.", "Forecast", "Code", "External (Enterprise - Distribution Channel)", "DIRECT_DIGITAL_ADVICE", "Internal", "", ""),
       ("Forecast Gross Sales", "Forecast gross inflows for the period (06 Net New Assets inflow definition); gross inflows less redemptions is the forecast net new assets.", "Forecast", "Amount", "", "USD 120,000,000", "Internal", "ICI", ""),
       ("Forecast Redemptions", "Forecast gross outflows for the period (06 Net New Assets outflow definition).", "Forecast", "Amount", "", "USD 95,000,000", "Internal", "ICI", ""),
       ("Forecast Average AUM", "Forecast average client assets (or fund net assets on share class rows).", "Forecast", "Amount", "", "USD 1,880,000,000", "Internal", "", ""),
       ("Forecast Net Fee Rate", "Forecast net revenue rate after waivers and discounts.", "Forecast", "Decimal", "Basis points", "21.0", "Internal", "", ""),
       ("Forecast Net Revenue", "Forecast revenue after fund waivers and client discounts for the offering or share class, channel and period.", "Forecast", "Amount", "", "USD 3,290,000", "Internal", "", "Y"),
     ]),
   ]),
   ("Plan vs Actual Variance", "Variance between actual and a plan version, with driver decomposition.", [
     ("Variance", [
       ("Compared Plan Version", "Plan version compared with actual.", "Variance", "Reference (Plan Version)", "", "BUD-FY2026-B1", "Internal", "", ""),
       ("Variance Amount", "Actual minus plan.", "Variance", "Amount", "", "USD -84,000", "Internal", "", "Y"),
       ("Variance Driver", "Main cause of the variance.", "Variance", "Code", "Variance Driver", "Market", "Internal", "", ""),
       ("Variance Commentary", "Explanation provided by FP&A.", "Variance", "Text", "", "Lower equity markets reduced average client assets 6%", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Intercompany & Transfer Pricing", "DF-ICT",
  "Intercompany service agreements between the firm's US entities (the RIA, the broker-dealer, the fund adviser, the transfer agent, the recordkeeper, the trust company and the parent's shared services), their transfer pricing policies under IRC section 482 and the resulting charges and settlements.",
  [
   ("Intercompany Agreement", "Agreement for services between internal legal entities.", [
     ("Intercompany Agreement", [
       ("Intercompany Agreement ID", "Unique identifier of the intercompany agreement.", "Intercompany Agreement", "Identifier", "", "ICA-0019", "Internal", "", "Y"),
       ("Service Provider Entity", "Internal entity providing the service.", "Intercompany Agreement", "Reference (Legal Entity)", "", "LEN-0004 (broker-dealer)", "Internal", "IRC §482", "Y"),
       ("Service Recipient Entity", "Internal entity receiving and paying for the service.", "Intercompany Agreement", "Reference (Legal Entity)", "", "LEN-0003 (fund adviser)", "Internal", "IRC §482", ""),
       ("Intercompany Service Type", "Type of service.", "Intercompany Agreement", "Code", "Intercompany Service Type", "Distribution Services", "Treas. Reg. §1.482-9", "FINRA Notice to Members 03-63", "Y"),
       ("Covered Products", "Products or share classes in scope.", "Intercompany Agreement", "Reference (Product) (multi)", "", "PRD-00981", "Internal", "", ""),
       ("Agreement Effective From", "Date the agreement applies from.", "Intercompany Agreement", "Date", "ISO 8601", "2025-01-01", "Internal", "", ""),
       ("Agreement Effective To", "Date the agreement ends.", "Intercompany Agreement", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Transfer Pricing Policy", "Arm's-length pricing method and parameters for an intercompany agreement.", [
     ("TP Policy", [
       ("TP Method", "Transfer pricing method applied to the controlled services transaction.", "TP Policy", "Code", "TP Method", "Cost of Services Plus Method", "Treas. Reg. §1.482-9", "OECD TPG", "Y"),
       ("Remuneration Basis", "How the provider is remunerated.", "TP Policy", "Code", "TP Remuneration Basis", "Cost Plus Mark-Up", "Treas. Reg. §1.482-9", "", ""),
       ("Remuneration Rate", "Mark-up on cost or fee-share percentage.", "TP Policy", "Percentage", "", "7.5% on total services costs", "Treas. Reg. §1.482-9", "", "Y"),
       ("Tested Party", "Entity whose result is tested against comparables.", "TP Policy", "Reference (Legal Entity)", "", "LEN-0004", "Treas. Reg. §1.482-9", "", ""),
       ("Arm's Length Range Lower Bound", "Lower bound of the arm's length (interquartile) range of the profit level indicator.", "TP Policy", "Percentage", "", "4.2%", "Treas. Reg. §1.482-1", "", ""),
       ("Arm's Length Range Upper Bound", "Upper bound of the arm's length range.", "TP Policy", "Percentage", "", "9.8%", "Treas. Reg. §1.482-1", "", ""),
       ("TP Documentation Reference", "19 transfer pricing documentation that supports the policy (IRC section 6662(e) documentation). The link is held on the 10 side.", "TP Policy", "Reference (Transfer Pricing Documentation, 19)", "", "US Local File FY2025", "IRC §482", "", ""),
     ]),
   ]),
   ("Intercompany Charge", "Period charges calculated under an intercompany agreement and their settlement.", [
     ("Intercompany Charge", [
       ("Intercompany Charge ID", "Unique identifier of the charge.", "Intercompany Charge", "Identifier", "", "ICC-2026-09-0019", "Internal", "", ""),
       ("Charging Agreement", "Agreement under which the charge is made.", "Intercompany Charge", "Reference (Intercompany Agreement)", "", "ICA-0019", "Internal", "", ""),
       ("Charge Period", "Fiscal period of the charge.", "Intercompany Charge", "Code", "External (09 Shared - Fiscal Period)", "FY2026-P09", "Internal", "", ""),
       ("Charge Amount", "Amount charged.", "Intercompany Charge", "Amount", "", "USD 980,000", "IRC §482", "", "Y"),
       ("Settlement Status", "Settlement status of the charge.", "Intercompany Charge", "Code", "Settlement Status", "Settled", "Internal", "", ""),
       ("Elimination Indicator", "Whether the charge is eliminated on consolidation (and, for members of the US consolidated federal return, deferred and matched under the intercompany transaction regulations).", "Intercompany Charge", "Boolean", "", "Y", "ASC 810", "Treas. Reg. §1.1502-13", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Revenue Contract Type": ("Internal (aligned to AICPA Revenue Recognition Guide, asset management)", [("Investment Advisory Agreement (Fund)","Investment Company Act management agreement with an own mutual fund or ETF, or the advisory agreement of a CIT"),("Advisory Agreement (Client)","Advisory or wrap program agreement with a client (15 Account Agreement)"),("Brokerage Customer Agreement","Brokerage account agreement with a client (15 Account Agreement)"),("Financial Planning Agreement","Standalone planning or subscription agreement"),("Plan Recordkeeping Agreement","Recordkeeping service arrangement with a plan sponsor (16)"),("Trust Agreement","Trust company appointment as trustee or agent (51)"),("Investment Management Agreement (Mandate)","Institutional separate account or OCIO mandate"),("Principal Underwriting / Distribution Agreement","Broker-dealer as principal underwriter under a 12b-1 plan (intermediary channel)"),("Shareholder Servicing Agreement",""),("Sub-Advisory Agreement","Firm acts as sub-adviser to a third-party fund"),("CIT Trustee / Advisory Agreement",""),("Other","")]),
 "Customer Determination Basis": ("AICPA Revenue Recognition Guide", [("Fund is Customer","Typical for '40 Act funds and CITs"),("Client is Customer","Advisory, brokerage, planning and trust clients"),("Plan Sponsor is Customer","Recordkeeping arrangements"),("Institution is Customer","Institutional separate accounts and OCIO mandates"),("Under Review","")]),
 "Accounting Basis": ("Shared list Accounting Basis (steward 19)", [("US GAAP",""),("Tax Basis","Book kept on a tax basis"),("Regulatory","Basis prescribed for a regulatory return")]),
 "Performance Obligation Type": ("ASC 606", [("Investment Advisory Services (Series)","Discretionary or non-discretionary advice over time"),("Asset Management Services (Series)","Daily management of an own fund or mandate"),("Financial Planning Services",""),("Brokerage Execution","Trade execution; satisfied on the trade date"),("Client Asset Custody & Account Servicing","Account maintenance and custody of client assets (SEC Rule 15c3-3) over time"),("Cash Sweep Administration","Administration of the bank deposit sweep"),("Recordkeeping Services","Plan and participant recordkeeping over time"),("Trust Administration",""),("Distribution Service","Sale of fund shares; satisfied at the point of sale"),("Shareholder Servicing","Ongoing servicing over time")]),
 "Satisfaction Pattern": ("ASC 606", [("Over Time",""),("Point in Time","")]),
 "Revenue Stream": ("Internal (aligned to US GAAP Taxonomy disaggregation and the FOCUS report revenue lines)", [("Advisory Fee","Asset-based advisory fee (47)"),("Wrap Fee","Wrap program fee (47)"),("Planning Fee","Standalone planning fee (47)"),("Subscription Fee","Flat or subscription advice fee (47)"),("Commission","Agency commission charged on client trade confirmations (48)"),("Markup / Markdown","Markup or markdown on principal trades, from client trade confirmations (48)"),("Account Service Fee","Wire, transfer-out, paper statement and similar fees (47)"),("Margin Interest","Interest on margin debit balances (49)"),("Fully Paid Lending Revenue","Firm share of fully paid securities lending revenue (49)"),("Bank Sweep Fee","Fees from program banks on swept deposits; account rows allocated from Cash Program Economics by 50 Sweep Allocation balance"),("Fund Management Fee","Own mutual fund, ETF, CIT and money market sweep fund fees (Fee Revenue Record only, not a Client Revenue stream)"),("Fulcrum Fee Adjustment","Advisers Act Rules 205-1 and 205-2 (Performance Fee Record only)"),("Mandate Performance Fee","Advisers Act Rule 205-3 (47)"),("12b-1 Fee","Intermediary channel share classes (Distribution Revenue Record only)"),("Transfer Agency Fee","Fees of the in-house transfer agent from own funds (fund level)"),("Sub-Advisory Fee Received","Firm as sub-adviser to a third-party fund"),("Recordkeeping Fee","Plan and participant fees billed by 47 under the 16 service arrangement"),("Trust Fee","Trust company fees billed by 47 under the 51 trust terms"),("OCIO Fee","Institutional OCIO fees (47)"),("Order Routing Payment","Payment for order flow; default none (SEC Rule 606 disclosure); lever: firm-level rows from 48 Rule 606 data, allocated to accounts only if needed"),("Other Revenue","")]),
 "Fee Basis Source": ("Internal", [("Fund Accounting NAV","27 fund average net assets"),("Transfer Agent Records","29 registered shares"),("06 Average Client Assets Measure","Estimate only")]),
 "Revenue Data Basis": ("Internal", [("Actual","Settled"),("Accrued Estimate","Daily or month-end accrual"),("Allocated","Spread from a higher grain"),("Restated","")]),
 "Constraint Assessment Outcome": ("ASC 606", [("Fully Constrained","No revenue recognized"),("Partially Constrained","Recognized up to the unconstrained amount"),("Unconstrained","Determined and no longer subject to reversal")]),
 "Distribution Revenue Type": ("SEC Rule 12b-1 / FINRA Rule 2341", [("12b-1 Distribution Fee",""),("12b-1 Service Fee",""),("Shareholder Servicing Fee","Non-12b-1"),("Front-End Sales Charge Retained","Underwriter concession net of dealer reallowance"),("Contingent Deferred Sales Charge","")]),
 "Principal vs Agent Conclusion": ("ASC 606", [("Principal","Present gross; pass-through as expense"),("Agent","Present net of pass-through"),("Under Review","")]),
 "Waiver Type": ("SEC Form N-1A / Internal (shared list, steward 27)", [("Contractual Fee Waiver",""),("Voluntary Fee Waiver",""),("Expense Reimbursement",""),("Money Market Yield Waiver","Waiver to maintain non-negative yield"),("Acquired Fund Fee Waiver","Waiver for fees of affiliated underlying funds"),("12b-1 Fee Waiver","")]),
 "Waiver Accounting Treatment": ("ASC 606", [("Reduction of Revenue","Consideration payable to a customer"),("Operating Expense","Where payment is for a distinct service"),("Under Review","")]),
 "Adviser-Borne Cost Type": ("Internal", [("Fund Expense Above Cap","Only amounts not reimbursed through the expense cap (those are Waiver Record)"),("Fund Organization and Offering Costs",""),("Seed Capital Cost",""),("Sub-TA Fee Above Fund Cap","Intermediary channel"),("Revenue Sharing (Own Resources)","Intermediary channel")]),
 "Cost Item Category": ("Internal (aligned to US GAAP Taxonomy and the FOCUS report expense lines)", [("Advisor Base Compensation","20 payroll by cost center (03 advisors), booked per cost center"),("Advisor Incentive Compensation","03 Compensation Statements, booked per cost center"),("Service Staff Compensation",""),("Referral Incentives","03 Channel Referral incentives"),("Marketing & Acquisition Spend","04 Spend Line actuals"),("Clearing & Exchange Fees","Clearing house and exchange fees (regulatory transaction fees are Regulatory Fees & Assessments)"),("Execution & Market Data","Execution venue and real-time market data services (licensed datasets are Third-Party Data Licenses)"),("Contact Center Technology",""),("Platform Technology",""),("Third-Party Data Licenses","14 data license costs"),("Statement & Mailing Costs",""),("Sub-Advisory Fees","52 sub-adviser engagements"),("Regulatory Fees & Assessments","SEC section 31 fees, FINRA trading activity fees and registration assessments"),("Revenue Sharing","Intermediary channel, from own resources"),("Sub-TA / Networking Fees","Intermediary channel"),("12b-1 Paid to Intermediaries","Intermediary channel"),("Platform Fees","Intermediary channel"),("Travel & Entertainment",""),("Other","")]),
 "Source Domain": ("Program Data Domains (member of the shared Business Domain list)", [("03 Advisor Organization, Coverage & Supervision","Compensation Statements, incentive plan components"),("04 Marketing, Digital & Client Engagement","Campaign spend"),("05 Intermediary & Institutional Distribution","Partner payments (intermediary channel)"),("14 Third-Party Data & Licensing","Data license costs"),("16 Retirement Plan Administration","Plan service arrangements"),("19 Finance & Accounting","Payable invoices"),("20 Human Capital","Payroll cost by cost center"),("40 Procurement & Vendor Management","Supplier invoices"),("47 Pricing, Fees & Billing","Fee calculations and invoices"),("48 Brokerage Orders & Execution","Confirmations and execution costs"),("49 Clearing, Settlement & Client Asset Custody","Clearing and margin costs"),("50 Money Movement, Cash & Sweep","Sweep and money movement costs"),("52 External Manager & Sub-Adviser Oversight","Sub-advisory engagements"),("ERP / Accounts Payable","Direct supplier invoice")]),
 "Capitalization Outcome": ("ASC 340-40", [("Expense as Incurred",""),("Capitalize - Cost to Obtain","Incremental cost of obtaining a contract"),("Capitalize - Cost to Fulfill",""),("Practical Expedient - Expensed","Amortization period one year or less"),("Other GAAP Applies","For example ASC 946 legacy guidance")]),
 "Accrual Basis": ("Internal", [("Engine Calculation","From the 03, 04 or 05 calculation"),("Run-Rate Estimate",""),("Budget-Based",""),("Invoice Received","")]),
 "True-Up Reason": ("Internal", [("Invoice Variance",""),("Basis Data Restated",""),("Rate Change",""),("Late Agreement Execution",""),("Cap Applied",""),("Error Correction","")]),
 "Cost Asset Type": ("ASC 340-40", [("Incremental Cost to Obtain","Advisor and referral incentives for new advisory contracts"),("Cost to Fulfill","For example account onboarding and conversion costs"),("Deferred Sales Commission","Legacy level-load and back-end-load share class commissions (intermediary channel; lever)")]),
 "Amortization Method": ("ASC 340-40", [("Straight-Line",""),("Pattern of Revenue",""),("Pattern of Redemptions","Aligned to a CDSC schedule (legacy)")]),
 "Customer Contract Linkage": ("AICPA Revenue Recognition Guide / Internal", [("Directly Obtains New Customer Contract","For example a new advisory client agreement or mandate"),("Linked to Fund Share Sales Only","Customer is the fund; no new contract obtained"),("Not Incremental","Discretionary, salary or team-based")]),
 "Management P&L Line": ("Internal (aligned to the FOCUS report revenue and expense lines)", [("Advisory Fee Revenue",""),("Brokerage Commission Revenue",""),("Account Service Fee Revenue",""),("Interest & Cash Program Revenue","Margin interest, fully paid lending and bank sweep fees"),("Fund Management Fee Revenue",""),("Performance Fee Revenue",""),("Distribution & Servicing Revenue",""),("Recordkeeping & Trust Fee Revenue",""),("Fund Waivers & Reimbursements",""),("Advisor & Service Compensation",""),("Marketing & Acquisition Spend",""),("Clearing, Client Asset Custody & Operations",""),("Technology & Data",""),("Partner Payments","Intermediary channel"),("Sub-Advisory Fees",""),("Amortization of Contract Costs",""),("Allocated Overhead",""),("Intercompany Service Fees","")]),
 "Cost Pool Type": ("Internal", [("Advice",""),("Client Service",""),("Platform & Technology",""),("Clearing & Client Asset Custody Operations",""),("Money Movement Operations",""),("Client Communications",""),("Compliance & Supervision",""),("Marketing & Acquisition",""),("Product Management",""),("Intermediary Distribution","Intermediary channel"),("Corporate Overhead","")]),
 "Cost-to-Serve Component": ("Internal (CW-157)", [("Advice","Advisor coverage and planning"),("Service","Contact center and service operations"),("Platform","Digital platform, advice engine and account technology"),("Clearing and Client Asset Custody","Self-clearing, client asset custody and transfer agency"),("Money Movement","ACH, wire, check and sweep processing"),("Communications","Statements, confirmations, tax forms and regulatory mailings"),("Regulatory","Supervision, surveillance and regulatory fees")]),
 "Allocation Method Type": ("Internal / TDABC", [("Direct Assignment",""),("Driver-Based",""),("Activity-Based",""),("Time-Driven Activity-Based","Kaplan & Anderson TDABC"),("Proportional to Revenue",""),("Fixed Percentage",""),("Step-Down",""),("Reciprocal","")]),
 "Allocation Driver Type": ("Internal", [("Average Client Assets","06 measure"),("Net New Assets","06 measure"),("Revenue",""),("Account Count","15 accounts"),("Household Count","02 Client Households"),("Service Contact Count","13 service requests and contact center interactions"),("Trade Count","48 executions"),("Money Movement Count","50 money movements"),("Advisor Activity Count","03 activities"),("Headcount",""),("Time / Effort","")]),
 "Profitability Dimension": ("Internal", [("Channel",""),("Business Line",""),("Service Offering",""),("Service Tier",""),("Product",""),("Share Class",""),("Advisor","03 Advisor; confidential"),("Household","02 Client Household; restricted"),("Client","Client or institutional client"),("Account","15 account"),("Client Segment",""),("Partner Firm","Intermediary channel"),("Retirement Plan","16 plan service arrangement"),("Legal Entity",""),("Region","")]),
 "Data Version": ("Internal", [("Actual",""),("Budget",""),("Forecast",""),("Scenario","")]),
 "Run Status": ("Internal", [("Draft",""),("Preliminary",""),("Final",""),("Superseded","")]),
 "Profitability Measure": ("Internal", [("Net Revenue Yield",""),("Net Revenue After Distribution Costs",""),("Contribution Margin",""),("Operating Profit",""),("Operating Margin",""),("Cost-to-Serve Rate",""),("Cost-Income Ratio","")]),
 "Acquisition Channel": ("Internal", [("Organic Digital","Direct web and app sign-up without paid media"),("Paid Digital Media",""),("Workplace Rollover","Rollover from a plan the firm recordkeeps (WR)"),("Self-Directed to Advice Conversion","Existing self-directed household enrolling in advice"),("Advisor Referral","03 Channel Referral"),("Client Referral","04 Client Referral"),("Events & Seminars",""),("Partner Introduction","Intermediary or institutional introduction"),("Other","")]),
 "Lifetime Value Method": ("Internal", [("Discounted Margin","Present value of projected margin over the horizon with attrition"),("Cohort Revenue Multiple","Revenue multiple from cohort history"),("Survival Model","Attrition modeled by a survival curve")]),
 "Pricing Scenario Type": ("Internal", [("Advisory Fee Rate Change",""),("Fee Schedule Restructure","Tiers, breakpoints or minimums"),("Commission Change",""),("Account Service Fee Change",""),("Fund Expense Ratio Change","36 Proposed Term Change; 01 once effective"),("Sweep Rate Change","Client rate on swept cash"),("New Offering Price",""),("Other","")]),
 "Hierarchy Type": ("Internal", [("Business Line",""),("Service Offering",""),("Channel",""),("Product",""),("Client Segment",""),("Legal Entity",""),("Cost Center",""),("Region","")]),
 "Hierarchy Status": ("Internal (member of the shared Record Status list)", [("Draft",""),("Active",""),("Retired","")]),
 "Restatement Trigger": ("Internal", [("Channel Reorganization",""),("Coverage Model Change","03 coverage model or reassignment"),("Offering Restructure",""),("Allocation Rule Change",""),("Account Mapping Change",""),("Product Reclassification",""),("Error Correction","")]),
 "Restatement Method": ("Internal", [("Full Restatement",""),("Prospective Only",""),("Pro Forma Side-by-Side","")]),
 "Plan Type": ("Internal (member of the shared Financial Plan Type list)", [("Annual Budget",""),("Rolling Forecast",""),("Long-Range Plan",""),("Scenario","")]),
 "Scenario": ("Internal (member of the shared Plan Scenario list)", [("Base",""),("Upside",""),("Downside",""),("Market Stress","")]),
 "Plan Version Status": ("Internal (member of the shared Plan Version Status list)", [("Draft",""),("Submitted",""),("Approved",""),("Locked","")]),
 "Variance Driver": ("Internal", [("Volume (Flows)",""),("Market",""),("Rate / Mix",""),("FX","Foreign-currency revenue of international funds and holdings"),("Timing",""),("Cost","")]),
 "Intercompany Service Type": ("Treas. Reg. §1.482-9 / Internal", [("Distribution Services","Broker-dealer as principal underwriter of own funds"),("Investment Advisory Services","Sub-advice between affiliates"),("Brokerage & Clearing Services",""),("Transfer Agency Services",""),("Recordkeeping Services",""),("Trust Services",""),("Technology Services",""),("Shared Services",""),("Fee Sharing","")]),
 "TP Method": ("Treas. Reg. §1.482-9 (controlled services)", [("Services Cost Method",""),("Comparable Uncontrolled Services Price Method",""),("Gross Services Margin Method",""),("Cost of Services Plus Method",""),("Comparable Profits Method",""),("Profit Split Method",""),("Unspecified Method","")]),
 "TP Remuneration Basis": ("Internal", [("Cost Plus Mark-Up",""),("Cost Without Mark-Up","Services cost method"),("Share of Management Fee",""),("Share of Distribution Fee",""),("Revenue Split","")]),
 "Settlement Status": ("Internal", [("Pending",""),("Invoiced",""),("Settled",""),("Netted","")]),
 "Reconciliation Type": ("Internal", [("Fee Calculations vs Client Revenue (47)",""),("Confirmations vs Commission Revenue (48)",""),("Booked vs Estimated Revenue (06)",""),("Partner Payments Accrued vs Calculated (05)","Intermediary channel"),("Compensation Accrual vs Statements (03)",""),("Client Revenue vs GL (19)",""),("Profitability vs GL (19)","")]),
 "Reconciliation Status": ("Internal (member of the shared Reconciliation Status list)", [("Reconciled",""),("Reconciled within Tolerance",""),("Break Open",""),("Break Explained","")]),
 "Business Line": ("Shared list Business Line (CW-004)", [("DB","Direct brokerage and self-directed investing"),("DA","Digital advice"),("HA","Human and hybrid advice"),("PF","Proprietary funds and ETFs"),("WR","Workplace retirement recordkeeping"),("IA","Institutional advisory"),("IC","Intermediary channel"),("TR","Personal trust services")]),
}

# ---------------------------------------------------------------------------
# Relationships, sources
# ---------------------------------------------------------------------------
REL = [
 ("Revenue Contract","contains","Performance Obligation","1 : 1..n",""),
 ("Revenue Contract","is based on","Fund Advisory Agreement (35: ADVA-) / Account Agreement (15: AAG-) / Service Arrangement (16: PSVA-) / Trust (51: TRUST-) / Investment Mandate (01: MND-) / Distribution Agreement (05: AGR-)","n : 1","Row rule on Underlying Agreement (CD-232, CW-156)."),
 ("Revenue Contract","has customer","Party (02 Client & Household: PTY-)","n : 1","Customer determination per the AICPA guide."),
 ("Revenue Contract","is recorded by","Legal Entity (09 Shared: LEN-)","n : 1",""),
 ("Fee Revenue Record","is earned on","Share Class (01: SHC-) under the fund fee terms (01: FSCH-)","n : 1","Fund expense terms are 01 (CW-051); 10 holds the booked revenue."),
 ("Fee Revenue Record","copies the accrual of","Fund Expense Accrual (27, management fee)","n : 1..n","Gross Fee Revenue and Applied Gross Fee Rate are Derived copies (CW-156)."),
 ("Fee Revenue Record","reconciles to","Estimated fee revenue measure (06: MSR-)","n : 1","Books versus estimate reconciliation."),
 ("Fee Revenue Record","is reduced by","Waiver Record","1 : 0..n",""),
 ("Fee Revenue Record","pays sub-advisory fee under","Sub-Adviser Engagement (52: SADV-)","n : 0..1",""),
 ("Performance Fee Record","applies terms of","Fund fee terms (01: FSCH-) / Fee Schedule Performance Fee Terms (47: CLFEE-)","n : 1","Row rule on Performance Fee Terms Reference; mandate amounts from the 47 Performance Fee Calculation."),
 ("Waiver Record","applies terms of","Expense cap terms (01: SHC- / FSCH-)","n : 1","01 owns the terms; 10 owns the financial impact; client fee waivers are 47 FWV-."),
 ("Distribution Revenue Record","passes through via","Payment Calculation (05: PCL-)","1 : 0..n","Intermediary channel only."),
 ("Client Revenue Record","is earned on","Account (15: ACC-)","n : 1","Household rows reference the 47 Fee Household (FHHG-); plan-paid rows the 16 Service Arrangement (PSVA-)."),
 ("Client Revenue Record","is calculated by","Account Fee Calculation / Fee Invoice (47: FCRUN- / BIL-)","n : 1..n","Advisory, wrap, planning, OCIO, recordkeeping and trust fees (CW-012)."),
 ("Client Revenue Record","is calculated by","Client Trade Confirmation (48: CCONF-)","n : 1..n","Commissions and markups (Commission Charged, Markup Markdown Amount)."),
 ("Client Revenue Record","is calculated by","Fee Debit / Fee Adjustment (47: FDBT- / FADJ-)","n : 0..n","Account service charges and corrections."),
 ("Client Revenue Record","is allocated by","Sweep Allocation (50)","n : 0..n","Bank Sweep Fee rows allocated from Cash Program Economics."),
 ("Client Revenue Record","is calculated by","Client Account Activity / Fully Paid Securities Loan (49: CLACT- / CSLN-)","n : 1","Margin interest and fully paid lending revenue."),
 ("Client Revenue Record","is earned under","Service Offering (01: OFFR-)","n : 1",""),
 ("Client Revenue Record","takes channel from","Account Channel Assignment (06: CHASG-)","n : 1","Derived copy as of the period end."),
 ("Client Revenue Record","takes segment from","Segment Assignment (02)","n : 0..1","Derived copy as of the period end."),
 ("Cash Program Economics","is earned on","Sweep Program / Program Bank (50: SWEEP- / PGBNK-)","n : 1","Average swept balance and client rate are Derived copies of 50; the fee is computed from 50 Program Bank Daily Total and the 39 program bank agreement."),
 ("Cash Program Economics","includes","Fee Revenue Record (money market sweep fund)","n : 0..1",""),
 ("Distribution Cost Item","is sourced from","Compensation Statement (03: CPS-)","n : 1","Advisor compensation, booked per cost center."),
 ("Distribution Cost Item","is sourced from","Payment Calculation / Partner Payment (05: PCL- / PMT-)","n : 1","Intermediary channel partner payments."),
 ("Distribution Cost Item","is sourced from","Campaign spend (04: CAM-)","n : 1","Marketing and acquisition actuals."),
 ("Distribution Cost Item","is charged to","Chart Segment Value / Cost Center (19 Finance)","n : 1","Cost center codes are mastered in 19 (CD-152)."),
 ("Distribution Cost Item","is accrued by","Accrual","1 : 0..n",""),
 ("Distribution Cost Item","may be capitalized into","Contract Cost Asset","n : 0..1",""),
 ("Capitalization Assessment","assesses","Incentive Plan Component (03: ICP-n-Cnn)","n : 1","CW-062, CW-159."),
 ("Account Mapping","maps to","GL Account / Ledger (19 Finance: GLA- / LDG-)","n : 1","GL postings (JNL-) and certified revenue are 19 (CD-152, CW-011)."),
 ("Control","reconciles","Account Fee Calculation (47) / Client Trade Confirmation (48) / Payment Calculation (05) / GL Account Balance (19)","n : 1..n","Reconciliation Type names the pair."),
 ("Cost Pool","is allocated by","Allocation Rule","1 : 1..n",""),
 ("Allocation Rule","applies","Allocation Method / Allocation Driver","n : 1",""),
 ("Allocation Driver","is measured by","Measure Definition (06: MSR-) / Service Request (13: SRQ-) / Client Trade Confirmation (48) / Money Movement (50)","n : 1",""),
 ("Allocation Run","produces","Allocation Result","1 : 0..n",""),
 ("Profitability Record","is dimensioned by","Party / Account / Service Offering / Service Tier / Share Class / Advisor (02 PTY-, 15 ACC-, 01 OFFR- and SHC-, 03 Advisor)","n : 0..1 each","Declared dimension grain; household rows restricted."),
 ("Profitability Record","is dimensioned by","Distributor Firm (05)","n : 0..1","Intermediary channel rows only."),
 ("Profitability Record","rolls up through","Management Hierarchy","n : 1",""),
 ("Profitability Record","has","Cost-to-Serve Profile","1 : 0..1","CW-157."),
 ("Client Acquisition Cost Record","is attributed to","Campaign (04: CAM-)","n : 0..1","Household counts are Derived copies of 04 Acquisition Milestone."),
 ("Lifetime Value Model","produces","Client Lifetime Value Estimate","1 : 0..n",""),
 ("Client Lifetime Value Estimate","values","Party (02: PTY-HH- Client Household)","n : 1","PII - financial; restricted."),
 ("Pricing Scenario","prices","Fee Schedule (47: CLFEE-) / Proposed Term Change (36)","n : 1","No adopted rate is held (CW-158)."),
 ("Pricing Scenario","is approved under","Product Change Initiative (36: LCHG-)","n : 0..1",""),
 ("Pricing Scenario","uses","Competitor Pricing Observation (11)","n : 0..n",""),
 ("Pricing Scenario","contains","Pricing Scenario Result","1 : 1..n",""),
 ("Management Hierarchy","contains","Management Hierarchy Node","1 : 1..n",""),
 ("Management Hierarchy","is restated by","Hierarchy Restatement","1 : 0..n",""),
 ("Plan Version","contains","Plan Line","1 : 1..n",""),
 ("Plan Version","rolls into","Financial Plan Version (19 Finance: FPL-)","n : 0..1","CD-152."),
 ("Flow & Revenue Forecast","uses definitions of","Measure Definition (06: MSR- Client Assets, Net New Assets)","n : 1","CW-011."),
 ("Intercompany Agreement","is priced by","TP Policy","1 : 1..n","Effective-dated."),
 ("TP Policy","is documented by","Transfer Pricing Documentation (19)","n : 1",""),
 ("Intercompany Agreement","generates","Intercompany Charge","1 : 0..n",""),
]

SRC = [
 ("FASB ASC 606 Revenue from Contracts with Customers","FASB","https://asc.fasb.org (Topic 606)","Free basic view (registration)","Five-step model, variable consideration and the constraint, principal versus agent, series guidance, consideration payable to a customer","Revenue Contract, Performance Obligation, Fee, Performance Fee and Client Revenue, Waivers",["ASC 606"]),
 ("FASB ASC 340-40 Other Assets and Deferred Costs - Contracts with Customers","FASB","https://asc.fasb.org (Subtopic 340-40)","Free basic view (registration)","Incremental costs to obtain, costs to fulfill, amortization, impairment, one-year practical expedient","Contract Cost Asset, Capitalization Assessment",["ASC 340-40"]),
 ("FASB ASC 280 Segment Reporting","FASB","https://asc.fasb.org (Topic 280)","Free basic view (registration)","Management approach to segments (CODM)","Operating Segment Mapping, Restatement, Business Line",["ASC 280"]),
 ("FASB ASC 810 Consolidation","FASB","https://asc.fasb.org (Topic 810)","Free basic view (registration)","Elimination of intercompany balances and transactions","Intercompany Charge",["ASC 810"]),
 ("AICPA Audit and Accounting Guide: Revenue Recognition (Ch. 4 Asset Management)","AICPA","https://www.aicpa-cima.com/","Licensed","Industry application: management fees, performance fees, customer determination, 12b-1 fees, CDSC, costs to obtain","Customer Determination, Trailing Fee Constraint, CDSC, Contract Linkage",["AICPA*"]),
 ("RSM US, Revenue recognition considerations for asset managers (Nov 2023)","RSM US","https://rsmus.com/content/dam/rsm/insights/financial-reporting/1pdf/Revenue-recognition-considerations-for-asset-managers-202311.pdf","Free","Practitioner summary of ASC 606 / 340-40 for asset managers","Secondary support for revenue and contract cost attributes",[]),
 ("Investment Advisers Act Rules 205-1, 205-2 and 205-3 (17 CFR 275.205-1 to 275.205-3)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-275","Regulation","Fulcrum fee computation (investment performance, asset value, specified period) and the qualified client exemption for performance fees","Performance Fee Record",["Advisers Act Rule 205*"]),
 ("SEC Rule 12b-1 (17 CFR 270.12b-1) and FINRA Rule 2341","US SEC; FINRA","https://www.ecfr.gov/current/title-17/section-270.12b-1","Regulation / SRO rule","Fund-paid distribution plans; sales charge and service fee limits","Distribution Revenue Type, Funding Source",["SEC Rule 12b-1","FINRA Rule 2341"]),
 ("Investment Company Act of 1940, Section 15","US Congress / US SEC","https://www.govinfo.gov/content/pkg/COMPS-1879/pdf/COMPS-1879.pdf","Statute","Advisory contract approval and termination on 60 days' notice without penalty","Termination Notice Period, Sub-Adviser Engagement",["Investment Company Act*"]),
 ("SEC Form N-1A (fee table, waivers and recoupment)","US SEC","https://www.sec.gov/files/formn-1a.pdf","Regulation","Gross and net expense ratios, contractual waivers and recoupment disclosure","Waiver Record, Fee Revenue Record",["SEC Form N-1A"]),
 ("SEC IM Guidance Update 2016-01 (mutual fund distribution and sub-accounting fees)","US SEC","https://www.sec.gov/investment/im-guidance-2016-01.pdf","Guidance","Fund-paid versus adviser-paid sub-accounting fees","Adviser-Borne Cost, Funding Source",["SEC IM*"]),
 ("SEC Rule 15c3-3 (customer protection) and the firm's cash sweep program disclosure","US SEC","https://www.ecfr.gov/current/title-17/section-240.15c3-3","Regulation","Sweep program conditions (paragraph (j)(2)) as context for cash program economics (confirm paragraph)","Cash Program Economics",["SEC Rule 15c3-3","Sweep program disclosure"]),
 ("SEC Rule 606 of Regulation NMS (order routing disclosure)","US SEC","https://www.ecfr.gov/current/title-17/section-242.606","Regulation","Disclosure of payment for order flow; source of the Order Routing Payment stream if the firm accepts it (default none)","Revenue Stream",["SEC Rule 606"]),
 ("FOCUS Report, Form X-17A-5 Part II (broker-dealer statement of income)","US SEC; FINRA","https://www.sec.gov/files/formx-17a-5_2.pdf","Regulation (confirm URL)","Broker-dealer revenue and expense lines (commissions, fees for account supervision and advisory services, interest, other)","Revenue Stream, Management P&L Line, Cost Item Category",["FOCUS Report*"]),
 ("Form ADV Part 2A, Item 5 (Fees and Compensation)","US SEC","https://www.sec.gov/about/forms/formadv-part2.pdf","Regulation (confirm URL)","Disclosure of advisory fee schedules and how fees are charged","Revenue Service Offering, Proposed Schedule Version",["Form ADV*"]),
 ("IRC section 482 and Treas. Reg. sections 1.482-1 and 1.482-9; IRC section 6662(e)","US Congress; US Treasury / IRS","https://www.ecfr.gov/current/title-26/section-1.482-1","Statute / regulation","Arm's length standard and range; methods for controlled services transactions; documentation","Intercompany & Transfer Pricing",["IRC §482","Treas. Reg.*"]),
 ("OECD Transfer Pricing Guidelines for Multinational Enterprises and Tax Administrations (2022)","OECD","https://doi.org/10.1787/0e655865-en","Free to read","Secondary reference only, for a firm with foreign affiliates (lever; confirm)","TP Method",["OECD*"]),
 ("FINRA Notice to Members 03-63 (Expense-Sharing Agreements)","FINRA","https://www.finra.org/rules-guidance/notices/03-63","Guidance (confirm URL)","Broker-dealer recording of expenses paid by affiliates under expense-sharing agreements (SEC Rule 17a-3 books and records)","Intercompany Service Type",["FINRA Notice*"]),
 ("US GAAP Financial Reporting Taxonomy (XBRL)","FASB","https://xbrl.fasb.org/","Free","Standard tags for revenue and expense lines in SEC filings","Account Mapping, Revenue Stream",["US GAAP Taxonomy"]),
 ("Time-Driven Activity-Based Costing (Kaplan & Anderson, HBR Nov 2004)","Harvard Business Review","https://hbswk.hbs.edu/item/adding-time-to-activity-based-costing","Article (licensed)","Capacity cost rate and time equations","Allocation Method, Allocation Driver, Cost-to-Serve",["TDABC"]),
 ("McKinsey Performance Lens Global Asset Management Survey","McKinsey & Company","https://www.mckinsey.com/featured-insights/charts/assets-up-but-profits-stuck","Free summaries; survey for participants","Industry revenue yield, cost and operating margin benchmarks","Profitability measures",["McKinsey*"]),
 ("ICI Trends in the Expenses and Fees of Funds, 2025","Investment Company Institute","https://www.ici.org/system/files/2026-03/per32-01.pdf","Free","Expense ratios, 12b-1 and load trends","Context for fee yield and distribution revenue",["ICI"]),
 ("SOX s.404 / COSO 2013 Internal Control","SEC; COSO","https://www.coso.org","Free framework summary","Controls over financial reporting","Runs, reconciliations",["SOX","COSO*"]),
]
