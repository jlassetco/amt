"""Data Domain 11 - Market & Competitive Intelligence (wealth-manager reference model; adapts the wholesale 11 in place, CW-013,
CW-160). Content module for taxonomy_builder.py."""

META = {
 "title": "Market & Competitive Intelligence Data Taxonomy",
 "subtitle": "Business domain 11 - Market & Competitive Intelligence | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-15",
 "output": "11_Market_and_Competitive_Intelligence/Market_and_Competitive_Intelligence_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the market and competitive intelligence data of a US wealth manager that serves investors directly: self-directed brokerage, digital and human advice, its own mutual funds, ETFs and CITs, workplace retirement recordkeeping, institutional advisory, a thin intermediary channel and optional personal trust services. Strategy, product and pricing teams use it to answer 'where are industry flows and household assets going, what is our share by channel, vehicle and segment, what do competing brokerages, digital and hybrid advisers, recordkeepers and fund sponsors offer and charge (advisory fee rates, commissions, account fees, margin rates, cash sweep yields, expense ratios), how do our funds compare with their peers on performance, fees and ratings, how big is each investor segment and plan market, and what is changing in the market and in regulation'. It is stitched together from industry statistics (ICI), household wealth statistics (Federal Reserve Survey of Consumer Finances and Financial Accounts Z.1), vendor methodologies (Morningstar flows, Star, Medalist and Sustainability ratings; LSEG Lipper Leaders; ISS Market Intelligence Simfund; Broadridge; Cerulli; Nasdaq eVestment) and public filings and disclosures (SEC Form ADV and Form CRS, fund prospectus fee tables under Form N-1A, DOL Form 5500, FINRA BrokerCheck). Use it as a starting point for a market-intelligence data mart, a data catalog or a business glossary."),
  ("Scope", "In scope: industry flow and asset dataset profiles, releases, revisions and observations (taking over the light 06 TX-MKT subdomain at consolidation) and external category mapping; market share definitions, records (MSH-) and league-table rankings, with the firm's numerator a Derived copy of the 06 certified measures; competitor profiles (CPF-) of brokerages, robo and hybrid advisers, wirehouses, RIA aggregators, recordkeepers, fund and ETF sponsors, bank wealth managers and trust companies, with their metrics, channel presence, strategic events (CEV-) and senior personnel moves; competitor offerings (COFF-) and competitor pricing observations (advisory fee rates, subscription fees, commissions, options contract fees, account service fees, margin rates, cash sweep yields, expense ratios); peer universes (PEER-), peer funds (PFD-) and peer metric snapshots; third-party ratings and awards for own and peer funds (Morningstar Star, Medalist and Sustainability ratings, Lipper Leaders, industry awards; RTG-, AWD-); fee and price benchmarking (FBS-) of share classes, advice programs and fee schedules, and pricing inputs; market sizing (MSZ-) by investor segment, wealth and age band, channel, geography and workplace plan market, thin opportunity potential for intermediary firms (IC) and plan market records from Form 5500; market research reports (MRR-) and trends (TRD-); institutional and OCIO mandate search events (MSE-) and aggregated win/loss analysis (IA, IC); news and regulatory horizon items (MIN-); the redistribution flag of each licensed dataset. Out of scope (referenced by ID only): own strategies, products, share classes, fund expense terms and service offerings (01, STR-/PRD-/SHC-/OFFR-); competitors, providers, plans, asset owners and individuals as parties, and client segment schemes (02, PTY-); the firm's certified Client Assets, Net New Assets and fund flow measures (06, MSR-), loads (06, LOAD-); client fee schedules (47, CLFEE-); intermediary firm, consultant and opportunity profiles (05: Distributor Firm, Consultant Profile, Sales Opportunity OPP-); compliance approval of rating and award citations (08, REV-); geography (09, GEO-); licensed datasets and license terms (14, DSET-/DLA-); pricing scenarios (10, PRSC-); product business cases (36); regulatory change management (38, REGCH-); due diligence of third-party funds on the platform (52)."),
  ("Structure", "Four levels: Data Domain > Data Family > Data Business Object > Data Business Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Licensed Dataset (DSET-, 14) -> Industry Dataset Profile (methodology, grain, estimation basis; Redistribution Restriction) -> Industry Data Release (IDR-, as-of date, revision) -> Industry Flow Observation at a grain (category x channel x vehicle x market x distributor firm x fund) -> mapped to own Share Classes (SHC-, 01) via Category Mapping -> Market Share Record (MSH-) under a Market Share Definition, whose firm numerator is a Derived copy of the 06 certified measure (MSR-). Competitor Profile (CPF-, on a 02 PTY- party) -> Competitor Metric Snapshot and Distribution Footprint, Competitor Offering (COFF-) -> Competitor Pricing Observation (offering x price component x as-of), Competitor Events (CEV-) and Personnel Moves. Peer Universe (PEER-) -> members = own share classes (SHC-) and Peer Funds (PFD-) -> Peer Metric Snapshots; Rating Observations (RTG-) and Awards (AWD-) for own and peer funds. Fee Benchmark Study (FBS-) compares an own share class, Service Offering (OFFR-) or Fee Schedule (CLFEE-, 47) with a peer universe or competitor offerings -> Fee Benchmark Result and Pricing Input, read by 10 Pricing Scenario (PRSC-) and 36 Business Case Market Evidence. Market Sizing Records (MSZ-) size segments, channels and plan markets; Plan Market Records hold Form 5500 data. Mandate Search Events (MSE-) and Win/Loss Analyses summarize institutional searches and the 05 opportunity outcomes. Market Research Reports (MRR-), Market Trends (TRD-) and Intelligence Items (MIN-) with Regulatory Horizon Items carry qualitative intelligence; 38 Regulatory Change Item cites the horizon item."),
  ("Design principles", "1) Market, not the firm (CW-160): this domain holds external observations; the firm's own values in a share, benchmark or wallet-share record are Derived copies from 06, 01 or 47 with their as-of dates, never re-mastered. 2) Separate the dataset (license and catalog in 14) from its analytical profile (methodology here) and from each release (as-of date and revision), so restated vendor history is never silently overwritten. 3) Every flow, share, price and sizing value states its basis (reported, estimated, modeled), grain, source and as-of date. 4) Define market share once: numerator, denominator, measure basis and scope at the same grain. 5) One rating model for own and peer funds. 6) Competitors and individuals are 02 parties; examples use hypothetical firm names (Northbridge Brokerage, Example Digital Advisers, Example Global Investors) and no real firm's data. 7) Peer data is not due diligence: a third-party fund on the platform is vetted in 52; 11 holds its peer metrics only. 8) Respect vendor licenses: store vendor values with their dataset (14) and the redistribution flag the Marketing Rule check needs. 9) Flag Critical Data Elements (CDE)."),
  ("Applies To", "Shows the record type each attribute is held on: Dataset Profile, Data Release, Flow Observation, Category Mapping, Share Definition, Share Record, Ranking, Competitor Profile, Competitor Metric, Footprint, Competitor Offering, Pricing Observation, Competitor Event, Personnel Move, Peer Universe, Universe Member, Peer Fund, Peer Snapshot, Rating Scheme, Rating Observation, Award, Fee Study, Fee Result, Pricing Input, Sizing Record, Opportunity Potential, Plan Market, Research Report, Market Trend, Search Event, Win/Loss Analysis, Intelligence Item, Regulatory Item or Redistribution Restriction. Fee statistics are Decimal values in the study's Measure Unit."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify a record, compute or explain market share, sizing, a competitor price or peer position, or to cite a rating or award correctly. Confirm with data owners."),
  ("Primary / Secondary Reference", "Standard or source the attribute definition is aligned to. Vendor references (Morningstar, LSEG Lipper, ISS Market Intelligence, Broadridge, Cerulli, Nasdaq eVestment, Discovery Data) indicate where the data is usually sourced and how the vendor defines it; they are not a license to reproduce vendor data. 'Internal' = firm-defined; there is no authoritative external definition."),
  ("Notes", "PII = personal information under the GLBA, Regulation S-P and US state privacy laws. Only Competitor Personnel Move holds personal data (PII - identity: the 02 party of a competitor executive or portfolio manager). Every other object is No PII; Opportunity Potential is held at intermediary firm level only. The firm's own client data is never held here."),
  ("Tabs", "Hierarchy: families, object groups and objects with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: object-level cardinalities, including references to other Data Domains | Sources: statistics, filings, rules and vendor methodologies used, with links."),
  ("Suggested next steps", "1) Validate with Corporate Strategy and Market Intelligence, Product and Pricing, Advice and Brokerage product owners, Workplace Sales, Institutional Sales and Compliance (rating and award citations). 2) Agree with 14 the split between the dataset catalog and license (DSET-, DLA-) and the 11 dataset profile and redistribution flag; inventory current subscriptions (Morningstar Direct, Simfund, Broadridge, Cerulli, eVestment, Discovery Data). 3) Agree with 06 the certified measures (MSR-) used as market share numerators, and with 47 and 01 the fee values copied into fee studies. 4) Agree with 10 and 36 how Pricing Scenario and Business Case Market Evidence read Competitor Pricing Observation and Fee Benchmark Result (CW-158). 5) Agree with 05 the Sales Opportunity, Distributor Firm and Consultant Profile references (CW-170). 6) Define the competitor set and the monthly price-capture routine. 7) Map attributes to source systems and extend code lists to firm values. 8) Turn the Relationships tab into a logical data model."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Industry Flow & Asset Data", "MI-FLW",
  "Analytical profiles, releases and observations of external industry flow and asset datasets (ICI, Morningstar, ISS Market Intelligence Simfund, Broadridge, Cerulli) for US mutual funds, ETFs, CITs and managed accounts, used for market sizing, share and trend analysis. Takes over 06 TX-MKT at consolidation.",
  [
   ("Industry Dataset Profile", "Methodology and coverage profile of each industry dataset, keyed to the licensed dataset cataloged in 14.", [
     ("Industry Dataset Profile", [
       ("Licensed Dataset", "Dataset in the 14 Third-Party Data catalog that this profile describes; carries publisher, license and entitlements.", "Dataset Profile", "Reference (Dataset)", "", "DSET-00042", "Internal", "", "Y", "No PII. Replaces 06 'Industry Dataset ID' (IND-)."),
       ("Dataset Family", "Type of industry statistic the dataset provides.", "Dataset Profile", "Code", "Industry Dataset Family", "Industry Flow Statistics", "Internal", "", ""),
       ("Industry Data Provider", "Organization compiling the data (trade association, vendor or public agency).", "Dataset Profile", "Code", "Industry Data Provider", "ICI", "Internal", "", "", "Provider party held in 02 via the 14 vendor record."),
       ("Flow Estimation Method", "Whether flows are reported by funds, estimated from assets and returns, or modeled.", "Dataset Profile", "Code", "Flow Estimation Method", "Estimated from TNA and Return", "Morningstar", "ICI", "", "Replaces 06 'Flow Methodology'."),
       ("Reinvested Distribution Treatment", "Whether reinvested dividends and capital gains are counted in flows (Y = included, N = treated as market movement).", "Dataset Profile", "Boolean", "", "N", "ICI", "Morningstar", ""),
       ("Category Scheme", "Classification used to group funds in the dataset.", "Dataset Profile", "Code", "Category Scheme", "Morningstar Category", "ICI", "LSEG Lipper", "", "Moves from 06."),
       ("Lowest Grain Available", "Finest level at which the dataset reports values.", "Dataset Profile", "Code (multi)", "Data Grain", "Share Class; Distributor Firm", "ISS Market Intelligence", "Broadridge", ""),
       ("Vehicles Covered", "Vehicle types included in the dataset.", "Dataset Profile", "Code (multi)", "Industry Vehicle Type", "Mutual Fund; ETF; CIT", "ISS Market Intelligence", "ICI", ""),
       ("Coverage Basis", "Whether the dataset attributes values by fund domicile, by reporting distributor, by investor residence or by filer.", "Dataset Profile", "Code", "Coverage Basis", "Fund Domicile", "ICI", "ISS Market Intelligence", ""),
       ("Publication Frequency", "How often the provider publishes the dataset.", "Dataset Profile", "Code", "Frequency", "Weekly", "ICI", "", ""),
       ("Revision Policy", "How the provider restates prior periods (rolling revisions, annual rebase, none).", "Dataset Profile", "Code", "Revision Policy", "Rolling Prior-Period Revisions", "ICI", "", ""),
     ]),
   ]),
   ("Industry Data Release", "Each published vintage of a dataset, so that revisions can be compared and analyses reproduced.", [
     ("Industry Data Release", [
       ("Data Release ID", "Unique identifier of the dataset release or vintage.", "Data Release", "Identifier", "", "IDR-ICI-WK-20260923", "Internal", "", "Y", "No PII."),
       ("As-of Date", "Period-end date the values relate to.", "Data Release", "Date", "ISO 8601", "2026-09-23", "ICI", "Morningstar", "Y"),
       ("Publication Date", "Date the provider published the release.", "Data Release", "Date", "ISO 8601", "2026-10-01", "Internal", "", ""),
       ("Release Status", "Whether the release is preliminary, final or revised.", "Data Release", "Code", "Release Status", "Preliminary", "ICI", "", ""),
       ("Supersedes Release", "Earlier release this vintage revises.", "Data Release", "Reference (Data Release)", "", "IDR-ICI-WK-20260916", "Internal", "", ""),
       ("Source Load", "Load (owned by 06) that brought the release into the data platform.", "Data Release", "Reference (Load)", "", "LOAD-20261001-FEED041-01", "Internal", "", ""),
     ]),
   ]),
   ("Industry Flow & Asset Observation", "A flow or asset value at a stated grain from a given release.", [
     ("Industry Flow Observation", [
       ("Data Release", "Release the observation belongs to.", "Flow Observation", "Reference (Data Release)", "", "IDR-SIMF-M-202608", "Internal", "", "", "No PII."),
       ("Industry Category", "Category value in the dataset's scheme.", "Flow Observation", "Code", "External (Vendor)", "Morningstar US Large Growth", "Morningstar", "ICI", "Y", "Moves from 06."),
       ("Distribution Channel", "Channel of the observation, where the dataset splits flows or assets by channel (direct, workplace, institutional or an intermediary sub-channel).", "Flow Observation", "Code", "Industry Channel", "Intermediary - RIA", "Cerulli", "Broadridge", ""),
       ("Vehicle Type", "Vehicle type of the observation.", "Flow Observation", "Code", "Industry Vehicle Type", "ETF", "ISS Market Intelligence", "ICI", ""),
       ("Region / Market", "Country of the observation per Coverage Basis: the United States for the firm's market, a foreign domicile only for peers of the firm's international funds.", "Flow Observation", "Code", "ISO 3166-1 alpha-2", "US", "ICI", "", ""),
       ("Distributor Firm", "Intermediary distributor firm (05 profile of a 02 party), where the dataset reports at firm level (IC).", "Flow Observation", "Reference (Distributor Firm, 05)", "", "PTY-100245", "Broadridge", "", ""),
       ("Fund Manager Firm", "Fund sponsor or asset manager whose funds the observation covers (own firm or competitor).", "Flow Observation", "Reference (Competitor Profile)", "", "CPF-0112", "ISS Market Intelligence", "", ""),
       ("Fund / Share Class", "Peer fund or own share class, where the observation is at fund level.", "Flow Observation", "Reference (Peer Fund / Share Class)", "", "PFD-0045871", "Morningstar", "", ""),
       ("Gross Sales", "Industry gross sales at the grain, where reported.", "Flow Observation", "Amount", "", "USD 18.2bn", "ICI", "ISS Market Intelligence", ""),
       ("Redemptions", "Industry redemptions at the grain, where reported.", "Flow Observation", "Amount", "", "USD 22.3bn", "ICI", "ISS Market Intelligence", ""),
       ("Net Flow", "Net new cash flow, net sales or estimated net flow at the grain.", "Flow Observation", "Amount", "", "USD -4.1bn", "ICI", "ISS Market Intelligence", "Y", "Moves from 06 'Industry Net Flow'."),
       ("Ending Assets", "Total net assets at period end.", "Flow Observation", "Amount", "", "USD 1.92tn", "ICI", "Morningstar", "Y", "Moves from 06 'Industry Assets'."),
       ("Observation Currency", "Currency of the amounts.", "Flow Observation", "Code", "ISO 4217", "USD", "Internal", "", ""),
       ("Value Basis", "Whether the value is reported, estimated or modeled.", "Flow Observation", "Code", "Value Basis", "Estimated", "Morningstar", "", "Y"),
     ]),
   ]),
   ("Category Mapping", "Mapping of external category values to own share classes and to the firm's internal market segments, used to build market share numerators.", [
     ("Category Mapping", [
       ("Category Scheme", "External scheme being mapped.", "Category Mapping", "Code", "Category Scheme", "Lipper Global Classification", "Internal", "", "", "No PII."),
       ("External Category Value", "Category value in the external scheme.", "Category Mapping", "Code", "External (Vendor)", "Equity Global", "LSEG Lipper", "", "Y"),
       ("Mapped Share Class", "Own share class mapped into the category; own-fund category assignment itself is held in 01.", "Category Mapping", "Reference (Share Class)", "", "SHC-004512", "Internal", "", "Y", "Moves from 06 'Firm Products Mapped'."),
       ("Internal Market Segment", "Firm market segment the category rolls up to for share reporting.", "Category Mapping", "Code", "Firm-defined", "US Equity - Large Growth", "Internal", "", ""),
       ("Mapping Effective From", "Date the mapping becomes valid.", "Category Mapping", "Date", "ISO 8601", "2026-01-31", "Internal", "", ""),
       ("Mapping Effective To", "Date the mapping ends, if applicable.", "Category Mapping", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Market Share", "MI-MSH",
  "Certified definitions and stored results of the firm's market share by category, channel (direct, advice, workplace, institutional and intermediary), vehicle and investor segment, and industry league-table rankings. The firm's own value is a Derived copy of the 06 certified measure or of the same industry dataset.",
  [
   ("Market Share Definition", "How each market share measure is calculated, so all reports compute share the same way.", [
     ("Market Share Definition", [
       ("Share Definition Code", "Unique code of the market share definition.", "Share Definition", "Identifier", "", "MSHD-NN-DIGAD-US", "Internal", "", "Y", "No PII."),
       ("Share Definition Name", "Business name of the measure.", "Share Definition", "Text", "", "US Digital Advice Net New Asset Share", "Internal", "", ""),
       ("Share Measure Basis", "What is being shared: assets, gross sales, net flows or net new assets.", "Share Definition", "Code", "Share Measure Basis", "Net New Assets", "Broadridge", "ISS Market Intelligence", "Y"),
       ("Share Dimension", "Dimension by which share is cut.", "Share Definition", "Code (multi)", "Share Dimension", "Channel; Wealth Band", "Internal", "", ""),
       ("Numerator Source", "Source of the firm's own value: a 06 certified measure (Client Assets, Net New Assets or fund flows) or the same industry dataset as the denominator.", "Share Definition", "Code", "Numerator Source", "06 Certified Measure", "Internal", "", "Y", "Same-source numerators avoid basis mismatch."),
       ("Denominator Dataset", "Licensed industry dataset (14) supplying the denominator.", "Share Definition", "Reference (Dataset)", "", "DSET-00042", "Internal", "", ""),
       ("Calculation Formula", "Formula for share, including treatment of negative denominators for flow share.", "Share Definition", "Text", "", "Firm net new assets / industry net new assets of the channel (share of inflows when the industry total is negative)", "Internal", "", ""),
       ("Negative Flow Treatment", "How share is expressed when industry or firm flows are negative.", "Share Definition", "Code", "Negative Flow Treatment", "Report Not Meaningful", "Internal", "", ""),
     ]),
   ]),
   ("Market Share Record", "Stored share results at a grain and period.", [
     ("Market Share Record", [
       ("Market Share Record ID", "Unique identifier of the share result.", "Share Record", "Identifier", "", "MSH-2026-08-000981", "Internal", "", "Y", "No PII."),
       ("Share Definition", "Definition the result is computed under.", "Share Record", "Reference (Share Definition)", "", "MSHD-NN-DIGAD-US", "Internal", "", "Y"),
       ("Period End Date", "Period end of the result.", "Share Record", "Date", "ISO 8601", "2026-08-31", "Internal", "", "Y"),
       ("Period Type", "Length of the measurement period.", "Share Record", "Code", "Period Type", "Trailing 12 Months", "Internal", "", ""),
       ("Category / Segment", "Category or internal segment value of the result.", "Share Record", "Code", "External (Vendor)", "Morningstar US Large Growth", "Morningstar", "", ""),
       ("Channel", "Channel of the result, where cut by channel.", "Share Record", "Code", "Industry Channel", "Direct - Digital Advice", "Cerulli", "", ""),
       ("Distributor Firm", "Intermediary distributor firm (05), where share is measured within a firm's category sales (IC).", "Share Record", "Reference (Distributor Firm, 05)", "", "PTY-100245", "Broadridge", "", ""),
       ("Region / Market", "Country of the result; the United States for the firm's market.", "Share Record", "Code", "ISO 3166-1 alpha-2", "US", "Internal", "", ""),
       ("Vehicle Type", "Vehicle of the result.", "Share Record", "Code", "Industry Vehicle Type", "Mutual Fund", "Internal", "", ""),
       ("Firm Value", "Firm numerator value as of the period end, copied from the 06 certified measure value or from the same industry dataset.", "Share Record", "Amount", "", "USD 412m", "Internal", "", "Y", "Derived copy of 06 Measure Value when Numerator Source = 06 Certified Measure (CW-160)."),
       ("Industry Value", "Industry denominator value.", "Share Record", "Amount", "", "USD 17.2bn", "Internal", "", "Y"),
       ("Market Share", "Firm value as a percentage of industry value.", "Share Record", "Percentage", "", "2.40%", "Broadridge", "ISS Market Intelligence", "Y", "Replaces 06 TX-MEA 'Market Share' measure."),
     ]),
   ]),
   ("Industry Rankings", "League-table positions of the firm and competitors by assets, flows or clients.", [
     ("Industry Ranking", [
       ("Ranked Firm", "Competitor profile (or own-firm profile) ranked.", "Ranking", "Reference (Competitor Profile)", "", "CPF-0001", "Internal", "", "", "No PII. The table's measure basis and period are the parent Market Share Record's."),
       ("Rank Position", "Position in the table.", "Ranking", "Integer", "", "4", "Internal", "", "Y"),
       ("Ranking Universe", "Scope of the table (market, channel, vehicle, category).", "Ranking", "Text", "", "US digital advice providers by assets, 2025", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Competitor Intelligence", "MI-CMP",
  "Profiles of competing direct brokerages, robo and hybrid advisers, wirehouses, RIA aggregators, workplace recordkeepers, fund and ETF sponsors, bank wealth managers and trust companies: their size and growth, channel presence, the offerings they sell and what they charge, strategic moves and senior personnel changes. The competitor is a 02 party; this domain holds the competitive view of it.",
  [
   ("Competitor Profile", "The firm's analytical record of a competing firm or group.", [
     ("Competitor Profile", [
       ("Competitor Profile ID", "Unique identifier of the competitor profile.", "Competitor Profile", "Identifier", "", "CPF-0112", "Internal", "", "Y", "No PII."),
       ("Competitor Party", "Party (02) of the competitor's ultimate parent or group; its name, domicile and hierarchy are read from 02.", "Competitor Profile", "Reference (Party)", "", "PTY-400877", "Internal", "", "Y"),
       ("Competitor Display Name", "Short name used in analysis, taken from the 02 party name.", "Competitor Profile", "Text", "", "Northbridge Brokerage", "Internal", "", ""),
       ("Competitor Tier", "Strategic importance of the competitor to the firm.", "Competitor Profile", "Code", "Competitor Tier", "Primary", "Internal", "", ""),
       ("Competitor Type", "Business model of the competitor.", "Competitor Profile", "Code", "Competitor Type", "Direct Brokerage", "Internal", "Cerulli", ""),
       ("Vendor Manager Identifiers", "Codes of the competitor in licensed vendor datasets (Morningstar BrandingId, Simfund manager code, eVestment firm ID), held here under the 14 license.", "Competitor Profile", "Text", "External (Vendor)", "Morningstar BN00000XXX", "Morningstar", "ISS Market Intelligence", "", "Vendor codes are mastered here; their use is governed by the 14 license."),
       ("Regulatory Identifiers", "SEC file and CRD numbers of the competitor's registered entities, copied from the 02 US Regulatory Identifiers of the party.", "Competitor Profile", "Text", "", "CRD 000000; SEC 801-00000", "SEC Form ADV", "FINRA BrokerCheck", "", "Derived copy of 02."),
       ("Competing Strategies", "Own strategies against which the competitor's funds are most often compared.", "Competitor Profile", "Reference (Strategy) (multi)", "", "STR-00123; STR-00456", "Internal", "", ""),
     ]),
   ]),
   ("Competitor Metrics", "Periodic size, growth and product-range metrics of the competitor, as the competitor or a vendor reports them.", [
     ("Competitor Metric Snapshot", [
       ("As-of Date", "Date the metrics relate to.", "Competitor Metric", "Date", "ISO 8601", "2026-06-30", "Internal", "", "Y", "No PII."),
       ("Total AUM", "Competitor's assets under management (Form ADV Item 5.F regulatory assets under management for US advisers, or fund sponsor assets).", "Competitor Metric", "Amount", "", "USD 640bn", "SEC Form ADV", "ISS Market Intelligence", "Y"),
       ("Reported Client Assets", "Total client assets the competitor reports (brokerage, advisory and plan assets), on the competitor's own definition; not the 06 Client Assets measure.", "Competitor Metric", "Amount", "", "USD 1.4tn", "Internal", "", "", "Read from earnings disclosures and filings; definitions differ by firm."),
       ("Reported Net New Assets", "Net new client assets the competitor reports for the period ending at the as-of date, on its own definition.", "Competitor Metric", "Amount", "", "USD 21.6bn", "Internal", "", ""),
       ("Client Account Count", "Number of client accounts the competitor reports.", "Competitor Metric", "Integer", "", "9800000", "Internal", "", ""),
       ("Advisor Count", "Number of financial advisors or investment adviser representatives the competitor reports or registers.", "Competitor Metric", "Integer", "", "2150", "FINRA BrokerCheck", "SEC Form ADV", ""),
       ("Trailing 12-Month Net Flows", "Estimated net flows into the competitor's funds and ETFs over the last 12 months.", "Competitor Metric", "Amount", "", "USD 4.2bn", "Morningstar", "ISS Market Intelligence", ""),
       ("Asset-Weighted Expense Ratio", "Asset-weighted average net expense ratio of the competitor's funds and ETFs.", "Competitor Metric", "Percentage", "", "0.48%", "Morningstar", "Morningstar US Fund Fee Study", ""),
     ]),
   ]),
   ("Distribution Footprint", "Where and how the competitor reaches clients, by channel.", [
     ("Competitor Distribution Footprint", [
       ("Channel", "Channel in which the competitor is active.", "Footprint", "Code", "Industry Channel", "Direct - Human Advice", "Cerulli", "", "Y", "No PII."),
       ("Presence Strength", "Assessed strength of presence in the channel.", "Footprint", "Code", "Presence Strength", "Strong", "Internal", "", ""),
       ("Estimated Advisor Headcount", "Estimated number of advisors or representatives serving clients in the channel.", "Footprint", "Integer", "", "140", "FINRA BrokerCheck", "Cerulli", "", "Replaces the wholesale Estimated Wholesaler Headcount (CW-160)."),
       ("Key Distribution Partners", "Intermediary firms (05) where the competitor has known placements or partnerships (IC).", "Footprint", "Reference (Distributor Firm, 05) (multi)", "", "PTY-100245; PTY-100311", "Internal", "", ""),
     ]),
   ]),
   ("Competitor Offerings & Pricing", "What competitors sell to investors and what they charge for it, captured from public schedules and disclosure documents (CW-160).", [
     ("Competitor Offering", [
       ("Competitor Offering ID", "Unique identifier of the competitor offering.", "Competitor Offering", "Identifier", "", "COFF-00213", "Internal", "", "Y", "No PII."),
       ("Offering Competitor", "Competitor profile of the firm that sells the offering.", "Competitor Offering", "Reference (Competitor Profile)", "", "CPF-0112", "Internal", "", "Y"),
       ("Competitor Offering Name", "Name of the offering as the competitor markets it.", "Competitor Offering", "Text", "", "Example Digital Advisers Core Portfolios", "Internal", "", ""),
       ("Competitor Offering Type", "Kind of offering (brokerage, digital, hybrid or human advice, recordkeeping, cash, trust, fund or ETF range).", "Competitor Offering", "Code", "Competitor Offering Type", "Digital Advice", "Internal", "SEC Form CRS", ""),
       ("Contested Business Line", "Business line of the firm the offering competes with (CW-004).", "Competitor Offering", "Code", "Business Line", "DA", "Internal", "", ""),
       ("Account Minimum", "Minimum investment or balance to open or enroll.", "Competitor Offering", "Amount", "", "USD 3,000", "SEC Form ADV Part 2A", "", ""),
       ("Offering Features", "Features the offering provides (tax-loss harvesting, rebalancing, advisor access, fractional shares).", "Competitor Offering", "Code (multi)", "Offering Feature", "Tax-Loss Harvesting; Automatic Rebalancing", "Internal", "", ""),
       ("Comparable Own Offering", "Own 01 Service Offering the competitor offering is compared with.", "Competitor Offering", "Reference (Service Offering)", "", "OFFR-0012", "Internal", "", ""),
       ("Offering Status", "Whether the offering is announced, active, closed to new clients or discontinued.", "Competitor Offering", "Code", "Competitor Offering Status", "Active", "Internal", "", ""),
     ]),
     ("Competitor Pricing Observation", [
       ("Priced Offering", "Competitor offering the price applies to.", "Pricing Observation", "Reference (Competitor Offering)", "", "COFF-00213", "Internal", "", "Y", "No PII. Key: COFF- / Price Component / Observation As-of Date [/ Balance Tier Lower Bound when tiered] (KEY_FORMATS)."),
       ("Price Component", "Component of price observed (advisory fee rate, commission, account fee, margin rate, cash sweep yield, expense ratio).", "Pricing Observation", "Code", "Price Component", "Advisory Fee Rate", "SEC Form ADV Part 2A", "SEC Form N-1A", "Y"),
       ("Observation As-of Date", "Date on which the price was in effect as observed.", "Pricing Observation", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
       ("Observed Rate", "Rate or yield of the component (annual fee rate, expense ratio, margin rate, cash sweep yield), where the component is a rate.", "Pricing Observation", "Percentage", "", "0.25%", "SEC Form ADV Part 2A", "", "Y"),
       ("Observed Amount", "Flat amount of the component (per-trade commission, per-contract fee, account service fee, subscription fee), where the component is an amount.", "Pricing Observation", "Amount", "", "USD 0.65", "Internal", "", "Y"),
       ("Price Quote Basis", "Unit in which the price is quoted (annual percentage of assets, per trade, per contract, per month, annual percentage yield).", "Pricing Observation", "Code", "Price Quote Basis", "Annual Percentage of Assets", "Internal", "", ""),
       ("Balance Tier Lower Bound", "Lower bound of the asset or balance tier the price applies to; set only when the price is tiered, and then part of the key.", "Pricing Observation", "Amount", "", "USD 1,000,000", "SEC Form ADV Part 2A", "", "Y", "Untiered prices leave it blank; the tier's upper bound is the next tier's lower bound."),
       ("Price Source Type", "Kind of document or dataset the price was captured from.", "Pricing Observation", "Code", "Pricing Source Type", "Form ADV Part 2A / Appendix 1", "Internal", "", ""),
       ("Source Document Reference", "Citation of the document, page or dataset the price was taken from, with its capture date.", "Pricing Observation", "Text", "", "Example Digital Advisers Form ADV Part 2A Appendix 1, 2026-03-28, Item 4", "Internal", "", ""),
     ]),
   ]),
   ("Competitor Strategic Events", "Material moves by competitors: launches, closures, price and cash yield changes, M&A, partnerships, market entries.", [
     ("Competitor Event", [
       ("Competitor Event ID", "Unique identifier of the event.", "Competitor Event", "Identifier", "", "CEV-2026-00412", "Internal", "", "Y", "No PII."),
       ("Competitor", "Competitor the event relates to.", "Competitor Event", "Reference (Competitor Profile)", "", "CPF-0112", "Internal", "", "Y"),
       ("Event Type", "Kind of strategic move.", "Competitor Event", "Code", "Competitor Event Type", "Cash Yield Change", "Internal", "", "Y"),
       ("Event Date", "Date the event was announced or became effective.", "Competitor Event", "Date", "ISO 8601", "2026-09-02", "Internal", "", "Y"),
       ("Affected Peer Funds", "Competitor funds affected by the event.", "Competitor Event", "Reference (Peer Fund) (multi)", "", "PFD-0045871", "Internal", "", ""),
       ("Assessed Impact", "Firm's assessment of impact on its own business.", "Competitor Event", "Code", "Impact Level", "Medium", "Internal", "", ""),
     ]),
   ]),
   ("Key Personnel Moves", "Hires and departures of senior executives and portfolio managers at competitors.", [
     ("Competitor Personnel Move", [
       ("Individual", "Party (02) of the person who moved.", "Personnel Move", "Reference (Party)", "", "PTY-901234", "Internal", "", "Y", "Object PII tier: PII - identity. PII."),
       ("Role", "Role of the individual.", "Personnel Move", "Code", "Personnel Role", "Portfolio Manager", "Internal", "", "", "PII."),
       ("Move Type", "Nature of the move.", "Personnel Move", "Code", "Personnel Move Type", "Departure", "Internal", "", "", "PII."),
       ("From Competitor", "Firm the individual left.", "Personnel Move", "Reference (Competitor Profile)", "", "CPF-0112", "Internal", "", "", "PII."),
       ("To Competitor", "Firm the individual joined, if known.", "Personnel Move", "Reference (Competitor Profile)", "", "CPF-0230", "Internal", "", "", "PII."),
       ("Move Date", "Date of the announcement.", "Personnel Move", "Date", "ISO 8601", "2026-07-21", "Internal", "", "Y", "PII."),
       ("Affected Strategies / Funds", "Peer funds the individual managed.", "Personnel Move", "Reference (Peer Fund) (multi)", "", "PFD-0045871", "Morningstar", "", "", "Manager moves drive Medalist People pillar changes. PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Peer Universes & Peer Funds", "MI-PEER",
  "Peer group definitions (vendor categories and custom peer sets), the non-firm funds in them, and periodic snapshots of peer performance, rank, fees, assets and flows. Peer data is not due diligence: a third-party fund on the platform is vetted in 52.",
  [
   ("Peer Universe", "Definition of a set of funds against which own products are compared.", [
     ("Peer Universe", [
       ("Peer Universe ID", "Unique identifier of the peer universe.", "Peer Universe", "Identifier", "", "PEER-0031", "Internal", "", "Y", "No PII."),
       ("Peer Universe Name", "Name of the universe.", "Peer Universe", "Text", "", "US Fund Large Growth - Clean Classes", "Internal", "", ""),
       ("Universe Type", "Whether the universe is a vendor category, a consultant universe or a custom set.", "Peer Universe", "Code", "Peer Universe Type", "Vendor Category", "Morningstar", "LSEG Lipper", ""),
       ("Base Category Scheme", "Vendor scheme the universe is based on, if any.", "Peer Universe", "Code", "Category Scheme", "Morningstar Category", "Morningstar", "", ""),
       ("Base Category Value", "Vendor category value.", "Peer Universe", "Code", "External (Vendor)", "Large Growth", "Morningstar", "", ""),
       ("Inclusion Rules", "Rules applied on top of the base category (share class type, domicile, minimum assets, active only, oldest share class).", "Peer Universe", "Text", "", "Active only; oldest clean class per fund; assets > USD 50m; US-domiciled open-end funds and ETFs", "Internal", "", ""),
       ("Representative Share Class Rule", "How one share class per fund is chosen for comparison.", "Peer Universe", "Code", "Representative Class Rule", "Oldest Share Class", "Morningstar", "", ""),
       ("Own Strategy Compared", "Own strategy the universe is primarily used for.", "Peer Universe", "Reference (Strategy)", "", "STR-00123", "Internal", "", ""),
       ("Universe Effective From", "Date the definition becomes valid.", "Peer Universe", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Universe Effective To", "Date the definition ends.", "Peer Universe", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Peer Universe Member", [
       ("Member Fund", "Peer fund or own share class in the universe.", "Universe Member", "Reference (Peer Fund / Share Class)", "", "PFD-0045871", "Internal", "", "Y", "No PII."),
       ("Manual Override Indicator", "Whether membership was forced in or out by an analyst.", "Universe Member", "Boolean", "", "N", "Internal", "", ""),
     ]),
   ]),
   ("Peer Fund", "Non-firm funds and share classes tracked for comparison. Own funds stay in 01.", [
     ("Peer Fund", [
       ("Peer Fund ID", "Unique internal identifier of the peer fund or share class.", "Peer Fund", "Identifier", "", "PFD-0045871", "Internal", "", "Y", "No PII. Never an own fund (own funds are SHC-, 01)."),
       ("Peer Fund Name", "Name of the fund and share class.", "Peer Fund", "Text", "", "Example Large Growth Fund Institutional Class", "Morningstar", "", ""),
       ("ISIN", "ISIN of the share class.", "Peer Fund", "Identifier", "ISO 6166", "US1234567890", "ISO 6166", "", "Y"),
       ("Ticker", "Exchange or Nasdaq fund ticker.", "Peer Fund", "Identifier", "", "EXGGX", "Internal", "", ""),
       ("Morningstar SecId", "Morningstar security identifier.", "Peer Fund", "Identifier", "External (Morningstar)", "F00000XXXX", "Morningstar", "", ""),
       ("Managing Firm", "Competitor profile of the managing firm.", "Peer Fund", "Reference (Competitor Profile)", "", "CPF-0112", "Internal", "", ""),
       ("Vehicle Type", "Vehicle type of the peer fund.", "Peer Fund", "Code", "Industry Vehicle Type", "Mutual Fund", "Internal", "", ""),
       ("Domicile", "Fund domicile; a foreign domicile only for peers of the firm's international funds.", "Peer Fund", "Code", "ISO 3166-1 alpha-2", "US", "Internal", "", ""),
       ("Peer Morningstar Category", "Morningstar category of the peer fund (own funds' category is held in 01).", "Peer Fund", "Code", "External (Morningstar)", "Large Growth", "Morningstar", "", ""),
     ]),
   ]),
   ("Peer Metric Snapshot", "Periodic metrics of each peer fund or own share class, for ranking and benchmarking.", [
     ("Peer Metric Snapshot", [
       ("Snapshot Subject", "Peer fund or own share class the metrics describe; own share class rows carry copies of 01 and 32 values (ROW_OWNERSHIP).", "Peer Snapshot", "Reference (Peer Fund / Share Class)", "", "PFD-0045871", "Internal", "", "Y", "No PII."),
       ("Snapshot Date", "Period end of the snapshot.", "Peer Snapshot", "Date", "ISO 8601", "2026-08-31", "Internal", "", "Y"),
       ("Return Period", "Period of the return.", "Peer Snapshot", "Code", "Return Period", "3 Years Annualized", "Morningstar", "", ""),
       ("Total Return", "Total return net of fees for the period.", "Peer Snapshot", "Percentage", "", "11.4%", "Morningstar", "LSEG Lipper", "Y", "Own share class rows copy the 32 Performance Return (ROW_OWNERSHIP)."),
       ("Category Percentile Rank", "Percentile rank in the universe (1 = best).", "Peer Snapshot", "Integer", "", "18", "Morningstar", "", "Y"),
       ("Quartile Rank", "Quartile in the universe.", "Peer Snapshot", "Code", "Quartile", "1st Quartile", "LSEG Lipper", "Morningstar", ""),
       ("Expense Ratio", "Net expense ratio of the share class from the prospectus fee table.", "Peer Snapshot", "Percentage", "", "0.85%", "Morningstar", "SEC Form N-1A", "Y", "Own share class rows copy the 01 Net Expense Ratio (ROW_OWNERSHIP)."),
       ("Estimated Net Flow", "Estimated net flow for the period.", "Peer Snapshot", "Amount", "", "USD -120m", "Morningstar", "", ""),
       ("Peer Universe", "Universe in which the rank was computed.", "Peer Snapshot", "Reference (Peer Universe)", "", "PEER-0031", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Ratings & Awards", "MI-RAT",
  "Third-party published fund and ESG ratings and industry awards for own and peer funds and offerings: Morningstar Star, Medalist and Sustainability ratings, LSEG Lipper Leaders and industry awards, held with the context the SEC Marketing Rule requires when they are cited. Consultant ratings and partner research ratings (05) are excluded.",
  [
   ("Rating Scheme", "Reference description of each published rating scheme.", [
     ("Rating Scheme", [
       ("Rating Scheme Code", "Code of the rating scheme.", "Rating Scheme", "Code", "Rating Scheme", "Morningstar Medalist Rating", "Internal", "", "Y", "No PII."),
       ("Rated Object Type", "Whether the scheme rates share classes, funds, service offerings or firms.", "Rating Scheme", "Code", "Rated Object Type", "Share Class", "Internal", "", ""),
       ("Rebalance Frequency", "How often ratings are recalculated.", "Rating Scheme", "Code", "Frequency", "Monthly", "Morningstar", "LSEG Lipper", ""),
       ("Minimum History Required", "Track record, in months, needed for a rating.", "Rating Scheme", "Integer", "Months", "36", "Morningstar", "LSEG Lipper", ""),
     ]),
   ]),
   ("Fund Rating Observation", "A rating value assigned to an own or peer share class or fund at a date.", [
     ("Rating Observation", [
       ("Rating Observation ID", "Unique identifier of the rating observation.", "Rating Observation", "Identifier", "", "RTG-2026-08-0031277", "Internal", "", "Y", "No PII."),
       ("Rating Scheme", "Scheme the rating belongs to.", "Rating Observation", "Code", "Rating Scheme", "Morningstar Rating (Star)", "Internal", "", "Y"),
       ("Rated Share Class / Fund", "Own share class (SHC-) or peer fund (PFD-) rated.", "Rating Observation", "Reference (Share Class / Peer Fund)", "", "SHC-004512", "Internal", "", "Y"),
       ("Rating Time Period", "Period the rating covers (overall, 3, 5 or 10 years).", "Rating Observation", "Code", "External (Morningstar / LSEG Lipper)", "Overall", "Morningstar", "LSEG Lipper", "Y"),
       ("Lipper Leaders Measure", "Lipper Leaders measure rated (Lipper only).", "Rating Observation", "Code", "External (LSEG Lipper)", "Consistent Return", "LSEG Lipper", "", ""),
       ("Rating Value", "Rating on the scheme's own scale (stars, medal, globes, Lipper score 1-5).", "Rating Observation", "Code", "External (Morningstar / LSEG Lipper)", "4 Stars", "Morningstar", "LSEG Lipper", "Y"),
       ("Rating Date", "Month-end or rebalance date of the rating.", "Rating Observation", "Date", "ISO 8601", "2026-08-31", "Morningstar", "", "Y"),
       ("Number of Funds Rated in Peer Group", "Size of the peer group the rating was distributed across (required in many rating citations).", "Rating Observation", "Integer", "", "412", "Morningstar", "SEC Marketing Rule", "Y"),
       ("Rating Peer Group", "Category or classification the rating was computed within.", "Rating Observation", "Code", "External (Vendor)", "US Fund Large Growth", "Morningstar", "LSEG Lipper", ""),
     ]),
     ("Medalist Rating Detail", [
       ("People Pillar", "Morningstar People pillar score.", "Rating Observation", "Code", "External (Morningstar)", "Above Average", "Morningstar", "", "", "No PII."),
       ("Process Pillar", "Morningstar Process pillar score.", "Rating Observation", "Code", "External (Morningstar)", "High", "Morningstar", "", ""),
       ("Parent Pillar", "Morningstar Parent pillar score.", "Rating Observation", "Code", "External (Morningstar)", "Average", "Morningstar", "", ""),
       ("Price Score", "Fee impact on the rating as expressed by Morningstar (current methodology states a score from -2.5 to +2.5).", "Rating Observation", "Decimal", "", "0.5", "Morningstar", "", "", "Verify against the April 2026 methodology (confirm)."),
       ("Analyst-Driven Percentage", "Share of pillar weight assigned directly by an analyst rather than by algorithm.", "Rating Observation", "Percentage", "", "100%", "Morningstar", "", "", "Needed to label the rating as analyst or quantitative in citations."),
     ]),
     ("Sustainability Rating Detail", [
       ("Portfolio ESG Risk Score", "Asset-weighted ESG risk score of the rated fund's portfolio holdings (vendor data, not 18) used for the Morningstar Sustainability Rating.", "Rating Observation", "Decimal", "", "21.4", "Morningstar", "", "", "No PII."),
       ("Sustainability Globes", "Morningstar Sustainability Rating (1-5 globes; more globes = lower ESG risk than the Global Category).", "Rating Observation", "Integer", "", "4", "Morningstar", "", ""),
     ]),
   ]),
   ("Industry Awards", "Industry awards won or contested by own and competitor funds, offerings and firms.", [
     ("Award", [
       ("Award ID", "Unique identifier of the award record.", "Award", "Identifier", "", "AWD-2026-0045", "Internal", "", "Y", "No PII."),
       ("Award Program", "Awarding program (for example LSEG Lipper Fund Awards United States or a Morningstar award program).", "Award", "Text", "", "LSEG Lipper Fund Awards United States 2026", "Internal", "", ""),
       ("Award Category", "Category within the program.", "Award", "Text", "", "Large-Cap Growth Funds - 5 Years", "Internal", "", ""),
       ("Award Outcome", "Result achieved.", "Award", "Code", "Award Outcome", "Winner", "Internal", "", "Y"),
       ("Recipient", "Own share class, own service offering, peer fund or competitor profile that received the award.", "Award", "Reference (Share Class / Service Offering / Peer Fund / Competitor Profile)", "", "SHC-004512", "Internal", "", "Y"),
       ("Award Date", "Date the award was announced.", "Award", "Date", "ISO 8601", "2026-03-12", "Internal", "", ""),
       ("Award Data Period", "Period of data the award was based on.", "Award", "Text", "", "Five years to 2025-11-30", "SEC Marketing Rule", "", "", "Required context when citing third-party ratings."),
       ("Paid to Participate Indicator", "Whether a fee was paid to enter the program or to use the award logo.", "Award", "Boolean", "", "N", "SEC Marketing Rule", "", "", "Disclosure under SEC Marketing Rule 206(4)-1; review owned by 08."),
       ("Citation Approval", "Compliance review approving use of the rating or award in marketing.", "Award", "Reference (Compliance Review)", "", "REV-2026-008812", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Fee & Price Benchmarking", "MI-FEE",
  "Comparison of the firm's fund expenses, advice program fees and brokerage prices with peer universes and competitor offerings: fee percentiles, competitiveness assessments and pricing inputs passed to 01, 47, 10 and 36. The fund expense terms are owned by 01, the client fee schedules by 47.",
  [
   ("Fee Benchmark Study", "A fee comparison exercise for an own share class, service offering or fee schedule against a peer universe or a set of competitor offerings.", [
     ("Fee Benchmark Study", [
       ("Fee Study ID", "Unique identifier of the study.", "Fee Study", "Identifier", "", "FBS-2026-0019", "Internal", "", "Y", "No PII."),
       ("Subject Share Class", "Own share class (01) benchmarked, where the study subject is a fund.", "Fee Study", "Reference (Share Class)", "", "SHC-004512", "Internal", "", "Y", "Name kept for DP-109 and DP-183; one of Subject Share Class and Subject Service Offering is set."),
       ("Subject Service Offering", "Own service offering (01) benchmarked, where the study subject is an advice or brokerage program (CW-160).", "Fee Study", "Reference (Service Offering)", "", "OFFR-0012", "Internal", "", "Y"),
       ("Subject Fee Schedule", "Client fee schedule version (47) of the service offering benchmarked, where the subject is an offering.", "Fee Study", "Reference (Fee Schedule, 47)", "", "CLFEE-0012-07", "Internal", "", "", "Must be a 47 schedule linked to the Subject Service Offering through the 01 Offering Fee Schedule Link."),
       ("Peer Universe", "Peer universe used for a fund comparison.", "Fee Study", "Reference (Peer Universe)", "", "PEER-0031", "Internal", "", ""),
       ("Comparison Offerings", "Competitor offerings used for an advice program or brokerage price comparison.", "Fee Study", "Reference (Competitor Offering) (multi)", "", "COFF-00213; COFF-00241", "Internal", "", ""),
       ("Fee Measure Compared", "Fee measure compared.", "Fee Study", "Code", "Fee Measure", "Advisory Fee Rate", "Internal", "SEC Form N-1A", "Y"),
       ("Measure Unit", "Unit in which every statistic of the study's Fee Benchmark Result and Pricing Input is expressed (percent, basis points or currency amount), following the fee measure compared.", "Fee Study", "Code", "Measure Unit", "Percent", "Internal", "", "", ""),
       ("Study Date", "As-of date of the peer and competitor fee data.", "Fee Study", "Date", "ISO 8601", "2026-08-31", "Internal", "", "Y"),
       ("Study Purpose", "Why the study was run.", "Fee Study", "Code", "Fee Study Purpose", "Advice Program Pricing Review", "Internal", "Investment Company Act Section 15(c)", ""),
     ]),
   ]),
   ("Fee Benchmark Result", "Statistics of the peer or competitor fee distribution and the own subject's position in it.", [
     ("Fee Benchmark Result", [
       ("Own Fee Rate", "Own fee at the study date, in the study's Measure Unit: the share class net expense ratio from 01, or the program fee rate or charge from the 47 fee schedule (the effective rate at the Reference Balance when the schedule is tiered).", "Fee Result", "Decimal", "", "0.30", "Internal", "", "Y", "No PII. Derived copy: 01 or 47 per the row rule (the workbook flag shows 01). Copied for point-in-time evidence only."),
       ("Reference Balance", "Account balance at which the Own Fee Rate and the peer statistics of a tiered schedule are evaluated; blank for untiered fees.", "Fee Result", "Amount", "", "USD 250,000", "Internal", "", "", ""),
       ("Peer Median Fee", "Median fee in the universe or competitor set, in the study's Measure Unit.", "Fee Result", "Decimal", "", "0.35", "Morningstar", "", "Y"),
       ("Peer 25th Percentile Fee", "25th percentile fee (cheaper quartile boundary), in the study's Measure Unit.", "Fee Result", "Decimal", "", "0.25", "Internal", "", ""),
       ("Peer 75th Percentile Fee", "75th percentile fee, in the study's Measure Unit.", "Fee Result", "Decimal", "", "0.89", "Internal", "", ""),
       ("Own Fee Percentile", "Percentile of the own fee in the universe or competitor set (1 = cheapest).", "Fee Result", "Integer", "", "38", "Internal", "", "Y"),
       ("Fee Competitiveness Assessment", "Firm assessment of fee competitiveness.", "Fee Result", "Code", "Fee Competitiveness", "Competitive", "Internal", "", ""),
     ]),
   ]),
   ("Pricing Recommendation Input", "Market evidence passed to 01 fund pricing governance, 47 fee schedule changes, 10 Pricing Scenario and 36 proposals; it is not the approved fee.", [
     ("Pricing Input", [
       ("Recommended Fee Range Low", "Lower bound of the recommended fee range, in the study's Measure Unit.", "Pricing Input", "Decimal", "", "0.25", "Internal", "", "", "No PII."),
       ("Recommended Fee Range High", "Upper bound of the recommended fee range, in the study's Measure Unit.", "Pricing Input", "Decimal", "", "0.30", "Internal", "", ""),
       ("Rationale", "Narrative rationale, including flows, cash yield and rating effects.", "Pricing Input", "Text", "", "Competing digital programs at 0.25% or below captured most new digital advice households over two years", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Market Sizing", "MI-MSZ",
  "Size of addressable US markets by investor segment, wealth and age band, channel, geography and workplace plan market; thin opportunity potential for intermediary firms (IC); and plan market records from public Form 5500 data. Sizing values are read by 36 business cases and 10 pricing scenarios.",
  [
   ("Market Sizing Record", "A sized market segment at a stated grain, method and as-of date.", [
     ("Market Sizing Record", [
       ("Market Sizing Record ID", "Unique identifier of the sizing record.", "Sizing Record", "Identifier", "", "MSZ-2026-06-004410", "Internal", "", "Y", "No PII."),
       ("Sizing Subject Type", "What is being sized.", "Sizing Record", "Code", "Sizing Subject Type", "Wealth Band", "Internal", "", ""),
       ("Sizing Metric", "Metric of the size.", "Sizing Record", "Code", "Sizing Metric", "Investable Household Assets", "Federal Reserve SCF", "Cerulli", "Y"),
       ("Channel", "Channel of the segment.", "Sizing Record", "Code", "Industry Channel", "Direct - Human Advice", "Cerulli", "", ""),
       ("Wealth Band", "Investable-asset band of the households sized, on the 02 Net Worth Band boundaries so that it nests with the firm's client profiles.", "Sizing Record", "Code", "Net Worth Band", "USD 250,000 - 499,999", "Federal Reserve SCF", "", "", "02 bands net worth excluding the primary residence; market data bands investable assets. The boundaries match, the measures differ (stated on the record by Sizing Metric)."),
       ("Age Band", "Age band of the head of the households sized.", "Sizing Record", "Code", "External (Federal Reserve SCF)", "55-64", "Federal Reserve SCF", "", ""),
       ("Mapped Firm Segment", "02 segment value this market segment corresponds to, written as '<02 Segmentation Scheme>: <segment>' (Wealth Tier for wealth bands, Life Stage for age bands), so that market size and the firm's clients can be compared.", "Sizing Record", "Code", "Firm-defined", "Wealth Tier: Mass Affluent", "Internal", "", "", "The scheme is a 02 Segmentation Scheme value; the mapping is mastered here."),
       ("Geography", "Geographic unit (09) of the segment.", "Sizing Record", "Reference (Geographic Unit)", "", "GEO-US-CBSA-35620", "Internal", "", ""),
       ("Asset Class / Category", "Asset class or category the size relates to, if not total.", "Sizing Record", "Text", "", "Fixed Income", "Internal", "", ""),
       ("Sizing Value", "Value of the metric, in the unit the Sizing Metric implies (USD for asset metrics, a count for household, advisor and participant metrics, a percent for growth rates).", "Sizing Record", "Decimal", "", "8100000000000", "Federal Reserve SCF", "Cerulli", "Y"),
       ("Sizing Method", "How the value was produced.", "Sizing Record", "Code", "Sizing Method", "Vendor Published", "Internal", "", ""),
       ("Sizing As-of Date", "Date the value relates to.", "Sizing Record", "Date", "ISO 8601", "2025-12-31", "Internal", "", "Y"),
       ("Source Dataset", "Licensed or public dataset (14) used.", "Sizing Record", "Reference (Dataset)", "", "DSET-00057", "Internal", "", ""),
     ]),
   ]),
   ("Intermediary Firm Opportunity Potential", "Estimated opportunity at an intermediary firm or advisor (IC, thin): addressable assets and wallet share.", [
     ("Opportunity Potential", [
       ("Target Party", "Intermediary firm assessed: a 02 party holding a 05 Distributor Firm role. Advisor-level potential is a lever (section 4 of Source_Notes).", "Opportunity Potential", "Reference (Party)", "", "PTY-200998", "Internal", "", "Y", "No PII (firm-level only)."),
       ("Addressable Assets", "Portion of the intermediary firm's assets in vehicles and categories where the firm has products.", "Opportunity Potential", "Amount", "", "USD 160m", "Internal", "Broadridge", ""),
       ("Firm Assets with Party", "Own-fund assets held through the intermediary firm, copied from the 06 intermediary-held measure at the as-of date.", "Opportunity Potential", "Amount", "", "USD 6.4m", "Internal", "", ""),
       ("Wallet Share", "Firm assets with the party divided by addressable assets.", "Opportunity Potential", "Percentage", "", "4.0%", "Internal", "", "Y"),
       ("Potential As-of Date", "Date of the assessment.", "Opportunity Potential", "Date", "ISO 8601", "2026-06-30", "Internal", "", "Y"),
     ]),
   ]),
   ("Workplace Plan Market", "Sizing of the US workplace retirement plan market for the firm's recordkeeping (WR), from public Form 5500 filings.", [
     ("Plan Market Record", [
       ("Plan Party", "Retirement plan (02) sized.", "Plan Market", "Reference (Retirement Plan)", "", "PTY-350114", "DOL Form 5500", "", "Y", "No PII (plan-level public filing data)."),
       ("Form 5500 Plan Year", "Plan year of the filing used.", "Plan Market", "Integer", "", "2024", "DOL Form 5500", "", "Y"),
       ("Total Plan Assets", "Net assets at end of year from Schedule H or Form 5500-SF.", "Plan Market", "Amount", "", "USD 1.2bn", "DOL Form 5500", "", "Y"),
       ("Participant Count", "Participants with account balances at end of year as filed.", "Plan Market", "Integer", "", "8400", "DOL Form 5500", "", ""),
       ("Recordkeeper", "Recordkeeper (02 party) identified from Schedule C or vendor data.", "Plan Market", "Reference (Party)", "", "PTY-330001", "DOL Form 5500", "", ""),
       ("Recordkeeping Opportunity Value", "Estimated assets the firm could recordkeep if it won the plan (plan sponsor prospect, WR).", "Plan Market", "Amount", "", "USD 1.1bn", "Internal", "", "Y", "Replaces the wholesale DCIO Opportunity Value (CW-139: DCIO is not a channel)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Market Research & Trends", "MI-MKS",
  "Market structure research on the US retail, advice, workplace and fund markets: channel and advice-model trends, digital and hybrid advice adoption, fee and cash yield compression, vehicle shifts and wealth transfer, from Cerulli-type studies and internal analysis.",
  [
   ("Market Research Report", "Research studies purchased or produced on the market.", [
     ("Market Research Report", [
       ("Research Report ID", "Unique identifier of the report.", "Research Report", "Identifier", "", "MRR-2026-0031", "Internal", "", "Y", "No PII."),
       ("Report Title", "Title of the report.", "Research Report", "Text", "", "US Digital and Hybrid Advice Markets 2026", "Cerulli", "", ""),
       ("Research Publisher", "Publisher of the report.", "Research Report", "Code", "Industry Data Provider", "Cerulli Associates", "Internal", "", ""),
       ("Research Topics", "Topics covered.", "Research Report", "Code (multi)", "Market Topic", "Digital Advice; Fees / Pricing", "Internal", "", ""),
       ("Licensed Dataset", "License and dataset record (14) governing use and sharing.", "Research Report", "Reference (Dataset)", "", "DSET-00061", "Internal", "", ""),
     ]),
   ]),
   ("Market Trend", "Tracked structural trends and their quantified indicators.", [
     ("Market Trend", [
       ("Market Trend ID", "Unique identifier of the trend.", "Market Trend", "Identifier", "", "TRD-0012", "Internal", "", "Y", "No PII."),
       ("Trend Name", "Name of the trend.", "Market Trend", "Text", "", "Hybrid advice adoption among mass-affluent households", "Internal", "", ""),
       ("Trend Topic", "Topic of the trend.", "Market Trend", "Code", "Market Topic", "Hybrid Advice", "Internal", "", ""),
       ("Trend Indicator Metric", "Metric used to track the trend.", "Market Trend", "Text", "", "% of households with USD 100k - 1m investable assets using a hybrid advice service", "Cerulli", "", ""),
       ("Indicator Value", "Latest value of the indicator.", "Market Trend", "Decimal", "", "14", "Cerulli", "", ""),
       ("Indicator As-of Date", "Date of the indicator value.", "Market Trend", "Date", "ISO 8601", "2025-12-31", "Internal", "", ""),
       ("Trend Direction", "Direction of the trend.", "Market Trend", "Code", "Trend Direction", "Increasing", "Internal", "", ""),
       ("Implication for Firm", "Assessed implication for product, pricing or channel strategy.", "Market Trend", "Text", "", "Extend advisor access in the digital program before the next price review", "Internal", "", ""),
       ("Evidence Reports", "Research reports evidencing the trend.", "Market Trend", "Reference (Research Report) (multi)", "", "MRR-2026-0031", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Institutional Search & Win/Loss", "MI-WLI",
  "External institutional and OCIO mandate search events (hires, terminations, searches announced) for the IA line, and aggregated win/loss analysis across the firm's own institutional, intermediary and plan sponsor opportunities. The opportunities and their win / loss reasons are owned by 05.",
  [
   ("Mandate Search Event", "Publicly reported or vendor-reported institutional search, hire or termination, including competitor wins.", [
     ("Mandate Search Event", [
       ("Search Event ID", "Unique identifier of the search event.", "Search Event", "Identifier", "", "MSE-2026-007712", "Internal", "", "Y", "No PII."),
       ("Search Event Type", "Kind of event.", "Search Event", "Code", "External (Nasdaq eVestment)", "Manager Hire", "Nasdaq eVestment", "", "Y"),
       ("Asset Owner", "Institution (02 party) running the search; it need not be a client of the firm.", "Search Event", "Reference (Party)", "", "PTY-220881", "Nasdaq eVestment", "", ""),
       ("Consultant", "Investment consultant (05 Consultant Profile of a 02 party) advising on the search.", "Search Event", "Reference (Consultant Profile, 05)", "", "PTY-300112", "Nasdaq eVestment", "", ""),
       ("Mandate Asset Class", "Asset class or universe of the mandate.", "Search Event", "Code", "External (Vendor)", "Global Emerging Markets Equity", "Nasdaq eVestment", "", ""),
       ("Mandate Size", "Reported or estimated mandate size.", "Search Event", "Amount", "", "USD 250m", "Nasdaq eVestment", "", "Y"),
       ("Winning / Hired Manager", "Competitor (or own firm) hired.", "Search Event", "Reference (Competitor Profile)", "", "CPF-0230", "Nasdaq eVestment", "", "Y"),
       ("Terminated Manager", "Manager terminated, where reported.", "Search Event", "Reference (Competitor Profile)", "", "CPF-0112", "Nasdaq eVestment", "", ""),
       ("Event Date", "Date of the decision or announcement.", "Search Event", "Date", "ISO 8601", "2026-08-14", "Nasdaq eVestment", "", ""),
       ("Linked Opportunity", "Own Sales Opportunity (05) in which the firm took part.", "Search Event", "Reference (Sales Opportunity, 05)", "", "OPP-2026-01877", "Internal", "", "", "Re-typed to the restored 05 object (CW-170, CW-134)."),
     ]),
   ]),
   ("Win/Loss Analysis", "Aggregated analysis of own opportunity outcomes and external search outcomes over a period.", [
     ("Win/Loss Analysis", [
       ("Analysis Period End", "End of the analysis period.", "Win/Loss Analysis", "Date", "ISO 8601", "2026-06-30", "Internal", "", "Y", "No PII."),
       ("Analysis Segment", "Segment analyzed (asset class, opportunity type, consultant).", "Win/Loss Analysis", "Text", "", "US public plans - OCIO searches", "Internal", "", "Y"),
       ("Opportunities Decided", "Count of own opportunities with an outcome (from the 05 Win / Loss records).", "Win/Loss Analysis", "Integer", "", "24", "Internal", "", ""),
       ("Win Rate", "Wins divided by decided opportunities.", "Win/Loss Analysis", "Percentage", "", "29%", "Internal", "", "Y"),
       ("Top Loss Reasons", "Most frequent loss reasons (05 Win Loss Reason list).", "Win/Loss Analysis", "Code (multi)", "External (05 Win Loss Reason)", "Fees; Investment Performance", "Internal", "", ""),
       ("Most Frequent Winning Competitor", "Competitor winning most often in the segment.", "Win/Loss Analysis", "Reference (Competitor Profile)", "", "CPF-0230", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("News & Horizon Scanning", "MI-HZN",
  "Curated news, research and US regulatory developments relevant to the firm's markets, tagged to competitors, products and topics, with relevance. The firm's implementation of a rule change is managed in 38, which cites the horizon item.",
  [
   ("Intelligence Item", "A captured news article, research note or market event.", [
     ("Intelligence Item", [
       ("Intelligence Item ID", "Unique identifier of the item.", "Intelligence Item", "Identifier", "", "MIN-2026-018223", "Internal", "", "Y", "No PII."),
       ("Headline", "Headline or title.", "Intelligence Item", "Text", "", "Northbridge Brokerage raises the yield on its cash sweep program", "Internal", "", ""),
       ("Source Type", "Kind of source.", "Intelligence Item", "Code", "Intelligence Source Type", "Trade Press", "Internal", "", ""),
       ("Publication Date", "Date published.", "Intelligence Item", "Date", "ISO 8601", "2026-09-02", "Internal", "", ""),
       ("Topic Tags", "Topics covered.", "Intelligence Item", "Code (multi)", "Market Topic", "Cash and Sweep Yields", "Internal", "", ""),
       ("Linked Competitors", "Competitor profiles mentioned.", "Intelligence Item", "Reference (Competitor Profile) (multi)", "", "CPF-0112", "Internal", "", ""),
       ("Linked Own Products", "Own strategies, products or service offerings affected.", "Intelligence Item", "Reference (Strategy / Product / Service Offering) (multi)", "", "STR-00123", "Internal", "", ""),
       ("Relevance Rating", "Assessed relevance to the firm.", "Intelligence Item", "Code", "Impact Level", "High", "Internal", "", ""),
     ]),
   ]),
   ("Regulatory Horizon Item", "Upcoming US regulatory initiatives affecting competition, pricing, products or channels, one record per regulator and initiative, updated as news items arrive. Compliance obligations are owned by 38 and 08.", [
     ("Regulatory Horizon Item", [
       ("Regulator / Body", "Regulator, self-regulatory organization or standard setter.", "Regulatory Item", "Code", "Regulatory Body", "SEC", "Internal", "", "Y", "No PII. Key: Regulator / Body x Regulatory Initiative."),
       ("Initiative Source Type", "Kind of initiative: rulemaking, SRO rule filing, legislation, litigation or staff guidance.", "Regulatory Item", "Code", "Initiative Source Type", "Rulemaking", "Internal", "", ""),
       ("Regulatory Initiative", "Name of the rule, proposal or other initiative.", "Regulatory Item", "Text", "", "Amendments to Regulation S-P (customer information safeguards and incident notification)", "Internal", "", "Y"),
       ("Initiative Stage", "Current stage of the initiative.", "Regulatory Item", "Code", "Regulatory Stage", "In Force", "Internal", "", ""),
       ("Expected Effective Date", "Date the change is expected to apply or its compliance date.", "Regulatory Item", "Date", "ISO 8601", "2025-12-03", "Internal", "", "Y", "Compliance dates differ for larger (2025-12-03) and smaller (2026-06-03) entities."),
       ("Market Impact Assessment", "Expected effect on competition, flows, pricing or channels.", "Regulatory Item", "Text", "", "Incident notification practices of competing brokerages become comparable; no expected price effect", "Internal", "", ""),
       ("Source Intelligence Items", "News and research items that report on the initiative; the horizon item is updated in place as they arrive.", "Regulatory Item", "Reference (Intelligence Item) (multi)", "", "MIN-2026-018223", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Data Sourcing Controls", "MI-SRC",
  "The use restriction of the licensed datasets behind this domain's values, held so that a rating, ranking or market statistic is not shown to clients when the license forbids it. License terms themselves stay in 14.",
  [
   ("Redistribution Restriction", "Whether values from a licensed dataset may be shown outside the firm, read from the 14 license terms.", [
     ("Redistribution Restriction", [
       ("Redistribution Permitted Indicator", "Whether values from the dataset may be shown to clients, prospects or intermediaries under the license.", "Redistribution Restriction", "Boolean", "", "N", "Internal", "SEC Marketing Rule", "Y", "No PII. Derived from 14 license terms; read by the 08 citation review. Keyed by the parent profile's Licensed Dataset."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Industry Dataset Family": ("Internal", [("Industry Flow Statistics","Trade-association aggregates (ICI)"),("Fund-Level Flow & Asset Database","Morningstar Direct, ISS Market Intelligence Simfund, LSEG Lipper"),("Intermediary Sales & Asset Data","Broadridge and Morningstar distribution data; firm, office and advisor grain"),("Advisor & Firm Universe","Discovery Data; SEC Form ADV and FINRA BrokerCheck derived"),("Household Wealth Statistics","Federal Reserve Survey of Consumer Finances and Financial Accounts (Z.1)"),("Market Sizing Research","Cerulli-type studies"),("Competitor Pricing Data","Public fee schedules and disclosure documents, or a vendor pricing dataset"),("Institutional Search & Mandate Data","Nasdaq eVestment, consultant databases"),("Retirement Plan Data","DOL Form 5500, vendor-enriched"),("Ratings Data","Morningstar, LSEG Lipper")]),
 "Industry Data Provider": ("Internal (shared Data Provider, steward 14)", [("ICI","Investment Company Institute"),("Morningstar",""),("LSEG Lipper",""),("ISS Market Intelligence","Simfund"),("Broadridge",""),("Cerulli Associates",""),("Nasdaq eVestment",""),("Discovery Data",""),("US Department of Labor","Form 5500 datasets"),("US SEC","Form ADV, EDGAR"),("FINRA","BrokerCheck, Industry Snapshot"),("Federal Reserve","Survey of Consumer Finances, Financial Accounts (Z.1)"),("Other","Name the provider on the record")]),
 "Flow Estimation Method": ("ICI / Morningstar / Internal", [("Reported by Funds","Actual sales and redemptions reported by member funds (ICI monthly)"),("Estimated from TNA and Return","Change in net assets not explained by return (Morningstar)"),("Estimated from Sample","Weekly estimate scaled from a reporting sample (ICI weekly)"),("ETF Shares Outstanding Change","Change in shares outstanding x NAV"),("Intermediary Reported","Distributor-level data contributed by intermediaries (Broadridge)"),("Modeled","Vendor or internal model")]),
 "Category Scheme": ("Internal (shared Fund Category Scheme, steward 11)", [("ICI Investment Classification",""),("Morningstar Category",""),("Morningstar Global Category","For peers of the firm's international funds"),("Lipper Global Classification",""),("eVestment Universe",""),("Firm Market Segment","")]),
 "Data Grain": ("Internal", [("Industry Total",""),("Asset Class",""),("Category",""),("Fund Manager Firm",""),("Fund",""),("Share Class",""),("Channel",""),("Distributor Firm",""),("Branch / Office",""),("Advisor",""),("Investor Segment","Household wealth or age band"),("Geography","")]),
 "Industry Vehicle Type": ("ICI / ISS Market Intelligence", [("Mutual Fund","Including foreign open-end funds that are peers of the firm's international funds"),("ETF",""),("Closed-End Fund",""),("Interval Fund",""),("CIT","Collective investment trust"),("SMA / Model","Separately managed account or model-delivered"),("Money Market Fund",""),("Variable Annuity Subaccount",""),("Other","")]),
 "Coverage Basis": ("Internal", [("Fund Domicile","Values attributed to the fund's country of domicile"),("Distributor Reported","Values reported by the distributing firm"),("Investor Residence","Values attributed to the investor's state or country of residence"),("Filer Reported","Values from each filer's regulatory filing (Form ADV, Form 5500)")]),
 "Frequency": ("Internal (shared Frequency, steward 09)", [("Daily",""),("Weekly",""),("Monthly",""),("Quarterly",""),("Semi-Annual",""),("Annual",""),("Ad Hoc","")]),
 "Revision Policy": ("Internal", [("No Revisions",""),("Rolling Prior-Period Revisions","E.g. ICI weekly estimates revised for adjustments and reclassifications"),("Annual Rebase",""),("Full History Restatement","")]),
 "Release Status": ("Internal", [("Preliminary",""),("Final",""),("Revised",""),("Withdrawn","")]),
 "Industry Channel": ("Internal (shared Distribution Channel, steward 09, CW-164 and CW-140 values)", [("Direct","Level 1: investors who deal with a firm directly"),("Direct - Self-Directed","Self-directed brokerage and fund-only accounts (DB)"),("Direct - Digital Advice","Digital advice programs (DA)"),("Direct - Human Advice","Human and hybrid advice programs (HA)"),("Direct - Trust","Personal trust services (TR)"),("Workplace","Level 1: workplace retirement plans"),("Workplace - Recordkept Plan","Participants in plans the provider recordkeeps (WR)"),("Institutional","Level 1: institutional asset owners"),("Institutional - Direct","Pensions, endowments, foundations covered directly"),("Institutional - Consultant-Led","Institutional business intermediated by an investment consultant"),("Institutional - OCIO","Outsourced chief investment officer mandates"),("Intermediary","Level 1: third-party intermediaries (IC)"),("Intermediary - Wirehouse",""),("Intermediary - National / Regional Broker-Dealer",""),("Intermediary - Independent Broker-Dealer",""),("Intermediary - RIA","Registered investment advisers, including hybrid and custodian-served RIAs"),("Intermediary - Bank / Trust","Bank brokerage, bank trust and private bank wealth units"),("Intermediary - TAMP / Model Marketplace",""),("Intermediary - Brokerage Platform","Third-party brokerage platforms and fund supermarkets"),("Intermediary - Third-Party Recordkeeper","Plans recordkept by others (formerly DCIO, CW-139)")]),
 "Value Basis": ("Internal (shared Data Basis, steward 09)", [("Reported",""),("Estimated",""),("Modeled",""),("Interpolated","")]),
 "Share Measure Basis": ("Internal", [("Assets",""),("Gross Sales",""),("Net Flows",""),("Positive Net Flows Only","Share of inflows among funds in net inflow"),("Net New Assets","Client asset flows on the 06 certified definition"),("Client Count","Households or accounts")]),
 "Share Dimension": ("Internal", [("Category",""),("Asset Class",""),("Channel",""),("Distributor Firm",""),("Region / Market",""),("Vehicle",""),("Wealth Band",""),("Investor Segment",""),("Total Industry","")]),
 "Numerator Source": ("Internal", [("Same Industry Dataset","Own value taken from the same vendor dataset as the denominator"),("06 Certified Measure","Own value copied from the 06 certified Client Assets, Net New Assets or fund flow measure"),("Blended","Requires a disclosure flag")]),
 "Negative Flow Treatment": ("Internal", [("Report Not Meaningful",""),("Share of Gross Sales Instead",""),("Signed Share","Negative share allowed"),("Share of Positive Flows","")]),
 "Period Type": ("Internal (shared Period Type, steward 09)", [("Month",""),("Quarter",""),("Year to Date",""),("Trailing 12 Months",""),("Calendar Year",""),("Point in Time","For asset share")]),
 "Competitor Tier": ("Internal", [("Primary","Head-to-head in core business lines and channels"),("Secondary",""),("Emerging / Disruptor",""),("Watch","")]),
 "Competitor Type": ("Internal / Cerulli", [("Direct Brokerage","Self-directed brokerage firm"),("Robo-Adviser","Digital-only advice firm"),("Hybrid Advice Firm","Digital advice with access to human advisors"),("Wirehouse",""),("Independent RIA Aggregator",""),("Workplace Recordkeeper",""),("Fund and ETF Sponsor",""),("Bank Wealth Manager",""),("Trust Company",""),("OCIO Provider","Outsourced chief investment officer (IA)"),("Other","")]),
 "Presence Strength": ("Internal", [("Dominant",""),("Strong",""),("Moderate",""),("Weak",""),("Not Present","")]),
 "Competitor Offering Type": ("Internal (aligned to SEC Form CRS relationship and service types)", [("Self-Directed Brokerage",""),("Digital Advice",""),("Hybrid Advice","Digital advice with advisor access"),("Human Advice",""),("Workplace Recordkeeping",""),("Cash Management","Cash sweep, cash management account or high-yield cash"),("Trust Services",""),("Fund Range",""),("ETF Range",""),("Institutional / OCIO","Separate account, OCIO or institutional advisory offering (IA)"),("Other","")]),
 "Offering Feature": ("Internal", [("Tax-Loss Harvesting",""),("Automatic Rebalancing",""),("Fractional Shares",""),("Direct Indexing",""),("Financial Planning Tools",""),("Dedicated Advisor",""),("On-Demand Advisor Access",""),("Cash Management Account",""),("Commission-Free Online Trades",""),("Retirement Income Planning",""),("ESG / Values-Based Portfolios",""),("Other","")]),
 "Competitor Offering Status": ("Internal", [("Announced",""),("Active",""),("Closed to New Clients",""),("Discontinued","")]),
 "Business Line": ("CW-004 (shared list, steward 09; two-letter codes as values)", [("DB","Direct brokerage and self-directed investing"),("DA","Digital advice"),("HA","Human and hybrid advice"),("PF","Proprietary funds and ETFs (including CITs)"),("WR","Workplace retirement recordkeeping"),("IA","Institutional advisory"),("IC","Intermediary channel"),("TR","Personal trust services (optional)")]),
 "Price Component": ("Internal (Form ADV Part 2A, Form CRS, Form N-1A fee table)", [("Advisory Fee Rate","Annual asset-based advisory or wrap fee"),("Flat or Subscription Fee","Fixed monthly or annual fee"),("Commission per Trade",""),("Options Contract Fee",""),("Account Service Fee","Maintenance, transfer, paper statement and similar fees"),("Margin Rate","Interest rate charged on margin balances"),("Cash Sweep Yield","Yield paid on swept or program cash"),("Expense Ratio","Net expense ratio of a fund or ETF"),("Other","")]),
 "Price Quote Basis": ("Internal", [("Annual Percentage of Assets",""),("Per Trade",""),("Per Contract",""),("Per Month",""),("Per Year",""),("Per Event",""),("Annual Percentage Yield",""),("Annual Interest Rate","")]),
 "Pricing Source Type": ("Internal", [("Published Fee Schedule",""),("Form ADV Part 2A / Appendix 1","Firm brochure or wrap fee program brochure"),("Form CRS",""),("Fund Prospectus Fee Table","Form N-1A Item 3"),("Website Rate Page",""),("Vendor Pricing Dataset","Licensed dataset (14)"),("Other","")]),
 "Competitor Event Type": ("Internal", [("Product Launch",""),("Product Closure / Merger",""),("Fee Reduction",""),("Pricing Change","Change in an advisory fee, commission or account fee"),("Program Launch","New advice or brokerage program"),("Feature Launch","New platform or program feature"),("Cash Yield Change",""),("Share Class Launch",""),("M&A",""),("Strategic Partnership",""),("New Market Entry",""),("Market Exit",""),("Distribution Agreement / Platform Win",""),("Rating Change",""),("Regulatory Action","")]),
 "Impact Level": ("Internal", [("High",""),("Medium",""),("Low",""),("None","")]),
 "Personnel Role": ("Internal", [("Portfolio Manager",""),("CIO",""),("CEO / Executive",""),("Head of Wealth / Advice",""),("Head of Distribution",""),("Head of Product",""),("Head of Digital","")]),
 "Personnel Move Type": ("Internal", [("Hire",""),("Departure",""),("Retirement",""),("Internal Role Change","")]),
 "Peer Universe Type": ("Internal", [("Vendor Category","Morningstar Category, Lipper Global Classification"),("Consultant Universe","eVestment or consultant database universe"),("Custom Peer Set","Hand-picked competitors"),("Partner-Defined Peer Group","Peer group used by an intermediary home office (IC)")]),
 "Representative Class Rule": ("Morningstar / Internal", [("Oldest Share Class",""),("Largest Share Class",""),("Clean / Institutional Class",""),("All Share Classes","")]),
 "Return Period": ("Morningstar / LSEG Lipper (shared Reporting Period Basis)", [("1 Month",""),("Year to Date",""),("1 Year",""),("3 Years Annualized",""),("5 Years Annualized",""),("10 Years Annualized",""),("Since Inception","")]),
 "Quartile": ("LSEG Lipper / Morningstar", [("1st Quartile","Best 25%"),("2nd Quartile",""),("3rd Quartile",""),("4th Quartile","Worst 25%")]),
 "Rating Scheme": ("Vendor methodologies", [("Morningstar Rating (Star)","1-5 stars; risk-adjusted return vs Morningstar Category; 36-month minimum"),("Morningstar Medalist Rating","Gold, Silver, Bronze, Neutral, Negative"),("Morningstar Sustainability Rating","1-5 globes vs Morningstar Global Category"),("Lipper Leaders","1-5 per measure; 5 = Lipper Leader (top 20%)"),("Other Third-Party Rating","Any other third-party rating or ranking cited under the SEC Marketing Rule")]),
 "Rated Object Type": ("Internal", [("Share Class",""),("Fund",""),("Service Offering","Advice or brokerage program"),("Firm","")]),
 "Award Outcome": ("Internal (shared Award Outcome, steward 11)", [("Winner",""),("Highly Commended",""),("Shortlisted / Finalist",""),("Not Placed","")]),
 "Fee Measure": ("Internal / SEC Form N-1A / Form ADV Part 2A", [("Net Expense Ratio","US prospectus fee table, net of waivers"),("Gross Expense Ratio",""),("Management Fee",""),("Advisory Fee Rate","Annual advisory or wrap program fee"),("All-In Program Cost","Advisory fee plus the asset-weighted expense ratio of the underlying funds"),("Commission per Trade",""),("Account Service Fee","")]),
 "Fee Study Purpose": ("Internal", [("New Product Pricing",""),("Repricing Review",""),("Board 15(c) Review","Investment Company Act Section 15(c) advisory contract renewal"),("Advice Program Pricing Review","Review of an advice or brokerage program's fee schedule (47)"),("Platform / Partner Negotiation","IC"),("RFP Support","IA")]),
 "Fee Competitiveness": ("Internal", [("Highly Competitive","Cheapest quartile"),("Competitive",""),("At Market",""),("Above Market",""),("Uncompetitive","Most expensive quartile")]),
 "Sizing Subject Type": ("Internal", [("Total Market",""),("Channel",""),("Investor Segment",""),("Wealth Band",""),("Age Band",""),("Geography",""),("Workplace Participant Market",""),("DC Plan Market",""),("Institutional Segment",""),("Distributor Firm","IC")]),
 "Sizing Metric": ("Internal / Federal Reserve SCF / Cerulli", [("Household Count",""),("Investable Household Assets",""),("Advised Household Assets",""),("Self-Directed Household Assets",""),("Digital Advice Assets",""),("Advisor-Controlled Assets",""),("Advisor Count",""),("Addressable Industry AUM","Assets in categories where the firm has products"),("DC Plan Assets",""),("DC Participant Count",""),("IRA Rollover Assets","Assets rolled over from workplace plans to IRAs"),("Institutional Assets",""),("Model Portfolio Assets",""),("Projected Asset Growth Rate","")]),
 "Net Worth Band": ("02 Client & Household (local copy of the 02 Net Worth Band boundaries; net worth there, investable assets here)", [("USD 0 - 49,999",""),("USD 50,000 - 99,999",""),("USD 100,000 - 249,999",""),("USD 250,000 - 499,999",""),("USD 500,000 - 999,999",""),("USD 1,000,000 - 2,499,999",""),("USD 2,500,000 - 4,999,999",""),("USD 5,000,000 - 9,999,999",""),("USD 10,000,000 - 24,999,999",""),("USD 25,000,000 or more","")]),
 "Measure Unit": ("22 Market Data & Pricing (local copy of the proposed shared Measure Unit, subset)", [("Percent","Rates and ratios, e.g. 0.30 = 0.30%"),("Basis Points",""),("Currency Amount","Per-trade, per-contract or per-account charges in USD")]),
 "Sizing Method": ("Internal", [("Vendor Published",""),("Public Statistic","Federal Reserve, ICI or DOL publication"),("Bottom-Up Aggregation","From firm or plan records"),("Top-Down Allocation","Allocated from total by driver"),("Regression / Model",""),("Analyst Estimate","")]),
 "Market Topic": ("Internal", [("Channel Trends",""),("Platform Consolidation",""),("Model Portfolios",""),("Vehicle Shift (ETF, CIT, SMA)",""),("Fees / Pricing",""),("Digital Advice",""),("Hybrid Advice",""),("Cash and Sweep Yields",""),("Direct Indexing",""),("Retirement / Rollovers",""),("Wealth Transfer",""),("Private Markets in Wealth",""),("ESG / Sustainability",""),("Advisor Demographics / Movement",""),("M&A",""),("Regulation",""),("Technology / AI","")]),
 "Trend Direction": ("Internal", [("Increasing",""),("Stable",""),("Decreasing",""),("Emerging","")]),
 "Intelligence Source Type": ("Internal", [("Trade Press",""),("Newswire",""),("Vendor Research",""),("Regulator Publication",""),("Competitor Filing / Website",""),("Sales Field Feedback","Captured from 03 advisor or 05 partner activities"),("Social Media","")]),
 "Regulatory Body": ("Internal (shared Regulator, steward 09; US values)", [("SEC","US Securities and Exchange Commission"),("FINRA",""),("US State Securities Regulator","Via NASAA"),("CFTC / NFA",""),("OCC",""),("Federal Reserve",""),("DOL / EBSA","US Department of Labor, Employee Benefits Security Administration"),("IRS / US Treasury",""),("FinCEN",""),("MSRB",""),("IOSCO","International standard setter")]),
 "Regulatory Stage": ("Internal (US rulemaking stages)", [("Concept Release / Request for Comment",""),("Proposed Rule",""),("Final Rule Adopted",""),("In Implementation","Between adoption and the compliance date"),("In Force",""),("Stayed / In Litigation",""),("Withdrawn","")]),
 "Initiative Source Type": ("Internal", [("Rulemaking","Agency notice-and-comment rulemaking"),("SRO Rule Filing","FINRA or MSRB rule filing under Exchange Act Section 19(b)"),("Legislation",""),("Litigation","Court challenge affecting a rule"),("Staff Guidance","FAQs, risk alerts, no-action letters"),("Enforcement Trend","")]),
}

# ---------------------------------------------------------------------------
# Relationships, sources
# ---------------------------------------------------------------------------
REL = [
 ("Industry Dataset Profile","describes","Licensed Dataset (14 Third-Party Data: DSET-)","1 : 1","License, vendor and entitlements stay in 14; methodology here."),
 ("Industry Dataset Profile","has","Redistribution Restriction","1 : 1","Use flag read from the 14 license terms."),
 ("Industry Dataset Profile","is published as","Industry Data Release","1 : 1..n","Each vintage kept; revisions supersede earlier releases."),
 ("Industry Data Release","is loaded by","Load (06 Client Assets, Flows & Channel Attribution: LOAD- / FEED-)","n : 1","Technical feed and load stay in 06."),
 ("Industry Data Release","contains","Industry Flow Observation","1 : 0..n",""),
 ("Industry Flow Observation","may be scoped to","Distributor Firm (05 Intermediary & Institutional Distribution, on a 02 PTY- party)","n : 0..1","IC firm-level data only."),
 ("Category Mapping","maps external category to","Share Class (01 Investment Product & Service Offering: SHC-)","n : n","Own-fund category assignment itself is held in 01."),
 ("Market Share Definition","uses denominator from","Licensed Dataset (14 Third-Party Data: DSET-)","n : 1",""),
 ("Market Share Definition","may use numerator from","Measure Definition / Measure Value (06 Client Assets, Flows & Channel Attribution: MSR-)","n : 0..1","When Numerator Source = 06 Certified Measure; the firm value is a Derived copy (CW-160)."),
 ("Market Share Record","is computed under","Market Share Definition","n : 1",""),
 ("Market Share Record","has","Industry Ranking","1 : 0..n","Ranked firms in the same table."),
 ("Competitor Profile","profiles","Party (02 Client & Household: PTY-)","1 : 1","Legal entity, name and hierarchy in 02 (CD-143)."),
 ("Competitor Profile","has","Competitor Metric Snapshot / Distribution Footprint","1 : 0..n",""),
 ("Competitor Profile","sells","Competitor Offering","1 : 0..n","CW-160."),
 ("Competitor Offering","is compared with","Service Offering (01 Investment Product & Service Offering: OFFR-)","n : 0..1",""),
 ("Competitor Offering","is priced by","Competitor Pricing Observation","1 : 0..n","One row per price component and as-of date."),
 ("Competitor Pricing Observation","is read by","Pricing Scenario (10 Client Revenue, Pricing Economics & Profitability: PRSC-)","n : n","Competitor prices as scenario inputs (CW-158)."),
 ("Competitor Pricing Observation","is cited by","Business Case Market Evidence (36 Product Development & Lifecycle)","n : n","Evidence for product and pricing proposals."),
 ("Competitor Profile","undergoes","Competitor Event","1 : 0..n",""),
 ("Competitor Personnel Move","concerns","Party - Individual (02 Client & Household: PTY-)","n : 1","PII - identity."),
 ("Peer Fund","is managed by","Competitor Profile","n : 1",""),
 ("Peer Universe","contains","Peer Fund / Share Class (01 Investment Product & Service Offering: SHC-)","1 : 1..n","Via Peer Universe Member; effective-dated."),
 ("Peer Universe","is used to compare","Investment Strategy (01 Investment Product & Service Offering: STR-)","n : 0..1",""),
 ("Peer Metric Snapshot","is ranked within","Peer Universe","n : 1",""),
 ("Peer Metric Snapshot","copies own share class values from","Share Class (01: Net Expense Ratio) / Performance Return (32)","n : 0..1","Own share class rows only (ROW_OWNERSHIP)."),
 ("Peer Fund","is vetted, when on the platform, by","Third-party fund due diligence (52 External Manager & Sub-Adviser Oversight)","1 : 0..1","52 owns the due diligence; 11 holds peer metrics only."),
 ("Rating Observation","rates","Share Class (01 Investment Product & Service Offering: SHC-) / Peer Fund","n : 1","Same structure for own and peer funds."),
 ("Award","citation is approved by","Compliance Review (08 Retail Conduct & Supervision: REV-)","n : 0..1","Marketing use of awards (SEC Marketing Rule); rating citations are reviewed in 08 against the Rating Observation."),
 ("Fee Benchmark Study","benchmarks","Share Class / Service Offering (01 Investment Product & Service Offering: SHC- / OFFR-)","n : 1","01 owns the fund expense terms."),
 ("Fee Benchmark Study","benchmarks","Fee Schedule (47 Pricing, Fees & Billing: CLFEE-)","n : 0..1","47 owns the client fee schedule; Own Fee Rate is a Derived copy."),
 ("Fee Benchmark Study","uses","Peer Universe / Competitor Offering","n : 0..n",""),
 ("Fee Benchmark Study","is cited by","Business Case Market Evidence (36 Product Development & Lifecycle)","n : n","36 reads the study (FBS-); 10 reads Competitor Pricing Observation (CW-158)."),
 ("Market Sizing Record","is located in","Geographic Unit (09 Shared Reference: GEO-)","n : 0..1",""),
 ("Market Sizing Record","maps to","Segmentation Scheme value (02 Client & Household: Segment Assignment)","n : 0..1","Mapped Firm Segment."),
 ("Market Sizing Record","is cited by","Business Case Market Evidence (36 Product Development & Lifecycle)","n : n",""),
 ("Opportunity Potential","assesses","Party with a Distributor Firm role (02 PTY- / 05 profile)","n : 1","IC, thin; firm level only."),
 ("Opportunity Potential","uses firm assets from","Measure Value (06 Client Assets, Flows & Channel Attribution)","n : 0..n","Derived copy."),
 ("Plan Market Record","sizes","Retirement Plan (02 Client & Household: PTY-)","n : 1","From DOL Form 5500."),
 ("Mandate Search Event","may link to","Sales Opportunity (05 Intermediary & Institutional Distribution: OPP-)","n : 0..1","05 owns the opportunity and its win / loss reason (CW-170)."),
 ("Mandate Search Event","is advised by","Consultant Profile (05 Intermediary & Institutional Distribution)","n : 0..1",""),
 ("Mandate Search Event","is won by","Competitor Profile","n : 0..1",""),
 ("Win/Loss Analysis","aggregates","Sales Opportunity outcomes (05 Intermediary & Institutional Distribution: OPP-)","1 : 0..n",""),
 ("Market Trend","is evidenced by","Market Research Report","n : n",""),
 ("Intelligence Item","mentions","Competitor Profile / Strategy (01: STR-) / Service Offering (01: OFFR-)","n : n",""),
 ("Intelligence Item","reports on","Regulatory Horizon Item","n : n","Via Source Intelligence Items; one horizon record per regulator and initiative."),
 ("Regulatory Horizon Item","is cited by","Regulatory Change Item (38 Corporate Compliance & Regulatory Affairs: REGCH-)","1 : 0..n","38 manages the firm's implementation."),
 ("Market Research Report","is licensed as","Licensed Dataset (14 Third-Party Data: DSET-)","n : 1","License terms (DLA-) are 14's."),
]

SRC = [
 ("ICI Estimated Long-Term Mutual Fund Flows and ETF Net Issuance (weekly)","Investment Company Institute","https://www.ici.org/research/stats/flows","Free summary; member data","Weekly estimates of mutual fund flows and ETF net issuance; prior weeks revised; monthly actuals collected separately","Flow Estimation Method, Revision Policy, Data Release",["ICI"]),
 ("ICI Monthly Trends in Mutual Fund Investing","Investment Company Institute","https://www.ici.org/monthly-trends-in-mutual-fund-investing","Free summary; member data","Reported sales, redemptions, net new cash flow by ICI classification","Industry Flow Observation, reinvestment treatment",[]),
 ("ICI Investment Company Fact Book","Investment Company Institute","https://www.icifactbook.org","Free","Annual US fund industry assets, flows, investor and household statistics","Market Sizing Record, Market Trend",[]),
 ("Federal Reserve Survey of Consumer Finances","Board of Governors of the Federal Reserve System","https://www.federalreserve.gov/econres/scfindex.htm","Public","Triennial household survey of income, assets and debt by wealth, income and age group","Wealth Band, Age Band, Market Sizing Record",["Federal Reserve SCF"]),
 ("Financial Accounts of the United States (Z.1)","Board of Governors of the Federal Reserve System","https://www.federalreserve.gov/releases/z1/","Public","Quarterly household and nonprofit financial assets by instrument","Market Sizing Record (household financial assets)",[]),
 ("Morningstar Estimated Net Cash Flow methodology","Morningstar","https://www.morningstar.com/content/dam/marketing/shared/research/methodology/765555_Estimated_Net_Cash_Flow_Methodology.pdf","Free methodology; data licensed","Flow = TNA(t) - TNA(t-1) x (1 + r); distribution adjustments; ETF shares outstanding","Flow Estimation Method, peer flows",["Morningstar"]),
 ("Morningstar Rating for Funds (Star Rating) methodology","Morningstar","https://www.morningstar.com/content/cs-images/v3/assets/blt9415ea4cc4157833/blt4746ec2633987fb2/67819c62694c4c0ed070ba0a/Morningstar_Rating_for_Funds.pdf","Free methodology; data licensed","Risk-adjusted return vs Morningstar Category; 36-month minimum; 3/5/10-year and overall","Rating Scheme, Rating Observation",[]),
 ("Morningstar Medalist Rating methodology (April 2026)","Morningstar","https://s25.q4cdn.com/634000362/files/doc_downloads/1/Morningstar_Medalist_Rating_Methodology-April-2026.pdf","Free methodology; data licensed","Gold/Silver/Bronze/Neutral/Negative; People, Process, Parent pillars; analyst-driven and data coverage %; price score","Medalist Rating Detail",[]),
 ("Morningstar Sustainability Rating methodology","Morningstar / Sustainalytics","https://www.morningstar.com/content/dam/marketing/shared/research/methodology/SustainabilityRatingMethodology_2021.pdf","Free methodology; data licensed","1-5 globes from portfolio ESG risk score vs Morningstar Global Category","Sustainability Rating Detail",[]),
 ("LSEG Lipper Leaders methodology","LSEG (Lipper)","https://lipperleaders.com/documents/LipperLeaders_Methodology_Intl.pdf","Free methodology; data licensed","Total Return, Consistent Return, Preservation, Expense (Tax Efficiency is a US-methodology measure; confirm against the US document); quintile scores 1-5; 3/5/10-year and overall","Lipper Leaders Measure, Rating Observation",["LSEG Lipper"]),
 ("ISS Market Intelligence Simfund","ISS Market Intelligence","https://www.issmarketintelligence.com","Licensed","Fund, ETF, CIT and SMA flows and assets across managers and vehicles","Industry Flow Observation, Competitor Metrics, CIT vehicle",["ISS Market Intelligence"]),
 ("Broadridge Distribution Insight / Sales & Asset Reporting","Broadridge","https://www.broadridge.com/financial-services/asset-management/mutual-funds-etf/access-unique-distribution-insights/sales-and-asset-reporting","Licensed","Intermediary sales and assets by firm, office and advisor; market share by channel","Market share within an intermediary firm, Opportunity Potential (IC)",["Broadridge"]),
 ("Cerulli Associates - US retail, advice and intermediary research","Cerulli Associates","https://www.cerulli.com","Licensed","Assets and households by channel and advice model, market share projections (structure only; confirm report titles)","Industry Channel, Market Sizing, Market Trends",["Cerulli"]),
 ("Nasdaq eVestment Market Lens","Nasdaq","https://www.nasdaq.com/solutions/evestment/asset-managers/market-lens","Licensed","Plan documents, mandates, searches under review, manager rosters","Mandate Search Event, Win/Loss Analysis",["Nasdaq eVestment"]),
 ("DOL Form 5500 Datasets (EFAST2)","US Department of Labor, EBSA","https://www.dol.gov/agencies/ebsa/about-ebsa/our-activities/public-disclosure/foia/form-5500-datasets","Public","Form 5500 / 5500-SF and schedules (H financials, C service providers), updated monthly","Plan Market Record",["DOL Form 5500"]),
 ("SEC Form ADV and Investment Adviser Public Disclosure (IAPD)","US SEC","https://adviserinfo.sec.gov","Public","Regulatory assets under management, client and advisor counts, brochures (Part 2A and Appendix 1 wrap fee brochure) of US investment advisers","Competitor Metrics, Competitor Offering, Competitor Pricing Observation",["SEC Form ADV","SEC Form ADV Part 2A"]),
 ("SEC Form CRS (Customer Relationship Summary): broker-dealer instructions and Form ADV Part 3","US SEC","https://www.sec.gov/files/formcrs.pdf; https://www.sec.gov/about/forms/formadv-part3.pdf","Regulation","Relationship and service types, fees and costs summarized for retail investors by broker-dealers (Form CRS) and investment advisers (Form ADV Part 3)","Competitor Offering Type, Pricing Source Type",["SEC Form CRS"]),
 ("FINRA BrokerCheck and FINRA 2026 Industry Snapshot","FINRA","https://brokercheck.finra.org; https://www.finra.org/media-center/reports-studies/2026-industry-snapshot","Public","Registered broker-dealer and representative records; annual industry statistics (2026 edition published June 2026)","Advisor Count, Estimated Advisor Headcount",["FINRA BrokerCheck"]),
 ("Morningstar US Fund Fee Study (annual)","Morningstar","https://www.morningstar.com (confirm page)","Free summary","Asset-weighted expense ratios of US funds and ETFs by type and sponsor","Asset-Weighted Expense Ratio, fee benchmarking context",["Morningstar US Fund Fee Study"]),
 ("SEC Marketing Rule 206(4)-1 (third-party ratings)","US SEC","https://www.ecfr.gov/current/title-17/section-275.206(4)-1","Regulation","Conditions for citing third-party ratings: date, period, provider, compensation disclosure","Award and rating citation attributes, Redistribution Restriction (review owned by 08)",["SEC Marketing Rule"]),
 ("SEC Form N-1A fee table (Item 3)","US SEC","https://www.sec.gov/files/formn-1a.pdf","Regulation","Expense ratio definitions for US funds","Fee Measure, Expense Ratio, Price Component",["SEC Form N-1A"]),
 ("Investment Company Act of 1940 Section 15(c)","US SEC / US Congress","https://www.law.cornell.edu/uscode/text/15/80a-15","Statute","Board approval of advisory contracts, informed by fee and performance comparisons","Fee Study Purpose",["Investment Company Act Section 15(c)"]),
 ("Discovery Data","Discovery Data","https://discoverydata.com","Licensed","Advisor and firm universe, practice asset estimates","Opportunity Potential inputs (IC)",["Discovery Data"]),
 ("ISO 6166 (ISIN) / ISO 3166 / ISO 4217 / ISO 8601","ISO","https://www.iso.org","Standard","Identifiers and code lists","Peer Fund identifiers, geography, currency, dates",["ISO 6166"]),
]
