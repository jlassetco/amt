"""Data Domain 12 - Institutional Client Servicing & Reporting (wealth-manager reference model; adapts the wholesale 12 in place,
CW-145). Content module for taxonomy_builder.py. The wholesale version stays at tag wholesale-v1.0."""

META = {
 "title": "Institutional Client Servicing & Reporting Data Taxonomy",
 "subtitle": "Business domain 12 - Institutional Client Servicing & Reporting | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "12_Institutional_Client_Servicing_and_Reporting/Institutional_Client_Servicing_and_Reporting_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for how a US wealth manager services its institutional relationships once they are won: the OCIO and institutional mandate clients of its registered investment adviser (endowments, foundations, public and corporate pensions, health systems, insurers' general accounts, Taft-Hartley plans and government entities; IA line), and the sponsors of the workplace plans its recordkeeper administers (WR line). The domain masters the Institutional Client profile and its Investment Policy Statement versions, the service model (service relationships with their OCIO and plan sponsor servicing detail, institutional service tiers, service standards, service teams and servicing coverage), client reporting from definition to delivery, client-facing guideline monitoring and breach notification, client service requests and cash-flow notifications, client reviews and relationship health, the operational set-up of a new mandate, and termination. It draws on the GIPS Standards for Firms (2020), Advisers Act Rules 204-2, 206(4)-1, 206(4)-2 and 206(4)-5, ERISA sections 3(21) and 3(38), DOL 29 CFR 2550.408b-2, UPMIFA, the CFA Institute guidance on investment policy statements, SEC Form N-PX, SWIFT ISO 15022 and ISO 20022 messaging and CRM service-case models."),
  ("Scope", "In scope: the Institutional Client profile (keyed by the 02 PTY- of a party with the Institutional Client role, CW-023) and its Investment Policy Statement versions (IPSV-); Service Relationships (SVR-) with OCIO Service Detail and Plan Sponsor Servicing Detail, Institutional Service Tiers, Service Standards (SLA-), Service Teams (SVT-) and Service Coverage Assignments (SVA-) for servicing roles; report definitions (RPT-), components (RCM-), templates (TPL-), packages (RPK-), presentation profiles (PPP-), holdings presentation and GIPS Report provision; report schedules, runs (RRN-), distribution lists (DLS-) and deliveries; guideline monitoring arrangements, breach notifications (GBN-) and compliance certificates; client service requests (CSR-) and cash flow notifications (CFN-); client reviews (CRV-) and relationship health scores; mandate onboarding, client custodian account set-up (CUA-), cash flow arrangements, outbound client data feeds (CDF-) and transition events (TRN-); mandate terminations (TRM-). Out of scope (referenced by ID): the party core, the thin retirement plan identity and contact points (02 Client & Household); mandates, investment restrictions, the OCIO service offering, benchmarks, GIPS composites and commentary (01); accounts (15); the relationship manager of record and meetings (03 Party Coverage Assignment and Advisor Activity, CW-138); surveys (04); consultants, pipeline and agreements (05, W4); complaints and compliance reviews (08); calendars and legal entities (09); plans, plan roles, recordkeeping arrangements and plan notices (16, CW-146); portfolios (18); strategic allocation (24) and external managers (52, CW-147); settlement instructions (26) and safekeeping accounts (28); performance (32); breaches (33); proxy votes (34); contracts (39); brands (42); billing arrangements and fee invoices (47, CW-012, CW-054). Participant requests are 13; return and portfolio holding values are produced in 18 and 32 and are not modeled here."),
  ("Structure", "Four levels: Data Domain > Data Family > Data Business Object > Data Business Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Party (02, PTY-) with the Institutional Client role -> Institutional Client profile -> Investment Policy Statement versions (IPSV-, referencing the 24 Asset Allocation Policy and the 01 mandates it governs). Service Relationship (SVR-: Institutional Client x servicing segment, with its serviced mandates MND- and pooled vehicles PRD-, the 05 consultant advisory relationship and the servicing legal entity) -> OCIO Service Detail (delegation scope, ERISA status, 01 OCIO offering, 52 managers in scope) or Plan Sponsor Servicing Detail rows, one per plan (02 Retirement Plan, 16 recordkeeping Service Arrangement and fiduciary committee) -> Institutional Service Tier and Service Standards (SLA-) -> Service Coverage Assignments (SVA-) of 20 employees in servicing roles; the relationship manager of record is the 03 Party Coverage Assignment. Reporting: Report Definition (RPT-) built from Components and a Template (TPL-) -> Report Package (RPK-) per relationship with a Presentation Profile (PPP-) -> Report Schedule -> Report Runs (RRN-) with cut-off, sign-off and version -> Report Deliveries to Distribution Lists (DLS-). Servicing: Breach Notifications (GBN-, reporting 33 breaches), Compliance Certificates, Service Requests (CSR-), Cash Flow Notifications (CFN-), Client Reviews (CRV-), Relationship Health Scores (reading 04 Survey Responses). Set-up: Mandate Onboarding (from a won 05 opportunity) -> Client Custodian Account (CUA-, causing the 28 SKA- and 26 SSI-), Cash Flow Arrangement, Client Data Feeds (CDF-), Transitions (TRN-). Exit: Mandate Termination (TRM-, final 47 fee invoice)."),
  ("Design principles", "1) Reference, don't redefine: mandates, restrictions and offerings are 01's; the party core is 02's; plans and plan roles are 16's; allocations 24's; managers 52's; breaches 33's; fees and invoices 47's. 2) Profile here, party core in 02: the Institutional Client is a role profile keyed by its PTY- (CW-023). 3) Separate the definition (what was promised: the IPS, the package, the standard) from the instance (the run, the notification, the request), so service levels can be measured. 4) Presentation, not calculation: the domain records which return type, fee basis, currency and periods a client sees, not the values. 5) Evidence trail: sign-off, delivery, client notification and call-back timestamps are kept for audits, client disputes, GIPS and Advisers Act books and records. 6) Breach facts are Derived copies of 33 (CD-222); custodian account set-up values are Derived copies of 28 and 02 (CD-194). 7) Effective-date coverage, tiers, IPS versions and recipients. 8) Every object states its PII tier; institutional profiles carry none, while recipients, signatories and officers are 'PII - identity' (CW-150). 9) Flag Critical Data Elements (CDE)."),
  ("Applies To", "Shows the record each attribute belongs to: Institutional Client, Investment Policy Statement, Service Relationship, OCIO Service Detail, Plan Sponsor Servicing Detail, Institutional Service Tier, Service Standard, Service Team, Service Coverage Assignment, Report Definition, Report Component, Report Template, Report Package, Presentation Profile, Report Schedule, Report Run, Distribution List, Report Delivery, Guideline Monitoring Arrangement, Breach Notification, Compliance Certificate, Client Service Request, Cash Flow Notification, Client Review, Relationship Health Score, Mandate Onboarding, Client Custodian Account, Cash Flow Arrangement, Client Data Feed, Transition Event or Mandate Termination."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify the institutional client, its policy, relationship or mandate, apply a regulatory test (government entity, ERISA plan), meet a contractual reporting or notification deadline, evidence sign-off and delivery, move client assets correctly, or end a mandate. Confirm with data owners (Institutional Client Service, Client Reporting, Investment Operations, Plan Sponsor Services, Compliance)."),
  ("Primary / Secondary Reference", "Standard or rule the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Vendor references (Salesforce Service Cloud) indicate common practice and are cross-checks, not schemas to reproduce. Next step: map GIPS-aligned attributes to the provision numbers of the 2020 GIPS Standards for Firms."),
  ("Notes", "PII = personal information under the GLBA, Regulation S-P and US state privacy laws. Each object's PII tier is stated in the Notes of its first attribute: 'PII - identity' or 'No PII'. Institutional clients are organizations, so their profiles hold no personal data; the individuals who receive reports, sign instructions, certify compliance or are assigned as service staff are identity data. No special-category data is held in this domain."),
  ("Tabs", "Hierarchy: families, object groups and objects with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: object-level cardinalities, including references to other Data Domains | Sources: rules, standards and vendor sources used, with links."),
  ("Suggested next steps", "1) Validate families, servicing roles, SLAs and CDEs with Institutional Client Service, Client Reporting, Plan Sponsor Services, Investment Operations and Compliance. 2) Map attributes to the CRM service cloud, the client reporting platform, the performance system, the OMS compliance engine, custodian account set-up tools and the sponsor portal. 3) Agree with 16 the plan sponsor boundary (CW-146) and the Service Arrangement and Plan Role Assignment names this module references. 4) Agree with 24 and 52 the Asset Allocation Policy and Sub-Adviser Engagement references of the IPS and the OCIO Service Detail (CW-147). 5) Agree with 05 the Consultant Advisory Relationship key and the won Sales Opportunity hand-off to Mandate Onboarding. 6) Harmonize Frequency, Delivery Channel and status lists with the enterprise code list registry (09). 7) Turn the Relationships tab into a logical data model."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Institutional Client Profile", "IS-CLT",
  "Who the firm's institutional clients are as asset owners, and the investment policy each has adopted: the Institutional Client profile of a party with the Institutional Client role (restored from the wholesale 02, CW-023) and its Investment Policy Statement versions. The party core (name, identifiers, tax profile) is mastered in 02; the mandates the policy governs are 01's.",
  [
   ("Institutional Client", "Role profile of an institutional asset owner the firm advises or whose plan it recordkeeps, keyed by the 02 party.", [
     ("Institutional Client", [
       ("Institutional Client Party", "Party (02) with the Institutional Client role that the profile describes; the profile's key.", "Institutional Client", "Reference (Party)", "", "PTY-301180", "Internal", "", "Y", "Object PII tier: No PII (institutional organizations). Key format: <PTY- id of the institutional client> (CW-133). The profile sits on the asset-owning party: the plan trust for a DB, public or Taft-Hartley plan, the institution for an endowment, foundation, health system or insurer, and the employer for DC plan sponsor servicing."),
       ("Institutional Client Type", "Kind of institutional asset owner (the party holding the profile: the plan trust for pension plans, the employer for DC plan sponsors), which drives the servicing model, the applicable prudence standard and regulatory tests.", "Institutional Client", "Code", "Institutional Client Type", "Endowment", "Internal", "SEC Form ADV", "Y"),
       ("Primary Business Line", "Business line (CW-004) under which the firm mainly serves the client: institutional advisory or workplace retirement recordkeeping.", "Institutional Client", "Code", "Business Line", "IA", "Internal", "", ""),
       ("Total Investable Assets", "Total assets of the institution's investment program, including assets the firm does not manage, as reported by the client.", "Institutional Client", "Amount", "", "USD 1,840,000,000", "Internal", "", ""),
       ("Assets As-Of Date", "Date the total investable assets figure relates to.", "Institutional Client", "Date", "ISO 8601", "2026-06-30", "Internal", "", ""),
       ("Governance Model", "How the institution's investment decisions are governed and how much is delegated.", "Institutional Client", "Code", "Governance Model", "Investment Committee with OCIO", "Internal", "", ""),
       ("Funded Status", "Ratio of plan assets to the actuarial liability, for defined benefit plans only.", "Institutional Client", "Percentage", "", "84%", "Internal", "", ""),
       ("Funded Status As-Of Date", "Measurement date of the funded status figure.", "Institutional Client", "Date", "ISO 8601", "2025-12-31", "Internal", "", ""),
       ("Government Entity Indicator", "Whether the client is a government entity (a state or political subdivision, its agencies, or a plan or pool it sponsors) for the pay-to-play rule.", "Institutional Client", "Boolean", "", "N", "SEC Rule 206(4)-5", "", "Y"),
       ("ERISA Plan Indicator", "Whether the client's assets are plan assets of an employee benefit plan subject to Title I of ERISA, so that the firm's fiduciary duties follow ERISA.", "Institutional Client", "Boolean", "", "N", "ERISA", "", "Y"),
       ("UPMIFA Applicability Indicator", "Whether the client is a charitable institution whose institutional funds are governed by the state enactment of the Uniform Prudent Management of Institutional Funds Act.", "Institutional Client", "Boolean", "", "Y", "UPMIFA", "", "", "Confirm with Legal for each state of organization."),
       ("Fiscal Year End", "Month and day on which the institution's fiscal year ends; drives annual reviews, spending calculations and audit confirmations.", "Institutional Client", "Text", "MM-DD", "06-30", "Internal", "", ""),
     ]),
   ]),
   ("Investment Policy Statement", "Versioned statement of the client's objectives, constraints and policy allocation that the firm's mandates are managed to.", [
     ("Investment Policy Statement", [
       ("IPS Version ID", "Unique identifier of one version of a client's investment policy statement.", "Investment Policy Statement", "Identifier", "", "IPSV-301180-04", "Internal", "CFA Institute IPS guidance", "Y", "Object PII tier: No PII. The version in force on a date is the Adopted version with the latest IPS Effective Date on or before it; earlier versions are Superseded."),
       ("IPS Client", "Institutional Client whose policy this is.", "Investment Policy Statement", "Reference (Institutional Client, 12)", "", "PTY-301180", "Internal", "", "Y"),
       ("IPS Version Number", "Sequential version of the policy for the client.", "Investment Policy Statement", "Integer", "", "4", "Internal", "", ""),
       ("IPS Status", "Lifecycle status of the version.", "Investment Policy Statement", "Code", "IPS Status", "Adopted", "Internal", "", "Y"),
       ("Firm-Drafted Indicator", "Whether the firm drafted the policy for the client to adopt (typical for OCIO clients) rather than receiving the client's own document.", "Investment Policy Statement", "Boolean", "", "Y", "Internal", "", ""),
       ("Governing Body Approval Date", "Date the client's board, trustees or investment committee approved the version.", "Investment Policy Statement", "Date", "ISO 8601", "2026-05-14", "CFA Institute IPS guidance", "", "Y"),
       ("IPS Effective Date", "Date from which the version governs the mandates.", "Investment Policy Statement", "Date", "ISO 8601", "2026-07-01", "Internal", "", "Y"),
       ("Return Objective", "Return the policy seeks, stated as the client states it.", "Investment Policy Statement", "Text", "", "CPI + 5% net of fees over rolling 10-year periods", "CFA Institute IPS guidance", "", ""),
       ("Spending Policy Method", "Method the institution uses to set annual spending or distributions from the portfolio, where it has one.", "Investment Policy Statement", "Code", "Spending Policy Method", "Percent of Trailing Average Market Value", "Internal", "UPMIFA", "", "UPMIFA sets a prudence standard, not a method; for a private foundation the binding figure is the IRC section 4942 minimum distribution (5%)."),
       ("Spending Rate", "Annual spending rate under the spending policy.", "Investment Policy Statement", "Percentage", "", "4.5%", "Internal", "UPMIFA", "", "See Spending Policy Method (IRC section 4942 for private foundations)."),
       ("Risk Tolerance Statement", "Client's statement of the risk it is willing to bear (for example a drawdown or volatility tolerance); binding guidelines are the 01 Investment Restrictions of the mandates.", "Investment Policy Statement", "Text", "", "Maximum peak-to-trough decline of 25% over a market cycle", "CFA Institute IPS guidance", "", ""),
       ("Minimum Liquidity Percentage", "Share of the portfolio the policy requires to be convertible to cash within 30 days for spending, benefit payments or capital calls.", "Investment Policy Statement", "Percentage", "", "15%", "CFA Institute IPS guidance", "", ""),
       ("Policy Allocation", "Strategic asset allocation (24) the policy adopts as its long-term target and ranges.", "Investment Policy Statement", "Reference (Asset Allocation Policy, 24)", "", "MND-01234 v3", "Internal", "", "", "CW-147: 24 masters the allocation; the IPS points at it. Key in the 24 form '<policy subject> v<version>' once 24 adds the client or mandate subject (24/32 fix pass); forced to 24 in OWNERSHIP_OVERRIDES because the MND- subject would resolve to 01."),
       ("Governed Mandates", "Mandates (01) managed under this policy version.", "Investment Policy Statement", "Reference (Investment Mandate) (multi)", "", "MND-01234; MND-01240", "Internal", "", "Y"),
       ("IPS Review Frequency", "How often the policy must be reviewed with the client.", "Investment Policy Statement", "Code", "Frequency", "Annual", "CFA Institute IPS guidance", "", ""),
       ("Next IPS Review Due Date", "Date by which the next review of the policy is due.", "Investment Policy Statement", "Date", "ISO 8601", "2027-05-31", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Client Service Model", "IS-SVC",
  "How the firm services each institutional relationship after it is won: the service relationship with its OCIO or plan sponsor servicing detail, the institutional service tier and service standards it receives, and the service staff assigned to it. The relationship manager of record is the 03 Party Coverage Assignment (CW-138).",
  [
   ("Service Relationship", "The servicing view of an Institutional Client: which mandates, pooled vehicles and plans are serviced together, in which segment and tier, by which legal entity.", [
     ("Service Relationship", [
       ("Service Relationship ID", "Unique identifier of the servicing relationship with an institutional client.", "Service Relationship", "Identifier", "", "SVR-00412", "Internal", "Salesforce Service Cloud", "Y", "Object PII tier: No PII."),
       ("Client", "Institutional Client (OCIO, institutional mandate or plan sponsor client) being serviced.", "Service Relationship", "Reference (Institutional Client, 12)", "", "PTY-301180", "Internal", "", "Y", "Re-pointed from Reference (Party) to the restored profile (CW-133); the key is the client's PTY-."),
       ("Servicing Segment", "Client segment that drives the service model.", "Service Relationship", "Code", "Servicing Segment", "OCIO", "Internal", "", "Y"),
       ("Relationship Business Line", "Business line (CW-004) under which the relationship is serviced.", "Service Relationship", "Code", "Business Line", "IA", "Internal", "", ""),
       ("Serviced Mandates", "Mandates (01) serviced under the relationship.", "Service Relationship", "Reference (Investment Mandate) (multi)", "", "MND-01234; MND-01240", "Internal", "", "Y"),
       ("Serviced Pooled Vehicles", "Firm mutual funds, ETFs or collective investment trusts (01) the client invests in that are serviced under the relationship.", "Service Relationship", "Reference (Product / Share Class) (multi)", "", "PRD-00981", "Internal", "", ""),
       ("Advising Consultant", "Investment consultant engagement (05) advising the client, as recorded on the consultant advisory relationship.", "Service Relationship", "Reference (Consultant Advisory Relationship, 05)", "", "PTY-100670 / PTY-301120 / 2019-07-01", "Internal", "", "", "Consultant relations are 05 (W4, CW-132); re-pointed from the wholesale 02 relationship."),
       ("Service Tier", "Institutional service tier assigned to the relationship (not the 01 retail Service Tier).", "Service Relationship", "Code", "Institutional Service Tier", "Tier 1 - Strategic", "Internal", "", ""),
       ("Servicing Legal Entity", "Internal legal entity (09) that contracts with and services the client: the registered investment adviser for OCIO and mandates, the trust company for collective investment trusts, or the recordkeeping entity for plan sponsors.", "Service Relationship", "Reference (Legal Entity)", "", "LEN-0004", "Internal", "", ""),
       ("Relationship Start Date", "Date servicing of the relationship began.", "Service Relationship", "Date", "ISO 8601", "2019-10-01", "Internal", "", ""),
       ("Service Relationship Status", "Lifecycle status of the servicing relationship.", "Service Relationship", "Code", "Service Relationship Status", "Active", "Internal", "", "Y"),
     ]),
     ("OCIO Service Detail", [
       ("OCIO Delegation Scope", "How much investment discretion the client has delegated to the firm as outsourced chief investment officer.", "OCIO Service Detail", "Code", "OCIO Delegation Scope", "Full Discretion", "Internal", "", "Y", "Object PII tier: No PII."),
       ("ERISA Fiduciary Status", "Fiduciary capacity in which the firm acts for plan assets: investment manager with discretion under ERISA section 3(38), co-fiduciary adviser under section 3(21), or not an ERISA fiduciary.", "OCIO Service Detail", "Code", "ERISA Fiduciary Status", "Not ERISA", "ERISA", "29 U.S.C. 1002", "Y", "For a plan the firm recordkeeps, the 16 Plan Role Assignment (3(38) or 3(21) role) is the master and this value must agree with it. For a non-OCIO separate-account mandate of an ERISA plan the status is held on the investment management agreement (39), not here (SME lever)."),
       ("OCIO Service Offering", "OCIO service offering (01) the relationship is delivered under.", "OCIO Service Detail", "Reference (Service Offering)", "", "OFFR-0031", "Internal", "", ""),
       ("Total Portfolio Indicator", "Whether the firm manages the client's total portfolio rather than a carve-out of it.", "OCIO Service Detail", "Boolean", "", "Y", "Internal", "", ""),
       ("Delegated Asset Share", "Share of the client's total investable assets delegated to the firm.", "OCIO Service Detail", "Percentage", "", "100%", "Internal", "", ""),
       ("Managers in Scope", "External manager engagements (52) in the client's OCIO portfolio that the firm oversees and reports on.", "OCIO Service Detail", "Reference (Sub-Adviser Engagement, 52) (multi)", "", "SADV-00412; SADV-00418", "Internal", "", "", "CW-147: 52 masters the managers and their due diligence."),
       ("Governing IPS", "Investment policy statement version the OCIO service is delivered under.", "OCIO Service Detail", "Reference (Investment Policy Statement, 12)", "", "IPSV-301180-04", "Internal", "", "Y"),
     ]),
     ("Plan Sponsor Servicing Detail", [
       ("Sponsor Service Relationship", "Plan sponsor service relationship the plan is serviced under; with the plan it keys the record.", "Plan Sponsor Servicing Detail", "Reference (Service Relationship)", "", "SVR-00431", "Internal", "", "Y", "Object PII tier: No PII. Key format: <SVR- id> / <PTY- id of the retirement plan>. CW-146: 16 owns the plan, 12 owns the service."),
       ("Serviced Retirement Plan", "Retirement plan (02 thin identity; administered in 16) whose sponsor the relationship services.", "Plan Sponsor Servicing Detail", "Reference (Retirement Plan)", "", "PTY-301121", "Internal", "DOL Form 5500", "Y"),
       ("Recordkeeping Service Arrangement", "Recordkeeping service arrangement (16) under which the firm administers the plan.", "Plan Sponsor Servicing Detail", "Reference (Service Arrangement, 16)", "", "PSVA-00921", "Internal", "", ""),
       ("Plan Fiduciary Committee", "Plan role assignment (16) of the sponsor's fiduciary or investment committee (an ERISA section 402(a) named fiduciary) that receives reviews and reports.", "Plan Sponsor Servicing Detail", "Reference (Plan Role Assignment, 16)", "", "PROL-2026-018812", "Internal", "ERISA", "", "Role value 'Plan Fiduciary Committee' is added to the 16 plan role list (16 fix pass)."),
       ("Plan Review Cadence", "How often the firm holds a plan review with the sponsor's committee.", "Plan Sponsor Servicing Detail", "Code", "Frequency", "Semi-Annual", "Internal", "", ""),
       ("Sponsor Portal Access Indicator", "Whether the sponsor uses the firm's plan sponsor portal for reports, payroll files and approvals.", "Plan Sponsor Servicing Detail", "Boolean", "", "Y", "Internal", "", ""),
     ]),
   ]),
   ("Service Tiers & Standards", "Institutional service tiers that bundle entitlements, and the measurable service standards the firm commits to.", [
     ("Institutional Service Tier", [
       ("Service Tier Code", "Code of the institutional service tier; the tier's natural key.", "Institutional Service Tier", "Code", "Institutional Service Tier", "Tier 1 - Strategic", "Internal", "", "Y", "Object PII tier: No PII. Renamed from Service Tier: 01 Service Tier is the retail tier (CW-028, CW-145)."),
       ("Tier Eligibility Criteria", "Rules that place a relationship in the tier (assets, revenue, complexity, strategic value).", "Institutional Service Tier", "Text", "", "Relationship assets over USD 1bn or OCIO full discretion", "Internal", "", ""),
       ("Standard Review Meeting Cadence", "Frequency of review meetings the tier is entitled to.", "Institutional Service Tier", "Code", "Frequency", "Quarterly", "Internal", "", ""),
       ("Standard Reporting Frequency", "Default frequency of the core client report for the tier.", "Institutional Service Tier", "Code", "Frequency", "Monthly", "Internal", "", ""),
     ]),
     ("Service Standard", [
       ("Service Standard ID", "Unique identifier of the service standard.", "Service Standard", "Identifier", "", "SLA-0031", "Internal", "", "", "Object PII tier: No PII."),
       ("Service Standard Metric", "What the standard measures.", "Service Standard", "Code", "Service Standard Metric", "Report Delivery Timeliness", "Internal", "ITIL", "Y"),
       ("Target Value", "Target the firm commits to, in the target unit.", "Service Standard", "Decimal", "", "10", "Internal", "", ""),
       ("Target Unit", "Unit of the target value.", "Service Standard", "Code", "SLA Unit", "Business Days After Period End", "Internal", "", ""),
       ("Contractual Indicator", "Whether the standard is written into the investment management agreement, the plan service agreement or a service-level schedule (rather than an internal target).", "Service Standard", "Boolean", "", "Y", "Internal", "", ""),
       ("Applies To Tier / Relationship", "Institutional service tier or specific relationship the standard applies to.", "Service Standard", "Reference (Institutional Service Tier / Service Relationship)", "", "SVR-00412", "Internal", "", ""),
       ("Standard Effective From", "Date the standard took effect.", "Service Standard", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
     ]),
   ]),
   ("Service Team & Coverage", "Service teams and the effective-dated assignment of service staff in servicing roles to relationships and mandates.", [
     ("Service Team", [
       ("Service Team ID", "Unique identifier of the service team or pod.", "Service Team", "Identifier", "", "SVT-INST-02", "Internal", "", "", "Object PII tier: PII - identity (team lead)."),
       ("Service Team Name", "Name of the team.", "Service Team", "Text", "", "Endowments & Foundations Client Service", "Internal", "", ""),
       ("Service Team Business Line", "Business line (CW-004) the team serves.", "Service Team", "Code", "Business Line", "IA", "Internal", "", ""),
       ("Service Team Lead", "Employee (20) leading the team.", "Service Team", "Reference (Employee)", "", "EMP-02210", "Internal", "", "", "PII"),
     ]),
     ("Service Coverage Assignment", [
       ("Service Assignment ID", "Unique identifier of the assignment.", "Service Coverage Assignment", "Identifier", "", "SVA-008812", "Internal", "", "", "Object PII tier: PII - identity (employee)."),
       ("Assigned Service Employee", "Employee (20) assigned to service the relationship or mandate.", "Service Coverage Assignment", "Reference (Employee)", "", "EMP-02231", "Internal", "", "Y", "PII"),
       ("Service Role", "Servicing role the employee plays for the client; the relationship manager of record is held on the 03 Party Coverage Assignment, not here (CW-138).", "Service Coverage Assignment", "Code", "Service Role", "Client Service Manager", "Internal", "", "Y"),
       ("Covered Service Relationship", "Relationship covered.", "Service Coverage Assignment", "Reference (Service Relationship)", "", "SVR-00412", "Internal", "", ""),
       ("Covered Mandate", "Mandate (01) covered, where the assignment is mandate-specific (for example a client portfolio manager per strategy).", "Service Coverage Assignment", "Reference (Investment Mandate)", "", "MND-01234", "Internal", "", ""),
       ("Primary Contact Indicator", "Whether the employee is the client's primary contact for the role.", "Service Coverage Assignment", "Boolean", "", "Y", "Internal", "", ""),
       ("Service Team", "Team the assignment belongs to.", "Service Coverage Assignment", "Reference (Service Team)", "", "SVT-INST-02", "Internal", "", ""),
       ("Assignment Effective From", "Date the assignment started.", "Service Coverage Assignment", "Date", "ISO 8601", "2025-04-01", "Internal", "", ""),
       ("Assignment Effective To", "Date the assignment ended; blank while current.", "Service Coverage Assignment", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Report Definition & Content", "IS-RDF",
  "What the firm reports to institutional clients and plan sponsors: report definitions and their content components, templates and branding, and the report packages assembled for each relationship.",
  [
   ("Report Definition", "The catalog of standard and bespoke client reports.", [
     ("Report Definition", [
       ("Report Definition ID", "Unique identifier of the report definition.", "Report Definition", "Identifier", "", "RPT-0107", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Report Name", "Name of the report.", "Report Definition", "Text", "", "Quarterly OCIO Total Portfolio Report", "Internal", "", ""),
       ("Report Type", "Type of client report.", "Report Definition", "Code", "Report Type", "OCIO Total Portfolio Report", "Internal", "", "Y"),
       ("Report Scope Level", "Level the report is produced for.", "Report Definition", "Code", "Report Scope Level", "Client Relationship", "Internal", "", ""),
       ("Standard / Bespoke Indicator", "Whether the report is a standard firm report, a standard report with client options, or built for one client.", "Report Definition", "Code", "Report Customization", "Standard", "Internal", "", ""),
       ("Regulatory Driver", "Contract, rule or industry standard that requires or shapes the report, if any.", "Report Definition", "Code (multi)", "Reporting Driver", "Client IMA / Contract; GIPS", "Internal", "GIPS", ""),
       ("Report Template", "Template used to render the report.", "Report Definition", "Reference (Report Template)", "", "TPL-0012", "Internal", "", ""),
       ("Available Languages", "Languages the report is produced in.", "Report Definition", "Code (multi)", "ISO 639-1", "en; es", "Internal", "", ""),
       ("Stewardship Report Scope", "Stewardship content included for the client: proxy votes cast for the client's mandates (34 voting record; Advisers Act Rule 206(4)-6) and for its pooled vehicles (fund Form N-PX), engagement activity and the proxy voting policy summary.", "Report Definition", "Code (multi)", "Stewardship Content", "Proxy Voting Record; Engagement Case Studies", "Internal", "SEC Rule 206(4)-6", "", "Moved here from the dropped Template Adoption (CW-145); re-sourced (CW-912) to Rule 206(4)-6, Rule 14Ad-1 (say-on-pay votes on the firm's own Form N-PX as a Form 13F manager) and fund Form N-PX for pooled vehicles only."),
     ]),
   ]),
   ("Report Components", "Reusable content blocks that make up a report.", [
     ("Report Component", [
       ("Component ID", "Unique identifier of the content component.", "Report Component", "Identifier", "", "RCM-0451", "Internal", "", "", "Object PII tier: No PII."),
       ("Component Type", "Kind of content the component shows.", "Report Component", "Code", "Report Component Type", "Performance Summary", "Internal", "", ""),
       ("Commentary Required Indicator", "Whether the component needs written commentary from the investment team.", "Report Component", "Boolean", "", "Y", "Internal", "", ""),
       ("Mandatory Component Indicator", "Whether the component is required (for example a GIPS or Advisers Act disclosure) and cannot be removed for a client.", "Report Component", "Boolean", "", "Y", "Internal", "GIPS", ""),
     ]),
   ]),
   ("Templates & Branding", "Layouts and branding applied to client reports.", [
     ("Report Template", [
       ("Template ID", "Unique identifier of the template.", "Report Template", "Identifier", "", "TPL-0012", "Internal", "", "", "Object PII tier: No PII."),
       ("Template Name", "Name of the template.", "Report Template", "Text", "", "Institutional Quarterly - Corporate Brand v4", "Internal", "", ""),
       ("Output Format", "File or rendering format produced.", "Report Template", "Code", "Report Output Format", "PDF", "Internal", "", ""),
       ("Brand", "Brand (42) applied to the template.", "Report Template", "Reference (Brand)", "", "BRD-001", "Internal", "", ""),
       ("Co-Branding / White-Label Type", "Whether the report carries the firm's brand, is co-branded with the client or its consultant, or is delivered as unbranded data.", "Report Template", "Code", "Branding Type", "Firm Brand", "Internal", "", ""),
     ]),
   ]),
   ("Report Packages", "The set of reports each relationship receives, with relationship-specific settings.", [
     ("Report Package", [
       ("Report Package ID", "Unique identifier of the client report package.", "Report Package", "Identifier", "", "RPK-00388", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Package Client", "Service relationship the package is produced for.", "Report Package", "Reference (Service Relationship)", "", "SVR-00412", "Internal", "", "Y"),
       ("Included Report Definitions", "Report definitions in the package, in order.", "Report Package", "Reference (Report Definition) (multi)", "", "RPT-0107; RPT-0115; RPT-0140", "Internal", "", "Y"),
       ("Covered Mandates / Vehicles", "Mandates (01) and pooled vehicles (01: the firm's funds and CITs the client invests in) the package reports on.", "Report Package", "Reference (Investment Mandate / Product) (multi)", "", "MND-01234; MND-01240", "Internal", "", ""),
       ("Covered Retirement Plans", "Retirement plans (02 thin identity; administered in 16) a plan sponsor package reports on.", "Report Package", "Reference (Retirement Plan) (multi)", "", "PTY-301121", "Internal", "", ""),
       ("Consolidation Level", "Whether the package reports mandates or plans separately or consolidated.", "Report Package", "Code", "Consolidation Level", "Consolidated and by Mandate", "Internal", "", ""),
       ("Package Frequency", "Production frequency of the package.", "Report Package", "Code", "Frequency", "Quarterly", "Internal", "", ""),
       ("Package Effective From", "Date the package configuration took effect.", "Report Package", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Performance & Holdings Presentation", "IS-PPR",
  "Reference data that controls how performance, portfolio holdings and GIPS information are presented to each client. Return values are produced in 32 and portfolio holding values in 18; this family records the presentation choices and disclosures.",
  [
   ("Performance Presentation Profile", "Return types, fee basis, currency, periods and benchmarks shown in a client's reports.", [
     ("Presentation Profile", [
       ("Presentation Profile ID", "Unique identifier of the presentation profile.", "Presentation Profile", "Identifier", "", "PPP-00211", "Internal", "", "", "Object PII tier: No PII."),
       ("Applies To Package / Mandate", "Report package or mandate the profile applies to.", "Presentation Profile", "Reference (Report Package / Investment Mandate)", "", "RPK-00388", "Internal", "", ""),
       ("Return Methodology Shown", "Return calculation method (time-weighted or money-weighted) the client sees.", "Presentation Profile", "Code", "Return Methodology", "Time-Weighted", "GIPS", "", "Y"),
       ("Fee Basis Shown", "Whether returns are shown gross of fees, net of fees, or both.", "Presentation Profile", "Code", "Fee Basis", "Gross and Net", "GIPS", "SEC Rule 206(4)-1", "Y"),
       ("Reporting Currency", "Currency in which returns and values are shown.", "Presentation Profile", "Code", "ISO 4217", "USD", "Internal", "", "Y"),
       ("Primary Benchmark Shown", "Benchmark (01) shown alongside the mandate's returns; normally the mandate's primary benchmark or the IPS policy benchmark, but may be client-specified.", "Presentation Profile", "Reference (Benchmark)", "", "BMK-0001", "GIPS", "", "Y"),
       ("Periods Shown", "Return periods shown.", "Presentation Profile", "Code (multi)", "Return Period", "QTD; YTD; 1Y; 3Y; 5Y; Since Inception", "GIPS", "", ""),
       ("Performance Start Date Shown", "Date from which the client's own track record is shown (usually the mandate funding date).", "Presentation Profile", "Date", "ISO 8601", "2019-10-01", "Internal", "", ""),
       ("Net Return Fee Treatment", "Whether net returns use actual or model fees.", "Presentation Profile", "Code", "Net Fee Treatment", "Actual Fees", "GIPS", "SEC Rule 206(4)-1", ""),
     ]),
   ]),
   ("Holdings & Look-Through Presentation", "How portfolio holdings, exposures and look-through are shown.", [
     ("Portfolio Holdings Presentation", [
       ("Portfolio Holdings Detail Level", "Level of 18 Portfolio Holding detail shown.", "Presentation Profile", "Code", "Portfolio Holdings Detail Level", "Full Portfolio Holdings", "Internal", "", "", "Object PII tier: No PII."),
       ("Look-Through Indicator", "Whether the portfolio holdings of pooled vehicles in the mandate are shown on a look-through basis.", "Presentation Profile", "Boolean", "", "Y", "Internal", "", ""),
       ("Look-Through Template", "Template used for look-through data, if any.", "Presentation Profile", "Code", "Look-Through Template", "Firm Look-Through File", "Internal", "", ""),
       ("Portfolio Holdings Disclosure Lag Days", "Lag applied before the 18 Portfolio Holdings of a pooled vehicle are disclosed, in line with the fund's portfolio holdings disclosure policy.", "Presentation Profile", "Integer", "Days", "30", "SEC Form N-1A Item 16(f)", "SEC Form N-PORT", "", "The fund's portfolio holdings disclosure policy (Form N-1A Item 16(f), described in the SAI) sets the lag; N-PORT gives only the public timing (2024 amendments, compliance dates extended; confirm)."),
     ]),
   ]),
   ("GIPS Disclosure Requirements", "GIPS composite reporting for the strategy behind a mandate, and when GIPS Reports must be provided or updated.", [
     ("GIPS Report Provision", [
       ("Related GIPS Composite", "GIPS composite (01) the mandate belongs to.", "Report Definition", "Reference (Composite)", "", "CMP-0045", "GIPS", "", "Y", "Object PII tier: No PII."),
       ("GIPS Report Type", "Type of GIPS Report provided.", "Report Definition", "Code", "GIPS Report Type", "Composite Time-Weighted Return Report", "GIPS", "", ""),
       ("GIPS Report Required Indicator", "Whether a GIPS Report must be provided (prospective clients) or is provided by choice (existing clients).", "Report Definition", "Boolean", "", "N", "GIPS", "", ""),
       ("GIPS Report As-Of Date", "Annual period end of the GIPS Report version provided; must be updated within 12 months of each annual period end.", "Report Definition", "Date", "ISO 8601", "2025-12-31", "GIPS", "", ""),
       ("Required Disclosure Set", "Set of GIPS numerical information and disclosures included (for example dispersion, 3-year standard deviation, composite and firm assets).", "Report Definition", "Code (multi)", "GIPS Disclosure Item", "Internal Dispersion; 3Y Ex-Post Std Dev; Composite Assets", "GIPS", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Report Production & Delivery", "IS-RPD",
  "When and how reports are produced and delivered: schedules and cut-offs, production runs with review, sign-off, versions and restatements, distribution lists and delivery records.",
  [
   ("Report Schedule", "Production calendar for a package or report.", [
     ("Report Schedule", [
       ("Scheduled Package / Report", "Package the schedule belongs to (the parent Report Package); kept for its readers, it repeats the parent key.", "Report Schedule", "Reference (Report Package / Report Definition)", "", "RPK-00388", "Internal", "", "", "Object PII tier: No PII."),
       ("Data Cut-Off Offset", "Business days after period end at which data is frozen.", "Report Schedule", "Integer", "Days", "5", "Internal", "", ""),
       ("Delivery Due Offset", "Business days after period end by which the report must be delivered.", "Report Schedule", "Integer", "Days", "10", "Internal", "", "Y"),
       ("Business Calendar", "Business-day calendar (09) used to compute the dates.", "Report Schedule", "Reference (Calendar)", "", "CAL-US-NYSE", "Internal", "", ""),
     ]),
   ]),
   ("Report Production Run", "Each production instance of a report or package for a period, with its control evidence.", [
     ("Report Run", [
       ("Report Run ID", "Unique identifier of the production run.", "Report Run", "Identifier", "", "RRN-2026Q3-004512", "Internal", "", "Y", "Object PII tier: PII - identity (sign-off employee)."),
       ("Run Package / Report", "Package or report produced.", "Report Run", "Reference (Report Package / Report Definition)", "", "RPK-00388", "Internal", "", ""),
       ("Reporting Period End", "Last day of the period reported (as-of date).", "Report Run", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
       ("Data Cut-Off Timestamp", "When source data was frozen for the run.", "Report Run", "Timestamp", "ISO 8601", "2026-10-07T18:00:00-04:00", "Internal", "", ""),
       ("Production Status", "Status of the run.", "Report Run", "Code", "Production Status", "Signed Off", "Internal", "", "Y"),
       ("Signed Off By", "Employee (20) who approved release to the client.", "Report Run", "Reference (Employee)", "", "EMP-02210", "Internal", "", "Y", "PII"),
       ("Sign-Off Timestamp", "When release was approved.", "Report Run", "Timestamp", "ISO 8601", "2026-10-12T15:20:00-04:00", "Internal", "SEC Rule 204-2", "Y"),
       ("Version Number", "Version of the run output; increments on reissue.", "Report Run", "Integer", "", "1", "Internal", "", ""),
       ("Restatement Indicator", "Whether the run restates a previously delivered report.", "Report Run", "Boolean", "", "N", "Internal", "GIPS", "Y"),
       ("Restatement Reason", "Why the report was restated.", "Report Run", "Code", "Restatement Reason", "Pricing Correction", "Internal", "GIPS", "", "When the cause is a return restatement, the restatement itself is the 32 Performance Restatement, which flags the client reports to reissue."),
       ("Compliance Review", "Compliance review (08) of the report content where required, for example a one-on-one presentation that shows hypothetical or extracted performance.", "Report Run", "Reference (Compliance Review)", "", "REV-2026-008812", "SEC Rule 206(4)-1", "", ""),
       ("Commentary Used", "Investment commentaries (01) included in the report.", "Report Run", "Reference (Investment Commentary) (multi)", "", "CMT-2026Q3-00412", "Internal", "", ""),
       ("SLA Met Indicator", "Whether the run was produced and signed off within the production service standard (delivery timeliness is on Report Delivery).", "Report Run", "Boolean", "", "Y", "Internal", "", ""),
     ]),
   ]),
   ("Recipients & Distribution", "Who receives each package and how.", [
     ("Distribution List", [
       ("Distribution List ID", "Unique identifier of the distribution list.", "Distribution List", "Identifier", "", "DLS-00977", "Internal", "", "", "Object PII tier: PII - identity (individual recipients)."),
       ("Distribution Package", "Package distributed to the list.", "Distribution List", "Reference (Report Package)", "", "RPK-00388", "Internal", "", ""),
       ("Recipient", "Person or organization (02) that receives the package: a trustee, committee member, staff officer, consultant or custodian.", "Distribution List", "Reference (Party)", "", "PTY-500881", "Internal", "", "", "PII (where an individual)."),
       ("Delivery Channel", "Channel used to deliver to the recipient.", "Distribution List", "Code", "Delivery Channel", "Client Portal", "Internal", "", "Y"),
       ("Delivery Contact Point", "Email or postal contact point (02) used.", "Distribution List", "Reference (Contact Point)", "", "CTP-0091245", "Internal", "", "", "PII"),
       ("Delivery Endpoint", "SFTP host and path, portal space or API endpoint for non-email delivery.", "Distribution List", "Text", "URI", "sftp://reports.example.com/clients/PTY-301180/", "Internal", "", ""),
     ]),
     ("Report Delivery", [
       ("Delivered Run", "Run delivered.", "Report Delivery", "Reference (Report Run)", "", "RRN-2026Q3-004512", "Internal", "", "Y", "Object PII tier: PII - identity (individual recipients). Key format: <RRN- id> / <PTY- id of the recipient>."),
       ("Delivery Recipient", "Recipient (02) of the delivery.", "Report Delivery", "Reference (Party)", "", "PTY-500881", "Internal", "", "", "PII"),
       ("Delivery Status", "Outcome of the delivery.", "Report Delivery", "Code", "Delivery Status", "Delivered", "Internal", "", "Y"),
       ("Delivered Timestamp", "When the delivery completed.", "Report Delivery", "Timestamp", "ISO 8601", "2026-10-13T08:00:00-04:00", "Internal", "", "Y"),
       ("Portal Document Reference", "Identifier of the document on the institutional client or plan sponsor portal (the portal is a 04 Digital Property).", "Report Delivery", "Identifier", "", "WEB-004/doc/88123", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Guideline Monitoring & Breach Reporting", "IS-GBR",
  "How compliance with each mandate's investment guidelines is monitored and certified to the client, and how guideline breaches are notified to the client and cured. The restrictions are owned by 01 and the breaches by 33 (CD-222). Client notification covers 01 mandate restrictions; 02 client restrictions on a 33 breach are retail and out of scope here.",
  [
   ("Monitoring Arrangement", "Client-facing guideline monitoring and certification commitments per mandate.", [
     ("Guideline Monitoring Arrangement", [
       ("Monitored Mandate", "Mandate (01) being monitored.", "Guideline Monitoring Arrangement", "Reference (Investment Mandate)", "", "MND-01234", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Monitored Restrictions", "Investment restrictions (01) monitored for the client.", "Guideline Monitoring Arrangement", "Reference (Restriction) (multi)", "", "RST-55012; RST-55013", "Internal", "", ""),
       ("Breach Notification Deadline", "Contractual deadline, in business days after detection, for notifying the client of a breach.", "Guideline Monitoring Arrangement", "Integer", "Days", "2", "Internal", "", "Y"),
       ("Consultant Notification Required Indicator", "Whether the client's investment consultant must be copied on breach notifications.", "Guideline Monitoring Arrangement", "Boolean", "", "Y", "Internal", "", ""),
       ("Compliance Certificate Frequency", "How often the firm certifies guideline compliance to the client.", "Guideline Monitoring Arrangement", "Code", "Frequency", "Quarterly", "Internal", "", "Y"),
     ]),
   ]),
   ("Breach Notification", "Client-facing record of guideline breaches and their cure.", [
     ("Breach Notification", [
       ("Breach Notification ID", "Unique identifier of the breach notification record.", "Breach Notification", "Identifier", "", "GBN-2026-00143", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Related Investment Breach", "Investment breach (33) that this client notification reports.", "Breach Notification", "Reference (Investment Breach, 33)", "", "BREACH-2026-00143", "Internal", "", "Y", "CD-222: the breach facts are mastered on the 33 Investment Breach; 12 keeps the client notification facts (requirement, deadline, notified timestamp)."),
       ("Breached Mandate", "Mandate (01) in breach.", "Breach Notification", "Reference (Investment Mandate)", "", "MND-01234", "Internal", "", ""),
       ("Breached Restriction", "Investment restriction (01) breached.", "Breach Notification", "Reference (Restriction)", "", "RST-55012", "Internal", "", "Y", "Value as held on the 33 Investment Breach.Breached Restriction of the Related Investment Breach (CD-222); it stays a reference to the 01 Investment Restriction, so it is not flagged Derived copy."),
       ("Breach Type", "Whether the breach was caused by the firm's action or by market movement.", "Breach Notification", "Code", "Breach Type", "Passive", "Internal", "", "", "Derived copy of 33 Investment Breach.Breach Type of the Related Investment Breach (CD-222). The CDE flag sits on the master (33)."),
       ("Breach Detected Date", "Date the breach was detected.", "Breach Notification", "Date", "ISO 8601", "2026-09-14", "Internal", "", "", "Derived copy of 33 Investment Breach.Breach Detected Date of the Related Investment Breach (CD-222)."),
       ("Client Notification Required Indicator", "Whether the breach must be notified to the client under the investment management agreement.", "Breach Notification", "Boolean", "", "Y", "Internal", "", "Y"),
       ("Client Notified Timestamp", "When the client was notified.", "Breach Notification", "Timestamp", "ISO 8601", "2026-09-15T10:12:00-04:00", "Internal", "", "Y"),
       ("Cure Action", "How the breach was cured.", "Breach Notification", "Code", "Cure Action", "Sell Down", "Internal", "", "", "Derived copy of 33 Investment Breach.Cure Action of the Related Investment Breach (CD-222)."),
       ("Cure Date", "Date the mandate was back within limits.", "Breach Notification", "Date", "ISO 8601", "2026-09-16", "Internal", "", "", "Derived copy of 33 Investment Breach.Cure Date of the Related Investment Breach (CD-222)."),
     ]),
   ]),
   ("Compliance Certification", "Periodic compliance certificates to clients.", [
     ("Compliance Certificate", [
       ("Certified Mandate", "Mandate (01) the certificate covers.", "Compliance Certificate", "Reference (Investment Mandate)", "", "MND-01234", "Internal", "", "Y", "Object PII tier: PII - identity (certifying officer). Key format: <MND- id> / <certificate period end>."),
       ("Certificate Period End", "Period end the certificate covers.", "Compliance Certificate", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
       ("Exceptions Reported Indicator", "Whether breaches or exceptions are listed in the certificate.", "Compliance Certificate", "Boolean", "", "Y", "Internal", "", ""),
       ("Certifying Officer", "Employee (20) who signed the certificate.", "Compliance Certificate", "Reference (Employee)", "", "EMP-03010", "Internal", "", "", "PII"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Client Service Requests & Instructions", "IS-CSR",
  "Requests and instructions received from institutional clients, plan sponsors and their consultants and auditors, from data requests and ad-hoc reports to contribution and withdrawal notifications, with their service level and resolution. Participant requests are 13; complaints are 08 (CW-070).",
  [
   ("Service Request", "Case record for each relationship-level request.", [
     ("Client Service Request", [
       ("Service Request ID", "Unique identifier of the request.", "Client Service Request", "Identifier", "", "CSR-2026-018832", "Internal", "Salesforce Service Cloud", "Y", "Object PII tier: PII - identity (individual requesters)."),
       ("Request Type", "Type of request.", "Client Service Request", "Code", "Institutional Service Request Type", "Ad-Hoc Report", "Internal", "Salesforce Service Cloud", "Y"),
       ("Requesting Party", "Person or organization (02) that raised the request: the client, its consultant, auditor or custodian, or a plan sponsor representative.", "Client Service Request", "Reference (Party)", "", "PTY-500881", "Internal", "", "", "PII (where an individual)."),
       ("Request Service Relationship", "Relationship the request relates to.", "Client Service Request", "Reference (Service Relationship)", "", "SVR-00412", "Internal", "", ""),
       ("Request Mandate", "Mandate (01) the request relates to, if specific.", "Client Service Request", "Reference (Investment Mandate)", "", "MND-01234", "Internal", "", ""),
       ("Request Received Timestamp", "When the request was received; starts service level timing.", "Client Service Request", "Timestamp", "ISO 8601", "2026-09-22T09:14:00-04:00", "Salesforce Service Cloud", "", ""),
       ("Request Status", "Status of the request.", "Client Service Request", "Code", "Request Status", "In Progress", "Salesforce Service Cloud", "", "Y"),
       ("Request Owner", "Employee (20) accountable for resolution.", "Client Service Request", "Reference (Employee)", "", "EMP-02231", "Salesforce Service Cloud", "", "", "PII"),
       ("Request SLA Due Timestamp", "When the request must be resolved under the applicable service standard.", "Client Service Request", "Timestamp", "ISO 8601", "2026-09-24T17:00:00-04:00", "Salesforce Service Cloud", "", "Y"),
       ("Resolution Code", "How the request was resolved.", "Client Service Request", "Code", "Resolution Code", "Fulfilled", "Internal", "", ""),
       ("Related Complaint", "Complaint (08) raised from the request, where the request is a written grievance that meets the complaint definition.", "Client Service Request", "Reference (Complaint, 08)", "", "CPL-2026-000412", "Internal", "", ""),
     ]),
   ]),
   ("Cash Flow Notification", "Client notifications of contributions to and withdrawals from mandates. The resulting flow transactions are owned by 06.", [
     ("Cash Flow Notification", [
       ("Cash Flow Notification ID", "Unique identifier of the notification.", "Cash Flow Notification", "Identifier", "", "CFN-2026-00788", "Internal", "", "", "Object PII tier: PII - identity (authorized signatory)."),
       ("Notified Mandate", "Mandate (01) the flow applies to.", "Cash Flow Notification", "Reference (Investment Mandate)", "", "MND-01234", "Internal", "", "Y"),
       ("Flow Direction", "Whether the flow is a contribution or a withdrawal.", "Cash Flow Notification", "Code", "Flow Direction", "Withdrawal", "Internal", "", "Y"),
       ("Notified Amount", "Amount notified by the client.", "Cash Flow Notification", "Amount", "", "USD 25,000,000", "Internal", "", "Y"),
       ("Settlement Form", "Whether the flow is in cash or in kind (in specie).", "Cash Flow Notification", "Code", "Settlement Form", "Cash", "Internal", "", ""),
       ("Requested Value Date", "Date the client wants the flow to settle.", "Cash Flow Notification", "Date", "ISO 8601", "2026-09-17", "Internal", "", "Y"),
       ("Notice Period Met Indicator", "Whether the contractual notice period was met.", "Cash Flow Notification", "Boolean", "", "Y", "Internal", "", ""),
       ("Authorized Signatory", "Client signatory (02) who authorized the instruction.", "Cash Flow Notification", "Reference (Party)", "", "PTY-500890", "Internal", "", "", "PII"),
       ("Call-Back Verification Performed", "Whether the instruction was verified by call-back to a known contact before it was acted on (fraud control).", "Cash Flow Notification", "Boolean", "", "Y", "Internal", "SEC Regulation S-ID", "Y", "Firm call-back policy; Regulation S-ID applies only where the firm's identity theft program designates institutional accounts as covered accounts."),
       ("Linked Transaction", "Resulting contribution or withdrawal flow transaction (06).", "Cash Flow Notification", "Reference (Transaction)", "", "TXN-88812345", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Client Reviews & Relationship Health", "IS-CRV",
  "Formal periodic reviews and governance meetings with institutional clients and plan sponsor committees, and the relationship health score used to manage retention. The meeting itself is a 03 Advisor Activity; relationship surveys are 04 (CW-093).",
  [
   ("Client Review Meeting", "Governance wrapper for annual and quarterly reviews, board, investment committee and plan fiduciary committee meetings, IPS reviews and consultant review meetings.", [
     ("Client Review", [
       ("Client Review ID", "Unique identifier of the review.", "Client Review", "Identifier", "", "CRV-2026-00315", "Internal", "", "", "Object PII tier: No PII."),
       ("Review Type", "Type of review or governance meeting.", "Client Review", "Code", "Client Review Type", "Plan Fiduciary Committee Review", "Internal", "", "Y"),
       ("Reviewed Relationship", "Relationship reviewed.", "Client Review", "Reference (Service Relationship)", "", "SVR-00412", "Internal", "", ""),
       ("Reviewed Mandates", "Mandates (01) covered.", "Client Review", "Reference (Investment Mandate) (multi)", "", "MND-01234", "Internal", "", ""),
       ("Reviewed IPS Version", "Investment policy statement version reviewed, for IPS reviews.", "Client Review", "Reference (Investment Policy Statement, 12)", "", "IPSV-301180-04", "CFA Institute IPS guidance", "", ""),
       ("Review Held Date", "Date the review took place.", "Client Review", "Date", "ISO 8601", "2026-11-18", "Internal", "", ""),
       ("Meeting Activity", "Advisor Activity (03) that records the meeting.", "Client Review", "Reference (Advisor Activity, 03)", "", "ACT-2026-0471120", "Internal", "", ""),
       ("Review Outcome", "Overall outcome reported by the service lead.", "Client Review", "Code", "Review Outcome", "Satisfied", "Internal", "", ""),
     ]),
   ]),
   ("Relationship Health", "Periodic composite score of relationship health and retention risk.", [
     ("Relationship Health Score", [
       ("Health Score Date", "Date of the score snapshot.", "Relationship Health Score", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y", "Object PII tier: No PII. Key format: <SVR- id> / <health score date>."),
       ("Scored Relationship", "Relationship scored.", "Relationship Health Score", "Reference (Service Relationship)", "", "SVR-00412", "Internal", "", "Y"),
       ("Overall Health Score", "Composite score from 0 to 100.", "Relationship Health Score", "Decimal", "", "72", "Internal", "", ""),
       ("Health Status", "RAG status derived from the score.", "Relationship Health Score", "Code", "RAG Status", "Amber", "Internal", "", "Y"),
       ("At-Risk Indicator", "Whether the relationship is flagged as at risk of termination or reduction.", "Relationship Health Score", "Boolean", "", "N", "Internal", "", "Y"),
       ("At-Risk Reason", "Main driver of the at-risk flag.", "Relationship Health Score", "Code", "At-Risk Reason", "Underperformance", "Internal", "", ""),
       ("Survey Inputs", "Relationship survey responses (04) read into the score.", "Relationship Health Score", "Reference (Survey Response, 04) (multi)", "", "SRSP-2026-00918231", "Internal", "", "", "Replaces the dropped Client Feedback Response (CW-093)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Mandate Operational Set-Up", "IS-MOS",
  "Operational set-up that lets a new mandate be funded, traded, settled and reported: the onboarding checklist from the won opportunity to the first report, set-up of the client custodian account at the client's custodian bank (the safekeeping accounts are mastered in 28 and the standing settlement instructions in 26, CD-155 and CD-194), cash-flow arrangements, outbound data feeds to custodians and consultants, and transitions and in-specie transfers.",
  [
   ("Mandate Onboarding", "Checklist that takes a won mandate from signed agreement to funded and reported.", [
     ("Mandate Onboarding", [
       ("Onboarded Mandate", "Mandate (01) being onboarded; with the onboarding start date it keys the record.", "Mandate Onboarding", "Reference (Investment Mandate)", "", "MND-01234", "Internal", "", "Y", "Object PII tier: PII - identity (onboarding owner). Key format: <MND- id> / <onboarding start date>."),
       ("Onboarding Start Date", "Date onboarding began.", "Mandate Onboarding", "Date", "ISO 8601", "2026-07-01", "Internal", "", "Y"),
       ("Won Opportunity", "Sales opportunity (05) whose win started the onboarding.", "Mandate Onboarding", "Reference (Sales Opportunity, 05)", "", "OPP-2026-00231", "Internal", "", ""),
       ("Onboarding Service Relationship", "Service relationship the new mandate joins.", "Mandate Onboarding", "Reference (Service Relationship)", "", "SVR-00412", "Internal", "", ""),
       ("Investment Management Agreement", "Signed investment management agreement or plan service agreement (39).", "Mandate Onboarding", "Reference (Contract)", "", "CTRCT-0004512", "Internal", "", "Y", "Value as held on 15 Institutional Account.Governing Agreement of the Opened Account."),
       ("Opened Account", "Institutional separate account (15) opened for the mandate.", "Mandate Onboarding", "Reference (Account)", "", "ACC-0720011", "Internal", "", ""),
       ("Client Custodian Set-Up", "Client custodian account set-up record for the mandate.", "Mandate Onboarding", "Reference (Client Custodian Account)", "", "CUA-01877", "Internal", "", ""),
       ("Target Funding Date", "Date the client and firm agreed for initial funding.", "Mandate Onboarding", "Date", "ISO 8601", "2026-08-01", "Internal", "", ""),
       ("Actual Funding Date", "Date the initial funding settled.", "Mandate Onboarding", "Date", "ISO 8601", "2026-08-03", "Internal", "", "Y"),
       ("First Report Due Date", "Date the first client report package is due.", "Mandate Onboarding", "Date", "ISO 8601", "2026-10-14", "Internal", "", ""),
       ("Onboarding Checklist Status", "Status of the onboarding checklist.", "Mandate Onboarding", "Code", "Onboarding Checklist Status", "Funded - Reporting Pending", "Internal", "", "Y"),
       ("Onboarding Owner", "Employee (20) coordinating the onboarding.", "Mandate Onboarding", "Reference (Employee)", "", "EMP-02240", "Internal", "", "", "PII (employee)."),
     ]),
   ]),
   ("Client Custodian Account Set-Up", "Accounts opened at the institutional client's custodian bank for the mandate (the client appoints the custodian; not 49 client asset custody and not the funds' 28 network).", [
     ("Client Custodian Account", [
       ("Client Custodian Account Set-Up ID", "Unique identifier of the client custodian account set-up record.", "Client Custodian Account", "Identifier", "", "CUA-01877", "Internal", "", "", "Object PII tier: No PII."),
       ("Client Account", "Institutional separate account (15) the custodian account belongs to.", "Client Custodian Account", "Reference (Account)", "", "ACC-0720011", "Internal", "", ""),
       ("Client Custodian Mandate", "Mandate (01) the account services.", "Client Custodian Account", "Reference (Investment Mandate)", "", "MND-01234", "Internal", "", "", "Value as held on 15 Institutional Account.Related Mandate of the Client Account."),
       ("Custodian", "Client's custodian bank (02 party).", "Client Custodian Account", "Reference (Party)", "", "PTY-100912", "Internal", "", "Y", "Value as held on 15 Institutional Account.Custodian of the Client Account; it stays a reference to the 02 party."),
       ("Custodian BIC", "BIC of the custodian.", "Client Custodian Account", "Identifier", "ISO 9362", "IRVTUS3NXXX", "ISO 9362", "", "Y", "Derived copy of the 02 Party Identifier (scheme BIC) of the Account Provider of the Created Safekeeping Account (CD-013, CD-194). CDE status inherited from the master."),
       ("Safekeeping Account Number", "Securities account number at the custodian.", "Client Custodian Account", "Identifier", "", "123456-01", "SWIFT ISO 15022", "ISO 20022", "Y", "Derived copy of 28 Safekeeping Account.Safekeeping Account Number of the Created Safekeeping Account (CD-194 option A). CDE status inherited from the master. Confidential; restrict access."),
       ("Created Safekeeping Account", "Safekeeping account (28) at the custodian that this set-up caused to be opened.", "Client Custodian Account", "Reference (Safekeeping Account, 28)", "", "SKA-000231", "Internal", "", "", "CD-194 option A: 28 masters the account; 12 keeps the set-up workflow."),
       ("Created Standing Settlement Instructions", "Standing settlement instructions (26) that this set-up caused to be created for the mandate.", "Client Custodian Account", "Reference (Standing Settlement Instruction, 26) (multi)", "", "SSI-0045512", "Internal", "", "", "CD-155 option A: 26 masters every SSI; 12 keeps the set-up workflow."),
     ]),
   ]),
   ("Cash Flow Arrangements", "Agreed terms for contribution and withdrawal notifications per mandate.", [
     ("Cash Flow Arrangement", [
       ("Arrangement Mandate", "Mandate (01) the arrangement applies to.", "Cash Flow Arrangement", "Reference (Investment Mandate)", "", "MND-01234", "Internal", "", "", "Object PII tier: No PII."),
       ("Notice Period Days", "Business days' notice required for flows.", "Cash Flow Arrangement", "Integer", "Days", "5", "Internal", "", "Y"),
       ("Notification Cut-Off Time", "Time by which a notice counts as received that day.", "Cash Flow Arrangement", "Time", "HH:MM + time zone", "12:00 America/New_York", "Internal", "", ""),
     ]),
   ]),
   ("Client Data Feeds", "Outbound data feeds to custodians, consultants and clients. Inbound feeds are owned by 06 (FEED-).", [
     ("Client Data Feed", [
       ("Client Data Feed ID", "Unique identifier of the outbound feed.", "Client Data Feed", "Identifier", "", "CDF-00231", "Internal", "", "", "Object PII tier: No PII."),
       ("Feed Recipient", "Organization (02) receiving the feed.", "Client Data Feed", "Reference (Party)", "", "PTY-100670", "Internal", "", "Y"),
       ("Feed Content Type", "Data sent in the feed.", "Client Data Feed", "Code (multi)", "Feed Content Type", "Portfolio Holdings; Transactions; Performance", "Internal", "", "Y"),
       ("Feed Transport", "Transport mechanism.", "Client Data Feed", "Code", "Delivery Channel", "SFTP", "Internal", "", ""),
       ("Feed Frequency", "Delivery frequency.", "Client Data Feed", "Code", "Frequency", "Daily", "Internal", "", ""),
       ("Data-Sharing Agreement", "Agreement that permits the data sharing (05 agreement, or the client's own contract in 39).", "Client Data Feed", "Reference (Agreement)", "", "AGR-001102", "Internal", "", ""),
     ]),
   ]),
   ("Transitions & In-Specie Transfers", "Events that move assets into, out of or between mandates.", [
     ("Transition Event", [
       ("Transition ID", "Unique identifier of the transition event.", "Transition Event", "Identifier", "", "TRN-2026-0042", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Transition Type", "Type of transition.", "Transition Event", "Code", "Transition Type", "Transition In", "Internal", "", "Y"),
       ("Transition Mandate", "Mandate (01) affected.", "Transition Event", "Reference (Investment Mandate)", "", "MND-01240", "Internal", "", ""),
       ("Transition Manager", "Transition manager (02 party) appointed, if any.", "Transition Event", "Reference (Party)", "", "PTY-100455", "Internal", "", ""),
       ("In-Specie Indicator", "Whether assets transfer in kind (in specie) rather than in cash.", "Transition Event", "Boolean", "", "Y", "Internal", "", "Y"),
       ("Actual Completion Date", "Date the transition was completed.", "Transition Event", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Transition Total Cost", "Aggregate cost of the transition (explicit costs plus implementation shortfall) as reported to the client in the post-transition report; trade-level cost analysis is 25.", "Transition Event", "Amount", "", "USD 1,240,000", "Internal", "", "", "Aggregate only; the 25 transaction cost analysis results are read, not copied."),
       ("Post-Transition Report Delivered Indicator", "Whether the post-transition cost and implementation shortfall report was delivered to the client.", "Transition Event", "Boolean", "", "N", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Termination & Offboarding", "IS-TRM",
  "Ending a mandate or relationship: notice, transition out, final reporting, the final fee invoice (47) and records retention.",
  [
   ("Termination", "Termination notice and offboarding checklist for a mandate.", [
     ("Mandate Termination", [
       ("Termination ID", "Unique identifier of the termination.", "Mandate Termination", "Identifier", "", "TRM-2026-0009", "Internal", "", "", "Object PII tier: No PII."),
       ("Terminated Mandate", "Mandate (01) terminated.", "Mandate Termination", "Reference (Investment Mandate)", "", "MND-01120", "Internal", "", "Y"),
       ("Termination Scope", "Whether the termination is full or partial.", "Mandate Termination", "Code", "Termination Scope", "Full", "Internal", "", ""),
       ("Notice Received Date", "Date written notice was received.", "Mandate Termination", "Date", "ISO 8601", "2026-07-31", "Internal", "", "Y"),
       ("Termination Reason", "Main reason for the termination.", "Mandate Termination", "Code", "Termination Reason", "Asset Allocation Change", "Internal", "", "Y"),
       ("Effective Termination Date", "Date management ceases.", "Mandate Termination", "Date", "ISO 8601", "2026-08-31", "Internal", "", "Y"),
       ("Transition-Out Event", "Transition event moving the assets out.", "Mandate Termination", "Reference (Transition Event)", "", "TRN-2026-0039", "Internal", "", ""),
       ("Final Report Run", "Final report run delivered to the client.", "Mandate Termination", "Reference (Report Run)", "", "RRN-2026M08-003311", "Internal", "", ""),
       ("Final Invoice", "Final pro-rated fee invoice (47) for the mandate.", "Mandate Termination", "Reference (Fee Invoice, 47)", "", "BIL-2026Q3-00930", "Internal", "", "", "Re-typed from Reference (Invoice) when the billing family moved to 47 (CW-012, CW-054)."),
       ("Records Retention End Date", "Date until which the client's books and records must be retained.", "Mandate Termination", "Date", "ISO 8601", "2033-08-31", "SEC Rule 204-2", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Institutional Client Type": ("Internal (aligned to SEC Form ADV Part 1A Item 5.D)", [("Public Pension Plan","State or local government defined benefit plan"),("Corporate DB Plan","Private-sector defined benefit plan subject to ERISA"),("Corporate DC Plan Sponsor","Employer sponsoring a plan the firm recordkeeps or advises"),("Endowment","College, university or school endowment"),("Foundation","Private or community foundation"),("Health System","Hospital or health system operating and pension assets"),("Insurance General Account","Insurer's general account assets"),("Taft-Hartley / Multiemployer Plan","Multiemployer plan jointly trusteed under the Labor Management Relations Act"),("Government Entity","State, municipal or agency operating, reserve or trust funds (not a pension)"),("Other","")]),
 "Governance Model": ("Internal", [("Internal CIO / Staff",""),("Investment Committee with Consultant",""),("Investment Committee with OCIO","Committee retains policy; implementation delegated to the firm"),("Board / Trustees with Consultant",""),("Fully Delegated (OCIO)","")]),
 "Business Line": ("Business lines of the wealth model (CW-004) - local copy of the shared list", [("DB","Direct brokerage and self-directed investing"),("DA","Digital advice"),("HA","Human and hybrid advice"),("PF","Proprietary funds and ETFs (including CITs)"),("WR","Workplace retirement recordkeeping"),("IA","Institutional advisory"),("IC","Intermediary channel"),("TR","Personal trust services (optional)")]),
 "IPS Status": ("Internal", [("Draft",""),("Under Client Review",""),("Adopted","Approved by the governing body and in force"),("Superseded","Replaced by a later version"),("Withdrawn","")]),
 "Spending Policy Method": ("Internal (UPMIFA prudence standard; IRC section 4942 for private foundations)", [("Percent of Trailing Average Market Value","Spending rate applied to an average of trailing quarter- or year-end values"),("Inflation-Adjusted Prior Spending","Prior year spending grown by inflation"),("Hybrid","Weighted blend of the two methods"),("Fixed Percent of Current Value",""),("Other","Institution-specific rule"),("Not Applicable","No spending policy (for example a pension plan)")]),
 "Servicing Segment": ("Internal", [("OCIO","Total or partial portfolio delegated to the firm as outsourced CIO"),("Institutional Separate Account","Single-client mandate in a 15 institutional separate account"),("Institutional Pooled (Fund or CIT)","Institution invested in the firm's mutual funds, ETFs or collective investment trusts"),("Plan Sponsor - Recordkept","Sponsor of a plan the firm recordkeeps"),("Plan Sponsor - CIT Only","Plan that invests in the firm's CITs on another recordkeeper")]),
 "Service Relationship Status": ("Internal", [("Onboarding",""),("Active",""),("Under Notice","Termination notice received"),("Terminated",""),("Dormant","No assets, relationship retained")]),
 "OCIO Delegation Scope": ("Internal", [("Full Discretion","Firm sets and implements allocation and selects managers within the IPS"),("Partial Discretion","Firm implements within limits; client approves allocation or manager changes"),("Non-Discretionary (Advisory)","Firm recommends; client decides")]),
 "ERISA Fiduciary Status": ("ERISA sections 3(21) and 3(38) (29 U.S.C. 1002)", [("ERISA 3(38) Investment Manager","Discretion over plan assets; acknowledges fiduciary status in writing"),("ERISA 3(21) Co-Fiduciary Adviser","Renders investment advice for a fee; plan fiduciary decides"),("Not ERISA","Client assets are not plan assets subject to Title I of ERISA")]),
 "Institutional Service Tier": ("Internal", [("Tier 1 - Strategic",""),("Tier 2 - Core",""),("Tier 3 - Standard",""),("Tier 4 - Pooled / Digital","Mainly self-service through the institutional or sponsor portal")]),
 "Frequency": ("Internal (harmonize with 09)", [("Daily",""),("Weekly",""),("Monthly",""),("Quarterly",""),("Semi-Annual",""),("Annual",""),("Ad Hoc",""),("On Event","")]),
 "Service Standard Metric": ("Internal", [("Report Delivery Timeliness",""),("Request Response Time",""),("Request Resolution Time",""),("Breach Notification Time",""),("Meeting Cadence Adherence",""),("Report Accuracy","Share of reports delivered without restatement"),("Cash Flow Instruction Processing Time","")]),
 "SLA Unit": ("Internal", [("Business Days After Period End",""),("Business Hours",""),("Business Days",""),("Calendar Days",""),("Percent","")]),
 "Service Role": ("Internal", [("Client Service Manager","Day-to-day service lead for the relationship"),("Client Portfolio Manager / Investment Specialist","Represents the investment team to the client"),("OCIO Client Strategist","Leads allocation and IPS discussions with an OCIO client's committee"),("Plan Sponsor Service Manager","Service lead for a recordkept plan sponsor"),("Reporting Analyst",""),("Client Onboarding Specialist",""),("Investment Operations Contact","Settlement, SSI and cash flow contact"),("Client Service Associate","")]),
 "Report Type": ("Internal", [("Monthly Valuation Report",""),("Quarterly Investment Report",""),("OCIO Total Portfolio Report","Total portfolio across firm-managed and external managers"),("Performance Report",""),("Portfolio Holdings & Valuation Statement",""),("Transaction Statement",""),("Performance Attribution Report",""),("Risk Report",""),("ESG / Climate Report","Client-requested sustainability metrics"),("Stewardship / Voting Report",""),("Compliance Certificate",""),("Consultant Data Pack","Standard data for consultant monitoring"),("Plan Sponsor Review Report","Plan health, investment line-up and fee review for the fiduciary committee"),("Participation & Deferral Report","Participation, deferral and automatic feature statistics of a recordkept plan"),("Fee Report Backup","Supporting detail for a 47 fee invoice"),("Flash Return","Early estimate after period end"),("Liability / LDI Report",""),("Transition Report","")]),
 "Report Scope Level": ("Internal", [("Mandate",""),("Client Relationship",""),("Pooled Fund or CIT",""),("Retirement Plan","")]),
 "Report Customization": ("Internal", [("Standard",""),("Standard with Client Options",""),("Bespoke","")]),
 "Reporting Driver": ("Internal", [("Client IMA / Contract",""),("Plan Sponsor Agreement","Recordkeeping or plan service agreement"),("GIPS",""),("ERISA 3(38) Reporting","Reporting the firm undertakes as ERISA investment manager"),("Advisers Act Rule 206(4)-2","Account statements in the context of the qualified custodian's statements"),("Other","")]),
 "Report Component Type": ("Internal", [("Cover & Contents",""),("Market Commentary",""),("Portfolio Commentary",""),("Performance Summary",""),("Performance Attribution",""),("Portfolio Holdings",""),("Sector / Country Exposure",""),("Transactions",""),("Risk Statistics",""),("ESG Metrics",""),("Voting & Engagement",""),("Cash Flows",""),("Fees & Costs","Fees as billed in 47"),("Guideline Compliance",""),("Plan Participation Statistics",""),("GIPS Disclosures",""),("Regulatory Disclosures","")]),
 "Report Output Format": ("Internal", [("PDF",""),("Excel",""),("CSV",""),("XML",""),("Interactive Portal View",""),("API / JSON","")]),
 "Branding Type": ("Internal", [("Firm Brand",""),("Co-Branded","With the client or its consultant"),("Unbranded Data","")]),
 "Consolidation Level": ("Internal", [("By Mandate",""),("Consolidated",""),("Consolidated and by Mandate",""),("By Plan","")]),
 "Return Methodology": ("GIPS", [("Time-Weighted",""),("Money-Weighted (IRR)",""),("Both","")]),
 "Fee Basis": ("GIPS", [("Gross of Fees",""),("Net of Fees",""),("Gross and Net","")]),
 "Return Period": ("GIPS / Internal", [("MTD",""),("QTD",""),("YTD",""),("1Y",""),("3Y",""),("5Y",""),("10Y",""),("Since Inception",""),("Calendar Years","")]),
 "Net Fee Treatment": ("GIPS", [("Actual Fees",""),("Model Fees",""),("Highest Fee","")]),
 "Portfolio Holdings Detail Level": ("Internal", [("Full Portfolio Holdings",""),("Top 10",""),("Exposures Only",""),("None","")]),
 "Look-Through Template": ("Internal", [("Firm Look-Through File",""),("Consultant Template","Template specified by the client's investment consultant"),("None","")]),
 "GIPS Report Type": ("GIPS", [("Composite Time-Weighted Return Report",""),("Composite Money-Weighted Return Report",""),("Pooled Fund Time-Weighted Return Report",""),("Pooled Fund Money-Weighted Return Report","")]),
 "GIPS Disclosure Item": ("GIPS", [("Compliance Statement",""),("Composite Description",""),("Benchmark Description",""),("Fee Schedule",""),("Number of Portfolios",""),("Composite Assets",""),("Total Firm Assets",""),("Internal Dispersion",""),("3Y Ex-Post Std Dev",""),("Composite Inception and Creation Dates",""),("Policies Available on Request","")]),
 "Stewardship Content": ("Advisers Act Rule 206(4)-6 / SEC Rule 14Ad-1 / SEC Form N-PX / Internal", [("Proxy Voting Record","Votes cast for the client's mandates (34; Rule 206(4)-6) and pooled vehicles (fund Form N-PX)"),("Proxy Voting Policy Summary",""),("Engagement Case Studies",""),("Escalation Activity",""),("Engagement Outcomes","")]),
 "Production Status": ("Internal", [("Scheduled",""),("Data Pending",""),("In Production",""),("In Review",""),("Signed Off",""),("Delivered",""),("Restated",""),("Canceled","")]),
 "Restatement Reason": ("Internal", [("Pricing Correction",""),("Transaction Correction",""),("Benchmark Correction",""),("Fee Correction",""),("Methodology Change",""),("Client Request","")]),
 "Delivery Channel": ("Internal", [("Client Portal",""),("Email",""),("Secure Email",""),("SFTP",""),("API",""),("Consultant Database Feed",""),("Post",""),("Data Vendor Platform","")]),
 "Delivery Status": ("Internal", [("Pending",""),("Delivered",""),("Opened","Portal or tracked email"),("Failed",""),("Recalled","")]),
 "Breach Type": ("Internal", [("Active","Caused by a firm action, such as a trade"),("Passive","Caused by market movement or a corporate action"),("Technical","Data or coding error, no actual exposure")]),
 "Cure Action": ("Internal", [("Sell Down",""),("Purchase",""),("Client Waiver",""),("Guideline Amended",""),("Self-Cured by Market","")]),
 "Institutional Service Request Type": ("Internal / Salesforce Service Cloud", [("Data Request",""),("Ad-Hoc Report",""),("Cash Flow Notification",""),("Rebalancing Instruction",""),("Guideline Change",""),("IPS Change Request",""),("Audit Confirmation",""),("SOC 1 Report Request","Service auditor's report on controls (AICPA SSAE 18)"),("Fee / Invoice Query","Resolved against the 47 fee invoice"),("Contact / Signatory Update",""),("Portal Access",""),("Proxy Voting Query",""),("Plan Sponsor Data Request","Plan-level data for the sponsor's committee, auditor or Form 5500 preparer"),("Consultant Questionnaire","Operational queries outside RFP and due diligence questionnaires (05)")]),
 "Request Status": ("Salesforce Service Cloud", [("New",""),("In Progress",""),("Waiting on Client",""),("Escalated",""),("Resolved",""),("Closed",""),("Canceled","")]),
 "Resolution Code": ("Internal", [("Fulfilled",""),("Partially Fulfilled",""),("Declined",""),("Duplicate",""),("Referred to Complaint","")]),
 "Flow Direction": ("Internal", [("Contribution",""),("Withdrawal","")]),
 "Settlement Form": ("Internal", [("Cash",""),("In Specie","In kind"),("Mixed","")]),
 "Client Review Type": ("Internal", [("Annual Review",""),("Quarterly Review",""),("Board / Trustee Meeting",""),("Investment Committee Meeting",""),("Plan Fiduciary Committee Review","Review of a recordkept plan with the sponsor's fiduciary committee"),("IPS Review","Periodic review of the investment policy statement"),("Consultant Review Meeting",""),("Onsite Visit by Client","")]),
 "Review Outcome": ("Internal", [("Satisfied",""),("Concerns Raised",""),("Mandate Under Review",""),("Expansion Discussed","Hand off to 05 as a sales opportunity")]),
 "RAG Status": ("Internal", [("Red",""),("Amber",""),("Green","")]),
 "At-Risk Reason": ("Internal", [("Underperformance",""),("Personnel Change",""),("Service Issues",""),("Client Strategy Change",""),("Fee Pressure",""),("Consultant Rating Change",""),("Plan Sponsor Event","Merger, plan termination or recordkeeper search")]),
 "Feed Content Type": ("Internal", [("Portfolio Holdings",""),("Transactions",""),("Performance",""),("Valuations",""),("Analytics / Risk",""),("Characteristics",""),("Plan Participant Statistics","Aggregated plan data for sponsors and their consultants")]),
 "Onboarding Checklist Status": ("Internal", [("Not Started",""),("Agreement Pending",""),("Account and Custodian Set-Up",""),("Ready to Fund",""),("Funded - Reporting Pending",""),("Complete",""),("Canceled","")]),
 "Transition Type": ("Internal", [("Initial Funding",""),("Transition In",""),("Transition Out",""),("Restructure",""),("Manager Replacement","")]),
 "Termination Scope": ("Internal", [("Full",""),("Partial","")]),
 "Termination Reason": ("Internal", [("Underperformance",""),("Asset Allocation Change",""),("Move to Passive",""),("Consultant Recommendation",""),("Fees",""),("Organizational Change at Firm",""),("Client Merger / Consolidation",""),("Plan Termination or Recordkeeper Change",""),("Strategy Closed","")]),
}

# ---------------------------------------------------------------------------
REL = [
 ("Institutional Client","profiles","Party [02]","1 : 1","Keyed by the PTY- of the party with the Institutional Client role (CW-023, CW-133)."),
 ("Institutional Client","adopts","Investment Policy Statement","1 : 0..n","One version in force at a time."),
 ("Investment Policy Statement","adopts","Asset Allocation Policy [24]","n : 0..1","CW-147: 24 masters the strategic allocation."),
 ("Investment Policy Statement","governs","Investment Mandate [01]","n : 1..n",""),
 ("Investment Policy Statement","sets the objective against","Benchmark [01]","n : 0..1","Read, no attribute: the policy benchmark is shown through Presentation Profile.Primary Benchmark Shown."),
 ("Service Relationship","services","Institutional Client","n : 1",""),
 ("Service Relationship","covers","Investment Mandate [01]","1 : 0..n","Pooled vehicles are referenced as Product / Share Class [01]."),
 ("Service Relationship","is advised by","Consultant Advisory Relationship [05]","n : 0..1","05 masters consultant relations (CW-132)."),
 ("Service Relationship","is contracted by","Internal Legal Entity [09]","n : 1",""),
 ("Service Relationship","is managed by","Party Coverage Assignment [03]","1 : 1..n","Read, no attribute: relationship manager of record, read from 03 as of a date (CW-138)."),
 ("OCIO Service Detail","is delivered under","Service Offering [01]","n : 1","OCIO offering."),
 ("OCIO Service Detail","oversees","Sub-Adviser Engagement [52]","1 : 0..n","External managers in the OCIO portfolio (CW-147)."),
 ("OCIO Service Detail","is governed by","Investment Policy Statement","n : 1",""),
 ("Plan Sponsor Servicing Detail","services","Retirement Plan [02 / 16]","n : 1","CW-146: 16 owns the plan."),
 ("Service Relationship","services the plans of","Plan Sponsor Servicing Detail","1 : 0..n","One row per plan of a plan sponsor relationship."),
 ("Plan Sponsor Servicing Detail","references","Service Arrangement [16]","n : 1","Recordkeeping arrangement."),
 ("Plan Sponsor Servicing Detail","reports to","Plan Role Assignment [16]","n : 0..1","The sponsor's fiduciary committee."),
 ("Service Relationship","is assigned","Institutional Service Tier","n : 1","Current tier only; not the 01 retail Service Tier."),
 ("Institutional Service Tier / Service Relationship","is governed by","Service Standard","1 : 0..n",""),
 ("Service Coverage Assignment","assigns","Employee [20]","n : 1","Servicing roles only; distinct from 03 Party Coverage Assignment and 05 Partner Coverage Assignment."),
 ("Service Relationship","is covered by","Service Coverage Assignment","1 : 1..n","At least a Client Service Manager."),
 ("Report Definition","is composed of","Report Component","1 : 1..n","Ordered."),
 ("Report Definition","is rendered with","Report Template","n : 1",""),
 ("Report Template","applies","Brand [42]","n : 1",""),
 ("Report Package","includes","Report Definition","n : 1..n",""),
 ("Report Package","covers","Retirement Plan [02 / 16]","n : 0..n","Plan sponsor packages; the plan data comes from 16."),
 ("Report Package","is presented per","Presentation Profile","1 : 1..n",""),
 ("Presentation Profile","shows","Benchmark [01]","n : 1..n",""),
 ("Presentation Profile","presents","Performance Return [32] and Portfolio Valuation Summary [18]","n : n","Values are read, not held."),
 ("Report Definition","discloses","GIPS Composite [01]","n : 0..1",""),
 ("Report Package","is produced as","Report Run","1 : 0..n","One run per period and version."),
 ("Report Run","is delivered to","Distribution List","n : 1..n",""),
 ("Distribution List","uses","Contact Point [02]","n : 1",""),
 ("Report Delivery","is published on","Digital Property [04]","n : 0..1","Read, no attribute: Portal Document Reference identifies the document on the 04 portal."),
 ("Report Run","may be reviewed by","Compliance Review [08]","1 : 0..1",""),
 ("Guideline Monitoring Arrangement","monitors","Investment Restriction [01]","1 : 1..n",""),
 ("Breach Notification","concerns","Investment Restriction [01]","n : 1",""),
 ("Breach Notification","reports","Investment Breach [33]","n : 1","The breach facts are mastered in 33 and copied here (CD-222)."),
 ("Client Service Request","may raise","Complaint [08]","1 : 0..1","CW-070."),
 ("Cash Flow Notification","results in","Transaction [06]","1 : 0..n",""),
 ("Client Review","is held as","Advisor Activity [03]","1 : 0..1",""),
 ("Client Review","may originate","Sales Opportunity [05]","1 : 0..n","Read, no attribute: expansion discussed is handed to 05 as an opportunity."),
 ("Relationship Health Score","reads","Survey Response [04]","n : 0..n","CW-093."),
 ("Mandate Onboarding","starts from","Sales Opportunity [05]","1 : 0..1",""),
 ("Mandate Onboarding","is governed by","Contract [39]","n : 1","Investment management or plan service agreement."),
 ("Mandate Onboarding","opens","Account [15]","1 : 0..1","Institutional separate account."),
 ("Mandate Onboarding","sets up","Client Custodian Account","1 : 0..n",""),
 ("Client Custodian Account","belongs to","Account [15]","n : 1",""),
 ("Client Custodian Account","is held at","Party (Custodian) [02]","n : 1",""),
 ("Client Custodian Account","caused the creation of","Safekeeping Account [28]","1 : 0..1","CD-194 option A."),
 ("Client Custodian Account","caused the creation of","Standing Settlement Instruction [26]","1 : 0..n","CD-155 option A."),
 ("Client Data Feed","is permitted by","Distribution Agreement [05] or Contract [39]","n : 0..1",""),
 ("Mandate Termination","triggers","Transition Event","1 : 0..1",""),
 ("Mandate Termination","is billed by","Fee Invoice [47]","1 : 0..1","Final invoice (CW-054)."),
 ("Mandate Termination","closes","Investment Mandate [01]","n : 1","01 sets the mandate lifecycle status."),
]

# ---------------------------------------------------------------------------
SRC = [
 ("GIPS Standards for Firms (2020) and GIPS Handbook","CFA Institute","https://www.gipsstandards.org/standards/gips-standards-for-firms/","Free","Composite and pooled fund reports, required numerical information and disclosures (Sections 4-7), 12-month update requirement, gross and net and TWR and MWR presentation","Performance & Holdings Presentation, GIPS Disclosure Requirements, Restatements",["GIPS"]),
 ("SEC Marketing Rule 206(4)-1 and Books and Records Rule 204-2","US SEC","https://www.sec.gov/rules-regulations/2020/12/investment-adviser-marketing","Regulation","Gross and net presentation, extracted and hypothetical performance; record retention","Fee Basis Shown, Net Return Fee Treatment, Compliance Review, Sign-Off, Records Retention",["SEC Rule 206(4)-1","SEC Rule 204-2"]),
 ("Advisers Act Rule 206(4)-5 (political contributions by certain investment advisers)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.206(4)-5","Regulation (public)","Government entity definition","Institutional Client.Government Entity Indicator",["SEC Rule 206(4)-5"]),
 ("Advisers Act Rule 206(4)-2 (custody of funds or securities of clients by investment advisers; confirm current status)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.206(4)-2","Regulation (public)","Qualified custodian account statements; adviser statements to clients","Reporting Driver, Client Custodian Account set-up",["Advisers Act Rule 206(4)-2"]),
 ("ERISA sections 3(21) and 3(38) (29 U.S.C. 1002)","US Congress / Cornell LII","https://www.law.cornell.edu/uscode/text/29/1002","Statute (public)","Fiduciary and investment manager definitions; plan assets","Institutional Client.ERISA Plan Indicator, OCIO Service Detail.ERISA Fiduciary Status",["ERISA","29 U.S.C. 1002"]),
 ("DOL 29 CFR 2550.408b-2 (service provider fee disclosure)","US DOL / Cornell LII","https://www.law.cornell.edu/cfr/text/29/2550.408b-2","Regulation (public)","Covered service provider disclosures to plan sponsors (owned by 16 and 47; 12 delivers reviews and reports around them)","Plan Sponsor Servicing Detail, Plan Sponsor Review Report",["DOL 408(b)(2)"]),
 ("Uniform Prudent Management of Institutional Funds Act (2006)","Uniform Law Commission","https://www.uniformlaws.org","Model act (public); state enactments vary","Prudent investing and spending of charitable institutional funds","Institutional Client.UPMIFA Applicability Indicator, Spending Policy Method, Spending Rate",["UPMIFA"]),
 ("Elements of an Investment Policy Statement for Institutional Investors","CFA Institute","https://www.cfainstitute.org","Free guidance","Objectives, constraints, governance and review content of an IPS","Investment Policy Statement",["CFA Institute IPS guidance"]),
 ("SEC Form N-PX (annual report of proxy voting record)","US SEC","https://www.sec.gov/files/formn-px.pdf","Form (public)","Fund proxy voting record reported annually (pooled vehicles only); also the form for the manager's own say-on-pay report","Stewardship Report Scope, Stewardship Content",["SEC Form N-PX"]),
 ("SEC Form N-1A Item 16(f) (portfolio holdings disclosure policy) and Form N-PORT","US SEC","https://www.sec.gov/files/formn-1a.pdf","Form (public)","Fund policies on disclosing portfolio holdings (SAI); N-PORT public timing","Portfolio Holdings Disclosure Lag Days",["SEC Form N-1A Item 16(f)","SEC Form N-PORT"]),
 ("Advisers Act Rule 206(4)-6 (proxy voting) and Rule 204-2(c)(2)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.206(4)-6","Regulation (public)","Adviser proxy voting policies, disclosure to clients of how to obtain their voting records, and record keeping","Stewardship Report Scope, Stewardship Content",["SEC Rule 206(4)-6"]),
 ("Exchange Act Rule 14Ad-1 (say-on-pay vote reporting by institutional investment managers on Form N-PX)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.14Ad-1","Regulation (public)","Form 13F managers report their say-on-pay votes on Form N-PX (first filings due August 31, 2024)","Stewardship Content",["SEC Rule 14Ad-1"]),
 ("Regulation S-ID (identity theft red flags)","US SEC / CFTC","https://www.ecfr.gov/current/title-17/chapter-II/part-248/subpart-C","Regulation (public)","Red flags for covered accounts (secondary: behind the firm's call-back policy)","Cash Flow Notification.Call-Back Verification Performed",["SEC Regulation S-ID"]),
 ("AICPA SSAE 18 / SOC 1 reports","AICPA & CIMA","https://www.aicpa-cima.com","Standard (licensed)","Service auditor reports on controls requested by clients and their auditors","Institutional Service Request Type",["AICPA SOC 1"]),
 ("SWIFT ISO 15022 MT 540-548 and ISO 20022 securities settlement messages","SWIFT","https://www.swift.com/standards/iso-15022","Standard (SWIFT member access for full specs)","Securities settlement and safekeeping account messages","Client Custodian Account (safekeeping account number); SSIs are mastered in 26 (CD-155)",["SWIFT ISO 15022","ISO 20022"]),
 ("ISO 9362 (BIC), ISO 4217, ISO 639, ISO 8601","ISO / SWIFT","https://www.iso.org","Standard; code lists widely available","Bank identifiers and reference code lists","Client Custodian Account, reference formats",["ISO 9362"]),
 ("Salesforce Service Cloud Case object","Salesforce","https://developer.salesforce.com/docs/atlas.en-us.object_reference.meta/object_reference/sforce_api_objects_case.htm","Proprietary documentation (public)","Case status, priority, origin, SLA and entitlement fields","Client Service Request model",["Salesforce Service Cloud"]),
 ("ITIL 4 Service Level Management","PeopleCert / AXELOS","https://www.axelos.com","Licensed framework","Service level definitions and measurement","Service Standards",["ITIL"]),
 ("SEC Form ADV Part 1A","US SEC","https://www.sec.gov/about/forms/formadv-part1a.pdf","Form (public)","Client type categories (Item 5.D)","Institutional Client Type",["SEC Form ADV"]),
]
