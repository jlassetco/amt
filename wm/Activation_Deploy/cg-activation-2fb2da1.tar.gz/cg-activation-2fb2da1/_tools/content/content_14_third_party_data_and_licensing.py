"""Business domain 14 - Third-Party Data & Licensing. Content module for taxonomy_builder.py."""

META = {
 "title": "Third-Party Data & Licensing Data Taxonomy",
 "subtitle": "Business domain 14 - Third-Party Data & Licensing | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "14_Third_Party_Data_and_Licensing/Third_Party_Data_and_Licensing_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the third-party data and licensing domain of a US direct wealth manager that relies on licensed external data: exchange market data and real-time quotes displayed to clients on its website and apps (the exchanges and the CTA, UTP and OPRA plans, licensed by professional and non-professional subscriber), account aggregation data on clients' held-away accounts (e.g. Plaid, Envestnet Yodlee, MX), financial planning data (capital market assumptions, tax, Social Security and mortality tables), fund data and ratings (Morningstar, LSEG Lipper), index data and the index licenses of its index funds and ETFs (MSCI, S&P DJI, FTSE Russell, Bloomberg, CRSP), market and reference data (Bloomberg, LSEG, ICE), ESG data and, for the thin intermediary channel and institutional advisory, advisor, firm and consultant databases (Discovery Data, Broadridge, Nasdaq eVestment) and marketing data. It defines what we buy, from whom, under which rights, who may use it, what it costs, and how compliance, vendor risk and data quality are managed. It draws on market data policy practice (FISD), regulation and supervisory guidance (the US interagency third-party risk management guidance, SEC Regulation S-P service-provider oversight, state privacy law such as the CCPA as amended by the CPRA, and the exchange and CTA / UTP subscriber agreements), assurance standards (AICPA SOC 2, ISO/IEC 27001) and data management frameworks (EDM Council DCAM and CDMC). Use it as a starting point for a data-license inventory, an entitlement and usage system, a vendor management data model or a data catalog."),
  ("Scope", "In scope: data vendor relationships (vendor role on a PTY- party, contacts, relationship owner, strategic tier, performance reviews); vendor risk and third-party risk management for data vendors (due diligence, SOC 2 / ISO 27001 evidence, substitutability and exit planning); the dataset and data product catalog (DSET-) with coverage, granularity, frequency, delivery, identifiers, history and lineage to consuming business domains; data license agreements we purchase (DLA-) with licensed scope, license model, term, renewal, termination, data destruction, audit and attribution clauses; permitted-use rights (display, non-display, derived data, redistribution, client reporting, marketing, index-tracking products, AI/ML); index and benchmark licensing (benchmark use, index-tracking product licenses, AUM-based fees); entitlements (ENT-) of employees, applications and client subscribers (real-time quotes, with professional or non-professional subscriber status) and the non-display application inventory; usage declarations, license audits, findings and true-ups; data cost (contract value, invoices, cost allocation to OU-, renewals and optimization); vendor data quality, SLAs and data challenges. Out of scope (referenced by ID only): party master, vendor legal identifiers and vendor contacts as persons, and clients who hold a market data entitlement (02 Client & Household: PTY-); benchmarks, products and share classes (01 Investment Product & Service Offering: BMK-, PRD-, SHC-); data-sharing and data-licensing agreements with distribution partners, and data fees paid to distributors (05 Intermediary & Institutional Distribution: AGR-); technical feeds, loads and the data received (06 Client Assets, Flows & Channel Attribution: FEED-); submissions we make to consultant databases (05 Intermediary & Institutional Distribution: DBS-, CW-134); intent signals and lead scores (04 Marketing, Digital & Client Engagement); personnel licenses (08 Retail Conduct & Supervision: LIC-); internal legal entities and org units (09 Shared Reference Data: LEN-, OU-); distribution cost accounting, accruals and allocation methods (10 Client Revenue, Pricing Economics & Profitability: ALM-, DCO-); the ratings, peer and market-share values themselves (11 Market & Competitive Intelligence); consultant data requests on mandates (12)."),
  ("Structure", "Four levels: Domain > Subdomain > Concept > Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Data Vendor (a PTY- party in the vendor role) -> Data License Agreement (DLA-, master agreement with order forms / schedules) -> Licensed Dataset Schedule (which DSET- datasets, territory, entities, user and application counts) -> Permitted Use Grants (display, non-display, derived, redistribution, client reporting, marketing, index-tracking, AI/ML) -> Entitlements (ENT-) of users, client subscribers and Consuming Applications (41 APPL-) -> Usage Declarations (UDC-) and License Audits (LAU-) with findings and true-ups. Datasets (DSET-) are delivered through technical feeds (06 FEED-) and consumed by business domains (Dataset Consumption). Index licenses are DLA- records of type Index License Agreement with Index Use and Product License Coverage (BMK- -> PRD-/SHC-). Commercials: Commercial Terms -> Data Invoices (DINV-) -> Cost Allocations to OU- -> Renewal Cases (RNW-). Assurance: Vendor Risk Assessments (VRA-) and Assurance Reports. Quality: Vendor Data SLAs and Vendor Data Issues (VDI-)."),
  ("Design principles", "1) A vendor is a party: vendor identity, LEI and contacts as persons are mastered in 02; this domain holds only the vendor relationship. 2) Rights are data, not prose: every permitted use is a coded grant with a status (permitted, conditional, prohibited, silent), so a use case can be checked against the license before data is used. 3) One dataset, many feeds and consumers: the DSET- catalog sits between the commercial license and the technical feed (06 FEED-), so lineage runs vendor -> license -> dataset -> feed -> consuming domain. 4) Effective-date grants, scopes, entitlements, allocations and coverage. 5) Hold contract facts once on the DLA- and derive notice deadlines and renewal pipeline from them. 6) Use FISD terminology (display, non-display, derived data) so that vendor policies can be compared. 7) Flag Critical Data Elements (CDE) for governance focus."),
  ("Applies To", "Shows the record type each attribute is held on: Vendor, Vendor Contact Role, Vendor Review, Risk Assessment, Assurance Report, Dataset, Dataset Field, Dataset Delivery, Dataset Consumption, Agreement, Licensed Scope, Permitted Use Grant, Attribution Requirement, Index Use, Index Product Coverage, Entitlement, Consuming Application, Usage Declaration, License Audit, Audit Finding, Commercial Terms, Data Invoice, Cost Allocation, Renewal Case, Vendor SLA, Vendor Data Issue or All."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify a dataset or license, prove the right to use data, report exchange subscribers correctly, pay or allocate data cost correctly, or manage the renewal and termination deadlines. Confirm with data owners."),
  ("Primary / Secondary Reference", "Standard or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Vendor references (Bloomberg, MSCI, Morningstar, Snowflake) reflect public descriptions of common license and delivery models, not the terms of any specific contract."),
  ("Tabs", "Hierarchy: domains, subdomains and concepts with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: concept-level cardinalities for the logical model, including references to other business domains | Sources: regulations, standards, frameworks and vendor material used, with owners, licenses and links."),
  ("Suggested next steps", "1) Validate domains, permitted-use categories and CDEs with Market Data / Data Office, Procurement, Legal, Vendor Risk, Index/ETF Product, Digital and Client Experience, Advice, Marketing and Finance. 2) Build the first inventory: top 25 vendors, their DLA- agreements, licensed datasets and renewal dates. 3) Have Legal interpret the permitted-use grants for the five highest-risk uses (display of real-time quotes to clients, client reporting, marketing materials, index-tracking products, AI/ML). 4) Agree with 06 that purchased vendor feeds reference DLA- (not AGR-) and that the FEED- 'License Use Restriction' is replaced by a reference to the grants here. 5) Agree with 05 the boundary for data bought from distributors versus vendors. 6) Agree with Enterprise Risk (37) and Procurement (40) whether data-vendor risk assessments are mastered here or in the enterprise TPRM tool. 7) Agree with 10 the hand-off of invoices and allocations to accounting. 8) Map attributes to source systems (contract lifecycle management, procurement / AP, entitlement tool such as a market data inventory platform, data catalog, TPRM tool)."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

D("Data Vendor Relationship", "TD-VND",
  "The firm's relationship with each external provider of licensed data: vendor role, contacts, ownership, strategic tier and periodic performance governance. The vendor itself is a party mastered in 02.",
  [
   ("Vendor Profile", "Vendor role and relationship attributes held for a party that supplies data to the firm.", [
     ("Data Vendor", [
       ("Vendor Party", "Party reference of the data vendor legal entity (identity, LEI and addresses are mastered in 02).", "Vendor", "Reference (Party)", "", "PTY-500210", "Internal", "", "Y"),
       ("Vendor Display Name", "Short commercial name used in catalogs and reports.", "Vendor", "Text", "", "Morningstar", "Internal", "", ""),
       ("Vendor Type", "Primary type of data vendor.", "Vendor", "Code", "Vendor Type", "Fund Data & Ratings Provider", "Internal", "", "Y"),
       ("Vendor Group", "Ultimate parent or group of the vendor, used to aggregate spend and concentration risk.", "Vendor", "Reference (Party)", "", "PTY-500001 (LSEG)", "Internal", "", ""),
       ("Vendor Subject Areas", "Subject areas the vendor supplies to the firm.", "Vendor", "Code (multi)", "Dataset Subject Area", "Fund Data; Ratings; ESG", "Internal", "", ""),
       ("Vendor Relationship Status", "Lifecycle status of the relationship.", "Vendor", "Code", "Vendor Relationship Status", "Active", "Internal", "", ""),
       ("Strategic Tier", "Importance of the vendor to the firm, driving governance intensity and review frequency.", "Vendor", "Code", "Vendor Strategic Tier", "Tier 1 - Strategic", "Internal", "US Interagency TPRM Guidance", "Y"),
       ("Relationship Owner", "Internal person accountable for the vendor relationship.", "Vendor", "Reference (Employee)", "", "EMP-01877", "Internal", "DCAM", "Y", "Enterprise workforce master not yet agreed (see §8 row 09); EMP- used provisionally."),
       ("Procurement Supplier ID", "Supplier number of the vendor in the procurement / accounts payable system.", "Vendor", "Identifier", "External (Procurement system)", "SUP 0045521", "Internal", "", "", "Derived copy (40) of Supplier Profile.ERP Supplier Number since the Stage 4 consolidation (CD-260); written without a hyphenated stem (SUP- is one letter from SUB-)."),
     ]),
     ("Vendor Contact Role", [
       ("Vendor Contact", "Party reference of the individual at the vendor (person mastered in 02).", "Vendor Contact Role", "Reference (Party)", "", "PTY-500877", "Internal", "", "", "PII"),
       ("Vendor Contact Role Type", "Role the individual plays for the firm.", "Vendor Contact Role", "Code", "Vendor Contact Role", "Account Manager", "Internal", "", ""),
       ("Primary Contact Indicator", "Whether this is the primary contact for the role.", "Vendor Contact Role", "Boolean", "", "Y", "Internal", "", ""),
       ("Contact Role Effective From", "Date the contact took on the role.", "Vendor Contact Role", "Date", "ISO 8601", "2025-01-15", "Internal", "", ""),
       ("Contact Role Effective To", "Date the contact left the role.", "Vendor Contact Role", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Vendor Performance Governance", "Periodic business review of the vendor's service, commercial position and open issues.", [
     ("Vendor Performance Review", [
       ("Review Date", "Date of the vendor business review.", "Vendor Review", "Date", "ISO 8601", "2026-06-20", "Internal", "", ""),
       ("Review Period", "Period the review covers.", "Vendor Review", "Text", "Firm-defined", "2026-H1", "Internal", "", ""),
       ("Overall Performance Rating", "Overall assessment of the vendor in the period.", "Vendor Review", "Code", "Performance Rating", "Meets Expectations", "Internal", "", ""),
       ("Next Review Date", "Scheduled date of the next review, set by strategic tier.", "Vendor Review", "Date", "ISO 8601", "2026-12-15", "Internal", "", ""),
     ]),
   ]),
  ])

D("Vendor Risk & Resilience", "TD-TPR",
  "Third-party risk management for data vendors: due diligence and periodic risk assessments, assurance evidence (SOC 2, ISO/IEC 27001), and the substitutability and exit planning that the US interagency third-party risk management guidance expects.",
  [
   ("Vendor Risk Assessment", "Due diligence and periodic risk assessment of a data vendor or a specific service.", [
     ("Vendor Risk Assessment", [
       ("Risk Assessment ID", "Unique identifier of the vendor risk assessment.", "Risk Assessment", "Identifier", "", "VRA-002311", "Internal", "", "Y"),
       ("Assessed Vendor", "Vendor being assessed.", "Risk Assessment", "Reference (Party)", "", "PTY-500210", "Internal", "", ""),
       ("Assessment Type", "Trigger and stage of the assessment.", "Risk Assessment", "Code", "Risk Assessment Type", "Periodic Review", "US Interagency TPRM Guidance", "", ""),
       ("Risk Domains Assessed", "Risk areas covered by the assessment.", "Risk Assessment", "Code (multi)", "Vendor Risk Domain", "Information Security; Business Continuity; Data Privacy", "US Interagency TPRM Guidance", "", ""),
       ("Inherent Risk Rating", "Risk before controls, driven by criticality, data sensitivity and substitutability.", "Risk Assessment", "Code", "Risk Rating", "High", "Internal", "", ""),
       ("Residual Risk Rating", "Risk after considering the vendor's controls and the firm's mitigants.", "Risk Assessment", "Code", "Risk Rating", "Medium", "Internal", "", "Y"),
       ("Personal Data Processed Indicator", "Whether the service involves the vendor processing personal information for the firm (e.g. client data sent to an account aggregator), or supplies personal data (e.g. advisor contact data).", "Risk Assessment", "Boolean", "", "Y", "SEC Regulation S-P", "CCPA / CPRA", "Y", "Drives Regulation S-P service-provider oversight and state privacy-law service provider contract terms, and privacy review."),
       ("Substitutability", "How readily the vendor or dataset could be replaced, on the firm's scale.", "Risk Assessment", "Code", "Firm-defined (substitutability scale, e.g. Not Substitutable, Difficult, Moderate, Easily Substitutable)", "Difficult", "Internal", "US Interagency TPRM Guidance", ""),
       ("Exit Strategy Documented Indicator", "Whether a documented exit plan exists for the service.", "Risk Assessment", "Boolean", "", "Y", "US Interagency TPRM Guidance", "", ""),
       ("Next Assessment Due Date", "Date the next periodic assessment is due.", "Risk Assessment", "Date", "ISO 8601", "2027-04-30", "Internal", "", "Y"),
     ]),
   ]),
   ("Assurance Evidence", "Independent assurance reports and certifications obtained from the vendor.", [
     ("Assurance Report", [
       ("Assurance Report Type", "Type of report or certificate received.", "Assurance Report", "Code", "Assurance Report Type", "SOC 2 Type II", "AICPA SOC 2", "ISO/IEC 27001", "Y"),
       ("Trust Services Categories Covered", "AICPA Trust Services Criteria categories in scope of a SOC 2 report (Security is always included).", "Assurance Report", "Code (multi)", "Trust Services Category", "Security; Availability; Confidentiality", "AICPA SOC 2", "", ""),
       ("Report Period Start", "Start of the period covered (Type II) or the as-of date (Type I).", "Assurance Report", "Date", "ISO 8601", "2025-07-01", "AICPA SOC 2", "", ""),
       ("Report Period End", "End of the period covered.", "Assurance Report", "Date", "ISO 8601", "2026-06-30", "AICPA SOC 2", "", ""),
       ("Auditor Opinion", "Opinion given by the service auditor.", "Assurance Report", "Code", "Auditor Opinion", "Unqualified", "AICPA SOC 2", "", ""),
       ("Exceptions Noted Indicator", "Whether testing exceptions were reported.", "Assurance Report", "Boolean", "", "N", "AICPA SOC 2", "", ""),
     ]),
   ]),
  ])

D("Dataset & Data Product Catalog", "TD-DST",
  "Catalog of every licensed dataset and data product (DSET-): what it contains, coverage, structure, delivery, identifiers and the business domains that consume it.",
  [
   ("Dataset Definition", "Identity, classification and ownership of a dataset.", [
     ("Dataset", [
       ("Dataset ID", "Unique identifier of the dataset or data product.", "Dataset", "Identifier", "", "DSET-00412", "Internal", "DCAM", "Y"),
       ("Dataset Name", "Business name of the dataset.", "Dataset", "Text", "", "Account Aggregation - Held-Away Accounts (US)", "Internal", "", "Y"),
       ("Dataset Vendor", "Vendor supplying the dataset.", "Dataset", "Reference (Party)", "", "PTY-500311", "Internal", "", "Y"),
       ("Vendor Product Code", "Vendor's product or package code, as shown on order forms.", "Dataset", "Identifier", "External (Vendor)", "MS-GFU-EQ", "Internal", "", ""),
       ("Dataset Description", "Narrative description of the content and intended use.", "Dataset", "Text", "", "Balances, securities and transactions of held-away accounts clients link for planning and advice (aggregated; not 49 Client Holdings)", "Internal", "", ""),
       ("Dataset Subject Area", "Primary subject area of the dataset.", "Dataset", "Code", "Dataset Subject Area", "Account Aggregation Data", "Internal", "", "Y"),
       ("Data Basis", "Whether values are reported, estimated, modeled or survey-based.", "Dataset", "Code", "Data Basis", "Estimated", "Internal", "", ""),
       ("Contains Personal Data Indicator", "Whether the dataset includes personal information (e.g. client account data from aggregation, advisor names, emails, phone numbers).", "Dataset", "Boolean", "", "Y", "SEC Regulation S-P", "CCPA / CPRA", "Y", "Client account data from aggregation is nonpublic personal information under GLBA and Regulation S-P (largely exempt from the CCPA); the CCPA applies to the non-GLBA data (marketing contacts, advisor databases, website visitors)."),
       ("Information Sensitivity", "Sensitivity classification of the dataset inside the firm.", "Dataset", "Code", "Information Classification", "Confidential", "CDMC", "", ""),
       ("Dataset Status", "Lifecycle status of the dataset in the catalog.", "Dataset", "Code", "Dataset Status", "In Production", "Internal", "", ""),
       ("Dataset Business Owner", "Internal person accountable for the dataset's use and value.", "Dataset", "Reference (Employee)", "", "EMP-02231", "DCAM", "", ""),
     ]),
   ]),
   ("Coverage & Structure", "Universe, geography, granularity, frequency and history of a dataset.", [
     ("Dataset Coverage", [
       ("Geographic Coverage", "Countries covered by the dataset.", "Dataset", "Code (multi)", "ISO 3166-1 alpha-2", "US", "Internal", "", ""),
       ("Covered Entity Types", "Kinds of entity the dataset describes.", "Dataset", "Code (multi)", "Covered Entity Type", "Advisors; Branches; Firms", "Internal", "", ""),
       ("Universe Description", "Description of the universe covered.", "Dataset", "Text", "", "All FINRA-registered reps and SEC/state RIAs", "Internal", "", ""),
       ("Data Granularity", "Lowest level of detail delivered.", "Dataset", "Code", "Data Granularity", "Advisor", "Internal", "", "Y"),
       ("Update Frequency", "How often the vendor refreshes the data.", "Dataset", "Code", "Frequency", "Monthly", "Internal", "", ""),
       ("Data Latency", "Lag between the as-of date and availability.", "Dataset", "Text", "T+n", "T+20", "Internal", "", ""),
       ("Licensed History Depth", "Years of history the firm is licensed to receive and retain.", "Dataset", "Integer", "Years", "10", "Internal", "", ""),
     ]),
     ("Dataset Key Field", [
       ("Field Name", "Name of a key field in the vendor's data dictionary.", "Dataset Field", "Text", "", "RepCRD", "Internal", "", ""),
       ("Field Business Definition", "Business definition of the field.", "Dataset Field", "Text", "", "FINRA CRD number of the representative", "Internal", "", ""),
       ("Identifier Scheme", "Identifier scheme the field carries, used for matching to firm masters.", "Dataset Field", "Code", "Identifier Scheme", "FINRA CRD", "Internal", "", ""),
       ("Match Target Concept", "Firm concept the identifier is matched to.", "Dataset Field", "Text", "Firm-defined", "Party (02) - Advisor", "Internal", "", ""),
     ]),
   ]),
   ("Delivery", "How the dataset reaches the firm.", [
     ("Dataset Delivery", [
       ("Delivery Method", "Channel through which the data is delivered.", "Dataset Delivery", "Code", "Delivery Method", "Cloud Data Share", "Internal", "Snowflake Marketplace", "Y"),
       ("Delivery Format", "Format of the delivered data.", "Dataset Delivery", "Code", "Delivery Format", "Database Table / View", "Internal", "", ""),
       ("Technical Feed", "Technical feed that implements the delivery (owned by 06).", "Dataset Delivery", "Reference (Feed)", "", "FEED-031", "Internal", "", "Y"),
       ("Marketplace Listing / Share Name", "Cloud marketplace listing or share name, where delivered by data sharing.", "Dataset Delivery", "Text", "", "VENDOR_X.FUND_DATA_US", "Snowflake Marketplace", "", ""),
     ]),
   ]),
   ("Dataset Consumption & Lineage", "Which business domains, applications and use cases consume each dataset, under which permitted use.", [
     ("Dataset Consumption", [
       ("Consumed Dataset", "Dataset consumed.", "Dataset Consumption", "Reference (Dataset)", "", "DSET-00412", "Internal", "CDMC", ""),
       ("Consuming Business Domain", "Business domain whose concepts are populated or enriched by the dataset.", "Dataset Consumption", "Code", "Consuming Business Domain", "45 Financial Planning & Advice", "Internal", "DCAM", "Y"),
       ("Consuming Application", "Application that consumes the dataset.", "Dataset Consumption", "Reference (Consuming Application)", "", "APPL-00412", "Internal", "", ""),
       ("Target Concept", "Concept or attribute populated in the consuming domain.", "Dataset Consumption", "Text", "", "45 Financial Planning & Advice / held-away assets", "Internal", "CDMC", ""),
       ("Use Case", "Business use the consumption supports.", "Dataset Consumption", "Code", "Use Case", "Advisor Targeting & Segmentation", "Internal", "", ""),
       ("Covering Permitted Use", "Permitted-use category under which the consumption is licensed.", "Dataset Consumption", "Code", "Permitted Use Category", "Internal Use - Non-Display", "FISD", "", "Y"),
       ("Authoritative Source Indicator", "Whether the dataset is the authoritative source for the target attribute.", "Dataset Consumption", "Boolean", "", "N", "CDMC", "DCAM", ""),
       ("Consumption Effective From", "Date the consumption began.", "Dataset Consumption", "Date", "ISO 8601", "2023-02-01", "Internal", "", ""),
       ("Consumption Effective To", "Date the consumption ended.", "Dataset Consumption", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

D("Data License Agreement", "TD-LIC",
  "Agreements under which the firm purchases data (DLA-): header, licensed scope, term and renewal, termination and data destruction, audit and reporting clauses.",
  [
   ("Agreement Header", "Identity, parties, type and term of a data license agreement or order form.", [
     ("Data License Agreement", [
       ("Data License Agreement ID", "Unique identifier of the agreement or order form.", "Agreement", "Identifier", "", "DLA-000184", "Internal", "", "Y"),
       ("Agreement Name", "Name of the agreement.", "Agreement", "Text", "", "Morningstar Data Order Form 2026 - Global Fund Data", "Internal", "", ""),
       ("Licensor", "Vendor granting the license.", "Agreement", "Reference (Party)", "", "PTY-500210", "Internal", "", "Y"),
       ("Licensee Legal Entity", "Internal legal entity that signs and holds the license.", "Agreement", "Reference (Legal Entity)", "", "LEN-0001", "Internal", "", "Y"),
       ("Agreement Type", "Contractual type of the document.", "Agreement", "Code", "Data Agreement Type", "Order Form / Schedule", "Internal", "", ""),
       ("Parent Agreement", "Master agreement under which an order form or schedule is issued.", "Agreement", "Reference (Data License Agreement)", "", "DLA-000100", "Internal", "", ""),
       ("License Model", "Basis on which the license is granted and priced.", "Agreement", "Code", "License Model", "Enterprise", "Internal", "Bloomberg", "Y"),
       ("Agreement Status", "Lifecycle status of the agreement.", "Agreement", "Code", "Agreement Status", "Active", "Internal", "", ""),
       ("Agreement Effective Date", "Date the license term starts.", "Agreement", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Current Term End Date", "Date the current term ends.", "Agreement", "Date", "ISO 8601", "2027-12-31", "Internal", "", "Y"),
       ("Auto-Renewal Indicator", "Whether the agreement renews automatically unless notice is given.", "Agreement", "Boolean", "", "Y", "Internal", "", ""),
       ("Non-Renewal Notice Period", "Notice required to prevent automatic renewal.", "Agreement", "Integer", "Days", "90", "Internal", "", ""),
       ("Notice Deadline Date", "Last date to give non-renewal notice (term end minus notice period).", "Agreement", "Date", "ISO 8601", "2027-10-02", "Internal", "", "Y", "Derived."),
       ("Governing Law", "Jurisdiction whose law governs the agreement.", "Agreement", "Code", "ISO 3166-1 alpha-2", "US", "Internal", "", ""),
       ("Agreement Business Owner", "Internal person accountable for the license.", "Agreement", "Reference (Employee)", "", "EMP-02231", "Internal", "", ""),
     ]),
   ]),
   ("Licensed Scope", "What is licensed under the agreement: datasets, territory, entities, users, applications and sites.", [
     ("Licensed Dataset Schedule", [
       ("Licensed Dataset", "Dataset licensed under the agreement.", "Licensed Scope", "Reference (Dataset)", "", "DSET-00412", "Internal", "", "Y"),
       ("Licensed Modules / Fields", "Modules, field packages or data categories included.", "Licensed Scope", "Text", "", "Fund static, performance, ratings; excludes holdings", "Internal", "", ""),
       ("Licensed Territory", "Countries in which the data may be used.", "Licensed Scope", "Code (multi)", "ISO 3166-1 alpha-2", "US; GB; LU", "Internal", "", "Y"),
       ("Licensed Legal Entities", "Group entities entitled to use the data (affiliates must be named if sharing is restricted).", "Licensed Scope", "Reference (Legal Entity)", "", "LEN-0001; LEN-0012", "Internal", "Morningstar", ""),
       ("Licensed Business Units", "Organization units licensed, where the license is departmental.", "Licensed Scope", "Reference (Org Unit)", "", "OU-0410 (Digital Advice)", "Internal", "Morningstar", ""),
       ("Licensed User Count", "Maximum number of named or concurrent users.", "Licensed Scope", "Integer", "", "45", "Internal", "FISD", "Y"),
       ("Licensed Application Count", "Maximum number of non-display applications or systems.", "Licensed Scope", "Integer", "", "3", "Internal", "FISD", ""),
       ("Scope Effective From", "Date the scope line became effective.", "Licensed Scope", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Scope Effective To", "Date the scope line ended.", "Licensed Scope", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Termination & Exit Obligations", "What must happen to data and derived data when the license ends.", [
     ("Termination Obligations", [
       ("Termination for Convenience Indicator", "Whether the firm may terminate before term end without cause.", "Agreement", "Boolean", "", "N", "Internal", "US Interagency TPRM Guidance", ""),
       ("Data Destruction Required Indicator", "Whether licensed data must be deleted or returned on termination.", "Agreement", "Boolean", "", "Y", "Internal", "", "Y"),
       ("Data Destruction Deadline", "Days after termination by which data must be destroyed.", "Agreement", "Integer", "Days", "30", "Internal", "", ""),
       ("Derived Data Survival Indicator", "Whether derived data created during the term may be kept after termination.", "Agreement", "Boolean", "", "Y", "FISD", "", "Y"),
       ("Regulatory Archive Exception Indicator", "Whether data embedded in records the firm must keep by law (e.g. client reports, marketing archives) is exempt from destruction.", "Agreement", "Boolean", "", "Y", "Internal", "", ""),
     ]),
   ]),
   ("Audit & Reporting Clauses", "Vendor audit rights and usage reporting obligations in the agreement.", [
     ("Compliance Clauses", [
       ("Vendor Audit Right Indicator", "Whether the vendor may audit the firm's use of the data.", "Agreement", "Boolean", "", "Y", "Internal", "FISD", "Y"),
       ("Audit Notice Period", "Advance notice the vendor must give before an audit.", "Agreement", "Integer", "Days", "30", "Internal", "", ""),
       ("Usage Reporting Frequency", "How often the firm must declare usage.", "Agreement", "Code", "Frequency", "Monthly", "Internal", "FISD", ""),
     ]),
   ]),
  ])

D("Permitted Use & Rights", "TD-USE",
  "Coded permitted-use grants under each license (display, non-display, derived data, redistribution, client reporting, marketing, index-tracking, AI/ML) and the attribution and disclaimer requirements that apply to outputs.",
  [
   ("Permitted Use Grant", "One coded right per agreement, dataset and use category, with its status and conditions.", [
     ("Permitted Use Grant", [
       ("Grant Agreement", "Agreement that grants or restricts the use.", "Permitted Use Grant", "Reference (Data License Agreement)", "", "DLA-000184", "Internal", "", ""),
       ("Grant Dataset", "Dataset the grant applies to (blank = all datasets under the agreement).", "Permitted Use Grant", "Reference (Dataset)", "", "DSET-00077", "Internal", "", "Y"),
       ("Permitted Use Category", "Category of use addressed by the grant.", "Permitted Use Grant", "Code", "Permitted Use Category", "Use in Marketing Materials", "FISD", "Internal", "Y"),
       ("Permission Status", "Whether the use is permitted under the license.", "Permitted Use Grant", "Code", "Permission Status", "Permitted with Conditions", "Internal", "", "Y"),
       ("Use Conditions", "Conditions or limits attached to the use.", "Permitted Use Grant", "Text", "", "Ratings only; must show rating date and attribution; no star ratings for funds < 3 years", "Internal", "Morningstar", ""),
       ("Non-Display Use Types", "Kinds of automated (non-display) processing permitted, using FISD terminology.", "Permitted Use Grant", "Code (multi)", "Non-Display Use Type", "Analytics & Reporting; Portfolio Management", "FISD", "", ""),
       ("Derived Data Ownership", "Who owns derived data created from the licensed data.", "Permitted Use Grant", "Code", "Derived Data Ownership", "Licensee, Non-Reverse-Engineerable", "FISD", "", ""),
       ("Redistribution Recipient Types", "Types of external recipients to whom data may be passed on.", "Permitted Use Grant", "Code (multi)", "Redistribution Recipient Type", "Clients; Distribution Partners", "Internal", "", ""),
       ("Redistribution Form Limits", "Limits on the form of redistributed data.", "Permitted Use Grant", "Code (multi)", "Redistribution Form Limit", "Non-Extractable Format; Limited Data Points", "Internal", "", ""),
       ("Delay Requirement", "Minimum delay before data may be shown or passed on.", "Permitted Use Grant", "Text", "", "15 minutes (real-time prices); month-end only (ratings)", "FISD", "", ""),
       ("Personal Data Use Restrictions", "Restrictions on using personal data in the dataset (e.g. use of aggregated account data only for the service the client asked for, no sale or sharing for cross-context advertising).", "Permitted Use Grant", "Text", "", "Aggregated account data used only for the client's plan and advice; no marketing use", "SEC Regulation S-P", "CCPA / CPRA", "", "Coordinate with 02 privacy and consent. Regulation S-P governs client account data; the CCPA governs non-GLBA personal data."),
       ("Legal Interpretation Confirmed Indicator", "Whether Legal has confirmed the coded interpretation.", "Permitted Use Grant", "Boolean", "", "Y", "Internal", "", "Y"),
       ("Grant Effective From", "Date the grant became effective.", "Permitted Use Grant", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Grant Effective To", "Date the grant ended.", "Permitted Use Grant", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Attribution & Disclaimer Requirements", "Source attribution, trademark and disclaimer text that must accompany displayed or redistributed data.", [
     ("Attribution Requirement", [
       ("Attribution Agreement", "Agreement that imposes the requirement.", "Attribution Requirement", "Reference (Data License Agreement)", "", "DLA-000184", "Internal", "", ""),
       ("Required Attribution Text", "Source attribution that must appear with the data.", "Attribution Requirement", "Text", "", "Source: Morningstar, Inc. As of 30/09/2026.", "Internal", "Morningstar", "Y"),
       ("Required Disclaimer Text", "Disclaimer or notice text required by the vendor.", "Attribution Requirement", "Text", "", "(c) 2026 Morningstar. All Rights Reserved. The information contained herein ...", "Internal", "", ""),
       ("Trademark Use Permitted Indicator", "Whether the vendor's names or logos may be used.", "Attribution Requirement", "Boolean", "", "Y", "Internal", "MSCI Index License", ""),
       ("Applies To Output Types", "Outputs to which the requirement applies.", "Attribution Requirement", "Code (multi)", "Output Type", "Factsheet; Website; Client Report", "Internal", "", ""),
     ]),
   ]),
  ])

D("Index & Benchmark Licensing", "TD-IDX",
  "Licenses to use indices: as benchmarks for funds and mandates, as the basis of index-tracking products, for index data display, together with product-level coverage and AUM-based fees.",
  [
   ("Index Use License", "How a licensed index (BMK- in 01) is used by the firm and under which license.", [
     ("Index Use", [
       ("Index License Agreement", "Agreement (DLA- of type Index License Agreement) covering the use.", "Index Use", "Reference (Data License Agreement)", "", "DLA-000231", "Internal", "MSCI Index License", ""),
       ("Licensed Index", "Benchmark or index licensed (master in 01).", "Index Use", "Reference (Benchmark)", "", "BMK-0001", "Internal", "", "Y"),
       ("Index Provider", "Index provider / benchmark administrator party.", "Index Use", "Reference (Party)", "", "PTY-500150 (MSCI)", "Internal", "MSCI Index License", ""),
       ("Index Use Type", "Way the firm uses the index.", "Index Use", "Code", "Index Use Type", "Index-Tracking Product", "Internal", "MSCI Index License", "Y"),
     ]),
   ]),
   ("Index Product License Coverage", "Products and share classes covered by an index-tracking product license and the fees due for each.", [
     ("Index Product Coverage", [
       ("Covered Product", "Product that tracks or uses the index (01).", "Index Product Coverage", "Reference (Product)", "", "PRD-01207", "Internal", "MSCI Index License", "Y"),
       ("Covered Share Class", "Share class covered, where fees or rights differ by class.", "Index Product Coverage", "Reference (Share Class)", "", "SHC-004412", "Internal", "", ""),
       ("Index Name in Product Name Indicator", "Whether the product name uses the index trademark (normally needs explicit license).", "Index Product Coverage", "Boolean", "", "Y", "MSCI Index License", "", ""),
       ("License Fee Basis", "How the product-level license fee is calculated.", "Index Product Coverage", "Code", "Index Fee Basis", "Basis Points on Average AUM", "MSCI Index License", "", ""),
       ("License Fee Rate", "Fee rate in basis points of AUM.", "Index Product Coverage", "Decimal", "Basis points", "2.5", "MSCI Index License", "", "Y"),
       ("Minimum Annual Fee", "Minimum annual fee per product or family.", "Index Product Coverage", "Amount", "", "USD 25,000", "MSCI Index License", "", ""),
       ("Fee AUM Basis", "AUM measure used to compute the fee (measure values come from 06).", "Index Product Coverage", "Code", "AUM Basis", "Average Daily Net Assets", "MSCI Index License", "", ""),
       ("Fee Payment Frequency", "How often the fee is calculated and paid.", "Index Product Coverage", "Code", "Frequency", "Quarterly", "MSCI Index License", "", ""),
       ("Coverage Effective From", "Date the product became covered.", "Index Product Coverage", "Date", "ISO 8601", "2025-11-03", "Internal", "", ""),
       ("Coverage Effective To", "Date coverage ended (closure, index change).", "Index Product Coverage", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

D("Entitlements & Access", "TD-ENT",
  "Who and what may access licensed data (ENT-): user, application and client subscriber entitlements (real-time quotes shown to clients), the client market data subscribers with their professional or non-professional status (one row per client), terminal and seat assignments, request and approval, recertification, and the inventory of non-display applications.",
  [
   ("Entitlement", "An effective-dated right of one user, client subscriber or application to access a dataset under a license.", [
     ("Entitlement", [
       ("Entitlement ID", "Unique identifier of the entitlement.", "Entitlement", "Identifier", "", "ENT-0098812", "Internal", "", "Y"),
       ("Entitlement Holder Type", "Whether the entitlement is held by a person, application or service account.", "Entitlement", "Code", "Entitlement Holder Type", "User", "FISD", "", ""),
       ("Entitled User", "Internal user holding the entitlement.", "Entitlement", "Reference (Employee)", "", "EMP-04410", "Internal", "", "", "PII"),
       ("Entitled Client", "Client (an individual or organization party in 02) holding an exchange market data entitlement as a subscriber, for real-time quotes displayed on the firm's website or apps.", "Entitlement", "Reference (Party)", "", "PTY-7203311", "CTA / UTP Plan", "", "", "PII. Added at W1b (plan section 5.1, CW-914). The client's professional or non-professional status is held once per client on Market Data Subscriber, not on each entitlement."),
       ("Entitled Application", "Consuming application holding the entitlement.", "Entitlement", "Reference (Consuming Application)", "", "APPL-00412", "Internal", "", ""),
       ("Entitled Dataset", "Dataset the entitlement grants access to.", "Entitlement", "Reference (Dataset)", "", "DSET-00077", "Internal", "", "Y"),
       ("Governing License", "Agreement that the entitlement counts against.", "Entitlement", "Reference (Data License Agreement)", "", "DLA-000184", "Internal", "", "Y"),
       ("Entitlement Type", "Kind of access granted.", "Entitlement", "Code", "Entitlement Type", "Terminal Seat", "Internal", "Bloomberg", ""),
       ("Vendor User ID", "Login or user ID assigned by the vendor.", "Entitlement", "Identifier", "External (Vendor)", "JSMITH123", "Internal", "", "", "PII"),
       ("Entitlement Status", "Lifecycle status of the entitlement.", "Entitlement", "Code", "Entitlement Status", "Active", "Internal", "", "Y"),
       ("Requested Date", "Date access was requested.", "Entitlement", "Date", "ISO 8601", "2026-02-03", "Internal", "", ""),
       ("Approver", "Person who approved the request.", "Entitlement", "Reference (Employee)", "", "EMP-02231", "Internal", "", ""),
       ("Approved Date", "Date the request was approved.", "Entitlement", "Date", "ISO 8601", "2026-02-04", "Internal", "", ""),
       ("Provisioned Date", "Date access became live.", "Entitlement", "Date", "ISO 8601", "2026-02-06", "Internal", "", ""),
       ("Revoked Date", "Date access was removed.", "Entitlement", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Last Recertification Date", "Date the entitlement was last recertified by the manager or owner.", "Entitlement", "Date", "ISO 8601", "2026-07-01", "Internal", "", "Y"),
       ("Last Used Date", "Last date the entitlement was used, from vendor or platform usage logs.", "Entitlement", "Date", "ISO 8601", "2026-09-28", "Internal", "", ""),
     ]),
   ]),
   ("Consuming Application Inventory", "Applications and systems that consume licensed data without a human viewing it (non-display) or that display it to users.", [
     ("Consuming Application", [
       ("Consuming Application ID", "41 application that this market data usage profile describes; the profile is keyed by the application.", "Consuming Application", "Reference (Application, 41)", "", "APPL-00412", "Internal", "FISD", "Y", "Keyed by the 41 Application since the Stage 4 consolidation (CD-264 option A); the 14 DAPP- key is retired. Name unchanged."),
       ("Application Name", "Name of the application.", "Consuming Application", "Text", "", "Distribution Data Warehouse", "Internal", "", "", "Derived copy (41) of Application.Application Name since the Stage 4 consolidation (CD-264)."),
       ("Usage Mode", "Whether the application uses the data for display, non-display or both.", "Consuming Application", "Code", "Usage Mode", "Non-Display", "FISD", "", "Y"),
       ("Non-Display Use Types", "Non-display purposes the application serves.", "Consuming Application", "Code (multi)", "Non-Display Use Type", "Analytics & Reporting", "FISD", "", ""),
       ("External Output Indicator", "Whether outputs leave the firm (client, partner, website, regulator).", "Consuming Application", "Boolean", "", "Y", "Internal", "", ""),
       ("Declared to Vendor Indicator", "Whether the application has been declared to the relevant vendors.", "Consuming Application", "Boolean", "", "Y", "FISD", "", "Y"),
     ]),
   ]),
   ("Market Data Subscribers", "Clients who receive exchange market data on the firm's website or apps, one row per client and status period, with the professional or non-professional status they attested under the exchange and plan subscriber agreements (W1b, plan section 5.1).", [
     ("Market Data Subscriber", [
       ("Subscriber Client", "Client (party in 02) who is a market data subscriber; key of the row with the status effective date.", "Market Data Subscriber", "Reference (Party)", "", "PTY-7203311", "CTA / UTP Plan", "", "Y", "PII. Added at W1b (CW-914)."),
       ("Market Data Subscriber Status", "Whether the client is a professional or non-professional subscriber as the exchange and plan subscriber agreements define it; drives the exchange fee and the monthly subscriber report for every entitlement the client holds.", "Market Data Subscriber", "Code", "Market Data Subscriber Status", "Non-Professional", "CTA / UTP Plan", "", "Y", "Added at W1b (CW-914)."),
       ("Subscriber Status Attested Date", "Date the client last attested the status (subscriber agreement or questionnaire).", "Market Data Subscriber", "Date", "ISO 8601", "2026-03-14", "CTA / UTP Plan", "", "", "Added at W1b (CW-914). Where the acceptance itself is held (02 Consent Record or 15) is open for W3."),
       ("Subscriber Status Effective From", "Date from which the status applies; a change of status is a new row.", "Market Data Subscriber", "Date", "ISO 8601", "2026-03-14", "Internal", "", "", "Added at W1b (CW-914)."),
     ]),
   ]),
  ])

D("Usage & License Compliance", "TD-CMP",
  "Usage declarations made to vendors, license audits (vendor-initiated or internal), findings, remediation and true-ups.",
  [
   ("Usage Declaration", "Periodic declarations of users, applications, recipients or AUM made to vendors.", [
     ("Usage Declaration", [
       ("Usage Declaration ID", "Unique identifier of the declaration.", "Usage Declaration", "Identifier", "", "UDC-2026-09-0031", "Internal", "", "Y"),
       ("Declaration Agreement", "Agreement the declaration is made under.", "Usage Declaration", "Reference (Data License Agreement)", "", "DLA-000231", "Internal", "", ""),
       ("Declaration Type", "What is being declared.", "Usage Declaration", "Code", "Declaration Type", "AUM-Linked Fee Declaration", "Internal", "FISD", "Y"),
       ("Declaration Period Start", "Start of the period declared.", "Usage Declaration", "Date", "ISO 8601", "2026-07-01", "Internal", "", ""),
       ("Declaration Period End", "End of the period declared.", "Usage Declaration", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
       ("Declared User Count", "Number of users declared.", "Usage Declaration", "Integer", "", "42", "Internal", "", ""),
       ("Declared Application Count", "Number of non-display applications declared.", "Usage Declaration", "Integer", "", "3", "FISD", "", ""),
       ("Declared AUM", "AUM declared for index-license fees (sourced from 06 measures).", "Usage Declaration", "Amount", "", "USD 4,820,000,000", "MSCI Index License", "", "Y"),
       ("Submission Due Date", "Date the declaration is due to the vendor.", "Usage Declaration", "Date", "ISO 8601", "2026-10-15", "Internal", "", "Y"),
       ("Submitted Date", "Date the declaration was submitted.", "Usage Declaration", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Declaration Status", "Workflow status of the declaration.", "Usage Declaration", "Code", "Declaration Status", "In Preparation", "Internal", "", ""),
     ]),
   ]),
   ("License Audit & Findings", "Vendor audits and internal license reviews, their findings, remediation and financial settlement.", [
     ("License Audit", [
       ("License Audit ID", "Unique identifier of the audit.", "License Audit", "Identifier", "", "LAU-0007", "Internal", "", "Y"),
       ("Audited Vendor", "Vendor whose data use is audited.", "License Audit", "Reference (Party)", "", "PTY-500210", "Internal", "", ""),
       ("Audit Type", "Who initiated and performs the audit.", "License Audit", "Code", "License Audit Type", "Vendor-Initiated", "Internal", "", ""),
       ("Audit Scope Period", "Usage period under review.", "License Audit", "Text", "", "2024-01-01 to 2025-12-31", "Internal", "", ""),
       ("Audit Status", "Workflow status of the audit.", "License Audit", "Code", "License Audit Status", "Fieldwork", "Internal", "", ""),
       ("Back-Fees Claimed", "Amount claimed by the vendor for past unlicensed use.", "License Audit", "Amount", "", "USD 180,000", "Internal", "", "Y"),
     ]),
     ("License Compliance Finding", [
       ("Finding Reference", "Identifier of the finding within the audit or review.", "Audit Finding", "Identifier", "", "LAU-0007-F03", "Internal", "", ""),
       ("Finding Type", "Kind of non-compliance found.", "Audit Finding", "Code", "License Finding Type", "Unlicensed User", "Internal", "FISD", "Y"),
       ("Finding Severity", "Severity of the finding.", "Audit Finding", "Code", "Severity", "High", "Internal", "", ""),
       ("Root Cause", "Root cause category.", "Audit Finding", "Code", "License Finding Root Cause", "Entitlement Not Revoked on Transfer", "Internal", "", ""),
       ("Remediation Action", "Agreed corrective action.", "Audit Finding", "Text", "", "Revoke 6 seats; add HR mover trigger to entitlement workflow", "Internal", "", ""),
       ("Remediation Due Date", "Date remediation must be complete.", "Audit Finding", "Date", "ISO 8601", "2026-11-30", "Internal", "", ""),
       ("True-Up Amount", "Additional license fee payable to regularize the use.", "Audit Finding", "Amount", "", "USD 42,000", "Internal", "", "Y"),
       ("Finding Status", "Status of the finding.", "Audit Finding", "Code", "Finding Status", "In Remediation", "Internal", "", ""),
     ]),
   ]),
  ])

D("Data Cost & Commercials", "TD-CST",
  "Contract value and pricing terms, vendor invoices, allocation of data cost to organization units, and the renewal and cost-optimization pipeline.",
  [
   ("Commercial Terms", "Price and payment terms of a data license agreement.", [
     ("Commercial Terms", [
       ("Annual Contract Value", "Annualized committed cost of the agreement.", "Commercial Terms", "Amount", "", "USD 412,000", "Internal", "", "Y"),
       ("Contract Currency", "Currency in which fees are charged.", "Commercial Terms", "Code", "ISO 4217", "USD", "ISO 4217", "", ""),
       ("Pricing Basis", "Unit on which the price is set.", "Commercial Terms", "Code", "Pricing Basis", "Per User per Month", "Internal", "", ""),
       ("Annual Price Escalator", "Contractual annual price increase.", "Commercial Terms", "Percentage", "", "5%", "Internal", "", ""),
     ]),
   ]),
   ("Data Invoice", "Vendor invoices for data, validated against the contract before payment.", [
     ("Data Invoice", [
       ("Data Invoice ID", "Unique internal identifier of the invoice.", "Data Invoice", "Identifier", "", "DINV-2026-01884", "Internal", "", "Y"),
       ("Vendor Invoice Number", "Invoice number assigned by the vendor.", "Data Invoice", "Identifier", "External (Vendor)", "INV-778120", "Internal", "", ""),
       ("Invoiced Agreement", "Agreement the invoice relates to.", "Data Invoice", "Reference (Data License Agreement)", "", "DLA-000184", "Internal", "", ""),
       ("Invoice Date", "Date of the invoice.", "Data Invoice", "Date", "ISO 8601", "2026-09-01", "Internal", "", ""),
       ("Service Period Start", "Start of the period invoiced.", "Data Invoice", "Date", "ISO 8601", "2026-10-01", "Internal", "", ""),
       ("Service Period End", "End of the period invoiced.", "Data Invoice", "Date", "ISO 8601", "2026-12-31", "Internal", "", ""),
       ("Invoice Net Amount", "Invoice amount before tax.", "Data Invoice", "Amount", "", "USD 103,000", "Internal", "", "Y"),
       ("Contract Validation Result", "Result of checking the invoice against contract price, scope and declared usage.", "Data Invoice", "Code", "Invoice Validation Result", "Matched", "Internal", "", ""),
       ("Invoice Status", "Processing status of the invoice.", "Data Invoice", "Code", "Invoice Status", "Approved for Payment", "Internal", "", ""),
       ("AP Document Reference", "Copy of the 19 Payable Invoice ID of the accounting record for this invoice; the link is held on 19 Payable Invoice.Source Data Invoice (CD-158).", "Data Invoice", "Identifier", "", "APV-2026-0018833", "Internal", "", ""),
     ]),
   ]),
   ("Cost Allocation", "Agreed split of data cost to organization units, the input to chargeback and to distribution profitability in 10.", [
     ("Data Cost Allocation", [
       ("Allocated Agreement", "Agreement whose cost is allocated.", "Cost Allocation", "Reference (Data License Agreement)", "", "DLA-000184", "Internal", "", ""),
       ("Allocated Org Unit", "Organization unit receiving the cost (09).", "Cost Allocation", "Reference (Org Unit)", "", "OU-0410", "Internal", "", "Y"),
       ("Allocation Share", "Share of the cost allocated to the unit.", "Cost Allocation", "Percentage", "", "60%", "Internal", "", "Y"),
       ("Allocation Driver", "Driver used to set the share.", "Cost Allocation", "Code", "Allocation Driver", "Entitled Users", "Internal", "", ""),
       ("Allocation Method Reference", "Allocation method defined in 10, where a standard method applies.", "Cost Allocation", "Reference (Allocation Method)", "", "ALM-012", "Internal", "", ""),
       ("Allocation Effective From", "Date the split became effective.", "Cost Allocation", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Allocation Effective To", "Date the split ended.", "Cost Allocation", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Renewal & Optimization", "Renewal cases, decisions and savings tracked ahead of notice deadlines.", [
     ("Renewal Case", [
       ("Renewal Case ID", "Unique identifier of the renewal case.", "Renewal Case", "Identifier", "", "RNW-2027-0014", "Internal", "", ""),
       ("Renewing Agreement", "Agreement up for renewal.", "Renewal Case", "Reference (Data License Agreement)", "", "DLA-000184", "Internal", "", "Y"),
       ("Renewal Decision", "Decision taken on renewal.", "Renewal Case", "Code", "Renewal Decision", "Renew - Reduced Scope", "Internal", "", "Y"),
       ("Negotiated Annual Value", "Annual value agreed after negotiation.", "Renewal Case", "Amount", "", "USD 398,000", "Internal", "", ""),
       ("Optimization Levers", "Levers used to reduce cost.", "Renewal Case", "Code (multi)", "Optimization Lever", "Seat Reduction; Vendor Consolidation", "Internal", "", ""),
       ("Overlapping Datasets", "Other datasets with overlapping content considered during the decision.", "Renewal Case", "Reference (Dataset)", "", "DSET-00413; DSET-00519", "Internal", "", ""),
     ]),
   ]),
  ])

D("Vendor Data Quality & Service Levels", "TD-DQS",
  "Service levels agreed with vendors, their measurement, and the vendor data issues and challenges raised by consuming domains.",
  [
   ("Vendor Service Levels", "SLAs on delivery, quality and support for a dataset, with measured results.", [
     ("Vendor Data SLA", [
       ("SLA Dataset", "Dataset the SLA applies to.", "Vendor SLA", "Reference (Dataset)", "", "DSET-00077", "Internal", "", ""),
       ("SLA Metric", "Dimension measured.", "Vendor SLA", "Code", "SLA Metric", "Delivery Timeliness", "Internal", "DCAM", "Y"),
       ("SLA Target", "Target value of the metric.", "Vendor SLA", "Text", "", "Delivered by 06:00 ET on 99% of business days", "Internal", "", ""),
       ("Measurement Period", "Period over which the SLA is measured.", "Vendor SLA", "Code", "Frequency", "Monthly", "Internal", "", ""),
       ("Measured Result", "Result for the latest period.", "Vendor SLA", "Text", "", "97.6%", "Internal", "", ""),
       ("SLA Breach Indicator", "Whether the latest result breached the target.", "Vendor SLA", "Boolean", "", "Y", "Internal", "", "Y"),
     ]),
   ]),
   ("Vendor Data Issues & Challenges", "Data errors, late deliveries and value challenges raised with vendors, and their resolution.", [
     ("Vendor Data Issue", [
       ("Vendor Data Issue ID", "Unique identifier of the issue.", "Vendor Data Issue", "Identifier", "", "VDI-004417", "Internal", "", "Y"),
       ("Issue Dataset", "Dataset in which the issue was found.", "Vendor Data Issue", "Reference (Dataset)", "", "DSET-00077", "Internal", "", ""),
       ("Issue Type", "Category of the issue.", "Vendor Data Issue", "Code", "Vendor Data Issue Type", "Incorrect Value", "Internal", "DCAM", "Y"),
       ("Issue Severity", "Severity of business impact.", "Vendor Data Issue", "Code", "Severity", "Medium", "Internal", "", ""),
       ("Issue Description", "Description of the issue and the records affected.", "Vendor Data Issue", "Text", "", "Share class SHC-004412 shown with wrong Morningstar category after reclassification", "Internal", "", ""),
       ("Detected Date", "Date the issue was detected.", "Vendor Data Issue", "Date", "ISO 8601", "2026-09-03", "Internal", "", ""),
       ("Detected By Domain", "Business domain that detected the issue.", "Vendor Data Issue", "Code", "Consuming Business Domain", "11 Market & Competitive Intelligence", "Internal", "", ""),
       ("Own Data Challenge Indicator", "Whether the issue challenges data the vendor holds about the firm's own products or people (e.g. fund data, ratings inputs).", "Vendor Data Issue", "Boolean", "", "Y", "Internal", "", ""),
       ("Vendor Ticket Reference", "Reference of the case in the vendor's support system.", "Vendor Data Issue", "Identifier", "External (Vendor)", "CS-2026-118823", "Internal", "", ""),
       ("Root Cause Category", "Cause of the issue once known.", "Vendor Data Issue", "Code", "Issue Root Cause", "Vendor Processing Error", "Internal", "", ""),
       ("Resolution Outcome", "Outcome of the issue or challenge.", "Vendor Data Issue", "Code", "Resolution Outcome", "Corrected by Vendor", "Internal", "", ""),
       ("Resolved Date", "Date the issue was resolved.", "Vendor Data Issue", "Date", "ISO 8601", "2026-09-10", "Internal", "", ""),
       ("Issue Status", "Status of the issue.", "Vendor Data Issue", "Code", "Issue Status", "Resolved", "Internal", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Vendor Type": ("Internal", [("Advisor & Firm Database","e.g. Discovery Data, FINTRX, Broadridge advisor data (intermediary channel)"),("Distribution Data Provider","e.g. Broadridge Distribution Insight (intermediary sales of the proprietary funds)"),("Exchange & Quote Provider","Exchanges and the CTA, UTP and OPRA plans: real-time and delayed quotes for client display, by subscriber"),("Account Aggregation Provider","e.g. Plaid, Envestnet Yodlee, MX: held-away account data linked by clients"),("Planning Data Provider","Capital market assumptions, tax, Social Security and mortality tables used by planning tools"),("Fund Data & Ratings Provider","e.g. Morningstar, LSEG Lipper, FE fundinfo"),("Index Provider","e.g. MSCI, S&P DJI, FTSE Russell, Bloomberg Indices"),("Market Data Provider","e.g. Bloomberg, LSEG"),("Consultant / Manager Database","e.g. Nasdaq eVestment"),("Intent & Marketing Data Provider","e.g. Bombora, ZoomInfo"),("ESG Data Provider","e.g. MSCI ESG, Sustainalytics, ISS ESG"),("Research & Survey Provider","e.g. Cerulli"),("Data Platform / Marketplace","Marketplace or data platform reselling data")]),
 "Dataset Subject Area": ("Internal", [("Advisor & Firm Data",""),("Distribution / Sales Data","Intermediary sales and assets"),("Industry Flows & AUM",""),("Fund Data",""),("Ratings & Research",""),("Index Data",""),("Market Data","Prices, reference and corporate actions"),("ESG Data",""),("Consultant Database",""),("Intent Data",""),("Contact & Firmographic Data",""),("Economic & Alternative Data",""),("Real-Time Market Data","Exchange quotes and trades for display to clients and staff"),("Account Aggregation Data","Held-away balances, securities and transactions (aggregated; not 49 Client Holdings)"),("Financial Planning Data","Assumptions and tables used in financial plans")]),
 "Vendor Relationship Status": ("Internal", [("Prospective","Under evaluation or trial"),("Onboarding",""),("Active",""),("Under Review","Performance or risk concerns"),("Exiting","Termination notice given"),("Inactive","No active agreements")]),
 "Vendor Strategic Tier": ("Internal (aligned to TPRM criticality tiering)", [("Tier 1 - Strategic","Hard to replace; supports critical processes or products"),("Tier 2 - Important",""),("Tier 3 - Standard",""),("Tier 4 - Low / Tactical","")]),
 "Vendor Contact Role": ("Internal", [("Account Manager",""),("Relationship Executive",""),("Client Support",""),("Licensing / Compliance Contact","Receives usage declarations"),("Billing Contact",""),("Technical / Data Delivery Contact",""),("Information Security Contact","")]),
 "Performance Rating": ("Internal", [("Exceeds Expectations",""),("Meets Expectations",""),("Partially Meets",""),("Does Not Meet","")]),
 "Risk Assessment Type": ("Internal / US Interagency TPRM Guidance", [("Onboarding Due Diligence",""),("Periodic Review",""),("Event-Driven Review","Incident, breach, ownership change"),("Renewal Review",""),("Exit Assessment","")]),
 "Vendor Risk Domain": ("Internal / US interagency third-party risk management guidance", [("Information Security",""),("Business Continuity & Resilience",""),("Data Privacy",""),("Financial Viability",""),("Legal & Regulatory",""),("Concentration",""),("Subcontracting / Fourth Party",""),("Reputational",""),("Forced Labor / Human Rights","Forced-labor and human-rights exposure in the supplier chain (US Tariff Act Section 307, UFLPA; firm policy).")]),
 "Risk Rating": ("Internal", [("Critical",""),("High",""),("Medium",""),("Low","")]),
 "Assurance Report Type": ("AICPA / ISO", [("SOC 1 Type I",""),("SOC 1 Type II",""),("SOC 2 Type I","Design of controls at a point in time"),("SOC 2 Type II","Design and operating effectiveness over a period"),("SOC 3",""),("ISO/IEC 27001 Certificate",""),("Penetration Test Summary",""),("Security Questionnaire Response","e.g. SIG or firm questionnaire")]),
 "Trust Services Category": ("AICPA Trust Services Criteria", [("Security","Common criteria; always in scope"),("Availability",""),("Processing Integrity",""),("Confidentiality",""),("Privacy","")]),
 "Auditor Opinion": ("AICPA", [("Unqualified",""),("Qualified",""),("Adverse",""),("Disclaimer","")]),
 "Data Basis": ("Internal", [("Reported","Sourced from filings, registers or providers"),("Estimated",""),("Modeled",""),("Survey-Based",""),("Mixed","")]),
 "Information Classification": ("Internal (aligned to CDMC classification)", [("Public",""),("Internal",""),("Confidential","Default for licensed data and license terms"),("Restricted","Personal or highly sensitive data")]),
 "Dataset Status": ("Internal", [("Proposed",""),("Trial / Evaluation",""),("Onboarding",""),("In Production",""),("Deprecated","Replacement planned"),("Retired","")]),
 "Covered Entity Type": ("Internal", [("Advisors",""),("Advisor Teams",""),("Branches",""),("Firms",""),("Institutional Investors",""),("Consultants",""),("Funds / Share Classes",""),("Indices",""),("Securities",""),("Companies (Issuers)",""),("Contacts (Marketing)","")]),
 "Data Granularity": ("Internal", [("Advisor",""),("Team",""),("Branch / Office",""),("Firm",""),("Share Class",""),("Fund",""),("Index",""),("Security",""),("Company",""),("Market / Category Aggregate","")]),
 "Frequency": ("Internal", [("Real-Time",""),("Intraday",""),("Daily",""),("Weekly",""),("Monthly",""),("Quarterly",""),("Semi-Annual",""),("Annual",""),("Ad Hoc","")]),
 "Identifier Scheme": ("Internal", [("FINRA CRD",""),("SEC File Number",""),("LEI","ISO 17442"),("ISIN","ISO 6166"),("CUSIP",""),("SEDOL",""),("FIGI",""),("Ticker",""),("Vendor Proprietary ID","e.g. Morningstar SecId, Discovery Data ID"),("Email Domain / Company Domain","Intent and firmographic data")]),
 "Delivery Method": ("Internal", [("API",""),("SFTP File",""),("Cloud Data Share","e.g. Snowflake Secure Data Sharing / Marketplace listing"),("Terminal / Desktop",""),("Web Platform",""),("Streaming Feed",""),("Excel Add-In",""),("Email","Discouraged")]),
 "Delivery Format": ("Internal", [("CSV / Delimited",""),("Fixed-Width",""),("XML",""),("JSON",""),("Parquet",""),("Database Table / View",""),("XLSX",""),("PDF","")]),
 "Consuming Business Domain": ("Program domain list", [("01 Investment Product & Service Offering",""),("02 Client & Household",""),("03 Advisor Organization, Coverage & Supervision",""),("04 Marketing, Digital & Client Engagement",""),("05 Intermediary & Institutional Distribution",""),("06 Client Assets, Flows & Channel Attribution",""),("08 Retail Conduct & Supervision",""),("09 Shared & Enterprise Reference Data",""),("10 Client Revenue, Pricing Economics & Profitability",""),("11 Market & Competitive Intelligence",""),("12 Institutional Client Servicing & Reporting",""),("13 Client Service & Communications",""),("Investment Management (outside program)",""),("45 Financial Planning & Advice","Wealth-manager domain (CW-002)")]),
 "Use Case": ("Internal", [("Advisor Targeting & Segmentation",""),("CRM Enrichment",""),("Sales & AUM Attribution",""),("Coverage Design & Potential",""),("Market Share & Competitive Analysis",""),("Product Development",""),("Marketing Campaigns",""),("Factsheets & Product Literature",""),("Client Reporting",""),("Benchmark Comparison",""),("Index-Tracking Portfolio Management",""),("RFP / Consultant Responses",""),("Analytics & AI Models","")]),
 "Permitted Use Category": ("FISD terminology / Internal", [("Internal Use - Display","Viewed by licensed users"),("Internal Use - Non-Display","Automated processing without human display"),("Derived Data Creation",""),("Redistribution to Clients",""),("Redistribution to Distribution Partners",""),("Use in Client Reporting",""),("Use in Marketing Materials","Factsheets, presentations, advertising"),("Public Website Display",""),("Use in Index-Tracking Product","Requires index license"),("Use as Benchmark",""),("Use in Regulatory Documents","Prospectus, summary prospectus, shareholder reports"),("AI / ML Model Training",""),("Generative AI Input / Retrieval","Use as prompt or retrieval context"),("Affiliate Sharing",""),("Service Provider Processing","")]),
 "Permission Status": ("Internal", [("Permitted",""),("Permitted with Conditions",""),("Requires Additional License",""),("Prohibited",""),("Not Addressed","Silent; treat as not permitted until Legal confirms")]),
 "Non-Display Use Type": ("FISD (non-display categories) / Internal", [("Analytics & Reporting",""),("Portfolio Management",""),("Index Calculation",""),("Fund Valuation / Pricing",""),("Risk Management",""),("Automated Trading",""),("Data Enrichment / Mastering",""),("Model Training","")]),
 "Derived Data Ownership": ("FISD / Internal", [("Licensee, Non-Reverse-Engineerable","Firm owns derived data that cannot recreate the source"),("Licensor Retains Rights",""),("Shared / Joint",""),("Not Addressed","")]),
 "Redistribution Recipient Type": ("Internal", [("Clients",""),("Prospects",""),("Distribution Partners",""),("Consultants",""),("Public / Website",""),("Regulators",""),("Service Providers","")]),
 "Redistribution Form Limit": ("Internal", [("Non-Extractable Format","e.g. PDF or image"),("Limited Data Points",""),("Delayed Data Only",""),("Aggregated Only",""),("Own Products Only","Data about the firm's own funds only"),("With Attribution","")]),
 "Output Type": ("Internal", [("Factsheet",""),("Presentation",""),("Website",""),("Client Report",""),("RFP / DDQ Response",""),("Prospectus / Shareholder Report",""),("Advertising",""),("Internal Report","")]),
 "Data Agreement Type": ("Internal", [("Master License Agreement",""),("Order Form / Schedule",""),("Data License Addendum",""),("Index License Agreement","Index data, benchmark use or index-tracking product license"),("Redistribution Agreement",""),("Evaluation / Trial Agreement",""),("Marketplace / Click-Through Terms","e.g. listing terms on a cloud marketplace"),("Data Processing Agreement","")]),
 "License Model": ("Internal (common vendor models)", [("Enterprise","Firm-wide use, not priced per user"),("Per Named User",""),("Per Concurrent User",""),("Per Application / Non-Display",""),("Site",""),("Departmental",""),("AUM-Linked","Typical for index-tracking products"),("Usage / Consumption-Based","API calls, records or credits"),("Product-Specific","")]),
 "Agreement Status": ("Internal", [("Draft",""),("In Negotiation",""),("Executed - Not Yet Effective",""),("Active",""),("Notice Given",""),("Expired",""),("Terminated","")]),
 "Index Use Type": ("Internal (index license terms)", [("Benchmark - Performance Comparison","Comparator only"),("Benchmark - Asset Allocation","Defines the portfolio's allocation or constraint"),("Benchmark - Performance Fee",""),("Index-Tracking Product","ETF or index fund tracking the index"),("Index Data Display Only",""),("Custom Index","Bespoke index calculated for the firm"),("Research / Analytics Only","")]),
 "Index Fee Basis": ("Internal (public descriptions of index licenses)", [("Basis Points on Average AUM",""),("Flat Annual Fee",""),("Minimum Fee plus Basis Points",""),("Per Product Fee",""),("Included in Data Subscription","")]),
 "AUM Basis": ("Internal", [("Average Daily Net Assets",""),("Month-End Net Assets",""),("Quarter-End Net Assets","")]),
 "Entitlement Holder Type": ("Internal / FISD", [("User",""),("Application",""),("Service Account",""),("Team / Shared",""),("Client Subscriber","Client of the firm receiving exchange market data on the website or apps (W1b)")]),
 "Entitlement Type": ("Internal", [("Terminal Seat","e.g. Bloomberg Terminal"),("Named Web User",""),("Concurrent User",""),("API Key",""),("Non-Display Application",""),("Data Share Access",""),("Excel Add-In User",""),("Client Real-Time Quote Display","Streaming or snapshot quotes shown to a client subscriber (W1b)")]),
 "Market Data Subscriber Status": ("CTA / UTP Plan and exchange subscriber agreements (confirm definitions)", [("Professional","Any subscriber that is not a Non-Professional Subscriber, e.g. a firm or a person registered or qualified with a regulator or acting as an investment adviser"),("Non-Professional","Natural person who uses the data solely for personal, non-business purposes, is not registered or qualified with the SEC, the CFTC, a state securities agency, an exchange or an SRO, and does not act as an investment adviser or use the data for others")]),
 "Entitlement Status": ("Internal", [("Requested",""),("Approved",""),("Active",""),("Suspended",""),("Revoked",""),("Rejected","")]),
 "Usage Mode": ("FISD", [("Display",""),("Non-Display",""),("Display and Non-Display","")]),
 "Declaration Type": ("Internal", [("User Count Declaration",""),("Non-Display Application Declaration",""),("AUM-Linked Fee Declaration",""),("Redistribution Recipient Report",""),("Annual License Certification",""),("Exchange Subscriber Report","Monthly professional and non-professional subscriber counts to the exchanges and plans (W1b)")]),
 "Declaration Status": ("Internal", [("Not Started",""),("In Preparation",""),("Submitted",""),("Acknowledged",""),("Queried by Vendor",""),("Overdue","")]),
 "License Audit Type": ("Internal", [("Vendor-Initiated",""),("Third-Party Auditor on Vendor's Behalf",""),("Internal Self-Assessment",""),("Internal Audit","")]),
 "License Audit Status": ("Internal", [("Notified",""),("Planning",""),("Fieldwork",""),("Draft Findings",""),("Negotiation",""),("Closed","")]),
 "License Finding Type": ("Internal", [("Unlicensed User",""),("Unlicensed Application",""),("Use Outside Permitted Scope",""),("Unauthorized Redistribution",""),("Missing Attribution",""),("Late / Inaccurate Declaration",""),("Data Retained After Termination",""),("Affiliate Use Not Licensed","")]),
 "License Finding Root Cause": ("Internal", [("Entitlement Not Revoked on Transfer",""),("Shadow Data Copy",""),("Unclear License Terms",""),("Process Not Followed",""),("Inventory Gap",""),("Vendor Error","")]),
 "Severity": ("Internal", [("Critical",""),("High",""),("Medium",""),("Low","")]),
 "Finding Status": ("Internal", [("Open",""),("In Remediation",""),("Remediated",""),("Accepted Risk",""),("Closed","")]),
 "Pricing Basis": ("Internal", [("Flat Annual",""),("Per User per Month",""),("Per Application",""),("Per Record / Entity",""),("Basis Points on AUM",""),("Credits / Consumption","")]),
 "Invoice Validation Result": ("Internal", [("Matched",""),("Price Variance",""),("Scope Variance",""),("Usage Variance",""),("Duplicate","")]),
 "Invoice Status": ("Internal", [("Received",""),("Under Validation",""),("Disputed",""),("Approved for Payment",""),("Paid",""),("Credited","")]),
 "Allocation Driver": ("Internal (coordinate with 10)", [("Entitled Users",""),("Usage Volume",""),("Fixed Percentage",""),("Equal Split",""),("AUM of Covered Products","")]),
 "Renewal Decision": ("Internal", [("Renew - As Is",""),("Renew - Reduced Scope",""),("Renew - Expanded Scope",""),("Replace with Alternative Vendor",""),("Terminate",""),("Pending","")]),
 "Optimization Lever": ("Internal", [("Seat Reduction",""),("Vendor Consolidation",""),("License Model Change",""),("Multi-Year Commitment",""),("Remove Unused Modules",""),("Enterprise Agreement","")]),
 "SLA Metric": ("Internal / DCAM data quality dimensions", [("Delivery Timeliness",""),("Completeness",""),("Accuracy",""),("Availability / Uptime",""),("Issue Response Time",""),("Issue Resolution Time","")]),
 "Vendor Data Issue Type": ("Internal / DCAM", [("Late Delivery",""),("Missing Records",""),("Incorrect Value",""),("Misclassification",""),("Identifier Mismatch",""),("Duplicate Records",""),("Unannounced Schema Change",""),("Stale Data","")]),
 "Issue Root Cause": ("Internal", [("Vendor Processing Error",""),("Vendor Source Error","Error in the vendor's upstream source"),("Firm-Supplied Data Error","Our own submission to the vendor was wrong"),("Mapping / Ingestion Error",""),("Methodology Difference",""),("Unknown","")]),
 "Resolution Outcome": ("Internal", [("Corrected by Vendor",""),("Challenge Rejected",""),("Partially Corrected",""),("Corrected Internally",""),("Accepted as Methodology","")]),
 "Issue Status": ("Internal", [("New",""),("Raised with Vendor",""),("In Progress",""),("Resolved",""),("Closed",""),("Canceled","")]),
}

REL = [
 ("Data Vendor","is a role of","Party (02 Client & Household: PTY-)","1 : 1","Vendor identity, LEI and addresses are mastered in 02."),
 ("Data Vendor","has","Vendor Contact Role","1 : 0..n","Contact persons are PTY- individuals in 02."),
 ("Data Vendor","is reviewed in","Vendor Performance Review","1 : 0..n",""),
 ("Data Vendor","is assessed by","Vendor Risk Assessment","1 : 1..n",""),
 ("Vendor Risk Assessment","is supported by","Assurance Report","1 : 0..n","SOC 2, ISO/IEC 27001 and other evidence."),
 ("Data Vendor","licenses","Data License Agreement","1 : 1..n","Order forms reference a master agreement (Parent Agreement)."),
 ("Data License Agreement","is signed by","Internal Legal Entity (09: LEN-)","n : 1",""),
 ("Data License Agreement","includes","Licensed Dataset Schedule","1 : 1..n",""),
 ("Licensed Dataset Schedule","covers","Dataset","n : 1",""),
 ("Data License Agreement","grants","Permitted Use Grant","1 : 1..n","One grant per dataset and use category."),
 ("Data License Agreement","imposes","Attribution Requirement","1 : 0..n",""),
 ("Dataset","is delivered via","Technical Feed (06 Client Assets, Flows & Channel Attribution: FEED-)","1 : 0..n","06 FEED- should reference DSET-/DLA- for purchased vendor data."),
 ("Dataset","is consumed through","Dataset Consumption","1 : 0..n","Lineage to consuming business domains (02, 03, 04, 06, 11 ...)."),
 ("Dataset Consumption","is permitted by","Permitted Use Grant","n : 1",""),
 ("Index Use","references","Benchmark (01 Investment Product & Service Offering: BMK-)","n : 1",""),
 ("Index Use","is licensed under","Data License Agreement (Index License Agreement)","n : 1",""),
 ("Index Use","covers","Index Product Coverage","1 : 0..n",""),
 ("Index Product Coverage","references","Product / Share Class (01 Investment Product & Service Offering: PRD-, SHC-)","n : 1",""),
 ("Entitlement","grants access to","Dataset","n : 1",""),
 ("Entitlement","counts against","Data License Agreement","n : 1",""),
 ("Entitlement","is held by","Employee (20 Human Capital: EMP-) / Client (02 Client & Household: PTY-) / Consuming Application","n : 1","Client subscribers hold real-time quote entitlements (W1b)."),
 ("Consuming Application","consumes","Dataset","n : n","Via Dataset Consumption."),
 ("Market Data Subscriber","is a role of","Client Party (02 Client & Household: PTY-)","n : 1","One row per client and status period; every entitlement the client holds reads the status from here (W1b)."),
 ("Usage Declaration","is made under","Data License Agreement","n : 1","AUM figures for index fees come from 06 measures."),
 ("License Audit","produces","License Compliance Finding","1 : 0..n",""),
 ("Data License Agreement","has","Commercial Terms","1 : 1",""),
 ("Data License Agreement","is billed by","Data Invoice","1 : 0..n","Accounting of invoices is handled by Finance / 10."),
 ("Data License Agreement","is allocated by","Data Cost Allocation","1 : 0..n",""),
 ("Data Cost Allocation","references","Org Unit (09: OU-) / Allocation Method (10: ALM-)","n : 1",""),
 ("Data License Agreement","is renewed via","Renewal Case","1 : 0..n",""),
 ("Dataset","is governed by","Vendor Data SLA","1 : 0..n",""),
 ("Dataset","has","Vendor Data Issue","1 : 0..n","Issues may relate to the firm's own products (01) or people (02) as held by the vendor."),
 ("Data License Agreement","is distinct from","Distribution Agreement (05: AGR-)","n/a","Data bought from vendors = DLA- (14); data exchanged with distribution partners = AGR- (05)."),
]

SRC = [
 ("FISD (SIIA) market data policy best practices and terminology","Financial Information Services Division, SIIA","https://fisd.net","Member resources; public summaries","Display, non-display and derived data definitions; standardization of market data policies","Permitted Use Category, Usage Mode, Non-Display Use Type, Derived Data Ownership, declarations",["FISD"]),
 ("AICPA SOC 2 - Trust Services Criteria","AICPA","https://www.aicpa-cima.com/topic/audit-assurance/audit-and-assurance-greater-than-soc-2","Standard (attestation)","SOC 2 Type I / II reports on security, availability, processing integrity, confidentiality and privacy","Assurance Report",["AICPA SOC 2"]),
 ("ISO/IEC 27001","ISO / IEC","https://www.iso.org/standard/27001","Standard (purchase)","Information security management system certification","Assurance Report Type",[]),
 ("Interagency Guidance on Third-Party Relationships: Risk Management (2023)","US Federal Reserve, FDIC, OCC","https://www.federalregister.gov/documents/2023/06/09/2023-12340/interagency-guidance-on-third-party-relationships-risk-management","Public guidance (banking; used as good practice)","Third-party lifecycle: planning, due diligence, contract negotiation, monitoring, termination","Risk Assessment Type, Vendor Risk Domain, Strategic Tier",["US Interagency TPRM Guidance"]),
 ("DCAM - Data Management Capability Assessment Model","EDM Council","https://edmcouncil.org/frameworks/dcam/","Member framework","Data ownership, stewardship, data quality management, data sourcing","Dataset ownership, SLA Metric, Data Management Metadata",["DCAM"]),
 ("CDMC - Cloud Data Management Capabilities","EDM Council","https://edmcouncil.org/frameworks/cdmc/","Free license","Cataloging and classification, authoritative sources, data sharing and lineage controls in cloud","Dataset classification, Authoritative Source Indicator, Hosting Model, Lineage",["CDMC"]),
 ("Snowflake Marketplace / Secure Data Sharing documentation","Snowflake","https://docs.snowflake.com/en/collaboration/collaboration-marketplace-about","Public documentation","Listings, provider/consumer model, paid listings, secure data sharing","Delivery Method (Cloud Data Share), Marketplace Listing",["Snowflake Marketplace"]),
 ("Bloomberg Data License (public product description)","Bloomberg","https://professional.bloomberg.com/products/data/data-license/","Public description; licensed product","Enterprise data delivery across reference, pricing, ESG, regulatory data; pricing by data and applications rather than users","License Model, Entitlement Type",[]),
 ("MSCI Index License Agreement for Funds (SEC filed exhibit)","MSCI Inc. / SEC EDGAR","https://www.sec.gov/Archives/edgar/data/1408198/000119312512086989/d264713dex101.htm","Public filing","Index license for funds: AUM-based fees on average daily net assets, quarterly in arrears, trademark use, product coverage","Index Product Coverage, Index Fee Basis, Usage Declaration (AUM)",["MSCI Index License"]),
 ("Morningstar data licensing (public reporting)","Morningstar / Financial Planning","https://www.financial-planning.com/news/consultants-call-morningstar-billing-unfair","Public article","Departmental licensing, affiliate sharing restrictions, redistribution fees","Licensed Business Units, Affiliate Sharing, Redistribution",[]),
 ("SEC Regulation S-P (17 CFR Part 248, Subpart A), including service-provider oversight","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-248/subpart-A","Regulation","Safeguarding customer information; oversight of service providers that receive it (e.g. account aggregators)","Personal Data Processed Indicator, Contains Personal Data Indicator, Personal Data Use Restrictions",["SEC Regulation S-P"]),
 ("California Consumer Privacy Act as amended by the CPRA","California Attorney General; California Privacy Protection Agency","https://oag.ca.gov/privacy/ccpa","Statute / regulation","Personal information in purchased and aggregated datasets; service provider and contractor terms; opt-out of sale or sharing","Contains Personal Data Indicator, Personal Data Use Restrictions, Personal Data Processed Indicator",["CCPA / CPRA"]),
 ("CTA and UTP Plans (consolidated tape) and exchange market data subscriber agreements, with OPRA for options","CTA Plan; UTP Plan; OPRA; US exchanges","https://www.ctaplan.com; https://www.utpplan.com; https://www.opraplan.com","Plan documents and subscriber agreements","Professional and non-professional subscriber definitions, display fees and monthly subscriber reporting","Entitled Client, Market Data Subscriber, Exchange Subscriber Report",["CTA / UTP Plan"]),
 ("ISO 4217 / ISO 3166 / ISO 8601","ISO","https://www.iso.org","Standard; code lists widely available","Currency, country and date codes","Reference code lists used throughout",["ISO 4217"]),
]
