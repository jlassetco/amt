"""Data Domain 17 - Instrument & Issuer Reference. Content module for taxonomy_builder.py."""

META = {
 "title": "Instrument & Issuer Reference Data Taxonomy",
 "subtitle": "Business domain 17 - Instrument & Issuer Reference | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "17_Instrument_and_Issuer_Reference/Instrument_and_Issuer_Reference_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the security master of a US wealth manager that runs a direct brokerage platform, digital and human advice, its own mutual funds, ETFs and CITs, workplace recordkeeping, institutional advisory and trust services. It defines every instrument the firm's funds and institutional portfolios hold, trade, price or reference as an underlying, and every instrument its clients can buy, hold or be recommended on the brokerage platform: what it is (type, asset class, CFI, issuer, currency), every identifier it carries (ISIN, CUSIP, SEDOL, FIGI, RIC, Bloomberg ID, UPI, internal), how it relates to other instruments and indices, its terms by asset class (equity, held funds, debt, coupon and redemption schedules, municipal securities, securitized products, listed and OTC derivatives, municipal fund securities such as 529 portfolios, private assets and fund interests), whether the platform allows it to be traded in fractional quantities or outside regular hours, where it is listed, how it is classified for investment and regulatory purposes, who issued it and how that issuer and the instrument are rated, and the corporate action events announced on it. It is stewarded by the security master (reference data) team in investment operations, which sources vendor data, scrubs it and sets up new instruments, which is why it sits apart from the product and platform team (01) and the party master (02). The firm is regulated and distributes in the US only; the instrument universe is global, so foreign instruments, issuers, listings and corporate actions stay. Stitched together from ISO 6166 (ISIN), ISO 10962 (CFI), ISO 18774 (FISN), ISO 10383 (MIC), ISO 4914 (UPI), OMG FIGI, the ANNA DSB product templates, ISO 15022 / ISO 20022 corporate action and security reference messages with SMPG market practice, the ISDA definitions and the FINOS Common Domain Model, the CFTC clearing requirement (17 CFR Part 50), OCC options symbology, FDIC deposit insurance rules (12 CFR Part 330), MSRB rules and EMMA, IRC sections 57 and 529, GICS, the NAIC SVO designation framework, SEC Rules 2a-7, 144 and 144A and FIBO SEC, DER and BE. Use it as a starting point for a security master, an EDM golden-copy model or a business glossary."),
  ("Scope", "In scope: the instrument master (equity, depositary receipts, fixed income including municipal securities and brokered certificates of deposit, money market instruments, third-party funds, own share classes, municipal fund securities (529 and ABLE portfolios), listed derivative contracts including retail-traded equity and index options, OTC derivative products at UPI level, private assets and LP fund interests), the instrument-level fractional and extended-hours trading eligibility flags with the 01 policy rule that set them, instrument identifiers across schemes, instrument relationships (underlying, conversion, depositary receipt, when-issued, successor), new-instrument setup requests, instrument and issuer classification assignments (firm asset class, GICS, ICB, BICS, firm sectors) and effective-dated regulatory instrument classifications (Rule 2a-7, Rule 144A, Regulation S, restricted securities, NAIC designation), equity, held-fund and municipal fund security terms, debt terms with coupon and redemption schedules, municipal security terms, securitized product terms, listed and OTC derivative terms, private asset and fund-interest terms, listings of third-party instruments, issuer profiles (the issuer role on a 02 party), issuer relationships, credit rating assignments, and corporate action event reference with event options. Out of scope (referenced by ID): issuers, guarantors, rating agencies, GPs, exchange operators and all other parties, their names, LEIs, legal parents, regulators and NAICS codes (02 party core); own products and share classes and their identifiers, listings, currency, domicile, vehicle and dealing terms (01 Investment Product; copied here only as Derived copies on Own Fund Share Class instruments); the tradable-universe and trading-feature policy rules, platform product availability and transaction-fee categories (01, CW-037); benchmarks and indices used as underlyings (01 Benchmark); countries, currencies, calendars and classification schemes (09 Shared & Enterprise Reference Data); licensed datasets (14 Third-Party Data & Licensing); peer funds (11 Market & Competitive Intelligence); employees (20 Human Capital); fund and institutional portfolio holdings, tax lots, commitments and portfolio transactions (18 Portfolio & Investment Book of Record). Held in other domains and not modeled here: client holdings, client tax lots and client-side corporate action processing at the broker-dealer (49), client orders and the eligibility checks that apply the flags held here (48), prices, factors, yields, index levels and rate fixings (22), trade economics and confirmations of the fund desk (26), fund-side corporate action entitlements, elections and payments (28), the firm's feeder funds and their access terms (01 Feeder Access Terms) and investee shareholder meetings (34)."),
  ("Structure", "Four levels: L1 Data Domain > L2 Data Family > L3 Data Business Object > L4 Data Business Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Instrument (INS-) is the master record. It carries Instrument Identifiers (IID-: ISIN, CUSIP, SEDOL, FIGI at each level, RIC, Bloomberg ID, UPI, OTC ISIN, exchange contract codes, vendor and internal schemes), is linked to other instruments and to benchmarks (BMK-, 01) through effective-dated Instrument Relationships, and is created through an Instrument Setup Request (ISR-). Its issuer is a party (PTY-, 02) that carries an Issuer Profile, Issuer Relationships (guarantor, credit parent override, sponsor) and Issuer Classification Assignments here. The instrument's terms are attribute groups chosen by asset class: Equity Terms, Fund Instrument Terms, Municipal Fund Security Terms, Debt Terms (with Coupon Schedule and Redemption Schedule rows), Municipal Security Terms, Securitized Product Terms, Listed Derivative Contract Terms, OTC Derivative Product Terms, Private Asset Terms and Fund Interest Terms. Fractional and extended-hours eligibility are flags on the Instrument, each with the 01 Tradable Universe Policy Rule (TUP-) that set it. Instrument Listings (LST-) place third-party instruments on venues (MIC). Instrument Classification Assignments and effective-dated Regulatory Instrument Classifications classify the instrument; Credit Rating Assignments rate the instrument or its issuer. Corporate Action Events (CAE-) are announced on an instrument and offer one or more Corporate Action Options. An own share class held in any book of record (first by client accounts, as client holdings mastered in 49; then by own portfolios, as portfolio holdings mastered in 18) is an Instrument of type Own Fund Share Class that references SHC- (01); every fact 01 holds about it is a Derived copy here. Fund and institutional portfolio holdings (18), client holdings (49), prices (22), fund desk trades (25, 26), client orders (48) and entitlements (28, 49) all key on INS- and CAE-; nothing here keys on them."),
  ("Design principles", "1) One instrument, many identifiers: the enterprise INS- key is stable; every numbering agency, vendor and internal number is an Instrument Identifier row with a scheme and effective period, and no identifier is repeated as a column elsewhere (the listing ticker lives on the Instrument Listing). 2) The issuer is a party, the issuer profile is a role: names, LEIs, legal parents, regulators and NAICS stay in 02; 17 holds only what the security master maintains (issuer type for limit testing, country of risk, investment sector, credit parent override, security-master issuer identifiers). 3) Never remaster own share classes: for an Own Fund Share Class instrument, name, FISN, currency, issue date, CFI, country of issue, identifiers, vehicle type, domicile, regulatory regime, dealing frequency, distribution policy and money market fund type are Derived copies of 01, and manager and issuer are left blank. 4) Reference, not market data: static and slowly changing terms belong here; prices, factors, yields, index levels and rate fixings are 22. Credit ratings are the one effective-dated observation kept here, because compliance and risk use them as reference. 5) Event reference, not processing: a corporate action event is announced once per instrument; entitlements and elections per fund portfolio are 28 and per client account 49. 6) One place per fact: a code list subtype (Equity Share Type, Private Asset Type) refines Instrument Type rather than repeating it, and indicators are kept only where no list answers the question. 7) Effective-date identifiers, relationships, classifications, regulatory classifications, ratings and listings so history can be reconstructed. 8) Flag Critical Data Elements (CDE). 9) Policy is not an instrument fact: the platform's tradable-universe and trading-feature rules are 01; 17 holds only each instrument's resulting flag and the rule that set it, and 48 applies it to client orders (CW-037)."),
  ("Applies To", "Shows the record each attribute belongs to: Instrument (including its term groups), Instrument Identifier, Instrument Relationship, Setup Request, Instrument Classification, Issuer Classification, Regulatory Classification, Coupon Period (a row of Coupon Schedule), Redemption Event (a row of Redemption Schedule), Listing, Issuer Profile, Issuer Relationship, Credit Rating, Corporate Action Event or Corporate Action Option."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify and match an instrument or event across systems, know what it is and in which currency it pays, link it to its issuer, test investment restrictions and regulatory eligibility, decide whether a client may trade it on the platform, settle, accrue and value it correctly, or process a corporate action on time. Confirm with the security master team, Investment Compliance, Fund Accounting, Investment Risk and Brokerage Operations."),
  ("Primary / Secondary Reference", "Standard, rule or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Vendor references (Bloomberg, ICE, LSEG, S&P, Aladdin, SimCorp) indicate common industry structure only, not a license to reproduce vendor field dictionaries. Next step: map each attribute to the security master of record and its vendor feeds, with a survivorship rule per field."),
  ("Notes", "Scope is the US wealth manager: EU/UK-only regulatory classifications, EU/UK reference data registers and the Solvency II look-through code were removed under CW-917 and are listed in the jurisdiction register; foreign instruments, listings and issuers are kept. Instrument and issuer data is not personal data, except the employee references on setup requests, issuer relationship overrides and corporate action scrubbing (PII, internal staff). Vendor-supplied values are licensed data: the source dataset (DSET-, 14) on each instrument determines permitted use and redistribution."),
  ("Tabs", "Hierarchy: Data Families, Object Groups and Data Business Objects with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: object-level cardinalities for the logical model, including references to other Data Domains | Sources: standards, rules and vendor models used, with owners, licenses and links."),
  ("Suggested next steps", "1) Validate families, instrument types, identifier schemes and CDEs with the security master team, Investment Compliance, Fund Accounting, Investment Risk, Brokerage Operations and the alternatives team that sets up feeder fund underlyings. 2) Name the security master of record (OMS / IBOR vendor, EDM tool or in-house) and set a golden-copy survivorship rule per field and per vendor. 3) Decide whether OTC derivatives are set up at product level (UPI) with trade economics in 26, or one instrument per trade. 4) Agree with 01 which own share classes are set up as instruments and how the derived copies are refreshed. 5) Agree with 02 the new Party Role Type values and which issuer parent drives concentration limits. 6) Agree with 28 who scrubs corporate action events and what the golden source is. 7) Confirm the licensed sector schemes with 14 (the NAIC designation is kept as an instrument attribute only, CW-165), and ask 09 to register investment classification schemes as ICS- records. 8) Harmonize Frequency, Record Status, Case Status, Approval Status, Message Standard and Data Provider with the enterprise shared lists (09), and Vehicle Type, Regulatory Regime, Distribution Policy and MMF Type with 01 (US values, CW-039). 9) Agree with 01 the Tradable Universe Policy Rule types that set the fractional and extended-hours flags, and with 48 and 49 how the flags and the options, CD, municipal and 529 terms are read. 10) Turn the Relationships tab into a logical instrument data model shared with 18, 22, 25, 26, 28, 31, 48 and 49."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

OWN = " Copied from 01 for own share classes; mastered here for third-party and other instruments."

# ---------------------------------------------------------------------------
D("Instrument Master", "IN-MST",
  "The instrument record itself: what it is, who issued it and in what currency, the identifiers it carries in every scheme, how it relates to other instruments and indices, and the request through which it was set up.",
  [
   ("Instrument Core", "Identity, type, issuer, currency and status of an instrument the firm holds, trades, prices or references as an underlying.", [
     ("Instrument", [
       ("Instrument ID", "Unique enterprise identifier of the instrument, assigned by the security master and never reused.", "Instrument", "Identifier", "", "INS-00412873", "Internal", "FIBO SEC", "Y"),
       ("Instrument Name", "Full descriptive name of the instrument as held in the security master." + OWN, "Instrument", "Text", "", "Apple Inc. Common Stock", "FIBO SEC", "ISO 20022", "", "Derived copy (01) on Own Fund Share Class instruments (01 Share Class name)."),
       ("FISN", "Financial Instrument Short Name built from the issuer short name and an abbreviated instrument description." + OWN, "Instrument", "Text", "ISO 18774", "APPLE INC/SH", "ISO 18774", "ISO 6166 (ANNA)", "", "Derived copy (01) on Own Fund Share Class instruments (01 Security Identifier FISN)."),
       ("Instrument Type", "Firm instrument type, aligned to ISO 10962 CFI categories and groups, that determines which term groups apply; own share classes always take 'Own Fund Share Class' whenever any book of record holds them (client holdings mastered in 49, portfolio holdings mastered in 18).", "Instrument", "Code", "Instrument Type", "Equity Share", "ISO 10962", "Internal", "Y"),
       ("Asset Class", "Level 1 of the firm asset-class hierarchy; derived within 17 from the Firm Asset Class classification assignment and must equal its level-1 node.", "Instrument", "Code", "Instrument Asset Class", "Equity", "Internal", "FIBO SEC", "Y", "Kept as a filter shortcut; the hierarchy is held once, in Instrument Classification Assignment."),
       ("CFI Code", "Six-letter Classification of Financial Instruments code assigned with the ISIN by the numbering agency (or by ANNA DSB for OTC derivatives)." + OWN, "Instrument", "Code", "ISO 10962", "ESVUFR", "ISO 10962", "ISO 6166 (ANNA)", "Y", "Derived copy (01) on Own Fund Share Class instruments."),
       ("Issuer", "Party that issued the instrument or is liable for it (company, government, third-party fund, SPV or portfolio company). Blank for Own Fund Share Class instruments, whose issuer is the own fund (see Own Investment Product).", "Instrument", "Reference (Party)", "", "PTY-7001234", "FIBO SEC", "ISO 20022", "Y", "Issuer core data (name, LEI, legal parents) is mastered in 02; issuer role data in Issuer Profile."),
       ("Denomination Currency", "Currency in which the instrument is denominated (nominal, par or share capital currency)." + OWN, "Instrument", "Code", "ISO 4217", "USD", "ISO 20022", "", "Y", "Derived copy (01) on Own Fund Share Class instruments (01 Share Class Currency)."),
       ("Country of Issue", "Country of the domestic market in which the instrument was issued; blank for international issues with an XS ISIN." + OWN, "Instrument", "Code", "ISO 3166-1 alpha-2", "US", "ISO 6166 (ANNA)", "", "", "Derived copy (01) on Own Fund Share Class instruments (01 Fund Domicile)."),
       ("Instrument Status", "Lifecycle status of the instrument in the security master; listing state is on Instrument Listing and default on Debt Terms.", "Instrument", "Code", "Instrument Status", "Active", "Internal", "", "Y"),
       ("Issue Date", "Date the instrument was first issued, or the contract listed for trading." + OWN, "Instrument", "Date", "ISO 8601", "1980-12-12", "ISO 20022", "", "", "Derived copy (01) on Own Fund Share Class instruments (01 Share Class Launch Date)."),
       ("Form of Security", "Whether the instrument is held in registered, bearer or book-entry form.", "Instrument", "Code", "External (ISO 20022 FormOfSecurity code)", "Registered", "ISO 20022", "", ""),
       ("Own Share Class", "Own share class this instrument represents, when an own fund share class is held in a client account (client holdings mastered in 49) or by an own portfolio (portfolio holdings mastered in 18), or is referenced by one.", "Instrument", "Reference (Share Class)", "", "SHC-004512", "Internal", "", "Y", "Populated only for Instrument Type 'Own Fund Share Class'; all share-class facts stay in 01."),
       ("Private Instrument Indicator", "Whether the instrument has no public identifier or listing and is known only by an internal identifier (private assets, fund interests, bilateral loans).", "Instrument", "Boolean", "", "N", "Internal", "", ""),
       ("Primary Data Provider", "Vendor whose record wins by default under the golden-copy survivorship rule; may differ from the dataset that licensed the record.", "Instrument", "Code", "Shared: Data Provider", "Bloomberg", "Internal", "", "", "Source Dataset answers licensing; this answers survivorship."),
       ("Source Dataset", "Licensed dataset that supplied the instrument record; determines permitted use and redistribution.", "Instrument", "Reference (Dataset)", "", "DSET-00117", "Internal", "", ""),
       ("Fractional Trading Eligible Indicator", "Whether clients may buy and sell the instrument in fractional share quantities on the brokerage platform, as set by the platform's fractional trading policy rule.", "Instrument", "Boolean", "", "Y", "Internal", "", "Y", "Instrument flag only (CW-037): the policy and its criteria are 01 Tradable Universe Policy Rule; 48 applies the flag to client orders; fractional client quantities are 49."),
       ("Fractional Trading Eligibility Rule", "Tradable universe policy rule whose criteria set the fractional trading flag on this instrument.", "Instrument", "Reference (Tradable Universe Policy Rule, 01)", "", "TUP-0008", "Internal", "", "", "Blank where the flag has never been evaluated."),
       ("Extended-Hours Eligible Indicator", "Whether clients may place orders in the instrument outside regular trading hours (pre-market and after-hours sessions) on the brokerage platform.", "Instrument", "Boolean", "", "N", "Internal", "FINRA Rule 2265", "Y", "Instrument flag only (CW-037): session times are on the 01 rule; the extended-hours risk disclosure (FINRA Rule 2265) is evidenced on the account in 15."),
       ("Extended-Hours Eligibility Rule", "Tradable universe policy rule whose criteria set the extended-hours flag on this instrument.", "Instrument", "Reference (Tradable Universe Policy Rule, 01)", "", "TUP-0009", "Internal", "", ""),
     ]),
   ]),
   ("Instrument Identifiers", "Every number by which the instrument is known in another scheme, with its scheme, level and effective period, so the enterprise INS- key is never overloaded. The only home of ISIN, CUSIP, SEDOL, FIGI, RIC, UPI and exchange contract codes in 17.", [
     ("Instrument Identifier", [
       ("Instrument Identifier ID", "Unique identifier of the instrument identifier record.", "Instrument Identifier", "Identifier", "", "IID-00981234", "Internal", "", ""),
       ("Identified Instrument", "Instrument the identifier belongs to.", "Instrument Identifier", "Reference (Instrument, 17)", "", "INS-00412873", "Internal", "", "Y"),
       ("Instrument Identifier Scheme", "Numbering scheme or vendor that issued the identifier, including the FIGI level where the scheme is FIGI.", "Instrument Identifier", "Code", "Instrument Identifier Scheme", "ISIN", "ISO 20022", "OMG FIGI / OpenFIGI", "Y"),
       ("Instrument Identifier Value", "The identifier exactly as issued by the scheme.", "Instrument Identifier", "Identifier", "External (format per scheme: ISO 6166, CUSIP, SEDOL, FIGI, ISO 4914)", "US0378331005", "ISO 6166 (ANNA)", "CUSIP Global Services", "Y"),
       ("Identifier Listing", "Listing the identifier applies to, for exchange-level identifiers (SEDOL, exchange-level FIGI, RIC).", "Instrument Identifier", "Reference (Listing, 17)", "", "LST-0007731", "OMG FIGI / OpenFIGI", "", "", "Blank on Own Fund Share Class instruments: 17 creates no listing for own share classes; the venue comes from 01 Listing."),
       ("Issuing Agency", "Numbering agency, registration authority or vendor that allocated the identifier.", "Instrument Identifier", "Reference (Party)", "", "PTY-7000088", "ISO 6166 (ANNA)", "", ""),
       ("Primary Identifier Indicator", "Whether this is the preferred identifier for the scheme when the instrument has more than one value in it.", "Instrument Identifier", "Boolean", "", "Y", "Internal", "", ""),
       ("Derived from Own Share Class Indicator", "Whether the identifier is a copy of an identifier mastered in 01 for an own share class rather than sourced by the security master.", "Instrument Identifier", "Boolean", "", "N", "Internal", "", "", "When Y the row is a Derived copy (01) of 01 Security Identifier or External Cross-Reference and must not be edited here."),
       ("Instrument Identifier Status", "Whether the identifier is current, retired or unverified.", "Instrument Identifier", "Code", "Shared: Identifier Status", "Active", "Internal", "", ""),
       ("Identifier Effective From", "Date the identifier became valid for the instrument.", "Instrument Identifier", "Date", "ISO 8601", "1980-12-12", "Internal", "", ""),
       ("Identifier Effective To", "Date the identifier ceased to be valid, for example after a CUSIP change on a corporate action.", "Instrument Identifier", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Instrument Relationships", "Effective-dated links between instruments, or from an instrument to an index: underlying, conversion, depositary receipt, when-issued and successor.", [
     ("Instrument Relationship", [
       ("Subject Instrument", "Instrument from which the relationship is stated (the derivative, the convertible, the depositary receipt, the when-issued line).", "Instrument Relationship", "Reference (Instrument, 17)", "", "INS-00500211", "Internal", "FIBO DER", "Y"),
       ("Related Instrument", "Instrument at the other end of the relationship; blank when the related item is an index.", "Instrument Relationship", "Reference (Instrument, 17)", "", "INS-00412873", "Internal", "FIBO DER", "Y"),
       ("Related Index", "Benchmark or index that is the underlying, when the subject is an index derivative or index-linked note.", "Instrument Relationship", "Reference (Benchmark)", "", "BMK-0001", "FIBO DER", "", ""),
       ("Instrument Relationship Type", "Nature of the relationship.", "Instrument Relationship", "Code", "Instrument Relationship Type", "Underlying Of", "Internal", "FIBO DER", "Y"),
       ("Relationship Ratio", "Quantity of the related instrument per unit of the subject (conversion ratio, depositary receipt ratio, deliverable quantity).", "Instrument Relationship", "Decimal", "", "2.0", "Internal", "", ""),
       ("Basket Weight", "Weight of the related instrument when the subject has a basket of underlyings.", "Instrument Relationship", "Percentage", "", "25%", "FINOS CDM", "", ""),
       ("Relationship Effective From", "Date the relationship took effect.", "Instrument Relationship", "Date", "ISO 8601", "2024-03-15", "Internal", "", ""),
       ("Relationship Effective To", "Date the relationship ended, for example when a when-issued line merges into the regular line.", "Instrument Relationship", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Instrument Setup", "Requests from the fund desks, brokerage operations, the alternatives team or operations to create, change or inactivate an instrument in the security master.", [
     ("Instrument Setup Request", [
       ("Setup Request ID", "Unique identifier of the setup request.", "Setup Request", "Identifier", "", "ISR-2026-004512", "Internal", "", ""),
       ("Setup Request Type", "What the request asks the security master team to do.", "Setup Request", "Code", "Setup Request Type", "New Instrument", "ISO 20022", "Internal", ""),
       ("Requested Identifier Scheme", "Scheme of the identifier supplied by the requester to find the instrument at vendors.", "Setup Request", "Code", "Instrument Identifier Scheme", "CUSIP", "Internal", "", ""),
       ("Requested Identifier Value", "Identifier supplied by the requester; blank for private instruments without a public identifier.", "Setup Request", "Identifier", "", "037833100", "Internal", "", ""),
       ("Requested Instrument Type", "Instrument type the requester expects the instrument to have.", "Setup Request", "Code", "Instrument Type", "Corporate Bond", "Internal", "", ""),
       ("Requesting Function", "Business function that raised the request.", "Setup Request", "Code", "Firm-defined", "Fixed Income Trading", "Internal", "", ""),
       ("Requested By", "Employee who raised the request.", "Setup Request", "Reference (Employee)", "", "EMP-30188", "Internal", "", "", "PII (employee)."),
       ("Request Timestamp", "When the request was raised.", "Setup Request", "Timestamp", "ISO 8601", "2026-10-05T13:42:00-04:00", "Internal", "", ""),
       ("Required By Timestamp", "When the instrument must be available, for example before a pre-trade compliance check or a new-issue allocation.", "Setup Request", "Timestamp", "ISO 8601", "2026-10-05T15:00:00-04:00", "Internal", "", ""),
       ("Setup Request Status", "Workflow status of the request.", "Setup Request", "Code", "Shared: Case Status", "Resolved / Completed", "Internal", "", ""),
       ("Setup Approval Status", "Approval status where the instrument type needs sign-off (private assets, new derivative products, new asset classes).", "Setup Request", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("Approved By", "Employee who approved the setup.", "Setup Request", "Reference (Employee)", "", "EMP-20991", "Internal", "", "", "PII (employee)."),
       ("Resulting Instrument", "Instrument created or changed by the request.", "Setup Request", "Reference (Instrument, 17)", "", "INS-00733120", "Internal", "", ""),
       ("Completion Timestamp", "When the instrument was released for use.", "Setup Request", "Timestamp", "ISO 8601", "2026-10-05T14:20:00-04:00", "Internal", "", ""),
       ("Rejection Reason", "Why the request was rejected or canceled.", "Setup Request", "Text", "", "Duplicate of INS-00733001", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Instrument Classification", "IN-CLS",
  "Investment and regulatory classification of instruments and issuers: firm asset class, GICS, ICB, BICS and firm sectors assigned with effective dates against scheme versions registered in 09 (ICS-), and the effective-dated regulatory eligibility classifications compliance and risk test against. Statutory industry codes (NAICS) stay on the 02 Organization.",
  [
   ("Instrument Classification", "Effective-dated assignment of an instrument to a node of an investment classification scheme.", [
     ("Instrument Classification Assignment", [
       ("Classified Instrument", "Instrument being classified.", "Instrument Classification", "Reference (Instrument, 17)", "", "INS-00412873", "Internal", "", "Y"),
       ("Instrument Classification Scheme", "Registered scheme version the assignment belongs to (firm asset class, GICS, ICB, BICS or a firm sector scheme).", "Instrument Classification", "Reference (Classification Scheme)", "", "ICS-FIRM-AC-2026", "Internal", "", "Y"),
       ("Instrument Classification Code", "Code of the node assigned in the scheme.", "Instrument Classification", "Code", "External (code of the scheme named)", "EQ-DEV-LC", "Internal", "", "Y"),
       ("Instrument Classification Level", "Level of the scheme hierarchy at which the code sits, copied from the scheme.", "Instrument Classification", "Integer", "", "3", "Internal", "", ""),
       ("Instrument Classification Label", "Name of the node assigned, copied from the scheme for readability.", "Instrument Classification", "Text", "", "Developed Markets Large Cap Equity", "Internal", "", ""),
       ("Instrument Classification Source", "Vendor that supplied the classification, or Other when assigned internally by the firm.", "Instrument Classification", "Code", "Shared: Data Provider", "Other", "Internal", "", ""),
       ("Instrument Classification Override Indicator", "Whether the security master or a research team overrode the vendor classification.", "Instrument Classification", "Boolean", "", "N", "Internal", "", ""),
       ("Instrument Classification Override Reason", "Why the vendor classification was overridden.", "Instrument Classification", "Text", "", "", "Internal", "", ""),
       ("Instrument Classification Effective From", "Date the assignment took effect.", "Instrument Classification", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Instrument Classification Effective To", "Date the assignment ended.", "Instrument Classification", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Issuer Classification", "Effective-dated assignment of an issuer to an investment sector (GICS, ICB, BICS or firm sector). Statutory industry codes (NAICS) are 02 Organization attributes.", [
     ("Issuer Classification Assignment", [
       ("Classified Issuer", "Issuer party being classified.", "Issuer Classification", "Reference (Party)", "", "PTY-7001234", "Internal", "", "Y"),
       ("Issuer Classification Scheme", "Registered sector scheme version the assignment belongs to.", "Issuer Classification", "Reference (Classification Scheme)", "", "ICS-GICS-2023", "GICS", "", "Y"),
       ("Issuer Sector Code", "Code of the sector node assigned (sub-industry, industry or sector code).", "Issuer Classification", "Code", "External (code of the scheme named)", "45202030", "GICS", "", "Y"),
       ("Issuer Sector Level", "Level of the scheme hierarchy at which the code sits, copied from the scheme.", "Issuer Classification", "Integer", "", "4", "GICS", "", ""),
       ("Issuer Sector Label", "Name of the sector node assigned, copied from the scheme for readability.", "Issuer Classification", "Text", "", "Technology Hardware, Storage & Peripherals", "GICS", "", ""),
       ("Issuer Classification Source", "Vendor that supplied the classification, or Other when assigned internally by the firm.", "Issuer Classification", "Code", "Shared: Data Provider", "MSCI", "Internal", "", ""),
       ("Primary Sector Scheme Indicator", "Whether this scheme drives compliance limits and client reporting for the issuer.", "Issuer Classification", "Boolean", "", "Y", "Internal", "", ""),
       ("Issuer Classification Effective From", "Date the assignment took effect.", "Issuer Classification", "Date", "ISO 8601", "2023-03-17", "Internal", "", ""),
       ("Issuer Classification Effective To", "Date the assignment ended.", "Issuer Classification", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Regulatory Classification", "Effective-dated US regulatory eligibility classifications of the instrument used by investment compliance (33), fund reporting and the brokerage platform. A new row is opened whenever any value changes (for example a Rule 144A or NAIC designation change).", [
     ("Regulatory Instrument Classification", [
       ("Regulatory Classified Instrument", "Instrument the classification set applies to.", "Regulatory Classification", "Reference (Instrument, 17)", "", "INS-00733120", "Internal", "", "Y"),
       ("Rule 2a-7 Eligible Security Indicator", "Whether the instrument is an eligible security for a US money market fund (maturity, credit quality and minimal credit risk determination).", "Regulatory Classification", "Boolean", "", "N", "SEC Rule 2a-7", "", "Y", "The minimal credit risk determination is made by the adviser; record its outcome, not the analysis."),
       ("Rule 144A Indicator", "Whether the instrument was offered under SEC Rule 144A to qualified institutional buyers.", "Regulatory Classification", "Boolean", "", "N", "SEC Rule 144A", "", "Y"),
       ("Regulation S Indicator", "Whether the instrument was offered outside the US under Regulation S.", "Regulatory Classification", "Boolean", "", "N", "Regulation S", "", ""),
       ("Restricted Security Indicator", "Whether the instrument is a restricted security that cannot be freely resold without registration or an exemption.", "Regulatory Classification", "Boolean", "", "N", "SEC Rule 144", "", ""),
       ("NAIC Designation Category", "NAIC designation and designation category of a fixed income instrument as published by the NAIC SVO or derived from eligible NRSRO ratings, carried as an instrument attribute of the investment universe (vendor-supplied; institutional advisory guidelines may test it); a regulatory designation, not a credit rating.", "Regulatory Classification", "Code", "NAIC Designation Category", "1.F", "NAIC SVO", "", ""),
       ("NAIC SVO Filing Status", "Basis on which the NAIC designation was obtained.", "Regulatory Classification", "Code", "NAIC SVO Filing Status", "Filing Exempt", "NAIC SVO", "", ""),
       ("Regulatory Classification Effective From", "Date this set of classifications took effect.", "Regulatory Classification", "Date", "ISO 8601", "2026-07-01", "Internal", "", "Y"),
       ("Regulatory Classification Effective To", "Date this set of classifications was superseded.", "Regulatory Classification", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Equity & Fund Terms", "IN-EQF",
  "Terms of equity, depositary receipt and preferred instruments, and of funds held by the firm's portfolios or bought by clients on the platform (third-party funds, LP fund interests and own share classes), including municipal fund securities (529 and ABLE portfolios). Facts 01 holds about own share classes and own plan portfolios are Derived copies here.",
  [
   ("Equity Terms", "Share subtype, voting, par, depositary receipt and preferred terms that the security master maintains for equity instruments.", [
     ("Equity Terms", [
       ("Equity Share Type", "Subtype of an instrument whose Instrument Type is Equity Share.", "Instrument", "Code", "Equity Share Type", "Ordinary / Common", "ISO 10962", "FIBO SEC", "Y"),
       ("Voting Rights Per Share", "Number of votes carried by one share.", "Instrument", "Decimal", "", "1", "ISO 10962", "", ""),
       ("Par Value", "Nominal value per share, where the share has one.", "Instrument", "Amount", "", "USD 0.00001", "FIBO SEC", "", ""),
       ("Shares Outstanding", "Number of shares outstanding, held as reference for issuer limits and ownership tests.", "Instrument", "Integer", "", "14840390000", "FIBO SEC", "", "", "Refreshed from issuer filings; not a daily market data series."),
       ("Shares Outstanding As-Of Date", "Date the shares outstanding figure refers to.", "Instrument", "Date", "ISO 8601", "2026-07-18", "Internal", "", ""),
       ("Dividend Frequency", "Regular dividend payment frequency declared by the issuer.", "Instrument", "Code", "Shared: Frequency", "Quarterly", "Internal", "", ""),
       ("Depositary Receipt Type", "Program type, where the Instrument Type is Depositary Receipt.", "Instrument", "Code", "Depositary Receipt Type", "Sponsored ADR Level III", "Internal", "FIBO SEC", ""),
       ("Depositary Bank", "Bank that issues the depositary receipts and holds the underlying shares.", "Instrument", "Reference (Party)", "", "PTY-7000412", "FIBO SEC", "", ""),
       ("Cumulative Dividend Indicator", "Whether unpaid preferred dividends accumulate and must be paid before common dividends.", "Instrument", "Boolean", "", "", "FIBO SEC", "", ""),
       ("Preferred Dividend Rate", "Stated dividend rate of a preferred share, as a percentage of par or liquidation preference.", "Instrument", "Percentage", "", "", "FIBO SEC", "", ""),
     ]),
   ]),
   ("Fund Instrument Terms", "Terms common to every fund the firm's portfolios hold or its clients can buy: third-party open-end funds, ETFs, CITs, closed-end and money market funds, LP fund interests, and own share classes.", [
     ("Fund Instrument Terms", [
       ("Fund Vehicle Type", "Legal and dealing form of the held fund." + OWN, "Instrument", "Code", "Shared: Vehicle Type", "Exchange-Traded Fund", "FIBO CIV", "openfunds", "Y", "Derived copy (01) on Own Fund Share Class instruments (01 Vehicle Type)."),
       ("Fund Regulatory Regime", "Regulatory regime the held fund is registered or exempt under (1940 Act registered, private fund under section 3(c)(1) or 3(c)(7), bank CIT)." + OWN, "Instrument", "Code", "Shared: Regulatory Regime", "US 1940 Act Registered", "openfunds", "", "", "Derived copy (01) on Own Fund Share Class instruments."),
       ("Fund Domicile", "Country where the held fund or underlying private fund is domiciled." + OWN, "Instrument", "Code", "ISO 3166-1 alpha-2", "US", "openfunds", "", "", "Derived copy (01) on Own Fund Share Class instruments (01 Fund Domicile)."),
       ("Fund Manager or General Partner", "Management company, adviser or general partner of a third-party fund or underlying private fund. Third-party funds only: blank for own share classes, whose managers are 01 Product Party Roles.", "Instrument", "Reference (Party)", "", "PTY-7002210", "openfunds", "ILPA", ""),
       ("Own Investment Product", "Own product the held share class belongs to, where the instrument is an own share class.", "Instrument", "Reference (Product)", "", "PRD-00231", "Internal", "", ""),
       ("Peer Fund", "Peer fund record in market intelligence, where a held third-party fund is also tracked as a peer.", "Instrument", "Reference (Peer Fund)", "", "PFD-0045512", "Internal", "", ""),
       ("Fund Dealing Frequency", "How often the held fund can be subscribed or redeemed." + OWN, "Instrument", "Code", "Shared: Frequency", "Daily", "openfunds", "", "", "Derived copy (01) on Own Fund Share Class instruments (01 Dealing Frequency)."),
       ("Fund Distribution Policy", "Whether the held share class accumulates or distributes income." + OWN, "Instrument", "Code", "Shared: Distribution Policy", "Distributing", "openfunds", "", "", "Derived copy (01) on Own Fund Share Class instruments (01 Distribution Policy)."),
       ("Money Market Fund Type", "Regulatory type of a held money market fund." + OWN, "Instrument", "Code", "Shared: MMF Type", "Government MMF", "SEC Rule 2a-7", "", "", "Derived copy (01) on Own Fund Share Class instruments (01 Money Market Fund Type)."),
     ]),
   ]),
   ("Municipal Fund Security Terms", "Portfolio-level terms of a municipal fund security offered by a state plan, above all a 529 college savings plan portfolio and an ABLE program portfolio, that clients hold on the platform. The plan itself (the issuing state trust or program) is the Issuer of the instrument, a 02 party, so its name is read from the party. Plan Sponsoring State, Program Manager and Plan Sales Channel are plan-level facts carried on each portfolio by design, because a separate plan object would add a business object for three slowly changing facts. Row rule: where the firm is the plan's program manager, the portfolios are its own products (01) and these attributes are Derived copies of 01; otherwise 17 masters them as third-party instruments.", [
     ("Municipal Fund Security Terms", [
       ("Municipal Fund Security Type", "Kind of state program the portfolio belongs to; refines Instrument Type Municipal Fund Security.", "Instrument", "Code", "Municipal Fund Security Type", "529 College Savings Plan Portfolio", "MSRB Rule D-12", "IRC §529", "Y"),
       ("Plan Sponsoring State", "State whose plan issues the portfolio; drives the in-state tax benefit question that 45 and 13 answer.", "Instrument", "Code", "ISO 3166-2", "US-NV", "IRC §529", "", "", "The issuing trust or state agency itself is the Issuer (02 party)."),
       ("Program Manager", "Firm that manages the plan for the state under a program management agreement; may be the firm itself.", "Instrument", "Reference (Party)", "", "PTY-7008110", "MSRB Rule G-45", "", ""),
       ("Plan Sales Channel", "Whether the plan is sold directly to the public or through external financial professionals.", "Instrument", "Code", "Municipal Fund Plan Sales Channel", "Direct-Sold", "MSRB Rule G-45", "", ""),
       ("Plan Portfolio Allocation Type", "How the portfolio's asset allocation is set over time.", "Instrument", "Code", "Municipal Fund Portfolio Allocation Type", "Enrollment-Date", "Internal", "", ""),
       ("Target Enrollment Year", "Year of expected first withdrawal that an age-based or enrollment-date portfolio is built for.", "Instrument", "Integer", "", "2036", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Debt Terms", "IN-DBT",
  "Terms of bonds, notes, money market instruments and loans: coupon, accrual and payment conventions, maturity, seniority, issue size and embedded options, with coupon and redemption schedules and securitized product terms. Rate fixings, factors, prices and yields are market data (22).",
  [
   ("Debt Terms", "Static terms of a debt instrument that drive accrual, payment, maturity and seniority.", [
     ("Debt Terms", [
       ("Coupon Type", "How the coupon is set over the life of the instrument.", "Instrument", "Code", "Coupon Type", "Fixed", "ISO 10962", "FIBO SEC", "Y"),
       ("Coupon Rate", "Annual coupon rate of a fixed-rate instrument, or the initial rate of a step instrument; later step rates are on Coupon Schedule.", "Instrument", "Percentage", "", "4.250%", "ISO 20022", "FIBO SEC", "Y"),
       ("Coupon Frequency", "How often coupons are paid.", "Instrument", "Code", "Shared: Frequency", "Semi-Annual", "ISO 20022", "", "Y"),
       ("Day Count Convention", "Convention used to accrue interest between payment dates.", "Instrument", "Code", "Day Count Convention", "30/360", "ISDA", "FINOS CDM", "Y"),
       ("Business Day Convention", "Rule that moves a payment date that falls on a non-business day.", "Instrument", "Code", "Business Day Convention", "Following", "ISDA", "FINOS CDM", ""),
       ("Payment Calendar", "Business day calendar used to adjust coupon and redemption dates.", "Instrument", "Reference (Calendar)", "", "CAL-US-SIFMA", "ISDA", "", ""),
       ("Reference Rate", "Floating-rate index the coupon resets from.", "Instrument", "Code", "External (ISO 20022 benchmark curve name / FpML floating rate index)", "SOFR", "ISO 20022", "FINOS CDM", "Y"),
       ("Reference Rate Term", "Tenor of the reference rate, where the index has several.", "Instrument", "Text", "", "3M", "ISO 20022", "FINOS CDM", ""),
       ("Floating Rate Spread", "Spread over the reference rate, in basis points.", "Instrument", "Decimal", "Basis points", "125", "FINOS CDM", "ISO 20022", ""),
       ("Coupon Floor Rate", "Minimum coupon rate on a floating-rate instrument.", "Instrument", "Percentage", "", "0.000%", "FINOS CDM", "", ""),
       ("Coupon Cap Rate", "Maximum coupon rate on a floating-rate instrument.", "Instrument", "Percentage", "", "", "FINOS CDM", "", ""),
       ("Maturity Date", "Date the principal is scheduled to be repaid in full.", "Instrument", "Date", "ISO 8601", "2034-05-15", "ISO 20022", "FIBO SEC", "Y"),
       ("Perpetual Indicator", "Whether the instrument has no scheduled maturity.", "Instrument", "Boolean", "", "N", "ISO 20022", "", ""),
       ("Dated Date", "Date interest starts to accrue.", "Instrument", "Date", "ISO 8601", "2024-05-15", "ISO 20022", "", ""),
       ("First Coupon Date", "Date of the first coupon payment, which may be a short or long first period.", "Instrument", "Date", "ISO 8601", "2024-11-15", "ISO 20022", "", ""),
       ("Issue Price", "Price at issue, as a percentage of par.", "Instrument", "Percentage", "", "99.512%", "ISO 20022", "", ""),
       ("Amount Issued", "Total principal amount issued.", "Instrument", "Amount", "", "USD 1,500,000,000", "ISO 20022", "", "Y"),
       ("Amount Outstanding", "Principal amount still outstanding after calls, sinks and buybacks, held as reference.", "Instrument", "Amount", "", "USD 1,500,000,000", "ISO 20022", "", ""),
       ("Amount Outstanding As-Of Date", "Date the amount outstanding figure refers to.", "Instrument", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
       ("Minimum Denomination", "Smallest amount in which the instrument can be held or traded.", "Instrument", "Amount", "", "USD 2,000", "ISO 20022", "", ""),
       ("Debt Seniority", "Ranking of the claim in liquidation, including lien position for secured debt.", "Instrument", "Code", "Debt Seniority", "Senior Unsecured", "FIBO SEC", "", "Y"),
       ("Debt Guarantor", "Party that guarantees payment on this instrument, where different from the issuer.", "Instrument", "Reference (Party)", "", "PTY-7001240", "FIBO SEC", "", ""),
       ("Callable Indicator", "Whether the issuer may redeem the instrument before maturity.", "Instrument", "Boolean", "", "Y", "ISO 20022", "", "Y", "Derived within 17 from Redemption Schedule; kept as a filter shortcut."),
       ("Puttable Indicator", "Whether the holder may require early redemption.", "Instrument", "Boolean", "", "N", "ISO 20022", "", "", "Derived within 17 from Redemption Schedule; kept as a filter shortcut."),
       ("Tax-Exempt Indicator", "Whether interest is exempt from US federal income tax (municipal securities).", "Instrument", "Boolean", "", "N", "IRC §103", "", ""),
       ("FDIC Insured Indicator", "Whether the instrument is a deposit of an FDIC-insured bank covered by federal deposit insurance up to the standard maximum per depositor, per bank and ownership category (brokered certificates of deposit).", "Instrument", "Boolean", "", "N", "FDIC 12 CFR Part 330", "", "Y", "The issuing bank is the Issuer (02 party); coverage per client is evaluated on 49 client holdings, not here."),
       ("Inflation-Linked Indicator", "Whether principal or coupon is indexed to an inflation index; Coupon Type stays the coupon mechanism (for example Fixed on a TIPS).", "Instrument", "Boolean", "", "N", "ISO 10962", "", ""),
       ("In Default Indicator", "Whether the issuer has missed a payment on the instrument or it is otherwise in default.", "Instrument", "Boolean", "", "N", "Internal", "", ""),
       ("Sustainable Bond Label", "Sustainable bond label claimed by the issuer under the ICMA principles.", "Instrument", "Code", "Sustainable Bond Label", "None", "ICMA", "", "", "Label claimed at issue; assessments of the label are 34."),
     ]),
   ]),
   ("Municipal Security Terms", "Terms of a US municipal bond or note that the security master maintains for state-specific fund limits, client tax reporting and disclosure lookup. The federal tax exemption is on Debt Terms; the EMMA identifier is an Instrument Identifier row.", [
     ("Municipal Security Terms", [
       ("Municipal Issuer State", "US state or territory of the municipal issuer, used for single-state fund tests and the client's in-state tax treatment.", "Instrument", "Code", "ISO 3166-2", "US-CA", "MSRB EMMA", "", "Y"),
       ("Municipal Security Type", "Source of repayment of the municipal security.", "Instrument", "Code", "Municipal Security Type", "General Obligation", "MSRB EMMA", "FIBO SEC", ""),
       ("AMT Subject Indicator", "Whether interest is a tax preference item for the federal alternative minimum tax (specified private activity bonds).", "Instrument", "Boolean", "", "N", "IRC §57", "", "Y"),
       ("Bond Insurer", "Financial guarantor that insures payment of principal and interest, where the issue is insured.", "Instrument", "Reference (Party)", "", "PTY-7008302", "MSRB EMMA", "", ""),
     ]),
   ]),
   ("Coupon Schedule", "Scheduled coupon periods of an instrument (one row per period), with accrual and payment dates and the fixed or step rate where known. Rate fixings of floating periods are 22.", [
     ("Coupon Schedule", [
       ("Coupon Instrument", "Instrument the coupon period belongs to.", "Coupon Period", "Reference (Instrument, 17)", "", "INS-00733120", "Internal", "", "Y"),
       ("Coupon Period Number", "Sequence number of the period from the first coupon.", "Coupon Period", "Integer", "", "3", "Internal", "", ""),
       ("Accrual Start Date", "First day of the accrual period.", "Coupon Period", "Date", "ISO 8601", "2025-05-15", "ISDA", "", "Y"),
       ("Accrual End Date", "Last day of the accrual period (exclusive).", "Coupon Period", "Date", "ISO 8601", "2025-11-15", "ISDA", "", ""),
       ("Coupon Payment Date", "Date the coupon is paid, after business day adjustment.", "Coupon Period", "Date", "ISO 8601", "2025-11-17", "ISO 20022", "", "Y"),
       ("Coupon Record Date", "Date on which holders of record are entitled to the coupon.", "Coupon Period", "Date", "ISO 8601", "2025-11-01", "ISO 20022", "", ""),
       ("Scheduled Coupon Rate", "Rate fixed in advance for the period (fixed and step coupons); blank for floating periods.", "Coupon Period", "Percentage", "", "4.250%", "ISO 20022", "", ""),
       ("Rate Fixing Date", "Date the floating rate for the period is fixed; the fixing itself is a 22 Reference Rate Fixing (CD-167).", "Coupon Period", "Date", "ISO 8601", "", "ISDA", "", ""),
       ("Irregular Period Indicator", "Whether the period is a short or long stub.", "Coupon Period", "Boolean", "", "N", "ISDA", "", ""),
     ]),
   ]),
   ("Redemption Schedule", "Scheduled and optional redemption events (one row per event): call, put, sinking fund, amortization and maturity.", [
     ("Redemption Schedule", [
       ("Redemption Instrument", "Instrument the redemption event belongs to.", "Redemption Event", "Reference (Instrument, 17)", "", "INS-00733120", "Internal", "", "Y"),
       ("Redemption Event Type", "Kind of redemption event.", "Redemption Event", "Code", "Redemption Event Type", "Call", "ISO 20022", "FIBO SEC", "Y"),
       ("Redemption Start Date", "First date the event can occur, or the scheduled date for a one-day event.", "Redemption Event", "Date", "ISO 8601", "2029-05-15", "ISO 20022", "", "Y"),
       ("Redemption End Date", "Last date of the exercise window for continuous calls or puts.", "Redemption Event", "Date", "ISO 8601", "2034-02-15", "ISO 20022", "", ""),
       ("Redemption Price", "Price paid on redemption, as a percentage of par.", "Redemption Event", "Percentage", "", "101.000%", "ISO 20022", "", "Y"),
       ("Scheduled Redemption Amount", "Principal amount redeemed by a sinking fund or amortization event.", "Redemption Event", "Amount", "", "", "ISO 20022", "", ""),
       ("Notice Period Days", "Minimum number of days' notice the exercising party must give.", "Redemption Event", "Integer", "Days", "30", "Internal", "", ""),
       ("Make-Whole Spread", "Spread over the reference government yield used to price a make-whole call, in basis points.", "Redemption Event", "Decimal", "Basis points", "25", "Internal", "", ""),
       ("Partial Redemption Allowed Indicator", "Whether the event may redeem part of the outstanding amount.", "Redemption Event", "Boolean", "", "Y", "ISO 20022", "", ""),
     ]),
   ]),
   ("Securitized Product Terms", "Deal, tranche and collateral terms of MBS, ABS, CMBS and CLOs. Pool factors are 22 Instrument Factor Observations and prepayment speeds 22 Pricing Analytics Observations (CD-167).", [
     ("Securitized Product Terms", [
       ("Securitized Collateral Type", "Type of collateral backing the instrument, including the agency program for agency MBS.", "Instrument", "Code", "Securitized Collateral Type", "Agency RMBS - UMBS", "ISO 10962", "FIBO SEC", "Y"),
       ("Pool Number", "Agency pool number or deal identifier assigned by the issuer.", "Instrument", "Identifier", "", "FN MA4783", "Internal", "", ""),
       ("Deal Name", "Name of the securitization deal or trust.", "Instrument", "Text", "", "Example CLO 2024-1 Ltd", "Internal", "", ""),
       ("Tranche Class", "Class or tranche designation within the deal.", "Instrument", "Text", "", "A-1", "Internal", "", ""),
       ("Tranche Seniority Rank", "Rank of the tranche in the payment waterfall, 1 being most senior.", "Instrument", "Integer", "", "1", "Internal", "", ""),
       ("Original Face Amount", "Face amount of the tranche at issue.", "Instrument", "Amount", "", "USD 320,000,000", "Internal", "", ""),
       ("Original Weighted Average Maturity", "Weighted average maturity of the collateral at issue, in months.", "Instrument", "Integer", "Months", "358", "Internal", "", ""),
       ("Payment Delay Days", "Days between the end of the accrual period and the payment date.", "Instrument", "Integer", "Days", "24", "Internal", "", ""),
       ("Collateral Manager or Servicer", "Party that manages the collateral (CLO manager) or services the loans.", "Instrument", "Reference (Party)", "", "PTY-7003301", "Internal", "", ""),
       ("Reinvestment Period End Date", "Date after which a managed deal can no longer reinvest principal proceeds.", "Instrument", "Date", "ISO 8601", "2029-04-20", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Derivative Terms", "IN-DRV",
  "Terms of exchange-traded derivative contracts and of OTC derivative products defined at product level (UPI). The UPI and exchange contract code are Instrument Identifier rows. Trade economics, confirmations and collateral are 26; prices and settlement prices are 22.",
  [
   ("Listed Derivative Contract Terms", "Contract specifications of futures and exchange-traded options, including the equity, ETF and index option series clients trade on the brokerage platform (one instrument per OCC series, identified by its OSI symbol as an Instrument Identifier row).", [
     ("Listed Derivative Contract Terms", [
       ("Contract Multiplier", "Value of one point of price movement per contract, or quantity of the underlying per contract.", "Instrument", "Decimal", "", "50", "Exchange", "OCC", "Y"),
       ("Contract Unit", "Description of the deliverable or reference quantity per contract.", "Instrument", "Text", "", "USD 50 x S&P 500 Index", "Exchange", "", ""),
       ("Tick Size", "Minimum price increment.", "Instrument", "Decimal", "", "0.25", "Exchange", "", ""),
       ("Tick Value", "Value of one tick per contract.", "Instrument", "Amount", "", "USD 12.50", "Exchange", "", ""),
       ("Expiry Date", "Date the contract expires.", "Instrument", "Date", "ISO 8601", "2026-12-18", "Exchange", "OCC", "Y"),
       ("Last Trading Date", "Last date the contract can be traded.", "Instrument", "Date", "ISO 8601", "2026-12-18", "Exchange", "", ""),
       ("First Notice Date", "First date the short may give notice of delivery on a physically settled future.", "Instrument", "Date", "ISO 8601", "", "Exchange", "", ""),
       ("Option Right", "Whether the option is a call or a put.", "Instrument", "Code", "External (ISO 10962 CFI option attribute: Call / Put)", "Call", "ISO 10962", "", "Y"),
       ("Strike Price", "Price at which the option may be exercised, in the Denomination Currency of the contract or in index points.", "Instrument", "Decimal", "", "6000", "Exchange", "OCC", "Y"),
       ("Option Style", "When the option may be exercised.", "Instrument", "Code", "Option Style", "European", "ISO 10962", "OCC", ""),
       ("Settlement Method", "Whether the contract settles by physical delivery or in cash.", "Instrument", "Code", "Settlement Method", "Cash", "ISO 10962", "OCC", "Y"),
       ("Clearing House", "Central counterparty that clears the contract.", "Instrument", "Reference (Party)", "", "PTY-7000301", "Exchange", "", "", "The Options Clearing Corporation for US listed options."),
       ("Option Expiration Type", "Listing cycle under which the option series was listed; one value per series, fixed at listing.", "Instrument", "Code", "Option Expiration Type", "Standard Monthly", "OCC", "Exchange", ""),
       ("Adjusted Option Indicator", "Whether OCC adjusted the series after a corporate action so that its deliverable is no longer the standard 100 shares of the underlying; the adjusted deliverable is stated in Contract Unit.", "Instrument", "Boolean", "", "N", "OCC", "", "Y", "An adjustment re-symbols the same series: the instrument keeps its INS- and takes a new OSI Instrument Identifier row with an effective date, the old OSI row being closed. Successor Of is used only where OCC lists a new series."),
     ]),
   ]),
   ("OTC Derivative Product Terms", "Product-level definition of an OTC derivative as identified by a UPI (held as an Instrument Identifier row); one product serves many trades.", [
     ("OTC Derivative Product Terms", [
       ("OTC Asset Class", "Asset class of the OTC product in the ISDA taxonomy.", "Instrument", "Code", "External (ISDA OTC taxonomy asset class)", "Interest Rate", "ISDA", "ANNA DSB", "Y"),
       ("OTC Base Product", "Base product in the ISDA taxonomy.", "Instrument", "Code", "External (ISDA OTC taxonomy base product)", "IR Swap", "ISDA", "ANNA DSB", ""),
       ("OTC Sub-Product", "Sub-product in the ISDA taxonomy.", "Instrument", "Code", "External (ISDA OTC taxonomy sub-product)", "Fixed Float", "ISDA", "ANNA DSB", ""),
       ("Notional Currency", "Currency of the notional amount.", "Instrument", "Code", "ISO 4217", "USD", "ANNA DSB", "FINOS CDM", "Y"),
       ("Other Notional Currency", "Second currency for FX and cross-currency products.", "Instrument", "Code", "ISO 4217", "", "ANNA DSB", "", ""),
       ("OTC Reference Rate", "Floating-rate index referenced by the product.", "Instrument", "Code", "External (ISO 20022 benchmark curve name / FpML floating rate index)", "SOFR", "ANNA DSB", "FINOS CDM", ""),
       ("OTC Delivery Type", "Whether the product settles physically or in cash.", "Instrument", "Code", "Settlement Method", "Cash", "ANNA DSB", "", ""),
       ("OTC Option Style", "Exercise style, where the product is an option or swaption.", "Instrument", "Code", "Option Style", "", "ANNA DSB", "", ""),
       ("Governing Definitions", "ISDA definitions booklet whose terms the product incorporates.", "Instrument", "Text", "", "2021 ISDA Interest Rate Derivatives Definitions", "ISDA", "FINOS CDM", ""),
       ("Clearing Mandate Indicator", "Whether the swap class is subject to the CFTC clearing requirement (classes of swaps required to be cleared, 17 CFR Part 50).", "Instrument", "Boolean", "", "Y", "CFTC 17 CFR Part 50", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Private Market Instruments", "IN-PVT",
  "Private instruments held by the firm's funds and feeder funds: private equity interests, direct and syndicated loans, real assets and limited partner interests in underlying funds (the underlying of a 01 feeder fund, CW-038). Most have no public identifier and are keyed by an internal identifier scheme. The feeder fund itself and its access terms are 01 (Feeder Access Terms); commitments and unfunded amounts are portfolio holdings mastered in 18.",
  [
   ("Private Asset Terms", "Terms of a private equity interest, loan or real asset.", [
     ("Private Asset Terms", [
       ("Private Asset Type", "Subtype of a private instrument whose Instrument Type is Loan, Private Equity Holding (a private equity interest; value name kept until the shared list is re-cut at W5) or Real Asset.", "Instrument", "Code", "Private Asset Type", "Direct Loan - Senior Secured", "Internal", "FIBO SEC", "Y"),
       ("Security Class Description", "Class of security held, as named in the investment documents.", "Instrument", "Text", "", "Series C Convertible Preferred", "Internal", "", ""),
       ("Loan Facility Type", "Type of loan facility, where the asset is a loan.", "Instrument", "Code", "Loan Facility Type", "Delayed Draw Term Loan", "Internal", "", ""),
       ("Administrative Agent", "Agent bank that administers the loan for the lenders.", "Instrument", "Reference (Party)", "", "PTY-7004102", "Internal", "", ""),
       ("Real Asset Country", "Country where the real asset is located.", "Instrument", "Code", "ISO 3166-1 alpha-2", "", "Internal", "", ""),
       ("Transfer Restriction Indicator", "Whether transfer requires consent of the issuer, agent or other holders.", "Instrument", "Boolean", "", "Y", "Internal", "", ""),
     ]),
   ]),
   ("Fund Interest Terms", "Terms specific to a limited partner interest in an underlying private fund held by an own fund of funds or secondaries vehicle. Manager and domicile are on Fund Instrument Terms.", [
     ("Fund Interest Terms", [
       ("Vintage Year", "Year of the underlying fund's first close or first capital call, per firm convention.", "Instrument", "Integer", "", "2024", "ILPA", "", ""),
       ("Private Fund Strategy", "Investment strategy of the underlying fund.", "Instrument", "Code", "Private Fund Strategy", "Buyout", "ILPA", "", ""),
       ("Commitment Currency", "Currency in which commitments to the underlying fund are made and called.", "Instrument", "Code", "ISO 4217", "USD", "ILPA", "", "Y"),
       ("Private Fund Legal Form", "Legal form of the underlying fund.", "Instrument", "Text", "", "Exempted Limited Partnership", "Internal", "", ""),
       ("Final Close Date", "Date of the underlying fund's final close.", "Instrument", "Date", "ISO 8601", "2025-06-30", "ILPA", "", ""),
       ("Investment Period End Date", "Date the underlying fund's investment period ends.", "Instrument", "Date", "ISO 8601", "2029-06-30", "ILPA", "", ""),
       ("Fund Term Years", "Contractual term of the underlying fund before extensions.", "Instrument", "Integer", "Years", "10", "ILPA", "", ""),
       ("Fund Term Extension Years", "Maximum extension of the term permitted by the fund documents.", "Instrument", "Integer", "Years", "2", "ILPA", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Listings", "IN-LST",
  "Listings of third-party instruments on trading venues (instrument x MIC). Listings of own ETF and closed-end share classes stay in 01 Listing.",
  [
   ("Instrument Listing", "Each venue on which a third-party instrument is listed or admitted to trading, with its local ticker and trading currency. The listing ticker is held here only, not as an identifier row.", [
     ("Instrument Listing", [
       ("Listing ID", "Unique identifier of the listing.", "Listing", "Identifier", "", "LST-0007731", "Internal", "", ""),
       ("Listed Instrument", "Instrument that is listed.", "Listing", "Reference (Instrument, 17)", "", "INS-00412873", "Internal", "", "Y"),
       ("Listing Venue MIC", "Segment MIC of the venue where one exists, otherwise the operating MIC.", "Listing", "Code", "ISO 10383 (MIC)", "XNGS", "ISO 10383", "", "Y"),
       ("Operating MIC", "Operating MIC of the exchange group that runs the venue.", "Listing", "Code", "ISO 10383 (MIC)", "XNAS", "ISO 10383", "", ""),
       ("Listing Ticker", "Local ticker of the instrument on the venue.", "Listing", "Text", "", "AAPL", "Exchange", "", "Y"),
       ("Listing Trading Currency", "Currency in which the instrument trades on the venue.", "Listing", "Code", "ISO 4217", "USD", "Exchange", "", ""),
       ("Primary Listing Indicator", "Whether this is the primary or home listing of the instrument.", "Listing", "Boolean", "", "Y", "Internal", "", "Y"),
       ("Round Lot Size", "Standard trading unit on the venue.", "Listing", "Integer", "", "100", "Exchange", "", ""),
       ("Trading Calendar", "Exchange calendar that governs trading days on the venue.", "Listing", "Reference (Calendar)", "", "CAL-XNAS", "Exchange", "", ""),
       ("Listing Status", "Whether the listing is active, suspended or delisted.", "Listing", "Code", "Listing Status", "Active", "Exchange", "", ""),
       ("Listing Date", "Date the instrument was admitted to trading on the venue.", "Listing", "Date", "ISO 8601", "1980-12-12", "Exchange", "", ""),
       ("Delisting Date", "Date the instrument ceased to be traded on the venue.", "Listing", "Date", "ISO 8601", "", "Exchange", "", ""),
       ("Delisting Reason", "Why the instrument was delisted.", "Listing", "Text", "", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Issuers & Ratings", "IN-ISS",
  "The issuer role the security master maintains on a 02 party (issuer type for limit testing, country of risk, security-master issuer identifiers), issuer relationships used for credit and concentration (guarantor, credit parent override, sponsor), and credit ratings of instruments and issuers. Issuer name, LEI, legal parents, organization type, regulators and NAICS are 02.",
  [
   ("Issuer Profile", "Issuer role on a 02 party: the facts only the security master maintains. No name or address attributes.", [
     ("Issuer Profile", [
       ("Issuer Party", "Party the issuer profile belongs to; key of the profile.", "Issuer Profile", "Reference (Party)", "", "PTY-7001234", "FIBO BE", "", "Y"),
       ("Issuer Type", "Credit and limit-testing class of the issuer (sovereign, agency, financial, corporate and so on) as used by compliance and risk.", "Issuer Profile", "Code", "Issuer Type", "Corporate", "Internal", "FIBO BE", "Y", "Differs from 02 Organization Type, which is the business type of the organization as a party."),
       ("Country of Risk", "Country whose economic and political risk the issuer is most exposed to.", "Issuer Profile", "Code", "ISO 3166-1 alpha-2", "US", "Internal", "", "Y"),
       ("Country of Risk Basis", "Rule or source used to determine the country of risk.", "Issuer Profile", "Code", "Country of Risk Basis", "Vendor Methodology", "Internal", "", ""),
       ("CUSIP Issuer Number", "First six characters of the CUSIP, identifying the issuer.", "Issuer Profile", "Identifier", "", "037833", "CUSIP Global Services", "", "Y", "Security-master issuer identifier; 02 Party Identifier holds general-purpose party identifiers (pending confirmation with 02)."),
       ("Bloomberg Company ID", "Bloomberg identifier of the issuing company, used to join vendor issuer-level data.", "Issuer Profile", "Identifier", "External (Vendor)", "101743", "Bloomberg", "", ""),
       ("Primary Equity Instrument", "Main listed equity of the issuer, used to map issuer-level data to an instrument.", "Issuer Profile", "Reference (Instrument, 17)", "", "INS-00412873", "Internal", "", ""),
       ("Issuer Profile Status", "Status of the issuer profile.", "Issuer Profile", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
       ("Issuer Profile Effective From", "Date the issuer profile was set up.", "Issuer Profile", "Date", "ISO 8601", "2019-01-02", "Internal", "", ""),
     ]),
   ]),
   ("Issuer Relationships", "Effective-dated links from an issuer to a related party used in credit and concentration analysis. Legal parents come from 02 (GLEIF Level 2).", [
     ("Issuer Relationship", [
       ("Subject Issuer", "Issuer from which the relationship is stated.", "Issuer Relationship", "Reference (Party)", "", "PTY-7001240", "Internal", "", "Y"),
       ("Related Party", "Party at the other end of the relationship (guarantor, credit parent, sponsor).", "Issuer Relationship", "Reference (Party)", "", "PTY-7001234", "Internal", "", "Y"),
       ("Issuer Relationship Type", "Nature of the relationship.", "Issuer Relationship", "Code", "Issuer Relationship Type", "Credit Parent Override", "Internal", "", "Y"),
       ("Guarantee Coverage", "Whether a guarantee covers all obligations of the issuer or only some.", "Issuer Relationship", "Text", "", "Full and unconditional", "Internal", "", ""),
       ("Override Reason", "Why the relationship departs from the 02 legal hierarchy.", "Issuer Relationship", "Text", "", "Finance subsidiary; credit risk sits with parent", "Internal", "", ""),
       ("Relationship Approved By", "Employee who approved the override.", "Issuer Relationship", "Reference (Employee)", "", "EMP-20991", "Internal", "", "", "PII (employee)."),
       ("Issuer Relationship Effective From", "Date the relationship took effect.", "Issuer Relationship", "Date", "ISO 8601", "2024-01-01", "Internal", "", ""),
       ("Issuer Relationship Effective To", "Date the relationship ended.", "Issuer Relationship", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Credit Ratings", "Effective-dated credit ratings of instruments (issue ratings) and issuers (issuer ratings) by nationally recognized statistical rating organizations (NRSROs), kept as reference for compliance and risk. NAIC designations are regulatory classifications, not credit ratings.", [
     ("Credit Rating Assignment", [
       ("Rated Instrument", "Instrument rated, for an issue rating; blank for an issuer rating.", "Credit Rating", "Reference (Instrument, 17)", "", "INS-00733120", "Internal", "", "Y"),
       ("Rated Issuer", "Issuer rated, for an issuer rating; blank for an issue rating (the issuer is read from the instrument).", "Credit Rating", "Reference (Party)", "", "", "Internal", "", "Y"),
       ("Credit Rating Agency", "NRSRO that issued the rating.", "Credit Rating", "Code", "Credit Rating Agency", "S&P Global Ratings", "SEC NRSRO", "", "Y"),
       ("Credit Rating Type", "What the rating measures and over what horizon.", "Credit Rating", "Code", "Credit Rating Type", "Long-Term Issue Credit Rating", "SEC NRSRO", "", "Y"),
       ("Credit Rating Value", "Rating symbol on the agency's scale.", "Credit Rating", "Code", "External (agency rating scale)", "AA+", "SEC NRSRO", "", "Y"),
       ("Credit Rating Outlook", "Agency's view of the likely direction of the rating over the medium term.", "Credit Rating", "Code", "Credit Rating Outlook", "Stable", "SEC NRSRO", "", ""),
       ("Credit Rating Watch Status", "Whether the rating is under short-term review for a possible change.", "Credit Rating", "Code", "Credit Rating Watch Status", "None", "SEC NRSRO", "", ""),
       ("Credit Rating Action", "Action the agency took on this date.", "Credit Rating", "Code", "Credit Rating Action", "Affirmed", "SEC NRSRO", "", ""),
       ("Credit Rating Action Date", "Date the agency published the rating action.", "Credit Rating", "Date", "ISO 8601", "2026-05-02", "SEC NRSRO", "", "Y"),
       ("Normalized Credit Rating Notch", "Rating converted to the firm's common numeric notch scale (1 = AAA) for comparison across agencies.", "Credit Rating", "Integer", "", "2", "Internal", "", ""),
       ("Credit Rating Effective To", "Date the rating was superseded or withdrawn.", "Credit Rating", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Credit Rating Source Dataset", "Licensed dataset that supplied the rating.", "Credit Rating", "Reference (Dataset)", "", "DSET-00131", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Corporate Action Events", "IN-CAE",
  "Corporate action events announced on an instrument and the options they offer, as golden-copy reference scrubbed from vendor and depository announcements. Entitlements, elections and payments are 28 per fund portfolio and 49 per client account. Investee shareholder and bondholder meetings are events of the meeting types here (CD-226); their agenda items, ballots and votes are 34.",
  [
   ("Corporate Action Event", "An announced corporate action on one instrument, with its type, mandatory or voluntary nature, key dates, announcement status and golden-copy status.", [
     ("Corporate Action Event", [
       ("Corporate Action Event ID", "Unique enterprise identifier of the event.", "Corporate Action Event", "Identifier", "", "CAE-2026-0012345", "Internal", "ISO 20022", "Y"),
       ("Official Corporate Action Event Reference", "Market-wide official reference of the event (COAF), used to match the event across custodians and vendors.", "Corporate Action Event", "Identifier", "", "US0000000123456789", "ISO 20022", "SMPG", "Y"),
       ("Event Instrument", "Instrument on which the event is announced.", "Corporate Action Event", "Reference (Instrument, 17)", "", "INS-00412873", "ISO 20022", "", "Y"),
       ("Corporate Action Event Type", "Type of event (ISO 15022 / 20022 CAEV).", "Corporate Action Event", "Code", "Corporate Action Event Type", "Cash Dividend", "ISO 15022", "ISO 20022", "Y"),
       ("Mandatory Voluntary Type", "Whether participation is mandatory, mandatory with options or voluntary (CAMV).", "Corporate Action Event", "Code", "Corporate Action Mandatory Voluntary", "Mandatory", "ISO 15022", "SMPG", "Y"),
       ("Corporate Action Announcement Status", "Confirmation status of the announcement as published by the issuer, agent or vendor.", "Corporate Action Event", "Code", "Corporate Action Announcement Status", "Confirmed", "ISO 20022", "SMPG", "Y"),
       ("Golden Copy Status", "Internal scrubbing status of the event in the security master.", "Corporate Action Event", "Code", "Corporate Action Golden Copy Status", "Scrubbed", "Internal", "", ""),
       ("Offeror", "Party making the offer in a tender, exchange or takeover event, where not the issuer.", "Corporate Action Event", "Reference (Party)", "", "PTY-7006120", "ISO 20022", "", ""),
       ("Announcement Date", "Date the event was officially announced.", "Corporate Action Event", "Date", "ISO 8601", "2026-07-31", "ISO 20022", "", ""),
       ("Ex-Date", "First date the instrument trades without the entitlement.", "Corporate Action Event", "Date", "ISO 8601", "2026-08-11", "ISO 20022", "SMPG", "Y"),
       ("Record Date", "Date on which holders of record are entitled to the event.", "Corporate Action Event", "Date", "ISO 8601", "2026-08-11", "ISO 20022", "SMPG", "Y"),
       ("Meeting Date", "Date of the investee general meeting or bondholder meeting, for the meeting event types (MEET, XMET, OMET, BMET, CMET); blank for other events.", "Corporate Action Event", "Date", "ISO 8601", "2027-05-14", "ISO 20022 seev.001", "SEC Form N-PX", "", "CD-226: 34 investee meeting agenda items and ballots key to the meeting CAE- and do not repeat the date."),
       ("Corporate Action Payment Date", "Date the cash or securities are distributed.", "Corporate Action Event", "Date", "ISO 8601", "2026-08-14", "ISO 20022", "", "Y"),
       ("Effective Date", "Date the event takes effect on the instrument, for example a split or name change.", "Corporate Action Event", "Date", "ISO 8601", "", "ISO 20022", "", ""),
       ("Announcement Message Standard", "Message standard of the announcement the golden copy was built from.", "Corporate Action Event", "Code", "Shared: Message Standard", "ISO 15022", "ISO 15022", "ISO 20022", ""),
       ("Announcement Source", "Data vendor or depository whose announcement was used as the primary source.", "Corporate Action Event", "Code", "Shared: Data Provider", "DTCC", "Internal", "", ""),
       ("Linked Event", "Related event processed together with this one, such as a rights issue and its subscription.", "Corporate Action Event", "Reference (Corporate Action Event, 17)", "", "CAE-2026-0012340", "ISO 20022", "SMPG", ""),
       ("Scrubbed By", "Employee who validated the event against multiple sources and released it.", "Corporate Action Event", "Reference (Employee)", "", "EMP-30412", "Internal", "", "", "PII (employee)."),
     ]),
   ]),
   ("Corporate Action Option", "Each option offered on an event, with its type, rates, ratios, deadline and default flag (ISO 15022 / 20022 CAOP).", [
     ("Corporate Action Option", [
       ("Option Event", "Event the option belongs to.", "Corporate Action Option", "Reference (Corporate Action Event, 17)", "", "CAE-2026-0012345", "ISO 20022", "", "Y"),
       ("Option Number", "Sequence number of the option within the event.", "Corporate Action Option", "Integer", "", "1", "ISO 20022", "SMPG", ""),
       ("Corporate Action Option Type", "Type of option (CAOP).", "Corporate Action Option", "Code", "Corporate Action Option Type", "Cash", "ISO 15022", "ISO 20022", "Y"),
       ("Default Option Indicator", "Whether this option applies if no election is made.", "Corporate Action Option", "Boolean", "", "Y", "ISO 20022", "SMPG", "Y"),
       ("Option Currency", "Currency of cash paid or charged under the option.", "Corporate Action Option", "Code", "ISO 4217", "USD", "ISO 20022", "", ""),
       ("Cash Rate Per Share", "Gross cash amount paid per share of the event instrument.", "Corporate Action Option", "Decimal", "", "0.26", "ISO 20022", "", "Y"),
       ("Resulting Instrument", "Instrument delivered under the option, for stock and exchange options.", "Corporate Action Option", "Reference (Instrument, 17)", "", "", "ISO 20022", "", ""),
       ("New Securities Quantity", "Quantity of the resulting instrument delivered per Old Securities Quantity held.", "Corporate Action Option", "Decimal", "", "", "ISO 20022", "", ""),
       ("Old Securities Quantity", "Quantity of the event instrument that gives rise to the New Securities Quantity.", "Corporate Action Option", "Decimal", "", "", "ISO 20022", "", ""),
       ("Option Price", "Price paid by the holder (subscription) or to the holder (tender) per unit.", "Corporate Action Option", "Amount", "", "", "ISO 20022", "", ""),
       ("Market Deadline", "Deadline set by the issuer or agent for elections on the option.", "Corporate Action Option", "Timestamp", "ISO 8601", "", "ISO 20022", "SMPG", "Y"),
       ("Fraction Disposition", "How fractional entitlements are treated.", "Corporate Action Option", "Code", "External (ISO 15022 DISF code)", "", "ISO 15022", "", ""),
       ("Option Status", "Announcement status of the option; Canceled or Withdrawn when the option is no longer offered.", "Corporate Action Option", "Code", "Corporate Action Announcement Status", "Confirmed", "ISO 20022", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 # Lists that mirror enterprise shared lists (values are a subset of, or proposed additions to, the shared list; see proposals_17.py)
 # Lists that mirror 01 Investment Product lists (same name, subset of the 01 values; shared candidates in proposals_17.py)
 # Local lists
 "Instrument Type": ("Internal (aligned to ISO 10962 CFI categories and groups)", [("Equity Share","CFI E: ES common, EP preferred, EL limited partnership units; subtype in Equity Share Type"),("Depositary Receipt","CFI ED (on equities) or DD (on debt)"),("Right","CFI RS / RP"),("Warrant","CFI RW"),("Government Bond","CFI DB"),("Municipal Bond","CFI DN"),("Corporate Bond","CFI DB / DT"),("Convertible Bond","CFI DC"),("Money Market Instrument","CFI DY: commercial paper, bills, bankers' acceptances; brokered CDs take Certificate of Deposit"),("Certificate of Deposit","Brokered certificate of deposit of an FDIC-insured bank (CW-039); CFI as allocated with the CUSIP"),("Mortgage-Backed Security","CFI DG"),("Asset-Backed Security","CFI DA"),("Collateralized Loan Obligation","CFI DA"),("Third-Party Fund","CFI C (CI, CE, CB and others); vehicle in Fund Vehicle Type"),("Own Fund Share Class","Own share class held in client accounts (49) or by own portfolios (18); references 01 SHC-; vehicle in Fund Vehicle Type (Derived copy 01)"),("Municipal Fund Security","529 college savings or ABLE program portfolio (MSRB Rule D-12; CW-039); subtype in Municipal Fund Security Type"),("Listed Future","CFI F"),("Listed Option","CFI O; one instrument per OCC series"),("OTC Derivative Product","CFI S, H or J (and M where applicable); UPI level"),("Loan","Syndicated or direct loan; subtype in Private Asset Type"),("Private Equity Holding","Subtype in Private Asset Type"),("Real Asset","Subtype in Private Asset Type"),("LP Fund Interest","Limited partner interest in an underlying fund"),("Cash / Deposit",""),("Other","")]),
 "Instrument Asset Class": ("Internal (firm asset-class taxonomy, level 1)", [("Equity",""),("Fixed Income",""),("Cash & Money Market",""),("Multi-Asset","Funds whose look-through spans asset classes"),("Derivative","Pending review with Investment Risk: may be replaced by the underlying asset class"),("Currency / FX","FX forwards and currency overlays"),("Private Equity",""),("Private Credit",""),("Real Assets",""),("Commodity","")]),
 "Instrument Status": ("Internal", [("Pending Setup","Created from a setup request, not yet released"),("Active",""),("Matured",""),("Called / Redeemed",""),("Expired","Derivative past expiry"),("Inactive","Kept for history only")]),
 "Instrument Identifier Scheme": ("ISO 20022 / Internal", [("ISIN","ISO 6166"),("CUSIP","CUSIP Global Services"),("CINS","CUSIP International Numbering System"),("SEDOL","LSEG; listing level"),("FIGI - Share Class Level","OMG FIGI"),("FIGI - Composite Level","OMG FIGI; country level"),("FIGI - Exchange Level","OMG FIGI; venue level"),("Bloomberg Ticker",""),("RIC","LSEG Reuters Instrument Code"),("Valoren","SIX"),("WKN","WM Datenservice"),("UPI","ISO 4914; ANNA DSB"),("OTC ISIN","ISO 6166; ANNA DSB"),("Exchange Contract Code","Listed derivative root symbol"),("OCC Option Symbol (OSI)","21-character OCC option symbol: root, expiration date, call or put, strike"),("MSRB EMMA Security ID","Identifier under which EMMA publishes the municipal security or 529 plan disclosures (confirm format)"),("Vendor Security ID","Other vendor identifier"),("Internal Private Asset ID","Firm scheme for instruments without a public identifier"),("Legacy System ID",""),("Other","")]),
 "Instrument Relationship Type": ("Internal / FIBO DER", [("Underlying Of","Derivative or structured note to its underlying"),("Converts Into","Convertible to the instrument it converts into"),("Exchangeable Into","Exchangeable bond to a third-party share"),("Depositary Receipt Of","Depositary receipt to the ordinary share"),("When-Issued Of","When-issued line to the regular line"),("Successor Of","New instrument after a merger, spin-off or identifier change"),("Cheapest-to-Deliver Basket Member","Bond deliverable into a futures contract"),("Reference Obligation Of","CDS product to its reference obligation"),("Tranche Of Deal","Tranche to another tranche of the same deal")]),
 "Setup Request Type": ("Internal (aligned to ISO 20022 reda security creation and maintenance)", [("New Instrument",""),("Amend Instrument",""),("Reactivate Instrument",""),("Inactivate Instrument",""),("Add Identifier",""),("Add Listing","")]),
 "NAIC Designation Category": ("NAIC SVO (designation 1 to 6 with categories, since 2021; confirm)", [("1.A",""),("1.B",""),("1.C",""),("1.D",""),("1.E",""),("1.F",""),("1.G",""),("2.A",""),("2.B",""),("2.C",""),("3.A",""),("3.B",""),("3.C",""),("4.A",""),("4.B",""),("4.C",""),("5.A",""),("5.B",""),("5.C",""),("6","")]),
 "NAIC SVO Filing Status": ("NAIC SVO (confirm)", [("Filing Exempt","Designation derived from eligible NRSRO ratings"),("SVO Designated","Filed with and designated by the SVO"),("Private Letter Rating","Designation based on a private rating"),("Not Filed","")]),
 "Equity Share Type": ("ISO 10962 / FIBO SEC", [("Ordinary / Common","CFI ES"),("Preferred","CFI EP"),("REIT Share","Share of a listed REIT"),("Limited Partnership Unit","CFI EL; listed MLP"),("Tracking Stock",""),("Other","")]),
 "Depositary Receipt Type": ("Internal", [("Sponsored ADR Level I","OTC traded"),("Sponsored ADR Level II","Exchange listed"),("Sponsored ADR Level III","Exchange listed with capital raising"),("Rule 144A ADR",""),("Unsponsored ADR",""),("GDR","Global depositary receipt")]),
 "Coupon Type": ("ISO 10962 / FIBO SEC", [("Fixed",""),("Floating",""),("Step-Up / Step-Down",""),("Zero Coupon",""),("Variable","Reset by formula or auction"),("Payment-in-Kind","")]),
 "Day Count Convention": ("ISDA definitions / FINOS CDM", [("30/360","Bond basis"),("30E/360","Eurobond basis"),("ACT/360",""),("ACT/365 (Fixed)",""),("ACT/ACT (ICMA)",""),("ACT/ACT (ISDA)",""),("ACT/365L",""),("Other","")]),
 "Business Day Convention": ("ISDA definitions / FINOS CDM", [("Following",""),("Modified Following",""),("Preceding",""),("Modified Preceding",""),("No Adjustment","")]),
 "Debt Seniority": ("Internal / FIBO SEC", [("Senior Secured - First Lien",""),("Senior Secured - Second Lien",""),("Senior Unsecured",""),("Senior Non-Preferred","Bank senior debt ranking below other senior liabilities in resolution (non-US bank issuers)"),("Subordinated","Including mezzanine debt"),("Junior Subordinated","")]),
 "Sustainable Bond Label": ("ICMA principles", [("None",""),("Green Bond","Use of proceeds"),("Social Bond","Use of proceeds"),("Sustainability Bond","Use of proceeds"),("Sustainability-Linked Bond","General-purpose proceeds; coupon linked to KPI targets")]),
 "Redemption Event Type": ("ISO 20022 / Internal", [("Call","Issuer option, at a fixed date or continuously"),("Make-Whole Call",""),("Put","Holder option"),("Sinking Fund",""),("Amortization","Scheduled principal repayment"),("Maturity",""),("Tender Offer Call",""),("Survivor Option","Holder's estate may redeem at par on the holder's death (brokered CDs, retail notes)")]),
 "Securitized Collateral Type": ("Internal / ISO 10962", [("Agency RMBS - GNMA",""),("Agency RMBS - UMBS","Fannie Mae / Freddie Mac uniform MBS"),("Agency CMO",""),("Non-Agency RMBS",""),("CMBS",""),("Auto ABS",""),("Credit Card ABS",""),("Student Loan ABS",""),("CLO",""),("Other ABS","")]),
 "Option Style": ("ISO 10962 / OCC", [("American",""),("European",""),("Bermudan",""),("Asian","")]),
 "Settlement Method": ("ISO 10962 / OCC", [("Cash",""),("Physical",""),("Elect at Exercise","")]),
 "Private Asset Type": ("Internal", [("Direct Loan - Senior Secured",""),("Direct Loan - Unitranche",""),("Direct Loan - Subordinated / Mezzanine",""),("Syndicated Loan",""),("Private Equity - Common",""),("Private Equity - Preferred",""),("Real Estate Equity",""),("Infrastructure Equity",""),("Other","")]),
 "Loan Facility Type": ("Internal / LSTA practice", [("Term Loan A",""),("Term Loan B",""),("Revolving Credit Facility",""),("Delayed Draw Term Loan",""),("Bridge Loan","")]),
 "Private Fund Strategy": ("Internal / ILPA", [("Buyout",""),("Growth Equity",""),("Venture Capital",""),("Private Credit",""),("Real Estate",""),("Infrastructure",""),("Secondaries",""),("Fund of Funds","")]),
 "Listing Status": ("Internal", [("Active",""),("Suspended","Trading halted on the venue"),("Delisted","")]),
 "Issuer Type": ("Internal / FIBO BE", [("Sovereign",""),("Supranational",""),("Agency / Government-Sponsored Enterprise",""),("Sub-Sovereign / Municipal",""),("Financial Institution",""),("Corporate","Including private portfolio companies"),("Fund / Collective Vehicle",""),("Special Purpose Vehicle",""),("Other","")]),
 "Country of Risk Basis": ("Internal", [("Domicile",""),("Primary Listing",""),("Revenue Exposure",""),("Vendor Methodology","Vendor's multi-factor country of risk"),("Analyst Override","")]),
 "Issuer Relationship Type": ("Internal", [("Guarantor",""),("Credit Parent Override","Parent used for credit and concentration when it differs from the 02 legal parent"),("Sponsor","Sponsor of an SPV, conduit or securitization"),("Keepwell Provider",""),("Successor Issuer","After merger or reorganization")]),
 "Credit Rating Agency": ("SEC NRSRO list", [("S&P Global Ratings",""),("Moody's Ratings",""),("Fitch Ratings",""),("Morningstar DBRS",""),("Kroll Bond Rating Agency",""),("AM Best","Insurer and insurance-related ratings"),("Other","Another NRSRO")]),
 "Credit Rating Type": ("Internal (agency definitions)", [("Long-Term Issuer Credit Rating",""),("Short-Term Issuer Credit Rating",""),("Long-Term Issue Credit Rating",""),("Short-Term Issue Credit Rating",""),("Local Currency Issuer Rating",""),("Foreign Currency Issuer Rating",""),("Recovery Rating","")]),
 "Credit Rating Outlook": ("Agency definitions", [("Positive",""),("Stable",""),("Negative",""),("Developing",""),("Not Assigned","")]),
 "Credit Rating Watch Status": ("Agency definitions", [("None",""),("Watch Positive",""),("Watch Negative",""),("Watch Developing","")]),
 "Credit Rating Action": ("Agency definitions", [("New Rating",""),("Upgrade",""),("Downgrade",""),("Affirmed",""),("Withdrawn",""),("Suspended","")]),
 "Corporate Action Event Type": ("ISO 15022 CAEV / ISO 20022 (selection)", [("Cash Dividend","DVCA"),("Stock Dividend","DVSE"),("Dividend Option","DVOP"),("Interest Payment","INTR"),("Partial Redemption","PCAL"),("Full Call / Early Redemption","MCAL"),("Final Maturity","REDM"),("Stock Split","SPLF"),("Reverse Split","SPLR"),("Rights Issue","RHTS"),("Merger","MRGR"),("Spin-Off","SOFF"),("Tender Offer","TEND"),("Exchange Offer","EXOF"),("Name Change","CHAN"),("Bankruptcy","BRUP"),("Class Action","CLSA"),("Consent Solicitation","CONS"),("Conversion","CONV"),("Annual General Meeting","MEET"),("Extraordinary General Meeting","XMET"),("Ordinary General Meeting","OMET"),("Bondholder Meeting","BMET"),("Court Meeting","CMET; UK scheme of arrangement"),("Other","OTHR")]),
 "Corporate Action Mandatory Voluntary": ("ISO 15022 CAMV", [("Mandatory","MAND"),("Mandatory with Options","CHOS"),("Voluntary","VOLU")]),
 "Corporate Action Announcement Status": ("ISO 20022 / SMPG", [("Preliminary","Announced, details incomplete"),("Confirmed","Details complete and confirmed by the issuer or agent"),("Canceled",""),("Withdrawn","")]),
 "Corporate Action Golden Copy Status": ("Internal", [("Pending Scrub","Received, not yet validated"),("Under Review","Sources disagree; analyst investigating"),("Scrubbed","Validated against multiple sources and released as golden copy"),("Exception","Released with an unresolved discrepancy")]),
 "Option Expiration Type": ("OCC / exchange product specifications (confirm)", [("Standard Monthly","Listed in the standard monthly cycle (third-Friday expiration), including long-dated series; time to expiry is read from Expiry Date"),("Weekly","Listed in the weekly cycle"),("Quarterly","Listed in the quarterly cycle"),("End-of-Month","Listed in the end-of-month cycle"),("Other","Any other listing cycle, including daily series")]),
 "Municipal Security Type": ("MSRB glossary / Internal", [("General Obligation","Backed by the issuer's taxing power"),("Revenue","Repaid from a specified revenue stream, including private activity bonds"),("Certificate of Participation","Lease-backed financing"),("Short-Term Note","Tax, revenue or bond anticipation note"),("Variable Rate Demand Obligation",""),("Other","")]),
 "Municipal Fund Security Type": ("MSRB Rule D-12", [("529 College Savings Plan Portfolio","IRC section 529 qualified tuition program"),("ABLE Program Portfolio","IRC section 529A"),("Local Government Investment Pool",""),("Other","")]),
 "Municipal Fund Plan Sales Channel": ("Internal", [("Direct-Sold","Sold by the plan directly to account owners"),("Advisor-Sold","Sold through external financial professionals (broker-dealers and advisers)")]),
 "Municipal Fund Portfolio Allocation Type": ("Internal", [("Enrollment-Date","Allocation glides with the target enrollment year"),("Age-Based","Allocation set by the beneficiary's age band"),("Static Allocation",""),("Individual Fund","Invests in a single underlying fund"),("Principal-Protected / Stable Value",""),("Other","")]),
 "Corporate Action Option Type": ("ISO 15022 CAOP / ISO 20022 (selection)", [("Cash","CASH"),("Securities","SECU"),("Cash and Securities","CASE"),("Take No Action","NOAC"),("Exercise","EXER"),("Lapse","LAPS"),("Buy Up","BUYA"),("Sell","SLLE"),("Consent Granted","CONY"),("Consent Denied","CONN"),("Other","OTHR")]),
}

# ---------------------------------------------------------------------------
REL = [
 ("Instrument","is identified by","Instrument Identifier","1 : 1..n","ISIN, CUSIP, SEDOL, FIGI, RIC, UPI, exchange contract codes, vendor and internal schemes, each effective-dated."),
 ("Instrument Identifier","may apply to","Instrument Listing","n : 0..1","Exchange-level identifiers (SEDOL, exchange FIGI, RIC); blank for own share classes."),
 ("Instrument","is issued by","Party (Issuer) [02]","n : 0..1","Issuer core (name, LEI, legal parents) mastered in 02; blank for own share classes."),
 ("Party (Issuer) [02]","has","Issuer Profile","1 : 0..1","Issuer role profile keyed by PTY- (CD-143, CD-144)."),
 ("Issuer Profile","has","Issuer Relationship","1 : 0..n","Guarantor, credit parent override, sponsor; legal parents come from 02 Legal Entity Hierarchy."),
 ("Instrument","is related to","Instrument via Instrument Relationship","n : n","Underlying, converts into, depositary receipt of, when-issued, successor."),
 ("Instrument Relationship","may reference","Benchmark [01]","n : 0..1","Underlying index of an index derivative; no Index object in 17."),
 ("Instrument (Own Fund Share Class)","represents","Share Class [01]","0..1 : 1","At most one instrument per own share class (pending SME question 5); 01 facts are Derived copies."),
 ("Instrument Setup Request","creates or changes","Instrument","n : 0..1",""),
 ("Instrument Setup Request","is raised by","Employee [20]","n : 1",""),
 ("Instrument Setup Request","is approved by","Employee [20]","n : 0..1",""),
 ("Instrument","is classified by","Instrument Classification Assignment","1 : 0..n","Firm asset class, GICS, ICB, BICS; effective-dated."),
 ("Instrument Classification Assignment","uses","Classification Scheme [09]","n : 1","ICS- register; GICS license held in 14."),
 ("Party (Issuer) [02]","is classified by","Issuer Classification Assignment","1 : 0..n","Investment sector only; NAICS stays on 02 Organization."),
 ("Issuer Classification Assignment","uses","Classification Scheme [09]","n : 1",""),
 ("Instrument","has","Regulatory Instrument Classification","1 : 0..n","Effective-dated; one current row."),
 ("Instrument","has eligibility flags set by","Tradable Universe Policy Rule [01]","n : 0..2","Fractional and extended-hours flags; policy in 01, checks in 48 (CW-037)."),
 ("Instrument","has","Coupon Schedule","1 : 0..n","Debt instruments only."),
 ("Instrument","has","Redemption Schedule","1 : 0..n","Call, put, sink, amortization, maturity."),
 ("Debt Terms","uses","Calendar [09]","n : 0..1","Payment calendar for date adjustment."),
 ("Instrument","is listed as","Instrument Listing","1 : 0..n","Third-party instruments; own listings stay in 01 Listing."),
 ("Instrument Listing","trades under","Calendar [09]","n : 0..1","Exchange calendar."),
 ("Instrument","is rated by","Credit Rating Assignment","1 : 0..n","Issue ratings."),
 ("Party (Issuer) [02]","is rated by","Credit Rating Assignment","1 : 0..n","Issuer ratings. Term conflict with 11 Rating Observation (fund ratings) noted in proposals_17.py."),
 ("Credit Rating Assignment","is sourced from","Dataset [14]","n : 0..1",""),
 ("Instrument","is subject of","Corporate Action Event","1 : 0..n","Announced once per instrument; fund-side entitlements (28) and client entitlements (49) reference CAE-."),
 ("Corporate Action Event","may be offered by","Party (Offeror) [02]","n : 0..1","Tender, exchange and takeover events."),
 ("Corporate Action Event","offers","Corporate Action Option","1 : 1..n","CAOP options with default flag."),
 ("Corporate Action Option","may deliver","Instrument","n : 0..1","Resulting instrument of stock, exchange and spin-off options."),
 ("Instrument","is sourced from","Dataset [14]","n : 0..1","Permitted use and redistribution of vendor data."),
 ("Fund Instrument Terms","may reference","Peer Fund [11]","n : 0..1","Held third-party fund also tracked as a peer."),
 ("Portfolio Holding [18]","holds","Instrument","n : 1","Fund and institutional portfolios; 18 references INS-; 17 holds no quantities or lots."),
 ("Client Holding [49]","holds","Instrument","n : 1","Client account holdings at the broker-dealer reference INS- (CW-007)."),
]

# ---------------------------------------------------------------------------
SRC = [
 ("ISO 6166 International Securities Identification Number (ISIN) and ANNA numbering agency practice","ISO; ANNA","https://www.anna-web.org","Standard; ANNA member service","ISIN structure, allocation by national numbering agencies, CFI and FISN allocated alongside the ISIN","Instrument Identifier, Instrument (Country of Issue, FISN, CFI Code)",["ISO 6166*"]),
 ("ISO 10962 Classification of Financial Instruments (CFI) (confirm edition and page)","ISO; ANNA (maintenance agency)","https://www.iso.org/standard/81140.html","Standard (purchase); code tables public via ANNA","Categories, groups and attributes of instruments; option, settlement and coupon attributes","Instrument Type, CFI Code, Coupon Type, Option Style, Settlement Method",["ISO 10962"]),
 ("ISO 18774 Financial Instrument Short Name (FISN)","ISO; ANNA","https://www.anna-web.org","Standard","Short name construction from issuer and instrument description","FISN",["ISO 18774"]),
 ("ISO 10383 Market Identifier Codes (MIC)","ISO; SWIFT (registration authority)","https://www.iso20022.org/market-identifier-codes","Open code list","Operating and segment MICs of trading venues","Instrument Listing",["ISO 10383"]),
 ("OMG Financial Instrument Global Identifier (FIGI) and OpenFIGI","Object Management Group; Bloomberg (registration authority)","https://www.openfigi.com","Open standard (MIT-licensed data)","FIGI hierarchy: share-class level, composite (country) level and exchange level","Instrument Identifier Scheme, Identifier Listing",["OMG FIGI*"]),
 ("ANNA Derivatives Service Bureau: OTC ISIN, UPI (ISO 4914) and CFI for OTC derivatives","ANNA DSB","https://www.anna-dsb.com","Utility service; product definitions public","Product-level identification of OTC derivatives, product templates by asset class, UPI reference data","OTC Derivative Product Terms, Instrument Identifier Scheme (UPI, OTC ISIN)",["ANNA DSB", "ISO 4914"]),
 ("CUSIP Global Services (CUSIP and CINS)","CUSIP Global Services (FactSet, on behalf of the American Bankers Association)","https://www.cusip.com","Licensed","Six-character issuer number and issue number; CINS for non-North American instruments","Instrument Identifier, Issuer Profile (CUSIP Issuer Number)",["CUSIP Global Services"]),
 ("GLEIF LEI and Level 2 relationship data","GLEIF","https://www.gleif.org","Open data","Issuer LEI and direct and ultimate parents (held in 02; referenced only)","Issuer Profile, Issuer Relationship (credit parent override vs legal parent)",["GLEIF"]),
 ("FIBO Securities (SEC), Derivatives (DER), Business Entities (BE) and Collective Investment Vehicles (CIV)","EDM Council","https://spec.edmcouncil.org/fibo/","Open (MIT license)","Instrument, issuer, equity, debt, securitization, fund and derivative concepts and their relationships","Instrument Core, Equity Terms, Fund Instrument Terms, Debt Terms, Instrument Relationship, Issuer Profile",["FIBO*"]),
 ("ISO 20022 message definitions: reda (security creation and maintenance) and seev (corporate action notification, seev.031)","ISO; SWIFT","https://www.iso20022.org/iso-20022-message-definitions","Open standard","Security reference content (form, denomination, dates, interest, redemption); corporate action event and option structure, key dates, COAF","Instrument, Debt Terms, Redemption Schedule, Setup Request Type, Corporate Action Event, Corporate Action Option",["ISO 20022"]),
 ("ISO 15022 corporate action messages (MT564) with CAEV, CAMV, CAOP and DISF codes","ISO; SWIFT","https://www.iso15022.org","Standard","Event type, mandatory / voluntary indicator, option type and fraction disposition codes","Corporate Action Event Type, Corporate Action Mandatory Voluntary, Corporate Action Option Type",["ISO 15022"]),
 ("SMPG corporate action market practice","Securities Market Practice Group","https://www.smpg.info","Public market practice documents","Event and option usage rules, mandatory / voluntary classification, key date definitions, announcement status","Corporate Action Event, Corporate Action Option",["SMPG"]),
 ("ISDA definitions and OTC derivatives taxonomy; FINOS Common Domain Model","ISDA; FINOS","https://www.finos.org/common-domain-model","ISDA definitions licensed; CDM open source","Day count and business day conventions, product taxonomy (asset class, base product, sub-product), product-level terms","Debt Terms, Coupon Schedule, OTC Derivative Product Terms",["ISDA", "FINOS CDM"]),
 ("CFTC clearing requirement (17 CFR Part 50, classes of swaps required to be cleared)","US CFTC","https://www.ecfr.gov/current/title-17/chapter-I/part-50","Regulation","Swap classes subject to mandatory clearing","Clearing Mandate Indicator",["CFTC 17 CFR Part 50"]),
 ("OCC options symbology (OSI) and listed option product specifications","The Options Clearing Corporation; US options exchanges","https://www.theocc.com","Public product and symbology documentation (confirm page)","21-character option symbol, standard and adjusted deliverables, expiration cycles, exercise style and settlement of US listed options","Listed Derivative Contract Terms, Instrument Identifier Scheme (OSI), Option Expiration Type",["OCC"]),
 ("FDIC deposit insurance coverage (12 CFR Part 330)","Federal Deposit Insurance Corporation","https://www.ecfr.gov/current/title-12/chapter-III/subchapter-B/part-330","Regulation","Insured deposits, standard maximum deposit insurance amount and ownership categories, pass-through coverage for brokered deposits","FDIC Insured Indicator, Instrument Type (Certificate of Deposit)",["FDIC 12 CFR Part 330"]),
 ("MSRB Rule D-12 (municipal fund security), Rule G-45 (529 plan underwriter reporting, confirm) and the EMMA disclosure system","Municipal Securities Rulemaking Board","https://www.msrb.org","Rules public; EMMA data public","Definition of municipal fund security (529 and ABLE plans, LGIPs); plan program manager and direct-sold or advisor-sold reporting; municipal security and plan disclosures on EMMA","Municipal Fund Security Terms, Municipal Security Terms, Instrument Identifier Scheme (EMMA)",["MSRB Rule D-12", "MSRB Rule G-45", "MSRB EMMA"]),
 ("Internal Revenue Code section 103 (interest on state and local bonds), section 529 (qualified tuition programs) and section 57(a)(5) (private activity bond interest as an AMT preference)","US Congress; IRS","https://www.law.cornell.edu/uscode/text/26/529","Statute","State-sponsored qualified tuition programs; tax preference for specified private activity bond interest","Debt Terms (Tax-Exempt Indicator), Municipal Fund Security Terms (Plan Sponsoring State), Municipal Security Terms (AMT Subject Indicator)",["IRC §103", "IRC §529", "IRC §57"]),
 ("FINRA Rule 2265 (extended hours trading risk disclosure)","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2265","Rule","Risk disclosure before a customer trades in extended hours","Extended-Hours Eligible Indicator",["FINRA Rule 2265"]),
 ("Global Industry Classification Standard (GICS)","MSCI; S&P Dow Jones Indices","https://www.msci.com/our-solutions/indexes/gics","Licensed (license held in 14)","Sector, industry group, industry and sub-industry levels","Issuer Classification Assignment",["GICS"]),
 ("NAIC Securities Valuation Office: designations, designation categories and filing exemption","NAIC","https://content.naic.org/svo.htm","Public guidance (Purposes and Procedures Manual is licensed)","NAIC designations and designation categories; filing-exempt securities","Regulatory Instrument Classification (NAIC Designation Category, NAIC SVO Filing Status)",["NAIC SVO"]),
 ("SEC Rule 2a-7 (money market funds)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.2a-7","Regulation","Eligible security definition; government, prime and tax-exempt fund types","Rule 2a-7 Eligible Security Indicator, MMF Type",["SEC Rule 2a-7"]),
 ("SEC Rule 144 (restricted securities), Rule 144A and Regulation S","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-230/section-230.144A","Regulation","Restricted securities (Rule 144(a)(3)); resales to qualified institutional buyers; offshore offerings","Regulatory Instrument Classification",["SEC Rule 144", "SEC Rule 144A", "Regulation S"]),
 ("ICMA Green Bond, Social Bond, Sustainability Bond and Sustainability-Linked Bond Principles","International Capital Market Association","https://www.icmagroup.org","Voluntary guidelines","Use-of-proceeds and sustainability-linked bond labels","Sustainable Bond Label",["ICMA"]),
 ("SEC Office of Credit Ratings (NRSROs) (confirm page)","US SEC","https://www.sec.gov","Regulation / public register","Registered rating organizations, rating classes, rating actions, outlooks and watches as defined by the agencies","Credit Rating Assignment, Credit Rating Agency",["SEC NRSRO"]),
 ("openfunds field definitions","openfunds association","https://openfunds.org","Open standard","Fund vehicle, regime, domicile, dealing frequency and distribution fields for held funds (field structure only; values are the US lists of 01)","Fund Instrument Terms",["openfunds"]),
 ("ILPA reporting template and principles","Institutional Limited Partners Association","https://ilpa.org","Open template","LP fund interest terms: GP, vintage, strategy, commitment currency, fund term","Fund Instrument Terms, Fund Interest Terms",["ILPA"]),
 ("Vendor security master models as structural cross-checks (Bloomberg, ICE Data Services, LSEG, S&P Global Market Intelligence; BlackRock Aladdin and SimCorp security reference)","Vendors","https://www.bloomberg.com/professional","Licensed","Structure only: how security masters split identifiers, terms by asset class, issuers and corporate actions; no field dictionaries copied","Overall structure, Issuer Profile vendor identifiers",["Bloomberg", "Exchange"]),
]
