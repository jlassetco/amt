"""Data Domain 18 - Portfolio & Investment Book of Record. Content module for taxonomy_builder.py."""

META = {
 "title": "Portfolio & Investment Book of Record Data Taxonomy",
 "subtitle": "Business domain 18 - Portfolio & Investment Book of Record | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "18_Portfolio_and_Investment_Book_of_Record/Portfolio_and_Investment_Book_of_Record_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the investment book of record (IBOR) of a US wealth manager that runs its own mutual funds, ETFs and collective investment trusts and manages institutional separate accounts and mandates in house (business lines PF and IA, CW-004). It defines the portfolio the firm manages (the managed book, as distinct from the product or service the client buys), how each portfolio implements a product, an institutional mandate, an institutional separate account or a model, how portfolios roll up into sleeves and aggregates, and what each portfolio holds at start of day, intraday and end of day: portfolio holdings by instrument with their IBOR valuation, derivative and private fund interest detail, tax lots and lot relief, cash balances and projected cash, the subscription and redemption cash expected into the portfolio, and every portfolio transaction as booked with its cost components and booking lifecycle. It closes with the controls on the book: position snapshots, manual position adjustments and the IBOR valuation summary. It is one of three books of record (CW-007): portfolio holdings of the firm's funds and institutional portfolios are mastered here; client holdings in brokerage and advisory accounts, including retail managed accounts, are mastered in 49 Clearing, Settlement & Client Asset Custody; fund shareholder positions in the firm's funds are 06. It is produced by investment operations from the order management and IBOR platform, which is why it sits apart from 01 Investment Product & Service Offering, 06 Client Assets, Flows & Channel Attribution and 49. The firm is regulated and distributes in the US only; its funds hold a global universe, so foreign instruments, currencies and transaction taxes stay. Built from ISO 20022 securities management (semt) statements, the FIX Protocol position maintenance and allocation messages, BIAN, FIBO, IRS Publication 550, IRC Sections 1012, 1091 and 1222, Treas. Reg. 1.1012-1 and Form 8949, GIPS 2020, the ILPA Reporting Template, SEC Form N-PORT and Rule 6c-11, SEC Form ADV, Exchange Act Section 28(e) and public descriptions of common IBOR platforms. Use it as a starting point for an IBOR data model, an investment operations glossary or the portfolio and holdings layer that portfolio trading, performance, risk and compliance key on."),
  ("Scope", "In scope: portfolio master (structural type, business line, status, base currency, owning entity for CIT and proprietary books, managing entity, book of record system and IBOR operating model), portfolio identifiers across OMS, IBOR, accounting, custodian, administrator and GIPS schemes, portfolio implementation links to products, institutional mandates, institutional separate accounts and models, portfolio hierarchy links (sleeves, carve-outs, aggregation), the IBOR accounting basis of each portfolio, portfolio lifecycle events, business-line detail for pooled fund, institutional separate account and private fund portfolios, portfolio holdings by holding view (start of day, intraday, end of day), holding valuation as carried in the IBOR, derivative and fund interest holding detail, tax lots and lot relief (including wash-sale adjustments), cash balances, projected cash movements, portfolio capital activity, portfolio transactions with their costs and charges and their booking events, position snapshots, position adjustments and the IBOR valuation summary. Not in scope (CW-007, CW-009): client holdings, client tax lots and cost basis, and cash and sweep balances of brokerage and advisory accounts (49); retail managed accounts are 15 accounts managed in 46 Managed Portfolios & Rebalancing that hold Client Holdings in 49, never portfolios here; fund shareholder positions (06). Out of scope (referenced by ID): products, share classes, mandates, model portfolios, fund structure and dealing terms, product service providers and portfolio manager assignment (01 Investment Product & Service Offering); parties such as brokers, counterparties, custodians and providers (02 Client & Household, party core); sponsor and consultant program agreements under which an institutional separate account is run (05 Intermediary & Institutional Distribution); Fund Shareholder Positions in the firm's funds, flows and client asset measures (06 Client Assets, Flows & Channel Attribution; register transactions are 29's, CW-122); legal entities, calendars, currencies and FX rate types (09 Shared & Enterprise Reference Data); custody accounts, standing settlement instructions, transition events and client cash flow notifications (12 Institutional Client Servicing & Reporting); institutional separate accounts and mandate accounts (15 Account); instruments, fund interest terms and corporate action events (17 Instrument & Issuer Reference); employees (20 Human Capital). Other domains own prices and FX rates (22), targets and portfolio construction (24), portfolio orders, executions and allocations (25 Portfolio Trading & Execution; client orders are 48), fund-side settlement status and collateral (26), the accounting book, accruals and NAV (27), fund custody and custodian reconciliation (28), investor subscriptions to and client holdings of the firm's feeder funds (15 Alternative Investment Subscription, 49), seed capital commitments (43 Seed Capital Commitment, SDCAP-) and the systems of record (41 Application, APPL-)."),
  ("Structure", "Four levels: Data Domain > Data Family > Data Business Object > Data Business Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Portfolio (PORT-) is the master record of a managed book. It carries Portfolio Identifiers (OMS, IBOR, accounting, custodian, administrator and GIPS schemes), is joined to what it delivers through effective-dated Portfolio Implementation Links (Implements Product, Implements Mandate, Manages Account for an institutional separate account, Follows Model) and to other portfolios through Portfolio Hierarchy Links (sleeve of, carve-out of, aggregation, successor of). Portfolio Accounting Basis and the business-line details (Fund, institutional separate account, Private Fund) are attribute groups of the Portfolio; Portfolio Lifecycle Events record inception, funding, restructuring, transitions and liquidation. A Portfolio Holding (HLD-) is one portfolio x instrument (17 INS-) x holding date x holding view, with Holding Valuation, Derivative Holding Detail and Fund Interest Holding Detail as attribute groups. The holding of an instrument is supported by Tax Lots (LOT-), each opened by a Portfolio Transaction and closed through Lot Relief; a Tax Lot carries its current state and its history is rebuilt from Lot Relief. Cash Balances and Projected Cash Movements carry the cash side; Portfolio Capital Activity is subscription and redemption cash expected into or out of the portfolio. A Portfolio Transaction (PTXN-) is the booked effect on the portfolio, with Transaction Cost & Charge and a trail of Portfolio Transaction Events. Portfolio Position Snapshots, Position Adjustments and the Portfolio Valuation Summary control and summarize the book."),
  ("Design principles", "1) Portfolio is not product: a product, share class, mandate or model (01) is what the firm sells; the Portfolio is the book the firm runs to deliver it, and an effective-dated link joins them (CD-145). Product facts (fund structure, dealing and valuation terms, service providers, mandate type) are read through the link, never repeated on the book. A model portfolio is never a Portfolio, and a feeder fund is a product linked to its master's portfolio. 2) Three books of record (CW-007): a Portfolio Holding (HLD-, here) is an instrument held by one of the firm's fund or institutional portfolios; a Client Holding (49) is a security or fund share held in a client's brokerage or advisory account, with its tax lots and cost basis; a Fund Shareholder Position (06 Position, POS-) is units of the firm's share classes held by an account on the fund register. 'Position' and 'holding' are never used bare here (CD-146); a fund-of-funds holding is a Portfolio Holding of an own-share-class instrument. Retail managed accounts (digital and human advice) are 15 accounts managed in 46 and hold Client Holdings in 49; they are never 18 portfolios, and the Manages Account link and SMA Portfolio Detail serve only the firm's own institutional separate accounts (IA line) and the sponsor program accounts it manages inside a third-party sponsor's wrap or model program (intermediary channel, IC line; CW-009). 3) IBOR, not ABOR: holdings are trade-date, intraday-capable and investment-facing; the official book, accruals and NAV are 27 and reconciliation to custodians is 28. 4) A Portfolio Transaction is the booked effect on the portfolio, not the order, allocation or settlement. 5) Values copied from other domains (prices, FX rates, allocation IDs, settlement confirmation, collateral, product transparency terms) are flagged Derived copy until their owners (01, 22, 25, 26) supply them by reference. 6) One model whether the book is kept in house or by an outsourced middle office (CD-147). 7) Record each fact once: sleeve as a hierarchy link, mandate and sub-advisory through the implemented mandate, seed capital as one indicator, shadow books as an operating model value. 8) Amounts are unsigned where a direction or type is recorded, and signed where none is. 9) Flag Critical Data Elements (CDE)."),
  ("Applies To", "Shows the record each attribute belongs to: Portfolio, Portfolio Identifier, Implementation Link, Hierarchy Link, Lifecycle Event, Holding, Tax Lot, Lot Relief, Cash Balance, Projected Cash, Capital Activity, Portfolio Transaction, Transaction Event, Snapshot, Adjustment or Valuation Summary."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify a portfolio and what it implements, to key every IBOR record to its portfolio and instrument, to state what a portfolio holds (instrument, quantity, holding date and view), to cost and relieve lots correctly for tax, to know the cash available to invest, or to book and trace a portfolio transaction. Confirm with investment operations, the portfolio management teams, fund tax and investment compliance."),
  ("Primary / Secondary Reference", "Standard, rule or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Vendor references (Aladdin, Charles River IMS, SimCorp Dimension, eFront / Investran) indicate common industry structure, not a license to reproduce vendor record layouts. Next step: map each attribute to the IBOR platform's portfolio, position, lot and transaction tables."),
  ("Notes", "PII = personal data under US privacy law (Regulation S-P, GLBA and state privacy laws). Employee references on lifecycle events, booking events and adjustments are personal data of internal staff. Where an institutional separate account belongs to a natural person (for example a personal trust or family office account served by the IA line), the portfolio name and sponsor or custodian account identifiers identify the client, and the book's holdings, lots, cash and transactions are nonpublic personal information (Regulation S-P, GLBA); restrict access accordingly. Retail clients' holdings are 49, not here. Holdings of funds before public disclosure may be material nonpublic information. Scope is the US wealth manager: the UK share identification rules and the MiFID II cost categories were removed under CW-918 and are listed in the jurisdiction register; foreign instruments, currencies and transaction taxes on foreign trades stay."),
  ("Tabs", "Hierarchy: families, object groups and objects with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: object-level cardinalities, including references to other Data Domains | Sources: standards used, owners, licenses and links."),
  ("Suggested next steps", "1) Validate families, portfolio types, link types, holding views and CDEs with investment operations, the portfolio management teams, fund tax and investment compliance. 2) Confirm which platform is the IBOR and whether it also holds the ABOR, and record the IBOR operating model per business line (CD-147). 3) Agree with 01 the implementation link for every product, mandate and institutional separate account, and with 15 the institutional account to portfolio grain (account or sleeve). 4) Agree with 06 and 49 the glossary terms Portfolio Holding, Client Holding and Fund Shareholder Position (CW-007), and the link between own-fund holdings and fund shareholder positions on the portfolio's account. 5) Agree with 17 the instrument key and the 'Own Fund Share Class' instrument type. 6) Have fund tax review lot relief methods by business line and wash-sale handling. 7) Hand the Derived copy attributes to their owners (01 transparency terms, 22 prices and FX, 25 allocations, 26 settlement and collateral) when those domains are drafted. 8) Turn the Relationships tab into a logical IBOR data model shared with 24 to 33."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))


# ---------------------------------------------------------------------------
D("Portfolio Master", "IB-PRT",
  "The managed book itself: identity, structural type, status and operating model of each portfolio, the identifiers it carries in every system that knows it, what it implements (product, mandate, institutional separate account or model), how portfolios link to one another, the IBOR conventions it is kept on and its lifecycle.",
  [
   ("Portfolio Core", "Identity, type, ownership and operating model of a portfolio. A model portfolio (01 MDL-) is never a Portfolio.", [
     ("Portfolio", [
       ("Portfolio ID", "Unique enterprise identifier of the managed book.", "Portfolio", "Identifier", "", "PORT-000412", "Internal", "FIBO SEC", "Y"),
       ("Portfolio Name", "Name by which investment operations and portfolio managers know the book.", "Portfolio", "Text", "", "Global Equity Income Fund - Main Book", "Internal", "", "", "PII where the book is an institutional separate account of a natural person (personal trust or family office)."),
       ("Portfolio Type", "Structural kind of book: a standalone book, a sleeve of another book, or an aggregate of other books.", "Portfolio", "Code", "Portfolio Type", "Standalone Book", "Internal", "GIPS 2020", "Y", "Business line and mandate type are not repeated here: they come from Business Line and from the implemented 01 object."),
       ("Business Line", "Enterprise business line whose assets the book holds.", "Portfolio", "Code", "Business Line", "PF", "Internal", "", "Y", "CW-004 values (shared list, steward 09; two-letter codes as values, as in 02 and 15). Fund, ETF and CIT books are PF; institutional separate account and institutional mandate books are IA; books of sponsor program accounts in third-party wrap or model programs are IC; a common trust fund book of the optional trust company is TR. Sub-advised mandates take the line of the vehicle or service they are sold under; seed books are flagged by Proprietary Capital Indicator."),
       ("Portfolio Status", "Current lifecycle status of the book.", "Portfolio", "Code", "Portfolio Status", "Active", "Internal", "", "", "Status history is held as Portfolio Lifecycle Events."),
       ("Base Currency", "Currency in which the book is valued and in which base amounts are expressed.", "Portfolio", "Code", "ISO 4217", "USD", "ISO 4217", "ISO 20022", "Y", "Book base currency; normally equals 01 Product Base Currency for a fund book."),
       ("Legal Owner Entity", "Internal legal entity that owns the book's assets, recorded only for CIT books (the trustee bank entity) and proprietary books (the firm entity holding seed or own capital).", "Portfolio", "Reference (Legal Entity)", "", "LEN-0031", "Internal", "FIBO SEC", "", "Blank for other books: a fund's legal owner is the 01 product reached through the Implements Product link; an institutional separate account's or mandate's owner is the account holder (15 ACC-, 02 PTY-) reached through the Manages Account or Implements Mandate link."),
       ("Managing Entity", "Internal adviser entity that manages the book under its investment management agreement, or that oversees an external sub-adviser running the book under a sub-advisory agreement.", "Portfolio", "Reference (Legal Entity)", "", "LEN-0004", "Internal", "SEC Form ADV", "", "External sub-advisers are parties (02); their oversight is 52 External Manager & Sub-Adviser Oversight."),
       ("Proprietary Capital Indicator", "Whether the book holds the firm's seed or other proprietary capital.", "Portfolio", "Boolean", "", "N", "Internal", "", "", "Derived copy (43) since the Stage 4 consolidation (CD-276). Row rule: 'Y' while the portfolio is the Seed Book of a 43 Seed Capital Commitment whose Seed Commitment Status is Approved, Funded or Partially Redeemed; 'N' otherwise. The only place 18 records seed status."),
       ("Inception Date", "Date the book first held assets.", "Portfolio", "Date", "ISO 8601", "2014-03-03", "GIPS 2020", "", "", "Book inception; may differ from 01 Product Inception Date (e.g. a book reused after a merger)."),
       ("Termination Date", "Date the book was closed after liquidation, merger or transfer of all assets.", "Portfolio", "Date", "ISO 8601", "", "GIPS 2020", "", ""),
       ("Book of Record System", "Application (41 application inventory) that holds the authoritative IBOR record of the book.", "Portfolio", "Reference (Application, 41)", "", "APPL-00387", "Internal", "", "", "CD-147, CD-263. Re-typed to the 41 Application at the Stage 4 consolidation; an outsourced provider platform is an Application of hosting model 'Provider-Hosted'."),
       ("IBOR Operating Model", "Whether the book is kept in house, by an outsourced middle office, or as a shadow of a record kept by the client's custodian.", "Portfolio", "Code", "IBOR Operating Model", "In House", "Internal", "", "", "CD-147."),
       ("Middle Office Provider", "Provider that keeps the book where the IBOR operating model is outsourced.", "Portfolio", "Reference (Party)", "", "PTY-100877", "Internal", "", ""),
       ("Safekeeping Custody Account", "Main safekeeping account at the custodian in which the book's securities are held (mastered in 28); for a segregated mandate book it is the account created through the 12 custody account set-up.", "Portfolio", "Reference (Safekeeping Account, 28)", "", "SKA-000231", "Internal", "", "", "CD-194 option A: re-typed from 12 Custody Account (CUA-) and widened to every book, fund books included. All accounts of a book, by purpose, are 28 Safekeeping Account Assignments (Owning Portfolio); settlement instructions are 26 (CD-155)."),
     ]),
   ]),
   ("Portfolio Identifiers", "Every code by which the book is known in another system, with its scheme, so the enterprise PORT- key is never overloaded.", [
     ("Portfolio Identifier", [
       ("Identified Portfolio", "Portfolio the identifier belongs to.", "Portfolio Identifier", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "Y"),
       ("Portfolio Identifier Scheme", "System or scheme that issued the identifier.", "Portfolio Identifier", "Code", "Portfolio Identifier Scheme", "OMS Portfolio Code", "Internal", "ISO 20022", ""),
       ("Portfolio Identifier Value", "The identifier as issued by the scheme.", "Portfolio Identifier", "Identifier", "", "GEIF-MAIN", "Internal", "", "Y", "PII where the book is an institutional separate account of a natural person and the scheme is a sponsor or custodian account number."),
       ("Identifier Issuer", "Custodian, administrator or other provider that issued the identifier, where external.", "Portfolio Identifier", "Reference (Party)", "", "PTY-100912", "Internal", "", ""),
       ("Portfolio Identifier Status", "Whether the identifier is in use.", "Portfolio Identifier", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
       ("Identifier Effective From", "Date the identifier became valid for the book.", "Portfolio Identifier", "Date", "ISO 8601", "2014-03-03", "Internal", "", ""),
       ("Identifier Effective To", "Date the identifier ceased to be valid for the book.", "Portfolio Identifier", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Portfolio Implementation", "What the book is run to deliver: a product, an institutional mandate, an institutional separate account or a model it tracks (CD-145). Retail managed accounts are never implemented by a portfolio here (CW-007, CW-009).", [
     ("Portfolio Implementation Link", [
       ("Implementing Portfolio", "Portfolio that implements the linked product, mandate, account or model.", "Implementation Link", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "Y"),
       ("Implementation Link Type", "Nature of the link; determines which one of the implemented-object references is filled.", "Implementation Link", "Code", "Implementation Link Type", "Implements Product", "Internal", "", "Y"),
       ("Implemented Product", "Mutual fund, ETF, CIT or other pooled vehicle the book delivers.", "Implementation Link", "Reference (Investment Product)", "", "PRD-00231", "Internal", "", "Y"),
       ("Implemented Mandate", "Segregated or sub-advised mandate the book delivers.", "Implementation Link", "Reference (Mandate)", "", "MND-01234", "Internal", "", "Y"),
       ("Managed Account", "Institutional separate account (15 Account of an institutional client, IA line) or sponsor program account (intermediary channel) the book manages; never a retail managed account of the firm, which holds Client Holdings in 49.", "Implementation Link", "Reference (Account)", "", "ACC-0091877", "Internal", "", "Y"),
       ("Followed Model Portfolio", "Model portfolio the book tracks.", "Implementation Link", "Reference (Model Portfolio)", "", "MDL-0045", "Internal", "", "", "Set only where the managed account has no 46 Model Assignment (MASGN-) under its 15 Program Enrollment (ENRL-); where it has one, they must agree (W1, CW-915, CW-045)."),
       ("Primary Implementation Indicator", "Whether this book holds the main assets of the implemented object where several books implement it.", "Implementation Link", "Boolean", "", "Y", "Internal", "", ""),
       ("Implementation Effective From", "Date the book began implementing the linked object.", "Implementation Link", "Date", "ISO 8601", "2014-03-03", "Internal", "", ""),
       ("Implementation Effective To", "Date the book stopped implementing the linked object.", "Implementation Link", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Portfolio Hierarchy", "Links between books: sleeve of a parent, carve-out, aggregation and succession. Own-fund (fund of funds) investments are Portfolio Holdings, not hierarchy links.", [
     ("Portfolio Hierarchy Link", [
       ("Parent Portfolio", "Portfolio at the higher level of the link.", "Hierarchy Link", "Reference (Portfolio, 18)", "", "PORT-000400", "Internal", "GIPS 2020", "Y"),
       ("Child Portfolio", "Portfolio at the lower level of the link.", "Hierarchy Link", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "Y"),
       ("Portfolio Hierarchy Link Type", "Nature of the link between the two books.", "Hierarchy Link", "Code", "Portfolio Hierarchy Link Type", "Sleeve Of", "Internal", "GIPS 2020", "Y"),
       ("Look-Through Roll-Up Indicator", "Whether holdings views of the parent include the child's holdings in place of a single line for the child.", "Hierarchy Link", "Boolean", "", "Y", "Internal", "", ""),
       ("Hierarchy Effective From", "Date the link took effect.", "Hierarchy Link", "Date", "ISO 8601", "2022-07-01", "Internal", "", ""),
       ("Hierarchy Effective To", "Date the link ended.", "Hierarchy Link", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Accounting Basis", "IBOR conventions applied to the book: lot relief default, income accrual, valuation calendar and FX conventions.", [
     ("Portfolio Accounting Basis", [
       ("Default Lot Relief Method", "Method used to choose which lots a sale or redemption relieves unless another method is specified on the trade.", "Portfolio", "Code", "Lot Relief Method", "High Cost", "IRS Publication 550", "Treas. Reg. 1.1012-1", "Y"),
       ("Wash-Sale Tracking Indicator", "Whether the IBOR adjusts lot basis and holding period for wash sales.", "Portfolio", "Boolean", "", "Y", "IRC Section 1091", "", ""),
       ("Daily Income Accrual Indicator", "Whether the IBOR accrues interest and dividend income on holdings every day rather than on payment.", "Portfolio", "Boolean", "", "Y", "Internal", "SimCorp", "", "The official accrual ledger is 27."),
       ("Valuation Calendar", "Calendar of business days on which the book is valued in the IBOR.", "Portfolio", "Reference (Calendar)", "", "CAL-NYSE", "Internal", "", ""),
       ("FX Rate Type Used", "FX rate type used to translate local amounts into the base currency.", "Portfolio", "Reference (FX Rate Type, 09)", "", "WMR London 4pm Close Mid", "Internal", "", ""),
       ("Start-of-Day Cutoff Time", "Time at which the IBOR rolls the book into the next start-of-day view.", "Portfolio", "Time", "HH:MM + time zone", "05:00 America/New_York", "Internal", "Aladdin", ""),
       ("Accounting Basis Effective From", "Date from which the current set of conventions applies.", "Portfolio", "Date", "ISO 8601", "2014-03-03", "Internal", "", "", "Earlier conventions are recoverable from Portfolio Lifecycle Events (Accounting Basis Change)."),
     ]),
   ]),
   ("Portfolio Lifecycle", "Events that create, fund, restructure, change and close a book.", [
     ("Portfolio Lifecycle Event", [
       ("Event Portfolio", "Portfolio the event applies to.", "Lifecycle Event", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "Y"),
       ("Portfolio Lifecycle Event Type", "Type of event in the life of the book.", "Lifecycle Event", "Code", "Portfolio Lifecycle Event Type", "Funding", "Internal", "GIPS 2020", "Y"),
       ("Event Effective Date", "Business date from which the event applies.", "Lifecycle Event", "Date", "ISO 8601", "2014-03-03", "Internal", "", ""),
       ("Resulting Portfolio Status", "Portfolio status set by the event, where the event changes it.", "Lifecycle Event", "Code", "Portfolio Status", "Active", "Internal", "", ""),
       ("Event Approval Status", "Approval state of the event where it needs sign-off (mergers, liquidations).", "Lifecycle Event", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("Counterpart Portfolio", "Other book involved, such as the surviving book in a merger.", "Lifecycle Event", "Reference (Portfolio, 18)", "", "PORT-000398", "Internal", "", ""),
       ("Related Transition Event", "Client transition that funded or emptied the book in kind (owned by 12).", "Lifecycle Event", "Reference (Transition Event)", "", "TRN-2026-0042", "Internal", "", ""),
       ("Event Recorded By", "Employee who recorded the event.", "Lifecycle Event", "Reference (Employee)", "", "EMP-30412", "Internal", "", "", "PII (internal staff)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Business-Line Detail", "IB-BLD",
  "Facts about the book that apply only to one kind of book: pooled funds (mutual funds, ETFs and CITs), institutional separate account portfolios and sleeves, and private fund portfolios. Product and mandate terms (structure, objective, fees, restrictions, dealing and valuation terms, service providers, mandate type) stay in 01; segregated mandate books carry only the custody account on the Portfolio.",
  [
   ("Pooled Fund Detail", "Book-level facts for mutual fund, ETF and CIT portfolios.", [
     ("Fund Portfolio Detail", [
       ("Cash Sweep Vehicle", "Money market instrument into which the book's uninvested cash is swept.", "Portfolio", "Reference (Instrument, 17)", "", "INS-00088120", "Internal", "", ""),
       ("Daily Holdings Publication Indicator", "Whether the book's holdings must be published every business day, which makes the IBOR end-of-day view the source of the published file.", "Portfolio", "Boolean", "", "Y", "SEC Rule 6c-11", "", "", "Derived copy of the 01 product transparency term (fully transparent ETF); publication and filing are 35."),
     ]),
   ]),
   ("SMA Detail", "Book-level facts for an institutional separate account or its sleeve run by the firm (IA line), or for a sponsor program account (intermediary channel) the firm manages in a third-party wrap or model program (IC line). The firm's own retail managed accounts are 15 accounts managed in 46, not 18 books (CW-009).", [
     ("SMA Portfolio Detail", [
       ("Sponsor Program Agreement", "Sponsor program agreement under which a sponsor program account (intermediary channel) book is run, or consultant program agreement of an institutional separate account, where there is one (owned by 05).", "Portfolio", "Reference (Agreement)", "", "AGR-000312", "Internal", "SEC Form ADV", "Y", "15 Program Enrollment (ENRL-) keys the offering by OFFR- (01); see proposals_18 for alignment."),
       ("Full Discretion Indicator", "Whether the firm trades the book with full discretion rather than delivering trades for the sponsor to place.", "Portfolio", "Boolean", "", "Y", "SEC Form ADV", "", ""),
       ("Tax-Aware Management Indicator", "Whether the book is managed to the institutional client's tax position (lot selection, gain budgets); tax-aware management of retail managed accounts is 46.", "Portfolio", "Boolean", "", "Y", "Internal", "IRS Publication 550", ""),
       ("Tax Loss Harvesting Indicator", "Whether losses are realized deliberately to offset gains in an institutional separate account; harvesting in retail managed accounts is 46 (Proposed Trade, Proposed Lot Selection).", "Portfolio", "Boolean", "", "Y", "Internal", "IRC Section 1091", ""),
     ]),
   ]),
   ("Private Fund Detail", "Book-level facts for a feeder fund or another book holding private fund interests (CW-038).", [
     ("Private Fund Portfolio Detail", [
       ("Valuation Lag Days", "Usual number of days after period end before underlying valuations reach the book.", "Portfolio", "Integer", "Days", "75", "ILPA Reporting Template", "", ""),
       ("Fund Interest Holdings Indicator", "Whether the book holds interests in other private funds (fund of funds, secondaries).", "Portfolio", "Boolean", "", "Y", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Holdings", "IB-HLD",
  "What each portfolio holds by instrument at a point in time in the IBOR (start of day, intraday, end of day), with the valuation carried in the book and detail for derivatives and fund interests. A Portfolio Holding is not a Client Holding (49) or a Fund Shareholder Position (06 POS-) (CW-007).",
  [
   ("Portfolio Holding", "Quantity of an instrument held by a portfolio at a holding date in a holding view.", [
     ("Portfolio Holding", [
       ("Holding ID", "Unique identifier of the holding record.", "Holding", "Identifier", "", "HLD-2026100500041201", "Internal", "ISO 20022", "Y"),
       ("Holding Portfolio", "Portfolio that holds the instrument.", "Holding", "Reference (Portfolio, 18)", "", "PORT-000412", "ISO 20022", "", "Y"),
       ("Held Instrument", "Instrument held.", "Holding", "Reference (Instrument, 17)", "", "INS-00104477", "ISO 20022", "FIBO SEC", "Y"),
       ("Holding Date", "Business date the holding applies to.", "Holding", "Date", "ISO 8601", "2026-10-05", "ISO 20022", "", "Y"),
       ("Holding View", "Which view of the book the holding belongs to.", "Holding", "Code", "Holding View", "End of Day", "Internal", "Aladdin", "Y"),
       ("Holding As-Of Timestamp", "Moment the holding was computed, for intraday views.", "Holding", "Timestamp", "ISO 8601", "2026-10-05T16:30:00-04:00", "Internal", "", ""),
       ("Holding Quantity", "Trade-date quantity held, unsigned; the Long / Short Indicator gives the direction.", "Holding", "Decimal", "", "125000", "ISO 20022", "FIX Protocol", "Y"),
       ("Quantity Unit", "Unit in which the quantity is expressed.", "Holding", "Code", "Quantity Unit", "Shares / Units", "ISO 20022", "", ""),
       ("Long / Short Indicator", "Whether the holding is long or short.", "Holding", "Code", "Long / Short Indicator", "Long", "ISO 20022", "SEC Form N-PORT", ""),
       ("Settled Quantity", "Part of the quantity for which settlement has occurred, as carried in the IBOR.", "Holding", "Decimal", "", "120000", "ISO 20022", "", "", "Computed in 18 from 26 Settlement Status Event (CD-181 rule d)."),
       ("Unsettled Quantity", "Part of the quantity from trades booked but not yet settled, as carried in the IBOR.", "Holding", "Decimal", "", "5000", "ISO 20022", "", "", "Computed in 18 from 26 Settlement Status Event (CD-181 rule d)."),
       ("Encumbered Quantity", "Part of the quantity pledged as collateral or otherwise not freely available.", "Holding", "Decimal", "", "0", "ISO 20022", "", "", "Derived copy (CD-181 rule c, row rule): sum of 26 Collateral Balance.Balance Quantity over rows with Balance Direction 'Posted' for the holding's portfolio, instrument and date, across all agreements and margin types (Variation, Initial, Cleared Initial and Cleared Variation Margin, and Repo Collateral); plus the on-loan quantity of 28 Securities Loan (Loan Quantity) for securities lending (CD-198)."),
       ("Corresponding Shareholder Position", "Fund shareholder position on the portfolio's account where the instrument is a share class of an own fund (owned by 06).", "Holding", "Reference (Fund Shareholder Position, 06)", "", "POS-20260930-0081123-004512", "Internal", "", "", "CD-146, CW-007, CW-151: the same units are a Portfolio Holding here and a Fund Shareholder Position in 06. 06 positions are kept at period end, so a daily holding points to the latest 06 position on or before its holding date."),
     ]),
   ]),
   ("Holding Valuation", "Valuation of a holding as carried in the IBOR. Not the official NAV valuation (27).", [
     ("Holding Valuation", [
       ("Price Used", "Unit price applied to value the holding.", "Holding", "Decimal", "", "45.23", "Internal", "SEC Form N-PORT", "", "Derived copy of 22 Approved Price.Approved Price Value (CD-167); for own fund share classes 22 copies the 27 NAV per Share."),
       ("Price Date", "Business date of the approved price applied.", "Holding", "Date", "ISO 8601", "2026-10-05", "Internal", "", "", "Derived copy of 22 Approved Price.Price Date (CD-167); the market data date of a carried-forward price is 22 Underlying Market Date."),
       ("Price Source", "How the approved price applied was reached (selected observation, override, fair value determination, own fund NAV, carried forward and so on).", "Holding", "Code", "Shared: Approved Price Basis", "Selected Observation", "Internal", "", "", "Derived copy of 22 Approved Price.Approved Price Basis (CD-167); the 22 list replaces the former placeholder."),
       ("Market Value Local", "Value of the holding in the instrument's local currency.", "Holding", "Amount", "", "EUR 5,653,750.00", "ISO 20022", "", ""),
       ("Holding FX Rate", "FX rate used to translate the local value into the base currency.", "Holding", "Decimal", "", "1.0942", "Internal", "", "", "Derived copy of 22 FX Rate Observation.Spot Rate, its inverse or a cross computed from two observations of the same rate type and timestamp (CD-168)."),
       ("Market Value Base", "Value of the holding in the portfolio's base currency.", "Holding", "Amount", "", "USD 6,186,333.25", "ISO 20022", "SEC Form N-PORT", "Y"),
       ("Accrued Income Base", "Interest or dividend income earned but not yet received, in base currency, as carried in the IBOR.", "Holding", "Amount", "", "USD 18,220.10", "ISO 20022", "", ""),
       ("Holding Cost Base", "Total adjusted cost of the open lots of the instrument in the portfolio, in base currency.", "Holding", "Amount", "", "USD 4,912,300.00", "IRS Publication 550", "", ""),
       ("Holding Weight", "Market value of the holding as a share of the book's total IBOR market value.", "Holding", "Percentage", "", "2.46%", "Internal", "", "", "Actual weight; target weights are 24."),
     ]),
   ]),
   ("Derivative Detail", "Exposure detail carried on holdings of futures, options, swaps and forwards. Contract terms are 17.", [
     ("Derivative Holding Detail", [
       ("Number of Contracts", "Number of contracts held.", "Holding", "Decimal", "", "250", "FIX Protocol", "SEC Form N-PORT", ""),
       ("Notional Amount Base", "Notional value of the holding in base currency.", "Holding", "Amount", "", "USD 31,250,000", "SEC Form N-PORT", "", "Y"),
       ("Delta Used", "Option delta applied to compute delta-adjusted exposure.", "Holding", "Decimal", "", "0.42", "SEC Form N-PORT", "", "", "Derived copy of 22 Pricing Analytics Observation.Analytic Measure Value of the approved row (Approved Analytics Value Indicator = Y) with Pricing Analytic Measure 'Option Delta' (CD-167); risk measures are 31."),
       ("Delta-Adjusted Exposure Base", "Economic exposure of the holding in base currency after applying delta.", "Holding", "Amount", "", "USD 13,125,000", "SEC Form N-PORT", "", ""),
       ("Initial Margin Posted", "Initial margin posted against the holding, as carried in the IBOR.", "Holding", "Amount", "", "USD 1,480,000", "Internal", "", "", "Derived by allocation (CD-181 rule b): for each 26 Trading Agreement and date, the posted Collateral Value of 26 Collateral Balance rows with Balance Margin Type Initial Margin or Cleared Initial Margin for the portfolio, allocated to its derivative holdings under the agreement pro rata to each holding's contribution to the 26 Initial Margin Calculation where available, otherwise pro rata to gross notional. The basis used is recorded with the value."),
       ("OTC Counterparty", "Counterparty to an over-the-counter derivative holding.", "Holding", "Reference (Party)", "", "PTY-100221", "SEC Form N-PORT", "", ""),
       ("Clearing Broker", "Clearing member through which a cleared derivative is held.", "Holding", "Reference (Party)", "", "PTY-100305", "Internal", "", ""),
     ]),
   ]),
   ("Fund Interest Detail", "Commitment and capital detail on holdings of interests in private funds. The general partner and fund terms are 17 instrument terms.", [
     ("Fund Interest Holding Detail", [
       ("Commitment Amount", "Amount the portfolio has committed to the underlying fund.", "Holding", "Amount", "", "USD 25,000,000", "ILPA Reporting Template", "", ""),
       ("Called Capital to Date", "Cumulative capital called by the underlying fund.", "Holding", "Amount", "", "USD 16,250,000", "ILPA Reporting Template", "", ""),
       ("Recallable Distributions", "Distributions received that the underlying fund may call again, adding back to the unfunded commitment.", "Holding", "Amount", "", "USD 500,000", "ILPA Reporting Template", "", ""),
       ("Unfunded Commitment", "Commitment not yet called and still callable, including recallable distributions.", "Holding", "Amount", "", "USD 9,250,000", "ILPA Reporting Template", "", "Y"),
       ("Distributions Received to Date", "Cumulative distributions received from the underlying fund.", "Holding", "Amount", "", "USD 4,100,000", "ILPA Reporting Template", "", ""),
       ("GP Reported NAV", "Net asset value of the interest on the latest statement from the general partner.", "Holding", "Amount", "", "USD 15,920,000", "ILPA Reporting Template", "", ""),
       ("GP Statement Date", "Period-end date of the latest general partner statement.", "Holding", "Date", "ISO 8601", "2026-06-30", "ILPA Reporting Template", "", ""),
       ("Adjusted NAV", "Fair value of the fund interest approved in 22 (the GP reported NAV rolled forward for calls and distributions since the statement date, with any further adjustments).", "Holding", "Amount", "", "USD 16,870,000", "Internal", "", "", "Derived copy of 22 Fair Value Determination.Fair Value Amount of the approved determination for the same portfolio (CD-170). GP Reported NAV stays mastered here."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Tax Lots", "IB-LOT",
  "The acquisition lots behind each holding, their cost and adjusted basis, and how sales and redemptions relieve them. A Tax Lot carries its current state; its history is rebuilt from Lot Relief. Client tax lots and cost basis are 49 (Client Holding), and the client's cost basis method election is 15 Cost Basis Election (CW-007).",
  [
   ("Tax Lot", "One acquisition of an instrument by a portfolio, with its cost and current remaining quantity.", [
     ("Tax Lot", [
       ("Tax Lot ID", "Unique identifier of the lot.", "Tax Lot", "Identifier", "", "LOT-00091234", "Internal", "IRS Publication 550", "Y"),
       ("Lot Portfolio", "Portfolio that holds the lot.", "Tax Lot", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "Y"),
       ("Lot Instrument", "Instrument acquired in the lot.", "Tax Lot", "Reference (Instrument, 17)", "", "INS-00104477", "Internal", "", "Y"),
       ("Opening Transaction", "Portfolio transaction that opened the lot.", "Tax Lot", "Reference (Portfolio Transaction, 18)", "", "PTXN-2026-000918273", "Internal", "", ""),
       ("Lot Open Date", "Trade date on which the lot was acquired.", "Tax Lot", "Date", "ISO 8601", "2025-02-14", "IRS Form 8949", "", "Y"),
       ("Original Quantity", "Quantity acquired in the lot.", "Tax Lot", "Decimal", "", "50000", "IRS Publication 550", "", ""),
       ("Remaining Quantity", "Quantity of the lot not yet relieved, as of the latest relief.", "Tax Lot", "Decimal", "", "35000", "IRS Publication 550", "", "Y"),
       ("Original Cost Local", "Cost of the lot in the instrument's local currency, including capitalized transaction costs.", "Tax Lot", "Amount", "", "EUR 1,762,500.00", "IRS Publication 550", "", ""),
       ("Original Cost Base", "Cost of the lot in the portfolio's base currency at the acquisition FX rate.", "Tax Lot", "Amount", "", "USD 1,836,525.00", "IRS Publication 550", "", ""),
       ("Wash-Sale Basis Adjustment", "Disallowed loss from a wash sale added to the lot's basis.", "Tax Lot", "Amount", "", "USD 12,400.00", "IRC Section 1091", "IRS Form 8949", ""),
       ("Adjusted Cost Basis Base", "Cost of the remaining quantity after wash-sale and other basis adjustments, in base currency.", "Tax Lot", "Amount", "", "USD 1,294,247.50", "IRS Publication 550", "IRS Form 8949", "Y"),
       ("Holding Period Start Date", "Date from which the holding period runs, after any tacking from a wash-sale lot.", "Tax Lot", "Date", "ISO 8601", "2025-02-14", "IRC Section 1222", "IRC Section 1091", ""),
       ("Lot Closed Indicator", "Whether the lot has been fully relieved.", "Tax Lot", "Boolean", "", "N", "Internal", "", ""),
     ]),
   ]),
   ("Lot Relief", "How a closing transaction relieved a lot, with the realized result.", [
     ("Lot Relief", [
       ("Relieved Tax Lot", "Lot relieved by the closing transaction.", "Lot Relief", "Reference (Tax Lot, 18)", "", "LOT-00091234", "Internal", "", "Y"),
       ("Closing Transaction", "Portfolio transaction (sale, redemption, transfer out) that relieved the lot.", "Lot Relief", "Reference (Portfolio Transaction, 18)", "", "PTXN-2026-001002114", "Internal", "", "Y"),
       ("Relief Method Applied", "Lot identification method used for this relief.", "Lot Relief", "Code", "Lot Relief Method", "High Cost", "Treas. Reg. 1.1012-1", "IRS Publication 550", ""),
       ("Relieved Quantity", "Quantity of the lot relieved.", "Lot Relief", "Decimal", "", "15000", "IRS Form 8949", "", ""),
       ("Relieved Cost Base", "Adjusted basis of the relieved quantity, in base currency.", "Lot Relief", "Amount", "", "USD 554,677.50", "IRS Form 8949", "", ""),
       ("Relief Proceeds Base", "Net proceeds allocated to the relieved quantity, in base currency.", "Lot Relief", "Amount", "", "USD 741,771.65", "IRS Form 8949", "", ""),
       ("Realized Gain / Loss Base", "Proceeds less relieved cost, in base currency.", "Lot Relief", "Amount", "", "USD 187,094.15", "IRS Form 8949", "", "Y"),
       ("Holding Period Term", "Whether the realized result is short-term or long-term.", "Lot Relief", "Code", "Holding Period Term", "Long-Term", "IRC Section 1222", "IRS Form 8949", ""),
       ("Wash-Sale Loss Disallowed", "Part of a realized loss disallowed because of a wash sale.", "Lot Relief", "Amount", "", "USD 0.00", "IRC Section 1091", "IRS Form 8949", ""),
       ("Wash-Sale Replacement Lot", "Lot whose basis absorbs the disallowed loss.", "Lot Relief", "Reference (Tax Lot, 18)", "", "", "IRC Section 1091", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Cash", "IB-CSH",
  "Cash the portfolio holds and expects: balances by currency, account and basis, projected movements from pending trades, income and capital activity, and the subscription and redemption cash expected into or out of the portfolio. Flow measures are 06; the cash ledger of the official book is 27.",
  [
   ("Cash Balance", "Cash held by a portfolio in one currency, account and balance type on a date.", [
     ("Cash Balance", [
       ("Cash Balance Portfolio", "Portfolio that holds the cash.", "Cash Balance", "Reference (Portfolio, 18)", "", "PORT-000412", "ISO 20022", "", "Y"),
       ("Balance Currency", "Currency of the balance.", "Cash Balance", "Code", "ISO 4217", "EUR", "ISO 4217", "", "Y"),
       ("Cash Safekeeping Account", "Cash account at the custodian, bank or clearing broker where the balance sits (mastered in 28).", "Cash Balance", "Reference (Safekeeping Account, 28)", "", "SKA-000232", "ISO 20022", "", "", "CD-194 option A: replaces 'Cash Account Number'; the account number is mastered on the 28 Safekeeping Account."),
       ("Cash Account Purpose", "What the cash account is used for.", "Cash Balance", "Code", "Cash Account Purpose", "Operating", "ISO 20022", "", ""),
       ("Cash Custodian", "Custodian, bank or clearing broker holding the cash account.", "Cash Balance", "Reference (Party)", "", "PTY-100912", "Internal", "", "", "Equals the Account Provider of the Cash Safekeeping Account (28); held for selection, never maintained apart from 28 (CD-194)."),
       ("Balance Date", "Business date of the balance.", "Cash Balance", "Date", "ISO 8601", "2026-10-05", "ISO 20022", "", "Y"),
       ("Cash Balance Type", "Timing basis of the balance.", "Cash Balance", "Code", "Cash Balance Type", "Settled", "ISO 20022", "Aladdin", "Y"),
       ("Balance Amount Local", "Balance in the balance currency; signed, negative for an overdraft.", "Cash Balance", "Amount", "", "EUR 2,310,442.18", "ISO 20022", "", "Y"),
       ("Cash FX Rate", "FX rate used to translate the balance into the base currency.", "Cash Balance", "Decimal", "", "1.0942", "Internal", "", "", "Derived copy of 22 FX Rate Observation.Spot Rate, its inverse or a cross (CD-168)."),
       ("Balance Amount Base", "Balance in the portfolio's base currency.", "Cash Balance", "Amount", "", "USD 2,528,085.83", "ISO 20022", "", ""),
     ]),
   ]),
   ("Projected Cash", "Cash movements expected on future value dates.", [
     ("Projected Cash Movement", [
       ("Projection Portfolio", "Portfolio the movement is expected in.", "Projected Cash", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "Y"),
       ("Projected Currency", "Currency of the movement.", "Projected Cash", "Code", "ISO 4217", "EUR", "ISO 4217", "", ""),
       ("Projected Value Date", "Date the movement is expected to settle.", "Projected Cash", "Date", "ISO 8601", "2026-10-07", "ISO 20022", "", "Y"),
       ("Projected Cash Source", "What gives rise to the movement.", "Projected Cash", "Code", "Projected Cash Source", "Pending Trade Settlement", "Internal", "SimCorp", ""),
       ("Projected Amount", "Expected amount in the movement currency, unsigned; Projected Flow Direction gives the direction.", "Projected Cash", "Amount", "", "EUR 678,160.22", "ISO 20022", "", "Y"),
       ("Projected Flow Direction", "Whether the movement is into or out of the portfolio.", "Projected Cash", "Code", "Shared: Flow Direction", "Inflow", "Internal", "", "", "Only Inflow and Outflow are used; Neutral does not apply."),
       ("Projection Data Basis", "Whether the amount is estimated or confirmed.", "Projected Cash", "Code", "Shared: Data Basis", "Reported / Actual", "Internal", "", ""),
       ("Source Portfolio Transaction", "Booked transaction whose settlement gives rise to the movement.", "Projected Cash", "Reference (Portfolio Transaction, 18)", "", "PTXN-2026-001002114", "Internal", "", ""),
       ("Source Corporate Action Event", "Corporate action whose payment gives rise to the movement (owned by 17).", "Projected Cash", "Reference (Corporate Action Event, 17)", "", "CAE-2026-0004410", "Internal", "", ""),
     ]),
   ]),
   ("Capital Activity", "Subscription and redemption cash expected into or out of the portfolio from the products, mandates or accounts it implements. Not a flow measure (06).", [
     ("Portfolio Capital Activity", [
       ("Activity Portfolio", "Portfolio the cash is expected into or out of.", "Capital Activity", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "Y"),
       ("Activity Share Class", "Share class (or private fund investor class) whose dealing gives rise to the activity; blank for mandate and institutional separate account books.", "Capital Activity", "Reference (Share Class)", "", "SHC-004512", "Internal", "", ""),
       ("Activity Account", "Institutional client account whose contribution or withdrawal gives rise to the activity, for mandate and institutional separate account books; blank for pooled funds.", "Capital Activity", "Reference (Account)", "", "", "Internal", "", ""),
       ("Capital Activity Type", "Kind of capital activity; also gives its direction.", "Capital Activity", "Code", "Capital Activity Type", "Subscription", "Internal", "ILPA Reporting Template", "Y"),
       ("Activity Trade Date", "Dealing date of the subscriptions or redemptions.", "Capital Activity", "Date", "ISO 8601", "2026-10-05", "Internal", "", "Y"),
       ("Activity Settlement Date", "Date the cash is expected to reach or leave the portfolio.", "Capital Activity", "Date", "ISO 8601", "2026-10-06", "Internal", "", ""),
       ("Activity Amount Base", "Amount of the activity in the portfolio's base currency, unsigned and gross for its type (subscriptions and redemptions of a day are separate records).", "Capital Activity", "Amount", "", "USD 3,420,000.00", "Internal", "", "Y"),
       ("Activity Data Basis", "Whether the amount is an estimate or the final dealing figure.", "Capital Activity", "Code", "Shared: Data Basis", "Estimated", "Internal", "", ""),
       ("Capital Activity Source", "Process or party that supplied the activity.", "Capital Activity", "Code", "Capital Activity Source", "Transfer Agent Estimate", "Internal", "", ""),
       ("Source Cash Flow Notification", "Client cash flow notification behind the activity, for mandate portfolios (owned by 12).", "Capital Activity", "Reference (Cash Flow Notification)", "", "CFN-2026-00788", "Internal", "", ""),
       ("In-Kind Activity Indicator", "Whether the activity is settled in securities rather than cash (ETF creation or redemption, in-kind subscription).", "Capital Activity", "Boolean", "", "N", "SEC Rule 6c-11", "", "", "The securities arrive as portfolio transactions of type In-Kind Transfer In / Out that reference this activity."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Portfolio Activity", "IB-ACT",
  "Every transaction as booked in the IBOR and its effect on the portfolio: trades, income, corporate actions, fees, transfers and in-kind movements, with their cost components and booking lifecycle. Portfolio orders and allocations are 25, fund-side settlement is 26 and shareholder transactions are 06 TXN-; client trades are 48 and 49.",
  [
   ("Portfolio Transaction", "One transaction as booked against a portfolio.", [
     ("Portfolio Transaction", [
       ("Portfolio Transaction ID", "Unique identifier of the booked transaction.", "Portfolio Transaction", "Identifier", "", "PTXN-2026-001002114", "Internal", "ISO 20022", "Y"),
       ("Transaction Portfolio", "Portfolio the transaction is booked against.", "Portfolio Transaction", "Reference (Portfolio, 18)", "", "PORT-000412", "ISO 20022", "FIX Protocol", "Y"),
       ("Portfolio Transaction Type", "Kind of transaction and its effect on holdings and cash.", "Portfolio Transaction", "Code", "Portfolio Transaction Type", "Sell", "ISO 20022", "FIX Protocol", "Y"),
       ("Transaction Instrument", "Instrument the transaction affects; blank for pure cash transactions.", "Portfolio Transaction", "Reference (Instrument, 17)", "", "INS-00104477", "ISO 20022", "", "Y"),
       ("Trade Date", "Date the transaction takes effect in the IBOR.", "Portfolio Transaction", "Date", "ISO 8601", "2026-10-05", "ISO 20022", "FIX Protocol", "Y"),
       ("Contractual Settlement Date", "Date on which the transaction is due to settle.", "Portfolio Transaction", "Date", "ISO 8601", "2026-10-07", "ISO 20022", "FIX Protocol", "Y"),
       ("Transaction Quantity", "Quantity of the instrument moved; signed, positive in and negative out.", "Portfolio Transaction", "Decimal", "", "-15000", "ISO 20022", "FIX Protocol", "Y"),
       ("Transaction Price", "Unit price at which the transaction was booked.", "Portfolio Transaction", "Decimal", "", "45.23", "FIX Protocol", "", ""),
       ("Transaction Currency", "Currency of the transaction amounts.", "Portfolio Transaction", "Code", "ISO 4217", "EUR", "ISO 4217", "", ""),
       ("Principal Amount", "Quantity times price, before accrued interest and costs.", "Portfolio Transaction", "Amount", "", "EUR 678,450.00", "ISO 20022", "FIX Protocol", ""),
       ("Accrued Interest Amount", "Interest bought or sold with a fixed income instrument.", "Portfolio Transaction", "Amount", "", "EUR 0.00", "ISO 20022", "FIX Protocol", ""),
       ("Net Settlement Amount", "Cash due to or from the portfolio after accrued interest and costs.", "Portfolio Transaction", "Amount", "", "EUR 678,160.22", "ISO 20022", "FIX Protocol", ""),
       ("Trade FX Rate", "FX rate booked to translate the net amount into the base currency.", "Portfolio Transaction", "Decimal", "", "1.0938", "Internal", "", "", "Row rule (CD-168): for market-rate rows, Derived copy of 22 FX Rate Observation.Spot Rate (or its inverse or a cross); for rows booked from an executed FX trade, derived from 25 Execution.Executed FX Rate converted to base currency (the executed rate, its inverse, or a cross through base with the 22 observation of one leg; far legs use Far Leg FX Rate). Securities trades whose FX the broker bundles in settlement keep the 22 copy."),
       ("Net Amount Base", "Net settlement amount in the portfolio's base currency.", "Portfolio Transaction", "Amount", "", "USD 741,771.65", "Internal", "", ""),
       ("Executing Broker", "Broker that executed the trade.", "Portfolio Transaction", "Reference (Party)", "", "PTY-100221", "FIX Protocol", "", ""),
       ("Transaction Counterparty", "Counterparty to the transaction where different from the executing broker (OTC, FX, transfers).", "Portfolio Transaction", "Reference (Party)", "", "PTY-100305", "ISO 20022", "", ""),
       ("Source Allocation ID", "Trade allocation from which the transaction was booked.", "Portfolio Transaction", "Reference (Trade Allocation, 25)", "", "ALLOC-2026-0041277", "FIX Protocol", "", "", "CD-180: re-typed from a Derived copy identifier to a reference to 25 Trade Allocation."),
       ("Source Corporate Action Event", "Corporate action that generated the transaction (owned by 17).", "Portfolio Transaction", "Reference (Corporate Action Event, 17)", "", "", "ISO 20022", "", ""),
       ("Related Transition Event", "Client transition under which securities moved in or out in kind (owned by 12).", "Portfolio Transaction", "Reference (Transition Event)", "", "TRN-2026-0042", "Internal", "", ""),
       ("Related Capital Activity", "Capital activity (ETF creation or redemption, in-kind subscription) that an in-kind transfer settles.", "Portfolio Transaction", "Reference (Portfolio Capital Activity, 18)", "", "PORT-000412 / SHC-004512 / 2026-10-05 / ETF Creation", "SEC Rule 6c-11", "", ""),
       ("Settlement Confirmed Indicator", "Whether settlement of the transaction has been confirmed.", "Portfolio Transaction", "Boolean", "", "N", "ISO 20022", "", "", "Derived copy (CD-181 rule a): Y when the latest 26 Settlement Status Event of the Settlement Instruction that settles the transaction has Trade Settlement Status 'Settled'. The only settlement fact held here."),
     ]),
   ]),
   ("Transaction Costs", "Explicit cost components of a booked transaction.", [
     ("Transaction Cost & Charge", [
       ("Commission Amount", "Broker commission charged on the transaction.", "Portfolio Transaction", "Amount", "", "EUR 271.38", "FIX Protocol", "", "", "Row rule (CD-174): Derived copy of 25 Allocation Cost Detail.Commission Amount on rows booked from a trade allocation; mastered here otherwise."),
       ("Research Payment Component", "Part of the commission paid for research and brokerage services under a client commission (soft dollar) or commission sharing arrangement within the Exchange Act Section 28(e) safe harbor.", "Portfolio Transaction", "Amount", "", "EUR 67.85", "Exchange Act Section 28(e)", "SEC Section 28(e) Release 34-54165", "", "Row rule (CD-174): Derived copy of 25 Allocation Cost Detail.Research Payment Component on rows booked from a trade allocation; mastered here otherwise."),
       ("Exchange and Clearing Fee Amount", "Fees charged by exchanges, clearing houses and depositories, including the SEC Section 31 transaction fee passed through on US sales.", "Portfolio Transaction", "Amount", "", "EUR 18.40", "FIX Protocol", "", ""),
       ("Transaction Tax Amount", "Stamp duty, financial transaction tax or other tax on the transaction.", "Portfolio Transaction", "Amount", "", "EUR 0.00", "FIX Protocol", "", ""),
       ("Total Explicit Cost", "Sum of explicit costs in the transaction currency.", "Portfolio Transaction", "Amount", "", "EUR 289.78", "Internal", "FIX Protocol", ""),
       ("Costs Capitalized Indicator", "Whether costs are added to lot cost (purchases) or deducted from proceeds (sales) rather than expensed.", "Portfolio Transaction", "Boolean", "", "Y", "IRS Publication 550", "", ""),
     ]),
   ]),
   ("Transaction Booking Events", "Booking, amendment, cancellation and rebooking of a portfolio transaction.", [
     ("Portfolio Transaction Event", [
       ("Event Transaction", "Portfolio transaction the event applies to.", "Transaction Event", "Reference (Portfolio Transaction, 18)", "", "PTXN-2026-001002114", "Internal", "", "Y"),
       ("Portfolio Transaction Event Type", "Kind of booking event.", "Transaction Event", "Code", "Portfolio Transaction Event Type", "Booked", "Internal", "FIX Protocol", ""),
       ("Event Timestamp", "Moment the event was recorded in the IBOR.", "Transaction Event", "Timestamp", "ISO 8601", "2026-10-05T14:02:31-04:00", "Internal", "", "Y"),
       ("Amendment Reason", "Why the booking was amended, canceled or rebooked.", "Transaction Event", "Text", "", "Price corrected to broker confirmation", "Internal", "", ""),
       ("Rebooked As Transaction", "Transaction that replaces this one after a cancel and rebook.", "Transaction Event", "Reference (Portfolio Transaction, 18)", "", "", "Internal", "", ""),
       ("Event Source System", "Application (41 application inventory) that generated the event.", "Transaction Event", "Reference (Application, 41)", "", "APPL-00398", "Internal", "", "", "Re-typed to the 41 Application at the Stage 4 consolidation (CD-263)."),
       ("Event Performed By", "Employee who performed the event, where manual.", "Transaction Event", "Reference (Employee)", "", "EMP-30412", "Internal", "", "", "PII (internal staff)."),
       ("Back-Dated Indicator", "Whether the event changes a trade date in a period whose snapshot is already locked.", "Transaction Event", "Boolean", "", "N", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Book Control", "IB-CTL",
  "Controls and summaries of the book: snapshots of the holdings at defined points (start of day, end of day, period-end lock), manual position adjustments with approval, and the IBOR valuation summary of each portfolio. Reconciliation to custodians is 28; NAV is 27; AUM is 06.",
  [
   ("Position Snapshot", "A frozen view of a portfolio's holdings and cash at a defined point. Its members are the Portfolio Holdings and Cash Balances of the portfolio whose holding date and holding view match the snapshot's business date and holding view, as they stood at the as-of timestamp.", [
     ("Portfolio Position Snapshot", [
       ("Snapshot Portfolio", "Portfolio the snapshot covers.", "Snapshot", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "Y"),
       ("Snapshot Type", "Kind of snapshot.", "Snapshot", "Code", "Snapshot Type", "Start of Day Official", "Internal", "Aladdin", "Y"),
       ("Snapshot Holding View", "Holding view of the holdings the snapshot freezes.", "Snapshot", "Code", "Holding View", "Start of Day", "Internal", "", ""),
       ("Snapshot Business Date", "Business date the snapshot represents; the date consumers join on.", "Snapshot", "Date", "ISO 8601", "2026-10-06", "Internal", "", "Y"),
       ("Snapshot As-Of Timestamp", "Moment the snapshot was taken.", "Snapshot", "Timestamp", "ISO 8601", "2026-10-06T05:00:00-04:00", "Internal", "", ""),
       ("Snapshot Locked Indicator", "Whether the snapshot and its member holdings are locked against further change.", "Snapshot", "Boolean", "", "Y", "Internal", "", ""),
       ("Snapshot Control Status", "Outcome of the controls run before the snapshot was released.", "Snapshot", "Code", "Shared: Reconciliation Status", "Reconciled within Tolerance", "Internal", "", "", "The reconciliation itself is 28."),
       ("Snapshot Restated Indicator", "Whether the snapshot was restated after a back-dated change.", "Snapshot", "Boolean", "", "N", "Internal", "", ""),
     ]),
   ]),
   ("Position Adjustment", "A manual correction to a holding, with reason and approval.", [
     ("Position Adjustment", [
       ("Adjusted Portfolio", "Portfolio whose holding is adjusted.", "Adjustment", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "Y"),
       ("Adjusted Instrument", "Instrument whose holding is adjusted.", "Adjustment", "Reference (Instrument, 17)", "", "INS-00104477", "Internal", "", "Y"),
       ("Adjusted Holding", "Holding record the adjustment changed; optional, because an adjustment can create a holding that did not exist.", "Adjustment", "Reference (Portfolio Holding, 18)", "", "HLD-2026100500041201", "Internal", "", ""),
       ("Adjustment Date", "Business date the adjustment applies to.", "Adjustment", "Date", "ISO 8601", "2026-10-05", "Internal", "FIX Protocol", "Y"),
       ("Position Adjustment Reason", "Why the holding was adjusted.", "Adjustment", "Code", "Position Adjustment Reason", "Custodian Break Correction", "Internal", "FIX Protocol", "Y"),
       ("Quantity Adjustment", "Change in quantity; signed, positive increases the holding.", "Adjustment", "Decimal", "", "-250", "FIX Protocol", "", "Y"),
       ("Cost Adjustment Base", "Change in cost basis, in base currency.", "Adjustment", "Amount", "", "USD 0.00", "Internal", "", ""),
       ("Adjustment Approval Status", "Approval state of the adjustment.", "Adjustment", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("Adjustment Approved By", "Employee who approved the adjustment.", "Adjustment", "Reference (Employee)", "", "EMP-30588", "Internal", "", "", "PII (internal staff)."),
       ("Adjustment Comment", "Explanation recorded with the adjustment.", "Adjustment", "Text", "", "Corporate action fractional shares not booked by IBOR", "Internal", "", ""),
       ("Adjusting Transaction", "Portfolio transaction booked to carry the adjustment; distinguishes adjustments made on the same day for the same reason.", "Adjustment", "Reference (Portfolio Transaction, 18)", "", "PTXN-2026-001002377", "Internal", "", ""),
     ]),
   ]),
   ("IBOR Valuation Summary", "Total IBOR value of a portfolio on a date and holding view. Not NAV (27) or Client Assets (06); one input to Firm AUM (CW-011).", [
     ("Portfolio Valuation Summary", [
       ("Valued Portfolio", "Portfolio summarized.", "Valuation Summary", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "Y"),
       ("Valuation As-Of Date", "Business date of the summary.", "Valuation Summary", "Date", "ISO 8601", "2026-10-05", "Internal", "", "Y"),
       ("Valuation View", "Holding view the summary is based on.", "Valuation Summary", "Code", "Holding View", "End of Day", "Internal", "", ""),
       ("Valuation Period Type", "Period the summary represents.", "Valuation Summary", "Code", "Shared: Period Type", "Point in Time", "Internal", "", ""),
       ("Total Holdings Market Value", "Market value of all holdings, in base currency.", "Valuation Summary", "Amount", "", "USD 244,310,550.00", "Internal", "", ""),
       ("Total Cash Balance", "Sum of cash balances, in base currency.", "Valuation Summary", "Amount", "", "USD 6,842,110.40", "Internal", "", ""),
       ("Total Accrued Income", "Accrued income carried on holdings, in base currency.", "Valuation Summary", "Amount", "", "USD 412,880.15", "Internal", "", ""),
       ("Total IBOR Market Value", "Holdings, cash and accrued income, in base currency.", "Valuation Summary", "Amount", "", "USD 251,565,540.55", "Internal", "", "Y", "An investment estimate; the official NAV is 27 and AUM measures are 06."),
       ("Summary Data Basis", "Whether the summary rests on final or estimated inputs.", "Valuation Summary", "Code", "Shared: Data Basis", "Reported / Actual", "Internal", "", ""),
       ("Summary Snapshot", "Snapshot the summary was computed from, keyed by portfolio, snapshot type and as-of timestamp.", "Valuation Summary", "Reference (Portfolio Position Snapshot, 18)", "", "PORT-000412 / End of Day / 2026-10-05T18:00:00-04:00", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 "Portfolio Type": ("Internal / GIPS 2020", [("Standalone Book","Book holding instruments in its own right"),("Sleeve","Book run as a sleeve of a parent book (strategy sleeve of a fund or of an institutional separate account); the parent is given by a Sleeve Of hierarchy link"),("Aggregate","Roll-up of child books holding no instruments of its own")]),
 "Business Line": ("CW-004 (shared list, steward 09; two-letter codes as values, as in 02 and 15)", [("DB","Direct brokerage and self-directed investing"),("DA","Digital advice"),("HA","Human and hybrid advice"),("PF","Proprietary funds and ETFs (including CITs)"),("WR","Workplace retirement recordkeeping"),("IA","Institutional advisory"),("IC","Intermediary channel"),("TR","Personal trust services (optional)")]),
 "Portfolio Status": ("Internal", [("Pending Inception","Set up, not yet funded"),("Active",""),("Closed to New Money","Run off; no new subscriptions"),("Liquidating",""),("Terminated","No holdings; book closed"),("Merged","Assets moved to a surviving book")]),
 "IBOR Operating Model": ("Internal (CD-147)", [("In House","The firm keeps the book on its own platform"),("Outsourced Middle Office","A provider keeps the book for the firm"),("Hybrid","Some functions in house, some outsourced"),("Shadow of Client Custodian Record","The firm keeps a shadow of an official book held by the client's custodian")]),
 "Portfolio Identifier Scheme": ("Internal", [("OMS Portfolio Code","Order management system"),("IBOR Portfolio Code",""),("Accounting System Fund Code","ABOR / fund accounting (27)"),("Custodian Account Number",""),("Fund Administrator Code",""),("GIPS Portfolio ID","Performance and composite system (32)"),("Private Markets System Code","eFront, Investran or equivalent"),("Sponsor Account Number","Sponsor's account number of a sponsor program account (intermediary channel)"),("Legacy System Code","")]),
 "Implementation Link Type": ("Internal (CD-145)", [("Implements Product","Mutual fund, ETF, CIT or other pooled vehicle; a feeder fund links to its master's portfolio"),("Implements Mandate","Institutional or sub-advised mandate (01 MND-)"),("Manages Account","Institutional separate account (15 ACC-, IA line) or sponsor program account (intermediary channel); never a retail managed account of the firm (CW-009)"),("Follows Model","Book tracks a model portfolio (01 MDL-)")]),
 "Portfolio Hierarchy Link Type": ("Internal / GIPS 2020", [("Sleeve Of","Child is a sleeve of the parent"),("Carve-Out Of","Child is a carve-out of the parent for performance (GIPS)"),("Aggregation","Parent is a roll-up of children"),("Successor Of","Child replaced the parent after a restructuring")]),
 "Portfolio Lifecycle Event Type": ("Internal / GIPS 2020", [("Set-Up",""),("Inception",""),("Funding","First assets received"),("Transition In","Assets received in kind from a client transition"),("Restructure","Sleeves added or removed"),("Status Change",""),("Accounting Basis Change","Lot relief default, calendar or FX convention changed"),("Change of Book of Record","Moved to another IBOR platform or provider"),("Merger","Merged into another book"),("Transition Out",""),("Liquidation",""),("Termination","")]),
 "Lot Relief Method": ("IRS Publication 550 / Treas. Reg. 1.1012-1", [("FIFO","First in, first out"),("LIFO","Last in, first out"),("High Cost","Highest-cost lots first"),("Low Cost","Lowest-cost lots first"),("Specific Lot Identification","Lots named on the trade"),("Tax-Optimized","Minimizes tax given gain budget and holding periods"),("Average Cost","Average cost of all units")]),
 "Holding View": ("Internal", [("Start of Day","Official opening view"),("Intraday","Real-time view including today's activity"),("End of Day","Closing view after the day's bookings")]),
 "Long / Short Indicator": ("ISO 20022 / SEC Form N-PORT", [("Long",""),("Short",""),("Not Applicable","Cash-like items and commitments")]),
 "Quantity Unit": ("ISO 20022 (quantity choice)", [("Shares / Units",""),("Face Amount","Nominal of debt instruments"),("Contracts","Futures and listed options"),("Notional","Swaps and forwards"),("Commitment","Private fund interests")]),
 "Holding Period Term": ("IRC Section 1222", [("Short-Term","Held one year or less"),("Long-Term","Held more than one year"),("Not Applicable","Tax-exempt book")]),
 "Cash Balance Type": ("ISO 20022 / Internal", [("Settled","Cash settled in the account"),("Trade Date","Settled cash plus booked trades not yet settled"),("Available","Settled cash less amounts blocked or committed")]),
 "Cash Account Purpose": ("Internal", [("Operating","Main cash account of the book"),("Margin","Cash held at a clearing broker"),("Collateral","Cash pledged or received as collateral"),("Income","Income collection account"),("Subscription / Redemption","Account receiving or paying capital activity")]),
 "Projected Cash Source": ("Internal", [("Pending Trade Settlement",""),("Income Receivable","Dividends and coupons"),("Corporate Action Payment",""),("Capital Activity","Expected subscriptions and redemptions"),("Fee Payment","Management and other fees"),("Capital Call","Private fund calls on the book"),("Distribution Received","Private fund distributions to the book"),("FX Settlement","")]),
 "Capital Activity Type": ("Internal / ILPA Reporting Template", [("Subscription","Inflow"),("Redemption","Outflow"),("ETF Creation","Inflow, in cash or in kind"),("ETF Redemption","Outflow, in cash or in kind"),("Client Contribution","Inflow; mandate or institutional separate account"),("Client Withdrawal","Outflow; mandate or institutional separate account"),("Capital Call Proceeds","Inflow; private fund"),("Distribution to Investors","Outflow; private fund"),("Seed Investment","Inflow"),("Seed Redemption","Outflow")]),
 "Capital Activity Source": ("Internal", [("Transfer Agent Estimate",""),("Transfer Agent Final",""),("Authorized Participant Order","ETF orders (29)"),("Client Cash Flow Notification","12 CFN-"),("Sponsor Notification","Sponsor of a sponsor program account (intermediary channel), or consultant of an institutional separate account"),("Private Fund Administrator",""),("Treasury","Seed capital")]),
 "Portfolio Transaction Type": ("ISO 20022 / FIX Protocol / Internal", [("Buy",""),("Sell",""),("Short Sale",""),("Buy to Cover",""),("Open Derivative",""),("Close Derivative",""),("Expiry / Maturity",""),("Dividend Income",""),("Interest Income",""),("Corporate Action - Securities",""),("Corporate Action - Cash",""),("Fee / Expense",""),("FX Spot",""),("FX Forward",""),("Capital Call Paid","Private fund interest"),("Distribution Received","Private fund interest"),("In-Kind Transfer In",""),("In-Kind Transfer Out",""),("Cash Transfer In",""),("Cash Transfer Out",""),("Adjustment","Booked for a position adjustment")]),
 "Portfolio Transaction Event Type": ("Internal / FIX Protocol", [("Booked",""),("Amended",""),("Canceled",""),("Rebooked","")]),
 "Snapshot Type": ("Internal", [("Start of Day Official",""),("End of Day",""),("Month-End Lock",""),("Quarter-End Lock",""),("Ad Hoc","")]),
 "Position Adjustment Reason": ("Internal / FIX Protocol", [("Custodian Break Correction",""),("Corporate Action Correction",""),("Missed Trade",""),("Duplicate Booking",""),("Conversion / Migration",""),("Private Asset Statement Update",""),("Other","")]),
}

# ---------------------------------------------------------------------------
REL = [
 ("Portfolio","is identified by","Portfolio Identifier","1 : 1..n","OMS, IBOR, accounting, custodian, administrator and GIPS schemes."),
 ("Portfolio","implements","Investment Product (01, PRD-) via Portfolio Implementation Link","n : 0..n","CD-145. A feeder fund is a product linked to its master's portfolio. Fund structure, dealing terms and service providers are read from the product."),
 ("Portfolio","implements","Investment Mandate (01, MND-) via Portfolio Implementation Link","n : 0..n","Segregated and sub-advised mandates; sub-advisory is the 01 mandate type."),
 ("Portfolio","manages","Account (15, ACC-) via Portfolio Implementation Link","n : 0..n","Institutional separate accounts (IA line) and sponsor program accounts (intermediary channel, IC line) only (CW-009). Effective-dated; one account may be run by several sleeve books if sleeves are not separate accounts (SME question 3)."),
 ("Portfolio","follows","Model Portfolio (01, MDL-) via Portfolio Implementation Link","n : 0..1","A model portfolio is never a Portfolio; must agree with 15 Program Enrollment where both exist."),
 ("Portfolio (Child)","rolls up to","Portfolio (Parent) via Portfolio Hierarchy Link","n : 0..n","Sleeves, carve-outs, aggregation, succession. Own-fund investments are holdings, not links."),
 ("Portfolio","is owned by","Internal Legal Entity (09, LEN-)","n : 0..1","CIT and proprietary books only."),
 ("Portfolio","is managed by","Internal Legal Entity (09, LEN-)","n : 1","Managing Entity."),
 ("Portfolio","is kept by","Party (02, PTY-) as middle office provider","n : 0..1","Outsourced IBOR operating model (CD-147)."),
 ("Portfolio","is held in","Safekeeping Account [28]","n : 0..1","Main safekeeping account (Safekeeping Custody Account, CD-194 option A); all accounts by purpose are 28 Safekeeping Account Assignments. SSIs are 26 (CD-155)."),
 ("Portfolio","is valued on","Calendar (09, CAL-)","n : 1","Valuation calendar on the accounting basis."),
 ("Portfolio","has","Portfolio Lifecycle Event","1 : 1..n","Inception to termination, including status and accounting basis changes."),
 ("Portfolio Lifecycle Event","may relate to","Transition Event (12, TRN-)","n : 0..1","In-kind funding or exit of mandate portfolios."),
 ("SMA Portfolio Detail","is run under","Distribution Agreement (05, AGR-)","n : 0..1","Sponsor program of a sponsor program account (intermediary channel), or consultant program of an institutional separate account, where there is one."),
 ("Portfolio","holds","Portfolio Holding","1 : 0..n","One per instrument x holding date x holding view."),
 ("Portfolio Holding","is of","Instrument (17, INS-)","n : 1","No instrument terms are held here."),
 ("Portfolio Holding","may correspond to","Fund Shareholder Position (06, POS-)","n : 0..1","Own-fund holdings: the same units are a Fund Shareholder Position on the portfolio's account (CD-146, CW-007); several views and dates map to one period-end position."),
 ("Portfolio x Instrument","is supported by","Tax Lot","1 : 0..n","Open lots of the instrument in the portfolio; a Tax Lot spans many holding dates and views."),
 ("Tax Lot","is of","Instrument (17, INS-)","n : 1",""),
 ("Tax Lot","is opened by","Portfolio Transaction","n : 1",""),
 ("Tax Lot","is relieved through","Lot Relief","1 : 0..n","Lot history is rebuilt from its reliefs."),
 ("Lot Relief","is caused by","Portfolio Transaction (closing)","n : 1",""),
 ("Portfolio","holds","Cash Balance","1 : 0..n","Per currency, cash account and balance type."),
 ("Portfolio","expects","Projected Cash Movement","1 : 0..n",""),
 ("Projected Cash Movement","arises from","Portfolio Transaction / Corporate Action Event (17, CAE-) / Portfolio Capital Activity","n : 0..1","Pending settlements, income, capital activity."),
 ("Portfolio","receives or pays","Portfolio Capital Activity","1 : 0..n",""),
 ("Portfolio Capital Activity","arises from dealing in","Share Class (01, SHC-)","n : 0..1","Pooled funds; shareholder transactions themselves are 29 Register Transaction (RGTX-, CW-122)."),
 ("Portfolio Capital Activity","arises from","Account (15, ACC-)","n : 0..1","Mandate and institutional separate account contributions and withdrawals."),
 ("Portfolio Capital Activity","may be notified by","Cash Flow Notification (12, CFN-)","n : 0..1","Mandate portfolios."),
 ("Portfolio","books","Portfolio Transaction","1 : 0..n","Booked effect on the portfolio; not the order (25) or settlement (26)."),
 ("Portfolio Transaction","is of","Instrument (17, INS-)","n : 0..1","Blank for pure cash transactions."),
 ("Portfolio Transaction","has","Portfolio Transaction Event","1 : 1..n","Booked, amended, canceled, rebooked."),
 ("Portfolio Transaction","is executed by","Party (02, PTY-) as broker or counterparty","n : 0..1",""),
 ("Portfolio Transaction","may be generated by","Corporate Action Event (17, CAE-)","n : 0..1",""),
 ("Portfolio Transaction","may move securities under","Transition Event (12, TRN-)","n : 0..1","In-specie transfers of mandate books."),
 ("Portfolio Transaction (in kind)","settles","Portfolio Capital Activity","n : 0..1","ETF creations and redemptions, in-kind subscriptions."),
 ("Portfolio Transaction","is booked from","Trade Allocation [25]","n : 0..1","Source Allocation ID (CD-180)."),
 ("Portfolio","has","Portfolio Position Snapshot","1 : 0..n","Start of day, end of day, period-end locks; members selected by business date and holding view."),
 ("Position Adjustment","changes","Portfolio Holding","n : 0..1","Approved by an Employee (20, EMP-)."),
 ("Position Adjustment","is booked as","Portfolio Transaction","1 : 1","Adjusting Transaction."),
 ("Portfolio","is summarized by","Portfolio Valuation Summary","1 : 0..n",""),
 ("Portfolio Valuation Summary","is computed from","Portfolio Position Snapshot","n : 0..1","IBOR estimate; NAV is 27 and AUM measures are 06."),
]

# ---------------------------------------------------------------------------
SRC = [
 ("ISO 20022 securities management (semt) messages: semt.002 Custody Statement of Holdings, semt.003 Accounting Statement of Holdings, semt.017 Statement of Transactions, semt.018 Statement of Pending Transactions","ISO / SWIFT","https://www.iso20022.org/iso-20022-message-definitions","Open standard","Holding statement structure (quantity, sub-balances such as settled and pending, price and value), transaction and pending transaction statements, cash balance types","Portfolio Holding, Holding Valuation, Cash Balance, Portfolio Transaction",["ISO 20022*"]),
 ("FIX Protocol: Allocation Instruction (MsgType J), Position Maintenance Request (AL) and Position Report (AP)","FIX Trading Community","https://www.fixtrading.org/standards/","Open standard","Transaction side, quantity, price, settlement date, accrued interest and commission on allocations; position adjustments and position reports","Portfolio Transaction, Transaction Cost & Charge, Position Adjustment",["FIX Protocol"]),
 ("BIAN Service Landscape (Investment Portfolio Management, Position Keeping, Investment Account service domains)","Banking Industry Architecture Network","https://bian.org/servicelandscape/","Open (registration)","Separation of portfolio management, position keeping and account behavior; used for the family cut only (confirm current service domain names)","Portfolio Master, Holdings, Book Control",["BIAN"]),
 ("FIBO Securities (SEC) and Financial Business & Commerce (FBC)","EDM Council","https://spec.edmcouncil.org/fibo/","Open (MIT license)","Portfolio and holding as concepts distinct from the security and from the account; legal owner","Portfolio, Portfolio Holding",["FIBO*"]),
 ("IRS Publication 550 (Investment Income and Expenses): basis of investment property, identification of shares sold, holding period, wash sales","US IRS","https://www.irs.gov/publications/p550","Regulation / guidance","Lot cost, adjusted basis, specific identification and FIFO default, capitalized costs, wash-sale basis adjustment and holding period tacking","Tax Lot, Lot Relief, Portfolio Accounting Basis, Lot Relief Method",["IRS Publication 550"]),
 ("IRC Section 1091 (wash sales); IRC Section 1222 (short- and long-term); Treas. Reg. 1.1012-1(c) (identification of securities sold)","US Congress; US Treasury","https://www.law.cornell.edu/uscode/text/26/1091","Statute / regulation","Disallowed loss, 61-day window, basis adjustment of replacement lot; one-year holding period; adequate identification and FIFO default","Tax Lot, Lot Relief, SMA Portfolio Detail",["IRC Section 1091", "IRC Section 1222", "Treas. Reg. 1.1012-1"]),
 ("IRS Form 8949 and instructions (Sales and Other Dispositions of Capital Assets)","US IRS","https://www.irs.gov/forms-pubs/about-form-8949","Form","Date acquired, date sold, proceeds, cost basis, wash-sale adjustment code, short- and long-term split","Lot Relief, Tax Lot",["IRS Form 8949"]),
 ("GIPS 2020 Standards for Firms (portfolio, composite, carve-out definitions)","CFA Institute","https://www.gipsstandards.org","Standard (free)","Portfolio as the unit of management, inception and termination, carve-outs","Portfolio, Portfolio Hierarchy Link, Portfolio Lifecycle Event",["GIPS 2020"]),
 ("ILPA Reporting Template and Capital Call & Distribution Template","Institutional Limited Partners Association","https://ilpa.org","Industry template (free)","Commitment, called capital, distributions, recallable distributions, unfunded commitment, NAV and capital account roll-forward","Fund Interest Holding Detail, Private Fund Portfolio Detail",["ILPA Reporting Template"]),
 ("SEC Form N-PORT and General Instructions","US SEC","https://www.sec.gov/files/formn-port.pdf","Regulatory form","Holding-level fields required for registered funds (quantity, units, value, long / short, derivatives notional and counterparty, delta); used as a cross-check","Portfolio Holding, Holding Valuation, Derivative Holding Detail",["SEC Form N-PORT"]),
 ("SEC Rule 6c-11 (exchange-traded funds)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.6c-11","Regulation","Daily publication of portfolio holdings; custom and in-kind baskets","Fund Portfolio Detail, Portfolio Capital Activity, Portfolio Transaction (Related Capital Activity)",["SEC Rule 6c-11"]),
 ("SEC interpretive release 34-54165 (2006): Commission Guidance Regarding Client Commission Practices Under Section 28(e) of the Securities Exchange Act of 1934","US SEC","https://www.sec.gov/rules-regulations/2006/07/commission-guidance-regarding-client-commission-practices-under-section-28e-securities-exchange-act","Regulatory guidance","Safe harbor for research and brokerage services paid with client commissions (soft dollars); eligible services; good-faith determination of reasonableness","Research Payment Component",["Exchange Act Section 28(e)", "SEC Section 28(e) Release 34-54165"]),
 ("SEC Form ADV (Part 1A Item 5; Part 2A Appendix 1 wrap fee programs)","US SEC","https://adviserinfo.sec.gov","Regulatory form","Discretionary authority, sub-advisory, and wrap fee and sponsor program structure (the firm's sponsor program accounts are intermediary channel)","SMA Portfolio Detail, Portfolio (Managing Entity)",["SEC Form ADV"]),
 ("BlackRock Aladdin (public product descriptions)","BlackRock","https://www.blackrock.com/aladdin","Vendor documentation (structure only)","Start-of-day and real-time IBOR views, portfolio and position concepts","Holding View, Snapshot Type, Portfolio Accounting Basis",["Aladdin"]),
 ("Charles River IMS (public product descriptions)","State Street","https://www.crd.com","Vendor documentation (structure only)","Portfolio and aggregate portfolio structures in an order management and IBOR platform","Portfolio, Portfolio Hierarchy Link",["Charles River"]),
 ("SimCorp Dimension / SimCorp One (public product descriptions)","SimCorp","https://www.simcorp.com","Vendor documentation (structure only)","Combined IBOR / ABOR, cash projection and accrual conventions","Projected Cash Movement, Portfolio Accounting Basis",["SimCorp"]),
 ("eFront and FIS Investran (public product descriptions)","BlackRock; FIS","https://www.efront.com","Vendor documentation (structure only)","Private markets fund interests, commitments and capital calls as held by private markets administration systems","Fund Interest Holding Detail, Private Fund Portfolio Detail",["eFront*"]),
 ("ISO 3166 / ISO 4217 / ISO 8601","ISO","https://www.iso.org","Standard; code lists widely available","Country, currency and date/time formats","Reference formats used throughout",["ISO 4217", "ISO 3166*", "ISO 8601"]),
]
