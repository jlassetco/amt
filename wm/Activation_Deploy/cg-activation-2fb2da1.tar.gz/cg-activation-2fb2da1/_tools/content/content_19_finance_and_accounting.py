"""Data Domain 19 - Finance & Accounting. Content module for taxonomy_builder.py."""

META = {
 "title": "Finance & Accounting Data Taxonomy",
 "subtitle": "Business domain 19 - Finance & Accounting | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "19_Finance_and_Accounting/Finance_and_Accounting_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the corporate books of a US direct wealth manager group (parent holding company, registered investment advisers, the self-clearing broker-dealer, transfer agent, recordkeeper, service company and the optional national trust company): the chart of accounts, general ledger accounts and chart segment values (company, natural account, cost center, profit center, product, channel, intercompany), the ledgers kept for each internal legal entity and accounting basis, journal entries and GL postings from every subledger, account balances, period close status and close tasks, consolidation scope and intercompany balances, payables and supplier payments, receivables and cash application, financial statements, statement line values and regulatory financial returns, enterprise financial plans, and corporate tax registrations, returns, provisions and transfer pricing documentation. It is produced by the Finance function (the Controller's group, Financial Reporting, FP&A and Tax) for every legal entity and every business line (CW-004). Fund books are excluded: the ledgers of the funds the firm manages belong to 27 Fund Accounting & Valuation. Built from the FASB Accounting Standards Codification (ASC 606, 810, 830, 740, 326), the US GAAP Financial Reporting Taxonomy, XBRL Global Ledger, the OECD Standard Audit File for Tax, ISO 20022 cash management and payment initiation messages, SEC Rule 17a-5 (FOCUS), SEC Form ADV financial items, state sales and use tax rules (the Streamlined Sales and Use Tax Agreement), the OECD Transfer Pricing Guidelines and Pillar Two GloBE rules, and Sarbanes-Oxley Section 404, with SAP S/4HANA, Oracle Fusion General Ledger and Workday Financials used as structural cross-checks only. Use it as a starting point for an enterprise finance data model, a finance data mart, a chart-of-accounts redesign or a business glossary."),
  ("Scope", "In scope: chart of accounts, GL accounts and chart segment values (including cost and profit center codes, which move here from 09 / 10 under CD-152); ledgers per legal entity, accounting basis, ledger currency and ledger role (with the accounting company code as the Company segment value); financial statement lines and line mapping; journal entries and GL postings (moved from 10) from every subledger; GL account balances; accounting period status (moved from 10) and close tasks; consolidation scope and intercompany balances and eliminations; payable invoices and credit notes, invoice lines, indirect tax detail, supplier payments and their application to invoices; receivable items and cash receipt application; financial statements, statement line values and regulatory financial returns (the broker-dealer's FOCUS reports and annual report, the advisers' Form ADV financial items and the Call Report of the optional national trust company); enterprise financial plan versions and plan lines; entity tax registrations, corporate tax returns, tax provisions and transfer pricing documentation (subject to CD-149). Out of scope (referenced by ID only): distribution revenue, waivers, cost items, accruals, allocation, profitability, management hierarchies, distribution budgets and intercompany agreements (10 FRR-, WVR-, DCO-, ACR-, ARN-, ICA-, ICC-, BUD-); fiscal calendars and periods, internal legal entities, org units, currencies and FX rate types (09 CAL-, LEN-, OU-); suppliers, customers, auditors and tax authorities (02 PTY-); partner invoices and payments (05 PMT-), fee invoices (12 BIL-), intermediary communication fee invoices (13 IFI-) and data invoices (14 DINV-), which keep their operational detail; employees and payroll results (20 EMP-); seed and proprietary portfolios (18 PORT-); FX rate observations (22 FXR-, CD-168); fund ledgers (27, CD-186); purchase orders (40 Purchase Order, PURCH-); corporate bank accounts, statements and regulatory capital calculations (43 Corporate Bank Account BKAC- and Capital Requirement Calculation RCAP-); 19 holds the cash GL account and its balance and the regulatory returns."),
  ("Structure", "Four levels: L1 Data Domain > L2 Data Family > L3 Data Business Object > L4 Data Business Attribute."),
  ("Core model", "Chart of Accounts -> GL Account (GLA-) and Chart Segment Value; Ledger (LDG-) = internal legal entity (09 LEN-) x accounting basis x ledger currency x ledger role, using one chart; the accounting company code is mastered once, as the Company Chart Segment Value. Journal Entry (JNL-) posts to one ledger in one fiscal period (09) and holds GL Posting lines (journal x line), each on a GL account and segment values, sourced from a 10 distribution finance record (including waivers and contract cost assets), a 19 payable, payment or receivable, or a 20 payroll run posted in summary. GL Account Balance = ledger x account combination x fiscal period x balance type x currency. Accounting Period Status = ledger x fiscal period; Close Tasks run each close cycle. Consolidation Scope Entity places a legal entity, a consolidated fund (01 PRD-) or a seed portfolio (18 PORT-) in a consolidation group with a method and control basis; Intercompany Balances are matched and eliminated. Payable Invoice (APV-) from a supplier (02 PTY-) has lines with GL coding and indirect tax detail and is settled by Supplier Payments through Supplier Payment Applications; it holds the link to the 05, 13 or 14 domain invoice it records. Receivable Item (debtor party or fund x source document, e.g. 12 BIL-, 10 FRR- or 10 ICC-) is cleared by Cash Receipt Applications. Financial Statement Line Mapping maps GL accounts to Financial Statement Lines, on which Financial Statement Line Values are reported; Financial Statements and Regulatory Financial Returns are produced per entity or group and period. Financial Plan Version (FPL-) holds Financial Plan Lines; 10 BUD- distribution plans roll into it. Entity Tax Registration, Tax Return (TAXR-), Tax Provision and Transfer Pricing Documentation (entity or group x fiscal year x document type) make up corporate tax."),
  ("Design principles", "1) Corporate books only: a fund's transactions never post to a 19 ledger; a fee the fund pays the firm does, as revenue of the adviser. 2) One ledger per legal entity x accounting basis x currency x ledger role, so US GAAP, regulatory and tax books are explicit, not assumed. 3) Moved objects keep their names: GL Posting and Accounting Period Status come from 10 with attribute names unchanged; Journal Entry takes the journal header. 4) One generic accounting record for each invoice, payment and receivable (CD-158); domain records keep their detail, and the links are held on the 19 record. 5) No FX series: the applied exchange rate on a posting or balance is a derived copy of 22 FX Rate Observation (CD-153, CD-168). 6) Account, segment and mapping records are effective-dated; restatements happen through journals, never by editing a posted line. 7) Shared enterprise lists (Payable Invoice Status, Outgoing Payment Status, Approval Status, Record Status, Regulator, Frequency, Reconciliation Status, RAG Status, Period Type, Reporting Period Basis) are used as 'Shared: <name>'."),
  ("Applies To", "Shows the record each attribute belongs to: Chart of Accounts, GL Account, Chart Segment Value, Ledger, Statement Line, Statement Line Mapping, Journal Entry, GL Posting, Account Balance, Accounting Period, Close Task, Consolidation Scope, Intercompany Balance, Payable Invoice, Invoice Line, Indirect Tax, Supplier Payment, Payment Application, Receivable Item, Cash Application, Financial Statement, Statement Line Value, Regulatory Return, Plan Version, Plan Line, Tax Registration, Tax Return, Tax Provision or TP Documentation."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify the account, ledger, entity or period of a posting, to state an amount, a posting date or a balance correctly, to key and settle an invoice, payment or receivable, to determine consolidation scope, or to file a financial, regulatory or tax return. Confirm with the Controller, Financial Reporting, FP&A and Tax."),
  ("Primary / Secondary Reference", "Standard, rule or source the attribute definition is aligned to (ASC, US GAAP Taxonomy, XBRL GL, OECD SAF-T, ISO 20022, SEC Rule 17a-5, SEC Form ADV, SSUTA, OECD TPG, OECD Pillar Two, SOX 404). 'Internal' = firm-defined. ERP references (SAP S/4HANA, Oracle Fusion GL, Workday Financials) show common structure only; vendor field dictionaries are not reproduced."),
  ("Notes", "PII = personal information under US privacy law (Regulation S-P for clients; state consumer privacy laws): employee identifiers on approvals and close tasks, and supplier or customer parties who are individuals (sole-proprietor contractors, individual clients billed directly for advisory or trust fees). Corporate financial data is confidential but not personal; plan and tax data are usually restricted until published."),
  ("Tabs", "Hierarchy, Taxonomy, Code Lists, Relationships, Sources."),
  ("Suggested next steps", "1) Validate families, objects and CDEs with the Controller, Financial Reporting, FP&A, Accounts Payable / Receivable and Tax. 2) Map attributes to the ERP general ledger, subledgers, consolidation tool and planning tool; record the system of record per object. 3) Agree the chart segment design (which of product, channel and intercompany sit in the GL) with 10 Client Revenue, Pricing Economics & Profitability. 4) Agree with 05, 12, 13 and 14 the reference attributes proposed in proposals_19.py (CD-158). 5) Apply the CD-152 hand-over in 10 and 09 (re-typing GL Natural Account, Applicable Ledger, Cost & Profit Center and Accounting Company Code as references). 6) Settle CD-149 (Tax domain) before Stage 2."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

FP = "External (09 Shared - Fiscal Period)"
FXT = "External (09 Shared - FX Rate Type)"
EMP_PII = "PII (employee identifier)."

# ---------------------------------------------------------------------------
D("Chart of Accounts & Ledgers", "FI-COA",
  "The structure of the books: charts of accounts, GL accounts, the segment values that qualify every posting (company, cost center, profit center, product, channel, intercompany), the ledgers kept for each legal entity and accounting basis, the statement lines of external reporting and the mapping of accounts to them.",
  [
   ("Chart of Accounts", "A chart of accounts and its segment structure.", [
     ("Chart of Accounts", [
       ("Chart of Accounts Code", "Code identifying the chart of accounts in the general ledger.", "Chart of Accounts", "Identifier", "", "GRPCOA", "Internal", "XBRL GL", "Y"),
       ("Chart of Accounts Name", "Business name of the chart.", "Chart of Accounts", "Text", "", "Group Operational Chart of Accounts", "Internal", "", ""),
       ("Chart Segment Structure", "Ordered list of segments that make up an account combination in this chart.", "Chart of Accounts", "Code (multi)", "Chart Segment", "Company; Natural Account; Cost Center; Product; Channel; Intercompany", "Oracle Fusion GL", "Workday Financials", ""),
       ("Chart Status", "Lifecycle status of the chart.", "Chart of Accounts", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
     ]),
   ]),
   ("GL Account", "Natural accounts of a chart, with their type, normal balance and default statement classification. GL Account is the only record for natural account values.", [
     ("GL Account", [
       ("GL Account ID", "Enterprise identifier of the GL account (chart x natural account).", "GL Account", "Identifier", "", "GLA-GRPCOA-620410", "Internal", "XBRL GL", "Y"),
       ("GL Account Chart", "Chart of accounts the account belongs to.", "GL Account", "Reference (Chart of Accounts, 19)", "", "GRPCOA", "Internal", "", ""),
       ("Natural Account Number", "Account number as used in the natural account segment.", "GL Account", "Identifier", "", "620410", "XBRL GL", "OECD SAF-T", "Y"),
       ("GL Account Name", "Business name of the natural account.", "GL Account", "Text", "", "Revenue Sharing and Platform Fees", "XBRL GL", "OECD SAF-T", ""),
       ("GL Account Type", "Fundamental accounting element the account records.", "GL Account", "Code", "GL Account Type", "Expense", "XBRL GL", "US GAAP Taxonomy", "Y"),
       ("Normal Balance", "Side on which the account's balance normally sits.", "GL Account", "Code", "Normal Balance", "Debit", "XBRL GL", "", ""),
       ("Financial Statement Class", "Default caption group used for internal reporting; the Financial Statement Line Mapping is authoritative for published statements.", "GL Account", "Code", "Financial Statement Class", "Operating Expense - Distribution", "US GAAP Taxonomy", "SEC Regulation S-X", "Y"),
       ("Parent Summary Account", "Summary (non-posting) account this account rolls up to in the chart hierarchy.", "GL Account", "Reference (GL Account, 19)", "", "GLA-GRPCOA-620000", "XBRL GL", "", ""),
       ("Subledger Control Account Indicator", "Whether the balance is maintained only by a subledger (payables, receivables) so manual journals are blocked.", "GL Account", "Boolean", "", "N", "SAP S/4HANA", "SOX 404", ""),
       ("Account Reconciliation Frequency", "How often the balance must be reconciled and signed off.", "GL Account", "Code", "Shared: Frequency", "Monthly", "SOX 404", "", ""),
       ("GL Account Status", "Lifecycle status of the account; only Active accounts accept postings.", "GL Account", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
       ("GL Account Effective From", "Date from which the account may be used.", "GL Account", "Date", "ISO 8601", "2019-01-01", "Internal", "", ""),
       ("GL Account Effective To", "Date after which the account may no longer be used.", "GL Account", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Chart Segment Value", "Values of the non-account segments (company, cost center, profit center, product, channel, intercompany), with the enterprise object each one represents. Natural account values are GL Accounts, never Chart Segment Values. The Company value is the single master of the accounting company code.", [
     ("Chart Segment Value", [
       ("Segment Value Chart", "Chart of accounts the value is defined in.", "Chart Segment Value", "Reference (Chart of Accounts, 19)", "", "GRPCOA", "Internal", "", ""),
       ("Chart Segment", "Segment the value belongs to (any segment except Natural Account).", "Chart Segment Value", "Code", "Chart Segment", "Cost Center", "Oracle Fusion GL", "Workday Financials", "Y"),
       ("Segment Value Code", "Code posted in the segment; for the Company segment this is the accounting company code of the legal entity.", "Chart Segment Value", "Identifier", "", "41020", "Internal", "XBRL GL", "Y", "Format decision: the posting code is the bare GL code (e.g. 41020, company 4100); the 09 org unit keeps its own OU-CC- key and is linked through Represented Org Unit (amends the CD-084 format)."),
       ("Segment Value Name", "Business name of the segment value.", "Chart Segment Value", "Text", "", "Human and Hybrid Advice - East Region", "Internal", "", ""),
       ("Parent Segment Value", "Value this value rolls up to in the segment's accounting hierarchy.", "Chart Segment Value", "Reference (Chart Segment Value, 19)", "", "41000", "Internal", "", ""),
       ("Represented Org Unit", "Org unit a cost center or profit center value stands for.", "Chart Segment Value", "Reference (Org Unit)", "", "OU-CC-41020", "Internal", "", ""),
       ("Represented Legal Entity", "Internal legal entity a company or intercompany value stands for.", "Chart Segment Value", "Reference (Legal Entity)", "", "LEN-0007", "Internal", "", ""),
       ("Represented Product", "Product a product segment value stands for, where products are carried in the GL.", "Chart Segment Value", "Reference (Product)", "", "PRD-00981", "Internal", "", ""),
       ("Segment Value Status", "Lifecycle status of the value; only Active values accept postings.", "Chart Segment Value", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
       ("Segment Value Effective From", "Date from which the value may be used.", "Chart Segment Value", "Date", "ISO 8601", "2024-01-01", "Internal", "", ""),
       ("Segment Value Effective To", "Date after which the value may no longer be used.", "Chart Segment Value", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Ledger", "The set of books kept for one legal entity under one accounting basis, currency and ledger role.", [
     ("Ledger", [
       ("Ledger ID", "Enterprise identifier of the ledger.", "Ledger", "Identifier", "", "LDG-4100-USGAAP-USD", "Internal", "Oracle Fusion GL", "Y"),
       ("Ledger Legal Entity", "Internal legal entity whose books the ledger holds; for a consolidation ledger, the group parent.", "Ledger", "Reference (Legal Entity)", "", "LEN-0007", "Internal", "XBRL GL", "Y"),
       ("Accounting Basis", "Accounting framework the ledger is kept under.", "Ledger", "Code", "Accounting Basis", "US GAAP", "Internal", "ASC 105", "Y"),
       ("Ledger Role", "Role of the ledger among the entity's books; part of the ledger's grain because an adjustment ledger shares entity, basis and currency with its primary ledger.", "Ledger", "Code", "Ledger Role", "Primary", "Oracle Fusion GL", "SAP S/4HANA", "Y"),
       ("Ledger Currency", "Currency in which the ledger's balances are held; for the primary ledger, the entity's functional currency as determined under ASC 830.", "Ledger", "Code", "ISO 4217", "USD", "ASC 830", "", "Y"),
       ("Ledger Chart of Accounts", "Chart of accounts used by the ledger.", "Ledger", "Reference (Chart of Accounts, 19)", "", "GRPCOA", "Internal", "", ""),
       ("Ledger Fiscal Calendar", "Fiscal calendar that defines the ledger's periods.", "Ledger", "Reference (Fiscal Calendar)", "", "CAL-FISCAL-GRP", "Internal", "", ""),
       ("Source Ledger", "Primary ledger from which a secondary, reporting-currency or adjustment ledger is derived.", "Ledger", "Reference (Ledger, 19)", "", "", "Oracle Fusion GL", "", ""),
     ]),
   ]),
   ("Financial Statement Lines & Mapping", "Statement lines of external reporting per framework, and the effective-dated mapping of GL accounts to them. External Reporting Line and XBRL Element moved from 10 Account Mapping (CD-152).", [
     ("Financial Statement Line", [
       ("Statement Line Code", "Firm code of the statement line or note line.", "Statement Line", "Identifier", "", "IS0110", "Internal", "", "Y"),
       ("Line Reporting Framework", "Framework whose statements the line belongs to.", "Statement Line", "Code", "Accounting Basis", "US GAAP", "Internal", "", ""),
       ("Line Statement Type", "Statement the line appears in.", "Statement Line", "Code", "Financial Statement Type", "Income Statement", "SEC Regulation S-X", "", ""),
       ("External Reporting Line", "Line in the published income statement or note.", "Statement Line", "Text", "", "Distribution and servicing fees", "US GAAP Taxonomy", "", ""),
       ("XBRL Element", "US GAAP Taxonomy element used to tag the external line (to be confirmed per filing).", "Statement Line", "Text", "External (US GAAP Taxonomy)", "us-gaap:DistributionAndServicingFees (to confirm)", "US GAAP Taxonomy", "", ""),
     ]),
     ("Financial Statement Line Mapping", [
       ("Mapped GL Account", "GL account being mapped.", "Statement Line Mapping", "Reference (GL Account, 19)", "", "GLA-GRPCOA-410100", "Internal", "", "Y"),
       ("Mapped Statement Line", "Statement line the account maps to.", "Statement Line Mapping", "Reference (Financial Statement Line, 19)", "", "IS0110", "Internal", "", ""),
       ("Revenue Disaggregation Category", "Category used in the ASC 606 disaggregation of revenue note.", "Statement Line Mapping", "Code", "External (10 - Revenue Stream)", "Distribution Fee", "ASC 606", "", ""),
       ("Line Mapping Effective From", "Date the mapping applies from.", "Statement Line Mapping", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Line Mapping Effective To", "Date the mapping ends.", "Statement Line Mapping", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Journals & Balances", "FI-JNL",
  "Journal entries posted to a ledger from every subledger and from manual entry, their lines (GL Posting, moved from 10), and the resulting account balances by period and balance type.",
  [
   ("Journal Entry", "The journal header: ledger, period, type, source and approval. Header attributes moved from 10 GL Posting (CD-152).", [
     ("Journal Entry", [
       ("Journal ID", "Unique identifier of the journal.", "Journal Entry", "Identifier", "", "JNL-2026-09-77120", "Internal", "SOX 404", "Y"),
       ("Journal Ledger", "Ledger the journal posts to.", "Journal Entry", "Reference (Ledger, 19)", "", "LDG-4100-USGAAP-USD", "XBRL GL", "", "Y"),
       ("Journal Type", "Type of journal.", "Journal Entry", "Code", "Journal Type", "Accrual", "Internal", "XBRL GL", "Y"),
       ("Journal Source", "Subledger, system or process that created the journal.", "Journal Entry", "Code", "Journal Source", "Client Revenue & Profitability", "XBRL GL", "OECD SAF-T", ""),
       ("Posting Date", "Date the journal posted.", "Journal Entry", "Date", "ISO 8601", "2026-09-30", "XBRL GL", "OECD SAF-T", "Y"),
       ("Posting Accounting Period", "Fiscal period of the posting.", "Journal Entry", "Code", FP, "FY2026-P09", "Internal", "", "Y"),
       ("Posting Legal Entity", "Internal legal entity whose ledger is posted.", "Journal Entry", "Reference (Legal Entity)", "", "LEN-0007", "Internal", "", "", "Determined by Journal Ledger -> Ledger Legal Entity; kept for compatibility with 10 (CD-152)."),
       ("Journal Status", "Processing status of the journal.", "Journal Entry", "Code", "Journal Status", "Posted", "Internal", "", ""),
       ("Manual Journal Indicator", "Whether the journal was keyed or uploaded by a person rather than generated by a subledger.", "Journal Entry", "Boolean", "", "N", "SOX 404", "PCAOB AS 2201", ""),
       ("Journal Prepared By", "Employee who prepared a manual journal.", "Journal Entry", "Reference (Employee)", "", "EMP-03390", "SOX 404", "", "", EMP_PII),
       ("Journal Approved By", "Employee who approved the journal; must differ from Journal Prepared By (segregation of duties).", "Journal Entry", "Reference (Employee)", "", "EMP-04211", "SOX 404", "PCAOB AS 2201", "", EMP_PII),
       ("Reversed Journal", "Journal that this journal reverses.", "Journal Entry", "Reference (Journal Entry, 19)", "", "JNL-2026-08-70415", "XBRL GL", "", ""),
     ]),
   ]),
   ("GL Posting", "Journal lines posted to the ledger. Moved from 10 with its name and attribute names unchanged; grain is journal x line.", [
     ("GL Posting", [
       ("Journal ID", "Journal the line belongs to.", "GL Posting", "Reference (Journal Entry, 19)", "", "JNL-2026-09-77120", "Internal", "SOX 404", "Y"),
       ("Journal Line Number", "Sequence number of the line within the journal.", "GL Posting", "Integer", "", "3", "XBRL GL", "OECD SAF-T", "Y"),
       ("Posted Account", "GL natural account posted.", "GL Posting", "Reference (GL Account, 19)", "", "GLA-GRPCOA-620410", "Internal", "", "Y"),
       ("Debit Credit Indicator", "Whether the line is a debit or a credit.", "GL Posting", "Code", "Normal Balance", "Debit", "XBRL GL", "OECD SAF-T", ""),
       ("Posted Amount", "Amount of the journal line in ledger currency, held unsigned; the side is given by Debit Credit Indicator.", "GL Posting", "Amount", "", "USD 1,740,000", "Internal", "", "Y"),
       ("Transaction Currency Amount", "Amount of the line in the currency of the underlying transaction, unsigned.", "GL Posting", "Amount", "", "EUR 1,602,000", "XBRL GL", "ASC 830", ""),
       ("Applied Exchange Rate", "Exchange rate used to convert the transaction amount to ledger currency.", "GL Posting", "Decimal", "", "1.0862", "ASC 830", "", "", "Derived copy of 22 FX Rate Observation.Spot Rate, or Period Rate where income and expense are translated at a period average, or its inverse or a cross (CD-153, CD-168)."),
       ("Cost Center Segment Value", "Cost center the line is charged to.", "GL Posting", "Reference (Chart Segment Value, 19)", "", "41020", "Internal", "", ""),
       ("Other Segment Values", "Product, channel and other non-account segment values on the line.", "GL Posting", "Reference (Chart Segment Value, 19) (multi)", "", "Product 0981; Channel WH", "Workday Financials", "", ""),
       ("Source Finance Record", "Fee revenue record, waiver record, cost item, accrual, contract cost asset, allocation run or intercompany charge that generated the line.", "GL Posting", "Reference (FRR- / WVR- / DCO- / ACR- / CCA- / ARN- / ICC-)", "", "ACR-2026-09-00441", "Internal", "SOX 404", "Y", "Waiver and expense reimbursement journals point at a 10 Waiver Record (WVR-); capitalized commission and amortization journals at a Contract Cost Asset (CCA-)."),
       ("Source Payable Invoice", "19 payable invoice that generated the line.", "GL Posting", "Reference (Payable Invoice, 19)", "", "APV-2026-0018833", "XBRL GL", "", ""),
       ("Source Supplier Payment", "19 supplier payment that generated the line.", "GL Posting", "Reference (Supplier Payment, 19)", "", "2000184533", "XBRL GL", "", ""),
       ("Source Receivable Item", "19 receivable item that generated the line.", "GL Posting", "Reference (Receivable Item, 19)", "", "1400072215", "XBRL GL", "", ""),
       ("Source Payroll Run", "Payroll run whose summary cost the line posts; payroll is posted in summary, never per employee.", "GL Posting", "Reference (Payroll Run, 20)", "", "US-SM-2026-09-R1", "Internal", "", "", "Run-level link to 20 Payroll Run (legal entity x pay period x run); no employee detail is held here."),
       ("Intercompany Partner Entity", "Counterparty internal entity for intercompany lines.", "GL Posting", "Reference (Legal Entity)", "", "LEN-0011", "Internal", "", ""),
     ]),
   ]),
   ("GL Account Balance", "Period balances by ledger, account combination, balance type and currency (actual, adjusted, translated, consolidated). Plan amounts are held only on Financial Plan Lines.", [
     ("GL Account Balance", [
       ("Balance Ledger", "Ledger holding the balance.", "Account Balance", "Reference (Ledger, 19)", "", "LDG-4100-USGAAP-USD", "XBRL GL", "", "Y"),
       ("Balance GL Account", "Natural account of the balance.", "Account Balance", "Reference (GL Account, 19)", "", "GLA-GRPCOA-620410", "XBRL GL", "", "Y"),
       ("Balance Segment Combination", "Full account combination (all segment values, in chart segment order) the balance is held at.", "Account Balance", "Text", "", "4100-620410-41020-0981-WH-0000", "Oracle Fusion GL", "", "", "Concatenated key of Chart Segment Values; each element is a 19 segment value code."),
       ("Balance Fiscal Period", "Fiscal period of the balance.", "Account Balance", "Code", FP, "FY2026-P09", "Internal", "", "Y"),
       ("Balance Type", "Kind of balance held.", "Account Balance", "Code", "Balance Type", "Actual", "Oracle Fusion GL", "SAP S/4HANA", "Y"),
       ("Balance Currency", "Currency in which the balance is expressed; part of the grain because translated balances can exist in several reporting currencies.", "Account Balance", "Code", "ISO 4217", "USD", "ASC 830", "", "Y"),
       ("Opening Balance", "Balance at the start of the period.", "Account Balance", "Amount", "", "USD 10,220,000", "XBRL GL", "OECD SAF-T", ""),
       ("Closing Balance", "Balance at the end of the period.", "Account Balance", "Amount", "", "USD 11,960,000", "XBRL GL", "OECD SAF-T", "Y"),
       ("Applied Exchange Rate", "Rate used where the balance is translated from ledger currency to a reporting currency.", "Account Balance", "Decimal", "", "1.2714", "ASC 830", "", "", "Derived copy of 22 FX Rate Observation.Spot Rate or Period Rate, or its inverse or a cross (CD-153, CD-168)."),
       ("Account Reconciliation Status", "Result of the period-end reconciliation of the balance.", "Account Balance", "Code", "Shared: Reconciliation Status", "Reconciled", "SOX 404", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Period Close & Consolidation", "FI-CLS",
  "Period status by ledger (moved from 10), the close task list, consolidation scope and intercompany matching and elimination.",
  [
   ("Accounting Period Status", "Close status of each fiscal period for each ledger. Moved from 10 with its name and attribute names unchanged; fiscal periods themselves stay in 09.", [
     ("Accounting Period Status", [
       ("Status Ledger", "Ledger the status applies to.", "Accounting Period", "Reference (Ledger, 19)", "", "LDG-4100-USGAAP-USD", "Internal", "", "Y"),
       ("Status Fiscal Period", "Fiscal period the status applies to.", "Accounting Period", "Code", FP, "FY2026-P09", "Internal", "", "Y"),
       ("Period Close Status", "Close status of the fiscal period for the ledger.", "Accounting Period", "Code", "Period Close Status", "Soft Close", "Internal", "SOX 404", "Y"),
       ("Translation Rate Type", "FX rate type used to translate income and expense to reporting currency (09 reference).", "Accounting Period", "Code", FXT, "Monthly Average Rate", "Internal", "ASC 830", ""),
       ("Balance Sheet Translation Rate Type", "FX rate type used to translate assets and liabilities at the period-end closing rate (09 reference).", "Accounting Period", "Code", FXT, "WMR London 4pm Close Mid", "ASC 830", "", ""),
       ("Hard Close Date", "Date the period was locked against all posting.", "Accounting Period", "Date", "ISO 8601", "2026-10-09", "Internal", "SOX 404", ""),
       ("Period Closed By", "Employee who closed or locked the period.", "Accounting Period", "Reference (Employee)", "", "EMP-04211", "SOX 404", "", "", EMP_PII),
       ("Period Reopen Reason", "Why a closed period was reopened, where it was.", "Accounting Period", "Text", "", "", "SOX 404", "", ""),
     ]),
   ]),
   ("Close Task", "Tasks in the close checklist for a close cycle and ledger, with owner, due workday and status.", [
     ("Close Task", [
       ("Close Task ID", "Identifier of the task in the close cycle.", "Close Task", "Identifier", "", "FY2026-P09-T042", "Internal", "", ""),
       ("Close Cycle Period", "Fiscal period being closed.", "Close Task", "Code", FP, "FY2026-P09", "Internal", "", ""),
       ("Close Task Ledger", "Ledger (and so legal entity) the task is performed for; empty for group-level tasks.", "Close Task", "Reference (Ledger, 19)", "", "LDG-4100-USGAAP-USD", "Internal", "", ""),
       ("Close Task Name", "What the task is.", "Close Task", "Text", "", "Reconcile intercompany balances with the broker-dealer", "Internal", "", ""),
       ("Close Task Owner", "Employee responsible for completing the task.", "Close Task", "Reference (Employee)", "", "EMP-03390", "SOX 404", "", "", EMP_PII),
       ("Due Workday", "Business day of the close calendar by which the task is due (e.g. 3 = third workday).", "Close Task", "Integer", "", "3", "Internal", "", ""),
       ("Close Task Status", "Progress status of the task.", "Close Task", "Code", "Close Task Status", "Completed", "Internal", "", ""),
       ("Close Task RAG", "Red-amber-green indicator shown on the close dashboard.", "Close Task", "Code", "Shared: RAG Status", "Green", "Internal", "", ""),
       ("Key Control Reference", "SOX key control the task evidences.", "Close Task", "Text", "", "Financial close key control 12", "SOX 404", "COSO", ""),
     ]),
   ]),
   ("Consolidation Scope", "Which entities, funds and portfolios are consolidated into each group, by what method and on what control basis. Each row has exactly one consolidated unit: a legal entity, a fund product or a seed portfolio.", [
     ("Consolidation Scope Entity", [
       ("Consolidation Group", "Consolidation group the unit is reported in.", "Consolidation Scope", "Code", "Firm-defined", "Group - US GAAP", "ASC 810", "", ""),
       ("Scope Legal Entity", "Internal legal entity in scope, where the consolidated unit is a group entity.", "Consolidation Scope", "Reference (Legal Entity)", "", "LEN-0004", "ASC 810", "", ""),
       ("Consolidated Fund Product", "Fund the firm manages and consolidates (e.g. a seeded fund), where the unit is a fund.", "Consolidation Scope", "Reference (Product)", "", "PRD-01220", "ASC 810", "", ""),
       ("Seed Portfolio", "Seed or proprietary portfolio whose holdings are brought into the group accounts, where the unit is a portfolio.", "Consolidation Scope", "Reference (Portfolio, 18)", "", "PORT-SEED-0041", "Internal", "", ""),
       ("Scope Fiscal Period", "Fiscal period for which the scope applies.", "Consolidation Scope", "Code", FP, "FY2026-P09", "Internal", "", ""),
       ("Consolidation Method", "How the unit is brought into the group accounts.", "Consolidation Scope", "Code", "Consolidation Method", "Full Consolidation", "ASC 810", "", "Y"),
       ("Control Assessment Basis", "Basis on which control or significant influence was concluded.", "Consolidation Scope", "Code", "Control Assessment Basis", "VIE - Primary Beneficiary", "ASC 810", "", "Y"),
       ("Group Ownership Percentage", "Effective economic interest of the group in the unit.", "Consolidation Scope", "Percentage", "", "100%", "ASC 810", "", ""),
       ("GP Entity Indicator", "Whether the unit is a general partner or manager entity of a private fund.", "Consolidation Scope", "Boolean", "", "N", "ASC 810", "", ""),
     ]),
   ]),
   ("Intercompany Balance", "Balances between pairs of group entities, their matching and elimination.", [
     ("Intercompany Balance", [
       ("Reporting Entity", "Group entity reporting the balance.", "Intercompany Balance", "Reference (Legal Entity)", "", "LEN-0021", "Internal", "ASC 810", "Y"),
       ("Counterparty Entity", "Group entity on the other side of the balance.", "Intercompany Balance", "Reference (Legal Entity)", "", "LEN-0004", "Internal", "ASC 810", "Y"),
       ("Intercompany GL Account", "Intercompany receivable, payable, revenue or expense account.", "Intercompany Balance", "Reference (GL Account, 19)", "", "GLA-GRPCOA-135000", "Internal", "", ""),
       ("Intercompany Period", "Fiscal period of the balance.", "Intercompany Balance", "Code", FP, "FY2026-P09", "Internal", "", ""),
       ("Reporting Entity Balance", "Balance as recorded by the reporting entity, in its ledger currency (USD for every entity of the US group).", "Intercompany Balance", "Amount", "", "USD 980,000", "Internal", "", ""),
       ("Counterparty Reported Balance", "Corresponding balance as recorded by the counterparty, translated to the same currency.", "Intercompany Balance", "Amount", "", "USD 975,400", "Internal", "", ""),
       ("Intercompany Difference", "Difference between the two balances.", "Intercompany Balance", "Amount", "", "USD 4,600", "Internal", "", "Y"),
       ("Intercompany Match Status", "Result of matching the two sides of the balance.", "Intercompany Balance", "Code", "Shared: Reconciliation Status", "Reconciled within Tolerance", "Internal", "", "Y"),
       ("Eliminated Indicator", "Whether the balance has been eliminated on consolidation (independent of the match status).", "Intercompany Balance", "Boolean", "", "Y", "ASC 810", "", ""),
       ("Elimination Journal", "Consolidation journal that eliminates the balance.", "Intercompany Balance", "Reference (Journal Entry, 19)", "", "JNL-2026-09-C0091", "ASC 810", "", ""),
       ("Source Intercompany Charge", "10 intercompany charge behind the balance, where it is a distribution charge.", "Intercompany Balance", "Reference (Intercompany Charge)", "", "ICC-2026-09-0019", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Payables", "FI-AP",
  "Generic accounts payable records for every supplier invoice and credit note, its lines and indirect tax, the payments that settle it and how each payment is applied (CD-158). Domain invoices in 05, 13 and 14 keep their operational detail; the links are held here.",
  [
   ("Payable Invoice", "The accounting record of a supplier invoice, credit note or prepayment request.", [
     ("Payable Invoice", [
       ("Payable Invoice ID", "Enterprise identifier of the payable invoice (AP voucher).", "Payable Invoice", "Identifier", "", "APV-2026-0018833", "OECD SAF-T", "XBRL GL", "Y"),
       ("Payable Document Type", "Whether the document is an invoice, a credit note or a prepayment request; credit notes reduce the amount owed.", "Payable Invoice", "Code", "Payable Document Type", "Invoice", "OECD SAF-T", "", "Y"),
       ("Supplier", "Party that issued the invoice.", "Payable Invoice", "Reference (Party)", "", "PTY-200417", "OECD SAF-T", "", "Y", "PII when the supplier is an individual."),
       ("Supplier Invoice Number", "Invoice number assigned by the supplier.", "Payable Invoice", "Identifier", "External (Vendor)", "INV-778120", "OECD SAF-T", "", "Y"),
       ("Invoice Date", "Date shown on the invoice.", "Payable Invoice", "Date", "ISO 8601", "2026-09-01", "OECD SAF-T", "", ""),
       ("Invoice Legal Entity", "Internal legal entity that owes the invoice.", "Payable Invoice", "Reference (Legal Entity)", "", "LEN-0021", "Internal", "", ""),
       ("Invoice Currency", "Currency of the invoice.", "Payable Invoice", "Code", "ISO 4217", "USD", "OECD SAF-T", "", ""),
       ("Invoice Gross Amount", "Total amount due including indirect tax, unsigned; the document type gives the direction.", "Payable Invoice", "Amount", "", "USD 25,440", "OECD SAF-T", "", "Y"),
       ("Payment Due Date", "Date by which the invoice must be paid.", "Payable Invoice", "Date", "ISO 8601", "2026-10-01", "Internal", "", "Y"),
       ("Payable Invoice Status", "Processing status of the invoice.", "Payable Invoice", "Code", "Shared: Payable Invoice Status", "Approved for Payment", "Internal", "", "Y"),
       ("Source Data Invoice", "14 data invoice the payable records, where the invoice is for licensed data.", "Payable Invoice", "Reference (Data Invoice)", "", "DINV-2026-01884", "Internal", "", ""),
       ("Source Intermediary Communication Fee Invoice", "05 intermediary communication fee invoice the payable records.", "Payable Invoice", "Reference (Intermediary Communication Fee Invoice, 05)", "", "IFI-2026-00412", "Internal", "", ""),
       ("Source Partner Invoice", "05 partner invoice the payable records, for revenue sharing and platform fees.", "Payable Invoice", "Reference (Partner Invoice, 05)", "", "INV-WHA-2026-0712", "Internal", "", ""),
       ("Purchase Order Reference", "Purchase order the invoice is matched to.", "Payable Invoice", "Reference (Purchase Order, 40)", "", "PURCH-4500021877", "Internal", "", "", "Re-typed at the Stage 4 consolidation (CD-260); the line-level match is 40 Invoice Match Result."),
     ]),
   ]),
   ("Payable Invoice Line", "Lines of a payable invoice with their GL coding.", [
     ("Payable Invoice Line", [
       ("Line Payable Invoice", "Invoice the line belongs to.", "Invoice Line", "Reference (Payable Invoice, 19)", "", "APV-2026-0018833", "OECD SAF-T", "", ""),
       ("Invoice Line Number", "Sequence number of the line on the invoice.", "Invoice Line", "Integer", "", "1", "OECD SAF-T", "", ""),
       ("Invoice Line Description", "What was supplied on the line.", "Invoice Line", "Text", "", "Q4 2026 index data license - display", "OECD SAF-T", "", ""),
       ("Line Net Amount", "Amount of the line before indirect tax.", "Invoice Line", "Amount", "", "USD 24,000", "OECD SAF-T", "", "Y"),
       ("Line Expense Account", "GL account the line is charged to.", "Invoice Line", "Reference (GL Account, 19)", "", "GLA-GRPCOA-640200", "Internal", "", "Y"),
       ("Line Cost Center", "Cost center the line is charged to.", "Invoice Line", "Reference (Chart Segment Value, 19)", "", "41020", "Internal", "", ""),
       ("Line Other Segment Values", "Product, channel and other segment values on the line.", "Invoice Line", "Reference (Chart Segment Value, 19) (multi)", "", "Channel WH", "Internal", "", ""),
     ]),
   ]),
   ("Indirect Tax Detail", "US sales and use tax (or a foreign VAT or GST a supplier charges) on a payable invoice line, and whether the firm self-assesses use tax.", [
     ("Indirect Tax Detail", [
       ("Indirect Tax Type", "Kind of indirect tax charged.", "Indirect Tax", "Code", "Tax Type", "Sales and Use Tax", "State sales and use tax law", "SSUTA", ""),
       ("Indirect Tax Rate", "Combined state and local rate applied.", "Indirect Tax", "Percentage", "", "6%", "State sales and use tax law", "SSUTA", ""),
       ("Indirect Tax Amount", "Tax amount on the line.", "Indirect Tax", "Amount", "", "USD 1,440", "OECD SAF-T", "", "Y"),
       ("Indirect Tax Recoverability", "How the tax on the line is treated: a cost, use tax the firm self-assesses, an exempt purchase, or a foreign tax that can be reclaimed.", "Indirect Tax", "Code", "Indirect Tax Recoverability", "Irrecoverable", "State sales and use tax law", "SSUTA", ""),
       ("Recoverable Percentage", "Share of the tax on the line that can be recovered: 0% for US sales and use tax, which is a cost of the purchase; a foreign indirect tax reclaim where one applies.", "Indirect Tax", "Percentage", "", "0%", "Internal", "", ""),
     ]),
   ]),
   ("Supplier Payment", "Outgoing payments made in a payment run and how each is applied to payable invoices.", [
     ("Supplier Payment", [
       ("Supplier Payment Document Number", "ERP document number of the payment.", "Supplier Payment", "Identifier", "", "2000184533", "OECD SAF-T", "ISO 20022", "Y"),
       ("Payment Run Reference", "Payment run the payment was made in.", "Supplier Payment", "Text", "", "US-AP 2026-10-01 run 1", "Internal", "", ""),
       ("Payee Supplier", "Party paid.", "Supplier Payment", "Reference (Party)", "", "PTY-200417", "ISO 20022", "", "Y", "PII when the payee is an individual."),
       ("Paying Legal Entity", "Internal legal entity making the payment.", "Supplier Payment", "Reference (Legal Entity)", "", "LEN-0021", "ISO 20022", "", ""),
       ("Payment Method", "Instrument used for the payment.", "Supplier Payment", "Code", "Payment Method", "ACH Credit", "ISO 20022", "", ""),
       ("Payment Amount", "Total amount paid.", "Supplier Payment", "Amount", "", "USD 25,440", "ISO 20022", "", "Y"),
       ("Payment Value Date", "Date the funds leave the paying bank account.", "Supplier Payment", "Date", "ISO 8601", "2026-10-01", "ISO 20022", "", "Y"),
       ("Paying Bank Account", "Firm bank account debited.", "Supplier Payment", "Reference (Corporate Bank Account, 43)", "", "BKAC-00118", "Internal", "", "", "Re-typed at the Stage 4 consolidation (CD-274): corporate bank accounts are mastered in 43."),
       ("Outgoing Payment Status", "Status of the payment.", "Supplier Payment", "Code", "Shared: Outgoing Payment Status", "Paid / Settled", "ISO 20022", "", ""),
       ("Settled Partner Payment", "05 partner payment this payment executes, for revenue sharing and platform fees.", "Supplier Payment", "Reference (Partner Payment)", "", "PMT-2026-004411", "Internal", "", ""),
     ]),
     ("Supplier Payment Application", [
       ("Applied Supplier Payment", "Payment being applied.", "Payment Application", "Reference (Supplier Payment, 19)", "", "2000184533", "Internal", "", ""),
       ("Settled Payable Invoice", "Payable invoice or credit note the payment is applied to.", "Payment Application", "Reference (Payable Invoice, 19)", "", "APV-2026-0018833", "Internal", "", "Y"),
       ("Applied Payment Amount", "Part of the payment applied to this invoice, allowing partial payments.", "Payment Application", "Amount", "", "USD 25,440", "Internal", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Receivables", "FI-AR",
  "Generic accounts receivable records for amounts owed to group entities (fee invoices, fees receivable from funds, intercompany, carried interest and other) and the application of cash received against them (CD-158).",
  [
   ("Receivable Item", "An open or cleared amount owed by a debtor, keyed by debtor and source document.", [
     ("Receivable Item", [
       ("Receivable Document Number", "ERP document number of the receivable.", "Receivable Item", "Identifier", "", "1400072215", "OECD SAF-T", "XBRL GL", "Y"),
       ("Customer Party", "External party that owes the amount (institutional client, partner, other); empty when the debtor is a fund the firm manages.", "Receivable Item", "Reference (Party)", "", "PTY-100455", "OECD SAF-T", "", "Y", "PII when the customer is an individual."),
       ("Debtor Fund Product", "Fund the firm manages that owes the amount (management, administration and other fees receivable).", "Receivable Item", "Reference (Product)", "", "PRD-00981", "Internal", "", ""),
       ("Receivable Legal Entity", "Internal legal entity owed the amount.", "Receivable Item", "Reference (Legal Entity)", "", "LEN-0021", "Internal", "", ""),
       ("Receivable Source Type", "Kind of document that created the receivable.", "Receivable Item", "Code", "Receivable Source Type", "Fee Invoice", "Internal", "", ""),
       ("Source Fee Invoice", "47 fee invoice the receivable records.", "Receivable Item", "Reference (Fee Invoice, 47)", "", "BIL-2026Q3-00921", "Internal", "", ""),
       ("Source Fee Revenue Record", "10 fee revenue record for fees receivable from a fund.", "Receivable Item", "Reference (Fee Revenue Record)", "", "FRR-2026-09-001882", "Internal", "", ""),
       ("Source Intercompany Charge", "10 intercompany charge the receivable records.", "Receivable Item", "Reference (Intercompany Charge)", "", "ICC-2026-09-0019", "Internal", "", ""),
       ("Other Source Document Reference", "Reference of the source document for subleases and other receivables that have no enterprise record.", "Receivable Item", "Text", "", "Sublease invoice 2026-08 Floor 12", "Internal", "", ""),
       ("Receivable Due Date", "Date by which payment is due.", "Receivable Item", "Date", "ISO 8601", "2026-11-09", "Internal", "", "Y"),
       ("Original Receivable Amount", "Amount owed when the item was raised, including output tax.", "Receivable Item", "Amount", "", "USD 631,020", "OECD SAF-T", "", "Y"),
       ("Open Receivable Amount", "Amount still outstanding.", "Receivable Item", "Amount", "", "USD 0", "Internal", "", "Y"),
       ("Output VAT Amount", "Sales or other indirect tax charged on the item; advisory, management and trust fees are generally not subject to state sales tax, so the amount is usually zero (name kept for continuity).", "Receivable Item", "Amount", "", "USD 0", "State sales and use tax law", "SSUTA", ""),
       ("Receivable Status", "Collection status of the item.", "Receivable Item", "Code", "Receivable Status", "Cleared", "Internal", "", ""),
     ]),
   ]),
   ("Cash Receipt Application", "Application of a cash receipt to a receivable item, including write-offs.", [
     ("Cash Receipt Application", [
       ("Cash Receipt Reference", "Identifier of the cash receipt being applied.", "Cash Application", "Identifier", "", "1600031188", "Internal", "ISO 20022", ""),
       ("Applied Receivable Item", "Receivable item the cash is applied to.", "Cash Application", "Reference (Receivable Item, 19)", "", "1400072215", "Internal", "", "Y"),
       ("Remitting Party", "Party that sent the cash.", "Cash Application", "Reference (Party)", "", "PTY-100455", "ISO 20022", "", "", "PII when the remitter is an individual."),
       ("Receipt Value Date", "Date the cash was credited to the firm's bank account.", "Cash Application", "Date", "ISO 8601", "2026-11-05", "ISO 20022", "", ""),
       ("Applied Amount", "Part of the receipt applied to this receivable item.", "Cash Application", "Amount", "", "USD 631,020", "Internal", "", "Y"),
       ("Write-Off Amount", "Residual amount written off on application.", "Cash Application", "Amount", "", "USD 0", "Internal", "", ""),
       ("Bank Statement Entry Reference", "Bank statement entry the receipt came from.", "Cash Application", "Reference (Bank Statement Entry, 43)", "", "BKAC-00118 / End-of-Day Statement / 2026-10-05 / 198 / 12", "ISO 20022", "", "", "Re-typed at the Stage 4 consolidation (CD-274): the 43 Bank Statement Entry, keyed by its statement and entry sequence; the link is held only here (one entry is applied to many receivable items)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Financial & Regulatory Reporting", "FI-RPT",
  "Statutory, group and regulatory financial statements and returns produced from the ledgers, with their line values.",
  [
   ("Financial Statement", "A financial statement for an entity or group, framework and period.", [
     ("Financial Statement", [
       ("Financial Statement ID", "Identifier of the statement (entity or group x framework x period x statement type).", "Financial Statement", "Identifier", "", "4100-USGAAP-FY2025-BS", "Internal", "", "Y"),
       ("Statement Reporting Entity", "Legal entity the statement is for, or the parent of a consolidated group.", "Financial Statement", "Reference (Legal Entity)", "", "LEN-0001", "SEC Regulation S-X", "", "Y"),
       ("Consolidated Statement Indicator", "Whether the statement presents a consolidated group rather than a single entity.", "Financial Statement", "Boolean", "", "Y", "ASC 810", "", ""),
       ("Statement Reporting Framework", "Framework the statement is prepared under.", "Financial Statement", "Code", "Accounting Basis", "US GAAP", "SEC Regulation S-X", "", "Y"),
       ("Financial Statement Type", "Which statement it is.", "Financial Statement", "Code", "Financial Statement Type", "Balance Sheet", "SEC Regulation S-X", "", "Y"),
       ("Statement Period Type", "Length of the period presented.", "Financial Statement", "Code", "Shared: Period Type", "Year", "Internal", "", ""),
       ("Statement Period End Date", "Balance sheet date or end of the period presented.", "Financial Statement", "Date", "ISO 8601", "2025-12-31", "SEC Regulation S-X", "", "Y"),
       ("Statement Approval Status", "Approval status of the statement version.", "Financial Statement", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("Statement Auditor", "Audit firm that audited the statement.", "Financial Statement", "Reference (Party)", "", "PTY-300012", "PCAOB AS 2201", "", ""),
     ]),
   ]),
   ("Financial Statement Line Value", "Values reported on each line of a financial statement.", [
     ("Financial Statement Line Value", [
       ("Line Financial Statement", "Statement the value belongs to.", "Statement Line Value", "Reference (Financial Statement, 19)", "", "4100-USGAAP-FY2025-BS", "Internal", "", ""),
       ("Value Statement Line", "Statement line the value is reported on; caption and XBRL element come from the line.", "Statement Line Value", "Reference (Financial Statement Line, 19)", "", "BS0120", "Internal", "", ""),
       ("Current Period Value", "Value reported for the current period.", "Statement Line Value", "Amount", "", "USD 48,300,000", "US GAAP Taxonomy", "", "Y"),
       ("Comparative Period Value", "Value reported for the comparative period.", "Statement Line Value", "Amount", "", "USD 44,950,000", "SEC Regulation S-X", "", ""),
       ("Value Period Basis", "Period basis of an income or cash flow value (e.g. year to date, quarter to date).", "Statement Line Value", "Code", "Shared: Reporting Period Basis", "Fiscal Year to Date", "Internal", "", ""),
     ]),
   ]),
   ("Regulatory Financial Return", "Financial and capital returns filed with regulators by group entities: FOCUS reports and the annual report of the self-clearing broker-dealer, Form ADV financial items of the advisers, and the Call Report of the optional national trust company.", [
     ("Regulatory Financial Return", [
       ("Return Filing Entity", "Legal entity filing the return.", "Regulatory Return", "Reference (Legal Entity)", "", "LEN-0003", "SEC Rule 17a-5", "SEC Form ADV", "Y"),
       ("Return Regulator", "Regulator the return is filed with.", "Regulatory Return", "Code", "Shared: Regulator", "FINRA", "SEC Rule 17a-5", "", ""),
       ("Regulatory Return Type", "Which return it is.", "Regulatory Return", "Code", "Regulatory Return Type", "FOCUS Report Part II", "SEC Rule 17a-5", "SEC Form ADV", "Y"),
       ("Return Reporting Period End", "End date of the period the return covers.", "Regulatory Return", "Date", "ISO 8601", "2026-09-30", "SEC Rule 17a-5", "", ""),
       ("Return Frequency", "How often the return is filed.", "Regulatory Return", "Code", "Shared: Frequency", "Quarterly", "SEC Rule 17a-5", "", ""),
       ("Return Due Date", "Regulatory deadline for the filing.", "Regulatory Return", "Date", "ISO 8601", "2026-10-26", "SEC Rule 17a-5", "", "Y"),
       ("Regulatory Return Status", "Filing status of the return.", "Regulatory Return", "Code", "Return Filing Status", "Accepted", "Internal", "", ""),
       ("Capital Requirement Amount", "Minimum capital required as reported on the return (e.g. the Rule 15c3-1 net capital requirement: at least USD 250,000 for a carrying broker-dealer, or 2% of aggregate debit items under the alternative standard).", "Regulatory Return", "Amount", "", "USD 250,000", "SEC Rule 15c3-1", "", "", "Derived copy (43) since the Stage 4 consolidation (CD-277): 43 Capital Requirement Calculation.Treasury Capital Requirement Amount of the return's filing entity and regime with Calculation As-Of Date = the return's reporting period end and approval status 'Approved' (the latest version if several). The return, its status and due date stay 19."),
       ("Capital Resources Amount", "Capital held against the requirement as reported on the return (e.g. net capital).", "Regulatory Return", "Amount", "", "USD 412,000,000", "SEC Rule 15c3-1", "", "", "Derived copy (43) since the Stage 4 consolidation (CD-277): 43 Capital Requirement Calculation.Treasury Capital Resources Amount of the return's filing entity and regime with Calculation As-Of Date = the return's reporting period end and approval status 'Approved' (the latest version if several). The return, its status and due date stay 19."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Planning & Forecasting", "FI-PLN",
  "Enterprise budgets, forecasts and long-range plans by legal entity, account and segment. Distribution plans (10 BUD-) roll into them.",
  [
   ("Financial Plan Version", "A version of an enterprise budget, forecast or long-range plan.", [
     ("Financial Plan Version", [
       ("Financial Plan Version ID", "Enterprise identifier of the plan version.", "Plan Version", "Identifier", "", "FPL-2027-BUD", "Internal", "", "Y"),
       ("Plan Cycle Name", "Planning cycle the version belongs to.", "Plan Version", "Text", "", "FY2027 Annual Budget", "Internal", "", ""),
       ("Financial Plan Type", "Kind of plan.", "Plan Version", "Code", "Plan Type", "Annual Budget", "Internal", "", ""),
       ("Plan Scenario", "Scenario the version represents, including stress scenarios.", "Plan Version", "Code", "Plan Scenario", "Base", "Internal", "", ""),
       ("Plan Fiscal Year", "Fiscal year covered.", "Plan Version", "Code", FP, "FY2027-Y", "Internal", "", "", "Year-type 09 fiscal period; ID format to confirm with 09."),
       ("Actuals Through Period", "Last fiscal period of actuals included in a forecast version.", "Plan Version", "Code", FP, "FY2026-P09", "Internal", "", ""),
       ("Plan Version Status", "Workflow status of the version.", "Plan Version", "Code", "Plan Version Status", "Approved", "Internal", "", ""),
       ("Plan Approved By", "Executive who approved the version.", "Plan Version", "Reference (Employee)", "", "EMP-00102", "Internal", "", "", EMP_PII),
     ]),
   ]),
   ("Financial Plan Line", "Planned amounts and FTE targets by legal entity, account combination and period.", [
     ("Financial Plan Line", [
       ("Line Plan Version", "Plan version the line belongs to.", "Plan Line", "Reference (Financial Plan Version, 19)", "", "FPL-2027-BUD", "Internal", "", "Y"),
       ("Plan Legal Entity", "Legal entity the amount is planned in.", "Plan Line", "Reference (Legal Entity)", "", "LEN-0007", "Internal", "", ""),
       ("Plan GL Account", "Natural account planned.", "Plan Line", "Reference (GL Account, 19)", "", "GLA-GRPCOA-620410", "Internal", "", ""),
       ("Plan Segment Values", "Cost center and other segment values the line is planned at.", "Plan Line", "Reference (Chart Segment Value, 19) (multi)", "", "41020; Channel WH", "Internal", "", ""),
       ("Plan Line Period", "Fiscal period of the amount.", "Plan Line", "Code", FP, "FY2027-P03", "Internal", "", ""),
       ("Plan Line Amount", "Planned amount in plan currency.", "Plan Line", "Amount", "", "USD 1,650,000", "Internal", "", "Y"),
       ("Planned FTE", "Top-down full-time equivalent target on the line where it carries staff cost; position-level FTE plans are 20 Workforce Positions.", "Plan Line", "Decimal", "", "12.5", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Corporate Tax", "FI-TAX",
  "Tax registrations, returns, provisions and transfer pricing documentation of the group's own entities. Investor tax (02, 13, 15, 16) and fund tax (27) are not here. Subject to CD-149: the family moves unchanged if a Tax domain is created.",
  [
   ("Entity Tax Registration", "Each registration of a group entity with a tax authority.", [
     ("Entity Tax Registration", [
       ("Registered Legal Entity", "Group entity that holds the registration.", "Tax Registration", "Reference (Legal Entity)", "", "LEN-0021", "Internal", "", ""),
       ("Registration Tax Jurisdiction", "Country or state of the registration.", "Tax Registration", "Code", "ISO 3166-2", "US-PA", "OECD SAF-T", "", "", "ISO 3166-1 alpha-2 country code; ISO 3166-2 where the registration is at state level (e.g. US-NY)."),
       ("Registration Tax Type", "Tax the registration is for; FATCA registrations (GIIN) are held under Withholding Tax.", "Tax Registration", "Code", "Tax Type", "Sales and Use Tax", "OECD SAF-T", "", ""),
       ("Tax Registration Number", "Number issued by the tax authority (e.g. EIN, state tax account or sales tax permit number, GIIN).", "Tax Registration", "Identifier", "", "PA-87654321", "OECD SAF-T", "IRS", "Y"),
       ("Registering Tax Authority", "Tax authority that issued the registration.", "Tax Registration", "Reference (Party)", "", "PTY-900021", "Internal", "", ""),
       ("Registration Effective From", "Date the registration took effect.", "Tax Registration", "Date", "ISO 8601", "2012-04-01", "Internal", "", ""),
       ("Registration Effective To", "Date the registration was canceled.", "Tax Registration", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Tax Return", "Corporate income tax, indirect tax and Pillar Two returns filed by group entities. Country-by-country reports are Transfer Pricing Documentation.", [
     ("Tax Return", [
       ("Tax Return ID", "Enterprise identifier of the return.", "Tax Return", "Identifier", "", "TAXR-US-4100-FY2025-1120", "Internal", "", "Y"),
       ("Return Legal Entity", "Group entity (or reporting parent) filing the return.", "Tax Return", "Reference (Legal Entity)", "", "LEN-0001", "IRS Form 1120", "OECD Pillar Two", "Y"),
       ("Return Tax Jurisdiction", "Country or state the return is filed in.", "Tax Return", "Code", "ISO 3166-2", "US", "Internal", "", "", "ISO 3166-1 alpha-2 country code; ISO 3166-2 where the return is filed at state level."),
       ("Return Tax Type", "Tax the return reports.", "Tax Return", "Code", "Tax Type", "Corporate Income Tax", "Internal", "", ""),
       ("Tax Return Form", "Official form or schema used.", "Tax Return", "Text", "External (tax authority forms)", "IRS Form 1120", "IRS Form 1120", "", ""),
       ("Return Tax Period", "Fiscal year or period the return covers.", "Tax Return", "Code", FP, "FY2025-Y", "Internal", "", "", "Year-type 09 fiscal period; ID format to confirm with 09."),
       ("Return Filing Due Date", "Due date including any extension granted.", "Tax Return", "Date", "ISO 8601", "2026-10-15", "IRS Form 1120", "", ""),
       ("Tax Return Status", "Filing status of the return.", "Tax Return", "Code", "Return Filing Status", "Filed", "Internal", "", ""),
       ("Tax Liability Amount", "Tax due as computed on the return.", "Tax Return", "Amount", "", "USD 18,400,000", "IRS Form 1120", "", "Y"),
     ]),
   ]),
   ("Tax Provision", "Income tax provision by entity, period, jurisdiction and component under ASC 740. The effective tax rate is computed from these rows in reporting.", [
     ("Tax Provision", [
       ("Provision Legal Entity", "Group entity the provision is for.", "Tax Provision", "Reference (Legal Entity)", "", "LEN-0007", "ASC 740", "", ""),
       ("Provision Fiscal Period", "Fiscal period of the provision.", "Tax Provision", "Code", FP, "FY2026-P09", "ASC 740", "", ""),
       ("Provision Tax Jurisdiction", "Jurisdiction the component relates to.", "Tax Provision", "Code", "ISO 3166-2", "US", "ASC 740", "", "", "ISO 3166-1 alpha-2 country code; ISO 3166-2 for state-level components."),
       ("Provision Component", "Component of the provision; values are grouped as expense components or balance sheet components.", "Tax Provision", "Code", "Provision Component", "Expense - Deferred Tax", "ASC 740", "", "Y"),
       ("Provision Amount", "Amount of the component.", "Tax Provision", "Amount", "", "USD 1,250,000", "ASC 740", "", "Y"),
       ("Provision Journal", "Journal that books the provision.", "Tax Provision", "Reference (Journal Entry, 19)", "", "JNL-2026-09-T0012", "Internal", "", ""),
     ]),
   ]),
   ("Transfer Pricing Documentation", "Master files, local files and country-by-country reports prepared for a group entity or the group. TP policy for distribution charges stays in 10.", [
     ("Transfer Pricing Documentation", [
       ("TP Documentation ID", "Identifier of the documentation (documented entity or group x fiscal year x document type).", "TP Documentation", "Identifier", "", "US Local File FY2025", "OECD TPG", "", ""),
       ("Documented Legal Entity", "Group entity the local file is for, or the group parent for a master file or CbC report.", "TP Documentation", "Reference (Legal Entity)", "", "LEN-0021", "OECD TPG", "IRS Form 8975", "Y"),
       ("TP Documentation Type", "Kind of documentation.", "TP Documentation", "Code", "TP Documentation Type", "Local File", "OECD TPG", "", "Y"),
       ("TP Documentation Fiscal Year", "Fiscal year documented.", "TP Documentation", "Code", FP, "FY2025-Y", "OECD TPG", "", "", "Year-type 09 fiscal period; ID format to confirm with 09."),
       ("Covered Intercompany Agreements", "10 intercompany agreements whose pricing the documentation supports: those whose 10 TP Policy names this documentation in TP Documentation Reference.", "TP Documentation", "Text (multi)", "", "ICA-0019", "OECD TPG", "", "", "Derived copy (10): the link is held on the 10 side (TP Policy.TP Documentation Reference, 10 review ruling 5); 19 holds no back-link of its own."),
       ("Covered Transaction Value", "Total value of the controlled transactions documented.", "TP Documentation", "Amount", "", "USD 11,800,000", "OECD TPG", "", ""),
       ("Contemporaneous Indicator", "Whether the documentation existed when the related return was filed (penalty protection).", "TP Documentation", "Boolean", "", "Y", "IRC Section 6662", "OECD TPG", ""),
       ("Documentation Owner", "Tax employee accountable for the documentation.", "TP Documentation", "Reference (Employee)", "", "EMP-02640", "Internal", "", "", EMP_PII),
     ]),
   ]),
  ])

CL = {
 # Moved from 10 (values kept)
 "Journal Type": ("Internal (moved from 10)", [("Accrual",""),("Reversal",""),("True-Up",""),("Allocation",""),("Reclassification",""),("Intercompany",""),("Amortization",""),("Standard","Added in 19: routine subledger posting"),("Revaluation","Added in 19: FX revaluation (ASC 830)"),("Consolidation Adjustment","Added in 19: elimination and top-side entries"),("Fee Waiver / Expense Reimbursement","Added in 19: from 10 Waiver Records"),("Opening Balance","Added in 19")]),
 "Period Close Status": ("Internal (moved from 10)", [("Open",""),("Soft Close",""),("Hard Close",""),("Reopened",""),("Not Yet Opened","Added in 19"),("Permanently Closed","Added in 19: year-end lock after audit")]),
 # New in 19
 "GL Account Type": ("XBRL GL / US GAAP Taxonomy", [("Asset",""),("Liability",""),("Equity",""),("Revenue",""),("Expense",""),("Statistical","Non-monetary quantity, e.g. headcount")]),
 "Normal Balance": ("XBRL GL", [("Debit",""),("Credit","")]),
 "Financial Statement Class": ("US GAAP Taxonomy / SEC Regulation S-X (firm captions)", [("Cash and Cash Equivalents",""),("Receivables",""),("Investments - Seed and Co-Investment",""),("Fixed Assets and Right-of-Use Assets",""),("Intangible Assets and Goodwill",""),("Payables and Accrued Liabilities",""),("Compensation Payable",""),("Debt",""),("Equity",""),("Revenue - Management and Advisory Fees",""),("Revenue - Performance Fees",""),("Revenue - Distribution and Servicing Fees",""),("Operating Expense - Compensation",""),("Operating Expense - Distribution",""),("Operating Expense - General and Administrative",""),("Non-Operating Income and Expense",""),("Income Tax","")]),
 "Chart Segment": ("Oracle Fusion GL / Workday Financials (structural cross-check)", [("Company","Legal entity; the value code is the accounting company code"),("Natural Account","Values held as GL Accounts, not Chart Segment Values"),("Cost Center",""),("Profit Center",""),("Product",""),("Channel",""),("Intercompany","Partner entity"),("Project",""),("Future Use","Reserved segment")]),
 "Accounting Basis": ("Internal", [("US GAAP",""),("Tax Basis","Book kept on a tax basis"),("Regulatory","Basis prescribed for a regulatory return")]),
 "Ledger Role": ("Oracle Fusion GL / SAP S/4HANA (structural cross-check)", [("Primary","Book of record for the entity"),("Secondary","Parallel accounting basis"),("Reporting Currency","Translated copy in a reporting currency"),("Adjustment","Top-side and audit adjustments only"),("Consolidation","Group consolidation ledger, kept for the group parent")]),
 "Journal Source": ("XBRL GL / Internal", [("Manual",""),("Accounts Payable","19 Payable Invoice and Supplier Payment"),("Accounts Receivable","19 Receivable Item and Cash Receipt Application"),("Client Revenue & Profitability","10: fee and client revenue, cash program economics, waivers and reimbursements, cost items, accruals, contract cost assets, allocation, intercompany charges"),("Incentive Compensation","Incentive compensation accruals from 03 Compensation Statements and 20 Payroll Results"),("Payroll","20 payroll runs, posted in summary"),("Fixed Assets",""),("Treasury / Bank",""),("Consolidation",""),("Tax Provision",""),("Spreadsheet Upload",""),("Lease Accounting","Postings of 44 Lease Accounting Measurement and lease payments (CD-279, Stage 4)"),("Travel & Expense","Postings of 44 Expense Reports (CD-280, Stage 4)")]),
 "Journal Status": ("Internal", [("Draft",""),("Pending Approval",""),("Approved",""),("Posted",""),("Rejected",""),("Reversed","")]),
 "Balance Type": ("Oracle Fusion GL / SAP S/4HANA (structural cross-check)", [("Actual",""),("Adjusted","Actual plus period-end adjustments"),("Translated","Reporting currency"),("Consolidated","After eliminations"),("Encumbrance","Committed spend, where used")]),
 "Close Task Status": ("Internal", [("Not Started",""),("In Progress",""),("Completed",""),("Reviewed",""),("Blocked",""),("Not Applicable","")]),
 "Consolidation Method": ("ASC 810 / ASC 323", [("Full Consolidation",""),("Equity Method",""),("Proportionate Consolidation","Joint operations"),("Fair Value - Not Consolidated","Investment entity or fair value option"),("Out of Scope","")]),
 "Control Assessment Basis": ("ASC 810 / ASC 946", [("Voting Interest Entity - Majority",""),("VIE - Primary Beneficiary","ASC 810 variable interest model"),("VIE - Not Primary Beneficiary",""),("Significant Influence",""),("Investment Entity Exception","ASC 946 investment company: investees held at fair value, not consolidated")]),
 "Payable Document Type": ("OECD SAF-T / Internal", [("Invoice",""),("Credit Note","Reduces the amount owed"),("Prepayment Request","Advance payment before the service is delivered")]),
 "Payment Method": ("ISO 20022 (pain.001 payment method / type) / Internal", [("ACH Credit",""),("Wire Transfer",""),("Check",""),("Corporate Card",""),("Netting","Intercompany netting")]),
 "Indirect Tax Recoverability": ("Internal (state sales and use tax; SSUTA)", [("Irrecoverable","Tax paid is a cost of the purchase (US sales tax)"),("Use Tax - Self-Assessed","The supplier charged no sales tax; the firm accrues and remits use tax"),("Exempt Purchase","An exemption or resale certificate applies"),("Fully Recoverable","Foreign indirect tax reclaimable by refund claim")]),
 "Receivable Source Type": ("Internal", [("Fee Invoice","47 BIL-"),("Fund Fee Receivable","10 FRR-; fee payable by a fund the firm manages (Debtor Fund Product)"),("Intercompany Charge","10 ICC-"),("Sublease",""),("Other","")]),
 "Receivable Status": ("Internal", [("Open",""),("Partially Paid",""),("Cleared",""),("In Dispute",""),("Written Off",""),("Credited","")]),
 "Financial Statement Type": ("SEC Regulation S-X", [("Balance Sheet","Statement of financial position"),("Income Statement","Statement of operations / profit or loss"),("Statement of Comprehensive Income",""),("Statement of Cash Flows",""),("Statement of Changes in Equity",""),("Notes","")]),
 "Regulatory Return Type": ("SEC / FINRA / OCC (confirm per entity)", [("FOCUS Report Part II","SEC Form X-17A-5; carrying or clearing broker-dealers, the return of the self-clearing broker-dealer"),("FOCUS Report Part IIA","Other broker-dealers, e.g. a fund distributor that does not carry customer accounts"),("Broker-Dealer Annual Report","SEC Rule 17a-5 annual audited report"),("Form ADV Financial Information","Form ADV Part 2A Item 18 (the financial item: balance sheet where the adviser requires prepayment of more than USD 1,200 six or more months in advance; financial condition disclosure where it has discretion or custody); Part 1A Item 5.F regulatory assets under management is a reported amount, not a financial return (confirm)"),("Bank Call Report","FFIEC, for the optional national trust company (confirm)")]),
 "Return Filing Status": ("Internal", [("Not Started",""),("In Preparation",""),("Under Review",""),("Filed",""),("Accepted",""),("Rejected",""),("Amended",""),("Extended","Extension granted")]),
 "Plan Type": ("Internal (aligned to 10 Plan Type)", [("Annual Budget",""),("Rolling Forecast",""),("Long-Range Plan",""),("Scenario","Off-cycle scenario plan; the scenario itself is Plan Scenario")]),
 "Plan Scenario": ("Internal (aligned to 10 Scenario)", [("Base",""),("Upside",""),("Downside",""),("Market Stress",""),("Capital and Liquidity Stress","Added in 19: e.g. broker-dealer net capital and liquidity stress testing")]),
 "Plan Version Status": ("Internal (aligned to 10 Plan Version Status)", [("Draft",""),("Submitted",""),("Approved",""),("Locked",""),("Superseded","Added in 19")]),
 "Tax Type": ("OECD SAF-T / Internal", [("Corporate Income Tax",""),("US State Income / Franchise Tax",""),("Sales and Use Tax","State and local sales and use tax"),("Withholding Tax","Includes FATCA (chapter 4) registrations, e.g. GIIN"),("Payroll Tax","Employer filings; payroll detail is 20"),("Pillar Two Top-Up Tax","GloBE / QDMTT")]),
 "Provision Component": ("ASC 740", [("Expense - Current Tax",""),("Expense - Deferred Tax",""),("Expense - Pillar Two Top-Up Tax",""),("Balance - Deferred Tax Asset",""),("Balance - Deferred Tax Liability",""),("Balance - Valuation Allowance",""),("Balance - Uncertain Tax Position Liability","ASC 740-10")]),
 "TP Documentation Type": ("OECD Transfer Pricing Guidelines (Chapter V)", [("Master File","Group level"),("Local File","Entity level"),("Country-by-Country Report","Group level; IRS Form 8975 / OECD CbCR XML"),("Benchmarking Study",""),("Intercompany Agreement Memo","")]),
}

# ---------------------------------------------------------------------------
REL = [
 ("Chart of Accounts","contains","GL Account","1 : 1..n","Natural accounts, keyed GLA-."),
 ("Chart of Accounts","contains","Chart Segment Value","1 : 1..n","Company, cost center, profit center, product, channel, intercompany values (never natural accounts)."),
 ("Chart Segment Value (Company)","represents","Internal Legal Entity [09]","n : 1","LEN-; the Company value code is the accounting company code, mastered once here. 09 Internal Legal Entity.Accounting Company Code becomes a derived copy (CD-152)."),
 ("Chart Segment Value (Cost / Profit Center)","represents","Org Unit [09]","n : 0..1","OU-CC-; 09 Cost & Profit Center codes become references to 19 (CD-152, amends CD-084)."),
 ("Ledger","is kept for","Internal Legal Entity [09]","n : 1","One ledger per entity x accounting basis x ledger currency x ledger role."),
 ("Ledger","uses","Chart of Accounts","n : 1",""),
 ("Ledger","uses","Fiscal Calendar [09]","n : 1","CAL-; periods stay in 09."),
 ("GL Account","is mapped by","Financial Statement Line Mapping","1 : 0..n","Effective-dated."),
 ("Financial Statement Line Mapping","maps to","Financial Statement Line","n : 1","Line belongs to one reporting framework."),
 ("GL Account","is mapped from","Account Mapping [10]","1 : 0..n","10 keeps Management P&L Line -> GL Account (ACM-, narrowed)."),
 ("Journal Entry","posts to","Ledger","n : 1",""),
 ("Journal Entry","has","GL Posting","1 : 1..n","Grain journal x line (moved from 10)."),
 ("GL Posting","posts to","GL Account","n : 1",""),
 ("GL Posting","is coded to","Chart Segment Value","n : 1..n","Cost center and other segments."),
 ("GL Posting","is sourced from","Fee Revenue Record / Client Revenue Record / Cash Program Economics / Waiver Record / Distribution Cost Item / Accrual / Contract Cost Asset / Allocation Run / Intercompany Charge [10]","n : 0..1","Source Finance Record."),
 ("GL Posting","is sourced from","Payable Invoice / Supplier Payment / Receivable Item","n : 0..1","Source Payable Invoice, Source Supplier Payment, Source Receivable Item."),
 ("GL Posting","summarizes","Payroll Run [20, proposed]","n : 0..1","Payroll posts in summary: one run produces many summary lines; Payroll Result rows (employee x run) roll up to the run in 20 and are never referenced here."),
 ("Journal Entry","is prepared and approved by","Employee [20]","n : 0..1","Preparer and approver must differ (SOX 404)."),
 ("GL Account Balance","summarizes","GL Posting","1 : 0..n","Ledger x account combination x fiscal period x balance type x balance currency."),
 ("Accounting Period Status","applies to","Ledger x Fiscal Period [09]","1 : 1","Moved from 10; 09 Fiscal Period Status becomes a derived copy for the group primary ledger."),
 ("Close Task","belongs to","Close cycle (Fiscal Period [09]) and Ledger","n : 1",""),
 ("Consolidation Scope Entity","places","Internal Legal Entity [09] / Product (consolidated fund) [01] / Portfolio (seed) [18]","n : 1","Exactly one consolidated unit per row; ownership links come from 09 Entity Ownership Relationship."),
 ("Intercompany Balance","is between","Internal Legal Entity [09] (two)","n : 2",""),
 ("Intercompany Balance","is eliminated by","Journal Entry","n : 0..1",""),
 ("Intercompany Balance","may arise from","Intercompany Charge [10]","n : 0..1",""),
 ("Payable Invoice","is issued by","Party (Supplier) [02]","n : 1",""),
 ("Payable Invoice","has","Payable Invoice Line","1 : 1..n",""),
 ("Payable Invoice Line","has","Indirect Tax Detail","1 : 0..n",""),
 ("Payable Invoice","records","Data Invoice [14] / Intermediary Communication Fee Invoice [05] / Partner Invoice [05]","1 : 0..1","Links held on the 19 record only (CD-158); domain invoices keep their detail."),
 ("Supplier Payment","is applied through","Supplier Payment Application","1 : 1..n",""),
 ("Supplier Payment Application","settles","Payable Invoice","n : 1","Partial payments and one payment for many invoices."),
 ("Supplier Payment","executes","Partner Payment [05]","1 : 0..1","PMT- keeps the calculation and partner detail."),
 ("Receivable Item","is owed by","Party (Customer) [02] / Product (fund debtor) [01]","n : 1",""),
 ("Receivable Item","records","Fee Invoice [47] / Fee Revenue Record [10] / Intercompany Charge [10]","1 : 0..1","Links held on the 19 record only (CD-158)."),
 ("Cash Receipt Application","clears","Receivable Item","n : 1",""),
 ("Financial Statement","has","Financial Statement Line Value","1 : 1..n",""),
 ("Financial Statement Line Value","is reported on","Financial Statement Line","n : 1","Caption and XBRL element come from the line; GL accounts reach it through the mapping."),
 ("Regulatory Financial Return","is filed by","Internal Legal Entity [09]","n : 1","Entity authorizations stay in 09."),
 ("Financial Plan Version","has","Financial Plan Line","1 : 1..n",""),
 ("Plan Version [10]","rolls up into","Financial Plan Version","n : 0..1","Link held on 10 BUD- (proposed attribute Enterprise Financial Plan Version)."),
 ("Tax Return","is filed by","Internal Legal Entity [09]","n : 1","Tax authority is a Party [02]."),
 ("Transfer Pricing Documentation","documents","Internal Legal Entity [09] (entity or group parent)","n : 1","Own Business Object: entity or group x fiscal year x document type."),
 ("Transfer Pricing Documentation","is referenced by","TP Policy [10] (Intercompany Agreement)","1 : 0..n","10 TP Policy.TP Documentation Reference holds the link; Covered Intercompany Agreements is a Derived copy (10 review ruling 5)."),
 ("Tax Provision","is booked by","Journal Entry","n : 0..1",""),
]

# ---------------------------------------------------------------------------
SRC = [
 ("FASB Accounting Standards Codification (ASC 105, 250, 326, 606, 740, 810, 830)","FASB","https://asc.fasb.org","Licensed (basic view free)","Revenue, credit losses, income tax provision and uncertain positions, consolidation (voting interest and VIE models, ASC 946 investment companies), foreign currency (functional currency, translation, remeasurement), accounting changes, financial statement presentation","GL Account, Consolidation Scope Entity, Tax Provision, Receivable Item, Ledger",["ASC*"]),
 ("US GAAP Financial Reporting Taxonomy (XBRL)","FASB","https://www.fasb.org/xbrl","Open","Statement elements, line captions, disaggregation of revenue tagging","Financial Statement Line, Financial Statement Class",["US GAAP Taxonomy"]),
 ("SEC Regulation S-X (form and content of financial statements)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-210","Regulation","Required statements and captions","Financial Statement, Financial Statement Type",["SEC Regulation S-X"]),
 ("XBRL Global Ledger Taxonomy Framework (XBRL GL) 2015 Recommendation","XBRL International","https://www.xbrl.org/int/gl/2015-03-25/gl-framework-REC-2015-03-25.html","Open","Account, journal header and line, debit/credit, source document and subledger concepts","Chart of Accounts, GL Account, Journal Entry, GL Posting, GL Account Balance",["XBRL GL"]),
 ("OECD Guidance for the Standard Audit File - Tax (SAF-T), Version 2.0 (April 2010)","OECD Forum on Tax Administration","https://web-archive-storage.oecd.org/aemint-web-archive-prod/web-archive/31/319f3ea18d49a9a849ac736cc1cb6b6325080f23fcee60705509cf6b00a8af4e.pdf","Open guidance","Master files (accounts, customers, suppliers, tax table), general ledger entries, source documents (invoices, payments)","GL Account, Journal Entry, GL Posting, Payable Invoice, Receivable Item, Entity Tax Registration",["OECD SAF-T"]),
 ("ISO 20022 message definitions: pain.001 (Customer Credit Transfer Initiation), camt.053 (Bank to Customer Statement), camt.054 (Debit/Credit Notification)","ISO / SWIFT","https://www.iso20022.org/iso-20022-message-definitions","Open standard","Payment method, value date, bank statement entries for cash application","Supplier Payment, Cash Receipt Application",["ISO 20022"]),
 ("SEC Rule 17a-5 (FOCUS Report, Form X-17A-5) and FINRA eFOCUS","US SEC; FINRA","https://www.finra.org/filing-reporting/focus","Regulation / SRO filing","Broker-dealer financial and operational returns, Part II and Part IIA, annual reports","Regulatory Financial Return, Regulatory Return Type",["SEC Rule 17a-5"]),
 ("SEC Rule 15c3-1 (net capital)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.15c3-1","Regulation","Net capital requirement and resources reported on FOCUS","Regulatory Financial Return (capital amounts)",["SEC Rule 15c3-1"]),
 ("OECD Transfer Pricing Guidelines for Multinational Enterprises and Tax Administrations (2022), Chapter V documentation","OECD","https://doi.org/10.1787/0e655865-en","Open guidance","Master file, local file and country-by-country report","Transfer Pricing Documentation, TP Documentation Type",["OECD TPG"]),
 ("OECD Pillar Two Global Anti-Base Erosion (GloBE) Model Rules and GloBE Information Return","OECD","https://www.oecd.org/en/topics/sub-issues/global-minimum-tax.html","Open guidance","Top-up tax as a tax type and provision component","Tax Type, Provision Component, Tax Return",["OECD Pillar Two"]),
 ("IRS Form 1120 (US corporation income tax return) and Form 8975 (Country-by-Country Report); IRC Section 6662(e)","US IRS","https://www.irs.gov/forms-pubs/about-form-1120","Regulation / forms","Corporate income tax return, CbC report, contemporaneous transfer pricing documentation for penalty protection","Tax Return, Transfer Pricing Documentation",["IRS Form 1120", "IRS Form 8975", "IRC Section 6662", "IRS"]),
 ("Streamlined Sales and Use Tax Agreement (SSUTA) and state sales and use tax laws","Streamlined Sales Tax Governing Board; US states","https://www.streamlinedsalestax.org (confirm)","Multistate agreement / state statutes","Sales and use tax on purchases and sales, use tax self-assessment, exemption certificates; sourcing rules","Indirect Tax Detail, Indirect Tax Recoverability, Receivable Item",["SSUTA", "State sales and use tax law"]),
 ("SEC Form ADV (Uniform Application for Investment Adviser Registration), Part 1A Item 5.F and Part 2A Item 18","US SEC","https://www.sec.gov/about/forms/formadv.pdf (confirm)","Regulatory form","Regulatory assets under management; financial condition disclosure and balance sheet of an adviser that requires prepayment or has custody","Regulatory Financial Return, Regulatory Return Type",["SEC Form ADV"]),
 ("Sarbanes-Oxley Act Section 404, SEC management report on ICFR, PCAOB AS 2201 and the COSO Internal Control - Integrated Framework (2013)","US SEC; PCAOB; COSO","https://pcaobus.org/oversight/standards/auditing-standards/details/AS2201","Statute / auditing standard","Journal preparation and approval (segregation of duties), period-end close controls, account reconciliations","Journal Entry, Accounting Period Status, Close Task, GL Account",["SOX 404", "PCAOB AS 2201", "COSO"]),
 ("SAP S/4HANA Universal Journal (ACDOCA), Oracle Fusion Cloud General Ledger (chart of accounts, ledgers, balance types), Workday Financials (accounting worktags)","SAP; Oracle; Workday","https://docs.oracle.com/en/cloud/saas/financials/","Vendor documentation","Segment and worktag structures, primary / secondary / reporting-currency ledgers, company codes, control accounts; used as cross-checks only, field dictionaries not copied","Chart of Accounts, Chart Segment Value, Ledger, GL Account Balance",["SAP S/4HANA", "Oracle Fusion GL", "Workday Financials"]),
 ("ISO 4217 / ISO 3166 / ISO 8601","ISO","https://www.iso.org","Standard; code lists widely available","Currency, country and subdivision, date and time formats","Reference formats used throughout",["ISO 4217", "ISO 3166"]),
]
