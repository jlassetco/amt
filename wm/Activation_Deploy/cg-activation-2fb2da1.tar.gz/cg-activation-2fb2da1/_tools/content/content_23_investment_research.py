"""Data Domain 23 - Investment Research. Content module for taxonomy_builder.py."""

META = {
 "title": "Investment Research Data Taxonomy",
 "subtitle": "Business domain 23 - Investment Research | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "23_Investment_Research/Investment_Research_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the buy-side investment research record of the investment management arm of a US direct wealth manager, which manages its proprietary mutual funds (including money market funds), ETFs and CITs, the model portfolios behind its digital and human advice, and institutional separate accounts (CW-004 lines PF, DA, HA and IA); a fund run by an external sub-adviser relies on the sub-adviser's research, which is not mastered here. It defines what the equity, credit, quantitative and macro research teams produce and keep as the basis for investment decisions: who covers which issuer, instrument, sector, country or rates market, and which names sit on focus and coverage lists; what the analyst recommends, on which firm scale, with what price target, conviction and valuation basis, and how that view has changed; the internal credit rating and outlook on an issuer, trading counterparty or instrument, including the Rule 2a-7 minimal credit risk determination for money market funds; analyst estimates of issuer metrics, research models, economic forecasts and quantitative signal definitions and scores; the research notes the teams publish and their subjects; meetings with issuer management, who attended and whether they were wall-crossed, what was discussed and whether material nonpublic information (MNPI) may have been received; and the third-party research the firm subscribes to, consumes and evaluates (the broker vote). It is stewarded by the research function (Director of Research, research operations), which is why it sits apart from market intelligence for distribution (11), client-facing commentary (01) and advisor activity (03). Stitched together from SEC guidance on Exchange Act Section 28(e) (Release 34-54165), SEC Rule 2a-7, Advisers Act Section 204A and Rule 204A-1, FINRA Rule 3110(d) (insider trading review at the affiliated broker-dealer), the CFA Institute Asset Manager Code, FINRA Rule 2241 (as a sell-side reference point) and FIBO, cross-checked against the structure of research management platforms (FactSet RMS, Bipsync) and estimate aggregators (Visible Alpha, Bloomberg BEst). Use it as a starting point for a research management data model, a research data product for portfolio managers, or a business glossary."),
  ("Scope", "In scope: research coverage assignments (analyst x issuer, instrument, sector, country or rates market x role, effective-dated) and research universes with their members; research recommendations on issuers, instruments, sectors, countries and rates markets (rating on a versioned firm scale, change type, conviction, price target, fair value estimate, horizon) with their valuation basis; internal credit assessments of issuers, trading counterparties and instruments (internal credit rating, outlook, expected recovery, Rule 2a-7 minimal credit risk and first tier determinations); analyst estimates by metric and fiscal period, research models, economic forecasts, quantitative signal definitions and persisted signal scores; research publications (initiations, updates, flash, sector, thematic, macro and credit notes), their subjects and their supervisory review and external release; issuer meetings with participants (including per-person wall crossing), topics and an MNPI flag with its compliance escalation reference; research provider profiles, research service subscriptions, research consumption records (reads, analyst calls, expert network calls) and research evaluation rounds (the broker vote) with their criterion scores. Out of scope (referenced by ID): issuers, research providers, expert networks, corporate access brokers and issuer executives (parties in 02 Client & Household); instruments, issuer profiles, issuer sector classifications and agency credit ratings (17 Instrument & Issuer Reference); classification schemes, geographic units and research teams as org units (09 Shared & Enterprise Reference Data); strategies and client-facing commentary (01 Investment Product & Service Offering); content assets (04 Marketing, Digital & Client Engagement); licensed datasets and data license agreements (14 Third-Party Data & Licensing); employees (20 Human Capital); AI use cases (21 Data Governance & Analytics); approved prices (22 Market Data & Pricing); house views, investment committee decisions and investment decisions (24 Portfolio Management & Construction); research budgets, research payment accounts, payment routes, commission sharing arrangements and research payments (25 Portfolio Trading & Execution); and, in later stages, stewardship engagements (34), model inventory (37) and the MNPI compliance determination, cleansing, restricted list, watch list and insider lists (38)."),
  ("Structure", "Four levels: L1 Data Domain > L2 Data Family > L3 Data Business Object > L4 Data Business Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Research Coverage Assignment (RCOV-) says which analyst (EMP-, 20) covers which subject: an issuer (PTY-, 02, with its 17 Issuer Profile), an instrument (INS-, 17), a sector node of a 09 classification scheme (ICS-), or a country or rates market (GEO-, 09), in which research coverage role and for which period. Research Universes group subjects into focus, coverage and approved research lists through effective-dated Research Universe Members. A Research Recommendation (RREC-) is one timestamped rating on the same range of subjects on a versioned firm scale with price target, fair value estimate, conviction and horizon, linked to the recommendation it supersedes, the coverage it was made under and the publication that announced it; its Recommendation Valuation Basis holds the method, assumptions and the price at recommendation (a Derived copy of the 22 Approved Price for the firm's primary pricing point and the recommendation date). Internal Credit Assessments hold the firm's own credit view of an issuer, trading counterparty or instrument (read by 25 Counterparty Review), including the Rule 2a-7 minimal credit risk determination; agency ratings remain 17 Credit Rating Assignments. Analyst Estimates, Research Models, Economic Forecasts, Research Signal Definitions and Research Signal Scores are the quantitative research record. A Research Publication (RPUB-) has Publication Subjects and a Publication Review that records supervisory sign-off and any external release as a 01 commentary (CMT-) or 04 content asset (AST-). An Issuer Meeting (IMTG-) has Participants (internal participants carry their wall crossing), Topics and one Meeting MNPI Assessment (the MNPI flag and escalation reference). Research Provider Profiles (keyed by PTY-) carry Research Service Subscriptions, Research Consumption Records and Research Evaluation Rounds (provider x period x evaluator, with Evaluation Criterion Scores), which 25 Research Payment reads. A recommendation informs any number of 24 Investment Decisions (IDEC-), each holding one reference to it; 34 and 38 will reference IMTG-."),
  ("Design principles", "1) Input, not decision: a recommendation never instructs a portfolio; there are no target weights, orders or limits here (24, 25, 33). 2) Qualified names: 'Research Recommendation' and 'Internal Credit Rating', never 'Rating' bare; 'Research Coverage', never 'Coverage' bare; 'Research Model', which is not the 37 model inventory or the 01 Model Portfolio. 3) One place per fact: the current research recommendation is the latest Research Recommendation row per subject, rating scale and recommending analyst, and the research team's view is that of the Primary Analyst; it is not a column on the coverage assignment, and the house view is 24's; the link from a recommendation to its announcing publication is held once, on the recommendation; issuer facts (type, country of risk, sector) are read from 17 and never copied onto coverage. 4) Everything is dated: coverage, universe membership, recommendations, credit assessments, estimates, forecasts and scores all carry an effective date, timestamp or as-of date, so the view an analyst held on any day can be reconstructed. 5) MNPI is flagged, not controlled: 23 records that MNPI may have been received, under which compliance escalation, and when each person was wall-crossed; the compliance determination, cleansing and the restricted, watch and insider lists are 38. 6) Valuation, not payment: 23 masters the evaluation of research providers; budgets, research payment accounts, payment routes, commission sharing and payments are 25. 7) Personal data: issuer executives, expert network contacts and sell-side analysts are individuals in 02 and are personal data where named; employee references carry the PII note. 8) Flag Critical Data Elements (CDE)."),
  ("Applies To", "Shows the record each attribute belongs to: Coverage Assignment, Research Universe, Universe Member, Recommendation, Credit Assessment, Estimate, Research Model, Economic Forecast, Signal Definition, Signal Score, Publication, Publication Subject, Issuer Meeting, Meeting Participant, Meeting Topic, Provider Profile, Service Subscription, Research Consumption, Evaluation Round or Criterion Score."),
  ("CDE", "Y = proposed Critical Data Element: needed to know who covers a subject, what the firm's current research view and internal credit rating of an issuer or instrument is and when it was formed, evidence the basis of a recommendation that an investment decision relied on, support the money market fund minimal credit risk record, detect and escalate possible MNPI from issuer contact, or evidence the research quality assessment behind the Section 28(e) good-faith determination. Confirm with the Director of Research, Head of Credit Research, Investment Compliance and the money market fund board's delegate."),
  ("Primary / Secondary Reference", "Standard, rule or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Vendor references (FactSet RMS, Bipsync, Visible Alpha, Bloomberg BEst) indicate common industry structure only, not a license to reproduce vendor record layouts. Next step: map each attribute to the research management platform of record and the OMS or portfolio construction tools that consume it."),
  ("Notes", "PII = personal information under US privacy law (state consumer privacy laws such as the CCPA as amended by the CPRA; Regulation S-P where the individual is also a client of the firm): named issuer executives, sell-side analysts and expert network contacts (individuals held in 02), and employee references (internal staff). Meeting notes and topic summaries may contain material nonpublic information and are classified with the enterprise Information Classification list (Restricted - MNPI where applicable). Research recommendations and internal credit ratings are confidential firm views and are not released externally except through a reviewed publication."),
  ("Tabs", "Hierarchy: Data Families, Object Groups and Data Business Objects with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: object-level cardinalities for the logical model, including references to other Data Domains | Sources: standards, rules and vendor models used, with owners, licenses and links."),
  ("Suggested next steps", "1) Validate families, rating scales, change types and CDEs with the Director of Research, Head of Credit Research, quantitative research, economics and Investment Compliance. 2) Name the research system of record (research management platform, OMS notes or shared drives) and whether equity, credit and quant use one system. 3) Agree with the money market fund board's delegate how Rule 2a-7 minimal credit risk determinations are recorded, approved and retained, and with 33 whether internal credit ratings feed compliance limits. 4) Agree with 24 that house views are 24 Investment Committee Decisions informed by 23 forecasts and recommendations, and that 24 adopts the RREC- key format. 5) Agree with 25 the research payment routes per fund and account (the adviser's own resources, or client commissions within the Section 28(e) safe harbor, including commission sharing arrangements) and that 25 Research Payment references the Research Evaluation Round and holds the payment route. 6) Agree with Compliance how MNPI from issuer meetings is escalated today and what 38 will need from the MNPI flag, escalation reference and participant wall crossings. 7) Agree with 34 (stewardship) who writes ESG assessments and how engagements reference issuer meetings. 8) Harmonize Record Status, Approval Status, Period Type, Sentiment and Information Classification with the enterprise shared lists (09), and Credit Outlook with 17. 9) Turn the Relationships tab into a logical research data model shared with 17, 22, 24 and 25."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
ISSUER_ROW = "Row Ownership Rule: on rows with an instrument, derived from the issuer of the 17 Instrument; entered here otherwise."

D("Research Coverage", "RS-COV",
  "Who covers what: effective-dated assignments of analysts to issuers, instruments, sectors, countries and rates markets, and the research universes (focus lists, coverage lists, approved research lists) that group research subjects. Issuer type, country of risk and sector are read from 17, never copied here.",
  [
   ("Coverage Assignments", "Effective-dated assignment of an analyst to a research subject in a research coverage role.", [
     ("Research Coverage Assignment", [
       ("Research Coverage Assignment ID", "Unique identifier of the coverage assignment.", "Coverage Assignment", "Identifier", "", "RCOV-000412", "Internal", "FactSet RMS", "Y"),
       ("Covering Analyst", "Analyst assigned to cover the subject.", "Coverage Assignment", "Reference (Employee)", "", "EMP-30412", "Internal", "", "Y", "PII (employee)."),
       ("Research Subject Type", "Kind of subject covered, which determines which subject attribute is filled.", "Coverage Assignment", "Code", "Research Subject Type", "Issuer", "Internal", "", ""),
       ("Covered Issuer", "Issuer covered, when the subject is an issuer; issuer facts come from the 17 Issuer Profile.", "Coverage Assignment", "Reference (Party)", "", "PTY-7001234", "Internal", "FIBO BE", "Y"),
       ("Covered Instrument", "Instrument covered, when coverage is of one security rather than the whole issuer (for example a single bond or a convertible).", "Coverage Assignment", "Reference (Instrument, 17)", "", "INS-00733120", "Internal", "FIBO SEC", ""),
       ("Covered Sector Scheme", "Registered classification scheme version of the covered sector, when the subject is a sector.", "Coverage Assignment", "Reference (Classification Scheme)", "", "ICS-GICS-2023", "GICS", "", ""),
       ("Covered Sector Code", "Node of the classification scheme covered, when the subject is a sector.", "Coverage Assignment", "Code", "External (code of the scheme named)", "4520", "GICS", "", "Y"),
       ("Covered Geography", "Country or region covered, when the subject is a country or a rates market (sovereign, rates and macro coverage).", "Coverage Assignment", "Reference (Geographic Unit)", "", "GEO-DE", "ISO 3166", "", "Y"),
       ("Research Coverage Role", "Role the analyst plays on the subject.", "Coverage Assignment", "Code", "Research Coverage Role", "Primary Analyst", "Internal", "", "Y"),
       ("Covering Research Team", "Research team (equity, credit, quantitative or macro team) under which the coverage is held.", "Coverage Assignment", "Reference (Org Unit)", "", "OU-RES-CR-IG", "Internal", "", ""),
       ("Served Investment Strategy", "Investment strategy the coverage chiefly serves, where coverage is dedicated to one strategy.", "Coverage Assignment", "Reference (Investment Strategy)", "", "STR-00031", "Internal", "", ""),
       ("Coverage Effective From", "Date the analyst took up coverage in this role.", "Coverage Assignment", "Date", "ISO 8601", "2025-02-03", "Internal", "", "Y"),
       ("Coverage Effective To", "Date the analyst stopped covering the subject in this role.", "Coverage Assignment", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Research Universes", "Named lists of research subjects (focus lists, coverage lists, approved research lists, signal universes) and their effective-dated members.", [
     ("Research Universe", [
       ("Research Universe Code", "Unique code of the research universe.", "Research Universe", "Identifier", "", "USLC_FOCUS", "Internal", "", ""),
       ("Research Universe Name", "Business name of the universe.", "Research Universe", "Text", "", "US Large Cap Equity Focus List", "Internal", "", ""),
       ("Research Universe Type", "Purpose the universe serves.", "Research Universe", "Code", "Research Universe Type", "Focus List", "Internal", "", ""),
       ("Universe Owner", "Research lead accountable for the universe's membership.", "Research Universe", "Reference (Employee)", "", "EMP-30155", "Internal", "", "", "PII (employee)."),
       ("Research Universe Status", "Whether the universe is in use.", "Research Universe", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
     ]),
     ("Research Universe Member", [
       ("Member Universe", "Universe the subject belongs to.", "Universe Member", "Reference (Research Universe, 23)", "", "USLC_FOCUS", "Internal", "", "Y"),
       ("Member Subject Type", "Kind of subject admitted to the universe (issuer, instrument, sector, country or rates market).", "Universe Member", "Code", "Research Subject Type", "Issuer", "Internal", "", ""),
       ("Member Issuer", "Issuer admitted, when the member is an issuer.", "Universe Member", "Reference (Party)", "", "PTY-7001234", "Internal", "", "Y"),
       ("Member Instrument", "Instrument admitted, when the member is a single security.", "Universe Member", "Reference (Instrument, 17)", "", "", "Internal", "", ""),
       ("Member Sector Scheme", "Registered classification scheme version of the member sector, when the member is a sector.", "Universe Member", "Reference (Classification Scheme)", "", "ICS-GICS-2023", "Internal", "", ""),
       ("Member Sector Code", "Node of the classification scheme admitted, when the member is a sector.", "Universe Member", "Code", "External (code of the scheme named)", "", "Internal", "", ""),
       ("Member Geography", "Country or region admitted, when the member is a country or a rates market.", "Universe Member", "Reference (Geographic Unit)", "", "", "Internal", "", ""),
       ("Member Market Segment", "Segment of a rates market admitted, when the member is a rates market.", "Universe Member", "Text", "", "", "Internal", "", ""),
       ("Inclusion Reason", "Why the subject was admitted to the universe.", "Universe Member", "Text", "", "Upgraded to Buy with high conviction after initiation", "Internal", "", ""),
       ("Membership Effective From", "Date the subject joined the universe.", "Universe Member", "Date", "ISO 8601", "2026-03-02", "Internal", "", ""),
       ("Membership Effective To", "Date the subject left the universe.", "Universe Member", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Recommendations & Credit Views", "RS-REC",
  "The analyst's view of a subject: research recommendations on a versioned firm scale with price target, fair value estimate, conviction and horizon, the valuation basis behind each one, and internal credit assessments of issuers and trading counterparties, including Rule 2a-7 minimal credit risk determinations. Agency credit ratings are 17 Credit Rating Assignments; house views and investment decisions that rely on a recommendation are 24.",
  [
   ("Research Recommendations", "Timestamped analyst recommendations. The current research recommendation is the latest row per subject, rating scale and recommending analyst; the research team's view is the current recommendation of the analyst whose coverage role is Primary Analyst. The firm's house view is a 24 Investment Committee Decision, not a 23 record.", [
     ("Research Recommendation", [
       ("Research Recommendation ID", "Unique identifier of the recommendation (RREC- plus seven digits).", "Recommendation", "Identifier", "", "RREC-0091377", "Internal", "FactSet RMS", "Y"),
       ("Recommending Analyst", "Analyst who made the recommendation.", "Recommendation", "Reference (Employee)", "", "EMP-30412", "Internal", "", "Y", "PII (employee)."),
       ("Recommendation Subject Type", "Kind of subject the recommendation is on, which determines which subject attribute is filled.", "Recommendation", "Code", "Research Subject Type", "Issuer", "Internal", "", ""),
       ("Recommended Issuer", "Issuer the recommendation is on, for issuer and instrument recommendations; for an instrument recommendation it is the instrument's issuer.", "Recommendation", "Reference (Party)", "", "PTY-7001234", "Internal", "", "Y", ISSUER_ROW),
       ("Recommended Instrument", "Instrument the recommendation is on, when it applies to one security (for example the primary listed share or a specific bond).", "Recommendation", "Reference (Instrument, 17)", "", "INS-00412873", "Internal", "", ""),
       ("Recommended Sector Scheme", "Registered classification scheme version of the sector, when the recommendation is on a sector.", "Recommendation", "Reference (Classification Scheme)", "", "ICS-GICS-2023", "Internal", "", ""),
       ("Recommended Sector Code", "Node of the classification scheme, when the recommendation is on a sector.", "Recommendation", "Code", "External (code of the scheme named)", "", "Internal", "", ""),
       ("Recommended Geography", "Country or region, when the recommendation is on a country or a rates market.", "Recommendation", "Reference (Geographic Unit)", "", "", "Internal", "", ""),
       ("Recommended Market Segment", "Segment of the rates market (for example a curve sector), when the recommendation is on a rates market.", "Recommendation", "Text", "", "", "Internal", "", ""),
       ("Source Coverage Assignment", "Coverage assignment under which the recommendation was made.", "Recommendation", "Reference (Research Coverage Assignment, 23)", "", "RCOV-000412", "Internal", "", ""),
       ("Recommendation Rating Scale", "Versioned firm scale the rating is expressed on.", "Recommendation", "Code", "Recommendation Rating Scale", "Firm Equity Five-Point Scale v2", "Internal", "FINRA Rule 2241", ""),
       ("Recommendation Rating", "Rating on the firm scale.", "Recommendation", "Code", "Recommendation Rating", "Buy", "Internal", "FINRA Rule 2241", "Y"),
       ("Recommendation Change Type", "How this recommendation relates to the same analyst's previous recommendation on the same subject and scale, or to the previous analyst's on a coverage transfer.", "Recommendation", "Code", "Recommendation Change Type", "Upgrade", "Internal", "FINRA Rule 2241", "Y"),
       ("Previous Recommendation", "Recommendation this one supersedes for the same subject, scale and analyst (or the previous analyst's, on a coverage transfer); blank for an initiation.", "Recommendation", "Reference (Research Recommendation, 23)", "", "RREC-0088120", "Internal", "", ""),
       ("Conviction Level", "Strength of the analyst's conviction in the recommendation.", "Recommendation", "Code", "Conviction Level", "High", "Internal", "", ""),
       ("Price Target", "Price per unit the analyst expects the instrument to reach by the end of the horizon.", "Recommendation", "Amount", "", "245.00", "FINRA Rule 2241", "", "Y"),
       ("Fair Value Estimate", "Analyst's estimate of the intrinsic value per unit today, where the scale uses fair value rather than a price target.", "Recommendation", "Amount", "", "231.50", "Internal", "", ""),
       ("Target Currency", "Currency of the price target and fair value estimate.", "Recommendation", "Code", "ISO 4217", "USD", "ISO 4217", "", ""),
       ("Recommendation Horizon Months", "Period over which the price target or view is expected to be realized, in months.", "Recommendation", "Integer", "", "12", "Internal", "", ""),
       ("Recommendation Timestamp", "Date and time the recommendation took effect in the research system.", "Recommendation", "Timestamp", "ISO 8601", "2026-09-14T13:05:00Z", "Internal", "", "Y"),
       ("Investment Thesis Summary", "Short statement of why the analyst holds the view.", "Recommendation", "Text", "", "Margin expansion from services mix not priced in", "CFA Institute Asset Manager Code", "", ""),
       ("Recommendation Approval Status", "Whether the change was approved where the research policy requires sign-off.", "Recommendation", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("Announcing Publication", "Research publication that announced the recommendation; the link is held here only, not on the publication.", "Recommendation", "Reference (Research Publication, 23)", "", "RPUB-0045512", "Internal", "", ""),
     ]),
     ("Recommendation Valuation Basis", [
       ("Valuation Method", "Primary method used to set the price target or fair value.", "Recommendation", "Code", "Valuation Method", "Discounted Cash Flow", "CFA Institute Asset Manager Code", "FINRA Rule 2241", ""),
       ("Valuation Model", "Research model the valuation was taken from.", "Recommendation", "Reference (Research Model, 23)", "", "RM_EQ_TECH_0412_DCF", "Internal", "", ""),
       ("Reference Approved Price", "22 Approved Price of the recommended instrument at the firm's primary pricing point for the recommendation date.", "Recommendation", "Reference (Approved Price, 22)", "", "PRICE-20260914-00412873-01-01", "Internal", "", ""),
       ("Price at Recommendation", "Approved price value of the recommended instrument at the firm's primary pricing point for the recommendation date, copied from the 22 Approved Price; its currency and quote basis are those of the 22 Approved Price.", "Recommendation", "Decimal", "", "212.40", "Internal", "", "", "Derived copy (22): Approved Price Value of the Reference Approved Price."),
       ("Key Assumptions", "Main assumptions the valuation depends on.", "Recommendation", "Text", "", "Services revenue +12% CAGR; terminal growth 3%", "Internal", "", ""),
       ("Key Risks", "Main risks that would invalidate the view.", "Recommendation", "Text", "", "Export restrictions on advanced equipment", "Internal", "FINRA Rule 2241", ""),
     ]),
   ]),
   ("Internal Credit Assessments", "The firm's own credit view of an issuer, a trading counterparty or an instrument, effective-dated, including the minimal credit risk determination for money market fund eligibility. The money market eligible list is a view of assessments in force with Minimal Credit Risk Indicator = Y, not a separate list.", [
     ("Internal Credit Assessment", [
       ("Assessed Party", "Party assessed: an issuer, or a trading counterparty whose credit 25 Counterparty Review reads; always filled, also for an issue-level assessment.", "Credit Assessment", "Reference (Party)", "", "PTY-7002210", "Internal", "", "Y", ISSUER_ROW),
       ("Assessed Instrument", "Instrument assessed, for an issue-level assessment; blank for a party-level assessment.", "Credit Assessment", "Reference (Instrument, 17)", "", "", "Internal", "", ""),
       ("Credit Analyst", "Credit analyst responsible for the assessment.", "Credit Assessment", "Reference (Employee)", "", "EMP-30588", "Internal", "", "Y", "PII (employee)."),
       ("Internal Credit Rating Scale", "Firm scale the internal credit rating is expressed on.", "Credit Assessment", "Code", "Internal Credit Rating Scale", "Firm Long-Term Credit Scale v3", "Internal", "", ""),
       ("Internal Credit Rating", "Firm's own credit rating of the party or instrument on the scale; the mapping to the 17 notch scale is held on the code value.", "Credit Assessment", "Code", "Internal Credit Rating", "ICR 4", "Internal", "SEC Rule 2a-7", "Y"),
       ("Internal Credit Outlook", "Analyst's view of the likely direction of the internal credit rating.", "Credit Assessment", "Code", "Shared: Credit Outlook", "Stable", "Internal", "", ""),
       ("Expected Recovery Rate", "Analyst's expected recovery on the assessed obligation in default.", "Credit Assessment", "Percentage", "", "45%", "Internal", "", ""),
       ("Minimal Credit Risk Indicator", "Whether the security or issuer is determined to present minimal credit risks for money market fund eligibility; blank when not assessed for a money market fund.", "Credit Assessment", "Boolean", "", "Y", "SEC Rule 2a-7", "", "Y", "Rule 2a-7 eligible security determination."),
       ("First Tier Determination Indicator", "Whether the issuer is determined to have the highest capacity to meet its short-term financial obligations (first tier security); blank when not assessed for a money market fund.", "Credit Assessment", "Boolean", "", "Y", "SEC Rule 2a-7", "", ""),
       ("Assessment Rationale", "Main reasons for the internal credit rating and outlook; for a money market fund determination, the analysis of financial condition, sources of liquidity, ability to react to market-wide and issuer-specific events, and strength of the issuer's industry.", "Credit Assessment", "Text", "", "Leverage reduced to 2.1x after asset sale", "Internal", "SEC Rule 2a-7", ""),
       ("Assessment Approval Status", "Whether the assessment has been approved by the credit committee or the money market fund board's delegate.", "Credit Assessment", "Code", "Shared: Approval Status", "Approved", "Internal", "SEC Rule 2a-7", ""),
       ("Assessment Approved By", "Employee who approved the assessment for the credit committee or board delegate.", "Credit Assessment", "Reference (Employee)", "", "EMP-30020", "Internal", "", "", "PII (employee)."),
       ("Assessment Effective From", "Date the assessment took effect.", "Credit Assessment", "Date", "ISO 8601", "2026-08-01", "Internal", "SEC Rule 2a-7", "Y"),
       ("Assessment Effective To", "Date the assessment was superseded or withdrawn.", "Credit Assessment", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Next Credit Review Date", "Date by which the assessment must be reviewed under the firm's credit policy.", "Credit Assessment", "Date", "ISO 8601", "2027-02-01", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Estimates, Models & Signals", "RS-EST",
  "The quantitative research record: analyst estimates of issuer metrics by fiscal period, the research models they come from, economic forecasts by the macro team, and quantitative signal definitions with their persisted scores. Research models here are analyst workbooks and quant research code; the model risk inventory is 37 and the 01 Model Portfolio is a product. House views adopted from forecasts are 24 Investment Committee Decisions.",
  [
   ("Analyst Estimates", "Analyst forecasts of issuer metrics by fiscal period, kept with the date each estimate was made.", [
     ("Analyst Estimate", [
       ("Estimated Issuer", "Issuer whose metric is estimated.", "Estimate", "Reference (Party)", "", "PTY-7001234", "Internal", "Visible Alpha", "Y"),
       ("Estimating Analyst", "Analyst who made the estimate.", "Estimate", "Reference (Employee)", "", "EMP-30412", "Internal", "", "", "PII (employee)."),
       ("Estimate Metric", "Issuer metric estimated.", "Estimate", "Code", "Estimate Metric", "Diluted EPS", "Internal", "Bloomberg BEst", "Y"),
       ("Fiscal Period Type", "Length of the issuer fiscal period estimated.", "Estimate", "Code", "Shared: Period Type", "Year", "Internal", "", ""),
       ("Fiscal Period End Date", "End date of the issuer's fiscal period estimated.", "Estimate", "Date", "ISO 8601", "2027-09-30", "Internal", "", "Y"),
       ("Estimate Value", "Estimated value of the metric, in the unit the metric defines.", "Estimate", "Decimal", "", "7.85", "Internal", "", "Y"),
       ("Estimate Currency", "Currency of the estimate, for monetary metrics.", "Estimate", "Code", "ISO 4217", "USD", "ISO 4217", "", ""),
       ("Estimate Date", "Date the analyst made this estimate; a revision is a new row.", "Estimate", "Date", "ISO 8601", "2026-09-14", "Internal", "", "Y"),
       ("Adjusted Basis Indicator", "Whether the estimate is on an adjusted (non-GAAP or non-IFRS) basis rather than the reported basis; part of the row's grain.", "Estimate", "Boolean", "", "Y", "Internal", "", ""),
       ("Source Research Model", "Research model the estimate was taken from.", "Estimate", "Reference (Research Model, 23)", "", "RM_EQ_TECH_0412_DCF", "Internal", "", ""),
     ]),
   ]),
   ("Research Models", "Versions of analyst valuation, credit and forecasting models held as research records.", [
     ("Research Model", [
       ("Research Model Key", "Unique key of the research model, stable across versions.", "Research Model", "Identifier", "", "RM_EQ_TECH_0412_DCF", "Internal", "", "Y"),
       ("Research Model Version", "Version number of the model.", "Research Model", "Integer", "", "14", "Internal", "", ""),
       ("Research Model Type", "Kind of model.", "Research Model", "Code", "Research Model Type", "Three-Statement with DCF", "Internal", "", ""),
       ("Modeled Issuer", "Issuer the model covers, where it covers one issuer; blank for sector, macro or quant models.", "Research Model", "Reference (Party)", "", "PTY-7001234", "Internal", "", ""),
       ("Model Author", "Analyst who owns the model.", "Research Model", "Reference (Employee)", "", "EMP-30412", "Internal", "", "", "PII (employee)."),
       ("Model Version Date", "Date this version was saved as the reference version.", "Research Model", "Date", "ISO 8601", "2026-09-12", "Internal", "", ""),
       ("Model Inventory Candidate Indicator", "Whether the model is used in automated decisions and must be registered in the model risk inventory (37).", "Research Model", "Boolean", "", "N", "Internal", "", ""),
       ("Research Model Status", "Whether the model version is current.", "Research Model", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
       ("Model Inventory Entry", "The 37 Model Inventory Entry registered for the model this record uses.", "Research Model", "Reference (Model Inventory Entry, 37)", "", "MODEL-0517 / 2", "SR 26-2", "", "", "Added 2026-10-14 (CD-246, GAP-37-001); blank until the model is registered (Model Inventory Candidate Indicator). Research Model Key stays the 23 key of the research record, not a copy of the 37 Model ID."),
     ]),
   ]),
   ("Economic Forecasts", "Macro team forecasts of economic indicators by economy and period, kept with the date each forecast was made.", [
     ("Economic Forecast", [
       ("Forecast Geography", "Economy or region forecast (country, euro area or other region).", "Economic Forecast", "Reference (Geographic Unit)", "", "GEO-US", "Internal", "", "Y"),
       ("Economic Indicator", "Indicator forecast.", "Economic Forecast", "Code", "Economic Indicator", "Real GDP Growth", "Internal", "", "Y"),
       ("Forecast Period Type", "Length of the period forecast.", "Economic Forecast", "Code", "Shared: Period Type", "Year", "Internal", "", ""),
       ("Forecast Period End Date", "End date of the period forecast.", "Economic Forecast", "Date", "ISO 8601", "2027-12-31", "Internal", "", ""),
       ("Forecast Value", "Forecast value of the indicator, in the unit the indicator defines.", "Economic Forecast", "Decimal", "", "1.8", "Internal", "", "Y"),
       ("Forecast Date", "Date the forecast was made; a revision is a new row.", "Economic Forecast", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
       ("Forecasting Economist", "Economist responsible for the forecast.", "Economic Forecast", "Reference (Employee)", "", "EMP-30701", "Internal", "", "", "PII (employee)."),
     ]),
   ]),
   ("Quantitative Signals", "Definitions of quantitative research signals and their persisted scores per instrument and date.", [
     ("Research Signal Definition", [
       ("Research Signal Code", "Unique code of the signal, stable across versions.", "Signal Definition", "Identifier", "", "SIG_VALUE_COMP", "Internal", "", "Y"),
       ("Research Signal Version", "Version number of the signal definition.", "Signal Definition", "Integer", "", "3", "Internal", "", ""),
       ("Research Signal Name", "Business name of the signal.", "Signal Definition", "Text", "", "Composite value", "Internal", "", ""),
       ("Signal Type", "Family of investment characteristic the signal measures.", "Signal Definition", "Code", "Signal Type", "Value", "Internal", "", ""),
       ("Signal Construction", "How the signal is calculated from its inputs, including normalization.", "Signal Definition", "Text", "", "Equal-weighted z-scores of E/P, B/P and FCF yield, sector-neutral, winsorized at +/-3", "Internal", "", ""),
       ("Primary Input Dataset", "Licensed dataset the signal mainly depends on.", "Signal Definition", "Reference (Dataset)", "", "DSET-00131", "Internal", "", ""),
       ("Signal Universe", "Research universe the signal is calculated over.", "Signal Definition", "Reference (Research Universe, 23)", "", "GLOBAL_EQ_QUANT", "Internal", "", ""),
       ("Signal Owner", "Quantitative researcher accountable for the signal.", "Signal Definition", "Reference (Employee)", "", "EMP-30811", "Internal", "", "", "PII (employee)."),
       ("Related AI Use Case", "AI use case registered for the signal, where it uses machine learning.", "Signal Definition", "Reference (AI Use Case)", "", "AIU-0042", "Internal", "", ""),
       ("Research Signal Status", "Whether the signal version is in production use.", "Signal Definition", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
       ("Signal Effective From", "Date the signal version went into production.", "Signal Definition", "Date", "ISO 8601", "2025-07-01", "Internal", "", ""),
       ("Signal Effective To", "Date the signal version was retired.", "Signal Definition", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Model Inventory Entry", "The 37 Model Inventory Entry registered for the model this record uses.", "Signal Definition", "Reference (Model Inventory Entry, 37)", "", "MODEL-0521 / 3", "SR 26-2", "", "", "Added 2026-10-14 (CD-246, GAP-37-001); blank for a signal the model risk team records as out of scope (CD-294). Research Signal Name stays the 23 business name of the signal."),
     ]),
     ("Research Signal Score", [
       ("Scored Signal", "Signal and version the score belongs to.", "Signal Score", "Reference (Research Signal Definition, 23)", "", "SIG_VALUE_COMP v3", "Internal", "", "Y"),
       ("Scored Instrument", "Instrument scored.", "Signal Score", "Reference (Instrument, 17)", "", "INS-00412873", "Internal", "", "Y"),
       ("Score As-Of Date", "Date the score applies to.", "Signal Score", "Date", "ISO 8601", "2026-10-05", "Internal", "", "Y"),
       ("Signal Score", "Value of the signal for the instrument on the date.", "Signal Score", "Decimal", "", "1.42", "Internal", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Research Publications", "RS-PUB",
  "Research notes the teams write for internal investment use (initiations, company updates, flash notes, sector, thematic, macro and credit notes), what each is about, and its supervisory review and any external release. A note released externally becomes a 01 Investment Commentary or 04 Content Asset linked to it.",
  [
   ("Publications", "Versioned research notes and their subjects.", [
     ("Research Publication", [
       ("Research Publication ID", "Unique identifier of the publication.", "Publication", "Identifier", "", "RPUB-0045512", "Internal", "FactSet RMS", "Y"),
       ("Publication Version", "Version number; a correction is a new version of the same publication.", "Publication", "Integer", "", "1", "Internal", "", ""),
       ("Publication Type", "Kind of research note.", "Publication", "Code", "Publication Type", "Company Update", "Internal", "", ""),
       ("Publication Title", "Title of the note.", "Publication", "Text", "", "Services mix drives upgrade to Buy", "Internal", "", ""),
       ("Lead Author", "Analyst who wrote the note.", "Publication", "Reference (Employee)", "", "EMP-30412", "Internal", "", "Y", "PII (employee)."),
       ("Publication Timestamp", "Date and time the note was released to its internal audience.", "Publication", "Timestamp", "ISO 8601", "2026-09-14T13:05:00Z", "Internal", "", "Y"),
       ("Publication Classification", "Information handling class of the note.", "Publication", "Code", "Shared: Information Classification", "Confidential", "Internal", "ISO/IEC 27001", ""),
       ("Document Location", "Location of the published document in the research system.", "Publication", "Text", "URI", "rms://pubs/2026/09/RPUB-0045512-v1.pdf", "Internal", "", ""),
       ("Drafting AI Use Case", "AI use case under which machine assistance was used to draft or summarize the note, if any.", "Publication", "Reference (AI Use Case)", "", "", "Internal", "", ""),
       ("Publication Record Status", "Whether this version is current, superseded by a correction or withdrawn.", "Publication", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
     ]),
     ("Publication Subject", [
       ("Subject Publication", "Publication the subject belongs to.", "Publication Subject", "Reference (Research Publication, 23)", "", "RPUB-0045512", "Internal", "", "Y"),
       ("Publication Subject Type", "Kind of subject discussed.", "Publication Subject", "Code", "Research Subject Type", "Issuer", "Internal", "", ""),
       ("Subject Issuer", "Issuer discussed, when the subject is an issuer.", "Publication Subject", "Reference (Party)", "", "PTY-7001234", "Internal", "", "Y"),
       ("Subject Instrument", "Instrument discussed, when the subject is one security.", "Publication Subject", "Reference (Instrument, 17)", "", "", "Internal", "", ""),
       ("Subject Sector Scheme", "Registered classification scheme version of the sector discussed, when the subject is a sector.", "Publication Subject", "Reference (Classification Scheme)", "", "ICS-GICS-2023", "Internal", "", ""),
       ("Subject Sector Code", "Node of the classification scheme discussed, when the subject is a sector.", "Publication Subject", "Code", "External (code of the scheme named)", "", "Internal", "", ""),
       ("Subject Geography", "Country or region discussed, when the subject is a country or a rates market.", "Publication Subject", "Reference (Geographic Unit)", "", "", "Internal", "", ""),
       ("Subject Theme", "Investment theme or rates market segment discussed, when the subject is a theme or a rates market.", "Publication Subject", "Text", "", "", "Internal", "", ""),
       ("Primary Subject Indicator", "Whether this is the main subject of the publication.", "Publication Subject", "Boolean", "", "Y", "Internal", "", ""),
     ]),
   ]),
   ("Publication Review & Release", "Supervisory review of a publication and its release outside the investment teams.", [
     ("Publication Review", [
       ("Supervisory Reviewer", "Research lead who reviewed the note before release.", "Publication", "Reference (Employee)", "", "EMP-30155", "CFA Institute Asset Manager Code", "", "", "PII (employee)."),
       ("Publication Review Status", "Outcome of the supervisory review.", "Publication", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("External Release Indicator", "Whether the note, or a version of it, has been released outside the firm.", "Publication", "Boolean", "", "N", "Internal", "", ""),
       ("External Release Date", "Date the note was released externally.", "Publication", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Released As Commentary", "Investment commentary through which the note was released to clients.", "Publication", "Reference (Investment Commentary)", "", "CMT-002231", "Internal", "", ""),
       ("Released As Content Asset", "Marketing content asset through which the note was released.", "Publication", "Reference (Content Asset)", "", "AST-098812", "Internal", "", ""),
       ("Investment Recommendation Disclosure Indicator", "Whether the released version is a research report or retail communication that needs the required disclosures applied (FINRA Rule 2241 research report disclosures, e.g. ratings distribution, price target basis and risks, conflicts; FINRA Rule 2210 content standards), where the affiliated broker-dealer distributes it to clients.", "Publication", "Boolean", "", "N", "FINRA Rule 2241", "FINRA Rule 2210", "", "Re-sourced at W1b from EU and UK MAR Article 20 (review fix pass, CW-923)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Issuer Meetings", "RS-MTG",
  "Meetings and calls with issuer management (one-to-ones, group meetings, conferences, site visits), who attended and whether they were wall-crossed, what was discussed, and whether material nonpublic information may have been received. Never a 03 Advisor Activity. 34 Engagement will reference the meeting when it has a stewardship objective; the compliance determination, cleansing, restricted list, watch list and insider lists are 38.",
  [
   ("Issuer Meeting", "One meeting with an issuer, its format, arrangement, attendees and notes.", [
     ("Issuer Meeting", [
       ("Issuer Meeting ID", "Unique identifier of the meeting.", "Issuer Meeting", "Identifier", "", "IMTG-0012874", "Internal", "Bipsync", "Y"),
       ("Meeting Issuer", "Issuer whose management or representatives were met.", "Issuer Meeting", "Reference (Party)", "", "PTY-7001234", "Internal", "", "Y"),
       ("Meeting Start Timestamp", "Date and time the meeting started.", "Issuer Meeting", "Timestamp", "ISO 8601", "2026-09-22T14:00:00Z", "Internal", "Advisers Act Section 204A", "Y"),
       ("Issuer Meeting Format", "Who was in the room: one-to-one, small group, conference presentation and so on.", "Issuer Meeting", "Code", "Issuer Meeting Format", "One-to-One", "Internal", "", ""),
       ("Meeting Channel", "How the meeting was held.", "Issuer Meeting", "Code", "Meeting Channel", "In Person", "Internal", "", ""),
       ("Arranging Provider", "Broker or corporate access provider that arranged the meeting; blank when arranged directly with the issuer.", "Issuer Meeting", "Reference (Party)", "", "PTY-1003320", "Internal", "", ""),
       ("Corporate Access Charge Basis", "How the corporate access was provided or paid for; amounts are 25.", "Issuer Meeting", "Code", "Corporate Access Charge Basis", "No Charge", "SEC Section 28(e) Release 34-54165", "", ""),
       ("Management Tone", "Analyst's reading of management's tone in the meeting.", "Issuer Meeting", "Code", "Shared: Sentiment", "Positive", "Internal", "", ""),
       ("Meeting Notes Location", "Location of the meeting notes in the research system.", "Issuer Meeting", "Text", "URI", "rms://meetings/2026/09/IMTG-0012874.docx", "Internal", "", "", "Notes may contain MNPI and names of issuer executives (PII)."),
       ("Meeting Notes Classification", "Information handling class of the meeting notes.", "Issuer Meeting", "Code", "Shared: Information Classification", "Confidential", "Internal", "ISO/IEC 27001", "", "Set to Restricted - MNPI when MNPI may have been received."),
       ("Summary AI Use Case", "AI use case under which the meeting summary was machine-generated, if any.", "Issuer Meeting", "Reference (AI Use Case)", "", "", "Internal", "", ""),
     ]),
     ("Issuer Meeting Participant", [
       ("Participant Meeting", "Meeting attended.", "Meeting Participant", "Reference (Issuer Meeting, 23)", "", "IMTG-0012874", "Internal", "", "Y"),
       ("Internal Participant", "Employee who attended, for internal participants.", "Meeting Participant", "Reference (Employee)", "", "EMP-30412", "Internal", "", "Y", "PII (employee)."),
       ("External Participant", "Individual who attended for the issuer or a third party, for external participants.", "Meeting Participant", "Reference (Party)", "", "PTY-8104471", "Internal", "", "", "PII."),
       ("Meeting Participant Role", "Role the participant played in the meeting.", "Meeting Participant", "Code", "Meeting Participant Role", "Issuer Executive", "Internal", "", ""),
       ("Wall-Crossing Consent Indicator", "Whether the internal participant agreed to receive inside information before it was disclosed (market sounding); internal participants only.", "Meeting Participant", "Boolean", "", "", "Advisers Act Section 204A", "", ""),
       ("Wall-Crossing Timestamp", "Date and time the internal participant was brought over the wall; internal participants only.", "Meeting Participant", "Timestamp", "ISO 8601", "", "Advisers Act Section 204A", "", "Y", "38 insider lists will read this per person."),
     ]),
     ("Issuer Meeting Topic", [
       ("Topic Meeting", "Meeting the topic was discussed in.", "Meeting Topic", "Reference (Issuer Meeting, 23)", "", "IMTG-0012874", "Internal", "", "Y"),
       ("Topic Sequence", "Order of the topic within the meeting record.", "Meeting Topic", "Integer", "", "2", "Internal", "", ""),
       ("Meeting Topic Category", "Subject area of the topic.", "Meeting Topic", "Code", "Meeting Topic Category", "Capital Allocation", "Internal", "", ""),
       ("Topic Summary", "What was said on the topic.", "Meeting Topic", "Text", "", "Buyback pace maintained; no change to dividend policy", "Internal", "", "", "May contain MNPI; classified with the meeting notes."),
       ("Stewardship Objective Indicator", "Whether the topic pursued a stewardship objective, so that 34 Engagement can reference the meeting.", "Meeting Topic", "Boolean", "", "N", "Internal", "", ""),
     ]),
   ]),
   ("MNPI Flag", "Whether material nonpublic information may have been received in the meeting, and the compliance escalation it was raised under. The compliance determination and cleansing are 38.", [
     ("Meeting MNPI Assessment", [
       ("MNPI Received Indicator", "Whether the attendees declared that material nonpublic information may have been received.", "Issuer Meeting", "Boolean", "", "N", "Advisers Act Section 204A", "FINRA Rule 3110(d)", "Y"),
       ("MNPI Escalation Reference", "Compliance escalation raised for the declaration.", "Issuer Meeting", "Reference (MNPI Escalation, 38)", "", "MNPI-2026-00412", "Advisers Act Section 204A", "", "", "Re-typed at the Stage 4 consolidation (CD-256): 23 flags MNPI, the 38 MNPI Escalation decides, the 38 Restricted List Entry restricts."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Third-Party Research", "RS-TPR",
  "External research the firm uses: research provider profiles (the research provider role on a 02 party), the research services subscribed to, the consumption of research and expert calls as evidence, and the periodic evaluation of providers (the broker vote), whose evaluation rounds 25 Research Payment reads. Budgets, research payment accounts, payment routes, commission sharing arrangements and payments are 25; research bought as data is a 14 licensed dataset.",
  [
   ("Research Providers & Services", "Research provider role profiles and the research services subscribed to.", [
     ("Research Provider Profile", [
       ("Research Provider Party", "Party the profile belongs to; key of the profile.", "Provider Profile", "Reference (Party)", "", "PTY-1003320", "Internal", "FIBO BE", "Y"),
       ("Research Provider Type", "Business model of the research provider.", "Provider Profile", "Code", "Research Provider Type", "Full-Service Broker", "SEC Section 28(e) Release 34-54165", "", "Y"),
       ("Research Specialties", "Research areas the provider specializes in.", "Provider Profile", "Code (multi)", "Research Specialty", "Equity; Credit", "Internal", "", ""),
       ("Approved Research Service Types", "Research services the provider is approved to supply.", "Provider Profile", "Code (multi)", "Research Service Type", "Written Research; Analyst Access; Corporate Access", "Internal", "", ""),
       ("Research Use Approval Status", "Whether the provider is approved for use by the investment teams.", "Provider Profile", "Code", "Shared: Approval Status", "Approved", "Internal", "", "Y"),
       ("Expert Network Due Diligence Date", "Date Compliance last completed due diligence on the expert network's MNPI controls; expert networks only.", "Provider Profile", "Date", "ISO 8601", "", "Advisers Act Section 204A", "", "", "Held here. 37 Third-Party Risk Assessment (type Expert Network MNPI Controls) now exists; making this date a Derived copy (37) is proposed under CD-248 (stage4_consolidation_notes §3)."),
       ("Research Provider Profile Status", "Whether the profile is in use.", "Provider Profile", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
       ("Provider Profile Effective From", "Date the profile was set up.", "Provider Profile", "Date", "ISO 8601", "2019-04-01", "Internal", "", ""),
       ("Provider Profile Effective To", "Date the profile was closed.", "Provider Profile", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Research Service Subscription", [
       ("Subscribed Provider", "Research provider supplying the service.", "Service Subscription", "Reference (Party)", "", "PTY-1003320", "Internal", "", "Y"),
       ("Subscribed Service Type", "Research service subscribed to.", "Service Subscription", "Code", "Research Service Type", "Written Research", "SEC Section 28(e) Release 34-54165", "", ""),
       ("Subscribing Research Team", "Research team or investment team that uses the service.", "Service Subscription", "Reference (Org Unit)", "", "OU-RES-EQ", "Internal", "", ""),
       ("Subscription Start Date", "Date the service started.", "Service Subscription", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Subscription End Date", "Date the service ended or will end.", "Service Subscription", "Date", "ISO 8601", "2026-12-31", "Internal", "", ""),
       ("Licensed Dataset", "Licensed dataset behind the service, where research is delivered as data; its data license agreement is read from 14.", "Service Subscription", "Reference (Dataset)", "", "", "Internal", "", ""),
     ]),
   ]),
   ("Research Consumption & Evaluation", "Evidence of research used and the periodic evaluation of providers.", [
     ("Research Consumption Record", [
       ("Consuming Employee", "Employee who read, attended or requested the research.", "Research Consumption", "Reference (Employee)", "", "EMP-30412", "Internal", "", "Y", "PII (employee)."),
       ("Consumed Provider", "Research provider that supplied the research or interaction.", "Research Consumption", "Reference (Party)", "", "PTY-1003320", "Internal", "", "Y"),
       ("Research Interaction Type", "Kind of research interaction.", "Research Consumption", "Code", "Research Interaction Type", "Analyst Call", "SEC Section 28(e) Release 34-54165", "", "Y"),
       ("Interaction Timestamp", "Date and time the interaction started, or the report was opened; distinguishes interactions with the same provider on the same day.", "Research Consumption", "Timestamp", "ISO 8601", "2026-09-18T15:30:00Z", "Internal", "", "Y"),
       ("Provider Contact", "Sell-side analyst, salesperson or expert who took part.", "Research Consumption", "Reference (Party)", "", "PTY-8200193", "Internal", "", "", "PII."),
       ("Related Issuer", "Issuer the interaction was about, if any.", "Research Consumption", "Reference (Party)", "", "PTY-7001234", "Internal", "", ""),
       ("Related Issuer Meeting", "Issuer meeting the interaction booked or led to, for corporate access.", "Research Consumption", "Reference (Issuer Meeting, 23)", "", "", "Internal", "", ""),
       ("Expert Call Approval Status", "Compliance pre-approval of an expert network call; expert calls only.", "Research Consumption", "Code", "Shared: Approval Status", "", "Advisers Act Section 204A", "", ""),
     ]),
     ("Research Evaluation Round", [
       ("Evaluated Provider", "Research provider evaluated.", "Evaluation Round", "Reference (Party)", "", "PTY-1003320", "Internal", "", "Y"),
       ("Evaluation Period Type", "Length of the evaluation period.", "Evaluation Round", "Code", "Shared: Period Type", "Half-Year", "Internal", "", ""),
       ("Evaluation Period End Date", "End date of the period evaluated.", "Evaluation Round", "Date", "ISO 8601", "2026-06-30", "Internal", "", "Y"),
       ("Evaluator", "Analyst or portfolio manager who cast the evaluation.", "Evaluation Round", "Reference (Employee)", "", "EMP-30412", "Internal", "", "Y", "PII (employee)."),
       ("Overall Evaluation Score", "Weighted score of the provider in the round, from the criterion scores and weights, on the firm's 1 to 5 scale.", "Evaluation Round", "Decimal", "", "3.85", "SEC Section 28(e) Release 34-54165", "", "Y", "Calculated in 23 from the Evaluation Criterion Score rows."),
       ("Vote Allocation Share", "Share of the evaluator's total vote for the period given to the provider; the payment allocation signal 25 Research Payment reads.", "Evaluation Round", "Percentage", "", "6.5%", "Internal", "", "Y", "Signal only; payment amounts are 25 (CD-174)."),
       ("Evaluation Comment", "Evaluator's overall comment on the provider.", "Evaluation Round", "Text", "", "Strong sector models; slow on earnings flashes", "Internal", "", ""),
       ("Evaluation Approval Status", "Whether the round result has been approved by the research lead for use by 25.", "Evaluation Round", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("Evaluation Approved By", "Research lead who approved the round result.", "Evaluation Round", "Reference (Employee)", "", "EMP-30155", "Internal", "", "", "PII (employee)."),
     ]),
     ("Evaluation Criterion Score", [
       ("Scored Evaluation Round", "Evaluation round the score belongs to.", "Criterion Score", "Reference (Research Evaluation Round, 23)", "", "PTY-1003320 / 2026-06-30 / EMP-30412", "Internal", "", "Y"),
       ("Evaluation Criterion", "Criterion scored.", "Criterion Score", "Code", "Evaluation Criterion", "Quality of Written Research", "SEC Section 28(e) Release 34-54165", "", "Y"),
       ("Criterion Score", "Score the evaluator gave on the criterion, on the firm's 1 to 5 scale.", "Criterion Score", "Decimal", "", "4", "Internal", "", ""),
       ("Criterion Weight", "Weight of the criterion in the round's overall score, as set by the firm's evaluation policy for the period.", "Criterion Score", "Percentage", "", "30%", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 # Lists that mirror enterprise shared lists by name (values are a subset of the shared list; see proposals_23.py SHARED_MEMBERSHIPS)
 # Local lists
 "Research Subject Type": ("Internal", [("Issuer","Subject is an issuer (02 party with a 17 issuer profile)."),("Instrument","Subject is one instrument (17)."),("Sector","Subject is a node of a 09 classification scheme."),("Country","Subject is a country or sovereign (09 geographic unit)."),("Rates Market","Subject is a government bond or rates market of a country or region, optionally a curve segment."),("Theme","Subject is a cross-sector investment theme (publications only).")]),
 "Research Coverage Role": ("Internal", [("Primary Analyst","Accountable for the recommendation on the subject; sets the research team view."),("Secondary Analyst","Back-up coverage; may publish in the primary analyst's absence."),("Associate Analyst","Supports the primary analyst; does not own recommendations."),("Sector Head","Oversees coverage of a sector."),("Specialist Contributor","Covers one aspect, e.g. ESG, legal or structure, of the subject.")]),
 "Research Universe Type": ("Internal", [("Focus List","Highest-conviction ideas of a research team."),("Coverage List","All subjects under active research coverage."),("Approved Research List","Subjects with research sufficient to be held by named strategies."),("Quant Signal Universe","Instruments a quantitative signal is calculated over.")]),
 "Recommendation Rating Scale": ("Internal (versioned firm scales)", [("Firm Equity Five-Point Scale v2","Strong Buy, Buy, Hold, Sell, Strong Sell."),("Firm Equity Relative Scale v1","Overweight, Neutral, Underweight versus sector."),("Firm Credit Relative Value Scale v1","Overweight, Market Weight, Underweight versus credit benchmark."),("Firm Sovereign and Rates Scale v1","Long, Neutral, Short duration or country view; an analyst input to 24, not the house view.")]),
 "Recommendation Rating": ("Internal (values by scale; FINRA Rule 2241 buy / hold / sell distribution used as a reference point)", [("Strong Buy","Equity five-point scale."),("Buy","Equity five-point scale."),("Hold","Equity five-point scale."),("Sell","Equity five-point scale."),("Strong Sell","Equity five-point scale."),("Overweight","Equity relative and credit relative value scales."),("Neutral","Equity relative scale; sovereign and rates scale."),("Market Weight","Credit relative value scale."),("Underweight","Equity relative and credit relative value scales."),("Long","Sovereign and rates scale."),("Short","Sovereign and rates scale."),("Not Rated","No rating in force (coverage suspended or initiating).")]),
 "Conviction Level": ("Internal", [("High",""),("Medium",""),("Low","")]),
 "Recommendation Change Type": ("Internal (FINRA Rule 2241 rating and price target history as a reference point)", [("Initiation","First recommendation on the subject by the analyst."),("Upgrade","Rating moved up the scale."),("Downgrade","Rating moved down the scale."),("Reiteration","Rating unchanged; view reaffirmed."),("Price Target Change","Rating unchanged; price target or fair value changed."),("Suspension","Rating suspended (e.g. pending information or restriction)."),("Reinstatement","Rating restored after suspension."),("Coverage Transfer","Recommendation restated by a new covering analyst."),("Discontinuation","Coverage and recommendation ended.")]),
 "Valuation Method": ("Internal (CFA Institute curriculum terms)", [("Discounted Cash Flow",""),("Dividend Discount Model",""),("Trading Multiples","Relative valuation versus peers."),("Sum of the Parts",""),("Residual Income",""),("Net Asset Value","Asset-based valuation, e.g. REITs and holding companies."),("Spread-Based Relative Value","Credit: spread versus rating and sector curve."),("Scenario-Weighted","Probability-weighted bull, base and bear cases.")]),
 "Internal Credit Rating Scale": ("Internal (versioned firm scales)", [("Firm Long-Term Credit Scale v3","ICR 1 to ICR 10 plus D; mapped to the 17 notch scale."),("Firm Short-Term Credit Scale v2","ST1 to ST3; used for money market instruments.")]),
 "Internal Credit Rating": ("Internal (firm-defined; agency equivalents and 17 notch mapping indicative, 1 = AAA)", [("ICR 1","Highest credit quality (AAA equivalent); notch 1."),("ICR 2","Very high (AA range); notches 2-4."),("ICR 3","High (A+ / A); notches 5-6."),("ICR 4","Upper medium (A-); notch 7."),("ICR 5","Medium (BBB+ / BBB); notches 8-9."),("ICR 6","Lower medium (BBB-); notch 10."),("ICR 7","Speculative (BB range); notches 11-13."),("ICR 8","Highly speculative (B range); notches 14-16."),("ICR 9","Substantial risk (CCC range and below); notches 17-19."),("ICR 10","Near default; notch 20."),("D","In default; notch 21."),("ST1","Short-term: highest capacity to meet short-term obligations."),("ST2","Short-term: strong capacity."),("ST3","Short-term: adequate capacity; not money market eligible.")]),
 "Estimate Metric": ("Internal (aligned to Visible Alpha / Bloomberg BEst field families)", [("Revenue","Currency, millions."),("EBITDA","Currency, millions."),("EBIT","Currency, millions."),("Net Income","Currency, millions."),("Diluted EPS","Currency per share."),("Dividend per Share","Currency per share."),("Free Cash Flow","Currency, millions."),("Capital Expenditure","Currency, millions."),("Net Debt","Currency, millions."),("Net Debt to EBITDA","Ratio (x)."),("Interest Coverage","Ratio (x)."),("Book Value per Share","Currency per share.")]),
 "Research Model Type": ("Internal", [("Three-Statement with DCF","Issuer financial model with discounted cash flow."),("Comparables","Peer multiples model."),("Credit Model","Issuer credit metrics, capital structure and recovery."),("Structured Credit Cash Flow Model","Collateral and waterfall model."),("Sector Model","Aggregate sector supply, demand or pricing model."),("Macro Model","Economic forecasting model."),("Quantitative Signal Model","Code that produces a research signal.")]),
 "Economic Indicator": ("Internal", [("Real GDP Growth","Percent, year on year."),("Headline CPI Inflation","Percent, year on year."),("Core Inflation","Percent, year on year (core PCE for the US, core HICP for the euro area)."),("Unemployment Rate","Percent of labor force."),("Policy Rate","Percent, end of period."),("10-Year Government Bond Yield","Percent, end of period."),("Fiscal Balance","Percent of GDP."),("Current Account Balance","Percent of GDP.")]),
 "Signal Type": ("Internal", [("Value",""),("Momentum",""),("Quality",""),("Low Volatility",""),("Growth",""),("Estimate Revision",""),("Sentiment","Derived from text or positioning data."),("Alternative Data","Derived from non-traditional datasets."),("Credit Spread","Fixed income relative value.")]),
 "Publication Type": ("Internal", [("Initiation of Coverage",""),("Company Update",""),("Earnings Note",""),("Flash Note","Short reaction to news."),("Sector Note",""),("Thematic Note",""),("Macro Outlook",""),("Credit Opinion",""),("Meeting Note","Written-up issuer meeting for wider internal distribution.")]),
 "Issuer Meeting Format": ("Internal", [("One-to-One","Firm attendees only with the issuer."),("Small Group","Several investors, typically fewer than ten."),("Large Group","Larger investor group or lunch."),("Conference Presentation","Issuer presentation at a broker or industry conference."),("Site Visit","Visit to an issuer facility."),("Investor Day","Issuer-hosted capital markets or investor day.")]),
 "Meeting Channel": ("Internal", [("In Person",""),("Video",""),("Telephone","")]),
 "Meeting Participant Role": ("Internal", [("Lead Analyst","Firm analyst leading the meeting."),("Portfolio Manager",""),("Stewardship Analyst",""),("Other Firm Attendee",""),("Issuer Executive","Board member or senior management of the issuer."),("Investor Relations","Issuer investor relations staff."),("Broker Host","Corporate access or sales staff of the arranging provider."),("Issuer Adviser","Banker or adviser attending for the issuer.")]),
 "Meeting Topic Category": ("Internal", [("Strategy",""),("Financial Results and Guidance",""),("Capital Allocation",""),("Mergers and Acquisitions",""),("Operations",""),("Governance and Board",""),("Executive Remuneration",""),("Environmental",""),("Social and Human Capital",""),("Regulatory and Legal","")]),
 "Corporate Access Charge Basis": ("Internal (SEC Section 28(e) Release 34-54165)", [("No Charge","No charge and no third-party benefit (e.g. arranged directly with the issuer)."),("Paid Separately","Paid by the firm from its own resources as a separate service."),("Included in Research Service","Provided as part of a paid research service.")]),
 "Research Provider Type": ("Internal (SEC Section 28(e) Release 34-54165); business model only", [("Full-Service Broker","Executing broker that also produces research."),("Independent Research Provider","Research-only firm with no execution."),("Expert Network","Arranges calls with industry experts."),("Corporate Access Provider","Arranges issuer meetings without producing research.")]),
 "Research Specialty": ("Internal", [("Equity",""),("Credit",""),("Macro and Economics",""),("Rates and FX",""),("Quantitative",""),("Sector Specialist","Deep coverage of one or a few sectors."),("ESG","")]),
 "Research Service Type": ("Internal", [("Written Research","Reports and notes."),("Analyst Access","Calls and meetings with the provider's analysts."),("Models","Financial models supplied by the provider."),("Corporate Access","Issuer meetings arranged by the provider."),("Expert Calls","Expert network consultations."),("Conferences","Provider-hosted conferences."),("Bespoke Research","Research commissioned for the firm.")]),
 "Research Interaction Type": ("Internal", [("Report Read",""),("Analyst Call",""),("Analyst Meeting",""),("Model Request",""),("Bespoke Research Request",""),("Expert Network Call",""),("Conference Attendance",""),("Corporate Access Booking","")]),
 "Evaluation Criterion": ("Internal (quality criteria behind the good-faith determination of reasonableness, SEC Section 28(e) Release 34-54165)", [("Quality of Written Research",""),("Analyst Access and Responsiveness",""),("Models and Data",""),("Corporate Access",""),("Sector and Issuer Coverage Breadth",""),("Idea Generation and Contribution to Decisions",""),("Timeliness","")]),
}

# ---------------------------------------------------------------------------
REL = [
 ("Research Coverage Assignment","is held by","Employee [20]","n : 1","Covering analyst."),
 ("Research Coverage Assignment","covers","Party (Issuer) [02]","n : 0..1","Issuer facts (type, country of risk, sector) are read from the 17 Issuer Profile and Issuer Classification Assignment."),
 ("Research Coverage Assignment","covers","Instrument [17]","n : 0..1","Single-security coverage."),
 ("Research Coverage Assignment","covers sector of","Classification Scheme [09]","n : 0..1","Sector coverage by scheme version and node."),
 ("Research Coverage Assignment","is held under","Org Unit [09]","n : 0..1","Research team."),
 ("Research Coverage Assignment","may serve","Investment Strategy [01]","n : 0..1",""),
 ("Research Universe","has","Research Universe Member","1 : 0..n","Effective-dated membership."),
 ("Research Recommendation","may be on","Classification Scheme / Geographic Unit [09]","n : 0..1","Sector, country and rates market recommendations."),
 ("Research Coverage Assignment","produces","Research Recommendation","1 : 0..n","Current research recommendation = latest row per subject x scale x recommending analyst; the team view comes from the Primary Analyst; no 'current rating' column on coverage. The house view is 24."),
 ("Research Recommendation","supersedes","Research Recommendation","0..1 : 0..1","Previous Recommendation."),
 ("Research Recommendation","has","Recommendation Valuation Basis","1 : 0..1",""),
 ("Recommendation Valuation Basis","reads","Approved Price [22]","n : 0..1","Price at Recommendation is a Derived copy (22)."),
 ("Research Recommendation","is announced in","Research Publication","n : 0..1","Link held on the recommendation only."),
 ("Research Recommendation","informs","Investment Decision [24]","1 : 0..n","24 Decision Rationale holds the single Linked Research Recommendation (RREC-); 23 holds no weights or orders."),
 ("Party (Issuer or Counterparty) [02]","is assessed by","Internal Credit Assessment","1 : 0..n","Internal view; agency ratings are 17 Credit Rating Assignment (CD-173)."),
 ("Internal Credit Assessment","may assess","Instrument [17]","n : 0..1","Issue-level assessment."),
 ("Counterparty Review [25]","may read","Internal Credit Assessment","n : 0..1","Credit view of a trading counterparty (CD-179)."),
 ("Party (Issuer) [02]","has","Analyst Estimate","1 : 0..n","By metric, fiscal period and estimate date."),
 ("Analyst Estimate","is taken from","Research Model","n : 0..1",""),
 ("Economic Forecast","is for","Geographic Unit [09]","n : 1",""),
 ("Research Signal Definition","produces","Research Signal Score","1 : 0..n","Persisted only if SME question 5 confirms."),
 ("Research Signal Score","scores","Instrument [17]","n : 1",""),
 ("Research Signal Definition","may be registered as","AI Use Case [21]","n : 0..1",""),
 ("Research Publication","has","Publication Subject","1 : 1..n",""),
 ("Research Publication","has","Publication Review","1 : 0..1",""),
 ("Publication Review","may be released as","Investment Commentary [01]","n : 0..1","External release (CD-172)."),
 ("Publication Review","may be released as","Content Asset [04]","n : 0..1",""),
 ("Issuer Meeting","is held with","Party (Issuer) [02]","n : 1","Never a 03 Advisor Activity (CD-172)."),
 ("Issuer Meeting","has","Issuer Meeting Participant","1 : 1..n","Internal (EMP-, 20) or external (PTY-, 02) participants; wall crossing recorded per internal participant."),
 ("Issuer Meeting","has","Issuer Meeting Topic","1 : 0..n",""),
 ("Issuer Meeting","has","Meeting MNPI Assessment","1 : 0..1","MNPI flag and escalation reference only; wall crossing is per participant."),
 ("Issuer Meeting","may be arranged by","Party (Research Provider) [02]","n : 0..1","Corporate access provider."),
 ("Engagement [34]","may reference","Issuer Meeting","n : 0..1","Stage 3; when a topic has a stewardship objective."),
 ("Restricted List Entry [38]","may reference","Issuer Meeting","n : 0..1","23 flags MNPI, 38 restricts (CD-256)."),
 ("Party (Research Provider) [02]","has","Research Provider Profile","1 : 0..1","Role profile keyed by PTY- (CD-179 Party Role Type 'Research Provider', 'Expert Network')."),
 ("Research Provider Profile","supplies","Research Service Subscription","1 : 0..n",""),
 ("Research Service Subscription","may be licensed as","Dataset / Data License Agreement [14]","n : 0..1",""),
 ("Research Provider Profile","is evidenced by","Research Consumption Record","1 : 0..n",""),
 ("Research Consumption Record","is logged for","Employee [20]","n : 1",""),
 ("Research Provider Profile","is evaluated in","Research Evaluation Round","1 : 0..n","Provider x period x evaluator."),
 ("Research Evaluation Round","has","Evaluation Criterion Score","1 : 1..n","One row per criterion."),
 ("Research Payment [25]","is set by","Research Evaluation Round","n : 0..n","Reads Overall Evaluation Score and Vote Allocation Share; payments, routes, budgets and accounts are 25 (CD-174)."),
]

# ---------------------------------------------------------------------------
SRC = [
 ("SEC interpretive release 34-54165 (2006): Commission Guidance Regarding Client Commission Practices Under Section 28(e) of the Securities Exchange Act of 1934","US SEC","https://www.sec.gov/rules-regulations/2006/07/commission-guidance-regarding-client-commission-practices-under-section-28e-securities-exchange-act","Regulatory guidance","Eligible research and brokerage services; lawful and appropriate assistance; good-faith determination of reasonableness, which the provider evaluation and consumption records evidence","Research Provider Type, Research Service Type, Corporate Access Charge Basis, Research Consumption Record, Research Evaluation Round, Evaluation Criterion Score",["SEC Section 28(e) Release 34-54165"]),
 ("SEC Rule 2a-7 under the Investment Company Act of 1940 (money market funds)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.2a-7","Regulation","Eligible security as one the board (or its delegate) determines presents minimal credit risks; factors for that determination; first tier security as an issuer with the highest capacity to meet short-term financial obligations","Internal Credit Assessment, Research Universe Type (Money Market Eligible List)",["SEC Rule 2a-7"]),
 ("Investment Advisers Act of 1940 Section 204A (prevention of misuse of nonpublic information) and Rule 204A-1 (code of ethics)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.204A-1","Statute / regulation","Written policies to prevent misuse of MNPI; basis for MNPI declarations, escalation and expert network controls","Meeting MNPI Assessment, Expert Call Approval Status, Expert Network Due Diligence Date",["Advisers Act Section 204A"]),
 ("CFA Institute Asset Manager Code (research and investment process: reasonable basis for investment decisions)","CFA Institute","https://rpc.cfainstitute.org/codes-and-standards/asset-manager-code","Industry code","Diligence and reasonable basis; documentation of research supporting investment decisions; supervisory review","Investment Thesis Summary, Valuation Method, Publication Review",["CFA Institute*"]),
 ("FINRA Rule 3110(d) (Supervision: transaction review and investigation for insider trading)","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/3110","SRO rule","Broker-dealer procedures to review securities transactions for trading on material nonpublic information; applies to the affiliated broker-dealer alongside the adviser's Section 204A policies","MNPI Received Indicator",["FINRA Rule 3110(d)"]),
 ("FINRA Rule 2210 (Communications with the Public)","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2210","SRO rule","Content standards, approval and filing of retail communications of the affiliated broker-dealer, including research released to clients","Investment Recommendation Disclosure Indicator",["FINRA Rule 2210"]),
 ("FINRA Rule 2241 (Research Analysts and Research Reports)","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2241","SRO rule (sell-side; reference point)","Rating definitions and buy / hold / sell distribution; price targets with valuation basis and risks; rating and price target history","Recommendation Rating, Recommendation Rating Scale, Recommendation Change Type, Price Target, Valuation Method, Key Risks, Investment Recommendation Disclosure Indicator",["FINRA Rule 2241"]),
 ("FIBO - Business Entities (BE) and Securities (SEC)","EDM Council","https://spec.edmcouncil.org/fibo/","Open (MIT license)","Issuer as a role of a legal entity; security and issuer concepts behind coverage and recommendation subjects","Research Coverage Assignment, Research Provider Profile",["FIBO*"]),
 ("FactSet Research Management Solutions (RMS) and Bipsync research management platform (vendor practice)","FactSet; Bipsync","https://www.factset.com","Vendor documentation","Structure of research notes, ratings and price target history, coverage, meeting notes and MNPI tagging in buy-side research management systems","Research Publication, Research Recommendation, Issuer Meeting",["FactSet RMS", "Bipsync"]),
 ("Visible Alpha and Bloomberg BEst consensus estimates (vendor practice)","Visible Alpha (S&P Global); Bloomberg","https://visiblealpha.com","Vendor documentation","Estimate metric families, fiscal period conventions, adjusted versus reported basis, consensus definitions","Analyst Estimate, Estimate Metric",["Visible Alpha", "Bloomberg BEst"]),
 ("ISO 4217 / ISO 3166 / ISO 8601; ISO/IEC 27001 (information classification)","ISO","https://www.iso.org","Standard","Currency, country and date/time formats; information classification for MNPI handling","Reference formats used throughout; Publication Classification, Meeting Notes Classification",["ISO 4217", "ISO 3166", "ISO/IEC 27001"]),
]
