"""Data Domain 27 - Fund Accounting & Valuation. Content module for taxonomy_builder.py."""

META = {
 "title": "Fund Accounting & Valuation Data Taxonomy",
 "subtitle": "Business domain 27 - Fund Accounting & Valuation | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "27_Fund_Accounting_and_Valuation/Fund_Accounting_and_Valuation_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the official books of the funds a US wealth manager sponsors and runs: its own mutual funds (including money market funds), ETFs and collective investment trusts (business line PF, CW-004), and any own private or feeder funds it offers. It covers the accounting book of record (ABOR) kept by fund accounting, in house or at an outsourced administrator. It defines each fund's book, its operating model and administrator over time, the portfolios it accounts for and its chart of accounts, the fund journals and trial balances posted to it, the official valuation of every position and the income accrued on it, the reconciliation of the book to the investment book (IBOR, 18), the fund and share class net asset value (NAV) struck every valuation day and allocated across classes, how the NAV is checked and released, the swing pricing decisions a fund that adopts swing pricing under Rule 22c-1(a)(3) takes on it, fund expense budgets, accruals, cap and waiver accruals and payments, the distributions the fund declares and their tax character, the fund's tax year, book-tax differences and RIC tests, NAV error cases and their impact by class, and the fund's financial statements and financial highlights. It is stewarded by fund accounting and fund tax, apart from the corporate ledgers of the firm (19 Finance & Accounting), the investment view of the portfolio (18 Portfolio & Investment Book of Record) and the client book of record of the brokerage (49). The firm is regulated and distributes in the US only; its funds hold a global universe, so foreign-currency books, FX translation and foreign income stay. Stitched together from Investment Company Act Rules 2a-4, 2a-5, 2a-7, 18f-3, 19a-1 and 22c-1, Regulation S-X Article 6, FASB ASC 946 and the AICPA Investment Companies guide, IRC Subchapter M (sections 851-855), section 4982 and Form 1120-RIC, OCC 12 CFR 9.18, the DTCC Mutual Fund Profile service, ICI practice on NAV error correction, and public descriptions of fund accounting platforms. Use it as a starting point for a fund accounting data model, an administrator oversight model or a business glossary."),
  ("Scope", "In scope: fund accounting books by accounting basis, their effective-dated operating model and administrator of record, the 18 portfolios each book accounts for, the fund chart of accounts, fund journal entries and lines with typed source references, fund trial balances, ABOR valuation records, ABOR to IBOR reconciliations and income accruals, fund NAV calculations by calculation source and version, share class NAVs (including CIT unit values), Rule 18f-3 class allocation, NAV release, swing pricing parameters and decisions (Rule 22c-1(a)(3)), fund expense budgets, expense accruals, expense cap and waiver accruals, fund expense payments, distribution declarations and their tax character, distributable income estimates, fund tax year records, book-tax differences, RIC test results, NAV error cases and their impact by class and date, NAV-level control checks, fund financial statement sets and financial highlights. Out of scope (referenced by ID): fund, series, share class, fee, expense cap, swing, distribution, valuation and service provider appointment terms (01 Investment Product & Service Offering); service provider parties (02 Client & Household, party core); shareholder transactions and positions (06); legal entities (09); adviser fee revenue and waiver impact (10); advisory fees billed to client accounts and any offset for proprietary funds held in advised accounts (47 Pricing, Fees & Billing); shareholder statements, tax forms, servicing errors and remediation (13); instruments, coupon schedules and corporate action events (17); portfolios, holdings, tax lots and portfolio transactions (18); corporate ledgers, receivables and payables (19); employees (20); approved prices, price validation, reference rate fixings, FX rates and fair value determinations (22); fund-side settlement instructions (26); client holdings and client cost basis of fund shares held in brokerage accounts (49); safekeeping accounts, income collection and custodian reconciliations (28); fund orders, ETF AP orders, TA controls including the capital stock proof, and per-channel NAV transmission (29); investor subscriptions, holdings and capital-call and distribution cash of the firm's feeder funds (15 Alternative Investment Subscription, 49, 50) and investor Schedules K-1 of feeder funds (13 tax documents from the feeder administrator). Held in other domains: RIC qualification status, N-CSR and N-PORT filings and the Rule 2a-5 valuation designee (35), fund mergers (36) and returns from NAV (32)."),
  ("Structure", "Four levels: Data Domain > Data Family > Data Business Object > Data Business Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Fund Accounting Book (fund x accounting basis) is the master record of a fund's books. Its operating model and administrator of record are effective-dated Fund Book Operating Periods, and Fund Book Portfolio Links name the 18 portfolios (one or more) it accounts for. The book uses a fund chart of accounts (Fund Ledger Account), and receives Fund Journal Entries (FJNL-) whose Fund Journal Lines carry one typed source reference each (18 portfolio transaction, 26 settlement, 29 fund order or AP order, or 27 distribution), and a daily Fund Trial Balance. ABOR Valuation Records hold the book's own quantity and the official value at the 22 Approved Price and FX Rate Observation; ABOR to IBOR Reconciliations compare them with 18 holdings by portfolio. Income Accruals record income earned. A Fund NAV Calculation (book x valuation date x calculation source x version) totals the book; each Share Class NAV (NAV-) states the official per-share value, class net assets and shares outstanding, with Class Allocation rows (Rule 18f-3) and, for CIT unit classes, a CIT Unit Value Detail group. A NAV Release records each release of a NAV for use; 29 Price & Rate Transmission sends it per channel. NAV Control Checks record NAV-level checks and rely on the 29 capital stock proof. Swing Pricing Parameters (effective-dated) drive daily Swing Pricing Decisions (SWG-). Fund Expense Budgets drive daily Fund Expense Accruals; Expense Cap & Waiver Accruals apply the 01 caps; Fund Expense Payments settle fund payables. Distribution Declarations (FDIV-) carry their Distribution Character; Distributable Income Estimates plan them. Fund Tax Year Records (FTAX-) hold the tax year, with Book-Tax Differences and RIC Test Results. NAV Error Cases (NEC-) record errors and their NAV Error Impact by class and date. Fund Financial Statements (one statement set per book and period) with Financial Highlights per class close the period."),
  ("Design principles", "1) Fund books are not corporate books: a fund's journals never post to a 19 ledger, and fund ledger objects are named 'Fund ...' so they never collide with 19 names (CD-186). A fee the fund pays the adviser is two records: an expense accrual here and fee revenue in 10 / 19; fees billed to client accounts are 47 Pricing, Fees & Billing, not fund expenses. 2) ABOR, not IBOR, and no second lot master: 18 owns holdings, lots and portfolio transactions; 27 keeps its own book quantity (booked under Rule 2a-4 and as-of corrections) and reconciles it to 18, and computes book cost from the 18 lots. 3) 27 applies prices, 22 masters them: applied price, rate fixing, fair value determination and FX rate are references to 22 records, and price validation is 22's. 4) Terms in 01, calculations in 27, finance views in 10: expense cap, swing maximum, distribution policy, valuation point, NAV precision and service provider appointments are read from 01; where a rate is copied onto a daily accrual it is flagged as a derived copy with its row rule. 5) 'NAV' means the official per-share value struck by fund accounting; the 18 IBOR valuation summary, 06 AUM and 01 iNAV are not NAV. 6) One fact, one place: NAV per share is held once (Share Class NAV); release, transmission (29), error impact and distribution records point at it. 7) Statuses do not mix dimensions: NAV Status is separate from NAV Version Type and from NAV Calculation Source; NAV Error Type is separate from cause; Distribution Type records income source only. 8) Effective-date operating models, portfolio links and swing parameters, and record who approved NAVs, swing decisions and journals. 9) Flag Critical Data Elements (CDE)."),
  ("Applies To", "Shows the record each attribute belongs to: Fund Book, Book Operating Period, Book Portfolio Link, Ledger Account, Fund Journal, Journal Line, Trial Balance, ABOR Valuation, ABOR-IBOR Reconciliation, Income Accrual, Fund NAV, Class NAV, Class Allocation, CIT Unit Value, NAV Release, Swing Parameter, Swing Decision, Expense Budget, Fund Expense Accrual, Cap & Waiver, Expense Payment, Distribution, Distribution Character, Distributable Income, Fund Tax Year, Book-Tax Difference, RIC Test, NAV Error, NAV Error Impact, NAV Control Check, Fund Statement or Financial Highlights."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify the records other domains match on (NAV-, FJNL-, FDIV-, NEC-, SWG-, FTAX-), to strike, check and release the official NAV (valuation date, NAV per share, net assets, shares outstanding, applied price and FX), to book the fund ledger correctly (journal accounts and amounts), to accrue and cap expenses, to declare and characterize distributions, to keep the fund qualified for its tax regime, or to measure and decide on a NAV error. Confirm with fund accounting, fund tax, the pricing committee and fund treasury."),
  ("Primary / Secondary Reference", "Standard, rule or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Vendor references (fund accounting platforms and administrators) indicate common industry structure, not a license to reproduce vendor record layouts. Next step: map each attribute to the fund accounting platform's book, ledger, valuation, NAV and expense tables, or to the administrator's oversight files."),
  ("Notes", "PII = personal data under US privacy law (Regulation S-P, GLBA and state privacy laws). Personal data is limited to employee references (preparers, approvers, case owners, check performers). NAVs and holdings before release, NAV error cases and fund tax positions are confidential; a NAV before release may be material nonpublic information. Scope is the US wealth manager: the UK equalization and reporting-fund attributes, dilution levies, dual pricing and the EU/UK tax regimes, returns and NAV error regimes were removed under CW-927 and are listed in the jurisdiction register."),
  ("Tabs", "Hierarchy: families, object groups and objects with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: object-level cardinalities, including references to other Data Domains | Sources: standards used, owners, licenses and links."),
  ("Suggested next steps", "1) Validate families, NAV versions, calculation sources and statuses, journal source types and CDEs with fund accounting, fund tax, the pricing committee and fund treasury. 2) Record the operating model and administrator of every fund book over time and its accounted portfolios (CD-147). 3) Agree with 18 the ABOR to IBOR reconciliation and that book cost starts from 18 Original Cost Base. 4) Agree with 22 the Approved Price key and the row rule for own share classes held by own portfolios. 5) Confirm with 29 the release / transmission split and the capital stock proof reliance. 6) Agree with 10 and 13 the derived copies of waiver amounts and NAV error magnitude (CD-188, CD-189). 7) Confirm the board-approved NAV error materiality policy by fund type (SEC staff practice and ICI industry practice, commonly 0.5% of NAV or one cent per share; confirm source). 8) Register the local copies of shared lists in the 09 code list registry and decide whether Accounting Basis is shared with 19."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Fund Books & Ledgers", "FA-FBK",
  "The official books of each fund (ABOR): the book kept per fund and accounting basis, its operating model and administrator over time, the 18 portfolios it accounts for, the fund chart of accounts, fund journal entries and lines, and daily trial balances. Never the corporate ledgers of the management company (19, CD-186).",
  [
   ("Fund Accounting Book", "The set of books of one fund (series) under one accounting basis.", [
     ("Fund Accounting Book", [
       ("Book Fund", "Fund (series-level product) whose books these are; each series of a multi-series trust has its own book.", "Fund Book", "Reference (Investment Product)", "", "PRD-00981", "ASC 946", "Internal", "Y"),
       ("Accounting Basis", "Accounting framework the book is kept under.", "Fund Book", "Code", "Shared: Accounting Basis", "US GAAP", "ASC 946", "SEC Regulation S-X Article 6", "Y", "ASC 946 applies under US GAAP; a Tax Basis book supports fund tax. The EU/UK values of the shared list leave with its steward 19 (CW-919, CW-039)."),
       ("Book Code", "Code of the fund in the fund accounting platform or at the administrator.", "Fund Book", "Identifier", "", "4410-USGAAP", "Internal", "", "", "Mastered here; the 18 Portfolio Identifier scheme 'Accounting System Fund Code' holds a copy (proposals_27)."),
       ("Book Fund Chart of Accounts", "Fund chart of accounts the book posts to; journal line accounts must belong to it.", "Fund Book", "Identifier", "", "US-RIC-STD", "Internal", "", ""),
       ("Business Line", "Enterprise business line of the fund, as recorded on the 18 portfolio that implements it.", "Fund Book", "Code", "Shared: Business Line", "PF", "Internal", "", "", "Derived copy of 18 Portfolio Business Line (CW-004 codes). Institutional separate accounts have no fund book."),
       ("Book Reporting Currency", "Currency in which the book is kept and net assets are reported.", "Fund Book", "Code", "ISO 4217", "USD", "ISO 4217", "ASC 946", "", "Derived copy of 01 Product Base Currency."),
       ("Book Owner Entity", "Internal legal entity that owns and signs the books, recorded for CIT books (the trustee bank) and other books the firm's own entity is accountable for.", "Fund Book", "Reference (Legal Entity)", "", "LEN-0031", "12 CFR 9.18", "Internal", "", "Blank for a registered fund, whose books belong to the fund itself."),
       ("Book Status", "Whether the book is open for posting.", "Fund Book", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
     ]),
     ("Fund Book Operating Period", [
       ("Operated Book", "Fund accounting book the period applies to.", "Book Operating Period", "Reference (Fund Accounting Book, 27)", "", "PRD-00981 / US GAAP", "Internal", "", "Y"),
       ("Fund Accounting Operating Model", "Whether the book is kept in house, by an administrator, by an administrator with a firm shadow NAV, or by a trustee bank (CD-147).", "Book Operating Period", "Code", "Fund Accounting Operating Model", "Outsourced with Shadow NAV", "Internal", "", ""),
       ("Fund Administrator of Record", "Administrator that keeps the book in the period, when fund accounting is outsourced.", "Book Operating Period", "Reference (Party)", "", "PTY-100990", "Internal", "", "", "01 Product Party Role 'Fund Administrator' masters the appointment; this records the provider that kept the book."),
       ("Operating Period Effective From", "Date the operating model and administrator took effect.", "Book Operating Period", "Date", "ISO 8601", "2023-01-01", "Internal", "", "Y"),
       ("Operating Period Effective To", "Date the period ended, for example on conversion to a new administrator.", "Book Operating Period", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Fund Book Portfolio Link", [
       ("Linked Book", "Fund accounting book that accounts for the portfolio.", "Book Portfolio Link", "Reference (Fund Accounting Book, 27)", "", "PRD-00981 / US GAAP", "Internal", "", "Y"),
       ("Accounted Portfolio", "18 portfolio whose holdings and transactions the book accounts for; a book may account for several portfolios (sleeves).", "Book Portfolio Link", "Reference (Portfolio)", "", "PORT-000412", "Internal", "", "Y"),
       ("Book Portfolio Role", "Part the portfolio plays in the book.", "Book Portfolio Link", "Code", "Book Portfolio Role", "Main Portfolio", "Internal", "", ""),
       ("Portfolio Link Effective From", "Date the portfolio started to be accounted in the book.", "Book Portfolio Link", "Date", "ISO 8601", "2014-03-03", "Internal", "", ""),
       ("Portfolio Link Effective To", "Date the portfolio stopped being accounted in the book.", "Book Portfolio Link", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Fund Chart of Accounts", "The fund ledger accounts of a fund chart: assets, liabilities, capital, income, expense and gains.", [
     ("Fund Ledger Account", [
       ("Fund Chart of Accounts", "Fund chart the account belongs to; usually one standard chart per fund family and accounting basis.", "Ledger Account", "Identifier", "", "US-RIC-STD", "Internal", "", ""),
       ("Fund Ledger Account Number", "Number of the account within the fund chart.", "Ledger Account", "Identifier", "", "11000", "Internal", "", "Y", "Not a 19 GL Account; fund accounts never carry a GLA- key."),
       ("Fund Ledger Account Name", "Name of the account as shown on the trial balance.", "Ledger Account", "Text", "", "Investments at Value - Equities", "Internal", "", ""),
       ("Fund Ledger Account Class", "Accounting class of the account.", "Ledger Account", "Code", "Fund Ledger Account Class", "Asset", "ASC 946", "SEC Regulation S-X Article 6", "Y"),
       ("Class-Specific Account Indicator", "Whether balances on the account are kept by share class (class-specific expenses, capital stock, distributions) rather than at fund level.", "Ledger Account", "Boolean", "", "N", "SEC Rule 18f-3", "", ""),
       ("Statement Caption", "Line of the fund financial statements the account rolls into.", "Ledger Account", "Text", "", "Investments in securities, at value", "SEC Regulation S-X Article 6", "ASC 946", ""),
     ]),
   ]),
   ("Fund Journals", "Entries posted to a fund book and their lines, with the event in another domain that caused each line.", [
     ("Fund Journal Entry", [
       ("Fund Journal Entry ID", "Unique identifier of the fund journal entry.", "Fund Journal", "Identifier", "", "FJNL-2026-1005-00412", "Internal", "", "Y", "Format FJNL-<year>-<MMDD of posting>-<daily sequence>."),
       ("Journal Book", "Fund accounting book the entry is posted to.", "Fund Journal", "Reference (Fund Accounting Book, 27)", "", "PRD-00981 / US GAAP", "Internal", "", ""),
       ("Fund Journal Source Type", "Kind of event the entry records.", "Fund Journal", "Code", "Fund Journal Source Type", "Trade", "ASC 946", "Internal", "Y"),
       ("Accounting Date", "Valuation date whose NAV the entry affects.", "Fund Journal", "Date", "ISO 8601", "2026-10-05", "SEC Rule 2a-4", "", "Y", "Under Rule 2a-4 trades are reflected no later than the first business day after trade date."),
       ("Posting Date", "Date the entry was actually posted; later than the accounting date for backdated and as-of entries.", "Fund Journal", "Date", "ISO 8601", "2026-10-06", "Internal", "", "Y"),
       ("Fund Journal Status", "Processing status of the entry.", "Fund Journal", "Code", "Fund Journal Status", "Posted", "Internal", "", ""),
       ("Reversed Journal", "Earlier fund journal entry that this entry reverses.", "Fund Journal", "Reference (Fund Journal Entry, 27)", "", "FJNL-2026-1002-00118", "Internal", "", ""),
       ("Related NAV Error Case", "NAV error case under which the entry is booked, for NAV error corrections.", "Fund Journal", "Reference (NAV Error Case, 27)", "", "NEC-2026-0031", "Internal", "", ""),
       ("Manual Entry Indicator", "Whether the entry was keyed by hand rather than generated from a source event.", "Fund Journal", "Boolean", "", "N", "Internal", "", ""),
       ("Journal Approved By", "Employee who approved a manual entry.", "Fund Journal", "Reference (Employee)", "", "EMP-02240", "Internal", "", "", "PII (internal staff)."),
     ]),
     ("Fund Journal Line", [
       ("Line Journal", "Fund journal entry the line belongs to.", "Journal Line", "Reference (Fund Journal Entry, 27)", "", "FJNL-2026-1005-00412", "Internal", "", ""),
       ("Journal Line Number", "Sequence of the line within the entry.", "Journal Line", "Integer", "", "2", "Internal", "", ""),
       ("Line Fund Ledger Account", "Fund ledger account the line is posted to, keyed by fund chart and account number.", "Journal Line", "Reference (Fund Ledger Account, 27)", "", "US-RIC-STD / 11000", "Internal", "", "Y"),
       ("Line Amount", "Signed amount of the line in the transaction currency; debits positive, credits negative.", "Journal Line", "Amount", "", "EUR 412,500.00", "Internal", "", "Y"),
       ("Line Base Amount", "Signed amount of the line in the book reporting currency.", "Journal Line", "Amount", "", "USD 481,935.00", "ASC 946", "", "Y"),
       ("Line FX Rate", "FX rate observation used to translate the line into the book currency.", "Journal Line", "Reference (FX Rate Observation, 22)", "", "FXR-20261005-WMR16-EURUSD-SP", "Internal", "ASC 830", ""),
       ("Line Share Class", "Share class the line is posted for, when the account is class-specific.", "Journal Line", "Reference (Share Class)", "", "SHC-004512", "SEC Rule 18f-3", "", ""),
       ("Line Instrument", "Instrument the line relates to, for investment, income and gain lines.", "Journal Line", "Reference (Instrument)", "", "INS-00412873", "Internal", "", ""),
       ("Source Portfolio Transaction", "18 portfolio transaction the line books (trade, income, corporate action, fee). One source reference per line is filled.", "Journal Line", "Reference (Portfolio Transaction)", "", "PTXN-2026-001002114", "Internal", "", ""),
       ("Source Settlement Instruction", "26 settlement instruction whose settlement the line records (receivable or payable for investments cleared).", "Journal Line", "Reference (Settlement Instruction, 26)", "", "SETL-2026-01180042", "Internal", "", ""),
       ("Source Fund Order", "29 fund order whose capital stock (subscription, redemption, exchange) the line books.", "Journal Line", "Reference (Fund Order, 29)", "", "FNDO-2026-00418273", "Internal", "", ""),
       ("Source AP Order", "29 ETF authorized participant creation or redemption order whose capital stock (in kind or cash) the line books.", "Journal Line", "Reference (AP Creation / Redemption Order, 29)", "", "ECR-2026-000512", "Rule 6c-11", "", ""),
       ("Source Distribution Declaration", "Distribution declaration the line books (declared, payable or reinvested).", "Journal Line", "Reference (Distribution Declaration, 27)", "", "FDIV-2026-000814", "Internal", "", ""),
     ]),
   ]),
   ("Fund Trial Balance", "Daily balances of each fund ledger account, the basis of the NAV.", [
     ("Fund Trial Balance", [
       ("Balance Book", "Fund accounting book the balance belongs to.", "Trial Balance", "Reference (Fund Accounting Book, 27)", "", "PRD-00981 / US GAAP", "Internal", "", ""),
       ("Balance Fund Ledger Account", "Fund ledger account the balance is for.", "Trial Balance", "Reference (Fund Ledger Account, 27)", "", "US-RIC-STD / 11000", "Internal", "", "Y"),
       ("Balance Date", "Valuation date of the balance.", "Trial Balance", "Date", "ISO 8601", "2026-10-05", "Internal", "", "Y"),
       ("Balance Share Class", "Share class of the balance, for class-specific accounts.", "Trial Balance", "Reference (Share Class)", "", "SHC-004512", "SEC Rule 18f-3", "", ""),
       ("Closing Balance Amount", "Balance at the end of the valuation date, in the book currency.", "Trial Balance", "Amount", "", "USD 244,310,552.28", "ASC 946", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("ABOR Investment Accounting", "FA-ABR",
  "The official quantity and value of each position of a fund and the income accrued on it, and the reconciliation of the book to the investment book. Lots and portfolio transactions come from 18; prices, rate fixings, fair values and FX rates from 22; 27 keeps its own book quantity, records what was applied and books the result.",
  [
   ("ABOR Valuation", "Official quantity and value of an instrument held by a fund on a valuation date.", [
     ("ABOR Valuation Record", [
       ("Valuation Book", "Fund accounting book the valuation belongs to.", "ABOR Valuation", "Reference (Fund Accounting Book, 27)", "", "PRD-00981 / US GAAP", "Internal", "", "Y"),
       ("Valued Instrument", "Instrument valued.", "ABOR Valuation", "Reference (Instrument)", "", "INS-00412873", "Internal", "", "Y"),
       ("ABOR Valuation Date", "Valuation date the value is struck for.", "ABOR Valuation", "Date", "ISO 8601", "2026-10-05", "SEC Rule 2a-4", "", "Y"),
       ("ABOR Quantity", "Quantity of the instrument held by the fund in the book at the valuation point, after trades and corporate actions booked under Rule 2a-4 and any as-of corrections, across all accounted portfolios.", "ABOR Valuation", "Decimal", "", "12000", "SEC Rule 2a-4", "", "Y", "Mastered here; reconciled to 18 holdings by ABOR to IBOR Reconciliation and to the custodian by 28."),
       ("Applied Price", "22 approved price applied to value the position.", "ABOR Valuation", "Reference (Approved Price, 22)", "", "PRICE-20261005-00412873-01-01", "SEC Rule 2a-4", "SEC Rule 2a-5", "Y", "For an own share class held by an own fund, the 22 price is itself a copy of the 27 NAV (22 row rule)."),
       ("Applied Fair Value Determination", "22 fair value determination applied when no readily available market quotation exists.", "ABOR Valuation", "Reference (Fair Value Determination, 22)", "", "FVD-2026-000318", "SEC Rule 2a-5", "ASC 820", "", "Fair value decisions and the valuation committee are 22."),
       ("Applied FX Rate", "22 FX rate observation used to translate the local value.", "ABOR Valuation", "Reference (FX Rate Observation, 22)", "", "FXR-20261005-WMR16-EURUSD-SP", "ASC 830", "", "Y"),
       ("ABOR Valuation Method", "Basis on which the position was valued in the book.", "ABOR Valuation", "Code", "ABOR Valuation Method", "Market Quotation", "SEC Rule 2a-4", "SEC Rule 2a-7", ""),
       ("Local Market Value", "Value of the position in the instrument's currency.", "ABOR Valuation", "Amount", "", "EUR 1,008,000.00", "ASC 946", "", ""),
       ("Base Market Value", "Value of the position in the book reporting currency.", "ABOR Valuation", "Amount", "", "USD 1,177,646.40", "ASC 946", "", "Y"),
       ("Identified Cost Amount", "Cost of the position under the book's accounting basis, in the book currency: for GAAP books the 18 lot Original Cost Base of the remaining quantity plus amortization and accretion booked here; for a Tax Basis book the 18 Adjusted Cost Basis Base.", "ABOR Valuation", "Amount", "", "USD 1,040,220.00", "ASC 946", "IRC Section 1012", ""),
       ("Unrealized Gain Loss Amount", "Base market value less identified cost.", "ABOR Valuation", "Amount", "", "USD 137,426.40", "ASC 946", "", ""),
     ]),
   ]),
   ("ABOR to IBOR Reconciliation", "Comparison of the book's quantity with the 18 holdings of each accounted portfolio (CD-196: reconciliations by producer; custodian reconciliation is 28).", [
     ("ABOR to IBOR Reconciliation", [
       ("Reconciled Book", "Fund accounting book reconciled.", "ABOR-IBOR Reconciliation", "Reference (Fund Accounting Book, 27)", "", "PRD-00981 / US GAAP", "Internal", "", ""),
       ("Reconciled Portfolio", "18 portfolio accounted in the book.", "ABOR-IBOR Reconciliation", "Reference (Portfolio)", "", "PORT-000412", "Internal", "", ""),
       ("Reconciled Instrument", "Instrument compared.", "ABOR-IBOR Reconciliation", "Reference (Instrument)", "", "INS-00412873", "Internal", "", ""),
       ("Reconciliation Date", "Valuation date compared.", "ABOR-IBOR Reconciliation", "Date", "ISO 8601", "2026-10-05", "Internal", "", ""),
       ("Compared Holding", "18 portfolio holding compared (accounting view), when the portfolio holds the instrument.", "ABOR-IBOR Reconciliation", "Reference (Portfolio Holding)", "", "HLD-2026100500041201", "Internal", "", ""),
       ("ABOR Attributed Quantity", "Book quantity attributed to the portfolio; the whole ABOR quantity when the book accounts for one portfolio.", "ABOR-IBOR Reconciliation", "Decimal", "", "12000", "Internal", "", ""),
       ("IBOR Quantity", "Quantity on the compared 18 holding.", "ABOR-IBOR Reconciliation", "Decimal", "", "12000", "Internal", "", "", "Derived copy of 18 Portfolio Holding quantity."),
       ("ABOR-IBOR Reconciliation Result", "Outcome of the comparison.", "ABOR-IBOR Reconciliation", "Code", "Shared: Reconciliation Status", "Reconciled", "Internal", "", "Y"),
       ("Difference Explanation", "Reason for a difference (timing of Rule 2a-4 booking, as-of correction, pending corporate action).", "ABOR-IBOR Reconciliation", "Text", "", "", "Internal", "", ""),
     ]),
   ]),
   ("Income Accrual", "Interest, dividends, amortization and accretion accrued by a fund on each instrument and date.", [
     ("Income Accrual", [
       ("Accrual Book", "Fund accounting book the accrual belongs to.", "Income Accrual", "Reference (Fund Accounting Book, 27)", "", "PRD-00981 / US GAAP", "Internal", "", ""),
       ("Accrual Instrument", "Instrument the income is earned on.", "Income Accrual", "Reference (Instrument)", "", "INS-00412873", "Internal", "", ""),
       ("Income Accrual Date", "Date the accrual is booked for.", "Income Accrual", "Date", "ISO 8601", "2026-10-05", "Internal", "", ""),
       ("Income Type", "Kind of income accrued.", "Income Accrual", "Code", "Income Type", "Interest", "ASC 946", "", ""),
       ("Accrual Coupon Period", "17 coupon schedule period the interest accrues in, keyed by instrument and coupon period number.", "Income Accrual", "Reference (Coupon Schedule, 17)", "", "INS-00412873 / 3", "Internal", "", ""),
       ("Applied Rate Fixing", "22 reference rate fixing that set the coupon of a floating-rate period.", "Income Accrual", "Reference (Reference Rate Fixing, 22)", "", "SOFR / ON / 2026-08-14", "Internal", "", ""),
       ("Coupon Rate Applied", "Annual all-in rate used for the accrual. Row rule: for fixed and step instruments it is the 17 coupon rate of the period (copy); for floating-rate instruments it is computed here from the applied 22 fixing plus the 17 spread.", "Income Accrual", "Percentage", "", "4.625%", "Internal", "", "", "Flagged Derived copy (17); mastered here for floating-rate rows (plan §4 item 9)."),
       ("Related Corporate Action Event", "17 dividend or income event the accrual books on ex-date.", "Income Accrual", "Reference (Corporate Action Event)", "", "CAE-2026-0012345", "Internal", "", ""),
       ("Daily Accrual Amount", "Income accrued for the date, in the instrument currency.", "Income Accrual", "Amount", "", "EUR 1,284.72", "ASC 946", "", "Y"),
       ("Accrued Income Balance", "Income accrued and not yet received at the end of the date.", "Income Accrual", "Amount", "", "EUR 26,980.11", "ASC 946", "", "Y"),
       ("Related Income Collection", "28 income collection record that receives the cash, keyed by safekeeping account, instrument and payment date.", "Income Accrual", "Reference (Income Collection, 28)", "", "SKA-004412 / INS-00412873 / 2026-11-15", "Internal", "", "", "28 compares expected (this accrual) with received income; composite keys to agree with 28 (proposals_27)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("NAV Calculation", "FA-NVC",
  "The official net asset value struck for each fund and share class on each valuation date, by calculation source and version, Rule 18f-3 class allocation, CIT unit value detail and the release of each NAV for use. Per-channel transmission is 29 (Price & Rate Transmission).",
  [
   ("Fund NAV", "Fund-level NAV calculation on a valuation date, by calculation source and version.", [
     ("Fund NAV Calculation", [
       ("NAV Book", "Fund accounting book the NAV is computed from; it identifies the fund.", "Fund NAV", "Reference (Fund Accounting Book, 27)", "", "PRD-00981 / US GAAP", "Internal", "", "Y"),
       ("Valuation Date", "Business date the NAV is struck for.", "Fund NAV", "Date", "ISO 8601", "2026-10-05", "SEC Rule 22c-1", "SEC Rule 2a-4", "Y"),
       ("NAV Calculation Source", "Who calculated this NAV: the official preparer (fund accounting or the administrator) or the firm's shadow calculation of an administrator NAV.", "Fund NAV", "Code", "NAV Calculation Source", "Administrator", "Internal", "", "Y", "Each source has its own version sequence; only the official preparer's Final version is the dealing NAV."),
       ("NAV Version Number", "Sequence of the calculation for the book, valuation date and calculation source.", "Fund NAV", "Integer", "", "1", "Internal", "", ""),
       ("NAV Version Type", "Why this version exists.", "Fund NAV", "Code", "NAV Version Type", "Original", "Internal", "", ""),
       ("NAV Status", "Lifecycle state of this version.", "Fund NAV", "Code", "NAV Status", "Final", "Internal", "", "Y"),
       ("Total Assets Amount", "Value of all assets of the fund, in the book currency.", "Fund NAV", "Amount", "", "USD 252,104,331.90", "ASC 946", "SEC Regulation S-X Article 6", ""),
       ("Total Liabilities Amount", "Value of all liabilities of the fund, including accrued expenses and payables.", "Fund NAV", "Amount", "", "USD 1,793,779.62", "ASC 946", "", ""),
       ("Fund Net Assets Amount", "Total assets less total liabilities.", "Fund NAV", "Amount", "", "USD 250,310,552.28", "ASC 946", "SEC Rule 2a-4", "Y"),
       ("Capital Activity Data Basis", "Whether the capital stock activity included is final or estimated.", "Fund NAV", "Code", "Shared: Data Basis", "Reported / Actual", "Internal", "", ""),
       ("NAV Approval Status", "Approval state of the calculation.", "Fund NAV", "Code", "Shared: Approval Status", "Approved", "Internal", "", "Y"),
       ("NAV Approved By", "Employee who approved the NAV for release.", "Fund NAV", "Reference (Employee)", "", "EMP-02240", "Internal", "", "", "PII (internal staff)."),
     ]),
   ]),
   ("Share Class NAV", "The official per-share value of each share class, held once and referenced everywhere else.", [
     ("Share Class NAV", [
       ("Share Class NAV ID", "Unique identifier of the share class NAV record.", "Class NAV", "Identifier", "", "NAV-2026100500451201", "Internal", "", "Y", "Format NAV-<valuation date YYYYMMDD><share class number, 6 digits><version, 2 digits>."),
       ("NAV Share Class", "Share class (or CIT unit class) the NAV is for.", "Class NAV", "Reference (Share Class)", "", "SHC-004512", "SEC Rule 18f-3", "", "Y"),
       ("Parent NAV Calculation", "Fund NAV calculation the class NAV belongs to; it gives the valuation date, calculation source and version.", "Class NAV", "Reference (Fund NAV Calculation, 27)", "", "PRD-00981 / US GAAP / 2026-10-05 / Administrator / 1", "Internal", "", ""),
       ("NAV per Share", "Official net asset value per share or unit, rounded to the 01 NAV decimal precision.", "Class NAV", "Decimal", "", "24.37", "SEC Rule 22c-1", "SEC Rule 2a-4", "Y", "The price at which every shareholder order of the date is filled; 06 Transaction Price is as delivered."),
       ("Class Net Assets Amount", "Net assets attributable to the class.", "Class NAV", "Amount", "", "USD 81,402,118.07", "SEC Rule 18f-3", "ASC 946", "Y"),
       ("Shares Outstanding", "Shares or units of the class outstanding at the valuation point, after the capital stock activity booked for the date.", "Class NAV", "Decimal", "", "3340024.118", "ASC 946", "", "Y", "Mastered here as booked capital stock; proved against the TA register by the 29 TA Control Check (SME question 3)."),
       ("NAV Currency", "Currency the NAV per share is expressed in.", "Class NAV", "Code", "ISO 4217", "USD", "ISO 4217", "", "", "Derived copy of 01 Share Class currency."),
       ("Offer Price", "Price per share including the maximum front-end sales charge, for load classes.", "Class NAV", "Decimal", "", "25.79", "SEC Form N-1A", "", ""),
       ("Swung NAV per Share", "Price per share after the swing factor, when a swing was applied.", "Class NAV", "Decimal", "", "24.41", "SEC Rule 22c-1", "", "Y"),
       ("Applied Swing Decision", "Swing pricing decision applied to the class price.", "Class NAV", "Reference (Swing Pricing Decision, 27)", "", "SWG-2026-1005-00981", "Internal", "", ""),
       ("Market-Based NAV per Share", "NAV per share of a money market fund computed with market-based values, to four decimals.", "Class NAV", "Decimal", "", "1.0002", "SEC Rule 2a-7", "SEC Form N-MFP", ""),
     ]),
     ("CIT Unit Value Detail", [
       ("CIT Valuation Basis", "Basis on which the unit value of the collective investment trust class is determined.", "CIT Unit Value", "Code", "CIT Valuation Basis", "Fair Value - Daily", "12 CFR 9.18", "", ""),
       ("Admission and Withdrawal Date Indicator", "Whether participating plans may enter or withdraw at this unit value (admissions and withdrawals occur only on valuation dates).", "CIT Unit Value", "Boolean", "", "Y", "12 CFR 9.18", "", ""),
     ]),
   ]),
   ("Class Allocation", "Rule 18f-3 allocation of common income, expenses and gains of a NAV calculation to its share classes.", [
     ("Class Allocation", [
       ("Allocation NAV Calculation", "Fund NAV calculation the allocation belongs to.", "Class Allocation", "Reference (Fund NAV Calculation, 27)", "", "PRD-00981 / US GAAP / 2026-10-05 / Administrator / 1", "Internal", "", ""),
       ("Allocation Share Class", "Share class receiving the allocation.", "Class Allocation", "Reference (Share Class)", "", "SHC-004512", "SEC Rule 18f-3", "", ""),
       ("Class Allocation Item", "Fund-level item being allocated.", "Class Allocation", "Code", "Class Allocation Item", "Net Investment Income Before Class Expenses", "SEC Rule 18f-3", "", ""),
       ("Class Allocation Method", "Method used to allocate the item.", "Class Allocation", "Code", "Class Allocation Method", "Relative Net Assets", "SEC Rule 18f-3", "", ""),
       ("Allocation Ratio", "Share of the item allocated to the class.", "Class Allocation", "Percentage", "", "32.5194%", "SEC Rule 18f-3", "", ""),
       ("Allocation Basis Amount", "Value the ratio is computed from (prior-day class net assets or settled share value).", "Class Allocation", "Amount", "", "USD 81,060,204.33", "SEC Rule 18f-3", "", "", "The class net assets of the day are held only on Share Class NAV."),
       ("Allocated Amount", "Amount of the item allocated to the class.", "Class Allocation", "Amount", "", "USD 11,402.84", "SEC Rule 18f-3", "", "Y"),
     ]),
   ]),
   ("NAV Release", "Each release of a share class NAV for use by dealing, transmission and publication. Per-channel transmission (timestamp, deadline, recipient, format) is 29 Price & Rate Transmission, which references the release.", [
     ("NAV Dissemination", [
       ("Released NAV", "Share class NAV released; the values are read from it, never repeated.", "NAV Release", "Reference (Share Class NAV, 27)", "", "NAV-2026100500451201", "Internal", "", "Y"),
       ("Release Sequence", "Sequence of releases for the share class and valuation date (1 for the first release, higher for corrections).", "NAV Release", "Integer", "", "1", "Internal", "", ""),
       ("Release Timestamp", "Date and time fund accounting released the NAV for transmission and publication.", "NAV Release", "Timestamp", "ISO 8601", "2026-10-05T18:05:00-04:00", "SEC Rule 22c-1", "", ""),
       ("NAV Release Status", "State of the release.", "NAV Release", "Code", "NAV Release Status", "Released", "Internal", "", ""),
       ("Corrected Release Indicator", "Whether the release replaces an earlier release for the same class and date.", "NAV Release", "Boolean", "", "N", "DTCC Mutual Fund Profile Service", "", "Y"),
       ("Corrected Release", "Earlier release that this release corrects, keyed by released NAV and release sequence.", "NAV Release", "Reference (NAV Dissemination, 27)", "", "NAV-2026100500451201 / 1", "Internal", "", "", "Vendor and platform deliveries are 29 transmissions."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Swing Pricing & Anti-Dilution", "FA-SWP",
  "Operating parameters of swing pricing for a fund that adopts it under SEC Rule 22c-1(a)(3), and the decision taken on each valuation date. The mechanism and maximum swing factor are 01 terms (CD-190); the net activity estimate comes from 29 orders.",
  [
   ("Swing Pricing Parameter", "Effective-dated thresholds and factors approved for a fund.", [
     ("Swing Pricing Parameter", [
       ("Parameter Fund", "Fund the parameters apply to.", "Swing Parameter", "Reference (Investment Product)", "", "PRD-01022", "Internal", "", "Y"),
       ("Swing Factor Method", "How the swing factor is determined.", "Swing Parameter", "Code", "Swing Factor Method", "Fixed Factor", "SEC Rule 22c-1", "Internal", ""),
       ("Swing Threshold", "Net capital activity, as a percentage of net assets, above which the price swings (zero for full swing).", "Swing Parameter", "Percentage", "", "2.00%", "SEC Rule 22c-1", "", "Y"),
       ("Inflow Swing Factor", "Factor applied to the NAV when net activity is an inflow above the threshold.", "Swing Parameter", "Percentage", "", "0.35%", "SEC Rule 22c-1", "", "Y", "Must not exceed the 01 Maximum Swing Factor."),
       ("Outflow Swing Factor", "Factor applied to the NAV when net activity is an outflow above the threshold.", "Swing Parameter", "Percentage", "", "0.40%", "SEC Rule 22c-1", "", "Y", "Must not exceed the 01 Maximum Swing Factor."),
       ("Parameter Effective From", "Date the parameters took effect.", "Swing Parameter", "Date", "ISO 8601", "2026-07-01", "Internal", "", ""),
       ("Parameter Effective To", "Date the parameters ceased to apply.", "Swing Parameter", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Swing Pricing Decision", "The swing decision taken for a fund on a valuation date.", [
     ("Swing Pricing Decision", [
       ("Swing Pricing Decision ID", "Unique identifier of the decision.", "Swing Decision", "Identifier", "", "SWG-2026-1005-00981", "Internal", "", "Y"),
       ("Decision Fund", "Fund the decision is for; equals the fund of the applied parameter set.", "Swing Decision", "Reference (Investment Product)", "", "PRD-01022", "Internal", "", ""),
       ("Decision Valuation Date", "Valuation date the decision applies to.", "Swing Decision", "Date", "ISO 8601", "2026-10-05", "SEC Rule 22c-1", "", ""),
       ("Applied Swing Parameter", "Parameter set in force on the date, keyed by fund and effective date.", "Swing Decision", "Reference (Swing Pricing Parameter, 27)", "", "PRD-01022 / 2026-07-01", "Internal", "", ""),
       ("Net Capital Activity Estimate", "Net subscriptions less redemptions known at the decision time, from 29 fund orders.", "Swing Decision", "Amount", "", "USD -6,210,400.00", "SEC Rule 22c-1", "", "Y"),
       ("Net Activity Direction", "Whether net activity was an inflow or an outflow; the price swings up on inflows and down on outflows.", "Swing Decision", "Code", "Shared: Flow Direction", "Outflow", "Internal", "", "", "'Neutral' is used here for zero net activity."),
       ("Threshold Breached Indicator", "Whether net activity exceeded the swing threshold.", "Swing Decision", "Boolean", "", "Y", "SEC Rule 22c-1", "", "Y"),
       ("Swing Factor Applied", "Factor actually applied to the NAV (zero when no swing).", "Swing Decision", "Percentage", "", "0.40%", "SEC Rule 22c-1", "", "Y"),
       ("Decision Approved By", "Employee who approved the decision.", "Swing Decision", "Reference (Employee)", "", "EMP-02240", "Internal", "", "", "PII (internal staff)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Fund Expenses", "FA-EXP",
  "What the fund budgets, accrues and pays for its own expenses, and how expense caps and waivers are applied. Cap and fee terms are 01; the adviser's revenue and waiver impact are 10 (CD-188); fund payables are kept here, not in 19.",
  [
   ("Fund Expense Budget", "Annual expense budgets that drive daily accrual amounts.", [
     ("Fund Expense Budget", [
       ("Budget Fund", "Fund the budget is for.", "Expense Budget", "Reference (Investment Product)", "", "PRD-00981", "Internal", "", ""),
       ("Budget Expense Type", "Expense the budget covers.", "Expense Budget", "Code", "Fund Expense Type", "Audit Fee", "SEC Regulation S-X Article 6", "", ""),
       ("Budget Fiscal Year End", "Last day of the fund fiscal year the budget covers.", "Expense Budget", "Date", "ISO 8601", "2027-10-31", "Internal", "", ""),
       ("Budgeted Amount", "Amount budgeted for the fiscal year.", "Expense Budget", "Amount", "", "USD 48,500.00", "Internal", "", "Y"),
       ("Budget Accrual Method", "How the budget is spread over the year.", "Expense Budget", "Code", "Accrual Method", "Fixed Daily Amount", "Internal", "", ""),
     ]),
   ]),
   ("Fund Expense Accrual", "Daily accrual of each expense of a fund or class.", [
     ("Fund Expense Accrual", [
       ("Accrual Fund", "Fund bearing the expense.", "Fund Expense Accrual", "Reference (Investment Product)", "", "PRD-00981", "Internal", "", ""),
       ("Accrual Share Class", "Share class bearing the expense, for class-specific expenses (distribution and service fees, transfer agency fees by class).", "Fund Expense Accrual", "Reference (Share Class)", "", "SHC-004512", "SEC Rule 18f-3", "", ""),
       ("Expense Accrual Date", "Date the accrual is booked for.", "Fund Expense Accrual", "Date", "ISO 8601", "2026-10-05", "Internal", "", ""),
       ("Accrual Expense Type", "Expense accrued.", "Fund Expense Accrual", "Code", "Fund Expense Type", "Management Fee", "SEC Regulation S-X Article 6", "", "Y"),
       ("Applied Fee Schedule", "01 fund fee schedule version the asset-based fee is computed under.", "Fund Expense Accrual", "Reference (Management Fee, 01)", "", "FSCH-00981-03", "Internal", "", "", "Re-typed from Reference (Fee Schedule): 'Fee Schedule' is the 47 client fee schedule (CLFEE-, CW-051)."),
       ("Fee Rate Applied", "Annual rate applied to the accrual basis for asset-based fees. Row rule: for a flat-rate schedule it is the 01 rate (copy); for a tiered schedule it is the blended effective rate computed here across breakpoints; blank for fixed and budgeted expenses.", "Fund Expense Accrual", "Percentage", "", "0.6500%", "Internal", "", "", "Flagged Derived copy (01); mastered here for blended breakpoint rows (plan §4 item 9)."),
       ("Accrual Basis Amount", "Net assets the asset-based fee is computed on (normally prior-day net assets).", "Fund Expense Accrual", "Amount", "", "USD 249,880,112.40", "Internal", "", ""),
       ("Accrued Expense Amount", "Expense accrued for the date.", "Fund Expense Accrual", "Amount", "", "USD 4,449.88", "ASC 946", "", "Y", "A management fee accrued here is the fund side of the adviser's revenue in 10 (two records, CD-186)."),
       ("Accrued Expense Balance", "Expense accrued and unpaid at the end of the date.", "Fund Expense Accrual", "Amount", "", "USD 133,496.40", "ASC 946", "", ""),
     ]),
   ]),
   ("Expense Cap & Waiver Accrual", "Daily application of the 01 expense cap and fee waivers to a share class, the source of the 10 waiver amounts.", [
     ("Expense Cap & Waiver Accrual", [
       ("Waiver Share Class", "Share class the cap or waiver applies to.", "Cap & Waiver", "Reference (Share Class)", "", "SHC-004512", "SEC Form N-1A", "", ""),
       ("Waiver Accrual Date", "Date of the accrual.", "Cap & Waiver", "Date", "ISO 8601", "2026-10-05", "Internal", "", ""),
       ("Waiver Type", "Kind of fee support applied.", "Cap & Waiver", "Code", "Waiver Type", "Contractual Fee Waiver", "SEC Form N-1A", "", ""),
       ("Expense Cap Rate Applied", "Annual expense cap in force for the class on the date.", "Cap & Waiver", "Percentage", "", "0.95%", "SEC Form N-1A", "", "", "Derived copy of 01 Cost Disclosure Expense Cap Rate."),
       ("Waived Fee Amount", "Fee waived by the adviser for the date.", "Cap & Waiver", "Amount", "", "USD 291.40", "SEC Form N-1A", "ASC 946", "Y", "Source of 10 Waiver Record Waived Fee Amount (Derived copy there, CD-188)."),
       ("Reimbursed Expense Amount", "Expense the adviser reimburses to the fund for the date.", "Cap & Waiver", "Amount", "", "USD 0.00", "SEC Form N-1A", "ASC 946", "Y", "Source of 10 Waiver Record Reimbursed Expense Amount (Derived copy there, CD-188)."),
       ("Recoupable Balance", "Waived and reimbursed amounts the adviser may still recoup from the class under the agreement.", "Cap & Waiver", "Amount", "", "USD 214,880.12", "SEC Form N-1A", "ASC 946", ""),
       ("Adviser Recoupment Receivable", "19 receivable item of the adviser for recoupment owed by the fund.", "Cap & Waiver", "Reference (Receivable Item)", "", "1400072215", "Internal", "", "", "Adviser side of the same event (19 Debtor Fund Product)."),
       ("Adviser Reimbursement Payable", "19 payable record of the adviser for the reimbursement it owes the fund.", "Cap & Waiver", "Reference (Payable Invoice)", "", "APV-2026-0018833", "Internal", "", "", "CD-188: 19 holds the resulting receivable or payable; confirm the 19 payable object for non-invoice payables."),
     ]),
   ]),
   ("Fund Expense Payment", "Payments of fund expenses to service providers out of fund assets.", [
     ("Fund Expense Payment", [
       ("Fund Payment Reference", "Reference of the payment in the fund's books.", "Expense Payment", "Identifier", "", "00981-2026-0912", "Internal", "", ""),
       ("Paying Fund", "Fund that makes the payment.", "Expense Payment", "Reference (Investment Product)", "", "PRD-00981", "Internal", "", ""),
       ("Expense Payee", "Service provider paid (custodian, auditor, administrator, legal counsel, directors' fees agent).", "Expense Payment", "Reference (Party)", "", "PTY-100912", "Internal", "", ""),
       ("Payment Expense Type", "Expense the payment settles.", "Expense Payment", "Code", "Fund Expense Type", "Custody Fee", "Internal", "", ""),
       ("Payment Amount", "Amount paid.", "Expense Payment", "Amount", "", "USD 18,422.10", "Internal", "", "Y"),
       ("Payment Date", "Date the payment was made.", "Expense Payment", "Date", "ISO 8601", "2026-10-02", "Internal", "", ""),
       ("Paying Safekeeping Account", "28 cash account of the fund the payment was made from.", "Expense Payment", "Reference (Safekeeping Account, 28)", "", "SKA-004413", "Internal", "", ""),
       ("Fund Payment Status", "Status of the payment.", "Expense Payment", "Code", "Shared: Outgoing Payment Status", "Paid / Settled", "Internal", "", ""),
       ("Paid by Adviser Indicator", "Whether the adviser paid the expense and is reimbursed by the fund rather than the fund paying directly.", "Expense Payment", "Boolean", "", "N", "Internal", "", "", "SME question 9."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Income & Distributions", "FA-INC",
  "The distributions a fund declares, their tax character, and the estimates of distributable income behind them. Distribution policy and frequency are 01 terms; reinvestment transactions are 06; tax forms are 13; shareholder elections are 15 (CD-192).",
  [
   ("Distribution Declaration", "A dividend or capital gain distribution declared on a share class; daily-dividend funds declare one row per day.", [
     ("Distribution Declaration", [
       ("Distribution Declaration ID", "Unique identifier of the declaration.", "Distribution", "Identifier", "", "FDIV-2026-000814", "Internal", "", "Y"),
       ("Declaring Share Class", "Share class the distribution is declared on.", "Distribution", "Reference (Share Class)", "", "SHC-004512", "Internal", "", "Y"),
       ("Distribution Type", "Income source the distribution is paid from.", "Distribution", "Code", "Distribution Type", "Net Investment Income", "IRC Section 852", "", "Y"),
       ("Daily Dividend Indicator", "Whether the row is a daily declaration of a daily-dividend fund (accrued daily, paid monthly); the daily rate is held only here.", "Distribution", "Boolean", "", "N", "SEC Rule 2a-7", "", ""),
       ("Spillback Indicator", "Whether the distribution is declared after year-end and treated as paid in the prior tax year.", "Distribution", "Boolean", "", "N", "IRC Section 855", "", ""),
       ("Declaration Date", "Date the board or its delegate declared the distribution.", "Distribution", "Date", "ISO 8601", "2026-12-14", "Internal", "", ""),
       ("Record Date", "Date on which shareholders of record are entitled.", "Distribution", "Date", "ISO 8601", "2026-12-15", "Internal", "", "Y"),
       ("Ex-Date", "Date the NAV is reduced by the distribution.", "Distribution", "Date", "ISO 8601", "2026-12-16", "Internal", "", "Y"),
       ("Payable Date", "Date the distribution is paid or reinvested.", "Distribution", "Date", "ISO 8601", "2026-12-17", "Internal", "", "Y"),
       ("Distribution Rate per Share", "Amount declared per share or unit.", "Distribution", "Decimal", "", "0.412500", "IRC Section 852", "", "Y"),
       ("Reinvest NAV", "Share class NAV at which distributions are reinvested.", "Distribution", "Reference (Share Class NAV, 27)", "", "NAV-2026121600451201", "Internal", "", ""),
       ("Excise Distribution Indicator", "Whether the distribution is made to meet the excise distribution requirement.", "Distribution", "Boolean", "", "Y", "IRC Section 4982", "", ""),
       ("Section 19 Notice Required Indicator", "Whether the distribution includes sources other than net investment income, so a written statement of source must accompany it.", "Distribution", "Boolean", "", "N", "SEC Rule 19a-1", "", ""),
     ]),
     ("Distribution Character", [
       ("Distribution Character Type", "Tax character of a part of the distribution.", "Distribution Character", "Code", "Distribution Character", "Qualified Dividend Income", "IRC Section 854", "IRS Form 1099-DIV", "Y"),
       ("Character Data Basis", "Whether the row is the estimate made at declaration (Rule 19a-1) or the final character after year-end; both rows are kept.", "Distribution Character", "Code", "Shared: Data Basis", "Reported / Actual", "SEC Rule 19a-1", "", "", "13 Tax Form Record reads the final rows."),
       ("Character Rate per Share", "Part of the rate per share with this character.", "Distribution Character", "Decimal", "", "0.185600", "IRS Form 1099-DIV", "", "Y"),
     ]),
   ]),
   ("Distributable Income Estimate", "Estimates of undistributed income and gains for a distribution requirement period.", [
     ("Distributable Income Estimate", [
       ("Estimate Fund", "Fund the estimate is for.", "Distributable Income", "Reference (Investment Product)", "", "PRD-00981", "Internal", "", ""),
       ("Distribution Requirement Period", "Period whose distribution requirement the estimate addresses.", "Distributable Income", "Code", "Distribution Requirement Period", "Excise Year - Capital Gains", "IRC Section 4982", "IRC Section 852", ""),
       ("Requirement Period End Date", "Last day of the requirement period.", "Distributable Income", "Date", "ISO 8601", "2026-10-31", "IRC Section 4982", "", ""),
       ("Estimate Date", "Date the estimate was made.", "Distributable Income", "Date", "ISO 8601", "2026-10-05", "Internal", "", ""),
       ("Undistributed Net Investment Income", "Ordinary income not yet distributed.", "Distributable Income", "Amount", "", "USD 1,204,330.12", "IRC Section 852", "", "Y"),
       ("Undistributed Short-Term Capital Gain", "Net short-term gains not yet distributed.", "Distributable Income", "Amount", "", "USD 312,004.00", "IRC Section 852", "", ""),
       ("Undistributed Long-Term Capital Gain", "Net long-term gains not yet distributed.", "Distributable Income", "Amount", "", "USD 4,880,112.40", "IRC Section 852", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Fund Tax", "FA-FTX",
  "The fund's tax year by jurisdiction and regime, its book-tax differences and the RIC asset and income tests. RIC qualification status and filings belong to 35; corporate tax is 19; partner-level allocations of private funds are 30. If a Tax domain is created, this family moves unchanged (CD-191, CD-149).",
  [
   ("Fund Tax Year Record", "A fund's tax year in one jurisdiction. For partnership regimes (feeder funds organized as partnerships) only fund-level results are held here; investor Schedules K-1 are 13 tax documents from the feeder administrator.", [
     ("Fund Tax Year Record", [
       ("Fund Tax Year Record ID", "Unique identifier of the tax year record.", "Fund Tax Year", "Identifier", "", "FTAX-00981-2026-US", "Internal", "", "Y"),
       ("Tax Year Fund", "Fund the tax year is for.", "Fund Tax Year", "Reference (Investment Product)", "", "PRD-00981", "Internal", "", ""),
       ("Tax Year End Date", "Last day of the tax year.", "Fund Tax Year", "Date", "ISO 8601", "2026-10-31", "IRC Section 852", "", ""),
       ("Tax Jurisdiction", "Country whose tax the record covers.", "Fund Tax Year", "Code", "ISO 3166-1 alpha-2", "US", "ISO 3166", "", ""),
       ("Fund Tax Regime", "Tax regime the fund is taxed under in the jurisdiction.", "Fund Tax Year", "Code", "Fund Tax Regime", "Regulated Investment Company", "IRC Section 851", "", "Y", "Qualification status for the year is 35 RIC Qualification Determination."),
       ("Investment Company Taxable Income", "Taxable income of the year before the dividends-paid deduction (RIC regime only).", "Fund Tax Year", "Amount", "", "USD 6,402,118.07", "IRC Section 852", "", "Y"),
       ("Net Capital Gain Amount", "Net long-term gain over net short-term loss for the year.", "Fund Tax Year", "Amount", "", "USD 9,804,330.00", "IRC Section 852", "", ""),
       ("Required Excise Distribution", "Distribution needed in the calendar year to avoid the excise tax (RIC regime only).", "Fund Tax Year", "Amount", "", "USD 16,880,120.00", "IRC Section 4982", "", "Y"),
       ("Excise Tax Amount", "Excise tax payable on undistributed income (RIC regime only).", "Fund Tax Year", "Amount", "", "USD 0.00", "IRC Section 4982", "IRS Form 8613", ""),
       ("Short-Term Capital Loss Carryforward", "Short-term capital losses carried forward at year-end.", "Fund Tax Year", "Amount", "", "USD 0.00", "IRC Section 1212", "", ""),
       ("Long-Term Capital Loss Carryforward", "Long-term capital losses carried forward at year-end.", "Fund Tax Year", "Amount", "", "USD 1,204,000.00", "IRC Section 1212", "", ""),
       ("Fund Tax Return Type", "Return prepared for the year; filing evidence is a 35 Fund Regulatory Filing (reference proposed, stage3_consolidation_notes §3 item 17).", "Fund Tax Year", "Code", "Fund Tax Return Type", "Form 1120-RIC", "IRS Form 1120-RIC", "", ""),
     ]),
   ]),
   ("Book-Tax Difference", "Differences between book and tax results of a fund tax year.", [
     ("Book-Tax Difference", [
       ("Difference Tax Year", "Fund tax year record the difference belongs to.", "Book-Tax Difference", "Reference (Fund Tax Year Record, 27)", "", "FTAX-00981-2026-US", "Internal", "", ""),
       ("Book-Tax Difference Type", "Kind of difference.", "Book-Tax Difference", "Code", "Book-Tax Difference Type", "In-Kind Redemption Gain", "IRC Section 852", "", "Y"),
       ("Difference Instrument", "Instrument the difference arises on, where instrument-specific.", "Book-Tax Difference", "Reference (Instrument)", "", "INS-00412873", "Internal", "", ""),
       ("Difference Amount", "Amount by which taxable results exceed book results (negative when lower).", "Book-Tax Difference", "Amount", "", "USD -2,410,220.00", "Internal", "", "Y"),
       ("Permanent Difference Indicator", "Whether the difference is permanent rather than timing.", "Book-Tax Difference", "Boolean", "", "Y", "ASC 946", "", ""),
       ("Capital Reclassification Amount", "Amount reclassified between paid-in capital and distributable earnings for a permanent difference (for example ETF in-kind redemption gains).", "Book-Tax Difference", "Amount", "", "USD 2,410,220.00", "ASC 946", "", ""),
     ]),
   ]),
   ("RIC Test Result", "Results of the Subchapter M asset diversification and gross income tests.", [
     ("RIC Test Result", [
       ("Tested Fund", "Fund tested.", "RIC Test", "Reference (Investment Product)", "", "PRD-00981", "IRC Section 851", "", ""),
       ("RIC Test Type", "Test performed.", "RIC Test", "Code", "RIC Test Type", "Asset Diversification - 50% Test", "IRC Section 851", "", "Y"),
       ("RIC Test Date", "Date the test was measured (quarter-end for asset tests, year-end for the income test).", "RIC Test", "Date", "ISO 8601", "2026-09-30", "IRC Section 851", "", ""),
       ("Measured Ratio", "Value the test measured.", "RIC Test", "Percentage", "", "71.40%", "IRC Section 851", "", "Y"),
       ("Required Threshold", "Limit or minimum the measured value is compared with.", "RIC Test", "Percentage", "", "50.00%", "IRC Section 851", "", ""),
       ("Test Passed Indicator", "Whether the fund met the test.", "RIC Test", "Boolean", "", "Y", "IRC Section 851", "", "Y"),
       ("Cure Deadline Date", "Last day to cure a failure within the statutory cure period.", "RIC Test", "Date", "ISO 8601", "", "IRC Section 851", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("NAV Errors & Corrections", "FA-COR",
  "NAV errors found in a fund, their materiality under the applicable policy, how they were corrected at fund level and their impact on each share class and date. Shareholder remediation and accounts impacted are 13 (CD-189); correction transactions are 06; as-of orders are 29.",
  [
   ("NAV Error Case", "One NAV error of a fund, from discovery to correction.", [
     ("NAV Error Case", [
       ("NAV Error Case ID", "Unique identifier of the case.", "NAV Error", "Identifier", "", "NEC-2026-0031", "Internal", "", "Y"),
       ("Error Fund", "Fund whose NAV was misstated.", "NAV Error", "Reference (Investment Product)", "", "PRD-00981", "Internal", "", ""),
       ("NAV Error Type", "What was wrong in the NAV.", "NAV Error", "Code", "NAV Error Type", "Pricing Error", "Internal", "", "Y"),
       ("NAV Error Cause", "Why the error happened.", "NAV Error", "Code", "NAV Error Cause", "Vendor Data Error", "Internal", "", ""),
       ("Error Discovery Date", "Date the error was found.", "NAV Error", "Date", "ISO 8601", "2026-10-07", "Internal", "", ""),
       ("First Affected Valuation Date", "First valuation date with a misstated NAV.", "NAV Error", "Date", "ISO 8601", "2026-10-02", "Internal", "", ""),
       ("Last Affected Valuation Date", "Last valuation date with a misstated NAV.", "NAV Error", "Date", "ISO 8601", "2026-10-06", "Internal", "", ""),
       ("Materiality Basis", "Policy under which materiality is judged: the fund board's NAV error policy, which follows SEC staff practice and industry practice, or the trustee's policy for a CIT.", "NAV Error", "Code", "Materiality Basis", "Board-Approved Policy (US)", "Internal", "", "", "No SEC rule sets a NAV error threshold; the policy source is SEC staff practice and ICI industry practice (confirm)."),
       ("Materiality Threshold", "Error size, as a percentage of the correct NAV, that an error must reach or exceed to be material under the basis.", "NAV Error", "Percentage", "", "0.50%", "Internal", "", "Y", "Threshold values by fund type to be confirmed (SME question 4)."),
       ("Material Error Indicator", "Whether the error is material: true when any NAV Error Impact row of the case reaches the threshold.", "NAV Error", "Boolean", "", "Y", "Internal", "", "Y"),
       ("Error Severity", "Severity assigned to the case for escalation.", "NAV Error", "Code", "Shared: Severity", "High", "Internal", "", ""),
       ("Fund Loss Amount", "Loss suffered by the fund that must be made good.", "NAV Error", "Amount", "", "USD 18,204.30", "Internal", "", "Y"),
       ("Reimbursing Entity", "Internal legal entity (normally the adviser) that compensates the fund.", "NAV Error", "Reference (Legal Entity)", "", "LEN-0021", "Internal", "", ""),
       ("Reimbursing Third Party", "Third party (administrator, pricing vendor, custodian) that compensates the fund, where applicable.", "NAV Error", "Reference (Party)", "", "PTY-100990", "Internal", "", ""),
       ("Correction Methods", "Fund-level correction actions taken; shareholder remediation is 13.", "NAV Error", "Code (multi)", "Correction Method", "Restate NAV; Fund Reimbursed", "Internal", "", "Y"),
       ("Regulators Notified", "Regulators notified of the error, where the policy or the trustee requires it.", "NAV Error", "Code (multi)", "Shared: Regulator", "SEC", "Internal", "", ""),
       ("NAV Error Case Status", "Status of the case.", "NAV Error", "Code", "Shared: Case Status", "In Progress", "Internal", "", "", "Values used: New / Received, In Progress, Pending Third Party, Escalated, Resolved / Completed, Closed, Canceled."),
       ("Case Owner", "Employee accountable for the case.", "NAV Error", "Reference (Employee)", "", "EMP-02231", "Internal", "", "", "PII (internal staff)."),
     ]),
   ]),
   ("NAV Error Impact", "The error's effect on each share class and valuation date.", [
     ("NAV Error Impact", [
       ("Impact Case", "NAV error case the impact belongs to.", "NAV Error Impact", "Reference (NAV Error Case, 27)", "", "NEC-2026-0031", "Internal", "", ""),
       ("Impacted Share Class", "Share class affected; must equal the class of the published NAV.", "NAV Error Impact", "Reference (Share Class)", "", "SHC-004512", "Internal", "", ""),
       ("Impacted Valuation Date", "Valuation date affected; must equal the date of the published NAV.", "NAV Error Impact", "Date", "ISO 8601", "2026-10-02", "Internal", "", ""),
       ("Published NAV", "Share class NAV that was published in error.", "NAV Error Impact", "Reference (Share Class NAV, 27)", "", "NAV-2026100200451201", "Internal", "", "Y"),
       ("Corrected NAV", "Restated share class NAV; blank when the NAV was not restated.", "NAV Error Impact", "Reference (Share Class NAV, 27)", "", "NAV-2026100200451202", "Internal", "", ""),
       ("NAV Difference per Share", "Published less corrected NAV per share.", "NAV Error Impact", "Decimal", "", "0.15", "Internal", "", ""),
       ("NAV Error Percentage", "Difference as a percentage of the corrected NAV.", "NAV Error Impact", "Percentage", "", "0.62%", "Internal", "", "Y", "Source of 13 Servicing Error NAV Error Magnitude (Derived copy there, CD-189)."),
       ("Threshold Exceeded Indicator", "Whether the difference reaches or exceeds the materiality threshold of the case.", "NAV Error Impact", "Boolean", "", "Y", "Internal", "", "Y", "Source of 13 Materiality Threshold Exceeded Indicator (Derived copy there, CD-189)."),
       ("Estimated Shareholder Impact Amount", "Estimated amount owed to or by shareholders who dealt at the wrong NAV; the remediation itself is 13.", "NAV Error Impact", "Amount", "", "USD 6,120.44", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("NAV Controls & Fund Reporting", "FA-OVS",
  "NAV-level checks run before release, including oversight of an administrator's NAV (CD-147) and reliance on the 29 capital stock proof, and the fund's periodic financial statements and financial highlights. Price validation is 22; filing of shareholder reports and N-CSR is 35.",
  [
   ("NAV Control Check", "A NAV-level check performed on a fund or share class NAV.", [
     ("NAV Control Check", [
       ("Checked Fund NAV", "Fund NAV calculation checked.", "NAV Control Check", "Reference (Fund NAV Calculation, 27)", "", "PRD-00981 / US GAAP / 2026-10-05 / Administrator / 1", "Internal", "", ""),
       ("Checked Class NAV", "Share class NAV checked, for class-level checks.", "NAV Control Check", "Reference (Share Class NAV, 27)", "", "NAV-2026100500451201", "Internal", "", ""),
       ("NAV Control Check Type", "Kind of check.", "NAV Control Check", "Code", "NAV Control Check Type", "NAV Change Tolerance", "Internal", "", "Y"),
       ("Check Run Sequence", "Run of the check for the NAV (preparer run, oversight run, re-run).", "NAV Control Check", "Integer", "", "1", "Internal", "", ""),
       ("Check Tolerance", "Tolerance the check compares against.", "NAV Control Check", "Percentage", "", "1.50%", "Internal", "", ""),
       ("Observed Variance", "Variance the check measured.", "NAV Control Check", "Percentage", "", "0.42%", "Internal", "", ""),
       ("Check Result", "Outcome of the check.", "NAV Control Check", "Code", "Shared: Reconciliation Status", "Reconciled within Tolerance", "Internal", "", "Y"),
       ("Oversight Check Indicator", "Whether the firm performed the check on an administrator's NAV rather than as preparer.", "NAV Control Check", "Boolean", "", "Y", "Internal", "", ""),
       ("Relied-On TA Control Check", "29 capital stock proof relied on before the NAV is released; the proof and its result are 29's.", "NAV Control Check", "Reference (TA Control Check, 29)", "", "TACK-2026-1005-004512", "Internal", "", ""),
       ("Check Performed By", "Employee who performed or signed off the check.", "NAV Control Check", "Reference (Employee)", "", "EMP-02231", "Internal", "", "", "PII (internal staff)."),
     ]),
   ]),
   ("Fund Financial Statements", "The set of periodic financial statements of a fund book and the per-class financial highlights.", [
     ("Fund Financial Statement", [
       ("Statement Book", "Fund accounting book (and so fund and accounting basis) the statements are prepared from.", "Fund Statement", "Reference (Fund Accounting Book, 27)", "", "PRD-00981 / US GAAP", "Internal", "", "Y"),
       ("Statement Period End Date", "Last day of the fiscal period the statements cover.", "Fund Statement", "Date", "ISO 8601", "2026-10-31", "SEC Regulation S-X Article 6", "", "Y"),
       ("Statements Included", "Statements included in the set.", "Fund Statement", "Code (multi)", "Fund Financial Statement Type", "Schedule of Investments; Statement of Assets and Liabilities; Statement of Operations; Statement of Changes in Net Assets", "SEC Regulation S-X Article 6", "ASC 946", ""),
       ("Audited Indicator", "Whether the set is audited (annual) or unaudited (semi-annual).", "Fund Statement", "Boolean", "", "Y", "SEC Form N-CSR", "", "Y"),
       ("Statement Auditor", "Audit firm that signed the opinion.", "Fund Statement", "Reference (Party)", "", "PTY-101100", "Internal", "", "", "01 Product Party Role 'Auditor' masters the appointment; this records the firm that signed."),
       ("Statement Net Assets", "Net assets reported, which may differ from the last struck NAV by post-period adjustments.", "Fund Statement", "Amount", "", "USD 251,004,330.18", "ASC 946", "", "Y"),
       ("Statement Approval Status", "Approval state of the statement set.", "Fund Statement", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
     ]),
     ("Financial Highlights", [
       ("Highlights Share Class", "Share class the highlights are for.", "Financial Highlights", "Reference (Share Class)", "", "SHC-004512", "SEC Form N-1A", "", ""),
       ("Beginning NAV per Share", "NAV per share at the start of the period, as reported.", "Financial Highlights", "Decimal", "", "22.81", "SEC Form N-1A", "ASC 946", ""),
       ("Net Investment Income per Share", "Net investment income per share for the period.", "Financial Highlights", "Decimal", "", "0.41", "SEC Form N-1A", "ASC 946", ""),
       ("Net Gain per Share", "Net realized and unrealized gain or loss per share for the period.", "Financial Highlights", "Decimal", "", "1.98", "SEC Form N-1A", "ASC 946", ""),
       ("Ending NAV per Share", "NAV per share at the end of the period, as reported.", "Financial Highlights", "Decimal", "", "24.37", "SEC Form N-1A", "ASC 946", "", "Equals the period-end Share Class NAV unless a post-period adjustment applies."),
       ("Total Return", "Total return of the class for the period, assuming reinvestment.", "Financial Highlights", "Percentage", "", "12.46%", "SEC Form N-1A", "", "Y", "Performance measurement is 32; this is the statement figure (CD-217 option pending, stage3_consolidation_notes §3 item 18)."),
       ("Highlights Gross Expense Ratio", "Actual expenses before waivers as a percentage of average net assets for the period.", "Financial Highlights", "Percentage", "", "1.08%", "SEC Form N-1A", "ASC 946", "Y", "Not the 01 Cost Disclosure prospectus fee-table ratio (term conflict 'Expense Ratio')."),
       ("Highlights Net Expense Ratio", "Actual expenses after waivers and reimbursements as a percentage of average net assets for the period.", "Financial Highlights", "Percentage", "", "0.95%", "SEC Form N-1A", "ASC 946", "Y", "Candidate source for 01 Cost Disclosure (SME question 10)."),
       ("Portfolio Turnover Rate", "Lesser of purchases or sales divided by average portfolio value.", "Financial Highlights", "Percentage", "", "38%", "SEC Form N-1A", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
CL = {
 # Local copies of enterprise shared lists (exact names and values from shared_code_lists.py; see proposals_27 SHARED_MEMBERSHIPS)
 # Same name and values as 18 and 21 (shared Business Line list deferred, stage1_consolidation_notes §2)
 # Byte-identical copy of 19 Accounting Basis (deferred shared candidate)
 # Local lists
 "Fund Accounting Operating Model": ("Internal (CD-147)", [("In House","Fund accounting performs the books and NAV on the firm's platform"),("Outsourced to Administrator","Administrator keeps the books; firm oversees by exception"),("Outsourced with Shadow NAV","Administrator keeps the books; firm strikes an independent shadow NAV"),("Trustee Bank","CIT books kept by or for the trustee bank")]),
 "Book Portfolio Role": ("Internal", [("Main Portfolio","The single or principal portfolio of the fund"),("Sleeve","One of several portfolios run for the fund (multi-manager, sub-advised)"),("Cash Management Sleeve",""),("Consolidated Subsidiary","For example a wholly owned subsidiary consolidated into the fund's books")]),
 "Fund Ledger Account Class": ("ASC 946 / SEC Regulation S-X Article 6", [("Asset",""),("Liability",""),("Capital","Paid-in capital and capital stock activity"),("Distributable Earnings","Undistributed income and accumulated gains or losses"),("Income",""),("Expense",""),("Realized Gain or Loss",""),("Change in Unrealized Gain or Loss",""),("Distributions to Shareholders",""),("Memorandum","Statistical or off-book account")]),
 "Fund Journal Source Type": ("Internal / ASC 946", [("Trade","Purchase or sale booked from 18 PTXN-"),("Corporate Action","From 17 CAE- and 18 PTXN-"),("Income","Interest, dividend, amortization and accretion accruals and receipts"),("Expense","Expense accruals, true-ups and payments"),("Expense Waiver","Cap and waiver accruals and recoupments"),("Valuation","Change in unrealized gain or loss"),("Capital Stock","Subscriptions, redemptions and exchanges from 29 FNDO- fund orders"),("ETF Creation / Redemption","In-kind or cash creations and redemptions from 29 ECR- AP orders"),("Distribution","Declarations, payments and reinvestments (FDIV-)"),("Swing Pricing / Dilution","Swing pricing adjustments (SEC Rule 22c-1(a)(3))"),("NAV Error Correction","Booked under an NEC- case"),("Tax","Fund tax accruals and payments"),("Other Adjustment","Adjustment with no source event; manual entries are flagged by Manual Entry Indicator")]),
 "Fund Journal Status": ("Internal", [("Draft",""),("Pending Approval",""),("Posted",""),("Rejected",""),("Reversed","")]),
 "ABOR Valuation Method": ("SEC Rules 2a-4, 2a-5, 2a-7 / Internal", [("Market Quotation","Readily available market quotation"),("Evaluated Price","Pricing service evaluation"),("Fair Value","22 fair value determination applied"),("Amortized Cost","Money market fund or short-term debt where permitted"),("NAV of Underlying Fund","Fund interest valued at the underlying fund's NAV"),("Contract Value","Stable value contracts in CITs")]),
 "Income Type": ("ASC 946 / Internal", [("Interest",""),("Dividend",""),("Amortization of Premium",""),("Accretion of Discount",""),("Payment-in-Kind Interest",""),("Securities Lending Income","Fund share from 28 lending revenue allocation"),("Other Income","")]),
 "NAV Calculation Source": ("Internal (CD-147)", [("Fund Accounting","Official NAV calculated in house"),("Administrator","Official NAV calculated by the administrator"),("Firm Shadow","Independent firm calculation used to oversee an administrator NAV; never the dealing NAV")]),
 "NAV Version Type": ("Internal", [("Original","First calculation for the date"),("Re-Strike","Recalculated before release on the same date"),("Restatement","Recalculated after release, under a NAV error case")]),
 "NAV Status": ("Internal", [("Estimated","Indicative calculation, not for dealing"),("Preliminary","Calculated, checks in progress"),("Final","Approved; the dealing NAV when the source is the official preparer"),("Superseded","Replaced by a later version")]),
 "NAV Release Status": ("Internal", [("Released","Released for transmission and publication"),("Withheld","Release held pending checks or an error investigation"),("Withdrawn","Released and then withdrawn; a corrected release follows")]),
 "Class Allocation Item": ("SEC Rule 18f-3", [("Net Investment Income Before Class Expenses",""),("Common Expenses","Fund-level expenses shared by all classes"),("Realized Gain or Loss",""),("Change in Unrealized Gain or Loss","")]),
 "Class Allocation Method": ("SEC Rule 18f-3", [("Relative Net Assets","Prior-day net assets of each class"),("Settled Shares","Value of settled shares, for daily-dividend funds"),("Simultaneous Equations","For daily-dividend funds with class-specific expenses")]),
 "CIT Valuation Basis": ("12 CFR 9.18 / Internal", [("Fair Value - Daily",""),("Fair Value - Monthly",""),("Fair Value - Quarterly","At least quarterly as required for collective investment funds"),("Contract Value","Stable value units")]),
 "Swing Factor Method": ("Internal / SEC Rule 22c-1(a)(3)", [("Fixed Factor","Approved factor applied whenever the threshold is breached"),("Dynamic Factor","Factor estimated daily from transaction cost and spread models")]),
 "Fund Expense Type": ("SEC Regulation S-X Article 6 / Internal", [("Management Fee",""),("Administration Fee",""),("Distribution and Service Fee","Rule 12b-1"),("Transfer Agency Fee",""),("Custody Fee",""),("Fund Accounting Fee",""),("Audit Fee",""),("Legal Fee",""),("Trustee / Director Fee",""),("Registration Fee",""),("Shareholder Reporting Expense",""),("Interest Expense","Including credit facility interest"),("Organization Cost",""),("Other Expense","")]),
 "Accrual Method": ("Internal", [("Asset-Based Rate","Annual rate times net assets divided by days in year"),("Fixed Daily Amount","Budget spread evenly"),("Invoice-Based","Accrued when invoiced"),("Per-Account Charge","Transfer agency per-account fees")]),
 "Waiver Type": ("SEC Form N-1A / Internal (same values as 10 Waiver Type)", [("Contractual Fee Waiver",""),("Voluntary Fee Waiver",""),("Expense Reimbursement",""),("Money Market Yield Waiver","Waiver to maintain non-negative yield"),("Acquired Fund Fee Waiver","Waiver for fees of affiliated underlying funds"),("12b-1 Fee Waiver","")]),
 "Distribution Type": ("IRC Section 852 / Internal (income source only)", [("Net Investment Income","Dividends from ordinary income"),("Short-Term Capital Gain",""),("Long-Term Capital Gain","Capital gain dividend")]),
 "Distribution Character": ("IRS Form 1099-DIV / IRC Sections 852-855, 871(k), 897", [("Ordinary Dividend",""),("Qualified Dividend Income",""),("Section 199A Dividend",""),("Short-Term Capital Gain Dividend","Reported within ordinary dividends; exempt from withholding for foreign shareholders under section 871(k)"),("Interest-Related Dividend","Exempt from withholding for foreign shareholders under section 871(k)"),("Long-Term Capital Gain",""),("Unrecaptured Section 1250 Gain",""),("Collectibles (28%) Gain",""),("Section 897 Gain","US real property interest gain"),("Return of Capital","Nondividend distribution"),("Exempt-Interest Dividend",""),("Specified Private Activity Bond Interest Dividend","Alternative minimum tax item"),("Foreign Tax Credit Pass-Through","")]),
 "Distribution Requirement Period": ("IRC Sections 852 and 4982", [("Fund Fiscal Year","Subchapter M distribution requirement"),("Excise Year - Ordinary Income","Calendar year"),("Excise Year - Capital Gains","One-year period ending October 31")]),
 "Fund Tax Regime": ("Internal", [("Regulated Investment Company","IRC Subchapter M"),("Group Trust","CIT exempt under Revenue Ruling 81-100"),("Partnership","Feeder funds organized as partnerships (CW-166); investor Schedules K-1 are 13 tax documents"),("Taxable Corporation",""),("Other","")]),
 "Fund Tax Return Type": ("IRS / Internal", [("Form 1120-RIC",""),("Form 8613","Excise tax return"),("Form 1065","Partnership return"),("None Required","")]),
 "Book-Tax Difference Type": ("IRC / Internal", [("Wash Sale Deferral","IRC Section 1091"),("PFIC Mark-to-Market","IRC Section 1296"),("Straddle Loss Deferral","IRC Section 1092"),("Section 1256 Mark-to-Market",""),("Section 988 Currency Gain or Loss",""),("Premium Amortization",""),("In-Kind Redemption Gain","IRC Section 852(b)(6); permanent, reclassified to paid-in capital"),("Late-Year Loss Deferral",""),("Return of Capital Basis Adjustment",""),("Non-Deductible Expense","")]),
 "RIC Test Type": ("IRC Section 851", [("Gross Income - 90% Test","Qualifying income"),("Asset Diversification - 50% Test","Quarterly"),("Asset Diversification - 25% Test","Quarterly; single issuer or controlled group")]),
 "NAV Error Type": ("Internal", [("Pricing Error",""),("FX Rate Error",""),("Trade Booking Error",""),("Corporate Action Error",""),("Income Accrual Error",""),("Expense Accrual Error",""),("Capital Stock Error",""),("Class Allocation Error",""),("Swing Pricing Error",""),("Distribution Error",""),("Other","")]),
 "NAV Error Cause": ("Internal", [("Vendor Data Error",""),("Manual Input Error",""),("System Defect",""),("Late or Missing Information",""),("Procedure Not Followed",""),("Third-Party Administrator Error",""),("Other","")]),
 "Correction Method": ("Internal (fund-level actions under the board-approved NAV error policy)", [("Restate NAV","Corrected NAV versions published; shareholder activity reprocessed by 13 and 29"),("Fund Reimbursed","Fund made whole by the adviser or a third party"),("Prospective Correction Only","Below threshold: books corrected going forward, no restatement"),("Other","")]),
 "Materiality Basis": ("Internal (SEC staff practice and board-approved policy; confirm source)", [("Board-Approved Policy (US)","Fund board's NAV error policy"),("Trustee Policy (CIT)",""),("Other","")]),
 "NAV Control Check Type": ("Internal (NAV-level checks only; price validation is 22, capital stock proof is 29)", [("NAV Change Tolerance","NAV change against benchmark or peer"),("Shadow NAV Comparison","Administrator NAV against firm shadow NAV"),("Price Exceptions Cleared","All 22 price validation exceptions for the fund resolved before release"),("Expense Ratio Check",""),("Distribution Rate Check",""),("Other","")]),
 "Fund Financial Statement Type": ("SEC Regulation S-X Article 6 / ASC 946", [("Schedule of Investments",""),("Statement of Assets and Liabilities",""),("Statement of Operations",""),("Statement of Changes in Net Assets",""),("Statement of Cash Flows","Where required"),("Notes to Financial Statements",""),("Other","")]),
}

# ---------------------------------------------------------------------------
REL = [
 ("Fund Accounting Book","is kept for","Investment Product (fund) [01]","n : 1","One book per fund (series) and accounting basis; institutional separate accounts have no book."),
 ("Fund Accounting Book","has","Fund Book Operating Period","1 : 1..n","Effective-dated operating model and administrator of record (CD-147)."),
 ("Fund Book Operating Period","names","Party (Fund Administrator) [02]","n : 0..1","Appointment mastered in 01 Product Party Role."),
 ("Fund Accounting Book","accounts for","Portfolio [18] via Fund Book Portfolio Link","1 : 1..n","One book, one or more portfolios (sleeves)."),
 ("Fund Accounting Book","is owned by","Internal Legal Entity [09]","n : 0..1","CIT trustee bank books."),
 ("Fund Accounting Book","posts to","Fund Ledger Account (fund chart)","n : 1..n","Through Book Fund Chart of Accounts."),
 ("Fund Accounting Book","has","Fund Journal Entry","1 : 0..n","Fund journals never post to a 19 Ledger (CD-186)."),
 ("Fund Journal Entry","has","Fund Journal Line","1 : 1..n",""),
 ("Fund Journal Entry","corrects under","NAV Error Case","n : 0..1",""),
 ("Fund Journal Line","is posted to","Fund Ledger Account","n : 1","Fund chart of accounts; not a 19 GL Account."),
 ("Fund Journal Line","books","Portfolio Transaction [18]","n : 0..1","Trades, income, corporate actions and fees."),
 ("Fund Journal Line","records settlement of","Settlement Instruction [26]","n : 0..1",""),
 ("Fund Journal Line","books capital stock from","Fund Order [29]","n : 0..1",""),
 ("Fund Journal Line","books ETF capital stock from","AP Creation / Redemption Order [29]","n : 0..1","In-kind and cash creations and redemptions."),
 ("Fund Accounting Book","has","Fund Trial Balance","1 : 0..n","Per ledger account and valuation date."),
 ("ABOR Valuation Record","applies","Approved Price [22]","n : 0..1","Prices are mastered in 22 (CD-187)."),
 ("ABOR Valuation Record","applies","Fair Value Determination [22]","n : 0..1",""),
 ("ABOR Valuation Record","applies","FX Rate Observation [22]","n : 0..1",""),
 ("ABOR to IBOR Reconciliation","compares the book with","Portfolio Holding [18]","n : 0..1","Keyed book x portfolio x instrument x date."),
 ("ABOR Valuation Record","is reconciled to the custodian by","Custody Reconciliation Run [28]","n : 0..n","Reverse link (CD-196)."),
 ("Income Accrual","accrues on","Instrument [17]","n : 1","Coupon periods from 17 Coupon Schedule; dividends from 17 Corporate Action Event."),
 ("Income Accrual","applies","Reference Rate Fixing [22]","n : 0..1","Floating-rate periods."),
 ("Income Accrual","is collected by","Income Collection [28]","n : 0..1","28 compares expected with received income."),
 ("Fund NAV Calculation","totals","Fund Trial Balance (same book and valuation date)","n : n","Several versions may total the same balances."),
 ("Fund NAV Calculation","has","Share Class NAV","1 : 1..n","One per share class (or CIT unit class)."),
 ("Share Class NAV","is struck for","Share Class [01]","n : 1","Under 01 Valuation Terms (valuation point, NAV precision)."),
 ("Fund NAV Calculation","is allocated by","Class Allocation","1 : 0..n","Rule 18f-3."),
 ("Share Class NAV","is released by","NAV Dissemination (release)","1 : 0..n","Values are read from the NAV, never repeated."),
 ("NAV Dissemination (release)","is transmitted by","Price & Rate Transmission [29]","1 : 0..n","Reverse link: 29 masters per-channel transmission."),
 ("NAV Control Check","checks","Fund NAV Calculation / Share Class NAV","n : 1",""),
 ("NAV Control Check","relies on","TA Control Check [29]","n : 0..1","Capital stock proof run by 29."),
 ("Swing Pricing Parameter","is applied by","Swing Pricing Decision","1 : 0..n","Within 01 Maximum Swing Factor."),
 ("Share Class NAV","is swung by","Swing Pricing Decision","n : 0..1",""),
 ("Fund Expense Accrual","is computed under","Fund Fee Schedule [01]","n : 0..1","Asset-based fees (FSCH-, CW-051)."),
 ("Fund Expense Accrual","is the fund side of","Fee Revenue Record [10]","n : 0..n","Reverse link: 10 reads 27 accruals."),
 ("Expense Cap & Waiver Accrual","is the source of","Waiver Record [10]","n : 0..1","CD-188 Derived copies."),
 ("Expense Cap & Waiver Accrual","is mirrored by","Receivable Item / Payable Invoice [19]","n : 0..1","Adviser side of recoupment and reimbursement."),
 ("Fund Expense Payment","pays","Party (service provider) [02]","n : 1",""),
 ("Distribution Declaration","has","Distribution Character","1 : 1..n","Estimated and final rows."),
 ("Distribution Declaration","is reinvested at","Share Class NAV","n : 0..1",""),
 ("Distribution Declaration","is reported on","Tax Form Record [13]","1 : 0..n","Reverse link: 13 reads final character."),
 ("Fund Tax Year Record","has","Book-Tax Difference","1 : 0..n",""),
 ("Investment Product (fund) [01]","is tested by","RIC Test Result","1 : 0..n","Qualification status is 35 RIC Qualification Determination."),
 ("NAV Error Case","has","NAV Error Impact","1 : 1..n","Per share class and valuation date."),
 ("NAV Error Impact","was published at","Share Class NAV","n : 1",""),
 ("NAV Error Impact","is corrected to","Share Class NAV","n : 0..1","Blank when not restated."),
 ("NAV Error Case","is referenced by","Servicing Error [13]","1 : 0..n","Reverse link (CD-189); remediation is 13."),
 ("NAV Error Case","is referenced by","Fund Order (As-Of Order Detail) [29]","1 : 0..n","Reverse link."),
 ("Fund Financial Statement","has","Financial Highlights","1 : 1..n","Per share class."),
]

# ---------------------------------------------------------------------------
SRC = [
 ("SEC Rule 2a-4 (definition of current net asset value)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.2a-4","Regulation","NAV computation, valuation of portfolio securities, recording of trades and capital stock by the next business day","Fund NAV Calculation, ABOR Valuation Record, Fund Journal Entry",["SEC Rule 2a-4"]),
 ("SEC Rule 2a-5 (good faith determinations of fair value) and adopting release IC-34128","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.2a-5","Regulation","Boundary to 22: fair value determinations and the valuation designee are applied here by reference","ABOR Valuation Record (Applied Fair Value Determination)",["SEC Rule 2a-5"]),
 ("SEC Rule 22c-1 (pricing of redeemable securities, including optional swing pricing)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.22c-1","Regulation","Forward pricing at the next computed NAV; optional swing pricing under Rule 22c-1(a)(3): board-approved policy, swing threshold, swing factor up to 2% (confirm), administrator of the policy","Share Class NAV, Swing Pricing Parameter, Swing Pricing Decision, Swing Factor Method",["SEC Rule 22c-1"]),
 ("SEC proposal: Open-End Fund Liquidity Risk Management Programs and Swing Pricing (Release 33-11130 / IC-34746, File S7-26-22, November 2022)","US SEC","https://www.govinfo.gov/content/pkg/FR-2022-12-16/html/2022-24376.htm","Proposed rule (not adopted)","Mandatory swing pricing and hard close proposals; context only","Swing Pricing Decision (Net Activity Data Basis)",["SEC Rule 22c-1"]),
 ("SEC Rule 18f-3 (multiple class companies)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.18f-3","Regulation","Allocation of income, expenses and gains among classes; class-specific expenses","Class Allocation, Fund Ledger Account, Fund Expense Accrual",["SEC Rule 18f-3"]),
 ("SEC Rule 19a-1 (written statement of source of dividends)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.19a-1","Regulation","Notice when a distribution includes sources other than net investment income","Distribution Declaration, Distribution Character",["SEC Rule 19a-1"]),
 ("SEC Rule 2a-7 (money market funds) and Form N-MFP","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.2a-7","Regulation","Amortized cost, market-based NAV to four decimals, daily dividends","Share Class NAV (Market-Based NAV), Distribution Declaration (Daily Dividend Indicator), ABOR Valuation Method",["SEC Rule 2a-7", "SEC Form N-MFP"]),
 ("SEC Rule 6c-11 (exchange-traded funds)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.6c-11","Regulation","Creation units and baskets behind ETF capital stock booked from 29 AP orders","Fund Journal Line (Source AP Order)",["Rule 6c-11"]),
 ("SEC Regulation S-X Article 6 (registered investment companies) and Form N-1A Item 13 (financial highlights); Form N-CSR","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-210","Regulation / forms","Statement content and captions, financial highlights per share and ratios","Fund Financial Statement, Financial Highlights, Fund Ledger Account Class",["SEC Regulation S-X Article 6", "SEC Form N-1A", "SEC Form N-CSR"]),
 ("FASB ASC 946 (Financial Services - Investment Companies), ASC 820, ASC 830; AICPA Audit and Accounting Guide: Investment Companies","FASB; AICPA","https://asc.fasb.org","Licensed standard","Investment company accounting, unrealized gains, financial highlights, permanent book-tax reclassifications","Fund Accounting Book, ABOR Valuation Record, Book-Tax Difference, Financial Highlights",["ASC 946", "ASC 820", "ASC 830", "ASC 962"]),
 ("IRC Sections 851-855 (Subchapter M, regulated investment companies), including section 852(b)(6) in-kind redemptions","US Congress (Cornell LII text)","https://www.law.cornell.edu/uscode/text/26/851","Statute","Gross income and asset diversification tests, distribution requirement, capital gain and qualified dividends, spillback, nonrecognition on in-kind redemptions","RIC Test Result, Fund Tax Year Record, Distribution Type and Character, Book-Tax Difference Type",["IRC Section 851", "IRC Section 852", "IRC Section 854", "IRC Section 855"]),
 ("IRC Section 4982 (excise tax on undistributed income of RICs) and IRS Form 8613","US Congress; US IRS","https://www.law.cornell.edu/uscode/text/26/4982","Statute / form","Calendar-year and October-year distribution requirements, excise tax","Distributable Income Estimate, Fund Tax Year Record",["IRC Section 4982", "IRS Form 8613"]),
 ("IRS Form 1120-RIC, Form 1099-DIV instructions; IRC Sections 871(k), 897, 1091, 1092, 1212, 1296","US IRS","https://www.irs.gov/forms-pubs/about-form-1099-div","Forms / statute","Fund return, distribution character boxes, wash sale, straddle, capital loss carryforward, PFIC mark-to-market","Distribution Character, Book-Tax Difference, Fund Tax Year Record",["IRS Form 1120-RIC", "IRS Form 1099-DIV", "IRC Section 1091", "IRC Section 1212"]),
 ("OCC 12 CFR 9.18 (collective investment funds)","US OCC","https://www.ecfr.gov/current/title-12/chapter-I/part-9/section-9.18","Regulation","Valuation of collective investment fund assets, admissions and withdrawals on valuation dates","CIT Unit Value Detail, Fund Accounting Book (Book Owner Entity)",["12 CFR 9.18"]),
 ("DTCC Mutual Fund Profile Service (price, rate and distribution data)","DTCC","https://www.dtcc.com/wealth-and-investment-solutions/fund-solutions/price-rate-distribution-data","Member documentation","NAV, rate and correction dissemination to intermediaries (transmission is 29)","NAV Dissemination (Corrected Release Indicator)",["DTCC Mutual Fund Profile Service"]),
 ("ICI papers on NAV error correction and valuation practice","Investment Company Institute","https://www.ici.org","Industry guidance (confirm titles)","Materiality practice for US NAV error policies (commonly 0.5% / one cent); with SEC staff practice, the basis of the board-approved policy (confirm source)","Materiality Basis, Materiality Threshold, Correction Method",["Internal"]),
 ("Fund accounting platforms and administrators (SimCorp, Aladdin, SS&C, State Street, BNY, Northern Trust, Citco) - public product descriptions","Vendors","https://www.simcorp.com","Vendor documentation (structure only)","ABOR / IBOR split, fund books, NAV workflow, expense and distribution modules","Fund Accounting Book, Fund Journal Entry, NAV Control Check",["Internal"]),
]
