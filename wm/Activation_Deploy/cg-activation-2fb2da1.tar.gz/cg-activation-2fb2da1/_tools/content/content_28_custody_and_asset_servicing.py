"""Data Domain 28 - Fund Custody & Asset Servicing. Content module for taxonomy_builder.py."""

META = {
 "title": "Fund Custody & Asset Servicing Data Taxonomy",
 "subtitle": "Business domain 28 - Fund Custody & Asset Servicing | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "28_Custody_and_Asset_Servicing/Custody_and_Asset_Servicing_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for fund custody oversight and asset servicing at a US wealth manager whose proprietary mutual funds, ETFs and collective investment trusts, and the institutional separate accounts it manages for institutional advisory clients, hold their assets at global custodian banks, which hold them in turn through sub-custodians and central securities depositories in the markets the funds invest in. It covers fund assets only: custody of client assets at the firm's self-clearing broker-dealer (customer securities in its possession or control, the reserve computation of SEC Rule 15c3-3 and the client holdings of every brokerage, retirement and managed account) is 49 Clearing, Settlement & Client Asset Custody (CW-007). It defines the custody network the funds rely on (provider profiles, sub-custodian arrangements by market, foreign custody and depository assessments, periodic service reviews), the safekeeping accounts in which each fund's and institutional separate account's assets are held, the statements custodians send and the reconciliations and breaks that compare them with the investment and accounting books, the per-account processing of corporate actions (notifications, entitlements, elections, payments, including dividend and interest income), the control of income received against income expected, withholding tax relief and reclaims in foreign markets, securities class action claims, and securities lending (programs, lending agreements, loans, collateral received, revenue split and loan reporting under SEC Rule 10c-1a). Fund custody is outsourced to custodian banks (or held by a CIT's trustee bank, which may be the firm's own trust company) while oversight stays in house, so the grain is the custodian's records as received plus the firm's own control records. Built from Investment Company Act Section 17(f) and SEC Rules 17f-4, 17f-5 and 17f-7, OCC 12 CFR 9.13, ISO 20022 seev, semt and camt messages and their ISO 15022 equivalents (MT535, MT564-MT566, MT950), SMPG and ISSA market practice, SEC Rule 10c-1a, SEC Form N-CEN, the ISLA Global Master Securities Lending Agreement, the OECD TRACE package and, for the EU markets the international funds invest in, the EU FASTER Directive. Use it as a starting point for a fund asset servicing data model, a custody oversight glossary or the control layer between the fund IBOR (18), the ABOR (27) and the custodians."),
  ("Scope", "In scope: custody provider profiles by role (global custodian, sub-custodian, CSD / ICSD, agent lender, and a CIT trustee bank that self-custodies, which may be the firm's own trust company) keyed by the 02 party or the 09 legal entity, sub-custodian network arrangements by market, foreign custody and depository assessments under Rules 17f-5 and 17f-7, custodian service reviews, safekeeping accounts (securities, cash, bank deposit and collateral accounts) and their effective-dated assignment to funds, portfolios and institutional separate accounts, custodian holding and cash statements, custody reconciliation runs (IBOR, ABOR, cash) and breaks, corporate action notification receipts per account, entitlements, elections and payments (including dividends and interest), income collection control, tax relief documentation, withholding tax reclaims, class action claims, securities lending programs, lending agreements (CD-182), loans, collateral received, regulatory loan reports and revenue allocation. Out of scope (referenced by ID): products, the appointed custodian of a fund and the permission to lend (01 Investment Product & Service Offering); custodians, sub-custodians, CSDs, agent lenders and borrowers as organizations, with their BIC, LEI and regulator (the 02 party core, CD-143); internal legal entities (09 Shared & Enterprise Reference Data) and their authorizations (38); the mandate custody set-up workflow of institutional clients (12 Institutional Client Servicing & Reporting); client accounts (15 Account); instruments, corporate action events (including class action cases) and options (17 Instrument & Issuer Reference); fund and institutional portfolios, portfolio holdings, cash balances and portfolio transactions (18 Portfolio & Investment Book of Record); employees (20 Human Capital); custody of client assets at the firm's broker-dealer, client holdings, the Rule 15c3-3 possession-or-control and reserve records and corporate actions on client holdings (49 Clearing, Settlement & Client Asset Custody, CW-007). Other domains own prices (22), investment decisions (24), fund-side settlement instructions, standing settlement instructions, fails, trading agreements and OTC collateral (26), the ABOR, income accruals and fund expenses (27), ETF creation and redemption orders (29), investee meetings and proxy votes (34), custody agreements as contracts (39) and SWIFT connectivity (41 Application Interface of mechanism SWIFT Network)."),
  ("Structure", "Four levels: Data Domain > Data Family > Data Business Object > Data Business Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "A Custody Provider Profile is the custody-specific profile of a 02 party (or, for a self-custodying CIT trustee, a 09 legal entity) in one provider role; Sub-Custodian Network Arrangements record which sub-custodian and depository a global custodian uses in each market, and Foreign Custody Assessments and Custodian Service Reviews record the oversight. A Safekeeping Account (SKA-) is an account at a custodian, sub-custodian, bank or securities depository that holds fund or institutional separate account assets; Safekeeping Account Assignments link it, effective-dated, to the fund (01 PRD-), portfolio (18 PORT-) or institutional separate account (15 ACC-) whose assets it holds. Custodian Statements arrive per safekeeping account and date, with Custodian Holding Statement Lines and Custodian Cash Statement Entries; a Custody Reconciliation Run (CUREC-) compares them with 18 portfolio holdings and cash or 27 ABOR values, and each difference is a Custody Reconciliation Break (CUREC-n-Bnn). A 17 Corporate Action Event (CAE-), including dividends and interest, reaches an account as a Corporate Action Notification Receipt and becomes a Corporate Action Entitlement (CAEN-), answered by Corporate Action Elections (ELECT-) and settled by Corporate Action Payments, which hold the cash and withholding facts and which 18 books as PTXN-. Income Collection is the control over income: it compares the payment with what 27 expects and records the chase. Tax Relief Documentation and Withholding Tax Reclaims (WHTR-) recover withholding tax shown on the payment; Class Action Claims (SCAC-) recover losses on a 17 class action event. A Securities Lending Program operates under Securities Lending Agreements and governs Securities Loans (SBL-), each with its collateral items and its Rule 10c-1a report, and Lending Revenue Allocations split revenue. The same events on client holdings (a client's dividend, election or class action) are processed in 49, not here."),
  ("Design principles", "1) A safekeeping account is not a client account: 15 ACC- is the client's account with the firm; SKA- is an account at a custodian, sub-custodian, bank or securities depository holding fund or institutional separate account assets, and an institutional separate account's safekeeping account names its owner ACC- without becoming one (CD-194, option A). Retail brokerage, retirement and managed accounts have no SKA-: their assets are client holdings in the firm's own custody (49, CW-007, CW-009). 2) Event in 17, processing in 28: event dates, types, options, rates, the market deadline and class action case facts are read from CAE- and the 17 option; only per-account facts, the claim and custodian discrepancies are held here, and the resulting change in the 18 Portfolio Holding is booked as an 18 Portfolio Transaction (CD-195). 3) Income once: the cash and withholding of a dividend or coupon are held on the Corporate Action Payment; Income Collection only controls it against the 27 expectation, and a reclaim points at the payment. 4) Reconcile, do not remaster: reconciliations and breaks point at 18 portfolio holdings and cash, 27 ABOR records and the custodian statement; the custodian's assertion is named 'Custodian ...', never 'Position' (CD-146, CD-196). 5) Settlement belongs to 26: no settlement instruction, fail or OTC collateral here. 6) Fund assets here, client assets in 49 (CW-007): custody of fund and institutional separate account assets at custodian banks is 28's; custody of client assets at the firm's broker-dealer (possession or control and the reserve computation under SEC Rule 15c3-3) is 49's. No 28 record serves both: a client's shares of a firm fund are a 49 Client Holding (with an 06 Fund Shareholder Position view), while the fund's own portfolio assets are 28's. 7) Parties are 02's: provider profiles carry no names, addresses, BICs, LEIs or regulators. 8) Effective-date arrangements, assessments, assignments and classifications; values that change daily (loan and collateral marks) carry their mark date. 9) One fact once: on-loan quantity lives on the Securities Loan and is not repeated as an account type or a mastered sub-balance. 10) The custody universe is global: foreign markets, sub-custodians, depositories, currencies and tax reclaims stay because the international funds hold foreign securities; the firm itself is regulated in the US only (CW-022). 11) Flag Critical Data Elements (CDE) and personal data."),
  ("Applies To", "Shows the record each attribute belongs to: Provider Profile, Network Arrangement, Custody Assessment, Service Review, Safekeeping Account, Account Assignment, Statement, Holding Line, Cash Entry, Reconciliation Run, Break, CA Notification, Entitlement, Election, CA Payment, Income Collection, Tax Relief, Reclaim, Class Action, Lending Program, Lending Agreement, Loan, Lending Collateral, Loan Report or Lending Revenue."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify a safekeeping account and whose assets it holds, to state what the custodian says is held, to measure and resolve a reconciliation difference, to entitle, elect and pay a corporate action correctly and on time, to recover income and withholding tax, or to control securities on loan, their collateral and their Rule 10c-1a reporting. Confirm with fund asset servicing, investment operations, fund accounting, fund tax and the securities lending desk."),
  ("Primary / Secondary Reference", "Standard, rule or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Vendor references (custodian portals, DTCC, Broadridge) indicate common industry structure, not a license to reproduce vendor record layouts. Next step: map each attribute to the custodian statement and corporate action feeds, the reconciliation platform and the lending agent's reports."),
  ("Notes", "PII = personal data under US privacy law (Regulation S-P, the Gramm-Leach-Bliley Act and state privacy laws). Most safekeeping accounts belong to funds and institutions; where an institutional separate account belongs to an individual or a personal trust, its safekeeping account number and name and every record keyed to it (statement lines, cash entries, entitlements, payments, income collections, breaks and class action claims) are nonpublic personal information: restrict access accordingly. The account number, name and claim amounts carry an explicit PII flag. Employee references (decision makers, break owners, reviewers) are personal data of staff. Custody account numbers of funds are confidential: restrict access and mask them in non-production environments."),
  ("Tabs", "Hierarchy: families, object groups and objects with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: object-level cardinalities, including references to other Data Domains | Sources: standards used, owners, licenses and links."),
  ("Suggested next steps", "1) Validate families, account types, reconciliation types and CDEs with fund asset servicing, investment operations, fund accounting, fund tax and the securities lending desk. 2) Agree the 28 / 49 boundary with the 49 drafter (W3): no SKA- for a retail brokerage, retirement or managed account; the broker-dealer's own accounts at DTC and at its banks (customer securities, the reserve bank account) are 49's; client-level corporate actions and class action claims are 49's. 3) Map statements, notifications and payments to the custodians' ISO 20022 and ISO 15022 feeds. 4) Agree with 17 the golden-copy event key and the class action case facts, with 18 the booking of corporate action results, with 27 the expected income, and with 26 the boundary on fund-side settlement and collateral. 5) Confirm the securities lending operating model (custodian or third-party agent) and the 10c-1a reporting party; Rule 10c-1a was remanded by the Fifth Circuit in August 2025 and its compliance date deferred to 28 September 2028 (confirm status). 6) Turn the Relationships tab into a logical fund asset servicing data model shared with 17, 18, 26 and 27."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))


# ---------------------------------------------------------------------------
D("Custody Network", "CU-NET",
  "The custody network the firm's funds and institutional separate accounts rely on and its oversight (fund assets; custody of client assets at the firm's broker-dealer is 49): each provider's custody profile by role, which sub-custodian and depository a global custodian uses in each market, the foreign custody and depository assessments required before assets may be held there, and periodic reviews of each provider's service.",
  [
   ("Custody Provider Profile", "Custody-specific facts about a provider of fund custody or asset servicing in one role. Name, address, BIC, LEI and regulator stay in 02 (or 09 for an internal trustee bank).", [
     ("Custody Provider Profile", [
       ("Provider Party", "External party the profile describes; exactly one of Provider Party and Provider Legal Entity is filled.", "Provider Profile", "Reference (Party)", "", "PTY-100912", "Internal", "FIBO BE", "Y"),
       ("Provider Legal Entity", "Internal legal entity the profile describes, where the firm's own trustee bank holds a CIT's assets itself; exactly one of Provider Party and Provider Legal Entity is filled.", "Provider Profile", "Reference (Legal Entity)", "", "", "OCC 12 CFR 9.13", "", "", "Used only for self-custody by an internal trustee bank (CIT line)."),
       ("Custody Provider Role", "Role in which the provider serves the firm's funds and institutional separate accounts in the custody chain.", "Provider Profile", "Code", "Custody Provider Role", "Global Custodian", "Investment Company Act Section 17(f)", "SEC Rule 17f-5", "Y", "One profile row per provider and role; a bank acting as global custodian and agent lender has two rows."),
       ("Services Provided", "Asset servicing services the provider delivers to the firm in this role.", "Provider Profile", "Code (multi)", "Custody Service Type", "Safekeeping; Income Collection; Corporate Actions; Tax Relief and Reclaims", "Internal", "", ""),
       ("Supported Message Standards", "Message standards the provider can send and receive for statements, corporate actions and cash.", "Provider Profile", "Code (multi)", "Shared: Message Standard", "ISO 15022; ISO 20022 seev", "ISO 20022", "SWIFT", ""),
       ("Service Agreement Reference", "Custody agreement under which the provider acts.", "Provider Profile", "Reference (Contract, 39)", "", "CTRCT-0041877", "Internal", "", "", "Re-typed at the Stage 4 consolidation (CD-257, CD-262): the custody agreement is a 39 Contract. Lending agreements are mastered in 28 (CD-182)."),
       ("Provider Profile Status", "Whether the provider is currently used in this role.", "Provider Profile", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
       ("Profile Effective From", "Date the provider began serving in this role.", "Provider Profile", "Date", "ISO 8601", "2019-04-01", "Internal", "", ""),
       ("Profile Effective To", "Date the provider stopped serving in this role.", "Provider Profile", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Sub-Custodian Network", "Which sub-custodian and depository a global custodian uses in each market, and how assets are held there.", [
     ("Sub-Custodian Network Arrangement", [
       ("Arrangement Global Custodian", "Global custodian whose network the arrangement belongs to.", "Network Arrangement", "Reference (Party)", "", "PTY-100912", "SEC Rule 17f-5", "", "Y"),
       ("Arrangement Market", "Market (country) in which the sub-custodian holds assets.", "Network Arrangement", "Code", "ISO 3166-1 alpha-2", "BR", "ISO 3166", "", "Y"),
       ("Sub-Custodian", "Bank appointed by the global custodian to hold assets in the market.", "Network Arrangement", "Reference (Party)", "", "PTY-101455", "SEC Rule 17f-5", "", "Y"),
       ("Securities Depository", "Central securities depository or ICSD in which the sub-custodian holds the assets.", "Network Arrangement", "Reference (Party)", "", "PTY-101460", "SEC Rule 17f-7", "", ""),
       ("Market Holding Model", "How assets are held at the depository in the market: in the beneficial owner's name, in an omnibus account, in a segregated account or through a nominee.", "Network Arrangement", "Code", "Custody Holding Model", "Omnibus", "ISSA", "", ""),
       ("Arrangement Status", "Whether the arrangement is in use.", "Network Arrangement", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
       ("Arrangement Effective From", "Date the global custodian started using the sub-custodian in the market.", "Network Arrangement", "Date", "ISO 8601", "2021-07-01", "Internal", "", ""),
       ("Arrangement Effective To", "Date the global custodian stopped using the sub-custodian in the market.", "Network Arrangement", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Foreign Custody Assessment", "Eligibility and risk assessments of the custodians and securities depositories that hold fund assets (Investment Company Act Section 17(f), Rules 17f-4, 17f-5 and 17f-7).", [
     ("Foreign Custody Assessment", [
       ("Assessed Arrangement", "Sub-custodian network arrangement assessed, where the assessment covers a sub-custodian.", "Custody Assessment", "Reference (Sub-Custodian Network Arrangement, 28)", "", "Global custodian A / BR / Sub-custodian B (2021-07-01)", "SEC Rule 17f-5", "", ""),
       ("Assessed Depository", "Depository assessed, where the assessment covers a securities depository.", "Custody Assessment", "Reference (Party)", "", "PTY-101460", "SEC Rule 17f-7", "", ""),
       ("Foreign Custody Assessment Type", "Rule under which the assessment is performed.", "Custody Assessment", "Code", "Foreign Custody Assessment Type", "Rule 17f-7 Depository Risk Analysis", "SEC Rule 17f-7", "SEC Rule 17f-5", "Y"),
       ("Assessment Date", "Date the assessment was completed.", "Custody Assessment", "Date", "ISO 8601", "2026-03-31", "SEC Rule 17f-5", "", ""),
       ("Assessing Party", "Foreign custody manager or primary custodian that performed the assessment.", "Custody Assessment", "Reference (Party)", "", "PTY-100912", "SEC Rule 17f-5", "", "", "Under Rule 17f-5 the fund board may delegate to a foreign custody manager, usually the global custodian. Where the firm assesses itself, record the 02 party that mirrors the 09 legal entity (CD-010)."),
       ("Custody Risk Rating", "Risk rating given to the custodian or depository.", "Custody Assessment", "Code", "Shared: Risk Rating", "Medium", "SEC Rule 17f-7", "", ""),
       ("Eligibility Decision", "Whether assets may be placed or kept with the custodian or depository.", "Custody Assessment", "Code", "Shared: Approval Status", "Approved with Conditions", "SEC Rule 17f-5", "", "Y"),
       ("Board Report Date", "Date the assessment was reported to the fund board.", "Custody Assessment", "Date", "ISO 8601", "2026-05-14", "SEC Rule 17f-5", "", ""),
     ]),
   ]),
   ("Custodian Service Review", "Periodic oversight of a fund custody provider's service in one role: KPIs, SOC 1 report and fee review (CD-147).", [
     ("Custodian Service Review", [
       ("Reviewed Provider", "Custody provider whose service is reviewed.", "Service Review", "Reference (Party)", "", "PTY-100912", "Internal", "", ""),
       ("Reviewed Provider Role", "Provider role reviewed, which with the provider identifies the Custody Provider Profile.", "Service Review", "Code", "Custody Provider Role", "Global Custodian", "Internal", "", ""),
       ("Review Period Start", "First day of the period reviewed.", "Service Review", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Review Period End", "Last day of the period reviewed.", "Service Review", "Date", "ISO 8601", "2026-06-30", "Internal", "", ""),
       ("Income Paid on Pay Date Percentage", "Share of income events credited on the payment date in the period.", "Service Review", "Percentage", "", "98.7%", "Internal", "", "", "Measured against a 21 Metric Definition (KPI-) once defined."),
       ("SOC 1 Report Received Indicator", "Whether the provider's SOC 1 (ISAE 3402) report covering the period was received.", "Service Review", "Boolean", "", "Y", "AICPA SOC 1", "ISAE 3402", ""),
       ("Service Review Outcome", "Overall conclusion of the review.", "Service Review", "Code", "Service Review Outcome", "Satisfactory with Actions", "Internal", "", ""),
       ("Reviewer", "Employee who performed the review.", "Service Review", "Reference (Employee)", "", "EMP-30877", "Internal", "", "", "PII (employee)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Safekeeping Accounts", "CU-SKP",
  "The accounts at custodians, sub-custodians, banks and securities depositories in which the assets of the firm's funds, portfolios and institutional separate accounts are held, and whose assets each one holds over time. Fund assets only: client assets in the custody of the firm's broker-dealer are client holdings in 49 (CW-007).",
  [
   ("Safekeeping Account", "An account at a custodian, sub-custodian, bank or securities depository in which fund or institutional separate account assets or cash are held (CD-194, option A: every fund, portfolio and institutional separate account). Not a 15 client account, and not the custody of client assets at the firm's broker-dealer (49).", [
     ("Safekeeping Account", [
       ("Safekeeping Account ID", "Unique enterprise identifier of the account.", "Safekeeping Account", "Identifier", "", "SKA-000231", "Internal", "", "Y"),
       ("Account Provider", "Custodian, sub-custodian or bank at which the account is held; exactly one of Account Provider and Internal Account Provider is filled.", "Safekeeping Account", "Reference (Party)", "", "PTY-100912", "ISO 20022", "", "Y", "For a fund's main account this must equal the custodian appointed in 01 Product Party Role (consistency check)."),
       ("Internal Account Provider", "Internal trustee bank at which the account is held where a CIT self-custodies; exactly one of Account Provider and Internal Account Provider is filled.", "Safekeeping Account", "Reference (Legal Entity)", "", "", "OCC 12 CFR 9.13", "", ""),
       ("Safekeeping Account Number", "Account number as issued by the provider.", "Safekeeping Account", "Identifier", "", "123456-01", "ISO 15022", "ISO 20022", "Y", "Mastered here. Confidential; PII where the owner of an institutional separate account is an individual or a personal trust. Mask in non-production environments."),
       ("Safekeeping Account Name", "Title of the account as registered at the provider.", "Safekeeping Account", "Text", "", "GLOBAL EQUITY INCOME FUND - MAIN", "ISO 20022", "", "", "PII where the owner of an institutional separate account is an individual or a personal trust."),
       ("Safekeeping Account Type", "What the account holds: securities, cash at a custodian, cash at a bank, or collateral.", "Safekeeping Account", "Code", "Safekeeping Account Type", "Securities Account", "ISO 20022", "", "Y", "Omnibus versus segregated is Account Holding Model."),
       ("Account Holding Model", "Whether the account pools several owners or is segregated for one owner.", "Safekeeping Account", "Code", "Custody Holding Model", "Individual Client Segregated", "ISSA", "", "", "Only the values Omnibus and Individual Client Segregated apply to an account; Direct Holding and Nominee describe a market (Network Arrangement) and the nominee is Registered Nominee."),
       ("Account Currency", "Currency of a cash or bank account; blank for securities accounts.", "Safekeeping Account", "Code", "ISO 4217", "USD", "ISO 4217", "", ""),
       ("Cash Account IBAN", "International bank account number of a cash or bank account where the provider issues one (cash accounts at sub-custodians in IBAN markets).", "Safekeeping Account", "Identifier", "ISO 13616", "DE89370400440532013000", "ISO 13616", "", "", "Confidential; PII where the owner of an institutional separate account is an individual or a personal trust."),
       ("Registered Nominee", "Nominee company in whose name the securities are registered, where not the beneficial owner.", "Safekeeping Account", "Reference (Party)", "", "PTY-101470", "ISSA", "", ""),
       ("Safekeeping Account Status", "Lifecycle status of the account.", "Safekeeping Account", "Code", "Safekeeping Account Status", "Open", "Internal", "", "Y"),
       ("Account Opened Date", "Date the provider opened the account.", "Safekeeping Account", "Date", "ISO 8601", "2014-02-20", "Internal", "", ""),
       ("Account Closed Date", "Date the provider closed the account.", "Safekeeping Account", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Safekeeping Account Assignment", "Effective-dated link from a safekeeping account to the fund, portfolio or institutional separate account whose assets it holds, one reference per owner type (as 18 Portfolio Implementation Link). A fund account carries the fund and its main book; an institutional separate account's account carries the client account and its book.", [
     ("Safekeeping Account Assignment", [
       ("Assigned Safekeeping Account", "Safekeeping account being assigned.", "Account Assignment", "Reference (Safekeeping Account, 28)", "", "SKA-000231", "Internal", "", "Y"),
       ("Owning Fund", "Fund whose assets the account holds; set for fund and CIT accounts, blank for institutional separate accounts.", "Account Assignment", "Reference (Product)", "", "PRD-00187", "Internal", "", "Y"),
       ("Owning Portfolio", "Managed book whose assets the account holds; set for every account that holds a book's assets.", "Account Assignment", "Reference (Portfolio)", "", "PORT-000412", "Internal", "", "Y"),
       ("Owning Client Account", "Institutional separate account (15 Institutional Account, IA line) whose assets the account holds; set for institutional separate accounts, blank for fund accounts.", "Account Assignment", "Reference (Account)", "", "ACC-0720011", "Internal", "", "Y", "Retail brokerage, retirement and managed accounts have no assignment: their assets are client holdings in the custody of the firm's broker-dealer (49, CW-007, CW-009). PII where the client is an individual or a personal trust."),
       ("Account Assignment Purpose", "What the account is used for on behalf of the owner.", "Account Assignment", "Code", "Account Assignment Purpose", "Main Safekeeping", "Internal", "", "", "The collateral purposes refine the Collateral Account type; they do not replace it."),
       ("Assignment Effective From", "Date the account began to hold the owner's assets for the purpose.", "Account Assignment", "Date", "ISO 8601", "2014-03-03", "Internal", "", ""),
       ("Assignment Effective To", "Date the account stopped holding the owner's assets for the purpose.", "Account Assignment", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Custodian Statements & Reconciliation", "CU-REC",
  "What custodians report (holdings and cash statements per safekeeping account and date, as received) and the firm's reconciliation of those statements against the investment book (18) and the accounting book (27), with the breaks found and their resolution.",
  [
   ("Custodian Statement", "A statement received from a custodian for one safekeeping account, statement type, date and statement number.", [
     ("Custodian Statement", [
       ("Statement Safekeeping Account", "Safekeeping account the statement covers.", "Statement", "Reference (Safekeeping Account, 28)", "", "SKA-000231", "ISO 20022", "", ""),
       ("Custodian Statement Type", "Kind of statement received.", "Statement", "Code", "Custodian Statement Type", "Statement of Holdings", "ISO 20022", "ISO 15022", "Y"),
       ("Statement Date", "Date as of which the statement reports balances.", "Statement", "Date", "ISO 8601", "2026-10-05", "ISO 20022", "", "Y"),
       ("Statement Number", "Sequence number the custodian gives the statement (and page), which separates intraday, delta and complete statements of the same date.", "Statement", "Identifier", "", "00412/001", "ISO 15022", "ISO 20022", ""),
       ("Complete Statement Indicator", "Whether the statement reports every holding (complete) rather than only changes (delta).", "Statement", "Boolean", "", "Y", "ISO 15022", "ISO 20022", ""),
       ("Statement Message Type", "Message type of the statement, such as semt.002, MT535, camt.053 or MT950; the message standard follows from it.", "Statement", "Code", "External (ISO 20022 / ISO 15022 message type)", "MT535", "ISO 15022", "ISO 20022", ""),
     ]),
   ]),
   ("Custodian Holding Statement Line", "One holding as asserted by the custodian on a statement (never a 'Position', CD-146).", [
     ("Custodian Holding Statement Line", [
       ("Holding Line Statement", "Statement the line belongs to.", "Holding Line", "Reference (Custodian Statement, 28)", "", "SKA-000231 / Statement of Holdings / 2026-10-05 / 00412", "ISO 20022", "", ""),
       ("Custodian Security Identifier", "Identifier of the instrument exactly as the custodian reported it.", "Holding Line", "Identifier", "ISO 6166", "US0378331005", "ISO 20022", "", "", "Part of the line's key, so unmatched lines can be held."),
       ("Statement Line Instrument", "Instrument the reported identifier was matched to in the security master; blank until matched.", "Holding Line", "Reference (Instrument, 17)", "", "INS-00412873", "ISO 20022", "", "Y"),
       ("Place of Safekeeping", "Depository or sub-custodian where the custodian says the holding is kept.", "Holding Line", "Reference (Party)", "", "PTY-101460", "ISO 20022", "", ""),
       ("Custodian Balance Type", "Sub-balance the quantity belongs to, such as available, pledged or out on loan.", "Holding Line", "Code", "Custodian Balance Type", "Available", "ISO 20022", "ISO 15022", "Y", "The on-loan sub-balance is the custodian's assertion; the loan itself is mastered on Securities Loan."),
       ("Custodian Quantity", "Quantity (units or face amount) the custodian reports for the balance type.", "Holding Line", "Decimal", "", "125000", "ISO 20022", "", "Y"),
       ("Custodian Market Value", "Market value of the holding as reported by the custodian.", "Holding Line", "Amount", "", "USD 28,612,500.00", "ISO 20022", "", "", "The custodian's valuation; official prices are 22's."),
     ]),
   ]),
   ("Custodian Cash Statement Entry", "One booked cash movement on a custodian cash statement.", [
     ("Custodian Cash Statement Entry", [
       ("Cash Entry Statement", "Statement the entry belongs to.", "Cash Entry", "Reference (Custodian Statement, 28)", "", "SKA-000232 / Cash Statement / 2026-10-05 / 00198", "ISO 20022", "", ""),
       ("Custodian Entry Reference", "Account servicer reference of the entry.", "Cash Entry", "Identifier", "", "ASR20261005-00881", "ISO 20022", "", ""),
       ("Entry Value Date", "Date from which the entry bears value.", "Cash Entry", "Date", "ISO 8601", "2026-10-05", "ISO 20022", "", ""),
       ("Entry Amount", "Amount of the entry; signed, positive for a credit and negative for a debit.", "Cash Entry", "Amount", "", "USD -2,500,000.00", "ISO 20022", "", "Y"),
       ("Bank Transaction Code", "Code classifying the entry (domain, family, sub-family), as sent by the custodian.", "Cash Entry", "Code", "External (ISO 20022 Bank Transaction Code)", "SECU / SETT / TRAD", "ISO 20022", "", ""),
     ]),
   ]),
   ("Custody Reconciliation Run", "One reconciliation of a portfolio or account against the custodian for one type and business date (CD-196).", [
     ("Custody Reconciliation Run", [
       ("Custody Reconciliation Run ID", "Unique identifier of the reconciliation run.", "Reconciliation Run", "Identifier", "", "CUREC-2026-100541", "Internal", "", "Y"),
       ("Custody Reconciliation Type", "Which two records are compared.", "Reconciliation Run", "Code", "Custody Reconciliation Type", "IBOR vs Custodian Holdings", "Internal", "", "Y"),
       ("Reconciled Portfolio", "Portfolio whose book is compared, where the scope is a portfolio.", "Reconciliation Run", "Reference (Portfolio)", "", "PORT-000412", "Internal", "", "Y"),
       ("Reconciled Safekeeping Account", "Safekeeping account compared, where the scope is an account.", "Reconciliation Run", "Reference (Safekeeping Account, 28)", "", "SKA-000231", "Internal", "", "Y"),
       ("Reconciliation Business Date", "Business date of the balances compared.", "Reconciliation Run", "Date", "ISO 8601", "2026-10-05", "Internal", "", "Y"),
       ("Compared Custodian Statement", "Custodian statement used as the external side.", "Reconciliation Run", "Reference (Custodian Statement, 28)", "", "SKA-000231 / Statement of Holdings / 2026-10-05 / 00412", "Internal", "", ""),
       ("Reconciliation Status", "Outcome of the run.", "Reconciliation Run", "Code", "Shared: Reconciliation Status", "Break Open", "Internal", "", "Y"),
       ("Signed Off By", "Employee who signed off the run.", "Reconciliation Run", "Reference (Employee)", "", "EMP-30912", "Internal", "", "", "PII (employee)."),
     ]),
   ]),
   ("Custody Reconciliation Break", "A difference found by a reconciliation run, keyed CUREC-n-Bnn, with its owner, cause and resolution.", [
     ("Custody Reconciliation Break", [
       ("Break ID", "Identifier of the break within its run.", "Break", "Identifier", "", "CUREC-2026-100541-B03", "Internal", "", "Y"),
       ("Break Run", "Reconciliation run that raised the break.", "Break", "Reference (Custody Reconciliation Run, 28)", "", "CUREC-2026-100541", "Internal", "", ""),
       ("Custody Break Type", "Nature of the difference.", "Break", "Code", "Custody Break Type", "Quantity Difference", "Internal", "", "Y"),
       ("Break Instrument", "Instrument the break concerns, for holding breaks.", "Break", "Reference (Instrument, 17)", "", "INS-00412873", "Internal", "", ""),
       ("Book Holding", "18 Portfolio Holding compared, for IBOR holding breaks.", "Break", "Reference (Portfolio Holding)", "", "HLD-0000000099812331", "Internal", "", ""),
       ("Book Cash Balance", "18 cash balance compared, for cash breaks.", "Break", "Reference (Cash Balance, 18)", "", "PORT-000412 / EUR / 2026-10-05", "Internal", "", ""),
       ("ABOR Valuation Record", "27 ABOR record compared, for ABOR breaks.", "Break", "Reference (ABOR Valuation Record, 27)", "", "GEIF US GAAP book / US0378331005 / 2026-10-05", "Internal", "", ""),
       ("Custodian Statement Line", "Custodian holding line compared.", "Break", "Reference (Custodian Holding Statement Line, 28)", "", "SKA-000231 / 2026-10-05 / US0378331005 / Available", "Internal", "", ""),
       ("Quantity Difference", "Book quantity minus custodian quantity; signed.", "Break", "Decimal", "", "-5000", "Internal", "", "Y", "The two quantities stay in 18 and on the statement line; only the difference is held here."),
       ("Amount Difference", "Book amount minus custodian amount; signed.", "Break", "Amount", "", "USD -1,144,500.00", "Internal", "", "Y"),
       ("Difference Valuation Price", "Approved price used to value a quantity difference.", "Break", "Reference (Approved Price, 22)", "", "PRICE-20261005-00091822-01-01", "Internal", "", ""),
       ("Break Severity", "Severity assigned to the break.", "Break", "Code", "Shared: Severity", "High", "Internal", "", ""),
       ("Break Owner", "Employee responsible for resolving the break.", "Break", "Reference (Employee)", "", "EMP-30912", "Internal", "", "", "PII (employee)."),
       ("Break Root Cause", "Cause of the break, once investigated.", "Break", "Code", "Break Root Cause", "Late Settlement", "Internal", "", ""),
       ("Related Settlement Instruction", "26 settlement instruction whose status or fail caused the break, where the cause is a settlement.", "Break", "Reference (Settlement Instruction, 26)", "", "SETL-2026-00881230", "Internal", "", "", "26 masters settlement status and fails; 28 holds only the link."),
       ("Related AP Order", "ETF creation or redemption order whose basket delivery caused the break.", "Break", "Reference (AP Creation / Redemption Order, 29)", "", "ECR-2026-004410", "Internal", "SEC Rule 6c-11", "", "Shortcut: the same order is reachable through the 26 settlement instruction of the basket (CD-183). Kept because asset servicing investigates ETF breaks by AP order."),
       ("Break Case Status", "Workflow status of the break.", "Break", "Code", "Shared: Case Status", "In Progress", "Internal", "", "Y"),
       ("Break Resolution Date", "Date the break was resolved.", "Break", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Corporate Action Processing", "CU-CAX",
  "Per-account processing of corporate actions announced in 17 on fund and institutional separate account assets, including dividends and interest (corporate actions on client holdings are 49's): the custodian's notification to each safekeeping account, the entitlement of the account, the election instructed on voluntary and optional events, and the payment the custodian booked, which holds the cash and withholding facts. The resulting change in the 18 Portfolio Holding is booked as an 18 Portfolio Transaction (CD-195).",
  [
   ("Corporate Action Notification Receipt", "One custodian notification message (seev.031 / MT564) of a 17 event to one safekeeping account, with differences from the golden copy.", [
     ("Corporate Action Notification Receipt", [
       ("Notified Event", "Corporate action event the notification refers to.", "CA Notification", "Reference (Corporate Action Event, 17)", "", "CAE-2026-0019876", "ISO 20022", "SMPG", "Y"),
       ("Notified Safekeeping Account", "Safekeeping account notified.", "CA Notification", "Reference (Safekeeping Account, 28)", "", "SKA-000231", "ISO 20022", "", ""),
       ("Custodian Event Reference", "Custodian's own reference for the event on this account (CORP), the same on every notification of the event.", "CA Notification", "Identifier", "", "CA88123GC", "ISO 15022", "ISO 20022", ""),
       ("Custodian Message Reference", "Sender's reference of this notification message (SEME), which identifies the receipt.", "CA Notification", "Identifier", "", "N20260801-0045519", "ISO 15022", "ISO 20022", ""),
       ("Notification Function", "Whether the message is a new notification, a replacement, a reminder or a cancellation (:23G:).", "CA Notification", "Code", "Notification Function", "New", "ISO 15022", "ISO 20022", ""),
       ("Custodian Response Deadline", "Deadline the custodian sets for this account's election, usually earlier than the 17 market deadline.", "CA Notification", "Timestamp", "ISO 8601", "2026-08-20T16:00:00-04:00", "ISO 20022", "SMPG", "Y"),
       ("Golden Copy Discrepancy Indicator", "Whether the notification differs from the 17 golden copy in a date, rate or option.", "CA Notification", "Boolean", "", "N", "Internal", "", ""),
     ]),
   ]),
   ("Corporate Action Entitlement", "The entitlement of one safekeeping account, for one portfolio, to one event (CAEN-).", [
     ("Corporate Action Entitlement", [
       ("Corporate Action Entitlement ID", "Unique identifier of the entitlement.", "Entitlement", "Identifier", "", "CAEN-2026-0045120", "Internal", "", "Y"),
       ("Entitlement Event", "Corporate action event the entitlement arises from.", "Entitlement", "Reference (Corporate Action Event, 17)", "", "CAE-2026-0012345", "ISO 20022", "", "Y"),
       ("Entitled Safekeeping Account", "Safekeeping account entitled.", "Entitlement", "Reference (Safekeeping Account, 28)", "", "SKA-000231", "ISO 20022", "", "Y"),
       ("Entitled Portfolio", "Portfolio whose 18 Portfolio Holding gives rise to the entitlement; part of the key when an omnibus account serves several portfolios.", "Entitlement", "Reference (Portfolio)", "", "PORT-000412", "Internal", "", ""),
       ("Eligible Balance", "Quantity held on the record date (or ex-date) that qualifies for the event.", "Entitlement", "Decimal", "", "125000", "ISO 20022", "SMPG", "Y"),
       ("Entitled Cash Amount", "Total gross cash due to the account across all elections (or under the default option).", "Entitlement", "Amount", "", "USD 32,500.00", "ISO 20022", "", "Y"),
       ("Entitled Securities Quantity", "Total quantity of securities due to the account across all elections.", "Entitlement", "Decimal", "", "", "ISO 20022", "", "Y"),
       ("Market Claim Indicator", "Whether part of the entitlement is due through a market claim on a pending trade.", "Entitlement", "Boolean", "", "N", "SMPG", "", ""),
       ("Corporate Action Entitlement Status", "Processing status of the entitlement.", "Entitlement", "Code", "Corporate Action Entitlement Status", "Confirmed", "Internal", "", "Y"),
     ]),
   ]),
   ("Corporate Action Election", "An election instructed for an entitlement: option, quantity, decision and instruction lifecycle (seev.033 / MT565, status seev.034 / MT567) (ELECT-).", [
     ("Corporate Action Election", [
       ("Corporate Action Election ID", "Unique identifier of the election.", "Election", "Identifier", "", "ELECT-2026-0008812", "Internal", "", "Y"),
       ("Elected Entitlement", "Entitlement the election is made for.", "Election", "Reference (Corporate Action Entitlement, 28)", "", "CAEN-2026-0045388", "ISO 20022", "", ""),
       ("Elected Option", "17 option chosen (event and option number).", "Election", "Reference (Corporate Action Option, 17)", "", "CAE-2026-0019876 / 2", "ISO 20022", "SMPG", "Y"),
       ("Elected Quantity", "Quantity of the eligible balance instructed under the option.", "Election", "Decimal", "", "125000", "ISO 20022", "", "Y"),
       ("Election Decision Maker", "Employee who decided the election.", "Election", "Reference (Employee)", "", "EMP-20415", "Internal", "", "", "PII (employee)."),
       ("Election Investment Decision", "Portfolio manager's investment decision behind the election, where 24 records it.", "Election", "Reference (Investment Decision, 24)", "", "IDEC-2026-0031122", "Internal", "", ""),
       ("Internal Election Deadline", "Firm deadline for the decision, set before the custodian's deadline.", "Election", "Timestamp", "ISO 8601", "2026-08-19T12:00:00-04:00", "Internal", "", "Y"),
       ("Election Instruction Status", "Stage of the instruction in its lifecycle, from the firm's draft through the custodian's acceptance to execution in the market, or the default applied when no instruction arrived.", "Election", "Code", "Election Instruction Status", "Accepted by Custodian", "ISO 20022", "SMPG", "Y"),
     ]),
   ]),
   ("Corporate Action Payment", "Cash or securities booked by the custodian for an entitlement (seev.036 / MT566), including reversals (seev.037). For dividends and interest it is the one record of income received and tax withheld.", [
     ("Corporate Action Payment", [
       ("Paid Entitlement", "Entitlement the payment settles.", "CA Payment", "Reference (Corporate Action Entitlement, 28)", "", "CAEN-2026-0045120", "ISO 20022", "", "Y"),
       ("Payment Confirmation Reference", "Reference of the custodian's movement confirmation or reversal message, which identifies the payment.", "CA Payment", "Identifier", "", "CONF20260814-0031", "ISO 20022", "ISO 15022", ""),
       ("Corporate Action Payment Type", "Whether the payment delivers cash, securities or both.", "CA Payment", "Code", "Corporate Action Payment Type", "Cash", "ISO 20022", "", ""),
       ("Payment Posting Date", "Date the custodian booked the payment.", "CA Payment", "Date", "ISO 8601", "2026-08-14", "ISO 20022", "", ""),
       ("Paid Gross Amount", "Gross cash amount before withholding tax.", "CA Payment", "Amount", "", "USD 32,500.00", "ISO 20022", "", ""),
       ("Withholding Tax Amount", "Tax withheld at source from the payment; the master of withholding for reclaims.", "CA Payment", "Amount", "", "USD 4,875.00", "ISO 20022", "OECD TRACE", "Y"),
       ("Paid Net Amount", "Cash credited after withholding tax and charges; the master of income received.", "CA Payment", "Amount", "", "USD 27,625.00", "ISO 20022", "", "Y"),
       ("Paid Securities Quantity", "Quantity of securities delivered or debited.", "CA Payment", "Decimal", "", "", "ISO 20022", "", ""),
       ("Delivered Instrument", "Instrument delivered, for securities payments.", "CA Payment", "Reference (Instrument, 17)", "", "", "ISO 20022", "", ""),
       ("Reversal Indicator", "Whether the record reverses an earlier payment.", "CA Payment", "Boolean", "", "N", "ISO 20022", "", ""),
       ("Booked Portfolio Transaction", "18 portfolio transaction that books the payment in the IBOR.", "CA Payment", "Reference (Portfolio Transaction)", "", "PTXN-2026-008140012", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Income & Tax Recovery", "CU-INC",
  "Control of income received against income expected, and recovery of what is withheld or lost: income collection over the corporate action payment, tax relief documentation filed per fund and market, withholding tax reclaims, and securities class action claims. Kept here under the tax split by producer (CD-149).",
  [
   ("Income Collection", "The control record over one income entitlement: income expected by 27 against the payment received, timing and chasing. The cash and withholding facts stay on the Corporate Action Payment.", [
     ("Income Collection", [
       ("Income Entitlement", "Dividend, interest or other income entitlement controlled.", "Income Collection", "Reference (Corporate Action Entitlement, 28)", "", "CAEN-2026-0045120", "Internal", "", "Y"),
       ("Income Due Date", "Date the income was due to be paid: the 17 Corporate Action Payment Date of the entitlement's event.", "Income Collection", "Date", "ISO 8601", "2026-08-14", "ISO 20022", "", "", "Derived copy (17) for every row: income without a 17 event is not controlled here until 17 announces it."),
       ("Expected Income Accrual", "27 income accrual row booked for the event on its ex-date (dividends) or for the coupon on the payment date (interest), which states what the fund expects.", "Income Collection", "Reference (Income Accrual, 27)", "", "GEIF US GAAP book / US0378331005 / Dividend / 2026-08-11", "Internal", "ASC 946", ""),
       ("Expected Net Income Amount", "Net income the fund expects: the accrued income balance less the withholding tax accrued on the expected accrual row.", "Income Collection", "Amount", "", "USD 27,625.00", "ASC 946", "", "", "Derived copy (27)."),
       ("Received Payment", "Corporate action payment that delivered the income, once received.", "Income Collection", "Reference (Corporate Action Payment, 28)", "", "CAEN-2026-0045120 / CONF20260814-0031", "Internal", "", ""),
       ("Income Difference Amount", "Expected net income minus the paid net amount of the received payment; signed.", "Income Collection", "Amount", "", "USD 0.00", "Internal", "", "Y"),
       ("Income Claim Status", "Stage of the control, from expected through received to any claim and its outcome.", "Income Collection", "Code", "Income Claim Status", "Received in Full", "Internal", "", ""),
     ]),
   ]),
   ("Tax Relief Documentation", "Documentation filed so a fund, as beneficial owner, receives treaty relief in a market.", [
     ("Tax Relief Documentation", [
       ("Beneficial Owner Fund", "Fund claiming relief as beneficial owner.", "Tax Relief", "Reference (Product)", "", "PRD-00187", "OECD TRACE", "", "Y"),
       ("Relief Market", "Market (source country) in which relief is claimed.", "Tax Relief", "Code", "ISO 3166-1 alpha-2", "DE", "OECD TRACE", "", ""),
       ("Tax Relief Method", "Procedure by which withholding is reduced.", "Tax Relief", "Code", "Tax Relief Method", "Long-Form Reclaim", "OECD TRACE", "EU FASTER Directive", "Y"),
       ("Treaty Rate Percentage", "Withholding rate due under the applicable treaty.", "Tax Relief", "Percentage", "", "15%", "OECD Model Tax Convention", "", ""),
       ("Relief Form", "Form or certificate filed, as named by the tax authority.", "Tax Relief", "Text", "", "Certificate of Residence (IRS Form 6166)", "IRS", "", ""),
       ("Documentation Approval Status", "Whether the tax authority or withholding agent accepted the documentation.", "Tax Relief", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("Documentation Expiry Date", "Date after which the documentation must be renewed.", "Tax Relief", "Date", "ISO 8601", "2027-12-31", "Internal", "", ""),
       ("Relief Effective From", "Date from which relief applies.", "Tax Relief", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Relief Effective To", "Date relief stops applying.", "Tax Relief", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Withholding Tax Reclaim", "A claim to a tax authority for withholding tax above the treaty or domestic rate on one payment (WHTR-).", [
     ("Withholding Tax Reclaim", [
       ("Withholding Tax Reclaim ID", "Unique identifier of the reclaim.", "Reclaim", "Identifier", "", "WHTR-2026-00317", "Internal", "", "Y"),
       ("Reclaiming Fund", "Fund on whose behalf tax is reclaimed.", "Reclaim", "Reference (Product)", "", "PRD-00187", "Internal", "", ""),
       ("Reclaim Market", "Country whose tax authority receives the reclaim.", "Reclaim", "Code", "ISO 3166-1 alpha-2", "DE", "OECD TRACE", "", ""),
       ("Source Payment", "Corporate action payment whose withholding tax is reclaimed; the amount withheld is read from it.", "Reclaim", "Reference (Corporate Action Payment, 28)", "", "CAEN-2026-0051877 / CONF20260515-0107", "Internal", "", "", "Where a market requires one filing for several payments, each payment keeps its own reclaim record and the filing reference groups them."),
       ("Reclaimable Amount", "Part of the withheld tax that can be recovered.", "Reclaim", "Amount", "", "EUR 11,375.00", "OECD TRACE", "", "Y"),
       ("Reclaim Filing Reference", "Reference of the filing submitted to the tax authority, shared by reclaims filed together.", "Reclaim", "Identifier", "", "BZST-2026-448812", "Internal", "", ""),
       ("Reclaim Filed Date", "Date the reclaim was filed.", "Reclaim", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
       ("Filing Agent", "Custodian or tax service provider that filed the reclaim.", "Reclaim", "Reference (Party)", "", "PTY-100912", "Internal", "", ""),
       ("Statute of Limitation Date", "Last date on which the reclaim can be filed.", "Reclaim", "Date", "ISO 8601", "2030-12-31", "Internal", "", ""),
       ("Tax Reclaim Status", "Status of the reclaim with the tax authority.", "Reclaim", "Code", "Tax Reclaim Status", "Filed", "Internal", "", "Y"),
       ("Recovered Amount", "Amount refunded by the tax authority.", "Reclaim", "Amount", "", "", "Internal", "", "Y"),
     ]),
   ]),
   ("Class Action Claim", "A claim filed for a fund or an institutional separate account on a securities class action settlement announced in 17 as a class action event (SCAC-). Case facts (name, class period, filing deadline) are read from the 17 event.", [
     ("Class Action Claim", [
       ("Class Action Claim ID", "Unique identifier of the claim.", "Class Action", "Identifier", "", "SCAC-00142", "Internal", "", "Y"),
       ("Class Action Event", "17 corporate action event of type Class Action that carries the case, settlement class instrument, class period and filing deadline.", "Class Action", "Reference (Corporate Action Event, 17)", "", "CAE-2026-0007712", "ISO 15022", "SMPG", "Y"),
       ("Claiming Fund", "Fund that bought the instrument in the class period.", "Class Action", "Reference (Product)", "", "PRD-00187", "Internal", "", ""),
       ("Claiming Client Account", "Institutional separate account for which a claim is filed, where the firm files for institutional clients.", "Class Action", "Reference (Account)", "", "", "Internal", "", "", "Claims on the client holdings of retail brokerage, retirement and managed accounts are 49's (W3). PII where the client is an individual or a personal trust."),
       ("Eligible Purchase Quantity", "Quantity bought in the class period that the claim covers.", "Class Action", "Decimal", "", "48000", "PSLRA", "", ""),
       ("Recognized Loss Amount", "Loss calculated under the plan of allocation.", "Class Action", "Amount", "", "USD 412,880.00", "PSLRA", "", "Y", "PII where the claim is filed for an individual client account."),
       ("Claim Filing Agent", "Custodian or claims service that files the claim.", "Class Action", "Reference (Party)", "", "PTY-101520", "Internal", "", ""),
       ("Claim Filed Date", "Date the claim was submitted.", "Class Action", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Opt-Out Indicator", "Whether the fund opted out of the class to pursue its own action or joined a non-US collective action.", "Class Action", "Boolean", "", "N", "Internal", "", ""),
       ("Class Action Claim Status", "Status of the claim.", "Class Action", "Code", "Class Action Claim Status", "Filed", "Internal", "", "Y"),
       ("Recovery Amount", "Amount distributed to the claimant.", "Class Action", "Amount", "", "", "Internal", "", "Y", "PII where the claim is filed for an individual client account."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Securities Lending", "CU-SLN",
  "The securities lending of funds and portfolios through an agent lender: programs and their limits, the lending agreements they operate under (CD-182), each loan with its collateral and regulatory reporting, and the split of lending revenue (CD-198). The permission to lend is 01's; trading agreements and OTC and margin collateral are 26's; cash collateral reinvestment vehicles are 18 portfolios.",
  [
   ("Securities Lending Program", "A fund's or portfolio's participation in a lending program with one agent lender.", [
     ("Securities Lending Program", [
       ("Lending Fund", "Fund that lends, which 01 must permit to lend.", "Lending Program", "Reference (Product)", "", "PRD-00187", "Internal", "", "Y"),
       ("Lending Portfolio", "Portfolio whose 18 Portfolio Holdings are lent.", "Lending Program", "Reference (Portfolio)", "", "PORT-000412", "Internal", "", ""),
       ("Agent Lender", "Custodian or third-party agent that lends on the fund's behalf.", "Lending Program", "Reference (Party)", "", "PTY-100912", "Internal", "", ""),
       ("Maximum On-Loan Percentage", "Highest share of the fund's assets that may be on loan.", "Lending Program", "Percentage", "", "33.33%", "Investment Company Act Section 18", "", "Y", "Provisional: future owner 01 as a fund policy limit (proposals_28). SEC staff position for registered funds; confirm the fund's own limit."),
       ("Fund Revenue Share Percentage", "Share of net lending revenue retained by the fund.", "Lending Program", "Percentage", "", "85%", "Internal", "SEC Form N-CEN", ""),
       ("Cash Collateral Reinvestment Portfolio", "18 portfolio in which cash collateral is reinvested.", "Lending Program", "Reference (Portfolio)", "", "PORT-000980", "Internal", "", ""),
       ("Program Status", "Whether the program is active.", "Lending Program", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
       ("Program Effective From", "Date the fund joined the program.", "Lending Program", "Date", "ISO 8601", "2019-05-01", "Internal", "", ""),
       ("Program Effective To", "Date the fund left the program.", "Lending Program", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Securities Lending Agreement", "A lending agreement under which a program operates: the authorization agreement between the fund and its agent, or a master lending agreement the agent signs with a borrower (CD-182).", [
     ("Securities Lending Agreement", [
       ("Agreement Program", "Lending program the agreement serves.", "Lending Agreement", "Reference (Securities Lending Program, 28)", "", "PRD-00187 / PTY-100912", "Internal", "", ""),
       ("Agreement Agent", "Agent lender that is party to the agreement.", "Lending Agreement", "Reference (Party)", "", "PTY-100912", "ISLA GMSLA", "", ""),
       ("Agreement Counterparty", "Borrower that is party to a master lending agreement; blank for the authorization agreement between the fund and its agent.", "Lending Agreement", "Reference (Party)", "", "PTY-101602", "ISLA GMSLA", "", ""),
       ("Lending Agreement Type", "Form of the agreement.", "Lending Agreement", "Code", "Lending Agreement Type", "GMSLA 2010", "ISLA GMSLA", "", "Y"),
       ("Eligible Collateral Types", "Collateral the agreement allows the borrower to deliver.", "Lending Agreement", "Code (multi)", "Lending Collateral Type", "Cash; US Treasury Securities; Other Government Bonds", "ISLA GMSLA", "", ""),
       ("Minimum Collateral Margin Percentage", "Collateral required as a share of loan value.", "Lending Agreement", "Percentage", "", "102%", "ISLA GMSLA", "", "Y"),
       ("Borrower Default Indemnification Indicator", "Whether the agent indemnifies the fund against borrower default under the agreement.", "Lending Agreement", "Boolean", "", "Y", "SEC Form N-CEN", "", ""),
       ("Agreement Document Reference", "Location of the signed agreement in the document store.", "Lending Agreement", "Text", "URI", "doc://legal/sla/2019-04-gmsla-borrower-b.pdf", "Internal", "", "", "39 Legal will index the document; the agreement record is mastered here (CD-182)."),
       ("Agreement Status", "Whether the agreement is in force.", "Lending Agreement", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
       ("Agreement Effective Date", "Date the agreement took effect.", "Lending Agreement", "Date", "ISO 8601", "2019-04-15", "ISLA GMSLA", "", ""),
       ("Agreement Termination Date", "Date the agreement ended.", "Lending Agreement", "Date", "ISO 8601", "", "ISLA GMSLA", "", ""),
     ]),
   ]),
   ("Securities Loan", "One loan of securities to a borrower (SBL-). Loan Value is the current state at the latest mark; history of marks is kept by the agent's daily reports.", [
     ("Securities Loan", [
       ("Securities Loan ID", "Unique identifier of the loan.", "Loan", "Identifier", "", "SBL-2026-0119822", "Internal", "", "Y"),
       ("Loan Program", "Lending program under which the loan is made.", "Loan", "Reference (Securities Lending Program, 28)", "", "PRD-00187 / PTY-100912", "Internal", "", ""),
       ("Governing Agreement", "Master lending agreement with the borrower under which the loan is made.", "Loan", "Reference (Securities Lending Agreement, 28)", "", "PRD-00187 / PTY-100912 / PTY-101602", "ISLA GMSLA", "", ""),
       ("Lent From Account", "Safekeeping account from which the securities are lent.", "Loan", "Reference (Safekeeping Account, 28)", "", "SKA-000231", "Internal", "", ""),
       ("Borrower", "Party that borrows the securities.", "Loan", "Reference (Party)", "", "PTY-101602", "ISLA GMSLA", "SEC Rule 10c-1a", "Y"),
       ("Loaned Instrument", "Instrument lent.", "Loan", "Reference (Instrument, 17)", "", "INS-00412873", "SEC Rule 10c-1a", "", "Y"),
       ("Loan Quantity", "Quantity on loan.", "Loan", "Decimal", "", "20000", "SEC Rule 10c-1a", "", "Y", "The fact of record for on-loan quantity; 18 and the custodian show it as a sub-balance."),
       ("Loan Value", "Market value of the securities on loan at the latest mark.", "Loan", "Amount", "", "USD 4,578,000.00", "ISLA GMSLA", "", "Y"),
       ("Loan Mark Date", "Date of the mark that Loan Value reflects.", "Loan", "Date", "ISO 8601", "2026-10-05", "ISLA GMSLA", "", ""),
       ("Lending Fee Rate", "Annual fee rate the borrower pays, for loans against non-cash collateral.", "Loan", "Percentage", "", "0.35%", "SEC Rule 10c-1a", "", ""),
       ("Rebate Rate", "Annual rate paid to the borrower on cash collateral.", "Loan", "Percentage", "", "", "SEC Rule 10c-1a", "", ""),
       ("Recall Date", "Date the lender recalled the securities, for example to vote or sell.", "Loan", "Date", "ISO 8601", "", "ISLA GMSLA", "", ""),
       ("Loan Return Date", "Date the securities were returned.", "Loan", "Date", "ISO 8601", "", "ISLA GMSLA", "", ""),
       ("Securities Loan Status", "Lifecycle status of the loan.", "Loan", "Code", "Securities Loan Status", "Open", "Internal", "", "Y"),
     ]),
   ]),
   ("Lending Collateral Received", "One collateral item received against a loan, or against a borrower's pool where the tri-party agent allocates collateral across loans, at one mark date. Not OTC or margin collateral (26).", [
     ("Lending Collateral Received", [
       ("Collateralized Loan", "Loan the item collateralizes; blank where collateral is held against a borrower pool.", "Lending Collateral", "Reference (Securities Loan, 28)", "", "SBL-2026-0119822", "Internal", "", ""),
       ("Collateral Pool Borrower", "Borrower whose pooled collateral the item belongs to, where collateral is not allocated loan by loan.", "Lending Collateral", "Reference (Party)", "", "", "Internal", "", ""),
       ("Collateral Mark Date", "Date of the valuation the row records.", "Lending Collateral", "Date", "ISO 8601", "2026-10-05", "ISLA GMSLA", "", ""),
       ("Lending Collateral Type", "Kind of collateral received.", "Lending Collateral", "Code", "Lending Collateral Type", "US Treasury Securities", "ISLA GMSLA", "SEC Rule 10c-1a", ""),
       ("Collateral Instrument", "Security received as collateral; blank for cash.", "Lending Collateral", "Reference (Instrument, 17)", "", "INS-00700015", "Internal", "", ""),
       ("Collateral Value", "Market value of the item at the mark date.", "Lending Collateral", "Amount", "", "USD 4,669,560.00", "ISLA GMSLA", "", "Y"),
       ("Collateral Margin Percentage", "Collateral value as a share of the loan value at the mark date.", "Lending Collateral", "Percentage", "", "102%", "ISLA GMSLA", "", ""),
       ("Tri-Party Agent", "Agent that holds and manages non-cash collateral.", "Lending Collateral", "Reference (Party)", "", "PTY-101611", "Internal", "", ""),
     ]),
   ]),
   ("Loan Regulatory Report", "The report of one loan under one regime (SEC Rule 10c-1a, reported to FINRA).", [
     ("Loan Regulatory Report", [
       ("Reported Loan", "Loan reported.", "Loan Report", "Reference (Securities Loan, 28)", "", "SBL-2026-0119822", "SEC Rule 10c-1a", "", ""),
       ("Loan Reporting Regime", "Regime under which the loan is reported.", "Loan Report", "Code", "Loan Reporting Regime", "SEC Rule 10c-1a", "SEC Rule 10c-1a", "", "", "One US value today (a member of the shared Regulatory Trade Report Regime list); kept so that the grain holds if a second regime applies."),
       ("Reporting Party", "Party that submits the report (agent lender or the firm entity).", "Loan Report", "Reference (Party)", "", "PTY-100912", "SEC Rule 10c-1a", "", "", "Where the firm reports, record the 02 party that mirrors the 09 legal entity (CD-010)."),
       ("Unique Transaction Identifier", "Identifier of the loan in the regulatory report: under Rule 10c-1a, the unique identifier FINRA assigns to the reported loan.", "Loan Report", "Identifier", "", "SL20260902000119822", "SEC Rule 10c-1a", "", "Y", "Confirm the format of the FINRA-assigned identifier (SLATE)."),
       ("Loan Report Status", "Status of the report at FINRA.", "Loan Report", "Code", "Loan Report Status", "Accepted", "SEC Rule 10c-1a", "", ""),
       ("Reporting Deferred Indicator", "Whether reporting is not yet required because the compliance date has been deferred.", "Loan Report", "Boolean", "", "Y", "SEC Rule 10c-1a", "", "", "SEC exemptive order of 3 December 2025, after the Fifth Circuit remanded Rule 10c-1a to the SEC in August 2025: reporting deferred to 28 September 2028 and public dissemination to 29 March 2029 (confirm the rule's status)."),
     ]),
   ]),
   ("Lending Revenue Allocation", "Lending revenue of a program for one period and its split between fund and agent.", [
     ("Lending Revenue Allocation", [
       ("Revenue Program", "Lending program the revenue relates to.", "Lending Revenue", "Reference (Securities Lending Program, 28)", "", "PRD-00187 / PTY-100912", "Internal", "", ""),
       ("Revenue Period Start", "First day of the period the revenue covers.", "Lending Revenue", "Date", "ISO 8601", "2026-09-01", "Internal", "", ""),
       ("Revenue Period End", "Last day of the period the revenue covers.", "Lending Revenue", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
       ("Gross Lending Revenue", "Fees and reinvestment income earned before rebates and the agent's share.", "Lending Revenue", "Amount", "", "USD 18,220.00", "Internal", "SEC Form N-CEN", ""),
       ("Agent Fee Amount", "Revenue retained by the agent lender.", "Lending Revenue", "Amount", "", "USD 2,431.50", "SEC Form N-CEN", "", ""),
       ("Fund Net Revenue", "Revenue credited to the fund.", "Lending Revenue", "Amount", "", "USD 13,778.50", "SEC Form N-CEN", "", "Y"),
       ("Revenue Data Basis", "Whether the figures are the agent's final report or an estimate.", "Lending Revenue", "Code", "Shared: Data Basis", "Reported / Actual", "Internal", "", "", "Only Reported / Actual and Estimated apply."),
       ("Booked Fund Journal Entry", "27 fund journal entry that books the fund's lending income.", "Lending Revenue", "Reference (Fund Journal Entry, 27)", "", "FJNL-2026-0930-00412", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 # Lists that mirror enterprise shared lists (same name and values as shared_code_lists.py; see proposals_28.py SHARED_MEMBERSHIPS)
 # New in 28
 "Custody Provider Role": ("Investment Company Act Section 17(f); SEC Rules 17f-4 / 17f-5 / 17f-7; Internal", [("Global Custodian","Custodian appointed by the fund or the institutional client; holds assets directly or through sub-custodians"),("Sub-Custodian","Local bank appointed by the global custodian in a market"),("Central Securities Depository","CSD in which securities are held in book-entry form"),("International Central Securities Depository","ICSD such as Euroclear Bank or Clearstream Banking"),("Trustee Custodian","CIT trustee bank acting as its own custodian (the firm's own trust company or a third-party trustee bank); an internal trustee is recorded as Provider Legal Entity"),("Agent Lender","Lends securities on the fund's behalf"),("Tri-Party Collateral Agent","Holds and manages non-cash lending collateral"),("Tax Reclaim Agent","Files withholding tax reclaims"),("Class Action Claims Filer","Files class action claims on the fund's behalf"),("Other","")]),
 "Custody Service Type": ("Internal", [("Safekeeping",""),("Settlement","Delivery and receipt of securities; settlement data is 26's"),("Income Collection",""),("Corporate Actions",""),("Tax Relief and Reclaims",""),("Class Action Filing",""),("Securities Lending",""),("Cash Management","")]),
 "Custody Holding Model": ("ISSA; Internal", [("Direct Holding","Securities held at the CSD in the beneficial owner's name (market level only)"),("Omnibus","Assets of several owners pooled in one account"),("Individual Client Segregated","Account holds the assets of one owner only"),("Nominee","Registered in a nominee company's name for the beneficial owner (market level only)")]),
 "Foreign Custody Assessment Type": ("SEC Rules 17f-4 / 17f-5 / 17f-7", [("Rule 17f-4 Securities Depository","Optional: review of a US securities depository such as DTC; Rule 17f-4 sets conditions on depository use and requires no risk analysis (SME question 14)"),("Rule 17f-5 Eligible Foreign Custodian","Foreign custody manager's determination and monitoring"),("Rule 17f-7 Depository Risk Analysis","Analysis of custody risks of an eligible foreign securities depository")]),
 "Service Review Outcome": ("Internal", [("Satisfactory",""),("Satisfactory with Actions","Remediation actions agreed"),("Unsatisfactory","Escalated; formal remediation plan")]),
 "Safekeeping Account Type": ("ISO 20022 / Internal", [("Securities Account","Holds financial instruments at a custodian or sub-custodian"),("Cash Account","Holds cash in one currency at a custodian"),("Bank Deposit Account","Holds cash at a bank outside the custody chain, such as a fund operating account"),("Collateral Account","Holds collateral received or pledged")]),
 "Safekeeping Account Status": ("Internal", [("Pending Opening","Requested from the provider"),("Open",""),("Blocked","No movements allowed (legal, market or migration hold)"),("Closing","Run-off; no new receipts"),("Closed","")]),
 "Account Assignment Purpose": ("Internal", [("Main Safekeeping","Main securities account of the fund or institutional separate account at the provider"),("Operating Cash",""),("Collateral Received","Refines the Collateral Account type"),("Collateral Posted","Refines the Collateral Account type"),("Securities Lending","Account used for lending activity"),("Subscription / Redemption Cash","Fund dealing cash; used by 29"),("Transition","Temporary account for a portfolio transition")]),
 "Custodian Statement Type": ("ISO 20022 / ISO 15022", [("Statement of Holdings","semt.002 / MT535"),("Statement of Transactions","semt.017 / MT536"),("Statement of Pending Transactions","semt.018 / MT537"),("Cash Statement","camt.053 / MT950 / MT940")]),
 "Custodian Balance Type": ("ISO 15022 MT535 field 93a / ISO 20022 sub-balance types (selection)", [("Available","AWAS"),("Blocked","BLOK"),("On Loan","LOAN"),("Borrowed","BORR"),("Collateral In","COLI"),("Collateral Out","COLO"),("Pledged","PLED"),("Pending Delivery","PEND"),("Pending Receipt","PENR"),("Out for Registration","REGO")]),
 "Custody Reconciliation Type": ("Internal", [("IBOR vs Custodian Holdings","18 holdings against the custodian statement"),("ABOR vs Custodian Holdings","27 ABOR against the custodian statement"),("Cash vs Custodian","18 cash balances against the custodian cash statement"),("Sub-Custodian vs Global Custodian","Network-level check where the firm receives both levels"),("Securities Lending vs Agent","On-loan balances against the agent lender's report")]),
 "Custody Break Type": ("Internal", [("Quantity Difference","Both sides hold the instrument with different quantities"),("Missing at Custodian","Held in the book, absent from the statement"),("Missing in Book","On the statement, absent from the book"),("Cash Amount Difference","Both sides hold the cash balance with different amounts"),("Valuation Difference","Same quantity; ABOR or custodian market value differs"),("Instrument Mismatch","Identifier maps to a different instrument")]),
 "Break Root Cause": ("Internal", [("Late Settlement","Settlement occurred on a different date than the book assumed"),("Failed Settlement","Settlement did not occur; see 26"),("Corporate Action Not Booked",""),("Corporate Action Booked Incorrectly",""),("Income Not Received",""),("Booking Error","Trade or transaction booked wrongly in the book"),("Custodian Error",""),("Static Data Error","Instrument or account set-up"),("Timing Difference","Statement and book cut-offs differ, with no settlement involved"),("Securities Lending Movement","Recall or return not reflected")]),
 "Notification Function": ("ISO 15022 :23G: / ISO 20022 seev.031", [("New","NEWM"),("Replacement","REPL"),("Eligible Balance Replacement","REPE"),("Reminder","RMDR"),("Cancellation","CANC"),("Withdrawal","WITH: event withdrawn by the issuer")]),
 "Corporate Action Entitlement Status": ("Internal / SMPG", [("Projected","Estimated from the 18 Portfolio Holding before record date"),("Confirmed","Confirmed by the custodian on eligible balance"),("Partially Paid",""),("Paid",""),("Reversed",""),("Canceled","Event withdrawn")]),
 "Election Instruction Status": ("Internal / ISO 20022 seev.034 / ISO 15022 MT567", [("Draft","Firm: decision pending"),("Sent","Firm: instruction sent, no custodian status yet"),("Accepted by Custodian","Custodian accepted the instruction; not yet executed in the market"),("Rejected by Custodian","Resend required"),("Executed","Option applied in the market"),("Canceled",""),("Defaulted","No valid instruction; the custodian applied the default option")]),
 "Corporate Action Payment Type": ("ISO 20022 seev.036", [("Cash",""),("Securities",""),("Cash and Securities","")]),
 "Income Claim Status": ("Internal", [("Expected","Due date not reached"),("Received in Full","Paid net amount equals the expected amount within tolerance"),("Short Paid","Received less than expected; claim to be raised"),("Unpaid","Due date passed with no payment; claim to be raised"),("Claim Raised","Claim with the custodian open"),("Claim Settled","Difference recovered"),("Written Off","Difference accepted as a loss")]),
 "Tax Relief Method": ("OECD TRACE; EU FASTER Directive (2025/50) for EU source countries", [("Relief at Source","Treaty rate applied at payment"),("Quick Refund","Excess refunded shortly after payment"),("Long-Form Reclaim","Standard refund procedure after payment"),("Exempt","Domestic exemption for the fund type"),("No Relief Available","")]),
 "Tax Reclaim Status": ("Internal", [("Not Filed",""),("Filed",""),("Queried","Tax authority requested information"),("Partially Recovered",""),("Recovered",""),("Rejected",""),("Time-Barred","Not filed before the statute of limitation")]),
 "Class Action Claim Status": ("Internal", [("Identified","Fund eligible; claim not yet prepared"),("Filed",""),("Deficient","Administrator requested more information"),("Approved",""),("Rejected",""),("Paid",""),("Opted Out","")]),
 "Lending Agreement Type": ("ISLA / Internal", [("Securities Lending Authorization Agreement","Between the lending fund and its agent lender"),("GMSLA 2010","Master agreement with a borrower; title-transfer collateral"),("GMSLA 2018 (Security Interest)","Master agreement with a borrower; pledge collateral"),("Master Securities Loan Agreement","US form of master agreement with a borrower")]),
 "Lending Collateral Type": ("ISLA / SEC Rule 10c-1a", [("Cash",""),("US Treasury Securities",""),("Other Government Bonds",""),("Agency Securities",""),("Equities",""),("Letters of Credit",""),("Other","")]),
 "Securities Loan Status": ("Internal", [("Open",""),("Recalled","Return requested by the lender"),("Partially Returned",""),("Returned",""),("Defaulted","Borrower failed to return")]),
 "Loan Reporting Regime": ("SEC Rule 10c-1a", [("SEC Rule 10c-1a","Reporting to FINRA (compliance deferred to 2028)")]),
 "Loan Report Status": ("Internal / SEC Rule 10c-1a", [("Pending",""),("Submitted",""),("Accepted",""),("Rejected","Correct and resubmit"),("Not Required","")]),
}

# ---------------------------------------------------------------------------
REL = [
 ("Custody Provider Profile","describes","Party [02] or Internal Legal Entity [09]","n : 1","Exactly one of the two; party core stays in 02 (CD-143), an internal CIT trustee is a 09 entity."),
 ("Sub-Custodian Network Arrangement","belongs to","Party (Global Custodian) [02]","n : 1","Per market and effective period."),
 ("Sub-Custodian Network Arrangement","appoints","Party (Sub-Custodian) [02]","n : 1",""),
 ("Sub-Custodian Network Arrangement","holds through","Party (Securities Depository) [02]","n : 0..1",""),
 ("Foreign Custody Assessment","assesses","Sub-Custodian Network Arrangement or Party (Depository) [02]","n : 1","Rules 17f-4, 17f-5 and 17f-7."),
 ("Custodian Service Review","reviews","Custody Provider Profile","n : 1","Provider and role identify the profile; KPIs measured against 21 Metric Definitions."),
 ("Safekeeping Account","is held at","Party (Custodian, Sub-Custodian or Bank) [02] or Internal Legal Entity [09]","n : 1","A fund's main account provider must equal its 01 Product Party Role custodian."),
 ("Safekeeping Account","is assigned to","Investment Product [01] / Portfolio [18] / Account [15] via Safekeeping Account Assignment","1 : 0..n","Effective-dated; an institutional separate account's safekeeping account names its 15 owner without becoming an ACC- (CD-194). Retail accounts have none: their assets are 49 client holdings (CW-007)."),
 ("Custody Account [12]","references","Safekeeping Account","1 : 1","Option A of CD-194: 12 keeps the mandate set-up workflow and points to the SKA- it created (proposed change to 12)."),
 ("Standing Settlement Instruction [26]","settles via","Safekeeping Account","n : 1","CD-155; 28 models no settlement instruction."),
 ("Safekeeping Account","receives","Custodian Statement","1 : 0..n","Per statement type, date and statement number."),
 ("Custodian Statement","contains","Custodian Holding Statement Line / Custodian Cash Statement Entry","1 : 0..n",""),
 ("Custodian Holding Statement Line","is matched to","Instrument [17]","n : 0..1","Blank until matched."),
 ("Custody Reconciliation Run","compares","Portfolio Holding / Cash Balance [18] or ABOR Valuation Record [27] with Custodian Statement","n : 1..n","CD-196; one run per scope, type and business date."),
 ("Custody Reconciliation Run","raises","Custody Reconciliation Break","1 : 0..n","Keyed CUREC-n-Bnn."),
 ("Custody Reconciliation Break","may be caused by","Settlement Instruction [26] / AP Creation / Redemption Order [29]","n : 0..1","Settlement and ETF basket deliveries."),
 ("Corporate Action Event [17]","is notified to","Safekeeping Account via Corporate Action Notification Receipt","1 : 0..n","seev.031 / MT564 messages per account: new, replacement, reminder, cancellation."),
 ("Corporate Action Event [17]","gives rise to","Corporate Action Entitlement","1 : 0..n","Event x safekeeping account x portfolio (CD-195)."),
 ("Corporate Action Entitlement","is answered by","Corporate Action Election","1 : 0..n","Option chosen from the 17 Corporate Action Option."),
 ("Corporate Action Election","may implement","Investment Decision [24]","n : 0..1","Where portfolio managers record the voluntary decision in 24."),
 ("Corporate Action Entitlement","is settled by","Corporate Action Payment","1 : 0..n","Includes reversals; holds income received and tax withheld."),
 ("Corporate Action Payment","is booked as","Portfolio Transaction [18]","1 : 0..1","The change in the 18 Portfolio Holding is booked in 18."),
 ("Income Collection","controls","Corporate Action Entitlement / Corporate Action Payment","1 : 1 / 1 : 0..1","Expected against received; no cash facts of its own."),
 ("Income Collection","is expected by","Income Accrual [27]","1 : 0..n","Matches 27 'Income Accrual is collected by Income Collection [28] n : 0..1'; the reference names the ex-date row."),
 ("Withholding Tax Reclaim","reclaims tax withheld on","Corporate Action Payment","n : 1","The withheld amount is read from the payment."),
 ("Tax Relief Documentation","is filed for","Investment Product [01]","n : 1","Per market and relief method."),
 ("Class Action Claim","claims on","Corporate Action Event (Class Action) [17]","n : 1","Case facts are the event's."),
 ("Class Action Claim","is filed for","Investment Product [01] or Account [15]","n : 1",""),
 ("Securities Lending Program","enrolls","Investment Product [01] / Portfolio [18]","n : 1","01 Securities Lending Permitted Indicator must be Y."),
 ("Securities Lending Program","operates under","Securities Lending Agreement","1 : 1..n","Authorization agreement with the agent and master agreements with borrowers (CD-182)."),
 ("Securities Loan","is made under","Securities Lending Agreement","n : 1",""),
 ("Securities Loan","is made to","Party (Borrower) [02]","n : 1",""),
 ("Securities Loan","is collateralized by","Lending Collateral Received","1 : 0..n","Per collateral item and mark date; pooled collateral is held against the borrower."),
 ("Securities Loan","is reported in","Loan Regulatory Report","1 : 0..n","One per regime."),
 ("Lending Revenue Allocation","is booked by","Fund Journal Entry [27]","n : 0..1","Fund lending income."),
]

# ---------------------------------------------------------------------------
SRC = [
 ("Investment Company Act of 1940 Section 17(f) (custody of fund assets) and SEC Rule 17f-4 (securities depositories)","US Congress; US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.17f-4","Statute / regulation","Bank custody requirement for fund assets and use of US securities depositories","Custody Provider Role, Foreign Custody Assessment Type",["SEC Rule 17f-4", "Investment Company Act Section 17(f)"]),
 ("SEC Rule 17f-5 (custody of investment company assets outside the United States)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.17f-5","Regulation","Eligible foreign custodian, foreign custody manager delegation, reporting to the board","Foreign Custody Assessment, Custody Provider Role",["SEC Rule 17f-5"]),
 ("SEC Rule 17f-7 (custody of investment company assets with a foreign securities depository)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.17f-7","Regulation","Eligible securities depository, analysis of custody risks","Foreign Custody Assessment, Sub-Custodian Network Arrangement",["SEC Rule 17f-7"]),
 ("OCC 12 CFR 9.13 (custody of fiduciary assets by national bank trustees)","US OCC","https://www.ecfr.gov/current/title-12/chapter-I/part-9/section-9.13","Regulation","Trustee bank custody of collective investment fund assets (self-custody)","Provider Legal Entity, Internal Account Provider",["OCC 12 CFR 9.13"]),
 ("ISO 20022 message definitions: seev (corporate action notification, instruction, status, confirmation, reversal), semt (statements of holdings and transactions), camt (cash statements)","ISO; SWIFT","https://www.iso20022.org/iso-20022-message-definitions","Open standard","seev.031/.033/.034/.036/.037, semt.002/.017/.018, camt.053 structures, sub-balance types, bank transaction codes","Custodian Statements, Corporate Action Processing",["ISO 20022"]),
 ("ISO 15022 / SWIFT MT535-MT537, MT564-MT568, MT940 and MT950","ISO; SWIFT","https://www.iso15022.org","Standard (full specifications for SWIFT members)","Legacy statement and corporate action message fields: MT535 field 93a balance qualifiers (AWAS, LOAN...), :23G: function, SEME and CORP references","Custodian Statements, Corporate Action Processing",["ISO 15022", "SWIFT"]),
 ("SMPG corporate action market practice","Securities Market Practice Group","https://www.smpg.info","Public market practice documents","Notification, instruction and confirmation flows, deadlines, market claims, default options","Corporate Action Processing",["SMPG"]),
 ("SEC Rule 10c-1a (reporting of securities loans) and the December 2025 exemptive order deferring compliance","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.10c-1a","Regulation","Loan data elements reported to FINRA (loan identifier, security, amount, rates, collateral type and margin); compliance date 28 September 2028","Securities Loan, Lending Collateral Received, Loan Regulatory Report",["SEC Rule 10c-1a"]),
 ("ISLA Global Master Securities Lending Agreement (GMSLA 2010 and 2018 Security Interest)","International Securities Lending Association","https://www.islaemea.org","Member documentation","Agreement forms, collateral, margin, marking to market and recall terms (market-neutral contract standard used by US agent lenders for non-US borrowers)","Securities Lending Agreement, Securities Loan, Lending Collateral Received",["ISLA GMSLA"]),
 ("SEC Form N-CEN (securities lending items)","US SEC","https://www.sec.gov/files/formn-cen.pdf","Regulatory form","Lending agent, indemnification, collateral reinvestment, fees and revenue split","Lending Revenue Allocation, Securities Lending Agreement",["SEC Form N-CEN"]),
 ("Investment Company Act of 1940 Section 18 (capital structure) and SEC staff positions on fund securities lending","US Congress; US SEC","https://www.law.cornell.edu/uscode/text/15/80a-18","Statute / staff guidance","Basis of the one-third of total assets on-loan limit for registered funds (staff no-action positions; confirm)","Maximum On-Loan Percentage",["Investment Company Act Section 18"]),
 ("Council Directive (EU) 2025/50 (FASTER, faster and safer relief of excess withholding taxes)","European Union","https://taxation-customs.ec.europa.eu/taxation/business-taxation/faster-directive_en","Directive","Relief at source and quick refund procedures of EU source countries for income on EU securities held by the international funds; transposition by end-2028, application from 2030","Tax Relief Method, Tax Relief Documentation",["EU FASTER Directive"]),
 ("OECD TRACE Implementation Package (treaty relief and compliance enhancement)","OECD","https://www.oecd.org/tax","Standard (confirm path)","Authorized intermediary model for relief at source and reclaims","Tax Relief Documentation, Withholding Tax Reclaim",["OECD TRACE", "OECD Model Tax Convention"]),
 ("IRS Form 6166 (certification of US tax residency)","US IRS","https://www.irs.gov/individuals/international-taxpayers/form-6166-certification-of-us-tax-residency","Regulation / forms","Residence certificates filed to claim treaty relief abroad","Tax Relief Documentation",["IRS"]),
 ("Private Securities Litigation Reform Act of 1995 (class actions) and claims administration practice","US Congress; claims administrators","https://www.congress.gov/bill/104th-congress/house-bill/1058","Statute","Class period, plan of allocation, recognized loss, claim filing","Class Action Claim",["PSLRA"]),
 ("FASB ASC 946 (Financial Services - Investment Companies)","FASB","https://asc.fasb.org","Accounting standard (subscription)","Income recognition on ex-date for dividends, which defines the expected income","Income Collection (Expected Income Accrual)",["ASC 946"]),
 ("AICPA SOC 1 (SSAE 18) and IAASB ISAE 3402 service organization control reports","AICPA; IAASB","https://www.aicpa-cima.com/topic/audit-assurance/audit-and-assurance-greater-than-soc-1","Professional standard","Control reports received from custodians","Custodian Service Review",["AICPA SOC 1", "ISAE 3402"]),
 ("ISSA (International Securities Services Association) market practice and custody reports","ISSA","https://www.issanet.org","Industry body","Holding models, segregation and nominee structures by market, asset servicing practice","Custody Holding Model, Market Holding Model, Account Holding Model, Registered Nominee",["ISSA"]),
 ("SEC Rule 6c-11 (exchange-traded funds)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.6c-11","Regulation","In-kind basket deliveries reconciled against custodian receipts","Custody Reconciliation Break (Related AP Order)",["SEC Rule 6c-11"]),
 ("Custodian and depository vendor models (custody portals of the large global custodians; DTCC asset services; class action claims services)","Vendors","https://www.dtcc.com/asset-services","Vendor documentation (structure only)","Statement, notification and claim structures as commonly delivered","Custodian Statements, Corporate Action Processing, Class Action Claim",["Internal"]),
 ("ISO 3166 / ISO 4217 / ISO 6166 / ISO 8601 / ISO 13616","ISO","https://www.iso.org","Standard; code lists widely available","Country, currency, ISIN, date and IBAN formats","Reference formats used throughout",["ISO 3166", "ISO 4217", "ISO 6166", "ISO 13616"]),
]
