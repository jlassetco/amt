"""Data Domain 31 - Investment Risk. Content module for taxonomy_builder.py."""

META = {
 "title": "Investment Risk Data Taxonomy",
 "subtitle": "Business domain 31 - Investment Risk | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "31_Investment_Risk/Investment_Risk_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the independent investment risk function of a US wealth manager that manages its own mutual funds, ETFs and collective investment trusts (PF line) and institutional separate accounts and OCIO mandates (IA line), and whose funds also serve its advice and workplace clients. It defines what the risk function measures about the funds and the fund and institutional portfolios the firm manages (18) and how much they could lose: the risk models, factors, factor returns and instrument factor loadings it uses; the calculation runs that produce ex-ante tracking error, volatility, value at risk (VaR), expected shortfall and beta, with their decomposition and VaR back-tests; portfolio exposures, counterparty exposures (including the measures that 25 counterparty trading limits cap) and fund leverage measurements (Rule 18f-4 derivatives exposure and Investment Company Act Section 18 asset coverage); stress scenarios, their shocks and results, including liquidity and climate scenarios; SEC Rule 22e-4 liquidity classifications, highly liquid investment minimums (HLIM), fund liquidity profiles and horizon buckets; Rule 18f-4 designated reference portfolios and VaR test results; the risk programs each fund is designated under (the Rule 22e-4 liquidity risk management program, the Rule 18f-4 derivatives risk management program, Rule 2a-7 money market fund stress testing); and the limits approved under those programs or by the risk committee (RLMT-), their daily utilization and every exceedance (RLEX-). The risk of a client's own account is not measured here: the client's risk profile is 02 and 45, and discretionary client accounts are managed in 46 (CW-009). It is a separate domain because Rules 22e-4 and 18f-4 require these measures to come from a program administrator and a derivatives risk manager independent of portfolio management, with their own models, limits and escalation to the fund board. Stitched together from SEC Rules 22e-4, 18f-4 and 2a-7, Investment Company Act Section 18, Forms N-PORT, N-RN, N-CEN and PF, the Basel market risk framework (concepts only), NGFS scenarios and the structure of commercial risk platforms (MSCI Barra, Bloomberg PORT, SimCorp Axioma)."),
  ("Scope", "In scope: risk models and their versions; risk factors, factor returns and instrument factor loadings; risk calculation runs; portfolio risk measures (ex-ante tracking error, ex-ante volatility, VaR, expected shortfall, ex-ante beta) and their decomposition; VaR back-tests; portfolio exposures by dimension (gross, net, DV01, CS01, duration, currency); counterparty exposures by measure (net mark-to-market, collateral held, net exposure, potential future exposure, gross notional, settlement, repo, unsettled-trade exposure and trading volume); Rule 18f-4 derivatives exposure and Section 18 asset coverage measurements; stress scenarios (STRESS-), scenario shocks, stress test results and liquidity stress detail; liquidity classifications, highly liquid investment minimums, fund liquidity profiles and liquidity horizon buckets; designated reference portfolios and VaR test results; risk program designations; risk limits (RLMT-), risk limit utilizations and risk limit exceedances (RLEX-), including utilization and exceedances of 25 counterparty trading limits (CD-215). Out of scope (referenced by ID): products, share classes, benchmarks, strategies and the declared leverage calculation method and maximum leverage (01 Investment Product & Service Offering); counterparties, vendors and other parties (the 02 party core, CD-143); legal entities and classification schemes (09 Shared & Enterprise Reference Data); licensed datasets (14 Third-Party Data & Licensing); instruments (17 Instrument & Issuer Reference); fund and institutional portfolios, holdings and the delta-adjusted exposure base (18 Portfolio & Investment Book of Record); employees (20 Human Capital); prices, curves, surfaces, pricing analytics, ETF market statistics and fair value determinations (22 Market Data & Pricing); internal credit assessments (23 Investment Research); optimizer estimates and portfolio construction constraints (24 Portfolio Management & Construction); counterparty approvals and trading limits (25 Portfolio Trading & Execution); trading agreements, collateral and initial margin (26 Trade Operations, Settlement & Collateral); NAVs (27 Fund Accounting & Valuation); feeder fund access terms (01 Feeder Access Terms); ex-post risk statistics and returns (32 Performance & Attribution); coded investment restrictions and breaches (33 Investment Compliance); climate and ESG metrics (34 Stewardship & Sustainable Investing); board approvals of 31 records, officer appointments, board reports and regulatory filings (35 Fund Governance & Regulatory Reporting); the model inventory (37 Enterprise & Operational Risk, Model Inventory Entry); client risk profiles (02, 45) and client managed accounts (46)."),
  ("Structure", "Four levels: Data Domain > Data Family > Data Business Object > Data Business Attribute."),
  ("Core model", "A Risk Model (firm-defined code x version, vendor 02 party and 14 dataset, Model Inventory Reference to the 37 Model Inventory Entry) defines Risk Factors, whose daily Risk Factor Returns it estimates, and loads each 17 instrument on each factor as an Instrument Factor Loading (specific risk on the factor 'Specific'). A Risk Calculation Run (model version x as-of date x run scope) records the 18 holdings date and the market data cut-off it used and produces Portfolio Risk Measures (portfolio x risk measure x horizon x confidence level x 01 benchmark), their Risk Decomposition and model-based Portfolio Exposures; VaR Back-Tests compare a one-day VaR measure with actual or hypothetical P&L. Counterparty Exposures (counterparty x date x counterparty exposure measure x portfolio, trading entity or firm scope x 26 netting agreement) supply every value a 25 Counterparty Trading Limit caps. Two keys are kept apart: Rule 22e-4, Rule 18f-4 and Rule 2a-7 program results are keyed by the fund (01 PRD-), measured on the fund's whole book in 18; measures, exposures, stress results and back-tests are keyed by the 18 portfolio (PORT-). Leverage & Exposure Measurements (fund x date x exposure method) read 27 net assets. Stress Scenarios (STRESS-, versioned) carry Stress Scenario Shocks on risk factors, 22 curves or 01 indices; Stress Test Results (with Liquidity Stress Detail) apply them to portfolios and may read 34 climate metrics. Liquidity Classifications (fund x instrument x date x portion) roll up to Fund Liquidity Profiles and Liquidity Horizon Buckets; each fund has an effective-dated Highly Liquid Investment Minimum. Designated Reference Portfolios (01 benchmark or 18 portfolio) feed VaR Test Results, which reference the Risk Limit holding the statutory threshold. Risk Program Designations say which program governs each fund. Risk Limits (RLMT-) are measured daily per limit and portfolio as Risk Limit Utilizations, which also measure 25 Counterparty Trading Limits; every exceedance of either is a Risk Limit Exceedance (RLEX-). Board approvals of 31 records are linked once, from 35 Resolution Subject Link (CD-237)."),
  ("Design principles", "1) Measured, not observed: per-instrument published values (prices, yields, vendor duration, option delta, curve points, fair values) are 22 and are read, never stored here; model outputs and portfolio aggregates are 31 (CD-211). 2) Ex-ante here, ex-post in 32: forecasts are 31, statistics from realized returns are 32 Ex-Post Risk Statistic; ambiguous names say 'Ex-Ante' or 'Ex-Post'. 3) Declaration vs measurement: 01 declares the leverage calculation method (the Rule 18f-4 VaR test) and the maximum leverage; 31 measures. 4) One limit, one owner (CD-223): risk-program and risk-committee limits are 31 Risk Limits; coded investment restrictions, including prospectus leverage and counterparty concentration limits, are 33 Compliance Rules; counterparty trading limits are 25; portfolio manager constraints and budgets are 24. An exceedance is recorded where its limit lives (RLEX- here, BREACH- in 33), except that 31 also records exceedances of 25 counterparty trading limits (CD-215). 'Breach' is never used here. 5) Thresholds only on Risk Limit, utilization only on Risk Limit Utilization, the HLIM only on Highly Liquid Investment Minimum. 6) Program results here, filings, board reports and board approvals in 35: 31 holds no filing status, filing date, board minute or approval link. 7) Fund keys for program results, portfolio keys for measures; 18 portfolios are fund and institutional portfolios only, never a retail client account (CW-009). 8) Keep dimensions apart: risk measure, VaR method and confidence level; scenario type and source; liquidity category and classification basis; exceedance workflow (Case Status) and resolution are separate lists. 9) Every measure, classification, limit, scenario and designation carries a date or an effective period; horizon and confidence level are part of the measure key, so 1-day and 20-day VaR coexist."),
  ("Applies To", "Shows the record each attribute belongs to: Risk Model, Risk Factor, Risk Factor Return, Factor Loading, Calculation Run, Risk Measure, Risk Decomposition, VaR Back-Test, Portfolio Exposure, Counterparty Exposure, Leverage Measurement, Stress Scenario, Scenario Shock, Stress Result, Liquidity Classification, HLIM, Liquidity Profile, Horizon Bucket, Reference Portfolio, VaR Test, Program Designation, Risk Limit, Limit Utilization or Limit Exceedance."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify what was measured, when and how (portfolio and fund keys, run, risk measure, horizon, confidence level, measure value, exposure method and value, counterparty exposure measure and amount), to evidence a regulatory program result (liquidity category and portion, HLIM, illiquid and highly liquid percentages, shortfall days, VaR test value and pass, consecutive days out of compliance, stress impact), or to control and escalate a limit (limit threshold, limit type, utilization, exceedance dates and severity, RLMT-, RLEX- and STRESS- identifiers). Confirm with the head of investment risk, the liquidity program administrator, the derivatives risk manager and fund compliance."),
  ("Primary / Secondary Reference", "Standard, rule or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Vendor references (MSCI Barra, Bloomberg PORT, SimCorp Axioma) indicate common platform structure, not a license to reproduce vendor field dictionaries. Basel market risk standards are cited for VaR, expected shortfall and back-testing concepts only; the firm is not a bank. Next step: map each attribute to the risk platform, the liquidity vendor feed and the Form N-PORT data sources."),
  ("Notes", "PII = personal data under US privacy law (Regulation S-P, the Gramm-Leach-Bliley Act and state privacy laws). Employee references (model owners, program leads, approvers, exceedance owners, and grain keys that embed an employee) are personal data of internal staff. Risk measures of a portfolio that implements an institutional separate account held by an individual or a personal trust are personal data and inherit the 15 account restrictions. Risk results of registered funds before public filing may be material nonpublic information. Key formats: RLMT-<sequence, 6 digits> (RLMT-000418); RLEX-<year>-<sequence, 5 digits> (RLEX-2026-00073); STRESS-<sequence, 4 digits> with the version as a separate attribute (STRESS-0042). Risk models are keyed by a firm-defined name without a hyphenated stem plus a version ('Global Equity Long-Term 2024' / 3); factors, runs, measures, classifications and tests are keyed by their grain, and references to them write the grain key with ' / ' between parts."),
  ("Tabs", "Hierarchy, Taxonomy, Code Lists, Relationships, Sources."),
  ("Suggested next steps", "1) Validate families, risk measures, exposure methods, scenario types and CDEs with the head of investment risk, the liquidity program administrator and the derivatives risk manager. 2) Confirm the risk platforms and vendors and which values are stored rather than recomputed (SME question 1). 3) Agree with 33 the split of limits (CD-223) and that 33 rules name, not copy, 31 measures. 4) Agree with 25 that each Counterparty Trading Limit type is measured by a 31 Counterparty Exposure measure, and that utilization and exceedances are recorded here (CD-215, SME question 9). 5) Agree with 35 the hand-offs by object name (CD-225) and that board approvals of 31 records are linked from 35 only (CD-237). 6) Agree with 24 the re-typing of Rebalance Run 'Risk Model Used' to Reference (Risk Model, 31) (CD-211). 7) Agree with 46 whether the managed account programs need a 31 measure (for example model portfolio risk) or keep risk in 46 (CW-009). 8) Done at the Stage 3 consolidation (CD-241): 31 cites the enterprise shared lists directly. 9) Done at the Stage 4 consolidation (CD-246): Risk Model references the 37 Model Inventory Entry."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

SMA = ("PII where the portfolio implements an institutional separate account held by an individual or a personal trust; the measure "
       "then inherits the 15 account restrictions.")
FUND_RULE = ("Program results are keyed by the fund (01 PRD-) and measured on the fund's whole book: every 18 portfolio linked to "
             "the product by an active 18 Portfolio Implementation Link, sleeves included.")
RUN_KEY = "Global Equity Long-Term 2024 / 3 / 2026-10-05 / US Registered Funds"
MEASURE_KEY = RUN_KEY + " / PORT-000412 / Ex-Ante Tracking Error / 252 / (none) / BMK-0001"

# ---------------------------------------------------------------------------
D("Risk Models & Factors", "RK-MOD",
  "The models the risk function uses to forecast risk: each model version, its factors, the daily factor returns and volatilities, and the loading of each instrument on each factor. Validation, tiering and the model inventory are 37 Model Risk Management. 22 instrument factors (pool and inflation factors) and fair value factors are different concepts.",
  [
   ("Risk Models", "The risk function's use of a model, by version.", [
     ("Risk Model", [
       ("Risk Model Code", "Firm-defined name of the risk model, written without a hyphenated stem.", "Risk Model", "Identifier", "", "Global Equity Long-Term 2024", "Internal", "MSCI Barra", "Y"),
       ("Risk Model Version", "Version of the model; a new version is created when the factor structure, estimation universe or parameters change.", "Risk Model", "Integer", "", "3", "Internal", "", "Y"),
       ("Risk Model Type", "Kind of model by how it produces risk.", "Risk Model", "Code", "Risk Model Type", "Fundamental Factor Model", "Internal", "MSCI Barra", ""),
       ("Model Forecast Horizon", "Horizon the vendor or the firm calibrated the model's forecasts for.", "Risk Model", "Code", "External (vendor model horizon convention)", "Long Horizon", "MSCI Barra", "SimCorp Axioma", ""),
       ("Model Vendor", "Vendor that supplies the model; blank for a model built in house.", "Risk Model", "Reference (Party)", "", "PTY-100512", "Internal", "", "", "02 Party Role Type 'Risk Model Vendor' (added at the Stage 3 consolidation, CD-143)."),
       ("Vendor Model Dataset", "Licensed dataset in which the vendor delivers factor returns, covariances and exposures.", "Risk Model", "Reference (Dataset)", "", "DSET-00518", "Internal", "", ""),
       ("Model Inventory Reference", "Entry and version of the model in the 37 model inventory.", "Risk Model", "Reference (Model Inventory Entry, 37)", "", "MODEL-0412 / 3", "SR 26-2", "SR 11-7 (historical)", "", "Re-typed from text at the Stage 4 consolidation (CD-216, CD-246); Risk Model Version equals Model Inventory Entry.Model Version."),
       ("Risk Model Owner", "Employee in the risk function accountable for the model's use.", "Risk Model", "Reference (Employee)", "", "EMP-30412", "Internal", "", "", "PII"),
       ("Risk Model Status", "Whether the model version is in use.", "Risk Model", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
       ("Model Effective From", "Date the version was first used for official measures; the model's factors are dated by it.", "Risk Model", "Date", "ISO 8601", "2024-07-01", "Internal", "", ""),
       ("Model Effective To", "Date the version stopped being used for official measures.", "Risk Model", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Risk Factors", "Factors of a model version, with their daily returns and volatilities.", [
     ("Risk Factor", [
       ("Factor Risk Model", "Model version the factor belongs to; the factor is dated by the version's effective period.", "Risk Factor", "Reference (Risk Model, 31)", "", "Global Equity Long-Term 2024 / 3", "Internal", "", ""),
       ("Risk Factor Code", "Code of the factor within the model version; specific risk is held on the factor 'Specific'.", "Risk Factor", "Identifier", "", "Momentum", "MSCI Barra", "", "Y"),
       ("Risk Factor Type", "Kind of factor (style, industry, country, rate, spread, sustainability and so on).", "Risk Factor", "Code", "Risk Factor Type", "Style", "MSCI Barra", "SimCorp Axioma", ""),
       ("Mapped Curve", "22 curve whose movements the factor represents, for interest rate, credit spread and inflation factors.", "Risk Factor", "Reference (Curve Definition, 22)", "", "CURVE-USD-UST", "Internal", "", "", "The curve points are 22 values and are not stored here."),
       ("Factor Classification Scheme", "Classification scheme version whose node the factor represents, for industry and country factors.", "Risk Factor", "Reference (Classification Scheme)", "", "ICS-GICS-2023", "Internal", "", ""),
       ("Factor Classification Code", "Node of the classification scheme the factor represents.", "Risk Factor", "Code", "External (code of the referenced classification scheme)", "4510", "GICS", "", ""),
     ]),
     ("Risk Factor Return", [
       ("Return Risk Factor", "Factor whose return is recorded.", "Risk Factor Return", "Reference (Risk Factor, 31)", "", "Global Equity Long-Term 2024 / 3 / Momentum", "Internal", "", ""),
       ("Factor Return Date", "Business date the return applies to.", "Risk Factor Return", "Date", "ISO 8601", "2026-10-05", "Internal", "", ""),
       ("Factor Return", "One-day return of the factor for the business date, as estimated by the model.", "Risk Factor Return", "Percentage", "", "0.18%", "MSCI Barra", "", ""),
       ("Factor Volatility Forecast", "Annualized forecast volatility of the factor on the date.", "Risk Factor Return", "Percentage", "", "4.20%", "MSCI Barra", "", ""),
       ("Covariance Matrix Dataset", "Dataset that holds the model's factor covariance matrix for the date; covariances are read from it, not stored row by row here.", "Risk Factor Return", "Reference (Dataset)", "", "DSET-00518", "Internal", "", ""),
       ("Factor Return Data Basis", "Whether the return was estimated by the model or interpolated for a missing date.", "Risk Factor Return", "Code", "Shared: Data Basis", "Modeled", "Internal", "", ""),
     ]),
   ]),
   ("Instrument Factor Loadings", "Loading of each instrument on each factor of a model version on a date.", [
     ("Instrument Factor Loading", [
       ("Loading Risk Model", "Model version the loading comes from.", "Factor Loading", "Reference (Risk Model, 31)", "", "Global Equity Long-Term 2024 / 3", "Internal", "", ""),
       ("Loaded Instrument", "Instrument loaded on the factor.", "Factor Loading", "Reference (Instrument, 17)", "", "INS-00104477", "Internal", "", ""),
       ("Loading Risk Factor", "Factor the instrument is loaded on.", "Factor Loading", "Reference (Risk Factor, 31)", "", "Global Equity Long-Term 2024 / 3 / Momentum", "Internal", "", ""),
       ("Factor Loading Date", "Business date of the loading.", "Factor Loading", "Date", "ISO 8601", "2026-10-05", "Internal", "", ""),
       ("Factor Loading", "Sensitivity of the instrument to the factor in the factor's unit (standardized score, beta, duration or currency weight); on the factor 'Specific' it is the annualized specific risk.", "Factor Loading", "Decimal", "", "1.12", "MSCI Barra", "SimCorp Axioma", "Y", "A model output, not the 22 vendor duration or option delta of the instrument (CD-211)."),
       ("Proxy Instrument", "Instrument whose loadings were used because the model does not cover the loaded instrument.", "Factor Loading", "Reference (Instrument, 17)", "", "", "Internal", "", ""),
       ("Factor Loading Data Basis", "Whether the loading was delivered by the model or estimated by the firm through a proxy.", "Factor Loading", "Code", "Shared: Data Basis", "Modeled", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Risk Measurement", "RK-MEA",
  "Calculation runs and the ex-ante risk measures they produce for each portfolio, their decomposition by risk dimension, and the back-tests of VaR against realized profit and loss.",
  [
   ("Risk Calculation Runs", "Each execution of a model over a set of portfolios on a date.", [
     ("Risk Calculation Run", [
       ("Run Risk Model", "Model version used by the run.", "Calculation Run", "Reference (Risk Model, 31)", "", "Global Equity Long-Term 2024 / 3", "Internal", "", "Y"),
       ("Run As-Of Date", "Business date the run measures.", "Calculation Run", "Date", "ISO 8601", "2026-10-05", "Internal", "", "Y"),
       ("Run Scope", "Firm-defined set of portfolios the run covers.", "Calculation Run", "Code", "Firm-defined", "US Registered Funds", "Internal", "", ""),
       ("Holdings As-Of Date", "Date of the 18 holdings the run measured.", "Calculation Run", "Date", "ISO 8601", "2026-10-05", "Internal", "", "", "Read from 18 Portfolio Holding (Holding Date); holdings are not stored here."),
       ("Holding View Used", "18 holding view the run read (start of day, intraday or end of day).", "Calculation Run", "Code", "Shared: Holding View", "End of Day", "Internal", "", ""),
       ("Market Data Cut-Off Timestamp", "Latest 22 market data the run used.", "Calculation Run", "Timestamp", "ISO 8601", "2026-10-05T18:00:00-04:00", "Internal", "", "", "Positions without a readily available market quotation (private markets, Level 3) are valued at the 22 Approved Price set from a 22 Fair Value Determination; the determination is referenced from Liquidity Classification, not copied."),
       ("Risk Run Status", "Processing state of the run.", "Calculation Run", "Code", "Risk Run Status", "Completed", "Internal", "", ""),
       ("Run Approval Status", "Whether the risk function has signed off the run's results for official use.", "Calculation Run", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
     ]),
   ]),
   ("Portfolio Risk Measures", "Ex-ante measures of each portfolio, by measure, horizon, confidence level and benchmark.", [
     ("Portfolio Risk Measure", [
       ("Measure Calculation Run", "Run that produced the measure.", "Risk Measure", "Reference (Risk Calculation Run, 31)", "", RUN_KEY, "Internal", "", "Y"),
       ("Measured Portfolio", "Portfolio measured; for a fund's program tests, the 18 portfolio that holds the fund's whole book.", "Risk Measure", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "Y", SMA),
       ("Risk Measure", "Measure computed.", "Risk Measure", "Code", "Risk Measure", "Value at Risk", "Basel MAR", "", "Y"),
       ("Risk Horizon Days", "Holding period of the measure in business days; annualized measures (tracking error, volatility) are recorded with 252.", "Risk Measure", "Integer", "Days", "20", "SEC Rule 18f-4", "", "Y"),
       ("Confidence Level", "Confidence level of a VaR or expected shortfall measure; blank for volatility, tracking error and beta.", "Risk Measure", "Code", "Confidence Level", "99%", "SEC Rule 18f-4", "Basel MAR", "Y"),
       ("Measure Benchmark", "01 benchmark a relative measure is computed against; blank for an absolute measure.", "Risk Measure", "Reference (Benchmark)", "", "BMK-0001", "Internal", "", "Y", "Part of the grain: an active and an absolute measure of the same kind coexist."),
       ("VaR Method", "Method used for a VaR or expected shortfall measure.", "Risk Measure", "Code", "VaR Method", "Historical Simulation", "Basel MAR", "SEC Rule 18f-4", ""),
       ("Lookback Period Days", "Number of business days of history the measure was estimated from.", "Risk Measure", "Integer", "Days", "756", "SEC Rule 18f-4", "", "", "Rule 18f-4 requires at least three years of history."),
       ("Risk Measure Value", "Value of the measure in the unit given: VaR and expected shortfall as a loss in percent of net assets, tracking error and volatility as an annualized percentage, beta as a ratio.", "Risk Measure", "Decimal", "", "4.87", "Internal", "", "Y"),
       ("Risk Measure Unit", "Unit of the measure value.", "Risk Measure", "Code", "Shared: Measure Unit", "Percent", "Internal", "", ""),
       ("Risk Measure Amount", "Value of a VaR or expected shortfall measure in the portfolio's base currency.", "Risk Measure", "Amount", "", "USD 12,180,000", "Internal", "", ""),
     ]),
   ]),
   ("Risk Decomposition", "Contribution of each risk dimension and bucket to a portfolio measure.", [
     ("Risk Decomposition", [
       ("Decomposed Measure", "Portfolio risk measure decomposed; its key carries the run, portfolio, measure, horizon, confidence level and benchmark.", "Risk Decomposition", "Reference (Portfolio Risk Measure, 31)", "", MEASURE_KEY, "Internal", "", "Y", SMA),
       ("Risk Dimension", "Dimension along which the measure is split.", "Risk Decomposition", "Code", "Risk Dimension", "Sector", "Bloomberg PORT", "", ""),
       ("Risk Bucket", "Value of the dimension the row is for: a factor code, a classification node, a country, a currency, a rating or maturity band, or an instrument key.", "Risk Decomposition", "Code", "Firm-defined (value of the risk dimension)", "Information Technology", "Internal", "", ""),
       ("Contribution to Risk", "Part of the measure attributable to the bucket, in the measure's unit.", "Risk Decomposition", "Decimal", "", "1.12", "Bloomberg PORT", "MSCI Barra", ""),
       ("Marginal Contribution to Risk", "Change in the measure for a small increase in the bucket's weight.", "Risk Decomposition", "Decimal", "", "0.041", "MSCI Barra", "", ""),
     ]),
   ]),
   ("VaR Back-Testing", "Comparison of one-day VaR with realized profit and loss, as Rule 18f-4 requires.", [
     ("VaR Back-Test", [
       ("Back-Tested Portfolio", "Portfolio back-tested.", "VaR Back-Test", "Reference (Portfolio, 18)", "", "PORT-000412", "SEC Rule 18f-4", "", "Y", SMA),
       ("Back-Test Risk Model", "Model version whose VaR is tested.", "VaR Back-Test", "Reference (Risk Model, 31)", "", "Global Equity Long-Term 2024 / 3", "Internal", "", ""),
       ("Back-Test Date", "Business date whose profit and loss is compared with the prior day's VaR.", "VaR Back-Test", "Date", "ISO 8601", "2026-10-05", "SEC Rule 18f-4", "", "Y"),
       ("Back-Test P&L Basis", "Whether the profit and loss is actual or hypothetical (end-of-day holdings revalued); part of the grain, as both are commonly tested on the same day.", "VaR Back-Test", "Code", "Back-Test P&L Basis", "Hypothetical", "Basel MAR", "SEC Rule 18f-4", "Y"),
       ("Back-Tested VaR Measure", "One-day VaR measure the realized profit and loss is compared with.", "VaR Back-Test", "Reference (Portfolio Risk Measure, 31)", "", "Global Equity Long-Term 2024 / 3 / 2026-10-02 / US Registered Funds / PORT-000412 / Value at Risk / 1 / 99% / (none)", "SEC Rule 18f-4", "", ""),
       ("Realized Daily P&L", "Profit or loss of the portfolio for the back-test date in base currency.", "VaR Back-Test", "Amount", "", "USD -2,140,000", "SEC Rule 18f-4", "", "", "Row rule: on Actual rows of funds with a 27 NAV it is a Derived copy (27) of the day's change in Fund Net Assets Amount excluding capital activity; on other Actual rows a Derived copy (18) of the day's change in Portfolio Valuation Summary Total IBOR Market Value excluding Portfolio Capital Activity; on Hypothetical rows it is computed here from 18 holdings and 22 approved prices."),
       ("Back-Test Exception Indicator", "Whether the loss exceeded the VaR measure.", "VaR Back-Test", "Boolean", "", "N", "SEC Rule 18f-4", "Basel MAR", "Y"),
       ("Exceptions in Window", "Number of exceptions in the back-test window ending on the date.", "VaR Back-Test", "Integer", "", "3", "Basel MAR", "SEC Rule 18f-4", ""),
       ("Back-Test Window Days", "Number of business days in the window.", "VaR Back-Test", "Integer", "Days", "250", "Basel MAR", "SEC Rule 18f-4", ""),
       ("Back-Test Zone", "Traffic-light zone the exception count falls in.", "VaR Back-Test", "Code", "External (Basel MAR99 traffic light: Green, Yellow, Red)", "Green", "Basel MAR", "", "", "Concept only; the firm is not subject to Basel capital rules."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Exposures", "RK-EXP",
  "Exposures of portfolios by dimension, exposure to each counterparty by measure (including every measure a 25 counterparty trading limit caps), and fund leverage measured against net assets as Rule 18f-4 derivatives exposure and Section 18 asset coverage.",
  [
   ("Portfolio Exposures", "Gross, net, rate and spread exposure of a portfolio by dimension and bucket.", [
     ("Portfolio Exposure", [
       ("Exposure Portfolio", "Portfolio measured.", "Portfolio Exposure", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "Y", SMA),
       ("Exposure As-Of Date", "Business date of the exposure.", "Portfolio Exposure", "Date", "ISO 8601", "2026-10-05", "Internal", "", "Y"),
       ("Exposure Calculation Run", "Run that produced a model-based exposure (beta-adjusted, DV01, CS01); blank where no model is used. Part of the grain.", "Portfolio Exposure", "Reference (Risk Calculation Run, 31)", "", RUN_KEY, "Internal", "", ""),
       ("Exposure Dimension", "Dimension the exposure is aggregated by.", "Portfolio Exposure", "Code", "Risk Dimension", "Currency", "Internal", "", ""),
       ("Exposure Bucket", "Value of the dimension the row is for.", "Portfolio Exposure", "Code", "Firm-defined (value of the risk dimension)", "EUR", "Internal", "", ""),
       ("Exposure Measure", "Exposure measure computed.", "Portfolio Exposure", "Code", "Exposure Measure", "Net Exposure", "Internal", "SEC Form N-PORT", "Y", "Delta-adjusted exposure of options is aggregated from 18 Derivative Holding Detail 'Delta-Adjusted Exposure Base', which stays mastered in 18 (CD-211)."),
       ("Exposure Value", "Value of the exposure measure in the unit given.", "Portfolio Exposure", "Decimal", "", "18450000", "Internal", "", "Y"),
       ("Exposure Value Unit", "Unit of the exposure value.", "Portfolio Exposure", "Code", "Shared: Measure Unit", "Currency Amount", "Internal", "", ""),
       ("Exposure Percent of Net Assets", "Exposure value as a percentage of portfolio net assets, where the measure is an amount.", "Portfolio Exposure", "Percentage", "", "7.40%", "Internal", "", ""),
       ("Exposure Benchmark", "01 benchmark an active exposure is measured against; blank for an absolute exposure.", "Portfolio Exposure", "Reference (Benchmark)", "", "", "Internal", "", ""),
     ]),
   ]),
   ("Counterparty Exposure", "Exposure to a counterparty by measure and scope, supplying every value a 25 counterparty trading limit caps (CD-215).", [
     ("Counterparty Exposure", [
       ("Exposure Counterparty", "Counterparty the exposure is to.", "Counterparty Exposure", "Reference (Party)", "", "PTY-100221", "ISDA", "", "Y"),
       ("Counterparty Exposure Date", "Business date of the exposure.", "Counterparty Exposure", "Date", "ISO 8601", "2026-10-05", "Internal", "", "Y"),
       ("Counterparty Exposure Measure", "Measure the row holds; the 25 limit-type measures carry the same names as 25 Limit Type values.", "Counterparty Exposure", "Code", "Counterparty Exposure Measure", "OTC Derivative Gross Notional", "Internal", "", "Y"),
       ("Counterparty Exposure Portfolio", "Portfolio exposed; blank for a row measured at trading entity or firm level.", "Counterparty Exposure", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "Y", SMA),
       ("Exposure Trading Entity", "Internal legal entity whose trading the row aggregates, for limits set per trading entity; blank for portfolio rows and firm-wide rows.", "Counterparty Exposure", "Reference (Legal Entity)", "", "", "Internal", "", ""),
       ("Netting Set Agreement", "26 trading agreement that defines the netting set, for netted measures; blank otherwise.", "Counterparty Exposure", "Reference (Trading Agreement, 26)", "", "TAGR-00118", "ISDA", "", "", "ISDA, CSA and clearing terms stay in 26."),
       ("Counterparty Exposure Method", "Method used, for mark-to-market and potential future exposure measures.", "Counterparty Exposure", "Code", "Counterparty Exposure Method", "Current Exposure Method", "Internal", "ISDA", ""),
       ("Counterparty Exposure Amount", "Value of the measure in base currency.", "Counterparty Exposure", "Amount", "", "USD 212,000,000", "Internal", "", "Y", "Row rule: on 'Collateral Held' rows a Derived copy (26): sum of 26 Collateral Balance 'Collateral Value' on Received rows of the agreement, portfolio and date with Balance Margin Type Variation Margin, Cleared Variation Margin or Repo Collateral (regulatory initial margin held in segregation is excluded); every other measure is computed here from 18 holdings, 25 executions and 26 settlement and OTC records."),
       ("Counterparty Exposure Percent of Net Assets", "Exposure amount as a percentage of the portfolio's net assets, for portfolio rows.", "Counterparty Exposure", "Percentage", "", "1.00%", "Internal", "", "", "33 Compliance Rules on counterparty concentration (fund policy and institutional guideline limits) read the Net Exposure After Collateral rows (CD-215)."),
       ("Applicable Trading Limit", "25 counterparty trading limit whose limit type this measure supplies.", "Counterparty Exposure", "Reference (Counterparty Trading Limit, 25)", "", "PTY-100221 / OTC Derivative Gross Notional / LEN-0004 / PRD-00231 / 2026-01-01", "Internal", "", "", "Utilization is held on Risk Limit Utilization, not here."),
       ("Counterparty Credit View", "23 internal credit assessment of the counterparty in force on the date.", "Counterparty Exposure", "Reference (Internal Credit Assessment, 23)", "", "PTY-100221 / EMP-30311 / Firm Credit Scale / 2026-01-30", "Internal", "", "", "PII (internal staff): the key embeds the analyst's employee ID."),
     ]),
   ]),
   ("Leverage & Derivatives Exposure", "Leverage of a fund measured against its net assets: Rule 18f-4 derivatives exposure and Investment Company Act Section 18 asset coverage of senior securities.", [
     ("Leverage & Exposure Measurement", [
       ("Measured Fund", "Fund measured.", "Leverage Measurement", "Reference (Investment Product)", "", "PRD-00981", "Internal", "", "Y", FUND_RULE),
       ("Leverage Measurement Date", "Business date of the measurement.", "Leverage Measurement", "Date", "ISO 8601", "2026-10-05", "Internal", "", "Y"),
       ("Exposure Method", "Regulatory method used.", "Leverage Measurement", "Code", "Exposure Method", "Rule 18f-4 Derivatives Exposure", "SEC Rule 18f-4", "Investment Company Act Section 18", "Y", "This attribute names the exposure measure; the VaR test the fund declares is 01 Leverage Calculation Method (read, not copied)."),
       ("Measured Exposure Amount", "Exposure computed under the method in base currency.", "Leverage Measurement", "Amount", "", "USD 61,400,000", "SEC Rule 18f-4", "", "Y"),
       ("Net Assets Used", "Net assets the exposure is divided by.", "Leverage Measurement", "Amount", "", "USD 250,310,552.28", "Internal", "", "", "Derived copy (27) of Fund Net Assets Amount of the NAV calculation in Net Assets Source NAV."),
       ("Net Assets Source NAV", "27 fund NAV calculation the net assets were taken from.", "Leverage Measurement", "Reference (Fund NAV Calculation, 27)", "", "PRD-00981 / US GAAP / 2026-10-05 / Administrator / 1", "Internal", "", ""),
       ("Leverage Percent of Net Assets", "Measured exposure as a percentage of net assets.", "Leverage Measurement", "Percentage", "", "24.53%", "SEC Rule 18f-4", "", "Y", "33 Compliance Rules on prospectus derivatives exposure limits read the Rule 18f-4 Derivatives Exposure rows, and borrowing and senior securities limits (01 Maximum Borrowing, Section 18(f)) read the Section 18 Asset Coverage rows (CD-214); the Rule 18f-4 10% limited derivatives user test is a 31 Risk Limit on the former."),
       ("Excluded Hedging Exposure Amount", "Currency and interest rate hedges excluded when testing the Rule 18f-4 limited derivatives user threshold.", "Leverage Measurement", "Amount", "", "USD 12,000,000", "SEC Rule 18f-4", "", ""),
       ("Measurement Calculation Run", "Run that produced the measurement, where a model run was used.", "Leverage Measurement", "Reference (Risk Calculation Run, 31)", "", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Stress Testing", "RK-STT",
  "Stress scenarios and their shocks, and the results of applying them to portfolios, including redemption (liquidity) and climate scenarios.",
  [
   ("Stress Scenarios", "Scenarios by version, with the shocks each applies.", [
     ("Stress Scenario", [
       ("Stress Scenario ID", "Unique identifier of the stress scenario.", "Stress Scenario", "Identifier", "", "STRESS-0042", "Internal", "", "Y", "Format STRESS-<sequence, 4 digits>; the version is a separate attribute."),
       ("Stress Scenario Version", "Version of the scenario; a change of shocks creates a new version.", "Stress Scenario", "Integer", "", "2", "Internal", "", "Y"),
       ("Stress Scenario Name", "Business name of the scenario.", "Stress Scenario", "Text", "", "Global Financial Crisis 2008 replay", "Internal", "", ""),
       ("Stress Scenario Type", "Kind of scenario by how it is constructed.", "Stress Scenario", "Code", "Stress Scenario Type", "Historical Replay", "SEC Rule 18f-4", "SEC Rule 22e-4", ""),
       ("Stress Scenario Source", "Who defined the scenario.", "Stress Scenario", "Code", "Stress Scenario Source", "Internal Risk Committee", "Internal", "", ""),
       ("Stress Test Frequency", "How often the scenario is run against the portfolios in scope (at least weekly for Rule 18f-4 programs).", "Stress Scenario", "Code", "Shared: Frequency", "Weekly", "SEC Rule 18f-4", "", ""),
       ("Historical Window Start Date", "First date of the historical period replayed, for historical scenarios.", "Stress Scenario", "Date", "ISO 8601", "2008-09-12", "Internal", "", ""),
       ("Historical Window End Date", "Last date of the historical period replayed.", "Stress Scenario", "Date", "ISO 8601", "2008-10-10", "Internal", "", ""),
       ("Climate Scenario Pathway", "Published climate pathway a climate scenario is calibrated to.", "Stress Scenario", "Code", "External (NGFS scenario name and phase)", "NGFS Net Zero 2050", "NGFS", "", "", "Climate metrics used as inputs are read from 34 (CD-216)."),
       ("Scenario Approval Status", "Approval state of the scenario version.", "Stress Scenario", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("Scenario Status", "Whether the scenario version is in use.", "Stress Scenario", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
       ("Scenario Effective From", "Date the version was first used.", "Stress Scenario", "Date", "ISO 8601", "2025-04-01", "Internal", "", ""),
       ("Scenario Effective To", "Date the version was last used.", "Stress Scenario", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Stress Scenario Shock", [
       ("Shock Scenario", "Scenario version the shock belongs to.", "Scenario Shock", "Reference (Stress Scenario, 31)", "", "STRESS-0042 / 2", "Internal", "", ""),
       ("Shocked Risk Factor", "Model factor shocked, where the shock is expressed on a factor (commodity and other market variables are shocked through their factors).", "Scenario Shock", "Reference (Risk Factor, 31)", "", "Global Equity Long-Term 2024 / 3 / Market", "Internal", "", ""),
       ("Shocked Curve", "22 curve shocked, where the shock is expressed on a curve.", "Scenario Shock", "Reference (Curve Definition, 22)", "", "", "Internal", "", ""),
       ("Shocked Index", "01 benchmark (index) whose level is shocked, where the shock is expressed on an index.", "Scenario Shock", "Reference (Benchmark)", "", "", "Internal", "", ""),
       ("Shock Tenor", "Tenor of a curve shock; blank for a parallel shift.", "Scenario Shock", "Code", "Shared: Rate Tenor", "", "Internal", "", ""),
       ("Shock Size", "Size of the shock in the shock unit.", "Scenario Shock", "Decimal", "", "-35", "Internal", "", "Y"),
       ("Shock Unit", "Unit in which the shock size is expressed.", "Scenario Shock", "Code", "Shared: Measure Unit", "Percent", "Internal", "", ""),
     ]),
   ]),
   ("Stress Test Results", "Effect of a scenario version on a portfolio on a date.", [
     ("Stress Test Result", [
       ("Result Scenario", "Scenario version applied.", "Stress Result", "Reference (Stress Scenario, 31)", "", "STRESS-0042 / 2", "Internal", "", "Y"),
       ("Stressed Portfolio", "Portfolio stressed; for a fund's program stress tests, the 18 portfolio that holds the fund's whole book.", "Stress Result", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "Y", SMA),
       ("Stress Test Date", "Business date of the 18 Portfolio Holdings stressed.", "Stress Result", "Date", "ISO 8601", "2026-10-02", "SEC Rule 18f-4", "", "Y"),
       ("Stress Test Program", "Program the test was run for.", "Stress Result", "Code", "Risk Program Type", "Derivatives Risk Management Program (Rule 18f-4)", "SEC Rule 18f-4", "SEC Rule 2a-7", ""),
       ("Stress Calculation Run", "Run that produced the result.", "Stress Result", "Reference (Risk Calculation Run, 31)", "", "Global Equity Long-Term 2024 / 3 / 2026-10-02 / US Registered Funds", "Internal", "", ""),
       ("Stress P&L Impact", "Change in portfolio value under the scenario in base currency.", "Stress Result", "Amount", "", "USD -61,250,000", "Internal", "", ""),
       ("Stress Impact Percent of Net Assets", "Stress P&L impact as a percentage of net assets.", "Stress Result", "Percentage", "", "-24.5%", "Internal", "", "Y"),
       ("Climate Metric Input", "34 portfolio sustainability metric (a climate indicator such as WACI or carbon footprint) used to scale a climate scenario's shocks to the portfolio.", "Stress Result", "Reference (Portfolio Sustainability Metric, 34)", "", "PORT-000412 / 2026-09-30 / WACI / Scope 1+2 / Point in Time", "NGFS", "", "", "Read by reference, never copied (CD-216). Key in the 34 format: scope / period end / indicator code / emission scopes / measurement basis. 34 merged its Portfolio Climate Metric into Portfolio Sustainability Metric; 34 records the link as 'is read by Stress Test Result'."),
     ]),
     ("Liquidity Stress Detail", [
       ("Redemption Shock Percent", "Redemptions assumed by the scenario as a percentage of net assets.", "Stress Result", "Percentage", "", "20%", "SEC Rule 22e-4", "", "", "Investor dealing terms are 01; investor holdings are 06 and 29; neither is copied here."),
       ("Stressed Liquidity Horizon Days", "Number of days over which redemptions and asset sales are assumed.", "Stress Result", "Integer", "Days", "7", "SEC Rule 22e-4", "", ""),
       ("Liquid Assets Available", "Assets that could be sold within the horizon under stressed market conditions.", "Stress Result", "Amount", "", "USD 52,000,000", "SEC Rule 22e-4", "", ""),
       ("Liquidity Coverage Ratio", "Liquid assets available divided by stressed redemptions.", "Stress Result", "Decimal", "", "1.04", "SEC Rule 22e-4", "", "Y"),
       ("Days to Meet Redemptions", "Days needed to raise cash for the stressed redemptions without significantly changing portfolio composition.", "Stress Result", "Integer", "Days", "6", "SEC Rule 22e-4", "", ""),
       ("Model Inventory Entry", "The 37 Model Inventory Entry registered for the model this record uses.", "Stress Result", "Reference (Model Inventory Entry, 37)", "", "MODEL-0456 / 1", "SR 26-2", "SEC Rule 22e-4", "", "Added 2026-10-14 (CD-246, GAP-37-001): the liquidity stress model the scenario was run on."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Liquidity Risk", "RK-LQD",
  "SEC Rule 22e-4 liquidity classification of each investment of a fund, the highly liquid investment minimum of each fund, and fund-level liquidity profiles and horizon buckets used for program reporting, Form N-PORT and, for the feeder funds (private funds), Form PF (CD-213, CW-166). Every object is keyed by the fund; 35 files them.",
  [
   ("Liquidity Classification", "Classification of each investment of a fund into a Rule 22e-4 liquidity category, in portions where split.", [
     ("Liquidity Classification", [
       ("Classified Fund", "Fund holding the investment.", "Liquidity Classification", "Reference (Investment Product)", "", "PRD-00981", "SEC Rule 22e-4", "SEC Form N-PORT", "Y", FUND_RULE),
       ("Classified Instrument", "Investment classified.", "Liquidity Classification", "Reference (Instrument, 17)", "", "INS-00104477", "SEC Rule 22e-4", "SEC Form N-PORT", "Y"),
       ("Classification Date", "Date as of which the classification was made.", "Liquidity Classification", "Date", "ISO 8601", "2026-09-30", "SEC Rule 22e-4", "", "Y"),
       ("Classification Portion Number", "Sequence of the portion when a position is split across categories; 1 when not split.", "Liquidity Classification", "Integer", "", "1", "SEC Form N-PORT", "", "Y"),
       ("Liquidity Category", "Rule 22e-4 category of the portion.", "Liquidity Classification", "Code", "Liquidity Category", "Highly Liquid", "SEC Rule 22e-4", "SEC Form N-PORT", "Y"),
       ("Portion Percent of Position", "Share of the fund's position classified in the category.", "Liquidity Classification", "Percentage", "", "100%", "SEC Form N-PORT", "", "Y"),
       ("Days to Cash", "Business days in which the portion could be converted to cash (or sold or disposed of) without significantly changing its market value, under the classification's trade size.", "Liquidity Classification", "Integer", "Days", "2", "SEC Rule 22e-4", "", "", "Business days throughout; the calendar-day tests of the moderately liquid, less liquid and illiquid categories are applied when the category is set."),
       ("Reasonably Anticipated Trade Size", "Trade size assumed when classifying, in base currency.", "Liquidity Classification", "Amount", "", "USD 4,500,000", "SEC Rule 22e-4", "", "", "SME question 3."),
       ("Liquidity Classification Basis", "Level at which the classification was made.", "Liquidity Classification", "Code", "Liquidity Classification Basis", "Asset Class", "SEC Rule 22e-4", "", ""),
       ("Classification Data Basis", "Whether the classification rests on vendor model output or the firm's own estimate.", "Liquidity Classification", "Code", "Shared: Data Basis", "Modeled", "Internal", "", ""),
       ("Liquidity Data Source Dataset", "Liquidity vendor dataset the classification inputs came from.", "Liquidity Classification", "Reference (Dataset)", "", "DSET-00620", "Internal", "", ""),
       ("Supporting Fair Value Determination", "22 fair value determination of a position without a readily available market quotation (private markets, Level 3), read as evidence for its classification.", "Liquidity Classification", "Reference (Fair Value Determination, 22)", "", "FVD-2026-001187", "SEC Rule 22e-4", "SEC Rule 2a-5", ""),
       ("Classification Override Reason", "Reason the program administrator overrode the model or asset class category; blank when not overridden.", "Liquidity Classification", "Text", "", "", "SEC Rule 22e-4", "", ""),
       ("Model Inventory Entry", "The 37 Model Inventory Entry registered for the model this record uses.", "Liquidity Classification", "Reference (Model Inventory Entry, 37)", "", "MODEL-0455 / 2", "SR 26-2", "SEC Rule 22e-4", "", "Added 2026-10-14 (CD-246, GAP-37-001): the liquidity classification model (vendor or in house) the category was taken from; blank when the classification was not modeled."),
     ]),
   ]),
   ("Highly Liquid Investment Minimum", "Minimum share of net assets a fund keeps in highly liquid investments.", [
     ("Highly Liquid Investment Minimum", [
       ("HLIM Fund", "Fund the minimum applies to.", "HLIM", "Reference (Investment Product)", "", "PRD-00981", "SEC Rule 22e-4", "", "Y"),
       ("HLIM Percent", "Minimum percentage of net assets in highly liquid investments; blank when the fund primarily holds highly liquid investments.", "HLIM", "Percentage", "", "15%", "SEC Rule 22e-4", "", "Y"),
       ("Primarily Highly Liquid Indicator", "Whether the fund primarily holds highly liquid investments and so needs no minimum.", "HLIM", "Boolean", "", "N", "SEC Rule 22e-4", "", ""),
       ("HLIM Effective From", "Date the minimum took effect.", "HLIM", "Date", "ISO 8601", "2026-01-01", "SEC Rule 22e-4", "", ""),
       ("HLIM Effective To", "Date the minimum was replaced.", "HLIM", "Date", "ISO 8601", "", "SEC Rule 22e-4", "", ""),
       ("HLIM Approval Status", "Approval state of the minimum within the program.", "HLIM", "Code", "Shared: Approval Status", "Approved", "Internal", "", "", "Board approval of a change made during a shortfall is linked from 35 Resolution Subject Link (CD-237); 31 holds no link."),
       ("HLIM Last Review Date", "Date the minimum was last reviewed by the program administrator.", "HLIM", "Date", "ISO 8601", "2026-06-30", "SEC Rule 22e-4", "", ""),
     ]),
   ]),
   ("Fund Liquidity Profiles", "Fund-level results of the liquidity program on each measurement date.", [
     ("Fund Liquidity Profile", [
       ("Profile Fund", "Fund whose liquidity is profiled.", "Liquidity Profile", "Reference (Investment Product)", "", "PRD-00981", "SEC Rule 22e-4", "", "Y", FUND_RULE),
       ("Profile Measurement Date", "Date as of which the profile is computed.", "Liquidity Profile", "Date", "ISO 8601", "2026-09-30", "SEC Rule 22e-4", "", "Y"),
       ("Profile Net Assets", "Net assets the percentages are computed on.", "Liquidity Profile", "Amount", "", "USD 250,310,552.28", "SEC Rule 22e-4", "", "", "Derived copy (27) of Fund Net Assets Amount of the fund's final NAV calculation for the date."),
       ("Highly Liquid Percent", "Share of net assets classified highly liquid, after the margin adjustment.", "Liquidity Profile", "Percentage", "", "71.2%", "SEC Rule 22e-4", "SEC Form N-PORT", "Y"),
       ("Highly Liquid Margin Adjustment", "Highly liquid assets posted as margin or collateral for derivatives that are not highly liquid, deducted for the HLIM test.", "Liquidity Profile", "Amount", "", "USD 1,200,000", "SEC Rule 22e-4", "", ""),
       ("Moderately Liquid Percent", "Share of net assets classified moderately liquid.", "Liquidity Profile", "Percentage", "", "18.4%", "SEC Rule 22e-4", "", ""),
       ("Less Liquid Percent", "Share of net assets classified less liquid.", "Liquidity Profile", "Percentage", "", "6.9%", "SEC Rule 22e-4", "", ""),
       ("Illiquid Percent", "Share of net assets classified illiquid.", "Liquidity Profile", "Percentage", "", "3.5%", "SEC Rule 22e-4", "SEC Form N-RN", "Y", "Tested against the 15% illiquid limit held as a Risk Limit; an excess is a Risk Limit Exceedance."),
       ("Applied HLIM", "Highly liquid investment minimum in force on the date.", "Liquidity Profile", "Reference (Highly Liquid Investment Minimum, 31)", "", "PRD-00981 / 2026-01-01", "SEC Rule 22e-4", "", ""),
       ("HLIM Shortfall Indicator", "Whether highly liquid investments were below the minimum on the date.", "Liquidity Profile", "Boolean", "", "N", "SEC Rule 22e-4", "SEC Form N-RN", ""),
       ("Consecutive HLIM Shortfall Days", "Consecutive calendar days the fund has been below its minimum, counted to the date.", "Liquidity Profile", "Integer", "Days", "0", "SEC Rule 22e-4", "SEC Form N-RN", "Y", "More than 7 days triggers board reporting and Form N-RN; the filing is 35."),
       ("Own ETF Market Statistic", "22 market statistics of the fund's own ETF shares for the date, read as a liquidity input.", "Liquidity Profile", "Reference (ETF Market Statistic, 22)", "", "INS-00950012 / 2026-09-30", "SEC Rule 22e-4", "SEC Rule 6c-11", "", "ETF rows only (CD-206)."),
     ]),
     ("Liquidity Horizon Bucket", [
       ("Bucket Fund", "Fund whose liquidity is bucketed.", "Horizon Bucket", "Reference (Investment Product)", "", "PRD-00512", "SEC Form PF", "", "Y", FUND_RULE),
       ("Bucket Measurement Date", "Date as of which the buckets are computed.", "Horizon Bucket", "Date", "ISO 8601", "2026-09-30", "SEC Form PF", "", "Y"),
       ("Liquidity Horizon Bucket", "Period within which the share is liquidatable or redeemable.", "Horizon Bucket", "Code", "Liquidity Horizon Bucket", "2-7 Days", "SEC Form PF", "", "Y"),
       ("Portfolio Percent Liquidatable", "Share of the portfolio that could be liquidated within the bucket.", "Horizon Bucket", "Percentage", "", "22%", "SEC Form PF", "", "Y"),
       ("Investor Liquidity Percent", "Share of investor equity that could be redeemed within the bucket under the fund's terms.", "Horizon Bucket", "Percentage", "", "0%", "SEC Form PF", "", "", "Computed from 01 dealing terms (or 01 Feeder Access Terms for feeder funds) and 29 or 49 investor holdings; the terms are not copied. Form PF buckets for the feeder funds (CW-166)."),
       ("Bucket Feeder Access Terms", "01 feeder access terms (tender, redemption and lock-up terms) that drive investor liquidity, for feeder funds.", "Horizon Bucket", "Reference (Feeder Access Terms, 01)", "", "PRD-00512", "SEC Form PF", "", ""),
       ("Bucket Data Basis", "Whether the percentages rest on vendor, modeled or estimated liquidity data.", "Horizon Bucket", "Code", "Shared: Data Basis", "Estimated", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Derivatives Risk", "RK-DER",
  "The designated reference portfolio of each fund and the daily VaR tests under Rule 18f-4 (CD-214). Both are keyed by the fund.",
  [
   ("Designated Reference Portfolios", "Index or securities portfolio a fund's relative VaR test is measured against.", [
     ("Designated Reference Portfolio", [
       ("DRP Fund", "Fund the reference portfolio is designated for.", "Reference Portfolio", "Reference (Investment Product)", "", "PRD-00981", "SEC Rule 18f-4", "", "Y"),
       ("Applicable VaR Test Regime", "Relative VaR test the designation serves.", "Reference Portfolio", "Code", "VaR Test Regime", "Rule 18f-4 Relative VaR", "SEC Rule 18f-4", "", ""),
       ("Designated Reference Index", "01 benchmark designated as the reference portfolio; blank when the fund's securities portfolio is designated.", "Reference Portfolio", "Reference (Benchmark)", "", "BMK-0001", "SEC Rule 18f-4", "", "Y", "Verify against the rule text: Rule 18f-4 defines a designated index as an unleveraged index approved by the derivatives risk manager that reflects the markets or asset classes in which the fund invests, and that is not administered by an affiliate unless widely recognized and used."),
       ("Reference Securities Portfolio", "18 portfolio of the fund's securities and other investments, excluding derivatives, designated as the reference portfolio.", "Reference Portfolio", "Reference (Portfolio, 18)", "", "", "SEC Rule 18f-4", "", ""),
       ("DRP Effective From", "Date the designation took effect.", "Reference Portfolio", "Date", "ISO 8601", "2025-08-19", "SEC Rule 18f-4", "", ""),
       ("DRP Effective To", "Date the designation was replaced.", "Reference Portfolio", "Date", "ISO 8601", "", "SEC Rule 18f-4", "", ""),
       ("DRP Approval Status", "Approval state of the designation by the derivatives risk manager.", "Reference Portfolio", "Code", "Shared: Approval Status", "Approved", "Internal", "", "", "Board reporting of the designation is a 35 Board Report Received (CD-237)."),
     ]),
   ]),
   ("VaR Test Results", "Daily outcome of each VaR test a fund is subject to.", [
     ("VaR Test Result", [
       ("VaR Test Fund", "Fund tested.", "VaR Test", "Reference (Investment Product)", "", "PRD-00981", "SEC Rule 18f-4", "", "Y", FUND_RULE),
       ("VaR Test Date", "Business date of the test.", "VaR Test", "Date", "ISO 8601", "2026-10-05", "SEC Rule 18f-4", "", "Y"),
       ("VaR Test Regime", "Regulatory VaR test applied.", "VaR Test", "Code", "VaR Test Regime", "Rule 18f-4 Relative VaR", "SEC Rule 18f-4", "", "Y"),
       ("Fund VaR Measure", "Portfolio risk measure giving the fund's VaR (99%, 20 trading days under Rule 18f-4), measured on the 18 portfolio that holds the fund's whole book.", "VaR Test", "Reference (Portfolio Risk Measure, 31)", "", RUN_KEY + " / PORT-000412 / Value at Risk / 20 / 99% / (none)", "SEC Rule 18f-4", "", ""),
       ("Applied Reference Portfolio", "Designated reference portfolio used, for relative tests.", "VaR Test", "Reference (Designated Reference Portfolio, 31)", "", "PRD-00981 / 2025-08-19", "SEC Rule 18f-4", "", ""),
       ("Reference Portfolio VaR", "VaR of the designated reference portfolio as a percentage of its value, computed on the same basis as the fund's VaR.", "VaR Test", "Percentage", "", "6.10%", "SEC Rule 18f-4", "", ""),
       ("VaR Test Value", "Value tested: fund VaR divided by reference portfolio VaR for a relative test, or fund VaR as a percentage of net assets for an absolute test.", "VaR Test", "Percentage", "", "131%", "SEC Rule 18f-4", "", "Y"),
       ("Applied VaR Limit", "Risk limit holding the statutory threshold tested against (200% or 250% relative; 20% or 25% absolute).", "VaR Test", "Reference (Risk Limit, 31)", "", "RLMT-000418", "SEC Rule 18f-4", "", "", "The threshold is held only on the Risk Limit."),
       ("VaR Test Pass Indicator", "Whether the test value was within the limit.", "VaR Test", "Boolean", "", "Y", "SEC Rule 18f-4", "", "Y"),
       ("Consecutive Business Days Out of Compliance", "Business days in a row the fund has failed the test, counted to the date.", "VaR Test", "Integer", "Days", "0", "SEC Rule 18f-4", "SEC Form N-RN", "Y", "More than 5 business days triggers board reporting and Form N-RN; the filing is 35."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Risk Programs & Limits", "RK-LIM",
  "Which risk program governs each fund, the limits approved under a program or by the risk committee (RLMT-), their daily utilization, and every exceedance (RLEX-), including utilization and exceedances of 25 counterparty trading limits (CD-215, CD-223). Excludes portfolio manager constraints and budgets (24 Portfolio Construction Constraint), coded investment restrictions (33) and the counterparty trading limits themselves (25).",
  [
   ("Risk Program Designations", "Effective-dated designation of each fund under each risk program.", [
     ("Risk Program Designation", [
       ("Program Fund", "Fund designated under the program.", "Program Designation", "Reference (Investment Product)", "", "PRD-00981", "SEC Rule 22e-4", "SEC Rule 18f-4", "Y"),
       ("Risk Program Type", "Program the fund is designated under.", "Program Designation", "Code", "Risk Program Type", "Liquidity Risk Management Program (Rule 22e-4)", "SEC Rule 22e-4", "SEC Rule 18f-4", "Y"),
       ("Program Regulator", "Authority whose rule establishes the program.", "Program Designation", "Code", "Shared: Regulator", "SEC", "Internal", "", ""),
       ("Program Effective From", "Date the designation took effect.", "Program Designation", "Date", "ISO 8601", "2018-12-01", "Internal", "", ""),
       ("Program Effective To", "Date the designation ended.", "Program Designation", "Date", "ISO 8601", "", "Internal", "", ""),
       ("In-Kind ETF Exemption Indicator", "Whether the fund is an In-Kind ETF exempt from liquidity classification and the HLIM.", "Program Designation", "Boolean", "", "N", "SEC Rule 22e-4", "", ""),
       ("Administrator Appointment", "35 officer appointment that names the program administrator or derivatives risk manager approved by the board.", "Program Designation", "Reference (Fund Officer Appointment, 35)", "", "PRD-00981 / Liquidity Risk Program Administrator (Rule 22e-4) / EMP-30412 / 2024-01-01", "SEC Rule 22e-4", "SEC Rule 18f-4", "", "PII (internal staff): the key embeds the employee ID. The appointment and its board approval are mastered in 35."),
       ("Program Risk Lead", "Employee leading the program day to day where no board-approved appointment exists (Rule 2a-7 stress testing, limited derivatives user policies, the firm risk appetite framework).", "Program Designation", "Reference (Employee)", "", "EMP-30412", "Internal", "", "", "PII"),
     ]),
   ]),
   ("Risk Limits", "Limits approved under a risk program or by the risk committee, on a 31 measure.", [
     ("Risk Limit", [
       ("Risk Limit ID", "Unique identifier of the risk limit.", "Risk Limit", "Identifier", "", "RLMT-000418", "Internal", "", "Y", "Format RLMT-<sequence, 6 digits>."),
       ("Risk Limit Name", "Business name of the limit.", "Risk Limit", "Text", "", "Rule 18f-4 relative VaR test - open-end funds", "Internal", "", ""),
       ("Limit Risk Program", "Program the limit is approved under.", "Risk Limit", "Code", "Risk Program Type", "Derivatives Risk Management Program (Rule 18f-4)", "Internal", "", ""),
       ("Limited Program Test Measure", "Program test measure the limit caps (VaR test values, illiquid percent, derivatives exposure percent, stress loss); blank when the limit caps a risk or exposure measure.", "Risk Limit", "Code", "Risk Limit Measure", "Relative VaR Ratio", "Internal", "", "Y", "Exactly one of Limited Program Test Measure, Limited Risk Measure and Limited Exposure Measure is set."),
       ("Limited Risk Measure", "Portfolio risk measure the limit caps, for risk appetite limits.", "Risk Limit", "Code", "Risk Measure", "", "Internal", "", ""),
       ("Limited Exposure Measure", "Portfolio exposure measure the limit caps, for risk appetite limits.", "Risk Limit", "Code", "Exposure Measure", "", "Internal", "", ""),
       ("Limit Horizon Days", "Horizon of the limited measure, for VaR and expected shortfall limits.", "Risk Limit", "Integer", "Days", "20", "Internal", "", ""),
       ("Limit Confidence Level", "Confidence level of the limited measure, for VaR and expected shortfall limits.", "Risk Limit", "Code", "Confidence Level", "99%", "Internal", "", ""),
       ("Limit Benchmark", "01 benchmark of a relative measure the limit caps (tracking error, active exposure).", "Risk Limit", "Reference (Benchmark)", "", "", "Internal", "", ""),
       ("Limit Stress Scenario", "Stress scenario whose loss the limit caps, for Stress Loss limits.", "Risk Limit", "Reference (Stress Scenario, 31)", "", "", "Internal", "", ""),
       ("Limit Exposure Dimension", "Dimension of an exposure limit set on one bucket (a currency, sector or country).", "Risk Limit", "Code", "Risk Dimension", "", "Internal", "", ""),
       ("Limit Exposure Bucket", "Bucket of the dimension the exposure limit applies to.", "Risk Limit", "Code", "Firm-defined (value of the risk dimension)", "", "Internal", "", ""),
       ("Limited Fund", "Fund the limit applies to.", "Risk Limit", "Reference (Investment Product)", "", "", "Internal", "", "", "Scope rule: exactly one of Limited Fund, Limited Portfolio, Limited Strategy and Limit Business Lines is set, or none for a firm-wide limit; a strategy, business line or firm-wide limit is measured separately for each portfolio in scope."),
       ("Limited Portfolio", "Portfolio the limit applies to.", "Risk Limit", "Reference (Portfolio, 18)", "", "", "Internal", "", "", SMA),
       ("Limited Strategy", "01 strategy whose portfolios the limit applies to.", "Risk Limit", "Reference (Strategy)", "", "", "Internal", "", ""),
       ("Limit Business Lines", "Business lines whose funds and portfolios the limit applies to, for limits set across a line (CW-004).", "Risk Limit", "Code (multi)", "Shared: Business Line", "PF; IA", "Internal", "", ""),
       ("Limit Threshold", "Value the measure must not exceed.", "Risk Limit", "Decimal", "", "200", "SEC Rule 18f-4", "", "Y"),
       ("Warning Threshold", "Value at which an early warning is raised before the limit is reached.", "Risk Limit", "Decimal", "", "180", "Internal", "", ""),
       ("Limit Threshold Unit", "Unit in which both thresholds are expressed.", "Risk Limit", "Code", "Shared: Measure Unit", "Percent", "Internal", "", ""),
       ("Risk Limit Type", "Whether the limit is hard, soft or monitoring only.", "Risk Limit", "Code", "Risk Limit Type", "Hard", "Internal", "", "Y"),
       ("Limit Setting Entity", "Internal legal entity that set the limit where it is not the adviser, such as the trustee bank of a CIT.", "Risk Limit", "Reference (Legal Entity)", "", "", "Internal", "", ""),
       ("Limit Approved By", "Employee or committee chair who approved the limit.", "Risk Limit", "Reference (Employee)", "", "EMP-30188", "Internal", "", "", "PII. SME question 4."),
       ("Risk Limit Status", "Whether the limit is in use.", "Risk Limit", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
       ("Limit Effective From", "Date the limit took effect.", "Risk Limit", "Date", "ISO 8601", "2022-08-19", "Internal", "", ""),
       ("Limit Effective To", "Date the limit stopped applying.", "Risk Limit", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Limit Monitoring", "Daily measurement of each limit per portfolio and the exceedances found.", [
     ("Risk Limit Utilization", [
       ("Utilized Risk Limit", "31 risk limit measured; blank for a 25 counterparty trading limit.", "Limit Utilization", "Reference (Risk Limit, 31)", "", "RLMT-000418", "Internal", "", ""),
       ("Utilized Counterparty Trading Limit", "25 counterparty trading limit measured; blank for a 31 risk limit.", "Limit Utilization", "Reference (Counterparty Trading Limit, 25)", "", "", "Internal", "", "", "CD-215."),
       ("Utilization Date", "Business date of the measurement.", "Limit Utilization", "Date", "ISO 8601", "2026-10-05", "Internal", "", "Y"),
       ("Utilized Portfolio", "Portfolio measured, when the limit covers several portfolios; blank for fund-level, entity-level and firm-level measurements. Part of the grain.", "Limit Utilization", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "Y", SMA),
       ("Utilization Measured Value", "Value of the limited measure on the date, kept as measured so a later restatement does not change the utilization reported.", "Limit Utilization", "Decimal", "", "131", "Internal", "", "", "Row rule: on 25 limit rows it is the Counterparty Exposure Amount of the 31 Counterparty Exposure row whose measure equals the 25 Limit Type, for the limit's counterparty, trading entity and fund, summed over portfolios where the limit is entity-wide."),
       ("Source Measure Record", "31 record the measured value was taken from.", "Limit Utilization", "Text", "", "VaR Test Result: PRD-00981 / 2026-10-05 / Rule 18f-4 Relative VaR", "Internal", "", "", "Format '<31 object name>: <grain key>' (proposals_31 GRAIN_KEY_FORMATS)."),
       ("Utilization Percent", "Measured value as a percentage of the limit threshold.", "Limit Utilization", "Percentage", "", "65.5%", "Internal", "", "Y"),
       ("Utilization RAG Status", "Red, amber or green status against the warning and limit thresholds.", "Limit Utilization", "Code", "Shared: RAG Status", "Green", "Internal", "", ""),
     ]),
     ("Risk Limit Exceedance", [
       ("Risk Limit Exceedance ID", "Unique identifier of the exceedance.", "Limit Exceedance", "Identifier", "", "RLEX-2026-00073", "Internal", "", "Y", "Format RLEX-<year>-<sequence, 5 digits>. Never called a breach; breaches of 33 rules are 33 BREACH-."),
       ("Exceeded Risk Limit", "31 risk limit exceeded; blank for a 25 counterparty trading limit.", "Limit Exceedance", "Reference (Risk Limit, 31)", "", "RLMT-000502", "Internal", "", ""),
       ("Exceeded Counterparty Trading Limit", "25 counterparty trading limit exceeded; blank for a 31 risk limit.", "Limit Exceedance", "Reference (Counterparty Trading Limit, 25)", "", "", "Internal", "", "", "CD-215; SME question 9."),
       ("Exceedance Portfolio", "Portfolio whose measure exceeded the limit, when the limit covers several portfolios.", "Limit Exceedance", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "", SMA),
       ("Triggering Utilization", "First utilization row over the limit, which leads to the program result behind it through its Source Measure Record.", "Limit Exceedance", "Reference (Risk Limit Utilization, 31)", "", "RLMT-000502 / 2026-09-22 / PORT-000412", "Internal", "", ""),
       ("Exceedance Start Date", "First business date the measure exceeded the limit.", "Limit Exceedance", "Date", "ISO 8601", "2026-09-22", "SEC Rule 22e-4", "SEC Rule 18f-4", "Y"),
       ("Exceedance End Date", "Business date the measure was back within the limit.", "Limit Exceedance", "Date", "ISO 8601", "2026-09-25", "Internal", "", "Y"),
       ("Exceedance Severity", "Severity assigned to the exceedance.", "Limit Exceedance", "Code", "Shared: Severity", "High", "Internal", "", "Y"),
       ("Exceedance Cause", "What caused the exceedance (market movement, redemptions, trading, model or data change).", "Limit Exceedance", "Text", "", "Large redemption reduced highly liquid assets; illiquid share rose to 15.6%", "Internal", "", ""),
       ("Exceedance Workflow Status", "Where the exceedance stands in its handling workflow.", "Limit Exceedance", "Code", "Shared: Case Status", "Closed", "Internal", "", ""),
       ("Escalated To", "Body or role the exceedance was escalated to.", "Limit Exceedance", "Code", "Firm-defined (escalation body)", "Fund Board", "Internal", "", "", "Board escalation is evidenced in 35 (Board Report Received, Reportable Fund Event)."),
       ("Board Reporting Required Indicator", "Whether the program requires the exceedance to be reported to the fund board.", "Limit Exceedance", "Boolean", "", "Y", "SEC Rule 22e-4", "SEC Rule 18f-4", ""),
       ("Form N-RN Trigger Indicator", "Whether the exceedance triggers a Form N-RN report; the filing itself is 35.", "Limit Exceedance", "Boolean", "", "Y", "SEC Form N-RN", "", "Y", "35 Reportable Fund Event references RLEX- (CD-225)."),
       ("Exceedance Resolution", "How the exceedance was resolved.", "Limit Exceedance", "Code", "Exceedance Resolution", "Position Reduced", "Internal", "", ""),
       ("Exceedance Owner", "Employee responsible for resolving the exceedance.", "Limit Exceedance", "Reference (Employee)", "", "EMP-30412", "Internal", "", "", "PII"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 # ---- enterprise shared lists are cited as 'Shared: <name>' (registered direct user since the Stage 3 consolidation, CD-241)
 # ---- local lists
 "Risk Model Type": ("Internal (structure of commercial risk platforms)", [("Fundamental Factor Model","Factors from observable characteristics (style, industry, country), e.g. MSCI Barra, Axioma fundamental models"),("Statistical Factor Model","Factors extracted from return history"),("Macroeconomic Factor Model","Factors are macroeconomic series"),("Full Revaluation Simulation Model","Positions repriced under historical or simulated scenarios"),("Liquidity Risk Model","Days to liquidate and liquidity cost by position"),("Counterparty Exposure Model","Simulated future exposure of netting sets")]),
 "Risk Factor Type": ("Internal / MSCI Barra / SimCorp Axioma", [("Market","Broad market factor"),("Style","e.g. value, momentum, size, volatility"),("Industry",""),("Country",""),("Currency",""),("Interest Rate","Mapped to a 22 curve"),("Credit Spread","Mapped to a 22 curve"),("Volatility","Implied volatility level"),("Commodity",""),("Inflation",""),("Sustainability","Climate transition or other sustainability factor (CD-216)"),("Specific","Idiosyncratic risk not explained by common factors")]),
 "Risk Run Status": ("Internal", [("Scheduled",""),("Running",""),("Completed",""),("Completed with Warnings","Results produced with data gaps or proxies"),("Failed","No usable results"),("Superseded","Replaced by a rerun for the same model version, date and scope")]),
 "Risk Measure": ("Internal / Basel MAR (concepts)", [("Ex-Ante Tracking Error","Forecast standard deviation of active return against a benchmark"),("Ex-Ante Volatility","Forecast standard deviation of total return"),("Value at Risk","Loss not exceeded at the confidence level over the horizon"),("Expected Shortfall","Average loss beyond the VaR at the confidence level"),("Ex-Ante Beta","Forecast sensitivity of portfolio return to benchmark return")]),
 "VaR Method": ("Basel MAR (concepts) / SEC Rule 18f-4", [("Historical Simulation","Revaluation under observed historical changes"),("Filtered Historical Simulation","Historical changes rescaled to current volatility"),("Parametric (Variance-Covariance)","Analytical from factor covariances"),("Monte Carlo Simulation","Revaluation under simulated scenarios")]),
 "Confidence Level": ("SEC Rule 18f-4 / Basel MAR", [("95%",""),("97.5%","Basel expected shortfall convention"),("99%","Rule 18f-4 VaR tests"),("99.5%","")]),
 "Risk Dimension": ("Internal / Bloomberg PORT", [("Risk Factor","One model factor"),("Factor Group","Style, industry, country, currency or specific"),("Asset Class",""),("Sector","Node of a classification scheme"),("Country",""),("Region",""),("Currency",""),("Issuer",""),("Credit Rating Band",""),("Maturity Band",""),("Instrument","One instrument")]),
 "Back-Test P&L Basis": ("Basel MAR99 (concepts) / SEC Rule 18f-4", [("Actual","Realized change in value including intraday trading and fees"),("Hypothetical","End-of-day holdings revalued at the next day's prices")]),
 "Exposure Measure": ("Internal / SEC Form N-PORT", [("Gross Exposure","Sum of absolute long and short exposures"),("Net Exposure","Long less short exposure"),("Long Exposure",""),("Short Exposure",""),("Beta-Adjusted Net Exposure",""),("DV01","Value change for a 1 bp fall in rates"),("CS01","Value change for a 1 bp widening of credit spreads"),("Duration Contribution","Contribution to portfolio effective duration"),("Spread Duration Contribution","")]),
 "Counterparty Exposure Method": ("Basel CRE52 (concepts) / Internal", [("Current Exposure Method","Replacement cost plus notional add-on"),("SA-CCR","Standardized approach for counterparty credit risk (concept only)"),("Internal PFE Simulation","Simulated potential future exposure at the firm's confidence level")]),
 "Counterparty Exposure Measure": ("Internal / 25 Limit Type (CD-215)", [("Net Mark-to-Market Exposure","Positive replacement value of the netting set before collateral"),("Collateral Held","Collateral received under the netting agreement (Derived copy 26)"),("Net Exposure After Collateral","Net mark-to-market exposure less collateral held, floored at zero"),("Potential Future Exposure","Peak exposure over the remaining life at the firm's confidence level (SME question 5)"),("OTC Derivative Gross Notional","25 Limit Type"),("FX Settlement Exposure","25 Limit Type: daily settlement risk"),("Repo Exposure","25 Limit Type"),("Unsettled Trade Exposure","25 Limit Type"),("Daily Trading Volume","25 Limit Type")]),
 "Exposure Method": ("SEC Rule 18f-4 / Investment Company Act Section 18", [("Rule 18f-4 Derivatives Exposure","Sum of gross notional amounts of derivatives (options delta-adjusted, interest rate derivatives as 10-year bond equivalents) plus short sale and elected financing exposure"),("Section 18 Asset Coverage","Asset coverage of senior securities under Investment Company Act Section 18(f)(1) (at least 300% for bank borrowings of an open-end fund), including reverse repurchase agreements and similar financing a fund does not elect to treat as derivatives transactions under Rule 18f-4(d)")]),
 "Stress Scenario Type": ("SEC Rules 18f-4, 22e-4 and 2a-7 / NGFS / Internal", [("Historical Replay","Market moves of a past period applied to current holdings"),("Hypothetical Market Shock","Designed shocks to factors, curves or variables"),("Sensitivity","Single factor or variable shocked"),("Reverse Stress","Scenario solved for a given loss or liquidity outcome"),("Liquidity (Redemption)","Redemption and market liquidity shocks (Rule 22e-4 reasonably foreseeable stressed conditions)"),("Climate Transition","Policy and technology transition pathway"),("Climate Physical","Physical hazard pathway")]),
 "Stress Scenario Source": ("Internal", [("Internal Risk Committee",""),("Risk Model Vendor","Vendor scenario library"),("Regulator Prescribed","e.g. Rule 2a-7(g)(8) events"),("NGFS","Network for Greening the Financial System scenarios"),("Client Requested","Institutional advisory client (IA line)")]),
 "Liquidity Category": ("SEC Rule 22e-4(a)", [("Highly Liquid","Reasonably expected to be convertible to cash in current market conditions in three business days or less without significantly changing its market value"),("Moderately Liquid","Convertible to cash in more than three calendar days but in seven calendar days or less without significantly changing its market value"),("Less Liquid","Able to be sold or disposed of in seven calendar days or less without significantly changing its market value, but settlement is expected to take more than seven calendar days"),("Illiquid","Cannot be sold or disposed of in seven calendar days or less without the sale significantly changing its market value")]),
 "Liquidity Classification Basis": ("SEC Rule 22e-4", [("Asset Class","Classified by asset class"),("Asset Class with Position Exception","Asset class default overridden for a position whose market, trading or investment-specific considerations differ"),("Position Level","Each position assessed on its own")]),
 "Liquidity Horizon Bucket": ("SEC Form PF", [("1 Day or Less",""),("2-7 Days",""),("8-30 Days",""),("31-90 Days",""),("91-180 Days",""),("181-365 Days",""),("More than 365 Days","")]),
 "VaR Test Regime": ("SEC Rule 18f-4 (01 Leverage Method 'Relative VaR Test' and 'Absolute VaR Test')", [("Rule 18f-4 Relative VaR","Fund VaR not above 200% of designated reference portfolio VaR (250% for closed-end funds with preferred stock outstanding)"),("Rule 18f-4 Absolute VaR","Fund VaR not above 20% of net assets (25% for closed-end funds with preferred stock outstanding)")]),
 "Risk Program Type": ("SEC Rules 22e-4, 18f-4, 2a-7 / Internal", [("Liquidity Risk Management Program (Rule 22e-4)",""),("Derivatives Risk Management Program (Rule 18f-4)",""),("Limited Derivatives User Policies (Rule 18f-4)","Fund relies on the limited derivatives user exception (exposure 10% of net assets or less)"),("Money Market Fund Stress Testing (Rule 2a-7)",""),("Firm Risk Appetite Framework","Risk committee limits not required by a rule")]),
 "Risk Limit Measure": ("Internal (program test measures only; risk appetite limits on a risk or exposure measure use the Risk Measure and Exposure Measure lists)", [("Relative VaR Ratio","Fund VaR divided by reference portfolio VaR (Rule 18f-4)"),("Absolute VaR Percent of Net Assets","Rule 18f-4"),("Derivatives Exposure Percent of Net Assets","Rule 18f-4 derivatives exposure; the 10% limited derivatives user test"),("Illiquid Investments Percent","Rule 22e-4 15% limit"),("Stress Loss","Loss under the stress scenario named on the limit")]),
 "Risk Limit Type": ("Internal", [("Hard","Exceedance requires immediate remediation and escalation"),("Soft","Exceedance requires review and an explained decision"),("Monitoring Only","Limit with no hard or soft consequence, watched for information; distinct from the Warning Threshold of a hard or soft limit")]),
 "Exceedance Resolution": ("Internal", [("Returned Within Limit by Market Movement",""),("Position Reduced",""),("Hedge Added",""),("Limit Temporarily Raised","Approved temporary increase"),("Limit Permanently Changed",""),("Measurement Corrected","No real exceedance; data or model error")]),
}

# ---------------------------------------------------------------------------
REL = [
 ("Risk Model","is supplied by","Party (02, PTY-) as model vendor","n : 0..1","Vendor data arrive in a 14 Dataset (DSET-)."),
 ("Risk Model","is inventoried as","Model Inventory Entry [37]","n : 0..1","Held on Risk Model.Model Inventory Reference (CD-216, CD-246)."),
 ("Risk Model","defines","Risk Factor","1 : 1..n","Specific risk is the factor 'Specific'."),
 ("Risk Factor","may represent","Curve Definition (22, CURVE-)","n : 0..1","Curve points stay 22."),
 ("Risk Factor","has","Risk Factor Return","1 : 0..n","Daily."),
 ("Instrument Factor Loading","loads","Instrument (17, INS-)","n : 1","Model output, not 22 vendor analytics (CD-211)."),
 ("Risk Calculation Run","uses","Risk Model","n : 1",""),
 ("Risk Calculation Run","reads","Portfolio Holding (18, HLD-) and Approved Price / Curve Point Observation (22)","n : n","Holdings date and market data cut-off recorded; values not stored."),
 ("Risk Calculation Run","produces","Portfolio Risk Measure / Risk Decomposition","1 : 0..n",""),
 ("Portfolio Risk Measure","measures","Portfolio (18, PORT-)","n : 1",""),
 ("Portfolio Risk Measure","is relative to","Benchmark (01, BMK-)","n : 0..1","Blank for absolute measures."),
 ("VaR Back-Test","tests","Portfolio Risk Measure (one-day VaR)","n : 1","Actual and hypothetical P&L bases are separate rows; realized P&L is a Derived copy of 27 or 18 (row rule)."),
 ("Risk Decomposition","decomposes","Portfolio Risk Measure","n : 1","The measure key carries horizon, confidence level and benchmark."),
 ("Portfolio Exposure","aggregates","Derivative Holding Detail (18) Delta-Adjusted Exposure Base","n : n","18 keeps the delta-adjusted exposure base (CD-211)."),
 ("Counterparty Exposure","is to","Party (02, PTY-) as counterparty","n : 1",""),
 ("Counterparty Exposure","is netted under","Trading Agreement (26, TAGR-)","n : 0..1","Collateral Held rows are Derived copies of 26 Collateral Balance."),
 ("Counterparty Exposure","supplies the measured value of","Counterparty Trading Limit (25)","n : 0..1","The row whose measure equals the 25 Limit Type (CD-215)."),
 ("Leverage & Exposure Measurement","measures","Investment Product (01, PRD-) against its declared method and maximum leverage","n : 1","01 Leverage Calculation Method and Maximum Leverage are read, not copied."),
 ("Leverage & Exposure Measurement","divides by","Fund NAV Calculation (27)","n : 0..1","Net assets Derived copy (27)."),
 ("Liquidity Horizon Bucket","reads investor terms of","Feeder Access Terms (01)","n : 0..1","Feeder funds only, while Form PF is filed (CW-166)."),
 ("Stress Scenario","has","Stress Scenario Shock","1 : 1..n",""),
 ("Stress Test Result","applies","Stress Scenario (STRESS-)","n : 1",""),
 ("Stress Test Result","may read","Portfolio Sustainability Metric (34)","n : 0..1","Climate scenarios read a 34 climate indicator value (CD-216)."),
 ("Liquidity Classification","classifies","Instrument (17, INS-) held by an Investment Product (01, PRD-)","n : 1","Fund keyed, measured on the fund's whole 18 book; split portions allowed."),
 ("Liquidity Classification","may read","Fair Value Determination (22, FVD-)","n : 0..1","Positions without a readily available market quotation."),
 ("Fund Liquidity Profile","aggregates","Liquidity Classification","1 : 1..n",""),
 ("Fund Liquidity Profile","is tested against","Highly Liquid Investment Minimum","n : 0..1","HLIM held only there."),
 ("Fund Liquidity Profile","reads","ETF Market Statistic (22)","n : 0..1","Own ETFs (CD-206)."),
 ("Highly Liquid Investment Minimum / Risk Program Designation","are approved through","Resolution Subject Link (35)","1 : 0..n","35 holds the link (CD-237); 31 holds none."),
 ("VaR Test Result","compares the fund's VaR with","Designated Reference Portfolio","n : 0..1","Relative tests only."),
 ("Designated Reference Portfolio","designates","Benchmark (01, BMK-) or Portfolio (18, PORT-)","n : 1",""),
 ("VaR Test Result","is tested against","Risk Limit (RLMT-)","n : 1","Thresholds only on Risk Limit."),
 ("Risk Program Designation","names the administrator through","Fund Officer Appointment (35)","n : 0..1",""),
 ("Risk Limit","is measured as","Risk Limit Utilization","1 : 0..n","One row per limit, date and portfolio in scope."),
 ("Risk Limit Exceedance (RLEX-)","is triggered by","Risk Limit Utilization","n : 1",""),
 ("Counterparty Trading Limit (25)","is measured as","Risk Limit Utilization","1 : 0..n","CD-215."),
 ("Risk Limit Exceedance (RLEX-)","exceeds","Risk Limit or Counterparty Trading Limit (25)","n : 1","Exactly one of the two."),
 ("Risk Limit Exceedance (RLEX-)","is referenced by","Reportable Fund Event / board reports (35)","1 : 0..n","N-RN and board reporting (CD-225)."),
 ("Compliance Rule (33, CRULE-)","reads","Portfolio Risk Measure / Leverage & Exposure Measurement / Counterparty Exposure","n : n","The rule names the 31 measure; the value is not copied (CD-223)."),
 ("Fund Regulatory Filing (35)","reports","Liquidity Classification / Fund Liquidity Profile / Liquidity Horizon Bucket / VaR Test Result / Leverage & Exposure Measurement / Stress Test Result","n : n","N-PORT, N-RN, N-CEN and, for private funds, Form PF (CD-213, CD-225)."),
 ("Rebalance Run (24, RBAL-)","uses","Risk Model","n : 0..1","24 'Risk Model Used' to be re-typed (CD-211)."),
]

# ---------------------------------------------------------------------------
SRC = [
 ("SEC Rule 22e-4 (liquidity risk management programs); Releases IC-32315 (2016) and IC-33142 (2018)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.22e-4","Regulation","Four liquidity categories, classification at least monthly, reasonably anticipated trade size, asset class classification, HLIM and shortfall reporting, 15% illiquid limit, In-Kind ETF exemption, split classification, liquidity risk assessment under normal and reasonably foreseeable stressed conditions","Liquidity Classification, Highly Liquid Investment Minimum, Fund Liquidity Profile, Risk Program Designation, Liquidity Category, Liquidity Stress Detail",["SEC Rule 22e-4"]),
 ("SEC Rule 18f-4 (use of derivatives by registered investment companies and BDCs); Release IC-34084 (2020)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.18f-4","Regulation","Derivatives risk management program and manager, derivatives exposure, relative (200% / 250%) and absolute (20% / 25%) VaR tests at 99% over 20 trading days with at least three years of data, designated reference portfolio, stress testing and back-testing, limited derivatives user exception (10%)","Designated Reference Portfolio, VaR Test Result, VaR Back-Test, Leverage & Exposure Measurement, VaR Test Regime, Exposure Method, Stress Scenario, Risk Limit",["SEC Rule 18f-4"]),
 ("SEC Form N-PORT and Form N-RN (formerly N-LIQUID)","US SEC","https://www.sec.gov/files/formn-port.pdf ; https://www.sec.gov/files/formn-rn.pdf","Regulatory form","Liquidity classification by holding (Item C.7), derivatives exposure and VaR information; N-RN reports of illiquid investments above 15%, HLIM shortfalls and VaR test failures","Liquidity Classification, Fund Liquidity Profile, VaR Test Result, Risk Limit Exceedance",["SEC Form N-PORT","SEC Form N-RN"]),
 ("SEC Form N-CEN","US SEC","https://www.sec.gov/files/formn-cen.pdf","Regulatory form","Annual census items on liquidity program and derivatives use, read by 35","Risk Program Designation",["SEC Form N-CEN"]),
 ("SEC Rule 2a-7(g)(8) (money market fund stress testing)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.2a-7","Regulation","Periodic stress tests of money market funds against hypothetical events and board reporting","Stress Test Result, Risk Program Type",["SEC Rule 2a-7"]),
 ("Basel Framework, MAR (market risk), including expected shortfall at 97.5% and back-testing traffic light","BCBS / BIS","https://www.bis.org/basel_framework/standard/MAR.htm","Standard","VaR, expected shortfall, actual and hypothetical P&L, back-test exceptions and zones (concepts only)","Risk Measure, VaR Back-Test, Confidence Level",["Basel MAR"]),
 ("NGFS climate scenarios","Network for Greening the Financial System","https://www.ngfs.net/ngfs-scenarios-portal/","Public scenarios","Climate transition and physical scenario families","Stress Scenario (Climate Scenario Pathway), Stress Scenario Source",["NGFS"]),
 ("SEC Form PF (sections on risk metrics and portfolio and investor liquidity)","US SEC; CFTC","https://www.sec.gov/files/formpf.pdf","Regulatory form","Liquidity buckets and risk metrics of private funds (the firm's feeder funds, CW-166); the filing is 35","Liquidity Horizon Bucket",["SEC Form PF"]),
 ("SEC Rule 6c-11 (exchange-traded funds)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.6c-11","Regulation","ETF market statistics read as a liquidity input","Fund Liquidity Profile (Own ETF Market Statistic)",["SEC Rule 6c-11"]),
 ("Federal Reserve / OCC Supervisory Guidance on Model Risk Management (SR 11-7)","Federal Reserve; OCC","https://www.federalreserve.gov/supervisionreg/srletters/sr1107.htm","Supervisory guidance","Model use vs model validation and inventory (applied by analogy; the model inventory is 37; superseded by SR 26-2)","Risk Model (Model Inventory Reference)",["SR 11-7"]),
 ("MSCI Barra factor models (public descriptions)","MSCI","https://www.msci.com","Vendor documentation","Factor model structure: factors, exposures, specific risk, covariance","Risk Model, Risk Factor, Instrument Factor Loading",["MSCI Barra"]),
 ("Bloomberg PORT (public descriptions)","Bloomberg","https://www.bloomberg.com/professional","Vendor documentation","Risk decomposition and contribution to risk by dimension","Risk Decomposition, Risk Dimension",["Bloomberg PORT"]),
 ("SimCorp Axioma risk models (public descriptions)","SimCorp","https://www.simcorp.com","Vendor documentation","Model horizons and factor types","Risk Model, Risk Factor Type",["SimCorp Axioma"]),
 ("Investment Company Act of 1940 Section 18 (capital structure: senior securities and asset coverage)","US Congress","https://www.law.cornell.edu/uscode/text/15/80a-18","Statute","Section 18(f)(1) 300% asset coverage for borrowings of open-end funds; senior securities that Rule 18f-4 does not cover","Exposure Method (Section 18 Asset Coverage), Leverage & Exposure Measurement",["Investment Company Act Section 18"]),
 ("ISDA Master Agreement and Credit Support Annex (structure)","ISDA","https://www.isda.org","Industry documentation","Netting set, replacement value and collateral concepts behind counterparty exposure","Counterparty Exposure",["ISDA"]),
 ("ISO 4217 / ISO 8601","ISO","https://www.iso.org","Standard","Currency and date formats","Formats used throughout",["ISO 4217","ISO 8601"]),
]
