"""Data Domain 33 - Investment Compliance. Content module for taxonomy_builder.py."""

META = {
 "title": "Investment Compliance Data Taxonomy",
 "subtitle": "Business domain 33 - Investment Compliance | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "33_Investment_Compliance/Investment_Compliance_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the investment compliance function of a US wealth manager that manages its own mutual funds, ETFs and collective investment trusts (PF line) and institutional separate accounts and OCIO mandates (IA line) in house. It defines how prospectus limits, institutional client guidelines and statutory investment restrictions become coded, versioned compliance rules in the order management and compliance engine; which fund and institutional portfolios each rule and rule library is assigned to; the instrument and issuer lists the rules read; how each restriction is coded, partially coded or monitored by hand; every pre-trade, intraday, post-trade and what-if check run with its rule-by-rule results; the alerts raised from failing and warning results, their disposition and any pre-trade override with four-eyes evidence; and investment breaches from detection through remediation, loss calculation, review and closure, with client and board waivers, periodic rule reviews and manual compliance checks. It answers to the chief compliance officer under SEC Rule 38a-1 and Advisers Act Rule 206(4)-7. Client-account checks of the brokerage and advice businesses (order suitability, account restrictions, Reg BI and managed account model drift) are not here: they belong to 48, 45 and 46. The fact that makes it a separate domain is that a coded rule is not the restriction it implements: one restriction becomes several rules, one rule serves many portfolios, and every test, override and breach must be evidenced against the exact rule version in force. Built from the Investment Company Act Sections 5, 12 and 18, SEC Rules 2a-7, 12d1-4, 12d3-1, 18f-4, 35d-1, 38a-1 and 31a-2, Advisers Act Rules 204-2 and 206(4)-7, IRC Subchapter M (Section 851), ERISA Sections 404 and 406, OCC 12 CFR 9.18 and public descriptions of common compliance engines. Use it as a starting point for a compliance engine data model, a breach register or an investment compliance glossary."),
  ("Scope", "In scope (mastered here): regulatory limit provisions (the statutory parameters rules are coded from); rule libraries; compliance rules (CRULE-) with logic, limits, warning levels, applicability and effective-dated, approved versions; rule library membership by version; rule source links to the restrictions and provisions they implement, with any internal buffer; rule assignments to portfolios; rule instrument lists and the members of firm-maintained lists; rule coding requests and restriction coding status; compliance check runs (CCHK-) with the pre-trade check subject and per-order check subject members carrying the outcome 25 copies; compliance rule results; compliance alerts (CALERT-), alert dispositions and pre-trade override approvals; investment breaches (BREACH-) and their source restrictions, breach remediation actions, breach loss calculations and breach reviews; guideline waivers; periodic rule reviews; manual compliance checks. Out of scope (referenced by ID): investment restrictions, mandates, products and regulatory regime (01 Investment Product & Service Offering); client restrictions, issuers, parties in interest and client approvers (02 Client & Household; Client Restriction keeps its name, CW-021); internal legal entities (09 Shared & Enterprise Reference Data); breach notifications to clients, guideline monitoring arrangements and compliance certificates (12 Institutional Client Servicing & Reporting); licensed datasets (14 Third-Party Data & Licensing); instruments, issuer profiles, regulatory instrument classifications and credit ratings (17 Instrument & Issuer Reference); portfolios and holdings (18 Portfolio & Investment Book of Record); employees (20 Human Capital); data quality issues (21 Data Governance & Analytics); internal credit assessments and MNPI assessments (23 Investment Research); proposed trades, rebalance runs and portfolio construction constraints (24 Portfolio Management & Construction); fund and institutional trade orders, block orders, order events, trade errors, cross trades and Rule 10f-3 purchases (25 Portfolio Trading & Execution); share class NAVs, NAV error cases and RIC test results (27 Fund Accounting & Valuation); risk measures, risk limits and risk limit exceedances (31 Investment Risk); sustainability exclusion lists (34 Stewardship & Sustainable Investing); board approvals (held on 35 Resolution Subject Link, CD-237), board reports, reportable fund events and regulator notifications (35 Fund Governance & Regulatory Reporting); product change initiatives (36 Product Development & Lifecycle). Not in scope at all: 15 Account Restrictions (ARX-), which are account-level blocks enforced on the client account (15, 29, 48); client order checks (48), Reg BI and advice evidence (45) and managed account drift and rebalancing checks (46); and the firm restricted and watch lists, code of ethics and personal trading (38 Corporate Compliance) and operational incidents (37)."),
  ("Structure", "Four levels: Data Domain > Data Family > Data Business Object > Data Business Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Regulatory Limit Provisions hold the statutory parameters and are the single master of statutory limit values (ICA Section 5(b)(1) 5% of total assets in one issuer within 75%, ICA Section 12(d)(1)(A)(iii) 10% in other investment companies, IRC Section 851(b)(3) 25% in one issuer). Compliance Rules (CRULE- x version) are effective-dated rule versions; only approved versions can be in force. A Rule Library version is a dated set of rule versions held as Rule Library Membership rows, and a rule may belong to several libraries. Each rule version is linked by Rule Source Links to what it implements: a 01 Investment Restriction (RST-), a 02 Client Restriction (CRX-), a Regulatory Limit Provision or a firm policy, with any internal buffer stated against the source value. Rule Assignments pin a library version or a rule version to a 18 Portfolio (PORT-) for an effective period, never a bare rule. Rules that test membership read Rule Instrument Lists; members are held here only for firm-maintained lists, while lists sourced from a 34 Sustainability Exclusion List or the 38 restricted list are read from their source. Rule Coding Requests record how a new or changed restriction (including a 36 product change) was interpreted, coded and approved, and Restriction Coding Status says whether each 01 or 02 restriction is coded, partially coded or monitored by hand. A Compliance Check Run (CCHK-) is one pre-trade, intraday, post-trade batch or what-if test. A pre-trade run has one Pre-Trade Check Subject (a 24 Proposed Trade, or a 25 Trade Order or Block Order), and one Check Subject Member row per tested order (each member order of a block) with an initial and a final Compliance Check Outcome, which 25 copies onto its Trade Order Event. Each run produces Compliance Rule Results per portfolio, rule version and evaluated issuer, instrument or group, with the limit applied after any Guideline Waiver. Failing and warning results raise Compliance Alerts (CALERT-) with Alert Dispositions and, before trading, Pre-Trade Override Approvals. A confirmed breach becomes an Investment Breach (BREACH-) per rule and issuer or group, with its primary source restriction and any further Breached Source Restrictions, Breach Remediation Actions (which may be implemented by a 25 Trade Order), a Breach Loss Calculation only where the loss is not on a 25 Trade Error, and Breach Reviews (root cause, escalation decision, CCO sign-off) that may open a 35 Reportable Fund Event. 12 Breach Notification and 35 board reporting reference the breach. Guideline Waivers (holding the relaxed limit as data), Periodic Rule Reviews and Manual Compliance Checks complete the program evidence."),
  ("Design principles", "1) Restriction is not rule: 01 and 02 say what the document or client requires; 33 says how the engine tests it, and never edits restriction text or limit values (CD-221). 2) Version everything that is tested: every result, alert, override and breach cites the rule version in force. 3) One limit, one owner: coded investment restrictions (including prospectus leverage and derivatives exposure caps and other rules that read a 31 measure) are 33 rules; risk-program limits are 31 Risk Limits, and their exceedances are 31's, never an Investment Breach (CD-223). 4) Check here, order in 25: 33 masters every run, result, alert and override; 25 copies the outcome and 33 holds no order status (CD-180, CD-221). 5) Breach here, report in 12 and 35: the breach is the master; client notification facts stay in 12 (CD-222). 6) One loss, one home: a trade error's loss stays on the 25 Trade Error, a NAV impact on the 27 NAV Error Case; Breach Loss Calculation covers only the rest. Regulator notification is a 35 Reportable Fund Event. 7) Investment compliance is not corporate compliance: the restricted list, code of ethics and personal trading are 38's; 33 rules read the restricted list and 34 exclusion lists at their source and never store their entries (CD-224). 8) Result status, alert workflow, disposition outcome, breach type and breach cause are separate lists. 9) Version and date rule sets unambiguously: rule versions are effective-dated and approved before they are in force, library versions are dated sets of rule versions, and assignments pin a version; a Date is effective from the start of that day in the portfolio's time zone. 10) Statutory limits are held once, on the Regulatory Limit Provision. 11) Flag Critical Data Elements (CDE) and personal data (PII)."),
  ("Applies To", "Shows the record each attribute belongs to: Provision, Library, Library Membership, Rule, Rule Source, Assignment, Instrument List, List Member, Coding Request, Coding Status, Check Run, Check Subject, Subject Member, Rule Result, Alert, Disposition, Override, Breach, Breach Source, Remediation, Loss Calculation, Breach Review, Waiver, Rule Review or Manual Check."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify a rule and the version in force, to know which portfolios it applies to and from which restriction it comes, to evidence what was tested, when and with what result, to release or block an order, to work and close an alert, or to identify, date, size, remediate and escalate an investment breach. Confirm with the chief compliance officer, the head of investment compliance and the fund boards' compliance reporting."),
  ("Primary / Secondary Reference", "Standard, rule or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Vendor references (Charles River IMS, Aladdin, SimCorp) indicate common industry structure only, not a license to reproduce vendor record layouts. Next step: map each attribute to the compliance engine of record per business line."),
  ("Notes", "PII = personal data under US privacy law (Regulation S-P, the Gramm-Leach-Bliley Act and state privacy laws). Compliance officer, coder, approver, reviewer and attesting employee references are personal data of internal staff. Rules, results, alerts and breaches for an institutional separate account held by an individual or a personal trust inherit client confidentiality (nonpublic personal information under Regulation S-P), and client restriction mappings are client confidential. No MNPI names are stored in 33: rule instrument lists sourced from the 38 restricted list hold no members here."),
  ("Tabs", "Hierarchy: Data Families, Object Groups and Data Business Objects with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: object-level cardinalities, including references to other Data Domains | Sources: standards, rules and vendor models used, with owners, licenses and links."),
  ("Suggested next steps", "1) Validate families, grains, lists and CDEs with the CCO, the head of investment compliance and the fund boards' compliance reporting. 2) Name the compliance engine of record per business line, and whether institutional separate account and private feeder fund guidelines run in the same engine as the funds (SME question 1). 3) Agree with 25 that Trade Order Event 'Compliance Check Outcome' becomes a Derived copy (33) of Pre-Trade Check Subject 'Compliance Check Outcome' (CD-180, CD-221). 4) Agree with 12 that Breach Notification gains 'Related Investment Breach' and that Breach Type, Breach Detected Date, Breached Restriction, Cure Action and Cure Date become Derived copies (33) (CD-222). 5) Agree with 31 the risk measures that 33 rules read and the line between Risk Limit and Compliance Rule (CD-223). 6) Agree with 46 and 48 that client-account checks (model drift, order suitability and restrictions) stay outside 33. 7) Agree with 34, 35, 36 and 38 the object names referenced here. 8) Turn the Relationships tab into the logical rule-to-breach model shared with 01, 02, 12, 24, 25, 27 and 35."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

EMP = "PII (internal staff)."
SMAP = ("PII where the portfolio implements an institutional separate account held by an individual or a personal trust; "
        "the result then inherits the 15 account restrictions.")
CLIENT = "Client confidential where the source is a client restriction or IMA guideline."
DATECONV = "Date convention: a Date effective from or to is effective from the start of that day in the portfolio's (or the library owner's) time zone; rule versions use Timestamps."

# ---------------------------------------------------------------------------
D("Rule Library", "IC-LIB",
  "The coded rule base: the statutory limit parameters rules are built from (33 is the master of statutory limits), the named rule libraries and the dated sets of rule versions that make up each library version, the compliance rules themselves with their logic, limits, warning levels and effective-dated versions, and the links from each rule version to the restriction, provision or policy it implements. Restriction text and limit values as written stay in 01 and 02.",
  [
   ("Regulatory Limit Provisions", "Statutory and regulatory investment limits broken into the testable components that rules are coded from. This is the master of statutory limit values; a 01 Investment Restriction with Restriction Source 'Regulatory' is the prospectus restatement and is linked to the provision (proposed to 01).", [
     ("Regulatory Limit Provision", [
       ("Provision Code", "Firm code that identifies one limit component of one regulatory provision.", "Provision", "Identifier", "Firm-defined", "ICA 5(b)(1) single issuer 5%", "Internal", "", "Y", "Written without a hyphenated stem so it never reads as an ID prefix."),
       ("Provision Citation", "Legal citation of the provision the limit comes from.", "Provision", "Text", "", "Investment Company Act of 1940, Section 5(b)(1)", "Investment Company Act Section 5", "", "Y"),
       ("Limit Component Description", "Plain statement of the single limit component, including the population it applies to.", "Provision", "Text", "", "Within 75% of total assets, no more than 5% of total assets in securities of any one issuer (cash items, government securities and securities of other investment companies excluded)", "Investment Company Act Section 5", "", "", "Government securities as defined in Section 2(a)(16): issued or guaranteed by the United States or by its instrumentalities acting under authority granted by Congress."),
       ("Provision Regulator", "Authority that administers the provision.", "Provision", "Code", "Shared: Regulator", "SEC", "Internal", "", "", "IRC provisions (Section 851) use 'IRS / US Treasury', added to the shared Regulator list at the Stage 3 consolidation (CD-241)."),
       ("Applicable Regulatory Regimes", "Vehicle or plan regimes the provision applies to.", "Provision", "Code (multi)", "Regulatory Regime", "US 1940 Act Registered", "openfunds", "Internal", ""),
       ("Statutory Limit Value", "Numeric limit set by the provision for this component; the single master of the statutory value.", "Provision", "Decimal", "", "5", "Investment Company Act Section 5", "", "Y"),
       ("Provision Limit Type", "Whether the statutory limit is a minimum, maximum, range or prohibition.", "Provision", "Code", "Shared: Restriction Limit Type", "Maximum", "Internal", "", ""),
       ("Provision Measurement Basis", "Basis the statutory limit is measured on.", "Provision", "Code", "Shared: Measurement Basis", "% of Total Assets", "Investment Company Act Section 5", "", ""),
       ("Interpretive Guidance Reference", "Citation of the staff guidance, FAQ or no-action letter that governs how the component is measured.", "Provision", "Text", "", "SEC staff FAQ on Rule 12d1-4 (citation per fund counsel)", "Internal", "", ""),
       ("Provision Effective From", "Date the limit component took effect in law.", "Provision", "Date", "ISO 8601", "1940-08-22", "Internal", "", ""),
       ("Provision Effective To", "Date the limit component was repealed or replaced.", "Provision", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Rule Libraries", "Named sets of rules applied together, such as all rules for a 1940 Act diversified fund or for Subchapter M diversification. A library version is a dated set of rule versions; rule versions are dated independently of library versions.", [
     ("Rule Library", [
       ("Rule Library Code", "Firm code of the library.", "Library", "Identifier", "Firm-defined", "1940 Act Diversified 75-5-10", "Internal", "Charles River IMS", "Y"),
       ("Rule Library Version", "Version of the library; a new version is created whenever the set of member rule versions changes.", "Library", "Integer", "", "4", "Internal", "", "Y"),
       ("Library Regulatory Regimes", "Vehicle or plan regimes the library is designed for.", "Library", "Code (multi)", "Regulatory Regime", "US 1940 Act Registered", "Internal", "", ""),
       ("Library Business Lines", "Business lines the library may be assigned to.", "Library", "Code (multi)", "Shared: Business Line", "PF", "Internal", "", ""),
       ("Library Owner", "Compliance officer accountable for the library.", "Library", "Reference (Employee)", "", "EMP-30544", "SEC Rule 38a-1", "", "", EMP),
       ("Library Status", "Whether the library version may be assigned.", "Library", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
       ("Library Version Effective From", "Date the library version took effect.", "Library", "Date", "ISO 8601", "2026-03-02", "Internal", "", "", DATECONV),
       ("Library Version Effective To", "Date the library version was superseded.", "Library", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Rule Library Membership", [
       ("Membership Library", "Library whose version the row belongs to.", "Library Membership", "Reference (Rule Library, 33)", "", "1940 Act Diversified 75-5-10", "Internal", "", "Y"),
       ("Membership Library Version", "Library version the row belongs to.", "Library Membership", "Integer", "", "4", "Internal", "", ""),
       ("Member Rule", "Rule included in the library version.", "Library Membership", "Reference (Compliance Rule, 33)", "", "CRULE-004512", "Internal", "", "Y", "A rule may belong to several libraries (e.g. the 1940 Act diversified library and the Subchapter M library)."),
       ("Member Rule Version", "Version of the rule included; a new rule version creates a new library version.", "Library Membership", "Integer", "", "3", "Internal", "", ""),
     ]),
   ]),
   ("Compliance Rules", "Coded tests run by the compliance engine, one row per rule version. A rule version is effective-dated on its own; only Approved versions can be in force.", [
     ("Compliance Rule", [
       ("Compliance Rule ID", "Enterprise identifier of the rule; stable across versions.", "Rule", "Identifier", "", "CRULE-004512", "Internal", "Charles River IMS", "Y"),
       ("Rule Version", "Version of the rule logic or parameters; every result cites it.", "Rule", "Integer", "", "3", "SEC Rule 31a-2", "Advisers Act Rule 204-2", "Y"),
       ("Rule Name", "Business name of the rule as shown to compliance analysts and traders.", "Rule", "Text", "", "ICA 12(d)(1)(A)(iii) investment companies 10% hard", "Internal", "", ""),
       ("Rule Type", "Kind of test the rule performs; exactly one type per rule, the more specific type taking precedence.", "Rule", "Code", "Rule Type", "Concentration", "Internal", "Charles River IMS", "Y"),
       ("Rule Logic Expression", "Coded expression the engine evaluates, in the engine's rule language or as structured pseudo-code.", "Rule", "Text", "", "SUM(MV) WHERE issuer is an investment company / total assets <= 10%", "Internal", "", "", CLIENT),
       ("Rule Limit Type", "Whether the coded limit is a minimum, maximum, range or prohibition.", "Rule", "Code", "Shared: Restriction Limit Type", "Maximum", "Internal", "", "Y"),
       ("Rule Limit Value", "Limit the engine tests against (the lower bound when the limit type is Range), which may sit inside the source restriction by an internal buffer.", "Rule", "Decimal", "", "9.5", "Internal", "", "Y", "The source value is read from 01 Investment Restriction.Limit Value or Regulatory Limit Provision.Statutory Limit Value; the difference is on Rule Source Link.Buffer Versus Source."),
       ("Rule Upper Limit Value", "Upper bound when the limit type is Range; blank otherwise.", "Rule", "Decimal", "", "", "Internal", "", "Y"),
       ("Warning Value", "Level at which the rule raises a warning before the limit is reached.", "Rule", "Decimal", "", "8.5", "Internal", "", "Y"),
       ("Rule Measurement Basis", "Basis the rule measures on.", "Rule", "Code", "Shared: Measurement Basis", "% of Total Assets", "Internal", "", "Y"),
       ("Rule Applicability", "Whether the rule is tested before trading, after trading, or both.", "Rule", "Code", "Rule Applicability", "Pre- and Post-Trade", "Internal", "Charles River IMS", "Y"),
       ("Hard Block Indicator", "Whether a pre-trade failure blocks release of the order unless an override is approved.", "Rule", "Boolean", "", "Y", "Internal", "", "Y", "Soft rules raise an alert but allow release."),
       ("Look-Through Indicator", "Whether the rule looks through fund and derivative holdings to underlying exposures; a modifier of any rule type.", "Rule", "Boolean", "", "N", "SEC Rule 12d1-4", "", ""),
       ("Rule Instrument Lists Read", "Rule instrument lists the rule tests membership of.", "Rule", "Reference (Rule Instrument List, 33) (multi)", "", "ERISA Parties in Interest", "Internal", "", "", "Filled for List Membership and Firm Restricted List rules and for concentration rules on an approved issuer list."),
       ("Risk Measure Read", "31 risk measure the rule tests, where the rule reads a 31 measurement rather than holdings.", "Rule", "Code", "Shared: Risk Measure", "", "Internal", "", "", "Names the 31 measure only; the value is never copied here (CD-223)."),
       ("Exposure Method Read", "31 exposure method the rule tests, for leverage and derivatives exposure caps.", "Rule", "Code", "Shared: Exposure Method", "", "SEC Rule 18f-4", "", "", "Example rules: a prospectus cap on derivatives exposure reads 'Rule 18f-4 Derivatives Exposure'; a borrowing or senior securities limit reads 'Section 18 Asset Coverage' (CD-223)."),
       ("Internal Credit Assessment Used Indicator", "Whether the rule reads the 23 Internal Credit Assessment, for example a Rule 2a-7 minimal credit risk determination, instead of or as well as agency ratings.", "Rule", "Boolean", "", "N", "SEC Rule 2a-7", "", ""),
       ("Originating Coding Request", "Coding request that created this rule version.", "Rule", "Reference (Rule Coding Request, 33)", "", "RCR 2026/0187", "Internal", "", ""),
       ("Version Approval Status", "Approval state of the rule version; only Approved or Approved with Conditions versions may be in force.", "Rule", "Code", "Shared: Approval Status", "Approved", "SEC Rule 38a-1", "", ""),
       ("Version Approved By", "Compliance officer who approved the rule version.", "Rule", "Reference (Employee)", "", "EMP-30544", "SEC Rule 38a-1", "", "", EMP),
       ("Version Approved Date", "Date the rule version was approved.", "Rule", "Date", "ISO 8601", "2026-02-27", "SEC Rule 38a-1", "", ""),
       ("Version Effective From", "Moment the rule version took effect in the engine; set only for approved versions.", "Rule", "Timestamp", "ISO 8601", "2026-03-02T06:00:00-05:00", "SEC Rule 31a-2", "", "Y"),
       ("Version Effective To", "Moment the rule version was superseded or retired.", "Rule", "Timestamp", "ISO 8601", "", "SEC Rule 31a-2", "", "Y"),
       ("Rule Status", "Operating status of the rule version in the engine.", "Rule", "Code", "Shared: Record Status", "Active", "Internal", "", "", "A pause does not end the version; it sets Paused with its own dates. A second pause of the same version closes the version and opens a new one, so pause history is never overwritten."),
       ("Rule Status Effective From", "Date the current rule status took effect.", "Rule", "Date", "ISO 8601", "2026-03-02", "Internal", "", "", DATECONV),
       ("Rule Status Effective To", "Date the current rule status ended, for example the end of a pause.", "Rule", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Rule Sources", "What each rule version implements: an investment restriction, a client restriction, a regulatory limit provision or a firm policy. The link is pinned to the rule version and carries no dates of its own.", [
     ("Rule Source Link", [
       ("Linked Rule", "Rule whose version implements the source.", "Rule Source", "Reference (Compliance Rule, 33)", "", "CRULE-004512", "Internal", "", "Y"),
       ("Linked Rule Version", "Version of the rule the link applies to.", "Rule Source", "Integer", "", "3", "Internal", "", ""),
       ("Rule Source Type", "Kind of source the rule implements.", "Rule Source", "Code", "Rule Source Type", "Investment Restriction", "Internal", "", "Y"),
       ("Source Investment Restriction", "Prospectus, SAI, fund document or mandate restriction implemented (owned by 01).", "Rule Source", "Reference (Restriction)", "", "RST-55012", "Internal", "", "Y"),
       ("Source Client Restriction", "Client restriction implemented, typically an investment exclusion (owned by 02).", "Rule Source", "Reference (Client Restriction)", "", "", "Internal", "", "Y", "Client confidential. 15 Account Restrictions (ARX-) are never a rule source (CD-221)."),
       ("Source Regulatory Provision", "Statutory limit component the rule codes, when the source is a regulation; for a Regulatory 01 restriction, the provision it restates.", "Rule Source", "Reference (Regulatory Limit Provision, 33)", "", "ICA 12(d)(1)(A)(iii) investment companies 10%", "Internal", "", ""),
       ("Interpretation Note", "How compliance interpreted the source when coding it.", "Rule Source", "Text", "", "Underlying funds identified from the 17 instrument type; money market fund investments under Rule 12d1-1 excluded", "Internal", "", ""),
       ("Buffer Versus Source", "Difference between the rule limit and the source limit value, in the measurement basis units; zero when the rule codes the source value, blank for client restriction and firm policy sources, which have no limit value.", "Rule Source", "Decimal", "", "-0.5", "Internal", "", "", "Source value read from 01 Investment Restriction.Limit Value or Regulatory Limit Provision.Statutory Limit Value, never stored here (SME question 2)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Rule Coding & Assignment", "IC-COD",
  "How rules reach portfolios and data: assignments of a pinned library version or rule version to portfolios, the instrument and issuer lists that membership rules read, the requests through which restrictions are interpreted and coded, and the coding status of each 01 and 02 restriction.",
  [
   ("Rule Assignments", "Effective-dated attachment of a library version or a rule version to a portfolio. Never a bare rule: a new library or rule version is put in force for a portfolio by closing the assignment row and opening a new one.", [
     ("Rule Assignment", [
       ("Assigned Rule", "Rule assigned; blank when a library is assigned.", "Assignment", "Reference (Compliance Rule, 33)", "", "", "Internal", "", ""),
       ("Assigned Rule Version", "Rule version assigned; required when a rule is assigned.", "Assignment", "Integer", "", "", "Internal", "", ""),
       ("Assigned Rule Library", "Library assigned; blank when a single rule is assigned.", "Assignment", "Reference (Rule Library, 33)", "", "1940 Act Diversified 75-5-10", "Internal", "", ""),
       ("Assigned Library Version", "Library version assigned; required when a library is assigned.", "Assignment", "Integer", "", "4", "Internal", "", ""),
       ("Assigned Portfolio", "Portfolio the rule or library is tested on.", "Assignment", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "Y", SMAP),
       ("Assignment Inclusion Type", "Whether the row includes the rule or carves it out of an assigned library.", "Assignment", "Code", "Shared: Inclusion Type", "Include", "Internal", "", ""),
       ("Assignment Basis", "Why the rule or library applies to the portfolio.", "Assignment", "Code", "Assignment Basis", "Fund Regime", "Internal", "", ""),
       ("Assignment Effective From", "Date the assignment took effect.", "Assignment", "Date", "ISO 8601", "2026-03-02", "Internal", "", "Y", DATECONV),
       ("Assignment Effective To", "Date the assignment ended.", "Assignment", "Date", "ISO 8601", "", "Internal", "", "Y"),
     ]),
   ]),
   ("Rule Instrument Lists", "Lists of instruments or issuers that membership rules test against. Members are held here only for firm-maintained lists; lists sourced from 34, 38 or 02 are read from their source and hold no members here.", [
     ("Rule Instrument List", [
       ("Rule Instrument List Code", "Firm code of the list.", "Instrument List", "Identifier", "Firm-defined", "ERISA Parties in Interest", "Internal", "", "Y"),
       ("Rule Instrument List Version", "Version of the list definition; membership is effective-dated separately.", "Instrument List", "Integer", "", "2", "Internal", "", ""),
       ("Rule Instrument List Type", "What the list is used for.", "Instrument List", "Code", "Rule Instrument List Type", "ERISA Party-in-Interest Issuers", "Internal", "ERISA", "Y"),
       ("Members Held Here Indicator", "Whether the list's members are maintained in 33 (firm-maintained list) or read from the source list at test time (sourced list).", "Instrument List", "Boolean", "", "Y", "Internal", "", "", "Row rule: N for lists fed from a 34 Sustainability Exclusion List, the 38 restricted list, or a 02-maintained party-in-interest list; such lists have no Rule Instrument List Member rows (CD-224)."),
       ("Source Sustainability Exclusion List", "34 exclusion list the rule list reads, for ESG exclusion lists.", "Instrument List", "Reference (Sustainability Exclusion List, 34)", "", "TCOAL / 3", "Internal", "", ""),
       ("Restricted List Source", "Firm restricted or watch list the rule list reads.", "Instrument List", "Reference (Firm Restricted List, 38)", "", "GRL", "Internal", "", "", "Re-typed at the Stage 4 consolidation (CD-224, CD-256): reads the 38 Firm Restricted List by its Restricted List Code. No restricted names are stored in 33."),
       ("Source Client Restriction", "Client restriction whose exclusion list the rule list implements (owned by 02).", "Instrument List", "Reference (Client Restriction)", "", "", "Internal", "", "", "Client confidential. 02 keeps the restriction text and Exclusion List Reference."),
       ("List Source Dataset", "Licensed dataset that populates a firm-maintained list.", "Instrument List", "Reference (Dataset)", "", "", "Internal", "", ""),
       ("List Information Classification", "Information classification of the list definition and any members held here.", "Instrument List", "Code", "Shared: Information Classification", "Confidential - Client", "Internal", "", ""),
       ("List Refresh Frequency", "How often the list is refreshed from its source.", "Instrument List", "Code", "Shared: Frequency", "Daily", "Internal", "", ""),
       ("List Status", "Whether the list is in use.", "Instrument List", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
     ]),
     ("Rule Instrument List Member", [
       ("Member List", "Firm-maintained list the member belongs to.", "List Member", "Reference (Rule Instrument List, 33)", "", "ERISA Parties in Interest", "Internal", "", ""),
       ("Member Instrument", "Instrument on the list, for instrument-level lists.", "List Member", "Reference (Instrument, 17)", "", "", "Internal", "", ""),
       ("Member Issuer", "Issuer on the list, for issuer-level lists; the issuer is a 02 party with a 17 Issuer Profile.", "List Member", "Reference (Party)", "", "PTY-7002210", "Internal", "", ""),
       ("Member Inclusion Type", "Whether the row puts the instrument or issuer on the list (Include) or carves it out of an included issuer group (Exclude).", "List Member", "Code", "Shared: Inclusion Type", "Include", "Internal", "", ""),
       ("Membership Reason", "Why the instrument or issuer is on the list.", "List Member", "Text", "", "Plan sponsor of client plan; party in interest under ERISA Section 3(14)", "ERISA", "", ""),
       ("Member Effective From", "Date the member joined the list.", "List Member", "Date", "ISO 8601", "2026-01-15", "Internal", "", "", DATECONV),
       ("Member Effective To", "Date the member left the list.", "List Member", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Rule Coding", "How a new or changed restriction is interpreted, coded, tested and approved, and the coding status of each restriction.", [
     ("Rule Coding Request", [
       ("Coding Request Reference", "Identifier of the coding request.", "Coding Request", "Identifier", "", "RCR 2026/0187", "Internal", "", "", "No enterprise prefix."),
       ("Coding Request Trigger", "Event that caused the request.", "Coding Request", "Code", "Coding Request Trigger", "IMA Amendment", "Internal", "", ""),
       ("Triggering Investment Restriction", "Investment restriction that is new or changed (owned by 01).", "Coding Request", "Reference (Restriction)", "", "RST-55012", "Internal", "", ""),
       ("Triggering Client Restriction", "Client restriction that is new or changed (owned by 02).", "Coding Request", "Reference (Client Restriction)", "", "", "Internal", "", "", "Client confidential."),
       ("Triggering Product Change", "36 product change initiative (prospectus or limit change, merger, conversion) that requires rules to change.", "Coding Request", "Reference (Product Change Initiative, 36)", "", "LCHG-2026-00118", "Internal", "", ""),
       ("Required Effective Date", "Date by which the rules must be live, such as the IMA amendment or prospectus effective date.", "Coding Request", "Date", "ISO 8601", "2026-10-01", "Internal", "", ""),
       ("Interpretation Summary", "How compliance interpreted the restriction, including assumptions agreed with the client or counsel.", "Coding Request", "Text", "", "Client's 'no tobacco' read as GICS sub-industry 30203010 plus issuers with more than 5% revenue from tobacco", "Internal", "", "", CLIENT),
       ("Coded By", "Analyst who coded the rules.", "Coding Request", "Reference (Employee)", "", "EMP-30561", "Internal", "", "", EMP),
       ("Coding Approved By", "Compliance officer who approved the coding for release.", "Coding Request", "Reference (Employee)", "", "EMP-30544", "SEC Rule 38a-1", "", "", EMP),
       ("Coding Approval Status", "Approval state of the coded rules.", "Coding Request", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("Implementation Date", "Date the coded rules went live; the rule versions created carry the request as Originating Coding Request.", "Coding Request", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
     ]),
     ("Restriction Coding Status", [
       ("Status Investment Restriction", "Investment restriction whose coding status is recorded (owned by 01).", "Coding Status", "Reference (Restriction)", "", "RST-55012", "Internal", "", ""),
       ("Status Client Restriction", "Client restriction whose coding status is recorded (owned by 02).", "Coding Status", "Reference (Client Restriction)", "", "", "Internal", "", "", "Client confidential."),
       ("Restriction Coding Status", "Whether and how the restriction is tested.", "Coding Status", "Code", "Restriction Coding Status", "Coded", "Internal", "", "Y", "Drives Manual Compliance Check and is read by 12 Guideline Monitoring Arrangement."),
       ("Not Testable Reason", "Why the restriction cannot be coded, or which part of it is not coded.", "Coding Status", "Text", "", "", "Internal", "", ""),
       ("Coding Status Effective From", "Date the status took effect.", "Coding Status", "Date", "ISO 8601", "2026-09-30", "Internal", "", "", DATECONV),
       ("Coding Status Effective To", "Date the status was superseded.", "Coding Status", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Checks & Results", "IC-CHK",
  "Every test the engine runs: pre-trade checks of proposed trades, orders and blocks, intraday and post-trade batch checks of portfolios, and what-if checks, with the outcome per tested order (one row per member order when a block is checked) and the result of each rule version for each portfolio and evaluated issuer or group. Order status stays in 25.",
  [
   ("Compliance Check Runs", "One execution of the compliance engine over a defined scope. A run is recorded even when no assigned rule applies (outcome Not Checked).", [
     ("Compliance Check Run", [
       ("Compliance Check Run ID", "Enterprise identifier of the run.", "Check Run", "Identifier", "", "CCHK-2026-000918822", "Internal", "Charles River IMS", "Y"),
       ("Compliance Check Run Type", "Kind of run: pre-trade, intraday, post-trade batch or what-if.", "Check Run", "Code", "Compliance Check Run Type", "Pre-Trade", "Internal", "", "Y"),
       ("Check Run Trigger", "Event or schedule that caused the engine to start the run.", "Check Run", "Code", "Check Run Trigger", "Order Entry", "Internal", "", ""),
       ("Run Timestamp", "Moment the engine evaluated the run.", "Check Run", "Timestamp", "ISO 8601", "2026-10-05T09:41:13.402-04:00", "SEC Rule 38a-1", "SEC Rule 31a-2", "Y"),
       ("Holdings As-Of Timestamp", "As-of moment of the 18 holdings and open orders the run tested.", "Check Run", "Timestamp", "ISO 8601", "2026-10-05T09:41:00-04:00", "Internal", "", ""),
       ("Run Batch Reference", "Engine batch that grouped this run with others, such as all proposals of one rebalance run or the nightly post-trade batch.", "Check Run", "Identifier", "", "BATCH 20261005 EOD 01", "Internal", "", ""),
       ("Evidential Period-End Run Indicator", "Whether the run is the designated evidential run for a period end, such as the quarter-end RIC diversification test read by 35 and the 12 Compliance Certificate.", "Check Run", "Boolean", "", "N", "IRC Section 851(b)(3)", "Internal", ""),
     ]),
     ("Pre-Trade Check Subject", [
       ("Tested Proposed Trade", "24 proposed trade tested before release.", "Check Subject", "Reference (Proposed Trade, 24)", "", "", "Internal", "", "Y"),
       ("Tested Trade Order", "25 trade order tested alone, before release to the desk or on amendment.", "Check Subject", "Reference (Trade Order, 25)", "", "", "Internal", "", "Y"),
       ("Tested Block Order", "25 block order tested as a whole; its member orders each get a Check Subject Member row.", "Check Subject", "Reference (Block Order, 25)", "", "BLOCK-2026-0081234", "Internal", "", "Y"),
       ("Subject Check Outcome", "Outcome of the check for a proposed trade subject; blank for order and block subjects, whose outcomes are on Check Subject Member rows.", "Check Subject", "Code", "Shared: Compliance Check Outcome", "", "Internal", "", ""),
     ]),
     ("Check Subject Member", [
       ("Member Check Run", "Pre-trade run the outcome belongs to.", "Subject Member", "Reference (Compliance Check Run, 33)", "", "CCHK-2026-000918822", "Internal", "", "Y"),
       ("Checked Trade Order", "25 trade order the outcome applies to: the order itself for a single-order subject, or each member order of a block subject.", "Subject Member", "Reference (Trade Order, 25)", "", "TORD-2026-00418812", "Internal", "", "Y"),
       ("Tested Quantity", "Quantity or amount of the order tested, as it stood when the check ran; the order's current quantity is 25's.", "Subject Member", "Decimal", "", "15000", "Internal", "", "", "Evidence of what was tested; not a copy of the 25 order quantity after amendment."),
       ("Initial Check Outcome", "Outcome before any override was decided.", "Subject Member", "Code", "Shared: Compliance Check Outcome", "Failed - Blocked", "Internal", "", ""),
       ("Compliance Check Outcome", "Final outcome for the order after any override; the value 25 copies.", "Subject Member", "Code", "Shared: Compliance Check Outcome", "Failed - Override Approved", "Internal", "", "Y", "Master of 25 Trade Order Event.Compliance Check Outcome, which becomes a Derived copy (33) (CD-180, CD-221). Row rule: 25 copies the outcome of the latest run before release that covered the order, whether alone or in a block; when an override changes the outcome, 25 records a second Compliance Checked event. Failed - Override Approved is set only when every hard failure for the order's portfolio has an approved override."),
       ("Releasing Override", "Override approval that released the order, when the final outcome is Failed - Override Approved.", "Subject Member", "Reference (Pre-Trade Override Approval, 33)", "", "CALERT-2026-0041901 / 1", "Internal", "", ""),
       ("Outcome Timestamp", "Moment the final outcome was set.", "Subject Member", "Timestamp", "ISO 8601", "2026-10-05T09:44:02-04:00", "Internal", "", ""),
     ]),
   ]),
   ("Rule Results", "The result of one rule version for one portfolio and, for grouped rules, one evaluated issuer, instrument or group in one run.", [
     ("Compliance Rule Result", [
       ("Result Check Run", "Run that produced the result.", "Rule Result", "Reference (Compliance Check Run, 33)", "", "CCHK-2026-000918822", "Internal", "", "Y"),
       ("Result Portfolio", "Portfolio the rule was evaluated for.", "Rule Result", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "Y", SMAP),
       ("Evaluated Rule", "Compliance rule whose version was evaluated for the portfolio in the run.", "Rule Result", "Reference (Compliance Rule, 33)", "", "CRULE-004512", "Internal", "", "Y"),
       ("Evaluated Rule Version", "Version of the rule in force at the run timestamp.", "Rule Result", "Integer", "", "3", "SEC Rule 31a-2", "", "Y"),
       ("Evaluated Issuer", "Issuer the result is for, for rules grouped by issuer; part of the grain.", "Rule Result", "Reference (Party)", "", "PTY-7002210", "Internal", "", "Y"),
       ("Evaluated Instrument", "Instrument the result is for, for rules grouped by instrument; part of the grain.", "Rule Result", "Reference (Instrument, 17)", "", "", "Internal", "", ""),
       ("Evaluated Group Key", "Sector, country or other group the result is for, for rules grouped by a classification; part of the grain.", "Rule Result", "Text", "", "", "Internal", "", ""),
       ("Compliance Rule Result Status", "Outcome of the rule for the portfolio and group.", "Rule Result", "Code", "Compliance Rule Result Status", "Warning", "Internal", "", "Y"),
       ("Measured Value", "Value the rule computed, in the rule's measurement basis.", "Rule Result", "Decimal", "", "8.92", "Internal", "", "Y"),
       ("Limit Applied", "Limit value the result was tested against at test time, after any guideline waiver.", "Rule Result", "Decimal", "", "9.5", "Internal", "", "", "Test-time evidence read from the rule version or the applied waiver; the masters are Compliance Rule.Rule Limit Value and Guideline Waiver.Waived Limit Value."),
       ("Applied Guideline Waiver", "Guideline waiver whose limit was applied instead of the rule limit.", "Rule Result", "Reference (Guideline Waiver, 33)", "", "", "Internal", "", ""),
       ("Numerator Value", "Numerator the engine computed, in the units of the rule's measurement basis (currency amount, shares, days or count).", "Rule Result", "Decimal", "", "44600000", "Internal", "", ""),
       ("Denominator Value", "Denominator the engine computed, in the units of the rule's measurement basis, such as net assets or the issuer's outstanding voting securities.", "Rule Result", "Decimal", "", "500000000", "Internal", "", "", "Computed by the engine from 18 holdings, 17 terms or the 27 fund NAV per the rule's denominator definition; test evidence, not a master of net assets."),
       ("Source Risk Measurement", "31 measurement read by the rule, for rules that test a risk measure.", "Rule Result", "Reference (Leverage & Exposure Measurement / Counterparty Exposure / Portfolio Risk Measure, 31)", "", "", "Internal", "", "", "Names the 31 record; the value read is the Measured Value (CD-223)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Alerts & Overrides", "IC-ALT",
  "Alerts raised from failing, warning and unevaluated rule results, how each is worked and disposed of, and the approvals that allow an order to be released despite a hard failure.",
  [
   ("Compliance Alerts", "Work items raised from rule results that need compliance attention.", [
     ("Compliance Alert", [
       ("Compliance Alert ID", "Enterprise identifier of the alert.", "Alert", "Identifier", "", "CALERT-2026-0041877", "Internal", "", "Y"),
       ("Source Rule Result", "Rule result that raised the alert.", "Alert", "Reference (Compliance Rule Result, 33)", "", "CCHK-2026-000918822 / PORT-000412 / CRULE-004512 v3 / PTY-7002210", "Internal", "", "Y"),
       ("Alert Severity", "Severity assigned to the alert so analysts work the most serious first.", "Alert", "Code", "Shared: Severity", "High", "Internal", "", ""),
       ("Alert Status", "Workflow status of the alert.", "Alert", "Code", "Shared: Case Status", "In Progress", "Internal", "", "Y"),
       ("Alert Raised Timestamp", "Moment the alert was raised.", "Alert", "Timestamp", "ISO 8601", "2026-10-05T09:41:13-04:00", "SEC Rule 38a-1", "", "Y"),
       ("Alert Assigned To", "Compliance analyst working the alert.", "Alert", "Reference (Employee)", "", "EMP-30561", "Internal", "", "", EMP),
     ]),
     ("Alert Disposition", [
       ("Disposed Alert", "Alert the disposition concludes.", "Disposition", "Reference (Compliance Alert, 33)", "", "CALERT-2026-0041877", "Internal", "", ""),
       ("Disposition Sequence", "Order of the disposition within the alert; a reopened alert gets a new disposition and keeps the earlier one.", "Disposition", "Integer", "", "1", "Internal", "", ""),
       ("Alert Disposition Outcome", "Conclusion reached on the alert.", "Disposition", "Code", "Alert Disposition Outcome", "Confirmed Breach", "Internal", "", "Y"),
       ("Disposition Rationale", "Why the analyst reached the conclusion.", "Disposition", "Text", "", "Passive breach after rating downgrade moved issuer into the 5% bucket", "Internal", "", ""),
       ("Disposed By", "Analyst who dispositioned the alert.", "Disposition", "Reference (Employee)", "", "EMP-30561", "Internal", "", "", EMP),
       ("Disposition Reviewed By", "Second reviewer of the disposition, where policy requires four-eyes review.", "Disposition", "Reference (Employee)", "", "EMP-30544", "Internal", "", "", EMP),
       ("Disposition Timestamp", "Moment the disposition was recorded.", "Disposition", "Timestamp", "ISO 8601", "2026-10-05T11:02:00-04:00", "Internal", "", ""),
       ("Related Data Quality Issue", "21 data quality issue raised when the alert was caused by bad data.", "Disposition", "Reference (Data Quality Issue, 21)", "", "", "Internal", "", ""),
     ]),
   ]),
   ("Pre-Trade Overrides", "Approvals that let an order with a hard failure be released.", [
     ("Pre-Trade Override Approval", [
       ("Override Alert", "Hard-fail alert the override applies to.", "Override", "Reference (Compliance Alert, 33)", "", "CALERT-2026-0041901", "Internal", "", ""),
       ("Override Approval Sequence", "Order of the approval when more than one approver is required.", "Override", "Integer", "", "1", "Internal", "", ""),
       ("Override Reason", "Why the override was requested.", "Override", "Code", "Override Reason", "Trade Reduces Existing Breach", "Internal", "", ""),
       ("Override Justification", "Narrative justification given by the requester.", "Override", "Text", "", "Sale reduces issuer weight from 10.4% to 9.1%; rule fails on post-trade cash basis only", "Internal", "", ""),
       ("Override Requested By", "Portfolio manager or trader who requested the override.", "Override", "Reference (Employee)", "", "EMP-30188", "Internal", "", "", EMP),
       ("Override Approver", "Compliance officer who decided the override.", "Override", "Reference (Employee)", "", "EMP-30544", "SEC Rule 38a-1", "", "", EMP),
       ("Override Approval Status", "Decision the approver took on the override request.", "Override", "Code", "Shared: Approval Status", "Approved with Conditions", "Internal", "", "Y"),
       ("Override Decision Timestamp", "Moment the approver decided.", "Override", "Timestamp", "ISO 8601", "2026-10-05T09:43:51-04:00", "Internal", "", ""),
       ("Override Conditions", "Conditions attached to the approval.", "Override", "Text", "", "Order quantity may not be increased; valid for today's session only", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Breaches & Remediation", "IC-BRC",
  "Investment breaches of coded rules from detection to closure: what was breached, for which issuer or group, when and why, the restrictions behind the breached rule, how it was cured, the loss to the portfolio where it is not already on a 25 Trade Error or 27 NAV Error Case, and the review and sign-off. Client notification is 12's; board reporting and regulator notification are 35's; exceedances of 31 risk limits are 31's.",
  [
   ("Investment Breaches", "The breach master, referenced by 12, 35 and 37.", [
     ("Investment Breach", [
       ("Investment Breach ID", "Enterprise identifier of the breach.", "Breach", "Identifier", "", "BREACH-2026-00143", "Internal", "", "Y"),
       ("Breached Portfolio", "Portfolio whose 18 Portfolio Holdings are outside the limit of the breached rule.", "Breach", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "Y", SMAP),
       ("Breached Rule", "Compliance rule whose limit the portfolio is outside.", "Breach", "Reference (Compliance Rule, 33)", "", "CRULE-004512", "Internal", "", "Y"),
       ("Breached Issuer", "Issuer whose exposure breaches the rule, for rules grouped by issuer; two issuers over the same limit are two breaches.", "Breach", "Reference (Party)", "", "PTY-7002210", "Internal", "", "Y"),
       ("Breached Instrument", "Instrument that breaches the rule, for rules grouped by instrument.", "Breach", "Reference (Instrument, 17)", "", "", "Internal", "", ""),
       ("Breached Group Key", "Sector, country or other group that breaches the rule, for rules grouped by a classification.", "Breach", "Text", "", "", "Internal", "", ""),
       ("Breached Restriction", "Primary 01 investment restriction the breached rule implements; blank when the primary source is a client restriction or only a regulatory provision.", "Breach", "Reference (Restriction)", "", "RST-55012", "Internal", "", "Y", "Typed pair with Breached Client Restriction: at most one is filled (the primary source from Rule Source Link). Other sources of the same rule are Breached Source Restriction rows. Master of 12 Breach Notification.Breached Restriction (CD-222)."),
       ("Breached Client Restriction", "Primary 02 client restriction the breached rule implements, when that is the primary source.", "Breach", "Reference (Client Restriction)", "", "", "Internal", "", "", "Client confidential. Proposed to 12 as a second Derived copy column (proposals_33)."),
       ("Originating Alert", "Alert from which the breach was confirmed.", "Breach", "Reference (Compliance Alert, 33)", "", "CALERT-2026-0041877", "Internal", "", ""),
       ("Originating Manual Check", "Manual compliance check that found the breach, when it was not found by the engine.", "Breach", "Reference (Manual Compliance Check, 33)", "", "", "Internal", "", ""),
       ("Breach Type", "Whether the breach was caused by the firm's action, by market movement or other external events, or is technical only.", "Breach", "Code", "Shared: Breach Type", "Passive", "Internal", "", "Y", "Values as 12 Breach Type. Technical = the limit was breached in the book of record because of a data or coding error and is recorded as a breach under the breach policy; an alert caused by bad data with no breach in the book of record is dispositioned as Data Issue instead. Master of 12 Breach Notification.Breach Type (CD-222)."),
       ("Breach Cause", "Event that caused the breach.", "Breach", "Code", "Breach Cause", "Credit Rating Change", "Internal", "", ""),
       ("Breach Start Date", "Date the portfolio first fell outside the limit.", "Breach", "Date", "ISO 8601", "2026-09-13", "Internal", "", "Y"),
       ("Breach Detected Date", "Date the breach was detected.", "Breach", "Date", "ISO 8601", "2026-09-14", "Internal", "", "Y", "Master of 12 Breach Notification.Breach Detected Date (CD-222)."),
       ("Breach Severity", "Severity assigned under the breach policy.", "Breach", "Code", "Shared: Severity", "Medium", "Internal", "", ""),
       ("Material Breach Indicator", "Whether the breach is material under the firm's breach materiality policy.", "Breach", "Boolean", "", "N", "SEC Rule 38a-1", "", "Y", "Material compliance matters are reported to the fund board (35) (SME question 5)."),
       ("Cure Deadline Date", "Date by which the breach must be cured under the source restriction, client agreement or policy.", "Breach", "Date", "ISO 8601", "2026-09-28", "SEC Rule 35d-1", "Internal", ""),
       ("Cure Action", "Action that brought the portfolio back within the limit, as reported to clients.", "Breach", "Code", "Shared: Cure Action", "Sell Down", "Internal", "", "Y", "Derived within 33: the type of the remediation action that completed the cure, or Self-Cured by Market where no action was needed. Values as 12 Cure Action. Master of 12 Breach Notification.Cure Action (CD-222)."),
       ("Cure Date", "Date the portfolio was back within the limit.", "Breach", "Date", "ISO 8601", "2026-09-16", "Internal", "", "Y", "Master of 12 Breach Notification.Cure Date (CD-222)."),
       ("Related Trade Error", "25 trade error that caused the breach; the loss is held on it.", "Breach", "Reference (Trade Error, 25)", "", "", "Internal", "", "", "When filled, no Breach Loss Calculation is made (one loss, one home)."),
       ("Related NAV Error Case", "27 NAV error case opened for the breach's effect on the NAV.", "Breach", "Reference (NAV Error Case, 27)", "", "", "Internal", "", ""),
       ("Breach Status", "Workflow status of the breach.", "Breach", "Code", "Shared: Case Status", "Closed", "Internal", "", ""),
       ("Breach Closure Date", "Date the breach was closed after review and sign-off.", "Breach", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
     ]),
     ("Breached Source Restriction", [
       ("Source Breach", "Breach the restriction row belongs to.", "Breach Source", "Reference (Investment Breach, 33)", "", "BREACH-2026-00143", "Internal", "", ""),
       ("Additional Breached Restriction", "Further 01 investment restriction implemented by the breached rule version, beyond the primary one on the breach.", "Breach Source", "Reference (Restriction)", "", "RST-55013", "Internal", "", "", "Typed pair: exactly one of the two restriction columns is filled per row. Copied within 33 from Rule Source Link."),
       ("Additional Breached Client Restriction", "Further 02 client restriction implemented by the breached rule version.", "Breach Source", "Reference (Client Restriction)", "", "", "Internal", "", "", "Client confidential."),
     ]),
   ]),
   ("Remediation", "Actions taken to cure the breach.", [
     ("Breach Remediation Action", [
       ("Remediated Breach", "Investment breach the action is taken to cure.", "Remediation", "Reference (Investment Breach, 33)", "", "BREACH-2026-00143", "Internal", "", ""),
       ("Remediation Action Sequence", "Order of the action within the breach.", "Remediation", "Integer", "", "1", "Internal", "", ""),
       ("Remediation Action Type", "Kind of action taken to cure the breach.", "Remediation", "Code", "Shared: Cure Action", "Sell Down", "Internal", "", "", "Valid values: Sell Down, Purchase, Client Waiver (obtaining one) and Guideline Amended (requesting one); Self-Cured by Market is not an action."),
       ("Remediation Action Description", "What is to be done.", "Remediation", "Text", "", "Sell 120,000 shares of issuer bonds over two sessions to bring weight below 9.5%", "Internal", "", ""),
       ("Remediation Action Owner", "Person responsible for the action.", "Remediation", "Reference (Employee)", "", "EMP-30188", "Internal", "", "", EMP),
       ("Remediation Due Date", "Date the action must be completed.", "Remediation", "Date", "ISO 8601", "2026-09-16", "Internal", "", ""),
       ("Remediation Completed Date", "Date the action was completed.", "Remediation", "Date", "ISO 8601", "2026-09-16", "Internal", "", "Y"),
       ("Implementing Trade Order", "25 trade order that carried out the action.", "Remediation", "Reference (Trade Order, 25)", "", "TORD-2026-00398120", "Internal", "", ""),
     ]),
   ]),
   ("Breach Losses", "Loss to the portfolio from a breach whose loss is not on a 25 Trade Error.", [
     ("Breach Loss Calculation", [
       ("Calculated Breach", "Breach the loss is calculated for.", "Loss Calculation", "Reference (Investment Breach, 33)", "", "BREACH-2026-00151", "Internal", "", ""),
       ("Loss Calculation Version", "Version of the calculation; a recalculation creates a new version.", "Loss Calculation", "Integer", "", "1", "Internal", "", ""),
       ("Loss Calculation Method", "Method used to measure the loss.", "Loss Calculation", "Code", "Loss Calculation Method", "Sell-Down Cost", "Internal", "", ""),
       ("Breach Loss Amount", "Loss to the portfolio caused by the breach; zero where the breach produced no loss or a gain.", "Loss Calculation", "Amount", "", "USD 18,240.00", "Internal", "", "Y"),
       ("Compensation Amount", "Amount paid to the portfolio to make it whole.", "Loss Calculation", "Amount", "", "USD 18,240.00", "Internal", "", ""),
       ("Compensating Entity", "Internal legal entity that pays the compensation, normally the adviser.", "Loss Calculation", "Reference (Legal Entity)", "", "LEN-0004", "Internal", "", "", "Where a third party pays (sub-adviser, insurer), record it in the review (SME question 6)."),
       ("Loss Calculation Approval Status", "Approval state of the calculation.", "Loss Calculation", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("Loss Calculation Approved By", "Officer who approved the calculation.", "Loss Calculation", "Reference (Employee)", "", "EMP-30544", "Internal", "", "", EMP),
     ]),
   ]),
   ("Breach Reviews", "Root cause, escalation decisions and sign-off of a breach. The regulator notification itself is a 35 Reportable Fund Event.", [
     ("Breach Review", [
       ("Reviewed Breach", "Investment breach the review covers.", "Breach Review", "Reference (Investment Breach, 33)", "", "BREACH-2026-00143", "Internal", "", ""),
       ("Breach Review Sequence", "Order of the review within the breach.", "Breach Review", "Integer", "", "1", "Internal", "", ""),
       ("Root Cause Description", "Underlying cause established by the review.", "Breach Review", "Text", "", "Rating downgrade feed arrived after the post-trade batch; rule tested stale rating", "Internal", "", ""),
       ("Control Improvement Actions", "Changes to rules, data or procedures agreed to prevent recurrence.", "Breach Review", "Text", "", "Rerun credit rules after the rating feed; coding request RCR 2026/0201", "Internal", "", ""),
       ("Regulatory Notification Required Indicator", "Whether the review concluded that the breach must be notified to a regulator, for example where an exemptive order or the banking regulator of a CIT's trustee requires it.", "Breach Review", "Boolean", "", "N", "Internal", "", "Y", "The notification (regulator, date, filing) is mastered by 35 Reportable Fund Event."),
       ("Resulting Reportable Fund Event", "35 reportable fund event opened to notify the regulator.", "Breach Review", "Reference (Reportable Fund Event, 35)", "", "", "Internal", "", ""),
       ("Board Reportable Indicator", "Whether the breach is reported to the fund board (or to the trustee of a CIT).", "Breach Review", "Boolean", "", "Y", "SEC Rule 38a-1", "", "", "Read by 35 board reporting (CD-225)."),
       ("CCO Sign-Off By", "Chief compliance officer or delegate who signed off the review.", "Breach Review", "Reference (Employee)", "", "EMP-30500", "SEC Rule 38a-1", "", "", EMP),
       ("CCO Sign-Off Date", "Date the chief compliance officer or delegate signed off the review.", "Breach Review", "Date", "ISO 8601", "2026-09-30", "SEC Rule 38a-1", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Waivers & Program Oversight", "IC-OVS",
  "Evidence of the compliance program around the rules: client or board approved exceptions to a rule for a portfolio with the relaxed limit held as data, periodic reviews of rules and libraries under Rule 38a-1, and manual checks of restrictions the engine cannot test.",
  [
   ("Guideline Waivers", "Approved, time-bound exceptions to a rule for a portfolio. The engine applies the waived limit in place of the rule limit while the waiver is in force.", [
     ("Guideline Waiver", [
       ("Guideline Waiver Reference", "Identifier of the waiver.", "Waiver", "Identifier", "", "GW 2026/0031", "Internal", "", "", "No enterprise prefix."),
       ("Waived Rule", "Rule the waiver relaxes or suspends.", "Waiver", "Reference (Compliance Rule, 33)", "", "CRULE-004588", "Internal", "", "Y"),
       ("Waived Portfolio", "Portfolio the waiver applies to.", "Waiver", "Reference (Portfolio, 18)", "", "PORT-000877", "Internal", "", "Y", SMAP),
       ("Waived Limit Value", "Limit that applies instead of the rule limit while the waiver is in force; blank when the rule is suspended outright.", "Waiver", "Decimal", "", "12", "Internal", "", "Y"),
       ("Waived Measurement Basis", "Measurement basis of the waived limit, normally the rule's own.", "Waiver", "Code", "Shared: Measurement Basis", "% of NAV", "Internal", "", ""),
       ("Waiver Scope Issuer", "Issuer the waiver is limited to; blank when it covers every issuer or group the rule tests.", "Waiver", "Reference (Party)", "", "PTY-030412", "Internal", "", ""),
       ("Waiver Basis", "Who granted the exception and on what basis.", "Waiver", "Code", "Waiver Basis", "Client Written Consent", "Internal", "", ""),
       ("Waiver Conditions", "Conditions attached to the waiver that are not captured as structured values.", "Waiver", "Text", "", "Applies during the transition period only; client to be informed monthly of the position", "Internal", "", "", CLIENT),
       ("Client Approver", "Client signatory who approved the waiver.", "Waiver", "Reference (Party)", "", "PTY-030419", "Internal", "", "", "PII where the approver is an individual."),
       ("Internal Approver", "Compliance officer who approved the waiver internally.", "Waiver", "Reference (Employee)", "", "EMP-30544", "Internal", "", "", EMP),
       ("Board Approval Date", "Date the fund board or trustee committee approved the waiver, for board-approved fund waivers; blank for client-approved waivers.", "Waiver", "Date", "ISO 8601", "2026-06-24", "Internal", "", "", "Derived copy (35): the meeting date of the 35 Board Resolution whose Resolution Subject Link names this waiver (subject type 'Guideline Waiver (33)'). The approval link is held only on 35 Resolution Subject Link; 33 holds no Board Resolution reference (CD-237, program lead ruling at the Stage 3 consolidation)."),
       ("Waiver Approval Status", "Approval state of the waiver.", "Waiver", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("Waiver Effective From", "Date the waiver took effect.", "Waiver", "Date", "ISO 8601", "2026-07-01", "Internal", "", "Y", DATECONV),
       ("Waiver Effective To", "Date the waiver expires.", "Waiver", "Date", "ISO 8601", "2026-12-31", "Internal", "", ""),
     ]),
   ]),
   ("Periodic Rule Reviews", "Reviews of rules and libraries for continued accuracy and adequacy.", [
     ("Periodic Rule Review", [
       ("Reviewed Rule", "Rule reviewed; blank when a whole library is reviewed.", "Rule Review", "Reference (Compliance Rule, 33)", "", "", "Internal", "", ""),
       ("Reviewed Rule Library", "Library reviewed; blank when a single rule is reviewed.", "Rule Review", "Reference (Rule Library, 33)", "", "1940 Act Diversified 75-5-10", "Internal", "", ""),
       ("Rule Review Date", "Date the review was completed.", "Rule Review", "Date", "ISO 8601", "2026-06-30", "SEC Rule 38a-1", "", ""),
       ("Annual Program Review Indicator", "Whether the review forms part of the Rule 38a-1 annual review of the compliance program.", "Rule Review", "Boolean", "", "Y", "SEC Rule 38a-1", "", ""),
       ("Rule Reviewer", "Compliance officer who performed the review.", "Rule Review", "Reference (Employee)", "", "EMP-30577", "SEC Rule 38a-1", "", "", EMP),
       ("Rule Review Outcome", "Conclusion of the review on whether the rule or library stays as coded.", "Rule Review", "Code", "Rule Review Outcome", "Change Requested", "Internal", "", ""),
       ("Changes Requested", "Changes to logic, parameters or assignments the review asked for.", "Rule Review", "Text", "", "Add look-through for money market fund holdings; retire legacy 10% cash rule", "Internal", "", ""),
       ("Resulting Coding Request", "Coding request raised to make the changes.", "Rule Review", "Reference (Rule Coding Request, 33)", "", "RCR 2026/0144", "Internal", "", ""),
     ]),
   ]),
   ("Manual Compliance Checks", "Attested checks of restrictions that are not coded or only partly coded.", [
     ("Manual Compliance Check", [
       ("Checked Investment Restriction", "Investment restriction checked by hand (owned by 01).", "Manual Check", "Reference (Restriction)", "", "RST-55031", "Internal", "", "Y"),
       ("Checked Client Restriction", "Client restriction checked by hand (owned by 02).", "Manual Check", "Reference (Client Restriction)", "", "", "Internal", "", "", "Client confidential."),
       ("Checked Portfolio", "Portfolio whose 18 Portfolio Holdings or activity were checked against the restriction.", "Manual Check", "Reference (Portfolio, 18)", "", "PORT-000412", "Internal", "", "", SMAP),
       ("Check Period Start Date", "First day of the period the check covers.", "Manual Check", "Date", "ISO 8601", "2026-07-01", "Internal", "", ""),
       ("Check Period End Date", "Last day of the period the check covers.", "Manual Check", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
       ("Manual Check Result", "Outcome of the manual check.", "Manual Check", "Code", "Compliance Rule Result Status", "Pass", "Internal", "", "Y", "Read by 12 Compliance Certificate."),
       ("Exception Description", "Exceptions to the restriction found by the check, if any; a breach found is linked from the breach (Originating Manual Check).", "Manual Check", "Text", "", "", "Internal", "", ""),
       ("Attested By", "Employee who performed and attested the check.", "Manual Check", "Reference (Employee)", "", "EMP-30577", "SEC Rule 38a-1", "", "", EMP),
       ("Attestation Timestamp", "Moment the attestation was recorded.", "Manual Check", "Timestamp", "ISO 8601", "2026-10-03T15:20:00-04:00", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 # Copies of 01 lists (values unchanged; shared lists deferred, stage3_consolidation_notes §2)
 "Regulatory Regime": ("openfunds / Internal (01 Regulatory Regime values, US re-cut of CW-039, plus one proposed addition)", [("US 1940 Act Registered",""),("US Private Fund 3(c)(1)",""),("US Private Fund 3(c)(7)",""),("US Bank CIT","OCC 12 CFR 9.18 / state banking regulation"),("ERISA Plan Assets","Proposed addition: vehicle holding ERISA plan assets (CIT, plan-asset institutional separate account or private fund)")]),
 # New in 33
 "Rule Type": ("Internal (aligned to common compliance engine rule categories; one type per rule, the more specific type wins: Firm Restricted List over List Membership, List Membership and Risk Measure Limit over Concentration and Eligibility)", [("Concentration","Exposure to an issuer, counterparty, sector, country or group as a share of the portfolio (including OTC counterparty exposure read from 31)"),("Eligibility","Only permitted asset or instrument types may be held, or a type is barred (prohibition is expressed by Rule Limit Type Prohibition)"),("List Membership","Tests holdings or orders against a Rule Instrument List (approved, prohibited, client exclusion, ERISA, ESG)"),("Firm Restricted List","Blocks trading in names on the 38 restricted list (CD-224); takes precedence over List Membership"),("Ratio","Relation of two portfolio quantities (e.g. asset coverage, 80% names policy)"),("Quantity","Holding as a share of the issuer's outstanding securities or voting stock"),("Maturity","Weighted average maturity or life, or maximum final maturity"),("Credit Quality","Minimum rating or internal credit assessment"),("Liquidity","Daily or weekly liquid asset minimums (Rule 2a-7); not the Rule 22e-4 program (31)"),("Risk Measure Limit","Coded restriction that tests a 31 measure, e.g. a prospectus cap on Rule 18f-4 derivatives exposure (CD-223)"),("Transaction Test","Tests a transaction type, e.g. Rule 17a-7 cross or Rule 10f-3 purchase conditions")]),
 "Rule Applicability": ("Internal", [("Pre-Trade Only",""),("Post-Trade Only",""),("Pre- and Post-Trade","")]),
 "Rule Source Type": ("Internal", [("Investment Restriction","01 RST-: prospectus, SAI, fund document or mandate guideline"),("Client Restriction","02 CRX-: client exclusion or instruction"),("Regulatory Limit Provision","Statutory limit coded directly"),("Firm Policy","Internal policy or buffer with no external source")]),
 "Assignment Basis": ("Internal", [("Fund Regime","Applies because of the vehicle's regulatory regime"),("Fund Document","Prospectus, SAI or fund agreement"),("Mandate","Investment management agreement guideline"),("Client Instruction","Client restriction"),("Firm Policy","House rule applied to all portfolios in scope")]),
 "Rule Instrument List Type": ("Internal", [("Approved Issuers","Issuers approved for purchase, e.g. Rule 2a-7 eligible names"),("Prohibited Issuers","Issuers that may not be bought"),("Client Exclusion","Client-supplied exclusion list (02)"),("ERISA Party-in-Interest Issuers","Issuers related to plan clients (ERISA Section 406); sourced from 02 if 02 maintains the list (SME question 10)"),("Securities-Related Issuers","Brokers, dealers, underwriters and investment advisers (ICA Section 12(d)(3), Rule 12d3-1)"),("Affiliated Issuers","Affiliates for Section 17 and Rule 10f-3 tests"),("Firm Restricted List Feed","Read from the 38 restricted list; no members held here (CD-224)"),("ESG Exclusion Feed","Read from a 34 Sustainability Exclusion List; no members held here"),("Eligible Counterparties","Counterparties a rule permits")]),
 "Restriction Coding Status": ("Internal", [("Coded","Fully tested by one or more rules"),("Partially Coded","Some elements tested; the rest checked manually"),("Manual Monitoring","Not coded; checked by Manual Compliance Check"),("Not Testable","Cannot be tested against portfolio data, e.g. a process obligation"),("Pending Coding","Coding request open")]),
 "Coding Request Trigger": ("Internal", [("New Fund or Mandate",""),("IMA Amendment",""),("Prospectus or SAI Change","Often a 36 product change"),("New Client Restriction",""),("Regulatory Change",""),("Breach Review Finding",""),("Periodic Rule Review Finding",""),("Data Model Change","New data field or vendor source"),("Other","")]),
 "Compliance Check Run Type": ("Internal (a run is recorded even when no rule applies, giving Not Checked)", [("Pre-Trade","Order, block or proposed trade before release"),("Intraday","Portfolios during the day including executions"),("Post-Trade Batch","End-of-day or start-of-day test of holdings"),("What-If","Hypothetical trades or rebalances, not recorded as pre-trade evidence")]),
 "Check Run Trigger": ("Internal", [("Order Entry",""),("Order Amendment",""),("Block Creation",""),("Rebalance Proposal",""),("Scheduled Batch",""),("Rule Change","Rerun after a new rule version"),("Holdings Correction",""),("User Request","")]),
 "Compliance Rule Result Status": ("Internal", [("Pass",""),("Warning","Past the warning level, within the limit"),("Fail","Outside the limit"),("Not Evaluated","Rule could not be evaluated, e.g. missing data"),("Not Applicable","Rule does not apply to the subject")]),
 "Alert Disposition Outcome": ("Internal", [("False Positive","Rule logic flagged a compliant position"),("Data Issue","Caused by bad or late data with no breach in the book of record; 21 DQI- raised (a breach recorded in the book of record because of a data error is a Technical breach)"),("Approved Exception","Covered by an override or guideline waiver"),("Resolved Before Execution","Order canceled or amended before release"),("Confirmed Breach","Investment breach opened (linked from the breach as Originating Alert)"),("Duplicate","Same condition already alerted")]),
 "Override Reason": ("Internal", [("Trade Reduces Existing Breach",""),("Data or Pricing Issue","Failure caused by data known to be wrong"),("Covered by Guideline Waiver",""),("Cash Flow Timing","Pending subscription or redemption cures the position"),("Corporate Action Pending",""),("Rule Coding Error",""),("Other","Explain in justification")]),
 "Breach Cause": ("Internal", [("Trade Error","See 25 Trade Error"),("Pre-Trade Override",""),("Market Movement",""),("Corporate Action",""),("Credit Rating Change",""),("Subscription or Redemption Flow",""),("Index Rebalance",""),("Restriction Change",""),("Rule Coding Error",""),("Data Error",""),("Under Investigation","Cause not yet established at detection"),("Other","")]),
 "Loss Calculation Method": ("Internal", [("Sell-Down Cost","Difference between the cost of the breaching position and the proceeds of its sale"),("Compliant Portfolio Comparison","Performance of the actual versus a hypothetical compliant portfolio"),("Opportunity Cost","Return forgone on an amount that should have been invested"),("Other","Explain in the breach review")]),
 "Waiver Basis": ("Internal", [("Client Written Consent","Institutional client (IA line)"),("Board Approval","Fund board or CIT trustee"),("Regulatory Relief","Exemptive order or no-action position"),("Transition Period","Temporary exception during a portfolio transition"),("Other","")]),
 "Rule Review Outcome": ("Internal", [("No Change",""),("Change Requested",""),("Retire Rule",""),("Escalated","Referred to the CCO or committee")]),
 # The enterprise shared lists are cited as 'Shared: <name>' (registered direct user since the Stage 3 consolidation, CD-241); Compliance Check Outcome, Breach Type and Cure Action became shared lists stewarded by 33 (CD-242).
}

# ---------------------------------------------------------------------------
REL = [
 ("Rule Library (version)","contains, via Rule Library Membership,","Compliance Rule (version)","n : n","A library version is a dated set of rule versions; a rule may belong to several libraries."),
 ("Compliance Rule (version)","implements, via Rule Source Link,","Investment Restriction [01]","n : n","RST-; one restriction may become several rules (CD-221)."),
 ("Compliance Rule (version)","implements, via Rule Source Link,","Client Restriction [02]","n : n","CRX-; 15 Account Restrictions (ARX-) are never rule sources."),
 ("Compliance Rule (version)","implements, via Rule Source Link,","Regulatory Limit Provision","n : n","The provision is the master of statutory limit values."),
 ("Investment Restriction [01] (source Regulatory)","restates","Regulatory Limit Provision","n : 0..1","Proposed to 01 (proposals_33); 33 holds the statutory value once."),
 ("Rule Library (version) / Compliance Rule (version)","is assigned to","Portfolio [18] via Rule Assignment","n : n","Effective-dated; the assignment pins a library version or a rule version, never a bare rule."),
 ("Compliance Rule","reads","Rule Instrument List","n : n","Rule Instrument Lists Read."),
 ("Rule Instrument List (firm-maintained)","has","Rule Instrument List Member","1 : 0..n","Only when Members Held Here Indicator = Y."),
 ("Rule Instrument List (sourced)","reads members of","Sustainability Exclusion List [34] / Firm Restricted List [38]","n : 0..1","No members stored in 33 (CD-224, CD-225)."),
 ("Compliance Rule","may read","Portfolio Risk Measure / Leverage & Exposure Measurement / Counterparty Exposure [31]","n : n","Names the measure or method; risk-program limits stay 31 Risk Limits (CD-223). Aligned to 31's cardinality."),
 ("Compliance Rule","may read (logical; no attribute)","Internal Credit Assessment [23] / Credit Rating Assignment [17]","n : n","Credit quality and Rule 2a-7 eligibility rules; flagged by Internal Credit Assessment Used Indicator."),
 ("Rule Coding Request","may be triggered by","Product Change Initiative [36]","n : 0..1","Prospectus or limit changes (CD-225)."),
 ("Rule Coding Request","creates","Compliance Rule (version)","1 : 0..n","Held on the rule version as Originating Coding Request; none when the outcome is Manual Monitoring or Not Testable."),
 ("Restriction Coding Status","describes","Investment Restriction [01] / Client Restriction [02]","n : 1","Effective-dated; read by 12 Guideline Monitoring Arrangement."),
 ("Compliance Check Run","tests, via Pre-Trade Check Subject,","Proposed Trade [24] / Trade Order [25] / Block Order [25]","1 : 0..1","Pre-trade runs only."),
 ("Compliance Check Run (pre-trade)","has","Check Subject Member","1 : 0..n","One row per tested order: the order itself, or each member order of a block."),
 ("Trade Order Event [25]","copies the outcome of","Check Subject Member","n : 1","Latest run before release that covered the order (CD-180, CD-221)."),
 ("Compliance Check Run","produces","Compliance Rule Result","1 : 0..n","Run x portfolio x rule version x evaluated issuer, instrument or group."),
 ("Compliance Rule Result","evaluates","Portfolio [18] holdings","n : 1","Holdings as of the run's holdings timestamp."),
 ("Compliance Rule Result","may apply","Guideline Waiver","n : 0..1","The waived limit replaces the rule limit."),
 ("Compliance Rule Result","raises","Compliance Alert","1 : 0..1","Only failing, warning and unevaluated results."),
 ("Compliance Alert","has","Alert Disposition","1 : 0..n","A reopened alert keeps earlier dispositions."),
 ("Compliance Alert","has","Pre-Trade Override Approval","1 : 0..n","Hard-fail alerts on pre-trade runs; four-eyes evidence."),
 ("Pre-Trade Override Approval","releases","Check Subject Member","1 : 0..n",""),
 ("Alert Disposition","may reference","Data Quality Issue [21]","n : 0..1","Disposition outcome Data Issue."),
 ("Investment Breach","originates from","Compliance Alert / Manual Compliance Check","n : 0..1","The link is held once, on the breach."),
 ("Investment Breach","breaches","Compliance Rule (version)","n : 1","Per issuer, instrument or group for grouped rules."),
 ("Investment Breach","concerns","Investment Restriction [01] / Client Restriction [02]","n : n","Primary source on the breach; further sources as Breached Source Restriction rows."),
 ("Investment Breach","may be caused by","Trade Error [25]","n : 0..1","The loss stays on the 25 Trade Error (CD-222)."),
 ("Investment Breach","may have NAV impact recorded as","NAV Error Case [27]","n : 0..1",""),
 ("Investment Breach","has","Breach Remediation Action","1 : 0..n","Sell-downs are implemented by 25 Trade Orders."),
 ("Investment Breach","has","Breach Loss Calculation","1 : 0..n","Only where no 25 Trade Error holds the loss; versioned."),
 ("Investment Breach","has","Breach Review","1 : 0..n","Root cause, escalation decision, CCO sign-off."),
 ("Breach Review","may open","Reportable Fund Event [35]","1 : 0..1","35 masters the regulator notification."),
 ("Breach Notification [12]","reports","Investment Breach","n : 1","12 gains Related Investment Breach; five 12 attributes become Derived copies (CD-222)."),
 ("Board Report Received [35]","references","Investment Breach","n : n","CD-225."),
 ("Guideline Waiver","relaxes","Compliance Rule for a Portfolio [18]","n : 1","Approved by a client party (02) or by a fund board; the board approval is linked only from 35 Resolution Subject Link (CD-237)."),
 ("Periodic Rule Review","reviews","Compliance Rule / Rule Library","n : 1","Rule 38a-1 annual review."),
 ("Manual Compliance Check","evidences","Investment Restriction [01] / Client Restriction [02] for a Portfolio [18]","n : 1","Read by 12 Compliance Certificate."),
 ("Portfolio Construction Constraint [24]","is not","Compliance Rule","-","PM constraints are not rules and are not tested here (CD-221)."),
 ("RIC Test Result [27] / RIC Qualification Determination [35]","is monitored by (logical; no attribute)","Compliance Rule (RIC diversification)","1 : 0..n","33 rules monitor; the determination is not 33's (CD-224). 27 vs 35 ownership is a consolidation question."),
]

# ---------------------------------------------------------------------------
SRC = [
 ("Investment Company Act of 1940 Sections 2(a)(16), 5(b)(1), 12(d) and 18","US Congress / SEC","https://www.law.cornell.edu/uscode/text/15/80a-5","Statute (public)","Government security definition; diversified company 75-5-10 test; fund-of-funds (Section 12(d)(1)) and securities-related issuer limits; asset coverage and senior securities. Sections 2, 12 and 18 are at .../80a-2, .../80a-12 and .../80a-18.","Regulatory Limit Provision, Rule Type, Measurement Basis",["Investment Company Act Section*"]),
 ("SEC Rules 12d1-4 (fund of funds) and 12d3-1 (securities-related issuers)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270","Regulation (public)","Acquiring fund conditions and limits; limits on holdings of brokers, dealers, underwriters and investment advisers","Regulatory Limit Provision, Rule Instrument List Type (Securities-Related Issuers)",["SEC Rule 12d1-4", "SEC Rule 12d3-1"]),
 ("SEC Rule 35d-1 (Names Rule) and 2023 amendments; compliance dates extended on 14 March 2025 to 11 June 2026 (larger fund groups) and 11 December 2026 (smaller)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.35d-1","Regulation (public)","80% investment policy, temporary departures and the 90-day return to compliance","Rule Type (Ratio), Cure Deadline Date",["SEC Rule 35d-1"]),
 ("SEC Rule 2a-7 (money market funds), as amended 2023","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.2a-7","Regulation (public)","Issuer diversification, WAM and WAL, daily and weekly liquid asset minimums, minimal credit risk determinations","Rule Type (Maturity, Liquidity, Credit Quality), Internal Credit Assessment Used Indicator",["SEC Rule 2a-7"]),
 ("SEC Rule 38a-1, Advisers Act Rule 206(4)-7 and adopting release (Investment Company Act Release No. 26299, Compliance Programs of Investment Companies and Investment Advisers, 2003)","US SEC","https://www.sec.gov/rules-regulations/2003/12/compliance-programs-investment-companies-investment-advisers","Regulation (public)","Written compliance policies, annual review, CCO report to the board and material compliance matters","Periodic Rule Review, Breach Review, Material Breach Indicator, Version Approval Status",["SEC Rule 38a-1"]),
 ("Investment Company Act Rule 31a-2 (record retention)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.31a-2","Regulation (public)","Retention of fund compliance records, rule versions and test evidence","Rule Version, Version Effective From, Run Timestamp",["SEC Rule 31a-2"]),
 ("Advisers Act Rule 204-2 (books and records)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.204-2","Regulation (public)","Adviser record retention for institutional separate account and fund compliance evidence","Rule Version",["Advisers Act Rule 204-2"]),
 ("SEC Rules 17a-7 (cross trades) and 10f-3 (affiliated underwritings)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.17a-7","Regulation (public)","Transaction conditions that pre-trade rules may test; the records stay in 25. Rule 10f-3 is at .../section-270.10f-3.","Rule Type (Transaction Test), Rule Instrument List Type (Affiliated Issuers)",["SEC Rule 17a-7", "SEC Rule 10f-3"]),
 ("IRC Section 851(b)(3) (RIC asset diversification)","US Congress / IRS","https://www.law.cornell.edu/uscode/text/26/851","Statute (public)","Quarterly diversification tests that 33 rules monitor; the determination stays outside 33","Rule Type, Evidential Period-End Run Indicator",["IRC Section 851"]),
 ("ERISA Sections 404(a)(1)(C) and 406; DOL PTE 84-14 (QPAM exemption, amended 2024)","US DOL / EBSA","https://www.dol.gov/agencies/ebsa/laws-and-regulations/laws/erisa","Statute / exemption (public)","Diversification duty; prohibited transactions with parties in interest","Rule Instrument List Type (ERISA Party-in-Interest Issuers), Regulatory Regime (ERISA Plan Assets)",["ERISA"]),
 ("OCC 12 CFR 9.18 (collective investment funds)","US OCC","https://www.ecfr.gov/current/title-12/chapter-I/part-9/section-9.18","Regulation (public)","CIT plan and investment limits (paragraph to confirm per fund)","Regulatory Limit Provision",["OCC 12 CFR 9.18"]),
 ("Compliance engine vendor practice: Charles River IMS compliance, BlackRock Aladdin compliance, SimCorp compliance","Charles River Development; BlackRock; SimCorp","https://www.crd.com","Vendor documentation (licensed)","Rule, rule group, assignment, pre-trade and post-trade checks, alerts and overrides as commonly structured; field names not reproduced","Compliance Rule, Rule Library, Compliance Check Run, Compliance Alert",["Charles River IMS"]),
]
