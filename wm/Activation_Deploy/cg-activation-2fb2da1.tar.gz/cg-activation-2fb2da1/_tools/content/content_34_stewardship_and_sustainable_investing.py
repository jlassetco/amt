"""Data Domain 34 - Stewardship & Sustainable Investing. Content module for taxonomy_builder.py."""

META = {
 "title": "Stewardship & Sustainable Investing Data Taxonomy",
 "subtitle": "Business domain 34 - Stewardship & Sustainable Investing | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "34_Stewardship_and_Sustainable_Investing/Stewardship_and_Sustainable_Investing_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the stewardship and sustainable investment record of a US wealth manager that votes and engages, as an institutional shareholder and bondholder, on behalf of its own mutual funds, ETFs and CITs, the institutional separate accounts it manages for the institutional advisory line and any other client account that delegates voting authority to it. It defines how the firm decides to vote (voting policies and guidelines, the policies it offers its fund shareholders as options of an investor choice proxy voting program, and who holds voting authority for each portfolio or account), how it votes each investee meeting (agenda items, proxy advisor recommendations, ballots per safekeeping account, vote instructions and their rationale, and decisions to recall lent shares), how it engages investee companies (engagement cases, objectives and milestones, interactions, escalation and collaborative initiatives), how it turns vendor and company-reported sustainability data into its own view (indicator definitions, issuer sustainability and ESG rating observations, firm ESG assessments and exclusion lists), and what it discloses (portfolio climate metrics, financed emissions and climate targets, Form N-PX voting reports, client voting reports and stewardship reports). It is stewarded by the investment stewardship team. The firm is regulated and distributes in the US only: SFDR classifications, principal adverse impacts, EU Taxonomy alignment, UK SDR, the UK Stewardship Code and the EU Shareholder Rights Directive were removed under CW-934 and are listed in the jurisdiction register; foreign investee companies, meetings and markets stay because the firm's funds hold them. Stitched together from SEC Form N-PX and Rules 30b1-4, 14Ad-1 and 206(4)-6, SEC Schedule 13D and 13G guidance, DOL 29 CFR 2550.404a-1, IFRS S2, the PCAF Global GHG Accounting and Reporting Standard, the GHG Protocol, the PRI Reporting Framework and the ICGN Global Stewardship Principles. Use it as a starting point for a stewardship data model, a voting and engagement platform mapping, an ESG data warehouse design or a business glossary."),
  ("Scope", "In scope: voting policies and voting guidelines, including the policies offered as investor choice options to fund shareholders; voting authority arrangements per portfolio or client account (institutional separate accounts of the IA line and other accounts that delegate voting); investee meeting agenda items (keyed to the 17 corporate action event of the meeting), proxy advisor recommendations, ballots per meeting and safekeeping account, vote decisions and rationale, and vote instructions; decisions to recall lent securities for a vote; engagements, engagement objectives, interactions and escalation actions; collaborative initiative memberships; sustainability indicator definitions, issuer sustainability observations, ESG rating observations, firm ESG assessments, sustainability exclusion lists and their members; portfolio sustainability metrics (climate and other indicators in one vocabulary); financed emissions holding detail and climate targets; proxy voting reports (including client account voting reports), stewardship reports and engagements reported. Out of scope (referenced by ID): ESG fund characteristics, products, share classes and investment restrictions (01 Investment Product & Service Offering); issuers, proxy advisors, initiatives and client exclusion lists (02 Client & Household); fund shareholder proxy campaigns, proposals and vote tallies of the firm's own funds, and each fund shareholder's investor choice election (13 Client Service & Communications); client report presentation (12); licensed ESG and proxy datasets (14); fund-level vendor sustainability ratings (11); instruments, issuer profiles, sustainable bond labels and meeting events (17); fund and institutional portfolios and their portfolio holdings (18); prices (22); issuer meetings (23); investment decisions (24); safekeeping accounts, entitlements and securities loans (28); legal entities and geography (09); employees (20); climate stress scenarios (31); coded compliance rules (33); Form N-PX filing and board approval of voting policies (35); product change initiatives (36)."),
  ("Structure", "Four levels: Domain > Subdomain > Concept > Attribute."),
  ("Core model", "Voting Policy (VPOL-) holds Voting Guidelines by guideline code; a policy offered in the investor choice program carries its Voting Choice Option Type and the own funds whose shareholders may choose it (each shareholder's election is 13's). Every portfolio (PORT-, 18) or client account (ACC-, 15: an institutional separate account of the IA line or another account that delegates voting) has an effective-dated Voting Authority Arrangement naming who holds voting authority and which policy applies. The meeting itself is a 17 Corporate Action Event (CAE-), or a 13 Proxy Campaign when it is a meeting of an own fund; 34 adds Investee Meeting Agenda Items, Proxy Advisor Recommendations licensed through 14, and one Ballot per meeting and 28 Safekeeping Account (SKA-). The firm's decision on each item under a policy is a Vote Rationale; each Vote Instruction (VOTE-) records the vote cast on one item of one ballot and implements a rationale. A Lending Recall Decision records whether lent shares (28 SBL-) were recalled. An Engagement (ENGM-) is a case with an engaged party (PTY-), Engagement Objectives, Engagement Interactions (which reference a 23 Issuer Meeting, IMTG-, rather than repeat it) and Escalation Actions. Sustainability Indicator Definitions are typed by level (issuer, portfolio, entity) with a unit per level. Vendor and company-reported issuer values are Issuer Sustainability Observations and ESG Rating Observations from a 14 dataset; the firm's view is the Firm ESG Assessment (ESGA-) and the Sustainability Exclusion List. Portfolio, product and entity values are Portfolio Sustainability Metrics, held once in one vocabulary and tagged with the frameworks they serve (TCFD / ISSB, NZAM, internal monitoring). Financed Emissions Holding Detail holds the PCAF attribution behind a metric; Climate Targets track metrics. Proxy Voting Reports and Stewardship Reports are the disclosed content; 35 files reports through its filing document rows and 12 presents them to clients."),
  ("Design principles", "1) Investee votes here, fund shareholder votes in 13: 'proxy' is always qualified. 2) The meeting is a 17 event, never a 34 object; meeting dates are read from 17. 3) Vote cast is held once, on the Vote Instruction; the decision and rationale once per item and policy. A meeting of an own fund is a 13 Proxy Campaign, and 13's Mirror / Echo tally is never repeated. 4) An engagement is a case, not a meeting: interactions that were issuer meetings reference 23 and repeat none of its facts. 5) One indicator vocabulary, typed by level: issuer values are observations, portfolio and entity values are metrics held once and tagged by framework. Observed vendor data is never overwritten and always names its source dataset and data basis; the firm's view is a separate, dated, approved assessment. 6) ESG fund characteristics and commitments stay in 01; 34 holds the data and metrics behind them. 7) Content in 34, filing in 35, presentation in 12. 8) Loans and recall execution stay in 28; 34 holds only the decision to recall. 9) Effective-date authority, assessments, exclusion list members and memberships. 10) Investor choice: 34 holds the policies offered and the funds they are offered for; the fund shareholder's choice is 13's. 11) Flag personal data (PII) on employees, named issuer contacts and individual clients who delegate voting authority, and Critical Data Elements (CDE)."),
  ("Applies To", "Shows the record each attribute belongs to: Voting Policy, Voting Guideline, Voting Authority, Agenda Item, Advisor Recommendation, Ballot, Vote Instruction, Vote Rationale, Recall Decision, Engagement, Engagement Objective, Engagement Interaction, Escalation Action, Initiative Membership, Indicator Definition, Sustainability Observation, ESG Rating Observation, ESG Assessment, Exclusion List, Exclusion List Member, Sustainability Metric, Financed Emissions Detail, Climate Target, Proxy Voting Report, Stewardship Report or Reported Engagement."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify a vote, ballot or engagement, to report a vote correctly on Form N-PX (vote cast, shares voted, shares on loan not recalled, proposal category, for or against management), to evidence engagement status, or to calculate and disclose climate metrics and financed emissions. Confirm with the stewardship team, Fund Administration (N-PX) and Compliance."),
  ("Primary / Secondary Reference", "Standard, rule or source the attribute definition is aligned to. 'Internal' = firm-defined. Vendor references (ISS, Glass Lewis, MSCI, Sustainalytics, Broadridge) indicate common industry structure, not a license to reproduce vendor record layouts."),
  ("Notes", "PII = personal information under US privacy law (Regulation S-P for client information, and state privacy laws): employee references (stewardship analysts, decision makers, approvers), named issuer contacts in engagement interactions, individual shareholder proponents and individual clients holding or delegating voting authority. Engagement records may contain material non-public information and carry an information classification. Scope is the US wealth manager: SFDR, EU Taxonomy, UK SDR, UK Stewardship Code and SRD II content was removed under CW-934 (jurisdiction register); index exclusion criteria of the indexes the funds track (for example Paris-aligned benchmark exclusions) stay as index methodology. Climate metrics follow IFRS S2, PCAF and the GHG Protocol voluntarily: no SEC climate disclosure rule is in force, and California SB 253 / SB 261 are a tailoring lever."),
  ("Tabs", "Hierarchy | Taxonomy | Code Lists | Relationships | Sources."),
  ("Suggested next steps", "1) Validate families, CDEs and code lists with the stewardship team, Fund Administration (N-PX), Investment Compliance (33), Risk (31) and the fund boards' counsel (35). 2) Map voting objects to the voting platform and proxy advisor feeds (meeting, agenda, ballot and vote records) and the custodian ballot distribution. 3) Ask 17 to add the meeting event types (including Court Meeting) and a meeting date (CD-226; a blocker for complete N-PX content) and 02 to add the proxy advisor, proxy voting agent and collaborative initiative role types (CD-143). 4) Agree the recall materiality rule with 28 and securities lending. 5) Agree with 33 how coded rules reference 34 exclusion lists, and with 31 who owns climate scenarios. 6) Agree with 13 (W2) how a fund shareholder's investor choice election references the Voting Policy options offered here, and how the votes the choices direct are tallied. 7) Done at the Stage 3 consolidation (CD-241): 34 cites the enterprise shared lists directly."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Stewardship Policies", "ST-POL",
  "The rules the firm votes by and who may vote: voting policies and their guidelines by issue category and market, the policies offered to fund shareholders as investor choice options, and for each portfolio or client account (an institutional separate account or another account that delegates voting) the effective-dated arrangement that says who holds voting authority and which policy applies. Board approval of a voting policy is held once, on 35 Resolution Subject Link.",
  [
   ("Voting Policies & Guidelines", "Versioned voting policies (house, adopted benchmark, client-specific, ESG overlay), the investor choice options among them, and the default position each takes on an issue category in a market.", [
     ("Voting Policy", [
       ("Voting Policy ID", "Unique identifier of the voting policy version.", "Voting Policy", "Identifier", "", "VPOL-HOUSE-2026", "Internal", "SEC Rule 206(4)-6", "Y"),
       ("Voting Policy Name", "Name under which the policy is published and referred to.", "Voting Policy", "Text", "", "Global Proxy Voting Guidelines", "SEC Rule 206(4)-6", "", ""),
       ("Voting Policy Type", "Whether the policy is the house policy, a proxy advisor benchmark policy adopted as is, a client's own policy or an ESG overlay.", "Voting Policy", "Code", "Voting Policy Type", "House", "Internal", "SEC Rule 206(4)-6", ""),
       ("Benchmark Proxy Advisor", "Proxy advisor whose benchmark policy is adopted or used as the starting point; blank for a fully custom policy.", "Voting Policy", "Reference (Party)", "", "PTY-1004410", "SEC Rule 206(4)-6", "", ""),
       ("Adopted Benchmark Policy Name", "Name and year of the advisor's benchmark or specialty policy adopted.", "Voting Policy", "Text", "", "ISS Sustainability Policy 2026", "Internal", "", ""),
       ("Policy Client", "Client whose own voting policy this is, for client-specific policies.", "Voting Policy", "Reference (Party)", "", "PTY-100221", "Internal", "", "", "PII when the client is an individual."),
       ("Policy Approval Status", "Approval state of the policy version within the firm; fund board approval is recorded by 35 on Resolution Subject Link.", "Voting Policy", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("Policy Approved By", "Chair of the stewardship committee or officer who approved the version.", "Voting Policy", "Reference (Employee)", "", "EMP-30588", "Internal", "", "", "PII (employee)."),
       ("Policy Effective From", "Date the policy version starts to apply to votes.", "Voting Policy", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Policy Effective To", "Date the policy version stopped applying.", "Voting Policy", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Policy Document Location", "Location of the published policy, including its conflicts of interest procedures.", "Voting Policy", "Text", "URI", "https://www.example.com/stewardship/voting-guidelines-2026.pdf", "SEC Rule 206(4)-6", "", ""),
       ("Voting Choice Option Type", "Kind of option the policy is when the firm offers it to fund shareholders in its investor choice (pass-through) proxy voting program; blank for a policy not offered as a choice.", "Voting Policy", "Code", "Voting Choice Option Type", "Board-Aligned", "Internal", "", "", "Added in W1b (plan section 5.1 row 34; CW-934)."),
       ("Voting Choice Offered Funds", "Own funds whose shareholders may choose the policy for the shares attributable to them under the investor choice program; each shareholder's election is held in 13.", "Voting Policy", "Reference (Product) (multi)", "", "PRD-00431; PRD-00432", "Internal", "", "", "Added in W1b (plan section 5.1 row 34; CW-934). The election and its effective dates are 13 (W2)."),
     ]),
     ("Voting Guideline", [
       ("Guideline Policy", "Policy version the guideline belongs to.", "Voting Guideline", "Reference (Voting Policy, 34)", "", "VPOL-HOUSE-2026", "Internal", "", ""),
       ("Guideline Code", "Firm code of the guideline within the policy version.", "Voting Guideline", "Identifier", "Firm-defined", "G2.3 US", "Internal", "", ""),
       ("Guideline Proposal Category", "Form N-PX proposal category the guideline covers.", "Voting Guideline", "Code", "Proposal Category", "Director elections", "SEC Form N-PX", "", ""),
       ("Guideline Issue", "Specific issue within the category the guideline addresses.", "Voting Guideline", "Text", "", "Board independence below two-thirds at a US large-cap company", "Internal", "", ""),
       ("Guideline Market", "Market or market group the guideline applies to.", "Voting Guideline", "Reference (Geographic Unit)", "", "GEO-US", "Internal", "", ""),
       ("Default Voting Position", "Position the guideline prescribes unless a case-by-case review decides otherwise.", "Voting Guideline", "Code", "Voting Position", "Against", "Internal", "ISS Benchmark Policy", ""),
       ("Guideline Rationale", "Why the firm takes this position.", "Voting Guideline", "Text", "", "Independent oversight of management requires a majority of independent directors.", "Internal", "ICGN Global Stewardship Principles", ""),
     ]),
   ]),
   ("Voting Authority", "Who holds the right to vote the securities of each portfolio or client account, and under which policy, over time.", [
     ("Voting Authority Arrangement", [
       ("Authority Portfolio", "Portfolio whose 18 Portfolio Holdings the arrangement covers; blank when the arrangement is set for a client account only.", "Voting Authority", "Reference (Portfolio)", "", "PORT-000412", "Internal", "", "Y"),
       ("Authority Account", "Client account the arrangement covers, where authority is set per account: an institutional separate account of the IA line, or another client account that delegates voting authority to the firm.", "Voting Authority", "Reference (Account)", "", "ACC-0091877", "Internal", "", "", "PII when the account is held by an individual."),
       ("Voting Authority Holder", "Who holds voting authority: the firm, the client, the CIT trustee, or fund shareholders through pass-through (investor choice) voting.", "Voting Authority", "Code", "Voting Authority Holder", "Firm", "SEC Rule 14Ad-1", "DOL 29 CFR 2550.404a-1", "Y"),
       ("Authority Holder Party", "External client or trustee bank that holds or delegates voting authority, where it is not the firm.", "Voting Authority", "Reference (Party)", "", "PTY-100912", "Internal", "", "", "PII when the client is an individual."),
       ("Trustee Legal Entity", "Firm trust company that holds voting authority as CIT trustee, where the trustee is the firm's own entity.", "Voting Authority", "Reference (Legal Entity)", "", "", "DOL 29 CFR 2550.404a-1", "", ""),
       ("Exercising Legal Entity", "Firm adviser entity that exercises voting authority, where the firm holds it or the trustee delegates it.", "Voting Authority", "Reference (Legal Entity)", "", "LEN-0004", "SEC Rule 206(4)-6", "", ""),
       ("Applied Voting Policy", "Voting policy version applied to votes under the arrangement.", "Voting Authority", "Reference (Voting Policy, 34)", "", "VPOL-HOUSE-2026", "SEC Rule 206(4)-6", "", "Y"),
       ("Voting Platform Provider", "Proxy voting agent that receives ballots and transmits instructions for the portfolio or account.", "Voting Authority", "Reference (Party)", "", "PTY-1004422", "Internal", "", ""),
       ("Authority Effective From", "Date the arrangement took effect.", "Voting Authority", "Date", "ISO 8601", "2026-01-01", "Internal", "", ""),
       ("Authority Effective To", "Date the arrangement ended, for example when a client took back voting authority.", "Voting Authority", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Investee Meetings & Votes", "ST-VTG",
  "How the firm votes at meetings of the companies and funds its portfolios hold: the agenda items of each meeting (a 17 corporate action event), proxy advisor recommendations, one ballot per meeting and safekeeping account, the firm's vote decision and rationale on each item, the vote instructed on each ballot, and decisions to recall lent shares so they can be voted. A meeting of one of the firm's own funds is a 13 Proxy Campaign; 34 records a ballot only where an own portfolio holds that fund.",
  [
   ("Agenda & Recommendations", "The matters put to a vote at an investee meeting and what licensed proxy advisors recommend on each.", [
     ("Investee Meeting Agenda Item", [
       ("Agenda Meeting", "Investee meeting the item is put to; the meeting, its record date and meeting date are a 17 corporate action event.", "Agenda Item", "Reference (Corporate Action Event, 17)", "", "CAE-2026-0012345", "SEC Form N-PX", "ISO 20022 seev.001", "Y"),
       ("Agenda Item Number", "Item number as printed on the issuer's form of proxy or notice of meeting.", "Agenda Item", "Text", "", "4a", "SEC Form N-PX", "ISO 20022 seev.001", "Y"),
       ("Proposal Text", "Description of the matter in the language of the issuer's form of proxy.", "Agenda Item", "Text", "", "Advisory vote to ratify named executive officers' compensation", "SEC Form N-PX", "", ""),
       ("Proposal Category", "Form N-PX categories the matter falls in; more than one may apply.", "Agenda Item", "Code (multi)", "Proposal Category", "Section 14A say-on-pay votes; Compensation", "SEC Form N-PX", "SEC Rule 14Ad-1", "Y", "A matter categorized 'Section 14A say-on-pay votes' is in scope of manager reporting under Rule 14Ad-1."),
       ("Agenda Item Proponent", "Who put the matter on the agenda.", "Agenda Item", "Code", "Agenda Item Proponent", "Management", "SEC Form N-PX", "", ""),
       ("Proponent Party", "Shareholder or dissident who proposed the matter, where not management; the firm's own filings are shown by Escalation Action.", "Agenda Item", "Reference (Party)", "", "", "Internal", "", "", "PII when the proponent is an individual."),
       ("Management Recommendation", "How the issuer's board recommends shareholders vote.", "Agenda Item", "Code", "Management Recommendation", "For", "SEC Form N-PX", "", "Y"),
     ]),
     ("Proxy Advisor Recommendation", [
       ("Recommended Agenda Item", "Agenda item the recommendation applies to.", "Advisor Recommendation", "Reference (Investee Meeting Agenda Item, 34)", "", "CAE-2026-0012345 / 4a", "Internal", "", ""),
       ("Proxy Advisor", "Proxy advisor that issued the recommendation.", "Advisor Recommendation", "Reference (Party)", "", "PTY-1004410", "SEC Rule 14a-1(l)", "", "Y"),
       ("Advisor Policy", "Benchmark or specialty policy of the advisor under which the recommendation was made, as coded by the advisor.", "Advisor Recommendation", "Code", "External (Vendor)", "ISS US Benchmark", "Internal", "", ""),
       ("Advisor Recommended Vote", "Vote the advisor recommends; the advisor's view, never the firm's decision.", "Advisor Recommendation", "Code", "Vote Cast", "Against", "Internal", "", ""),
       ("Recommendation Source Dataset", "Licensed proxy research dataset the recommendation arrived in.", "Advisor Recommendation", "Reference (Dataset)", "", "DSET-00413", "Internal", "", ""),
       ("Recommendation Revised Indicator", "Whether the advisor revised the recommendation after first publication, for example after an issuer response.", "Advisor Recommendation", "Boolean", "", "N", "SEC Rule 14a-2(b)(9)", "", ""),
     ]),
   ]),
   ("Ballots & Votes", "One ballot per meeting and safekeeping account, the firm's vote decision and rationale per agenda item and policy, and the vote instructed on each item of each ballot.", [
     ("Ballot", [
       ("Ballot Meeting", "Investee meeting the ballot is for; blank for a meeting of an own fund, which is a 13 Proxy Campaign.", "Ballot", "Reference (Corporate Action Event, 17)", "", "CAE-2026-0012345", "ISO 20022 seev.001", "", "Y"),
       ("Own Fund Proxy Campaign", "13 proxy campaign of an own fund, where an own portfolio (for example a fund of funds) holds that fund as a shareholder; 13's Mirror / Echo vote tally is not repeated here.", "Ballot", "Reference (Proxy Campaign)", "", "", "Investment Company Act 1940 Section 12(d)(1)", "", ""),
       ("Ballot Safekeeping Account", "Safekeeping account whose holding on the record date the ballot represents; the portfolio is read from the 28 safekeeping account assignment.", "Ballot", "Reference (Safekeeping Account, 28)", "", "SKA-000231", "ISO 20022 seev.001", "", "Y", "PII when the safekeeping account belongs to an individual client."),
       ("Governing Voting Authority", "Voting authority arrangement in effect for the portfolio on the meeting date.", "Ballot", "Reference (Voting Authority Arrangement, 34)", "", "PORT-000412 / 2026-01-01", "Internal", "", ""),
       ("Ballot Control Number", "Control number the ballot distributor or custodian assigns to the ballot.", "Ballot", "Identifier", "", "7781-4410-2290-1184", "Broadridge ProxyEdge", "ISO 20022 seev.001", ""),
       ("Ballot Entitlement", "28 corporate action entitlement of the account for the meeting; source of Record Date Shares.", "Ballot", "Reference (Corporate Action Entitlement, 28)", "", "CAEN-2026-0045120", "Internal", "", ""),
       ("Record Date Shares", "Shares held in the account on the record date, including shares then on loan; equals shares voted plus shares not voted plus shares on loan not recalled.", "Ballot", "Decimal", "", "185000", "SEC Form N-PX", "ISO 20022 seev.001", "Y", "Derived copy (28). Row rule: the Eligible Balance of the referenced 28 Corporate Action Entitlement; where no entitlement exists (own-fund meetings), the 18 portfolio holding quantity on the record date."),
       ("Shares on Loan Not Recalled", "Shares out on loan on the record date that were not recalled and so could not be voted.", "Ballot", "Decimal", "", "20000", "SEC Form N-PX", "", "Y", "Derived copy (28). Row rule: quantity of the meeting instrument lent from the account under 28 Securities Loans that was on loan at the record date and not returned before it. Needs a dated on-loan quantity in 28 (requested in proposals_34); the 34 recall decision is not an input."),
       ("Vote Deadline Timestamp", "Latest time the voting agent accepts instructions for the ballot.", "Ballot", "Timestamp", "ISO 8601", "2026-05-12T23:59:00-04:00", "ISO 20022 seev.001", "", ""),
       ("Share Blocking Indicator", "Whether voting blocks the shares from trading until the meeting, as some markets require.", "Ballot", "Boolean", "", "N", "ISO 20022 seev.001", "", ""),
       ("Ballot Status", "Workflow status of the ballot; whether each item was voted is read from its vote instructions.", "Ballot", "Code", "Ballot Status", "Instructed", "Internal", "", ""),
     ]),
     ("Vote Rationale", [
       ("Rationale Agenda Item", "Investee agenda item the decision is for.", "Vote Rationale", "Reference (Investee Meeting Agenda Item, 34)", "", "CAE-2026-0012345 / 4a", "Internal", "", "Y"),
       ("Rationale Fund Proxy Proposal", "13 proxy proposal the decision is for, for meetings of own funds.", "Vote Rationale", "Reference (Proxy Proposal)", "", "", "Internal", "", ""),
       ("Rationale Voting Policy", "Voting policy version applied in making the decision.", "Vote Rationale", "Reference (Voting Policy, 34)", "", "VPOL-HOUSE-2026", "SEC Rule 206(4)-6", "", ""),
       ("Vote Rationale Text", "Reason for the firm's vote decision on the item under the policy.", "Vote Rationale", "Text", "", "Pay outcomes not aligned with three-year relative TSR; engagement on metrics unsuccessful.", "Internal", "SEC Rule 206(4)-6", ""),
       ("Pre-Declared Vote Indicator", "Whether the firm announced its vote publicly before the meeting.", "Vote Rationale", "Boolean", "", "N", "Internal", "", ""),
       ("Linked Engagement", "Engagement the decision supports or escalates.", "Vote Rationale", "Reference (Engagement, 34)", "", "ENGM-2026-00318", "Internal", "", ""),
       ("Override Approved By", "Employee who approved a decision against the policy's default position.", "Vote Rationale", "Reference (Employee)", "", "EMP-30588", "Internal", "", "", "PII (employee)."),
     ]),
     ("Vote Instruction", [
       ("Vote Instruction ID", "Unique identifier of the vote instruction.", "Vote Instruction", "Identifier", "", "VOTE-2026-00412873", "Internal", "", "Y"),
       ("Voted Ballot", "Ballot the instruction is given on.", "Vote Instruction", "Reference (Ballot, 34)", "", "CAE-2026-0012345 / SKA-000231", "Internal", "", "Y"),
       ("Voted Agenda Item", "Investee agenda item the instruction votes on.", "Vote Instruction", "Reference (Investee Meeting Agenda Item, 34)", "", "CAE-2026-0012345 / 4a", "SEC Form N-PX", "", "Y"),
       ("Voted Fund Proxy Proposal", "13 proxy proposal the instruction votes on, for meetings of own funds.", "Vote Instruction", "Reference (Proxy Proposal)", "", "", "SEC Form N-PX", "", ""),
       ("Applied Vote Rationale", "Vote decision and rationale the instruction implements.", "Vote Instruction", "Reference (Vote Rationale, 34)", "", "CAE-2026-0012345 / 4a / VPOL-HOUSE-2026", "Internal", "", ""),
       ("Vote Cast", "How the shares were voted on the item.", "Vote Instruction", "Code", "Vote Cast", "Against", "SEC Form N-PX", "ISO 20022 seev.004", "Y", "The fact of record for the vote cast; ballots, rationale and reports do not repeat it."),
       ("Shares Voted", "Number of shares instructed to be voted on the item, as Form N-PX reports them; whether the issuer recorded them is shown by Vote Confirmation Status.", "Vote Instruction", "Decimal", "", "165000", "SEC Form N-PX", "", "Y"),
       ("Against Management Indicator", "Whether the vote was against management's recommendation.", "Vote Instruction", "Boolean", "", "Y", "SEC Form N-PX", "", "Y", "Computed from Vote Cast and Management Recommendation; held because Form N-PX reports it."),
       ("Against Policy Indicator", "Whether the vote departed from the default position of the applied voting guideline.", "Vote Instruction", "Boolean", "", "N", "SEC Rule 206(4)-6", "", ""),
       ("Vote Decision Source", "Who or what decided the vote: the policy default, a stewardship analyst, a portfolio manager override, a committee or a client direction.", "Vote Instruction", "Code", "Vote Decision Source", "Stewardship Analyst Case-by-Case", "Internal", "", ""),
       ("Vote Decision Maker", "Employee who decided the vote.", "Vote Instruction", "Reference (Employee)", "", "EMP-30412", "SEC Rule 206(4)-6", "", "", "PII (employee)."),
       ("Instructed Timestamp", "When the instruction was submitted to the voting agent.", "Vote Instruction", "Timestamp", "ISO 8601", "2026-05-08T15:40:00-04:00", "Internal", "ISO 20022 seev.004", ""),
       ("Vote Confirmation Status", "How far the vote has been confirmed along the chain from voting agent to issuer.", "Vote Instruction", "Code", "Vote Confirmation Status", "Confirmed - Recorded by Issuer", "Internal", "ISO 20022 seev.007", ""),
     ]),
   ]),
   ("Securities Lending Recall", "The stewardship decision whether to recall lent shares so they can be voted; the recall itself and the loan are 28's.", [
     ("Lending Recall Decision", [
       ("Recall Meeting", "Meeting the recall decision is made for.", "Recall Decision", "Reference (Corporate Action Event, 17)", "", "CAE-2026-0012345", "Internal", "", ""),
       ("Recall Securities Loan", "Loan the decision applies to.", "Recall Decision", "Reference (Securities Loan, 28)", "", "SBL-2026-0119822", "Internal", "", "Y"),
       ("Recall Decided Indicator", "Whether the firm decided to recall the shares for the vote.", "Recall Decision", "Boolean", "", "Y", "SEC Form N-PX", "", "Y"),
       ("Materiality Assessment", "Why the vote was or was not judged material enough to recall.", "Recall Decision", "Text", "", "Contested director election at a top-10 holding.", "Internal", "", ""),
       ("Recall Decision Maker", "Employee who decided whether to recall the loaned shares.", "Recall Decision", "Reference (Employee)", "", "EMP-30412", "Internal", "", "", "PII (employee)."),
       ("Recall Requested Date", "Date the stewardship team asked the agent lender to recall; the date the agent recalled from the borrower is 28 Securities Loan.Recall Date.", "Recall Decision", "Date", "ISO 8601", "2026-04-02", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Engagement", "ST-ENG",
  "Engagement with investee companies, issuers and market participants as a case with an objective: its objectives and milestones, the interactions held (referencing 23 issuer meetings rather than repeating them), escalation steps, and the collaborative initiatives the firm belongs to. Engagement that may go beyond passive investment is flagged for the Schedule 13D / 13G review (SEC guidance).",
  [
   ("Engagement Cases", "The engagement case and the objectives it pursues.", [
     ("Engagement", [
       ("Engagement ID", "Unique identifier of the engagement case.", "Engagement", "Identifier", "", "ENGM-2026-00318", "Internal", "", "Y"),
       ("Engaged Party", "Issuer, or for market-wide and policy engagement the regulator, standard setter or index provider engaged.", "Engagement", "Reference (Party)", "", "PTY-7001234", "Internal", "", "Y"),
       ("Engagement Theme", "Environmental, social or governance themes the engagement seeks to influence.", "Engagement", "Code (multi)", "Engagement Theme", "Climate Change; Executive Remuneration", "PRI Reporting Framework", "", ""),
       ("Engagement Headline", "One-line headline of the case; the measurable objectives are Engagement Objectives.", "Engagement", "Text", "", "Net zero transition plan", "Internal", "", ""),
       ("Engagement Lead", "Employee who leads the case.", "Engagement", "Reference (Employee)", "", "EMP-30412", "Internal", "", "", "PII (employee)."),
       ("Engagement Start Date", "Date the case was opened.", "Engagement", "Date", "ISO 8601", "2026-02-10", "Internal", "", ""),
       ("Engagement Status", "Workflow status of the case; the result is held separately as Engagement Outcome.", "Engagement", "Code", "Shared: Case Status", "In Progress", "Internal", "", "Y"),
       ("Engagement Outcome", "Result of the engagement against its objectives.", "Engagement", "Code", "Engagement Outcome", "Not Yet Determined", "Internal", "", "Y"),
       ("Collaborative Initiative", "Initiative under which a collaborative engagement is run; blank for engagement by the firm alone.", "Engagement", "Reference (Party)", "", "PTY-1009031", "PRI Reporting Framework", "", ""),
       ("Passive Status Review Indicator", "Whether the engagement may go beyond what a passive investor may do, so that Schedule 13G eligibility must be reviewed.", "Engagement", "Boolean", "", "N", "SEC Schedule 13G", "SEC C&DI 103.12", "", "Flag only; the filing determination is 38 Ownership Disclosure Determination (CD-251)."),
       ("Engagement Information Classification", "Information handling class of the case, including whether it holds material non-public information.", "Engagement", "Code", "Shared: Information Classification", "Confidential", "Internal", "ISO/IEC 27001", ""),
     ]),
     ("Engagement Objective", [
       ("Objective Engagement", "Engagement the objective belongs to.", "Engagement Objective", "Reference (Engagement, 34)", "", "ENGM-2026-00318", "Internal", "", ""),
       ("Objective Sequence", "Order of the objective within the engagement; with the engagement it forms the key.", "Engagement Objective", "Integer", "", "1", "Internal", "", ""),
       ("Objective Description", "Specific, measurable change the firm asks the issuer to make.", "Engagement Objective", "Text", "", "Publish SBTi-validated 2030 Scope 1 and 2 target.", "Internal", "", ""),
       ("Engagement Milestone Stage", "Stage the issuer has reached toward the objective.", "Engagement Objective", "Code", "Engagement Milestone Stage", "Issuer Acknowledged", "Internal", "", ""),
       ("Objective Target Date", "Date by which the objective should be met.", "Engagement Objective", "Date", "ISO 8601", "2027-06-30", "Internal", "", ""),
       ("Objective Achieved Date", "Date the objective was assessed as met.", "Engagement Objective", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Interactions & Escalation", "Each contact with the engaged party in the course of the engagement, and the escalation steps taken when engagement does not succeed.", [
     ("Engagement Interaction", [
       ("Interaction ID", "Firm-defined identifier of the interaction: engagement ID and interaction number.", "Engagement Interaction", "Identifier", "Firm-defined", "ENGM-2026-00318 #03", "Internal", "", "Y"),
       ("Interaction Engagement", "Engagement the interaction belongs to.", "Engagement Interaction", "Reference (Engagement, 34)", "", "ENGM-2026-00318", "Internal", "", ""),
       ("Contact Medium", "Medium of the contact; whether a 23 meeting record exists is shown by Interaction Issuer Meeting.", "Engagement Interaction", "Code", "Engagement Contact Medium", "Meeting or Call", "PRI Reporting Framework", "", ""),
       ("Interaction Issuer Meeting", "23 issuer meeting record of the interaction, when one exists; its date, participants and topics are read from 23.", "Engagement Interaction", "Reference (Issuer Meeting)", "", "IMTG-0012874", "Internal", "", ""),
       ("Interaction Date", "Date of the interaction; blank when an issuer meeting is referenced.", "Engagement Interaction", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Interaction Employee", "Employee who conducted the interaction; blank when an issuer meeting is referenced.", "Engagement Interaction", "Reference (Employee)", "", "", "Internal", "", "", "PII (employee)."),
       ("Issuer Contact", "Named individual at the engaged party who was contacted; blank when an issuer meeting is referenced.", "Engagement Interaction", "Reference (Party)", "", "", "Internal", "", "", "PII."),
       ("Discussed Objective", "Engagement objective the interaction advanced.", "Engagement Interaction", "Reference (Engagement Objective, 34)", "", "ENGM-2026-00318 / 1", "Internal", "", ""),
       ("Interaction Summary", "What was raised and the engaged party's response.", "Engagement Interaction", "Text", "", "Board chair confirmed target work under way; committed to disclosure timeline.", "Internal", "", "", "May contain MNPI and names of issuer executives (PII)."),
     ]),
     ("Escalation Action", [
       ("Escalated Engagement", "Engagement whose lack of progress the action responds to.", "Escalation Action", "Reference (Engagement, 34)", "", "ENGM-2026-00318", "Internal", "", ""),
       ("Escalation Sequence", "Order of the action within the engagement; with the engagement it forms the key.", "Escalation Action", "Integer", "", "1", "Internal", "", ""),
       ("Escalation Action Type", "Form of escalation used when engagement alone has not achieved the objective.", "Escalation Action", "Code", "Escalation Action Type", "Vote Against Director", "ICGN Global Stewardship Principles", "", "Y"),
       ("Escalation Date", "Date the action was taken.", "Escalation Action", "Date", "ISO 8601", "2026-05-08", "Internal", "", ""),
       ("Escalation Approver", "Employee who approved the escalation.", "Escalation Action", "Reference (Employee)", "", "EMP-30588", "Internal", "", "", "PII (employee)."),
       ("Escalation Agenda Item", "Agenda item voted against, or shareholder proposal filed or co-filed, as the escalation; every ballot's instruction on it follows the Vote Rationale.", "Escalation Action", "Reference (Investee Meeting Agenda Item, 34)", "", "CAE-2026-0012345 / 4a", "Internal", "", ""),
       ("Resulting Investment Decision", "Investment decision that acted on a divestment recommendation.", "Escalation Action", "Reference (Investment Decision)", "", "IDEC-2026-0088412", "Internal", "", ""),
     ]),
   ]),
   ("Collaborative Initiatives", "The firm's memberships of investor initiatives and networks, by firm legal entity and period. Signatory or member status of an initiative (for example PRI) is the membership itself.", [
     ("Collaborative Initiative Membership", [
       ("Membership Initiative", "Initiative or investor network joined.", "Initiative Membership", "Reference (Party)", "", "PTY-1009031", "Internal", "", ""),
       ("Member Legal Entity", "Firm legal entity that is the member or signatory.", "Initiative Membership", "Reference (Legal Entity)", "", "LEN-0004", "Internal", "", ""),
       ("Membership Effective From", "Date the firm entity joined or signed the initiative.", "Initiative Membership", "Date", "ISO 8601", "2019-04-01", "Internal", "", ""),
       ("Membership Effective To", "Date the firm entity left the initiative.", "Initiative Membership", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Membership Status", "Whether the membership is current.", "Initiative Membership", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("ESG Data & Assessments", "ST-ESG",
  "Sustainability data about issuers and instruments as observed from vendors and company reports, and the firm's own view: indicator definitions at issuer, portfolio and entity level, issuer sustainability and ESG rating observations, firm ESG assessments and sustainability exclusion lists.",
  [
   ("Indicators & Observations", "What is measured, at which level and in which unit, and the values vendors and companies report, kept as dated observations from a named source and never overwritten.", [
     ("Sustainability Indicator Definition", [
       ("Indicator Code", "Firm code of the sustainability indicator; issuer-level and portfolio-level measures have separate codes.", "Indicator Definition", "Identifier", "Firm-defined", "GHG_SCOPE1", "Internal", "", "Y"),
       ("Indicator Version", "Version of the definition; together with the code it forms the key.", "Indicator Definition", "Integer", "", "2", "Internal", "", ""),
       ("Indicator Name", "Business name of the indicator as used in disclosures.", "Indicator Definition", "Text", "", "Scope 1 GHG emissions", "Internal", "", ""),
       ("Indicator Description", "What the indicator measures and how it is computed or sourced.", "Indicator Definition", "Text", "", "Direct greenhouse gas emissions from sources owned or controlled by the company, in tonnes CO2e.", "GHG Protocol", "IFRS S2", ""),
       ("Indicator Level", "Whether the indicator measures an issuer, a portfolio or product aggregate, or a firm legal entity aggregate.", "Indicator Definition", "Code", "Indicator Level", "Issuer", "Internal", "PCAF Standard Part A", "Y"),
       ("Indicator Unit", "Unit of measure of values at the indicator's level, for example tCO2e for an issuer, tCO2e per USD million invested for a portfolio carbon footprint.", "Indicator Definition", "Reference (Unit of Measure, 09)", "", "tCO2e", "Internal", "GHG Protocol", "Y"),
       ("Input Indicator", "Issuer-level indicator a portfolio or entity indicator aggregates.", "Indicator Definition", "Reference (Sustainability Indicator Definition, 34)", "", "", "PCAF Standard Part A", "", ""),
       ("Sustainability Indicator Scope", "GHG Protocol scope the indicator covers, for emissions indicators.", "Indicator Definition", "Code", "Sustainability Indicator Scope", "Scope 1", "GHG Protocol", "", ""),
     ]),
     ("Issuer Sustainability Observation", [
       ("Observation Key", "System-assigned surrogate key of the observation.", "Sustainability Observation", "Identifier", "", "7700412881", "Internal", "", ""),
       ("Observed Issuer", "Issuer the value describes.", "Sustainability Observation", "Reference (Party)", "", "PTY-7001234", "Internal", "", "Y"),
       ("Observed Instrument", "Instrument the value describes, for instrument-level indicators such as use-of-proceeds bond metrics.", "Sustainability Observation", "Reference (Instrument)", "", "", "Internal", "", ""),
       ("Observed Indicator", "Issuer-level indicator the value is for.", "Sustainability Observation", "Reference (Sustainability Indicator Definition, 34)", "", "GHG_SCOPE1 / 2", "Internal", "", "Y"),
       ("Reporting Period End Date", "Last day of the company reporting period the value relates to.", "Sustainability Observation", "Date", "ISO 8601", "2025-12-31", "Internal", "", "Y"),
       ("Observed Value", "Value as normalized into the indicator unit.", "Sustainability Observation", "Decimal", "", "1284500", "Internal", "", "Y"),
       ("Observation Data Basis", "Whether the value was reported by the company, estimated or modeled.", "Sustainability Observation", "Code", "Shared: Data Basis", "Reported / Actual", "PCAF Standard Part A", "", "Y"),
       ("Observation Source Dataset", "Licensed dataset the value arrived in; the vendor is identified through it.", "Sustainability Observation", "Reference (Dataset)", "", "DSET-00412", "Internal", "", "Y"),
       ("Originating Provider", "Organization through which the value was originally collected from the company, where it differs from the dataset vendor, such as a disclosure platform whose data a vendor redistributes.", "Sustainability Observation", "Code", "Shared: Data Provider", "CDP", "Internal", "", "", "CDP was added to the shared Data Provider list at the Stage 3 consolidation (CD-241)."),
       ("Observation As-Of Date", "Date the source published or delivered the value.", "Sustainability Observation", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
     ]),
     ("ESG Rating Observation", [
       ("Rated Issuer", "Issuer the vendor rating is for.", "ESG Rating Observation", "Reference (Party)", "", "PTY-7001234", "Internal", "", "Y"),
       ("Rating Source Dataset", "Licensed ESG ratings dataset the rating arrived in.", "ESG Rating Observation", "Reference (Dataset)", "", "DSET-00077", "Internal", "", "Y"),
       ("ESG Rating Type", "Kind of vendor assessment the observation holds, such as an overall rating, a risk score or a controversy level.", "ESG Rating Observation", "Code", "ESG Rating Type", "ESG Rating", "Internal", "", ""),
       ("ESG Rating Value", "Rating, score, category or flag exactly as published by the vendor, including vendor controversy levels.", "ESG Rating Observation", "Text", "External (Vendor)", "AA", "Internal", "", "Y"),
       ("ESG Rating Numeric Score", "Vendor's numeric score underlying the rating, where published.", "ESG Rating Observation", "Decimal", "", "7.4", "Internal", "", ""),
       ("Rating As-Of Date", "Date the rating was assigned or last confirmed by the vendor.", "ESG Rating Observation", "Date", "ISO 8601", "2026-08-14", "Internal", "", "Y"),
     ]),
   ]),
   ("Firm Assessments", "The firm's own dated, approved view of an issuer's sustainability profile.", [
     ("Firm ESG Assessment", [
       ("ESG Assessment ID", "Unique identifier of the assessment version.", "ESG Assessment", "Identifier", "", "ESGA-0004512", "Internal", "", "Y"),
       ("Assessed Issuer", "Issuer whose sustainability profile the firm assessed.", "ESG Assessment", "Reference (Party)", "", "PTY-7001234", "Internal", "", ""),
       ("Assessment Strategy", "Investment strategy the assessment is made for, where scores are set per strategy; blank for a firm-wide assessment.", "ESG Assessment", "Reference (Strategy)", "", "", "Internal", "", ""),
       ("Assessment Date", "Date the assessment was made.", "ESG Assessment", "Date", "ISO 8601", "2026-09-18", "Internal", "", ""),
       ("Firm ESG Score", "Firm's overall ESG score for the issuer.", "ESG Assessment", "Decimal", "Firm-defined (0-10 scale)", "6.5", "Internal", "", "Y"),
       ("Environmental Pillar Score", "Firm score for how well the issuer manages environmental risks and impacts.", "ESG Assessment", "Decimal", "Firm-defined (0-10 scale)", "5.8", "Internal", "", ""),
       ("Social Pillar Score", "Firm score for how well the issuer manages social risks, such as labor, human rights and product safety.", "ESG Assessment", "Decimal", "Firm-defined (0-10 scale)", "7.1", "Internal", "", ""),
       ("Governance Pillar Score", "Firm score for the quality of the issuer's board, pay, audit and shareholder rights practices.", "ESG Assessment", "Decimal", "Firm-defined (0-10 scale)", "6.9", "Internal", "", ""),
       ("Firm Controversy View", "Firm's judgment of the severity of the issuer's controversies.", "ESG Assessment", "Code", "Shared: Severity", "Low", "Internal", "", ""),
       ("Assessing Analyst", "Analyst who made the assessment.", "ESG Assessment", "Reference (Employee)", "", "EMP-30412", "Internal", "", "", "PII (employee)."),
       ("Assessment Approval Status", "Approval state of the assessment.", "ESG Assessment", "Code", "Shared: Approval Status", "Approved", "Internal", "", "Y"),
       ("Assessment Effective To", "Date after which the assessment no longer applies; blank while current.", "ESG Assessment", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Assessment Methodology Name", "Scoring methodology used, as registered (with its version) in the 37 model inventory.", "ESG Assessment", "Reference (Model Inventory Entry, 37)", "", "MODEL-0302", "Internal", "", "", "Re-typed from text at the Stage 4 consolidation (CD-246); name unchanged."),
     ]),
   ]),
   ("Exclusions", "The firm's own sustainability exclusion lists and their effective-dated members; client-supplied lists stay in 02 and coded rules in 33.", [
     ("Sustainability Exclusion List", [
       ("Exclusion List Code", "Firm code of the list.", "Exclusion List", "Identifier", "Firm-defined", "TCOAL", "Internal", "", "Y"),
       ("Exclusion List Version", "Version of the list's policy definition (basis and threshold); together with the code it forms the key.", "Exclusion List", "Integer", "", "3", "Internal", "", "Y"),
       ("Exclusion List Name", "Business name of the list as used in policies and fund documents.", "Exclusion List", "Text", "", "Thermal Coal Exclusion List", "Internal", "", ""),
       ("Exclusion Policy Basis", "Policy or standard the list implements; one basis per list.", "Exclusion List", "Code", "Exclusion Policy Basis", "Thermal Coal", "Internal", "EU BMR Delegated Regulation (EU) 2020/1818", "Y"),
       ("Revenue Threshold Percentage", "Revenue share above which an issuer is excluded, for revenue-based lists.", "Exclusion List", "Percentage", "", "1%", "Internal", "", ""),
       ("List Approval Status", "Approval state of the list version.", "Exclusion List", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("List Approved By", "Employee who approved the list version.", "Exclusion List", "Reference (Employee)", "", "EMP-30588", "Internal", "", "", "PII (employee)."),
       ("List Effective From", "Date the list version applies from.", "Exclusion List", "Date", "ISO 8601", "2026-07-01", "Internal", "", ""),
     ]),
     ("Exclusion List Member", [
       ("Member List", "List the member belongs to (list code); members are effective-dated across list versions.", "Exclusion List Member", "Reference (Sustainability Exclusion List, 34)", "", "TCOAL", "Internal", "", "Y"),
       ("Excluded Issuer", "Issuer whose securities portfolios applying the list may not hold.", "Exclusion List Member", "Reference (Party)", "", "PTY-7006120", "Internal", "", "Y"),
       ("Excluded Instrument", "Instrument on the list, where the list works at instrument level or an instrument is carved back in.", "Exclusion List Member", "Reference (Instrument)", "", "", "Internal", "", ""),
       ("Member Inclusion Type", "Exclude for a listed issuer or instrument; Include for an instrument carved back in (for example a green bond of an excluded issuer).", "Exclusion List Member", "Code", "Shared: Inclusion Type", "Exclude", "Internal", "", "Y"),
       ("Measured Revenue Percentage", "Revenue share the firm measured against the threshold.", "Exclusion List Member", "Percentage", "", "14.2%", "Internal", "", "", "The firm's figure; the source value is the Supporting Observation."),
       ("Supporting Observation", "Sustainability observation that evidenced the breach.", "Exclusion List Member", "Reference (Issuer Sustainability Observation, 34)", "", "7700419920", "Internal", "", ""),
       ("Member Effective From", "Date the member was added.", "Exclusion List Member", "Date", "ISO 8601", "2026-07-01", "Internal", "", ""),
       ("Member Effective To", "Date the member was removed.", "Exclusion List Member", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Portfolio Sustainability Metrics & Product Outcomes", "ST-PAI",
  "Portfolio, product and entity sustainability metrics held once in one vocabulary (financed emissions, carbon footprint, WACI, implied temperature rise and other indicators) and tagged with the frameworks they are reported under. The ESG characteristics and commitments of products are held in 01.",
  [
   ("Portfolio Sustainability Metrics", "One value per scope (portfolio, product or legal entity), period, indicator, emission scope and measurement basis, held once and reported under every framework it serves.", [
     ("Portfolio Sustainability Metric", [
       ("Metric Portfolio", "Portfolio the metric is measured for.", "Sustainability Metric", "Reference (Portfolio)", "", "PORT-000412", "IFRS S2", "", "Y"),
       ("Metric Product", "Product the metric is measured for, where measured at product level.", "Sustainability Metric", "Reference (Product)", "", "", "Internal", "", ""),
       ("Metric Legal Entity", "Firm legal entity the metric is measured for, for entity-level climate reports.", "Sustainability Metric", "Reference (Legal Entity)", "", "", "IFRS S2", "", ""),
       ("Metric Indicator", "Portfolio- or entity-level indicator measured; the single vocabulary for climate and other sustainability measures.", "Sustainability Metric", "Reference (Sustainability Indicator Definition, 34)", "", "CARBON_FOOTPRINT / 1", "Internal", "IFRS S2", "Y"),
       ("Metric Period End Date", "Measurement date for point-in-time values, or last day of the period for averaged values.", "Sustainability Metric", "Date", "ISO 8601", "2025-12-31", "IFRS S2", "", "Y"),
       ("Emission Scopes Included", "GHG scopes included, so that Scope 1+2 and Scope 1+2+3 values of the same indicator are separate rows.", "Sustainability Metric", "Code (multi)", "Sustainability Indicator Scope", "Scope 1; Scope 2 (Location-Based)", "GHG Protocol", "", "Y"),
       ("Metric Measurement Basis", "Whether the value is a point-in-time measure or an average over the period's valuation points.", "Sustainability Metric", "Code", "Metric Measurement Basis", "Average of Quarter-End Valuation Points", "Internal", "", "Y"),
       ("Metric Framework", "Frameworks the value is reported under; one value can serve several.", "Sustainability Metric", "Code (multi)", "Metric Framework", "TCFD / ISSB; NZAM Progress", "Internal", "", ""),
       ("Metric Calculation Standard", "Calculation standard the value follows.", "Sustainability Metric", "Code", "Metric Calculation Standard", "PCAF Part A", "PCAF Standard Part A", "", ""),
       ("Metric Value", "Calculated value in the metric unit.", "Sustainability Metric", "Decimal", "", "84.2", "IFRS S2", "", "Y"),
       ("Metric Unit", "Unit of the value, normally the indicator's portfolio-level unit.", "Sustainability Metric", "Reference (Unit of Measure, 09)", "", "tCO2e per USD million invested", "IFRS S2", "", ""),
       ("Normalization Currency", "Currency of the denominator of normalized metrics (per million invested or per million revenue).", "Sustainability Metric", "Code", "ISO 4217", "USD", "IFRS S2", "", ""),
       ("Metric Coverage Percentage", "Share of portfolio value covered by data.", "Sustainability Metric", "Percentage", "", "93%", "IFRS S2", "", "Y"),
       ("Metric Data Basis", "Overall basis of the data behind the value.", "Sustainability Metric", "Code", "Shared: Data Basis", "Mixed", "PCAF Standard Part A", "", "Y"),
       ("Weighted PCAF Data Quality Score", "Holding-weighted PCAF data quality score of the inputs, for emissions metrics.", "Sustainability Metric", "Decimal", "", "2.4", "PCAF Standard Part A", "", ""),
       ("Metric Model Name", "Model used for modeled metrics such as implied temperature rise, as registered in the 37 model inventory.", "Sustainability Metric", "Reference (Model Inventory Entry, 37)", "", "MODEL-0307", "Internal", "", "", "Re-typed from text at the Stage 4 consolidation (CD-246); name unchanged."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Financed Emissions & Climate Targets", "ST-CLI",
  "The holding-level attribution behind financed emissions metrics, and the climate targets the firm sets with their baselines and progress.",
  [
   ("Financed Emissions Attribution", "One row per holding behind a financed emissions metric, following PCAF.", [
     ("Financed Emissions Holding Detail", [
       ("Detail Holding", "Portfolio holding the attribution is for.", "Financed Emissions Detail", "Reference (Portfolio Holding)", "", "HLD-2026100500041201", "PCAF Standard Part A", "", "Y"),
       ("Detail Issuer", "Issuer whose emissions and EVIC are used; the holding's issuer, or its parent where PCAF requires consolidated figures, so it is held rather than derived.", "Financed Emissions Detail", "Reference (Party)", "", "PTY-7001234", "PCAF Standard Part A", "", ""),
       ("PCAF Asset Class", "PCAF asset class whose method is applied.", "Financed Emissions Detail", "Code", "PCAF Asset Class", "Listed Equity and Corporate Bonds", "PCAF Standard Part A", "", ""),
       ("Holding Value Used", "Outstanding amount of the portfolio holding (18) at the measurement date.", "Financed Emissions Detail", "Amount", "", "USD 18,450,000", "PCAF Standard Part A", "", "", "Derived copy (18): market value of the 18 portfolio holding at the measurement date."),
       ("Attribution Basis", "Denominator the attribution factor is computed on.", "Financed Emissions Detail", "Code", "Attribution Basis", "EVIC", "PCAF Standard Part A", "", ""),
       ("Attribution Denominator Value", "Value of the denominator (EVIC, equity plus debt, or PPP-adjusted GDP) used.", "Financed Emissions Detail", "Amount", "", "USD 42,300,000,000", "PCAF Standard Part A", "", "", "Derived copy; owner by row (Attribution Basis): EVIC of listed issuers from 22 pricing analytics (primary); EVIC supplied by a vendor from the 14 licensed dataset; Total Equity plus Debt of private companies held through 17 private market instruments from 22 fair value determinations; PPP-Adjusted GDP of sovereigns from a 14 licensed sovereign dataset, as PCAF prescribes."),
       ("Attribution Factor", "Share of the issuer's emissions attributed to the holding.", "Financed Emissions Detail", "Decimal", "", "0.000436", "PCAF Standard Part A", "", "Y"),
       ("Attributed Emissions", "Emissions attributed to the holding.", "Financed Emissions Detail", "Decimal", "", "560.1", "PCAF Standard Part A", "", "Y"),
       ("PCAF Data Quality Score", "PCAF data quality score of the emissions input.", "Financed Emissions Detail", "Code", "PCAF Data Quality Score", "2", "PCAF Standard Part A", "", "Y"),
       ("Source Observation", "Issuer sustainability observation that supplied the emissions input.", "Financed Emissions Detail", "Reference (Issuer Sustainability Observation, 34)", "", "7700412881", "Internal", "", ""),
     ]),
   ]),
   ("Climate Targets", "Targets the firm sets for itself, its entities or portfolios, with baseline, target year and progress.", [
     ("Climate Target", [
       ("Climate Target Code", "Firm code of the target.", "Climate Target", "Identifier", "Firm-defined", "NZAM2030-A", "Internal", "", "Y"),
       ("Climate Target Type", "Form of the target under the firm's net zero or climate commitment.", "Climate Target", "Code", "Climate Target Type", "Portfolio Decarbonization Reference Target", "NZAM Commitment", "IFRS S2", ""),
       ("Target Legal Entity", "Firm legal entity the target is set for, for entity-level targets.", "Climate Target", "Reference (Legal Entity)", "", "LEN-0004", "IFRS S2", "", ""),
       ("Target Portfolio", "Portfolio the target is set for, for portfolio-level targets.", "Climate Target", "Reference (Portfolio)", "", "", "Internal", "", ""),
       ("Target Indicator", "Portfolio-level indicator the target is expressed in.", "Climate Target", "Reference (Sustainability Indicator Definition, 34)", "", "CARBON_FOOTPRINT / 1", "IFRS S2", "", "Y"),
       ("Target Emission Scopes", "GHG scopes the target covers.", "Climate Target", "Code (multi)", "Sustainability Indicator Scope", "Scope 1; Scope 2 (Location-Based)", "IFRS S2", "", ""),
       ("Baseline Year", "Year whose metric value the target's reduction is measured from.", "Climate Target", "Integer", "", "2019", "IFRS S2", "", ""),
       ("Baseline Value", "Metric value in the baseline year.", "Climate Target", "Decimal", "", "112.4", "IFRS S2", "", ""),
       ("Target Year", "Year by which the target is to be met.", "Climate Target", "Integer", "", "2030", "IFRS S2", "", "Y"),
       ("Target Reduction Percentage", "Reduction from the baseline the target requires, for reduction targets.", "Climate Target", "Percentage", "", "50%", "IFRS S2", "", "Y"),
       ("AUM in Scope Percentage", "Share of assets under management covered by the target.", "Climate Target", "Percentage", "", "38%", "NZAM Commitment", "", ""),
       ("Latest Progress Metric", "Portfolio sustainability metric row that shows the latest progress; the value is read from it.", "Climate Target", "Reference (Portfolio Sustainability Metric, 34)", "", "PORT-000412 / 2025-12-31 / CARBON_FOOTPRINT / Scope 1+2 / Point in Time", "IFRS S2", "", ""),
       ("Target Progress Status", "Whether the target is on track.", "Climate Target", "Code", "Shared: RAG Status", "Amber", "Internal", "", ""),
       ("Target Set Date", "Date the target was adopted.", "Climate Target", "Date", "ISO 8601", "2021-11-01", "IFRS S2", "", ""),
       ("Target Status", "Whether the target is current or was withdrawn, for example after the NZAM relaunch.", "Climate Target", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Stewardship Disclosure & Reporting", "ST-DSC",
  "The stewardship content the firm discloses: proxy voting reports (Form N-PX fund and manager reports, client account voting reports) and stewardship reports (the firm's own stewardship report, PRI reporting, voluntary climate reports, NZAM progress reports) and the engagements each report features. Filing is 35's (its filing document rows reference the reports); client presentation is 12's.",
  [
   ("Voting Disclosures", "Voting record content per reporting person, report type and period.", [
     ("Proxy Voting Report", [
       ("Proxy Voting Report ID", "Firm-defined identifier of the report: period end year, report type and reporting person.", "Proxy Voting Report", "Identifier", "Firm-defined", "2026 NPX-FUND PRD-00431", "Internal", "", "Y"),
       ("Reporting Fund Series", "Registered fund series the report is for, for fund N-PX reports.", "Proxy Voting Report", "Reference (Product)", "", "PRD-00431", "SEC Form N-PX", "SEC Rule 30b1-4", "Y"),
       ("Reporting Manager Entity", "Firm adviser entity the report is for, for manager say-on-pay reports.", "Proxy Voting Report", "Reference (Legal Entity)", "", "", "SEC Rule 14Ad-1", "", ""),
       ("Reporting Client Account", "Client account the report is for, for client account voting reports (an institutional separate account or another account that delegates voting).", "Proxy Voting Report", "Reference (Account)", "", "", "Internal", "", "", "PII when the account is held by an individual."),
       ("Proxy Voting Report Type", "Regulation or purpose the voting report is prepared for.", "Proxy Voting Report", "Code", "Proxy Voting Report Type", "Form N-PX - Fund Report", "SEC Form N-PX", "", "Y"),
       ("Voting Report Period Start", "First day of the reporting period.", "Proxy Voting Report", "Date", "ISO 8601", "2025-07-01", "SEC Form N-PX", "", ""),
       ("Voting Report Period End", "Last day of the reporting period.", "Proxy Voting Report", "Date", "ISO 8601", "2026-06-30", "SEC Form N-PX", "", "Y"),
       ("No Votes Indicator", "Whether the report states that no votes were cast in the period.", "Proxy Voting Report", "Boolean", "", "N", "SEC Form N-PX", "", ""),
       ("Joint Report Indicator", "Whether the manager's say-on-pay votes are reported jointly with the funds' report.", "Proxy Voting Report", "Boolean", "", "N", "SEC Form N-PX", "SEC Rule 14Ad-1", ""),
       ("Voting Report Approval Status", "Approval state of the report content.", "Proxy Voting Report", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("Voting Report Approved By", "Employee who approved the content.", "Proxy Voting Report", "Reference (Employee)", "", "EMP-30588", "Internal", "", "", "PII (employee)."),
     ]),
   ]),
   ("Stewardship Reports & Status", "Stewardship and climate reports by framework, reporting entity and period, and the engagements they feature.", [
     ("Stewardship Report", [
       ("Stewardship Report ID", "Firm-defined identifier of the report: period end year, framework and reporting entity.", "Stewardship Report", "Identifier", "Firm-defined", "2025 STEW-ANNUAL LEN-0004", "Internal", "", "Y"),
       ("Stewardship Framework", "Framework or rule the report is prepared under.", "Stewardship Report", "Code", "Stewardship Framework", "Firm Stewardship Report", "Internal", "", "Y"),
       ("Stewardship Reporting Entity", "Firm legal entity the report is for.", "Stewardship Report", "Reference (Legal Entity)", "", "LEN-0004", "Internal", "", "Y"),
       ("Stewardship Report Product", "Product the report is for, for product-level reports (for example a fund's climate report).", "Stewardship Report", "Reference (Product)", "", "", "Internal", "", ""),
       ("Stewardship Report Period Start", "First day of the reporting period.", "Stewardship Report", "Date", "ISO 8601", "2025-01-01", "Internal", "", ""),
       ("Stewardship Report Period End", "Last day of the reporting period.", "Stewardship Report", "Date", "ISO 8601", "2025-12-31", "Internal", "", "Y"),
       ("Stewardship Report Approval Status", "Approval state of the report.", "Stewardship Report", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("Stewardship Report Approved By", "Employee who approved the report.", "Stewardship Report", "Reference (Employee)", "", "EMP-30588", "Internal", "", "", "PII (employee)."),
       ("Report Publication Location", "Where the report is published.", "Stewardship Report", "Text", "URI", "https://www.example.com/stewardship/report-2025.pdf", "Internal", "", ""),
       ("Framework Assessment Result", "Score or grade the framework body gave the report, where it grades reports (for example PRI module scores).", "Stewardship Report", "Text", "", "4 stars (Policy Governance and Strategy)", "PRI Reporting Framework", "", ""),
     ]),
     ("Reported Engagement", [
       ("Reported Engagement Case", "Engagement featured in the report.", "Reported Engagement", "Reference (Engagement, 34)", "", "ENGM-2026-00318", "Internal", "", ""),
       ("Case Study Indicator", "Whether the engagement is presented as a case study rather than counted in aggregate.", "Reported Engagement", "Boolean", "", "Y", "Internal", "", ""),
       ("Issuer Named Indicator", "Whether the engaged party is named in the published report.", "Reported Engagement", "Boolean", "", "Y", "Internal", "", ""),
       ("Report Section Reference", "Section of the report where the engagement appears.", "Reported Engagement", "Text", "", "Engagement case studies - Climate", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 # The enterprise shared lists are cited as 'Shared: <name>' (registered direct user since the Stage 3 consolidation, CD-241).

 # Stewardship policies and voting
 "Voting Policy Type": ("Internal / SEC Rule 206(4)-6", [("House","Policy written and maintained by the firm."),("Benchmark-Adopted","A proxy advisor's benchmark or specialty policy adopted as the firm's policy."),("Client-Specific","A client's own policy the firm votes by for that client's account."),("ESG Overlay","Policy that adds sustainability positions on top of a base policy.")]),
 "Voting Position": ("Internal", [("For",""),("Against",""),("Abstain",""),("Withhold","Director elections under plurality voting."),("Case-by-Case","No default; the item is reviewed on its merits. Who then decides is Vote Decision Source.")]),
 "Voting Authority Holder": ("Internal / SEC Rule 14Ad-1 / DOL 29 CFR 2550.404a-1", [("Firm","The firm holds and exercises voting authority."),("Client Retained","The client keeps voting authority; the firm does not vote."),("Client Directed","The firm votes as the client directs or under the client's policy."),("Trustee","The CIT trustee holds voting authority; it may delegate it to the firm."),("Sub-Adviser","A sub-adviser votes the portfolio's securities."),("Pass-Through Voting Choice","Fund shareholders choose among the policies offered under the investor choice program (Voting Choice Option Type); the election is 13's.")]),
 "Voting Choice Option Type": ("Internal (investor choice proxy voting program options; confirm against the firm's program terms)", [("Fund Adviser Policy","The policy the firm applies to the funds it advises; the default where the shareholder makes no choice."),("Board-Aligned","Votes in line with the recommendations of each investee company's board."),("Third-Party Benchmark","A proxy advisor's benchmark or specialty policy (for example a public pension or values-based policy)."),("Values-Based","A policy reflecting a stated set of values, for example faith-based or sustainability-focused."),("Not Voting","The shares attributable to the shareholder are not voted, except where a vote is needed for quorum (confirm program terms)."),("Other","")]),
 "Proposal Category": ("SEC Form N-PX (as amended by Release 33-11131)", [("Audit-related",""),("Capital structure",""),("Compensation",""),("Corporate governance",""),("Director elections",""),("Diversity, equity, and inclusion",""),("Environment or climate",""),("Extraordinary transactions",""),("Human rights or human capital/workforce",""),("Investment company matters",""),("Section 14A say-on-pay votes","Say-on-pay, say-on-frequency and golden parachute votes; in scope of Rule 14Ad-1 manager reporting."),("Shareholder rights and defenses",""),("Other social issues",""),("Other","")]),
 "Agenda Item Proponent": ("SEC Form N-PX / Internal", [("Management","Proposed by the issuer's board or management."),("Shareholder","Proposed by a shareholder, including the firm when it files or co-files (see Escalation Action)."),("Dissident Shareholder","Proposed by a shareholder soliciting in opposition to management, e.g. a contested election.")]),
 "Management Recommendation": ("SEC Form N-PX / Internal", [("For",""),("Against",""),("Abstain",""),("One Year","Say-on-frequency."),("Two Years","Say-on-frequency."),("Three Years","Say-on-frequency."),("None","The board makes no recommendation.")]),
 "Vote Cast": ("SEC Form N-PX / ISO 20022 seev.004 (vote instruction)", [("For",""),("Against",""),("Abstain",""),("Withhold","Director elections under plurality voting."),("One Year","Say-on-frequency."),("Two Years","Say-on-frequency."),("Three Years","Say-on-frequency."),("Do Not Vote","A decision not to vote the item; reported on Form N-PX as not voted.")]),
 "Ballot Status": ("Internal", [("Received","Ballot received from the distributor or custodian."),("Pending Instruction","Awaiting a voting decision."),("Partially Instructed","Some agenda items instructed."),("Instructed","All agenda items instructed."),("Rejected by Agent","Instruction rejected, e.g. missing power of attorney or late."),("Closed","Meeting held; no further action.")]),
 "Vote Decision Source": ("Internal", [("Policy Default","Voted per the guideline's default position."),("Stewardship Analyst Case-by-Case","Decided by a stewardship analyst on review."),("Portfolio Manager Override","Decided by the portfolio manager against the stewardship team's recommendation."),("Stewardship Committee","Decided by the stewardship committee, e.g. a conflict of interest."),("Client Direction","Voted as the client directed."),("Pass-Through Voting Choice","Voted per the policy chosen by fund shareholders under the investor choice program."),("Echo / Mirror Voting","Voted in proportion to other holders, e.g. a fund of funds voting an own underlying fund.")]),
 "Vote Confirmation Status": ("Internal / ISO 20022 seev.006 and seev.007", [("Not Requested",""),("Pending",""),("Confirmed - Received by Agent","Voting agent confirmed electronic receipt."),("Confirmed - Recorded by Issuer","Issuer or its tabulator confirmed the vote was validly recorded and counted."),("Rejected","Vote rejected by the agent or issuer.")]),

 # Engagement
 "Engagement Theme": ("Internal (aligned to PRI Reporting Framework themes)", [("Board Composition and Effectiveness",""),("Executive Remuneration",""),("Climate Change",""),("Biodiversity and Natural Capital",""),("Human Rights",""),("Human Capital",""),("Diversity, Equity and Inclusion",""),("Capital Allocation",""),("Audit and Risk Oversight",""),("Shareholder Rights",""),("Business Conduct and Controversies",""),("Disclosure and Reporting",""),("Market-Wide and Policy","Engagement with regulators, standard setters or index providers."),("Other","")]),
 "Engagement Outcome": ("Internal", [("Not Yet Determined","Engagement ongoing."),("Objective Achieved",""),("Partially Achieved",""),("Not Achieved",""),("Discontinued","Engagement stopped, e.g. holding sold for unrelated reasons.")]),
 "Engagement Milestone Stage": ("Internal (common four-milestone engagement tracking practice)", [("Concern Raised","Concern communicated to the issuer."),("Issuer Acknowledged","Issuer acknowledged the concern."),("Plan Developed","Issuer developed a credible plan to address it."),("Plan Implemented","Issuer implemented the plan.")]),
 "Engagement Contact Medium": ("Internal / PRI Reporting Framework", [("Meeting or Call","In person, video or telephone; a 23 Issuer Meeting record may exist."),("Letter",""),("Email",""),("Site Visit",""),("Question at General Meeting",""),("Collaborative Group Meeting","Meeting held by an investor initiative."),("Other","")]),
 "Escalation Action Type": ("Internal / ICGN Global Stewardship Principles", [("Vote Against Management",""),("Vote Against Director","Vote against the responsible director or committee chair."),("Shareholder Proposal Filed",""),("Shareholder Proposal Co-Filed",""),("Statement at General Meeting",""),("Public Statement",""),("Collaborative Escalation","Joint letter or action through an initiative."),("Requisition of General Meeting",""),("Divestment Recommendation","Recommendation to portfolio managers to sell; acting on it is a 24 investment decision."),("Exclusion List Addition","Issuer added to a 34 exclusion list."),("Other","")]),

 # ESG data and assessments
 "Indicator Level": ("Internal / PCAF", [("Issuer","Measure of one issuer, portfolio company or instrument; held as Issuer Sustainability Observations."),("Portfolio","Aggregate of a portfolio or product; held as Portfolio Sustainability Metrics."),("Entity","Aggregate of a firm legal entity, e.g. the firm's total financed emissions.")]),
 "Sustainability Indicator Scope": ("GHG Protocol Corporate Standard", [("Scope 1","Direct emissions."),("Scope 2 (Location-Based)",""),("Scope 2 (Market-Based)",""),("Scope 3","Value chain emissions."),("Not Applicable","Non-emissions indicator.")]),
 "ESG Rating Type": ("Internal", [("ESG Rating","Letter or category rating of overall ESG profile."),("ESG Risk Score","Score of unmanaged ESG risk."),("Controversy Level","Vendor's controversy flag or category, held as published."),("Climate Score","Climate or carbon performance score."),("Governance Score",""),("Norms-Based Assessment","Compliance with UN Global Compact principles and OECD Guidelines."),("Other","")]),
 "Exclusion Policy Basis": ("Internal; index exclusion criteria of tracked indexes (EU BMR Delegated Regulation (EU) 2020/1818 Art 12 for Paris-aligned and climate transition indexes)", [("Controversial Weapons","Cluster munitions, anti-personnel mines, chemical and biological weapons."),("Thermal Coal",""),("Oil Sands",""),("Arctic Oil and Gas",""),("Tobacco",""),("UN Global Compact Violation",""),("OECD Guidelines Violation",""),("Paris-Aligned Benchmark Exclusions","Exclusions of a Paris-aligned index a fund tracks (Delegated Regulation 2020/1818 Art 12(1)(a)-(g)); index methodology."),("Climate Transition Benchmark Exclusions","Exclusions of a climate transition index a fund tracks (Art 12(1)(a)-(c)); index methodology."),("Other","")]),

 # Portfolio metrics and outcomes
 "Metric Measurement Basis": ("Internal / IFRS S2", [("Point in Time","Holdings at the measurement date."),("Average of Quarter-End Valuation Points","Average over the period's quarter-end valuation points."),("Annual Average",""),("Period Total","Flow measures over the period.")]),
 "Metric Framework": ("Internal", [("TCFD / ISSB","IFRS S2 and TCFD-aligned reporting."),("NZAM Progress","Net zero target progress reporting."),("Internal","Internal monitoring only.")]),
 "Metric Calculation Standard": ("Internal", [("PCAF Part A","PCAF Global GHG Accounting and Reporting Standard Part A."),("IFRS S2 / TCFD","WACI and carbon footprint as defined by TCFD and IFRS S2."),("Proprietary Methodology","Vendor or firm method with no public standard, e.g. implied temperature rise; name it in Metric Model Name.")]),

 # Financed emissions and targets
 "PCAF Asset Class": ("PCAF Standard Part A (asset classes; confirm against the third edition)", [("Listed Equity and Corporate Bonds",""),("Business Loans and Unlisted Equity","Includes private equity and private debt."),("Project Finance",""),("Commercial Real Estate",""),("Mortgages",""),("Motor Vehicle Loans",""),("Sovereign Debt","")]),
 "Attribution Basis": ("PCAF Standard Part A", [("EVIC","Enterprise value including cash, for listed companies."),("Total Equity plus Debt","For private companies."),("Total Project Equity plus Debt","Project finance."),("Property Value at Origination","Real estate and mortgages."),("PPP-Adjusted GDP","Sovereign debt.")]),
 "PCAF Data Quality Score": ("PCAF Standard Part A", [("1","Verified reported emissions."),("2","Unverified reported emissions."),("3","Physical activity-based estimate."),("4","Economic activity-based estimate using revenue."),("5","Economic activity-based estimate using asset or sector averages.")]),
 "Climate Target Type": ("Net Zero Asset Managers commitment / IFRS S2 (confirm after the NZAM relaunch)", [("Portfolio Decarbonization Reference Target","Reduction in portfolio emissions or intensity from a baseline."),("Portfolio Coverage Target","Share of assets in net zero aligned or aligning issuers."),("Engagement Threshold Target","Share of financed emissions under engagement or stewardship."),("Absolute Financed Emissions Target",""),("Climate Solutions Investment Target","")]),

 # Disclosure
 "Proxy Voting Report Type": ("SEC Form N-PX / SEC Rule 14Ad-1 / SEC Rule 206(4)-6", [("Form N-PX - Fund Report","Registered fund's annual record of votes (Rule 30b1-4)."),("Form N-PX - Manager Say-on-Pay Report","Manager's annual record of say-on-pay votes (Rule 14Ad-1)."),("Client Account Voting Report","Votes cast for one client account (an institutional separate account or another account that delegates voting), provided on request under Rule 206(4)-6; 12 presents it.")]),
 "Stewardship Framework": ("Internal / PRI / NZAM / IFRS S2", [("Firm Stewardship Report","The firm's voluntary annual investment stewardship report (votes, engagement, policy)."),("Voluntary Climate Report (TCFD / IFRS S2)","Entity or product climate report prepared voluntarily against TCFD or IFRS S2."),("PRI Reporting Framework",""),("Net Zero Asset Managers Progress Report","Confirm after the NZAM relaunch."),("Other","")]),
}

# ---------------------------------------------------------------------------
REL = [
 ("Voting Policy","has","Voting Guideline","1 : 1..n","One default position per guideline code (issue category and market)."),
 ("Voting Policy","is approved for funds through","Resolution Subject Link [35]","1 : 0..n","Held once, by 35 (CD-237); 34 holds no board resolution reference."),
 ("Voting Policy","may adopt the benchmark of","Party (Proxy Advisor) [02]","n : 0..1","Benchmark-adopted policies."),
 ("Voting Policy","is offered as an investor choice option to shareholders of","Investment Product [01]","n : n","Voting Choice Offered Funds; each shareholder's election is 13 (W2)."),
 ("Voting Authority Arrangement","covers","Portfolio [18]","n : 0..1","Effective-dated; a portfolio or a client account is filled."),
 ("Voting Authority Arrangement","may cover","Account [15]","n : 0..1","Institutional separate accounts (IA line) and other client accounts that delegate voting authority."),
 ("Voting Authority Arrangement","applies","Voting Policy","n : 0..1","Blank where the client retains authority."),
 ("Investee Meeting Agenda Item","is put to","Corporate Action Event (meeting) [17]","n : 1","The meeting is a 17 CAE- (CD-226); 34 holds no meeting object."),
 ("Proxy Advisor Recommendation","is made on","Investee Meeting Agenda Item","n : 1","One per advisor and advisor policy."),
 ("Proxy Advisor Recommendation","is licensed through","Dataset [14]","n : 1",""),
 ("Ballot","is issued for","Corporate Action Event (meeting) [17]","n : 0..1","Investee meetings."),
 ("Ballot","is issued for","Proxy Campaign [13]","n : 0..1","Meetings of own funds held by own portfolios; 13 keeps the Mirror / Echo tally."),
 ("Ballot","represents the holding of","Safekeeping Account [28]","n : 1","One ballot per meeting and account; the portfolio is read from the 28 assignment."),
 ("Ballot","copies eligible shares from","Corporate Action Entitlement [28]","1 : 0..1","Record Date Shares = Eligible Balance."),
 ("Ballot","reads shares on loan from","Securities Loan [28]","n : 0..n","Shares on Loan Not Recalled is a Derived copy (28)."),
 ("Ballot","has","Vote Instruction","1 : 0..n","One per agenda item."),
 ("Vote Rationale","decides","Investee Meeting Agenda Item / Proxy Proposal [13]","n : 1","One decision per item and voting policy applied."),
 ("Vote Instruction","implements","Vote Rationale","n : 0..1","Every ballot voted under the policy implements the same decision."),
 ("Vote Instruction","votes on","Investee Meeting Agenda Item / Proxy Proposal [13]","n : 1",""),
 ("Vote Instruction","is decided by","Employee [20]","n : 0..1",""),
 ("Lending Recall Decision","is made on","Securities Loan [28]","n : 1","Recall execution and Recall Date stay in 28 (CD-198)."),
 ("Engagement","engages","Party (issuer, portfolio company or market participant) [02]","n : 1","Issuer profile in 17, portfolio company profile in 30."),
 ("Engagement","has","Engagement Objective","1 : 1..n",""),
 ("Engagement","has","Engagement Interaction","1 : 0..n",""),
 ("Engagement Interaction","may have the record","Issuer Meeting [23]","n : 0..1","No date, participant or topic facts repeated (CD-227)."),
 ("Engagement","may be escalated by","Escalation Action","1 : 0..n",""),
 ("Escalation Action","may act through","Investee Meeting Agenda Item","n : 0..1","Vote against or shareholder proposal filed."),
 ("Escalation Action","may be acted on by","Investment Decision [24]","n : 0..1","Divestment."),
 ("Vote Rationale","may support","Engagement","n : 0..1",""),
 ("Collaborative Initiative Membership","joins","Party (Collaborative Engagement Initiative) [02]","n : 1","By firm legal entity [09] and period."),
 ("Sustainability Indicator Definition (Portfolio or Entity)","aggregates","Sustainability Indicator Definition (Issuer)","n : 0..1","Input Indicator."),
 ("Sustainability Indicator Definition","is measured in","Unit of Measure [09]","n : 1",""),
 ("Issuer Sustainability Observation","measures","Sustainability Indicator Definition (Issuer)","n : 1",""),
 ("Issuer Sustainability Observation","is sourced from","Dataset [14]","n : 1","Every observation names its dataset (CD-228)."),
 ("ESG Rating Observation","is sourced from","Dataset [14]","n : 1","Issuer-level vendor ratings; fund ratings are 11."),
 ("Firm ESG Assessment","assesses","Party (Issuer) [02]","n : 1","Dated and approved; no ESG score on 23 Research Recommendation."),
 ("Sustainability Exclusion List","has","Exclusion List Member","1 : 0..n","Members effective-dated across list versions."),
 ("Sustainability Exclusion List","may feed","Rule Instrument List [33]","1 : 0..n","33 holds the link (Source Sustainability Exclusion List)."),
 ("Sustainability Exclusion List","may be cited by","Investment Restriction [01]","1 : 0..n","Restriction Source 'ESG Exclusion Policy'."),
 ("Portfolio Sustainability Metric","measures","Sustainability Indicator Definition (Portfolio or Entity)","n : 1","One vocabulary for climate and other sustainability metrics."),
 ("Portfolio Sustainability Metric","is measured on","Portfolio [18] / Investment Product [01] / Internal Legal Entity [09]","n : 1",""),
 ("Portfolio Sustainability Metric","has","Financed Emissions Holding Detail","1 : 0..n",""),
 ("Financed Emissions Holding Detail","reads","Portfolio Holding [18]","n : 1","Holding Value Used is a Derived copy (18)."),
 ("Portfolio Sustainability Metric","is read by","Stress Test Result [31]","1 : 0..n","31 holds the link (Climate Metric Input)."),
 ("Climate Target","is tracked by","Portfolio Sustainability Metric","1 : 0..1","Latest Progress Metric."),
 ("Proxy Voting Report","reports","Vote Instruction","n : n","Selection rule: instructions whose ballot portfolio is the reporting fund series (or every instruction with Rule 14Ad-1 authority for the manager, or the client account's instructions), whose meeting falls in the period and, for manager reports, whose item is a Section 14A say-on-pay vote. No report line is stored."),
 ("Proxy Voting Report","is filed through","Filing Document of Fund Regulatory Filing [35]","1 : 0..n","35 holds one filing document row per series' report (CD-230)."),
 ("Proxy Voting Report / Stewardship Report","is presented to clients by","Report Run [12]","1 : 0..n","12 presents; holds no stewardship facts."),
 ("Stewardship Report","features","Reported Engagement","1 : 0..n",""),
]

# ---------------------------------------------------------------------------
SRC = [
 ("SEC Form N-PX and Rule 30b1-4 as amended by Release 33-11131 (Enhanced Reporting of Proxy Votes by Registered Management Investment Companies; Reporting of Executive Compensation Votes by Institutional Investment Managers), adopted November 2, 2022, compliance from July 1, 2024","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.30b1-4","Regulation","Proposal categories, shares voted, how voted, shares loaned and not recalled, for or against management, issuer form-of-proxy language","Proposal Category, Vote Instruction, Ballot, Proxy Voting Report",["SEC Form N-PX", "SEC Rule 30b1-4"]),
 ("SEC Rule 14Ad-1 (report of proxy voting record on executive compensation)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.14Ad-1","Regulation","Manager say-on-pay reporting where the manager has and exercises voting power","Voting Authority Holder, Proxy Voting Report Type",["SEC Rule 14Ad-1"]),
 ("SEC Rule 206(4)-6 (proxy voting by investment advisers)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.206(4)-6","Regulation","Written voting policies, conflicts of interest procedures, disclosure and records","Voting Policy, Voting Guideline, Vote Decision Source",["SEC Rule 206(4)-6"]),
 ("SEC Schedules 13D and 13G and Compliance and Disclosure Interpretation 103.12 (February 2025) on engagement and passive investor status","US SEC","https://www.sec.gov/rules-regulations/staff-guidance/compliance-disclosure-interpretations/exchange-act-sections-13d-13g-regulation-13d-g","Regulatory guidance (confirm page)","When engagement may make a holder ineligible to file on Schedule 13G","Engagement.Passive Status Review Indicator",["SEC Schedule 13G", "SEC C&DI 103.12"]),
 ("SEC Rules 14a-1(l) and 14a-2(b)(9) (proxy voting advice) as amended in 2020 and 2022","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-240/section-240.14a-2","Regulation","Proxy voting advice businesses; issuer access to advice","Proxy Advisor Recommendation",["SEC Rule 14a-1(l)", "SEC Rule 14a-2(b)(9)"]),
 ("DOL 29 CFR 2550.404a-1 (fiduciary duties regarding plan investments and investment courses of action, including proxy voting)","US DOL / EBSA","https://www.ecfr.gov/current/title-29/subtitle-B/chapter-XXV/subchapter-F/part-2550/section-2550.404a-1","Regulation","Proxy voting duties for plan assets, including CIT and ERISA separate accounts","Voting Authority Holder (Trustee)",["DOL 29 CFR 2550.404a-1"]),
 ("Commission Delegated Regulation (EU) 2020/1818 (minimum standards for EU Climate Transition and Paris-aligned Benchmarks), Art 12","European Commission","https://eur-lex.europa.eu/eli/reg_del/2020/1818/oj","Index methodology (EU law; kept as the exclusion criteria of tracked Paris-aligned and climate transition indexes, CW-934)","PAB and CTB exclusions (controversial weapons, tobacco, UNGC/OECD violators, coal, oil and gas revenue thresholds) applied by indexes the funds track","Exclusion Policy Basis, Sustainability Exclusion List",["EU BMR Delegated Regulation (EU) 2020/1818"]),
 ("IFRS S2 Climate-related Disclosures (ISSB, June 2023), incorporating the TCFD recommendations","IFRS Foundation","https://www.ifrs.org/issued-standards/ifrs-sustainability-standards-navigator/ifrs-s2-climate-related-disclosures/","Standard (voluntary for the firm)","Financed emissions for asset managers, climate metrics and targets","Portfolio Sustainability Metric, Climate Target",["IFRS S2"]),
 ("PCAF Global GHG Accounting and Reporting Standard Part A: Financed Emissions (third edition, December 2025, confirm)","Partnership for Carbon Accounting Financials","https://carbonaccountingfinancials.com/standard","Industry standard (voluntary)","Asset classes, attribution factors (EVIC and equity plus debt), data quality scores 1-5","Financed Emissions Holding Detail, PCAF Asset Class, PCAF Data Quality Score, Attribution Basis",["PCAF Standard Part A"]),
 ("GHG Protocol Corporate Accounting and Reporting Standard and Scope 2 Guidance","WRI / WBCSD","https://ghgprotocol.org/corporate-standard","Industry standard","Scope 1, 2 (location- and market-based) and 3","Sustainability Indicator Scope",["GHG Protocol"]),
 ("Net Zero Asset Managers initiative commitment and target-setting (relaunched 2025, confirm current wording)","NZAM","https://www.netzeroassetmanagers.org","Industry initiative (confirm)","Target types, AUM in scope, progress reporting","Climate Target Type, Climate Target",["NZAM Commitment"]),
 ("PRI Reporting Framework","Principles for Responsible Investment","https://www.unpri.org/reporting-and-assessment","Industry framework (confirm 2026 modules)","Stewardship and engagement reporting, assessment scores","Stewardship Report, Engagement Theme, Engagement Channel",["PRI Reporting Framework"]),
 ("ICGN Global Stewardship Principles","International Corporate Governance Network","https://www.icgn.org","Industry principles (confirm edition)","Engagement and escalation practice","Escalation Action Type, Voting Guideline",["ICGN Global Stewardship Principles"]),
 ("ISS and Glass Lewis benchmark proxy voting policies (public documents)","ISS STOXX; Glass Lewis","https://www.issgovernance.com","Vendor documentation","Policy and guideline structure; recommendation feeds","Voting Policy, Voting Guideline, Proxy Advisor Recommendation",["ISS Benchmark Policy"]),
 ("ISO 20022 securities events (seev) general meeting messages: seev.001 Meeting Notification, seev.004 Meeting Instruction, seev.006 Meeting Instruction Status, seev.007 Meeting Vote Execution Confirmation","ISO / SWIFT","https://www.iso20022.org/iso-20022-message-definitions","Open standard","Ballot, instruction, status and vote confirmation across the intermediary chain","Ballot, Vote Instruction, Vote Confirmation Status",["ISO 20022 seev*"]),
 ("Broadridge ProxyEdge (vendor practice)","Broadridge","https://www.broadridge.com","Vendor documentation","Ballot control numbers and distribution to institutional voters","Ballot.Ballot Control Number",["Broadridge ProxyEdge"]),
]
