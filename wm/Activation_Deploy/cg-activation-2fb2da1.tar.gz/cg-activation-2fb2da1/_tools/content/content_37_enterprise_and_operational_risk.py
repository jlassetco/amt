"""Data Domain 37 - Enterprise & Operational Risk. Content module for taxonomy_builder.py."""

META = {
 "title": "Enterprise and Operational Risk Data Taxonomy",
 "subtitle": "Business domain 37 - Enterprise & Operational Risk | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "37_Enterprise_and_Operational_Risk/Enterprise_and_Operational_Risk_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the second line of defense (enterprise and operational risk, model risk, operational resilience and business continuity, and third-party risk) and the third line (internal audit) of a US wealth manager that runs a direct brokerage platform through a self-clearing broker-dealer, digital and human advice through a registered investment adviser, its own mutual funds, ETFs and CITs, workplace retirement recordkeeping, institutional advisory and optional trust services. It defines the firm's record of what can go wrong, what controls it, what did go wrong and what it cost: the non-financial risk taxonomy, the enterprise risk register (RISK-) and its dated assessments, risk appetite statements, RCSA campaigns, the control library (CNTRL-) with risk-to-control links and control tests by every line, operational incidents (OPINC-) with their Basel classification, sources and notifications (Regulation S-P customer notifications and state breach notifications for incidents involving customer information; a FINRA Rule 4530 report only where the incident also involves a 4530 reportable event, such as a violation or a customer complaint; other SEC or regulator notifications), operational loss events (LOSS-) and their amounts and recoveries, key risk indicators and observations, the issues and actions register (ISSUE-), critical functions and the resources they depend on, business impact analyses, business continuity plans (FINRA Rule 4370 and the adviser's and funds' compliance-program plans) and resilience tests, the enterprise third-party risk assessment (CD-090), the model inventory (MODEL-) with tiering, validation and monitoring, and the internal audit universe, plans, engagements (AUDIT-), findings (AUDF-) and closure validations. It is a separate domain because the risk and control framework is a cross-cutting register that every business domain is assessed against, kept by functions that must stay independent of the businesses they assess. The firm is regulated and operates in the US only: DORA, the UK operational resilience regime (important business services and impact tolerances), FCA notifications, PRA model risk principles and the EBA outsourcing guidelines were removed under CW-937 and are listed in the jurisdiction register. Stitched together from COSO ERM (2017) and Internal Control - Integrated Framework (2013), the Basel Committee operational risk event types and Principles for the Sound Management of Operational Risk (2021), the ORX Reference Taxonomy, FINRA Rules 4370 and 4530, SEC Regulation S-P, SEC Rules 38a-1 and 206(4)-7, the interagency sound practices to strengthen operational resilience (2020) and third-party guidance (2023), Federal Reserve SR 26-2 (superseding SR 11-7) on model risk, the IIA Global Internal Audit Standards (2024), ISO 22301, NIST CSF 2.0, PCAOB AS 2201 and the structure of GRC platforms (ServiceNow IRM, Archer, MetricStream)."),
  ("Scope", "In scope: risk taxonomy categories and versions; enterprise risks (RISK-), risk assessments (inherent, residual, trend) and risk appetite statements; RCSA campaigns; controls (CNTRL-, versioned), risk control links and control tests by the first line, compliance monitoring (38) and risk; operational incidents (OPINC-), their source records, classification and regulatory notifications; operational loss events (LOSS-) and loss event amounts; key risk indicators, thresholds and observations; risk issues (ISSUE-) and issue actions, including risk acceptances; critical or important functions and resilience resource mappings, business impact analyses, business continuity plans and resilience tests; third-party risk assessments and their risk domain results; model inventory entries (MODEL-), model tier assignments, validations and performance monitoring; auditable entities, audit plans, audit engagements (AUDIT-), audit findings (AUDF-) and finding closure validations. Out of scope (referenced by ID): legal entities, org units and office locations (09); employees, workforce positions and the key-person flag (20); parties (02); investment breaches (33) and risk limit exceedances (31), which are investment events; trade errors (25), NAV error cases (27), servicing errors and shareholder remediation (13), settlement penalties and fails charges (26) and plan corrections (16), whose loss amounts stay with them; domain control executions (29 TA Control Check, 27 NAV Control Check, 06 Reconciliation, 19 Close Task, 10 Control); data quality issues, metric definitions, data assets and AI use cases (21); risk, attribution, research and valuation models as used (31, 32, 23, 22); data-vendor risk assessments and assurance reports (14); journal entries (19); examinations, examination findings and policies (38); legal matters, contracts and corporate resolutions (39); supplier engagements, supplier risk tiering and outsourcing arrangements (40); applications, IT incidents and security and resilience tests (41); insurance claims (43); physical security incidents and sites (44)."),
  ("Structure", "Four levels: Data Domain > Data Family > Data Business Object > Data Business Attribute."),
  ("Core model", "Risk Taxonomy Categories (levels 1-3, versioned, mapped to the Basel event types and the ORX reference taxonomy) classify every Enterprise Risk (RISK-). Each risk is assessed many times as Risk Assessments (inherent and residual rating, trend), often inside an RCSA Campaign, and is bounded by Risk Appetite Statements, which KRI Thresholds link to; board approval is linked from 39 Corporate Resolution Subject Link, and 37 keeps only a derived approval date. Controls (CNTRL- x version) mitigate risks through Risk Control Links; a Control names the domain record type that executes it (29 TA Control Check, 27 NAV Control Check, 06 Reconciliation, 19 Close Task) and Control Tests sample those executions by reference. An Operational Incident (OPINC-) has Incident Source Records pointing to the event that revealed it (25 Trade Error, 27 NAV Error Case, 33 Investment Breach, 31 Risk Limit Exceedance, 13 Servicing Error, 41 IT Incident, 44 Physical Security and Health & Safety Incidents, 01 model deliveries and others; a self-identified incident has none), an Incident Classification (Basel levels 1-2, firm level 3, cause, near miss) and Incident Regulatory Notifications, each with its regime (Regulation S-P customer notification, state breach notification, FINRA Rule 4530 report where a 4530 reportable event is involved, SEC or other regulator, internal) and stage (initial, update or amendment, final). Incidents with a financial effect give Operational Loss Events (LOSS-). Loss Event Amounts hold the gross loss borne by the firm (Derived copies of the source record's firm-borne amount, or mastered here where no source exists); the loss event holds the client or portfolio Impact Amount separately. Insurance recoveries are read from 43 Insurance Claim, which references the loss event. KRIs (versioned, with thresholds) are observed per date. Risk Issues (ISSUE-) hold the one link to their source (audit finding, 38 examination finding or program review, incident, control test, model validation, third-party assessment, resilience test, 41 vulnerability finding) and are closed through Issue Actions. Critical or Important Functions (the critical activities and operations of the interagency guidance) are mapped to the people, processes, applications, IT services, sites, suppliers and data they depend on by Resilience Resource Mappings; Business Impact Analyses set recovery objectives, Business Continuity Plans (FINRA Rule 4370 for the broker-dealer; the adviser's and funds' plans under Rules 206(4)-7 and 38a-1) cover them and Resilience Tests exercise the plans. Third-Party Risk Assessments (third party x 40 supplier engagement x cycle) record residual risk with Risk Domain Results. Model Inventory Entries (MODEL- x version) are tiered, validated and monitored; 31, 32, 21, 22, 24 and 34 hold the reference. Internal Audit plans engagements (AUDIT-) over Auditable Entities; Audit Findings (AUDF-) are remediated by Risk Issues and closed only by a Finding Closure Validation attempt with outcome Validated - Closed."),
  ("Design principles", "1) Library here, execution there (CD-243): a Control defines the control; check records stay in their domains and are sampled by reference. 2) Investment event is not an operational incident (CD-244): a 33 breach or 31 exceedance becomes an incident only when an operational failure caused it or it caused a loss, and the incident copies none of its facts. 3) One loss, one home (CD-244): the firm's gross loss and the client or portfolio impact are separate measures, and each is a Derived copy of the source record's matching amount where one exists. 4) One incident record per layer (CD-245): the 41 IT Incident and 44 Physical Security Incident are the technical records; 37 holds the business-impact record, the link and every regulatory notification. 5) Inventory here, use there (CD-246): consumers hold the reference to the Model Inventory Entry; 37 keeps no list of uses. 6) Tier in 40, residual risk here (CD-248): neither copies the other's rating; the outsourcing register is 40's. 7) Audit independence (CD-247): the Internal Audit family is owned by the Chief Audit Executive; findings are rated only by Internal Audit and closed only by Finding Closure Validation. 8) One rating, one home: inherent and residual ratings only on Risk Assessment and Third-Party Risk Assessment, incident severity only on the incident, issue rating only on the issue, finding rating only on the finding. 9) Keep dimensions apart: Basel event type vs cause category, control type vs control nature, Case Status vs Loss Status, model type vs model tier. 10) Every assessment, link, appetite, function, mapping and auditable entity is effective-dated; every observation, test and validation is dated."),
  ("Applies To", "Shows the record each attribute belongs to: Risk Category, Risk, Risk Assessment, Appetite, RCSA Campaign, Control, Risk Control Link, Control Test, Incident, Incident Source, Incident Classification, Notification, Loss Event, Loss Amount, KRI, KRI Threshold, KRI Observation, Issue, Issue Action, Function, Resource Mapping, BIA, BCP, Resilience Test, TP Assessment, TP Domain Result, Model, Model Tier, Model Validation, Model Monitoring, Auditable Entity, Audit Plan, Audit Engagement, Audit Finding or Closure Validation."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify a risk, control, incident, loss, issue, model, engagement or finding and its version; to evidence a rating (inherent and residual risk, severity, tier, validation outcome, finding rating); to compute and report operational losses (Basel event type, loss component, amount, booking date); to meet a regulatory deadline (notification regime, stage and deadline under Regulation S-P, state breach laws or FINRA Rule 4530, recovery objectives); or to evidence closure (issue status and due date, closure validation). Confirm with the Chief Risk Officer, the Head of Operational Risk, the Head of Model Risk and the Chief Audit Executive."),
  ("Primary / Secondary Reference", "Standard, rule or source the attribute definition is aligned to. 'Internal' = firm-defined. Basel standards are cited for event types and loss data concepts only; the firm is not a bank. SR 26-2 and the interagency sound practices and third-party guidance are applied by analogy. Vendor references (ServiceNow IRM, Archer, MetricStream) indicate common GRC platform structure, not a license to reproduce vendor schemas."),
  ("Notes", "PII = personal information under US privacy law (Regulation S-P for client information; state privacy laws). Employee references (risk owners, testers, assessors, auditors, validators) are personal data of internal staff. Incidents involving client data are classified Restricted - Personal Data; whistleblowing-sourced incidents are confidential and their reporter is never recorded here. Portfolio references on incidents are fund and institutional portfolios (18); retail managed accounts are 15 accounts, not 18 portfolios (CW-007). Key formats: RISK-<sequence, 5 digits> (RISK-00412); CNTRL-<sequence, 6 digits>, version separate (CNTRL-004120); OPINC-<year>-<sequence, 5 digits> (OPINC-2026-01187); LOSS-<year>-<sequence, 5 digits> (LOSS-2026-00213); ISSUE-<year>-<sequence, 5 digits> (ISSUE-2026-00877); MODEL-<sequence, 4 digits>, version separate (MODEL-0412); AUDIT-<plan year>-<sequence, 3 digits> (AUDIT-2026-014); AUDF-<plan year>-<engagement sequence, 3 digits>-<finding, 2 digits> (AUDF-2026-014-03). Other objects are keyed by grain or by firm codes written without a hyphenated stem ('KRI 0412', 'CIF 03', 'BCP 014', 'NFR 3.07', 'TPRA 2026/00412', 'AUE 0118')."),
  ("Tabs", "Hierarchy, Taxonomy, Code Lists, Relationships, Sources."),
  ("Suggested next steps", "1) Validate families, the risk taxonomy, Basel mapping, CDEs and ownership (CRO families vs the Chief Audit Executive's family) with the Chief Risk Officer and the Chief Audit Executive (SME questions 1 and 2). 2) Agree the loss threshold and near-miss policy (SME question 3) and whether every trade and NAV error raises an incident (SME question 4). 3) Agree with 25, 27, 13, 33, 26 and 43 the Loss Event Amount row rule (CD-244). 4) Agree with 41 and 44 that the link from the technical incident is held only here, and who decides a Regulation S-P customer notification or a FINRA Rule 4530 report (CD-245). 5) Done at the Stage 4 consolidation (CD-246): the 21, 22, 31, 32 and 34 model text attributes reference the Model Inventory Entry and 24 Decision Algorithm Code is a Derived copy (37). 6) Agree with 40 and 14 the tier / residual split (CD-248 as amended: 14 Inherent Risk Rating stays 14) and the deferred derived copy of 14 Residual Risk Rating. 7) Confirm which entities keep a FINRA Rule 4370 plan (the broker-dealer) and how the adviser's and funds' continuity plans under Rules 206(4)-7 and 38a-1 relate to it (SME question 5), and SOX applicability (SME question 6). 8) Map attributes to the GRC platform."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

EMP = "PII (internal staff)."
SMA = "PII only where the portfolio is an institutional separate account of an individual (rare); retail managed accounts are 15 accounts, not 18 portfolios (CW-007)."
CAO = "Data owner: Chief Audit Executive (CD-247); not editable by the first or second line."
CAP = "Business capability map code as 21 and 41 hold it (text code, no master object yet; open item)."

# ---------------------------------------------------------------------------
D("Risk Framework & Register", "ER-RFW",
  "The firm's non-financial risk taxonomy, the enterprise risk register, the dated assessments of each risk and the appetite the boards have set. Investment risk measurement (exposures, VaR, liquidity) is 31; this family holds non-financial risk, plus the capital and liquidity appetite statements 43 measures against.",
  [
   ("Risk Taxonomy", "The versioned hierarchy of non-financial risk categories, mapped to the Basel event types and the ORX reference taxonomy. Level 1 rows are the risk types; there is no separate risk type list.", [
     ("Risk Taxonomy Category", [
       ("Risk Category Code", "Firm code of the category, stable across taxonomy versions and written without a hyphenated stem.", "Risk Category", "Identifier", "", "NFR 3.07", "Internal", "ORX Reference Taxonomy", "Y"),
       ("Risk Taxonomy Version", "Version of the taxonomy the category row belongs to; a new version is issued when categories are added, split or retired.", "Risk Category", "Integer", "", "4", "Internal", "", "Y"),
       ("Risk Category Name", "Business name of the category.", "Risk Category", "Text", "", "NAV calculation and publication error", "Internal", "", ""),
       ("Parent Risk Category", "Category one level up in the same taxonomy version; blank for a level 1 risk type, so the level and the level 1 type are read from the parent chain.", "Risk Category", "Reference (Risk Taxonomy Category, 37)", "", "NFR 2.07 / 4", "ORX Reference Taxonomy", "Basel OPE25", ""),
       ("Mapped Basel Event Type", "Basel level 2 event type the category maps to for loss data reporting; blank for risk types outside operational risk (strategic).", "Risk Category", "Code", "Basel Event Type Level 2", "Transaction Capture, Execution and Maintenance", "Basel II Annex 9", "BCBS PSMOR 2021", "", "Default for Incident Classification.Basel Event Type Level 2."),
     ]),
   ]),
   ("Enterprise Risk Register", "Each risk the firm has identified, who owns it and where it sits.", [
     ("Enterprise Risk", [
       ("Risk ID", "Enterprise identifier of the risk register entry.", "Risk", "Identifier", "", "RISK-00412", "Internal", "COSO ERM 2017", "Y"),
       ("Risk Statement", "Description of the risk as cause, event and consequence.", "Risk", "Text", "", "Manual override of a stale vendor price is not detected before NAV release, so a misstated NAV is published and shareholders deal at the wrong price.", "COSO ERM 2017", "Internal", ""),
       ("Risk Category", "Level 3 taxonomy category the risk is classified under.", "Risk", "Reference (Risk Taxonomy Category, 37)", "", "NFR 3.07 / 4", "ORX Reference Taxonomy", "", "Y"),
       ("Risk Owning Org Unit", "Org unit accountable for managing the risk.", "Risk", "Reference (Org Unit)", "", "OU-0217", "Internal", "", ""),
       ("Risk Legal Entities", "Internal legal entities whose operations carry the risk.", "Risk", "Reference (Legal Entity) (multi)", "", "LEN-0004; LEN-0021", "Internal", "", ""),
       ("Risk Owner", "Employee accountable for the risk (first line).", "Risk", "Reference (Employee)", "", "EMP-30412", "COSO ERM 2017", "", "", EMP),
       ("Risk Business Lines", "Business lines exposed to the risk.", "Risk", "Code (multi)", "Shared: Business Line", "PF; DB", "Internal", "", ""),
       ("Enterprise Risk Status", "Whether the risk is current in the register.", "Risk", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
     ]),
     ("Risk Assessment", [
       ("Assessed Risk", "Risk the assessment rates.", "Risk Assessment", "Reference (Enterprise Risk, 37)", "", "RISK-00412", "Internal", "", ""),
       ("Risk Assessment Date", "Date the assessment was concluded; assessments are never overwritten.", "Risk Assessment", "Date", "ISO 8601", "2026-09-30", "COSO ERM 2017", "", "Y"),
       ("Risk Assessment Basis", "How the assessment was made.", "Risk Assessment", "Code", "Risk Assessment Basis", "RCSA", "Internal", "", ""),
       ("Source RCSA Campaign", "RCSA campaign in which the assessment was made, for assessments of basis RCSA.", "Risk Assessment", "Reference (RCSA Campaign, 37)", "", "RCSA 2026H2 / OU-0217", "Internal", "", ""),
       ("Inherent Likelihood", "Likelihood of the risk event before controls, on the firm's five-point matrix.", "Risk Assessment", "Code", "Risk Matrix Score", "4 - High", "COSO ERM 2017", "", ""),
       ("Inherent Impact", "Impact of the risk event before controls, on the firm's five-point matrix.", "Risk Assessment", "Code", "Risk Matrix Score", "4 - High", "COSO ERM 2017", "", ""),
       ("Inherent Risk Rating", "Rating of the risk before controls, read from inherent likelihood and impact on the matrix.", "Risk Assessment", "Code", "Shared: Risk Rating", "High", "COSO ERM 2017", "BCBS PSMOR 2021", "Y", "'Prohibited' is not used for enterprise risks."),
       ("Residual Likelihood", "Likelihood of the risk event after the linked controls.", "Risk Assessment", "Code", "Risk Matrix Score", "2 - Low", "COSO ERM 2017", "", ""),
       ("Residual Impact", "Impact of the risk event after the linked controls.", "Risk Assessment", "Code", "Risk Matrix Score", "4 - High", "COSO ERM 2017", "", ""),
       ("Residual Risk Rating", "Rating of the risk after the linked controls, as assessed on the date.", "Risk Assessment", "Code", "Shared: Risk Rating", "Medium", "COSO ERM 2017", "BCBS PSMOR 2021", "Y", "'Prohibited' is not used for enterprise risks."),
       ("Risk Trend", "Expected direction of the residual risk over the next period.", "Risk Assessment", "Code", "Risk Trend", "Stable", "Internal", "", ""),
       ("Within Appetite Indicator", "Whether the residual risk was judged within the appetite statement whose KRI thresholds measure the risk (KRI Threshold.Linked Appetite Statement of the risk's KRIs) on the date.", "Risk Assessment", "Boolean", "", "Y", "COSO ERM 2017", "", ""),
       ("Risk Assessor", "Employee who performed or signed the assessment.", "Risk Assessment", "Reference (Employee)", "", "EMP-30588", "Internal", "", "", EMP),
     ]),
     ("Risk Appetite Statement", [
       ("Appetite Statement Code", "Firm code of the appetite statement, written without a hyphenated stem: RAS, year, the category code of Appetite Category and a sequence.", "Appetite", "Identifier", "", "RAS 2026 OPS 04", "Internal", "COSO ERM 2017", "Y"),
       ("Appetite Category", "Area of risk the statement bounds; capital and liquidity statements are those 43 measures its capital profile against.", "Appetite", "Code", "Appetite Category", "Operational Errors", "COSO ERM 2017", "", ""),
       ("Appetite Scope Entity", "Internal legal entity the statement applies to; blank for the firm-wide statement.", "Appetite", "Reference (Legal Entity)", "", "LEN-0012", "Internal", "", ""),
       ("Appetite Statement Text", "Qualitative statement of how much of the risk the entity accepts.", "Appetite", "Text", "", "No appetite for NAV errors above the materiality threshold; low appetite for errors below it.", "COSO ERM 2017", "", ""),
       ("Appetite Tolerance Threshold", "Value at which the risk leaves appetite and escalation to the board is required, in the unit of the KRIs linked to the statement.", "Appetite", "Decimal", "", "3", "COSO ERM 2017", "", "Y", "KRI Threshold amber and red levels are management early-warning levels set at or inside this value; the KRI-to-appetite link is held on KRI Threshold."),
       ("Appetite Approval Date", "Date the entity board approved the statement.", "Appetite", "Date", "ISO 8601", "2026-03-26", "COSO ERM 2017", "", "", "Derived copy (39): effective date of the Corporate Resolution linked to the statement by 39 Corporate Resolution Subject Link (Subject Risk Appetite Statement); 37 holds no approval reference. SME question 10."),
       ("Appetite Effective From", "Date the statement took effect.", "Appetite", "Date", "ISO 8601", "2026-04-01", "Internal", "", ""),
       ("Appetite Effective To", "Date the statement was superseded or withdrawn.", "Appetite", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Risk & Control Self-Assessment", "ER-CSA",
  "The control library and the work that keeps it honest: RCSA campaigns, the links between risks and the controls that mitigate them, and tests of those controls by the first line, compliance monitoring and risk. Control executions stay in the domains that perform them (CD-243); audit testing stays in the audit engagement.",
  [
   ("RCSA Campaigns", "Periodic self-assessment of risks and controls by an org unit.", [
     ("RCSA Campaign", [
       ("RCSA Campaign Code", "Firm code of the campaign, written without a hyphenated stem.", "RCSA Campaign", "Identifier", "", "RCSA 2026H2", "Internal", "", "Y"),
       ("Assessed Org Unit", "Org unit that performs the self-assessment.", "RCSA Campaign", "Reference (Org Unit)", "", "OU-0217", "Internal", "", ""),
       ("RCSA Period End Date", "Last day of the period the campaign assesses.", "RCSA Campaign", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
       ("RCSA Sign-Off By", "Head of the org unit who signed the assessment.", "RCSA Campaign", "Reference (Employee)", "", "EMP-30412", "Internal", "", "", EMP),
       ("RCSA Campaign Status", "Workflow status of the campaign for the org unit.", "RCSA Campaign", "Code", "Shared: Case Status", "In Progress", "Internal", "", ""),
     ]),
   ]),
   ("Control Library", "Each control the firm relies on, versioned.", [
     ("Control", [
       ("Control ID", "Enterprise identifier of the control library entry, stable across versions.", "Control", "Identifier", "", "CNTRL-004120", "COSO IC 2013", "Internal", "Y"),
       ("Control Version", "Version of the control; a change to objective, design or frequency creates a new version.", "Control", "Integer", "", "3", "Internal", "", "Y"),
       ("Control Objective", "What the control is designed to achieve, stated as the risk it addresses.", "Control", "Text", "", "Detect price overrides older than one day before the NAV is released.", "COSO IC 2013", "", ""),
       ("Control Type", "Whether the control prevents, detects or corrects.", "Control", "Code", "Control Type", "Detective", "COSO IC 2013", "", "Y"),
       ("Control Nature", "Whether the control is manual, automated or IT-dependent manual.", "Control", "Code", "Control Nature", "IT-Dependent Manual", "PCAOB AS 2201", "", ""),
       ("Control Frequency", "How often the control operates.", "Control", "Code", "Shared: Frequency", "Daily", "Internal", "", ""),
       ("Key Control Indicator", "Whether the control is a key control for the risks it is linked to.", "Control", "Boolean", "", "Y", "COSO IC 2013", "", ""),
       ("SOX Key Control Indicator", "Whether the control is a key control over financial reporting under SOX Section 404.", "Control", "Boolean", "", "N", "SOX 404", "PCAOB AS 2201", "", "SME question 6: applies only if the firm or a parent is subject to SOX 404."),
       ("Control Execution Record Type", "Domain record type in which each operation of the control is evidenced.", "Control", "Code", "Control Execution Record Type", "27 NAV Control Check", "Internal", "", "", "The executions stay in their domain and are never re-mastered here (CD-243)."),
       ("Control Owning Legal Entity", "Internal legal entity that owns and operates the control, for example the CIT trustee bank for trustee controls under OCC 12 CFR 9.", "Control", "Reference (Legal Entity)", "", "LEN-0021", "Internal", "OCC 12 CFR 9", ""),
       ("Control Owner", "Employee accountable for the control's operation.", "Control", "Reference (Employee)", "", "EMP-02231", "COSO IC 2013", "", "", EMP),
       ("Control Version Approval Status", "Whether the second line has approved the control version's design.", "Control", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("Control Version Effective From", "Date the version took effect.", "Control", "Date", "ISO 8601", "2025-07-01", "Internal", "", ""),
       ("Control Version Effective To", "Date the version was superseded or the control retired.", "Control", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Risk Control Link", [
       ("Linked Risk", "Risk the control mitigates.", "Risk Control Link", "Reference (Enterprise Risk, 37)", "", "RISK-00412", "Internal", "", ""),
       ("Linked Control", "Control that mitigates the risk.", "Risk Control Link", "Reference (Control, 37)", "", "CNTRL-004120", "Internal", "", ""),
       ("Mitigation Strength", "How much of the risk the control is judged to mitigate; High means strong mitigation.", "Risk Control Link", "Code", "Assessment Level", "High", "Internal", "", ""),
       ("Link Effective From", "Date the link took effect.", "Risk Control Link", "Date", "ISO 8601", "2025-07-01", "Internal", "", ""),
       ("Link Effective To", "Date the link ended.", "Risk Control Link", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Control Testing", "Tests of control design and operation by the first line, compliance monitoring and risk.", [
     ("Control Test", [
       ("Tested Control", "Control (and version) tested.", "Control Test", "Reference (Control, 37)", "", "CNTRL-004120 / 3", "Internal", "", ""),
       ("Control Test Date", "Date the test was concluded.", "Control Test", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
       ("Control Test Sequence", "Order of the test among tests of the same control version on the date.", "Control Test", "Integer", "", "1", "Internal", "", ""),
       ("Control Test Type", "Whether the test evaluated design or operating effectiveness.", "Control Test", "Code", "Control Test Type", "Operating Effectiveness", "PCAOB AS 2201", "COSO IC 2013", ""),
       ("Testing Line", "Line or function that performed the test; compliance monitoring tests by 38 are rows with value Compliance (CD-243).", "Control Test", "Code", "Testing Line", "Compliance", "SEC Rule 38a-1", "Internal", "Y"),
       ("Control Tester", "Employee who performed the test.", "Control Test", "Reference (Employee)", "", "EMP-30544", "Internal", "", "", EMP),
       ("Sampled Execution Records", "Keys of the domain execution records sampled, in the owner's published format.", "Control Test", "Text", "", "TACK-2026-1005-004512; TACK-2026-1006-004530", "Internal", "", "", "Evidence only: results stay in the executing domain (CD-243). Every key is of the record type named by the tested Control's Control Execution Record Type, so a resolver can type it."),
       ("Control Test Result", "Conclusion of the test.", "Control Test", "Code", "Control Test Result", "Effective with Exceptions", "COSO IC 2013", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Operational Incidents & Losses", "ER-INL",
  "Operational incidents (the business-impact record of an operational failure), the records that revealed them, their classification and regulatory notification, and the loss events and amounts that follow. Investment breaches (33) and risk limit exceedances (31) are incidents only when an operational failure caused them or they caused a loss; technical incident records stay in 41 and 44 (CD-244, CD-245). Insurance recoveries are read from 43 Insurance Claim, which references the loss event.",
  [
   ("Operational Incidents", "Each operational failure the firm records, with its impact.", [
     ("Operational Incident", [
       ("Operational Incident ID", "Enterprise identifier of the operational incident.", "Incident", "Identifier", "", "OPINC-2026-01187", "Internal", "Basel OPE25", "Y"),
       ("Incident Description", "What happened, how it was found and what was affected.", "Incident", "Text", "", "Stale vendor price override on a high-yield bond not detected; NAV of two share classes misstated for three days.", "Internal", "", "", "May contain personal data; classify by Incident Information Classification."),
       ("Incident Occurrence Date", "Date the failure first occurred.", "Incident", "Date", "ISO 8601", "2026-09-29", "Basel OPE25", "", "Y"),
       ("Incident Discovery Date", "Date the firm became aware of the failure.", "Incident", "Date", "ISO 8601", "2026-10-02", "Basel OPE25", "", "Y"),
       ("Incident Business Process", "Business capability in which the failure occurred.", "Incident", "Code", "Firm-defined (business capability map code)", "C-08.03 Fund Accounting and NAV", "Internal", "", "", CAP),
       ("Incident Legal Entity", "Internal legal entity that bears the incident.", "Incident", "Reference (Legal Entity)", "", "LEN-0021", "Basel OPE25", "", ""),
       ("Impacted Products", "Funds or products affected.", "Incident", "Reference (Investment Product) (multi)", "", "PRD-00981", "Internal", "", ""),
       ("Impacted Portfolios", "Portfolios affected, where narrower than the product.", "Incident", "Reference (Portfolio, 18) (multi)", "", "PORT-000412", "Internal", "", "", SMA),
       ("Incident Severity", "Severity assigned under the incident policy; the only severity of the incident.", "Incident", "Code", "Shared: Severity", "High", "Internal", "", "Y"),
       ("Incident Root Cause Description", "Root cause established by the investigation.", "Incident", "Text", "", "Override report excluded fixed income securities after a vendor file layout change.", "Internal", "", ""),
       ("Incident Owner", "Employee accountable for managing the incident to closure.", "Incident", "Reference (Employee)", "", "EMP-02231", "Internal", "", "", EMP),
       ("Incident Information Classification", "Confidentiality class of the incident record; incidents involving client data are Restricted - Personal Data.", "Incident", "Code", "Shared: Information Classification", "Confidential", "Internal", "", ""),
       ("Whistleblowing Source Indicator", "Whether the incident was raised through the whistleblowing channel.", "Incident", "Boolean", "", "N", "Internal", "", "", "Confidential; the reporter is never recorded here."),
       ("Incident Status", "Workflow status of the incident.", "Incident", "Code", "Shared: Case Status", "In Progress", "Internal", "", "Y"),
     ]),
     ("Incident Source Record", [
       ("Source Incident", "Operational incident the source belongs to.", "Incident Source", "Reference (Operational Incident, 37)", "", "OPINC-2026-01187", "Internal", "", ""),
       ("Incident Source Type", "Kind of record that revealed or caused the incident; exactly one typed source column is filled per row. A self-identified incident has no source rows.", "Incident Source", "Code", "Incident Source Type", "NAV Error Case", "Internal", "", "Y"),
       ("Source Trade Error", "25 trade error behind the incident.", "Incident Source", "Reference (Trade Error, 25)", "", "TE 2026/0042", "Internal", "", "", "Copies no trade error facts."),
       ("Source NAV Error Case", "27 NAV error case behind the incident.", "Incident Source", "Reference (NAV Error Case, 27)", "", "NEC-2026-0031", "Internal", "", ""),
       ("Source Investment Breach", "33 investment breach that an operational failure caused or that caused a loss.", "Incident Source", "Reference (Investment Breach, 33)", "", "BREACH-2026-00143", "Internal", "", "", "CD-244: no breach type, dates or cure are copied."),
       ("Source Risk Limit Exceedance", "31 risk limit exceedance that an operational failure caused or that caused a loss.", "Incident Source", "Reference (Risk Limit Exceedance, 31)", "", "RLEX-2026-00073", "Internal", "", "", "CD-244: no exceedance facts are copied."),
       ("Source Servicing Error", "13 servicing error behind the incident.", "Incident Source", "Reference (Servicing Error, 13)", "", "ERR-2026-00218", "Internal", "", ""),
       ("Source IT Incident", "41 IT incident (including security incidents) that disrupted a business service or caused a loss.", "Incident Source", "Reference (IT Incident, 41)", "", "ITINC-2026-004512", "NIST CSF 2.0", "", "", "The link is held only here; 41 holds no 37 reference (CD-245)."),
       ("Source Physical Security Incident", "44 physical security incident behind the incident.", "Incident Source", "Reference (Physical Security Incident, 44)", "", "PSI 2026-0007", "Internal", "", "", "The link is held only here; 44 holds no 37 reference."),
       ("Source Health and Safety Incident", "44 health and safety incident that disrupted a service or caused a loss (Basel Employment Practices and Workplace Safety).", "Incident Source", "Reference (Health & Safety Incident, 44)", "", "HSEI-2026-0017", "Internal", "", "", "PII; special-category health data stays in 44. The link is held only here."),
       ("Source Plan Correction", "16 plan correction case behind the incident.", "Incident Source", "Reference (Plan Correction, 16)", "", "PCOR-2026-00119", "IRS EPCRS", "", ""),
       ("Source AP Order", "29 ETF authorized participant order processed in error.", "Incident Source", "Reference (AP Creation / Redemption Order, 29)", "", "ECR-2026-000512", "Internal", "", ""),
       ("Source Model Portfolio", "01 model portfolio whose delivery to a model platform sponsor (IC line) or an institutional separate account was in error.", "Incident Source", "Reference (Model Portfolio)", "", "MDL-0077", "Internal", "", "", "Model-delivery error; the delivery itself is not mastered here."),
       ("Source Account Monitoring Alert", "29 account monitoring alert that revealed a fraud.", "Incident Source", "Reference (Account Monitoring Alert, 29)", "", "AMA-2026-0012281", "Internal", "", "", "PII (shareholder account); Restricted. The AML case itself is 38."),
     ]),
     ("Incident Classification", [
       ("Basel Event Type Level 2", "Basel level 2 event type of the incident.", "Incident Classification", "Code", "Basel Event Type Level 2", "Transaction Capture, Execution and Maintenance", "Basel II Annex 9", "", "Y", "Equals the Mapped Basel Event Type of the Incident Risk Category unless overridden, with the reason in Classification Override Reason."),
       ("Basel Event Type Level 1", "Basel level 1 event type of the incident.", "Incident Classification", "Code", "Basel Event Type Level 1", "Execution, Delivery and Process Management", "Basel II Annex 9", "", "", "Derived within 37: the level 1 parent named in the description of the Level 2 value."),
       ("Incident Risk Category", "Firm level 3 taxonomy category of the incident.", "Incident Classification", "Reference (Risk Taxonomy Category, 37)", "", "NFR 3.07 / 4", "ORX Reference Taxonomy", "", ""),
       ("Classification Override Reason", "Why the Basel level 2 type differs from the category's mapping; blank when it does not.", "Incident Classification", "Text", "", "", "Internal", "", ""),
       ("Cause Category", "Category of the underlying cause, kept apart from the event type.", "Incident Classification", "Code", "Cause Category", "Process Design", "BCBS PSMOR 2021", "ORX Reference Taxonomy", ""),
       ("Near Miss Indicator", "Whether the failure was caught before it caused a loss or disruption.", "Incident Classification", "Boolean", "", "N", "BCBS PSMOR 2021", "", "Y", "SME question 3."),
     ]),
     ("Incident Regulatory Notification", [
       ("Notified Incident", "Operational incident notified.", "Notification", "Reference (Operational Incident, 37)", "", "OPINC-2026-01187", "Internal", "", ""),
       ("Notification Authority", "Authority notified, where the notification goes to an authority; blank for a notification only to affected customers.", "Notification", "Code", "Shared: Regulator", "FINRA", "Regulation S-P", "FINRA Rule 4530", "Y"),
       ("Incident Notification Regime", "Rule or law under which the notification is made.", "Notification", "Code", "Incident Notification Regime", "Regulation S-P Customer Notification", "Regulation S-P", "FINRA Rule 4530", "Y", "Added in the W1b review fix pass (CW-937): the regime was split from the stage."),
       ("Incident Notification Stage", "Stage of the notification within its regime: initial notice, an update or amendment, or the final report.", "Notification", "Code", "Incident Notification Stage", "Initial", "Internal", "FINRA Rule 4530", "Y", "Name kept so readers resolve; the regime is Incident Notification Regime (CW-937)."),
       ("Notifying Legal Entity", "Internal legal entity that made the notification.", "Notification", "Reference (Legal Entity)", "", "LEN-0003", "FINRA Rule 4530", "", ""),
       ("Notification Deadline Timestamp", "Latest time the notification may be submitted under the regime.", "Notification", "Timestamp", "ISO 8601", "2026-11-01T17:00:00-04:00", "Regulation S-P", "FINRA Rule 4530", "Y"),
       ("Notification Sent Timestamp", "When the notification was submitted.", "Notification", "Timestamp", "ISO 8601", "2026-10-20T11:42:00-04:00", "Internal", "", "Y"),
       ("Authority Reference Number", "Reference the authority assigned to the notification.", "Notification", "Identifier", "", "4530-2026-118204", "Internal", "", ""),
     ]),
   ]),
   ("Operational Losses", "Loss events, the firm's gross loss and the client or portfolio impact, with one home per amount.", [
     ("Operational Loss Event", [
       ("Loss Event ID", "Enterprise identifier of the operational loss event.", "Loss Event", "Identifier", "", "LOSS-2026-00213", "Basel OPE25", "Internal", "Y"),
       ("Originating Incident", "Operational incident the loss arose from; event type and cause are read from its classification.", "Loss Event", "Reference (Operational Incident, 37)", "", "OPINC-2026-01187", "Basel OPE25", "", "Y"),
       ("Loss Legal Entity", "Internal legal entity that bears the loss.", "Loss Event", "Reference (Legal Entity)", "", "LEN-0021", "Basel OPE25", "", ""),
       ("Loss Business Line", "Business line the loss is attributed to.", "Loss Event", "Code", "Shared: Business Line", "PF", "Internal", "", ""),
       ("Loss Status", "Whether the loss event is still open to new amounts.", "Loss Event", "Code", "Loss Status", "Open", "Basel OPE25", "", ""),
       ("Impact Amount", "Harm to clients, funds or portfolios caused by the event, whoever bore it; distinct from the firm's gross loss on Loss Event Amount.", "Loss Event", "Amount", "", "USD 18,204.30", "Internal", "", "Y", "Row rule (program lead ruling 3): where the event's Gross Loss row references a source, Derived copy of 25 Trade Error.Error Gain or Loss Amount (sign reversed), 27 NAV Error Case.Fund Loss Amount or 33 Breach Loss Calculation.Breach Loss Amount (latest approved version); where Impact Source Servicing Error is filled, the sum of 13 Shareholder Remediation.Compensation Amount over the remediation rows of that error (a sum by incident, not a per-row copy); otherwise mastered here."),
       ("Impact Source Servicing Error", "13 servicing error whose shareholder remediation rows are summed into the impact amount.", "Loss Event", "Reference (Servicing Error, 13)", "", "", "Internal", "", ""),
       ("Related Legal Matter", "39 legal matter whose settlement, judgment or fine is part of the loss.", "Loss Event", "Reference (Legal Matter, 39)", "", "LMAT-2026-0019", "Internal", "", ""),
     ]),
     ("Loss Event Amount", [
       ("Amount Loss Event", "Loss event the amount belongs to.", "Loss Amount", "Reference (Operational Loss Event, 37)", "", "LOSS-2026-00213", "Basel OPE25", "", ""),
       ("Loss Amount Sequence", "Order of the amount within the loss event.", "Loss Amount", "Integer", "", "1", "Internal", "", ""),
       ("Loss Amount Component", "What the amount represents: gross loss, provision, third-party recovery, gain or near-miss estimate.", "Loss Amount", "Code", "Loss Amount Component", "Gross Loss", "Basel OPE25", "", "Y"),
       ("Loss Amount", "Gross loss borne by the firm for the component: cash paid out plus write-downs, in its currency.", "Loss Amount", "Amount", "", "USD 18,204.30", "Basel OPE25", "", "Y", "Row rule (CD-244, program lead ruling 3): Derived copy where a typed source column is filled: 25 Trade Error.Reimbursement Amount, 27 NAV Error Case.Fund Loss Amount where the Reimbursing Entity is an internal legal entity (the firm-borne cost), 33 Breach Loss Calculation.Compensation Amount where the Compensating Entity is internal, 26 Settlement Penalty.Penalty Amount where Penalty Absorbed by Firm Indicator is Y. Mastered here on rows with no source (fraud, legal settlements and fines, business disruption costs, third-party recoveries). Insurance recoveries are not rows here: they are read from 43 Insurance Claim at claim level."),
       ("Loss Booking Date", "Date the amount was booked in the general ledger; the earliest gross loss booking is the event's first booked date.", "Loss Amount", "Date", "ISO 8601", "2026-10-05", "Basel OPE25", "", "Y"),
       ("GL Evidence Journal", "19 journal entry that booked the amount.", "Loss Amount", "Reference (Journal Entry, 19)", "", "JNL-2026-09-77120", "Internal", "", ""),
       ("Amount Source Trade Error", "25 trade error that holds the amount.", "Loss Amount", "Reference (Trade Error, 25)", "", "", "Internal", "", ""),
       ("Amount Source NAV Error Case", "27 NAV error case that holds the amount.", "Loss Amount", "Reference (NAV Error Case, 27)", "", "NEC-2026-0031", "Internal", "", ""),
       ("Amount Source Breach Loss Calculation", "33 breach loss calculation (breach and version) that holds the amount.", "Loss Amount", "Reference (Breach Loss Calculation, 33)", "", "", "Internal", "", ""),
       ("Amount Source Settlement Penalty", "26 settlement penalty that holds the amount.", "Loss Amount", "Reference (Settlement Penalty, 26)", "", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Key Risk Indicators", "ER-KRI",
  "Indicators that measure risks and appetite, their thresholds and their observed values. A KRI may be defined on a 21 metric definition, whose definition and direction it then copies; the observed value is mastered here (CD-243).",
  [
   ("KRI Definitions", "Each KRI and its thresholds, versioned.", [
     ("Key Risk Indicator", [
       ("KRI Code", "Firm code of the indicator, written without a hyphenated stem.", "KRI", "Identifier", "", "KRI 0412", "Internal", "", "Y"),
       ("KRI Version", "Version of the indicator; a change of definition or thresholds creates a new version.", "KRI", "Integer", "", "2", "Internal", "", "Y"),
       ("KRI Definition", "How the indicator is calculated and from which records.", "KRI", "Text", "", "Count of 27 NAV error cases with Material Error Indicator Y discovered in the calendar month.", "Internal", "", "", "Row rule: Derived copy (21) of Metric Definition.Metric Definition Text when Source Metric Definition is filled; mastered here otherwise."),
       ("Measured Risk", "Enterprise risk the indicator measures.", "KRI", "Reference (Enterprise Risk, 37)", "", "RISK-00412", "Internal", "", ""),
       ("Source Metric Definition", "21 metric definition the indicator is defined on, where the metric is registered.", "KRI", "Reference (Metric Definition, 21)", "", "KPI-0311", "Internal", "", ""),
       ("KRI Frequency", "How often the indicator is observed.", "KRI", "Code", "Shared: Frequency", "Monthly", "Internal", "", ""),
     ]),
     ("KRI Threshold", [
       ("KRI Threshold Direction", "Which way a change in the value is favorable.", "KRI Threshold", "Code", "Shared: Metric Direction", "Lower Is Better", "Internal", "", "Y", "Row rule: Derived copy (21) of Metric Definition.Metric Direction when the KRI has a Source Metric Definition; mastered here otherwise, on the 21 list."),
       ("KRI Amber Threshold", "Value at which the indicator turns amber.", "KRI Threshold", "Decimal", "", "1", "Internal", "", "Y"),
       ("KRI Red Threshold", "Value at which the indicator turns red.", "KRI Threshold", "Decimal", "", "2", "Internal", "", "Y"),
       ("Linked Appetite Statement", "Appetite statement whose tolerance the thresholds sit inside; the only link between a KRI and appetite.", "KRI Threshold", "Reference (Risk Appetite Statement, 37)", "", "RAS 2026 OPS 04", "COSO ERM 2017", "", ""),
     ]),
   ]),
   ("KRI Observations", "The measured value of each KRI per observation date.", [
     ("KRI Observation", [
       ("Observed KRI", "Indicator (code and version) observed; the version fixes the thresholds applied.", "KRI Observation", "Reference (Key Risk Indicator, 37)", "", "KRI 0412 / 2", "Internal", "", ""),
       ("KRI Observation Date", "Date the value applies to.", "KRI Observation", "Date", "ISO 8601", "2026-09-30", "Internal", "", "Y"),
       ("KRI Observed Value", "Measured value of the indicator in its unit.", "KRI Observation", "Decimal", "", "1", "Internal", "", "Y"),
       ("KRI Observation RAG", "Status of the value against the thresholds of the KRI version.", "KRI Observation", "Code", "Shared: RAG Status", "Amber", "Internal", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Issues & Actions", "ER-ISS",
  "The one remediation register: issues from every source (self-identified, control tests, incidents, model validations, audit findings, 38 examination findings and program reviews, third-party assessments, resilience tests, 41 vulnerability findings) and the actions that close them, including risk acceptances. The link from an issue to its source is held once, here (program lead ruling 4).",
  [
   ("Risk Issues", "Each issue and its remediation.", [
     ("Risk Issue", [
       ("Risk Issue ID", "Enterprise identifier of the issue.", "Issue", "Identifier", "", "ISSUE-2026-00877", "Internal", "", "Y"),
       ("Issue Description", "Control gap or weakness to be remediated.", "Issue", "Text", "", "Stale override report excludes fixed income securities.", "Internal", "", ""),
       ("Issue Source Type", "Kind of record that raised the issue; exactly one typed source column is filled, none for a self-identified issue.", "Issue", "Code", "Issue Source Type", "Operational Incident", "Internal", "", "Y"),
       ("Source Audit Finding", "Audit finding the issue holds management's agreed action for; the only link between a finding and its issue.", "Issue", "Reference (Audit Finding, 37)", "", "", "IIA GIAS 2024", "", ""),
       ("Source Examination Finding", "38 examination finding the issue remediates.", "Issue", "Reference (Examination Finding, 38)", "", "", "Internal", "", "", "38 is asked to drop Remediating Risk Issue (proposals_37)."),
       ("Source Compliance Program Review", "38 compliance program review that raised the issue.", "Issue", "Reference (Compliance Program Review, 38)", "", "", "SEC Rule 38a-1", "", "", "38 is asked to drop Review Findings Raised (proposals_37)."),
       ("Source Operational Incident", "Operational incident that raised the issue.", "Issue", "Reference (Operational Incident, 37)", "", "OPINC-2026-01187", "Internal", "", ""),
       ("Source Control Test", "Control test (control, version, date, sequence) whose exceptions raised the issue.", "Issue", "Reference (Control Test, 37)", "", "", "Internal", "", ""),
       ("Source Model Validation", "Model validation whose finding the issue remediates.", "Issue", "Reference (Model Validation, 37)", "", "", "SR 26-2", "", ""),
       ("Source Third-Party Risk Assessment", "Third-party risk assessment that raised the issue.", "Issue", "Reference (Third-Party Risk Assessment, 37)", "", "", "Internal", "", ""),
       ("Source Resilience Test", "Resilience test whose vulnerability raised the issue.", "Issue", "Reference (Resilience Test, 37)", "", "", "ISO 22301", "", ""),
       ("Source Vulnerability Finding", "41 vulnerability finding the issue covers, including by risk acceptance.", "Issue", "Reference (Vulnerability Finding, 41)", "", "", "Internal", "", "", "41 is asked to drop Risk Acceptance Issue (proposals_37)."),
       ("Issue Rating", "Rating of the issue; the only rating of the remediation.", "Issue", "Code", "Shared: Severity", "High", "Internal", "", "Y", "An audit finding keeps its own rating, which the issue owner never overwrites (CD-247)."),
       ("Issue Related Risk", "Enterprise risk whose control the issue weakens.", "Issue", "Reference (Enterprise Risk, 37)", "", "RISK-00412", "Internal", "", ""),
       ("Issue Owner", "Employee accountable for remediation.", "Issue", "Reference (Employee)", "", "EMP-02231", "Internal", "", "", EMP),
       ("Issue Due Date", "Date by which the issue must be remediated.", "Issue", "Date", "ISO 8601", "2026-12-31", "Internal", "", "Y", "Derived within 37 for audit-sourced issues: equals Audit Finding Due Date of the Source Audit Finding."),
       ("Issue Status", "Workflow status of the issue.", "Issue", "Code", "Shared: Case Status", "In Progress", "Internal", "", "Y"),
     ]),
     ("Issue Action", [
       ("Action Issue", "Issue the action belongs to.", "Issue Action", "Reference (Risk Issue, 37)", "", "ISSUE-2026-00877", "Internal", "", ""),
       ("Issue Action Sequence", "Order of the action within the issue.", "Issue Action", "Integer", "", "1", "Internal", "", ""),
       ("Issue Action Type", "Kind of action, including risk acceptance.", "Issue Action", "Code", "Issue Action Type", "Control Enhancement", "Internal", "", ""),
       ("Issue Action Description", "What is to be done.", "Issue Action", "Text", "", "Extend the stale override report to fixed income and add a completeness check on the vendor file.", "Internal", "", ""),
       ("Issue Action Owner", "Employee responsible for the action.", "Issue Action", "Reference (Employee)", "", "EMP-02231", "Internal", "", "", EMP),
       ("Issue Action Due Date", "Date the action must be completed.", "Issue Action", "Date", "ISO 8601", "2026-11-30", "Internal", "", ""),
       ("Issue Action Completed Date", "Date the action was completed, with evidence.", "Issue Action", "Date", "ISO 8601", "", "Internal", "", "Y"),
       ("Risk Acceptance Approver", "Senior employee who approved a risk acceptance, for actions of type Risk Acceptance.", "Issue Action", "Reference (Employee)", "", "", "Internal", "", "", EMP),
       ("Risk Acceptance Expiry Date", "Date a risk acceptance lapses and must be renewed or remediated.", "Issue Action", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Operational Resilience & Continuity", "ER-RES",
  "Business continuity and operational resilience of the broker-dealer, the adviser and fund operations: the critical or important functions that must keep running (the critical activities and operations of the interagency guidance), the resources they depend on, business impact analyses, business continuity plans (FINRA Rule 4370; the adviser's and funds' compliance-program plans under SEC Rules 206(4)-7 and 38a-1) and resilience tests (CD-249). ICT continuity and disaster recovery plans and technical test results are 41's; outsourcing arrangements are 40's.",
  [
   ("Business Services & Functions", "The critical functions that must keep running and the resources they depend on.", [
     ("Critical or Important Function", [
       ("Critical Function Code", "Firm code of the function, unique across entities and written without a hyphenated stem.", "Function", "Identifier", "", "CIF 03", "Interagency TPRM Guidance", "Interagency Sound Practices", "Y"),
       ("Critical Function Name", "Name of the function.", "Function", "Text", "", "Portfolio valuation and NAV calculation for the firm's mutual funds and ETFs", "Interagency Sound Practices", "", ""),
       ("Designating Entity", "Internal legal entity that designates the function as critical (the broker-dealer, the adviser or the trust company).", "Function", "Reference (Legal Entity)", "", "LEN-0012", "Internal", "", ""),
       ("Function Effective From", "Date the designation took effect.", "Function", "Date", "ISO 8601", "2025-01-01", "Internal", "", ""),
       ("Function Effective To", "Date the designation ended.", "Function", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Resilience Resource Mapping", [
       ("Mapped Function", "Critical or important function the resource supports.", "Resource Mapping", "Reference (Critical or Important Function, 37)", "", "CIF 03", "Interagency Sound Practices", "FINRA Rule 4370", ""),
       ("Resilience Resource Type", "Kind of resource mapped; exactly one typed resource column is filled per row.", "Resource Mapping", "Code", "Resilience Resource Type", "Application", "FINRA Rule 4370", "", ""),
       ("Mapped Workforce Position", "20 workforce position the function depends on; its Key-Person Risk Indicator is read, not copied.", "Resource Mapping", "Reference (Workforce Position, 20)", "", "", "Internal", "", "", "CD-249 resolves the 20 'input to 37' note."),
       ("Mapped Business Process", "Business capability the function depends on.", "Resource Mapping", "Code", "Firm-defined (business capability map code)", "", "Internal", "", "", CAP),
       ("Mapped Application", "41 application the function depends on (a mission critical system under FINRA Rule 4370 for the broker-dealer).", "Resource Mapping", "Reference (Application, 41)", "", "APPL-00412", "Internal", "", ""),
       ("Mapped IT Service", "41 IT service the function depends on.", "Resource Mapping", "Reference (IT Service, 41)", "", "SVC 0118", "Internal", "", "", "41 holds no dependency of its services on 37 (CD-268)."),
       ("Mapped Site", "Office or site the function depends on, including alternate locations.", "Resource Mapping", "Reference (Office Location, 09)", "", "", "Internal", "", "", "09 keeps SITE-; 44 Site Profile profiles it (CD-279)."),
       ("Mapped Supplier Engagement", "40 supplier engagement the function depends on (critical business constituents, banks and counterparties under FINRA Rule 4370).", "Resource Mapping", "Reference (Supplier Engagement, 40)", "", "", "Internal", "", ""),
       ("Mapped Data Asset", "21 data asset the function depends on.", "Resource Mapping", "Reference (Data Asset, 21)", "", "", "Internal", "", ""),
       ("Mapping Effective From", "Date the dependency was recorded as current.", "Resource Mapping", "Date", "ISO 8601", "2026-06-30", "Internal", "", ""),
       ("Mapping Effective To", "Date the dependency ended.", "Resource Mapping", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Continuity & Testing", "Business impact analyses, continuity plans and resilience tests.", [
     ("Business Impact Analysis", [
       ("Analyzed Business Process", "Business capability analyzed.", "BIA", "Code", "Firm-defined (business capability map code)", "C-08.03 Fund Accounting and NAV", "ISO 22301", "", "Y", CAP),
       ("BIA Date", "Date the analysis was approved.", "BIA", "Date", "ISO 8601", "2026-05-31", "ISO 22301", "", "Y"),
       ("Recovery Time Objective Hours", "Target time to resume the process after disruption.", "BIA", "Decimal", "", "4", "ISO 22301", "", "Y"),
       ("Recovery Point Objective Hours", "Maximum data loss the process can accept, in hours.", "BIA", "Decimal", "", "1", "ISO 22301", "", ""),
       ("Maximum Tolerable Period of Disruption Hours", "Time after which the process's disruption becomes unacceptable.", "BIA", "Decimal", "", "24", "ISO 22301", "", "Y"),
     ]),
     ("Business Continuity Plan", [
       ("Business Continuity Plan Code", "Firm code of the plan, written without a hyphenated stem.", "BCP", "Identifier", "", "BCP 014", "ISO 22301", "FINRA Rule 4370", "Y"),
       ("Business Continuity Plan Version", "Version of the plan.", "BCP", "Integer", "", "6", "ISO 22301", "", "Y"),
       ("Plan Scope", "Processes, sites and teams the plan covers.", "BCP", "Text", "", "Fund accounting and NAV publication, Malvern and Charlotte sites", "ISO 22301", "FINRA Rule 4370", ""),
       ("Plan Invocation Criteria", "Conditions under which the plan is invoked.", "BCP", "Text", "", "Loss of either site or of the fund accounting platform for more than 2 hours", "ISO 22301", "", ""),
       ("Plan Owner", "Employee accountable for the plan.", "BCP", "Reference (Employee)", "", "EMP-30412", "ISO 22301", "", "", EMP),
       ("Plan Approval Status", "Approval state of the plan version.", "BCP", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("Plan Last Reviewed Date", "Date the plan was last reviewed.", "BCP", "Date", "ISO 8601", "2026-05-31", "ISO 22301", "FINRA Rule 4370", ""),
     ]),
     ("Resilience Test", [
       ("Resilience Test Reference", "Firm reference of the test, written without a hyphenated stem.", "Resilience Test", "Identifier", "", "RTEST 2026/011", "Internal", "", "Y"),
       ("Resilience Test Date", "Date the test was run.", "Resilience Test", "Date", "ISO 8601", "2026-07-15", "ISO 22301", "FINRA Rule 4370", "Y"),
       ("Resilience Test Type", "Kind of test.", "Resilience Test", "Code", "Resilience Test Type", "Scenario Test", "ISO 22301", "FINRA Rule 4370", ""),
       ("Tested Continuity Plan", "Continuity plan (code and version) exercised.", "Resilience Test", "Reference (Business Continuity Plan, 37)", "", "BCP 014 / 6", "ISO 22301", "", ""),
       ("Resilience Test Scenario", "Severe but plausible scenario tested.", "Resilience Test", "Text", "", "Fund accounting vendor unavailable for 36 hours at month end", "Interagency Sound Practices", "", ""),
       ("Source Security and Resilience Test", "41 technical test (DR failover, penetration test) whose result the test relies on.", "Resilience Test", "Reference (Security & Resilience Test, 41)", "", "SRT 2026-0031", "Internal", "", "", "Read by reference; the technical result is 41's (CD-249)."),
       ("Tolerance Met Indicator", "Whether the tested plan recovered the covered processes within their recovery time objectives (Business Impact Analysis) in the test.", "Resilience Test", "Boolean", "", "N", "ISO 22301", "FINRA Rule 4370", "Y", "Vulnerabilities are raised as Risk Issues of source type Resilience Test."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Third-Party Risk", "ER-TPR",
  "The enterprise third-party risk register (CD-090, CD-248): the residual risk of each third party per 40 supplier engagement and assessment cycle, by risk domain. The inherent criticality tier, exit plans and the outsourcing register are 40's; data-vendor and custody specializations stay in 14 and 28 and hold the reference to this assessment.",
  [
   ("Third-Party Risk Assessments", "Residual risk of a third party per engagement and cycle.", [
     ("Third-Party Risk Assessment", [
       ("Third-Party Risk Assessment Reference", "Firm reference of the assessment, written without a hyphenated stem.", "TP Assessment", "Identifier", "", "TPRA 2026/00412", "Internal", "", "Y"),
       ("Assessed Supplier Engagement", "40 supplier engagement assessed; its inherent tier is read from 40 Supplier Risk Tiering, never copied.", "TP Assessment", "Reference (Supplier Engagement, 40)", "", "VENG-001877", "Interagency TPRM Guidance", "", ""),
       ("Assessed Third Party", "Third party assessed.", "TP Assessment", "Reference (Party)", "", "PTY-500210", "Interagency TPRM Guidance", "", "", "Row rule: Derived copy (40) of the supplier of the Assessed Supplier Engagement; mastered here only for onboarding assessments of a prospective supplier with no engagement yet."),
       ("Third-Party Assessment Type", "Trigger and kind of assessment.", "TP Assessment", "Code", "Third-Party Assessment Type", "Periodic", "Interagency TPRM Guidance", "FINRA Regulatory Notice 21-29", "Y"),
       ("Third-Party Residual Risk Rating", "Residual risk of the third party for the engagement after its controls and the firm's mitigants.", "TP Assessment", "Code", "Shared: Risk Rating", "Medium", "Interagency TPRM Guidance", "", "Y", "Source of the proposed 14 Vendor Risk Assessment Residual Risk Rating derived copy (CD-248)."),
       ("Exit Feasibility", "Risk function's residual judgment of whether the 40 exit plan for the engagement would work.", "TP Assessment", "Code", "Exit Feasibility", "Exitable with Disruption", "Interagency TPRM Guidance", "", "", "The exit plan itself is 40 Exit Plan."),
       ("Third-Party Assessor", "Employee who performed the assessment.", "TP Assessment", "Reference (Employee)", "", "EMP-30588", "Internal", "", "", EMP),
       ("Third-Party Assessment Completed Date", "Date the assessment was concluded.", "TP Assessment", "Date", "ISO 8601", "2026-04-30", "Internal", "", "Y"),
       ("Third-Party Next Assessment Due Date", "Date the next periodic assessment is due.", "TP Assessment", "Date", "ISO 8601", "2027-04-30", "Internal", "", ""),
     ]),
     ("Third-Party Risk Domain Result", [
       ("Result Assessment", "Third-party risk assessment the result belongs to.", "TP Domain Result", "Reference (Third-Party Risk Assessment, 37)", "", "TPRA 2026/00412", "Internal", "", ""),
       ("Third-Party Risk Domain", "Risk domain assessed.", "TP Domain Result", "Code", "Third-Party Risk Domain", "Information Security", "Interagency TPRM Guidance", "", "Y"),
       ("Domain Risk Rating", "Residual rating for the domain; 'Prohibited' means the domain alone rules out the relationship.", "TP Domain Result", "Code", "Shared: Risk Rating", "Medium", "Interagency TPRM Guidance", "", ""),
       ("Domain Evidence Assurance Report", "14 assurance report relied on, for data vendors.", "TP Domain Result", "Reference (Assurance Report, 14)", "", "VRA-002311 / SOC 2 Type II / 2026-06-30", "AICPA SOC 2", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Model Risk Management", "ER-MRM",
  "The firm's model inventory and its governance: each model and version, its tier, its independent validations and its ongoing performance monitoring (CD-246). Model vendor, owner, governance status and version are mastered here; the models as used (factors, methods, parameters) stay in 31, 32, 23, 22 and 34, and AI use cases and AI risk classification stay in 21.",
  [
   ("Model Inventory", "Each model in use or development, versioned and tiered.", [
     ("Model Inventory Entry", [
       ("Model ID", "Enterprise identifier of the model, stable across versions.", "Model", "Identifier", "", "MODEL-0412", "SR 26-2", "", "Y"),
       ("Model Version", "Version of the model; a material change creates a new version, and a consumer's version (for example 31 Risk Model Version) equals it.", "Model", "Integer", "", "3", "SR 26-2", "", "Y", "Consumers reference the model as 'MODEL-0412 / 3' (proposals_37)."),
       ("Model Name", "Business name of the model.", "Model", "Text", "", "Global equity long-term factor risk model", "Internal", "", ""),
       ("Model Type", "Kind of model by what it does.", "Model", "Code", "Model Type", "Investment Risk", "SR 26-2", "", "Y"),
       ("Model Purpose", "Business purpose and intended use of the model.", "Model", "Text", "", "Ex-ante tracking error and VaR for US registered funds.", "SR 26-2", "", ""),
       ("Model Owner", "Employee accountable for the model's use.", "Model", "Reference (Employee)", "", "EMP-30412", "SR 26-2", "", "Y", EMP),
       ("Model Vendor", "Vendor that supplies the model; blank for a model built in house, which is how in-house models are identified.", "Model", "Reference (Party)", "", "PTY-100512", "SR 26-2", "", ""),
       ("Model Use Status", "Whether the model version may be used.", "Model", "Code", "Shared: Record Status", "Active", "SR 26-2", "", ""),
     ]),
     ("Model Tier Assignment", [
       ("Tiered Model", "Model the tier applies to.", "Model Tier", "Reference (Model Inventory Entry, 37)", "", "MODEL-0412", "SR 26-2", "", ""),
       ("Model Tier", "Risk tier that sets validation depth and frequency.", "Model Tier", "Code", "Model Tier", "Tier 1", "SR 26-2", "", "Y"),
       ("Model Materiality", "Materiality of the model's use to the firm and its clients; High means more model risk.", "Model Tier", "Code", "Assessment Level", "High", "Internal", "SR 26-2", ""),
       ("Model Complexity", "Complexity of the model; High means more model risk.", "Model Tier", "Code", "Assessment Level", "Medium", "Internal", "SR 26-2", ""),
       ("Model Uncertainty", "Uncertainty of the model's inputs and outputs; High means more model risk.", "Model Tier", "Code", "Assessment Level", "Medium", "Internal", "SR 26-2", ""),
       ("Tier Effective From", "Date the tier took effect.", "Model Tier", "Date", "ISO 8601", "2025-01-01", "Internal", "", ""),
       ("Tier Effective To", "Date the tier was superseded.", "Model Tier", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Model Validation & Monitoring", "Independent validation and ongoing monitoring of each model version.", [
     ("Model Validation", [
       ("Validated Model", "Model (and version) validated.", "Model Validation", "Reference (Model Inventory Entry, 37)", "", "MODEL-0412 / 3", "SR 26-2", "", ""),
       ("Model Validation Sequence", "Order of the validation among validations of the version.", "Model Validation", "Integer", "", "2", "Internal", "", ""),
       ("Model Validation Type", "Reason for the validation.", "Model Validation", "Code", "Model Validation Type", "Periodic", "SR 26-2", "", ""),
       ("Internal Validator", "Employee of the independent validation team who led the validation.", "Model Validation", "Reference (Employee)", "", "EMP-30544", "SR 26-2", "", "", EMP),
       ("External Validator", "Third party that performed the validation, where outsourced.", "Model Validation", "Reference (Party)", "", "", "SR 26-2", "", "", "Party Role Type 'External Model Validator' proposed (CD-143)."),
       ("Model Validation Completed Date", "Date the validation report was issued.", "Model Validation", "Date", "ISO 8601", "2026-06-30", "SR 26-2", "", "Y"),
       ("Model Validation Outcome", "Conclusion of the validation.", "Model Validation", "Code", "Model Validation Outcome", "Approved with Conditions", "SR 26-2", "", "Y", "Findings are Risk Issues of source type Model Validation."),
       ("Model Validation Conditions", "Conditions or restrictions on use set by the validation.", "Model Validation", "Text", "", "Not approved for private credit portfolios until a spread factor is added.", "SR 26-2", "", ""),
     ]),
     ("Model Performance Monitoring", [
       ("Monitored Model", "Model (and version) monitored.", "Model Monitoring", "Reference (Model Inventory Entry, 37)", "", "MODEL-0412 / 3", "SR 26-2", "", ""),
       ("Monitoring Period End Date", "Last day of the period monitored.", "Model Monitoring", "Date", "ISO 8601", "2026-09-30", "SR 26-2", "", "Y"),
       ("Monitoring Test", "Firm test applied to the model's outputs.", "Model Monitoring", "Code", "Firm-defined (model monitoring test)", "VaR exceptions count", "SR 26-2", "", ""),
       ("Monitoring Threshold Breached Indicator", "Whether the test result breached its threshold.", "Model Monitoring", "Boolean", "", "N", "SR 26-2", "", "Y"),
       ("Back-Test Evidence", "31 VaR back-tests relied on in the period, where the model is a risk model.", "Model Monitoring", "Reference (VaR Back-Test, 31) (multi)", "", "PORT-000412 / Global Equity Long-Term 2024 / 3 / 2026-09-30 / Actual", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Internal Audit", "ER-AUD",
  "The third line's record: the audit universe, the annual audit plan, engagements, findings and the validations that close them. Owned by the Chief Audit Executive, distinct from the risk-owned families, so its independence rests on ownership (CD-247; SME question 1). Audit committee approval of the plan is linked from 39 Corporate Resolution Subject Link.",
  [
   ("Audit Universe & Plan", "What can be audited and what the plan covers.", [
     ("Auditable Entity", [
       ("Auditable Entity Code", "Firm code of the audit universe entry, written without a hyphenated stem.", "Auditable Entity", "Identifier", "", "AUE 0118", "IIA GIAS 2024", "", "Y", CAO),
       ("Auditable Entity Name", "Name of the unit, process, entity or third party.", "Auditable Entity", "Text", "", "Fund accounting and NAV oversight", "IIA GIAS 2024", "", ""),
       ("Auditable Entity Type", "Kind of auditable entity.", "Auditable Entity", "Code", "Auditable Entity Type", "Process", "IIA GIAS 2024", "", ""),
       ("Covered Org Unit", "Org unit the entry covers.", "Auditable Entity", "Reference (Org Unit)", "", "OU-0217", "Internal", "", ""),
       ("Covered Legal Entity", "Internal legal entity the entry covers.", "Auditable Entity", "Reference (Legal Entity)", "", "LEN-0021", "Internal", "", ""),
       ("Covered Third Party", "Third party the entry covers, for entries of type Third Party.", "Auditable Entity", "Reference (Party)", "", "", "IIA GIAS 2024", "", ""),
       ("Inherent Audit Risk", "Internal Audit's assessment of the entry's inherent risk for planning.", "Auditable Entity", "Code", "Shared: Risk Rating", "High", "IIA GIAS 2024", "", "Y", "'Prohibited' is not used for auditable entities."),
       ("Audit Cycle Months", "Maximum interval between audits of the entry.", "Auditable Entity", "Integer", "", "24", "IIA GIAS 2024", "", ""),
       ("Auditable Entity Effective From", "Date the entry was added to the universe.", "Auditable Entity", "Date", "ISO 8601", "2023-01-01", "Internal", "", ""),
       ("Auditable Entity Effective To", "Date the entry was removed from the universe.", "Auditable Entity", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Audit Plan", [
       ("Audit Plan Year", "Year the plan covers.", "Audit Plan", "Integer", "", "2026", "IIA GIAS 2024", "", "Y", CAO),
       ("Audit Plan Version", "Version of the plan; a change approved mid-year creates a new version.", "Audit Plan", "Integer", "", "2", "IIA GIAS 2024", "", "Y"),
       ("Audit Plan Approval Status", "Whether the audit committee has approved the plan version; the approval itself is linked from 39 Corporate Resolution Subject Link.", "Audit Plan", "Code", "Shared: Approval Status", "Approved", "IIA GIAS 2024", "", "", "Derived copy (39) of the resolution outcome through Subject Audit Plan."),
       ("Co-Sourced Provider", "External firm that supplies auditors under co-sourcing.", "Audit Plan", "Reference (Party)", "", "", "Internal", "", "", "Party Role Type 'Co-Sourced Internal Audit Provider' proposed (CD-143)."),
     ]),
   ]),
   ("Engagements & Findings", "Each audit, what it found and how findings are closed.", [
     ("Audit Engagement", [
       ("Audit Engagement ID", "Enterprise identifier of the engagement.", "Audit Engagement", "Identifier", "", "AUDIT-2026-014", "IIA GIAS 2024", "", "Y", CAO),
       ("Engagement Audit Plan", "Audit plan (year and version) the engagement belongs to.", "Audit Engagement", "Reference (Audit Plan, 37)", "", "2026 / 2", "IIA GIAS 2024", "", ""),
       ("Audit Engagement Type", "Kind of engagement.", "Audit Engagement", "Code", "Audit Engagement Type", "Assurance", "IIA GIAS 2024", "", ""),
       ("Covered Auditable Entities", "Audit universe entries the engagement covers.", "Audit Engagement", "Reference (Auditable Entity, 37) (multi)", "", "AUE 0118", "IIA GIAS 2024", "", ""),
       ("Engagement Lead", "Auditor who leads the engagement.", "Audit Engagement", "Reference (Employee)", "", "EMP-40112", "IIA GIAS 2024", "", "", EMP),
       ("Fieldwork Start Date", "Date fieldwork started.", "Audit Engagement", "Date", "ISO 8601", "2026-08-03", "IIA GIAS 2024", "", ""),
       ("Audit Report Issued Date", "Date the final report was issued; ends the engagement.", "Audit Engagement", "Date", "ISO 8601", "2026-09-25", "IIA GIAS 2024", "", "Y"),
       ("Overall Audit Rating", "Overall opinion of the engagement.", "Audit Engagement", "Code", "Audit Rating", "Needs Improvement", "IIA GIAS 2024", "", "Y"),
     ]),
     ("Audit Finding", [
       ("Audit Finding ID", "Enterprise identifier of the finding.", "Audit Finding", "Identifier", "", "AUDF-2026-014-03", "IIA GIAS 2024", "", "Y", CAO),
       ("Finding Engagement", "Engagement that raised the finding.", "Audit Finding", "Reference (Audit Engagement, 37)", "", "AUDIT-2026-014", "IIA GIAS 2024", "", ""),
       ("Audit Finding Rating", "Severity of the finding as rated by Internal Audit; never overwritten by the issue owner.", "Audit Finding", "Code", "Shared: Severity", "High", "IIA GIAS 2024", "", "Y"),
       ("Finding Condition", "What the auditors found.", "Audit Finding", "Text", "", "Stale price overrides on fixed income were not covered by the daily review.", "IIA GIAS 2024", "", ""),
       ("Finding Criteria", "Standard, policy or control the condition was assessed against.", "Audit Finding", "Text", "", "Pricing policy section 4.2; control CNTRL-004120 v3", "IIA GIAS 2024", "", ""),
       ("Finding Root Cause", "Why the condition exists.", "Audit Finding", "Text", "", "Report scope not updated after vendor file change.", "IIA GIAS 2024", "", ""),
       ("Audit Finding Due Date", "Remediation date agreed with management; the issue's due date copies it.", "Audit Finding", "Date", "ISO 8601", "2026-12-31", "IIA GIAS 2024", "", "Y"),
     ]),
     ("Finding Closure Validation", [
       ("Validated Finding", "Audit finding whose remediation was validated.", "Closure Validation", "Reference (Audit Finding, 37)", "", "AUDF-2026-014-03", "IIA GIAS 2024", "", "", CAO),
       ("Validation Attempt Sequence", "Order of the validation attempt for the finding.", "Closure Validation", "Integer", "", "1", "IIA GIAS 2024", "", ""),
       ("Closure Validated By", "Auditor who validated the remediation.", "Closure Validation", "Reference (Employee)", "", "EMP-40112", "IIA GIAS 2024", "", "", EMP),
       ("Closure Validation Date", "Date the attempt was concluded; the date of the attempt with outcome Validated - Closed is the only date on which a finding closes.", "Closure Validation", "Date", "ISO 8601", "2026-10-05", "IIA GIAS 2024", "", "Y"),
       ("Finding Validation Outcome", "Result of the attempt.", "Closure Validation", "Code", "Finding Validation Outcome", "Not Validated - Remains Open", "IIA GIAS 2024", "", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
CL = {
 # Enterprise shared lists are cited directly as 'Shared: <name>'; the local copies were removed at the Stage 4 consolidation (CD-283).
 # Local lists
 "Risk Matrix Score": ("Internal (COSO ERM 2017 likelihood and impact matrix)", [("1 - Very Low",""),("2 - Low",""),("3 - Moderate",""),("4 - High",""),("5 - Very High","")]),
 "Basel Event Type Level 1": ("Basel Committee (Basel II Annex 9; Basel III OPE25)", [("Internal Fraud",""),("External Fraud",""),("Employment Practices and Workplace Safety",""),("Clients, Products and Business Practices",""),("Damage to Physical Assets",""),("Business Disruption and System Failures",""),("Execution, Delivery and Process Management","")]),
 "Basel Event Type Level 2": ("Basel Committee (Basel II Annex 9; Basel III OPE25)", [("Unauthorized Activity","Internal Fraud"),("Theft and Fraud (Internal)","Internal Fraud"),("Theft and Fraud (External)","External Fraud"),("Systems Security","External Fraud"),("Employee Relations","Employment Practices and Workplace Safety"),("Safe Environment","Employment Practices and Workplace Safety"),("Diversity and Discrimination","Employment Practices and Workplace Safety"),("Suitability, Disclosure and Fiduciary","Clients, Products and Business Practices"),("Improper Business or Market Practices","Clients, Products and Business Practices"),("Product Flaws","Clients, Products and Business Practices"),("Selection, Sponsorship and Exposure","Clients, Products and Business Practices"),("Advisory Activities","Clients, Products and Business Practices"),("Disasters and Other Events","Damage to Physical Assets"),("Systems","Business Disruption and System Failures"),("Transaction Capture, Execution and Maintenance","Execution, Delivery and Process Management"),("Monitoring and Reporting","Execution, Delivery and Process Management"),("Customer Intake and Documentation","Execution, Delivery and Process Management"),("Customer / Client Account Management","Execution, Delivery and Process Management"),("Trade Counterparties","Execution, Delivery and Process Management"),("Vendors and Suppliers","Execution, Delivery and Process Management")]),
 "Cause Category": ("Internal (BCBS PSMOR people, process, systems, external events)", [("People - Human Error",""),("People - Misconduct",""),("People - Capacity or Key Person",""),("Process Design",""),("Process Execution",""),("Systems - Application Failure",""),("Systems - Infrastructure Failure",""),("Systems - Cyber Attack",""),("Data Quality",""),("Third Party Failure",""),("External Event",""),("Under Investigation","Cause not yet established")]),
 "Risk Assessment Basis": ("Internal", [("RCSA","Risk and control self-assessment campaign"),("Top-Down","Senior management or risk committee assessment"),("Ad Hoc","Triggered by an incident, change or finding"),("Second Line Challenge","Risk function override of a self-assessment")]),
 "Risk Trend": ("Internal", [("Increasing",""),("Stable",""),("Decreasing","")]),
 "Appetite Category": ("Internal (COSO ERM 2017); the description holds the code used in Appetite Statement Code", [("Operational Errors","OPS"),("Conduct and Client Outcomes","CON"),("Regulatory Compliance","REG"),("Financial Crime","FCR"),("Technology and Cyber","TEC"),("Third Party","TPR"),("Operational Resilience","RES"),("Model","MOD"),("Reputation","REP"),("Capital and Liquidity","CAP; statements 43 measures its capital profile against")]),
 "Assessment Level": ("Internal", [("Low",""),("Medium",""),("High","")]),
 "Control Type": ("COSO IC 2013", [("Preventive",""),("Detective",""),("Corrective","")]),
 "Control Nature": ("PCAOB AS 2201 / Internal", [("Manual",""),("Automated",""),("IT-Dependent Manual","Manual control that relies on system-generated information")]),
 "Control Execution Record Type": ("Internal (CD-243)", [("29 TA Control Check","TACK-"),("27 NAV Control Check",""),("06 Reconciliation","RCN-"),("19 Close Task",""),("10 Control","Distribution finance reconciliation"),("33 Compliance Check Run","CCHK-"),("21 Data Quality Result","Data quality rules operating as controls"),("Off-System Evidence","Evidence held outside a domain record")]),
 "Control Test Type": ("PCAOB AS 2201 / COSO IC 2013", [("Design Effectiveness",""),("Operating Effectiveness",""),("Remediation Retest","")]),
 "Testing Line": ("Internal (three lines model)", [("First Line","Business self-testing"),("Compliance","38 compliance monitoring (CD-243)"),("Risk","Second line operational risk testing")]),
 "Control Test Result": ("Internal", [("Effective",""),("Effective with Exceptions",""),("Ineffective",""),("Not Tested","Test not performed in the period"),("Control Not Operated","Control had no occasion to operate in the period")]),
 "Incident Source Type": ("Internal (CD-244, CD-245)", [("Trade Error","25"),("NAV Error Case","27"),("Investment Breach","33; only with operational failure or loss"),("Risk Limit Exceedance","31; only with operational failure or loss"),("Servicing Error","13"),("IT Incident","41, including security incidents"),("Physical Security Incident","44"),("Plan Correction","16"),("AP Order Error","29"),("Account Monitoring Alert","29; fraud"),("Health and Safety Incident","44"),("Model Delivery Error","01 model portfolio")]),
 "Incident Notification Regime": ("SEC Regulation S-P / state breach notification laws / FINRA Rule 4530 / Internal", [("Regulation S-P Customer Notification","Notice to affected individuals of unauthorized access to or use of sensitive customer information (17 CFR 248.30; the 2024 amendments are in force)"),("State Breach Notification","Notice to residents or a state attorney general under a state data breach law"),("FINRA Rule 4530 Report","Only where the incident also involves a Rule 4530 reportable event (for example a violation or a specified customer complaint); operational incidents as such are not 4530 events"),("SEC or Other Regulator Notification","For example an SEC or state securities regulator notification"),("Internal","Internal escalation only, no external notice")]),
 "Incident Notification Stage": ("Internal", [("Initial",""),("Update or Amendment","Supplementary notice or amended filing"),("Final","Closing report")]),
 "Loss Amount Component": ("Basel OPE25 / Internal", [("Gross Loss",""),("Provision","Reserve booked before settlement"),("Third-Party Recovery",""),("Gain","Operational gain, recorded where policy requires"),("Near-Miss Estimate","Not booked; SME question 3")]),
 "Loss Status": ("Internal", [("Open","Further amounts expected"),("Closed","No further amounts expected")]),
 "Issue Source Type": ("Internal (CD-247, CD-253)", [("Self-Identified","No source column"),("Control Test",""),("Operational Incident",""),("Model Validation",""),("Audit Finding",""),("Regulatory Finding","38 Examination Finding"),("Compliance Program Review","38"),("Third-Party Assessment",""),("Resilience Test",""),("Vulnerability Finding","41")]),
 "Issue Action Type": ("Internal", [("Control Enhancement",""),("New Control",""),("Process Change",""),("System Change",""),("Training",""),("Risk Acceptance","Approver and expiry required")]),
 "Resilience Resource Type": ("Internal / FINRA Rule 4370", [("People","20 workforce position"),("Process","Business capability"),("IT Service","41"),("Application","41"),("Site","09 / 44"),("Third Party","40 supplier engagement"),("Information","21 data asset")]),
 "Resilience Test Type": ("ISO 22301 / FINRA Rule 4370", [("Scenario Test","Severe but plausible scenario against the recovery objectives"),("BCP Exercise",""),("Tabletop Exercise",""),("Call Tree Test",""),("DR Test Result Received","41 technical test read by reference")]),
 "Third-Party Assessment Type": ("Interagency TPRM Guidance", [("Onboarding",""),("Periodic",""),("Triggered","Incident, change of control or material change"),("Expert Network MNPI Controls","Source of 23 Expert Network Due Diligence Date (CD-248)"),("Exit","")]),
 "Third-Party Risk Domain": ("14 Vendor Risk Domain values plus Conduct and MNPI (merge proposed in proposals_37)", [("Information Security",""),("Business Continuity & Resilience",""),("Data Privacy",""),("Financial Viability",""),("Legal & Regulatory",""),("Concentration",""),("Subcontracting / Fourth Party",""),("Reputational",""),("Forced Labor / Human Rights","Forced-labor and human-rights exposure in the supplier chain (US Tariff Act Section 307, UFLPA; firm policy)."),("Conduct and MNPI","Expert networks and research providers")]),
 "Exit Feasibility": ("Internal (Interagency TPRM Guidance, termination)", [("Readily Exitable",""),("Exitable with Disruption",""),("Not Exitable","")]),
 "Model Type": ("SR 26-2 / Internal", [("Investment Risk","Market, credit, counterparty and liquidity risk models"),("Valuation",""),("Performance Attribution",""),("Portfolio Optimizer",""),("Capital Market Assumptions","Model that produces the 24 capital-market assumption sets (CMASET-)"),("Portfolio Construction Algorithm","Rules engine or algorithm that takes 24 investment decisions or builds 46 managed account trades without a person"),("Trading Algorithm",""),("Research Signal",""),("AI / Machine Learning",""),("ESG Scoring",""),("Financial Forecasting","")]),
 "Model Tier": ("Internal (SR 26-2 risk-based tiering)", [("Tier 1","Highest risk; annual validation"),("Tier 2",""),("Tier 3","Lowest risk")]),
 "Model Validation Type": ("SR 26-2", [("Initial",""),("Periodic",""),("Change","Validation of a material change")]),
 "Model Validation Outcome": ("SR 26-2 / Internal", [("Approved",""),("Approved with Conditions",""),("Rejected","")]),
 "Auditable Entity Type": ("IIA GIAS 2024", [("Org Unit",""),("Process",""),("Legal Entity",""),("Third Party",""),("Technology","")]),
 "Audit Engagement Type": ("IIA GIAS 2024", [("Assurance",""),("Advisory",""),("Follow-Up",""),("Regulatory-Requested","")]),
 "Audit Rating": ("Internal", [("Satisfactory",""),("Needs Improvement",""),("Unsatisfactory","")]),
 "Finding Validation Outcome": ("IIA GIAS 2024 / Internal", [("Validated - Closed",""),("Not Validated - Remains Open",""),("Closed - Risk Accepted","Through an Issue Action of type Risk Acceptance")]),
}

# ---------------------------------------------------------------------------
REL = [
 ("Risk Taxonomy Category","is the parent of","Risk Taxonomy Category","1 : 0..n","Levels 1-3 within a taxonomy version."),
 ("Enterprise Risk","is classified under","Risk Taxonomy Category","n : 1","Level 3 category."),
 ("Enterprise Risk","is owned by","Org Unit [09] / Employee [20]","n : 1",""),
 ("Enterprise Risk","is rated by","Risk Assessment","1 : 0..n","Dated, never overwritten."),
 ("Risk Assessment","may be made in","RCSA Campaign","n : 0..1",""),
 ("KRI Threshold","sits inside","Risk Appetite Statement","n : 0..1","The only KRI-appetite link."),
 ("Capital Profile [43]","is bounded by","Risk Appetite Statement","n : 0..1","Appetite Category Capital and Liquidity; 43 holds the reference."),
 ("Enterprise Risk","is mitigated by","Control via Risk Control Link","n : n","Effective-dated."),
 ("Control","names the record type of its executions in","29 / 27 / 06 / 19 / 10 / 33 / 21","","By record type only; executions stay in their domain (CD-243)."),
 ("Control","is owned by","Legal Entity [09]","n : 0..1","Trustee controls of CITs."),
 ("Control Test","samples","Domain execution records","n : n","By owner-format key, as evidence only."),
 ("Operational Incident","is revealed by","Incident Source Record","1 : 0..n","None for a self-identified incident."),
 ("Incident Source Record","references","Trade Error [25] / NAV Error Case [27] / Servicing Error [13] / Plan Correction [16]","n : 1","No facts copied."),
 ("Incident Source Record","references","Investment Breach [33] / Risk Limit Exceedance [31]","n : 1","Only with operational failure or loss (CD-244)."),
 ("Incident Source Record","references","IT Incident [41] / Physical Security Incident [44] / Health & Safety Incident [44]","n : 1","Link held only here (CD-245)."),
 ("Incident Source Record","references","AP Creation / Redemption Order [29] / Account Monitoring Alert [29] / Model Portfolio [01]","n : 1",""),
 ("Operational Incident","has","Incident Classification","1 : 1","Basel levels 1-2, firm level 3, cause and near miss."),
 ("Operational Incident","is notified by","Incident Regulatory Notification","1 : 0..n","Regulation S-P customer and state breach notifications for customer-data incidents; FINRA Rule 4530 reports only where a 4530 event is involved; regime and stage on each row."),
 ("Operational Incident","gives rise to","Operational Loss Event","1 : 0..n",""),
 ("Operational Loss Event","has","Loss Event Amount","1 : 1..n","Gross loss borne by the firm; row rule."),
 ("Loss Event Amount","copies its amount from","Trade Error [25] / NAV Error Case [27] / Breach Loss Calculation [33] / Settlement Penalty [26]","n : 0..1","Firm-borne amount (CD-244)."),
 ("Operational Loss Event","sums its impact from","Shareholder Remediation [13] via Servicing Error [13]","n : 0..1","Sum by incident, not a per-row copy."),
 ("Insurance Claim [43]","recovers","Operational Loss Event","n : 1","Held on the claim only; recoveries read at claim level."),
 ("Loss Event Amount","is booked by","Journal Entry [19]","n : 0..1",""),
 ("Operational Loss Event","may arise from","Legal Matter [39]","n : 0..1","Settlements and fines."),
 ("Key Risk Indicator","may be defined on","Metric Definition [21]","n : 0..1","Definition and direction copied; observed values mastered here."),
 ("Key Risk Indicator","is observed as","KRI Observation","1 : 0..n",""),
 ("Risk Issue","is raised from","Audit Finding / Operational Incident / Control Test / Model Validation / Third-Party Risk Assessment / Resilience Test","n : 0..1","Link held once, on the issue."),
 ("Risk Issue","is raised from","Examination Finding [38] / Compliance Program Review [38] / Vulnerability Finding [41]","n : 0..1","Link held once, on the issue (program lead ruling 4)."),
 ("Risk Issue","is remediated by","Issue Action","1 : 1..n","Including risk acceptance."),
 ("Critical or Important Function","depends on","Workforce Position [20] / Application [41] / IT Service [41] / Office Location [09] / Supplier Engagement [40] / Data Asset [21] via Resilience Resource Mapping","n : n","Key-person flag read from 20."),
 ("Resilience Test","exercises","Business Continuity Plan","n : 0..1","Tested Continuity Plan; recovery objectives from the Business Impact Analysis."),
 ("Outsourcing Arrangement [40]","supports","Critical or Important Function","n : n","40 holds the reference (CD-249, CD-261; CW-940)."),
 ("Resilience Test","may rely on","Security & Resilience Test [41]","n : 0..1","DR results read by reference."),
 ("Third-Party Risk Assessment","assesses","Supplier Engagement [40] and its Party [02]","n : 1","Inherent tier is 40 Supplier Risk Tiering (CD-248)."),
 ("Vendor Risk Assessment [14]","specializes","Third-Party Risk Assessment","n : 0..1","14 holds the reference (proposed)."),
 ("Risk Model [31] / Attribution Model [32] / AI Use Case [21] / Fair Value Determination [22] / Firm ESG Assessment [34] / AI System Profile [41]","is inventoried as","Model Inventory Entry","n : 1","Consumer holds the reference (CD-246)."),
 ("Model Inventory Entry","is validated by","Model Validation","1 : 0..n",""),
 ("Model Performance Monitoring","relies on","VaR Back-Test [31]","n : n",""),
 ("Audit Engagement","covers","Auditable Entity","n : n",""),
 ("Audit Finding","is validated by","Finding Closure Validation","1 : 0..n","Repeat attempts until Validated - Closed."),
]

# ---------------------------------------------------------------------------
SRC = [
 ("COSO Enterprise Risk Management - Integrating with Strategy and Performance (2017)","COSO","https://www.coso.org/enterprise-risk-management","Licensed framework (summary public)","Risk register, risk statements, appetite and tolerance, assessment of severity","Enterprise Risk, Risk Assessment, Risk Appetite Statement",["COSO ERM 2017"]),
 ("COSO Internal Control - Integrated Framework (2013)","COSO","https://www.coso.org/internal-control","Licensed framework (summary public)","Control components and principles, control types, key controls","Control, Risk Control Link, Control Test",["COSO IC 2013"]),
 ("Basel Committee, Revisions to the Principles for the Sound Management of Operational Risk (2021)","BIS / BCBS","https://www.bis.org/bcbs/publ/d515.htm","Public","Risk identification and assessment, RCSA, KRIs, loss data, cause analysis","Risk Assessment, Key Risk Indicator, Cause Category",["BCBS PSMOR 2021"]),
 ("Basel Framework OPE25 Standardised approach (loss data standards)","BIS / BCBS","https://www.bis.org/basel_framework/chapter/OPE/25.htm","Public","Loss data fields, gross loss, recoveries, dates","Operational Loss Event, Loss Event Amount",["Basel OPE25"]),
 ("Basel II: International Convergence of Capital Measurement and Capital Standards (2006), Annex 9 detailed loss event type classification","BIS / BCBS","https://www.bis.org/publ/bcbs128.htm","Public","Event types levels 1-2","Basel Event Type Level 1 and Level 2",["Basel II Annex 9"]),
 ("ORX Reference Taxonomy for operational and non-financial risk","ORX","https://managingrisktogether.orx.org","Member (public summary)","Level 1-2 cross-check of risk and event types, cause categories","Risk Taxonomy Category, Non-Financial Risk Type",["ORX Reference Taxonomy"]),
 ("Federal Reserve SR 26-2 Revised Guidance on Model Risk Management (2026-04-17, supersedes SR 11-7)","Board of Governors of the Federal Reserve System","https://www.federalreserve.gov/supervisionreg/srletters/sr2602.htm","Supervisory guidance (applied by analogy)","Model definition, inventory, validation, ongoing monitoring","Model Risk Management family",["SR 26-2"]),
 ("Federal Reserve SR 11-7 Supervisory Guidance on Model Risk Management (historical)","Board of Governors of the Federal Reserve System; OCC","https://www.federalreserve.gov/supervisionreg/srletters/sr1107.htm","Supervisory guidance (rescinded 2026-04-17 by SR 26-2, with SR 21-8)","Basis of the 21 and 31 model notes","Model Inventory Entry (history)",["SR 11-7"]),
 ("IIA Global Internal Audit Standards (2024)","The Institute of Internal Auditors","https://www.theiia.org/en/standards/2024-standards/global-internal-audit-standards/","Licensed standard (public summary)","Audit universe, plan, engagement, findings (condition, criteria, root cause), follow-up, independence","Internal Audit family",["IIA GIAS 2024"]),
 ("ISO 22301:2019 Business continuity management systems","ISO","https://www.iso.org/standard/75106.html","Licensed standard","BIA, RTO, RPO, MTPD, plans and exercises (structure only)","Business Impact Analysis, Business Continuity Plan, Resilience Test",["ISO 22301"]),
 ("NIST Cybersecurity Framework 2.0","NIST","https://www.nist.gov/cyberframework","Public","Govern, Respond and Recover functions at the 37-41 boundary","Incident Source Record (IT incidents)",["NIST CSF 2.0"]),
 ("Interagency Guidance on Third-Party Relationships: Risk Management (June 2023)","Federal Reserve, FDIC, OCC","https://www.federalreserve.gov/supervisionreg/srletters/SR2304.htm","Supervisory guidance","Third-party lifecycle, due diligence, ongoing monitoring, risk domains","Third-Party Risk family",["Interagency TPRM Guidance"]),
 ("FINRA Regulatory Notice 21-29 (vendor management and outsourcing)","FINRA","https://www.finra.org/rules-guidance/notices/21-29","Regulatory guidance","Broker-dealer supervision of outsourced activities and vendor due diligence; the broker-dealer's own counterpart of the bank interagency guidance","Third-Party Risk family",["FINRA Regulatory Notice 21-29"]),
 ("SEC Rule 38a-1 and Advisers Act Rule 206(4)-7","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.38a-1","Regulation","Compliance program testing performed by 38 (testing line Compliance); business continuity as part of the adviser's and funds' compliance policies and procedures","Control Test, Business Continuity Plan",["SEC Rule 38a-1"]),
 ("FINRA Rule 4370 (Business Continuity Plans and Emergency Contact Information)","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/4370","SRO rule","Broker-dealer BCP elements: data backup and recovery, mission critical systems, alternate locations, critical business constituents, banks and counterparties, annual review","Business Continuity Plan, Resilience Resource Mapping, Resilience Test",["FINRA Rule 4370"]),
 ("FINRA Rule 4530 (Reporting Requirements)","FINRA","https://www.finra.org/rules-guidance/rulebooks/finra-rules/4530","SRO rule","Reporting of specified events: Rule 4530(a) events (violations, specified written customer complaints, disciplinary and criminal events), 4530(b) internal conclusions of violations and 4530(d) quarterly complaint statistics (confirm against the rule text). An operational incident leads to a 4530 report only where it also involves such an event","Incident Regulatory Notification, Incident Notification Regime",["FINRA Rule 4530"]),
 ("SEC Regulation S-P, 17 CFR Part 248 Subpart A (as amended 2024: incident response program and customer notification, 248.30)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-248/subpart-A","Regulation","Notice to affected individuals of unauthorized access to sensitive customer information; deadlines (amendments in force)","Incident Regulatory Notification, Incident Notification Regime",["Regulation S-P"]),
 ("Interagency Paper on Sound Practices to Strengthen Operational Resilience (Federal Reserve SR 20-24, OCC, FDIC; November 2020)","Federal Reserve, OCC, FDIC","https://www.federalreserve.gov/supervisionreg/srletters/SR2024.htm","Supervisory guidance (applied by analogy; confirm page)","Critical operations and core business lines, mapping of interconnections and dependencies, scenario analysis, tolerance for disruption","Critical or Important Function, Resilience Resource Mapping, Resilience Test",["Interagency Sound Practices"]),
 ("PCAOB AS 2201 and SOX Section 404","PCAOB; US Congress","https://pcaobus.org/oversight/standards/auditing-standards/details/AS2201","Standard / statute","Key controls, control nature, design and operating effectiveness tests","Control, Control Test",["PCAOB AS 2201", "SOX 404"]),
 ("AICPA SOC 2","AICPA","https://www.aicpa-cima.com/topic/audit-assurance/audit-and-assurance-greater-than-soc-2","Standard","Assurance evidence read from 14","Third-Party Risk Domain Result",["AICPA SOC 2"]),
 ("OCC 12 CFR Part 9 (fiduciary activities of national banks)","US OCC","https://www.ecfr.gov/current/title-12/chapter-I/part-9","Regulation","Trustee bank controls for collective investment trusts","Control Owning Legal Entity",["OCC 12 CFR 9"]),
 ("IRS EPCRS (Rev. Proc. 2021-30)","US IRS","https://www.irs.gov/retirement-plans/epcrs-overview","Guidance","Plan correction as an incident source","Incident Source Record",["IRS EPCRS"]),
 ("GRC platform structure: ServiceNow IRM, Archer, MetricStream (public product descriptions)","ServiceNow; Archer; MetricStream","https://www.servicenow.com/products/integrated-risk-management.html","Vendor documentation","Common object structure for risks, controls, issues, incidents and audits","Structure only",["ServiceNow IRM"]),
]
