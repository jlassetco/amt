"""Data Domain 39 - Legal & Corporate Governance. Content module for taxonomy_builder.py."""

# Row rule shared by the Contract attributes that a typed record also masters (CD-257, plan §4 item 9).
RR = ("Row rule (CD-257): owner = domain of the typed link (01, 05, 10, 14, 16, 26, 28, 35, 43 or 44, as named by "
      "Typed Record Type; for 44 leases the link is 44 Lease.Lease Contract); mastered in 39 on untyped rows (custody, "
      "administration, TA service, NDA, engagement letter, bank mandate, constitutional documents) and on rows typed only by a "
      "40 Supplier Contract Profile. The declared owner '05' is a placeholder until the catalog supports per-row owners "
      "(plan §4 item 9); this note is the authority.")

META = {
 "title": "Legal & Corporate Governance Data Taxonomy",
 "subtitle": "Business domain 39 - Legal & Corporate Governance | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "39_Legal_and_Corporate_Governance/Legal_and_Corporate_Governance_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the legal record of a US wealth manager and its group companies (the holding company, the registered investment adviser, the self-clearing broker-dealer, the fund trusts' service companies and the optional trust company): every executed contract and its documents, the disputes, litigation and enforcement matters the firm is party to, the legal holds that suspend record disposal, the boards, officers and resolutions of the firm's own companies, who may sign for them, and the trademarks that protect the firm's names. It is stewarded by the general counsel's office and the company secretariat. The domain exists because of the shared-concept pattern (CD-144, CD-257): Legal masters the generic contract record and its key (CTRCT-), and each business domain keeps only the typed profile it produces (05 distribution agreements, 14 data licenses, 26 trading agreements, 28 securities lending agreements, 35 fund advisory and sub-advisory agreements, 10 intercompany agreements, 16 recordkeeping arrangements, 01 mandates, 40 supplier contract profiles, 43 debt facilities and insurance policies, 44 leases), so one repository answers what the firm has signed with a party, under which entity, and what it obliges the firm to do. The firm is organized and regulated in the US only: UK Companies Act and Companies House filings, the PSC register, Luxembourg registers, SM&CR officer roles, ICARA approvals, EU and UK trademark offices and GDPR processor terms were removed under CW-939 and are listed in the jurisdiction register; contract governing law (England and Wales, Luxembourg and others) stays, because it is a fact of the instrument. Drawn from the CLOC Core 12 legal operations model, the LEDES e-billing standard and ABA UTBMS codes, the Federal Rules of Civil Procedure 26 and 37(e) and The Sedona Conference Commentary on Legal Holds, ASC 450-20 (and IAS 37 where an entity reports under IFRS), the Delaware General Corporation Law and other state corporate law, Maryland corporate and statutory trust law, FinCEN beneficial ownership information reporting, SEC Form ADV and Rule 206(4)-7, USPTO and WIPO trademark practice and the Nice Classification, Regulation S-P service-provider oversight and state privacy contract terms, SEC Rule 204-2 and FINRA Rule 4511. Use it as a starting point for a contract lifecycle management model, a matter management and e-billing model, a legal hold register, an entity management model or a business glossary."),
  ("Scope", "In scope: the enterprise contract record for every executed instrument, its typed link to the business domain record, parties, signatories, document versions, key dates and clause positions; legal service requests (contract reviews, NDAs, advice); legal matters (litigation, arbitration, regulatory enforcement, subpoenas, employment and IP disputes), their parties, events, ASC 450 / IAS 37 assessments, outside counsel engagements and invoice reviews; legal holds, custodians and scope; corporate governing bodies of internal legal entities (other than fund, fund-management and general partner boards, which are 35), memberships, officer appointments, meetings, corporate resolutions and their subject links, and entity statutory filings; powers of attorney and signing authority grants; trademark registrations, docket deadlines and license grants. Out of scope (referenced by ID): products and mandates (01); parties, including counterparties, opposing parties, outside counsel and outside directors (02); typed agreements and their commercial terms (05, 10, 14, 16, 26, 28, 35, 40, 43, 44); retention rules and captured communications (08); internal legal entities, their identity, form, jurisdiction and ownership (09); payable invoices and journals (19); employees (20); data assets (21); fund boards, fund officers and fund resolutions (35); loss events, risk appetite and audit plans (37); regulatory examinations, policies and firm filings (38); applications (41); brands (04, moving to 42 under CD-271); bank accounts and insurance policies (43); leases (44)."),
  ("Structure", "Four levels: Data Domain > Data Family > Data Business Object > Data Business Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "A Contract (CTRCT-) is one executed legal instrument: its family and subtype, contracting entity (09 LEN-), parent contract (master, amendment, SOW, side letter), status, dates and governing law. Its Typed Contract Link names, at most once, the typed record a business domain masters for it (05 AGR- or its amendment, 14 DLA-, 26 TAGR-, 35 ADVA-, 28 lending agreement, 10 ICA-, 16 PSVA-, 01 MND-, 43 DEBT- or INPOL-); 40 Supplier Contract Profile and 44 Lease hold the link from their side (keyed by or referencing CTRCT-). Every executed amendment is its own Contract with a Parent Contract and its own typed link where one exists; document versions are drafts and conformed copies of one instrument; where it does, the Contract's status, dates, governing law and party roles are Derived copies of that record (row rule), and where it does not they are mastered here. Contract Party, Contract Signatory, Contract Document Version, Contract Key Date and Contract Clause Position hang off the Contract; a Legal Service Request may result in one. A Legal Matter (LMAT-) has Matter Parties, Matter Events, dated Matter Financial Assessments (likelihood, reserve, range, disclosure), Outside Counsel Engagements (engagement letter = Contract) and Outside Counsel Invoice Reviews (19 APV-); an enforcement matter references the 38 Regulatory Examination that led to it. A Legal Hold (LHOLD-) issued for a matter or an exam has Custodians (20 EMP-) and Scope rows (08 record class, 41 application, 21 data asset, 02 party, date range), which are the source of the 02 and 08 legal hold indicators. A Corporate Governing Body (CGOV-) governs a 09 entity that is not a fund or fund manager; it has Memberships, meets in Corporate Board Meetings (including written consents) and adopts Corporate Resolutions (CGRES-), whose Corporate Resolution Subject Links hold, once, what was approved (contracts, memberships, officer appointments, powers of attorney, signing authority grants, 37 risk appetite and audit plans, 38 policy versions, 43 facilities and capital transactions, 42 publications). Corporate Officer Appointments, Entity Statutory Filings, Powers of Attorney (POWER-) and Signing Authority Grants are held per entity; Trademark Registrations (TMARK-) carry Docket Deadlines and License Grants."),
  ("Design principles", "1) Generic contract here, typed profile there (CD-257): no commercial term, fee, payment, collateral, lending or side letter economics is held here; Contract attributes that a typed record also masters are Derived copies on typed rows and the row rule is stated on each. 2) Corporate boards here, fund boards in 35 (CD-231, CD-259): a body that governs a fund (a 1940 Act fund board), a fund-management body (the CIT trustee's fiduciary committee) or a private fund's general partner is a 35 Fund Governing Body; carry vehicles and holding entities with no fund-governing role are 39. 3) Entity in 09, governance here: no legal name, legal form, jurisdiction, ownership percentage or LEI on any 39 object. 4) Enforcement here, exams in 38 (CD-253). 5) Hold here, retention in 08 (CD-258): a hold suspends disposal; 08 keeps the rule. 6) One link per approval: what a corporate resolution approved, including memberships, officer appointments, powers of attorney and signing authority grants, is held only on Corporate Resolution Subject Link; no 39 object and no consumer in 37, 38, 42 or 43 holds its own approving resolution. 7) Effective-date parties, memberships, appointments, authority grants and powers of attorney. 8) Flag personal data: every attribute that identifies an individual, and every attribute of a row whose subject is an individual (memberships, officer appointments, custodians, signatories, authority grants), is flagged PII; matter records are privileged and Restricted - Legal, and may hold criminal history data (restricted tier, CD-344)."),
  ("Applies To", "Shows the record each attribute belongs to: Contract, Typed Link, Contract Party, Document Version, Signatory, Key Date, Clause, Legal Request, Matter, Matter Party, Matter Event, Financial Assessment, Counsel Engagement, Invoice Review, Legal Hold, Custodian, Hold Scope, Corporate Body, Membership, Officer Appointment, Corporate Meeting, Corporate Resolution, Subject Link, Statutory Filing, Power of Attorney, Authority Grant, Trademark, Docket Deadline or License Grant."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify a contract and the typed record behind it, know when it starts, ends and must be renewed or terminated, identify a matter and its status, reserve and likelihood, prove a hold was issued, acknowledged and released, evidence who governs and may sign for an entity and when, or know whether a trademark is registered and when it must be renewed. Confirm with the general counsel, company secretary and the controller (reserves)."),
  ("Primary / Secondary Reference", "Standard, rule or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Vendor references (CLM, matter management, entity management tools) indicate common industry structure, not a license to reproduce vendor record layouts."),
  ("Notes", "PII = personal information under US privacy law (Regulation S-P for client information; state privacy laws). Legal matter records, assessments, invoice reviews and hold scopes are attorney-client privileged or attorney work product and are classified Restricted - Legal; contracts with commercially sensitive terms are Restricted - Commercial Terms. Names of individuals are held in 02 and 20, not here; outside counsel timekeepers are held by their LEDES timekeeper IDs. Matters that are criminal or quasi-criminal may hold criminal history data about individuals (restricted tier, CD-344)."),
  ("Tabs", "Hierarchy: Data Families, object groups and Data Business Objects with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: object-level cardinalities, including references to other Data Domains | Sources: standards, rules and vendor models used, with owners, licenses and links."),
  ("Suggested next steps", "1) Validate families, contract families and subtypes, matter types, body types, officer roles and CDEs with the general counsel, company secretary, litigation and IP counsel and the controller. 2) Name the contract lifecycle tool and decide whether it is the system of record for 05 and 14 agreements or an index (SME questions 1 and 2). 3) Load Typed Contract Link from the business domains' records and agree the row rule with each typed owner. 4) Agree with 02 and 08 that their Legal Hold Indicators become Derived copies of Legal Hold Scope (CD-258), and with 28, 35 and 20 the re-typing of their text contract references (CD-257). 5) Agree with 37, 38, 42 and 43 that board approvals are held only on Corporate Resolution Subject Link. 6) Inventory internal entity boards apart from fund boards (SME question 4). 7) Map Outside Counsel Invoice Review to the LEDES 1998B / XML format and UTBMS codes of the e-billing tool. 8) Turn the Relationships tab into a logical legal data model shared with 09, 35, 38 and 40."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Contract Repository", "LG-CTR",
  "The enterprise record of every executed legal instrument (CD-257): what it is, who signed it for which entity, the typed record a business domain keeps for it, its documents, key dates and negotiated clause positions, and the legal service requests that produce contracts and advice.",
  [
   ("Contracts & Typed Links", "The contract record and its link to the typed record that a business domain masters.", [
     ("Contract", [
       ("Contract ID", "Unique enterprise identifier of the executed instrument.", "Contract", "Identifier", "", "CTRCT-0041877", "Internal", "CLOC", "Y"),
       ("Contract Title", "Name of the instrument as it appears on its cover page or in the repository.", "Contract", "Text", "", "Global Custody Agreement - Example Funds Trust and Custodian Bank A (2019, amended 2024)", "Internal", "", ""),
       ("Contract Family", "Broad kind of instrument, which decides who reviews it and whether a typed record is expected.", "Contract", "Code", "Contract Family", "Fund Service Provider Agreement", "CLOC", "Internal", "Y"),
       ("Contract Subtype", "Specific kind of instrument within the family.", "Contract", "Code", "Contract Subtype", "Custody Agreement", "CLOC", "Internal", "Y"),
       ("Contract Hierarchy Role", "Position of the instrument relative to the contract it belongs to; every executed amendment is its own Contract with a Parent Contract.", "Contract", "Code", "Contract Hierarchy Role", "Amendment", "Internal", "", ""),
       ("Parent Contract", "Master, framework or original contract that this amendment, SOW, schedule or side letter belongs to.", "Contract", "Reference (Contract, 39)", "", "CTRCT-0018220", "Internal", "", ""),
       ("Contracting Entity", "Internal legal entity that is bound by the instrument.", "Contract", "Reference (Legal Entity)", "", "LEN-0004", "Internal", "", "Y", "Must agree with the internal party on the typed record where one exists."),
       ("Contracting Product", "Fund or registrant that is itself party to the instrument (custody, administration, TA service, fund declaration of trust, LPA).", "Contract", "Reference (Investment Product)", "", "PRD-00187", "Internal", "", ""),
       ("Related Corporate Bank Account", "43 corporate bank account whose bank mandate this contract is; bank mandates are untyped contracts because 43 keeps no mandate agreement record.", "Contract", "Reference (Corporate Bank Account, 43)", "", "BKAC-00118", "Internal", "", "", "43 Corporate Bank Account is the account, not a contract (CD-257 as amended); the mandate signatories stay 43."),
       ("Contract Status", "Lifecycle status of the instrument.", "Contract", "Code", "Shared: Agreement Status", "Active", "Internal", "", "Y", RR),
       ("Contract Effective Date", "Date the instrument took effect.", "Contract", "Date", "ISO 8601", "2019-04-15", "Internal", "", "Y", RR),
       ("Contract Expiry Date", "Date the current term ends unless renewed; empty for an evergreen instrument.", "Contract", "Date", "ISO 8601", "2027-04-14", "Internal", "", "Y", RR),
       ("Governing Law", "Law chosen in the instrument to govern it.", "Contract", "Code", "Governing Law", "New York", "Internal", "", "", RR),
       ("Legal Owner", "In-house lawyer accountable for the instrument in the repository.", "Contract", "Reference (Employee)", "", "EMP-30612", "CLOC", "", "", "PII (internal staff)."),
       ("Contract Business Lines", "Business lines the instrument serves.", "Contract", "Code (multi)", "Shared: Business Line", "PF", "Internal", "", ""),
     ]),
     ("Typed Contract Link", [
       ("Typed Record Type", "Kind of typed record a business domain masters for the contract, which says which link below is populated (for 40 and 44 the link is held on their side); 'None' for an untyped contract.", "Typed Link", "Code", "Typed Record Type", "Fund Advisory Agreement (35)", "Internal", "", "Y", "At most one link is populated per contract, and one contract carries the link to a given typed record: an amendment links to the 05 Agreement Amendment, or has no typed link and masters its dates here (CD-257)."),
       ("Linked Distribution Agreement", "05 distribution agreement (selling, platform, AP, wrap sponsor, fund participation) the contract is.", "Typed Link", "Reference (Agreement)", "", "AGR-004512", "Internal", "", "Y"),
       ("Linked Agreement Amendment", "05 agreement amendment the contract is, when the contract is an executed amendment of a 05 agreement.", "Typed Link", "Reference (Agreement Amendment, 05)", "", "AGR-004512-A03", "Internal", "", ""),
       ("Linked Data License Agreement", "14 data license agreement the contract is (including index licenses).", "Typed Link", "Reference (Data License Agreement)", "", "DLA-000184", "Internal", "", "Y"),
       ("Linked Trading Agreement", "26 trading agreement (ISDA, CSA, GMRA, clearing, give-up) the contract is.", "Typed Link", "Reference (Trading Agreement)", "", "TAGR-00118", "Internal", "", "Y"),
       ("Linked Fund Advisory Agreement", "35 fund advisory, sub-advisory or delegation agreement the contract is.", "Typed Link", "Reference (Fund Advisory Agreement)", "", "ADVA-00041", "Internal", "", "Y"),
       ("Linked Securities Lending Agreement", "28 securities lending authorization or master lending agreement the contract is.", "Typed Link", "Reference (Securities Lending Agreement, 28)", "", "GMSLA 2010 with borrower 101602 under the lending program of fund 00187", "Internal", "", "", "28 keys the agreement by program, agent and counterparty; no prefix."),
       ("Linked Intercompany Agreement", "10 intercompany service agreement the contract is.", "Typed Link", "Reference (Intercompany Agreement, 10)", "", "ICA-0019", "OECD TPG", "", ""),
       ("Linked Service Arrangement", "16 recordkeeping service arrangement the contract is.", "Typed Link", "Reference (Service Arrangement, 16)", "", "PSVA-00921", "Internal", "", ""),
       ("Linked Investment Mandate", "01 mandate whose investment management agreement the contract is.", "Typed Link", "Reference (Mandate)", "", "MND-01234", "Internal", "", "Y", "SME question 3 (who signs and stores IMAs)."),
       ("Linked Debt Facility", "43 corporate debt facility the contract is.", "Typed Link", "Reference (Debt Facility, 43)", "", "DEBT-0003", "Internal", "", ""),
       ("Linked Insurance Policy", "43 corporate insurance policy the contract is.", "Typed Link", "Reference (Corporate Insurance Policy, 43)", "", "INPOL-DO-2026-01", "Internal", "", ""),
     ]),
   ]),
   ("Parties, Signatories & Documents", "Who is bound by the contract, who signed it on what authority, and its document versions.", [
     ("Contract Party", [
       ("Party Contract", "Contract the party is bound by.", "Contract Party", "Reference (Contract, 39)", "", "CTRCT-0041877", "Internal", "", ""),
       ("Contract Party Role", "Role the party plays under the contract.", "Contract Party", "Code", "Contract Party Role", "Counterparty", "Internal", "CLOC", "Y", RR),
       ("External Contract Party", "External party bound by or benefiting from the contract.", "Contract Party", "Reference (Party)", "", "PTY-100912", "Internal", "", "Y", "PII when the party is an individual. Exactly one of External Contract Party and Internal Contract Party is filled. Row rule (CD-257): on typed rows it must agree with the typed record's counterparty, which the typed owner masters; mastered here on untyped rows."),
       ("Internal Contract Party", "Group entity bound by the contract other than the contracting entity (guarantor, co-obligor, beneficiary).", "Contract Party", "Reference (Legal Entity)", "", "LEN-0021", "Internal", "", "Y", "Row rule (CD-257): on typed rows it must agree with the typed record, which the typed owner masters; mastered here on untyped rows."),
       ("Notice Contact Point", "Address or email named in the notices clause for the party.", "Contract Party", "Reference (Contact Point)", "", "CTP-0091245", "Internal", "", "", "PII when the party is an individual."),
       ("Party Effective From", "Date the party became bound (signature, accession or assignment).", "Contract Party", "Date", "ISO 8601", "2019-04-15", "Internal", "", ""),
       ("Party Effective To", "Date the party ceased to be bound (assignment, release, novation).", "Contract Party", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
     ("Contract Signatory", [
       ("Signed Contract", "Contract that was signed.", "Signatory", "Reference (Contract, 39)", "", "CTRCT-0041877", "Internal", "", "", "PII (row about an individual)."),
       ("Signing Employee", "Employee who signed for a group entity or fund.", "Signatory", "Reference (Employee)", "", "EMP-30412", "Internal", "", "", "PII (internal staff). Exactly one of Signing Employee and External Signatory is filled."),
       ("External Signatory", "Individual who signed for the counterparty or as attorney-in-fact outside the group.", "Signatory", "Reference (Party)", "", "PTY-702551", "Internal", "", "", "PII."),
       ("Signing Capacity", "Title or capacity in which the person signed.", "Signatory", "Text", "", "Authorized Signatory", "Internal", "", "", "PII."),
       ("Relied-On Power of Attorney", "Power of attorney the signatory relied on.", "Signatory", "Reference (Power of Attorney, 39)", "", "POWER-2026-00112", "Internal", "", "", "PII (row about an individual)."),
       ("Relied-On Authority Grant", "Signing authority grant the signatory relied on.", "Signatory", "Reference (Signing Authority Grant, 39)", "", "Employee 30412 / Contract Signature / entity 0004 / 2026-01-01", "Internal", "", "", "PII (row about an individual)."),
       ("Signed Date", "Date the signatory signed.", "Signatory", "Date", "ISO 8601", "2024-03-28", "ESIGN Act", "eIDAS", "Y", "PII."),
     ]),
     ("Contract Document Version", [
       ("Document Version Contract", "Contract the document version belongs to.", "Document Version", "Reference (Contract, 39)", "", "CTRCT-0041877", "Internal", "", ""),
       ("Document Version Number", "Sequence of the version within the contract.", "Document Version", "Integer", "", "3", "Internal", "", ""),
       ("Document Sequence", "Number of the file within the version (main agreement, each exhibit, each signed counterpart).", "Document Version", "Integer", "", "1", "Internal", "", ""),
       ("Document Role", "Part of the instrument the file holds.", "Document Version", "Code", "Document Role", "Main Agreement", "CLOC", "", ""),
       ("Document Version Type", "Stage of the document: drafts and conformed copies of one instrument; an executed amendment is its own Contract.", "Document Version", "Code", "Document Version Type", "Executed", "CLOC", "", "Y"),
       ("Document Location", "Repository path of the file; the only place a contract document location is held.", "Document Version", "Text", "URI", "clm://contracts/CTRCT-0041877/v3-executed.pdf", "Internal", "", ""),
       ("E-Signature Envelope ID", "Identifier of the electronic signature envelope that produced the executed copy.", "Document Version", "Identifier", "External (Vendor)", "4f1c9a2e-77b0-4d13-a0c2-9e81d4b2c6a1", "ESIGN Act", "eIDAS", ""),
       ("Document Executed Date", "Date the version became fully executed (last signature).", "Document Version", "Date", "ISO 8601", "2024-03-28", "Internal", "", ""),
     ]),
   ]),
   ("Dates & Clauses", "Dates that need action and the positions taken on clauses that Legal tracks.", [
     ("Contract Key Date", [
       ("Key Date Contract", "Contract the date belongs to.", "Key Date", "Reference (Contract, 39)", "", "CTRCT-0041877", "Internal", "", ""),
       ("Key Date Type", "Kind of date.", "Key Date", "Code", "Key Date Type", "Renewal Notice Deadline", "CLOC", "", "Y"),
       ("Key Date Sequence", "Occurrence of the date type within the contract (each annual renewal notice deadline, each option).", "Key Date", "Integer", "", "2", "Internal", "", ""),
       ("Key Date Value", "The date.", "Key Date", "Date", "ISO 8601", "2027-01-14", "Internal", "", "Y", RR + " Applies only to date types the typed record holds (for example 35 Initial Term End Date, 44 lease option dates); other types (price review, compliance deliverable, exclusivity end) are mastered here on every row."),
       ("Key Date Action Status", "Whether the action the date calls for has been taken.", "Key Date", "Code", "Deadline Action Status", "Open", "Internal", "", ""),
     ]),
     ("Contract Clause Position", [
       ("Clause Contract", "Contract the clause is in.", "Clause", "Reference (Contract, 39)", "", "CTRCT-0041877", "Internal", "", ""),
       ("Clause Type", "Kind of clause tracked.", "Clause", "Code", "Clause Type", "Limitation of Liability", "CLOC", "Regulation S-P", ""),
       ("Clause Position", "How the clause compares with the firm's standard position.", "Clause", "Code", "Clause Position", "Negotiated - Within Fallback", "Internal", "", "Y"),
       ("Clause Summary", "Short description of what was agreed, written by the reviewing lawyer.", "Clause", "Text", "", "Custodian liability capped at 12 months' fees except for negligence, fraud and willful misconduct", "Internal", "", ""),
     ]),
   ]),
   ("Legal Service Requests", "Requests to Legal for contract review, NDAs and advice, the intake stage of the CLOC model.", [
     ("Legal Service Request", [
       ("Legal Request Number", "Number of the request in the legal intake tool.", "Legal Request", "Identifier", "", "2026/00318", "CLOC", "", ""),
       ("Legal Request Type", "Kind of help requested.", "Legal Request", "Code", "Legal Request Type", "Contract Review - Third-Party Paper", "CLOC", "", "Y"),
       ("Requesting Employee", "Employee who raised the request.", "Legal Request", "Reference (Employee)", "", "EMP-20417", "Internal", "", "", "PII (internal staff)."),
       ("Assigned Lawyer", "In-house lawyer assigned to the request.", "Legal Request", "Reference (Employee)", "", "EMP-30612", "CLOC", "", "", "PII (internal staff)."),
       ("Legal Request Status", "Workflow status of the request.", "Legal Request", "Code", "Shared: Case Status", "In Progress", "CLOC", "", ""),
       ("Request Received Date", "Date the request was received.", "Legal Request", "Date", "ISO 8601", "2026-09-14", "CLOC", "", ""),
       ("Request Completed Date", "Date the advice was given or the contract executed.", "Legal Request", "Date", "ISO 8601", "", "CLOC", "", ""),
       ("Resulting Contract", "Contract the request produced.", "Legal Request", "Reference (Contract, 39)", "", "CTRCT-0041902", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Legal Matters & Litigation", "LG-MAT",
  "Disputes, litigation, arbitration, regulatory enforcement and subpoena responses the firm or its funds are party to (CD-253, CD-258): parties, events and deadlines, the dated loss contingency assessment, and the outside counsel engaged and their invoices. Examinations and inquiries are 38; a formal investigation, subpoena or Wells notice is a matter here.",
  [
   ("Matters", "The matter, who is in it, and what has happened.", [
     ("Legal Matter", [
       ("Legal Matter ID", "Unique enterprise identifier of the matter.", "Matter", "Identifier", "", "LMAT-2026-0019", "Internal", "CLOC", "Y"),
       ("Legal Matter Type", "Kind of matter.", "Matter", "Code", "Legal Matter Type", "Regulatory Enforcement Investigation", "CLOC", "SEC Enforcement Manual", "Y"),
       ("Forum Type", "Kind of forum hearing the matter (not the identity of a regulator, which is Matter Regulator).", "Matter", "Code", "Forum Type", "Regulator", "Internal", "", ""),
       ("Docket Number", "Case, arbitration or investigation number assigned by the forum.", "Matter", "Identifier", "", "HO-14412", "Internal", "", ""),
       ("Matter Regulator", "Regulator conducting an enforcement matter; the only place the regulator of a matter is held.", "Matter", "Code", "Shared: Regulator", "SEC", "SEC Enforcement Manual", "", ""),
       ("Originating Examination", "38 examination or inquiry that led to the enforcement matter.", "Matter", "Reference (Regulatory Examination, 38)", "", "EXAM-2026-0007", "Internal", "", "", "CD-253: 38 holds the exam; the referral link is held here once."),
       ("Matter Status", "Workflow status of the matter.", "Matter", "Code", "Shared: Case Status", "In Progress", "CLOC", "", "Y"),
       ("Matter Significance", "Significance of the matter to the firm.", "Matter", "Code", "Shared: Severity", "High", "Internal", "", ""),
       ("Matter Opened Date", "Date Legal opened the matter.", "Matter", "Date", "ISO 8601", "2026-05-11", "CLOC", "", ""),
       ("Matter Closed Date", "Date the matter was closed (final judgment, settlement, termination of investigation).", "Matter", "Date", "ISO 8601", "", "CLOC", "", ""),
       ("Privilege Indicator", "Whether the matter record and its materials are protected by attorney-client privilege or as work product.", "Matter", "Boolean", "", "Y", "FRCP 26", "", "Y"),
       ("Matter Classification", "Information classification of the matter record.", "Matter", "Code", "Shared: Information Classification", "Restricted - Legal", "Internal", "", ""),
       ("Responsible Lawyer", "In-house lawyer responsible for the matter.", "Matter", "Reference (Employee)", "", "EMP-30612", "CLOC", "", "", "PII (internal staff)."),
     ]),
     ("Matter Party", [
       ("Party Matter", "Matter the party is in.", "Matter Party", "Reference (Legal Matter, 39)", "", "LMAT-2026-0019", "Internal", "", ""),
       ("Matter Party Role", "Role the party plays in the matter.", "Matter Party", "Code", "Matter Party Role", "Defendant", "Internal", "", "Y"),
       ("External Matter Party", "External party in the matter (opposing party, opposing counsel, co-defendant, witness).", "Matter Party", "Reference (Party)", "", "PTY-300455", "Internal", "", "Y", "PII when the party is an individual; criminal history data (restricted tier, CD-344) where the matter is criminal or quasi-criminal. Proposed 02 Party Role Type 'Opposing Party' (CD-143). Regulators are not matter parties (Matter Regulator); outside counsel are held on Outside Counsel Engagement."),
       ("Internal Matter Entity", "Group entity that is a party.", "Matter Party", "Reference (Legal Entity)", "", "LEN-0004", "Internal", "", ""),
       ("Employee Matter Party", "Employee who is a party or named individual (employment dispute, named defendant).", "Matter Party", "Reference (Employee)", "", "EMP-20417", "Internal", "", "", "PII (internal staff); criminal history data (restricted tier, CD-344) where the matter is criminal or quasi-criminal."),
     ]),
     ("Matter Event", [
       ("Event Matter", "Matter the event belongs to.", "Matter Event", "Reference (Legal Matter, 39)", "", "LMAT-2026-0019", "Internal", "", ""),
       ("Matter Event Sequence", "Order of the event within the matter.", "Matter Event", "Integer", "", "4", "Internal", "", ""),
       ("Matter Event Type", "Kind of event.", "Matter Event", "Code", "Matter Event Type", "Wells Notice Received", "SEC Enforcement Manual", "FRCP 26", ""),
       ("Matter Event Date", "Date the event occurred.", "Matter Event", "Date", "ISO 8601", "2026-09-02", "Internal", "", "Y"),
       ("Response Deadline", "Date by which the firm must respond or act.", "Matter Event", "Date", "ISO 8601", "2026-10-02", "SEC Enforcement Manual", "", ""),
       ("Matter Event Description", "Short description of the event.", "Matter Event", "Text", "", "Staff Wells notice; submission due within 30 days", "Internal", "", ""),
     ]),
   ]),
   ("Matter Financials & Counsel", "Loss contingency assessments, outside counsel engagements and invoice reviews.", [
     ("Matter Financial Assessment", [
       ("Assessed Matter", "Matter assessed.", "Financial Assessment", "Reference (Legal Matter, 39)", "", "LMAT-2026-0019", "Internal", "", ""),
       ("Assessment Reporting Entity", "Group entity whose financial statements the assessment is made for.", "Financial Assessment", "Reference (Legal Entity)", "", "LEN-0001", "ASC 450", "IAS 37", "Y"),
       ("Assessment Date", "Date of the assessment (usually each quarter end).", "Financial Assessment", "Date", "ISO 8601", "2026-09-30", "ASC 450", "IAS 37", "Y"),
       ("ASC 450 Likelihood", "Likelihood that a loss has been incurred, for a reporting entity that reports under US GAAP.", "Financial Assessment", "Code", "ASC 450 Likelihood", "Reasonably Possible", "ASC 450", "", "Y", "Filled when the reporting entity reports under US GAAP."),
       ("IAS 37 Likelihood", "Likelihood that an outflow will be required, for a reporting entity that reports under IFRS.", "Financial Assessment", "Code", "IAS 37 Likelihood", "Possible", "IAS 37", "", "Y", "Filled when the reporting entity reports under IFRS; a matter can be Reasonably Possible under ASC 450 and Probable under IAS 37."),
       ("Reserve Amount", "Amount accrued for the matter; the only place a litigation reserve is held.", "Financial Assessment", "Amount", "ISO 4217", "USD 0", "ASC 450", "IAS 37", "Y", "Privileged."),
       ("Estimated Loss Range Low", "Low end of the reasonably possible loss range.", "Financial Assessment", "Amount", "ISO 4217", "USD 2,000,000", "ASC 450", "", "", "Privileged."),
       ("Estimated Loss Range High", "High end of the reasonably possible loss range.", "Financial Assessment", "Amount", "ISO 4217", "USD 6,500,000", "ASC 450", "", "", "Privileged."),
       ("Disclosure Required Indicator", "Whether the matter must be disclosed in the financial statements of the entity.", "Financial Assessment", "Boolean", "", "Y", "ASC 450", "IAS 37", "Y"),
       ("Reserve Journal Entry", "19 journal entry that booked or changed the reserve.", "Financial Assessment", "Reference (Journal Entry)", "", "JNL-2026-09-77120", "Internal", "", "", "19 books; 39 decides the amount."),
     ]),
     ("Outside Counsel Engagement", [
       ("Engaged Matter", "Matter the firm is engaged on; empty for general advisory engagements, which are identified by their engagement letter.", "Counsel Engagement", "Reference (Legal Matter, 39)", "", "LMAT-2026-0019", "Internal", "", ""),
       ("Outside Counsel Firm", "Law firm engaged.", "Counsel Engagement", "Reference (Party)", "", "PTY-300455", "Internal", "", "Y", "Proposed 02 Party Role Type 'Outside Counsel' (CD-143)."),
       ("Engagement Letter", "Contract that is the engagement letter; with the matter it identifies the engagement.", "Counsel Engagement", "Reference (Contract, 39)", "", "CTRCT-0042011", "Internal", "", "Y"),
       ("Engagement Budget Amount", "Budget approved for the engagement.", "Counsel Engagement", "Amount", "ISO 4217", "USD 850,000", "CLOC", "", ""),
       ("Approved Timekeeper IDs", "LEDES timekeeper IDs of the firm's staff approved to bill the engagement.", "Counsel Engagement", "Identifier", "", "PA01; SA07; PL03", "LEDES", "", "", "PII (identifies individuals at the firm)."),
       ("Engagement Start Date", "Date the engagement began.", "Counsel Engagement", "Date", "ISO 8601", "2026-05-15", "Internal", "", ""),
     ]),
     ("Outside Counsel Invoice Review", [
       ("Reviewed Engagement", "Engagement the invoice was billed under.", "Invoice Review", "Reference (Outside Counsel Engagement, 39)", "", "CTRCT-0042011 / LMAT-2026-0019", "Internal", "", ""),
       ("Counsel Invoice Number", "Invoice number assigned by the law firm.", "Invoice Review", "Identifier", "", "88120 0926", "LEDES", "", ""),
       ("Payable Invoice", "19 payable invoice the reviewed invoice was booked as.", "Invoice Review", "Reference (Payable Invoice)", "", "APV-2026-0018833", "Internal", "", ""),
       ("Billed Fees Amount", "Fees and expenses billed on the invoice.", "Invoice Review", "Amount", "ISO 4217", "USD 182,450", "LEDES", "", "", "Derived copy of 19 Payable Invoice gross amount."),
       ("Approved Amount", "Amount Legal approved for payment.", "Invoice Review", "Amount", "ISO 4217", "USD 171,900", "LEDES", "", "Y"),
       ("Reduction Amount", "Amount reduced on review.", "Invoice Review", "Amount", "ISO 4217", "USD 10,550", "LEDES", "", ""),
       ("UTBMS Task Codes Billed", "UTBMS task codes on the invoice lines.", "Invoice Review", "Code (multi)", "External (ABA UTBMS Litigation Code Set)", "L120; L210; L320", "ABA UTBMS", "LEDES", ""),
       ("Invoice Review Status", "Approval status of the review.", "Invoice Review", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("Invoice Review Date", "Date the review was completed.", "Invoice Review", "Date", "ISO 8601", "2026-10-03", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Legal Holds & Preservation", "LG-PRS",
  "Legal holds that suspend record disposal while litigation, investigation or a regulatory exam is pending or reasonably anticipated (CD-258): who must preserve, what is covered and when the hold was issued, acknowledged and released. Retention rules stay in 08; the 02 and 08 legal hold indicators are copies of Legal Hold Scope.",
  [
   ("Holds", "The hold, its custodians and its scope.", [
     ("Legal Hold", [
       ("Legal Hold ID", "Unique enterprise identifier of the hold.", "Legal Hold", "Identifier", "", "LHOLD-2026-0007", "Internal", "Sedona Conference", "Y"),
       ("Hold Matter", "Matter the hold preserves for.", "Legal Hold", "Reference (Legal Matter, 39)", "", "LMAT-2026-0019", "FRCP 37(e)", "", "", "Exactly one of Hold Matter and Hold Examination is filled."),
       ("Hold Examination", "38 examination or inquiry the hold preserves for.", "Legal Hold", "Reference (Regulatory Examination, 38)", "", "EXAM-2026-0007", "Internal", "", "", "SME question 6."),
       ("Duty to Preserve Trigger Date", "Date litigation or investigation was reasonably anticipated, from which the duty to preserve runs.", "Legal Hold", "Date", "ISO 8601", "2026-05-08", "FRCP 37(e)", "Sedona Conference", "Y"),
       ("Hold Issued Date", "Date the hold notice was issued.", "Legal Hold", "Date", "ISO 8601", "2026-05-11", "Sedona Conference", "", "Y"),
       ("Hold Released Date", "Date the hold was released.", "Legal Hold", "Date", "ISO 8601", "", "Sedona Conference", "", "Y"),
       ("Issuing Lawyer", "Lawyer who issued the hold.", "Legal Hold", "Reference (Employee)", "", "EMP-30612", "Internal", "", "", "PII (internal staff)."),
       ("Hold Status", "Lifecycle status of the hold; custodian acknowledgment is held on Legal Hold Custodian.", "Legal Hold", "Code", "Hold Status", "Active", "Sedona Conference", "", "Y"),
     ]),
     ("Legal Hold Custodian", [
       ("Custodian Hold", "Hold the custodian is subject to.", "Custodian", "Reference (Legal Hold, 39)", "", "LHOLD-2026-0007", "Internal", "", "", "PII (row about an individual)."),
       ("Custodian Employee", "Employee who must preserve records.", "Custodian", "Reference (Employee)", "", "EMP-20417", "Sedona Conference", "", "Y", "PII (internal staff)."),
       ("Notice Sent Date", "Date the hold notice was sent to the custodian.", "Custodian", "Date", "ISO 8601", "2026-05-11", "Sedona Conference", "", "", "PII."),
       ("Custodian Acknowledgment Status", "Whether the custodian has acknowledged the hold.", "Custodian", "Code", "Custodian Acknowledgment Status", "Acknowledged", "Sedona Conference", "", "Y", "PII."),
       ("Acknowledged Date", "Date the custodian acknowledged the hold.", "Custodian", "Date", "ISO 8601", "2026-05-13", "Sedona Conference", "", "Y", "PII."),
       ("Last Reminder Date", "Date of the latest reminder sent to the custodian.", "Custodian", "Date", "ISO 8601", "2026-08-11", "Sedona Conference", "", "", "PII."),
       ("Custodian Released Date", "Date the custodian was released from the hold.", "Custodian", "Date", "ISO 8601", "", "Sedona Conference", "", "", "PII."),
     ]),
     ("Legal Hold Scope", [
       ("Scope Hold", "Hold the scope row belongs to.", "Hold Scope", "Reference (Legal Hold, 39)", "", "LHOLD-2026-0007", "Internal", "", ""),
       ("Hold Scope Type", "Kind of data source the row covers, which says which reference is populated.", "Hold Scope", "Code", "Hold Scope Type", "Record Class", "Sedona Conference", "", "Y"),
       ("Scope Inclusion Type", "Whether the row brings the source into the hold or carves it out.", "Hold Scope", "Code", "Shared: Inclusion Type", "Include", "Internal", "", ""),
       ("Scoped Retention Rule", "21 retention rule whose record class is preserved.", "Hold Scope", "Reference (Retention Rule, 21)", "", "RET-BD-COMMS", "SEC Rule 17a-4", "SEC Rule 204-2", ""),
       ("Scoped Application", "41 application whose data is preserved.", "Hold Scope", "Reference (Application, 41)", "", "APPL-00412", "Internal", "", ""),
       ("Scoped Data Asset", "21 data asset whose data is preserved.", "Hold Scope", "Reference (Data Asset)", "", "DAS-000318", "Internal", "", ""),
       ("Scoped Party", "02 party whose records are preserved.", "Hold Scope", "Reference (Party)", "", "PTY-500771", "Internal", "", "", "PII when the party is an individual."),
       ("Scope Date From", "Earliest record date covered.", "Hold Scope", "Date", "ISO 8601", "2023-01-01", "FRCP 26", "", ""),
       ("Scope Date To", "Latest record date covered; empty while ongoing.", "Hold Scope", "Date", "ISO 8601", "", "FRCP 26", "", ""),
       ("Disposal Suspended Indicator", "Whether disposal of records in scope is suspended now; true while the hold is active and the row is an inclusion.", "Hold Scope", "Boolean", "", "Y", "FRCP 37(e)", "FINRA Rule 4511", "Y", "Source of the 02 Retention and 08 Captured Communication Record Legal Hold Indicators (Derived copies, CD-258)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Corporate Entity Governance", "LG-CGV",
  "Boards and committees of the group's own companies (holding company, adviser, broker-dealer, service companies, feeder fund general partners), their members and officers, their meetings and resolutions, what each resolution approved, and the statutory filings the companies make (CD-259). Fund boards (1940 Act fund trusts), the CIT trustee's fiduciary committee and boards of private fund general partners are 35 (CD-259); entity identity and ownership are 09.",
  [
   ("Bodies, Members & Officers", "Corporate governing bodies, who sits on them and the officers of each entity.", [
     ("Corporate Governing Body", [
       ("Corporate Body ID", "Unique enterprise identifier of the body or committee.", "Corporate Body", "Identifier", "", "CGOV-0003", "Internal", "Diligent Entities", "Y"),
       ("Corporate Body Name", "Name of the body as stated in its constitution or terms of reference.", "Corporate Body", "Text", "", "Board of Directors of Example Asset Management Holdings Inc.", "Internal", "", ""),
       ("Corporate Body Type", "Legal kind of body.", "Corporate Body", "Code", "Corporate Body Type", "Board of Directors", "DGCL", "", "Y"),
       ("Governed Entity", "Internal legal entity the body governs.", "Corporate Body", "Reference (Legal Entity)", "", "LEN-0001", "Internal", "", "Y", "Never a fund or a fund-management entity, whose boards are 35 (CD-231, CD-259). An affiliated CIT trustee bank's own corporate board is 39; its fiduciary committee that governs CITs is a 35 Fund Governing Body."),
       ("Parent Corporate Body", "Body of which this committee is a committee; empty for a full board.", "Corporate Body", "Reference (Corporate Governing Body, 39)", "", "CGOV-0001", "Internal", "", ""),
       ("Body Constitution Document", "Document version of the bylaws, articles, operating agreement or terms of reference that constitutes the body.", "Corporate Body", "Reference (Contract Document Version, 39)", "", "CTRCT-0040012 v2", "Internal", "", ""),
       ("Meeting Frequency", "How often the body is scheduled to meet.", "Corporate Body", "Code", "Shared: Frequency", "Quarterly", "Internal", "", ""),
       ("Corporate Body Status", "Whether the body is constituted and acting.", "Corporate Body", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
     ]),
     ("Corporate Body Membership", [
       ("Membership Body", "Body the member sits on.", "Membership", "Reference (Corporate Governing Body, 39)", "", "CGOV-0003", "Internal", "", "", "PII (row about an individual)."),
       ("Member Employee", "Employee who is a member (executive director, manager).", "Membership", "Reference (Employee)", "", "EMP-30412", "Internal", "", "Y", "PII (internal staff). Exactly one of Member Employee and Member External Party is filled."),
       ("Member External Party", "Individual outside the group who is a member (independent or outside director).", "Membership", "Reference (Party)", "", "PTY-702880", "Internal", "", "", "PII. Proposed 02 Party Role Type 'Outside Director' (CD-143)."),
       ("Corporate Member Role", "Position the member holds on the body; independence is held on Independent Member Indicator.", "Membership", "Code", "Corporate Member Role", "Independent / Outside Director", "DGCL", "", "Y", "PII."),
       ("Independent Member Indicator", "Whether the board has determined the member to be independent.", "Membership", "Boolean", "", "Y", "Internal", "", "", "PII."),
       ("Membership Effective From", "Date the membership began.", "Membership", "Date", "ISO 8601", "2026-01-01", "Internal", "", "Y", "PII."),
       ("Membership Effective To", "Date the membership ended.", "Membership", "Date", "ISO 8601", "", "Internal", "", "", "PII."),
     ]),
     ("Corporate Officer Appointment", [
       ("Officer Entity", "Internal legal entity the officer is appointed for.", "Officer Appointment", "Reference (Legal Entity)", "", "LEN-0004", "Internal", "", "Y", "PII (row about an individual)."),
       ("Corporate Officer Role", "Office or designated function held.", "Officer Appointment", "Code", "Corporate Officer Role", "Chief Compliance Officer (Rule 206(4)-7)", "DGCL", "SEC Rule 206(4)-7", "Y", "PII."),
       ("Officer Employee", "Employee who holds the office.", "Officer Appointment", "Reference (Employee)", "", "EMP-30588", "Internal", "", "Y", "PII (internal staff)."),
       ("Regulatory Notification Filing", "38 firm filing that notified the regulator of the appointment (Form ADV or Form BD amendment).", "Officer Appointment", "Reference (Firm Regulatory Filing, 38)", "", "FILNG-ADV-2026-00002", "SEC Form ADV", "", "", "PII. The individual's registrations (Form U4) are mastered in 08."),
       ("Officer Effective From", "Date the appointment took effect.", "Officer Appointment", "Date", "ISO 8601", "2026-02-01", "Internal", "", "Y", "PII."),
       ("Officer Effective To", "Date the appointment ended.", "Officer Appointment", "Date", "ISO 8601", "", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Meetings & Resolutions", "Meetings and written consents of corporate bodies, the resolutions adopted and what each approved.", [
     ("Corporate Board Meeting", [
       ("Meeting Body", "Body that met or acted by written consent.", "Corporate Meeting", "Reference (Corporate Governing Body, 39)", "", "CGOV-0003", "Internal", "", ""),
       ("Corporate Meeting Date", "Date the meeting was held or the written consent took effect.", "Corporate Meeting", "Date", "ISO 8601", "2026-11-18", "DGCL", "", "Y"),
       ("Corporate Meeting Sequence", "Number of the meeting on that date for the body.", "Corporate Meeting", "Integer", "", "1", "Internal", "", ""),
       ("Corporate Meeting Type", "Kind of meeting or action.", "Corporate Meeting", "Code", "Corporate Meeting Type", "Regular Board Meeting", "DGCL", "", ""),
       ("Quorum Present Indicator", "Whether a quorum under the constitution was present.", "Corporate Meeting", "Boolean", "", "Y", "DGCL", "", ""),
       ("Minutes Approval Status", "Whether the body has approved the minutes.", "Corporate Meeting", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
     ]),
     ("Corporate Resolution", [
       ("Corporate Resolution ID", "Unique enterprise identifier of the resolution.", "Corporate Resolution", "Identifier", "", "CGRES-2026-00041", "Internal", "", "Y"),
       ("Adopting Corporate Meeting", "Meeting or written consent at which the resolution was adopted.", "Corporate Resolution", "Reference (Corporate Board Meeting, 39)", "", "CGOV-0003 / 2026-11-18 / 1", "Internal", "", "Y"),
       ("Resolution Title", "Short statement of what was resolved.", "Corporate Resolution", "Text", "", "Approve 2027 operational risk appetite statement", "Internal", "", ""),
       ("Corporate Resolution Outcome", "Result of the vote or consent.", "Corporate Resolution", "Code", "Shared: Committee Decision Outcome", "Approved", "Internal", "", "Y"),
       ("Corporate Resolution Effective Date", "Date the action takes effect.", "Corporate Resolution", "Date", "ISO 8601", "2027-01-01", "Internal", "", "Y"),
       ("Superseded Corporate Resolution", "Earlier resolution this one replaces or rescinds.", "Corporate Resolution", "Reference (Corporate Resolution, 39)", "", "CGRES-2025-00037", "Internal", "", ""),
     ]),
     ("Corporate Resolution Subject Link", [
       ("Linked Corporate Resolution", "Resolution that approves the subject.", "Subject Link", "Reference (Corporate Resolution, 39)", "", "CGRES-2026-00041", "Internal", "", "Y"),
       ("Corporate Resolution Subject Type", "Kind of record approved, which says which subject reference is populated.", "Subject Link", "Code", "Corporate Resolution Subject Type", "Risk Appetite Statement (37)", "Internal", "", "Y"),
       ("Subject Contract", "Contract approved for signature.", "Subject Link", "Reference (Contract, 39)", "", "CTRCT-0041877", "Internal", "", ""),
       ("Subject Body Membership", "Appointment of a member to a corporate body approved.", "Subject Link", "Reference (Corporate Body Membership, 39)", "", "CGOV-0003 / employee 30412 / Executive Director / 2026-01-01", "DGCL", "", "", "PII (identifies an individual)."),
       ("Subject Officer Appointment", "Officer appointment approved.", "Subject Link", "Reference (Corporate Officer Appointment, 39)", "", "entity 0004 / Chief Compliance Officer (Rule 206(4)-7) / employee 30588 / 2026-02-01", "DGCL", "", "", "PII (identifies an individual)."),
       ("Subject Power of Attorney", "Power of attorney whose grant was authorized.", "Subject Link", "Reference (Power of Attorney, 39)", "", "POWER-2026-00112", "DGCL", "", ""),
       ("Subject Authority Grant", "Signing authority grant delegated.", "Subject Link", "Reference (Signing Authority Grant, 39)", "", "Employee 30412 / Contract Signature / entity 0004 / 2026-01-01", "Internal", "", "", "PII (identifies an individual)."),
       ("Subject Risk Appetite Statement", "37 risk appetite statement approved.", "Subject Link", "Reference (Risk Appetite Statement, 37)", "", "RAS 2026 OPS 04", "Internal", "", "", "One link per approval (program lead ruling): 37 drops its Approving Corporate Resolution."),
       ("Subject Audit Plan", "37 internal audit plan approved by the audit committee.", "Subject Link", "Reference (Audit Plan, 37)", "", "2026 / 2", "Internal", "", ""),
       ("Subject Policy Version", "38 policy version approved by an entity board.", "Subject Link", "Reference (Policy Version, 38)", "", "POLCY-0118 version 4", "Internal", "", "", "Fund board policy approvals are 35."),
       ("Subject Debt Facility", "43 debt facility approved.", "Subject Link", "Reference (Debt Facility, 43)", "", "DEBT-0003", "Internal", "", ""),
       ("Subject Capital Transaction", "43 intra-group dividend, capital contribution or reduction approved.", "Subject Link", "Reference (Intra-Group Capital Transaction, 43)", "", "IGCT 2026/007", "DGCL", "", ""),
       ("Subject Corporate Publication", "42 corporate publication approved by a board (for example the corporate responsibility report).", "Subject Link", "Reference (Corporate Publication, 42)", "", "CRR/0004/2025/1", "Internal", "", ""),
       ("Subject Description", "Free-text description of the subject where no typed reference applies.", "Subject Link", "Text", "", "Change of registered office address", "Internal", "", ""),
     ]),
   ]),
   ("Statutory Filings", "Filings an internal entity must make to its state of formation or qualification (annual reports, franchise tax reports) or under corporate transparency law (FinCEN beneficial ownership reporting, where it applies).", [
     ("Entity Statutory Filing", [
       ("Filing Entity", "Internal legal entity that files.", "Statutory Filing", "Reference (Legal Entity)", "", "LEN-0021", "Internal", "", "Y"),
       ("Statutory Filing Type", "Kind of filing.", "Statutory Filing", "Code", "Statutory Filing Type", "Delaware Annual Franchise Tax Report", "DGCL", "FinCEN BOI", "Y"),
       ("Filing Period End", "Last day of the period or the review date the filing covers.", "Statutory Filing", "Date", "ISO 8601", "2025-12-31", "DGCL", "", ""),
       ("Statutory Filing Due Date", "Date the filing is due.", "Statutory Filing", "Date", "ISO 8601", "2026-03-01", "DGCL", "", "Y"),
       ("Statutory Filed Date", "Date the filing was made.", "Statutory Filing", "Date", "ISO 8601", "2026-02-20", "Internal", "", ""),
       ("Registry Filing Reference", "Reference the registry gave the submission.", "Statutory Filing", "Identifier", "", "DE annual report 2025 confirmation 0457912", "Internal", "", ""),
       ("Filing Exemption Indicator", "Whether the entity is exempt from this filing type for the period (for example every domestic entity, exempt from BOI reporting under FinCEN's August 2026 final rule).", "Statutory Filing", "Boolean", "", "N", "FinCEN BOI", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Signing Authority", "LG-SGN",
  "Who may act and sign for each internal entity: powers of attorney granted to employees or outside attorneys-in-fact, and signing authority grants by authority type and limit. Bank account mandates and their signatories are 43.",
  [
   ("Powers & Grants", "Powers of attorney and signing authority grants.", [
     ("Power of Attorney", [
       ("Power of Attorney ID", "Unique enterprise identifier of the power of attorney.", "Power of Attorney", "Identifier", "", "POWER-2026-00112", "Internal", "", "Y"),
       ("Grantor Entity", "Internal legal entity that grants the power.", "Power of Attorney", "Reference (Legal Entity)", "", "LEN-0004", "Internal", "", "Y"),
       ("Attorney Employee", "Employee appointed as attorney-in-fact.", "Power of Attorney", "Reference (Employee)", "", "EMP-30412", "Internal", "", "", "PII (internal staff). Exactly one of Attorney Employee and Attorney Party is filled."),
       ("Attorney Party", "Individual or firm outside the group appointed as attorney-in-fact (local counsel, tax agent).", "Power of Attorney", "Reference (Party)", "", "PTY-300455", "Internal", "", "", "PII when an individual. Proposed 02 Party Role Type 'Attorney-in-Fact' (CD-143)."),
       ("Power of Attorney Type", "Kind of power granted.", "Power of Attorney", "Code", "Power of Attorney Type", "Limited - Specific Transactions", "Internal", "", ""),
       ("Power Scope", "Acts the attorney may perform.", "Power of Attorney", "Text", "", "Execute custody and fund administration agreements and amendments on behalf of the entity", "Internal", "", ""),
       ("Power Monetary Limit", "Largest commitment the attorney may make under the power.", "Power of Attorney", "Amount", "ISO 4217", "USD 5,000,000", "Internal", "", ""),
       ("Power Effective From", "Date the power took effect.", "Power of Attorney", "Date", "ISO 8601", "2026-03-01", "Internal", "", "Y"),
       ("Power Revoked Date", "Date the power was revoked or lapsed.", "Power of Attorney", "Date", "ISO 8601", "", "Internal", "", "Y"),
     ]),
     ("Signing Authority Grant", [
       ("Authorized Employee", "Employee granted the authority.", "Authority Grant", "Reference (Employee)", "", "EMP-30412", "Internal", "", "Y", "PII (internal staff)."),
       ("Authority Type", "Kind of act the person may authorize or sign.", "Authority Grant", "Code", "Authority Type", "Contract Signature", "Internal", "", "Y", "PII (row about an individual)."),
       ("Authority Entity", "Internal legal entity the authority is exercised for.", "Authority Grant", "Reference (Legal Entity)", "", "LEN-0004", "Internal", "", "Y", "PII (row about an individual)."),
       ("Authority Monetary Limit", "Largest amount the person may commit alone or with a co-signer.", "Authority Grant", "Amount", "ISO 4217", "USD 1,000,000", "Internal", "", "", "PII (row about an individual)."),
       ("Dual Signature Required Indicator", "Whether a second authorized signature is required.", "Authority Grant", "Boolean", "", "Y", "Internal", "", "", "PII (row about an individual)."),
       ("Grant Effective From", "Date the grant took effect.", "Authority Grant", "Date", "ISO 8601", "2026-01-01", "Internal", "", "Y", "PII."),
       ("Grant Effective To", "Date the grant ended.", "Authority Grant", "Date", "ISO 8601", "", "Internal", "", "", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Intellectual Property", "LG-IPR",
  "Trademark registrations that protect the firm's corporate and product names, their docket deadlines, and licenses to use them. Brand architecture is 04 (moving to 42 under CD-271); the corporate brand standard is 42; 39 holds the legal registration (CD-259).",
  [
   ("Trademarks", "Registrations, deadlines and license grants.", [
     ("Trademark Registration", [
       ("Trademark Registration ID", "Unique enterprise identifier of the mark in one office and jurisdiction.", "Trademark", "Identifier", "", "TMARK-00318", "Internal", "", "Y"),
       ("Mark Text", "Words of the mark, or a description of a logo mark.", "Trademark", "Text", "", "EXAMPLE INVESTMENTS", "USPTO", "", ""),
       ("Trademark Owner Entity", "Internal legal entity that owns the mark.", "Trademark", "Reference (Legal Entity)", "", "LEN-0001", "USPTO", "", "Y"),
       ("IP Office", "Office where the mark is filed.", "Trademark", "Code", "IP Office", "USPTO", "WIPO Madrid", "", ""),
       ("Trademark Application Number", "Number the office gave the application (US serial number).", "Trademark", "Identifier", "", "98123456", "USPTO", "", ""),
       ("Trademark Registration Number", "Number of the registration.", "Trademark", "Identifier", "", "7412339", "USPTO", "", "Y"),
       ("Trademark Registration Date", "Date the mark was registered.", "Trademark", "Date", "ISO 8601", "2024-06-18", "USPTO", "", ""),
       ("Nice Classes", "Nice classes of goods and services the registration covers.", "Trademark", "Code (multi)", "External (WIPO Nice Classification)", "36", "WIPO Nice", "", ""),
       ("Trademark Status", "Status of the application or registration.", "Trademark", "Code", "Trademark Status", "Registered", "USPTO", "", "Y"),
       ("Protected Brand", "Brand the mark protects.", "Trademark", "Reference (Brand)", "", "BRD-001", "Internal", "", "", "04 Brand moves to 42 under CD-271; the reference then resolves to 42."),
     ]),
     ("Trademark Docket Deadline", [
       ("Docket Registration", "Registration the deadline belongs to.", "Docket Deadline", "Reference (Trademark Registration, 39)", "", "TMARK-00318", "Internal", "", ""),
       ("Docket Deadline Type", "Kind of deadline.", "Docket Deadline", "Code", "Docket Deadline Type", "Section 8 Declaration of Use (Years 5-6)", "Lanham Act", "USPTO", ""),
       ("Docket Due Date", "Date the action is due, not counting any grace period.", "Docket Deadline", "Date", "ISO 8601", "2030-06-18", "USPTO", "", "Y"),
       ("Docket Completed Date", "Date the action was filed or completed.", "Docket Deadline", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Docket Action Status", "Whether the action has been taken.", "Docket Deadline", "Code", "Deadline Action Status", "Open", "Internal", "", ""),
     ]),
     ("Trademark License Grant", [
       ("Licensed Registration", "Trademark registration the license covers.", "License Grant", "Reference (Trademark Registration, 39)", "", "TMARK-00318", "Internal", "", ""),
       ("Licensee Entity", "Group entity licensed to use the mark.", "License Grant", "Reference (Legal Entity)", "", "LEN-0021", "Internal", "", "", "Exactly one of Licensee Entity and Licensee Party is filled."),
       ("Licensee Party", "External party licensed to use the mark (co-branding partner, sub-adviser).", "License Grant", "Reference (Party)", "", "PTY-100912", "Internal", "", ""),
       ("Licensing Contract", "Contract that grants the license.", "License Grant", "Reference (Contract, 39)", "", "CTRCT-0043310", "Internal", "", "Y"),
       ("Permitted Use", "Use of the mark the license allows.", "License Grant", "Text", "", "Use of EXAMPLE INVESTMENTS in the names of the firm's ETFs listed on NYSE Arca", "Internal", "", ""),
       ("License Effective From", "Date the license took effect.", "License Grant", "Date", "ISO 8601", "2025-01-01", "Internal", "", ""),
       ("License Effective To", "Date the license ended.", "License Grant", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 # Enterprise shared lists are cited directly as 'Shared: <name>'; the local copies were removed at the Stage 4 consolidation (CD-283).
 # Local lists
 "Contract Family": ("CLOC / Internal (CD-257). One family per instrument; where two seem to apply, the first of Constitutional Document, Settlement Agreement, Legal Services Engagement wins", [("Distribution and Intermediary Agreement","Typed in 05"),("Investment Management Agreement","Fund advisory (35), IMA for a mandate (01)"),("Fund Service Provider Agreement","Custody, administration, TA and fund audit engagement letters; untyped unless 28 lending"),("Trading and Collateral Agreement","Typed in 26"),("Data and Index License","Typed in 14"),("Supplier and Technology Agreement","Profile in 40"),("Financing and Treasury Agreement","Corporate debt, bank mandates, insurance (43)"),("Real Estate Agreement","Leases (44)"),("Intercompany Agreement","Typed in 10"),("Retirement Plan Services Agreement","Typed in 16"),("Constitutional Document","Charter, articles, bylaws, operating agreement, declaration of trust, limited partnership agreement (including the LPA of a feeder fund organized as a partnership), and the subscription agreements and side letters made under an LPA"),("Confidentiality Agreement","NDA"),("Legal Services Engagement","Outside counsel engagement letter only"),("Employment-Related Agreement","Separation or consulting agreement with an individual; settlements are Settlement Agreement"),("Settlement Agreement","Litigation or regulatory settlement"),("Other","")]),
 "Contract Subtype": ("CLOC / Internal; family shown in each description (crosswalk)", [("Selling / Dealer Agreement","Distribution and Intermediary Agreement"),("Platform Agreement","Distribution and Intermediary Agreement"),("Authorized Participant Agreement","Distribution and Intermediary Agreement"),("CIT Participation Agreement","Distribution and Intermediary Agreement; plan participation in a CIT"),("Investment Advisory Agreement","Investment Management Agreement"),("Sub-Advisory Agreement","Investment Management Agreement"),("Investment Management Agreement (Separate Account)","Investment Management Agreement"),("Custody Agreement","Fund Service Provider Agreement"),("Fund Administration Agreement","Fund Service Provider Agreement"),("Transfer Agency Agreement","Fund Service Provider Agreement"),("Securities Lending Agreement","Fund Service Provider Agreement"),("ISDA Master Agreement","Trading and Collateral Agreement"),("Index License Agreement","Data and Index License"),("Exchange Listing Agreement","Supplier and Technology Agreement; ETF listing, untyped"),("Master Services Agreement","Supplier and Technology Agreement"),("Statement of Work","Supplier and Technology Agreement"),("Software License / SaaS Agreement","Supplier and Technology Agreement"),("Data Processing Agreement","Supplier and Technology Agreement; Regulation S-P service-provider terms"),("Credit Agreement","Financing and Treasury Agreement"),("Bank Account Mandate","Financing and Treasury Agreement; untyped, references 43 Corporate Bank Account"),("Insurance Policy","Financing and Treasury Agreement"),("Office Lease","Real Estate Agreement"),("Limited Partnership Agreement","Constitutional Document"),("Subscription Agreement","Constitutional Document; a feeder fund's subscription into an underlying fund, or an investor's into a feeder"),("Side Letter","Constitutional Document; a side letter the feeder negotiates with an underlying manager (CW-166)"),("Certificate of Incorporation / Articles","Constitutional Document"),("Bylaws","Constitutional Document"),("Operating Agreement","Constitutional Document; LLC"),("Declaration of Trust","Constitutional Document"),("Mutual Non-Disclosure Agreement","Confidentiality Agreement"),("One-Way Non-Disclosure Agreement","Confidentiality Agreement"),("Engagement Letter","Legal Services Engagement"),("Settlement Agreement","Settlement Agreement"),("Other","Other")]),
 "Contract Hierarchy Role": ("Internal", [("Standalone",""),("Master / Framework",""),("Amendment",""),("Amendment and Restatement",""),("Statement of Work / Order",""),("Schedule / Addendum",""),("Side Letter",""),("Assignment / Novation",""),("Termination Agreement","")]),
 "Typed Record Type": ("Internal (CD-257; one value per typed owner)", [("None","Untyped contract; 39 masters status, dates, governing law and parties"),("Distribution Agreement (05)",""),("Data License Agreement (14)",""),("Trading Agreement (26)",""),("Fund Advisory Agreement (35)",""),("Securities Lending Agreement (28)",""),("Intercompany Agreement (10)",""),("Service Arrangement (16)",""),("Investment Mandate (01)",""),("Supplier Contract Profile (40)","Link held by 40 (keyed by CTRCT-); procurement terms only, so 39 masters status, dates, law and parties"),("Agreement Amendment (05)",""),("Debt Facility (43)",""),("Corporate Insurance Policy (43)",""),("Lease (44)","Link held by 44 Lease.Lease Contract")]),
 "Governing Law": ("05 Governing Law list, copied, with additions (see proposals_39 SHARED_CANDIDATES)", [("New York",""),("Delaware",""),("Massachusetts",""),("California",""),("Maryland","Added by 39: Maryland corporations and statutory trusts"),("England and Wales",""),("Scotland",""),("Luxembourg",""),("Ireland",""),("Germany",""),("Switzerland",""),("Other","")]),
 "Contract Party Role": ("Internal / CLOC", [("Counterparty",""),("Fund Party","Fund or registrant party to a service agreement"),("Guarantor",""),("Beneficiary",""),("Third-Party Beneficiary",""),("Agent",""),("Assignee",""),("Assignor","")]),
 "Document Role": ("CLOC / Internal", [("Main Agreement",""),("Exhibit / Schedule",""),("Signed Counterpart",""),("Data Processing Addendum",""),("Certificate / Incumbency","")]),
 "Deadline Action Status": ("Internal", [("Open",""),("Completed",""),("Waived",""),("Missed","")]),
 "Document Version Type": ("CLOC / Internal", [("Template",""),("Draft",""),("Counterparty Draft",""),("Execution Version",""),("Executed","Fully signed"),("Conformed Copy","Incorporates all amendments for reference"),("Translation","")]),
 "Key Date Type": ("CLOC / Internal", [("Renewal Date",""),("Renewal Notice Deadline",""),("Termination Notice Deadline",""),("Option Exercise Deadline",""),("Price Review Date",""),("Compliance Deliverable Due","Certificate, report or audit right exercise"),("Lock-Up / Exclusivity End","")]),
 "Clause Type": ("CLOC / Internal; Regulation S-P service-provider oversight and state privacy law", [("Limitation of Liability",""),("Indemnity",""),("Assignment and Change of Control",""),("Termination for Convenience",""),("Confidentiality",""),("Data Protection and Privacy Terms","Service-provider privacy and safeguarding terms: Regulation S-P oversight of service providers (17 CFR 248.30) and state privacy law service-provider contract terms (for example the CPRA)"),("Audit Rights",""),("Exclusivity",""),("Most-Favored-Nation",""),("Non-Solicitation",""),("Governing Law and Jurisdiction",""),("Subcontracting",""),("Business Continuity and Exit","")]),
 "Clause Position": ("Internal", [("Standard","Firm's standard language"),("Negotiated - Within Fallback","Within pre-approved fallback positions"),("Non-Standard - Approved","Outside fallbacks; approved by the clause owner"),("Not Present","Clause absent from the contract")]),
 "Legal Request Type": ("CLOC / Internal", [("Contract Review - Firm Paper",""),("Contract Review - Third-Party Paper",""),("NDA",""),("Amendment",""),("Legal Advice",""),("Regulatory Interpretation",""),("Corporate Secretarial Request","Resolution, filing, power of attorney"),("Trademark Clearance",""),("Litigation Support","")]),
 "Legal Matter Type": ("CLOC / Internal", [("Commercial Litigation",""),("Class Action - Defendant",""),("Arbitration",""),("Regulatory Enforcement Investigation","Formal order of investigation (CD-253)"),("Regulatory Enforcement Proceeding",""),("Subpoena / Third-Party Request","Firm is not a party"),("Employment Dispute",""),("Intellectual Property Dispute",""),("Pre-Litigation Dispute",""),("Class Action Claim - Claimant","Firm or funds as claimant, not the 28 class action claim filing")]),
 "Forum Type": ("Internal", [("US Federal Court",""),("US State Court",""),("Non-US Court","Court outside the US, for example a foreign collective action in which a fund is claimant or a dispute under an English-law contract (CW-022)"),("Arbitral Tribunal",""),("FINRA Dispute Resolution",""),("Regulator","Investigation or administrative proceeding"),("Trademark Office","Opposition or cancellation"),("None","Pre-litigation"),("Other","")]),
 "Matter Party Role": ("Internal", [("Plaintiff / Claimant",""),("Defendant / Respondent",""),("Co-Defendant",""),("Opposing Counsel",""),("Witness",""),("Subpoenaed Party",""),("Insurer","")]),
 "Matter Event Type": ("Internal / FRCP / SEC Enforcement Manual", [("Complaint Served",""),("Subpoena Received",""),("Wells Notice Received",""),("Wells Submission Filed",""),("Motion Filed",""),("Discovery Cut-Off Reached",""),("Hearing",""),("Mediation",""),("Settlement Agreed",""),("Judgment / Award",""),("Appeal Filed",""),("Matter Closed","")]),
 "ASC 450 Likelihood": ("FASB ASC 450-20", [("Probable","Likely to occur; accrue if reasonably estimable"),("Reasonably Possible","More than remote but less than likely; disclose"),("Remote","Slight chance; no disclosure required")]),
 "IAS 37 Likelihood": ("IAS 37", [("Probable","More likely than not; recognize a provision if reliably estimable"),("Possible","Not probable and not remote; disclose a contingent liability"),("Remote","No disclosure required")]),
 "Hold Status": ("Sedona Conference / Internal", [("Draft",""),("Issued",""),("Active","In force"),("Partially Released","Some custodians or scope released"),("Released","")]),
 "Hold Scope Type": ("Sedona Conference / Internal", [("Record Class","21 retention rule"),("Application","41 application"),("Data Asset","21 data asset"),("Party","02 party records"),("Custodian Mailbox and Files","Covered through Legal Hold Custodian"),("Physical Records","")]),
 "Custodian Acknowledgment Status": ("Sedona Conference / Internal", [("Notice Sent",""),("Acknowledged",""),("Reminder Sent","Not yet acknowledged after reminder"),("Escalated","Escalated to the custodian's manager"),("Released","")]),
 "Corporate Body Type": ("DGCL; Internal", [("Board of Directors",""),("Board of Managers","LLC, including a feeder fund general partner"),("Executive Committee",""),("Audit Committee","Of the corporate group"),("Risk Committee",""),("Compensation Committee",""),("Nomination Committee",""),("Shareholders / Members (as a body)","Shareholders or members of the entity; their meetings and consents are Corporate Meeting Types")]),
 "Corporate Member Role": ("Internal", [("Chair",""),("Executive Director",""),("Independent / Outside Director",""),("Manager","LLC board of managers"),("Committee Member",""),("Corporate Secretary","Attends; not a voting member"),("Observer","")]),
 "Corporate Officer Role": ("DGCL s.142; SEC Rule 206(4)-7; 31 CFR 1023.210", [("President / Chief Executive Officer",""),("Secretary",""),("Treasurer / Chief Financial Officer",""),("Chief Compliance Officer (Rule 206(4)-7)","Investment adviser CCO"),("AML Compliance Officer / BSA Officer","Broker-dealer AML program (31 CFR 1023.210)"),("Managing Member","LLC"),("Other","")]),
 "Corporate Meeting Type": ("DGCL", [("Regular Board Meeting",""),("Special Board Meeting",""),("Committee Meeting",""),("Annual Meeting of Stockholders",""),("Special Meeting of Stockholders",""),("Unanimous Written Consent","DGCL s.141(f)"),("Stockholder Written Consent","DGCL s.228")]),
 "Corporate Resolution Subject Type": ("Internal (one link per approval)", [("Contract (39)",""),("Corporate Body Membership (39)",""),("Corporate Officer Appointment (39)",""),("Power of Attorney (39)",""),("Signing Authority Grant (39)",""),("Risk Appetite Statement (37)",""),("Audit Plan (37)",""),("Policy Version (38)",""),("Debt Facility (43)",""),("Intra-Group Capital Transaction (43)",""),("Corporate Publication (42)",""),("Other","Free-text subject")]),
 "Statutory Filing Type": ("DGCL; Maryland SDAT; other state annual report laws; FinCEN BOI", [("Delaware Annual Franchise Tax Report",""),("Maryland Annual Report and Personal Property Return",""),("Other State Annual Report","Annual report or statement of information in another state of formation or foreign qualification (for example Pennsylvania)"),("FinCEN BOI Report","Lever only (confirm): an entity formed under foreign law and registered to do business in a state; the firm's own US entities file no BOI report under FinCEN's August 2026 final rule"),("Other","")]),
 "Power of Attorney Type": ("Internal", [("General Corporate",""),("Limited - Specific Transactions",""),("Litigation",""),("Tax Representation","IRS Form 2848 or foreign equivalent"),("Registry and Filing",""),("Local Market Registration","Custody or tax registration in a foreign market")]),
 "Authority Type": ("Internal", [("Contract Signature",""),("Payment Approval",""),("Regulatory Filing Signature",""),("Trading Authority Letter",""),("Litigation Settlement",""),("Hiring and Compensation Approval","")]),
 "IP Office": ("WIPO / national offices", [("USPTO","United States Patent and Trademark Office"),("WIPO Madrid","International registration"),("Other National Office","")]),
 "Trademark Status": ("USPTO TSDR", [("Application Filed",""),("Under Examination",""),("Published for Opposition",""),("Opposed",""),("Registered",""),("Abandoned / Withdrawn",""),("Canceled / Expired","")]),
 "Docket Deadline Type": ("Lanham Act ss.8, 9, 15; WIPO Madrid", [("Office Action Response",""),("Opposition Window Close",""),("Section 8 Declaration of Use (Years 5-6)","US"),("Section 15 Incontestability Declaration","US, optional"),("Renewal (Sections 8 and 9)","US, every 10 years"),("Madrid Dependency Period End","Five years from international registration")]),
}

# ---------------------------------------------------------------------------
REL = [
 ("Contract","is bound by","Internal Legal Entity [09]","n : 1","Contracting Entity; 09 keeps the entity record."),
 ("Contract","is a child of","Contract (parent)","n : 0..1","Amendment, SOW, schedule or side letter of a master."),
 ("Contract","is typed by","Typed Contract Link","1 : 1","At most one typed record per contract (CD-257)."),
 ("Typed Contract Link","points to","Distribution Agreement or Agreement Amendment [05] / Data License Agreement [14] / Trading Agreement [26] / Fund Advisory Agreement [35]","1 : 0..1","One contract per typed record; each amendment is its own contract. Typed owner keeps commercial terms; 39 dates, status, law and roles are Derived copies on these rows."),
 ("Typed Contract Link","points to","Securities Lending Agreement [28] / Intercompany Agreement [10] / Service Arrangement [16] / Investment Mandate [01]","1 : 0..1","Side letters at the letter level (commitment x date)."),
 ("Supplier Contract Profile [40]","is keyed by","Contract","0..1 : 1","40 holds the link (keyed by CTRCT-); procurement terms only."),
 ("Typed Contract Link","points to","Debt Facility, Corporate Insurance Policy [43]","1 : 0..1",""),
 ("Lease [44]","is documented by","Contract","0..1 : 1","44 Lease.Lease Contract holds the link (program lead ruling)."),
 ("Contract (bank mandate)","governs","Corporate Bank Account [43]","n : 0..1","Untyped contract; 43 keeps the account and its signatories."),
 ("Servicing Provider Engagement [13]","is governed by","Contract","n : 0..1","TA service agreements are untyped contracts; 13 holds the link (proposed)."),
 ("Contract","has","Contract Party","1 : 1..n","Each party is an 02 Party or a 09 entity, effective-dated."),
 ("Contract","is signed by","Contract Signatory","1 : 0..n","Signatory relies on a Power of Attorney or Signing Authority Grant; constitutional documents adopted by resolution and legacy loads may have none."),
 ("Contract","has","Contract Document Version","1 : 1..n","The only executed-copy record: 05 Distribution Agreement.Executed Contract references CTRCT-; the 05 Agreement Document (DOC-) is retired (CW-131)."),
 ("Contract","has","Contract Key Date / Contract Clause Position","1 : 0..n",""),
 ("Legal Service Request","may result in","Contract","n : 0..1",""),
 ("Legal Matter","has","Matter Party / Matter Event","1 : 1..n","Parties are 02 parties, 09 entities or 20 employees."),
 ("Legal Matter","may originate from","Regulatory Examination [38]","n : 0..1","CD-253."),
 ("Legal Matter","is assessed by","Matter Financial Assessment","1 : 0..n","Reserve posted as a 19 Journal Entry."),
 ("Operational Loss Event [37]","may arise from","Legal Matter","n : 0..1","37 holds the link; settlements and fines feed loss data."),
 ("Legal Matter","is handled by","Outside Counsel Engagement","1 : 0..n","Engagement keyed by its engagement letter Contract; the firm is an 02 Party."),
 ("Outside Counsel Invoice Review","reviews","Payable Invoice [19]","1 : 1","19 books and pays."),
 ("Legal Hold","preserves for","Legal Matter / Regulatory Examination [38]","n : 1",""),
 ("Legal Hold","binds","Legal Hold Custodian -> Employee [20]","1 : 1..n",""),
 ("Legal Hold Scope","covers","Retention Rule [21] / Application [41] / Data Asset [21] / Party [02]","n : 1","Source of the 02 and 08 Legal Hold Indicators (Derived copies, CD-258); the retention schedule is 21 (CW-068)."),
 ("Corporate Governing Body","governs","Internal Legal Entity [09]","n : 1","Never a fund or fund-management entity (35, CD-231)."),
 ("Corporate Governing Body","has","Corporate Body Membership","1 : 1..n","Members are 20 employees or 02 parties."),
 ("Internal Legal Entity [09]","has","Corporate Officer Appointment","1 : 0..n","Notified through a 38 Firm Regulatory Filing where required."),
 ("Corporate Board Meeting","adopts","Corporate Resolution","1 : 0..n","Written consents are meetings of a consent type."),
 ("Corporate Resolution","approves","Corporate Resolution Subject Link -> Contract / Body Membership / Officer Appointment / Power of Attorney / Signing Authority Grant / Risk Appetite Statement, Audit Plan [37] / Policy Version [38] / Debt Facility, Capital Transaction [43] / Corporate Publication [42]","1 : 0..n","One link per approval; consumers hold none."),
 ("Internal Legal Entity [09]","files","Entity Statutory Filing","1 : 0..n",""),
 ("Power of Attorney","is granted by","Internal Legal Entity [09]","n : 1","Attorney is a 20 employee or 02 party; the authorizing resolution is found through Corporate Resolution Subject Link."),
 ("Signing Authority Grant","authorizes","Employee [20] for Internal Legal Entity [09]","n : 1",""),
 ("Trademark Registration","protects","Brand [04, moving to 42]","n : 0..1","CD-259, CD-271."),
 ("Trademark Registration","has","Trademark Docket Deadline / Trademark License Grant","1 : 0..n","License granted by a Contract."),
 ("Fund Governing Body [35]","is distinct from","Corporate Governing Body","n/a","CD-231, CD-259."),
]

# ---------------------------------------------------------------------------
SRC = [
 ("CLOC Core 12 and Legal Operations Maturity Model","Corporate Legal Operations Consortium (CLOC)","https://cloc.org","Member framework (confirm public pages)","Intake, contract lifecycle, matter management, outside counsel management","Legal Service Request, Contract, Contract Key Date, Outside Counsel Engagement",["CLOC"]),
 ("LEDES e-billing formats (LEDES 1998B, LEDES XML 2.x) and ABA UTBMS code sets","LEDES Oversight Committee; American Bar Association","https://ledes.org","Open standard","Invoice line format, task, activity and expense codes","Outside Counsel Invoice Review, Outside Counsel Engagement",["LEDES","ABA UTBMS"]),
 ("Federal Rules of Civil Procedure 26 (discovery) and 37(e) (failure to preserve ESI); Zubulake v. UBS Warburg (S.D.N.Y. 2003-2004)","US Courts; Cornell LII","https://www.law.cornell.edu/rules/frcp/rule_37","Public law","Duty to preserve, trigger date, sanctions for spoliation, privilege","Legal Hold, Legal Hold Scope, Legal Matter",["FRCP*"]),
 ("The Sedona Conference Commentary on Legal Holds, Second Edition: The Trigger and The Process","The Sedona Conference","https://thesedonaconference.org","Free publication (confirm path)","Hold notices, custodians, acknowledgment, reminders, scope and release","Legal Hold, Legal Hold Custodian, Legal Hold Scope, Hold Status",["Sedona Conference"]),
 ("Delaware General Corporation Law, Title 8 Chapter 1 (ss.141 board, 142 officers, 228 written consent; franchise tax)","State of Delaware","https://delcode.delaware.gov/title8/c001/","Public law","Board powers and committees, officers, written consents","Corporate Governing Body, Corporate Officer Appointment, Corporate Meeting Type, Statutory Filing Type",["DGCL"]),
 ("Maryland Corporations and Associations Article (General Corporation Law; Maryland Statutory Trust Act) and SDAT annual report","State of Maryland","https://dat.maryland.gov","Public law (confirm statute page)","Maryland corporations and statutory trusts used for funds and entities; annual report","Governing Law, Statutory Filing Type",["Maryland law"]),
 ("FinCEN Beneficial Ownership Information Reporting final rule (August 2026) exempting domestic entities and US persons (Federal Register citation to confirm)","US FinCEN","https://www.fincen.gov/boi","Regulation","Permanent domestic exemption; reporting only by entities formed under foreign law and registered in a state","Entity Statutory Filing (Filing Exemption Indicator)",["FinCEN BOI"]),
 ("FASB ASC 450-20 Loss Contingencies","FASB","https://asc.fasb.org","Licensed (cite topic only)","Probable, reasonably possible and remote; accrual and disclosure","Matter Financial Assessment, ASC 450 Likelihood",["ASC 450"]),
 ("IAS 37 Provisions, Contingent Liabilities and Contingent Assets","IFRS Foundation","https://www.ifrs.org/issued-standards/list-of-standards/ias-37-provisions-contingent-liabilities-and-contingent-assets/","Licensed standard (summary public)","Provision recognition, contingent liability disclosure","Matter Financial Assessment",["IAS 37"]),
 ("SEC Division of Enforcement, Enforcement Manual (current edition, updated 2026-02-24): Wells process, formal orders, subpoenas","US SEC","https://www.sec.gov/divisions/enforce/enforcementmanual.pdf","Public guidance","Enforcement investigation stages, Wells notices and submissions","Legal Matter Type, Matter Event Type",["SEC Enforcement Manual"]),
 ("USPTO trademark basics and TSDR; Lanham Act ss.8, 9 and 15 (15 U.S.C. 1058, 1059, 1065)","USPTO","https://www.uspto.gov/trademarks","Public","Application and registration numbers, statuses, maintenance filings","Trademark Registration, Trademark Docket Deadline, Docket Deadline Type",["USPTO","Lanham Act"]),
 ("WIPO Nice Classification and Madrid System","WIPO","https://www.wipo.int/classifications/nice/en/","Public","Classes of goods and services; international registration and dependency","Nice Classes, IP Office, Docket Deadline Type",["WIPO*"]),
 ("eIDAS Regulation (EU) No 910/2014 and the US ESIGN Act (15 U.S.C. 7001)","European Union; US Congress","https://eur-lex.europa.eu/eli/reg/2014/910/oj","Public law","Validity of electronic signatures","Contract Signatory, Contract Document Version",["eIDAS","ESIGN Act"]),
 ("SEC Rule 204-2, SEC Rule 17a-4 and FINRA Rule 4511 (books and records)","US SEC; FINRA","https://www.ecfr.gov/current/title-17/chapter-II/part-275/section-275.204-2","Regulation","Retention context that a legal hold suspends","Legal Hold Scope",["SEC Rule 204-2","SEC Rule 17a-4","FINRA Rule 4511"]),
 ("SEC Form ADV and Rule 206(4)-7","US SEC","https://www.sec.gov/about/forms/formadv.pdf","Regulation","CCO designation and disclosure","Corporate Officer Appointment, Corporate Officer Role",["SEC Form ADV","SEC Rule 206(4)-7"]),
 ("SEC Regulation S-P, 17 CFR 248.30 (safeguards, incident response and oversight of service providers, as amended 2024; amendments in force)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-248/subpart-A","Regulation","Service-provider oversight terms that data protection clauses implement","Clause Type",["Regulation S-P"]),
 ("ASC 842 and IFRS 16 (leases), OECD Transfer Pricing Guidelines","FASB; IFRS Foundation; OECD","https://www.ifrs.org/issued-standards/list-of-standards/ifrs-16-leases/","Licensed / public","Context for the typed lease and intercompany records 39 links to","Typed Contract Link",["ASC 842","IFRS 16","OECD TPG"]),
 ("Vendor cross-checks: Ironclad, Icertis (CLM); Diligent Entities (entity management); Mitratech, Onit (matter management) - public product descriptions","Vendors","https://www.diligent.com","Vendor documentation (structure only)","Common structures for contract repositories, entity boards and officers, matters and e-billing","Contract, Corporate Governing Body, Legal Matter",["Diligent Entities","Ironclad / Icertis"]),
 ("ISO 3166 / ISO 4217 / ISO 8601","ISO","https://www.iso.org","Standard; code lists widely available","Country, currency and date formats","Reference formats used throughout",["ISO 3166","ISO 4217","ISO 8601"]),
]
