"""Data Domain 40 - Procurement & Vendor Management. Content module for taxonomy_builder.py."""

META = {
 "title": "Procurement & Vendor Management Data Taxonomy",
 "subtitle": "Business domain 40 - Procurement & Vendor Management | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "40_Procurement_and_Vendor_Management/Procurement_and_Vendor_Management_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the procurement and third-party records of a US wealth manager (direct brokerage, digital and human advice, its own mutual funds, ETFs and CITs, workplace recordkeeping, institutional advisory and optional trust services) that buys technology, data, services, outsourced operations, contingent labor and facilities for every group entity: the investment adviser, the self-clearing broker-dealer, the fund complex and the optional trust company. It defines the supplier profile kept for each external party the firm buys from, the remittance details used to pay it, how a supplier is onboarded and screened, what the firm buys from whom and for which unit (the supplier engagement), how sourcing events the firm issues are run and awarded, the purchase-to-pay chain from requisition to purchase order, receipt and the match of each supplier invoice line before 19 Finance & Accounting pays it, the procurement terms and service levels of supplier contracts, supplier performance and spend, the inherent criticality tier that sets due-diligence depth, and the outsourcing register with exit plans that evidences the broker-dealer's supervision of outsourced functions (FINRA Rule 3110 and Regulatory Notice 21-29), the oversight of fund service providers (SEC Rule 38a-1), the oversight of service providers with access to customer information (Regulation S-P as amended in 2024) and the trust company's third-party risk management (the 2023 interagency guidance). It is stewarded by the procurement and vendor management office, which is why it sits apart from the party master (02), the accounting record of invoices and payments (19), the contract repository (39) and residual third-party risk (37). Stitched together from FINRA Rule 3110 and Regulatory Notice 21-29, SEC Rule 38a-1, Regulation S-P, the US interagency third-party risk guidance, ISO 20400, UNSPSC, UN/CEFACT Buy-Ship-Pay, IRS Forms W-9 and W-8 and public Coupa and SAP Ariba documentation. Use it as a starting point for a supplier master, a procure-to-pay data model or a vendor oversight and outsourcing register."),
  ("Scope", "In scope: supplier profiles (supplier status history, ERP supplier number, default terms, diversity certifications), supplier remittance details, supplier onboarding cases, supplier engagements and their links to the 14, 13, 28 and 01 specializations, supplier category assignments; sourcing events the firm issues (RFI, Sourcing RFP, RFQ, reverse auction, single-source justification), invitations, bids and awards per supplier; purchase requisitions, purchase orders and lines, goods and service receipts and invoice match results against 19 payable invoice lines; supplier contract profiles (procurement terms of a 39 contract) and contracted service levels; supplier performance reviews, service level measurement results and supplier spend summaries; supplier risk tiering (inherent criticality), outsourcing arrangements and exit plans. Out of scope (referenced by ID): party identity, LEI, addresses, contacts and tax status (02 Client & Household, the party core for every external party); legal entities, org units, offices and fiscal periods (09 Shared & Enterprise Reference Data); payable invoices, supplier payments, GL accounts and cost centers (19 Finance & Accounting); employees and contingent worker detail (20 Human Capital); data assets (21); data vendors, data licenses, data invoices, vendor risk assessments and vendor data SLAs (14 Third-Party Data & Licensing); servicing provider engagements and their SLAs (13); recordkeeping service arrangements (16); custody provider profiles (28); fund service provider appointments (01); RFPs the firm answers (03); residual third-party risk and critical or important functions (37 Enterprise & Operational Risk); AML cases and conflicts (38 Corporate Compliance & Regulatory Affairs); contracts, their dates, parties, governing law and clauses (39 Legal & Corporate Governance); IT services and applications (41 Technology & Information Security); corporate bank accounts (43); facility work orders and expense reports (44 Workplace & Corporate Services). The firm is regulated in the US only; no EU or UK register of ICT arrangements or outsourcing notification is kept (CW-940)."),
  ("Structure", "Four levels: Data Domain > Data Family > Data Business Object > Data Business Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "A supplier is a 02 party (PTY-) with one Supplier Profile here, which carries the ERP supplier number, dated supplier status and default terms; Supplier Remittance Details hang off the profile and Supplier Onboarding Cases record each screening and approval (screening hits escalate to 38, which holds the only link). A Supplier Engagement (VENG-) records what the firm buys from the supplier, for which business owner, unit and buying entity, whether it is fund-paid, and links to the specialization that holds domain-specific facts (14 Data Vendor, 13 Servicing Provider Engagement, 28 Custody Provider Profile, 01 Product Party Role); Supplier Category Assignments classify it by UNSPSC and firm category. A Sourcing Event (SRCG-) the firm issues invites suppliers (Sourcing Invitation) and ends in one Sourcing Award per awarded supplier, each naming its share, engagement and 39 contract. A Purchase Requisition (PREQ-) becomes Purchase Order (PURCH-) lines, which are received (Goods and Service Receipt) and matched to 19 payable invoice lines (Invoice Match Result, with matched quantity, amount and price) before 19 pays. Each supplier contract is a 39 Contract (CTRCT-) with a Supplier Contract Profile here, and Contracted Service Levels measured in Service Level Measurement Results. Supplier Performance Reviews and Supplier Spend Summaries close the loop. Supplier Risk Tiering gives each engagement a dated inherent criticality tier; 37 Third-Party Risk Assessment holds the residual result. Outsourcing Arrangements (OUTS-) with their Exit Plan form the outsourcing register: each names the internal entity that outsources, the function, the US oversight regimes it falls under (FINRA Rule 3110 for the broker-dealer, SEC Rule 38a-1 for the funds, Regulation S-P for customer information, the interagency guidance for the trust company) and the 37 critical or important functions it supports."),
  ("Design principles", "1) One supplier, specialized profiles (CD-260): the supplier is a 02 party with one 40 profile; 14, 13 and 28 hold specializations keyed by the same party and hold no copy of the profile, apart from 14 'Procurement Supplier ID', which becomes a Derived copy (40). Each engagement is performance-reviewed in exactly one of 40, 14, 13 or 28. 2) The firm issues here, answers in 03: a Sourcing Event is an RFI, RFP or RFQ the firm sends to suppliers; 'RFP' is always qualified ('Sourcing RFP', 'Client RFP'). 3) Order and match here, invoice and payment in 19 (CD-158): 40 holds no invoice header, tax or payment amount; the match holds the quantities, amounts and prices it applied. 4) Firm purchases only: fund expenses paid by the funds (27) are not firm purchase orders, though the engagement (flagged fund-paid) and the outsourcing classification still apply where the firm oversees the provider. 5) Tier here, risk in 37, register here (CD-248, CD-249, CD-261): the inherent criticality tier is a dated classification here; the residual rating and the designation of functions are 37's; the outsourcing register is 40's. 6) Terms here, contract in 39 (CD-257): contract dates, governing law, parties and clauses are 39's and appear here only as Derived copies where the register needs them. 7) Oversight records follow the third-party lifecycle of the 2023 interagency guidance and FINRA Regulatory Notice 21-29 (planning, due diligence, contract negotiation, ongoing monitoring, termination), so each fact is held once, at the stage that produces it. 8) Effective-date statuses, tiers, categories, engagements, remittance details and contracted service levels; date receipts and matches. 9) Flag personal data (PII) for individual suppliers, remittance details and employees, and sensitive personal information under state privacy laws where a certification reveals it. 10) Flag Critical Data Elements (CDE)."),
  ("Applies To", "Shows the record each attribute belongs to: Supplier, Remittance, Onboarding, Engagement, Category, Sourcing Event, Award, Invitation, Requisition, Purchase Order, PO Line, Receipt, Invoice Match, Contract Profile, Service Level, Performance Review, Service Level Result, Spend Summary, Risk Tiering, Outsourcing or Exit Plan."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify a supplier and match it to the ERP and the 02 party, to pay the right bank account, to know what is bought from whom under which contract and purchase order, to match invoices before payment, to set due-diligence depth, and to evidence the oversight of outsourced functions and service providers to FINRA, the SEC and the trust company's regulator. Confirm with the head of procurement, accounts payable, TPRM and compliance."),
  ("Primary / Secondary Reference", "Standard, rule or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Regulatory references (FINRA Rule 3110 and Regulatory Notice 21-29, SEC Rule 38a-1, Regulation S-P, the 2023 interagency third-party guidance) indicate the requirement that makes the data necessary; none of them prescribes a register layout, so the outsourcing register fields are firm-defined. Vendor references (Coupa, SAP Ariba) indicate common procurement-suite structure, not a license to reproduce vendor record layouts."),
  ("Notes", "PII = personal data under US state privacy laws (for example the California Consumer Privacy Act as amended by the CPRA, which covers business contacts and employees); Regulation S-P governs the customer information the firm shares with service providers. A supplier that is an individual (sole proprietor, independent consultant) makes its profile, remittance details and spend personal data; two diversity certification values reveal sensitive personal information (sexual orientation, health) for an individual. Employees named as requesters, approvers, buyers and receivers are personal data of internal staff. Remittance bank details are classified 'Restricted - Personal Data' for individual suppliers (Restricted otherwise) and held masked; the account verification date evidences the call-back control against payment-redirection fraud. Supplier screening hits escalate to a 38 AML Case; the case number is never held here (SAR confidentiality)."),
  ("Tabs", "Hierarchy: families, object groups and objects with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: object-level cardinalities, including references to other Data Domains | Sources: standards used, owners, licenses and links."),
  ("Suggested next steps", "1) Validate families, supplier statuses, categories, PO types, criticality tiers and drivers, outsourcing regimes and CDEs with procurement, accounts payable, TPRM, compliance (broker-dealer and fund CCO) and legal. 2) Done at the Stage 4 consolidation: 19 Payable Invoice 'Purchase Order Reference' references the Purchase Order (CD-260). Still to agree with 19: invoiced quantity and unit price on Payable Invoice Line, and a remit-to account reference on Supplier Payment (CD-158, CD-260). 3) Done at the Stage 4 consolidation: 14 'Procurement Supplier ID' is a Derived copy (40) (CD-260). 4) Agree with 02 whether supplier tax status is held on the 02 Tax Profile of the supplier party, so that Tax Form on File can become a Derived copy (02). 5) Done at the Stage 4 consolidation: 20 'Supplier Contract Reference' references the 39 Contract (CD-257). 6) Agree with 37 that neither 37 nor 40 copies the other's rating (CD-248), and which functions count as critical activities under the interagency guidance and FINRA Regulatory Notice 21-29. 7) Agree with 39 the notice-period sides of supplier contracts. 8) Map attributes to the procurement suite, the ERP supplier master and the vendor oversight tool. 9) Done at the Stage 4 consolidation: 40 cites the enterprise shared lists directly."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

EMP_PII = "PII (internal staff)."
SUP_PII = "PII when the supplier is an individual (sole proprietor or independent consultant)."

# ---------------------------------------------------------------------------
D("Supplier Management", "VM-SUP",
  "The supplier record kept for every external party the firm buys from: the supplier profile and its dated status, the remittance details used to pay it, onboarding and screening cases, what the firm buys from it (supplier engagements, linked to the data-vendor, servicing, custody and fund service specializations) and how each engagement is categorized. Party identity, LEI, addresses, contacts, tax status and TINs are mastered in 02; the supplier's tax form on file (payee Form W-9 or W-8) is mastered here (CW-940).",
  [
   ("Supplier Profile", "The supplier role profile of a 02 party: ERP supplier number, dated status, default commercial terms and certifications.", [
     ("Supplier Profile", [
       ("Supplier Party", "02 party the profile describes; identity, legal form, LEI, addresses and contacts stay in 02.", "Supplier", "Reference (Party)", "", "PTY-702114", "Internal", "Coupa", "Y", SUP_PII),
       ("ERP Supplier Number", "Number of the supplier in the ERP supplier master, used on purchase orders and payable invoices; written without a hyphenated stem.", "Supplier", "Identifier", "External (ERP supplier master)", "SUP 0045521", "SAP Ariba", "Coupa", "Y", "14 Data Vendor 'Procurement Supplier ID' becomes a Derived copy of this value (CD-260)."),
       ("Supplier Status", "Whether the firm may buy from the supplier: prospect, approved, restricted, blocked or inactive.", "Supplier", "Code", "Supplier Status", "Approved", "Internal", "ISO 20400", "Y"),
       ("Supplier Status Effective From", "Date the supplier status took effect.", "Supplier", "Date", "ISO 8601", "2025-03-14", "Internal", "", ""),
       ("Supplier Status Effective To", "Date the supplier status was superseded; empty for the current status. One row per status period keeps the history of blocks and reinstatements.", "Supplier", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Default Payment Terms", "Payment terms applied to purchase orders unless a contract or order says otherwise.", "Supplier", "Code", "Payment Terms", "Net 30", "Internal", "UN/CEFACT Buy-Ship-Pay", ""),
       ("Diversity Certifications", "Small, minority-owned, women-owned, veteran-owned or other diverse business certifications the supplier holds.", "Supplier", "Code (multi)", "Diversity Certification Type", "Women-Owned Business Enterprise; Small Business", "US SBA", "Internal", "", SUP_PII + " Sensitive personal information under state privacy laws for an individual supplier holding 'LGBTQ+-Owned Business Enterprise' or 'Disability-Owned Business Enterprise'; restrict access to those values."),
       ("Tax Form on File", "IRS form or self-certification held for the supplier for information reporting and withholding.", "Supplier", "Code", "Tax Form Type", "W-9", "IRS Form W-9", "IRS Form W-8BEN-E", "", SUP_PII + " Mastered here for suppliers (CW-940): the wealth 02 Tax Profile holds the party's tax classification and masked TIN, and client forms are 15 Account Tax Certifications; becomes a Derived copy (02) if 02 extends the form on file to the Supplier role (proposed). The TIN is held masked in 02 only."),
       ("Supplier Relationship Manager", "Procurement employee accountable for the supplier relationship.", "Supplier", "Reference (Employee)", "", "EMP-20417", "Internal", "", "", EMP_PII),
     ]),
   ]),
   ("Supplier Remittance Detail", "The bank accounts a supplier is paid into, each verified by call-back before first use.", [
     ("Supplier Remittance Detail", [
       ("Remittance Supplier", "Supplier whose payments go to the remittance account.", "Remittance", "Reference (Party)", "", "PTY-702114", "Internal", "", "", SUP_PII),
       ("Remittance Sequence", "Sequence number of the remittance account among the supplier's accounts.", "Remittance", "Integer", "", "1", "Internal", "", ""),
       ("Bank Account Number (Masked)", "Remit-to bank account number (or IBAN for a supplier paid abroad), held masked outside the payment system.", "Remittance", "Identifier", "", "******4471", "ISO 20022", "ISO 13616", "Y", "Restricted - Personal Data for an individual supplier; Restricted otherwise."),
       ("Bank Identifier", "ABA routing number of the remit-to bank, or its BIC for a supplier paid abroad.", "Remittance", "Identifier", "External (ABA routing number / ISO 9362 BIC)", "021000021", "ISO 20022", "ISO 9362", "", "Restricted."),
       ("Account Verified Date", "Date the bank details were confirmed by call-back to a known supplier contact, the control against payment-redirection fraud.", "Remittance", "Date", "ISO 8601", "2025-03-12", "Internal", "", "Y"),
       ("Remittance Effective From", "Date from which payments may be made to the account.", "Remittance", "Date", "ISO 8601", "2025-03-14", "Internal", "", ""),
       ("Remittance Effective To", "Date after which the account may no longer be paid.", "Remittance", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Supplier Onboarding", "Each onboarding or re-onboarding case for a supplier: screening, insurance, information security and conflicts checks, approval and completion.", [
     ("Supplier Onboarding Case", [
       ("Onboarding Supplier", "Supplier being onboarded.", "Onboarding", "Reference (Party)", "", "PTY-702114", "Internal", "", "", SUP_PII),
       ("Onboarding Sequence", "Sequence number of the case for the supplier (first onboarding, re-onboarding, periodic refresh).", "Onboarding", "Integer", "", "2", "Internal", "", ""),
       ("Completed Onboarding Steps", "Onboarding steps completed on the case.", "Onboarding", "Code (multi)", "Onboarding Step", "Sanctions Screening; Insurance Certificate; Information Security Questionnaire", "Internal", "US Interagency TPRM Guidance", ""),
       ("Sanctions Screening Result", "Disposition of the screening of the supplier and its owners against sanctions lists.", "Onboarding", "Code", "Shared: Screening Result", "No Match", "OFAC", "", "Y", "A Confirmed Match escalates to 38, whose AML Case holds the only link to this case (Source Supplier Onboarding Case); the case number is not held here."),
       ("Onboarding Case Status", "Workflow status of the onboarding case.", "Onboarding", "Code", "Shared: Case Status", "Resolved / Completed", "Internal", "", "Y"),
       ("Onboarding Approval Status", "Outcome of the approval to use the supplier.", "Onboarding", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("Onboarding Completed Date", "Date every required step was completed and the case closed.", "Onboarding", "Date", "ISO 8601", "2025-03-14", "Internal", "", ""),
     ]),
   ]),
   ("Supplier Engagement", "What the firm buys from a supplier, for which owner, unit and buying entity, who pays, and the specialization record that holds domain-specific facts.", [
     ("Supplier Engagement", [
       ("Supplier Engagement ID", "Enterprise identifier of the supplier engagement.", "Engagement", "Identifier", "", "VENG-001877", "Internal", "", "Y"),
       ("Engaged Supplier", "Supplier the engagement is with.", "Engagement", "Reference (Party)", "", "PTY-702114", "Internal", "", "Y", SUP_PII),
       ("Service Description", "What is bought under the engagement, in business terms.", "Engagement", "Text", "", "SaaS data warehouse, support and professional services for the enterprise data platform", "ISO 20400", "", ""),
       ("Engagement Business Owner", "Employee accountable for the service received under the engagement.", "Engagement", "Reference (Employee)", "", "EMP-01877", "US Interagency TPRM Guidance", "", "Y", EMP_PII),
       ("Requesting Org Unit", "09 org unit that consumes the service.", "Engagement", "Reference (Org Unit)", "", "OU-TECH-DATA", "Internal", "", ""),
       ("Engagement Buying Entity", "Internal legal entity that contracts for and pays for the service.", "Engagement", "Reference (Legal Entity)", "", "LEN-0004", "Internal", "", "Y"),
       ("Engagement Business Lines", "Business lines the service supports.", "Engagement", "Code (multi)", "Shared: Business Line", "PF; DB", "Internal", "", ""),
       ("Fund-Paid Indicator", "Whether the provider is paid by the funds under a fund service agreement (27 fund expense) rather than by the firm; fund-paid engagements carry no 40 purchase order.", "Engagement", "Boolean", "", "N", "Internal", "SEC Rule 38a-1", "", "Brief rule 4."),
       ("Specialized Data Vendor", "14 Data Vendor profile of the same party, where the engagement buys licensed data.", "Engagement", "Reference (Data Vendor, 14)", "", "PTY-500210", "Internal", "", "", "Keyed by the same party (CD-260 rule 1)."),
       ("Specialized Servicing Provider Engagement", "29 servicing provider engagement (party x servicing role) the engagement corresponds to, where the supplier services fund shareholders.", "Engagement", "Reference (Servicing Provider Engagement, 29)", "", "PTY-100990 / Transfer Agent / Registrar", "Internal", "", ""),
       ("Specialized Custody Provider Profile", "28 custody provider profile (party x custody role x effective period) the engagement corresponds to.", "Engagement", "Reference (Custody Provider Profile, 28)", "", "PTY-100912 / Global Custodian / 2024-01-01", "Internal", "", ""),
       ("Fund Service Provider Role", "01 product party role (product x party x role type x effective period) by which a fund appointed the provider, where the firm oversees a fund-appointed provider.", "Engagement", "Reference (Product Party Role, 01)", "", "PRD-00981 / PTY-100455 / Fund Administrator / 2024-01-01", "SEC Rule 38a-1", "", ""),
       ("Shared Data Assets", "21 data assets the supplier receives or processes under the engagement.", "Engagement", "Reference (Data Asset) (multi)", "", "DAS-000318", "SEC Regulation S-P", "", "", "Customer information shared with a service provider falls under the Regulation S-P service-provider oversight duty (17 CFR 248.30, 2024 amendments)."),
       ("Engagement Start Date", "Date the service started or is due to start.", "Engagement", "Date", "ISO 8601", "2025-04-01", "Internal", "", ""),
       ("Engagement End Date", "Date the service ended or is planned to end.", "Engagement", "Date", "ISO 8601", "", "Internal", "", ""),
       ("Engagement Status", "Lifecycle status of the engagement.", "Engagement", "Code", "Shared: Record Status", "Active", "Internal", "", "", "Shared Record Status used as the lifecycle (Proposed, Active, Inactive, Retired); exit is evidenced by Engagement End Date."),
     ]),
   ]),
   ("Supplier Category Assignment", "Dated classification of an engagement by firm procurement category and UNSPSC code.", [
     ("Supplier Category Assignment", [
       ("Categorized Engagement", "Engagement being classified.", "Category", "Reference (Supplier Engagement, 40)", "", "VENG-001877", "Internal", "", ""),
       ("Procurement Category", "Firm procurement category assigned to the engagement.", "Category", "Code", "Procurement Category", "IT Software and SaaS", "Internal", "UNSPSC", "Y"),
       ("UNSPSC Code", "UNSPSC segment and family (or deeper) code of what is bought.", "Category", "Code", "External (UNSPSC)", "43230000", "UNSPSC", "", ""),
       ("Category Effective From", "Date the assignment took effect.", "Category", "Date", "ISO 8601", "2025-04-01", "Internal", "", ""),
       ("Category Effective To", "Date the assignment ended.", "Category", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Sourcing", "VM-SRC",
  "Competitive and non-competitive sourcing events the firm issues to suppliers (RFI, Sourcing RFP, RFQ, reverse auction, single-source justification), the suppliers invited and their bids, and the award to each winning supplier. RFPs and DDQs the firm receives from clients and consultants are 03 RFP Requests (RFP-), not sourcing events.",
  [
   ("Sourcing Event", "A request the firm issues to suppliers, with its owner, timetable, estimated value and status.", [
     ("Sourcing Event", [
       ("Sourcing Event ID", "Enterprise identifier of the sourcing event.", "Sourcing Event", "Identifier", "", "SRCG-2026-0031", "Internal", "", "Y"),
       ("Sourcing Event Type", "Kind of sourcing event.", "Sourcing Event", "Code", "Sourcing Event Type", "Sourcing RFP", "Coupa", "SAP Ariba", "Y"),
       ("Sourcing Owner", "Procurement employee who runs the event.", "Sourcing Event", "Reference (Employee)", "", "EMP-20417", "Internal", "", "", EMP_PII),
       ("Originating Requisition", "Purchase requisition that triggered the event, where one did.", "Sourcing Event", "Reference (Purchase Requisition, 40)", "", "PREQ-2026-0018840", "Internal", "", ""),
       ("Event Issue Date", "Date the event was issued to suppliers.", "Sourcing Event", "Date", "ISO 8601", "2026-02-02", "Internal", "", ""),
       ("Estimated Contract Value", "Estimated total value of the contract to be awarded, used to set approval and sourcing thresholds.", "Sourcing Event", "Amount", "", "USD 2,400,000", "Internal", "", "Y"),
       ("Sourcing Event Status", "Lifecycle status of the event.", "Sourcing Event", "Code", "Sourcing Event Status", "Awarded", "Coupa", "", "Y"),
       ("Single-Source Justification", "Reason a single supplier was approached without competition, for single-source events.", "Sourcing Event", "Text", "", "Incumbent holds the only licensed interface to the TA platform", "Internal", "", ""),
     ]),
   ]),
   ("Sourcing Invitation", "Each supplier invited to an event, its bid and evaluation.", [
     ("Sourcing Invitation", [
       ("Invitation Sourcing Event", "Event the supplier was invited to.", "Invitation", "Reference (Sourcing Event, 40)", "", "SRCG-2026-0031", "Internal", "", ""),
       ("Invited Supplier", "Supplier invited to respond; a prospect is a 02 party with supplier status Prospect.", "Invitation", "Reference (Party)", "", "PTY-702114", "Internal", "", "", SUP_PII),
       ("Bid Amount", "Total price the supplier bid over the evaluation term; empty if it did not respond.", "Invitation", "Amount", "", "USD 2,150,000", "Internal", "", "Y"),
       ("Overall Evaluation Score", "Combined weighted score used to rank responses.", "Invitation", "Decimal", "", "84.7", "Internal", "", ""),
       ("Sourcing Disqualification Reason", "Why the response was excluded from evaluation; empty when it was evaluated.", "Invitation", "Code", "Sourcing Disqualification Reason", "Late Response", "Internal", "", ""),
     ]),
   ]),
   ("Sourcing Award", "The award of business to one supplier on an event; a split award has one row per awarded supplier.", [
     ("Sourcing Award", [
       ("Award Sourcing Event", "Event the award concludes.", "Award", "Reference (Sourcing Event, 40)", "", "SRCG-2026-0031", "Internal", "", ""),
       ("Awarded Supplier", "Supplier awarded business.", "Award", "Reference (Party)", "", "PTY-702114", "Internal", "", "Y", SUP_PII),
       ("Award Date", "Date the award decision was taken.", "Award", "Date", "ISO 8601", "2026-04-17", "Internal", "", ""),
       ("Awarded Value", "Value of the business awarded to the supplier over the expected contract term.", "Award", "Amount", "", "USD 2,150,000", "Internal", "", "Y"),
       ("Award Share", "Share of the event's volume or value awarded to the supplier in a split award.", "Award", "Percentage", "", "100%", "Internal", "", ""),
       ("Award Rationale", "Why the supplier was chosen.", "Award", "Text", "", "Highest weighted score; lowest five-year total cost", "Internal", "", ""),
       ("Award Approval Status", "Outcome of the award approval.", "Award", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
       ("Resulting Supplier Engagement", "Engagement created or extended by the award.", "Award", "Reference (Supplier Engagement, 40)", "", "VENG-001877", "Internal", "", ""),
       ("Resulting Contract", "39 contract signed as a result of the award.", "Award", "Reference (Contract, 39)", "", "CTRCT-0041877", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Purchasing", "VM-PUR",
  "The purchase-to-pay chain on the procurement side: requisitions, purchase orders and their lines, goods and service receipts and the match of each 19 payable invoice line to a purchase order line. The invoice, its header amounts and taxes, and the payment are mastered in 19 (CD-158).",
  [
   ("Purchase Requisition", "An internal request to buy, with its requester, cost center, amount and approval outcome.", [
     ("Purchase Requisition", [
       ("Purchase Requisition ID", "Enterprise identifier of the requisition.", "Requisition", "Identifier", "", "PREQ-2026-0018840", "Coupa", "SAP Ariba", "Y"),
       ("Requester", "Employee who raised the requisition.", "Requisition", "Reference (Employee)", "", "EMP-01877", "Internal", "", "", EMP_PII),
       ("Requisition Cost Center", "19 cost center segment value the spend will be charged to.", "Requisition", "Reference (Chart Segment Value, 19)", "", "41020", "Internal", "", ""),
       ("Requisition Amount", "Estimated amount of the request.", "Requisition", "Amount", "", "USD 480,000", "Internal", "", "Y"),
       ("Needed-By Date", "Date the goods or service are needed.", "Requisition", "Date", "ISO 8601", "2026-06-30", "Internal", "", ""),
       ("Purchase Requisition Status", "Lifecycle status of the requisition.", "Requisition", "Code", "Purchase Requisition Status", "Converted to Purchase Order", "Coupa", "", "Y"),
       ("Requisition Approval Status", "Outcome of the requisition approval chain.", "Requisition", "Code", "Shared: Approval Status", "Approved", "Internal", "", ""),
     ]),
   ]),
   ("Purchase Order", "The commitment the firm makes to a supplier: header terms, supplier, entity and governing contract.", [
     ("Purchase Order", [
       ("Purchase Order ID", "Enterprise identifier of the purchase order, built from the ERP purchase order number.", "Purchase Order", "Identifier", "", "PURCH-4500021877", "UN/CEFACT Buy-Ship-Pay", "SAP Ariba", "Y", "19 Payable Invoice 'Purchase Order Reference' (today 'PO 4500021877') re-types to Reference (Purchase Order, 40) (CD-260, proposed)."),
       ("Ordered Supplier", "Supplier the order is placed with; must equal the Engaged Supplier of the Ordered Engagement.", "Purchase Order", "Reference (Party)", "", "PTY-702114", "UN/CEFACT Buy-Ship-Pay", "", "Y", SUP_PII),
       ("Ordering Legal Entity", "Internal legal entity that places and pays for the order.", "Purchase Order", "Reference (Legal Entity)", "", "LEN-0004", "Internal", "", "Y"),
       ("Ordered Engagement", "Supplier engagement the order is placed under.", "Purchase Order", "Reference (Supplier Engagement, 40)", "", "VENG-001877", "Internal", "", ""),
       ("Governing Contract", "39 contract whose terms govern the order; empty for an order on standard terms.", "Purchase Order", "Reference (Contract, 39)", "", "CTRCT-0041877", "Internal", "", "Y"),
       ("Purchase Order Type", "Structural type of the order.", "Purchase Order", "Code", "Purchase Order Type", "Contract Release", "SAP Ariba", "Coupa", "Y"),
       ("Order Date", "Date the order was issued to the supplier.", "Purchase Order", "Date", "ISO 8601", "2026-05-04", "UN/CEFACT Buy-Ship-Pay", "", ""),
       ("Order Total Amount", "Sum of the line amounts of the order, in the order currency.", "Purchase Order", "Amount", "", "USD 480,000", "UN/CEFACT Buy-Ship-Pay", "", "Y"),
       ("Purchase Order Status", "Lifecycle status of the order.", "Purchase Order", "Code", "Purchase Order Status", "Partially Received", "SAP Ariba", "", "Y"),
     ]),
   ]),
   ("Purchase Order Line", "Each line of a purchase order: what is ordered, at what price, for which period and charged where.", [
     ("Purchase Order Line", [
       ("Line Purchase Order", "Order the line belongs to.", "PO Line", "Reference (Purchase Order, 40)", "", "PURCH-4500021877", "UN/CEFACT Buy-Ship-Pay", "", "Y"),
       ("PO Line Number", "Sequence number of the line on the order.", "PO Line", "Integer", "", "10", "UN/CEFACT Buy-Ship-Pay", "", ""),
       ("Line Item Description", "Item or service ordered on the line.", "PO Line", "Text", "", "Data warehouse compute credits, 12 months", "UN/CEFACT Buy-Ship-Pay", "", ""),
       ("Line Receipt Basis", "Whether the line is received by quantity, by accepted service amount, by milestone or by approved time sheet.", "PO Line", "Code", "Receipt Type", "Amount-Based Service Acceptance", "SAP Ariba", "", ""),
       ("Ordered Quantity", "Quantity ordered, for quantity-based lines.", "PO Line", "Decimal", "", "1", "UN/CEFACT Buy-Ship-Pay", "", ""),
       ("Unit Price", "Agreed price per unit.", "PO Line", "Amount", "", "USD 480,000", "UN/CEFACT Buy-Ship-Pay", "", ""),
       ("Line Amount", "Ordered amount of the line before indirect tax.", "PO Line", "Amount", "", "USD 480,000", "UN/CEFACT Buy-Ship-Pay", "", "Y"),
       ("Line GL Account", "19 GL account the line will be charged to.", "PO Line", "Reference (GL Account, 19)", "", "GLA-GRPCOA-640200", "Internal", "", ""),
       ("Line Cost Center", "19 cost center segment value the line will be charged to.", "PO Line", "Reference (Chart Segment Value, 19)", "", "41020", "Internal", "", ""),
       ("Service Period Start", "First day of the service period for service lines.", "PO Line", "Date", "ISO 8601", "2026-05-01", "Internal", "", ""),
       ("Service Period End", "Last day of the service period for service lines.", "PO Line", "Date", "ISO 8601", "2027-04-30", "Internal", "", ""),
       ("Source Requisition", "Requisition the line was created from.", "PO Line", "Reference (Purchase Requisition, 40)", "", "PREQ-2026-0018840", "Internal", "", ""),
       ("Contingent Workers", "Workers supplied under a contingent labor or statement-of-work line; each worker's engagement detail stays in 20 Contingent Worker Detail.", "PO Line", "Reference (Employee) (multi)", "", "EMP-61022; EMP-61023", "Internal", "", "", "PII (the individual workers)."),
     ]),
   ]),
   ("Goods and Service Receipt", "Confirmation that goods were received or a service accepted against an order line.", [
     ("Goods and Service Receipt", [
       ("Receipt Purchase Order", "Order the receipt is posted against.", "Receipt", "Reference (Purchase Order, 40)", "", "PURCH-4500021877", "UN/CEFACT Buy-Ship-Pay", "", ""),
       ("Receipt PO Line Number", "Order line the receipt is posted against.", "Receipt", "Integer", "", "10", "UN/CEFACT Buy-Ship-Pay", "", ""),
       ("Receipt Sequence", "Sequence number of the receipt on the line.", "Receipt", "Integer", "", "3", "Internal", "", ""),
       ("Receipt Date", "Date the goods were received or the service accepted.", "Receipt", "Date", "ISO 8601", "2026-07-31", "UN/CEFACT Buy-Ship-Pay", "", "Y"),
       ("Received Quantity", "Quantity received, for quantity-based lines; negative on a return.", "Receipt", "Decimal", "", "1", "UN/CEFACT Buy-Ship-Pay", "", "Y"),
       ("Accepted Service Amount", "Amount of service accepted, for amount-based and milestone lines; negative on a reversal.", "Receipt", "Amount", "", "USD 40,000", "SAP Ariba", "", "Y"),
       ("Receiver", "Employee who confirmed the receipt or acceptance.", "Receipt", "Reference (Employee)", "", "EMP-01877", "Internal", "", "", EMP_PII),
     ]),
   ]),
   ("Invoice Match Result", "The match of a 19 payable invoice line to a purchase order line (and receipts), with the quantities, amounts and prices the match applied and its outcome.", [
     ("Invoice Match Result", [
       ("Matched Payable Invoice", "19 payable invoice whose line is matched.", "Invoice Match", "Reference (Payable Invoice, 19)", "", "APV-2026-0018833", "Internal", "", "Y"),
       ("Matched Invoice Line Number", "Line number of the 19 payable invoice line matched.", "Invoice Match", "Integer", "", "1", "OECD SAF-T", "", "", "Derived copy (19) of Payable Invoice Line.Invoice Line Number."),
       ("Matched Purchase Order", "Order the invoice line is matched to.", "Invoice Match", "Reference (Purchase Order, 40)", "", "PURCH-4500021877", "Internal", "", "Y"),
       ("Matched PO Line Number", "Order line the invoice line is matched to.", "Invoice Match", "Integer", "", "10", "Internal", "", ""),
       ("Match Type", "Documents compared in the match.", "Invoice Match", "Code", "Match Type", "Three-Way", "SAP Ariba", "Coupa", ""),
       ("Matched Quantity", "Invoiced quantity accepted against the order line (and its receipts) by this match.", "Invoice Match", "Decimal", "", "1", "SAP Ariba", "", "Y"),
       ("Matched Amount", "Invoice line amount accepted against the order line by this match, in the order currency.", "Invoice Match", "Amount", "", "USD 40,000", "SAP Ariba", "", "Y"),
       ("Unit Price Used", "Invoiced unit price the match compared with the order unit price.", "Invoice Match", "Amount", "", "USD 41,250", "SAP Ariba", "", "", "Mastered here as the price the match applied; becomes a Derived copy (19) once 19 Payable Invoice Line gains Invoiced Unit Price (proposed)."),
       ("Quantity Variance", "Invoiced quantity minus the quantity available to match (received less previously matched for three-way; ordered less previously matched for two-way).", "Invoice Match", "Decimal", "", "0", "Internal", "", "Y"),
       ("Price Variance Amount", "Unit Price Used minus the order unit price, times the matched quantity.", "Invoice Match", "Amount", "", "USD 1,250", "Internal", "", "Y"),
       ("Tolerance Applied", "Price tolerance allowed before the line is held.", "Invoice Match", "Percentage", "", "2%", "Internal", "", ""),
       ("Invoice Match Status", "Outcome of the match.", "Invoice Match", "Code", "Invoice Match Status", "Held", "Coupa", "", "Y"),
       ("Match Hold Reason", "Why a held line was not released for payment.", "Invoice Match", "Code", "Match Hold Reason", "Price Over Tolerance", "Coupa", "", ""),
       ("Match Timestamp", "Date and time the match was last run; re-runs replace the result, and hold history stays in the procurement suite's audit log.", "Invoice Match", "Timestamp", "ISO 8601", "2026-08-04T09:12:00Z", "Internal", "", ""),
       ("Invoice Status at Match", "Status of the 19 payable invoice when the match was run, shown for the match work queue.", "Invoice Match", "Code", "Shared: Payable Invoice Status", "Under Review", "Internal", "", "", "Derived copy (19) of Payable Invoice.Payable Invoice Status; never set here."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Supplier Contracts", "VM-CON",
  "The procurement terms of supplier contracts and their contracted service levels. Each supplier contract is a 39 Contract (CTRCT-); 39 masters its dates, parties, governing law and clauses, and the profile here holds none of them (CD-257).",
  [
   ("Supplier Contract Profile", "Commercial terms of a supplier contract as procurement manages them. Row rule: a profile exists only on 39 contracts that are untyped or typed as 'Supplier Contract Profile (40)' in 39 Typed Contract Link; data licenses keep their commercial terms in 14 Data License Agreement and leases in 44 Lease.", [
     ("Supplier Contract Profile", [
       ("Profiled Contract", "39 contract the profile is typed on.", "Contract Profile", "Reference (Contract, 39)", "", "CTRCT-0041877", "Internal", "", "Y"),
       ("Contracted Engagements", "Supplier engagements the contract governs (a framework contract may cover several).", "Contract Profile", "Reference (Supplier Engagement, 40) (multi)", "", "VENG-001877", "Internal", "", ""),
       ("Total Contract Value", "Expected total value of the contract over its committed term.", "Contract Profile", "Amount", "", "USD 2,150,000", "Internal", "", "Y"),
       ("Contract Pricing Model", "How the price is determined.", "Contract Profile", "Code", "Contract Pricing Model", "Consumption-Based", "Internal", "", ""),
       ("Contract Payment Terms", "Payment terms agreed in the contract.", "Contract Profile", "Code", "Payment Terms", "Net 45", "Internal", "", ""),
       ("Exit Assistance Period", "Number of months of termination and transition assistance the supplier is contractually bound to give; empty where none is agreed.", "Contract Profile", "Integer", "Months", "12", "US Interagency TPRM Guidance", "FINRA Regulatory Notice 21-29", ""),
       ("Contract Status", "Status of the 39 contract, shown for procurement work queues.", "Contract Profile", "Code", "Shared: Agreement Status", "Active", "Internal", "", "", "Derived copy (39) of Contract.Contract Status; never set here."),
     ]),
   ]),
   ("Contracted Service Level", "Service levels agreed in supplier contracts that no specialization measures. Row rule: rows exist only where 13 Service Level Definition, 14 Vendor Data SLA, 05 Service Level Agreement or 44 Facility Work Order service levels do not already measure the service.", [
     ("Contracted Service Level", [
       ("Service Level Contract", "39 contract that sets the service level.", "Service Level", "Reference (Contract, 39)", "", "CTRCT-0041877", "Internal", "", "Y"),
       ("Service Level Metric Name", "Name of the metric measured.", "Service Level", "Text", "", "Platform availability", "Internal", "", ""),
       ("Service Level Target", "Value the supplier must meet.", "Service Level", "Decimal", "", "99.9", "Internal", "", ""),
       ("Service Level Unit", "Unit of the target.", "Service Level", "Code", "Shared: SLA Unit", "Percent", "Internal", "", ""),
       ("Service Credit Rate", "Credit due as a share of the monthly charge when the target is missed.", "Service Level", "Percentage", "", "5%", "Internal", "", ""),
       ("Service Level Effective From", "Date the service level took effect.", "Service Level", "Date", "ISO 8601", "2026-05-01", "Internal", "", ""),
       ("Service Level Effective To", "Date the service level ended or was replaced.", "Service Level", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Supplier Performance & Spend", "VM-PRF",
  "How suppliers perform and what the firm spends with them: periodic performance reviews of engagements, measured results against contracted service levels and spend summaries by supplier, buying entity and fiscal period. Row rule: each engagement is performance-reviewed in exactly one domain by engagement type: 14 Vendor Performance Review for data-vendor engagements, 13 oversight reviews for servicing provider engagements, 28 Custodian Service Reviews for custody engagements, and 40 Supplier Performance Review for every other engagement.",
  [
   ("Supplier Performance Review", "Periodic scorecard review of an engagement not reviewed in 14, 13 or 28.", [
     ("Supplier Performance Review", [
       ("Reviewed Engagement", "Engagement reviewed.", "Performance Review", "Reference (Supplier Engagement, 40)", "", "VENG-001877", "Internal", "", ""),
       ("Review Period End", "Last day of the period reviewed.", "Performance Review", "Date", "ISO 8601", "2026-06-30", "Internal", "", ""),
       ("Scored Dimensions", "Scorecard dimensions assessed in the review.", "Performance Review", "Code (multi)", "Performance Dimension", "Service Delivery; Quality; Commercial; Relationship", "ISO 20400", "", ""),
       ("Overall Performance Score", "Weighted scorecard score.", "Performance Review", "Decimal", "", "3.8", "Internal", "", ""),
       ("Overall Performance Rating", "Overall rating the review gives the supplier.", "Performance Review", "Code", "Supplier Performance Rating", "Meets Expectations", "Internal", "", "Y"),
     ]),
   ]),
   ("Service Level Measurement Result", "Measured result of a contracted service level for one period.", [
     ("Service Level Measurement Result", [
       ("Measured Contract", "39 contract whose contracted service level was measured.", "Service Level Result", "Reference (Contract, 39)", "", "CTRCT-0041877", "Internal", "", ""),
       ("Measured Metric Name", "Contracted service level metric measured.", "Service Level Result", "Text", "", "Platform availability", "Internal", "", ""),
       ("Measured Service Level Effective From", "Effective From of the contracted service level row measured, so a change of target is unambiguous.", "Service Level Result", "Date", "ISO 8601", "2026-05-01", "Internal", "", ""),
       ("Measurement Period End", "Last day of the period measured.", "Service Level Result", "Date", "ISO 8601", "2026-08-31", "Internal", "", ""),
       ("Actual Value", "Measured result for the period.", "Service Level Result", "Decimal", "", "99.72", "Internal", "", "Y"),
       ("Service Level Met Indicator", "Whether the target was met.", "Service Level Result", "Boolean", "", "N", "Internal", "", "Y"),
       ("Service Credit Due Amount", "Credit the supplier owes for the miss.", "Service Level Result", "Amount", "", "USD 2,000", "Internal", "", ""),
     ]),
   ]),
   ("Supplier Spend Summary", "Committed, received, invoiced and paid spend by supplier, buying entity and fiscal period, in the group reporting currency.", [
     ("Supplier Spend Summary", [
       ("Spend Supplier", "Supplier the spend is with.", "Spend Summary", "Reference (Party)", "", "PTY-702114", "Internal", "", "Y", SUP_PII),
       ("Spend Legal Entity", "Internal legal entity that bought.", "Spend Summary", "Reference (Legal Entity)", "", "LEN-0004", "Internal", "", ""),
       ("Spend Fiscal Period", "09 fiscal period summarized.", "Spend Summary", "Reference (Fiscal Period, 09)", "", "FY2026-P09", "Internal", "", ""),
       ("Committed Amount", "Amount of purchase order lines issued in the period (by Order Date), in the group reporting currency.", "Spend Summary", "Amount", "", "USD 480,000", "Internal", "", "Y"),
       ("Received Amount", "Amount received or accepted against purchase orders in the period (by Receipt Date), in the group reporting currency.", "Spend Summary", "Amount", "", "USD 120,000", "Internal", "", ""),
       ("Invoiced Amount", "Net amount of supplier invoices and credit notes recorded in the period, in the group reporting currency.", "Spend Summary", "Amount", "", "USD 118,750", "Internal", "", "", "Derived copy (19): sum of Payable Invoice Line.Line Net Amount for the supplier and entity, signed by Payable Invoice.Payable Document Type (credit notes negative), assigned to the period by Invoice Date and translated at the 22 FX rate of that date (row rule: all invoices, with or without a purchase order)."),
       ("Paid Amount", "Amount paid to the supplier in the period, in the group reporting currency.", "Spend Summary", "Amount", "", "USD 97,500", "Internal", "", "", "Derived copy (19): sum of Supplier Payment.Payment Amount by Payment Value Date, translated at the 22 FX rate of that date."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Criticality & Outsourcing", "VM-OUT",
  "How critical each engagement is and the register of outsourced functions: the inherent criticality tier that sets due-diligence depth (residual risk is 37's) and outsourcing arrangements with exit plans, kept to evidence the supervision of outsourced broker-dealer functions (FINRA Rule 3110, Regulatory Notice 21-29), fund service provider oversight (SEC Rule 38a-1), service-provider oversight for customer information (Regulation S-P) and the trust company's third-party risk management (CD-249, CD-261).",
  [
   ("Supplier Risk Tiering", "Dated inherent criticality classification of an engagement.", [
     ("Supplier Risk Tiering", [
       ("Tiered Engagement", "Engagement classified.", "Risk Tiering", "Reference (Supplier Engagement, 40)", "", "VENG-001877", "US Interagency TPRM Guidance", "", ""),
       ("Third-Party Criticality Tier", "Inherent criticality of the engagement before controls.", "Risk Tiering", "Code", "Third-Party Criticality Tier", "Tier 1 - Critical", "US Interagency TPRM Guidance", "FINRA Regulatory Notice 21-29", "Y", "Not the residual rating (37 Third-Party Risk Assessment); neither copies the other (CD-248)."),
       ("Criticality Drivers", "Factors that put the engagement in its tier.", "Risk Tiering", "Code (multi)", "Criticality Driver", "ICT Service; Personal Data Access; Supports Critical or Important Function", "US Interagency TPRM Guidance", "FINRA Regulatory Notice 21-29", "Y", "Row rule: 'Supports Critical or Important Function' is set from the 37 references on the engagement's Outsourcing Arrangements, never chosen by hand."),
       ("Due-Diligence Depth", "Depth of due diligence and monitoring the tier requires.", "Risk Tiering", "Code", "Due Diligence Depth", "Enhanced", "US Interagency TPRM Guidance", "", ""),
       ("Tier Effective From", "Date the tier took effect.", "Risk Tiering", "Date", "ISO 8601", "2026-03-20", "Internal", "", ""),
       ("Tier Effective To", "Date the tier was superseded.", "Risk Tiering", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Outsourcing Arrangement", "Each outsourcing of a function by an internal entity, as kept in the outsourcing register.", [
     ("Outsourcing Arrangement", [
       ("Outsourcing Arrangement ID", "Enterprise identifier of the outsourcing arrangement.", "Outsourcing", "Identifier", "", "OUTS-0042", "FINRA Regulatory Notice 21-29", "", "Y"),
       ("Outsourcing Engagement", "Supplier engagement under which the function is outsourced.", "Outsourcing", "Reference (Supplier Engagement, 40)", "", "VENG-001877", "Internal", "", ""),
       ("Outsourcing Entity", "Internal legal entity that outsources the function and keeps the register entry.", "Outsourcing", "Reference (Legal Entity)", "", "LEN-0012", "FINRA Regulatory Notice 21-29", "US Interagency TPRM Guidance", "Y"),
       ("Outsourced Function Description", "Function or activity outsourced.", "Outsourcing", "Text", "", "Print and mail of client statements and trade confirmations for the broker-dealer", "FINRA Regulatory Notice 21-29", "", ""),
       ("Outsourcing Regimes", "Regulatory regimes under which the arrangement is registered or overseen.", "Outsourcing", "Code (multi)", "Outsourcing Regime", "FINRA Rule 3110 Supervision of Outsourced Functions; Reg S-P Service Provider Oversight", "FINRA Rule 3110", "SEC Regulation S-P", ""),
       ("Supported Critical or Important Functions", "37 critical or important functions (critical activities in the 2023 interagency guidance) the arrangement supports.", "Outsourcing", "Reference (Critical or Important Function, 37) (multi)", "", "CIF 03", "US Interagency TPRM Guidance", "FINRA Regulatory Notice 21-29", "Y"),
       ("Critical or Important Outsourcing Indicator", "Whether the arrangement supports at least one function 37 designates critical or important.", "Outsourcing", "Boolean", "", "Y", "US Interagency TPRM Guidance", "FINRA Regulatory Notice 21-29", "Y", "Derived copy (37): Y when any Supported Critical or Important Function is designated in 37; the designation is never made here."),
       ("Outsourcing Contract", "39 contract that governs the arrangement.", "Outsourcing", "Reference (Contract, 39)", "", "CTRCT-0041877", "US Interagency TPRM Guidance", "SEC Regulation S-P", "Y"),
       ("Related Plan Service Arrangement", "16 recordkeeping service arrangement the outsourcing relates to, where a CIT or plan recordkeeping function is outsourced.", "Outsourcing", "Reference (Service Arrangement, 16)", "", "PSVA-00921", "Internal", "", "", "Plan service terms stay in 16 (brief §3)."),
       ("Intragroup Outsourcing Indicator", "Whether the provider is a member of the firm's group (an affiliate).", "Outsourcing", "Boolean", "", "N", "FINRA Regulatory Notice 21-29", "", ""),
       ("Service Commencement Date", "Date the outsourced service went live (may differ from 39 Contract Effective Date).", "Outsourcing", "Date", "ISO 8601", "2025-07-01", "Internal", "", ""),
       ("Outsourcing Arrangement Status", "Lifecycle status of the arrangement in the register.", "Outsourcing", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
     ]),
   ]),
   ("Exit Plan", "The planned way out of an outsourcing arrangement and when it was last tested.", [
     ("Exit Plan", [
       ("Exit Strategy Type", "Planned way out of the arrangement.", "Exit Plan", "Code", "Exit Strategy Type", "Transfer to Alternative Provider", "US Interagency TPRM Guidance", "FINRA Regulatory Notice 21-29", ""),
       ("Alternative Providers", "Parties identified as alternative providers for the outsourced function.", "Exit Plan", "Reference (Party) (multi)", "", "PTY-100455", "US Interagency TPRM Guidance", "", "", SUP_PII),
       ("Planned Transition Period", "Number of months the plan allows for transition; compare with the contracted Exit Assistance Period on the Supplier Contract Profile.", "Exit Plan", "Integer", "Months", "18", "US Interagency TPRM Guidance", "", ""),
       ("Exit Plan Last Tested Date", "Date the plan was last tested or walked through.", "Exit Plan", "Date", "ISO 8601", "2026-05-14", "US Interagency TPRM Guidance", "FINRA Regulatory Notice 21-29", "Y"),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# Enterprise shared lists are cited directly ('Shared: <name>'); 40 is a registered direct user (CD-283).
# ---------------------------------------------------------------------------
CL = {
 # Enterprise shared lists are cited directly as 'Shared: <name>'; the local copies were removed at the Stage 4 consolidation (CD-283).
 # Local list aligned to the IRS forms of 15 Tax Form Type (the wealth 02 holds no form list; CW-940)
 "Tax Form Type": ("IRS (values as 15 Tax Form Type)", [("W-9",""),("Substitute Form W-9","Supplier's own form with the Form W-9 certification"),("W-8BEN",""),("W-8BEN-E",""),("W-8IMY",""),("W-8EXP",""),("W-8ECI","")]),
 # Local lists
 "Supplier Status": ("Internal", [("Prospect","Invited or under evaluation; no purchase order may be issued"),("Approved","Onboarded; may be ordered from"),("Restricted","May be ordered from only with procurement approval, e.g. pending a lapsed certificate"),("Blocked","No new orders or payments; e.g. sanctions hit or fraud concern"),("Inactive","No activity; retained for history")]),
 "Procurement Category": ("Internal (mapped to UNSPSC segments)", [("IT Software and SaaS","Licensed software and software as a service"),("IT Hardware and Infrastructure",""),("Cloud Infrastructure and Hosting Services","IaaS, PaaS and hosting; SaaS is IT Software and SaaS"),("IT Professional Services",""),("Market and Reference Data","Specialized in 14"),("Investment Research","Specialized in 23 / 25"),("Fund and Investor Services","Administration, transfer agency, fund custody oversight (28)"),("Professional Services - Legal","Outside counsel; see 39"),("Professional Services - Audit and Tax",""),("Consulting",""),("Contingent Labor","Workers detailed in 20"),("Marketing and Printing",""),("Facilities and Real Estate Services","See 44"),("Travel and Events","See 44"),("Insurance and Brokerage","See 43"),("Telecommunications",""),("Other","")]),
 "Diversity Certification Type": ("US SBA / Internal", [("Small Business","US SBA size standards"),("Minority-Owned Business Enterprise",""),("Women-Owned Business Enterprise",""),("Veteran-Owned Small Business",""),("Service-Disabled Veteran-Owned Small Business","Reveals health data for an individual"),("HUBZone Business","US SBA program"),("LGBTQ+-Owned Business Enterprise","Sensitive personal information under state privacy laws for an individual; restricted"),("Disability-Owned Business Enterprise","Sensitive personal information under state privacy laws for an individual; restricted")]),
 "Onboarding Step": ("Internal / US Interagency TPRM Guidance", [("Sanctions Screening",""),("Adverse Media Check",""),("Tax Form Collection",""),("Bank Detail Verification","Call-back control"),("Insurance Certificate",""),("Information Security Questionnaire",""),("Data Protection Assessment","Regulation S-P service-provider oversight (17 CFR 248.30) and state privacy law service-provider terms"),("Business Continuity Review",""),("Conflicts Check","A conflict found is raised in 38"),("Criticality Tiering",""),("Financial Viability Review","")]),
 "Sourcing Event Type": ("Internal (Coupa / SAP Ariba event types)", [("RFI","Request for information"),("Sourcing RFP","Request for proposal the firm issues; not a 03 Client RFP"),("RFQ","Request for quotation"),("Reverse Auction",""),("Single-Source Justification","Non-competitive award with documented rationale"),("Renewal Negotiation","")]),
 "Sourcing Event Status": ("Internal", [("Draft",""),("Issued",""),("Responses Under Evaluation",""),("Awarded",""),("Canceled",""),("No Award","")]),
 "Sourcing Disqualification Reason": ("Internal", [("Late Response",""),("Incomplete Response",""),("Failed Mandatory Requirement",""),("Failed Due Diligence",""),("Conflict of Interest",""),("Sanctions or Screening Concern",""),("Withdrew","")]),
 "Purchase Requisition Status": ("Internal", [("Draft",""),("Submitted",""),("Pending Approval",""),("Approved",""),("Rejected",""),("In Sourcing","A sourcing event is running"),("Converted to Purchase Order",""),("Canceled","")]),
 "Purchase Order Type": ("Internal (SAP Ariba / Coupa order types)", [("Standard","One-off order for defined goods or services"),("Blanket","Spend limit for a period, called off by invoices or releases"),("Contract Release","Order against a 39 contract"),("Statement of Work","Services ordered under a statement of work, including contingent labor"),("Subscription","Recurring license or SaaS subscription")]),
 "Purchase Order Status": ("Internal", [("Draft",""),("Pending Approval",""),("Issued",""),("Acknowledged","Supplier confirmed"),("Partially Received",""),("Fully Received",""),("Closed",""),("Canceled","")]),
 "Receipt Type": ("Internal", [("Quantity-Based Goods Receipt",""),("Amount-Based Service Acceptance",""),("Milestone Acceptance",""),("Time Sheet Approval","Contingent labor")]),
 "Match Type": ("Accounts payable practice", [("Two-Way","Invoice to purchase order"),("Three-Way","Invoice to purchase order and receipt"),("Four-Way","Invoice to purchase order, receipt and inspection or acceptance")]),
 "Invoice Match Status": ("Internal", [("Matched",""),("Matched Within Tolerance",""),("Held",""),("Released","Hold released by an approver"),("Rejected","Invoice line returned to the supplier")]),
 "Match Hold Reason": ("Internal", [("Price Over Tolerance",""),("Quantity Over Received",""),("No Receipt",""),("Purchase Order Closed",""),("Supplier Mismatch",""),("Currency Mismatch",""),("Duplicate Suspected","")]),
 "Payment Terms": ("Internal (UN/CEFACT payment terms concepts)", [("Due on Receipt",""),("Net 15",""),("Net 30",""),("Net 45",""),("Net 60",""),("Net 90",""),("2/10 Net 30","2% discount if paid in 10 days"),("Advance Payment","")]),
 "Contract Pricing Model": ("Internal", [("Fixed Fee",""),("Time and Materials",""),("Unit Rate",""),("Subscription",""),("Consumption-Based",""),("Tiered by AUM or Volume",""),("Outcome-Based","")]),
 "Performance Dimension": ("Internal / ISO 20400", [("Service Delivery",""),("Quality",""),("Commercial",""),("Relationship",""),("Innovation",""),("Risk and Compliance",""),("Sustainability","")]),
 "Supplier Performance Rating": ("Internal (labels as 14 Performance Rating)", [("Exceeds Expectations",""),("Meets Expectations",""),("Partially Meets",""),("Does Not Meet","")]),
 "Third-Party Criticality Tier": ("Internal / US Interagency TPRM Guidance", [("Tier 1 - Critical","Full due diligence, annual reassessment, exit plan and board-level reporting"),("Tier 2 - High","Enhanced due diligence and annual reassessment"),("Tier 3 - Moderate","Standard due diligence; reassessment every two years"),("Tier 4 - Low","Onboarding checks only")]),
 "Criticality Driver": ("Internal / US Interagency TPRM Guidance / FINRA Regulatory Notice 21-29", [("ICT Service",""),("Outsourcing",""),("Supports Critical or Important Function","Set from 37 references, not chosen by hand"),("Personal Data Access",""),("Confidential Data Access",""),("Client-Facing Service",""),("Low Substitutability",""),("High Spend",""),("Regulatory Requirement","")]),
 "Due Diligence Depth": ("Internal", [("Standard",""),("Enhanced",""),("Full Critical","On-site or virtual review, financial viability, exit plan")]),
 "Outsourcing Regime": ("FINRA / SEC / US banking agencies", [("FINRA Rule 3110 Supervision of Outsourced Functions","Broker-dealer functions outsourced to a third party; FINRA Regulatory Notice 21-29"),("SEC Rule 38a-1 Service Provider Oversight","Fund service providers overseen by the fund CCO"),("Reg S-P Service Provider Oversight","Service provider with access to customer information (17 CFR 248.30, 2024 amendments)"),("Interagency Third-Party Guidance (Trust Company)","Third parties of the optional trust company and the CIT trustee (2023 interagency guidance)"),("Advisers Act Rule 206(4)-7 Service Provider Oversight","Adviser compliance program oversight of service providers"),("Other","")]),
 "Exit Strategy Type": ("Internal / US Interagency TPRM Guidance", [("Transfer to Alternative Provider",""),("Reintegration In House",""),("Orderly Wind-Down of Service",""),("Multi-Provider Failover","")]),
}

# ---------------------------------------------------------------------------
REL = [
 ("Supplier Profile","describes","Party [02]","1 : 1","Supplier identity, LEI, addresses, contacts, tax status and TINs stay in 02 (CD-143, CD-260); the tax form on file is mastered here (CW-940)."),
 ("Supplier Profile","has","Supplier Remittance Detail","1 : 0..n","Effective-dated; 19 Supplier Payment to reference the verified account (proposed)."),
 ("Supplier Profile","is onboarded through","Supplier Onboarding Case","1 : 1..n","Screening hits escalate to 38; 38 AML Case holds the only link back (SAR confidentiality)."),
 ("Supplier Profile","has","Supplier Engagement","1 : 0..n","What is bought from the supplier."),
 ("Supplier Engagement","is specialized by","Data Vendor [14]","n : 0..1","Same party (CD-260); 14 Procurement Supplier ID becomes a Derived copy (40)."),
 ("Supplier Engagement","is specialized by","Servicing Provider Engagement [29]","n : 0..1","Oversight reviews in 29; provider SLAs in 13 (CW-088)."),
 ("Supplier Engagement","is specialized by","Custody Provider Profile [28]","n : 0..1","Custody reviews stay in 28."),
 ("Supplier Engagement","oversees","Product Party Role [01]","n : 0..1","Fund-appointed providers (Fund-Paid Indicator); fund expenses are 27, not purchase orders."),
 ("Supplier Engagement","is bought for","Internal Legal Entity / Org Unit [09]","n : 1",""),
 ("Supplier Engagement","is classified by","Supplier Category Assignment","1 : 1..n","Effective-dated."),
 ("Sourcing Event","invites","Sourcing Invitation","1 : 1..n","Each invited supplier is a 02 party."),
 ("Sourcing Event","results in","Sourcing Award","1 : 0..n","One row per awarded supplier (split awards)."),
 ("Sourcing Award","results in","Contract [39]","1 : 0..1",""),
 ("Purchase Requisition","is fulfilled by","Purchase Order Line","1 : 0..n",""),
 ("Purchase Order","has","Purchase Order Line","1 : 1..n",""),
 ("Purchase Order","is governed by","Contract [39]","n : 0..1","Supplier Contract Profile holds the procurement terms."),
 ("Purchase Order Line","is charged to","GL Account / Chart Segment Value [19]","n : 1","Cost center and expense account."),
 ("Purchase Order Line","supplies","Employee (Contingent Worker Detail) [20]","1 : 0..n","Contingent labor and statement-of-work lines."),
 ("Purchase Order Line","is received by","Goods and Service Receipt","1 : 0..n",""),
 ("Invoice Match Result","matches","Payable Invoice line [19]","n : 1","The invoice and payment are 19's (CD-158); 19 Purchase Order Reference re-types to PURCH- (proposed)."),
 ("Invoice Match Result","matches","Purchase Order Line","n : 1",""),
 ("Supplier Contract Profile","is typed on","Contract [39]","1 : 1","Untyped contracts or those typed 'Supplier Contract Profile (40)' only; dates, parties and clauses are 39's (CD-257)."),
 ("Supplier Contract Profile","sets","Contracted Service Level","1 : 0..n","Only where 13, 14, 05 and 44 do not measure the service."),
 ("Contracted Service Level","is measured by","Service Level Measurement Result","1 : 0..n","One per period."),
 ("Supplier Engagement","is reviewed in","Supplier Performance Review","1 : 0..n","Only engagements not reviewed in 14, 13 or 28."),
 ("Supplier Spend Summary","copies invoiced and paid amounts from","Payable Invoice / Supplier Payment [19]","n : n","Derived copies (19), credit notes signed negative."),
 ("Supplier Engagement","is tiered by","Supplier Risk Tiering","1 : 1..n","Effective-dated inherent tier."),
 ("Supplier Engagement","is assessed by","Third-Party Risk Assessment [37]","1 : 0..n","Residual risk; 37 holds the reference; neither copies the other's rating (CD-248)."),
 ("Supplier Engagement","is mapped as a resource in","Resilience Resource Mapping [37]","1 : 0..n","37 holds the reference."),
 ("Outsourcing Arrangement","is under","Supplier Engagement","n : 1",""),
 ("Outsourcing Arrangement","supports","Critical or Important Function [37]","n : n","Designation is 37's (CD-249)."),
 ("Outsourcing Arrangement","may relate to","Service Arrangement [16]","n : 0..1","CIT and plan recordkeeping outsourcings."),
 ("Outsourcing Arrangement","has","Exit Plan","1 : 0..1",""),
 ("Supplier Profile","is paid by","Supplier Payment [19]","1 : 0..n","Paid through 19 from 43 corporate bank accounts."),
 ("Purchase Order","is referenced by","Facility Work Order [44]","1 : 0..n","44 Work Order Purchase Order; expense reports are paid outside purchase orders."),
]

# ---------------------------------------------------------------------------
SRC = [
 ("SEC Rule 38a-1 (compliance programs of investment companies) and Advisers Act Rule 206(4)-7","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-270/section-270.38a-1","Regulation","Oversight of fund and adviser service providers","Supplier Engagement (Fund Service Provider Role, Fund-Paid Indicator), Outsourcing Regime",["SEC Rule 38a-1"]),
 ("Interagency Guidance on Third-Party Relationships: Risk Management (Federal Reserve, FDIC, OCC, June 2023; SR 23-4)","US banking agencies","https://www.federalreserve.gov/supervisionreg/srletters/SR2304.htm","Guidance","Third-party lifecycle, criticality-based due diligence, onboarding, monitoring, contingency and termination planning (applied to the optional trust company and the CIT trustee, and adopted as the firm-wide lifecycle)","Supplier Risk Tiering, Onboarding Step, Third-Party Criticality Tier, Outsourcing Arrangement, Exit Plan",["US Interagency TPRM Guidance"]),
 ("ISO 20400:2017 Sustainable procurement - Guidance","ISO","https://www.iso.org/standard/63026.html","Standard (licensed)","Procurement process stages, supplier engagement and performance management (structure only)","Supplier Engagement, Supplier Performance Review",["ISO 20400"]),
 ("UN/CEFACT Buy-Ship-Pay Reference Data Model and Cross-Industry Order","UNECE","https://unece.org/trade/uncefact","Open standard","Purchase order, line, receipt and payment terms concepts","Purchase Order, Purchase Order Line, Goods and Service Receipt",["UN/CEFACT Buy-Ship-Pay"]),
 ("UNSPSC (United Nations Standard Products and Services Code)","GS1 US (code manager)","https://www.unspsc.org","Classification (free to use)","Segment, family, class and commodity codes for procurement categories","Supplier Category Assignment",["UNSPSC"]),
 ("Coupa public product documentation (supplier management, sourcing, procure-to-pay, invoice matching)","Coupa Software","https://www.coupa.com","Vendor documentation","Sourcing events, requisitions, purchase orders, receipts and match tolerances (structure only)","Purchasing family, Sourcing family",["Coupa"]),
 ("SAP Ariba public product documentation (sourcing, procurement, invoice management)","SAP","https://www.sap.com/products/spend-management.html","Vendor documentation","Purchase order types, service entry and two-, three- and four-way match (structure only)","Purchasing family, Sourcing family",["SAP Ariba"]),
 ("IRS Forms W-9 and W-8BEN-E","US IRS","https://www.irs.gov/forms-pubs/about-form-w-9","Regulation / forms","Supplier tax documentation","Supplier Profile (Tax Form on File)",["IRS Form W-9", "IRS Form W-8BEN-E"]),
 ("OFAC sanctions programs and the Specially Designated Nationals (SDN) List","US Treasury","https://ofac.treasury.gov","Regulation","Supplier sanctions screening","Supplier Onboarding Case",["OFAC"]),
 ("US SBA size standards and small business certification programs","US SBA","https://www.sba.gov/federal-contracting/contracting-guide/size-standards","Regulation / program","Small and diverse business certification types","Diversity Certification Type",["US SBA"]),
 ("SEC Regulation S-P (17 CFR Part 248, Subpart A), as amended May 2024 (service provider oversight, 17 CFR 248.30); ISO/IEC 27001 Annex A","US SEC; ISO","https://www.ecfr.gov/current/title-17/chapter-II/part-248/subpart-A","Regulation / standard","Oversight of service providers with access to customer information, including breach notification to the firm within 72 hours; classification of remittance data","Supplier Engagement (Shared Data Assets), Outsourcing Arrangement, Onboarding Step, Supplier Remittance Detail",["SEC Regulation S-P"]),
 ("California Consumer Privacy Act as amended by the California Privacy Rights Act (Cal. Civ. Code 1798.100 et seq.) and other state privacy laws","State of California (CPPA, Attorney General)","https://oag.ca.gov/privacy/ccpa","Regulation","Personal data of individual suppliers and sensitive personal information revealed by diversity certifications","Supplier Profile, Diversity Certification Type",["CCPA / CPRA"]),
 ("FINRA Rule 3110 (Supervision) and Regulatory Notice 21-29 (supervisory obligations related to outsourcing to third-party vendors, August 2021)","FINRA","https://www.finra.org/rules-guidance/notices/21-29","Regulation / guidance","Supervision of outsourced broker-dealer functions: risk-based due diligence, ongoing monitoring, contingency and exit planning, records","Outsourcing Arrangement, Exit Plan, Supplier Risk Tiering, Outsourcing Regime",["FINRA Rule 3110", "FINRA Regulatory Notice 21-29"]),
 ("ISO 4217 / ISO 3166 / ISO 8601 / ISO 9362 (BIC) / ISO 13616 (IBAN) / ISO 20022; OECD SAF-T","ISO; SWIFT; OECD","https://www.iso.org","Standard","Currency, country, date, bank identifier and account number formats; invoice line numbering","Reference formats used throughout",["ISO 3166", "ISO 9362", "ISO 13616", "ISO 20022", "OECD SAF-T"]),
]
