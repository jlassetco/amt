"""Data Domain 42 - Corporate Communications & Public Affairs. Content module for taxonomy_builder.py (Stage 4 draft v0.1)."""

META = {
 "title": "Corporate Communications & Public Affairs Data Taxonomy",
 "subtitle": "Business domain 42 - Corporate Communications & Public Affairs | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "42_Corporate_Communications_and_Public_Affairs/Corporate_Communications_and_Public_Affairs_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the records of the corporate communications and public affairs function of a US wealth manager (direct brokerage, digital and human advice, its own mutual funds, ETFs and CITs, workplace recordkeeping, institutional advisory and optional trust services): the team that speaks for the firm as a company rather than for its products and advice. It defines the brand register and its standards, use authorizations and reputation measures; media contact profiles, media inquiries, press releases, media coverage and spokesperson authorizations; corporate publications (the broker-dealer's statement of financial condition, the corporate responsibility report, the annual review) and the source records whose figures they publish; internal communications, their audiences and aggregate engagement; communications issues and crises, issue statements and crisis communication plans; public policy positions, consultation responses, contacts with government officials and trade association memberships; lobbying registrations under the federal Lobbying Disclosure Act and state lobbying registers, registered lobbyists, lobbying disclosure reports (LD-2, LD-203, state periodic reports) and their issue lines; and corporate events and corporate award entries. Stitched together from the US Lobbying Disclosure Act and the LDA Guidance of the Clerk of the House and Secretary of the Senate, state lobbying statutes, SEC Rule 17a-5(c), SEC Regulation D, FINRA Rule 2210, IRC 162(e) and 6033(e), GRI 2 and GRI 415, the PRSA code and the AMEC Barcelona Principles. Use it as a starting point for a communications and public affairs data model or a business glossary."),
  ("Scope", "In scope: the brand register (moved from 04 Marketing, Digital & Client Engagement under CD-271, names unchanged), brand standard versions, brand use authorizations and reputation measurements; media contact profiles, media inquiries, press releases, media coverage items and spokesperson authorizations; corporate publications and publication source links; internal communications, audiences and engagement; communications issues, issue statements and crisis communication plans; public policy positions, consultation responses, government official contacts and trade association memberships; lobbying registrations, registered lobbyists, lobbying disclosure reports and report issue lines; corporate events and corporate award entries. Out of scope (referenced by ID): journalists, outlets, officials, agencies, trade associations, wire services and award organizers (02 Client & Household, the party core for every external party, PTY-); campaigns, content assets, marketing events, digital properties and social media accounts (04, CAM-, AST-, EVT-, WEB-, SOC-); compliance review of communications and gifts and entertainment (08, REV-, GNE-); fund and manager award results (11, AWD-); shareholder communications (13, COMM-); legal entities, org units and office locations (09); employees and job profiles (20); product change initiatives (36); and the sibling records of 37 (operational incidents, business continuity plans), 38 (policies, political contributions), 39 (legal matters, contracts, corporate resolutions, trademarks), 41 (IT incidents), 43 (capital requirement calculations) and 44 (health and safety, physical security incidents, operational emission records)."),
  ("Structure", "Four levels: Data Domain > Data Family > Data Business Object > Data Business Attribute."),
  ("Core model", "Brand (BRD-) is the register of the firm's brands; Brand Standard Versions and Brand Use Authorizations hang off it, and Reputation Measurements measure a brand or the firm. Journalists and outlets are 02 parties with an effective-dated Media Contact Profile. A Media Inquiry (MEDQ-) is answered, a Press Release (NEWS-) is issued by a legal entity and published on a 04 Digital Property, and both may generate Media Coverage Items (MCOV-). Spokesperson Authorizations say which employees may speak on which topics. A Corporate Publication (type x issuer x period x version) is approved, where a board must approve it, through the 39 Corporate Resolution Subject Link (42 holds only a derived approval date), and points through Publication Source Links to the 20, 43 and 44 records whose figures it publishes. Internal Communications have Audiences and aggregate Engagement. A Communications Issue (CRIS-) holds its trigger reference once (37, 39, 41 or 44 incident or matter) and carries Issue Statements; Crisis Communication Plans are versioned and linked to the 37 Business Continuity Plan. Public Policy Positions (PUBP-) are argued in Consultation Responses and Government Official Contacts; Trade Association Memberships hold dues and the lobbying portion. A Lobbying Registration (regime x registrant) designates Registered Lobbyists and files Lobbying Disclosure Reports (LOBR-) with Issue Lines; an LD-203 report references 38 Political Contributions and copies no amount. Corporate Events and Corporate Award Entries complete the record."),
  ("Design principles", "1) 42 holds the corporate message; 04 holds the channels (CD-272): no URL or handle register here, only references to WEB- and SOC-. 2) 42 publishes, others produce: a corporate publication holds no figure that 20, 43 or 44 masters. 3) Lobbying here, political money in 38 (CD-273). 4) One brand register, stewarded per brand level (CD-271). 5) Fund and manager award results stay in 11. 6) A communications issue references its trigger once; the triggering domains hold no reference back. 7) Effective-date profiles, authorizations, memberships, registrations and lobbyist designations; version positions, standards, plans and publications. 8) Flag personal data (journalists, officials, lobbyists, spokespeople, authors) as PII. 9) Flag Critical Data Elements (CDE)."),
  ("Applies To", "Shows the record each attribute belongs to: Brand, Brand Standard, Brand Use, Reputation Measure, Media Profile, Media Inquiry, Press Release, Coverage, Spokesperson, Publication, Source Link, Internal Comm, Audience, Engagement, Issue, Statement, Crisis Plan, Policy Position, Consultation, Official Contact, Membership, Registration, Lobbyist, Lobbying Report, Issue Line, Corporate Event or Award Entry."),
  ("CDE", "Y = proposed Critical Data Element: needed to identify a brand, release, inquiry, issue, publication, registration or report, to meet a statutory publication or lobbying disclosure deadline, to evidence approval and compliance review of a public statement, or to report lobbying expenses and issues correctly. Confirm with the Head of Corporate Communications, the Head of Government Relations and Compliance."),
  ("Primary / Secondary Reference", "Standard, rule or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Vendor practice (media monitoring, newswire and PR CRM tools) indicates common structure only."),
  ("Notes", "PII = personal data under US state privacy laws. Journalists, government officials, registered lobbyists (including the covered official positions they held), spokespeople and authors are individuals. LD-203 contribution details are personal data held in 38. Internal communication engagement is held in aggregate only."),
  ("Tabs", "Hierarchy | Taxonomy | Code Lists | Relationships | Sources."),
  ("Suggested next steps", "1) Validate families, the brand stewardship row rule and CDEs with Corporate Communications, Government Relations, Marketing (04) and Compliance (08, 38). 2) Confirm whether the firm or an affiliate is an LDA registrant or only a client of outside lobbying firms, and in which states it registers lobbyists. 3) Map Media Contact Profile, Media Inquiry and Media Coverage Item to the PR CRM and media monitoring tools. 4) Agree with 20, 43 and 44 the source records each corporate publication cites. 5) Agree with 37, 39, 41 and 44 that the trigger link is held only on the Communications Issue. 6) The LD-203 report references 38 Political Contributions by their key (PCON <year>-<sequence>). 7) Done at the Stage 4 consolidation: 04 Brand moved here with BRD- (CD-271)."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Brand Governance", "CP-BGV",
  "The brand register of the group (moved from 04 Marketing, Digital & Client Engagement under CD-271, names unchanged), the brand standards that govern its use, the authorizations given to affiliates and partners to use a brand, and the measurements of brand and corporate reputation.",
  [
   ("Brand Register", "Corporate, affiliate, sub- and product-range brands under which the firm operates and markets. Row rule (CD-271), read from Brand Level: Corporate Brand, Affiliate / Boutique Brand and Co-Brand rows are stewarded by Corporate Communications; Sub-Brand and Product Range Brand rows by 04 Marketing. All rows are mastered here.", [
     ("Brand", [
       # Moved from 04 unchanged (CD-271)
       ("Brand ID", "Unique internal identifier for the brand.", "Brand", "Identifier", "", "BRD-003", "Internal", "", "Y"),
       ("Brand Name", "Name of the brand as used in market.", "Brand", "Text", "", "Example Investments Fixed Income", "Internal", "", "Y"),
       ("Brand Level", "Position of the brand in the brand architecture.", "Brand", "Code", "Brand Level", "Sub-Brand", "Internal", "", "Y"),
       ("Parent Brand", "Brand directly above this brand in the hierarchy.", "Brand", "Reference (Brand)", "", "BRD-001", "Internal", "", ""),
       ("Brand Status", "Lifecycle status of the brand.", "Brand", "Code", "Brand Status", "Active", "Internal", "", ""),
       ("Brand Permitted Jurisdictions", "Countries in which the brand may be used (e.g., subject to trademark registration or entity licensing).", "Brand", "Code (multi)", "ISO 3166-1 alpha-2", "US; GB; LU; DE; IE", "Internal", "", ""),
       # Corporate brand governance additions in 42
       ("Brand Owning Entity", "Group legal entity that owns the brand and in whose name its trademarks are filed (the registrations themselves are 39 Trademark Registrations).", "Brand", "Reference (Legal Entity)", "", "LEN-0003", "Internal", "", "", "Added in 42."),
     ]),
   ]),
   ("Brand Standards", "Versioned brand guidelines: visual identity, tone of voice and usage rules.", [
     ("Brand Standard Version", [
       ("Standard Brand", "Brand the guideline governs.", "Brand Standard", "Reference (Brand)", "", "BRD-001", "Internal", "", "Y"),
       ("Standard Version Number", "Version of the brand guideline.", "Brand Standard", "Text", "", "4.2", "Internal", "", ""),
       ("Visual Identity Rules Summary", "Summary of the logo, color, typography and imagery rules the version sets.", "Brand Standard", "Text", "", "Masterbrand logo lockup with endorsement line for affiliates; primary palette navy and teal", "ISO 20671", "", ""),
       ("Standard Approved By", "Executive who approved the guideline version.", "Brand Standard", "Reference (Employee)", "", "EMP-30588", "Internal", "", "", "PII."),
       ("Standard Effective From", "Date the guideline version took effect.", "Brand Standard", "Date", "ISO 8601", "2026-01-15", "Internal", "", ""),
       ("Standard Effective To", "Date the guideline version was superseded.", "Brand Standard", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Brand Use Authorizations", "Permissions given to group affiliates or external partners to use a brand.", [
     ("Brand Use Authorization", [
       ("Authorized Brand", "Brand the authorization permits to be used.", "Brand Use", "Reference (Brand)", "", "BRD-001", "Internal", "", "Y"),
       ("Licensee Entity", "Group legal entity authorized to use the brand; empty when the licensee is external.", "Brand Use", "Reference (Legal Entity)", "", "LEN-0021", "Internal", "", ""),
       ("Licensee Party", "External party (intermediary firm, plan sponsor partner, event organizer) authorized to use the brand; empty when the licensee is a group entity.", "Brand Use", "Reference (Party)", "", "PTY-104588", "Internal", "", ""),
       ("Brand Use Scopes", "Kinds of use permitted.", "Brand Use", "Code (multi)", "Brand Use Scope", "Co-Branding; Sponsorship", "Internal", "", "Y"),
       ("Brand Use Contract", "Contract (license or sponsorship agreement) under which the brand may be used, where one exists.", "Brand Use", "Reference (Contract, 39)", "", "CTRCT-0041877", "Internal", "", "", "39 masters contracts and trademark rights."),
       ("Brand Use Effective From", "Date the authorization starts.", "Brand Use", "Date", "ISO 8601", "2026-03-01", "Internal", "", ""),
       ("Brand Use Effective To", "Date the authorization ends.", "Brand Use", "Date", "ISO 8601", "2027-02-28", "Internal", "", ""),
     ]),
   ]),
   ("Reputation Measurement", "Measured brand and corporate reputation: awareness, consideration, reputation index, share of voice and net sentiment.", [
     ("Reputation Measurement", [
       ("Measured Brand", "Brand measured; for the firm as a whole, the Corporate Brand.", "Reputation Measure", "Reference (Brand)", "", "BRD-001", "Barcelona Principles 4.0", "", ""),
       ("Reputation Measure", "Measure reported.", "Reputation Measure", "Code", "Reputation Measure", "Share of Voice", "Barcelona Principles 4.0", "ISO 20671", "Y"),
       ("Measurement Value", "Value of the measure for the period, in the unit the measure defines.", "Reputation Measure", "Decimal", "", "18.4", "Barcelona Principles 4.0", "", "Y"),
       ("Measurement Stakeholder Group", "Audience the measure was taken among.", "Reputation Measure", "Code", "Stakeholder Group", "Financial Advisers and Intermediaries", "Barcelona Principles 4.0", "", ""),
       ("Measurement Provider", "Research or media monitoring vendor that produced the measure.", "Reputation Measure", "Reference (Party)", "", "PTY-100733", "Internal", "", ""),
       ("Measurement Data Basis", "How the value was obtained.", "Reputation Measure", "Code", "Shared: Data Basis", "Survey-Based", "Internal", "", ""),
       ("Measurement Period Start", "First day of the measured period; with the period end it separates monthly from annual measures.", "Reputation Measure", "Date", "ISO 8601", "2026-07-01", "Internal", "", ""),
       ("Measurement Period End", "Last day of the measured period.", "Reputation Measure", "Date", "ISO 8601", "2026-09-30", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Media Relations", "CP-MED",
  "The firm's relationship with the media: profiles of journalists and outlets (parties in 02), inquiries received, press releases issued, the coverage that results and the employees authorized to speak for the firm.",
  [
   ("Media Contacts", "Media profile of a journalist or outlet held in the 02 party master (17 Issuer Profile pattern).", [
     ("Media Contact Profile", [
       ("Media Party", "Journalist or media outlet the profile describes.", "Media Profile", "Reference (Party)", "", "PTY-104588", "Internal", "", "", "PII when the party is a journalist."),
       ("Media Outlet", "Outlet the journalist writes for; empty on an outlet's own profile.", "Media Profile", "Reference (Party)", "", "PTY-100221", "Internal", "", ""),
       ("Media Outlet Type", "Kind of outlet, on an outlet's profile.", "Media Profile", "Code", "Media Outlet Type", "Trade Press", "Internal", "", ""),
       ("Media Beats", "Subjects the journalist or outlet covers.", "Media Profile", "Code (multi)", "Media Beat", "Asset Management; ETFs; Retirement", "Internal", "", "", "PII when the party is a journalist."),
       ("Media Relationship Owner", "Communications team member who manages the relationship.", "Media Profile", "Reference (Employee)", "", "EMP-30412", "Internal", "", "", "PII."),
       ("Embargo Trusted Indicator", "Whether the journalist or outlet may receive material under embargo.", "Media Profile", "Boolean", "", "Y", "PRSA Code of Ethics", "", "", "PII when the party is a journalist."),
       ("Media Profile Effective From", "Date the profile values took effect.", "Media Profile", "Date", "ISO 8601", "2025-05-01", "Internal", "", ""),
       ("Media Profile Effective To", "Date the profile values were superseded (beat or outlet change).", "Media Profile", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Media Inquiries", "Questions received from journalists and how they were answered.", [
     ("Media Inquiry", [
       ("Media Inquiry ID", "Unique identifier of the inquiry.", "Media Inquiry", "Identifier", "", "MEDQ-2026-00318", "Internal", "", "Y"),
       ("Inquiring Journalist", "Journalist who made the inquiry.", "Media Inquiry", "Reference (Party)", "", "PTY-104588", "Internal", "", "", "PII."),
       ("Inquiring Outlet", "Outlet the inquiry was made for.", "Media Inquiry", "Reference (Party)", "", "PTY-100221", "Internal", "", ""),
       ("Inquiry Received Timestamp", "When the inquiry was received.", "Media Inquiry", "Timestamp", "ISO 8601", "2026-10-05T09:12:00-04:00", "Internal", "", ""),
       ("Inquiry Topic", "Subject of the question as asked.", "Media Inquiry", "Text", "", "Outflows from the firm's flagship bond fund in Q3", "Internal", "", ""),
       ("Inquiry Response Deadline", "Deadline the journalist set for a response.", "Media Inquiry", "Timestamp", "ISO 8601", "2026-10-05T16:00:00-04:00", "Internal", "", "Y"),
       ("Inquiry Handled By", "Communications team member who handled the inquiry.", "Media Inquiry", "Reference (Employee)", "", "EMP-30412", "Internal", "", "", "PII."),
       ("Inquiry Response Type", "Form of the response given.", "Media Inquiry", "Code", "Inquiry Response Type", "On-Record Statement", "Internal", "", "Y"),
       ("Inquiry Status", "Workflow state of the inquiry.", "Media Inquiry", "Code", "Shared: Case Status", "Closed", "Internal", "", ""),
       ("Inquiry Communications Issue", "Communications issue the inquiry relates to, where it was handled as part of one.", "Media Inquiry", "Reference (Communications Issue, 42)", "", "CRIS-2026-007", "Internal", "", ""),
     ]),
   ]),
   ("Press Releases", "Announcements the firm issues to the media.", [
     ("Press Release", [
       ("Press Release ID", "Unique identifier of the press release.", "Press Release", "Identifier", "", "NEWS-2026-0042", "Internal", "", "Y"),
       ("Press Release Type", "Kind of announcement.", "Press Release", "Code", "Press Release Type", "Product Launch", "Internal", "", "Y"),
       ("Press Release Headline", "Headline of the release as issued.", "Press Release", "Text", "", "Example Investments lists three active fixed income ETFs on NYSE Arca", "Internal", "", ""),
       ("Issuing Entity", "Group legal entity in whose name the release is issued.", "Press Release", "Reference (Legal Entity)", "", "LEN-0004", "Internal", "", "Y"),
       ("Release Subject Products", "Products the release announces or discusses.", "Press Release", "Reference (Investment Product) (multi)", "", "PRD-00981; PRD-00982", "Internal", "", ""),
       ("Release Change Initiative", "Product change initiative (launch, merger, liquidation) the release announces.", "Press Release", "Reference (Product Change Initiative, 36)", "", "LCHG-2026-00118", "Internal", "", ""),
       ("Embargo Until Timestamp", "Time before which recipients may not publish the release.", "Press Release", "Timestamp", "ISO 8601", "2026-10-07T08:00:00-04:00", "PRSA Code of Ethics", "", ""),
       ("Release Timestamp", "When the release was issued to the wire and published.", "Press Release", "Timestamp", "ISO 8601", "2026-10-07T08:00:00-04:00", "Internal", "", "Y", "Held only here."),
       ("Release Publication Property", "Firm digital property (newsroom) where the release is published; 04 holds the property register (CD-272).", "Press Release", "Reference (Digital Property)", "", "WEB-012", "Internal", "", ""),
       ("Release Compliance Review", "08 compliance review of the release where it is a retail or institutional communication.", "Press Release", "Reference (Compliance Review)", "", "REV-2026-004518", "FINRA Rule 2210", "SEC Marketing Rule", "Y", "08 decides whether review is required and holds the outcome."),
       ("Fund in Offering Indicator", "Whether the release mentions a feeder fund (a private fund offered under Regulation D) that is in its offering window, so general solicitation restrictions apply.", "Press Release", "Boolean", "", "N", "SEC Regulation D Rule 502(c)", "SEC Regulation D Rule 506(c)", "Y", "The fund is identified by its PRD- in Release Subject Products; its offering window is the 01 Offering Window (OFWN-)."),
       ("Release Approved By", "Executive who approved the release for issue.", "Press Release", "Reference (Employee)", "", "EMP-30588", "Internal", "", "", "PII."),
       ("Press Release Status", "Publication state of the release.", "Press Release", "Code", "Press Release Status", "Issued", "Internal", "", ""),
       ("Coordinated Shareholder Communication", "13 shareholder notice issued in step with the release (fund reorganizations and liquidations).", "Press Release", "Reference (Shareholder Communication)", "", "COMM-2026-0145", "Internal", "", ""),
     ]),
   ]),
   ("Media Coverage", "Articles and broadcasts by media outlets and journalists that mention the firm, its brands or its people. Row rule (CD-272): social media mentions are mastered in 04 Social Listening Mention; 42 references them from a communications issue and does not record them as coverage.", [
     ("Media Coverage Item", [
       ("Coverage Item ID", "Unique identifier of the coverage item.", "Coverage", "Identifier", "", "MCOV-20261006-00012", "Internal", "", "Y"),
       ("Coverage Outlet", "Outlet that published the item.", "Coverage", "Reference (Party)", "", "PTY-100221", "Internal", "", ""),
       ("Coverage Author", "Journalist who wrote or presented the item.", "Coverage", "Reference (Party)", "", "PTY-104588", "Internal", "", "", "PII."),
       ("Coverage Publication Date", "Date the item was published or broadcast.", "Coverage", "Date", "ISO 8601", "2026-10-06", "Internal", "", "Y"),
       ("Coverage Headline", "Headline of the item.", "Coverage", "Text", "", "Example Investments bets on active bond ETFs", "Internal", "", ""),
       ("Estimated Reach", "Estimated audience of the item as reported by the monitoring provider.", "Coverage", "Integer", "", "240000", "Barcelona Principles 4.0", "", ""),
       ("Coverage Sentiment", "Tone of the item toward the firm.", "Coverage", "Code", "Shared: Sentiment", "Positive", "Barcelona Principles 4.0", "", ""),
       ("Coverage Mentioned Brands", "Brands the item mentions; supports share of voice and brand-level sentiment.", "Coverage", "Reference (Brand) (multi)", "", "BRD-001; BRD-003", "Barcelona Principles 4.0", "", ""),
       ("Quoted Spokesperson", "Employee quoted in the item.", "Coverage", "Reference (Employee)", "", "EMP-30588", "Internal", "", "", "PII."),
       ("Originating Press Release", "Press release the item reports, where it does.", "Coverage", "Reference (Press Release, 42)", "", "NEWS-2026-0042", "Internal", "", ""),
       ("Originating Media Inquiry", "Media inquiry the item resulted from, where it did.", "Coverage", "Reference (Media Inquiry, 42)", "", "MEDQ-2026-00318", "Internal", "", ""),
     ]),
   ]),
   ("Spokespeople", "Employees authorized to speak to the media for the firm.", [
     ("Spokesperson Authorization", [
       ("Spokesperson", "Employee authorized to speak.", "Spokesperson", "Reference (Employee)", "", "EMP-30588", "Internal", "", "Y", "PII."),
       ("Authorized Topics", "Topics the employee may speak on.", "Spokesperson", "Code (multi)", "Spokesperson Topic", "Markets and Economy; Public Policy", "Internal", "", ""),
       ("Authorized Markets", "Countries in whose media the employee may speak.", "Spokesperson", "Code (multi)", "ISO 3166-1 alpha-2", "US; GB", "Internal", "", ""),
       ("Media Training Completion Date", "Date the employee last completed media training (copied from the 20 learning completion).", "Spokesperson", "Date", "ISO 8601", "2026-02-11", "Internal", "", "", "PII. Derived copy (20): completion date of the 20 Learning Completion for the learning item 'Media Training' (firm learning catalog)."),
       ("Spokesperson Effective From", "Date the authorization starts.", "Spokesperson", "Date", "ISO 8601", "2026-02-15", "Internal", "", ""),
       ("Spokesperson Effective To", "Date the authorization ends or was withdrawn.", "Spokesperson", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Corporate Publications", "CP-PUB",
  "Statements and reports the firm publishes about itself as a company, some of them under a statutory publication duty (the broker-dealer statement of financial condition, SEC Rule 17a-5(c)), and the links to the records in other Data Domains whose figures they publish (42 publishes, others produce).",
  [
   ("Corporate Publications", "One publication of a given type by an issuing entity for a period, versioned.", [
     ("Corporate Publication", [
       ("Corporate Publication ID", "Firm-defined identifier of the publication version: type code / publishing entity number / period end year / version.", "Publication", "Identifier", "Firm-defined", "SFC/0003/2025/1", "Internal", "", "Y"),
       ("Corporate Publication Type", "Kind of publication and the duty it meets.", "Publication", "Code", "Publication Type", "Statement of Financial Condition", "Internal", "SEC Rule 17a-5(c)", "Y"),
       ("Publishing Entity", "Group legal entity that publishes, or on whose behalf a group statement is published.", "Publication", "Reference (Legal Entity)", "", "LEN-0021", "Internal", "", "Y"),
       ("Publication Period End", "End of the financial year or reporting period the publication covers.", "Publication", "Date", "ISO 8601", "2025-12-31", "Internal", "", "Y"),
       ("Publication Version", "Version of the publication for the period; a correction is a new version.", "Publication", "Integer", "", "1", "Internal", "", ""),
       ("Publication Signatory", "Director or officer who signed the publication.", "Publication", "Reference (Employee)", "", "EMP-01234", "Internal", "", "", "PII."),
       ("Publication Board Approval Date", "Date of the board resolution that approved the publication, read through the 39 Corporate Resolution Subject Link for this publication.", "Publication", "Date", "ISO 8601", "", "Internal", "", "", "Derived copy (39). 39 holds the only approval link (stage-wide ruling); empty where no board approval is required."),
       ("Publication Deadline Date", "Last date on which the publication may be made under its duty.", "Publication", "Date", "ISO 8601", "2026-06-30", "Internal", "", ""),
       ("Publication Date", "Date the publication was made public.", "Publication", "Date", "ISO 8601", "2026-05-28", "Internal", "", "Y"),
       ("Publication Property", "Firm website where the publication is posted; 04 holds the property register.", "Publication", "Reference (Digital Property)", "", "WEB-012", "Internal", "SEC Rule 17a-5(c)", ""),
       ("Publication Status", "Lifecycle state of the publication version.", "Publication", "Code", "Publication Status", "Published", "Internal", "", ""),
     ]),
   ]),
   ("Publication Sources", "Evidence links from a publication to the records whose figures it publishes. One typed source reference is filled per row, or the Other Source Record Key.", [
     ("Publication Source Link", [
       ("Linked Publication", "Publication the figure appears in.", "Source Link", "Reference (Corporate Publication, 42)", "", "SFC/0003/2025/1", "Internal", "", "Y"),
       ("Source Human Capital Metric Value", "20 metric value published (headcount, workforce composition).", "Source Link", "Reference (Human Capital Metric Value, 20)", "", "Total headcount, 2025-12-31", "Internal", "GRI 2", ""),
       ("Source Capital Requirement Calculation", "43 net capital calculation published in the net capital note of the broker-dealer statement of financial condition.", "Source Link", "Reference (Capital Requirement Calculation, 43)", "", "RCAP-0003-NC-20251231-01", "SEC Rule 17a-5(c)", "SEC Rule 15c3-1", ""),
       ("Source Operational Emission Record", "44 operational emission record published in the corporate responsibility report.", "Source Link", "Reference (Operational Emission Record, 44)", "", "LEN-0004 / ENTITY / 2025 / Scope 2 (Market-Based) / Market-Based", "GHG Protocol Corporate Standard", "", ""),
       ("Other Source Record Key", "Owning Data Domain number and key of a source record where no typed reference above applies (e.g. 19 balance sheet figures in the statement of financial condition).", "Source Link", "Identifier", "", "", "Internal", "", ""),
       ("Source As-Of Date", "As-of date of the source record used.", "Source Link", "Date", "ISO 8601", "2026-04-05", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Internal Communications", "CP-ICM",
  "Announcements and messages to the firm's own staff, who they were sent to, and aggregate measures of how they were received.",
  [
   ("Internal Communications", "Messages to staff.", [
     ("Internal Communication", [
       ("Internal Communication ID", "Identifier of the internal communication issued by the intranet publishing system (year and sequence, no prefix).", "Internal Comm", "Identifier", "", "2026-00412", "Internal", "", "Y"),
       ("Internal Communication Type", "Kind of internal message.", "Internal Comm", "Code", "Internal Communication Type", "Leadership Message", "Internal", "", "Y"),
       ("Internal Communication Title", "Title or subject line of the message.", "Internal Comm", "Text", "", "Our new ETF range and what it means for you", "Internal", "", ""),
       ("Internal Communication Sender", "Executive in whose name the message is sent.", "Internal Comm", "Reference (Employee)", "", "EMP-01234", "Internal", "", "", "PII."),
       ("Internal Channels", "Channels the message was published on.", "Internal Comm", "Code (multi)", "Internal Channel", "Email; Intranet", "Internal", "", ""),
       ("Internal Publish Timestamp", "When the message was published.", "Internal Comm", "Timestamp", "ISO 8601", "2026-10-07T08:30:00-04:00", "Internal", "", "Y"),
       ("Internal Communication Issue", "Communications issue the message relates to.", "Internal Comm", "Reference (Communications Issue, 42)", "", "CRIS-2026-007", "Internal", "", ""),
       ("Announced Policy", "38 firm policy whose launch or change the message announces.", "Internal Comm", "Reference (Policy, 38)", "", "POLCY-0118", "Internal", "", ""),
     ]),
   ]),
   ("Audiences", "Who a message was sent to.", [
     ("Internal Communication Audience", [
       ("Audience Communication", "Message the audience segment received.", "Audience", "Reference (Internal Communication, 42)", "", "2026-00412", "Internal", "", ""),
       ("Audience Segment Type", "Basis on which the segment is defined.", "Audience", "Code", "Audience Segment Type", "Org Unit", "Internal", "", "Y"),
       ("Audience Org Unit", "Org unit the segment covers.", "Audience", "Reference (Org Unit)", "", "OU-DIST-US", "Internal", "", ""),
       ("Audience Office", "Office location the segment covers.", "Audience", "Reference (Office Location)", "", "SITE-US-SFO", "Internal", "", ""),
       ("Audience Legal Entity", "Legal entity whose staff the segment covers.", "Audience", "Reference (Legal Entity)", "", "LEN-0021", "Internal", "", ""),
       ("Audience Job Profile", "20 job profile whose holders the segment covers.", "Audience", "Reference (Job Profile)", "", "JOB-00412", "Internal", "", ""),
       ("Audience Recipient Count", "Number of staff in the segment when the message was sent.", "Audience", "Integer", "", "1240", "Internal", "", ""),
     ]),
   ]),
   ("Engagement", "Aggregate measures of how a message was received; no per-person rows.", [
     ("Internal Communication Engagement", [
       ("Engagement Communication", "Message measured.", "Engagement", "Reference (Internal Communication, 42)", "", "2026-00412", "Internal", "", ""),
       ("Engagement Channel", "Channel measured.", "Engagement", "Code", "Internal Channel", "Intranet", "Internal", "", ""),
       ("Engagement Measurement Date", "Date up to which the measures are counted.", "Engagement", "Date", "ISO 8601", "2026-10-14", "Internal", "", ""),
       ("Unique Viewers Count", "Number of distinct recipients who opened or viewed the message.", "Engagement", "Integer", "", "3188", "Internal", "", ""),
       ("View Rate", "Unique viewers as a share of recipients.", "Engagement", "Percentage", "", "71.5%", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Issues & Crisis Communications", "CP-CRS",
  "Reputational issues and crises the firm manages in public, the statements it issues about them and the plans it keeps ready. The incident, matter or event that triggered an issue is mastered in its own Data Domain and referenced once, from the issue.",
  [
   ("Communications Issues", "An issue or crisis managed by Corporate Communications.", [
     ("Communications Issue", [
       ("Communications Issue ID", "Unique identifier of the issue.", "Issue", "Identifier", "", "CRIS-2026-007", "Internal", "", "Y"),
       ("Issue Title", "Short name of the issue.", "Issue", "Text", "", "Delayed NAV publication for three US bond funds", "Internal", "", ""),
       ("Issue Level", "Severity of the issue on the communications scale.", "Issue", "Code", "Issue Level", "Level 2 - Significant Issue", "Internal", "", "Y"),
       ("Issue Trigger Type", "Kind of event that triggered the issue; says which trigger reference is filled.", "Issue", "Code", "Issue Trigger Type", "Operational Incident", "Internal", "", "Y"),
       ("Trigger Operational Incident", "37 operational incident that triggered the issue.", "Issue", "Reference (Operational Incident, 37)", "", "OPINC-2026-01187", "Internal", "", "", "Held once, here (CD-272)."),
       ("Trigger IT Incident", "41 IT or security incident that triggered the issue.", "Issue", "Reference (IT Incident, 41)", "", "ITINC-2026-004512", "Internal", "", "", "Held once, here (CD-272)."),
       ("Trigger Legal Matter", "39 legal matter that triggered the issue (litigation, enforcement action).", "Issue", "Reference (Legal Matter, 39)", "", "LMAT-2026-0019", "Internal", "", "", "Held once, here (CD-272)."),
       ("Trigger Health and Safety Incident", "44 health and safety incident that triggered the issue.", "Issue", "Reference (Health & Safety Incident, 44)", "", "HSEI-2026-0031", "Internal", "", "", "Held once, here (CD-272)."),
       ("Trigger Physical Security Incident", "44 physical security incident that triggered the issue.", "Issue", "Reference (Physical Security Incident, 44)", "", "PSI 2026-0042", "Internal", "", "", "Held once, here (CD-272)."),
       ("Trigger External Event Description", "Description of an external event (market event, industry story, activist campaign) that triggered the issue.", "Issue", "Text", "", "", "Internal", "", ""),
       ("Issue Status", "Workflow state of the issue.", "Issue", "Code", "Shared: Case Status", "In Progress", "Internal", "", "Y"),
       ("Issue Lead", "Communications lead for the issue.", "Issue", "Reference (Employee)", "", "EMP-30412", "Internal", "", "", "PII."),
       ("Affected Stakeholder Groups", "Stakeholder groups affected by or interested in the issue.", "Issue", "Code (multi)", "Stakeholder Group", "Clients; Financial Advisers and Intermediaries; Media", "Internal", "", ""),
       ("Related Social Mentions", "04 social listening mentions about the issue; 04 masters social mentions (CD-272).", "Issue", "Reference (Social Listening Mention, 04) (multi)", "", "", "Internal", "", ""),
       ("Issue Opened Timestamp", "When the issue was opened.", "Issue", "Timestamp", "ISO 8601", "2026-10-02T18:05:00-04:00", "Internal", "", ""),
       ("Activated Crisis Plan", "Crisis communication plan version invoked for the issue.", "Issue", "Reference (Crisis Communication Plan, 42)", "", "CCP 004 / 3", "Internal", "", ""),
     ]),
   ]),
   ("Issue Statements", "Holding statements, reactive Q&A and messages issued about an issue.", [
     ("Issue Statement", [
       ("Statement Issue", "Issue the statement is about.", "Statement", "Reference (Communications Issue, 42)", "", "CRIS-2026-007", "Internal", "", "Y"),
       ("Statement Version", "Version of the statement for the audience.", "Statement", "Integer", "", "2", "Internal", "", ""),
       ("Statement Type", "Kind of statement.", "Statement", "Code", "Statement Type", "Holding Statement", "Internal", "", ""),
       ("Statement Audience", "Stakeholder group the statement is written for.", "Statement", "Code", "Stakeholder Group", "Media", "Internal", "", ""),
       ("Statement Approved By", "Executive who approved the statement.", "Statement", "Reference (Employee)", "", "EMP-01234", "Internal", "", "", "PII."),
       ("Statement Release Timestamp", "When the statement was released to its audience.", "Statement", "Timestamp", "ISO 8601", "2026-10-02T20:00:00-04:00", "Internal", "", ""),
       ("Statement Delivery Methods", "How the statement was made available; delivery records of client and shareholder messages stay in 12 and 13.", "Statement", "Code (multi)", "Shared: Delivery Method", "Website; Email", "Internal", "", ""),
     ]),
   ]),
   ("Crisis Preparedness", "Plans prepared in advance for communications in a crisis.", [
     ("Crisis Communication Plan", [
       ("Crisis Plan Code", "Firm code of the plan, written without a hyphenated stem; the version is separate.", "Crisis Plan", "Identifier", "Firm-defined", "CCP 004", "Internal", "", "Y"),
       ("Crisis Plan Name", "Name of the plan.", "Crisis Plan", "Text", "", "Fund Operations Disruption Plan", "Internal", "", ""),
       ("Crisis Plan Version", "Version of the plan.", "Crisis Plan", "Integer", "", "3", "Internal", "", "Y"),
       ("Crisis Scenario Types", "Kinds of trigger the plan covers.", "Crisis Plan", "Code (multi)", "Issue Trigger Type", "Operational Incident; IT Incident", "Internal", "", ""),
       ("Crisis Plan Owner", "Employee accountable for the plan.", "Crisis Plan", "Reference (Employee)", "", "EMP-30588", "Internal", "", "", "PII."),
       ("Linked Business Continuity Plan", "37 business continuity plan the communications plan supports.", "Crisis Plan", "Reference (Business Continuity Plan, 37)", "", "BCP 014 / 6", "Internal", "", ""),
       ("Crisis Plan Approval Date", "Date the plan version was approved.", "Crisis Plan", "Date", "ISO 8601", "2026-04-20", "Internal", "", ""),
       ("Crisis Plan Status", "Lifecycle state of the plan version.", "Crisis Plan", "Code", "Shared: Record Status", "Active", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Government Relations & Public Policy", "CP-GPA",
  "The positions the firm takes on public policy, how it argues them in consultations and meetings with officials, and its memberships of trade associations that lobby on its behalf.",
  [
   ("Policy Positions", "Approved, versioned positions the firm takes on public policy topics.", [
     ("Public Policy Position", [
       ("Policy Position ID", "Unique identifier of the position; the version is separate.", "Policy Position", "Identifier", "", "PUBP-0031", "Internal", "", "Y"),
       ("Policy Position Version", "Version of the position.", "Policy Position", "Integer", "", "2", "Internal", "", ""),
       ("Policy Position Title", "Short title of the position.", "Policy Position", "Text", "", "Access to CITs for 403(b) plans", "Internal", "", ""),
       ("Policy Topic", "Topic the position addresses.", "Policy Position", "Code", "Policy Topic", "Retirement Policy", "GRI 415", "", "Y"),
       ("Policy Position Jurisdictions", "Jurisdictions the position applies to.", "Policy Position", "Code (multi)", "ISO 3166-1 alpha-2", "US", "Internal", "", ""),
       ("Policy Position Summary", "Summary of what the firm supports or opposes and why.", "Policy Position", "Text", "", "Supports legislation allowing 403(b) plans to offer collective investment trusts", "Internal", "", ""),
       ("Policy Position Effective From", "Date the version took effect.", "Policy Position", "Date", "ISO 8601", "2026-03-01", "Internal", "", ""),
       ("Policy Position Effective To", "Date the version was superseded or withdrawn.", "Policy Position", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
   ("Consultation Responses", "Responses the firm submits to consultations of regulators and legislatures.", [
     ("Consultation Response", [
       ("Consultation Body Type", "Kind of body that issued the consultation.", "Consultation", "Code", "Consultation Body Type", "Regulator", "Internal", "", ""),
       ("Consulting Regulator", "Regulator that issued the consultation, when the body is a regulator.", "Consultation", "Code", "Shared: Regulator", "SEC", "Internal", "", ""),
       ("Consulting Body", "Legislature, committee, ministry or other body that issued the consultation, when it is not a regulator.", "Consultation", "Reference (Party)", "", "PTY-300411", "Internal", "", ""),
       ("Consultation Reference", "Reference the body gave the consultation (an SEC file number, a FINRA Regulatory Notice number, a Federal Register docket number).", "Consultation", "Identifier", "", "S7-2026-04", "Internal", "", "Y"),
       ("Responding Entity", "Group legal entity in whose name the response is submitted.", "Consultation", "Reference (Legal Entity)", "", "LEN-0004", "Internal", "", "Y"),
       ("Response Submission Date", "Date the response was submitted.", "Consultation", "Date", "ISO 8601", "2026-09-15", "Internal", "", "Y"),
       ("Response Position", "Public policy position the response argues.", "Consultation", "Reference (Public Policy Position, 42)", "", "PUBP-0031", "Internal", "", ""),
       ("Joint Response Association", "Trade association with which the response was submitted jointly, if any.", "Consultation", "Reference (Party)", "", "PTY-300512", "Internal", "", ""),
     ]),
   ]),
   ("Government Official Contacts", "Meetings, calls and letters with government officials and their staff.", [
     ("Government Official Contact", [
       ("Official Contact ID", "Firm-defined identifier of the contact event.", "Official Contact", "Identifier", "Firm-defined", "GOC/2026/0118", "Internal", "", ""),
       ("Contacted Official", "Official or staff member contacted.", "Official Contact", "Reference (Party)", "", "PTY-300877", "LDA (2 U.S.C. 1602)", "", "Y", "PII."),
       ("Official Agency", "Agency, office or legislative body the official belongs to.", "Official Contact", "Reference (Party)", "", "PTY-300411", "LDA (2 U.S.C. 1602)", "", ""),
       ("Firm Attendees", "Employees who took part in the contact.", "Official Contact", "Reference (Employee) (multi)", "", "EMP-01234; EMP-30588", "Internal", "", "", "PII."),
       ("Official Contact Date", "Date of the contact.", "Official Contact", "Date", "ISO 8601", "2026-09-22", "Internal", "", "Y"),
       ("Official Contact Topics", "Policy topics discussed.", "Official Contact", "Code (multi)", "Policy Topic", "Retirement Policy", "Internal", "", ""),
       ("Discussed Position", "Public policy position the firm put forward.", "Official Contact", "Reference (Public Policy Position, 42)", "", "PUBP-0031", "Internal", "", ""),
       ("Lobbying Contact Indicator", "Whether the contact is a lobbying contact with a covered official under the LDA definition, and so counts toward registration and LD-2 reporting.", "Official Contact", "Boolean", "", "Y", "LDA (2 U.S.C. 1602)", "LDA Guidance", "Y"),
       ("Related Hospitality Item", "08 gift or entertainment item provided to the official at or around the contact; 08 decides its compliance.", "Official Contact", "Reference (Gift / Entertainment Item)", "", "GNE-2026-018834", "Internal", "", ""),
     ]),
   ]),
   ("Trade Associations", "Memberships of industry and trade associations.", [
     ("Trade Association Membership", [
       ("Trade Association", "Association the firm belongs to.", "Membership", "Reference (Party)", "", "PTY-300512", "GRI 2-28", "", ""),
       ("Member Entity", "Group legal entity that holds the membership.", "Membership", "Reference (Legal Entity)", "", "LEN-0004", "GRI 2-28", "", "Y"),
       ("Membership Tier", "Membership class held.", "Membership", "Code", "Association Membership Tier", "Board Member", "Internal", "", ""),
       ("Annual Dues Amount", "Dues payable for the membership year.", "Membership", "Amount", "ISO 4217", "USD 185000", "Internal", "", "Y", "Held only here."),
       ("Dues Lobbying Portion Percentage", "Share of dues the association reports as spent on lobbying and political expenditure (IRC 6033(e) notice).", "Membership", "Percentage", "", "22%", "IRC 162(e)", "IRC 6033(e)", "", "The tax treatment is 19's."),
       ("Lobbying Portion Reported Indicator", "Whether the percentage was reported by the association (Y) or estimated by the firm (N).", "Membership", "Boolean", "", "Y", "IRC 6033(e)", "", ""),
       ("Membership Effective From", "Date the membership started.", "Membership", "Date", "ISO 8601", "2019-01-01", "Internal", "", ""),
       ("Membership Effective To", "Date the membership ended.", "Membership", "Date", "ISO 8601", "", "Internal", "", ""),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Lobbying Disclosure", "CP-LOB",
  "Registrations under lobbying disclosure regimes (the federal Lobbying Disclosure Act and US state lobbying registers), the employees designated as lobbyists, and the periodic reports filed. Political contributions reported on LD-203 are mastered in 38 and referenced, never copied (CD-273).",
  [
   ("Registrations", "A registration of a group entity, as registrant or as client, under one regime.", [
     ("Lobbying Registration", [
       ("Lobbying Registration ID", "Identifier the regime assigned to the registration (LDA Senate ID or House ID, state registration number).", "Registration", "Identifier", "External (regime registration number)", "401103942-12", "LDA Guidance", "State lobbying statutes", "Y", "Held only here."),
       ("Lobbying Regime", "Disclosure regime the registration is made under.", "Registration", "Code", "Lobbying Regime", "US Lobbying Disclosure Act", "LDA (2 U.S.C. 1603)", "State lobbying statutes", "Y"),
       ("Registrant Category", "Capacity in which the group appears on the register.", "Registration", "Code", "Registrant Category", "LDA In-House Self-Filer", "LDA Guidance", "State lobbying statutes", "Y"),
       ("Registrant Entity", "Group legal entity that is the registrant or the client named on the registration.", "Registration", "Reference (Legal Entity)", "", "LEN-0004", "LDA (2 U.S.C. 1603)", "", "Y"),
       ("Outside Lobbying Firm", "Lobbying firm that registered the group entity as its client, where the registration is not filed by the group.", "Registration", "Reference (Party)", "", "", "LDA (2 U.S.C. 1603)", "", ""),
       ("Registration Jurisdiction", "US state (or local jurisdiction within a state) of a state lobbying register; left blank for the LDA.", "Registration", "Code", "ISO 3166-2", "US-NY", "Internal", "", ""),
       ("Registration Effective Date", "Date the registration took effect (for an LD-1, the date of the first lobbying contact or retention).", "Registration", "Date", "ISO 8601", "2024-02-14", "LDA Guidance", "", "Y"),
       ("Registration Termination Date", "Date the registration was terminated.", "Registration", "Date", "ISO 8601", "", "LDA Guidance", "", ""),
     ]),
   ]),
   ("Registered Lobbyists", "Employees listed as lobbyists on a registration.", [
     ("Registered Lobbyist", [
       ("Lobbyist", "Employee listed as a lobbyist.", "Lobbyist", "Reference (Employee)", "", "EMP-30588", "LDA (2 U.S.C. 1602)", "", "Y", "PII."),
       ("Lobbyist Registration", "Registration the lobbyist is listed on.", "Lobbyist", "Reference (Lobbying Registration, 42)", "", "401103942-12", "LDA Guidance", "", "Y"),
       ("Covered Official Position Held", "Covered executive or legislative branch position the lobbyist held in the 20 years before first acting as lobbyist, as disclosed on the LD-1 or LD-2; several positions are separated with ';'.", "Lobbyist", "Text", "", "Legislative Assistant, Senate Committee on Banking, Housing, and Urban Affairs", "LDA Guidance", "", "Y", "PII."),
       ("Lobbyist Effective From", "Date the employee was first listed on the registration.", "Lobbyist", "Date", "ISO 8601", "2024-02-14", "LDA Guidance", "", ""),
       ("Lobbyist Effective To", "Date the employee was removed (terminated as lobbyist on an LD-2).", "Lobbyist", "Date", "ISO 8601", "", "LDA Guidance", "", ""),
     ]),
   ]),
   ("Lobbying Reports", "Periodic disclosure reports filed under a registration.", [
     ("Lobbying Disclosure Report", [
       ("Lobbying Report ID", "Unique identifier of the report.", "Lobbying Report", "Identifier", "", "LOBR-LD2-2026Q3-001", "Internal", "", "Y"),
       ("Report Registration", "Registration the report is filed under.", "Lobbying Report", "Reference (Lobbying Registration, 42)", "", "401103942-12", "LDA Guidance", "", "Y"),
       ("Filing Lobbyist", "Registered lobbyist who files the report in their own name (LD-203 lobbyist rows); blank for registrant filings.", "Lobbying Report", "Reference (Employee)", "", "", "LDA Guidance", "", "Y", "PII."),
       ("Lobbying Report Type", "Kind of report.", "Lobbying Report", "Code", "Lobbying Report Type", "LD-2 Quarterly Activity Report", "LDA Guidance", "State lobbying statutes", "Y"),
       ("Report Period", "Period the report covers, as a quarter, half-year or year.", "Lobbying Report", "Text", "", "2026Q3", "LDA Guidance", "", "Y"),
       ("Report Filed Timestamp", "When the report was filed.", "Lobbying Report", "Timestamp", "ISO 8601", "2026-10-16T15:22:00-04:00", "LDA Guidance", "", "Y"),
       ("Report Filing ID", "Identifier the register assigned to the filing.", "Lobbying Report", "Identifier", "External (register filing identifier)", "8f1c2a77-0d4e-4b9e-9b61-2f6d0e1a4c55", "LDA Guidance", "", ""),
       ("Lobbying Expense Amount", "Expenses for lobbying activities reported on an LD-2 for the period, rounded to the nearest USD 10,000; blank on other report types and when below the reporting floor.", "Lobbying Report", "Amount", "ISO 4217", "USD 120000", "LDA Guidance", "", "Y"),
       ("Below LD-2 Reporting Floor Indicator", "Whether the LD-2 reports expenses of less than USD 5,000 (a check box, not a figure).", "Lobbying Report", "Boolean", "", "N", "LDA Guidance", "", ""),
       ("Expense Reporting Method", "Method used to compute expenses on an LD-2 of an in-house registrant.", "Lobbying Report", "Code", "LDA Expense Reporting Method", "IRC 162(e) Method", "LDA Guidance", "IRC 162(e)", ""),
       ("Amended Report", "Earlier report this report amends.", "Lobbying Report", "Reference (Lobbying Disclosure Report, 42)", "", "", "LDA Guidance", "", ""),
       ("Reported Political Contributions", "38 political contribution records disclosed on an LD-203; amounts and recipients stay in 38.", "Lobbying Report", "Reference (Political Contribution, 38) (multi)", "", "PCON 2026-00007", "LDA Guidance", "", "", "LD-203 only. PII when the contributor is a lobbyist. CD-273: no amount is copied."),
       ("Gift Rule Certification Indicator", "Whether the filer certified on the LD-203 that it has read and complied with the congressional gift and travel rules.", "Lobbying Report", "Boolean", "", "Y", "LDA Guidance", "", ""),
     ]),
   ]),
   ("Report Issue Lines", "The general issue areas reported on an LD-2 and what was lobbied on.", [
     ("Lobbying Report Issue Line", [
       ("Issue Line Report", "Report the line belongs to.", "Issue Line", "Reference (Lobbying Disclosure Report, 42)", "", "LOBR-LD2-2026Q3-001", "LDA Guidance", "", "Y"),
       ("General Issue Area Code", "LDA general issue area of the line.", "Issue Line", "Code", "External (LDA general issue area codes, LDA Guidance)", "RET", "LDA Guidance", "", "Y"),
       ("Specific Lobbying Issues", "Specific issues lobbied on, including bill numbers and executive branch actions.", "Issue Line", "Text", "", "H.R. 1013, Retirement Fairness for Charities and Educational Institutions Act; CIT access for 403(b) plans", "LDA Guidance", "", ""),
       ("Entities Contacted", "Houses of Congress and federal agencies contacted on the issue.", "Issue Line", "Code (multi)", "External (LDA list of houses of Congress and federal agencies)", "U.S. House of Representatives; U.S. Senate; Securities and Exchange Commission", "LDA Guidance", "", ""),
       ("Issue Line Lobbyists", "Employees who acted as lobbyists on the issue; each must hold an effective Registered Lobbyist row on the report's registration.", "Issue Line", "Reference (Employee) (multi)", "", "EMP-30588", "LDA Guidance", "", "", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Corporate Events & Recognition", "CP-REC",
  "Events the firm holds as a company (not client or prospect marketing events, which are 04) and the entries it submits for awards. Fund and manager award results stay in 11.",
  [
   ("Corporate Events", "Town halls, media briefings, policy roundtables, exchange listing ceremonies and community events.", [
     ("Corporate Event", [
       ("Corporate Event ID", "Firm-defined identifier of the corporate event: year / sequence.", "Corporate Event", "Identifier", "Firm-defined", "CE/2026/0031", "Internal", "", "Y"),
       ("Corporate Event Name", "Name of the event.", "Corporate Event", "Text", "", "Active fixed income ETF listing ceremony", "Internal", "", ""),
       ("Corporate Event Type", "Kind of corporate event.", "Corporate Event", "Code", "Corporate Event Type", "Exchange Listing Ceremony", "Internal", "", "Y"),
       ("Corporate Event Start Timestamp", "When the event starts.", "Corporate Event", "Timestamp", "ISO 8601", "2026-10-07T09:15:00-04:00", "Internal", "", "Y"),
       ("Corporate Event Venue", "Firm office where the event is held; empty for external venues.", "Corporate Event", "Reference (Office Location)", "", "SITE-US-SFO", "Internal", "", ""),
       ("External Venue Description", "Name and city of an external venue.", "Corporate Event", "Text", "", "NYSE, New York", "Internal", "", ""),
       ("Corporate Event Audiences", "Stakeholder groups invited.", "Corporate Event", "Code (multi)", "Stakeholder Group", "Media; Employees", "Internal", "", ""),
       ("Event Press Release", "Press release issued for the event.", "Corporate Event", "Reference (Press Release, 42)", "", "NEWS-2026-0042", "Internal", "", ""),
     ]),
   ]),
   ("Award Entries", "Entries the firm submits for awards, and the result of firm-level awards.", [
     ("Corporate Award Entry", [
       ("Award Program Name", "Name of the award program and edition.", "Award Entry", "Text", "", "Investment Week Sustainable Investment Awards 2026", "Internal", "", ""),
       ("Award Organizer", "Organization that runs the awards.", "Award Entry", "Reference (Party)", "", "PTY-300901", "Internal", "", ""),
       ("Entry Category", "Category entered.", "Award Entry", "Text", "", "Asset Manager of the Year - ESG", "Internal", "", ""),
       ("Award Year", "Year of the award edition.", "Award Entry", "Integer", "", "2026", "Internal", "", ""),
       ("Award Entrant Type", "What kind of entrant the entry is for; says which entrant reference and which result attribute is filled.", "Award Entry", "Code", "Award Entrant Type", "Firm", "Internal", "", "Y"),
       ("Entrant Entity", "Group legal entity entered.", "Award Entry", "Reference (Legal Entity)", "", "LEN-0021", "Internal", "", ""),
       ("Entrant Product", "Product entered.", "Award Entry", "Reference (Investment Product)", "", "", "Internal", "", ""),
       ("Entrant Employee", "Employee entered (for a manager or individual award).", "Award Entry", "Reference (Employee)", "", "", "Internal", "", "", "PII."),
       ("Firm Award Result", "Result of the entry for a firm-level award (employer, firm of the year, brand, ESG leadership); empty for fund and manager awards.", "Award Entry", "Code", "Award Result", "Highly Commended", "Internal", "", "Y"),
       ("Fund or Manager Award Record", "11 award record holding the result of a fund or manager award entry.", "Award Entry", "Reference (Award, 11)", "", "AWD-2026-0045", "Internal", "", "", "11 is the only record of fund and manager award results, including whether a fee was paid to participate."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
CL = {
 # Moved from 04 Marketing, Digital & Client Engagement (CD-271; values unchanged)
 "Brand Level": ("Internal", [("Corporate Brand","Masterbrand of the group"),("Affiliate / Boutique Brand","Investment affiliate in a multi-boutique firm"),("Sub-Brand","Capability or business-line brand"),("Product Range Brand","Brand for a range, e.g. an ETF range"),("Co-Brand","Joint brand with a distributor or partner")]),
 "Brand Status": ("Internal", [("Planned",""),("Active",""),("Being Retired","Rebrand in progress"),("Retired","")]),
 # Enterprise shared lists are cited directly as 'Shared: <name>'; the local copies were removed at the Stage 4 consolidation (CD-283).
 # New in 42
 "Brand Use Scope": ("Internal", [("Co-Branding","Joint materials with an intermediary firm or partner"),("Sponsorship","Sponsorship of a third-party event, team or program"),("Affiliate Endorsement","Group brand endorsement of an affiliate"),("Third-Party Event","Use by an event organizer"),("Media / Publication","Use by a publisher, e.g. an award logo or ranking"),("Charitable / Community","Use by a charity or community partner")]),
 "Reputation Measure": ("AMEC Barcelona Principles 4.0 / ISO 20671 (structure only)", [("Aided Awareness","Share of the audience that recognizes the brand when prompted (percent)"),("Unaided Awareness","Share that names the brand unprompted (percent)"),("Consideration","Share that would consider the brand (percent)"),("Reputation Index","Composite reputation score of the provider's model (index)"),("Share of Voice","Share of category media mentions that mention the brand (percent)"),("Net Sentiment","Positive minus negative mentions as a share of all mentions (percent)"),("Net Promoter Score","Promoters minus detractors (score -100 to 100)")]),
 "Media Outlet Type": ("Internal", [("National Newspaper",""),("Financial Newswire",""),("Trade Press","Asset management, adviser and pensions trade titles"),("Broadcast - TV",""),("Broadcast - Radio / Podcast",""),("Online News",""),("Newsletter / Substack",""),("Social Media Creator","Individual whose channel is followed as a media source"),("Other","")]),
 "Media Beat": ("Internal", [("Asset Management",""),("ETFs",""),("Retirement",""),("Wealth / Adviser",""),("Fixed Income",""),("Equities",""),("Private Markets",""),("Sustainable Investing",""),("Markets / Economics",""),("Regulation / Policy",""),("Corporate / M&A",""),("Technology","")]),
 "Inquiry Response Type": ("Internal (PRSA practice)", [("On-Record Statement","Written statement attributable to the firm"),("Interview","Spokesperson interview on the record"),("Background","Information not for attribution"),("Data Provided","Facts or figures provided"),("Referred","Referred to another party (e.g. an industry body)"),("Declined to Comment","")]),
 "Press Release Type": ("Internal", [("Corporate Announcement",""),("Financial Results","Results of a listed parent"),("Product Launch","Fund, ETF, CIT or strategy launch"),("Exchange Listing",""),("Product Change","Reorganization, merger, liquidation, rename"),("Executive Appointment",""),("Acquisition / Partnership",""),("Award / Recognition","Firm-level award"),("Research / Survey","Publication of firm research"),("Policy Statement","Public policy position"),("Other","")]),
 "Press Release Status": ("Internal", [("Draft",""),("Scheduled","Approved and set for release at the embargo time"),("Issued",""),("Corrected","A correction has been issued"),("Withdrawn","Withdrawn after issue"),("Canceled","Not issued")]),
 "Publication Type": ("Internal (SEC Rule 17a-5(c); GRI)", [("Statement of Financial Condition","Broker-dealer statement of financial condition furnished to customers semiannually, audited at year end (SEC Rule 17a-5(c)); net capital figures from 43"),("Corporate Responsibility Report","Sustainability or impact report; figures from 20 and 44"),("Annual Review","Corporate review of the year"),("Other","")]),
 "Publication Status": ("Internal", [("Draft",""),("In Approval",""),("Published",""),("Superseded","A later version replaced it"),("Withdrawn","")]),
 "Internal Communication Type": ("Internal", [("All-Staff Announcement",""),("Leadership Message",""),("Intranet Article",""),("Policy Launch Notice","Announces a 38 policy or change"),("Organization Announcement","Appointments and structure changes"),("Crisis Update","Employee message during a communications issue"),("Town Hall Invitation","")]),
 "Internal Channel": ("Internal", [("Email",""),("Intranet",""),("Enterprise Social Network",""),("Collaboration Chat",""),("Digital Signage",""),("Town Hall","Live or recorded")]),
 "Audience Segment Type": ("Internal", [("All Staff",""),("Org Unit",""),("Office Location",""),("Legal Entity",""),("Job Profile",""),("Leadership Group","Named senior leadership population kept by Corporate Communications (e.g. top 150 leaders)")]),
 "Issue Level": ("Internal", [("Level 1 - Watch","Monitored; no external activity"),("Level 2 - Significant Issue","Active management; holding statement ready"),("Level 3 - Crisis","Crisis plan invoked; executive sign-off of statements")]),
 "Issue Trigger Type": ("Internal", [("Operational Incident","37"),("IT Incident","41, including cyber incidents"),("Legal Matter","39 litigation or enforcement"),("Health and Safety Incident","44"),("Physical Security Incident","44"),("External Event","Market, industry or activist event")]),
 "Stakeholder Group": ("Internal (GRI 2-29 stakeholder concepts)", [("Clients",""),("Fund Shareholders",""),("Financial Advisers and Intermediaries",""),("Employees",""),("Media",""),("Regulators and Government",""),("Investors in the Firm","Shareholders and lenders of the parent"),("Communities",""),("Other","")]),
 "Statement Type": ("Internal (form of the statement only; audience and channel are separate attributes)", [("Holding Statement",""),("Reactive Q&A",""),("Proactive Statement",""),("Correction / Clarification","")]),
 "Spokesperson Topic": ("Internal", [("Firm Strategy and Results",""),("Markets and Economy",""),("Investment Capabilities",""),("Public Policy","Positions approved as Public Policy Positions"),("Sustainability",""),("Crisis Response","Statements on a communications issue")]),
 "Policy Topic": ("Internal", [("Fund Regulation",""),("ETF Regulation",""),("Retirement Policy","Including CIT access for 403(b) plans"),("Private Markets Access","Retail access to private markets"),("Tax Policy",""),("Sustainable Finance",""),("Market Structure",""),("Data and Technology","")]),
 "Consultation Body Type": ("Internal", [("Regulator",""),("Legislature / Committee",""),("Government Ministry / Treasury",""),("Standard Setter","e.g. IOSCO, ISSB"),("Self-Regulatory Organization","")]),
 "Association Membership Tier": ("Internal", [("Board Member",""),("Full Member",""),("Associate Member",""),("Observer","")]),
 "Lobbying Regime": ("LDA; state lobbying statutes", [("US Lobbying Disclosure Act","Federal; Clerk of the House and Secretary of the Senate"),("US State Lobbying Regime","State (or local) registration; jurisdiction on the record")]),
 "Registrant Category": ("LDA Guidance; state lobbying statutes", [("LDA In-House Self-Filer","Organization employing in-house lobbyists"),("LDA Client of Lobbying Firm","Named as client on an outside firm's registration"),("US State Lobbyist Employer / Principal","")]),
 "Lobbying Report Type": ("LDA Guidance; state lobbying statutes", [("LD-2 Quarterly Activity Report","Code LD2 in the LOBR- key"),("LD-203 Semiannual Contribution Report","Code LD203"),("US State Periodic Report","Code STATE")]),
 "LDA Expense Reporting Method": ("LDA Guidance (LD-2 expense methods)", [("LDA Definitions Method","Method A"),("IRC 6033(b)(8) Method","Method B, tax-exempt organizations"),("IRC 162(e) Method","Method C")]),
 "Corporate Event Type": ("Internal", [("Town Hall",""),("Media Briefing",""),("Policy Roundtable",""),("Exchange Listing Ceremony",""),("Community Event",""),("Corporate Anniversary / Opening",""),("Other","")]),
 "Award Entrant Type": ("Internal", [("Firm","Firm-level award; result held here"),("Product","Fund or product award; result in 11"),("Portfolio Manager","Manager award; result in 11"),("Individual (Corporate)","Individual corporate award, e.g. communicator or leader of the year; result here")]),
 "Award Result": ("Internal (identical values to 11 Award Outcome; shared-list candidate)", [("Winner",""),("Highly Commended",""),("Shortlisted / Finalist",""),("Not Placed","")]),
}

# ---------------------------------------------------------------------------
REL = [
 ("Brand","is parent of","Brand","1 : 0..n","Brand architecture (moved from 04, CD-271)."),
 ("Brand","has","Brand Standard Version","1 : 0..n","Versioned guidelines."),
 ("Brand","is authorized for use by","Brand Use Authorization","1 : 0..n","Licensee is a 09 legal entity or a 02 party."),
 ("Brand","is protected by","Trademark Registration [39]","1 : 0..n","39 holds trademark rights; held on the 39 side."),
 ("Brand","is applied by","Report Template [12]","1 : 0..n","12 'Brand' re-resolves to 42 (CD-271)."),
 ("Reputation Measurement","measures","Brand","n : 1",""),
 ("Media Contact Profile","describes","Party (Journalist / Media Outlet) [02]","n : 1","Profile keyed by PTY- (CD-143)."),
 ("Media Inquiry","is made by","Party (Journalist) [02]","n : 1",""),
 ("Media Inquiry","may relate to","Communications Issue","n : 0..1",""),
 ("Press Release","is issued by","Internal Legal Entity [09]","n : 1",""),
 ("Press Release","is published on","Digital Property [04]","n : 0..1","04 keeps the property register (CD-272)."),
 ("Press Release","is reviewed by","Compliance Review [08]","n : 0..1","Where the release is a regulated communication."),
 ("Press Release","announces","Product Change Initiative [36] / Investment Product [01]","n : 0..n",""),
 ("Press Release","is coordinated with","Shareholder Communication [13]","n : 0..1","13 holds notices and delivery."),
 ("Media Coverage Item","may originate from","Press Release / Media Inquiry","n : 0..1",""),
 ("Spokesperson Authorization","authorizes","Employee [20]","n : 1",""),
 ("Corporate Publication","is approved through","Corporate Resolution Subject Link [39]","1 : 0..1","Link held only on 39; 42 holds a derived Board Approval Date."),
 ("Corporate Publication","is evidenced by","Publication Source Link","1 : 0..n","42 publishes, others produce."),
 ("Publication Source Link","points to","Human Capital Metric Value [20] / Capital Requirement Calculation [43] / Operational Emission Record [44]","n : 0..1","One typed source per row, or the Other Source Record Key."),
 ("Internal Communication","is sent to","Internal Communication Audience","1 : 1..n","Segments by 09 org unit, office or legal entity."),
 ("Internal Communication","is measured by","Internal Communication Engagement","1 : 0..n","Aggregate only."),
 ("Internal Communication","may announce","Policy [38]","n : 0..1",""),
 ("Communications Issue","is triggered by","Operational Incident [37] / IT Incident [41] / Legal Matter [39] / Health & Safety Incident / Physical Security Incident [44]","n : 0..1","Held once, here; no reference back (CD-272)."),
 ("Communications Issue","has","Issue Statement","1 : 0..n",""),
 ("Communications Issue","refers to","Social Listening Mention [04]","n : 0..n","04 masters social mentions (CD-272)."),
 ("Crisis Communication Plan","supports","Business Continuity Plan [37]","n : 0..1",""),
 ("Consultation Response","argues","Public Policy Position","n : 0..1",""),
 ("Government Official Contact","is with","Party (Government Official) [02]","n : 1",""),
 ("Government Official Contact","may involve","Gift / Entertainment Item [08]","n : 0..1","08 decides compliance (CD-273)."),
 ("Trade Association Membership","is with","Party (Trade Association) [02]","n : 1","Dues lobbying portion; tax treatment in 19."),
 ("Lobbying Registration","is held by","Internal Legal Entity [09]","n : 1",""),
 ("Lobbying Registration","lists","Registered Lobbyist","1 : 0..n","Lobbyists are 20 employees."),
 ("Lobbying Registration","files","Lobbying Disclosure Report","1 : 0..n",""),
 ("Lobbying Disclosure Report","has","Lobbying Report Issue Line","1 : 0..n","LD-2 only."),
 ("Lobbying Disclosure Report","discloses","Political Contribution [38]","n : 0..n","LD-203; no amount copied (CD-273)."),
 ("Corporate Event","may be announced by","Press Release","n : 0..1","Client and prospect events are 04 EVT-."),
 ("Corporate Event","may be hosted in","Space Reservation [44]","1 : 0..n","Link held on 44."),
 ("Corporate Award Entry","has result in","Award [11]","1 : 0..1","Fund and manager awards only."),
]

# ---------------------------------------------------------------------------
SRC = [
 ("Lobbying Disclosure Act of 1995, as amended by the Honest Leadership and Open Government Act of 2007 (2 U.S.C. 1601 et seq.)","US Congress","https://www.law.cornell.edu/uscode/text/2/chapter-26","Statute","Lobbying contact, covered officials, registration (LD-1), quarterly reports (LD-2), semiannual contribution reports (LD-203)","Lobbying Registration, Registered Lobbyist, Lobbying Disclosure Report, Government Official Contact",["LDA*"]),
 ("Lobbying Disclosure Act Guidance (Clerk of the House and Secretary of the Senate)","US House Clerk; US Senate Secretary","https://lobbyingdisclosure.house.gov/ldaguidance.pdf","Official guidance","Registration thresholds (in-house expenses USD 16,000 per quarter from 2025-01-01), LD-2 content, rounding and expense methods, general issue area codes, LD-203 content and certification, covered official positions within 20 years","Lobbying Disclosure Report, Lobbying Report Issue Line, LDA lists",["LDA Guidance"]),
 ("State lobbying registration and reporting statutes (for example New York Legislative Law Article 1-A, administered by the Commission on Ethics and Lobbying in Government)","US states","https://ethics.ny.gov/lobbying","Statute","State registration of lobbyists and their employers (clients), periodic reports, local jurisdictions","Lobbying Registration, Registrant Category, Lobbying Report Type",["State lobbying statutes"]),
 ("SEC Rule 17a-5(c) (statements of financial condition furnished to customers) and Rule 15c3-1 (net capital)","US SEC","https://www.ecfr.gov/current/title-17/section-240.17a-5","Regulation","Semiannual statement of financial condition (audited at year end) with the net capital note, furnished to customers; website availability as the rule permits (confirm)","Corporate Publication (Statement of Financial Condition), Publication Source Link",["SEC Rule 17a-5(c)", "SEC Rule 15c3-1"]),
 ("SEC Regulation D, Rules 502(c) and 506(c) (general solicitation)","US SEC","https://www.ecfr.gov/current/title-17/chapter-II/part-230","Regulation","Limits on general solicitation in private offerings; the condition under which it is allowed","Press Release (Fund in Offering Indicator)",["SEC Regulation D*"]),
 ("FINRA Rule 2210 (Communications with the Public) and SEC Marketing Rule (Advisers Act Rule 206(4)-1)","FINRA; US SEC","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2210","SRO rule / regulation","When a press release or statement is a retail or institutional communication that 08 reviews; third-party award disclosures","Press Release (Release Compliance Review), Corporate Award Entry",["FINRA Rule 2210", "SEC Marketing Rule"]),
 ("Internal Revenue Code sections 162(e) and 6033(e) (lobbying and political expenditures; notice of nondeductible dues)","US Congress; US IRS","https://www.law.cornell.edu/uscode/text/26/162","Statute","Nondeductible lobbying portion of trade association dues reported by the association","Trade Association Membership, LDA Expense Reporting Method",["IRC 162(e)", "IRC 6033(e)"]),
 ("GRI 2: General Disclosures 2021 (2-28 Membership associations, 2-29 stakeholder engagement) and GRI 415: Public Policy 2016","Global Reporting Initiative","https://www.globalreporting.org/standards/","Open standard","Membership associations, stakeholder groups, public policy and political contribution disclosure","Trade Association Membership, Stakeholder Group, Public Policy Position",["GRI*"]),
 ("PRSA Code of Ethics","Public Relations Society of America","https://www.prsa.org/about/prsa-code-of-ethics","Professional code","Free flow and disclosure of information, conflicts of interest, embargo practice","Media Contact Profile, Press Release, Inquiry Response Type",["PRSA Code of Ethics"]),
 ("Barcelona Principles 4.0 (AMEC, June 2025)","AMEC","https://amecorg.com","Industry framework (confirm URL)","Measurement and evaluation of communications: outcomes over outputs, share of voice and sentiment as contextual measures","Reputation Measurement, Media Coverage Item",["Barcelona Principles 4.0"]),
 ("ISO 20671 Brand evaluation - principles and fundamentals; ISO 10668 Brand valuation (structure only)","ISO","https://www.iso.org/standard/68570.html","Standard (purchase; confirm edition)","Brand strength dimensions used to structure reputation measures and brand standards","Reputation Measure, Brand Standard Version",["ISO 20671"]),
 ("GHG Protocol Corporate Accounting and Reporting Standard","WRI / WBCSD","https://ghgprotocol.org/corporate-standard","Open standard","Scope 1, 2 and 3 emissions published in corporate responsibility reports (figures from 44)","Publication Source Link",["GHG Protocol Corporate Standard"]),
]
